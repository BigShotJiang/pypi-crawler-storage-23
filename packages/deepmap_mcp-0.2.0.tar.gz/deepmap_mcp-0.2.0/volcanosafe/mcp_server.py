#!/usr/bin/env python3
"""
DeepMap AI MCP Server
=====================
Wraps the DeepMap AI API (volcano monitoring, earthquake prediction,
seismic risk, tidal forcing, and LiDAR analysis) as a Model Context
Protocol server for native integration with Claude and other
MCP-compatible LLMs.

Install:
    pip install mcp httpx

Run (stdio, for Claude Desktop):
    python -m volcanosafe.mcp_server

Configure in claude_desktop_config.json:
    {
      "mcpServers": {
        "deepmap": {
          "command": "python",
          "args": ["-m", "volcanosafe.mcp_server"],
          "env": {
            "DEEPMAP_API_URL": "https://api.volcanosafe.com",
            "DEEPMAP_API_KEY": "dm_live_..."
          }
        }
      }
    }

Author: DeepMap AI
"""

from __future__ import annotations

import json
import os
import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Support both new DEEPMAP_API_URL and legacy VOLCANOSAFE_BASE_URL env vars
DEEPMAP_BASE = os.environ.get(
    "DEEPMAP_API_URL",
    os.environ.get("VOLCANOSAFE_BASE_URL", "https://api.volcanosafe.com"),
)
API_KEY = os.environ.get(
    "DEEPMAP_API_KEY",
    os.environ.get("VOLCANOSAFE_API_KEY", ""),
)

# ---------------------------------------------------------------------------
# Static constants
# ---------------------------------------------------------------------------

VOLCANO_IDS = [
    "popocatepetl", "colima", "fuego", "kilauea", "etna",
    "mauna_loa", "pacaya", "cotopaxi", "vesuvius", "rainier",
]
VOLCANO_LIST = ", ".join(VOLCANO_IDS)

EARTHQUAKE_REGIONS = [
    "ucerf3", "new_madrid", "cascadia", "wasatch", "oklahoma", "trans_mexico",
]
EARTHQUAKE_REGION_LIST = ", ".join(EARTHQUAKE_REGIONS)


def _headers() -> dict:
    """Build request headers with optional API key."""
    h = {"Accept": "application/json"}
    if API_KEY:
        h["X-API-Key"] = API_KEY
    return h


def main():
    """Entry point -- run the MCP server over stdio."""
    try:
        from mcp.server import Server
        from mcp.types import Tool, TextContent
        from mcp.server.stdio import stdio_server
    except ImportError:
        print(
            "MCP SDK not installed. Install with:\n"
            "  pip install mcp httpx\n"
        )
        raise SystemExit(1)

    import asyncio
    import httpx

    server = Server("deepmap-ai")

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @server.list_tools()
    async def list_tools():
        return [
            # ==============================================================
            # Volcano tools
            # ==============================================================
            Tool(
                name="volcano_risk",
                description=(
                    "Get a full real-time risk assessment for a volcano. "
                    "Returns risk score (0-100), alert level, seismic data, "
                    "tidal state, travel advisory, and flight impact. "
                    f"Available volcanoes: {VOLCANO_LIST}"
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "volcano_id": {
                            "type": "string",
                            "description": (
                                "Volcano identifier. Options: "
                                + VOLCANO_LIST
                            ),
                        },
                        "include_seismic": {
                            "type": "boolean",
                            "default": True,
                            "description": (
                                "Include real-time USGS seismic query "
                                "(adds ~2s latency but gives live data)"
                            ),
                        },
                    },
                    "required": ["volcano_id"],
                },
            ),
            Tool(
                name="volcano_quick",
                description=(
                    "Get a quick risk score for a volcano (low latency, "
                    "no real-time seismic fetch). Ideal for batch or "
                    "insurance queries. Returns risk score, alert level, "
                    "headline, and insurance advisory."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "volcano_id": {
                            "type": "string",
                            "description": f"Volcano ID. Options: {VOLCANO_LIST}",
                        },
                    },
                    "required": ["volcano_id"],
                },
            ),
            Tool(
                name="volcano_flights",
                description=(
                    "Get flight disruption risk for airports near a volcano. "
                    "Returns affected airports, distance, and disruption "
                    "probability."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "volcano_id": {
                            "type": "string",
                            "description": f"Volcano ID. Options: {VOLCANO_LIST}",
                        },
                    },
                    "required": ["volcano_id"],
                },
            ),
            Tool(
                name="volcano_tidal_forecast",
                description=(
                    "Get a tidal eruption risk window forecast for a volcano. "
                    "Based on peer-reviewed Mf tidal cycle analysis "
                    "(p=0.000132, Schuster test on 40,913 M5+ earthquakes). "
                    "Returns upcoming high-risk time windows."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "volcano_id": {
                            "type": "string",
                            "description": f"Volcano ID. Options: {VOLCANO_LIST}",
                        },
                        "days": {
                            "type": "integer",
                            "default": 14,
                            "description": "Forecast horizon in days (1-30)",
                        },
                    },
                    "required": ["volcano_id"],
                },
            ),
            Tool(
                name="volcano_advisory",
                description=(
                    "Get a plain-text travel advisory for a volcano. "
                    "Returns headline, detailed advisory, insurance "
                    "recommendation, and monitoring agency status."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "volcano_id": {
                            "type": "string",
                            "description": f"Volcano ID. Options: {VOLCANO_LIST}",
                        },
                    },
                    "required": ["volcano_id"],
                },
            ),
            Tool(
                name="volcano_list",
                description=(
                    "List all monitored volcanoes with their names, "
                    "countries, coordinates, and last eruption dates."
                ),
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name="volcano_batch",
                description=(
                    "Get quick risk scores for multiple volcanoes at once. "
                    "Returns risk score and alert level for each. "
                    "Max 10 volcanoes per request."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "volcano_ids": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "List of volcano IDs. "
                                f"Options: {VOLCANO_LIST}"
                            ),
                        },
                    },
                    "required": ["volcano_ids"],
                },
            ),

            # ==============================================================
            # Earthquake tools
            # ==============================================================
            Tool(
                name="predict_earthquake",
                description=(
                    "Run ML earthquake risk prediction for a specific "
                    "region. Returns risk score, confidence, contributing "
                    "features, and alert recommendation. Uses "
                    "GradientBoosting model trained on real USGS data. "
                    f"Available regions: {EARTHQUAKE_REGION_LIST}"
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "region": {
                            "type": "string",
                            "description": (
                                "Earthquake monitoring region. Options: "
                                + EARTHQUAKE_REGION_LIST
                            ),
                        },
                    },
                    "required": ["region"],
                },
            ),
            Tool(
                name="list_earthquake_regions",
                description=(
                    "List all supported earthquake monitoring regions "
                    "with bounds, historical seismicity rate, and "
                    "magnitude of completeness (Mc)."
                ),
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name="assess_current_earthquakes",
                description=(
                    "Run current global seismic risk assessment across "
                    "all monitored regions using live USGS data. Returns "
                    "per-region risk levels, recent event counts, and "
                    "anomaly flags."
                ),
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name="earthquake_alert_cycle",
                description=(
                    "Run a full earthquake alert cycle across all "
                    "monitored regions. Returns current alert status, "
                    "triggered alerts, and recommended actions for each "
                    "region."
                ),
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name="predict_seismic_risk",
                description=(
                    "Seismic hazard risk assessment for any geographic "
                    "location. Combines Vs30 site classification with "
                    "regional seismicity to produce a composite risk "
                    "score (0-10). Includes liquefaction probability "
                    "and amplification factor. Useful for insurance "
                    "underwriting and real estate due diligence."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "latitude": {
                            "type": "number",
                            "description": "Latitude in decimal degrees",
                        },
                        "longitude": {
                            "type": "number",
                            "description": "Longitude in decimal degrees",
                        },
                        "radius_km": {
                            "type": "number",
                            "default": 100,
                            "description": (
                                "Search radius in km for nearest seismic "
                                "stations (default: 100)"
                            ),
                        },
                    },
                    "required": ["latitude", "longitude"],
                },
            ),
            Tool(
                name="analyze_tidal_forcing",
                description=(
                    "Analyze tidal stress forcing on earthquake "
                    "triggering at a location. Tests whether earthquake "
                    "occurrence is modulated by solid Earth tides using "
                    "Schuster's test and Rayleigh statistics. Returns "
                    "tidal phase correlation, p-values, and stress "
                    "decomposition by tidal constituent."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "latitude": {
                            "type": "number",
                            "description": "Region center latitude",
                        },
                        "longitude": {
                            "type": "number",
                            "description": "Region center longitude",
                        },
                    },
                    "required": ["latitude", "longitude"],
                },
            ),
            Tool(
                name="detect_fault_scarps",
                description=(
                    "Detect fault scarps from LiDAR/3DEP slope-break "
                    "analysis. Identifies linear fault traces from "
                    "digital elevation models using gradient and "
                    "curvature analysis. Returns detected scarps with "
                    "strike, dip direction, and length estimates."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "rows": {
                            "type": "integer",
                            "default": 200,
                            "description": "DEM grid rows (default: 200)",
                        },
                        "cols": {
                            "type": "integer",
                            "default": 200,
                            "description": "DEM grid columns (default: 200)",
                        },
                    },
                    "required": [],
                },
            ),
        ]

    # ------------------------------------------------------------------
    # Tool execution
    # ------------------------------------------------------------------

    @server.call_tool()
    async def call_tool(name: str, arguments: dict):
        async with httpx.AsyncClient(
            base_url=DEEPMAP_BASE,
            headers=_headers(),
            timeout=30.0,
        ) as client:
            try:
                # ======================================================
                # Volcano tools
                # ======================================================
                if name == "volcano_risk":
                    vid = arguments["volcano_id"]
                    params = {}
                    if not arguments.get("include_seismic", True):
                        params["include_seismic"] = "false"
                    resp = await client.get(f"/v1/risk/{vid}", params=params)

                elif name == "volcano_quick":
                    vid = arguments["volcano_id"]
                    resp = await client.get(f"/v1/quick/{vid}")

                elif name == "volcano_flights":
                    vid = arguments["volcano_id"]
                    resp = await client.get(f"/v1/flights/{vid}")

                elif name == "volcano_tidal_forecast":
                    vid = arguments["volcano_id"]
                    days = arguments.get("days", 14)
                    resp = await client.get(
                        f"/v1/tidal/{vid}", params={"days": days}
                    )

                elif name == "volcano_advisory":
                    vid = arguments["volcano_id"]
                    resp = await client.get(f"/v1/advisory/{vid}")

                elif name == "volcano_list":
                    resp = await client.get("/v1/volcanoes")

                elif name == "volcano_batch":
                    ids = arguments.get("volcano_ids", [])
                    ids_str = ",".join(ids[:10])
                    resp = await client.get(
                        "/v1/batch", params={"ids": ids_str}
                    )

                # ======================================================
                # Earthquake tools
                # ======================================================
                elif name == "predict_earthquake":
                    region = arguments["region"]
                    resp = await client.get(
                        f"/api/v1/earthquake/predict/{region}"
                    )

                elif name == "list_earthquake_regions":
                    resp = await client.get("/api/v1/earthquake/regions")

                elif name == "assess_current_earthquakes":
                    resp = await client.get(
                        "/api/v1/earthquake/assess-current"
                    )

                elif name == "earthquake_alert_cycle":
                    resp = await client.get(
                        "/api/v1/earthquake/alert-cycle"
                    )

                elif name == "predict_seismic_risk":
                    lat = arguments["latitude"]
                    lon = arguments["longitude"]
                    radius = arguments.get("radius_km", 100)
                    resp = await client.post(
                        "/api/v1/predict/seismic-risk",
                        json={
                            "lat": lat,
                            "lon": lon,
                            "radius_km": radius,
                        },
                    )

                elif name == "analyze_tidal_forcing":
                    lat = arguments["latitude"]
                    lon = arguments["longitude"]
                    resp = await client.post(
                        "/api/v1/cross-physics/tidal-forcing",
                        json={
                            "lat": lat,
                            "lon": lon,
                            "use_demo": True,
                        },
                    )

                elif name == "detect_fault_scarps":
                    rows = arguments.get("rows", 200)
                    cols = arguments.get("cols", 200)
                    resp = await client.post(
                        "/api/v1/lidar/fault-scarps",
                        params={"rows": rows, "cols": cols},
                    )

                else:
                    return [TextContent(
                        type="text",
                        text=f"Unknown tool: {name}",
                    )]

                # Handle errors
                if resp.status_code != 200:
                    return [TextContent(
                        type="text",
                        text=(
                            f"API error {resp.status_code}: "
                            f"{resp.text}"
                        ),
                    )]

                data = resp.json()
                return [TextContent(
                    type="text",
                    text=json.dumps(data, indent=2, default=str),
                )]

            except httpx.ConnectError:
                return [TextContent(
                    type="text",
                    text=(
                        f"Cannot connect to DeepMap AI API at "
                        f"{DEEPMAP_BASE}. Is the server running?"
                    ),
                )]
            except Exception as e:
                return [TextContent(
                    type="text",
                    text=f"Error calling DeepMap AI API: {e}",
                )]

    # ------------------------------------------------------------------
    # Run
    # ------------------------------------------------------------------

    async def _run():
        async with stdio_server() as (read, write):
            await server.run(read, write)

    logger.info("Starting DeepMap AI MCP server (base=%s)", DEEPMAP_BASE)
    asyncio.run(_run())


if __name__ == "__main__":
    main()
