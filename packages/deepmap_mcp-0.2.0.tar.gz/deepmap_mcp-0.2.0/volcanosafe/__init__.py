"""DeepMap AI -- Real-time volcano monitoring, earthquake prediction, and geophysical intelligence."""
__version__ = "0.2.0"
