"""
VolcanoSafe -- Risk Assessment Engine
======================================

Computes real-time volcano risk scores for tourism and travel insurance.
Combines seismic data, tidal forcing, eruption history, and atmospheric
dispersion to produce tourist-friendly risk assessments.

No dedicated hardware required -- all data from public APIs.
"""

from __future__ import annotations

import math
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import numpy as np
import requests

# =====================================================================
# Volcano Database (with tourism context)
# =====================================================================

VOLCANOES = {
    "popocatepetl": {
        "name": "Popocatepetl",
        "country": "Mexico",
        "lat": 19.023,
        "lon": -98.628,
        "elevation_m": 5426,
        "vei_typical": 2,
        "last_eruption": "2024-ongoing",
        "exclusion_zone_km": 12,
        "nearby_pop_millions": 25.0,
        "nearby_airports": ["MMMX"],
        "airport_names": ["Mexico City (MEX)"],
        "airport_distance_km": [70],
        "tourism_notes": "Most active volcano in Mexico. Visible from Mexico City. 12km exclusion zone enforced by CENAPRED.",
        "monitoring": "CENAPRED Level 2 Yellow",
        "rs_station": "RD265",
    },
    "colima": {
        "name": "Volcan de Colima",
        "country": "Mexico",
        "lat": 19.514,
        "lon": -103.617,
        "elevation_m": 3839,
        "vei_typical": 3,
        "last_eruption": "2019",
        "exclusion_zone_km": 8,
        "nearby_pop_millions": 5.0,
        "nearby_airports": ["MMGL"],
        "airport_names": ["Guadalajara (GDL)"],
        "airport_distance_km": [130],
        "tourism_notes": "Most active volcano in North America by eruption frequency. Popular for volcanology tourism.",
        "monitoring": "University of Colima",
        "rs_station": "R457D",
    },
    "fuego": {
        "name": "Fuego",
        "country": "Guatemala",
        "lat": 14.473,
        "lon": -90.880,
        "elevation_m": 3763,
        "vei_typical": 2,
        "last_eruption": "2024-ongoing",
        "exclusion_zone_km": 6,
        "nearby_pop_millions": 3.5,
        "nearby_airports": ["MGGT"],
        "airport_names": ["Guatemala City (GUA)"],
        "airport_distance_km": [50],
        "tourism_notes": "Frequently active stratovolcano. 2018 VEI-3 eruption killed 190+ people. Popular Acatenango hike offers views.",
        "monitoring": "INSIVUMEH",
        "rs_station": None,
    },
    "kilauea": {
        "name": "Kilauea",
        "country": "USA",
        "lat": 19.421,
        "lon": -155.287,
        "elevation_m": 1247,
        "vei_typical": 1,
        "last_eruption": "2023",
        "exclusion_zone_km": 2,
        "nearby_pop_millions": 0.2,
        "nearby_airports": ["PHTO", "PHNL"],
        "airport_names": ["Hilo (ITO)", "Honolulu (HNL)"],
        "airport_distance_km": [45, 340],
        "tourism_notes": "Shield volcano with effusive eruptions. Hawaii Volcanoes National Park receives 1.3M visitors/year.",
        "monitoring": "USGS HVO",
        "rs_station": "R64DA",
    },
    "etna": {
        "name": "Mount Etna",
        "country": "Italy",
        "lat": 37.751,
        "lon": 15.004,
        "elevation_m": 3357,
        "vei_typical": 2,
        "last_eruption": "2024-ongoing",
        "exclusion_zone_km": 3,
        "nearby_pop_millions": 1.2,
        "nearby_airports": ["LICC"],
        "airport_names": ["Catania (CTA)"],
        "airport_distance_km": [30],
        "tourism_notes": "Europe's most active volcano. UNESCO World Heritage. Popular hiking and skiing destination.",
        "monitoring": "INGV",
        "rs_station": "RD640",
    },
    "mauna_loa": {
        "name": "Mauna Loa",
        "country": "USA",
        "lat": 19.475,
        "lon": -155.608,
        "elevation_m": 4169,
        "vei_typical": 0,
        "last_eruption": "2022",
        "exclusion_zone_km": 5,
        "nearby_pop_millions": 0.2,
        "nearby_airports": ["PHTO", "PHKO"],
        "airport_names": ["Hilo (ITO)", "Kona (KOA)"],
        "airport_distance_km": [50, 60],
        "tourism_notes": "World's largest active volcano by volume. Effusive lava flows. Low explosive risk.",
        "monitoring": "USGS HVO",
        "rs_station": "R3A8A",
    },
    "pacaya": {
        "name": "Pacaya",
        "country": "Guatemala",
        "lat": 14.382,
        "lon": -90.601,
        "elevation_m": 2552,
        "vei_typical": 1,
        "last_eruption": "2024-ongoing",
        "exclusion_zone_km": 2.5,
        "nearby_pop_millions": 3.5,
        "nearby_airports": ["MGGT"],
        "airport_names": ["Guatemala City (GUA)"],
        "airport_distance_km": [35],
        "tourism_notes": "Most visited volcano in Guatemala. Guided hikes to lava flows. Marshmallow roasting popular.",
        "monitoring": "INSIVUMEH",
        "rs_station": None,
    },
    "cotopaxi": {
        "name": "Cotopaxi",
        "country": "Ecuador",
        "lat": -0.677,
        "lon": -78.436,
        "elevation_m": 5897,
        "vei_typical": 3,
        "last_eruption": "2023",
        "exclusion_zone_km": 15,
        "nearby_pop_millions": 3.0,
        "nearby_airports": ["SEQM"],
        "airport_names": ["Quito (UIO)"],
        "airport_distance_km": [60],
        "tourism_notes": "One of world's highest active volcanoes. Major lahar risk to Quito. Climbing permits required.",
        "monitoring": "IG-EPN",
        "rs_station": None,
    },
    "vesuvius": {
        "name": "Vesuvius",
        "country": "Italy",
        "lat": 40.821,
        "lon": 14.426,
        "elevation_m": 1281,
        "vei_typical": 3,
        "last_eruption": "1944",
        "exclusion_zone_km": 7,
        "nearby_pop_millions": 3.0,
        "nearby_airports": ["LIRN"],
        "airport_names": ["Naples (NAP)"],
        "airport_distance_km": [15],
        "tourism_notes": "3M+ people in red zone. 2.5M tourists/year to ruins + crater. Dormant but dangerous.",
        "monitoring": "INGV OV",
        "rs_station": None,
    },
    "rainier": {
        "name": "Mount Rainier",
        "country": "USA",
        "lat": 46.853,
        "lon": -121.760,
        "elevation_m": 4392,
        "vei_typical": 3,
        "last_eruption": "1894",
        "exclusion_zone_km": 10,
        "nearby_pop_millions": 4.0,
        "nearby_airports": ["KSEA"],
        "airport_names": ["Seattle-Tacoma (SEA)"],
        "airport_distance_km": [87],
        "tourism_notes": "Most dangerous volcano in USA (lahar risk). 2M+ visitors/year to National Park.",
        "monitoring": "USGS CVO",
        "rs_station": None,
    },
}

# Tidal constituents for eruption window computation
TIDAL_CONSTITUENTS = {
    "M2": {"period_hours": 12.4206, "name": "Principal lunar semidiurnal"},
    "K1": {"period_hours": 23.9345, "name": "Lunisolar diurnal"},
    "Mf": {"period_hours": 13.661 * 24, "name": "Lunar fortnightly"},  # 13.66 days
}


# =====================================================================
# Seismic Data Fetcher (USGS real-time)
# =====================================================================

def fetch_recent_seismicity(lat: float, lon: float, radius_km: float = 50,
                            days: int = 30, min_mag: float = 1.0) -> Dict:
    """Fetch recent earthquakes near a volcano from USGS."""
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=days)

    params = {
        "format": "geojson",
        "starttime": start.strftime("%Y-%m-%dT00:00:00"),
        "endtime": end.strftime("%Y-%m-%dT%H:%M:%S"),
        "latitude": lat,
        "longitude": lon,
        "maxradiuskm": radius_km,
        "minmagnitude": min_mag,
        "limit": 5000,
        "orderby": "time",
    }

    try:
        resp = requests.get(
            "https://earthquake.usgs.gov/fdsnws/event/1/query",
            params=params, timeout=30,
        )
        if resp.status_code != 200:
            return {"n_events": 0, "events": [], "error": f"HTTP {resp.status_code}"}

        data = resp.json()
        features = data.get("features", [])

        events = []
        for f in features:
            p = f["properties"]
            c = f["geometry"]["coordinates"]
            events.append({
                "time": p.get("time"),
                "mag": p.get("mag"),
                "depth": c[2],
                "lat": c[1],
                "lon": c[0],
                "place": p.get("place", ""),
            })

        mags = [e["mag"] for e in events if e["mag"] is not None]
        depths = [e["depth"] for e in events if e["depth"] is not None]

        return {
            "n_events": len(events),
            "max_mag": max(mags) if mags else 0,
            "mean_mag": round(np.mean(mags), 2) if mags else 0,
            "mean_depth_km": round(np.mean(depths), 1) if depths else 0,
            "events_per_day": round(len(events) / max(days, 1), 1),
            "events": events[:20],  # Return last 20 for display
        }

    except Exception as e:
        return {"n_events": 0, "events": [], "error": str(e)}


# =====================================================================
# Tidal Eruption Window Calculator
# =====================================================================

def compute_tidal_stress(dt: datetime, lat: float) -> Dict:
    """Compute current tidal stress state at a location."""
    # Julian day from J2000.0
    jd = (dt - datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)).total_seconds() / 86400.0

    results = {}
    for name, info in TIDAL_CONSTITUENTS.items():
        period_days = info["period_hours"] / 24.0
        phase = (jd % period_days) / period_days * 2 * math.pi
        stress = math.cos(phase)  # Normalized -1 to +1

        results[name] = {
            "phase_rad": round(phase, 4),
            "phase_deg": round(math.degrees(phase), 1),
            "stress_normalized": round(stress, 4),
            "state": "compressive" if stress > 0.3 else "extensional" if stress < -0.3 else "neutral",
        }

    # Combined tidal risk (Mf-weighted, based on our p=0.000132 finding)
    mf_stress = results["Mf"]["stress_normalized"]
    k1_stress = results["K1"]["stress_normalized"]
    combined = 0.6 * abs(mf_stress) + 0.3 * abs(k1_stress) + 0.1 * abs(results["M2"]["stress_normalized"])

    results["combined_tidal_risk"] = round(combined, 3)
    results["tidal_risk_label"] = (
        "HIGH" if combined > 0.7 else
        "MODERATE" if combined > 0.4 else
        "LOW"
    )

    return results


def forecast_tidal_windows(lat: float, days_ahead: int = 14) -> List[Dict]:
    """Forecast high-tidal-risk windows for the next N days."""
    windows = []
    now = datetime.now(timezone.utc)
    in_window = False
    window_start = None

    # Scan hourly
    for hour in range(days_ahead * 24):
        dt = now + timedelta(hours=hour)
        tidal = compute_tidal_stress(dt, lat)
        risk = tidal["combined_tidal_risk"]

        if risk > 0.6 and not in_window:
            in_window = True
            window_start = dt
        elif risk <= 0.6 and in_window:
            in_window = False
            duration = (dt - window_start).total_seconds() / 3600
            # Find peak in this window
            peak_risk = 0
            peak_time = window_start
            for h in range(int(duration)):
                check_dt = window_start + timedelta(hours=h)
                check_risk = compute_tidal_stress(check_dt, lat)["combined_tidal_risk"]
                if check_risk > peak_risk:
                    peak_risk = check_risk
                    peak_time = check_dt

            windows.append({
                "start": window_start.isoformat(),
                "end": dt.isoformat(),
                "peak_time": peak_time.isoformat(),
                "peak_risk": round(peak_risk, 3),
                "duration_hours": round(duration, 1),
            })

    return windows


# =====================================================================
# Core Risk Assessment
# =====================================================================

def assess_volcano_risk(volcano_id: str, include_seismic: bool = True) -> Dict:
    """
    Compute comprehensive tourism risk score for a volcano.

    Returns a tourist-friendly risk assessment with:
    - risk_score (0-100)
    - alert_level (1-5 scale)
    - travel_advisory (plain English)
    - tidal_forecast (next 14 days)
    - flight_impact (airport disruption risk)
    """
    volcano_id = volcano_id.lower().replace(" ", "_").replace("-", "_")

    if volcano_id not in VOLCANOES:
        return {"error": f"Unknown volcano: {volcano_id}", "available": list(VOLCANOES.keys())}

    v = VOLCANOES[volcano_id]
    now = datetime.now(timezone.utc)

    # 1. Base risk from eruption recency and VEI
    years_since = _years_since_eruption(v["last_eruption"])
    if "ongoing" in v["last_eruption"]:
        base_risk = 65 + v["vei_typical"] * 5  # Currently active
    elif years_since < 2:
        base_risk = 45 + v["vei_typical"] * 3
    elif years_since < 10:
        base_risk = 25 + v["vei_typical"] * 2
    elif years_since < 50:
        base_risk = 15 + v["vei_typical"]
    else:
        base_risk = 5

    # 2. Seismic component (real-time from USGS)
    seismic = {"n_events": 0}
    seismic_risk = 0
    if include_seismic:
        seismic = fetch_recent_seismicity(v["lat"], v["lon"], radius_km=50, days=30)
        rate = seismic.get("events_per_day", 0)
        max_mag = seismic.get("max_mag", 0)

        if rate > 20:
            seismic_risk = 30
        elif rate > 10:
            seismic_risk = 20
        elif rate > 5:
            seismic_risk = 12
        elif rate > 1:
            seismic_risk = 5
        else:
            seismic_risk = 0

        if max_mag > 4.0:
            seismic_risk += 15
        elif max_mag > 3.0:
            seismic_risk += 8
        elif max_mag > 2.0:
            seismic_risk += 3

    # 3. Tidal component
    tidal = compute_tidal_stress(now, v["lat"])
    tidal_risk = tidal["combined_tidal_risk"] * 10  # 0-10 points

    # 4. Combined risk score
    risk_score = min(100, base_risk + seismic_risk + tidal_risk)

    # 5. Alert level (1-5)
    if risk_score >= 80:
        alert_level = 5
        alert_name = "DANGER"
        alert_color = "#FF0000"
    elif risk_score >= 60:
        alert_level = 4
        alert_name = "WARNING"
        alert_color = "#FF6600"
    elif risk_score >= 40:
        alert_level = 3
        alert_name = "WATCH"
        alert_color = "#FFCC00"
    elif risk_score >= 20:
        alert_level = 2
        alert_name = "ADVISORY"
        alert_color = "#00AAFF"
    else:
        alert_level = 1
        alert_name = "NORMAL"
        alert_color = "#00CC44"

    # 6. Travel advisory text
    advisory = _generate_advisory(v, risk_score, alert_name, seismic, tidal)

    # 7. Flight impact
    flight_impact = []
    for i, apt in enumerate(v.get("nearby_airports", [])):
        dist = v["airport_distance_km"][i] if i < len(v.get("airport_distance_km", [])) else 999
        apt_name = v["airport_names"][i] if i < len(v.get("airport_names", [])) else apt

        if risk_score >= 70 and dist < 100:
            flight_risk = "HIGH -- Ash cloud closures likely"
        elif risk_score >= 50 and dist < 150:
            flight_risk = "MODERATE -- Possible delays during eruption"
        elif risk_score >= 30 and dist < 80:
            flight_risk = "LOW -- Monitor for ash advisories"
        else:
            flight_risk = "MINIMAL"

        flight_impact.append({
            "airport_code": apt,
            "airport_name": apt_name,
            "distance_km": dist,
            "disruption_risk": flight_risk,
        })

    # 8. Tidal forecast windows
    tidal_windows = forecast_tidal_windows(v["lat"], days_ahead=14)

    return {
        "volcano": {
            "id": volcano_id,
            "name": v["name"],
            "country": v["country"],
            "lat": v["lat"],
            "lon": v["lon"],
            "elevation_m": v["elevation_m"],
        },
        "assessment": {
            "timestamp": now.isoformat(),
            "risk_score": round(risk_score, 1),
            "alert_level": alert_level,
            "alert_name": alert_name,
            "alert_color": alert_color,
            "components": {
                "base_risk": round(base_risk, 1),
                "seismic_risk": round(seismic_risk, 1),
                "tidal_risk": round(tidal_risk, 1),
            },
        },
        "travel_advisory": advisory,
        "seismicity": {
            "period_days": 30,
            "n_events": seismic.get("n_events", 0),
            "max_magnitude": seismic.get("max_mag", 0),
            "events_per_day": seismic.get("events_per_day", 0),
            "mean_depth_km": seismic.get("mean_depth_km", 0),
        },
        "tidal_state": tidal,
        "tidal_forecast_14d": tidal_windows[:10],  # Top 10 windows
        "flight_impact": flight_impact,
        "monitoring": {
            "agency": v.get("monitoring", "Unknown"),
            "exclusion_zone_km": v.get("exclusion_zone_km"),
            "nearby_population_millions": v.get("nearby_pop_millions"),
        },
        "tourism_notes": v.get("tourism_notes", ""),
    }


def _years_since_eruption(last_eruption: str) -> float:
    """Parse years since last eruption string."""
    if "ongoing" in last_eruption:
        return 0
    try:
        year = int(last_eruption[:4])
        return datetime.now().year - year
    except (ValueError, IndexError):
        return 100


def _generate_advisory(volcano: Dict, risk_score: float, alert_name: str,
                       seismic: Dict, tidal: Dict) -> Dict:
    """Generate tourist-friendly travel advisory."""
    name = volcano["name"]
    country = volcano["country"]

    if risk_score >= 80:
        headline = f"DO NOT TRAVEL to {name} area"
        summary = (
            f"{name} in {country} poses an imminent danger. Active eruption or "
            f"strong precursory signals detected. Stay outside the "
            f"{volcano['exclusion_zone_km']} km exclusion zone. Follow local "
            f"civil protection instructions."
        )
        recommendation = "Cancel plans. Monitor official advisories. Have evacuation route ready."
    elif risk_score >= 60:
        headline = f"RECONSIDER TRAVEL near {name}"
        summary = (
            f"{name} in {country} shows elevated volcanic activity. "
            f"{'Significant seismic unrest detected. ' if seismic.get('events_per_day', 0) > 5 else ''}"
            f"{'Tidal stress is currently high, increasing eruption probability. ' if tidal.get('tidal_risk_label') == 'HIGH' else ''}"
            f"Eruption possible with limited warning."
        )
        recommendation = "Avoid areas within exclusion zone. Purchase travel insurance with volcanic coverage. Check flights 24h before departure."
    elif risk_score >= 40:
        headline = f"EXERCISE CAUTION near {name}"
        summary = (
            f"{name} in {country} has moderate volcanic activity. "
            f"The volcano {'is currently active' if 'ongoing' in volcano.get('last_eruption', '') else 'has recent eruption history'}. "
            f"Minor eruptions may occur."
        )
        recommendation = "Travel is possible but register with embassy. Stay informed of alert level changes. Avoid summit areas."
    elif risk_score >= 20:
        headline = f"NORMAL PRECAUTIONS for {name} area"
        summary = (
            f"{name} in {country} shows typical background activity. "
            f"The volcano is monitored continuously. No immediate concern."
        )
        recommendation = "Safe for tourism. Stay on marked trails. Follow park ranger instructions."
    else:
        headline = f"{name} area is SAFE for travel"
        summary = (
            f"{name} in {country} is at normal background levels. "
            f"Enjoy your visit!"
        )
        recommendation = "No restrictions. Enjoy the volcanic scenery safely."

    return {
        "headline": headline,
        "summary": summary,
        "recommendation": recommendation,
        "insurance_advisory": "YES" if risk_score >= 40 else "RECOMMENDED" if risk_score >= 20 else "OPTIONAL",
        "updated": datetime.now(timezone.utc).isoformat(),
    }


def list_volcanoes() -> List[Dict]:
    """List all monitored volcanoes with basic info."""
    result = []
    for vid, v in VOLCANOES.items():
        result.append({
            "id": vid,
            "name": v["name"],
            "country": v["country"],
            "lat": v["lat"],
            "lon": v["lon"],
            "elevation_m": v["elevation_m"],
            "last_eruption": v["last_eruption"],
            "monitoring": v.get("monitoring", ""),
        })
    return result
