"""Allow running as `python -m volcanosafe`."""
from volcanosafe.mcp_server import main

main()
