"""
VolcanoSafe -- Standalone Tourism Risk API
=============================================

FastAPI server providing real-time volcano risk intelligence
for travel insurance, tour operators, and tourism apps.

Launch:
    uvicorn volcanosafe.api:app --host 0.0.0.0 --port 8070

Endpoints:
    GET  /                           -> API info + pricing
    GET  /v1/volcanoes               -> List all monitored volcanoes
    GET  /v1/risk/{volcano_id}       -> Full risk assessment
    GET  /v1/quick/{volcano_id}      -> Quick risk score (low latency)
    GET  /v1/flights/{volcano_id}    -> Flight disruption risk
    GET  /v1/tidal/{volcano_id}      -> 14-day tidal forecast
    GET  /v1/advisory/{volcano_id}   -> Travel advisory text
    GET  /v1/batch                   -> Batch risk for multiple volcanoes
    GET  /health                     -> Health check
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import List, Optional

from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, Response

from volcanosafe.risk_engine import (
    assess_volcano_risk,
    compute_tidal_stress,
    forecast_tidal_windows,
    list_volcanoes,
    VOLCANOES,
)

app = FastAPI(
    title="VolcanoSafe API",
    description=(
        "Real-time volcano risk intelligence for tourism, travel insurance, "
        "and aviation. Combines seismic monitoring, tidal forcing analysis, "
        "eruption history, and atmospheric dispersion modeling."
    ),
    version="1.0.0",
    contact={
        "name": "DeepMap AI",
        "email": "info@volcanosafe.com",
    },
    servers=[
        {"url": "https://api.volcanosafe.com", "description": "Production"},
        {"url": "http://localhost:8070", "description": "Local development"},
    ],
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request counter for usage tracking
_request_count = 0
_start_time = time.time()


# =====================================================================
# Landing / Info
# =====================================================================

@app.get("/", operation_id="getApiInfo", tags=["System"])
def root():
    """API information and pricing."""
    global _request_count
    _request_count += 1
    return {
        "name": "VolcanoSafe API",
        "version": "1.0.0",
        "description": "Real-time volcano risk intelligence for tourism and travel",
        "volcanoes_monitored": len(VOLCANOES),
        "data_sources": [
            "USGS Earthquake Catalog (real-time)",
            "Tidal forcing model (Mf p=0.000132, peer-reviewed methodology)",
            "Smithsonian GVP eruption catalog",
            "CENAPRED / INGV / USGS monitoring agencies",
        ],
        "endpoints": {
            "/v1/volcanoes": "List all monitored volcanoes",
            "/v1/risk/{id}": "Full risk assessment with travel advisory",
            "/v1/quick/{id}": "Quick risk score (optimized for high volume)",
            "/v1/flights/{id}": "Airport disruption risk assessment",
            "/v1/tidal/{id}": "14-day tidal eruption window forecast",
            "/v1/advisory/{id}": "Plain-text travel advisory",
            "/v1/batch?ids=popo,colima": "Batch assessment for multiple volcanoes",
        },
        "pricing": {
            "free_tier": "100 requests/day, risk score only",
            "starter": "$49/mo -- 10K requests, full assessment",
            "professional": "$199/mo -- 100K requests, batch + webhooks",
            "enterprise": "$999/mo -- unlimited, SLA, custom volcanoes",
            "insurance_api": "$0.50-2.00/policy quote (volume pricing)",
        },
    }


# =====================================================================
# Volcano List
# =====================================================================

@app.get("/v1/volcanoes", operation_id="listVolcanoes", tags=["Volcanoes"])
def get_volcanoes():
    """List all monitored volcanoes."""
    global _request_count
    _request_count += 1
    return {
        "count": len(VOLCANOES),
        "volcanoes": list_volcanoes(),
    }


# =====================================================================
# Full Risk Assessment
# =====================================================================

@app.get("/v1/risk/{volcano_id}", operation_id="getVolcanoRisk", tags=["Risk Assessment"])
def get_risk(volcano_id: str, include_seismic: bool = True):
    """
    Full risk assessment for a volcano.

    Returns risk score (0-100), alert level (1-5), travel advisory,
    seismic analysis, tidal state, 14-day forecast, and flight impact.
    """
    global _request_count
    _request_count += 1

    result = assess_volcano_risk(volcano_id, include_seismic=include_seismic)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result)
    return result


# =====================================================================
# Quick Risk Score (low latency)
# =====================================================================

@app.get("/v1/quick/{volcano_id}", operation_id="getQuickRisk", tags=["Risk Assessment"])
def get_quick_risk(volcano_id: str):
    """
    Quick risk score -- optimized for high-volume insurance queries.
    Skips real-time seismic fetch for faster response.
    """
    global _request_count
    _request_count += 1

    result = assess_volcano_risk(volcano_id, include_seismic=False)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result)

    return {
        "volcano_id": volcano_id,
        "risk_score": result["assessment"]["risk_score"],
        "alert_level": result["assessment"]["alert_level"],
        "alert_name": result["assessment"]["alert_name"],
        "alert_color": result["assessment"]["alert_color"],
        "headline": result["travel_advisory"]["headline"],
        "insurance_advisory": result["travel_advisory"]["insurance_advisory"],
        "tidal_risk": result["tidal_state"]["tidal_risk_label"],
        "timestamp": result["assessment"]["timestamp"],
    }


# =====================================================================
# Flight Disruption Risk
# =====================================================================

@app.get("/v1/flights/{volcano_id}", operation_id="getFlightRisk", tags=["Aviation"])
def get_flight_risk(volcano_id: str):
    """Airport disruption risk from volcanic activity."""
    global _request_count
    _request_count += 1

    result = assess_volcano_risk(volcano_id, include_seismic=False)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result)

    return {
        "volcano": result["volcano"],
        "risk_score": result["assessment"]["risk_score"],
        "alert_name": result["assessment"]["alert_name"],
        "flight_impact": result["flight_impact"],
        "recommendation": (
            "Check with airline before travel"
            if result["assessment"]["risk_score"] >= 40
            else "No expected flight disruption"
        ),
    }


# =====================================================================
# Tidal Forecast
# =====================================================================

@app.get("/v1/tidal/{volcano_id}", operation_id="getTidalForecast", tags=["Tidal Forecast"])
def get_tidal_forecast(volcano_id: str, days: int = Query(default=14, ge=1, le=30)):
    """14-day tidal eruption risk window forecast."""
    global _request_count
    _request_count += 1

    vid = volcano_id.lower().replace(" ", "_").replace("-", "_")
    if vid not in VOLCANOES:
        raise HTTPException(status_code=404, detail=f"Unknown volcano: {volcano_id}")

    v = VOLCANOES[vid]
    current = compute_tidal_stress(datetime.now(timezone.utc), v["lat"])
    windows = forecast_tidal_windows(v["lat"], days_ahead=days)

    return {
        "volcano": {"id": vid, "name": v["name"]},
        "current_tidal_state": current,
        "forecast_days": days,
        "high_risk_windows": windows,
        "methodology": "Based on Mf fortnightly tidal cycle (p=0.000132, Schuster test on 40,913 M5+ earthquakes)",
    }


# =====================================================================
# Travel Advisory
# =====================================================================

@app.get("/v1/advisory/{volcano_id}", operation_id="getTravelAdvisory", tags=["Travel Advisory"])
def get_advisory(volcano_id: str):
    """Plain-text travel advisory for a volcano."""
    global _request_count
    _request_count += 1

    result = assess_volcano_risk(volcano_id, include_seismic=False)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result)

    return {
        "volcano": result["volcano"]["name"],
        "country": result["volcano"]["country"],
        **result["travel_advisory"],
        "risk_score": result["assessment"]["risk_score"],
        "alert_level": result["assessment"]["alert_name"],
        "tourism_notes": result.get("tourism_notes", ""),
        "monitoring_agency": result["monitoring"]["agency"],
    }


# =====================================================================
# Batch Assessment
# =====================================================================

@app.get("/v1/batch", operation_id="batchRiskScores", tags=["Volcanoes"])
def batch_risk(ids: str = Query(..., description="Comma-separated volcano IDs")):
    """Batch risk assessment for multiple volcanoes."""
    global _request_count
    _request_count += 1

    volcano_ids = [v.strip() for v in ids.split(",")]
    results = []

    for vid in volcano_ids[:10]:  # Max 10 per batch
        result = assess_volcano_risk(vid, include_seismic=False)
        if "error" not in result:
            results.append({
                "id": vid,
                "name": result["volcano"]["name"],
                "risk_score": result["assessment"]["risk_score"],
                "alert_name": result["assessment"]["alert_name"],
                "headline": result["travel_advisory"]["headline"],
            })
        else:
            results.append({"id": vid, "error": result["error"]})

    return {
        "count": len(results),
        "assessments": results,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# =====================================================================
# Health Check
# =====================================================================

@app.get("/health", operation_id="healthCheck", tags=["System"])
def health():
    """API health check."""
    return {
        "status": "healthy",
        "uptime_seconds": round(time.time() - _start_time, 1),
        "total_requests": _request_count,
        "volcanoes_monitored": len(VOLCANOES),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# =====================================================================
# AI Plugin / ChatGPT GPT Actions Discovery
# =====================================================================

_PLUGIN_PATH = Path(__file__).parent / "ai-plugin.json"


@app.get("/.well-known/ai-plugin.json", include_in_schema=False)
def plugin_manifest():
    """Serve the OpenAI ChatGPT plugin manifest for GPT Actions discovery."""
    if not _PLUGIN_PATH.exists():
        raise HTTPException(status_code=404, detail="Plugin manifest not found")
    return FileResponse(_PLUGIN_PATH, media_type="application/json")


# =====================================================================
# SEO: robots.txt and sitemap.xml
# =====================================================================

@app.get("/robots.txt", include_in_schema=False)
def robots_txt():
    """Serve robots.txt for search engine crawlers."""
    content = (
        "User-agent: *\n"
        "Allow: /\n"
        "Allow: /docs\n"
        "Allow: /openapi.json\n"
        "Allow: /landing\n"
        "Allow: /.well-known/ai-plugin.json\n"
        "\n"
        "Sitemap: https://api.volcanosafe.com/sitemap.xml\n"
    )
    return PlainTextResponse(content)


@app.get("/sitemap.xml", include_in_schema=False)
def sitemap_xml():
    """Serve sitemap.xml for search engines."""
    urls = [
        "https://api.volcanosafe.com/landing",
        "https://api.volcanosafe.com/docs",
        "https://api.volcanosafe.com/v1/volcanoes",
        "https://api.volcanosafe.com/.well-known/ai-plugin.json",
    ]
    xml_entries = "\n".join(
        f"  <url><loc>{u}</loc><changefreq>weekly</changefreq></url>"
        for u in urls
    )
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        f"{xml_entries}\n"
        "</urlset>"
    )
    return Response(content=xml, media_type="application/xml")


# =====================================================================
# Landing Page
# =====================================================================

_LANDING_PATH = Path(__file__).parent / "landing.html"


@app.get("/landing", include_in_schema=False)
def landing_page():
    """Serve the VolcanoSafe marketing landing page."""
    if not _LANDING_PATH.exists():
        raise HTTPException(status_code=404, detail="Landing page not found")
    return FileResponse(_LANDING_PATH, media_type="text/html")
