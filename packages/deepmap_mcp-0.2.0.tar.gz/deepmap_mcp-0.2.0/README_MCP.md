# DeepMap AI MCP Server

Real-time volcano monitoring, earthquake prediction, and geophysical intelligence as a [Model Context Protocol](https://modelcontextprotocol.io/) server.
Gives Claude (and any MCP-compatible LLM) direct access to live volcanic risk scores,
earthquake predictions, seismic risk assessments, tidal forcing analysis,
flight disruption forecasts, tidal eruption windows, LiDAR fault detection, and travel advisories.

## Install

```bash
pip install deepmap-mcp
```

## Configure for Claude Desktop

Add the following to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "deepmap": {
      "command": "python",
      "args": ["-m", "volcanosafe.mcp_server"],
      "env": {
        "DEEPMAP_API_URL": "https://api.volcanosafe.com",
        "DEEPMAP_API_KEY": "dm_live_..."
      }
    }
  }
}
```

Or run directly from the command line:

```bash
deepmap-mcp
```

## Available Tools

### Volcano Tools

| Tool | Description |
|------|-------------|
| `volcano_risk` | Full real-time risk assessment with seismic data, tidal state, travel advisory, and flight impact |
| `volcano_quick` | Low-latency risk score without live seismic fetch -- ideal for batch or insurance queries |
| `volcano_flights` | Flight disruption risk for airports near a volcano |
| `volcano_tidal_forecast` | Tidal eruption risk window forecast based on Mf tidal cycle analysis |
| `volcano_advisory` | Plain-text travel advisory with insurance recommendation and monitoring agency status |
| `volcano_list` | List all monitored volcanoes with names, countries, coordinates, and last eruption dates |
| `volcano_batch` | Quick risk scores for multiple volcanoes at once (max 10 per request) |

### Earthquake Tools

| Tool | Description |
|------|-------------|
| `predict_earthquake` | ML earthquake risk prediction for a region using GradientBoosting trained on real USGS data. Returns risk score, confidence, and contributing features |
| `list_earthquake_regions` | List all supported earthquake monitoring regions with bounds, historical rate, and magnitude of completeness |
| `assess_current_earthquakes` | Current global seismic risk assessment across all monitored regions using live USGS data |
| `earthquake_alert_cycle` | Full alert cycle across all monitored regions with triggered alerts and recommended actions |
| `predict_seismic_risk` | Seismic hazard risk score (0-10) for any lat/lon combining Vs30 site classification, liquefaction probability, and amplification factor |
| `analyze_tidal_forcing` | Tidal stress forcing analysis on earthquake triggering using Schuster's test and Rayleigh statistics |
| `detect_fault_scarps` | LiDAR/3DEP slope-break fault scarp detection with strike, dip direction, and length estimates |

### Supported Earthquake Regions

| Region Key | Name |
|------------|------|
| `ucerf3` | Southern California (UCERF3) |
| `new_madrid` | New Madrid Seismic Zone |
| `cascadia` | Cascadia Subduction Zone |
| `wasatch` | Wasatch Front (Utah) |
| `oklahoma` | Oklahoma (Induced) |
| `trans_mexico` | Trans-Mexican Volcanic Belt |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DEEPMAP_API_URL` | `https://api.volcanosafe.com` | API base URL |
| `DEEPMAP_API_KEY` | *(empty)* | API key for authenticated access |
| `VOLCANOSAFE_BASE_URL` | *(fallback)* | Legacy env var, still supported |
| `VOLCANOSAFE_API_KEY` | *(fallback)* | Legacy env var, still supported |

## Documentation

Full API documentation: [https://api.volcanosafe.com/docs](https://api.volcanosafe.com/docs)

## License

MIT
