from plugin_system.plugins.base_plugin import BasePlugin


class SimplePlugin(BasePlugin):
    """
    Simple example plugin that automatically inherits all default methods from the BasePlugin.
    """
