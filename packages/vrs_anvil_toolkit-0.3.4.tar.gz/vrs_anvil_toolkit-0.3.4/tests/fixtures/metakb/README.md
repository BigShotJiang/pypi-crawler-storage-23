# protected data
unzip metakb json files here.
