#!/bin/bash
pytest tests/unit
