echo "~~~ vasp/test.sh ~~~"
echo "cwd: $(pwd)"
echo "ls -hl:"
ls -hl
