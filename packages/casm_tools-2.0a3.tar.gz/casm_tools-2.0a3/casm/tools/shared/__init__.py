"""Miscellaneous helpers for casm-tools"""
