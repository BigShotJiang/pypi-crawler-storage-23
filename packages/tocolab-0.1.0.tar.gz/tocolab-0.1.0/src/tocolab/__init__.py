"""tocolab: Push code to Google Colab from the command line."""

__version__ = "0.1.0"
