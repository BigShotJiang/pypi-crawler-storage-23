"""
Tool selection module.

Provides tool selector strategies for choosing relevant tools based on queries.
"""

__version__ = "0.1.0.0"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"

from .base import BaseToolSelector, SelectorResources, ToolSelectorProtocol
from .dfsdt_selector import DFSDTSelector
from .embedding_selector import EmbeddingSelector
from .gorilla_selector import GorillaSelector, GorillaSelectorConfig
from .hybrid_selector import HybridSelector, HybridSelectorConfig
from .keyword_selector import KeywordSelector
from .registry import (
    SelectorRegistry,
    create_selector,
    register_selector,
)
from .schemas import (
    CONFIG_TYPES,
    AdaptiveSelectorConfig,
    DFSDTSelectorConfig,
    EmbeddingSelectorConfig,
    KeywordSelectorConfig,
    SelectorConfig,
    ToolPrediction,
    ToolSelectionQuery,
    TwoStageSelectorConfig,
    create_selector_config,
)

# Auto-register built-in selectors
register_selector("keyword", KeywordSelector)
register_selector("embedding", EmbeddingSelector)
register_selector("hybrid", HybridSelector)
register_selector("gorilla", GorillaSelector)
register_selector("dfsdt", DFSDTSelector)

__all__ = [
    # Base classes
    "BaseToolSelector",
    "SelectorResources",
    "ToolSelectorProtocol",
    # Selector implementations
    "KeywordSelector",
    "EmbeddingSelector",
    "HybridSelector",
    "HybridSelectorConfig",
    "GorillaSelector",
    "GorillaSelectorConfig",
    "DFSDTSelector",
    "DFSDTSelectorConfig",
    # Registry
    "SelectorRegistry",
    "register_selector",
    "create_selector",
    # Schemas
    "SelectorConfig",
    "KeywordSelectorConfig",
    "EmbeddingSelectorConfig",
    "TwoStageSelectorConfig",
    "AdaptiveSelectorConfig",
    "ToolSelectionQuery",
    "ToolPrediction",
    "CONFIG_TYPES",
    "create_selector_config",
]
