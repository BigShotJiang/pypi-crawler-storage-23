"""Benchmark on GCP compute instances."""
