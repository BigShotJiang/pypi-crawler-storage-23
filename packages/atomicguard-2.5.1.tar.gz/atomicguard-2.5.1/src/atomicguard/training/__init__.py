"""
Generic RL training infrastructure for AtomicGuard.

Provides the training loop, curriculum scheduling, and configuration
for training RL agents on workflow step execution. First-class part
of the core framework — not tied to any specific benchmark or codebase.
"""
