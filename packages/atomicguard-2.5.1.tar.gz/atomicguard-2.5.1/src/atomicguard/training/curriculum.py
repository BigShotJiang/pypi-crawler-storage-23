"""
Curriculum scheduling for workflow discovery training.

Controls which tasks the RL agent trains on and when to increase
difficulty. Easier tasks let the agent discover simple workflows first;
as it succeeds, harder tasks force it to discover more sophisticated
action pair sequences.

Defines task sampling and difficulty scheduling strategies.
Pure logic — no infrastructure or framework dependencies.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum


class DifficultyLevel(Enum):
    """Task difficulty tiers for curriculum scheduling."""

    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


@dataclass(frozen=True)
class CurriculumTask:
    """A single task in the curriculum with difficulty metadata."""

    task_id: str
    specification: str
    difficulty: DifficultyLevel
    estimated_steps: int  # Expected number of workflow steps


class CurriculumScheduler:
    """Schedules task difficulty progression during training.

    Starts with easier tasks and gradually increases difficulty
    as the agent's performance improves. No infrastructure deps.
    """

    def __init__(
        self,
        tasks: list[CurriculumTask],
        difficulty_threshold: float = 0.7,
    ) -> None:
        """
        Args:
            tasks: Pool of available training tasks.
            difficulty_threshold: Success rate required to advance difficulty.
        """
        self._tasks = tasks
        self._threshold = difficulty_threshold
        self._current_level = DifficultyLevel.EASY

    def sample_task(self) -> CurriculumTask:
        """Sample a task at the current difficulty level.

        Returns:
            A CurriculumTask at the current difficulty.

        Raises:
            ValueError: If no tasks available at current level.
        """
        eligible = [t for t in self._tasks if t.difficulty == self._current_level]
        if not eligible:
            raise ValueError(
                f"No tasks available at difficulty level {self._current_level.value}"
            )
        return random.choice(eligible)

    def update(self, success_rate: float) -> None:
        """Update curriculum based on recent performance.

        Args:
            success_rate: Rolling success rate (0.0-1.0).
        """
        if success_rate >= self._threshold:
            levels = list(DifficultyLevel)
            current_idx = levels.index(self._current_level)
            if current_idx < len(levels) - 1:
                self._current_level = levels[current_idx + 1]

    @property
    def current_difficulty(self) -> DifficultyLevel:
        """Current difficulty level."""
        return self._current_level
