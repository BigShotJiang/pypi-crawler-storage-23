"""
RL training environment for workflow discovery.

Presents the set of available action pairs as choices for the RL agent.
Each episode, the agent selects action pair indices, the environment
executes them (generator + guard), and the reward signal teaches which
action pair sequences (workflows) solve the task.

State: which APs are satisfied (frozenset) + which are available.
Action: int index into the AP pool — which AP to execute next.
Transition: success → AP moves to satisfied; failure → state unchanged.
Done: all APs satisfied (success) or step budget exhausted.

Backtracking: When ``enable_backtracking=True`` and the agent re-selects
a satisfied AP, cascade invalidation removes that AP and all transitive
dependents from ``satisfied``, failure context from the downstream AP is
injected, and the AP re-executes with fresh context. This mirrors the
rule-based workflow's Definition 47 (cascade invalidation) and
Definition 48 (failure context injection).

No gymnasium dependency — action pairs and guards are the environment.
"""

from __future__ import annotations

import logging
import random
import time
from collections import deque
from typing import TYPE_CHECKING

from atomicguard.domain.feedback_summarizer import FeedbackSummarizer
from atomicguard.domain.interfaces import (
    ActionPairPoolInterface,
    EnvironmentInterface,
)
from atomicguard.domain.models import Artifact
from atomicguard.domain.rl.reward import RewardFunctionInterface, RewardSignal
from atomicguard.domain.rl.state import State

if TYPE_CHECKING:
    from atomicguard.domain.interfaces import ArtifactDAGInterface

logger = logging.getLogger(__name__)

_MAX_FEEDBACK_ENTRIES = 3
_MAX_ARTIFACT_CHARS = 2000


class TrainingEnvironment(EnvironmentInterface):
    """Presents available action pairs as choices for workflow discovery.

    Each episode, the agent selects action pair indices to execute.
    Guards evaluate outcomes. Successful trajectories teach the policy
    which action pair sequences solve the task.

    State is (satisfied, available) frozensets. Action is an int index
    into the AP pool. On success the selected AP moves from available
    to satisfied; on failure the state is unchanged but a step is
    consumed from the budget.

    When ``enable_backtracking`` is True, re-selecting a satisfied AP
    triggers cascade invalidation (Def 47) and failure context injection
    (Def 48), allowing the agent to learn *when* backtracking is
    beneficial.

    Implements EnvironmentInterface so Trainer depends on the domain
    port, not on this concrete class.
    """

    def __init__(
        self,
        workflow: ActionPairPoolInterface,
        specification: str,
        reward_fn: RewardFunctionInterface,
        max_steps: int | None = None,
        artifact_dag: ArtifactDAGInterface | None = None,
        max_attempts_per_ap: int | None = None,
        enable_backtracking: bool = True,
        rmax_per_ap: int = 2,
        max_selections_per_ap: int | None = None,
    ) -> None:
        """
        Args:
            workflow: Injected action pair pool implementing ActionPairPoolInterface.
            specification: Task specification for the workflow.
            reward_fn: Reward function for computing rewards.
            max_steps: Maximum steps per episode. Defaults to 2 * num_action_pairs.
            artifact_dag: Optional artifact DAG for context construction.
            max_attempts_per_ap: Max failed attempts per AP before it is masked
                out. None means no per-AP limit (only global budget applies).
            enable_backtracking: When True, re-selecting a satisfied AP triggers
                cascade invalidation and failure context injection instead of
                wasting a step.
            rmax_per_ap: Max retries within DualStateAgent per RL step.
                Each AP execution gets up to ``rmax_per_ap + 1`` total attempts
                with guard feedback injected between retries. Default 2 (3
                total attempts).
            max_selections_per_ap: Max times the RL agent can select the same
                AP across different steps in one episode (regardless of
                pass/fail). None means no selection limit. When hit, the AP
                is treated as exhausted and backtrack targets are presented
                if backtracking is enabled.
        """
        self._workflow = workflow
        self._specification = specification
        self._reward_fn = reward_fn
        self._enable_backtracking = enable_backtracking
        self._rmax_per_ap = rmax_per_ap
        # Ensure a persistent DAG exists for the lifetime of the environment.
        # Creating a fresh InMemoryArtifactDAG() per step would lose artifacts
        # between steps, breaking downstream dependency resolution via
        # context.ambient.repository.get_artifact().
        if artifact_dag is not None:
            self._artifact_dag: ArtifactDAGInterface = artifact_dag
        else:
            from atomicguard.infrastructure.persistence.memory import (
                InMemoryArtifactDAG,
            )

            self._artifact_dag = InMemoryArtifactDAG()
        self._max_attempts_per_ap = max_attempts_per_ap
        self._max_selections_per_ap = max_selections_per_ap

        # Cache the action pair pool (immutable for the episode)
        self._action_pairs = self._workflow.get_available_action_pairs()
        self._ap_ids = tuple(ap.action_pair_id for ap in self._action_pairs)
        self._max_steps = max_steps or max(2 * len(self._action_pairs), 1)

        # Build requires map from ActionPairInfo for dependency masking
        self._requires_map: dict[str, tuple[str, ...]] = {
            ap.action_pair_id: ap.requires for ap in self._action_pairs
        }

        # OR-group dependency map: AP ID → tuple of OR-groups
        self._requires_any_map: dict[str, tuple[tuple[str, ...], ...]] = {
            ap.action_pair_id: ap.requires_any for ap in self._action_pairs
        }

        # Variant group maps
        self._groups: dict[str, set[str]] = {}  # group_name → AP IDs
        self._ap_group: dict[str, str] = {}  # AP ID → group_name
        for ap in self._action_pairs:
            if ap.group:
                self._groups.setdefault(ap.group, set()).add(ap.action_pair_id)
                self._ap_group[ap.action_pair_id] = ap.group

        # Required count for completion: non-grouped APs + one per group
        self._required_count: int = sum(
            1 for ap_id in self._ap_ids if ap_id not in self._ap_group
        ) + len(self._groups)

        # Build reverse dependency map for cascade invalidation
        self._dependents_map: dict[str, set[str]] = {
            ap_id: set() for ap_id in self._ap_ids
        }
        for ap in self._action_pairs:
            for dep in ap.requires:
                if dep in self._dependents_map:
                    self._dependents_map[dep].add(ap.action_pair_id)
            # Include requires_any reverse deps for cascade invalidation
            for or_group in ap.requires_any:
                for dep_id in or_group:
                    if dep_id in self._dependents_map:
                        self._dependents_map[dep_id].add(ap.action_pair_id)

        # Escalation routing from ActionPairInfo metadata
        self._escalate_feedback_to: dict[str, tuple[str, ...]] = {
            ap.action_pair_id: ap.escalate_feedback_to for ap in self._action_pairs
        }

        # Per-AP r_patience for cross-step stagnation detection
        self._r_patience: dict[str, int | None] = {
            ap.action_pair_id: ap.r_patience for ap in self._action_pairs
        }
        self._feedback_summarizer = FeedbackSummarizer()

        # Strategy selector tracking
        self._strategy_ap_id: str | None = None
        self._strategy_recommendation: int = 0

        # Episode tracking
        self._episode_number: int = 0
        self._current_workflow_id: str = "training"

        # Episode state (initialized in reset)
        self._satisfied: frozenset[str] = frozenset()
        self._steps_taken: int = 0
        self._done: bool = False
        self._artifacts: dict[str, Artifact] = {}  # AP ID → produced artifact
        self._attempt_counts: dict[str, int] = {}  # AP ID → failed attempt count
        self._selection_counts: dict[str, int] = {}  # AP ID → total RL selections
        self._guard_feedback: dict[
            str, list[str]
        ] = {}  # AP ID → guard feedback history
        self._failed_artifacts: dict[
            str, str
        ] = {}  # AP ID → last failed artifact content
        self._escalation_feedback: dict[
            str, list[str]
        ] = {}  # AP ID → injected failure context
        self._exhausted_aps: set[str] = set()  # APs that hit attempt or selection cap
        self._episode_tokens: int = 0  # Total LLM tokens consumed this episode
        self._backtrack_count: int = 0  # Cascade invalidations this episode
        self._last_step_duration_ms: float = 0.0  # Duration of last AP execution
        self._episode_execution_ms: float = 0.0  # Cumulative AP execution time

    @property
    def action_pair_ids(self) -> tuple[str, ...]:
        """Public accessor for the cached action pair IDs."""
        return self._ap_ids

    def reset(self) -> State:
        """Reset to the start of a fresh episode.

        Returns:
            Initial state with all action pairs available, none satisfied.
        """
        self._episode_number += 1
        self._current_workflow_id = f"training_ep{self._episode_number:04d}"

        self._satisfied = frozenset()
        self._steps_taken = 0
        self._done = False
        self._artifacts = {}
        self._attempt_counts = {}
        self._selection_counts = {}
        self._guard_feedback = {}
        self._failed_artifacts = {}
        self._escalation_feedback = {}
        self._exhausted_aps = set()
        self._episode_tokens = 0
        self._backtrack_count = 0
        self._last_step_duration_ms = 0.0
        self._episode_execution_ms = 0.0
        self._strategy_recommendation = 0

        return self._build_state()

    def execute_step(self, action: int) -> tuple[State, RewardSignal, bool]:
        """Execute one agent decision and return the outcome.

        The agent selects an action pair index. The environment executes
        it (generator + guard). If the guard passes, the AP moves to
        satisfied. If it fails, state is unchanged but a step is consumed.

        When backtracking is enabled and the agent re-selects a satisfied AP,
        cascade invalidation removes that AP and its transitive dependents
        from satisfied, failure context is injected, and the AP re-executes.

        Args:
            action: Index into the action pair pool — which AP to execute.

        Returns:
            Tuple of (next_state, reward_signal, done).
        """
        current_available = self._build_state().available

        if self._done:
            state = self._build_state()
            return (
                state,
                self._reward_fn.compute(
                    guard_passed=False,
                    tokens_used=0,
                    retries_used=0,
                    terminal=True,
                    action=action,
                    satisfied=self._satisfied,
                    available=current_available,
                ),
                True,
            )

        # Validate action index
        if action < 0 or action >= len(self._action_pairs):
            # Invalid action — penalize and consume a step
            self._steps_taken += 1
            self._done = self._steps_taken >= self._max_steps
            state = self._build_state()
            return (
                state,
                self._reward_fn.compute(
                    guard_passed=False,
                    tokens_used=0,
                    retries_used=0,
                    terminal=self._done,
                    action=action,
                    satisfied=self._satisfied,
                    available=state.available,
                ),
                self._done,
            )

        selected_ap = self._action_pairs[action]
        ap_id = selected_ap.action_pair_id

        # Handle backtracking: agent selected a satisfied AP that's in available
        # as a backtrack target (added by _build_state when an AP is exhausted)
        if ap_id in self._satisfied and ap_id in current_available:
            if self._enable_backtracking:
                self._perform_backtrack(ap_id)
                # Fall through to execute the AP with fresh context
            else:
                # Shouldn't happen (backtrack targets not added when disabled),
                # but handle gracefully
                logger.debug(
                    "[%s] Blocked (already satisfied), available=%s",
                    ap_id,
                    current_available,
                )
                self._steps_taken += 1
                self._done = self._steps_taken >= self._max_steps
                state = self._build_state()
                return (
                    state,
                    self._reward_fn.compute(
                        guard_passed=False,
                        tokens_used=0,
                        retries_used=0,
                        terminal=self._done,
                        action=action,
                        satisfied=self._satisfied,
                        available=state.available,
                    ),
                    self._done,
                )
        elif ap_id not in current_available:
            # AP not available: either already satisfied (no backtrack) or deps not met
            reason = "already satisfied" if ap_id in self._satisfied else "deps not met"
            logger.debug(
                "[%s] Blocked (%s), available=%s", ap_id, reason, current_available
            )
            self._steps_taken += 1
            self._done = self._steps_taken >= self._max_steps
            state = self._build_state()
            return (
                state,
                self._reward_fn.compute(
                    guard_passed=False,
                    tokens_used=0,
                    retries_used=0,
                    terminal=self._done,
                    action=action,
                    satisfied=self._satisfied,
                    available=state.available,
                ),
                self._done,
            )

        # Track RL-level selection count (before execution)
        self._selection_counts[ap_id] = self._selection_counts.get(ap_id, 0) + 1

        # Execute the action pair via DualStateAgent (retry + feedback loop)
        guard_passed = False
        artifact = None
        try:
            from atomicguard.application.agent import DualStateAgent
            from atomicguard.domain.exceptions import (
                EscalationRequired,
                RmaxExhausted,
                StagnationDetected,
            )

            dag = self._artifact_dag

            logger.info(
                "[%s] Executing (step %d/%d, satisfied=%d/%d)",
                ap_id,
                self._steps_taken + 1,
                self._max_steps,
                len(self._satisfied),
                self._required_count,
            )

            # Build dependencies dict for guard validation (keyed by AP ID)
            dep_dict = {
                dep_id: self._artifacts[dep_id]
                for dep_id in selected_ap.requires
                if dep_id in self._artifacts
            }
            # Include satisfied OR-group member artifacts
            for or_group in self._requires_any_map.get(ap_id, ()):
                for member_id in or_group:
                    if member_id in self._artifacts and member_id not in dep_dict:
                        dep_dict[member_id] = self._artifacts[member_id]
            if selected_ap.requires:
                logger.debug(
                    "[%s] requires=%s → dep_artifacts=%s",
                    ap_id,
                    selected_ap.requires,
                    list(dep_dict.keys()),
                )
            esc_entries = self._escalation_feedback.get(ap_id, [])
            if esc_entries:
                logger.info(
                    "[%s] Executing with escalation feedback (%d entries)",
                    ap_id,
                    len(esc_entries),
                )

            agent = DualStateAgent(
                action_pair=selected_ap.action_pair,
                artifact_dag=dag,
                rmax=self._rmax_per_ap,
                constraints="",
                action_pair_id=ap_id,
                workflow_id=self._current_workflow_id,
            )
            _t0 = time.perf_counter()
            try:
                artifact = agent.execute(
                    specification=self._specification,
                    dependencies=dep_dict,
                    escalation_feedback=tuple(esc_entries),
                )
                guard_passed = True
            except RmaxExhausted as e:
                artifact = e.provenance[-1][0] if e.provenance else None
                guard_passed = False
                if artifact is not None and hasattr(artifact, "content"):
                    self._failed_artifacts[ap_id] = artifact.content
                if e.provenance:
                    feedback = e.provenance[-1][1]
                    logger.info(
                        "[%s] Guard FAILED (rmax exhausted): %r", ap_id, feedback
                    )
                    if ap_id not in self._guard_feedback:
                        self._guard_feedback[ap_id] = []
                    self._guard_feedback[ap_id].append(feedback)
            except StagnationDetected as e:
                artifact = e.artifact
                guard_passed = False
                if artifact is not None and hasattr(artifact, "content"):
                    self._failed_artifacts[ap_id] = artifact.content
                logger.info("[%s] Guard FAILED (stagnation): %r", ap_id, e.feedback)
                if ap_id not in self._guard_feedback:
                    self._guard_feedback[ap_id] = []
                self._guard_feedback[ap_id].append(e.feedback)
            except EscalationRequired as e:
                artifact = e.artifact
                guard_passed = False
                if artifact is not None and hasattr(artifact, "content"):
                    self._failed_artifacts[ap_id] = artifact.content
                logger.info("[%s] Guard FAILED (fatal): %r", ap_id, e.feedback)
                # Fatal → mark AP as exhausted immediately
                self._exhausted_aps.add(ap_id)
                if ap_id not in self._guard_feedback:
                    self._guard_feedback[ap_id] = []
                self._guard_feedback[ap_id].append(e.feedback)

            self._last_step_duration_ms = (time.perf_counter() - _t0) * 1000
            self._episode_execution_ms += self._last_step_duration_ms

            # Accumulate token usage from all artifacts produced by this AP
            # (DualStateAgent may have stored multiple attempts in the DAG)
            all_artifacts = dag.get_all_for_action_pair(
                ap_id, self._current_workflow_id
            )
            for a in all_artifacts:
                meta = getattr(a, "metadata", None) or {}
                tokens = meta.get("total_tokens", 0)
                if tokens:
                    self._episode_tokens += tokens
        except Exception:
            logger.exception("[%s] Exception during execution", ap_id)
            guard_passed = False

        # Update state based on outcome
        self._steps_taken += 1

        if guard_passed:
            self._satisfied = self._satisfied | {ap_id}
            if artifact is not None:
                self._artifacts[ap_id] = artifact
                logger.debug(
                    "[%s] Guard passed — artifact stored (id=%s), satisfied=%s",
                    ap_id,
                    artifact.artifact_id,
                    self._satisfied,
                )
            # Extract strategy recommendation from strategy AP artifact
            if ap_id == self._strategy_ap_id and artifact is not None:
                self._strategy_recommendation = self._extract_strategy(artifact)
        else:
            self._attempt_counts[ap_id] = self._attempt_counts.get(ap_id, 0) + 1

            # Cross-step stagnation detection (r_patience)
            # DSA's internal r_patience can't fire across RL steps (rmax_per_ap
            # is typically 2, r_patience is 3-4), so we check at the env level.
            r_pat = self._r_patience.get(ap_id)
            if (
                isinstance(r_pat, int)
                and ap_id not in self._exhausted_aps
                and len(self._guard_feedback.get(ap_id, [])) >= r_pat
            ):
                fb_list = self._guard_feedback[ap_id]
                if self._feedback_summarizer.check_stagnation(fb_list, r_pat):
                    self._exhausted_aps.add(ap_id)
                    logger.info(
                        "[%s] Stagnation detected (%d similar feedbacks), marking exhausted",
                        ap_id,
                        r_pat,
                    )
                    if self._enable_backtracking and ap_id in self._guard_feedback:
                        self._inject_exhaustion_feedback(ap_id)

            if (
                self._max_attempts_per_ap is not None
                and ap_id not in self._exhausted_aps
                and self._attempt_counts[ap_id] >= self._max_attempts_per_ap
            ):
                self._exhausted_aps.add(ap_id)
                logger.debug(
                    "[%s] Exhausted (%d/%d attempts), masking out",
                    ap_id,
                    self._attempt_counts[ap_id],
                    self._max_attempts_per_ap,
                )
                # Inject failure context into escalation targets on exhaustion,
                # mirroring StagnationDetected in the rule-based workflow.
                # This decouples feedback injection from cascade invalidation —
                # the feedback is pre-staged so it's ready when the policy
                # eventually backtracks to the right upstream AP.
                if self._enable_backtracking and ap_id in self._guard_feedback:
                    self._inject_exhaustion_feedback(ap_id)

        # Check selection cap (applies regardless of pass/fail)
        if (
            self._max_selections_per_ap is not None
            and ap_id not in self._exhausted_aps
            and self._selection_counts.get(ap_id, 0) >= self._max_selections_per_ap
        ):
            self._exhausted_aps.add(ap_id)
            logger.info(
                "[%s] Selection cap reached (%d/%d selections), masking out",
                ap_id,
                self._selection_counts[ap_id],
                self._max_selections_per_ap,
            )
            if self._enable_backtracking and ap_id in self._guard_feedback:
                self._inject_exhaustion_feedback(ap_id)

        # Check termination: all required APs satisfied or budget exhausted
        # Also terminate if no APs are available (all satisfied or exhausted)
        state = self._build_state()
        all_satisfied = self._is_complete()
        budget_exhausted = self._steps_taken >= self._max_steps
        no_actions_left = len(state.available) == 0
        self._done = all_satisfied or budget_exhausted or no_actions_left

        if self._done:
            logger.info(
                "Episode done: all_satisfied=%s, budget_exhausted=%s, "
                "steps=%d/%d, satisfied=%d/%d (required=%d)",
                all_satisfied,
                budget_exhausted,
                self._steps_taken,
                self._max_steps,
                len(self._satisfied),
                self._required_count,
                self._required_count,
            )

        reward = self._reward_fn.compute(
            guard_passed=guard_passed,
            tokens_used=0,
            retries_used=self._steps_taken,
            terminal=self._done,
            action=action,
            satisfied=self._satisfied,
            available=state.available,
        )

        return state, reward, self._done

    def _perform_backtrack(self, ap_id: str) -> None:
        """Cascade invalidation and failure context injection for backtracking.

        When the agent re-selects a satisfied AP, this:
        1. Removes the AP and all transitive dependents from satisfied (Def 47)
        2. Updates the artifact mapping so new artifacts replace old for deps
        3. Resets attempt counters for invalidated APs
        4. Injects failure context from failed downstream APs (Def 48)

        Artifacts remain in the DAG as immutable history — only the _artifacts
        dict (used for dep resolution) is updated when new artifacts are produced.

        Args:
            ap_id: The action pair ID to backtrack to.
        """
        self._backtrack_count += 1
        to_invalidate = self._get_transitive_dependents(ap_id)
        to_invalidate.add(ap_id)

        # Find the downstream AP that most recently failed (if any) for context injection
        failed_downstream = None
        for inv_id in to_invalidate:
            if inv_id != ap_id and inv_id in self._guard_feedback:
                failed_downstream = inv_id

        logger.info(
            "[%s] Cascade invalidation: removing %s from satisfied",
            ap_id,
            to_invalidate,
        )

        for inv_id in to_invalidate:
            self._satisfied = self._satisfied - {inv_id}
            self._artifacts.pop(inv_id, None)
            self._attempt_counts.pop(inv_id, None)
            self._selection_counts.pop(inv_id, None)
            self._failed_artifacts.pop(inv_id, None)
            self._exhausted_aps.discard(inv_id)
            # Reset strategy bits if strategy AP is invalidated
            if inv_id == self._strategy_ap_id:
                self._strategy_recommendation = 0

        # Inject failure context from failed downstream into escalation targets
        if failed_downstream:
            feedback_entries = self._guard_feedback[failed_downstream]
            summary = self._build_failure_summary(
                failed_downstream,
                feedback_entries,
                self._failed_artifacts.get(failed_downstream, ""),
            )

            # Route to configured escalation targets, or default to the AP itself
            targets = self._escalate_feedback_to.get(failed_downstream, ())
            if not targets:
                targets = (ap_id,)

            for target_id in targets:
                if target_id not in self._escalation_feedback:
                    self._escalation_feedback[target_id] = []
                self._escalation_feedback[target_id].append(summary)
                logger.debug(
                    "[%s] Failure context injected from %s",
                    target_id,
                    failed_downstream,
                )

    def _inject_exhaustion_feedback(self, ap_id: str) -> None:
        """Pre-stage failure context when an AP exhausts max_attempts_per_ap.

        Mirrors StagnationDetected in the rule-based workflow: when an AP
        is stuck, inject its guard feedback into the configured
        escalate_feedback_to targets so that when the policy eventually
        backtracks to those targets, the context is already available.

        This decouples feedback injection from cascade invalidation —
        feedback flows immediately on exhaustion, cascade invalidation
        waits for the policy to re-select the right upstream AP.

        Args:
            ap_id: The exhausted AP whose feedback should be routed.
        """
        feedback_entries = self._guard_feedback[ap_id]
        summary = self._build_failure_summary(
            ap_id,
            feedback_entries,
            self._failed_artifacts.get(ap_id, ""),
        )

        # Route to configured targets, or to all direct dependencies as fallback
        targets = self._escalate_feedback_to.get(ap_id, ())
        if not targets:
            targets = self._requires_map.get(ap_id, ())

        if not targets:
            return

        for target_id in targets:
            if target_id not in self._escalation_feedback:
                self._escalation_feedback[target_id] = []
            self._escalation_feedback[target_id].append(summary)
            logger.info(
                "[%s] Exhaustion feedback injected into %s",
                ap_id,
                target_id,
            )

    def _get_transitive_dependents(self, target_id: str) -> set[str]:
        """Find all APs that transitively depend on target_id (Def 47).

        Uses BFS over the reverse dependency map.

        Args:
            target_id: The AP ID to find dependents for.

        Returns:
            Set of AP IDs that depend on target (directly or transitively).
        """
        dependents: set[str] = set()
        queue: deque[str] = deque([target_id])

        while queue:
            current = queue.popleft()
            for dep_id in self._dependents_map.get(current, set()):
                if dep_id not in dependents:
                    dependents.add(dep_id)
                    queue.append(dep_id)

        return dependents

    @staticmethod
    def _build_failure_summary(
        ap_id: str,
        feedback_entries: list[str],
        artifact_content: str = "",
    ) -> str:
        """Build a concise failure summary from recent guard feedback.

        Args:
            ap_id: The AP that failed.
            feedback_entries: Guard feedback strings from failed attempts.
            artifact_content: Optional last failed artifact content to include.

        Returns:
            Formatted failure summary string.
        """
        recent = feedback_entries[-_MAX_FEEDBACK_ENTRIES:]
        entries = "\n".join(f"  - {fb}" for fb in recent)
        summary = f"Downstream AP '{ap_id}' failed. Recent feedback:\n{entries}"
        if artifact_content:
            truncated = artifact_content[:_MAX_ARTIFACT_CHARS]
            if len(artifact_content) > _MAX_ARTIFACT_CHARS:
                truncated += f"\n... (truncated, {len(artifact_content)} chars total)"
            summary += f"\n\nLast failed artifact from '{ap_id}':\n{truncated}"
        return summary

    def _get_backtrack_targets(self, exhausted_ap_id: str) -> frozenset[str]:
        """Compute backtracking targets for an exhausted AP.

        Returns the configured ``escalate_feedback_to`` targets if present,
        otherwise falls back to direct upstream dependencies (AND + OR-group
        members). Only includes targets that are currently satisfied.

        Args:
            exhausted_ap_id: The AP that exhausted its retries.

        Returns:
            Frozenset of AP IDs the agent can backtrack to.
        """
        candidates = self._escalate_feedback_to.get(exhausted_ap_id, ())
        if not candidates:
            # Fallback: AND deps + OR-group members
            and_deps = self._requires_map.get(exhausted_ap_id, ())
            or_deps: list[str] = []
            for or_group in self._requires_any_map.get(exhausted_ap_id, ()):
                or_deps.extend(or_group)
            candidates = and_deps + tuple(or_deps)

        return frozenset(ap_id for ap_id in candidates if ap_id in self._satisfied)

    def get_episode_stats(self) -> dict[str, int | float | str]:
        """Return episode-level token, backtrack, and timing stats."""
        return {
            "tokens": self._episode_tokens,
            "backtracks": self._backtrack_count,
            "total_aps": len(self._ap_ids),
            "required_aps": self._required_count,
            "last_step_duration_ms": self._last_step_duration_ms,
            "episode_execution_ms": self._episode_execution_ms,
            "workflow_id": self._current_workflow_id,
        }

    def get_state(self) -> dict:
        """Return serialisable state for checkpoint persistence."""
        return {"episode_number": self._episode_number}

    def set_state(self, state: dict) -> None:
        """Restore state from a checkpoint."""
        self._episode_number = state.get("episode_number", self._episode_number)

    def configure_strategy_ap(self, ap_id: str) -> None:
        """Designate an AP as the strategy selector.

        When this AP's guard passes, the environment extracts the strategy
        recommendation from the artifact content and encodes it as 2 bits
        in the state. If the AP is cascade-invalidated, the bits reset.

        Args:
            ap_id: The action pair ID of the strategy selector.
        """
        self._strategy_ap_id = ap_id

    def _is_complete(self) -> bool:
        """Group-aware completion check.

        All non-grouped APs must be satisfied, plus at least one member
        of each variant group.
        """
        for ap_id in self._ap_ids:
            if ap_id in self._ap_group:
                continue
            if ap_id not in self._satisfied:
                return False
        for _group_name, members in self._groups.items():
            if not any(m in self._satisfied for m in members):
                return False
        return True

    @staticmethod
    def _extract_strategy(artifact: Artifact) -> int:
        """Extract strategy recommendation from artifact content JSON.

        Returns:
            0=UNKNOWN, 1=MINIMAL, 2=COMPREHENSIVE, 3=DIRECT.
        """
        import json as _json

        _STRATEGY_MAP = {"MINIMAL": 1, "COMPREHENSIVE": 2, "DIRECT": 3}
        try:
            data = _json.loads(artifact.content)
            rec = data.get("recommendation", "")
            value = _STRATEGY_MAP.get(rec.upper(), 0)
            if value:
                logger.info("Strategy recommendation extracted: %s (%d)", rec, value)
            return value
        except (ValueError, AttributeError):
            logger.warning("Failed to extract strategy from artifact content")
            return 0

    def _build_state(self) -> State:
        """Build a State from current episode state with dependency-aware masking.

        Availability rules:
        1. Not already satisfied
        2. All AND deps (requires) satisfied
        3. All OR-groups (requires_any) have at least one satisfied member
        4. Group exclusion: skip if group already has a satisfied member
        5. Not exhausted (attempt cap, selection cap)

        When backtracking is enabled and any AP is exhausted, its backtrack
        targets (upstream satisfied APs) are added to ``available`` so the
        agent can choose to backtrack. The ``backtrack_active`` flag is set
        to let the policy distinguish normal from backtracking states.
        """
        # Precompute satisfied groups
        satisfied_groups: set[str] = set()
        for ap_id in self._satisfied:
            grp = self._ap_group.get(ap_id)
            if grp:
                satisfied_groups.add(grp)

        available = frozenset(
            ap_id
            for ap_id in self._ap_ids
            if ap_id not in self._satisfied
            # AND deps
            and all(dep in self._satisfied for dep in self._requires_map.get(ap_id, ()))
            # OR-group deps
            and all(
                any(dep in self._satisfied for dep in or_group)
                for or_group in self._requires_any_map.get(ap_id, ())
            )
            # Group exclusion: skip if group already satisfied
            and not (
                ap_id in self._ap_group and self._ap_group[ap_id] in satisfied_groups
            )
            # Attempt/selection caps
            and (
                self._max_attempts_per_ap is None
                or self._attempt_counts.get(ap_id, 0) < self._max_attempts_per_ap
            )
            and (
                self._max_selections_per_ap is None
                or self._selection_counts.get(ap_id, 0) < self._max_selections_per_ap
            )
        )

        # Add backtrack targets from exhausted APs
        backtrack_targets: frozenset[str] = frozenset()
        if self._enable_backtracking and self._exhausted_aps:
            all_targets: set[str] = set()
            for exhausted_id in self._exhausted_aps:
                targets = self._get_backtrack_targets(exhausted_id)
                all_targets.update(targets)
            if all_targets:
                backtrack_targets = frozenset(all_targets)
                available = available | backtrack_targets
                logger.debug(
                    "Backtrack targets presented: %s (from exhausted: %s)",
                    backtrack_targets,
                    self._exhausted_aps,
                )

        return State(
            satisfied=self._satisfied,
            available=available,
            backtrack_active=bool(backtrack_targets),
            strategy_recommendation=self._strategy_recommendation,
        )


class MultiInstanceEnvironment(EnvironmentInterface):
    """Rotates across multiple TrainingEnvironments on each reset().

    Each episode trains on a different instance, teaching the policy
    to generalise across SWE-Bench problems.  Supports sequential
    (round-robin) and random instance rotation.

    Implements EnvironmentInterface so Trainer depends on the domain
    port, not on this concrete class.
    """

    def __init__(
        self,
        environments: list[TrainingEnvironment],
        rotation: str = "sequential",
    ) -> None:
        """
        Args:
            environments: One TrainingEnvironment per SWE-Bench instance.
            rotation: ``"sequential"`` (round-robin) or ``"random"``.

        Raises:
            ValueError: If *environments* is empty or *rotation* is invalid.
        """
        if not environments:
            raise ValueError(
                "MultiInstanceEnvironment requires at least one environment"
            )
        if rotation not in ("sequential", "random"):
            raise ValueError(
                f"rotation must be 'sequential' or 'random', got {rotation!r}"
            )

        self._environments = environments
        self._rotation = rotation
        self._current_idx = 0
        self._current: TrainingEnvironment = environments[0]
        self._current_resolved_idx: int = 0

    def reset(self) -> State:
        """Select the next instance and reset its environment.

        Returns:
            Initial state from the newly selected environment.
        """
        if self._rotation == "sequential":
            self._current_resolved_idx = self._current_idx
            self._current = self._environments[self._current_idx]
            self._current_idx = (self._current_idx + 1) % len(self._environments)
        else:
            self._current_resolved_idx = random.randrange(len(self._environments))
            self._current = self._environments[self._current_resolved_idx]

        return self._current.reset()

    def execute_step(self, action: int) -> tuple[State, RewardSignal, bool]:
        """Delegate to the current episode's environment.

        Args:
            action: Index into the action pair pool.

        Returns:
            Tuple of (next_state, reward_signal, done).
        """
        return self._current.execute_step(action)

    def get_episode_stats(self) -> dict[str, int | float | str]:
        """Delegate to the current episode's environment."""
        stats = self._current.get_episode_stats()
        stats["instance_index"] = self._current_resolved_idx
        return stats

    def get_state(self) -> dict:
        """Return serialisable state for checkpoint persistence."""
        sub_states = [env.get_state() for env in self._environments]
        return {
            "current_idx": self._current_idx,
            "sub_environments": sub_states,
        }

    def set_state(self, state: dict) -> None:
        """Restore state from a checkpoint."""
        self._current_idx = state.get("current_idx", self._current_idx)
        for env, sub_state in zip(
            self._environments, state.get("sub_environments", []), strict=False
        ):
            env.set_state(sub_state)
