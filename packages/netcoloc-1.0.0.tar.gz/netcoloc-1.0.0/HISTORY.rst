=======
History
=======


1.0.0 (2025-07-09)
------------------

* `obonet <https://pypi.org/project/obonet/>`__ added as a dependency, replacing `DDOT <https://github.com/idekerlab/ddot>`__ dependency

* `cdapsutil <https://pypi.org/project/cdapsutil/>`__ added as a dependency

* `network_colocalization` updated for compatability with `pandas>=2.0 <https://pypi.org/project/pandas/>`__

* `validation` updated for compatability with `obonet <https://pypi.org/project/obonet/>`__. Added ``validation.focus_ontology()`` to replace ``ddot.Ontology.focus()`` functionality, and ``validation.find_related_terms()`` and ``validation.get_MP_description()`` for analyzing Mammalian Phenotype Ontology terms.

* `example_notebooks` updated for compatibility with `pandas>=2.0 <https://pypi.org/project/pandas/>`__ and `obonet <https://pypi.org/project/obonet/>`__

* ``validation.load_MGI_mouseKO_data()`` and ``validation.load_MPO()`` updated to allow re-use of previously downloaded files

* Added ability to map genes via the MGI database in ``validation.load_MGI_mouse_KO_data()``

* Added functions to map genes to the ontology and restrict to a subset of genes (``validation.map_genes_to_MPO()``)

* Stabilized *network_colocalization* to accept pd.Series, pd.DataFrame and np.ndarray inputs

* Added support for overlapping sets of seed genes in ``network_colocalization.calculate_expected_overlap()``, with option to remove the overlapping genes from the analysis, or randomize within the overlapping seed genes. 

* Added function ``network_colocalization.get_p_from_permutation_results()`` to calculate P-value from Z-test of observed vs permuted results. 

* Added function ``network_colocalization.calculate_mean_z_score_distribution()`` to analyze mean netcoloc z-scores in addition to the size of the colocalized network. 

* `requirements_dev.txt` updated for `python=3.13`

* Expanded unit tests for `netcoloc_utils`, `netprop`, `netprop_zscore`, `network_colocalization` and `validation` modules


0.1.7 (2022-06-28)
--------------------

* Removed unused `network_localization.py` module


0.1.6 (2022-06-16)
--------------------

* `ipycytoscape <https://ipycytoscape.readthedocs.io/en/latest>`__ added as a dependency

* `ipywidgets <https://ipywidgets.readthedocs.io/en/latest>`__ added as a dependency

* Added `network_colocalization.sweep_input_pvals()` to sweep p-values and scores

* Added `network_colocalization.calculate_network_enrichment()` to sweep over z-score thresholds

* `netprop.get_individual_heats_matrix()` can take a networkx `Graph` object and internally call
  `netprop.get_normalized_adjancency_matrix()`. Documentation updated in both methods to note
  that the resulting matrices can be saved via `numpy.save()` and retrieved via `numpy.load()`

* `example_notebooks/ASD_CHD_NetColoc_analysis.ipynb` now visualizes hierarchy using
  `ipycytoscape <https://ipycytoscape.readthedocs.io/en/latest>`__

* `example_notebooks/ASD_CHD_NetColoc_analysis.ipynb` updated with a note about using `numpy.save()`
  and `numpy.load()` to save and retrieve result from `netprop.get_individual_heats_matrix()`





0.1.5 (2022-03-09)
--------------------

* Fixed divide by zero error seen when calculating cosine distance by updating `netprop.get_normalized_adjancency_matrix()`
  to properly normalize an adjacency matrix that is asymetric (UD-1863)
  

0.1.4 (2021-08-31)
--------------------

* If import of DDOT package fails, only a warning message will be
  displayed unless user invokes ``netcoloc.validation.load_MPO()``
  in which case an ``ImportError`` is raised

* Fixed bug where ``z1_threshold`` parameter was being passed to ``z2_threshold`` parameter in
  ``netcoloc.network_cololcalization.calcualte_network_overlap`` method called by ``netcoloc.network_colocalization.calculate_network_overlap_subgraph`` method
  

0.1.3 (2021-08-18)
--------------------

* Added dependency `gprofiler-official <https://pypi.org/project/gprofiler-official>`__
  to ``setup.py`` and ``requirements.txt`` because this is used by
  ``network_colocalization.py``

0.1.2 (2021-08-17)
--------------------

* Added new `validation.py` module containing mouse knockout database
  functionality

0.1.1 (2021-08-06)
-------------------

* Fixed netcoloc imports in `netprop_zcore.py`


0.1.0 (2021-03-10)
------------------

* First release on PyPI.
