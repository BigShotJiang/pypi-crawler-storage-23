# Laakhay Core

`laakhay-core` provides the shared type definitions and data models for the Laakhay ecosystem. It is designed to be a lightweight, high-performance, and zero-dependency library that prevents type drift between services.

## Core Principles

- **Zero Runtime Dependencies**: No Pydantic or external libraries required for core execution.
- **High Performance**: Uses Python `dataclasses` with `slots=True` for memory efficiency and speed.
- **Interoperability**: Standardized `Bar`, `Order`, and `Signal` models across `data`, `ta`, and `quantlab`.
- **Stable Contracts**: Versioned model serialization and explicit normalization helpers.

## Usage

```python
from laakhay.core import (
    Bar,
    DatasetKey,
    DataSource,
    Order,
    OrderSide,
    OrderType,
    Signal,
    Timeframe,
    to_decimal,
    to_timestamp,
)

bar = Bar(
    ts=to_timestamp("2026-02-20T00:00:00Z"),
    open=to_decimal("50000"),
    high=to_decimal("51000"),
    low=to_decimal("49000"),
    close=to_decimal("50500"),
    volume=to_decimal("10.5"),
)

order = Order(
    id="ord-1",
    symbol="BTCUSDT",
    side=OrderSide.BUY,
    type=OrderType.LIMIT,
    qty="0.1",
    price="50000",
)

signal = Signal(symbol="BTCUSDT", side="SELL", type="LIMIT", price="51000", sl="2%")
key = DatasetKey(symbol="BTCUSDT", timeframe=Timeframe("1h"), source=DataSource.OHLCV)
```

## Public API

- `laakhay.core` exports all canonical contracts directly.
- Preferred import style:

```python
from laakhay.core import Bar, Order, Signal, DatasetKey, Timeframe
```
