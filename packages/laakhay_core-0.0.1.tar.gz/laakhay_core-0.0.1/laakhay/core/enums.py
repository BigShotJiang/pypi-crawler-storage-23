"""Shared canonical enums used across Laakhay libraries."""

from enum import StrEnum


class DataSource(StrEnum):
    OHLCV = "ohlcv"
    TRADES = "trades"
    ORDERBOOK = "orderbook"
    LIQUIDATION = "liquidation"


class MarketType(StrEnum):
    SPOT = "spot"
    FUTURES = "futures"
    PERPETUAL = "perpetual"
    OPTIONS = "options"
