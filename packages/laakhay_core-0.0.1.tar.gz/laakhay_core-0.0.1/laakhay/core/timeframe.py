"""Timeframe utilities and constants."""

from __future__ import annotations

import re
from enum import StrEnum


class TimeframeUnit(StrEnum):
    MINUTE = "m"
    HOUR = "h"
    DAY = "d"
    WEEK = "w"
    MONTH = "M"


class Timeframe:
    """Trading timeframe representation (e.g., '1m', '5m', '1h', '1d')."""

    _PATTERN = re.compile(r"^(\d+)([mhdwM])$")

    def __init__(self, value: str):
        match = self._PATTERN.match(value)
        if not match:
            raise ValueError(f"Invalid timeframe format: {value}. Expected format like '1m', '15m', '1h', '1d'.")

        self.value = value
        self.amount = int(match.group(1))
        self.unit = TimeframeUnit(match.group(2))

        if self.amount <= 0:
            raise ValueError(f"Timeframe amount must be positive, got {self.amount}")

    @property
    def seconds(self) -> int:
        """Total seconds in this timeframe."""
        multipliers = {
            TimeframeUnit.MINUTE: 60,
            TimeframeUnit.HOUR: 3600,
            TimeframeUnit.DAY: 86400,
            TimeframeUnit.WEEK: 604800,
            TimeframeUnit.MONTH: 2592000,  # Approximate (30 days)
        }
        return self.amount * multipliers[self.unit]

    @property
    def minutes(self) -> int:
        """Total minutes in this timeframe."""
        return self.seconds // 60

    def __str__(self) -> str:
        return self.value

    def __repr__(self) -> str:
        return f"Timeframe('{self.value}')"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Timeframe):
            return self.seconds == other.seconds
        if isinstance(other, str):
            try:
                return self.seconds == Timeframe(other).seconds
            except ValueError:
                return False
        return False

    def __hash__(self) -> int:
        return hash(self.value)

    @classmethod
    def coerce(cls, value: str | Timeframe) -> Timeframe:
        """Coerce a string or Timeframe object into a Timeframe instance."""
        if isinstance(value, cls):
            return value
        return cls(str(value))
