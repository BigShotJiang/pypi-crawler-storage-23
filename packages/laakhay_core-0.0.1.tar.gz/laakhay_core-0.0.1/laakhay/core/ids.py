"""Canonical identifier aliases shared across Laakhay libraries."""

from typing import NewType, TypeAlias

run_id = NewType("run_id", str)
user_id = NewType("user_id", str)
order_id = NewType("order_id", str)
trade_id = NewType("trade_id", str)
position_id = NewType("position_id", str)
dataset_id = NewType("dataset_id", str)

id_like: TypeAlias = str
