"""Position and execution models."""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from ..ids import order_id, trade_id
from ..normalization import to_decimal, to_timestamp
from ..types import Price, Qty, Symbol, Timestamp
from .order import OrderSide


@dataclass(frozen=True, slots=True)
class Trade:
    """Execution output from an order."""

    trade_id: trade_id | str
    order_id: order_id | str
    symbol: Symbol
    side: OrderSide | str
    qty: Qty
    price: Price
    timestamp: Timestamp = field(default_factory=lambda: datetime.now(UTC))
    fee: Price = Decimal("0")
    fee_asset: str | None = None
    schema_version: int = 1

    def __post_init__(self) -> None:
        object.__setattr__(self, "trade_id", str(self.trade_id))
        object.__setattr__(self, "order_id", str(self.order_id))
        object.__setattr__(self, "side", OrderSide(self.side))
        object.__setattr__(self, "qty", to_decimal(self.qty, field_name="qty"))
        object.__setattr__(self, "price", to_decimal(self.price, field_name="price"))
        object.__setattr__(self, "fee", to_decimal(self.fee, field_name="fee"))
        object.__setattr__(self, "timestamp", to_timestamp(self.timestamp, field_name="timestamp"))

    def to_dict(self) -> dict[str, Any]:
        return {
            "trade_id": self.trade_id,
            "order_id": self.order_id,
            "symbol": self.symbol,
            "side": self.side.value,
            "qty": str(self.qty),
            "price": str(self.price),
            "timestamp": self.timestamp.isoformat(),
            "fee": str(self.fee),
            "fee_asset": self.fee_asset,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Trade":
        return cls(
            trade_id=str(raw["trade_id"]),
            order_id=str(raw["order_id"]),
            symbol=str(raw["symbol"]),
            side=str(raw["side"]),
            qty=raw["qty"],
            price=raw["price"],
            timestamp=raw.get("timestamp", datetime.now(UTC)),
            fee=raw.get("fee", "0"),
            fee_asset=raw.get("fee_asset"),
            schema_version=int(raw.get("schema_version", 1)),
        )


@dataclass(slots=True)
class Position:
    """Mutable net position state after applying trades.

    Invariants:
    - qty > 0 => long
    - qty < 0 => short
    - qty == 0 => avg_entry_price is reset to 0
    """

    symbol: Symbol
    qty: Qty = Decimal("0")
    avg_entry_price: Price = Decimal("0")
    schema_version: int = 1

    def __post_init__(self) -> None:
        self.qty = to_decimal(self.qty, field_name="qty")
        self.avg_entry_price = to_decimal(self.avg_entry_price, field_name="avg_entry_price")

    @property
    def market_value(self) -> Price:
        """Net market value at average entry price."""
        return self.qty * self.avg_entry_price

    @property
    def abs_qty(self) -> Qty:
        return abs(self.qty)

    @property
    def is_flat(self) -> bool:
        return self.qty == 0

    @property
    def is_long(self) -> bool:
        return self.qty > 0

    @property
    def is_short(self) -> bool:
        return self.qty < 0

    def update(self, trade: Trade) -> None:
        """Update position with a new trade using netting logic."""
        if trade.symbol != self.symbol:
            raise ValueError(f"Symbol mismatch: {trade.symbol} != {self.symbol}")

        if trade.qty <= 0:
            raise ValueError("Trade quantity must be positive")

        if trade.side == OrderSide.BUY:
            self._apply_buy(trade)
        else:
            self._apply_sell(trade)

    def _apply_buy(self, trade: Trade) -> None:
        if self.is_flat:
            self.qty = trade.qty
            self.avg_entry_price = trade.price
        elif self.is_long:
            total_cost = (self.qty * self.avg_entry_price) + (trade.qty * trade.price)
            self.qty += trade.qty
            self.avg_entry_price = total_cost / self.qty
        else:  # Short
            short_qty = abs(self.qty)
            if trade.qty < short_qty:
                self.qty += trade.qty
            elif trade.qty == short_qty:
                self.qty = Decimal("0")
                self.avg_entry_price = Decimal("0")
            else:  # Reverse
                remainder = trade.qty - short_qty
                self.qty = remainder
                self.avg_entry_price = trade.price

    def _apply_sell(self, trade: Trade) -> None:
        if self.is_flat:
            self.qty = -trade.qty
            self.avg_entry_price = trade.price
        elif self.is_short:
            total_qty_abs = abs(self.qty) + trade.qty
            total_notional = (abs(self.qty) * self.avg_entry_price) + (trade.qty * trade.price)
            self.qty = -total_qty_abs
            self.avg_entry_price = total_notional / total_qty_abs
        else:  # Long
            if trade.qty < self.qty:
                self.qty -= trade.qty
            elif trade.qty == self.qty:
                self.qty = Decimal("0")
                self.avg_entry_price = Decimal("0")
            else:  # Reverse
                remainder = trade.qty - self.qty
                self.qty = -remainder
                self.avg_entry_price = trade.price

    def to_dict(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "qty": str(self.qty),
            "avg_entry_price": str(self.avg_entry_price),
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Position":
        return cls(
            symbol=str(raw["symbol"]),
            qty=raw.get("qty", "0"),
            avg_entry_price=raw.get("avg_entry_price", "0"),
            schema_version=int(raw.get("schema_version", 1)),
        )
