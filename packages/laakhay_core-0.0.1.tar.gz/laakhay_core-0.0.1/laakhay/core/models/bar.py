"""Bar (OHLCV) data model."""

from dataclasses import dataclass
from typing import Any

from ..normalization import to_decimal, to_timestamp
from ..types import Price, Qty, Timestamp


@dataclass(slots=True, frozen=True)
class Bar:
    """
    Unified OHLCV bar representation.
    Designed for high-performance memory efficiency using slots.
    """

    ts: Timestamp
    open: Price
    high: Price
    low: Price
    close: Price
    volume: Qty
    is_closed: bool = True
    schema_version: int = 1

    def __post_init__(self) -> None:
        """Basic validation for bar integrity."""
        object.__setattr__(self, "ts", to_timestamp(self.ts, field_name="ts"))
        object.__setattr__(self, "open", to_decimal(self.open, field_name="open"))
        object.__setattr__(self, "high", to_decimal(self.high, field_name="high"))
        object.__setattr__(self, "low", to_decimal(self.low, field_name="low"))
        object.__setattr__(self, "close", to_decimal(self.close, field_name="close"))
        object.__setattr__(self, "volume", to_decimal(self.volume, field_name="volume"))

        if self.high < self.low:
            raise ValueError(f"High ({self.high}) cannot be less than Low ({self.low})")
        if self.high < max(self.open, self.close):
            raise ValueError("High must be >= open and close")
        if self.low > min(self.open, self.close):
            raise ValueError("Low must be <= open and close")
        if self.volume < 0:
            raise ValueError("Volume cannot be negative")

    @property
    def hl2(self) -> Price:
        """High + Low / 2 (Mid price)."""
        return (self.high + self.low) / 2

    @property
    def hlc3(self) -> Price:
        """High + Low + Close / 3 (Typical price)."""
        return (self.high + self.low + self.close) / 3

    @property
    def ohlc4(self) -> Price:
        """Open + High + Low + Close / 4 (Average price)."""
        return (self.open + self.high + self.low + self.close) / 4

    @property
    def range(self) -> Price:
        """High - Low (Total range)."""
        return self.high - self.low

    @property
    def body_size(self) -> Price:
        """|Close - Open| (Absolute body size)."""
        return abs(self.close - self.open)

    @property
    def upper_shadow(self) -> Price:
        """High - max(Open, Close) (Upper wick/shadow)."""
        return self.high - max(self.open, self.close)

    @property
    def lower_shadow(self) -> Price:
        """min(Open, Close) - Low (Lower wick/shadow)."""
        return min(self.open, self.close) - self.low

    @property
    def is_bullish(self) -> bool:
        """True if close > open."""
        return self.close > self.open

    @property
    def is_bearish(self) -> bool:
        """True if close < open."""
        return self.close < self.open

    def to_dict(self) -> dict[str, Any]:
        return {
            "ts": self.ts.isoformat(),
            "open": str(self.open),
            "high": str(self.high),
            "low": str(self.low),
            "close": str(self.close),
            "volume": str(self.volume),
            "is_closed": self.is_closed,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Bar":
        return cls(
            ts=raw["ts"],
            open=raw["open"],
            high=raw["high"],
            low=raw["low"],
            close=raw["close"],
            volume=raw["volume"],
            is_closed=bool(raw.get("is_closed", True)),
            schema_version=int(raw.get("schema_version", 1)),
        )
