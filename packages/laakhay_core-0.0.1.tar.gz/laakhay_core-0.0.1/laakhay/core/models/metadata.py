"""Standard metadata for datasets and series."""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from ..enums import DataSource
from ..exceptions import ValidationError
from ..normalization import to_timestamp
from ..timeframe import Timeframe
from ..types import Symbol, Timestamp

# Standard source identifiers
SOURCE_OHLCV = DataSource.OHLCV.value
SOURCE_TRADES = DataSource.TRADES.value
SOURCE_ORDERBOOK = DataSource.ORDERBOOK.value
SOURCE_LIQUIDATION = DataSource.LIQUIDATION.value


@dataclass(frozen=True, slots=True)
class DatasetKey:
    """Immutable key for identifying a data series within a dataset."""

    symbol: Symbol
    timeframe: Timeframe | str
    source: DataSource | str
    schema_version: int = 1

    def __post_init__(self) -> None:
        object.__setattr__(self, "timeframe", Timeframe.coerce(self.timeframe))
        try:
            object.__setattr__(self, "source", DataSource(self.source))
        except ValueError as exc:
            raise ValidationError(
                f"Unknown dataset source: {self.source!r}",
                code="invalid_data_source",
                details={"source": self.source},
            ) from exc

    def __str__(self) -> str:
        return f"{self.symbol}|{self.timeframe.value}|{self.source.value}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "symbol": self.symbol,
            "timeframe": self.timeframe.value,
            "source": self.source.value,
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "DatasetKey":
        if "source" not in raw:
            raise ValidationError(
                "DatasetKey.source is required",
                code="missing_required_field",
                details={"field": "source"},
            )
        return cls(
            symbol=str(raw["symbol"]),
            timeframe=str(raw["timeframe"]),
            source=str(raw["source"]),
            schema_version=int(raw.get("schema_version", 1)),
        )


@dataclass(frozen=True, slots=True)
class DatasetMetadata:
    """Metadata for a collection of data series."""

    created_at: Timestamp = field(default_factory=lambda: datetime.now(UTC))
    description: str = ""
    tags: frozenset[str] = field(default_factory=frozenset)
    schema_version: int = 1

    def __post_init__(self) -> None:
        object.__setattr__(self, "created_at", to_timestamp(self.created_at, field_name="created_at"))

    def to_dict(self) -> dict[str, Any]:
        return {
            "created_at": self.created_at.isoformat(),
            "description": self.description,
            "tags": list(self.tags),
            "schema_version": self.schema_version,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "DatasetMetadata":
        return cls(
            created_at=raw.get("created_at", datetime.now(UTC)),
            description=str(raw.get("description", "")),
            tags=frozenset(str(tag) for tag in raw.get("tags", [])),
            schema_version=int(raw.get("schema_version", 1)),
        )
