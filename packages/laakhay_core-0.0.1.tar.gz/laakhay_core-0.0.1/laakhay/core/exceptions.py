"""Core exceptions for the Laakhay ecosystem."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


class LaakhayError(Exception):
    """Base exception for all Laakhay-related errors."""

    default_code = "laakhay_error"

    def __init__(self, message: str, *, code: str | None = None, details: Mapping[str, Any] | None = None) -> None:
        super().__init__(message)
        self.code = code or self.default_code
        self.details = dict(details or {})


class ValidationError(LaakhayError, ValueError):
    """Raised when data validation fails."""

    default_code = "validation_error"


class ConfigurationError(LaakhayError):
    """Raised when application configuration is invalid."""

    default_code = "configuration_error"


class DataError(LaakhayError):
    """Base class for data-related errors."""

    default_code = "data_error"


class MissingDataError(DataError):
    """Raised when requested data is not found."""

    default_code = "missing_data"


class CapabilityError(LaakhayError):
    """Raised when a requested feature/capability is unavailable."""

    default_code = "capability_error"


class ContractMismatchError(LaakhayError):
    """Raised when producer/consumer contracts diverge."""

    default_code = "contract_mismatch"


class ConflictError(LaakhayError):
    """Raised for invalid or conflicting state transitions."""

    default_code = "conflict_error"
