"""Public API surface for `laakhay.core`."""

from importlib.metadata import PackageNotFoundError, version

from .enums import DataSource, MarketType
from .exceptions import (
    CapabilityError,
    ConfigurationError,
    ConflictError,
    ContractMismatchError,
    DataError,
    LaakhayError,
    MissingDataError,
    ValidationError,
)
from .ids import dataset_id, id_like, order_id, position_id, run_id, trade_id, user_id
from .models import (
    SOURCE_LIQUIDATION,
    SOURCE_OHLCV,
    SOURCE_ORDERBOOK,
    SOURCE_TRADES,
    Bar,
    DatasetKey,
    DatasetMetadata,
    Order,
    OrderSide,
    OrderStatus,
    OrderType,
    Position,
    RiskType,
    Signal,
    SLTPType,
    Trade,
)
from .normalization import to_decimal, to_timestamp
from .timeframe import Timeframe, TimeframeUnit
from .types import (
    Price,
    PriceLike,
    Qty,
    QtyLike,
    Rate,
    RateLike,
    Symbol,
    SymbolLike,
    Timestamp,
    TimestampLike,
)

try:
    __version__ = version("laakhay-core")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "__version__",
    "Bar",
    "CapabilityError",
    "ConfigurationError",
    "ConflictError",
    "ContractMismatchError",
    "DataError",
    "DataSource",
    "dataset_id",
    "DatasetKey",
    "DatasetMetadata",
    "id_like",
    "LaakhayError",
    "MarketType",
    "MissingDataError",
    "Order",
    "order_id",
    "OrderSide",
    "OrderStatus",
    "OrderType",
    "Position",
    "position_id",
    "Price",
    "PriceLike",
    "Qty",
    "QtyLike",
    "Rate",
    "RateLike",
    "RiskType",
    "run_id",
    "SLTPType",
    "SOURCE_LIQUIDATION",
    "SOURCE_OHLCV",
    "SOURCE_ORDERBOOK",
    "SOURCE_TRADES",
    "Signal",
    "Symbol",
    "SymbolLike",
    "Timeframe",
    "TimeframeUnit",
    "Timestamp",
    "TimestampLike",
    "Trade",
    "trade_id",
    "user_id",
    "ValidationError",
    "to_decimal",
    "to_timestamp",
]
