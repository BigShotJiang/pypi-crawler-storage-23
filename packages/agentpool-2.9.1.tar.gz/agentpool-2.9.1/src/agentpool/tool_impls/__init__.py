"""Standalone tool implementations.

Each tool is a subclass of Tool that can be used independently or grouped.
"""

from __future__ import annotations
