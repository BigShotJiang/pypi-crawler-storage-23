"""Skills package for Claude Code Skills support."""

from agentpool.skills.manager import SkillsManager

__all__ = ["SkillsManager"]
