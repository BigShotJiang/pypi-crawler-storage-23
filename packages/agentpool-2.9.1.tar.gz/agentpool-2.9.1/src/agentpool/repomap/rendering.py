"""Rendering utilities for tree-based output.

This module contains helper functions for rendering tree structures and
working with filesystem entries.
"""

from __future__ import annotations
