"""File provider for agentpool."""

from __future__ import annotations

from agentpool_storage.file_provider.provider import FileProvider

__all__ = ["FileProvider"]
