"""MCP protocol server implementation for AgentPool."""

from agentpool_server.mcp_server.server import MCPServer


__all__ = ["MCPServer"]
