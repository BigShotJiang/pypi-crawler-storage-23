# The ratio1 Edge Protocol CLI 

## Develop

```bash
pip install -e .
```