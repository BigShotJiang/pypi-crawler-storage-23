# Python API

**lanctools** exports two classes for working with local ancestry data. [LancData](#lanctools-lancdata) contains the genotype and local ancestry data for a set of plink2 `.pgen` and `.lanc` files, together with efficient methods for querying this data. [FlatLanc](#lanctools-flatlanc) is the core data structure which stores local ancestry data in a flattened structure.

## ::: lanctools.LancData
    handler: python
    options:
      show_root_heading: true
      show_source: true

## ::: lanctools.FlatLanc
    handler: python
    options:
      show_root_heading: true
      show_source: true
