"""Tests for TimeRange model."""

import pytest
from pydantic import ValidationError

from radiens_core.models.time_range import TimeRange


def test_create_time_range() -> None:
    tr = TimeRange(
        sec=(0.0, 10.0),
        timestamp=(0, 300000),
        fs=30000.0,
        dur_sec=10.0,
        walltime="2024-01-01 00:00:00",
        n=300000,
    )
    assert tr.sec == (0.0, 10.0)
    assert tr.fs == 30000.0
    assert tr.n == 300000


def test_time_range_is_frozen() -> None:
    tr = TimeRange(
        sec=(0.0, 10.0),
        timestamp=(0, 300000),
        fs=30000.0,
        dur_sec=10.0,
        walltime="2024-01-01 00:00:00",
        n=300000,
    )
    with pytest.raises(ValidationError):
        tr.fs = 20000.0  # type: ignore[misc]
