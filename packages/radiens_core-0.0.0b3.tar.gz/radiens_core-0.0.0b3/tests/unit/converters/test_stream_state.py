"""Tests for stream state converters."""

from radiens_core._converters._stream_state import stream_state_request_to_proto
from radiens_core.models.enums import StreamMode
from radiens_core.models.status import StreamStateRequest


def test_stream_state_request_to_proto() -> None:
    """Test conversion of StreamStateRequest to proto."""
    # Test OFF mode
    request_off = StreamStateRequest(mode=StreamMode.OFF)
    proto_off = stream_state_request_to_proto(request_off)
    assert proto_off.mode == 0  # S_OFF proto value

    # Test ON mode
    request_on = StreamStateRequest(mode=StreamMode.ON)
    proto_on = stream_state_request_to_proto(request_on)
    assert proto_on.mode == 1  # S_ON proto value
