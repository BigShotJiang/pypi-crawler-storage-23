"""Tests for stimulation enum converters."""

from __future__ import annotations

from radiens_core._converters._enums import (
    stim_polarity_from_proto,
    stim_pulse_mode_from_proto,
    stim_shape_from_proto,
    stim_trigger_edge_or_level_from_proto,
    stim_trigger_level_from_proto,
)
from radiens_core._generated import allegoserver_pb2
from radiens_core.models.enums import (
    StimPolarity,
    StimPulseMode,
    StimShape,
    StimTriggerEdgeOrLevel,
    StimTriggerHighOrLow,
)


class TestStimShapeFromProto:
    def test_all_values(self) -> None:
        assert stim_shape_from_proto(int(allegoserver_pb2.BIPHASIC)) == StimShape.BIPHASIC
        assert (
            stim_shape_from_proto(int(allegoserver_pb2.BIPHASIC_INTERPHASE_DELAY))
            == StimShape.BIPHASIC_INTERPHASE_DELAY
        )
        assert stim_shape_from_proto(int(allegoserver_pb2.TRIPHASIC)) == StimShape.TRIPHASIC
        assert stim_shape_from_proto(int(allegoserver_pb2.MONOPHASIC)) == StimShape.MONOPHASIC


class TestStimPolarityFromProto:
    def test_all_values(self) -> None:
        assert stim_polarity_from_proto(int(allegoserver_pb2.CATHODIC_FIRST)) == StimPolarity.CATHODIC_FIRST
        assert stim_polarity_from_proto(int(allegoserver_pb2.ANODIC_FIRST)) == StimPolarity.ANODIC_FIRST


class TestStimTriggerEdgeFromProto:
    def test_all_values(self) -> None:
        assert stim_trigger_edge_or_level_from_proto(int(allegoserver_pb2.ST_EDGE)) == StimTriggerEdgeOrLevel.EDGE
        assert stim_trigger_edge_or_level_from_proto(int(allegoserver_pb2.ST_LEVEL)) == StimTriggerEdgeOrLevel.LEVEL


class TestStimTriggerLevelFromProto:
    def test_all_values(self) -> None:
        assert stim_trigger_level_from_proto(int(allegoserver_pb2.ST_HIGH)) == StimTriggerHighOrLow.HIGH
        assert stim_trigger_level_from_proto(int(allegoserver_pb2.ST_LOW)) == StimTriggerHighOrLow.LOW


class TestStimPulseModeFromProto:
    def test_all_values(self) -> None:
        assert stim_pulse_mode_from_proto(int(allegoserver_pb2.SINGLE_PULSE)) == StimPulseMode.SINGLE_PULSE
        assert stim_pulse_mode_from_proto(int(allegoserver_pb2.PULSE_TRAIN)) == StimPulseMode.PULSE_TRAIN
