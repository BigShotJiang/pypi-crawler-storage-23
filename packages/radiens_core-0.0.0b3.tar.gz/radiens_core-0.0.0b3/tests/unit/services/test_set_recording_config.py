"""Test set/get recording config service functionality."""

from unittest.mock import Mock, patch

from radiens_core._generated import allegoserver_pb2, common_pb2
from radiens_core._services._allego_core import (
    get_recording_config_proto,
    set_recording_config_proto,
)
from radiens_core._transport._channel_pool import ChannelPool


class TestSetRecordingConfigProto:
    """Test set_recording_config_proto functionality."""

    def test_calls_stub_with_config_recording_request(self) -> None:
        """Test that set_recording_config_proto calls stub.SetConfigRecording with correct request."""
        # Arrange
        pool = Mock(spec=ChannelPool)
        channel = Mock()
        stub = Mock()
        response = common_pb2.StandardReply()

        pool.get_channel.return_value = channel
        stub.SetConfigRecording.return_value = response

        request = allegoserver_pb2.ConfigRecording(
            baseFileName="test_recording",
            baseFilePath="/path/to/data",
            dataSourceIdx=0,
            timeStamp=True,
            recordingType=allegoserver_pb2.continuous,
        )

        # Mock the stub creation
        with patch(
            "radiens_core._generated.allegoserver_pb2_grpc.AllegoCoreStub",
            return_value=stub,
        ):
            # Act
            result = set_recording_config_proto(pool, "localhost:8080", request)

            # Assert
            pool.get_channel.assert_called_once_with("localhost:8080")
            stub.SetConfigRecording.assert_called_once_with(request)
            assert result is response


class TestGetRecordingConfigProto:
    """Test get_recording_config_proto functionality."""

    def test_calls_stub_with_standard_request(self) -> None:
        """Test that get_recording_config_proto calls stub.GetConfigRecording with StandardRequest."""
        # Arrange
        pool = Mock(spec=ChannelPool)
        channel = Mock()
        stub = Mock()
        response = allegoserver_pb2.ConfigRecording()

        pool.get_channel.return_value = channel
        stub.GetConfigRecording.return_value = response

        # Mock the stub creation
        with patch(
            "radiens_core._generated.allegoserver_pb2_grpc.AllegoCoreStub",
            return_value=stub,
        ):
            # Act
            result = get_recording_config_proto(pool, "localhost:8080")

            # Assert
            pool.get_channel.assert_called_once_with("localhost:8080")
            stub.GetConfigRecording.assert_called_once_with(common_pb2.StandardRequest())
            assert result is response
