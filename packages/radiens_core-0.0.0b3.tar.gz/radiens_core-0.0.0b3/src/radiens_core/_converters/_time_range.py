"""TimeRange <-> proto converters."""

from __future__ import annotations

from radiens_core._generated import common_pb2
from radiens_core.models.time_range import TimeRange


def time_range_from_proto(
    sec_start: float,
    sec_end: float,
    ts_start: int,
    ts_end: int,
    fs: float,
    dur_sec: float,
    walltime: str,
    n: int,
) -> TimeRange:
    """Build a domain TimeRange from proto fields."""
    return TimeRange(
        sec=(sec_start, sec_end),
        timestamp=(ts_start, ts_end),
        fs=fs,
        dur_sec=dur_sec,
        walltime=walltime,
        n=n,
    )


def time_range_to_proto(tr: TimeRange) -> common_pb2.TimeRange:
    """Convert domain TimeRange to proto TimeRange."""
    return common_pb2.TimeRange(
        timestamp=list(tr.timestamp),
        fs=tr.fs,
    )
