"""Recording config converters — domain models <-> proto messages."""

from __future__ import annotations

from typing import TYPE_CHECKING

from radiens_core._converters._enums import (
    data_recording_type_from_proto,
    data_recording_type_to_proto,
)
from radiens_core._generated import allegoserver_pb2

if TYPE_CHECKING:
    from radiens_core.models.status import RecordingConfig


def recording_config_to_proto(
    config: RecordingConfig,
) -> allegoserver_pb2.ConfigRecording:
    """Convert domain RecordingConfig to proto ConfigRecording."""
    return allegoserver_pb2.ConfigRecording(
        baseFileName=config.base_file_name,
        baseFilePath=config.base_file_path,
        dataSourceIdx=config.datasource_idx,
        timeStamp=config.time_stamp,
        splitFilesByPort=config.split_files_by_port,
        forceStartAtTStamp0=config.force_start_at_tstamp_0,
        recordingType=data_recording_type_to_proto(config.recording_type),
    )


def recording_config_from_proto(
    proto: allegoserver_pb2.ConfigRecording,
) -> RecordingConfig:
    """Convert proto ConfigRecording to domain RecordingConfig."""
    from radiens_core.models.status import RecordingConfig

    return RecordingConfig(
        base_file_name=proto.baseFileName,
        base_file_path=proto.baseFilePath,
        datasource_idx=proto.dataSourceIdx,
        time_stamp=proto.timeStamp,
        split_files_by_port=proto.splitFilesByPort,
        force_start_at_tstamp_0=proto.forceStartAtTStamp0,
        recording_type=data_recording_type_from_proto(proto.recordingType),
    )
