"""Signal data <-> proto converters."""

from __future__ import annotations

import numpy as np
import numpy.typing as npt

from radiens_core._generated import common_pb2
from radiens_core.models.signals import SignalArrays, SigSelect


def radix_matrix_to_numpy(
    mb: common_pb2.RadixMatrixBytes,
) -> npt.NDArray[np.float64] | None:
    """Convert proto RadixMatrixBytes to a numpy 2D array (channels x samples).

    Returns None if data is empty.
    """
    if len(mb.data) == 0:
        return None
    arr = np.frombuffer(mb.data, dtype=np.float32).astype(np.float64)
    return arr.reshape(mb.shape[0], mb.shape[1])


def signal_arrays_from_signals2(
    sigs: common_pb2.Signals2,
) -> SignalArrays:
    """Build domain SignalArrays from proto Signals2."""
    return SignalArrays(
        amp=radix_matrix_to_numpy(sigs.amp),
        gpio_ain=radix_matrix_to_numpy(sigs.ain),
        gpio_din=radix_matrix_to_numpy(sigs.din),
        gpio_dout=radix_matrix_to_numpy(sigs.dout),
    )


def sig_select_to_proto(sig_sel: SigSelect) -> common_pb2.SigSelector:
    """Convert domain SigSelect to proto SigSelector."""
    return common_pb2.SigSelector(
        ampNtvIdxs=sig_sel.amp.tolist(),
        ainNtvIdxs=sig_sel.gpio_ain.tolist(),
        dinNtvIdxs=sig_sel.gpio_din.tolist(),
        doutNtvIdxs=sig_sel.gpio_dout.tolist(),
    )
