"""Restart converters — domain models <-> proto messages."""

from __future__ import annotations

from typing import TYPE_CHECKING

from radiens_core._converters._enums import backbone_mode_to_proto
from radiens_core._generated import allegoserver_pb2

if TYPE_CHECKING:
    from radiens_core.models.status import RestartRequest


def restart_request_to_proto(
    request: RestartRequest,
) -> allegoserver_pb2.RestartRequest:
    """Convert domain RestartRequest to proto RestartRequest."""
    return allegoserver_pb2.RestartRequest(
        mode=backbone_mode_to_proto(request.mode),
    )
