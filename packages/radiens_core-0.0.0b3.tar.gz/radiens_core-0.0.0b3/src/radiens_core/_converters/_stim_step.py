"""Stimulation step control converters — domain ↔ proto."""

from __future__ import annotations

from typing import TYPE_CHECKING

from radiens_core._converters._enums import (
    stim_step_from_proto,
    stim_step_to_proto,
)
from radiens_core.models.status import (
    StimStepRequest,
    StimStepState,
)

if TYPE_CHECKING:
    from radiens_core._generated import allegoserver_pb2


def stim_step_request_to_proto(
    request: StimStepRequest,
) -> allegoserver_pb2.StimStepMessage:
    """Convert ``StimStepRequest`` domain model → proto message."""
    from radiens_core._generated import allegoserver_pb2

    return allegoserver_pb2.StimStepMessage(
        stimStep=stim_step_to_proto(request.stim_step),
    )


def stim_step_state_from_proto(
    response: allegoserver_pb2.StimStepMessage,
) -> StimStepState:
    """Convert ``StimStepMessage`` proto response → domain model."""
    return StimStepState(
        stim_step=stim_step_from_proto(response.stimStep),
    )
