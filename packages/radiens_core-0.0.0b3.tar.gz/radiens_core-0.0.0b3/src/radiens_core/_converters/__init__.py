"""Proto <-> domain converters — the ONLY place importing both proto and domain types."""
