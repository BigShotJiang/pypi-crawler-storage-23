"""Stimulation parameter converter — proto ↔ domain."""

from __future__ import annotations

from typing import TYPE_CHECKING

from radiens_core._converters._enums import (
    stim_polarity_from_proto,
    stim_polarity_to_proto,
    stim_pulse_mode_from_proto,
    stim_pulse_mode_to_proto,
    stim_shape_from_proto,
    stim_shape_to_proto,
    stim_trigger_edge_or_level_from_proto,
    stim_trigger_edge_or_level_to_proto,
    stim_trigger_level_from_proto,
    stim_trigger_level_to_proto,
)
from radiens_core.models.stim import StimParams

if TYPE_CHECKING:
    from radiens_core._generated import allegoserver_pb2


def stim_params_from_proto(
    reply: allegoserver_pb2.StimParamsReply,
) -> dict[int, StimParams]:
    """Convert ``StimParamsReply`` proto → dict keyed by system channel index."""
    result: dict[int, StimParams] = {}
    for sys_chan_idx, pb in reply.params.items():
        result[sys_chan_idx] = _single_from_proto(pb)
    return result


def _single_from_proto(pb: allegoserver_pb2.StimParams) -> StimParams:
    """Convert a single ``StimParams`` proto message to a domain model."""
    return StimParams(
        stim_shape=stim_shape_from_proto(pb.stimShape),
        stim_polarity=stim_polarity_from_proto(pb.stimPolarity),
        first_phase_duration=pb.firstPhaseDuration,
        second_phase_duration=pb.secondPhaseDuration,
        interphase_delay=pb.interphaseDelay,
        first_phase_amplitude=pb.firstPhaseAmplitude,
        second_phase_amplitude=pb.secondPhaseAmplitude,
        baseline_voltage=pb.baselineVoltage,
        trigger_edge_or_level=stim_trigger_edge_or_level_from_proto(pb.triggerEdgeOrLevel),
        trigger_high_or_low=stim_trigger_level_from_proto(pb.triggerHighOrLow),
        enabled=pb.enabled,
        post_trigger_delay=pb.postTriggerDelay,
        pulse_or_train=stim_pulse_mode_from_proto(pb.pulseOrTrain),
        number_of_stim_pulses=pb.numberOfStimPulses,
        pulse_train_period=pb.pulseTrainPeriod,
        refractory_period=pb.refractoryPeriod,
        pre_stim_amp_settle=pb.preStimAmpSettle,
        post_stim_amp_settle=pb.postStimAmpSettle,
        maintain_amp_settle=pb.maintainAmpSettle,
        enable_amp_settle=pb.enableAmpSettle,
        post_stim_charge_recov_on=pb.postStimChargeRecovOn,
        post_stim_charge_recov_off=pb.postStimChargeRecovOff,
        enable_charge_recovery=pb.enableChargeRecovery,
        trigger_source_is_keypress=pb.triggerSourceIsKeypress,
        trigger_source_idx=pb.triggerSourceIdx,
        stim_sys_chan_idx=pb.stimSysChanIdx,
    )


def stim_params_to_proto(
    stim_params: StimParams,
) -> allegoserver_pb2.StimParams:
    """Convert ``StimParams`` domain model → proto message."""
    from radiens_core._generated import allegoserver_pb2

    return allegoserver_pb2.StimParams(
        stimShape=stim_shape_to_proto(stim_params.stim_shape),
        stimPolarity=stim_polarity_to_proto(stim_params.stim_polarity),
        firstPhaseDuration=stim_params.first_phase_duration,
        secondPhaseDuration=stim_params.second_phase_duration,
        interphaseDelay=stim_params.interphase_delay,
        firstPhaseAmplitude=stim_params.first_phase_amplitude,
        secondPhaseAmplitude=stim_params.second_phase_amplitude,
        baselineVoltage=stim_params.baseline_voltage,
        triggerEdgeOrLevel=stim_trigger_edge_or_level_to_proto(
            stim_params.trigger_edge_or_level
        ),
        triggerHighOrLow=stim_trigger_level_to_proto(
            stim_params.trigger_high_or_low
        ),
        enabled=stim_params.enabled,
        postTriggerDelay=stim_params.post_trigger_delay,
        pulseOrTrain=stim_pulse_mode_to_proto(stim_params.pulse_or_train),
        numberOfStimPulses=stim_params.number_of_stim_pulses,
        pulseTrainPeriod=stim_params.pulse_train_period,
        refractoryPeriod=stim_params.refractory_period,
        preStimAmpSettle=stim_params.pre_stim_amp_settle,
        postStimAmpSettle=stim_params.post_stim_amp_settle,
        maintainAmpSettle=stim_params.maintain_amp_settle,
        enableAmpSettle=stim_params.enable_amp_settle,
        postStimChargeRecovOn=stim_params.post_stim_charge_recov_on,
        postStimChargeRecovOff=stim_params.post_stim_charge_recov_off,
        enableChargeRecovery=stim_params.enable_charge_recovery,
        triggerSourceIsKeypress=stim_params.trigger_source_is_keypress,
        triggerSourceIdx=stim_params.trigger_source_idx,
        stimSysChanIdx=stim_params.stim_sys_chan_idx,
    )
