"""Radiens Python client for neuroscience data acquisition and analysis."""

from radiens_core._version import __version__
from radiens_core.allego_client import AllegoClient
from radiens_core.curate_client import CurateClient
from radiens_core.exceptions import (
    ConfigurationError,
    DataProcessingError,
    DatasetError,
    RadiensError,
    ServerCommunicationError,
    SignalSelectionError,
    TimeRangeError,
)
from radiens_core.models.channels import ChannelMetadata
from radiens_core.models.dataset import DatasetMetadata
from radiens_core.models.enums import (
    ClientType,
    DataRecordingType,
    KeyIndex,
    Port,
    RadiensFileType,
    RecordMode,
    SignalType,
    StimPolarity,
    StimPulseMode,
    StimShape,
    StimStep,
    StimTriggerEdgeOrLevel,
    StimTriggerHighOrLow,
    StreamMode,
    TrsMode,
)
from radiens_core.models.gpio import GPIOChannelCount
from radiens_core.models.ports import PortChannelCount
from radiens_core.models.signals import SignalArrays, SigSelect
from radiens_core.models.status import (
    BackboneStatus,
    RecordingConfig,
    RecordingStatus,
    StimStepRequest,
    StimStepState,
    StreamingStatus,
)
from radiens_core.models.stim import StimParams
from radiens_core.models.time_range import TimeRange
from radiens_core.specs import FlexSignalSpec, FlexTimeRange, SignalSpec, TimeRangeSpec
from radiens_core.videre_client import VidereClient

__all__ = [
    "AllegoClient",
    "BackboneStatus",
    "ChannelMetadata",
    "ClientType",
    "ConfigurationError",
    "CurateClient",
    "DataProcessingError",
    "DataRecordingType",
    "DatasetError",
    "DatasetMetadata",
    "FlexSignalSpec",
    "FlexTimeRange",
    "GPIOChannelCount",
    "KeyIndex",
    "Port",
    "PortChannelCount",
    "RadiensError",
    "RadiensFileType",
    "RecordMode",
    "RecordingConfig",
    "RecordingStatus",
    "ServerCommunicationError",
    "SigSelect",
    "SignalArrays",
    "SignalSelectionError",
    "SignalSpec",
    "SignalType",
    "StimParams",
    "StimPolarity",
    "StimPulseMode",
    "StimShape",
    "StimStep",
    "StimStepRequest",
    "StimStepState",
    "StimTriggerEdgeOrLevel",
    "StimTriggerHighOrLow",
    "StreamMode",
    "StreamingStatus",
    "TimeRange",
    "TimeRangeError",
    "TimeRangeSpec",
    "TrsMode",
    "VidereClient",
    "__version__",
]
