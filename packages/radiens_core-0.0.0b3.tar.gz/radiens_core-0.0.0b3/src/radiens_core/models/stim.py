"""Stimulation parameter domain model."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from radiens_core.models.enums import (
    StimKeypressIndex,
    StimPolarity,
    StimPulseMode,
    StimShape,
    StimTriggerEdgeOrLevel,
    StimTriggerHighOrLow,
)


class StimParams(BaseModel):
    """Stimulation parameters for a single channel.

    All timing values are in microseconds (μs). Current amplitudes are in μA
    for amplifier channels and V for DAC channels.
    """

    model_config = ConfigDict(frozen=True)

    # --- Channel identity ---
    stim_sys_chan_idx: int
    """System channel index (ntvAbsKeyIdx)."""

    # --- Waveform shape ---
    stim_shape: StimShape = StimShape.BIPHASIC
    stim_polarity: StimPolarity = StimPolarity.CATHODIC_FIRST

    # --- Phase timing (μs) ---
    first_phase_duration: float = 100.0
    second_phase_duration: float = 100.0
    interphase_delay: float = 0.0

    # --- Amplitudes (μA for amp, V for DAC) ---
    first_phase_amplitude: float = 0.1  # Default to 0.1 μA to be conservative
    second_phase_amplitude: float = 0.0
    baseline_voltage: float = 0.0

    # --- Trigger ---
    trigger_edge_or_level: StimTriggerEdgeOrLevel = StimTriggerEdgeOrLevel.EDGE
    trigger_high_or_low: StimTriggerHighOrLow = StimTriggerHighOrLow.HIGH
    enabled: bool = True
    post_trigger_delay: float = 0.0

    # --- Pulse train ---
    pulse_or_train: StimPulseMode = StimPulseMode.SINGLE_PULSE
    number_of_stim_pulses: int = 1
    pulse_train_period: float = 0.0
    refractory_period: float = 0.0

    # --- Amp settle ---
    pre_stim_amp_settle: float = 0.0
    post_stim_amp_settle: float = 0.0
    maintain_amp_settle: bool = False
    enable_amp_settle: bool = False

    # --- Charge recovery ---
    post_stim_charge_recov_on: float = 0.0
    post_stim_charge_recov_off: float = 0.0
    enable_charge_recovery: bool = False

    # --- Trigger source ---
    trigger_source_is_keypress: bool = False
    trigger_source_idx: int | StimKeypressIndex
    """AIN/DIN sysChanIdx, or keypress number."""


    @classmethod
    def biphasic(
        cls: type[StimParams],
        *,
        amplitude: float,
        pulse_duration: float,
        polarity: StimPolarity,
        stim_sys_chan_idx: int,
        enabled: bool = True,
        **overrides: object,
    ) -> StimParams:
        """Create biphasic stimulation parameters.

        Args:
            amplitude: First phase amplitude (μA for amp channels)
            pulse_duration: Phase duration in microseconds
            polarity: Stimulation polarity (cathodic or anodic first)
            stim_sys_chan_idx: System channel index
            charge_balanced: If True, second phase amplitude matches first phase
            **overrides: Override any other StimParams field

        Returns:
            StimParams configured for biphasic stimulation
        """
        return cls(
            stim_shape=StimShape.BIPHASIC,
            stim_polarity=polarity,
            first_phase_duration=pulse_duration,
            second_phase_duration=pulse_duration,
            first_phase_amplitude=amplitude,
            second_phase_amplitude=amplitude,
            stim_sys_chan_idx=stim_sys_chan_idx,
            enabled=enabled,
            **overrides,  # type: ignore[arg-type]
        )
