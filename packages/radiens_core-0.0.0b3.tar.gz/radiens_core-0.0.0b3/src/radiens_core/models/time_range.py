"""TimeRange — resolved, concrete time range with all fields populated."""

from pydantic import BaseModel, ConfigDict


class TimeRange(BaseModel):
    """A resolved, concrete time range.

    All fields are populated after resolution from a TimeRangeSpec
    against dataset metadata or cache state.

    Attributes
    ----------
    sec : tuple[float, float]
        Start and end times in seconds ``(start, end)``.
    timestamp : tuple[int, int]
        Start and end times in samples ``(start_sample, end_sample)``.
    fs : float
        Sampling rate in Hz.
    dur_sec : float
        Duration in seconds.
    walltime : str
        Wall-clock time string.
    n : int
        Number of samples.
    """

    model_config = ConfigDict(frozen=True)

    sec: tuple[float, float]
    timestamp: tuple[int, int]
    fs: float
    dur_sec: float
    walltime: str
    n: int
