"""Port domain models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from radiens_core.models.enums import Port


class PortChannelCount(BaseModel):
    """Port channel count information."""

    model_config = ConfigDict(frozen=True)

    port: Port
    channel_count: int
