"""DatasetMetadata — immutable metadata for a linked dataset."""

from pydantic import BaseModel, ConfigDict

from radiens_core.models.channels import ChannelMetadata
from radiens_core.models.enums import RadiensFileType
from radiens_core.models.time_range import TimeRange


class DatasetMetadata(BaseModel):
    """Metadata for a linked dataset.

    Returned by ``link_data_file()`` and similar operations.
    Contains everything needed to query signals from this dataset.
    """

    model_config = ConfigDict(frozen=True)

    id: str
    base_name: str
    path: str
    file_type: RadiensFileType
    time_range: TimeRange
    channel_metadata: ChannelMetadata
    parent_dsource_id: str = ""
    probe_uid: str = ""

    @property
    def duration(self) -> float:
        """Dataset duration in seconds."""
        return self.time_range.dur_sec

    @property
    def sampling_rate(self) -> float:
        """Sampling rate in Hz."""
        return self.time_range.fs
