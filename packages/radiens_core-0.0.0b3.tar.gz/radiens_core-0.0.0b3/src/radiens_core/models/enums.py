"""Domain enums — proto-free, plain Python IntEnum/StrEnum values.

These enums mirror the proto enum values but have ZERO dependency on generated code.
The mapping between domain enums and proto enums lives in ``_converters/_enums.py``.
"""

from enum import IntEnum, StrEnum

__all__ = [
    "AreaUnits",
    "BackboneMode",
    "ClientType",
    "DataRecordingType",
    "KeyIndex",
    "Port",
    "RadiensFileType",
    "RadiensService",
    "RecordMode",
    "SignalType",
    "SignalUnits",
    "StimPolarity",
    "StimPulseMode",
    "StimShape",
    "StimTriggerEdgeOrLevel",
    "StimTriggerHighOrLow",
    "StreamMode",
    "TrsMode",
]


class ClientType(StrEnum):
    """Client type identifier."""

    ALLEGO = "AllegoClient"
    VIDERE = "VidereClient"
    CURATE = "CurateClient"


class RadiensService(IntEnum):
    """Radiens backend service type."""

    CORE = 0
    DASH = 1
    SORTER = 2
    DEV = 3
    RADIENSPY = 4
    PCACHE = 5


class KeyIndex(IntEnum):
    """Channel key index type.

    NTV: native position in DAQ stream per signal type (starts at 0).
    DATA: position in backing dataset per signal type.
    SYS: global position across all signal types.
    """

    NTV = 0
    DATA = 1
    SYS = 2


class SignalType(IntEnum):
    """Signal type. Values match proto ``common.SignalType``."""

    AMP = 0   # PRI in proto
    AIN = 1   # AUX in proto
    DIN = 2
    DOUT = 3


class TrsMode(IntEnum):
    """Time range selection mode. Values match proto ``common.TimeRangeSelMode``."""

    SUBSET = 0     # TRS_SUBSET
    TO_HEAD = 1    # TRS_TO_HEAD
    FROM_HEAD = 2  # TRS_FROM_HEAD


class RadiensFileType(IntEnum):
    """Recording file type. Values match proto ``common.RadixFileTypes``."""

    RHD = 0
    XDAT = 1
    CSV = 2
    HDF5 = 3
    NEX5 = 4
    NWB = 5
    KILOSORT2 = 8
    NSX = 13
    TDT = 15
    SPIKES = 16
    OE_DAT = 22


class SignalUnits(IntEnum):
    """Signal measurement units."""

    UNKNOWN = 0
    MICROVOLTS = 1
    VOLTS = 2
    BINARY = 3


class AreaUnits(IntEnum):
    """Area measurement units for electrode sites."""

    SQUARE_MICROMETERS = 0  # µm² (base unit)
    SQUARE_MILLIMETERS = 1  # mm²
    SQUARE_CENTIMETERS = 2  # cm²
    SQUARE_NANOMETERS = 3  # nm²
    SQUARE_METERS = 4  # m²


# ===================================================================
# Stimulation enums
# ===================================================================


class StimShape(IntEnum):
    """Stimulation waveform shape. Values match proto ``allego.StimShape``."""

    BIPHASIC = 0
    BIPHASIC_INTERPHASE_DELAY = 1
    TRIPHASIC = 2
    MONOPHASIC = 3


class StimPolarity(IntEnum):
    """Stimulation polarity. Values match proto ``allego.StimPolarity``."""

    CATHODIC_FIRST = 0
    ANODIC_FIRST = 1


class StimTriggerEdgeOrLevel(IntEnum):
    """Stimulation trigger edge/level mode. Values match proto ``allego.StimTriggerEdgeOrLevel``."""

    EDGE = 0
    LEVEL = 1


class StimTriggerHighOrLow(IntEnum):
    """Stimulation trigger high/low. Values match proto ``allego.StimTriggerHighOrLow``."""

    HIGH = 0
    LOW = 1


class StimPulseMode(IntEnum):
    """Stimulation pulse mode. Values match proto ``allego.StimPulseOrTrain``."""

    SINGLE_PULSE = 0
    PULSE_TRAIN = 1


# ===================================================================
# System status enums
# ===================================================================


class BackboneMode(IntEnum):
    """Hardware backbone mode. Values match proto ``allego.BackboneMode``."""

    SMARTBOX_PRO = 0
    SMARTBOX_SIM_GEN_SINE = 1  # low freq
    SMARTBOX_SIM_GEN_SPIKES = 2
    SMARTBOX_SIM_DATASOURCE = 3
    OPEN_EPHYS_USB3 = 4
    INTAN_RECORDING_CONTROLLER_1024 = 5
    SMARTBOX_CLASSIC = 6
    INTAN_RECORDING_CONTROLLER_512 = 7
    OPEN_EPHYS_USB2 = 8
    INTAN_USB2 = 9
    SMARTBOX_SIM_GEN_SINE_MAPPED = 10
    SMARTBOX_SIM_GEN_SINE_HIGH_FREQ = 11
    SMARTBOX_SIM_GEN_SINE_MULTI_BAND = 12
    SMARTBOX_PRO_SINAPS_256 = 13
    SMARTBOX_PRO_SINAPS_1024 = 14
    XDAQ_ONE_REC = 15
    XDAQ_ONE_STIM = 16
    XDAQ_CORE_REC = 17
    XDAQ_CORE_STIM = 18
    SMARTBOX_PRO_SINAPS_512 = 19
    XDAQ_GEN2_ONE_STIM = 20
    XDAQ_GEN2_CORE_STIM = 21
    XDAQ_GEN2_ONE_REC = 22
    XDAQ_GEN2_CORE_REC = 23
    SMARTBOX_SIM_GEN_LFP = 24


class StreamMode(IntEnum):
    """Data stream mode. Values match proto ``allego.StreamMode``."""

    OFF = 0  # S_OFF
    ON = 1   # S_ON


class RecordMode(IntEnum):
    """Data recording mode. Values match proto ``allego.RecordMode``."""

    OFF = 0  # R_OFF
    ON = 1   # R_ON


class DataRecordingType(IntEnum):
    """Data recording type. Values match proto ``allego.DataRecordingType``."""

    CONTINUOUS = 0           # continuous
    SPIKES = 1              # spikes
    CONTINUOUS_AND_SPIKES = 2    # continuousAndSpikes


class Port(IntEnum):
    """Hardware port identifier. Values match proto ``common.Port``."""

    A = 0
    B = 1
    C = 2
    D = 3
    E = 4
    F = 5
    G = 6
    H = 7


class TriggerChannel(IntEnum):
    """Trigger channel identifier. Values match proto ``allego.TriggerChannel``."""

    T_DIN_0 = 0
    T_DIN_1 = 1
    T_DIN_2 = 2
    T_DIN_3 = 3
    T_DIN_4 = 4
    T_DIN_5 = 5
    T_DIN_6 = 6
    T_DIN_7 = 7
    T_DIN_8 = 8
    T_DIN_9 = 9
    T_DIN_10 = 10
    T_DIN_11 = 11
    T_DIN_12 = 12
    T_DIN_13 = 13
    T_DIN_14 = 14
    T_DIN_15 = 15
    T_DOUT_0 = 16
    T_DOUT_1 = 17
    T_DOUT_2 = 18
    T_DOUT_3 = 19
    T_DOUT_4 = 20
    T_DOUT_5 = 21
    T_DOUT_6 = 22
    T_DOUT_7 = 23
    T_DOUT_8 = 24
    T_DOUT_9 = 25
    T_DOUT_10 = 26
    T_DOUT_11 = 27
    T_DOUT_12 = 28
    T_DOUT_13 = 29
    T_DOUT_14 = 30
    T_DOUT_15 = 31
    T_NONE = 32


class StimStep(IntEnum):
    """Stimulation step size. Values match proto ``allego.StimStep``."""

    STIM_STEP_SIZE_MIN = 0
    STIM_STEP_SIZE_10_NA = 1
    STIM_STEP_SIZE_20_NA = 2
    STIM_STEP_SIZE_50_NA = 3
    STIM_STEP_SIZE_100_NA = 4
    STIM_STEP_SIZE_200_NA = 5
    STIM_STEP_SIZE_500_NA = 6
    STIM_STEP_SIZE_1_UA = 7
    STIM_STEP_SIZE_2_UA = 8
    STIM_STEP_SIZE_5_UA = 9
    STIM_STEP_SIZE_10_UA = 10
    STIM_STEP_SIZE_MAX = 11


class StimKeypressIndex(IntEnum):
    KEYPRESS_1 = 1
    KEYPRESS_2 = 2
    KEYPRESS_3 = 3
    KEYPRESS_4 = 4
    KEYPRESS_5 = 5
    KEYPRESS_6 = 6
    KEYPRESS_7 = 7
    KEYPRESS_8 = 8
