"""Domain models — pure Pydantic v2, zero proto dependency."""
