"""GPIO domain models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class GPIOChannelCount(BaseModel):
    """GPIO channel count information."""

    model_config = ConfigDict(frozen=True)

    n_aux: int
    n_din: int
    n_dout: int
