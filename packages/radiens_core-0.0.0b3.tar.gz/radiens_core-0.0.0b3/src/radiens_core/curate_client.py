"""CurateClient — data curation client (skeleton)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from radiens_core._constants import ALLEGO_CORE_ADDR
from radiens_core._transport._auth import AuthInterceptor
from radiens_core._transport._channel_pool import ChannelPool

if TYPE_CHECKING:
    from radiens_core.models.enums import RadiensService


class CurateClient:
    """Client for data curation operations (skeleton)."""

    def __init__(self, address: str = ALLEGO_CORE_ADDR) -> None:
        self._address = address
        self._pool = ChannelPool(
            interceptors=[AuthInterceptor(server_address=address)],
        )

    # --- Lifecycle ---

    def close(self) -> None:
        """Close all gRPC channels."""
        self._pool.close()

    def __enter__(self) -> CurateClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # --- Internal helpers ---

    def _server_address(self, service: RadiensService) -> str:
        """Resolve server address for the given service."""
        return self._address
