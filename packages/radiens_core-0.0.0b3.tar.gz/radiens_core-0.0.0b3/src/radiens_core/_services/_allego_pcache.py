"""Pcache1 RPC wrappers — thin service layer (proto only)."""
