#!/usr/bin/env python3
"""Example usage of Restart method."""

from asyncio import sleep

from radiens_core import AllegoClient
from radiens_core.models.enums import BackboneMode
from radiens_core.models.status import RestartRequest


def main() -> None:
    """Demonstrate Restart usage."""
    with AllegoClient() as client:
        print("=== System Restart Examples ===")

        # Check current system status before restart
        print("\\n1. Checking current system status...")
        try:
            status = client.get_status()
            print(f"System connected: {status.is_connected}")
            print(f"Current stream mode: {status.streaming.stream_mode}")
            sleep(2)  # Simulate some time before restart
        except Exception as e:
            print(f"Status check failed: {e}")

        print("\\n2. Restarting with SmartBox Pro mode...")
        try:
            # Restart with SmartBox Pro hardware mode
            restart_req = RestartRequest(mode=BackboneMode.SMARTBOX_PRO)
            client.restart(restart_req)
            sleep(2)  # Simulate some time before restart
            print("✅ System restarted with SmartBox Pro mode")
        except Exception as e:
            print(f"❌ Restart failed: {e}")

        print("\\n3. Restarting with simulation mode...")
        try:
            # Restart with simulation mode for testing
            sim_restart = RestartRequest(mode=BackboneMode.SMARTBOX_SIM_GEN_SINE)
            client.restart(sim_restart)
            sleep(2)  # Simulate some time before restart
            print("✅ System restarted with simulation sine wave generation")
        except Exception as e:
            print(f"❌ Restart failed: {e}")

        print("\\n4. Restarting with XDAQ recording mode...")
        try:
            # Restart with XDAQ recording hardware
            xdaq_restart = RestartRequest(mode=BackboneMode.XDAQ_ONE_REC)
            client.restart(xdaq_restart)
            sleep(2)  # Simulate some time before restart
            print("✅ System restarted with XDAQ ONE recording mode")
        except Exception as e:
            print(f"❌ Restart failed: {e}")

        print("\\n=== Available Hardware Modes ===")
        print("SmartBox modes:")
        print(f"  - SMARTBOX_PRO: {BackboneMode.SMARTBOX_PRO}")
        print(f"  - SMARTBOX_CLASSIC: {BackboneMode.SMARTBOX_CLASSIC}")
        print("\\nSimulation modes:")
        print(f"  - SINE_GEN: {BackboneMode.SMARTBOX_SIM_GEN_SINE}")
        print(f"  - SPIKES_GEN: {BackboneMode.SMARTBOX_SIM_GEN_SPIKES}")
        print("\\nXDAQ modes:")
        print(f"  - XDAQ_ONE_REC: {BackboneMode.XDAQ_ONE_REC}")
        print(f"  - XDAQ_CORE_REC: {BackboneMode.XDAQ_CORE_REC}")
        print("\\n(See BackboneMode enum for complete list)")


if __name__ == "__main__":
    main()
