import json
import uuid
import datetime
from dataclasses import asdict, is_dataclass
from typing import Any
from google.cloud import pubsub_v1 # type: ignore
from ..model import Run, Span, Correlation, DataExchange
from .protocols import EventsStore, DataExchangeStore

def _json_serializer(obj: Any) -> Any:
    if isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    if is_dataclass(obj):
        return asdict(obj)
    raise TypeError(f"Type {type(obj)} not serializable")

class PubSubEventsStore(EventsStore):
    def __init__(self, project_id: str, topic_prefix: str = "obs"):
        self.publisher = pubsub_v1.PublisherClient()
        self.project_id = project_id
        
        # Topic names
        self.topic_run = f"projects/{project_id}/topics/{topic_prefix}-run"
        self.topic_span = f"projects/{project_id}/topics/{topic_prefix}-span"
        self.topic_log = f"projects/{project_id}/topics/{topic_prefix}-log"

    def _publish(self, topic: str, type_: str, payload: dict) -> None:
        message_id = str(uuid.uuid4())
        envelope = {
            "message_id": message_id,
            "type": type_,
            "emitted_at": datetime.datetime.utcnow().isoformat() + "Z",
            "payload": payload
        }
        data_str = json.dumps(envelope, default=_json_serializer)
        data = data_str.encode("utf-8")
        
        # Publish asynchronously
        self.publisher.publish(topic, data)

    def write_run(self, run: Run) -> None:
        self._publish(self.topic_run, "RUN", asdict(run))

    def write_span(self, span: Span) -> None:
        self._publish(self.topic_span, "SPAN", asdict(span))

    def write_log(self, correlation: Correlation, severity: str, message: str, attrs: dict | None = None) -> None:
        payload = {
            "correlation": asdict(correlation),
            "severity": severity,
            "message": message,
            "attrs": attrs
        }
        self._publish(self.topic_log, "LOG", payload)


class PubSubDataExchangeStore(DataExchangeStore):
    def __init__(self, project_id: str, topic_name: str = "obs-data-exchange"):
        self.publisher = pubsub_v1.PublisherClient()
        self.topic_path = f"projects/{project_id}/topics/{topic_name}"

    def write_data_exchange(self, dx: DataExchange) -> None:
        message_id = str(uuid.uuid4())
        envelope = {
            "message_id": message_id,
            "type": "DATA_EXCHANGE",
            "emitted_at": datetime.datetime.utcnow().isoformat() + "Z",
            "payload": asdict(dx)
        }
        data_str = json.dumps(envelope, default=_json_serializer)
        data = data_str.encode("utf-8")
        
        self.publisher.publish(self.topic_path, data)
