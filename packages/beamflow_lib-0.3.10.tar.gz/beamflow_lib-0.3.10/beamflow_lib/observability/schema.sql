-- 1. Run Events Table
CREATE TABLE IF NOT EXISTS `observability.run_events` (
    event_id STRING NOT NULL,
    event_time TIMESTAMP,
    tenant_id STRING,
    correlation_integration STRING,
    integration_pipeline STRING,
    run_id STRING,
    artifact_id STRING,
    env_snapshot_id STRING,
    event_type STRING,
    status STRING,
    trace_id STRING,
    span_id STRING,
    tags JSON,
    attrs JSON
)
PARTITION BY DATE(event_time)
CLUSTER BY tenant_id, run_id;

-- 2. Span Facts Table
CREATE TABLE IF NOT EXISTS `observability.span_facts` (
    event_id STRING,
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    tenant_id STRING,
    correlation_integration STRING,
    integration_pipeline STRING,
    run_id STRING,
    trace_id STRING,
    span_id STRING,
    parent_span_id STRING,
    step_key STRING,
    attempt INT64,
    name STRING,
    status STRING,
    error_summary STRING,
    tags JSON,
    attrs JSON
)
PARTITION BY DATE(end_time)
CLUSTER BY tenant_id, run_id, trace_id, step_key;

-- 3. Log Events Table
CREATE TABLE IF NOT EXISTS `observability.log_events` (
    event_id STRING,
    time TIMESTAMP,
    tenant_id STRING,
    correlation_integration STRING,
    integration_pipeline STRING,
    run_id STRING,
    trace_id STRING,
    span_id STRING,
    step_key STRING,
    attempt INT64,
    severity STRING,
    message STRING,
    tags JSON,
    attrs JSON
)
PARTITION BY DATE(time)
CLUSTER BY tenant_id, run_id, trace_id;


-- 4. Data Exchange Table
CREATE TABLE IF NOT EXISTS `observability.data_exchange` (
    id STRING NOT NULL,
    event_id STRING,
    tenant_id STRING,
    correlation_integration STRING,
    integration_pipeline STRING,
    run_id STRING,
    trace_id STRING,
    span_id STRING,
    parent_span_id STRING,
    step_key STRING,
    correlation_attempt INT64,
    
    integration STRING,
    channel STRING,
    operation STRING,
    remote_system STRING,
    address STRING,
    
    occurred_at TIMESTAMP,
    completed_at TIMESTAMP,
    state STRING,
    attempt_num INT64 DEFAULT 1,
    retry_of_id STRING,
    duration_ms INT64,
    
    http_method STRING,
    status_code INT64,
    
    request_payload_ref STRING,
    response_payload_ref STRING,
    request_content_type STRING,
    response_content_type STRING,
    request_size_bytes INT64,
    response_size_bytes INT64,
    
    tags JSON,
    attrs JSON
)
PARTITION BY DATE(occurred_at)
CLUSTER BY tenant_id, run_id, integration, channel;

-- 5. Record Links Table
CREATE TABLE IF NOT EXISTS `observability.record_links` (
    tenant_id STRING NOT NULL,
    integration STRING,
    pipeline STRING,
    run_id STRING,
    trace_id STRING,
    span_id STRING,
    record_key STRING NOT NULL,
    event_time TIMESTAMP NOT NULL,
    kind STRING NOT NULL,
    source STRING
)
PARTITION BY DATE(event_time)
CLUSTER BY tenant_id, record_key, run_id;
