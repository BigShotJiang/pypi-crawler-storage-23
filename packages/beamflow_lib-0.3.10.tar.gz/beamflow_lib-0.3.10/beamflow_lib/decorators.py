import functools
import inspect
import asyncio
from typing import Any, Callable, Optional, TypeVar, Awaitable, Union, Protocol, Mapping
from .context import integration_context, current_context, IntegrationContext
from opentelemetry import trace
from .queue.backend import Schedule, get_backend, register_task_schedule
from .observability.ingestion import (
    record_run_started, record_run_ended, record_run_scheduled,
    record_span_started, record_span_ended
)


def get_tracer():
    """Return a tracer for the framework."""
    return trace.get_tracer("integrator-framework")

T = TypeVar("T")

class JobHandle(Protocol):
    id: str
    tags: Mapping[str, Any]
    def status(self) -> str: ...
    async def result(self, timeout: Optional[float] = None) -> Any: ...
    def cancel(self) -> bool: ...

def integration_step(
    *,
    integration: str,
    integration_pipeline: str,
    name: Optional[str] = None,
    tags: Optional[Mapping[str, Any]] = None,
):
    """
    Decorator for an immediate integration step.
    Always creates/joins context and a span.
    """
    def decorator(func: Callable[..., Any]):
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            # Check if this is a new run or a sub-step
            parent = current_context()
            is_new_run = parent is None
            
            span_name = f"{integration_pipeline}.{name or func.__name__}"
            tracer = get_tracer()
            
            with integration_context(
                integration=integration, 
                integration_pipeline=integration_pipeline,
                tags=tags
            ):
                ctx = current_context()
                
                # Observability: Record start
                start_time = asyncio.get_event_loop().time() # Roughly
                from datetime import datetime, UTC
                wall_start = datetime.now(UTC)

                if is_new_run:
                    await record_run_started(correlation=ctx.corelation)
                else:
                    await record_span_started(name=span_name, correlation=ctx.corelation)

                with tracer.start_as_current_span(
                    span_name,
                    attributes={
                        "fw.integration": ctx.integration,
                        "fw.pipeline": ctx.integration_pipeline,
                        "fw.run_id": ctx.run_id,
                        "code.function": func.__name__,
                        **{f"tag.{k}": v for k, v in ctx.tags.items()}
                    }
                ):
                    status = "SUCCEEDED"
                    error = None
                    try:
                        if inspect.iscoroutinefunction(func):
                            return await func(*args, **kwargs)
                        else:
                            return func(*args, **kwargs)
                    except Exception as e:
                        status = "FAILED"
                        error = str(e)
                        raise
                    finally:
                        # Observability: Record end
                        if is_new_run:
                            await record_run_ended(status=status, correlation=ctx.corelation)
                        else:
                            await record_span_ended(
                                name=span_name, 
                                status="OK" if status == "SUCCEEDED" else "ERROR", 
                                correlation=ctx.corelation,
                                error_summary=error
                            )

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            tracer = get_tracer()
            span_name = f"{integration_pipeline}.{name or func.__name__}"
            
            parent = current_context()
            is_new_run = parent is None

            with integration_context(
                integration=integration, 
                integration_pipeline=integration_pipeline,
                tags=tags
            ):
                ctx = current_context()
                
                # Sync observability events (we are in sync wrapper)
                # Note: record_* functions are async, but they use AsyncManager 
                # which offloads to thread pool. We can fire and forget if we don't await.
                # However, for robustness in CLI/Sync scripts we might want to block?
                # For now let's fire and forget using asyncio if loop exists, else maybe block?
                # Actually record_* functions ALREADY create tasks if EVENTUAL.
                # But here we are in sync code. Let's wrap in a helper.
                def _fire_and_forget(coro):
                    try:
                        loop = asyncio.get_event_loop()
                        if loop.is_running():
                            loop.create_task(coro)
                        else:
                            loop.run_until_complete(coro)
                    except RuntimeError:
                        asyncio.run(coro)

                if is_new_run:
                    _fire_and_forget(record_run_started(correlation=ctx.corelation))
                else:
                    _fire_and_forget(record_span_started(name=span_name, correlation=ctx.corelation))

                with tracer.start_as_current_span(
                    span_name,
                    attributes={
                        "fw.integration": ctx.integration,
                        "fw.pipeline": ctx.integration_pipeline,
                        "fw.run_id": ctx.run_id,
                        "code.function": func.__name__,
                        **{f"tag.{k}": v for k, v in ctx.tags.items()}
                    }
                ):
                    status = "SUCCEEDED"
                    error = None
                    try:
                        return func(*args, **kwargs)
                    except Exception as e:
                        status = "FAILED"
                        error = str(e)
                        raise
                    finally:
                        if is_new_run:
                            _fire_and_forget(record_run_ended(status=status, correlation=ctx.corelation))
                        else:
                            _fire_and_forget(record_span_ended(
                                name=span_name, 
                                status="OK" if status == "SUCCEEDED" else "ERROR", 
                                correlation=ctx.corelation,
                                error_summary=error
                            ))

        return async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper

    return decorator

class TaskWrapper:
    def __init__(self, func: Callable, metadata: dict):
        self.func = func
        self.metadata = metadata
        self._backend_handler = None  # Lazily populated by the backend if needed
        functools.update_wrapper(self, func)
        
        # Register task for lazy backend configuration
        from .queue.backend import register_task_wrapper
        register_task_wrapper(self)
        
        # If a default schedule is provided, try to register it with the backend.
        if "default_schedule" in self.metadata and self.metadata["default_schedule"]:
            register_task_schedule(
                self,  # Pass the wrapper itself so the backend can attach schedules to the actor
                self.metadata["default_schedule"],
                tags=self.metadata.get("tags")
            )

    async def run(self, *args, **kwargs) -> Any:
        """Execute immediately in-process."""
        tracer = get_tracer()
        span_name = f"{self.metadata['pipeline']}.{self.metadata.get('name') or self.func.__name__}"
        
        parent = current_context()
        is_subtask = parent is not None

        with integration_context(
            integration=self.metadata['integration'], 
            integration_pipeline=self.metadata['pipeline'],
            tags=self.metadata.get("tags")
        ):
            ctx = current_context()
            
            if not is_subtask:
                await record_run_started(correlation=ctx.corelation)
            else:
                await record_span_started(name=span_name, correlation=ctx.corelation)

            with tracer.start_as_current_span(
                span_name,
                attributes={
                    "fw.integration": ctx.integration,
                    "fw.pipeline": ctx.integration_pipeline,
                    "fw.run_id": ctx.run_id,
                    "code.function": self.func.__name__,
                    **{f"tag.{k}": v for k, v in ctx.tags.items()}
                }
            ):
                status = "SUCCEEDED"
                error = None
                try:
                    if inspect.iscoroutinefunction(self.func):
                        return await self.func(*args, **kwargs)
                    else:
                        return self.func(*args, **kwargs)
                except Exception as e:
                    status = "FAILED"
                    error = str(e)
                    raise
                finally:
                    if not is_subtask:
                        await record_run_ended(status=status, correlation=ctx.corelation)
                    else:
                        await record_span_ended(
                            name=span_name, 
                            status="OK" if status == "SUCCEEDED" else "ERROR", 
                            correlation=ctx.corelation,
                            error_summary=error
                        )

    def submit(self, *args, **kwargs) -> JobHandle:
        """Enqueue to technical backend."""
        from .queue.backend import get_backend
        backend = get_backend()
        
        ctx = current_context()
        is_subtask = ctx is not None
        
        # Record scheduled event (only for root runs? No, user says "any time scheduled... unless sub task treat as span")
        # If it's a subtask, we might want to record a span start for "ENQUEUED"? 
        # But let's stick to the user's "treat as span" for EXECUTION.
        # For scheduling, we can always record a RunEvent(SCHEDULED) but maybe with a flag?
        # Actually, let's just record RunEvent(SCHEDULED) for everyone for now, OR follow the same run/span split.
        
        def _fire(coro):
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(coro)
                else:
                    loop.run_until_complete(coro)
            except RuntimeError:
                asyncio.run(coro)
        
        if not ctx:
             with integration_context(
                integration=self.metadata['integration'],
                integration_pipeline=self.metadata['pipeline'],
                tags=self.metadata.get("tags")
             ) as tmp_ctx:
                 _fire(record_run_scheduled(correlation=tmp_ctx.corelation))
                 ctx = tmp_ctx
        else:
            # If subtask, we could record a span, but SCHEDULED event is traditionally a RunEvent.
            # Let's just record it anyway.
            _fire(record_run_scheduled(correlation=ctx.corelation))
 
        return backend.submit(
            self._backend_handler or self.func, 
            args, 
            kwargs, 
            context=ctx,
            integration=self.metadata['integration'],
            pipeline=self.metadata['pipeline'],
            tags={**(self.metadata.get("tags") or {}), "fw.is_subtask": is_subtask}
        )

    def schedule(self, eta_or_delay: Union[int, float, Any], *args, **kwargs) -> JobHandle:
        """Schedule for future execution."""
        from .queue.backend import get_backend
        backend = get_backend()
        
        ctx = current_context()
        is_subtask = ctx is not None

        def _fire(coro):
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(coro)
                else:
                    loop.run_until_complete(coro)
            except RuntimeError:
                asyncio.run(coro)
        
        if not ctx:
             with integration_context(
                integration=self.metadata['integration'],
                integration_pipeline=self.metadata['pipeline'],
                tags=self.metadata.get("tags")
             ) as tmp_ctx:
                 _fire(record_run_scheduled(correlation=tmp_ctx.corelation, attrs={"delay": eta_or_delay}))
                 ctx = tmp_ctx
        else:
            _fire(record_run_scheduled(correlation=ctx.corelation, attrs={"delay": eta_or_delay}))
 
        return backend.schedule(
            self._backend_handler or self.func,
            args,
            kwargs,
            eta_or_delay=eta_or_delay,
            context=ctx,
            integration=self.metadata['integration'],
            pipeline=self.metadata['pipeline'],
            tags={**(self.metadata.get("tags") or {}), "fw.is_subtask": is_subtask}
        )

    def __call__(self, *args, **kwargs) -> JobHandle:
        return self.submit(*args, **kwargs)

def integration_task(
    *,
    integration: str,
    integration_pipeline: str,
    queue: Optional[str] = None,
    name: Optional[str] = None,
    tags: Optional[Mapping[str, Any]] = None,
    default_schedule: Optional[Schedule] = None,
):
    """
    Decorator for a task that can be executed inline or submitted to a queue.
    """
    def decorator(func: Callable[..., Any]):
        return TaskWrapper(func, {
            "integration": integration,
            "pipeline": integration_pipeline,
            "queue": queue,
            "name": name,
            "tags": tags,
            "default_schedule": default_schedule
        })
    return decorator
