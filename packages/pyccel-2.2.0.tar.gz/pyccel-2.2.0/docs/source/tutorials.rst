Tutorials
=======================

This documentation demonstrates a few cases where Pyccel is useful in the real world.

.. toctree::
   :maxdepth: 1
   :caption: Tutorials:

   tutorials/testing_kernels.rst
