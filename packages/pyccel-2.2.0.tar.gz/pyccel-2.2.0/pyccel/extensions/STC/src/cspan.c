#define i_implement
#include "../include/stc/cspan.h"
