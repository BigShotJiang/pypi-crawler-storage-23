#define i_implement
#include "../include/stc/utf8.h"
#define STC_CSTR_UTF8
#include "../include/stc/cstr.h"
