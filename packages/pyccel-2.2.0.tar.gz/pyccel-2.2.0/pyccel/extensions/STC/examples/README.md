Examples
========
This folder contains various examples of STC container usage.

