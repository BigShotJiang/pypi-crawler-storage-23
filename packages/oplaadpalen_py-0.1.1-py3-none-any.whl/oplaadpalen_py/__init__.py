"""Oplaadpalen.nl Python Library - EV Charging Station API Client."""

__version__ = "0.1.2"
__author__ = "Willem Oldemans"
__description__ = "Python client for Oplaadpalen.nl EV charging stations API"

from .client import OplaadpalenClient

__all__ = ["OplaadpalenClient"]
