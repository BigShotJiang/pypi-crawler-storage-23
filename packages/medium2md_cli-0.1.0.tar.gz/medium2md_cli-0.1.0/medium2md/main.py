def main():
    print("Hello from medium2md!")


if __name__ == "__main__":
    main()
