import os
import pathlib
import subprocess

assets = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")


def test_alifestd_downsample_tips_lineage_asexual_cli_help():
    subprocess.run(  # nosec B603
        [
            "python3",
            "-m",
            "phyloframe.legacy._alifestd_downsample_tips_lineage_asexual",
            "--help",
        ],
        check=True,
    )


def test_alifestd_downsample_tips_lineage_asexual_cli_version():
    subprocess.run(  # nosec B603
        [
            "python3",
            "-m",
            "phyloframe.legacy._alifestd_downsample_tips_lineage_asexual",
            "--version",
        ],
        check=True,
    )


def test_alifestd_downsample_tips_lineage_asexual_cli_csv():
    output_file = "/tmp/phyloframe_alifestd_downsample_tips_lineage_asexual.csv"  # nosec B108
    pathlib.Path(output_file).unlink(missing_ok=True)
    subprocess.run(  # nosec B603
        [
            "python3",
            "-m",
            "phyloframe.legacy._alifestd_downsample_tips_lineage_asexual",
            "-n",
            "1",
            "--criterion-delta",
            "origin_time",
            "--criterion-target",
            "origin_time",
            output_file,
        ],
        check=True,
        input=(f"{assets}/nk_ecoeaselection-workingformat.csv".encode()),
    )
    assert os.path.exists(output_file)


def test_alifestd_downsample_tips_lineage_asexual_cli_parquet():
    output_file = "/tmp/phyloframe_alifestd_downsample_tips_lineage_asexual.pqt"  # nosec B108
    pathlib.Path(output_file).unlink(missing_ok=True)
    subprocess.run(  # nosec B603
        [
            "python3",
            "-m",
            "phyloframe.legacy._alifestd_downsample_tips_lineage_asexual",
            "-n",
            "1",
            output_file,
        ],
        check=True,
        input=(f"{assets}/nk_ecoeaselection-workingformat.csv".encode()),
    )
    assert os.path.exists(output_file)


def test_alifestd_downsample_tips_lineage_asexual_cli_ignore_topological_sensitivity():  # noqa: E501
    output_file = "/tmp/phyloframe_alifestd_downsample_tips_lineage_asexual_ignore.csv"  # nosec B108
    pathlib.Path(output_file).unlink(missing_ok=True)
    subprocess.run(  # nosec B603
        [
            "python3",
            "-m",
            "phyloframe.legacy._alifestd_downsample_tips_lineage_asexual",
            "-n",
            "1",
            "--ignore-topological-sensitivity",
            output_file,
        ],
        check=True,
        input=(f"{assets}/nk_ecoeaselection-workingformat.csv".encode()),
    )
    assert os.path.exists(output_file)


def test_alifestd_downsample_tips_lineage_asexual_cli_drop_topological_sensitivity():  # noqa: E501
    output_file = "/tmp/phyloframe_alifestd_downsample_tips_lineage_asexual_drop.csv"  # nosec B108
    pathlib.Path(output_file).unlink(missing_ok=True)
    subprocess.run(  # nosec B603
        [
            "python3",
            "-m",
            "phyloframe.legacy._alifestd_downsample_tips_lineage_asexual",
            "-n",
            "1",
            "--drop-topological-sensitivity",
            output_file,
        ],
        check=True,
        input=(f"{assets}/nk_ecoeaselection-workingformat.csv".encode()),
    )
    assert os.path.exists(output_file)
