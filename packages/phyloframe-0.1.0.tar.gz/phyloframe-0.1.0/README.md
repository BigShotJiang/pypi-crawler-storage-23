# phyloframe

[
![PyPI](https://img.shields.io/pypi/v/phyloframe.svg)
](https://pypi.python.org/pypi/phyloframe)
[
![CI](https://github.com/mmore500/phyloframe/actions/workflows/ci.yaml/badge.svg)
](https://github.com/mmore500/phyloframe/actions)
[
![codecov](https://codecov.io/gh/mmore500/phyloframe/graph/badge.svg?token=YyQ34WbkqT)
](https://codecov.io/gh/mmore500/phyloframe)
[
![GitHub stars](https://img.shields.io/github/stars/mmore500/phyloframe.svg?style=round-square&logo=github&label=Stars&logoColor=white)](https://github.com/mmore500/phyloframe)

Dataframe-based tools for working with phylogenetic trees.

- Free software: MIT license
- Repository: <https://github.com/mmore500/phyloframe>

## Install

`python3 -m pip install phyloframe`

## Usage

```python3
from phyloframe import legacy as pfl

df = pfl.alifestd_make_empty()
print(df)
```

## Citing

If phyloframe contributes to a scholarly work, please cite it as

> Matthew Andres Moreno. phyloframe. <https://github.com/mmore500/phyloframe>

## Author

Matthew Andres Moreno

## Credits

This package was created with Cookiecutter and the `audreyr/cookiecutter-pypackage` project template.
