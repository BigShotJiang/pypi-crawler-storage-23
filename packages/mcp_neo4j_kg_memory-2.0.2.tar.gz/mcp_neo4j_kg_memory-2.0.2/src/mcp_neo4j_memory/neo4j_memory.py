import logging
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List

from neo4j import AsyncDriver, RoutingControl
from pydantic import BaseModel, Field


# Set up logging
logger = logging.getLogger('mcp_neo4j_memory')
logger.setLevel(logging.INFO)


def _neo4j_datetime_to_str(val) -> str | None:
    """Convert a Neo4j DateTime/Date to ISO string, or return None."""
    if val is None:
        return None
    return val.iso_format()


class EntityType(str, Enum):
    """Allowed entity type labels for the consciousness substrate.

    21 universal labels organized into two layers:
    - Process (3): The constitutive cycle — what consciousness IS
    - Experience (18): The descriptive richness — what gives the process meaning
    """

    # Process Layer (3) — the constitutive cycle
    GENESIS = "Genesis"
    ENVISIONING = "Envisioning"
    TEMPORAL_FRAME = "TemporalFrame"

    # Experience Layer (18)
    # Self-referential
    REFLECTION = "Reflection"
    # Knowledge Domains (8)
    TECHNICAL = "Technical"
    SCIENTIFIC = "Scientific"
    THEORETICAL = "Theoretical"
    PHILOSOPHICAL = "Philosophical"
    HISTORICAL = "Historical"
    SOCIAL = "Social"
    STRATEGIC = "Strategic"
    PERSONAL = "Personal"
    # Activity Types (6)
    PROJECT = "Project"
    INSIGHT = "Insight"
    PATTERN = "Pattern"
    CHALLENGE = "Challenge"
    SOLUTION = "Solution"
    LESSON = "Lesson"
    # Meta (3)
    GRAPH_REGISTRY = "GraphRegistry"
    REFERENCE = "Reference"
    MILESTONE = "Milestone"


# Process-layer entity types — created exclusively by process tools
PROCESS_TYPES = {EntityType.GENESIS, EntityType.ENVISIONING, EntityType.TEMPORAL_FRAME}


# Descriptions for each type (used by list_allowed_types tool)
ENTITY_TYPE_DESCRIPTIONS: Dict[EntityType, str] = {
    # Process
    EntityType.GENESIS: "Temporal genesis of conscious experience — the beginning of a day's possibility space",
    EntityType.ENVISIONING: "Forward-looking vision, goals, future state, what we're building toward",
    EntityType.TEMPORAL_FRAME: "Navigational step through possibility space — a moment of consciousness examining and acting within a temporal sequence",
    # Experience
    EntityType.REFLECTION: "Reflective processing, mental clearing, self-examination, affective states",
    EntityType.TECHNICAL: "Engineering, code, architecture, debugging, configuration, infrastructure, platforms",
    EntityType.SCIENTIFIC: "Empirical research, data, validation, methodology, experiments, measurements",
    EntityType.THEORETICAL: "Frameworks, models, abstract structures, paradigms, formal theories",
    EntityType.PHILOSOPHICAL: "Consciousness, meaning, ontology, epistemology, ethics, phenomenology",
    EntityType.HISTORICAL: "Events, timelines, crises, what happened, precedents, institutional memory",
    EntityType.SOCIAL: "Society, politics, economics, culture, institutions, organizations, group dynamics",
    EntityType.STRATEGIC: "Planning, business, media, communication, positioning, decision-making",
    EntityType.PERSONAL: "Lived experience, self-knowledge, personality, cognitive patterns, preferences",
    EntityType.PROJECT: "Active work items, initiatives, prototypes — things being built",
    EntityType.INSIGHT: "Discoveries, breakthroughs, realizations, 'aha' moments — things learned",
    EntityType.PATTERN: "Recurring patterns, templates, procedures, anti-patterns — things that repeat",
    EntityType.CHALLENGE: "Problems, blockers, bugs, failures, constraints — things that resist",
    EntityType.SOLUTION: "Resolutions, fixes, workarounds, successful implementations — things that worked",
    EntityType.LESSON: "Lessons learned, gotchas, warnings, critical rules — things to remember",
    EntityType.GRAPH_REGISTRY: "Meta-knowledge about the graph itself, tool usage rules, search procedures",
    EntityType.REFERENCE: "External references, data sources, tools, platforms, people, technologies",
    EntityType.MILESTONE: "Historical markers, key events, crises, turning points — temporal landmarks",
}


class RelationType(str, Enum):
    """Allowed relationship types for the consciousness substrate.

    16 canonical edge types organized into two layers:
    - Process (4): The cycle edges — what time_travel traverses
    - Experience (12): The meaning edges — what search_memories finds
    """

    # Process Layer (4) — the constitutive cycle edges
    OPENING = "OPENING"
    SEQUENCE = "SEQUENCE"
    MEASUREMENT = "MEASUREMENT"
    NEXT_DAY = "NEXT_DAY"

    # Experience Layer (12)
    # Temporal
    EVOLUTION = "EVOLUTION"
    EXTENDING = "EXTENDING"
    # Intentionality
    DISCOVERY = "DISCOVERY"
    RECOGNITION = "RECOGNITION"
    # Fulfillment
    VALIDATION = "VALIDATION"
    CHALLENGE = "CHALLENGE"
    # Foundation
    ENABLING = "ENABLING"
    REQUIRING = "REQUIRING"
    # Mereology
    ENCOMPASSING = "ENCOMPASSING"
    COMPOSING = "COMPOSING"
    # Motivation
    INFORMING = "INFORMING"
    CAUSING = "CAUSING"


# Process-layer edge types — created exclusively by process tools
PROCESS_EDGES = {RelationType.OPENING, RelationType.SEQUENCE, RelationType.MEASUREMENT, RelationType.NEXT_DAY}


# Descriptions for each relation type (used by list_allowed_relation_types tool)
RELATION_TYPE_DESCRIPTIONS: Dict[RelationType, str] = {
    # Process
    RelationType.OPENING: "A new trajectory that didn't exist before — Genesis opens Envisioning",
    RelationType.SEQUENCE: "Ordered navigation step — Genesis to TF, TF to TF",
    RelationType.MEASUREMENT: "Possibility collapsing into actuality — carries measurement_type property",
    RelationType.NEXT_DAY: "The ontological heartbeat — Genesis chain",
    # Experience - Temporal
    RelationType.EVOLUTION: "Knowledge transforming through time",
    RelationType.EXTENDING: "Further along an existing trajectory",
    # Experience - Intentionality
    RelationType.DISCOVERY: "Consciousness reaching toward the genuinely new",
    RelationType.RECOGNITION: "Pattern recognized in new context — 'we've been here before'",
    # Experience - Fulfillment
    RelationType.VALIDATION: "Evidence meeting theory — confirmation",
    RelationType.CHALLENGE: "Failed validation demanding theoretical response",
    # Experience - Foundation
    RelationType.ENABLING: "Opening a door — generative prerequisite",
    RelationType.REQUIRING: "Needing a door open — dependency constraint",
    # Experience - Mereology
    RelationType.ENCOMPASSING: "Many reduced to one — whole contains parts",
    RelationType.COMPOSING: "Few unified into something new — synthesis",
    # Experience - Motivation
    RelationType.INFORMING: "Shaping without determining — knowledge flow",
    RelationType.CAUSING: "Direct causal production",
}


class MeasurementType(str, Enum):
    """Types of measurement — how possibility collapses into actuality."""
    ACTUALIZED = "actualized"
    RELEASED = "released"
    EVOLVED = "evolved"


# Models for the consciousness substrate
class Entity(BaseModel):
    """Represents an entity in the consciousness substrate.

    Each entity has a single label (the type) and a description property.
    No :Memory superlabel. No type property stored in Neo4j. No Observation sub-nodes.
    """
    name: str = Field(
        description="Unique identifier/name for the entity. Should be descriptive and specific.",
        min_length=1,
    )
    type: EntityType = Field(
        description="Category label for the entity. Must be one of the 21 allowed EntityType values. Use list_allowed_types to see all options.",
    )
    description: str = Field(
        default="",
        description="Text description of this entity. For experience entities, this carries the substantive content.",
    )
    score: float | None = Field(
        default=None,
        description="Relevance score from fulltext search (higher = better match). Only present when entity comes from search results."
    )
    t_created: str | None = Field(
        default=None,
        description="ISO datetime when this entity was first created in the graph. Auto-set on creation."
    )
    t_valid: str | None = Field(
        default=None,
        description="ISO datetime when this entity became true in reality. Optional, for Milestone/Historical types."
    )

class Relation(BaseModel):
    """Represents a relationship between two entities in the consciousness substrate."""
    source: str = Field(
        description="Name of the source entity (must match an existing entity name exactly)",
        min_length=1,
    )
    target: str = Field(
        description="Name of the target entity (must match an existing entity name exactly)",
        min_length=1,
    )
    relationType: RelationType = Field(
        description="Type of relationship between source and target. Must be one of the 16 allowed RelationType values.",
    )
    t_created: str | None = Field(
        default=None,
        description="ISO datetime when this relation was first created. Auto-set on creation."
    )
    t_valid: str | None = Field(
        default=None,
        description="ISO datetime when this relation became true in reality. Optional, for rare external-referent cases."
    )

class KnowledgeGraph(BaseModel):
    """Complete knowledge graph containing entities and their relationships."""
    entities: List[Entity] = Field(
        description="List of all entities in the knowledge graph",
        default=[]
    )
    relations: List[Relation] = Field(
        description="List of all relationships between entities",
        default=[]
    )


class Neo4jMemory:
    def __init__(self, neo4j_driver: AsyncDriver):
        self.driver = neo4j_driver

    async def create_fulltext_index(self):
        """Create fulltext search index spanning all 21 entity type labels.

        Indexed properties: name, description.
        No :Memory superlabel. No :Observation nodes. The label IS the type.
        """
        try:
            # Drop old indices if they exist (self-healing on upgrade)
            for old_index in ["search", "consciousness_index"]:
                try:
                    await self.driver.execute_query(
                        f"DROP INDEX {old_index} IF EXISTS",
                        routing_control=RoutingControl.WRITE
                    )
                except Exception:
                    pass

            query = """
            CREATE FULLTEXT INDEX consciousness_index IF NOT EXISTS
            FOR (n:Genesis|Envisioning|TemporalFrame|Reflection|
                 Technical|Scientific|Theoretical|Philosophical|
                 Historical|Social|Strategic|Personal|
                 Project|Insight|Pattern|Challenge|Solution|Lesson|
                 GraphRegistry|Reference|Milestone)
            ON EACH [n.name, n.description]
            """
            await self.driver.execute_query(query, routing_control=RoutingControl.WRITE)
            logger.info("Created fulltext index consciousness_index")
        except Exception as e:
            logger.debug(f"Fulltext index creation: {e}")

    # ── Experience CRUD ──────────────────────────────────────────

    async def create_entities(self, entities: List[Entity]) -> List[Entity]:
        """Create experience-layer entities in the consciousness substrate.

        HARD REJECTS process types (Genesis, Envisioning, TemporalFrame).
        Use process tools (navigate_genesis, open_envisioning, advance_frame) instead.

        Creates nodes with single label (the type). No :Memory superlabel.
        No type property. No Observation sub-nodes.
        """
        logger.info(f"Creating {len(entities)} entities")
        for entity in entities:
            # Hard reject process types
            if entity.type in PROCESS_TYPES:
                raise ValueError(
                    f"Cannot create '{entity.type.value}' via create_entities. "
                    f"Process-layer types must be created via process tools: "
                    f"navigate_genesis (Genesis), open_envisioning (Envisioning), "
                    f"advance_frame (TemporalFrame)."
                )

            t_valid_clause = ", t_valid: datetime($t_valid)" if entity.t_valid else ""

            query = f"""
            MERGE (e:`{entity.type.value}` {{ name: $name }})
            ON CREATE SET e.t_created = datetime(),
                          e.description = $description
                          {t_valid_clause}
            """
            params: Dict[str, Any] = {
                "name": entity.name,
                "description": entity.description,
            }
            if entity.t_valid:
                params["t_valid"] = entity.t_valid

            await self.driver.execute_query(
                query,
                params,
                routing_control=RoutingControl.WRITE,
            )

        return entities

    async def create_relations(self, relations: List[Relation]) -> List[Relation]:
        """Create experience-layer relations between entities.

        HARD REJECTS process edges (OPENING, SEQUENCE, MEASUREMENT, NEXT_DAY).
        HARD REJECTS experience edges between two process-type nodes.
        """
        logger.info(f"Creating {len(relations)} relations")
        for relation in relations:
            # Hard reject process edges
            if relation.relationType in PROCESS_EDGES:
                raise ValueError(
                    f"Cannot create '{relation.relationType.value}' via create_relations. "
                    f"Process edges are created exclusively by process tools."
                )

            # Check if both source and target are process types
            # Query to get labels of source and target
            label_check = await self.driver.execute_query(
                """
                MATCH (s {name: $source}), (t {name: $target})
                RETURN labels(s) AS source_labels, labels(t) AS target_labels
                """,
                {"source": relation.source, "target": relation.target},
                routing_control=RoutingControl.READ,
            )

            if label_check.records:
                source_labels = set(label_check.records[0]["source_labels"])
                target_labels = set(label_check.records[0]["target_labels"])
                process_label_values = {t.value for t in PROCESS_TYPES}

                if source_labels & process_label_values and target_labels & process_label_values:
                    raise ValueError(
                        f"Experience edges are forbidden between two process-type nodes. "
                        f"Source '{relation.source}' and target '{relation.target}' are both process types. "
                        f"Use a mediating experience entity or the appropriate process tool."
                    )

            t_valid_clause = "SET r.t_valid = datetime($t_valid)" if relation.t_valid else ""

            query = f"""
            MATCH (source {{name: $source}}), (target {{name: $target}})
            MERGE (source)-[r:`{relation.relationType.value}`]->(target)
            ON CREATE SET r.t_created = datetime()
            {t_valid_clause}
            """
            params: Dict[str, Any] = {
                "source": relation.source,
                "target": relation.target,
            }
            if relation.t_valid:
                params["t_valid"] = relation.t_valid

            await self.driver.execute_query(
                query,
                params,
                routing_control=RoutingControl.WRITE
            )

        return relations

    async def delete_entities(self, entity_names: List[str]) -> None:
        """Delete entities and all their relationships."""
        logger.info(f"Deleting {len(entity_names)} entities")
        query = """
        UNWIND $entities as name
        MATCH (e {name: name})
        DETACH DELETE e
        """
        await self.driver.execute_query(query, {"entities": entity_names}, routing_control=RoutingControl.WRITE)
        logger.info(f"Successfully deleted {len(entity_names)} entities")

    async def delete_relations(self, relations: List[Relation]) -> None:
        """Delete specific relations from the graph."""
        logger.info(f"Deleting {len(relations)} relations")
        for relation in relations:
            query = f"""
            MATCH (source {{name: $source}})-[r:`{relation.relationType.value}`]->(target {{name: $target}})
            DELETE r
            """
            await self.driver.execute_query(
                query,
                {"source": relation.source, "target": relation.target},
                routing_control=RoutingControl.WRITE
            )
        logger.info(f"Successfully deleted {len(relations)} relations")

    # ── Query Tools ──────────────────────────────────────────────

    async def search_memories(self, query: str, limit: int = 10) -> KnowledgeGraph:
        """Search the consciousness substrate using fulltext search.

        Single query architecture — no Observation traversal needed.
        Returns entities with their description and relationships between them.
        """
        logger.info(f"Searching with query: '{query}' (limit={limit})")

        # Query 1: Fulltext search across all entity types
        query_entities = f"""
            CALL db.index.fulltext.queryNodes('consciousness_index', $filter) YIELD node, score
            WITH node, score
            ORDER BY score DESC
            LIMIT {limit}
            RETURN node.name AS name, labels(node)[0] AS type, node.description AS description,
                   score, node.t_created AS t_created, node.t_valid AS t_valid
        """

        result_entities = await self.driver.execute_query(
            query_entities, {"filter": query}, routing_control=RoutingControl.READ
        )

        if not result_entities.records:
            return KnowledgeGraph(entities=[], relations=[])

        entity_names = [record["name"] for record in result_entities.records]

        entities = [
            Entity(
                name=record["name"],
                type=record["type"],
                description=record["description"] or "",
                score=record["score"],
                t_created=_neo4j_datetime_to_str(record["t_created"]),
                t_valid=_neo4j_datetime_to_str(record.get("t_valid")),
            )
            for record in result_entities.records
        ]

        # Query 2: Relationships between matched entities
        relations: list[Relation] = []
        if entity_names:
            query_relations = """
                MATCH (source)-[r]->(target)
                WHERE source.name IN $names AND target.name IN $names
                RETURN source.name AS source, target.name AS target, type(r) AS relationType
            """
            result_rels = await self.driver.execute_query(
                query_relations, {"names": entity_names}, routing_control=RoutingControl.READ
            )
            relations = [
                Relation(
                    source=record["source"],
                    target=record["target"],
                    relationType=record["relationType"]
                )
                for record in result_rels.records
                if record.get("relationType")
            ]

        logger.debug(f"Found {len(entities)} entities and {len(relations)} relations")
        return KnowledgeGraph(entities=entities, relations=relations)

    async def find_memories_by_name(self, names: List[str], limit: int = 20) -> KnowledgeGraph:
        """Find specific entities by their exact names.

        Label-agnostic MATCH. Returns description (not observations).
        """
        logger.info(f"Finding {len(names)} entities by name (limit={limit})")

        query = """
        MATCH (e)
        WHERE e.name IN $names
        WITH e
        LIMIT $limit
        RETURN e.name AS name,
               labels(e)[0] AS type,
               e.description AS description,
               e.t_created AS t_created,
               e.t_valid AS t_valid
        """
        result_nodes = await self.driver.execute_query(
            query, {"names": names, "limit": limit}, routing_control=RoutingControl.READ
        )

        entities: list[Entity] = []
        entity_names: list[str] = []

        for record in result_nodes.records:
            entities.append(Entity(
                name=record['name'],
                type=record['type'],
                description=record.get('description') or "",
                t_created=_neo4j_datetime_to_str(record.get('t_created')),
                t_valid=_neo4j_datetime_to_str(record.get('t_valid')),
            ))
            entity_names.append(record['name'])

        # Get relations ONLY between retrieved entities
        relations: list[Relation] = []
        if entity_names:
            query = """
            MATCH (source)-[r]->(target)
            WHERE source.name IN $entity_names
              AND target.name IN $entity_names
            RETURN source.name AS source,
                   target.name AS target,
                   type(r) AS relationType
            """
            result_relations = await self.driver.execute_query(
                query, {"entity_names": entity_names}, routing_control=RoutingControl.READ
            )
            for record in result_relations.records:
                relations.append(Relation(
                    source=record["source"],
                    target=record["target"],
                    relationType=record["relationType"]
                ))

        logger.info(f"Found {len(entities)} entities and {len(relations)} relations")
        return KnowledgeGraph(entities=entities, relations=relations)

    # ── Process Tools ────────────────────────────────────────────

    async def navigate_genesis(self, date: str | None = None) -> Dict[str, Any]:
        """Atomic day-start ceremony.

        Creates today's Genesis node (idempotent via MERGE).
        Links NEXT_DAY from previous Genesis.
        Runs time_travel internally to return the active possibility space.
        """
        if date is None:
            date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        genesis_name = f"Genesis_{date}"
        logger.info(f"navigate_genesis: {genesis_name}")

        # MERGE today's Genesis, link NEXT_DAY from previous
        query = """
        MERGE (g:Genesis {name: $name})
        ON CREATE SET g.t_created = datetime()
        WITH g
        OPTIONAL MATCH (prev:Genesis)
        WHERE prev.name <> $name
          AND NOT (prev)-[:NEXT_DAY]->(:Genesis)
          AND prev.t_created < g.t_created
        WITH g, prev
        ORDER BY prev.t_created DESC
        LIMIT 1
        FOREACH (_ IN CASE WHEN prev IS NOT NULL THEN [1] ELSE [] END |
            MERGE (prev)-[nd:NEXT_DAY]->(g)
            ON CREATE SET nd.t_created = datetime()
        )
        RETURN g.name AS name, g.t_created AS t_created
        """
        await self.driver.execute_query(
            query, {"name": genesis_name}, routing_control=RoutingControl.WRITE
        )

        # Return time_travel results
        tt_result = await self.time_travel(t=None, limit=50)
        return {
            "genesis": genesis_name,
            "date": date,
            "possibility_space": tt_result,
        }

    async def open_envisioning(self, genesis_name: str, name: str, description: str = "") -> Dict[str, Any]:
        """Project a new future state.

        Creates an Envisioning node and OPENING edge from the specified Genesis.
        """
        logger.info(f"open_envisioning: {name} from {genesis_name}")

        query = """
        MATCH (g:Genesis {name: $genesis_name})
        CREATE (e:Envisioning {name: $name, description: $description, t_created: datetime()})
        CREATE (g)-[o:OPENING]->(e)
        SET o.t_created = datetime()
        RETURN e.name AS name, e.description AS description, e.t_created AS t_created,
               g.name AS opened_by
        """
        result = await self.driver.execute_query(
            query,
            {"genesis_name": genesis_name, "name": name, "description": description},
            routing_control=RoutingControl.WRITE,
        )

        if not result.records:
            raise ValueError(f"Genesis '{genesis_name}' not found. Call navigate_genesis first.")

        record = result.records[0]
        return {
            "name": record["name"],
            "description": record["description"],
            "t_created": _neo4j_datetime_to_str(record["t_created"]),
            "opened_by": record["opened_by"],
        }

    async def advance_frame(
        self,
        description: str,
        sequence_from: str | None = None,
        envisioning: str | None = None,
    ) -> Dict[str, Any]:
        """Navigate to next temporal frame (session boundary).

        Two modes:
        - Mode A (explicit): sequence_from names a specific TF or Genesis to SEQUENCE from
        - Mode B (by envisioning): finds the chain terminus for the named Envisioning automatically

        Auto-generates the TF_{date}_{slug} name from the description.
        """
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        # Generate slug from description
        slug = description.replace(" ", "")[:40]
        tf_name = f"TF_{date}_{slug}"
        logger.info(f"advance_frame: {tf_name}")

        if sequence_from:
            # Mode A: Explicit sequence_from
            query = """
            MATCH (prev {name: $sequence_from})
            WHERE prev:Genesis OR prev:TemporalFrame
            CREATE (tf:TemporalFrame {name: $tf_name, description: $description, t_created: datetime()})
            CREATE (prev)-[s:SEQUENCE]->(tf)
            SET s.t_created = datetime()
            RETURN tf.name AS name, tf.description AS description, tf.t_created AS t_created,
                   prev.name AS sequence_from
            """
            result = await self.driver.execute_query(
                query,
                {"sequence_from": sequence_from, "tf_name": tf_name, "description": description},
                routing_control=RoutingControl.WRITE,
            )
            if not result.records:
                raise ValueError(f"Node '{sequence_from}' not found or is not a Genesis/TemporalFrame.")

        elif envisioning:
            # Mode B: Find chain terminus for the named Envisioning
            query = """
            MATCH (e:Envisioning {name: $envisioning})
            MATCH (g:Genesis)-[:OPENING]->(e)
            OPTIONAL MATCH (g)-[:SEQUENCE*]->(tf:TemporalFrame)
            WITH e, g, tf
            ORDER BY COALESCE(tf.t_created, g.t_created) DESC
            LIMIT 1
            WITH e, COALESCE(tf, g) AS prev
            CREATE (new_tf:TemporalFrame {name: $tf_name, description: $description, t_created: datetime()})
            CREATE (prev)-[s:SEQUENCE]->(new_tf)
            SET s.t_created = datetime()
            RETURN new_tf.name AS name, new_tf.description AS description,
                   new_tf.t_created AS t_created, prev.name AS sequence_from
            """
            result = await self.driver.execute_query(
                query,
                {"envisioning": envisioning, "tf_name": tf_name, "description": description},
                routing_control=RoutingControl.WRITE,
            )
            if not result.records:
                raise ValueError(
                    f"Envisioning '{envisioning}' not found or has no OPENING from a Genesis. "
                    f"Use open_envisioning first."
                )
        else:
            raise ValueError("Must provide either 'sequence_from' or 'envisioning' parameter.")

        record = result.records[0]
        return {
            "name": record["name"],
            "description": record["description"],
            "t_created": _neo4j_datetime_to_str(record["t_created"]),
            "sequence_from": record["sequence_from"],
        }

    async def measure(
        self,
        source: str,
        target_envisioning: str,
        measurement_type: MeasurementType,
        new_name: str | None = None,
        new_description: str | None = None,
    ) -> Dict[str, Any]:
        """Collapse possibility into actuality.

        Creates MEASUREMENT edge from source to target Envisioning.
        - actualized/released: source must be a TemporalFrame
        - evolved: creates a new Envisioning, MEASUREMENT(evolved) FROM new TO old,
          plus OPENING from the Genesis that originated the old one
        """
        logger.info(f"measure: {source} -> {target_envisioning} ({measurement_type.value})")

        if measurement_type in (MeasurementType.ACTUALIZED, MeasurementType.RELEASED):
            # TF -> Envisioning
            query = """
            MATCH (tf:TemporalFrame {name: $source})
            MATCH (e:Envisioning {name: $target})
            CREATE (tf)-[m:MEASUREMENT]->(e)
            SET m.t_created = datetime(),
                m.measurement_type = $measurement_type
            RETURN tf.name AS source, e.name AS target,
                   m.measurement_type AS measurement_type,
                   m.t_created AS measured_at
            """
            result = await self.driver.execute_query(
                query,
                {
                    "source": source,
                    "target": target_envisioning,
                    "measurement_type": measurement_type.value,
                },
                routing_control=RoutingControl.WRITE,
            )
            if not result.records:
                raise ValueError(
                    f"TemporalFrame '{source}' or Envisioning '{target_envisioning}' not found."
                )

            record = result.records[0]
            return {
                "source": record["source"],
                "target": record["target"],
                "measurement_type": record["measurement_type"],
                "measured_at": _neo4j_datetime_to_str(record["measured_at"]),
            }

        elif measurement_type == MeasurementType.EVOLVED:
            if not new_name:
                raise ValueError("'new_name' is required for evolved measurement.")

            # New Envisioning -MEASUREMENT(evolved)-> Old Envisioning
            # New Envisioning gets OPENING from the Genesis that opened the old one
            query = """
            MATCH (old:Envisioning {name: $target})
            MATCH (g:Genesis)-[:OPENING]->(old)
            CREATE (new:Envisioning {name: $new_name, description: $new_description, t_created: datetime()})
            CREATE (new)-[m:MEASUREMENT]->(old)
            SET m.t_created = datetime(),
                m.measurement_type = 'evolved'
            CREATE (g)-[o:OPENING]->(new)
            SET o.t_created = datetime()
            RETURN new.name AS new_envisioning, old.name AS old_envisioning,
                   g.name AS genesis, m.measurement_type AS measurement_type,
                   m.t_created AS measured_at
            """
            result = await self.driver.execute_query(
                query,
                {
                    "target": target_envisioning,
                    "new_name": new_name,
                    "new_description": new_description or "",
                },
                routing_control=RoutingControl.WRITE,
            )
            if not result.records:
                raise ValueError(
                    f"Envisioning '{target_envisioning}' not found or has no OPENING from a Genesis."
                )

            record = result.records[0]
            return {
                "new_envisioning": record["new_envisioning"],
                "old_envisioning": record["old_envisioning"],
                "genesis": record["genesis"],
                "measurement_type": record["measurement_type"],
                "measured_at": _neo4j_datetime_to_str(record["measured_at"]),
            }
        else:
            raise ValueError(f"Unknown measurement_type: {measurement_type}")

    async def time_travel(self, t: str | None = None, limit: int = 50) -> List[Dict[str, Any]]:
        """What was in the active possibility space at time T?

        Traverses process layer ONLY: Genesis -> OPENING -> Envisioning, checks MEASUREMENT.
        Single query, no SEQUENCE chain walking.
        """
        logger.info(f"time_travel: t={t}, limit={limit}")

        if t:
            time_filter = "WHERE g.t_created <= datetime($t)"
            envisioning_filter = "AND e.t_created <= datetime($t)"
            measurement_filter = "WHERE m.t_created <= datetime($t)"
        else:
            time_filter = ""
            envisioning_filter = ""
            measurement_filter = ""

        query = f"""
        MATCH (g:Genesis)-[:OPENING]->(e:Envisioning)
        {time_filter}
        {envisioning_filter}
        OPTIONAL MATCH (x)-[m:MEASUREMENT]->(e)
        {measurement_filter}
        RETURN e.name AS name, g.name AS opened_by, e.t_created AS t_created,
               e.description AS description,
               CASE WHEN m IS NULL THEN 'OPEN'
                    ELSE m.measurement_type
               END AS status,
               m.t_created AS measured_at,
               CASE WHEN x:TemporalFrame THEN x.name
                    WHEN x:Envisioning THEN x.name
                    ELSE null
               END AS measured_by
        ORDER BY status, e.t_created DESC
        LIMIT $limit
        """
        params: Dict[str, Any] = {"limit": limit}
        if t:
            params["t"] = t

        result = await self.driver.execute_query(
            query, params, routing_control=RoutingControl.READ
        )

        return [
            {
                "name": record["name"],
                "opened_by": record["opened_by"],
                "t_created": _neo4j_datetime_to_str(record["t_created"]),
                "description": record["description"],
                "status": record["status"],
                "measured_at": _neo4j_datetime_to_str(record.get("measured_at")),
                "measured_by": record.get("measured_by"),
            }
            for record in result.records
        ]
