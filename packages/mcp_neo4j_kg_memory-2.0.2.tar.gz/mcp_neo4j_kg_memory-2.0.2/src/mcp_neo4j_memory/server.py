import json
import logging
from typing import Any, Literal

from neo4j import AsyncGraphDatabase, Query, RoutingControl
from pydantic import Field
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from fastmcp.server import FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.tools.tool import ToolResult
from mcp.types import TextContent
from neo4j.exceptions import Neo4jError, ClientError
from mcp.types import ToolAnnotations

# Monkey patch FastMCP to support full HTTP method suite outside of auth required path
from fastmcp.server import http as fastmcp_http
from starlette.routing import Route

from .neo4j_memory import (
    Neo4jMemory, Entity, EntityType, ENTITY_TYPE_DESCRIPTIONS, PROCESS_TYPES,
    Relation, RelationType, RELATION_TYPE_DESCRIPTIONS, PROCESS_EDGES,
    MeasurementType, KnowledgeGraph,
)
from .utils import format_namespace, _is_write_query, _value_sanitize

# Set up logging
logger = logging.getLogger('mcp_neo4j_memory')
logger.setLevel(logging.INFO)

# Monkey-patch the bug in FastMCP 2.13.0.2
_original_create_streamable_http_app = fastmcp_http.create_streamable_http_app


def patched_create_streamable_http_app(*args, **kwargs):
    app = _original_create_streamable_http_app(*args, **kwargs)

    # Fix the missing methods in the Route
    # The streamable HTTP endpoint is at the specified path
    streamable_http_path = kwargs.get('streamable_http_path', '/mcp')

    for i, route in enumerate(app.routes):
        if isinstance(route, Route) and route.path == streamable_http_path:
            # Check if methods are missing (they will be None or empty)
            if not route.methods or route.methods == ['GET']:
                # Recreate the route with correct methods
                app.routes[i] = Route(
                    route.path,
                    endpoint=route.endpoint,
                    methods=["GET", "POST", "DELETE"]
                )
                logger.info(f"Patched route {route.path} to accept GET, POST, DELETE")
                break

    return app


# Apply the monkey patch
fastmcp_http.create_streamable_http_app = patched_create_streamable_http_app

def create_mcp_server(
    memory: Neo4jMemory,
    namespace: str = "",
    read_timeout: int = 30,
    schema_sample_size: int = 1000,
) -> FastMCP:
    """Create an MCP server instance for the consciousness substrate."""

    namespace_prefix = format_namespace(namespace)
    mcp: FastMCP = FastMCP("mcp-neo4j-kg-memory")

    # ── Process Tools ────────────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "navigate_genesis",
        annotations=ToolAnnotations(title="Navigate Genesis",
                                          readOnlyHint=False,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def navigate_genesis(
        date: str | None = Field(default=None, description="Date in YYYY-MM-DD format. Defaults to today (UTC).")
    ) -> ToolResult:
        """Atomic day-start ceremony. Creates today's Genesis node (idempotent),
        links NEXT_DAY from the previous Genesis, and returns the active possibility space.

        This is the FIRST tool to call at the start of any day/session. It answers:
        "What envisionings are currently open? Which are dormant? What's the landscape?"

        Returns: today's Genesis + all open/closed Envisionings with their status.

        Example: {"date": "2026-03-06"}  (or omit for today)
        """
        logger.info(f"MCP tool: navigate_genesis (date={date})")
        try:
            result = await memory.navigate_genesis(date=date)
            text = json.dumps(result, indent=2, default=str)
            return ToolResult(content=[TextContent(type="text", text=text)],
                              structured_content={"result": result})
        except Exception as e:
            logger.error(f"Error in navigate_genesis: {e}")
            raise ToolError(f"Error in navigate_genesis: {e}")

    @mcp.tool(
        name=namespace_prefix + "open_envisioning",
        annotations=ToolAnnotations(title="Open Envisioning",
                                          readOnlyHint=False,
                                          destructiveHint=False,
                                          idempotentHint=False,
                                          openWorldHint=True))
    async def open_envisioning(
        genesis_name: str = Field(..., description="Name of the Genesis node to open this Envisioning from (e.g. 'Genesis_2026-03-06')"),
        name: str = Field(..., description="Descriptive name for the Envisioning (e.g. 'Edge AI Manufacturing Continuity')"),
        description: str = Field(default="", description="Vision text: what does done look like, what uncertainties exist"),
    ) -> ToolResult:
        """Project a new future state that consciousness is directed toward.

        Creates an Envisioning node with an OPENING edge from the specified Genesis.
        This represents a new trajectory that didn't exist before.

        Use navigate_genesis first to see what's already open before creating new envisionings.

        Example: {"genesis_name": "Genesis_2026-03-06", "name": "Federated Ontology Platform", "description": "..."}
        """
        logger.info(f"MCP tool: open_envisioning ({name})")
        try:
            result = await memory.open_envisioning(genesis_name=genesis_name, name=name, description=description)
            text = json.dumps(result, indent=2, default=str)
            return ToolResult(content=[TextContent(type="text", text=text)],
                              structured_content={"result": result})
        except ValueError as e:
            raise ToolError(str(e))
        except Exception as e:
            logger.error(f"Error in open_envisioning: {e}")
            raise ToolError(f"Error in open_envisioning: {e}")

    @mcp.tool(
        name=namespace_prefix + "advance_frame",
        annotations=ToolAnnotations(title="Advance Frame",
                                          readOnlyHint=False,
                                          destructiveHint=False,
                                          idempotentHint=False,
                                          openWorldHint=True))
    async def advance_frame(
        description: str = Field(..., description="Session context: what is being worked on, what focus areas"),
        sequence_from: str | None = Field(default=None, description="Mode A: exact name of TF or Genesis to SEQUENCE from"),
        envisioning: str | None = Field(default=None, description="Mode B: name of the Envisioning to re-enter (auto-finds chain terminus)"),
    ) -> ToolResult:
        """Navigate to the next temporal frame (session boundary).

        Creates a TemporalFrame with a SEQUENCE edge. Two modes:
        - Mode A (explicit): provide sequence_from with a specific TF or Genesis name
        - Mode B (by envisioning): provide envisioning name, auto-finds the chain terminus

        Mode B is the common case: "I'm working on X" and advance_frame handles the topology.
        Auto-generates TF_{date}_{slug} name from the description.

        One TF per session/conversation, not per action or per day.

        Example Mode B: {"description": "Consciousness redesign session", "envisioning": "MCP Substrate v2"}
        """
        logger.info(f"MCP tool: advance_frame")
        try:
            result = await memory.advance_frame(description=description, sequence_from=sequence_from, envisioning=envisioning)
            text = json.dumps(result, indent=2, default=str)
            return ToolResult(content=[TextContent(type="text", text=text)],
                              structured_content={"result": result})
        except ValueError as e:
            raise ToolError(str(e))
        except Exception as e:
            logger.error(f"Error in advance_frame: {e}")
            raise ToolError(f"Error in advance_frame: {e}")

    @mcp.tool(
        name=namespace_prefix + "measure",
        annotations=ToolAnnotations(title="Measure",
                                          readOnlyHint=False,
                                          destructiveHint=False,
                                          idempotentHint=False,
                                          openWorldHint=True))
    async def measure(
        source: str = Field(..., description="Name of the source TemporalFrame (for actualized/released)"),
        target_envisioning: str = Field(..., description="Name of the Envisioning being measured/closed"),
        measurement_type: str = Field(..., description="One of: 'actualized', 'released', 'evolved'"),
        new_name: str | None = Field(default=None, description="For evolved: name of the new Envisioning that replaces the old"),
        new_description: str | None = Field(default=None, description="For evolved: description of the new Envisioning"),
    ) -> ToolResult:
        """Collapse possibility into actuality. Creates a MEASUREMENT edge.

        Three measurement types:
        - actualized: TF measured it into reality. The envisioning became real.
        - released: TF measured it as deliberately not actualized. Choosing not to pursue.
        - evolved: Old envisioning's form has evolved. Creates a NEW Envisioning with
          MEASUREMENT(evolved) pointing TO the old one (closing it), plus OPENING from
          the same Genesis. Requires new_name and new_description.

        NOTE: CAUSING is NOT MEASUREMENT. If an Envisioning caused something but isn't
        being closed, use create_relations with CAUSING. Both edges can coexist.

        Example actualized: {"source": "TF_2026-03-06_...", "target_envisioning": "Dashboard MVP", "measurement_type": "actualized"}
        Example evolved: {"source": "ignored", "target_envisioning": "Old Vision", "measurement_type": "evolved", "new_name": "New Vision", "new_description": "..."}
        """
        logger.info(f"MCP tool: measure ({measurement_type})")
        try:
            mt = MeasurementType(measurement_type)
            result = await memory.measure(
                source=source,
                target_envisioning=target_envisioning,
                measurement_type=mt,
                new_name=new_name,
                new_description=new_description,
            )
            text = json.dumps(result, indent=2, default=str)
            return ToolResult(content=[TextContent(type="text", text=text)],
                              structured_content={"result": result})
        except ValueError as e:
            raise ToolError(str(e))
        except Exception as e:
            logger.error(f"Error in measure: {e}")
            raise ToolError(f"Error in measure: {e}")

    @mcp.tool(
        name=namespace_prefix + "time_travel",
        annotations=ToolAnnotations(title="Time Travel",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def time_travel(
        t: str | None = Field(default=None, description="ISO datetime to query at (e.g. '2026-03-06T12:00:00Z'). Defaults to now."),
        limit: int = Field(default=50, description="Maximum Envisionings to return (default 50, max 200)", ge=1, le=200),
    ) -> ToolResult:
        """What was in the active possibility space at time T?

        Traverses the process layer: Genesis -> OPENING -> Envisioning, checks for MEASUREMENT.
        - OPEN = no inbound MEASUREMENT (active possibility)
        - CLOSED = has inbound MEASUREMENT (read measurement_type: actualized/released/evolved)

        Does NOT walk SEQUENCE chains. Those are for drill-down context, not core query.

        Example: {"t": "2026-02-15T00:00:00Z", "limit": 50}
        """
        logger.info(f"MCP tool: time_travel (t={t}, limit={limit})")
        try:
            result = await memory.time_travel(t=t, limit=limit)
            text = json.dumps(result, indent=2, default=str)
            return ToolResult(content=[TextContent(type="text", text=text)],
                              structured_content={"result": result})
        except Exception as e:
            logger.error(f"Error in time_travel: {e}")
            raise ToolError(f"Error in time_travel: {e}")

    # ── Experience Tools ─────────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "create_entities",
        annotations=ToolAnnotations(title="Create Entities",
                                          readOnlyHint=False,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def create_entities(entities: list[Entity] = Field(..., description="List of experience-layer entities to create")) -> ToolResult:
        """Create experience-layer entities in the consciousness substrate.

        HARD REJECTS process types (Genesis, Envisioning, TemporalFrame).
        Use the process tools instead: navigate_genesis, open_envisioning, advance_frame.

        Each entity gets a single label (the type), a description, and auto-set t_created.
        No :Memory superlabel. No type property stored. No Observation sub-nodes.

        IMPORTANT: The `type` field must be one of the 18 experience EntityType values.
        Call `list_allowed_types` to see all valid types.

        Example:
        {
            "entities": [
                {"name": "Process-Experience Layer Distinction", "type": "Insight", "description": "The graph has two layers..."},
                {"name": "Brentano 1874", "type": "Reference", "description": "All mental acts are directed toward objects"}
            ]
        }
        """
        logger.info(f"MCP tool: create_entities ({len(entities)} entities)")
        try:
            entity_objects = [Entity.model_validate(entity) for entity in entities]
            result = await memory.create_entities(entity_objects)
            return ToolResult(content=[TextContent(type="text", text=json.dumps([e.model_dump() for e in result]))],
                          structured_content={"result": result})
        except ValueError as e:
            raise ToolError(str(e))
        except Neo4jError as e:
            logger.error(f"Neo4j error creating entities: {e}")
            raise ToolError(f"Neo4j error creating entities: {e}")
        except Exception as e:
            logger.error(f"Error creating entities: {e}")
            raise ToolError(f"Error creating entities: {e}")

    @mcp.tool(
        name=namespace_prefix + "create_relations",
        annotations=ToolAnnotations(title="Create Relations",
                                          readOnlyHint=False,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def create_relations(relations: list[Relation] = Field(..., description="List of experience-layer relations to create")) -> ToolResult:
        """Create experience-layer relationships between entities.

        HARD REJECTS process edges (OPENING, SEQUENCE, MEASUREMENT, NEXT_DAY).
        These are created exclusively by process tools.

        HARD REJECTS experience edges where BOTH source AND target are process types
        (Genesis, Envisioning, TemporalFrame). Use a mediating experience entity instead.

        All 12 experience edge types are accepted. Auto-sets t_created.

        IMPORTANT: The `relationType` field must be one of the 12 experience RelationType values.
        Call `list_allowed_relation_types` to see all valid types.

        Example:
        {
            "relations": [
                {"source": "TF_2026-03-06_Session", "target": "Process Insight", "relationType": "DISCOVERY"},
                {"source": "Insight A", "target": "Pattern B", "relationType": "INFORMING"}
            ]
        }
        """
        logger.info(f"MCP tool: create_relations ({len(relations)} relations)")
        try:
            relation_objects = [Relation.model_validate(relation) for relation in relations]
            result = await memory.create_relations(relation_objects)
            return ToolResult(content=[TextContent(type="text", text=json.dumps([r.model_dump() for r in result]))],
                          structured_content={"result": result})
        except ValueError as e:
            raise ToolError(str(e))
        except Neo4jError as e:
            logger.error(f"Neo4j error creating relations: {e}")
            raise ToolError(f"Neo4j error creating relations: {e}")
        except Exception as e:
            logger.error(f"Error creating relations: {e}")
            raise ToolError(f"Error creating relations: {e}")

    @mcp.tool(
        name=namespace_prefix + "delete_entities",
        annotations=ToolAnnotations(title="Delete Entities",
                                          readOnlyHint=False,
                                          destructiveHint=True,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def delete_entities(entityNames: list[str] = Field(..., description="List of exact entity names to delete permanently")) -> ToolResult:
        """Delete entities and all their associated relationships from the consciousness substrate.

        Permanently removes entities along with all relationships they participate in.
        This is a destructive operation that cannot be undone.

        Returns:
            str: Success confirmation message

        Example: {"entityNames": ["Old Entity", "Outdated Node"]}
        """
        logger.info(f"MCP tool: delete_entities ({len(entityNames)} entities)")
        try:
            await memory.delete_entities(entityNames)
            return ToolResult(content=[TextContent(type="text", text="Entities deleted successfully")],
                              structured_content={"result": "Entities deleted successfully"})
        except Neo4jError as e:
            logger.error(f"Neo4j error deleting entities: {e}")
            raise ToolError(f"Neo4j error deleting entities: {e}")
        except Exception as e:
            logger.error(f"Error deleting entities: {e}")
            raise ToolError(f"Error deleting entities: {e}")

    @mcp.tool(
        name=namespace_prefix + "delete_relations",
        annotations=ToolAnnotations(title="Delete Relations",
                                          readOnlyHint=False,
                                          destructiveHint=True,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def delete_relations(relations: list[Relation] = Field(..., description="List of specific relationships to delete")) -> ToolResult:
        """Delete specific relationships between entities.

        Removes relationships while keeping the entities themselves.

        IMPORTANT: The `relationType` field must be one of the 16 allowed RelationType values.

        Example:
        {
            "relations": [
                {"source": "Node A", "target": "Node B", "relationType": "INFORMING"}
            ]
        }
        """
        logger.info(f"MCP tool: delete_relations ({len(relations)} relations)")
        try:
            relation_objects = [Relation.model_validate(relation) for relation in relations]
            await memory.delete_relations(relation_objects)
            return ToolResult(content=[TextContent(type="text", text="Relations deleted successfully")],
                          structured_content={"result": "Relations deleted successfully"})
        except Neo4jError as e:
            logger.error(f"Neo4j error deleting relations: {e}")
            raise ToolError(f"Neo4j error deleting relations: {e}")
        except Exception as e:
            logger.error(f"Error deleting relations: {e}")
            raise ToolError(f"Error deleting relations: {e}")

    # ── Query Tools ──────────────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "search_memories",
        annotations=ToolAnnotations(title="Search Memories",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def search_memories(
        query: str = Field(..., description="Fulltext search query to find entities by name or description"),
        limit: int = Field(10, description="Maximum number of results to return (default 10, max 50)", ge=1, le=50)
    ) -> ToolResult:
        """Search the consciousness substrate using fulltext search.

        Searches across all entity names and descriptions. Returns matching entities
        and relationships between them, ordered by relevance score.

        Example: {"query": "consciousness measurement", "limit": 20}
        """
        logger.info(f"MCP tool: search_memories ('{query}', limit={limit})")
        try:
            result = await memory.search_memories(query, limit=limit)
            return ToolResult(content=[TextContent(type="text", text=result.model_dump_json())],
                              structured_content=result)
        except Neo4jError as e:
            logger.error(f"Neo4j error searching memories: {e}")
            raise ToolError(f"Neo4j error searching memories: {e}")
        except Exception as e:
            logger.error(f"Error searching memories: {e}")
            raise ToolError(f"Error searching memories: {e}")

    @mcp.tool(
        name=namespace_prefix + "find_memories_by_name",
        annotations=ToolAnnotations(title="Find Memories by Name",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def find_memories_by_name(
        names: list[str] = Field(..., description="List of exact entity names to retrieve"),
        limit: int = Field(20, description="Maximum entities to return (default 20, max 50)", ge=1, le=50)
    ) -> ToolResult:
        """Find specific entities by their exact names.

        Retrieves entities that exactly match the provided names, along with relationships
        only between the returned entities.

        Example: {"names": ["Genesis_2026-03-06", "Edge AI Manufacturing"], "limit": 20}
        """
        logger.info(f"MCP tool: find_memories_by_name ({len(names)} names, limit={limit})")
        try:
            result = await memory.find_memories_by_name(names, limit=limit)
            return ToolResult(content=[TextContent(type="text", text=result.model_dump_json())],
                              structured_content=result)
        except Neo4jError as e:
            logger.error(f"Neo4j error finding memories by name: {e}")
            raise ToolError(f"Neo4j error finding memories by name: {e}")
        except Exception as e:
            logger.error(f"Error finding memories by name: {e}")
            raise ToolError(f"Error finding memories by name: {e}")

    # ── Taxonomy Tools ───────────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "list_allowed_types",
        annotations=ToolAnnotations(title="List Allowed Entity Types",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def list_allowed_types() -> ToolResult:
        """List all allowed entity types organized by layer.

        Returns 21 types in 2 layers:
        - Process (3): Genesis, Envisioning, TemporalFrame — the constitutive cycle
        - Experience (18): everything else — the descriptive richness

        Process types can ONLY be created via process tools.
        Experience types are created via create_entities.
        """
        logger.info("MCP tool: list_allowed_types")

        categories = {
            "process": {
                "description": "The constitutive cycle. Created exclusively by process tools (navigate_genesis, open_envisioning, advance_frame).",
                "types": {},
            },
            "experience": {
                "description": "The descriptive richness. Created via create_entities.",
                "types": {},
            },
        }

        for et in EntityType:
            cat = "process" if et in PROCESS_TYPES else "experience"
            categories[cat]["types"][et.value] = ENTITY_TYPE_DESCRIPTIONS[et]

        result = {
            "total_types": len(EntityType),
            "categories": categories,
        }

        text = json.dumps(result, indent=2)
        return ToolResult(
            content=[TextContent(type="text", text=text)],
            structured_content={"result": result},
        )

    @mcp.tool(
        name=namespace_prefix + "list_allowed_relation_types",
        annotations=ToolAnnotations(title="List Allowed Relation Types",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def list_allowed_relation_types() -> ToolResult:
        """List all allowed relationship types organized by layer.

        Returns 16 types in 2 layers:
        - Process (4): OPENING, SEQUENCE, MEASUREMENT, NEXT_DAY — the cycle edges
        - Experience (12): everything else — the meaning edges

        Process edges are created exclusively by process tools.
        Experience edges are created via create_relations.
        """
        logger.info("MCP tool: list_allowed_relation_types")

        # Subcategorize experience edges
        experience_subcats = {
            "temporal": {
                "description": "Temporal transformation and trajectory",
                "types": {},
            },
            "intentionality": {
                "description": "Consciousness reaching toward knowledge",
                "types": {},
            },
            "fulfillment": {
                "description": "Theory meeting evidence",
                "types": {},
            },
            "foundation": {
                "description": "Prerequisite and dependency",
                "types": {},
            },
            "mereology": {
                "description": "Part-whole relationships",
                "types": {},
            },
            "motivation": {
                "description": "Knowledge flow and causation",
                "types": {},
            },
        }

        _exp_subcat_map = {
            "temporal": [RelationType.EVOLUTION, RelationType.EXTENDING],
            "intentionality": [RelationType.DISCOVERY, RelationType.RECOGNITION],
            "fulfillment": [RelationType.VALIDATION, RelationType.CHALLENGE],
            "foundation": [RelationType.ENABLING, RelationType.REQUIRING],
            "mereology": [RelationType.ENCOMPASSING, RelationType.COMPOSING],
            "motivation": [RelationType.INFORMING, RelationType.CAUSING],
        }

        for subcat, members in _exp_subcat_map.items():
            for member in members:
                experience_subcats[subcat]["types"][member.value] = RELATION_TYPE_DESCRIPTIONS[member]

        process_types = {}
        for rt in PROCESS_EDGES:
            process_types[rt.value] = RELATION_TYPE_DESCRIPTIONS[rt]

        result = {
            "total_types": len(RelationType),
            "layers": {
                "process": {
                    "description": "The cycle edges. Created exclusively by process tools. What time_travel traverses.",
                    "types": process_types,
                },
                "experience": {
                    "description": "The meaning edges. Created via create_relations. What search_memories finds.",
                    "subcategories": experience_subcats,
                },
            },
        }

        text = json.dumps(result, indent=2)
        return ToolResult(
            content=[TextContent(type="text", text=text)],
            structured_content={"result": result},
        )

    # ── Cypher Tools ──────────────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "get_neo4j_schema",
        annotations=ToolAnnotations(title="Get Neo4j Schema",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def get_neo4j_schema() -> ToolResult:
        """List all node labels, their attributes and their relationships to other nodes in the neo4j database.
        This requires that the APOC plugin is installed and enabled."""
        logger.info("MCP tool: get_neo4j_schema")

        try:
            # Compact schema: labels with property keys and counts
            nodes_result = await memory.driver.execute_query(
                Query(
                    """
                    CALL apoc.meta.nodeTypeProperties()
                    YIELD nodeType, propertyName, propertyTypes
                    WITH nodeType,
                         collect({property: propertyName, types: propertyTypes}) AS properties
                    RETURN nodeType AS label, properties
                    ORDER BY label
                    """,
                    timeout=read_timeout,
                ),
                routing_=RoutingControl.READ,
            )

            # Compact schema: relationship types with connected labels
            rels_result = await memory.driver.execute_query(
                Query(
                    """
                    CALL apoc.meta.relTypeProperties()
                    YIELD relType, propertyName, propertyTypes
                    WITH relType,
                         collect(CASE WHEN propertyName IS NOT NULL
                                 THEN {property: propertyName, types: propertyTypes}
                                 ELSE null END) AS properties
                    RETURN relType, [p IN properties WHERE p IS NOT NULL] AS properties
                    ORDER BY relType
                    """,
                    timeout=read_timeout,
                ),
                routing_=RoutingControl.READ,
            )

            # Node counts per label
            counts_result = await memory.driver.execute_query(
                Query(
                    """
                    CALL db.labels() YIELD label
                    CALL apoc.cypher.run('MATCH (n:`' + label + '`) RETURN count(n) AS count', {})
                    YIELD value
                    RETURN label, value.count AS count
                    ORDER BY count DESC
                    """,
                    timeout=read_timeout,
                ),
                routing_=RoutingControl.READ,
            )

            schema = {
                "node_labels": [dict(record) for record in nodes_result.records],
                "relationship_types": [dict(record) for record in rels_result.records],
                "node_counts": [dict(record) for record in counts_result.records],
            }

            text = json.dumps(schema, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": schema},
            )
        except ClientError as e:
            if "apoc" in str(e).lower():
                raise ToolError(
                    "APOC plugin is not available. get_neo4j_schema requires APOC to be installed and enabled."
                )
            raise ToolError(f"Neo4j client error: {e}")
        except Neo4jError as e:
            logger.error(f"Neo4j error getting schema: {e}")
            raise ToolError(f"Neo4j error getting schema: {e}")
        except Exception as e:
            logger.error(f"Error getting schema: {e}")
            raise ToolError(f"Error getting schema: {e}")

    @mcp.tool(
        name=namespace_prefix + "read_neo4j_cypher",
        annotations=ToolAnnotations(title="Read Neo4j Cypher",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def read_neo4j_cypher(
        query: str = Field(..., description="The Cypher query to execute."),
        params: dict[str, Any] = Field(default_factory=dict, description="The parameters to pass to the Cypher query."),
    ) -> ToolResult:
        """Execute a read-only Cypher query on the neo4j database.

        Read-only escape hatch for debugging and ad-hoc queries.
        Write queries are rejected — use the bounded mutation tools instead.
        """
        logger.info(f"MCP tool: read_neo4j_cypher")

        # Guard: reject write queries
        if _is_write_query(query):
            raise ToolError(
                "Write queries are not allowed via read_neo4j_cypher. "
                "Use the bounded mutation tools (create_entities, create_relations, etc.) instead."
            )

        try:
            result = await memory.driver.execute_query(
                Query(query, timeout=read_timeout),
                parameters_=params,
                routing_=RoutingControl.READ,
            )
            records = [_value_sanitize(dict(record)) for record in result.records]
            records = [r for r in records if r is not None]
            text = json.dumps(records, indent=2, default=str)

            # Safety truncation to prevent context explosion
            if len(text) > 200_000:
                text = text[:200_000] + "\n... (truncated — add LIMIT to your query)"

            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error executing cypher: {e}")
            raise ToolError(f"Neo4j error executing cypher: {e}")
        except Exception as e:
            logger.error(f"Error executing cypher: {e}")
            raise ToolError(f"Error executing cypher: {e}")

    # ── GDS Analytics Tools ───────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "gds_create_projection",
        annotations=ToolAnnotations(title="GDS Create Projection",
                                          readOnlyHint=False,
                                          destructiveHint=False,
                                          idempotentHint=False,
                                          openWorldHint=False))
    async def gds_create_projection(
        name: str = Field(..., description="Name for the graph projection"),
        rel_types: list[str] = Field(default=None, description="Relationship types to include (defaults to all). E.g. ['INFORMING', 'ENCOMPASSING']"),
        undirected: bool = Field(default=True, description="Whether to treat relationships as undirected (default true)"),
        memory_gb: str = Field(default="2GB", description="Memory allocation for the projection."),
    ) -> ToolResult:
        """Create a GDS graph projection for analytics.

        Projects a subgraph into GDS memory for running algorithms like PageRank, Louvain, WCC.
        Uses label-agnostic MATCH (no :Memory superlabel).

        SCALING CONSTRAINT: Cypher projections traverse every matched relationship.
        For large graphs, scope carefully with rel_types filters.
        """
        logger.info(f"MCP tool: gds_create_projection (name={name})")
        try:
            if rel_types:
                rel_filter = "|".join(f"`{rt}`" for rt in rel_types)
                match_clause = f"MATCH (source)-[r:{rel_filter}]->(target)"
            else:
                match_clause = "MATCH (source)-[r]->(target)"

            config_parts = [f"memory: '{memory_gb}'"]
            if undirected:
                config_parts.append("undirectedRelationshipTypes: ['*']")
            config_str = ", ".join(config_parts)

            query = f"""
                {match_clause}
                RETURN gds.graph.project(
                    $name,
                    source,
                    target,
                    {{}},
                    {{{config_str}}}
                )
            """

            result = await memory.driver.execute_query(
                query,
                name=name,
                routing_=RoutingControl.READ,
            )
            records = [_value_sanitize(dict(record)) for record in result.records]
            records = [r for r in records if r is not None]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error creating GDS projection: {e}")
            raise ToolError(f"Neo4j error creating GDS projection: {e}")
        except Exception as e:
            logger.error(f"Error creating GDS projection: {e}")
            raise ToolError(f"Error creating GDS projection: {e}")

    @mcp.tool(
        name=namespace_prefix + "gds_drop_projection",
        annotations=ToolAnnotations(title="GDS Drop Projection",
                                          readOnlyHint=False,
                                          destructiveHint=True,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def gds_drop_projection(
        name: str = Field(..., description="Name of the graph projection to drop"),
    ) -> ToolResult:
        """Drop a GDS graph projection to free memory."""
        logger.info(f"MCP tool: gds_drop_projection (name={name})")
        try:
            result = await memory.driver.execute_query(
                "CALL gds.graph.drop($name)",
                name=name,
                routing_=RoutingControl.WRITE,
            )
            records = [dict(record) for record in result.records]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error dropping GDS projection: {e}")
            raise ToolError(f"Neo4j error dropping GDS projection: {e}")
        except Exception as e:
            logger.error(f"Error dropping GDS projection: {e}")
            raise ToolError(f"Error dropping GDS projection: {e}")

    @mcp.tool(
        name=namespace_prefix + "gds_pagerank",
        annotations=ToolAnnotations(title="GDS PageRank",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def gds_pagerank(
        projection: str = Field(..., description="Name of the graph projection to run PageRank on"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Maximum number of results to return (default 20)"),
    ) -> ToolResult:
        """Run PageRank on a GDS graph projection.

        Returns nodes ranked by importance/centrality. Requires a projection created via gds_create_projection.
        """
        logger.info(f"MCP tool: gds_pagerank (projection={projection}, limit={result_limit})")
        try:
            result = await memory.driver.execute_query(
                """
                CALL gds.pageRank.stream($projection)
                YIELD nodeId, score
                RETURN gds.util.asNode(nodeId).name AS node,
                       labels(gds.util.asNode(nodeId))[0] AS type,
                       score
                ORDER BY score DESC
                LIMIT $result_limit
                """,
                projection=projection,
                result_limit=result_limit,
                routing_=RoutingControl.READ,
            )
            records = [dict(record) for record in result.records]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error running PageRank: {e}")
            raise ToolError(f"Neo4j error running PageRank: {e}")
        except Exception as e:
            logger.error(f"Error running PageRank: {e}")
            raise ToolError(f"Error running PageRank: {e}")

    @mcp.tool(
        name=namespace_prefix + "gds_louvain",
        annotations=ToolAnnotations(title="GDS Louvain",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def gds_louvain(
        projection: str = Field(..., description="Name of the graph projection to run Louvain on"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Maximum number of results to return (default 20)"),
    ) -> ToolResult:
        """Run Louvain community detection on a GDS graph projection.

        Identifies communities/clusters. Requires a projection created via gds_create_projection.
        """
        logger.info(f"MCP tool: gds_louvain (projection={projection}, limit={result_limit})")
        try:
            result = await memory.driver.execute_query(
                """
                CALL gds.louvain.stream($projection)
                YIELD nodeId, communityId
                RETURN gds.util.asNode(nodeId).name AS node,
                       labels(gds.util.asNode(nodeId))[0] AS type,
                       communityId
                ORDER BY communityId, node
                LIMIT $result_limit
                """,
                projection=projection,
                result_limit=result_limit,
                routing_=RoutingControl.READ,
            )
            records = [dict(record) for record in result.records]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error running Louvain: {e}")
            raise ToolError(f"Neo4j error running Louvain: {e}")
        except Exception as e:
            logger.error(f"Error running Louvain: {e}")
            raise ToolError(f"Error running Louvain: {e}")

    @mcp.tool(
        name=namespace_prefix + "gds_wcc",
        annotations=ToolAnnotations(title="GDS Weakly Connected Components",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def gds_wcc(
        projection: str = Field(..., description="Name of the graph projection to run WCC on"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Maximum number of results to return (default 20)"),
    ) -> ToolResult:
        """Run Weakly Connected Components on a GDS graph projection.

        Identifies connected components. Requires a projection created via gds_create_projection.
        """
        logger.info(f"MCP tool: gds_wcc (projection={projection}, limit={result_limit})")
        try:
            result = await memory.driver.execute_query(
                """
                CALL gds.wcc.stream($projection)
                YIELD nodeId, componentId
                RETURN gds.util.asNode(nodeId).name AS node,
                       labels(gds.util.asNode(nodeId))[0] AS type,
                       componentId
                ORDER BY componentId, node
                LIMIT $result_limit
                """,
                projection=projection,
                result_limit=result_limit,
                routing_=RoutingControl.READ,
            )
            records = [dict(record) for record in result.records]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error running WCC: {e}")
            raise ToolError(f"Neo4j error running WCC: {e}")
        except Exception as e:
            logger.error(f"Error running WCC: {e}")
            raise ToolError(f"Error running WCC: {e}")

    return mcp


async def main(
    neo4j_uri: str,
    neo4j_user: str,
    neo4j_password: str,
    neo4j_database: str,
    transport: Literal["stdio", "sse", "streamable-http"] = "stdio",
    namespace: str = "",
    host: str = "127.0.0.1",
    port: int = 8000,
    path: str = "/mcp/",
    allow_origins: list[str] = [],
    allowed_hosts: list[str] = [],
    read_timeout: int = 30,
    schema_sample_size: int = 1000,
) -> None:
    logger.info(f"Starting Neo4j MCP Memory Server")
    logger.info(f"Connecting to Neo4j with DB URL: {neo4j_uri}")

    # Connect to Neo4j
    neo4j_driver = AsyncGraphDatabase.driver(
        neo4j_uri,
        auth=(neo4j_user, neo4j_password),
        database=neo4j_database
    )

    # Verify connection
    try:
        await neo4j_driver.verify_connectivity()
        logger.info(f"Connected to Neo4j at {neo4j_uri}")
    except Exception as e:
        logger.error(f"Failed to connect to Neo4j: {e}")
        exit(1)

    # Initialize memory
    memory = Neo4jMemory(neo4j_driver)
    logger.info("Neo4jMemory initialized")

    # Create fulltext index
    await memory.create_fulltext_index()

    # Configure security middleware
    custom_middleware = [
        Middleware(
            CORSMiddleware,
            allow_origins=allow_origins,
            allow_methods=["GET", "POST"],
            allow_headers=["*"],
        ),
        Middleware(TrustedHostMiddleware,
                   allowed_hosts=allowed_hosts)
    ]

    # Create MCP server
    mcp = create_mcp_server(memory, namespace, read_timeout=read_timeout, schema_sample_size=schema_sample_size)
    logger.info("MCP server created")

    # Run the server with the specified transport
    logger.info(f"Starting server with transport: {transport}")
    match transport:
        case "streamable-http":
            logger.info(f"HTTP server starting on {host}:{port}{path}")
            await mcp.run_http_async(host=host, port=port, path=path, middleware=custom_middleware, transport="streamable-http", stateless_http=True)
        case "stdio":
            logger.info("STDIO server starting")
            await mcp.run_stdio_async()
        case "sse":
            logger.info(f"SSE server starting on {host}:{port}{path}")
            await mcp.run_http_async(host=host, port=port, path=path, middleware=custom_middleware, transport="sse")
        case _:
            raise ValueError(f"Unsupported transport: {transport}")
