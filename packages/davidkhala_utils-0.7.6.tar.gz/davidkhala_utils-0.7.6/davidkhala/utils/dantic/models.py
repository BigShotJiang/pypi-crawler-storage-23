from pydantic import BaseModel


class ID(BaseModel):
    id: str
