"""OpenMed TUI - Interactive Terminal User Interface for clinical NER analysis."""

from openmed.tui.app import OpenMedTUI

__all__ = ["OpenMedTUI"]
