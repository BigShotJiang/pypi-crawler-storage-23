# TruthCheck Architecture

## Overview

TruthCheck is designed to be simple, local-first, and extensible. No cloud services required for basic functionality.

```
┌───────────────────────────────────────────────────────┐
│                     TruthCheck                         │
├───────────────────────────────────────────────────────┤
│                                                        │
│  verify(url)                 trace_claim(claim)        │
│       │                            │                   │
│       ▼                            ▼                   │
│  ┌──────────────┐           ┌──────────────┐          │
│  │ PublisherDB  │           │SearchProvider│          │
│  │ (8,974 srcs) │           │(Brave/SearX) │          │
│  └──────────────┘           └──────────────┘          │
│       │                            │                   │
│       ▼                            ▼                   │
│  ┌──────────────┐           ┌──────────────┐          │
│  │ContentAnalyze│           │ Find Fact-   │          │
│  │  (L3)        │           │ Checks       │          │
│  └──────────────┘           └──────────────┘          │
│       │                            │                   │
│       ▼                            ▼                   │
│  ┌──────────────┐           ┌──────────────┐          │
│  │   Scorer     │           │ LLM Analysis │          │
│  └──────────────┘           │  (optional)  │          │
│       │                     └──────────────┘          │
│       ▼                            │                   │
│  VerificationResult          TraceResult              │
│                                                        │
├───────────────────────────────────────────────────────┤
│  Data: publishers.json (2.5MB, 8,974 sources)         │
│  Source: mediabiasfactcheck.com (auto-synced weekly)  │
└───────────────────────────────────────────────────────┘
```

## Core Components

### 1. Publisher Database (`publisher_db.py`)

The heart of TruthCheck. Contains 8,974 publishers from MBFC with:
- Trust score (0-1)
- Bias rating (left → right)
- Factual reporting level
- Credibility assessment

```python
from truthcheck.publisher_db import PublisherDB

db = PublisherDB()  # Auto-syncs if data >7 days old
publisher = db.lookup("reuters.com")
# Publisher(domain='reuters.com', name='Reuters', trust_score=0.85, ...)
```

**Data flow:**
1. On first use, checks if `publishers.json` is >7 days old
2. If stale, fetches latest from MBFC (0.15s)
3. Loads into memory (14ms)
4. Lookups are O(1) dictionary access

### 2. Sync (`sync.py`)

Fetches and converts MBFC data:

```python
from truthcheck.sync import sync_database, is_stale, auto_sync

# Check if update needed
if is_stale(max_age_days=7):
    sync_database()  # Fetches from MBFC, saves to publishers.json

# Auto-sync is called automatically on first PublisherDB() load
```

**MBFC data source:**
```
https://raw.githubusercontent.com/drmikecrowe/mbfcext/master/docs/v5/data/combined.json
```

### 3. Analyzers

#### Publisher Analyzer (L1)

Fast database lookup:

```python
class PublisherAnalyzer:
    def analyze(self, url: str, content: str = None) -> Signal:
        domain = extract_domain(url)
        publisher = self.db.lookup(domain)
        
        if publisher:
            return Signal(
                name="publisher",
                score=publisher.trust_score,
                confidence=0.9 if publisher.verified else 0.7,
                details={"name": publisher.name, "found": True}
            )
        
        # Unknown publisher
        return Signal(name="publisher", score=0.5, confidence=0.2, details={"found": False})
```

#### Content Analyzer (L3)

Detects red flags in article text:

```python
class ContentAnalyzer:
    CLICKBAIT_PATTERNS = [
        r"you won't believe",
        r"shocking",
        r"exposed",
        # ...
    ]
    
    def analyze(self, url: str, content: str = None) -> Signal:
        flags = []
        score = 0.7
        
        # Check for clickbait
        if self._has_clickbait(content):
            flags.append("clickbait")
            score -= 0.2
        
        # Check for excessive caps
        if self._excessive_caps(content):
            flags.append("excessive_caps")
            score -= 0.1
        
        return Signal(name="content", score=score, confidence=0.5, details={"flags": flags})
```

### 4. Scorer (`scorer.py`)

Combines signals into final score:

```python
WEIGHTS = {
    "publisher": 0.7,   # Publisher database is most reliable
    "content": 0.3,     # Content heuristics are supplementary
}

def calculate(signals: dict[str, Signal]) -> VerificationResult:
    weighted_sum = 0
    weight_total = 0
    
    for name, signal in signals.items():
        weight = WEIGHTS.get(name, 0.1) * signal.confidence
        weighted_sum += signal.score * weight
        weight_total += weight
    
    trust_score = weighted_sum / weight_total if weight_total > 0 else 0.5
    
    return VerificationResult(
        trust_score=trust_score,
        recommendation=get_recommendation(trust_score),
        signals=signals
    )
```

### 5. Claim Tracer (`trace.py`)

Traces claims to their sources:

```python
class ClaimTracer:
    def trace(self, claim: str) -> TraceResult:
        # 1. Search for the claim
        results = self.search_provider.search(claim)
        
        # 2. Identify fact-check sites
        fact_checks = [r for r in results if self._is_fact_check(r.url)]
        
        # 3. Extract ratings from snippets
        for fc in fact_checks:
            fc.rating = self._extract_rating(fc.snippet)
        
        # 4. Determine verdict
        verdict = self._calculate_verdict(fact_checks)
        
        # 5. Optional: LLM analysis for better summary
        if self.llm:
            summary = self._llm_summarize(claim, fact_checks)
        
        return TraceResult(
            claim=claim,
            verdict=verdict,
            fact_checks=fact_checks,
            sources=results
        )
```

## Data Models

```python
@dataclass
class Signal:
    name: str           # "publisher", "content"
    score: float        # 0.0 to 1.0
    confidence: float   # How sure we are
    details: dict       # Analyzer-specific data

@dataclass
class Publisher:
    domain: str
    name: str
    trust_score: float
    category: str       # "mainstream", "general", "questionable"
    bias: str           # "left", "center", "right", etc.
    fact_check_rating: str
    verified: bool

@dataclass
class VerificationResult:
    url: str
    trust_score: float
    recommendation: str  # "TRUST", "CAUTION", "REJECT"
    signals: dict[str, Signal]

@dataclass
class TraceResult:
    claim: str
    verdict: str        # "TRUE", "FALSE", "MIXED", "UNVERIFIED"
    confidence: float
    summary: str
    fact_checks: list[FactCheck]
    sources: list[SearchResult]
```

## Configuration

Environment-based configuration (`config.py`):

```python
# Search provider
SEARCH_PROVIDER = os.getenv("TRUTHSCORE_SEARCH_PROVIDER", "brave")
BRAVE_API_KEY = os.getenv("BRAVE_API_KEY")
SEARXNG_URL = os.getenv("SEARXNG_URL", "http://localhost:8080")

# LLM provider (optional)
LLM_PROVIDER = os.getenv("TRUTHSCORE_LLM_PROVIDER", "ollama")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# Auto-sync control
AUTO_SYNC_DISABLED = os.getenv("TRUTHSCORE_NO_AUTO_SYNC", "").lower() in ("1", "true")
```

## File Structure

```
src/truthcheck/
├── __init__.py          # Public API exports
├── verify.py            # verify() function
├── trace.py             # trace_claim() function  
├── publisher_db.py      # Publisher database with auto-sync
├── sync.py              # MBFC sync logic
├── config.py            # Environment configuration
├── models.py            # Data classes
├── scorer.py            # Signal → score calculation
├── utils.py             # URL parsing, domain extraction
├── search.py            # Search providers (Brave, SearXNG)
├── llm.py               # LLM providers (OpenAI, Anthropic, Gemini, Ollama)
├── cli.py               # Command-line interface
├── mcp_server.py        # MCP server for Claude/Cursor
├── analyzers/
│   ├── __init__.py
│   ├── publisher.py     # L1: Publisher lookup
│   └── content.py       # L3: Content heuristics
└── data/
    ├── publishers.json  # 8,974 publishers (2.5MB)
    └── publishers/      # YAML overrides (optional)
        └── _template.yaml
```

## Performance

| Operation | Time |
|-----------|------|
| Load database | 14ms |
| Publisher lookup | <1ms |
| Content analysis | ~5ms |
| Full verify() | ~20ms |
| MBFC sync (network) | ~150ms |

## Design Decisions

### Why no Domain Analyzer (L2)?

We originally planned WHOIS/DNS analysis for unknown publishers. Decided against it:
- WHOIS lookups are slow (1-2s per domain)
- Many WHOIS APIs are rate-limited or paid
- Domain age is a weak signal (scammers buy old domains)
- 8,974 publishers covers most legitimate news sources

### Why JSON instead of SQLite?

- 9K publishers fits easily in memory (~2.5MB)
- Dictionary lookup is O(1)
- No database dependencies
- Simpler to update/sync

### Why auto-sync on first use?

- Users never need to think about updates
- 7-day threshold balances freshness vs. network calls
- Fails silently → always works offline
- Can disable with `TRUTHSCORE_NO_AUTO_SYNC=1`
