# TruthCheck MCP Server

The MCP (Model Context Protocol) server allows AI assistants like Claude to use TruthCheck directly.

## Installation

```bash
pip install truthcheck
```

## Running the Server

```bash
truthcheck-mcp
```

Or run directly:
```bash
python -m truthcheck.mcp_server
```

## Configuration

### Claude Desktop

Add to `~/.config/claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "truthcheck": {
      "command": "truthcheck-mcp"
    }
  }
}
```

### With Search API (for trace_claim)

```json
{
  "mcpServers": {
    "truthcheck": {
      "command": "truthcheck-mcp",
      "env": {
        "BRAVE_API_KEY": "your-brave-api-key"
      }
    }
  }
}
```

### With LLM (for claim extraction)

```json
{
  "mcpServers": {
    "truthcheck": {
      "command": "truthcheck-mcp",
      "env": {
        "TRUTHSCORE_LLM_PROVIDER": "ollama",
        "OLLAMA_MODEL": "llama3"
      }
    }
  }
}
```

## Available Tools

| Tool | Description | Requirements |
|------|-------------|--------------|
| `verify_source` | Check if a URL is trustworthy | None (free) |
| `lookup_publisher` | Get publisher info by domain | None (free) |
| `trace_claim` | Find fact-checks for a claim | Search API |

### verify_source

Check if a URL is trustworthy before citing.

**Input:**
```json
{
  "url": "https://reuters.com/article/..."
}
```

**Output:**
```json
{
  "url": "https://reuters.com/article/...",
  "trust_score": 0.85,
  "recommendation": "TRUST",
  "signals": {
    "publisher": {
      "score": 0.85,
      "name": "Reuters",
      "bias": "center",
      "found": true
    },
    "content": {
      "score": 0.7,
      "flags": []
    }
  }
}
```

### lookup_publisher

Get information about a known publisher.

**Input:**
```json
{
  "domain": "breitbart.com"
}
```

**Output:**
```json
{
  "domain": "breitbart.com",
  "name": "Breitbart",
  "trust_score": 0.30,
  "category": "questionable",
  "bias": "fake-news",
  "fact_check_rating": "mixed",
  "found": true
}
```

### trace_claim

Track down fact-checks for a claim.

**Input:**
```json
{
  "claim": "The Great Wall of China is visible from space"
}
```

**Output:**
```json
{
  "claim": "The Great Wall of China is visible from space",
  "verdict": "FALSE",
  "confidence": 0.92,
  "summary": "This is a common myth. NASA confirms...",
  "fact_checks": [
    {
      "source": "snopes.com",
      "url": "https://snopes.com/fact-check/great-wall-space/",
      "rating": "FALSE"
    }
  ]
}
```

*Requires search API (Brave or SearXNG).*

## How Claude Uses It

When Claude has TruthCheck enabled:

1. **Verify before citing:**
   > "Let me verify that source... [calls verify_source] The source has a trust score of 0.30, which indicates it's not reliable. I'll find a better source."

2. **Check publisher credibility:**
   > "I'll check the publisher... [calls lookup_publisher] This is from Reuters (trust score: 0.85, center bias), a reliable source."

3. **Fact-check claims:**
   > "Let me verify that claim... [calls trace_claim] According to Snopes and NASA, this is a myth."

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `BRAVE_API_KEY` | Brave Search API key | For trace_claim |
| `SEARXNG_URL` | Self-hosted SearXNG URL | Alternative to Brave |
| `TRUTHSCORE_LLM_PROVIDER` | LLM for analysis | Optional |
| `OPENAI_API_KEY` | OpenAI API key | If using OpenAI |
| `ANTHROPIC_API_KEY` | Anthropic API key | If using Anthropic |
| `GEMINI_API_KEY` | Google AI API key | If using Gemini |
| `TRUTHSCORE_NO_AUTO_SYNC` | Disable auto-sync | Optional |

## Troubleshooting

### "Command not found: truthcheck-mcp"

Make sure TruthCheck is installed:
```bash
pip install truthcheck
```

And your Python bin is in PATH:
```bash
which truthcheck-mcp
```

### "Publisher not found"

The publisher might not be in MBFC's database. You can:
1. Submit it to [MBFC](https://mediabiasfactcheck.com/submit-source/)
2. Add a local override in `data/publishers/domain.yaml`

### Slow first request

The database auto-syncs if data is >7 days old. First request may take ~200ms. Subsequent requests are <20ms.

### Offline usage

TruthCheck ships with a full database snapshot and works offline. Set `TRUTHSCORE_NO_AUTO_SYNC=1` to disable network checks.
