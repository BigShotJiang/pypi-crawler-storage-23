"""
Tests for main verify() function.
TDD: Write these tests FIRST, then implement verify.py
"""
import json
import pytest


def create_json_db(path, publishers: dict):
    """Helper to create a JSON database."""
    db_file = path / "publishers.json"
    db_file.write_text(json.dumps({
        "meta": {"source": "test"},
        "publishers": publishers
    }))


class TestVerify:
    """Tests for the verify() function."""
    
    def test_verify_known_publisher(self, tmp_path):
        """Verify returns high score for known trusted publisher."""
        from truthcheck import verify
        from truthcheck.publisher_db import PublisherDB
        
        # Create test publisher in JSON format
        create_json_db(tmp_path, {
            "trusted.com": {
                "name": "Trusted News",
                "trust_score": 0.9,
                "credibility": "high"
            }
        })
        
        db = PublisherDB(tmp_path)
        result = verify("https://trusted.com/article", publisher_db=db)
        
        assert result.trust_score >= 0.7
        assert result.recommendation in ["TRUST", "CAUTION"]
        assert "publisher" in result.signals
    
    def test_verify_unknown_publisher(self, tmp_path):
        """Verify returns neutral score for unknown publisher."""
        from truthcheck import verify
        from truthcheck.publisher_db import PublisherDB
        
        db = PublisherDB(tmp_path)  # Empty DB
        result = verify("https://unknown-site.com/article", publisher_db=db)
        
        assert 0.4 <= result.trust_score <= 0.7
        assert result.signals["publisher"].details["found"] == False
    
    def test_verify_with_content(self, tmp_path):
        """Verify analyzes provided content."""
        from truthcheck import verify
        from truthcheck.publisher_db import PublisherDB
        
        db = PublisherDB(tmp_path)
        
        good_content = """
        By John Smith, Reporter
        
        This is a well-written article about current events.
        The facts are clearly presented with proper attribution.
        """
        
        result = verify(
            "https://example.com/article",
            content=good_content,
            publisher_db=db
        )
        
        assert "content" in result.signals
        assert "no_author" not in result.signals["content"].details.get("flags", [])
    
    def test_verify_clickbait_lowers_score(self, tmp_path):
        """Clickbait content lowers overall score."""
        from truthcheck import verify
        from truthcheck.publisher_db import PublisherDB
        
        db = PublisherDB(tmp_path)
        
        clickbait = """
        You WON'T BELIEVE what happened next!!!
        SHOCKING revelations EXPOSED!!!
        """
        
        result = verify(
            "https://example.com/clickbait",
            content=clickbait,
            publisher_db=db
        )
        
        assert result.trust_score < 0.6
        assert "clickbait" in result.signals["content"].details.get("flags", [])
    
    def test_verify_returns_verification_result(self, tmp_path):
        """Verify returns a VerificationResult object."""
        from truthcheck import verify
        from truthcheck.models import VerificationResult
        from truthcheck.publisher_db import PublisherDB
        
        db = PublisherDB(tmp_path)
        result = verify("https://example.com", publisher_db=db)
        
        assert isinstance(result, VerificationResult)
        assert hasattr(result, "trust_score")
        assert hasattr(result, "recommendation")
        assert hasattr(result, "signals")
    
    def test_verify_url_stored_in_result(self, tmp_path):
        """Result contains the verified URL."""
        from truthcheck import verify
        from truthcheck.publisher_db import PublisherDB
        
        db = PublisherDB(tmp_path)
        result = verify("https://example.com/page", publisher_db=db)
        
        assert result.url == "https://example.com/page"
    
    def test_verify_invalid_url(self):
        """Verify handles invalid URL gracefully."""
        from truthcheck import verify
        
        # Should not crash
        result = verify("not-a-valid-url")
        
        # Should return low confidence result
        assert result.trust_score == 0.5
        assert result.signals["publisher"].confidence <= 0.2
    
    def test_verify_uses_default_db(self):
        """Verify uses bundled publisher DB by default."""
        from truthcheck import verify
        
        # Reuters is in our synced data
        result = verify("https://reuters.com/article")
        
        assert result.signals["publisher"].details.get("found") == True
        assert result.signals["publisher"].details.get("name") == "Reuters"
    
    def test_verify_multiple_signals(self, tmp_path):
        """Verify combines multiple analyzers."""
        from truthcheck import verify
        from truthcheck.publisher_db import PublisherDB
        
        create_json_db(tmp_path, {
            "test.com": {
                "name": "Test Site",
                "trust_score": 0.7,
                "credibility": "medium"
            }
        })
        
        db = PublisherDB(tmp_path)
        content = "By Jane Doe. This is some article content."
        
        result = verify("https://test.com/article", content=content, publisher_db=db)
        
        # Should have both publisher and content signals
        assert "publisher" in result.signals
        assert "content" in result.signals
    
    def test_verify_score_bounds(self, tmp_path):
        """Score is always between 0 and 1."""
        from truthcheck import verify
        from truthcheck.publisher_db import PublisherDB
        
        db = PublisherDB(tmp_path)
        
        # Various inputs
        urls = [
            "https://example.com",
            "https://sketchy-site.biz/scam",
            "not-valid",
        ]
        
        for url in urls:
            result = verify(url, publisher_db=db)
            assert 0 <= result.trust_score <= 1, f"Score out of bounds for {url}"
