"""
Tests for data models.
TDD: Write these tests FIRST, then implement models.py
"""
import pytest


class TestSignal:
    """Tests for the Signal model."""
    
    def test_signal_creation(self):
        """Signal can be created with valid parameters."""
        from truthcheck.models import Signal
        
        signal = Signal(
            name="publisher",
            score=0.8,
            confidence=0.9,
            details={"name": "Reuters"}
        )
        
        assert signal.name == "publisher"
        assert signal.score == 0.8
        assert signal.confidence == 0.9
        assert signal.details["name"] == "Reuters"
    
    def test_signal_score_must_be_between_0_and_1(self):
        """Signal score must be in range [0, 1]."""
        from truthcheck.models import Signal
        
        # Valid boundary values
        Signal(name="test", score=0.0, confidence=0.5, details={})
        Signal(name="test", score=1.0, confidence=0.5, details={})
        
        # Invalid: too high
        with pytest.raises(ValueError, match="[Ss]core"):
            Signal(name="test", score=1.5, confidence=0.5, details={})
        
        # Invalid: negative
        with pytest.raises(ValueError, match="[Ss]core"):
            Signal(name="test", score=-0.1, confidence=0.5, details={})
    
    def test_signal_confidence_must_be_between_0_and_1(self):
        """Signal confidence must be in range [0, 1]."""
        from truthcheck.models import Signal
        
        # Valid boundary values
        Signal(name="test", score=0.5, confidence=0.0, details={})
        Signal(name="test", score=0.5, confidence=1.0, details={})
        
        # Invalid: too high
        with pytest.raises(ValueError, match="[Cc]onfidence"):
            Signal(name="test", score=0.5, confidence=1.1, details={})
        
        # Invalid: negative
        with pytest.raises(ValueError, match="[Cc]onfidence"):
            Signal(name="test", score=0.5, confidence=-0.5, details={})


class TestPublisher:
    """Tests for the Publisher model."""
    
    def test_publisher_creation(self):
        """Publisher can be created with required fields."""
        from truthcheck.models import Publisher
        
        publisher = Publisher(
            domain="reuters.com",
            name="Reuters",
            trust_score=0.95,
            category="news"
        )
        
        assert publisher.domain == "reuters.com"
        assert publisher.name == "Reuters"
        assert publisher.trust_score == 0.95
        assert publisher.category == "news"
    
    def test_publisher_from_yaml(self):
        """Publisher can be created from YAML content."""
        from truthcheck.models import Publisher
        
        yaml_content = """
domain: reuters.com
name: Reuters
trust_score: 0.95
category: news
"""
        publisher = Publisher.from_yaml(yaml_content)
        
        assert publisher.domain == "reuters.com"
        assert publisher.name == "Reuters"
        assert publisher.trust_score == 0.95
        assert publisher.category == "news"
    
    def test_publisher_from_yaml_with_optional_fields(self):
        """Publisher handles optional fields from YAML."""
        from truthcheck.models import Publisher
        
        yaml_content = """
domain: nytimes.com
name: The New York Times
trust_score: 0.9
category: news
bias: center-left
fact_check_rating: high
verified: true
"""
        publisher = Publisher.from_yaml(yaml_content)
        
        assert publisher.domain == "nytimes.com"
        assert publisher.bias == "center-left"
        assert publisher.fact_check_rating == "high"
        assert publisher.verified == True
    
    def test_publisher_from_yaml_missing_required_field(self):
        """Publisher raises error when required field is missing."""
        from truthcheck.models import Publisher
        
        yaml_content = """
domain: example.com
name: Example
# missing trust_score and category
"""
        with pytest.raises((ValueError, TypeError, KeyError)):
            Publisher.from_yaml(yaml_content)
    
    def test_publisher_trust_score_bounds(self):
        """Publisher trust_score must be in range [0, 1]."""
        from truthcheck.models import Publisher
        
        with pytest.raises(ValueError):
            Publisher(
                domain="bad.com",
                name="Bad",
                trust_score=1.5,
                category="news"
            )


class TestVerificationResult:
    """Tests for the VerificationResult model."""
    
    def test_verification_result_creation(self):
        """VerificationResult can be created with valid parameters."""
        from truthcheck.models import VerificationResult, Signal
        
        signals = {
            "publisher": Signal("publisher", 0.8, 0.9, {"name": "Test"})
        }
        
        result = VerificationResult(
            url="https://example.com/article",
            trust_score=0.8,
            recommendation="TRUST",
            signals=signals
        )
        
        assert result.url == "https://example.com/article"
        assert result.trust_score == 0.8
        assert result.recommendation == "TRUST"
        assert "publisher" in result.signals
    
    def test_verification_result_recommendation_values(self):
        """VerificationResult recommendation must be valid."""
        from truthcheck.models import VerificationResult
        
        # Valid recommendations
        for rec in ["TRUST", "CAUTION", "REJECT"]:
            result = VerificationResult(
                url="https://example.com",
                trust_score=0.5,
                recommendation=rec,
                signals={}
            )
            assert result.recommendation == rec
    
    def test_verification_result_invalid_recommendation(self):
        """VerificationResult rejects invalid recommendation."""
        from truthcheck.models import VerificationResult
        
        with pytest.raises((ValueError, TypeError)):
            VerificationResult(
                url="https://example.com",
                trust_score=0.5,
                recommendation="INVALID",
                signals={}
            )


class TestGetRecommendation:
    """Tests for the get_recommendation helper function."""
    
    def test_high_score_returns_trust(self):
        """Score >= 0.8 returns TRUST."""
        from truthcheck.models import get_recommendation
        
        assert get_recommendation(0.8) == "TRUST"
        assert get_recommendation(0.9) == "TRUST"
        assert get_recommendation(1.0) == "TRUST"
    
    def test_medium_score_returns_caution(self):
        """Score 0.5-0.79 returns CAUTION."""
        from truthcheck.models import get_recommendation
        
        assert get_recommendation(0.5) == "CAUTION"
        assert get_recommendation(0.6) == "CAUTION"
        assert get_recommendation(0.79) == "CAUTION"
    
    def test_low_score_returns_reject(self):
        """Score < 0.5 returns REJECT."""
        from truthcheck.models import get_recommendation
        
        assert get_recommendation(0.0) == "REJECT"
        assert get_recommendation(0.3) == "REJECT"
        assert get_recommendation(0.49) == "REJECT"
    
    def test_boundary_values(self):
        """Boundary values are handled correctly."""
        from truthcheck.models import get_recommendation
        
        # Exactly 0.8 should be TRUST
        assert get_recommendation(0.8) == "TRUST"
        
        # Just below 0.8 should be CAUTION
        assert get_recommendation(0.799) == "CAUTION"
        
        # Exactly 0.5 should be CAUTION
        assert get_recommendation(0.5) == "CAUTION"
        
        # Just below 0.5 should be REJECT
        assert get_recommendation(0.499) == "REJECT"


class TestTraceResult:
    """Tests for the TraceResult model."""
    
    def test_trace_result_creation(self):
        """TraceResult can be created with valid parameters."""
        from truthcheck.models import TraceResult
        
        result = TraceResult(
            claim="The earth is flat",
            verdict="FALSE",
            confidence=0.95,
            summary="This claim is false according to scientific consensus.",
            fact_checks=[],
            sources=[],
            origin=None
        )
        
        assert result.claim == "The earth is flat"
        assert result.verdict == "FALSE"
        assert result.confidence == 0.95
    
    def test_trace_result_verdict_values(self):
        """TraceResult verdict must be valid."""
        from truthcheck.models import TraceResult
        
        for verdict in ["TRUE", "FALSE", "MIXED", "UNVERIFIED"]:
            result = TraceResult(
                claim="Test",
                verdict=verdict,
                confidence=0.5,
                summary="Test",
                fact_checks=[],
                sources=[],
                origin=None
            )
            assert result.verdict == verdict
    
    def test_trace_result_invalid_verdict(self):
        """TraceResult rejects invalid verdict."""
        from truthcheck.models import TraceResult
        
        with pytest.raises((ValueError, TypeError)):
            TraceResult(
                claim="Test",
                verdict="MAYBE",  # Invalid
                confidence=0.5,
                summary="Test",
                fact_checks=[],
                sources=[],
                origin=None
            )


class TestFactCheck:
    """Tests for the FactCheck model."""
    
    def test_fact_check_creation(self):
        """FactCheck can be created with valid parameters."""
        from truthcheck.models import FactCheck
        
        fc = FactCheck(
            source="snopes.com",
            url="https://snopes.com/fact-check/example",
            rating="FALSE"
        )
        
        assert fc.source == "snopes.com"
        assert fc.url == "https://snopes.com/fact-check/example"
        assert fc.rating == "FALSE"


class TestSearchResult:
    """Tests for the SearchResult model."""
    
    def test_search_result_creation(self):
        """SearchResult can be created with valid parameters."""
        from truthcheck.models import SearchResult
        
        result = SearchResult(
            url="https://example.com/article",
            title="Example Article",
            snippet="This is a snippet from the article.",
            source="brave"
        )
        
        assert result.url == "https://example.com/article"
        assert result.title == "Example Article"
        assert result.snippet == "This is a snippet from the article."
        assert result.source == "brave"
