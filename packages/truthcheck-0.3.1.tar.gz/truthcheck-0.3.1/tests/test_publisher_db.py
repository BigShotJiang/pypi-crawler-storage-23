"""
Tests for Publisher Database.
TDD: Write these tests FIRST, then implement publisher_db.py
"""
import json
import pytest
from pathlib import Path


def create_yaml_publisher(path: Path, domain: str, name: str, trust_score: float, category: str = "news"):
    """Helper to create a publisher YAML file in the overrides directory."""
    overrides_dir = path / "publishers"
    overrides_dir.mkdir(exist_ok=True)
    
    yaml_file = overrides_dir / f"{domain}.yaml"
    yaml_file.write_text(f"""
domain: {domain}
name: {name}
trust_score: {trust_score}
category: {category}
""")


def create_json_db(path: Path, publishers: dict):
    """Helper to create a JSON database."""
    db_file = path / "publishers.json"
    db_file.write_text(json.dumps({
        "meta": {"source": "test", "count": len(publishers)},
        "publishers": publishers
    }))


class TestPublisherDB:
    """Tests for the PublisherDB class."""
    
    def test_load_single_publisher(self, tmp_path):
        """Load a single publisher from YAML override."""
        from truthcheck.publisher_db import PublisherDB
        
        create_yaml_publisher(tmp_path, "reuters.com", "Reuters", 0.95, "news")
        
        db = PublisherDB(tmp_path)
        publisher = db.lookup("reuters.com")
        
        assert publisher is not None
        assert publisher.name == "Reuters"
        assert publisher.trust_score == 0.95
    
    def test_load_multiple_publishers(self, tmp_path):
        """Load multiple publishers from JSON database."""
        from truthcheck.publisher_db import PublisherDB
        
        create_json_db(tmp_path, {
            "a.com": {"name": "Site A", "trust_score": 0.8, "credibility": "high"},
            "b.com": {"name": "Site B", "trust_score": 0.6, "credibility": "medium"},
        })
        
        db = PublisherDB(tmp_path)
        
        assert db.lookup("a.com") is not None
        assert db.lookup("b.com") is not None
        assert len(db) == 2
    
    def test_lookup_unknown_publisher(self, tmp_path):
        """Unknown publisher returns None."""
        from truthcheck.publisher_db import PublisherDB
        
        db = PublisherDB(tmp_path)
        assert db.lookup("unknown-site.com") is None
    
    def test_lookup_with_www_prefix(self, tmp_path):
        """Lookup normalizes www prefix."""
        from truthcheck.publisher_db import PublisherDB
        
        create_json_db(tmp_path, {
            "example.com": {"name": "Example", "trust_score": 0.7}
        })
        
        db = PublisherDB(tmp_path)
        
        # www.example.com should match example.com
        assert db.lookup("www.example.com") is not None
        assert db.lookup("www.example.com").name == "Example"
    
    def test_lookup_subdomain_matches_parent(self, tmp_path):
        """Subdomain lookup falls back to parent domain."""
        from truthcheck.publisher_db import PublisherDB
        
        create_json_db(tmp_path, {
            "nytimes.com": {"name": "NYT", "trust_score": 0.9}
        })
        
        db = PublisherDB(tmp_path)
        
        # cooking.nytimes.com should match nytimes.com
        assert db.lookup("cooking.nytimes.com") is not None
        assert db.lookup("cooking.nytimes.com").name == "NYT"
        
        # api.nytimes.com should also match
        assert db.lookup("api.nytimes.com") is not None
    
    def test_lookup_case_insensitive(self, tmp_path):
        """Lookup is case insensitive."""
        from truthcheck.publisher_db import PublisherDB
        
        create_json_db(tmp_path, {
            "example.com": {"name": "Example", "trust_score": 0.7}
        })
        
        db = PublisherDB(tmp_path)
        
        assert db.lookup("EXAMPLE.COM") is not None
        assert db.lookup("Example.Com") is not None
    
    def test_skip_template_files(self, tmp_path):
        """Files starting with _ are skipped."""
        from truthcheck.publisher_db import PublisherDB
        
        overrides_dir = tmp_path / "publishers"
        overrides_dir.mkdir()
        
        (overrides_dir / "_template.yaml").write_text("""
domain: template.com
name: Template
trust_score: 0.5
category: other
""")
        (overrides_dir / "real.com.yaml").write_text("""
domain: real.com
name: Real
trust_score: 0.8
category: news
""")
        
        db = PublisherDB(tmp_path)
        
        assert db.lookup("template.com") is None
        assert db.lookup("real.com") is not None
        assert len(db) == 1
    
    def test_skip_non_yaml_files(self, tmp_path):
        """Non-YAML files are skipped."""
        from truthcheck.publisher_db import PublisherDB
        
        overrides_dir = tmp_path / "publishers"
        overrides_dir.mkdir()
        
        (overrides_dir / "readme.md").write_text("# Publishers")
        (overrides_dir / "index.json").write_text("{}")
        create_yaml_publisher(tmp_path, "real.com", "Real", 0.8, "news")
        
        db = PublisherDB(tmp_path)
        assert len(db) == 1
    
    def test_empty_directory(self, tmp_path):
        """Empty directory creates empty DB."""
        from truthcheck.publisher_db import PublisherDB
        
        db = PublisherDB(tmp_path)
        assert len(db) == 0
        assert db.lookup("anything.com") is None
    
    def test_invalid_yaml_skipped(self, tmp_path):
        """Invalid YAML files are skipped with warning."""
        from truthcheck.publisher_db import PublisherDB
        
        overrides_dir = tmp_path / "publishers"
        overrides_dir.mkdir()
        
        (overrides_dir / "bad.com.yaml").write_text("""
this is not valid yaml: [
""")
        create_yaml_publisher(tmp_path, "good.com", "Good", 0.8, "news")
        
        # Should not raise, just skip bad file
        db = PublisherDB(tmp_path)
        assert len(db) == 1
        assert db.lookup("good.com") is not None
    
    def test_missing_required_fields_skipped(self, tmp_path):
        """YAML missing required fields is skipped."""
        from truthcheck.publisher_db import PublisherDB
        
        overrides_dir = tmp_path / "publishers"
        overrides_dir.mkdir()
        
        (overrides_dir / "incomplete.com.yaml").write_text("""
domain: incomplete.com
name: Incomplete
# missing trust_score and category
""")
        create_yaml_publisher(tmp_path, "complete.com", "Complete", 0.8, "news")
        
        db = PublisherDB(tmp_path)
        assert len(db) == 1
        assert db.lookup("complete.com") is not None
        assert db.lookup("incomplete.com") is None
    
    def test_get_all_publishers(self, tmp_path):
        """Can iterate over all publishers."""
        from truthcheck.publisher_db import PublisherDB
        
        create_json_db(tmp_path, {
            "a.com": {"name": "A", "trust_score": 0.8},
            "b.com": {"name": "B", "trust_score": 0.6},
        })
        
        db = PublisherDB(tmp_path)
        all_publishers = list(db.all())
        
        assert len(all_publishers) == 2
        domains = [p.domain for p in all_publishers]
        assert "a.com" in domains
        assert "b.com" in domains
    
    def test_default_data_path(self):
        """DB can use default data path."""
        from truthcheck.publisher_db import PublisherDB
        
        # Should not raise - uses bundled data
        db = PublisherDB()
        # We have synced publishers
        assert db.lookup("reuters.com") is not None
    
    def test_lookup_from_url(self, tmp_path):
        """Convenience method to lookup from full URL."""
        from truthcheck.publisher_db import PublisherDB
        
        create_json_db(tmp_path, {
            "example.com": {"name": "Example", "trust_score": 0.7}
        })
        
        db = PublisherDB(tmp_path)
        
        publisher = db.lookup_url("https://www.example.com/article/123")
        assert publisher is not None
        assert publisher.name == "Example"
    
    def test_yaml_overrides_json(self, tmp_path):
        """YAML files override JSON database entries."""
        from truthcheck.publisher_db import PublisherDB
        
        # JSON has a publisher
        create_json_db(tmp_path, {
            "example.com": {"name": "From JSON", "trust_score": 0.5}
        })
        
        # YAML overrides it
        create_yaml_publisher(tmp_path, "example.com", "From YAML Override", 0.9, "news")
        
        db = PublisherDB(tmp_path)
        publisher = db.lookup("example.com")
        
        assert publisher.name == "From YAML Override"
        assert publisher.trust_score == 0.9
    
    def test_meta_from_json(self, tmp_path):
        """Database metadata comes from JSON."""
        from truthcheck.publisher_db import PublisherDB
        
        db_file = tmp_path / "publishers.json"
        db_file.write_text(json.dumps({
            "meta": {
                "source": "test",
                "mbfc_date": "2026-01-01",
                "count": 1
            },
            "publishers": {
                "test.com": {"name": "Test", "trust_score": 0.5}
            }
        }))
        
        db = PublisherDB(tmp_path)
        
        assert db.meta["source"] == "test"
        assert db.meta["mbfc_date"] == "2026-01-01"
