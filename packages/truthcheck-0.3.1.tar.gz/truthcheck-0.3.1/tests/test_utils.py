"""
Tests for utility functions.
TDD: Write these tests FIRST, then implement utils.py
"""
import pytest


class TestExtractDomain:
    """Tests for the extract_domain function."""
    
    def test_extract_domain_simple_https(self):
        """Extract domain from simple HTTPS URL."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("https://example.com/page") == "example.com"
    
    def test_extract_domain_simple_http(self):
        """Extract domain from simple HTTP URL."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("http://example.com/page") == "example.com"
    
    def test_extract_domain_with_www(self):
        """Extract domain strips www prefix."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("https://www.example.com/page") == "example.com"
    
    def test_extract_domain_subdomain_preserved(self):
        """Subdomains other than www are preserved."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("https://blog.example.com") == "blog.example.com"
        assert extract_domain("https://api.example.com/v1") == "api.example.com"
    
    def test_extract_domain_with_port(self):
        """Extract domain ignores port number."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("https://example.com:8080/page") == "example.com"
    
    def test_extract_domain_with_query_string(self):
        """Extract domain ignores query string."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("https://example.com/page?foo=bar") == "example.com"
    
    def test_extract_domain_with_fragment(self):
        """Extract domain ignores fragment."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("https://example.com/page#section") == "example.com"
    
    def test_extract_domain_no_scheme(self):
        """Extract domain handles missing scheme."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("example.com/page") == "example.com"
        assert extract_domain("www.example.com") == "example.com"
    
    def test_extract_domain_uppercase(self):
        """Extract domain normalizes to lowercase."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("https://EXAMPLE.COM/page") == "example.com"
        assert extract_domain("https://Example.Com/page") == "example.com"
    
    def test_extract_domain_invalid_url(self):
        """Extract domain raises error for invalid URL."""
        from truthcheck.utils import extract_domain
        
        with pytest.raises(ValueError):
            extract_domain("not-a-url")
        
        with pytest.raises(ValueError):
            extract_domain("")
    
    def test_extract_domain_complex_paths(self):
        """Extract domain handles complex URL paths."""
        from truthcheck.utils import extract_domain
        
        assert extract_domain("https://nytimes.com/2024/01/01/world/article.html") == "nytimes.com"
        assert extract_domain("https://reuters.com/article/us-economy/story-123") == "reuters.com"


class TestNormalizeDomain:
    """Tests for the normalize_domain function."""
    
    def test_normalize_removes_www(self):
        """Normalize domain removes www prefix."""
        from truthcheck.utils import normalize_domain
        
        assert normalize_domain("www.example.com") == "example.com"
    
    def test_normalize_lowercase(self):
        """Normalize domain converts to lowercase."""
        from truthcheck.utils import normalize_domain
        
        assert normalize_domain("EXAMPLE.COM") == "example.com"
        assert normalize_domain("Example.Com") == "example.com"
    
    def test_normalize_preserves_subdomains(self):
        """Normalize domain preserves non-www subdomains."""
        from truthcheck.utils import normalize_domain
        
        assert normalize_domain("blog.example.com") == "blog.example.com"
        assert normalize_domain("www.blog.example.com") == "blog.example.com"
    
    def test_normalize_strips_whitespace(self):
        """Normalize domain strips whitespace."""
        from truthcheck.utils import normalize_domain
        
        assert normalize_domain("  example.com  ") == "example.com"


class TestGetParentDomain:
    """Tests for the get_parent_domain function."""
    
    def test_parent_domain_from_subdomain(self):
        """Get parent domain from subdomain."""
        from truthcheck.utils import get_parent_domain
        
        assert get_parent_domain("blog.example.com") == "example.com"
        assert get_parent_domain("api.blog.example.com") == "blog.example.com"
    
    def test_parent_domain_from_root(self):
        """Get parent domain from root returns None."""
        from truthcheck.utils import get_parent_domain
        
        assert get_parent_domain("example.com") is None
    
    def test_parent_domain_from_tld(self):
        """Get parent domain from TLD-like returns None."""
        from truthcheck.utils import get_parent_domain
        
        assert get_parent_domain("com") is None


class TestFetchContent:
    """Tests for the fetch_content function."""
    
    def test_fetch_content_success(self, mocker):
        """Fetch content returns text from URL."""
        from truthcheck.utils import fetch_content
        
        mock_response = mocker.Mock()
        mock_response.text = "<html><body>Hello World</body></html>"
        mock_response.raise_for_status = mocker.Mock()
        mocker.patch("requests.get", return_value=mock_response)
        
        content = fetch_content("https://example.com")
        assert "Hello World" in content
    
    def test_fetch_content_timeout(self, mocker):
        """Fetch content handles timeout."""
        from truthcheck.utils import fetch_content
        import requests
        
        mocker.patch("requests.get", side_effect=requests.Timeout())
        
        with pytest.raises(Exception):  # Could be custom exception
            fetch_content("https://example.com")
    
    def test_fetch_content_404(self, mocker):
        """Fetch content handles 404."""
        from truthcheck.utils import fetch_content
        import requests
        
        mock_response = mocker.Mock()
        mock_response.raise_for_status.side_effect = requests.HTTPError("404")
        mocker.patch("requests.get", return_value=mock_response)
        
        with pytest.raises(Exception):
            fetch_content("https://example.com/not-found")
