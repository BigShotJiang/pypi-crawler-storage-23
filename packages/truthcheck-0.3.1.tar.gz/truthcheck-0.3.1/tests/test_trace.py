"""
Tests for verify_claim.
TDD: Write these tests FIRST, then implement trace.py
"""
import pytest
from unittest.mock import Mock


class TestSearchProvider:
    """Tests for search provider abstraction."""
    
    def test_brave_provider_interface(self):
        """BraveSearchProvider has correct interface."""
        from truthcheck.search import BraveSearchProvider
        
        provider = BraveSearchProvider(api_key="test-key")
        assert hasattr(provider, "search")
    
    def test_search_result_model(self):
        """SearchResult model works correctly."""
        from truthcheck.models import SearchResult
        
        result = SearchResult(
            url="https://example.com",
            title="Example",
            snippet="Test snippet",
            source="brave"
        )
        assert result.url == "https://example.com"


class TestClaimTracer:
    """Tests for the ClaimTracer class."""
    
    @pytest.fixture
    def mock_search_provider(self):
        """Create a mock search provider."""
        provider = Mock()
        provider.search.return_value = [
            Mock(
                url="https://snopes.com/fact-check/test-claim",
                title="Fact Check: Test Claim is False",
                snippet="Our investigation found this claim to be FALSE.",
                source="brave"
            ),
            Mock(
                url="https://reuters.com/article/related",
                title="Reuters: Related News",
                snippet="According to official sources...",
                source="brave"
            ),
            Mock(
                url="https://random-blog.com/post",
                title="My Opinion on This",
                snippet="I think this is true because reasons...",
                source="brave"
            ),
        ]
        return provider
    
    def test_tracer_requires_search_provider(self):
        """ClaimTracer requires a search provider."""
        from truthcheck.trace import ClaimTracer
        
        with pytest.raises((ValueError, TypeError)):
            ClaimTracer(search_provider=None)
    
    def test_trace_returns_result(self, mock_search_provider):
        """trace() returns a TraceResult."""
        from truthcheck.trace import ClaimTracer
        from truthcheck.models import TraceResult
        
        tracer = ClaimTracer(search_provider=mock_search_provider)
        result = tracer.trace("Test claim")
        
        assert isinstance(result, TraceResult)
        assert result.claim == "Test claim"
    
    def test_trace_identifies_fact_checks(self, mock_search_provider):
        """trace() identifies fact-check sources."""
        from truthcheck.trace import ClaimTracer
        
        tracer = ClaimTracer(search_provider=mock_search_provider)
        result = tracer.trace("Test claim")
        
        # Should find Snopes as a fact-checker
        fact_check_urls = [fc.url for fc in result.fact_checks]
        assert any("snopes.com" in url for url in fact_check_urls)
    
    def test_trace_returns_verdict(self, mock_search_provider):
        """trace() returns a verdict."""
        from truthcheck.trace import ClaimTracer
        
        tracer = ClaimTracer(search_provider=mock_search_provider)
        result = tracer.trace("Test claim")
        
        assert result.verdict in ["TRUE", "FALSE", "MIXED", "UNVERIFIED"]
    
    def test_trace_returns_confidence(self, mock_search_provider):
        """trace() returns confidence score."""
        from truthcheck.trace import ClaimTracer
        
        tracer = ClaimTracer(search_provider=mock_search_provider)
        result = tracer.trace("Test claim")
        
        assert 0 <= result.confidence <= 1
    
    def test_trace_returns_sources(self, mock_search_provider):
        """trace() returns list of sources."""
        from truthcheck.trace import ClaimTracer
        
        tracer = ClaimTracer(search_provider=mock_search_provider)
        result = tracer.trace("Test claim")
        
        assert len(result.sources) > 0
    
    def test_is_fact_check_domain(self, mock_search_provider):
        """_is_fact_check_domain identifies known fact-checkers."""
        from truthcheck.trace import ClaimTracer
        
        tracer = ClaimTracer(search_provider=mock_search_provider)
        
        assert tracer._is_fact_check_domain("snopes.com") == True
        assert tracer._is_fact_check_domain("politifact.com") == True
        assert tracer._is_fact_check_domain("factcheck.org") == True
        assert tracer._is_fact_check_domain("random-blog.com") == False
    
    def test_extract_rating_from_snippet(self, mock_search_provider):
        """_extract_rating parses rating from text."""
        from truthcheck.trace import ClaimTracer
        
        tracer = ClaimTracer(search_provider=mock_search_provider)
        
        assert tracer._extract_rating("This claim is FALSE") == "FALSE"
        assert tracer._extract_rating("Rating: True") == "TRUE"
        assert tracer._extract_rating("Verdict: Mostly False") == "FALSE"
        assert tracer._extract_rating("No clear rating here") is None


class TestTraceClaim:
    """Tests for the verify_claim convenience function."""
    
    def test_verify_claim_without_provider_raises(self):
        """verify_claim without search provider raises error."""
        from truthcheck.trace import verify_claim
        
        with pytest.raises(ValueError, match="[Ss]earch"):
            verify_claim("Some claim")
    
    def test_verify_claim_with_api_key(self, mocker):
        """verify_claim works with API key."""
        from truthcheck.trace import verify_claim
        from truthcheck.models import TraceResult
        
        # Mock the search provider
        mock_provider_class = mocker.patch("truthscore.trace.BraveSearchProvider")
        mock_provider = Mock()
        mock_provider.search.return_value = [
            Mock(
                url="https://snopes.com/fact-check/test",
                title="Fact Check",
                snippet="This is FALSE",
                source="brave"
            )
        ]
        mock_provider_class.return_value = mock_provider
        
        result = verify_claim("Test claim", search_api_key="test-key")
        
        assert isinstance(result, TraceResult)
        assert result.claim == "Test claim"
