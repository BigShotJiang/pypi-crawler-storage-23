"""
Tests for CLI.
TDD: Write these tests FIRST, then implement cli.py
"""
import pytest
import json
from click.testing import CliRunner


class TestCLI:
    """Tests for the command-line interface."""
    
    @pytest.fixture
    def runner(self):
        """Create a CLI test runner."""
        return CliRunner()
    
    def test_cli_has_help(self, runner):
        """CLI has help option."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["--help"])
        
        assert result.exit_code == 0
        assert "TruthScore" in result.output or "truthscore" in result.output.lower()
    
    def test_cli_has_version(self, runner):
        """CLI has version option."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["--version"])
        
        assert result.exit_code == 0
        assert "0.1" in result.output
    
    def test_check_command_exists(self, runner):
        """Check command exists."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["check", "--help"])
        
        assert result.exit_code == 0
        assert "URL" in result.output or "url" in result.output.lower()
    
    def test_check_known_publisher(self, runner):
        """Check returns result for known publisher."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["check", "https://reuters.com/article"])
        
        assert result.exit_code == 0
        assert "Trust Score" in result.output or "trust" in result.output.lower()
        assert "TRUST" in result.output or "0.9" in result.output
    
    def test_check_unknown_publisher(self, runner):
        """Check returns result for unknown publisher."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["check", "https://unknown-random-site.com/page"])
        
        assert result.exit_code == 0
        assert "Trust Score" in result.output or "trust" in result.output.lower()
    
    def test_check_json_output(self, runner):
        """Check can output JSON."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["check", "https://reuters.com", "--json"])
        
        assert result.exit_code == 0
        
        # Should be valid JSON
        data = json.loads(result.output)
        assert "trust_score" in data
        assert "recommendation" in data
        assert "signals" in data
    
    def test_check_verbose_output(self, runner):
        """Check verbose shows more details."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["check", "https://reuters.com", "-v"])
        
        assert result.exit_code == 0
        # Should show signal details
        assert "publisher" in result.output.lower()
    
    def test_check_invalid_url(self, runner):
        """Check handles invalid URL gracefully."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["check", "not-a-url"])
        
        # Should not crash
        assert result.exit_code == 0
        assert "Trust Score" in result.output or "CAUTION" in result.output
    
    def test_trace_command_exists(self, runner):
        """Trace command exists."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["trace", "--help"])
        
        assert result.exit_code == 0
        assert "claim" in result.output.lower()
    
    def test_trace_requires_search_key(self, runner, monkeypatch):
        """Trace requires search API key."""
        from truthcheck.cli import cli
        
        # Ensure no search key
        monkeypatch.delenv("TRUTHSCORE_SEARCH_KEY", raising=False)
        
        result = runner.invoke(cli, ["trace", "Some claim to trace"])
        
        # Should fail or warn about missing key
        assert result.exit_code != 0 or "search" in result.output.lower() or "api" in result.output.lower()
    
    def test_lookup_command(self, runner):
        """Lookup command shows publisher info."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["lookup", "reuters.com"])
        
        assert result.exit_code == 0
        assert "Reuters" in result.output
        # Score varies by MBFC data version, just check it's high
        assert "0.8" in result.output or "0.9" in result.output
    
    def test_lookup_unknown(self, runner):
        """Lookup unknown publisher shows not found."""
        from truthcheck.cli import cli
        
        result = runner.invoke(cli, ["lookup", "unknown-site-12345.com"])
        
        assert result.exit_code == 0
        assert "not found" in result.output.lower() or "unknown" in result.output.lower()
