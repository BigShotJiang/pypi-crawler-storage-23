"""
Tests for Scorer.
TDD: Write these tests FIRST, then implement scorer.py
"""
import pytest
from truthcheck.models import Signal


class TestScorer:
    """Tests for the Scorer class."""
    
    def test_calculate_single_signal(self):
        """Calculate score from single signal."""
        from truthcheck.scorer import Scorer
        
        signals = {
            "publisher": Signal("publisher", 0.9, 0.9, {})
        }
        
        scorer = Scorer()
        result = scorer.calculate(signals, url="https://example.com")
        
        assert result.trust_score == pytest.approx(0.9, rel=0.1)
        assert result.url == "https://example.com"
    
    def test_calculate_multiple_signals(self):
        """Calculate weighted average from multiple signals."""
        from truthcheck.scorer import Scorer
        
        signals = {
            "publisher": Signal("publisher", 0.9, 0.9, {}),
            "content": Signal("content", 0.7, 0.6, {}),
        }
        
        scorer = Scorer()
        result = scorer.calculate(signals, url="https://example.com")
        
        # Should be weighted average
        assert 0.7 < result.trust_score < 0.9
    
    def test_publisher_has_highest_weight(self):
        """Publisher signal has highest weight."""
        from truthcheck.scorer import Scorer
        
        scorer = Scorer()
        
        # High publisher, low others
        signals1 = {
            "publisher": Signal("publisher", 0.95, 0.9, {}),
            "domain": Signal("domain", 0.3, 0.7, {}),
            "content": Signal("content", 0.3, 0.5, {}),
        }
        
        # Low publisher, high others
        signals2 = {
            "publisher": Signal("publisher", 0.2, 0.9, {}),
            "domain": Signal("domain", 0.9, 0.7, {}),
            "content": Signal("content", 0.9, 0.5, {}),
        }
        
        result1 = scorer.calculate(signals1, url="https://example.com")
        result2 = scorer.calculate(signals2, url="https://example.com")
        
        # Publisher weight should make result1 > result2
        assert result1.trust_score > result2.trust_score
    
    def test_recommendation_trust(self):
        """High score returns TRUST recommendation."""
        from truthcheck.scorer import Scorer
        
        signals = {
            "publisher": Signal("publisher", 0.95, 0.9, {}),
        }
        
        scorer = Scorer()
        result = scorer.calculate(signals, url="https://example.com")
        
        assert result.recommendation == "TRUST"
    
    def test_recommendation_caution(self):
        """Medium score returns CAUTION recommendation."""
        from truthcheck.scorer import Scorer
        
        signals = {
            "publisher": Signal("publisher", 0.65, 0.9, {}),
        }
        
        scorer = Scorer()
        result = scorer.calculate(signals, url="https://example.com")
        
        assert result.recommendation == "CAUTION"
    
    def test_recommendation_reject(self):
        """Low score returns REJECT recommendation."""
        from truthcheck.scorer import Scorer
        
        signals = {
            "publisher": Signal("publisher", 0.3, 0.9, {}),
        }
        
        scorer = Scorer()
        result = scorer.calculate(signals, url="https://example.com")
        
        assert result.recommendation == "REJECT"
    
    def test_confidence_affects_weight(self):
        """Lower confidence means less weight."""
        from truthcheck.scorer import Scorer
        
        scorer = Scorer()
        
        # High confidence bad signal
        signals1 = {
            "test": Signal("test", 0.2, 0.9, {}),
        }
        
        # Low confidence bad signal
        signals2 = {
            "test": Signal("test", 0.2, 0.2, {}),
        }
        
        result1 = scorer.calculate(signals1, url="https://example.com")
        result2 = scorer.calculate(signals2, url="https://example.com")
        
        # Low confidence should pull less toward the bad score
        # (though effect may be subtle with single signal)
        assert result2.trust_score >= result1.trust_score
    
    def test_empty_signals(self):
        """Empty signals returns neutral score."""
        from truthcheck.scorer import Scorer
        
        scorer = Scorer()
        result = scorer.calculate({}, url="https://example.com")
        
        assert result.trust_score == 0.5
        assert result.recommendation == "CAUTION"
    
    def test_result_contains_signals(self):
        """Result contains original signals."""
        from truthcheck.scorer import Scorer
        
        signals = {
            "publisher": Signal("publisher", 0.8, 0.9, {"name": "Test"}),
        }
        
        scorer = Scorer()
        result = scorer.calculate(signals, url="https://example.com")
        
        assert "publisher" in result.signals
        assert result.signals["publisher"].details["name"] == "Test"
    
    def test_score_bounds(self):
        """Score is always between 0 and 1."""
        from truthcheck.scorer import Scorer
        
        scorer = Scorer()
        
        # Very high signals
        high_signals = {
            "a": Signal("a", 1.0, 1.0, {}),
            "b": Signal("b", 1.0, 1.0, {}),
        }
        result = scorer.calculate(high_signals, url="https://example.com")
        assert 0 <= result.trust_score <= 1
        
        # Very low signals
        low_signals = {
            "a": Signal("a", 0.0, 1.0, {}),
            "b": Signal("b", 0.0, 1.0, {}),
        }
        result = scorer.calculate(low_signals, url="https://example.com")
        assert 0 <= result.trust_score <= 1
