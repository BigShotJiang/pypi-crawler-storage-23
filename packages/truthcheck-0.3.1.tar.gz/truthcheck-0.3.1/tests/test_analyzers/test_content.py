"""
Tests for Content Analyzer (L3).
TDD: Write these tests FIRST, then implement analyzers/content.py
"""
import pytest


class TestContentAnalyzer:
    """Tests for the L3 Content Analyzer."""
    
    def test_analyzer_has_name(self):
        """Analyzer has a name attribute."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        assert analyzer.name == "content"
    
    def test_analyze_clean_content(self):
        """Clean, professional content scores well."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        content = """
        By John Smith, Senior Reporter
        
        The Federal Reserve announced today that interest rates will remain 
        unchanged at 5.25%, citing stable inflation metrics and a resilient 
        labor market.
        
        Fed Chair Jerome Powell stated in a press conference that the committee
        will continue to monitor economic indicators closely.
        
        "We remain committed to our 2% inflation target," Powell said.
        """
        
        signal = analyzer.analyze("https://example.com", content)
        
        assert signal.name == "content"
        assert signal.score >= 0.7
        assert len(signal.details.get("flags", [])) == 0
    
    def test_analyze_clickbait_content(self):
        """Clickbait content scores poorly."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        content = """
        You WON'T BELIEVE What Just Happened!!!
        
        SHOCKING: This ONE WEIRD TRICK Will Change EVERYTHING!
        
        Scientists EXPOSED for hiding the TRUTH about what they don't
        want you to know! The mainstream media is LYING to you!
        """
        
        signal = analyzer.analyze("https://example.com", content)
        
        assert signal.score < 0.5
        assert "clickbait" in signal.details.get("flags", [])
    
    def test_analyze_excessive_caps(self):
        """Excessive caps are flagged."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        content = "THIS IS ALL CAPS AND VERY SHOUTY CONTENT THAT SEEMS UNTRUSTWORTHY"
        
        signal = analyzer.analyze("https://example.com", content)
        
        assert "excessive_caps" in signal.details.get("flags", [])
        assert signal.score < 0.7
    
    def test_analyze_missing_author(self):
        """Content without author attribution is flagged."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        content = """
        Some article content without any author attribution.
        This is just random text that doesn't have a byline.
        """
        
        signal = analyzer.analyze("https://example.com", content)
        
        assert "no_author" in signal.details.get("flags", [])
    
    def test_analyze_has_author(self):
        """Content with author is not flagged for missing author."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        content = """
        By Jane Doe
        
        This article has a proper author attribution.
        """
        
        signal = analyzer.analyze("https://example.com", content)
        
        assert "no_author" not in signal.details.get("flags", [])
    
    def test_analyze_author_variations(self):
        """Various author formats are recognized."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        
        author_formats = [
            "By John Smith",
            "by John Smith",
            "Author: John Smith",
            "Written by John Smith",
            "John Smith, Reporter",
        ]
        
        for content in author_formats:
            signal = analyzer.analyze("https://example.com", content)
            assert "no_author" not in signal.details.get("flags", []), f"Failed for: {content}"
    
    def test_analyze_sensational_language(self):
        """Sensational language is flagged."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        content = """
        BREAKING: Shocking revelations expose the horrifying truth!
        You won't believe what scientists discovered!
        This changes everything we know!
        """
        
        signal = analyzer.analyze("https://example.com", content)
        
        # Should have multiple flags
        flags = signal.details.get("flags", [])
        assert len(flags) >= 1
        assert signal.score < 0.6
    
    def test_analyze_empty_content(self):
        """Empty content returns neutral score."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        
        signal = analyzer.analyze("https://example.com", "")
        
        assert signal.score == 0.5
        assert signal.confidence <= 0.3
    
    def test_analyze_none_content(self):
        """None content returns neutral score."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        
        signal = analyzer.analyze("https://example.com", None)
        
        assert signal.score == 0.5
        assert signal.confidence <= 0.3
    
    def test_analyze_returns_signal(self):
        """Analyze always returns a Signal object."""
        from truthcheck.analyzers.content import ContentAnalyzer
        from truthcheck.models import Signal
        
        analyzer = ContentAnalyzer()
        
        signal = analyzer.analyze("https://example.com", "Some content")
        assert isinstance(signal, Signal)
    
    def test_score_bounds(self):
        """Score is always between 0 and 1."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        
        # Very bad content
        bad_content = "SHOCKING!!! YOU WON'T BELIEVE!!! EXPOSED!!! BREAKING!!!"
        signal = analyzer.analyze("https://example.com", bad_content)
        assert 0 <= signal.score <= 1
        
        # Good content
        good_content = "By John Smith. The quarterly report shows steady growth."
        signal = analyzer.analyze("https://example.com", good_content)
        assert 0 <= signal.score <= 1
    
    def test_multiple_flags_compound(self):
        """Multiple issues compound to lower score."""
        from truthcheck.analyzers.content import ContentAnalyzer
        
        analyzer = ContentAnalyzer()
        
        # Content with one issue
        one_issue = "YOU WON'T BELIEVE what happened next!"
        signal1 = analyzer.analyze("https://example.com", one_issue)
        
        # Content with multiple issues
        many_issues = "YOU WON'T BELIEVE!!! SHOCKING TRUTH EXPOSED!!! THEY DON'T WANT YOU TO KNOW!!!"
        signal2 = analyzer.analyze("https://example.com", many_issues)
        
        assert signal2.score <= signal1.score
