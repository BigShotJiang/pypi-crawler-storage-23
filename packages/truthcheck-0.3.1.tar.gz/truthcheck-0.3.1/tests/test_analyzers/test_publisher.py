"""
Tests for Publisher Analyzer (L1).
TDD: Write these tests FIRST, then implement analyzers/publisher.py
"""
import json
import pytest


class TestPublisherAnalyzer:
    """Tests for the L1 Publisher Analyzer."""
    
    @pytest.fixture
    def publisher_db(self, tmp_path):
        """Create a test publisher database."""
        from truthcheck.publisher_db import PublisherDB
        
        # Create JSON database
        db_file = tmp_path / "publishers.json"
        db_file.write_text(json.dumps({
            "meta": {"source": "test"},
            "publishers": {
                "trusted.com": {
                    "name": "Trusted News",
                    "trust_score": 0.9,
                    "credibility": "high",
                    "bias": "center"
                },
                "sketchy.com": {
                    "name": "Sketchy Site",
                    "trust_score": 0.3,
                    "credibility": "low"
                },
                "decent.com": {
                    "name": "Decent Site",
                    "trust_score": 0.7,
                    "credibility": "medium"
                }
            }
        }))
        
        return PublisherDB(tmp_path)
    
    def test_analyzer_has_name(self, publisher_db):
        """Analyzer has a name attribute."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        
        analyzer = PublisherAnalyzer(publisher_db)
        assert analyzer.name == "publisher"
    
    def test_analyze_trusted_publisher(self, publisher_db):
        """Trusted publisher returns high score."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        
        analyzer = PublisherAnalyzer(publisher_db)
        signal = analyzer.analyze("https://trusted.com/article")
        
        assert signal.name == "publisher"
        assert signal.score == 0.9
        assert signal.confidence >= 0.7  # High confidence for high-credibility
        assert signal.details["found"] == True
        assert signal.details["name"] == "Trusted News"
    
    def test_analyze_sketchy_publisher(self, publisher_db):
        """Sketchy publisher returns low score."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        
        analyzer = PublisherAnalyzer(publisher_db)
        signal = analyzer.analyze("https://sketchy.com/clickbait")
        
        assert signal.score == 0.3
        assert signal.details["found"] == True
    
    def test_analyze_unverified_publisher(self, publisher_db):
        """Medium-credibility publisher has lower confidence than high."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        
        analyzer = PublisherAnalyzer(publisher_db)
        
        high_cred_signal = analyzer.analyze("https://trusted.com/article")
        medium_cred_signal = analyzer.analyze("https://decent.com/article")
        
        # Medium credibility should have lower confidence
        assert medium_cred_signal.confidence <= high_cred_signal.confidence
    
    def test_analyze_unknown_publisher(self, publisher_db):
        """Unknown publisher returns neutral score with low confidence."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        
        analyzer = PublisherAnalyzer(publisher_db)
        signal = analyzer.analyze("https://unknown-site.com/page")
        
        assert signal.score == 0.5  # Neutral
        assert signal.confidence <= 0.3  # Low confidence
        assert signal.details["found"] == False
    
    def test_analyze_subdomain_matches_parent(self, publisher_db):
        """Subdomain lookup falls back to parent domain."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        
        analyzer = PublisherAnalyzer(publisher_db)
        signal = analyzer.analyze("https://blog.trusted.com/post")
        
        assert signal.score == 0.9
        assert signal.details["name"] == "Trusted News"
    
    def test_analyze_normalizes_url(self, publisher_db):
        """Analyzer normalizes URL before lookup."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        
        analyzer = PublisherAnalyzer(publisher_db)
        
        # All should match trusted.com
        urls = [
            "https://trusted.com/article",
            "https://www.trusted.com/article",
            "http://TRUSTED.COM/article",
            "trusted.com/article",
        ]
        
        for url in urls:
            signal = analyzer.analyze(url)
            assert signal.details["found"] == True, f"Failed for {url}"
            assert signal.details["name"] == "Trusted News"
    
    def test_analyze_returns_signal(self, publisher_db):
        """Analyze always returns a Signal object."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        from truthcheck.models import Signal
        
        analyzer = PublisherAnalyzer(publisher_db)
        
        # Known publisher
        signal1 = analyzer.analyze("https://trusted.com")
        assert isinstance(signal1, Signal)
        
        # Unknown publisher
        signal2 = analyzer.analyze("https://unknown.com")
        assert isinstance(signal2, Signal)
    
    def test_analyze_invalid_url(self, publisher_db):
        """Analyzer handles invalid URLs gracefully."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        
        analyzer = PublisherAnalyzer(publisher_db)
        
        # Should not raise, return low confidence
        signal = analyzer.analyze("not-a-valid-url")
        assert signal.confidence <= 0.2
        assert signal.details.get("error") is not None
    
    def test_analyze_with_content_ignored(self, publisher_db):
        """Content parameter is ignored by publisher analyzer."""
        from truthcheck.analyzers.publisher import PublisherAnalyzer
        
        analyzer = PublisherAnalyzer(publisher_db)
        
        # Content should not affect result
        signal1 = analyzer.analyze("https://trusted.com")
        signal2 = analyzer.analyze("https://trusted.com", content="Some content")
        
        assert signal1.score == signal2.score
        assert signal1.details == signal2.details
