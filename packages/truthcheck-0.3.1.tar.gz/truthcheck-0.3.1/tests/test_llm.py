"""
Tests for LLM providers.
TDD: Write these tests FIRST, then implement llm.py
"""
import pytest
from unittest.mock import Mock, patch


class TestLLMProvider:
    """Tests for LLM provider abstraction."""
    
    def test_openai_provider_interface(self):
        """OpenAI provider has correct interface."""
        from truthcheck.llm import OpenAIProvider
        
        provider = OpenAIProvider(api_key="test-key")
        assert hasattr(provider, "complete")
        assert hasattr(provider, "analyze_fact_check")
    
    def test_anthropic_provider_interface(self):
        """Anthropic provider has correct interface."""
        from truthcheck.llm import AnthropicProvider
        
        provider = AnthropicProvider(api_key="test-key")
        assert hasattr(provider, "complete")
        assert hasattr(provider, "analyze_fact_check")
    
    def test_ollama_provider_interface(self):
        """Ollama provider has correct interface."""
        from truthcheck.llm import OllamaProvider
        
        provider = OllamaProvider(model="llama3")
        assert hasattr(provider, "complete")
        assert hasattr(provider, "analyze_fact_check")
    
    def test_get_provider_openai(self):
        """get_provider returns OpenAI provider."""
        from truthcheck.llm import get_provider
        
        provider = get_provider("openai", api_key="test-key")
        assert provider.__class__.__name__ == "OpenAIProvider"
    
    def test_get_provider_anthropic(self):
        """get_provider returns Anthropic provider."""
        from truthcheck.llm import get_provider
        
        provider = get_provider("anthropic", api_key="test-key")
        assert provider.__class__.__name__ == "AnthropicProvider"
    
    def test_get_provider_ollama(self):
        """get_provider returns Ollama provider."""
        from truthcheck.llm import get_provider
        
        provider = get_provider("ollama", model="llama3")
        assert provider.__class__.__name__ == "OllamaProvider"
    
    def test_get_provider_unknown(self):
        """get_provider raises for unknown provider."""
        from truthcheck.llm import get_provider
        
        with pytest.raises(ValueError):
            get_provider("unknown-provider")


class TestAnalyzeFactCheck:
    """Tests for LLM fact-check analysis."""
    
    def test_analyze_returns_verdict(self, mocker):
        """analyze_fact_check returns verdict."""
        from truthcheck.llm import OpenAIProvider
        
        # Mock the API call
        mock_response = Mock()
        mock_response.choices = [Mock(message=Mock(content='{"verdict": "FALSE", "confidence": 0.9, "summary": "This is false"}'))]
        mocker.patch("openai.OpenAI")
        
        provider = OpenAIProvider(api_key="test")
        provider.client = Mock()
        provider.client.chat.completions.create.return_value = mock_response
        
        result = provider.analyze_fact_check(
            claim="Test claim",
            source_content="This claim has been debunked and is FALSE.",
            source_url="https://snopes.com/test"
        )
        
        assert "verdict" in result
        assert result["verdict"] in ["TRUE", "FALSE", "MIXED", "UNVERIFIED"]
    
    def test_analyze_returns_confidence(self, mocker):
        """analyze_fact_check returns confidence score."""
        from truthcheck.llm import OpenAIProvider
        
        mock_response = Mock()
        mock_response.choices = [Mock(message=Mock(content='{"verdict": "FALSE", "confidence": 0.85, "summary": "Test"}'))]
        mocker.patch("openai.OpenAI")
        
        provider = OpenAIProvider(api_key="test")
        provider.client = Mock()
        provider.client.chat.completions.create.return_value = mock_response
        
        result = provider.analyze_fact_check(
            claim="Test",
            source_content="Test content",
            source_url="https://example.com"
        )
        
        assert "confidence" in result
        assert 0 <= result["confidence"] <= 1
    
    def test_analyze_returns_summary(self, mocker):
        """analyze_fact_check returns summary."""
        from truthcheck.llm import OpenAIProvider
        
        mock_response = Mock()
        mock_response.choices = [Mock(message=Mock(content='{"verdict": "FALSE", "confidence": 0.9, "summary": "The claim is false because..."}'))]
        mocker.patch("openai.OpenAI")
        
        provider = OpenAIProvider(api_key="test")
        provider.client = Mock()
        provider.client.chat.completions.create.return_value = mock_response
        
        result = provider.analyze_fact_check(
            claim="Test",
            source_content="Test content",
            source_url="https://example.com"
        )
        
        assert "summary" in result
        assert len(result["summary"]) > 0


class TestTraceClaimWithLLM:
    """Tests for verify_claim with LLM support."""
    
    def test_trace_with_llm_provider(self, mocker):
        """verify_claim uses LLM when provided."""
        from truthcheck.trace import verify_claim
        from truthcheck.models import TraceResult
        
        # Mock search
        mock_search = Mock()
        mock_search.search.return_value = [
            Mock(url="https://snopes.com/test", title="Fact Check", snippet="FALSE", source="brave")
        ]
        
        # Mock LLM
        mock_llm = Mock()
        mock_llm.analyze_fact_check.return_value = {
            "verdict": "FALSE",
            "confidence": 0.9,
            "summary": "LLM determined this is false"
        }
        
        result = verify_claim(
            "Test claim",
            search_provider=mock_search,
            llm_provider=mock_llm
        )
        
        assert isinstance(result, TraceResult)
        # Should use LLM's verdict
        assert mock_llm.analyze_fact_check.called
    
    def test_trace_without_llm_uses_rules(self, mocker):
        """verify_claim falls back to rules without LLM."""
        from truthcheck.trace import verify_claim
        
        mock_search = Mock()
        mock_search.search.return_value = [
            Mock(url="https://snopes.com/test", title="Fact Check: FALSE", snippet="This is FALSE", source="brave")
        ]
        
        result = verify_claim(
            "Test claim",
            search_provider=mock_search,
            llm_provider=None  # No LLM
        )
        
        # Should still return a result using rules
        assert result.verdict in ["TRUE", "FALSE", "MIXED", "UNVERIFIED"]
