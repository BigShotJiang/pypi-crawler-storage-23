"""
Tests for MCP Server.
TDD: Write these tests FIRST, then implement mcp_server.py
"""
import pytest
import json


class TestMCPTools:
    """Tests for MCP tool definitions."""
    
    def test_get_tools_returns_list(self):
        """get_tools() returns list of tool definitions."""
        from truthcheck.mcp_server import get_tools
        
        tools = get_tools()
        
        assert isinstance(tools, list)
        assert len(tools) >= 2  # At least verify_source and verify_claim
    
    def test_verify_source_tool_defined(self):
        """verify_source tool is defined."""
        from truthcheck.mcp_server import get_tools
        
        tools = get_tools()
        tool_names = [t["name"] for t in tools]
        
        assert "verify_source" in tool_names
    
    def test_verify_claim_tool_defined(self):
        """verify_claim tool is defined."""
        from truthcheck.mcp_server import get_tools
        
        tools = get_tools()
        tool_names = [t["name"] for t in tools]
        
        assert "verify_claim" in tool_names
    
    def test_lookup_publisher_tool_defined(self):
        """lookup_publisher tool is defined."""
        from truthcheck.mcp_server import get_tools
        
        tools = get_tools()
        tool_names = [t["name"] for t in tools]
        
        assert "lookup_publisher" in tool_names
    
    def test_tools_have_descriptions(self):
        """All tools have descriptions."""
        from truthcheck.mcp_server import get_tools
        
        tools = get_tools()
        
        for tool in tools:
            assert "description" in tool
            assert len(tool["description"]) > 10


class TestMCPHandlers:
    """Tests for MCP tool handlers."""
    
    def test_handle_verify_source(self):
        """handle_verify_source returns verification result."""
        from truthcheck.mcp_server import handle_verify_source
        
        result = handle_verify_source({"url": "https://reuters.com/article"})
        
        assert "trust_score" in result
        assert "recommendation" in result
        assert result["recommendation"] in ["TRUST", "CAUTION", "REJECT"]
    
    def test_handle_verify_source_with_content(self):
        """handle_verify_source accepts optional content."""
        from truthcheck.mcp_server import handle_verify_source
        
        result = handle_verify_source({
            "url": "https://example.com",
            "content": "By John Smith. This is an article."
        })
        
        assert "trust_score" in result
        assert "signals" in result
    
    def test_handle_verify_source_invalid_url(self):
        """handle_verify_source handles invalid URL."""
        from truthcheck.mcp_server import handle_verify_source
        
        result = handle_verify_source({"url": "not-a-url"})
        
        # Should not crash, return result
        assert "trust_score" in result
    
    def test_handle_lookup_publisher_found(self):
        """handle_lookup_publisher returns publisher info."""
        from truthcheck.mcp_server import handle_lookup_publisher
        
        result = handle_lookup_publisher({"domain": "reuters.com"})
        
        assert result["found"] == True
        assert result["name"] == "Reuters"
        assert "trust_score" in result
    
    def test_handle_lookup_publisher_not_found(self):
        """handle_lookup_publisher handles unknown publisher."""
        from truthcheck.mcp_server import handle_lookup_publisher
        
        result = handle_lookup_publisher({"domain": "unknown-site-12345.com"})
        
        assert result["found"] == False
    
    def test_handle_verify_claim_no_api_key(self):
        """handle_verify_claim returns error without API key."""
        from truthcheck.mcp_server import handle_verify_claim
        
        result = handle_verify_claim({"claim": "Test claim"})
        
        # Should return error about missing API key
        assert "error" in result or result.get("verdict") == "UNVERIFIED"


class TestMCPCallTool:
    """Tests for the call_tool dispatcher."""
    
    def test_call_tool_verify_source(self):
        """call_tool dispatches to verify_source."""
        from truthcheck.mcp_server import call_tool
        
        result = call_tool("verify_source", {"url": "https://reuters.com"})
        
        assert "trust_score" in result
    
    def test_call_tool_lookup_publisher(self):
        """call_tool dispatches to lookup_publisher."""
        from truthcheck.mcp_server import call_tool
        
        result = call_tool("lookup_publisher", {"domain": "reuters.com"})
        
        assert "found" in result
    
    def test_call_tool_unknown(self):
        """call_tool returns error for unknown tool."""
        from truthcheck.mcp_server import call_tool
        
        result = call_tool("unknown_tool", {})
        
        assert "error" in result
