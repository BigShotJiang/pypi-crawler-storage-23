"""
Shared pytest fixtures for TruthScore tests.
"""
import json
import pytest
from pathlib import Path
import tempfile


def create_test_publisher_db(path: Path) -> Path:
    """Create a test publisher database in the given directory."""
    # Create JSON database
    db_file = path / "publishers.json"
    db_file.write_text(json.dumps({
        "meta": {"source": "test", "count": 3},
        "publishers": {
            "trusted.com": {
                "name": "Trusted News",
                "trust_score": 0.9,
                "credibility": "high",
                "bias": "center",
                "reporting": "high"
            },
            "sketchy.com": {
                "name": "Sketchy Site",
                "trust_score": 0.3,
                "credibility": "low",
                "flags": ["poor-sourcing"]
            },
            "decent.com": {
                "name": "Decent Site",
                "trust_score": 0.6,
                "credibility": "medium"
            },
            "reuters.com": {
                "name": "Reuters",
                "trust_score": 0.95,
                "credibility": "high",
                "bias": "center",
                "reporting": "very-high"
            }
        }
    }))
    return path


@pytest.fixture
def tmp_publisher_db(tmp_path):
    """Create a temporary publisher database with test data."""
    return create_test_publisher_db(tmp_path)


@pytest.fixture
def sample_clean_content():
    """Sample article content that should score well."""
    return """
    By John Smith, Senior Reporter
    
    The Federal Reserve announced today that interest rates will remain unchanged
    at 5.25%, citing stable inflation metrics and a resilient labor market.
    
    Fed Chair Jerome Powell stated in a press conference that the committee
    will continue to monitor economic indicators closely.
    
    "We remain committed to our 2% inflation target," Powell said.
    
    Economists surveyed by Reuters largely expected this decision, with 85%
    predicting no change in rates.
    """


@pytest.fixture
def sample_clickbait_content():
    """Sample clickbait content that should score poorly."""
    return """
    You WON'T BELIEVE What Just Happened!!!
    
    SHOCKING: This ONE WEIRD TRICK Will Change EVERYTHING!
    
    Scientists EXPOSED for hiding the TRUTH about what they don't
    want you to know! The mainstream media is LYING to you!
    
    Click here to find out what THEY don't want you to see!!!
    """


@pytest.fixture
def mock_whois_old_domain(mocker):
    """Mock WHOIS returning an old, established domain."""
    from datetime import datetime
    
    return mocker.patch(
        "truthscore.analyzers.domain.whois_lookup",
        return_value={
            "created": datetime(2010, 1, 1),
            "updated": datetime(2024, 1, 1),
            "registrar": "GoDaddy",
            "private": False,
        }
    )


@pytest.fixture
def mock_whois_new_domain(mocker):
    """Mock WHOIS returning a new, suspicious domain."""
    from datetime import datetime, timedelta
    
    return mocker.patch(
        "truthscore.analyzers.domain.whois_lookup",
        return_value={
            "created": datetime.now() - timedelta(days=15),
            "updated": datetime.now() - timedelta(days=5),
            "registrar": "Unknown Registrar",
            "private": True,
        }
    )


@pytest.fixture
def mock_search_provider(mocker):
    """Mock search provider with sample results."""
    from unittest.mock import Mock
    
    provider = Mock()
    provider.search.return_value = [
        Mock(
            url="https://snopes.com/fact-check/example",
            title="Fact Check: Example Claim",
            snippet="This claim has been rated FALSE.",
            source="brave"
        ),
        Mock(
            url="https://reuters.com/article/example",
            title="Reuters: Related Story",
            snippet="According to official sources...",
            source="brave"
        ),
        Mock(
            url="https://random-blog.com/opinion",
            title="My Thoughts on This",
            snippet="I think this is true because...",
            source="brave"
        ),
    ]
    return provider
