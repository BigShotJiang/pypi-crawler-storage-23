"""
TruthScore MCP Server.

Model Context Protocol server for AI assistants like Claude.

Usage:
    python -m truthscore.mcp_server
    
Or with uvx:
    uvx truthscore-mcp
"""
import os
import json
import asyncio
import logging
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from truthcheck.verify import verify
from truthcheck.trace import verify_claim
from truthcheck.publisher_db import PublisherDB


logger = logging.getLogger(__name__)

# Global publisher database
_publisher_db = None


def get_publisher_db() -> PublisherDB:
    """Get or create the publisher database."""
    global _publisher_db
    if _publisher_db is None:
        _publisher_db = PublisherDB()
    return _publisher_db


def get_tools() -> list[dict]:
    """
    Get list of available MCP tools.
    
    Returns:
        List of tool definitions in MCP format
    """
    return [
        {
            "name": "verify_source",
            "description": (
                "Verify if a URL is from a trustworthy source. "
                "Call this before citing any external article, news story, or webpage. "
                "Returns a trust score (0-1) and recommendation (TRUST/CAUTION/REJECT)."
            ),
            "inputSchema": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "The URL to verify"
                    },
                    "content": {
                        "type": "string",
                        "description": "Optional: article content if already fetched"
                    }
                },
                "required": ["url"]
            }
        },
        {
            "name": "verify_claim",
            "description": (
                "Find sources for a claim and determine if it's true. "
                "Use when you have a claim but no source URL. "
                "Searches the web and checks fact-checking sites. "
                "Requires TRUTHSCORE_SEARCH_KEY environment variable."
            ),
            "inputSchema": {
                "type": "object",
                "properties": {
                    "claim": {
                        "type": "string",
                        "description": "The factual claim to trace and verify"
                    }
                },
                "required": ["claim"]
            }
        },
        {
            "name": "lookup_publisher",
            "description": (
                "Look up information about a publisher/news source. "
                "Returns trust score, category, bias rating if known."
            ),
            "inputSchema": {
                "type": "object",
                "properties": {
                    "domain": {
                        "type": "string",
                        "description": "Domain name (e.g., 'nytimes.com')"
                    }
                },
                "required": ["domain"]
            }
        }
    ]


def handle_verify_source(arguments: dict) -> dict:
    """Handle verify_source tool call."""
    url = arguments.get("url", "")
    content = arguments.get("content")
    
    result = verify(url, content=content)
    
    return {
        "url": result.url,
        "trust_score": result.trust_score,
        "recommendation": result.recommendation,
        "signals": {
            name: {
                "score": sig.score,
                "confidence": sig.confidence,
                "details": sig.details
            }
            for name, sig in result.signals.items()
        }
    }


def handle_verify_claim(arguments: dict) -> dict:
    """Handle verify_claim tool call."""
    claim = arguments.get("claim", "")
    
    # Check for search API key
    search_key = os.environ.get("TRUTHSCORE_SEARCH_KEY")
    
    if not search_key:
        return {
            "error": "TRUTHSCORE_SEARCH_KEY environment variable not set",
            "claim": claim,
            "verdict": "UNVERIFIED",
            "message": "Search API key required. Set TRUTHSCORE_SEARCH_KEY."
        }
    
    # Check for LLM configuration
    llm_provider = os.environ.get("TRUTHSCORE_LLM_PROVIDER")
    llm_api_key = None
    llm_model = os.environ.get("TRUTHSCORE_LLM_MODEL")
    
    if llm_provider:
        if llm_provider in ("openai", "anthropic"):
            llm_api_key = os.environ.get(f"TRUTHSCORE_{llm_provider.upper()}_KEY") or \
                          os.environ.get(f"{llm_provider.upper()}_API_KEY")
    
    try:
        result = verify_claim(
            claim, 
            search_api_key=search_key,
            llm_provider_name=llm_provider,
            llm_api_key=llm_api_key,
            llm_model=llm_model
        )
        
        return {
            "claim": result.claim,
            "verdict": result.verdict,
            "confidence": result.confidence,
            "summary": result.summary,
            "fact_checks": [
                {"source": fc.source, "url": fc.url, "rating": fc.rating}
                for fc in result.fact_checks
            ],
            "sources_count": len(result.sources),
            "llm_enabled": llm_provider is not None
        }
    except Exception as e:
        return {
            "error": str(e),
            "claim": claim,
            "verdict": "UNVERIFIED"
        }


def handle_lookup_publisher(arguments: dict) -> dict:
    """Handle lookup_publisher tool call."""
    domain = arguments.get("domain", "")
    
    db = get_publisher_db()
    publisher = db.lookup(domain)
    
    if publisher:
        return {
            "found": True,
            "domain": publisher.domain,
            "name": publisher.name,
            "trust_score": publisher.trust_score,
            "category": publisher.category,
            "verified": publisher.verified,
            "bias": publisher.bias,
            "fact_check_rating": publisher.fact_check_rating
        }
    else:
        return {
            "found": False,
            "domain": domain,
            "message": "Publisher not in database"
        }


def call_tool(name: str, arguments: dict) -> dict:
    """
    Dispatch tool call to appropriate handler.
    
    Args:
        name: Tool name
        arguments: Tool arguments
        
    Returns:
        Tool result as dict
    """
    handlers = {
        "verify_source": handle_verify_source,
        "verify_claim": handle_verify_claim,
        "lookup_publisher": handle_lookup_publisher,
    }
    
    handler = handlers.get(name)
    if handler:
        return handler(arguments)
    else:
        return {"error": f"Unknown tool: {name}"}


# MCP Server setup
app = Server("truthscore")


@app.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools."""
    tools = get_tools()
    return [
        Tool(
            name=t["name"],
            description=t["description"],
            inputSchema=t["inputSchema"]
        )
        for t in tools
    ]


@app.call_tool()
async def mcp_call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle tool call from MCP client."""
    result = call_tool(name, arguments)
    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def main():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


def run():
    """Entry point for the MCP server."""
    asyncio.run(main())


if __name__ == "__main__":
    run()
