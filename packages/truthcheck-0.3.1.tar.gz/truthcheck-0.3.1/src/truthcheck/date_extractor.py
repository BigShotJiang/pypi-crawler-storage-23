"""
TruthScore Date Extractor.

Extract publication dates from web pages using multiple strategies.
"""
import re
from datetime import datetime
from typing import Optional
import logging

logger = logging.getLogger(__name__)


def extract_date(html: str, url: str = "") -> Optional[datetime]:
    """
    Extract publication date from HTML content.
    
    Tries multiple strategies in order of reliability:
    1. Meta tags (most reliable)
    2. JSON-LD structured data
    3. Time elements
    4. URL patterns
    5. Text patterns (least reliable)
    
    Args:
        html: HTML content of the page
        url: URL of the page (for URL-based extraction)
        
    Returns:
        datetime if found, None otherwise
    """
    # Strategy 1: Meta tags
    date = _extract_from_meta(html)
    if date:
        return date
    
    # Strategy 2: JSON-LD
    date = _extract_from_jsonld(html)
    if date:
        return date
    
    # Strategy 3: Time elements
    date = _extract_from_time_element(html)
    if date:
        return date
    
    # Strategy 4: URL patterns
    date = _extract_from_url(url)
    if date:
        return date
    
    # Strategy 5: Text patterns
    date = _extract_from_text(html)
    if date:
        return date
    
    return None


def _extract_from_meta(html: str) -> Optional[datetime]:
    """Extract date from meta tags."""
    patterns = [
        # Open Graph / Article
        r'<meta\s+(?:property|name)=["\'](?:article:published_time|og:published_time)["\']'
        r'\s+content=["\']([^"\']+)["\']',
        r'<meta\s+content=["\']([^"\']+)["\']\s+'
        r'(?:property|name)=["\'](?:article:published_time|og:published_time)["\']',
        
        # Generic date meta
        r'<meta\s+(?:property|name)=["\'](?:date|pubdate|publish_date|publishdate|'
        r'datePublished|DC\.date\.issued)["\']'
        r'\s+content=["\']([^"\']+)["\']',
        r'<meta\s+content=["\']([^"\']+)["\']\s+'
        r'(?:property|name)=["\'](?:date|pubdate|publish_date)["\']',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            date = _parse_date(match.group(1))
            if date:
                return date
    
    return None


def _extract_from_jsonld(html: str) -> Optional[datetime]:
    """Extract date from JSON-LD structured data."""
    import json
    
    # Find JSON-LD blocks
    pattern = r'<script\s+type=["\']application/ld\+json["\']\s*>(.*?)</script>'
    matches = re.findall(pattern, html, re.DOTALL | re.IGNORECASE)
    
    for match in matches:
        try:
            data = json.loads(match)
            
            # Handle arrays
            if isinstance(data, list):
                for item in data:
                    date = _extract_date_from_jsonld_object(item)
                    if date:
                        return date
            else:
                date = _extract_date_from_jsonld_object(data)
                if date:
                    return date
                    
        except json.JSONDecodeError:
            continue
    
    return None


def _extract_date_from_jsonld_object(data: dict) -> Optional[datetime]:
    """Extract date from a JSON-LD object."""
    if not isinstance(data, dict):
        return None
    
    # Common date fields
    date_fields = ['datePublished', 'dateCreated', 'dateModified', 'uploadDate']
    
    for field in date_fields:
        if field in data:
            date = _parse_date(data[field])
            if date:
                return date
    
    # Check nested objects
    if '@graph' in data:
        for item in data['@graph']:
            date = _extract_date_from_jsonld_object(item)
            if date:
                return date
    
    return None


def _extract_from_time_element(html: str) -> Optional[datetime]:
    """Extract date from <time> elements."""
    patterns = [
        r'<time[^>]+datetime=["\']([^"\']+)["\']',
        r'<time[^>]*>([^<]+)</time>',
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, html, re.IGNORECASE)
        for match in matches:
            date = _parse_date(match)
            if date:
                return date
    
    return None


def _extract_from_url(url: str) -> Optional[datetime]:
    """Extract date from URL patterns."""
    if not url:
        return None
    
    patterns = [
        # /2026/02/19/ or /2026-02-19/
        r'/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/',
        # /20260219/
        r'/(\d{4})(\d{2})(\d{2})/',
        # ?date=2026-02-19
        r'[?&]date=(\d{4})-(\d{1,2})-(\d{1,2})',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            try:
                year = int(match.group(1))
                month = int(match.group(2))
                day = int(match.group(3))
                
                if 1990 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31:
                    return datetime(year, month, day)
            except (ValueError, IndexError):
                continue
    
    return None


def _extract_from_text(html: str) -> Optional[datetime]:
    """Extract date from visible text patterns."""
    # Remove HTML tags for text analysis
    text = re.sub(r'<[^>]+>', ' ', html)
    
    patterns = [
        # February 19, 2026
        r'(January|February|March|April|May|June|July|August|September|October|November|December)'
        r'\s+(\d{1,2}),?\s+(\d{4})',
        # 19 February 2026
        r'(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December)'
        r'\s+(\d{4})',
        # 2026-02-19 or 2026/02/19
        r'(\d{4})[-/](\d{1,2})[-/](\d{1,2})',
    ]
    
    month_map = {
        'january': 1, 'february': 2, 'march': 3, 'april': 4,
        'may': 5, 'june': 6, 'july': 7, 'august': 8,
        'september': 9, 'october': 10, 'november': 11, 'december': 12
    }
    
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            groups = match.groups()
            try:
                if groups[0].lower() in month_map:
                    # "February 19, 2026"
                    month = month_map[groups[0].lower()]
                    day = int(groups[1])
                    year = int(groups[2])
                elif groups[1].lower() in month_map:
                    # "19 February 2026"
                    day = int(groups[0])
                    month = month_map[groups[1].lower()]
                    year = int(groups[2])
                else:
                    # "2026-02-19"
                    year = int(groups[0])
                    month = int(groups[1])
                    day = int(groups[2])
                
                if 1990 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31:
                    return datetime(year, month, day)
            except (ValueError, IndexError):
                continue
    
    return None


def _parse_date(date_str: str) -> Optional[datetime]:
    """Parse a date string into datetime."""
    if not date_str:
        return None
    
    # Clean up the string
    date_str = date_str.strip()
    
    # Try common formats
    formats = [
        '%Y-%m-%dT%H:%M:%S%z',      # ISO 8601 with timezone
        '%Y-%m-%dT%H:%M:%SZ',       # ISO 8601 UTC
        '%Y-%m-%dT%H:%M:%S',        # ISO 8601 no tz
        '%Y-%m-%d',                  # Simple date
        '%B %d, %Y',                 # February 19, 2026
        '%d %B %Y',                  # 19 February 2026
        '%Y/%m/%d',                  # 2026/02/19
        '%m/%d/%Y',                  # 02/19/2026
        '%d/%m/%Y',                  # 19/02/2026
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_str[:30], fmt)
        except ValueError:
            continue
    
    # Try dateparser as fallback if available
    try:
        import dateparser
        result = dateparser.parse(date_str)
        if result:
            return result
    except ImportError:
        pass
    
    return None


def format_date(dt: Optional[datetime]) -> str:
    """Format datetime as ISO date string."""
    if dt is None:
        return "unknown"
    return dt.strftime('%Y-%m-%d')
