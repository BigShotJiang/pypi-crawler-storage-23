"""
TruthScore utility functions.

URL parsing, domain extraction, and content fetching.
"""
from urllib.parse import urlparse
from typing import Optional
import requests


class FetchError(Exception):
    """Error fetching content from URL."""
    pass


def normalize_domain(domain: str) -> str:
    """
    Normalize a domain name.
    
    - Converts to lowercase
    - Removes www. prefix
    - Strips whitespace
    
    Args:
        domain: Domain name to normalize
        
    Returns:
        Normalized domain name
    """
    domain = domain.strip().lower()
    
    if domain.startswith("www."):
        domain = domain[4:]
    
    return domain


def extract_domain(url: str) -> str:
    """
    Extract and normalize domain from a URL.
    
    Args:
        url: URL to extract domain from
        
    Returns:
        Normalized domain name
        
    Raises:
        ValueError: If URL is invalid or empty
    """
    if not url or not url.strip():
        raise ValueError("URL cannot be empty")
    
    url = url.strip()
    
    # Add scheme if missing
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    
    try:
        parsed = urlparse(url)
    except Exception as e:
        raise ValueError(f"Invalid URL: {url}") from e
    
    netloc = parsed.netloc
    
    # Handle port
    if ":" in netloc:
        netloc = netloc.split(":")[0]
    
    if not netloc:
        raise ValueError(f"Invalid URL: {url}")
    
    # Validate domain has at least one dot (basic TLD check)
    if "." not in netloc:
        raise ValueError(f"Invalid domain: {netloc}")
    
    return normalize_domain(netloc)


def get_parent_domain(domain: str) -> Optional[str]:
    """
    Get the parent domain of a subdomain.
    
    Args:
        domain: Domain name (e.g., "blog.example.com")
        
    Returns:
        Parent domain (e.g., "example.com") or None if already at root
    """
    parts = domain.split(".")
    
    # Need at least 3 parts for a subdomain (sub.domain.tld)
    if len(parts) <= 2:
        return None
    
    return ".".join(parts[1:])


def fetch_content(url: str, timeout: int = 10) -> str:
    """
    Fetch content from a URL.
    
    Args:
        url: URL to fetch
        timeout: Request timeout in seconds
        
    Returns:
        Response text content
        
    Raises:
        FetchError: If request fails
    """
    try:
        response = requests.get(
            url,
            timeout=timeout,
            headers={
                "User-Agent": "TruthScore/0.1 (content verification)"
            }
        )
        response.raise_for_status()
        return response.text
    except requests.Timeout as e:
        raise FetchError(f"Timeout fetching {url}") from e
    except requests.HTTPError as e:
        raise FetchError(f"HTTP error fetching {url}: {e}") from e
    except requests.RequestException as e:
        raise FetchError(f"Error fetching {url}: {e}") from e
