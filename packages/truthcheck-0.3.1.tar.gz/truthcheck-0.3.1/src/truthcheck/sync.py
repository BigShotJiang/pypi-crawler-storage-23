"""
TruthScore Database Sync.

Fetches publisher data from Media Bias/Fact Check and updates local database.
"""
import json
import requests
from pathlib import Path
from typing import Optional
from datetime import datetime

# MBFC combined.json URL (updated daily)
MBFC_URL = "https://raw.githubusercontent.com/drmikecrowe/mbfcext/master/docs/v5/data/combined.json"

# Mapping MBFC fields to our schema
BIAS_MAP = {
    "left": "left",
    "left-center": "left-center",
    "center": "center",
    "right-center": "right-center",
    "right": "right",
    "pro-science": "pro-science",
    "conspiracy-pseudoscience": "conspiracy",
    "satire": "satire",
    "fake-news": "fake-news",
}

CREDIBILITY_MAP = {
    "high-credibility": "high",
    "medium-credibility": "medium",
    "low-credibility": "low",
}

REPORTING_MAP = {
    "very-high": "very-high",
    "high": "high",
    "mostly-factual": "mostly-factual",
    "mixed": "mixed",
    "low": "low",
    "very-low": "very-low",
}


def fetch_mbfc(timeout: int = 30) -> dict:
    """
    Fetch the latest MBFC combined.json.
    
    Returns:
        Parsed JSON data
        
    Raises:
        requests.RequestException: On network error
    """
    response = requests.get(MBFC_URL, timeout=timeout)
    response.raise_for_status()
    return response.json()


def convert_source(source: dict) -> Optional[dict]:
    """
    Convert an MBFC source to TruthScore format.
    
    Args:
        source: MBFC source dict
        
    Returns:
        TruthScore publisher dict, or None if invalid
    """
    domain = source.get("domain", "").strip()
    if not domain or "/" in domain:  # Skip subdomain paths for now
        return None
    
    bias = source.get("bias", "")
    if bias not in BIAS_MAP:
        return None
    
    # Build publisher entry
    publisher = {
        "domain": domain,
        "name": source.get("name", domain),
        "bias": BIAS_MAP.get(bias, "unknown"),
    }
    
    # Credibility → trust_score approximation
    credibility = source.get("credibility", "")
    if credibility in CREDIBILITY_MAP:
        publisher["credibility"] = CREDIBILITY_MAP[credibility]
        # Map to numeric score
        score_map = {"high": 0.85, "medium": 0.60, "low": 0.30}
        publisher["trust_score"] = score_map.get(CREDIBILITY_MAP[credibility], 0.5)
    
    # Factual reporting
    reporting = source.get("reporting", "")
    if reporting in REPORTING_MAP:
        publisher["reporting"] = REPORTING_MAP[reporting]
    
    # Questionable flags
    questionable = source.get("questionable", [])
    if questionable:
        publisher["flags"] = questionable
    
    # MBFC URL for reference
    url = source.get("url", "")
    if url:
        publisher["mbfc_url"] = url
    
    return publisher


def sync_database(
    output_path: Optional[Path] = None,
    verbose: bool = False
) -> dict:
    """
    Sync publisher database from MBFC.
    
    Args:
        output_path: Where to save the JSON database (default: package data dir)
        verbose: Print progress
        
    Returns:
        Stats dict with counts
    """
    if output_path is None:
        output_path = Path(__file__).parent / "data" / "publishers.json"
    
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if verbose:
        print(f"Fetching MBFC data from {MBFC_URL}...")
    
    data = fetch_mbfc()
    
    mbfc_version = data.get("version", "unknown")
    mbfc_date = data.get("date", "unknown")
    sources = data.get("sources", [])
    
    if verbose:
        print(f"MBFC version {mbfc_version}, dated {mbfc_date}")
        print(f"Processing {len(sources)} sources...")
    
    publishers = {}
    skipped = 0
    
    for source in sources:
        converted = convert_source(source)
        if converted:
            domain = converted.pop("domain")
            publishers[domain] = converted
        else:
            skipped += 1
    
    # Build output
    db = {
        "meta": {
            "source": "mediabiasfactcheck.com",
            "mbfc_version": mbfc_version,
            "mbfc_date": mbfc_date,
            "synced_at": datetime.utcnow().isoformat() + "Z",
            "count": len(publishers),
        },
        "publishers": publishers,
    }
    
    # Write JSON
    with open(output_path, "w") as f:
        json.dump(db, f, indent=2)
    
    stats = {
        "total": len(sources),
        "imported": len(publishers),
        "skipped": skipped,
        "output": str(output_path),
        "mbfc_date": mbfc_date,
    }
    
    if verbose:
        print(f"Imported {stats['imported']} publishers, skipped {stats['skipped']}")
        print(f"Saved to {output_path}")
    
    return stats


def get_database_path() -> Path:
    """Get the path to the publishers database."""
    return Path(__file__).parent / "data" / "publishers.json"


def is_stale(max_age_days: int = 7) -> bool:
    """
    Check if the database is stale (older than max_age_days).
    
    Args:
        max_age_days: Maximum age in days before considered stale
        
    Returns:
        True if database is missing or older than max_age_days
    """
    db_path = get_database_path()
    
    if not db_path.exists():
        return True
    
    try:
        with open(db_path) as f:
            data = json.load(f)
        
        synced_at = data.get("meta", {}).get("synced_at")
        if not synced_at:
            return True
        
        # Parse ISO timestamp
        from datetime import datetime
        synced = datetime.fromisoformat(synced_at.replace("Z", "+00:00"))
        age = datetime.now(synced.tzinfo) - synced
        
        return age.days >= max_age_days
        
    except (json.JSONDecodeError, IOError, ValueError):
        return True


import os

# Environment variable to disable auto-sync
AUTO_SYNC_DISABLED = os.environ.get("TRUTHSCORE_NO_AUTO_SYNC", "").lower() in ("1", "true", "yes")


def auto_sync(max_age_days: int = 7, timeout: int = 5) -> bool:
    """
    Automatically sync if database is stale.
    
    This is called lazily on first database access.
    Fails silently and uses cached data if network unavailable.
    
    Set TRUTHSCORE_NO_AUTO_SYNC=1 to disable.
    
    Args:
        max_age_days: Sync if older than this many days
        timeout: Network timeout in seconds (short to avoid blocking)
        
    Returns:
        True if synced, False if skipped or failed
    """
    if AUTO_SYNC_DISABLED:
        return False
    
    if not is_stale(max_age_days):
        return False
    
    try:
        sync_database(verbose=False)
        return True
    except Exception:
        # Network error, timeout, etc. — use cached data
        return False


def load_database() -> dict:
    """
    Load the publisher database.
    
    Returns:
        Database dict with 'meta' and 'publishers' keys
    """
    db_path = get_database_path()
    if not db_path.exists():
        return {"meta": {}, "publishers": {}}
    
    with open(db_path) as f:
        return json.load(f)


def get_publisher(domain: str) -> Optional[dict]:
    """
    Look up a publisher by domain.
    
    Args:
        domain: Domain name (e.g., "nytimes.com")
        
    Returns:
        Publisher dict or None
    """
    db = load_database()
    
    # Normalize
    domain = domain.lower().strip()
    if domain.startswith("www."):
        domain = domain[4:]
    
    return db.get("publishers", {}).get(domain)
