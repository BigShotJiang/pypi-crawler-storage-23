"""
Publisher Analyzer (L1).

Checks if a URL comes from a known, trusted publisher.
"""
from typing import Optional

from truthcheck.models import Signal
from truthcheck.publisher_db import PublisherDB
from truthcheck.utils import extract_domain


class PublisherAnalyzer:
    """
    L1 Analyzer: Publisher Database Lookup.
    
    Checks if the URL's domain is in our community-curated publisher database.
    This is the fastest and most reliable signal when we have data.
    
    Attributes:
        name: Analyzer identifier ("publisher")
        db: Publisher database instance
    """
    
    name = "publisher"
    
    def __init__(self, db: PublisherDB):
        """
        Initialize the publisher analyzer.
        
        Args:
            db: Publisher database to use for lookups
        """
        self.db = db
    
    def analyze(self, url: str, content: Optional[str] = None) -> Signal:
        """
        Analyze a URL by looking up its publisher.
        
        Args:
            url: URL to analyze
            content: Ignored - publisher lookup doesn't need content
            
        Returns:
            Signal with publisher information and trust score
        """
        # Try to extract domain
        try:
            domain = extract_domain(url)
        except ValueError as e:
            return Signal(
                name=self.name,
                score=0.5,
                confidence=0.1,
                details={
                    "found": False,
                    "error": str(e),
                }
            )
        
        # Look up publisher
        publisher = self.db.lookup(domain)
        
        if publisher:
            # Verified publishers get higher confidence
            confidence = 0.9 if publisher.verified else 0.7
            
            return Signal(
                name=self.name,
                score=publisher.trust_score,
                confidence=confidence,
                details={
                    "found": True,
                    "name": publisher.name,
                    "domain": publisher.domain,
                    "category": publisher.category,
                    "verified": publisher.verified,
                    "bias": publisher.bias,
                    "fact_check_rating": publisher.fact_check_rating,
                }
            )
        
        # Unknown publisher - neutral score, low confidence
        return Signal(
            name=self.name,
            score=0.5,
            confidence=0.2,
            details={
                "found": False,
                "domain": domain,
            }
        )
