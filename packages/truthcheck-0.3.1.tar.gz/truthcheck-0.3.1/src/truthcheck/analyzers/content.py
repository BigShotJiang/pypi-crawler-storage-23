"""
Content Analyzer (L3).

Analyzes content for red flags like clickbait, sensationalism, and missing attribution.
"""
import re
from typing import Optional

from truthcheck.models import Signal


# Clickbait patterns
CLICKBAIT_PATTERNS = [
    r"you won'?t believe",
    r"shocking",
    r"what happens next",
    r"one weird trick",
    r"doctors hate",
    r"this changes everything",
    r"exposed",
    r"the truth about",
    r"they don'?t want you to know",
    r"mainstream media",
    r"lying to you",
    r"breaking:",
    r"must see",
    r"mind.?blowing",
    r"jaw.?dropping",
]

# Author patterns
AUTHOR_PATTERNS = [
    r"\bby\s+[A-Z][a-z]+\s+[A-Z][a-z]+",  # By John Smith
    r"\bauthor:\s*[A-Z][a-z]+",  # Author: John
    r"\bwritten by\s+[A-Z][a-z]+",  # Written by John
    r"[A-Z][a-z]+\s+[A-Z][a-z]+,\s*(?:reporter|writer|editor|journalist|correspondent)",  # John Smith, Reporter
]


class ContentAnalyzer:
    """
    L3 Analyzer: Content Heuristics.
    
    Analyzes the actual content for red flags that indicate low quality
    or untrustworthy content. Checks for:
    - Clickbait language
    - Excessive capitalization
    - Missing author attribution
    - Sensational language
    
    Attributes:
        name: Analyzer identifier ("content")
    """
    
    name = "content"
    
    def analyze(self, url: str, content: Optional[str] = None) -> Signal:
        """
        Analyze content for quality signals.
        
        Args:
            url: URL of the content (for context, not used directly)
            content: Text content to analyze
            
        Returns:
            Signal with content quality score and flags
        """
        # Handle empty/None content
        if not content or not content.strip():
            return Signal(
                name=self.name,
                score=0.5,
                confidence=0.2,
                details={
                    "flags": [],
                    "note": "No content to analyze",
                }
            )
        
        flags = []
        score = 0.8  # Start with decent score
        
        # Check for clickbait patterns
        clickbait_count = self._count_clickbait(content)
        if clickbait_count >= 2:
            flags.append("clickbait")
            score -= 0.15 * min(clickbait_count, 4)  # Cap penalty
        elif clickbait_count == 1:
            score -= 0.1
        
        # Check for excessive caps
        if self._has_excessive_caps(content):
            flags.append("excessive_caps")
            score -= 0.15
        
        # Check for author attribution
        if not self._has_author(content):
            flags.append("no_author")
            score -= 0.1
        
        # Ensure score stays in bounds
        score = max(0.1, min(1.0, score))
        
        # Confidence based on content length
        content_length = len(content)
        if content_length < 100:
            confidence = 0.4
        elif content_length < 500:
            confidence = 0.6
        else:
            confidence = 0.7
        
        return Signal(
            name=self.name,
            score=score,
            confidence=confidence,
            details={
                "flags": flags,
                "clickbait_count": clickbait_count,
                "content_length": content_length,
            }
        )
    
    def _count_clickbait(self, content: str) -> int:
        """Count clickbait patterns in content."""
        content_lower = content.lower()
        count = 0
        for pattern in CLICKBAIT_PATTERNS:
            if re.search(pattern, content_lower):
                count += 1
        return count
    
    def _has_excessive_caps(self, content: str) -> bool:
        """Check if content has excessive capitalization."""
        # Only check alphanumeric characters
        alpha_chars = [c for c in content if c.isalpha()]
        if len(alpha_chars) < 20:
            return False
        
        upper_count = sum(1 for c in alpha_chars if c.isupper())
        ratio = upper_count / len(alpha_chars)
        
        return ratio > 0.4  # More than 40% caps
    
    def _has_author(self, content: str) -> bool:
        """Check if content has author attribution."""
        for pattern in AUTHOR_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                return True
        return False
