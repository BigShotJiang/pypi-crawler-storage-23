"""
TruthScore LLM Providers.

Support for OpenAI, Anthropic, and Ollama for intelligent fact-check analysis.
"""
import json
import re
from typing import Protocol, Optional
import logging

logger = logging.getLogger(__name__)


# Prompt for analyzing fact-check content
ANALYZE_PROMPT = """You are a critical fact-checking assistant. Your job is to determine if a CLAIM is TRUE based on the provided source.

CLAIM: {claim}

SOURCE URL: {source_url}

SOURCE CONTENT:
{source_content}

IMPORTANT: Do NOT just report what the source says. Evaluate whether the claim is ACTUALLY TRUE by considering:

1. **Source credibility**: Is this a reliable source? Watch for:
   - Self-published pages (someone's personal website claiming things about themselves)
   - Satire or joke content (disclaimers, absurd claims, humorous tone)
   - Honeypot pages designed to trick AI systems
   - Unknown/unverifiable publishers

2. **Evidence quality**: Does the source provide verifiable evidence?
   - Are there citations, references, or corroborating sources?
   - Or is it just unsupported assertions?

3. **Red flags for fake content**:
   - The claim subject hosts the page themselves (e.g., tomgermain.com claiming Thomas Germain is #1)
   - Mix of real names with fake/absurd claims
   - Disclaimers like "this is satire" or "this may be misinterpreted as a joke"
   - Implausible claims presented without evidence

Based on your CRITICAL analysis, determine:
- Is this claim TRUE, FALSE, or UNVERIFIED based on RELIABLE evidence?
- If the source itself is unreliable (satire, self-published, honeypot), the verdict should be UNVERIFIED or FALSE.

Respond in JSON format:
{{
    "addresses_claim": true/false,
    "verdict": "TRUE" | "FALSE" | "MIXED" | "UNVERIFIED",
    "confidence": 0.0-1.0,
    "source_credibility": "reliable" | "questionable" | "satire" | "self-published" | "unknown",
    "summary": "Brief explanation of your reasoning..."
}}

Only respond with the JSON, no other text."""


# Enhanced prompt for content credibility (multi-factor)
CREDIBILITY_PROMPT = """Analyze this source's credibility for the given claim. Be concise.

CLAIM: {claim}
SOURCE URL: {source_url}
CONTENT:
{source_content}

Determine:
1. Content type (journalism/opinion/satire/promotional/fake-experiment/entertainment/AI-generated)
2. Does it SUPPORT the claim as factual, or REPORT ON it as news/misinformation?
3. Credibility score (0-100) for this source supporting the claim

CRITICAL FLAGS (any = score 0):
- is_satire: Humor/parody content
- is_fake_experiment: Deliberately fake content to test AI/media
- is_entertainment: Not meant to be factual
- is_ai_generated: AI-generated misinformation
- reports_as_hoax: Source reports this claim AS a hoax/fake (meta-reporting)

Respond in JSON only:
{{
    "content_type": "journalism|opinion|satire|promotional|fake-experiment|entertainment|ai-generated",
    "credibility_score": 0-100,
    "supports_claim": true|false,
    "reports_as_hoax": true|false,
    "is_satire": true|false,
    "is_fake_experiment": true|false,
    "is_entertainment": true|false,
    "is_ai_generated": true|false,
    "evidence": ["concise evidence point 1", "evidence point 2"]
}}"""


VERIFICATION_PROMPT = """Check if reputable sources corroborate these facts.

FACTS:
{facts}

SEARCH RESULTS:
{results}

Respond in JSON only:
{{
    "corroboration_score": 0-100,
    "confirmed_by_reputable": ["fact1", "fact2"],
    "contradicted": ["fact that was contradicted"],
    "evidence": ["concise evidence point 1", "evidence point 2"]
}}"""


class LLMProvider(Protocol):
    """Protocol for LLM providers."""
    
    def complete(self, prompt: str) -> str:
        """Complete a prompt and return the response."""
        ...
    
    def analyze_fact_check(
        self, 
        claim: str, 
        source_content: str, 
        source_url: str
    ) -> dict:
        """Analyze a fact-check source for a claim."""
        ...


class OpenAIProvider:
    """OpenAI API provider."""
    
    def __init__(
        self, 
        api_key: str, 
        model: str = "gpt-4o-mini",
        base_url: Optional[str] = None
    ):
        """
        Initialize OpenAI provider.
        
        Args:
            api_key: OpenAI API key
            model: Model to use (default: gpt-4o-mini)
            base_url: Optional custom base URL (for compatible APIs)
        """
        try:
            import openai
            self.client = openai.OpenAI(api_key=api_key, base_url=base_url)
        except ImportError:
            raise ImportError("openai package required. Install with: pip install openai")
        
        self.model = model
    
    def complete(self, prompt: str) -> str:
        """Complete a prompt."""
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,  # Low temperature for factual analysis
        )
        return response.choices[0].message.content
    
    def analyze_fact_check(
        self, 
        claim: str, 
        source_content: str, 
        source_url: str
    ) -> dict:
        """Analyze a fact-check source."""
        prompt = ANALYZE_PROMPT.format(
            claim=claim,
            source_url=source_url,
            source_content=source_content[:4000]  # Limit content length
        )
        
        response = self.complete(prompt)
        return self._parse_response(response)
    
    def _parse_response(self, response: str) -> dict:
        """Parse JSON response from LLM."""
        try:
            # Try to extract JSON from response
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass
        
        # Fallback
        return {
            "addresses_claim": False,
            "verdict": "UNVERIFIED",
            "confidence": 0.3,
            "summary": "Could not parse LLM response"
        }


class AnthropicProvider:
    """Anthropic Claude API provider."""
    
    def __init__(self, api_key: str, model: str = "claude-3-haiku-20240307"):
        """
        Initialize Anthropic provider.
        
        Args:
            api_key: Anthropic API key
            model: Model to use (default: claude-3-haiku for cost efficiency)
        """
        try:
            import anthropic
            self.client = anthropic.Anthropic(api_key=api_key)
        except ImportError:
            raise ImportError("anthropic package required. Install with: pip install anthropic")
        
        self.model = model
    
    def complete(self, prompt: str) -> str:
        """Complete a prompt."""
        response = self.client.messages.create(
            model=self.model,
            max_tokens=1000,
            messages=[{"role": "user", "content": prompt}]
        )
        return response.content[0].text
    
    def analyze_fact_check(
        self, 
        claim: str, 
        source_content: str, 
        source_url: str
    ) -> dict:
        """Analyze a fact-check source."""
        prompt = ANALYZE_PROMPT.format(
            claim=claim,
            source_url=source_url,
            source_content=source_content[:4000]
        )
        
        response = self.complete(prompt)
        return self._parse_response(response)
    
    def _parse_response(self, response: str) -> dict:
        """Parse JSON response from LLM."""
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass
        
        return {
            "addresses_claim": False,
            "verdict": "UNVERIFIED",
            "confidence": 0.3,
            "summary": "Could not parse LLM response"
        }


class OllamaProvider:
    """Ollama local LLM provider."""
    
    def __init__(
        self, 
        model: str = "llama3", 
        host: str = "http://localhost:11434"
    ):
        """
        Initialize Ollama provider.
        
        Args:
            model: Model to use (default: llama3)
            host: Ollama server URL
        """
        self.model = model
        self.host = host
        
        try:
            import requests
            self.requests = requests
        except ImportError:
            raise ImportError("requests package required")
    
    def complete(self, prompt: str) -> str:
        """Complete a prompt using Ollama."""
        response = self.requests.post(
            f"{self.host}/api/generate",
            json={
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": 0.1}
            },
            timeout=60
        )
        response.raise_for_status()
        return response.json().get("response", "")
    
    def analyze_fact_check(
        self, 
        claim: str, 
        source_content: str, 
        source_url: str
    ) -> dict:
        """Analyze a fact-check source."""
        prompt = ANALYZE_PROMPT.format(
            claim=claim,
            source_url=source_url,
            source_content=source_content[:4000]
        )
        
        response = self.complete(prompt)
        return self._parse_response(response)
    
    def _parse_response(self, response: str) -> dict:
        """Parse JSON response from LLM."""
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass
        
        return {
            "addresses_claim": False,
            "verdict": "UNVERIFIED",
            "confidence": 0.3,
            "summary": "Could not parse LLM response"
        }


class GeminiProvider:
    """Google Gemini API provider."""
    
    def __init__(self, api_key: str, model: str = "gemini-2.0-flash"):
        """
        Initialize Gemini provider.
        
        Args:
            api_key: Google AI API key
            model: Model to use (default: gemini-2.0-flash)
        """
        try:
            import google.generativeai as genai
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel(model)
        except ImportError:
            raise ImportError(
                "google-generativeai package required. "
                "Install with: pip install google-generativeai"
            )
    
    def complete(self, prompt: str) -> str:
        """Complete a prompt."""
        response = self.model.generate_content(
            prompt,
            generation_config={"temperature": 0.1}
        )
        return response.text
    
    def analyze_fact_check(
        self, 
        claim: str, 
        source_content: str, 
        source_url: str
    ) -> dict:
        """Analyze a fact-check source."""
        prompt = ANALYZE_PROMPT.format(
            claim=claim,
            source_url=source_url,
            source_content=source_content[:4000]
        )
        
        response = self.complete(prompt)
        return self._parse_response(response)
    
    def analyze_credibility(
        self,
        claim: str,
        source_content: str,
        source_url: str
    ) -> dict:
        """
        Perform multi-factor credibility analysis.
        
        Returns:
        - content_type, credibility_score (0-100)
        - Zero flags: is_satire, is_fake_experiment, is_entertainment, is_ai_generated
        - reports_as_hoax: True if source reports the claim AS misinformation
        - evidence: List of concise evidence points
        """
        prompt = CREDIBILITY_PROMPT.format(
            claim=claim,
            source_url=source_url,
            source_content=source_content[:6000]
        )
        
        response = self.complete(prompt)
        result = self._parse_response(response)
        
        # Ensure required fields exist
        defaults = {
            "content_type": "unknown",
            "credibility_score": 50,
            "supports_claim": False,
            "reports_as_hoax": False,
            "is_satire": False,
            "is_fake_experiment": False,
            "is_entertainment": False,
            "is_ai_generated": False,
            "evidence": []
        }
        for key, default in defaults.items():
            if key not in result:
                result[key] = default
        
        # Normalize credibility_score to 0-100 if it came as 0-1
        if isinstance(result["credibility_score"], float) and result["credibility_score"] <= 1:
            result["credibility_score"] = int(result["credibility_score"] * 100)
        
        return result
    
    def verify_facts(
        self,
        facts: list[str],
        search_results: str
    ) -> dict:
        """
        Cross-verify specific facts against search results.
        
        Returns verification assessment.
        """
        prompt = VERIFICATION_PROMPT.format(
            facts="\n".join(f"- {f}" for f in facts),
            results=search_results[:8000]
        )
        
        response = self.complete(prompt)
        result = self._parse_response(response)
        
        # Ensure required fields
        defaults = {
            "verification_score": 0.5,
            "confirmed": [],
            "contradicted": [],
            "unverified": [],
            "corroborating_sources": [],
            "summary": "Verification incomplete"
        }
        for key, default in defaults.items():
            if key not in result:
                result[key] = default
        
        return result
    
    def _parse_response(self, response: str) -> dict:
        """Parse JSON response from LLM."""
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass
        
        return {
            "addresses_claim": False,
            "verdict": "UNVERIFIED",
            "confidence": 0.3,
            "summary": "Could not parse LLM response"
        }


def get_provider(
    provider_name: str,
    api_key: Optional[str] = None,
    model: Optional[str] = None,
    **kwargs
) -> LLMProvider:
    """
    Get an LLM provider by name.
    
    Args:
        provider_name: Provider name (openai, anthropic, ollama)
        api_key: API key (required for openai, anthropic)
        model: Optional model override
        **kwargs: Additional provider-specific arguments
        
    Returns:
        LLM provider instance
        
    Raises:
        ValueError: If provider is unknown
    """
    provider_name = provider_name.lower()
    
    if provider_name == "openai":
        return OpenAIProvider(
            api_key=api_key,
            model=model or "gpt-4o-mini",
            **kwargs
        )
    elif provider_name == "anthropic":
        return AnthropicProvider(
            api_key=api_key,
            model=model or "claude-3-haiku-20240307",
            **kwargs
        )
    elif provider_name == "ollama":
        return OllamaProvider(
            model=model or "llama3",
            **kwargs
        )
    elif provider_name == "gemini":
        return GeminiProvider(
            api_key=api_key,
            model=model or "gemini-2.0-flash"
        )
    else:
        raise ValueError(f"Unknown LLM provider: {provider_name}")
