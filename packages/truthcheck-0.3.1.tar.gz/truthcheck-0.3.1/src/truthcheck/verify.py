"""
TruthScore main verification function.

This is the primary entry point for verifying URLs.
"""
from typing import Optional

from truthcheck.models import VerificationResult
from truthcheck.publisher_db import PublisherDB
from truthcheck.analyzers.publisher import PublisherAnalyzer
from truthcheck.analyzers.content import ContentAnalyzer
from truthcheck.scorer import Scorer


def verify(
    url: str,
    content: Optional[str] = None,
    publisher_db: Optional[PublisherDB] = None,
) -> VerificationResult:
    """
    Verify a URL and return a trust score.
    
    Runs multiple analyzers to assess the trustworthiness of a URL:
    - L1: Publisher lookup (is this a known source?)
    - L3: Content analysis (clickbait, quality signals)
    
    Args:
        url: URL to verify
        content: Optional pre-fetched content. If not provided,
                 content analysis will be limited.
        publisher_db: Optional custom publisher database.
                      Uses bundled data if not provided.
    
    Returns:
        VerificationResult with trust score, recommendation, and signals
    
    Example:
        >>> result = verify("https://reuters.com/article")
        >>> print(result.trust_score)  # 0.95
        >>> print(result.recommendation)  # "TRUST"
    """
    # Use default publisher DB if not provided
    if publisher_db is None:
        publisher_db = PublisherDB()
    
    # Initialize analyzers
    publisher_analyzer = PublisherAnalyzer(publisher_db)
    content_analyzer = ContentAnalyzer()
    
    # Run analyzers
    signals = {}
    
    # L1: Publisher lookup
    signals["publisher"] = publisher_analyzer.analyze(url)
    
    # L3: Content analysis (if content provided)
    if content:
        signals["content"] = content_analyzer.analyze(url, content)
    else:
        # Still run content analyzer with None to get a neutral signal
        signals["content"] = content_analyzer.analyze(url, None)
    
    # Calculate final score
    scorer = Scorer()
    result = scorer.calculate(signals, url=url)
    
    return result
