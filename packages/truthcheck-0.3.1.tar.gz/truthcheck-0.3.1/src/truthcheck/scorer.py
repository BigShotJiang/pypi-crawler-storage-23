"""
TruthScore Scorer.

Combines signals from multiple analyzers into a final trust score.
"""
from truthcheck.models import Signal, VerificationResult, get_recommendation


# Default weights for each analyzer
DEFAULT_WEIGHTS = {
    "publisher": 0.40,  # Known publishers are strongest signal
    "domain": 0.20,     # Domain age/SSL matters
    "content": 0.25,    # Content quality
    "claims": 0.15,     # Claim verification (if available)
}


class Scorer:
    """
    Combines signals into a final trust score.
    
    Uses weighted averaging with confidence as an additional factor.
    Publisher signal has the highest weight since known publishers
    are the most reliable indicator.
    """
    
    def __init__(self, weights: dict = None):
        """
        Initialize scorer with optional custom weights.
        
        Args:
            weights: Dict of signal name -> weight. Uses defaults if not provided.
        """
        self.weights = weights or DEFAULT_WEIGHTS
    
    def calculate(self, signals: dict[str, Signal], url: str) -> VerificationResult:
        """
        Calculate final trust score from signals.
        
        Args:
            signals: Dict of signal name -> Signal from analyzers
            url: The URL being verified
            
        Returns:
            VerificationResult with combined score and recommendation
        """
        if not signals:
            return VerificationResult(
                url=url,
                trust_score=0.5,
                recommendation="CAUTION",
                signals=signals,
            )
        
        total_score = 0.0
        total_weight = 0.0
        
        for name, signal in signals.items():
            # Get weight for this signal type
            weight = self.weights.get(name, 0.1)  # Default weight for unknown
            
            # Adjust weight by confidence
            adjusted_weight = weight * signal.confidence
            
            total_score += signal.score * adjusted_weight
            total_weight += adjusted_weight
        
        # Calculate weighted average
        if total_weight > 0:
            final_score = total_score / total_weight
        else:
            final_score = 0.5
        
        # Ensure bounds
        final_score = max(0.0, min(1.0, final_score))
        
        return VerificationResult(
            url=url,
            trust_score=final_score,
            recommendation=get_recommendation(final_score),
            signals=signals,
        )
