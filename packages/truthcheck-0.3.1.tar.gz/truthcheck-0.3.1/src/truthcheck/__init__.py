"""
TruthScore - Open source AI content verification.

Verify URLs and trace claims to fight misinformation.
"""
from truthcheck.models import (
    Signal,
    Publisher,
    VerificationResult,
    SearchResult,
    FactCheck,
    TraceResult,
    get_recommendation,
)
from truthcheck.verify import verify
from truthcheck.trace import verify_claim, trace_claim
from truthcheck.config import get_search_provider, get_llm_provider

__version__ = "0.3.1"
__all__ = [
    # Main functions
    "verify",
    "verify_claim",
    "trace_claim",
    # Config helpers (reads from env)
    "get_search_provider",
    "get_llm_provider",
    # Models
    "Signal",
    "Publisher", 
    "VerificationResult",
    "SearchResult",
    "FactCheck",
    "TraceResult",
    "get_recommendation",
]
