"""
TruthScore Command-Line Interface.

Usage:
    truthcheck check <url>
    truthcheck trace "<claim>"
    truthcheck lookup <domain>
"""
import json
import os
import sys
import click

from truthcheck import __version__
from truthcheck.verify import verify
from truthcheck.publisher_db import PublisherDB
from truthcheck.utils import extract_domain


# ANSI colors
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
RESET = "\033[0m"
BOLD = "\033[1m"


def get_recommendation_color(recommendation: str) -> str:
    """Get color for recommendation."""
    colors = {
        "TRUST": GREEN,
        "CAUTION": YELLOW,
        "REJECT": RED,
    }
    return colors.get(recommendation, RESET)


@click.group()
@click.version_option(__version__, prog_name="TruthScore")
def cli():
    """TruthScore - Open source AI content verification.
    
    Verify URLs and trace claims to fight misinformation.
    """
    pass


@cli.command()
@click.argument("url")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("-v", "--verbose", is_flag=True, help="Show detailed signals")
def check(url: str, as_json: bool, verbose: bool):
    """Check if a URL is trustworthy.
    
    Example:
        truthcheck check https://reuters.com/article
    """
    result = verify(url)
    
    if as_json:
        # JSON output
        output = {
            "url": result.url,
            "trust_score": result.trust_score,
            "recommendation": result.recommendation,
            "signals": {
                name: {
                    "score": sig.score,
                    "confidence": sig.confidence,
                    "details": sig.details,
                }
                for name, sig in result.signals.items()
            },
        }
        click.echo(json.dumps(output, indent=2))
    else:
        # Human-readable output
        color = get_recommendation_color(result.recommendation)
        
        click.echo(f"\n{BOLD}URL:{RESET} {result.url}")
        click.echo(f"{BOLD}Trust Score:{RESET} {result.trust_score:.2f}")
        click.echo(f"{BOLD}Recommendation:{RESET} {color}{result.recommendation}{RESET}")
        
        if verbose:
            click.echo(f"\n{BOLD}Signals:{RESET}")
            for name, signal in result.signals.items():
                click.echo(f"  {name}:")
                click.echo(f"    Score: {signal.score:.2f}")
                click.echo(f"    Confidence: {signal.confidence:.2f}")
                if signal.details:
                    for key, value in signal.details.items():
                        click.echo(f"    {key}: {value}")
        
        click.echo()


@cli.command()
@click.argument("claim")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--search", "search_provider", type=click.Choice(["duckduckgo", "brave", "searxng"]),
              default="duckduckgo", help="Search provider (default: duckduckgo)")
@click.option("--llm", "llm_provider", type=click.Choice(["openai", "anthropic", "ollama", "gemini"]), 
              help="LLM provider for better accuracy")
@click.option("--llm-model", help="LLM model name (optional)")
@click.option("--deep", is_flag=True, help="Deep analysis: fetch and read all sources (requires --llm)")
def verify(claim: str, as_json: bool, search_provider: str, llm_provider: str, llm_model: str, deep: bool):
    """Verify a claim and return TruthScore (0-100).
    
    Analyzes credibility using multiple factors:
    - Publisher reputation (30%)
    - Content analysis (30%)
    - Corroboration (20%)
    - Fact-checks (20%)
    
    Uses DuckDuckGo by default (no API key needed).
    Use --deep with --llm for detailed content analysis.
    
    \b
    Examples:
        truthcheck verify "The Great Wall is visible from space"
        truthcheck verify "Earth is flat" --llm gemini --deep
    """
    from truthcheck.trace import verify_claim
    from truthcheck.search import DuckDuckGoProvider, BraveSearchProvider, SearXNGProvider
    
    # Set up search provider
    search_key = os.environ.get("TRUTHSCORE_SEARCH_KEY")
    provider = None
    
    if search_provider == "duckduckgo":
        try:
            provider = DuckDuckGoProvider()
        except Exception as e:
            click.echo(f"{RED}Error:{RESET} Could not initialize DuckDuckGo: {e}", err=True)
            sys.exit(1)
    elif search_provider == "brave":
        if not search_key:
            click.echo(
                f"{RED}Error:{RESET} Brave Search requires API key.\n\n"
                "Set TRUTHSCORE_SEARCH_KEY environment variable:\n"
                "  export TRUTHSCORE_SEARCH_KEY=your-brave-api-key\n\n"
                "Get a free key at: https://brave.com/search/api/\n\n"
                "Or use --search duckduckgo (no key needed)",
                err=True
            )
            sys.exit(1)
        provider = BraveSearchProvider(search_key)
    elif search_provider == "searxng":
        searxng_url = os.environ.get("SEARXNG_URL", "http://localhost:8080")
        provider = SearXNGProvider(searxng_url)
    
    # Warn if --deep without --llm
    if deep and not llm_provider:
        click.echo(
            f"{YELLOW}Warning:{RESET} --deep requires --llm for best results. "
            "Will fetch sources but analysis will be limited.",
            err=True
        )
    
    # Get LLM API key if using LLM
    llm_api_key = None
    if llm_provider in ("openai", "anthropic", "gemini"):
        llm_api_key = os.environ.get(f"TRUTHSCORE_{llm_provider.upper()}_KEY") or \
                      os.environ.get(f"{llm_provider.upper()}_API_KEY") or \
                      os.environ.get("GOOGLE_API_KEY")  # Common env var for Gemini
        if not llm_api_key:
            click.echo(
                f"{YELLOW}Warning:{RESET} No API key for {llm_provider}. "
                f"Set {llm_provider.upper()}_API_KEY or TRUTHSCORE_{llm_provider.upper()}_KEY",
                err=True
            )
            llm_provider = None
    
    result = verify_claim(
        claim, 
        search_provider=provider,
        llm_provider_name=llm_provider,
        llm_api_key=llm_api_key,
        llm_model=llm_model,
        deep_analysis=deep
    )
    
    if as_json:
        output = {
            "claim": result.claim,
            "truthscore": result.truthscore,
            "label": result.label,
            "score_breakdown": {
                "publisher_credibility": round(result.score_breakdown.publisher_credibility, 1),
                "content_analysis": round(result.score_breakdown.content_analysis, 1),
                "corroboration": round(result.score_breakdown.corroboration, 1),
                "fact_check": round(result.score_breakdown.fact_check, 1),
            },
            "zero_flags": {
                "is_satire": result.score_breakdown.is_satire,
                "is_fake_experiment": result.score_breakdown.is_fake_experiment,
                "is_entertainment": result.score_breakdown.is_entertainment,
                "is_ai_generated": result.score_breakdown.is_ai_generated,
                "is_self_published": result.score_breakdown.is_self_published,
            },
            "evidence": result.evidence,
            "fact_checks": [
                {"source": fc.source, "url": fc.url, "rating": fc.rating}
                for fc in result.fact_checks
            ],
            "sources_count": len(result.sources),
        }
        click.echo(json.dumps(output, indent=2))
    else:
        # Color based on score
        if result.truthscore == 0:
            color = RED
        elif result.truthscore < 30:
            color = RED
        elif result.truthscore < 60:
            color = YELLOW
        else:
            color = GREEN
        
        click.echo(f"\n{BOLD}Claim:{RESET} {result.claim}")
        click.echo(f"{BOLD}TruthScore:{RESET} {color}{result.truthscore}/100{RESET} ({result.label})")
        
        # Score breakdown
        sb = result.score_breakdown
        click.echo(f"\n{BOLD}Score Breakdown:{RESET}")
        click.echo(f"  Publisher Credibility: {sb.publisher_credibility:.0f}/100 (30%)")
        click.echo(f"  Content Analysis:      {sb.content_analysis:.0f}/100 (30%)")
        click.echo(f"  Corroboration:         {sb.corroboration:.0f}/100 (20%)")
        click.echo(f"  Fact-Check:            {sb.fact_check:.0f}/100 (20%)")
        
        # Zero flags
        zero_reason = sb.zero_reason
        if zero_reason:
            click.echo(f"\n{RED}⚠️ ZERO FLAG: {zero_reason}{RESET}")
        
        # Evidence
        if result.evidence:
            click.echo(f"\n{BOLD}Evidence:{RESET}")
            for ev in result.evidence[:7]:
                click.echo(f"  • {ev}")
        
        # Fact-checks
        if result.fact_checks:
            relevant_fcs = [fc for fc in result.fact_checks if fc.rating not in ("UNKNOWN", "UNVERIFIED")]
            if relevant_fcs:
                click.echo(f"\n{BOLD}Fact-Checks:{RESET}")
                for fc in relevant_fcs[:3]:
                    click.echo(f"  • {fc.source}: {fc.rating}")
        
        click.echo(f"\n{BOLD}Sources Analyzed:{RESET} {len(result.sources)}")
        click.echo()


@cli.command()
@click.argument("claim")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--quick", is_flag=True, help="Quick mode: analyze only 5 sources")
@click.option("--deep", "depth", flag_value=30, help="Deep mode: analyze up to 30 sources")
@click.option("--max-sources", default=15, help="Maximum sources to analyze (default: 15)")
@click.option("--threshold", default=0.5, help="Similarity threshold (0-1)")
def trace(claim: str, as_json: bool, quick: bool, depth: int, max_sources: int, threshold: float):
    """Trace a claim back to its origin.
    
    Finds the original source of a claim and builds a propagation tree
    showing how it spread across the web.
    
    Speed vs accuracy trade-off:
      --quick       Fast (5 sources, ~30 sec)
      (default)     Balanced (15 sources, ~1-2 min)
      --deep        Thorough (30 sources, ~3-5 min)
    
    \b
    Examples:
        truthcheck trace "Some claim" --quick      # Fast
        truthcheck trace "Some claim"              # Default
        truthcheck trace "Some claim" --deep       # Thorough
        truthcheck trace "Some claim" --max-sources 50  # Custom
    """
    # Apply quick/deep overrides
    if quick:
        max_sources = 5
    elif depth:
        max_sources = depth
    from truthcheck.trace import trace_claim
    
    click.echo(f"Tracing claim origin (analyzing up to {max_sources} sources)...")
    
    result = trace_claim(
        claim,
        similarity_threshold=threshold,
        max_sources=max_sources,
    )
    
    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        from truthcheck.visualize import visualize_full
        click.echo(visualize_full(result))


@cli.command()
@click.option("--verbose", "-v", is_flag=True, help="Show detailed progress")
def sync(verbose: bool):
    """Sync publisher database from Media Bias/Fact Check.
    
    Downloads the latest MBFC data and updates the local database.
    Run this periodically to stay current.
    
    Example:
        truthcheck sync
    """
    from truthcheck.sync import sync_database, get_database_path, load_database
    
    # Show current state
    db = load_database()
    meta = db.get("meta", {})
    current_count = meta.get("count", 0)
    current_date = meta.get("mbfc_date", "never")
    
    if current_count > 0:
        click.echo(f"Current database: {current_count} publishers (MBFC date: {current_date})")
    
    click.echo("Fetching latest MBFC data...")
    
    try:
        stats = sync_database(verbose=verbose)
        
        click.echo(f"\n{GREEN}✓ Sync complete!{RESET}")
        click.echo(f"  Imported: {stats['imported']} publishers")
        click.echo(f"  MBFC date: {stats['mbfc_date']}")
        click.echo(f"  Saved to: {stats['output']}")
        
    except Exception as e:
        click.echo(f"{RED}Error:{RESET} {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("domain")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def lookup(domain: str, as_json: bool):
    """Look up a publisher in the database.
    
    Example:
        truthcheck lookup reuters.com
    """
    db = PublisherDB()
    
    # Normalize domain
    try:
        if "/" in domain or ":" in domain:
            domain = extract_domain(domain)
    except ValueError:
        pass
    
    publisher = db.lookup(domain)
    
    if publisher:
        if as_json:
            output = {
                "found": True,
                "domain": publisher.domain,
                "name": publisher.name,
                "trust_score": publisher.trust_score,
                "category": publisher.category,
                "verified": publisher.verified,
                "bias": publisher.bias,
                "fact_check_rating": publisher.fact_check_rating,
            }
            click.echo(json.dumps(output, indent=2))
        else:
            click.echo(f"\n{BOLD}Publisher Found:{RESET}")
            click.echo(f"  Domain: {publisher.domain}")
            click.echo(f"  Name: {publisher.name}")
            click.echo(f"  Trust Score: {publisher.trust_score}")
            click.echo(f"  Category: {publisher.category}")
            click.echo(f"  Verified: {publisher.verified}")
            if publisher.bias:
                click.echo(f"  Bias: {publisher.bias}")
            if publisher.fact_check_rating:
                click.echo(f"  Fact Check Rating: {publisher.fact_check_rating}")
            click.echo()
    else:
        if as_json:
            click.echo(json.dumps({"found": False, "domain": domain}))
        else:
            click.echo(f"\n{YELLOW}Publisher not found:{RESET} {domain}")
            click.echo("Consider contributing this publisher to the database!")
            click.echo("See: https://github.com/truthscore/truthscore/blob/main/CONTRIBUTING.md")
            click.echo()


def main():
    """Entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
