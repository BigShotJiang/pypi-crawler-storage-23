"""
TruthScore Search Providers.

Supports multiple search backends:
- DuckDuckGo (free, no API key required)
- Brave Search (API key, 2000 free/month)
- Google Custom Search (API key, 100 free/day)
- SearXNG (self-hosted, free)
"""
from typing import Protocol
import requests

from truthcheck.models import SearchResult


class SearchProvider(Protocol):
    """Protocol for search providers."""
    
    def search(self, query: str, num_results: int = 10) -> list[SearchResult]:
        """Search for a query and return results."""
        ...


class DuckDuckGoProvider:
    """
    DuckDuckGo search provider (free, no API key).
    
    Uses the ddgs library for reliable searching.
    Lower quality than Google/Brave but works without any API key.
    """
    
    def __init__(self):
        """Initialize DuckDuckGo provider."""
        try:
            from ddgs import DDGS
            self._ddgs_available = True
        except ImportError:
            self._ddgs_available = False
    
    def search(self, query: str, num_results: int = 10) -> list[SearchResult]:
        """
        Search using DuckDuckGo.
        
        Args:
            query: Search query
            num_results: Number of results to return
            
        Returns:
            List of SearchResult objects
        """
        if not self._ddgs_available:
            # Fallback message
            return []
        
        try:
            from ddgs import DDGS
            
            results = []
            ddg_results = DDGS().text(query, max_results=num_results)
            
            for item in ddg_results:
                results.append(SearchResult(
                    url=item.get("href", ""),
                    title=item.get("title", ""),
                    snippet=item.get("body", ""),
                    source="duckduckgo"
                ))
            
            return results
            
        except Exception:
            return []


class BraveSearchProvider:
    """
    Brave Search API provider.
    
    Get API key at: https://brave.com/search/api/
    Free tier: 2,000 queries/month
    Paid: $5 per 1,000 queries
    """
    
    BASE_URL = "https://api.search.brave.com/res/v1/web/search"
    
    def __init__(self, api_key: str):
        """
        Initialize Brave search provider.
        
        Args:
            api_key: Brave Search API key
        """
        if not api_key:
            raise ValueError("Brave API key is required")
        self.api_key = api_key
    
    def search(self, query: str, num_results: int = 10) -> list[SearchResult]:
        """
        Search using Brave Search API.
        
        Args:
            query: Search query
            num_results: Number of results to return
            
        Returns:
            List of SearchResult objects
        """
        try:
            response = requests.get(
                self.BASE_URL,
                headers={
                    "Accept": "application/json",
                    "X-Subscription-Token": self.api_key,
                },
                params={"q": query, "count": num_results},
                timeout=10
            )
            response.raise_for_status()
            data = response.json()
            
            results = []
            for item in data.get("web", {}).get("results", [])[:num_results]:
                results.append(SearchResult(
                    url=item.get("url", ""),
                    title=item.get("title", ""),
                    snippet=item.get("description", ""),
                    source="brave"
                ))
            
            return results
            
        except requests.RequestException:
            return []


class GoogleSearchProvider:
    """
    Google Custom Search API provider.
    
    Setup:
    1. Create project: https://console.cloud.google.com/
    2. Enable Custom Search API
    3. Create search engine: https://programmablesearchengine.google.com/
    4. Get API key from Cloud Console
    
    Free tier: 100 queries/day
    Paid: $5 per 1,000 queries
    """
    
    BASE_URL = "https://www.googleapis.com/customsearch/v1"
    
    def __init__(self, api_key: str, cx: str):
        """
        Initialize Google search provider.
        
        Args:
            api_key: Google API key
            cx: Custom Search Engine ID
        """
        if not api_key:
            raise ValueError("Google API key is required")
        if not cx:
            raise ValueError("Google Custom Search Engine ID (cx) is required")
        self.api_key = api_key
        self.cx = cx
    
    def search(self, query: str, num_results: int = 10) -> list[SearchResult]:
        """
        Search using Google Custom Search API.
        
        Args:
            query: Search query
            num_results: Number of results to return (max 10 per request)
            
        Returns:
            List of SearchResult objects
        """
        try:
            response = requests.get(
                self.BASE_URL,
                params={
                    "key": self.api_key,
                    "cx": self.cx,
                    "q": query,
                    "num": min(num_results, 10),  # Google max is 10
                },
                timeout=10
            )
            response.raise_for_status()
            data = response.json()
            
            results = []
            for item in data.get("items", []):
                results.append(SearchResult(
                    url=item.get("link", ""),
                    title=item.get("title", ""),
                    snippet=item.get("snippet", ""),
                    source="google"
                ))
            
            return results
            
        except requests.RequestException:
            return []


class SearXNGProvider:
    """
    SearXNG self-hosted search provider.
    
    Free, unlimited searches. Aggregates results from multiple engines.
    Setup: https://docs.searxng.org/
    
    Quick start:
        docker run -d -p 8080:8080 searxng/searxng
    """
    
    def __init__(self, base_url: str = "http://localhost:8080"):
        """
        Initialize SearXNG provider.
        
        Args:
            base_url: SearXNG instance URL
        """
        self.base_url = base_url.rstrip("/")
    
    def search(self, query: str, num_results: int = 10) -> list[SearchResult]:
        """
        Search using SearXNG.
        
        Args:
            query: Search query
            num_results: Number of results to return
            
        Returns:
            List of SearchResult objects
        """
        try:
            response = requests.get(
                f"{self.base_url}/search",
                params={
                    "q": query,
                    "format": "json",
                    "engines": "google,bing,duckduckgo",
                },
                timeout=15
            )
            response.raise_for_status()
            data = response.json()
            
            results = []
            for item in data.get("results", [])[:num_results]:
                results.append(SearchResult(
                    url=item.get("url", ""),
                    title=item.get("title", ""),
                    snippet=item.get("content", ""),
                    source="searxng"
                ))
            
            return results
            
        except requests.RequestException:
            return []
