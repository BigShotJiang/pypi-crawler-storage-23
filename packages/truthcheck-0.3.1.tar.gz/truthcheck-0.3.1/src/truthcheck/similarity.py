"""
TruthScore Similarity Engine.

Local text similarity using MinHash (LSH) for near-duplicate detection.
No heavy dependencies - runs fast on any machine.
"""
import re
from typing import Optional
import logging

logger = logging.getLogger(__name__)

# Lazy load MinHash
_minhash_available = None


def _check_minhash():
    """Check if datasketch is available."""
    global _minhash_available
    if _minhash_available is None:
        try:
            from datasketch import MinHash
            _minhash_available = True
        except ImportError:
            _minhash_available = False
    return _minhash_available


def _tokenize(text: str) -> list[str]:
    """
    Tokenize text into shingles (n-grams) for MinHash.
    
    Uses word 3-grams for better accuracy than single words.
    """
    # Normalize
    text = text.lower()
    text = re.sub(r'[^\w\s]', ' ', text)
    words = text.split()
    
    # Generate 3-grams (shingles)
    if len(words) < 3:
        return words
    
    shingles = []
    for i in range(len(words) - 2):
        shingle = ' '.join(words[i:i+3])
        shingles.append(shingle)
    
    return shingles


def _get_minhash(text: str, num_perm: int = 128):
    """Create a MinHash signature for text."""
    from datasketch import MinHash
    
    mh = MinHash(num_perm=num_perm)
    for shingle in _tokenize(text):
        mh.update(shingle.encode('utf8'))
    
    return mh


def _jaccard_fallback(text1: str, text2: str) -> float:
    """
    Pure Python Jaccard similarity fallback.
    
    Used when datasketch is not installed.
    """
    tokens1 = set(_tokenize(text1))
    tokens2 = set(_tokenize(text2))
    
    if not tokens1 or not tokens2:
        return 0.0
    
    intersection = len(tokens1 & tokens2)
    union = len(tokens1 | tokens2)
    
    return intersection / union if union > 0 else 0.0


def extract_relevant_paragraphs(
    text: str, 
    keywords: list[str], 
    max_chars: int = 2000
) -> str:
    """
    Extract paragraphs relevant to the claim keywords.
    
    This keeps the text focused for similarity comparison.
    
    Args:
        text: Full document text
        keywords: Keywords from the claim to match
        max_chars: Maximum characters to return
        
    Returns:
        Concatenated relevant paragraphs
    """
    if not text or not keywords:
        return text[:max_chars] if text else ""
    
    # Normalize keywords
    keywords_lower = [kw.lower() for kw in keywords if len(kw) > 2]
    
    # Split into paragraphs
    paragraphs = re.split(r'\n\s*\n', text)
    
    # Score each paragraph by keyword matches
    scored = []
    for p in paragraphs:
        p_lower = p.lower()
        score = sum(1 for kw in keywords_lower if kw in p_lower)
        if score > 0:
            scored.append((score, p))
    
    # Sort by score descending
    scored.sort(key=lambda x: -x[0])
    
    # Take top paragraphs up to max_chars
    result = []
    total_chars = 0
    for score, p in scored:
        if total_chars + len(p) > max_chars:
            break
        result.append(p)
        total_chars += len(p)
    
    # If no matches, fall back to first max_chars
    if not result:
        return text[:max_chars]
    
    return "\n\n".join(result)


def extract_claim_keywords(claim: str) -> list[str]:
    """
    Extract key terms from a claim for matching.
    
    Focuses on proper nouns, numbers, and distinctive words.
    """
    # Common stop words to filter out
    stop_words = {
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare',
        'ought', 'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by',
        'from', 'as', 'into', 'through', 'during', 'before', 'after', 'above',
        'below', 'between', 'under', 'again', 'further', 'then', 'once',
        'here', 'there', 'when', 'where', 'why', 'how', 'all', 'each', 'few',
        'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only',
        'own', 'same', 'so', 'than', 'too', 'very', 'just', 'and', 'but',
        'if', 'or', 'because', 'until', 'while', 'that', 'which', 'who',
        'whom', 'this', 'these', 'those', 'am', 'what', 'it', 'its', 'i',
        'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your',
        'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself',
        'she', 'her', 'hers', 'herself', 'they', 'them', 'their', 'theirs',
        'themselves', 'best', 'worst', 'first', 'last', 'most', 'least'
    }
    
    # Find proper nouns (capitalized sequences)
    proper_nouns = re.findall(r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b', claim)
    
    # Find other words
    words = re.findall(r'\b\w+\b', claim.lower())
    keywords = [w for w in words if w not in stop_words and len(w) > 2]
    
    # Combine: proper nouns first, then keywords
    result = list(proper_nouns)
    for kw in keywords:
        if kw.lower() not in [r.lower() for r in result]:
            result.append(kw)
    
    return result[:10]  # Top 10


def compute_similarity(text1: str, text2: str) -> float:
    """
    Compute similarity between two texts using MinHash.
    
    Falls back to pure Python Jaccard if datasketch not installed.
    
    Args:
        text1: First text
        text2: Second text
        
    Returns:
        Similarity score 0.0 to 1.0
    """
    if not text1 or not text2:
        return 0.0
    
    # Truncate very long texts
    text1 = text1[:10000]
    text2 = text2[:10000]
    
    if _check_minhash():
        mh1 = _get_minhash(text1)
        mh2 = _get_minhash(text2)
        return mh1.jaccard(mh2)
    else:
        # Pure Python fallback
        return _jaccard_fallback(text1, text2)


def compute_similarity_batch(
    target: str, 
    candidates: list[str]
) -> list[float]:
    """
    Compute similarity between target and multiple candidates.
    
    Args:
        target: Target text to compare against
        candidates: List of candidate texts
        
    Returns:
        List of similarity scores
    """
    if not target or not candidates:
        return [0.0] * len(candidates)
    
    target = target[:10000]
    
    if _check_minhash():
        target_mh = _get_minhash(target)
        similarities = []
        for cand in candidates:
            if not cand:
                similarities.append(0.0)
            else:
                cand_mh = _get_minhash(cand[:10000])
                similarities.append(target_mh.jaccard(cand_mh))
        return similarities
    else:
        # Pure Python fallback
        return [_jaccard_fallback(target, c[:10000] if c else "") for c in candidates]


def find_most_similar(
    target: str, 
    candidates: list[tuple[str, any]],  # (text, metadata)
    threshold: float = 0.3
) -> Optional[tuple[float, any]]:
    """
    Find the most similar candidate to target.
    
    Args:
        target: Target text
        candidates: List of (text, metadata) tuples
        threshold: Minimum similarity to return a match (default 0.3 for MinHash)
        
    Returns:
        (similarity, metadata) of best match, or None if below threshold
    """
    if not candidates:
        return None
    
    texts = [c[0] for c in candidates]
    similarities = compute_similarity_batch(target, texts)
    
    best_idx = max(range(len(similarities)), key=lambda i: similarities[i])
    best_sim = similarities[best_idx]
    
    if best_sim >= threshold:
        return (best_sim, candidates[best_idx][1])
    
    return None
