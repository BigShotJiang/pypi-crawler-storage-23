"""
TruthScore Publisher Database.

Loads publisher data from:
1. JSON database (synced from MBFC) - primary source
2. YAML files - local overrides

Auto-syncs from MBFC if data is stale (> 7 days old).
"""
import json
from pathlib import Path
from typing import Optional, Iterator
import logging
import yaml

from truthcheck.models import Publisher
from truthcheck.utils import normalize_domain, get_parent_domain, extract_domain


logger = logging.getLogger(__name__)

# Module-level flag to ensure we only auto-sync once per process
_auto_sync_done = False


def get_data_dir() -> Path:
    """Get the path to the data directory."""
    return Path(__file__).parent / "data"


def get_json_db_path() -> Path:
    """Get the path to the JSON database."""
    return get_data_dir() / "publishers.json"


def get_yaml_overrides_path() -> Path:
    """Get the path to YAML overrides directory."""
    return get_data_dir() / "publishers"


class PublisherDB:
    """
    Publisher database with JSON primary + YAML overrides.
    
    Usage:
        db = PublisherDB()
        
        publisher = db.lookup("nytimes.com")
        if publisher:
            print(f"{publisher.name}: {publisher.trust_score}")
    """
    
    def __init__(self, data_path: Optional[Path] = None):
        """
        Initialize the publisher database.
        
        Args:
            data_path: Path to data directory (for testing).
                       If None, uses package data.
        """
        if data_path is None:
            self._json_path = get_json_db_path()
            self._yaml_path = get_yaml_overrides_path()
        else:
            data_path = Path(data_path)
            self._json_path = data_path / "publishers.json"
            self._yaml_path = data_path / "publishers"
        
        self._publishers: dict[str, Publisher] = {}
        self._meta: dict = {}
        self._load_all()
    
    def _load_all(self) -> None:
        """Load all publishers from JSON + YAML overrides."""
        # Load JSON database (primary)
        self._load_json()
        
        # Load YAML overrides (can override JSON entries)
        self._load_yaml_overrides()
    
    def _load_json(self) -> None:
        """Load the JSON database, auto-syncing if stale."""
        global _auto_sync_done
        
        # Auto-sync if stale (only once per process, only for default path)
        if not _auto_sync_done and self._json_path == get_json_db_path():
            _auto_sync_done = True
            try:
                from truthcheck.sync import auto_sync
                if auto_sync(max_age_days=7, timeout=5):
                    logger.info("Auto-synced publisher database from MBFC")
            except Exception as e:
                logger.debug(f"Auto-sync skipped: {e}")
        
        if not self._json_path.exists():
            logger.info(f"JSON database not found: {self._json_path}")
            logger.info("Run 'truthcheck sync' to download publisher data")
            return
        
        try:
            with open(self._json_path) as f:
                data = json.load(f)
            
            self._meta = data.get("meta", {})
            publishers = data.get("publishers", {})
            
            for domain, info in publishers.items():
                try:
                    publisher = self._convert_json_publisher(domain, info)
                    self._publishers[domain] = publisher
                except Exception as e:
                    logger.debug(f"Failed to convert {domain}: {e}")
            
            logger.info(f"Loaded {len(self._publishers)} publishers from JSON")
            
        except (json.JSONDecodeError, IOError) as e:
            logger.warning(f"Failed to load JSON database: {e}")
    
    def _convert_json_publisher(self, domain: str, info: dict) -> Publisher:
        """Convert JSON publisher entry to Publisher object."""
        # Map credibility to category
        credibility = info.get("credibility", "medium")
        category_map = {
            "high": "mainstream",
            "medium": "general",
            "low": "questionable",
        }
        
        # Map flags to verified status
        flags = info.get("flags", [])
        verified = credibility == "high" and not flags
        
        return Publisher(
            domain=domain,
            name=info.get("name", domain),
            trust_score=info.get("trust_score", 0.5),
            category=category_map.get(credibility, "general"),
            verified=verified,
            bias=info.get("bias"),
            fact_check_rating=info.get("reporting"),
        )
    
    def _load_yaml_overrides(self) -> None:
        """Load YAML files as overrides."""
        if not self._yaml_path.exists():
            return
        
        for yaml_file in self._yaml_path.glob("*.yaml"):
            # Skip template files
            if yaml_file.name.startswith("_"):
                continue
            
            try:
                content = yaml_file.read_text()
                publisher = Publisher.from_yaml(content)
                domain = normalize_domain(publisher.domain)
                self._publishers[domain] = publisher
                logger.debug(f"Override loaded: {domain}")
            except Exception as e:
                logger.warning(f"Failed to load {yaml_file}: {e}")
    
    @property
    def meta(self) -> dict:
        """Get database metadata (source, date, count)."""
        return self._meta
    
    def lookup(self, domain: str) -> Optional[Publisher]:
        """
        Look up a publisher by domain.
        
        Handles:
        - Case normalization (EXAMPLE.COM -> example.com)
        - www prefix removal (www.example.com -> example.com)
        - Subdomain fallback (blog.example.com -> example.com)
        
        Args:
            domain: Domain to look up
            
        Returns:
            Publisher if found, None otherwise
        """
        domain = normalize_domain(domain)
        
        # Direct match
        if domain in self._publishers:
            return self._publishers[domain]
        
        # Try parent domain (for subdomains)
        parent = get_parent_domain(domain)
        while parent:
            if parent in self._publishers:
                return self._publishers[parent]
            parent = get_parent_domain(parent)
        
        return None
    
    def lookup_url(self, url: str) -> Optional[Publisher]:
        """
        Look up a publisher from a full URL.
        
        Args:
            url: Full URL to extract domain from
            
        Returns:
            Publisher if found, None otherwise
        """
        try:
            domain = extract_domain(url)
            return self.lookup(domain)
        except ValueError:
            return None
    
    def all(self) -> Iterator[Publisher]:
        """Iterate over all publishers in the database."""
        yield from self._publishers.values()
    
    def __len__(self) -> int:
        """Return the number of publishers in the database."""
        return len(self._publishers)
    
    def __contains__(self, domain: str) -> bool:
        """Check if a domain is in the database."""
        return self.lookup(domain) is not None
