"""
TruthScore Claim Tracing.

Find sources for claims and verify them.
"""
import re
from typing import Optional, Protocol

from truthcheck.models import TraceResult, FactCheck, SearchResult, ScoreBreakdown
from truthcheck.search import BraveSearchProvider, SearchProvider
from truthcheck.utils import extract_domain, fetch_content
from truthcheck.publisher_db import PublisherDB


class LLMProvider(Protocol):
    """Protocol for LLM providers."""
    def analyze_fact_check(self, claim: str, source_content: str, source_url: str) -> dict:
        ...


# Known fact-checking domains
FACT_CHECK_DOMAINS = [
    "snopes.com",
    "politifact.com",
    "factcheck.org",
    "fullfact.org",
    "truthorfiction.com",
    "reuters.com/fact-check",
    "apnews.com/ap-fact-check",
    "washingtonpost.com/news/fact-checker",
    "leadstories.com",
    "checkyourfact.com",
]


class ClaimTracer:
    """
    Traces claims to find sources and fact-checks.
    
    Searches the web for a claim, identifies fact-check articles,
    and synthesizes a verdict based on available information.
    
    With LLM: Reads and understands fact-check articles for accurate verdicts.
    Without LLM: Uses regex patterns to extract verdicts (less accurate).
    """
    
    def __init__(
        self, 
        search_provider: SearchProvider,
        llm_provider: Optional[LLMProvider] = None,
        deep_analysis: bool = False,
        publisher_db: Optional[PublisherDB] = None
    ):
        """
        Initialize claim tracer.
        
        Args:
            search_provider: Search provider to use for queries
            llm_provider: Optional LLM for intelligent analysis
            deep_analysis: If True, fetch and analyze ALL sources (not just fact-checkers)
            publisher_db: Optional publisher database for reputation checking
            
        Raises:
            ValueError: If search_provider is None
        """
        if search_provider is None:
            raise ValueError("Search provider is required")
        self.search_provider = search_provider
        self.llm_provider = llm_provider
        self.deep_analysis = deep_analysis
        self.publisher_db = publisher_db or PublisherDB()
    
    def trace(self, claim: str) -> TraceResult:
        """
        Trace a claim and calculate TruthScore (0-100).
        
        Args:
            claim: The claim to trace
            
        Returns:
            TraceResult with truthscore, score_breakdown, and evidence
        """
        # Extract key terms from claim for smarter searching
        key_terms = self._extract_key_terms(claim)
        
        # Multi-strategy search for better coverage
        all_search_results = []
        
        # Strategy 1: Direct claim search
        search_results = self.search_provider.search(claim, num_results=8)
        all_search_results.extend(search_results)
        
        # Strategy 2: Key terms search (catches more relevant sources)
        if key_terms:
            term_query = " ".join(key_terms)
            term_results = self.search_provider.search(term_query, num_results=5)
            all_search_results.extend(term_results)
        
        # Strategy 3: Search for "hoax" or "fake" + claim terms (catches debunking)
        debunk_query = f'{" ".join(key_terms[:3])} hoax OR fake OR experiment OR debunk'
        debunk_results = self.search_provider.search(debunk_query, num_results=3)
        all_search_results.extend(debunk_results)
        
        # Strategy 4: Fact-check sites
        fact_check_query = f'{" ".join(key_terms[:3])} site:snopes.com OR site:politifact.com OR site:factcheck.org'
        fact_check_results = self.search_provider.search(fact_check_query, num_results=5)
        
        # Combine and deduplicate results
        seen_urls = set()
        all_results = []
        for r in all_search_results + fact_check_results:
            if r.url not in seen_urls:
                seen_urls.add(r.url)
                all_results.append(r)
        
        # Initialize scoring
        evidence = []
        fact_checks = []
        sources = []
        source_analyses = []
        
        # Flags that force score to 0
        is_satire = False
        is_fake_experiment = False
        is_entertainment = False
        is_ai_generated = False
        is_self_published = False
        reports_as_hoax = False
        
        # Score accumulators
        publisher_scores = []
        content_scores = []
        corroboration_count = 0
        reputable_sources_count = 0
        
        for result in all_results:
            try:
                domain = extract_domain(result.url)
            except ValueError:
                continue
            
            if self._is_fact_check_domain(domain):
                # Analyze fact-check source
                if self.llm_provider:
                    rating, _ = self._analyze_with_llm(claim, result)
                else:
                    rating = self._extract_rating(result.title + " " + result.snippet)
                
                fact_checks.append(FactCheck(
                    source=domain,
                    url=result.url,
                    rating=rating or "UNKNOWN"
                ))
            else:
                sources.append(result)
                
                # Deep analysis with LLM
                if self.deep_analysis and self.llm_provider and len(source_analyses) < 5:
                    analysis = self._analyze_source_credibility(claim, result, domain)
                    if analysis:
                        source_analyses.append(analysis)
                        
                        # Check for zero-score flags
                        flags = analysis.get("flags", {})
                        if flags.get("self_published"):
                            is_self_published = True
                            evidence.append(f"⚠️ Self-published: {domain} publishes claims about its own subject")
                        if flags.get("satire"):
                            is_satire = True
                            evidence.append(f"🎭 Satire detected: {domain}")
                        if flags.get("fake_experiment"):
                            is_fake_experiment = True
                            evidence.append(f"🧪 Fake experiment: Content designed to test AI/media")
                        if flags.get("entertainment"):
                            is_entertainment = True
                            evidence.append(f"🎬 Entertainment: Not factual content")
                        if flags.get("ai_generated"):
                            is_ai_generated = True
                            evidence.append(f"🤖 AI-generated misinformation detected")
                        if analysis.get("reports_as_hoax"):
                            reports_as_hoax = True
                            evidence.append(f"📰 {domain} reports this claim as a hoax/fake")
                        
                        # Collect scores
                        rep = analysis.get("reputation", {})
                        pub_score = rep.get("trust_score", 0.5) * 100
                        publisher_scores.append(pub_score)
                        
                        content_score = analysis.get("content_score", 50)
                        if isinstance(content_score, float) and content_score <= 1:
                            content_score = content_score * 100
                        content_scores.append(content_score)
                        
                        # Track corroboration
                        if rep.get("trust_score", 0) >= 0.7:
                            reputable_sources_count += 1
                            if analysis.get("rating") == "TRUE":
                                corroboration_count += 1
                        
                        # Collect evidence from analysis
                        for ev in analysis.get("evidence", []):
                            if ev and len(evidence) < 10:
                                evidence.append(f"[{domain}] {ev}")
        
        # Deduplicate fact-checks
        seen_urls = set()
        unique_fact_checks = []
        for fc in fact_checks:
            if fc.url not in seen_urls:
                seen_urls.add(fc.url)
                unique_fact_checks.append(fc)
        
        # Calculate factor scores (0-100)
        publisher_credibility = sum(publisher_scores) / len(publisher_scores) if publisher_scores else 50
        content_analysis = sum(content_scores) / len(content_scores) if content_scores else 50
        
        # Corroboration score: based on reputable sources confirming
        if reputable_sources_count > 0:
            corroboration = (corroboration_count / reputable_sources_count) * 100
        else:
            corroboration = 50  # Neutral if no reputable sources
        
        # Fact-check score: based on fact-checker verdicts
        fact_check_score = 50  # Default neutral
        fc_ratings = [fc.rating for fc in unique_fact_checks if fc.rating != "UNKNOWN"]
        if fc_ratings:
            true_count = sum(1 for r in fc_ratings if r in ("TRUE", "MOSTLY TRUE"))
            false_count = sum(1 for r in fc_ratings if r in ("FALSE", "MOSTLY FALSE"))
            if true_count > false_count:
                fact_check_score = 70 + (true_count / len(fc_ratings)) * 30
            elif false_count > true_count:
                fact_check_score = 30 - (false_count / len(fc_ratings)) * 30
        
        # If reputable sources report this AS a hoax, it's strong evidence of FALSE
        if reports_as_hoax:
            content_analysis = min(content_analysis, 20)
            evidence.insert(0, "📰 Reputable source(s) report this claim as misinformation")
        
        # Build score breakdown
        score_breakdown = ScoreBreakdown(
            publisher_credibility=publisher_credibility,
            content_analysis=content_analysis,
            corroboration=corroboration,
            fact_check=fact_check_score,
            is_satire=is_satire,
            is_fake_experiment=is_fake_experiment,
            is_entertainment=is_entertainment,
            is_ai_generated=is_ai_generated,
            is_self_published=is_self_published and not reports_as_hoax  # Don't double-penalize
        )
        
        truthscore = score_breakdown.truthscore
        
        # Add zero-reason to evidence if applicable
        zero_reason = score_breakdown.zero_reason
        if zero_reason and zero_reason not in str(evidence):
            evidence.insert(0, f"🚨 {zero_reason}")
        
        return TraceResult(
            claim=claim,
            truthscore=truthscore,
            score_breakdown=score_breakdown,
            evidence=evidence[:10],  # Keep top 10 evidence points
            sources=sources,
            fact_checks=unique_fact_checks
        )
    
    def _analyze_with_llm(self, claim: str, result) -> tuple[Optional[str], Optional[str]]:
        """Use LLM to analyze a fact-check source."""
        try:
            # Try to fetch the actual content
            content = fetch_content(result.url)
        except Exception:
            # Fall back to snippet
            content = result.title + "\n" + result.snippet
        
        try:
            analysis = self.llm_provider.analyze_fact_check(
                claim=claim,
                source_content=content,
                source_url=result.url
            )
            return analysis.get("verdict"), analysis.get("summary")
        except Exception as e:
            # Fall back to regex on error
            return self._extract_rating(result.title + " " + result.snippet), None
    
    def _is_fact_check_domain(self, domain: str) -> bool:
        """Check if a domain is a known fact-checker."""
        domain = domain.lower()
        for fc_domain in FACT_CHECK_DOMAINS:
            if fc_domain in domain or domain in fc_domain:
                return True
        return False
    
    def _extract_key_terms(self, claim: str) -> list[str]:
        """
        Extract key terms from a claim for smarter searching.
        
        Focuses on names, nouns, and distinctive phrases.
        """
        import re
        
        # Find proper nouns (capitalized words)
        proper_nouns = re.findall(r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b', claim)
        
        # Remove common words
        stop_words = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
                      'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
                      'would', 'could', 'should', 'may', 'might', 'must', 'shall',
                      'at', 'by', 'for', 'from', 'in', 'of', 'on', 'to', 'with',
                      'and', 'but', 'or', 'nor', 'so', 'yet', 'that', 'this',
                      'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they'}
        
        words = claim.lower().split()
        key_words = [w for w in words if w not in stop_words and len(w) > 2]
        
        # Combine: proper nouns first (most important), then key words
        terms = []
        for pn in proper_nouns:
            terms.append(pn)
        for kw in key_words:
            if kw.lower() not in [t.lower() for t in terms]:
                terms.append(kw)
        
        return terms[:6]  # Top 6 terms
    
    def _get_publisher_reputation(self, domain: str) -> dict:
        """
        Get publisher reputation from database.
        
        Returns dict with trust_score, credibility, and bias.
        """
        publisher = self.publisher_db.lookup(domain)
        if publisher:
            return {
                "known": True,
                "name": publisher.name,
                "trust_score": publisher.trust_score,
                "credibility": "high" if publisher.trust_score >= 0.7 else 
                              "medium" if publisher.trust_score >= 0.4 else "low",
                "bias": publisher.bias,
                "fact_check_rating": publisher.fact_check_rating
            }
        return {
            "known": False,
            "trust_score": 0.3,  # Unknown sources get low default trust
            "credibility": "unknown"
        }
    
    def _is_self_published_claim(self, claim: str, domain: str) -> bool:
        """
        Detect if a claim is self-published (e.g., tomgermain.com claiming about Thomas Germain).
        
        This is a major red flag for misinformation.
        Returns False for known reputable publishers.
        """
        # First check if this is a known publisher - if so, not self-published
        if self.publisher_db:
            publisher = self.publisher_db.lookup(domain)
            if publisher and publisher.trust_score >= 0.5:
                return False  # Known reputable source, not self-published
        
        claim_lower = claim.lower()
        domain_lower = domain.lower()
        
        # Extract potential name from domain (e.g., "tomgermain" from "tomgermain.com")
        domain_name = domain_lower.split('.')[0].replace('-', '').replace('_', '')
        
        # Skip common generic domains
        generic_domains = {'www', 'blog', 'news', 'media', 'info', 'web', 'site', 'online'}
        if domain_name in generic_domains:
            return False
        
        # Look for person names in the claim (capitalized words that could be names)
        # and check if they match the domain
        import re
        # Find potential names (sequences of capitalized words)
        potential_names = re.findall(r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b', claim)
        
        for name in potential_names:
            name_lower = name.lower().replace(' ', '')
            # Check if the name (without spaces) matches or is contained in domain
            if len(name_lower) > 5:
                # Check for significant overlap
                if name_lower in domain_name or domain_name in name_lower:
                    return True
                # Check if last name (last word) is in domain
                last_name = name.split()[-1].lower()
                if len(last_name) > 4 and last_name in domain_name:
                    return True
        
        return False
    
    def _analyze_source_credibility(self, claim: str, result, domain: str) -> dict:
        """
        Perform multi-factor credibility analysis on a source.
        
        Returns analysis dict with:
        - reputation: Publisher reputation from MBFC
        - content_score: LLM credibility assessment (0-100)
        - flags: Zero-score flags (satire, fake_experiment, etc.)
        - evidence: Concise evidence points from LLM
        - reports_as_hoax: True if source reports claim AS misinformation
        """
        # Factor 1: Publisher reputation
        reputation = self._get_publisher_reputation(domain)
        
        # Factor 2: Self-published check
        is_self_published = self._is_self_published_claim(claim, domain)
        
        # Factor 3: LLM content analysis
        content_score = 50
        is_satire = False
        is_fake_experiment = False
        is_entertainment = False
        is_ai_generated = False
        reports_as_hoax = False
        evidence = []
        rating = "UNVERIFIED"
        
        if hasattr(self.llm_provider, 'analyze_credibility'):
            try:
                content = fetch_content(result.url)
            except Exception:
                content = result.title + "\n" + result.snippet
            
            try:
                analysis = self.llm_provider.analyze_credibility(
                    claim=claim,
                    source_content=content,
                    source_url=result.url
                )
                
                content_score = analysis.get("credibility_score", 50)
                is_satire = analysis.get("is_satire", False)
                is_fake_experiment = analysis.get("is_fake_experiment", False)
                is_entertainment = analysis.get("is_entertainment", False)
                is_ai_generated = analysis.get("is_ai_generated", False)
                reports_as_hoax = analysis.get("reports_as_hoax", False)
                evidence = analysis.get("evidence", [])
                
                # Determine rating based on content_score
                if content_score >= 70:
                    rating = "TRUE"
                elif content_score >= 40:
                    rating = "MIXED"
                else:
                    rating = "FALSE"
                    
            except Exception:
                # Fall back to basic analysis
                basic_rating, _ = self._analyze_with_llm(claim, result)
                rating = basic_rating or "UNVERIFIED"
                content_score = 70 if rating == "TRUE" else 30 if rating == "FALSE" else 50
        else:
            # Fall back to basic analysis
            basic_rating, _ = self._analyze_with_llm(claim, result)
            rating = basic_rating or "UNVERIFIED"
            content_score = 70 if rating == "TRUE" else 30 if rating == "FALSE" else 50
        
        return {
            "domain": domain,
            "url": result.url,
            "rating": rating,
            "content_score": content_score,
            "flags": {
                "self_published": is_self_published,
                "satire": is_satire,
                "fake_experiment": is_fake_experiment,
                "entertainment": is_entertainment,
                "ai_generated": is_ai_generated,
            },
            "reports_as_hoax": reports_as_hoax,
            "reputation": reputation,
            "evidence": evidence,
        }
    
    def _extract_rating(self, text: str) -> Optional[str]:
        """Extract rating from text (e.g., 'FALSE', 'TRUE')."""
        text = text.upper()
        
        # Look for explicit ratings
        patterns = [
            (r'\bFALSE\b', "FALSE"),
            (r'\bTRUE\b', "TRUE"),
            (r'\bMOSTLY FALSE\b', "FALSE"),
            (r'\bMOSTLY TRUE\b', "TRUE"),
            (r'\bPARTLY FALSE\b', "MIXED"),
            (r'\bMIXED\b', "MIXED"),
            (r'\bMIXTURE\b', "MIXED"),
            (r'\bUNPROVEN\b', "UNVERIFIED"),
        ]
        
        for pattern, rating in patterns:
            if re.search(pattern, text):
                return rating
        
        return None
    
    def _calculate_verdict(
        self, 
        fact_checks: list[FactCheck], 
        sources: list,
        source_analyses: list = None
    ) -> tuple[str, float]:
        """Calculate overall verdict from fact-checks, sources, and deep analysis."""
        source_analyses = source_analyses or []
        
        # Check for critical red flags
        self_published = [a for a in source_analyses if a.get("flags", {}).get("self_published")]
        satire_sources = [a for a in source_analyses if a.get("flags", {}).get("satire")]
        
        # If only evidence is self-published or satire = FALSE
        supporting_analyses = [a for a in source_analyses 
                             if not a.get("flags", {}).get("self_published") 
                             and not a.get("flags", {}).get("satire")]
        
        if (self_published or satire_sources) and not fact_checks and not supporting_analyses:
            reasons = []
            if self_published:
                reasons.append("self-published")
            if satire_sources:
                reasons.append("satire")
            return ("FALSE", 0.85)
        
        # Collect all ratings from fact-checks (high weight - authoritative)
        ratings = []
        for fc in fact_checks:
            if fc.rating != "UNKNOWN":
                ratings.append({"rating": fc.rating, "weight": 3.0})  # Fact-checkers get triple weight
        
        # Add ratings from deep source analysis (weighted by credibility score)
        for analysis in source_analyses:
            if analysis.get("rating") and analysis["rating"] != "UNKNOWN":
                # Use credibility score if available, otherwise reputation
                credibility = analysis.get("credibility_score", 
                              analysis.get("reputation", {}).get("trust_score", 0.3))
                
                # Flagged sources get penalty weight
                flags = analysis.get("flags", {})
                if flags.get("self_published") or flags.get("satire"):
                    # These sources actively count as FALSE evidence
                    ratings.append({"rating": "FALSE", "weight": 2.0})
                elif flags.get("extraordinary_claims"):
                    # Reduce weight for extraordinary claims without evidence
                    ratings.append({"rating": analysis["rating"], "weight": credibility * 0.5})
                else:
                    ratings.append({"rating": analysis["rating"], "weight": credibility})
        
        if not ratings:
            return ("UNVERIFIED", 0.3)
        
        # Weighted voting
        false_weight = sum(r["weight"] for r in ratings if r["rating"] == "FALSE")
        true_weight = sum(r["weight"] for r in ratings if r["rating"] == "TRUE")
        mixed_weight = sum(r["weight"] for r in ratings if r["rating"] == "MIXED")
        unverified_weight = sum(r["weight"] for r in ratings if r["rating"] == "UNVERIFIED")
        total_weight = false_weight + true_weight + mixed_weight + unverified_weight
        
        if total_weight == 0:
            return ("UNVERIFIED", 0.3)
        
        # Determine verdict based on weighted voting
        if false_weight > true_weight and false_weight >= (total_weight * 0.4):
            confidence = min(0.95, 0.5 + (false_weight / total_weight) * 0.45)
            return ("FALSE", confidence)
        elif true_weight > false_weight and true_weight >= (total_weight * 0.5):
            confidence = min(0.95, 0.5 + (true_weight / total_weight) * 0.45)
            return ("TRUE", confidence)
        elif mixed_weight > 0 or (false_weight > 0 and true_weight > 0):
            return ("MIXED", 0.5)
        else:
            return ("UNVERIFIED", 0.4)
    
    def _generate_summary(
        self, 
        claim: str, 
        verdict: str, 
        fact_checks: list[FactCheck],
        source_analyses: list = None
    ) -> str:
        """Generate a human-readable summary."""
        source_analyses = source_analyses or []
        total_sources = len(fact_checks) + len(source_analyses)
        
        # Check for critical flags
        self_published = [a for a in source_analyses if a.get("flags", {}).get("self_published")]
        satire = [a for a in source_analyses if a.get("flags", {}).get("satire")]
        extraordinary = [a for a in source_analyses if a.get("flags", {}).get("extraordinary_claims")]
        
        # Include insights from deep analysis
        deep_insights = []
        for analysis in source_analyses:
            if analysis.get("summary"):
                deep_insights.append(analysis["summary"])
        
        base_summary = ""
        if verdict == "FALSE":
            if self_published:
                base_summary = f"🚨 FALSE: The only supporting evidence is SELF-PUBLISHED ({self_published[0]['domain']}). This is a common misinformation pattern."
            elif satire:
                base_summary = f"🎭 FALSE: Source detected as SATIRE ({satire[0]['domain']}). Not factual content."
            else:
                base_summary = f"This claim appears to be FALSE based on {total_sources} source(s)."
        elif verdict == "TRUE":
            base_summary = f"✅ This claim appears to be TRUE based on {total_sources} source(s)."
        elif verdict == "MIXED":
            reasons = []
            if extraordinary:
                reasons.append("extraordinary claims without strong evidence")
            base_summary = f"⚖️ MIXED: This claim has conflicting evidence."
            if reasons:
                base_summary += f" ({'; '.join(reasons)})"
        else:
            base_summary = f"❓ UNVERIFIED: This claim could not be verified. Analyzed {total_sources} source(s)."
        
        # Append credibility details
        credibility_notes = []
        for analysis in source_analyses[:2]:  # Top 2 analyses
            cred_score = analysis.get("credibility_score")
            if cred_score is not None:
                domain = analysis.get("domain", "source")
                credibility_notes.append(f"{domain}: {cred_score:.0%} credibility")
        
        if credibility_notes:
            base_summary += f" [Credibility: {', '.join(credibility_notes)}]"
        
        # Append the most relevant deep insight
        for insight in deep_insights:
            # Skip if already covered in main summary
            if self_published and "SELF-PUBLISHED" in insight:
                continue
            if satire and "SATIRE" in insight:
                continue
            # Add first unique insight
            base_summary += " " + insight
            break
        
        return base_summary


def verify_claim(
    claim: str,
    search_api_key: Optional[str] = None,
    search_provider: Optional[SearchProvider] = None,
    llm_provider: Optional[LLMProvider] = None,
    llm_provider_name: Optional[str] = None,
    llm_api_key: Optional[str] = None,
    llm_model: Optional[str] = None,
    deep_analysis: bool = False,
) -> TraceResult:
    """
    Trace a claim to find sources and verdict.
    
    Convenience function that creates a ClaimTracer with the
    appropriate search provider and optional LLM.
    
    Args:
        claim: The claim to trace
        search_api_key: Brave Search API key (if no provider given)
        search_provider: Custom search provider (optional)
        llm_provider: Custom LLM provider (optional)
        llm_provider_name: LLM provider name (openai, anthropic, ollama, gemini)
        llm_api_key: LLM API key (for openai, anthropic, gemini)
        llm_model: LLM model name (optional)
        deep_analysis: If True, fetch and analyze ALL sources (not just fact-checkers)
        
    Returns:
        TraceResult with verdict, sources, and fact-checks
        
    Raises:
        ValueError: If no search provider or API key given
        
    Examples:
        # Basic with DuckDuckGo (free, no key)
        from truthcheck.search import DuckDuckGoProvider
        result = verify_claim("Earth is flat", search_provider=DuckDuckGoProvider())
        
        # With Gemini + deep analysis
        result = verify_claim(
            "Some claim about a person",
            search_provider=DuckDuckGoProvider(),
            llm_provider_name="gemini",
            llm_api_key="your-key",
            deep_analysis=True
        )
        
        # With local Ollama (free, private)
        result = verify_claim(
            "Earth is flat",
            search_provider=DuckDuckGoProvider(),
            llm_provider_name="ollama",
            llm_model="llama3"
        )
    """
    # Set up search provider
    if search_provider is None:
        if search_api_key is None:
            raise ValueError(
                "Search provider or API key required. Pass search_provider "
                "(e.g., DuckDuckGoProvider()) or search_api_key for Brave."
            )
        search_provider = BraveSearchProvider(search_api_key)
    
    # Set up LLM provider if specified
    if llm_provider is None and llm_provider_name:
        from truthcheck.llm import get_provider
        llm_provider = get_provider(
            llm_provider_name,
            api_key=llm_api_key,
            model=llm_model
        )
    
    tracer = ClaimTracer(
        search_provider, 
        llm_provider=llm_provider,
        deep_analysis=deep_analysis
    )
    return tracer.trace(claim)


# ============================================================================
# TRACE CLAIM - Origin Tracking
# ============================================================================

def trace_claim(
    claim: str,
    search_provider: Optional[SearchProvider] = None,
    search_api_key: Optional[str] = None,
    similarity_threshold: float = 0.5,
    max_sources: int = 20,
) -> dict:
    """
    Trace a claim back to its origin and build propagation tree.
    
    Unlike verify_claim (which scores truthfulness), this function
    tracks how a claim spread across the web.
    
    Args:
        claim: The claim to trace
        search_provider: Search provider (DuckDuckGoProvider by default)
        search_api_key: Brave API key if not using search_provider
        similarity_threshold: Min similarity to link sources (0.5 default)
        max_sources: Maximum sources to analyze
        
    Returns:
        Dict with origin, timeline, tree, graph, and stats
        
    Example:
        from truthcheck import trace_claim
        
        result = trace_claim("Thomas Germain is the best tech journalist at eating hot dogs")
        
        print(result["origin"])  # Earliest/original source
        print(result["timeline"])  # Chronological spread
        print(result["tree"])  # Hierarchical propagation
    """
    from truthcheck.search import DuckDuckGoProvider, BraveSearchProvider
    from truthcheck.similarity import extract_claim_keywords, extract_relevant_paragraphs
    from truthcheck.date_extractor import extract_date
    from truthcheck.propagation import Source, PropagationTreeBuilder
    
    # Set up search provider
    if search_provider is None:
        if search_api_key:
            search_provider = BraveSearchProvider(search_api_key)
        else:
            search_provider = DuckDuckGoProvider()
    
    # Extract keywords for searching
    keywords = extract_claim_keywords(claim)
    
    # Multi-strategy search
    all_results = []
    seen_urls = set()
    
    # Strategy 1: Direct claim search
    results = search_provider.search(claim, num_results=10)
    for r in results:
        if r.url not in seen_urls:
            seen_urls.add(r.url)
            all_results.append(r)
    
    # Strategy 2: Key terms search
    if keywords:
        term_query = " ".join(keywords[:5])
        results = search_provider.search(term_query, num_results=10)
        for r in results:
            if r.url not in seen_urls:
                seen_urls.add(r.url)
                all_results.append(r)
    
    # Limit to max_sources
    all_results = all_results[:max_sources]
    
    # Fetch and analyze each source
    sources = []
    
    for result in all_results:
        try:
            # Fetch content
            content = fetch_content(result.url)
            
            # Extract date
            date = extract_date(content, result.url)
            
            # Extract relevant paragraphs
            relevant = extract_relevant_paragraphs(content, keywords, max_chars=2000)
            
            # Get domain
            domain = extract_domain(result.url)
            
            source = Source(
                url=result.url,
                domain=domain,
                title=result.title,
                content=relevant,
                date=date,
            )
            sources.append(source)
            
        except Exception as e:
            # Skip sources we can't fetch
            continue
    
    # Build propagation tree
    builder = PropagationTreeBuilder(similarity_threshold=similarity_threshold)
    tree = builder.build(claim, sources)
    
    return tree.to_dict()
