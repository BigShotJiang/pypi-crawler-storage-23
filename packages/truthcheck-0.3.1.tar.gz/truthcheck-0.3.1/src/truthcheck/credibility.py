"""
TruthScore Credibility Scoring.

Multi-factor credibility assessment for claim verification.
"""
from dataclasses import dataclass
from typing import Optional, Protocol
import logging

logger = logging.getLogger(__name__)


@dataclass
class CredibilityScore:
    """Multi-factor credibility assessment."""
    
    # Individual scores (0.0 - 1.0)
    publisher_score: float = 0.5      # From MBFC database
    content_score: float = 0.5        # LLM analysis of content credibility
    verification_score: float = 0.5   # Cross-verification with other sources
    
    # Flags
    is_self_published: bool = False
    is_satire: bool = False
    has_extraordinary_claims: bool = False
    has_contradictions: bool = False
    corroborated_by_reputable: bool = False
    
    # Details
    publisher_name: Optional[str] = None
    content_analysis: Optional[str] = None
    verification_notes: Optional[str] = None
    
    @property
    def overall_score(self) -> float:
        """
        Calculate weighted overall credibility score.
        
        Weights:
        - Publisher: 30% (known reputation)
        - Content: 40% (what does the content actually say/show)
        - Verification: 30% (can it be independently verified)
        
        Penalties applied for red flags.
        """
        base_score = (
            self.publisher_score * 0.30 +
            self.content_score * 0.40 +
            self.verification_score * 0.30
        )
        
        # Apply penalties for red flags
        penalties = 0.0
        if self.is_self_published:
            penalties += 0.4  # Major red flag
        if self.is_satire:
            penalties += 0.5  # Content is not meant to be factual
        if self.has_extraordinary_claims:
            penalties += 0.2  # Needs extraordinary evidence
        if self.has_contradictions:
            penalties += 0.15
        
        # Apply bonus for corroboration
        bonus = 0.0
        if self.corroborated_by_reputable:
            bonus += 0.2
        
        final_score = max(0.0, min(1.0, base_score - penalties + bonus))
        return final_score
    
    @property
    def verdict(self) -> str:
        """Get verdict based on overall score."""
        score = self.overall_score
        if score >= 0.7:
            return "LIKELY_TRUE"
        elif score >= 0.5:
            return "UNCERTAIN"
        elif score >= 0.3:
            return "LIKELY_FALSE"
        else:
            return "FALSE"
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "overall_score": round(self.overall_score, 2),
            "verdict": self.verdict,
            "factors": {
                "publisher_score": round(self.publisher_score, 2),
                "content_score": round(self.content_score, 2),
                "verification_score": round(self.verification_score, 2),
            },
            "flags": {
                "is_self_published": self.is_self_published,
                "is_satire": self.is_satire,
                "has_extraordinary_claims": self.has_extraordinary_claims,
                "has_contradictions": self.has_contradictions,
                "corroborated_by_reputable": self.corroborated_by_reputable,
            },
            "details": {
                "publisher": self.publisher_name,
                "content_analysis": self.content_analysis,
                "verification": self.verification_notes,
            }
        }


# Enhanced LLM prompt for content credibility analysis
CONTENT_CREDIBILITY_PROMPT = """You are an expert fact-checker analyzing content credibility.

CLAIM BEING EVALUATED: {claim}

SOURCE URL: {source_url}

SOURCE CONTENT:
{source_content}

Analyze this source's CREDIBILITY for supporting the claim. Consider:

1. **Content Quality Signals**:
   - Is this journalism, opinion, satire, or promotional content?
   - Are claims supported by evidence, citations, or verifiable facts?
   - Is the writing professional or sensationalized?

2. **Red Flags for Misinformation**:
   - Satire indicators (disclaimers, absurd juxtapositions, humorous tone)
   - Extraordinary claims without extraordinary evidence
   - Internal contradictions or logical inconsistencies
   - "Too perfect" stories that confirm biases
   - Vague sources ("experts say", "studies show" without citations)
   - Emotional manipulation or outrage bait

3. **Fact-Checkable Elements**:
   - What specific facts does this source claim?
   - Are dates, names, places verifiable?
   - Does it contradict well-established knowledge?

4. **Source-Claim Relationship**:
   - Does the source have a conflict of interest?
   - Is this promoting the subject of the claim?
   - Is the source independent or affiliated?

Respond in JSON format:
{{
    "content_type": "journalism" | "opinion" | "satire" | "promotional" | "unknown",
    "credibility_score": 0.0-1.0,
    "supports_claim": true | false | "partially",
    "is_satire": true | false,
    "has_extraordinary_claims": true | false,
    "has_contradictions": true | false,
    "red_flags": ["list of specific red flags found"],
    "verifiable_facts": ["list of specific claims that could be independently checked"],
    "summary": "Brief analysis explaining your credibility assessment"
}}

Only respond with the JSON, no other text."""


CROSS_VERIFICATION_PROMPT = """You are verifying specific facts from a claim.

ORIGINAL CLAIM: {claim}

FACTS TO VERIFY:
{facts_to_verify}

SEARCH RESULTS FROM REPUTABLE SOURCES:
{search_results}

For each fact, determine if reputable sources confirm, contradict, or don't address it.

Respond in JSON format:
{{
    "verification_score": 0.0-1.0,
    "facts_confirmed": ["list of facts confirmed by reputable sources"],
    "facts_contradicted": ["list of facts contradicted"],
    "facts_unverified": ["list of facts not found in reputable sources"],
    "corroborating_sources": ["list of reputable sources that confirm key facts"],
    "contradicting_sources": ["list of sources that contradict"],
    "summary": "Overall verification assessment"
}}

Only respond with the JSON, no other text."""
