"""
TruthScore data models.

Core data structures for verification results, signals, and publishers.
"""
from dataclasses import dataclass, field
from typing import Literal, Optional
import yaml


# Type aliases
Recommendation = Literal["TRUST", "CAUTION", "REJECT"]
Verdict = Literal["TRUE", "FALSE", "MIXED", "UNVERIFIED"]


def get_recommendation(score: float) -> Recommendation:
    """
    Get recommendation based on trust score.
    
    Args:
        score: Trust score between 0 and 1
        
    Returns:
        TRUST if score >= 0.8
        CAUTION if score >= 0.5
        REJECT otherwise
    """
    if score >= 0.8:
        return "TRUST"
    elif score >= 0.5:
        return "CAUTION"
    return "REJECT"


@dataclass
class Signal:
    """
    A verification signal from an analyzer.
    
    Attributes:
        name: Analyzer name (e.g., "publisher", "domain", "content")
        score: Trust score between 0 and 1
        confidence: How confident we are in this score (0-1)
        details: Additional details from the analyzer
    """
    name: str
    score: float
    confidence: float
    details: dict = field(default_factory=dict)
    
    def __post_init__(self):
        if not 0 <= self.score <= 1:
            raise ValueError(f"Score must be between 0 and 1, got {self.score}")
        if not 0 <= self.confidence <= 1:
            raise ValueError(f"Confidence must be between 0 and 1, got {self.confidence}")


@dataclass
class Publisher:
    """
    A publisher from the community database.
    
    Attributes:
        domain: The domain name (e.g., "reuters.com")
        name: Human-readable name
        trust_score: Trust score between 0 and 1
        category: Category (news, academic, government, blog, other)
        bias: Optional political bias
        fact_check_rating: Optional fact-check rating
        verified: Whether this publisher has been verified
    """
    domain: str
    name: str
    trust_score: float
    category: str
    bias: Optional[str] = None
    fact_check_rating: Optional[str] = None
    verified: bool = False
    
    def __post_init__(self):
        if not 0 <= self.trust_score <= 1:
            raise ValueError(f"Trust score must be between 0 and 1, got {self.trust_score}")
    
    @classmethod
    def from_yaml(cls, content: str) -> "Publisher":
        """
        Create a Publisher from YAML content.
        
        Args:
            content: YAML string containing publisher data
            
        Returns:
            Publisher instance
            
        Raises:
            ValueError: If required fields are missing
        """
        data = yaml.safe_load(content)
        
        # Check required fields
        required = ["domain", "name", "trust_score", "category"]
        for field_name in required:
            if field_name not in data:
                raise ValueError(f"Missing required field: {field_name}")
        
        return cls(
            domain=data["domain"],
            name=data["name"],
            trust_score=data["trust_score"],
            category=data["category"],
            bias=data.get("bias"),
            fact_check_rating=data.get("fact_check_rating"),
            verified=data.get("verified", False),
        )


@dataclass
class VerificationResult:
    """
    Result of verifying a URL.
    
    Attributes:
        url: The URL that was verified
        trust_score: Overall trust score (0-1)
        recommendation: TRUST, CAUTION, or REJECT
        signals: Dict of signal name -> Signal
    """
    url: str
    trust_score: float
    recommendation: Recommendation
    signals: dict
    
    def __post_init__(self):
        valid_recommendations = ("TRUST", "CAUTION", "REJECT")
        if self.recommendation not in valid_recommendations:
            raise ValueError(
                f"Recommendation must be one of {valid_recommendations}, "
                f"got {self.recommendation}"
            )


@dataclass
class SearchResult:
    """
    A search result from a search provider.
    
    Attributes:
        url: URL of the result
        title: Page title
        snippet: Text snippet/description
        source: Search provider name
    """
    url: str
    title: str
    snippet: str
    source: str


@dataclass
class FactCheck:
    """
    A fact-check result.
    
    Attributes:
        source: Fact-check site domain
        url: URL of the fact-check article
        rating: Rating given (TRUE, FALSE, MIXED, etc.)
    """
    source: str
    url: str
    rating: str


@dataclass
class ScoreBreakdown:
    """
    Breakdown of TruthScore factors.
    
    Weights:
    - publisher_credibility: 30% - Is the source reputable?
    - content_analysis: 30% - Does the content make sense? Any red flags?
    - corroboration: 20% - Do other reputable sources confirm?
    - fact_check: 20% - What do fact-checkers say?
    """
    publisher_credibility: float = 50.0  # 0-100
    content_analysis: float = 50.0       # 0-100
    corroboration: float = 50.0          # 0-100
    fact_check: float = 50.0             # 0-100
    
    # Automatic zero flags
    is_satire: bool = False
    is_fake_experiment: bool = False
    is_entertainment: bool = False
    is_ai_generated: bool = False
    is_self_published: bool = False
    
    @property
    def truthscore(self) -> int:
        """Calculate weighted TruthScore (0-100)."""
        # If any automatic-zero flag is set, return 0
        if any([
            self.is_satire,
            self.is_fake_experiment,
            self.is_entertainment,
            self.is_ai_generated,
            self.is_self_published
        ]):
            return 0
        
        # Weighted sum
        score = (
            self.publisher_credibility * 0.30 +
            self.content_analysis * 0.30 +
            self.corroboration * 0.20 +
            self.fact_check * 0.20
        )
        return max(0, min(100, int(score)))
    
    @property
    def zero_reason(self) -> Optional[str]:
        """Return reason if score is forced to zero."""
        if self.is_satire:
            return "Content identified as satire"
        if self.is_fake_experiment:
            return "Content is a deliberate fake/experiment"
        if self.is_entertainment:
            return "Content is entertainment, not factual"
        if self.is_ai_generated:
            return "Content is AI-generated misinformation"
        if self.is_self_published:
            return "Only source is self-published by claim subject"
        return None


@dataclass
class TraceResult:
    """
    Result of tracing a claim.
    
    Attributes:
        claim: The claim that was traced
        truthscore: Score 0-100 (0=false, 100=true)
        score_breakdown: Detailed factor breakdown
        evidence: List of evidence points supporting the score
        sources: List of sources analyzed
        fact_checks: List of fact-check results found
    """
    claim: str
    truthscore: int  # 0-100
    score_breakdown: ScoreBreakdown
    evidence: list  # Concise evidence points
    sources: list
    fact_checks: list
    
    def __post_init__(self):
        if not 0 <= self.truthscore <= 100:
            raise ValueError(f"TruthScore must be 0-100, got {self.truthscore}")
    
    @property
    def label(self) -> str:
        """Human-readable label based on score."""
        if self.truthscore == 0:
            return "FALSE"
        elif self.truthscore < 25:
            return "LIKELY FALSE"
        elif self.truthscore < 50:
            return "UNCERTAIN"
        elif self.truthscore < 75:
            return "POSSIBLY TRUE"
        else:
            return "LIKELY TRUE"
