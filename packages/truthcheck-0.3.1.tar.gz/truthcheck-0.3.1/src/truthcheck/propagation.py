"""
TruthScore Propagation Tree Builder.

Build a tree showing how a claim spread across sources.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
import logging

from truthcheck.similarity import (
    compute_similarity_batch,
    extract_relevant_paragraphs,
    extract_claim_keywords
)
from truthcheck.date_extractor import extract_date, format_date

logger = logging.getLogger(__name__)


@dataclass
class Source:
    """A source that mentions the claim."""
    url: str
    domain: str
    title: str
    content: str  # Relevant paragraphs
    date: Optional[datetime] = None
    date_confidence: float = 1.0  # How confident we are in the date
    
    # Computed fields
    similarity_to_claim: float = 0.0
    parent_url: Optional[str] = None
    parent_similarity: float = 0.0
    
    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "domain": self.domain,
            "title": self.title,
            "date": format_date(self.date),
            "similarity_to_claim": round(self.similarity_to_claim, 2),
            "parent_url": self.parent_url,
            "parent_similarity": round(self.parent_similarity, 2) if self.parent_url else None,
        }


@dataclass
class PropagationTree:
    """Tree structure showing claim propagation."""
    claim: str
    origin: Optional[Source] = None
    sources: list[Source] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        """Convert to JSON-serializable dict."""
        return {
            "claim": self.claim,
            "origin": self.origin.to_dict() if self.origin else None,
            "timeline": self._build_timeline(),
            "tree": self._build_tree_structure(),
            "graph": self._build_graph(),
            "stats": self._build_stats(),
        }
    
    def _build_timeline(self) -> list[dict]:
        """Build chronological timeline."""
        def normalize_date(dt):
            """Remove timezone info for comparison."""
            if dt and hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
                return dt.replace(tzinfo=None)
            return dt
        
        dated_sources = [(s, s.date) for s in self.sources if s.date]
        dated_sources.sort(key=lambda x: normalize_date(x[1]))
        
        return [
            {
                "date": format_date(s.date),
                "url": s.url,
                "domain": s.domain,
                "title": s.title,
            }
            for s, _ in dated_sources
        ]
    
    def _build_tree_structure(self) -> Optional[dict]:
        """Build hierarchical tree structure."""
        if not self.origin:
            return None
        
        def build_node(source: Source) -> dict:
            children = [s for s in self.sources if s.parent_url == source.url]
            return {
                "url": source.url,
                "domain": source.domain,
                "date": format_date(source.date),
                "title": source.title,
                "children": [build_node(c) for c in children]
            }
        
        return build_node(self.origin)
    
    def _build_graph(self) -> dict:
        """Build nodes and edges for visualization."""
        nodes = [
            {
                "id": s.url,
                "domain": s.domain,
                "date": format_date(s.date),
                "title": s.title,
            }
            for s in self.sources
        ]
        
        edges = [
            {
                "from": s.parent_url,
                "to": s.url,
                "similarity": round(s.parent_similarity, 2),
            }
            for s in self.sources if s.parent_url
        ]
        
        return {"nodes": nodes, "edges": edges}
    
    def _build_stats(self) -> dict:
        """Build summary statistics."""
        def normalize_date(dt):
            """Remove timezone info for comparison."""
            if dt and hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
                return dt.replace(tzinfo=None)
            return dt
        
        dates = [s.date for s in self.sources if s.date]
        normalized_dates = [normalize_date(d) for d in dates]
        domains = [s.domain for s in self.sources]
        
        # Count domain frequencies
        domain_counts = {}
        for d in domains:
            domain_counts[d] = domain_counts.get(d, 0) + 1
        
        top_domains = sorted(domain_counts.items(), key=lambda x: -x[1])[:5]
        
        # Find min/max dates
        min_date = min(normalized_dates) if normalized_dates else None
        max_date = max(normalized_dates) if normalized_dates else None
        
        return {
            "sources_found": len(self.sources),
            "sources_with_dates": len(dates),
            "date_range": [
                format_date(min_date),
                format_date(max_date),
            ],
            "top_domains": [d for d, _ in top_domains],
        }


class PropagationTreeBuilder:
    """
    Build a propagation tree from sources.
    
    Algorithm:
    1. Sort sources by date (earliest first)
    2. For each source, find most similar earlier source
    3. If similarity > threshold, link as parent
    4. Origin = earliest source with no parent
    """
    
    def __init__(self, similarity_threshold: float = 0.5):
        """
        Initialize builder.
        
        Args:
            similarity_threshold: Min similarity to consider as "copied from"
        """
        self.threshold = similarity_threshold
    
    def build(
        self, 
        claim: str,
        sources: list[Source]
    ) -> PropagationTree:
        """
        Build propagation tree from sources.
        
        Args:
            claim: The claim being traced
            sources: List of sources mentioning the claim
            
        Returns:
            PropagationTree with origin, timeline, and graph
        """
        if not sources:
            return PropagationTree(claim=claim)
        
        # Extract keywords for relevance filtering
        keywords = extract_claim_keywords(claim)
        
        # Compute similarity to claim for all sources
        claim_text = claim
        source_texts = [s.content for s in sources]
        similarities = compute_similarity_batch(claim_text, source_texts)
        
        for i, s in enumerate(sources):
            s.similarity_to_claim = similarities[i]
        
        # Sort by date (unknowns at end)
        def date_sort_key(s):
            if s.date is None:
                return (1, datetime.max)  # Put unknowns at end
            # Make all datetimes comparable by removing timezone
            dt = s.date
            if hasattr(dt, 'tzinfo') and dt.tzinfo is not None:
                dt = dt.replace(tzinfo=None)
            return (0, dt)
        
        sources_sorted = sorted(sources, key=date_sort_key)
        
        # Build parent relationships
        for i, source in enumerate(sources_sorted):
            # Only look at earlier sources
            earlier = sources_sorted[:i]
            if not earlier:
                continue
            
            # Find most similar earlier source
            best_sim = 0.0
            best_parent = None
            
            earlier_texts = [e.content for e in earlier]
            sims = compute_similarity_batch(source.content, earlier_texts)
            
            for j, sim in enumerate(sims):
                if sim > best_sim:
                    best_sim = sim
                    best_parent = earlier[j]
            
            if best_sim >= self.threshold and best_parent:
                source.parent_url = best_parent.url
                source.parent_similarity = best_sim
        
        # Find origin (earliest with no parent, or highest claim similarity)
        candidates = [s for s in sources_sorted if s.parent_url is None]
        if candidates:
            # Prefer dated sources, then highest similarity to claim
            origin = max(
                candidates,
                key=lambda s: (s.date is not None, s.similarity_to_claim)
            )
        else:
            # All have parents, take earliest
            origin = sources_sorted[0] if sources_sorted else None
        
        return PropagationTree(
            claim=claim,
            origin=origin,
            sources=sources_sorted,
        )
