"""
TruthCheck Visualization.

Simple ASCII/text visualization for trace results.
"""
from typing import Optional


def visualize_tree(tree_data: dict, max_depth: int = 5) -> str:
    """
    Create ASCII visualization of propagation tree.
    
    Args:
        tree_data: Tree structure from trace_claim result
        max_depth: Maximum depth to display
        
    Returns:
        ASCII tree string
    """
    if not tree_data:
        return "  (no tree data)"
    
    lines = []
    
    def render_node(node: dict, prefix: str = "", is_last: bool = True, depth: int = 0):
        if depth > max_depth:
            return
        
        # Connector characters
        connector = "└── " if is_last else "├── "
        extension = "    " if is_last else "│   "
        
        # Format node info
        domain = node.get("domain", "unknown")
        date = node.get("date", "?")
        
        if depth == 0:
            # Root node (origin)
            lines.append(f"🌱 {domain}")
            lines.append(f"   └─ {date}")
        else:
            lines.append(f"{prefix}{connector}{domain} ({date})")
        
        # Render children
        children = node.get("children", [])
        for i, child in enumerate(children):
            is_child_last = (i == len(children) - 1)
            new_prefix = prefix + extension if depth > 0 else "   "
            render_node(child, new_prefix, is_child_last, depth + 1)
    
    render_node(tree_data)
    return "\n".join(lines)


def visualize_timeline(timeline: list, max_items: int = 10) -> str:
    """
    Create ASCII timeline visualization.
    
    Args:
        timeline: List of timeline items from trace_claim
        max_items: Maximum items to show
        
    Returns:
        ASCII timeline string
    """
    if not timeline:
        return "  (no timeline data)"
    
    lines = []
    
    for i, item in enumerate(timeline[:max_items]):
        date = item.get("date", "?")
        domain = item.get("domain", "unknown")
        title = item.get("title", "")[:40]
        
        if i == 0:
            marker = "🥇"
        elif i == 1:
            marker = "🥈"
        elif i == 2:
            marker = "🥉"
        else:
            marker = f"{i+1}."
        
        # Timeline bar
        bar_char = "━" if i == 0 else "─"
        
        lines.append(f"  {marker} [{date}] {domain}")
        if title:
            lines.append(f"     └─ {title}...")
    
    if len(timeline) > max_items:
        lines.append(f"  ... and {len(timeline) - max_items} more")
    
    return "\n".join(lines)


def visualize_graph(graph: dict) -> str:
    """
    Create ASCII visualization of propagation graph.
    
    Args:
        graph: Graph with nodes and edges from trace_claim
        
    Returns:
        ASCII graph string
    """
    edges = graph.get("edges", [])
    if not edges:
        return "  (no propagation links detected)"
    
    lines = []
    
    for edge in edges[:10]:
        from_url = edge.get("from", "?")
        to_url = edge.get("to", "?")
        sim = edge.get("similarity", 0)
        
        # Extract domains
        from_domain = from_url.split("/")[2] if "/" in from_url else from_url
        to_domain = to_url.split("/")[2] if "/" in to_url else to_url
        
        # Similarity bar
        bar_len = int(sim * 10)
        bar = "█" * bar_len + "░" * (10 - bar_len)
        
        lines.append(f"  {from_domain[:20]:20} ──▶ {to_domain[:20]}")
        lines.append(f"  {' '*20} [{bar}] {sim:.0%}")
    
    if len(edges) > 10:
        lines.append(f"  ... and {len(edges) - 10} more links")
    
    return "\n".join(lines)


def visualize_full(result: dict) -> str:
    """
    Create full visualization of trace_claim result.
    
    Args:
        result: Full result dict from trace_claim
        
    Returns:
        Complete ASCII visualization
    """
    sections = []
    
    # Header
    claim = result.get("claim", "Unknown claim")
    sections.append(f"╔{'═'*60}╗")
    sections.append(f"║ CLAIM TRACE RESULT{' '*41}║")
    sections.append(f"╠{'═'*60}╣")
    
    # Claim (truncated)
    claim_display = claim[:56] + "..." if len(claim) > 56 else claim
    sections.append(f"║ {claim_display:<58} ║")
    sections.append(f"╚{'═'*60}╝")
    sections.append("")
    
    # Origin
    origin = result.get("origin")
    if origin:
        sections.append("🎯 ORIGIN (First Source)")
        sections.append(f"   Domain: {origin.get('domain', '?')}")
        sections.append(f"   Date:   {origin.get('date', '?')}")
        sections.append(f"   URL:    {origin.get('url', '?')[:50]}...")
        sections.append("")
    
    # Timeline
    timeline = result.get("timeline", [])
    if timeline:
        sections.append("📅 TIMELINE")
        sections.append(visualize_timeline(timeline))
        sections.append("")
    
    # Propagation
    graph = result.get("graph", {})
    if graph.get("edges"):
        sections.append("🔗 PROPAGATION")
        sections.append(visualize_graph(graph))
        sections.append("")
    
    # Stats
    stats = result.get("stats", {})
    if stats:
        sections.append("📊 STATS")
        sections.append(f"   Sources found: {stats.get('sources_found', 0)}")
        sections.append(f"   With dates:    {stats.get('sources_with_dates', 0)}")
        date_range = stats.get('date_range', [])
        if date_range and date_range[0]:
            sections.append(f"   Date range:    {date_range[0]} → {date_range[1]}")
        top = stats.get('top_domains', [])
        if top:
            sections.append(f"   Top domains:   {', '.join(top[:3])}")
    
    return "\n".join(sections)
