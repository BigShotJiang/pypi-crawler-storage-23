"""
TruthScore Configuration.

Reads settings from environment variables with sensible defaults.
Load .env file in your application if needed (e.g., python-dotenv).
"""
import os
from typing import Optional

# Search provider settings
# Options: duckduckgo (free), brave, google, searxng
# If not set, auto-detects based on available API keys
SEARCH_PROVIDER = os.getenv("TRUTHSCORE_SEARCH_PROVIDER", "auto")

# Brave Search
BRAVE_API_KEY = os.getenv("BRAVE_API_KEY")

# Google Custom Search
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
GOOGLE_CX = os.getenv("GOOGLE_CX") or os.getenv("GOOGLE_ENGINE_ID")  # Search Engine ID

# SearXNG (self-hosted)
SEARXNG_URL = os.getenv("SEARXNG_URL", "http://localhost:8080")

# LLM provider settings
LLM_PROVIDER = os.getenv("TRUTHSCORE_LLM_PROVIDER", "ollama")

# OpenAI
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL")  # For compatible APIs

# Anthropic
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-3-haiku-20240307")

# Google Gemini
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

# Ollama (local)
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3")

# General settings
TIMEOUT = int(os.getenv("TRUTHSCORE_TIMEOUT", "10"))
LOG_LEVEL = os.getenv("TRUTHSCORE_LOG_LEVEL", "INFO")


def get_search_provider():
    """
    Get configured search provider instance.
    
    Priority (if TRUTHSCORE_SEARCH_PROVIDER=auto):
    1. Brave (if BRAVE_API_KEY set) - best quality
    2. Google (if GOOGLE_API_KEY + GOOGLE_CX set) - best quality
    3. SearXNG (if SEARXNG_URL reachable) - free, aggregated
    4. DuckDuckGo - free fallback, no setup needed
    
    Returns:
        SearchProvider instance
        
    Raises:
        ValueError: If explicitly configured provider can't be initialized
    """
    from truthcheck.search import (
        BraveSearchProvider,
        GoogleSearchProvider,
        SearXNGProvider,
        DuckDuckGoProvider,
    )
    
    provider = SEARCH_PROVIDER.lower()
    
    # Explicit provider selection
    if provider == "brave":
        if not BRAVE_API_KEY:
            raise ValueError(
                "BRAVE_API_KEY not set. "
                "Get a free key at: https://brave.com/search/api/"
            )
        return BraveSearchProvider(api_key=BRAVE_API_KEY)
    
    elif provider == "google":
        if not GOOGLE_API_KEY or not GOOGLE_CX:
            raise ValueError(
                "GOOGLE_API_KEY and GOOGLE_CX not set. "
                "Setup at: https://programmablesearchengine.google.com/"
            )
        return GoogleSearchProvider(api_key=GOOGLE_API_KEY, cx=GOOGLE_CX)
    
    elif provider == "searxng":
        return SearXNGProvider(base_url=SEARXNG_URL)
    
    elif provider == "duckduckgo":
        return DuckDuckGoProvider()
    
    elif provider == "auto":
        # Auto-detect best available provider
        
        # 1. Try Brave (best quality)
        if BRAVE_API_KEY:
            return BraveSearchProvider(api_key=BRAVE_API_KEY)
        
        # 2. Try Google (best quality)
        if GOOGLE_API_KEY and GOOGLE_CX:
            return GoogleSearchProvider(api_key=GOOGLE_API_KEY, cx=GOOGLE_CX)
        
        # 3. DuckDuckGo (free, always works)
        return DuckDuckGoProvider()
    
    else:
        raise ValueError(
            f"Unknown search provider: {provider}. "
            "Options: auto, duckduckgo, brave, google, searxng"
        )


def get_llm_provider():
    """
    Get configured LLM provider instance.
    
    Returns:
        LLMProvider instance based on TRUTHSCORE_LLM_PROVIDER
        
    Raises:
        ValueError: If provider not configured properly
    """
    from truthcheck.llm import (
        OpenAIProvider, 
        AnthropicProvider, 
        OllamaProvider,
        GeminiProvider
    )
    
    provider = LLM_PROVIDER.lower()
    
    if provider == "openai":
        if not OPENAI_API_KEY:
            raise ValueError(
                "OPENAI_API_KEY not set. "
                "Get a key at: https://platform.openai.com/api-keys"
            )
        return OpenAIProvider(
            api_key=OPENAI_API_KEY,
            model=OPENAI_MODEL,
            base_url=OPENAI_BASE_URL
        )
    
    elif provider == "anthropic":
        if not ANTHROPIC_API_KEY:
            raise ValueError(
                "ANTHROPIC_API_KEY not set. "
                "Get a key at: https://console.anthropic.com/"
            )
        return AnthropicProvider(
            api_key=ANTHROPIC_API_KEY,
            model=ANTHROPIC_MODEL
        )
    
    elif provider == "gemini":
        if not GEMINI_API_KEY:
            raise ValueError(
                "GEMINI_API_KEY not set. "
                "Get a key at: https://aistudio.google.com/apikey"
            )
        return GeminiProvider(
            api_key=GEMINI_API_KEY,
            model=GEMINI_MODEL
        )
    
    elif provider == "ollama":
        return OllamaProvider(
            host=OLLAMA_HOST,
            model=OLLAMA_MODEL
        )
    
    else:
        raise ValueError(f"Unknown LLM provider: {provider}")
