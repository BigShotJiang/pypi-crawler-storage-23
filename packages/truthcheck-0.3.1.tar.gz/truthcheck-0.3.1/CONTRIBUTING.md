# Contributing to TruthCheck

Thank you for your interest in helping fight misinformation!

## Publisher Database

TruthCheck uses [Media Bias/Fact Check (MBFC)](https://mediabiasfactcheck.com/) as its primary publisher database. This data is synced automatically and includes 8,900+ sources.

### Adding New Publishers

To add a publisher that MBFC doesn't cover:

1. **Preferred:** Submit to MBFC directly at [mediabiasfactcheck.com](https://mediabiasfactcheck.com/submit-source/)
   - This helps the entire ecosystem
   - MBFC has established methodology for bias/credibility ratings

2. **For local overrides:** Create a YAML file in `src/truthcheck/data/publishers/`:

```yaml
# mysite.com.yaml
domain: mysite.com
name: My Site
trust_score: 0.7  # 0-1 scale
category: news    # news, academic, government, blog, other
verified: false
bias: center      # left, left-center, center, right-center, right
fact_check_rating: high  # very-high, high, mostly-factual, mixed, low, very-low
```

Local YAML files override the MBFC database.

### Updating the Database

Run `truthcheck sync` to fetch the latest MBFC data.

## Code Contributions

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Write tests first (TDD)
4. Implement the feature
5. Run tests: `pytest tests/ -v`
6. Submit a pull request

### Code Style

- Python 3.10+
- Use type hints
- Format with `black`
- Lint with `ruff`
- 90%+ test coverage

## Reporting Issues

- Use GitHub Issues
- Include reproduction steps
- Specify Python version and OS

## Questions?

Open a Discussion on GitHub.
