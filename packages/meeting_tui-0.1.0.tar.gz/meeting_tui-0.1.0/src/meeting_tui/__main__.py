"""Entry point for meeting-tui — CLI interface using Click."""

from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler
import click
import sounddevice as sd

from meeting_tui.config import load_config


def _configure_file_logging(output_dir: str) -> str:
    """Configure a dedicated file logger for meeting_tui logs.

    Returns the absolute log file path.
    """
    from pathlib import Path

    log_dir = Path(output_dir).expanduser()
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = (log_dir / "meeting-tui.log").resolve()

    base_logger = logging.getLogger("meeting_tui")
    base_logger.setLevel(logging.INFO)
    base_logger.propagate = False

    # Replace existing handlers to avoid duplicate logs on re-entry.
    base_logger.handlers.clear()

    max_bytes = int(os.environ.get("MEETING_TUI_LOG_MAX_BYTES", str(5 * 1024 * 1024)))
    backup_count = int(os.environ.get("MEETING_TUI_LOG_BACKUP_COUNT", "3"))

    if max_bytes > 0 and backup_count > 0:
        file_handler: logging.Handler = RotatingFileHandler(
            log_path,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8",
        )
    else:
        file_handler = logging.FileHandler(log_path, encoding="utf-8")

    file_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    base_logger.addHandler(file_handler)

    return str(log_path)


@click.command()
@click.option("--device", type=str, default=None, help="Audio input device index or name")
@click.option(
    "--model",
    type=click.Choice(["tiny", "base", "small", "medium", "large-v3"]),
    default=None,
    help="Whisper model size for transcription",
)
@click.option("--output", type=click.Path(), default=None, help="Output directory for transcripts")
@click.option(
    "--llm-backend",
    type=click.Choice(["ollama", "openai", "gemini"]),
    default=None,
    help="LLM backend to use",
)
@click.option("--title", type=str, default=None, help="Meeting title for transcript files")
@click.option("--list-devices", is_flag=True, help="List available audio input devices and exit")
@click.option("--config", "config_path", type=click.Path(), default=None, help="Path to config file")
def main(
    device: str | None,
    model: str | None,
    output: str | None,
    llm_backend: str | None,
    title: str | None,
    list_devices: bool,
    config_path: str | None,
) -> None:
    """Meeting TUI — Live meeting transcription and AI chat in your terminal."""
    if list_devices:
        _print_devices()
        return

    # Build CLI overrides dict
    cli_overrides: dict = {}
    if device is not None:
        try:
            cli_overrides.setdefault("audio", {})["device"] = int(device)
        except ValueError:
            # Partial name match — find the device index by name substring
            resolved = _resolve_device_by_name(device)
            if resolved is not None:
                cli_overrides.setdefault("audio", {})["device"] = resolved
            else:
                click.echo(f"Error: No audio input device matching '{device}'. Use --list-devices.")
                raise SystemExit(1)
    if model is not None:
        cli_overrides.setdefault("transcription", {})["model_size"] = model
    if output is not None:
        cli_overrides.setdefault("persistence", {})["output_dir"] = output
    if llm_backend is not None:
        cli_overrides.setdefault("llm", {})["backend"] = llm_backend
    if title is not None:
        cli_overrides.setdefault("persistence", {})["title"] = title

    from pathlib import Path

    config = load_config(
        config_path=Path(config_path) if config_path else None,
        cli_overrides=cli_overrides if cli_overrides else None,
    )

    log_path = _configure_file_logging(config.persistence.output_dir)
    click.echo(f"Logging to: {log_path}")

    # Pre-load ML models *before* the Textual event loop starts.
    # CTranslate2 (faster-whisper) triggers a Python 3.13+ fds_to_keep
    # race when loaded from any thread inside an asyncio loop.
    # Loading synchronously here avoids the issue entirely.
    from meeting_tui.audio.vad import VADProcessor
    from meeting_tui.transcription.engine import TranscriptionEngine

    click.echo("Loading VAD model...")
    vad = VADProcessor(config.vad, sample_rate=config.audio.sample_rate)
    vad.load_model()

    click.echo(f"Loading Whisper '{config.transcription.model_size}' model...")
    engine = TranscriptionEngine(config.transcription)
    engine.load_model()

    click.echo("Models loaded. Starting app...")

    from meeting_tui.app import MeetingApp

    app = MeetingApp(config, vad=vad, engine=engine)
    app.run()


def _resolve_device_by_name(name: str) -> int | None:
    """Resolve a device name (partial, case-insensitive) to a device index."""
    devices = sd.query_devices()
    name_lower = name.lower()
    matches = []
    for i, dev in enumerate(devices):
        if dev["max_input_channels"] > 0 and name_lower in dev["name"].lower():
            matches.append(i)
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        click.echo(f"Ambiguous device name '{name}'. Matches:")
        for i in matches:
            click.echo(f"  [{i}] {devices[i]['name']}")
        return None
    return None


def _print_devices() -> None:
    """Print available audio input devices."""
    devices = sd.query_devices()
    click.echo("Available audio input devices:\n")
    for i, dev in enumerate(devices):
        if dev["max_input_channels"] > 0:
            marker = " *" if i == sd.default.device[0] else ""
            click.echo(f"  [{i}] {dev['name']} (channels: {dev['max_input_channels']}){marker}")
    click.echo("\n  * = default device")
    click.echo("\nUse --device <index> to select a device.")


if __name__ == "__main__":
    main()
