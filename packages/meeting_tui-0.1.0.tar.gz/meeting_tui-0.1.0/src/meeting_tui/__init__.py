"""meeting-tui: Terminal-based meeting companion with live transcription and AI chat."""

__version__ = "0.1.0"
