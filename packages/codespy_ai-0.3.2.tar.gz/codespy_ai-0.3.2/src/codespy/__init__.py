"""codespy - Code review agent powered by DSPy."""

__version__ = "0.3.2"
