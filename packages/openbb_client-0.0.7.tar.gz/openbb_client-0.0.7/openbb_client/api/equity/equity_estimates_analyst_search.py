from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_analyst_search import OBBjectAnalystSearch
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["benzinga"] | Unset = "benzinga",
    analyst_name: None | str | Unset = UNSET,
    firm_name: None | str | Unset = UNSET,
    analyst_ids: None | str | Unset = UNSET,
    firm_ids: None | str | Unset = UNSET,
    limit: int | None | Unset = 100,
    page: int | None | Unset = 0,
    fields: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_analyst_name: None | str | Unset
    if isinstance(analyst_name, Unset):
        json_analyst_name = UNSET
    else:
        json_analyst_name = analyst_name
    params["analyst_name"] = json_analyst_name

    json_firm_name: None | str | Unset
    if isinstance(firm_name, Unset):
        json_firm_name = UNSET
    else:
        json_firm_name = firm_name
    params["firm_name"] = json_firm_name

    json_analyst_ids: None | str | Unset
    if isinstance(analyst_ids, Unset):
        json_analyst_ids = UNSET
    else:
        json_analyst_ids = analyst_ids
    params["analyst_ids"] = json_analyst_ids

    json_firm_ids: None | str | Unset
    if isinstance(firm_ids, Unset):
        json_firm_ids = UNSET
    else:
        json_firm_ids = firm_ids
    params["firm_ids"] = json_firm_ids

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_page: int | None | Unset
    if isinstance(page, Unset):
        json_page = UNSET
    else:
        json_page = page
    params["page"] = json_page

    json_fields: None | str | Unset
    if isinstance(fields, Unset):
        json_fields = UNSET
    else:
        json_fields = fields
    params["fields"] = json_fields

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/estimates/analyst_search",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectAnalystSearch.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["benzinga"] | Unset = "benzinga",
    analyst_name: None | str | Unset = UNSET,
    firm_name: None | str | Unset = UNSET,
    analyst_ids: None | str | Unset = UNSET,
    firm_ids: None | str | Unset = UNSET,
    limit: int | None | Unset = 100,
    page: int | None | Unset = 0,
    fields: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse]:
    """Analyst Search

     Search for specific analysts and get their forecast track record.

    Args:
        provider (Literal['benzinga'] | Unset):  Default: 'benzinga'.
        analyst_name (None | str | Unset): Analyst names to return. Omitting will return all
            available analysts. Multiple comma separated items allowed for provider(s): benzinga.
        firm_name (None | str | Unset): Firm names to return. Omitting will return all available
            firms. Multiple comma separated items allowed for provider(s): benzinga.
        analyst_ids (None | str | Unset): List of analyst IDs to return. Multiple comma separated
            items allowed. (provider: benzinga)
        firm_ids (None | str | Unset): Firm IDs to return. Multiple comma separated items allowed.
            (provider: benzinga)
        limit (int | None | Unset): Number of results returned. Limit 1000. (provider: benzinga)
            Default: 100.
        page (int | None | Unset): Page offset. For optimization, performance and technical
            reasons, page offsets are limited from 0 - 100000. Limit the query results by other
            parameters such as date. (provider: benzinga) Default: 0.
        fields (None | str | Unset): Fields to include in the response. See
            https://docs.benzinga.io/benzinga-apis/calendar/get-ratings to learn about the available
            fields. Multiple comma separated items allowed. (provider: benzinga)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        analyst_name=analyst_name,
        firm_name=firm_name,
        analyst_ids=analyst_ids,
        firm_ids=firm_ids,
        limit=limit,
        page=page,
        fields=fields,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["benzinga"] | Unset = "benzinga",
    analyst_name: None | str | Unset = UNSET,
    firm_name: None | str | Unset = UNSET,
    analyst_ids: None | str | Unset = UNSET,
    firm_ids: None | str | Unset = UNSET,
    limit: int | None | Unset = 100,
    page: int | None | Unset = 0,
    fields: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse | None:
    """Analyst Search

     Search for specific analysts and get their forecast track record.

    Args:
        provider (Literal['benzinga'] | Unset):  Default: 'benzinga'.
        analyst_name (None | str | Unset): Analyst names to return. Omitting will return all
            available analysts. Multiple comma separated items allowed for provider(s): benzinga.
        firm_name (None | str | Unset): Firm names to return. Omitting will return all available
            firms. Multiple comma separated items allowed for provider(s): benzinga.
        analyst_ids (None | str | Unset): List of analyst IDs to return. Multiple comma separated
            items allowed. (provider: benzinga)
        firm_ids (None | str | Unset): Firm IDs to return. Multiple comma separated items allowed.
            (provider: benzinga)
        limit (int | None | Unset): Number of results returned. Limit 1000. (provider: benzinga)
            Default: 100.
        page (int | None | Unset): Page offset. For optimization, performance and technical
            reasons, page offsets are limited from 0 - 100000. Limit the query results by other
            parameters such as date. (provider: benzinga) Default: 0.
        fields (None | str | Unset): Fields to include in the response. See
            https://docs.benzinga.io/benzinga-apis/calendar/get-ratings to learn about the available
            fields. Multiple comma separated items allowed. (provider: benzinga)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        analyst_name=analyst_name,
        firm_name=firm_name,
        analyst_ids=analyst_ids,
        firm_ids=firm_ids,
        limit=limit,
        page=page,
        fields=fields,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["benzinga"] | Unset = "benzinga",
    analyst_name: None | str | Unset = UNSET,
    firm_name: None | str | Unset = UNSET,
    analyst_ids: None | str | Unset = UNSET,
    firm_ids: None | str | Unset = UNSET,
    limit: int | None | Unset = 100,
    page: int | None | Unset = 0,
    fields: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse]:
    """Analyst Search

     Search for specific analysts and get their forecast track record.

    Args:
        provider (Literal['benzinga'] | Unset):  Default: 'benzinga'.
        analyst_name (None | str | Unset): Analyst names to return. Omitting will return all
            available analysts. Multiple comma separated items allowed for provider(s): benzinga.
        firm_name (None | str | Unset): Firm names to return. Omitting will return all available
            firms. Multiple comma separated items allowed for provider(s): benzinga.
        analyst_ids (None | str | Unset): List of analyst IDs to return. Multiple comma separated
            items allowed. (provider: benzinga)
        firm_ids (None | str | Unset): Firm IDs to return. Multiple comma separated items allowed.
            (provider: benzinga)
        limit (int | None | Unset): Number of results returned. Limit 1000. (provider: benzinga)
            Default: 100.
        page (int | None | Unset): Page offset. For optimization, performance and technical
            reasons, page offsets are limited from 0 - 100000. Limit the query results by other
            parameters such as date. (provider: benzinga) Default: 0.
        fields (None | str | Unset): Fields to include in the response. See
            https://docs.benzinga.io/benzinga-apis/calendar/get-ratings to learn about the available
            fields. Multiple comma separated items allowed. (provider: benzinga)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        analyst_name=analyst_name,
        firm_name=firm_name,
        analyst_ids=analyst_ids,
        firm_ids=firm_ids,
        limit=limit,
        page=page,
        fields=fields,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["benzinga"] | Unset = "benzinga",
    analyst_name: None | str | Unset = UNSET,
    firm_name: None | str | Unset = UNSET,
    analyst_ids: None | str | Unset = UNSET,
    firm_ids: None | str | Unset = UNSET,
    limit: int | None | Unset = 100,
    page: int | None | Unset = 0,
    fields: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse | None:
    """Analyst Search

     Search for specific analysts and get their forecast track record.

    Args:
        provider (Literal['benzinga'] | Unset):  Default: 'benzinga'.
        analyst_name (None | str | Unset): Analyst names to return. Omitting will return all
            available analysts. Multiple comma separated items allowed for provider(s): benzinga.
        firm_name (None | str | Unset): Firm names to return. Omitting will return all available
            firms. Multiple comma separated items allowed for provider(s): benzinga.
        analyst_ids (None | str | Unset): List of analyst IDs to return. Multiple comma separated
            items allowed. (provider: benzinga)
        firm_ids (None | str | Unset): Firm IDs to return. Multiple comma separated items allowed.
            (provider: benzinga)
        limit (int | None | Unset): Number of results returned. Limit 1000. (provider: benzinga)
            Default: 100.
        page (int | None | Unset): Page offset. For optimization, performance and technical
            reasons, page offsets are limited from 0 - 100000. Limit the query results by other
            parameters such as date. (provider: benzinga) Default: 0.
        fields (None | str | Unset): Fields to include in the response. See
            https://docs.benzinga.io/benzinga-apis/calendar/get-ratings to learn about the available
            fields. Multiple comma separated items allowed. (provider: benzinga)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectAnalystSearch | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            analyst_name=analyst_name,
            firm_name=firm_name,
            analyst_ids=analyst_ids,
            firm_ids=firm_ids,
            limit=limit,
            page=page,
            fields=fields,
        )
    ).parsed
