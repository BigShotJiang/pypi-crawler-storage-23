from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.currency_snapshots_provider import CurrencySnapshotsProvider
from ...models.currency_snapshots_quote_type import CurrencySnapshotsQuoteType
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_currency_snapshots import OBBjectCurrencySnapshots
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: CurrencySnapshotsProvider,
    base: str | Unset = "usd",
    quote_type: CurrencySnapshotsQuoteType | Unset = CurrencySnapshotsQuoteType.INDIRECT,
    counter_currencies: list[str] | None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    params["base"] = base

    json_quote_type: str | Unset = UNSET
    if not isinstance(quote_type, Unset):
        json_quote_type = quote_type.value

    params["quote_type"] = json_quote_type

    json_counter_currencies: list[str] | None | str | Unset
    if isinstance(counter_currencies, Unset):
        json_counter_currencies = UNSET
    elif isinstance(counter_currencies, list):
        json_counter_currencies = counter_currencies

    else:
        json_counter_currencies = counter_currencies
    params["counter_currencies"] = json_counter_currencies

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/currency/snapshots",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectCurrencySnapshots.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: CurrencySnapshotsProvider,
    base: str | Unset = "usd",
    quote_type: CurrencySnapshotsQuoteType | Unset = CurrencySnapshotsQuoteType.INDIRECT,
    counter_currencies: list[str] | None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse]:
    """Snapshots

     Snapshots of currency exchange rates from an indirect or direct perspective of a base currency.

    Args:
        provider (CurrencySnapshotsProvider):
        base (str | Unset): The base currency symbol. Multiple comma separated items allowed for
            provider(s): akshare, fmp, polygon. Default: 'usd'.
        quote_type (CurrencySnapshotsQuoteType | Unset): Whether the quote is direct or indirect.
            Selecting 'direct' will return the exchange rate as the amount of domestic currency
            required to buy one unit of the foreign currency. Selecting 'indirect' (default) will
            return the exchange rate as the amount of foreign currency required to buy one unit of the
            domestic currency. Default: CurrencySnapshotsQuoteType.INDIRECT.
        counter_currencies (list[str] | None | str | Unset): An optional list of counter currency
            symbols to filter for. None returns all.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        base=base,
        quote_type=quote_type,
        counter_currencies=counter_currencies,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: CurrencySnapshotsProvider,
    base: str | Unset = "usd",
    quote_type: CurrencySnapshotsQuoteType | Unset = CurrencySnapshotsQuoteType.INDIRECT,
    counter_currencies: list[str] | None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse | None:
    """Snapshots

     Snapshots of currency exchange rates from an indirect or direct perspective of a base currency.

    Args:
        provider (CurrencySnapshotsProvider):
        base (str | Unset): The base currency symbol. Multiple comma separated items allowed for
            provider(s): akshare, fmp, polygon. Default: 'usd'.
        quote_type (CurrencySnapshotsQuoteType | Unset): Whether the quote is direct or indirect.
            Selecting 'direct' will return the exchange rate as the amount of domestic currency
            required to buy one unit of the foreign currency. Selecting 'indirect' (default) will
            return the exchange rate as the amount of foreign currency required to buy one unit of the
            domestic currency. Default: CurrencySnapshotsQuoteType.INDIRECT.
        counter_currencies (list[str] | None | str | Unset): An optional list of counter currency
            symbols to filter for. None returns all.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        base=base,
        quote_type=quote_type,
        counter_currencies=counter_currencies,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: CurrencySnapshotsProvider,
    base: str | Unset = "usd",
    quote_type: CurrencySnapshotsQuoteType | Unset = CurrencySnapshotsQuoteType.INDIRECT,
    counter_currencies: list[str] | None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse]:
    """Snapshots

     Snapshots of currency exchange rates from an indirect or direct perspective of a base currency.

    Args:
        provider (CurrencySnapshotsProvider):
        base (str | Unset): The base currency symbol. Multiple comma separated items allowed for
            provider(s): akshare, fmp, polygon. Default: 'usd'.
        quote_type (CurrencySnapshotsQuoteType | Unset): Whether the quote is direct or indirect.
            Selecting 'direct' will return the exchange rate as the amount of domestic currency
            required to buy one unit of the foreign currency. Selecting 'indirect' (default) will
            return the exchange rate as the amount of foreign currency required to buy one unit of the
            domestic currency. Default: CurrencySnapshotsQuoteType.INDIRECT.
        counter_currencies (list[str] | None | str | Unset): An optional list of counter currency
            symbols to filter for. None returns all.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        base=base,
        quote_type=quote_type,
        counter_currencies=counter_currencies,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: CurrencySnapshotsProvider,
    base: str | Unset = "usd",
    quote_type: CurrencySnapshotsQuoteType | Unset = CurrencySnapshotsQuoteType.INDIRECT,
    counter_currencies: list[str] | None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse | None:
    """Snapshots

     Snapshots of currency exchange rates from an indirect or direct perspective of a base currency.

    Args:
        provider (CurrencySnapshotsProvider):
        base (str | Unset): The base currency symbol. Multiple comma separated items allowed for
            provider(s): akshare, fmp, polygon. Default: 'usd'.
        quote_type (CurrencySnapshotsQuoteType | Unset): Whether the quote is direct or indirect.
            Selecting 'direct' will return the exchange rate as the amount of domestic currency
            required to buy one unit of the foreign currency. Selecting 'indirect' (default) will
            return the exchange rate as the amount of foreign currency required to buy one unit of the
            domestic currency. Default: CurrencySnapshotsQuoteType.INDIRECT.
        counter_currencies (list[str] | None | str | Unset): An optional list of counter currency
            symbols to filter for. None returns all.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCurrencySnapshots | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            base=base,
            quote_type=quote_type,
            counter_currencies=counter_currencies,
        )
    ).parsed
