import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.economy_fred_regional_aggregation_method_type_0 import EconomyFredRegionalAggregationMethodType0
from ...models.economy_fred_regional_frequency_type_0 import EconomyFredRegionalFrequencyType0
from ...models.economy_fred_regional_region_type_type_0 import EconomyFredRegionalRegionTypeType0
from ...models.economy_fred_regional_transform_type_0 import EconomyFredRegionalTransformType0
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_fred_regional import OBBjectFredRegional
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["fred"] | Unset = "fred",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100000,
    is_series_group: bool | Unset = False,
    region_type: EconomyFredRegionalRegionTypeType0 | None | Unset = UNSET,
    season: str | Unset = "nsa",
    units: None | str | Unset = UNSET,
    frequency: EconomyFredRegionalFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomyFredRegionalAggregationMethodType0
    | None
    | Unset = EconomyFredRegionalAggregationMethodType0.EOP,
    transform: EconomyFredRegionalTransformType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params["is_series_group"] = is_series_group

    json_region_type: None | str | Unset
    if isinstance(region_type, Unset):
        json_region_type = UNSET
    elif isinstance(region_type, EconomyFredRegionalRegionTypeType0):
        json_region_type = region_type.value
    else:
        json_region_type = region_type
    params["region_type"] = json_region_type

    params["season"] = season

    json_units: None | str | Unset
    if isinstance(units, Unset):
        json_units = UNSET
    else:
        json_units = units
    params["units"] = json_units

    json_frequency: None | str | Unset
    if isinstance(frequency, Unset):
        json_frequency = UNSET
    elif isinstance(frequency, EconomyFredRegionalFrequencyType0):
        json_frequency = frequency.value
    else:
        json_frequency = frequency
    params["frequency"] = json_frequency

    json_aggregation_method: None | str | Unset
    if isinstance(aggregation_method, Unset):
        json_aggregation_method = UNSET
    elif isinstance(aggregation_method, EconomyFredRegionalAggregationMethodType0):
        json_aggregation_method = aggregation_method.value
    else:
        json_aggregation_method = aggregation_method
    params["aggregation_method"] = json_aggregation_method

    json_transform: None | str | Unset
    if isinstance(transform, Unset):
        json_transform = UNSET
    elif isinstance(transform, EconomyFredRegionalTransformType0):
        json_transform = transform.value
    else:
        json_transform = transform
    params["transform"] = json_transform

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/fred_regional",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectFredRegional.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100000,
    is_series_group: bool | Unset = False,
    region_type: EconomyFredRegionalRegionTypeType0 | None | Unset = UNSET,
    season: str | Unset = "nsa",
    units: None | str | Unset = UNSET,
    frequency: EconomyFredRegionalFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomyFredRegionalAggregationMethodType0
    | None
    | Unset = EconomyFredRegionalAggregationMethodType0.EOP,
    transform: EconomyFredRegionalTransformType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse]:
    """Fred Regional

     Query the Geo Fred API for regional economic data by series group.

    The series group ID is found by using `fred_search` and the `series_id` parameter.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        symbol (str): Symbol to get data for.;
                For this function, it is the series_group ID or series ID. If the symbol provided is
            for a series_group, set the `is_series_group` parameter to True. Not all series that are
            in FRED have geographical data. (provider: fred)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): The number of data entries to return. Default: 100000.
        is_series_group (bool | Unset): When True, the symbol provided is for a series_group, else
            it is for a series ID. (provider: fred) Default: False.
        region_type (EconomyFredRegionalRegionTypeType0 | None | Unset): The type of regional
            data. Parameter is only valid when `is_series_group` is True. (provider: fred)
        season (str | Unset): The seasonal adjustments to the data. Parameter is only valid when
            `is_series_group` is True. (provider: fred) Default: 'nsa'.
        units (None | str | Unset): The units of the data. This should match the units returned
            from searching by series ID. An incorrect field will not necessarily return an error.
            Parameter is only valid when `is_series_group` is True. (provider: fred)
        frequency (EconomyFredRegionalFrequencyType0 | None | Unset): Frequency aggregation to
            convert high frequency data to lower frequency.

                None = No change

                a = Annual

                q = Quarterly

                m = Monthly

                w = Weekly

                d = Daily

                wef = Weekly, Ending Friday

                weth = Weekly, Ending Thursday

                wew = Weekly, Ending Wednesday

                wetu = Weekly, Ending Tuesday

                wem = Weekly, Ending Monday

                wesu = Weekly, Ending Sunday

                wesa = Weekly, Ending Saturday

                bwew = Biweekly, Ending Wednesday

                bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (EconomyFredRegionalAggregationMethodType0 | None | Unset): A key that
            indicates the aggregation method used for frequency aggregation.
                    This parameter has no affect if the frequency parameter is not set.

                avg = Average

                sum = Sum

                eop = End of Period
                     (provider: fred) Default: EconomyFredRegionalAggregationMethodType0.EOP.
        transform (EconomyFredRegionalTransformType0 | None | Unset): Transformation type

                None = No transformation

                chg = Change

                ch1 = Change from Year Ago

                pch = Percent Change

                pc1 = Percent Change from Year Ago

                pca = Compounded Annual Rate of Change

                cch = Continuously Compounded Rate of Change

                cca = Continuously Compounded Annual Rate of Change

                log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        is_series_group=is_series_group,
        region_type=region_type,
        season=season,
        units=units,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100000,
    is_series_group: bool | Unset = False,
    region_type: EconomyFredRegionalRegionTypeType0 | None | Unset = UNSET,
    season: str | Unset = "nsa",
    units: None | str | Unset = UNSET,
    frequency: EconomyFredRegionalFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomyFredRegionalAggregationMethodType0
    | None
    | Unset = EconomyFredRegionalAggregationMethodType0.EOP,
    transform: EconomyFredRegionalTransformType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse | None:
    """Fred Regional

     Query the Geo Fred API for regional economic data by series group.

    The series group ID is found by using `fred_search` and the `series_id` parameter.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        symbol (str): Symbol to get data for.;
                For this function, it is the series_group ID or series ID. If the symbol provided is
            for a series_group, set the `is_series_group` parameter to True. Not all series that are
            in FRED have geographical data. (provider: fred)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): The number of data entries to return. Default: 100000.
        is_series_group (bool | Unset): When True, the symbol provided is for a series_group, else
            it is for a series ID. (provider: fred) Default: False.
        region_type (EconomyFredRegionalRegionTypeType0 | None | Unset): The type of regional
            data. Parameter is only valid when `is_series_group` is True. (provider: fred)
        season (str | Unset): The seasonal adjustments to the data. Parameter is only valid when
            `is_series_group` is True. (provider: fred) Default: 'nsa'.
        units (None | str | Unset): The units of the data. This should match the units returned
            from searching by series ID. An incorrect field will not necessarily return an error.
            Parameter is only valid when `is_series_group` is True. (provider: fred)
        frequency (EconomyFredRegionalFrequencyType0 | None | Unset): Frequency aggregation to
            convert high frequency data to lower frequency.

                None = No change

                a = Annual

                q = Quarterly

                m = Monthly

                w = Weekly

                d = Daily

                wef = Weekly, Ending Friday

                weth = Weekly, Ending Thursday

                wew = Weekly, Ending Wednesday

                wetu = Weekly, Ending Tuesday

                wem = Weekly, Ending Monday

                wesu = Weekly, Ending Sunday

                wesa = Weekly, Ending Saturday

                bwew = Biweekly, Ending Wednesday

                bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (EconomyFredRegionalAggregationMethodType0 | None | Unset): A key that
            indicates the aggregation method used for frequency aggregation.
                    This parameter has no affect if the frequency parameter is not set.

                avg = Average

                sum = Sum

                eop = End of Period
                     (provider: fred) Default: EconomyFredRegionalAggregationMethodType0.EOP.
        transform (EconomyFredRegionalTransformType0 | None | Unset): Transformation type

                None = No transformation

                chg = Change

                ch1 = Change from Year Ago

                pch = Percent Change

                pc1 = Percent Change from Year Ago

                pca = Compounded Annual Rate of Change

                cch = Continuously Compounded Rate of Change

                cca = Continuously Compounded Annual Rate of Change

                log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        is_series_group=is_series_group,
        region_type=region_type,
        season=season,
        units=units,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100000,
    is_series_group: bool | Unset = False,
    region_type: EconomyFredRegionalRegionTypeType0 | None | Unset = UNSET,
    season: str | Unset = "nsa",
    units: None | str | Unset = UNSET,
    frequency: EconomyFredRegionalFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomyFredRegionalAggregationMethodType0
    | None
    | Unset = EconomyFredRegionalAggregationMethodType0.EOP,
    transform: EconomyFredRegionalTransformType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse]:
    """Fred Regional

     Query the Geo Fred API for regional economic data by series group.

    The series group ID is found by using `fred_search` and the `series_id` parameter.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        symbol (str): Symbol to get data for.;
                For this function, it is the series_group ID or series ID. If the symbol provided is
            for a series_group, set the `is_series_group` parameter to True. Not all series that are
            in FRED have geographical data. (provider: fred)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): The number of data entries to return. Default: 100000.
        is_series_group (bool | Unset): When True, the symbol provided is for a series_group, else
            it is for a series ID. (provider: fred) Default: False.
        region_type (EconomyFredRegionalRegionTypeType0 | None | Unset): The type of regional
            data. Parameter is only valid when `is_series_group` is True. (provider: fred)
        season (str | Unset): The seasonal adjustments to the data. Parameter is only valid when
            `is_series_group` is True. (provider: fred) Default: 'nsa'.
        units (None | str | Unset): The units of the data. This should match the units returned
            from searching by series ID. An incorrect field will not necessarily return an error.
            Parameter is only valid when `is_series_group` is True. (provider: fred)
        frequency (EconomyFredRegionalFrequencyType0 | None | Unset): Frequency aggregation to
            convert high frequency data to lower frequency.

                None = No change

                a = Annual

                q = Quarterly

                m = Monthly

                w = Weekly

                d = Daily

                wef = Weekly, Ending Friday

                weth = Weekly, Ending Thursday

                wew = Weekly, Ending Wednesday

                wetu = Weekly, Ending Tuesday

                wem = Weekly, Ending Monday

                wesu = Weekly, Ending Sunday

                wesa = Weekly, Ending Saturday

                bwew = Biweekly, Ending Wednesday

                bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (EconomyFredRegionalAggregationMethodType0 | None | Unset): A key that
            indicates the aggregation method used for frequency aggregation.
                    This parameter has no affect if the frequency parameter is not set.

                avg = Average

                sum = Sum

                eop = End of Period
                     (provider: fred) Default: EconomyFredRegionalAggregationMethodType0.EOP.
        transform (EconomyFredRegionalTransformType0 | None | Unset): Transformation type

                None = No transformation

                chg = Change

                ch1 = Change from Year Ago

                pch = Percent Change

                pc1 = Percent Change from Year Ago

                pca = Compounded Annual Rate of Change

                cch = Continuously Compounded Rate of Change

                cca = Continuously Compounded Annual Rate of Change

                log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        is_series_group=is_series_group,
        region_type=region_type,
        season=season,
        units=units,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100000,
    is_series_group: bool | Unset = False,
    region_type: EconomyFredRegionalRegionTypeType0 | None | Unset = UNSET,
    season: str | Unset = "nsa",
    units: None | str | Unset = UNSET,
    frequency: EconomyFredRegionalFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomyFredRegionalAggregationMethodType0
    | None
    | Unset = EconomyFredRegionalAggregationMethodType0.EOP,
    transform: EconomyFredRegionalTransformType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse | None:
    """Fred Regional

     Query the Geo Fred API for regional economic data by series group.

    The series group ID is found by using `fred_search` and the `series_id` parameter.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        symbol (str): Symbol to get data for.;
                For this function, it is the series_group ID or series ID. If the symbol provided is
            for a series_group, set the `is_series_group` parameter to True. Not all series that are
            in FRED have geographical data. (provider: fred)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): The number of data entries to return. Default: 100000.
        is_series_group (bool | Unset): When True, the symbol provided is for a series_group, else
            it is for a series ID. (provider: fred) Default: False.
        region_type (EconomyFredRegionalRegionTypeType0 | None | Unset): The type of regional
            data. Parameter is only valid when `is_series_group` is True. (provider: fred)
        season (str | Unset): The seasonal adjustments to the data. Parameter is only valid when
            `is_series_group` is True. (provider: fred) Default: 'nsa'.
        units (None | str | Unset): The units of the data. This should match the units returned
            from searching by series ID. An incorrect field will not necessarily return an error.
            Parameter is only valid when `is_series_group` is True. (provider: fred)
        frequency (EconomyFredRegionalFrequencyType0 | None | Unset): Frequency aggregation to
            convert high frequency data to lower frequency.

                None = No change

                a = Annual

                q = Quarterly

                m = Monthly

                w = Weekly

                d = Daily

                wef = Weekly, Ending Friday

                weth = Weekly, Ending Thursday

                wew = Weekly, Ending Wednesday

                wetu = Weekly, Ending Tuesday

                wem = Weekly, Ending Monday

                wesu = Weekly, Ending Sunday

                wesa = Weekly, Ending Saturday

                bwew = Biweekly, Ending Wednesday

                bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (EconomyFredRegionalAggregationMethodType0 | None | Unset): A key that
            indicates the aggregation method used for frequency aggregation.
                    This parameter has no affect if the frequency parameter is not set.

                avg = Average

                sum = Sum

                eop = End of Period
                     (provider: fred) Default: EconomyFredRegionalAggregationMethodType0.EOP.
        transform (EconomyFredRegionalTransformType0 | None | Unset): Transformation type

                None = No transformation

                chg = Change

                ch1 = Change from Year Ago

                pch = Percent Change

                pc1 = Percent Change from Year Ago

                pca = Compounded Annual Rate of Change

                cch = Continuously Compounded Rate of Change

                cca = Continuously Compounded Annual Rate of Change

                log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectFredRegional | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            start_date=start_date,
            end_date=end_date,
            limit=limit,
            is_series_group=is_series_group,
            region_type=region_type,
            season=season,
            units=units,
            frequency=frequency,
            aggregation_method=aggregation_method,
            transform=transform,
        )
    ).parsed
