from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_sec_htm_file import OBBjectSecHtmFile
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["sec"] | Unset = "sec",
    url_query: str | Unset = "",
    use_cache: bool | Unset = True,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["url"] = url_query

    params["use_cache"] = use_cache

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/regulators/sec/htm_file",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectSecHtmFile.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    url_query: str | Unset = "",
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse]:
    """Htm File

     Download a raw HTML object from the SEC website.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        url_query (str | Unset): URL for the SEC filing. (provider: sec) Default: ''.
        use_cache (bool | Unset): Cache the file for use later. Default is True. (provider: sec)
            Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        url_query=url_query,
        use_cache=use_cache,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    url_query: str | Unset = "",
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse | None:
    """Htm File

     Download a raw HTML object from the SEC website.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        url_query (str | Unset): URL for the SEC filing. (provider: sec) Default: ''.
        use_cache (bool | Unset): Cache the file for use later. Default is True. (provider: sec)
            Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        url_query=url_query,
        use_cache=use_cache,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    url_query: str | Unset = "",
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse]:
    """Htm File

     Download a raw HTML object from the SEC website.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        url_query (str | Unset): URL for the SEC filing. (provider: sec) Default: ''.
        use_cache (bool | Unset): Cache the file for use later. Default is True. (provider: sec)
            Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        url_query=url_query,
        use_cache=use_cache,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    url_query: str | Unset = "",
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse | None:
    """Htm File

     Download a raw HTML object from the SEC website.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        url_query (str | Unset): URL for the SEC filing. (provider: sec) Default: ''.
        use_cache (bool | Unset): Cache the file for use later. Default is True. (provider: sec)
            Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectSecHtmFile | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            url_query=url_query,
            use_cache=use_cache,
        )
    ).parsed
