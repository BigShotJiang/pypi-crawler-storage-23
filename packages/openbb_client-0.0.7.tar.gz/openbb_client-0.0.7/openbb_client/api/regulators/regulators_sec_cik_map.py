from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_cik_map import OBBjectCikMap
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    use_cache: bool | None | Unset = True,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    json_use_cache: bool | None | Unset
    if isinstance(use_cache, Unset):
        json_use_cache = UNSET
    else:
        json_use_cache = use_cache
    params["use_cache"] = json_use_cache

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/regulators/sec/cik_map",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectCikMap.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    use_cache: bool | None | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse]:
    """Cik Map

     Map a ticker symbol to a CIK number.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for.
        use_cache (bool | None | Unset): Whether or not to use cache for the request, default is
            True. (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        use_cache=use_cache,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    use_cache: bool | None | Unset = True,
) -> Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse | None:
    """Cik Map

     Map a ticker symbol to a CIK number.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for.
        use_cache (bool | None | Unset): Whether or not to use cache for the request, default is
            True. (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        use_cache=use_cache,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    use_cache: bool | None | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse]:
    """Cik Map

     Map a ticker symbol to a CIK number.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for.
        use_cache (bool | None | Unset): Whether or not to use cache for the request, default is
            True. (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        use_cache=use_cache,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    use_cache: bool | None | Unset = True,
) -> Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse | None:
    """Cik Map

     Map a ticker symbol to a CIK number.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for.
        use_cache (bool | None | Unset): Whether or not to use cache for the request, default is
            True. (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCikMap | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            use_cache=use_cache,
        )
    ).parsed
