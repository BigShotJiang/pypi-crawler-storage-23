from enum import Enum


class EquityEstimatesForwardEbitdaEstimateTypeType0(str, Enum):
    CASH_FLOW_PER_SHARE = "cash_flow_per_share"
    EBIT = "ebit"
    EBITDA = "ebitda"
    ENTERPRISE_VALUE = "enterprise_value"
    PRETAX_INCOME = "pretax_income"

    def __str__(self) -> str:
        return str(self.value)
