from enum import Enum


class EquityFundamentalRatiosProvider(str, Enum):
    FMP = "fmp"
    INTRINIO = "intrinio"

    def __str__(self) -> str:
        return str(self.value)
