from enum import Enum


class EconomyCompositeLeadingIndicatorCountryType0(str, Enum):
    ALL = "all"
    ASIA5 = "asia5"
    AUSTRALIA = "australia"
    BRAZIL = "brazil"
    CANADA = "canada"
    CHINA = "china"
    EUROPE4 = "europe4"
    FRANCE = "france"
    G20 = "g20"
    G7 = "g7"
    GERMANY = "germany"
    INDIA = "india"
    INDONESIA = "indonesia"
    ITALY = "italy"
    JAPAN = "japan"
    MEXICO = "mexico"
    NORTH_AMERICA = "north_america"
    SOUTH_AFRICA = "south_africa"
    SOUTH_KOREA = "south_korea"
    SPAIN = "spain"
    TURKEY = "turkey"
    UNITED_KINGDOM = "united_kingdom"
    UNITED_STATES = "united_states"

    def __str__(self) -> str:
        return str(self.value)
