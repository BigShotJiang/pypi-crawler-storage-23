from enum import Enum


class EconomyFredSeriesProvider(str, Enum):
    FRED = "fred"
    INTRINIO = "intrinio"

    def __str__(self) -> str:
        return str(self.value)
