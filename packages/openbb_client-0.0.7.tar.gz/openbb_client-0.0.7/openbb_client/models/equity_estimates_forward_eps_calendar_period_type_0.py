from enum import Enum


class EquityEstimatesForwardEpsCalendarPeriodType0(str, Enum):
    Q1 = "q1"
    Q2 = "q2"
    Q3 = "q3"
    Q4 = "q4"

    def __str__(self) -> str:
        return str(self.value)
