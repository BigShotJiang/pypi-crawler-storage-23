from enum import Enum


class EquityEstimatesForwardEbitdaProvider(str, Enum):
    FMP = "fmp"
    INTRINIO = "intrinio"

    def __str__(self) -> str:
        return str(self.value)
