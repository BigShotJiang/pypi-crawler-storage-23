from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPBalanceSheetData")


@_attrs_define
class FMPBalanceSheetData:
    """FMP Balance Sheet Data.

    Attributes:
        period_ending (datetime.date): The end date of the reporting period.
        fiscal_period (None | str | Unset): The fiscal period of the report.
        fiscal_year (int | None | Unset): The fiscal year of the fiscal period.
        filing_date (datetime.date | None | Unset): The date when the filing was made.
        accepted_date (datetime.datetime | None | Unset): The date and time when the filing was accepted.
        cik (None | str | Unset): The Central Index Key (CIK) assigned by the SEC, if applicable.
        symbol (None | str | Unset): The stock ticker symbol.
        reported_currency (None | str | Unset): The currency in which the balance sheet was reported.
        cash_and_cash_equivalents (int | None | Unset): Cash and cash equivalents.
        short_term_investments (int | None | Unset): Short term investments.
        cash_and_short_term_investments (int | None | Unset): Cash and short term investments.
        accounts_receivables (int | None | Unset): Accounts receivables.
        other_receivables (int | None | Unset): Other receivables.
        net_receivables (int | None | Unset): Net receivables.
        inventory (int | None | Unset): Inventory.
        other_current_assets (int | None | Unset): Other current assets.
        total_current_assets (int | None | Unset): Total current assets.
        plant_property_equipment_net (int | None | Unset): Plant property equipment net.
        goodwill (int | None | Unset): Goodwill.
        intangible_assets (int | None | Unset): Intangible assets.
        goodwill_and_intangible_assets (int | None | Unset): Goodwill and intangible assets.
        long_term_investments (int | None | Unset): Long term investments.
        tax_assets (int | None | Unset): Tax assets.
        other_non_current_assets (int | None | Unset): Other non current assets.
        non_current_assets (int | None | Unset): Total non current assets.
        other_assets (int | None | Unset): Other assets.
        total_assets (int | None | Unset): Total assets.
        accounts_payable (int | None | Unset): Accounts payable.
        prepaid_expenses (int | None | Unset): Prepaid expenses.
        accrued_expenses (int | None | Unset): Accrued expenses.
        short_term_debt (int | None | Unset): Short term debt.
        tax_payables (int | None | Unset): Tax payables.
        current_deferred_revenue (int | None | Unset): Current deferred revenue.
        other_current_liabilities (int | None | Unset): Other current liabilities.
        other_payables (int | None | Unset): Other payables.
        total_current_liabilities (int | None | Unset): Total current liabilities.
        total_payables (int | None | Unset): Total payables.
        long_term_debt (int | None | Unset): Long term debt.
        deferred_revenue_non_current (int | None | Unset): Non current deferred revenue.
        deferred_tax_liabilities_non_current (int | None | Unset): Deferred tax liabilities non current.
        other_non_current_liabilities (int | None | Unset): Other non current liabilities.
        total_non_current_liabilities (int | None | Unset): Total non current liabilities.
        capital_lease_obligations_current (int | None | Unset): Current capital lease obligations.
        capital_lease_obligations_non_current (int | None | Unset): Non current capital lease obligations.
        capital_lease_obligations (int | None | Unset): Capital lease obligations.
        other_liabilities (int | None | Unset): Other liabilities.
        total_liabilities (int | None | Unset): Total liabilities.
        preferred_stock (int | None | Unset): Preferred stock.
        common_stock (int | None | Unset): Common stock.
        treasury_stock (int | None | Unset): Treasury stock.
        retained_earnings (int | None | Unset): Retained earnings.
        additional_paid_in_capital (int | None | Unset): Additional paid in capital.
        accumulated_other_comprehensive_income (int | None | Unset): Accumulated other comprehensive income (loss).
        other_shareholders_equity (int | None | Unset): Other shareholders equity.
        other_total_shareholders_equity (int | None | Unset): Other total shareholders equity.
        total_common_equity (int | None | Unset): Total common equity.
        total_equity_non_controlling_interests (int | None | Unset): Total equity non controlling interests.
        total_liabilities_and_shareholders_equity (int | None | Unset): Total liabilities and shareholders equity.
        minority_interest (int | None | Unset): Minority interest.
        total_liabilities_and_total_equity (int | None | Unset): Total liabilities and total equity.
        total_investments (int | None | Unset): Total investments.
        total_debt (int | None | Unset): Total debt.
        net_debt (int | None | Unset): Net debt.
    """

    period_ending: datetime.date
    fiscal_period: None | str | Unset = UNSET
    fiscal_year: int | None | Unset = UNSET
    filing_date: datetime.date | None | Unset = UNSET
    accepted_date: datetime.datetime | None | Unset = UNSET
    cik: None | str | Unset = UNSET
    symbol: None | str | Unset = UNSET
    reported_currency: None | str | Unset = UNSET
    cash_and_cash_equivalents: int | None | Unset = UNSET
    short_term_investments: int | None | Unset = UNSET
    cash_and_short_term_investments: int | None | Unset = UNSET
    accounts_receivables: int | None | Unset = UNSET
    other_receivables: int | None | Unset = UNSET
    net_receivables: int | None | Unset = UNSET
    inventory: int | None | Unset = UNSET
    other_current_assets: int | None | Unset = UNSET
    total_current_assets: int | None | Unset = UNSET
    plant_property_equipment_net: int | None | Unset = UNSET
    goodwill: int | None | Unset = UNSET
    intangible_assets: int | None | Unset = UNSET
    goodwill_and_intangible_assets: int | None | Unset = UNSET
    long_term_investments: int | None | Unset = UNSET
    tax_assets: int | None | Unset = UNSET
    other_non_current_assets: int | None | Unset = UNSET
    non_current_assets: int | None | Unset = UNSET
    other_assets: int | None | Unset = UNSET
    total_assets: int | None | Unset = UNSET
    accounts_payable: int | None | Unset = UNSET
    prepaid_expenses: int | None | Unset = UNSET
    accrued_expenses: int | None | Unset = UNSET
    short_term_debt: int | None | Unset = UNSET
    tax_payables: int | None | Unset = UNSET
    current_deferred_revenue: int | None | Unset = UNSET
    other_current_liabilities: int | None | Unset = UNSET
    other_payables: int | None | Unset = UNSET
    total_current_liabilities: int | None | Unset = UNSET
    total_payables: int | None | Unset = UNSET
    long_term_debt: int | None | Unset = UNSET
    deferred_revenue_non_current: int | None | Unset = UNSET
    deferred_tax_liabilities_non_current: int | None | Unset = UNSET
    other_non_current_liabilities: int | None | Unset = UNSET
    total_non_current_liabilities: int | None | Unset = UNSET
    capital_lease_obligations_current: int | None | Unset = UNSET
    capital_lease_obligations_non_current: int | None | Unset = UNSET
    capital_lease_obligations: int | None | Unset = UNSET
    other_liabilities: int | None | Unset = UNSET
    total_liabilities: int | None | Unset = UNSET
    preferred_stock: int | None | Unset = UNSET
    common_stock: int | None | Unset = UNSET
    treasury_stock: int | None | Unset = UNSET
    retained_earnings: int | None | Unset = UNSET
    additional_paid_in_capital: int | None | Unset = UNSET
    accumulated_other_comprehensive_income: int | None | Unset = UNSET
    other_shareholders_equity: int | None | Unset = UNSET
    other_total_shareholders_equity: int | None | Unset = UNSET
    total_common_equity: int | None | Unset = UNSET
    total_equity_non_controlling_interests: int | None | Unset = UNSET
    total_liabilities_and_shareholders_equity: int | None | Unset = UNSET
    minority_interest: int | None | Unset = UNSET
    total_liabilities_and_total_equity: int | None | Unset = UNSET
    total_investments: int | None | Unset = UNSET
    total_debt: int | None | Unset = UNSET
    net_debt: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        period_ending = self.period_ending.isoformat()

        fiscal_period: None | str | Unset
        if isinstance(self.fiscal_period, Unset):
            fiscal_period = UNSET
        else:
            fiscal_period = self.fiscal_period

        fiscal_year: int | None | Unset
        if isinstance(self.fiscal_year, Unset):
            fiscal_year = UNSET
        else:
            fiscal_year = self.fiscal_year

        filing_date: None | str | Unset
        if isinstance(self.filing_date, Unset):
            filing_date = UNSET
        elif isinstance(self.filing_date, datetime.date):
            filing_date = self.filing_date.isoformat()
        else:
            filing_date = self.filing_date

        accepted_date: None | str | Unset
        if isinstance(self.accepted_date, Unset):
            accepted_date = UNSET
        elif isinstance(self.accepted_date, datetime.datetime):
            accepted_date = self.accepted_date.isoformat()
        else:
            accepted_date = self.accepted_date

        cik: None | str | Unset
        if isinstance(self.cik, Unset):
            cik = UNSET
        else:
            cik = self.cik

        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        reported_currency: None | str | Unset
        if isinstance(self.reported_currency, Unset):
            reported_currency = UNSET
        else:
            reported_currency = self.reported_currency

        cash_and_cash_equivalents: int | None | Unset
        if isinstance(self.cash_and_cash_equivalents, Unset):
            cash_and_cash_equivalents = UNSET
        else:
            cash_and_cash_equivalents = self.cash_and_cash_equivalents

        short_term_investments: int | None | Unset
        if isinstance(self.short_term_investments, Unset):
            short_term_investments = UNSET
        else:
            short_term_investments = self.short_term_investments

        cash_and_short_term_investments: int | None | Unset
        if isinstance(self.cash_and_short_term_investments, Unset):
            cash_and_short_term_investments = UNSET
        else:
            cash_and_short_term_investments = self.cash_and_short_term_investments

        accounts_receivables: int | None | Unset
        if isinstance(self.accounts_receivables, Unset):
            accounts_receivables = UNSET
        else:
            accounts_receivables = self.accounts_receivables

        other_receivables: int | None | Unset
        if isinstance(self.other_receivables, Unset):
            other_receivables = UNSET
        else:
            other_receivables = self.other_receivables

        net_receivables: int | None | Unset
        if isinstance(self.net_receivables, Unset):
            net_receivables = UNSET
        else:
            net_receivables = self.net_receivables

        inventory: int | None | Unset
        if isinstance(self.inventory, Unset):
            inventory = UNSET
        else:
            inventory = self.inventory

        other_current_assets: int | None | Unset
        if isinstance(self.other_current_assets, Unset):
            other_current_assets = UNSET
        else:
            other_current_assets = self.other_current_assets

        total_current_assets: int | None | Unset
        if isinstance(self.total_current_assets, Unset):
            total_current_assets = UNSET
        else:
            total_current_assets = self.total_current_assets

        plant_property_equipment_net: int | None | Unset
        if isinstance(self.plant_property_equipment_net, Unset):
            plant_property_equipment_net = UNSET
        else:
            plant_property_equipment_net = self.plant_property_equipment_net

        goodwill: int | None | Unset
        if isinstance(self.goodwill, Unset):
            goodwill = UNSET
        else:
            goodwill = self.goodwill

        intangible_assets: int | None | Unset
        if isinstance(self.intangible_assets, Unset):
            intangible_assets = UNSET
        else:
            intangible_assets = self.intangible_assets

        goodwill_and_intangible_assets: int | None | Unset
        if isinstance(self.goodwill_and_intangible_assets, Unset):
            goodwill_and_intangible_assets = UNSET
        else:
            goodwill_and_intangible_assets = self.goodwill_and_intangible_assets

        long_term_investments: int | None | Unset
        if isinstance(self.long_term_investments, Unset):
            long_term_investments = UNSET
        else:
            long_term_investments = self.long_term_investments

        tax_assets: int | None | Unset
        if isinstance(self.tax_assets, Unset):
            tax_assets = UNSET
        else:
            tax_assets = self.tax_assets

        other_non_current_assets: int | None | Unset
        if isinstance(self.other_non_current_assets, Unset):
            other_non_current_assets = UNSET
        else:
            other_non_current_assets = self.other_non_current_assets

        non_current_assets: int | None | Unset
        if isinstance(self.non_current_assets, Unset):
            non_current_assets = UNSET
        else:
            non_current_assets = self.non_current_assets

        other_assets: int | None | Unset
        if isinstance(self.other_assets, Unset):
            other_assets = UNSET
        else:
            other_assets = self.other_assets

        total_assets: int | None | Unset
        if isinstance(self.total_assets, Unset):
            total_assets = UNSET
        else:
            total_assets = self.total_assets

        accounts_payable: int | None | Unset
        if isinstance(self.accounts_payable, Unset):
            accounts_payable = UNSET
        else:
            accounts_payable = self.accounts_payable

        prepaid_expenses: int | None | Unset
        if isinstance(self.prepaid_expenses, Unset):
            prepaid_expenses = UNSET
        else:
            prepaid_expenses = self.prepaid_expenses

        accrued_expenses: int | None | Unset
        if isinstance(self.accrued_expenses, Unset):
            accrued_expenses = UNSET
        else:
            accrued_expenses = self.accrued_expenses

        short_term_debt: int | None | Unset
        if isinstance(self.short_term_debt, Unset):
            short_term_debt = UNSET
        else:
            short_term_debt = self.short_term_debt

        tax_payables: int | None | Unset
        if isinstance(self.tax_payables, Unset):
            tax_payables = UNSET
        else:
            tax_payables = self.tax_payables

        current_deferred_revenue: int | None | Unset
        if isinstance(self.current_deferred_revenue, Unset):
            current_deferred_revenue = UNSET
        else:
            current_deferred_revenue = self.current_deferred_revenue

        other_current_liabilities: int | None | Unset
        if isinstance(self.other_current_liabilities, Unset):
            other_current_liabilities = UNSET
        else:
            other_current_liabilities = self.other_current_liabilities

        other_payables: int | None | Unset
        if isinstance(self.other_payables, Unset):
            other_payables = UNSET
        else:
            other_payables = self.other_payables

        total_current_liabilities: int | None | Unset
        if isinstance(self.total_current_liabilities, Unset):
            total_current_liabilities = UNSET
        else:
            total_current_liabilities = self.total_current_liabilities

        total_payables: int | None | Unset
        if isinstance(self.total_payables, Unset):
            total_payables = UNSET
        else:
            total_payables = self.total_payables

        long_term_debt: int | None | Unset
        if isinstance(self.long_term_debt, Unset):
            long_term_debt = UNSET
        else:
            long_term_debt = self.long_term_debt

        deferred_revenue_non_current: int | None | Unset
        if isinstance(self.deferred_revenue_non_current, Unset):
            deferred_revenue_non_current = UNSET
        else:
            deferred_revenue_non_current = self.deferred_revenue_non_current

        deferred_tax_liabilities_non_current: int | None | Unset
        if isinstance(self.deferred_tax_liabilities_non_current, Unset):
            deferred_tax_liabilities_non_current = UNSET
        else:
            deferred_tax_liabilities_non_current = self.deferred_tax_liabilities_non_current

        other_non_current_liabilities: int | None | Unset
        if isinstance(self.other_non_current_liabilities, Unset):
            other_non_current_liabilities = UNSET
        else:
            other_non_current_liabilities = self.other_non_current_liabilities

        total_non_current_liabilities: int | None | Unset
        if isinstance(self.total_non_current_liabilities, Unset):
            total_non_current_liabilities = UNSET
        else:
            total_non_current_liabilities = self.total_non_current_liabilities

        capital_lease_obligations_current: int | None | Unset
        if isinstance(self.capital_lease_obligations_current, Unset):
            capital_lease_obligations_current = UNSET
        else:
            capital_lease_obligations_current = self.capital_lease_obligations_current

        capital_lease_obligations_non_current: int | None | Unset
        if isinstance(self.capital_lease_obligations_non_current, Unset):
            capital_lease_obligations_non_current = UNSET
        else:
            capital_lease_obligations_non_current = self.capital_lease_obligations_non_current

        capital_lease_obligations: int | None | Unset
        if isinstance(self.capital_lease_obligations, Unset):
            capital_lease_obligations = UNSET
        else:
            capital_lease_obligations = self.capital_lease_obligations

        other_liabilities: int | None | Unset
        if isinstance(self.other_liabilities, Unset):
            other_liabilities = UNSET
        else:
            other_liabilities = self.other_liabilities

        total_liabilities: int | None | Unset
        if isinstance(self.total_liabilities, Unset):
            total_liabilities = UNSET
        else:
            total_liabilities = self.total_liabilities

        preferred_stock: int | None | Unset
        if isinstance(self.preferred_stock, Unset):
            preferred_stock = UNSET
        else:
            preferred_stock = self.preferred_stock

        common_stock: int | None | Unset
        if isinstance(self.common_stock, Unset):
            common_stock = UNSET
        else:
            common_stock = self.common_stock

        treasury_stock: int | None | Unset
        if isinstance(self.treasury_stock, Unset):
            treasury_stock = UNSET
        else:
            treasury_stock = self.treasury_stock

        retained_earnings: int | None | Unset
        if isinstance(self.retained_earnings, Unset):
            retained_earnings = UNSET
        else:
            retained_earnings = self.retained_earnings

        additional_paid_in_capital: int | None | Unset
        if isinstance(self.additional_paid_in_capital, Unset):
            additional_paid_in_capital = UNSET
        else:
            additional_paid_in_capital = self.additional_paid_in_capital

        accumulated_other_comprehensive_income: int | None | Unset
        if isinstance(self.accumulated_other_comprehensive_income, Unset):
            accumulated_other_comprehensive_income = UNSET
        else:
            accumulated_other_comprehensive_income = self.accumulated_other_comprehensive_income

        other_shareholders_equity: int | None | Unset
        if isinstance(self.other_shareholders_equity, Unset):
            other_shareholders_equity = UNSET
        else:
            other_shareholders_equity = self.other_shareholders_equity

        other_total_shareholders_equity: int | None | Unset
        if isinstance(self.other_total_shareholders_equity, Unset):
            other_total_shareholders_equity = UNSET
        else:
            other_total_shareholders_equity = self.other_total_shareholders_equity

        total_common_equity: int | None | Unset
        if isinstance(self.total_common_equity, Unset):
            total_common_equity = UNSET
        else:
            total_common_equity = self.total_common_equity

        total_equity_non_controlling_interests: int | None | Unset
        if isinstance(self.total_equity_non_controlling_interests, Unset):
            total_equity_non_controlling_interests = UNSET
        else:
            total_equity_non_controlling_interests = self.total_equity_non_controlling_interests

        total_liabilities_and_shareholders_equity: int | None | Unset
        if isinstance(self.total_liabilities_and_shareholders_equity, Unset):
            total_liabilities_and_shareholders_equity = UNSET
        else:
            total_liabilities_and_shareholders_equity = self.total_liabilities_and_shareholders_equity

        minority_interest: int | None | Unset
        if isinstance(self.minority_interest, Unset):
            minority_interest = UNSET
        else:
            minority_interest = self.minority_interest

        total_liabilities_and_total_equity: int | None | Unset
        if isinstance(self.total_liabilities_and_total_equity, Unset):
            total_liabilities_and_total_equity = UNSET
        else:
            total_liabilities_and_total_equity = self.total_liabilities_and_total_equity

        total_investments: int | None | Unset
        if isinstance(self.total_investments, Unset):
            total_investments = UNSET
        else:
            total_investments = self.total_investments

        total_debt: int | None | Unset
        if isinstance(self.total_debt, Unset):
            total_debt = UNSET
        else:
            total_debt = self.total_debt

        net_debt: int | None | Unset
        if isinstance(self.net_debt, Unset):
            net_debt = UNSET
        else:
            net_debt = self.net_debt

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "period_ending": period_ending,
            }
        )
        if fiscal_period is not UNSET:
            field_dict["fiscal_period"] = fiscal_period
        if fiscal_year is not UNSET:
            field_dict["fiscal_year"] = fiscal_year
        if filing_date is not UNSET:
            field_dict["filing_date"] = filing_date
        if accepted_date is not UNSET:
            field_dict["accepted_date"] = accepted_date
        if cik is not UNSET:
            field_dict["cik"] = cik
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if reported_currency is not UNSET:
            field_dict["reported_currency"] = reported_currency
        if cash_and_cash_equivalents is not UNSET:
            field_dict["cash_and_cash_equivalents"] = cash_and_cash_equivalents
        if short_term_investments is not UNSET:
            field_dict["short_term_investments"] = short_term_investments
        if cash_and_short_term_investments is not UNSET:
            field_dict["cash_and_short_term_investments"] = cash_and_short_term_investments
        if accounts_receivables is not UNSET:
            field_dict["accounts_receivables"] = accounts_receivables
        if other_receivables is not UNSET:
            field_dict["other_receivables"] = other_receivables
        if net_receivables is not UNSET:
            field_dict["net_receivables"] = net_receivables
        if inventory is not UNSET:
            field_dict["inventory"] = inventory
        if other_current_assets is not UNSET:
            field_dict["other_current_assets"] = other_current_assets
        if total_current_assets is not UNSET:
            field_dict["total_current_assets"] = total_current_assets
        if plant_property_equipment_net is not UNSET:
            field_dict["plant_property_equipment_net"] = plant_property_equipment_net
        if goodwill is not UNSET:
            field_dict["goodwill"] = goodwill
        if intangible_assets is not UNSET:
            field_dict["intangible_assets"] = intangible_assets
        if goodwill_and_intangible_assets is not UNSET:
            field_dict["goodwill_and_intangible_assets"] = goodwill_and_intangible_assets
        if long_term_investments is not UNSET:
            field_dict["long_term_investments"] = long_term_investments
        if tax_assets is not UNSET:
            field_dict["tax_assets"] = tax_assets
        if other_non_current_assets is not UNSET:
            field_dict["other_non_current_assets"] = other_non_current_assets
        if non_current_assets is not UNSET:
            field_dict["non_current_assets"] = non_current_assets
        if other_assets is not UNSET:
            field_dict["other_assets"] = other_assets
        if total_assets is not UNSET:
            field_dict["total_assets"] = total_assets
        if accounts_payable is not UNSET:
            field_dict["accounts_payable"] = accounts_payable
        if prepaid_expenses is not UNSET:
            field_dict["prepaid_expenses"] = prepaid_expenses
        if accrued_expenses is not UNSET:
            field_dict["accrued_expenses"] = accrued_expenses
        if short_term_debt is not UNSET:
            field_dict["short_term_debt"] = short_term_debt
        if tax_payables is not UNSET:
            field_dict["tax_payables"] = tax_payables
        if current_deferred_revenue is not UNSET:
            field_dict["current_deferred_revenue"] = current_deferred_revenue
        if other_current_liabilities is not UNSET:
            field_dict["other_current_liabilities"] = other_current_liabilities
        if other_payables is not UNSET:
            field_dict["other_payables"] = other_payables
        if total_current_liabilities is not UNSET:
            field_dict["total_current_liabilities"] = total_current_liabilities
        if total_payables is not UNSET:
            field_dict["total_payables"] = total_payables
        if long_term_debt is not UNSET:
            field_dict["long_term_debt"] = long_term_debt
        if deferred_revenue_non_current is not UNSET:
            field_dict["deferred_revenue_non_current"] = deferred_revenue_non_current
        if deferred_tax_liabilities_non_current is not UNSET:
            field_dict["deferred_tax_liabilities_non_current"] = deferred_tax_liabilities_non_current
        if other_non_current_liabilities is not UNSET:
            field_dict["other_non_current_liabilities"] = other_non_current_liabilities
        if total_non_current_liabilities is not UNSET:
            field_dict["total_non_current_liabilities"] = total_non_current_liabilities
        if capital_lease_obligations_current is not UNSET:
            field_dict["capital_lease_obligations_current"] = capital_lease_obligations_current
        if capital_lease_obligations_non_current is not UNSET:
            field_dict["capital_lease_obligations_non_current"] = capital_lease_obligations_non_current
        if capital_lease_obligations is not UNSET:
            field_dict["capital_lease_obligations"] = capital_lease_obligations
        if other_liabilities is not UNSET:
            field_dict["other_liabilities"] = other_liabilities
        if total_liabilities is not UNSET:
            field_dict["total_liabilities"] = total_liabilities
        if preferred_stock is not UNSET:
            field_dict["preferred_stock"] = preferred_stock
        if common_stock is not UNSET:
            field_dict["common_stock"] = common_stock
        if treasury_stock is not UNSET:
            field_dict["treasury_stock"] = treasury_stock
        if retained_earnings is not UNSET:
            field_dict["retained_earnings"] = retained_earnings
        if additional_paid_in_capital is not UNSET:
            field_dict["additional_paid_in_capital"] = additional_paid_in_capital
        if accumulated_other_comprehensive_income is not UNSET:
            field_dict["accumulated_other_comprehensive_income"] = accumulated_other_comprehensive_income
        if other_shareholders_equity is not UNSET:
            field_dict["other_shareholders_equity"] = other_shareholders_equity
        if other_total_shareholders_equity is not UNSET:
            field_dict["other_total_shareholders_equity"] = other_total_shareholders_equity
        if total_common_equity is not UNSET:
            field_dict["total_common_equity"] = total_common_equity
        if total_equity_non_controlling_interests is not UNSET:
            field_dict["total_equity_non_controlling_interests"] = total_equity_non_controlling_interests
        if total_liabilities_and_shareholders_equity is not UNSET:
            field_dict["total_liabilities_and_shareholders_equity"] = total_liabilities_and_shareholders_equity
        if minority_interest is not UNSET:
            field_dict["minority_interest"] = minority_interest
        if total_liabilities_and_total_equity is not UNSET:
            field_dict["total_liabilities_and_total_equity"] = total_liabilities_and_total_equity
        if total_investments is not UNSET:
            field_dict["total_investments"] = total_investments
        if total_debt is not UNSET:
            field_dict["total_debt"] = total_debt
        if net_debt is not UNSET:
            field_dict["net_debt"] = net_debt

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        period_ending = isoparse(d.pop("period_ending")).date()

        def _parse_fiscal_period(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fiscal_period = _parse_fiscal_period(d.pop("fiscal_period", UNSET))

        def _parse_fiscal_year(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year", UNSET))

        def _parse_filing_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                filing_date_type_0 = isoparse(data).date()

                return filing_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        filing_date = _parse_filing_date(d.pop("filing_date", UNSET))

        def _parse_accepted_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                accepted_date_type_0 = isoparse(data)

                return accepted_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        accepted_date = _parse_accepted_date(d.pop("accepted_date", UNSET))

        def _parse_cik(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cik = _parse_cik(d.pop("cik", UNSET))

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_reported_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reported_currency = _parse_reported_currency(d.pop("reported_currency", UNSET))

        def _parse_cash_and_cash_equivalents(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cash_and_cash_equivalents = _parse_cash_and_cash_equivalents(d.pop("cash_and_cash_equivalents", UNSET))

        def _parse_short_term_investments(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        short_term_investments = _parse_short_term_investments(d.pop("short_term_investments", UNSET))

        def _parse_cash_and_short_term_investments(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cash_and_short_term_investments = _parse_cash_and_short_term_investments(
            d.pop("cash_and_short_term_investments", UNSET)
        )

        def _parse_accounts_receivables(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        accounts_receivables = _parse_accounts_receivables(d.pop("accounts_receivables", UNSET))

        def _parse_other_receivables(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_receivables = _parse_other_receivables(d.pop("other_receivables", UNSET))

        def _parse_net_receivables(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_receivables = _parse_net_receivables(d.pop("net_receivables", UNSET))

        def _parse_inventory(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        inventory = _parse_inventory(d.pop("inventory", UNSET))

        def _parse_other_current_assets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_current_assets = _parse_other_current_assets(d.pop("other_current_assets", UNSET))

        def _parse_total_current_assets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_current_assets = _parse_total_current_assets(d.pop("total_current_assets", UNSET))

        def _parse_plant_property_equipment_net(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        plant_property_equipment_net = _parse_plant_property_equipment_net(d.pop("plant_property_equipment_net", UNSET))

        def _parse_goodwill(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        goodwill = _parse_goodwill(d.pop("goodwill", UNSET))

        def _parse_intangible_assets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        intangible_assets = _parse_intangible_assets(d.pop("intangible_assets", UNSET))

        def _parse_goodwill_and_intangible_assets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        goodwill_and_intangible_assets = _parse_goodwill_and_intangible_assets(
            d.pop("goodwill_and_intangible_assets", UNSET)
        )

        def _parse_long_term_investments(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        long_term_investments = _parse_long_term_investments(d.pop("long_term_investments", UNSET))

        def _parse_tax_assets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        tax_assets = _parse_tax_assets(d.pop("tax_assets", UNSET))

        def _parse_other_non_current_assets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_non_current_assets = _parse_other_non_current_assets(d.pop("other_non_current_assets", UNSET))

        def _parse_non_current_assets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        non_current_assets = _parse_non_current_assets(d.pop("non_current_assets", UNSET))

        def _parse_other_assets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_assets = _parse_other_assets(d.pop("other_assets", UNSET))

        def _parse_total_assets(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_assets = _parse_total_assets(d.pop("total_assets", UNSET))

        def _parse_accounts_payable(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        accounts_payable = _parse_accounts_payable(d.pop("accounts_payable", UNSET))

        def _parse_prepaid_expenses(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        prepaid_expenses = _parse_prepaid_expenses(d.pop("prepaid_expenses", UNSET))

        def _parse_accrued_expenses(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        accrued_expenses = _parse_accrued_expenses(d.pop("accrued_expenses", UNSET))

        def _parse_short_term_debt(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        short_term_debt = _parse_short_term_debt(d.pop("short_term_debt", UNSET))

        def _parse_tax_payables(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        tax_payables = _parse_tax_payables(d.pop("tax_payables", UNSET))

        def _parse_current_deferred_revenue(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        current_deferred_revenue = _parse_current_deferred_revenue(d.pop("current_deferred_revenue", UNSET))

        def _parse_other_current_liabilities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_current_liabilities = _parse_other_current_liabilities(d.pop("other_current_liabilities", UNSET))

        def _parse_other_payables(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_payables = _parse_other_payables(d.pop("other_payables", UNSET))

        def _parse_total_current_liabilities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_current_liabilities = _parse_total_current_liabilities(d.pop("total_current_liabilities", UNSET))

        def _parse_total_payables(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_payables = _parse_total_payables(d.pop("total_payables", UNSET))

        def _parse_long_term_debt(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        long_term_debt = _parse_long_term_debt(d.pop("long_term_debt", UNSET))

        def _parse_deferred_revenue_non_current(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        deferred_revenue_non_current = _parse_deferred_revenue_non_current(d.pop("deferred_revenue_non_current", UNSET))

        def _parse_deferred_tax_liabilities_non_current(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        deferred_tax_liabilities_non_current = _parse_deferred_tax_liabilities_non_current(
            d.pop("deferred_tax_liabilities_non_current", UNSET)
        )

        def _parse_other_non_current_liabilities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_non_current_liabilities = _parse_other_non_current_liabilities(
            d.pop("other_non_current_liabilities", UNSET)
        )

        def _parse_total_non_current_liabilities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_non_current_liabilities = _parse_total_non_current_liabilities(
            d.pop("total_non_current_liabilities", UNSET)
        )

        def _parse_capital_lease_obligations_current(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        capital_lease_obligations_current = _parse_capital_lease_obligations_current(
            d.pop("capital_lease_obligations_current", UNSET)
        )

        def _parse_capital_lease_obligations_non_current(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        capital_lease_obligations_non_current = _parse_capital_lease_obligations_non_current(
            d.pop("capital_lease_obligations_non_current", UNSET)
        )

        def _parse_capital_lease_obligations(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        capital_lease_obligations = _parse_capital_lease_obligations(d.pop("capital_lease_obligations", UNSET))

        def _parse_other_liabilities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_liabilities = _parse_other_liabilities(d.pop("other_liabilities", UNSET))

        def _parse_total_liabilities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_liabilities = _parse_total_liabilities(d.pop("total_liabilities", UNSET))

        def _parse_preferred_stock(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        preferred_stock = _parse_preferred_stock(d.pop("preferred_stock", UNSET))

        def _parse_common_stock(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        common_stock = _parse_common_stock(d.pop("common_stock", UNSET))

        def _parse_treasury_stock(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        treasury_stock = _parse_treasury_stock(d.pop("treasury_stock", UNSET))

        def _parse_retained_earnings(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        retained_earnings = _parse_retained_earnings(d.pop("retained_earnings", UNSET))

        def _parse_additional_paid_in_capital(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        additional_paid_in_capital = _parse_additional_paid_in_capital(d.pop("additional_paid_in_capital", UNSET))

        def _parse_accumulated_other_comprehensive_income(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        accumulated_other_comprehensive_income = _parse_accumulated_other_comprehensive_income(
            d.pop("accumulated_other_comprehensive_income", UNSET)
        )

        def _parse_other_shareholders_equity(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_shareholders_equity = _parse_other_shareholders_equity(d.pop("other_shareholders_equity", UNSET))

        def _parse_other_total_shareholders_equity(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_total_shareholders_equity = _parse_other_total_shareholders_equity(
            d.pop("other_total_shareholders_equity", UNSET)
        )

        def _parse_total_common_equity(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_common_equity = _parse_total_common_equity(d.pop("total_common_equity", UNSET))

        def _parse_total_equity_non_controlling_interests(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_equity_non_controlling_interests = _parse_total_equity_non_controlling_interests(
            d.pop("total_equity_non_controlling_interests", UNSET)
        )

        def _parse_total_liabilities_and_shareholders_equity(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_liabilities_and_shareholders_equity = _parse_total_liabilities_and_shareholders_equity(
            d.pop("total_liabilities_and_shareholders_equity", UNSET)
        )

        def _parse_minority_interest(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        minority_interest = _parse_minority_interest(d.pop("minority_interest", UNSET))

        def _parse_total_liabilities_and_total_equity(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_liabilities_and_total_equity = _parse_total_liabilities_and_total_equity(
            d.pop("total_liabilities_and_total_equity", UNSET)
        )

        def _parse_total_investments(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_investments = _parse_total_investments(d.pop("total_investments", UNSET))

        def _parse_total_debt(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_debt = _parse_total_debt(d.pop("total_debt", UNSET))

        def _parse_net_debt(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_debt = _parse_net_debt(d.pop("net_debt", UNSET))

        fmp_balance_sheet_data = cls(
            period_ending=period_ending,
            fiscal_period=fiscal_period,
            fiscal_year=fiscal_year,
            filing_date=filing_date,
            accepted_date=accepted_date,
            cik=cik,
            symbol=symbol,
            reported_currency=reported_currency,
            cash_and_cash_equivalents=cash_and_cash_equivalents,
            short_term_investments=short_term_investments,
            cash_and_short_term_investments=cash_and_short_term_investments,
            accounts_receivables=accounts_receivables,
            other_receivables=other_receivables,
            net_receivables=net_receivables,
            inventory=inventory,
            other_current_assets=other_current_assets,
            total_current_assets=total_current_assets,
            plant_property_equipment_net=plant_property_equipment_net,
            goodwill=goodwill,
            intangible_assets=intangible_assets,
            goodwill_and_intangible_assets=goodwill_and_intangible_assets,
            long_term_investments=long_term_investments,
            tax_assets=tax_assets,
            other_non_current_assets=other_non_current_assets,
            non_current_assets=non_current_assets,
            other_assets=other_assets,
            total_assets=total_assets,
            accounts_payable=accounts_payable,
            prepaid_expenses=prepaid_expenses,
            accrued_expenses=accrued_expenses,
            short_term_debt=short_term_debt,
            tax_payables=tax_payables,
            current_deferred_revenue=current_deferred_revenue,
            other_current_liabilities=other_current_liabilities,
            other_payables=other_payables,
            total_current_liabilities=total_current_liabilities,
            total_payables=total_payables,
            long_term_debt=long_term_debt,
            deferred_revenue_non_current=deferred_revenue_non_current,
            deferred_tax_liabilities_non_current=deferred_tax_liabilities_non_current,
            other_non_current_liabilities=other_non_current_liabilities,
            total_non_current_liabilities=total_non_current_liabilities,
            capital_lease_obligations_current=capital_lease_obligations_current,
            capital_lease_obligations_non_current=capital_lease_obligations_non_current,
            capital_lease_obligations=capital_lease_obligations,
            other_liabilities=other_liabilities,
            total_liabilities=total_liabilities,
            preferred_stock=preferred_stock,
            common_stock=common_stock,
            treasury_stock=treasury_stock,
            retained_earnings=retained_earnings,
            additional_paid_in_capital=additional_paid_in_capital,
            accumulated_other_comprehensive_income=accumulated_other_comprehensive_income,
            other_shareholders_equity=other_shareholders_equity,
            other_total_shareholders_equity=other_total_shareholders_equity,
            total_common_equity=total_common_equity,
            total_equity_non_controlling_interests=total_equity_non_controlling_interests,
            total_liabilities_and_shareholders_equity=total_liabilities_and_shareholders_equity,
            minority_interest=minority_interest,
            total_liabilities_and_total_equity=total_liabilities_and_total_equity,
            total_investments=total_investments,
            total_debt=total_debt,
            net_debt=net_debt,
        )

        fmp_balance_sheet_data.additional_properties = d
        return fmp_balance_sheet_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
