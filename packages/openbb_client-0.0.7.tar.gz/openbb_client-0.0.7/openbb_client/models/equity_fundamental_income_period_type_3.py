from enum import Enum


class EquityFundamentalIncomePeriodType3(str, Enum):
    ANNUAL = "annual"
    QUARTER = "quarter"
    TTM = "ttm"

    def __str__(self) -> str:
        return str(self.value)
