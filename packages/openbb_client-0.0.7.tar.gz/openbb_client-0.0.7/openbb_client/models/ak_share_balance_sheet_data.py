from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AKShareBalanceSheetData")


@_attrs_define
class AKShareBalanceSheetData:
    """AKShare Balance Sheet Data.

    Attributes:
        period_ending (datetime.date): The end date of the reporting period.
        fiscal_period (None | str | Unset): The fiscal period of the report.
        fiscal_year (int | None | Unset): The fiscal year of the fiscal period.
        总权益 (float | None | Unset): 总权益.
        负债总额 (float | None | Unset): 负债总额.
        总资产 (float | None | Unset): 总资产.
    """

    period_ending: datetime.date
    fiscal_period: None | str | Unset = UNSET
    fiscal_year: int | None | Unset = UNSET
    总权益: float | None | Unset = UNSET
    负债总额: float | None | Unset = UNSET
    总资产: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        period_ending = self.period_ending.isoformat()

        fiscal_period: None | str | Unset
        if isinstance(self.fiscal_period, Unset):
            fiscal_period = UNSET
        else:
            fiscal_period = self.fiscal_period

        fiscal_year: int | None | Unset
        if isinstance(self.fiscal_year, Unset):
            fiscal_year = UNSET
        else:
            fiscal_year = self.fiscal_year

        总权益: float | None | Unset
        if isinstance(self.总权益, Unset):
            总权益 = UNSET
        else:
            总权益 = self.总权益

        负债总额: float | None | Unset
        if isinstance(self.负债总额, Unset):
            负债总额 = UNSET
        else:
            负债总额 = self.负债总额

        总资产: float | None | Unset
        if isinstance(self.总资产, Unset):
            总资产 = UNSET
        else:
            总资产 = self.总资产

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "period_ending": period_ending,
            }
        )
        if fiscal_period is not UNSET:
            field_dict["fiscal_period"] = fiscal_period
        if fiscal_year is not UNSET:
            field_dict["fiscal_year"] = fiscal_year
        if 总权益 is not UNSET:
            field_dict["总权益"] = 总权益
        if 负债总额 is not UNSET:
            field_dict["负债总额"] = 负债总额
        if 总资产 is not UNSET:
            field_dict["总资产"] = 总资产

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        period_ending = isoparse(d.pop("period_ending")).date()

        def _parse_fiscal_period(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fiscal_period = _parse_fiscal_period(d.pop("fiscal_period", UNSET))

        def _parse_fiscal_year(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year", UNSET))

        def _parse_总权益(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        总权益 = _parse_总权益(d.pop("总权益", UNSET))

        def _parse_负债总额(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        负债总额 = _parse_负债总额(d.pop("负债总额", UNSET))

        def _parse_总资产(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        总资产 = _parse_总资产(d.pop("总资产", UNSET))

        ak_share_balance_sheet_data = cls(
            period_ending=period_ending,
            fiscal_period=fiscal_period,
            fiscal_year=fiscal_year,
            总权益=总权益,
            负债总额=负债总额,
            总资产=总资产,
        )

        ak_share_balance_sheet_data.additional_properties = d
        return ak_share_balance_sheet_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
