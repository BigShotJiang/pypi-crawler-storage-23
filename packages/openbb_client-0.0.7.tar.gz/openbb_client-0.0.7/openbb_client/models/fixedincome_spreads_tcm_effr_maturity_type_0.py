from enum import Enum


class FixedincomeSpreadsTcmEffrMaturityType0(str, Enum):
    VALUE_0 = "10y"
    VALUE_1 = "5y"
    VALUE_2 = "1y"
    VALUE_3 = "6m"
    VALUE_4 = "3m"

    def __str__(self) -> str:
        return str(self.value)
