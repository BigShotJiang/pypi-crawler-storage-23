from enum import Enum


class EquityScreenerSectorType2(str, Enum):
    BASIC_MATERIALS = "basic_materials"
    COMMUNICATION_SERVICES = "communication_services"
    CONSUMER_CYCLICAL = "consumer_cyclical"
    CONSUMER_DEFENSIVE = "consumer_defensive"
    ENERGY = "energy"
    FINANCIAL_SERVICES = "financial_services"
    HEALTHCARE = "healthcare"
    INDUSTRIALS = "industrials"
    REAL_ESTATE = "real_estate"
    TECHNOLOGY = "technology"
    UTILITIES = "utilities"

    def __str__(self) -> str:
        return str(self.value)
