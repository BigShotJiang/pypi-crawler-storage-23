from enum import Enum


class FixedincomeRateAmeriborMaturityType0(str, Enum):
    ALL = "all"
    AVERAGE_30D = "average_30d"
    AVERAGE_90D = "average_90d"
    OVERNIGHT = "overnight"
    TERM_30D = "term_30d"
    TERM_90D = "term_90d"

    def __str__(self) -> str:
        return str(self.value)
