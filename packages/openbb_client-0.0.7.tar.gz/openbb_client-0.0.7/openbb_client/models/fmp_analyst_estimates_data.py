from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPAnalystEstimatesData")


@_attrs_define
class FMPAnalystEstimatesData:
    """FMP Analyst Estimates Data.

    Attributes:
        symbol (str): Symbol representing the entity requested in the data.
        date (datetime.date): The date of the data.
        estimated_revenue_low (int | None | Unset): Estimated revenue low.
        estimated_revenue_high (int | None | Unset): Estimated revenue high.
        estimated_revenue_avg (int | None | Unset): Estimated revenue average.
        estimated_sga_expense_low (int | None | Unset): Estimated SGA expense low.
        estimated_sga_expense_high (int | None | Unset): Estimated SGA expense high.
        estimated_sga_expense_avg (int | None | Unset): Estimated SGA expense average.
        estimated_ebitda_low (int | None | Unset): Estimated EBITDA low.
        estimated_ebitda_high (int | None | Unset): Estimated EBITDA high.
        estimated_ebitda_avg (int | None | Unset): Estimated EBITDA average.
        estimated_ebit_low (int | None | Unset): Estimated EBIT low.
        estimated_ebit_high (int | None | Unset): Estimated EBIT high.
        estimated_ebit_avg (int | None | Unset): Estimated EBIT average.
        estimated_net_income_low (int | None | Unset): Estimated net income low.
        estimated_net_income_high (int | None | Unset): Estimated net income high.
        estimated_net_income_avg (int | None | Unset): Estimated net income average.
        estimated_eps_avg (float | None | Unset): Estimated EPS average.
        estimated_eps_high (float | None | Unset): Estimated EPS high.
        estimated_eps_low (float | None | Unset): Estimated EPS low.
        number_analyst_estimated_revenue (int | None | Unset): Number of analysts who estimated revenue.
        number_analysts_estimated_eps (int | None | Unset): Number of analysts who estimated EPS.
    """

    symbol: str
    date: datetime.date
    estimated_revenue_low: int | None | Unset = UNSET
    estimated_revenue_high: int | None | Unset = UNSET
    estimated_revenue_avg: int | None | Unset = UNSET
    estimated_sga_expense_low: int | None | Unset = UNSET
    estimated_sga_expense_high: int | None | Unset = UNSET
    estimated_sga_expense_avg: int | None | Unset = UNSET
    estimated_ebitda_low: int | None | Unset = UNSET
    estimated_ebitda_high: int | None | Unset = UNSET
    estimated_ebitda_avg: int | None | Unset = UNSET
    estimated_ebit_low: int | None | Unset = UNSET
    estimated_ebit_high: int | None | Unset = UNSET
    estimated_ebit_avg: int | None | Unset = UNSET
    estimated_net_income_low: int | None | Unset = UNSET
    estimated_net_income_high: int | None | Unset = UNSET
    estimated_net_income_avg: int | None | Unset = UNSET
    estimated_eps_avg: float | None | Unset = UNSET
    estimated_eps_high: float | None | Unset = UNSET
    estimated_eps_low: float | None | Unset = UNSET
    number_analyst_estimated_revenue: int | None | Unset = UNSET
    number_analysts_estimated_eps: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        symbol = self.symbol

        date = self.date.isoformat()

        estimated_revenue_low: int | None | Unset
        if isinstance(self.estimated_revenue_low, Unset):
            estimated_revenue_low = UNSET
        else:
            estimated_revenue_low = self.estimated_revenue_low

        estimated_revenue_high: int | None | Unset
        if isinstance(self.estimated_revenue_high, Unset):
            estimated_revenue_high = UNSET
        else:
            estimated_revenue_high = self.estimated_revenue_high

        estimated_revenue_avg: int | None | Unset
        if isinstance(self.estimated_revenue_avg, Unset):
            estimated_revenue_avg = UNSET
        else:
            estimated_revenue_avg = self.estimated_revenue_avg

        estimated_sga_expense_low: int | None | Unset
        if isinstance(self.estimated_sga_expense_low, Unset):
            estimated_sga_expense_low = UNSET
        else:
            estimated_sga_expense_low = self.estimated_sga_expense_low

        estimated_sga_expense_high: int | None | Unset
        if isinstance(self.estimated_sga_expense_high, Unset):
            estimated_sga_expense_high = UNSET
        else:
            estimated_sga_expense_high = self.estimated_sga_expense_high

        estimated_sga_expense_avg: int | None | Unset
        if isinstance(self.estimated_sga_expense_avg, Unset):
            estimated_sga_expense_avg = UNSET
        else:
            estimated_sga_expense_avg = self.estimated_sga_expense_avg

        estimated_ebitda_low: int | None | Unset
        if isinstance(self.estimated_ebitda_low, Unset):
            estimated_ebitda_low = UNSET
        else:
            estimated_ebitda_low = self.estimated_ebitda_low

        estimated_ebitda_high: int | None | Unset
        if isinstance(self.estimated_ebitda_high, Unset):
            estimated_ebitda_high = UNSET
        else:
            estimated_ebitda_high = self.estimated_ebitda_high

        estimated_ebitda_avg: int | None | Unset
        if isinstance(self.estimated_ebitda_avg, Unset):
            estimated_ebitda_avg = UNSET
        else:
            estimated_ebitda_avg = self.estimated_ebitda_avg

        estimated_ebit_low: int | None | Unset
        if isinstance(self.estimated_ebit_low, Unset):
            estimated_ebit_low = UNSET
        else:
            estimated_ebit_low = self.estimated_ebit_low

        estimated_ebit_high: int | None | Unset
        if isinstance(self.estimated_ebit_high, Unset):
            estimated_ebit_high = UNSET
        else:
            estimated_ebit_high = self.estimated_ebit_high

        estimated_ebit_avg: int | None | Unset
        if isinstance(self.estimated_ebit_avg, Unset):
            estimated_ebit_avg = UNSET
        else:
            estimated_ebit_avg = self.estimated_ebit_avg

        estimated_net_income_low: int | None | Unset
        if isinstance(self.estimated_net_income_low, Unset):
            estimated_net_income_low = UNSET
        else:
            estimated_net_income_low = self.estimated_net_income_low

        estimated_net_income_high: int | None | Unset
        if isinstance(self.estimated_net_income_high, Unset):
            estimated_net_income_high = UNSET
        else:
            estimated_net_income_high = self.estimated_net_income_high

        estimated_net_income_avg: int | None | Unset
        if isinstance(self.estimated_net_income_avg, Unset):
            estimated_net_income_avg = UNSET
        else:
            estimated_net_income_avg = self.estimated_net_income_avg

        estimated_eps_avg: float | None | Unset
        if isinstance(self.estimated_eps_avg, Unset):
            estimated_eps_avg = UNSET
        else:
            estimated_eps_avg = self.estimated_eps_avg

        estimated_eps_high: float | None | Unset
        if isinstance(self.estimated_eps_high, Unset):
            estimated_eps_high = UNSET
        else:
            estimated_eps_high = self.estimated_eps_high

        estimated_eps_low: float | None | Unset
        if isinstance(self.estimated_eps_low, Unset):
            estimated_eps_low = UNSET
        else:
            estimated_eps_low = self.estimated_eps_low

        number_analyst_estimated_revenue: int | None | Unset
        if isinstance(self.number_analyst_estimated_revenue, Unset):
            number_analyst_estimated_revenue = UNSET
        else:
            number_analyst_estimated_revenue = self.number_analyst_estimated_revenue

        number_analysts_estimated_eps: int | None | Unset
        if isinstance(self.number_analysts_estimated_eps, Unset):
            number_analysts_estimated_eps = UNSET
        else:
            number_analysts_estimated_eps = self.number_analysts_estimated_eps

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "symbol": symbol,
                "date": date,
            }
        )
        if estimated_revenue_low is not UNSET:
            field_dict["estimated_revenue_low"] = estimated_revenue_low
        if estimated_revenue_high is not UNSET:
            field_dict["estimated_revenue_high"] = estimated_revenue_high
        if estimated_revenue_avg is not UNSET:
            field_dict["estimated_revenue_avg"] = estimated_revenue_avg
        if estimated_sga_expense_low is not UNSET:
            field_dict["estimated_sga_expense_low"] = estimated_sga_expense_low
        if estimated_sga_expense_high is not UNSET:
            field_dict["estimated_sga_expense_high"] = estimated_sga_expense_high
        if estimated_sga_expense_avg is not UNSET:
            field_dict["estimated_sga_expense_avg"] = estimated_sga_expense_avg
        if estimated_ebitda_low is not UNSET:
            field_dict["estimated_ebitda_low"] = estimated_ebitda_low
        if estimated_ebitda_high is not UNSET:
            field_dict["estimated_ebitda_high"] = estimated_ebitda_high
        if estimated_ebitda_avg is not UNSET:
            field_dict["estimated_ebitda_avg"] = estimated_ebitda_avg
        if estimated_ebit_low is not UNSET:
            field_dict["estimated_ebit_low"] = estimated_ebit_low
        if estimated_ebit_high is not UNSET:
            field_dict["estimated_ebit_high"] = estimated_ebit_high
        if estimated_ebit_avg is not UNSET:
            field_dict["estimated_ebit_avg"] = estimated_ebit_avg
        if estimated_net_income_low is not UNSET:
            field_dict["estimated_net_income_low"] = estimated_net_income_low
        if estimated_net_income_high is not UNSET:
            field_dict["estimated_net_income_high"] = estimated_net_income_high
        if estimated_net_income_avg is not UNSET:
            field_dict["estimated_net_income_avg"] = estimated_net_income_avg
        if estimated_eps_avg is not UNSET:
            field_dict["estimated_eps_avg"] = estimated_eps_avg
        if estimated_eps_high is not UNSET:
            field_dict["estimated_eps_high"] = estimated_eps_high
        if estimated_eps_low is not UNSET:
            field_dict["estimated_eps_low"] = estimated_eps_low
        if number_analyst_estimated_revenue is not UNSET:
            field_dict["number_analyst_estimated_revenue"] = number_analyst_estimated_revenue
        if number_analysts_estimated_eps is not UNSET:
            field_dict["number_analysts_estimated_eps"] = number_analysts_estimated_eps

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        symbol = d.pop("symbol")

        date = isoparse(d.pop("date")).date()

        def _parse_estimated_revenue_low(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_revenue_low = _parse_estimated_revenue_low(d.pop("estimated_revenue_low", UNSET))

        def _parse_estimated_revenue_high(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_revenue_high = _parse_estimated_revenue_high(d.pop("estimated_revenue_high", UNSET))

        def _parse_estimated_revenue_avg(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_revenue_avg = _parse_estimated_revenue_avg(d.pop("estimated_revenue_avg", UNSET))

        def _parse_estimated_sga_expense_low(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_sga_expense_low = _parse_estimated_sga_expense_low(d.pop("estimated_sga_expense_low", UNSET))

        def _parse_estimated_sga_expense_high(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_sga_expense_high = _parse_estimated_sga_expense_high(d.pop("estimated_sga_expense_high", UNSET))

        def _parse_estimated_sga_expense_avg(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_sga_expense_avg = _parse_estimated_sga_expense_avg(d.pop("estimated_sga_expense_avg", UNSET))

        def _parse_estimated_ebitda_low(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_ebitda_low = _parse_estimated_ebitda_low(d.pop("estimated_ebitda_low", UNSET))

        def _parse_estimated_ebitda_high(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_ebitda_high = _parse_estimated_ebitda_high(d.pop("estimated_ebitda_high", UNSET))

        def _parse_estimated_ebitda_avg(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_ebitda_avg = _parse_estimated_ebitda_avg(d.pop("estimated_ebitda_avg", UNSET))

        def _parse_estimated_ebit_low(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_ebit_low = _parse_estimated_ebit_low(d.pop("estimated_ebit_low", UNSET))

        def _parse_estimated_ebit_high(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_ebit_high = _parse_estimated_ebit_high(d.pop("estimated_ebit_high", UNSET))

        def _parse_estimated_ebit_avg(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_ebit_avg = _parse_estimated_ebit_avg(d.pop("estimated_ebit_avg", UNSET))

        def _parse_estimated_net_income_low(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_net_income_low = _parse_estimated_net_income_low(d.pop("estimated_net_income_low", UNSET))

        def _parse_estimated_net_income_high(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_net_income_high = _parse_estimated_net_income_high(d.pop("estimated_net_income_high", UNSET))

        def _parse_estimated_net_income_avg(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        estimated_net_income_avg = _parse_estimated_net_income_avg(d.pop("estimated_net_income_avg", UNSET))

        def _parse_estimated_eps_avg(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        estimated_eps_avg = _parse_estimated_eps_avg(d.pop("estimated_eps_avg", UNSET))

        def _parse_estimated_eps_high(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        estimated_eps_high = _parse_estimated_eps_high(d.pop("estimated_eps_high", UNSET))

        def _parse_estimated_eps_low(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        estimated_eps_low = _parse_estimated_eps_low(d.pop("estimated_eps_low", UNSET))

        def _parse_number_analyst_estimated_revenue(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        number_analyst_estimated_revenue = _parse_number_analyst_estimated_revenue(
            d.pop("number_analyst_estimated_revenue", UNSET)
        )

        def _parse_number_analysts_estimated_eps(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        number_analysts_estimated_eps = _parse_number_analysts_estimated_eps(
            d.pop("number_analysts_estimated_eps", UNSET)
        )

        fmp_analyst_estimates_data = cls(
            symbol=symbol,
            date=date,
            estimated_revenue_low=estimated_revenue_low,
            estimated_revenue_high=estimated_revenue_high,
            estimated_revenue_avg=estimated_revenue_avg,
            estimated_sga_expense_low=estimated_sga_expense_low,
            estimated_sga_expense_high=estimated_sga_expense_high,
            estimated_sga_expense_avg=estimated_sga_expense_avg,
            estimated_ebitda_low=estimated_ebitda_low,
            estimated_ebitda_high=estimated_ebitda_high,
            estimated_ebitda_avg=estimated_ebitda_avg,
            estimated_ebit_low=estimated_ebit_low,
            estimated_ebit_high=estimated_ebit_high,
            estimated_ebit_avg=estimated_ebit_avg,
            estimated_net_income_low=estimated_net_income_low,
            estimated_net_income_high=estimated_net_income_high,
            estimated_net_income_avg=estimated_net_income_avg,
            estimated_eps_avg=estimated_eps_avg,
            estimated_eps_high=estimated_eps_high,
            estimated_eps_low=estimated_eps_low,
            number_analyst_estimated_revenue=number_analyst_estimated_revenue,
            number_analysts_estimated_eps=number_analysts_estimated_eps,
        )

        fmp_analyst_estimates_data.additional_properties = d
        return fmp_analyst_estimates_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
