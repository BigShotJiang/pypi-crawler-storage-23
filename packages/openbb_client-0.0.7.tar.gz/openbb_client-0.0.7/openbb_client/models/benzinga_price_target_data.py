from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.benzinga_price_target_data_action_change_type_0 import BenzingaPriceTargetDataActionChangeType0
from ..models.benzinga_price_target_data_action_type_0 import BenzingaPriceTargetDataActionType0
from ..models.benzinga_price_target_data_importance_type_0 import BenzingaPriceTargetDataImportanceType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="BenzingaPriceTargetData")


@_attrs_define
class BenzingaPriceTargetData:
    """Benzinga Price Target Data.

    Attributes:
        published_date (datetime.date | datetime.datetime): Published date of the price target.
        symbol (str): Symbol representing the entity requested in the data.
        published_time (None | str | Unset): Time of the original rating, UTC.
        exchange (None | str | Unset): Exchange where the company is traded.
        company_name (None | str | Unset): Name of company that is the subject of rating.
        analyst_name (None | str | Unset): Analyst name.
        analyst_firm (None | str | Unset): Name of the analyst firm that published the price target.
        currency (None | str | Unset): Currency the data is denominated in.
        price_target (float | None | Unset): The current price target.
        adj_price_target (float | None | Unset): Adjusted price target for splits and stock dividends.
        price_target_previous (float | None | Unset): Previous price target.
        previous_adj_price_target (float | None | Unset): Previous adjusted price target.
        price_when_posted (float | None | Unset): Price when posted.
        rating_current (None | str | Unset): The analyst's rating for the company.
        rating_previous (None | str | Unset): Previous analyst rating for the company.
        action (BenzingaPriceTargetDataActionType0 | None | Unset): Description of the change in rating from firm's last
            rating.Note that all of these terms are precisely defined.
        action_change (BenzingaPriceTargetDataActionChangeType0 | None | Unset): Description of the change in price
            target from firm's last price target.
        importance (BenzingaPriceTargetDataImportanceType0 | None | Unset): Subjective Basis of How Important Event is
            to Market. 5 = High
        notes (None | str | Unset): Notes of the price target.
        analyst_id (None | str | Unset): Id of the analyst.
        url_news (None | str | Unset): URL for analyst ratings news articles for this ticker on Benzinga.com.
        url_analyst (None | str | Unset): URL for analyst ratings page for this ticker on Benzinga.com.
        id (None | str | Unset): Unique ID of this entry.
        last_updated (datetime.datetime | None | Unset): Last updated timestamp, UTC.
    """

    published_date: datetime.date | datetime.datetime
    symbol: str
    published_time: None | str | Unset = UNSET
    exchange: None | str | Unset = UNSET
    company_name: None | str | Unset = UNSET
    analyst_name: None | str | Unset = UNSET
    analyst_firm: None | str | Unset = UNSET
    currency: None | str | Unset = UNSET
    price_target: float | None | Unset = UNSET
    adj_price_target: float | None | Unset = UNSET
    price_target_previous: float | None | Unset = UNSET
    previous_adj_price_target: float | None | Unset = UNSET
    price_when_posted: float | None | Unset = UNSET
    rating_current: None | str | Unset = UNSET
    rating_previous: None | str | Unset = UNSET
    action: BenzingaPriceTargetDataActionType0 | None | Unset = UNSET
    action_change: BenzingaPriceTargetDataActionChangeType0 | None | Unset = UNSET
    importance: BenzingaPriceTargetDataImportanceType0 | None | Unset = UNSET
    notes: None | str | Unset = UNSET
    analyst_id: None | str | Unset = UNSET
    url_news: None | str | Unset = UNSET
    url_analyst: None | str | Unset = UNSET
    id: None | str | Unset = UNSET
    last_updated: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        published_date: str
        if isinstance(self.published_date, datetime.date):
            published_date = self.published_date.isoformat()
        else:
            published_date = self.published_date.isoformat()

        symbol = self.symbol

        published_time: None | str | Unset
        if isinstance(self.published_time, Unset):
            published_time = UNSET
        else:
            published_time = self.published_time

        exchange: None | str | Unset
        if isinstance(self.exchange, Unset):
            exchange = UNSET
        else:
            exchange = self.exchange

        company_name: None | str | Unset
        if isinstance(self.company_name, Unset):
            company_name = UNSET
        else:
            company_name = self.company_name

        analyst_name: None | str | Unset
        if isinstance(self.analyst_name, Unset):
            analyst_name = UNSET
        else:
            analyst_name = self.analyst_name

        analyst_firm: None | str | Unset
        if isinstance(self.analyst_firm, Unset):
            analyst_firm = UNSET
        else:
            analyst_firm = self.analyst_firm

        currency: None | str | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        price_target: float | None | Unset
        if isinstance(self.price_target, Unset):
            price_target = UNSET
        else:
            price_target = self.price_target

        adj_price_target: float | None | Unset
        if isinstance(self.adj_price_target, Unset):
            adj_price_target = UNSET
        else:
            adj_price_target = self.adj_price_target

        price_target_previous: float | None | Unset
        if isinstance(self.price_target_previous, Unset):
            price_target_previous = UNSET
        else:
            price_target_previous = self.price_target_previous

        previous_adj_price_target: float | None | Unset
        if isinstance(self.previous_adj_price_target, Unset):
            previous_adj_price_target = UNSET
        else:
            previous_adj_price_target = self.previous_adj_price_target

        price_when_posted: float | None | Unset
        if isinstance(self.price_when_posted, Unset):
            price_when_posted = UNSET
        else:
            price_when_posted = self.price_when_posted

        rating_current: None | str | Unset
        if isinstance(self.rating_current, Unset):
            rating_current = UNSET
        else:
            rating_current = self.rating_current

        rating_previous: None | str | Unset
        if isinstance(self.rating_previous, Unset):
            rating_previous = UNSET
        else:
            rating_previous = self.rating_previous

        action: None | str | Unset
        if isinstance(self.action, Unset):
            action = UNSET
        elif isinstance(self.action, BenzingaPriceTargetDataActionType0):
            action = self.action.value
        else:
            action = self.action

        action_change: None | str | Unset
        if isinstance(self.action_change, Unset):
            action_change = UNSET
        elif isinstance(self.action_change, BenzingaPriceTargetDataActionChangeType0):
            action_change = self.action_change.value
        else:
            action_change = self.action_change

        importance: int | None | Unset
        if isinstance(self.importance, Unset):
            importance = UNSET
        elif isinstance(self.importance, BenzingaPriceTargetDataImportanceType0):
            importance = self.importance.value
        else:
            importance = self.importance

        notes: None | str | Unset
        if isinstance(self.notes, Unset):
            notes = UNSET
        else:
            notes = self.notes

        analyst_id: None | str | Unset
        if isinstance(self.analyst_id, Unset):
            analyst_id = UNSET
        else:
            analyst_id = self.analyst_id

        url_news: None | str | Unset
        if isinstance(self.url_news, Unset):
            url_news = UNSET
        else:
            url_news = self.url_news

        url_analyst: None | str | Unset
        if isinstance(self.url_analyst, Unset):
            url_analyst = UNSET
        else:
            url_analyst = self.url_analyst

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        last_updated: None | str | Unset
        if isinstance(self.last_updated, Unset):
            last_updated = UNSET
        elif isinstance(self.last_updated, datetime.datetime):
            last_updated = self.last_updated.isoformat()
        else:
            last_updated = self.last_updated

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "published_date": published_date,
                "symbol": symbol,
            }
        )
        if published_time is not UNSET:
            field_dict["published_time"] = published_time
        if exchange is not UNSET:
            field_dict["exchange"] = exchange
        if company_name is not UNSET:
            field_dict["company_name"] = company_name
        if analyst_name is not UNSET:
            field_dict["analyst_name"] = analyst_name
        if analyst_firm is not UNSET:
            field_dict["analyst_firm"] = analyst_firm
        if currency is not UNSET:
            field_dict["currency"] = currency
        if price_target is not UNSET:
            field_dict["price_target"] = price_target
        if adj_price_target is not UNSET:
            field_dict["adj_price_target"] = adj_price_target
        if price_target_previous is not UNSET:
            field_dict["price_target_previous"] = price_target_previous
        if previous_adj_price_target is not UNSET:
            field_dict["previous_adj_price_target"] = previous_adj_price_target
        if price_when_posted is not UNSET:
            field_dict["price_when_posted"] = price_when_posted
        if rating_current is not UNSET:
            field_dict["rating_current"] = rating_current
        if rating_previous is not UNSET:
            field_dict["rating_previous"] = rating_previous
        if action is not UNSET:
            field_dict["action"] = action
        if action_change is not UNSET:
            field_dict["action_change"] = action_change
        if importance is not UNSET:
            field_dict["importance"] = importance
        if notes is not UNSET:
            field_dict["notes"] = notes
        if analyst_id is not UNSET:
            field_dict["analyst_id"] = analyst_id
        if url_news is not UNSET:
            field_dict["url_news"] = url_news
        if url_analyst is not UNSET:
            field_dict["url_analyst"] = url_analyst
        if id is not UNSET:
            field_dict["id"] = id
        if last_updated is not UNSET:
            field_dict["last_updated"] = last_updated

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_published_date(data: object) -> datetime.date | datetime.datetime:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                published_date_type_0 = isoparse(data).date()

                return published_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, str):
                raise TypeError()
            published_date_type_1 = isoparse(data)

            return published_date_type_1

        published_date = _parse_published_date(d.pop("published_date"))

        symbol = d.pop("symbol")

        def _parse_published_time(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        published_time = _parse_published_time(d.pop("published_time", UNSET))

        def _parse_exchange(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        exchange = _parse_exchange(d.pop("exchange", UNSET))

        def _parse_company_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        company_name = _parse_company_name(d.pop("company_name", UNSET))

        def _parse_analyst_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        analyst_name = _parse_analyst_name(d.pop("analyst_name", UNSET))

        def _parse_analyst_firm(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        analyst_firm = _parse_analyst_firm(d.pop("analyst_firm", UNSET))

        def _parse_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))

        def _parse_price_target(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        price_target = _parse_price_target(d.pop("price_target", UNSET))

        def _parse_adj_price_target(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        adj_price_target = _parse_adj_price_target(d.pop("adj_price_target", UNSET))

        def _parse_price_target_previous(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        price_target_previous = _parse_price_target_previous(d.pop("price_target_previous", UNSET))

        def _parse_previous_adj_price_target(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        previous_adj_price_target = _parse_previous_adj_price_target(d.pop("previous_adj_price_target", UNSET))

        def _parse_price_when_posted(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        price_when_posted = _parse_price_when_posted(d.pop("price_when_posted", UNSET))

        def _parse_rating_current(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        rating_current = _parse_rating_current(d.pop("rating_current", UNSET))

        def _parse_rating_previous(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        rating_previous = _parse_rating_previous(d.pop("rating_previous", UNSET))

        def _parse_action(data: object) -> BenzingaPriceTargetDataActionType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                action_type_0 = BenzingaPriceTargetDataActionType0(data)

                return action_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BenzingaPriceTargetDataActionType0 | None | Unset, data)

        action = _parse_action(d.pop("action", UNSET))

        def _parse_action_change(data: object) -> BenzingaPriceTargetDataActionChangeType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                action_change_type_0 = BenzingaPriceTargetDataActionChangeType0(data)

                return action_change_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BenzingaPriceTargetDataActionChangeType0 | None | Unset, data)

        action_change = _parse_action_change(d.pop("action_change", UNSET))

        def _parse_importance(data: object) -> BenzingaPriceTargetDataImportanceType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, int):
                    raise TypeError()
                importance_type_0 = BenzingaPriceTargetDataImportanceType0(data)

                return importance_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BenzingaPriceTargetDataImportanceType0 | None | Unset, data)

        importance = _parse_importance(d.pop("importance", UNSET))

        def _parse_notes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        notes = _parse_notes(d.pop("notes", UNSET))

        def _parse_analyst_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        analyst_id = _parse_analyst_id(d.pop("analyst_id", UNSET))

        def _parse_url_news(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url_news = _parse_url_news(d.pop("url_news", UNSET))

        def _parse_url_analyst(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url_analyst = _parse_url_analyst(d.pop("url_analyst", UNSET))

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_last_updated(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_updated_type_0 = isoparse(data)

                return last_updated_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_updated = _parse_last_updated(d.pop("last_updated", UNSET))

        benzinga_price_target_data = cls(
            published_date=published_date,
            symbol=symbol,
            published_time=published_time,
            exchange=exchange,
            company_name=company_name,
            analyst_name=analyst_name,
            analyst_firm=analyst_firm,
            currency=currency,
            price_target=price_target,
            adj_price_target=adj_price_target,
            price_target_previous=price_target_previous,
            previous_adj_price_target=previous_adj_price_target,
            price_when_posted=price_when_posted,
            rating_current=rating_current,
            rating_previous=rating_previous,
            action=action,
            action_change=action_change,
            importance=importance,
            notes=notes,
            analyst_id=analyst_id,
            url_news=url_news,
            url_analyst=url_analyst,
            id=id,
            last_updated=last_updated,
        )

        benzinga_price_target_data.additional_properties = d
        return benzinga_price_target_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
