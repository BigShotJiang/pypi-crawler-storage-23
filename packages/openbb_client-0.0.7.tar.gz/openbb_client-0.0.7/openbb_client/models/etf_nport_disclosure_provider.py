from enum import Enum


class EtfNportDisclosureProvider(str, Enum):
    FMP = "fmp"
    SEC = "sec"

    def __str__(self) -> str:
        return str(self.value)
