from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="EconDbEconomicIndicatorsData")


@_attrs_define
class EconDbEconomicIndicatorsData:
    """EconDB Economic Indicators Data.

    Attributes:
        date (datetime.date | None | Unset): The date of the data.
        symbol_root (None | str | Unset): The root symbol for the indicator (e.g. GDP).
        symbol (None | str | Unset): Symbol representing the entity requested in the data.
        country (None | str | Unset): The country represented by the data.
        value (float | int | None | Unset):
    """

    date: datetime.date | None | Unset = UNSET
    symbol_root: None | str | Unset = UNSET
    symbol: None | str | Unset = UNSET
    country: None | str | Unset = UNSET
    value: float | int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date: None | str | Unset
        if isinstance(self.date, Unset):
            date = UNSET
        elif isinstance(self.date, datetime.date):
            date = self.date.isoformat()
        else:
            date = self.date

        symbol_root: None | str | Unset
        if isinstance(self.symbol_root, Unset):
            symbol_root = UNSET
        else:
            symbol_root = self.symbol_root

        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        country: None | str | Unset
        if isinstance(self.country, Unset):
            country = UNSET
        else:
            country = self.country

        value: float | int | None | Unset
        if isinstance(self.value, Unset):
            value = UNSET
        else:
            value = self.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if date is not UNSET:
            field_dict["date"] = date
        if symbol_root is not UNSET:
            field_dict["symbol_root"] = symbol_root
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if country is not UNSET:
            field_dict["country"] = country
        if value is not UNSET:
            field_dict["value"] = value

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                date_type_0 = isoparse(data).date()

                return date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        date = _parse_date(d.pop("date", UNSET))

        def _parse_symbol_root(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol_root = _parse_symbol_root(d.pop("symbol_root", UNSET))

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_country(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        country = _parse_country(d.pop("country", UNSET))

        def _parse_value(data: object) -> float | int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | int | None | Unset, data)

        value = _parse_value(d.pop("value", UNSET))

        econ_db_economic_indicators_data = cls(
            date=date,
            symbol_root=symbol_root,
            symbol=symbol,
            country=country,
            value=value,
        )

        econ_db_economic_indicators_data.additional_properties = d
        return econ_db_economic_indicators_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
