from enum import Enum


class DerivativesOptionsSurfaceOptionTypeType0(str, Enum):
    CALLS = "calls"
    ITM = "itm"
    OTM = "otm"
    PUTS = "puts"

    def __str__(self) -> str:
        return str(self.value)
