from enum import Enum


class FixedincomeCorporateCommercialPaperCategoryType1(str, Enum):
    A2P2 = "a2p2"
    ALL = "all"
    ASSET_BACKED = "asset_backed"
    FINANCIAL = "financial"
    NONFINANCIAL = "nonfinancial"

    def __str__(self) -> str:
        return str(self.value)
