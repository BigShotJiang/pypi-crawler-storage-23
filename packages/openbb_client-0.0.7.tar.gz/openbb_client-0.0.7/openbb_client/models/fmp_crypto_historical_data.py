from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPCryptoHistoricalData")


@_attrs_define
class FMPCryptoHistoricalData:
    """FMP Crypto Historical Price Data.

    Attributes:
        date (datetime.date | datetime.datetime): The date of the data.
        close (float): The close price.
        open_ (float | None | Unset): The open price.
        high (float | None | Unset): The high price.
        low (float | None | Unset): The low price.
        volume (float | None | Unset): The trading volume.
        vwap (float | None | Unset): Volume Weighted Average Price over the period.
        change (float | None | Unset): Change in the price from the previous close.
        change_percent (float | None | Unset): Change in the price from the previous close, as a normalized percent.
    """

    date: datetime.date | datetime.datetime
    close: float
    open_: float | None | Unset = UNSET
    high: float | None | Unset = UNSET
    low: float | None | Unset = UNSET
    volume: float | None | Unset = UNSET
    vwap: float | None | Unset = UNSET
    change: float | None | Unset = UNSET
    change_percent: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date: str
        if isinstance(self.date, datetime.date):
            date = self.date.isoformat()
        else:
            date = self.date.isoformat()

        close = self.close

        open_: float | None | Unset
        if isinstance(self.open_, Unset):
            open_ = UNSET
        else:
            open_ = self.open_

        high: float | None | Unset
        if isinstance(self.high, Unset):
            high = UNSET
        else:
            high = self.high

        low: float | None | Unset
        if isinstance(self.low, Unset):
            low = UNSET
        else:
            low = self.low

        volume: float | None | Unset
        if isinstance(self.volume, Unset):
            volume = UNSET
        else:
            volume = self.volume

        vwap: float | None | Unset
        if isinstance(self.vwap, Unset):
            vwap = UNSET
        else:
            vwap = self.vwap

        change: float | None | Unset
        if isinstance(self.change, Unset):
            change = UNSET
        else:
            change = self.change

        change_percent: float | None | Unset
        if isinstance(self.change_percent, Unset):
            change_percent = UNSET
        else:
            change_percent = self.change_percent

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "close": close,
            }
        )
        if open_ is not UNSET:
            field_dict["open"] = open_
        if high is not UNSET:
            field_dict["high"] = high
        if low is not UNSET:
            field_dict["low"] = low
        if volume is not UNSET:
            field_dict["volume"] = volume
        if vwap is not UNSET:
            field_dict["vwap"] = vwap
        if change is not UNSET:
            field_dict["change"] = change
        if change_percent is not UNSET:
            field_dict["change_percent"] = change_percent

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_date(data: object) -> datetime.date | datetime.datetime:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                date_type_0 = isoparse(data).date()

                return date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, str):
                raise TypeError()
            date_type_1 = isoparse(data)

            return date_type_1

        date = _parse_date(d.pop("date"))

        close = d.pop("close")

        def _parse_open_(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        open_ = _parse_open_(d.pop("open", UNSET))

        def _parse_high(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        high = _parse_high(d.pop("high", UNSET))

        def _parse_low(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        low = _parse_low(d.pop("low", UNSET))

        def _parse_volume(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        volume = _parse_volume(d.pop("volume", UNSET))

        def _parse_vwap(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        vwap = _parse_vwap(d.pop("vwap", UNSET))

        def _parse_change(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change = _parse_change(d.pop("change", UNSET))

        def _parse_change_percent(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_percent = _parse_change_percent(d.pop("change_percent", UNSET))

        fmp_crypto_historical_data = cls(
            date=date,
            close=close,
            open_=open_,
            high=high,
            low=low,
            volume=volume,
            vwap=vwap,
            change=change,
            change_percent=change_percent,
        )

        fmp_crypto_historical_data.additional_properties = d
        return fmp_crypto_historical_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
