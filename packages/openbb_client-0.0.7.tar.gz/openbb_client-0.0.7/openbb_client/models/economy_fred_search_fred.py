from enum import Enum


class EconomyFredSearchFred(str, Enum):
    FULL_TEXT = "full_text"
    RELEASE = "release"
    SERIES_ID = "series_id"

    def __str__(self) -> str:
        return str(self.value)
