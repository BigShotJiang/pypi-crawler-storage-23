from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FederalReserveFederalFundsRateData")


@_attrs_define
class FederalReserveFederalFundsRateData:
    """FederalReserve FED Data.

    Attributes:
        date (datetime.date): The date of the data.
        rate (float): Effective federal funds rate.
        target_range_upper (float | None | Unset): Upper bound of the target range.
        target_range_lower (float | None | Unset): Lower bound of the target range.
        percentile_1 (float | None | Unset): 1st percentile of the distribution.
        percentile_25 (float | None | Unset): 25th percentile of the distribution.
        percentile_75 (float | None | Unset): 75th percentile of the distribution.
        percentile_99 (float | None | Unset): 99th percentile of the distribution.
        volume (float | None | Unset): The trading volume.The notional volume of transactions (Billions of $).
        intraday_low (float | None | Unset): Intraday low. This field is only present for data before 2016.
        intraday_high (float | None | Unset): Intraday high. This field is only present for data before 2016.
        standard_deviation (float | None | Unset): Standard deviation. This field is only present for data before 2016.
        revision_indicator (None | str | Unset): Indicates a revision of the data for that date.
    """

    date: datetime.date
    rate: float
    target_range_upper: float | None | Unset = UNSET
    target_range_lower: float | None | Unset = UNSET
    percentile_1: float | None | Unset = UNSET
    percentile_25: float | None | Unset = UNSET
    percentile_75: float | None | Unset = UNSET
    percentile_99: float | None | Unset = UNSET
    volume: float | None | Unset = UNSET
    intraday_low: float | None | Unset = UNSET
    intraday_high: float | None | Unset = UNSET
    standard_deviation: float | None | Unset = UNSET
    revision_indicator: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        rate = self.rate

        target_range_upper: float | None | Unset
        if isinstance(self.target_range_upper, Unset):
            target_range_upper = UNSET
        else:
            target_range_upper = self.target_range_upper

        target_range_lower: float | None | Unset
        if isinstance(self.target_range_lower, Unset):
            target_range_lower = UNSET
        else:
            target_range_lower = self.target_range_lower

        percentile_1: float | None | Unset
        if isinstance(self.percentile_1, Unset):
            percentile_1 = UNSET
        else:
            percentile_1 = self.percentile_1

        percentile_25: float | None | Unset
        if isinstance(self.percentile_25, Unset):
            percentile_25 = UNSET
        else:
            percentile_25 = self.percentile_25

        percentile_75: float | None | Unset
        if isinstance(self.percentile_75, Unset):
            percentile_75 = UNSET
        else:
            percentile_75 = self.percentile_75

        percentile_99: float | None | Unset
        if isinstance(self.percentile_99, Unset):
            percentile_99 = UNSET
        else:
            percentile_99 = self.percentile_99

        volume: float | None | Unset
        if isinstance(self.volume, Unset):
            volume = UNSET
        else:
            volume = self.volume

        intraday_low: float | None | Unset
        if isinstance(self.intraday_low, Unset):
            intraday_low = UNSET
        else:
            intraday_low = self.intraday_low

        intraday_high: float | None | Unset
        if isinstance(self.intraday_high, Unset):
            intraday_high = UNSET
        else:
            intraday_high = self.intraday_high

        standard_deviation: float | None | Unset
        if isinstance(self.standard_deviation, Unset):
            standard_deviation = UNSET
        else:
            standard_deviation = self.standard_deviation

        revision_indicator: None | str | Unset
        if isinstance(self.revision_indicator, Unset):
            revision_indicator = UNSET
        else:
            revision_indicator = self.revision_indicator

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "rate": rate,
            }
        )
        if target_range_upper is not UNSET:
            field_dict["target_range_upper"] = target_range_upper
        if target_range_lower is not UNSET:
            field_dict["target_range_lower"] = target_range_lower
        if percentile_1 is not UNSET:
            field_dict["percentile_1"] = percentile_1
        if percentile_25 is not UNSET:
            field_dict["percentile_25"] = percentile_25
        if percentile_75 is not UNSET:
            field_dict["percentile_75"] = percentile_75
        if percentile_99 is not UNSET:
            field_dict["percentile_99"] = percentile_99
        if volume is not UNSET:
            field_dict["volume"] = volume
        if intraday_low is not UNSET:
            field_dict["intraday_low"] = intraday_low
        if intraday_high is not UNSET:
            field_dict["intraday_high"] = intraday_high
        if standard_deviation is not UNSET:
            field_dict["standard_deviation"] = standard_deviation
        if revision_indicator is not UNSET:
            field_dict["revision_indicator"] = revision_indicator

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        rate = d.pop("rate")

        def _parse_target_range_upper(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        target_range_upper = _parse_target_range_upper(d.pop("target_range_upper", UNSET))

        def _parse_target_range_lower(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        target_range_lower = _parse_target_range_lower(d.pop("target_range_lower", UNSET))

        def _parse_percentile_1(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentile_1 = _parse_percentile_1(d.pop("percentile_1", UNSET))

        def _parse_percentile_25(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentile_25 = _parse_percentile_25(d.pop("percentile_25", UNSET))

        def _parse_percentile_75(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentile_75 = _parse_percentile_75(d.pop("percentile_75", UNSET))

        def _parse_percentile_99(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentile_99 = _parse_percentile_99(d.pop("percentile_99", UNSET))

        def _parse_volume(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        volume = _parse_volume(d.pop("volume", UNSET))

        def _parse_intraday_low(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        intraday_low = _parse_intraday_low(d.pop("intraday_low", UNSET))

        def _parse_intraday_high(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        intraday_high = _parse_intraday_high(d.pop("intraday_high", UNSET))

        def _parse_standard_deviation(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        standard_deviation = _parse_standard_deviation(d.pop("standard_deviation", UNSET))

        def _parse_revision_indicator(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        revision_indicator = _parse_revision_indicator(d.pop("revision_indicator", UNSET))

        federal_reserve_federal_funds_rate_data = cls(
            date=date,
            rate=rate,
            target_range_upper=target_range_upper,
            target_range_lower=target_range_lower,
            percentile_1=percentile_1,
            percentile_25=percentile_25,
            percentile_75=percentile_75,
            percentile_99=percentile_99,
            volume=volume,
            intraday_low=intraday_low,
            intraday_high=intraday_high,
            standard_deviation=standard_deviation,
            revision_indicator=revision_indicator,
        )

        federal_reserve_federal_funds_rate_data.additional_properties = d
        return federal_reserve_federal_funds_rate_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
