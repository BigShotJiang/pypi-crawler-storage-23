from enum import Enum


class EconomySurveyManufacturingOutlookNyTopicType0(str, Enum):
    BUSINESS_OUTLOOK = "business_outlook"
    CAPEX = "capex"
    DELIVERY_TIMES = "delivery_times"
    EMPLOYMENT = "employment"
    HOURS_WORKED = "hours_worked"
    INVENTORIES = "inventories"
    NEW_ORDERS = "new_orders"
    PRICES_PAID = "prices_paid"
    PRICES_RECEIVED = "prices_received"
    SHIPMENTS = "shipments"
    UNFILLED_ORDERS = "unfilled_orders"

    def __str__(self) -> str:
        return str(self.value)
