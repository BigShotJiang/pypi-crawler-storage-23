from enum import Enum


class EquityPriceQuoteIntrinio(str, Enum):
    BATS = "bats"
    BATS_DELAYED = "bats_delayed"
    CTA_A_DELAYED = "cta_a_delayed"
    CTA_B_DELAYED = "cta_b_delayed"
    DELAYED_SIP = "delayed_sip"
    IEX = "iex"
    INTRINIO_MX = "intrinio_mx"
    INTRINIO_MX_PLUS = "intrinio_mx_plus"
    UTP_DELAYED = "utp_delayed"

    def __str__(self) -> str:
        return str(self.value)
