from enum import Enum


class FixedincomeRateOvernightBankFundingProvider(str, Enum):
    FEDERAL_RESERVE = "federal_reserve"
    FRED = "fred"

    def __str__(self) -> str:
        return str(self.value)
