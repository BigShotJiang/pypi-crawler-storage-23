from enum import Enum


class CurrencyPriceHistoricalIntervalType0(str, Enum):
    VALUE_0 = "1m"
    VALUE_1 = "5m"
    VALUE_2 = "15m"
    VALUE_3 = "30m"
    VALUE_4 = "1h"
    VALUE_5 = "4h"
    VALUE_6 = "1d"

    def __str__(self) -> str:
        return str(self.value)
