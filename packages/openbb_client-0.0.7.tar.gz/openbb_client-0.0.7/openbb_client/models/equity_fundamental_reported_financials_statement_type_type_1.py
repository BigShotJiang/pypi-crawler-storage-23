from enum import Enum


class EquityFundamentalReportedFinancialsStatementTypeType1(str, Enum):
    BALANCE = "balance"
    CASH = "cash"
    INCOME = "income"

    def __str__(self) -> str:
        return str(self.value)
