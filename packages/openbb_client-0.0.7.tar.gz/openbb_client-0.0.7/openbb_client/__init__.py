"""A client library for accessing OpenBB Platform API"""

from .client import AuthenticatedClient, Client
from .skills import (
    OpenBBConfig,
    OpenBBAPIClient,
    MarketDataService,
    StockPriceService,
    FinancialMetricsService,
    FinancialAnalysisService,
    StockPrice,
    QuoteData,
    FinancialMetrics,
    TechnicalIndicator,
)

__all__ = (
    "AuthenticatedClient",
    "Client",
    "OpenBBConfig",
    "OpenBBAPIClient",
    "MarketDataService",
    "StockPriceService",
    "FinancialMetricsService",
    "FinancialAnalysisService",
    "StockPrice",
    "QuoteData",
    "FinancialMetrics",
    "TechnicalIndicator",
)
