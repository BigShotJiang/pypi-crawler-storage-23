"""
mkdocs-superquiz plugin
A MkDocs plugin to create interactive quizzes
"""

__version__ = "0.1.0"