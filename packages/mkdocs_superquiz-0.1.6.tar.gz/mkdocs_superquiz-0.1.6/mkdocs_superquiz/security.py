"""
Module de sécurité pour mkdocs-superquiz
"""

import hashlib
import base64
import json


def prepare_teacher_code_hash(teacher_code):
    """
    Prépare le hash du code enseignant
    
    Args:
        teacher_code: Code enseignant (peut être déjà un hash avec préfixe "sha256:")
    
    Returns:
        Hash SHA256 du code
    """
    # Si le code commence par "sha256:", c'est déjà un hash
    if teacher_code.startswith("sha256:"):
        return teacher_code.replace("sha256:", "")
    
    # Sinon, hasher le code
    return hashlib.sha256(teacher_code.encode()).hexdigest()


def generate_unlock_code(teacher_code, page_uuid, unlock_type, exercise_id=None, question_id=None):
    """
    Génère un code de déblocage
    
    Args:
        teacher_code: Code enseignant (hash SHA256)
        page_uuid: UUID de la page
        unlock_type: Type de déblocage ("page", "exercise", "question")
        exercise_id: ID de l'exercice (optionnel)
        question_id: ID de la question (optionnel)
    
    Returns:
        Code de déblocage (8 premiers caractères du hash)
    """
    # Construire le payload
    payload = teacher_code + page_uuid + unlock_type
    
    if unlock_type in ['exercise', 'question'] and exercise_id:
        payload += exercise_id
    
    if unlock_type == 'question' and question_id:
        payload += str(question_id)
    
    # Hasher
    code_hash = hashlib.sha256(payload.encode()).hexdigest()
    
    # Retourner les 8 premiers caractères en majuscules
    return code_hash[:8].upper()


def encrypt_answers(data, encryption_key):
    """
    Chiffre les données de correction avec XOR simple
    
    Args:
        data: Dictionnaire contenant les données de correction
        encryption_key: Clé de chiffrement
    
    Returns:
        Données chiffrées en base64
    """
    # Convertir en JSON
    json_data = json.dumps(data)
    
    # Encoder en bytes
    data_bytes = json_data.encode('utf-8')
    key_bytes = encryption_key.encode('utf-8')
    
    # XOR avec la clé
    encrypted_bytes = bytearray()
    for i in range(len(data_bytes)):
        encrypted_bytes.append(data_bytes[i] ^ key_bytes[i % len(key_bytes)])
    
    # Encoder en base64
    encrypted_b64 = base64.b64encode(encrypted_bytes).decode('utf-8')
    
    return encrypted_b64


def decrypt_answers(encrypted_data, encryption_key):
    """
    Déchiffre les données de correction
    
    Args:
        encrypted_data: Données chiffrées en base64
        encryption_key: Clé de chiffrement
    
    Returns:
        Dictionnaire des données déchiffrées
    """
    try:
        # Décoder base64
        encrypted_bytes = base64.b64decode(encrypted_data)
        key_bytes = encryption_key.encode('utf-8')
        
        # XOR avec la clé
        decrypted_bytes = bytearray()
        for i in range(len(encrypted_bytes)):
            decrypted_bytes.append(encrypted_bytes[i] ^ key_bytes[i % len(key_bytes)])
        
        # Décoder en string puis JSON
        json_data = decrypted_bytes.decode('utf-8')
        data = json.loads(json_data)
        
        return data
    
    except Exception as e:
        print(f"Erreur de déchiffrement: {e}")
        return None


def obfuscate_data(data):
    """
    Obfusque les données (alias pour encrypt_answers)
    
    Args:
        data: Données à obfusquer
    
    Returns:
        Données obfusquées
    """
    # Utiliser une clé par défaut pour l'obfuscation
    default_key = "mkdocs-superquiz-obfuscation-key"
    return encrypt_answers(data, default_key)