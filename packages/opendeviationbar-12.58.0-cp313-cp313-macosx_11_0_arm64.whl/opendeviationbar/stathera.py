# Issue #158: Stathera trade-ID alignment paradigm
"""Stathera: Trade-ID alignment cleanup for overlapping bars.

Identifies overlap chains where bars from different processing sources
(sidecar, recency-backfill, kintsugi) share aggTrade ID ranges, selects
canonical bars, and deletes redundant ones.

Usage:
    >>> from opendeviationbar.stathera import stathera_cleanup
    >>> deleted = stathera_cleanup(dry_run=True)  # preview
    >>> deleted = stathera_cleanup(dry_run=False)  # execute
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class OverlapBar:
    """A bar participating in an overlap chain."""

    close_time_ms: int
    first_agg_trade_id: int
    last_agg_trade_id: int
    computed_at: str  # ISO timestamp from ClickHouse
    opendeviationbar_version: str


@dataclass
class OverlapChain:
    """A set of bars with overlapping trade-ID ranges."""

    symbol: str
    threshold_decimal_bps: int
    bars: list[OverlapBar] = field(default_factory=list)
    canonical: list[OverlapBar] = field(default_factory=list)
    redundant: list[OverlapBar] = field(default_factory=list)


def identify_overlap_chains(
    symbol: str,
    threshold_decimal_bps: int,
    ouroboros_mode: str | None = None,  # SSoT-OK: resolved from config
) -> list[OverlapChain]:
    """Find overlap chains for a (symbol, threshold) pair.

    Walks bars ordered by first_agg_trade_id. When bar[n+1].first_tid <=
    bar[n].last_tid, they belong to the same chain.
    """
    from opendeviationbar.clickhouse import OpenDeviationBarCache
    from opendeviationbar.ouroboros import get_operational_ouroboros_mode

    if ouroboros_mode is None:
        ouroboros_mode = get_operational_ouroboros_mode()

    with OpenDeviationBarCache() as cache:
        result = cache.client.query(
            """
            SELECT close_time_ms, first_agg_trade_id, last_agg_trade_id,
                   toString(computed_at) AS computed_at_str,
                   opendeviationbar_version
            FROM opendeviationbar_cache.open_deviation_bars FINAL
            WHERE symbol = {symbol:String}
              AND threshold_decimal_bps = {threshold:UInt32}
              AND ouroboros_mode = {ouroboros:String}
              AND first_agg_trade_id > 0
              AND last_agg_trade_id > 0
            ORDER BY first_agg_trade_id, close_time_ms
            """,
            parameters={
                "symbol": symbol,
                "threshold": threshold_decimal_bps,
                "ouroboros": ouroboros_mode,
            },
        )

    bars = [
        OverlapBar(
            close_time_ms=row[0],
            first_agg_trade_id=row[1],
            last_agg_trade_id=row[2],
            computed_at=row[3],
            opendeviationbar_version=row[4] or "",
        )
        for row in result.result_rows
    ]

    if not bars:
        return []

    chains: list[OverlapChain] = []
    current_chain: list[OverlapBar] = [bars[0]]

    for bar in bars[1:]:
        prev = current_chain[-1]
        if bar.first_agg_trade_id <= prev.last_agg_trade_id:
            # Overlapping — extend chain
            current_chain.append(bar)
        else:
            # Non-overlapping — flush chain if it has overlaps
            if len(current_chain) > 1:
                chain = OverlapChain(
                    symbol=symbol,
                    threshold_decimal_bps=threshold_decimal_bps,
                    bars=list(current_chain),
                )
                _select_canonical(chain)
                chains.append(chain)
            current_chain = [bar]

    # Flush last chain
    if len(current_chain) > 1:
        chain = OverlapChain(
            symbol=symbol,
            threshold_decimal_bps=threshold_decimal_bps,
            bars=list(current_chain),
        )
        _select_canonical(chain)
        chains.append(chain)

    return chains


def _select_canonical(chain: OverlapChain) -> None:
    """Select canonical bars from an overlap chain using greedy cover.

    Prefer bars with the most recent computed_at (most recent computation wins).
    Build a greedy non-overlapping cover of the TID range.
    """
    # Sort by computed_at descending (newest first), then by first_tid
    sorted_bars = sorted(
        chain.bars,
        key=lambda b: (b.computed_at, b.first_agg_trade_id),
        reverse=True,
    )

    # Greedy cover: pick bars that don't overlap already-selected bars
    selected: list[OverlapBar] = []
    covered_ranges: list[tuple[int, int]] = []

    for bar in sorted_bars:
        overlaps_existing = any(
            bar.first_agg_trade_id <= end and bar.last_agg_trade_id >= start
            for start, end in covered_ranges
        )
        if not overlaps_existing:
            selected.append(bar)
            covered_ranges.append(
                (bar.first_agg_trade_id, bar.last_agg_trade_id)
            )

    canonical_set = {id(b) for b in selected}
    chain.canonical = selected
    chain.redundant = [b for b in chain.bars if id(b) not in canonical_set]


def stathera_cleanup(
    *,
    symbol: str | None = None,
    threshold: int | None = None,
    dry_run: bool = True,
    ouroboros_mode: str | None = None,  # SSoT-OK: resolved from config
) -> int:
    """Run Stathera cleanup: identify overlapping bars, delete redundant ones.

    When ouroboros_mode is None, iterates ALL ouroboros modes found in ClickHouse
    (matches what the heartbeat checks). Pass an explicit mode to restrict.

    Returns number of bars deleted (0 in dry_run mode).
    """
    from opendeviationbar.clickhouse import OpenDeviationBarCache

    # Discover all ouroboros modes if none specified
    if ouroboros_mode is not None:
        modes = [ouroboros_mode]
    else:
        with OpenDeviationBarCache() as cache:
            result = cache.client.query(
                "SELECT DISTINCT ouroboros_mode "
                "FROM opendeviationbar_cache.open_deviation_bars "
                "WHERE first_agg_trade_id > 0"
            )
            modes = [row[0] for row in result.result_rows]
        logger.info("Cleaning all ouroboros modes: %s", modes)

    total_deleted = 0
    total_chains = 0

    for mode in modes:
        deleted, chains = _cleanup_mode(
            mode,
            symbol=symbol,
            threshold=threshold,
            dry_run=dry_run,
        )
        total_deleted += deleted
        total_chains += chains

    logger.info(
        "Stathera cleanup %s: %d chains, %d bars deleted",
        "dry-run" if dry_run else "complete",
        total_chains,
        total_deleted,
    )

    return total_deleted


_MAX_CONVERGENCE_PASSES = 20


def _cleanup_mode(
    ouroboros_mode: str,
    *,
    symbol: str | None = None,
    threshold: int | None = None,
    dry_run: bool = True,
) -> tuple[int, int]:
    """Clean overlaps for a single ouroboros mode. Returns (deleted, chain_count).

    When not dry_run, loops until no overlaps remain (the greedy canonical
    selection may require multiple passes to fully resolve complex chains).
    """
    mode_deleted = 0
    mode_chains = 0

    for pass_num in range(1, _MAX_CONVERGENCE_PASSES + 1):
        deleted, chains = _cleanup_pass(
            ouroboros_mode,
            symbol=symbol,
            threshold=threshold,
            dry_run=dry_run,
        )
        mode_deleted += deleted
        mode_chains += chains

        # Dry-run: single pass (report only)
        # Apply: stop when no more redundant bars found
        if dry_run or deleted == 0:
            break

        if pass_num > 1:
            logger.info("Convergence pass %d: deleted %d more bars", pass_num, deleted)

    if not dry_run and pass_num > 1 and mode_deleted > 0:
        logger.info(
            "Converged after %d passes (%d total bars deleted)",
            pass_num,
            mode_deleted,
        )

    return mode_deleted, mode_chains


def _cleanup_pass(
    ouroboros_mode: str,
    *,
    symbol: str | None = None,
    threshold: int | None = None,
    dry_run: bool = True,
) -> tuple[int, int]:
    """Single cleanup pass. Returns (deleted, chain_count)."""
    from opendeviationbar.clickhouse import OpenDeviationBarCache

    # Discover pairs
    with OpenDeviationBarCache() as cache:
        if symbol and threshold:
            pairs = [(symbol, threshold)]
        else:
            result = cache.client.query(
                """
                SELECT DISTINCT symbol, threshold_decimal_bps
                FROM opendeviationbar_cache.open_deviation_bars
                WHERE first_agg_trade_id > 0
                ORDER BY symbol, threshold_decimal_bps
                """
            )
            pairs = [(row[0], row[1]) for row in result.result_rows]
            if symbol:
                pairs = [(s, t) for s, t in pairs if s == symbol]
            if threshold:
                pairs = [(s, t) for s, t in pairs if t == threshold]

    pass_deleted = 0
    pass_chains = 0

    for sym, thr in pairs:
        chains = identify_overlap_chains(sym, thr, ouroboros_mode=ouroboros_mode)
        if not chains:
            continue

        pass_chains += len(chains)
        redundant_count = sum(len(c.redundant) for c in chains)

        logger.info(
            "%s@%d (%s): %d overlap chain(s), %d redundant bar(s)",
            sym,
            thr,
            ouroboros_mode,
            len(chains),
            redundant_count,
        )

        if dry_run:
            for chain in chains:
                logger.info(
                    "  chain: %d bars, %d canonical, %d redundant "
                    "(tid range %d-%d)",
                    len(chain.bars),
                    len(chain.canonical),
                    len(chain.redundant),
                    min(b.first_agg_trade_id for b in chain.bars),
                    max(b.last_agg_trade_id for b in chain.bars),
                )
            continue

        # Execute deletion
        deleted = _delete_redundant_bars(
            sym, thr, chains, ouroboros_mode=ouroboros_mode
        )
        pass_deleted += deleted

    return pass_deleted, pass_chains


def _delete_redundant_bars(
    symbol: str,
    threshold: int,
    chains: list[OverlapChain],
    ouroboros_mode: str | None = None,  # SSoT-OK: resolved from config
) -> int:
    """Delete redundant bars from overlap chains."""
    from opendeviationbar.clickhouse import OpenDeviationBarCache

    all_redundant = []
    for chain in chains:
        for bar in chain.redundant:
            all_redundant.append(
                (bar.close_time_ms, bar.first_agg_trade_id, bar.last_agg_trade_id)
            )

    if not all_redundant:
        return 0

    with OpenDeviationBarCache() as cache:
        cache.delete_bars_by_identity(
            symbol, threshold, all_redundant, ouroboros_mode=ouroboros_mode,
            timeout=60,  # Issue #175: shorter per-pair timeout
        )

    return len(all_redundant)


