"""Allow running as `python -m appstore_cli`."""
from appstore_cli.cli import cli

cli()
