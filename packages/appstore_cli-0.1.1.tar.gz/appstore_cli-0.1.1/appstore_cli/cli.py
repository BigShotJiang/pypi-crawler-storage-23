"""App Store Connect CLI — manage builds, TestFlight, and submissions."""

from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path

import click
import jwt
import requests
from dotenv import load_dotenv

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

CONFIG_DIR = Path.home() / ".config" / "appstore"
ACTIVE_FILE = CONFIG_DIR / "active"
API_HOST = "https://api.appstoreconnect.apple.com"
BASE_URL = f"{API_HOST}/v1"



def _profile_path(name: str) -> Path:
    return CONFIG_DIR / f"{name}.env"


def _active_profile() -> str:
    if ACTIVE_FILE.exists():
        return ACTIVE_FILE.read_text().strip()
    return "default"


def load_config(profile: str | None = None):
    """Load credentials from env vars or a named profile."""
    # Env vars always take priority
    if all(os.getenv(k) for k in ("ASC_KEY_ID", "ASC_ISSUER_ID", "ASC_KEY_PATH")):
        key_id = os.getenv("ASC_KEY_ID")
        issuer_id = os.getenv("ASC_ISSUER_ID")
        key_path = os.getenv("ASC_KEY_PATH")
    else:
        name = profile or _active_profile()
        env_file = _profile_path(name)
        if not env_file.exists():
            click.echo(
                f"Error: Profile '{name}' not found. Run 'appstore auth setup' or "
                f"'appstore auth setup --profile {name}' to create it.",
                err=True,
            )
            sys.exit(1)
        load_dotenv(env_file, override=True)
        key_id = os.getenv("ASC_KEY_ID")
        issuer_id = os.getenv("ASC_ISSUER_ID")
        key_path = os.getenv("ASC_KEY_PATH")
    if not all([key_id, issuer_id, key_path]):
        click.echo(
            "Error: Incomplete credentials. Run 'appstore auth setup' to configure.",
            err=True,
        )
        sys.exit(1)
    key_path = os.path.expanduser(key_path)
    if not os.path.exists(key_path):
        click.echo(f"Error: Key file not found: {key_path}", err=True)
        sys.exit(1)
    return key_id, issuer_id, key_path


# ---------------------------------------------------------------------------
# JWT
# ---------------------------------------------------------------------------


def generate_token(key_id: str, issuer_id: str, key_path: str) -> str:
    with open(key_path, "r") as f:
        private_key = f.read()
    payload = {
        "iss": issuer_id,
        "iat": int(time.time()),
        "exp": int(time.time()) + 1200,
        "aud": "appstoreconnect-v1",
    }
    return jwt.encode(
        payload, private_key, algorithm="ES256", headers={"kid": key_id}
    )


# ---------------------------------------------------------------------------
# API Client
# ---------------------------------------------------------------------------


class ASCClient:
    def __init__(self, profile: str | None = None):
        key_id, issuer_id, key_path = load_config(profile)
        self.token = generate_token(key_id, issuer_id, key_path)
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }

    def _url(self, path: str) -> str:
        if path.startswith("http"):
            return path
        # Paths starting with v1/, v2/, etc. are fully versioned (from manifest)
        stripped = path.lstrip("/")
        if re.match(r"v\d+/", stripped):
            return f"{API_HOST}/{stripped}"
        return f"{BASE_URL}/{stripped}"

    def _request(self, method: str, url: str, **kwargs) -> requests.Response:
        """Send an HTTP request with automatic retry on 429 rate limiting."""
        max_retries = 3
        for attempt in range(max_retries + 1):
            resp = requests.request(method, url, headers=self.headers, **kwargs)
            if resp.status_code != 429 or attempt == max_retries:
                return resp
            retry_after = int(resp.headers.get("Retry-After", 2 ** attempt))
            click.echo(f"Rate limited, retrying in {retry_after}s...", err=True)
            time.sleep(retry_after)
        return resp  # unreachable, but satisfies type checkers

    def _handle_response(self, resp: requests.Response) -> dict:
        if resp.status_code == 204:
            return {}
        content_type = resp.headers.get("Content-Type", "")
        if "json" not in content_type and resp.ok:
            # Non-JSON response (gzip reports, CSV exports, etc.)
            return {"_raw": True, "_content": resp.content, "_content_type": content_type}
        try:
            body = resp.json()
        except ValueError:
            if not resp.ok:
                click.echo(f"Error {resp.status_code}: {resp.text}", err=True)
                sys.exit(1)
            return {}
        if not resp.ok:
            errors = body.get("errors", [])
            for err in errors:
                detail = err.get("detail", err.get("title", "Unknown error"))
                click.echo(f"Error {err.get('status', resp.status_code)}: {detail}", err=True)
            if not errors:
                click.echo(f"Error {resp.status_code}: {resp.text}", err=True)
            sys.exit(1)
        return body

    def get(self, path: str, params: dict | None = None) -> dict:
        resp = self._request("GET", self._url(path), params=params)
        return self._handle_response(resp)

    def get_all(self, path: str, params: dict | None = None) -> list:
        """GET with automatic pagination. Returns all data items."""
        items = []
        url = self._url(path)
        while url:
            resp = self._request("GET", url, params=params)
            body = self._handle_response(resp)
            items.extend(body.get("data", []))
            url = body.get("links", {}).get("next")
            params = None  # params already encoded in next URL
        return items

    def post(self, path: str, data: dict) -> dict:
        resp = self._request("POST", self._url(path), json=data)
        return self._handle_response(resp)

    def patch(self, path: str, data: dict) -> dict:
        resp = self._request("PATCH", self._url(path), json=data)
        return self._handle_response(resp)

    def delete(self, path: str, data: dict | None = None) -> dict:
        kwargs = {}
        if data is not None:
            kwargs["json"] = data
        resp = self._request("DELETE", self._url(path), **kwargs)
        return self._handle_response(resp)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def print_table(headers: list[str], rows: list[list[str]]):
    """Print a simple aligned table."""
    if not rows:
        click.echo("No results.")
        return
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))
    header_line = "  ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
    click.echo(header_line)
    click.echo("  ".join("-" * w for w in col_widths))
    for row in rows:
        click.echo("  ".join(str(cell).ljust(col_widths[i]) for i, cell in enumerate(row)))


def output(ctx: click.Context, data, formatter):
    """Print raw JSON or formatted output depending on --json flag."""
    if isinstance(data, dict) and data.get("_raw"):
        # Non-JSON response — write binary content to stdout
        sys.stdout.buffer.write(data["_content"])
        return
    if ctx.obj.get("json_output"):
        click.echo(json.dumps(data, indent=2))
    else:
        formatter(data)



# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


@click.group()
@click.option("--json", "json_output", is_flag=True, help="Output raw JSON")
@click.option("--profile", "profile", default=None, help="Auth profile to use")
@click.pass_context
def cli(ctx, json_output, profile):
    """App Store Connect CLI."""
    ctx.ensure_object(dict)
    ctx.obj["json_output"] = json_output
    ctx.obj["profile"] = profile


# -- auth ------------------------------------------------------------------


@cli.group()
def auth():
    """Manage API credentials and profiles."""


@auth.command("setup")
@click.option("--profile", "profile_name", default=None, help="Profile name (default: 'default')")
def auth_setup(profile_name):
    """Configure App Store Connect API credentials interactively."""

    name = profile_name or "default"

    click.echo("App Store Connect API credentials setup")
    click.echo("Generate a key at: https://appstoreconnect.apple.com/access/integrations/api\n")

    key_id = click.prompt("Key ID")
    issuer_id = click.prompt("Issuer ID")
    default_key_path = f"~/.appstoreconnect/AuthKey_{key_id}.p8"
    key_path = click.prompt("Path to .p8 key file", default=default_key_path)

    expanded = os.path.expanduser(key_path)
    if not os.path.exists(expanded):
        click.echo(f"\nWarning: Key file not found at {expanded}", err=True)
        if not click.confirm("Save credentials anyway?", default=True):
            click.echo("Aborted.")
            return

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    env_file = _profile_path(name)
    env_file.write_text(
        f"ASC_KEY_ID={key_id}\n"
        f"ASC_ISSUER_ID={issuer_id}\n"
        f"ASC_KEY_PATH={key_path}\n"
    )
    env_file.chmod(0o600)

    # Set as active if it's the first profile or explicitly requested
    if not ACTIVE_FILE.exists() or profile_name:
        ACTIVE_FILE.write_text(name)
        click.echo(f"\nCredentials saved to {env_file} (active)")
    else:
        click.echo(f"\nCredentials saved to {env_file}")


@auth.command("use")
@click.argument("profile_name")
def auth_use(profile_name):
    """Switch the active profile."""
    env_file = _profile_path(profile_name)
    if not env_file.exists():
        click.echo(f"Error: Profile '{profile_name}' not found.", err=True)
        click.echo(f"Run 'appstore auth setup --profile {profile_name}' to create it.", err=True)
        sys.exit(1)
    ACTIVE_FILE.write_text(profile_name)
    click.echo(f"Switched to profile '{profile_name}'.")


@auth.command("list")
def auth_list():
    """List all configured profiles."""

    profiles = sorted(p.stem for p in CONFIG_DIR.glob("*.env"))
    if not profiles:
        click.echo("No profiles configured. Run 'appstore auth setup' to get started.")
        return
    active = _active_profile()
    for name in profiles:
        marker = " (active)" if name == active else ""
        click.echo(f"  {name}{marker}")


@auth.command("status")
def auth_status():
    """Show current credential configuration."""

    has_env_vars = all(os.getenv(k) for k in ("ASC_KEY_ID", "ASC_ISSUER_ID", "ASC_KEY_PATH"))

    if has_env_vars:
        click.echo("Source:     Environment variables")
        click.echo(f"Key ID:     {os.getenv('ASC_KEY_ID')}")
        click.echo(f"Issuer ID:  {os.getenv('ASC_ISSUER_ID')}")
        key_path = os.path.expanduser(os.getenv("ASC_KEY_PATH", ""))
        click.echo(f"Key Path:   {os.getenv('ASC_KEY_PATH')}")
        click.echo(f"Key Exists: {os.path.exists(key_path)}")
        return

    active = _active_profile()
    env_file = _profile_path(active)
    if not env_file.exists():
        click.echo("No credentials configured. Run 'appstore auth setup' to get started.")
        return

    load_dotenv(env_file, override=True)
    click.echo(f"Profile:    {active}")
    click.echo(f"Source:     {env_file}")
    click.echo(f"Key ID:     {os.getenv('ASC_KEY_ID', 'not set')}")
    click.echo(f"Issuer ID:  {os.getenv('ASC_ISSUER_ID', 'not set')}")
    key_path = os.path.expanduser(os.getenv("ASC_KEY_PATH", ""))
    click.echo(f"Key Path:   {os.getenv('ASC_KEY_PATH', 'not set')}")
    click.echo(f"Key Exists: {os.path.exists(key_path)}")


@auth.command("reset")
@click.option("--profile", "profile_name", default=None, help="Profile to remove (default: active profile)")
def auth_reset(profile_name):
    """Remove saved credentials for a profile."""

    name = profile_name or _active_profile()
    env_file = _profile_path(name)
    if not env_file.exists():
        click.echo(f"No saved credentials for profile '{name}'.")
        return
    if click.confirm(f"Delete profile '{name}' ({env_file})?"):
        env_file.unlink()
        # If we deleted the active profile, clear the active marker
        if ACTIVE_FILE.exists() and ACTIVE_FILE.read_text().strip() == name:
            ACTIVE_FILE.unlink()
        click.echo(f"Profile '{name}' removed.")
    else:
        click.echo("Aborted.")



# ---------------------------------------------------------------------------
# Generic engine — auto-generated commands from manifest.json
# ---------------------------------------------------------------------------

MANIFEST_PATH = Path(__file__).resolve().parent / "manifest.json"  # bundled with package


def to_kebab(camel: str) -> str:
    """Convert camelCase to kebab-case: betaGroups -> beta-groups."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", camel)
    return s.lower()


def build_included_map(data):
    """Build a lookup map from the JSON:API 'included' sideloaded array.

    Returns {(type, id): display_name} where display_name is the best
    human-readable label found in the included resource's attributes.
    """
    inc_map = {}
    for inc in data.get("included", []):
        attrs = inc.get("attributes", {})
        label = (attrs.get("name") or attrs.get("displayName")
                 or attrs.get("bundleId") or attrs.get("email")
                 or attrs.get("versionString") or attrs.get("version")
                 or inc.get("id", ""))
        inc_map[(inc["type"], inc["id"])] = str(label)
    return inc_map


def format_attr_value(val, max_len=40):
    """Format an attribute value for display, handling lists, dicts, None."""
    if val is None:
        return ""
    if isinstance(val, list):
        if val and isinstance(val[0], dict):
            # List of objects — summarize count
            return f"[{len(val)} items]"
        return ", ".join(str(v) for v in val)
    if isinstance(val, dict):
        # Nested object — show as compact summary
        parts = [f"{k}={v}" for k, v in val.items() if v is not None]
        val = "{" + ", ".join(parts[:3]) + "}"
    val = str(val)
    if len(val) > max_len:
        val = val[:max_len - 3] + "..."
    return val


def generic_table_formatter(data, display_attrs):
    """Format a list response as a table using display_attrs."""
    items = data if isinstance(data, list) else data.get("data", [])
    if not items:
        click.echo("No results.")
        return
    inc_map = build_included_map(data) if isinstance(data, dict) else {}
    # Determine which relationships to show as extra columns
    rel_cols = []
    if inc_map:
        # Find relationship keys that have matching included data
        sample_rels = items[0].get("relationships", {})
        for rname, rval in sample_rels.items():
            rdata = rval.get("data")
            if isinstance(rdata, dict) and (rdata.get("type"), rdata.get("id")) in inc_map:
                rel_cols.append(rname)
            elif isinstance(rdata, list) and rdata and (rdata[0].get("type"), rdata[0].get("id")) in inc_map:
                rel_cols.append(rname)
            if len(rel_cols) >= 2:
                break
    headers = ["ID"] + [to_kebab(a).upper() for a in display_attrs]
    for rc in rel_cols:
        headers.append(to_kebab(rc).upper())
    rows = []
    for item in items:
        attrs = item.get("attributes", {})
        row = [item.get("id", "")]
        for a in display_attrs:
            row.append(format_attr_value(attrs.get(a, "")))
        for rc in rel_cols:
            rdata = item.get("relationships", {}).get(rc, {}).get("data")
            if isinstance(rdata, dict):
                row.append(inc_map.get((rdata.get("type"), rdata.get("id")), rdata.get("id", "")))
            elif isinstance(rdata, list) and rdata:
                labels = [inc_map.get((r.get("type"), r.get("id")), r.get("id", "")) for r in rdata[:3]]
                row.append(", ".join(labels))
            else:
                row.append("")
        rows.append(row)
    print_table(headers, rows)


def generic_detail_formatter(data, schema_attrs):
    """Format a single resource detail view."""
    item = data.get("data", data) if isinstance(data, dict) else data
    inc_map = build_included_map(data) if isinstance(data, dict) else {}
    click.echo(f"ID:    {item.get('id', '')}")
    click.echo(f"Type:  {item.get('type', '')}")
    attrs = item.get("attributes", {})
    for a in schema_attrs:
        label = to_kebab(a).replace("-", " ").title()
        click.echo(f"{label}:  {format_attr_value(attrs.get(a, ''), max_len=200)}")
    if inc_map:
        rels = item.get("relationships", {})
        for rname, rval in rels.items():
            rdata = rval.get("data")
            if isinstance(rdata, dict):
                label = inc_map.get((rdata.get("type"), rdata.get("id")))
                if label:
                    click.echo(f"{to_kebab(rname).replace('-', ' ').title()}:  {label}")
            elif isinstance(rdata, list) and rdata:
                labels = [inc_map.get((r.get("type"), r.get("id")), r.get("id", "")) for r in rdata[:10]]
                resolved = [l for l in labels if l]
                if resolved:
                    click.echo(f"{to_kebab(rname).replace('-', ' ').title()}:  {', '.join(resolved)}")


def load_manifest():
    """Load manifest.json, return list of resources or empty list."""
    if not MANIFEST_PATH.exists():
        return []
    with open(MANIFEST_PATH) as f:
        return json.load(f).get("resources", [])


def create_list_command(resource):
    """Build a Click command for listing a resource."""
    res_type = resource["type"]
    path = resource["path"]
    display_attrs = resource.get("display_attrs", [])
    list_meta = resource.get("list", {})
    filters = list_meta.get("filters", [])
    sorts = list_meta.get("sorts", [])

    @click.pass_context
    def list_cmd(ctx, **kwargs):
        client = ASCClient(ctx.obj.get("profile"))
        fetch_all = kwargs.pop("all", False)
        include_val = kwargs.pop("include", None)
        params = {"limit": kwargs.pop("limit", 200)}
        sort_val = kwargs.pop("sort", None)
        if sort_val:
            params["sort"] = sort_val
        if include_val:
            params["include"] = include_val
        for key, val in kwargs.items():
            if val is not None:
                # Reverse-map the param name back to the original filter field
                for f in filters:
                    expected_param = "filter_" + to_kebab(f).replace(".", "-").replace("-", "_")
                    if expected_param == key:
                        params[f"filter[{f}]"] = val
                        break
        if fetch_all:
            items = client.get_all(path.lstrip("/"), params=params)
            body = {"data": items}
        else:
            body = client.get(path.lstrip("/"), params=params)

        def fmt(body):
            generic_table_formatter(body, display_attrs)

        output(ctx, body, fmt)

    # Add options dynamically
    list_cmd = click.option("--all", "all", is_flag=True, default=False,
                            help="Fetch all pages (auto-paginate)")(list_cmd)
    list_cmd = click.option("--limit", default=200, help="Max results per page", show_default=True)(list_cmd)
    if sorts:
        sort_help = f"Sort field ({', '.join(sorts[:5])}{'...' if len(sorts) > 5 else ''})"
        list_cmd = click.option("--sort", default=None, help=sort_help)(list_cmd)
    includes = list_meta.get("includes", [])
    if includes:
        inc_help = f"Include related resources ({', '.join(includes[:5])}{'...' if len(includes) > 5 else ''})"
        list_cmd = click.option("--include", default=None, help=inc_help)(list_cmd)
    for f in filters:
        kebab = to_kebab(f).replace(".", "-")
        opt_name = f"--filter-{kebab}"
        param_name = f"filter_{kebab.replace('-', '_')}"
        list_cmd = click.option(opt_name, param_name, default=None, help=f"Filter by {f}")(list_cmd)

    cmd = click.command("list", help=f"List {to_kebab(res_type)}.")(list_cmd)
    return cmd


def create_get_command(resource):
    """Build a Click command for getting a single resource."""
    res_type = resource["type"]
    path = resource["path"]
    schema_attrs = resource.get("schema_attrs", [])
    display_attrs = resource.get("display_attrs", schema_attrs[:6])

    @click.argument("resource_id")
    @click.pass_context
    def get_cmd(ctx, resource_id):
        client = ASCClient(ctx.obj.get("profile"))
        body = client.get(f"{path.lstrip('/')}/{resource_id}")

        def fmt(body):
            generic_detail_formatter(body, schema_attrs or display_attrs)

        output(ctx, body, fmt)

    cmd = click.command("get", help=f"Get a {to_kebab(res_type)[:-1]} by ID.")(get_cmd)
    return cmd


def create_create_command(resource):
    """Build a Click command for creating a resource."""
    res_type = resource["type"]
    path = resource["path"]
    create_meta = resource.get("create", {})
    create_attrs = create_meta.get("attributes", {})
    create_rels = create_meta.get("relationships", {})
    schema_attrs = resource.get("schema_attrs", [])

    @click.pass_context
    def create_cmd(ctx, **kwargs):
        client = ASCClient(ctx.obj.get("profile"))
        attributes = {}
        relationships = {}
        for aname, ainfo in create_attrs.items():
            opt_key = to_kebab(aname).replace("-", "_")
            val = kwargs.get(opt_key)
            if val is not None:
                if ainfo.get("type") == "boolean":
                    val = val.lower() in ("true", "1", "yes") if isinstance(val, str) else val
                elif ainfo.get("type") == "integer":
                    val = int(val)
                attributes[aname] = val
            elif ainfo.get("required"):
                click.echo(f"Error: --{to_kebab(aname)} is required.", err=True)
                sys.exit(1)
        for rname, rinfo in create_rels.items():
            opt_key = to_kebab(rname).replace("-", "_") + "_id"
            val = kwargs.get(opt_key)
            if val is not None:
                rel_data = {"type": rinfo["type"], "id": val}
                if rinfo.get("many"):
                    relationships[rname] = {"data": [rel_data]}
                else:
                    relationships[rname] = {"data": rel_data}
            elif rinfo.get("required"):
                click.echo(f"Error: --{to_kebab(rname)}-id is required.", err=True)
                sys.exit(1)

        payload = {
            "data": {
                "type": res_type,
                "attributes": attributes,
            }
        }
        if relationships:
            payload["data"]["relationships"] = relationships

        body = client.post(path.lstrip("/"), data=payload)

        def fmt(body):
            generic_detail_formatter(body, schema_attrs or list(create_attrs.keys()))

        output(ctx, body, fmt)

    # Add options for attributes
    for aname, ainfo in create_attrs.items():
        opt_name = f"--{to_kebab(aname)}"
        required = ainfo.get("required", False)
        help_text = f"{'(required) ' if required else ''}{aname} ({ainfo.get('type', 'string')})"
        create_cmd = click.option(opt_name, required=required, default=None, help=help_text)(create_cmd)
    # Add options for relationships
    for rname, rinfo in create_rels.items():
        opt_name = f"--{to_kebab(rname)}-id"
        required = rinfo.get("required", False)
        help_text = f"{'(required) ' if required else ''}ID of related {rinfo['type']}"
        create_cmd = click.option(opt_name, required=required, default=None, help=help_text)(create_cmd)

    cmd = click.command("create", help=f"Create a {to_kebab(res_type)[:-1]}.")(create_cmd)
    return cmd


def create_update_command(resource):
    """Build a Click command for updating a resource."""
    res_type = resource["type"]
    path = resource["path"]
    update_meta = resource.get("update", {})
    update_attrs = update_meta.get("attributes", {})
    schema_attrs = resource.get("schema_attrs", [])

    @click.argument("resource_id")
    @click.pass_context
    def update_cmd(ctx, resource_id, **kwargs):
        client = ASCClient(ctx.obj.get("profile"))
        attributes = {}
        for aname, ainfo in update_attrs.items():
            opt_key = to_kebab(aname).replace("-", "_")
            val = kwargs.get(opt_key)
            if val is not None:
                if ainfo.get("type") == "boolean":
                    val = val.lower() in ("true", "1", "yes") if isinstance(val, str) else val
                elif ainfo.get("type") == "integer":
                    val = int(val)
                attributes[aname] = val
        if not attributes:
            click.echo("No attributes to update. Pass at least one --option.", err=True)
            sys.exit(1)

        payload = {
            "data": {
                "type": res_type,
                "id": resource_id,
                "attributes": attributes,
            }
        }
        body = client.patch(f"{path.lstrip('/')}/{resource_id}", data=payload)

        def fmt(body):
            generic_detail_formatter(body, schema_attrs or list(update_attrs.keys()))

        output(ctx, body, fmt)

    # Add options for updatable attributes
    for aname, ainfo in update_attrs.items():
        opt_name = f"--{to_kebab(aname)}"
        help_text = f"{aname} ({ainfo.get('type', 'string')})"
        update_cmd = click.option(opt_name, default=None, help=help_text)(update_cmd)

    cmd = click.command("update", help=f"Update a {to_kebab(res_type)[:-1]}.")(update_cmd)
    return cmd


def create_delete_command(resource):
    """Build a Click command for deleting a resource."""
    res_type = resource["type"]
    path = resource["path"]

    @click.argument("resource_id")
    @click.option("--yes", is_flag=True, help="Skip confirmation")
    @click.pass_context
    def delete_cmd(ctx, resource_id, yes):
        if not yes:
            if not click.confirm(f"Delete {to_kebab(res_type)[:-1]} {resource_id}?"):
                click.echo("Aborted.")
                return
        client = ASCClient(ctx.obj.get("profile"))
        client.delete(f"{path.lstrip('/')}/{resource_id}")
        click.echo(f"Deleted {resource_id}.")

    cmd = click.command("delete", help=f"Delete a {to_kebab(res_type)[:-1]}.")(delete_cmd)
    return cmd


def register_generic_commands():
    """Load the manifest and register generic command groups for all resources."""
    resources = load_manifest()
    if not resources:
        return

    # Names of hand-written groups to skip
    existing = set(cli.commands.keys())

    for resource in resources:
        group_name = to_kebab(resource["type"])
        if group_name in existing:
            continue

        # Create a Click group for this resource
        ops = resource["operations"]
        grp = click.Group(name=group_name,
                          help=" | ".join(ops))
        if "list" in ops:
            grp.add_command(create_list_command(resource))
        if "get" in ops:
            grp.add_command(create_get_command(resource))
        if "create" in ops:
            grp.add_command(create_create_command(resource))
        if "update" in ops:
            grp.add_command(create_update_command(resource))
        if "delete" in ops:
            grp.add_command(create_delete_command(resource))

        cli.add_command(grp)


register_generic_commands()


# ---------------------------------------------------------------------------
# Relationship commands — injected into generic groups after registration
# ---------------------------------------------------------------------------


@cli.commands["beta-groups"].command("add-build")
@click.argument("group_id")
@click.argument("build_id")
@click.pass_context
def beta_groups_add_build(ctx, group_id, build_id):
    """Add a build to a beta group."""
    client = ASCClient(ctx.obj.get("profile"))
    body = client.post(f"betaGroups/{group_id}/relationships/builds", data={
        "data": [{"type": "builds", "id": build_id}]
    })

    def fmt(body):
        click.echo(f"Build {build_id} added to group {group_id}.")

    output(ctx, body if body else {"status": "ok"}, fmt)


@cli.commands["beta-groups"].command("remove-build")
@click.argument("group_id")
@click.argument("build_id")
@click.pass_context
def beta_groups_remove_build(ctx, group_id, build_id):
    """Remove a build from a beta group."""
    client = ASCClient(ctx.obj.get("profile"))
    body = client.delete(f"betaGroups/{group_id}/relationships/builds", data={
        "data": [{"type": "builds", "id": build_id}]
    })

    def fmt(body):
        click.echo(f"Build {build_id} removed from group {group_id}.")

    output(ctx, body if body else {"status": "ok"}, fmt)


@cli.commands["app-store-versions"].command("set-build")
@click.argument("version_id")
@click.argument("build_id")
@click.pass_context
def app_store_versions_set_build(ctx, version_id, build_id):
    """Attach a build to an App Store version."""
    client = ASCClient(ctx.obj.get("profile"))
    body = client.patch(f"appStoreVersions/{version_id}/relationships/build", data={
        "data": {"type": "builds", "id": build_id}
    })

    def fmt(body):
        click.echo(f"Build {build_id} attached to version {version_id}.")

    output(ctx, body if body else {"status": "ok"}, fmt)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    cli()
