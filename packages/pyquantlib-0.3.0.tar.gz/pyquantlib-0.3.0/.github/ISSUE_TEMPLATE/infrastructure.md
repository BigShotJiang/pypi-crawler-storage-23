---
name: Infrastructure Task
about: CI, tooling, documentation, or project setup work
title: '[INFRA] '
labels: infrastructure
assignees: ''
---

## Task
<!-- What needs to be done -->

## Category
<!-- Check one -->
- [ ] CI/CD
- [ ] Documentation
- [ ] Tooling
- [ ] Project structure
- [ ] Release prep

## Details
<!-- Steps, requirements, or acceptance criteria -->

## Related
<!-- Links to related issues, docs, or references -->
