/*
 * PyQuantLib: Python bindings for QuantLib
 * https://github.com/quantales/pyquantlib
 *
 * Copyright (c) 2025 Yassine Idyiahia
 * SPDX-License-Identifier: BSD-3-Clause
 * See LICENSE for details.
 *
 * ---
 * QuantLib is Copyright (c) 2000-2025 The QuantLib Authors
 * https://www.quantlib.org/
 */

#include "pyquantlib/pyquantlib.h"
#include <ql/instruments/bonds/cmsratebond.hpp>
#include <ql/indexes/swapindex.hpp>
#include <ql/time/daycounter.hpp>
#include <ql/time/schedule.hpp>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;
using namespace QuantLib;

void ql_instruments::cmsratebond(py::module_& m) {
    py::class_<CmsRateBond, Bond, ext::shared_ptr<CmsRateBond>>(
        m, "CmsRateBond",
        "CMS-rate bond.")
        .def(py::init([](Natural settlementDays,
                         Real faceAmount,
                         Schedule schedule,
                         const ext::shared_ptr<SwapIndex>& index,
                         const DayCounter& paymentDayCounter,
                         BusinessDayConvention paymentConvention,
                         const py::object& fixingDays,
                         const std::vector<Real>& gearings,
                         const std::vector<Spread>& spreads,
                         const std::vector<Rate>& caps,
                         const std::vector<Rate>& floors,
                         bool inArrears,
                         Real redemption,
                         const Date& issueDate) {
            Natural fd = Null<Natural>();
            if (!fixingDays.is_none())
                fd = fixingDays.cast<Natural>();
            return ext::make_shared<CmsRateBond>(
                settlementDays, faceAmount, std::move(schedule), index,
                paymentDayCounter, paymentConvention, fd,
                gearings, spreads, caps, floors,
                inArrears, redemption, issueDate);
        }),
            py::arg("settlementDays"),
            py::arg("faceAmount"),
            py::arg("schedule"),
            py::arg("index"),
            py::arg("paymentDayCounter"),
            py::arg("paymentConvention") = Following,
            py::arg("fixingDays") = py::none(),
            py::arg("gearings") = std::vector<Real>{1.0},
            py::arg("spreads") = std::vector<Spread>{0.0},
            py::arg("caps") = std::vector<Rate>{},
            py::arg("floors") = std::vector<Rate>{},
            py::arg("inArrears") = false,
            py::arg("redemption") = 100.0,
            py::arg("issueDate") = Date(),
            "Constructs a CMS-rate bond.");
}
