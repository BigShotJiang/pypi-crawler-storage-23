# PyQuantLib Examples

Jupyter notebooks demonstrating PyQuantLib usage.

## Running the Examples

### Prerequisites

```bash
pip install pyquantlib[examples]
```

### Launch

```bash
jupyter notebook
```
