# Blocks Control SDK

A unified Python interface to interact with popular coding agents.

> Think of it like litellm, but for coding agents

## Supported Agents

- **Claude Code** - Anthropic's Claude
- **Gemini CLI** - Google's Gemini
- **Codex CLI** - OpenAI's Codex
- **Cursor CLI** - Cursor's AI agent
- **OpenCode** - OpenCode CLI agent
- **Kimi CLI** - Kimi's AI agent

## Installation

```bash
pip install blocks-control-sdk
```

You must also have the dependent agent packages installed to use a specific agent.

```bash
npm i -g @anthropic-ai/claude-code   # For Claude Code
npm i -g @google/gemini-cli           # For Gemini CLI
npm i -g @openai/codex-cli            # For Codex CLI
npm i -g @anthropic-ai/cursor-cli     # For Cursor CLI (if applicable)
```

## Usage

### Async Streaming

```python
import asyncio
from blocks_control_sdk import ClaudeCode


async def main():
    agent = ClaudeCode()
    async for message in agent.stream("Write a python script to print 'Hello, World!'"):
        if isinstance(message, tuple):
            tool_name, args = message
            print(f"Tool call: {tool_name} with args {args}")
        else:
            print(message.content)

if __name__ == "__main__":
    asyncio.run(main())
```

### Sync with Callbacks

```python
from blocks_control_sdk import Codex

agent = Codex()

def on_message(notification):
    print(notification.message.content)

agent.register_notification(agent.notifications.NOTIFY_MESSAGE_V2, on_message)

agent.query("Write a python script to print 'Hello, World!'")
```

### All Agents

```python
from blocks_control_sdk import ClaudeCode, Codex, GeminiCLI, CursorCLI, OpenCode, KimiCLI

# Claude
claude = ClaudeCode()

# Gemini
gemini = GeminiCLI()

# Codex
codex = Codex()

# Cursor
cursor = CursorCLI()

# OpenCode
opencode = OpenCode()

# Kimi
kimi = KimiCLI()
```

## Environment Variables

```bash
export ANTHROPIC_API_KEY="your-key"  # For Claude
export GEMINI_API_KEY="your-key"     # For Gemini
export OPENAI_API_KEY="your-key"     # For Codex
export CURSOR_API_KEY="your-key"     # For Cursor
```
