from blocks_control_sdk.activity_providers.base import AgentActivityProvider
from blocks_control_sdk.control.agent_base import NotifyMessageArgs, NotifyCompleteArgs, NotifyToolCallArgs


class WebhookActivityProvider(AgentActivityProvider):
    def on_message(self, notification: NotifyMessageArgs) -> None:
        pass

    def on_complete(self, notification: NotifyCompleteArgs) -> None:
        pass

    def on_tool_call(self, notification: NotifyToolCallArgs) -> None:
        pass
