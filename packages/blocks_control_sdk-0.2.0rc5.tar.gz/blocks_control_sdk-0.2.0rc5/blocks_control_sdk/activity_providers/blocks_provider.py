from blocks_control_sdk.activity_providers.base import AgentActivityProvider
from blocks_control_sdk.control.agent_base import NotifyMessageArgs, NotifyCompleteArgs, NotifyToolCallArgs
from blocks_control_sdk.tools.blocks import send_message__blocks

class BlocksActivityProvider(AgentActivityProvider):
    def on_message(self, notification: NotifyMessageArgs) -> None:
        message = notification.message
        chat_thread_id = notification.chat_thread_id

        if message.content:
            send_message__blocks(message.content, urgency_level_between_zero_to_10=6, chat_thread_id=chat_thread_id)

    def on_complete(self, notification: NotifyCompleteArgs) -> None:
        message = notification.last_message
        chat_thread_id = notification.chat_thread_id

        if message:
            send_message__blocks(message, urgency_level_between_zero_to_10=10, role="assistant", type="final_message", chat_thread_id=chat_thread_id)

    def on_tool_call(self, notification: NotifyToolCallArgs) -> None:
        serialized_args = notification.serialized_args
        chat_thread_id = notification.chat_thread_id

        send_message__blocks(serialized_args, urgency_level_between_zero_to_10=6, role="assistant", type="tool_call", chat_thread_id=chat_thread_id)
