from enum import Enum


class OpenCodeModels(str, Enum):
    # Anthropic models
    claude_sonnet_latest = "anthropic/claude-sonnet-4-5"
    claude_opus_latest = "anthropic/claude-opus-4-6"
    claude_opus_4_5 = "anthropic/claude-opus-4-5"
    claude_haiku_latest = "anthropic/claude-haiku-4-5"

    # OpenAI models
    openai_codex_latest = "openai/gpt-5.2-codex"
    openai_latest = "openai/gpt-5.2"

    # Google models
    # gemini_flash_latest = "google/gemini-flash-latest"
    # gemini_pro_latest = "google/gemini-3-pro-preview"

class SisyphusModels(str, Enum):
    sisyphus_latest = "anthropic/claude-opus-4-6"
    sisyphus_opus_4_5 = "anthropic/claude-opus-4-5"
