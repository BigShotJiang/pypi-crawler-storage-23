from enum import Enum

class GeminiModels(str, Enum):
    gemini_flash_latest = "gemini-flash-latest"
    gemini_2_5_pro = "gemini-2.5-pro"
    gemini_2_5_flash_lite = "gemini-2.5-flash-lite"
    gemini_3_pro_preview = "gemini-3-pro-preview"

    def to_litellm_model(self):
        return f"gemini/{self.value}"