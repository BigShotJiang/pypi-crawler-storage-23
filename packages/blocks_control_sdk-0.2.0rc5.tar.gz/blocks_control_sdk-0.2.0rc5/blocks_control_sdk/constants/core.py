from pathlib import Path
from enum import Enum
import os

BLOCKS_USER_HOME = os.getenv("BLOCKS_USER_HOME", "/home/blocks")
WORKSPACE_DIR = Path(BLOCKS_USER_HOME) / "workspace"

INTERNAL_MCP_NAME = "blocks-internal-mcp"


class BlocksComputePlatform(str, Enum):
    EMERALD = "emerald"
    FARGATE = "fargate"


def is_micro_vm() -> bool:
    """Check if running on a micro-VM compute platform (emerald)."""
    platform = os.getenv("BLOCKS_COMPUTE_PLATFORM", "").lower()
    return platform == BlocksComputePlatform.EMERALD