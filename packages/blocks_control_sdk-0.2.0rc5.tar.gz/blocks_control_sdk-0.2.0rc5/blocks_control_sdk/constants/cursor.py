from enum import Enum
from typing import Dict, List, TypedDict


class CursorModelInfo(TypedDict):
    modelId: str
    displayModelId: str
    displayName: str
    displayNameShort: str
    aliases: List[str]
    maxMode: bool


class CursorModels(str, Enum):
    # Anthropic Claude models
    claude_4_5_sonnet = "claude-4.5-sonnet"
    claude_4_5_sonnet_thinking = "claude-4.5-sonnet-thinking"
    claude_4_5_opus = "claude-4.5-opus-high"
    claude_4_6_opus = "claude-4.6-opus-high"
    claude_4_6_opus_thinking = "claude-4.6-opus-high-thinking"

    # Auto/Default
    auto = "default"

    # Cursor native
    composer_1 = "composer-1"

    # OpenAI models
    gpt_5_2_codex_high = "gpt-5.2-codex-high"

    # Google models
    gemini_3_pro = "gemini-3-pro"


# Full model metadata
CURSOR_MODELS_INFO: Dict[CursorModels, CursorModelInfo] = {
    CursorModels.claude_4_5_sonnet: {
        "modelId": "claude-4.5-sonnet",
        "displayModelId": "sonnet-4.5",
        "displayName": "Claude 4.5 Sonnet",
        "displayNameShort": "Sonnet 4.5",
        "aliases": ["sonnet", "sonnet-4.5"],
        "maxMode": False
    },
    CursorModels.claude_4_5_sonnet_thinking: {
        "modelId": "claude-4.5-sonnet-thinking",
        "displayModelId": "sonnet-4.5-thinking",
        "displayName": "Claude 4.5 Sonnet (Thinking)",
        "displayNameShort": "Sonnet 4.5 (Thinking)",
        "aliases": ["sonnet-4.5-thinking"],
        "maxMode": False
    },
    CursorModels.claude_4_5_opus: {
        "modelId": "claude-4.5-opus-high",
        "displayModelId": "opus-4.5",
        "displayName": "Claude 4.5 Opus",
        "displayNameShort": "Opus 4.5",
        "aliases": ["opus", "opus-4.5", "claude-4.5-opus"],
        "maxMode": False
    },
    CursorModels.claude_4_6_opus: {
        "modelId": "claude-4.6-opus-high",
        "displayModelId": "opus-4.6",
        "displayName": "Claude 4.6 Opus",
        "displayNameShort": "Opus 4.6",
        "aliases": ["opus-4.6", "claude-4.6-opus"],
        "maxMode": False
    },
    CursorModels.claude_4_6_opus_thinking: {
        "modelId": "claude-4.6-opus-high-thinking",
        "displayModelId": "opus-4.6-thinking",
        "displayName": "Claude 4.6 Opus (Thinking)",
        "displayNameShort": "Opus 4.6 (Thinking)",
        "aliases": ["opus-4.6-thinking", "claude-4.6-opus-thinking"],
        "maxMode": False
    },
    CursorModels.auto: {
        "modelId": "default",
        "displayModelId": "auto",
        "displayName": "Auto",
        "displayNameShort": "Auto",
        "aliases": ["auto"],
        "maxMode": False
    },
    CursorModels.composer_1: {
        "modelId": "composer-1",
        "displayModelId": "composer-1",
        "displayName": "Composer 1",
        "displayNameShort": "Composer 1",
        "aliases": [],
        "maxMode": False
    },
    CursorModels.gpt_5_2_codex_high: {
        "modelId": "gpt-5.2-codex-high",
        "displayModelId": "gpt-5.2-codex-high",
        "displayName": "GPT-5.2 Codex High",
        "displayNameShort": "GPT-5.2 Codex High",
        "aliases": [],
        "maxMode": False
    },
    CursorModels.gemini_3_pro: {
        "modelId": "gemini-3-pro",
        "displayModelId": "gemini-3-pro",
        "displayName": "Gemini 3 Pro",
        "displayNameShort": "Gemini 3 Pro",
        "aliases": [],
        "maxMode": False
    },
}
