from enum import Enum


class KimiModels(str, Enum):
    # Kimi K2 models (moonshot-ai provider)
    kimi_k2_5 = "moonshot-ai/kimi-k2.5"
    kimi_k2_thinking = "moonshot-ai/kimi-k2-thinking"
    kimi_k2_turbo = "moonshot-ai/kimi-k2-turbo-preview"
    kimi_k2_thinking_turbo = "moonshot-ai/kimi-k2-thinking-turbo"
    kimi_k2_0711 = "moonshot-ai/kimi-k2-0711-preview"
    kimi_k2_0905 = "moonshot-ai/kimi-k2-0905-preview"

    # Default model
    kimi_default = "moonshot-ai/kimi-k2.5"
