from blocks_control_sdk.blocks_events.context import BLOCKS_EVENT__TRIGGER_ALIAS
from blocks_control_sdk.control.agent_base import LLM
from blocks_control_sdk.utils import get_blocks_runtime_config, BlocksRuntimeConfigKeys
from blocks_control_sdk.prompt_builder import build_standard_prompt


def github_pull_request_prompt_and_config(input, llm_provider: LLM):
    print("########################### Github Pull Request V2 ###########################")

    return build_standard_prompt(
        trigger_alias=BLOCKS_EVENT__TRIGGER_ALIAS.GITHUB_PULL_REQUEST_COMMENT,
        input=input,
        agent=llm_provider.value,
        include_write_code_instructions=True
    )


def github_issue_prompt_and_config(input, llm_provider: LLM):
    print("########################### Github Issue V2 ###########################")

    return build_standard_prompt(
        trigger_alias=BLOCKS_EVENT__TRIGGER_ALIAS.GITHUB_ISSUE_COMMENT,
        input=input,
        agent=llm_provider.value
    )


def github_pull_request_review_comment_prompt_and_config(input, llm_provider: LLM):
    print("########################### Github Pull Request Review Comment V2 ###########################")

    return build_standard_prompt(
        trigger_alias=BLOCKS_EVENT__TRIGGER_ALIAS.GITHUB_PULL_REQUEST_REVIEW_COMMENT,
        input=input,
        agent=llm_provider.value
    )


def linear_issue_comment_prompt_and_config(input, llm_provider: LLM):
    print("########################### Linear Issue Comment V2 ###########################")

    return build_standard_prompt(
        trigger_alias=BLOCKS_EVENT__TRIGGER_ALIAS.LINEAR_ISSUE_COMMENT,
        input=input,
        agent=llm_provider.value
    )


def gitlab_issue_comment_prompt_and_config(input, llm_provider: LLM):
    print("########################### GitLab Issue Comment V2 ###########################")

    return build_standard_prompt(
        trigger_alias=BLOCKS_EVENT__TRIGGER_ALIAS.GITLAB_ISSUE_COMMENT,
        input=input,
        agent=llm_provider.value
    )


def gitlab_merge_request_comment_prompt_and_config(input, llm_provider: LLM):
    print("########################### GitLab Merge Request Comment V2 ###########################")

    return build_standard_prompt(
        trigger_alias=BLOCKS_EVENT__TRIGGER_ALIAS.GITLAB_MERGE_REQUEST_COMMENT,
        input=input,
        agent=llm_provider.value,
        include_write_code_instructions=True
    )

def webhook_and_configure_no_todo_list(input, llm_provider: LLM):
    print("########################### Webhook Prompt ###########################")

    return build_standard_prompt(
        trigger_alias=BLOCKS_EVENT__TRIGGER_ALIAS.WEBHOOK,
        input=input,
        agent=llm_provider.value
    )

def slack_mention_prompt(input, llm_provider: LLM):
    print("########################### Slack Mention Prompt ###########################")

    return build_standard_prompt(
        trigger_alias=BLOCKS_EVENT__TRIGGER_ALIAS.SLACK_MENTION,
        input=input,
        agent=llm_provider.value,
        include_write_code_instructions=True
    )
