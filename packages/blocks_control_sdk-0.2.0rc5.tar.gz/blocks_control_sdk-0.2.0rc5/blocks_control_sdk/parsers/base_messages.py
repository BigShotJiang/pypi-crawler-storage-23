from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from litellm.types.utils import ModelResponse

BLOCKS_PROVIDER_SPECIFIC_FIELDS__IS_FINAL_MESSAGE = "blocks__is_final_message"

def print_litellm_model_response(resp: "ModelResponse"):
    print("ROLE:", resp.choices[0].message.role)
    print("TEXT:", resp.choices[0].message.content)
    print("REASONING:", getattr(resp.choices[0].message, "reasoning_content", None))
    print("PROVIDER SPECIFIC FIELDS:", resp.choices[0].message.provider_specific_fields)
    if resp.choices[0].message.tool_calls:
        for tc in resp.choices[0].message.tool_calls:
            print("TOOL:", tc.function.name, tc.function.arguments)
    