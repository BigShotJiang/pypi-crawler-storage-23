"""Minimal logger for agents module."""
import logging
import os
import sys

# Support both CONTROL_LOG_LEVEL (consistency with control-sdk)
# and AGENTS_LOG_LEVEL (explicit control)
level = os.environ.get("CONTROL_LOG_LEVEL") or os.environ.get("AGENTS_LOG_LEVEL", "INFO")
level = level.upper()

# Configure root logger
logging.basicConfig(
    level=getattr(logging, level, logging.INFO),
    format="%(message)s",
    stream=sys.stdout,
    force=True
)

# Create logger instance
log = logging.getLogger("agents")
log.setLevel(getattr(logging, level, logging.INFO))


def is_debug():
    """Check if debug logging is enabled."""
    return log.isEnabledFor(logging.DEBUG)


def error_debug(msg, *args, **kwargs):
    """Log as error only when debug level is enabled."""
    if log.isEnabledFor(logging.DEBUG):
        log.error(msg, *args, **kwargs)


def stream_line(line):
    """
    Stream a line of output preserving print(line, end="", flush=True) behavior.
    Used for raw NDJSON output from underlying CLIs.
    """
    if line.endswith('\n'):
        log.info(line.rstrip('\n'))
    else:
        print(line, end='', flush=True)
