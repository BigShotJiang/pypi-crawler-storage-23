from .kongming_rs import hv  # noqa: F401 — triggers Rust extension init
