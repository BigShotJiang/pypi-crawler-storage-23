from .lib import xxhash

from xxhash import * # type: ignore
