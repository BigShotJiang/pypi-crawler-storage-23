"""Enhanced dataclass helpers with Arrow awareness."""

from .dataclass import dataclass_to_arrow_field
