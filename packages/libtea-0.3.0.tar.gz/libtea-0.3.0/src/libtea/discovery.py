"""TEI parsing, .well-known/tea fetching, and SemVer-based endpoint selection.

Implements the TEA discovery flow: parse a TEI URN, fetch the ``.well-known/tea``
document from the TEI's domain, and select the best-matching endpoint using
SemVer 2.0.0 comparison and priority-based ordering.
"""

import logging
import warnings
from dataclasses import dataclass
from typing import Any
from urllib.parse import urljoin, urlparse

import requests
from pydantic import ValidationError
from semver import Version as _SemVer

from libtea._constants import USER_AGENT
from libtea._security import _validate_download_url
from libtea.exceptions import TeaDiscoveryError, TeaInsecureTransportWarning, TeaValidationError
from libtea.models import TeaEndpoint, TeaWellKnown, TeiType

logger = logging.getLogger("libtea")

_VALID_TEI_TYPES = frozenset(e.value for e in TeiType)


def _endpoint_sort_key(pair: tuple[_SemVer, TeaEndpoint]) -> tuple[_SemVer, float]:
    """Sort key: highest SemVer version desc, then priority desc (default 1.0 per TEA spec)."""
    return (pair[0], pair[1].priority if pair[1].priority is not None else 1.0)


_DOMAIN_LABEL_CHARS = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-")


def _is_valid_domain(domain: str) -> bool:
    """Validate a domain name per RFC 952 / RFC 1123.

    Rules: each label is 1-63 characters of ``[a-zA-Z0-9-]`` with no leading
    or trailing hyphens, and the total length is at most 253 characters.
    """
    if not domain or len(domain) > 253:
        return False
    for label in domain.split("."):
        if not label or len(label) > 63:
            return False
        if label[0] == "-" or label[-1] == "-":
            return False
        if not all(c in _DOMAIN_LABEL_CHARS for c in label):
            return False
    return True


def parse_tei(tei: str) -> tuple[str, str, str]:
    """Parse a TEI URN into (type, domain, identifier).

    TEI format: ``urn:tei:<type>:<domain>:<identifier>``

    Args:
        tei: TEI URN string.

    Returns:
        Tuple of (type, domain, identifier).

    Raises:
        TeaDiscoveryError: If the TEI format is invalid.
    """
    parts = tei.split(":")
    if len(parts) < 5 or parts[0] != "urn" or parts[1] != "tei":
        raise TeaDiscoveryError(f"Invalid TEI: {tei!r}. Expected format: urn:tei:<type>:<domain>:<identifier>")

    tei_type = parts[2]
    if tei_type not in _VALID_TEI_TYPES:
        raise TeaDiscoveryError(
            f"Invalid TEI type: {tei_type!r}. Must be one of: {', '.join(sorted(_VALID_TEI_TYPES))}"
        )
    domain = parts[3]
    if not domain or not _is_valid_domain(domain):
        raise TeaDiscoveryError(f"Invalid domain in TEI: {domain!r}")
    identifier = ":".join(parts[4:])
    return tei_type, domain, identifier


def fetch_well_known(
    domain: str,
    *,
    timeout: float = 10.0,
    scheme: str = "https",
    port: int | None = None,
) -> TeaWellKnown:
    """Fetch and parse the .well-known/tea discovery document from a domain.

    Args:
        domain: Domain name to resolve (e.g. ``tea.example.com``).
        timeout: HTTP request timeout in seconds.
        scheme: URL scheme, ``"https"`` (default) or ``"http"``.
        port: Optional port number. Default ports (443 for https, 80 for http)
            are omitted from the URL.

    Returns:
        Parsed well-known document with endpoint list.

    Raises:
        TeaDiscoveryError: If the domain is invalid, unreachable, or returns
            an invalid document.
    """
    if scheme not in ("http", "https"):
        raise TeaDiscoveryError(f"Invalid scheme: {scheme!r}. Must be 'http' or 'https'.")
    if scheme == "http":
        warnings.warn(
            "Fetching .well-known/tea over plaintext HTTP. Use HTTPS in production.",
            TeaInsecureTransportWarning,
            stacklevel=2,
        )
    if port is not None and not (1 <= port <= 65535):
        raise TeaDiscoveryError(f"Invalid port: {port}. Must be between 1 and 65535.")
    if not domain or not _is_valid_domain(domain):
        raise TeaDiscoveryError(f"Invalid domain: {domain!r}")

    default_port = 80 if scheme == "http" else 443
    resolved_port = port if port is not None else default_port
    if resolved_port == default_port:
        url = f"{scheme}://{domain}/.well-known/tea"
    else:
        url = f"{scheme}://{domain}:{resolved_port}/.well-known/tea"

    kwargs: dict[str, Any] = {"timeout": timeout, "allow_redirects": False, "headers": {"user-agent": USER_AGENT}}

    logger.debug("Fetching well-known discovery document: %s", url)
    _max_discovery_redirects = 5
    current_url = url
    try:
        # Follow redirects manually with SSRF validation at each hop
        # (automatic redirects would allow intermediate hops to internal IPs).
        response = None
        redirects = 0
        try:
            while True:
                response = requests.get(current_url, stream=True, **kwargs)
                if 300 <= response.status_code < 400:
                    redirects += 1
                    if redirects > _max_discovery_redirects:
                        raise TeaDiscoveryError(f"Too many discovery redirects (max {_max_discovery_redirects})")
                    location = response.headers.get("Location")
                    if not location:
                        raise TeaDiscoveryError(
                            f"Discovery redirect without Location header: HTTP {response.status_code}"
                        )
                    current_url = urljoin(current_url, location)
                    # Validate scheme and SSRF at each hop
                    hop_parsed = urlparse(current_url)
                    if hop_parsed.scheme not in ("http", "https"):
                        raise TeaDiscoveryError(f"Discovery redirected to unsupported scheme: {hop_parsed.scheme!r}")
                    if scheme == "https" and hop_parsed.scheme == "http":
                        raise TeaDiscoveryError(
                            f"Discovery for {domain} was downgraded from HTTPS to HTTP via redirect. "
                            "This may indicate a misconfigured server or a downgrade attack. "
                            "Use scheme='http' explicitly if plaintext is intended."
                        )
                    try:
                        _validate_download_url(current_url)
                    except TeaValidationError as exc:
                        raise TeaDiscoveryError(
                            f"Discovery for {domain} redirected to a blocked or disallowed URL"
                        ) from exc
                    response.close()
                    response = None
                    continue
                break

            if response.status_code >= 400:
                body_snippet = ""
                try:
                    if response.raw:
                        response.raw.decode_content = True
                    raw_bytes = response.raw.read(201) if response.raw else b""
                    body_snippet = raw_bytes.decode("utf-8", errors="replace")[:200]
                    if len(raw_bytes) > 200:
                        body_snippet += " (truncated)"
                except Exception:
                    pass
                msg = f"Failed to fetch {current_url}: HTTP {response.status_code}"
                if body_snippet:
                    msg = f"{msg} — {body_snippet}"
                raise TeaDiscoveryError(msg)

            try:
                data = response.json()
            except ValueError as exc:
                raise TeaDiscoveryError(f"Invalid JSON in .well-known/tea response from {domain}") from exc
        finally:
            if response is not None:
                response.close()
    except requests.ConnectionError as exc:
        logger.warning("Discovery connection error for %s: %s", current_url, exc)
        raise TeaDiscoveryError(f"Failed to connect to {current_url}: {exc}") from exc
    except requests.Timeout as exc:
        logger.warning("Discovery timeout for %s: %s", current_url, exc)
        raise TeaDiscoveryError(f"Failed to connect to {current_url}: {exc}") from exc
    except requests.RequestException as exc:
        raise TeaDiscoveryError(f"HTTP error fetching {current_url}: {exc}") from exc

    try:
        return TeaWellKnown.model_validate(data)
    except ValidationError as exc:
        raise TeaDiscoveryError(f"Invalid .well-known/tea document from {domain}: {exc}") from exc


def select_endpoints(well_known: TeaWellKnown, supported_version: str) -> list[TeaEndpoint]:
    """Select all endpoints that exactly match the given version, sorted by priority.

    Uses exact SemVer 2.0.0 comparison (no range matching). For flexible
    version negotiation that can downgrade to compatible server versions,
    use :func:`select_best_endpoint` instead.

    Args:
        well_known: Parsed .well-known/tea document.
        supported_version: Exact SemVer version string to match.

    Returns:
        List of matching endpoints, highest priority first.

    Raises:
        TeaDiscoveryError: If no endpoint supports the requested version.
    """
    try:
        target = _SemVer.parse(supported_version)
    except ValueError as exc:
        raise TeaDiscoveryError(f"Invalid version string {supported_version!r}: {exc}") from exc

    candidates: list[tuple[_SemVer, TeaEndpoint]] = []
    for ep in well_known.endpoints:
        for v_str in ep.versions:
            try:
                v = _SemVer.parse(v_str)
            except ValueError:
                continue
            if v == target:
                candidates.append((v, ep))
                break

    if not candidates:
        available = {v for ep in well_known.endpoints for v in ep.versions}
        raise TeaDiscoveryError(
            f"No endpoint found for version {supported_version!r}. Available versions: {sorted(available)}"
        )

    # All matched versions are identical (exact match); sort by priority desc (default 1.0 per spec)
    candidates.sort(
        key=_endpoint_sort_key,
        reverse=True,
    )
    return [ep for _, ep in candidates]


def select_endpoint(well_known: TeaWellKnown, supported_version: str) -> TeaEndpoint:
    """Select the best endpoint that supports the given version.

    Convenience wrapper around :func:`select_endpoints` that returns only
    the top-priority candidate.

    Args:
        well_known: Parsed .well-known/tea document.
        supported_version: SemVer version string the client supports.

    Returns:
        The best matching endpoint.

    Raises:
        TeaDiscoveryError: If no endpoint supports the requested version.
    """
    return select_endpoints(well_known, supported_version)[0]


@dataclass(frozen=True)
class VersionedEndpoint:
    """An endpoint paired with the server version it was matched on.

    Returned by :func:`select_best_endpoint` to let callers know which
    version to use in the URL path (``v{matched_version}``).
    """

    endpoint: TeaEndpoint
    matched_version: str


def _is_compatible_version(client: _SemVer, server: _SemVer) -> bool:
    """Check if a client version is backward-compatible with a server version.

    Compares only core version (major.minor.patch), ignoring prerelease tags.

    Rules:
    - Same major version.
    - Server core version (major.minor.patch) must be <= client core version.
    """
    if client.major != server.major:
        return False
    # Compare only (major, minor, patch), ignoring prerelease/build metadata
    client_core = (client.major, client.minor, client.patch)
    server_core = (server.major, server.minor, server.patch)
    return client_core >= server_core


def select_best_endpoint(well_known: TeaWellKnown, supported_version: str) -> VersionedEndpoint:
    """Select the best compatible endpoint using flexible version negotiation.

    First tries exact match (existing behavior). If no exact match, finds
    endpoints with backward-compatible versions: the client can downgrade to
    a server with a lower version in the same compatibility family, but never
    connects to a server with a higher version than the client supports.

    Args:
        well_known: Parsed .well-known/tea document.
        supported_version: SemVer version string the client supports.

    Returns:
        The best matching endpoint with the server version it was matched on.

    Raises:
        TeaDiscoveryError: If no compatible endpoint is found.
    """
    try:
        target = _SemVer.parse(supported_version)
    except ValueError as exc:
        raise TeaDiscoveryError(f"Invalid version string {supported_version!r}: {exc}") from exc

    # Phase 1: exact match — delegate to select_endpoints
    try:
        exact = select_endpoints(well_known, supported_version)
        return VersionedEndpoint(endpoint=exact[0], matched_version=supported_version)
    except TeaDiscoveryError:
        pass  # fall through to Phase 2 (compatible match)

    # Phase 2: compatible match (client >= server in same family)
    compatible: list[tuple[_SemVer, TeaEndpoint]] = []
    for ep in well_known.endpoints:
        best_v_for_ep: _SemVer | None = None
        for v_str in ep.versions:
            try:
                v = _SemVer.parse(v_str)
            except ValueError:
                continue
            if _is_compatible_version(target, v) and (best_v_for_ep is None or v > best_v_for_ep):
                best_v_for_ep = v
        if best_v_for_ep is not None:
            compatible.append((best_v_for_ep, ep))

    if not compatible:
        available = {v for ep in well_known.endpoints for v in ep.versions}
        raise TeaDiscoveryError(
            f"No compatible endpoint found for version {supported_version!r}. Available versions: {sorted(available)}"
        )

    # Prefer highest compatible version, then highest priority
    compatible.sort(
        key=_endpoint_sort_key,
        reverse=True,
    )
    best_ver, best_ep = compatible[0]
    logger.info(
        "No exact match for %s; negotiated to compatible server version %s",
        supported_version,
        best_ver,
    )
    warnings.warn(
        f"No exact version match for {supported_version!r}; negotiated to server version {best_ver}. "
        f"The server may not support all features of the requested version.",
        stacklevel=2,
    )
    return VersionedEndpoint(endpoint=best_ep, matched_version=str(best_ver))


__all__ = [
    "VersionedEndpoint",
    "fetch_well_known",
    "parse_tei",
    "select_best_endpoint",
    "select_endpoint",
    "select_endpoints",
]
