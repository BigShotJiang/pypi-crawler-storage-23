Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/functools_simpletest.py
    :caption: examples/functools_simpletest.py
    :linenos:
