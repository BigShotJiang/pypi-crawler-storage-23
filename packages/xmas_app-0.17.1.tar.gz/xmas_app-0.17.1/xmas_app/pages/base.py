from fastapi import Request
from nicegui import binding, ui

from xmas_app.settings import get_settings


class BasePage:
    """Base class providing some defaults."""

    client_is_qgis = binding.BindableProperty()

    def __init__(self, request: Request) -> None:
        """Initializes the BasePage.

        Args:
            request: a `fastapi.Request` for e.g. header extraction
        """
        ui.colors(primary="rgb(157 157 156)", secondary="rgb(57 92 127)")
        ui.button.default_props("flat square no-caps")
        ui.dropdown_button.default_props("flat square no-caps")
        ui.select.default_props("square filled dense")
        request.headers.get("user-agent", None)
        self.client_is_qgis = request.headers.get("user-agent", "").startswith(
            get_settings().qgis_plugin_name
        )
        if self.client_is_qgis:
            ui.add_head_html(
                '<script src="qrc:///qtwebchannel/qwebchannel.js"></script>'
            )
