"""Remove unique index from doc filename.

Allow files with the same name for different plans.

Revision ID: 5bc8757a75a8
Revises: 53a0d4789886
Create Date: 2026-03-02 19:59:00.908118

"""

from typing import Sequence, Union

from alembic import op
from xplan_tools.settings import get_settings

# revision identifiers, used by Alembic.
revision: str = "5bc8757a75a8"
down_revision: Union[str, Sequence[str], None] = "53a0d4789886"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

schema = get_settings().db_schema or "public"


def upgrade() -> None:
    """Upgrade schema."""
    op.drop_index(
        op.f("ix_docs_filename"), table_name="docs", schema=schema, if_exists=True
    )
    op.create_index(
        op.f("ix_docs_filename"),
        "docs",
        ["filename"],
        schema=schema,
    )


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(
        op.f("ix_docs_filename"), table_name="docs", schema=schema, if_exists=True
    )
    op.create_index(
        op.f("ix_docs_filename"), "docs", ["filename"], schema=schema, unique=True
    )
