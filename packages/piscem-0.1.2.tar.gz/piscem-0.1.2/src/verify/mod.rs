pub mod index_compare;
pub mod parity;
pub mod rad_compare;
