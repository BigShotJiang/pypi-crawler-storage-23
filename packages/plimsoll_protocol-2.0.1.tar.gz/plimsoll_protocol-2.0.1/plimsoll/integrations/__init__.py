"""Plimsoll Protocol Framework Integrations — Drop-in safety for any AI agent stack."""
