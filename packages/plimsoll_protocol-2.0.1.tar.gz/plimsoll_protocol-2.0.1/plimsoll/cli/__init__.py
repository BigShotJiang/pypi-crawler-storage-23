"""Plimsoll Protocol CLI — Zero-friction setup for the AI agent circuit breaker."""
