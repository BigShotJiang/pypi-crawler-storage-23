"""Plimsoll Protocol Price Oracles — Currency normalization for multi-chain physics."""
