# py-yprinciple-gen

We do not use the AGENTS.md file but use wikipush with wiki with the id "wiki"
The relevant information is in https://wiki.bitplan.com/index.php/Py-yprinciple-gen
