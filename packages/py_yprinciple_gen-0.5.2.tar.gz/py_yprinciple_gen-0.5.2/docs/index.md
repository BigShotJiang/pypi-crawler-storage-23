# py-yprinciple-gen API Documentation

::: yprinciple
    options:
      show_submodules: true
