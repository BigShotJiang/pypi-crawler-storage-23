"""Allow running as `python -m zhi`."""

from __future__ import annotations

from zhi.cli import main

main()
