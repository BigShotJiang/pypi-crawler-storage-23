# API reference

::: pgserviceparser

## GUI Widget

::: pgserviceparser.gui.PGServiceParserWidget
