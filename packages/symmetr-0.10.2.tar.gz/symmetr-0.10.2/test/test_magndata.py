from symmetr.magndata import get_magndata_structure

struct = get_magndata_structure('3.2')

print(struct)