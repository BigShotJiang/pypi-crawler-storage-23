"""Evaluation package for the Phoneme Discovery benchmark."""

from .evaluate import phoneme_discovery

__all__ = ["phoneme_discovery"]
