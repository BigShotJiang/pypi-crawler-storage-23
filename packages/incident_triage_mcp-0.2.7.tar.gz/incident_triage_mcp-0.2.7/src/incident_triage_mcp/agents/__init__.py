"""LangGraph-based local agents for incident triage."""

