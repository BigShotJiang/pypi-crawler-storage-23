# make_xlsx

Skriptet genererar en excelfil med timrapporter. Om man kör testet får man:

!["excel skärmdump"](./screen_shot.png)

