"""
Orthogonality Analysis Module for FactorDB

This module provides comprehensive factor orthogonality analysis capabilities
for identifying and eliminating redundant factors from a factor pool.

The analysis is organized in three phases:

Phase 1: Global Correlation Check
- Correlation Matrix Heatmap (Spearman rank correlation)
- Effective Number of Factors (PCA-based eigenvalue analysis)

Phase 2: Clustering & Structure Analysis
- Hierarchical Clustering Analysis
- Minimum Spanning Tree (MST) Analysis

Phase 3: Selection & Pruning
- Variance Inflation Factor (VIF) within clusters
- Marginal IC Analysis (stepwise selection)

Example usage:
```python
from factordb.orthogonality import OrthogonalityRunner

# Initialize runner with config
runner = OrthogonalityRunner(
    asset_type=AssetType.STOCK,
    factor_type=FactorType.DAILY
)

# Run full analysis
analysis_id, report = runner.run(market_data=market_df)

# Get results
print(f"Effective factors: {report.effective_n.effective_n_90}")
print(f"Selected factors: {len(report.final_selected_factors)}")
print(f"Removed factors: {len(report.removed_factors)}")
```
"""

from .correlation_analyzer import (
    CorrelationAnalyzer,
    CorrelationAnalysisResult,
    EffectiveFactorResult,
)

from .clustering_analyzer import (
    ClusteringAnalyzer,
    ClusterInfo,
    HierarchicalClusteringResult,
    MSTEdge,
    MSTResult,
)

from .selection_analyzer import (
    SelectionAnalyzer,
    VIFResult,
    ClusterVIFResult,
    MarginalICResult,
    SelectionResult,
)

from .orthogonality_analyzer import (
    OrthogonalityAnalyzer,
    OrthogonalityReport,
)

from .runner import (
    OrthogonalityRunner,
    load_orthogonality_config,
)

__all__ = [
    # Runner (main entry point)
    "OrthogonalityRunner",
    "load_orthogonality_config",
    
    # Main analyzer
    "OrthogonalityAnalyzer",
    "OrthogonalityReport",
    
    # Phase 1: Correlation Analysis
    "CorrelationAnalyzer",
    "CorrelationAnalysisResult",
    "EffectiveFactorResult",
    
    # Phase 2: Clustering Analysis
    "ClusteringAnalyzer",
    "ClusterInfo",
    "HierarchicalClusteringResult",
    "MSTEdge",
    "MSTResult",
    
    # Phase 3: Selection Analysis
    "SelectionAnalyzer",
    "VIFResult",
    "ClusterVIFResult",
    "MarginalICResult",
    "SelectionResult",
]
