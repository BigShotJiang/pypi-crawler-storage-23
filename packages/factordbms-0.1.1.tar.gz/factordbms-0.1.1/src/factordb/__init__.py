"""
FactorDB - A comprehensive factor library management system
"""

from .core.factor import BaseFactor, MinedFactor, ExpressionFactor, CustomFactor, FactorMetadata
from .core.factor_manager import FactorManager
from .core.config import FactorDBConfig, FactorType, AssetType
from .core.expression import ExpressionNormalizer, ExpressionCalculator, ExpressionParser

# Orthogonality analysis module
from .orthogonality import (
    OrthogonalityAnalyzer,
    OrthogonalityReport,
    CorrelationAnalyzer,
    ClusteringAnalyzer,
    SelectionAnalyzer,
)

__version__ = "0.1.1"
__all__ = [
    # Core classes
    "BaseFactor",
    "MinedFactor",
    "ExpressionFactor",
    "CustomFactor",
    "FactorMetadata",
    "FactorManager",
    "FactorDBConfig",
    "FactorType",
    "AssetType",
    # Expression tools
    "ExpressionNormalizer",
    "ExpressionCalculator",
    "ExpressionParser",
    # Orthogonality analysis
    "OrthogonalityAnalyzer",
    "OrthogonalityReport",
    "CorrelationAnalyzer",
    "ClusteringAnalyzer",
    "SelectionAnalyzer",
]
