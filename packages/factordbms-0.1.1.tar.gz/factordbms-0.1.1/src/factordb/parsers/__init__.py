"""
Parsers module for FactorDB

This module provides parsers for different factor mining framework results.
"""

from .base_parser import BaseFactorParser
from .gpfactor_parser import GPFactorParser
from .masfactor_miner_parser import MasfactorMinerParser
from .parser_factory import get_parser, parse_factor_file, detect_framework, parse_multiple_files

__all__ = [
    "BaseFactorParser",
    "GPFactorParser",
    "MasfactorMinerParser",
    "get_parser",
    "parse_factor_file",
    "detect_framework",
    "parse_multiple_files",
]
