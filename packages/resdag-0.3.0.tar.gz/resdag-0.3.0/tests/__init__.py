"""Test suite for resdag."""
