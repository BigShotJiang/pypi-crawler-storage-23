# Work-In-Progress (WIP)

Active investigations, design discussions, and unresolved issues.

## Contents

Files here represent:
- Design decisions being explored
- Bugs or features under investigation
- Analysis that hasn't yet been implemented
- Discussion notes that may lead to GitHub issues

## Status

Files in this directory are **not finalized** and may be:
- Moved to docs/workflow/completed/ when implemented
- Converted to GitHub issues for formal tracking
- Deleted if the approach is abandoned

Keep these notes concise and link to related GitHub issues when possible.
