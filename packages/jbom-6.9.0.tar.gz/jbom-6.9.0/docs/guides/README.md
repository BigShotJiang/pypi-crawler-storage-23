# Guides

User-facing and developer-facing guides for working with jBOM.

## Contents

- **USER_GUIDE.md** - Instructions for using jBOM as an end user
- **DEVELOPER_GUIDE.md** - Setup and contribution guide for developers

These guides provide practical, step-by-step instructions for common tasks.
