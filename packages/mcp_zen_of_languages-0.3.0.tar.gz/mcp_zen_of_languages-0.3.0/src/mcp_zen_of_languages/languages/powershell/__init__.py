"""Powershell module."""

from mcp_zen_of_languages.languages.powershell.analyzer import PowerShellAnalyzer

__all__ = ["PowerShellAnalyzer"]
