  /* --- New chat --- */
  window.newChat=function(){
    window.newSession();
  };
