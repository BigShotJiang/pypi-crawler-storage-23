This module extends the functionality of the OCA shop by creating
a redirect to the latest shop page in https://apps.odoo-community.org
