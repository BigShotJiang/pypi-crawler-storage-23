# ARM Repository Template
Basic repository template with required security workflows
