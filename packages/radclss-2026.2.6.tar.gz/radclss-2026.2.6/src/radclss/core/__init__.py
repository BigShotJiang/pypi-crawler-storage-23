"""
=============================
 radclss.core package
=============================

This package contains the core functions for RadCLss.

... autosummary::
    :toctree: generated/

    radclss_core

"""

from .radclss_core import radclss  # noqa: F401

__all__ = ["radclss"]
