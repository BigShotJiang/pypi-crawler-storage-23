"""Release and packaging command registration."""

import click


def register_release_commands(cli: click.Group) -> None:
    """Register connector packaging and publishing commands."""
    from .package_cmd import package_command
    from .publish_cmd import publish_command

    cli.add_command(publish_command, name="publish")
    cli.add_command(package_command, name="package")


__all__ = ["register_release_commands"]
