"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.agentic.do_cmd import *  # noqa: F401,F403
from centris_sdk.cli.commands.agentic.do_cmd import _get_api_key, _get_api_url  # noqa: F401
