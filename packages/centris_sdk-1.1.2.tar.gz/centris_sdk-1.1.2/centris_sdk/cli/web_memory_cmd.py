"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.agentic.web_memory_cmd import *  # noqa: F401,F403
