"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.catalog.update_cmd import *  # noqa: F401,F403
