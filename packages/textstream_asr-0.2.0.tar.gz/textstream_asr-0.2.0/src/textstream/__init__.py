"""TextStream — Live speech-to-text streaming on Apple Silicon."""

__version__ = "0.2.0"
