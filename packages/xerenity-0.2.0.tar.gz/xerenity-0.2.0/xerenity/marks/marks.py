class Marks:
    """
    Access market marks snapshots from the market_marks table.

    Usage:
        x = Xerenity(username, password)
        snap = x.marks.latest()
        snap = x.marks.snapshot("2026-03-03")
    """

    def __init__(self, connection):
        self._conn = connection

    def snapshot(self, fecha: str) -> dict:
        """
        Fetch the marks snapshot for a specific date.

        Args:
            fecha: ISO date string, e.g. '2026-03-03'

        Returns:
            dict with keys: fecha, fx_spot, sofr_on, ibr, sofr, ndf
            or None if no data for that date.
        """
        result = (
            self._conn.supabase.table("market_marks")
            .select("*")
            .eq("fecha", fecha)
            .limit(1)
            .execute()
        )
        data = result.data
        return data[0] if data else None

    def latest(self) -> dict:
        """
        Fetch the most recent marks snapshot.

        Returns:
            dict with keys: fecha, fx_spot, sofr_on, ibr, sofr, ndf
            or None if table is empty.
        """
        result = (
            self._conn.supabase.table("market_marks")
            .select("*")
            .order("fecha", desc=True)
            .limit(1)
            .execute()
        )
        data = result.data
        return data[0] if data else None
