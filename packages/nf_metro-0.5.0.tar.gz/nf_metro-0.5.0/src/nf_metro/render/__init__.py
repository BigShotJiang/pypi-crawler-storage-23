"""SVG rendering for metro maps."""

from nf_metro.render.svg import render_svg

__all__ = ["render_svg"]
