import pytest
from oaa.settings import config
from oaa.settings_utils import SourceType
# Config file config-v2-csv-push describes pushing a csv file directly
# to Veza via the CSV uploader. It still needs a mapping_filepath because it
# will create and update the mapping on the datasource.


@pytest.fixture
def provider_id():
    yield '01994dbd-5551-729b-ab82-8d5714cee692'


@pytest.fixture
def _config():
    config.update(config_file='./tests/config-v2-csv-push.yaml')

    return config


def test_config_settings(_config, provider_id):
    """TODO: Docstring for test_config_settings.

    :multi_db_stream_config: TODO
    :returns: TODO

    """
    assert _config.sources['users'].source_type == SourceType.csv_push
    assert _config.sources['users'].csv_provider_id == provider_id


def test_get_none_provider(_config):
    config.sources['users'].csv_provider_id = 'invalid'
    api_mapping = _config.sources['users'].get_api_mapping()
    assert api_mapping is None


def test_get_mapping_from_api(_config):

    api_mapping = _config.sources['users'].get_api_mapping()

    assert api_mapping.template_type == 'hris'
    assert api_mapping.column_mappings

    for cm in api_mapping.column_mappings:
        assert cm.column_name or cm.column_name == ''


def test_invalid_csv_to_mapping(_config, provider_id):
    """TODO: Docstring for test_config_settings.

    :multi_db_stream_config: TODO
    :returns: TODO

    """
    assert _config.sources['users_invalid'].source_type == SourceType.csv_push
    assert _config.sources['users_invalid'].csv_provider_id == provider_id

    # from oaa.app_runners.custom_app import CustomAppRunner
    # runner = CustomAppRunner()

    # runner.validate_source_to_mapping(

    source = _config.sources['users_invalid']
    is_valid, problems = source.validate_to_api_csv_mapping()

    assert is_valid is False


def test_valid_csv_to_mapping(_config, provider_id):
    """TODO: Docstring for test_config_settings.

    :multi_db_stream_config: TODO
    :returns: TODO

    """
    assert _config.sources['users'].source_type == SourceType.csv_push
    assert _config.sources['users'].csv_provider_id == provider_id

    source = _config.sources['users']
    is_valid, problems = source.validate_to_api_csv_mapping()

    for prob in problems:
        print(prob)
    assert is_valid is True


def test_run_runner(_config, provider_id):
    assert _config.is_csv_push
    from oaa.app_runners.custom_app import CustomAppRunner
    from oaaclient.templates import CustomApplication

    runner = CustomAppRunner()
    runner.run()

    # assert isinstance(runner._provider_object, CustomApplication)

    for source_name, source in config.sources.items():
        assert source.csv_provider_id
        provider = source.get_provider()
        assert isinstance(provider, dict)
        assert provider['id'] == provider_id
    assert runner._get('_created_oaa_objects') is False

    assert runner._get('_created_provider') is False

