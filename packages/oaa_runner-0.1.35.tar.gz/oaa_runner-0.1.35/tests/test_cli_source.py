import pytest
from oaa.app_runners.custom_app import CustomAppRunner
from oaa.hooks.decorators import HOOK_EVENTS, OAAHookEvent
import logging
logging.basicConfig(log_level=logging.debug)
logger = logging.getLogger(__name__)


@pytest.fixture
def _config(config):
    config.update(config_file='./tests/config-with-cli-source.yaml')

    yield config
    config.reset()

# If hooks are defined in a logic module, then we should be able to find them
# in oaa.app_runners.decorators.HOOK_EVENTS


def test_pre_transform_in_hooks(_config):
    assert _config.sources
    assert HOOK_EVENTS[OAAHookEvent.PRE_TRANSFORM]
    import myhooks
    assert myhooks.do_something in HOOK_EVENTS[OAAHookEvent.PRE_TRANSFORM]['hooks']
    assert HOOK_EVENTS[OAAHookEvent.PRE_TRANSFORM]['results'] == []


def test_hooks_run(_config):
    assert _config.sources
    runner = CustomAppRunner()
    runner.run()

    assert 'wacka' in HOOK_EVENTS[OAAHookEvent.PRE_TRANSFORM]['results']

def test_source(_config):
    runner = CustomAppRunner()
    runner.run()

    ran = False

    for f in _config.sources['files'].records:
        assert f.FILENAME
        assert f.resource_type == 'file'
        ran = True
    assert ran
