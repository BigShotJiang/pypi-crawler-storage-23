from oaa.models import FieldMapping
from oaa.models import DynamicTranformOptions_Enum
import pytest

YESES = [
        'y',
        'Y',
        'Yes',
        'True',
        '1',
        1
]


@pytest.fixture(params=YESES)
def include(request):
    yield request.param


@pytest.fixture(params=DynamicTranformOptions_Enum)
def transform_option(request):
    yield str(request.param.name)


@pytest.fixture(params=YESES)
def is_custom(request):
    yield request.param


@pytest.mark.parametrize('none_value', ['none', 'None', None])
def test_field_mapping_None(none_value, include, is_custom):
    mapping = {
        'include': include,
        'source_field': 'EMPL_NO',
        'veza_obj': 'Employee',
        'is_custom': is_custom,
        'destination_field': 'employee_number',
        'transform': none_value
    }

    mapping_obj = FieldMapping.model_validate(mapping)

    assert mapping_obj


def test_field_mapping_none(include, is_custom):
    mapping = {
        'include': include,
        'source_field': 'EMPL_NO',
        'veza_obj': 'Employee',
        'is_custom': is_custom,
        'destination_field': 'employee_number',
        'transform': 'None'
    }

    mapping_obj = FieldMapping.model_validate(mapping)

    assert mapping_obj


# def test_field_mapping_other_transform(include, is_custom, transform_option):
def test_field_mapping_other_transform(include, is_custom, transform_option):
    mapping = {
        'include': include,
        'source_field': 'EMPL_NO',
        'veza_obj': 'Employee',
        'is_custom': is_custom,
        'destination_field': 'employee_number',
        'transform': transform_option
    }

    mapping_obj = FieldMapping.model_validate(mapping)

    assert mapping_obj
