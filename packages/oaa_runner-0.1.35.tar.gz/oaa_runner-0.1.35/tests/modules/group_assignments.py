

def run(provider, sources=None, config=None):

    for group in sources['groups'].records:

        for group_user in group.username.split(','):
            user = provider.local_users[group_user]
            user.add_group(group.id)

    return True
