import petl
import requests
from dotenv import load_dotenv
from oaa.hooks.decorators import hook, OAAHookEvent
from oaa.hooks.decorators import hook, OAAHookEvent

load_dotenv()


@hook(event=OAAHookEvent.PRE_TRANSFORM, keep_results=True)
def do_something(event, source=None, **kwargs):
    """TODO: Docstring for return_wacko.
    :returns: TODO

    """

    return 'wacka'

def some_function_to_fetch_data(connection=None, source=None, **kwargs):
    return something

def fetch(connection=None, source=None, **kwargs):
    '''
    Fetch the data. This is the function that is called by oaa.

    '''

    res = some_function_to_fetch_data(connection=connection, source=source)

    return petl.fromdicts(res)
