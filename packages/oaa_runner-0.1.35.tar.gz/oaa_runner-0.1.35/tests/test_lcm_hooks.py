import pytest
from oaa.app_runners.custom_app import CustomAppRunner
from oaa.hooks.decorators import HOOK_EVENTS, OAAHookEvent
import logging
logging.basicConfig(log_level=logging.debug)
logger = logging.getLogger(__name__)


@pytest.fixture
def _config(config):
    HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['results'] = []
    config.update(config_file='./tests/config-lcm-sources.yaml')

    yield config
    config.reset()

# If hooks are defined in a logic module, then we should be able to find them
# in oaa.app_runners.decorators.HOOK_EVENTS


def test_lcm_create_user_in_events(_config):
    # runner = CustomAppRunner()
    # runner.run(push_to_oaa=False)
    assert _config.sources
    import lcm_test
    assert HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['hooks']
    assert lcm_test.hook_create_user in HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['hooks']
    assert HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['results'] == []


def test_hooks_run(_config):
    assert _config.sources
    runner = CustomAppRunner()
    runner.lcm_create_user({'username': 'kevin'})
    assert ['kevin'] == HOOK_EVENTS[OAAHookEvent.LCM_CREATE_USER]['results']
