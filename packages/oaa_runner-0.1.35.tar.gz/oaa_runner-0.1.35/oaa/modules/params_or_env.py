import os
from dotenv import load_dotenv
# from oaa.hooks.decorators import hook, OAAHookEvent
load_dotenv()


def params_or_env(connection, source, key):
    if key in os.environ:
        return os.environ[key]

    if connection.params:
        if key in connection.params:
            return connection.params[key]

    if source.params:
        if key in source.params:
            return source.params[key]

    return
