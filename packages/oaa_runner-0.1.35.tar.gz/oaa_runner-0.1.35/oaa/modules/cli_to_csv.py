#!/usr/bin/env python
# -*- coding: utf-8 -*-

from oaa.source.cli import CLIRunner

import logging
logger = logging.getLogger(__name__)


def fetch(connection=None, source=None, **kwargs):

    if not source.params['cmd'] or not source.params['fieldnames']:
        logger.error('cmd and fieldnames required to query via cli')

    runner = CLIRunner(source=source, connection=connection)

    result = runner.run_cmd(cmd=source.params['cmd'],
                            headers=source.params['fieldnames'],
                            # **connection.params,
                            # **source.params,
                            **kwargs)

    return result
