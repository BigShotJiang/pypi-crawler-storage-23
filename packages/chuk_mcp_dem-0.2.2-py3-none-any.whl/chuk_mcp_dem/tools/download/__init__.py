"""Download tools for DEM data."""

from .api import register_download_tools

__all__ = ["register_download_tools"]
