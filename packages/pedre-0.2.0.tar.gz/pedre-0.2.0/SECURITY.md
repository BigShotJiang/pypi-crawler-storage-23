# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in Pedre, please do **not** open a public
GitHub issue.

Instead, report it privately by:

- Opening a GitHub Security Advisory (preferred), or
- Contacting the maintainer via GitHub direct message

Please include:
- A description of the vulnerability
- Steps to reproduce, if applicable
- Any relevant logs or screenshots

## Supported Versions

Pedre is currently developed on a best-effort basis.
Only the latest released version is supported with security fixes.

## Disclosure Policy

Reported vulnerabilities will be reviewed as time permits.
There is no guaranteed response time, but responsible disclosure is appreciated.
