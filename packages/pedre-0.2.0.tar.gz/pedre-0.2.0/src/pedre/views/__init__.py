"""Game views package."""

from pedre.views.game_view import GameView

__all__ = ["GameView"]
