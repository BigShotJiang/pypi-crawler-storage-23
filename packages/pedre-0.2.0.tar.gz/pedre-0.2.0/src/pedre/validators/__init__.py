"""Validators for game assets (scripts, dialogs, maps)."""

from pedre.validators.base import ValidationResult, Validator

__all__ = ["ValidationResult", "Validator"]
