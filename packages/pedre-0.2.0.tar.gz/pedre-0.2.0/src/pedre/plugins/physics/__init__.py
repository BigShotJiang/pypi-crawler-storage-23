"""Physics plugin.

This module provides the PhysicsPlugin class, which handles collision detection
and resolution.
"""

from pedre.plugins.physics.base import PhysicsBasePlugin
from pedre.plugins.physics.plugin import PhysicsPlugin

__all__ = ["PhysicsBasePlugin", "PhysicsPlugin"]
