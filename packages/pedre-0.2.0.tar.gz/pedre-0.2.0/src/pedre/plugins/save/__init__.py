"""Save/load plugin module."""

from pedre.plugins.save.base import GameSaveData, SaveBasePlugin
from pedre.plugins.save.plugin import SavePlugin

__all__ = ["GameSaveData", "SaveBasePlugin", "SavePlugin"]
