"""Waypoint management plugin."""

from pedre.plugins.waypoint.base import WaypointBasePlugin
from pedre.plugins.waypoint.plugin import WaypointPlugin

__all__ = ["WaypointBasePlugin", "WaypointPlugin"]
