"""Actions for NPC plugin."""

import logging
from typing import TYPE_CHECKING, Any, Self

from pedre.actions import Action, WaitForConditionAction
from pedre.actions.registry import ActionParseError, ActionRegistry
from pedre.plugins.npc.sprites import AnimatedNPC
from pedre.types import EntityReference

if TYPE_CHECKING:
    from pedre.plugins.game_context import GameContext


logger = logging.getLogger(__name__)


@ActionRegistry.register
class MoveNPCAction(Action):
    """Move one or more NPCs to a waypoint.

    This action initiates NPC movement to a named waypoint location. The waypoint
    is resolved to tile coordinates from the game's waypoint registry, and the NPC
    pathfinding plugin handles the actual movement.

    The action completes immediately after initiating the movement - it doesn't
    wait for the NPC to arrive. Use WaitForNPCMovementAction if you need to wait
    for the NPC to reach the destination before proceeding.

    Multiple NPCs can be moved simultaneously by providing a list of names. This is
    useful for coordinated group movements.

    Example usage:
        # Single NPC
        {
            "name": "move_npc",
            "npcs": ["martin"],
            "waypoint": "town_square"
        }

        # Multiple NPCs
        {
            "name": "move_npc",
            "npcs": ["martin", "yema"],
            "waypoint": "forest_entrance"
        }
    """

    name = "move_npc"

    def __init__(
        self,
        npc_names: list[str],
        waypoint: str,
    ) -> None:
        """Initialize NPC movement action.

        Args:
            npc_names: List of NPC names to move.
            waypoint: Name of waypoint to move to.
        """
        self.npc_names = npc_names
        self.waypoint = waypoint
        self.started = False

    def execute(self, context: GameContext) -> bool:
        """Start NPC movement."""
        if not self.started:
            # Resolve waypoint to pixel coordinates
            waypoints = context.waypoint_plugin.get_waypoints()
            if self.waypoint in context.waypoint_plugin.get_waypoints():
                x, y = waypoints[self.waypoint]
                logger.debug(
                    "MoveNPCAction: Resolved waypoint '%s' to position (%.1f, %.1f)",
                    self.waypoint,
                    x,
                    y,
                )
            else:
                logger.warning("MoveNPCAction: Waypoint '%s' not found", self.waypoint)
                return True  # Complete immediately on error

            # Move all NPCs to the target
            npc_plugin = context.npc_plugin
            for npc_name in self.npc_names:
                npc_plugin.move_npc_to_position(npc_name, x, y)
                logger.debug("MoveNPCAction: Moving %s to (%.1f, %.1f)", npc_name, x, y)

            self.started = True

        # Movement is asynchronous, completes immediately
        return True

    def reset(self) -> None:
        """Reset the action."""
        self.started = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create MoveNPCAction from a dictionary."""
        npcs = data.get("npcs")
        waypoint = data.get("waypoint")

        if not npcs or (isinstance(npcs, list) and len(npcs) == 0):
            msg = "missing required 'npcs' field (non-empty list)"
            raise ActionParseError(msg)
        if not isinstance(npcs, list):
            msg = "'npcs' must be a list"
            raise ActionParseError(msg)
        if not all(isinstance(item, str) for item in npcs):
            msg = "'npcs' items must be strings"
            raise ActionParseError(msg)

        if not waypoint:
            msg = "missing required 'waypoint' field"
            raise ActionParseError(msg)
        if not isinstance(waypoint, str):
            msg = "'waypoint' must be a string"
            raise ActionParseError(msg)

        return cls(npc_names=npcs, waypoint=waypoint)

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        refs = set()

        refs.update([EntityReference(type="npc", name=npc) for npc in self.npc_names])
        refs.add(EntityReference(type="waypoint", name=self.waypoint))

        return refs


@ActionRegistry.register
class StartAppearAnimationAction(Action):
    """Start the appear animation for one or more NPCs.

    This action makes NPCs visible that have their sprite.visible property set to False.
    Hidden NPCs are not rendered and cannot be interacted with by the player. When revealed,
    the NPCs become visible, are added to the collision wall list.

    NPCs can be hidden by setting sprite.visible = False during initialization in the map
    data or programmatically. AnimatedNPCs will also play their appear animation when revealed.

    Example usage:
        {
            "name": "start_appear_animation",
            "npcs": ["martin", "yema", "romi"]
        }
    """

    name = "start_appear_animation"

    def __init__(self, npc_names: list[str]) -> None:
        """Initialize NPC appear animation action.

        Args:
            npc_names: List of NPC names to reveal.
        """
        self.npc_names = npc_names
        self.executed = False

    def execute(self, context: GameContext) -> bool:
        """Reveal NPCs and show particle effects."""
        if not self.executed:
            npc_plugin = context.npc_plugin
            npc_plugin.show_npcs(self.npc_names)
            self.executed = True
            logger.debug("StartAppearAnimationAction: Revealed NPCs %s", self.npc_names)

        return True

    def reset(self) -> None:
        """Reset the action."""
        self.executed = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create StartAppearAnimationAction from a dictionary."""
        npcs = data.get("npcs")
        if not npcs or (isinstance(npcs, list) and len(npcs) == 0):
            msg = "missing required 'npcs' field (non-empty list)"
            raise ActionParseError(msg)
        if not isinstance(npcs, list):
            msg = "'npcs' must be a list"
            raise ActionParseError(msg)
        if not all(isinstance(item, str) for item in npcs):
            msg = "'npcs' items must be strings"
            raise ActionParseError(msg)

        return cls(npc_names=npcs)

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        refs = set()

        refs.update([EntityReference(type="npc", name=npc) for npc in self.npc_names])
        return refs


@ActionRegistry.register
class AdvanceDialogAction(Action):
    """Advance an NPC's dialog level.

    This action increments an NPC's dialog level by 1, which is used to track progression
    through conversation stages. NPCs can have different dialog text and behaviors at
    different levels, allowing for branching conversations and story progression.

    The dialog level is stored persistently in the NPC's state and is commonly used
    in combination with dialog conditions to show different content based on player progress.

    Example usage:
        {
            "name": "advance_dialog",
            "npc": "martin"
        }
    """

    name = "advance_dialog"

    def __init__(self, npc_name: str) -> None:
        """Initialize dialog advance action.

        Args:
            npc_name: Name of the NPC whose dialog to advance.
        """
        self.npc_name = npc_name
        self.executed = False

    def execute(self, context: GameContext) -> bool:
        """Advance the dialog."""
        if not self.executed:
            npc_plugin = context.npc_plugin
            npc_plugin.advance_dialog(self.npc_name)
            self.executed = True
            logger.debug("AdvanceDialogAction: Advanced %s dialog", self.npc_name)

        return True

    def reset(self) -> None:
        """Reset the action."""
        self.executed = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create AdvanceDialogAction from a dictionary."""
        npc = data.get("npc")
        if not npc:
            msg = "missing required 'npc' field"
            raise ActionParseError(msg)
        if not isinstance(npc, str):
            msg = "'npc' must be a string"
            raise ActionParseError(msg)

        return cls(npc_name=npc)

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        refs = set()
        refs.update([EntityReference(type="npc", name=self.npc_name)])
        return refs


@ActionRegistry.register
class SetDialogLevelAction(Action):
    """Set an NPC's dialog level to a specific value.

    This action sets an NPC's dialog level to an exact value, unlike AdvanceDialogAction
    which increments by 1. This is useful for jumping to specific conversation states,
    resetting progress, or handling non-linear dialog flows.

    Use this when you need precise control over dialog state, such as when triggering
    special events or skipping conversation stages based on other game conditions.

    Example usage:
        # Jump to a specific dialog stage
        {
            "name": "set_dialog_level",
            "npc": "martin",
            "dialog_level": 5
        }

        # Reset dialog to beginning
        {
            "name": "set_dialog_level",
            "npc": "yema",
            "dialog_level": 0
        }
    """

    name = "set_dialog_level"

    def __init__(self, npc_name: str, level: int) -> None:
        """Initialize set dialog level action.

        Args:
            npc_name: Name of the NPC whose dialog level to set.
            level: The dialog level to set.
        """
        self.npc_name = npc_name
        self.level = level
        self.executed = False

    def execute(self, context: GameContext) -> bool:
        """Set the dialog level."""
        if not self.executed:
            npc_plugin = context.npc_plugin
            npc_state = npc_plugin.get_npcs().get(self.npc_name)
            if npc_state:
                old_level = npc_state.dialog_level
                npc_state.dialog_level = self.level
                logger.debug(
                    "SetDialogLevelAction: Set %s dialog level from %d to %d",
                    self.npc_name,
                    old_level,
                    self.level,
                )
            else:
                logger.warning("SetDialogLevelAction: NPC %s not found", self.npc_name)
            self.executed = True

        return True

    def reset(self) -> None:
        """Reset the action."""
        self.executed = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create SetDialogLevelAction from a dictionary."""
        npc = data.get("npc")
        if not npc:
            msg = "missing required 'npc' field"
            raise ActionParseError(msg)
        if not isinstance(npc, str):
            msg = "'npc' must be a string"
            raise ActionParseError(msg)
        dialog_level = data.get("dialog_level")
        if not dialog_level:
            msg = "missing required 'dialog_level' field"
            raise ActionParseError(msg)

        if not isinstance(dialog_level, int) or isinstance(dialog_level, bool):
            msg = "'dialog_level' must be an int"
            raise ActionParseError(msg)

        return cls(
            npc_name=npc,
            level=dialog_level,
        )

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        refs = set()
        refs.update([EntityReference(type="npc", name=self.npc_name)])
        return refs


@ActionRegistry.register
class SetCurrentNPCAction(Action):
    """Set the current NPC tracking for dialog event attribution.

    This action is necessary when showing dialogs through scripts rather than
    direct player interaction with an NPC. It ensures that when the dialog closes,
    the correct DialogClosedEvent is published with the proper NPC attribution.

    Why this is needed:
    - When a player directly interacts with an NPC, current_npc_name is set automatically
    - When the dialog closes, a DialogClosedEvent is published with that NPC's name and level
    - Scripts can trigger on dialog_closed events to chain actions

    However, when a script shows a dialog (not from direct NPC interaction):
    - current_npc_name would be empty
    - The dialog closed event wouldn't know which NPC it belonged to
    - Subsequent scripts waiting for dialog_closed events for that NPC wouldn't trigger

    Example usage:
        {
            "name": "set_current_npc",
            "npc": "martin"
        }

    This should be used before any scripted dialog action to ensure proper event tracking.
    """

    name = "set_current_npc"

    def __init__(self, npc_name: str) -> None:
        """Initialize set current NPC action.

        Args:
            npc_name: Name of the NPC to set as current for dialog attribution.
        """
        self.npc_name = npc_name
        self.executed = False

    def execute(self, context: GameContext) -> bool:
        """Set the current NPC for dialog event tracking.

        Returns:
            True when the action completes (always completes immediately).
        """
        if not self.executed:
            # Access game view through context to set current NPC
            npc_plugin = context.npc_plugin
            dialog_plugin = context.dialog_plugin
            npc_state = npc_plugin.get_npcs().get(self.npc_name)
            if npc_state:
                dialog_plugin.set_current_npc_name(self.npc_name)
                dialog_plugin.set_current_dialog_level(npc_state.dialog_level)
            logger.debug(
                "SetCurrentNPCAction: Set current NPC to %s at level %d",
                self.npc_name,
                npc_state.dialog_level if npc_state else 0,
            )

            self.executed = True

        return True

    def reset(self) -> None:
        """Reset the action."""
        self.executed = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create SetCurrentNPCAction from a dictionary."""
        npc = data.get("npc")
        if not npc:
            msg = "missing required 'npc' field"
            raise ActionParseError(msg)
        if not isinstance(npc, str):
            msg = "'npc' must be a string"
            raise ActionParseError(msg)
        return cls(npc_name=npc)

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        refs = set()
        refs.update([EntityReference(type="npc", name=self.npc_name)])
        return refs


@ActionRegistry.register
class WaitForNPCMovementAction(WaitForConditionAction):
    """Wait for NPC to complete movement.

    This action pauses script execution until the specified NPC finishes moving
    to their destination. NPCs move asynchronously along paths, so this action
    is necessary when you need to ensure an NPC has arrived before proceeding.

    The action checks that both the NPC's path is empty and the is_moving flag
    is False, ensuring the movement is fully complete.

    Commonly used after MoveNPCAction to coordinate actions that should happen
    when the NPC reaches their destination.

    Example usage in a sequence:
        [
            {"name": "move_npc", "npc": "martin", "waypoint": "town_square"},
            {"name": "wait_for_movement", "npc": "martin"},
            {"name": "dialog", "speaker": "martin", "text": ["I made it!"]}
        ]
    """

    name = "wait_for_movement"

    def __init__(self, npc_name: str) -> None:
        """Initialize NPC movement wait action.

        Args:
            npc_name: Name of the NPC to wait for.
        """
        self.npc_name = npc_name

        def check_movement(ctx: GameContext) -> bool:
            npc_plugin = ctx.npc_plugin
            npc_state = npc_plugin.get_npcs().get(npc_name)
            if not npc_state:
                return True
            # NPC is not moving if path is empty and is_moving is False
            return len(npc_state.path) == 0 and not npc_state.is_moving

        super().__init__(check_movement, f"NPC {npc_name} movement complete")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create WaitForNPCMovementAction from a dictionary."""
        npc = data.get("npc")
        if not npc:
            msg = "missing required 'npc' field"
            raise ActionParseError(msg)
        if not isinstance(npc, str):
            msg = "'npc' must be a string"
            raise ActionParseError(msg)
        return cls(npc_name=npc)

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        refs = set()
        refs.update([EntityReference(type="npc", name=self.npc_name)])
        return refs


@ActionRegistry.register
class WaitForNPCsAppearAction(WaitForConditionAction):
    """Wait for multiple NPCs to complete their appear animations.

    This action pauses script execution until all specified AnimatedNPCs finish
    their appear animation. AnimatedNPCs play a special appear animation when
    they're revealed (see StartAppearAnimationAction), and this action ensures that animation
    completes before proceeding.

    Only AnimatedNPC sprites have appear animations. Regular NPC sprites will be
    considered complete immediately. The action waits for all NPCs in the list
    to finish appearing.

    Commonly used after StartAppearAnimationAction to ensure NPCs have fully materialized
    before starting dialog or other interactions.

    Example usage in a reveal sequence:
        [
            {"name": "start_appear_animation", "npcs": ["martin", "yema"]},
            {"name": "wait_npcs_appear", "npcs": ["martin", "yema"]},
            {"name": "dialog", "speaker": "martin", "text": ["We're here!"]}
        ]
    """

    name = "wait_npcs_appear"

    def __init__(self, npc_names: list[str]) -> None:
        """Initialize NPC appear wait action.

        Args:
            npc_names: List of NPC names to wait for.
        """
        self.npc_names = npc_names

        def check_all_appeared(ctx: GameContext) -> bool:
            npc_plugin = ctx.npc_plugin
            for npc_name in npc_names:
                npc_state = npc_plugin.get_npcs().get(npc_name)
                if not npc_state:
                    continue
                # Check if it's an AnimatedNPC and if appear animation is complete
                if isinstance(npc_state.sprite, AnimatedNPC) and not npc_state.sprite.appear_complete:
                    return False
            # All NPCs have completed their appear animations
            return True

        super().__init__(check_all_appeared, f"NPCs {', '.join(npc_names)} appear complete")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create WaitForNPCsAppearAction from a dictionary."""
        npcs = data.get("npcs")
        if not npcs or (isinstance(npcs, list) and len(npcs) == 0):
            msg = "missing required 'npcs' field (non-empty list)"
            raise ActionParseError(msg)
        if not isinstance(npcs, list):
            msg = "'npcs' must be a list"
            raise ActionParseError(msg)
        if not all(isinstance(item, str) for item in npcs):
            msg = "'npcs' items must be strings"
            raise ActionParseError(msg)
        return cls(npc_names=npcs)

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        refs = set()
        refs.update([EntityReference(type="npc", name=npc) for npc in self.npc_names])
        return refs


@ActionRegistry.register
class WaitForNPCsDisappearAction(WaitForConditionAction):
    """Wait for multiple NPCs to complete their disappear animations.

    This action pauses script execution until all specified AnimatedNPCs finish
    their disappear animation. AnimatedNPCs play a special disappear animation when
    StartDisappearAnimationAction is triggered, and this action ensures that animation
    completes before proceeding.

    Only AnimatedNPC sprites have disappear animations. Regular NPC sprites will be
    considered complete immediately. The action waits for all NPCs in the list
    to finish disappearing.

    Commonly used after StartDisappearAnimationAction to ensure NPCs have fully
    faded away before continuing the script or transitioning scenes.

    Example usage in a disappear sequence:
        [
            {"name": "start_disappear_animation", "npcs": ["martin", "yema"]},
            {"name": "wait_for_npcs_disappear", "npcs": ["martin", "yema"]},
            {"name": "change_scene", "target_map": "Forest.tmx"}
        ]
    """

    name = "wait_for_npcs_disappear"

    def __init__(self, npc_names: list[str]) -> None:
        """Initialize NPC disappear wait action.

        Args:
            npc_names: List of NPC names to wait for.
        """
        self.npc_names = npc_names

        def check_all_disappeared(ctx: GameContext) -> bool:
            npc_plugin = ctx.npc_plugin
            for npc_name in npc_names:
                npc_state = npc_plugin.get_npcs().get(npc_name)
                if not npc_state:
                    continue
                # Check if it's an AnimatedNPC and if disappear animation is complete
                if isinstance(npc_state.sprite, AnimatedNPC) and not npc_state.sprite.disappear_complete:
                    return False
            # All NPCs have completed their disappear animations
            return True

        super().__init__(check_all_disappeared, f"NPCs {', '.join(npc_names)} disappear complete")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create WaitForNPCsDisappearAction from a dictionary."""
        npcs = data.get("npcs")
        if not npcs or (isinstance(npcs, list) and len(npcs) == 0):
            msg = "missing required 'npcs' field (non-empty list)"
            raise ActionParseError(msg)
        if not isinstance(npcs, list):
            msg = "'npcs' must be a list"
            raise ActionParseError(msg)
        if not all(isinstance(item, str) for item in npcs):
            msg = "'npcs' items must be strings"
            raise ActionParseError(msg)

        return cls(npc_names=npcs)

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        refs = set()
        refs.update([EntityReference(type="npc", name=npc) for npc in self.npc_names])
        return refs


@ActionRegistry.register
class StartDisappearAnimationAction(Action):
    """Start the disappear animation for one or more NPCs.

    This action triggers the disappear animation for AnimatedNPCs, which plays
    a visual effect as the NPC fades away. The action also resets the disappear
    event flag so the NPCDisappearEvent can be emitted when the animation completes.

    Only AnimatedNPC sprites have disappear animations. Regular sprites will be
    silently skipped with a warning in the logs.

    This action waits for all NPCs to complete their disappear animations before
    completing. Once the animation finishes, the NPCs are automatically removed
    from the wall collision list so the player can walk through their space.

    Example usage:
        # Single NPC
        {
            "name": "start_disappear_animation",
            "npcs": ["martin"]
        }

        # Multiple NPCs
        {
            "name": "start_disappear_animation",
            "npcs": ["martin", "yema"]
        }
    """

    name = "start_disappear_animation"

    def __init__(self, npc_names: list[str]) -> None:
        """Initialize disappear animation action.

        Args:
            npc_names: List of NPC names to make disappear.
        """
        self.npc_names = npc_names
        self.animation_started = False

    def execute(self, context: GameContext) -> bool:
        """Start the disappear animation and wait for completion."""
        # Start animations for all NPCs on first call
        if not self.animation_started:
            npc_plugin = context.npc_plugin
            for npc_name in self.npc_names:
                npc_state = npc_plugin.get_npcs().get(npc_name)
                if npc_state and isinstance(npc_state.sprite, AnimatedNPC):
                    npc_state.sprite.start_disappear_animation()
                    # Reset the disappear event flag so event can be emitted
                    npc_state.disappear_event_emitted = False
                    logger.debug("StartDisappearAnimationAction: Started disappear animation for %s", npc_name)
                else:
                    logger.warning(
                        "StartDisappearAnimationAction: NPC %s not found or not AnimatedNPC",
                        npc_name,
                    )
            self.animation_started = True

        # Check if all animations have completed
        npc_plugin = context.npc_plugin
        for npc_name in self.npc_names:
            npc_state = npc_plugin.get_npcs().get(npc_name)
            if not npc_state:
                continue
            # Check if it's an AnimatedNPC and if disappear animation is still running
            if isinstance(npc_state.sprite, AnimatedNPC) and not npc_state.sprite.disappear_complete:
                return False
        scene_plugin = context.scene_plugin
        # All animations complete - remove NPCs from walls
        for npc_name in self.npc_names:
            npc_state = npc_plugin.get_npcs().get(npc_name)
            if npc_state and npc_state.sprite:
                scene_plugin.remove_from_wall_list(npc_state.sprite)
                logger.debug("StartDisappearAnimationAction: Removed %s from wall list", npc_name)

        return True

    def reset(self) -> None:
        """Reset the action."""
        self.animation_started = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create StartDisappearAnimationAction from a dictionary."""
        npcs = data.get("npcs")
        if not npcs or (isinstance(npcs, list) and len(npcs) == 0):
            msg = "missing required 'npcs' field (non-empty list)"
            raise ActionParseError(msg)
        if not isinstance(npcs, list):
            msg = "'npcs' must be a list"
            raise ActionParseError(msg)
        if not all(isinstance(item, str) for item in npcs):
            msg = "'npcs' items must be strings"
            raise ActionParseError(msg)
        return cls(npc_names=npcs)

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        refs = set()
        refs.update([EntityReference(type="npc", name=npc) for npc in self.npc_names])
        return refs
