"""Game plugins for managing different aspects of gameplay."""
