"""Actions for camera plugin."""

import logging
from typing import TYPE_CHECKING, Any, Self

from pedre.actions import Action
from pedre.actions.registry import ActionParseError, ActionRegistry
from pedre.types import EntityReference

if TYPE_CHECKING:
    from pedre.plugins.game_context import GameContext
logger = logging.getLogger(__name__)


@ActionRegistry.register
class FollowPlayerAction(Action):
    """Set camera to follow the player.

    This action configures the camera to continuously follow the player sprite.
    The camera will keep tracking the player's position across all frames until
    another camera action changes the follow behavior or the scene changes.

    The action completes immediately after setting the follow mode. The actual
    camera movement happens in CameraPlugin.update() which is called every frame.

    By default, the camera smoothly interpolates to the player's position using
    lerp (creates a slight lag effect). Set smooth=false for instant tracking.

    Example usage:
        # Smooth following (default)
        {
            "name": "follow_player"
        }

        # Instant following (no smoothing)
        {
            "name": "follow_player",
            "smooth": false
        }
    """

    name = "follow_player"

    def __init__(self, *, smooth: bool = True) -> None:
        """Initialize follow player action.

        Args:
            smooth: If True, use smooth interpolation. If False, instant follow.
        """
        self.smooth = smooth
        self.executed = False

    def execute(self, context: GameContext) -> bool:
        """Set camera to follow player."""
        if not self.executed:
            camera_plugin = context.camera_plugin
            camera_plugin.set_follow_player(smooth=self.smooth)
            logger.debug(
                "FollowPlayerAction: Camera now following player (smooth=%s)",
                self.smooth,
            )
            self.executed = True

        return True  # Complete immediately

    def reset(self) -> None:
        """Reset the action."""
        self.executed = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create FollowPlayerAction from a dictionary."""
        smooth = data.get("smooth", True)
        if not isinstance(smooth, bool):
            msg = "'smooth' must be a bool"
            raise ActionParseError(msg)
        return cls(smooth=smooth)


@ActionRegistry.register
class FollowNPCAction(Action):
    """Set camera to follow a specific NPC.

    This action configures the camera to continuously follow a named NPC sprite.
    The camera will keep tracking the NPC's position across all frames until
    another camera action changes the follow behavior or the scene changes.

    This is useful for cutscenes or scripted sequences where you want to focus
    the camera on an NPC rather than the player.

    The action completes immediately after setting the follow mode. The actual
    camera movement happens in CameraPlugin.update() which is called every frame.

    By default, the camera smoothly interpolates to the NPC's position using
    lerp. Set smooth=false for instant tracking.

    If the specified NPC doesn't exist, a warning is logged but the action
    still completes. The camera will not move until a valid target is set.

    Example usage:
        # Smooth following (default)
        {
            "name": "follow_npc",
            "npc": "martin"
        }

        # Instant following (no smoothing)
        {
            "name": "follow_npc",
            "npc": "boss_enemy",
            "smooth": false
        }

    Common pattern - cutscene focusing on NPC:
        [
            {"name": "follow_npc", "npc": "martin"},
            {"name": "dialog", "speaker": "martin", "text": ["Watch this!"]},
            {"name": "wait_for_dialog_close"},
            {"name": "move_npc", "npcs": ["martin"], "waypoint": "destination"},
            {"name": "wait_for_movement", "npc": "martin"},
            {"name": "follow_player"}
        ]
    """

    name = "follow_npc"

    def __init__(self, npc_name: str, *, smooth: bool = True) -> None:
        """Initialize follow NPC action.

        Args:
            npc_name: Name of the NPC to follow.
            smooth: If True, use smooth interpolation. If False, instant follow.
        """
        self.npc_name = npc_name
        self.smooth = smooth
        self.executed = False

    def execute(self, context: GameContext) -> bool:
        """Set camera to follow NPC."""
        if not self.executed:
            camera_plugin = context.camera_plugin
            # Validate NPC exists
            npc_plugin = context.npc_plugin
            npc_state = npc_plugin.get_npc_by_name(self.npc_name)
            if not npc_state:
                logger.warning("FollowNPCAction: NPC '%s' not found", self.npc_name)

            camera_plugin.set_follow_npc(self.npc_name, smooth=self.smooth)
            logger.debug(
                "FollowNPCAction: Camera now following '%s' (smooth=%s)",
                self.npc_name,
                self.smooth,
            )
            self.executed = True

        return True  # Complete immediately

    def reset(self) -> None:
        """Reset the action."""
        self.executed = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create FollowNPCAction from a dictionary."""
        # --- Required: npc ---
        npc = data.get("npc")
        if npc is None:
            msg = "follow_npc: missing required 'npc' field"
            raise ActionParseError(msg)

        if not isinstance(npc, str):
            msg = "follow_npc: 'npc' must be a string"
            raise ActionParseError(msg)

        smooth = data.get("smooth", True)
        if not isinstance(smooth, bool):
            msg = "follow_npc: 'smooth' must be a bool"
            raise ActionParseError(msg)

        return cls(npc_name=npc, smooth=smooth)

    def get_references(self) -> set[EntityReference]:
        """Extract references for validation."""
        return {EntityReference(type="npc", name=self.npc_name)}


@ActionRegistry.register
class StopCameraFollowAction(Action):
    """Stop camera following, keeping it at current position.

    This action disables camera following behavior set by follow_player or
    follow_npc actions. The camera will remain at its current position and
    stop tracking any targets.

    This is useful for:
    - Freezing camera during dialog or cutscenes
    - Manual camera control via other means
    - Creating static camera shots

    The action completes immediately.

    Example usage:
        {
            "name": "stop_camera_follow"
        }

    Example - freeze camera during dialog:
        [
            {"name": "stop_camera_follow"},
            {"name": "dialog", "speaker": "narrator", "text": ["Time stands still..."]},
            {"name": "wait_for_dialog_close"},
            {"name": "follow_player"}
        ]
    """

    name = "stop_camera_follow"

    def __init__(self) -> None:
        """Initialize stop camera follow action."""
        self.executed = False

    def execute(self, context: GameContext) -> bool:
        """Stop camera following."""
        if not self.executed:
            camera_plugin = context.camera_plugin
            camera_plugin.stop_follow()
            logger.debug("StopCameraFollowAction: Camera following stopped")
            self.executed = True

        return True

    def reset(self) -> None:
        """Reset the action."""
        self.executed = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:  # noqa: ARG003
        """Create StopCameraFollowAction from a dictionary."""
        return cls()
