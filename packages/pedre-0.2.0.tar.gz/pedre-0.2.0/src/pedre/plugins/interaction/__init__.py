"""Interaction plugin for handling interactive objects in the game world.

This package provides:
- InteractionPlugin: Core plugin for managing interactive objects
- InteractiveObject: Data class representing an interactive object

Events (registered via INSTALLED_EVENTS):
- ObjectInteractedEvent: Event fired when player interacts with an object

Conditions (registered via INSTALLED_CONDITIONS):
- check_object_interacted: Check if an object has been interacted with

The interaction plugin handles player interactions with objects in the game world,
supporting message dialogs, toggle states, and other interactive behaviors configured
via Tiled map properties.
"""

from pedre.plugins.interaction.base import InteractionBasePlugin, InteractiveObject
from pedre.plugins.interaction.plugin import InteractionPlugin

__all__ = ["InteractionBasePlugin", "InteractionPlugin", "InteractiveObject"]
