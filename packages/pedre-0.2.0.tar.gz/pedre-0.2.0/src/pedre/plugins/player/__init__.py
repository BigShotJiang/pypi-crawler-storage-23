"""Player management plugin.

This module provides the PlayerPlugin class, which handles player spawning,
movement, and animation, along with the AnimatedPlayer sprite class.
"""

from pedre.plugins.player.base import PlayerBasePlugin
from pedre.plugins.player.plugin import PlayerPlugin

__all__ = ["PlayerBasePlugin", "PlayerPlugin"]
