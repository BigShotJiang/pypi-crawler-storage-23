"""Actions for dialog plugin."""

import logging
from typing import TYPE_CHECKING, Any, Self

from pedre.actions import Action, WaitForConditionAction
from pedre.actions.registry import ActionParseError, ActionRegistry
from pedre.conf import settings

if TYPE_CHECKING:
    from pedre.plugins.game_context import GameContext

logger = logging.getLogger(__name__)


@ActionRegistry.register
class DialogAction(Action):
    """Show a dialog to the player.

    This action displays a dialog box with text from a speaker. The dialog
    is handled by the dialog plugin and can consist of multiple pages that
    the player advances through.

    The action completes immediately after queuing the dialog - it doesn't
    wait for the player to finish reading. Use WaitForDialogCloseAction if
    you need to wait for the player to dismiss the dialog before proceeding.

    Example usage:
        {
            "name": "dialog",
            "speaker": "martin",
            "text": ["Hello there!", "Welcome to the game."]
        }

        # With instant display (no letter-by-letter reveal)
        {
            "name": "dialog",
            "speaker": "Narrator",
            "text": ["The world fades to black..."],
            "instant": true
        }

        # With auto-close for cutscenes
        {
            "name": "dialog",
            "speaker": "Narrator",
            "text": ["The adventure begins..."],
            "auto_close": true
        }
    """

    name = "dialog"

    def __init__(
        self,
        speaker: str,
        text: list[str],
        *,
        instant: bool = settings.DIALOG_INSTANT_TEXT_DEFAULT,
        auto_close: bool = settings.DIALOG_AUTO_CLOSE_DEFAULT,
    ) -> None:
        """Initialize dialog action.

        Args:
            speaker: Name of the character speaking.
            text: List of dialog pages to show.
            instant: If True, text appears immediately without letter-by-letter reveal.
                Defaults to settings.DIALOG_INSTANT_TEXT_DEFAULT.
            auto_close: If True, dialog automatically closes after configured duration.
                If False, player must manually close. Defaults to settings.DIALOG_AUTO_CLOSE_DEFAULT.
        """
        self.speaker = speaker
        self.text = text
        self.instant = instant
        self.auto_close = auto_close
        self.started = False

    def execute(self, context: GameContext) -> bool:
        """Show dialog if not already showing."""
        if not self.started:
            dialog_plugin = context.dialog_plugin
            dialog_plugin.show_dialog(self.speaker, self.text, instant=self.instant, auto_close=self.auto_close)
            logger.debug("DialogAction: Showing dialog from %s", self.speaker)
            self.started = True

        # Action completes immediately, dialog plugin handles display
        return True

    def reset(self) -> None:
        """Reset the action."""
        self.started = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create DialogAction from a dictionary.

        Note: This handles basic dialog creation. For text_from references,
        the ScriptPlugin handles resolution before calling this method.
        """
        speaker = data.get("speaker")
        if speaker is None:
            msg = "dialog: missing required 'speaker' field"
            raise ActionParseError(msg)

        if not isinstance(speaker, str):
            msg = "dialog: 'speaker' must be a string"
            raise ActionParseError(msg)

        text = data.get("text")
        if text is None:
            msg = "dialog: missing required 'text' field"
            raise ActionParseError(msg)

        if not isinstance(text, list):
            msg = "dialog: 'text' must be a list"
            raise ActionParseError(msg)

        if not text:
            msg = "dialog: 'text' must not be empty"
            raise ActionParseError(msg)

        if not all(isinstance(item, str) for item in text):
            msg = "dialog: all items in 'text' must be strings"
            raise ActionParseError(msg)

        instant = data.get("instant", settings.DIALOG_INSTANT_TEXT_DEFAULT)
        if not isinstance(instant, bool):
            msg = "dialog: 'instant' must be a bool"
            raise ActionParseError(msg)

        auto_close = data.get("auto_close", settings.DIALOG_AUTO_CLOSE_DEFAULT)
        if not isinstance(auto_close, bool):
            msg = "dialog: 'auto_close' must be a bool"
            raise ActionParseError(msg)

        return cls(
            speaker=speaker,
            text=text,
            instant=instant,
            auto_close=auto_close,
        )


@ActionRegistry.register
class WaitForDialogCloseAction(WaitForConditionAction):
    """Wait for dialog to be closed.

    This action pauses script execution until the player dismisses the currently
    showing dialog. It's essential for creating proper dialog sequences where each
    message should be read before continuing.

    Commonly used after DialogAction to ensure the player has seen the message
    before the script proceeds to the next action.

    Example usage in a sequence:
        [
            {"name": "dialog", "speaker": "martin", "text": ["Hello!"]},
            {"name": "wait_for_dialog_close"},
            {"name": "dialog", "speaker": "yema", "text": ["Hi there!"]}
        ]
    """

    name = "wait_for_dialog_close"

    def __init__(self) -> None:
        """Initialize dialog wait action."""

        def check_dialog_closed(ctx: GameContext) -> bool:
            dialog_plugin = ctx.dialog_plugin
            return dialog_plugin is None or not dialog_plugin.is_showing()

        super().__init__(check_dialog_closed, "Dialog closed")

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:  # noqa: ARG003
        """Create WaitForDialogCloseAction from a dictionary."""
        return cls()
