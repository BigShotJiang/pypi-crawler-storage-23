"""Debug plugin for displaying development information overlays."""

from pedre.plugins.debug.plugin import DebugPlugin

__all__ = ["DebugPlugin"]
