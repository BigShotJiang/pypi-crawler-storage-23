"""Constants for sprites."""

# Base animation properties (used by AnimatedSprite)
BASE_ANIMATION_PROPERTIES = [
    "idle_up_frames",
    "idle_up_row",
    "idle_down_frames",
    "idle_down_row",
    "idle_left_frames",
    "idle_left_row",
    "idle_right_frames",
    "idle_right_row",
    "walk_up_frames",
    "walk_up_row",
    "walk_down_frames",
    "walk_down_row",
    "walk_left_frames",
    "walk_left_row",
    "walk_right_frames",
    "walk_right_row",
]
