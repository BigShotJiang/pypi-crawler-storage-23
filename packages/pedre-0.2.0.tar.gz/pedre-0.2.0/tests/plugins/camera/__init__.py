"""Unit tests for camera plugin."""
