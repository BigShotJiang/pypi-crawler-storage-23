"""Tests for waypoint plugin."""
