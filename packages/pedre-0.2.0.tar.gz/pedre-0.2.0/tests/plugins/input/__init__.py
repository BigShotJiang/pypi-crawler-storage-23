"""Unit tests for Input plugin."""
