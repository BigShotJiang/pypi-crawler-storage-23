"""Unit tests for plugins."""
