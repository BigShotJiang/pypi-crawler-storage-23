"""Tests for save plugin."""
