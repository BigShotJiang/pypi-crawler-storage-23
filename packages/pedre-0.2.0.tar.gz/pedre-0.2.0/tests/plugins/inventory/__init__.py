"""Unit tests for Inventory plugin."""
