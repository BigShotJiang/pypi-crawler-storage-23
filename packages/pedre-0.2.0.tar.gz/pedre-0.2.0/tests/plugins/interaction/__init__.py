"""Unit tests for interaction plugin."""
