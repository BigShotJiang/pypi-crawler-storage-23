"""Unit tests for Pause Menu plugin."""
