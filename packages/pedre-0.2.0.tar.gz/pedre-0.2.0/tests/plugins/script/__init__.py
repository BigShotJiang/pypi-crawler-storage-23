"""Script plugin tests."""
