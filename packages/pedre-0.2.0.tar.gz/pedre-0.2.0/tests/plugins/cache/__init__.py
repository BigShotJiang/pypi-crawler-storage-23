"""Unit tests for cache plugin."""
