"""Unit tests for Physics plugin."""
