"""Unit tests for Pathfinding plugin."""
