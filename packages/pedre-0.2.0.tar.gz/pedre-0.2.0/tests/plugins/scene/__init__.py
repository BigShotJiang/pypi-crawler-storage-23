"""Tests for scene plugin."""
