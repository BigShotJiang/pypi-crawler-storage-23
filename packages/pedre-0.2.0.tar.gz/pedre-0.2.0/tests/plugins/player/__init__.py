"""Unit tests for Player plugin."""
