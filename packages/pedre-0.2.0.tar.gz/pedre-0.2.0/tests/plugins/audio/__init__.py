"""Unit tests for audio plugin."""
