"""Unit tests for Debug plugin."""
