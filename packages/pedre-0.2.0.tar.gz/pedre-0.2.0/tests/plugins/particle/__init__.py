"""Unit tests for Particle plugin."""
