"""Unit tests for dialog plugin."""
