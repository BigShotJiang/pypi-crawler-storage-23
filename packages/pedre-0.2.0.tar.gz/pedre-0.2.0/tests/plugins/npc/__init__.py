"""Unit tests for NPC plugin."""
