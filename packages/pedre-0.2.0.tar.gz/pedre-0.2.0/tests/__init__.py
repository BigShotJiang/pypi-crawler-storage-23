"""Tests for the pedre game."""
