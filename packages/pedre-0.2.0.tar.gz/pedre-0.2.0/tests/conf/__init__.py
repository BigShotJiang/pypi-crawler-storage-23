"""Tests for pedre.conf module."""
