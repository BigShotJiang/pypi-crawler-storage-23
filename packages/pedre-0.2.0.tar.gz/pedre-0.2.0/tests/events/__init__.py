"""Unit tests for events."""
