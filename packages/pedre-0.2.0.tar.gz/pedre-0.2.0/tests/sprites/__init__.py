"""Unit tests for sprites."""
