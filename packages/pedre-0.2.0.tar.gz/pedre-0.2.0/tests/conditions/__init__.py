"""Unit tests for conditions."""
