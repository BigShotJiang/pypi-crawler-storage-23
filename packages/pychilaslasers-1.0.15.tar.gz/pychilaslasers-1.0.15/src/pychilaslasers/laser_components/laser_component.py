"""Abstract base class for laser hardware components.

This module defines the common interface that all laser hardware components
must implement. This encapsulation allows for abstracticizing the internals of
the laser in such a way as to allow for better visualization of their state and
possible operations.

**Authors**: SDU
"""

# ⚛️ Type checking
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pychilaslasers.comm import Communication
    from pychilaslasers.laser import Laser

# ✅ Standard library imports
from abc import ABC, abstractmethod


class LaserComponent(ABC):
    """Abstract base class for all laser hardware components.

    This class defines the common interface that all laser components must
    implement. It provides standardized access to the value of the sensor and it's unit.

    Attributes:
        value: The current value of the component (implementation-dependent).
        unit: The unit of measurement for this component's values.
    """

    _unit: str

    def __init__(self, laser: Laser) -> None:  # noqa: D107
        super().__init__()
        self._comm: Communication = laser.comm

    ########## Properties (Getters/Setters) ##########

    @property
    @abstractmethod
    def value(self) -> float:
        """Returns the current value of the component in appropriate units."""
        ...

    @property
    def unit(self) -> str:
        """Returns the unit string (e.g., "mA", "°C", "V") for this component."""
        return self._unit
