"""Message pool for protobuf descriptors."""

# Placeholder for message pool utilities if needed
