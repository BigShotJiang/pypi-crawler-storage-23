# Solutions for SFA Tutorial Exercises

This directory contains complete solutions for all exercises in the Stochastic Frontier Analysis tutorial series.

## How to Use Solutions

1. **Try the exercises yourself first.** Each tutorial notebook contains exercises with instructions and empty code cells for you to complete.
2. **Check your approach.** After attempting an exercise, compare your solution with the one provided here.
3. **Learn from differences.** If your solution differs, both may be correct. Focus on understanding the reasoning behind each approach.

## Solution Notebooks

| Solution | Corresponding Tutorial | Key Exercises |
|----------|----------------------|---------------|
| `01_introduction_sfa_solution.ipynb` | Introduction to SFA | Half-normal vs exponential, farm production frontier |
| `02_panel_sfa_solution.ipynb` | Panel SFA | BC92 estimation, time-varying efficiency, airline panel |
| `03_four_component_tfp_solution.ipynb` | Four-Component & TFP | TFP decomposition, persistent vs transient |
| `04_determinants_heterogeneity_solution.ipynb` | Determinants & Heterogeneity | BC95 with z-vars, Wang 2002, marginal effects |
| `05_testing_comparison_solution.ipynb` | Testing & Comparison | LR tests, model selection, bootstrap |
| `06_complete_case_study_solution.ipynb` | Complete Case Study | Full research pipeline on Brazilian data |

## What Solutions Include

Each solution notebook contains:
- Complete code for all exercises
- Expected output and results
- Brief explanations of the approach
- Interpretation of results

## Tips

- Multiple approaches to the same exercise may be equally valid
- Focus on understanding the economic interpretation, not just the code
- If your numerical results differ slightly, check whether the difference is due to random seeds or optimization settings
- Pay attention to the diagnostic checks — they help validate your results
