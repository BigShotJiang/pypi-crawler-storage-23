"""Tests for diagnostics tutorials."""
