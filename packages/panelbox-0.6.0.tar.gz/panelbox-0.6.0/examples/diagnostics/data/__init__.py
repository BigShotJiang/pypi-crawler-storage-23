"""Diagnostics tutorial datasets."""
