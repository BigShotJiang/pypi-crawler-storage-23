---
title: "Bias-Corrected GMM"
description: "Hahn-Kuersteiner (2002) bias-corrected GMM estimator for dynamic panel data, reducing finite-sample bias from O(1/N) to O(1/N^2)."
---

# Bias-Corrected GMM

!!! info "Quick Reference"
    **Class:** `panelbox.gmm.BiasCorrectedGMM`
    **Import:** `from panelbox.gmm import BiasCorrectedGMM`
    **Stata equivalent:** No direct equivalent (custom post-estimation correction)
    **R equivalent:** No direct equivalent

## Overview

Standard GMM estimators for dynamic panels (Arellano-Bond, Blundell-Bond) have **finite-sample bias** of order $O(1/N)$. While they are consistent as $N \to \infty$, this bias can be substantial in moderate samples -- for example, with $N = 100$ and $T = 10$, the AR coefficient can be biased by 10-20% of its true value.

The Bias-Corrected GMM estimator, following Hahn and Kuersteiner (2002), computes an **analytical bias term** $\hat{B}(\hat{\beta})$ and subtracts it:

$$\hat{\beta}^{BC} = \hat{\beta}^{GMM} - \frac{\hat{B}(\hat{\beta})}{N}$$

This reduces the bias to $O(1/N^2)$, providing substantially more accurate point estimates when both $N$ and $T$ are moderate.

PanelBox's implementation wraps either Difference GMM or System GMM as the base estimator, applies the Hahn-Kuersteiner correction, and reports both corrected and uncorrected estimates for comparison.

## Quick Example

```python
import pandas as pd
from panelbox.gmm import BiasCorrectedGMM

# Data must have MultiIndex (entity_id, time_id)
panel_data = data.set_index(["id", "year"])

model = BiasCorrectedGMM(
    data=panel_data,
    dep_var="n",
    lags=[1],
    id_var="id",
    time_var="year",
    exog_vars=["w", "k"],
    bias_order=1,
)
results = model.fit()

# Compare corrected vs uncorrected
print(f"Uncorrected: {model.params_uncorrected_}")
print(f"Corrected:   {model.params_}")
print(f"Bias magnitude: {model.bias_magnitude():.4f}")
```

## When to Use

- **Moderate N and T**: Both $N > 50$ and $T > 10$ (bias correction needs sufficient data)
- **Dynamic panels** with lagged dependent variables
- **Concern about bias** in policy-relevant coefficients
- **Robustness check**: Compare bias-corrected with standard GMM estimates

!!! warning "Key Assumptions"
    1. **Large N, large T asymptotics**: Bias correction is derived under joint $N, T \to \infty$
    2. **Minimum recommended**: $N \geq 50$, $T \geq 10$ (warnings issued below these thresholds)
    3. **First-order correction**: The simplified Nickell-type bias formula $B(\rho) \approx -(1+\rho)/(T-1)$ applies to the AR coefficient
    4. All standard GMM assumptions apply to the base estimator

!!! note "When NOT to Use"
    - **Very small N or T** (< 30): Bias correction may not be reliable
    - **Very large N** (> 1000): Bias is negligible, standard GMM suffices
    - **T > 30**: Bias correction has negligible impact; save computation time
    - **Static panels**: No lagged dependent variable means no dynamic bias

## Detailed Guide

### The Bias Problem

For the standard dynamic panel model:

$$y_{it} = \rho \, y_{i,t-1} + X_{it}'\beta + \alpha_i + \varepsilon_{it}$$

The Arellano-Bond GMM estimator has:

$$E[\hat{\rho}^{GMM} - \rho] \approx \frac{B(\rho)}{N} + O(N^{-2})$$

For the AR(1) coefficient, the approximate bias is the Nickell (1981) formula:

$$B(\rho) \approx -\frac{1 + \rho}{T - 1}$$

**Example**: With $\rho = 0.7$ and $T = 10$, the bias is approximately $-1.7/9 \approx -0.19$. The true coefficient of 0.7 would be estimated as approximately 0.51 without correction.

### The Hahn-Kuersteiner Correction

The correction procedure:

1. **Estimate standard GMM** to get $\hat{\beta}$
2. **Compute bias term** $\hat{B}(\hat{\beta})$ using the analytical formula
3. **Apply correction**: $\hat{\beta}^{BC} = \hat{\beta} - \hat{B}/N$
4. **Adjust variance** (conservative: uses uncorrected variance)

### Estimation

=== "With Difference GMM (Default)"
    ```python
    from panelbox.gmm import BiasCorrectedGMM

    panel_data = data.set_index(["id", "year"])

    model = BiasCorrectedGMM(
        data=panel_data,
        dep_var="n",
        lags=[1],
        id_var="id",
        time_var="year",
        exog_vars=["w", "k"],
        bias_order=1,
    )
    results = model.fit(time_dummies=True, use_system_gmm=False)
    ```

=== "With System GMM"
    ```python
    model = BiasCorrectedGMM(
        data=panel_data,
        dep_var="n",
        lags=[1],
        id_var="id",
        time_var="year",
        exog_vars=["w", "k"],
        bias_order=1,
    )
    results = model.fit(time_dummies=True, use_system_gmm=True)
    ```

### Interpreting Results

```python
# Compare corrected vs uncorrected estimates
print("Parameter Comparison:")
for i, name in enumerate(results.params.index):
    uncorr = model.params_uncorrected_[i]
    corr = model.params_[i]
    diff = corr - uncorr
    print(f"  {name}: uncorrected={uncorr:.4f}, corrected={corr:.4f}, diff={diff:.4f}")

# Overall bias magnitude
print(f"\nBias magnitude (L2 norm): {model.bias_magnitude():.4f}")
print(f"Bias term: {model.bias_term_}")
```

### When Bias Correction Matters

The correction is most impactful when:

| Scenario | Approximate Bias | Impact |
|----------|-----------------|--------|
| N=50, T=5, rho=0.7 | -0.43 | Very large |
| N=100, T=10, rho=0.7 | -0.19 | Substantial |
| N=200, T=15, rho=0.7 | -0.12 | Moderate |
| N=500, T=20, rho=0.7 | -0.09 | Small |
| N=1000, T=30, rho=0.7 | -0.06 | Negligible |

## Configuration Options

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `data` | `pd.DataFrame` | required | Panel data with MultiIndex (entity, time) |
| `dep_var` | `str` | required | Dependent variable name |
| `lags` | `list[int]` | required | Lags of dependent variable (e.g., `[1]`) |
| `id_var` | `str` | `"id"` | Entity identifier |
| `time_var` | `str` | `"year"` | Time variable |
| `exog_vars` | `list[str]` | `None` | Exogenous regressors |
| `bias_order` | `int` | `1` | Order of bias correction (1 or 2) |
| `min_n` | `int` | `50` | Minimum N for warning |
| `min_t` | `int` | `10` | Minimum T for warning |

**`fit()` parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `time_dummies` | `bool` | `True` | Include time dummies |
| `use_system_gmm` | `bool` | `False` | Use System GMM as base estimator |
| `verbose` | `bool` | `False` | Print estimation progress |

## Diagnostics

### Bias Assessment

```python
# Check if bias correction was meaningful
magnitude = model.bias_magnitude()
if magnitude > 0.01:
    print(f"Meaningful correction: {magnitude:.4f}")
else:
    print(f"Negligible correction: {magnitude:.4f} -- standard GMM is fine")

# All standard GMM diagnostics are available
print(f"AR(2) p-value: {results.ar2_test.pvalue:.4f}")
print(f"Hansen J p-value: {results.hansen_j.pvalue:.4f}")
```

### Reporting Convention

!!! tip "Best Practice for Papers"
    Report both uncorrected and bias-corrected estimates side by side. If the correction is small ($< 5\%$ of the coefficient), this provides evidence that finite-sample bias is not a concern. If the correction is large, the bias-corrected estimates should be preferred.

## Tutorials

| Tutorial | Description | Link |
|----------|-------------|------|
| Complete GMM Guide | Overview of all GMM estimators | [Complete Guide](complete-guide.md) |

## See Also

- [Difference GMM](difference-gmm.md) -- Base estimator (Arellano-Bond)
- [System GMM](system-gmm.md) -- Alternative base estimator (Blundell-Bond)
- [CUE-GMM](cue-gmm.md) -- Another approach to reducing finite-sample bias
- [Diagnostics](diagnostics.md) -- GMM diagnostic tests

## References

1. Hahn, J., & Kuersteiner, G. (2002). "Asymptotically Unbiased Inference for a Dynamic Panel Model with Fixed Effects when Both n and T Are Large." *Econometrica*, 70(4), 1639-1657.
2. Nickell, S. (1981). "Biases in Dynamic Models with Fixed Effects." *Econometrica*, 49(6), 1417-1426.
3. Arellano, M., & Bond, S. (1991). "Some Tests of Specification for Panel Data: Monte Carlo Evidence and an Application to Employment Equations." *Review of Economic Studies*, 58(2), 277-297.
4. Bun, M. J. G., & Windmeijer, F. (2010). "The Weak Instrument Problem of the System GMM Estimator in Dynamic Panel Data Models." *The Econometrics Journal*, 13(1), 95-126.
