---
title: "References & Bibliography"
description: "Key papers, textbooks, and seminal references for panel data econometrics"
---

# References & Bibliography

!!! abstract "Key Takeaway"
    This page collects the foundational papers and textbooks behind PanelBox's methods. References are organized by topic to help you find the relevant literature for your research area.

## Core Textbooks

These textbooks provide comprehensive coverage of panel data econometrics and are referenced throughout the theory pages.

- **Wooldridge, J.M. (2010).** *Econometric Analysis of Cross Section and Panel Data*, 2nd ed. MIT Press. --- The most comprehensive graduate-level textbook on panel data methods. Covers FE, RE, GMM, IV, selection models, and nonlinear models.

- **Baltagi, B.H. (2013).** *Econometric Analysis of Panel Data*, 5th ed. Wiley. --- Standard reference covering static and dynamic panel models, spatial panels, and panel unit root/cointegration tests.

- **Arellano, M. (2003).** *Panel Data Econometrics*. Oxford University Press. --- Advanced treatment focusing on GMM, dynamic models, and nonlinear panel methods.

- **Cameron, A.C. & Trivedi, P.K. (2005).** *Microeconometrics: Methods and Applications*. Cambridge University Press. --- Broad coverage of microeconometric methods including panel data, discrete choice, count data, and selection models.

- **Hsiao, C. (2014).** *Analysis of Panel Data*, 3rd ed. Cambridge University Press. --- Thorough coverage of both static and dynamic panel models with extensive mathematical detail.

- **Greene, W.H. (2018).** *Econometric Analysis*, 8th ed. Pearson. --- General econometrics textbook with strong coverage of panel data, discrete choice, and frontier models.

## Panel Data Fundamentals

- **Mundlak, Y. (1978).** "On the Pooling of Time Series and Cross Section Data." *Econometrica*, 46(1), 69--85. --- The Mundlak approach for testing FE vs. RE assumptions.

- **Hausman, J.A. (1978).** "Specification Tests in Econometrics." *Econometrica*, 46(6), 1251--1271. --- The Hausman specification test for comparing FE and RE estimators.

- **Chamberlain, G. (1980).** "Analysis of Covariance with Qualitative Data." *Review of Economic Studies*, 47(1), 225--238. --- Conditional likelihood for FE logit, eliminating incidental parameters.

- **Mundlak, Y. (1961).** "Empirical Production Function Free of Management Bias." *Journal of Farm Economics*, 43(1), 44--56. --- Early formulation of the fixed effects approach.

- **Neyman, J. & Scott, E.L. (1948).** "Consistent Estimates Based on Partially Consistent Observations." *Econometrica*, 16(1), 1--32. --- The incidental parameters problem in maximum likelihood estimation.

## GMM & Dynamic Models

- **Arellano, M. & Bond, S. (1991).** "Some Tests of Specification for Panel Data: Monte Carlo Evidence and an Application to Employment Equations." *Review of Economic Studies*, 58(2), 277--297. --- The original Difference GMM estimator with AR tests.

- **Blundell, R. & Bond, S. (1998).** "Initial Conditions and Moment Restrictions in Dynamic Panel Data Models." *Journal of Econometrics*, 87(1), 115--143. --- System GMM with additional moment conditions from the level equation.

- **Roodman, D. (2009).** "How to Do xtabond2: An Introduction to Difference and System GMM in Stata." *Stata Journal*, 9(1), 86--136. --- Practical guide to GMM estimation with discussion of instrument proliferation.

- **Windmeijer, F. (2005).** "A Finite Sample Correction for the Variance of Linear Efficient Two-Step GMM Estimators." *Journal of Econometrics*, 126(1), 25--51. --- Correction for downward-biased two-step standard errors.

- **Hansen, L.P., Heaton, J. & Yaron, A. (1996).** "Finite-Sample Properties of Some Alternative GMM Estimators." *Journal of Business & Economic Statistics*, 14(3), 262--280. --- CUE-GMM theory and Monte Carlo comparison.

- **Hahn, J. & Kuersteiner, G. (2002).** "Asymptotically Unbiased Inference for a Dynamic Panel Model with Fixed Effects When Both N and T Are Large." *Econometrica*, 70(4), 1639--1657. --- Analytical bias correction for dynamic panel GMM.

- **Nickell, S. (1981).** "Biases in Dynamic Models with Fixed Effects." *Econometrica*, 49(6), 1417--1426. --- Derivation of the Nickell bias in FE estimation of dynamic models.

- **Hansen, L.P. (1982).** "Large Sample Properties of Generalized Method of Moments Estimators." *Econometrica*, 50(4), 1029--1054. --- The foundational GMM theory paper.

## Spatial Econometrics

- **Anselin, L. (1988).** *Spatial Econometrics: Methods and Models*. Kluwer Academic Publishers. --- Foundational textbook establishing the field of spatial econometrics.

- **LeSage, J. & Pace, R.K. (2009).** *Introduction to Spatial Econometrics*. CRC Press. --- Modern treatment with emphasis on direct/indirect effects decomposition and Bayesian methods.

- **Elhorst, J.P. (2014).** *Spatial Econometrics: From Cross-Sectional Data to Spatial Panels*. Springer. --- Comprehensive guide covering spatial panel models, dynamic spatial panels, and model selection.

- **Lee, L.F. & Yu, J. (2010).** "Estimation of Spatial Autoregressive Panel Data Models with Fixed Effects." *Journal of Econometrics*, 154(2), 165--185. --- ML estimation of spatial panel models with bias correction.

- **Anselin, L. (1995).** "Local Indicators of Spatial Association --- LISA." *Geographical Analysis*, 27(2), 93--115. --- Local Moran's I and spatial cluster detection.

- **Moran, P.A.P. (1950).** "Notes on Continuous Stochastic Phenomena." *Biometrika*, 37, 17--23. --- The original global Moran's I test statistic.

- **Anselin, L., Bera, A.K., Florax, R. & Yoon, M.J. (1996).** "Simple Diagnostic Tests for Spatial Dependence." *Regional Science and Urban Economics*, 26(1), 77--104. --- LM tests for spatial lag vs. spatial error.

## Stochastic Frontier Analysis

- **Aigner, D., Lovell, C.A.K. & Schmidt, P. (1977).** "Formulation and Estimation of Stochastic Frontier Production Function Models." *Journal of Econometrics*, 6(1), 21--37. --- Original SFA formulation with composed error.

- **Meeusen, W. & van den Broeck, J. (1977).** "Efficiency Estimation from Cobb-Douglas Production Functions with Composed Error." *International Economic Review*, 18(2), 435--444. --- Independent development of SFA.

- **Jondrow, J., Lovell, C.A.K., Materov, I.S. & Schmidt, P. (1982).** "On the Estimation of Technical Inefficiency in the Stochastic Frontier Production Function Model." *Journal of Econometrics*, 19(2--3), 233--238. --- JLMS estimator for entity-level efficiency.

- **Battese, G.E. & Coelli, T.J. (1992).** "Frontier Production Functions, Technical Efficiency and Panel Data: With Application to Paddy Farmers in India." *Journal of Productivity Analysis*, 3, 153--169. --- Time-varying inefficiency with exponential decay.

- **Battese, G.E. & Coelli, T.J. (1995).** "A Model for Technical Inefficiency Effects in a Stochastic Frontier Production Function for Panel Data." *Empirical Economics*, 20, 325--332. --- Inefficiency as function of exogenous variables.

- **Greene, W.H. (2005).** "Reconsidering Heterogeneity in Panel Data Estimators of the Stochastic Frontier Model." *Journal of Econometrics*, 126(2), 269--303. --- True FE/RE models separating heterogeneity from inefficiency.

- **Kumbhakar, S.C., Lien, G. & Hardaker, J.B. (2014).** "Technical Efficiency in Competing Panel Data Models: A Study of Norwegian Grain Farming." *Journal of Productivity Analysis*, 41, 321--337. --- Four-component model with persistent and transient inefficiency.

- **Kumbhakar, S.C. & Lovell, C.A.K. (2000).** *Stochastic Frontier Analysis*. Cambridge University Press. --- Comprehensive textbook on SFA theory and practice.

## Quantile Regression

- **Koenker, R. & Bassett, G. (1978).** "Regression Quantiles." *Econometrica*, 46(1), 33--50. --- The original quantile regression estimator.

- **Koenker, R. (2004).** "Quantile Regression for Longitudinal Data." *Journal of Multivariate Analysis*, 91(1), 74--89. --- Penalized FE quantile regression for panel data.

- **Canay, I.A. (2011).** "A Simple Approach to Quantile Regression for Panel Data." *The Econometrics Journal*, 14(3), 368--386. --- Two-step FE quantile regression.

- **Machado, J.A.F. & Santos Silva, J.M.C. (2019).** "Quantiles via Moments." *Journal of Econometrics*, 213(1), 145--173. --- Location-scale model with non-crossing guarantee.

- **Athey, S. & Imbens, G.W. (2006).** "Identification and Inference in Nonlinear Difference-in-Differences Models." *Econometrica*, 74(2), 431--497. --- Changes-in-changes for distributional treatment effects.

- **Chernozhukov, V., Fernandez-Val, I. & Melly, B. (2013).** "Inference on Counterfactual Distributions." *Econometrica*, 81(6), 2205--2268. --- Counterfactual distributional analysis.

- **Koenker, R. (2005).** *Quantile Regression*. Cambridge University Press. --- Comprehensive textbook on quantile regression theory and applications.

## Unit Root & Cointegration

- **Levin, A., Lin, C.F. & Chu, C. (2002).** "Unit Root Tests in Panel Data: Asymptotic and Finite-Sample Properties." *Journal of Econometrics*, 108(1), 1--24. --- LLC panel unit root test with common $\rho$.

- **Im, K.S., Pesaran, M.H. & Shin, Y. (2003).** "Testing for Unit Roots in Heterogeneous Panels." *Journal of Econometrics*, 115(1), 53--74. --- IPS test allowing heterogeneous $\rho_i$.

- **Maddala, G.S. & Wu, S. (1999).** "A Comparative Study of Unit Root Tests with Panel Data and a New Simple Test." *Oxford Bulletin of Economics and Statistics*, 61(S1), 631--652. --- Fisher combination test for panel unit roots.

- **Hadri, K. (2000).** "Testing for Stationarity in Heterogeneous Panel Data." *The Econometrics Journal*, 3(2), 148--161. --- Panel stationarity test (reversed null).

- **Pedroni, P. (1999).** "Critical Values for Cointegration Tests in Heterogeneous Panels with Multiple Regressors." *Oxford Bulletin of Economics and Statistics*, 61(S1), 653--670. --- Seven panel cointegration test statistics.

- **Pedroni, P. (2004).** "Panel Cointegration: Asymptotic and Finite Sample Properties of Pooled Time Series Tests with an Application to the PPP Hypothesis." *Econometric Theory*, 20(3), 597--625. --- Asymptotic theory for Pedroni tests.

- **Kao, C. (1999).** "Spurious Regression and Residual-Based Tests for Cointegration in Panel Data." *Journal of Econometrics*, 90(1), 1--44. --- Homogeneous panel cointegration test.

- **Westerlund, J. (2007).** "Testing for Error Correction in Panel Data." *Oxford Bulletin of Economics and Statistics*, 69(6), 709--748. --- ECM-based cointegration test with bootstrap.

- **Pesaran, M.H. (2007).** "A Simple Panel Unit Root Test in the Presence of Cross-Section Dependence." *Journal of Applied Econometrics*, 22(2), 265--312. --- CIPS test robust to cross-sectional dependence.

## Discrete Choice & Count Models

- **McFadden, D. (1974).** "Conditional Logit Analysis of Qualitative Choice Behavior." In *Frontiers in Econometrics*, ed. P. Zarembka. --- Foundational discrete choice theory and conditional logit.

- **Train, K. (2009).** *Discrete Choice Methods with Simulation*, 2nd ed. Cambridge University Press. --- Comprehensive textbook covering logit, probit, nested, and mixed logit.

- **Hausman, J.A., Hall, B.H. & Griliches, Z. (1984).** "Econometric Models for Count Data with an Application to the Patents-R&D Relationship." *Econometrica*, 52(4), 909--938. --- Panel count models.

- **Cameron, A.C. & Trivedi, P.K. (1998).** *Regression Analysis of Count Data*. Cambridge University Press. --- Standard reference for Poisson, negative binomial, and zero-inflated models.

- **Santos Silva, J.M.C. & Tenreyro, S. (2006).** "The Log of Gravity." *Review of Economics and Statistics*, 88(4), 641--658. --- PPML estimator for gravity models.

- **Wooldridge, J.M. (1999).** "Distribution-Free Estimation of Some Nonlinear Panel Data Models." *Journal of Econometrics*, 90(1), 77--97. --- Quasi-MLE for panel count data.

## Censored & Selection Models

- **Heckman, J.J. (1979).** "Sample Selection Bias as a Specification Error." *Econometrica*, 47(1), 153--161. --- Original two-step selection correction.

- **Wooldridge, J.M. (1995).** "Selection Corrections for Panel Data Models Under Conditional Mean Independence Assumptions." *Journal of Econometrics*, 68(1), 115--132. --- Panel extension of Heckman model.

- **Tobin, J. (1958).** "Estimation of Relationships for Limited Dependent Variables." *Econometrica*, 26(1), 24--36. --- The Tobit model for censored data.

- **Honor\'e, B.E. (1992).** "Trimmed LAD and Least Squares Estimation of Truncated and Censored Regression Models with Fixed Effects." *Econometrica*, 60(3), 533--565. --- Semiparametric FE estimator for censored panel data.

- **Kyriazidou, E. (1997).** "Estimation of a Panel Data Sample Selection Model." *Econometrica*, 65(6), 1335--1364. --- Semiparametric panel selection model.

## Standard Errors & Inference

- **White, H. (1980).** "A Heteroskedasticity-Consistent Covariance Matrix Estimator and a Direct Test for Heteroskedasticity." *Econometrica*, 48(4), 817--838. --- HC robust standard errors.

- **Arellano, M. (1987).** "Computing Robust Standard Errors for Within-Groups Estimators." *Oxford Bulletin of Economics and Statistics*, 49(4), 431--434. --- Cluster-robust SE for panel FE.

- **Driscoll, J.C. & Kraay, A. (1998).** "Consistent Covariance Matrix Estimation with Spatially Dependent Panel Data." *Review of Economics and Statistics*, 80(4), 549--560. --- Driscoll-Kraay SE for cross-sectional dependence.

- **Newey, W.K. & West, K.D. (1987).** "A Simple, Positive Semi-Definite, Heteroskedasticity and Autocorrelation Consistent Covariance Matrix." *Econometrica*, 55(3), 703--708. --- HAC variance estimation.

- **Beck, N. & Katz, J.N. (1995).** "What to Do (and Not to Do) with Time-Series Cross-Section Data." *American Political Science Review*, 89(3), 634--647. --- Panel-corrected standard errors (PCSE).

- **Cameron, A.C., Gelbach, J.B. & Miller, D.L. (2011).** "Robust Inference with Multiway Clustering." *Journal of Business & Economic Statistics*, 29(2), 238--249. --- Multi-way clustered standard errors.

## Diagnostics & Validation

- **Breusch, T.S. & Pagan, A.R. (1980).** "The Lagrange Multiplier Test and its Applications to Model Specification in Econometrics." *Review of Economic Studies*, 47(1), 239--253. --- LM tests for heteroskedasticity and serial correlation.

- **Wooldridge, J.M. (2002).** "Econometric Analysis of Cross Section and Panel Data." MIT Press, Section 10.5. --- Wooldridge test for serial correlation in panel FE models.

- **Pesaran, M.H. (2004).** "General Diagnostic Tests for Cross Section Dependence in Panels." *Cambridge Working Papers in Economics*, No. 0435. --- CD test for cross-sectional dependence.

- **Sargan, J.D. (1958).** "The Estimation of Economic Relationships Using Instrumental Variables." *Econometrica*, 26(3), 393--415. --- Overidentification test for IV/GMM.

## Software References

- **PanelBox Documentation.** The official documentation for the PanelBox Python library.
- **Stata Manual.** Panel data estimation commands: `xtreg`, `xtabond2`, `xtdpd`, `xtivreg`.
- **R plm Package.** Croissant, Y. & Millo, G. (2008). "Panel Data Econometrics in R: The plm Package." *Journal of Statistical Software*, 27(2).
- **R frontier Package.** Coelli, T. & Henningsen, A. Stochastic frontier analysis in R.
- **R spdep Package.** Bivand, R. Spatial dependence analysis in R.
- **Python statsmodels.** Panel data models and diagnostic tests.

## See Also

- [Theory Index](panel-fundamentals.md) --- overview and reading guide
- [Panel Fundamentals](panel-fundamentals.md)
- [GMM Theory](gmm-theory.md)
- [Spatial Theory](spatial-theory.md)
- [Frontier Theory](sfa-theory.md)
- [Quantile Theory](quantile-theory.md)
- [Cointegration Theory](../diagnostics/cointegration/index.md)
