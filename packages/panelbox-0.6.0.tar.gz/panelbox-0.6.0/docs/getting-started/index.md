---
title: Getting Started
description: Install PanelBox and run your first panel data model in minutes
---

# Getting Started

Welcome to PanelBox! This section will get you up and running quickly.

<div class="grid cards" markdown>

- :material-download: **[Installation](installation.md)**

    Install PanelBox and verify your setup

- :material-rocket-launch: **[Quick Start](quickstart.md)**

    Run your first panel data model in 5 minutes

- :material-book-open-variant: **[Core Concepts](core-concepts.md)**

    Understand panel data, formulas, and the PanelBox workflow

- :material-map-marker-path: **[Choosing a Model](choosing-model.md)**

    Decision guide for selecting the right econometric model

</div>
