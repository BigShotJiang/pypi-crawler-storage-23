# wgc-clippy

Low-level utility helpers for the WGC QA framework.

## Modules

- `cmd_helper` — subprocess command execution
- `waiter` — polling/wait utilities with timeout
- `os_helper` — OS-level file and process operations
- `registry` — Windows Registry read/write
- `process_helper` — process inspection and manipulation
- `regex_helper` — regex matching utilities
- `testrail_api` — TestRail API integration
- `torrents_helper` — torrent file operations
- `file_downloader` — HTTP file download
- `magic_folder` — temporary directory utilities

## Install

```bash
pip install wgc-clippy
```
