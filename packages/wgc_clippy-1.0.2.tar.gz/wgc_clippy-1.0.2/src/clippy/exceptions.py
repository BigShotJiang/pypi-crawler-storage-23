# -*- coding: utf-8 -*-


class ClippyException(Exception):
    """Base exception for clippy package."""
