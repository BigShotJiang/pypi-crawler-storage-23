# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from contextlib import contextmanager
from os import path, makedirs, getcwd, chdir


@contextmanager
def magic_folder(path_):
    original_dir = getcwd()
    try:
        if not path.isdir(path_):
            makedirs(path_)
        chdir(path_)
        yield
    finally:
        chdir(original_dir)
