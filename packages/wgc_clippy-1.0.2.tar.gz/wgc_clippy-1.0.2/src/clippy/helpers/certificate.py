# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from os import path
from time import time
from tempfile import mkdtemp

from OpenSSL import crypto

from .cmd_helper import CmdHelper


class CertificatesHelper:

    @classmethod
    def _generate_cert_and_pem(cls, cert_name: str) -> tuple:
        """
        Generates new cert and pem files.

        Args:
            cert_name: certificate name

        Returns:
            cert, key and pem files.
        """
        key = crypto.PKey()
        key.generate_key(crypto.TYPE_RSA, 2048)

        cert = crypto.X509()
        cert.get_subject().C = 'UA'
        cert.get_subject().L = 'Kiev'
        cert.get_subject().O = 'Wargaming.net'  # noqa
        cert.get_subject().OU = 'WDS'
        cert.get_subject().CN = cert_name
        cert.set_serial_number(int(time() * 10000))
        cert.set_version(2)
        cert.gmtime_adj_notBefore(-3600 * 48)
        cert.gmtime_adj_notAfter(24 * 60 * 60 * 365 * 7)
        cert.set_issuer(cert.get_subject())
        cert.set_pubkey(key)
        cert.sign(key, 'sha256')

        return key, cert

    @classmethod
    def generate_pfx_certificate(cls, cert_name: str, cert_file_name: str = None) -> tuple:
        """
        Generates new pfx certificate.

        Args:
            cert_name: certificate name.
            cert_file_name: cert file name, if None than cert_name will be used.

        Returns:
            path to generated cer, pfx and key files.
        """
        key, cert = cls._generate_cert_and_pem(cert_name)
        cert_file_name = cert_file_name or cert_name
        tmp_folder = mkdtemp(prefix='clippycert_')
        cer_path = path.join(tmp_folder, '%s.cer' % cert_file_name)
        pfx_path = path.join(tmp_folder, '%s.pfx' % cert_file_name)
        key_path = path.join(tmp_folder, '%s.key' % cert_file_name)
        p12 = crypto.PKCS12()
        p12.set_privatekey(key)
        p12.set_certificate(cert)
        pfx = p12.export()

        cert = crypto.dump_certificate(crypto.FILETYPE_PEM, cert)
        key = crypto.dump_privatekey(crypto.FILETYPE_PEM, key)

        with open(cer_path, "wt") as cer_file:
            cer_file.write(bytes.decode(cert))

        with open(pfx_path, "wb") as pfx_file:
            pfx_file.write(pfx)

        with open(key_path, "wb") as key_file:
            key_file.write(key)

        return cer_path, pfx_path, key_path

    @classmethod
    def generate_pem_certificate(cls, cert_name: str, cert_file_name: str = None) -> str:
        """
        Generates new pem certificate.

        Args:
            cert_name: certificate name.
            cert_file_name: cert file name, if None than cert_name will be used.

        Returns:
             path to generated certificate.
        """
        key, cert = cls._generate_cert_and_pem(cert_name)
        cert = crypto.dump_certificate(crypto.FILETYPE_PEM, cert)
        key = crypto.dump_privatekey(crypto.FILETYPE_PEM, key)
        cert_file_name = cert_file_name or cert_name

        tmp_folder = mkdtemp(prefix='clippycert_')
        pem_path = path.join(tmp_folder, '%s.pem' % cert_file_name)
        with open(pem_path, 'wb') as pem_cert_file:
            pem_cert_file.write(cert)
            pem_cert_file.write(key)

        cer_path = path.join(tmp_folder, '%s.cer' % cert_file_name)
        with open(cer_path, 'wb') as cert_file:
            cert_file.write(cert)

        return pem_path

    @classmethod
    def install_certificate(cls, path_to_cert: str, store: str = 'Root'):
        """
        Install certificate.

        Args:
            path_to_cert: path to cert.
            store: store where cert need to be stored.
        """
        CmdHelper.execute('certutil –addstore –f "%s" "%s"' % (store,
                                                               path_to_cert))

    @classmethod
    def delete_certificate(cls, cert_name: str, store: str = 'Root'):
        """
        Install certificate.

        Args:
            cert_name: cert name.
            store: store where cert is stored.
        """
        CmdHelper.execute('certutil -delstore "%s" "%s"' % (store, cert_name))
