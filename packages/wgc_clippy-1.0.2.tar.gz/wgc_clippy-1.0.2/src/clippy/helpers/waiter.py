# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from typing import Callable
from time import time, sleep
from logging import getLogger

from ..exceptions import ClippyException

log = getLogger(__name__)


class PollingTimeoutExpired(ClippyException):
    """
    PollingTimeoutException
    """


class Waiter(object):

    @classmethod
    def poll(cls, timeout: float, func: Callable, failure_message: str = None, sleep_seconds: float = 1.0, *args):
        """
        Polls function during given timeout.

        Args:
            timeout: timeout in seconds.
            func: function that will be polled.
            failure_message: failure message, if set then error will be raised if condition will not met in
                given timeout.
            sleep_seconds: time to sleep between iterations.
            args: args that will be passed to function.

        Returns:
            Result of given function if can be interpreted as True, otherwise False.
        """
        start_time = time()
        while True:
            result = func(*args)
            if result:
                return result
            elif time() - start_time >= timeout:
                if failure_message is not None:
                    raise PollingTimeoutExpired(failure_message)
                else:
                    return False
            sleep(sleep_seconds)
