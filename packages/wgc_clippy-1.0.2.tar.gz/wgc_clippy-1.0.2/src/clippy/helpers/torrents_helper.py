# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from typing import List, Union
from os import path, makedirs, stat
from tempfile import mkstemp
from time import time
from hashlib import sha1
from logging import getLogger
from functools import partial

import bencodepy

from ..exceptions import ClippyException

log = getLogger(__name__)


class TorrentsHelperException(ClippyException):
    """
    Torrents helper exception class.
    """


class TorrentsHelper(object):
    """
    https://wiki.theory.org/BitTorrentSpecification
    http://www.bittorrent.org/beps/bep_0047.html
    """

    @classmethod
    def generate_torrent_file(cls, file_path: Union[str, List[str]], webseed: str, created_by: str = None,
                              comment: str = None, chunk_length: int = 16 * 1024, root_folder: str = None,
                              with_paddings: bool = False) -> str:
        """
        Generates torrent file by given data.

        Args:
            file_path: path to file that will be seeded.
            webseed: url to file that will be seeded.
            created_by: "created by" field.
            comment: comment to torrent.
            chunk_length: length of piece.
            root_folder: if specified than all files paths will be specified as related to this folder otherwise
                path of first file will be specified as root.
            with_paddings: flag that indicates should padding files be generated or not.

        Returns:
            path to generated torrent file.
        """
        pieces_hash = b''

        file_path = file_path if isinstance(file_path, list) else [file_path]
        if not file_path:
            raise TorrentsHelperException('Expected that at least one file '
                                          'will be passed to generator.')
        for file_ in file_path:
            if not path.isfile(str(file_)):
                raise TorrentsHelperException('%s file does not exists.' %
                                              str(file_))

        _, torrent_file_path = mkstemp(suffix='.torrent', prefix='wg_temp_')

        root_folder = root_folder or path.dirname(str(file_path[0]))
        padding_folder = path.join(root_folder, '.pad')
        files_list = []  # tuple e.g. (file_path, file_attr)
        cached_chunk = b''
        for i, file_ in enumerate(file_path):
            files_list.append((str(file_), None))
            with open(str(file_), 'rb') as file_handler:
                for chunk in iter(partial(file_handler.read, chunk_length), b''):
                    cached_chunk += chunk
                    if len(cached_chunk) >= chunk_length:
                        pieces_hash += sha1(cached_chunk[:chunk_length]).digest()
                        offset = file_handler.tell() - (len(cached_chunk) - chunk_length)
                        file_handler.seek(offset)
                        cached_chunk = b''
                    # if with_padding and not the last file
                    elif with_paddings and i + 1 < len(file_path):
                        if not path.isdir(padding_folder):
                            makedirs(padding_folder)
                        bytes_left = chunk_length - len(cached_chunk)
                        padding_file = path.join(
                            padding_folder, str(bytes_left))
                        padding_content = b'\x00' * bytes_left
                        if not path.isfile(padding_file) or \
                                stat(padding_file).st_size != bytes_left:
                            with open(padding_file, 'wb') as ps:
                                ps.write(padding_content)
                        files_list.append((padding_file, 'p'))
                        pieces_hash += \
                            sha1(cached_chunk + padding_content).digest()
                        cached_chunk = b''

        # if we have completed loop over files but trailing chunk is present
        if cached_chunk:
            pieces_hash += sha1(cached_chunk).digest()

        data = {'url-list': [webseed],
                'creation date': int(time()),
                'encoding': 'UTF-8'}

        info = {}
        if len(file_path) > 1:
            info['name'] = path.basename(root_folder)
            info['files'] = []
            for file_, file_attr in files_list:
                rel_path = path.relpath(file_, root_folder)
                file_rel_path = list(path.split(rel_path)) if \
                    path.sep in rel_path else [rel_path]
                file_info = {'length': path.getsize(file_),
                             'path': file_rel_path}
                if file_attr:
                    file_info['attr'] = file_attr

                info['files'].append(file_info)
        else:
            info['name'] = path.basename(files_list[0][0])
            info['length'] = path.getsize(files_list[0][0])

        data['info'] = info
        data['info'].update({'piece length': chunk_length,
                             'pieces': pieces_hash})

        if comment:
            data['comment'] = comment
        if created_by:
            data['created by'] = created_by

        data = bencodepy.encode(data)

        with open(torrent_file_path, 'wb') as torrent_file:
            torrent_file.write(data)

        return torrent_file_path
