# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

import string
import random


class RandomHelper(object):

    @classmethod
    def generate_suffix(cls, text: str, suffix_length: int = 4,
                        suffix_symbols: str = string.digits + string.ascii_lowercase, delimiter: str = '.') -> str:
        """
        Generates suffix for given text.

        Args:
            text: initial text.
            suffix_length: length of generated suffix.
            suffix_symbols: symbols that can be used in prefix.
            delimiter: symbols that can be used in prefix.

        Returns:
            text with random suffix.
        """
        suffix = ''.join(random.choice(suffix_symbols) for _ in range(suffix_length))
        text = f'{text}{delimiter}{suffix}'
        return text
