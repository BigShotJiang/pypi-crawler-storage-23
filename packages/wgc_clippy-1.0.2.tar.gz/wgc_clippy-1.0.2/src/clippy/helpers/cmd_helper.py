# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from typing import Dict

import subprocess
import signal
import os

from logging import getLogger

log = getLogger(__name__)


class CalledProcessError(subprocess.CalledProcessError):

    def __str__(self):
        if self.returncode and self.returncode < 0:
            try:
                return "Command '%s' died with %r. Output: %s" % (
                    self.cmd, signal.Signals(-self.returncode), self.output)
            except ValueError:
                return "Command '%s' died with unknown signal %d. " \
                       "Output: %s" % (self.cmd, -self.returncode, self.output)
        else:
            return "Command '%s' returned non-zero exit status %d. " \
                   "Output: %s" % (self.cmd, self.returncode, self.output)


class CmdHelper:

    @classmethod
    def execute(cls, command: str, dont_wait: bool = False, timeout: int = 60, input: str = None,
                dont_redirect_out_error: bool = False, ignore_errors: bool = False, log_command: bool = True):
        """
        Executes given command via command line.

        Args:
            command: command that should be executed.
            dont_wait: flag that indicates should we wait before completion or not.
            timeout: process timeout.
            input: input (doesn't used with flag dont_wait).
            dont_redirect_out_error: redirect stdout and stderr or not for process.
            ignore_errors: ignore errors during execution.
            log_command: if enabled then command will be logged.

        Returns:
            execution output.
        """
        result = None
        if log_command:
            log.debug('Executing command with flag dont_wait=%s: %s' % (dont_wait, command))
        if dont_wait:
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= (
                    subprocess.STARTF_USESTDHANDLES | subprocess.STARTF_USESHOWWINDOW
                )
                startupinfo.wShowWindow = subprocess.SW_HIDE
            if dont_redirect_out_error:
                return subprocess.Popen(
                    command, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, startupinfo=startupinfo)
            else:
                return subprocess.Popen(
                    command, shell=True, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, startupinfo=startupinfo)
        else:
            try:
                result = subprocess.check_output(
                    command, shell=True, stderr=subprocess.STDOUT,
                    timeout=timeout, input=input)
            except subprocess.CalledProcessError as e:
                if not ignore_errors:
                    raise CalledProcessError(
                        e.returncode, e.cmd, e.output)
            except subprocess.TimeoutExpired as e:
                if not ignore_errors:
                    raise subprocess.TimeoutExpired(command, timeout, e.output)
            except OSError as e:
                log.debug(f'{e} during execution {command}')
                if not ignore_errors:
                    raise e

        return result

    @classmethod
    def get_file_properties(cls, file_path: str) -> Dict[str, str]:
        """
        Gets file properties.

        Args:
            file_path: file path.

        Returns:
            file properties.
        """
        file_properties = {}
        for property_name in ['CompanyName',
                              'FileDescription',
                              'FileVersion',
                              'InternalName',
                              'LegalCopyright',
                              'LegalTrademarks1',
                              'LegalTrademarks2',
                              'OriginalFilename',
                              'ProductName',
                              'ProductVersion']:
            file_properties[property_name] = \
                cls.execute('powershell (get-item "%s").'
                            'VersionInfo.%s' % (file_path,
                                                property_name),
                            timeout=60).strip()

        return file_properties
