# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import os
import socket
import sys
import time
from typing import List, Union, Dict, Optional
import re
import hashlib
import chardet
from glob import glob
from os import path, walk, remove, rename
import platform
from pathlib import Path
import shutil
from time import sleep
from binascii import crc32
from logging import getLogger
from urllib import request
from urllib.error import HTTPError, URLError
import locale
import subprocess
import ctypes
import ctypes.wintypes as wintypes

import psutil

if platform.system() == 'Windows':
    import pywintypes
    import win32api

from .cmd_helper import CmdHelper, CalledProcessError
from ..exceptions import ClippyException
from .regex_helper import RegexHelper
from .process_helper import terminate_process

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

HWND = wintypes.HWND
LPARAM = wintypes.LPARAM
DWORD = wintypes.DWORD
BOOL = wintypes.BOOL

EnumWindowsProc = ctypes.WINFUNCTYPE(BOOL, HWND, LPARAM)

WM_CLOSE = 0x0010
PROCESS_TERMINATE = 0x0001
SYNCHRONIZE = 0x00100000
WAIT_TIMEOUT = 0x00000102

# Signatures
user32.EnumWindows.argtypes = [EnumWindowsProc, LPARAM]
user32.EnumWindows.restype = BOOL

user32.GetWindowTextLengthW.argtypes = [HWND]
user32.GetWindowTextLengthW.restype = ctypes.c_int

user32.GetWindowTextW.argtypes = [HWND, ctypes.c_wchar_p, ctypes.c_int]
user32.GetWindowTextW.restype = ctypes.c_int

user32.GetWindowThreadProcessId.argtypes = [HWND, ctypes.POINTER(DWORD)]
user32.GetWindowThreadProcessId.restype = DWORD

user32.PostMessageW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.PostMessageW.restype = BOOL

kernel32.OpenProcess.argtypes = [DWORD, wintypes.BOOL, DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE

kernel32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
kernel32.TerminateProcess.restype = wintypes.BOOL

kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
kernel32.CloseHandle.restype = wintypes.BOOL

kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, DWORD]
kernel32.WaitForSingleObject.restype = DWORD

TH32CS_SNAPPROCESS = 0x00000002
INVALID_HANDLE_VALUE = -1


class PROCESSENTRY32(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.c_void_p),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", ctypes.c_char * 260)
    ]

log = getLogger(__name__)


def _iter_all_windows():
    hwnds = []
    
    @EnumWindowsProc
    def _callback(hwnd, lparam):
        hwnds.append(hwnd)
        return True
    
    user32.EnumWindows(_callback, 0)
    return hwnds


def _get_window_title(hwnd: int) -> str:
    length = user32.GetWindowTextLengthW(hwnd)
    if length == 0:
        return ""
    buf = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buf, length + 1)
    return buf.value or ""


def _get_window_pid(hwnd: int) -> int:
    pid = DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value


def _wait_for_exit(hprocess, timeout_sec: float) -> bool:
    if timeout_sec <= 0:
        return False
    ms = int(timeout_sec * 1000)
    res = kernel32.WaitForSingleObject(hprocess, ms)
    return res != WAIT_TIMEOUT


def _hard_kill_pid(pid: int, timeout_sec: float = 3.0) -> bool:
    access = PROCESS_TERMINATE | SYNCHRONIZE
    hprocess = kernel32.OpenProcess(access, False, pid)
    if not hprocess:
        return False
    try:
        ok = kernel32.TerminateProcess(hprocess, 1)
        if not ok:
            return False
        return _wait_for_exit(hprocess, timeout_sec)
    finally:
        kernel32.CloseHandle(hprocess)


class OSHelper:
    
    @classmethod
    def close_error_popups(
            cls,
            title_substrings=None,
            kill_owners: bool = False,
            max_passes: int = 3,
            sleep_between: float = 0.3,
    ):
        """
        Closes system/error windows by using part of their title.
        Example: before running tests, call with ["Bad Image", "dummy_game.exe"].
        
        title_substrings: List of substrings that should appear in the window title
        kill_owners: Additionally, hard kill the process that owns the window
        """
        if title_substrings is None:
            title_substrings = ["Bad Image", "Application Error"]
        
        me = os.getpid()
        
        for _ in range(max_passes):
            closed_any = False
            
            for hwnd in _iter_all_windows():
                title = _get_window_title(hwnd)
                if not title:
                    continue
                
                lower = title.lower()
                if not any(sub.lower() in lower for sub in title_substrings):
                    continue

                user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
                closed_any = True
                
                if kill_owners:
                    pid = _get_window_pid(hwnd)
                    if pid and pid != me:
                        _hard_kill_pid(pid)
            
            if not closed_any:
                break
            
            time.sleep(sleep_between)
    
    @classmethod
    def remove_file_or_directory(cls, path_: str, system_delete: bool = False, ignore_errors: bool = True) -> bool:
        """
        Removes file or directory.

        Args:
            path_: path to file or directory that should be removed.
            system_delete: if True then "rmdir" command will be used.
            ignore_errors: flag that indicates should we ignore errors or not.

        Returns:
            True if path was deleted or False if not.
        """
        
        def rem_error(*args):
            func, path, e = args  # onerror returns a tuple containing function, path and exception info
            log.error(e[1])
        
        path_ = str(path_)
        if '*' in path_:
            items = glob(path_, recursive=True)
        else:
            items = [path_]
        path_results = []
        for path_ in items:
            if not list(Path(path_).parents):
                path_results.append(False)
            if path.isfile(path_):
                try:
                    remove(path_)
                except (WindowsError, PermissionError) as e:
                    log.debug(e)
                    if not ignore_errors:
                        raise e
            else:
                if system_delete:
                    if path.basename(path_) == '*':
                        CmdHelper.execute('FOR /D %%i IN ("%s") DO RD /S /Q '
                                          '"\\\\?\\%%i"%s' %
                                          (path_, ' || exit 0' * ignore_errors),
                                          timeout=200, ignore_errors=ignore_errors)
                        CmdHelper.execute('%s%s' % (path_,
                                                    ' || exit 0' * ignore_errors), ignore_errors=ignore_errors)
                    else:
                        CmdHelper.execute('rmdir "\\\\?\\%s" /s /q%s' %
                                          (path_, ' || exit 0' * ignore_errors),
                                          timeout=200, ignore_errors=ignore_errors)
                else:
                    try_num = 1
                    while True:
                        try:
                            shutil.rmtree(path_, ignore_errors=ignore_errors, onerror=rem_error)
                            break
                        except (WindowsError, PermissionError) as e:
                            log.debug(e)
                            if try_num == 14:
                                raise e
                            if path.isfile(e.filename):
                                try:
                                    remove(e.filename)
                                except (WindowsError, PermissionError):
                                    log.debug(e)
                            else:
                                shutil.rmtree(path_, ignore_errors=True,
                                              onerror=rem_error)
                            if not path.exists(path_):
                                break
                            sleep(1)
                            try_num += 1
            try:
                result = not path.isfile(path_) and not path.isdir(path_)
            except (WindowsError, PermissionError) as e:
                log.debug(e)
                result = False
            path_results.append(result)
        if ignore_errors:
            return True
        return False not in path_results
    
    @classmethod
    def rename_file_or_directory(cls, src: str, dst: str) -> bool:
        """
        Rename file or directory.

        Args:
            src: source object.
            dst: destination object.

        Returns:
            Result of operation.
        """
        result = True
        try:
            rename(src, dst)
        except (WindowsError, PermissionError):
            result = False
        return result
    
    @classmethod
    def create_file(cls, path_name: str, content: str = '', offset: int = 0) -> str:
        """
        Create file with specific content.

        Args:
            offset: the position of the read/write pointer within the file.
            path_name: path for file in filesystem.
            content: file content.

        Returns:
            file path
        """
        try:
            with open(path_name, 'w' + 'b' * isinstance(content, bytes)) as \
                    newfile:
                newfile.seek(offset)
                newfile.write(content)
        except (PermissionError, WindowsError) as e:
            log.error(f'{e}: {path_name}')
            return False
        return path_name
    
    @classmethod
    def append_file(cls, path_name: str, content: str = '', offset: int = 0, whence: int = 0):
        """
        Create file with specific content.

        Args:
            path_name: path for file in filesystem.
            content: file content.

        Returns:
            file path.
        """
        with open(path_name, 'ab') as newfile:
            newfile.seek(offset, whence)
            newfile.write(content.encode('utf-8'))
        return path_name
    
    @classmethod
    def get_running_processes(
            cls,
            processes_name: Union[str, List[str]] = None
    ) -> Dict[str, List[int]]:
        """
        Get running processes using psutil (faster and safer).

        Args:
            processes_name:
                Optional process name or list of names to filter by.
                - Matching is case-insensitive.
                - If a value contains '*' or '?', it is treated as a wildcard pattern.
                - Otherwise, a partial substring match is used (e.g. 'python' will
                  match 'python.exe').

        Returns:
            Dict where keys are process names and values are lists of PIDs.
        """
        log.debug(f'Get list of running processes. filter={processes_name}')
        
        exact_substrings: List[str] = []
        wildcard_patterns: List[re.Pattern] = []
        
        # Normalize filter(s): collect substrings and compiled wildcard regex.
        if processes_name:
            if isinstance(processes_name, str):
                processes_name = [processes_name]
            
            for name in processes_name:
                if not name:
                    continue
                
                if '*' in name or '?' in name:
                    pattern = RegexHelper.convert_wildcard_to_regex(name)
                    wildcard_patterns.append(re.compile(pattern, re.IGNORECASE))
                else:
                    exact_substrings.append(name.lower())
        
        processes: Dict[str, List[int]] = {}
        
        for proc in psutil.process_iter(attrs=['name', 'pid']):
            try:
                p_name = proc.info.get('name')
                p_pid = proc.info.get('pid')
                
                if not p_name or p_pid is None:
                    continue
                
                # If no filters are provided, collect everything.
                if exact_substrings or wildcard_patterns:
                    name_lower = p_name.lower()
                    
                    matched = False
                    
                    # Substring filters (case-insensitive).
                    if exact_substrings:
                        for needle in exact_substrings:
                            if needle in name_lower:
                                matched = True
                                break
                    
                    # Wildcard filters.
                    if not matched and wildcard_patterns:
                        for pattern in wildcard_patterns:
                            if pattern.match(p_name):
                                matched = True
                                break
                    
                    if not matched:
                        continue
                
                processes.setdefault(p_name, []).append(int(p_pid))
            
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        return dict(sorted(processes.items()))
    
    @classmethod
    def _terminate(cls, process_name, pid):
        log.debug(f'Trying to kill {process_name} with {pid}')
        terminate_process(pid)
    
    @classmethod
    def terminate_process(cls, process_name: Union[str, List[str]]) -> bool:
        """
        Terminates processes by name in the strict order they are provided.
        """
        # Normalize to list and preserve the exact order provided by the caller.
        if not isinstance(process_name, list):
            targets = [process_name]
        else:
            targets = list(process_name)
        
        if not targets:
            return False
        
        matched = False
        killed_pids: set[int] = set()
        
        for raw_name in targets:
            if not raw_name:
                continue
            
            # Decide whether this target is a "simple" name or a pattern.
            is_pattern = any(ch in raw_name for ch in '*?[]()+^$|')
            raw_lower = raw_name.lower()
            regex = None
            
            if is_pattern:
                try:
                    regex = re.compile(raw_name, re.IGNORECASE)
                except re.error as e:
                    # Invalid regex – fall back to simple substring search.
                    log.debug(f"[terminate_process] Invalid pattern {raw_name!r}: {e}. "
                             f"Falling back to substring match.")
                    regex = None

            for proc in psutil.process_iter(attrs=['pid', 'name']):
                try:
                    p_name = proc.info.get('name')
                    p_pid = proc.info.get('pid')
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
                
                if not p_name or p_pid is None:
                    continue
                
                # Avoid double-killing the same PID if it matched previous target(s).
                if p_pid in killed_pids:
                    continue
                
                p_name_lower = p_name.lower()
                is_target = False
                
                if is_pattern:
                    if regex is not None:
                        # Regex match (case-insensitive).
                        if regex.search(p_name):
                            is_target = True
                    else:
                        # Fallback: substring match on the raw pattern text.
                        if raw_lower in p_name_lower:
                            is_target = True
                else:
                    # Simple exact name match (case-insensitive).
                    if p_name_lower == raw_lower:
                        is_target = True
                
                if not is_target:
                    continue
                
                # We have a match for the current target in the defined order.
                cls._terminate(p_name, int(p_pid))
                killed_pids.add(int(p_pid))
                matched = True
        
        return matched
    
    @classmethod
    def is_process_exists(
            cls,
            process_name: str,
            process_list: dict = None
    ) -> int:
        """
        Checks whether a process with the given name exists.
        Includes a native WinAPI fallback if the standard check fails on Windows.
        """
        if not process_name:
            return 0
        
        # 1. Standard check (fast, cached)
        processes = process_list or cls.get_running_processes()
        needle = process_name.lower()
        has_wildcards = ('*' in process_name) or ('?' in process_name)
        
        compiled_pattern: Optional[re.Pattern] = None
        if has_wildcards:
            pattern_str = RegexHelper.convert_wildcard_to_regex(process_name)
            compiled_pattern = re.compile(pattern_str, re.IGNORECASE)
        
        for name, pid_value in processes.items():
            if not name:
                continue
            
            # Logic extracted to avoid code duplication
            if cls._match_name(name, needle, compiled_pattern):
                pid = cls._resolve_pid(pid_value)
                if pid > 0:
                    log.debug("is_process_exists(%r) -> return %s (standard)", process_name, pid)
                    return pid
        
        # 2. Professional Fallback: Native WinAPI (Windows only)
        if sys.platform == 'win32' and process_list is None:
            native_pid = cls._find_process_native_win(needle, compiled_pattern)
            if native_pid > 0:
                log.info("is_process_exists(%r) -> found %s via WinAPI fallback (missed by standard list)", process_name, native_pid)
                return native_pid
        
        return 0
    
    @staticmethod
    def _match_name(name: str, needle: str, pattern: Optional[re.Pattern]) -> bool:
        if pattern:
            return bool(pattern.match(name))
        return needle in name.lower()
    
    @staticmethod
    def _resolve_pid(pid_value) -> int:
        if isinstance(pid_value, (list, tuple, set)):
            try:
                # Filter None and find min
                valid = [int(p) for p in pid_value if p is not None]
                return min(valid) if valid else 0
            except ValueError:
                return 0
        try:
            return int(pid_value)
        except (TypeError, ValueError):
            return 0
    
    @classmethod
    def _find_process_native_win(cls, needle_lower: str, pattern: Optional[re.Pattern]) -> int:
        """
        Directly queries Windows Kernel via CreateToolhelp32Snapshot.
        This ignores permissions that might block 'OpenProcess' but still lists the PID and Name.
        """
        try:
            kernel32 = ctypes.windll.kernel32
            hProcessSnap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
            
            if hProcessSnap == INVALID_HANDLE_VALUE:
                return 0
            
            pe32 = PROCESSENTRY32()
            pe32.dwSize = ctypes.sizeof(PROCESSENTRY32)
            
            if not kernel32.Process32First(hProcessSnap, ctypes.byref(pe32)):
                kernel32.CloseHandle(hProcessSnap)
                return 0
            
            found_pid = 0
            while True:
                # szExeFile is bytes in Python 3 ctypes, need decoding
                try:
                    exe_name = pe32.szExeFile.decode('utf-8', 'ignore')
                except Exception:
                    exe_name = ""
                
                if exe_name:
                    if cls._match_name(exe_name, needle_lower, pattern):
                        found_pid = int(pe32.th32ProcessID)
                        break
                
                if not kernel32.Process32Next(hProcessSnap, ctypes.byref(pe32)):
                    break
            
            kernel32.CloseHandle(hProcessSnap)
            return found_pid
        except Exception as e:
            log.error(f"WinAPI process check failed: {e}")
            return 0
    
    @classmethod
    def get_process_ram(cls, name: str) -> str:
        """
        Gets process ram.

        Args:
            name: name of process.

        Returns:
            process memory percent.
        """
        result = None
        for process in psutil.process_iter():
            try:
                if re.match(name, process.name()):
                    result = process
                    break
            except psutil.NoSuchProcess:
                pass
        if result is not None:
            memory_percent = result.memory_percent()
            log.info(memory_percent)
            return memory_percent
    
    @classmethod
    def get_os_version(cls) -> str:
        """
        Gets current OS version.

        Returns:
            current OS version.
        """
        # cut build num from full version
        version = '.'.join(platform.version().split('.', 2)[:-1])
        return version
    
    @classmethod
    def is_os_version_11(cls):
        if int(platform.version().split('.', 2)[2]) >= 22000 and int(platform.version().split('.', 2)[0]) == 10:
            return True
        return False
    
    @classmethod
    def get_os_language(cls) -> str:
        """
        Gets OS language.

        Returns:
            OS language.
        """
        current_system = platform.system()
        if current_system == 'Windows':
            lang = locale.windows_locale[
                ctypes.windll.kernel32.GetUserDefaultUILanguage()]
        elif current_system == 'Darwin':
            lang = subprocess.check_output("osascript -e 'user locale of (get system info)'", shell=True).decode()
        else:
            raise ClippyException(f'Can\'t determine os language for platform: {current_system}')
        lang = lang.split('_')[0]
        return lang
    
    @classmethod
    def get_full_os_name(cls) -> str:
        """
        Gets full OS name.

        Returns:
            full os name.
        """
        full_os_name = ' '.join([platform.uname()[0], platform.uname()[2],
                                 '(%s)' % ('x64' if '64' in platform.uname()[4]
                                           else 'x86')])
        return full_os_name
    
    @classmethod
    def get_file_crc(cls, file_path: str) -> str:
        """
        Gets crc of file.

        Args:
            file_path: path to file.

        Returns:
            file crc.
        """
        file_path = f'\\\\?\\{file_path}'
        if path.isfile(file_path):
            with open(file_path, 'rb') as file_:
                content = file_.read()
            crc = crc32(content) % (1 << 32)
            return hex(crc).rstrip('L')
    
    @classmethod
    def get_file_md5(cls, file_path: str) -> str:
        """
        Gets md5 of file.

        Args:
            file_path: path to file.

        Returns:
            file md5
        """
        if path.isfile(file_path):
            hash_md5 = hashlib.md5()
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(128 * hash_md5.block_size), b''):
                    hash_md5.update(chunk)
            return hash_md5.hexdigest()
    
    @classmethod
    def get_file_sha1(cls, file_path: str) -> str:
        """
        Gets sha1 of file.

        Args:
            file_path: path to file.

        Returns:
            file sha1.
        """
        if path.isfile(file_path):
            hash_sha1 = hashlib.sha1()
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_sha1.update(chunk)
            return hash_sha1.hexdigest()
    
    @classmethod
    def get_file_sha256(cls, file_path: str) -> str:
        """
        Gets sha256 of file.

        Args:
            file_path: path to file.

        Returns:
            file sha256.
        """
        if path.isfile(file_path):
            sha256 = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for block in iter(lambda: f.read(4096), b''):
                    sha256.update(block)
            return sha256.hexdigest()
    
    @classmethod
    def get_listening_ports(cls, process_name: str) -> List[int]:
        """
        Get listening ports for process.

        Args:
            process_name: name of process.

        Returns:
            List of listening ports.
        """
        ports = []
        for process in psutil.process_iter():
            try:
                if process_name in process.name():
                    connections = process.connections()
                    for conn in connections:
                        ports.append(conn.laddr[1])
            except (OSError, psutil.NoSuchProcess):
                pass
        return ports
    
    @classmethod
    def get_open_connections(cls, process_name) -> List[object]:
        """
        Get opened connections for process.

        Args:
            process_name: name of process.
        Returns:
            List of connections.
        """
        for process in psutil.process_iter():
            if process_name in process.name():
                connections = process.connections()
                return [con for con in connections if con.status == 'ESTABLISHED']
    
    @classmethod
    def get_file_content(cls, file_path: str) -> str:
        """
        Get file content.

        Args:
            file_path: path to file.

        Returns:
            file content.
        """
        retries = 2
        try_num = 1
        
        if path.isfile(file_path):
            while True:
                try:
                    with open(file_path, 'rb') as sp:
                        data = sp.read()
                        encoding = chardet.detect(data)['encoding']
                        if encoding:
                            return data.decode(encoding, errors='ignore')
                        else:
                            return data.decode('utf-8', errors='ignore')
                except PermissionError as e:
                    try_num += 1
                    if try_num == retries:
                        return ''
                    log.error(e)
                    sleep(.2)
        return ''
    
    @classmethod
    def get_latest_line_content(cls, file_path: str) -> str:
        """
        Get latest line in file content.

        Args:
            file_path: path to file.

        Returns:
            file content.
        """
        retries = 2
        try_num = 1
        
        if path.isfile(file_path):
            while True:
                try:
                    with open(file_path, 'rb') as sp:
                        lines = sp.readlines()
                        lines = lines or ['']
                        encoding = chardet.detect(lines[-1])['encoding']
                        return lines[-1].decode(encoding, errors='ignore')
                except PermissionError as e:
                    try_num += 1
                    if try_num == retries:
                        return ''
                    log.error(e)
                    sleep(.2)
    
    @classmethod
    def get_all_files_in_dirs(cls, start_directory: str, pattern: str) -> List[str]:
        """
        Get all files in dir and subdirs.

        Args:
            start_directory: directory from start.
            pattern: file pattern for search.

        Returns:
            list of files.
        """
        files = []
        for dir_, _, _ in walk(start_directory):
            files.extend(glob(path.join(dir_, pattern)))
        return files
    
    @classmethod
    def get_processes(cls, pattern: str) -> Dict[str, int]:
        """
        Gets processes.

        Arguments:
            pattern: process name pattern.

        Returns:
            Process names with pid.
        """
        result = {}
        for process in psutil.process_iter():
            try:
                name = process.name()
                if re.match(pattern, name):
                    result[name] = process.pid
            except psutil.NoSuchProcess:
                pass
        return result
    
    @classmethod
    def is_web_path_exist(cls, url: str) -> bool:
        """
        Verifies that web path exist.

        Args:
            url: web path that will be checked.

        Returns:
            True if exist otherwise False.
        """
        try:
            request.urlopen(url, timeout=15)
        except (HTTPError, URLError, AttributeError, ConnectionError) as e:
            log.debug(f'{e} {url}')
            return False
        except socket.timeout:
            log.debug(f'socket.timeout error: {url}')
            for _ in range(3):
                sleep(3)
                try:
                    request.urlopen(url)
                    return True
                except (HTTPError, URLError, AttributeError, ConnectionError) as e:
                    log.debug(f'{e} {url}')
                    continue
                except socket.timeout:
                    log.debug(f'socket.timeout error: {url}')
                    continue
            return False
        return True
    
    @classmethod
    def get_file_copyright(cls, file_path: str) -> str:
        """
        Returns file copyright.

        Args:
            file_path: path to the file

        Returns:
            File copyright from details formatted as string
        """
        result = ''
        if platform.system() == 'Windows' and path.isfile(file_path):
            try:
                lang, codepage = win32api.GetFileVersionInfo(file_path, '\\VarFileInfo\\Translation')[0]
                result = win32api.GetFileVersionInfo(file_path,
                                                     u'\\StringFileInfo\\%04X%04X\\LegalCopyright' % (lang, codepage))
            except pywintypes.error:
                log.debug(f'File {file_path} does not have copyright attributes')
        return result
    
    @classmethod
    def get_file_company_name(cls, file_path: str) -> str:
        """
        Returns file company name.

        Args:
            file_path: path to the file

        Returns:
            File company name from details formatted as string
        """
        result = ''
        if platform.system() == 'Windows' and path.isfile(file_path):
            try:
                lang, codepage = win32api.GetFileVersionInfo(file_path, '\\VarFileInfo\\Translation')[0]
                result = win32api.GetFileVersionInfo(file_path,
                                                     u'\\StringFileInfo\\%04X%04X\\CompanyName' % (lang, codepage))
            except pywintypes.error:
                log.debug(f'File {file_path} does not have company name attributes')
        return result
    
    @classmethod
    def get_file_product_name(cls, file_path: str) -> str:
        """
        Returns file product name.

        Args:
            file_path: path to the file

        Returns:
            File product name from details formatted as string
        """
        result = ''
        if platform.system() == 'Windows' and path.isfile(file_path):
            try:
                lang, codepage = win32api.GetFileVersionInfo(file_path, '\\VarFileInfo\\Translation')[0]
                result = win32api.GetFileVersionInfo(file_path,
                                                     u'\\StringFileInfo\\%04X%04X\\FileDescription' % (lang, codepage))
            except pywintypes.error:
                log.debug(f'File {file_path} does not have file description attributes')
        return result
    
    @classmethod
    def get_process_io_priority(cls, process_name: str) -> str:
        """
        Get process IO Priority value.

        Args:
            process_name: name of process.

        Returns:
            IO priority as string.
        """
        result = None
        for process in psutil.process_iter():
            try:
                if re.match(process_name, process.name()):
                    result = process
                    break
            except psutil.NoSuchProcess:
                pass
        if result is not None:
            return str(result.ionice())
