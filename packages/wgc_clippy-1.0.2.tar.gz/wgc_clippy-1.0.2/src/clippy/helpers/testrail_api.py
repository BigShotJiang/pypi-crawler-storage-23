# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import json
import ssl
import requests
from requests.packages.urllib3 import PoolManager
from requests.adapters import HTTPAdapter
from urllib3.util.ssl_ import create_urllib3_context


# This is the 2.11 Requests cipher string.
CIPHERS = (
    'ECDH+AESGCM:DH+AESGCM:ECDH+AES256:DH+AES256:ECDH+AES128:DH+AES:ECDH+HIGH:'
    'DH+HIGH:ECDH+3DES:DH+3DES:RSA+AESGCM:RSA+AES:RSA+HIGH:RSA+3DES:!aNULL:'
    '!eNULL:!MD5'
)

requests.packages.urllib3.disable_warnings()


class Ssl3HttpAdapter(HTTPAdapter):

    def init_poolmanager(self, connections, maxsize, block=False, *args, **kwargs):
        self.poolmanager = PoolManager(
            num_pools=connections, maxsize=maxsize,
            block=block, ssl_version=ssl.PROTOCOL_SSLv23)


class DESAdapter(HTTPAdapter):

    def init_poolmanager(self, connections, maxsize, block=False, *args, **kwargs):
        context = create_urllib3_context(ciphers=CIPHERS)
        kwargs['ssl_context'] = context
        self.poolmanager = PoolManager(
            num_pools=connections, maxsize=maxsize,
            block=block, ssl_version=ssl.PROTOCOL_SSLv23, *args, **kwargs)


class TestRailError(Exception):
    pass


class TestRail:
    def __init__(self, base_url, user, password, project_id):
        self.project_id = project_id
        self.test_runs = Runs(base_url, user, password)
        self.tests = Tests(base_url, user, password)
        self.test_result = Results(base_url, user, password)
        self.test_cases = Cases(base_url, user, password)
        self.test_plans = Plans(base_url, user, password)
        self.test_suites = Suites(base_url, user, password)
        self.test_sections = Sections(base_url, user, password)
        self.users = Users(base_url, user, password)
        self.configs = Configurations(base_url, user, password)

    def get_conf(self, project_id, run_id, run_type):
        assert run_type, 'type required'
        cfg_ids = []
        for run in getattr(self, 'iter_runs_from_%s' % run_type)(run_id):
            cfg_ids.extend([_ids for _ids in run[u'config_ids']])
        prj_cfg = self.configs.get_configs(project_id)
        for e in prj_cfg:
            if len(set(ids[u'id'] for ids in e[u'configs']) & set(cfg_ids)) > 1:
                raise Exception(
                    'Checked several parameters for the "{0}" '
                    'configuration group'.format(e[u'name'])
                )
            for cfg in e[u'configs']:
                if cfg[u'id'] in cfg_ids:
                    yield e[u'name'], cfg[u'name']

    def iter_runs_from_run(self, run_id):
        yield self.test_runs.get_run(run_id)

    def iter_runs_from_test_plan(self, plan_id):
        test_runs = []
        test_entries = self.test_plans.get_plan(plan_id)[u'entries']
        for te in test_entries:
            test_runs.extend(te[u'runs'])
        return test_runs

    def get_tests(self, run_type, *args, **kwargs):
        assert run_type, 'type required'
        return getattr(self, 'iter_tests_from_%s' % run_type)(*args, **kwargs)

    def iter_tests_from_run(self, run_id):
        run_tests = self.tests.get_tests(run_id)
        for test in run_tests:
            if test[u'custom_autotest']:
                yield test[u'custom_autotest'], test[u'priority_id'], test[u'id'], test[u'status_id']

    def iter_tests_from_test_plan(self, plan_id):
        test_runs = self.iter_runs_from_test_plan(plan_id)
        test_runs_ids = [run[u'id'] for run in test_runs]
        for _id in test_runs_ids:
            for i in self.iter_tests_from_run(_id):
                yield i

    def check_parameters(self, run_type, *args, **kwargs):
        assert run_type, 'type required'
        status = getattr(self, 'check_%s' % run_type)(*args, **kwargs)
        if status.get(u'is_completed'):
            return False, 'Test plan/run is closed'
        return True, None

    def check_run(self, run_id):
        return self.test_runs.get_run(run_id)

    def check_test_plan(self, plan_id):
        return self.test_plans.get_plan(plan_id)

    def get_user_id_by_login(self, login):
        return next(user[u'id'] for user in self.users.get_users() if user[u'email'].startswith(login))

    def get_cases(self):
        cases = []
        suites = self.test_suites.get_suites(self.project_id)
        for s in suites:
            for c in self.test_cases.get_cases(self.project_id,
                                               suite_id=s['id']):
                cases.append(c)
        return cases


class TestRailRequester:
    def __init__(self, base_url, user, password):
        self.base_url = base_url
        self.headers = {'Content-Type': 'application/json'}
        self.session = requests.Session()
        self.session.mount(self.base_url, DESAdapter())
        self.session.auth = (user, password)

    @classmethod
    def raise_for_status(cls, response):
        try:
            response.raise_for_status()
        except Exception as e:
            if len(response.content) > 0 and response.headers.get(
                    'Content-Type') == 'application/json; charset=utf-8':
                content = response.json()
                if u'error' in content:
                    e = TestRailError(content.get(u'error'))
            raise e

    def request(self, uri, data=None, request_method='GET', filters=None):
        url = self.base_url + uri
        if data:
            request_method = 'POST'

        if filters:
            url += ''.join(['&%s=%s' % f for f in filters.items()])

        response = self.session.request(
            request_method,
            url,
            headers=self.headers,
            data=json.dumps(data),
            verify=False
        )
        self.raise_for_status(response)
        if len(response.content) > 0:
            return response.json()


class Results(TestRailRequester):

    def get_results(self, test_id, filters=None):
        return self.request('/get_results/%s' % test_id, filters=filters)

    def get_results_for_case(self, run_id, case_id, filters=None):
        return self.request('/get_results_for_case/%s/%s' % (run_id, case_id),
                            filters=filters)

    def get_results_for_run(self, run_id, filters=None):
        return self.request('/get_results_for_run/%s' % run_id,
                            filters=filters)

    def add_result(self, test_id, **kwargs):
        return self.request('/add_result/%s' % test_id, kwargs)

    def add_result_for_case(self, run_id, case_id, **kwargs):
        return self.request('/add_result_for_case/%s/%s' % (run_id, case_id),
                            kwargs)

    def add_results(self, run_id, **kwargs):
        return self.request('/add_results/%s' % run_id, kwargs)

    def add_results_for_cases(self, run_id, **kwargs):
        return self.request('/add_results_for_cases/%s' % run_id, kwargs)


class Tests(TestRailRequester):

    def get_test(self, test_id):
        return self.request('/get_test/%s' % test_id)

    def get_tests(self, run_id, filters=None):
        return self.request('/get_tests/%s' % run_id, filters=filters)


class Cases(TestRailRequester):

    def get_case(self, case_id):
        return self.request('/get_case/%s' % case_id)

    def get_cases(self, project_id, filters=None, **kwargs):
        req = '/get_cases/%s' % project_id
        if kwargs:
            for arg in kwargs.items():
                req += '&%s=%s' % arg
        return self.request(req, filters=filters)

    def add_case(self, section_id, **kwargs):
        return self.request('/add_case/%s' % section_id, kwargs)

    def update_case(self, case_id, **kwargs):
        return self.request('/update_case/%s' % case_id, kwargs)

    def delete_case(self, case_id):
        return self.request('/delete_case/%s' % case_id, request_method='POST')


class Suites(TestRailRequester):

    def get_suite(self, suite_id):
        return self.request('/get_suite/%s' % suite_id)

    def get_suites(self, project_id):
        return self.request('/get_suites/%s' % project_id)

    def add_suite(self, project_id, **kwargs):
        return self.request('/add_suite/%s' % project_id, kwargs)

    def update_suite(self, suite_id, **kwargs):
        return self.request('/update_suite/%s' % suite_id, kwargs)

    def delete_suite(self, suite_id):
        return self.request('/delete_suite/%s' % suite_id,
                            request_method='POST')


class Sections(TestRailRequester):

    def get_section(self, section_id):
        return self.request('/get_section/%s' % section_id)

    def get_sections(self, project_id, suite_id):
        return self.request('/get_sections/%s&suite_id=%s' % (
            project_id, suite_id))

    def add_section(self, project_id, **kwargs):
        return self.request('/add_section/%s' % project_id, kwargs)

    def update_section(self, section_id, **kwargs):
        return self.request('/update_section/%s' % section_id, kwargs)

    def delete_section(self, section_id):
        return self.request('/delete_section/%s' % section_id,
                            request_method='POST')


class Runs(TestRailRequester):

    def get_run(self, run_id):
        return self.request('/get_run/%s' % run_id)

    def get_runs(self, project_id, plan_id, filters=None):
        return self.request('/get_runs/%s/%s' % (project_id, plan_id),
                            filters=filters)

    def add_run(self, project_id, **kwargs):
        return self.request('/add_run/%s' % project_id, kwargs)

    def update_run(self, run_id, **kwargs):
        return self.request('/update_run/%s' % run_id, kwargs)

    def close_run(self, run_id):
        return self.request('/close_run/%s' % run_id, request_method='POST')

    def delete_run(self, run_id):
        return self.request('/delete_run/%s' % run_id, request_method='POST')


class Plans(TestRailRequester):

    def get_plan(self, plan_id):
        return self.request('/get_plan/%s' % plan_id)

    def get_plans(self, project_id, filters=None):
        return self.request('/get_plans/%s' % project_id, filters=filters)

    def add_plan(self, project_id, **kwargs):
        return self.request('/add_plan/%s' % project_id, kwargs)

    def add_plan_entries(self, plan_id, **kwargs):
        return self.request('/add_plan_entry/%s' % plan_id, kwargs)

    def update_plan(self, plan_id, **kwargs):
        return self.request('/update_plan/%s' % plan_id, kwargs)

    def update_plan_entry(self, plan_id, entry_id, **kwargs):
        return self.request('/update_plan_entry/%s/%s' % (plan_id, entry_id),
                            kwargs)

    def close_plan(self, plan_id):
        return self.request('/close_plan/%s' % plan_id, request_method='POST')

    def delete_plan(self, plan_id):
        return self.request('/delete_plan/%s' % plan_id, request_method='POST')

    def delete_plan_entry(self, plan_id, entry_id):
        return self.request('/delete_plan_entry/%s/%s' % (plan_id, entry_id),
                            request_method='POST')


class Milestones(TestRailRequester):

    def get_milestone(self, milestone_id):
        return self.request('/get_milestone/%s' % milestone_id)

    def get_milestones(self, project_id, filters=None):
        return self.request('/get_milestones/%s' % project_id, filters=filters)

    def add_milestone(self, project_id, **kwargs):
        return self.request('/add_milestone/%s' % project_id, kwargs)

    def update_milestone(self, milestone_id, **kwargs):
        return self.request('/update_milestone/%s' % milestone_id, kwargs)

    def delete_milestone(self, milestone_id):
        return self.request('/delete_milestone/%s' % milestone_id,
                            request_method='POST')


class Projects(TestRailRequester):

    def get_project(self, project_id):
        return self.request('/get_project/%s' % project_id)

    def get_projects(self, filters=None):
        return self.request('/get_projects', filters=filters)

    def add_project(self, **kwargs):
        return self.request('/add_project', kwargs)

    def update_project(self, project_id, **kwargs):
        return self.request('/update_project/%s' % project_id, kwargs)

    def delete_project(self, project_id):
        return self.request('/delete_project/%s' % project_id, request_method='POST')


class Users(TestRailRequester):

    def get_users(self):
        return self.request('/get_users')

    def get_user(self, id):
        return self.request('/get_user/%s' % id)

    def get_user_by_email(self, email):
        return self.request('/get_user_by_email&email=%s' % email)


class Configurations(TestRailRequester):

    def get_configs(self, project_id):
        return self.request('/get_configs/%s' % project_id)


class CaseFields(TestRailRequester):

    def get_case_fields(self):
        return self.request('/get_case_fields')


class CaseTypes(TestRailRequester):

    def get_case_types(self):
        return self.request('/get_case_types')


class Priorities(TestRailRequester):

    def get_priorities(self):
        return self.request('/get_priorities')


class ResultFields(TestRailRequester):

    def get_result_fields(self):
        return self.request('/get_result_fields')


class Statuses(TestRailRequester):

    def get_statuses(self):
        return self.request('/get_statuses')
