# -*- coding: utf-8 -*-

from __future__ import annotations

__author__ = 'm_beloborodko@wargaming.net'

from typing import Iterator, List
from os import path
import winreg
from enum import Enum


class RegistryHelper:

    HKEY_CURRENT_USER = winreg.HKEY_CURRENT_USER
    HKEY_LOCAL_MACHINE = winreg.HKEY_LOCAL_MACHINE
    HKEY_CLASSES_ROOT = winreg.HKEY_CLASSES_ROOT
    REG_BINARY = winreg.REG_BINARY
    REG_DWORD = winreg.REG_DWORD
    REG_EXPAND_SZ = winreg.REG_EXPAND_SZ
    REG_NONE = winreg.REG_NONE
    REG_SZ = winreg.REG_SZ

    constants = {REG_BINARY: 'REG_BINARY',
                 REG_DWORD: 'REG_DWORD',
                 REG_EXPAND_SZ: 'REG_EXPAND_SZ',
                 REG_NONE: 'REG_NONE',
                 REG_SZ: 'REG_SZ'}

    class FieldType(Enum):
        REG_NONE = 0
        REG_SZ = 1
        REG_EXPAND_SZ = 2
        REG_BINARY = 3
        REG_DWORD = 4
        REG_DWORD_BIG_ENDIAN = 5
        REG_LINK = 6

    @classmethod
    def delete_key(cls, key, current_key: str, arch_key: int = 0):
        """
        Deletes registry key.

        Args:
            key: any one of the predefined HKEY_* constants.
            current_key: string that must be a subkey of the key identified by the key parameter.
            arch_key: winreg.KEY_WOW64_32KEY, winreg.KEY_WOW64_64KEY
        """
        try:
            open_key = winreg.OpenKey(key, current_key, 0, winreg.KEY_ALL_ACCESS | arch_key)
        except FileNotFoundError:
            return
        info_key = winreg.QueryInfoKey(open_key)
        for x in range(0, info_key[0]):
            try:
                sub_key = winreg.EnumKey(open_key, x)
            except OSError as e:
                if e.errno == 22:
                    return
                else:
                    raise e
            try:
                winreg.DeleteKeyEx(open_key, sub_key, winreg.KEY_ALL_ACCESS | arch_key)
            except OSError:
                cls.delete_key(key, path.join(current_key, sub_key))

        winreg.DeleteKey(open_key, "")
        open_key.Close()

    @classmethod
    def delete_value(cls, key: str | int, sub_key: str, value: str):
        """
        Deletes registry value.

        Args:
            key: any one of the predefined HKEY_* constants.
            sub_key: string that must be a subkey of the key identified by the key parameter.
            value: value.
        """
        try:
            _key = winreg.OpenKey(key, sub_key, 0, winreg.KEY_ALL_ACCESS)
            winreg.DeleteValue(_key, value)
        except FileNotFoundError:
            pass

    @classmethod
    def create_key(cls, key: str | int, sub_key: str):
        """
        Creates key.

        Args:
            key: any one of the predefined HKEY_* constants.
            sub_key: string that must be a subkey of the key identified by the key parameter.
        """
        winreg.CreateKey(key, sub_key)

    @classmethod
    def set_value(cls, key: str | int, sub_key: str, key_type: int, name: str, value: str):
        """
        Sets registry value.

        Args:
            key: any one of the predefined HKEY_* constants.
            sub_key: string that must be a subkey of the key identified by the key parameter.
            key_type: key type.
            name: name.
            value: value.
        """
        if not cls.is_key_exist(key, sub_key):
            cls.create_key(key, sub_key)

        _key = winreg.OpenKey(key, sub_key, 0, winreg.KEY_ALL_ACCESS)
        winreg.SetValueEx(_key, name, 0, key_type, value)

    @classmethod
    def is_key_exist(cls, key: str | int, sub_key: str) -> bool:
        """
        Check, whatever register key exists.

        Args:
            key: any one of the predefined HKEY_* constants.
            sub_key: string that must be a subkey of the key identified by the key parameter.

        Returns:
            True if existed, False if not.
        """
        exist = True
        try:
            winreg.OpenKey(key, sub_key, 0, winreg.KEY_ALL_ACCESS)
        except WindowsError:
            exist = False
        return exist

    @classmethod
    def get_key_value(cls, key: str, sub_key: str, parameter: str) -> str:
        """
        Get key value in registry.

        Args:
            key: any one of the predefined HKEY_* constants.
            sub_key: string that must be a subkey of the key identified by the key parameter.
            parameter: parameter name.

        Returns:
            value of registry key.
        """
        con_reg = winreg.ConnectRegistry(None, key)
        try:
            _key = winreg.OpenKey(con_reg, sub_key)
            value = winreg.QueryValueEx(_key, parameter)
        except WindowsError:
            value = None
        return value

    @classmethod
    def iter_keys(cls, key: str, sub_key: str) -> List[str]:
        """
        Iterate registry subkeys by key value.

        Args:
            key: any one of the predefined HKEY_* constants.
            sub_key: string that must be a subkey of the key identified by the key parameter.

        Returns:
            list of subkeys by key in registry.
        """
        result = []
        root_key = winreg.OpenKey(key, sub_key, 0, winreg.KEY_ALL_ACCESS)
        for index in range(winreg.QueryInfoKey(root_key)[0]):
            _sub_key = winreg.EnumKey(root_key, index)
            result.append(_sub_key)
        return result

    @classmethod
    def enum_key(cls, key: str, sub_key: str) -> Iterator:
        """
        Enumerate sub keys.

        Args:
            key: root key.
            sub_key: sub key.

        Returns:
            Iterator with enumerated sub keys.
        """
        root_key = winreg.OpenKey(key, sub_key, 0, winreg.KEY_ALL_ACCESS)
        i = 0
        while True:
            try:
                subkey = winreg.EnumKey(root_key, i)
                yield subkey
                i += 1
            except WindowsError:
                break

    @classmethod
    def enum_value(cls, key: str, sub_key: str) -> Iterator:
        """
        Enumerate values by key/sub key.

        Args:
            key: root key.
            sub_key: sub key.

        Returns:
            Iterator with enumerated values.
        """
        root_key = winreg.OpenKey(key, sub_key, 0, winreg.KEY_ALL_ACCESS)
        try:
            count = 0
            while True:
                name, value, key_type = winreg.EnumValue(root_key, count)
                yield name, value, key_type
                count = count + 1
        except WindowsError:
            pass
