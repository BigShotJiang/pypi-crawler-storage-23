# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import socket
from threading import Thread


class UdpHelper(object):

    messages = []
    _thread = None
    _is_stopped = False

    @classmethod
    def _listen(cls, host, port):
        del cls.messages[:]
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind((host, port))
        while not cls._is_stopped:
            data, addr = sock.recvfrom(1024)  # buffer size is 1024 bytes
            cls.messages.append(data.decode('utf-8'))

    @classmethod
    def start(cls, host, port):
        thread = Thread(target=cls._listen, args=(host, port,))
        thread.daemon = True
        thread.start()

    @classmethod
    def stop(cls):
        cls._is_stopped = True
