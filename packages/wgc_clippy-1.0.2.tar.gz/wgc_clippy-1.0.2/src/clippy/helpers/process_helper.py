# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import ctypes
import os
import signal
import time
from ctypes import wintypes, WinDLL, POINTER, Structure, sizeof, \
    windll, c_long, c_int, c_void_p, byref

import pefile
import win32process

from logging import getLogger

log = getLogger(__name__)

VIRTUAL_MEM = (0x1000 | 0x2000)
LPBOOL = POINTER(wintypes.BOOL)
ERROR_NO_MORE_FILES = 0x0012
ERROR_BAD_LENGTH = 0x0018
ERROR_MOD_NOT_FOUND = 0x007E
INVALID_HANDLE_VALUE = wintypes.HANDLE(-1).value
DONT_RESOLVE_DLL_REFERENCES = 0x00000001
MAX_PATH = 260
MAX_MODULE_NAME32 = 255
TH32CS_SNAPMODULE = 0x00000008
PAGE_READWRITE = 0x04
PAGE_EXECUTE_READWRITE = 0x00000040
DELETE = 0x00010000
READ_CONTROL = 0x00020000
WRITE_DAC = 0x00040000
WRITE_OWNER = 0x00080000
SYNCHRONIZE = 0x00100000
PROCESS_SUSPEND_RESUME = 0x0800
PROCESS_ALL_ACCESS = (DELETE |
                      READ_CONTROL |
                      WRITE_DAC |
                      WRITE_OWNER |
                      SYNCHRONIZE |
                      0xFFF  # If < WinXP/WinServer2003 - 0xFFFF otherwhise
                      )
LPVOID = ctypes.c_void_p
LPCWSTR = ctypes.c_wchar_p
SIZE_T = ctypes.c_size_t
DWORD = ctypes.c_uint32
HANDLE = ctypes.c_void_p
HMODULE = ctypes.c_void_p
BOOL = ctypes.c_bool

# Creation flags
CREATE_SUSPENDED = 0x00000004
MEM_COMMIT_RESERVE = 0x3000
LIST_MODULES_ALL = 0x03
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
user32 = ctypes.WinDLL('user32', use_last_error=True)

HWND = wintypes.HWND
LPARAM = wintypes.LPARAM

PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
SYNCHRONIZE = 0x00100000

WAIT_TIMEOUT = 0x00000102
INFINITE = 0xFFFFFFFF
WM_CLOSE = 0x0010

# OpenProcess
kernel32.OpenProcess.argtypes = [DWORD, BOOL, DWORD]
kernel32.OpenProcess.restype = HANDLE

# TerminateProcess
kernel32.TerminateProcess.argtypes = [HANDLE, UINT := DWORD]
kernel32.TerminateProcess.restype = BOOL

# CloseHandle
kernel32.CloseHandle.argtypes = [HANDLE]
kernel32.CloseHandle.restype = BOOL

# WaitForSingleObject
kernel32.WaitForSingleObject.argtypes = [HANDLE, DWORD]
kernel32.WaitForSingleObject.restype = DWORD

# EnumWindows / GetWindowThreadProcessId / PostMessage
EnumWindowsProc = ctypes.WINFUNCTYPE(BOOL, HWND, LPARAM)

user32.EnumWindows.argtypes = [EnumWindowsProc, LPARAM]
user32.EnumWindows.restype = BOOL

user32.GetWindowThreadProcessId.argtypes = [HWND, ctypes.POINTER(DWORD)]
user32.GetWindowThreadProcessId.restype = DWORD

user32.PostMessageW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.PostMessageW.restype = BOOL


class MODULEENTRY32(ctypes.Structure):
    _fields_ = [
        ('dwSize', wintypes.DWORD),
        ('th32ModuleID', wintypes.DWORD),
        ('th32ProcessID', wintypes.DWORD),
        ('GlblcntUsage', wintypes.DWORD),
        ('ProccntUsage', wintypes.DWORD),
        ('modBaseAddr', ctypes.POINTER(ctypes.c_byte)),
        ('modBaseSize', wintypes.DWORD),
        ('hModule', wintypes.HMODULE),
        ('szModule', wintypes.CHAR * 256),
        ('szExePath', wintypes.CHAR * wintypes.MAX_PATH),
    ]


class MODULEENTRY32W(Structure):
    _fields_ = (('dwSize', wintypes.DWORD),
                ('th32ModuleID', wintypes.DWORD),
                ('th32ProcessID', wintypes.DWORD),
                ('GlblcntUsage', wintypes.DWORD),
                ('ProccntUsage', wintypes.DWORD),
                ('modBaseAddr', wintypes.LPVOID),
                ('modBaseSize', wintypes.DWORD),
                ('hModule', wintypes.HMODULE),
                ('szModule', wintypes.WCHAR * (MAX_MODULE_NAME32 + 1)),
                ('szExePath', wintypes.WCHAR * MAX_PATH))
    
    def __init__(self, *args, **kwds):
        super(MODULEENTRY32W, self).__init__(*args, **kwds)
        self.dwSize = sizeof(self)


class STARTUPINFO(ctypes.Structure):
    _fields_ = [
        ("cb", DWORD),
        ("lpReserved", LPCWSTR),
        ("lpDesktop", LPCWSTR),
        ("lpTitle", LPCWSTR),
        ("dwX", DWORD),
        ("dwY", DWORD),
        ("dwXSize", DWORD),
        ("dwYSize", DWORD),
        ("dwXCountChars", DWORD),
        ("dwYCountChars", DWORD),
        ("dwFillAttribute", DWORD),
        ("dwFlags", DWORD),
        ("wShowWindow", ctypes.c_ushort),
        ("cbReserved2", ctypes.c_ushort),
        ("lpReserved2", ctypes.c_void_p),
        ("hStdInput", HANDLE),
        ("hStdOutput", HANDLE),
        ("hStdError", HANDLE),
    ]


class PROCESS_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("hProcess", HANDLE),
        ("hThread", HANDLE),
        ("dwProcessId", DWORD),
        ("dwThreadId", DWORD),
    ]


LPMODULEENTRY32W = POINTER(MODULEENTRY32W)
CreateToolhelp32Snapshot = windll.kernel32.CreateToolhelp32Snapshot
CreateToolhelp32Snapshot.reltype = c_long
CreateToolhelp32Snapshot.argtypes = [c_int, c_int]
OpenProcess = windll.kernel32.OpenProcess
OpenProcess.argtypes = [c_void_p, c_int, c_long]
OpenProcess.rettype = c_long
NtSuspendProcess = windll.ntdll.NtSuspendProcess
NtSuspendProcess.argtypes = (wintypes.HANDLE,)
NtSuspendProcess.restype = c_long
NtResumeProcess = windll.ntdll.NtResumeProcess
NtResumeProcess.argtypes = (wintypes.HANDLE,)
NtResumeProcess.restype = c_long
GetPriorityClass = windll.kernel32.GetPriorityClass
GetPriorityClass.argtypes = [c_void_p]
GetPriorityClass.rettype = c_long
TerminateProcess = windll.kernel32.TerminateProcess
TerminateProcess.argtypes = (wintypes.HANDLE, wintypes.UINT)
TerminateProcess.rettype = c_int
CloseHandle = windll.kernel32.CloseHandle
CloseHandle.argtypes = [c_void_p]
CloseHandle.rettype = c_int
kernel32.Module32FirstW.argtypes = (wintypes.HANDLE, LPMODULEENTRY32W)
kernel32.Module32FirstW.rettype = c_int
kernel32.Module32NextW.argtypes = (wintypes.HANDLE, LPMODULEENTRY32W)
kernel32.Module32NextW.rettype = c_int
GetLastError = windll.kernel32.GetLastError
GetLastError.rettype = c_long

# --- Constants and Types ---
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
kernel32.GetModuleHandleW.restype = wintypes.HMODULE
kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
psapi = ctypes.WinDLL("psapi", use_last_error=True)

# Define function prototypes
CreateProcessW = kernel32.CreateProcessW
CreateProcessW.argtypes = [
    LPCWSTR,  # lpApplicationName
    LPCWSTR,  # lpCommandLine
    LPVOID,  # lpProcessAttributes
    LPVOID,  # lpThreadAttributes
    BOOL,  # bInheritHandles
    DWORD,  # dwCreationFlags
    LPVOID,  # lpEnvironment
    LPCWSTR,  # lpCurrentDirectory
    ctypes.POINTER(STARTUPINFO),
    ctypes.POINTER(PROCESS_INFORMATION)
]
CreateProcessW.restype = BOOL

EnumProcessModulesEx = psapi.EnumProcessModulesEx
EnumProcessModulesEx.argtypes = [HANDLE, ctypes.POINTER(HMODULE), DWORD, ctypes.POINTER(DWORD), DWORD]
EnumProcessModulesEx.restype = BOOL

GetModuleFileNameExW = psapi.GetModuleFileNameExW
GetModuleFileNameExW.argtypes = [HANDLE, HMODULE, ctypes.c_wchar_p, DWORD]
GetModuleFileNameExW.restype = DWORD

VirtualAllocEx = kernel32.VirtualAllocEx
VirtualAllocEx.argtypes = [HANDLE, LPVOID, SIZE_T, DWORD, DWORD]
VirtualAllocEx.restype = LPVOID

WriteProcessMemory = kernel32.WriteProcessMemory
WriteProcessMemory.argtypes = [HANDLE, LPVOID, LPVOID, SIZE_T, ctypes.POINTER(SIZE_T)]
WriteProcessMemory.restype = BOOL

CreateRemoteThread = kernel32.CreateRemoteThread
CreateRemoteThread.argtypes = [HANDLE, LPVOID, SIZE_T, LPVOID, LPVOID, DWORD, ctypes.POINTER(DWORD)]
CreateRemoteThread.restype = HANDLE

WaitForSingleObject = kernel32.WaitForSingleObject
WaitForSingleObject.argtypes = [HANDLE, DWORD]
WaitForSingleObject.restype = DWORD

ResumeThread = kernel32.ResumeThread
ResumeThread.argtypes = [HANDLE]
ResumeThread.restype = DWORD

CloseHandle = kernel32.CloseHandle
CloseHandle.argtypes = [HANDLE]
CloseHandle.restype = BOOL

CreateToolhelp32Snapshot = kernel32.CreateToolhelp32Snapshot
GetModuleHandleW = kernel32.GetModuleHandleW
GetProcAddress = kernel32.GetProcAddress
GetProcAddress.restype = ctypes.c_void_p
GetProcAddress.argtypes = [wintypes.HMODULE, wintypes.LPCSTR]
Module32First = ctypes.windll.kernel32.Module32First
Module32Next = ctypes.windll.kernel32.Module32Next


def is_x32_process(h_process):
    return win32process.IsWow64Process(h_process)


def raise_last_error(msg=""):
    err = ctypes.get_last_error()
    raise OSError(f"{msg} (LastError: {err})")


def get_module_base_address(pid, module_name):
    """
    Returns the base address of a module in a remote process.
    """
    snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid)
    if snapshot == ctypes.c_void_p(-1).value:
        raise RuntimeError("Failed to take snapshot of modules")
    
    me32 = MODULEENTRY32()
    me32.dwSize = ctypes.sizeof(MODULEENTRY32)
    
    success = Module32First(snapshot, ctypes.byref(me32))
    while success:
        mod_name = me32.szModule.decode("utf-8").lower()
        if mod_name == module_name.lower():
            base_addr = ctypes.cast(me32.modBaseAddr, ctypes.c_void_p).value
            CloseHandle(snapshot)
            return base_addr
        success = Module32Next(snapshot, ctypes.byref(me32))
    
    CloseHandle(snapshot)
    raise RuntimeError(f"Module {module_name} not found in remote process")


def get_remote_proc_address(hProcess, module_name, func_name):
    """
    Gets the address of func_name inside module_name in the remote process.
    """
    
    # Get local base address of module
    
    h_local_mod = GetModuleHandleW(module_name)
    if not h_local_mod:
        raise RuntimeError(f"GetModuleHandleW failed for {module_name}")
    
    # Get local address of function
    func_addr = GetProcAddress(h_local_mod, func_name)
    if not func_addr:
        raise RuntimeError(f"GetProcAddress failed for {func_name}")
    
    # Calculate offset within the module
    offset = func_addr - h_local_mod
    
    # Get remote module base address
    pid = wintypes.DWORD()
    windll.kernel32.GetProcessId(hProcess, ctypes.byref(pid))
    remote_base = get_module_base_address(pid.value, module_name)
    if not remote_base:
        raise RuntimeError(f"Remote module base not found: {module_name}")
    
    # Final address = remote base + offset
    return remote_base + offset


def get_base_addr_module(pid, lib_containing_func="kernel32.dll", func_to_call="LoadLibraryW"):
    h_lib = windll.kernel32.GetModuleHandleW(lib_containing_func)
    if not h_lib:
        # 2.It's not so try using loadlibrary
        h_lib = windll.kernel32.LoadLibraryW(lib_containing_func)
        
        # 3.It's either a typo or a 32bit library so try Get32bitProcAddr(lib_containing_func,  func_to_call)
        # which implicitly calls GetProcessModuleBase(full_module_path)
        if not h_lib:
            try:
                TH32CS_SNAPMODULE32 = 0x00000010
                hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid)
                module_base = 0
                mmem = MODULEENTRY32W()
                ret = kernel32.Module32FirstW(hSnapshot, byref(mmem))
                
                if mmem.szExePath.lower() == str(lib_containing_func.lower()):
                    module_base = mmem.modBaseAddr
                else:
                    while ret:
                        ret = kernel32.Module32NextW(hSnapshot, byref(mmem))
                        if mmem.szExePath.lower() == str(lib_containing_func.lower()):
                            module_base = mmem.modBaseAddr
                            break
                
                pe = pefile.PE(lib_containing_func, fast_load=True)
                pe.parse_data_directories(directories=[
                    pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_EXPORT']])
                addr_list = []
                for exp in pe.DIRECTORY_ENTRY_EXPORT.symbols:
                    if exp.name.decode('utf-8') == func_to_call:
                        addr_list.append(exp.address + module_base)
                h_func = addr_list[0]
            
            except Exception as e:
                raise Exception("Process.Get32bitProcAddr: Error getting function address; %s\n" % str(e))
        else:
            h_func = windll.kernel32.GetProcAddress(h_lib, str(func_to_call))
    else:
        h_func = windll.kernel32.GetProcAddress(h_lib, str(func_to_call))
    return h_func


def suspend_process(pid):
    process_handle = OpenProcess(PROCESS_SUSPEND_RESUME, False, pid)
    try:
        NtSuspendProcess(process_handle)
    finally:
        CloseHandle(process_handle)


def resume_process(pid):
    process_handle = OpenProcess(PROCESS_SUSPEND_RESUME, False, pid)
    try:
        NtResumeProcess(process_handle)
    finally:
        CloseHandle(process_handle)


def _iter_hwnds_for_pid(target_pid: int):
    """
    Enumerate all top-level window handles that belong to the given PID.
    Used to send WM_CLOSE for graceful termination.
    """
    hwnds = []

    @EnumWindowsProc
    def _callback(hwnd, lparam):
        pid = DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == target_pid:
            hwnds.append(hwnd)
        return True  # continue enumeration

    user32.EnumWindows(_callback, 0)
    return hwnds


def _wait_for_exit(process_handle: HANDLE, timeout_seconds: float) -> bool:
    """
    Wait until the process exits or timeout occurs.
    Returns True if process exited, False on timeout.
    """
    if timeout_seconds <= 0:
        return False

    ms = int(timeout_seconds * 1000)
    result = kernel32.WaitForSingleObject(process_handle, ms)
    return result != WAIT_TIMEOUT


def terminate_process(pid: int,
                      timeout_grace: float = 3.0,
                      timeout_kill: float = 5.0,
                      force_exit_code: int = 1) -> bool:
    """
    Graceful-then-force process termination on Windows.

    1) Try to close all top-level windows of the process via WM_CLOSE.
    2) Wait up to `timeout_grace` seconds.
    3) If a process is still alive, call TerminateProcess(pid, force_exit_code).
    4) Wait up to `timeout_kill` seconds for a hard-killed process to exit.

    Returns:
        True – if the process is no longer alive by the time the function exits.
        False – if the handle/access rights could not be obtained or the process is still alive.
    """
    if os.name != 'nt':
        try:
            log.debug(f'Terminating process {pid}: kill({pid}, SIGTERM)')
            os.kill(pid, signal.SIGTERM)
            waited = 0.0
            step = 0.1
            while waited < timeout_grace:
                try:
                    log.debug(f'Terminating process {pid}: kill({pid}, 0)')
                    os.kill(pid, 0)
                except OSError:
                    return True
                time.sleep(step)
                waited += step

            # Force kill
            log.debug(f'Terminating process {pid}: kill({pid}, SIGKILL)')
            os.kill(pid, signal.SIGKILL)
            return True
        except Exception as e:
            log.debug(f"[terminate_process] POSIX kill failed for PID {pid}: {e}")
            return False

    process_handle = None
    try:
        access = PROCESS_TERMINATE | PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE
        process_handle = kernel32.OpenProcess(access, False, pid)

        if not process_handle:
            err = ctypes.get_last_error()
            log.debug(f"[terminate_process] OpenProcess failed for PID {pid}, error={err}")
            return False

        # --- 1. Graceful: send WM_CLOSE to all windows of the process ---
        hwnds = _iter_hwnds_for_pid(pid)
        if hwnds:
            log.debug(f"[terminate_process] Sending WM_CLOSE to {len(hwnds)} windows for PID {pid}")
            for hwnd in hwnds:
                log.debug(f'Sending WM_CLOSE to {hwnd}, PID {pid}')
                user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)

            if _wait_for_exit(process_handle, timeout_grace):
                log.debug(f"[terminate_process] Process {pid} exited gracefully after WM_CLOSE.")
                return True
        else:
            log.debug(f"[terminate_process] No top-level windows found for PID {pid}, skipping WM_CLOSE.")

        # --- 2. Hard kill: TerminateProcess ---
        log.debug(f"[terminate_process] Forcing termination of PID {pid} with exit code {force_exit_code}.")
        ok = kernel32.TerminateProcess(process_handle, force_exit_code)
        if not ok:
            err = ctypes.get_last_error()
            log.debug(f"[terminate_process] TerminateProcess failed for PID {pid}, error={err}")
            return False

        if _wait_for_exit(process_handle, timeout_kill):
            log.debug(f"[terminate_process] Process {pid} was force-terminated.")
            return True
        else:
            log.debug(f"[terminate_process] WaitForSingleObject timeout for PID {pid} after TerminateProcess.")
            return False

    except Exception as e:
        log.info(f"[terminate_process] Error terminating process {pid}: {e}")
        return False

    finally:
        if process_handle:
            kernel32.CloseHandle(process_handle)