# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

from typing import Dict
import ssl
import urllib.request
from pathlib import Path
from urllib.parse import urljoin
from os import makedirs
from time import sleep
import asyncio

import aiohttp
from bs4 import BeautifulSoup

sem = asyncio.Semaphore(10)
counter = 0


def download_file(src: str, dst: str, verify_ssl: bool = True):
    """
    Downloads file.

    Args:
        src: file that should be downloaded e.g. http://dwd.pershastudia.org/wgc/demo/develop/17.03.00.2493/bin/wgc.exe
        dst: destination file.
        verify_ssl: indicates should we verify cert or not.
    """
    block_sz = 2 ** 13

    ctx = None
    if not verify_ssl:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

    u = urllib.request.urlopen(src, context=ctx)
    with open(dst, 'wb') as file_:
        while True:
            buffer = u.read(block_sz)
            if not buffer:
                break

            file_.write(buffer)


async def download_file_async(session: aiohttp.ClientSession, src: str, dst: str, count: int = 0):
    """
    Task for download file async.

    Args:
        count: count of urls.
        session: session.
        src: file that should be downloaded e.g. http://dwd.pershastudia.org/wgc/demo/develop/17.03.00.2493/bin/wgc.exe
        dst: destination file.
        verify_ssl: indicates should we verify cert or not.
    """
    block_sz = 2 ** 13
    global counter

    async with sem:
        async with session.get(src) as response:
            with open(dst, 'wb') as file_:
                while True:
                    buffer = await response.content.read(block_sz)
                    if not buffer:
                        break

                    file_.write(buffer)
    counter += 1
    if count != 0:
        print(counter, end=f'\rDownloaded: {counter} / {counter / count * 100}% of {count}', flush=True)


async def download_file_list(src_dst_map: Dict[str, str]):
    """
    Download list of files.

    Args:
        src_dst_map: dict with key - src file that should be downloaded e.g.
            http://dwd.pershastudia.org/wgc/demo/develop/17.03.00.2493/bin/wgc.exe
            and value - dst, destination file.
    """
    global counter
    counter = 0
    con = aiohttp.TCPConnector(limit=30)
    loop = asyncio.get_event_loop()
    async with aiohttp.ClientSession(loop=loop, connector=con) as _session:
        tasks = [asyncio.ensure_future(download_file_async(_session, src, dst, len(src_dst_map))) for src, dst in src_dst_map.items()]
        loop.run_until_complete(asyncio.gather(*tasks))


async def download_files(src: str, dst: str):
    """
    Download asynchronous files

    Args:
        src: file that should be downloaded e.g. http://dwd.pershastudia.org/wgc/demo/develop/17.03.00.2493/bin/wgc.exe
        dst: destination file.
    """
    global counter
    counter = 0
    urls_for = []
    loop = asyncio.get_event_loop()
    con = aiohttp.TCPConnector(limit=30)

    async def downloader(session_, src_, dst_):
        try:
            async with session_.get(src_) as resp:
                headers = resp.headers
                if resp.status != 200:
                    raise Exception('%s, return %s' % (src_, resp.status))
                content = await resp.content.read()
        except Exception:
            sleep(1)
            async with session_.get(src_) as resp:
                headers = resp.headers
                if resp.status != 200:
                    raise Exception('%s, return %s' % (src_, resp.status))
                content = await resp.content.read()
        if 'text/html' in headers.get('Content-Type', ''):
            makedirs(dst_, exist_ok=True)
            content = BeautifulSoup(content, 'html.parser')
            links = content.pre.find_all('a')
            if links:
                for link in links[1:]:
                    await downloader(
                        session_,
                        urljoin('%s/' % src_.rstrip("/"), link.text),
                        str(Path(dst_, link.text)))
        else:
            urls_for.append({'src': src_, 'dst': dst_})

    async with aiohttp.ClientSession(loop=loop, connector=con) as _session:
        await downloader(_session, src, dst)
        tasks = [asyncio.ensure_future(download_file_async(_session, url['src'], url['dst'])) for url in urls_for]
        loop.run_until_complete(asyncio.gather(*tasks))
