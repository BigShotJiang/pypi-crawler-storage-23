# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from io import BytesIO, StringIO

from PIL import Image
import svgwrite


class ImageHelper:

    @classmethod
    def prepare_image(cls, size: tuple, color: tuple, vector: bool = False) -> bytes:
        """
        Generate image content.

        Args:
            size: image size.
            color: image color.
            vector: flag that indicates is image in vector format or not.

        Returns:
            image content.
        """
        if vector:
            dwg = svgwrite.Drawing(size=size)
            width, height = size
            dwg.add(dwg.polygon([(0, 0), (width, 0), (width, height),
                                 (0, height)], fill=color))
            image_bytes = StringIO()
            dwg.write(image_bytes)
        else:
            image = Image.new("RGB", size, color)
            image_bytes = BytesIO()
            image.save(image_bytes, format='JPEG')

        image_bytes.flush()
        result = image_bytes.getvalue()

        return result
