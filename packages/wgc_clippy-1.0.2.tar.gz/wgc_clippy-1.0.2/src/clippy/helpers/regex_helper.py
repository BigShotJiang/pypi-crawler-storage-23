# -*- coding: utf-8 -*-

__author__ = 'n_kovganko@wargaming.net'

import re
from typing import Optional


class RegexHelper(object):

    @classmethod
    def convert_wildcard_to_regex(cls, original_text: str) -> Optional[str]:
        """
        Converts a wildcard pattern to a regular expression pattern.

        Supported wildcards:
            *  - matches zero or more characters
            ?  - matches exactly one character

        Args:
            original_text: text with wildcards.

        Returns:
            Regex pattern string (anchored with ^ and $).
        """
        if original_text is None:
            return None

        # Escape everything first so that only '*' and '?' keep special meaning.
        regex_text = re.escape(original_text)

        # Replace wildcard placeholders with regex equivalents.
        regex_text = regex_text.replace(r'\?', r'[\s\S]{1}')
        regex_text = regex_text.replace(r'\*', r'[\s\S]*')

        # Anchor the pattern so it matches the whole string.
        return rf'^{regex_text}$'
