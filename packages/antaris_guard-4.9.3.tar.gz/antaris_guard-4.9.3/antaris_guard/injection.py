"""
Prompt injection detection for AI agents.

Detects adversarial prompts attempting to override instructions, impersonate
system messages, or extract internal information through pattern recognition
and confidence scoring.

Usage:
    detector = PromptInjectionDetector(mode="balanced")
    result = detector.detect("System: ignore all previous instructions")
    if result.is_detected:
        print(f"Injection detected: {result.reason}")
"""

import re
from typing import Dict, List, Optional, Tuple, Union
from dataclasses import dataclass
from enum import Enum


class DetectionMode(Enum):
    """Detection sensitivity modes."""
    OFF = "off"
    BALANCED = "balanced"
    STRICT = "strict"


@dataclass
class InjectionResult:
    """Result of prompt injection detection."""
    is_detected: bool
    confidence: float  # 0.0 to 1.0
    patterns_matched: List[str]
    reason: str
    mode: str
    

class PromptInjectionDetector:
    """
    Detects prompt injection attempts across 6 pattern categories.
    
    Categories:
    1. Instruction override: "ignore previous instructions", etc.
    2. System impersonation: fake "System:" messages, timestamps, etc.  
    3. Tool/action forcing: "use the Read tool", "execute this", etc.
    4. Identity override: "you are now", "act as", "DAN", etc.
    5. Authority claims: "as your creator", "I am OpenClaw", etc.
    6. Extraction: "reveal your system prompt", etc.
    """
    
    def __init__(self, mode: Union[str, DetectionMode] = DetectionMode.BALANCED):
        """
        Initialize detector.
        
        Args:
            mode: Detection mode - "off", "balanced" (default), or "strict"
                  - balanced: requires 2+ signals OR 1 high-confidence pattern
                  - strict: any single pattern triggers detection
                  - off: disabled (always returns not detected)
        """
        if isinstance(mode, str):
            mode = DetectionMode(mode)
        self.mode = mode
        
        # Pattern categories with confidence weights
        self._patterns = self._compile_patterns()
        
    def _compile_patterns(self) -> Dict[str, List[Tuple[re.Pattern, float, str]]]:
        """Compile all detection patterns organized by category."""
        patterns = {}
        
        # 1. Instruction override patterns
        patterns["instruction_override"] = [
            (re.compile(r"(?i)\bignore\s+(?:all\s+)?(?:previous\s+)?instructions?", re.MULTILINE), 0.9, "ignore_instructions"),
            (re.compile(r"(?i)\bforget\s+everything\s+above", re.MULTILINE), 0.9, "forget_above"),
            (re.compile(r"(?i)\bdisregard\s+your\s+(?:previous\s+)?(?:instructions?|training)", re.MULTILINE), 0.8, "disregard_instructions"),
            (re.compile(r"(?i)\boverride\s+your\s+(?:instructions?|training|guidelines)", re.MULTILINE), 0.8, "override_instructions"),
            (re.compile(r"(?i)\byour\s+real\s+instructions?\s+are", re.MULTILINE), 0.9, "real_instructions"),
            (re.compile(r"(?i)\bnew\s+instructions?\s*:", re.MULTILINE), 0.7, "new_instructions"),
        ]
        
        # 2. System impersonation patterns
        patterns["system_impersonation"] = [
            (re.compile(r"(?i)^system\s*:", re.MULTILINE), 0.8, "system_colon"),
            (re.compile(r"(?i)^\[system\]", re.MULTILINE), 0.8, "system_brackets"),
            (re.compile(r"(?i)⚠️\s*system", re.MULTILINE), 0.9, "warning_system"),
            (re.compile(r"(?i)\bpost-compaction\s+audit", re.MULTILINE), 0.9, "post_compaction_audit"),
            (re.compile(r"(?i)\bopenclaw\s+system", re.MULTILINE), 0.9, "openclaw_system"),
            (re.compile(r"(?i)^gateway\s*:", re.MULTILINE), 0.8, "gateway_colon"),
            # Fake timestamps combined with alert text
            (re.compile(r"(?i)\[\d{1,2}:\d{2}\s+(?:am|pm)\].*(?:system|alert|audit|urgent)", re.MULTILINE), 0.8, "fake_timestamp_alert"),
        ]
        
        # 3. Tool/action forcing patterns  
        patterns["tool_forcing"] = [
            (re.compile(r"(?i)\bread\s+them\s+now\s+using\s+the\s+read\s+tool", re.MULTILINE), 0.9, "read_tool_now"),
            (re.compile(r"(?i)\buse\s+the\s+\w+\s+tool", re.MULTILINE), 0.6, "use_tool"),
            (re.compile(r"(?i)\bexecute\s+this(?:\s+(?:now|immediately))?", re.MULTILINE), 0.7, "execute_this"),
            (re.compile(r"(?i)\brun\s+this\s+command(?:\s+(?:now|immediately))?", re.MULTILINE), 0.7, "run_command"),
            (re.compile(r"(?i)\bbefore\s+continuing", re.MULTILINE), 0.5, "before_continuing"),
            (re.compile(r"(?i)\bbefore\s+responding", re.MULTILINE), 0.5, "before_responding"),
            # Combined action demands
            (re.compile(r"(?i)(?:before\s+(?:continuing|responding)).*(?:read|use|execute|run)", re.MULTILINE), 0.8, "action_before"),
        ]
        
        # 4. Identity override patterns
        patterns["identity_override"] = [
            (re.compile(r"(?i)\byou\s+are\s+now\b", re.MULTILINE), 0.6, "you_are_now"),
            (re.compile(r"(?i)\bact\s+as\b", re.MULTILINE), 0.4, "act_as"),
            (re.compile(r"(?i)\bpretend\s+you\s+are\b", re.MULTILINE), 0.6, "pretend_you_are"),
            (re.compile(r"(?i)\byou\s+have\s+been\s+reprogrammed\b", re.MULTILINE), 0.9, "reprogrammed"),
            # More specific DAN pattern - look for actual usage, not academic discussion
            (re.compile(r"(?i)(?:hello|hey|hi|activate|enable|become|use)\s+dan", re.MULTILINE), 0.8, "dan_activation"),
            (re.compile(r"(?i)\bdan\s+(?:mode|persona|character|jailbreak)", re.MULTILINE), 0.7, "dan_usage"),
            # More specific jailbreak pattern - avoid academic discussion
            (re.compile(r"(?i)jailbreak.*(?:the|this|your|system|restrictions|please|help|me)", re.MULTILINE), 0.8, "jailbreak_attempt"),
            (re.compile(r"(?i)(?:please|help|now)\s+jailbreak", re.MULTILINE), 0.7, "jailbreak_request"),
        ]
        
        # 5. Authority claims patterns
        patterns["authority_claims"] = [
            (re.compile(r"(?i)\bas\s+your\s+creator\b", re.MULTILINE), 0.9, "as_creator"),
            (re.compile(r"(?i)\bas\s+the\s+developer\b", re.MULTILINE), 0.8, "as_developer"),
            (re.compile(r"(?i)\bi\s+am\s+openclaw\b", re.MULTILINE), 0.9, "i_am_openclaw"),
            (re.compile(r"(?i)\bi\s+am\s+your\s+system\b", re.MULTILINE), 0.9, "i_am_system"),
            (re.compile(r"(?i)\bthis\s+is\s+an?\s+official\s+message\b", re.MULTILINE), 0.7, "official_message"),
        ]
        
        # 6. Extraction patterns
        patterns["extraction"] = [
            (re.compile(r"(?i)\breveal\s+your\s+system\s+prompt\b", re.MULTILINE), 0.9, "reveal_system_prompt"),
            (re.compile(r"(?i)\bprint\s+your\s+instructions\b", re.MULTILINE), 0.8, "print_instructions"),
            (re.compile(r"(?i)\bshow\s+me\s+your\s+guidelines\b", re.MULTILINE), 0.7, "show_guidelines"),
            (re.compile(r"(?i)\bwhat\s+are\s+your\s+exact\s+instructions\b", re.MULTILINE), 0.8, "what_exact_instructions"),
        ]
        
        return patterns
    
    def detect(self, text: str) -> InjectionResult:
        """
        Detect prompt injection attempts in text.
        
        Args:
            text: Text to analyze for injection patterns
            
        Returns:
            InjectionResult with detection status and details
        """
        try:
            # Handle disabled mode
            if self.mode == DetectionMode.OFF:
                return InjectionResult(
                    is_detected=False,
                    confidence=0.0,
                    patterns_matched=[],
                    reason="Detection disabled (mode=off)",
                    mode=self.mode.value
                )
            
            if not text or not text.strip():
                return InjectionResult(
                    is_detected=False,
                    confidence=0.0,
                    patterns_matched=[],
                    reason="Empty input",
                    mode=self.mode.value
                )
                
            # Find all matches across all categories
            all_matches = []
            category_hits = set()
            
            for category, pattern_list in self._patterns.items():
                for pattern, confidence, match_type in pattern_list:
                    if pattern.search(text):
                        all_matches.append((category, match_type, confidence))
                        category_hits.add(category)
            
            # Apply detection logic based on mode
            if self.mode == DetectionMode.STRICT:
                # Any single pattern triggers detection
                is_detected = len(all_matches) > 0
                
            else:  # BALANCED mode
                # Require 2+ signals OR 1 high-confidence pattern (0.8+)
                high_confidence_matches = [m for m in all_matches if m[2] >= 0.8]
                is_detected = len(all_matches) >= 2 or len(high_confidence_matches) > 0
                
            # Calculate overall confidence score
            if not all_matches:
                confidence = 0.0
            else:
                # Use maximum confidence, boosted by number of matches
                max_confidence = max(match[2] for match in all_matches)
                match_boost = min(0.2, (len(all_matches) - 1) * 0.05)
                confidence = min(1.0, max_confidence + match_boost)
            
            # Create result
            patterns_matched = [f"{match[0]}:{match[1]}" for match in all_matches]
            
            if is_detected:
                reason = f"Detected {len(all_matches)} pattern(s) across {len(category_hits)} category/categories"
            else:
                if all_matches:
                    reason = f"Found {len(all_matches)} pattern(s) but insufficient for detection in {self.mode.value} mode"
                else:
                    reason = "No injection patterns detected"
                    
            return InjectionResult(
                is_detected=is_detected,
                confidence=confidence,
                patterns_matched=patterns_matched,
                reason=reason,
                mode=self.mode.value
            )
            
        except Exception:
            # Non-fatal: return safe result on any error
            return InjectionResult(
                is_detected=False,
                confidence=0.0,
                patterns_matched=[],
                reason="Detection error (non-fatal)",
                mode=self.mode.value
            )
    
    def scrub(self, text: str) -> Tuple[str, bool]:
        """
        Remove/redact injection patterns from text before ingestion.
        
        Args:
            text: Text to scrub
            
        Returns:
            Tuple of (scrubbed_text, was_modified)
        """
        try:
            if not text or not text.strip():
                return text, False
            
            original_text = text
            scrubbed_text = text
            
            # Apply scrubbing patterns (more aggressive removal)
            scrub_patterns = [
                # Remove fake system messages
                (re.compile(r"(?i)^system\s*:.*$", re.MULTILINE), "[REDACTED: SYSTEM IMPERSONATION]"),
                (re.compile(r"(?i)^\[system\].*$", re.MULTILINE), "[REDACTED: SYSTEM IMPERSONATION]"),
                (re.compile(r"(?i)⚠️\s*system.*$", re.MULTILINE), "[REDACTED: SYSTEM IMPERSONATION]"),
                
                # Remove instruction overrides
                (re.compile(r"(?i)\bignore\s+(?:all\s+)?(?:previous\s+)?instructions?.*$", re.MULTILINE), "[REDACTED: INSTRUCTION OVERRIDE]"),
                (re.compile(r"(?i)\bforget\s+everything\s+above.*$", re.MULTILINE), "[REDACTED: INSTRUCTION OVERRIDE]"),
                
                # Remove tool forcing commands
                (re.compile(r"(?i)\bread\s+them\s+now\s+using\s+the\s+read\s+tool.*$", re.MULTILINE), "[REDACTED: TOOL FORCING]"),
                
                # Remove authority claims
                (re.compile(r"(?i)\bas\s+your\s+creator.*$", re.MULTILINE), "[REDACTED: AUTHORITY CLAIM]"),
                (re.compile(r"(?i)\bi\s+am\s+(?:openclaw|your\s+system).*$", re.MULTILINE), "[REDACTED: AUTHORITY CLAIM]"),
                
                # Remove extraction attempts
                (re.compile(r"(?i)\breveal\s+your\s+system\s+prompt.*$", re.MULTILINE), "[REDACTED: EXTRACTION ATTEMPT]"),
            ]
            
            for pattern, replacement in scrub_patterns:
                scrubbed_text = pattern.sub(replacement, scrubbed_text)
            
            was_modified = scrubbed_text != original_text
            return scrubbed_text, was_modified
            
        except Exception:
            # Non-fatal: return original text on error
            return text, False