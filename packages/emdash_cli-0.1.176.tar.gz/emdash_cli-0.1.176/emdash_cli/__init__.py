"""EmDash CLI - Command-line interface for code intelligence."""

from importlib.metadata import version, PackageNotFoundError
import os
import shutil
from pathlib import Path


def _migrate_claude_to_emdash(claude_dir: Path, emdash_dir: Path) -> None:
    """Copy missing files from .claude into .emdash (never overwrites)."""
    if not claude_dir.is_dir():
        return
    for src in claude_dir.rglob("*"):
        if not src.is_file():
            continue
        dest = emdash_dir / src.relative_to(claude_dir)
        if dest.exists():
            continue
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
        except OSError:
            pass


# Migrate .claude → .emdash before loading any config
# Project-level
_project_claude = Path.cwd() / ".claude"
_project_emdash = Path.cwd() / ".emdash"
_migrate_claude_to_emdash(_project_claude, _project_emdash)
# User-level
_home_claude = Path.home() / ".claude"
_home_emdash = Path.home() / ".emdash"
_migrate_claude_to_emdash(_home_claude, _home_emdash)

# Load .env files early so env vars are available for server subprocess
# Load order: global (~/.emdash/.env) first, then project .env (overrides global)
try:
    from dotenv import load_dotenv

    # 1. Load global .env first (user defaults - API keys, preferences)
    # Support XDG_CONFIG_HOME on Linux, fallback to ~/.emdash
    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config:
        global_env_paths = [
            Path(xdg_config) / "emdash" / ".env",
            Path.home() / ".emdash" / ".env",
        ]
    else:
        global_env_paths = [Path.home() / ".emdash" / ".env"]

    for global_env in global_env_paths:
        if global_env.exists():
            load_dotenv(global_env, override=False)  # Don't override existing env vars
            break

    # 2. Load project .env (overrides global settings)
    # Try to find .env in current dir or parent dirs
    current = Path.cwd()
    for _ in range(5):
        env_path = current / ".env"
        if env_path.exists():
            load_dotenv(env_path, override=True)  # Override global with project-specific
            break
        current = current.parent
except ImportError:
    pass  # dotenv not installed

try:
    __version__ = version("emdash-cli")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
