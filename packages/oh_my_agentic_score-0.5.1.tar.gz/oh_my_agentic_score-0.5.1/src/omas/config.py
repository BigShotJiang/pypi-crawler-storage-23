"""Configuration constants and threshold defaults."""

import os
from pathlib import Path

# Claude Code data paths
CLAUDE_DIR = Path.home() / ".claude"
CLAUDE_PROJECTS_DIR = CLAUDE_DIR / "projects"
CLAUDE_HISTORY_FILE = CLAUDE_DIR / "history.jsonl"

# OMAS storage paths
OMAS_DIR = Path.home() / ".omas"
SQLITE_DB_PATH = OMAS_DIR / "metrics.db"
REPORTS_DIR = OMAS_DIR / "reports"
UPLOAD_QUEUE_PATH = OMAS_DIR / "upload_queue.json"

# OMAS Cloud server URL — single source of truth.
#
# Priority (highest → lowest):
#   1. OMAS_SERVER_URL env var (runtime override, e.g. .env for local dev)
#   2. _PRODUCTION_SERVER_URL (baked in at CI/CD build time via sed)
#   3. Hardcoded fallback below
#
# CI/CD injects the production URL by replacing the placeholder value of
# _PRODUCTION_SERVER_URL before `uv build`.  See .github/workflows/release.yml.
_PRODUCTION_SERVER_URL = "https://api.oh-my-agentic-score.com"  # CI/CD replaces this line
DEFAULT_SERVER_URL = os.environ.get("OMAS_SERVER_URL", _PRODUCTION_SERVER_URL)

# Thread classification thresholds
Z_THREAD_MAX_HUMAN_MESSAGES = 1
Z_THREAD_MIN_TOOL_CALLS = 10

B_THREAD_MIN_DEPTH = 2

L_THREAD_MIN_AUTONOMOUS_MINUTES = 30.0
L_THREAD_MIN_TOOL_CALLS = 50

F_THREAD_MIN_SIMILARITY = 0.7

P_THREAD_MIN_CONCURRENT = 2

C_THREAD_MIN_HUMAN_MESSAGES = 3
C_THREAD_MIN_TOOLS_PER_GAP = 3

# Trivial delegation threshold: if a human message is followed by
# ≤ this many tool calls before the next human message, it is
# considered a trivial delegation (e.g. "run tests") and excluded
# from the effective human message count in the Fewer (F) score.
TRIVIAL_DELEGATION_THRESHOLD = 5

# AI-written lines bonus: lines needed for full +1.0 density bonus
AI_LINES_FULL_SCORE = 50_000

# Automated message filters (content patterns that indicate non-human messages)
AUTOMATED_MESSAGE_PATTERNS = [
    "<observed_from_primary_session>",
    "<local-command-",
    "<system-reminder>",
]
