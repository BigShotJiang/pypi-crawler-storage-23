"""CLI module for munchboka-edutools book building."""
