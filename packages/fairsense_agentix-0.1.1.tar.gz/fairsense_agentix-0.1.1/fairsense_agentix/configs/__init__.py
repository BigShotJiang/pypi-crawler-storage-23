"""Configuration module for FairSense-AgentiX."""

from fairsense_agentix.configs.settings import Settings, settings


__all__ = ["Settings", "settings"]
