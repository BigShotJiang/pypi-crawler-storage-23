"""FastAPI server helpers for FairSense-AgentiX."""
