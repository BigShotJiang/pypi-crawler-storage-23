# YourLang

A custom programming language with both **interpreted** and **compiled** (bytecode VM) modes.

Built entirely in Python as a B.Tech major project.

---

## Installation

```bash
pip install yourlang
```

---

## Quick Start

```bash
# Start the interactive REPL
yourlang repl

# Create a new program file
yourlang new myprogram.yl

# Run in interpreted mode (fast, instant)
yourlang run myprogram.yl

# Compile to bytecode then run
yourlang compile myprogram.yl
yourlang exec    myprogram.ylc

# Compile + run in one command
yourlang build myprogram.yl

# Inspect compiled bytecode
yourlang disasm myprogram.yl
```

---

## Language Syntax

```
// Variables
integer $x = 10
float   $g = 9.81
string  $s = "hello"
bool    $b = true

// Output and input
show("Value: " . $x)
integer $n = integer(getInput("Enter number: "))

// Conditionals
check($x > 5){
    show("big")
}
recheck($x == 5){
    show("exactly 5")
}
otherwise{
    show("small")
}

// While loop (loops WHILE condition is FALSE)
integer $i = 0
repeat until($i == 5){
    show($i)
    $i = $i + 1
}

// For loop
for repeat($i < 5, $i = $i + 1){
    show($i)
}

// Switch
menu $x{
    case 1:
        show("one")
        exitloop
    case 2:
        show("two")
        exitloop
    default:
        show("other")
        exitloop
}

// Functions
define factorial($n){
    check($n == 0){ getback 1 }
    getback $n * factorial($n - 1)
}
show(factorial(10))

// Exception handling
try{
    integer $r = integer("bad")
}
over{
    show("Caught: " . $error)
}

// File handling
File $f = open("data.txt", W)
write($f, "Hello!")
close($f)

File $f = open("data.txt", R)
string $content = read($f)
close($f)
show($content)
```

---

## Built-in Modules

### `include #math`

| Function | Description |
|---|---|
| `sqrt($n)` | Square root |
| `pow($b, $e)` | Power: b^e |
| `abs($n)` | Absolute value |
| `floor($n)` | Round down |
| `ceil($n)` | Round up |
| `round($n)` | Round to nearest |
| `max($a, $b)` | Larger value |
| `min($a, $b)` | Smaller value |
| `clamp($v, $lo, $hi)` | Clamp value |
| `log($n)` | Natural log |
| `sin($n)` | Sine (radians) |
| `cos($n)` | Cosine (radians) |
| `tan($n)` | Tangent |
| `isEven($n)` | True if even |
| `isOdd($n)` | True if odd |
| `$PI` | 3.14159... |
| `$E` | 2.71828... |

### `include #string`

| Function | Description |
|---|---|
| `len($s)` | Length |
| `upper($s)` | Uppercase |
| `lower($s)` | Lowercase |
| `trim($s)` | Strip whitespace |
| `contains($s, $sub)` | Substring check |
| `startsWith($s, $p)` | Prefix check |
| `endsWith($s, $p)` | Suffix check |
| `replace($s, $a, $b)` | Replace |
| `charAt($s, $i)` | Character at index |
| `substr($s, $i, $n)` | Substring |
| `reverse($s)` | Reverse |
| `toInt($s)` | Parse to integer |
| `toFloat($s)` | Parse to float |

---

## Architecture

```
Source (.yl)
    │
    ▼
Lexer          tokenize source into tokens
    │
    ▼
Parser         build Abstract Syntax Tree (AST)
    │
    ├──► Interpreter   tree-walk executor (interpreted mode)
    │
    └──► Compiler ──► Bytecode (.ylc) ──► VM  (compiled mode)
```

---

## License

MIT
