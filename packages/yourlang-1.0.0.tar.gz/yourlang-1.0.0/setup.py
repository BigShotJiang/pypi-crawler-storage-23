from setuptools import setup

setup(
    name="yourlang",
    version="1.0.0",
)