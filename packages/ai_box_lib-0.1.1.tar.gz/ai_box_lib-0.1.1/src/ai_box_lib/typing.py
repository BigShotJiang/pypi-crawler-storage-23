"""Typing definitions for context, channels and features."""
from typing import Any, Mapping, TypeAlias

ContextType: TypeAlias = Mapping[str, Any]
ChannelType: TypeAlias = Mapping[str, Any]
FeatureType: TypeAlias = Mapping[str, Any]
