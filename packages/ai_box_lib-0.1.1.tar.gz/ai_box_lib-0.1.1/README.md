# AI Box Library

Python library for NXP Edge AI Industrial Platform