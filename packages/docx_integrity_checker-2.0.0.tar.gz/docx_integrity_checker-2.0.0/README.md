This program parses different data points from a .docx file to give you all the information needed to identify cheating within the metadata of a document.

Limitations are as such: Must be a Word Document written in microsoft word.

If the file is not written in word or is not a docx the program will tell you.

Similarly if the file has been scraped for meta data the program will tell you.

For windows and mac please download the program, point your terminal towards the directory in which you downloaded the files, and then run main.py

For linux please run the command when prompted and then run the program again. 

If you have trouble using the program or downloading the program you can reach me at gavint1250@gmail.com I can provide a .exe or .dmg file upon request.

Please do not pass my work off as your own. So long as I am credited, use it to your hearts content.