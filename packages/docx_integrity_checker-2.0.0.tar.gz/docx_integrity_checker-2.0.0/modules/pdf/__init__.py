
from .analyzer import analyze_pdf
