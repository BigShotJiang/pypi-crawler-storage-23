"""Stereo Home UI — Simplified 3-step workflow (Home Edition)

Step 1: ChArUco camera calibration
  - Opens CalibrationUIAdvanced as a modal window
    (guided recording + auto-calibration in one flow)

Step 2: Auto-Monitor
  - Define dining zone first (required gate before monitoring)
  - YOLO person detection triggers pose recording
  - Saves xy CSV only (no video files)
  - 3D extraction starts automatically when each session ends

Step 3: Session History
  - Shows all sessions with their 2D / 3D status
  - 3D extraction runs automatically; re-run button available if needed
"""
from __future__ import annotations

import logging
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import ttk, messagebox, filedialog

try:
  import cv2
  import numpy as np
  CV2_AVAILABLE = True
except ImportError:
  CV2_AVAILABLE = False

try:
  from PIL import Image, ImageTk
  PIL_AVAILABLE = True
except ImportError:
  PIL_AVAILABLE = False

from .config import load_yaml_config
from .calibration_ui import (
  CalibConfig,
  CameraPreview,
)
from .realtime_detector import RealtimeDetector, RealtimeDetectorConfig

logger = logging.getLogger(__name__)

# ── Color palette (dark theme) ───────────────────────────────────────────────
BG       = "#2b2b2b"
BG_PANEL = "#333333"
BG_DARK  = "#1e1e1e"
FG       = "#e0e0e0"
FG_DIM   = "#888888"
GREEN    = "#4CAF50"
BLUE     = "#2196F3"
ORANGE   = "#FF9800"
RED      = "#f44336"


# ============================================================================
# HomeUI
# ============================================================================

class HomeUI(tk.Tk):
  """Home Edition: Calibrate → Auto-Monitor → Auto-Extract 3D."""

  # ── Initialisation ─────────────────────────────────────────────────────────

  def __init__(self, config_path: Optional[Path] = None,
               project_dir: Optional[Path] = None):
    tk.Tk.__init__(self)
    self.title("Stereo Camera 3D Motion Capture — Home Edition")
    self.geometry("950x860")
    self.configure(bg=BG)
    self.resizable(True, True)

    # Thread → UI message queue
    self._msg_queue: queue.Queue = queue.Queue()

    # Load config and resolve project directory
    self._load_config(config_path, project_dir)

    # ── Step 1 state ──
    self._calibrated = False
    self._camera: Optional[CameraPreview] = None
    self._calib_proc: Optional[subprocess.Popen] = None

    # ── Step 2 state ──
    self._detector: Optional[RealtimeDetector] = None
    self._det_timer_id: Optional[str] = None
    self._det_event_q: queue.Queue = queue.Queue()

    # 就餐区域监控（独立于姿态录制）
    self._dining_monitor = None   # DiningZoneMonitor，start_monitor 时创建

    # Zone drawing state
    self._zone_data: Optional[dict] = None
    self._zone_drawing = False
    self._zone_start: Optional[tuple] = None
    self._preview_scale = 1.0
    self._preview_x_offset = 0
    self._preview_y_offset = 0
    self._preview_left_w = 1600
    self._preview_left_h = 1200

    # ── Step 3 state: active extraction tracking ──
    self._extracting_session: Optional[str] = None

    # Build UI
    self._build_ui()

    # Load existing zone from disk
    self._zone_data = self._load_dining_zone()

    # Start 50 ms update loop
    self.after(50, self._update_loop)

    # Check existing calibration/recordings on disk
    self._check_existing()

  # ── Config / project dir ───────────────────────────────────────────────────

  def _load_config(self, config_path: Optional[Path],
                   project_dir_override: Optional[Path]):
    """Load YAML config and resolve project directory (same logic as PipelineUI)."""
    if config_path is None:
      from .paths import resolve_default_config
      config_path = resolve_default_config()

    self._config_path = config_path
    self._yaml_data = load_yaml_config(config_path)
    self.config = CalibConfig.from_yaml(config_path)

    if project_dir_override:
      self._project_dir = Path(project_dir_override)
      self._project_dir.mkdir(parents=True, exist_ok=True)
      return

    # Mirror pipeline_ui.py resolution logic
    project_cfg = self._yaml_data.get("project", {})
    project_dir_str = project_cfg.get("project_dir", "")

    if project_dir_str:
      p = Path(project_dir_str)
      if not p.is_absolute():
        p = Path.cwd() / p
      self._project_dir = p
    else:
      output_base = self._yaml_data.get("output", {}).get("base_dir", "")
      if output_base:
        base = Path(output_base)
        if not base.is_absolute():
          base = Path.cwd() / base
        self._project_dir = base.parent   # recordings/ → parent = project root
      else:
        # Final fallback: sibling projects/ directory next to tool root
        from .paths import tool_root
        self._project_dir = tool_root().parent.parent / "projects" / "home_project"

    self._project_dir.mkdir(parents=True, exist_ok=True)
    logger.info(f"Project directory: {self._project_dir}")

  def _check_existing(self):
    """Check calibration status and recordings on disk."""
    self._calibrated = (self._project_dir / "camera_array.toml").exists()

    self._refresh_step1_ui()
    self._refresh_step2_ui()
    self._refresh_sessions()

    if self._calibrated:
      logger.info("Calibration data found — ready to monitor.")
    else:
      logger.info(f"Project: {self._project_dir}")

  # ── UI construction ─────────────────────────────────────────────────────────

  def _build_ui(self):
    """Build scrollable main layout."""
    outer = tk.Frame(self, bg=BG)
    outer.pack(fill=tk.BOTH, expand=True)

    canvas = tk.Canvas(outer, bg=BG, highlightthickness=0)
    sb = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
    self._inner = tk.Frame(canvas, bg=BG)

    self._inner.bind(
      "<Configure>",
      lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
    )
    canvas.create_window((0, 0), window=self._inner, anchor="nw", tags="inner")
    canvas.configure(yscrollcommand=sb.set)
    sb.pack(side=tk.RIGHT, fill=tk.Y)
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    canvas.bind("<Configure>",
                lambda e: canvas.itemconfig("inner", width=e.width))
    canvas.bind_all("<MouseWheel>",
                    lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

    inner = self._inner
    inner.config(padx=14, pady=12)

    # ── Header ──
    hdr = tk.Frame(inner, bg=BG)
    hdr.pack(fill=tk.X, pady=(0, 8))

    tk.Label(
      hdr, text="Stereo Camera 3D Motion Capture",
      font=("Segoe UI", 19, "bold"), fg=FG, bg=BG,
    ).pack(side=tk.LEFT)

    # Project info (right side)
    proj_frm = tk.Frame(hdr, bg=BG)
    proj_frm.pack(side=tk.RIGHT)

    self._proj_label = tk.Label(
      proj_frm,
      text=self._short_path(self._project_dir),
      font=("Segoe UI", 9), fg=FG_DIM, bg=BG,
    )
    self._proj_label.pack(side=tk.LEFT)

    tk.Button(
      proj_frm, text="Change...",
      font=("Segoe UI", 9), bg="#555", fg=FG,
      relief="flat", padx=8, pady=2,
      command=self._on_select_project,
    ).pack(side=tk.LEFT, padx=(6, 0))

    # ── Three step panels ──
    self._build_step1(inner)
    self._build_step2(inner)
    self._build_step3(inner)

  def _make_panel(self, parent: tk.Frame, title: str,
                  color: str, step: int) -> tk.Frame:
    """Create a labelled step panel; return the inner content Frame."""
    frm = tk.LabelFrame(
      parent,
      text=f"  Step {step} — {title}  ",
      font=("Segoe UI", 11, "bold"),
      fg=color, bg=BG_PANEL,
      bd=1, relief="groove",
    )
    frm.pack(fill=tk.X, pady=(0, 10))
    inner = tk.Frame(frm, bg=BG_PANEL)
    inner.pack(fill=tk.X, padx=14, pady=10)
    return inner

  # ── Step 1: ChArUco Calibration ────────────────────────────────────────────

  def _build_step1(self, parent: tk.Frame):
    inner = self._make_panel(parent, "Calibrate Cameras (ChArUco)", GREEN, 1)

    # Single launch button row
    btn_row = tk.Frame(inner, bg=BG_PANEL)
    btn_row.pack(fill=tk.X)

    self.btn_start_calib = tk.Button(
      btn_row, text="\U0001f4f7  Start Calibration",
      font=("Segoe UI", 11, "bold"),
      bg=GREEN, fg="white", activebackground="#388E3C",
      relief="flat", padx=20, pady=6,
      command=self._on_start_calib,
    )
    self.btn_start_calib.pack(side=tk.LEFT)

    self._calib_dot = tk.Label(
      btn_row, text="\u25cf", font=("Segoe UI", 14),
      fg=FG_DIM, bg=BG_PANEL,
    )
    self._calib_dot.pack(side=tk.LEFT, padx=(12, 4))

    self._calib_status_lbl = tk.Label(
      btn_row, text="Not calibrated",
      font=("Segoe UI", 10), fg=FG_DIM, bg=BG_PANEL,
    )
    self._calib_status_lbl.pack(side=tk.LEFT)

    self._calib_progress = ttk.Progressbar(
      inner, mode="determinate", maximum=100,
    )
    self._calib_progress.pack(fill=tk.X, pady=(8, 0))

  # ── Step 2: Auto-Monitor ────────────────────────────────────────────────────

  def _build_step2(self, parent: tk.Frame):
    inner = self._make_panel(parent, "Auto-Monitor", BLUE, 2)

    # Status row
    status_row = tk.Frame(inner, bg=BG_PANEL)
    status_row.pack(fill=tk.X)

    self._mon_dot = tk.Label(
      status_row, text="\u25cf", font=("Segoe UI", 20),
      fg=FG_DIM, bg=BG_PANEL,
    )
    self._mon_dot.pack(side=tk.LEFT, padx=(0, 8))

    status_col = tk.Frame(status_row, bg=BG_PANEL)
    status_col.pack(side=tk.LEFT, fill=tk.X, expand=True)

    self._mon_state_lbl = tk.Label(
      status_col, text="Idle",
      font=("Segoe UI", 14, "bold"), fg=FG_DIM, bg=BG_PANEL, anchor="w",
    )
    self._mon_state_lbl.pack(fill=tk.X)

    self._mon_detail_lbl = tk.Label(
      status_col, text="Calibrate first to enable monitoring.",
      font=("Segoe UI", 9), fg=FG_DIM, bg=BG_PANEL, anchor="w",
    )
    self._mon_detail_lbl.pack(fill=tk.X)

    self._mon_session_lbl = tk.Label(
      status_row, text="Sessions: 0",
      font=("Segoe UI", 11), fg=FG_DIM, bg=BG_PANEL,
    )
    self._mon_session_lbl.pack(side=tk.RIGHT)

    # ── Dining Zone row ──
    zone_row = tk.Frame(inner, bg=BG_PANEL)
    zone_row.pack(fill=tk.X, pady=(10, 0))

    self._zone_dot = tk.Label(
      zone_row, text="\u25cf", font=("Segoe UI", 13),
      fg=FG_DIM, bg=BG_PANEL,
    )
    self._zone_dot.pack(side=tk.LEFT, padx=(0, 6))

    self._zone_label = tk.Label(
      zone_row, text="Dining Zone: not defined",
      font=("Segoe UI", 10), fg=FG_DIM, bg=BG_PANEL,
    )
    self._zone_label.pack(side=tk.LEFT, fill=tk.X, expand=True)

    self.btn_clear_zone = tk.Button(
      zone_row, text="Clear Zone",
      font=("Segoe UI", 9), bg="#555", fg=FG,
      relief="flat", padx=8, pady=3,
      state=tk.DISABLED,
      command=self._on_clear_zone,
    )
    self.btn_clear_zone.pack(side=tk.RIGHT, padx=(4, 0))

    self.btn_mark_zone = tk.Button(
      zone_row, text="Mark Zone",
      font=("Segoe UI", 9), bg="#555", fg=FG,
      relief="flat", padx=8, pady=3,
      state=tk.DISABLED,
      command=self._on_mark_zone,
    )
    self.btn_mark_zone.pack(side=tk.RIGHT, padx=(4, 0))

    # Start / Stop buttons
    btn_row = tk.Frame(inner, bg=BG_PANEL)
    btn_row.pack(fill=tk.X, pady=(10, 0))

    self.btn_start_mon = tk.Button(
      btn_row, text="\u25b6  Start Monitoring",
      font=("Segoe UI", 11, "bold"),
      bg=BLUE, fg="white", activebackground="#1976D2",
      relief="flat", padx=20, pady=6,
      state=tk.DISABLED,
      command=self._on_start_monitor,
    )
    self.btn_start_mon.pack(side=tk.LEFT)

    self.btn_stop_mon = tk.Button(
      btn_row, text="\u25a0  Stop Monitoring",
      font=("Segoe UI", 11),
      bg="#555", fg=FG,
      relief="flat", padx=16, pady=6,
      state=tk.DISABLED,
      command=self._on_stop_monitor,
    )
    self.btn_stop_mon.pack(side=tk.LEFT, padx=8)

    # Camera preview canvas
    self.mon_preview_canvas = tk.Canvas(
      inner, bg=BG_DARK, height=250, highlightthickness=0,
    )
    self.mon_preview_canvas.pack(fill=tk.X, pady=(10, 0))
    self.mon_preview_canvas.create_text(
      14, 125,
      text="Camera feed appears here during monitoring.",
      anchor="w", fill=FG_DIM, font=("Segoe UI", 11),
    )

    # Advanced settings (collapsible)
    self._adv_expanded = False
    self._adv_toggle_btn = tk.Button(
      inner, text="\u25b8  Advanced Settings",
      font=("Segoe UI", 9), bg=BG_PANEL, fg=FG_DIM,
      relief="flat", anchor="w",
      command=self._toggle_advanced,
    )
    self._adv_toggle_btn.pack(fill=tk.X, pady=(8, 0))

    self._adv_frame = tk.Frame(inner, bg=BG_PANEL)
    adv_grid = tk.Frame(self._adv_frame, bg=BG_PANEL)
    adv_grid.pack(fill=tk.X, padx=6, pady=4)

    tk.Label(adv_grid, text="Camera index:", font=("Segoe UI", 9),
             fg=FG_DIM, bg=BG_PANEL).grid(row=0, column=0, sticky="w", padx=(0, 4))
    self.var_cam_index = tk.IntVar(value=0)
    tk.Spinbox(adv_grid, from_=0, to=10, width=4, textvariable=self.var_cam_index,
               font=("Segoe UI", 9)).grid(row=0, column=1, padx=4)

    tk.Label(adv_grid, text="Target FPS:", font=("Segoe UI", 9),
             fg=FG_DIM, bg=BG_PANEL).grid(row=0, column=2, sticky="w", padx=(16, 4))
    self.var_fps = tk.IntVar(value=20)
    tk.Spinbox(adv_grid, from_=5, to=30, width=4, textvariable=self.var_fps,
               font=("Segoe UI", 9)).grid(row=0, column=3, padx=4)
    tk.Label(adv_grid, text="fps", font=("Segoe UI", 9),
             fg=FG_DIM, bg=BG_PANEL).grid(row=0, column=4, sticky="w")

    tk.Label(adv_grid, text="Absence threshold:", font=("Segoe UI", 9),
             fg=FG_DIM, bg=BG_PANEL).grid(row=1, column=0, sticky="w", pady=(4, 0))
    self.var_absence = tk.IntVar(value=15)
    tk.Spinbox(adv_grid, from_=5, to=60, width=4, textvariable=self.var_absence,
               font=("Segoe UI", 9)).grid(row=1, column=1, padx=4, pady=(4, 0))
    tk.Label(adv_grid, text="checks", font=("Segoe UI", 9),
             fg=FG_DIM, bg=BG_PANEL).grid(row=1, column=2, sticky="w", pady=(4, 0))

    tk.Label(adv_grid, text="Cooldown:", font=("Segoe UI", 9),
             fg=FG_DIM, bg=BG_PANEL).grid(row=1, column=3, sticky="w", padx=(16, 4), pady=(4, 0))
    self.var_cooldown = tk.IntVar(value=300)
    tk.Spinbox(adv_grid, from_=30, to=600, width=5, textvariable=self.var_cooldown,
               font=("Segoe UI", 9)).grid(row=1, column=4, padx=4, pady=(4, 0))
    tk.Label(adv_grid, text="sec", font=("Segoe UI", 9),
             fg=FG_DIM, bg=BG_PANEL).grid(row=1, column=5, sticky="w", pady=(4, 0))

    self.var_night = tk.BooleanVar(value=True)
    tk.Checkbutton(
      adv_grid, text="Night mode (CLAHE low-light enhancement)",
      variable=self.var_night,
      font=("Segoe UI", 9), fg=FG_DIM, bg=BG_PANEL,
      selectcolor=BG, activebackground=BG_PANEL,
    ).grid(row=2, column=0, columnspan=6, sticky="w", pady=(4, 0))

  # ── Step 3: Session History ────────────────────────────────────────────────

  def _build_step3(self, parent: tk.Frame):
    inner = self._make_panel(parent, "Session History & 3D Data", ORANGE, 3)

    tk.Label(
      inner,
      text="3D extraction runs automatically after each session ends.",
      font=("Segoe UI", 9, "italic"), fg=FG_DIM, bg=BG_PANEL, anchor="w",
    ).pack(fill=tk.X, pady=(0, 6))

    # Active extraction progress
    self._extract_progress_lbl = tk.Label(
      inner, text="", font=("Segoe UI", 9),
      fg=ORANGE, bg=BG_PANEL, anchor="w",
    )
    self._extract_progress_lbl.pack(fill=tk.X)

    self._extract_progress = ttk.Progressbar(
      inner, mode="determinate", maximum=100,
    )
    self._extract_progress.pack(fill=tk.X, pady=(2, 8))

    # Session list
    list_frm = tk.Frame(inner, bg=BG_PANEL)
    list_frm.pack(fill=tk.BOTH, expand=True)

    self._sessions_text = tk.Text(
      list_frm, bg=BG_DARK, fg=FG,
      font=("Consolas", 9), height=7,
      state=tk.DISABLED, wrap=tk.NONE,
      highlightthickness=0, bd=0,
    )
    sb_h = ttk.Scrollbar(list_frm, orient="horizontal",
                          command=self._sessions_text.xview)
    self._sessions_text.configure(xscrollcommand=sb_h.set)
    sb_v = ttk.Scrollbar(list_frm, orient="vertical",
                          command=self._sessions_text.yview)
    self._sessions_text.configure(yscrollcommand=sb_v.set)

    sb_v.pack(side=tk.RIGHT, fill=tk.Y)
    sb_h.pack(side=tk.BOTTOM, fill=tk.X)
    self._sessions_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Configure text tags for colour coding
    self._sessions_text.tag_configure("done",    foreground="#aaffaa")
    self._sessions_text.tag_configure("pending", foreground=FG_DIM)
    self._sessions_text.tag_configure("active",  foreground=ORANGE)
    self._sessions_text.tag_configure("header",  foreground=FG_DIM)

    # Bottom controls
    ctrl_row = tk.Frame(inner, bg=BG_PANEL)
    ctrl_row.pack(fill=tk.X, pady=(6, 0))

    tk.Button(
      ctrl_row, text="Refresh",
      font=("Segoe UI", 9), bg="#555", fg=FG,
      relief="flat", padx=8, pady=2,
      command=self._refresh_sessions,
    ).pack(side=tk.LEFT)

    self.btn_reextract = tk.Button(
      ctrl_row, text="Re-extract Selected",
      font=("Segoe UI", 9), bg="#555", fg=FG,
      relief="flat", padx=8, pady=2,
      state=tk.DISABLED,
      command=self._on_reextract_selected,
    )
    self.btn_reextract.pack(side=tk.LEFT, padx=6)

    self._selected_session: Optional[str] = None
    self._sessions_text.bind("<Button-1>", self._on_session_click)

  # ── UI state refresh ───────────────────────────────────────────────────────

  def _refresh_step1_ui(self):
    if self._calibrated:
      self._calib_dot.config(fg=GREEN)
      self._calib_status_lbl.config(text="\u2713 Calibrated", fg=GREEN)
      self._calib_progress["value"] = 100
    else:
      self._calib_dot.config(fg=FG_DIM)
      self._calib_status_lbl.config(text="Not calibrated", fg=FG_DIM)
      self._calib_progress["value"] = 0

  def _refresh_step2_ui(self):
    if self._calibrated:
      self.btn_mark_zone.config(state=tk.NORMAL)
      if self._zone_data:
        self.btn_start_mon.config(state=tk.NORMAL)
        self._zone_dot.config(fg=GREEN)
        self._zone_label.config(text="Dining Zone: defined", fg=GREEN)
        self.btn_clear_zone.config(state=tk.NORMAL)
        self._mon_detail_lbl.config(text="Ready — click Start Monitoring.")
      else:
        self.btn_start_mon.config(state=tk.DISABLED)
        self._zone_dot.config(fg=FG_DIM)
        self._zone_label.config(
          text="Dining Zone: not defined — define zone first", fg=FG_DIM,
        )
        self.btn_clear_zone.config(state=tk.DISABLED)
        self._mon_detail_lbl.config(
          text="Define a dining zone first to enable monitoring.",
        )
    else:
      self.btn_start_mon.config(state=tk.DISABLED)
      self.btn_mark_zone.config(state=tk.DISABLED)
      self.btn_clear_zone.config(state=tk.DISABLED)
      self._mon_detail_lbl.config(text="Calibrate first to enable monitoring.")

  def _toggle_advanced(self):
    if self._adv_expanded:
      self._adv_frame.pack_forget()
      self._adv_expanded = False
      self._adv_toggle_btn.config(text="\u25b8  Advanced Settings")
    else:
      self._adv_frame.pack(fill=tk.X, pady=(4, 0))
      self._adv_expanded = True
      self._adv_toggle_btn.config(text="\u25be  Advanced Settings")

  # ── Project dir ────────────────────────────────────────────────────────────

  def _on_select_project(self):
    d = filedialog.askdirectory(
      title="Select Project Directory",
      initialdir=str(self._project_dir.parent),
    )
    if d:
      self._project_dir = Path(d)
      self._project_dir.mkdir(parents=True, exist_ok=True)
      self._proj_label.config(text=self._short_path(self._project_dir))
      self._zone_data = self._load_dining_zone()
      self._check_existing()
      logger.info(f"Project directory: {self._project_dir}")

  @staticmethod
  def _short_path(p: Path) -> str:
    """Return a short display string for a path."""
    try:
      rel = p.relative_to(Path.cwd())
      s = str(rel)
    except ValueError:
      s = str(p)
    return s if len(s) <= 60 else "..." + s[-57:]

  # ── Step 1: calibration modal ─────────────────────────────────────────────

  def _on_start_calib(self):
    """Launch CalibrationUIAdvanced as a standalone subprocess (same as stereo-calibrate)."""
    # Release camera preview — Windows DirectShow exclusive access.
    if self._camera and self._camera._running:
      self._camera.stop()
      self._camera = None
      time.sleep(0.35)

    self.btn_start_calib.config(state=tk.DISABLED, text="Calibration running...")
    self._calib_dot.config(fg=ORANGE)
    self._calib_status_lbl.config(text="Calibration window open...", fg=ORANGE)

    # Use "-m recorder.calibration_ui_advanced" so that relative imports inside
    # the module work correctly.  Running the .py file directly would fail with
    # "attempted relative import with no known parent package".
    pkg = __name__.rsplit(".", 1)[0]   # "recorder"
    cmd = [sys.executable, "-m", f"{pkg}.calibration_ui_advanced",
           "--project-dir", str(self._project_dir)]
    if self._config_path and self._config_path.exists():
      cmd += ["--config", str(self._config_path)]

    self._calib_proc = subprocess.Popen(cmd)
    self._poll_calib_proc()

  def _poll_calib_proc(self):
    """Poll calibration subprocess every 500 ms; when it exits, run auto-calibration."""
    if self._calib_proc and self._calib_proc.poll() is None:
      self.after(500, self._poll_calib_proc)
      return

    self._calib_proc = None

    # CalibrationUIAdvanced only splits videos into calibration/intrinsic|extrinsic/.
    # The actual camera_array.toml is produced by run_auto_calibration().
    # Check whether recording videos were produced (i.e. the user didn't cancel).
    intrinsic_p1 = self._project_dir / "calibration" / "intrinsic" / "port_1.mp4"
    if intrinsic_p1.exists():
      # Videos are ready — run headless auto-calibration now
      self._run_auto_calibration()
    else:
      # User closed the calibration window without recording — just refresh state
      self.btn_start_calib.config(state=tk.NORMAL, text="\U0001f4f7  Start Calibration")
      self._calib_dot.config(fg=FG_DIM)
      self._calib_status_lbl.config(text="Not calibrated", fg=FG_DIM)
      self._check_existing()

  def _run_auto_calibration(self):
    """Run headless auto-calibration in background thread after videos are recorded."""
    self._calib_dot.config(fg=ORANGE)
    self._calib_status_lbl.config(text="Auto-calibrating...", fg=ORANGE)
    self._calib_progress["value"] = 0

    def worker():
      try:
        from .auto_calibrate import AutoCalibConfig, run_auto_calibration

        def on_progress(stage, msg, pct):
          self._msg_queue.put(("calib_progress", (stage, msg, pct)))

        cfg = AutoCalibConfig.from_yaml(self._yaml_data, self._project_dir)
        result = run_auto_calibration(cfg, on_progress=on_progress)

        if result.success:
          self._msg_queue.put(("calib_done", result))
        else:
          self._msg_queue.put(("calib_error", result.error_message or "Calibration failed"))
      except Exception as e:
        self._msg_queue.put(("calib_error", str(e)))

    threading.Thread(target=worker, daemon=True).start()

  # ── Step 2: auto-monitor ───────────────────────────────────────────────────

  def _on_start_monitor(self):
    # Stop camera preview if running — DirectShow exclusive access
    if self._camera and self._camera._running:
      self._camera.stop()
      self._camera = None
      time.sleep(0.35)

    rt_config = RealtimeDetectorConfig.from_calib_config(
      self.config,
      device_index=self.var_cam_index.get(),
      fps_target=self.var_fps.get(),
      auto_mode=True,
      absence_threshold=self.var_absence.get(),
      cooldown_seconds=float(self.var_cooldown.get()),
      low_light_enhance=self.var_night.get(),
    )

    recordings_base = self._project_dir / "recordings"
    recordings_base.mkdir(parents=True, exist_ok=True)

    self._detector = RealtimeDetector(
      rt_config, recordings_base,
      on_event=lambda e: self._det_event_q.put(e),
    )
    if not self._detector.start():
      messagebox.showerror("Error", "Cannot start monitoring. Check camera connection.")
      self._detector = None
      return

    # 就餐区域监控（独立运行，与姿态录制并行）
    if self._zone_data:
      from .dining_zone_monitor import DiningZoneMonitor
      from .ip_camera_trigger import StubIPCameraTrigger  # 有摄像头时换成 RTSPIPCameraTrigger
      self._dining_monitor = DiningZoneMonitor(
        zone=self._zone_data,
        trigger=StubIPCameraTrigger(),
        recordings_dir=self._project_dir / "recordings",
        absence_timeout=300.0,   # 5 分钟无人 → 就餐结束
        photo_interval=30.0,     # 每 30 秒拍一张
        overlap_threshold=0.5,   # 身体一半进入 zone → 算在内
        on_state_change=self._on_dining_state_change,
      )

    self.btn_start_mon.config(state=tk.DISABLED)
    self.btn_stop_mon.config(state=tk.NORMAL)
    self.btn_mark_zone.config(state=tk.DISABLED)
    self.btn_clear_zone.config(state=tk.DISABLED)
    self._mon_dot.config(fg=GREEN)
    self._mon_state_lbl.config(text="Monitoring \u2014 waiting for person...", fg=GREEN)
    self._mon_detail_lbl.config(text="YOLO person detection active.", fg=FG_DIM)
    logger.info("Auto-monitoring started (YOLO person detection + pose)")
    self._det_timer_tick()

  def _on_stop_monitor(self):
    if self._det_timer_id:
      self.after_cancel(self._det_timer_id)
      self._det_timer_id = None

    if self._detector:
      self._detector.stop()
      self._detector = None

    self._dining_monitor = None   # 随监控一起停止

    self.btn_start_mon.config(state=tk.NORMAL if self._zone_data else tk.DISABLED)
    self.btn_stop_mon.config(state=tk.DISABLED)
    self.btn_mark_zone.config(state=tk.NORMAL)
    self.btn_clear_zone.config(state=tk.NORMAL if self._zone_data else tk.DISABLED)
    self._mon_dot.config(fg=FG_DIM)
    self._mon_state_lbl.config(text="Idle", fg=FG_DIM)
    self._mon_detail_lbl.config(text="Monitoring stopped.", fg=FG_DIM)

    self.mon_preview_canvas.delete("all")
    self.mon_preview_canvas.create_text(
      14, 125, text="Camera feed appears here during monitoring.",
      anchor="w", fill=FG_DIM, font=("Segoe UI", 11),
    )
    logger.info("Auto-monitoring stopped.")
    self._refresh_sessions()

  def _det_timer_tick(self):
    if not self._detector or not self._detector.is_running:
      return

    while True:
      try:
        self._handle_detector_event(self._det_event_q.get_nowait())
      except queue.Empty:
        break

    dt = self._detector
    state = dt.auto_state

    if state == "idle":
      self._mon_dot.config(fg=GREEN)
      self._mon_state_lbl.config(text="Monitoring \u2014 waiting for person...", fg=GREEN)
      self._mon_detail_lbl.config(text="No person detected.", fg=FG_DIM)
    elif state == "detecting":
      elapsed = int(dt.recording_elapsed)
      m, s = divmod(elapsed, 60)
      self._mon_dot.config(fg=RED)
      self._mon_state_lbl.config(text="DETECTING \u2014 recording", fg=RED)
      self._mon_detail_lbl.config(
        text=f"Elapsed {m:02d}:{s:02d}  |  Frames {dt.frame_count}  |  Keypoints {dt.keypoint_count}",
        fg=RED,
      )
    elif state == "cooldown":
      rem = int(dt.cooldown_remaining)
      self._mon_dot.config(fg=ORANGE)
      self._mon_state_lbl.config(text="Cooldown \u2014 waiting for return...", fg=ORANGE)
      self._mon_detail_lbl.config(text=f"{rem} s remaining in cooldown.", fg=ORANGE)

    self._mon_session_lbl.config(text=f"Sessions: {dt.session_count}")

    frame = dt.get_frame()
    if frame is not None and CV2_AVAILABLE and PIL_AVAILABLE:
      self._display_mon_frame(frame, detecting=(state == "detecting"))

    # 就餐区域监控：每次 tick 更新一次（50ms 间隔，不影响性能）
    if self._dining_monitor is not None:
      boxes = dt.get_last_person_boxes()
      self._dining_monitor.update(boxes)

    self._det_timer_id = self.after(50, self._det_timer_tick)

  def _on_dining_state_change(self, new_state: str, info: dict):
    """就餐区域状态变化回调（从 DiningZoneMonitor 的 worker 线程调用）。"""
    # 通过消息队列转到主线程更新 UI
    self._msg_queue.put(("dining_state", (new_state, info)))

  def _handle_detector_event(self, event: dict):
    etype = event.get("type", "")
    if etype == "session_start":
      logger.info(f"[Monitor] Session started: {event.get('session', '')}")
    elif etype == "session_complete":
      s = event.get("session", "")
      f = event.get("total_frames", 0)
      k = event.get("total_keypoints", 0)
      logger.info(f"[Monitor] Session complete: {s} ({f} frames, {k} keypoints)")
    elif etype == "csv_saved":
      path = event.get("path", "")
      session = event.get("session", "")
      logger.info(f"[Monitor] CSV saved: {path}")
      self._refresh_sessions()
      # Auto-extract 3D immediately
      if session and self._calibrated:
        self._auto_extract(session)
    elif etype == "error":
      logger.error(f"[Monitor] {event.get('message', '')}")

  def _display_mon_frame(self, frame, detecting: bool = False):
    canvas = self.mon_preview_canvas
    cw = canvas.winfo_width()
    ch = canvas.winfo_height()
    if cw < 10 or ch < 10:
      return
    fh, fw = frame.shape[:2]
    scale = min(cw / fw, ch / fh)
    nw, nh = int(fw * scale), int(fh * scale)
    resized = cv2.resize(frame, (nw, nh))
    if detecting:
      cv2.circle(resized, (nw - 18, 18), 7, (0, 0, 255), -1)
    rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(rgb)
    photo = ImageTk.PhotoImage(image=img)
    canvas.delete("all")
    x_off = (cw - nw) // 2
    y_off = (ch - nh) // 2
    canvas.create_image(x_off, y_off, anchor=tk.NW, image=photo)
    canvas._photo = photo

    # Track frame transform for zone overlay coordinate mapping
    self._preview_scale = scale
    self._preview_x_offset = x_off
    self._preview_y_offset = y_off
    self._preview_left_w = fw
    self._preview_left_h = fh

    self._draw_zone_overlay()

  # ── Step 3: session history & 3D extraction ────────────────────────────────

  def _scan_sessions(self) -> list[dict]:
    """Scan recordings/ and return session info dicts."""
    rec_dir = self._project_dir / "recordings"
    sessions = []
    if not rec_dir.exists():
      return sessions

    for d in sorted(rec_dir.iterdir(), reverse=True):
      if not d.is_dir():
        continue
      xy_csv = d / "YOLOV8_POSE" / "xy_YOLOV8_POSE.csv"
      xyz_csv = d / "YOLOV8_POSE" / "xyz_YOLOV8_POSE.csv"
      has_2d = xy_csv.exists()
      has_3d = xyz_csv.exists()
      if not has_2d:
        continue  # Ignore legacy video-only sessions in home UI
      kp_count = 0
      if has_2d:
        try:
          import pandas as pd
          kp_count = len(pd.read_csv(xy_csv))
        except Exception:
          pass
      sessions.append({
        "name": d.name,
        "has_2d": has_2d,
        "has_3d": has_3d,
        "kp": kp_count,
        "xyz_path": str(xyz_csv) if has_3d else "",
      })
    return sessions

  def _refresh_sessions(self):
    """Redraw the session list text widget."""
    sessions = self._scan_sessions()
    self._sessions_text.config(state=tk.NORMAL)
    self._sessions_text.delete("1.0", tk.END)

    if not sessions:
      self._sessions_text.insert(tk.END, "No sessions found.\n", "pending")
    else:
      header = f"{'Session':<30}  {'2D':>6}  {'3D':>8}  {'Output'}\n"
      self._sessions_text.insert(tk.END, header, "header")
      self._sessions_text.insert(tk.END, "\u2500" * 80 + "\n", "header")
      for s in sessions:
        is_active = (s["name"] == self._extracting_session)
        two_d = f"{s['kp']:>6} kp" if s["has_2d"] else "   N/A"
        if is_active:
          three_d = " extracting"
          out = ""
          tag = "active"
        elif s["has_3d"]:
          three_d = "     done"
          out = Path(s["xyz_path"]).name
          tag = "done"
        else:
          three_d = "  pending"
          out = ""
          tag = "pending"
        line = f"{s['name']:<30}  {two_d}  {three_d}  {out}\n"
        self._sessions_text.insert(tk.END, line, tag)

    self._sessions_text.config(state=tk.DISABLED)

    # Enable re-extract button only when calibrated + session selected
    if self._calibrated and self._selected_session:
      self.btn_reextract.config(state=tk.NORMAL)

  def _on_session_click(self, event):
    """Select a session by clicking its row."""
    idx = self._sessions_text.index(f"@{event.x},{event.y}")
    line_num = int(idx.split(".")[0])
    if line_num <= 2:  # header rows
      return
    line = self._sessions_text.get(f"{line_num}.0", f"{line_num}.end").strip()
    if line.startswith("\u2500") or not line:
      return
    name = line.split()[0]
    self._selected_session = name
    self.btn_reextract.config(
      state=tk.NORMAL if self._calibrated else tk.DISABLED,
    )
    logger.info(f"Selected session: {name}")

  def _auto_extract(self, session_name: str):
    """Start background 3D extraction for session_name (auto-triggered)."""
    if self._extracting_session == session_name:
      return  # Already in progress
    self._extracting_session = session_name
    self._extract_progress_lbl.config(
      text=f"Extracting 3D: {session_name}...", fg=ORANGE,
    )
    self._extract_progress["value"] = 0
    self._refresh_sessions()
    threading.Thread(
      target=self._worker_extract_3d,
      args=(session_name,),
      daemon=True,
    ).start()

  def _on_reextract_selected(self):
    """Re-run 3D extraction for the selected session."""
    if not self._selected_session:
      return
    self._auto_extract(self._selected_session)

  def _worker_extract_3d(self, session_name: str):
    try:
      from .auto_calibrate import run_auto_reconstruction

      def on_progress(stage, msg, pct):
        self._msg_queue.put(("extract_progress", (stage, msg, pct)))

      output_path = run_auto_reconstruction(
        self._project_dir,
        session_name,
        tracker_name="YOLOV8_POSE",
        fps_target=10,
        on_progress=on_progress,
      )
      self._msg_queue.put(("extract_done", (session_name, str(output_path))))
    except Exception as e:
      self._msg_queue.put(("extract_error", (session_name, str(e))))

  # ── Main update loop ───────────────────────────────────────────────────────

  def _update_loop(self):
    while True:
      try:
        mtype, mdata = self._msg_queue.get_nowait()
        self._handle_message(mtype, mdata)
      except queue.Empty:
        break

    # Show camera preview on monitoring canvas when marking zone (no detector)
    if (self._camera and self._camera._running
        and not self._detector
        and CV2_AVAILABLE and PIL_AVAILABLE):
      frame = self._camera.get_frame()
      if frame is not None:
        self._display_mon_frame(frame)

    self.after(50, self._update_loop)

  def _handle_message(self, mtype: str, mdata):
    """Dispatch messages from background threads."""

    if mtype == "calib_progress":
      stage, text, pct = mdata
      if pct >= 0:
        self._calib_progress["value"] = pct
      self._calib_status_lbl.config(
        text=f"Calibrating: {text[:60]}", fg=ORANGE,
      )

    elif mtype == "calib_done":
      self._calib_progress["value"] = 100
      self.btn_start_calib.config(state=tk.NORMAL, text="\U0001f4f7  Start Calibration")
      self._check_existing()   # → sets _calibrated=True, updates dot/label/step2

    elif mtype == "calib_error":
      err = str(mdata)
      self._calib_dot.config(fg=RED)
      self._calib_status_lbl.config(text=f"Error: {err[:60]}", fg=RED)
      self._calib_progress["value"] = 0
      self.btn_start_calib.config(state=tk.NORMAL, text="\U0001f4f7  Start Calibration")
      logger.error(f"Auto-calibration failed: {err}")
      messagebox.showerror("Calibration Error",
                           f"Auto-calibration failed:\n{err}",
                           parent=self)

    elif mtype == "extract_progress":
      stage, text, pct = mdata
      if pct >= 0:
        self._extract_progress["value"] = pct
      self._extract_progress_lbl.config(
        text=f"Extracting 3D: {text}", fg=ORANGE,
      )

    elif mtype == "extract_done":
      session_name, output_path = mdata
      self._extracting_session = None
      self._extract_progress["value"] = 100
      self._extract_progress_lbl.config(
        text=f"\u2713 3D extraction complete: {Path(output_path).name}", fg=GREEN,
      )
      logger.info(f"3D output: {output_path}")
      self._refresh_sessions()

    elif mtype == "extract_error":
      session_name, err = mdata
      self._extracting_session = None
      self._extract_progress_lbl.config(
        text=f"3D extraction failed for {session_name}", fg=RED,
      )
      logger.error(f"3D extraction failed ({session_name}): {err}")
      self._refresh_sessions()

    elif mtype == "dining_state":
      new_state, info = mdata
      self._update_dining_ui(new_state, info)

  def _update_dining_ui(self, state: str, info: dict):
    """根据就餐区域状态刷新 zone 状态标签（主线程）。"""
    sid = info.get("session_id") or ""
    photos = info.get("photo_count", 0)
    cooldown = info.get("cooldown_remaining", 0.0)

    if state == "occupied":
      elapsed = int(info.get("session_elapsed", 0))
      m, s = divmod(elapsed, 60)
      self._zone_dot.config(fg=GREEN)
      self._zone_label.config(
        text=f"Dining Zone: \u2022 occupied  {m:02d}:{s:02d}  \U0001f4f7{photos}",
        fg=GREEN,
      )
    elif state == "cooldown":
      rem = int(cooldown)
      self._zone_dot.config(fg=ORANGE)
      self._zone_label.config(
        text=f"Dining Zone: person left — ending in {rem}s  \U0001f4f7{photos}",
        fg=ORANGE,
      )
    else:  # empty
      self._zone_dot.config(fg=FG_DIM)
      if sid:
        # 刚结束一次 session
        self._zone_label.config(
          text=f"Dining Zone: session ended  \U0001f4f7{photos} photos saved",
          fg=FG_DIM,
        )
      else:
        self._zone_label.config(text="Dining Zone: defined — watching...", fg=GREEN)

  # ========================================================================
  # Dining Zone
  # ========================================================================

  def _on_mark_zone(self):
    """Enter zone-drawing mode. Start camera preview if needed."""
    if not (self._camera and self._camera._running) and not self._detector:
      if not CV2_AVAILABLE:
        messagebox.showerror("Error", "OpenCV not available for camera preview.")
        return
      self._camera = CameraPreview(
        self.config.device_name,
        self.config.video_size,
        self.config.fps,
        device_index=self.var_cam_index.get(),
      )
      if not self._camera.start():
        messagebox.showerror("Error", "Failed to open camera for zone marking.")
        self._camera = None
        return

    self._zone_drawing = True
    self.mon_preview_canvas.bind("<Button-1>", self._zone_mouse_press)
    self.mon_preview_canvas.bind("<B1-Motion>", self._zone_mouse_drag)
    self.mon_preview_canvas.bind("<ButtonRelease-1>", self._zone_mouse_release)
    self._zone_label.config(text="Dining Zone: draw on preview...", fg=ORANGE)
    self._zone_dot.config(fg=ORANGE)
    logger.info("Draw dining zone on camera preview (click and drag)")

  def _on_clear_zone(self):
    """Clear the dining zone."""
    self._zone_data = None
    self._zone_drawing = False
    self.mon_preview_canvas.delete("zone_rect")
    self.mon_preview_canvas.delete("zone_overlay")
    self.mon_preview_canvas.unbind("<Button-1>")
    self.mon_preview_canvas.unbind("<B1-Motion>")
    self.mon_preview_canvas.unbind("<ButtonRelease-1>")
    zone_path = self._project_dir / "config" / "dining_zone.toml"
    if zone_path.exists():
      zone_path.unlink()
    self._zone_dot.config(fg=FG_DIM)
    self._zone_label.config(text="Dining Zone: not defined", fg=FG_DIM)
    self.btn_clear_zone.config(state=tk.DISABLED)
    self.btn_start_mon.config(state=tk.DISABLED)
    self._mon_detail_lbl.config(text="Define a dining zone first to enable monitoring.")
    logger.info("Dining zone cleared")

  def _zone_mouse_press(self, event):
    self._zone_start = (event.x, event.y)

  def _zone_mouse_drag(self, event):
    if self._zone_start is None:
      return
    self.mon_preview_canvas.delete("zone_rect")
    self.mon_preview_canvas.create_rectangle(
      self._zone_start[0], self._zone_start[1], event.x, event.y,
      outline="#4CAF50", width=2, dash=(5, 3), tags="zone_rect",
    )

  def _zone_mouse_release(self, event):
    if self._zone_start is None:
      return
    x1_c, y1_c = self._zone_start
    x2_c, y2_c = event.x, event.y
    self._zone_start = None
    self._zone_drawing = False

    # Ensure minimum size on canvas
    if abs(x2_c - x1_c) < 10 or abs(y2_c - y1_c) < 10:
      self.mon_preview_canvas.delete("zone_rect")
      self._zone_label.config(text="Dining Zone: too small, try again", fg=RED)
      return

    # Normalize order
    if x1_c > x2_c:
      x1_c, x2_c = x2_c, x1_c
    if y1_c > y2_c:
      y1_c, y2_c = y2_c, y1_c

    # Convert canvas coords to source image coords
    img_x1 = (x1_c - self._preview_x_offset) / self._preview_scale
    img_y1 = (y1_c - self._preview_y_offset) / self._preview_scale
    img_x2 = (x2_c - self._preview_x_offset) / self._preview_scale
    img_y2 = (y2_c - self._preview_y_offset) / self._preview_scale

    # Normalize relative to left camera dimensions
    left_w = self._preview_left_w
    left_h = self._preview_left_h
    x1_norm = max(0.0, min(1.0, img_x1 / left_w))
    y1_norm = max(0.0, min(1.0, img_y1 / left_h))
    x2_norm = max(0.0, min(1.0, img_x2 / left_w))
    y2_norm = max(0.0, min(1.0, img_y2 / left_h))

    # Validate normalized size
    if x2_norm - x1_norm < 0.02 or y2_norm - y1_norm < 0.02:
      self.mon_preview_canvas.delete("zone_rect")
      self._zone_label.config(text="Dining Zone: too small, try again", fg=RED)
      return

    # Store and save
    self._zone_data = {
      "x1": x1_norm, "y1": y1_norm,
      "x2": x2_norm, "y2": y2_norm,
    }
    self._save_dining_zone()

    # Unbind mouse events
    self.mon_preview_canvas.unbind("<Button-1>")
    self.mon_preview_canvas.unbind("<B1-Motion>")
    self.mon_preview_canvas.unbind("<ButtonRelease-1>")

    # Update UI
    self.mon_preview_canvas.delete("zone_rect")
    self._draw_zone_overlay()
    self._zone_dot.config(fg=GREEN)
    self._zone_label.config(text="Dining Zone: defined", fg=GREEN)
    self.btn_clear_zone.config(state=tk.NORMAL)
    self.btn_start_mon.config(state=tk.NORMAL)
    self._mon_detail_lbl.config(text="Ready \u2014 click Start Monitoring.")
    logger.info(
      f"Dining zone saved: ({x1_norm:.2f},{y1_norm:.2f})-({x2_norm:.2f},{y2_norm:.2f})"
    )

  def _save_dining_zone(self):
    """Save dining zone to project config/dining_zone.toml."""
    if not self._zone_data:
      return
    config_dir = self._project_dir / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    zone_path = config_dir / "dining_zone.toml"

    z = self._zone_data
    xsplit = self.config.xsplit
    full_h = self.config.full_h
    content = (
      "[zone]\n"
      f'name = "dining_area"\n'
      f"x1 = {z['x1']:.4f}\n"
      f"y1 = {z['y1']:.4f}\n"
      f"x2 = {z['x2']:.4f}\n"
      f"y2 = {z['y2']:.4f}\n"
      f"px_x1 = {int(z['x1'] * xsplit)}\n"
      f"px_y1 = {int(z['y1'] * full_h)}\n"
      f"px_x2 = {int(z['x2'] * xsplit)}\n"
      f"px_y2 = {int(z['y2'] * full_h)}\n"
    )
    zone_path.write_text(content)

  def _load_dining_zone(self) -> Optional[dict]:
    """Load dining zone from project config/dining_zone.toml."""
    zone_path = self._project_dir / "config" / "dining_zone.toml"
    if not zone_path.exists():
      return None
    try:
      data = {}
      for line in zone_path.read_text().splitlines():
        line = line.strip()
        if "=" in line and not line.startswith("[") and not line.startswith("#"):
          key, val = line.split("=", 1)
          key = key.strip()
          val = val.strip().strip('"')
          if key in ("x1", "y1", "x2", "y2"):
            data[key] = float(val)
      if all(k in data for k in ("x1", "y1", "x2", "y2")):
        return data
    except Exception as e:
      logger.warning(f"Failed to load dining zone: {e}")
    return None

  def _draw_zone_overlay(self):
    """Draw the dining zone rectangle overlay on the monitoring canvas."""
    self.mon_preview_canvas.delete("zone_overlay")
    if not self._zone_data:
      return
    z = self._zone_data
    left_w = self._preview_left_w
    left_h = self._preview_left_h
    scale = self._preview_scale
    x_off = self._preview_x_offset
    y_off = self._preview_y_offset

    # Convert normalized zone coords to canvas coords
    cx1 = z["x1"] * left_w * scale + x_off
    cy1 = z["y1"] * left_h * scale + y_off
    cx2 = z["x2"] * left_w * scale + x_off
    cy2 = z["y2"] * left_h * scale + y_off

    self.mon_preview_canvas.create_rectangle(
      cx1, cy1, cx2, cy2,
      outline="#4CAF50", width=2, tags="zone_overlay",
    )
    self.mon_preview_canvas.create_text(
      cx1 + 4, cy1 + 2, text="Dining Zone", anchor=tk.NW,
      fill="#4CAF50", font=("Segoe UI", 8), tags="zone_overlay",
    )

  # ── Utilities ──────────────────────────────────────────────────────────────

  def destroy(self):
    if self._det_timer_id:
      self.after_cancel(self._det_timer_id)
    if self._detector:
      self._detector.stop()
    if self._camera:
      self._camera.stop()
    if self._calib_proc and self._calib_proc.poll() is None:
      self._calib_proc.terminate()
    super().destroy()
