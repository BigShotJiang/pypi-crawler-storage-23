"""IP Camera Trigger — 抽象接口 + 各种实现

架构说明
--------
Python 主动从摄像头"拉"一帧，保存到本地硬盘。
摄像头本身不需要做任何特殊配置（不用它内部存储）：

    IP摄像头
        │
        │ RTSP视频流 / HTTP snapshot
        ▼
    Python (cv2 / requests)
        │
        │ cv2.imwrite / file.write_bytes
        ▼
    本地硬盘  recordings/dining_xxx/photos/photo_001.jpg

使用方法
--------
现在（无摄像头）:
    trigger = StubIPCameraTrigger()   # 只写日志，不真正拍照

将来（有摄像头）, 二选一:
    trigger = RTSPIPCameraTrigger("rtsp://admin:pass@192.168.1.10/stream1")
    trigger = HTTPIPCameraTrigger("192.168.1.10", username="admin", password="pass")

在 DiningZoneMonitor 里只用抽象接口，换实现不需要改其他任何代码。
"""
from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


# ============================================================================
# 抽象接口
# ============================================================================

class IPCameraTrigger(ABC):
    """协议无关的 IP 摄像头触发接口。所有实现必须继承此类。"""

    @abstractmethod
    def start_session(self, session_id: str, save_dir: Path) -> bool:
        """
        就餐开始——通知摄像头上线 / 做好准备。
        save_dir: 本次就餐照片的保存目录（已创建好）。
        返回 True 表示成功。
        """

    @abstractmethod
    def take_photo(self, session_id: str, index: int, save_dir: Path) -> bool:
        """
        拍摄第 index 张照片，保存到 save_dir / f"photo_{index:03d}.jpg"。
        返回 True 表示成功。
        """

    @abstractmethod
    def stop_session(self, session_id: str) -> bool:
        """就餐结束——通知摄像头下线。返回 True 表示成功。"""


# ============================================================================
# Stub 实现（无摄像头时使用）
# ============================================================================

class StubIPCameraTrigger(IPCameraTrigger):
    """
    占位实现：只写日志，不做任何真实的网络调用。
    有真实摄像头后，将此类替换为 RTSPIPCameraTrigger 或
    HTTPIPCameraTrigger，其他代码零改动。
    """

    def start_session(self, session_id: str, save_dir: Path) -> bool:
        logger.info(f"[IP Camera STUB] start_session  id={session_id}  dir={save_dir}")
        # 写一个元数据文件，方便以后排查
        (save_dir / "session_meta.txt").write_text(
            f"session_id={session_id}\n"
            f"trigger=StubIPCameraTrigger\n"
            f"started={time.strftime('%Y-%m-%d %H:%M:%S')}\n",
            encoding="utf-8",
        )
        return True

    def take_photo(self, session_id: str, index: int, save_dir: Path) -> bool:
        logger.info(f"[IP Camera STUB] take_photo  #{index:03d}  session={session_id}")
        # 写一个占位文件，模拟照片存在
        (save_dir / f"photo_{index:03d}.stub").write_text(
            f"stub photo {index}\n", encoding="utf-8"
        )
        return True

    def stop_session(self, session_id: str) -> bool:
        logger.info(f"[IP Camera STUB] stop_session  id={session_id}")
        return True


# ============================================================================
# RTSP 实现（最通用，几乎所有 IP 摄像头都支持）
# ============================================================================

class RTSPIPCameraTrigger(IPCameraTrigger):
    """
    通过 RTSP 视频流抓帧保存。需要 opencv-python。

    几乎所有 IP 摄像头都支持 RTSP，格式通常为：
        rtsp://用户名:密码@IP地址:554/stream1
        rtsp://用户名:密码@IP地址:554/ch0/main/av_stream   (海康)
        rtsp://用户名:密码@IP地址:554/h264Preview_01_main   (大华)
        rtsp://IP地址:554/live                              (无验证)

    买到摄像头后查说明书或在 ONVIF Device Manager 里找 RTSP 地址。
    """

    def __init__(self, rtsp_url: str, timeout_sec: float = 5.0):
        self._url = rtsp_url
        self._timeout = timeout_sec

    def start_session(self, session_id: str, save_dir: Path) -> bool:
        logger.info(f"[RTSP] start_session  id={session_id}  url={self._url}")
        # RTSP 不需要"开机"命令，连接时摄像头已在工作
        # 可选：在这里验证摄像头是否可达
        return self._ping()

    def take_photo(self, session_id: str, index: int, save_dir: Path) -> bool:
        try:
            import cv2
            cap = cv2.VideoCapture(self._url)
            cap.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, self._timeout * 1000)
            cap.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, self._timeout * 1000)
            ret, frame = cap.read()
            cap.release()
            if not ret or frame is None:
                logger.warning(f"[RTSP] take_photo #{index:03d} — no frame received")
                return False
            out_path = save_dir / f"photo_{index:03d}.jpg"
            cv2.imwrite(str(out_path), frame)
            logger.info(f"[RTSP] photo saved: {out_path.name}")
            return True
        except Exception as e:
            logger.error(f"[RTSP] take_photo error: {e}")
            return False

    def stop_session(self, session_id: str) -> bool:
        logger.info(f"[RTSP] stop_session  id={session_id}")
        return True

    def _ping(self) -> bool:
        """尝试连接一次验证摄像头可达。"""
        try:
            import cv2
            cap = cv2.VideoCapture(self._url)
            ok = cap.isOpened()
            cap.release()
            if not ok:
                logger.warning(f"[RTSP] cannot connect to {self._url}")
            return ok
        except Exception as e:
            logger.warning(f"[RTSP] ping error: {e}")
            return False


# ============================================================================
# HTTP Snapshot 实现（适合支持 HTTP CGI 的摄像头）
# ============================================================================

class HTTPIPCameraTrigger(IPCameraTrigger):
    """
    通过 HTTP 请求抓取快照。需要 requests 库。

    常见 snapshot URL（查摄像头说明书）：
        http://IP/snapshot.cgi               (通用)
        http://IP/cgi-bin/snapshot.cgi       (海康/大华)
        http://IP/cgi-bin/api.cgi?cmd=Snap   (Reolink)
        http://IP/image/jpeg.cgi             (Axis)

    认证方式：大多数摄像头用 Basic Auth（用户名+密码）。
    """

    def __init__(
        self,
        host: str,
        snapshot_path: str = "/snapshot.cgi",
        port: int = 80,
        username: str = "admin",
        password: str = "",
        timeout_sec: float = 5.0,
    ):
        self._base = f"http://{host}:{port}"
        self._snap_url = f"{self._base}{snapshot_path}"
        self._auth = (username, password) if username else None
        self._timeout = timeout_sec

    def start_session(self, session_id: str, save_dir: Path) -> bool:
        logger.info(f"[HTTP] start_session  id={session_id}  url={self._snap_url}")
        return True

    def take_photo(self, session_id: str, index: int, save_dir: Path) -> bool:
        try:
            import requests
            r = requests.get(
                self._snap_url, auth=self._auth,
                timeout=self._timeout, stream=True,
            )
            r.raise_for_status()
            out_path = save_dir / f"photo_{index:03d}.jpg"
            out_path.write_bytes(r.content)
            logger.info(f"[HTTP] photo saved: {out_path.name}  ({len(r.content)} bytes)")
            return True
        except Exception as e:
            logger.error(f"[HTTP] take_photo error: {e}")
            return False

    def stop_session(self, session_id: str) -> bool:
        logger.info(f"[HTTP] stop_session  id={session_id}")
        return True
