# filler-classifier

Thai filler word classifier for voice bots. Classifies customer input into categories and returns the appropriate filler phrase to play instantly while the LLM generates a full response.

Built for [ingfah.ai](https://ingfah.ai) voice bot but easily adaptable to any Thai voice AI system.

## Why

Voice bots have a latency problem: the user speaks, ASR transcribes, then the LLM takes 1-3 seconds to respond. Dead silence feels broken. The solution is to play a short filler phrase ("สักครู่นะคะ", "ขออภัยด้วยน่ะคะ") immediately while the LLM thinks.

But you can't play the same filler for everything. If someone is angry, "ได้เลยค่ะ" sounds dismissive. If someone asks a question, "ขออภัยด้วยน่ะคะ" makes no sense.

This classifier picks the right filler by category.

## Categories

| Category | When | Example Fillers |
|---|---|---|
| `complaint` | Angry, frustrated, profanity, threats | ขออภัยด้วยน่ะคะ |
| `question` | Asking for info, pricing, how-to | สักครู่นะคะ, ตรวจสอบให้นะคะ |
| `default` | Greetings, agreements, requests, everything else | รับทราบค่ะ, ได้เลยค่ะ |

### Default Filler Phrases

| Category | Fillers |
|---|---|
| `complaint` | ขออภัยด้วยน่ะคะ |
| `question` | สักครู่นะคะ, สักครู่ค่ะ, ตรวจสอบให้นะคะ |
| `default` | รับทราบค่ะ, ค่ะ ได้ค่ะ, ได้เลยค่ะ, ดีเลยค่ะ, ยินดีค่ะ |

A random filler is picked from the matching category each time. These are designed to be short (~0.3-0.5s when synthesized) for minimal latency.

## How It Works

Uses `intfloat/multilingual-e5-small` embeddings with centroid-based cosine similarity:

1. Each category has ~30-60 anchor phrases (real Thai customer service examples)
2. On init, all anchors are embedded and averaged into category centroids
3. At inference, the input is embedded and compared to centroids via cosine similarity
4. The closest category wins, and a random filler from that category is returned

## Performance

- **Accuracy**: 89.6% on 1,000 Thai customer service sentences
- **Inference**: <10ms per classification (after model load)
- **Init**: ~200ms for centroid computation
- **Model size**: ~118MB (multilingual-e5-small)

## Installation

```bash
pip install filler-classifier
```

## Usage

```python
from filler_classifier import FillerClassifier

# loads model automatically on first init
clf = FillerClassifier()

# classify and get category + confidence + filler
category, confidence, filler = clf.classify("อยากถามเรื่องบิลครับ")
# ("question", 0.872, "สักครู่นะคะ")

category, confidence, filler = clf.classify("ใช้งานไม่ได้เลย")
# ("complaint", 0.891, "ขออภัยด้วยน่ะคะ")

category, confidence, filler = clf.classify("ได้ครับ ตกลง")
# ("default", 0.845, "ได้เลยค่ะ")

# or just get the filler phrase directly
filler = clf.get_filler("มีโปรอะไรบ้างครับ")
# "ตรวจสอบให้นะคะ"
```

### Sharing the model

If you already have a `SentenceTransformer` instance loaded (e.g., for other tasks), pass it in to avoid loading twice:

```python
from sentence_transformers import SentenceTransformer
from filler_classifier import FillerClassifier

model = SentenceTransformer("intfloat/multilingual-e5-small")
clf = FillerClassifier(model=model)
```

## Customizing Fillers

Override `CATEGORY_FILLERS` to use your own phrases:

```python
import filler_classifier

filler_classifier.CATEGORY_FILLERS["complaint"] = ["ขออภัยค่ะ", "เข้าใจค่ะ"]
filler_classifier.CATEGORY_FILLERS["question"] = ["รอสักครู่นะคะ"]
```

## License

MIT
