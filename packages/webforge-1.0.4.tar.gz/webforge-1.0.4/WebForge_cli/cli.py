#!/usr/bin/env python3
"""
WebForge CLI - Scaffold new projects
Usage: webforge new <project-name>
       webforge run
"""

import sys
import os
import argparse
from pathlib import Path


FORGE_PY_TEMPLATE = '''\
from WebForge import webforge, security, env as web

# ─── Environment ─────────────────────────────────────────────────────────────
# password = web.env("PASSWORD")
# ip = "192.168.1.1"

# ─── Routes ──────────────────────────────────────────────────────────────────
@web.app("/")
def index():
    web.route("style", "/public/service/style.css")
    return web.render("index.html")

@web.app("/login")
def login():
    return web.render("login.html")

# ─── Security ────────────────────────────────────────────────────────────────
# @web.security("/")
# def secure_home():
#     if not web.password(password):
#         return web.redirect("/login")
#     if not web.ip(ip):
#         return web.abort(403)

# ─── Run ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    web.runapp(debug=True, port=5000, host="0.0.0.0")
'''

INDEX_HTML_TEMPLATE = '''\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WebForge App</title>
  <link rel="stylesheet" href="/static/style" />
</head>
<body>
  <main>
    <h1>🔥 Welcome to WebForge</h1>
    <p>Your app is running. Edit <code>public/pages/index.html</code> to get started.</p>
    <a href="/login">Go to Login</a>
  </main>
  <script src="/public/script/app.js"></script>
</body>
</html>
'''

LOGIN_HTML_TEMPLATE = '''\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - WebForge</title>
  <link rel="stylesheet" href="/static/style" />
</head>
<body>
  <main>
    <h1>🔐 Login</h1>
    <form method="POST" action="/login">
      <input type="password" name="password" placeholder="Password" required />
      <button type="submit">Sign In</button>
    </form>
  </main>
</body>
</html>
'''

STYLE_CSS_TEMPLATE = '''\
/* WebForge default styles */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: "Segoe UI", system-ui, -apple-system, sans-serif;
  background: #0f0f13;
  color: #e8e8f0;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

main {
  text-align: center;
  padding: 3rem;
  max-width: 600px;
}

h1 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
  background: linear-gradient(135deg, #ff6b35, #f7c59f);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

p { color: #a0a0b8; margin-bottom: 1.5rem; }

a, button {
  display: inline-block;
  padding: 0.75rem 2rem;
  background: #ff6b35;
  color: white;
  border: none;
  border-radius: 8px;
  text-decoration: none;
  cursor: pointer;
  font-size: 1rem;
  transition: background 0.2s;
}

a:hover, button:hover { background: #e85a25; }

input {
  display: block;
  width: 100%;
  padding: 0.75rem 1rem;
  margin-bottom: 1rem;
  background: #1a1a24;
  border: 1px solid #333;
  border-radius: 8px;
  color: #e8e8f0;
  font-size: 1rem;
}

code {
  background: #1a1a24;
  padding: 0.2rem 0.5rem;
  border-radius: 4px;
  font-family: monospace;
  color: #ff6b35;
}
'''

APP_JS_TEMPLATE = '''\
// WebForge App - client-side scripts
console.log("🔥 WebForge App loaded");
'''

REQUIREMENTS_TEMPLATE = '''\
WebForge
flask>=3.0.0
python-dotenv>=1.0.0
'''

GITIGNORE_TEMPLATE = '''\
__pycache__/
*.py[cod]
.env
*.env
venv/
.venv/
'''


def scaffold(name: str):
    base = Path(name)
    if base.exists():
        print(f"❌ Directory '{name}' already exists.")
        sys.exit(1)

    dirs = [
        base / "backend" / "server",
        base / "public" / "pages",
        base / "public" / "script",
        base / "public" / "service",
    ]
    for d in dirs:
        d.mkdir(parents=True)

    files = {
        base / "backend" / "server" / "forge.py": FORGE_PY_TEMPLATE,
        base / "backend" / "requirements.txt": REQUIREMENTS_TEMPLATE,
        base / "public" / "pages" / "index.html": INDEX_HTML_TEMPLATE,
        base / "public" / "pages" / "login.html": LOGIN_HTML_TEMPLATE,
        base / "public" / "service" / "style.css": STYLE_CSS_TEMPLATE,
        base / "public" / "script" / "app.js": APP_JS_TEMPLATE,
        base / ".gitignore": GITIGNORE_TEMPLATE,
    }

    for path, content in files.items():
        path.write_text(content, encoding="utf-8")

    print(f"""
╔══════════════════════════════════════════════╗
║        🔥 WebForge Project Created!           ║
╠══════════════════════════════════════════════╣
║  Project: {name:<35}║
╠══════════════════════════════════════════════╣
║  Next steps:                                  ║
║  cd {name:<39}║
║  pip install -r backend/requirements.txt      ║
║  python backend/server/forge.py               ║
╚══════════════════════════════════════════════╝
    """)


def run_server():
    """Run the forge.py in the current project"""
    forge = Path("backend/server/forge.py")
    if not forge.exists():
        print("❌ No forge.py found. Are you in a WebForge project directory?")
        sys.exit(1)
    os.execv(sys.executable, [sys.executable, str(forge)])


def main():
    parser = argparse.ArgumentParser(
        prog="webforge",
        description="🔥 WebForge - Create web apps easily"
    )
    subparsers = parser.add_subparsers(dest="command")

    # webforge new <name>
    new_parser = subparsers.add_parser("new", help="Create a new WebForge project")
    new_parser.add_argument("name", help="Project name")

    # webforge run
    subparsers.add_parser("run", help="Run the current WebForge project")

    args = parser.parse_args()

    if args.command == "new":
        scaffold(args.name)
    elif args.command == "run":
        run_server()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
