"""
WebForge - Create web applications easily

Usage in forge.py:
    from WebForge import webforge, security, env as web

    @web.app("/")
    def index():
        web.route("style", "/public/service/style.css")
        return web.render("index.html")

    @web.security("/")
    def secure_home():
        if not web.password(pw): return web.redirect("/login")
        if not web.ip(allowed):  return web.abort(403)

    web.runapp(debug=True, port=5000)
"""

from .core import WebForgeApp

# Single global app instance shared across the whole project
_app = WebForgeApp()


class _Namespace:
    """
    The WebForge namespace object.
    Imported as `env as web` so that `web.env()`, `web.app()`, etc. all work.
    Also callable directly: web("MY_VAR") == web.env("MY_VAR")
    """

    def __init__(self, app: WebForgeApp):
        self._app = app

    def __call__(self, key: str, default=None):
        return self._app.env(key, default)

    # ── Environment ─────────────────────────────────────
    def env(self, key: str, default=None):
        """Read an environment variable (like os.getenv)"""
        return self._app.env(key, default)

    # ── Routing ─────────────────────────────────────────
    def app(self, route_path: str, methods=None):
        """Decorator: register a route handler"""
        return self._app.app(route_path, methods)

    def route(self, name: str, path: str):
        """Register a named static file route"""
        return self._app.add_static_route(name, path)

    # ── Responses ───────────────────────────────────────
    def render(self, template: str, **context):
        """Render an HTML template from public/pages/"""
        return self._app.render(template, **context)

    def redirect(self, url: str, code: int = 302):
        """HTTP redirect"""
        return self._app.redirect(url, code)

    def abort(self, code: int, message=None):
        """Abort with an HTTP error code"""
        return self._app.abort(code, message)

    # ── Security ────────────────────────────────────────
    def security(self, route_path: str):
        """Decorator: register security middleware for a route"""
        return self._app.security(route_path)

    def password(self, stored_password: str) -> bool:
        """Check session password against stored value"""
        return self._app.check_password(stored_password)

    def ip(self, allowed_ip) -> bool:
        """Check if request IP matches allowed value(s)"""
        return self._app.check_ip(allowed_ip)

    # ── Server ──────────────────────────────────────────
    def runapp(self, debug: bool = False, port: int = 5000, host: str = "0.0.0.0"):
        """Start the WebForge development server"""
        return self._app.run(debug=debug, port=port, host=host)


_ns = _Namespace(_app)

# Public exports:
#   from WebForge import webforge, security, env as web
webforge = _app          # raw app instance (advanced use)
security = _ns.security  # importable standalone decorator
env = _ns               # becomes `web` via `env as web`

__all__ = ["WebForgeApp", "webforge", "security", "env"]
