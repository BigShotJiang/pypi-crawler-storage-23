"""The numerical image analysis - input/output (`NImA-io`)."""
