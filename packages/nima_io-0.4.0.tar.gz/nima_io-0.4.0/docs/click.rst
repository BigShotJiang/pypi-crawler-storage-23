.. _cli:

Command-line tool
=================

.. contents::
   :local:

.. click:: nima_io.__main__:imgdiff
   :prog: imgdiff
   :nested: full
