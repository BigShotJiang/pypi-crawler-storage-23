nima_io.read
----------------

.. automodule:: nima_io.read
   :undoc-members:
   :autosummary-sections: Classes ;; Exceptions ;; Functions ;; Methods ;; Data
