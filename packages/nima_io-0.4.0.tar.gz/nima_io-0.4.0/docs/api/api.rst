.. _api:

API references
==============

This part of the documentation lists the full API reference of all public
classes and functions.

.. toctree::
   :maxdepth: 1

   nima_io
