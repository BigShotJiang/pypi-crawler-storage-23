"""Test suite for the nima_io package."""
