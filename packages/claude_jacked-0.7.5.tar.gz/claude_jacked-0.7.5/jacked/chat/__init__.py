"""Chat sessions — WebSocket bridge between browser and Claude CLI."""
