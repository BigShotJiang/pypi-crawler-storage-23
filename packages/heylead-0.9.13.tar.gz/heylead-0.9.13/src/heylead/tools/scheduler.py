"""Tool: scheduler — View scheduler status or toggle on/off.

Thin dispatcher that routes to existing run_* functions based on the action parameter.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


async def run_scheduler(
    action: str = "status",
    enabled: bool = True,
    cloud: bool = False,
) -> str:
    """Manage the autonomous scheduler.

    Actions:
      status — Show scheduler status, pending jobs, and recent activity
      toggle — Enable or disable the scheduler

    Args:
        action: What to do: 'status' or 'toggle'.
        enabled: True to enable, False to disable (for 'toggle').
        cloud: If True, toggle the cloud scheduler for 24/7 operation (for 'toggle').
    """
    action = action.lower().strip()

    if action == "status":
        from .scheduler_status import run_scheduler_status
        return await run_scheduler_status()

    if action == "toggle":
        from .scheduler_status import run_toggle_scheduler
        return await run_toggle_scheduler(enabled=enabled, cloud=cloud)

    return f"Unknown action: '{action}'. Use 'status' or 'toggle'."
