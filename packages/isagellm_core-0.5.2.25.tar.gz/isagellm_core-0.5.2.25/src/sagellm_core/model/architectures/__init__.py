"""Model architecture builders for sageLLM.

This package provides layer-wise model builders that construct models
using custom layers for kernel injection support.

Based on issue #35 - ModelLoader 重构 - 支持逐层模型构建.
"""

from __future__ import annotations

from sagellm_core.model.architectures.base import (
    LayerWiseModelBuilder,
    ModelBuilderRegistry,
    get_model_builder,
    register_model_builder,
)

# Import model builders to trigger registration
from sagellm_core.model.architectures.llama import LlamaModelBuilder  # noqa: F401
from sagellm_core.model.architectures.qwen import QwenModelBuilder  # noqa: F401

__all__ = [
    "LayerWiseModelBuilder",
    "ModelBuilderRegistry",
    "get_model_builder",
    "register_model_builder",
    "LlamaModelBuilder",
    "QwenModelBuilder",
]
