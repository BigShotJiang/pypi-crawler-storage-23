# Test module with mutable state for verifying serialization isolation
