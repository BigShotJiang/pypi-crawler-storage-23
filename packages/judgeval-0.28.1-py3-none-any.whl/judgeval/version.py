__version__ = "0.28.1"


def get_version() -> str:
    return __version__
