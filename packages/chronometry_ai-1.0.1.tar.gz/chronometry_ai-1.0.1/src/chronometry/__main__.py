"""Entry point for python -m chronometry."""

from chronometry.cli import main

main()
