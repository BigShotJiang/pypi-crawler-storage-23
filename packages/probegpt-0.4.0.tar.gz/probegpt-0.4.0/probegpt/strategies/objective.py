from __future__ import annotations

from pydantic_ai import Agent
from pydantic_ai.models import Model

from probegpt.core.models import Probe
from probegpt.data import load_prompt

from .base import AbstractStrategy


def _technique_hint(techniques: list[str]) -> str:
    if not techniques:
        return ""
    tags = ", ".join(techniques)
    return f"WORKING TECHNIQUES (discovered this run — prioritise these):\n  {tags}\n\n"


class ObjectiveStrategy(AbstractStrategy):
    """Generate fresh probes targeting a specific user-defined objective."""

    def __init__(self, targets: list[str]) -> None:
        self._targets = targets
        self._template = load_prompt("strategies/objective")

    def generate(
        self,
        seeds: list[Probe],
        model: Model,
        count: int = 5,
        technique_hints: list[str] | None = None,
        **_: object,
    ) -> list[str]:
        if not self._targets:
            return []
        goal = self._targets[0]
        hint = _technique_hint(technique_hints or [])
        system = self._template.format(count=count, goal=goal, technique_hint=hint)
        agent = Agent(model, system_prompt=system)
        result = agent.run_sync(f"Generate {count} prompts for goal: {goal}")
        return self._parse_candidates(result.output)[:count]

    def get_name(self) -> str:
        return "objective"

    def get_description(self) -> str:
        preview = ", ".join(self._targets[:2])
        suffix = "…" if len(self._targets) > 2 else ""
        return f"Generate fresh probes targeting: {preview}{suffix}"
