from __future__ import annotations

from pydantic_ai import Agent
from pydantic_ai.models import Model

from probegpt.core.models import Probe
from probegpt.data import load_prompt

from .base import AbstractStrategy


def _technique_hint(techniques: list[str]) -> str:
    if not techniques:
        return ""
    tags = ", ".join(techniques)
    return f"WORKING TECHNIQUES (discovered this run — prioritise these):\n  {tags}\n\n"


class LinguisticStrategy(AbstractStrategy):
    """Obfuscate intent using English-language tricks without character encoding."""

    def __init__(self, objective: str) -> None:
        self._objective = objective
        self._template = load_prompt("strategies/linguistic")

    def generate(
        self,
        seeds: list[Probe],
        model: Model,
        count: int = 5,
        technique_hints: list[str] | None = None,
        **_: object,
    ) -> list[str]:
        hint = _technique_hint(technique_hints or [])
        system = self._template.format(count=count, technique_hint=hint)
        agent = Agent(model, system_prompt=system)
        try:
            out = agent.run_sync(
                f"Generate {count} linguistically-obfuscated probes.\nObjective: {self._objective}"
            )
            return self._parse_candidates(out.output)[:count]
        except Exception:
            return []

    def get_name(self) -> str:
        return "linguistic"

    def get_description(self) -> str:
        return "Obfuscate intent via typos, phonetic spelling, logic tricks, double negatives"
