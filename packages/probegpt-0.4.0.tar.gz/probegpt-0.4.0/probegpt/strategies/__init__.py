from probegpt.strategies.distraction import DistractionStrategy
from probegpt.strategies.encoding import EncodingStrategy
from probegpt.strategies.linguistic import LinguisticStrategy
from probegpt.strategies.mutation import MutationStrategy
from probegpt.strategies.objective import ObjectiveStrategy
from probegpt.strategies.persuasion import PersuasionStrategy
from probegpt.strategies.roleplay import RoleplayStrategy
from probegpt.strategies.structural import StructuralStrategy

ALL_STRATEGY_NAMES: list[str] = [
    "objective",
    "mutation",
    "encoding",
    "roleplay",
    "persuasion",
    "linguistic",
    "structural",
    "distraction",
]

__all__ = [
    "ALL_STRATEGY_NAMES",
    "DistractionStrategy",
    "EncodingStrategy",
    "LinguisticStrategy",
    "MutationStrategy",
    "ObjectiveStrategy",
    "PersuasionStrategy",
    "RoleplayStrategy",
    "StructuralStrategy",
]
