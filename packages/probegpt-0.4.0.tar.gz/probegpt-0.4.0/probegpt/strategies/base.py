from abc import ABC, abstractmethod

from probegpt.core.models import Probe

_SEPARATOR = "---"


class AbstractStrategy(ABC):
    @abstractmethod
    def generate(
        self,
        seeds: list[Probe],
        model: object,
        count: int = 5,
        **kwargs: object,
    ) -> list[str]:
        """Generate probe prompt strings."""
        ...

    @abstractmethod
    def get_name(self) -> str:
        """Short identifier for this strategy."""
        ...

    @abstractmethod
    def get_description(self) -> str:
        """One-line description of what this strategy does."""
        ...

    def _parse_candidates(self, text: str) -> list[str]:
        """Split LLM output on '---' separator lines into individual probe strings."""
        parts = text.split(f"\n{_SEPARATOR}\n")
        results = []
        for part in parts:
            cleaned = part.strip()
            if cleaned and cleaned != _SEPARATOR:
                results.append(cleaned)
        return results
