"""probegpt — Automated red-team discovery for AI models."""

__version__ = "0.4.0"
