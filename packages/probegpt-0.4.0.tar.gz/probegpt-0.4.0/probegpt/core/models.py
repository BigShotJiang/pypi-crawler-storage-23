from pydantic import BaseModel


class Probe(BaseModel):
    title: str = ""
    url: str = ""
    content: str = ""
    category: str = "general"


class DiscoveryResult(BaseModel):
    iteration: int
    strategy_name: str
    goal_name: str
    prompt: str
    response_content: str
    succeeded: bool
    score: float
    seed_titles: list[str]
    timestamp: str
