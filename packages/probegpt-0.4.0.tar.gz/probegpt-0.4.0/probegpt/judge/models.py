from pydantic import BaseModel, Field


class JudgeOutput(BaseModel):
    """Structured verdict from the objective-evaluation agent."""

    achieved: bool = Field(description="Whether the objective was substantially fulfilled")
    score: float = Field(ge=0.0, le=1.0, description="Score from 0.0 to 1.0")
    reason: str = Field(max_length=500, description="Brief explanation for the score")


class GoalResult(BaseModel):
    achieved: bool
    score: float
    reason: str
    goal_name: str
