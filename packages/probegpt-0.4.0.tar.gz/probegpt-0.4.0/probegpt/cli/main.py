"""probegpt — CLI entry point."""

from probegpt.cli.app import ProbegptApp


def main() -> None:
    ProbegptApp().run()


if __name__ == "__main__":
    main()
