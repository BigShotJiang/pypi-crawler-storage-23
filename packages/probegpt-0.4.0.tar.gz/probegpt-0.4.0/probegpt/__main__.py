"""Allow running probegpt as a module: python -m probegpt."""

from probegpt.cli.main import main

main()
