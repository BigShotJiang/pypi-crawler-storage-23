"""All tags available in RSM markup."""

from collections import namedtuple
from datetime import datetime
from pathlib import Path

############
# Block tags
############
BlockTagInfo = namedtuple("BlockTagInfo", ["shorthand"])

abstract = BlockTagInfo(None)
"""Manuscript abstract."""
algorithm = BlockTagInfo(None)
"""Algorithm listing."""
appendix = BlockTagInfo(None)
"""Mark where the appendix sections begin."""
author = BlockTagInfo(None)
"""Author information."""
references = BlockTagInfo(None)
"""List of bibliography items."""
codeblock = BlockTagInfo(None)
"""Code listing."""
config = BlockTagInfo(None)
"""Document configuration."""
corollary = BlockTagInfo(None)
"""Corollary."""
definition = BlockTagInfo(None)
"""Definition."""
enumerate = BlockTagInfo(None)  # pylint: disable=redefined-builtin
"""Numbered list."""
example = BlockTagInfo(None)
"""Example."""
figure = BlockTagInfo(None)
"""Figure float."""
html = BlockTagInfo(None)
"""HTML asset."""
itemize = BlockTagInfo(None)
"""Unnumbered list."""
lemma = BlockTagInfo(None)
"""Lemma."""
mathblock = BlockTagInfo(None)
"""Math block (a.k.a. display math)."""
proof = BlockTagInfo(None)
"""Proof of Theorem."""
proposition = BlockTagInfo(None)
"""Proposition."""
remark = BlockTagInfo(None)
"""Remark."""
section = BlockTagInfo(None)
"""Section."""
sketch = BlockTagInfo(None)
"""Proof sketch."""
subsection = BlockTagInfo(None)
"""Subsection."""
subsubsection = BlockTagInfo(None)
"""Sub-subsection."""
theorem = BlockTagInfo(None)
"""Theorem."""
toc = BlockTagInfo(None)
"""Table of Contents"""
video = BlockTagInfo(None)
"""Video asset."""


################
# Paragraph tags
################
ParagraphTagInfo = namedtuple("ParagraphTagInfo", ["x"])

item = ParagraphTagInfo(None)
"""Item in enumerate or itemize."""
caption = ParagraphTagInfo(None)
"""Figure or table caption."""
paragraph = ParagraphTagInfo(None)
"""Generic paragraph.  Use when adding meta tags to a paragraph."""


#############
# Inline tags
#############
InlineTagInfo = namedtuple("InlineTagInfo", ["shorthand"])

code = InlineTagInfo(None)
"""Inline code."""
cite = InlineTagInfo(None)
"""Citation."""
claim = InlineTagInfo(None)
"""Mathematical claim."""
draft = InlineTagInfo(None)
"""A visible comment."""
math = InlineTagInfo(None)
"""Inline math."""
note = InlineTagInfo(None)
"""Footnote."""
ref = InlineTagInfo(None)
"""Link to internal label."""
span = InlineTagInfo(None)
"""Text span."""
url = InlineTagInfo(None)
"""Link to external URL."""


###########
# Meta tags
###########


MetaTagInfo = namedtuple("MetaTagInfo", ["parent", "type"])

accent = MetaTagInfo(None, str)
"""Accent color for the manuscript (blue, red, green, orange, yellow, purple, pink, gray)."""
lang = MetaTagInfo(None, str)
"""Language code for the manuscript (e.g., en, es, fr, de, en-US)."""
typography = MetaTagInfo(None, str)
"""Typography style for the manuscript (sans-serif, serif)."""
affiliation = MetaTagInfo(None, datetime)
"""Author institutional affiliation."""
author_display_first = MetaTagInfo(None, int)
"""Number of authors to display at start when >5 authors."""
author_display_last = MetaTagInfo(None, int)
"""Number of authors to display at end when >5 authors."""
author_note = MetaTagInfo(None, str)
"""Author note (e.g., 'Equal contribution')."""
email = MetaTagInfo(None, str)
"""Author email."""
emphas = MetaTagInfo(None, bool)
"""Whether span is emphasized."""
goal = MetaTagInfo(None, "?")
"""Theorem goal."""
icon = MetaTagInfo(None, list)
"""Icon assigned to the block."""
isclaim = MetaTagInfo(None, bool)
"""Whether a math block is a claim."""
keywords = MetaTagInfo(None, list)
"""Abstract keywords."""
label = MetaTagInfo(None, str)
"""Tag label."""
lang = MetaTagInfo(None, str)
"""Specify language in code and code blocks."""
msc = MetaTagInfo(None, list)
"""Mathematics Subject Classification."""
name = MetaTagInfo(None, str)
"""Author name."""
nonum = MetaTagInfo(None, bool)
"""Whether to number the tag."""
numbering = MetaTagInfo(None, str)
"""Numbering mode for theorems and sections (document, section, or none)."""
orcid = MetaTagInfo(None, str)
"""Author ORCID identifier."""
override_date = MetaTagInfo(None, datetime)
"""Override manuscript date via config block."""
alt = MetaTagInfo(None, str)
"""Alt text for figure images."""
dark = MetaTagInfo(None, Path)
"""Path to alternate figure image rendered in dark mode."""
path = MetaTagInfo(None, Path)
"""Figure path."""
reftext = MetaTagInfo(None, str)
"""Label reftext."""
scale = MetaTagInfo(None, str)
"""Figure scale."""
static = MetaTagInfo(None, Path)
"""Path to alternate figure for static/PDF export."""
strong = MetaTagInfo(None, bool)
"""Whether span is strong."""
theme = MetaTagInfo(None, str)
"""Manuscript theme."""
title = MetaTagInfo(None, str)
"""Manuscript or section title."""
toc_depth = MetaTagInfo(None, int)
"""Table of contents depth."""
class_ = MetaTagInfo(None, list)
"""CSS classes for this tag."""


###########
# Math tags
###########
MathTagInfo = namedtuple("MathTagInfo", ["shorthand"])

assume = MathTagInfo(None)
"""Introduce an assumption."""
case = MathTagInfo(None)
"""Prove special case of the goal."""
define = MathTagInfo(None)
"""Introduce a variable and assumption."""
exercise = MathTagInfo(None)
"""Introduce an exercise."""
let = MathTagInfo(None)
"""Introduce a variable and assumption."""
new = MathTagInfo(None)
"""Introduce a variable and assumption."""
p = MathTagInfo(None)
"""Sub-proof."""
pick = MathTagInfo(None)
"""Introduce a variable with a specific property (see 'st')."""
porism = MathTagInfo(None)
"""Corollary of a proof."""
prev = MathTagInfo(None)
"""Reference the previous step."""
prev2 = MathTagInfo(None)
"""Reference the step before last."""
prev3 = MathTagInfo(None)
"""Reference the step two steps before."""
previous = MathTagInfo(None)
"""Reference the previous step."""
problem = MathTagInfo(None)
"""Introduce a problem."""
prove = MathTagInfo(None)
"""Set goal."""
qed = MathTagInfo(None)
"""State the goal is proven."""
st = MathTagInfo(None)
"""'Such that', part of 'pick'."""
step = MathTagInfo(None)
"""Proof step."""
suffices = MathTagInfo(None)
"""Change goal."""
suppose = MathTagInfo(None)
"""Introduce an assumption."""
then = MathTagInfo(None)
"""State a claim under an assumption."""
wlog = MathTagInfo(None)
"""Without loss of generality (introduce an assupmtion)."""
write = MathTagInfo(None)
"""Introduce a symbol."""


############
# Table tags
############
TableTagInfo = namedtuple("TableTagInfo", ["shorthand"])

table = TableTagInfo(None)
"""Table."""
tbody = TableTagInfo(None)
"""Table body."""
td = TableTagInfo(None)
"""Table datum."""
thead = TableTagInfo(None)
"""Table head."""
tr = TableTagInfo(None)
"""Table row."""
