# Memory Implementation Guide

This document describes how to add memory to the NL2SQL multi-agent system, broken into five self-contained steps ordered by impact.

---

## Table of Contents

1. [Short-Term Conversational Memory](#1-short-term-conversational-memory)
2. [Cross-Session Persistence](#2-cross-session-persistence)
3. [Per-User Thread Identity](#3-per-user--per-thread-identity)
4. [Long-Term User Profile Store](#4-long-term-user-profile-store)
5. [Coreference Resolution Node](#5-coreference-resolution-node)

---

## 1. Short-Term Conversational Memory

Allows the user to ask follow-up questions like *"now filter by date"* without repeating context. History is passed into the LLM prompt on every turn.

### 1.1 — `nl2sql_agents/models/schemas.py` — Add `chat_history` to `GraphState`

```python
# nl2sql_agents/models/schemas.py

from __future__ import annotations
import operator
from pydantic import BaseModel, Field
from typing import Optional, Annotated
from typing_extensions import TypedDict

# ... all existing models stay unchanged ...

class ChatMessage(TypedDict):
    role: str    # "user" | "assistant"
    content: str

class GraphState(TypedDict, total=False):
    user_query: str
    tables: list[TableMetaData]

    # ── NEW ──────────────────────────────────────────────
    chat_history: list[ChatMessage]          # grows across turns
    # ─────────────────────────────────────────────────────

    # written by security_filter and discovery node (parallel branches)
    security_passed: Annotated[set[str], operator.or_]
    discovery_result: DiscoveryResult

    # gate onwards
    gated_tables: list[TableMetaData]
    formatted_schema: FormattedSchema
    generation: GenerationResult
    validation: ValidationResult
    retry_context: Optional[str]
    attempt: int
    output: FinalOutput
```

### 1.2 — `nl2sql_agents/agents/query_generator.py` — Inject history into the prompt

```python
# nl2sql_agents/agents/query_generator.py

SYSTEM_PROMPT = """You are an expert SQL developer.
Given a database schema and a natural language question, write a single SQL SELECT query that answers the question.
Rules:
- Output ONLY the SQL query, no explanation.
- Use standard SQL syntax compatible with the target database.
- Only SELECT — no INSERT, UPDATE, DELETE, DROP, or DDL.
- Use table aliases for readability.
- Handle NULLs appropriately."""

class QueryGeneratorAgent(BaseAgent):
    def build_prompt(
        self,
        schema: FormattedSchema,
        user_query: str,
        prompt_varient: str = PROMPT_VARIENT[0],
        retry_content: str | None = None,
        chat_history: list[dict] | None = None,   # ── NEW ──
        **_,
    ) -> list[dict[str, str]]:

        messages: list[dict[str, str]] = [
            {"role": "system", "content": SYSTEM_PROMPT},
        ]

        # ── NEW: inject prior turns so the LLM has context ──
        if chat_history:
            for turn in chat_history[-6:]:   # keep last 6 turns to stay within token budget
                messages.append({"role": turn["role"], "content": turn["content"]})
        # ─────────────────────────────────────────────────────

        user_content = (
            f"Schema: \n{schema.content}\n\n"
            f"{prompt_varient}\n{user_query}"
        )
        if retry_content:
            user_content += f"\n\nPrevious attempt failed. Fix these: \n{retry_content}"

        messages.append({"role": "user", "content": user_content})
        return messages
```

### 1.3 — `nl2sql_agents/orchestrator/nodes.py` — Forward `chat_history` to the generator

```python
# nl2sql_agents/orchestrator/nodes.py  (inside generate_sql_node)

async def generate_sql_node(state: GraphState) -> dict:
    """PARALLEL: Generates N SQL Candidates in parallel."""
    logger.info("Generation Attempt: %d of %d", state['attempt'], MAX_RETRIES)

    generation = await generator_agent.generate(
        state['formatted_schema'],
        state['user_query'],
        retry_context=state.get('retry_context'),
        chat_history=state.get('chat_history', []),   # ── NEW ──
    )

    return {'generation': generation}
```

Also pass `chat_history` down into `QueryGeneratorAgent.generate()` and `_generator_one()`:

```python
# nl2sql_agents/agents/query_generator.py

async def generate(
    self,
    schema: FormattedSchema,
    user_query: str,
    n_candidates: int = N_CANDIDATES,
    retry_context: str | None = None,
    chat_history: list[dict] | None = None,   # ── NEW ──
) -> GenerationResult:
    temps = CANDIDATE_TEMPERATURES[:n_candidates]
    varients = PROMPT_VARIENT[:n_candidates]

    candidates = await asyncio.gather(
        *[
            self._generator_one(schema, user_query, t, v, retry_context, chat_history)
            for t, v in zip(temps, varients)
        ]
    )
    return GenerationResult(candidates=list(candidates))

async def _generator_one(
    self,
    schema: FormattedSchema,
    user_query: str,
    temperature: float,
    prompt_varient: str,
    retry_context: str | None,
    chat_history: list[dict] | None = None,   # ── NEW ──
) -> SQLCandidate:
    messages = self.build_prompt(
        schema=schema,
        user_query=user_query,
        prompt_varient=prompt_varient,
        retry_content=retry_context,
        chat_history=chat_history,            # ── NEW ──
    )
    raw = await self.call_llm(messages=messages, temperature=temperature)
    sql = self.parse_response(raw)
    ...
```

### 1.4 — `nl2sql_agents/orchestrator/nodes.py` — Append to history in `explain_node`

After the pipeline completes, record the turn so the next invocation can use it.

```python
# nl2sql_agents/orchestrator/nodes.py  (inside explain_node — at the end, before returning)

async def explain_node(state: GraphState) -> dict:
    # ... existing explainer logic ...

    output = FinalOutput(
        sql=best_sql,
        explanation=explainer_output.explanation,
        safety_report=explainer_output.safety_report,
        optimization_hints=explainer_output.optimization_hints,
        candidate_scores=state['validation'].all_results,
    )

    # ── NEW: record the completed turn in chat_history ──
    history = list(state.get('chat_history') or [])
    history.append({"role": "user",      "content": state['user_query']})
    history.append({"role": "assistant", "content": best_sql})
    # ─────────────────────────────────────────────────────

    return {
        "output": output,
        "chat_history": history,   # ── NEW ──
    }
```

---

## 2. Cross-Session Persistence

`MemorySaver` was already imported but never wired in, and it only lives in RAM. Replace it with `SqliteSaver` so history survives restarts.

### 2.1 — Install the dependency

```bash
pip install langgraph-checkpoint-sqlite
```

### 2.2 — `nl2sql_agents/config/settings.py` — Add `MEMORY_DB_PATH`

```python
# nl2sql_agents/config/settings.py  (add near the bottom)

import pathlib

# Memory / Checkpointing
MEMORY_DB_PATH: str = os.getenv(
    "MEMORY_DB_PATH",
    str(pathlib.Path(__file__).parent.parent / "cache" / "memory.sqlite"),
)
```

### 2.3 — `nl2sql_agents/orchestrator/pipeline.py` — Wire `SqliteSaver`

```python
# nl2sql_agents/orchestrator/pipeline.py

from models.schemas import GraphState
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver   # ── CHANGED ──
from config.settings import MEMORY_DB_PATH                     # ── NEW ──

from .nodes import (
    gate_node, load_schema, explain_node, should_retry,
    validate_node, discovery_node, format_schema_node,
    generate_sql_node, security_filter_node,
)

def build_graph() -> StateGraph:
    builder = StateGraph(GraphState)

    # nodes
    builder.add_node("load_schema",      load_schema)
    builder.add_node("security_filter",  security_filter_node)
    builder.add_node("discovery",        discovery_node)
    builder.add_node("gate",             gate_node)
    builder.add_node("format_schema",    format_schema_node)
    builder.add_node("generate_sql",     generate_sql_node)
    builder.add_node("validate",         validate_node)
    builder.add_node("explain",          explain_node)

    # edges (unchanged)
    builder.set_entry_point('load_schema')
    builder.add_edge("load_schema",     'security_filter')
    builder.add_edge("load_schema",     'discovery')
    builder.add_edge("security_filter", "gate")
    builder.add_edge("discovery",       "gate")
    builder.add_edge("gate",            'format_schema')
    builder.add_edge("format_schema",   'generate_sql')
    builder.add_edge("generate_sql",    'validate')
    builder.add_conditional_edges("validate", should_retry, {
        'generate_sql': "generate_sql",
        "explain":      "explain"
    })
    builder.add_edge("explain", END)

    # ── NEW: persistent SQLite checkpointer ──
    memory = AsyncSqliteSaver.from_conn_string(MEMORY_DB_PATH)
    return builder.compile(checkpointer=memory)
    # ─────────────────────────────────────────

graph = build_graph()
```

> **Note:** `AsyncSqliteSaver` is async-context-aware. If you need a synchronous fallback for testing, use `SqliteSaver` from `langgraph.checkpoint.sqlite` instead.

---

## 3. Per-User / Per-Thread Identity

The `thread_id` in `main.py` is hardcoded to `'user'`. Every user (or session) must get their own thread so their histories don't bleed into each other.

### 3.1 — `main.py` — Derive or load `thread_id`

```python
# main.py

import uuid
import pathlib

SESSION_FILE = pathlib.Path.home() / ".nl2sql_session"

def get_thread_id() -> str:
    """Load an existing session ID or create a new one."""
    if SESSION_FILE.exists():
        tid = SESSION_FILE.read_text().strip()
        if tid:
            return tid
    tid = str(uuid.uuid4())
    SESSION_FILE.write_text(tid)
    return tid

# Replace the hardcoded config with:
config = {"configurable": {"thread_id": get_thread_id()}}
```

### 3.2 — CLI flag to start a fresh session

```python
# main.py  (inside main())

async def main() -> None:
    global config

    if "--new-session" in sys.argv:
        sys.argv.remove("--new-session")
        new_tid = str(uuid.uuid4())
        SESSION_FILE.write_text(new_tid)
        config = {"configurable": {"thread_id": new_tid}}
        print(f"Started new session: {new_tid}\n")

    # ... rest of existing main() logic unchanged ...
```

Usage:

```bash
python main.py --new-session          # fresh history
python main.py "Who are the top customers?"
```

---

## 4. Long-Term User Profile Store

Stores facts about the user that persist across many sessions: frequently queried tables, preferred database, etc. Uses LangGraph's `InMemoryStore` (swap for a Redis/Postgres-backed store for production).

### 4.1 — `memory/user_profile.py` — New module

Create the file `memory/user_profile.py`:

```python
# memory/user_profile.py

import json
import pathlib
import logging
from typing import Any

logger = logging.getLogger(__name__)

PROFILE_DIR = pathlib.Path(__file__).parent.parent / "cache" / "profiles"
PROFILE_DIR.mkdir(parents=True, exist_ok=True)


class UserProfileStore:
    """Persistent per-user JSON profile."""

    def __init__(self, thread_id: str) -> None:
        self._path = PROFILE_DIR / f"{thread_id}.json"
        self._data: dict[str, Any] = self._load()

    def _load(self) -> dict[str, Any]:
        if self._path.exists():
            try:
                return json.loads(self._path.read_text())
            except json.JSONDecodeError:
                logger.warning("Corrupt profile at %s — resetting.", self._path)
        return {"frequent_tables": {}, "last_db": None, "query_count": 0}

    def _save(self) -> None:
        self._path.write_text(json.dumps(self._data, indent=2))

    # --- public API ---

    def record_query(self, tables_used: list[str]) -> None:
        self._data["query_count"] = self._data.get("query_count", 0) + 1
        freq = self._data.setdefault("frequent_tables", {})
        for t in tables_used:
            freq[t] = freq.get(t, 0) + 1
        self._save()

    def top_tables(self, n: int = 5) -> list[str]:
        freq = self._data.get("frequent_tables", {})
        return sorted(freq, key=lambda t: freq[t], reverse=True)[:n]

    def set_last_db(self, db_path: str) -> None:
        self._data["last_db"] = db_path
        self._save()

    def get_last_db(self) -> str | None:
        return self._data.get("last_db")

    @property
    def query_count(self) -> int:
        return self._data.get("query_count", 0)
```

Also create `memory/__init__.py`:

```python
# memory/__init__.py
from .user_profile import UserProfileStore

__all__ = ["UserProfileStore"]
```

### 4.2 — `nl2sql_agents/orchestrator/nodes.py` — Record tables after gate, update profile

```python
# nl2sql_agents/orchestrator/nodes.py  (top-level imports / initialisation)

from memory.user_profile import UserProfileStore

# profile is keyed by thread_id — resolved at runtime
_profiles: dict[str, UserProfileStore] = {}

def _get_profile(state: GraphState) -> UserProfileStore:
    tid = state.get("thread_id", "default")
    if tid not in _profiles:
        _profiles[tid] = UserProfileStore(tid)
    return _profiles[tid]
```

```python
# nl2sql_agents/orchestrator/nodes.py  (inside explain_node, after building FinalOutput)

profile = _get_profile(state)
profile.record_query([t.table_name for t in state.get('gated_tables', [])])
```

### 4.3 — `nl2sql_agents/models/schemas.py` — Add `thread_id` to `GraphState`

```python
class GraphState(TypedDict, total=False):
    user_query: str
    thread_id: str            # ── NEW ──
    chat_history: list[ChatMessage]
    tables: list[TableMetaData]
    ...
```

### 4.4 — `main.py` — Pass `thread_id` into the initial state

```python
async def run_query(query: str) -> None:
    tid = config["configurable"]["thread_id"]
    final_state = await graph.ainvoke(
        {"user_query": query, "thread_id": tid},   # ── thread_id added ──
        config,
    )
    print_output(final_state["output"])
```

---

## 5. Coreference Resolution Node

Resolves pronouns and elliptic references before the pipeline runs.

- *"now filter by date"* → *"Show all orders placed last month, filtered by order_date"*
- *"show those customers"* → *"Show customers who bought product X"*

### 5.1 — `nl2sql_agents/agents/resolver.py` — New agent

```python
# nl2sql_agents/agents/resolver.py

import logging
from agents.base_agent import BaseAgent
from models.schemas import ChatMessage

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are a query disambiguation assistant.
Given a conversation history and a new user question, rewrite the question as a
fully self-contained, unambiguous natural language query that does not rely on
pronouns or references to prior turns.

Rules:
- If the question is already self-contained, return it unchanged.
- Output ONLY the rewritten question. No explanations."""


class QueryResolverAgent(BaseAgent):
    def build_prompt(
        self,
        user_query: str,
        chat_history: list[ChatMessage] | None = None,
    ) -> list[dict[str, str]]:
        messages: list[dict[str, str]] = [
            {"role": "system", "content": SYSTEM_PROMPT},
        ]
        if chat_history:
            for turn in chat_history[-6:]:
                messages.append({"role": turn["role"], "content": turn["content"]})
        messages.append({"role": "user", "content": f"New question: {user_query}"})
        return messages

    def parse_response(self, raw: str) -> str:
        return raw.strip()

    async def resolve(
        self,
        user_query: str,
        chat_history: list[ChatMessage] | None = None,
    ) -> str:
        """Return a disambiguated, self-contained version of user_query."""
        if not chat_history:
            return user_query   # nothing to resolve
        messages = self.build_prompt(user_query, chat_history)
        resolved = await self.call_llm(messages=messages, temperature=0.0)
        result = self.parse_response(resolved)
        logger.info("QueryResolver: '%s' → '%s'", user_query, result)
        return result
```

### 5.2 — `nl2sql_agents/orchestrator/nodes.py` — Add `resolve_query_node`

```python
# nl2sql_agents/orchestrator/nodes.py

from agents.resolver import QueryResolverAgent

resolver_agent = QueryResolverAgent()

async def resolve_query_node(state: GraphState) -> dict:
    """Rewrite the user query to be self-contained using chat history."""
    resolved = await resolver_agent.resolve(
        state['user_query'],
        chat_history=state.get('chat_history'),
    )
    return {"user_query": resolved}
```

### 5.3 — `nl2sql_agents/orchestrator/pipeline.py` — Insert the node before `load_schema`

```python
# nl2sql_agents/orchestrator/pipeline.py

from .nodes import resolve_query_node   # ── NEW ──

def build_graph() -> StateGraph:
    builder = StateGraph(GraphState)

    # nodes
    builder.add_node("resolve_query",    resolve_query_node)   # ── NEW ──
    builder.add_node("load_schema",      load_schema)
    builder.add_node("security_filter",  security_filter_node)
    builder.add_node("discovery",        discovery_node)
    builder.add_node("gate",             gate_node)
    builder.add_node("format_schema",    format_schema_node)
    builder.add_node("generate_sql",     generate_sql_node)
    builder.add_node("validate",         validate_node)
    builder.add_node("explain",          explain_node)

    # edges
    builder.set_entry_point('resolve_query')                   # ── CHANGED ──
    builder.add_edge("resolve_query",   'load_schema')         # ── NEW ──

    builder.add_edge("load_schema",     'security_filter')
    builder.add_edge("load_schema",     'discovery')
    builder.add_edge("security_filter", "gate")
    builder.add_edge("discovery",       "gate")
    builder.add_edge("gate",            'format_schema')
    builder.add_edge("format_schema",   'generate_sql')
    builder.add_edge("generate_sql",    'validate')
    builder.add_conditional_edges("validate", should_retry, {
        'generate_sql': "generate_sql",
        "explain":      "explain"
    })
    builder.add_edge("explain", END)

    memory = AsyncSqliteSaver.from_conn_string(MEMORY_DB_PATH)
    return builder.compile(checkpointer=memory)

graph = build_graph()
```

---

## Final Pipeline Flow (with all memory features)

```
User Input
    │
    ▼
resolve_query          ← rewrites ambiguous queries using chat_history
    │
    ▼
load_schema            ← DB introspection / cache
    ├──────────────────────────────────┐
    ▼                                  ▼
security_filter                    discovery          ← uses chat_history for table bias (optional)
    │                                  │
    └──────────┬───────────────────────┘
               ▼
             gate
               │
               ▼
         format_schema
               │
               ▼
         generate_sql   ← receives chat_history, injects last N turns into prompt
               │
               ▼
           validate ──(retry)──► generate_sql
               │
               ▼
            explain     ← appends turn to chat_history, records tables in UserProfileStore
               │
               ▼
             END

LangGraph SqliteSaver snapshots GraphState (including chat_history) after every node.
```

---

## Required pip installs

```bash
pip install langgraph-checkpoint-sqlite
```

All other dependencies (`langgraph`, `langchain-openai`) are already in `requirements.txt`.
