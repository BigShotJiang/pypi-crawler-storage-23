# anafibre.dispersion

::: anafibre.dispersion
