Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/yotoplayer_simpletest.py
    :caption: examples/yotoplayer_simpletest.py
    :linenos:
