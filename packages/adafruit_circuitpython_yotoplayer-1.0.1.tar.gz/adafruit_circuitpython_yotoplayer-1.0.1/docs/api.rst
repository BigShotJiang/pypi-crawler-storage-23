
.. If you created a package, create one automodule per module in the package.

.. If your library file(s) are nested in a directory (e.g. /adafruit_foo/foo.py)
.. use this format as the module name: "adafruit_foo.foo"

API Reference
#############

.. automodule:: adafruit_yoto.cr95hf
    :members:

.. automodule:: adafruit_yoto.es8156
    :members:

.. automodule:: adafruit_yoto.graphics
    :members:

.. automodule:: adafruit_yoto.network
    :members:

.. automodule:: adafruit_yoto.peripherals
    :members:

.. automodule:: adafruit_yoto.sgm41513
    :members:

.. automodule:: adafruit_yoto.yoto
    :members:
