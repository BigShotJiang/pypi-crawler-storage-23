from django.apps import AppConfig


class OIDCProviderConfig(AppConfig):
    name = "hidp.oidc_provider"
    label = "hidp_oidc_provider"
