# Hello, ID Please

"Hello, ID Please" (HIdP) is a Django application that offers a
full-featured authentication system for Django projects. It is designed with
the OWASP best practices in mind and offers a secure and flexible solution for
registering and authenticating users in Django projects.

Please read the full documentation on https://leukeleu.github.io/django-hidp/
