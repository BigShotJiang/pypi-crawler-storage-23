#!/bin/bash
# Generate API docs
echo "Generating API docs..."
cd docs
make html