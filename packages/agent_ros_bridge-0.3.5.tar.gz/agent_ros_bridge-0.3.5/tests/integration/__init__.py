"""Integration tests for Agent ROS Bridge"""
