"""Tests for Agent ROS Bridge"""
