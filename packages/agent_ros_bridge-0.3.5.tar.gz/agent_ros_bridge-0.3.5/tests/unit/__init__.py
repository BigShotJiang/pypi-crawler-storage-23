"""Unit tests for Agent ROS Bridge"""
