# WSL2 Setup Guide

## GUI Support
Install VcXsrv on Windows for X11 forwarding.

## USB Passthrough
Use `usbipd` to attach USB devices to WSL2.