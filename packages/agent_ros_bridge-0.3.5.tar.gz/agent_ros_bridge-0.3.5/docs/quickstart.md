# Quick Start Guide

## Installation
1. Clone the repository
2. Run `./scripts/build.sh`
3. Run `./scripts/run_demo.sh --greenhouse --mock`

## Configuration
Edit config files in `config/` directory to customize settings.