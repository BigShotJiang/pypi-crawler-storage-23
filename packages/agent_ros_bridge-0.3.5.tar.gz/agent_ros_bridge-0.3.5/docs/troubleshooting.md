# Troubleshooting Guide

## Common Issues

### ROS not found
Make sure ROS is installed and sourced before running.

### Permission denied
Run with `sudo` for hardware access or use `--mock` mode for testing.