# Embedded Deployment Guide

## Jetson
Run `./scripts/deploy_jetson.sh` for automated deployment.

## Raspberry Pi
Run `./scripts/deploy_rpi.sh` for automated deployment.