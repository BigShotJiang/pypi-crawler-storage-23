"""GangDan - Offline Development Assistant powered by Ollama and ChromaDB."""

__version__ = "1.0.2"
