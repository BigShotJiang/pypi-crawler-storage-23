﻿from setuptools import setup, find_packages
from pathlib import Path

long_description = Path("README.md").read_text(encoding="utf-8")

setup(
    name='lcsb-icommands',
    version='2.0.3',
    description='iRODS client for automatic data ingestion via OAuth2/Keycloak',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Sandesh Patil',
    author_email='sandesh.patil@uni.lu',
    url='https://gitlab.com/uniluxembourg/lcsb/BioCore/RDMS/irods/lcsb-icai',
    license='MIT',
    packages=find_packages(),
    py_modules=['lcsb_icommands'],
    package_dir={'': 'client'},
    install_requires=[
        'requests>=2.31.0',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Topic :: Scientific/Engineering :: Bio-Informatics',
        'Topic :: System :: Filesystems',
        'Intended Audience :: Science/Research',
    ],
    entry_points={
        'console_scripts': [
            # interactive shell
            'icai=lcsb_icommands:cmd_icai',
            # icommand-compatible wrappers
            'iinit=lcsb_icommands:cmd_iinit',
            'ils=lcsb_icommands:cmd_ils',
            'iput=lcsb_icommands:cmd_iput',
            'iget=lcsb_icommands:cmd_iget',
            'imkdir=lcsb_icommands:cmd_imkdir',
            'irdm=lcsb_icommands:cmd_irdm',
            'ipwd=lcsb_icommands:cmd_ipwd',
            'imeta=lcsb_icommands:cmd_imeta',
            'icd=lcsb_icommands:cmd_icd',
            'imv=lcsb_icommands:cmd_imv',
            'icp=lcsb_icommands:cmd_icp',
            'ichmod=lcsb_icommands:cmd_ichmod',
            'ichksum=lcsb_icommands:cmd_ichksum',
            'itree=lcsb_icommands:cmd_itree',
            'ienv=lcsb_icommands:cmd_ienv',
            'ihelp=lcsb_icommands:cmd_ihelp',
        ],
    },
    python_requires='>=3.8',
)