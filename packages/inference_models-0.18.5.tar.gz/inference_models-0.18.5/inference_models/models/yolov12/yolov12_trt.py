from inference_models.models.yolov8.yolov8_object_detection_trt import (
    YOLOv8ForObjectDetectionTRT,
)


class YOLOv12ForObjectDetectionTRT(YOLOv8ForObjectDetectionTRT):
    pass
