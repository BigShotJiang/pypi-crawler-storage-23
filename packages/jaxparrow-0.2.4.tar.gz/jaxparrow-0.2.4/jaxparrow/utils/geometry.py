import jax
import jax.numpy as jnp
from jaxtyping import Float

from .operators import interpolation


#: Approximate earth angular speed
EARTH_ANG_SPEED = 7.292115e-5
#: Approximate earth radius
EARTH_RADIUS = 6370e3
#: Approximate gravity
GRAVITY = 9.81
#: Degrees / radians conversion factor
P0 = jnp.pi / 180


def compute_spatial_step(
    lat: Float[jax.Array, "lat lon"],
    lon: Float[jax.Array, "lat lon"]
) -> [Float[jax.Array, "lat lon"], Float[jax.Array, "lat lon"]]:
    """
    Computes the spatial steps of a grid (in meters) along `x` and `y`.

    It makes use of the distance-on-a-sphere formula with Taylor expansion approximations of `cos` and `arccos`
    functions to avoid truncation issues.

    Parameters
    ----------
    lat : Float[jax.Array, "lat lon"]
        Latitude grid
    lon : Float[jax.Array, "lat lon"]
        Longitude grid

    Returns
    -------
    dx : Float[jax.Array, "lat lon"]
        Spatial steps in meters along `x`
    dy : Float[jax.Array, "lat lon"]
        Spatial steps in meters along `y`
    """
    def haversine_distance(lat1, lat2, lon1, lon2):
        # convert to radians
        lat1_rad = jnp.radians(lat1)
        lat2_rad = jnp.radians(lat2)

        # difference in radians; normalize lon diff to [-180, 180] before radians to handle dateline
        dlon = lon2 - lon1
        dlon = (dlon + 180.0) % 360.0 - 180.0   # now in [-180,180]
        dlon_rad = jnp.radians(dlon)

        dlat_rad = jnp.radians(lat2 - lat1)

        a = jnp.sin(dlat_rad / 2.0) ** 2 + jnp.cos(lat1_rad) * jnp.cos(lat2_rad) * (jnp.sin(dlon_rad / 2.0) ** 2)
        c = 2.0 * jnp.arctan2(jnp.sqrt(a), jnp.sqrt(1.0 - a))
        d = EARTH_RADIUS * c
        return d
    
    dx, dy = jnp.zeros_like(lat), jnp.zeros_like(lat)
    # dx
    dx = dx.at[:, :-1].set(haversine_distance(lat[:, :-1], lat[:, 1:], lon[:, :-1], lon[:, 1:]))
    dx = dx.at[:, -1].set(dx[:, -2])
    # dy
    dy = dy.at[:-1, :].set(haversine_distance(lat[:-1, :], lat[1:, :], lon[:-1, :], lon[1:, :]))
    dy = dy.at[-1, :].set(dy[-2, :])

    return dx, dy


def compute_coriolis_factor(
    lat: Float[jax.Array, "lat lon"]
) -> Float[jax.Array, "lat lon"]:
    """
    Computes the Coriolis factor from a latitude grid.

    Parameters
    ----------
    lat : Float[jax.Array, "lat lon"]
        Latitudes grid

    Returns
    -------
    cf : Float[jax.Array, "lat lon"]
        Coriolis factor grid
    """
    return 2 * EARTH_ANG_SPEED * jnp.sin(lat * P0)


def compute_uv_grids(
    lat_t: Float[jax.Array, "lat lon"],
    lon_t: Float[jax.Array, "lat lon"]
) -> [
    Float[jax.Array, "lat lon"], Float[jax.Array, "lat lon"], Float[jax.Array, "lat lon"], Float[jax.Array, "lat lon"]
]:
    """
    Computes the U and V grids associated to a T grid following NEMO convention.

    Parameters
    ----------
    lat_t : Float[jax.Array, "lat lon"]
        Latitudes of the T grid
    lon_t : Float[jax.Array, "lat lon"]
        Longitudes of the T grid

    Returns
    -------
    lat_u : Float[jax.Array, "lat lon"]
        Latitudes of the U grid
    lon_u : Float[jax.Array, "lat lon"]
        Longitudes of the U grid
    lat_v : Float[jax.Array, "lat lon"]
        Latitudes of the V grid
    lon_v : Float[jax.Array, "lat lon"]
        Longitudes of the V grid
    """
    lat_mask = jnp.zeros_like(lat_t, dtype=bool)
    lon_mask = jnp.zeros_like(lon_t, dtype=bool)

    lat_u = interpolation(lat_t, lat_mask, axis=1, padding="right")
    lat_u = lat_u.at[:, -1].set(2 * lat_t[:, -1] - lat_t[:, -2])
    lon_u = interpolation(lon_t, lon_mask, axis=1, padding="right")
    lon_u = lon_u.at[:, -1].set(2 * lon_t[:, -1] - lon_t[:, -2])

    lat_v = interpolation(lat_t, lat_mask, axis=0, padding="right")
    lat_v = lat_v.at[-1, :].set(2 * lat_t[-1, :] - lat_t[-2, :])
    lon_v = interpolation(lon_t, lon_mask, axis=0, padding="right")
    lon_v = lon_v.at[-1, :].set(2 * lon_t[-1, :] - lon_t[-2, :])

    return lat_u, lon_u, lat_v, lon_v
