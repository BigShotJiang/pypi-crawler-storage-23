"""Local scheduler for testing and development."""

from hpc_runner.schedulers.local.scheduler import LocalScheduler

__all__ = ["LocalScheduler"]
