"""Data providers for HPC Monitor TUI."""

from .jobs import JobProvider

__all__ = ["JobProvider"]
