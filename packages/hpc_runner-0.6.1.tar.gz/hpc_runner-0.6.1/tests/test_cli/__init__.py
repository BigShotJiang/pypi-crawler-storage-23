"""Tests for CLI."""
