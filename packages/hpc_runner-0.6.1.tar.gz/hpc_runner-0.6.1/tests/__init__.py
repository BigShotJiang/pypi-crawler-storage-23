"""Tests for hpc-runner."""
