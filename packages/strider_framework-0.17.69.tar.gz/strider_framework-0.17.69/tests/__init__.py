"""Testes do Stride."""
