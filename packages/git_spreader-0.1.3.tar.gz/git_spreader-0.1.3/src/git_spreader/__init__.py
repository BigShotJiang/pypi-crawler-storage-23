"""git-spreader: Redistribute git commit timestamps across a realistic working schedule."""

from importlib.metadata import version

__version__ = version("git-spreader")
