"""SmartMemory Claude Code plugin — zero-infra persistent memory."""

__version__ = "0.1.0"
