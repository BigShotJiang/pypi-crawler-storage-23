---
inclusion: fileMatch
fileMatchPattern: "synth/cli/*"
---

# CLI Development

Rules for implementing and modifying CLI commands in `synth/cli/`.

## Architecture

- `main.py` — CLI entry point using `click`. Defines the top-level `synth` group and
  registers all subcommands. The `pyproject.toml` entry point is `synth = "synth.cli.main:cli"`.
- Each subcommand lives in its own module: `dev.py`, `run_cmd.py`, `eval_cmd.py`,
  `trace_cmd.py`, `deploy_cmd.py`, `doctor.py`.
- `banner.py` — boot sequence / terminal branding. Isolated from command logic.

## Click Conventions

- Use `@click.group()` for the top-level `cli` and `@cli.command()` for subcommands.
- Use `click.argument()` for positional args (e.g., file path, prompt text).
- Use `click.option()` for flags and named parameters (e.g., `--dataset`, `--target`,
  `--dry-run`).
- Print user-facing output with `click.echo()`, not `print()`.
- Use `click.style()` for colored output. Respect `NO_COLOR` env var.
- Exit with `sys.exit(1)` or `raise SystemExit(1)` on failure. `synth eval` MUST exit
  non-zero if the pass rate falls below the configured threshold.

## Command Reference

| Command | Module | Description |
|---------|--------|-------------|
| `synth dev <file>` | `dev.py` | REPL with hot-reload + trace UI in browser |
| `synth run <file> "prompt"` | `run_cmd.py` | Execute agent, print RunResult + trace summary |
| `synth eval <file> --dataset <json>` | `eval_cmd.py` | Run evaluation suite, print report |
| `synth trace <run_id>` | `trace_cmd.py` | Open stored trace in browser viewer |
| `synth deploy --target agentcore` | `deploy_cmd.py` | Package and deploy to AgentCore |
| `synth doctor` | `doctor.py` | Check env vars, credentials, dependency versions |

## Banner / Boot Sequence Rules

The boot sequence in `banner.py` uses a state machine. Follow these rules strictly:

- Check `SYNTH_NO_BANNER=1` env var first — skip entirely if set.
- Check module-level session flag — skip if already displayed this process.
- Detect terminal capabilities:
  - Width via `shutil.get_terminal_size()`, default to 80 if unavailable.
  - Color support via `NO_COLOR` env var and `sys.stdout.isatty()`.
- Render elements in order with randomized delays (40–120ms via `random.uniform()` +
  `time.sleep()`).
- Apply flicker effect on the ERROR line: 3 rapid bold toggles using ANSI escape codes.
- Set session flag after display to prevent re-display within the same process.
- In no-color mode, render plain monochrome ASCII without ANSI codes or flicker.
- Color palette: bright green for main text, dim green for borders/logo, bold yellow for
  warning/flicker, red background + white text for error badge, dim green for closing divider.

## `synth dev` Hot-Reload

- Watch the agent file for changes using filesystem events.
- On file save, reload the agent module without restarting the process.
- Keep the REPL session alive across reloads.
- Open the trace UI in the default browser on startup.

## `synth doctor` Checks

The doctor command MUST check and report on:
1. Python version (3.10+ required)
2. Core dependencies installed and version-compatible
3. Provider-specific env vars (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, etc.)
4. `SYNTH_TRACE_ENDPOINT` if set — validate URL format
5. Optional provider packages — report which are installed
6. For each issue found, print the fix instruction (matching `SynthConfigError` patterns)

## Error Handling in CLI

- Catch `SynthError` subclasses at the command level and format them nicely with
  `click.echo()` + `click.style()`. Don't let raw tracebacks reach the user.
- For unexpected errors, print a brief message and suggest `synth doctor` or
  filing an issue.
- `deploy_cmd.py` MUST catch `SynthConfigError` for missing `synth[agentcore]` and
  print the `pip install` command.

## Output Formatting

- `synth run` prints the `RunResult.text` followed by a trace summary (tokens, cost,
  latency) on stderr so stdout can be piped.
- `synth eval` prints a table of pass/fail results per case, then an overall score line.
  Exit code 0 if pass rate meets threshold, 1 otherwise.
- `synth doctor` uses `[  OK  ]` / `[FAIL]` prefixes for each check, matching the
  boot sequence aesthetic.
