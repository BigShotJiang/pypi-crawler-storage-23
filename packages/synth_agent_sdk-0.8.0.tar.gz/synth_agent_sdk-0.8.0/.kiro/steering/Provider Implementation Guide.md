---
inclusion: fileMatch
fileMatchPattern: "synth/providers/*"
---

# Provider Implementation Guide

Rules for implementing and modifying LLM provider adapters in `synth/providers/`.

## Adding a New Provider

1. Create `synth/providers/<name>.py` with a class that subclasses `BaseProvider`.
2. Implement both `async complete()` and `async stream()` methods.
3. Register the provider in `_PROVIDER_SPECS` in `router.py` with a tuple of
   `(module_path, class_name, pip_package, pip_extra)`.
4. Add the optional extra to `pyproject.toml` under `[project.optional-dependencies]`
   and include it in the `all` extra.
5. Add the prefix to the parametrized test cases in `tests/unit/test_providers.py`.

## Lazy Import Pattern

Provider SDK packages MUST be imported lazily inside the provider class, never at
module top level. The `ProviderRouter` handles this via `_import_provider_class()`.

Within the provider module itself, guard the SDK import:

```python
from __future__ import annotations

from synth.errors import SynthConfigError
from synth.providers.base import BaseProvider, ProviderResponse, ...

try:
    import some_sdk
except ImportError:
    some_sdk = None  # type: ignore[assignment]
```

Then check at instantiation time:

```python
class SomeProvider(BaseProvider):
    def __init__(self, model: str, base_url: str | None = None, **kwargs):
        if some_sdk is None:
            raise SynthConfigError(
                message="Provider package 'some-sdk' is not installed. Run: pip install synth-agent-sdk[some]",
                component="SomeProvider",
                suggestion="pip install synth-agent-sdk[some]",
            )
```

## Response Normalization

- `complete()` MUST return a `ProviderResponse` with `text`, `usage` (as `TokenUsage`),
  and `tool_calls` (as `list[ToolCallInfo]`).
- `stream()` MUST yield `ProviderEvent` subtypes: `TextChunkEvent`, `ThinkingChunkEvent`,
  `ToolCallChunkEvent`, `ProviderDoneEvent`, or `ProviderErrorEvent`.
- Never expose provider-specific types (e.g., `anthropic.Message`, `openai.ChatCompletion`)
  beyond the provider module. The `raw` field on `ProviderResponse` can carry the original
  object for debugging but no SDK logic outside the provider should depend on it.

## Constructor Contract

Every provider constructor MUST accept at minimum:
- `model: str` — the full model string (including prefix like `bedrock/...`)
- `base_url: str | None` — optional custom endpoint override
- `**kwargs` — forwarded from the router for future extensibility

## Retry Integration

Provider implementations do NOT handle retries themselves. The `RetryHandler` in
`retry.py` wraps provider calls at the Agent layer. Providers should raise or let
HTTP errors propagate naturally so the retry handler can catch HTTP 429 and 5xx.

The retry handler uses exponential backoff: `base * 2^attempt` with jitter, up to
`max_retries` (default 3).

## Bedrock-Specific Rules

- `BedrockProvider` uses `boto3` `bedrock-runtime` client, not provider-specific SDKs.
- It accepts both short-form (`bedrock/claude-sonnet-4-5`) and full ARN-style model IDs
  (`bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0`).
- AWS credentials come from the environment (IAM role, env vars, AWS config), never from
  Synth-specific API key env vars.
- When deployed to AgentCore, the runtime provides IAM credentials automatically.

## Streaming Contract

- Every provider MUST support streaming when `stream()` is called.
- The stream MUST end with a `ProviderDoneEvent` containing final `TokenUsage`.
- On error during streaming, yield a `ProviderErrorEvent` and stop iteration.
- The Agent layer maps `ProviderEvent` types to SDK `StreamEvent` types — providers
  don't need to know about `TokenEvent`, `DoneEvent`, etc.

## Testing Providers

- Use `unittest.mock.patch("importlib.import_module", ...)` to test routing without
  real SDK imports.
- Test both the happy path (mock module with mock class) and the missing-package path
  (raise `ImportError`).
- Parametrize tests across all known prefixes.
- For integration tests (not in CI), use real API calls gated behind env var checks.
