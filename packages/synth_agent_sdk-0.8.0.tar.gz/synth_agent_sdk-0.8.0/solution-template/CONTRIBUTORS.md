# Founding Authors

- David Kaleko 
- Isaac Privitera
- Brian Zambrano
- Ryan Razkenari
- Monica Raj
- Anurag Bhagat

# Contributors

- Davide Merlin
