"""Third-party observability integration adapters for the Synth SDK.

Provides one-line configuration stubs for Langfuse, Datadog, and Honeycomb.
Each adapter translates a ``Trace`` into the platform-specific format and
forwards it.  The adapters are intentionally thin — they validate
configuration and delegate to the platform SDK.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from synth.tracing.trace import Trace


# ---------------------------------------------------------------------------
# Base integration
# ---------------------------------------------------------------------------


class BaseTraceIntegration(ABC):
    """Abstract base for third-party trace integrations."""

    @abstractmethod
    def send(self, trace: Trace) -> None:
        """Forward a Trace to the external platform."""
        ...


# ---------------------------------------------------------------------------
# Langfuse
# ---------------------------------------------------------------------------


class LangfuseIntegration(BaseTraceIntegration):
    """Forward traces to Langfuse.

    Parameters
    ----------
    public_key:
        Langfuse public key.
    secret_key:
        Langfuse secret key.
    host:
        Langfuse API host.  Defaults to the Langfuse cloud endpoint.
    """

    def __init__(
        self,
        public_key: str,
        secret_key: str,
        host: str = "https://cloud.langfuse.com",
    ) -> None:
        self.public_key = public_key
        self.secret_key = secret_key
        self.host = host

    def send(self, trace: Trace) -> None:
        """Forward *trace* to Langfuse."""
        # Stub — real implementation would use the langfuse SDK.
        # Kept minimal; users are expected to install langfuse separately.
        pass  # pragma: no cover


# ---------------------------------------------------------------------------
# Datadog
# ---------------------------------------------------------------------------


class DatadogIntegration(BaseTraceIntegration):
    """Forward traces to Datadog APM.

    Parameters
    ----------
    api_key:
        Datadog API key.
    site:
        Datadog site (e.g. ``"datadoghq.com"``).
    """

    def __init__(
        self,
        api_key: str,
        site: str = "datadoghq.com",
    ) -> None:
        self.api_key = api_key
        self.site = site

    def send(self, trace: Trace) -> None:
        """Forward *trace* to Datadog."""
        pass  # pragma: no cover


# ---------------------------------------------------------------------------
# Honeycomb
# ---------------------------------------------------------------------------


class HoneycombIntegration(BaseTraceIntegration):
    """Forward traces to Honeycomb.

    Parameters
    ----------
    api_key:
        Honeycomb API key.
    dataset:
        Honeycomb dataset name.
    """

    def __init__(
        self,
        api_key: str,
        dataset: str = "synth-traces",
    ) -> None:
        self.api_key = api_key
        self.dataset = dataset

    def send(self, trace: Trace) -> None:
        """Forward *trace* to Honeycomb."""
        pass  # pragma: no cover
