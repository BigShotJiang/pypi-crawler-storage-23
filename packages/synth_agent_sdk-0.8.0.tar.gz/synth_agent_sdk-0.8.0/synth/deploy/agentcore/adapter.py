"""AgentCore adapter for payload translation.

Translates between AWS AgentCore invocation payloads and Synth's
``run()`` input/output format.  Extracts user identity securely from
the validated JWT token in the ``RequestContext`` rather than trusting
the payload body, preventing impersonation via prompt injection.
"""

from __future__ import annotations

import logging
from typing import Any

from synth._compat import run_sync
from synth.errors import SynthConfigError

logger = logging.getLogger(__name__)


class AgentCoreAdapter:
    """Bridge between AgentCore runtime and Synth agents/graphs.

    Parameters
    ----------
    agent_or_graph:
        A Synth ``Agent`` or ``Graph`` instance.
    """

    def __init__(self, agent_or_graph: Any) -> None:
        self._target = agent_or_graph

    def handle_invocation(
        self,
        payload: dict[str, Any],
        context: Any | None = None,
    ) -> dict[str, Any]:
        """Handle an AgentCore invocation synchronously.

        Parameters
        ----------
        payload:
            The AgentCore invocation payload.
        context:
            Optional ``RequestContext`` from AgentCore Runtime.  When
            provided, the user ID is extracted from the validated JWT
            token rather than the payload.

        Returns
        -------
        dict
            AgentCore-compatible response.
        """
        return run_sync(self.ahandle_invocation(payload, context))

    async def ahandle_invocation(
        self,
        payload: dict[str, Any],
        context: Any | None = None,
    ) -> dict[str, Any]:
        """Handle an AgentCore invocation asynchronously.

        Parameters
        ----------
        payload:
            The AgentCore invocation payload.
        context:
            Optional ``RequestContext`` from AgentCore Runtime.

        Returns
        -------
        dict
            AgentCore-compatible response.
        """
        self._validate_payload(payload)

        prompt = self._extract_prompt(payload)
        session_id = payload.get("runtimeSessionId") or payload.get("session_id")

        # Securely extract user ID from JWT — never from payload body
        user_id: str | None = None
        if context is not None:
            try:
                from synth.deploy.agentcore.auth import extract_user_id
                user_id = extract_user_id(context)
            except SynthConfigError:
                logger.warning(
                    "Could not extract user_id from RequestContext JWT. "
                    "Proceeding without user identity."
                )

        run_kwargs: dict[str, Any] = {}
        if session_id:
            run_kwargs["thread_id"] = session_id

        result = await self._target.arun(prompt, **run_kwargs)

        response: dict[str, Any] = {
            "output": {"text": result.text},
            "metadata": {
                "tokens": {
                    "input": result.tokens.input_tokens,
                    "output": result.tokens.output_tokens,
                    "total": result.tokens.total_tokens,
                },
                "cost": result.cost,
                "latency_ms": result.latency_ms,
            },
        }

        if user_id:
            response["metadata"]["user_id"] = user_id

        return response

    @staticmethod
    def _validate_payload(payload: dict[str, Any]) -> None:
        """Validate the AgentCore payload schema.

        Raises ``SynthConfigError`` for malformed payloads.
        """
        if not isinstance(payload, dict):
            raise SynthConfigError(
                message="AgentCore payload must be a JSON object (dict).",
                component="AgentCoreAdapter",
                suggestion="Check the AgentCore invocation format.",
            )

        has_prompt = (
            "prompt" in payload
            or "input" in payload
        )
        if not has_prompt:
            raise SynthConfigError(
                message="AgentCore payload missing 'input' or 'prompt' field.",
                component="AgentCoreAdapter",
                suggestion=(
                    "Payload must contain 'input' (str or {text: str}) or 'prompt' (str)."
                ),
            )

    @staticmethod
    def _extract_prompt(payload: dict[str, Any]) -> str:
        """Extract the prompt string from an AgentCore payload."""
        if not isinstance(payload, dict):
            raise SynthConfigError(
                message="AgentCore payload must be a dict.",
                component="AgentCoreAdapter",
                suggestion="Payload must contain 'input' (str or {text: str}) or 'prompt' (str).",
            )
        if "input" in payload:
            inp = payload["input"]
            if isinstance(inp, str):
                return inp
            if isinstance(inp, dict) and "text" in inp:
                return str(inp["text"])

        if "prompt" in payload:
            return str(payload["prompt"])

        raise SynthConfigError(
            message="AgentCore payload is missing 'input' or 'prompt' field.",
            component="AgentCoreAdapter",
            suggestion="Payload must contain 'input' (str or {text: str}) or 'prompt' (str).",
        )
