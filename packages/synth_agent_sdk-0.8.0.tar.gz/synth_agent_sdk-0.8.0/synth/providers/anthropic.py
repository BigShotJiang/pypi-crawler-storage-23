"""AnthropicProvider — Anthropic Claude model adapter.

Routes requests to the Anthropic Messages API using the ``anthropic``
Python SDK.  The SDK is lazily imported so that users who don't need
Anthropic don't pay the import cost or require the package.
"""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from typing import Any

from synth.errors import SynthConfigError
from synth.providers.base import (
    BaseProvider,
    ProviderDoneEvent,
    ProviderErrorEvent,
    ProviderEvent,
    ProviderResponse,
    TextChunkEvent,
    ThinkingChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.types import Message, TokenUsage

try:
    import anthropic
except ImportError:
    anthropic = None  # type: ignore[assignment]


class AnthropicProvider(BaseProvider):
    """LLM provider adapter for Anthropic Claude models.

    Parameters
    ----------
    model:
        Model identifier, e.g. ``"claude-sonnet-4-5"``.
    base_url:
        Optional custom API endpoint.
    **kwargs:
        Extra options forwarded to the Anthropic client constructor.
    """

    def __init__(self, model: str, base_url: str | None = None, **kwargs: Any) -> None:
        if anthropic is None:
            raise SynthConfigError(
                message="Provider package 'anthropic' is not installed. "
                "Run: pip install synth-agent-sdk[anthropic]",
                component="AnthropicProvider",
                suggestion="pip install synth-agent-sdk[anthropic]",
            )

        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise SynthConfigError(
                message="ANTHROPIC_API_KEY environment variable is not set.",
                component="AnthropicProvider",
                suggestion="Set the ANTHROPIC_API_KEY environment variable. "
                "Get your key at https://console.anthropic.com/",
            )

        self._model = model
        client_kwargs: dict[str, Any] = {"api_key": api_key, **kwargs}
        if base_url is not None:
            client_kwargs["base_url"] = base_url

        self._client = anthropic.AsyncAnthropic(**client_kwargs)

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    def _build_tools(self, tools: list[dict[str, Any]] | None) -> list[dict[str, Any]] | None:
        """Convert Synth tool schemas to Anthropic tool format."""
        if not tools:
            return None
        anthropic_tools = []
        for t in tools:
            anthropic_tools.append({
                "name": t["name"],
                "description": t.get("description", ""),
                "input_schema": t.get("parameters", {}),
            })
        return anthropic_tools

    def _build_messages(
        self, messages: list[Message]
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Split messages into a system prompt and Anthropic message list."""
        system: str | None = None
        api_messages: list[dict[str, Any]] = []
        for msg in messages:
            if msg["role"] == "system":
                system = msg["content"]
            else:
                api_messages.append({"role": msg["role"], "content": msg["content"]})
        return system, api_messages

    # -----------------------------------------------------------------
    # BaseProvider interface
    # -----------------------------------------------------------------

    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        """Send a completion request to the Anthropic Messages API.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``max_tokens``, etc.).
        """
        system, api_messages = self._build_messages(messages)
        api_kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": api_messages,
            "max_tokens": kwargs.pop("max_tokens", 4096),
            **kwargs,
        }
        if system is not None:
            api_kwargs["system"] = system

        anthropic_tools = self._build_tools(tools)
        if anthropic_tools is not None:
            api_kwargs["tools"] = anthropic_tools

        response = await self._client.messages.create(**api_kwargs)

        # Parse response
        text_parts: list[str] = []
        tool_calls: list[ToolCallInfo] = []
        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append(
                    ToolCallInfo(id=block.id, name=block.name, args=block.input)
                )

        usage = TokenUsage(
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            total_tokens=response.usage.input_tokens + response.usage.output_tokens,
        )

        return ProviderResponse(
            text="".join(text_parts),
            usage=usage,
            tool_calls=tool_calls,
            raw=response,
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ProviderEvent, None]:
        """Stream a completion from the Anthropic Messages API.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``max_tokens``, etc.).
        """
        system, api_messages = self._build_messages(messages)
        api_kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": api_messages,
            "max_tokens": kwargs.pop("max_tokens", 4096),
            **kwargs,
        }
        if system is not None:
            api_kwargs["system"] = system

        anthropic_tools = self._build_tools(tools)
        if anthropic_tools is not None:
            api_kwargs["tools"] = anthropic_tools

        input_tokens = 0
        output_tokens = 0

        try:
            async with self._client.messages.stream(**api_kwargs) as stream:
                async for event in stream:
                    if event.type == "content_block_delta":
                        delta = event.delta
                        if delta.type == "text_delta":
                            yield TextChunkEvent(text=delta.text)
                        elif delta.type == "thinking_delta":
                            yield ThinkingChunkEvent(text=delta.thinking)
                        elif delta.type == "input_json_delta":
                            pass  # Partial JSON for tool args — handled at block end
                    elif event.type == "content_block_stop":
                        block = stream.current_message_snapshot.content[event.index]
                        if block.type == "tool_use":
                            yield ToolCallChunkEvent(
                                id=block.id, name=block.name, args=block.input
                            )
                    elif event.type == "message_delta":
                        output_tokens = getattr(
                            event.usage, "output_tokens", output_tokens
                        )
                    elif event.type == "message_start":
                        input_tokens = getattr(
                            event.message.usage, "input_tokens", 0
                        )

            yield ProviderDoneEvent(
                usage=TokenUsage(
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                )
            )
        except Exception as exc:
            yield ProviderErrorEvent(error=exc)
