# Feature: synth-agent-sdk, Property 36: Error message structure
"""Property-based tests for error message structure.

**Validates: Requirements 15.1**

For any SynthError subclass instance, the error should contain non-empty values
for: what went wrong (message), which component raised it (component field),
and a suggested fix (suggestion field).
"""

from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.errors import (
    CostLimitError,
    GraphLoopError,
    GraphRoutingError,
    GuardViolationError,
    PipelineError,
    RunNotFoundError,
    SynthConfigError,
    SynthError,
    SynthParseError,
    ToolDefinitionError,
    ToolExecutionError,
)

# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

non_empty_text = st.text(min_size=1, max_size=200).filter(lambda s: s.strip())


def _build_synth_error(cls, message, component, suggestion):
    """Build a SynthError subclass instance with the correct constructor args."""
    base_kwargs = dict(component=component, suggestion=suggestion)

    if cls is ToolExecutionError:
        return cls(
            message,
            **base_kwargs,
            tool_name="some_tool",
            tool_args={"key": "value"},
            original_error=RuntimeError("underlying"),
        )
    if cls in (GuardViolationError, CostLimitError):
        return cls(
            message,
            **base_kwargs,
            guard_name="test_guard",
            violating_content="bad content",
            remediation="fix it",
        )
    if cls is GraphRoutingError:
        return cls(
            message,
            **base_kwargs,
            node_name="stuck_node",
            current_state={"x": 1},
        )
    if cls is GraphLoopError:
        return cls(
            message,
            **base_kwargs,
            node_history=["a", "b", "a"],
            max_iterations=10,
        )
    if cls is RunNotFoundError:
        return cls(
            message,
            **base_kwargs,
            run_id="run-123",
        )
    if cls is PipelineError:
        return cls(
            message,
            **base_kwargs,
            failed_step=0,
            agent_name="agent_a",
            partial_results=[],
        )
    # SynthError, SynthConfigError, ToolDefinitionError, SynthParseError
    return cls(message, **base_kwargs)


ALL_ERROR_CLASSES = st.sampled_from(
    [
        SynthError,
        SynthConfigError,
        ToolDefinitionError,
        ToolExecutionError,
        GuardViolationError,
        CostLimitError,
        SynthParseError,
        GraphRoutingError,
        GraphLoopError,
        RunNotFoundError,
        PipelineError,
    ]
)


# ---------------------------------------------------------------------------
# Property 36: Error message structure
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    cls=ALL_ERROR_CLASSES,
    message=non_empty_text,
    component=non_empty_text,
    suggestion=non_empty_text,
)
def test_error_message_structure(cls, message, component, suggestion):
    """Property 36: Every SynthError subclass instance has non-empty message,
    component, and suggestion.

    **Validates: Requirements 15.1**
    """
    error = _build_synth_error(cls, message, component, suggestion)

    # str(error) reflects the message and must be non-empty
    assert str(error), "str(error) must be non-empty"

    # component field must be non-empty
    assert error.component, "error.component must be non-empty"

    # suggestion field must be non-empty
    assert error.suggestion, "error.suggestion must be non-empty"

    # All SynthError subclasses must be catchable as SynthError
    assert isinstance(error, SynthError)
