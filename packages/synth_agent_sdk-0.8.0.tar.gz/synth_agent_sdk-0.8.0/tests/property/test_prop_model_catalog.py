"""Property-based tests for ``ModelCatalog``, ``RegionValidator``, and
``agentcore.yaml`` round-trip persistence.

**Property 11: Region filtering correctness**
**Validates: Requirements 4.2**

**Property 12: Model ID written correctly based on CRIS requirement**
**Validates: Requirements 4.3, 4.4, 4.7**

**Property 13: agentcore.yaml round-trip persistence**
**Validates: Requirements 4.7, 7.1**

# Feature: agentcore-init-enhancements, Property 13: agentcore.yaml round-trip persistence
"""

from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.cli.init_cmd import _build_agentcore_yaml
from synth.deploy.agentcore.model_catalog import ModelCatalog, RegionValidator


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

# AWS region strings — realistic format
_REGION_STRATEGY = st.one_of(
    st.sampled_from([
        "us-east-1", "us-east-2", "us-west-1", "us-west-2",
        "eu-west-1", "eu-west-2", "eu-central-1",
        "ap-northeast-1", "ap-southeast-1", "ap-southeast-2",
        "ap-south-1", "sa-east-1", "ca-central-1",
    ]),
    # Also test unknown regions
    st.from_regex(r"[a-z]{2}-[a-z]+-[1-9]", fullmatch=True),
)

# Valid AWS profile names (alphanumeric + hyphens/underscores)
_PROFILE_STRATEGY = st.one_of(
    st.none(),
    st.from_regex(r"[a-zA-Z][a-zA-Z0-9_-]{0,30}", fullmatch=True),
)

# Model IDs from the real catalog
_CATALOG = ModelCatalog()
_MODEL_IDS = [e.model_id for e in _CATALOG.MODELS]
_MODEL_ID_STRATEGY = st.sampled_from(_MODEL_IDS)

# Agent names
_NAME_STRATEGY = st.from_regex(r"[a-z][a-z0-9-]{0,29}", fullmatch=True)


# ---------------------------------------------------------------------------
# Helper: parse the flat YAML produced by _build_agentcore_yaml
# ---------------------------------------------------------------------------

def _parse_yaml_fields(content: str) -> dict[str, str]:
    """Parse key: value lines from the agentcore.yaml content.

    Only handles the simple ``key: value`` format produced by
    ``_build_agentcore_yaml`` — no nested structures.
    """
    result: dict[str, str] = {}
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("#") or not line or line.startswith("-"):
            continue
        if ": " in line:
            key, _, value = line.partition(": ")
            result[key.strip()] = value.strip().strip('"')
    return result


# ---------------------------------------------------------------------------
# Property 11: Region filtering correctness
# ---------------------------------------------------------------------------

@given(region=_REGION_STRATEGY)
@settings(max_examples=100)
def test_prop11_region_filtering_only_returns_available_models(region: str) -> None:
    """Property 11: models_for_region returns only models available in that region.

    For any AWS region string, ``RegionValidator.models_for_region()`` should
    return only models whose ``native_regions`` or ``cris_regions`` list includes
    that region, OR return all models when the region is unknown.

    **Property 11: Region filtering correctness**
    **Validates: Requirements 4.2**
    """
    catalog = ModelCatalog()
    validator = RegionValidator(catalog)

    models = validator.models_for_region(region)
    availability_unknown = validator.availability_unknown_for_region(region)

    if availability_unknown:
        # Unknown region: all models returned as fallback
        assert len(models) == len(catalog.MODELS)
    else:
        # Known region: every returned model must be available there
        for entry in models:
            in_native = region in entry.native_regions
            in_cris = region in entry.cris_regions
            assert in_native or in_cris, (
                f"Model {entry.model_id} returned for region {region!r} "
                f"but is not in native_regions={entry.native_regions} "
                f"or cris_regions={entry.cris_regions}"
            )

        # No model that is NOT available should appear
        all_available_ids = {e.model_id for e in models}
        for entry in catalog.MODELS:
            in_native = region in entry.native_regions
            in_cris = region in entry.cris_regions
            if not in_native and not in_cris:
                assert entry.model_id not in all_available_ids, (
                    f"Model {entry.model_id} should NOT appear for region {region!r}"
                )


# ---------------------------------------------------------------------------
# Property 12: Model ID written correctly based on CRIS requirement
# ---------------------------------------------------------------------------

@given(
    model_id=_MODEL_ID_STRATEGY,
    region=_REGION_STRATEGY,
)
@settings(max_examples=100)
def test_prop12_effective_model_id_matches_cris_requirement(
    model_id: str,
    region: str,
) -> None:
    """Property 12: effective_model_id returns base ID or CRIS profile ID correctly.

    For any (model, region) pair where the model is in the catalog:
    - If CRIS is required: effective ID == cris_profile_id, cris_enabled == True
    - If CRIS is not required: effective ID == base model_id, cris_enabled == False

    **Property 12: Model ID written correctly based on CRIS requirement**
    **Validates: Requirements 4.3, 4.4, 4.7**
    """
    catalog = ModelCatalog()
    validator = RegionValidator(catalog)

    requires_cris = validator.requires_cris(model_id, region)
    effective_id = validator.effective_model_id(model_id, region)

    # Find the catalog entry
    entry = next((e for e in catalog.MODELS if e.model_id == model_id), None)
    assert entry is not None, f"Model {model_id} not found in catalog"

    if requires_cris:
        # Must use the CRIS profile ID
        assert effective_id == entry.cris_profile_id, (
            f"Expected CRIS profile ID {entry.cris_profile_id!r} "
            f"but got {effective_id!r} for model={model_id}, region={region}"
        )
        assert effective_id != model_id or entry.cris_profile_id == model_id
    else:
        # Must use the base model ID
        assert effective_id == model_id, (
            f"Expected base model ID {model_id!r} "
            f"but got {effective_id!r} for region={region}"
        )

    # requires_cris is True iff region is in cris_regions AND NOT in native_regions
    expected_cris = region in entry.cris_regions and region not in entry.native_regions
    assert requires_cris == expected_cris, (
        f"requires_cris mismatch for model={model_id}, region={region}: "
        f"got {requires_cris}, expected {expected_cris}"
    )


# ---------------------------------------------------------------------------
# Property 13: agentcore.yaml round-trip persistence
# ---------------------------------------------------------------------------

@given(
    name=_NAME_STRATEGY,
    aws_region=_REGION_STRATEGY,
    model_id=_MODEL_ID_STRATEGY,
    cris_enabled=st.booleans(),
    aws_profile=_PROFILE_STRATEGY,
)
@settings(max_examples=100)
def test_prop13_agentcore_yaml_round_trip(
    name: str,
    aws_region: str,
    model_id: str,
    cris_enabled: bool,
    aws_profile: str | None,
) -> None:
    """Property 13: agentcore.yaml round-trip persistence.

    For any (region, model_id, cris_enabled, aws_profile) tuple written to
    ``agentcore.yaml``, reading the file back and parsing it should produce
    the same values with no data loss or type coercion.

    **Property 13: agentcore.yaml round-trip persistence**
    **Validates: Requirements 4.7, 7.1**
    """
    setup = {
        "aws_region": aws_region,
        "model_id": model_id,
        "cris_enabled": cris_enabled,
        "aws_profile": aws_profile,
    }

    content = _build_agentcore_yaml(name, setup)
    fields = _parse_yaml_fields(content)

    # aws_region round-trips exactly
    assert fields.get("aws_region") == aws_region, (
        f"aws_region mismatch: wrote {aws_region!r}, read {fields.get('aws_region')!r}"
    )

    # model_id round-trips exactly
    assert fields.get("model_id") == model_id, (
        f"model_id mismatch: wrote {model_id!r}, read {fields.get('model_id')!r}"
    )

    # cris_enabled round-trips as the correct boolean string
    expected_cris_str = "true" if cris_enabled else "false"
    assert fields.get("cris_enabled") == expected_cris_str, (
        f"cris_enabled mismatch: wrote {cris_enabled!r}, "
        f"read {fields.get('cris_enabled')!r}"
    )

    # aws_profile round-trips when provided, absent when None
    if aws_profile is not None:
        assert fields.get("aws_profile") == aws_profile, (
            f"aws_profile mismatch: wrote {aws_profile!r}, "
            f"read {fields.get('aws_profile')!r}"
        )
    else:
        assert "aws_profile" not in fields, (
            "aws_profile should be absent when None, but was found in output"
        )

    # agent_name round-trips exactly
    assert fields.get("agent_name") == name, (
        f"agent_name mismatch: wrote {name!r}, read {fields.get('agent_name')!r}"
    )

    # No credential values in output (security invariant)
    assert "AKIA" not in content
    assert "ASIA" not in content
