"""Unit tests for the Pipeline orchestration module.

Covers sequential execution, parallel groups, error handling with partial
results, streaming with stage labels, output_schema validation, stage naming,
parallel token aggregation, and sync streaming.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from pydantic import BaseModel

from synth.agent import Agent
from synth.errors import PipelineError
from synth.orchestration.pipeline import ParallelGroup, Pipeline
from synth.providers.base import ProviderResponse
from synth.types import (
    DoneEvent,
    RunResult,
    StageEvent,
    TokenEvent,
    TokenUsage,
)
from tests.conftest import MockProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USAGE = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)


def _make_agent(text: str) -> Agent:
    """Create an Agent backed by a MockProvider returning *text*."""
    provider = MockProvider(responses=[ProviderResponse(text=text, usage=_USAGE)])
    with patch("synth.agent.ProviderRouter.resolve", return_value=provider):
        return Agent(instructions=text)


def _make_failing_agent(exc: Exception) -> Agent:
    """Create an Agent whose provider raises *exc*."""
    provider = MockProvider(error=exc)
    with patch("synth.agent.ProviderRouter.resolve", return_value=provider):
        return Agent(instructions="failing")


# ---------------------------------------------------------------------------
# Sequential execution
# ---------------------------------------------------------------------------


class TestPipelineSequential:
    """Tests for sequential pipeline execution."""

    @pytest.mark.asyncio
    async def test_single_stage(self):
        """Pipeline with one agent returns that agent's result."""
        agent = _make_agent("hello")
        pipeline = Pipeline([agent])
        result = await pipeline.arun("input")
        assert result.text == "hello"

    @pytest.mark.asyncio
    async def test_two_stages_chain_output(self):
        """Second agent receives first agent's output as its prompt."""
        agent_a = _make_agent("step-one-output")
        agent_b = _make_agent("step-two-output")
        pipeline = Pipeline([agent_a, agent_b])
        result = await pipeline.arun("initial")
        assert result.text == "step-two-output"

    @pytest.mark.asyncio
    async def test_three_stages(self):
        """Pipeline chains three agents sequentially."""
        agents = [_make_agent(f"out-{i}") for i in range(3)]
        pipeline = Pipeline(agents)
        result = await pipeline.arun("start")
        assert result.text == "out-2"

    def test_sync_run(self):
        """Pipeline.run() works synchronously."""
        agent = _make_agent("sync-result")
        pipeline = Pipeline([agent])
        result = pipeline.run("go")
        assert result.text == "sync-result"


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestPipelineErrors:
    """Tests for pipeline error handling with partial results."""

    @pytest.mark.asyncio
    async def test_error_at_step_zero(self):
        """Error at step 0 raises PipelineError with empty partial results."""
        agent = _make_failing_agent(RuntimeError("boom"))
        pipeline = Pipeline([agent])

        with pytest.raises(PipelineError) as exc_info:
            await pipeline.arun("input")

        err = exc_info.value
        assert err.failed_step == 0
        assert err.partial_results == []

    @pytest.mark.asyncio
    async def test_error_at_step_one_has_partial(self):
        """Error at step 1 includes step 0's result in partial_results."""
        agent_ok = _make_agent("ok-output")
        agent_bad = _make_failing_agent(RuntimeError("fail"))
        pipeline = Pipeline([agent_ok, agent_bad])

        with pytest.raises(PipelineError) as exc_info:
            await pipeline.arun("input")

        err = exc_info.value
        assert err.failed_step == 1
        assert len(err.partial_results) == 1
        assert err.partial_results[0].text == "ok-output"

    @pytest.mark.asyncio
    async def test_error_includes_agent_name(self):
        """PipelineError includes the failing agent's name."""
        agent_bad = _make_failing_agent(RuntimeError("oops"))
        pipeline = Pipeline([agent_bad])

        with pytest.raises(PipelineError) as exc_info:
            await pipeline.arun("input")

        assert exc_info.value.agent_name != ""


# ---------------------------------------------------------------------------
# ParallelGroup
# ---------------------------------------------------------------------------


class TestParallelGroup:
    """Tests for ParallelGroup concurrent execution."""

    @pytest.mark.asyncio
    async def test_parallel_group_merges_outputs(self):
        """ParallelGroup merges agent outputs with newline join."""
        agents = [_make_agent("alpha"), _make_agent("beta")]
        group = ParallelGroup(agents)
        pipeline = Pipeline([group])
        result = await pipeline.arun("input")
        assert "alpha" in result.text
        assert "beta" in result.text

    @pytest.mark.asyncio
    async def test_parallel_group_custom_merge(self):
        """ParallelGroup uses custom merge function when provided."""
        agents = [_make_agent("a"), _make_agent("b")]
        group = ParallelGroup(
            agents,
            merge=lambda results: " + ".join(r.text for r in results),
        )
        pipeline = Pipeline([group])
        result = await pipeline.arun("input")
        assert result.text == "a + b"


# ---------------------------------------------------------------------------
# Streaming
# ---------------------------------------------------------------------------


class TestPipelineStreaming:
    """Tests for pipeline streaming with stage labels."""

    @pytest.mark.asyncio
    async def test_stream_events_have_stage_name(self):
        """Every streamed event is wrapped in StageEvent with a stage name."""
        agent = _make_agent("streamed")
        pipeline = Pipeline([agent])

        events = [e async for e in pipeline.astream("input")]
        assert all(isinstance(e, StageEvent) for e in events)
        assert all(e.stage_name != "" for e in events)

    @pytest.mark.asyncio
    async def test_stream_two_stages_labels_differ(self):
        """Events from different stages have different stage names."""
        agent_a = _make_agent("first")
        agent_b = _make_agent("second")
        pipeline = Pipeline([agent_a, agent_b])

        events = [e async for e in pipeline.astream("input")]
        stage_names = {e.stage_name for e in events}
        assert len(stage_names) == 2

    @pytest.mark.asyncio
    async def test_stream_contains_done_event(self):
        """Stream includes a DoneEvent from the final stage."""
        agent = _make_agent("done")
        pipeline = Pipeline([agent])

        events = [e async for e in pipeline.astream("input")]
        done_events = [
            e for e in events if isinstance(e.event, DoneEvent)
        ]
        assert len(done_events) >= 1


# ---------------------------------------------------------------------------
# Stage naming
# ---------------------------------------------------------------------------


class TestStageNaming:
    """Tests for Pipeline._stage_name across all branches."""

    def test_stage_name_parallel_group(self):
        """ParallelGroup stages are named 'parallel_group_{idx}'."""
        group = ParallelGroup([_make_agent("a")])
        assert Pipeline._stage_name(group, 2) == "parallel_group_2"

    def test_stage_name_agent_with_instructions(self):
        """Agent with instructions uses first 30 chars as name."""
        agent = _make_agent("short instructions")
        name = Pipeline._stage_name(agent, 0)
        assert name == "short instructions"

    def test_stage_name_agent_long_instructions_truncated(self):
        """Agent with long instructions is truncated to 30 chars."""
        long_text = "a" * 50
        agent = _make_agent(long_text)
        name = Pipeline._stage_name(agent, 0)
        assert len(name) <= 30

    def test_stage_name_agent_no_instructions_uses_model(self):
        """Agent with empty instructions falls back to model name."""
        agent = _make_agent("")
        # Clear instructions to trigger the model branch
        agent.instructions = ""
        name = Pipeline._stage_name(agent, 3)
        # Should contain the step index
        assert "3" in name

    def test_stage_name_plain_object_fallback(self):
        """Object with no instructions or model falls back to 'stage_{idx}'."""

        class Bare:
            pass

        name = Pipeline._stage_name(Bare(), 7)
        assert name == "stage_7"


# ---------------------------------------------------------------------------
# ParallelGroup details
# ---------------------------------------------------------------------------


class TestParallelGroupDetails:
    """Tests for ParallelGroup merge and aggregation behaviour."""

    def test_default_merge_concatenates_with_newlines(self):
        """_default_merge joins result texts with newlines."""
        results = [
            RunResult(
                text="alpha", output=None,
                tokens=TokenUsage(input_tokens=0, output_tokens=0, total_tokens=0),
                cost=0, latency_ms=0, trace=None, tool_calls=[],
            ),
            RunResult(
                text="beta", output=None,
                tokens=TokenUsage(input_tokens=0, output_tokens=0, total_tokens=0),
                cost=0, latency_ms=0, trace=None, tool_calls=[],
            ),
        ]
        assert ParallelGroup._default_merge(results) == "alpha\nbeta"

    @pytest.mark.asyncio
    async def test_parallel_aggregates_tokens(self):
        """_run_parallel sums input/output tokens across agents."""
        usage_a = TokenUsage(input_tokens=10, output_tokens=20, total_tokens=30)
        usage_b = TokenUsage(input_tokens=5, output_tokens=15, total_tokens=20)
        provider_a = MockProvider(
            responses=[ProviderResponse(text="a", usage=usage_a)]
        )
        provider_b = MockProvider(
            responses=[ProviderResponse(text="b", usage=usage_b)]
        )
        with patch("synth.agent.ProviderRouter.resolve", return_value=provider_a):
            agent_a = Agent(instructions="a")
        with patch("synth.agent.ProviderRouter.resolve", return_value=provider_b):
            agent_b = Agent(instructions="b")

        group = ParallelGroup([agent_a, agent_b])
        result = await Pipeline._run_parallel(group, "input")

        assert result.tokens.input_tokens == 15
        assert result.tokens.output_tokens == 35
        assert result.tokens.total_tokens == 50

    @pytest.mark.asyncio
    async def test_parallel_cost_is_sum(self):
        """_run_parallel sums cost across agents."""
        agents = [_make_agent("x"), _make_agent("y")]
        group = ParallelGroup(agents)
        result = await Pipeline._run_parallel(group, "input")
        # Each MockProvider default usage has cost from RunResult;
        # the result cost should be the sum of individual costs
        assert result.cost >= 0

    @pytest.mark.asyncio
    async def test_parallel_latency_is_max(self):
        """_run_parallel uses max latency across agents."""
        agents = [_make_agent("x"), _make_agent("y")]
        group = ParallelGroup(agents)
        result = await Pipeline._run_parallel(group, "input")
        assert result.latency_ms >= 0


# ---------------------------------------------------------------------------
# Structured output on pipeline
# ---------------------------------------------------------------------------


class TestPipelineStructuredOutput:
    """Tests for output_schema validation on the final stage."""

    @pytest.mark.asyncio
    async def test_output_schema_parses_final_stage(self):
        """output_schema validates and parses the final stage's text."""

        class Answer(BaseModel):
            value: int

        # Agent returns valid JSON
        agent = _make_agent('{"value": 42}')
        pipeline = Pipeline([agent])
        result = await pipeline.arun('go', output_schema=Answer)
        assert result.output is not None
        assert result.output.value == 42

    @pytest.mark.asyncio
    async def test_output_schema_none_skips_parsing(self):
        """Without output_schema, result.output comes from the agent."""
        agent = _make_agent("plain text")
        pipeline = Pipeline([agent])
        result = await pipeline.arun("go")
        # output should be None since no schema was requested
        assert result.output is None

    def test_sync_run_with_output_schema(self):
        """Pipeline.run() with output_schema works synchronously."""

        class Item(BaseModel):
            name: str

        agent = _make_agent('{"name": "widget"}')
        pipeline = Pipeline([agent])
        result = pipeline.run("go", output_schema=Item)
        assert result.output is not None
        assert result.output.name == "widget"


# ---------------------------------------------------------------------------
# Streaming with ParallelGroup
# ---------------------------------------------------------------------------


class TestPipelineStreamingParallel:
    """Tests for streaming behaviour with ParallelGroup stages."""

    @pytest.mark.asyncio
    async def test_stream_parallel_group_yields_done_event(self):
        """Streaming a ParallelGroup stage yields a StageEvent with DoneEvent."""
        agents = [_make_agent("p1"), _make_agent("p2")]
        group = ParallelGroup(agents)
        pipeline = Pipeline([group])

        events = [e async for e in pipeline.astream("input")]
        assert len(events) >= 1
        assert all(isinstance(e, StageEvent) for e in events)
        done_events = [e for e in events if isinstance(e.event, DoneEvent)]
        assert len(done_events) == 1
        assert "p1" in done_events[0].event.result.text

    @pytest.mark.asyncio
    async def test_stream_mixed_sequential_and_parallel(self):
        """Streaming a pipeline with both Agent and ParallelGroup stages."""
        agent = _make_agent("solo")
        group = ParallelGroup([_make_agent("g1"), _make_agent("g2")])
        pipeline = Pipeline([agent, group])

        events = [e async for e in pipeline.astream("input")]
        stage_names = {e.stage_name for e in events}
        assert len(stage_names) == 2


# ---------------------------------------------------------------------------
# Sync streaming
# ---------------------------------------------------------------------------


class TestPipelineSyncStream:
    """Tests for the synchronous stream() wrapper."""

    def test_sync_stream_yields_stage_events(self):
        """Pipeline.stream() yields StageEvent objects synchronously."""
        agent = _make_agent("sync-streamed")
        pipeline = Pipeline([agent])

        events = list(pipeline.stream("input"))
        assert len(events) >= 1
        assert all(isinstance(e, StageEvent) for e in events)

    def test_sync_stream_two_stages(self):
        """Sync stream from two stages produces events from both."""
        agent_a = _make_agent("first")
        agent_b = _make_agent("second")
        pipeline = Pipeline([agent_a, agent_b])

        events = list(pipeline.stream("input"))
        stage_names = {e.stage_name for e in events}
        assert len(stage_names) == 2


# ---------------------------------------------------------------------------
# PipelineError re-raise
# ---------------------------------------------------------------------------


class TestPipelineErrorReRaise:
    """Tests for PipelineError passthrough (not double-wrapped)."""

    @pytest.mark.asyncio
    async def test_pipeline_error_not_double_wrapped(self):
        """A PipelineError raised by a nested pipeline is re-raised as-is."""
        inner_agent = _make_failing_agent(RuntimeError("inner boom"))
        inner_pipeline = Pipeline([inner_agent])

        # Wrap inner pipeline in an object that quacks like an agent
        class PipelineStage:
            instructions = "inner pipeline"

            async def arun(self, prompt):
                return await inner_pipeline.arun(prompt)

            async def astream(self, prompt):
                async for e in inner_pipeline.astream(prompt):
                    yield e

        outer = Pipeline([PipelineStage()])

        with pytest.raises(PipelineError) as exc_info:
            await outer.arun("go")

        # The error should be from the inner pipeline (step 0),
        # not re-wrapped by the outer pipeline
        assert exc_info.value.failed_step == 0
