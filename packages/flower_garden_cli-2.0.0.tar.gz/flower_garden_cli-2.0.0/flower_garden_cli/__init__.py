"""
Flower Garden CLI v2.0
A living, breathing terminal garden with weather, seasons, ecosystems, and achievements.
"""

__version__ = "2.0.0"
__author__ = "David Zhang"
__email__ = "davzhang77@gmail.com"

from .main import main

__all__ = ["main"]
