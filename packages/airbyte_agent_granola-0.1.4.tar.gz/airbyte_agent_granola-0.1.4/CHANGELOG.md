# Granola changelog

## [0.1.4] - 2026-02-20
- Updated connector definition (YAML version 1.0.2)
- Source commit: fc238ee4
- SDK version: 0.1.0

## [0.1.3] - 2026-02-20
- Updated connector definition (YAML version 1.0.1)
- Source commit: cb4380e7
- SDK version: 0.1.0

## [0.1.2] - 2026-02-19
- Updated connector definition (YAML version 1.0.1)
- Source commit: 7cda3ed1
- SDK version: 0.1.0

## [0.1.1] - 2026-02-19
- Updated connector definition (YAML version 1.0.1)
- Source commit: 3f4da97b
- SDK version: 0.1.0

## [0.1.0] - 2026-02-12
- Updated connector definition (YAML version 1.0.1)
- Source commit: 7afbc8f0
- SDK version: 0.1.0
