# Notes: Omni SDK

## Upstream Omni Facts
- API backend version constant: `2`.
- gRPC gateway API path prefix: `/api`.
- Method path shape: `/api/<service>/<method>`.
- Service-account signing uses headers:
  - `Grpc-Metadata-x-sidero-timestamp`
  - `Grpc-Metadata-x-sidero-payload`
  - `Grpc-Metadata-x-sidero-signature`
- Signature format: `siderov1 <identity> <fingerprint> <base64_signature>`.

## Config decisions
- Config precedence: dict > explicit path > `OMNI_SDK_CONFIG` > default path lookup.
- Default config locations:
  - Linux/macOS: `~/.config/omnisdk/config.{yml,yaml,toml,json}`
  - Windows: `%LOCALAPPDATA%/omnisdk/config.{yml,yaml,toml,json}`

## Implementation strategy
- Build async transport first, then typed APIs, then sync wrappers and CLI.
- Keep generated-model pipeline script-based with placeholder baseline generation in this iteration.

## Follow-up implemented
- Unified sync/async client pattern added to `OmniClient` with async `a...` method pairs.
- Compatibility alias changed from `omni_sdk` to `omnisdk`.
