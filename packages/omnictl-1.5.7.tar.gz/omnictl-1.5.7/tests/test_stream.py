from __future__ import annotations

import httpx
import pytest

from omni.http.stream import StreamProtocolError, parse_gateway_stream


@pytest.mark.asyncio()
async def test_parse_gateway_stream_success() -> None:
    response = httpx.Response(
        200,
        content=b'{"result":{"a":1}}\n{"result":{"a":2}}\n',
    )
    items = [item async for item in parse_gateway_stream(response)]
    assert items == [{"a": 1}, {"a": 2}]


@pytest.mark.asyncio()
async def test_parse_gateway_stream_error() -> None:
    response = httpx.Response(200, content=b'{"error":"boom"}\n')
    with pytest.raises(StreamProtocolError):
        _ = [item async for item in parse_gateway_stream(response)]
