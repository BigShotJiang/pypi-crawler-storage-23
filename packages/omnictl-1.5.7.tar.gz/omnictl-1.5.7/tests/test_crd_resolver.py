from __future__ import annotations

from omni.api.crd import resolver


def test_resolver_alias_hits_curated_entry() -> None:
    r = resolver()
    info = r.resolve("cluster")
    assert info is not None
    assert info.resource_type == "Clusters.omni.sidero.dev"


def test_resolver_fuzzy_search() -> None:
    r = resolver()
    info = r.resolve("kubernetesstatus")
    assert info is not None
    assert "KubernetesStatuses.omni.sidero.dev" == info.resource_type
