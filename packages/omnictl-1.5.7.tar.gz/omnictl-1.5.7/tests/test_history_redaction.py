from __future__ import annotations

from omni.cli.history import redact_argv, redacted_command


def test_redact_sensitive_long_flag_value() -> None:
    argv = ["omnipy", "talos", "--token", "abc123", "--cluster", "c1"]
    redacted = redact_argv(argv)
    assert redacted == ["omnipy", "talos", "--token", "<redacted>", "--cluster", "c1"]


def test_redact_sensitive_equal_form() -> None:
    argv = ["omnipy", "talos", "--authorization=Bearer abc", "get", "members"]
    redacted = redact_argv(argv)
    assert redacted[2] == "--authorization=<redacted>"


def test_redact_command_quotes() -> None:
    cmd = redacted_command(["omnipy", "kubeconfig", "--service-account-key", "secret-value"])
    assert "--service-account-key" in cmd
    assert "<redacted>" in cmd
    assert "secret-value" not in cmd

