from __future__ import annotations

from omni.config.models import CacheConfig, RetryConfig
from omni.http.cache import CacheController
from omni.http.retry import RetryPolicy
from omni.state import StateStore


def test_retry_policy_statuses() -> None:
    policy = RetryPolicy(RetryConfig())
    assert policy.should_retry_status(429)
    assert policy.should_retry_status(503)
    assert not policy.should_retry_status(404)


def test_cache_controller_basic() -> None:
    state = StateStore()
    cache = CacheController(CacheConfig(), state)

    key = cache.cache_key("omni.resources.ResourceService.Get", {"id": "abc"}, None, "default")
    assert cache.get(key) is None

    cache.set(key, {"ok": True}, ttl=60)
    assert cache.get(key) == {"ok": True}

    cache.invalidate_after_mutation("omni.resources.ResourceService.Update", "default")
    assert cache.get(key) is None

    state.close()
