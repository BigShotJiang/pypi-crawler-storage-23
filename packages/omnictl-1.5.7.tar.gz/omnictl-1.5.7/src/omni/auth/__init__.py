"""Authentication helpers."""

from omni.auth.service_account import (
    DEFAULT_SERVICE_ACCOUNT_ENV_ALIASES,
    ServiceAccount,
    decode_service_account,
    load_service_account_from_env,
)
from omni.auth.signer import (
    AUTHORIZATION_HEADER,
    INCLUDED_GRPC_HEADERS,
    PAYLOAD_HEADER,
    SIGNATURE_HEADER,
    SIGNATURE_VERSION,
    TIMESTAMP_HEADER,
    SideroSigner,
    SignedHeaders,
)

__all__ = [
    "AUTHORIZATION_HEADER",
    "DEFAULT_SERVICE_ACCOUNT_ENV_ALIASES",
    "INCLUDED_GRPC_HEADERS",
    "PAYLOAD_HEADER",
    "SIGNATURE_HEADER",
    "SIGNATURE_VERSION",
    "TIMESTAMP_HEADER",
    "ServiceAccount",
    "SideroSigner",
    "SignedHeaders",
    "decode_service_account",
    "load_service_account_from_env",
]
