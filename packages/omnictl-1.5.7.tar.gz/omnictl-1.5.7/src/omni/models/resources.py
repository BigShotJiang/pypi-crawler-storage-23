"""Curated resource models."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from omni.models.base import OmniModel


class ResourceMetadata(OmniModel):
    namespace: str
    type: str
    id: str
    version: int | None = None


class ResourceObject(OmniModel):
    metadata: ResourceMetadata
    spec: dict[str, Any] = Field(default_factory=dict)


class ResourceList(OmniModel):
    items: list[ResourceObject] = Field(default_factory=list)
