"""Curated management models."""

from __future__ import annotations

from pydantic import Field

from omni.models.base import OmniModel


class ServiceAccount(OmniModel):
    name: str
    role: str | None = None
    public_key_id: str | None = None


class ListServiceAccountsResponse(OmniModel):
    service_accounts: list[ServiceAccount] = Field(default_factory=list)


class KubeconfigResponse(OmniModel):
    kubeconfig: str


class TalosconfigResponse(OmniModel):
    talosconfig: str
