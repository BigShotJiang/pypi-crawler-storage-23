"""Curated CRD metadata overrides for DX-critical resource types."""

from __future__ import annotations

CRD_OVERRIDES: dict[str, dict[str, object]] = {
    "Clusters.omni.sidero.dev": {
        "aliases": ["cluster", "clusters"],
        "description": (
            "Cluster desired-state resource. Defines Talos/Kubernetes versions, feature flags, "
            "and settings for an Omni-managed cluster."
        ),
    },
    "ClusterStatuses.omni.sidero.dev": {
        "aliases": ["clusterstatus", "clusterstatuses"],
        "description": "Controller-managed status resource that reports cluster health and readiness.",
    },
    "Machines.omni.sidero.dev": {
        "aliases": ["machine", "machines"],
        "description": "Registered machine inventory resource discovered or provisioned through Omni.",
    },
    "MachineStatuses.omni.sidero.dev": {
        "aliases": ["machinestatus", "machinestatuses"],
        "description": "Controller-managed per-machine health/status snapshot.",
    },
    "Users.omni.sidero.dev": {
        "aliases": ["user", "users"],
        "description": "Omni user identity and role mapping resource.",
    },
    "JoinTokens.omni.sidero.dev": {
        "aliases": ["jointoken", "jointokens"],
        "description": "Machine/provider enrollment tokens for joining infrastructure to Omni.",
    },
}
