"""Curated pydantic model bases."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class OmniModel(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)


class DynamicModel(OmniModel):
    """Fallback model used when no curated/generated model exists."""

    pass


def model_from_payload(payload: dict[str, Any]) -> DynamicModel:
    return DynamicModel.model_validate(payload)
