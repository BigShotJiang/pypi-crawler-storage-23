"""RPC method metadata and helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True, slots=True)
class RpcMethod:
    """Metadata for an Omni RPC exposed through grpc-gateway."""

    service: str
    name: str
    stream: bool = False
    idempotent: bool = False

    @property
    def fq_method(self) -> str:
        return f"/{self.service}/{self.name}"

    @property
    def path(self) -> str:
        return f"/api/{self.service}/{self.name}"

    @property
    def key(self) -> str:
        return f"{self.service}.{self.name}"


SAFE_RESOURCE_METHODS: Final[set[str]] = {
    "omni.resources.ResourceService.Get",
    "omni.resources.ResourceService.List",
    "omni.resources.ResourceService.Controllers",
    "omni.resources.ResourceService.DependencyGraph",
}

SAFE_MANAGEMENT_METHODS: Final[set[str]] = {
    "management.ManagementService.Kubeconfig",
    "management.ManagementService.Talosconfig",
    "management.ManagementService.Omniconfig",
    "management.ManagementService.ListServiceAccounts",
}

MUTATING_PREFIXES: Final[tuple[str, ...]] = (
    "Create",
    "Update",
    "Delete",
    "Destroy",
    "Renew",
    "Reset",
    "Teardown",
)


def is_likely_mutating(method_name: str) -> bool:
    return method_name.startswith(MUTATING_PREFIXES)
