"""Compatibility helpers for runtime/environment differences."""
