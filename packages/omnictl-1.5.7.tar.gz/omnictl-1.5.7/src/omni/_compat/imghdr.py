"""Compatibility shim for Python 3.13+ where stdlib `imghdr` was removed.

This module implements a subset of the former stdlib API used by downstream deps.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import BinaryIO


def _test_jpeg(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h[6:10] in (b"JFIF", b"Exif"):
        return "jpeg"
    return None


def _test_png(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h.startswith(b"\211PNG\r\n\032\n"):
        return "png"
    return None


def _test_gif(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    return None


def _test_tiff(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h[:2] in (b"MM", b"II"):
        return "tiff"
    return None


def _test_rgb(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h.startswith(b"\001\332"):
        return "rgb"
    return None


def _test_pbm(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if len(h) >= 3 and h[0:1] == b"P" and h[1:2] in b"14" and h[2:3].isspace():
        return "pbm"
    return None


def _test_pgm(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if len(h) >= 3 and h[0:1] == b"P" and h[1:2] in b"25" and h[2:3].isspace():
        return "pgm"
    return None


def _test_ppm(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if len(h) >= 3 and h[0:1] == b"P" and h[1:2] in b"36" and h[2:3].isspace():
        return "ppm"
    return None


def _test_rast(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h.startswith(b"\x59\xa6\x6a\x95"):
        return "rast"
    return None


def _test_xbm(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h.startswith(b"#define"):
        return "xbm"
    return None


def _test_bmp(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h.startswith(b"BM"):
        return "bmp"
    return None


def _test_webp(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h.startswith(b"RIFF") and h[8:12] == b"WEBP":
        return "webp"
    return None


def _test_exr(h: bytes, f: BinaryIO | None) -> str | None:  # noqa: ARG001
    if h.startswith(b"\x76\x2f\x31\x01"):
        return "exr"
    return None


tests: list[Callable[[bytes, BinaryIO | None], str | None]] = [
    _test_jpeg,
    _test_png,
    _test_gif,
    _test_tiff,
    _test_rgb,
    _test_pbm,
    _test_pgm,
    _test_ppm,
    _test_rast,
    _test_xbm,
    _test_bmp,
    _test_webp,
    _test_exr,
]


def what(file: str | bytes | BinaryIO, h: bytes | None = None) -> str | None:
    f = None
    try:
        if h is None:
            if isinstance(file, (str, bytes)):
                with open(file, "rb") as fobj:
                    h = fobj.read(32)
            else:
                f = file
                location = file.tell()
                h = file.read(32)
                file.seek(location)

        if h is None:
            return None

        for test in tests:
            result = test(h, f)
            if result:
                return result
        return None
    except OSError:
        return None
