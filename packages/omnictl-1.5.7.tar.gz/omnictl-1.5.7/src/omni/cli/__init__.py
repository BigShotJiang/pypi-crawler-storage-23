"""CLI package."""

from omni.cli.main import app

__all__ = ["app"]
