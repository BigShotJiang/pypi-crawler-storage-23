"""Service API facades."""

from omni.api.auth import AuthAPI
from omni.api.crd import CRDCatalogResolver, CRDInfo, resolver
from omni.api.management import ManagementAPI
from omni.api.oidc import OIDCAPI
from omni.api.resources import ResourceAPI

__all__ = [
    "AuthAPI",
    "CRDCatalogResolver",
    "CRDInfo",
    "ManagementAPI",
    "OIDCAPI",
    "ResourceAPI",
    "resolver",
]
