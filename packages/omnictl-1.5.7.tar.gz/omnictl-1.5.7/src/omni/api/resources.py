"""Resource service API facade."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from omni.generated import methods
from omni.http.transport import OmniTransport

DEFAULT_RUNTIME = "Omni"


def _with_default_runtime(metadata: dict[str, str] | None) -> dict[str, str]:
    merged = dict(metadata or {})
    merged.setdefault("runtime", DEFAULT_RUNTIME)
    return merged


class ResourceAPI:
    def __init__(self, transport: OmniTransport) -> None:
        self._transport = transport

    async def get(self, request: dict[str, Any], *, metadata: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._transport.call(methods.RESOURCE_GET, request, metadata=_with_default_runtime(metadata))

    async def list(self, request: dict[str, Any], *, metadata: dict[str, str] | None = None) -> dict[str, Any]:
        return await self._transport.call(methods.RESOURCE_LIST, request, metadata=_with_default_runtime(metadata))

    async def create(
        self, request: dict[str, Any], *, metadata: dict[str, str] | None = None
    ) -> dict[str, Any]:
        return await self._transport.call(
            methods.RESOURCE_CREATE,
            request,
            metadata=_with_default_runtime(metadata),
        )

    async def update(
        self, request: dict[str, Any], *, metadata: dict[str, str] | None = None
    ) -> dict[str, Any]:
        return await self._transport.call(
            methods.RESOURCE_UPDATE,
            request,
            metadata=_with_default_runtime(metadata),
        )

    async def delete(
        self, request: dict[str, Any], *, metadata: dict[str, str] | None = None
    ) -> dict[str, Any]:
        return await self._transport.call(
            methods.RESOURCE_DELETE,
            request,
            metadata=_with_default_runtime(metadata),
        )

    async def teardown(
        self, request: dict[str, Any], *, metadata: dict[str, str] | None = None
    ) -> dict[str, Any]:
        return await self._transport.call(
            methods.RESOURCE_TEARDOWN,
            request,
            metadata=_with_default_runtime(metadata),
        )

    async def watch(
        self, request: dict[str, Any], *, metadata: dict[str, str] | None = None
    ) -> AsyncIterator[dict[str, Any]]:
        async for event in self._transport.stream(
            methods.RESOURCE_WATCH,
            request,
            metadata=_with_default_runtime(metadata),
        ):
            yield event

    async def controllers(
        self, request: dict[str, Any], *, metadata: dict[str, str] | None = None
    ) -> dict[str, Any]:
        return await self._transport.call(
            methods.RESOURCE_CONTROLLERS,
            request,
            metadata=_with_default_runtime(metadata),
        )

    async def dependency_graph(
        self, request: dict[str, Any], *, metadata: dict[str, str] | None = None
    ) -> dict[str, Any]:
        return await self._transport.call(
            methods.RESOURCE_DEPENDENCY_GRAPH,
            request,
            metadata=_with_default_runtime(metadata),
        )
