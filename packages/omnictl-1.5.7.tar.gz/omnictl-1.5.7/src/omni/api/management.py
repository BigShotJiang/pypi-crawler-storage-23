"""Management service API facade."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from omni.generated import methods
from omni.http.transport import OmniTransport


class ManagementAPI:
    def __init__(self, transport: OmniTransport) -> None:
        self._transport = transport

    async def kubeconfig(
        self,
        request: dict[str, Any],
        *,
        metadata: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_KUBECONFIG, request, metadata=metadata)

    async def talosconfig(
        self,
        request: dict[str, Any],
        *,
        metadata: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_TALOSCONFIG, request, metadata=metadata)

    async def omniconfig(
        self,
        request: dict[str, Any] | None = None,
        *,
        metadata: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._transport.call(
            methods.MANAGEMENT_OMNICONFIG,
            request or {},
            metadata=metadata,
        )

    async def machine_logs(self, request: dict[str, Any]) -> AsyncIterator[dict[str, Any]]:
        async for item in self._transport.stream(methods.MANAGEMENT_MACHINE_LOGS, request):
            yield item

    async def validate_config(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_VALIDATE_CONFIG, request)

    async def validate_json_schema(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_VALIDATE_JSONSCHEMA, request)

    async def create_service_account(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_CREATE_SERVICE_ACCOUNT, request)

    async def renew_service_account(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_RENEW_SERVICE_ACCOUNT, request)

    async def list_service_accounts(self) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_LIST_SERVICE_ACCOUNTS, {})

    async def destroy_service_account(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_DESTROY_SERVICE_ACCOUNT, request)

    async def kubernetes_upgrade_pre_checks(
        self,
        request: dict[str, Any],
        *,
        metadata: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await self._transport.call(
            methods.MANAGEMENT_KUBERNETES_UPGRADE_PRE_CHECKS,
            request,
            metadata=metadata,
        )

    async def kubernetes_sync_manifests(
        self,
        request: dict[str, Any],
        *,
        metadata: dict[str, str] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        async for item in self._transport.stream(
            methods.MANAGEMENT_KUBERNETES_SYNC_MANIFESTS,
            request,
            metadata=metadata,
        ):
            yield item

    async def create_schematic(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_CREATE_SCHEMATIC, request)

    async def get_support_bundle(self, request: dict[str, Any]) -> AsyncIterator[dict[str, Any]]:
        async for item in self._transport.stream(methods.MANAGEMENT_GET_SUPPORT_BUNDLE, request):
            yield item

    async def read_audit_log(self, request: dict[str, Any]) -> AsyncIterator[dict[str, Any]]:
        async for item in self._transport.stream(methods.MANAGEMENT_READ_AUDIT_LOG, request):
            yield item

    async def maintenance_upgrade(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_MAINTENANCE_UPGRADE, request)

    async def get_machine_join_config(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_GET_MACHINE_JOIN_CONFIG, request)

    async def create_join_token(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_CREATE_JOIN_TOKEN, request)

    async def reset_node_unique_token(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.MANAGEMENT_RESET_NODE_UNIQUE_TOKEN, request)
