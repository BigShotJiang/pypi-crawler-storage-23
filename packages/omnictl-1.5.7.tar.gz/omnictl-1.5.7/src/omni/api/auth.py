"""Auth service facade."""

from __future__ import annotations

from typing import Any

from omni.generated import methods
from omni.http.transport import OmniTransport


class AuthAPI:
    def __init__(self, transport: OmniTransport) -> None:
        self._transport = transport

    async def register_public_key(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.AUTH_REGISTER_PUBLIC_KEY, request)

    async def await_public_key_confirmation(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.AUTH_AWAIT_PUBLIC_KEY_CONFIRMATION, request)

    async def confirm_public_key(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.AUTH_CONFIRM_PUBLIC_KEY, request)

    async def revoke_public_key(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.AUTH_REVOKE_PUBLIC_KEY, request)
