"""OIDC service facade."""

from __future__ import annotations

from typing import Any

from omni.generated import methods
from omni.http.transport import OmniTransport


class OIDCAPI:
    def __init__(self, transport: OmniTransport) -> None:
        self._transport = transport

    async def authenticate(self, request: dict[str, Any]) -> dict[str, Any]:
        return await self._transport.call(methods.OIDC_AUTHENTICATE, request)
