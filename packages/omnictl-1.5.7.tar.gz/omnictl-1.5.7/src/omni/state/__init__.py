"""Persistent state primitives."""

from omni.state.store import StateStore, default_state_path

__all__ = ["StateStore", "default_state_path"]
