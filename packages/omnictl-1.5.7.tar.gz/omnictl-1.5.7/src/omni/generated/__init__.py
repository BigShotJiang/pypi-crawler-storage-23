"""Generated artifacts for Omni SDK."""

from omni.generated.crd_catalog import CRD_CATALOG
from omni.generated.methods import ALL_METHODS

__all__ = ["ALL_METHODS", "CRD_CATALOG"]
