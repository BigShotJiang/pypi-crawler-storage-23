"""Client entrypoints."""

from omni.client.async_client import AsyncOmniClient
from omni.client.singleton import (
    configure,
    get_client,
    get_sync_client,
    get_unified_client,
    set_default_cluster,
    set_default_instance,
    use_cluster,
    use_instance,
)
from omni.client.sync_client import OmniClient

__all__ = [
    "AsyncOmniClient",
    "OmniClient",
    "configure",
    "get_client",
    "get_sync_client",
    "get_unified_client",
    "set_default_cluster",
    "set_default_instance",
    "use_cluster",
    "use_instance",
]
