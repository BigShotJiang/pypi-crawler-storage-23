"""Compatibility alias for `omni` package."""

from omni import *  # noqa: F401,F403
