"""Basic omnictl usage examples."""

from __future__ import annotations

import asyncio

from omni import OmniClient


def sync_example() -> None:
    client = OmniClient()
    try:
        print(client.list_service_accounts())
    finally:
        client.close()


async def async_example() -> None:
    async with OmniClient() as client:
        print(await client.alist_service_accounts())


if __name__ == "__main__":
    sync_example()
    asyncio.run(async_example())
