"""Compatibility import alias example (`omnisdk`)."""

from __future__ import annotations

import omnisdk


def main() -> None:
    client = omnisdk.OmniClient()
    try:
        payload = client.list_service_accounts()
        print(f"service accounts payload keys: {sorted(payload.keys())}")
    finally:
        client.close()


if __name__ == "__main__":
    main()
