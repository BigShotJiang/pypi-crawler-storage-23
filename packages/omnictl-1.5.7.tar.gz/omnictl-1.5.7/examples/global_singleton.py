"""Global/singleton client helpers and context overrides."""

from __future__ import annotations

from omni import configure, get_sync_client, use_cluster


def main() -> None:
    configure()

    client = get_sync_client()
    clusters = client.resources.list({"namespace": "default", "type": "Clusters.omni.sidero.dev"})
    print(f"default context cluster count: {len(clusters.get('items', []))}")

    # Override cluster only for this scope.
    with use_cluster("halceon"):
        scoped = get_sync_client()
        statuses = scoped.resources.list({"namespace": "default", "type": "ClusterStatuses.omni.sidero.dev"})
        print(f"scoped context status count: {len(statuses.get('items', []))}")


if __name__ == "__main__":
    main()
