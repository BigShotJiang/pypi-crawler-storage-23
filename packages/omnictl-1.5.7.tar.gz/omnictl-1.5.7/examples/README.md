# Examples

All examples assume you already have Omni credentials configured (for example in `~/.config/omnisdk/config.yml`).

Run examples with `uv`:

```bash
uv run python examples/<file>.py
```

Available examples:

- `basic_usage.py`: minimal sync + async calls on one unified client.
- `sync_resource_queries.py`: list clusters and machine hostnames (sync).
- `async_resource_queries.py`: async cluster and machine-status queries.
- `config_sources.py`: config precedence and loading from dict/path/env.
- `global_singleton.py`: global client helpers and temporary context overrides.
- `export_access_configs.py`: fetch kubeconfig and ensure managed talosconfig.
- `audit_log_stream.py`: stream and decode audit log chunks.
- `compat_alias.py`: use the `omnisdk` compatibility import.
