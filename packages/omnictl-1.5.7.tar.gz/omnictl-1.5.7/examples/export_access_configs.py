"""Fetch kubeconfig and ensure managed talosconfig for a cluster."""

from __future__ import annotations

import base64
from pathlib import Path

from omni import OmniClient


def main() -> None:
    cluster = "halceon"
    out_dir = Path("artifacts")
    out_dir.mkdir(parents=True, exist_ok=True)

    client = OmniClient()
    try:
        kube_payload = client.get_kubeconfig(service_account=False, break_glass=False)
        kubeconfig_raw = kube_payload.get("kubeconfig")
        if isinstance(kubeconfig_raw, str):
            kube_path = out_dir / f"{cluster}.kubeconfig"
            kube_path.write_bytes(base64.b64decode(kubeconfig_raw))
            print(f"wrote {kube_path}")

        talos_path = client.ensure_talosconfig(cluster=cluster)
        print(f"managed talosconfig: {talos_path}")
    finally:
        client.close()


if __name__ == "__main__":
    main()
