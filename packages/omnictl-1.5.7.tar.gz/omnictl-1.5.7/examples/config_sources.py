"""Config source examples: dict, explicit path, and OMNI_SDK_CONFIG."""

from __future__ import annotations

import os
from pathlib import Path

from omni import OmniClient


def from_dict() -> None:
    client = OmniClient(
        config={
            "default_instance": "lab",
            "instances": {
                "lab": {
                    "url": "https://omni.example.invalid",
                }
            },
        }
    )
    try:
        print("constructed client from dict config")
    finally:
        client.close()


def from_path(path: Path) -> None:
    client = OmniClient(config_path=path)
    try:
        print(f"constructed client from config_path={path}")
    finally:
        client.close()


def from_env(path: Path) -> None:
    os.environ["OMNI_SDK_CONFIG"] = str(path)
    client = OmniClient()
    try:
        print("constructed client from OMNI_SDK_CONFIG")
    finally:
        client.close()
    os.environ.pop("OMNI_SDK_CONFIG", None)


if __name__ == "__main__":
    default_cfg = Path.home() / ".config" / "omnisdk" / "config.yml"
    from_dict()
    if default_cfg.exists():
        from_path(default_cfg)
        from_env(default_cfg)
    else:
        print(f"skip path/env examples: missing {default_cfg}")
