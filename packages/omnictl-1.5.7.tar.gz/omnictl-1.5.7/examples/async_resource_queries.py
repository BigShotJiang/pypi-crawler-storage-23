"""Async resource queries using the unified client (`a*` methods)."""

from __future__ import annotations

import asyncio

from omni import OmniClient


async def main() -> None:
    async with OmniClient() as client:
        clusters = await client.alist_resources("default", "Clusters.omni.sidero.dev")
        print(f"clusters payload keys: {sorted(clusters.keys())}")

        machine_statuses = await client.alist_resources("default", "MachineStatuses.omni.sidero.dev")
        print(f"machine status count: {len(machine_statuses.get('items', []))}")


if __name__ == "__main__":
    asyncio.run(main())
