"""Stream audit logs with async iteration."""

from __future__ import annotations

import asyncio
import base64

from omni import AsyncOmniClient


async def main() -> None:
    client = AsyncOmniClient()
    try:
        async for event in client.management.read_audit_log(
            {"start_time": "2026-01-01", "end_time": "2026-01-02"}
        ):
            chunk = event.get("audit_log")
            if isinstance(chunk, str):
                print(base64.b64decode(chunk).decode("utf-8"), end="")
    finally:
        await client.aclose()


if __name__ == "__main__":
    asyncio.run(main())
