from ._fixed_fields import FixedCategoricalJointObsField

__all__ = ["FixedCategoricalJointObsField"]
