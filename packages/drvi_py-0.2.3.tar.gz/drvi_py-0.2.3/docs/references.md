# References

If DRVI is helpful in your research, please consider citing {cite:p}`Moinfar2024-cx`.
For other references used in the documentation see below:

```{bibliography}
:cited:
```
