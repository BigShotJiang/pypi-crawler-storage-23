"""
biblioteca destinada à integração com o SharePoint, utilizando a biblioteca automaweb.
"""

import automaweb

