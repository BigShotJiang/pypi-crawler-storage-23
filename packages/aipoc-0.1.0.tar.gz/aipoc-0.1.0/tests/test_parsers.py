"""Tests for poc parsers — written BEFORE implementation (test-first).

Expected counts from fixtures:
- Claude Code for /Users/test/my-app: 5 prompts (from history.jsonl)
- Claude Code for /Users/test/backend: 3 prompts
- Claude Code sessions for my-app: 2 user messages (sess-001) + 3 user messages (sess-002) = 5
- Codex CLI for /Users/test/my-app: 3 prompts (excluding system/developer messages)
- Codex CLI for /Users/test/backend: 2 prompts
- Cursor for /Users/test/my-app: 4 composer sessions + 2 chat prompts = 6
- Cursor for /Users/test/backend: 0 (empty workspace)

Total for /Users/test/my-app across all tools: 5 (claude) + 3 (codex) + 6 (cursor) = 14
Total for /Users/test/backend: 3 (claude) + 2 (codex) + 0 (cursor) = 5
"""
import json
import sys
import unittest
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

FIXTURES = Path(__file__).parent / "fixtures"


class TestClaudeParser(unittest.TestCase):
    def test_count_from_history(self):
        from poc.parsers.claude import count_from_history
        counts = count_from_history(FIXTURES / "claude" / "history.jsonl")
        self.assertEqual(counts["/Users/test/my-app"], 5)
        self.assertEqual(counts["/Users/test/backend"], 3)

    def test_count_from_sessions(self):
        from poc.parsers.claude import count_from_sessions
        project_dir = FIXTURES / "claude" / "projects" / "-Users-test-my-app"
        result = count_from_sessions(project_dir)
        self.assertEqual(result["total_prompts"], 5)
        self.assertEqual(result["sessions"], 2)

    def test_count_for_project(self):
        from poc.parsers.claude import count_for_project
        result = count_for_project("/Users/test/my-app", FIXTURES / "claude")
        self.assertEqual(result["prompts"], 5)
        self.assertEqual(result["sessions"], 2)


class TestCodexParser(unittest.TestCase):
    def test_count_for_project(self):
        from poc.parsers.codex import count_for_project
        result = count_for_project("/Users/test/my-app", FIXTURES / "codex")
        self.assertEqual(result["prompts"], 3)
        self.assertEqual(result["sessions"], 1)

    def test_count_for_different_project(self):
        from poc.parsers.codex import count_for_project
        result = count_for_project("/Users/test/backend", FIXTURES / "codex")
        self.assertEqual(result["prompts"], 2)
        self.assertEqual(result["sessions"], 1)

    def test_filters_system_messages(self):
        """Developer/system role messages and AGENTS.md user messages should be excluded."""
        from poc.parsers.codex import count_for_project
        result = count_for_project("/Users/test/my-app", FIXTURES / "codex")
        # Only real user prompts, not developer or system-injected user messages
        self.assertEqual(result["prompts"], 3)


class TestCursorParser(unittest.TestCase):
    def test_count_for_project(self):
        from poc.parsers.cursor import count_for_project
        result = count_for_project("/Users/test/my-app", FIXTURES / "cursor")
        self.assertEqual(result["composer_sessions"], 4)
        self.assertEqual(result["chat_prompts"], 2)
        self.assertEqual(result["prompts"], 6)

    def test_empty_workspace(self):
        from poc.parsers.cursor import count_for_project
        result = count_for_project("/Users/test/backend", FIXTURES / "cursor")
        self.assertEqual(result["prompts"], 0)

    def test_unknown_project(self):
        from poc.parsers.cursor import count_for_project
        result = count_for_project("/Users/test/nonexistent", FIXTURES / "cursor")
        self.assertEqual(result["prompts"], 0)


class TestClaudeChats(unittest.TestCase):
    def test_list_chats(self):
        from poc.parsers.claude import list_chats
        chats = list_chats("/Users/test/my-app", FIXTURES / "claude")
        self.assertEqual(len(chats), 2)
        # Should be sorted by modified date descending (most recent first)
        self.assertEqual(chats[0]["first_prompt"], "fix the CSS bug")
        self.assertEqual(chats[0]["message_count"], 6)
        self.assertEqual(chats[0]["tool"], "claude")
        self.assertEqual(chats[1]["first_prompt"], "create a hello world app")

    def test_list_chats_empty_project(self):
        from poc.parsers.claude import list_chats
        chats = list_chats("/Users/test/nonexistent", FIXTURES / "claude")
        self.assertEqual(len(chats), 0)


class TestCodexChats(unittest.TestCase):
    def test_list_chats(self):
        from poc.parsers.codex import list_chats
        chats = list_chats("/Users/test/my-app", FIXTURES / "codex")
        self.assertEqual(len(chats), 1)
        self.assertEqual(chats[0]["first_prompt"], "build me a todo app")
        self.assertEqual(chats[0]["prompts"], 3)
        self.assertEqual(chats[0]["tool"], "codex")

    def test_list_chats_empty(self):
        from poc.parsers.codex import list_chats
        chats = list_chats("/Users/test/nonexistent", FIXTURES / "codex")
        self.assertEqual(len(chats), 0)


class TestCursorChats(unittest.TestCase):
    def test_list_chats(self):
        from poc.parsers.cursor import list_chats
        chats = list_chats("/Users/test/my-app", FIXTURES / "cursor")
        self.assertEqual(len(chats), 4)
        # Sorted by most recent first
        self.assertEqual(chats[0]["name"], "Styling")
        self.assertEqual(chats[0]["tool"], "cursor")

    def test_list_chats_empty(self):
        from poc.parsers.cursor import list_chats
        chats = list_chats("/Users/test/nonexistent", FIXTURES / "cursor")
        self.assertEqual(len(chats), 0)


class TestAggregatorChats(unittest.TestCase):
    def test_list_all_chats(self):
        from poc.aggregator import list_all_chats
        chats = list_all_chats("/Users/test/my-app", {
            "claude": FIXTURES / "claude",
            "codex": FIXTURES / "codex",
            "cursor": FIXTURES / "cursor",
        })
        # 2 claude + 1 codex + 4 cursor = 7 total chats
        self.assertEqual(len(chats), 7)
        # Should be sorted by date, most recent first across all tools
        # All should have a 'tool' field
        tools = set(c["tool"] for c in chats)
        self.assertEqual(tools, {"claude", "codex", "cursor"})


class TestAggregator(unittest.TestCase):
    def test_total_for_project(self):
        from poc.aggregator import count_all
        result = count_all("/Users/test/my-app", {
            "claude": FIXTURES / "claude",
            "codex": FIXTURES / "codex",
            "cursor": FIXTURES / "cursor",
        })
        self.assertEqual(result["total"], 14)
        self.assertEqual(result["by_tool"]["claude"]["prompts"], 5)
        self.assertEqual(result["by_tool"]["codex"]["prompts"], 3)
        self.assertEqual(result["by_tool"]["cursor"]["prompts"], 6)

    def test_total_for_backend(self):
        from poc.aggregator import count_all
        result = count_all("/Users/test/backend", {
            "claude": FIXTURES / "claude",
            "codex": FIXTURES / "codex",
            "cursor": FIXTURES / "cursor",
        })
        self.assertEqual(result["total"], 5)


if __name__ == "__main__":
    unittest.main()
