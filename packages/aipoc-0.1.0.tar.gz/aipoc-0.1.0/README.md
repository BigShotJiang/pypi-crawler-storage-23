# aipoc — Prompts of Codebase

Like `loc` counts lines of code, `aipoc` counts how many AI prompts built your codebase.

## Install

```
pip install aipoc
```

## Usage

```bash
aipoc                    # current directory
aipoc /path/to/project   # specific project
aipoc --all              # all projects ranked by prompt count
aipoc --deep             # show all chat sessions, not just top 10
aipoc --json             # machine-readable output
```

## Example output

```
   aipoc — Prompts of Codebase
  /Users/sam/my-project

  ├───────────────────────────────────────────────────┤
  │ Tool             │   Prompts│  Sessions│ Details  │
  ├───────────────────────────────────────────────────┤
  │ Claude Code      │      2929│      1252│ history  │
  │ Codex CLI        │        88│        56│          │
  ├───────────────────────────────────────────────────┤
  │ TOTAL            │      3017│          │          │
  ├───────────────────────────────────────────────────┤

  Recent chats

    1. Codex CLI   Feb 10    11p  Hey, can you use exaMCP ?
    2. Claude Code Jan 22    14p  build the auth flow
    3. Claude Code Jan 21     8p  add dark mode
   ...

  ... and 553 more. Run with --deep to see all.
```

## Supported tools

| Tool | Data source |
|------|------------|
| **Claude Code** | `~/.claude/history.jsonl` + session files |
| **Codex CLI** | `~/.codex/sessions/` JSONL files |
| **Cursor** | `~/Library/.../Cursor/User/workspaceStorage/` SQLite |

Zero external dependencies — uses only Python stdlib.
