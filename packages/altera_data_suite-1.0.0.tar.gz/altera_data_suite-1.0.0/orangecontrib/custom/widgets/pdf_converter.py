from PyQt6.QtCore import QUrl, QObject, QThread, pyqtSignal, Qt, pyqtSlot
from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtWidgets import QLabel, QVBoxLayout
from PyQt6.QtWebEngineWidgets import QWebEngineView
from Orange.widgets.gui import ProgressBar
from Orange.widgets.widget import OWWidget, Output, Msg
from Orange.widgets.settings import Setting
from Orange.data import Table
import pkg_resources, os, base64, tempfile, json
from .auxiliary_functions import _f0, _f1, _f2, _f3, _f4


class _OW(QObject):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)
    progress = pyqtSignal(int)

    def __init__(self, pdf_path, opacity, zoom):
        super().__init__()
        self.pdf_path = pdf_path
        self.opacity = opacity
        self.zoom = zoom

    def run(self):
        try:
            output_path = os.path.join(tempfile.gettempdir(), "pdf_ink_overlay.png")

            def progress_callback(current, total):
                self.progress.emit(int((current / total) * 100))

            _f0(
                self.pdf_path,
                output_path,
                zoom=self.zoom,
                opacity=self.opacity,
                white_threshold=150,
                ink_color=(0, 0, 0),
                progress_cb=progress_callback,
            )
            with open(output_path, "rb") as f:
                img_data = base64.b64encode(f.read()).decode("utf-8")
            self.finished.emit(f"data:image/png;base64,{img_data}")
        except Exception as e:
            self.error.emit(str(e))


class _CW(QObject):
    progress = pyqtSignal(int)
    message = pyqtSignal(str)
    finished = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, file_path, tables_info, total_pages, dpi):
        super().__init__()
        self.file_path = file_path
        self.tables_info = tables_info
        self.total_pages = total_pages
        self.dpi = dpi

    def run(self):
        try:

            def progress_cb(current, total):
                self.progress.emit(int((current / total) * 100))
                self.message.emit(f"Processing page {current} / {total}")

            df = _f1(
                self.file_path,
                self.tables_info,
                self.total_pages,
                self.dpi,
                progress_cb,
            )
            self.finished.emit(df)
        except Exception as e:
            self.error.emit(str(e))


class _Br(QObject):
    def __init__(self, view, parent_widget):
        super().__init__()
        self.view = view
        self.parent_widget = parent_widget
        self.dpi = 150

    @pyqtSlot(str, str)
    def receivePdfData(self, filename, base64_data):
        try:
            pdf_bytes = base64.b64decode(base64_data)
            temp_dir = tempfile.gettempdir()
            safe_filename = "".join(
                c for c in filename if c.isalnum() or c in ("_", "-", ".")
            )
            temp_path = os.path.join(temp_dir, f"pdf_converter_{safe_filename}")
            with open(temp_path, "wb") as f:
                f.write(pdf_bytes)
            self.parent_widget.file_path = temp_path
            self.parent_widget.steps = _f4(temp_path)
        except Exception:
            pass

    @pyqtSlot(str)
    def setPdfPath(self, pdf_path):
        self.parent_widget.file_path = pdf_path
        self.parent_widget.steps = _f4(pdf_path)

    @pyqtSlot(str)
    def saveHtmlState(self, html_delimiters):
        try:
            data = json.loads(html_delimiters)
            self.parent_widget.ui_state = data
        except Exception:
            self.parent_widget.ui_state = {"rectangles": [], "guides": []}

    @pyqtSlot(str, int)
    def getCoordinatesFromJs(self, data, breaklines=1):
        if not self.parent_widget.file_path:
            self.view.page().runJavaScript(
                "alert('Error: No PDF loaded. Please load a PDF first.')"
            )
            return
        if not os.path.exists(self.parent_widget.file_path):
            self.view.page().runJavaScript("alert('Error: PDF file not found.')")
            return
        try:
            tables_info = json.loads(data)
        except Exception as e:
            self.view.page().runJavaScript(
                f"alert('Error parsing coordinates: {str(e)}')"
            )
            return
        self.parent_widget.tables_info_ui = tables_info
        self.parent_widget.break_lines = breaklines
        self.closeWidget()
        self.parent_widget.process_tables(tables_info)

    @pyqtSlot()
    def closeWidget(self):
        self.parent_widget.close()

    @pyqtSlot()
    def openFileDialog(self):
        from PyQt6.QtWidgets import QFileDialog

        file_path, _ = QFileDialog.getOpenFileName(
            self.view, "Open PDF File", "", "PDF Files (*.pdf)"
        )
        if file_path:
            self.parent_widget.file_path = file_path
            self.parent_widget.steps = _f4(file_path)
            safe_path = file_path.replace("\\", "\\\\").replace("'", "\\'")
            self.view.page().runJavaScript(
                f"if (window.loadPdfFromPath) {{ window.loadPdfFromPath('{safe_path}'); }}"
            )

    @pyqtSlot(str, float, float)
    def generateInkOverlay(self, pdf_path, opacity=0.3, zoom=2.0):
        self.overlay_thread = QThread()
        self.overlay_worker = _OW(pdf_path, opacity, zoom)
        self.overlay_worker.moveToThread(self.overlay_thread)
        self.overlay_thread.started.connect(self.overlay_worker.run)

        def on_overlay_finished(base64_data):
            self.view.page().runJavaScript(
                f"if (window.setInkOverlay) {{ window.setInkOverlay('{base64_data}'); }}"
            )
            self.overlay_thread.quit()
            self.overlay_thread.wait()

        def on_overlay_error(error_msg):
            self.view.page().runJavaScript(
                "if (window.setInkOverlayError) { window.setInkOverlayError(); }"
            )
            self.view.page().runJavaScript(
                f"alert('Failed to generate overlay: {error_msg}');"
            )
            self.overlay_thread.quit()
            self.overlay_thread.wait()

        def on_overlay_progress(percent):
            self.view.page().runJavaScript(
                f"if (window.setOverlayProgress) {{ window.setOverlayProgress({percent}); }}"
            )

        self.overlay_worker.finished.connect(on_overlay_finished)
        self.overlay_worker.progress.connect(on_overlay_progress)
        self.overlay_worker.error.connect(on_overlay_error)
        self.overlay_worker.finished.connect(self.overlay_worker.deleteLater)
        self.overlay_worker.error.connect(self.overlay_worker.deleteLater)
        self.overlay_thread.finished.connect(self.overlay_thread.deleteLater)
        self.overlay_thread.start()


class PdfConverter(OWWidget):
    name = "PDF Converter"
    description = "This is a PDF Table Extractor widget that lets you interactively extract tables from PDF documents. You can load PDFs, visually select table areas by drawing boundaries, set column delimiters."
    category = "Altera Data Suite"
    icon = "icons/pdf_converter.svg"
    want_main_area = True
    want_control_area = False
    priority = 1

    class Outputs:
        data = Output("Data", Table)

    file_path: str = Setting("", schema_only=True)
    break_lines: int = Setting(1, schema_only=True)
    ui_state: dict = Setting({"rectangles": [], "guides": []}, schema_only=True)
    tables_info_ui: list = Setting([], schema_only=True)

    class Error(OWWidget.Error):
        invalid_path = Msg("File path is invalid, File was not found.")
        processing_failed = Msg("Processing failed: {}")
        path_is_not_file = Msg("File path is not a PDF file.")

    class Warning(OWWidget.Warning):
        empty_input = Msg("No input data")
        partial_data = Msg("Some data is missing")

    class Information(OWWidget.Information):
        data_loaded = Msg("Data successfully loaded")
        processing_complete = Msg("Processing complete")

    def __init__(self):
        super().__init__()
        self.extracted_tables = []
        self.steps = 0
        self.pb = None
        self.counter = 0
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        self.status_label = QLabel("Ready")
        layout.addWidget(self.status_label)
        self.setup_webengine()
        self.mainArea.layout().addWidget(self.view)

    def setup_webengine(self):
        self.view = QWebEngineView()
        self.view.setContextMenuPolicy(Qt.NoContextMenu)
        self.channel = QWebChannel()
        self.bridge = _Br(self.view, self)
        self.channel.registerObject("bridge", self.bridge)
        self.view.page().setWebChannel(self.channel)
        try:
            html_path = pkg_resources.resource_filename(
                "orangecontrib.custom.widgets", "UI/pdf_converter_gui/index.html"
            )
            if os.path.exists(html_path):
                self.view.setUrl(QUrl.fromLocalFile(html_path))
        except Exception:
            pass
        self.view.loadFinished.connect(self.on_page_loaded)

    def on_page_loaded(self, ok):
        if not ok:
            return
        if self.file_path and os.path.exists(self.file_path):
            self.steps = _f4(self.file_path)
            safe_path = self.file_path.replace("\\", "\\\\").replace("'", "\\'")
            js_code = f"""
                if (window.loadPdfFromPath) {{
                    window.loadPdfFromPath('{safe_path}').then(() => {{
                        {self._get_restore_ui_state_js()}
                    }}).catch((err) => {{}});
                }}
            """
            self.view.page().runJavaScript(js_code)
        else:
            if self.ui_state and (
                self.ui_state.get("rectangles") or self.ui_state.get("guides")
            ):
                self.view.page().runJavaScript(self._get_restore_ui_state_js())

    def _get_restore_ui_state_js(self):
        if not self.ui_state or (
            not self.ui_state.get("rectangles") and not self.ui_state.get("guides")
        ):
            return ""
        json_data = json.dumps(self.ui_state)
        return f"""
            if (window.restoreAnnotations) {{
                window.restoreAnnotations({json_data});
            }}
        """

    def process_tables(self, tables_info):
        from .auxiliary_functions import verify_license

        if not verify_license():
            self.Error.processing_failed(
                "Invalid or expired license. Please contact support to renew."
            )
            return
        self.setBlocking(True)
        if not self.file_path or not os.path.exists(self.file_path):
            self.setBlocking(False)
            return
        if not tables_info or len(tables_info) == 0:
            self.setBlocking(False)
            return
        self.pb = ProgressBar(self, iterations=self.steps)
        self.counter = 0
        self.thread = QThread()
        self.worker = _CW(self.file_path, tables_info, self.steps, self.bridge.dpi)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)

        def on_progress(percent):
            if self.counter < self.steps:
                self.pb.advance()
                self.counter += 1

        self.worker.progress.connect(on_progress)

        def on_finished(df):
            self.pb.finish()
            self.setBlocking(False)
            self.view.page().runJavaScript(
                "if (window.showLoaderHandler) { window.showLoaderHandler(0); }"
            )
            if df is None:
                return
            table = _f2(df)
            self.Outputs.data.send(table)
            self.Error.clear()
            self.status_label.setText(_f3(self.file_path))

        self.worker.finished.connect(on_finished)

        def on_error(msg):
            self.Error.processing_failed(msg)
            self.setBlocking(False)
            if self.pb:
                self.pb.finish()

        self.worker.error.connect(on_error)

        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.worker.error.connect(self.thread.quit)
        self.worker.error.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def onDeleteWidget(self):
        if hasattr(self, "file_path") and self.file_path:
            if "pdf_converter_" in self.file_path and os.path.exists(self.file_path):
                try:
                    os.remove(self.file_path)
                except Exception:
                    pass
        super().onDeleteWidget()
