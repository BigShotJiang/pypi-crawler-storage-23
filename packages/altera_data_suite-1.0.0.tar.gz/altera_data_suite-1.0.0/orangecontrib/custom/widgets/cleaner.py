import os, json
from PyQt6.QtCore import QObject, pyqtSlot
from Orange.widgets import widget
from Orange.widgets.widget import Input, Output
from Orange.widgets.settings import Setting
from Orange.data import Table, StringVariable
from .web_utils import WebEngineMixin
from .auxiliary_functions import _o2d, _d2o, _aaco


class _Br(QObject):
    def __init__(self, _v, _pw):
        super().__init__()
        self._v = _v
        self._pw = _pw
        self._pj = []
        self._ld = False
        self._v.loadFinished.connect(self._ol)

    def _ol(self, ok):
        if ok:
            self._ld = True
            for _j in self._pj:
                self._v.page().runJavaScript(_j)
            self._pj.clear()

    def _rj(self, _j):
        if self._ld:
            self._v.page().runJavaScript(_j)
        else:
            self._pj.append(_j)

    def _sc(self, _d):
        self._rj(f"window.updateColumnDefinitions&&updateColumnDefinitions({_d});")

    def _rs(self, _s):
        self._rj(f"window.restoreCleaningState&&restoreCleaningState({_s});")

    def _sn(self):
        self._rj("window.showNoDataMessage&&showNoDataMessage();")

    @pyqtSlot(str)
    def cleaningChanged(self, _s):
        self._pw._occ(_s)


class OWCleaner(WebEngineMixin, widget.OWWidget):
    name = "Cleaner"
    description = "Clean and transform text columns with various operations"
    category = "Altera Data Suite"
    icon = "icons/cleaner.svg"
    priority = 30

    class Inputs:
        data = Input("Input Table", Table)

    class Outputs:
        cleaned_data = Output("Cleaned Data", Table)

    cleaning_state = Setting('{"operations":[]}')
    DESTROY_TIMEOUT = 300
    want_main_area = True
    want_control_area = False
    resizing_enabled = True

    class Error(widget.OWWidget.Error):
        license_error = widget.Msg("License error: {}")

    def __init__(self):
        super().__init__()
        self._id = None
        self._od = None
        self._df = None
        self._tc = []
        _h = os.path.join(os.path.dirname(__file__), "UI", "cleaner_ui", "index.html")
        self.setup_webengine_lazy(_h, _Br, zoom_factor=0.9)

    def on_webengine_ready(self):
        if self._id is not None and self._tc:
            self.bridge._sc(json.dumps(self._tc))
            self.bridge._rs(self.cleaning_state)
            self._ac()
        elif self.web_loaded and self.bridge:
            self.bridge._sn()

    def on_webengine_show(self):
        pass

    @Inputs.data
    def set_data(self, data):
        self.Error.clear()
        if data is None:
            self._id = None
            self._df = None
            self._od = None
            self._tc = []
            self.Outputs.cleaned_data.send(None)
            if self.web_loaded and self.bridge:
                self.bridge._sn()
            return
        self._id = data
        self._od = data.domain
        self._df = _o2d(data)
        self._tc = [
            v.name
            for v in list(data.domain.attributes)
            + list(data.domain.class_vars)
            + list(data.domain.metas)
            if isinstance(v, StringVariable)
        ]
        self._ac()
        if self.web_loaded and self.bridge:
            if self._tc:
                self.bridge._sc(json.dumps(self._tc))
                self.bridge._rs(self.cleaning_state)
            else:
                self.bridge._sn()

    def _occ(self, _s):
        self.cleaning_state = _s
        self._ac()

    def _ac(self):
        if self._df is None:
            self.Outputs.cleaned_data.send(None)
            return
        try:
            if not json.loads(self.cleaning_state).get("operations"):
                self.Outputs.cleaned_data.send(self._id)
                return
            self.Outputs.cleaned_data.send(
                _d2o(_aaco(self._df, self.cleaning_state), self._od)
            )
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.cleaned_data.send(None)
        except Exception as _e:
            print(f"[CLEANER] Cleaning error: {_e}")
            self.Outputs.cleaned_data.send(self._id)
