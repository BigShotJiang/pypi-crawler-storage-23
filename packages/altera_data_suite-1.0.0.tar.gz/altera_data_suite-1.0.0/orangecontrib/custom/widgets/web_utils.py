import os, time
from collections import OrderedDict
from PyQt6.QtCore import QUrl, Qt, QEvent
from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEnginePage
from PyQt6.QtWidgets import QMessageBox, QInputDialog

try:
    from PyQt6 import sip

    _SIP = True
except ImportError:
    _SIP = False


class _LRU:
    MAX = 5

    def __init__(self):
        self._q = OrderedDict()

    def touch(self, w):
        self._q[w] = time.time()
        self._q.move_to_end(w)

    def remove(self, w):
        self._q.pop(w, None)

    def _valid(self, w):
        try:
            if not hasattr(w, "web") or w.web is None:
                return False
            if _SIP:
                if sip.isdeleted(w.web):
                    return False
            else:
                try:
                    _ = w.web.isVisible
                except RuntimeError:
                    return False
            return True
        except (RuntimeError, AttributeError):
            return False

    def enforce_limit(self):
        if len(self._q) <= self.MAX:
            return
        for w in [x for x in self._q if not self._valid(x)]:
            self.remove(w)
        if len(self._q) <= self.MAX:
            return
        for w in list(self._q.keys()):
            if not self._valid(w):
                self.remove(w)
                continue
            try:
                if not w.web.isVisible():
                    w._destroy_webengine()
                    self.remove(w)
                    return
            except (RuntimeError, AttributeError):
                self.remove(w)
                continue


_LRU_MGR = _LRU()


class _Page(QWebEnginePage):
    def javaScriptAlert(self, o, msg):
        QMessageBox.information(None, "Message", msg)

    def javaScriptConfirm(self, o, msg):
        return (
            QMessageBox.question(
                None,
                "Confirm",
                msg,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            == QMessageBox.StandardButton.Yes
        )

    def javaScriptPrompt(self, o, msg, default, result):
        text, ok = QInputDialog.getText(None, "Input", msg, text=default)
        if ok:
            result.append(text)
            return True
        return False


class _View(QWebEngineView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setPage(_Page(self))

    def wheelEvent(self, e):
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            e.ignore()
            return
        super().wheelEvent(e)

    def event(self, e):
        if (
            e.type() == QEvent.Type.KeyPress
            and e.modifiers() & Qt.KeyboardModifier.ControlModifier
        ):
            if e.key() in (
                Qt.Key.Key_Plus,
                Qt.Key.Key_Equal,
                Qt.Key.Key_Minus,
                Qt.Key.Key_0,
            ):
                return True
        return super().event(e)


class WebEngineMixin:
    def setup_webengine_lazy(self, html_path, bridge_class, zoom_factor=1.0):
        self.html_path = html_path
        self.bridge_class = bridge_class
        self.zoom_factor = zoom_factor
        self.web = None
        self.bridge = None
        self.channel = None
        self.web_loaded = False
        self.web_ready = False

    def _is_webengine_valid(self):
        try:
            if self.web is None:
                return False
            if _SIP:
                if sip.isdeleted(self.web):
                    return False
            else:
                try:
                    _ = self.web.isVisible
                except RuntimeError:
                    return False
            return True
        except (RuntimeError, AttributeError):
            return False

    def _create_webengine(self):
        if self.web is not None and self._is_webengine_valid():
            return
        self.web = _View()
        self.web.setZoomFactor(self.zoom_factor)
        self.channel = QWebChannel()
        self.bridge = self.bridge_class(self.web, self)
        self.channel.registerObject("bridge", self.bridge)
        self.web.page().setWebChannel(self.channel)
        self.web.setUrl(QUrl.fromLocalFile(self.html_path))
        self.mainArea.layout().addWidget(self.web)
        self.web_loaded = True
        self.web_ready = True

    def _destroy_webengine(self):
        _LRU_MGR.remove(self)
        if not self._is_webengine_valid():
            self.web = None
            self.bridge = None
            self.channel = None
            self.web_loaded = False
            self.web_ready = False
            return
        try:
            self.web.setParent(None)
            self.web.deleteLater()
        except (RuntimeError, AttributeError):
            pass
        self.web = None
        self.bridge = None
        self.channel = None
        self.web_loaded = False
        self.web_ready = False

    def showEvent(self, event):
        if not self.web_loaded:
            self._create_webengine()
            self.on_webengine_ready()
        else:
            if self._is_webengine_valid():
                self.web.show()
            else:
                self.web_loaded = False
                self._create_webengine()
                self.on_webengine_ready()
        _LRU_MGR.touch(self)
        _LRU_MGR.enforce_limit()
        self.on_webengine_show()
        super().showEvent(event)

    def closeEvent(self, event):
        if self._is_webengine_valid():
            try:
                self.web.hide()
            except (RuntimeError, AttributeError):
                pass
        super().closeEvent(event)

    def onDeleteWidget(self):
        self._destroy_webengine()
        if hasattr(super(), "onDeleteWidget"):
            super().onDeleteWidget()

    def on_webengine_ready(self):
        pass

    def on_webengine_show(self):
        pass
