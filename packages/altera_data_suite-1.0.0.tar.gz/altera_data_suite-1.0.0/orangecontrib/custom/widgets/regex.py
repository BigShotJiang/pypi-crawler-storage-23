import os, json
from PyQt6.QtCore import QObject, pyqtSlot
from Orange.widgets import widget
from Orange.widgets.widget import Input, Output
from Orange.widgets.settings import Setting
from Orange.data import Table
from .web_utils import WebEngineMixin
from .auxiliary_functions import _o2d, _d2ob, _prp, _PL


class _Br(QObject):
    def __init__(self, _v, _pw):
        super().__init__()
        self._v = _v
        self._pw = _pw
        self._pj = []
        self._ld = False
        self._v.loadFinished.connect(self._ol)

    def _ol(self, ok):
        if ok:
            self._ld = True
            for _j in self._pj:
                self._v.page().runJavaScript(_j)
            self._pj.clear()

    def _rj(self, _j):
        if self._ld:
            self._v.page().runJavaScript(_j)
        else:
            self._pj.append(_j)

    def _sd(self, _d):
        self._rj(f"window.receiveDataFromPython&&receiveDataFromPython({_d});")

    def _sn(self):
        self._rj("window.showNoDataMessage&&showNoDataMessage();")

    @pyqtSlot(str)
    def processRegex(self, _s):
        self._pw._opr(_s)


class OWRegexExtractor(WebEngineMixin, widget.OWWidget):
    name = "Regular Expressions"
    description = "Extract regex matches with intelligent pattern detection"
    category = "Altera Data Suite"
    icon = "icons/regex.svg"
    priority = 10

    class Inputs:
        data = Input("Input Table", Table)

    class Outputs:
        processed_data = Output("Regex Tables", Table)

    regex_pattern = Setting("")
    new_column_name = Setting("Extracted")
    selected_column = Setting("")
    match_mode = Setting("smart_extract")
    literal_mode = Setting(False)
    DESTROY_TIMEOUT = 300
    want_main_area = True
    want_control_area = False
    resizing_enabled = True

    class Error(widget.OWWidget.Error):
        license_error = widget.Msg("License error: {}")

    def __init__(self):
        super().__init__()
        self._id = None
        self._df = None
        _h = os.path.join(os.path.dirname(__file__), "UI", "regex_ui", "index.html")
        self.setup_webengine_lazy(_h, _Br, zoom_factor=0.9)

    def on_webengine_ready(self):
        if self._id is not None:
            self._sid()
            self._pil()
        elif self.web_loaded and self.bridge:
            self.bridge._sn()

    def on_webengine_show(self):
        pass

    @Inputs.data
    def set_data(self, data):
        self.Error.clear()
        if data is None:
            self._id = None
            self._df = None
            self.Outputs.processed_data.send(None)
            if self.web_loaded and self.bridge:
                self.bridge._sn()
            return
        self._id = data
        self._df = _o2d(data)
        self._pil()
        if self.web_loaded and self.bridge:
            self._sid()

    def _sid(self):
        if self._df is None:
            return
        _cols = self._df.columns.tolist()
        if not self.selected_column or self.selected_column not in _cols:
            self.selected_column = _cols[0] if _cols else ""
        self.bridge._sd(
            json.dumps(
                {
                    "type": "init",
                    "columns": _cols,
                    "selected_column": self.selected_column,
                    "pattern_library": _PL,
                    "settings": {
                        "regex_pattern": self.regex_pattern,
                        "new_column_name": self.new_column_name,
                        "match_mode": self.match_mode,
                        "literal_mode": self.literal_mode,
                    },
                }
            )
        )

    def _pil(self):
        if self._df is None:
            return
        _cols = self._df.columns.tolist()
        if not self.selected_column or self.selected_column not in _cols:
            self.selected_column = _cols[0] if _cols else ""
        self._pri(
            {
                "pattern": self.regex_pattern,
                "column": self.selected_column,
                "mode": self.match_mode,
                "literal": self.literal_mode,
                "new_column_name": self.new_column_name,
                "use_preset": None,
            }
        )

    @pyqtSlot(str)
    def _opr(self, _s):
        try:
            self._pri(json.loads(_s))
        except Exception as _e:
            print(f"[REGEX] Error: {_e}")

    def _pri(self, _p):
        if self._df is None:
            return
        _pat = _p.get("pattern", "")
        _col = _p.get("column", self.selected_column)
        _mode = _p.get("mode", "smart_extract")
        _lit = _p.get("literal", False)
        _ncn = _p.get("new_column_name", "Extracted")
        _up = _p.get("use_preset", None)
        self.selected_column = _col
        self.match_mode = _mode
        self.literal_mode = _lit
        self.new_column_name = _ncn
        if _up and _up in _PL:
            _pat = _PL[_up]
        self.regex_pattern = _pat
        try:
            _rdf, _rd = _prp(self._df, _col, _pat, _mode, _lit, _ncn)
            if _rd.get("status") not in ("error",):
                self.Outputs.processed_data.send(_d2ob(_rdf))
            if self.web_loaded and self.bridge:
                self.bridge._sd(json.dumps(_rd))
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.processed_data.send(None)
