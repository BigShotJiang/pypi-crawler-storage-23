import os, json
from PyQt6.QtCore import QObject, pyqtSlot
from Orange.widgets import widget
from Orange.widgets.widget import Input, Output
from Orange.widgets.settings import Setting
from Orange.data import Table
from .web_utils import WebEngineMixin
from .auxiliary_functions import _o2d, _d2ob, _acs


class _Br(QObject):
    def __init__(self, _v, _pw):
        super().__init__()
        self._v = _v
        self._pw = _pw
        self._pj = []
        self._ld = False
        self._v.loadFinished.connect(self._ol)

    def _ol(self, ok):
        if ok:
            self._ld = True
            for _j in self._pj:
                self._v.page().runJavaScript(_j)
            self._pj.clear()

    def _rj(self, _j):
        if self._ld:
            self._v.page().runJavaScript(_j)
        else:
            self._pj.append(_j)

    def _sd(self, _d):
        self._rj(f"window.receiveDataFromPython&&receiveDataFromPython({_d});")

    def _sn(self):
        self._rj("window.showNoDataMessage&&showNoDataMessage();")

    @pyqtSlot(str)
    def shiftChanged(self, _s):
        self._pw._osc(_s)


class OWMultiShiftColumns(WebEngineMixin, widget.OWWidget):
    name = "Multi Shift Columns"
    description = "Shift selected columns up or down by N steps"
    category = "Altera Data Suite"
    icon = "icons/multishift.svg"
    priority = 10

    class Inputs:
        data = Input("Input Table", Table)

    class Outputs:
        shifted_data = Output("Shifted Table", Table)

    selected_columns = Setting([])
    direction = Setting("down")
    steps = Setting(1)
    want_main_area = True
    want_control_area = False
    resizing_enabled = True

    class Error(widget.OWWidget.Error):
        license_error = widget.Msg("License error: {}")

    def __init__(self):
        super().__init__()
        self._id = None
        self._df = None
        _h = os.path.join(
            os.path.dirname(__file__), "UI", "multi_shift_ui", "index.html"
        )
        self.setup_webengine_lazy(_h, _Br, zoom_factor=0.9)

    def on_webengine_ready(self):
        if self._id is not None:
            self._sdj()
            self._as()
        elif self.web_loaded and self.bridge:
            self.bridge._sn()

    def on_webengine_show(self):
        pass

    @Inputs.data
    def set_data(self, data):
        self.Error.clear()
        if data is None:
            self._id = None
            self._df = None
            self.Outputs.shifted_data.send(None)
            if self.web_loaded and self.bridge:
                self.bridge._sn()
            return
        self._id = data
        self._df = _o2d(data)
        self._as()
        if self.web_loaded and self.bridge:
            self._sdj()

    def _sdj(self):
        if self._df is None:
            return
        self.bridge._sd(
            json.dumps(
                {
                    "type": "columns",
                    "columns": [
                        {"name": c, "type": str(self._df[c].dtype)}
                        for c in self._df.columns
                    ],
                    "selected_columns": self.selected_columns,
                    "direction": self.direction,
                    "steps": self.steps,
                }
            )
        )

    def _osc(self, _s):
        try:
            _p = json.loads(_s)
            self.selected_columns = _p.get("columns", [])
            self.direction = _p.get("direction", "down")
            self.steps = _p.get("steps", 1)
            self._as()
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.shifted_data.send(None)
        except Exception as _e:
            print(f"[MULTISHIFT] Error: {_e}")

    def _as(self):
        if self._df is None:
            self.Outputs.shifted_data.send(None)
            return
        try:
            self.Outputs.shifted_data.send(
                _d2ob(_acs(self._df, self.selected_columns, self.direction, self.steps))
            )
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.shifted_data.send(None)
