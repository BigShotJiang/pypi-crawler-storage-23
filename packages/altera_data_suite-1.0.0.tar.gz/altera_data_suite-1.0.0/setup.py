from setuptools import setup, find_packages

setup(
    name="altera-data-suite",
    version="1.0.0",
    author="Your Name",
    description="Altera Data Suite for Orange3",
    packages=find_packages(),
    package_data={
        "orangecontrib.custom.widgets": [
            "icons/*.svg",
            "web_UI/**/*",
        ]
    },
    install_requires=[
        "orange3",
        "PyQt6",
        "PyQt6-WebEngine",
        "pandas",
        "numpy",
        "keyring",
        "requests",
        "pymupdf",
        "camelot-py",
        "pypdfium2",
        "Pillow",
    ],
    entry_points={
        "orange3.addon": ("altera_data_suite = orangecontrib.custom",),
        "orange.widgets": ("Altera Data Suite = orangecontrib.custom.widgets",),
    },
    python_requires=">=3.10",
)
