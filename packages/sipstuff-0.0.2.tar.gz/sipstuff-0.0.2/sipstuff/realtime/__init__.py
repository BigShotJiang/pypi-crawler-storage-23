"""Real-time Piper TTS streaming for incoming SIP calls."""
