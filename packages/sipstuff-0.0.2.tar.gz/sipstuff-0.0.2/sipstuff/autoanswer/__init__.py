"""Auto-answer incoming SIP calls with WAV playback and TTS announcements."""
