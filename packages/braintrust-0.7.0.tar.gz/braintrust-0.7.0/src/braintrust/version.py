VERSION = "0.7.0"

# this will be templated during the build
GIT_COMMIT = "8ab9dc06de08f7a925fabe52dbbdb6df3b480e89"
