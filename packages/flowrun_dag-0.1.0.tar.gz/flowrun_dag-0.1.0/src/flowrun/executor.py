import asyncio
import concurrent.futures
import functools
import logging
import time
import traceback
from dataclasses import dataclass
from typing import Any

from flowrun.context import RunContext
from flowrun.task import TaskSpec

_default_logger = logging.getLogger("flowrun.executor")


@dataclass
class ExecutionResult:
    """Result of executing a TaskSpec for a single attempt.

    Attributes
    ----------
    ok : bool
        True if the task completed successfully.
    result : Any
        The value returned by the task when successful.
    error : str | None
        The traceback string when the task failed, or None if there was no error.
    duration_s : float
        Execution duration in seconds.
    attempt : int
        The attempt number for this execution result (always 1 because tasks are executed once per DAG run).
    """

    ok: bool
    result: Any = None
    error: str | None = None
    duration_s: float = 0.0
    attempt: int = 1


class TaskExecutor:
    """
    SRP: run one TaskSpec exactly once.
    The scheduler is responsible for dependency ordering and state tracking.

    Uses:
    - asyncio for async tasks
    - a user-provided concurrent.futures.Executor for sync IO tasks
    - optional upstream result propagation via ``upstream`` keyword argument
    """

    def __init__(
        self,
        executor: concurrent.futures.Executor,
        *,
        logger: logging.Logger | None = None,
    ) -> None:
        """Initialize the TaskExecutor.

        Parameters
        ----------
        executor : concurrent.futures.Executor
            Executor used to run synchronous task functions. The caller retains
            ownership and is responsible for shutting it down when appropriate.
        logger : logging.Logger | None
            Optional logger instance. Falls back to ``logging.getLogger('flowrun.executor')``.
        """
        self._executor = executor
        self._log = logger or _default_logger

    @property
    def executor(self) -> concurrent.futures.Executor:
        """Expose the underlying executor for lifecycle management."""
        return self._executor

    async def run_once(
        self,
        spec: TaskSpec,
        timeout_s: float | None,
        context: RunContext[Any] | None = None,
        upstream_results: dict[str, Any] | None = None,
    ) -> ExecutionResult:
        """Execute a TaskSpec once, honoring an optional timeout and returning an ExecutionResult.

        Parameters
        ----------
        spec : TaskSpec
            The task specification to execute; may represent a synchronous function
            or an asynchronous coroutine function.
        timeout_s : float | None
            Maximum number of seconds to allow the task to run for this attempt,
            or None to disable the timeout.
        context : RunContext[Any] | None
            Optional runtime context passed to tasks that opt-in via signature.
        upstream_results : dict[str, Any] | None
            Mapping of completed dependency task names to their results. Provided
            only when the task declares an ``upstream`` parameter.

        Returns
        -------
        ExecutionResult
            Object describing whether the task succeeded, the returned value (if any),
            the error traceback (if failed), the execution duration in seconds, and
            the attempt number.

        Notes
        -----
        Exceptions raised by the task are captured and returned in the ExecutionResult.error
        field; timeouts are translated into a failure ExecutionResult with an explanatory message.
        """
        start = time.time()
        try:
            if spec.requires_context and context is None:
                raise RuntimeError(f"Task '{spec.name}' requires a RunContext but none was provided.")

            args: tuple[Any, ...] = ()
            if context is not None and spec.accepts_context:
                args = (context,)

            kwargs: dict[str, Any] = {}
            if spec.accepts_upstream:
                kwargs["upstream"] = upstream_results or {}
            elif spec.named_deps:
                resolved = upstream_results or {}
                for dep_name in spec.named_deps:
                    if dep_name not in resolved:
                        raise RuntimeError(
                            f"Task '{spec.name}' expects upstream result '{dep_name}', but it was not provided."
                        )
                    kwargs[dep_name] = resolved[dep_name]

            if spec.is_async():
                # run coroutine directly with timeout
                coro = spec.func(*args, **kwargs)
                res = await asyncio.wait_for(coro, timeout=timeout_s)
            else:
                # run sync func in thread pool with timeout
                loop = asyncio.get_running_loop()
                call = functools.partial(spec.func, *args, **kwargs)
                fut = loop.run_in_executor(self._executor, call)
                res = await asyncio.wait_for(fut, timeout=timeout_s)

            return ExecutionResult(
                ok=True,
                result=res,
                duration_s=time.time() - start,
            )
        except (asyncio.exceptions.TimeoutError, TimeoutError):
            self._log.warning("Task %r timed out after %ss", spec.name, timeout_s)
            return ExecutionResult(
                ok=False,
                error=f"Timeout after {timeout_s}s",
                duration_s=time.time() - start,
            )
        except Exception as exc:
            self._log.debug("Task %r raised %s", spec.name, type(exc).__name__, exc_info=True)
            return ExecutionResult(
                ok=False,
                error="".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
                duration_s=time.time() - start,
            )
