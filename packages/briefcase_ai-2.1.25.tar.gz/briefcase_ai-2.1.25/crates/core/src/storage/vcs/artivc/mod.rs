use super::super::StorageError;
use super::provider::{VcsProvider, VcsProviderConfig};
use async_trait::async_trait;
use std::collections::HashMap;
use std::path::PathBuf;
use std::process::Command;

#[derive(Clone, Debug)]
pub struct ArtiVcConfig {
    pub workspace_path: PathBuf,
    pub remote_url: Option<String>,
}

pub struct ArtiVcProvider {
    config: ArtiVcConfig,
    vcs_config: VcsProviderConfig,
}

impl ArtiVcProvider {
    pub fn new(config: VcsProviderConfig) -> Result<Self, StorageError> {
        let workspace_path = config
            .extra
            .get("workspace_path")
            .map(|p| PathBuf::from(p))
            .unwrap_or_else(|| PathBuf::from("./briefcase_artivc"));

        let remote_url = config.endpoint.clone();

        let artivc_config = ArtiVcConfig {
            workspace_path,
            remote_url,
        };

        let provider = ArtiVcProvider {
            config: artivc_config,
            vcs_config: config,
        };

        Ok(provider)
    }

    fn get_object_path(&self, path: &str) -> PathBuf {
        self.config.workspace_path.join(path)
    }

    fn artivc_command(&self, args: &[&str]) -> Result<String, StorageError> {
        let output = Command::new("artivc")
            .current_dir(&self.config.workspace_path)
            .args(args)
            .output()
            .map_err(|e| StorageError::ConnectionError(format!("ArtiVC command failed: {}", e)))?;

        if !output.status.success() {
            return Err(StorageError::ConnectionError(format!(
                "ArtiVC error: {}",
                String::from_utf8_lossy(&output.stderr)
            )));
        }

        Ok(String::from_utf8_lossy(&output.stdout).trim().to_string())
    }
}

#[async_trait]
impl VcsProvider for ArtiVcProvider {
    async fn write_object(&self, path: &str, data: &[u8]) -> Result<(), StorageError> {
        let object_path = self.get_object_path(path);

        if let Some(parent) = object_path.parent() {
            tokio::task::spawn_blocking({
                let parent = parent.to_path_buf();
                move || std::fs::create_dir_all(parent)
            })
            .await
            .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?
            .map_err(|e| StorageError::IoError(format!("Failed to create directories: {}", e)))?;
        }

        tokio::task::spawn_blocking({
            let path = object_path.clone();
            let data = data.to_vec();
            move || std::fs::write(path, data)
        })
        .await
        .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?
        .map_err(|e| StorageError::IoError(format!("Failed to write object: {}", e)))?;

        Ok(())
    }

    async fn read_object(&self, path: &str) -> Result<Vec<u8>, StorageError> {
        let object_path = self.get_object_path(path);

        if !object_path.exists() {
            return Err(StorageError::NotFound(format!(
                "Object not found: {}",
                path
            )));
        }

        tokio::task::spawn_blocking({
            let path = object_path.clone();
            move || std::fs::read(path)
        })
        .await
        .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?
        .map_err(|e| StorageError::IoError(format!("Failed to read object: {}", e)))
    }

    async fn list_objects(&self, prefix: &str) -> Result<Vec<String>, StorageError> {
        let base_path = self.get_object_path(prefix);

        let results = tokio::task::spawn_blocking({
            let base_path = base_path.clone();
            move || {
                let mut objects = Vec::new();
                if base_path.exists() {
                    if let Ok(entries) = std::fs::read_dir(&base_path) {
                        for entry in entries.flatten() {
                            if let Ok(metadata) = entry.metadata() {
                                if metadata.is_file() {
                                    if let Some(name) = entry.file_name().into_string().ok() {
                                        objects.push(format!("{}/{}", prefix, name));
                                    }
                                }
                            }
                        }
                    }
                }
                objects
            }
        })
        .await
        .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?;

        Ok(results)
    }

    async fn delete_object(&self, path: &str) -> Result<bool, StorageError> {
        let object_path = self.get_object_path(path);

        if !object_path.exists() {
            return Ok(false);
        }

        tokio::task::spawn_blocking({
            let path = object_path.clone();
            move || std::fs::remove_file(path)
        })
        .await
        .map_err(|e| StorageError::IoError(format!("Spawn blocking failed: {}", e)))?
        .map_err(|e| StorageError::IoError(format!("Failed to delete object: {}", e)))?;

        Ok(true)
    }

    async fn create_version(&self, message: &str) -> Result<String, StorageError> {
        // Create a tag with timestamp
        let timestamp = chrono::Utc::now().format("%Y%m%d_%H%M%S").to_string();
        let tag_name = format!("v_{}", timestamp);

        self.artivc_command(&["push"])?;
        self.artivc_command(&["tag", &tag_name, "-m", message])?;

        Ok(tag_name)
    }

    async fn health_check(&self) -> Result<bool, StorageError> {
        tokio::task::spawn_blocking({
            let workspace_path = self.config.workspace_path.clone();
            move || workspace_path.exists()
        })
        .await
        .map_err(|e| StorageError::ConnectionError(format!("Health check spawn failed: {}", e)))
    }

    fn provider_name(&self) -> &'static str {
        "artivc"
    }

    fn config_summary(&self) -> String {
        format!(
            "ArtiVC(workspace={}, remote={:?})",
            self.config.workspace_path.display(),
            self.config.remote_url
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_artivc_config_parsing() {
        let mut extra = HashMap::new();
        extra.insert("workspace_path".to_string(), "/tmp/artivc_ws".to_string());

        let vcs_config = VcsProviderConfig {
            provider_type: "artivc".to_string(),
            endpoint: Some("s3://my-bucket".to_string()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = ArtiVcProvider::new(vcs_config).unwrap();
        assert_eq!(
            provider.config.workspace_path,
            PathBuf::from("/tmp/artivc_ws")
        );
        assert_eq!(
            provider.config.remote_url,
            Some("s3://my-bucket".to_string())
        );
    }

    #[test]
    fn test_artivc_defaults() {
        let vcs_config = VcsProviderConfig {
            provider_type: "artivc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = ArtiVcProvider::new(vcs_config).unwrap();
        assert_eq!(
            provider.config.workspace_path,
            PathBuf::from("./briefcase_artivc")
        );
    }

    #[test]
    fn test_provider_name() {
        let vcs_config = VcsProviderConfig {
            provider_type: "artivc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = ArtiVcProvider::new(vcs_config).unwrap();
        assert_eq!(provider.provider_name(), "artivc");
    }

    #[test]
    fn test_config_summary() {
        let mut extra = HashMap::new();
        extra.insert("workspace_path".to_string(), "/tmp/artivc".to_string());

        let vcs_config = VcsProviderConfig {
            provider_type: "artivc".to_string(),
            endpoint: Some("gcs://bucket".to_string()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = ArtiVcProvider::new(vcs_config).unwrap();
        let summary = provider.config_summary();
        assert!(summary.contains("ArtiVC"));
    }

    #[tokio::test]
    async fn test_write_and_read_object() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("workspace_path".to_string(), tmp_path.clone());

        let vcs_config = VcsProviderConfig {
            provider_type: "artivc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = ArtiVcProvider::new(vcs_config).unwrap();
        let test_data = b"test content for artivc";
        let test_path = "test_file.txt";

        provider.write_object(test_path, test_data).await.unwrap();
        let read_data = provider.read_object(test_path).await.unwrap();

        assert_eq!(read_data, test_data);
    }

    #[tokio::test]
    async fn test_read_nonexistent_returns_not_found() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("workspace_path".to_string(), tmp_path);

        let vcs_config = VcsProviderConfig {
            provider_type: "artivc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = ArtiVcProvider::new(vcs_config).unwrap();

        let result = provider.read_object("nonexistent.txt").await;
        assert!(matches!(result, Err(StorageError::NotFound(_))));
    }

    #[tokio::test]
    async fn test_list_objects_with_prefix() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("workspace_path".to_string(), tmp_path.clone());

        let vcs_config = VcsProviderConfig {
            provider_type: "artivc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = ArtiVcProvider::new(vcs_config).unwrap();

        // Write multiple files
        provider
            .write_object("artifacts/model1.bin", b"model_data1")
            .await
            .unwrap();
        provider
            .write_object("artifacts/model2.bin", b"model_data2")
            .await
            .unwrap();
        provider
            .write_object("configs/config.yaml", b"config_data")
            .await
            .unwrap();

        // List objects with prefix
        let objects = provider.list_objects("artifacts").await.unwrap();
        assert_eq!(objects.len(), 2);
        assert!(objects.iter().any(|o| o.contains("model1.bin")));
        assert!(objects.iter().any(|o| o.contains("model2.bin")));
    }

    #[tokio::test]
    async fn test_delete_object() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("workspace_path".to_string(), tmp_path);

        let vcs_config = VcsProviderConfig {
            provider_type: "artivc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = ArtiVcProvider::new(vcs_config).unwrap();
        let test_path = "delete_test.bin";

        provider
            .write_object(test_path, b"to delete")
            .await
            .unwrap();
        let delete_result = provider.delete_object(test_path).await.unwrap();

        assert_eq!(delete_result, true);

        let read_result = provider.read_object(test_path).await;
        assert!(matches!(read_result, Err(StorageError::NotFound(_))));
    }

    #[tokio::test]
    async fn test_health_check_valid_workspace() {
        let tmp = tempfile::tempdir().unwrap();
        let tmp_path = tmp.path().to_str().unwrap().to_string();

        let mut extra = HashMap::new();
        extra.insert("workspace_path".to_string(), tmp_path);

        let vcs_config = VcsProviderConfig {
            provider_type: "artivc".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra,
        };

        let provider = ArtiVcProvider::new(vcs_config).unwrap();
        let health = provider.health_check().await.unwrap();

        assert_eq!(health, true);
    }
}
