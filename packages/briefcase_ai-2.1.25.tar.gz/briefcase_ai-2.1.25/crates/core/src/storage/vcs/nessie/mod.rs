use super::super::StorageError;
use super::provider::{VcsProvider, VcsProviderConfig};
use async_trait::async_trait;
use base64::{engine::general_purpose::STANDARD as BASE64, Engine as _};
use reqwest::Client;
use serde_json::json;
use std::collections::HashMap;

#[derive(Clone, Debug)]
pub struct NessieConfig {
    pub endpoint: String,
    pub branch: String,
    pub token: Option<String>,
    pub access_key: Option<String>,
    pub secret_key: Option<String>,
}

pub struct NessieProvider {
    config: NessieConfig,
    client: Client,
}

impl NessieProvider {
    pub fn new(config: VcsProviderConfig) -> Result<Self, StorageError> {
        let endpoint = config
            .endpoint
            .ok_or_else(|| StorageError::InvalidQuery("Endpoint is required".to_string()))?;

        let branch = config.branch.unwrap_or_else(|| "main".to_string());

        let nessie_config = NessieConfig {
            endpoint,
            branch,
            token: config.token,
            access_key: config.access_key,
            secret_key: config.secret_key,
        };

        let client = Client::new();

        Ok(NessieProvider {
            config: nessie_config,
            client,
        })
    }

    fn get_auth_header(&self) -> Option<String> {
        if let Some(token) = &self.config.token {
            Some(format!("Bearer {}", token))
        } else if let (Some(key), Some(secret)) = (&self.config.access_key, &self.config.secret_key)
        {
            let credentials = format!("{}:{}", key, secret);
            let encoded = BASE64.encode(&credentials);
            Some(format!("Basic {}", encoded))
        } else {
            None
        }
    }

    fn api_url(&self, path: &str) -> String {
        format!(
            "{}/api/v2/trees/{}{}",
            self.config.endpoint, self.config.branch, path
        )
    }
}

#[async_trait]
impl VcsProvider for NessieProvider {
    async fn write_object(&self, path: &str, data: &[u8]) -> Result<(), StorageError> {
        let url = self.api_url(&format!("/contents/{}", path));

        let mut request = self.client.put(&url).body(data.to_vec());

        if let Some(auth) = self.get_auth_header() {
            request = request.header("Authorization", auth);
        }

        let response = request
            .send()
            .await
            .map_err(|e| StorageError::ConnectionError(format!("Failed to write object: {}", e)))?;

        if response.status().is_success() {
            Ok(())
        } else {
            Err(StorageError::ConnectionError(format!(
                "Write failed with status: {}",
                response.status()
            )))
        }
    }

    async fn read_object(&self, path: &str) -> Result<Vec<u8>, StorageError> {
        let url = self.api_url(&format!("/contents/{}", path));

        let mut request = self.client.get(&url);

        if let Some(auth) = self.get_auth_header() {
            request = request.header("Authorization", auth);
        }

        let response = request
            .send()
            .await
            .map_err(|e| StorageError::ConnectionError(format!("Failed to read object: {}", e)))?;

        if response.status().is_not_found() {
            return Err(StorageError::NotFound(format!(
                "Object not found: {}",
                path
            )));
        }

        if !response.status().is_success() {
            return Err(StorageError::ConnectionError(format!(
                "Read failed with status: {}",
                response.status()
            )));
        }

        response
            .bytes()
            .await
            .map(|b| b.to_vec())
            .map_err(|e| StorageError::IoError(format!("Failed to read response body: {}", e)))
    }

    async fn list_objects(&self, prefix: &str) -> Result<Vec<String>, StorageError> {
        let url = format!(
            "{}/api/v2/trees/{}/entries?filter=prefix=='{}'",
            self.config.endpoint, self.config.branch, prefix
        );

        let mut request = self.client.get(&url);

        if let Some(auth) = self.get_auth_header() {
            request = request.header("Authorization", auth);
        }

        let response = request
            .send()
            .await
            .map_err(|e| StorageError::ConnectionError(format!("Failed to list objects: {}", e)))?;

        if !response.status().is_success() {
            return Err(StorageError::ConnectionError(format!(
                "List failed with status: {}",
                response.status()
            )));
        }

        let text = response
            .text()
            .await
            .map_err(|e| StorageError::IoError(format!("Failed to read response: {}", e)))?;

        let json: serde_json::Value = serde_json::from_str(&text).map_err(|e| {
            StorageError::SerializationError(format!("Invalid JSON response: {}", e))
        })?;

        let mut objects = Vec::new();
        if let Some(entries) = json.get("entries").and_then(|e| e.as_array()) {
            for entry in entries {
                if let Some(name) = entry.get("name").and_then(|n| n.as_str()) {
                    objects.push(name.to_string());
                }
            }
        }

        Ok(objects)
    }

    async fn delete_object(&self, path: &str) -> Result<bool, StorageError> {
        let url = self.api_url(&format!("/contents/{}", path));

        let mut request = self.client.delete(&url);

        if let Some(auth) = self.get_auth_header() {
            request = request.header("Authorization", auth);
        }

        let response = request.send().await.map_err(|e| {
            StorageError::ConnectionError(format!("Failed to delete object: {}", e))
        })?;

        if response.status().is_not_found() {
            return Ok(false);
        }

        Ok(response.status().is_success())
    }

    async fn create_version(&self, message: &str) -> Result<String, StorageError> {
        let url = format!(
            "{}/api/v2/trees/{}/history",
            self.config.endpoint, self.config.branch
        );

        let body = json!({
            "message": message,
            "commit": {
                "message": message
            }
        });

        let mut request = self.client.post(&url).json(&body);

        if let Some(auth) = self.get_auth_header() {
            request = request.header("Authorization", auth);
        }

        let response = request.send().await.map_err(|e| {
            StorageError::ConnectionError(format!("Failed to create version: {}", e))
        })?;

        if !response.status().is_success() {
            return Err(StorageError::ConnectionError(format!(
                "Create version failed with status: {}",
                response.status()
            )));
        }

        let text = response
            .text()
            .await
            .map_err(|e| StorageError::IoError(format!("Failed to read response: {}", e)))?;

        let json: serde_json::Value = serde_json::from_str(&text).map_err(|e| {
            StorageError::SerializationError(format!("Invalid JSON response: {}", e))
        })?;

        json.get("hash")
            .and_then(|h| h.as_str())
            .map(|s| s.to_string())
            .ok_or_else(|| StorageError::SerializationError("No hash in response".to_string()))
    }

    async fn health_check(&self) -> Result<bool, StorageError> {
        let url = format!("{}/api/v2/config", self.config.endpoint);

        let mut request = self.client.get(&url);

        if let Some(auth) = self.get_auth_header() {
            request = request.header("Authorization", auth);
        }

        let response = request
            .send()
            .await
            .map_err(|e| StorageError::ConnectionError(format!("Health check failed: {}", e)))?;

        Ok(response.status().is_success())
    }

    fn provider_name(&self) -> &'static str {
        "nessie"
    }

    fn config_summary(&self) -> String {
        format!(
            "Nessie(endpoint={}, branch={}, auth={})",
            self.config.endpoint,
            self.config.branch,
            if self.config.token.is_some() {
                "token"
            } else {
                "basic"
            }
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use wiremock::matchers::{method, path};
    use wiremock::{Mock, MockServer, ResponseTemplate};

    #[test]
    fn test_nessie_config_with_endpoint() {
        let mut extra = HashMap::new();
        let vcs_config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some("https://nessie.example.com".to_string()),
            access_key: None,
            secret_key: None,
            token: Some("my_token".to_string()),
            repository: None,
            branch: Some("develop".to_string()),
            extra,
        };

        let provider = NessieProvider::new(vcs_config).unwrap();
        assert_eq!(provider.config.endpoint, "https://nessie.example.com");
        assert_eq!(provider.config.branch, "develop");
        assert_eq!(provider.config.token, Some("my_token".to_string()));
    }

    #[test]
    fn test_nessie_missing_endpoint() {
        let vcs_config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: None,
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let result = NessieProvider::new(vcs_config);
        assert!(result.is_err());
    }

    #[test]
    fn test_nessie_default_branch() {
        let vcs_config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some("https://nessie.example.com".to_string()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(vcs_config).unwrap();
        assert_eq!(provider.config.branch, "main");
    }

    #[test]
    fn test_nessie_api_url() {
        let vcs_config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some("https://api.nessie.io".to_string()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: Some("prod".to_string()),
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(vcs_config).unwrap();
        let url = provider.api_url("/contents/myfile.txt");
        assert_eq!(
            url,
            "https://api.nessie.io/api/v2/trees/prod/contents/myfile.txt"
        );
    }

    #[test]
    fn test_nessie_provider_name() {
        let vcs_config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some("https://nessie.example.com".to_string()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(vcs_config).unwrap();
        assert_eq!(provider.provider_name(), "nessie");
    }

    #[tokio::test]
    async fn test_write_object_success() {
        let server = MockServer::start().await;

        Mock::given(method("PUT"))
            .and(path("/api/v2/trees/main/contents/test.txt"))
            .respond_with(ResponseTemplate::new(200))
            .mount(&server)
            .await;

        let config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some(server.uri()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(config).unwrap();
        let result = provider.write_object("test.txt", b"test data").await;
        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn test_read_object_success() {
        let server = MockServer::start().await;

        Mock::given(method("GET"))
            .and(path("/api/v2/trees/main/contents/test.txt"))
            .respond_with(ResponseTemplate::new(200).set_body_bytes(b"file content"))
            .mount(&server)
            .await;

        let config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some(server.uri()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(config).unwrap();
        let result = provider.read_object("test.txt").await;
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), b"file content");
    }

    #[tokio::test]
    async fn test_read_object_not_found() {
        let server = MockServer::start().await;

        Mock::given(method("GET"))
            .and(path("/api/v2/trees/main/contents/missing.txt"))
            .respond_with(ResponseTemplate::new(404))
            .mount(&server)
            .await;

        let config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some(server.uri()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(config).unwrap();
        let result = provider.read_object("missing.txt").await;
        assert!(result.is_err());
        assert!(matches!(result.unwrap_err(), StorageError::NotFound(_)));
    }

    #[tokio::test]
    async fn test_list_objects_success() {
        let server = MockServer::start().await;

        Mock::given(method("GET"))
            .and(path("/api/v2/trees/main/entries"))
            .respond_with(
                ResponseTemplate::new(200).set_body_string(
                    r#"{"entries": [{"name": "file1.txt"}, {"name": "file2.txt"}]}"#,
                ),
            )
            .mount(&server)
            .await;

        let config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some(server.uri()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(config).unwrap();
        let result = provider.list_objects("test/").await;
        assert!(result.is_ok());
        let objects = result.unwrap();
        assert_eq!(objects.len(), 2);
        assert!(objects.contains(&"file1.txt".to_string()));
        assert!(objects.contains(&"file2.txt".to_string()));
    }

    #[tokio::test]
    async fn test_delete_object_success() {
        let server = MockServer::start().await;

        Mock::given(method("DELETE"))
            .and(path("/api/v2/trees/main/contents/test.txt"))
            .respond_with(ResponseTemplate::new(204))
            .mount(&server)
            .await;

        let config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some(server.uri()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(config).unwrap();
        let result = provider.delete_object("test.txt").await;
        assert!(result.is_ok());
        assert!(result.unwrap());
    }

    #[tokio::test]
    async fn test_delete_object_not_found() {
        let server = MockServer::start().await;

        Mock::given(method("DELETE"))
            .and(path("/api/v2/trees/main/contents/missing.txt"))
            .respond_with(ResponseTemplate::new(404))
            .mount(&server)
            .await;

        let config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some(server.uri()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(config).unwrap();
        let result = provider.delete_object("missing.txt").await;
        assert!(result.is_ok());
        assert!(!result.unwrap());
    }

    #[tokio::test]
    async fn test_create_version_success() {
        let server = MockServer::start().await;

        Mock::given(method("POST"))
            .and(path("/api/v2/trees/main/history"))
            .respond_with(ResponseTemplate::new(200).set_body_string(r#"{"hash": "abc123def456"}"#))
            .mount(&server)
            .await;

        let config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some(server.uri()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(config).unwrap();
        let result = provider.create_version("test commit").await;
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), "abc123def456");
    }

    #[tokio::test]
    async fn test_health_check_healthy() {
        let server = MockServer::start().await;

        Mock::given(method("GET"))
            .and(path("/api/v2/config"))
            .respond_with(ResponseTemplate::new(200))
            .mount(&server)
            .await;

        let config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some(server.uri()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(config).unwrap();
        let result = provider.health_check().await;
        assert!(result.is_ok());
        assert!(result.unwrap());
    }

    #[tokio::test]
    async fn test_health_check_unhealthy() {
        let server = MockServer::start().await;

        Mock::given(method("GET"))
            .and(path("/api/v2/config"))
            .respond_with(ResponseTemplate::new(500))
            .mount(&server)
            .await;

        let config = VcsProviderConfig {
            provider_type: "nessie".to_string(),
            endpoint: Some(server.uri()),
            access_key: None,
            secret_key: None,
            token: None,
            repository: None,
            branch: None,
            extra: HashMap::new(),
        };

        let provider = NessieProvider::new(config).unwrap();
        let result = provider.health_check().await;
        assert!(result.is_ok());
        assert!(!result.unwrap());
    }
}
