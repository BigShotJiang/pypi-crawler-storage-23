# EAGLELIZ
Python binding for [eagle.cool api](https://api.eagle.cool).

Currently only supports the following endpoints:
- /api/application/info
- /api/item/addFromPaths

## Installation
```bash
pip install eagleliz
```
