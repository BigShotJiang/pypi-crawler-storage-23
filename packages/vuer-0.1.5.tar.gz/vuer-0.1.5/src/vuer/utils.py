def print_error(message: str) -> None:
    print(f"\033[91m[ERROR] {message}\033[0m")
