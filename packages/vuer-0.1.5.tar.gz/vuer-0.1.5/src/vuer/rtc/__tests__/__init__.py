"""Tests for vuer.rtc module."""
