"""Vuer CLI with plugin discovery."""

from .main import main

__all__ = ["main"]
