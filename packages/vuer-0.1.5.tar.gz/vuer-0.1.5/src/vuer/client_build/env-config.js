// This file is generated at build time and exposed to the browser
// It provides environment variables at runtime
window.ENV = {
};
