import secrets
import string


def generate_password(length: int = 12) -> str:
    """
    Generate a cryptographically secure random password.
    Ensures at least one uppercase, lowercase, digit, and special character.
    """
    if length < 4:
        raise ValueError("Password length must be at least 4")

    char_sets = [
        string.ascii_uppercase,
        string.ascii_lowercase,
        string.digits,
        string.punctuation,
    ]

    password = [secrets.choice(char_set) for char_set in char_sets]
    all_chars = "".join(char_sets)

    password += [secrets.choice(all_chars) for _ in range(length - 4)]
    secrets.SystemRandom().shuffle(password)

    return "".join(password)