# Secure Password Generator

Generate cryptographically secure passwords in Python.

## Installation

```bash
pip install secure-password-generator