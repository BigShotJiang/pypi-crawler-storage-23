# Usage

To use ANDALUS in a project:

```python
import andalus
```
