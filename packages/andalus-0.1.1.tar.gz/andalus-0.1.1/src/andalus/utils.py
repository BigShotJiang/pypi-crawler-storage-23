def do_something_useful() -> None:
    print("Replace this with a utility function")


def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b
