# History

## 0.1.0 (2026-02-25)

* First release on PyPI.
