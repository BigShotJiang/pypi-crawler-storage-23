"""zodify - Zod-inspired dict validation for Python."""

import os
import types
from typing import Any, Literal, TypeVar, cast as typing_cast, overload

__version__: str = "0.5.0"
__all__ = ["__version__", "validate", "env", "Validator", "Optional", "ValidationError"]

_MISSING: object = object()
_BOOL_TRUE = {"true", "1", "yes"}
_BOOL_FALSE = {"false", "0", "no"}
UnknownKeysMode = Literal["reject", "strip"]
ErrorMode = Literal["text", "structured"]
_DictValueT = TypeVar("_DictValueT")
_SchemaValueT = TypeVar("_SchemaValueT")
_EnvCastT = TypeVar("_EnvCastT", str, int, float, bool)


class ValidationError(ValueError):
    """Validation error with machine-readable issues list

    Args:
        issues: List of issue dicts, each with keys
                ``path``, ``message``, ``expected``, ``got``.
                Dicts **must** contain at least ``path`` and
                ``message``; a ``KeyError`` is raised otherwise.

    Example:
        >>> from zodify import ValidationError
        >>> e = ValidationError([{"path": "db.port", "message": "expected int, got str", "expected": "int", "got": "str"}])
        >>> str(e)
        'db.port: expected int, got str'
    """

    issues: list[dict[str, str]]
    __slots__ = ("issues",)

    def __init__(self, issues: list[dict[str, str]]) -> None:
        self.issues = [dict(d) for d in issues]
        super().__init__("\n".join(
            f"{d['path']}: {d['message']}" for d in self.issues
        ))

    def __reduce__(self) -> tuple[object, tuple[list[dict[str, str]]]]:
        # Keep structured issues intact for copy/deepcopy/pickle.
        return (self.__class__, (self.issues,))


class Optional:
    """Mark a schema key as optional with an optional default

    Args:
        type: The expected type for the value when present.
        default: Default value if key is absent from data.
                 If omitted, absent keys are excluded from
                 the result.

    Example:
        >>> from zodify import validate, Optional
        >>> schema = {"name": str, "role": Optional(str, "user")}
        >>> validate(schema, {"name": "Alice"})
        {'name': 'Alice', 'role': 'user'}
    """

    type: Any
    default: Any
    __slots__ = ("type", "default")

    def __init__(self, type: Any, default: Any = _MISSING) -> None:
        self.type = type
        self.default = default

    def __repr__(self) -> str:
        if self.default is _MISSING:
            return f"Optional({self.type!r})"
        return f"Optional({self.type!r}, {self.default!r})"


def _coerce_value(value: Any, target: type, key: str) -> Any:
    """Coerce a value to the target type"""
    if target is str:
        return str(value)
    if type(value) is not str:
        raise ValueError(
            f"{key}: expected {target.__name__}, "
            f"got {type(value).__name__}"
        )
    if not value:
        raise ValueError(
            f"{key}: cannot coerce empty string to "
            f"{target.__name__}"
        )
    if target is bool:
        lower = value.lower()
        if lower in _BOOL_TRUE:
            return True
        if lower in _BOOL_FALSE:
            return False
        raise ValueError(
            f"{key}: cannot coerce '{value}' to bool"
        )
    if target is int:
        try:
            return int(value)
        except (ValueError, TypeError) as e:
            raise ValueError(
                f"{key}: cannot coerce '{value}' to int"
            ) from e
    if target is float:
        try:
            return float(value)
        except (ValueError, TypeError) as e:
            raise ValueError(
                f"{key}: cannot coerce '{value}' to float"
            ) from e
    raise ValueError(
        f"{key}: cannot coerce to {target.__name__}"
    )


def _resolve_mode_options(
    unknown_keys: object,
    error_mode: object,
) -> tuple[UnknownKeysMode, ErrorMode]:
    """Validate and normalize unknown_keys/error_mode options."""
    if unknown_keys not in ("reject", "strip"):
        raise ValueError("unknown_keys must be 'reject' or 'strip'")
    if error_mode not in ("text", "structured"):
        raise ValueError("error_mode must be 'text' or 'structured'")
    return (
        typing_cast(UnknownKeysMode, unknown_keys),
        typing_cast(ErrorMode, error_mode),
    )


def _check_list(value: Any, expected: list[Any], key: str, coerce: bool,
                errors: list[tuple[str, str, str, str]], depth: int,
                unknown_keys: UnknownKeysMode) -> Any:
    """Validate each element in a list against the expected type"""
    if type(value) is not list:
        errors.append((key, f"expected list, got {type(value).__name__}",
                       "list", type(value).__name__))
        return _MISSING
    result: list[Any] = []
    for i, item in enumerate(value):
        checked = _check_value(item, expected[0], f"{key}[{i}]",
                               coerce, errors, depth, unknown_keys)
        if checked is not _MISSING:
            result.append(checked)
    return result


def _check_type(value: Any, expected: type, key: str, coerce: bool,
                errors: list[tuple[str, str, str, str]]) -> Any:
    """Check a value against an expected type with optional coercion"""
    if type(value) is expected:
        return value
    if coerce:
        try:
            return _coerce_value(value, expected, key)
        except ValueError:
            if type(value) is not str:
                msg = f"expected {expected.__name__}, got {type(value).__name__}"
            elif not value:
                msg = f"cannot coerce empty string to {expected.__name__}"
            else:
                msg = f"cannot coerce '{value}' to {expected.__name__}"
            errors.append((key, msg, expected.__name__,
                           type(value).__name__))
            return _MISSING
    errors.append((
        key, f"expected {expected.__name__}, got {type(value).__name__}",
        expected.__name__, type(value).__name__))
    return _MISSING


def _check_value(value: Any, expected: Any, key: str, coerce: bool,
                 errors: list[tuple[str, str, str, str]], depth: int,
                 unknown_keys: UnknownKeysMode) -> Any:
    """Validate one value against one schema entry"""
    if isinstance(expected, dict):
        if type(value) is not dict:
            errors.append((key, f"expected dict, got {type(value).__name__}",
                           "dict", type(value).__name__))
            return _MISSING
        return _validate(expected, value, coerce,
                         key + ".", errors, depth - 1, unknown_keys)
    if isinstance(expected, list) and len(expected) == 1:
        return _check_list(value, expected, key, coerce, errors, depth, unknown_keys)
    if isinstance(expected, list):
        raise TypeError(
            f"invalid schema value for key '{key}': "
            f"list schema must contain exactly one "
            f"element type, got {len(expected)}"
        )
    if isinstance(expected, types.UnionType):
        for t in expected.__args__:
            if type(value) is t and (not coerce or t is not str):
                return value
        if coerce:
            for t in expected.__args__:
                try:
                    return _coerce_value(value, t, key)
                except ValueError:
                    pass
        type_names = " | ".join(t.__name__ for t in expected.__args__)
        errors.append((key, f"expected {type_names}, got {type(value).__name__}",
                       type_names, type(value).__name__))
        return _MISSING
    if type(expected) is type:
        return _check_type(value, expected, key, coerce, errors)
    if callable(expected):
        try:
            if expected(value):
                return value
        except Exception as exc:
            errors.append((
                key,
                f"custom validation failed ({type(exc).__name__}: {exc})",
                "callable",
                "failed",
            ))
            return _MISSING
        errors.append((key, "custom validation failed", "callable", "failed"))
        return _MISSING
    raise TypeError(
        f"invalid schema value for key '{key}': "
        f"{expected!r}"
    )


def _validate(schema: dict[str, Any], data: dict[str, Any], coerce: bool,
              prefix: str, errors: list[tuple[str, str, str, str]], depth: int,
              unknown_keys: UnknownKeysMode) -> dict[str, Any]:
    """Iterate schema keys and validate each value"""
    result: dict[str, Any] = {}
    if depth <= 0:
        errors.append((prefix.rstrip("."),
                       "max depth exceeded",
                       "max_depth", "exceeded"))
        return result
    for key, expected in schema.items():
        if isinstance(expected, Optional):
            exp = expected.type
            default = expected.default
        else:
            exp = expected
            default = _MISSING
        full_key = f"{prefix}{key}"
        if key not in data:
            if default is not _MISSING:
                result[key] = default
            elif isinstance(expected, Optional):
                pass  # no default, key absent from result
            else:
                errors.append((
                    full_key, "missing required key",
                    "required", "missing",
                ))
            continue
        checked = _check_value(
            data[key], exp, full_key, coerce, errors, depth,
            unknown_keys,
        )
        if checked is not _MISSING:
            result[key] = checked
    if unknown_keys == "reject":
        for key in data:
            if key not in schema:
                errors.append((f"{prefix}{key}", "unknown key",
                               "known", "unknown"))
    return result


@overload
def validate(
    schema: dict[str, type[_SchemaValueT]],
    data: dict[str, Any],
    *,
    coerce: bool = False,
    max_depth: int = 32,
    unknown_keys: Literal["reject"] = "reject",
    error_mode: ErrorMode = "text",
) -> dict[str, _SchemaValueT]:
    ...


@overload
def validate(
    schema: dict[str, Any],
    data: dict[str, _DictValueT],
    *,
    coerce: bool = False,
    max_depth: int = 32,
    unknown_keys: Literal["reject"] = "reject",
    error_mode: ErrorMode = "text",
) -> dict[str, _DictValueT]:
    ...


@overload
def validate(
    schema: dict[str, Any],
    data: dict[str, Any],
    *,
    coerce: bool = False,
    max_depth: int = 32,
    unknown_keys: Literal["strip"],
    error_mode: ErrorMode = "text",
) -> dict[str, Any]:
    ...


def validate(schema: dict[str, Any], data: dict[str, Any], *, coerce: bool = False,
             max_depth: int = 32, unknown_keys: UnknownKeysMode = "reject",
             error_mode: ErrorMode = "text") -> dict[str, Any]:
    """Validate a dict against a type schema

    Args:
        schema: Dict mapping keys to expected types.
        data: The dict to validate.
        coerce: If True, cast string values to target types.
        max_depth: Maximum nesting depth (default 32).
        unknown_keys: How to handle extra keys ("reject" or
                      "strip"). Default "reject".
        error_mode: Error output format. ``"text"`` raises
                    ``ValueError`` with human-readable strings
                    (default). ``"structured"`` raises
                    ``ValidationError`` with ``.issues`` list
                    of dicts.

    Returns:
        A new dict with only schema-declared keys.

    Raises:
        TypeError: If schema or data is not a dict, or
                   if schema contains invalid values.
        ValueError: If any key fails validation (text mode),
                    or if unknown_keys / error_mode is invalid.
        ValidationError: If any key fails validation
                         (structured mode). Subclass of
                         ValueError.

    Example:
        >>> from zodify import validate
        >>> validate({"name": str, "age": int}, {"name": "Alice", "age": 30})
        {'name': 'Alice', 'age': 30}
    """
    if type(schema) is not dict:
        raise TypeError("schema must be a dict")
    if type(data) is not dict:
        raise TypeError("data must be a dict")
    resolved_unknown_keys, resolved_error_mode = _resolve_mode_options(
        unknown_keys,
        error_mode,
    )
    errors: list[tuple[str, str, str, str]] = []
    result = _validate(
        schema, data, coerce, "", errors, max_depth,
        resolved_unknown_keys,
    )
    if errors:
        if resolved_error_mode == "structured":
            raise ValidationError([
                {"path": p, "message": m, "expected": e, "got": g}
                for p, m, e, g in errors
            ])
        raise ValueError("\n".join(
            f"{path}: {msg}" for path, msg, _, _ in errors
        ))
    return result


@overload
def env(name: str, cast: type[_EnvCastT]) -> _EnvCastT:
    ...


@overload
def env(name: str, cast: type[_EnvCastT], default: _EnvCastT) -> _EnvCastT:
    ...


def env(name: str, cast: type[_EnvCastT], default: object = _MISSING) -> _EnvCastT:
    """Read and type-cast an environment variable

    Args:
        name: The environment variable name.
        cast: Target type (str, int, float, bool).
        default: Default value if env var is not set.
                 If not provided, missing vars raise
                 ValueError. Defaults are NOT type-checked.

    Returns:
        The typed value of the environment variable.

    Raises:
        ValueError: If the env var is missing (with no
                    default) or cannot be cast to the
                    target type.

    Example:
        >>> import os; os.environ["PORT"] = "8080"
        >>> from zodify import env
        >>> env("PORT", int)
        8080
        >>> del os.environ["PORT"]
    """
    value = os.environ.get(name)
    if value is None:
        if default is not _MISSING:
            return typing_cast(_EnvCastT, default)
        raise ValueError(
            f"{name}: missing required env var"
        )
    return typing_cast(_EnvCastT, _coerce_value(value, cast, name))


class Validator:
    """Validate dict data with reusable default validate() options

    Args:
        coerce: Default value for ``validate(..., coerce=...)``.
        max_depth: Default value for ``validate(..., max_depth=...)``.
        unknown_keys: Default value for ``validate(..., unknown_keys=...)``.
        error_mode: Default value for ``validate(..., error_mode=...)``.

    Example:
        >>> from zodify import Validator
        >>> v = Validator(coerce=True, error_mode="structured")
        >>> v.validate({"port": int}, {"port": "8080"})
        {'port': 8080}
    """

    __slots__ = ("coerce", "max_depth", "unknown_keys", "error_mode")

    coerce: bool
    max_depth: int
    unknown_keys: UnknownKeysMode
    error_mode: ErrorMode

    def __init__(
        self,
        *,
        coerce: bool = False,
        max_depth: int = 32,
        unknown_keys: UnknownKeysMode = "reject",
        error_mode: ErrorMode = "text",
    ) -> None:
        resolved_unknown_keys, resolved_error_mode = _resolve_mode_options(
            unknown_keys,
            error_mode,
        )
        self.coerce = coerce
        self.max_depth = max_depth
        self.unknown_keys = resolved_unknown_keys
        self.error_mode = resolved_error_mode

    @overload
    def validate(
        self,
        schema: dict[str, type[_SchemaValueT]],
        data: dict[str, Any],
        *,
        coerce: bool = ...,
        max_depth: int = ...,
        unknown_keys: UnknownKeysMode = ...,
        error_mode: ErrorMode = ...,
    ) -> dict[str, _SchemaValueT]:
        ...

    @overload
    def validate(
        self,
        schema: dict[str, Any],
        data: dict[str, _DictValueT],
        *,
        coerce: bool = ...,
        max_depth: int = ...,
        unknown_keys: UnknownKeysMode = ...,
        error_mode: ErrorMode = ...,
    ) -> dict[str, _DictValueT]:
        ...

    def validate(
        self,
        schema: dict[str, Any],
        data: dict[str, Any],
        *,
        coerce: object = _MISSING,
        max_depth: object = _MISSING,
        unknown_keys: object = _MISSING,
        error_mode: object = _MISSING,
    ) -> dict[str, Any]:
        use_coerce = self.coerce if coerce is _MISSING else coerce
        use_max_depth = self.max_depth if max_depth is _MISSING else max_depth
        use_unknown_keys = (
            self.unknown_keys
            if unknown_keys is _MISSING
            else unknown_keys
        )
        use_error_mode = self.error_mode if error_mode is _MISSING else error_mode
        return validate(
            schema,
            data,
            coerce=typing_cast(bool, use_coerce),
            max_depth=typing_cast(int, use_max_depth),
            unknown_keys=typing_cast(UnknownKeysMode, use_unknown_keys),
            error_mode=typing_cast(ErrorMode, use_error_mode),
        )
