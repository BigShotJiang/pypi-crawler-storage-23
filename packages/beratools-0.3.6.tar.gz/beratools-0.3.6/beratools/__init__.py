__author__ = """AppliedGRG"""
__email__ = 'appliedgrg@gmail.com'
__version__ = '0.3.6'
__license__ = "GPL-3.0-or-later"
__copyright__ = "Copyright (c) AppliedGRG"
__status__ = "Pre-Alpha"
__url__ = "https://github.com/appliedgrg/beratools"
__all__ = ["tools", "gui"]