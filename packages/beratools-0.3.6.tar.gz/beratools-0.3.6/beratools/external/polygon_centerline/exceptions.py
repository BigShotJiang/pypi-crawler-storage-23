class CenterlineError(Exception):
    """Gets raised if centerline cannot be extracted from input Polygon."""
