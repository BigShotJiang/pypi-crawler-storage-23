"""TcTools package."""

# Version placeholder - will be updated by poetry-dynamic-versioning":
__version__ = "0.1.7"
