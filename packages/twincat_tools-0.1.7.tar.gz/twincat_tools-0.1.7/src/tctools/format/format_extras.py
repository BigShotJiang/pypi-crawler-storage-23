from enum import Enum


class Kind(Enum):
    XML = (0,)
    DECLARATION = (1,)
    IMPLEMENTATION = 2
