"""Allow running as python -m lintlang."""
import sys

from lintlang.cli import main

sys.exit(main())
