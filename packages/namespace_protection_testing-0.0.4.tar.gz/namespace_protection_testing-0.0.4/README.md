# namespace-protection-testing

A package for namespace protection testing.

## Installation

```bash
pip install namespace-protection-testing
```

## Usage

```python
from namespace_protection_testing import hello

hello()
```
