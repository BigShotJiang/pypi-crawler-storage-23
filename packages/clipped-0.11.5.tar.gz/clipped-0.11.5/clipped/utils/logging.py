class LogLevels:
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


DEFAULT_LOGS_ROOT = "/tmp/logs"
