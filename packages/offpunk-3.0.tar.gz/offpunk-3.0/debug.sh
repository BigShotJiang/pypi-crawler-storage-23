#!/bin/bash
XDG_DATA_HOME="~/debug/data" XDG_CONFIG_HOME="~/debug/config" XDG_CACHE_HOME="~/debug/cache" python offpunk.py
