"""
:mod:`tests.integration.workflow` package.

Integration tests for :mod:`etlplus.workflow`.
"""
