/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_PRUNING_PRUNERECIPES_H_
#define AIDGE_PRUNING_PRUNERECIPES_H_

#include "aidge/data/Tensor.hpp"
#include "aidge/graph/GraphView.hpp"

namespace Aidge {
/**
 * @brief Automatically insert weights Prune nodes in a GraphView, for
 * Conv and FC operators.
 * @param graphView The GraphView to process.
 */
void insertWeightPruneNodes(std::shared_ptr<GraphView> graphView);

/**
 * @brief Retrieve data and masks associated to Prune nodes.
 * @param graphView The GraphView to process.
 */
std::vector<std::pair<std::shared_ptr<Tensor>, std::shared_ptr<Tensor>>>
pruneDataAndMasks(std::shared_ptr<GraphView> graphView);
} // namespace Aidge

#endif /* AIDGE_PRUNING_PRUNERECIPES_H_ */
