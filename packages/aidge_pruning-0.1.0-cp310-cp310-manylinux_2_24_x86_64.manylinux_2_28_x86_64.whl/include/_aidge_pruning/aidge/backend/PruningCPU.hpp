// /********************************************************************************
//  * Copyright (c) 2023 CEA-List
//  *
//  * This program and the accompanying materials are made available under the
//  * terms of the Eclipse Public License 2.0 which is available at
//  * http://www.eclipse.org/legal/epl-2.0.
//  *
//  * SPDX-License-Identifier: EPL-2.0
//  *
//  ********************************************************************************/
#ifndef AIDGE_PRUNING_CPU_IMPORTS_H_
#define AIDGE_PRUNING_CPU_IMPORTS_H_

#include "aidge/backend/cpu/operator/PruneImpl.hpp"

// ...

#endif /* AIDGE_PRUNING_CPU_IMPORTS_H_ */