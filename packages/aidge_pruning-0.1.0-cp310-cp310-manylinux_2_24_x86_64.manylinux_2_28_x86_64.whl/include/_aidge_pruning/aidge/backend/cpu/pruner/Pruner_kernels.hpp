/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CPU_PRUNER_KERNEL_H_
#define AIDGE_CPU_PRUNER_KERNEL_H_

#include <random>

#include "aidge/utils/Registrar.hpp"

#include "aidge/pruning/pruner/IterNonStructPruner.hpp"
#include "aidge/pruning/pruner/RandomPruner.hpp"

namespace Aidge {
void Pruner_cpu_update_masks_random(std::size_t inputLength,
                                    void *mask_,
                                    float threshold);

template <class I>
void Pruner_cpu_update_masks_iter_nonstruct(std::size_t inputLength,
                                            const void *input_,
                                            void *mask_,
                                            float threshold,
                                            float delta)
{
    const I *input = static_cast<const I *>(input_);
    int8_t *mask = static_cast<int8_t *>(mask_);
    unsigned int zero_counter = 0;
    unsigned int iter_delta = 0;

    // Find the correct iter delta
    while (static_cast<float>(zero_counter) / inputLength < threshold) {
        ++iter_delta;
        zero_counter = 0;
        for (unsigned int i = 0; i < inputLength; ++i) {
            if (std::abs(input[i]) <= delta * iter_delta) {
                ++zero_counter;
            }
        }
    }

    // Fill the mask tensor
    for (unsigned int i = 0; i < inputLength; ++i) {
        mask[i] = (std::abs(input[i]) <= delta * iter_delta) ? 0U : 1U;
    }
}

// Kernels registration to implementation entry point
REGISTRAR(RandomPruner, "cpu", Pruner_cpu_update_masks_random);

REGISTRAR(IterNonStructPruner,
          {"cpu", DataType::Float16},
          Pruner_cpu_update_masks_iter_nonstruct<half_float::half>);
REGISTRAR(IterNonStructPruner,
          {"cpu", DataType::Float32},
          Pruner_cpu_update_masks_iter_nonstruct<float>);
REGISTRAR(IterNonStructPruner,
          {"cpu", DataType::Float64},
          Pruner_cpu_update_masks_iter_nonstruct<double>);
} // namespace Aidge

#endif /* AIDGE_CPU_PRUNER_KERNEL_H_ */
