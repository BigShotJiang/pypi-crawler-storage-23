/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CPU_OPERATOR_PRUNEIMPL_FORWARD_KERNEL_H_
#define AIDGE_CPU_OPERATOR_PRUNEIMPL_FORWARD_KERNEL_H_

#include <random>

#include "aidge/utils/Registrar.hpp"

#include "aidge/backend/cpu/operator/PruneImpl.hpp"

namespace Aidge {
template <class I, class O>
void PruneImpl_cpu_apply_pruning_with_masks(std::size_t inputLength,
                                            const void *input_,
                                            const void *mask_,
                                            void *output_)
{
    const I *input = static_cast<const I *>(input_);
    const int8_t *mask = static_cast<const int8_t *>(mask_);
    O *output = static_cast<O *>(output_);

    for (unsigned int i = 0; i < inputLength; ++i) {
        output[i] = input[i] * mask[i];
    }
}

// Kernels registration to implementation entry point
REGISTRAR(PruneImpl_cpu,
          {{{DataType::Float16}}, {{DataType::Float16}, {DataType::Int8}}},
          {ProdConso::inPlaceModel,
           Aidge::PruneImpl_cpu_apply_pruning_with_masks<half_float::half,
                                                         half_float::half>,
           Aidge::PruneImpl_cpu_apply_pruning_with_masks<half_float::half,
                                                         half_float::half>});
REGISTRAR(PruneImpl_cpu,
          {{{DataType::Float32}}, {{DataType::Float32}, {DataType::Int8}}},
          {ProdConso::inPlaceModel,
           Aidge::PruneImpl_cpu_apply_pruning_with_masks<float, float>,
           Aidge::PruneImpl_cpu_apply_pruning_with_masks<float, float>});
REGISTRAR(PruneImpl_cpu,
          {{{DataType::Float64}}, {{DataType::Float64}, {DataType::Int8}}},
          {ProdConso::inPlaceModel,
           Aidge::PruneImpl_cpu_apply_pruning_with_masks<double, double>,
           Aidge::PruneImpl_cpu_apply_pruning_with_masks<double, double>});
} // namespace Aidge

#endif /* AIDGE_CPU_OPERATOR_PRUNEIMPL_FORWARD_KERNEL_H_ */
