/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_PRUNING_PRUNER_ITERNONSTRUCTPRUNER_H_
#define AIDGE_PRUNING_PRUNER_ITERNONSTRUCTPRUNER_H_

#include <functional>
#include <memory>
#include <vector>

#include "aidge/backend/cpu/data/TensorImpl.hpp"
#include "aidge/data/Tensor.hpp"
#include "aidge/pruning/pruner/Pruner.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/StaticAttributes.hpp"
#include "aidge/utils/TensorUtils.hpp"

namespace Aidge {

enum class IterNonStructPrunerAttr { Delta };

class IterNonStructPruner
    : public Pruner,
      public Registrable<
          IterNonStructPruner,
          std::pair<std::string, DataType>,
          std::function<void(
              const std::size_t, const void *, void *, float, float)>> {
  private:
    using Attributes_ = StaticAttributes<IterNonStructPrunerAttr, float>;
    template <IterNonStructPrunerAttr e>
    using attr = typename Attributes_::template attr<e>;
    const std::shared_ptr<Attributes_> mAttributes;

  public:
    IterNonStructPruner(const float delta = 0.001f)
        : Pruner(),
          mAttributes(std::make_shared<Attributes_>(
              attr<IterNonStructPrunerAttr::Delta>(delta)))
    {
    }

    inline std::shared_ptr<Attributes> attributes() const
    {
        return mAttributes;
    }
    inline float &delta() const noexcept
    {
        return mAttributes->getAttr<IterNonStructPrunerAttr::Delta>();
    }

    void updateMasks() override final;
};

} // namespace Aidge

namespace {
template <>
const char *const EnumStrings<Aidge::IterNonStructPrunerAttr>::data[] = {
    "delta"};
}

#endif // AIDGE_PRUNING_PRUNER_ITERNONSTRUCTPRUNER_H_
