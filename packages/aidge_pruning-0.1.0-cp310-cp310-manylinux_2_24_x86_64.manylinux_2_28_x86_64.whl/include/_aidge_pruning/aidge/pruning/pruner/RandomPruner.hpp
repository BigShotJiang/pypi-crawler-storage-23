/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_PRUNING_PRUNER_RANDOMPRUNER_H_
#define AIDGE_PRUNING_PRUNER_RANDOMPRUNER_H_

#include <functional>
#include <memory>
#include <vector>

#include "aidge/backend/cpu/data/TensorImpl.hpp"
#include "aidge/data/Tensor.hpp"
#include "aidge/pruning/pruner/Pruner.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/TensorUtils.hpp"

namespace Aidge {

class RandomPruner
    : public Pruner,
      public Registrable<
          RandomPruner,
          std::string,
          std::function<void(const std::size_t, void *, float)>> {
  public:
    RandomPruner() : Pruner() {}

    void updateMasks() override final;
};

} // namespace Aidge

#endif // AIDGE_PRUNING_PRUNER_RANDOMPRUNER_H_
