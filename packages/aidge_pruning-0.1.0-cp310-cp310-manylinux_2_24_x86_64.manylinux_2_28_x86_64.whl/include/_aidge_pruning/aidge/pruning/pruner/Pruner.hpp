/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_PRUNING_PRUNER_PRUNER_H_
#define AIDGE_PRUNING_PRUNER_PRUNER_H_

#include <memory>
#include <vector>

#include "aidge/data/Tensor.hpp"
#include "aidge/graph/GraphView.hpp"
#include "aidge/operator/MetaOperator.hpp"
#include "aidge/operator/OperatorTensor.hpp"
#include "aidge/pruning/pruningRate/PRScheduler.hpp"

namespace Aidge {

/**
 * @brief Interface for pruner classes.
 * Masks to prune and the pruning rate scheduler should be specified outside
 * of the constructor in their own setter functions to avoid constructors with
 * too many parameters in derived classes.
 */
class Pruner {
  protected:
    /// @brief List of Tensors to update.
    std::vector<std::pair<std::shared_ptr<Tensor>, std::shared_ptr<Tensor>>>
        mDataAndMasks{};
    /// @brief Learning rate scheduler.
    /// @note Initialized with constant learning rate.
    PRScheduler mPRScheduler = PRScheduler(1.0e-5f);

  public:
    Pruner() = default;

    virtual ~Pruner() noexcept;

  public:
    // getter & setters
    inline const std::vector<
        std::pair<std::shared_ptr<Tensor>, std::shared_ptr<Tensor>>> &
    dataAndMasks() const noexcept
    {
        return mDataAndMasks;
    }

    virtual void setDataAndMasks(
        const std::vector<std::pair<std::shared_ptr<Tensor>,
                                    std::shared_ptr<Tensor>>> &dataAndMasks)
    {
        mDataAndMasks = dataAndMasks;
    }

    constexpr float pruningRate() const noexcept
    {
        return mPRScheduler.pruningRate();
    }

    const PRScheduler &pruningRateScheduler() const noexcept
    {
        return mPRScheduler;
    }

    void setPruningRateScheduler(const PRScheduler &prscheduler)
    {
        mPRScheduler = prscheduler;
    }

    /**
     * @brief Update each mask Tensor registered with respect to the associated
     * update function.
     */
    virtual void updateMasks() {}
};

} // namespace Aidge

#endif // AIDGE_PRUNING_PRUNER_PRUNER_H_
