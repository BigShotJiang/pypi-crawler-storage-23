/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_PRUNING_PRUNER_PRSCHEDULER_H_
#define AIDGE_PRUNING_PRUNER_PRSCHEDULER_H_

#include <cstddef>    // std::size_t
#include <functional> // std::function
#include <vector>

namespace Aidge {

/**
 * @class PRScheduler
 * @brief Manage the pruning rate evolution.
 *
 */
class PRScheduler {
  private:
    /// @brief Current step
    std::size_t mStep = 0;
    /// @brief Pointer to PR update function. Takes a single float value as
    /// parameter.
    std::function<float(float, const std::size_t)> mStepFunc;

    /// @brief Current learning Rate
    float mPR;
    /// @brief Initial learning Rate passed in the constructor
    float mInitialPR;

  public:
    PRScheduler() = delete;

    /**
     * @brief Construct a new PRScheduler object. Default is ConstantPR.
     *
     * @param initialPR Initial learning rate.
     * Will default to 0 if a negative value is passed.
     * @param stepFunc Recursive update function for learning rate value.
     * Default is the Constant function.
     * @param nb_warmup_steps Number of warm-up steps before starting to use
     * ``stepFunc`` for learning rate update. If specified, learning rate will
     * linearly increase from 0 to ``initialLR``.
     * Default is 0.
     */
    PRScheduler(
        const float initialPR,
        std::function<float(float, const std::size_t)> stepFunc =
            [](float val, const std::size_t /*step*/) { return val; })
        : mStepFunc(stepFunc),
          mPR((initialPR > 0.0f) ? initialPR : 0.0f),
          mInitialPR(mPR)
    {
        // ctor
    }

    // Copy constructor
    PRScheduler(const PRScheduler &other)
        : mStep(other.mStep),
          mStepFunc(other.mStepFunc),
          mPR(other.mPR),
          mInitialPR(other.mInitialPR)
    {
        // Copy constructor implementation
    }

    PRScheduler &operator=(const PRScheduler &) = default;
    // PRScheduler(PRScheduler&&)      = default;

  public:
    // Getters & setters
    constexpr inline std::size_t step() const noexcept { return mStep; }
    constexpr inline float pruningRate() const noexcept { return mPR; }

    /**
     * @brief Update the pruning rate to the next value.
     * @note The pruning rate is updated using the provided function.
     */
    void update() { mPR = mStepFunc(mPR, mStep); };

    std::vector<float> pr_profiling(const std::size_t nbStep) const;

    constexpr void reset() noexcept
    {
        mStep = 0;
        mPR = mInitialPR;
    }
};

} // namespace Aidge

#endif /* AIDGE_PRUNING_PRUNER_PRSCHEDULER_H_ */
