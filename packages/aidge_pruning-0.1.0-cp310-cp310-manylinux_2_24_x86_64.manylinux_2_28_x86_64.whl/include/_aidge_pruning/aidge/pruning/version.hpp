#ifndef aidge_pruning_VERSION_H
#define aidge_pruning_VERSION_H

namespace Aidge {
namespace pruning {

	struct Version {
		static constexpr int major = 0;
		static constexpr int minor = 1;
		static constexpr int patch = 0;
		static constexpr const char* full = "0.1.0";
		static constexpr const char* git_hash = "97afca0";
	};
} // namespace pruning
} // namespace Aidge

#endif
