/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_PRUNING_OPERATOR_PRUNE_H_
#define AIDGE_PRUNING_OPERATOR_PRUNE_H_

#include <cassert>
#include <memory>
#include <vector>

#include "aidge/backend/OperatorImpl.hpp"
#include "aidge/graph/Node.hpp"
#include "aidge/operator/OperatorTensor.hpp"
#include "aidge/operator/Producer.hpp"
#include "aidge/utils/ErrorHandling.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/Types.h"

namespace Aidge {

/**
 * @brief The Prune operator applies a binary mask to its input to produce its
 * output. The mask is accessible through the operator's second output.
 * The DataType of the mask tensor is fixed to Int8.
 * A Pruner object is required to initialize and update the mask.
 *
 */
class Prune_Op : public OperatorTensorWithImpl<Prune_Op> {
  public:
    static constexpr const char *const Type = "Prune";
    static constexpr const char *const InputsName[] = {"data_input"};
    static constexpr const char *const OutputsName[] = {"data_output", "mask"};

    Prune_Op() : OperatorTensorWithImpl(Type, {InputCategory::Data}, 2)
    {
        mOutputs[1]->toDtype(DataType::Int8);
    }

    bool forwardDims(bool allowDataDependency = false) override final;
    void setDataType(const DataType &dataType) const override final;
};

inline std::shared_ptr<Node> Prune(const std::string &name = "")
{
    return std::make_shared<Node>(std::make_shared<Prune_Op>(), name);
}

} // namespace Aidge

#endif /* AIDGE_PRUNING_OPERATOR_PRUNE_H_ */
