"""
Backwards-compatible setup.py for AltSportsData SDK

The main configuration is in pyproject.toml
"""

from setuptools import setup

if __name__ == "__main__":
    setup()