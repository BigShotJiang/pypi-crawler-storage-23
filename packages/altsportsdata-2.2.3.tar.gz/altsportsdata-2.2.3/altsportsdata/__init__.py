"""
AltSportsData Python SDK

Alternative sports odds & data for sportsbooks, DFS platforms, and prediction markets.

Quick start::

    pip install altsportsdata

    from altsportsdata import AltSportsData

    client = AltSportsData(api_key="your_key")
    wsl = client.get_league("wsl")

    events = wsl.list_events(status="upcoming")
    odds = wsl.get_moneylines(events[0].id)

    # Or discover what's available across all leagues
    for m in client.get_markets():
        print(f"{m['league']:12} {m['event_name']:30} {', '.join(m['markets'])}")

Docs: https://api.altsportsdata.com/public/docs
API:  https://api.altsportsdata.com/public/docs/swagger
"""

__version__ = "2.2.3"
__author__ = "AltSportsData"
__description__ = "The data feed for alternative sports betting — odds, events, futures for 30 leagues"

from .client import AltSportsData
from .models import (
    # Enums
    SportType,
    OddType,
    EventStatus,
    MarketStatus,
    Settlement,
    PropSettlement,
    LapStatus,
    FutureType,
    ExactasType,
    OverUnderSubMarketType,
    SortOrder,
    # Core models
    Team,
    Athlete,
    RoundScore,
    # Event models
    EventResponse,
    EventListing,
    EventParticipant,
    EventRoundListing,
    EventRoundHeatListing,
    ScoresListing,
    TeamsListing,
    # Jai Alai
    JaiAlaiEvent,
    JaiAlaiOdds,
    ScoreDetail,
    SetDetail,
    TeamDetail,
    # Odds models
    EventWinnerOdd,
    FastestLapOdd,
    HeatOddsAthlete,
    HeatOddsEvent,
    HeatOddsRound,
    HeadToHead,
    PlayerEventParticipant,
    PlayerAthlete,
    PropBet,
    DreamTeam,
    DreamTeamTeam,
    ProjectionExacta,
    ExactasAthlete,
    OverUnderOdd,
    OverUnderGroup,
    MultiOverUnder,
    SelectionDto,
    # SGP
    SgpRequest,
    SgpResponse,
    # Futures
    FutureListing,
    FutureOdds,
    FutureOdd,
    FutureOddAthlete,
    # Sports
    SportsListing,
    # Jai Alai odds
    BaseSelection,
    MoneyLineGroup,
    EventWinnerMarket,
    SpreadSelection,
    SpreadGroup,
    TotalSetsSelection,
    TotalSetsGroup,
    MatchWinnerMarketType,
    SetOdds,
)
from .exceptions import (
    AltSportsDataError,
    AuthenticationError,
    ValidationError,
    RateLimitError,
    NotFoundError,
    PermissionError,
    ServerError,
    NetworkError,
    ConfigurationError,
    DataFormatError,
)

__all__ = [
    "AltSportsData",
    # Enums
    "SportType", "OddType", "EventStatus", "MarketStatus",
    "Settlement", "PropSettlement", "LapStatus", "FutureType",
    "ExactasType", "OverUnderSubMarketType", "SortOrder",
    # Core
    "Team", "Athlete", "RoundScore",
    # Events
    "EventResponse", "EventListing", "EventParticipant",
    "EventRoundListing", "EventRoundHeatListing", "ScoresListing", "TeamsListing",
    # Jai Alai
    "JaiAlaiEvent", "JaiAlaiOdds", "ScoreDetail", "SetDetail", "TeamDetail",
    # Odds
    "EventWinnerOdd", "FastestLapOdd", "HeatOddsAthlete", "HeatOddsEvent",
    "HeatOddsRound", "HeadToHead", "PlayerEventParticipant", "PlayerAthlete",
    "PropBet", "DreamTeam", "DreamTeamTeam", "ProjectionExacta", "ExactasAthlete",
    "OverUnderOdd", "OverUnderGroup", "MultiOverUnder", "SelectionDto",
    # SGP
    "SgpRequest", "SgpResponse",
    # Futures
    "FutureListing", "FutureOdds", "FutureOdd", "FutureOddAthlete",
    # Sports
    "SportsListing",
    # Jai Alai odds
    "BaseSelection", "MoneyLineGroup", "EventWinnerMarket",
    "SpreadSelection", "SpreadGroup", "TotalSetsSelection", "TotalSetsGroup",
    "MatchWinnerMarketType", "SetOdds",
    # Exceptions
    "AltSportsDataError", "AuthenticationError", "ValidationError",
    "RateLimitError", "NotFoundError", "PermissionError", "ServerError",
    "NetworkError", "ConfigurationError", "DataFormatError",
]
