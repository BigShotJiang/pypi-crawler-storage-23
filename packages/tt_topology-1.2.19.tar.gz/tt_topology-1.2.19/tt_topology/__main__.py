# SPDX-FileCopyrightText: © 2024 Tenstorrent Inc.
# SPDX-License-Identifier: Apache-2.0

import tt_topology


if __name__ == "__main__":
    tt_topology.main()
