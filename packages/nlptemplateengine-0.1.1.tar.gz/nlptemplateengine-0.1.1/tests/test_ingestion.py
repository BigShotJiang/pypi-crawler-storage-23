from pathlib import Path

from NLPTemplateEngine.ingestion import convert_csv_data


def test_convert_csv_data_smoke():
    path = Path("src/NLPTemplateEngine/resources/dfQASParameters.csv")
    specs = convert_csv_data(path)

    assert "Templates" in specs
    assert "Defaults" in specs
    assert "Questions" in specs
    assert "Shortcuts" in specs
    assert "RandomTabularDataset" in specs["Templates"]
