import NLPTemplateEngine.core as core


def _specs():
    return {
        "ParameterQuestions": {
            "RandomTabularDataset": {
                "items": {"Items": []},
            }
        },
        "ParameterTypePatterns": {
            "RandomTabularDataset": {
                "items": "{_String..}",
            }
        },
        "Templates": {
            "RandomTabularDataset": {
                "Python": {
                    "Template": [
                        {
                            "Value": "call(`items`)",
                        }
                    ]
                }
            }
        },
        "Defaults": {"RandomTabularDataset": {}},
        "Questions": {},
        "Shortcuts": {},
    }


def test_concretize_fills_template(monkeypatch):
    monkeypatch.setattr(core, "get_specs", lambda spec_type="standard": _specs())

    def fake_llm_textual_answer(command, questions, **kwargs):
        return {questions[0]: "a, b"}

    monkeypatch.setattr(core, "llm_textual_answer", fake_llm_textual_answer)

    result = core.concretize("cmd", template="RandomTabularDataset", lang="Python")
    assert result == 'call(["a", "b"])'


def test_concretize_classifies(monkeypatch):
    monkeypatch.setattr(core, "get_specs", lambda spec_type="standard": _specs())

    def fake_llm_textual_answer(command, questions, **kwargs):
        return {questions[0]: "a, b"}

    def fake_llm_classify(command, labels, **kwargs):
        return "Random Tabular Dataset"

    monkeypatch.setattr(core, "llm_textual_answer", fake_llm_textual_answer)
    monkeypatch.setattr(core, "llm_classify", fake_llm_classify)

    result = core.concretize("cmd", template=None, lang="Python")
    assert result == 'call(["a", "b"])'
