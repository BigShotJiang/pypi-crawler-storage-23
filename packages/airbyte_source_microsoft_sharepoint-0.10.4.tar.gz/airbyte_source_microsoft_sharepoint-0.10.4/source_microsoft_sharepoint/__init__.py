#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#


from .source import SourceMicrosoftSharePoint

__all__ = ["SourceMicrosoftSharePoint"]
