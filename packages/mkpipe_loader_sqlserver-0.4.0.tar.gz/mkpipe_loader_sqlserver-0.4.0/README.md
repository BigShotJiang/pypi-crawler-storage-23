# mkpipe-loader-sqlserver

SQL Server loader plugin for mkpipe.
