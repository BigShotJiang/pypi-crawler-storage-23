"""Resource modules package."""
