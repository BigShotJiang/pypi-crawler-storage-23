"""Export OpenAPI spec from FastAPI app to openapi.json."""

import json
import sys
from pathlib import Path

from kubera.api.main import create_app


def main() -> None:
    app = create_app()
    spec = app.openapi()
    out = Path("openapi.json")
    out.write_text(json.dumps(spec, indent=2) + "\n")
    print(f"Wrote {out} (version {spec['info']['version']})")


if __name__ == "__main__":
    main()
