# Kubera Core

Personal asset management backend. All financial data stays on your machine.

## Install & Run

```bash
pip install kubera-core
kubera-core start
```

- API docs: http://localhost:8000/docs
- Auth token is auto-generated and printed on first start

## Options

```bash
kubera-core start --host 127.0.0.1 --port 3000
kubera-core token                    # show current token
kubera-core token --refresh          # generate new token
```

## Credential Management

API keys for financial services are managed via CLI only (never through web).

```bash
kubera-core credential add upbit     # interactive masked input
kubera-core credential list          # show status
kubera-core credential remove upbit
```

Supported providers: upbit, kis, binance, codef

## Tech Stack

FastAPI, SQLAlchemy (SQLite), Pydantic, cryptography (Fernet)

## Related

- [kubera-web](https://github.com/oh-my-kubera/kubera-web) — Next.js dashboard (PWA)

## License

MIT
