"""FastAPI dependencies."""

from __future__ import annotations

from typing import Generator

from fastapi import Request
from sqlalchemy.orm import Session

from kubera.core.models.base import get_engine, get_session


def get_db(request: Request) -> Generator[Session, None, None]:
    """Yield a database session, closing after request."""
    settings = request.app.state.settings
    engine = get_engine(settings.database_url)
    session = get_session(engine)
    try:
        yield session
    finally:
        session.close()
