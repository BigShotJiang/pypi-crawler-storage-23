# api

> Parent: [kubera/CONTEXT.md](../CONTEXT.md)

FastAPI HTTP layer. All state lives in core.

## Key patterns

- `create_app(settings)` factory. Settings stored in `app.state.settings`.
- Auth: Bearer token via `verify_token` dependency. All routers except `/api/v1/health`.
- DB: `get_db(request)` yields session per request. Tests override via `dependency_overrides`.
- Schemas: `from_attributes=True` for ORM conversion. `PaginatedResponse[T]` generic.
- Errors: `KuberaError(detail, code, status)` → `{"detail", "code", "status"}`.

## Endpoints

| Method | Path | Auth | Notes |
|--------|------|:----:|-------|
| GET | /health | no | |
| POST | /snapshots/import | yes | multipart file upload |
| GET | /snapshots | yes | paginated |
| GET | /snapshots/trend | yes | date filter |
| GET | /snapshots/compare | yes | from_date + to_date |
| GET | /snapshots/{id} | yes | detail with entries |
| GET | /snapshots/{id}/ledger | yes | paginated ledger entries |
| POST | /snapshots/{id}/assets | yes | add manual asset entry |
| DELETE | /snapshots/{id}/assets/{entry_id} | yes | remove asset entry |
| DELETE | /snapshots/{id} | yes | hard delete (cascade) |

All paths prefixed with `/api/v1`.

## Cross-repo contract

`openapi.json` is source of truth. kubera-web generates TS types from it. CI syncs on release.
