# core

> Parent: [kubera/CONTEXT.md](../CONTEXT.md)

Business logic. No HTTP/CLI awareness.

## Models

All inherit `(TimestampMixin, Base)` — `created_at`, `updated_at`, `deleted_at`. All have `user_id: str = "default"`.

| Model | Role |
|-------|------|
| Snapshot | Parent record per date+source. Hard delete cascades children. |
| AssetEntry, InvestmentEntry, LoanEntry, InsuranceEntry | Child entry tables (details in `snapshot/CONTEXT.md`) |
| LedgerEntry | Cash flow entries from Banksalad Sheet 2 |

## Service pattern

`XxxService(db: Session)` — receives session, owns commit/refresh. No static methods.

## Packages

- `snapshot/` — Banksalad Excel import, manual asset entries, trend, comparison (see `snapshot/CONTEXT.md`)

## DB

SQLite + WAL mode. Factory: `get_engine(url)` → `get_session(engine)`.
No alembic — tables via `create_all()`. `models/__init__.py` re-exports everything.

## Decisions

| Decision | Choice | Reason |
|----------|--------|--------|
| No Alembic | `create_all()` | Self-hosted single-user app; schema rarely changes |
| Hard delete for Snapshot | CASCADE | Financial snapshots are immutable imports, no soft-delete needed |
| Single `snapshot/` package | Flat structure | Only one domain so far; split when a second domain appears |
