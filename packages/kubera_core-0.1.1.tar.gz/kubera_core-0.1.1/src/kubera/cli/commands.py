"""CLI subcommands."""

from __future__ import annotations

import argparse
import sys

PROVIDER_FIELDS: dict[str, list[dict]] = {
    "mail": [
        {"name": "imap_host", "required": True, "prompt": "IMAP host (e.g. imap.gmail.com)"},
        {"name": "imap_port", "required": False, "prompt": "IMAP port", "default": "993"},
        {"name": "email", "required": True, "prompt": "Email address"},
        {"name": "password", "required": True, "prompt": "Password (app password)", "secret": True},
        {"name": "sender_filter", "required": False, "prompt": "Sender filter", "default": "banksalad"},
    ],
}


def cmd_start(args: argparse.Namespace) -> None:
    """Start the Kubera server."""
    from kubera.core.config import get_settings

    settings = get_settings()
    token = settings.ensure_token()

    host = args.host or settings.host
    port = args.port or settings.port

    # Run Alembic migrations if alembic.ini exists
    _run_migrations(settings.database_url)

    print(f"Starting Kubera on {host}:{port}")
    print(f"API docs: http://{host}:{port}/docs")
    print(f"Token: {token}")

    if getattr(args, "mail_watch", False):
        mail_config = _get_mail_config()
        if mail_config is None:
            print("Error: no mail credential configured.")
            print("Run 'kubera-core credential add mail' first.")
            sys.exit(1)

        import threading
        from kubera.core.models import get_engine, get_session
        from kubera.core.snapshot.mail_watcher import MailWatcher

        engine = get_engine(settings.database_url)
        watcher = MailWatcher(
            db_factory=lambda: get_session(engine),
            imap_config=mail_config,
            zip_password=settings.snapshot_zip_password,
        )
        thread = threading.Thread(target=watcher.start, kwargs={"interval": settings.mail_watch_interval}, daemon=True)
        thread.start()
        print(f"Mail watcher enabled (interval: {settings.mail_watch_interval}s)")

    import uvicorn
    from kubera.api.main import create_app

    app = create_app(settings)
    uvicorn.run(app, host=host, port=port)


def cmd_token(args: argparse.Namespace) -> None:
    """Show or refresh the auth token."""
    from kubera.core.config import Settings

    settings = Settings()

    if args.refresh:
        import secrets
        token = secrets.token_urlsafe(32)
        settings.secret_token = token
        settings._write_token_to_env(token)
        print(f"New token: {token}")
    else:
        token = settings.ensure_token()
        print(token)


def cmd_snapshot(args: argparse.Namespace) -> None:
    """Manage financial snapshots."""
    if args.snap_command == "import":
        _cmd_snapshot_import(args)
    elif args.snap_command == "list":
        _cmd_snapshot_list()
    else:
        print("Usage: kubera-core snapshot {import,list}")


def _cmd_snapshot_import(args: argparse.Namespace) -> None:
    """Import a Banksalad Excel export."""
    from pathlib import Path

    from kubera.core.config import Settings
    from kubera.core.models import Base, get_engine, get_session
    from kubera.core.snapshot.service import SnapshotService

    file_path = Path(args.file)
    if not file_path.exists():
        print(f"Error: file not found: {file_path}")
        sys.exit(1)

    settings = Settings()
    engine = get_engine(settings.database_url)
    Base.metadata.create_all(engine)
    session = get_session(engine)
    try:
        svc = SnapshotService(session)
        snapshot = svc.import_from_file(file_path, password=args.password)
        print(f"Imported snapshot: {snapshot.snapshot_date} (source={snapshot.source})")
        print(f"  Credit score: {snapshot.credit_score}")
        print(f"  Total assets: {snapshot.total_assets:,.0f}")
        print(f"  Total liabilities: {snapshot.total_liabilities:,.0f}")
        print(f"  Net worth: {snapshot.net_worth:,.0f}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
    finally:
        session.close()


def _cmd_snapshot_list() -> None:
    """List snapshots."""
    from kubera.core.config import Settings
    from kubera.core.models import Base, get_engine, get_session
    from kubera.core.snapshot.service import SnapshotService

    settings = Settings()
    engine = get_engine(settings.database_url)
    Base.metadata.create_all(engine)
    session = get_session(engine)
    try:
        svc = SnapshotService(session)
        items, total = svc.list_snapshots()
        if not items:
            print("No snapshots found.")
            return
        print(f"{'Date':<14} {'Source':<12} {'Net Worth':>16} {'Credit':>8}")
        print("-" * 52)
        for s in items:
            credit = str(s.credit_score) if s.credit_score else "-"
            print(f"{s.snapshot_date!s:<14} {s.source:<12} {s.net_worth:>16,.0f} {credit:>8}")
        print(f"\nTotal: {total} snapshot(s)")
    finally:
        session.close()


def cmd_credential(args: argparse.Namespace) -> None:
    """Manage credentials."""
    if args.cred_command == "add":
        _cmd_credential_add(args)
    elif args.cred_command == "list":
        _cmd_credential_list()
    elif args.cred_command == "remove":
        _cmd_credential_remove(args)
    else:
        print("Usage: kubera-core credential {add,list,remove}")


def _cmd_credential_add(args: argparse.Namespace) -> None:
    """Interactively add a credential for a provider."""
    import getpass

    provider = args.provider
    if provider not in PROVIDER_FIELDS:
        print(f"Error: unsupported provider '{provider}'. Supported: {', '.join(PROVIDER_FIELDS)}")
        sys.exit(1)

    fields = PROVIDER_FIELDS[provider]
    credential: dict[str, str] = {"provider": provider}
    for field in fields:
        default = field.get("default")
        prompt = field["prompt"]
        if default:
            prompt = f"{prompt} [{default}]"
        prompt += ": "
        if field.get("secret"):
            value = getpass.getpass(prompt)
        else:
            value = input(prompt)
        if not value and default is not None:
            value = default
        if field["required"] and not value:
            print(f"Error: '{field['name']}' is required.")
            sys.exit(1)
        if value:
            credential[field["name"]] = value

    _save_credential(credential)
    print(f"Credential for '{provider}' saved.")


def _cmd_credential_list() -> None:
    """List saved credentials."""
    credentials = _load_credentials()
    if not credentials:
        print("No credentials stored.")
        return
    print(f"{'Provider':<12} {'Key':<20} {'Value'}")
    print("-" * 50)
    for cred in credentials:
        provider = cred.get("provider", "")
        for key, value in cred.items():
            if key == "provider":
                continue
            display = "***" if key == "password" else value
            print(f"{provider:<12} {key:<20} {display}")
            provider = ""  # only show provider on first row


def _cmd_credential_remove(args: argparse.Namespace) -> None:
    """Remove credentials for a provider."""
    provider = args.provider
    credentials = _load_credentials()
    remaining = [c for c in credentials if c.get("provider") != provider]
    if len(remaining) == len(credentials):
        print(f"No credential found for provider '{provider}'.")
        sys.exit(1)
    _write_credentials(remaining)
    print(f"Credential for '{provider}' removed.")


def _credentials_path() -> "Path":
    from pathlib import Path
    return Path(".kubera_credentials.json")


def _load_credentials() -> list[dict]:
    import json
    path = _credentials_path()
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_credential(credential: dict) -> None:
    credentials = _load_credentials()
    # Replace existing entry for same provider
    provider = credential["provider"]
    credentials = [c for c in credentials if c.get("provider") != provider]
    credentials.append(credential)
    _write_credentials(credentials)


def _write_credentials(credentials: list[dict]) -> None:
    import json
    _credentials_path().write_text(json.dumps(credentials, indent=2))


def cmd_mail_watch(args: argparse.Namespace) -> None:
    """Run IMAP mail watcher in foreground."""
    from kubera.core.config import get_settings
    from kubera.core.models import get_engine, get_session
    from kubera.core.snapshot.mail_watcher import MailWatcher

    mail_config = _get_mail_config()
    if mail_config is None:
        print("Error: no mail credential configured.")
        print("Run 'kubera-core credential add mail' first.")
        sys.exit(1)

    settings = get_settings()
    engine = get_engine(settings.database_url)

    watcher = MailWatcher(
        db_factory=lambda: get_session(engine),
        imap_config=mail_config,
        zip_password=settings.snapshot_zip_password,
    )

    print(f"Starting mail watcher (interval: {settings.mail_watch_interval}s)")
    print("Press Ctrl+C to stop.")
    try:
        watcher.start(interval=settings.mail_watch_interval)
    except KeyboardInterrupt:
        watcher.stop()
        print("\nMail watcher stopped.")


def _get_mail_config() -> dict | None:
    """Load mail credential from stored credentials. Returns None if not found."""
    credentials = _load_credentials()
    for cred in credentials:
        if cred.get("provider") == "mail":
            return cred
    return None


def _run_migrations(database_url: str) -> None:
    """Run Alembic migrations if configured."""
    from pathlib import Path

    if not Path("alembic.ini").exists():
        return

    try:
        from alembic.config import Config
        from alembic import command

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", database_url)
        command.upgrade(alembic_cfg, "head")
    except Exception:
        # If no migrations exist yet, just skip
        pass
