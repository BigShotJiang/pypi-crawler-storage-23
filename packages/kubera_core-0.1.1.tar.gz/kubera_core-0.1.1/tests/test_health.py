"""Tests for health endpoint."""

import pytest
from fastapi.testclient import TestClient

from kubera.api.main import create_app
from kubera.core.config import Settings


@pytest.fixture()
def client():
    settings = Settings(_env_file=None, database_url="sqlite:///:memory:")
    app = create_app(settings)
    return TestClient(app)


def test_health_returns_ok(client):
    resp = client.get("/api/v1/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


def test_health_no_auth_required(client):
    # No Authorization header - should still work
    resp = client.get("/api/v1/health")
    assert resp.status_code == 200
