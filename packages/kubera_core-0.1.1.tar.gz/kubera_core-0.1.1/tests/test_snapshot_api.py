"""Tests for snapshot API endpoints."""

from datetime import date
from decimal import Decimal
from io import BytesIO
from pathlib import Path
import tempfile

from openpyxl import Workbook

from kubera.core.snapshot.models import Snapshot, AssetEntry, InvestmentEntry, LedgerEntry, LoanEntry, InsuranceEntry


def _create_test_xlsx_bytes(filename_stem="2025-01-01~2025-01-15"):
    """Create test xlsx in memory matching real Banksalad structure."""
    wb = Workbook()
    ws = wb.active

    row = 2
    # 1. Customer info
    ws.cell(row=row, column=2, value="1.고객정보")
    row += 2
    ws.cell(row=row, column=2, value="이름")
    ws.cell(row=row, column=5, value="신용점수\n(KCB)")
    row += 1
    ws.cell(row=row, column=2, value="홍길동")
    ws.cell(row=row, column=5, value=820)
    row += 2

    # 3. Finance
    ws.cell(row=row, column=2, value="3.재무현황")
    row += 2
    ws.cell(row=row, column=2, value="항목")
    ws.cell(row=row, column=3, value="상품명")
    ws.cell(row=row, column=5, value="금액")
    ws.cell(row=row, column=6, value="항목")
    ws.cell(row=row, column=7, value="상품명")
    ws.cell(row=row, column=9, value="금액")
    row += 1
    ws.cell(row=row, column=2, value="예금")
    ws.cell(row=row, column=3, value="신한 정기예금")
    ws.cell(row=row, column=5, value=50000000)
    ws.cell(row=row, column=6, value="신용대출")
    ws.cell(row=row, column=7, value="신용대출")
    ws.cell(row=row, column=9, value=10000000)
    row += 1
    ws.cell(row=row, column=2, value="총자산")
    ws.cell(row=row, column=5, value=50000000)
    ws.cell(row=row, column=6, value="총부채")
    ws.cell(row=row, column=9, value=10000000)
    row += 2

    # 4. Insurance
    ws.cell(row=row, column=2, value="4.보험현황")
    row += 2
    ws.cell(row=row, column=2, value="금융사")
    ws.cell(row=row, column=3, value="보험명")
    ws.cell(row=row, column=5, value="계약상태")
    ws.cell(row=row, column=6, value="총납입금")
    row += 1
    ws.cell(row=row, column=2, value="삼성생명")
    ws.cell(row=row, column=3, value="종신보험")
    ws.cell(row=row, column=5, value="유지")
    ws.cell(row=row, column=6, value=1000000)
    row += 1
    ws.cell(row=row, column=2, value="합계")
    row += 2

    # 5. Investment
    ws.cell(row=row, column=2, value="5.투자현황")
    row += 2
    ws.cell(row=row, column=2, value="투자상품종류")
    ws.cell(row=row, column=3, value="금융사")
    ws.cell(row=row, column=4, value="상품명")
    ws.cell(row=row, column=6, value="투자원금")
    ws.cell(row=row, column=7, value="평가금액")
    ws.cell(row=row, column=8, value="수익률")
    row += 1
    ws.cell(row=row, column=2, value="주식")
    ws.cell(row=row, column=3, value="한국투자")
    ws.cell(row=row, column=4, value="TIGER ETF")
    ws.cell(row=row, column=6, value=5000000)
    ws.cell(row=row, column=7, value=5500000)
    ws.cell(row=row, column=8, value=10.0)
    row += 1
    ws.cell(row=row, column=2, value="합계")
    row += 2

    # 6. Loan
    ws.cell(row=row, column=2, value="6.대출현황")
    row += 2
    ws.cell(row=row, column=2, value="대출종류")
    ws.cell(row=row, column=3, value="금융사")
    ws.cell(row=row, column=4, value="상품명")
    ws.cell(row=row, column=6, value="대출원금")
    ws.cell(row=row, column=7, value="대출잔액")
    ws.cell(row=row, column=8, value="대출금리")
    row += 1
    ws.cell(row=row, column=2, value="신용")
    ws.cell(row=row, column=3, value="국민은행")
    ws.cell(row=row, column=4, value="신용대출")
    ws.cell(row=row, column=6, value=10000000)
    ws.cell(row=row, column=7, value=9000000)
    ws.cell(row=row, column=8, value=4.5)
    row += 1
    ws.cell(row=row, column=2, value="합계")

    # Sheet 2: Ledger
    ws2 = wb.create_sheet("가계부 내역")
    ws2.cell(row=1, column=1, value="날짜")
    ws2.cell(row=1, column=2, value="시간")
    ws2.cell(row=1, column=3, value="타입")
    ws2.cell(row=1, column=4, value="대분류")
    ws2.cell(row=1, column=5, value="소분류")
    ws2.cell(row=1, column=6, value="내용")
    ws2.cell(row=1, column=7, value="금액")
    ws2.cell(row=1, column=8, value="화폐")
    ws2.cell(row=1, column=9, value="결제수단")
    ws2.cell(row=1, column=10, value="메모")
    ws2.cell(row=2, column=1, value="2025-01-14")
    ws2.cell(row=2, column=3, value="지출")
    ws2.cell(row=2, column=4, value="식비")
    ws2.cell(row=2, column=5, value="외식")
    ws2.cell(row=2, column=6, value="점심")
    ws2.cell(row=2, column=7, value=-12000)
    ws2.cell(row=2, column=8, value="KRW")
    ws2.cell(row=2, column=9, value="신한카드")
    ws2.cell(row=3, column=1, value="2025-01-10")
    ws2.cell(row=3, column=3, value="수입")
    ws2.cell(row=3, column=4, value="급여")
    ws2.cell(row=3, column=7, value=3000000)
    ws2.cell(row=3, column=8, value="KRW")
    ws2.cell(row=4, column=1, value="2025-01-12")
    ws2.cell(row=4, column=3, value="이체")
    ws2.cell(row=4, column=4, value="이체")
    ws2.cell(row=4, column=7, value=-500000)

    buf = BytesIO()
    wb.save(buf)
    wb.close()
    buf.seek(0)
    return buf.getvalue(), f"{filename_stem}.xlsx"


def _seed_snapshot(db, snapshot_date, source="banksalad"):
    """Seed a snapshot directly in DB for testing."""
    snapshot = Snapshot(
        user_id="default",
        snapshot_date=snapshot_date,
        source=source,
        credit_score=800,
        total_assets=Decimal("50000000"),
        total_liabilities=Decimal("10000000"),
        net_worth=Decimal("40000000"),
        asset_entries=[AssetEntry(category="deposit", product_name="Test", amount=Decimal("50000000"))],
        investment_entries=[InvestmentEntry(broker="B", product_name="C", invested_amount=Decimal("1000"), current_value=Decimal("1100"))],
        loan_entries=[LoanEntry(lender="D", product_name="E", principal=Decimal("10000000"), balance=Decimal("9000000"))],
        insurance_entries=[InsuranceEntry(insurer="F", product_name="G", status="active", total_paid=Decimal("500000"))],
        ledger_entries=[
            LedgerEntry(entry_date=date(2025, 1, 10), entry_type="지출", major_category="식비", amount=Decimal("-12000")),
            LedgerEntry(entry_date=date(2025, 1, 5), entry_type="수입", major_category="급여", amount=Decimal("3000000")),
        ],
    )
    db.add(snapshot)
    db.commit()
    db.refresh(snapshot)
    return snapshot


class TestImportEndpoint:
    def test_import_xlsx(self, client, auth_headers):
        content, filename = _create_test_xlsx_bytes()
        resp = client.post(
            "/api/v1/snapshots/import",
            files={"file": (filename, content, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
            headers=auth_headers,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["snapshot_date"] == "2025-01-15"
        assert data["source"] == "banksalad"
        assert data["credit_score"] == 820
        assert float(data["total_assets"]) == 50000000.0
        assert float(data["total_liabilities"]) == 10000000.0

    def test_import_duplicate_returns_409(self, client, auth_headers):
        content, filename = _create_test_xlsx_bytes()
        client.post(
            "/api/v1/snapshots/import",
            files={"file": (filename, content, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
            headers=auth_headers,
        )
        resp = client.post(
            "/api/v1/snapshots/import",
            files={"file": (filename, content, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
            headers=auth_headers,
        )
        assert resp.status_code == 409
        assert resp.json()["code"] == "SNAPSHOT_DUPLICATE"


class TestListEndpoint:
    def test_list_snapshots(self, client, auth_headers, db):
        _seed_snapshot(db, date(2025, 1, 15))
        _seed_snapshot(db, date(2025, 2, 15))

        resp = client.get("/api/v1/snapshots", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["items"]) == 2

    def test_list_with_date_filter(self, client, auth_headers, db):
        _seed_snapshot(db, date(2025, 1, 15))
        _seed_snapshot(db, date(2025, 3, 15))

        resp = client.get("/api/v1/snapshots?start=2025-03-01", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.json()["total"] == 1


class TestGetEndpoint:
    def test_get_snapshot_detail(self, client, auth_headers, db):
        snapshot = _seed_snapshot(db, date(2025, 1, 15))

        resp = client.get(f"/api/v1/snapshots/{snapshot.id}", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["snapshot_date"] == "2025-01-15"
        assert len(data["asset_entries"]) == 1
        assert len(data["investment_entries"]) == 1
        assert len(data["loan_entries"]) == 1
        assert len(data["insurance_entries"]) == 1
        assert len(data["ledger_entries"]) == 2

    def test_get_not_found(self, client, auth_headers):
        resp = client.get("/api/v1/snapshots/9999", headers=auth_headers)
        assert resp.status_code == 404


class TestImportLedger:
    def test_import_includes_ledger_entries(self, client, auth_headers):
        content, filename = _create_test_xlsx_bytes()
        resp = client.post(
            "/api/v1/snapshots/import",
            files={"file": (filename, content, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
            headers=auth_headers,
        )
        assert resp.status_code == 201
        snapshot_id = resp.json()["id"]

        detail = client.get(f"/api/v1/snapshots/{snapshot_id}", headers=auth_headers)
        data = detail.json()
        # 이체 filtered out, 수입+지출 only
        assert len(data["ledger_entries"]) == 2
        types = {e["entry_type"] for e in data["ledger_entries"]}
        assert types == {"수입", "지출"}


class TestLedgerEndpoint:
    def test_get_ledger_entries(self, client, auth_headers, db):
        snapshot = _seed_snapshot(db, date(2025, 1, 15))

        resp = client.get(f"/api/v1/snapshots/{snapshot.id}/ledger", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["items"]) == 2

    def test_get_ledger_pagination(self, client, auth_headers, db):
        snapshot = _seed_snapshot(db, date(2025, 1, 15))

        resp = client.get(f"/api/v1/snapshots/{snapshot.id}/ledger?size=1", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["items"]) == 1
        assert data["pages"] == 2

    def test_get_ledger_not_found(self, client, auth_headers):
        resp = client.get("/api/v1/snapshots/9999/ledger", headers=auth_headers)
        assert resp.status_code == 404


class TestDeleteEndpoint:
    def test_delete_snapshot(self, client, auth_headers, db):
        snapshot = _seed_snapshot(db, date(2025, 1, 15))

        resp = client.delete(f"/api/v1/snapshots/{snapshot.id}", headers=auth_headers)
        assert resp.status_code == 204

        resp = client.get(f"/api/v1/snapshots/{snapshot.id}", headers=auth_headers)
        assert resp.status_code == 404

    def test_delete_not_found(self, client, auth_headers):
        resp = client.delete("/api/v1/snapshots/9999", headers=auth_headers)
        assert resp.status_code == 404


class TestTrendEndpoint:
    def test_trend(self, client, auth_headers, db):
        _seed_snapshot(db, date(2025, 1, 15))
        _seed_snapshot(db, date(2025, 2, 15))

        resp = client.get("/api/v1/snapshots/trend", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2
        assert data[0]["snapshot_date"] == "2025-01-15"
        assert data[1]["snapshot_date"] == "2025-02-15"

    def test_trend_with_date_filter(self, client, auth_headers, db):
        _seed_snapshot(db, date(2025, 1, 15))
        _seed_snapshot(db, date(2025, 3, 15))

        resp = client.get("/api/v1/snapshots/trend?start=2025-02-01", headers=auth_headers)
        assert resp.status_code == 200
        assert len(resp.json()) == 1


class TestCompareEndpoint:
    def test_compare(self, client, auth_headers, db):
        _seed_snapshot(db, date(2025, 1, 15))
        # Second snapshot with different values
        s2 = Snapshot(
            user_id="default",
            snapshot_date=date(2025, 2, 15),
            source="banksalad",
            credit_score=850,
            total_assets=Decimal("60000000"),
            total_liabilities=Decimal("8000000"),
            net_worth=Decimal("52000000"),
        )
        db.add(s2)
        db.commit()

        resp = client.get(
            "/api/v1/snapshots/compare?from_date=2025-01-15&to_date=2025-02-15",
            headers=auth_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["from_date"] == "2025-01-15"
        assert data["to_date"] == "2025-02-15"
        assert data["diff"]["credit_score"] == 50
        assert float(data["diff"]["net_worth"]) == 12000000.0

    def test_compare_not_found(self, client, auth_headers):
        resp = client.get(
            "/api/v1/snapshots/compare?from_date=2020-01-01&to_date=2020-02-01",
            headers=auth_headers,
        )
        assert resp.status_code == 404
