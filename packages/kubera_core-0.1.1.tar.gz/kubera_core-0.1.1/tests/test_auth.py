"""Tests for authentication."""

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient

from kubera.api.auth import verify_token
from kubera.api.main import create_app
from kubera.core.config import Settings


@pytest.fixture()
def settings():
    return Settings(_env_file=None, database_url="sqlite:///:memory:", secret_token="test-token-123")


@pytest.fixture()
def app(settings):
    app = create_app(settings)

    # Add a protected test endpoint
    @app.get("/api/v1/protected")
    def protected(token: str = Depends(verify_token)):
        return {"message": "secret", "token": token}

    return app


@pytest.fixture()
def client(app):
    return TestClient(app)


def test_valid_token(client):
    resp = client.get(
        "/api/v1/protected",
        headers={"Authorization": "Bearer test-token-123"},
    )
    assert resp.status_code == 200
    assert resp.json()["message"] == "secret"


def test_invalid_token(client):
    resp = client.get(
        "/api/v1/protected",
        headers={"Authorization": "Bearer wrong-token"},
    )
    assert resp.status_code == 401


def test_missing_token(client):
    resp = client.get("/api/v1/protected")
    assert resp.status_code == 401
