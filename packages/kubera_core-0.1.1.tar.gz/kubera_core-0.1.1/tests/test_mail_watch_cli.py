"""Tests for mail-watch CLI integration (issue #25)."""

from __future__ import annotations

import argparse
import sys
from unittest.mock import MagicMock, patch

import pytest


# Patch targets: source modules because cmd_start/cmd_mail_watch use lazy imports
_WATCHER = "kubera.core.snapshot.mail_watcher.MailWatcher"
_GET_ENGINE = "kubera.core.models.get_engine"
_GET_SESSION = "kubera.core.models.get_session"
_RUN_MIGRATIONS = "kubera.cli.commands._run_migrations"


class TestMailWatchSubcommand:
    def test_help_shows_mail_watch(self, capsys):
        from kubera.cli import main

        original = sys.argv
        sys.argv = ["kubera-core", "--help"]
        try:
            main()
        except SystemExit:
            pass
        sys.argv = original
        captured = capsys.readouterr()
        assert "mail-watch" in captured.out

    def test_start_help_shows_mail_watch_flag(self, capsys):
        from kubera.cli import main

        original = sys.argv
        sys.argv = ["kubera-core", "start", "--help"]
        try:
            main()
        except SystemExit:
            pass
        sys.argv = original
        captured = capsys.readouterr()
        assert "--mail-watch" in captured.out


class TestCmdMailWatch:
    def test_no_credential_exits_with_error(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import cmd_mail_watch

        args = argparse.Namespace()
        with pytest.raises(SystemExit) as exc_info:
            cmd_mail_watch(args)

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        assert "no mail credential" in captured.out.lower()
        assert "credential add mail" in captured.out

    def test_with_credential_starts_watcher(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        import json

        cred_path = tmp_path / ".kubera_credentials.json"
        cred_path.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.test.com",
            "email": "test@test.com",
            "password": "secret",
        }]))

        from kubera.cli.commands import cmd_mail_watch

        mock_watcher = MagicMock()
        mock_watcher.start.side_effect = KeyboardInterrupt

        with patch(_WATCHER, return_value=mock_watcher) as MockWatcher, \
             patch(_GET_ENGINE), \
             patch(_GET_SESSION):
            args = argparse.Namespace()
            cmd_mail_watch(args)

        MockWatcher.assert_called_once()
        call_kwargs = MockWatcher.call_args.kwargs
        assert call_kwargs["imap_config"]["imap_host"] == "imap.test.com"
        mock_watcher.start.assert_called_once()
        mock_watcher.stop.assert_called_once()


class TestStartWithMailWatch:
    def test_mail_watch_flag_without_credential_exits(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import cmd_start

        args = argparse.Namespace(host=None, port=None, mail_watch=True)

        with patch(_RUN_MIGRATIONS):
            with pytest.raises(SystemExit) as exc_info:
                cmd_start(args)

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        assert "no mail credential" in captured.out.lower()

    def test_mail_watch_flag_with_credential_starts_thread(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        import json

        cred_path = tmp_path / ".kubera_credentials.json"
        cred_path.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.test.com",
            "email": "test@test.com",
            "password": "secret",
        }]))

        from kubera.cli.commands import cmd_start

        args = argparse.Namespace(host=None, port=None, mail_watch=True)

        mock_thread = MagicMock()

        with patch(_RUN_MIGRATIONS), \
             patch(_WATCHER) as MockWatcher, \
             patch(_GET_ENGINE), \
             patch(_GET_SESSION), \
             patch("threading.Thread", return_value=mock_thread) as MockThread, \
             patch("uvicorn.run"), \
             patch("kubera.api.main.create_app"):
            cmd_start(args)

        MockWatcher.assert_called_once()
        mock_thread.start.assert_called_once()
        captured = capsys.readouterr()
        assert "mail watcher enabled" in captured.out.lower()

    def test_start_without_mail_watch_flag(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import cmd_start

        args = argparse.Namespace(host=None, port=None, mail_watch=False)

        with patch(_RUN_MIGRATIONS), \
             patch("uvicorn.run"), \
             patch("kubera.api.main.create_app"):
            cmd_start(args)

        captured = capsys.readouterr()
        assert "mail watcher" not in captured.out.lower()


class TestGetMailConfig:
    def test_returns_none_when_no_credentials(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import _get_mail_config

        assert _get_mail_config() is None

    def test_returns_mail_config(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        import json

        cred_path = tmp_path / ".kubera_credentials.json"
        cred_path.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.example.com",
            "email": "user@example.com",
            "password": "pass",
        }]))

        from kubera.cli.commands import _get_mail_config

        config = _get_mail_config()
        assert config is not None
        assert config["imap_host"] == "imap.example.com"

    def test_ignores_non_mail_providers(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        import json

        cred_path = tmp_path / ".kubera_credentials.json"
        cred_path.write_text(json.dumps([{
            "provider": "other",
            "host": "example.com",
        }]))

        from kubera.cli.commands import _get_mail_config

        assert _get_mail_config() is None
