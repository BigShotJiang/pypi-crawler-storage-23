from http import HTTPStatus
from typing import Never, Optional

class BaseAssertableException(Exception):
    @classmethod
    def raise_if(cls, condition: bool, message: str) -> Optional[Never]:
        if condition:
            raise cls(message)

    @classmethod
    def raise_unless(cls, condition: bool, message: str) -> Optional[Never]:
        cls.raise_if(not condition, message)

class HTTPException(BaseAssertableException):
    def __init__(self, status_code: int, message: Optional[str] = None):
        self.status_code = status_code
        if message is None:
            try:
                self.message = HTTPStatus(status_code).phrase
            except ValueError:
                self.message = f'HTTP {status_code}'
        else:
            self.message = message

        super().__init__(self.message)

    @classmethod
    def raise_if(
        cls,
        condition: bool,
        status_code: int,
        message: Optional[str] = None,
    ) -> Optional[Never]:
        if condition:
            raise cls(status_code, message)

    @classmethod
    def raise_unless(
        cls,
        condition: bool,
        status_code: int,
        message: Optional[str] = None,
    ) -> Optional[Never]:
        cls.raise_if(not condition, status_code, message)
