from time import time
from enum import StrEnum
from pathlib import Path
from http import HTTPStatus
from asyncio import to_thread
from mimetypes import guess_type
from secrets import token_urlsafe
from logging import Logger, getLogger
from .exceptions import HTTPException
from html import escape as html_escape
from dataclasses import field, dataclass
from urllib.parse import quote, unquote, parse_qs
from inspect import getmro, signature, iscoroutinefunction
from re import Match, compile, Pattern, finditer, escape as regex_escape
from json import loads as default_json_loads, dumps as default_json_dumps
from typing import (
    Any,
    Self,
    Union,
    Literal,
    TypeVar,
    overload,
    Iterator,
    Callable,
    Optional,
    Protocol,
    Awaitable,
    TypeAlias,
    AsyncIterator,
)

#region Types
Header: TypeAlias = Union['KnownHeader', str]
HeaderValue: TypeAlias = Union[str, list[str]]
Headers: TypeAlias = dict[Header, HeaderValue]
RouteResult: TypeAlias = Any
RouteHandler: TypeAlias = Callable[..., Awaitable[RouteResult]]
ErrorHandler: TypeAlias = Callable[['Context', BaseException], Awaitable[RouteResult]]
Decorator: TypeAlias = Callable[[RouteHandler], RouteHandler]
BeforeRequestHandler: TypeAlias = Callable[[Optional['Context']], Awaitable[Optional[RouteResult]]]
AfterRequestHandler: TypeAlias = Callable[['Response'], Awaitable['Response']]
ResponseNext: TypeAlias = Callable[[], Awaitable['Response']]
ResponseMiddleware: TypeAlias = Callable[['Context', ResponseNext], Awaitable['Response']]
TeardownHandler: TypeAlias = Callable[['Context', Optional[BaseException]], Awaitable[None]]
LifespanHandler: TypeAlias = Callable[..., Awaitable[None]]
RequestMethod: TypeAlias = Literal['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'CONNECT', 'OPTIONS', 'TRACE', 'PATCH']
RequestMethods: TypeAlias = list[RequestMethod]
RouteParam: TypeAlias = Any
RouteParams: TypeAlias = dict[str, RouteParam]
ByteStream: TypeAlias = Union[AsyncIterator[bytes], Iterator[bytes]]
ResponseBodyKind: TypeAlias = Literal['body', 'stream']
FormPayload: TypeAlias = dict[str, list[str]]
JSONPayload: TypeAlias = Union[dict[str, 'JSONPayload'], list['JSONPayload'], str, int, float, bool, None]
RequestPayload: TypeAlias = Union[FormPayload, JSONPayload, bytes]
JSONLoads: TypeAlias = Callable[[Any], Any]
JSONDumps: TypeAlias = Callable[[Any], Union[str, bytes]]
LoggerLike: TypeAlias = Logger
RouteParser: TypeAlias = Callable[[str], RouteParam]
RouteFormatter: TypeAlias = Callable[[RouteParam], str]
ContentTypeMatcher: TypeAlias = Union[str, Callable[[str], bool]]
RequestPayloadParser: TypeAlias = Callable[['Request'], RequestPayload]
ResponseCoercer: TypeAlias = Callable[[Any], Optional['Response']]
SameSite: TypeAlias = Union['KnownSameSite', str]

_T = TypeVar('_T')
#endregion

#region Enums
class KnownHeader(StrEnum):
    CACHE_CONTROL = 'cache-control'
    CONNECTION = 'connection'
    KEEP_ALIVE = 'keep-alive'
    DATE = 'date'
    PRAGMA = 'pragma'
    TRAILER = 'trailer'
    TRANSFER_ENCODING = 'transfer-encoding'
    UPGRADE = 'upgrade'
    VIA = 'via'
    WARNING = 'warning'

    ACCEPT = 'accept'
    ACCEPT_CHARSET = 'accept-charset'
    ACCEPT_ENCODING = 'accept-encoding'
    ACCEPT_LANGUAGE = 'accept-language'
    ACCEPT_RANGES = 'accept-ranges'
    USER_AGENT = 'user-agent'

    HOST = 'host'
    REFERER = 'referer'
    ORIGIN = 'origin'

    AUTHORIZATION = 'authorization'
    PROXY_AUTHORIZATION = 'proxy-authorization'
    COOKIE = 'cookie'

    CONTENT_TYPE = 'content-type'
    CONTENT_LENGTH = 'content-length'

    IF_MATCH = 'if-match'
    IF_NONE_MATCH = 'if-none-match'
    IF_MODIFIED_SINCE = 'if-modified-since'
    IF_UNMODIFIED_SINCE = 'if-unmodified-since'
    IF_RANGE = 'if-range'

    RANGE = 'range'

    SERVER = 'server'
    ALLOW = 'allow'
    LOCATION = 'location'
    RETRY_AFTER = 'retry-after'

    CONTENT_ENCODING = 'content-encoding'
    CONTENT_DISPOSITION = 'content-disposition'
    CONTENT_LANGUAGE = 'content-language'
    CONTENT_LOCATION = 'content-location'
    CONTENT_RANGE = 'content-range'
    LAST_MODIFIED = 'last-modified'
    ETAG = 'etag'

    SET_COOKIE = 'set-cookie'
    WWW_AUTHENTICATE = 'www-authenticate'
    PROXY_AUTHENTICATE = 'proxy-authenticate'

    EXPIRES = 'expires'
    AGE = 'age'
    VARY = 'vary'
    LINK = 'link'

    ACCESS_CONTROL_ALLOW_ORIGIN = 'access-control-allow-origin'
    ACCESS_CONTROL_ALLOW_METHODS = 'access-control-allow-methods'
    ACCESS_CONTROL_ALLOW_HEADERS = 'access-control-allow-headers'
    ACCESS_CONTROL_ALLOW_CREDENTIALS = 'access-control-allow-credentials'
    ACCESS_CONTROL_EXPOSE_HEADERS = 'access-control-expose-headers'
    ACCESS_CONTROL_MAX_AGE = 'access-control-max-age'
    ACCESS_CONTROL_REQUEST_METHOD = 'access-control-request-method'
    ACCESS_CONTROL_REQUEST_HEADERS = 'access-control-request-headers'

    CONTENT_SECURITY_POLICY = 'content-security-policy'
    STRICT_TRANSPORT_SECURITY = 'strict-transport-security'
    X_CONTENT_TYPE_OPTIONS = 'x-content-type-options'
    X_FRAME_OPTIONS = 'x-frame-options'
    X_XSS_PROTECTION = 'x-xss-protection'
    REFERRER_POLICY = 'referrer-policy'
    PERMISSIONS_POLICY = 'permissions-policy'
    CROSS_ORIGIN_EMBEDDER_POLICY = 'cross-origin-embedder-policy'
    CROSS_ORIGIN_OPENER_POLICY = 'cross-origin-opener-policy'
    CROSS_ORIGIN_RESOURCE_POLICY = 'cross-origin-resource-policy'
    CLEAR_SITE_DATA = 'clear-site-data'

    X_FORWARDED_FOR = 'x-forwarded-for'
    X_FORWARDED_PROTO = 'x-forwarded-proto'
    X_FORWARDED_HOST = 'x-forwarded-host'
    X_FORWARDED_PORT = 'x-forwarded-port'
    X_FORWARDED_PREFIX = 'x-forwarded-prefix'
    FORWARDED = 'forwarded'

    SEC_FETCH_DEST = 'sec-fetch-dest'
    SEC_FETCH_MODE = 'sec-fetch-mode'
    SEC_FETCH_SITE = 'sec-fetch-site'
    SEC_FETCH_USER = 'sec-fetch-user'

    X_REQUEST_ID = 'x-request-id'
    X_REAL_IP = 'x-real-ip'
    X_POWERED_BY = 'x-powered-by'
    X_DNS_PREFETCH_CONTROL = 'x-dns-prefetch-control'
    X_PERMITTED_CROSS_DOMAIN_POLICIES = 'x-permitted-cross-domain-policies'
    DNT = 'dnt'
    TE = 'te'

class KnownContentType(StrEnum):
    JSON = 'application/json'
    HTML = 'text/html'
    PLAIN_TEXT = 'text/plain'
    FORM_URLENCODED = 'application/x-www-form-urlencoded'
    FORM_MULTIPART = 'multipart/form-data'
    OCTET_STREAM = 'application/octet-stream'
    JAVASCRIPT = 'application/javascript'
    XML = 'application/xml'

class KnownSameSite(StrEnum):
    LAX = 'Lax'
    STRICT = 'Strict'
    NONE = 'None'

class KnownCacheDirective(StrEnum):
    NO_CACHE = 'no-cache'
    NO_STORE = 'no-store'
    PUBLIC = 'public'
    PRIVATE = 'private'
    MUST_REVALIDATE = 'must-revalidate'
    PROXY_REVALIDATE = 'proxy-revalidate'
    MAX_AGE = 'max-age'
    S_MAXAGE = 's-maxage'
    IMMUTABLE = 'immutable'
    STALE_WHILE_REVALIDATE = 'stale-while-revalidate'
    STALE_IF_ERROR = 'stale-if-error'
#endregion

def _sanitize_header_value(value: str) -> str:
    return value.replace('\r', '').replace('\n', '')

def _encode_cookie_value(value: str) -> str:
    # Preserve existing percent-encoded sequences while preventing delimiter injection.
    return quote(value, safe="!#$%&'()*+-./:<=>?@[]^_`{|}~%")

def _append_set_cookie_header(headers: Headers, cookie: str) -> None:
    cookie = _sanitize_header_value(cookie)
    existing = headers.get(KnownHeader.SET_COOKIE.value)
    if existing is None:
        headers[KnownHeader.SET_COOKIE] = [cookie]
    else:
        if isinstance(existing, list):
            existing.append(cookie)
        else:
            headers[KnownHeader.SET_COOKIE] = [_sanitize_header_value(str(existing)), cookie]

def _normalize_headers(
    headers: Headers,
    *,
    sanitize_values: bool = False,
) -> Headers:
    normalized: Headers = {}
    for raw_key, raw_value in headers.items():
        key = str(raw_key).lower()
        values = raw_value if isinstance(raw_value, list) else [raw_value]
        for value in values:
            value_str = str(value)
            safe_value = _sanitize_header_value(value_str) if sanitize_values else value_str
            _append_request_header(normalized, key, safe_value)

    return normalized

def _encode_headers_for_asgi(headers: Headers) -> list[list[bytes]]:
    encoded: list[list[bytes]] = []
    for key, value in headers.items():
        key_str = str(key)
        values = value if isinstance(value, list) else [value]
        for header_value in values:
            safe_value = _sanitize_header_value(str(header_value))
            encoded.append([key_str.encode('utf-8'), safe_value.encode('utf-8')])

    return encoded

def _append_request_header(headers: Headers, name: str, value: str) -> None:
    key = str(name).lower()
    existing = headers.get(key)
    if existing is None:
        headers[key] = value
    elif isinstance(existing, list):
        existing.append(value)
    else:
        headers[key] = [existing, value]

def _max_content_length(headers: Headers) -> Optional[int]:
    raw_value = headers.get(KnownHeader.CONTENT_LENGTH)
    if raw_value is None:
        return None

    values = raw_value if isinstance(raw_value, list) else [raw_value]
    parsed_values: list[int] = []
    for value in values:
        try:
            parsed_values.append(int(str(value)))
        except ValueError:
            continue

    if not parsed_values:
        return None

    return max(parsed_values)

@dataclass(frozen=True)
class RouteConverter:
    regex: str
    parse: RouteParser = str
    format: RouteFormatter = str
    allows_slash: bool = False

def _default_route_converters() -> dict[str, RouteConverter]:
    return {
        'int': RouteConverter(regex=r'\d+', parse=int, format=lambda value: str(int(value))),
        'float': RouteConverter(regex=r'\d+\.?\d*', parse=float, format=lambda value: str(float(value))),
        'path': RouteConverter(regex=r'.+', parse=str, format=str, allows_slash=True),
    }

class Blueprint:
    def __init__(self, name: str, *, url_prefix: Optional[str] = None, strict_slashes: Optional[bool] = None):
        self.name = name
        self.url_prefix = url_prefix or ''
        self.strict_slashes = strict_slashes
        self._route_converters: dict[str, RouteConverter] = _default_route_converters()
        self.routes: list[Route] = []
        self.before_request_handlers: list[BeforeRequestHandler] = []
        self.after_request_handlers: list[AfterRequestHandler] = []
        self.error_handlers: dict[type, ErrorHandler] = {}

    def register_converter(
        self,
        name: str,
        *,
        regex: str,
        parse: RouteParser = str,
        format: RouteFormatter = str,
        allows_slash: bool = False,
    ) -> None:
        if not name:
            raise ValueError('converter name cannot be empty.')
        if not regex:
            raise ValueError('converter regex cannot be empty.')
        if not callable(parse):
            raise TypeError('converter parse must be callable.')
        if not callable(format):
            raise TypeError('converter format must be callable.')

        self._route_converters[name] = RouteConverter(
            regex=regex,
            parse=parse,
            format=format,
            allows_slash=allows_slash,
        )

    def _route_pattern(self, pattern: str) -> 'RoutePattern':
        return RoutePattern(pattern, converters=self._route_converters)

    def route(
        self,
        pattern: str,
        *,
        methods: Optional[RequestMethods] = None,
        endpoint: Optional[str] = None,
        strict_slashes: Optional[bool] = None,
    ) -> Callable[[RouteHandler], RouteHandler]:
        if methods is None:
            methods = ['GET']

        def decorator(func: RouteHandler) -> RouteHandler:
            route_endpoint = endpoint or f'{self.name}.{func.__name__}'
            full_pattern = self.url_prefix + pattern

            route = Route(
                pattern=self._route_pattern(full_pattern),
                handler=func,
                methods=methods,
                endpoint=route_endpoint,
                strict_slashes=strict_slashes,
                blueprint=self.name,
            )

            self.routes.append(route)

            return func
        return decorator

    def get(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['GET'], endpoint=endpoint, strict_slashes=strict_slashes)

    def head(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['HEAD'], endpoint=endpoint, strict_slashes=strict_slashes)

    def post(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['POST'], endpoint=endpoint, strict_slashes=strict_slashes)

    def put(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['PUT'], endpoint=endpoint, strict_slashes=strict_slashes)

    def delete(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['DELETE'], endpoint=endpoint, strict_slashes=strict_slashes)

    def connect(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['CONNECT'], endpoint=endpoint, strict_slashes=strict_slashes)

    def options(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['OPTIONS'], endpoint=endpoint, strict_slashes=strict_slashes)

    def trace(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['TRACE'], endpoint=endpoint, strict_slashes=strict_slashes)

    def patch(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['PATCH'], endpoint=endpoint, strict_slashes=strict_slashes)

    def before_request(self, func: BeforeRequestHandler) -> BeforeRequestHandler:
        self.before_request_handlers.append(func)
        return func

    def after_request(self, func: AfterRequestHandler) -> AfterRequestHandler:
        self.after_request_handlers.append(func)
        return func

    def error_handler(self, exception: type) -> Callable[[ErrorHandler], ErrorHandler]:
        def decorator(func: ErrorHandler) -> ErrorHandler:
            self.error_handlers[exception] = func
            return func
        return decorator

    def register_blueprint(self, blueprint: 'Blueprint') -> None:
        for route in blueprint.routes:
            full_pattern = self.url_prefix + route.pattern.pattern
            endpoint = (
                route.endpoint
                if route.endpoint.startswith(f'{self.name}.')
                else f'{self.name}.{route.endpoint}'
            )
            use_strict = (
                route.strict_slashes
                if route.strict_slashes is not None
                else blueprint.strict_slashes
                if blueprint.strict_slashes is not None
                else self.strict_slashes
            )
            nested_route = Route(
                pattern=RoutePattern(full_pattern, converters=route.pattern.converters),
                handler=route.handler,
                methods=route.methods,
                endpoint=endpoint,
                decorators=route.decorators,
                strict_slashes=use_strict,
                blueprint=self.name,
            )
            self.routes.append(nested_route)

        self.before_request_handlers.extend(blueprint.before_request_handlers)
        self.after_request_handlers.extend(blueprint.after_request_handlers)
        self.error_handlers.update(blueprint.error_handlers)
#endregion

#region Routing
@dataclass
class Route:
    pattern: RoutePattern
    handler: RouteHandler
    methods: RequestMethods
    endpoint: str
    decorators: list[Decorator] = field(default_factory=list)
    strict_slashes: Optional[bool] = None
    blueprint: Optional[str] = None
    _resolved_handler: Optional[RouteHandler] = field(default=None, init=False, repr=False)
    _resolved_handler_accepts_ctx: Optional[bool] = field(default=None, init=False, repr=False)
    _resolved_handler_decorator_count: int = field(default=-1, init=False, repr=False)

class RoutePattern:
    def __init__(
        self,
        pattern: str,
        *,
        converters: Optional[dict[str, RouteConverter]] = None,
    ):
        self.pattern = pattern
        self.converters = dict(converters or _default_route_converters())
        self.param_names: list[str] = []
        self.param_types: list[Optional[str]] = []
        self.param_group_names: list[str] = []
        self.param_converters: list[Optional[RouteConverter]] = []
        self.segments: tuple[str, ...] = tuple()
        self.segment_count: int = 0
        self.first_segment_literal: Optional[str] = None
        self.is_static = True
        self.fixed_segment_count: Optional[int] = 0
        self.static_segment_count: int = 0
        self.typed_dynamic_segment_count: int = 0
        self.plain_dynamic_segment_count: int = 0
        self.path_converter_count: int = 0
        self.specificity: tuple[int, int, int, int, int, int] = (0, 0, 0, 0, 0, 0)
        self._analyze_segments(pattern)
        self.regex = self._compile_pattern(pattern)

    def _analyze_segments(self, pattern: str) -> None:
        normalized = pattern.strip('/')
        if not normalized:
            segments: tuple[str, ...] = tuple()
        else:
            segments = tuple(normalized.split('/'))

        self.segments = segments
        self.segment_count = len(segments)
        self.first_segment_literal = None
        self.is_static = True
        has_path_converter = False
        self.static_segment_count = 0
        self.typed_dynamic_segment_count = 0
        self.plain_dynamic_segment_count = 0
        self.path_converter_count = 0

        for i, segment in enumerate(segments):
            if segment.startswith('<') and segment.endswith('>'):
                self.is_static = False
                inner = segment[1:-1]
                converter = inner.split(':', 1)[0] if ':' in inner else None
                converter_config = self.converters.get(converter) if converter else None
                if converter_config is not None and converter_config.allows_slash:
                    has_path_converter = True
                    self.path_converter_count += 1
                elif converter_config is not None:
                    self.typed_dynamic_segment_count += 1
                else:
                    self.plain_dynamic_segment_count += 1
            elif i == 0:
                self.first_segment_literal = segment
                self.static_segment_count += 1
            else:
                self.static_segment_count += 1

        if has_path_converter:
            self.fixed_segment_count = None
        else:
            self.fixed_segment_count = len(segments)

        self.specificity = (
            1 if self.is_static else 0,
            self.static_segment_count,
            self.typed_dynamic_segment_count,
            self.plain_dynamic_segment_count,
            -self.path_converter_count,
            self.segment_count,
        )

    def _compile_pattern(self, pattern: str) -> Pattern:
        param_pattern = r'<(?:(\w+):)?(\w+)>'

        def replacer(match: Match) -> str:
            type_name = match.group(1)
            param_name = match.group(2)
            converter = self.converters.get(type_name) if type_name else None
            self.param_names.append(param_name)
            self.param_types.append(type_name)
            self.param_converters.append(converter)
            group_name = f'_p{len(self.param_group_names)}'
            self.param_group_names.append(group_name)

            converter_regex = converter.regex if converter is not None else r'[^/]+'
            return f'(?P<{group_name}>{converter_regex})'

        regex_parts: list[str] = []
        last_end = 0
        for match in finditer(param_pattern, pattern):
            static_part = pattern[last_end:match.start()]
            regex_parts.append(regex_escape(static_part))
            regex_parts.append(replacer(match))
            last_end = match.end()
        regex_parts.append(regex_escape(pattern[last_end:]))
        regex_pattern = ''.join(regex_parts)
        regex_pattern = f'^{regex_pattern}$'

        return compile(regex_pattern)

    def match(self, path: str) -> Optional[RouteParams]:
        match = self.regex.match(path)
        if not match:
            return None

        params: RouteParams = {}
        for name, group_name, converter in zip(
            self.param_names,
            self.param_group_names,
            self.param_converters,
        ):
            value = match.group(group_name)
            value = unquote(value)

            if converter is not None:
                try:
                    value = converter.parse(value)
                except Exception:
                    return None

            params[name] = value

        return params
#endregion

#region Request/Response

@dataclass
class Request:
    method: str
    path: str
    query_string: str
    headers: Headers
    body: bytes = b''
    json_loads: JSONLoads = field(default=default_json_loads, repr=False)
    body_receive: Optional[Callable[[], Awaitable[dict[str, Any]]]] = field(default=None, repr=False)
    max_body_size: Optional[int] = field(default=None, repr=False)
    payload_parser: Optional[RequestPayloadParser] = field(default=None, repr=False)
    route_params: RouteParams = field(default_factory=dict)
    _query: Optional[dict[str, list[str]]] = field(default=None, init=False)
    _json: Optional[Any] = field(default=None, init=False)
    _json_loaded: bool = field(default=False, init=False)
    _json_valid: bool = field(default=True, init=False)
    _form: Optional[dict[str, list[str]]] = field(default=None, init=False)
    _cookies: Optional[dict[str, str]] = field(default=None, init=False)
    _body_fully_read: bool = field(default=True, init=False)
    _body_read_size: int = field(default=0, init=False)
    _client_disconnected: bool = field(default=False, init=False)

    def __post_init__(self) -> None:
        self.headers = _normalize_headers(self.headers, sanitize_values=False)
        self._body_fully_read = self.body_receive is None
        self._body_read_size = len(self.body)

    async def _read_next_body_chunk(self, *, enforce_limit: bool) -> Optional[bytes]:
        while not self._body_fully_read:
            if self.body_receive is None:
                self._body_fully_read = True
                return None

            message = await self.body_receive()
            message_type = message.get('type')
            if message_type == 'http.disconnect':
                self._body_fully_read = True
                self._client_disconnected = True
                return None
            if message_type != 'http.request':
                continue

            chunk = message.get('body', b'')
            if not message.get('more_body', False):
                self._body_fully_read = True

            self._body_read_size += len(chunk)
            if (
                enforce_limit
                and self.max_body_size is not None
                and self._body_read_size > self.max_body_size
            ):
                raise HTTPException(
                    413,
                    'Request body exceeds configured maximum size.',
                )

            if chunk:
                return chunk

        return None

    async def read(self) -> bytes:
        if self._body_fully_read:
            return self.body

        chunks = [self.body] if self.body else []
        while True:
            chunk = await self._read_next_body_chunk(enforce_limit=True)
            if chunk is None:
                break
            chunks.append(chunk)

        self.body = b''.join(chunks)
        return self.body

    async def iter_body(self, *, cache: bool = False) -> AsyncIterator[bytes]:
        cached_chunks: Optional[list[bytes]] = [] if cache else None
        if self.body:
            yield self.body
            if cached_chunks is not None:
                cached_chunks.append(self.body)

        while True:
            chunk = await self._read_next_body_chunk(enforce_limit=True)
            if chunk is None:
                if cached_chunks is not None:
                    self.body = b''.join(cached_chunks)
                return
            if cached_chunks is not None:
                cached_chunks.append(chunk)
            yield chunk

    async def drain_unread_body(self) -> bool:
        if self._body_fully_read:
            return False

        over_limit = False
        while not self._body_fully_read:
            chunk = await self._read_next_body_chunk(enforce_limit=False)
            if (
                not over_limit
                and self.max_body_size is not None
                and self._body_read_size > self.max_body_size
            ):
                over_limit = True
            if chunk is None:
                continue

        return over_limit

    @property
    def client_disconnected(self) -> bool:
        return self._client_disconnected

    @property
    def query(self) -> dict[str, list[str]]:
        if self._query is None:
            self._query = parse_qs(self.query_string)

        return self._query

    @property
    def json(self) -> JSONPayload:
        if not self._body_fully_read:
            raise RuntimeError('Request body is streamed. Use `await request.json_async()`.')
        if not self._json_loaded:
            try:
                self._json = self.json_loads(self.body)
                self._json_valid = True
            except Exception:
                self._json = None
                self._json_valid = False
            self._json_loaded = True

        return self._json

    @property
    def is_json_valid(self) -> bool:
        if not self._body_fully_read:
            raise RuntimeError('Request body is streamed. Use `await request.is_json_valid_async()`.')
        _ = self.json
        return self._json_valid

    @property
    def form(self) -> FormPayload:
        if not self._body_fully_read:
            raise RuntimeError('Request body is streamed. Use `await request.form_async()`.')
        if self._form is None:
            content_type = (self.get_header(KnownHeader.CONTENT_TYPE, '') or '').lower()
            if KnownContentType.FORM_URLENCODED in content_type:
                try:
                    self._form = parse_qs(self.body.decode('utf-8'))
                except UnicodeDecodeError:
                    self._form = {}
            else:
                self._form = {}

        return self._form

    @property
    def cookies(self) -> dict[str, str]:
        if self._cookies is None:
            cookies: dict[str, str] = {}
            cookie_header = self.get_header(KnownHeader.COOKIE, '')
            if cookie_header:
                for chunk in cookie_header.split(';'):
                    if '=' not in chunk:
                        continue
                    name, value = chunk.split('=', 1)
                    cookies[name.strip()] = unquote(value.strip())
            self._cookies = cookies

        return self._cookies

    @property
    def payload(self) -> RequestPayload:
        if not self._body_fully_read:
            raise RuntimeError('Request body is streamed. Use `await request.payload_async()`.')
        if self.payload_parser is not None:
            return self.payload_parser(self)
        content_type = (self.get_header(KnownHeader.CONTENT_TYPE, '') or '').lower()
        if KnownContentType.JSON in content_type:
            return self.json
        if KnownContentType.FORM_URLENCODED in content_type:
            return self.form
        return self.body

    async def json_async(self) -> JSONPayload:
        await self.read()
        return self.json

    async def is_json_valid_async(self) -> bool:
        _ = await self.json_async()
        return self._json_valid

    async def form_async(self) -> FormPayload:
        await self.read()
        return self.form

    async def payload_async(self) -> RequestPayload:
        await self.read()
        return self.payload

    def get_header(self, name: Header, default: Optional[str] = None) -> Optional[str]:
        value = self.headers.get(str(name).lower())
        if value is None:
            return default
        if isinstance(value, list):
            if str(name).lower() == KnownHeader.COOKIE.value:
                return '; '.join(value)
            return ', '.join(value)
        return value

    @overload
    def route_param(self, name: str) -> RouteParam:
        ...

    @overload
    def route_param(self, name: str, *, as_type: type[_T]) -> _T:
        ...

    def route_param(self, name: str, *, as_type: Optional[type[Any]] = None) -> Any:
        value = self.route_params[name]
        if as_type is None or isinstance(value, as_type):
            return value

        return as_type(value)


class Response:
    def __init__(
        self,
        body: Union[str, bytes] = '',
        status: int = 200,
        headers: Optional[Headers] = None,
        *,
        stream: Optional[ByteStream] = None,
    ):
        self.status = status
        self.body: Union[str, bytes] = body
        self.stream: Optional[ByteStream] = None
        self._body_kind: ResponseBodyKind = 'body'
        self.headers: Headers = _normalize_headers(dict(headers or {}), sanitize_values=True)

        if stream is not None:
            self._body_kind = 'stream'
            self.stream = stream
            self.body = b''
            self._set_default_header(KnownHeader.CONTENT_TYPE, KnownContentType.OCTET_STREAM)
        elif self._find_header_key(KnownHeader.CONTENT_TYPE) is None:
            if isinstance(self.body, str):
                self.headers[KnownHeader.CONTENT_TYPE] = f'{KnownContentType.HTML}; charset=utf-8'
            else:
                self.headers[KnownHeader.CONTENT_TYPE] = KnownContentType.OCTET_STREAM

    @classmethod
    def stream(
        cls,
        stream: ByteStream,
        status: int = 200,
        headers: Optional[Headers] = None,
    ) -> Self:
        return cls(status=status, headers=headers, stream=stream)

    @property
    def is_stream(self) -> bool:
        return self._body_kind != 'body'

    @property
    def is_buffered(self) -> bool:
        return self._body_kind == 'body'

    def _find_header_key(self, name: Header) -> Optional[Header]:
        target = str(name).lower()
        if target in self.headers:
            return target
        return None

    def _set_default_header(self, name: Header, value: str) -> None:
        key = str(name).lower()
        if key not in self.headers:
            self.headers[key] = value

    def set_header(self, name: Header, value: str) -> Self:
        self.headers[str(name).lower()] = _sanitize_header_value(value)
        return self

    def set_cookie(
        self,
        name: str,
        value: str,
        max_age: Optional[int] = None,
        path: str = '/',
        domain: Optional[str] = None,
        secure: bool = False,
        httponly: bool = False,
        samesite: Optional[SameSite] = None,
    ) -> Self:
        cookie = f'{name}={_encode_cookie_value(value)}'
        if max_age is not None:
            cookie += f';Max-Age={max_age}'
        cookie += f';Path={path}'
        if domain:
            cookie += f';Domain={domain}'
        if secure:
            cookie += ';Secure'
        if httponly:
            cookie += ';HttpOnly'
        if samesite:
            cookie += f';SameSite={samesite}'

        _append_set_cookie_header(self.headers, cookie)

        return self

    async def iter_chunks(self) -> AsyncIterator[bytes]:
        if self._body_kind == 'body':
            body_bytes = self.body.encode('utf-8') if isinstance(self.body, str) else self.body
            if body_bytes:
                yield body_bytes
            return

        if self.stream is None:
            return

        if hasattr(self.stream, '__aiter__'):
            async for item in self.stream:  # type: ignore[misc]
                yield item.encode('utf-8') if isinstance(item, str) else item
        else:
            for item in self.stream:  # type: ignore[union-attr]
                yield item.encode('utf-8') if isinstance(item, str) else item

class StreamResponse(Response):
    def __init__(
        self,
        stream: ByteStream,
        status: int = 200,
        headers: Optional[Headers] = None,
    ):
        super().__init__(status=status, headers=headers, stream=stream)

@dataclass
class _SessionRecord:
    data: dict[str, Any]
    expires_at: Optional[float]
    last_access: float

class SessionEngine(Protocol):
    async def load(self, session_id: str) -> Optional[dict[str, Any]]:
        ...

    async def create(self) -> tuple[str, dict[str, Any]]:
        ...

    async def save(self, session_id: str, data: dict[str, Any]) -> None:
        ...

    async def destroy(self, session_id: str) -> None:
        ...

class InMemorySessionEngine:
    def __init__(
        self,
        *,
        ttl: Optional[int] = None,
        purge_interval: int = 60,
        max_entries: Optional[int] = 10_000,
    ):
        if ttl is not None and ttl <= 0:
            raise ValueError('ttl must be > 0 or None.')
        if purge_interval < 0:
            raise ValueError('purge_interval must be >= 0.')
        if max_entries is not None and max_entries <= 0:
            raise ValueError('max_entries must be > 0 or None.')

        self.ttl = ttl
        self.purge_interval = purge_interval
        self.max_entries = max_entries
        self._sessions: dict[str, _SessionRecord] = {}
        self._last_session_purge = 0.0

    def _generate_session_id(self) -> str:
        while True:
            session_id = token_urlsafe(32)
            if session_id not in self._sessions:
                return session_id

    def _is_expired(self, record: _SessionRecord, now: float) -> bool:
        return record.expires_at is not None and record.expires_at <= now

    def _touch(self, record: _SessionRecord, now: float) -> None:
        record.last_access = now
        if self.ttl is not None:
            record.expires_at = now + self.ttl

    def _purge_expired_sessions(self, now: float) -> None:
        if self.ttl is None:
            return
        if self.purge_interval > 0 and now - self._last_session_purge < self.purge_interval:
            return

        expired_ids = [
            session_id
            for session_id, record in self._sessions.items()
            if self._is_expired(record, now)
        ]
        for session_id in expired_ids:
            del self._sessions[session_id]

        self._last_session_purge = now

    def _enforce_capacity(self) -> None:
        if self.max_entries is None or len(self._sessions) <= self.max_entries:
            return

        overflow = len(self._sessions) - self.max_entries
        evict_ids = sorted(
            self._sessions.items(),
            key=lambda item: item[1].last_access,
        )[:overflow]
        for session_id, _ in evict_ids:
            self._sessions.pop(session_id, None)

    async def load(self, session_id: str) -> Optional[dict[str, Any]]:
        now = time()
        self._purge_expired_sessions(now)

        record = self._sessions.get(session_id)
        if record is None:
            return None
        if self._is_expired(record, now):
            self._sessions.pop(session_id, None)
            return None

        self._touch(record, now)
        return dict(record.data)

    async def create(self) -> tuple[str, dict[str, Any]]:
        now = time()
        self._purge_expired_sessions(now)

        session_id = self._generate_session_id()
        return session_id, {}

    async def save(self, session_id: str, data: dict[str, Any]) -> None:
        now = time()
        self._purge_expired_sessions(now)

        record = self._sessions.get(session_id)
        if record is None:
            record = _SessionRecord(data={}, expires_at=None, last_access=now)
            self._sessions[session_id] = record

        record.data = dict(data)
        self._touch(record, now)
        self._enforce_capacity()

    async def destroy(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)

class Session:
    def __init__(
        self,
        session_id: str,
        data: dict[str, Any],
        *,
        new: bool = False,
    ):
        self.id = session_id
        self.data = data
        self.new = new
        self.destroyed = False
        self.modified = False

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self.data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.data[key] = value
        self.modified = True

    def __delitem__(self, key: str) -> None:
        del self.data[key]
        self.modified = True

    def __contains__(self, key: str) -> bool:
        return key in self.data

    def __iter__(self) -> Iterator[str]:
        return iter(self.data)

    def __len__(self) -> int:
        return len(self.data)

    def items(self):
        return self.data.items()

    def clear(self) -> None:
        self.data.clear()
        self.modified = True

    def destroy(self) -> None:
        if self.destroyed:
            return
        self.destroyed = True
        self.modified = True
        self.data.clear()


@dataclass
class Context:
    request: Request
    app: 'Ryuuseigun'
    g: dict[str, Any] = field(default_factory=dict)
    _after_request_callbacks: list[AfterRequestHandler] = field(default_factory=list, init=False)
    _session: Optional[Session] = field(default=None, init=False)

    def url_for(self, endpoint: str, *, full_url: bool = False, **params: Any) -> str:
        if full_url and not self.app.base_url:
            relative_url = self.app.url_for(endpoint, full_url=False, **params)
            return self.app._build_full_url_from_request(relative_url, self.request)

        return self.app.url_for(endpoint, full_url=full_url, **params)

    def after_this_request(self, func: AfterRequestHandler) -> AfterRequestHandler:
        self._after_request_callbacks.append(func)
        return func

    @property
    def session(self) -> Session:
        if self._session is None:
            raise RuntimeError(
                'Sessions are async-only. Use `await ctx.session_async()`.',
            )
        return self._session

    async def session_async(self) -> Session:
        if self._session is None:
            self._session = await self.app._get_or_create_session(self.request)
        return self._session
#endregion


class Ryuuseigun:
    def __init__(
        self,
        name: str,
        base_url: str = '',
        *,
        strict_slashes: bool = True,
        public_dir: Optional[str] = None,
        session_cookie_name: str = 'session',
        session_cookie_path: str = '/',
        session_cookie_secure: bool = False,
        session_cookie_httponly: bool = True,
        session_cookie_samesite: Optional[SameSite] = KnownSameSite.LAX,
        session_ttl: Optional[int] = None,
        session_purge_interval: int = 60,
        session_max_entries: Optional[int] = 10_000,
        session_engine: Optional[SessionEngine] = None,
        max_request_body_size: Optional[int] = 16 * 1024 * 1024,
        loads: JSONLoads = default_json_loads,
        dumps: JSONDumps = default_json_dumps,
        logger: Optional[LoggerLike] = None,
    ):
        if session_ttl is not None and session_ttl <= 0:
            raise ValueError('session_ttl must be > 0 or None.')
        if session_purge_interval < 0:
            raise ValueError('session_purge_interval must be >= 0.')
        if session_max_entries is not None and session_max_entries <= 0:
            raise ValueError('session_max_entries must be > 0 or None.')
        if max_request_body_size is not None and max_request_body_size <= 0:
            raise ValueError('max_request_body_size must be > 0 or None.')
        if not callable(loads):
            raise TypeError('loads must be callable.')
        if not callable(dumps):
            raise TypeError('dumps must be callable.')
        if logger is not None and not isinstance(logger, Logger):
            raise TypeError('logger must be a logging.Logger instance or None.')

        self.name = name
        self.base_url = base_url
        self.strict_slashes = strict_slashes
        self.public_dir = public_dir
        self.session_cookie_name = session_cookie_name
        self.session_cookie_path = session_cookie_path
        self.session_cookie_secure = session_cookie_secure
        self.session_cookie_httponly = session_cookie_httponly
        self.session_cookie_samesite = session_cookie_samesite
        self.session_ttl = session_ttl
        self.session_purge_interval = session_purge_interval
        self.session_max_entries = session_max_entries
        self.max_request_body_size = max_request_body_size
        self.loads = loads
        self.dumps = dumps
        self.logger = logger if logger is not None else getLogger(__name__)
        self._route_converters: dict[str, RouteConverter] = _default_route_converters()
        self._request_payload_parsers: list[tuple[Callable[[str], bool], RequestPayloadParser]] = []
        self._response_coercers: list[ResponseCoercer] = []
        self._install_default_request_payload_parsers()
        self._install_default_response_coercers()

        if session_engine is None:
            self.session_engine: SessionEngine = InMemorySessionEngine(
                ttl=session_ttl,
                purge_interval=session_purge_interval,
                max_entries=session_max_entries,
            )
        else:
            missing_methods = [
                method_name
                for method_name in ('load', 'create', 'save', 'destroy')
                if not callable(getattr(session_engine, method_name, None))
            ]
            if missing_methods:
                missing = ', '.join(missing_methods)
                raise TypeError(
                    f'session_engine is missing required callable methods: {missing}.',
                )
            self.session_engine = session_engine
        non_async_methods = [
            method_name
            for method_name in ('load', 'create', 'save', 'destroy')
            if not iscoroutinefunction(getattr(self.session_engine, method_name, None))
        ]
        if non_async_methods:
            methods = ', '.join(non_async_methods)
            raise TypeError(
                f'session_engine methods must be async: {methods}.',
            )

        self.routes: list[Route] = []
        self.blueprints: list[Blueprint] = []
        self.before_request_handlers: list[BeforeRequestHandler] = []
        self.after_request_handlers: list[AfterRequestHandler] = []
        self.teardown_handlers: list[TeardownHandler] = []
        self.startup_handlers: list[LifespanHandler] = []
        self.shutdown_handlers: list[LifespanHandler] = []
        self.error_handlers: dict[type, ErrorHandler] = {}
        self._blueprint_before_request_handlers: dict[str, list[BeforeRequestHandler]] = {}
        self._blueprint_after_request_handlers: dict[str, list[AfterRequestHandler]] = {}
        self._blueprint_error_handlers: dict[str, dict[type, ErrorHandler]] = {}
        self._endpoint_map: dict[str, Route] = {}
        self._handler_accepts_ctx_cache: dict[Callable[..., Any], bool] = {}
        self._route_resolution_cache: dict[
            tuple[str, str],
            tuple[Optional[Route], Optional[tuple[tuple[str, RouteParam], ...]], tuple[str, ...]],
        ] = {}
        self._route_cache_max_size = 4096
        self._route_indexes_dirty = True
        self._http_routes_by_index: list[Route] = []
        self._http_exact_route_indices: dict[str, list[int]] = {}
        self._http_dynamic_route_indices: dict[Optional[str], list[int]] = {}

    def _cache_set(self, cache: dict[Any, Any], key: Any, value: Any, max_size: int) -> None:
        cache[key] = value
        if len(cache) > max_size:
            cache.pop(next(iter(cache)))

    def _invalidate_route_resolution_cache(self) -> None:
        self._route_resolution_cache.clear()
        self._route_indexes_dirty = True
        self._http_routes_by_index.clear()
        self._http_exact_route_indices.clear()
        self._http_dynamic_route_indices.clear()

    @staticmethod
    def _path_segment_info(path: str) -> tuple[Optional[str], int]:
        normalized = path.strip('/')
        if not normalized:
            return None, 0

        segments = normalized.split('/')
        return segments[0], len(segments)

    @staticmethod
    def _toggle_trailing_slash(path: str) -> str:
        if path == '/':
            return path
        if path.endswith('/'):
            normalized = path.rstrip('/')
            return normalized or '/'
        return f'{path}/'

    @staticmethod
    def _route_is_strict(route: Route, default_strict: bool) -> bool:
        if route.strict_slashes is None:
            return default_strict
        return route.strict_slashes

    def _route_sort_key(self, route_index: int) -> tuple[int, int, int, int, int, int, int]:
        route = self._http_routes_by_index[route_index]
        return (*route.pattern.specificity, -route_index)

    def _ensure_route_indexes(self) -> None:
        if not self._route_indexes_dirty:
            return

        self._http_routes_by_index = list(self.routes)
        self._http_exact_route_indices = {}
        self._http_dynamic_route_indices = {}
        for index, route in enumerate(self._http_routes_by_index):
            pattern = route.pattern
            if pattern.is_static:
                self._http_exact_route_indices.setdefault(pattern.pattern, []).append(index)
            else:
                bucket_key = pattern.first_segment_literal
                self._http_dynamic_route_indices.setdefault(bucket_key, []).append(index)

        self._route_indexes_dirty = False

    def _callable_accepts_ctx(self, func: Callable[..., Any]) -> bool:
        cached = self._handler_accepts_ctx_cache.get(func)
        if cached is not None:
            return cached

        accepts_ctx = bool(signature(func).parameters)
        self._handler_accepts_ctx_cache[func] = accepts_ctx

        return accepts_ctx

    def _resolve_route_handler(self, route: Route) -> tuple[RouteHandler, bool]:
        if (
            route._resolved_handler is None
            or route._resolved_handler_decorator_count != len(route.decorators)
        ):
            handler = route.handler
            for decorator in reversed(route.decorators):
                handler = decorator(handler)
            route._resolved_handler = handler
            route._resolved_handler_accepts_ctx = self._callable_accepts_ctx(handler)
            route._resolved_handler_decorator_count = len(route.decorators)

        return route._resolved_handler, bool(route._resolved_handler_accepts_ctx)

    def register_converter(
        self,
        name: str,
        *,
        regex: str,
        parse: RouteParser = str,
        format: RouteFormatter = str,
        allows_slash: bool = False,
    ) -> None:
        if not name:
            raise ValueError('converter name cannot be empty.')
        if not regex:
            raise ValueError('converter regex cannot be empty.')
        if not callable(parse):
            raise TypeError('converter parse must be callable.')
        if not callable(format):
            raise TypeError('converter format must be callable.')

        self._route_converters[name] = RouteConverter(
            regex=regex,
            parse=parse,
            format=format,
            allows_slash=allows_slash,
        )
        self._invalidate_route_resolution_cache()

    def _route_pattern(self, pattern: str) -> RoutePattern:
        return RoutePattern(pattern, converters=self._route_converters)

    def route(
            self,
            pattern: str,
            *,
            methods: Optional[RequestMethods] = None,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        if methods is None:
            methods = ['GET']

        def decorator(func: RouteHandler) -> RouteHandler:
            route_endpoint = endpoint or func.__name__
            use_strict = strict_slashes if strict_slashes is not None else self.strict_slashes
            route = Route(
                pattern=self._route_pattern(pattern),
                handler=func,
                methods=methods,
                endpoint=route_endpoint,
                strict_slashes=use_strict,
            )
            self.routes.append(route)
            self._endpoint_map[route_endpoint] = route
            self._invalidate_route_resolution_cache()
            return func
        return decorator

    #region HTTP method shortcuts
    def get(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['GET'], endpoint=endpoint, strict_slashes=strict_slashes)

    def head(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['HEAD'], endpoint=endpoint, strict_slashes=strict_slashes)

    def post(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['POST'], endpoint=endpoint, strict_slashes=strict_slashes)

    def put(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['PUT'], endpoint=endpoint, strict_slashes=strict_slashes)

    def delete(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['DELETE'], endpoint=endpoint, strict_slashes=strict_slashes)

    def connect(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['CONNECT'], endpoint=endpoint, strict_slashes=strict_slashes)

    def options(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['OPTIONS'], endpoint=endpoint, strict_slashes=strict_slashes)

    def trace(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['TRACE'], endpoint=endpoint, strict_slashes=strict_slashes)

    def patch(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        return self.route(pattern, methods=['PATCH'], endpoint=endpoint, strict_slashes=strict_slashes)
    #endregion

    def register_blueprint(self, blueprint: Blueprint) -> None:
        self.blueprints.append(blueprint)

        for route in blueprint.routes:
            use_strict = (
                route.strict_slashes
                if route.strict_slashes is not None
                else blueprint.strict_slashes
                if blueprint.strict_slashes is not None
                else self.strict_slashes
            )
            app_route = Route(
                pattern=RoutePattern(route.pattern.pattern, converters=route.pattern.converters),
                handler=route.handler,
                methods=route.methods,
                endpoint=route.endpoint,
                decorators=route.decorators,
                strict_slashes=use_strict,
                blueprint=route.blueprint,
            )
            self.routes.append(app_route)
            self._endpoint_map[route.endpoint] = app_route

        self._blueprint_before_request_handlers.setdefault(blueprint.name, []).extend(
            blueprint.before_request_handlers,
        )
        self._blueprint_after_request_handlers.setdefault(blueprint.name, []).extend(
            blueprint.after_request_handlers,
        )
        self._blueprint_error_handlers.setdefault(blueprint.name, {}).update(
            blueprint.error_handlers,
        )
        self._invalidate_route_resolution_cache()

    def before_request(self, func: BeforeRequestHandler) -> BeforeRequestHandler:
        self.before_request_handlers.append(func)
        return func

    def after_request(self, func: AfterRequestHandler) -> AfterRequestHandler:
        self.after_request_handlers.append(func)
        return func

    def teardown_context(self, func: TeardownHandler) -> TeardownHandler:
        self.teardown_handlers.append(func)
        return func

    def on_startup(self, func: LifespanHandler) -> LifespanHandler:
        self.startup_handlers.append(func)
        return func

    def on_shutdown(self, func: LifespanHandler) -> LifespanHandler:
        self.shutdown_handlers.append(func)
        return func

    def error_handler(self, exception: type) -> Callable[[ErrorHandler], ErrorHandler]:
        def decorator(func: ErrorHandler) -> ErrorHandler:
            self.error_handlers[exception] = func
            return func
        return decorator

    @staticmethod
    def _first_header_token(value: Optional[str]) -> Optional[str]:
        if not value:
            return None
        token = value.split(',', 1)[0].strip()
        return token or None

    @classmethod
    def _forwarded_header_param(cls, value: Optional[str], key: str) -> Optional[str]:
        first_value = cls._first_header_token(value)
        if not first_value:
            return None

        for part in first_value.split(';'):
            name, separator, raw_value = part.partition('=')
            if not separator:
                continue
            if name.strip().lower() != key:
                continue
            parsed = raw_value.strip().strip('"')
            if parsed:
                return parsed

        return None

    def _build_full_url_from_request(self, url: str, request: Request) -> str:
        proto = self._first_header_token(request.get_header(KnownHeader.X_FORWARDED_PROTO))
        if proto is None:
            proto = self._forwarded_header_param(
                request.get_header(KnownHeader.FORWARDED),
                'proto',
            )
        if proto is None:
            proto = 'http'

        host = self._first_header_token(request.get_header(KnownHeader.X_FORWARDED_HOST))
        if host is None:
            host = self._forwarded_header_param(
                request.get_header(KnownHeader.FORWARDED),
                'host',
            )
        if host is None:
            host = self._first_header_token(request.get_header(KnownHeader.HOST))
        if host is None:
            raise ValueError(
                'full_url requires base_url or a Host/X-Forwarded-Host/Forwarded header.',
            )

        if url.startswith('/'):
            return f'{proto}://{host}{url}'
        return f'{proto}://{host}/{url}'

    def url_for(
        self,
        endpoint: str,
        *,
        full_url: bool = False,
        **params: Any,
    ) -> str:
        route = self._endpoint_map.get(endpoint)
        if not route:
            raise ValueError(f'Unknown endpoint: {endpoint}')

        pattern = route.pattern.pattern
        url = pattern
        missing_params = [name for name in route.pattern.param_names if name not in params]
        if missing_params:
            missing = ', '.join(sorted(set(missing_params)))
            raise ValueError(f'Missing route params for endpoint {endpoint}: {missing}')

        for name, type_name, converter in zip(
            route.pattern.param_names,
            route.pattern.param_types,
            route.pattern.param_converters,
        ):
            value = params[name]

            if converter is None:
                raw_value = str(value)
                safe = ''
                placeholder = f'<{name}>'
            else:
                raw_value = str(converter.format(value))
                safe = '/' if converter.allows_slash else ''
                if type_name is None:
                    placeholder = f'<{name}>'
                else:
                    placeholder = f'<{type_name}:{name}>'

            encoded_value = quote(raw_value, safe=safe)
            url = url.replace(placeholder, encoded_value)

        if not full_url:
            return url

        if not self.base_url:
            raise ValueError('full_url requires base_url to be set.')
        base_url = self.base_url.rstrip('/')
        if url.startswith('/'):
            return f'{base_url}{url}'
        return f'{base_url}/{url}'

    @staticmethod
    def _normalize_session_create_result(result: Any) -> tuple[str, dict[str, Any]]:
        if not isinstance(result, tuple) or len(result) != 2:
            raise TypeError('session_engine.create() must return (session_id, dict).')
        session_id, data = result
        if not isinstance(session_id, str):
            raise TypeError('session_engine.create() must return (session_id: str, dict).')
        if not isinstance(data, dict):
            raise TypeError('session_engine.create() must return (session_id, dict).')
        return session_id, data

    async def _get_or_create_session(self, request: Request) -> Session:
        session_id = request.cookies.get(self.session_cookie_name)
        if session_id:
            loaded = await self.session_engine.load(session_id)
            if loaded is not None:
                if not isinstance(loaded, dict):
                    raise TypeError('session_engine.load() must return dict or None.')
                return Session(
                    session_id,
                    dict(loaded),
                    new=False,
                )

        created = await self.session_engine.create()
        session_id, data = self._normalize_session_create_result(created)
        return Session(
            session_id,
            dict(data),
            new=True,
        )

    async def _persist_session(self, session: Session) -> None:
        if session.destroyed:
            await self.session_engine.destroy(session.id)
            return

        await self.session_engine.save(session.id, session.data)

    async def _apply_session_cookie(
        self,
        ctx: Context,
        response: Response,
    ) -> Response:
        session = ctx._session
        if session is None:
            return response

        if session.destroyed:
            await self._persist_session(session)
            response.set_cookie(
                self.session_cookie_name,
                '',
                max_age=0,
                path=self.session_cookie_path,
                secure=self.session_cookie_secure,
                httponly=self.session_cookie_httponly,
                samesite=self.session_cookie_samesite,
            )
            return response

        if session.new and not session.modified and not session.data:
            return response

        should_set_cookie = session.new
        await self._persist_session(session)
        if should_set_cookie:
            response.set_cookie(
                self.session_cookie_name,
                session.id,
                path=self.session_cookie_path,
                secure=self.session_cookie_secure,
                httponly=self.session_cookie_httponly,
                samesite=self.session_cookie_samesite,
            )
        return response

    async def _try_static_response(self, path: str, method: RequestMethod) -> Optional[Response]:
        if not self.public_dir or method not in ('GET', 'HEAD'):
            return None

        request_path = unquote(path).lstrip('/')
        if not request_path:
            return None

        base_dir = Path(self.public_dir).resolve()
        fs_path = (base_dir / request_path).resolve()
        if not fs_path.is_relative_to(base_dir):
            return None

        if not fs_path.is_file():
            return None

        try:
            file_size = await to_thread(lambda: fs_path.stat().st_size)
        except OSError:
            raise HTTPException(403)

        # Probe readability before returning a streaming response.
        try:
            handle = await to_thread(open, fs_path, 'rb')
            await to_thread(handle.close)
        except OSError:
            raise HTTPException(403)

        content_type, _ = guess_type(fs_path)
        headers: Headers = {
            KnownHeader.CONTENT_TYPE: content_type or KnownContentType.OCTET_STREAM,
            KnownHeader.CONTENT_LENGTH: str(file_size),
        }

        if method == 'HEAD':
            return Response(body=b'', status=200, headers=headers)

        chunk_size = 64 * 1024

        async def stream_file() -> AsyncIterator[bytes]:
            handle = await to_thread(open, fs_path, 'rb')
            try:
                while True:
                    chunk = await to_thread(handle.read, chunk_size)
                    if not chunk:
                        return
                    yield chunk
            finally:
                await to_thread(handle.close)

        return StreamResponse(stream=stream_file(), status=200, headers=headers)

    def _resolve_route(
        self,
        path: str,
        method: str,
    ) -> tuple[Optional[tuple[Route, RouteParams]], list[str]]:
        self._ensure_route_indexes()
        cache_key = (path, method)
        cached = self._route_resolution_cache.get(cache_key)
        if cached is not None:
            cached_route, frozen_params, cached_allowed_methods = cached
            if cached_route is not None and frozen_params is not None:
                return (cached_route, dict(frozen_params)), list(cached_allowed_methods)
            return None, list(cached_allowed_methods)

        first_segment, segment_count = self._path_segment_info(path)
        path_variants: list[tuple[str, int]] = [(path, segment_count)]
        if path != '/':
            alt_path = self._toggle_trailing_slash(path)
            if alt_path != path:
                _, alt_segment_count = self._path_segment_info(alt_path)
                path_variants.append((alt_path, alt_segment_count))

        candidate_indices: list[int] = []
        for candidate_path, _ in path_variants:
            candidate_indices.extend(self._http_exact_route_indices.get(candidate_path, []))
        candidate_indices.extend(self._http_dynamic_route_indices.get(first_segment, []))
        if first_segment is not None:
            candidate_indices.extend(self._http_dynamic_route_indices.get(None, []))

        seen_indices: set[int] = set(candidate_indices)
        ordered_candidate_indices = sorted(
            seen_indices,
            key=self._route_sort_key,
            reverse=True,
        )

        methods_for_path: list[str] = []
        for index in ordered_candidate_indices:
            route = self._http_routes_by_index[index]
            pattern = route.pattern
            route_is_strict = self._route_is_strict(route, self.strict_slashes)
            variants_to_match = path_variants[:1] if route_is_strict else path_variants

            params: Optional[RouteParams] = None
            for candidate_path, candidate_segment_count in variants_to_match:
                fixed_segment_count = pattern.fixed_segment_count
                if (
                    fixed_segment_count is not None
                    and candidate_segment_count != fixed_segment_count
                ):
                    continue

                params = route.pattern.match(candidate_path)
                if params is not None:
                    break

            if params is None:
                continue

            method_allowed = method in route.methods or (method == 'HEAD' and 'GET' in route.methods)
            if method_allowed:
                self._cache_set(
                    self._route_resolution_cache,
                    cache_key,
                    (route, tuple(params.items()), tuple()),
                    self._route_cache_max_size,
                )
                return (route, params), []

            methods_for_path.extend(route.methods)
            if 'GET' in route.methods:
                methods_for_path.append('HEAD')

        # Preserve registration order while removing duplicates.
        allowed_methods = list(dict.fromkeys(methods_for_path))
        self._cache_set(
            self._route_resolution_cache,
            cache_key,
            (None, None, tuple(allowed_methods)),
            self._route_cache_max_size,
        )

        return None, allowed_methods

    def _match_route(self, path: str, method: str) -> Optional[tuple[Route, RouteParams]]:
        match, _ = self._resolve_route(path, method)
        return match

    def _allowed_methods_for_path(self, path: str) -> list[str]:
        _, allowed_methods = self._resolve_route(path, '__allowed__')
        return allowed_methods

    @staticmethod
    def _normalize_content_type_matcher(
        matcher: ContentTypeMatcher,
    ) -> Callable[[str], bool]:
        if isinstance(matcher, str):
            needle = matcher.lower()

            def matches(content_type: str) -> bool:
                return needle in content_type

            return matches
        if callable(matcher):
            return matcher
        raise TypeError('matcher must be a content-type substring or callable.')

    def add_request_payload_parser(
        self,
        matcher: ContentTypeMatcher,
        parser: RequestPayloadParser,
        *,
        first: bool = False,
    ) -> None:
        if not callable(parser):
            raise TypeError('parser must be callable.')
        normalized_matcher = self._normalize_content_type_matcher(matcher)
        entry = (normalized_matcher, parser)
        if first:
            self._request_payload_parsers.insert(0, entry)
        else:
            self._request_payload_parsers.append(entry)

    def clear_request_payload_parsers(self) -> None:
        self._request_payload_parsers.clear()

    def _install_default_request_payload_parsers(self) -> None:
        self.add_request_payload_parser(KnownContentType.JSON, lambda request: request.json)
        self.add_request_payload_parser(KnownContentType.FORM_URLENCODED, lambda request: request.form)

    def _parse_request_payload(self, request: Request) -> RequestPayload:
        content_type = (request.get_header(KnownHeader.CONTENT_TYPE, '') or '').lower()
        for matcher, parser in self._request_payload_parsers:
            if matcher(content_type):
                return parser(request)

        return request.body

    def add_response_coercer(
        self,
        coercer: ResponseCoercer,
        *,
        first: bool = False,
    ) -> None:
        if not callable(coercer):
            raise TypeError('coercer must be callable.')
        if first:
            self._response_coercers.insert(0, coercer)
        else:
            self._response_coercers.append(coercer)

    def clear_response_coercers(self) -> None:
        self._response_coercers.clear()

    def _install_default_response_coercers(self) -> None:
        self.add_response_coercer(self._coerce_response_instance)
        self.add_response_coercer(self._coerce_response_tuple)
        self.add_response_coercer(self._coerce_response_dict)
        self.add_response_coercer(self._coerce_response_fallback)

    def _coerce_response_instance(self, result: Any) -> Optional[Response]:
        if isinstance(result, Response):
            return result
        return None

    def _coerce_response_tuple(self, result: Any) -> Optional[Response]:
        if not isinstance(result, tuple):
            return None

        if len(result) == 2:
            body, status = result
            if isinstance(body, dict):
                return self._json_response(body, status=status)
            return Response(body=body, status=status)

        if len(result) == 3:
            body, status, headers = result
            if isinstance(body, dict):
                return self._json_response(body, status=status, headers=headers)
            return Response(body=body, status=status, headers=headers)

        raise ValueError('Tuple must be (body, status) or (body, status, headers)')

    def _coerce_response_dict(self, result: Any) -> Optional[Response]:
        if isinstance(result, dict):
            return self._json_response(result)
        return None

    @staticmethod
    def _coerce_response_fallback(result: Any) -> Optional[Response]:
        return Response(body=result)

    @staticmethod
    def _headers_have_content_type(headers: Headers) -> bool:
        return KnownHeader.CONTENT_TYPE.value in headers

    def _json_response(
        self,
        payload: dict[str, Any],
        *,
        status: int = 200,
        headers: Optional[Headers] = None,
    ) -> Response:
        body = self.dumps(payload)
        if not isinstance(body, (str, bytes)):
            raise TypeError('dumps must return str or bytes.')

        resolved_headers: Headers = dict(headers or {})
        if not self._headers_have_content_type(resolved_headers):
            resolved_headers[KnownHeader.CONTENT_TYPE] = KnownContentType.JSON
        return Response(body=body, status=status, headers=resolved_headers)

    def _make_response(self, result: RouteResult) -> Response:
        for coercer in self._response_coercers:
            response = coercer(result)
            if response is None:
                continue
            if not isinstance(response, Response):
                raise TypeError('response coercers must return Response or None.')
            return response

        raise TypeError(f'No response coercer handled result type: {type(result).__name__}')

    async def _run_before_handlers(
        self,
        ctx: Context,
        handlers: list[BeforeRequestHandler],
    ) -> Optional[Response]:
        for handler in handlers:
            if self._callable_accepts_ctx(handler):
                result = await handler(ctx)
            else:
                result = await handler()

            if result is not None:
                return self._make_response(result)

        return None

    async def _run_after_handlers(
        self,
        ctx: Context,
        response: Response,
        handlers: list[AfterRequestHandler],
        *,
        include_after_this_request_callbacks: bool = False,
    ) -> Response:
        for handler in handlers:
            response = await handler(response)

        if include_after_this_request_callbacks:
            for handler in ctx._after_request_callbacks:
                response = await handler(response)

        return response

    async def _run_response_middleware_chain(
        self,
        ctx: Context,
        terminal_handler: ResponseNext,
        middlewares: list[ResponseMiddleware],
    ) -> Response:
        async def dispatch(index: int) -> Response:
            if index >= len(middlewares):
                return await terminal_handler()

            middleware = middlewares[index]

            async def next_call() -> Response:
                return await dispatch(index + 1)

            return await middleware(ctx, next_call)

        return await dispatch(0)

    def _app_hook_middleware(self) -> ResponseMiddleware:
        async def middleware(ctx: Context, next_call: ResponseNext) -> Response:
            early_response = await self._run_before_handlers(ctx, self.before_request_handlers)
            if early_response is None:
                response = await next_call()
            else:
                response = early_response

            return await self._run_after_handlers(
                ctx,
                response,
                self.after_request_handlers,
                include_after_this_request_callbacks=True,
            )

        return middleware

    def _blueprint_hook_middleware(self, blueprint_name: str) -> ResponseMiddleware:
        before_handlers = self._blueprint_before_request_handlers.get(blueprint_name, [])
        after_handlers = self._blueprint_after_request_handlers.get(blueprint_name, [])

        async def middleware(ctx: Context, next_call: ResponseNext) -> Response:
            early_response = await self._run_before_handlers(ctx, before_handlers)
            if early_response is None:
                response = await next_call()
            else:
                response = early_response

            return await self._run_after_handlers(ctx, response, after_handlers)

        return middleware

    def _error_response_middleware(
        self,
        blueprint_name_getter: Callable[[], Optional[str]],
        error_sink: Callable[[BaseException], None],
    ) -> ResponseMiddleware:
        async def middleware(ctx: Context, next_call: ResponseNext) -> Response:
            try:
                return await next_call()
            except Exception as e:
                error_sink(e)
                return await self._handle_error(
                    ctx,
                    e,
                    blueprint_name=blueprint_name_getter(),
                )

        return middleware

    async def _run_teardown(self, ctx: Context, exc: Optional[BaseException]) -> None:
        for handler in self.teardown_handlers:
            try:
                await handler(ctx, exc)
            except Exception:
                self.logger.exception('Error in teardown handler.')

    async def _handle_error(
        self,
        ctx: Context,
        exc: BaseException,
        *,
        blueprint_name: Optional[str] = None,
    ) -> Response:
        allowed_methods = getattr(exc, 'allowed_methods', None)

        if blueprint_name:
            blueprint_error_handlers = self._blueprint_error_handlers.get(blueprint_name, {})
            for exc_type in getmro(type(exc)):
                if exc_type in blueprint_error_handlers:
                    handler = blueprint_error_handlers[exc_type]
                    result = await handler(ctx, exc)
                    response = self._make_response(result)
                    if allowed_methods:
                        response.set_header(KnownHeader.ALLOW, ', '.join(allowed_methods))
                    return response

        for exc_type in getmro(type(exc)):
            if exc_type in self.error_handlers:
                handler = self.error_handlers[exc_type]
                result = await handler(ctx, exc)
                response = self._make_response(result)
                if allowed_methods:
                    response.set_header(KnownHeader.ALLOW, ', '.join(allowed_methods))
                return response

        status = getattr(exc, 'status_code', 500)
        message = str(exc) or HTTPStatus(status).phrase
        escaped_phrase = html_escape(HTTPStatus(status).phrase)
        escaped_message = html_escape(message)
        response = Response(
            body=f'<h1>{status} {escaped_phrase}</h1><p>{escaped_message}</p>',
            status=status,
        )
        if allowed_methods:
            response.set_header(KnownHeader.ALLOW, ', '.join(allowed_methods))
        return response

    async def _run_lifespan_handlers(self, handlers: list[LifespanHandler]) -> None:
        for handler in handlers:
            if self._callable_accepts_ctx(handler):
                await handler(self)
            else:
                await handler()

    async def _handle_lifespan(self, receive: Callable, send: Callable) -> None:
        while True:
            message = await receive()
            if message['type'] == 'lifespan.startup':
                try:
                    await self._run_lifespan_handlers(self.startup_handlers)
                except Exception as e:
                    self.logger.exception('Startup handler failed.')
                    await send({'type': 'lifespan.startup.failed', 'message': str(e)})
                    return

                await send({'type': 'lifespan.startup.complete'})
            elif message['type'] == 'lifespan.shutdown':
                try:
                    await self._run_lifespan_handlers(self.shutdown_handlers)
                except Exception as e:
                    self.logger.exception('Shutdown handler failed.')
                    await send({'type': 'lifespan.shutdown.failed', 'message': str(e)})
                    return

                await send({'type': 'lifespan.shutdown.complete'})

                return

    async def _handle_request_object(self, request: Request) -> Response:
        method = request.method
        path = request.path
        ctx = Context(request=request, app=self)
        if self.session_cookie_name in request.cookies:
            ctx._session = await self._get_or_create_session(request)
        exc: Optional[BaseException] = None
        active_blueprint_name: Optional[str] = None
        handled_exception: Optional[BaseException] = None

        def remember_exception(error: BaseException) -> None:
            nonlocal handled_exception
            handled_exception = error

        async def endpoint_dispatch() -> Response:
            nonlocal active_blueprint_name

            static_response = await self._try_static_response(path, method)
            if static_response is not None:
                return static_response

            match, allowed_methods = self._resolve_route(path, method)
            if not match:
                if allowed_methods:
                    method_not_allowed = HTTPException(405)
                    method_not_allowed.allowed_methods = allowed_methods
                    raise method_not_allowed
                raise HTTPException(404)

            route, params = match
            request.route_params = params
            active_blueprint_name = route.blueprint

            async def invoke_route_handler() -> Response:
                handler, handler_accepts_ctx = self._resolve_route_handler(route)
                if handler_accepts_ctx:
                    result = await handler(ctx)
                else:
                    result = await handler()

                return self._make_response(result)

            if active_blueprint_name:
                return await self._run_response_middleware_chain(
                    ctx,
                    invoke_route_handler,
                    [self._blueprint_hook_middleware(active_blueprint_name)],
                )

            return await invoke_route_handler()

        middlewares: list[ResponseMiddleware] = [
            self._error_response_middleware(
                lambda: active_blueprint_name,
                remember_exception,
            ),
            self._app_hook_middleware(),
        ]

        try:
            response = await self._run_response_middleware_chain(
                ctx,
                endpoint_dispatch,
                middlewares,
            )
        except BaseException as e:
            exc = e
            raise
        finally:
            if exc is None:
                exc = handled_exception
            await self._run_teardown(ctx, exc)

        response = await self._apply_session_cookie(ctx, response)
        return response

    async def handle_request(
            self,
            method: RequestMethod,
            path: str,
            query_string: str,
            headers: Headers,
            body: bytes
    ) -> Response:
        request = Request(
            method=method,
            path=path,
            query_string=query_string,
            headers=headers,
            body=body,
            json_loads=self.loads,
            payload_parser=self._parse_request_payload,
            max_body_size=self.max_request_body_size,
        )
        return await self._handle_request_object(request)

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        if scope['type'] == 'lifespan':
            await self._handle_lifespan(receive, send)
            return

        if scope['type'] == 'websocket':
            await send({'type': 'websocket.close', 'code': 1003})
            return

        if scope['type'] != 'http':
            return

        method = scope['method']
        path = scope['path']
        async def send_early_response(response: Response) -> None:
            await send({
                'type': 'http.response.start',
                'status': response.status,
                'headers': _encode_headers_for_asgi(response.headers),
            })
            await send({
                'type': 'http.response.body',
                'body': b'' if method == 'HEAD' else (
                    response.body.encode('utf-8') if isinstance(response.body, str) else response.body
                ),
            })

        try:
            query_string = scope.get('query_string', b'').decode('utf-8')
        except UnicodeDecodeError:
            await send_early_response(
                Response(
                    body=(
                        '<h1>400 Bad Request</h1>'
                        '<p>Malformed UTF-8 in query string.</p>'
                    ),
                    status=400,
                ),
            )
            return

        headers = {}
        for name, value in scope.get('headers', []):
            try:
                header_name = name.decode('utf-8').lower()
                header_value = value.decode('utf-8')
            except UnicodeDecodeError:
                await send_early_response(
                    Response(
                        body=(
                            '<h1>400 Bad Request</h1>'
                            '<p>Malformed UTF-8 in request headers.</p>'
                        ),
                        status=400,
                    ),
                )
                return

            _append_request_header(
                headers,
                header_name,
                header_value,
            )

        if self.max_request_body_size is not None:
            content_length = _max_content_length(headers)
            if content_length is not None and content_length > self.max_request_body_size:
                await send_early_response(
                    Response(
                        body=(
                            '<h1>413 Request Entity Too Large</h1>'
                            '<p>Request body exceeds configured maximum size.</p>'
                        ),
                        status=413,
                    ),
                )
                return

        request = Request(
            method=method,
            path=path,
            query_string=query_string,
            headers=headers,
            body=b'',
            json_loads=self.loads,
            payload_parser=self._parse_request_payload,
            body_receive=receive,
            max_body_size=self.max_request_body_size,
        )
        response = await self._handle_request_object(request)
        if not response.is_stream:
            over_limit = await request.drain_unread_body()
            if request.client_disconnected:
                return
            if over_limit:
                response = Response(
                    body=(
                        '<h1>413 Request Entity Too Large</h1>'
                        '<p>Request body exceeds configured maximum size.</p>'
                    ),
                    status=413,
                )

        await send({
            'type': 'http.response.start',
            'status': response.status,
            'headers': _encode_headers_for_asgi(response.headers),
        })

        if method == 'HEAD':
            await send({
                'type': 'http.response.body',
                'body': b'',
                'more_body': False,
            })
            return

        if response.is_stream:
            async for chunk in response.iter_chunks():
                if not chunk:
                    continue
                await send({
                    'type': 'http.response.body',
                    'body': chunk,
                    'more_body': True,
                })
            await send({
                'type': 'http.response.body',
                'body': b'',
                'more_body': False,
            })
            return

        body_bytes = response.body.encode('utf-8') if isinstance(response.body, str) else response.body
        await send({
            'type': 'http.response.body',
            'body': body_bytes,
        })
