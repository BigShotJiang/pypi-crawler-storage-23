import json
import pytest
import asyncio
from typing import Any
from datetime import datetime, timezone

from ryuuseigun import (
    Blueprint,
    HTTPException,
    KnownContentType,
    KnownHeader,
    KnownSameSite,
    Response,
    Ryuuseigun,
)
from ryuuseigun.utils import apply_conditional_response, format_http_date, make_etag


def run(coro):
    return asyncio.run(coro)


def response_header(response, name: str) -> str | None:
    name = name.lower()
    for key, value in response.headers.items():
        if str(key).lower() != name:
            continue
        if isinstance(value, list):
            return ", ".join(value)
        return str(value)
    return None


async def call_asgi_http(
    app: Ryuuseigun,
    *,
    method: str,
    path: str,
    headers: dict[str, str] | None = None,
    raw_headers: list[tuple[bytes, bytes]] | None = None,
    query_string: bytes = b"",
    body_chunks: list[bytes] | None = None,
    tail_messages: list[dict[str, Any]] | None = None,
    idle_message: dict[str, Any] | None = None,
) -> tuple[int, dict[str, list[str]], bytes]:
    sent_messages: list[dict[str, Any]] = []
    chunks = body_chunks or [b""]

    http_messages: list[dict[str, Any]] = []
    if len(chunks) == 1:
        http_messages.append({"type": "http.request", "body": chunks[0], "more_body": False})
    else:
        for i, chunk in enumerate(chunks):
            http_messages.append(
                {
                    "type": "http.request",
                    "body": chunk,
                    "more_body": i < len(chunks) - 1,
                }
            )

    if tail_messages:
        http_messages.extend(tail_messages)

    async def receive() -> dict[str, Any]:
        if http_messages:
            return http_messages.pop(0)
        if idle_message is not None:
            return idle_message
        return {"type": "http.disconnect"}

    async def send(message: dict[str, Any]) -> None:
        sent_messages.append(message)

    scope = {
        "type": "http",
        "http_version": "1.1",
        "method": method,
        "path": path,
        "query_string": query_string,
        "headers": raw_headers if raw_headers is not None else [
            (k.lower().encode("utf-8"), v.encode("utf-8"))
            for k, v in (headers or {}).items()
        ],
    }

    await app(scope, receive, send)

    start = next(msg for msg in sent_messages if msg["type"] == "http.response.start")
    body = b"".join(msg.get("body", b"") for msg in sent_messages if msg["type"] == "http.response.body")

    response_headers: dict[str, list[str]] = {}
    for raw_name, raw_value in start["headers"]:
        name = raw_name.decode("utf-8").lower()
        value = raw_value.decode("utf-8")
        response_headers.setdefault(name, []).append(value)

    return start["status"], response_headers, body


def test_dict_response_and_custom_json_hooks() -> None:
    loads_calls: list[bytes] = []
    dumps_calls: list[dict[str, Any]] = []

    def loads(raw: Any) -> Any:
        if isinstance(raw, str):
            raw = raw.encode("utf-8")
        loads_calls.append(raw)
        return json.loads(raw)

    def dumps(value: Any) -> bytes:
        dumps_calls.append(value)
        return json.dumps(value, separators=(",", ":")).encode("utf-8")

    app = Ryuuseigun(__name__, "http://localhost", loads=loads, dumps=dumps)

    @app.post("/echo")
    async def echo(ctx):
        payload = await ctx.request.json_async()
        return {"plus": payload["value"] + 1}

    response = run(
        app.handle_request(
            "POST",
            "/echo",
            "",
            {KnownHeader.CONTENT_TYPE: KnownContentType.JSON},
            b'{"value":41}',
        )
    )

    assert response.status == 200
    assert response.body == b'{"plus":42}'
    assert response_header(response, KnownHeader.CONTENT_TYPE.value) == KnownContentType.JSON.value
    assert loads_calls == [b'{"value":41}']
    assert dumps_calls == [{"plus": 42}]


def test_constructor_base_url_is_optional() -> None:
    app = Ryuuseigun(__name__)

    @app.get("/")
    async def index():
        return "ok"

    response = run(app.handle_request("GET", "/", "", {}, b""))

    assert response.status == 200
    assert response.body == "ok"


def test_context_url_for_full_url_uses_request_host_when_base_url_missing() -> None:
    app = Ryuuseigun(__name__)

    @app.get("/hello")
    async def hello():
        return "ok"

    @app.get("/link")
    async def link(ctx):
        return {"url": ctx.url_for("hello", full_url=True)}

    status, _, body = run(
        call_asgi_http(
            app,
            method="GET",
            path="/link",
            headers={"host": "example.test"},
        )
    )

    assert status == 200
    assert json.loads(body) == {"url": "http://example.test/hello"}


def test_context_url_for_full_url_prefers_x_forwarded_headers() -> None:
    app = Ryuuseigun(__name__)

    @app.get("/hello")
    async def hello():
        return "ok"

    @app.get("/link")
    async def link(ctx):
        return {"url": ctx.url_for("hello", full_url=True)}

    status, _, body = run(
        call_asgi_http(
            app,
            method="GET",
            path="/link",
            headers={
                "host": "internal.local",
                "x-forwarded-proto": "https",
                "x-forwarded-host": "api.example.com",
            },
        )
    )

    assert status == 200
    assert json.loads(body) == {"url": "https://api.example.com/hello"}


def test_url_for_full_url_without_base_url_still_requires_base_url_outside_context() -> None:
    app = Ryuuseigun(__name__)

    @app.get("/hello")
    async def hello():
        return "ok"

    with pytest.raises(ValueError, match="full_url requires base_url"):
        _ = app.url_for("hello", full_url=True)


def test_make_etag_is_stable_and_quoted() -> None:
    tag_from_str = make_etag("hello world")
    tag_from_bytes = make_etag(b"hello world")
    weak_tag = make_etag(b"hello world", weak=True)

    assert tag_from_str == tag_from_bytes
    assert tag_from_str.startswith('"') and tag_from_str.endswith('"')
    assert weak_tag == f"W/{tag_from_str}"


def test_apply_conditional_response_returns_304_on_matching_if_none_match() -> None:
    app = Ryuuseigun(__name__, "http://localhost")
    body = b"asset-v1"
    etag = make_etag(body)

    @app.get("/asset")
    async def asset(ctx):
        response = Response(
            body=body,
            headers={KnownHeader.CONTENT_TYPE: KnownContentType.OCTET_STREAM},
        )
        return apply_conditional_response(
            ctx,
            response,
            etag=etag,
            cache_control="public, max-age=60",
        )

    first_status, first_headers, first_body = run(
        call_asgi_http(app, method="GET", path="/asset")
    )
    assert first_status == 200
    assert first_body == body
    assert first_headers[KnownHeader.ETAG.value] == [etag]
    assert first_headers[KnownHeader.CACHE_CONTROL.value] == ["public, max-age=60"]

    second_status, second_headers, second_body = run(
        call_asgi_http(
            app,
            method="GET",
            path="/asset",
            headers={KnownHeader.IF_NONE_MATCH.value: etag},
        )
    )
    assert second_status == 304
    assert second_body == b""
    assert second_headers[KnownHeader.ETAG.value] == [etag]
    assert second_headers[KnownHeader.CACHE_CONTROL.value] == ["public, max-age=60"]
    assert KnownHeader.CONTENT_TYPE.value not in second_headers


def test_apply_conditional_response_uses_last_modified_when_no_if_none_match() -> None:
    app = Ryuuseigun(__name__, "http://localhost")
    last_modified = datetime(2026, 2, 20, 0, 0, 0, tzinfo=timezone.utc)
    last_modified_header = format_http_date(last_modified)

    @app.get("/docs")
    async def docs(ctx):
        response = Response("docs-v1")
        return apply_conditional_response(
            ctx,
            response,
            last_modified=last_modified,
            cache_control="public, max-age=300",
        )

    status, headers, body = run(
        call_asgi_http(
            app,
            method="GET",
            path="/docs",
            headers={KnownHeader.IF_MODIFIED_SINCE.value: last_modified_header},
        )
    )
    assert status == 304
    assert body == b""
    assert headers[KnownHeader.LAST_MODIFIED.value] == [last_modified_header]
    assert headers[KnownHeader.CACHE_CONTROL.value] == ["public, max-age=300"]


def test_if_none_match_takes_precedence_over_if_modified_since() -> None:
    app = Ryuuseigun(__name__, "http://localhost")
    body = b"payload"
    etag = make_etag(body)
    last_modified = datetime(2025, 1, 1, 0, 0, 0, tzinfo=timezone.utc)

    @app.get("/resource")
    async def resource(ctx):
        response = Response(body=body)
        return apply_conditional_response(
            ctx,
            response,
            etag=etag,
            last_modified=last_modified,
        )

    status, _, response_body = run(
        call_asgi_http(
            app,
            method="GET",
            path="/resource",
            headers={
                KnownHeader.IF_NONE_MATCH.value: '"other-tag"',
                KnownHeader.IF_MODIFIED_SINCE.value: format_http_date(datetime(2030, 1, 1, tzinfo=timezone.utc)),
            },
        )
    )
    assert status == 200
    assert response_body == body


def test_custom_response_coercer_handles_custom_return_type() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    class Box:
        def __init__(self, value: str):
            self.value = value

    def box_coercer(result: Any):
        if isinstance(result, Box):
            return Response(f"box:{result.value}", status=201)
        return None

    app.add_response_coercer(box_coercer, first=True)

    @app.get("/box")
    async def box_route():
        return Box("ok")

    response = run(app.handle_request("GET", "/box", "", {}, b""))
    assert response.status == 201
    assert response.body == "box:ok"


def test_custom_request_payload_parser_handles_custom_content_type() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    app.add_request_payload_parser(
        "text/csv",
        lambda request: [
            row.split(",")
            for row in request.body.decode("utf-8").splitlines()
            if row
        ],
        first=True,
    )

    @app.post("/csv")
    async def csv_route(ctx):
        payload = await ctx.request.payload_async()
        return {"rows": payload}

    response = run(
        app.handle_request(
            "POST",
            "/csv",
            "",
            {KnownHeader.CONTENT_TYPE: "text/csv"},
            b"a,b\n1,2\n",
        )
    )
    assert response.status == 200
    assert json.loads(response.body) == {"rows": [["a", "b"], ["1", "2"]]}


def test_custom_route_converter_parse_and_url_for_format() -> None:
    app = Ryuuseigun(__name__, "http://localhost")
    app.register_converter(
        "hex",
        regex=r"[0-9a-fA-F]+",
        parse=lambda raw: int(raw, 16),
        format=lambda value: format(int(value), "x"),
    )

    @app.get("/color/<hex:value>")
    async def color(ctx):
        return {"value": ctx.request.route_param("value")}

    response = run(app.handle_request("GET", "/color/ff", "", {}, b""))
    assert response.status == 200
    assert json.loads(response.body) == {"value": 255}
    assert app.url_for("color", value=255) == "/color/ff"


def test_custom_route_converter_allows_slash_segments() -> None:
    app = Ryuuseigun(__name__, "http://localhost")
    app.register_converter(
        "segmentpath",
        regex=r".+",
        parse=str,
        format=str,
        allows_slash=True,
    )

    @app.get("/files/<segmentpath:key>")
    async def files(ctx):
        return {"key": ctx.request.route_param("key")}

    response = run(app.handle_request("GET", "/files/a/b/c", "", {}, b""))
    assert response.status == 200
    assert json.loads(response.body) == {"key": "a/b/c"}
    assert app.url_for("files", key="a/b/c") == "/files/a/b/c"


def test_blueprint_custom_route_converter_survives_registration() -> None:
    app = Ryuuseigun(__name__, "http://localhost")
    bp = Blueprint("bp", url_prefix="/bp")
    bp.register_converter(
        "slug",
        regex=r"[a-z0-9-]+",
        parse=lambda raw: raw.upper(),
        format=lambda value: str(value).lower(),
    )

    @bp.get("/<slug:item>")
    async def item(ctx):
        return {"item": ctx.request.route_param("item")}

    app.register_blueprint(bp)

    response = run(app.handle_request("GET", "/bp/abc-1", "", {}, b""))
    assert response.status == 200
    assert json.loads(response.body) == {"item": "ABC-1"}
    assert app.url_for("bp.item", item="ABC-1") == "/bp/abc-1"


def test_non_strict_route_matches_both_slash_variants_without_duplicate_routes() -> None:
    app = Ryuuseigun(__name__, "http://localhost", strict_slashes=False)

    @app.get("/hello")
    async def hello():
        return "ok"

    assert len(app.routes) == 1

    no_slash = run(app.handle_request("GET", "/hello", "", {}, b""))
    with_slash = run(app.handle_request("GET", "/hello/", "", {}, b""))

    assert no_slash.status == 200
    assert no_slash.body == "ok"
    assert with_slash.status == 200
    assert with_slash.body == "ok"


def test_non_strict_blueprint_route_matches_both_variants_without_duplicate_routes() -> None:
    app = Ryuuseigun(__name__, "http://localhost")
    bp = Blueprint("api", url_prefix="/api", strict_slashes=False)

    @bp.get("/ping")
    async def ping():
        return "pong"

    app.register_blueprint(bp)
    assert len(app.routes) == 1

    no_slash = run(app.handle_request("GET", "/api/ping", "", {}, b""))
    with_slash = run(app.handle_request("GET", "/api/ping/", "", {}, b""))

    assert no_slash.status == 200
    assert no_slash.body == "pong"
    assert with_slash.status == 200
    assert with_slash.body == "pong"


def test_route_specificity_prefers_static_over_path_converter() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.get("/items/<path:value>")
    async def dynamic_item(ctx):
        return f"dynamic:{ctx.request.route_param('value')}"

    @app.get("/items/new")
    async def static_item():
        return "static"

    response = run(app.handle_request("GET", "/items/new", "", {}, b""))
    assert response.status == 200
    assert response.body == "static"


def test_route_specificity_prefers_typed_converter_over_path_converter() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.get("/value/<path:value>")
    async def path_value(ctx):
        return f"path:{ctx.request.route_param('value')}"

    @app.get("/value/<int:value>")
    async def int_value(ctx):
        return f"int:{ctx.request.route_param('value')}"

    numeric_response = run(app.handle_request("GET", "/value/123", "", {}, b""))
    text_response = run(app.handle_request("GET", "/value/a/b", "", {}, b""))

    assert numeric_response.status == 200
    assert numeric_response.body == "int:123"
    assert text_response.status == 200
    assert text_response.body == "path:a/b"


def test_blueprint_hooks_and_error_handlers_are_scoped() -> None:
    app = Ryuuseigun(__name__, "http://localhost")
    bp = Blueprint("api", url_prefix="/api")

    state = {"app_before": 0, "bp_before": 0}

    @app.before_request
    async def app_before(_ctx):
        state["app_before"] += 1

    @bp.before_request
    async def bp_before(_ctx):
        state["bp_before"] += 1

    @app.error_handler(ValueError)
    async def app_error(_ctx, _exc):
        return "app", 500

    @bp.error_handler(ValueError)
    async def bp_error(_ctx, _exc):
        return "bp", 418

    @bp.get("/fail")
    async def bp_fail():
        raise ValueError("boom")

    @app.get("/fail")
    async def app_fail():
        raise ValueError("boom")

    app.register_blueprint(bp)

    bp_response = run(app.handle_request("GET", "/api/fail", "", {}, b""))
    app_response = run(app.handle_request("GET", "/fail", "", {}, b""))

    assert bp_response.status == 418
    assert bp_response.body == "bp"
    assert app_response.status == 500
    assert app_response.body == "app"
    assert state == {"app_before": 2, "bp_before": 1}


def test_session_cookie_lifecycle() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.get("/login")
    async def login(ctx):
        session = await ctx.session_async()
        session["user_id"] = 123
        return "ok"

    @app.get("/me")
    async def me(ctx):
        session = await ctx.session_async()
        return str(session.get("user_id", "anon"))

    @app.get("/logout")
    async def logout(ctx):
        session = await ctx.session_async()
        session.destroy()
        return "bye"

    login_response = run(app.handle_request("GET", "/login", "", {}, b""))
    set_cookie = response_header(login_response, KnownHeader.SET_COOKIE.value)
    assert set_cookie is not None
    session_pair = set_cookie.split(";", 1)[0]

    me_response = run(
        app.handle_request(
            "GET",
            "/me",
            "",
            {KnownHeader.COOKIE: session_pair},
            b"",
        )
    )
    assert me_response.status == 200
    assert me_response.body == "123"

    logout_response = run(
        app.handle_request(
            "GET",
            "/logout",
            "",
            {KnownHeader.COOKIE: session_pair},
            b"",
        )
    )
    logout_cookie = response_header(logout_response, KnownHeader.SET_COOKIE.value)
    assert logout_cookie is not None
    assert "Max-Age=0" in logout_cookie


def test_sync_session_engine_is_rejected() -> None:
    class SyncSessionEngine:
        def load(self, _session_id: str):
            return None

        def create(self):
            return "sid", {}

        def save(self, _session_id: str, _data: dict[str, Any]):
            return None

        def destroy(self, _session_id: str):
            return None

    with pytest.raises(TypeError, match="session_engine methods must be async"):
        _ = Ryuuseigun(__name__, "http://localhost", session_engine=SyncSessionEngine())


def test_async_session_engine_roundtrip_with_session_async() -> None:
    class AsyncMemorySessionEngine:
        def __init__(self):
            self.store: dict[str, dict[str, Any]] = {}
            self.counter = 0

        async def load(self, session_id: str):
            data = self.store.get(session_id)
            if data is None:
                return None
            return dict(data)

        async def create(self):
            self.counter += 1
            return f"s{self.counter}", {}

        async def save(self, session_id: str, data: dict[str, Any]):
            self.store[session_id] = dict(data)

        async def destroy(self, session_id: str):
            self.store.pop(session_id, None)

    engine = AsyncMemorySessionEngine()
    app = Ryuuseigun(__name__, "http://localhost", session_engine=engine)

    @app.get("/login")
    async def login(ctx):
        session = await ctx.session_async()
        session["user"] = "alice"
        return "ok"

    @app.get("/me")
    async def me(ctx):
        session = await ctx.session_async()
        return session.get("user", "anon")

    login_response = run(app.handle_request("GET", "/login", "", {}, b""))
    cookie = response_header(login_response, KnownHeader.SET_COOKIE.value)
    assert cookie is not None
    session_pair = cookie.split(";", 1)[0]

    me_response = run(
        app.handle_request(
            "GET",
            "/me",
            "",
            {KnownHeader.COOKIE: session_pair},
            b"",
        )
    )
    assert me_response.status == 200
    assert me_response.body == "alice"


def test_session_property_works_when_session_is_preloaded_from_cookie() -> None:
    class AsyncMemorySessionEngine:
        def __init__(self):
            self.store: dict[str, dict[str, Any]] = {"sid-1": {"user": "alice"}}

        async def load(self, session_id: str):
            data = self.store.get(session_id)
            if data is None:
                return None
            return dict(data)

        async def create(self):
            return "sid-new", {}

        async def save(self, session_id: str, data: dict[str, Any]):
            self.store[session_id] = dict(data)

        async def destroy(self, session_id: str):
            self.store.pop(session_id, None)

    app = Ryuuseigun(__name__, "http://localhost", session_engine=AsyncMemorySessionEngine())

    @app.get("/me")
    async def me(ctx):
        return ctx.session.get("user", "anon")

    response = run(
        app.handle_request(
            "GET",
            "/me",
            "",
            {KnownHeader.COOKIE: "session=sid-1"},
            b"",
        )
    )
    assert response.status == 200
    assert response.body == "alice"


def test_session_property_requires_preloaded_or_async_access() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.error_handler(RuntimeError)
    async def runtime_error_handler(_ctx, exc):
        return str(exc), 500

    @app.get("/bad")
    async def bad(ctx):
        _ = ctx.session
        return "ok"

    response = run(app.handle_request("GET", "/bad", "", {}, b""))
    assert response.status == 500
    assert "Sessions are async-only. Use `await ctx.session_async()`." in response.body


def test_form_urlencoded_async_parsing() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.post("/form")
    async def form_route(ctx):
        return await ctx.request.form_async()

    response = run(
        app.handle_request(
            "POST",
            "/form",
            "",
            {KnownHeader.CONTENT_TYPE: KnownContentType.FORM_URLENCODED},
            b"a=1&b=2&b=3",
        )
    )

    assert response.status == 200
    assert response_header(response, KnownHeader.CONTENT_TYPE.value) == KnownContentType.JSON.value
    assert json.loads(response.body) == {"a": ["1"], "b": ["2", "3"]}


def test_chunked_upload_stream_via_asgi() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.post("/upload")
    async def upload(ctx):
        total = 0
        async for chunk in ctx.request.iter_body():
            total += len(chunk)
        return {"bytes": total}

    multipart = (
        b"--boundary123\r\n"
        b"Content-Disposition: form-data; name=\"file\"; filename=\"demo.txt\"\r\n"
        b"Content-Type: text/plain\r\n\r\n"
        b"hello upload\n"
        b"--boundary123--\r\n"
    )

    status, headers, body = run(
        call_asgi_http(
            app,
            method="POST",
            path="/upload",
            headers={"content-type": "multipart/form-data; boundary=boundary123"},
            body_chunks=[multipart[:40], multipart[40:90], multipart[90:]],
        )
    )

    assert status == 200
    assert headers[KnownHeader.CONTENT_TYPE.value] == [KnownContentType.JSON.value]
    assert json.loads(body) == {"bytes": len(multipart)}


def test_static_path_traversal_is_blocked(tmp_path) -> None:
    public_dir = tmp_path / "public"
    public_dir.mkdir()
    (public_dir / "hello.txt").write_text("ok", encoding="utf-8")
    (tmp_path / "secret.txt").write_text("secret", encoding="utf-8")

    app = Ryuuseigun(__name__, "http://localhost", public_dir=str(public_dir))

    ok_status, _, ok_body = run(call_asgi_http(app, method="GET", path="/hello.txt"))
    assert ok_status == 200
    assert ok_body == b"ok"

    traversal_paths = [
        "/../secret.txt",
        "/%2e%2e/secret.txt",
        "/..%2fsecret.txt",
        "/..%5csecret.txt",
    ]
    for path in traversal_paths:
        status, _, _ = run(call_asgi_http(app, method="GET", path=path))
        assert status == 404


def test_content_length_over_limit_returns_413_before_handler() -> None:
    app = Ryuuseigun(__name__, "http://localhost", max_request_body_size=5)
    called = {"value": False}

    @app.post("/limited")
    async def limited():
        called["value"] = True
        return "ok"

    status, _, body = run(
        call_asgi_http(
            app,
            method="POST",
            path="/limited",
            headers={"content-length": "6"},
            body_chunks=[b"abcdef"],
        )
    )

    assert status == 413
    assert b"Request Entity Too Large" in body
    assert called["value"] is False


def test_chunked_body_over_limit_returns_413_after_drain() -> None:
    app = Ryuuseigun(__name__, "http://localhost", max_request_body_size=5)
    called = {"value": False}

    @app.post("/limited")
    async def limited():
        called["value"] = True
        return "ok"

    status, _, body = run(
        call_asgi_http(
            app,
            method="POST",
            path="/limited",
            body_chunks=[b"abc", b"def"],
        )
    )

    assert status == 413
    assert b"Request Entity Too Large" in body
    assert called["value"] is True


def test_response_header_crlf_is_sanitized() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.get("/headers")
    async def headers_route():
        return "ok", 200, {"X-Test": "good\r\nx-evil: 1"}

    status, headers, _ = run(call_asgi_http(app, method="GET", path="/headers"))

    assert status == 200
    assert headers["x-test"] == ["goodx-evil: 1"]
    assert "x-evil" not in headers


def test_set_cookie_crlf_is_sanitized() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.get("/cookie")
    async def cookie_route():
        response = Response("ok")
        response.set_cookie("sid", "abc\r\nSet-Cookie: pwn=1")
        return response

    status, headers, _ = run(call_asgi_http(app, method="GET", path="/cookie"))

    assert status == 200
    cookie = headers[KnownHeader.SET_COOKIE.value][0]
    assert "\r" not in cookie
    assert "\n" not in cookie


def test_set_cookie_value_prevents_attribute_injection_and_roundtrips() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.get("/set")
    async def set_cookie_route():
        response = Response("ok")
        response.set_cookie("sid", "abc;Secure")
        return response

    @app.get("/read")
    async def read_cookie_route(ctx):
        return ctx.request.cookies.get("sid", "")

    _, headers, _ = run(call_asgi_http(app, method="GET", path="/set"))
    set_cookie = headers[KnownHeader.SET_COOKIE.value][0]
    assert set_cookie.startswith("sid=abc%3BSecure;")

    cookie_pair = set_cookie.split(";", 1)[0]
    status, _, body = run(
        call_asgi_http(
            app,
            method="GET",
            path="/read",
            headers={"cookie": cookie_pair},
        )
    )

    assert status == 200
    assert body.decode("utf-8") == "abc;Secure"


def test_http_exception_message_is_html_escaped() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.get("/bad")
    async def bad():
        raise HTTPException(400, "<script>alert(1)</script>")

    status, _, body = run(call_asgi_http(app, method="GET", path="/bad"))
    body_text = body.decode("utf-8")

    assert status == 400
    assert "<script>" not in body_text
    assert "&lt;script&gt;alert(1)&lt;/script&gt;" in body_text


def test_generic_exception_message_is_html_escaped() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.get("/boom")
    async def boom():
        raise ValueError("<b>boom</b>")

    status, _, body = run(call_asgi_http(app, method="GET", path="/boom"))
    body_text = body.decode("utf-8")

    assert status == 500
    assert "<b>boom</b>" not in body_text
    assert "&lt;b&gt;boom&lt;/b&gt;" in body_text


def test_405_includes_allow_header() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.post("/only-post")
    async def only_post():
        return "ok"

    status, headers, _ = run(call_asgi_http(app, method="GET", path="/only-post"))

    assert status == 405
    assert headers[KnownHeader.ALLOW.value] == ["POST"]


def test_head_returns_no_body() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    @app.get("/head")
    async def head_route():
        return "content"

    status, _, body = run(call_asgi_http(app, method="HEAD", path="/head"))

    assert status == 200
    assert body == b""


def test_http_invalid_query_utf8_returns_400() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    status, _, body = run(
        call_asgi_http(
            app,
            method="GET",
            path="/",
            query_string=b"\xff",
        )
    )

    assert status == 400
    assert b"Malformed UTF-8 in query string" in body


def test_http_invalid_header_utf8_returns_400() -> None:
    app = Ryuuseigun(__name__, "http://localhost")

    status, _, body = run(
        call_asgi_http(
            app,
            method="GET",
            path="/",
            raw_headers=[(b"x-test", b"\xff")],
        )
    )

    assert status == 400
    assert b"Malformed UTF-8 in request headers" in body


def test_websocket_scope_is_rejected_as_unsupported() -> None:
    app = Ryuuseigun(__name__, "http://localhost")
    sent_messages: list[dict[str, Any]] = []

    async def receive() -> dict[str, Any]:
        return {"type": "websocket.disconnect", "code": 1000}

    async def send(message: dict[str, Any]) -> None:
        sent_messages.append(message)

    scope = {
        "type": "websocket",
        "path": "/ws",
        "query_string": b"",
        "headers": [],
    }

    run(app(scope, receive, send))

    assert sent_messages == [{"type": "websocket.close", "code": 1003}]


def test_session_cookie_flags_follow_configuration() -> None:
    app = Ryuuseigun(
        __name__,
        "http://localhost",
        session_cookie_path="/app",
        session_cookie_secure=True,
        session_cookie_httponly=True,
        session_cookie_samesite=KnownSameSite.STRICT,
    )

    @app.get("/set")
    async def set_session(ctx):
        session = await ctx.session_async()
        session["user_id"] = 1
        return "ok"

    set_response = run(app.handle_request("GET", "/set", "", {}, b""))
    cookie = response_header(set_response, KnownHeader.SET_COOKIE.value)

    assert cookie is not None
    assert "Path=/app" in cookie
    assert "Secure" in cookie
    assert "HttpOnly" in cookie
    assert "SameSite=Strict" in cookie
