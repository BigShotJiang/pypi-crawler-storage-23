"""Kader CLI - Modern Vibe Coding CLI."""

from .app import KaderApp, main

__all__ = ["KaderApp", "main"]
