from __future__ import annotations

# Max bytes to read from end of a file to avoid OOM
TAIL_BYTES = 64 * 1024  # 64 KB


def read_tail(path, max_bytes: int = TAIL_BYTES) -> str:
    """Read the tail of a file, skipping partial first line."""
    try:
        file_size = path.stat().st_size
        with open(path, "rb") as f:
            if file_size > max_bytes:
                f.seek(file_size - max_bytes)
                f.readline()  # skip partial line
            return f.read().decode("utf-8", errors="replace")
    except Exception:
        return ""
