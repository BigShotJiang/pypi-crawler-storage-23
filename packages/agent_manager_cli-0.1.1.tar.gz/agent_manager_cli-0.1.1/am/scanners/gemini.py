"""Scanner for Google Gemini CLI sessions (~/.gemini/tmp/)."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from am.schemas.session import LocalSession

GEMINI_DIR = Path.home() / ".gemini" / "tmp"


def _parse_gemini_project(project_dir: Path) -> list[LocalSession]:
    """Parse sessions from a Gemini project hash directory."""
    chats_dir = project_dir / "chats"
    if not chats_dir.is_dir():
        return []

    sessions: list[LocalSession] = []

    # Try to find project path from logs.json
    project_path = ""
    logs_file = chats_dir / "logs.json"
    if logs_file.is_file():
        try:
            data = json.loads(logs_file.read_text(encoding="utf-8"))
            # logs.json may contain cwd or project root info
            if isinstance(data, dict):
                project_path = data.get("cwd", "")
        except Exception:
            pass

    project_name = Path(project_path).name if project_path else project_dir.name[:12]

    # Scan JSON files in chats/ directory
    for chat_file in chats_dir.glob("*.json"):
        if chat_file.name == "logs.json":
            continue
        try:
            stat = chat_file.stat()
            last_message = None

            # Try to extract last user message from chat JSON
            try:
                data = json.loads(chat_file.read_text(encoding="utf-8"))
                messages = []
                if isinstance(data, list):
                    messages = data
                elif isinstance(data, dict):
                    messages = data.get("messages", [])
                    if not project_path:
                        project_path = data.get("cwd", "")

                for msg in reversed(messages):
                    if msg.get("role") == "user":
                        content = msg.get("content", "")
                        if isinstance(content, list):
                            content = " ".join(
                                p.get("text", "") for p in content if isinstance(p, dict)
                            )
                        text = str(content).strip()
                        if text:
                            last_message = text[:200]
                            break
            except Exception:
                pass

            sessions.append(
                LocalSession(
                    session_id=chat_file.stem,
                    project=project_name,
                    project_path=project_path,
                    cli="gemini",
                    last_message=last_message,
                    updated_at=datetime.fromtimestamp(stat.st_mtime, tz=UTC),
                )
            )
        except Exception:
            continue

    return sessions


def scan_gemini_sessions() -> list[LocalSession]:
    if not GEMINI_DIR.is_dir():
        return []

    sessions: list[LocalSession] = []

    for project_dir in GEMINI_DIR.iterdir():
        if not project_dir.is_dir():
            continue
        try:
            sessions.extend(_parse_gemini_project(project_dir))
        except Exception:
            continue

    return sessions
