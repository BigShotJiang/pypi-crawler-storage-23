from __future__ import annotations

from datetime import UTC, datetime

from am.scanners.claude import scan_claude_sessions
from am.scanners.codex import scan_codex_sessions
from am.scanners.gemini import scan_gemini_sessions
from am.schemas.session import LocalSession


def scan_all_sessions() -> list[LocalSession]:
    """Scan all supported CLI tools and return merged session list."""
    sessions: list[LocalSession] = []
    sessions.extend(scan_claude_sessions())
    sessions.extend(scan_codex_sessions())
    sessions.extend(scan_gemini_sessions())
    sessions.sort(
        key=lambda s: s.updated_at or datetime.min.replace(tzinfo=UTC),
        reverse=True,
    )
    return sessions
