"""Agent Manager CLI — Node Agent, daemon, session scanner."""

__version__ = "0.1.1"
