"""Tests for stream event mapping."""

import json

from am.cli import map_stream_event


class TestSystemEvents:
    def test_system_init(self):
        line = json.dumps(
            {
                "type": "system",
                "subtype": "init",
                "session_id": "abc-123",
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "status"
        assert events[0]["data"]["status"] == "running"
        assert events[0]["data"]["session_id"] == "abc-123"

    def test_system_non_init_ignored(self):
        line = json.dumps({"type": "system", "subtype": "other"})
        assert map_stream_event(line) == []


class TestAssistantEvents:
    def test_text_block(self):
        line = json.dumps(
            {
                "type": "assistant",
                "message": {
                    "content": [{"type": "text", "text": "Hello world"}],
                },
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "text"
        assert events[0]["data"]["text"] == "Hello world"

    def test_thinking_block(self):
        line = json.dumps(
            {
                "type": "assistant",
                "message": {
                    "content": [{"type": "thinking", "thinking": "Let me think..."}],
                },
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "thinking"
        assert events[0]["data"]["text"] == "Let me think..."

    def test_tool_use_block(self):
        line = json.dumps(
            {
                "type": "assistant",
                "message": {
                    "content": [
                        {
                            "type": "tool_use",
                            "name": "bash",
                            "input": {"command": "ls"},
                            "id": "tool-1",
                        }
                    ],
                },
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "tool_use"
        assert events[0]["data"]["tool"] == "bash"
        assert events[0]["data"]["input"] == {"command": "ls"}
        assert events[0]["data"]["tool_use_id"] == "tool-1"

    def test_multiple_blocks(self):
        line = json.dumps(
            {
                "type": "assistant",
                "message": {
                    "content": [
                        {"type": "thinking", "thinking": "hmm"},
                        {"type": "text", "text": "result"},
                    ],
                },
            }
        )
        events = map_stream_event(line)
        assert len(events) == 2
        assert events[0]["event_type"] == "thinking"
        assert events[1]["event_type"] == "text"


class TestUserEvents:
    def test_tool_result_string(self):
        line = json.dumps(
            {
                "type": "user",
                "message": {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": "tool-1",
                            "content": "file contents here",
                            "is_error": False,
                        }
                    ],
                },
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "tool_result"
        assert events[0]["data"]["tool_use_id"] == "tool-1"
        assert events[0]["data"]["content"] == "file contents here"
        assert events[0]["data"]["is_error"] is False

    def test_tool_result_list_content(self):
        line = json.dumps(
            {
                "type": "user",
                "message": {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": "tool-2",
                            "content": [
                                {"type": "text", "text": "line 1"},
                                {"type": "text", "text": "line 2"},
                            ],
                        }
                    ],
                },
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["data"]["content"] == "line 1\nline 2"

    def test_tool_result_truncated(self):
        long_content = "x" * 3000
        line = json.dumps(
            {
                "type": "user",
                "message": {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": "t",
                            "content": long_content,
                        }
                    ],
                },
            }
        )
        events = map_stream_event(line)
        assert len(events[0]["data"]["content"]) == 2000


class TestResultEvents:
    def test_success(self):
        line = json.dumps(
            {
                "type": "result",
                "subtype": "success",
                "total_cost_usd": 0.05,
                "duration_ms": 12000,
                "num_turns": 3,
                "session_id": "sess-1",
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "status"
        assert events[0]["data"]["status"] == "completed"
        assert events[0]["data"]["cost_usd"] == 0.05
        assert events[0]["data"]["session_id"] == "sess-1"

    def test_error_result(self):
        line = json.dumps(
            {
                "type": "result",
                "subtype": "error",
                "total_cost_usd": 0.01,
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "error"
        assert "error" in events[0]["data"]["message"]


class TestStreamEvents:
    def test_text_delta(self):
        line = json.dumps(
            {
                "type": "stream_event",
                "event": {"delta": {"type": "text_delta", "text": "hi"}},
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "text"
        assert events[0]["data"]["partial"] is True

    def test_thinking_delta(self):
        line = json.dumps(
            {
                "type": "stream_event",
                "event": {"delta": {"type": "thinking_delta", "thinking": "..."}},
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "thinking"
        assert events[0]["data"]["partial"] is True


class TestInputRequest:
    def test_permission_request(self):
        line = json.dumps(
            {
                "type": "input_request",
                "request_type": "permission",
                "tool_name": "bash",
                "tool_input": {"command": "rm -rf /"},
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["event_type"] == "input_request"
        assert events[0]["data"]["request_type"] == "permission"
        assert events[0]["data"]["tool_name"] == "bash"

    def test_question_request(self):
        line = json.dumps(
            {
                "type": "input_request",
                "request_type": "question",
                "questions": [{"text": "Continue?"}],
            }
        )
        events = map_stream_event(line)
        assert len(events) == 1
        assert events[0]["data"]["questions"] == [{"text": "Continue?"}]


class TestEdgeCases:
    def test_invalid_json(self):
        assert map_stream_event("not json") == []

    def test_empty_string(self):
        assert map_stream_event("") == []

    def test_unknown_type(self):
        line = json.dumps({"type": "unknown_event"})
        assert map_stream_event(line) == []

    def test_empty_content_blocks(self):
        line = json.dumps(
            {
                "type": "assistant",
                "message": {"content": []},
            }
        )
        assert map_stream_event(line) == []
