# Agent Manager CLI

CLI-клиент для удалённого управления AI-агентами. Работает в паре с сервером [Agent Control](https://agent-manager.space).

## Что это

**Node Agent** — процесс на вашем компьютере, который:
1. Сканирует локальные CLI-сессии (Claude Code, Codex, Gemini)
2. Отправляет список сессий на сервер
3. Получает команды от сервера («подключись к сессии X»)
4. Запускает daemon для стриминга событий в дашборд

```
Ваш компьютер                         Сервер
$ am login                      →     авторизация
$ am connect                    →     WS /ws/node (постоянное)
  сканирует ~/.claude/ и т.д.   →     список сессий → Redis

Телефон: "+ Агент" → "Подключить"
  Сервер                        →     {"type":"attach",...}
  Node запускает daemon         →     WS /ws/daemon (стрим)
```

## Установка

```bash
pip install agent-manager-cli
```

Или через uv:

```bash
uv tool install agent-manager-cli
```

## Быстрый старт

### 1. Авторизация

```bash
am login
```

Запросит email и пароль. Сохраняет токены в `~/.agentmanager/config.json`.

По умолчанию подключается к `agent-manager.space` по HTTPS. Для локальной разработки:

```bash
am login --host localhost:8000 --email user@test.com --password pass
```

### 2. Запуск Node Agent

```bash
am connect
```

Node Agent:
- Подключается к серверу через WebSocket
- Сканирует сессии каждые 30 секунд
- Отправляет heartbeat каждые 25 секунд
- Слушает команды `attach` от сервера

После запуска в дашборде появится статус «Node Agent онлайн» и список ваших сессий.

### 3. Подключение сессии

В дашборде: **+ Агент** → **Подключить сессию** → выберите сессию → **Подключить**.

Node Agent автоматически запустит daemon, и стрим появится в дашборде.

## Ручной режим (daemon)

Можно запустить daemon напрямую, без Node Agent:

```bash
am daemon --token <DAEMON_TOKEN> -- \
    claude --continue --resume <SESSION_ID> \
    --output-format stream-json \
    --input-format stream-json
```

Pipe-режим (только чтение, без двустороннего ввода):

```bash
claude -p "task" --output-format stream-json | am daemon --token <TOKEN>
```

## Команды

| Команда | Описание |
|---------|----------|
| `am login` | Авторизация на сервере |
| `am connect` | Запуск Node Agent |
| `am daemon` | Запуск daemon для конкретной сессии |

### am login

```
am login --host <HOST> [--email <EMAIL>] [--password <PASS>] [--secure]
```

| Флаг | Описание |
|------|----------|
| `--host` | Адрес сервера (по умолчанию `agent-manager.space`) |
| `--email` | Email (запросит, если не указан) |
| `--password` | Пароль (запросит, если не указан) |
| `--secure` | Использовать HTTPS/WSS |

### am connect

```
am connect [--host <HOST>] [--secure]
```

| Флаг | Описание |
|------|----------|
| `--host` | Переопределить сохранённый хост |
| `--secure` | Использовать WSS |

### am daemon

```
am daemon --token <TOKEN> [--host <HOST>] [--secure] [--no-followup] [-- <CLI_COMMAND>]
```

| Флаг | Описание |
|------|----------|
| `--token` | Daemon JWT токен (обязательно) |
| `--host` | Адрес сервера (по умолчанию `localhost:8000`) |
| `--secure` | Использовать WSS |
| `--no-followup` | Не ждать follow-up сообщений |

## Поддерживаемые CLI

| CLI | Директория сессий | Формат |
|-----|-------------------|--------|
| Claude Code | `~/.claude/projects/` | JSONL |
| Codex | `~/.codex/sessions/` | JSONL |
| Gemini | `~/.gemini/tmp/` | JSON |

## Конфигурация

Токены и настройки хранятся в `~/.agentmanager/config.json`:

```json
{
  "host": "agent-manager.space",
  "secure": true,
  "access_token": "...",
  "refresh_token": "..."
}
```

## Требования

- Python 3.11+
- Зависимости: `websockets`, `pydantic`

## Разработка

```bash
git clone <repo>
cd am-cli
uv sync
uv run am --help
uv run pytest
uv run ruff check .
```

## Лицензия

MIT
