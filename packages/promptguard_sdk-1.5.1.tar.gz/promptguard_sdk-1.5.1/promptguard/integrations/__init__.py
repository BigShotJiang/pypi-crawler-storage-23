"""
Framework-specific integrations for PromptGuard.

These provide deeper integration than auto-instrumentation by hooking
into framework callback / lifecycle systems for richer context (chain
names, tool calls, agent steps, multi-turn tracking).
"""
