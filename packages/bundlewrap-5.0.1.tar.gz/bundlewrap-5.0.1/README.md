BundleWrap is a decentralized configuration management system that is designed to be powerful, easy to extend and extremely versatile.

For more information, have a look at [bundlewrap.org](https://bundlewrap.org) and [docs.bundlewrap.org](https://docs.bundlewrap.org).

------------------------------------------------------------------------

<a href="https://pypi.python.org/pypi/bundlewrap/">
    <img src="http://img.shields.io/pypi/v/bundlewrap.svg" alt="Latest Version">
</a>
&nbsp;
<a href="https://github.com/bundlewrap/bundlewrap/actions">
    <img src="https://github.com/bundlewrap/bundlewrap/workflows/Tests/badge.svg" alt="Build status">
</a>
&nbsp;
<a href="https://pypi.python.org/pypi/bundlewrap/">
    <img src="http://img.shields.io/pypi/pyversions/bundlewrap.svg" alt="Python compatibility">
</a>
&nbsp;
<a href="https://deepsource.io/gh/bundlewrap/bundlewrap/">
    <img src="https://deepsource.io/gh/bundlewrap/bundlewrap.svg/?label=DeepSource&show_trend=true" alt="DeepSource">
</a>

------------------------------------------------------------------------

BundleWrap is © 2013 - 2026 [Torsten Rehn](mailto:torsten@rehn.email)
