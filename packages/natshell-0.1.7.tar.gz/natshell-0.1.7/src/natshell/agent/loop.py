"""Core ReAct agent loop — plans, executes tools, observes, repeats."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, AsyncIterator

from natshell.agent.context import SystemContext
from natshell.agent.context_manager import ContextManager
from natshell.agent.system_prompt import build_system_prompt
from natshell.config import AgentConfig, ModelConfig
from natshell.inference.engine import CompletionResult, InferenceEngine, ToolCall
from natshell.safety.classifier import Risk, SafetyClassifier
from natshell.tools import execute_shell as _exec_shell_mod
from natshell.tools import read_file as _read_file_mod
from natshell.tools.execute_shell import needs_sudo_password as _needs_sudo_password
from natshell.tools.registry import ToolRegistry, ToolResult

logger = logging.getLogger(__name__)


class EventType(Enum):
    THINKING = "thinking"
    PLANNING = "planning"  # Model's text before tool calls
    EXECUTING = "executing"  # About to run a tool
    TOOL_RESULT = "tool_result"  # Result from a tool
    CONFIRM_NEEDED = "confirm_needed"  # Awaiting user confirmation
    BLOCKED = "blocked"  # Command was blocked
    RESPONSE = "response"  # Final text response from model
    ERROR = "error"  # Something went wrong
    RUN_STATS = "run_stats"  # Cumulative stats for the full agent run
    PLAN_STEP = "plan_step"  # Plan step divider (start/update)
    PLAN_COMPLETE = "plan_complete"  # Entire plan finished


@dataclass
class AgentEvent:
    """An event yielded by the agent loop for the TUI to render."""

    type: EventType
    data: Any = None
    tool_call: ToolCall | None = None
    tool_result: ToolResult | None = None
    metrics: dict[str, Any] | None = None


def _build_metrics(result: CompletionResult, elapsed_ms: int) -> dict[str, Any]:
    """Build a metrics dict from inference result and timing."""
    metrics: dict[str, Any] = {"response_time_ms": elapsed_ms}
    if result.completion_tokens:
        metrics["completion_tokens"] = result.completion_tokens
        if elapsed_ms > 0:
            metrics["tokens_per_sec"] = result.completion_tokens / (elapsed_ms / 1000)
    if result.prompt_tokens:
        metrics["prompt_tokens"] = result.prompt_tokens
    return metrics


def _build_run_stats(
    steps: int,
    total_wall_ms: int,
    total_inference_ms: int,
    total_prompt_tokens: int,
    total_completion_tokens: int,
) -> dict[str, Any]:
    """Build cumulative stats for an entire agent run."""
    stats: dict[str, Any] = {
        "steps": steps,
        "total_wall_ms": total_wall_ms,
        "total_inference_ms": total_inference_ms,
        "total_prompt_tokens": total_prompt_tokens,
        "total_completion_tokens": total_completion_tokens,
    }
    total_tokens = total_prompt_tokens + total_completion_tokens
    if total_tokens:
        stats["total_tokens"] = total_tokens
    if total_inference_ms > 0 and total_completion_tokens:
        stats["avg_tokens_per_sec"] = total_completion_tokens / (total_inference_ms / 1000)
    return stats


class AgentLoop:
    """The ReAct agent loop — the brain of NatShell."""

    def __init__(
        self,
        engine: InferenceEngine,
        tools: ToolRegistry,
        safety: SafetyClassifier,
        config: AgentConfig,
        fallback_config: ModelConfig | None = None,
    ) -> None:
        self.engine = engine
        self.tools = tools
        self.safety = safety
        self.config = config
        self.fallback_config = fallback_config
        self._system_context: SystemContext | None = None
        self.messages: list[dict[str, Any]] = []
        self._context_manager: ContextManager | None = None
        self._max_tokens: int = config.max_tokens

    def initialize(self, system_context: SystemContext) -> None:
        """Build the system prompt and initialize conversation."""
        self._system_context = system_context
        system_prompt = build_system_prompt(system_context)
        self.messages = [{"role": "system", "content": system_prompt}]
        self._setup_context_manager()

    async def swap_engine(self, new_engine: InferenceEngine) -> None:
        """Replace the inference engine at runtime. Clears conversation history."""
        old_engine = self.engine
        self.engine = new_engine
        self.clear_history()
        if self._system_context:
            self.initialize(self._system_context)
        if hasattr(old_engine, "close"):
            await old_engine.close()

    def _effective_max_tokens(self, n_ctx: int) -> int:
        """Scale max_tokens based on context window size.

        Uses 25% of the context window (capped at 65536), with the configured
        value as a minimum floor.  This gives small local models their current
        behaviour while providing remote/large models proper output headroom.
        """
        return max(self.config.max_tokens, min(n_ctx // 4, 65536))

    _DEFAULT_MAX_STEPS = 15

    def _effective_max_steps(self, n_ctx: int) -> int:
        """Scale max_steps based on context window size.

        Larger models with bigger context windows handle more complex multi-step
        tasks.  Only auto-scales when the configured value is the default (15);
        an explicit user override is respected as-is.
        """
        if self.config.max_steps != self._DEFAULT_MAX_STEPS:
            return self.config.max_steps
        if n_ctx >= 262144:
            return 75
        elif n_ctx >= 131072:
            return 60
        elif n_ctx >= 32768:
            return 50
        elif n_ctx >= 16384:
            return 35
        elif n_ctx >= 8192:
            return 25
        return self._DEFAULT_MAX_STEPS

    def _effective_max_output_chars(self, n_ctx: int) -> int:
        """Scale shell output truncation with context window."""
        if n_ctx >= 262144:
            return 64000
        elif n_ctx >= 131072:
            return 32000
        elif n_ctx >= 65536:
            return 16000
        elif n_ctx >= 32768:
            return 12000
        elif n_ctx >= 16384:
            return 8000
        return 4000

    def _effective_read_file_lines(self, n_ctx: int) -> int:
        """Scale read_file default line count with context window."""
        if n_ctx >= 262144:
            return 4000
        elif n_ctx >= 131072:
            return 2000
        elif n_ctx >= 65536:
            return 1000
        elif n_ctx >= 32768:
            return 500
        elif n_ctx >= 16384:
            return 300
        return 200

    def _setup_context_manager(self) -> None:
        """Create a ContextManager sized to the current engine's context window."""
        try:
            info = self.engine.engine_info()
            n_ctx = info.n_ctx or 4096
        except (AttributeError, TypeError):
            # Gracefully handle mock engines or engines without engine_info
            n_ctx = 4096

        self._max_tokens = self._effective_max_tokens(n_ctx)
        self._max_steps = self._effective_max_steps(n_ctx)

        # Scale tool limits with context window
        _exec_shell_mod.configure_limits(self._effective_max_output_chars(n_ctx))
        _read_file_mod.configure_limits(self._effective_read_file_lines(n_ctx))

        if self._max_tokens != self.config.max_tokens:
            logger.info(
                "Scaled max_tokens %d → %d for %d-token context window",
                self.config.max_tokens,
                self._max_tokens,
                n_ctx,
            )
        if self._max_steps != self.config.max_steps:
            logger.info(
                "Scaled max_steps %d → %d for %d-token context window",
                self.config.max_steps,
                self._max_steps,
                n_ctx,
            )

        response_reserve = self._max_tokens
        tool_reserve = self.config.context_reserve or 400
        budget = n_ctx - response_reserve - tool_reserve
        budget = max(budget, 1024)  # minimum viable budget

        tokenizer_fn = None
        # Only use the tokenizer if it's explicitly defined (not auto-generated by mocks)
        if "count_tokens" in dir(type(self.engine)):
            tokenizer_fn = self.engine.count_tokens

        self._context_manager = ContextManager(
            context_budget=budget,
            tokenizer_fn=tokenizer_fn,
        )

    async def handle_user_message(
        self,
        user_input: str,
        confirm_callback=None,
        password_callback=None,
    ) -> AsyncIterator[AgentEvent]:
        """
        Process a user message through the full agent loop.

        Yields AgentEvent objects for the TUI to render.

        Args:
            user_input: The user's natural language request.
            confirm_callback: An async callable that takes a ToolCall and returns
                            True (confirmed) or False (declined). Required when
                            safety mode is 'confirm'.
            password_callback: An async callable that takes a ToolCall and returns
                            the sudo password (str) or None if cancelled.
        """
        self.messages.append({"role": "user", "content": user_input})

        # Cumulative stats for this run
        run_t0 = time.monotonic()
        total_prompt_tokens = 0
        total_completion_tokens = 0
        total_inference_ms = 0
        steps_used = 0

        max_steps = getattr(self, "_max_steps", self.config.max_steps)
        for step in range(max_steps):
            steps_used = step + 1
            # Signal that the model is thinking
            yield AgentEvent(type=EventType.THINKING)

            # Trim context if needed
            if self._context_manager:
                self.messages = self._context_manager.trim_messages(self.messages)

            # Get model response
            try:
                t0 = time.monotonic()
                result = await self.engine.chat_completion(
                    messages=self.messages,
                    tools=self.tools.get_tool_schemas(),
                    temperature=self.config.temperature,
                    max_tokens=self._max_tokens,
                )
                elapsed_ms = int((time.monotonic() - t0) * 1000)
                total_inference_ms += elapsed_ms
                total_prompt_tokens += result.prompt_tokens or 0
                total_completion_tokens += result.completion_tokens or 0
            except Exception as e:
                logger.exception("Inference error")
                if self._can_fallback(e):
                    fell_back = await self._try_local_fallback()
                    if fell_back:
                        yield AgentEvent(
                            type=EventType.ERROR,
                            data="Remote server unreachable."
                            " Switched to local model. History cleared.",
                        )
                        return
                yield AgentEvent(type=EventType.ERROR, data=f"Inference error: {e}")
                return

            # Handle truncated responses (thinking consumed all tokens)
            if result.finish_reason == "length" and not result.tool_calls:
                raw = result.content or ""
                # Check if content is only <think> residue or empty
                # Strip both closed and unclosed <think> blocks
                stripped = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL)
                stripped = re.sub(
                    r"<think>(?:(?!</think>).)*$", "", stripped, flags=re.DOTALL
                ).strip()
                if stripped:
                    # Partial response — show it but warn the user
                    self.messages.append({"role": "assistant", "content": stripped})
                    yield AgentEvent(
                        type=EventType.RESPONSE,
                        data=stripped,
                        metrics=_build_metrics(result, elapsed_ms),
                    )
                    yield AgentEvent(
                        type=EventType.ERROR,
                        data="Response was truncated (hit token limit). "
                        "The context window may be full. Try /clear to reset.",
                    )
                    if steps_used > 1:
                        run_wall_ms = int((time.monotonic() - run_t0) * 1000)
                        yield AgentEvent(
                            type=EventType.RUN_STATS,
                            metrics=_build_run_stats(
                                steps_used,
                                run_wall_ms,
                                total_inference_ms,
                                total_prompt_tokens,
                                total_completion_tokens,
                            ),
                        )
                    return
                else:
                    yield AgentEvent(
                        type=EventType.ERROR,
                        data="Response was truncated — the model used all"
                        " available tokens without producing a complete"
                        " response. Try a simpler request or /clear to reset.",
                    )
                    return

            # Case 1: Model wants to call tools
            if result.tool_calls:
                # If the model also provided text (planning/reasoning), emit it
                if result.content:
                    yield AgentEvent(type=EventType.PLANNING, data=result.content)

                for tool_call in result.tool_calls:
                    # Safety classification
                    risk = self.safety.classify_tool_call(tool_call.name, tool_call.arguments)

                    if risk == Risk.BLOCKED:
                        yield AgentEvent(type=EventType.BLOCKED, tool_call=tool_call)
                        self._append_tool_exchange(
                            tool_call,
                            "BLOCKED: This command was blocked by the safety classifier. "
                            "Try an alternative approach.",
                        )
                        continue

                    if risk == Risk.CONFIRM and confirm_callback:
                        yield AgentEvent(type=EventType.CONFIRM_NEEDED, tool_call=tool_call)
                        confirmed = await confirm_callback(tool_call)
                        if not confirmed:
                            self._append_tool_exchange(
                                tool_call,
                                "DECLINED: The user declined to execute this command.",
                            )
                            continue

                    # Restart thinking animation before execution
                    yield AgentEvent(type=EventType.THINKING)
                    # Execute the tool
                    yield AgentEvent(type=EventType.EXECUTING, tool_call=tool_call)

                    tool_result = await self.tools.execute(tool_call.name, tool_call.arguments)

                    # If sudo needs a password, prompt the user and retry
                    if (
                        tool_call.name == "execute_shell"
                        and password_callback
                        and _needs_sudo_password(tool_result)
                    ):
                        password = await password_callback(tool_call)
                        if password:
                            from natshell.tools.execute_shell import set_sudo_password

                            set_sudo_password(password)
                            yield AgentEvent(type=EventType.THINKING)
                            tool_result = await self.tools.execute(
                                tool_call.name, tool_call.arguments
                            )

                    yield AgentEvent(
                        type=EventType.TOOL_RESULT,
                        tool_call=tool_call,
                        tool_result=tool_result,
                    )

                    # Append exchange to conversation history
                    self._append_tool_exchange(tool_call, tool_result.to_message_content())

                # Continue the loop — model will see tool results and decide next step
                continue

            # Case 2: Model responded with text only (task complete or needs info)
            if result.content:
                self.messages.append(
                    {
                        "role": "assistant",
                        "content": result.content,
                    }
                )
                yield AgentEvent(
                    type=EventType.RESPONSE,
                    data=result.content,
                    metrics=_build_metrics(result, elapsed_ms),
                )
                if steps_used > 1:
                    run_wall_ms = int((time.monotonic() - run_t0) * 1000)
                    yield AgentEvent(
                        type=EventType.RUN_STATS,
                        metrics=_build_run_stats(
                            steps_used,
                            run_wall_ms,
                            total_inference_ms,
                            total_prompt_tokens,
                            total_completion_tokens,
                        ),
                    )
                return

            # Case 3: Empty response (shouldn't happen, but handle gracefully)
            yield AgentEvent(
                type=EventType.ERROR,
                data="Model returned an empty response.",
            )
            return

        # Hit max steps
        run_wall_ms = int((time.monotonic() - run_t0) * 1000)
        yield AgentEvent(
            type=EventType.RESPONSE,
            data=f"I've reached the maximum number of steps ({max_steps}). "
            f"Here's what I've done so far. You can continue with a follow-up request.",
        )
        yield AgentEvent(
            type=EventType.RUN_STATS,
            metrics=_build_run_stats(
                steps_used,
                run_wall_ms,
                total_inference_ms,
                total_prompt_tokens,
                total_completion_tokens,
            ),
        )

    def _can_fallback(self, error: Exception) -> bool:
        """Check if we should attempt fallback to local model."""
        import httpx

        from natshell.inference.remote import RemoteEngine

        if not isinstance(self.engine, RemoteEngine):
            return False
        if self.fallback_config is None:
            return False
        return isinstance(error, (httpx.ConnectError, httpx.ConnectTimeout))

    async def _try_local_fallback(self) -> bool:
        """Attempt to load and swap to the local model. Returns True on success."""
        if self.fallback_config is None:
            return False

        # Resolve model path
        model_path = self.fallback_config.path
        if model_path == "auto":
            model_dir = Path.home() / ".local" / "share" / "natshell" / "models"
            model_path = str(model_dir / self.fallback_config.hf_file)

        if not Path(model_path).exists():
            logger.warning("Local model not found at %s — cannot fall back", model_path)
            return False

        try:
            from natshell.inference.local import LocalEngine

            engine = await asyncio.to_thread(
                LocalEngine,
                model_path=model_path,
                n_ctx=self.fallback_config.n_ctx,
                n_threads=self.fallback_config.n_threads,
                n_gpu_layers=self.fallback_config.n_gpu_layers,
            )
            await self.swap_engine(engine)
            return True
        except Exception:
            logger.exception("Failed to load local model for fallback")
            return False

    def _append_tool_exchange(self, tool_call: ToolCall, result_content: str) -> None:
        """Append a tool call + result pair to the message history."""
        # Assistant message with tool call
        # Use "" instead of None — llama-cpp-python may iterate content and choke on None
        self.messages.append(
            {
                "role": "assistant",
                "content": "",
                "tool_calls": [
                    {
                        "id": tool_call.id,
                        "type": "function",
                        "function": {
                            "name": tool_call.name,
                            "arguments": json.dumps(tool_call.arguments),
                        },
                    }
                ],
            }
        )
        # Tool result message
        self.messages.append(
            {
                "role": "tool",
                "tool_call_id": tool_call.id,
                "content": result_content,
            }
        )

    def clear_history(self) -> None:
        """Clear conversation history, keeping only the system prompt."""
        if self.messages and self.messages[0]["role"] == "system":
            self.messages = [self.messages[0]]
        else:
            self.messages = []

    def compact_history(self) -> dict[str, Any]:
        """Compact conversation history, keeping system prompt and last 2 messages.

        Returns a stats dict with compaction results.
        """
        if len(self.messages) <= 3:
            return {"compacted": False}

        cm = self._context_manager
        before_msgs = len(self.messages)
        before_tokens = cm.estimate_tokens(self.messages) if cm else 0

        system = self.messages[0]

        # Collect non-system messages, keep last 2
        rest = self.messages[1:]
        last_2 = rest[-2:]
        dropped = rest[:-2]

        # Build extractive summary
        summary = ""
        if cm and dropped:
            summary = cm.build_summary(dropped)

        summary_msg: dict[str, Any] = {
            "role": "system",
            "content": (
                f"[Context compacted: {len(dropped)} messages replaced with summary.\n"
                f"{summary}\n"
                "Recent context follows.]"
            ),
        }

        self.messages = [system, summary_msg] + last_2

        after_msgs = len(self.messages)
        after_tokens = cm.estimate_tokens(self.messages) if cm else 0

        return {
            "compacted": True,
            "before_msgs": before_msgs,
            "after_msgs": after_msgs,
            "before_tokens": before_tokens,
            "after_tokens": after_tokens,
            "summary": summary,
        }
