# Changelog

## [0.1.5-mod.03] — Code Quality, Security & Refactor (2026-02-27)

### Code Quality

-   **openai.py:** removed unnecessary `# type: ignore[arg-type]` on line 294
-   **cli.py:** added explanatory comments to bare `except` blocks
-   **picoschema_reverse.py:** removed 3 unused variable assignments
-   **lint:** fixed all 11 Ruff lint issues across the codebase (capitalized docstrings, import ordering, unused variables)

### Features

-   **parse.py:** added `strict: bool = False` parameter to `parse_document()` — when `True`, YAML parse errors raise exceptions instead of being silently ignored
-   **dotprompt.py:** added schema caching in `_wrapped_schema_resolver()` — resolved schemas are stored in `self._schemas` dict to avoid redundant resolution
-   **resolvers.py:** improved error handling with descriptive messages in resolver wrappers

### Security

-   **google.py:** added `_validate_save_path()` to prevent path traversal attacks (CWE-22) on image `save_path` — rejects absolute paths and `..` components

### Refactoring

-   **adapters/_base.py:** extracted shared `parse_data_uri()` helper function for parsing `data:` URI strings into `(mime_type, data_bytes)` tuples
-   **anthropic.py, google.py:** refactored to use `parse_data_uri()` instead of inline data URI parsing, reducing code duplication
-   **adapters/__init__.py:** replaced lazy-loading registry with direct imports — SDK packages are now core dependencies

### Resolved TODOs

-   **dotprompt.py:** resolved 4 TODO markers — schema caching, `_wrapped_schema_resolver` error handling, `_resolve_json_schema` caching, `_render_picoschema` error propagation
-   **resolvers.py:** resolved 2 TODO markers — sync/async resolver error handling improvements

### Dependencies

-   **pyproject.toml:** `openai`, `anthropic`, and `google-genai` are now **required** core dependencies (previously optional extras); removed `[project.optional-dependencies]` section entirely

### Tests

-   added 37 new tests (471 → **508 total**): CLI helpers (`cli_test.py`), `parse_data_uri` (`base_test.py`), `_validate_save_path` and media part conversion (`google_test.py`), `__main__.py` entry point (`test_main.py`)

### Documentation

-   **README.md:** updated install instructions (removed `[all]` extra), updated Supported Adapters table (removed "Install Extra" column), added `save_path` security note

### Changed Files Summary

| File | Status | Description |
|------|--------|-------------|
| `src/dotpromptz/adapters/__init__.py` | **Modified** | Direct imports instead of lazy loading |
| `src/dotpromptz/adapters/_base.py` | **Modified** | Added `parse_data_uri()` helper |
| `src/dotpromptz/adapters/openai.py` | **Modified** | Removed `type: ignore`, added docstring |
| `src/dotpromptz/adapters/anthropic.py` | **Modified** | Refactored to use `parse_data_uri()` |
| `src/dotpromptz/adapters/google.py` | **Modified** | Added `_validate_save_path()`, refactored data URI parsing |
| `src/dotpromptz/parse.py` | **Modified** | Added `strict` parameter to `parse_document()` |
| `src/dotpromptz/cli.py` | **Modified** | Added comments to `except` blocks, capitalized docstring |
| `src/dotpromptz/picoschema_reverse.py` | **Modified** | Removed unused variable assignments |
| `src/dotpromptz/dotprompt.py` | **Modified** | Resolved 4 TODOs, added schema caching |
| `src/dotpromptz/resolvers.py` | **Modified** | Resolved 2 TODOs |
| `src/dotpromptz/__init__.py` | **Modified** | Fixed `__all__` format |
| `pyproject.toml` | **Modified** | SDK deps required; removed optional-dependencies |
| `tests/dotpromptz/cli_test.py` | **Modified** | +20 new test methods |
| `tests/dotpromptz/adapters/base_test.py` | **Modified** | +7 `TestParseDataUri` tests |
| `tests/dotpromptz/adapters/google_test.py` | **Modified** | +7 tests (save_path validation, media conversion) |
| `tests/dotpromptz/test_main.py` | **New** | 3 tests for `__main__.py` entry point |
| `README.md` | **Modified** | Updated install instructions and adapter table |


## \[0.1.5-mod.02\] — Model Field Deprecation & Adapter Refactor (2026-02-27)

### Breaking Changes

-   **adapters:** `to_openai_request()`, `to_anthropic_request()`, and `to_genai_request()` no longer accept a `model` parameter — the model name is now resolved from `config['model']` or `rendered.model` (deprecated fallback)
-   **frontmatter:** top-level `model` field in `.prompt` frontmatter is deprecated; use `adapter` for adapter/provider selection and `config.model` for the LLM model name

### Features

-   **adapters/_base:** add `_ensure_model()` method to `Adapter` ABC — injects `_default_model` into `config['model']` when no model is found in the rendered prompt
-   **dotprompt:** add `_resolve_model_name()` static method with priority chain: `additional_metadata.config['model']` → `prompt.config['model']` → `additional_metadata.model` (deprecated) → `prompt.model` (deprecated) → `None`
-   **parse:** emit `DeprecationWarning` when top-level `model` is used in frontmatter; automatically populate `adapter` from `model` when `adapter` is not explicitly set

### Changed Files Summary

| File | Status | Description |
|------|--------|-------------|
| `src/dotpromptz/parse.py` | **Modified** | Deprecation warning for top-level `model`; auto-map `model` → `adapter` |
| `src/dotpromptz/dotprompt.py` | **Modified** | Added `_resolve_model_name()` static method |
| `src/dotpromptz/adapters/_base.py` | **Modified** | Added `_ensure_model()` method to Adapter ABC |
| `src/dotpromptz/adapters/openai.py` | **Modified** | Removed `model` param from `to_openai_request()`; `convert()` uses `_ensure_model()` |
| `src/dotpromptz/adapters/anthropic.py` | **Modified** | Removed `model` param from `to_anthropic_request()`; `convert()` uses `_ensure_model()` |
| `src/dotpromptz/adapters/google.py` | **Modified** | Removed `model` param from `to_genai_request()`; `convert()` uses `_ensure_model()` |
| `src/dotpromptz/cli.py` | **Modified** | Dry-run and adapter inference use `config.get('model')` with `rendered.model` fallback |
| `tests/dotpromptz/adapters/openai_test.py` | **Modified** | Tests use `config={'model': ...}` instead of top-level `model` |
| `tests/dotpromptz/adapters/anthropic_test.py` | **Modified** | Tests use `config={'model': ...}` instead of top-level `model` |
| `tests/dotpromptz/adapters/google_test.py` | **Modified** | Tests use `config={'model': ...}` instead of top-level `model` |
| `tests/dotpromptz/parse_test.py` | **Modified** | Updated for deprecation behavior (`model` → `adapter` mapping) |
| `README.md` | **Modified** | Updated examples to new `adapter`/`config.model` convention |
| `USAGE.md` | **Modified** | Updated all examples and architecture docs |

---

## \[0.1.5-mod.01\] — LLM Adapters & CLI (2026-02-26)

### Features

-   **adapters:** add LLM API adapter system with unified `Adapter` ABC, `GenerateResponse`, `Usage`, and `ToolCallResult` models (`adapters/_base.py`)
-   **adapters/openai:** add OpenAI Chat Completions adapter with tool call conversion, and role/content mapping (`adapters/openai.py`)
-   **adapters/anthropic:** add Anthropic Claude Messages API adapter with system message extraction, base64 media support, and tool conversion (`adapters/anthropic.py`)
-   **adapters/google:** add Google (Gemini) adapter with `parts` format, `system_instruction`, and `function_declarations` (`adapters/google.py`)
-   **adapters:** all adapters support `base_url` parameter for third-party compatible endpoints (DeepSeek, vLLM, Ollama, proxies, etc.) via constructor param or env vars (`OPENAI_BASE_URL`, `ANTHROPIC_BASE_URL`, `GOOGLE_BASE_URL`)
-   **adapters/registry:** add lazy adapter registry with `get_adapter()` and `list_adapters()` — SDK packages not imported until first use (`adapters/__init__.py`)
-   **cli:** add `dotprompt run` CLI command (click-based) for running .prompt files from the command line (`cli.py`)
-   **cli:** support `--dry-run` mode to render prompts without API calls, outputting structured JSON
-   **cli:** support `--input` (JSON string) and `--input-file` (JSON file) for template variables
-   **cli:** support `--dry-run`, `--verbose` options
-   **cli:** adapter auto-inferred from frontmatter `adapter` field or model name prefix (e.g. `gpt-4o` → openai, `claude-3` → anthropic, `gemini-2` → google)
-   **cli:** frontmatter supports `adapter` field as string (`adapter: openai`) or full config (`adapter: {name: openai, base_url: ...}`)
-   **cli:** `.env` file auto-loaded from current directory
-   **cli:** add `python -m dotpromptz` entry point (`__main__.py`)
-   **pyproject:** add `[project.scripts]` entry `dotprompt = "dotpromptz.cli:cli"`
-   **pyproject:** add optional dependencies: `[openai]`, `[anthropic]`, `[google]`, `[all]`
-   **pyproject:** add `click>=8.0` and `python-dotenv>=1.0` to core dependencies

### Tests

-   add adapter unit tests: `base_test.py`, `openai_test.py`, `anthropic_test.py`, `google_test.py` (55 tests)
-   add CLI integration tests: `cli_test.py` (7 tests, using subprocess for async-safe testing)
-   total test suite: **433 tests passing**

### Changed Files Summary

| File | Status | Description |
|------------------|---------------------|---------------------------------|
| `src/dotpromptz/adapters/_base.py` | **New** | Adapter ABC, GenerateResponse, Usage, ToolCallResult |
| `src/dotpromptz/adapters/openai.py` | **Modified** | Added conversion functions + OpenAIAdapter class with base_url support |
| `src/dotpromptz/adapters/anthropic.py` | **New** | Anthropic Claude adapter with base_url support |
| `src/dotpromptz/adapters/google.py` | **New** | Google (Gemini) adapter with base_url support |
| `src/dotpromptz/adapters/__init__.py` | **Modified** | Lazy registry + public API |
| `src/dotpromptz/cli.py` | **New** | Click CLI with `dotprompt run` command |
| `src/dotpromptz/__main__.py` | **New** | `python -m dotpromptz` entry |
| `pyproject.toml` | **Modified** | Dependencies, optional-deps, scripts entry |
| `tests/dotpromptz/adapters/__init__.py` | **New** | Test package init |
| `tests/dotpromptz/adapters/base_test.py` | **New** | Base model tests |
| `tests/dotpromptz/adapters/openai_test.py` | **New** | OpenAI adapter tests |
| `tests/dotpromptz/adapters/anthropic_test.py` | **New** | Anthropic adapter tests |
| `tests/dotpromptz/adapters/google_test.py` | **New** | Google adapter tests |
| `tests/dotpromptz/cli_test.py` | **New** | CLI integration tests |
| `USAGE.md` | **New** | 中文使用教程 |

------------------------------------------------------------------------

## [0.1.5](https://github.com/google/dotprompt/compare/dotpromptz-0.1.4...dotpromptz-0.1.5) (2026-01-30)

### Features

-   integrate pyrefly type checker and improve CI workflows ([#451](https://github.com/google/dotprompt/issues/451)) ([619beaf](https://github.com/google/dotprompt/commit/619beaff845a99e5f2e67fb093fefdfe626e3646))
-   **promptly:** add lsp, fmt, and check implementations ([#438](https://github.com/google/dotprompt/issues/438)) ([27fd3d4](https://github.com/google/dotprompt/commit/27fd3d4c7aa96e09c46cb54546da1783be2f6a6e))
-   **py:** add bazel build/test support and automate requirements ([#399](https://github.com/google/dotprompt/issues/399)) ([efd7fe0](https://github.com/google/dotprompt/commit/efd7fe0592e2491c34e8fd399e756de375c802eb))
-   **py:** switch to using ty for type checking ([#376](https://github.com/google/dotprompt/issues/376)) ([7f1c026](https://github.com/google/dotprompt/commit/7f1c0268e5de5a2d6d887ac590d110dea7d3ed07))

### Bug Fixes

-   add cycle detection to partial resolution across all runtimes ([#431](https://github.com/google/dotprompt/issues/431)) ([4e23d44](https://github.com/google/dotprompt/commit/4e23d44865415c13ab1a5b52c2930e32d26eac5d))
-   compile render issue ([#404](https://github.com/google/dotprompt/issues/404)) ([7152799](https://github.com/google/dotprompt/commit/71527994142de94f7897ce296d31581519e97fe8))
-   **dotpromptz:** clean up pyproject.toml ([#436](https://github.com/google/dotprompt/issues/436)) ([420d05d](https://github.com/google/dotprompt/commit/420d05d9383b1942366010a66745fc7a5b7926bd))
-   **dotpromptz:** enable type-safe schema field in Pydantic models ([#435](https://github.com/google/dotprompt/issues/435)) ([dfc6098](https://github.com/google/dotprompt/commit/dfc6098c161ec49e874b24aefd22d078c7d6870e))
-   **dotpromptz:** update dotpromptz-handlebars dependency to \>=0.1.7 ([#486](https://github.com/google/dotprompt/issues/486)) ([56dedb2](https://github.com/google/dotprompt/commit/56dedb276a6dbf8e5fecb32e3a4d7c4cb5ba0dc8))
-   **dotpromptz:** update dotpromptz-handlebars dependency to \>=0.1.8 ([#492](https://github.com/google/dotprompt/issues/492)) ([cc918b1](https://github.com/google/dotprompt/commit/cc918b19c7ce5af9038aad666861fc3484a0eca2))
-   Ensure helper behavior parity across all runtimes ([#395](https://github.com/google/dotprompt/issues/395)) ([76de7ba](https://github.com/google/dotprompt/commit/76de7ba6065e07667dda5d3acb8b57ce36b48662))
-   path traversal security hardening (CWE-22) ([#413](https://github.com/google/dotprompt/issues/413)) ([5be598e](https://github.com/google/dotprompt/commit/5be598e9dcd617924150500974173fb0dbbc7acf))
-   **release:** consistent naming and auto-publish to pypi on release creation ([#425](https://github.com/google/dotprompt/issues/425)) ([12ba56d](https://github.com/google/dotprompt/commit/12ba56d9135979da21af042a8030daff7a705f87))

### Documentation

-   add comprehensive API documentation for all language implementations ([#454](https://github.com/google/dotprompt/issues/454)) ([f641a62](https://github.com/google/dotprompt/commit/f641a6230aaffc2a422fcaa68ebd5f9a370153ba))

## [0.1.4](https://github.com/google/dotprompt/compare/dotpromptz-v0.1.3...dotpromptz-0.1.4) (2025-12-15)

### Features

-   add implementation of helpers and util modules; move interfaces into dotpromptz project ([#73](https://github.com/google/dotprompt/issues/73)) ([8c7aea1](https://github.com/google/dotprompt/commit/8c7aea1faffaf823d01b132e55cb175a4fca5ccb))
-   add stub spec_test.py and script to monitor tests. ([#138](https://github.com/google/dotprompt/issues/138)) ([65966e9](https://github.com/google/dotprompt/commit/65966e9bfc077e85d0b83d04d0384150470dbfd3))
-   **go/parse:** parse.go implementation [#62](https://github.com/google/dotprompt/issues/62) ([#87](https://github.com/google/dotprompt/issues/87)) ([d5dc13c](https://github.com/google/dotprompt/commit/d5dc13c0bf0437875a3b133511ffed474a8b3bf9))
-   parseDocument python ([#80](https://github.com/google/dotprompt/issues/80)) ([82ebc36](https://github.com/google/dotprompt/commit/82ebc3672e8de051dfbdd92968ed3f84c79a247f))
-   partial test runner implementation now loads tests ([#139](https://github.com/google/dotprompt/issues/139)) ([b09dd2f](https://github.com/google/dotprompt/commit/b09dd2f9b8029317ce484d6f32d5a3fb89f5f7e1))
-   Port JS types to Python ([#65](https://github.com/google/dotprompt/issues/65)) ([edcb037](https://github.com/google/dotprompt/commit/edcb03765f3cb6e5743d107a35cf255a60ab0369))
-   **py/dotprompt:** render and compile implementations ([#263](https://github.com/google/dotprompt/issues/263)) ([961d0db](https://github.com/google/dotprompt/commit/961d0dbbd9c2ce522252bc3d92f6dde4b7fe9cc1))
-   **py/dotpromptz:** \_resolve_metadata for dotprompt ([#226](https://github.com/google/dotprompt/issues/226)) ([cfcc87b](https://github.com/google/dotprompt/commit/cfcc87b57e49785c2356b03fbc5b7bf773472683))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_json_schema implementation ([#217](https://github.com/google/dotprompt/issues/217)) ([0b62136](https://github.com/google/dotprompt/commit/0b621363a394c6b5c0fac6a957098eccff6891ca))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_partials implementation ([#215](https://github.com/google/dotprompt/issues/215)) ([03a161c](https://github.com/google/dotprompt/commit/03a161c3440a680bc0df472f35efa155fe0d5151))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_tools implementation and raise ValueError when resolver is None ([#214](https://github.com/google/dotprompt/issues/214)) ([57caf5d](https://github.com/google/dotprompt/commit/57caf5d9a9f4fe720c67f99fd10439d5ebe434dc))
-   **py/dotpromptz:** add resolve_json_schema and test case for ResolverCallable that returns an asyncio.Future ([#211](https://github.com/google/dotprompt/issues/211)) ([7bbe80d](https://github.com/google/dotprompt/commit/7bbe80d6a1d9dc18c4d1baacfccf2f33fc8b7e26))
-   **py/dotpromptz:** add resolvers module ([#207](https://github.com/google/dotprompt/issues/207)) ([826f257](https://github.com/google/dotprompt/commit/826f2572e710cebd0138bd757d2bef2e4898d730))
-   **py/dotpromptz:** because the Picoschema parser can resolve schemas at runtime, we make it an async implementation ([#220](https://github.com/google/dotprompt/issues/220)) ([ae285a8](https://github.com/google/dotprompt/commit/ae285a88f3502e0a02c85d04c49c2e2e6ef88766))
-   **py/dotpromptz:** configure handlebars to not escape by default ([#163](https://github.com/google/dotprompt/issues/163)) ([f7c33e1](https://github.com/google/dotprompt/commit/f7c33e1303476fd473e803f930ac1e1f9e1d87c9))
-   **py/dotpromptz:** construct test-specific dotprompt instance with partials and partial resolver set up ([#275](https://github.com/google/dotprompt/issues/275)) ([0af9a64](https://github.com/google/dotprompt/commit/0af9a64acf50278bdffda337e19c66fbb97e43a3))
-   **py/dotpromptz:** directory-based async and sync implementations of PromptStore and PromptStoreWritable ([#164](https://github.com/google/dotprompt/issues/164)) ([ac92fbf](https://github.com/google/dotprompt/commit/ac92fbf3af7ac3207102c94c20d294d8c54b9dd4))
-   **py/dotpromptz:** Dotprompt.{render\|compile} with CompileRenderer stub ([#248](https://github.com/google/dotprompt/issues/248)) ([61c578c](https://github.com/google/dotprompt/commit/61c578cf43ac490f8076306a8e2b5eb0ae15f385))
-   **py/dotpromptz:** implement helpers in terms of the rust implementation of handlebars-rust and fix go flakiness ([#115](https://github.com/google/dotprompt/issues/115)) ([314c0b5](https://github.com/google/dotprompt/commit/314c0b5182aaad25bf4cfccb8207faa60f63256f))
-   **py/dotpromptz:** initial bits of Dotprompt class ([#148](https://github.com/google/dotprompt/issues/148)) ([90f7838](https://github.com/google/dotprompt/commit/90f78384a958d41d78dee48497a78dfde11f4476))
-   **py/dotpromptz:** render_metadata implementation and associated tests ([#229](https://github.com/google/dotprompt/issues/229)) ([e66dc45](https://github.com/google/dotprompt/commit/e66dc453c718222e1633be951923a35335296dd5))
-   **py/dotpromptz:** simpler spec test runner harness ([#266](https://github.com/google/dotprompt/issues/266)) ([89378bf](https://github.com/google/dotprompt/commit/89378bfded004f3b246c90f6474c2fb972037956))
-   **py/dotpromptz:** test harness that creates suites and test case methods dynamically ([#279](https://github.com/google/dotprompt/issues/279)) ([1dc2bda](https://github.com/google/dotprompt/commit/1dc2bdac5de513cb41d32905d20069ab29307a72))
-   **py/dotpromptz:** translate render_metadata for dotprompt.py from ts ([#227](https://github.com/google/dotprompt/issues/227)) ([ae1919b](https://github.com/google/dotprompt/commit/ae1919b3457824241c734fdf8328f61279fb6710))
-   **py/dotpromptz:** use async picoschema_to_json_schema in dotprompt.\_render_picoschema ([#221](https://github.com/google/dotprompt/issues/221)) ([072d95d](https://github.com/google/dotprompt/commit/072d95deb01d9b09a7f60d9f6b3fb53a8067e497))
-   **py:** add SafeString implementation that works with js2py ([#104](https://github.com/google/dotprompt/issues/104)) ([1ebeca3](https://github.com/google/dotprompt/commit/1ebeca3976faf2dc91d8d7f4a74c218824aac353))
-   **py:** add support for python 3.14 ([#365](https://github.com/google/dotprompt/issues/365)) ([53db722](https://github.com/google/dotprompt/commit/53db722352d360c9097028d63eb1b7e9576d3d24))
-   **py:** fix picoschema spec test ([#303](https://github.com/google/dotprompt/issues/303)) ([73439c1](https://github.com/google/dotprompt/commit/73439c183f557d7bb67b9cbc060e5602c219fc68))
-   **py:** implement identify_partials in terms of regexps since we do not have an AST to walk [#90](https://github.com/google/dotprompt/issues/90) ([#150](https://github.com/google/dotprompt/issues/150)) ([f802275](https://github.com/google/dotprompt/commit/f8022755d7eef716bbb54dd08a2c3a061250d393))
-   **py:** implementation of parse.py; refactor parse.ts and update tests. ([#79](https://github.com/google/dotprompt/issues/79)) ([47e7245](https://github.com/google/dotprompt/commit/47e7245c0aae710b102178019d1f3449c2f1af66))
-   **py:** local variables support workaround ([#318](https://github.com/google/dotprompt/issues/318)) ([d09598b](https://github.com/google/dotprompt/commit/d09598b969d5dbeaed3ca4136e903b4a2dc80531))
-   python implementations of helpers ([#129](https://github.com/google/dotprompt/issues/129)) ([79c6ef3](https://github.com/google/dotprompt/commit/79c6ef3e9cc472fed3a832c00a1515ceef0981da))
-   python: implement spec test logic ([#285](https://github.com/google/dotprompt/issues/285)) ([944f1fe](https://github.com/google/dotprompt/commit/944f1fee3e0e1f4f8bcd3c9bc4f6104ffbe17f2c))
-   python: picoschema support ISSUE: [#36](https://github.com/google/dotprompt/issues/36) CHANGELOG: - \[x\] Port relevant functionality - \[x\] Add tests ([#95](https://github.com/google/dotprompt/issues/95)) ([0da188c](https://github.com/google/dotprompt/commit/0da188c52540f041309e39fa6bc798eaf7fd7a81))
-   **python:** add OpenAI adapter implementation for dotprompt [#38](https://github.com/google/dotprompt/issues/38) ([#97](https://github.com/google/dotprompt/issues/97)) ([d171f87](https://github.com/google/dotprompt/commit/d171f8792ecf08f446e18ea3bbd5309cafa1d8a3))
-   **python:** support lower versions of python (\>=3.10) ([#187](https://github.com/google/dotprompt/issues/187)) ([4240f9d](https://github.com/google/dotprompt/commit/4240f9d720891e350f9116aa4401ce6ea7fac5a3))
-   **py:** utility function to unquote a string literal coming from js2py handlebars helpers ([#107](https://github.com/google/dotprompt/issues/107)) ([b3672ca](https://github.com/google/dotprompt/commit/b3672ca6192de4895585b28b8bbd301f8294090f))
-   **py:** utility to remove undefined fields from dicts/lists recursively ([#105](https://github.com/google/dotprompt/issues/105)) ([d25c911](https://github.com/google/dotprompt/commit/d25c911bc1e84e5691b961a4c38a8bcd73c80aa0))
-   use the HEAD version of addlicense ([#280](https://github.com/google/dotprompt/issues/280)) ([bdf0d36](https://github.com/google/dotprompt/commit/bdf0d36a430a363de4163f48394546cba884eaaf))

### Bug Fixes

-   change project name for pypi publish ([#200](https://github.com/google/dotprompt/issues/200)) ([2c07132](https://github.com/google/dotprompt/commit/2c0713264fb2c30bdc43f1bd9e51d416f96d1b7e))
-   **docs:** add documentation explaining yaml spec test format and revert typo ([#267](https://github.com/google/dotprompt/issues/267)) ([20cd71b](https://github.com/google/dotprompt/commit/20cd71bd68c9ec28de7264a72d495ff636e62cff))
-   **docs:** update docs for helpers.py functions ([#118](https://github.com/google/dotprompt/issues/118)) ([40f74d4](https://github.com/google/dotprompt/commit/40f74d4cf75a47d8b7f9f85801a1bb5969bae082))
-   **docs:** update helper docs ([#132](https://github.com/google/dotprompt/issues/132)) ([9b84245](https://github.com/google/dotprompt/commit/9b842459e8faa5f4afe7d389deb6c351ab1271be))
-   **go,py:** type fixes and ensure we build/lint the go code in hooks and ci ([#83](https://github.com/google/dotprompt/issues/83)) ([19a8257](https://github.com/google/dotprompt/commit/19a8257f4f73b776229d5324a0366fd9a79c20aa))
-   **helpers:** use ctx instead of hash to get the fn and inverse ([#131](https://github.com/google/dotprompt/issues/131)) ([8749d1f](https://github.com/google/dotprompt/commit/8749d1f78ee754742ae7fcc9247854021178bdbc))
-   **js:** clean up redundant call to register helpers that have already been registered ([#261](https://github.com/google/dotprompt/issues/261)) ([84e3c0c](https://github.com/google/dotprompt/commit/84e3c0cfd8da3b0292eebb2fe8a771fe41d09038))
-   **license:** use the full license header in source code ([#142](https://github.com/google/dotprompt/issues/142)) ([64894ef](https://github.com/google/dotprompt/commit/64894ef898876b861c6c244d522f634cd8fcc842))
-   **py/dotpromptz:** add todo about caching resolved schema for later ([#223](https://github.com/google/dotprompt/issues/223)) ([728dbaa](https://github.com/google/dotprompt/commit/728dbaaef1d0569148426a97242edd1f8064cdbe))
-   **py/dotpromptz:** add unit tests for resolver and fix sync resolver error handling ([#208](https://github.com/google/dotprompt/issues/208)) ([5e04e28](https://github.com/google/dotprompt/commit/5e04e28c99eff0f83c9c8a15df5ef56ff3ebd85f))
-   **py/dotpromptz:** address compatibility with python 3.10 and add tox configuration for parallelized tests ([#188](https://github.com/google/dotprompt/issues/188)) ([d2ba21f](https://github.com/google/dotprompt/commit/d2ba21ff3e54f4ca4328b7e574bb6492699095bc))
-   **py/dotpromptz:** dotprompt.define_tool takes just a tool def ([#224](https://github.com/google/dotprompt/issues/224)) ([72039fc](https://github.com/google/dotprompt/commit/72039fc689d82344bfc1300345059340603404bc))
-   **py/dotpromptz:** ensure parser handles {CR, CRLF, LF} line endings ([#256](https://github.com/google/dotprompt/issues/256)) ([18cff7a](https://github.com/google/dotprompt/commit/18cff7af50860c46fb37a2fa9c373bd410f11701))
-   **py/dotpromptz:** fix broken picoschema parser tests ([#232](https://github.com/google/dotprompt/issues/232)) ([4d154aa](https://github.com/google/dotprompt/commit/4d154aaae99f2f31500d86ed6191a05298700b91))
-   **py/dotpromptz:** fix pydantic warnings and tabulate the various types in typing.py ([#196](https://github.com/google/dotprompt/issues/196)) ([24dcfdd](https://github.com/google/dotprompt/commit/24dcfdd320884452ee48fca859619b400fe61327))
-   **py/dotpromptz:** make resolver concrete in resolve, resolve_tool, and resolve_partial ([#210](https://github.com/google/dotprompt/issues/210)) ([3730190](https://github.com/google/dotprompt/commit/37301903c8f26f1b8363ad1f2d515a6df19303e2))
-   **py/dotpromptz:** pyyaml is a runtime dependency; also update dotpromptz-handlebars to 0.1.3 ([#369](https://github.com/google/dotprompt/issues/369)) ([d9132b3](https://github.com/google/dotprompt/commit/d9132b3172eef7060081306e09107a0b33b5420a))
-   **py/dotpromptz:** register initial helpers and partials correctly ([#260](https://github.com/google/dotprompt/issues/260)) ([0752865](https://github.com/google/dotprompt/commit/0752865b415c6cc90c87e3113b537632a52e3423))
-   **py/dotpromptz:** registering partials and start rendering some specs ([#269](https://github.com/google/dotprompt/issues/269)) ([aff3c4b](https://github.com/google/dotprompt/commit/aff3c4b9ee548e61268ca070f6660d51c860619d))
-   **py/dotpromptz:** remove stray reference to inspect.isasyncgenfunction since we dont deal with those as resolvers ([#216](https://github.com/google/dotprompt/issues/216)) ([c300515](https://github.com/google/dotprompt/commit/c3005159aea0af906e3f704d03fd5859a9540d4f))
-   **py/dotpromptz:** remove unused Options type from dotprompt.py and fix typo ([#213](https://github.com/google/dotprompt/issues/213)) ([ae59431](https://github.com/google/dotprompt/commit/ae5943179e77aa6fa775d092254d8adf21b06eb2))
-   **py/dotpromptz:** some lint and add docstrings ([#235](https://github.com/google/dotprompt/issues/235)) ([2e1c893](https://github.com/google/dotprompt/commit/2e1c893bbbe7c29480d67e2d693db90e9bef9b1b))
-   **py/handlebarrz:** helpers support in handlebarrz ([#291](https://github.com/google/dotprompt/issues/291)) ([d5d66a3](https://github.com/google/dotprompt/commit/d5d66a35858a068c2995b82fe54b62f0be4d057f))
-   **py/spec_test:** hex-encoded SHA-256 digest rather than base64-encoded SHA-256 digest for module IDs ([#140](https://github.com/google/dotprompt/issues/140)) ([796c644](https://github.com/google/dotprompt/commit/796c6442a3c1836de2170c466966382a0577a940))
-   **py:** lint reporting missing docstrings in test files ([#199](https://github.com/google/dotprompt/issues/199)) ([4d91514](https://github.com/google/dotprompt/commit/4d9151468ddd13f334454701daae42d5717d4dcf))
-   **py:** metadata purpose support ([#296](https://github.com/google/dotprompt/issues/296)) ([4a0f436](https://github.com/google/dotprompt/commit/4a0f436f1420f738d4fb46a4e5f41129929fb0fd))
-   remove spurious role type `assistant` ([#169](https://github.com/google/dotprompt/issues/169)) ([1b5142c](https://github.com/google/dotprompt/commit/1b5142c4a7ad20ef722d438cefa0b93a82d7adbb))

### Documentation

-   add initial mkdocs documentation for eng [#43](https://github.com/google/dotprompt/issues/43) ([#44](https://github.com/google/dotprompt/issues/44)) ([31be336](https://github.com/google/dotprompt/commit/31be336d14899acf7ea1cefb4b782f5b2d1c31d1))
-   **py/dotpromptz:** document awaitable type hierarchy as ASCII diagram in comments to make code readable ([#212](https://github.com/google/dotprompt/issues/212)) ([0926749](https://github.com/google/dotprompt/commit/0926749e72d17264b8078151b10f616a906cfd66))
-   **py:** add docstring to parse.py and dotprompt.py modules. ([#246](https://github.com/google/dotprompt/issues/246)) ([c9d53bb](https://github.com/google/dotprompt/commit/c9d53bb3cad96f9d8ef5778ada93ee65276afa09))
-   **py:** add documentation for the resolvers module ([#209](https://github.com/google/dotprompt/issues/209)) ([04b6691](https://github.com/google/dotprompt/commit/04b6691227ef5b01ebf5261d4846a3ba7e723ab2))
-   **py:** ascii diagrams to explain the relationships between the types for easy visualization ([#197](https://github.com/google/dotprompt/issues/197)) ([6d775c4](https://github.com/google/dotprompt/commit/6d775c4bf1301c63d111b0d45db53dba61117555))

## [0.1.3](https://github.com/google/dotprompt/compare/dotpromptz-v0.1.2...dotpromptz-0.1.3) (2025-11-19)

### Features

-   add implementation of helpers and util modules; move interfaces into dotpromptz project ([#73](https://github.com/google/dotprompt/issues/73)) ([8c7aea1](https://github.com/google/dotprompt/commit/8c7aea1faffaf823d01b132e55cb175a4fca5ccb))
-   add stub spec_test.py and script to monitor tests. ([#138](https://github.com/google/dotprompt/issues/138)) ([65966e9](https://github.com/google/dotprompt/commit/65966e9bfc077e85d0b83d04d0384150470dbfd3))
-   **go/parse:** parse.go implementation [#62](https://github.com/google/dotprompt/issues/62) ([#87](https://github.com/google/dotprompt/issues/87)) ([d5dc13c](https://github.com/google/dotprompt/commit/d5dc13c0bf0437875a3b133511ffed474a8b3bf9))
-   parseDocument python ([#80](https://github.com/google/dotprompt/issues/80)) ([82ebc36](https://github.com/google/dotprompt/commit/82ebc3672e8de051dfbdd92968ed3f84c79a247f))
-   partial test runner implementation now loads tests ([#139](https://github.com/google/dotprompt/issues/139)) ([b09dd2f](https://github.com/google/dotprompt/commit/b09dd2f9b8029317ce484d6f32d5a3fb89f5f7e1))
-   Port JS types to Python ([#65](https://github.com/google/dotprompt/issues/65)) ([edcb037](https://github.com/google/dotprompt/commit/edcb03765f3cb6e5743d107a35cf255a60ab0369))
-   **py/dotprompt:** render and compile implementations ([#263](https://github.com/google/dotprompt/issues/263)) ([961d0db](https://github.com/google/dotprompt/commit/961d0dbbd9c2ce522252bc3d92f6dde4b7fe9cc1))
-   **py/dotpromptz:** \_resolve_metadata for dotprompt ([#226](https://github.com/google/dotprompt/issues/226)) ([cfcc87b](https://github.com/google/dotprompt/commit/cfcc87b57e49785c2356b03fbc5b7bf773472683))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_json_schema implementation ([#217](https://github.com/google/dotprompt/issues/217)) ([0b62136](https://github.com/google/dotprompt/commit/0b621363a394c6b5c0fac6a957098eccff6891ca))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_partials implementation ([#215](https://github.com/google/dotprompt/issues/215)) ([03a161c](https://github.com/google/dotprompt/commit/03a161c3440a680bc0df472f35efa155fe0d5151))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_tools implementation and raise ValueError when resolver is None ([#214](https://github.com/google/dotprompt/issues/214)) ([57caf5d](https://github.com/google/dotprompt/commit/57caf5d9a9f4fe720c67f99fd10439d5ebe434dc))
-   **py/dotpromptz:** add resolve_json_schema and test case for ResolverCallable that returns an asyncio.Future ([#211](https://github.com/google/dotprompt/issues/211)) ([7bbe80d](https://github.com/google/dotprompt/commit/7bbe80d6a1d9dc18c4d1baacfccf2f33fc8b7e26))
-   **py/dotpromptz:** add resolvers module ([#207](https://github.com/google/dotprompt/issues/207)) ([826f257](https://github.com/google/dotprompt/commit/826f2572e710cebd0138bd757d2bef2e4898d730))
-   **py/dotpromptz:** because the Picoschema parser can resolve schemas at runtime, we make it an async implementation ([#220](https://github.com/google/dotprompt/issues/220)) ([ae285a8](https://github.com/google/dotprompt/commit/ae285a88f3502e0a02c85d04c49c2e2e6ef88766))
-   **py/dotpromptz:** configure handlebars to not escape by default ([#163](https://github.com/google/dotprompt/issues/163)) ([f7c33e1](https://github.com/google/dotprompt/commit/f7c33e1303476fd473e803f930ac1e1f9e1d87c9))
-   **py/dotpromptz:** construct test-specific dotprompt instance with partials and partial resolver set up ([#275](https://github.com/google/dotprompt/issues/275)) ([0af9a64](https://github.com/google/dotprompt/commit/0af9a64acf50278bdffda337e19c66fbb97e43a3))
-   **py/dotpromptz:** directory-based async and sync implementations of PromptStore and PromptStoreWritable ([#164](https://github.com/google/dotprompt/issues/164)) ([ac92fbf](https://github.com/google/dotprompt/commit/ac92fbf3af7ac3207102c94c20d294d8c54b9dd4))
-   **py/dotpromptz:** Dotprompt.{render\|compile} with CompileRenderer stub ([#248](https://github.com/google/dotprompt/issues/248)) ([61c578c](https://github.com/google/dotprompt/commit/61c578cf43ac490f8076306a8e2b5eb0ae15f385))
-   **py/dotpromptz:** implement helpers in terms of the rust implementation of handlebars-rust and fix go flakiness ([#115](https://github.com/google/dotprompt/issues/115)) ([314c0b5](https://github.com/google/dotprompt/commit/314c0b5182aaad25bf4cfccb8207faa60f63256f))
-   **py/dotpromptz:** initial bits of Dotprompt class ([#148](https://github.com/google/dotprompt/issues/148)) ([90f7838](https://github.com/google/dotprompt/commit/90f78384a958d41d78dee48497a78dfde11f4476))
-   **py/dotpromptz:** render_metadata implementation and associated tests ([#229](https://github.com/google/dotprompt/issues/229)) ([e66dc45](https://github.com/google/dotprompt/commit/e66dc453c718222e1633be951923a35335296dd5))
-   **py/dotpromptz:** simpler spec test runner harness ([#266](https://github.com/google/dotprompt/issues/266)) ([89378bf](https://github.com/google/dotprompt/commit/89378bfded004f3b246c90f6474c2fb972037956))
-   **py/dotpromptz:** test harness that creates suites and test case methods dynamically ([#279](https://github.com/google/dotprompt/issues/279)) ([1dc2bda](https://github.com/google/dotprompt/commit/1dc2bdac5de513cb41d32905d20069ab29307a72))
-   **py/dotpromptz:** translate render_metadata for dotprompt.py from ts ([#227](https://github.com/google/dotprompt/issues/227)) ([ae1919b](https://github.com/google/dotprompt/commit/ae1919b3457824241c734fdf8328f61279fb6710))
-   **py/dotpromptz:** use async picoschema_to_json_schema in dotprompt.\_render_picoschema ([#221](https://github.com/google/dotprompt/issues/221)) ([072d95d](https://github.com/google/dotprompt/commit/072d95deb01d9b09a7f60d9f6b3fb53a8067e497))
-   **py:** add SafeString implementation that works with js2py ([#104](https://github.com/google/dotprompt/issues/104)) ([1ebeca3](https://github.com/google/dotprompt/commit/1ebeca3976faf2dc91d8d7f4a74c218824aac353))
-   **py:** fix picoschema spec test ([#303](https://github.com/google/dotprompt/issues/303)) ([73439c1](https://github.com/google/dotprompt/commit/73439c183f557d7bb67b9cbc060e5602c219fc68))
-   **py:** implement identify_partials in terms of regexps since we do not have an AST to walk [#90](https://github.com/google/dotprompt/issues/90) ([#150](https://github.com/google/dotprompt/issues/150)) ([f802275](https://github.com/google/dotprompt/commit/f8022755d7eef716bbb54dd08a2c3a061250d393))
-   **py:** implementation of parse.py; refactor parse.ts and update tests. ([#79](https://github.com/google/dotprompt/issues/79)) ([47e7245](https://github.com/google/dotprompt/commit/47e7245c0aae710b102178019d1f3449c2f1af66))
-   **py:** local variables support workaround ([#318](https://github.com/google/dotprompt/issues/318)) ([d09598b](https://github.com/google/dotprompt/commit/d09598b969d5dbeaed3ca4136e903b4a2dc80531))
-   python implementations of helpers ([#129](https://github.com/google/dotprompt/issues/129)) ([79c6ef3](https://github.com/google/dotprompt/commit/79c6ef3e9cc472fed3a832c00a1515ceef0981da))
-   python: implement spec test logic ([#285](https://github.com/google/dotprompt/issues/285)) ([944f1fe](https://github.com/google/dotprompt/commit/944f1fee3e0e1f4f8bcd3c9bc4f6104ffbe17f2c))
-   python: picoschema support ISSUE: [#36](https://github.com/google/dotprompt/issues/36) CHANGELOG: - \[x\] Port relevant functionality - \[x\] Add tests ([#95](https://github.com/google/dotprompt/issues/95)) ([0da188c](https://github.com/google/dotprompt/commit/0da188c52540f041309e39fa6bc798eaf7fd7a81))
-   **python:** add OpenAI adapter implementation for dotprompt [#38](https://github.com/google/dotprompt/issues/38) ([#97](https://github.com/google/dotprompt/issues/97)) ([d171f87](https://github.com/google/dotprompt/commit/d171f8792ecf08f446e18ea3bbd5309cafa1d8a3))
-   **python:** support lower versions of python (\>=3.10) ([#187](https://github.com/google/dotprompt/issues/187)) ([4240f9d](https://github.com/google/dotprompt/commit/4240f9d720891e350f9116aa4401ce6ea7fac5a3))
-   **py:** utility function to unquote a string literal coming from js2py handlebars helpers ([#107](https://github.com/google/dotprompt/issues/107)) ([b3672ca](https://github.com/google/dotprompt/commit/b3672ca6192de4895585b28b8bbd301f8294090f))
-   **py:** utility to remove undefined fields from dicts/lists recursively ([#105](https://github.com/google/dotprompt/issues/105)) ([d25c911](https://github.com/google/dotprompt/commit/d25c911bc1e84e5691b961a4c38a8bcd73c80aa0))
-   use the HEAD version of addlicense ([#280](https://github.com/google/dotprompt/issues/280)) ([bdf0d36](https://github.com/google/dotprompt/commit/bdf0d36a430a363de4163f48394546cba884eaaf))

### Bug Fixes

-   change project name for pypi publish ([#200](https://github.com/google/dotprompt/issues/200)) ([2c07132](https://github.com/google/dotprompt/commit/2c0713264fb2c30bdc43f1bd9e51d416f96d1b7e))
-   **docs:** add documentation explaining yaml spec test format and revert typo ([#267](https://github.com/google/dotprompt/issues/267)) ([20cd71b](https://github.com/google/dotprompt/commit/20cd71bd68c9ec28de7264a72d495ff636e62cff))
-   **docs:** update docs for helpers.py functions ([#118](https://github.com/google/dotprompt/issues/118)) ([40f74d4](https://github.com/google/dotprompt/commit/40f74d4cf75a47d8b7f9f85801a1bb5969bae082))
-   **docs:** update helper docs ([#132](https://github.com/google/dotprompt/issues/132)) ([9b84245](https://github.com/google/dotprompt/commit/9b842459e8faa5f4afe7d389deb6c351ab1271be))
-   **go,py:** type fixes and ensure we build/lint the go code in hooks and ci ([#83](https://github.com/google/dotprompt/issues/83)) ([19a8257](https://github.com/google/dotprompt/commit/19a8257f4f73b776229d5324a0366fd9a79c20aa))
-   **helpers:** use ctx instead of hash to get the fn and inverse ([#131](https://github.com/google/dotprompt/issues/131)) ([8749d1f](https://github.com/google/dotprompt/commit/8749d1f78ee754742ae7fcc9247854021178bdbc))
-   **js:** clean up redundant call to register helpers that have already been registered ([#261](https://github.com/google/dotprompt/issues/261)) ([84e3c0c](https://github.com/google/dotprompt/commit/84e3c0cfd8da3b0292eebb2fe8a771fe41d09038))
-   **license:** use the full license header in source code ([#142](https://github.com/google/dotprompt/issues/142)) ([64894ef](https://github.com/google/dotprompt/commit/64894ef898876b861c6c244d522f634cd8fcc842))
-   **py/dotpromptz:** add todo about caching resolved schema for later ([#223](https://github.com/google/dotprompt/issues/223)) ([728dbaa](https://github.com/google/dotprompt/commit/728dbaaef1d0569148426a97242edd1f8064cdbe))
-   **py/dotpromptz:** add unit tests for resolver and fix sync resolver error handling ([#208](https://github.com/google/dotprompt/issues/208)) ([5e04e28](https://github.com/google/dotprompt/commit/5e04e28c99eff0f83c9c8a15df5ef56ff3ebd85f))
-   **py/dotpromptz:** address compatibility with python 3.10 and add tox configuration for parallelized tests ([#188](https://github.com/google/dotprompt/issues/188)) ([d2ba21f](https://github.com/google/dotprompt/commit/d2ba21ff3e54f4ca4328b7e574bb6492699095bc))
-   **py/dotpromptz:** dotprompt.define_tool takes just a tool def ([#224](https://github.com/google/dotprompt/issues/224)) ([72039fc](https://github.com/google/dotprompt/commit/72039fc689d82344bfc1300345059340603404bc))
-   **py/dotpromptz:** ensure parser handles {CR, CRLF, LF} line endings ([#256](https://github.com/google/dotprompt/issues/256)) ([18cff7a](https://github.com/google/dotprompt/commit/18cff7af50860c46fb37a2fa9c373bd410f11701))
-   **py/dotpromptz:** fix broken picoschema parser tests ([#232](https://github.com/google/dotprompt/issues/232)) ([4d154aa](https://github.com/google/dotprompt/commit/4d154aaae99f2f31500d86ed6191a05298700b91))
-   **py/dotpromptz:** fix pydantic warnings and tabulate the various types in typing.py ([#196](https://github.com/google/dotprompt/issues/196)) ([24dcfdd](https://github.com/google/dotprompt/commit/24dcfdd320884452ee48fca859619b400fe61327))
-   **py/dotpromptz:** make resolver concrete in resolve, resolve_tool, and resolve_partial ([#210](https://github.com/google/dotprompt/issues/210)) ([3730190](https://github.com/google/dotprompt/commit/37301903c8f26f1b8363ad1f2d515a6df19303e2))
-   **py/dotpromptz:** register initial helpers and partials correctly ([#260](https://github.com/google/dotprompt/issues/260)) ([0752865](https://github.com/google/dotprompt/commit/0752865b415c6cc90c87e3113b537632a52e3423))
-   **py/dotpromptz:** registering partials and start rendering some specs ([#269](https://github.com/google/dotprompt/issues/269)) ([aff3c4b](https://github.com/google/dotprompt/commit/aff3c4b9ee548e61268ca070f6660d51c860619d))
-   **py/dotpromptz:** remove stray reference to inspect.isasyncgenfunction since we dont deal with those as resolvers ([#216](https://github.com/google/dotprompt/issues/216)) ([c300515](https://github.com/google/dotprompt/commit/c3005159aea0af906e3f704d03fd5859a9540d4f))
-   **py/dotpromptz:** remove unused Options type from dotprompt.py and fix typo ([#213](https://github.com/google/dotprompt/issues/213)) ([ae59431](https://github.com/google/dotprompt/commit/ae5943179e77aa6fa775d092254d8adf21b06eb2))
-   **py/dotpromptz:** some lint and add docstrings ([#235](https://github.com/google/dotprompt/issues/235)) ([2e1c893](https://github.com/google/dotprompt/commit/2e1c893bbbe7c29480d67e2d693db90e9bef9b1b))
-   **py/handlebarrz:** helpers support in handlebarrz ([#291](https://github.com/google/dotprompt/issues/291)) ([d5d66a3](https://github.com/google/dotprompt/commit/d5d66a35858a068c2995b82fe54b62f0be4d057f))
-   **py/spec_test:** hex-encoded SHA-256 digest rather than base64-encoded SHA-256 digest for module IDs ([#140](https://github.com/google/dotprompt/issues/140)) ([796c644](https://github.com/google/dotprompt/commit/796c6442a3c1836de2170c466966382a0577a940))
-   **py:** lint reporting missing docstrings in test files ([#199](https://github.com/google/dotprompt/issues/199)) ([4d91514](https://github.com/google/dotprompt/commit/4d9151468ddd13f334454701daae42d5717d4dcf))
-   **py:** metadata purpose support ([#296](https://github.com/google/dotprompt/issues/296)) ([4a0f436](https://github.com/google/dotprompt/commit/4a0f436f1420f738d4fb46a4e5f41129929fb0fd))
-   remove spurious role type `assistant` ([#169](https://github.com/google/dotprompt/issues/169)) ([1b5142c](https://github.com/google/dotprompt/commit/1b5142c4a7ad20ef722d438cefa0b93a82d7adbb))

### Documentation

-   add initial mkdocs documentation for eng [#43](https://github.com/google/dotprompt/issues/43) ([#44](https://github.com/google/dotprompt/issues/44)) ([31be336](https://github.com/google/dotprompt/commit/31be336d14899acf7ea1cefb4b782f5b2d1c31d1))
-   **py/dotpromptz:** document awaitable type hierarchy as ASCII diagram in comments to make code readable ([#212](https://github.com/google/dotprompt/issues/212)) ([0926749](https://github.com/google/dotprompt/commit/0926749e72d17264b8078151b10f616a906cfd66))
-   **py:** add docstring to parse.py and dotprompt.py modules. ([#246](https://github.com/google/dotprompt/issues/246)) ([c9d53bb](https://github.com/google/dotprompt/commit/c9d53bb3cad96f9d8ef5778ada93ee65276afa09))
-   **py:** add documentation for the resolvers module ([#209](https://github.com/google/dotprompt/issues/209)) ([04b6691](https://github.com/google/dotprompt/commit/04b6691227ef5b01ebf5261d4846a3ba7e723ab2))
-   **py:** ascii diagrams to explain the relationships between the types for easy visualization ([#197](https://github.com/google/dotprompt/issues/197)) ([6d775c4](https://github.com/google/dotprompt/commit/6d775c4bf1301c63d111b0d45db53dba61117555))

## [0.1.2](https://github.com/google/dotprompt/compare/dotpromptz-0.1.1...dotpromptz-0.1.2) (2025-10-29)

### Features

-   add implementation of helpers and util modules; move interfaces into dotpromptz project ([#73](https://github.com/google/dotprompt/issues/73)) ([8c7aea1](https://github.com/google/dotprompt/commit/8c7aea1faffaf823d01b132e55cb175a4fca5ccb))
-   add stub spec_test.py and script to monitor tests. ([#138](https://github.com/google/dotprompt/issues/138)) ([65966e9](https://github.com/google/dotprompt/commit/65966e9bfc077e85d0b83d04d0384150470dbfd3))
-   **go/parse:** parse.go implementation [#62](https://github.com/google/dotprompt/issues/62) ([#87](https://github.com/google/dotprompt/issues/87)) ([d5dc13c](https://github.com/google/dotprompt/commit/d5dc13c0bf0437875a3b133511ffed474a8b3bf9))
-   parseDocument python ([#80](https://github.com/google/dotprompt/issues/80)) ([82ebc36](https://github.com/google/dotprompt/commit/82ebc3672e8de051dfbdd92968ed3f84c79a247f))
-   partial test runner implementation now loads tests ([#139](https://github.com/google/dotprompt/issues/139)) ([b09dd2f](https://github.com/google/dotprompt/commit/b09dd2f9b8029317ce484d6f32d5a3fb89f5f7e1))
-   Port JS types to Python ([#65](https://github.com/google/dotprompt/issues/65)) ([edcb037](https://github.com/google/dotprompt/commit/edcb03765f3cb6e5743d107a35cf255a60ab0369))
-   **py/dotprompt:** render and compile implementations ([#263](https://github.com/google/dotprompt/issues/263)) ([961d0db](https://github.com/google/dotprompt/commit/961d0dbbd9c2ce522252bc3d92f6dde4b7fe9cc1))
-   **py/dotpromptz:** \_resolve_metadata for dotprompt ([#226](https://github.com/google/dotprompt/issues/226)) ([cfcc87b](https://github.com/google/dotprompt/commit/cfcc87b57e49785c2356b03fbc5b7bf773472683))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_json_schema implementation ([#217](https://github.com/google/dotprompt/issues/217)) ([0b62136](https://github.com/google/dotprompt/commit/0b621363a394c6b5c0fac6a957098eccff6891ca))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_partials implementation ([#215](https://github.com/google/dotprompt/issues/215)) ([03a161c](https://github.com/google/dotprompt/commit/03a161c3440a680bc0df472f35efa155fe0d5151))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_tools implementation and raise ValueError when resolver is None ([#214](https://github.com/google/dotprompt/issues/214)) ([57caf5d](https://github.com/google/dotprompt/commit/57caf5d9a9f4fe720c67f99fd10439d5ebe434dc))
-   **py/dotpromptz:** add resolve_json_schema and test case for ResolverCallable that returns an asyncio.Future ([#211](https://github.com/google/dotprompt/issues/211)) ([7bbe80d](https://github.com/google/dotprompt/commit/7bbe80d6a1d9dc18c4d1baacfccf2f33fc8b7e26))
-   **py/dotpromptz:** add resolvers module ([#207](https://github.com/google/dotprompt/issues/207)) ([826f257](https://github.com/google/dotprompt/commit/826f2572e710cebd0138bd757d2bef2e4898d730))
-   **py/dotpromptz:** because the Picoschema parser can resolve schemas at runtime, we make it an async implementation ([#220](https://github.com/google/dotprompt/issues/220)) ([ae285a8](https://github.com/google/dotprompt/commit/ae285a88f3502e0a02c85d04c49c2e2e6ef88766))
-   **py/dotpromptz:** configure handlebars to not escape by default ([#163](https://github.com/google/dotprompt/issues/163)) ([f7c33e1](https://github.com/google/dotprompt/commit/f7c33e1303476fd473e803f930ac1e1f9e1d87c9))
-   **py/dotpromptz:** construct test-specific dotprompt instance with partials and partial resolver set up ([#275](https://github.com/google/dotprompt/issues/275)) ([0af9a64](https://github.com/google/dotprompt/commit/0af9a64acf50278bdffda337e19c66fbb97e43a3))
-   **py/dotpromptz:** directory-based async and sync implementations of PromptStore and PromptStoreWritable ([#164](https://github.com/google/dotprompt/issues/164)) ([ac92fbf](https://github.com/google/dotprompt/commit/ac92fbf3af7ac3207102c94c20d294d8c54b9dd4))
-   **py/dotpromptz:** Dotprompt.{render\|compile} with CompileRenderer stub ([#248](https://github.com/google/dotprompt/issues/248)) ([61c578c](https://github.com/google/dotprompt/commit/61c578cf43ac490f8076306a8e2b5eb0ae15f385))
-   **py/dotpromptz:** implement helpers in terms of the rust implementation of handlebars-rust and fix go flakiness ([#115](https://github.com/google/dotprompt/issues/115)) ([314c0b5](https://github.com/google/dotprompt/commit/314c0b5182aaad25bf4cfccb8207faa60f63256f))
-   **py/dotpromptz:** initial bits of Dotprompt class ([#148](https://github.com/google/dotprompt/issues/148)) ([90f7838](https://github.com/google/dotprompt/commit/90f78384a958d41d78dee48497a78dfde11f4476))
-   **py/dotpromptz:** render_metadata implementation and associated tests ([#229](https://github.com/google/dotprompt/issues/229)) ([e66dc45](https://github.com/google/dotprompt/commit/e66dc453c718222e1633be951923a35335296dd5))
-   **py/dotpromptz:** simpler spec test runner harness ([#266](https://github.com/google/dotprompt/issues/266)) ([89378bf](https://github.com/google/dotprompt/commit/89378bfded004f3b246c90f6474c2fb972037956))
-   **py/dotpromptz:** test harness that creates suites and test case methods dynamically ([#279](https://github.com/google/dotprompt/issues/279)) ([1dc2bda](https://github.com/google/dotprompt/commit/1dc2bdac5de513cb41d32905d20069ab29307a72))
-   **py/dotpromptz:** translate render_metadata for dotprompt.py from ts ([#227](https://github.com/google/dotprompt/issues/227)) ([ae1919b](https://github.com/google/dotprompt/commit/ae1919b3457824241c734fdf8328f61279fb6710))
-   **py/dotpromptz:** use async picoschema_to_json_schema in dotprompt.\_render_picoschema ([#221](https://github.com/google/dotprompt/issues/221)) ([072d95d](https://github.com/google/dotprompt/commit/072d95deb01d9b09a7f60d9f6b3fb53a8067e497))
-   **py:** add SafeString implementation that works with js2py ([#104](https://github.com/google/dotprompt/issues/104)) ([1ebeca3](https://github.com/google/dotprompt/commit/1ebeca3976faf2dc91d8d7f4a74c218824aac353))
-   **py:** fix picoschema spec test ([#303](https://github.com/google/dotprompt/issues/303)) ([73439c1](https://github.com/google/dotprompt/commit/73439c183f557d7bb67b9cbc060e5602c219fc68))
-   **py:** implement identify_partials in terms of regexps since we do not have an AST to walk [#90](https://github.com/google/dotprompt/issues/90) ([#150](https://github.com/google/dotprompt/issues/150)) ([f802275](https://github.com/google/dotprompt/commit/f8022755d7eef716bbb54dd08a2c3a061250d393))
-   **py:** implementation of parse.py; refactor parse.ts and update tests. ([#79](https://github.com/google/dotprompt/issues/79)) ([47e7245](https://github.com/google/dotprompt/commit/47e7245c0aae710b102178019d1f3449c2f1af66))
-   **py:** local variables support workaround ([#318](https://github.com/google/dotprompt/issues/318)) ([d09598b](https://github.com/google/dotprompt/commit/d09598b969d5dbeaed3ca4136e903b4a2dc80531))
-   python implementations of helpers ([#129](https://github.com/google/dotprompt/issues/129)) ([79c6ef3](https://github.com/google/dotprompt/commit/79c6ef3e9cc472fed3a832c00a1515ceef0981da))
-   python: implement spec test logic ([#285](https://github.com/google/dotprompt/issues/285)) ([944f1fe](https://github.com/google/dotprompt/commit/944f1fee3e0e1f4f8bcd3c9bc4f6104ffbe17f2c))
-   python: picoschema support ISSUE: [#36](https://github.com/google/dotprompt/issues/36) CHANGELOG: - \[x\] Port relevant functionality - \[x\] Add tests ([#95](https://github.com/google/dotprompt/issues/95)) ([0da188c](https://github.com/google/dotprompt/commit/0da188c52540f041309e39fa6bc798eaf7fd7a81))
-   **python:** add OpenAI adapter implementation for dotprompt [#38](https://github.com/google/dotprompt/issues/38) ([#97](https://github.com/google/dotprompt/issues/97)) ([d171f87](https://github.com/google/dotprompt/commit/d171f8792ecf08f446e18ea3bbd5309cafa1d8a3))
-   **python:** support lower versions of python (\>=3.10) ([#187](https://github.com/google/dotprompt/issues/187)) ([4240f9d](https://github.com/google/dotprompt/commit/4240f9d720891e350f9116aa4401ce6ea7fac5a3))
-   **py:** utility function to unquote a string literal coming from js2py handlebars helpers ([#107](https://github.com/google/dotprompt/issues/107)) ([b3672ca](https://github.com/google/dotprompt/commit/b3672ca6192de4895585b28b8bbd301f8294090f))
-   **py:** utility to remove undefined fields from dicts/lists recursively ([#105](https://github.com/google/dotprompt/issues/105)) ([d25c911](https://github.com/google/dotprompt/commit/d25c911bc1e84e5691b961a4c38a8bcd73c80aa0))
-   use the HEAD version of addlicense ([#280](https://github.com/google/dotprompt/issues/280)) ([bdf0d36](https://github.com/google/dotprompt/commit/bdf0d36a430a363de4163f48394546cba884eaaf))

### Bug Fixes

-   change project name for pypi publish ([#200](https://github.com/google/dotprompt/issues/200)) ([2c07132](https://github.com/google/dotprompt/commit/2c0713264fb2c30bdc43f1bd9e51d416f96d1b7e))
-   **docs:** add documentation explaining yaml spec test format and revert typo ([#267](https://github.com/google/dotprompt/issues/267)) ([20cd71b](https://github.com/google/dotprompt/commit/20cd71bd68c9ec28de7264a72d495ff636e62cff))
-   **docs:** update docs for helpers.py functions ([#118](https://github.com/google/dotprompt/issues/118)) ([40f74d4](https://github.com/google/dotprompt/commit/40f74d4cf75a47d8b7f9f85801a1bb5969bae082))
-   **docs:** update helper docs ([#132](https://github.com/google/dotprompt/issues/132)) ([9b84245](https://github.com/google/dotprompt/commit/9b842459e8faa5f4afe7d389deb6c351ab1271be))
-   **go,py:** type fixes and ensure we build/lint the go code in hooks and ci ([#83](https://github.com/google/dotprompt/issues/83)) ([19a8257](https://github.com/google/dotprompt/commit/19a8257f4f73b776229d5324a0366fd9a79c20aa))
-   **helpers:** use ctx instead of hash to get the fn and inverse ([#131](https://github.com/google/dotprompt/issues/131)) ([8749d1f](https://github.com/google/dotprompt/commit/8749d1f78ee754742ae7fcc9247854021178bdbc))
-   **js:** clean up redundant call to register helpers that have already been registered ([#261](https://github.com/google/dotprompt/issues/261)) ([84e3c0c](https://github.com/google/dotprompt/commit/84e3c0cfd8da3b0292eebb2fe8a771fe41d09038))
-   **license:** use the full license header in source code ([#142](https://github.com/google/dotprompt/issues/142)) ([64894ef](https://github.com/google/dotprompt/commit/64894ef898876b861c6c244d522f634cd8fcc842))
-   **py/dotpromptz:** add todo about caching resolved schema for later ([#223](https://github.com/google/dotprompt/issues/223)) ([728dbaa](https://github.com/google/dotprompt/commit/728dbaaef1d0569148426a97242edd1f8064cdbe))
-   **py/dotpromptz:** add unit tests for resolver and fix sync resolver error handling ([#208](https://github.com/google/dotprompt/issues/208)) ([5e04e28](https://github.com/google/dotprompt/commit/5e04e28c99eff0f83c9c8a15df5ef56ff3ebd85f))
-   **py/dotpromptz:** address compatibility with python 3.10 and add tox configuration for parallelized tests ([#188](https://github.com/google/dotprompt/issues/188)) ([d2ba21f](https://github.com/google/dotprompt/commit/d2ba21ff3e54f4ca4328b7e574bb6492699095bc))
-   **py/dotpromptz:** dotprompt.define_tool takes just a tool def ([#224](https://github.com/google/dotprompt/issues/224)) ([72039fc](https://github.com/google/dotprompt/commit/72039fc689d82344bfc1300345059340603404bc))
-   **py/dotpromptz:** ensure parser handles {CR, CRLF, LF} line endings ([#256](https://github.com/google/dotprompt/issues/256)) ([18cff7a](https://github.com/google/dotprompt/commit/18cff7af50860c46fb37a2fa9c373bd410f11701))
-   **py/dotpromptz:** fix broken picoschema parser tests ([#232](https://github.com/google/dotprompt/issues/232)) ([4d154aa](https://github.com/google/dotprompt/commit/4d154aaae99f2f31500d86ed6191a05298700b91))
-   **py/dotpromptz:** fix pydantic warnings and tabulate the various types in typing.py ([#196](https://github.com/google/dotprompt/issues/196)) ([24dcfdd](https://github.com/google/dotprompt/commit/24dcfdd320884452ee48fca859619b400fe61327))
-   **py/dotpromptz:** make resolver concrete in resolve, resolve_tool, and resolve_partial ([#210](https://github.com/google/dotprompt/issues/210)) ([3730190](https://github.com/google/dotprompt/commit/37301903c8f26f1b8363ad1f2d515a6df19303e2))
-   **py/dotpromptz:** register initial helpers and partials correctly ([#260](https://github.com/google/dotprompt/issues/260)) ([0752865](https://github.com/google/dotprompt/commit/0752865b415c6cc90c87e3113b537632a52e3423))
-   **py/dotpromptz:** registering partials and start rendering some specs ([#269](https://github.com/google/dotprompt/issues/269)) ([aff3c4b](https://github.com/google/dotprompt/commit/aff3c4b9ee548e61268ca070f6660d51c860619d))
-   **py/dotpromptz:** remove stray reference to inspect.isasyncgenfunction since we dont deal with those as resolvers ([#216](https://github.com/google/dotprompt/issues/216)) ([c300515](https://github.com/google/dotprompt/commit/c3005159aea0af906e3f704d03fd5859a9540d4f))
-   **py/dotpromptz:** remove unused Options type from dotprompt.py and fix typo ([#213](https://github.com/google/dotprompt/issues/213)) ([ae59431](https://github.com/google/dotprompt/commit/ae5943179e77aa6fa775d092254d8adf21b06eb2))
-   **py/dotpromptz:** some lint and add docstrings ([#235](https://github.com/google/dotprompt/issues/235)) ([2e1c893](https://github.com/google/dotprompt/commit/2e1c893bbbe7c29480d67e2d693db90e9bef9b1b))
-   **py/handlebarrz:** helpers support in handlebarrz ([#291](https://github.com/google/dotprompt/issues/291)) ([d5d66a3](https://github.com/google/dotprompt/commit/d5d66a35858a068c2995b82fe54b62f0be4d057f))
-   **py/spec_test:** hex-encoded SHA-256 digest rather than base64-encoded SHA-256 digest for module IDs ([#140](https://github.com/google/dotprompt/issues/140)) ([796c644](https://github.com/google/dotprompt/commit/796c6442a3c1836de2170c466966382a0577a940))
-   **py:** lint reporting missing docstrings in test files ([#199](https://github.com/google/dotprompt/issues/199)) ([4d91514](https://github.com/google/dotprompt/commit/4d9151468ddd13f334454701daae42d5717d4dcf))
-   **py:** metadata purpose support ([#296](https://github.com/google/dotprompt/issues/296)) ([4a0f436](https://github.com/google/dotprompt/commit/4a0f436f1420f738d4fb46a4e5f41129929fb0fd))
-   remove spurious role type `assistant` ([#169](https://github.com/google/dotprompt/issues/169)) ([1b5142c](https://github.com/google/dotprompt/commit/1b5142c4a7ad20ef722d438cefa0b93a82d7adbb))

### Documentation

-   add initial mkdocs documentation for eng [#43](https://github.com/google/dotprompt/issues/43) ([#44](https://github.com/google/dotprompt/issues/44)) ([31be336](https://github.com/google/dotprompt/commit/31be336d14899acf7ea1cefb4b782f5b2d1c31d1))
-   **py/dotpromptz:** document awaitable type hierarchy as ASCII diagram in comments to make code readable ([#212](https://github.com/google/dotprompt/issues/212)) ([0926749](https://github.com/google/dotprompt/commit/0926749e72d17264b8078151b10f616a906cfd66))
-   **py:** add docstring to parse.py and dotprompt.py modules. ([#246](https://github.com/google/dotprompt/issues/246)) ([c9d53bb](https://github.com/google/dotprompt/commit/c9d53bb3cad96f9d8ef5778ada93ee65276afa09))
-   **py:** add documentation for the resolvers module ([#209](https://github.com/google/dotprompt/issues/209)) ([04b6691](https://github.com/google/dotprompt/commit/04b6691227ef5b01ebf5261d4846a3ba7e723ab2))
-   **py:** ascii diagrams to explain the relationships between the types for easy visualization ([#197](https://github.com/google/dotprompt/issues/197)) ([6d775c4](https://github.com/google/dotprompt/commit/6d775c4bf1301c63d111b0d45db53dba61117555))

## [0.1.1](https://github.com/google/dotprompt/compare/dotpromptz-v0.1.0...dotpromptz-0.1.1) (2025-10-24)

### Features

-   add implementation of helpers and util modules; move interfaces into dotpromptz project ([#73](https://github.com/google/dotprompt/issues/73)) ([8c7aea1](https://github.com/google/dotprompt/commit/8c7aea1faffaf823d01b132e55cb175a4fca5ccb))
-   add stub spec_test.py and script to monitor tests. ([#138](https://github.com/google/dotprompt/issues/138)) ([65966e9](https://github.com/google/dotprompt/commit/65966e9bfc077e85d0b83d04d0384150470dbfd3))
-   **go/parse:** parse.go implementation [#62](https://github.com/google/dotprompt/issues/62) ([#87](https://github.com/google/dotprompt/issues/87)) ([d5dc13c](https://github.com/google/dotprompt/commit/d5dc13c0bf0437875a3b133511ffed474a8b3bf9))
-   parseDocument python ([#80](https://github.com/google/dotprompt/issues/80)) ([82ebc36](https://github.com/google/dotprompt/commit/82ebc3672e8de051dfbdd92968ed3f84c79a247f))
-   partial test runner implementation now loads tests ([#139](https://github.com/google/dotprompt/issues/139)) ([b09dd2f](https://github.com/google/dotprompt/commit/b09dd2f9b8029317ce484d6f32d5a3fb89f5f7e1))
-   Port JS types to Python ([#65](https://github.com/google/dotprompt/issues/65)) ([edcb037](https://github.com/google/dotprompt/commit/edcb03765f3cb6e5743d107a35cf255a60ab0369))
-   **py/dotprompt:** render and compile implementations ([#263](https://github.com/google/dotprompt/issues/263)) ([961d0db](https://github.com/google/dotprompt/commit/961d0dbbd9c2ce522252bc3d92f6dde4b7fe9cc1))
-   **py/dotpromptz:** \_resolve_metadata for dotprompt ([#226](https://github.com/google/dotprompt/issues/226)) ([cfcc87b](https://github.com/google/dotprompt/commit/cfcc87b57e49785c2356b03fbc5b7bf773472683))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_json_schema implementation ([#217](https://github.com/google/dotprompt/issues/217)) ([0b62136](https://github.com/google/dotprompt/commit/0b621363a394c6b5c0fac6a957098eccff6891ca))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_partials implementation ([#215](https://github.com/google/dotprompt/issues/215)) ([03a161c](https://github.com/google/dotprompt/commit/03a161c3440a680bc0df472f35efa155fe0d5151))
-   **py/dotpromptz:** add initial Dotprompt.\_resolve_tools implementation and raise ValueError when resolver is None ([#214](https://github.com/google/dotprompt/issues/214)) ([57caf5d](https://github.com/google/dotprompt/commit/57caf5d9a9f4fe720c67f99fd10439d5ebe434dc))
-   **py/dotpromptz:** add resolve_json_schema and test case for ResolverCallable that returns an asyncio.Future ([#211](https://github.com/google/dotprompt/issues/211)) ([7bbe80d](https://github.com/google/dotprompt/commit/7bbe80d6a1d9dc18c4d1baacfccf2f33fc8b7e26))
-   **py/dotpromptz:** add resolvers module ([#207](https://github.com/google/dotprompt/issues/207)) ([826f257](https://github.com/google/dotprompt/commit/826f2572e710cebd0138bd757d2bef2e4898d730))
-   **py/dotpromptz:** because the Picoschema parser can resolve schemas at runtime, we make it an async implementation ([#220](https://github.com/google/dotprompt/issues/220)) ([ae285a8](https://github.com/google/dotprompt/commit/ae285a88f3502e0a02c85d04c49c2e2e6ef88766))
-   **py/dotpromptz:** configure handlebars to not escape by default ([#163](https://github.com/google/dotprompt/issues/163)) ([f7c33e1](https://github.com/google/dotprompt/commit/f7c33e1303476fd473e803f930ac1e1f9e1d87c9))
-   **py/dotpromptz:** construct test-specific dotprompt instance with partials and partial resolver set up ([#275](https://github.com/google/dotprompt/issues/275)) ([0af9a64](https://github.com/google/dotprompt/commit/0af9a64acf50278bdffda337e19c66fbb97e43a3))
-   **py/dotpromptz:** directory-based async and sync implementations of PromptStore and PromptStoreWritable ([#164](https://github.com/google/dotprompt/issues/164)) ([ac92fbf](https://github.com/google/dotprompt/commit/ac92fbf3af7ac3207102c94c20d294d8c54b9dd4))
-   **py/dotpromptz:** Dotprompt.{render\|compile} with CompileRenderer stub ([#248](https://github.com/google/dotprompt/issues/248)) ([61c578c](https://github.com/google/dotprompt/commit/61c578cf43ac490f8076306a8e2b5eb0ae15f385))
-   **py/dotpromptz:** implement helpers in terms of the rust implementation of handlebars-rust and fix go flakiness ([#115](https://github.com/google/dotprompt/issues/115)) ([314c0b5](https://github.com/google/dotprompt/commit/314c0b5182aaad25bf4cfccb8207faa60f63256f))
-   **py/dotpromptz:** initial bits of Dotprompt class ([#148](https://github.com/google/dotprompt/issues/148)) ([90f7838](https://github.com/google/dotprompt/commit/90f78384a958d41d78dee48497a78dfde11f4476))
-   **py/dotpromptz:** render_metadata implementation and associated tests ([#229](https://github.com/google/dotprompt/issues/229)) ([e66dc45](https://github.com/google/dotprompt/commit/e66dc453c718222e1633be951923a35335296dd5))
-   **py/dotpromptz:** simpler spec test runner harness ([#266](https://github.com/google/dotprompt/issues/266)) ([89378bf](https://github.com/google/dotprompt/commit/89378bfded004f3b246c90f6474c2fb972037956))
-   **py/dotpromptz:** test harness that creates suites and test case methods dynamically ([#279](https://github.com/google/dotprompt/issues/279)) ([1dc2bda](https://github.com/google/dotprompt/commit/1dc2bdac5de513cb41d32905d20069ab29307a72))
-   **py/dotpromptz:** translate render_metadata for dotprompt.py from ts ([#227](https://github.com/google/dotprompt/issues/227)) ([ae1919b](https://github.com/google/dotprompt/commit/ae1919b3457824241c734fdf8328f61279fb6710))
-   **py/dotpromptz:** use async picoschema_to_json_schema in dotprompt.\_render_picoschema ([#221](https://github.com/google/dotprompt/issues/221)) ([072d95d](https://github.com/google/dotprompt/commit/072d95deb01d9b09a7f60d9f6b3fb53a8067e497))
-   **py:** add SafeString implementation that works with js2py ([#104](https://github.com/google/dotprompt/issues/104)) ([1ebeca3](https://github.com/google/dotprompt/commit/1ebeca3976faf2dc91d8d7f4a74c218824aac353))
-   **py:** fix picoschema spec test ([#303](https://github.com/google/dotprompt/issues/303)) ([73439c1](https://github.com/google/dotprompt/commit/73439c183f557d7bb67b9cbc060e5602c219fc68))
-   **py:** implement identify_partials in terms of regexps since we do not have an AST to walk [#90](https://github.com/google/dotprompt/issues/90) ([#150](https://github.com/google/dotprompt/issues/150)) ([f802275](https://github.com/google/dotprompt/commit/f8022755d7eef716bbb54dd08a2c3a061250d393))
-   **py:** implementation of parse.py; refactor parse.ts and update tests. ([#79](https://github.com/google/dotprompt/issues/79)) ([47e7245](https://github.com/google/dotprompt/commit/47e7245c0aae710b102178019d1f3449c2f1af66))
-   **py:** local variables support workaround ([#318](https://github.com/google/dotprompt/issues/318)) ([d09598b](https://github.com/google/dotprompt/commit/d09598b969d5dbeaed3ca4136e903b4a2dc80531))
-   python implementations of helpers ([#129](https://github.com/google/dotprompt/issues/129)) ([79c6ef3](https://github.com/google/dotprompt/commit/79c6ef3e9cc472fed3a832c00a1515ceef0981da))
-   python: implement spec test logic ([#285](https://github.com/google/dotprompt/issues/285)) ([944f1fe](https://github.com/google/dotprompt/commit/944f1fee3e0e1f4f8bcd3c9bc4f6104ffbe17f2c))
-   python: picoschema support ISSUE: [#36](https://github.com/google/dotprompt/issues/36) CHANGELOG: - \[x\] Port relevant functionality - \[x\] Add tests ([#95](https://github.com/google/dotprompt/issues/95)) ([0da188c](https://github.com/google/dotprompt/commit/0da188c52540f041309e39fa6bc798eaf7fd7a81))
-   **python:** add OpenAI adapter implementation for dotprompt [#38](https://github.com/google/dotprompt/issues/38) ([#97](https://github.com/google/dotprompt/issues/97)) ([d171f87](https://github.com/google/dotprompt/commit/d171f8792ecf08f446e18ea3bbd5309cafa1d8a3))
-   **python:** support lower versions of python (\>=3.10) ([#187](https://github.com/google/dotprompt/issues/187)) ([4240f9d](https://github.com/google/dotprompt/commit/4240f9d720891e350f9116aa4401ce6ea7fac5a3))
-   **py:** utility function to unquote a string literal coming from js2py handlebars helpers ([#107](https://github.com/google/dotprompt/issues/107)) ([b3672ca](https://github.com/google/dotprompt/commit/b3672ca6192de4895585b28b8bbd301f8294090f))
-   **py:** utility to remove undefined fields from dicts/lists recursively ([#105](https://github.com/google/dotprompt/issues/105)) ([d25c911](https://github.com/google/dotprompt/commit/d25c911bc1e84e5691b961a4c38a8bcd73c80aa0))
-   use the HEAD version of addlicense ([#280](https://github.com/google/dotprompt/issues/280)) ([bdf0d36](https://github.com/google/dotprompt/commit/bdf0d36a430a363de4163f48394546cba884eaaf))

### Bug Fixes

-   change project name for pypi publish ([#200](https://github.com/google/dotprompt/issues/200)) ([2c07132](https://github.com/google/dotprompt/commit/2c0713264fb2c30bdc43f1bd9e51d416f96d1b7e))
-   **docs:** add documentation explaining yaml spec test format and revert typo ([#267](https://github.com/google/dotprompt/issues/267)) ([20cd71b](https://github.com/google/dotprompt/commit/20cd71bd68c9ec28de7264a72d495ff636e62cff))
-   **docs:** update docs for helpers.py functions ([#118](https://github.com/google/dotprompt/issues/118)) ([40f74d4](https://github.com/google/dotprompt/commit/40f74d4cf75a47d8b7f9f85801a1bb5969bae082))
-   **docs:** update helper docs ([#132](https://github.com/google/dotprompt/issues/132)) ([9b84245](https://github.com/google/dotprompt/commit/9b842459e8faa5f4afe7d389deb6c351ab1271be))
-   **go,py:** type fixes and ensure we build/lint the go code in hooks and ci ([#83](https://github.com/google/dotprompt/issues/83)) ([19a8257](https://github.com/google/dotprompt/commit/19a8257f4f73b776229d5324a0366fd9a79c20aa))
-   **helpers:** use ctx instead of hash to get the fn and inverse ([#131](https://github.com/google/dotprompt/issues/131)) ([8749d1f](https://github.com/google/dotprompt/commit/8749d1f78ee754742ae7fcc9247854021178bdbc))
-   **js:** clean up redundant call to register helpers that have already been registered ([#261](https://github.com/google/dotprompt/issues/261)) ([84e3c0c](https://github.com/google/dotprompt/commit/84e3c0cfd8da3b0292eebb2fe8a771fe41d09038))
-   **license:** use the full license header in source code ([#142](https://github.com/google/dotprompt/issues/142)) ([64894ef](https://github.com/google/dotprompt/commit/64894ef898876b861c6c244d522f634cd8fcc842))
-   **py/dotpromptz:** add todo about caching resolved schema for later ([#223](https://github.com/google/dotprompt/issues/223)) ([728dbaa](https://github.com/google/dotprompt/commit/728dbaaef1d0569148426a97242edd1f8064cdbe))
-   **py/dotpromptz:** add unit tests for resolver and fix sync resolver error handling ([#208](https://github.com/google/dotprompt/issues/208)) ([5e04e28](https://github.com/google/dotprompt/commit/5e04e28c99eff0f83c9c8a15df5ef56ff3ebd85f))
-   **py/dotpromptz:** address compatibility with python 3.10 and add tox configuration for parallelized tests ([#188](https://github.com/google/dotprompt/issues/188)) ([d2ba21f](https://github.com/google/dotprompt/commit/d2ba21ff3e54f4ca4328b7e574bb6492699095bc))
-   **py/dotpromptz:** dotprompt.define_tool takes just a tool def ([#224](https://github.com/google/dotprompt/issues/224)) ([72039fc](https://github.com/google/dotprompt/commit/72039fc689d82344bfc1300345059340603404bc))
-   **py/dotpromptz:** ensure parser handles {CR, CRLF, LF} line endings ([#256](https://github.com/google/dotprompt/issues/256)) ([18cff7a](https://github.com/google/dotprompt/commit/18cff7af50860c46fb37a2fa9c373bd410f11701))
-   **py/dotpromptz:** fix broken picoschema parser tests ([#232](https://github.com/google/dotprompt/issues/232)) ([4d154aa](https://github.com/google/dotprompt/commit/4d154aaae99f2f31500d86ed6191a05298700b91))
-   **py/dotpromptz:** fix pydantic warnings and tabulate the various types in typing.py ([#196](https://github.com/google/dotprompt/issues/196)) ([24dcfdd](https://github.com/google/dotprompt/commit/24dcfdd320884452ee48fca859619b400fe61327))
-   **py/dotpromptz:** make resolver concrete in resolve, resolve_tool, and resolve_partial ([#210](https://github.com/google/dotprompt/issues/210)) ([3730190](https://github.com/google/dotprompt/commit/37301903c8f26f1b8363ad1f2d515a6df19303e2))
-   **py/dotpromptz:** register initial helpers and partials correctly ([#260](https://github.com/google/dotprompt/issues/260)) ([0752865](https://github.com/google/dotprompt/commit/0752865b415c6cc90c87e3113b537632a52e3423))
-   **py/dotpromptz:** registering partials and start rendering some specs ([#269](https://github.com/google/dotprompt/issues/269)) ([aff3c4b](https://github.com/google/dotprompt/commit/aff3c4b9ee548e61268ca070f6660d51c860619d))
-   **py/dotpromptz:** remove stray reference to inspect.isasyncgenfunction since we dont deal with those as resolvers ([#216](https://github.com/google/dotprompt/issues/216)) ([c300515](https://github.com/google/dotprompt/commit/c3005159aea0af906e3f704d03fd5859a9540d4f))
-   **py/dotpromptz:** remove unused Options type from dotprompt.py and fix typo ([#213](https://github.com/google/dotprompt/issues/213)) ([ae59431](https://github.com/google/dotprompt/commit/ae5943179e77aa6fa775d092254d8adf21b06eb2))
-   **py/dotpromptz:** some lint and add docstrings ([#235](https://github.com/google/dotprompt/issues/235)) ([2e1c893](https://github.com/google/dotprompt/commit/2e1c893bbbe7c29480d67e2d693db90e9bef9b1b))
-   **py/handlebarrz:** helpers support in handlebarrz ([#291](https://github.com/google/dotprompt/issues/291)) ([d5d66a3](https://github.com/google/dotprompt/commit/d5d66a35858a068c2995b82fe54b62f0be4d057f))
-   **py/spec_test:** hex-encoded SHA-256 digest rather than base64-encoded SHA-256 digest for module IDs ([#140](https://github.com/google/dotprompt/issues/140)) ([796c644](https://github.com/google/dotprompt/commit/796c6442a3c1836de2170c466966382a0577a940))
-   **py:** lint reporting missing docstrings in test files ([#199](https://github.com/google/dotprompt/issues/199)) ([4d91514](https://github.com/google/dotprompt/commit/4d9151468ddd13f334454701daae42d5717d4dcf))
-   **py:** metadata purpose support ([#296](https://github.com/google/dotprompt/issues/296)) ([4a0f436](https://github.com/google/dotprompt/commit/4a0f436f1420f738d4fb46a4e5f41129929fb0fd))
-   remove spurious role type `assistant` ([#169](https://github.com/google/dotprompt/issues/169)) ([1b5142c](https://github.com/google/dotprompt/commit/1b5142c4a7ad20ef722d438cefa0b93a82d7adbb))

### Documentation

-   add initial mkdocs documentation for eng [#43](https://github.com/google/dotprompt/issues/43) ([#44](https://github.com/google/dotprompt/issues/44)) ([31be336](https://github.com/google/dotprompt/commit/31be336d14899acf7ea1cefb4b782f5b2d1c31d1))
-   **py/dotpromptz:** document awaitable type hierarchy as ASCII diagram in comments to make code readable ([#212](https://github.com/google/dotprompt/issues/212)) ([0926749](https://github.com/google/dotprompt/commit/0926749e72d17264b8078151b10f616a906cfd66))
-   **py:** add docstring to parse.py and dotprompt.py modules. ([#246](https://github.com/google/dotprompt/issues/246)) ([c9d53bb](https://github.com/google/dotprompt/commit/c9d53bb3cad96f9d8ef5778ada93ee65276afa09))
-   **py:** add documentation for the resolvers module ([#209](https://github.com/google/dotprompt/issues/209)) ([04b6691](https://github.com/google/dotprompt/commit/04b6691227ef5b01ebf5261d4846a3ba7e723ab2))
-   **py:** ascii diagrams to explain the relationships between the types for easy visualization ([#197](https://github.com/google/dotprompt/issues/197)) ([6d775c4](https://github.com/google/dotprompt/commit/6d775c4bf1301c63d111b0d45db53dba61117555))