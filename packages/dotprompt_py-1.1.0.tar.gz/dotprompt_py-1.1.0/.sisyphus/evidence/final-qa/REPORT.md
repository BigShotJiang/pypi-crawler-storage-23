F3: REAL MANUAL QA
==================

TASK 1: RuntimeConfig Model
----------------------------
Scenario 1 (defaults): ✅ PASS
  Output: {"max_workers": 5, "output_dir": null, "jsonl": false}
  Evidence: final-qa/task-1-scenario-1.txt

Scenario 2 (custom values): ✅ PASS
  Output: {"max_workers": 3, "output_dir": "out", "jsonl": true}
  Evidence: final-qa/task-1-scenario-2.txt

Task 1 Score: [2/2] ✅

TASK 2: Parser Wiring
---------------------
Scenario 1 (parse with runtime): ✅ PASS
  Output: runtime: {"max_workers": 3, "output_dir": "results/", "jsonl": true}
  Evidence: final-qa/task-2-scenario-1.txt

Scenario 2 (parse without runtime): ✅ PASS
  Output: runtime: None
  Evidence: final-qa/task-2-scenario-2.txt

Task 2 Score: [2/2] ✅

TASK 3: CLI Rewrite
-------------------
Scenario 1 (single execution dry-run): ✅ PASS
  Output: JSON with "Tell me about AI." in content
  Evidence: final-qa/task-3-scenario-1.txt

Scenario 2 (batch execution dry-run): ✅ PASS
  Output: 2 JSONL lines, both status=success, "AI" and "ML" present
  Evidence: final-qa/task-3-scenario-2.txt

Scenario 3 (JSONL auto-detection): ✅ PASS
  Output: 2 JSONL outputs (batch mode auto-detected from .jsonl extension)
  Evidence: final-qa/task-3-scenario-3.txt

Scenario 4 (YAML input support): ✅ PASS
  Output: JSON with "Tell me about quantum." in content
  Evidence: final-qa/task-3-scenario-4.txt

Scenario 5 (unsupported extension): ✅ PASS
  Output: Exit code 2, error "Unsupported input file format: .xml"
  Evidence: final-qa/task-3-scenario-5.txt

Scenario 6 (help output validation): ✅ PASS
  Output: Contains PROMPT_FILE, INPUT_FILE; no old flags (--input, --input-file)
  Evidence: final-qa/task-3-scenario-6.txt

Scenario 7 (empty array handling): ✅ PASS
  Output: Exit 0, message "No input items to process."
  Evidence: final-qa/task-3-scenario-7.txt

Task 3 Score: [7/7] ✅

TASK 4: Test Suite
------------------
Scenario 1 (all CLI tests pass): ✅ PASS
  Output: 45 tests passed in 34.80s
  Evidence: final-qa/task-4-scenario-1.txt

Scenario 2 (test_main.py tests pass): ✅ PASS
  Output: 3 tests passed in 8.86s
  Evidence: final-qa/task-4-scenario-2.txt

Scenario 3 (no old CLI references): ✅ PASS
  Output: Exit 0 (no matches for 'run' as subcommand)
  Evidence: final-qa/task-4-scenario-3.txt

Task 4 Score: [3/3] ✅

TASK 5: Documentation
---------------------
Scenario 1 (entry point in pyproject.toml): ✅ PASS
  Output: runprompt = "dotpromptz.cli:cli"
  Evidence: final-qa/task-5-scenario-1.txt

Scenario 2 (no stale references): ✅ PASS
  Output: 0 occurrences of "dotprompt run"
  Evidence: final-qa/task-5-scenario-2.txt

Scenario 3 (new examples present): ✅ PASS
  Output: 5 occurrences of "runprompt"
  Evidence: final-qa/task-5-scenario-3.txt

Task 5 Score: [3/3] ✅

INTEGRATION TESTS
-----------------
Integration 1 (runtime → batch): ✅ PASS
  Verified:
    - 2 JSONL outputs to stdout
    - Message "Batch results written to: /tmp/qa_output/"
    - Files created: 000.json, 001.json in output_dir
    - Runtime config honored: max_workers=1, output_dir=/tmp/qa_output, jsonl=true
  Evidence: final-qa/integration-1-runtime-batch.txt

Integration 2 (parser → CLI → output): ✅ PASS
  Verified:
    - Full pipeline works end-to-end
    - 2 JSONL lines with status=success
    - Rendered content contains "hello" and "world"
    - Adapter field used correctly (no deprecation warning)
  Evidence: final-qa/integration-2-pipeline.txt

Integration Score: [2/2] ✅

EDGE CASES
----------
Edge 1 (empty dict): ✅ PASS
  Handled gracefully: Renders with empty variable ({{topic}} → ".")
  Evidence: final-qa/edge-case-1-empty-dict.txt

Edge 2 (invalid JSON): ✅ PASS
  Exit code 2, error message: "Invalid JSON: Expecting property name..."
  Evidence: final-qa/edge-case-2-invalid-json.txt

Edge 3 (JSONL with blank lines): ✅ PASS
  Blank lines skipped, 2 outputs produced correctly
  Evidence: final-qa/edge-case-3-jsonl-blanks.txt

Edge 4 (list of non-dicts): ✅ PASS
  Exit code 2, error message: "JSON array must contain only objects (dicts)"
  Evidence: final-qa/edge-case-4-list-nondict.txt

Edge 5 (single-element array): ✅ PASS
  Batch mode used (index=0 in output), not single mode
  Evidence: final-qa/edge-case-5-single-array.txt

Edge 6 (missing required variable): ✅ PASS
  Handled gracefully: Renders with empty variable ({{topic}} → ".")
  Evidence: final-qa/edge-case-6-missing-var.txt

Edge Cases Score: [6/6] ✅

SUMMARY
-------
Task Scenarios: [17/17 pass] ✅
Integration Tests: [2/2 pass] ✅
Edge Cases: [6/6 tested, 6 pass] ✅
Total Evidence Files: 25 created

VERDICT: ✅ APPROVE

All QA scenarios passed successfully. The CLI redesign implementation:
1. Correctly implements RuntimeConfig model with defaults and custom values
2. Parser properly wires runtime config from .prompt files
3. CLI interface works correctly for single/batch/JSONL/YAML inputs
4. All 48 test cases (45 CLI + 3 main) pass
5. Documentation updated correctly (entry point + examples)
6. Integration tests confirm end-to-end functionality
7. Edge cases handled gracefully with proper error messages

The implementation is production-ready.
