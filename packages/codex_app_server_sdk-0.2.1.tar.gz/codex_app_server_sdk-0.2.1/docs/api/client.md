# `codex_app_server_client.client`

::: codex_app_server_client.client
