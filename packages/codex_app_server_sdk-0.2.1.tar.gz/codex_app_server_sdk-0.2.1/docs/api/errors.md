# `codex_app_server_client.errors`

::: codex_app_server_client.errors
