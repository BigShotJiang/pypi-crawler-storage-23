# `codex_app_server_client.protocol`

::: codex_app_server_client.protocol
