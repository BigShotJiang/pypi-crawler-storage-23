"""RedflowClient — the main entry point for interacting with redflow runs.

Provides run creation (with idempotency), cancellation, listing, status
transitions, and registry sync.  All Redis mutations that touch multiple
keys use Lua scripts via EVALSHA for atomicity.
"""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import math
import os
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from redis.asyncio import Redis

from . import _keys as K
from ._json import safe_json_dumps, safe_json_loads, safe_json_try_loads
from ._lua_scripts import (
    ENQUEUE_RUN,
    FINALIZE_TERMINAL_RUN,
    PROMOTE_SCHEDULED_RUN,
    REQUEST_CANCELLATION,
    SCHEDULE_RETRY,
    TRANSITION_IF_CURRENT_STATUS,
    TRANSITION_QUEUED_TO_RUNNING,
    TRANSITION_RUN_STATUS,
)
from ._time import now_ms
from .errors import (
    CanceledError,
    InputValidationError,
    NonRetriableError,
    OutputSerializationError,
    RedflowError,
    UnknownWorkflowError,
    serialize_error,
)
from .registry import WorkflowRegistry
from .types import (
    ALL_STATUSES,
    DEFAULT_MAX_ATTEMPTS,
    IDEMPOTENCY_TTL_SEC,
    ListedRun,
    ListRunsParams,
    RunState,
    RunStats,
    RunStatus,
    StepState,
    WorkflowMeta,
)

_POLL_MS = 250
_STALE_WORKFLOW_GRACE_MS = 30_000


def default_prefix() -> str:
    return os.environ.get("REDFLOW_PREFIX", "redflow:v1")


# ---------- helpers ----------


def _normalize_max_concurrency(value: Any) -> int:
    try:
        v = int(value)
    except (TypeError, ValueError):
        return 1
    return max(1, v)


def _parse_redis_int(value: Any) -> int:
    if value is None:
        return 0
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def _is_valid_datetime(dt: datetime | None) -> bool:
    return isinstance(dt, datetime) and math.isfinite(dt.timestamp())


def _cron_to_dict(c: Any) -> dict[str, Any]:
    """Serialize a CronTrigger omitting None values (matches JS ``JSON.stringify`` behavior)."""
    d: dict[str, Any] = {"expression": c.expression}
    if c.timezone is not None:
        d["timezone"] = c.timezone
    if c.input is not None:
        d["input"] = c.input
    if c.id is not None:
        d["id"] = c.id
    return d


def _parse_enqueue_result(value: Any) -> tuple[str, str] | None:
    """Parse ``["created"|"existing", runId]`` from Lua script."""
    if isinstance(value, (list, tuple)):
        if len(value) == 1 and isinstance(value[0], (list, tuple)):
            return _parse_enqueue_result(value[0])
        if len(value) >= 2:
            kind_raw = value[0]
            run_id_raw = value[1]
            kind = kind_raw.decode() if isinstance(kind_raw, bytes) else str(kind_raw)
            run_id = run_id_raw.decode() if isinstance(run_id_raw, bytes) else str(run_id_raw)
            if kind in ("created", "existing") and run_id:
                return (kind, run_id)
    return None


def _decode(value: Any) -> str:
    """Decode bytes → str, pass through str."""
    if isinstance(value, bytes):
        return value.decode()
    return str(value) if value is not None else ""


def is_terminal_status(status: RunStatus) -> bool:
    return status in ("succeeded", "failed", "canceled")


def is_retryable_error(err: BaseException) -> bool:
    return not isinstance(
        err, (InputValidationError, UnknownWorkflowError, OutputSerializationError, CanceledError, NonRetriableError)
    )


def compute_retry_delay_ms(attempt: int) -> int:
    """Exponential backoff with jitter, matching the TS client."""
    import random

    base = 250
    max_delay = 30_000
    exp = min(max_delay, base * (2 ** max(0, attempt - 1)))
    jitter = random.randint(0, 99)
    return exp + jitter


def make_error_json(err: BaseException | Any) -> str:
    try:
        return safe_json_dumps(serialize_error(err))
    except Exception:
        return '{"name":"Error","message":"Failed to serialize original error","kind":"error"}'


# ---------- RunHandle ----------


@dataclass(slots=True)
class ConcreteRunHandle:
    """Concrete implementation of the RunHandle protocol."""

    id: str
    _client: RedflowClient

    async def get_state(self) -> RunState | None:
        return await self._client.get_run(self.id)

    async def result(self, *, timeout_ms: int = 30_000) -> Any:
        return await self._client.wait_for_result(self.id, timeout_ms=timeout_ms)


# ---------- RedflowClient ----------


class RedflowClient:
    """High-level client for creating and managing redflow workflow runs."""

    __slots__ = ("prefix", "redis")

    def __init__(self, redis: Redis[Any], prefix: str) -> None:
        self.redis = redis
        self.prefix = prefix

    async def close(self) -> None:
        await self.redis.aclose()

    # ---------- state management ----------

    async def reset_state(self) -> dict[str, int]:
        """Delete all redflow keys (testing/dev only)."""
        normalized = self.prefix.rstrip(":")
        pattern = f"{normalized}:*"
        deleted = 0
        cursor: int | str = 0

        while True:
            cursor, found_keys = await self.redis.scan(cursor=int(cursor), match=pattern, count=500)
            if found_keys:
                deleted += await self.redis.unlink(*found_keys)
            if cursor == 0:
                break

        with contextlib.suppress(Exception):
            deleted += await self.redis.unlink(normalized)

        return {"deleted": deleted}

    # ---------- workflow metadata ----------

    async def list_workflows(self) -> list[str]:
        members = await self.redis.smembers(K.workflows(self.prefix))
        return [_decode(m) for m in members]

    async def get_workflow_meta(self, name: str) -> WorkflowMeta | None:
        data = await self.redis.hgetall(K.workflow(self.prefix, name))
        if not data:
            return None

        decoded: dict[str, str] = {_decode(k): _decode(v) for k, v in data.items()}

        parsed_cron = safe_json_try_loads(decoded.get("cronJson"))
        cron_ids = safe_json_try_loads(decoded.get("cronIdsJson")) or []
        cron_list = parsed_cron if isinstance(parsed_cron, list) else []

        cron_with_next: list[dict[str, Any]] = []
        for i, trigger in enumerate(cron_list):
            cron_id = (
                cron_ids[i]
                if i < len(cron_ids)
                else self._compute_cron_id(
                    name,
                    trigger.get("id"),
                    trigger.get("expression", ""),
                    trigger.get("timezone"),
                    trigger.get("input"),
                )
            )
            raw_next = await self.redis.zscore(K.cron_next(self.prefix), cron_id)
            entry = dict(trigger)
            if raw_next and _parse_redis_int(raw_next) > 0:
                entry["next_run_at"] = int(raw_next)
            cron_with_next.append(entry)

        result: WorkflowMeta = {
            "name": name,
            "app": (decoded.get("app") or "unknown").strip() or "unknown",
            "queue": decoded.get("queue", "default"),
            "max_concurrency": _normalize_max_concurrency(decoded.get("maxConcurrency", "1")),
            "updated_at": int(decoded.get("updatedAt", "0")),
        }
        max_attempts_raw = decoded.get("maxAttempts")
        if max_attempts_raw:
            result["max_attempts"] = int(max_attempts_raw)
        if cron_with_next:
            result["cron"] = cron_with_next

        return result

    async def list_workflows_meta(self) -> list[WorkflowMeta]:
        names = await self.list_workflows()
        results: list[WorkflowMeta] = []
        for name in names:
            meta = await self.get_workflow_meta(name)
            if meta:
                results.append(meta)
        return results

    async def get_stats(self) -> RunStats:
        by_status: dict[RunStatus, int] = {}
        total = 0
        for status in ALL_STATUSES:
            count = _parse_redis_int(await self.redis.zcard(K.runs_status(self.prefix, status)))
            by_status[status] = count
            total += count
        return {"total": total, "by_status": by_status}

    # ---------- run lifecycle ----------

    async def emit_workflow(
        self,
        workflow_name: str,
        input: Any,
        *,
        idempotency_key: str | None = None,
        idempotency_ttl: int | None = None,
        run_at: datetime | None = None,
    ) -> ConcreteRunHandle:
        return await self.run_by_name(
            workflow_name,
            input,
            idempotency_key=idempotency_key,
            idempotency_ttl=idempotency_ttl,
            run_at=run_at,
        )

    async def run_by_name(
        self,
        workflow_name: str,
        input: Any,
        *,
        idempotency_key: str | None = None,
        idempotency_ttl: int | None = None,
        run_at: datetime | None = None,
        queue_override: str | None = None,
        max_attempts_override: int | None = None,
    ) -> ConcreteRunHandle:
        queue_from_registry = await self._get_queue_for_workflow(workflow_name)
        queue = queue_override or queue_from_registry
        if not queue:
            raise UnknownWorkflowError(workflow_name)

        max_attempts = (
            max_attempts_override or await self._get_max_attempts_for_workflow(workflow_name) or DEFAULT_MAX_ATTEMPTS
        )

        return await self._enqueue_run(
            workflow_name=workflow_name,
            queue=queue,
            input=input,
            available_at=run_at,
            idempotency_key=idempotency_key,
            idempotency_ttl=idempotency_ttl,
            max_attempts=max_attempts,
        )

    async def cancel_run(self, run_id: str, *, reason: str = "") -> bool:
        run_key = K.run(self.prefix, run_id)
        ts = now_ms()

        requested_from = await self._request_cancellation(run_id, ts, reason)
        if requested_from == "__missing__":
            return False
        if requested_from in ("succeeded", "failed", "canceled"):
            return False
        if requested_from == "running":
            return True

        queue = _decode(await self.redis.hget(run_key, "queue")) or "default"

        canceled_now = await self.transition_run_status_if_current(run_id, requested_from, "canceled", ts)
        if canceled_now:
            await self._finalize_canceled_run_immediately(run_id, queue, ts)
            return True

        latest_status = _decode(await self.redis.hget(run_key, "status"))
        if latest_status in ("queued", "scheduled"):
            canceled_latest = await self.transition_run_status_if_current(run_id, latest_status, "canceled", ts)
            if canceled_latest:
                await self._finalize_canceled_run_immediately(run_id, queue, ts)
                return True

        final_status = _decode(await self.redis.hget(run_key, "status"))
        return final_status in ("running", "queued", "scheduled", "canceled")

    async def get_run(self, run_id: str) -> RunState | None:
        run_key = K.run(self.prefix, run_id)
        raw = await self.redis.hgetall(run_key)
        if not raw:
            return None

        data: dict[str, str] = {_decode(k): _decode(v) for k, v in raw.items()}

        input_val = safe_json_loads(data.get("inputJson") or "null")
        output_val = safe_json_try_loads(data.get("outputJson"))
        error_val = safe_json_try_loads(data.get("errorJson"))

        result: RunState = {
            "id": run_id,
            "workflow": data.get("workflow", ""),
            "queue": data.get("queue", "default"),
            "status": data.get("status", "queued"),  # type: ignore[typeddict-item]
            "input": input_val,
            "attempt": int(data.get("attempt", "0")),
            "max_attempts": int(data.get("maxAttempts", str(DEFAULT_MAX_ATTEMPTS))),
            "created_at": int(data.get("createdAt", "0")),
        }
        if output_val is not None:
            result["output"] = output_val
        if error_val is not None:
            result["error"] = error_val
        if data.get("availableAt"):
            result["available_at"] = int(data["availableAt"])
        if data.get("startedAt"):
            result["started_at"] = int(data["startedAt"])
        if data.get("finishedAt"):
            result["finished_at"] = int(data["finishedAt"])
        if data.get("cancelRequestedAt"):
            result["cancel_requested_at"] = int(data["cancelRequestedAt"])
        if data.get("cancelReason"):
            result["cancel_reason"] = data["cancelReason"]

        return result

    async def get_run_steps(self, run_id: str) -> list[StepState]:
        steps_key = K.run_steps(self.prefix, run_id)
        raw = await self.redis.hgetall(steps_key)

        entries: list[tuple[int, StepState]] = []
        for name_raw, value_raw in raw.items():
            name = _decode(name_raw)
            try:
                parsed = safe_json_loads(_decode(value_raw))
            except (ValueError, Exception):
                entries.append((0, {"name": name, "status": "running"}))
                continue

            if not isinstance(parsed, dict):
                entries.append((0, {"name": name, "status": "running"}))
                continue

            order = parsed.get("seq", parsed.get("startedAt", 0))

            step: StepState = {"name": name, "status": parsed.get("status", "running")}
            if "startedAt" in parsed:
                step["started_at"] = parsed["startedAt"]
            if "finishedAt" in parsed:
                step["finished_at"] = parsed["finishedAt"]

            out = safe_json_try_loads(parsed.get("outputJson"))
            err = safe_json_try_loads(parsed.get("errorJson"))
            if out is not None:
                step["output"] = out
            if err is not None:
                step["error"] = err

            entries.append((order, step))

        entries.sort(key=lambda e: e[0])
        return [s for _, s in entries]

    async def list_runs(self, params: ListRunsParams | None = None) -> list[ListedRun]:
        p = params or ListRunsParams()
        limit = max(1, p.limit)
        offset = max(0, p.offset)

        if p.status and p.workflow:
            workflow_index_key = K.workflow_runs(self.prefix, p.workflow)
            result: list[ListedRun] = []
            cursor = 0
            skipped = 0
            batch_size = max(100, limit * 2)

            while len(result) < limit:
                run_ids_raw = await self.redis.zrevrange(workflow_index_key, cursor, cursor + batch_size - 1)
                if not run_ids_raw:
                    break
                cursor += len(run_ids_raw)

                for rid_raw in run_ids_raw:
                    rid = _decode(rid_raw)
                    run_state = await self.get_run(rid)
                    if not run_state or run_state.get("status") != p.status:
                        continue
                    if skipped < offset:
                        skipped += 1
                        continue
                    result.append(self._to_listed_run(run_state))
                    if len(result) >= limit:
                        break

            return result

        if p.status:
            index_key = K.runs_status(self.prefix, p.status)
        elif p.workflow:
            index_key = K.workflow_runs(self.prefix, p.workflow)
        else:
            index_key = K.runs_created(self.prefix)

        run_ids_raw = await self.redis.zrevrange(index_key, offset, offset + limit - 1)
        runs: list[ListedRun] = []
        for rid_raw in run_ids_raw:
            rid = _decode(rid_raw)
            run_state = await self.get_run(rid)
            if run_state:
                runs.append(self._to_listed_run(run_state))
        return runs

    def make_run_handle(self, run_id: str) -> ConcreteRunHandle:
        return ConcreteRunHandle(id=run_id, _client=self)

    async def wait_for_result(self, run_id: str, *, timeout_ms: int = 30_000) -> Any:
        deadline = now_ms() + timeout_ms
        missing_grace_ms = max(250, min(2000, _POLL_MS * 4))
        missing_since: int | None = None
        seen_state = False

        while True:
            state = await self.get_run(run_id)
            if not state:
                t = now_ms()
                if missing_since is None:
                    missing_since = t
                if t - missing_since >= missing_grace_ms:
                    if seen_state:
                        raise RedflowError(f"Run state unavailable: {run_id}")
                    raise RedflowError(f"Run not found: {run_id}")
                if t > deadline:
                    from .errors import TimeoutError

                    raise TimeoutError(f"Timed out waiting for run result ({run_id})")
                await asyncio.sleep(_POLL_MS / 1000)
                continue

            seen_state = True
            missing_since = None

            status = state.get("status")
            if status == "succeeded":
                return state.get("output")
            if status == "failed":
                raise RedflowError(f"Run failed: {safe_json_dumps(state.get('error'))}")
            if status == "canceled":
                cancel_reason = state.get("cancel_reason")
                raise CanceledError(f"Run canceled: {cancel_reason}" if cancel_reason else "Run canceled")

            if now_ms() > deadline:
                from .errors import TimeoutError

                raise TimeoutError(f"Timed out waiting for run result ({run_id})")
            await asyncio.sleep(_POLL_MS / 1000)

    # ---------- registry sync ----------

    async def sync_registry(self, registry: WorkflowRegistry, *, app: str) -> None:
        app = app.strip()
        if not app:
            raise ValueError("sync_registry requires a non-empty app")

        defs = registry.list()
        sync_started_at = now_ms()
        registered_names = {d.options.name for d in defs}

        await self._cleanup_stale_workflows(registered_names, sync_started_at, app)

        for defn in defs:
            opts = defn.options
            name = opts.name
            queue = opts.queue
            max_concurrency = _normalize_max_concurrency(opts.max_concurrency)
            cron = opts.cron
            max_attempts = opts.max_attempts
            updated_at = now_ms()

            custom_cron_ids: set[str] = set()
            for c in cron:
                if c.id:
                    if c.id in custom_cron_ids:
                        raise ValueError(f"Duplicate cron trigger id '{c.id}' in workflow '{name}'")
                    custom_cron_ids.add(c.id)

            workflow_key = K.workflow(self.prefix, name)
            await self.redis.sadd(K.workflows(self.prefix), name)

            prev_cron_ids_raw = await self.redis.hget(workflow_key, "cronIdsJson")
            prev_cron_ids = safe_json_try_loads(_decode(prev_cron_ids_raw)) or []
            next_cron_ids = [self._compute_cron_id(name, c.id, c.expression, c.timezone, c.input) for c in cron]

            next_cron_id_set = set(next_cron_ids)
            for old_id in prev_cron_ids:
                if old_id not in next_cron_id_set:
                    await self.redis.hdel(K.cron_def(self.prefix), old_id)
                    await self.redis.zrem(K.cron_next(self.prefix), old_id)

            for i, c in enumerate(cron):
                cron_id = next_cron_ids[i]
                cron_input = c.input if c.input is not None else {}

                cron_def_data = {
                    "id": cron_id,
                    "workflow": name,
                    "queue": queue,
                    "maxConcurrency": max_concurrency,
                    "expression": c.expression,
                    "timezone": c.timezone,
                    "inputJson": safe_json_dumps(cron_input),
                }
                await self.redis.hset(K.cron_def(self.prefix), cron_id, safe_json_dumps(cron_def_data))

                next_at = self._compute_next_cron_at_ms(c.expression, c.timezone)
                if next_at is not None:
                    await self.redis.zadd(K.cron_next(self.prefix), {cron_id: next_at})
                else:
                    await self.redis.zrem(K.cron_next(self.prefix), cron_id)

            meta: dict[str, str] = {
                "name": name,
                "queue": queue,
                "maxConcurrency": str(max_concurrency),
                "app": app,
                "updatedAt": str(updated_at),
                "cronJson": safe_json_dumps([_cron_to_dict(c) for c in cron]),
                "cronIdsJson": safe_json_dumps(next_cron_ids),
            }
            if max_attempts is not None:
                meta["maxAttempts"] = str(max_attempts)

            await self.redis.hset(workflow_key, mapping=meta)

    # ---------- status transitions (used by worker) ----------

    async def transition_run_status(self, run_id: str, next_status: RunStatus, updated_at: int) -> None:
        status_index_prefix = K.runs_status(self.prefix, "")
        running_count_key = await self._resolve_workflow_running_key(run_id) or K.workflow_running(
            self.prefix, "__unknown__"
        )
        result = await TRANSITION_RUN_STATUS.execute(
            self.redis,
            keys=[K.run(self.prefix, run_id), K.runs_status(self.prefix, next_status), running_count_key],
            args=[run_id, next_status, str(updated_at), status_index_prefix],
        )
        if _decode(result) == "__missing__":
            raise RedflowError(f"Run not found: {run_id}")

    async def schedule_retry(
        self,
        run_id: str,
        *,
        queue: str,
        next_at: int,
        error_json: str,
        updated_at: int,
        workflow_name: str | None = None,
    ) -> str:
        """Returns ``"scheduled"``, ``"canceled"``, or ``"__missing__"``."""
        run_key = K.run(self.prefix, run_id)
        wf_name = workflow_name or _decode(await self.redis.hget(run_key, "workflow")) or ""
        running_count_key = K.workflow_running(self.prefix, wf_name or "__unknown__")
        status_index_prefix = K.runs_status(self.prefix, "")
        result = await SCHEDULE_RETRY.execute(
            self.redis,
            keys=[
                run_key,
                K.runs_status(self.prefix, "scheduled"),
                K.queue_scheduled(self.prefix, queue),
                K.runs_status(self.prefix, "canceled"),
                running_count_key,
            ],
            args=[run_id, str(updated_at), str(next_at), error_json, status_index_prefix],
        )
        return _decode(result)

    async def transition_run_status_if_current(
        self,
        run_id: str,
        expected_status: str,
        next_status: RunStatus,
        updated_at: int,
    ) -> bool:
        running_count_key = K.workflow_running(self.prefix, "__unused__")
        if expected_status == "running" or next_status == "running":
            running_count_key = await self._resolve_workflow_running_key(run_id) or K.workflow_running(
                self.prefix, "__unknown__"
            )

        changed = await TRANSITION_IF_CURRENT_STATUS.execute(
            self.redis,
            keys=[
                K.run(self.prefix, run_id),
                K.runs_status(self.prefix, expected_status),
                K.runs_status(self.prefix, next_status),
                running_count_key,
            ],
            args=[run_id, expected_status, next_status, str(updated_at)],
        )
        return changed == 1 or changed == b"1"

    async def finalize_run(
        self,
        run_id: str,
        *,
        status: RunStatus,
        output_json: str | None = None,
        error_json: str | None = None,
        finished_at: int,
        workflow_name: str | None = None,
    ) -> None:
        run_key = K.run(self.prefix, run_id)
        wf_name = workflow_name or _decode(await self.redis.hget(run_key, "workflow")) or ""
        running_count_key = K.workflow_running(self.prefix, wf_name or "__unknown__")

        result = await FINALIZE_TERMINAL_RUN.execute(
            self.redis,
            keys=[
                run_key,
                K.runs_status(self.prefix, "scheduled"),
                K.runs_status(self.prefix, "queued"),
                K.runs_status(self.prefix, "running"),
                K.runs_status(self.prefix, "succeeded"),
                K.runs_status(self.prefix, "failed"),
                K.runs_status(self.prefix, "canceled"),
                running_count_key,
            ],
            args=[
                run_id,
                status,
                str(finished_at),
                output_json or "",
                error_json or "",
                "1" if output_json is not None else "0",
                "1" if error_json is not None else "0",
            ],
        )
        decoded_result = _decode(result)
        if decoded_result == "__missing__":
            raise RedflowError(f"Run not found: {run_id}")

    async def promote_scheduled_run_if_due(
        self,
        run_id: str,
        *,
        queue: str,
        due_at: int,
        updated_at: int,
    ) -> str:
        """Returns ``"promoted"``, ``"not_due"``, ``"missing"``, or ``"stale"``."""
        result = await PROMOTE_SCHEDULED_RUN.execute(
            self.redis,
            keys=[
                K.run(self.prefix, run_id),
                K.queue_scheduled(self.prefix, queue),
                K.runs_status(self.prefix, "scheduled"),
                K.runs_status(self.prefix, "queued"),
                K.queue_ready(self.prefix, queue),
            ],
            args=[run_id, str(updated_at), str(due_at)],
        )
        decoded = _decode(result)
        if decoded in ("promoted", "not_due", "missing", "stale"):
            return decoded
        return "missing"

    async def transition_queued_to_running(
        self,
        run_id: str,
        *,
        workflow_name: str,
        max_concurrency: int,
        updated_at: int,
    ) -> int:
        """Returns 2 (moved), 1 (concurrency limit), or 0 (not queued/missing)."""
        result = await TRANSITION_QUEUED_TO_RUNNING.execute(
            self.redis,
            keys=[
                K.run(self.prefix, run_id),
                K.runs_status(self.prefix, "queued"),
                K.runs_status(self.prefix, "running"),
                K.workflow_running(self.prefix, workflow_name),
            ],
            args=[
                run_id,
                str(updated_at),
                workflow_name,
                str(max_concurrency),
                K.run(self.prefix, ""),
            ],
        )
        try:
            return int(result)
        except (TypeError, ValueError):
            return 0

    # ---------- internal ----------

    async def _resolve_workflow_running_key(self, run_id: str) -> str | None:
        workflow_name = _decode(await self.redis.hget(K.run(self.prefix, run_id), "workflow"))
        if not workflow_name:
            return None
        return K.workflow_running(self.prefix, workflow_name)

    async def _get_queue_for_workflow(self, workflow_name: str) -> str | None:
        raw = await self.redis.hget(K.workflow(self.prefix, workflow_name), "queue")
        return _decode(raw) if raw else None

    async def _get_max_attempts_for_workflow(self, workflow_name: str) -> int | None:
        raw = await self.redis.hget(K.workflow(self.prefix, workflow_name), "maxAttempts")
        if not raw:
            return None
        try:
            v = int(raw)
            return v if v > 0 else None
        except (TypeError, ValueError):
            return None

    def _compute_cron_id(
        self,
        workflow_name: str,
        user_id: str | None,
        expression: str,
        timezone: str | None,
        input: Any,
    ) -> str:
        if user_id:
            stable = safe_json_dumps({"workflowName": workflow_name, "userId": user_id})
            h = hashlib.sha256(stable.encode()).hexdigest()[:24]
            return f"cron_user_{h}"

        obj: dict[str, Any] = {
            "workflowName": workflow_name,
            "expression": expression,
            "timezone": timezone,
        }
        if input is not None:
            obj["input"] = input
        stable = safe_json_dumps(obj)
        h = hashlib.sha256(stable.encode()).hexdigest()[:24]
        return f"cron_auto_{h}"

    def _compute_next_cron_at_ms(self, expression: str, timezone: str | None) -> int | None:
        try:
            from croniter import croniter

            if timezone:
                from zoneinfo import ZoneInfo

                start = datetime.now(ZoneInfo(timezone))
            else:
                start = datetime.now()
            cron = croniter(expression, start)
            next_dt = cron.get_next(datetime)
            return int(next_dt.timestamp() * 1000)
        except Exception:
            return None

    async def _cleanup_stale_workflows(
        self,
        registered_names: set[str],
        sync_started_at: int,
        app: str,
    ) -> None:
        existing_names = await self.list_workflows()
        for name in existing_names:
            if name in registered_names:
                continue
            wf_key = K.workflow(self.prefix, name)
            wf_app = (_decode(await self.redis.hget(wf_key, "app"))).strip()
            is_legacy_unscoped = wf_app == "" or wf_app == "unknown"
            if not is_legacy_unscoped and wf_app != app:
                continue
            updated_at = int(_decode(await self.redis.hget(wf_key, "updatedAt")) or "0")
            if updated_at > 0 and sync_started_at - updated_at < _STALE_WORKFLOW_GRACE_MS:
                continue
            await self._delete_workflow_metadata(name)

    async def _delete_workflow_metadata(self, workflow_name: str) -> None:
        wf_key = K.workflow(self.prefix, workflow_name)
        prev_cron_ids = safe_json_try_loads(_decode(await self.redis.hget(wf_key, "cronIdsJson"))) or []
        for cron_id in prev_cron_ids:
            await self.redis.hdel(K.cron_def(self.prefix), cron_id)
            await self.redis.zrem(K.cron_next(self.prefix), cron_id)
        await self.redis.delete(wf_key)
        await self.redis.srem(K.workflows(self.prefix), workflow_name)

    async def _request_cancellation(self, run_id: str, requested_at: int, reason: str) -> str:
        result = await REQUEST_CANCELLATION.execute(
            self.redis,
            keys=[K.run(self.prefix, run_id)],
            args=[str(requested_at), reason],
        )
        decoded = _decode(result)
        return decoded if decoded else "__missing__"

    async def _finalize_canceled_run_immediately(self, run_id: str, queue: str, finished_at: int) -> None:
        run_key = K.run(self.prefix, run_id)
        await self.redis.zrem(K.queue_scheduled(self.prefix, queue), run_id)
        await self.redis.lrem(K.queue_ready(self.prefix, queue), 0, run_id)
        await self.redis.lrem(K.queue_processing(self.prefix, queue), 0, run_id)
        await self.redis.hdel(run_key, "availableAt")
        await self.redis.hdel(run_key, "outputJson")
        await self.redis.hdel(run_key, "errorJson")
        await self.redis.hset(run_key, mapping={"finishedAt": str(finished_at)})

    async def _enqueue_run(
        self,
        *,
        workflow_name: str,
        queue: str,
        input: Any,
        available_at: datetime | None = None,
        idempotency_key: str | None = None,
        idempotency_ttl: int | None = None,
        max_attempts: int,
    ) -> ConcreteRunHandle:
        created_at = now_ms()
        available_at_ms: int | None = None
        if available_at and _is_valid_datetime(available_at):
            available_at_ms = int(available_at.timestamp() * 1000)

        should_schedule = available_at_ms is not None and available_at_ms > created_at
        run_id = f"run_{uuid.uuid4()}"
        status: RunStatus = "scheduled" if should_schedule else "queued"
        run_key = K.run(self.prefix, run_id)

        idempotency_redis_key = (
            K.idempotency(self.prefix, workflow_name, idempotency_key)
            if idempotency_key
            else K.idempotency(self.prefix, "__unused__", run_id)
        )

        result = await ENQUEUE_RUN.execute(
            self.redis,
            keys=[
                run_key,
                K.runs_created(self.prefix),
                K.runs_status(self.prefix, status),
                K.workflow_runs(self.prefix, workflow_name),
                K.queue_ready(self.prefix, queue),
                K.queue_scheduled(self.prefix, queue),
                idempotency_redis_key,
            ],
            args=[
                run_id,
                workflow_name,
                queue,
                status,
                safe_json_dumps(input),
                str(created_at),
                str(available_at_ms) if should_schedule else "",
                str(max_attempts),
                "1" if idempotency_key else "0",
                str(idempotency_ttl or IDEMPOTENCY_TTL_SEC),
                K.run(self.prefix, ""),
            ],
        )

        parsed = _parse_enqueue_result(result)
        if not parsed:
            raise RedflowError(f"Failed to enqueue run '{workflow_name}': unexpected Redis response")

        kind, actual_run_id = parsed
        if kind == "existing":
            await self._repair_existing_run_placement(actual_run_id)

        return self.make_run_handle(actual_run_id)

    async def _repair_existing_run_placement(self, run_id: str) -> None:
        run_key = K.run(self.prefix, run_id)
        raw = await self.redis.hgetall(run_key)
        if not raw:
            return

        data: dict[str, str] = {_decode(k): _decode(v) for k, v in raw.items()}
        status = data.get("status")
        queue = data.get("queue", "default")
        workflow_name = data.get("workflow", "")
        created_at_raw = data.get("createdAt", "0")
        created_at = int(created_at_raw) if created_at_raw.isdigit() and int(created_at_raw) > 0 else now_ms()

        await self.redis.zadd(K.runs_created(self.prefix), {run_id: created_at})
        if status:
            await self.redis.zadd(K.runs_status(self.prefix, status), {run_id: created_at})
        if workflow_name:
            await self.redis.zadd(K.workflow_runs(self.prefix, workflow_name), {run_id: created_at})

        if status == "queued":
            ready_key = K.queue_ready(self.prefix, queue)
            processing_key = K.queue_processing(self.prefix, queue)
            ready_list = [_decode(x) for x in await self.redis.lrange(ready_key, 0, -1)]
            processing_list = [_decode(x) for x in await self.redis.lrange(processing_key, 0, -1)]
            if run_id not in ready_list and run_id not in processing_list:
                await self.redis.lpush(ready_key, run_id)

        elif status == "scheduled":
            scheduled_key = K.queue_scheduled(self.prefix, queue)
            score = await self.redis.zscore(scheduled_key, run_id)
            if score is None:
                available_at_raw = data.get("availableAt", "0")
                available_at = (
                    int(available_at_raw) if available_at_raw.isdigit() and int(available_at_raw) > 0 else now_ms()
                )
                await self.redis.zadd(scheduled_key, {run_id: available_at})

    @staticmethod
    def _to_listed_run(run: RunState) -> ListedRun:
        result: ListedRun = {
            "id": run["id"],
            "workflow": run["workflow"],
            "queue": run["queue"],
            "status": run["status"],
            "created_at": run["created_at"],
            "attempt": run["attempt"],
            "max_attempts": run["max_attempts"],
        }
        if "error" in run:
            result["error"] = run["error"]
        if "available_at" in run:
            result["available_at"] = run["available_at"]
        if "started_at" in run:
            result["started_at"] = run["started_at"]
        if "finished_at" in run:
            result["finished_at"] = run["finished_at"]
        return result


# ---------- factory ----------


def create_client(
    *,
    redis: Redis[Any] | None = None,
    url: str | None = None,
    prefix: str | None = None,
) -> RedflowClient:
    """Create a :class:`RedflowClient` with sensible defaults."""
    pfx = prefix or default_prefix()
    if redis is not None:
        return RedflowClient(redis, pfx)
    if url:
        return RedflowClient(Redis.from_url(url), pfx)
    return RedflowClient(Redis.from_url(os.environ.get("REDIS_URL", "redis://localhost:6379")), pfx)
