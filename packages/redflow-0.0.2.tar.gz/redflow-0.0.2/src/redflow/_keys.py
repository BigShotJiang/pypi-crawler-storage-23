"""Redis key layout — must stay in sync with the TypeScript ``keys.ts``."""

from __future__ import annotations


def with_prefix(prefix: str, suffix: str) -> str:
    p = prefix.rstrip(":")
    s = suffix.lstrip(":")
    return f"{p}:{s}"


def _encode_composite_part(value: str) -> str:
    return f"{len(value)}:{value}"


# ---------- key builders ----------


def workflows(prefix: str) -> str:
    return with_prefix(prefix, "workflows")


def workflow(prefix: str, workflow_name: str) -> str:
    return with_prefix(prefix, f"workflow:{workflow_name}")


def workflow_runs(prefix: str, workflow_name: str) -> str:
    return with_prefix(prefix, f"workflow-runs:{workflow_name}")


def workflow_running(prefix: str, workflow_name: str) -> str:
    return with_prefix(prefix, f"workflow-running:{workflow_name}")


def runs_created(prefix: str) -> str:
    return with_prefix(prefix, "runs:created")


def runs_status(prefix: str, status: str) -> str:
    return with_prefix(prefix, f"runs:status:{status}")


def run(prefix: str, run_id: str) -> str:
    return with_prefix(prefix, f"run:{run_id}")


def run_steps(prefix: str, run_id: str) -> str:
    return with_prefix(prefix, f"run:{run_id}:steps")


def run_lease(prefix: str, run_id: str) -> str:
    return with_prefix(prefix, f"run:{run_id}:lease")


def queue_ready(prefix: str, queue: str) -> str:
    return with_prefix(prefix, f"q:{queue}:ready")


def queue_processing(prefix: str, queue: str) -> str:
    return with_prefix(prefix, f"q:{queue}:processing")


def queue_scheduled(prefix: str, queue: str) -> str:
    return with_prefix(prefix, f"q:{queue}:scheduled")


def cron_def(prefix: str) -> str:
    return with_prefix(prefix, "cron:def")


def cron_next(prefix: str) -> str:
    return with_prefix(prefix, "cron:next")


def lock_cron(prefix: str) -> str:
    return with_prefix(prefix, "lock:cron")


def idempotency(prefix: str, workflow_name: str, idempotency_key: str) -> str:
    return with_prefix(
        prefix,
        f"idempo:{_encode_composite_part(workflow_name)}:{_encode_composite_part(idempotency_key)}",
    )
