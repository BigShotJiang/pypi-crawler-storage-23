"""
VLA vs Standard Training - GPT-2 on WikiText-2
===============================================
Real test to verify PPL improvement claim.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import math
import time
import sys

sys.path.insert(0, '/mnt/c/SimGen')

# Check CUDA
assert torch.cuda.is_available(), "CUDA required"
device = torch.device('cuda')
print(f"Device: {torch.cuda.get_device_name()}")

# =============================================================================
# LOAD WIKITEXT-2
# =============================================================================

def load_wikitext2():
    """Load WikiText-2 dataset."""
    try:
        from datasets import load_dataset
        dataset = load_dataset('wikitext', 'wikitext-2-raw-v1')
        return dataset['train']['text'], dataset['validation']['text']
    except ImportError:
        print("Installing datasets...")
        import subprocess
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'datasets', '-q'])
        from datasets import load_dataset
        dataset = load_dataset('wikitext', 'wikitext-2-raw-v1')
        return dataset['train']['text'], dataset['validation']['text']


class WikiTextDataset(Dataset):
    def __init__(self, texts, tokenizer, seq_len=128):
        self.seq_len = seq_len
        # Simple character-level tokenization for speed
        all_text = '\n'.join([t for t in texts if t.strip()])

        # Build vocab from text
        chars = sorted(set(all_text))
        self.vocab_size = len(chars)
        self.char_to_idx = {c: i for i, c in enumerate(chars)}
        self.idx_to_char = {i: c for c, i in self.char_to_idx.items()}

        # Encode
        self.data = torch.tensor([self.char_to_idx.get(c, 0) for c in all_text], dtype=torch.long)

    def __len__(self):
        return max(0, len(self.data) - self.seq_len - 1)

    def __getitem__(self, idx):
        x = self.data[idx:idx + self.seq_len]
        y = self.data[idx + 1:idx + self.seq_len + 1]
        return x, y


# =============================================================================
# MINI GPT-2
# =============================================================================

class MiniGPT2(nn.Module):
    """Small GPT-2 for testing."""

    def __init__(self, vocab_size, dim=256, n_heads=4, n_layers=4, seq_len=128, dropout=0.1):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, dim)
        self.pos_embed = nn.Embedding(seq_len, dim)
        self.drop = nn.Dropout(dropout)

        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(
                d_model=dim, nhead=n_heads, dim_feedforward=dim*4,
                dropout=dropout, batch_first=True, norm_first=True
            ) for _ in range(n_layers)
        ])

        self.ln = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab_size, bias=False)
        self.seq_len = seq_len

        # Weight tying
        self.head.weight = self.embed.weight

        # Init
        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, x):
        B, T = x.shape
        pos = torch.arange(T, device=x.device)

        x = self.drop(self.embed(x) + self.pos_embed(pos))

        # Causal mask
        mask = torch.triu(torch.ones(T, T, device=x.device), diagonal=1).bool()

        for layer in self.layers:
            x = layer(x, src_mask=mask, is_causal=True)

        x = self.ln(x)
        return self.head(x)


def train_epoch(model, dataloader, optimizer, use_vla=False, max_steps=None):
    """Train for one epoch."""
    model.train()
    total_loss = 0
    n_batches = 0

    if use_vla:
        from simgen import vla
        vla.enable_vla(verbose=False)

    for i, (x, y) in enumerate(dataloader):
        if max_steps and i >= max_steps:
            break

        x, y = x.to(device), y.to(device)

        optimizer.zero_grad()
        logits = model(x)
        loss = F.cross_entropy(logits.view(-1, logits.size(-1)), y.view(-1))
        loss.backward()

        # Gradient clipping
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        total_loss += loss.item()
        n_batches += 1

    if use_vla:
        from simgen import vla
        vla.disable_vla(verbose=False)

    return total_loss / n_batches


def evaluate(model, dataloader, use_vla=False, max_steps=None):
    """Evaluate and return perplexity."""
    model.eval()
    total_loss = 0
    n_batches = 0

    if use_vla:
        from simgen import vla
        vla.enable_vla(verbose=False)

    with torch.no_grad():
        for i, (x, y) in enumerate(dataloader):
            if max_steps and i >= max_steps:
                break

            x, y = x.to(device), y.to(device)
            logits = model(x)
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), y.view(-1))
            total_loss += loss.item()
            n_batches += 1

    if use_vla:
        from simgen import vla
        vla.disable_vla(verbose=False)

    avg_loss = total_loss / n_batches
    return math.exp(avg_loss), avg_loss


# =============================================================================
# MAIN TEST
# =============================================================================

print("="*70)
print("VLA vs Standard Training - GPT-2 on WikiText-2")
print("="*70)

# Load data
print("\nLoading WikiText-2...")
train_texts, val_texts = load_wikitext2()
print(f"Train texts: {len(train_texts)}, Val texts: {len(val_texts)}")

# Create datasets
SEQ_LEN = 128
BATCH_SIZE = 32
train_dataset = WikiTextDataset(train_texts, None, SEQ_LEN)
val_dataset = WikiTextDataset(val_texts, None, SEQ_LEN)
print(f"Vocab size: {train_dataset.vocab_size}")
print(f"Train samples: {len(train_dataset)}, Val samples: {len(val_dataset)}")

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, drop_last=True)

# Training config
N_EPOCHS = 3
LR = 3e-4
MAX_TRAIN_STEPS = 500  # Per epoch
MAX_VAL_STEPS = 100

# =============================================================================
# TEST 1: Standard Training
# =============================================================================

print("\n" + "="*70)
print("TEST 1: Standard PyTorch Training")
print("="*70)

torch.manual_seed(42)
torch.cuda.manual_seed(42)

model_std = MiniGPT2(train_dataset.vocab_size, dim=256, n_heads=4, n_layers=4).to(device)
optimizer_std = torch.optim.AdamW(model_std.parameters(), lr=LR, weight_decay=0.01)

print(f"Model params: {sum(p.numel() for p in model_std.parameters()):,}")

std_losses = []
std_ppls = []
start_time = time.time()

for epoch in range(N_EPOCHS):
    train_loss = train_epoch(model_std, train_loader, optimizer_std, use_vla=False, max_steps=MAX_TRAIN_STEPS)
    val_ppl, val_loss = evaluate(model_std, val_loader, use_vla=False, max_steps=MAX_VAL_STEPS)
    std_losses.append(train_loss)
    std_ppls.append(val_ppl)
    print(f"  Epoch {epoch+1}: Train Loss={train_loss:.4f}, Val PPL={val_ppl:.2f}")

std_time = time.time() - start_time
std_final_ppl = std_ppls[-1]

# =============================================================================
# TEST 2: VLA Training
# =============================================================================

print("\n" + "="*70)
print("TEST 2: VLA Training (exact arithmetic)")
print("="*70)

torch.manual_seed(42)
torch.cuda.manual_seed(42)

model_vla = MiniGPT2(train_dataset.vocab_size, dim=256, n_heads=4, n_layers=4).to(device)
optimizer_vla = torch.optim.AdamW(model_vla.parameters(), lr=LR, weight_decay=0.01)

vla_losses = []
vla_ppls = []
start_time = time.time()

for epoch in range(N_EPOCHS):
    train_loss = train_epoch(model_vla, train_loader, optimizer_vla, use_vla=True, max_steps=MAX_TRAIN_STEPS)
    val_ppl, val_loss = evaluate(model_vla, val_loader, use_vla=True, max_steps=MAX_VAL_STEPS)
    vla_losses.append(train_loss)
    vla_ppls.append(val_ppl)
    print(f"  Epoch {epoch+1}: Train Loss={train_loss:.4f}, Val PPL={val_ppl:.2f}")

vla_time = time.time() - start_time
vla_final_ppl = vla_ppls[-1]

# =============================================================================
# RESULTS
# =============================================================================

print("\n" + "="*70)
print("RESULTS")
print("="*70)

ppl_improvement = (std_final_ppl - vla_final_ppl) / std_final_ppl * 100

print(f"\n{'Method':<20} {'Final PPL':>12} {'Time':>10} {'PPL Change':>15}")
print("-"*60)
print(f"{'Standard PyTorch':<20} {std_final_ppl:>12.2f} {std_time:>9.1f}s {'baseline':>15}")
print(f"{'VLA (exact)':<20} {vla_final_ppl:>12.2f} {vla_time:>9.1f}s {ppl_improvement:>+14.1f}%")

print("\nPer-epoch PPL:")
print(f"  Standard: {' -> '.join(f'{p:.2f}' for p in std_ppls)}")
print(f"  VLA:      {' -> '.join(f'{p:.2f}' for p in vla_ppls)}")

if ppl_improvement > 0:
    print(f"\n✓ VLA improved PPL by {ppl_improvement:.1f}%")
else:
    print(f"\n✗ VLA did not improve PPL (change: {ppl_improvement:.1f}%)")

print("\n" + "="*70)
