"""
VLA Runtime v2.0 Test
"""
import sys
sys.path.insert(0, '/mnt/c/SimGen/simgen')

print("="*60)
print("VLA RUNTIME v2.0 TEST")
print("="*60)

import vla_runtime as vla
print(f"Version: {vla.__version__}")
info = vla.get_backend_info()
print(f"Backend: {info['backend']}")
print(f"Device: {info['device']}")

import torch
torch.manual_seed(42)
device = 'cuda'

# Test vla_sum with return_vla
print("\n--- vla_sum ---")
x = torch.randn(10000, device=device, dtype=torch.float32)
result = vla.vla_sum(x, return_vla=True)
print(f"VLAResult: {result.n_limbs} limbs")
print(f"Collapsed: {result.collapse().item():.10f}")

# Test vla_matmul with return_vla
print("\n--- vla_matmul ---")
a = torch.randn(64, 128, device=device, dtype=torch.float32)
b = torch.randn(128, 64, device=device, dtype=torch.float32)
result = vla.vla_matmul(a, b, return_vla=True)
collapsed = result.collapse()
print(f"VLAResult: {result.n_limbs} limbs, collapsed shape {collapsed.shape}")

# Test vla_bmm
print("\n--- vla_bmm ---")
a = torch.randn(4, 16, 32, device=device, dtype=torch.float32)
b = torch.randn(4, 32, 16, device=device, dtype=torch.float32)
result = vla.vla_bmm(a, b, return_vla=True)
collapsed = result.collapse()
print(f"VLAResult: {result.n_limbs} limbs, collapsed shape {collapsed.shape}")

# Test vla_conv2d
print("\n--- vla_conv2d ---")
x = torch.randn(1, 3, 16, 16, device=device, dtype=torch.float32)
w = torch.randn(32, 3, 3, 3, device=device, dtype=torch.float32)
result = vla.vla_conv2d(x, w, return_vla=True)
collapsed = result.collapse()
print(f"VLAResult: {result.n_limbs} limbs, collapsed shape {collapsed.shape}")

# Test vla_conv_transpose2d
print("\n--- vla_conv_transpose2d ---")
x = torch.randn(1, 32, 8, 8, device=device, dtype=torch.float32)
w = torch.randn(32, 16, 3, 3, device=device, dtype=torch.float32)
result = vla.vla_conv_transpose2d(x, w, stride=2, padding=1, return_vla=True)
collapsed = result.collapse()
print(f"VLAResult: {result.n_limbs} limbs, collapsed shape {collapsed.shape}")

# Test vla_einsum
print("\n--- vla_einsum ---")
a = torch.randn(500, device=device, dtype=torch.float32)
b = torch.randn(500, device=device, dtype=torch.float32)
result = vla.vla_einsum('i,i->', a, b, return_vla=True)
print(f"VLAResult: {result.n_limbs} limbs")
print(f"to_decimal: {result.to_decimal()}")

# Test VLAAdamW
print("\n--- VLAAdamW ---")
import torch.nn as nn
model = nn.Linear(64, 32).to(device)
opt = vla.VLAAdamW(model.parameters(), lr=0.01)
for _ in range(50):
    opt.zero_grad()
    loss = model(torch.randn(8, 64, device=device)).pow(2).mean()
    loss.backward()
    opt.step()
state = list(opt.state.values())[0]
print(f"FP64 exp_avg: {state['exp_avg'].dtype}")
print(f"FP64 exp_avg_sq: {state['exp_avg_sq'].dtype}")

# Test VLASGD
print("\n--- VLASGD ---")
model2 = nn.Linear(64, 32).to(device)
opt2 = vla.VLASGD(model2.parameters(), lr=0.01, momentum=0.9)
for _ in range(50):
    opt2.zero_grad()
    loss = model2(torch.randn(8, 64, device=device)).pow(2).mean()
    loss.backward()
    opt2.step()
state2 = list(opt2.state.values())[0]
print(f"FP64 momentum: {state2['momentum_buffer'].dtype}")

print("\n" + "="*60)
print("VLA RUNTIME v2.0: ALL TESTS PASSED!")
print("="*60)
