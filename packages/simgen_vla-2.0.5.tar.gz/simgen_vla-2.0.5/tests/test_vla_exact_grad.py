"""
Test VLAMatmulFunction for truly exact gradients
"""
import torch
import sys
sys.path.insert(0, 'C:/SimGen')

device = 'cuda'
print(f"Device: {torch.cuda.get_device_name()}")

from simgen import vla

print("\n" + "="*60)
print("VLAMatmulFunction.apply - Truly Exact Gradients?")
print("="*60)

torch.manual_seed(42)

# Create tensors
A = torch.randn(64, 64, device=device, dtype=torch.float32, requires_grad=True)
B = torch.randn(64, 64, device=device, dtype=torch.float32, requires_grad=True)

# Ground truth: FP64
A_f64 = A.detach().double().requires_grad_(True)
B_f64 = B.detach().double().requires_grad_(True)
C_f64 = torch.matmul(A_f64, B_f64)
loss_f64 = C_f64.sum()
loss_f64.backward()
grad_A_gt = A_f64.grad.clone()
grad_B_gt = B_f64.grad.clone()

# Standard FP32
A_std = A.detach().float().requires_grad_(True)
B_std = B.detach().float().requires_grad_(True)
C_std = torch.matmul(A_std, B_std)
loss_std = C_std.sum()
loss_std.backward()
grad_A_std = A_std.grad
grad_B_std = B_std.grad

std_err_A = (grad_A_std.double() - grad_A_gt).abs().max().item()
std_err_B = (grad_B_std.double() - grad_B_gt).abs().max().item()

print(f"\nStandard FP32:")
print(f"  grad_A error: {std_err_A:.2e}")
print(f"  grad_B error: {std_err_B:.2e}")

# VLA Autograd Function
A_vla = A.detach().float().requires_grad_(True)
B_vla = B.detach().float().requires_grad_(True)
C_vla = vla.VLAMatmulFunction.apply(A_vla, B_vla)
loss_vla = C_vla.sum()
loss_vla.backward()
grad_A_vla = A_vla.grad
grad_B_vla = B_vla.grad

vla_err_A = (grad_A_vla.double() - grad_A_gt).abs().max().item()
vla_err_B = (grad_B_vla.double() - grad_B_gt).abs().max().item()

print(f"\nVLAMatmulFunction.apply:")
print(f"  grad_A error: {vla_err_A:.2e}")
print(f"  grad_B error: {vla_err_B:.2e}")

print(f"\nImprovement:")
print(f"  grad_A: {std_err_A/max(vla_err_A, 1e-20):.1f}x more accurate")
print(f"  grad_B: {std_err_B/max(vla_err_B, 1e-20):.1f}x more accurate")

if vla_err_A == 0 and vla_err_B == 0:
    print("\n✓ TRULY EXACT GRADIENTS! Zero error!")
elif vla_err_A < std_err_A and vla_err_B < std_err_B:
    print("\n✓ Gradients improved but not zero")
    print("  (Conversion to FP32 at the end adds small error)")
