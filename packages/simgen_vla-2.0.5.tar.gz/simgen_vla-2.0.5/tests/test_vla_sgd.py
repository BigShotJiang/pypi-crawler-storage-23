"""
VLASGD Test - FP64 Momentum State
"""
import sys
sys.path.insert(0, '/mnt/c/SimGen/simgen')
import torch
import torch.nn as nn

import vla_triton as vla

print("="*60)
print("VLASGD TEST")
print("="*60)

torch.manual_seed(42)
device = "cuda"

# Test 1: Basic optimizer creation and training
print("\n--- Test 1: Create and Train ---")
model = nn.Linear(64, 32).to(device)
optimizer = vla.VLASGD(model.parameters(), lr=0.01, momentum=0.9)
print(f"Optimizer: {type(optimizer).__name__}")

x = torch.randn(16, 64, device=device)
target = torch.randn(16, 32, device=device)

for step in range(100):
    optimizer.zero_grad()
    out = model(x)
    loss = ((out - target) ** 2).mean()
    loss.backward()
    optimizer.step()

print(f"Final loss: {loss.item():.4f}")

# Test 2: Check state is FP64
print("\n--- Test 2: State Precision ---")
for p in model.parameters():
    if p in optimizer.state:
        state = optimizer.state[p]
        buf_dtype = state["momentum_buffer"].dtype
        print(f"momentum_buffer dtype: {buf_dtype}")
        print(f"FP64 state: {buf_dtype == torch.float64}")
        break

# Test 3: 1000-step drift comparison
print("\n--- Test 3: 1000-step Drift Comparison ---")
torch.manual_seed(42)

model_std = nn.Linear(64, 32).to(device)
opt_std = torch.optim.SGD(model_std.parameters(), lr=0.01, momentum=0.9)

model_vla = nn.Linear(64, 32).to(device)
model_vla.load_state_dict(model_std.state_dict())
opt_vla = vla.VLASGD(model_vla.parameters(), lr=0.01, momentum=0.9)

x = torch.randn(16, 64, device=device)
target = torch.randn(16, 32, device=device)

for step in range(1000):
    opt_std.zero_grad()
    loss_std = ((model_std(x) - target) ** 2).mean()
    loss_std.backward()
    opt_std.step()

    opt_vla.zero_grad()
    loss_vla = ((model_vla(x) - target) ** 2).mean()
    loss_vla.backward()
    opt_vla.step()

weight_diff = (model_std.weight.data - model_vla.weight.data.float()).abs().max().item()
print(f"Weight diff after 1000 steps: {weight_diff:.2e}")

# State comparison
for p_std, p_vla in zip(model_std.parameters(), model_vla.parameters()):
    if p_std in opt_std.state and p_vla in opt_vla.state:
        buf_std = opt_std.state[p_std]["momentum_buffer"]
        buf_vla = opt_vla.state[p_vla]["momentum_buffer"]
        buf_diff = (buf_std.double() - buf_vla).abs().max().item()
        print(f"Momentum buffer diff: {buf_diff:.2e}")
        print(f"Standard momentum dtype: {buf_std.dtype}")
        print(f"VLA momentum dtype: {buf_vla.dtype}")
        break

# Test 4: Nesterov momentum
print("\n--- Test 4: Nesterov Momentum ---")
torch.manual_seed(42)
model = nn.Linear(64, 32).to(device)
optimizer = vla.VLASGD(model.parameters(), lr=0.01, momentum=0.9, nesterov=True)

for step in range(100):
    optimizer.zero_grad()
    out = model(x)
    loss = ((out - target) ** 2).mean()
    loss.backward()
    optimizer.step()

print(f"Nesterov final loss: {loss.item():.4f}")
print("Nesterov momentum: OK")

print("\n" + "="*60)
print("VLASGD: FP64 MOMENTUM = NO DRIFT!")
print("="*60)
