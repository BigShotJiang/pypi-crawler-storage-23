"""Test VLA monkey-patching system."""
import torch
import torch.nn as nn
import torch.nn.functional as F
import sys
sys.path.insert(0, '/mnt/c/SimGen')

from simgen import vla

print("="*60)
print("VLA Monkey-Patch Test")
print("="*60)

# Test 1: Verify patching works
print("\n1. Testing enable_vla()")
print("-"*40)

# Before patching
x = torch.randn(4, 8, device='cuda')
w = torch.randn(16, 8, device='cuda')

result_before = F.linear(x, w)
print(f"Before VLA: F.linear result dtype = {result_before.dtype}")

# Enable VLA
vla.enable_vla()

result_after = F.linear(x, w)
print(f"After VLA: F.linear result dtype = {result_after.dtype}")

# Verify it's actually different (VLA uses FP64 internally)
print(f"Results match: {torch.allclose(result_before, result_after, atol=1e-5)}")

# Test 2: Cross-entropy with VLA
print("\n2. Testing VLA cross-entropy")
print("-"*40)

logits = torch.randn(32, 1000, device='cuda')
targets = torch.randint(0, 1000, (32,), device='cuda')

loss = F.cross_entropy(logits, targets)
print(f"VLA cross-entropy loss: {loss.item():.6f}")

# Test 3: Full model forward pass
print("\n3. Testing full model forward (SimpleGPT)")
print("-"*40)

class SimpleGPT(nn.Module):
    def __init__(self, vocab=1000, dim=128, heads=4, layers=2, seq=32):
        super().__init__()
        self.embed = nn.Embedding(vocab, dim)
        self.pos = nn.Embedding(seq, dim)
        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(dim, heads, dim*4, dropout=0, batch_first=True)
            for _ in range(layers)
        ])
        self.ln = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab, bias=False)
        self.seq = seq

    def forward(self, x):
        B, T = x.shape
        h = self.embed(x) + self.pos(torch.arange(T, device=x.device))
        for layer in self.layers:
            h = layer(h)
        h = self.ln(h)
        return self.head(h)

model = SimpleGPT().cuda()
x = torch.randint(0, 1000, (4, 32), device='cuda')
targets = torch.randint(0, 1000, (4, 32), device='cuda')

# Forward pass with VLA enabled (all internal ops use VLA)
logits = model(x)
loss = F.cross_entropy(logits.view(-1, 1000), targets.view(-1))
print(f"Forward pass successful!")
print(f"Loss: {loss.item():.4f}")

# Test backward
loss.backward()
print(f"Backward pass successful!")

# Test 4: Context manager
print("\n4. Testing vla_mode() context manager")
print("-"*40)

vla.disable_vla()
print(f"VLA enabled: {vla.is_vla_enabled()}")

with vla.vla_mode():
    print(f"Inside context: VLA enabled = {vla.is_vla_enabled()}")
    test_logits = torch.randn(4, 100, device='cuda')
    test_targets = torch.randint(0, 100, (4,), device='cuda')
    loss = F.cross_entropy(test_logits, test_targets)
    print(f"Loss in context: {loss.item():.4f}")

print(f"After context: VLA enabled = {vla.is_vla_enabled()}")

print("\n" + "="*60)
print("All tests passed!")
print("="*60)
