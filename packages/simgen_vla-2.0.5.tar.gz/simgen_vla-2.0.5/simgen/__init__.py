"""
SimGen VLA - TRUE ZERO ERROR GPU Computation
=============================================

Universal lossless arithmetic for PyTorch.
Multi-level error tracking captures ALL rounding error.

Usage:
    from simgen import vla

    # Exact operations with VLAResult
    result = vla.vla_sum(x, return_vla=True)   # Returns VLAResult with limbs
    result = vla.vla_matmul(a, b)              # Exact matrix multiplication

    # FP64 optimizer state (prevents drift)
    optimizer = vla.VLAAdamW(model.parameters(), lr=1e-3)
    optimizer = vla.VLASGD(model.parameters(), lr=0.01, momentum=0.9)

    # Check backend
    print(vla.get_backend_info())

Website: https://simgen.dev
License: Proprietary - All rights reserved
"""

__version__ = "2.0.5"
__author__ = "Clouthier Simulation Labs"

# Unified API: Triton (Linux) or Cubin (production)
from . import vla_runtime as vla

# Direct imports for convenience
from .vla_runtime import (
    VLAResult,
    VLAAdamW,
    VLASGD,
    get_backend_info,
)

__all__ = [
    "vla",
    "VLAResult",
    "VLAAdamW",
    "VLASGD",
    "get_backend_info",
    "__version__",
]
