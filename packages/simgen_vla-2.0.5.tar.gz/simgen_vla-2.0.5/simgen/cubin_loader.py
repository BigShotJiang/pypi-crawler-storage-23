"""
SimGen VLA Cubin Loader
=======================
Loads and launches precompiled CUDA kernels from cubin files.
No source code required at runtime - complete IP protection.
"""

import os
import json
import ctypes
import torch
from pathlib import Path
from typing import Dict, Optional, Tuple

# CUDA driver API - support both old and new bindings
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

try:
    # New API (cuda-bindings 12.x)
    from cuda.bindings import driver as cuda
    CUDA_AVAILABLE = True
except ImportError:
    try:
        # Old API (deprecated)
        import cuda.cuda as cuda
        CUDA_AVAILABLE = True
    except ImportError:
        CUDA_AVAILABLE = False

__all__ = ["CubinLoader", "get_gpu_arch", "SUPPORTED_ARCHS"]

SUPPORTED_ARCHS = [75, 80, 86, 89, 90]


def get_gpu_arch() -> int:
    """Get the compute capability of the current GPU."""
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA not available")
    props = torch.cuda.get_device_properties(0)
    return props.major * 10 + props.minor


def _find_best_arch(target_arch: int) -> int:
    """Find the best compatible architecture for the target GPU."""
    compatible = [a for a in SUPPORTED_ARCHS if a <= target_arch]
    if not compatible:
        raise RuntimeError(
            f"GPU architecture sm_{target_arch} is not supported. "
            f"Minimum required: sm_{min(SUPPORTED_ARCHS)}"
        )
    return max(compatible)


class CubinLoader:
    """
    Loads and manages precompiled CUDA kernels from cubin files.
    """

    def __init__(self, cubin_dir=None):
        if cubin_dir is None:
            # Get directory where this module is installed
            import os
            module_dir = os.path.dirname(os.path.abspath(__file__))
            cubin_dir = os.path.join(module_dir, "cubin")

        self.cubin_dir = Path(cubin_dir)
        self._modules: Dict[str, any] = {}
        self._kernels: Dict[str, "CubinKernel"] = {}
        self._metadata: Dict[str, dict] = {}

        # Load manifest
        manifest_path = self.cubin_dir / "manifest.json"
        if manifest_path.exists():
            with open(manifest_path) as f:
                self.manifest = json.load(f)
        else:
            self.manifest = {}

        # Detect GPU architecture
        self.gpu_arch = get_gpu_arch()
        self.cubin_arch = _find_best_arch(self.gpu_arch)
        self.sm_name = f"sm_{self.cubin_arch}"

        # Initialize CUDA
        if CUDA_AVAILABLE:
            self._init_cuda()

    def _init_cuda(self):
        """Initialize CUDA driver API."""
        # Ensure PyTorch has initialized CUDA first
        if torch.cuda.is_available():
            _ = torch.zeros(1, device="cuda")

        err, = cuda.cuInit(0)
        if err != cuda.CUresult.CUDA_SUCCESS:
            raise RuntimeError(f"CUDA init failed: {err}")

        err, self.context = cuda.cuCtxGetCurrent()
        if err != cuda.CUresult.CUDA_SUCCESS or not self.context:
            err, device = cuda.cuDeviceGet(0)
            err, self.context = cuda.cuCtxCreate(0, device)

    def _load_kernel(self, kernel_name: str) -> "CubinKernel":
        """Load a kernel and its metadata."""
        if kernel_name in self._kernels:
            return self._kernels[kernel_name]

        # Find cubin and metadata files
        cubin_file = f"{kernel_name}_{self.sm_name}.cubin"
        meta_file = f"{kernel_name}_{self.sm_name}.json"

        cubin_path = self.cubin_dir / cubin_file
        meta_path = self.cubin_dir / meta_file

        if not cubin_path.exists():
            raise FileNotFoundError(f"Cubin not found: {cubin_path}")
        if not meta_path.exists():
            raise FileNotFoundError(f"Metadata not found: {meta_path}")

        # Load metadata
        with open(meta_path) as f:
            metadata = json.load(f)

        # Load cubin
        with open(cubin_path, "rb") as f:
            cubin_data = f.read()

        # Load as CUDA module
        err, module = cuda.cuModuleLoadData(cubin_data)
        if err != cuda.CUresult.CUDA_SUCCESS:
            raise RuntimeError(f"Failed to load cubin: {err}")

        # Get kernel function
        err, function = cuda.cuModuleGetFunction(module, kernel_name.encode())
        if err != cuda.CUresult.CUDA_SUCCESS:
            raise RuntimeError(f"Failed to get function: {err}")

        self._modules[kernel_name] = module
        self._metadata[kernel_name] = metadata

        kernel = CubinKernel(function, kernel_name, metadata)
        self._kernels[kernel_name] = kernel
        return kernel

    def get_kernel(self, kernel_name: str) -> "CubinKernel":
        """Get a kernel by name."""
        return self._load_kernel(kernel_name)

    def list_kernels(self) -> list:
        """List all available kernel names."""
        return list(self.manifest.keys())

    def get_info(self) -> dict:
        """Get loader information."""
        return {
            "gpu_arch": self.gpu_arch,
            "cubin_arch": self.cubin_arch,
            "sm_name": self.sm_name,
            "cubin_dir": str(self.cubin_dir),
            "kernels_available": len(self.manifest),
            "kernels_loaded": len(self._kernels),
        }


class CubinKernel:
    """Wrapper for a loaded CUDA kernel function."""

    def __init__(self, function, name: str, metadata: dict):
        self.function = function
        self.name = name
        self.metadata = metadata
        self.num_warps = metadata.get("num_warps", 4)
        self.shared_mem = metadata.get("shared", 0)

    def __call__(self, grid: Tuple[int, ...], *args, stream=None):
        """Launch the kernel with the given grid and arguments.

        Args:
            grid: Tuple of (gridX,) or (gridX, gridY) or (gridX, gridY, gridZ)
            *args: Kernel arguments (tensors and scalars)
            stream: CUDA stream (None for default)
        """
        # Normalize grid to 3D
        if len(grid) == 1:
            grid = (grid[0], 1, 1)
        elif len(grid) == 2:
            grid = (grid[0], grid[1], 1)

        # Block size from num_warps (32 threads per warp)
        block = (self.num_warps * 32, 1, 1)

        # Build kernel parameters
        arg_values = []
        arg_ptrs = []

        for arg in args:
            if isinstance(arg, torch.Tensor):
                val = ctypes.c_uint64(arg.data_ptr())
                arg_values.append(val)
                arg_ptrs.append(ctypes.addressof(val))
            elif isinstance(arg, int):
                val = ctypes.c_int32(arg)
                arg_values.append(val)
                arg_ptrs.append(ctypes.addressof(val))
            elif isinstance(arg, float):
                val = ctypes.c_double(arg)
                arg_values.append(val)
                arg_ptrs.append(ctypes.addressof(val))
            else:
                raise TypeError(f"Unsupported argument type: {type(arg)}")

        # Add null scratch pointers (Triton adds 2 extra params for scratch memory)
        scratch1 = ctypes.c_uint64(0)
        scratch2 = ctypes.c_uint64(0)
        arg_values.extend([scratch1, scratch2])
        arg_ptrs.extend([ctypes.addressof(scratch1), ctypes.addressof(scratch2)])

        kernel_params = (ctypes.c_void_p * len(arg_ptrs))(*arg_ptrs)

        # Get stream
        if stream is None:
            stream = cuda.CUstream(0)

        # Launch
        err, = cuda.cuLaunchKernel(
            self.function,
            grid[0], grid[1], grid[2],
            block[0], block[1], block[2],
            self.shared_mem,
            stream,
            kernel_params,
            0,
        )

        if err != cuda.CUresult.CUDA_SUCCESS:
            raise RuntimeError(f"Kernel launch failed: {err}")


# Global loader instance
_loader: Optional[CubinLoader] = None


def get_loader() -> CubinLoader:
    """Get the global cubin loader instance."""
    global _loader
    if _loader is None:
        _loader = CubinLoader()
    return _loader


# High-level functions using precompiled kernels
def cubin_relu(x: torch.Tensor) -> torch.Tensor:
    """ReLU using precompiled kernel."""
    loader = get_loader()
    kernel = loader.get_kernel("_vla_relu_kernel")

    n = x.numel()
    out = torch.empty_like(x)

    BLOCK = 1024
    grid = ((n + BLOCK - 1) // BLOCK,)

    kernel(grid, x, out, n)
    torch.cuda.synchronize()

    return out
