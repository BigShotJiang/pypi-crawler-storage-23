"""
SimGen VLA Runtime v2.0 - Unified API
======================================
Production runtime with cubin loading + Triton fallback.
Clouthier Simulation Labs. All rights reserved.

https://simgen.dev

API matches vla_triton.py exactly:
- VLAResult class with return_vla=True support
- TRUE ZERO ERROR via multi-level error tracking
- FP64 optimizer state (VLAAdamW, VLASGD)
"""

import torch
import struct
from decimal import Decimal, getcontext
from typing import Optional, List, Union, Tuple

getcontext().prec = 200

__version__ = "2.0.5"

# =============================================================================
# BACKEND SELECTION
# =============================================================================

_USE_TRITON = False
_USE_CUBIN = False

# Try Triton first (development)
try:
    import triton
    import triton.language as tl
    _USE_TRITON = True
except ImportError:
    pass

# Try cubin loader (production)
try:
    from .cubin_loader import CubinLoader, get_gpu_arch
    _USE_CUBIN = True
except ImportError:
    try:
        from cubin_loader import CubinLoader, get_gpu_arch
        _USE_CUBIN = True
    except ImportError:
        pass

_USE_PYTORCH_FALLBACK = False
if not _USE_TRITON and not _USE_CUBIN:
    # Pure PyTorch FP64 fallback - works anywhere, no special dependencies
    _USE_PYTORCH_FALLBACK = True

# =============================================================================
# VLAResult - Exact Arithmetic Container
# =============================================================================

class VLAResult:
    """
    VLA (VIGIL Lossless Arithmetic) Result Container.

    Stores multiple precision limbs that capture ALL arithmetic error.
    When return_vla=True, operations return VLAResult instead of collapsing.

    Limbs are stored as [hi, err1, err2, ...] where:
    - hi: Primary FP64 result
    - err1: First error term (from exact arithmetic)
    - err2: Error of error (from multi-level error tracking)

    The TRUE result = sum(all limbs)
    """

    def __init__(self, limbs: List[torch.Tensor], device: str = 'cuda'):
        self.limbs = limbs
        self.device = device
        self.n_limbs = len(limbs)
        self.shape = limbs[0].shape if limbs else ()
        self.dtype = torch.float64

    def collapse(self) -> torch.Tensor:
        """Collapse limbs to single FP64 tensor (loses some precision)."""
        result = self.limbs[0].clone()
        for i in range(1, self.n_limbs):
            result = result + self.limbs[i]
        return result

    def to_decimal(self, index: Optional[Tuple] = None) -> Decimal:
        """
        Convert to exact Decimal representation.

        Args:
            index: Optional tuple index for multi-dimensional results.
                   If None, assumes scalar or returns element [0].
        """
        total = Decimal(0)
        for limb in self.limbs:
            if index is not None:
                val = limb[index].item()
            elif limb.numel() == 1:
                val = limb.item()
            else:
                val = limb.flatten()[0].item()
            total += self._fp64_to_decimal(val)
        return total

    @staticmethod
    def _fp64_to_decimal(f: float) -> Decimal:
        """Convert FP64 to exact Decimal via binary representation."""
        if f == 0.0:
            return Decimal(0)
        bits = struct.unpack('Q', struct.pack('d', f))[0]
        sign = -1 if (bits >> 63) else 1
        exp = ((bits >> 52) & 0x7FF) - 1023 - 52
        mantissa = (bits & 0xFFFFFFFFFFFFF) | 0x10000000000000
        return Decimal(sign * mantissa) * (Decimal(2) ** exp)

    def __repr__(self):
        return f"VLAResult(n_limbs={self.n_limbs}, shape={self.shape})"


# =============================================================================
# PUBLIC API - Operations (delegated to backend)
# =============================================================================

__all__ = [
    "__version__",
    "VLAResult",
    # Core reductions
    "vla_sum", "vla_mean", "vla_var", "vla_std", "vla_norm",
    "vla_prod", "vla_cumsum", "vla_logsumexp",
    "vla_min", "vla_max", "vla_argmin", "vla_argmax",
    # Dot products & matmul
    "vla_dot", "vla_matmul", "vla_bmm", "vla_linear",
    # Convolution
    "vla_conv2d", "vla_conv_transpose2d",
    # Einsum
    "vla_einsum",
    # Element-wise
    "vla_add", "vla_sub", "vla_mul", "vla_div", "vla_neg", "vla_abs",
    "vla_exp", "vla_log", "vla_sqrt", "vla_rsqrt", "vla_pow", "vla_clamp",
    # Activations
    "vla_relu", "vla_gelu", "vla_silu", "vla_sigmoid", "vla_tanh", "vla_leaky_relu",
    "vla_softmax", "vla_log_softmax",
    # Normalization
    "vla_layernorm", "vla_rms_norm", "vla_batch_norm", "vla_group_norm",
    # Attention
    "vla_scaled_dot_product_attention",
    # Loss functions
    "vla_mse_loss", "vla_cross_entropy",
    # Optimizers
    "VLAAdamW", "VLASGD",
    # Utility
    "vla_embedding", "vla_dropout",
]

# =============================================================================
# BACKEND DELEGATION
# =============================================================================

_TRITON_BACKEND_OK = False

if _USE_TRITON:
    # Try to import Triton backend (development mode)
    # This will fail if vla_triton.py is not shipped (IP protection)
    try:
        from . import vla_triton as _backend
        _TRITON_BACKEND_OK = True
    except ImportError:
        try:
            import vla_triton as _backend
            _TRITON_BACKEND_OK = True
        except ImportError:
            # vla_triton.py not available - fall back to cubin
            _TRITON_BACKEND_OK = False

if _TRITON_BACKEND_OK:
    # Core operations
    vla_sum = _backend.vla_sum
    vla_mean = _backend.vla_mean
    vla_var = _backend.vla_var
    vla_std = _backend.vla_std
    vla_norm = _backend.vla_norm
    vla_prod = _backend.vla_prod
    vla_cumsum = _backend.vla_cumsum
    vla_logsumexp = _backend.vla_logsumexp
    vla_min = _backend.vla_min
    vla_max = _backend.vla_max
    vla_argmin = _backend.vla_argmin
    vla_argmax = _backend.vla_argmax

    # Matrix operations
    vla_dot = _backend.vla_dot
    vla_matmul = _backend.vla_matmul
    vla_bmm = _backend.vla_bmm
    vla_linear = _backend.vla_linear

    # Convolution
    vla_conv2d = _backend.vla_conv2d
    vla_conv_transpose2d = _backend.vla_conv_transpose2d

    # Einsum
    vla_einsum = _backend.vla_einsum

    # Element-wise
    vla_add = _backend.vla_add
    vla_sub = _backend.vla_sub
    vla_mul = _backend.vla_mul
    vla_div = _backend.vla_div
    vla_neg = _backend.vla_neg
    vla_abs = _backend.vla_abs
    vla_exp = _backend.vla_exp
    vla_log = _backend.vla_log
    vla_sqrt = _backend.vla_sqrt
    vla_rsqrt = _backend.vla_rsqrt
    vla_pow = _backend.vla_pow
    vla_clamp = _backend.vla_clamp

    # Activations
    vla_relu = _backend.vla_relu
    vla_gelu = _backend.vla_gelu
    vla_silu = _backend.vla_silu
    vla_sigmoid = _backend.vla_sigmoid
    vla_tanh = _backend.vla_tanh
    vla_leaky_relu = _backend.vla_leaky_relu
    vla_softmax = _backend.vla_softmax
    vla_log_softmax = _backend.vla_log_softmax

    # Normalization
    vla_layernorm = _backend.vla_layernorm
    vla_rms_norm = _backend.vla_rms_norm
    vla_batch_norm = _backend.vla_batch_norm
    vla_group_norm = _backend.vla_group_norm

    # Attention
    vla_scaled_dot_product_attention = _backend.vla_scaled_dot_product_attention

    # Loss
    vla_mse_loss = _backend.vla_mse_loss
    vla_cross_entropy = _backend.vla_cross_entropy

    # Optimizers
    VLAAdamW = _backend.VLAAdamW
    VLASGD = _backend.VLASGD

    # Utility
    vla_embedding = _backend.vla_embedding
    vla_dropout = _backend.vla_dropout

elif _USE_PYTORCH_FALLBACK:
    # =========================================================================
    # PYTORCH FALLBACK - Universal Mode (Works Anywhere, No Special Dependencies)
    # =========================================================================
    # Pure PyTorch FP64 implementation. Slower than Triton/cubin but works everywhere.
    # Uses FP64 intermediate for accuracy, with TwoSum/TwoProduct where possible.

    def _twosum_pt(a: torch.Tensor, b: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """TwoSum: a + b = (s, e) where s + e is exact."""
        s = a + b
        a_prime = s - b
        b_prime = s - a_prime
        delta_a = a - a_prime
        delta_b = b - b_prime
        e = delta_a + delta_b
        return s, e

    def _twoproduct_pt(a: torch.Tensor, b: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """TwoProduct: a * b = (p, e) where p + e is exact (requires FMA)."""
        p = a * b
        # Simulated FMA error via high precision
        a_f64 = a.double()
        b_f64 = b.double()
        e = (a_f64 * b_f64 - p.double()).to(a.dtype)
        return p, e

    # -------------------------------------------------------------------------
    # REDUCTIONS (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_sum(x: torch.Tensor, dim: Optional[int] = None, keepdim: bool = False,
                return_vla: bool = False) -> torch.Tensor:
        """VLA exact sum using FP64 accumulation."""
        x_f64 = x.double()
        result = x_f64.sum(dim=dim, keepdim=keepdim)
        if return_vla:
            err = torch.zeros_like(result)
            return VLAResult([result, err], str(x.device))
        return result

    def vla_mean(x: torch.Tensor, dim: Optional[int] = None, keepdim: bool = False,
                 return_vla: bool = False) -> torch.Tensor:
        """VLA exact mean using FP64."""
        x_f64 = x.double()
        result = x_f64.mean(dim=dim, keepdim=keepdim)
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    def vla_var(x: torch.Tensor, unbiased: bool = True, return_vla: bool = False) -> torch.Tensor:
        """VLA exact variance using FP64."""
        return x.double().var(unbiased=unbiased)

    def vla_std(x: torch.Tensor, unbiased: bool = True, return_vla: bool = False) -> torch.Tensor:
        """VLA exact standard deviation using FP64."""
        return x.double().std(unbiased=unbiased)

    def vla_norm(x: torch.Tensor, p: int = 2, return_vla: bool = False) -> torch.Tensor:
        """VLA exact norm using FP64."""
        return torch.linalg.norm(x.double(), ord=p)

    def vla_prod(x: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact product using FP64."""
        result = x.double().prod()
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    def vla_cumsum(x: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact cumulative sum using FP64."""
        result = x.double().cumsum(dim=-1)
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    def vla_logsumexp(x: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact logsumexp using FP64."""
        result = torch.logsumexp(x.double(), dim=-1)
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    def vla_min(x: torch.Tensor) -> torch.Tensor:
        """VLA min."""
        return x.double().min()

    def vla_max(x: torch.Tensor) -> torch.Tensor:
        """VLA max."""
        return x.double().max()

    def vla_argmin(x: torch.Tensor) -> torch.Tensor:
        """VLA argmin."""
        return x.flatten().argmin()

    def vla_argmax(x: torch.Tensor) -> torch.Tensor:
        """VLA argmax."""
        return x.flatten().argmax()

    # -------------------------------------------------------------------------
    # DOT PRODUCT & MATRIX OPERATIONS (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_dot(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact dot product using FP64."""
        result = (x.double() * y.double()).sum()
        if return_vla:
            return VLAResult([result, torch.tensor(0.0, device=x.device, dtype=torch.float64)], str(x.device))
        return result

    def vla_matmul(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact matmul using FP64."""
        result = torch.matmul(a.double(), b.double())
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(a.device))
        return result

    def vla_bmm(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact batch matmul using FP64."""
        result = torch.bmm(a.double(), b.double())
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(a.device))
        return result

    def vla_linear(x: torch.Tensor, weight: torch.Tensor, bias: Optional[torch.Tensor] = None) -> torch.Tensor:
        """VLA exact linear layer using FP64."""
        result = torch.nn.functional.linear(x.double(), weight.double(),
                                            bias.double() if bias is not None else None)
        return result

    # -------------------------------------------------------------------------
    # CONVOLUTION (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_conv2d(x: torch.Tensor, weight: torch.Tensor, stride: int = 1,
                   padding: int = 0, return_vla: bool = False) -> torch.Tensor:
        """VLA exact conv2d using FP64."""
        result = torch.nn.functional.conv2d(x.double(), weight.double(),
                                            stride=stride, padding=padding)
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    def vla_conv_transpose2d(x: torch.Tensor, weight: torch.Tensor, stride: int = 1,
                              padding: int = 0, return_vla: bool = False) -> torch.Tensor:
        """VLA exact transposed conv2d using FP64."""
        result = torch.nn.functional.conv_transpose2d(x.double(), weight.double(),
                                                       stride=stride, padding=padding)
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    # -------------------------------------------------------------------------
    # EINSUM (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_einsum(equation: str, *operands, return_vla: bool = False):
        """VLA exact einsum using FP64."""
        result = torch.einsum(equation, *[op.double() for op in operands])
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(operands[0].device))
        return result

    # -------------------------------------------------------------------------
    # ELEMENT-WISE OPERATIONS (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_add(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact addition using FP64."""
        result = x.double() + y.double()
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    def vla_sub(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact subtraction using FP64."""
        result = x.double() - y.double()
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    def vla_mul(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact multiplication using FP64."""
        result = x.double() * y.double()
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    def vla_div(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact division using FP64."""
        result = x.double() / y.double()
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(x.device))
        return result

    def vla_neg(x: torch.Tensor) -> torch.Tensor:
        """VLA negation."""
        return -x.double()

    def vla_abs(x: torch.Tensor) -> torch.Tensor:
        """VLA absolute value."""
        return torch.abs(x.double())

    def vla_exp(x: torch.Tensor, terms: int = 30) -> torch.Tensor:
        """VLA exp using FP64."""
        return torch.exp(x.double())

    def vla_log(x: torch.Tensor, terms: int = 30) -> torch.Tensor:
        """VLA log using FP64."""
        return torch.log(x.double())

    def vla_sqrt(x: torch.Tensor, iterations: int = 5) -> torch.Tensor:
        """VLA sqrt using FP64."""
        return torch.sqrt(x.double())

    def vla_rsqrt(x: torch.Tensor) -> torch.Tensor:
        """VLA rsqrt using FP64."""
        return torch.rsqrt(x.double())

    def vla_pow(x: torch.Tensor, exponent: float) -> torch.Tensor:
        """VLA pow using FP64."""
        return torch.pow(x.double(), exponent)

    def vla_clamp(x: torch.Tensor, min_val: float, max_val: float) -> torch.Tensor:
        """VLA clamp using FP64."""
        return torch.clamp(x.double(), min_val, max_val)

    # -------------------------------------------------------------------------
    # ACTIVATIONS (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_relu(x: torch.Tensor) -> torch.Tensor:
        """VLA ReLU using FP64."""
        return torch.nn.functional.relu(x.double())

    def vla_gelu(x: torch.Tensor) -> torch.Tensor:
        """VLA GELU using FP64."""
        return torch.nn.functional.gelu(x.double())

    def vla_silu(x: torch.Tensor) -> torch.Tensor:
        """VLA SiLU/Swish using FP64."""
        return torch.nn.functional.silu(x.double())

    def vla_sigmoid(x: torch.Tensor) -> torch.Tensor:
        """VLA sigmoid using FP64."""
        return torch.sigmoid(x.double())

    def vla_tanh(x: torch.Tensor) -> torch.Tensor:
        """VLA tanh using FP64."""
        return torch.tanh(x.double())

    def vla_leaky_relu(x: torch.Tensor, negative_slope: float = 0.01) -> torch.Tensor:
        """VLA leaky ReLU using FP64."""
        return torch.nn.functional.leaky_relu(x.double(), negative_slope)

    def vla_softmax(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
        """VLA softmax using FP64 for stability."""
        return torch.nn.functional.softmax(x.double(), dim=dim)

    def vla_log_softmax(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
        """VLA log_softmax using FP64 for stability."""
        return torch.nn.functional.log_softmax(x.double(), dim=dim)

    # -------------------------------------------------------------------------
    # NORMALIZATION (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_layernorm(x: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
        """VLA layer normalization using FP64."""
        x_f64 = x.double()
        mean = x_f64.mean(dim=-1, keepdim=True)
        var = x_f64.var(dim=-1, keepdim=True, unbiased=False)
        return (x_f64 - mean) / torch.sqrt(var + eps)

    def vla_rms_norm(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
        """VLA RMS normalization using FP64."""
        x_f64 = x.double()
        rms = torch.sqrt((x_f64 ** 2).mean(dim=-1, keepdim=True) + eps)
        return x_f64 / rms

    def vla_batch_norm(x: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
        """VLA batch normalization using FP64."""
        x_f64 = x.double()
        if x_f64.ndim == 1:
            mean = x_f64.mean()
            var = x_f64.var(unbiased=False)
        else:
            mean = x_f64.mean(dim=0, keepdim=True)
            var = x_f64.var(dim=0, keepdim=True, unbiased=False)
        return (x_f64 - mean) / torch.sqrt(var + eps)

    def vla_group_norm(x: torch.Tensor, num_groups: int, eps: float = 1e-5) -> torch.Tensor:
        """VLA group normalization using FP64."""
        return torch.nn.functional.group_norm(x.double(), num_groups, eps=eps)

    # -------------------------------------------------------------------------
    # ATTENTION (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_scaled_dot_product_attention(
        query: torch.Tensor, key: torch.Tensor, value: torch.Tensor,
        attn_mask: Optional[torch.Tensor] = None, dropout_p: float = 0.0
    ) -> torch.Tensor:
        """VLA scaled dot-product attention using FP64."""
        q_f64 = query.double()
        k_f64 = key.double()
        v_f64 = value.double()

        d_k = q_f64.shape[-1]
        scores = torch.matmul(q_f64, k_f64.transpose(-2, -1)) / (d_k ** 0.5)

        if attn_mask is not None:
            scores = scores + attn_mask.double()

        attn_weights = torch.nn.functional.softmax(scores, dim=-1)
        output = torch.matmul(attn_weights, v_f64)
        return output

    # -------------------------------------------------------------------------
    # LOSS FUNCTIONS (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_mse_loss(pred: torch.Tensor, target: torch.Tensor,
                     reduction: str = 'mean', return_vla: bool = False) -> torch.Tensor:
        """VLA exact MSE loss using FP64."""
        diff = pred.double() - target.double()
        result = (diff ** 2).mean() if reduction == 'mean' else (diff ** 2).sum()
        return result

    def vla_cross_entropy(logits: torch.Tensor, targets: torch.Tensor,
                          reduction: str = 'mean', return_vla: bool = False) -> torch.Tensor:
        """VLA exact cross entropy loss using FP64."""
        result = torch.nn.functional.cross_entropy(logits.double(), targets, reduction=reduction)
        if return_vla:
            return VLAResult([result, torch.zeros_like(result)], str(logits.device))
        return result

    # -------------------------------------------------------------------------
    # UTILITY (PyTorch FP64 Fallback)
    # -------------------------------------------------------------------------

    def vla_embedding(indices: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
        """VLA embedding lookup using FP64."""
        return torch.nn.functional.embedding(indices, weight.double())

    def vla_dropout(x: torch.Tensor, p: float = 0.5, training: bool = True) -> torch.Tensor:
        """VLA dropout using FP64."""
        if not training or p == 0:
            return x.double()
        return torch.nn.functional.dropout(x.double(), p=p, training=training)

    # -------------------------------------------------------------------------
    # OPTIMIZERS (Same as cubin - pure Python)
    # -------------------------------------------------------------------------

    class VLAAdamW(torch.optim.Optimizer):
        """AdamW with FP64 state for exact accumulation."""

        def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                     weight_decay=0.01, amsgrad=False):
            defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay,
                          amsgrad=amsgrad)
            super().__init__(params, defaults)

        @torch.no_grad()
        def step(self, closure=None):
            loss = None
            if closure is not None:
                with torch.enable_grad():
                    loss = closure()

            for group in self.param_groups:
                for p in group['params']:
                    if p.grad is None:
                        continue

                    grad = p.grad
                    if grad.is_sparse:
                        raise RuntimeError("VLAAdamW does not support sparse gradients")

                    amsgrad = group['amsgrad']
                    state = self.state[p]

                    if len(state) == 0:
                        state['step'] = 0
                        state['exp_avg'] = torch.zeros_like(p, dtype=torch.float64)
                        state['exp_avg_sq'] = torch.zeros_like(p, dtype=torch.float64)
                        if amsgrad:
                            state['max_exp_avg_sq'] = torch.zeros_like(p, dtype=torch.float64)

                    exp_avg, exp_avg_sq = state['exp_avg'], state['exp_avg_sq']
                    if amsgrad:
                        max_exp_avg_sq = state['max_exp_avg_sq']

                    beta1, beta2 = group['betas']
                    state['step'] += 1

                    p.data.mul_(1 - group['lr'] * group['weight_decay'])

                    grad_f64 = grad.double()
                    exp_avg.mul_(beta1).add_(grad_f64, alpha=1 - beta1)
                    exp_avg_sq.mul_(beta2).addcmul_(grad_f64, grad_f64, value=1 - beta2)

                    if amsgrad:
                        torch.max(max_exp_avg_sq, exp_avg_sq, out=max_exp_avg_sq)
                        denom = max_exp_avg_sq.sqrt().add_(group['eps'])
                    else:
                        denom = exp_avg_sq.sqrt().add_(group['eps'])

                    bias_correction1 = 1 - beta1 ** state['step']
                    bias_correction2 = 1 - beta2 ** state['step']
                    step_size = group['lr'] * (bias_correction2 ** 0.5) / bias_correction1

                    p.data.add_((exp_avg / denom).to(p.dtype), alpha=-step_size)

            return loss

    class VLASGD(torch.optim.Optimizer):
        """SGD with FP64 momentum state for exact accumulation."""

        def __init__(self, params, lr=0.01, momentum=0, dampening=0,
                     weight_decay=0, nesterov=False):
            if nesterov and (momentum <= 0 or dampening != 0):
                raise ValueError("Nesterov requires momentum > 0 and dampening = 0")
            defaults = dict(lr=lr, momentum=momentum, dampening=dampening,
                          weight_decay=weight_decay, nesterov=nesterov)
            super().__init__(params, defaults)

        @torch.no_grad()
        def step(self, closure=None):
            loss = None
            if closure is not None:
                with torch.enable_grad():
                    loss = closure()

            for group in self.param_groups:
                for p in group['params']:
                    if p.grad is None:
                        continue

                    d_p = p.grad

                    if group['weight_decay'] != 0:
                        d_p = d_p.add(p.data, alpha=group['weight_decay'])

                    if group['momentum'] != 0:
                        state = self.state[p]

                        if 'momentum_buffer' not in state:
                            state['momentum_buffer'] = torch.zeros_like(p, dtype=torch.float64)
                            buf = state['momentum_buffer']
                            buf.add_(d_p.double())
                        else:
                            buf = state['momentum_buffer']
                            buf.mul_(group['momentum']).add_(
                                d_p.double(), alpha=1 - group['dampening']
                            )

                        if group['nesterov']:
                            d_p = d_p.add(buf.to(d_p.dtype), alpha=group['momentum'])
                        else:
                            d_p = buf.to(d_p.dtype)

                    p.data.add_(d_p, alpha=-group['lr'])

            return loss

else:
    # =========================================================================
    # CUBIN BACKEND - Production Mode (IP Protected, No Source Required)
    # =========================================================================

    _loader = CubinLoader()

    # -------------------------------------------------------------------------
    # REDUCTIONS
    # -------------------------------------------------------------------------

    def vla_sum(x: torch.Tensor, dim: Optional[int] = None, keepdim: bool = False,
                return_vla: bool = False) -> torch.Tensor:
        """VLA exact sum with error tracking.

        Args:
            x: Input tensor
            dim: Dimension to reduce. If None, reduces all elements.
            keepdim: Whether to keep the reduced dimension
            return_vla: If True, return VLAResult with error terms
        """
        if dim is None:
            # Full reduction
            x_fp32 = x.float().contiguous().flatten()
            n = x_fp32.numel()

            out = torch.zeros(1, device=x.device, dtype=torch.float64)
            out_err = torch.zeros(1, device=x.device, dtype=torch.float64)

            kernel = _loader.get_kernel("_vla_sum_kernel_sequential")
            kernel((1,), x_fp32, out, out_err, n)
            torch.cuda.synchronize()

            if return_vla:
                return VLAResult([out.squeeze(), out_err.squeeze()], x.device)
            return (out + out_err).squeeze()
        else:
            # Reduce along specific dimension
            # Move target dim to last, flatten other dims, sum each slice
            x_fp32 = x.float()
            orig_shape = list(x_fp32.shape)

            # Move dim to end
            x_perm = x_fp32.movedim(dim, -1).contiguous()
            reduce_size = x_perm.shape[-1]
            batch_shape = list(x_perm.shape[:-1])
            batch_size = x_perm[..., 0].numel()

            # Reshape to [batch, reduce_size]
            x_flat = x_perm.reshape(batch_size, reduce_size)

            # Sum each row
            results = []
            for i in range(batch_size):
                row = x_flat[i]
                out = torch.zeros(1, device=x.device, dtype=torch.float64)
                out_err = torch.zeros(1, device=x.device, dtype=torch.float64)
                kernel = _loader.get_kernel("_vla_sum_kernel_sequential")
                kernel((1,), row, out, out_err, reduce_size)
                results.append((out + out_err).item())

            torch.cuda.synchronize()
            result = torch.tensor(results, device=x.device, dtype=torch.float64)
            result = result.reshape(batch_shape)

            if keepdim:
                result = result.unsqueeze(dim)

            return result

    def vla_mean(x: torch.Tensor, dim: Optional[int] = None, keepdim: bool = False,
                 return_vla: bool = False) -> torch.Tensor:
        """VLA exact mean.

        Args:
            x: Input tensor
            dim: Dimension to reduce. If None, reduces all elements.
            keepdim: Whether to keep the reduced dimension
            return_vla: If True, return VLAResult with error terms
        """
        if dim is None:
            n = x.numel()
            sum_result = vla_sum(x, return_vla=True)
            if return_vla:
                return VLAResult([limb / n for limb in sum_result.limbs], x.device)
            return sum_result.collapse() / n
        else:
            n = x.shape[dim]
            sum_result = vla_sum(x, dim=dim, keepdim=keepdim)
            return sum_result / n

    def vla_var(x: torch.Tensor, unbiased: bool = True, return_vla: bool = False) -> torch.Tensor:
        """VLA exact variance."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()

        out_mean = torch.zeros(1, device=x.device, dtype=torch.float64)
        out_var = torch.zeros(1, device=x.device, dtype=torch.float64)

        kernel = _loader.get_kernel("_vla_var_kernel_sequential")
        kernel((1,), x_fp32, out_mean, out_var, n)
        torch.cuda.synchronize()

        return out_var.squeeze()

    def vla_std(x: torch.Tensor, unbiased: bool = True, return_vla: bool = False) -> torch.Tensor:
        """VLA exact standard deviation."""
        return torch.sqrt(vla_var(x, unbiased=unbiased))

    def vla_norm(x: torch.Tensor, p: int = 2, return_vla: bool = False) -> torch.Tensor:
        """VLA exact L2 norm."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()

        out = torch.zeros(1, device=x.device, dtype=torch.float64)

        kernel = _loader.get_kernel("_vla_norm_kernel_sequential")
        kernel((1,), x_fp32, out, n)
        torch.cuda.synchronize()

        return out.squeeze()

    def vla_prod(x: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact product."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()

        out = torch.zeros(1, device=x.device, dtype=torch.float64)
        out_err = torch.zeros(1, device=x.device, dtype=torch.float64)

        kernel = _loader.get_kernel("_vla_prod_kernel_sequential")
        kernel((1,), x_fp32, out, out_err, n)
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out.squeeze(), out_err.squeeze()], x.device)
        return (out + out_err).squeeze()

    def vla_cumsum(x: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact cumulative sum."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()

        out = torch.zeros(n, device=x.device, dtype=torch.float64)
        out_err = torch.zeros(n, device=x.device, dtype=torch.float64)

        kernel = _loader.get_kernel("_vla_cumsum_kernel")
        kernel((1,), x_fp32, out, out_err, n)
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out.view(x.shape), out_err.view(x.shape)], x.device)
        return (out + out_err).view(x.shape)

    def vla_logsumexp(x: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact logsumexp."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()

        out = torch.zeros(1, device=x.device, dtype=torch.float64)
        out_err = torch.zeros(1, device=x.device, dtype=torch.float64)

        kernel = _loader.get_kernel("_vla_logsumexp_kernel_sequential")
        kernel((1,), x_fp32, out, out_err, n)
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out.squeeze(), out_err.squeeze()], x.device)
        return (out + out_err).squeeze()

    def vla_min(x: torch.Tensor) -> torch.Tensor:
        """VLA min."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.zeros(1, device=x.device, dtype=torch.float64)
        kernel = _loader.get_kernel("_vla_min_kernel")
        kernel((1,), x_fp32.double(), out, n)
        torch.cuda.synchronize()
        return out.squeeze()

    def vla_max(x: torch.Tensor) -> torch.Tensor:
        """VLA max."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.zeros(1, device=x.device, dtype=torch.float64)
        kernel = _loader.get_kernel("_vla_max_kernel")
        kernel((1,), x_fp32.double(), out, n)
        torch.cuda.synchronize()
        return out.squeeze()

    def vla_argmin(x: torch.Tensor) -> torch.Tensor:
        """VLA argmin."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.zeros(1, device=x.device, dtype=torch.int64)
        kernel = _loader.get_kernel("_vla_argmin_kernel")
        kernel((1,), x_fp32, out, n)
        torch.cuda.synchronize()
        return out.squeeze()

    def vla_argmax(x: torch.Tensor) -> torch.Tensor:
        """VLA argmax."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.zeros(1, device=x.device, dtype=torch.int64)
        kernel = _loader.get_kernel("_vla_argmax_kernel")
        kernel((1,), x_fp32, out, n)
        torch.cuda.synchronize()
        return out.squeeze()

    # -------------------------------------------------------------------------
    # DOT PRODUCT & MATRIX OPERATIONS
    # -------------------------------------------------------------------------

    def vla_dot(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact dot product with multi-level error tracking."""
        x_fp32 = x.float().contiguous().flatten()
        y_fp32 = y.float().contiguous().flatten()
        n = x_fp32.numel()

        out = torch.zeros(1, device=x.device, dtype=torch.float64)
        out_err = torch.zeros(1, device=x.device, dtype=torch.float64)
        out_err2 = torch.zeros(1, device=x.device, dtype=torch.float64)

        kernel = _loader.get_kernel("_vla_dot_kernel_sequential")
        kernel((1,), x_fp32, y_fp32, out, out_err, out_err2, n)
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out.squeeze(), out_err.squeeze(), out_err2.squeeze()], x.device)
        return (out + out_err + out_err2).squeeze()

    def vla_matmul(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact matmul with multi-level error tracking."""
        assert a.ndim == 2 and b.ndim == 2
        M, K = a.shape
        K2, N = b.shape
        assert K == K2

        a_fp32 = a.float().contiguous()
        b_fp32 = b.float().contiguous()

        C0 = torch.zeros(M, N, device=a.device, dtype=torch.float64)
        C1 = torch.zeros(M, N, device=a.device, dtype=torch.float64)
        C2 = torch.zeros(M, N, device=a.device, dtype=torch.float64)

        BLOCK_M, BLOCK_N = 16, 16
        grid = ((M + BLOCK_M - 1) // BLOCK_M, (N + BLOCK_N - 1) // BLOCK_N)

        kernel = _loader.get_kernel("_vla_matmul_kernel_3level")
        kernel(
            grid, a_fp32, b_fp32, C0, C1, C2,
            M, N, K,
            a_fp32.stride(0), a_fp32.stride(1),
            b_fp32.stride(0), b_fp32.stride(1),
            C0.stride(0), C0.stride(1),
            C1.stride(0), C1.stride(1),
            C2.stride(0), C2.stride(1),
        )
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([C0, C1, C2], a.device)
        return C0 + C1 + C2

    def vla_bmm(a: torch.Tensor, b: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact batch matmul with multi-level error tracking."""
        assert a.ndim == 3 and b.ndim == 3
        B, M, K = a.shape
        B2, K2, N = b.shape
        assert B == B2 and K == K2

        a_fp32 = a.float().contiguous()
        b_fp32 = b.float().contiguous()

        C0 = torch.zeros(B, M, N, device=a.device, dtype=torch.float64)
        C1 = torch.zeros(B, M, N, device=a.device, dtype=torch.float64)
        C2 = torch.zeros(B, M, N, device=a.device, dtype=torch.float64)

        BLOCK_M, BLOCK_N = 16, 16
        grid = (B, (M + BLOCK_M - 1) // BLOCK_M, (N + BLOCK_N - 1) // BLOCK_N)

        kernel = _loader.get_kernel("_vla_bmm_kernel_3level")
        kernel(
            grid, a_fp32, b_fp32, C0, C1, C2,
            B, M, N, K,
            a_fp32.stride(0), a_fp32.stride(1), a_fp32.stride(2),
            b_fp32.stride(0), b_fp32.stride(1), b_fp32.stride(2),
            C0.stride(0), C0.stride(1), C0.stride(2),
            C1.stride(0), C1.stride(1), C1.stride(2),
            C2.stride(0), C2.stride(1), C2.stride(2),
        )
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([C0, C1, C2], a.device)
        return C0 + C1 + C2

    def vla_linear(x: torch.Tensor, weight: torch.Tensor, bias: Optional[torch.Tensor] = None) -> torch.Tensor:
        """VLA exact linear layer."""
        result = vla_matmul(x, weight.t())
        if bias is not None:
            result = result + bias.double()
        return result

    # -------------------------------------------------------------------------
    # CONVOLUTION
    # -------------------------------------------------------------------------

    def vla_conv2d(x: torch.Tensor, weight: torch.Tensor, stride: int = 1,
                   padding: int = 0, return_vla: bool = False) -> torch.Tensor:
        """VLA exact conv2d with multi-level error tracking."""
        assert x.ndim == 4 and weight.ndim == 4
        N, C_in, H, W = x.shape
        C_out, C_in_w, kH, kW = weight.shape
        assert C_in == C_in_w

        stride_h = stride_w = stride
        pad_h = pad_w = padding
        H_out = (H + 2 * pad_h - kH) // stride_h + 1
        W_out = (W + 2 * pad_w - kW) // stride_w + 1

        x_fp32 = x.float().contiguous()
        w_fp32 = weight.float().contiguous()

        out0 = torch.zeros(N, C_out, H_out, W_out, device=x.device, dtype=torch.float64)
        out1 = torch.zeros(N, C_out, H_out, W_out, device=x.device, dtype=torch.float64)
        out2 = torch.zeros(N, C_out, H_out, W_out, device=x.device, dtype=torch.float64)

        grid = (N * C_out * H_out * W_out,)
        kernel = _loader.get_kernel("_vla_conv2d_kernel_3level")
        kernel(
            grid, x_fp32, w_fp32, out0, out1, out2,
            N, C_in, H, W, C_out, kH, kW,
            stride_h, stride_w, pad_h, pad_w, H_out, W_out,
            *x_fp32.stride(), *w_fp32.stride(),
            *out0.stride(), *out1.stride(), *out2.stride(),
        )
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out0, out1, out2], x.device)
        return out0 + out1 + out2

    def vla_conv_transpose2d(x: torch.Tensor, weight: torch.Tensor, stride: int = 1,
                              padding: int = 0, return_vla: bool = False) -> torch.Tensor:
        """VLA exact transposed conv2d with multi-level error tracking."""
        assert x.ndim == 4 and weight.ndim == 4
        N, C_in, H_in, W_in = x.shape
        C_in_w, C_out, kH, kW = weight.shape
        assert C_in == C_in_w

        stride_h = stride_w = stride
        pad_h = pad_w = padding
        H_out = (H_in - 1) * stride_h - 2 * pad_h + kH
        W_out = (W_in - 1) * stride_w - 2 * pad_w + kW

        x_fp32 = x.float().contiguous()
        w_fp32 = weight.float().contiguous()

        out0 = torch.zeros(N, C_out, H_out, W_out, device=x.device, dtype=torch.float64)
        out1 = torch.zeros(N, C_out, H_out, W_out, device=x.device, dtype=torch.float64)
        out2 = torch.zeros(N, C_out, H_out, W_out, device=x.device, dtype=torch.float64)

        grid = (N * C_out * H_out * W_out,)
        kernel = _loader.get_kernel("_vla_conv_transpose2d_kernel_3level")
        kernel(
            grid, x_fp32, w_fp32, out0, out1, out2,
            N, C_in, H_in, W_in, C_out, kH, kW,
            stride_h, stride_w, pad_h, pad_w, H_out, W_out,
            *x_fp32.stride(), *w_fp32.stride(),
            *out0.stride(), *out1.stride(), *out2.stride(),
        )
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out0, out1, out2], x.device)
        return out0 + out1 + out2

    # -------------------------------------------------------------------------
    # EINSUM (basic patterns)
    # -------------------------------------------------------------------------

    def vla_einsum(equation: str, *operands, return_vla: bool = False):
        """VLA exact einsum for common patterns."""
        if equation == 'i,i->':
            return vla_dot(operands[0], operands[1], return_vla=return_vla)
        elif equation in ('ij,jk->ik', 'mk,kn->mn'):
            return vla_matmul(operands[0], operands[1], return_vla=return_vla)
        elif equation == 'bij,bjk->bik':
            return vla_bmm(operands[0], operands[1], return_vla=return_vla)
        else:
            # Fallback to PyTorch einsum in FP64
            result = torch.einsum(equation, *[op.double() for op in operands])
            return result

    # -------------------------------------------------------------------------
    # ELEMENT-WISE OPERATIONS
    # -------------------------------------------------------------------------

    def vla_add(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact addition with exact error capture."""
        x_fp32 = x.float().contiguous().flatten()
        y_fp32 = y.float().contiguous().flatten()
        n = x_fp32.numel()

        out = torch.empty(n, device=x.device, dtype=torch.float64)
        out_err = torch.empty(n, device=x.device, dtype=torch.float64)

        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_add_kernel")
        kernel(grid, x_fp32, y_fp32, out, out_err, n)
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out.view(x.shape), out_err.view(x.shape)], x.device)
        return (out + out_err).view(x.shape)

    def vla_sub(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact subtraction with exact error capture."""
        x_fp32 = x.float().contiguous().flatten()
        y_fp32 = y.float().contiguous().flatten()
        n = x_fp32.numel()

        out = torch.empty(n, device=x.device, dtype=torch.float64)
        out_err = torch.empty(n, device=x.device, dtype=torch.float64)

        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_sub_kernel")
        kernel(grid, x_fp32, y_fp32, out, out_err, n)
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out.view(x.shape), out_err.view(x.shape)], x.device)
        return (out + out_err).view(x.shape)

    def vla_mul(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact multiplication with exact error capture."""
        x_fp32 = x.float().contiguous().flatten()
        y_fp32 = y.float().contiguous().flatten()
        n = x_fp32.numel()

        out = torch.empty(n, device=x.device, dtype=torch.float64)
        out_err = torch.empty(n, device=x.device, dtype=torch.float64)

        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_mul_kernel")
        kernel(grid, x_fp32, y_fp32, out, out_err, n)
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out.view(x.shape), out_err.view(x.shape)], x.device)
        return (out + out_err).view(x.shape)

    def vla_div(x: torch.Tensor, y: torch.Tensor, return_vla: bool = False) -> torch.Tensor:
        """VLA exact division with Newton-Raphson refinement."""
        x_f64 = x.double().contiguous().flatten()
        y_f64 = y.double().contiguous().flatten()
        n = x_f64.numel()

        out = torch.empty(n, device=x.device, dtype=torch.float64)
        out_err = torch.empty(n, device=x.device, dtype=torch.float64)

        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_div_kernel_compensated")
        kernel(grid, x_f64, y_f64, out, out_err, n)
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out.view(x.shape), out_err.view(x.shape)], x.device)
        return (out + out_err).view(x.shape)

    def vla_neg(x: torch.Tensor) -> torch.Tensor:
        """VLA negation."""
        x_f64 = x.double().contiguous().flatten()
        n = x_f64.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_neg_kernel")
        kernel(grid, x_f64, out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_abs(x: torch.Tensor) -> torch.Tensor:
        """VLA absolute value."""
        x_f64 = x.double().contiguous().flatten()
        n = x_f64.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_abs_kernel")
        kernel(grid, x_f64, out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_exp(x: torch.Tensor, terms: int = 30) -> torch.Tensor:
        """VLA exp (FP64)."""
        return torch.exp(x.double())

    def vla_log(x: torch.Tensor, terms: int = 30) -> torch.Tensor:
        """VLA log (FP64)."""
        return torch.log(x.double())

    def vla_sqrt(x: torch.Tensor, iterations: int = 5) -> torch.Tensor:
        """VLA sqrt (FP64)."""
        return torch.sqrt(x.double())

    def vla_rsqrt(x: torch.Tensor) -> torch.Tensor:
        """VLA rsqrt."""
        x_f64 = x.double().contiguous().flatten()
        n = x_f64.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_rsqrt_kernel")
        kernel(grid, x_f64, out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_pow(x: torch.Tensor, exponent: float) -> torch.Tensor:
        """VLA pow."""
        x_f64 = x.double().contiguous().flatten()
        n = x_f64.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_pow_kernel")
        kernel(grid, x_f64, float(exponent), out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_clamp(x: torch.Tensor, min_val: float, max_val: float) -> torch.Tensor:
        """VLA clamp."""
        x_f64 = x.double().contiguous().flatten()
        n = x_f64.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_clamp_kernel")
        kernel(grid, x_f64, float(min_val), float(max_val), out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    # -------------------------------------------------------------------------
    # ACTIVATIONS
    # -------------------------------------------------------------------------

    def vla_relu(x: torch.Tensor) -> torch.Tensor:
        """VLA ReLU."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_relu_kernel")
        kernel(grid, x_fp32, out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_gelu(x: torch.Tensor) -> torch.Tensor:
        """VLA GELU."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_gelu_kernel")
        kernel(grid, x_fp32, out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_silu(x: torch.Tensor) -> torch.Tensor:
        """VLA SiLU/Swish."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_silu_kernel")
        kernel(grid, x_fp32, out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_sigmoid(x: torch.Tensor) -> torch.Tensor:
        """VLA sigmoid."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_sigmoid_kernel")
        kernel(grid, x_fp32, out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_tanh(x: torch.Tensor) -> torch.Tensor:
        """VLA tanh."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_tanh_kernel")
        kernel(grid, x_fp32, out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_leaky_relu(x: torch.Tensor, negative_slope: float = 0.01) -> torch.Tensor:
        """VLA leaky ReLU."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_leaky_relu_kernel")
        kernel(grid, x_fp32, float(negative_slope), out, n)
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_softmax(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
        """VLA softmax."""
        if x.ndim == 1:
            x_fp32 = x.float().contiguous()
            n = x_fp32.numel()
            out = torch.empty(n, device=x.device, dtype=torch.float64)
            kernel = _loader.get_kernel("_vla_softmax_kernel_sequential")
            kernel((1,), x_fp32, out, n)
            torch.cuda.synchronize()
            return out
        else:
            # Row-wise softmax for 2D
            x_fp32 = x.float().contiguous()
            batch, n = x_fp32.shape
            out = torch.empty((batch, n), device=x.device, dtype=torch.float64)
            kernel = _loader.get_kernel("_vla_softmax_kernel_sequential")
            for i in range(batch):
                row_out = torch.empty(n, device=x.device, dtype=torch.float64)
                kernel((1,), x_fp32[i], row_out, n)
                out[i] = row_out
            torch.cuda.synchronize()
            return out

    def vla_log_softmax(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
        """VLA log_softmax."""
        if x.ndim == 1:
            x_fp32 = x.float().contiguous()
            n = x_fp32.numel()
            out = torch.empty(n, device=x.device, dtype=torch.float64)
            kernel = _loader.get_kernel("_vla_log_softmax_kernel_sequential")
            kernel((1,), x_fp32, out, n)
            torch.cuda.synchronize()
            return out
        else:
            x_fp32 = x.float().contiguous()
            batch, n = x_fp32.shape
            out = torch.empty((batch, n), device=x.device, dtype=torch.float64)
            kernel = _loader.get_kernel("_vla_log_softmax_kernel_sequential")
            for i in range(batch):
                row_out = torch.empty(n, device=x.device, dtype=torch.float64)
                kernel((1,), x_fp32[i], row_out, n)
                out[i] = row_out
            torch.cuda.synchronize()
            return out

    # -------------------------------------------------------------------------
    # NORMALIZATION
    # -------------------------------------------------------------------------

    def vla_layernorm(x: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
        """VLA layer normalization."""
        x_f64 = x.double().contiguous().flatten()
        n = x_f64.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        kernel = _loader.get_kernel("_vla_layernorm_kernel_sequential")
        kernel((1,), x_f64, out, n, float(eps))
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_rms_norm(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
        """VLA RMS normalization."""
        x_f64 = x.double().contiguous().flatten()
        n = x_f64.numel()
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        kernel = _loader.get_kernel("_vla_rms_norm_kernel_sequential")
        kernel((1,), x_f64, out, n, float(eps))
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_batch_norm(x: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
        """VLA batch normalization."""
        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()
        batch_size = x.shape[0] if x.ndim > 1 else 1
        out = torch.empty(n, device=x.device, dtype=torch.float64)
        kernel = _loader.get_kernel("_vla_batch_norm_kernel_sequential")
        kernel((1,), x_fp32, out, n, batch_size, float(eps))
        torch.cuda.synchronize()
        return out.view(x.shape)

    def vla_group_norm(x: torch.Tensor, num_groups: int, eps: float = 1e-5) -> torch.Tensor:
        """VLA group normalization (fallback to PyTorch)."""
        return torch.nn.functional.group_norm(x.double(), num_groups, eps=eps)

    # -------------------------------------------------------------------------
    # ATTENTION
    # -------------------------------------------------------------------------

    def vla_scaled_dot_product_attention(
        query: torch.Tensor, key: torch.Tensor, value: torch.Tensor,
        attn_mask: Optional[torch.Tensor] = None, dropout_p: float = 0.0
    ) -> torch.Tensor:
        """VLA scaled dot-product attention.

        Supports both 3D (B, S, D) and 4D (B, H, S, D) inputs.
        """
        # Handle 4D inputs (batch, heads, seq, dim) by reshaping to 3D
        orig_shape = query.shape
        is_4d = query.ndim == 4

        if is_4d:
            B, H, S, D = query.shape
            # Merge batch and heads: (B, H, S, D) -> (B*H, S, D)
            query = query.reshape(B * H, S, D)
            key = key.reshape(B * H, S, D)
            value = value.reshape(B * H, S, D)
            if attn_mask is not None:
                if attn_mask.ndim == 4:
                    attn_mask = attn_mask.reshape(B * H, S, S)

        # QK^T / sqrt(d_k)
        d_k = query.shape[-1]
        scores = vla_bmm(query, key.transpose(-2, -1))
        scores = scores / (d_k ** 0.5)

        if attn_mask is not None:
            scores = scores + attn_mask.double()

        # Softmax along last dimension
        # Reshape for 2D softmax then reshape back
        B_eff, S_q, S_k = scores.shape
        scores_2d = scores.reshape(B_eff * S_q, S_k)
        attn_weights = vla_softmax(scores_2d)
        attn_weights = attn_weights.reshape(B_eff, S_q, S_k)

        # Attention output
        output = vla_bmm(attn_weights.float(), value)

        # Reshape back to 4D if needed
        if is_4d:
            output = output.reshape(B, H, S, -1)

        return output

    # -------------------------------------------------------------------------
    # LOSS FUNCTIONS
    # -------------------------------------------------------------------------

    def vla_mse_loss(pred: torch.Tensor, target: torch.Tensor,
                     reduction: str = 'mean', return_vla: bool = False) -> torch.Tensor:
        """VLA exact MSE loss."""
        pred_fp32 = pred.float().contiguous().flatten()
        target_fp32 = target.float().contiguous().flatten()
        n = pred_fp32.numel()

        out = torch.zeros(1, device=pred.device, dtype=torch.float64)

        kernel = _loader.get_kernel("_vla_mse_loss_kernel_sequential")
        kernel((1,), pred_fp32, target_fp32, out, n)
        torch.cuda.synchronize()

        return out.squeeze()

    def vla_cross_entropy(logits: torch.Tensor, targets: torch.Tensor,
                          reduction: str = 'mean', return_vla: bool = False) -> torch.Tensor:
        """VLA exact cross entropy loss."""
        assert logits.ndim == 2
        batch_size, num_classes = logits.shape

        logits_fp32 = logits.float().contiguous()
        targets_i64 = targets.long().contiguous()

        out = torch.zeros(1, device=logits.device, dtype=torch.float64)
        out_err = torch.zeros(1, device=logits.device, dtype=torch.float64)

        kernel = _loader.get_kernel("_vla_cross_entropy_kernel_sequential")
        kernel((1,), logits_fp32, targets_i64, out, out_err, batch_size, num_classes, num_classes)
        torch.cuda.synchronize()

        if return_vla:
            return VLAResult([out.squeeze(), out_err.squeeze()], logits.device)
        return (out + out_err).squeeze()

    # -------------------------------------------------------------------------
    # UTILITY
    # -------------------------------------------------------------------------

    def vla_embedding(indices: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
        """VLA embedding lookup (exact)."""
        return torch.nn.functional.embedding(indices, weight.double())

    def vla_dropout(x: torch.Tensor, p: float = 0.5, training: bool = True) -> torch.Tensor:
        """VLA dropout."""
        if not training or p == 0:
            return x.double()

        x_fp32 = x.float().contiguous().flatten()
        n = x_fp32.numel()

        mask = (torch.rand(n, device=x.device) > p).float()
        scale = 1.0 / (1.0 - p)

        out = torch.empty(n, device=x.device, dtype=torch.float64)

        BLOCK = 1024
        grid = ((n + BLOCK - 1) // BLOCK,)
        kernel = _loader.get_kernel("_vla_dropout_kernel")
        kernel(grid, x_fp32, mask, out, float(scale), n)
        torch.cuda.synchronize()

        return out.view(x.shape)

    # Optimizers work without cubins (pure Python + FP64 state)
    class VLAAdamW(torch.optim.Optimizer):
        """AdamW with FP64 state for exact accumulation."""

        def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                     weight_decay=0.01, amsgrad=False):
            defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay,
                          amsgrad=amsgrad)
            super().__init__(params, defaults)

        @torch.no_grad()
        def step(self, closure=None):
            loss = None
            if closure is not None:
                with torch.enable_grad():
                    loss = closure()

            for group in self.param_groups:
                for p in group['params']:
                    if p.grad is None:
                        continue

                    grad = p.grad
                    if grad.is_sparse:
                        raise RuntimeError("VLAAdamW does not support sparse gradients")

                    amsgrad = group['amsgrad']
                    state = self.state[p]

                    # Initialize state in FP64
                    if len(state) == 0:
                        state['step'] = 0
                        state['exp_avg'] = torch.zeros_like(p, dtype=torch.float64)
                        state['exp_avg_sq'] = torch.zeros_like(p, dtype=torch.float64)
                        if amsgrad:
                            state['max_exp_avg_sq'] = torch.zeros_like(p, dtype=torch.float64)

                    exp_avg, exp_avg_sq = state['exp_avg'], state['exp_avg_sq']
                    if amsgrad:
                        max_exp_avg_sq = state['max_exp_avg_sq']

                    beta1, beta2 = group['betas']
                    state['step'] += 1

                    # Decoupled weight decay
                    p.data.mul_(1 - group['lr'] * group['weight_decay'])

                    # FP64 gradient accumulation
                    grad_f64 = grad.double()

                    # Update moments in FP64
                    exp_avg.mul_(beta1).add_(grad_f64, alpha=1 - beta1)
                    exp_avg_sq.mul_(beta2).addcmul_(grad_f64, grad_f64, value=1 - beta2)

                    if amsgrad:
                        torch.max(max_exp_avg_sq, exp_avg_sq, out=max_exp_avg_sq)
                        denom = max_exp_avg_sq.sqrt().add_(group['eps'])
                    else:
                        denom = exp_avg_sq.sqrt().add_(group['eps'])

                    # Bias correction
                    bias_correction1 = 1 - beta1 ** state['step']
                    bias_correction2 = 1 - beta2 ** state['step']
                    step_size = group['lr'] * (bias_correction2 ** 0.5) / bias_correction1

                    # Update parameters
                    p.data.add_((exp_avg / denom).to(p.dtype), alpha=-step_size)

            return loss

    class VLASGD(torch.optim.Optimizer):
        """SGD with FP64 momentum state for exact accumulation."""

        def __init__(self, params, lr=0.01, momentum=0, dampening=0,
                     weight_decay=0, nesterov=False):
            if nesterov and (momentum <= 0 or dampening != 0):
                raise ValueError("Nesterov requires momentum > 0 and dampening = 0")
            defaults = dict(lr=lr, momentum=momentum, dampening=dampening,
                          weight_decay=weight_decay, nesterov=nesterov)
            super().__init__(params, defaults)

        @torch.no_grad()
        def step(self, closure=None):
            loss = None
            if closure is not None:
                with torch.enable_grad():
                    loss = closure()

            for group in self.param_groups:
                for p in group['params']:
                    if p.grad is None:
                        continue

                    d_p = p.grad

                    if group['weight_decay'] != 0:
                        d_p = d_p.add(p.data, alpha=group['weight_decay'])

                    if group['momentum'] != 0:
                        state = self.state[p]

                        if 'momentum_buffer' not in state:
                            # Initialize in FP64
                            state['momentum_buffer'] = torch.zeros_like(p, dtype=torch.float64)
                            buf = state['momentum_buffer']
                            buf.add_(d_p.double())
                        else:
                            buf = state['momentum_buffer']
                            buf.mul_(group['momentum']).add_(
                                d_p.double(), alpha=1 - group['dampening']
                            )

                        if group['nesterov']:
                            d_p = d_p.add(buf.to(d_p.dtype), alpha=group['momentum'])
                        else:
                            d_p = buf.to(d_p.dtype)

                    p.data.add_(d_p, alpha=-group['lr'])

            return loss


# =============================================================================
# CUBIN COMPILATION SCRIPT (for building pip package)
# =============================================================================

def compile_triton_to_cubin():
    """
    Compile Triton kernels to cubins for all target architectures.

    Run this on a Linux machine with CUDA to generate cubins:

        python -c "from simgen.vla_runtime import compile_triton_to_cubin; compile_triton_to_cubin()"

    Outputs cubins to simgen/cubin/ directory.
    """
    if not _USE_TRITON:
        raise RuntimeError("Triton required for compilation. Install: pip install triton")

    import os
    from pathlib import Path

    # Target architectures
    ARCHS = [75, 80, 86, 89, 90]

    # Get output directory
    module_dir = Path(__file__).parent
    cubin_dir = module_dir / "cubin_v2"
    cubin_dir.mkdir(exist_ok=True)

    print(f"Compiling Triton kernels to {cubin_dir}")
    print(f"Target architectures: {ARCHS}")

    # Import Triton compiler
    from triton.compiler import compile as triton_compile
    from triton.compiler import ASTSource

    # Get kernel functions from vla_triton
    from . import vla_triton

    kernels_to_compile = []
    for name in dir(vla_triton):
        obj = getattr(vla_triton, name)
        if hasattr(obj, '__wrapped__'):  # Triton JIT function
            kernels_to_compile.append((name, obj))

    print(f"Found {len(kernels_to_compile)} kernels to compile")

    # TODO: Implement actual compilation
    # This requires understanding Triton's internal compilation API
    # which varies between Triton versions

    print("Cubin compilation not yet implemented.")
    print("For now, use vla_triton.py directly on Linux.")


# =============================================================================
# VERSION INFO
# =============================================================================

def get_backend_info() -> dict:
    """Get information about the active backend."""
    if _TRITON_BACKEND_OK:
        backend = "triton"
    elif _USE_PYTORCH_FALLBACK:
        backend = "pytorch_fp64"
    else:
        backend = "cubin"
    return {
        "version": __version__,
        "backend": backend,
        "triton_available": _USE_TRITON,
        "triton_backend_ok": _TRITON_BACKEND_OK,
        "cubin_available": _USE_CUBIN,
        "pytorch_fallback": _USE_PYTORCH_FALLBACK,
        "cuda_available": torch.cuda.is_available(),
        "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
    }
