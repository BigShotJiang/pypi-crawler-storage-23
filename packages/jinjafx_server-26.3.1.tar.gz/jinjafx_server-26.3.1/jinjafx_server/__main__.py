import sys, jinjafx_server
sys.argv[0] = 'jinjafx_server'
sys.exit(jinjafx_server.main())
