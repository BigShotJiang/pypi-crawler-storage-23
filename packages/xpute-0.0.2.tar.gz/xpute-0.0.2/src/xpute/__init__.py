# src/xpute/__init__.py

from __future__ import annotations
from dataclasses import dataclass
import sys
from typing import Any, TextIO, List, Callable

__all__ = ["compile", "sprintf", "printf"]

@dataclass
class _Fmt:
  left: bool = False
  plus: bool = False
  space: bool = False
  zero: bool = False
  alt: bool = False
  width: int = -1
  prec: int = -1
  conv: str = "s"

Token = tuple[str, Any]  # ("lit", str) or ("fmt", _Fmt)

def compile(fmt: str) -> Callable[[list[Any]], str]:
  toks = _parse(fmt)
  def _run(args: list[Any]) -> str:
    return _format(toks, args)
  return _run

def sprintf(fmt: str, *args: Any) -> str:
  return compile(fmt)(list(args))

def printf(fmt: str, *args: Any, file: TextIO | None = None, end: str = "") -> int:
  if file is None:
    file = sys.stdout
  s = sprintf(fmt, *args) + end
  file.write(s)
  return len(s)

def _parse(fmt: str) -> List[Token]:
  out: List[Token] = []
  i = 0

  def push_lit(s: str) -> None:
    if not s:
      return
    if out and out[-1][0] == "lit":
      out[-1] = ("lit", out[-1][1] + s)
    else:
      out.append(("lit", s))

  while i < len(fmt):
    j = fmt.find("%", i)
    if j < 0:
      push_lit(fmt[i:])
      break
    push_lit(fmt[i:j])
    i = j + 1

    if i >= len(fmt):
      push_lit("%")
      break

    if fmt[i] == "%":
      f = _Fmt(conv="%")
      out.append(("fmt", f))
      i += 1
      continue

    f = _Fmt()
    while i < len(fmt):
      ch = fmt[i]
      if ch == "-": f.left = True
      elif ch == "+": f.plus = True
      elif ch == " ": f.space = True
      elif ch == "0": f.zero = True
      elif ch == "#": f.alt = True
      else: break
      i += 1

    w, n = _read_int(fmt, i)
    if n:
      f.width = w
      i += n

    if i < len(fmt) and fmt[i] == ".":
      i += 1
      p, n = _read_int(fmt, i)
      f.prec = p if n else 0
      i += n

    # length modifiers: ignored
    if i < len(fmt) and fmt[i] in "hlztj":
      c0 = fmt[i]; i += 1
      if i < len(fmt) and ((c0 == "h" and fmt[i] == "h") or (c0 == "l" and fmt[i] == "l")):
        i += 1

    if i >= len(fmt):
      push_lit("%")
      break

    c = fmt[i]; i += 1
    if c not in "diuxXobscefpg%":
      push_lit("%" + c)
      continue
    f.conv = c
    out.append(("fmt", f))

  return out

def _read_int(s: str, i: int) -> tuple[int, int]:
  n = 0
  start = i
  while i < len(s) and s[i].isdigit():
    n = n * 10 + (ord(s[i]) - 48)
    i += 1
  return (n, i - start)

def _pad(s: str, width: int, left: bool, zero: bool) -> str:
  if width <= 0 or len(s) >= width:
    return s
  p = ("0" if zero else " ") * (width - len(s))
  return s + p if left else p + s

def _format(toks: List[Token], args: List[Any]) -> str:
  ai = 0
  out: list[str] = []
  for k, v in toks:
    if k == "lit":
      out.append(v)
      continue
    f: _Fmt = v
    if f.conv == "%":
      out.append("%")
      continue
    a = args[ai] if ai < len(args) else None
    ai += 1
    out.append(_one(f, a))
  return "".join(out)

def _one(f: _Fmt, a: Any) -> str:
  c = f.conv
  if c == "s":
    s = "None" if a is None else str(a)
    if f.prec >= 0:
      s = s[:f.prec]
    return _pad(s, f.width, f.left, False)

  if c == "c":
    n = int(a) if a is not None else 0
    s = chr(n & 0xffff)
    return _pad(s, f.width, f.left, False)

  if c == "p":
    s = "0x%08x" % (hash(str(a)) & 0xffffffff)
    return _pad(s, f.width, f.left, f.zero)

  if c in "diuxXob":
    n = int(a) if a is not None else 0
    neg = False
    if c in "di":
      if n < 0:
        neg = True
        n = -n
    else:
      n &= (1 << 64) - 1

    base = 10
    if c in "xX": base = 16
    elif c == "o": base = 8
    elif c == "b": base = 2

    digits = "0123456789abcdef"
    s = "0" if n == 0 else ""
    while n:
      s = digits[n % base] + s
      n //= base
    if c == "X":
      s = s.upper()

    if f.prec >= 0:
      s = s.rjust(f.prec, "0")

    prefix = ""
    if f.alt:
      if c == "x": prefix = "0x"
      elif c == "X": prefix = "0X"
      elif c == "o": prefix = "0"
      elif c == "b": prefix = "0b"

    sign = ""
    if neg: sign = "-"
    elif f.plus: sign = "+"
    elif f.space: sign = " "

    core = prefix + s
    if (not f.left) and f.zero and f.prec < 0 and f.width > 0:
      need = f.width - (len(sign) + len(core))
      if need > 0:
        core = prefix + ("0" * need) + s
      return sign + core

    return _pad(sign + core, f.width, f.left, False)

  if c in "feg":
    try:
      x = float(a)
    except Exception:
      return str(a)
    if x != x or x == float("inf") or x == float("-inf"):
      return _pad(str(x), f.width, f.left, False)

    sign = ""
    if x < 0:
      sign = "-"
      x = -x
    elif f.plus:
      sign = "+"
    elif f.space:
      sign = " "

    p = f.prec if f.prec >= 0 else 6
    if c == "f":
      s = format(x, f".{p}f")
    elif c == "e":
      s = format(x, f".{p}e")
    else:
      s = format(x, f".{p}g")
      if f.alt and ("e" not in s and "E" not in s) and "." not in s:
        s += "."

    if (not f.left) and f.zero and f.width > 0:
      need = f.width - (len(sign) + len(s))
      if need > 0:
        s = ("0" * need) + s
      return sign + s

    return _pad(sign + s, f.width, f.left, False)

  return str(a)