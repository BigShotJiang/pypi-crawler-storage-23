from aes70.ocp1.ocabitset16 import OcaBitSet16

OcaParameterMask = OcaBitSet16;
