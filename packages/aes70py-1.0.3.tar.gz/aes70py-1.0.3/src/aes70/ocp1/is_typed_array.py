import array

def is_typed_array(o):
    return isinstance(x, (bytearray, memoryview, array.array))

