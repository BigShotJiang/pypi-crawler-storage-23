"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocanetworksignalchannelstatus import OcaNetworkSignalChannelStatus as type

OcaNetworkSignalChannelStatus = Enum8(type)
