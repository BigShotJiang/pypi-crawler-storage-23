"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocamediaclocklockstate import OcaMediaClockLockState as type

OcaMediaClockLockState = Enum8(type)
