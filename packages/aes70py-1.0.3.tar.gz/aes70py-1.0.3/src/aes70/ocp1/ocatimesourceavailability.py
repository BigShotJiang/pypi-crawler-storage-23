"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocatimesourceavailability import OcaTimeSourceAvailability as type

OcaTimeSourceAvailability = Enum8(type)
