"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocawaveformtype import OcaWaveformType as type

OcaWaveformType = Enum8(type)
