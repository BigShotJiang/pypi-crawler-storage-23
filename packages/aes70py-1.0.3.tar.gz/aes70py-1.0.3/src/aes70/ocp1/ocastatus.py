"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocastatus import OcaStatus as type

OcaStatus = Enum8(type)
