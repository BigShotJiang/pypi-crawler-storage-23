"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocanetworkcontrolprotocol import OcaNetworkControlProtocol as type

OcaNetworkControlProtocol = Enum8(type)
