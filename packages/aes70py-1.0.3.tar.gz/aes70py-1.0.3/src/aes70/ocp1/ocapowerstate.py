"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocapowerstate import OcaPowerState as type

OcaPowerState = Enum8(type)
