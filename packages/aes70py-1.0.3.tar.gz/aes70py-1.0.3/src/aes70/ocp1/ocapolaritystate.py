"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocapolaritystate import OcaPolarityState as type

OcaPolarityState = Enum8(type)
