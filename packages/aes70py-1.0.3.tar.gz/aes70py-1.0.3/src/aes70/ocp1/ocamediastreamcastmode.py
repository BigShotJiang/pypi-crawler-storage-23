"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocamediastreamcastmode import OcaMediaStreamCastMode as type

OcaMediaStreamCastMode = Enum8(type)
