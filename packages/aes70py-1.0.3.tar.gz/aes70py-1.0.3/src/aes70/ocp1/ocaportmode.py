"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocaportmode import OcaPortMode as type

OcaPortMode = Enum8(type)
