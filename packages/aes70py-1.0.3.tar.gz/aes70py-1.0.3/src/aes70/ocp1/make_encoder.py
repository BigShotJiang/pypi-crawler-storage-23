def makeEncoder(name):
    # Throw error to indicate the function is not implemented
    raise Exception('Not implemented.')
