"""
This file is part of aes70py.
This file has been generated.
"""
from .enum16 import Enum16
from aes70.types.ocacomponent import OcaComponent as type

OcaComponent = Enum16(type)
