"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocatimesourcesyncstatus import OcaTimeSourceSyncStatus as type

OcaTimeSourceSyncStatus = Enum8(type)
