"""
This file is part of aes70py.
This file has been generated.
"""
from .enum8 import Enum8
from aes70.types.ocaparametriceqshape import OcaParametricEQShape as type

OcaParametricEQShape = Enum8(type)
