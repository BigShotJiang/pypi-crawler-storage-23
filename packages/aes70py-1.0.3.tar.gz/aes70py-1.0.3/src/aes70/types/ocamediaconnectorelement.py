"""
This file is part of aes70py.
This file has been generated.
"""

  OcaMediaConnectorElement_PinMap = 1
  OcaMediaConnectorElement_Connection = 2
  OcaMediaConnectorElement_Coding = 4
  OcaMediaConnectorElement_AlignmentLevel = 8
  OcaMediaConnectorElement_AlignmentGain = 16

