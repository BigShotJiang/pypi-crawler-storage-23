"""
This file is part of aes70py.
This file has been generated.
"""
from aes70.types.enum import Enum

# Command values for OcaMediaNetwork.ControlConnector(...)
# @class OcaMediaConnectorCommand
OcaMediaConnectorCommand = Enum({
    'None': 0,
    'Start': 1,
    'Pause': 2,
})
