"""
This file is part of aes70py.
This file has been generated.
"""

  OcaObjectSearchResultFlags_ONo = 1
  OcaObjectSearchResultFlags_ClassIdentification = 2
  OcaObjectSearchResultFlags_ContainerPath = 4
  OcaObjectSearchResultFlags_Role = 8
  OcaObjectSearchResultFlags_Label = 16

