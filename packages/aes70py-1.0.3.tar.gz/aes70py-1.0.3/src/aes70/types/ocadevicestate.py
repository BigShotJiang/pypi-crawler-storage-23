"""
This file is part of aes70py.
This file has been generated.
"""

  OcaDeviceState_Operational = 1
  OcaDeviceState_Disabled = 2
  OcaDeviceState_Error = 4
  OcaDeviceState_Initializing = 8
  OcaDeviceState_Updating = 16

