"""
This file is part of aes70py.
This file has been generated.
"""
from aes70.types.enum import Enum

# Mute states
# @class OcaMuteState
OcaMuteState = Enum({
    'Muted': 1,
    'Unmuted': 2,
})
