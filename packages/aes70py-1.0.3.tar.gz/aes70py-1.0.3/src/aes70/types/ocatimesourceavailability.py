"""
This file is part of aes70py.
This file has been generated.
"""
from aes70.types.enum import Enum

# States of time sources
# @class OcaTimeSourceAvailability
OcaTimeSourceAvailability = Enum({
    'Unavailable': 0,
    'Available': 1,
})
