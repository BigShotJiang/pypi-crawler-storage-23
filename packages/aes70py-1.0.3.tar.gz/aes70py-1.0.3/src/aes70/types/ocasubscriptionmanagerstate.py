"""
This file is part of aes70py.
This file has been generated.
"""
from aes70.types.enum import Enum

# Enum describing **OcaSubscriptionManager** states.
# @class OcaSubscriptionManagerState
OcaSubscriptionManagerState = Enum({
    'Normal': 1,
    'EventsDisabled': 2,
})
