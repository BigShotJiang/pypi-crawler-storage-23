"""
This file is part of aes70py.
This file has been generated.
"""
from aes70.types.enum import Enum

# Polarity states
# @class OcaPolarityState
OcaPolarityState = Enum({
    'NonInverted': 1,
    'Inverted': 2,
})
