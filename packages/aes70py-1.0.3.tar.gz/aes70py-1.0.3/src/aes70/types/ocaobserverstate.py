"""
This file is part of aes70py.
This file has been generated.
"""
from aes70.types.enum import Enum

# Interpolation law for ramper to use.
# @class OcaObserverState
OcaObserverState = Enum({
    'NotTriggered': 0,
    'Triggered': 1,
})
