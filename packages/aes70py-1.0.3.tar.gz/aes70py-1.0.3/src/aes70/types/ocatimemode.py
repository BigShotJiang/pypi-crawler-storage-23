"""
This file is part of aes70py.
This file has been generated.
"""
from aes70.types.enum import Enum

# Time mode of **OcaTask** agent.
# @class OcaTimeMode
OcaTimeMode = Enum({
    'Absolute': 1,
    'Relative': 2,
})
