"""Execution helpers shared by CLI batch mode and GUI."""

from __future__ import annotations

import time
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from ncheck.logic.core import normalize_host, normalize_url, parse_ports_spec
from ncheck.services import (
    run_attack_surface_assessment,
    run_dns_lookup,
    run_http_check,
    run_osint_domain,
    run_osint_email,
    run_personal_security_check,
    run_ping,
    run_port_scan,
    run_security_audit,
    run_system_usage,
    run_tls_inspection,
    run_traceroute,
)

_SUPPORTED_CHECKS = (
    "ping",
    "dns",
    "http",
    "ports",
    "traceroute",
    "tls",
    "system",
    "audit",
    "surface",
    "osint_domain",
    "osint_email",
    "personal_security",
)


def available_checks() -> tuple[str, ...]:
    return _SUPPORTED_CHECKS


def _coerce_int(
    raw_value: Any,
    *,
    name: str,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int:
    try:
        value = int(raw_value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid integer for '{name}': {raw_value!r}.") from exc

    if minimum is not None and value < minimum:
        raise ValueError(f"'{name}' must be >= {minimum}.")
    if maximum is not None and value > maximum:
        raise ValueError(f"'{name}' must be <= {maximum}.")

    return value


def _coerce_float(
    raw_value: Any,
    *,
    name: str,
    minimum: float | None = None,
    maximum: float | None = None,
) -> float:
    try:
        value = float(raw_value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid number for '{name}': {raw_value!r}.") from exc

    if minimum is not None and value < minimum:
        raise ValueError(f"'{name}' must be >= {minimum}.")
    if maximum is not None and value > maximum:
        raise ValueError(f"'{name}' must be <= {maximum}.")

    return value


def _coerce_bool(raw_value: Any, *, name: str) -> bool:
    if isinstance(raw_value, bool):
        return raw_value
    if isinstance(raw_value, int):
        return bool(raw_value)
    if isinstance(raw_value, str):
        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "y"}:
            return True
        if normalized in {"0", "false", "no", "n"}:
            return False

    raise ValueError(f"Invalid boolean for '{name}': {raw_value!r}.")


def _coerce_ports(raw_value: Any) -> list[int]:
    if isinstance(raw_value, str):
        return parse_ports_spec(raw_value)

    if isinstance(raw_value, list):
        unique_ports: set[int] = set()
        for item in raw_value:
            port = _coerce_int(item, name="port", minimum=1, maximum=65535)
            unique_ports.add(port)
        if not unique_ports:
            raise ValueError("Ports list cannot be empty.")
        return sorted(unique_ports)

    raise ValueError("Ports must be either a comma/range string or a list of integers.")


def _coerce_optional_str(raw_value: Any, *, name: str) -> str | None:
    if raw_value is None:
        return None
    if isinstance(raw_value, str):
        cleaned = raw_value.strip()
        return cleaned or None
    raise ValueError(f"Invalid value for '{name}'. Must be a string.")


def _iso_utc(raw_datetime: datetime) -> str:
    return raw_datetime.replace(microsecond=0).isoformat().replace("+00:00", "Z")


@dataclass(slots=True)
class CheckExecution:
    check: str
    ok: bool
    payload: dict[str, Any]
    started_at: str
    finished_at: str
    duration_ms: float
    input: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "check": self.check,
            "ok": self.ok,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration_ms": round(self.duration_ms, 3),
            "input": self.input,
            "payload": self.payload,
        }


def _execute_ping(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    host = normalize_host(str(options.get("host", "")))
    count = _coerce_int(options.get("count", 4), name="count", minimum=1, maximum=20)
    timeout = _coerce_float(options.get("timeout", 2.0), name="timeout", minimum=0.1, maximum=30.0)
    result = run_ping(host=host, count=count, timeout=timeout)
    return result.to_dict(), result.ok


def _execute_dns(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    host = normalize_host(str(options.get("host", "")))
    family = str(options.get("family", "any")).lower()
    if family not in {"any", "ipv4", "ipv6"}:
        raise ValueError("Family must be one of: any, ipv4, ipv6.")
    result = run_dns_lookup(host=host, family=family)
    return result.to_dict(), result.ok


def _execute_http(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    url = normalize_url(str(options.get("url", "")))
    method = str(options.get("method", "GET")).upper()
    if method not in {"GET", "HEAD"}:
        raise ValueError("Method must be GET or HEAD.")
    timeout = _coerce_float(options.get("timeout", 5.0), name="timeout", minimum=0.1, maximum=60.0)
    follow_redirects = _coerce_bool(options.get("follow_redirects", True), name="follow_redirects")
    result = run_http_check(
        url=url,
        method=method,
        timeout=timeout,
        follow_redirects=follow_redirects,
    )
    return result.to_dict(), result.ok


def _execute_ports(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    host = normalize_host(str(options.get("host", "")))
    ports = _coerce_ports(options.get("ports", "22,80,443"))
    timeout = _coerce_float(options.get("timeout", 0.6), name="timeout", minimum=0.05, maximum=10.0)
    workers = _coerce_int(options.get("workers", 100), name="workers", minimum=1, maximum=512)
    result = run_port_scan(
        host=host,
        ports=ports,
        timeout=timeout,
        workers=workers,
    )
    return result.to_dict(), result.ok


def _execute_traceroute(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    host = normalize_host(str(options.get("host", "")))
    max_hops = _coerce_int(options.get("max_hops", 20), name="max_hops", minimum=1, maximum=64)
    timeout = _coerce_float(options.get("timeout", 1.5), name="timeout", minimum=0.1, maximum=10.0)
    result = run_traceroute(host=host, max_hops=max_hops, timeout_seconds=timeout)
    return result.to_dict(), result.ok


def _execute_tls(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    host = normalize_host(str(options.get("host", "")))
    port = _coerce_int(options.get("port", 443), name="port", minimum=1, maximum=65535)
    timeout = _coerce_float(options.get("timeout", 5.0), name="timeout", minimum=0.2, maximum=30.0)
    result = run_tls_inspection(host=host, port=port, timeout_seconds=timeout)
    return result.to_dict(), result.ok


def _execute_system(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    interval = _coerce_float(
        options.get("interval", 0.2),
        name="interval",
        minimum=0.1,
        maximum=5.0,
    )
    top = _coerce_int(options.get("top", 8), name="top", minimum=1, maximum=30)
    result = run_system_usage(interval_seconds=interval, top=top)
    return result.to_dict(), result.ok


def _execute_audit(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    host = normalize_host(str(options.get("host", "")))
    authorized = _coerce_bool(options.get("authorized", False), name="authorized")
    if not authorized:
        raise ValueError("Audit checks require 'authorized=true'.")

    ports = _coerce_ports(options.get("ports", "21,22,23,80,443,445,3389"))
    timeout = _coerce_float(options.get("timeout", 1.0), name="timeout", minimum=0.1, maximum=10.0)
    workers = _coerce_int(options.get("workers", 120), name="workers", minimum=1, maximum=512)

    raw_url = options.get("url")
    normalized_url: str | None
    if raw_url is None:
        normalized_url = None
    elif isinstance(raw_url, str) and raw_url.strip():
        normalized_url = normalize_url(raw_url)
    elif isinstance(raw_url, str):
        normalized_url = None
    else:
        raise ValueError("URL must be a string when provided.")

    result = run_security_audit(
        host=host,
        ports=ports,
        timeout_seconds=timeout,
        workers=workers,
        url=normalized_url,
    )
    return result.to_dict(), result.ok


def _execute_surface(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    host = normalize_host(str(options.get("host", "")))
    authorized = _coerce_bool(options.get("authorized", False), name="authorized")
    ports = _coerce_ports(options.get("ports", "21,22,23,80,443,445,3389"))
    timeout = _coerce_float(options.get("timeout", 1.0), name="timeout", minimum=0.1, maximum=10.0)
    workers = _coerce_int(options.get("workers", 120), name="workers", minimum=1, maximum=512)
    tls_port = _coerce_int(options.get("tls_port", 443), name="tls_port", minimum=1, maximum=65535)
    http_method = str(options.get("http_method", "HEAD")).upper()
    if http_method not in {"GET", "HEAD"}:
        raise ValueError("http_method must be GET or HEAD.")

    raw_url = _coerce_optional_str(options.get("url"), name="url")
    result = run_attack_surface_assessment(
        host=host,
        ports=ports,
        authorized=authorized,
        timeout_seconds=timeout,
        workers=workers,
        url=raw_url,
        tls_port=tls_port,
        http_method=http_method,
    )
    return result.to_dict(), result.ok


def _execute_osint_domain(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    target = normalize_host(str(options.get("target") or options.get("host") or ""))
    timeout = _coerce_float(options.get("timeout", 5.0), name="timeout", minimum=0.2, maximum=30.0)
    include_subdomains = _coerce_bool(
        options.get("include_subdomains", True),
        name="include_subdomains",
    )
    max_subdomains = _coerce_int(
        options.get("max_subdomains", 250),
        name="max_subdomains",
        minimum=1,
        maximum=2000,
    )

    result = run_osint_domain(
        target=target,
        timeout_seconds=timeout,
        include_subdomains=include_subdomains,
        max_subdomains=max_subdomains,
    )
    return result.to_dict(), result.ok


def _execute_osint_email(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    raw_email = _coerce_optional_str(options.get("email"), name="email")
    if not raw_email:
        raise ValueError("Email cannot be empty.")

    timeout = _coerce_float(options.get("timeout", 5.0), name="timeout", minimum=0.2, maximum=30.0)
    hibp_api_key = _coerce_optional_str(options.get("hibp_api_key"), name="hibp_api_key")
    result = run_osint_email(
        email=raw_email,
        timeout_seconds=timeout,
        hibp_api_key=hibp_api_key,
    )
    return result.to_dict(), result.ok


def _execute_personal_security(options: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
    top_ports = _coerce_int(options.get("top_ports", 30), name="top_ports", minimum=1, maximum=200)
    risky_ports = _coerce_ports(options.get("risky_ports", "21,23,445,3389,5900,6379,27017"))
    result = run_personal_security_check(
        top_ports=top_ports,
        risky_ports=risky_ports,
    )
    return result.to_dict(), result.ok


_EXECUTORS = {
    "ping": _execute_ping,
    "dns": _execute_dns,
    "http": _execute_http,
    "ports": _execute_ports,
    "traceroute": _execute_traceroute,
    "tls": _execute_tls,
    "system": _execute_system,
    "audit": _execute_audit,
    "surface": _execute_surface,
    "osint_domain": _execute_osint_domain,
    "osint_email": _execute_osint_email,
    "personal_security": _execute_personal_security,
}


def execute_check(
    check: str,
    options: Mapping[str, Any] | None = None,
) -> tuple[dict[str, Any], bool]:
    normalized_check = check.strip().lower()
    if normalized_check not in _EXECUTORS:
        supported = ", ".join(_SUPPORTED_CHECKS)
        raise ValueError(f"Unknown check '{check}'. Supported checks: {supported}.")

    options_map: Mapping[str, Any] = options or {}
    return _EXECUTORS[normalized_check](options_map)


def execute_check_safe(check: str, options: Mapping[str, Any] | None = None) -> CheckExecution:
    started = datetime.now(tz=UTC)
    started_perf = time.perf_counter()
    options_copy = dict(options or {})
    normalized_check = check.strip().lower()

    try:
        payload, ok = execute_check(normalized_check, options_copy)
    except Exception as exc:
        payload = {
            "status": "error",
            "error_message": str(exc),
        }
        ok = False

    finished = datetime.now(tz=UTC)
    duration_ms = (time.perf_counter() - started_perf) * 1000

    return CheckExecution(
        check=normalized_check,
        ok=ok,
        payload=payload,
        started_at=_iso_utc(started),
        finished_at=_iso_utc(finished),
        duration_ms=duration_ms,
        input=options_copy,
    )


def build_batch_report(executions: list[CheckExecution]) -> dict[str, Any]:
    successful = len([execution for execution in executions if execution.ok])
    failed = len(executions) - successful

    started_at = executions[0].started_at if executions else None
    finished_at = executions[-1].finished_at if executions else None
    duration_ms = round(sum(execution.duration_ms for execution in executions), 3)

    return {
        "status": "success" if failed == 0 else "error",
        "summary": {
            "total_checks": len(executions),
            "successful_checks": successful,
            "failed_checks": failed,
            "started_at": started_at,
            "finished_at": finished_at,
            "duration_ms": duration_ms,
        },
        "results": [execution.to_dict() for execution in executions],
    }
