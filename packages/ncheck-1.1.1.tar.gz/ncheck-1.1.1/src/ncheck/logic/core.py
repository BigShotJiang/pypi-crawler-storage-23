"""Core normalization helpers shared by CLI and services."""

from __future__ import annotations

from urllib.parse import urlparse


def normalize_host(raw_host: str) -> str:
    host = raw_host.strip()
    if not host:
        raise ValueError("Host cannot be empty.")
    return host


def humanize_key(raw_key: str) -> str:
    return raw_key.replace("_", " ").title()


def normalize_url(raw_url: str) -> str:
    url = raw_url.strip()
    if not url:
        raise ValueError("URL cannot be empty.")

    if "://" not in url:
        url = f"https://{url}"

    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("URL scheme must be http or https.")
    if not parsed.netloc:
        raise ValueError("URL must include a valid host.")

    return url


def parse_ports_spec(raw_ports: str) -> list[int]:
    ports: set[int] = set()
    chunks = [chunk.strip() for chunk in raw_ports.split(",") if chunk.strip()]

    if not chunks:
        raise ValueError("Ports list cannot be empty.")

    for chunk in chunks:
        if "-" in chunk:
            start_str, end_str = chunk.split("-", maxsplit=1)
            if not start_str.isdigit() or not end_str.isdigit():
                raise ValueError(f"Invalid range '{chunk}'. Use format start-end.")

            start, end = int(start_str), int(end_str)
            if start > end:
                raise ValueError(f"Invalid range '{chunk}'. Start must be <= end.")

            for port in range(start, end + 1):
                _ensure_valid_port(port)
                ports.add(port)
            continue

        if not chunk.isdigit():
            raise ValueError(f"Invalid port '{chunk}'.")

        port = int(chunk)
        _ensure_valid_port(port)
        ports.add(port)

    return sorted(ports)


def _ensure_valid_port(port: int) -> None:
    if not 1 <= port <= 65535:
        raise ValueError(f"Invalid port '{port}'. Port must be between 1 and 65535.")
