"""Batch plan loading and validation utilities."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def _load_yaml(text: str) -> Any:
    try:
        import yaml
    except ModuleNotFoundError as exc:
        raise ValueError(
            "YAML plan detected but dependency 'PyYAML' is missing. "
            "Install with: pip install -e .[batch]"
        ) from exc

    try:
        return yaml.safe_load(text)
    except yaml.YAMLError as exc:  # type: ignore[attr-defined]
        raise ValueError(f"Invalid YAML batch plan: {exc}") from exc


def _load_json(text: str) -> Any:
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON batch plan: {exc.msg}.") from exc


def _normalize_entry(raw_entry: Any, index: int) -> dict[str, Any]:
    if not isinstance(raw_entry, dict):
        raise ValueError(f"Entry #{index} must be an object.")

    raw_check = raw_entry.get("check")
    if not isinstance(raw_check, str) or not raw_check.strip():
        raise ValueError(f"Entry #{index} must define a non-empty 'check' field.")

    options: dict[str, Any] = {}
    raw_options = raw_entry.get("options")
    if raw_options is not None:
        if not isinstance(raw_options, dict):
            raise ValueError(f"Entry #{index} field 'options' must be an object.")
        options.update(raw_options)

    for key, value in raw_entry.items():
        if key in {"check", "options"}:
            continue
        options[key] = value

    return {
        "check": raw_check.strip().lower(),
        "options": options,
    }


def load_batch_plan(plan_file: str | Path) -> list[dict[str, Any]]:
    path = Path(plan_file)
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ValueError(f"Unable to read batch plan '{path}': {exc}") from exc

    stripped = text.lstrip()
    if not stripped:
        raise ValueError("Batch plan file cannot be empty.")

    suffix = path.suffix.lower()
    if suffix in {".yaml", ".yml"}:
        data = _load_yaml(text)
    elif suffix == ".json":
        data = _load_json(text)
    elif stripped.startswith("{") or stripped.startswith("["):
        data = _load_json(text)
    else:
        data = _load_yaml(text)

    if isinstance(data, dict):
        raw_checks = data.get("checks")
    elif isinstance(data, list):
        raw_checks = data
    else:
        raise ValueError("Batch plan must be a list or an object containing 'checks'.")

    if not isinstance(raw_checks, list):
        raise ValueError("Batch plan field 'checks' must be a list.")
    if not raw_checks:
        raise ValueError("Batch plan must contain at least one check entry.")

    normalized_checks = [
        _normalize_entry(raw_entry=raw_entry, index=index)
        for index, raw_entry in enumerate(raw_checks, start=1)
    ]
    return normalized_checks
