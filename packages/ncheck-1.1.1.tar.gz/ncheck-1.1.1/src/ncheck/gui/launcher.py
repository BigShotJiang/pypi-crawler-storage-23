"""Launcher utilities for the Streamlit-based ncheck GUI."""

from __future__ import annotations

import argparse
import importlib.util
import subprocess
import sys
from pathlib import Path


def launch_streamlit_dashboard(
    *,
    host: str = "127.0.0.1",
    port: int = 8501,
    headless: bool = False,
) -> int:
    if importlib.util.find_spec("streamlit") is None:
        raise RuntimeError(
            "Dependency 'streamlit' is missing. Install with: pip install -e .[gui]"
        )

    app_path = Path(__file__).resolve().with_name("app.py")
    command = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(app_path),
        "--server.address",
        host,
        "--server.port",
        str(port),
        "--server.headless",
        "true" if headless else "false",
        "--browser.gatherUsageStats",
        "false",
    ]
    completed = subprocess.run(command, check=False)
    return int(completed.returncode)


def main() -> None:
    parser = argparse.ArgumentParser(description="Launch ncheck GUI dashboard.")
    parser.add_argument("--host", default="127.0.0.1", help="Server bind address.")
    parser.add_argument(
        "--port",
        type=int,
        default=8501,
        help="Server port.",
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Start dashboard without opening browser automatically.",
    )
    args = parser.parse_args()

    exit_code = launch_streamlit_dashboard(
        host=args.host,
        port=args.port,
        headless=args.headless,
    )
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
