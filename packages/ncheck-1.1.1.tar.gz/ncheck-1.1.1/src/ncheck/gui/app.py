"""Enterprise-style GUI dashboard for ncheck diagnostics."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

import streamlit as st

from ncheck.logic import available_checks, execute_check_safe


def _utc_timestamp() -> str:
    return (
        datetime.now(tz=UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    )


def _init_session_state() -> None:
    st.session_state.setdefault("executions", [])
    st.session_state.setdefault("selected_check", "ping")


def _inject_theme() -> None:
    st.markdown(
        """
        <style>
          .block-container { padding-top: 1.2rem; }
          .stMetricValue { font-size: 1.5rem; }
          .policy-note {
            border: 1px solid #d5dde8;
            border-left: 4px solid #0b5fff;
            border-radius: 8px;
            padding: 12px;
            margin-top: 8px;
            background: #f8fbff;
          }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _render_inputs(check: str) -> dict[str, Any]:
    options: dict[str, Any] = {}

    if check == "ping":
        options["host"] = st.text_input("Host", value="8.8.8.8")
        options["count"] = st.slider("Count", min_value=1, max_value=20, value=4)
        options["timeout"] = st.number_input(
            "Timeout (seconds)",
            min_value=0.1,
            max_value=30.0,
            value=2.0,
            step=0.1,
        )
    elif check == "dns":
        options["host"] = st.text_input("Host", value="example.com")
        options["family"] = st.selectbox(
            "Family", options=["any", "ipv4", "ipv6"], index=0
        )
    elif check == "http":
        options["url"] = st.text_input("URL", value="https://example.com")
        options["method"] = st.selectbox("Method", options=["GET", "HEAD"], index=0)
        options["timeout"] = st.number_input(
            "Timeout (seconds)",
            min_value=0.1,
            max_value=60.0,
            value=5.0,
            step=0.1,
        )
        options["follow_redirects"] = st.checkbox("Follow redirects", value=True)
    elif check == "ports":
        options["host"] = st.text_input("Host", value="scanme.nmap.org")
        options["ports"] = st.text_input("Ports", value="22,80,443")
        options["timeout"] = st.number_input(
            "Timeout per port (seconds)",
            min_value=0.05,
            max_value=10.0,
            value=0.6,
            step=0.05,
        )
        options["workers"] = st.slider("Workers", min_value=1, max_value=512, value=100)
    elif check == "traceroute":
        options["host"] = st.text_input("Host", value="cloudflare.com")
        options["max_hops"] = st.slider("Max hops", min_value=1, max_value=64, value=20)
        options["timeout"] = st.number_input(
            "Hop timeout (seconds)",
            min_value=0.1,
            max_value=10.0,
            value=1.5,
            step=0.1,
        )
    elif check == "tls":
        options["host"] = st.text_input("Host", value="cloudflare.com")
        options["port"] = st.number_input(
            "Port",
            min_value=1,
            max_value=65535,
            value=443,
            step=1,
        )
        options["timeout"] = st.number_input(
            "Timeout (seconds)",
            min_value=0.2,
            max_value=30.0,
            value=5.0,
            step=0.1,
        )
    elif check == "system":
        options["interval"] = st.number_input(
            "Sampling interval (seconds)",
            min_value=0.1,
            max_value=5.0,
            value=0.2,
            step=0.1,
        )
        options["top"] = st.slider("Top processes", min_value=1, max_value=30, value=8)
    elif check == "audit":
        options["host"] = st.text_input("Host", value="example.com")
        options["ports"] = st.text_input("Ports", value="21,22,23,80,443,445,3389")
        options["timeout"] = st.number_input(
            "Timeout per connection (seconds)",
            min_value=0.1,
            max_value=10.0,
            value=1.0,
            step=0.1,
        )
        options["workers"] = st.slider("Workers", min_value=1, max_value=512, value=120)
        options["url"] = st.text_input("Optional URL for headers", value="")
        options["authorized"] = st.checkbox(
            "I am authorized to audit this target", value=False
        )
        st.markdown(
            (
                "<div class='policy-note'>"
                "<strong>Legal notice:</strong> execute audits only on systems you own "
                "or where you have explicit authorization."
                "</div>"
            ),
            unsafe_allow_html=True,
        )
    elif check == "surface":
        options["host"] = st.text_input("Host", value="example.com")
        options["ports"] = st.text_input("Ports", value="21,22,23,80,443,445,3389")
        options["timeout"] = st.number_input(
            "Timeout per phase (seconds)",
            min_value=0.1,
            max_value=10.0,
            value=1.0,
            step=0.1,
        )
        options["workers"] = st.slider("Workers", min_value=1, max_value=512, value=120)
        options["tls_port"] = st.number_input(
            "TLS Port",
            min_value=1,
            max_value=65535,
            value=443,
            step=1,
        )
        options["http_method"] = st.selectbox("HTTP method", options=["HEAD", "GET"], index=0)
        options["url"] = st.text_input("Optional URL", value="")
        options["authorized"] = st.checkbox("I am authorized to test this target", value=False)
        st.markdown(
            (
                "<div class='policy-note'>"
                "<strong>Scope notice:</strong> this workflow performs active network checks. "
                "Use only within approved engagement scope."
                "</div>"
            ),
            unsafe_allow_html=True,
        )
    elif check == "osint_domain":
        options["target"] = st.text_input("Target domain", value="example.com")
        options["timeout"] = st.number_input(
            "Timeout (seconds)",
            min_value=0.2,
            max_value=30.0,
            value=5.0,
            step=0.1,
        )
        options["include_subdomains"] = st.checkbox(
            "Include Certificate Transparency subdomains",
            value=True,
        )
        options["max_subdomains"] = st.slider(
            "Max subdomains",
            min_value=1,
            max_value=2000,
            value=250,
        )
    elif check == "osint_email":
        options["email"] = st.text_input("Email", value="security@example.com")
        options["timeout"] = st.number_input(
            "Timeout (seconds)",
            min_value=0.2,
            max_value=30.0,
            value=5.0,
            step=0.1,
        )
        options["hibp_api_key"] = st.text_input(
            "HIBP API key (optional)",
            value="",
            type="password",
        )
        st.caption("When API key is omitted, breach lookup is skipped.")
    elif check == "personal_security":
        options["top_ports"] = st.slider(
            "Max listening ports",
            min_value=1,
            max_value=200,
            value=30,
        )
        options["risky_ports"] = st.text_input(
            "Risky ports",
            value="21,23,445,3389,5900,6379,27017",
        )

    return options


def _render_summary(history: list[dict[str, Any]]) -> None:
    total_runs = len(history)
    successful_runs = len([entry for entry in history if bool(entry.get("ok"))])
    failed_runs = total_runs - successful_runs
    success_rate = round((successful_runs / total_runs) * 100, 1) if total_runs else 0.0

    metric_col_1, metric_col_2, metric_col_3, metric_col_4 = st.columns(4)
    metric_col_1.metric("Total Runs", str(total_runs))
    metric_col_2.metric("Successful", str(successful_runs))
    metric_col_3.metric("Failed", str(failed_runs))
    metric_col_4.metric("Success Rate", f"{success_rate}%")


def _render_latest_execution(history: list[dict[str, Any]]) -> None:
    st.subheader("Latest Result")
    if not history:
        st.info("Run a diagnostic from the sidebar to populate this panel.")
        return

    latest = history[-1]
    payload = latest.get("payload", {})

    if latest.get("ok"):
        st.success(f"Check `{latest.get('check', 'unknown')}` completed successfully.")
    else:
        st.error(f"Check `{latest.get('check', 'unknown')}` finished with failure.")

    tab_summary, tab_payload, tab_input = st.tabs(["Summary", "Payload JSON", "Input"])
    with tab_summary:
        details = {
            "check": latest.get("check"),
            "ok": latest.get("ok"),
            "duration_ms": latest.get("duration_ms"),
            "started_at": latest.get("started_at"),
            "finished_at": latest.get("finished_at"),
            "status": payload.get("status"),
            "error_message": payload.get("error_message"),
            "risk_level": payload.get("risk_level"),
            "risk_score": payload.get("risk_score"),
        }
        cleaned = {key: value for key, value in details.items() if value is not None}
        st.json(cleaned, expanded=False)

    with tab_payload:
        st.code(json.dumps(payload, indent=2, sort_keys=True), language="json")

    with tab_input:
        st.code(
            json.dumps(latest.get("input", {}), indent=2, sort_keys=True),
            language="json",
        )


def _render_history(history: list[dict[str, Any]]) -> None:
    st.subheader("Execution Timeline")
    if not history:
        st.caption("No executions yet.")
        return

    rows = [
        {
            "finished_at": entry.get("finished_at"),
            "check": entry.get("check"),
            "ok": "success" if entry.get("ok") else "error",
            "duration_ms": round(float(entry.get("duration_ms") or 0.0), 3),
        }
        for entry in history
    ]
    st.dataframe(rows, use_container_width=True, hide_index=True)


def _render_export(history: list[dict[str, Any]]) -> None:
    report = {
        "generated_at": _utc_timestamp(),
        "application": "ncheck-gui",
        "total_runs": len(history),
        "runs": history,
    }
    filename = f"ncheck-report-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    st.download_button(
        "Download consolidated JSON report",
        data=json.dumps(report, indent=2, sort_keys=True),
        file_name=filename,
        mime="application/json",
        use_container_width=True,
    )


def render() -> None:
    st.set_page_config(
        page_title="ncheck Control Center",
        page_icon="N",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    _init_session_state()
    _inject_theme()

    st.title("ncheck Control Center")
    st.caption(
        "Enterprise security platform for diagnostics, authorized pentest workflows and OSINT."
    )

    with st.sidebar:
        st.header("Execution Console")
        selected = st.selectbox(
            "Choose diagnostic workflow",
            options=list(available_checks()),
            index=list(available_checks()).index(
                str(st.session_state["selected_check"])
            ),
            format_func=lambda value: value.replace("_", " ").title(),
        )
        st.session_state["selected_check"] = selected

        with st.form("diagnostic-form", clear_on_submit=False):
            options = _render_inputs(selected)
            submitted = st.form_submit_button(
                "Run Diagnostic", use_container_width=True
            )

        if submitted:
            execution = execute_check_safe(selected, options)
            st.session_state["executions"].append(execution.to_dict())

        if st.button("Clear History", use_container_width=True):
            st.session_state["executions"] = []

    history: list[dict[str, Any]] = list(st.session_state["executions"])
    _render_summary(history)
    _render_latest_execution(history)
    _render_history(history)
    _render_export(history)


if __name__ == "__main__":
    render()
