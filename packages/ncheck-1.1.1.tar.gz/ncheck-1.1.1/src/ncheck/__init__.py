"""ncheck package metadata."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("ncheck")
except PackageNotFoundError:
    __version__ = "1.1.0-dev"

__all__ = ["__version__"]
