from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from rich import box
from rich.table import Table
from rich.text import Text

from ncheck.logic import humanize_key


def _format_value(key: str, value: Any) -> Text:
    if key == "status":
        style = "bold green" if str(value) == "success" else "bold red"
        return Text(str(value), style=style)
    if isinstance(value, float):
        return Text(f"{value:.3f}")
    if isinstance(value, dict):
        return Text(json.dumps(value, indent=2, sort_keys=True))
    if isinstance(value, list):
        if not value:
            return Text("(none)")
        if all(not isinstance(item, (dict, list)) for item in value):
            return Text(", ".join(str(item) for item in value))
        return Text(json.dumps(value, indent=2, sort_keys=True))
    return Text(str(value))


def dict_to_table(data: Mapping[str, Any], title: str = "Data") -> Table:
    table = Table(
        title=title,
        box=box.SIMPLE_HEAVY,
        header_style="bold cyan",
        expand=True,
    )
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Value", style="magenta")

    for key, value in data.items():
        str_key = str(key)
        label = humanize_key(str_key)
        table.add_row(label, _format_value(str_key, value))

    return table
