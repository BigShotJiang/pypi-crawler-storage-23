"""Service layer for defensive security posture audits."""

from __future__ import annotations

import urllib.error
import urllib.request

from ncheck.logic import normalize_host, normalize_url
from ncheck.models import SecurityAuditResult
from ncheck.services.execute_ports import run_port_scan

_RISKY_PORTS = {
    21: "FTP exposed (clear-text credentials risk).",
    23: "Telnet exposed (clear-text credentials risk).",
    445: "SMB exposed (lateral movement risk).",
    3389: "RDP exposed (brute-force risk).",
    5900: "VNC exposed (remote access risk).",
    3306: "MySQL exposed (database exposure risk).",
    5432: "PostgreSQL exposed (database exposure risk).",
    6379: "Redis exposed (unauthorized data access risk).",
    27017: "MongoDB exposed (unauthorized data access risk).",
    9200: "Elasticsearch exposed (data leakage risk).",
}

_REQUIRED_SECURITY_HEADERS = [
    "strict-transport-security",
    "content-security-policy",
    "x-content-type-options",
    "x-frame-options",
    "referrer-policy",
]


def _infer_audit_url(host: str, open_ports: list[int]) -> str | None:
    if 443 in open_ports:
        return f"https://{host}"
    if 80 in open_ports:
        return f"http://{host}"
    return None


def _check_missing_headers(
    url: str, timeout_seconds: float
) -> tuple[list[str], str | None]:
    request = urllib.request.Request(url=url, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            headers = {name.lower(): value for name, value in response.headers.items()}
    except urllib.error.HTTPError as exc:
        headers = (
            {name.lower(): value for name, value in exc.headers.items()}
            if exc.headers
            else {}
        )
    except Exception as exc:
        return [], str(exc)

    missing_headers = [
        header_name
        for header_name in _REQUIRED_SECURITY_HEADERS
        if header_name not in headers
    ]
    return missing_headers, None


def _risk_level(score: int) -> str:
    if score == 0:
        return "low"
    if score <= 3:
        return "medium"
    return "high"


def run_security_audit(
    host: str,
    ports: list[int],
    timeout_seconds: float = 1.0,
    workers: int = 120,
    url: str | None = None,
) -> SecurityAuditResult:
    normalized_host = normalize_host(host)
    port_scan_result = run_port_scan(
        host=normalized_host,
        ports=ports,
        timeout=timeout_seconds,
        workers=workers,
    )

    if not port_scan_result.ok:
        return SecurityAuditResult(
            host=normalized_host,
            status="error",
            scan_ports=sorted(ports),
            error_message=port_scan_result.error_message,
        )

    open_ports = port_scan_result.open_ports or []
    risky_ports = sorted([port for port in open_ports if port in _RISKY_PORTS])
    findings: list[str] = [_RISKY_PORTS[port] for port in risky_ports]
    recommendations: list[str] = []

    if url:
        try:
            audited_url = normalize_url(url)
        except ValueError as exc:
            return SecurityAuditResult(
                host=normalized_host,
                status="error",
                scan_ports=sorted(ports),
                open_ports=open_ports,
                error_message=str(exc),
            )
    else:
        audited_url = _infer_audit_url(normalized_host, open_ports)
    missing_headers: list[str] = []
    if audited_url:
        missing_headers, headers_error = _check_missing_headers(
            audited_url,
            timeout_seconds=max(1.0, timeout_seconds * 3),
        )
        if headers_error:
            findings.append(
                f"Could not validate HTTP security headers: {headers_error}"
            )
        elif missing_headers:
            findings.append(
                "Missing HTTP security headers: " + ", ".join(missing_headers) + "."
            )

    if risky_ports:
        recommendations.append(
            "Restrict public access to risky services using firewall rules."
        )
    if missing_headers:
        recommendations.append(
            "Harden web responses with recommended HTTP security headers."
        )
    if not open_ports:
        recommendations.append(
            "No open ports in scan scope. Keep host segmentation controls active."
        )

    score = (len(risky_ports) * 2) + len(missing_headers)
    return SecurityAuditResult(
        host=normalized_host,
        status="success",
        scan_ports=sorted(ports),
        open_ports=open_ports,
        risky_open_ports=risky_ports or None,
        missing_security_headers=missing_headers or None,
        findings=findings or None,
        recommendations=recommendations or None,
        risk_level=_risk_level(score),
        risk_score=score,
        audited_url=audited_url,
    )
