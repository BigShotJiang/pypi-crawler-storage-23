"""Service layer for local system resource diagnostics."""

from __future__ import annotations

import importlib
from typing import Any

from ncheck.models import SystemUsageResult


def _to_mb(value: int | float) -> float:
    return round(float(value) / (1024 * 1024), 2)


def _collect_top_processes(psutil: Any, top: int) -> list[dict[str, Any]]:
    processes: list[dict[str, Any]] = []
    for process in psutil.process_iter(
        ["pid", "name", "cpu_percent", "memory_percent"]
    ):
        try:
            info = process.info
            processes.append(
                {
                    "pid": int(info.get("pid") or 0),
                    "name": str(info.get("name") or "unknown"),
                    "cpu_percent": round(float(info.get("cpu_percent") or 0.0), 2),
                    "memory_percent": round(
                        float(info.get("memory_percent") or 0.0), 2
                    ),
                }
            )
        except Exception:
            continue

    processes.sort(
        key=lambda proc: (proc["cpu_percent"], proc["memory_percent"]),
        reverse=True,
    )
    return processes[:top]


def run_system_usage(interval_seconds: float = 0.2, top: int = 8) -> SystemUsageResult:
    try:
        psutil = importlib.import_module("psutil")
    except ModuleNotFoundError:
        return SystemUsageResult(
            status="error",
            error_message="Dependency 'psutil' is missing. Install with: pip install -e .",
        )

    try:
        cpu_percent = round(float(psutil.cpu_percent(interval=interval_seconds)), 2)
        memory = psutil.virtual_memory()
        swap = psutil.swap_memory()
        top_processes = _collect_top_processes(psutil, top=max(1, top))
    except Exception as exc:
        return SystemUsageResult(
            status="error",
            error_message=str(exc),
        )

    return SystemUsageResult(
        status="success",
        cpu_percent=cpu_percent,
        cpu_count_logical=int(psutil.cpu_count(logical=True) or 0),
        cpu_count_physical=int(psutil.cpu_count(logical=False) or 0),
        memory_total_mb=_to_mb(memory.total),
        memory_used_mb=_to_mb(memory.used),
        memory_percent=round(float(memory.percent), 2),
        swap_percent=round(float(swap.percent), 2),
        top_processes=top_processes,
    )
