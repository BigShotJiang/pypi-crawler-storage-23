"""Service layer for composed attack-surface assessments."""

from __future__ import annotations

from ncheck.logic import normalize_host, normalize_url
from ncheck.models import AttackSurfaceResult
from ncheck.services.execute_audit import run_security_audit
from ncheck.services.execute_dns import run_dns_lookup
from ncheck.services.execute_http import run_http_check
from ncheck.services.execute_tls import run_tls_inspection


def _risk_level(score: int) -> str:
    if score == 0:
        return "low"
    if score <= 3:
        return "medium"
    return "high"


def _infer_http_url(host: str, open_ports: list[int]) -> str | None:
    if 443 in open_ports:
        return f"https://{host}"
    if 80 in open_ports:
        return f"http://{host}"
    return None


def run_attack_surface_assessment(
    host: str,
    ports: list[int],
    *,
    authorized: bool,
    timeout_seconds: float = 1.0,
    workers: int = 120,
    url: str | None = None,
    tls_port: int = 443,
    http_method: str = "HEAD",
) -> AttackSurfaceResult:
    normalized_host = normalize_host(host)
    if not authorized:
        return AttackSurfaceResult(
            host=normalized_host,
            status="error",
            scan_ports=sorted(ports),
            error_message="Attack surface checks require explicit authorization.",
        )

    if url:
        try:
            normalized_url = normalize_url(url)
        except ValueError as exc:
            return AttackSurfaceResult(
                host=normalized_host,
                status="error",
                scan_ports=sorted(ports),
                error_message=str(exc),
            )
    else:
        normalized_url = None

    audit_result = run_security_audit(
        host=normalized_host,
        ports=ports,
        timeout_seconds=timeout_seconds,
        workers=workers,
        url=normalized_url,
    )
    if audit_result.status != "success":
        return AttackSurfaceResult(
            host=normalized_host,
            status="error",
            scan_ports=sorted(ports),
            error_message=audit_result.error_message,
        )

    dns_result = run_dns_lookup(normalized_host, family="any")
    tls_result = run_tls_inspection(
        normalized_host,
        port=tls_port,
        timeout_seconds=max(2.0, timeout_seconds * 3),
    )

    open_ports = audit_result.open_ports or []
    candidate_url = normalized_url or _infer_http_url(normalized_host, open_ports)
    http_result = (
        run_http_check(
            candidate_url,
            method=http_method,
            timeout=max(2.0, timeout_seconds * 3),
            follow_redirects=True,
        )
        if candidate_url
        else None
    )

    findings = list(audit_result.findings or [])
    recommendations = list(audit_result.recommendations or [])
    risk_score = int(audit_result.risk_score or 0)

    if not dns_result.ok:
        findings.append(f"DNS lookup failed during surface assessment: {dns_result.error_message}")
        recommendations.append("Validate DNS integrity before exposing services externally.")
        risk_score += 1

    if tls_result.status != "success":
        findings.append(f"TLS inspection failed: {tls_result.error_message}")
        recommendations.append("Validate TLS endpoint reachability and certificate chain.")
        risk_score += 1
    elif tls_result.warnings:
        findings.extend(tls_result.warnings)
        recommendations.append("Mitigate TLS warnings (protocol/certificate lifecycle).")
        risk_score += len(tls_result.warnings)

    if http_result and not http_result.ok:
        findings.append(f"HTTP check failed: {http_result.error_message}")
        recommendations.append("Validate public HTTP endpoint behavior and upstream dependencies.")
        risk_score += 1

    if not open_ports:
        recommendations.append(
            "No open ports were found in scope; keep segmentation controls enforced."
        )

    tls_summary = {
        "status": tls_result.status,
        "port": tls_result.port,
        "protocol": tls_result.protocol,
        "days_remaining": tls_result.days_remaining,
        "warnings": tls_result.warnings,
        "error_message": tls_result.error_message,
    }
    http_summary = (
        {
            "status": http_result.status,
            "url": http_result.url,
            "http_status_code": http_result.http_status_code,
            "response_time_ms": http_result.response_time_ms,
            "error_message": http_result.error_message,
        }
        if http_result
        else None
    )

    return AttackSurfaceResult(
        host=normalized_host,
        status="success",
        scan_ports=sorted(ports),
        resolved_addresses=dns_result.addresses if dns_result.ok else None,
        open_ports=open_ports,
        tls_summary=tls_summary,
        http_summary=http_summary,
        findings=findings or None,
        recommendations=recommendations or None,
        risk_level=_risk_level(risk_score),
        risk_score=risk_score,
    )
