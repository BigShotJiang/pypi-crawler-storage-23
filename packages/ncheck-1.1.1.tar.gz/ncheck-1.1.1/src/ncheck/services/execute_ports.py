"""Service layer for TCP port scanning."""

from __future__ import annotations

import socket
from concurrent.futures import ThreadPoolExecutor
from functools import partial

from ncheck.logic import normalize_host
from ncheck.models import PortScanResult


def _check_port(host: str, port: int, timeout: float) -> tuple[int, bool]:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return port, True
    except Exception:
        return port, False


def run_port_scan(
    host: str,
    ports: list[int],
    timeout: float = 0.6,
    workers: int = 100,
) -> PortScanResult:
    normalized_host = normalize_host(host)
    if not ports:
        return PortScanResult(
            host=normalized_host,
            status="error",
            error_message="No ports provided.",
        )

    try:
        socket.getaddrinfo(normalized_host, None)
    except socket.gaierror as exc:
        return PortScanResult(
            host=normalized_host,
            status="error",
            tested_ports=sorted(ports),
            error_message=str(exc),
        )

    max_workers = max(1, min(workers, len(ports), 512))
    scanner = partial(_check_port, normalized_host, timeout=timeout)
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(scanner, ports))

    open_ports = sorted([port for port, is_open in results if is_open])
    closed_ports = sorted([port for port, is_open in results if not is_open])

    return PortScanResult(
        host=normalized_host,
        status="success",
        tested_ports=sorted(ports),
        open_ports=open_ports,
        closed_ports=closed_ports,
        timeout_seconds=round(timeout, 3),
    )
