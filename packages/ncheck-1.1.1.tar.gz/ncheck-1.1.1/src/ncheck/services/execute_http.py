"""Service layer for HTTP checks."""

from __future__ import annotations

import time
import urllib.error
import urllib.request

from ncheck.logic import normalize_url
from ncheck.models import HttpResult


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[override]
        return None


def _build_opener(follow_redirects: bool) -> urllib.request.OpenerDirector:
    if follow_redirects:
        return urllib.request.build_opener()
    return urllib.request.build_opener(_NoRedirectHandler)


def run_http_check(
    url: str,
    method: str = "GET",
    timeout: float = 5.0,
    follow_redirects: bool = True,
) -> HttpResult:
    normalized_url = normalize_url(url)
    normalized_method = method.upper()
    opener = _build_opener(follow_redirects=follow_redirects)
    request = urllib.request.Request(normalized_url, method=normalized_method)

    start = time.perf_counter()
    try:
        with opener.open(request, timeout=timeout) as response:
            elapsed_ms = round((time.perf_counter() - start) * 1000, 3)
            return HttpResult(
                url=normalized_url,
                status="success",
                method=normalized_method,
                http_status_code=int(response.status),
                reason=str(response.reason),
                response_time_ms=elapsed_ms,
                final_url=response.geturl(),
            )
    except urllib.error.HTTPError as exc:
        elapsed_ms = round((time.perf_counter() - start) * 1000, 3)
        return HttpResult(
            url=normalized_url,
            status="error",
            method=normalized_method,
            http_status_code=int(exc.code),
            reason=str(exc.reason),
            response_time_ms=elapsed_ms,
            final_url=exc.geturl(),
            error_message=f"HTTP {exc.code}: {exc.reason}",
        )
    except urllib.error.URLError as exc:
        return HttpResult(
            url=normalized_url,
            status="error",
            method=normalized_method,
            error_message=str(exc.reason),
        )
    except Exception as exc:
        return HttpResult(
            url=normalized_url,
            status="error",
            method=normalized_method,
            error_message=str(exc),
        )
