"""Service layer for traceroute diagnostics."""

from __future__ import annotations

import platform
import re
import subprocess

from ncheck.logic import normalize_host
from ncheck.models import TracerouteResult

_IP_PATTERN = re.compile(r"((?:\d{1,3}\.){3}\d{1,3}|[a-fA-F0-9:]{2,})$")


def _build_traceroute_command(
    host: str, max_hops: int, timeout_seconds: float
) -> list[str]:
    system_name = platform.system().lower()
    if system_name.startswith("win"):
        timeout_ms = max(1, int(timeout_seconds * 1000))
        return [
            "tracert",
            "-d",
            "-h",
            str(max_hops),
            "-w",
            str(timeout_ms),
            host,
        ]

    return [
        "traceroute",
        "-n",
        "-m",
        str(max_hops),
        "-w",
        str(timeout_seconds),
        host,
    ]


def _extract_hops(output: str) -> list[str]:
    hops: list[str] = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if not stripped[0].isdigit():
            continue

        match = _IP_PATTERN.search(stripped)
        if match:
            hops.append(match.group(1))
        else:
            hops.append("*")

    return hops


def run_traceroute(
    host: str, max_hops: int = 20, timeout_seconds: float = 1.5
) -> TracerouteResult:
    normalized_host = normalize_host(host)
    command = _build_traceroute_command(normalized_host, max_hops, timeout_seconds)

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=max(10, int(max_hops * timeout_seconds * 2)),
            check=False,
        )
    except FileNotFoundError:
        return TracerouteResult(
            host=normalized_host,
            status="error",
            max_hops=max_hops,
            timeout_seconds=timeout_seconds,
            error_message=(
                "Traceroute command not found on this system. "
                "Install traceroute/tracert tool and retry."
            ),
        )
    except subprocess.TimeoutExpired:
        return TracerouteResult(
            host=normalized_host,
            status="error",
            max_hops=max_hops,
            timeout_seconds=timeout_seconds,
            error_message="Traceroute timed out before completion.",
        )
    except Exception as exc:
        return TracerouteResult(
            host=normalized_host,
            status="error",
            max_hops=max_hops,
            timeout_seconds=timeout_seconds,
            error_message=str(exc),
        )

    merged_output = "\n".join(part for part in [result.stdout, result.stderr] if part)
    hops = _extract_hops(merged_output)
    if not hops:
        return TracerouteResult(
            host=normalized_host,
            status="error",
            max_hops=max_hops,
            timeout_seconds=timeout_seconds,
            error_message="Unable to parse traceroute hops from command output.",
        )

    return TracerouteResult(
        host=normalized_host,
        status="success",
        max_hops=max_hops,
        timeout_seconds=timeout_seconds,
        hop_count=len(hops),
        hops=hops,
    )
