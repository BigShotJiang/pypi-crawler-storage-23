"""Service layer for ping execution."""

from __future__ import annotations

import importlib
from typing import Any

from ncheck.logic import normalize_host
from ncheck.models import PingResult


def _to_float(value: Any) -> float:
    return round(float(value), 3)


def run_ping(host: str, count: int = 4, timeout: float = 2.0) -> PingResult:
    normalized_host = normalize_host(host)

    try:
        pythonping = importlib.import_module("pythonping")
    except ModuleNotFoundError:
        return PingResult(
            host=normalized_host,
            status="error",
            error_message="Dependency 'pythonping' is missing. Install with: pip install -e .",
        )

    try:
        response = pythonping.ping(
            normalized_host,
            count=count,
            timeout=timeout,
            verbose=False,
        )
    except PermissionError:
        return PingResult(
            host=normalized_host,
            status="error",
            error_message=(
                "Permission denied for ICMP requests. Try running with elevated privileges."
            ),
        )
    except Exception as exc:
        return PingResult(
            host=normalized_host,
            status="error",
            error_message=str(exc),
        )

    return PingResult(
        host=normalized_host,
        status="success",
        avg_latency_ms=_to_float(response.rtt_avg_ms),
        min_latency_ms=_to_float(response.rtt_min_ms),
        max_latency_ms=_to_float(response.rtt_max_ms),
        packet_loss_percent=_to_float(response.packet_loss * 100),
    )


def ping_host(host: str) -> dict[str, Any]:
    """Backward-compatible facade used by older callers."""
    return run_ping(host).to_dict()
