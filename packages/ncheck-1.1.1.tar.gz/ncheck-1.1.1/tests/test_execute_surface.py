import ncheck.services.execute_surface as surface_service
from ncheck.models import DnsResult, HttpResult, SecurityAuditResult, TlsResult


def test_run_attack_surface_assessment_requires_authorization() -> None:
    result = surface_service.run_attack_surface_assessment(
        host="example.com",
        ports=[80, 443],
        authorized=False,
    )

    assert result.status == "error"
    assert "authorization" in (result.error_message or "").lower()


def test_run_attack_surface_assessment_success(monkeypatch) -> None:
    monkeypatch.setattr(
        surface_service,
        "run_security_audit",
        lambda host, ports, timeout_seconds, workers, url: SecurityAuditResult(
            host=host,
            status="success",
            scan_ports=ports,
            open_ports=[443],
            findings=["Missing HTTP security headers: x-frame-options."],
            recommendations=["Add x-frame-options."],
            risk_level="medium",
            risk_score=1,
        ),
    )
    monkeypatch.setattr(
        surface_service,
        "run_dns_lookup",
        lambda host, family: DnsResult(
            host=host,
            status="success",
            query_type=family,
            addresses=["93.184.216.34"],
        ),
    )
    monkeypatch.setattr(
        surface_service,
        "run_tls_inspection",
        lambda host, port, timeout_seconds: TlsResult(
            host=host,
            status="success",
            port=port,
            protocol="TLSv1.3",
            warnings=["Certificate will expire in less than 30 days."],
        ),
    )
    monkeypatch.setattr(
        surface_service,
        "run_http_check",
        lambda url, method, timeout, follow_redirects: HttpResult(
            url=url,
            status="success",
            method=method,
            http_status_code=200,
        ),
    )

    result = surface_service.run_attack_surface_assessment(
        host="example.com",
        ports=[80, 443],
        authorized=True,
    )

    assert result.status == "success"
    assert result.open_ports == [443]
    assert (result.risk_score or 0) >= 2
    assert result.findings
