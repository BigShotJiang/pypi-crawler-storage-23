import urllib.error

import ncheck.services.execute_http as http_service


class _FakeResponse:
    status = 200
    reason = "OK"

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def geturl(self) -> str:
        return "https://example.com/final"


class _FakeSuccessOpener:
    def open(self, request, timeout: float):  # noqa: ANN001
        assert request.method == "GET"
        assert timeout == 4.0
        return _FakeResponse()


def test_run_http_check_success(monkeypatch) -> None:
    monkeypatch.setattr(
        http_service,
        "_build_opener",
        lambda follow_redirects: _FakeSuccessOpener(),
    )

    result = http_service.run_http_check("example.com", method="GET", timeout=4.0)

    assert result.ok is True
    assert result.url == "https://example.com"
    assert result.http_status_code == 200
    assert result.final_url == "https://example.com/final"


class _FakeErrorOpener:
    def open(self, request, timeout: float):  # noqa: ANN001
        raise urllib.error.HTTPError(
            url=request.full_url,
            code=503,
            msg="Service Unavailable",
            hdrs=None,
            fp=None,
        )


def test_run_http_check_http_error(monkeypatch) -> None:
    monkeypatch.setattr(
        http_service,
        "_build_opener",
        lambda follow_redirects: _FakeErrorOpener(),
    )

    result = http_service.run_http_check("https://example.com/maintenance")

    assert result.ok is False
    assert result.http_status_code == 503
    assert "HTTP 503" in (result.error_message or "")
