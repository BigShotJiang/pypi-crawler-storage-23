import ncheck.services.execute_personal_security as personal_service


class _FakeAddr:
    def __init__(self, ip: str, port: int) -> None:
        self.ip = ip
        self.port = port


class _FakeConn:
    def __init__(self, status: str, ip: str, port: int, pid: int) -> None:
        self.status = status
        self.laddr = _FakeAddr(ip, port)
        self.pid = pid


class _FakeProcess:
    def __init__(self, name: str) -> None:
        self._name = name

    def name(self) -> str:
        return self._name


class _FakePsutil:
    @staticmethod
    def net_connections(kind: str):
        assert kind == "inet"
        return [
            _FakeConn("LISTEN", "0.0.0.0", 3389, 1),
            _FakeConn("LISTEN", "127.0.0.1", 8080, 2),
        ]

    @staticmethod
    def Process(pid: int):  # noqa: N802
        return _FakeProcess("proc-1" if pid == 1 else "proc-2")


def test_run_personal_security_check_success(monkeypatch) -> None:
    monkeypatch.setattr(
        personal_service.importlib,
        "import_module",
        lambda name: _FakePsutil,
    )
    monkeypatch.setattr(personal_service, "_detect_firewall_status", lambda system: "off")

    result = personal_service.run_personal_security_check(top_ports=10, risky_ports=[3389])

    assert result.status == "success"
    assert result.firewall_status == "off"
    assert result.risky_listening_ports
    assert result.risky_listening_ports[0]["port"] == 3389
    assert (result.risk_score or 0) >= 3


def test_run_personal_security_check_missing_dependency(monkeypatch) -> None:
    def _raise_module_not_found(name: str):
        raise ModuleNotFoundError("No module named 'psutil'")

    monkeypatch.setattr(
        personal_service.importlib,
        "import_module",
        _raise_module_not_found,
    )

    result = personal_service.run_personal_security_check()

    assert result.status == "error"
    assert "psutil" in (result.error_message or "")
