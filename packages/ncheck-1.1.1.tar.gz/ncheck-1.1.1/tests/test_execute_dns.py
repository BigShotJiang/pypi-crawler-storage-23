import socket

import ncheck.services.execute_dns as dns_service


def test_run_dns_lookup_success(monkeypatch) -> None:
    def _fake_getaddrinfo(host: str, *args, **kwargs):
        assert host == "example.com"
        return [
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 0)),
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 0)),
            (
                socket.AF_INET6,
                socket.SOCK_STREAM,
                6,
                "",
                ("2606:2800:220:1:248:1893:25c8:1946", 0),
            ),
        ]

    monkeypatch.setattr(dns_service.socket, "getaddrinfo", _fake_getaddrinfo)

    result = dns_service.run_dns_lookup(" example.com ", family="any")

    assert result.ok is True
    assert result.host == "example.com"
    assert result.addresses == ["2606:2800:220:1:248:1893:25c8:1946", "93.184.216.34"]


def test_run_dns_lookup_invalid_host(monkeypatch) -> None:
    def _raise_gaierror(*args, **kwargs):
        raise socket.gaierror(-2, "Name or service not known")

    monkeypatch.setattr(dns_service.socket, "getaddrinfo", _raise_gaierror)

    result = dns_service.run_dns_lookup("missing.example")

    assert result.ok is False
    assert "Name or service not known" in (result.error_message or "")
