from typer.testing import CliRunner

import ncheck.cli as cli_module
from ncheck.models import (
    AttackSurfaceResult,
    OsintDomainResult,
    OsintEmailResult,
    PersonalSecurityResult,
)

runner = CliRunner()


def test_surface_requires_authorization() -> None:
    result = runner.invoke(cli_module.app, ["surface", "example.com"])
    assert result.exit_code == 2


def test_osint_domain_json_success(monkeypatch) -> None:
    monkeypatch.setattr(
        cli_module,
        "run_osint_domain",
        lambda target, timeout_seconds, include_subdomains, max_subdomains: OsintDomainResult(
            target=target,
            status="success",
            risk_score=0,
            risk_level="low",
        ),
    )

    result = runner.invoke(cli_module.app, ["osint-domain", "example.com", "--json"])

    assert result.exit_code == 0
    assert '"target": "example.com"' in result.stdout


def test_osint_email_fail_on_findings(monkeypatch) -> None:
    monkeypatch.setattr(
        cli_module,
        "run_osint_email",
        lambda email, timeout_seconds, hibp_api_key: OsintEmailResult(
            email=email,
            status="success",
            domain="example.com",
            breach_count=1,
            risk_level="medium",
            risk_score=2,
        ),
    )

    result = runner.invoke(
        cli_module.app,
        ["osint-email", "security@example.com", "--fail-on-findings", "--json"],
    )

    assert result.exit_code == 1


def test_personal_security_json_success(monkeypatch) -> None:
    monkeypatch.setattr(
        cli_module,
        "run_personal_security_check",
        lambda top_ports, risky_ports: PersonalSecurityResult(
            status="success",
            platform="windows",
            hostname="host-a",
            risk_level="low",
            risk_score=0,
        ),
    )

    result = runner.invoke(cli_module.app, ["personal-security", "--json"])

    assert result.exit_code == 0
    assert '"hostname": "host-a"' in result.stdout


def test_surface_json_success(monkeypatch) -> None:
    monkeypatch.setattr(
        cli_module,
        "run_attack_surface_assessment",
        (
            lambda host, ports, authorized, timeout_seconds, workers, url, tls_port, http_method: (
                AttackSurfaceResult(
                    host=host,
                    status="success",
                    scan_ports=ports,
                    open_ports=[443],
                    risk_level="low",
                    risk_score=0,
                )
            )
        ),
    )

    result = runner.invoke(
        cli_module.app,
        ["surface", "example.com", "--authorized", "--json"],
    )

    assert result.exit_code == 0
    assert '"open_ports": [' in result.stdout
