import ncheck.services.execute_ping as ping_service


class _FakeResponse:
    rtt_avg_ms = 12.345
    rtt_min_ms = 10.111
    rtt_max_ms = 20.999
    packet_loss = 0.25


class _FakePythonPing:
    @staticmethod
    def ping(host: str, count: int, timeout: float, verbose: bool) -> _FakeResponse:
        assert host == "example.com"
        assert count == 3
        assert timeout == 1.5
        assert verbose is False
        return _FakeResponse()


def test_run_ping_success(monkeypatch) -> None:
    monkeypatch.setattr(
        ping_service.importlib,
        "import_module",
        lambda name: _FakePythonPing,
    )

    result = ping_service.run_ping("  example.com  ", count=3, timeout=1.5)

    assert result.ok is True
    assert result.host == "example.com"
    assert result.packet_loss_percent == 25.0
    assert result.error_message is None


def test_run_ping_missing_dependency(monkeypatch) -> None:
    def _raise_module_not_found(_: str):
        raise ModuleNotFoundError("No module named 'pythonping'")

    monkeypatch.setattr(
        ping_service.importlib, "import_module", _raise_module_not_found
    )

    result = ping_service.run_ping("example.com")

    assert result.ok is False
    assert "pythonping" in (result.error_message or "")


def test_run_ping_runtime_exception(monkeypatch) -> None:
    class _BrokenPythonPing:
        @staticmethod
        def ping(host: str, count: int, timeout: float, verbose: bool) -> _FakeResponse:
            raise RuntimeError("network unavailable")

    monkeypatch.setattr(
        ping_service.importlib,
        "import_module",
        lambda name: _BrokenPythonPing,
    )

    result = ping_service.run_ping("example.com")

    assert result.ok is False
    assert result.error_message == "network unavailable"
