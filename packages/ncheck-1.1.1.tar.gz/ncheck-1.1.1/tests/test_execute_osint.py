import ncheck.services.execute_osint as osint_service


def test_run_osint_domain_success(monkeypatch) -> None:
    monkeypatch.setattr(
        osint_service,
        "_resolve_whois_server",
        lambda target, timeout_seconds: "whois.example",
    )
    monkeypatch.setattr(
        osint_service,
        "_query_whois",
        (
            lambda server, query, timeout_seconds: (
                "Registrar: Example Registrar\n"
                "Creation Date: 2020-01-01\n"
                "Registry Expiry Date: 2030-01-01\n"
                "Name Server: ns1.example.com\n"
            )
        ),
    )

    def _fake_doh(name: str, record_type: str, timeout_seconds: float) -> list[str]:
        if record_type == "TXT":
            return ["v=spf1 include:_spf.example.com ~all"]
        if record_type == "DMARC" or name.startswith("_dmarc."):
            return ['"v=DMARC1; p=quarantine; rua=mailto:dmarc@example.com"']
        return ["value"]

    monkeypatch.setattr(osint_service, "_doh_query", _fake_doh)
    monkeypatch.setattr(osint_service, "_url_exists", lambda url, timeout_seconds: True)
    monkeypatch.setattr(
        osint_service,
        "_discover_subdomains",
        lambda target, timeout_seconds, max_subdomains: ["api.example.com"],
    )

    result = osint_service.run_osint_domain("example.com")

    assert result.status == "success"
    assert result.registrar == "Example Registrar"
    assert result.security_txt_present is True
    assert result.risk_score == 0


def test_run_osint_email_invalid_format() -> None:
    result = osint_service.run_osint_email("invalid-email")
    assert result.status == "error"
    assert "Invalid email format" in (result.error_message or "")


def test_run_osint_email_with_breach(monkeypatch) -> None:
    monkeypatch.setattr(
        osint_service,
        "_doh_query",
        lambda name, record_type, timeout_seconds: ["10 mail.example.com"],
    )
    monkeypatch.setattr(
        osint_service,
        "_query_hibp",
        lambda email, api_key, timeout_seconds: [
            {
                "name": "ExampleBreach",
                "breach_date": "2024-01-01",
            }
        ],
    )

    result = osint_service.run_osint_email(
        "security@example.com",
        hibp_api_key="token",
    )

    assert result.status == "success"
    assert result.breach_count == 1
    assert (result.risk_score or 0) > 0
