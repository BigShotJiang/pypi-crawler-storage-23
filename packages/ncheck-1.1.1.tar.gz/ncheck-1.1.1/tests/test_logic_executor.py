import pytest

import ncheck.logic.executor as executor
from ncheck.models import PingResult


def test_execute_check_ping_success(monkeypatch) -> None:
    def _fake_run_ping(host: str, count: int, timeout: float) -> PingResult:
        assert host == "example.com"
        assert count == 3
        assert timeout == 1.5
        return PingResult(
            host=host,
            status="success",
            avg_latency_ms=12.0,
            packet_loss_percent=0.0,
        )

    monkeypatch.setattr(executor, "run_ping", _fake_run_ping)

    payload, ok = executor.execute_check(
        "ping",
        {
            "host": "example.com",
            "count": 3,
            "timeout": 1.5,
        },
    )

    assert ok is True
    assert payload["status"] == "success"


def test_execute_check_rejects_unknown_check() -> None:
    with pytest.raises(ValueError) as excinfo:
        executor.execute_check("invalid-check", {})

    assert "Unknown check" in str(excinfo.value)


def test_execute_check_audit_requires_authorization() -> None:
    with pytest.raises(ValueError) as excinfo:
        executor.execute_check(
            "audit",
            {
                "host": "example.com",
                "ports": "80,443",
                "authorized": False,
            },
        )

    assert "authorized=true" in str(excinfo.value)


def test_execute_check_safe_wraps_errors_in_payload() -> None:
    execution = executor.execute_check_safe("invalid-check", {})

    assert execution.ok is False
    assert execution.payload["status"] == "error"
    assert "Unknown check" in str(execution.payload.get("error_message"))


def test_build_batch_report_summarizes_executions(monkeypatch) -> None:
    class _FakeSystemResult:
        status = "success"
        ok = True

        @staticmethod
        def to_dict() -> dict[str, object]:
            return {"status": "success", "cpu_percent": 10.0}

    def _fake_run_system_usage(interval_seconds: float, top: int) -> _FakeSystemResult:
        assert interval_seconds == 0.2
        assert top == 1
        return _FakeSystemResult()

    monkeypatch.setattr(executor, "run_system_usage", _fake_run_system_usage)

    success_execution = executor.execute_check_safe(
        "system", {"interval": 0.2, "top": 1}
    )
    error_execution = executor.execute_check_safe("invalid-check", {})

    report = executor.build_batch_report([success_execution, error_execution])

    assert report["status"] == "error"
    assert report["summary"]["total_checks"] == 2
    assert report["summary"]["failed_checks"] == 1


def test_execute_check_osint_domain(monkeypatch) -> None:
    class _FakeOsintDomainResult:
        status = "success"
        ok = True

        @staticmethod
        def to_dict() -> dict[str, object]:
            return {"status": "success", "target": "example.com", "risk_score": 0}

    def _fake_run_osint_domain(
        target: str,
        timeout_seconds: float,
        include_subdomains: bool,
        max_subdomains: int,
    ) -> _FakeOsintDomainResult:
        assert target == "example.com"
        assert timeout_seconds == 5.0
        assert include_subdomains is True
        assert max_subdomains == 10
        return _FakeOsintDomainResult()

    monkeypatch.setattr(executor, "run_osint_domain", _fake_run_osint_domain)

    payload, ok = executor.execute_check(
        "osint_domain",
        {"target": "example.com", "max_subdomains": 10},
    )

    assert ok is True
    assert payload["target"] == "example.com"


def test_execute_check_personal_security(monkeypatch) -> None:
    class _FakePersonalSecurityResult:
        status = "success"
        ok = True

        @staticmethod
        def to_dict() -> dict[str, object]:
            return {"status": "success", "risk_score": 0}

    def _fake_run_personal_security_check(
        top_ports: int,
        risky_ports: list[int],
    ) -> _FakePersonalSecurityResult:
        assert top_ports == 5
        assert risky_ports == [22, 443]
        return _FakePersonalSecurityResult()

    monkeypatch.setattr(
        executor,
        "run_personal_security_check",
        _fake_run_personal_security_check,
    )

    payload, ok = executor.execute_check(
        "personal_security",
        {"top_ports": 5, "risky_ports": "22,443"},
    )

    assert ok is True
    assert payload["status"] == "success"
