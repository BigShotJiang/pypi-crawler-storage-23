import socket

import ncheck.services.execute_ports as ports_service


def test_run_port_scan_success(monkeypatch) -> None:
    monkeypatch.setattr(
        ports_service.socket,
        "getaddrinfo",
        lambda host, port: [
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 0))
        ],
    )

    def _fake_check_port(host: str, port: int, timeout: float) -> tuple[int, bool]:
        assert host == "localhost"
        assert timeout == 0.3
        return port, port in {22, 443}

    monkeypatch.setattr(ports_service, "_check_port", _fake_check_port)

    result = ports_service.run_port_scan(
        " localhost ", ports=[22, 80, 443], timeout=0.3, workers=3
    )

    assert result.ok is True
    assert result.open_ports == [22, 443]
    assert result.closed_ports == [80]


def test_run_port_scan_resolution_error(monkeypatch) -> None:
    def _raise_gaierror(host: str, port):  # noqa: ANN001
        raise socket.gaierror(-2, "Name or service not known")

    monkeypatch.setattr(ports_service.socket, "getaddrinfo", _raise_gaierror)

    result = ports_service.run_port_scan("nope.invalid", ports=[80])

    assert result.ok is False
    assert "Name or service not known" in (result.error_message or "")
