import subprocess

import ncheck.services.execute_traceroute as traceroute_service


def test_run_traceroute_success(monkeypatch) -> None:
    def _fake_run(*args, **kwargs):
        return subprocess.CompletedProcess(
            args=["tracert"],
            returncode=0,
            stdout=(
                "  1     1 ms     1 ms     1 ms  192.168.0.1\n"
                "  2    10 ms    11 ms    12 ms  93.184.216.34\n"
            ),
            stderr="",
        )

    monkeypatch.setattr(traceroute_service.subprocess, "run", _fake_run)
    monkeypatch.setattr(traceroute_service.platform, "system", lambda: "Windows")

    result = traceroute_service.run_traceroute(
        "example.com", max_hops=5, timeout_seconds=1.0
    )

    assert result.ok is True
    assert result.hop_count == 2
    assert result.hops == ["192.168.0.1", "93.184.216.34"]


def test_run_traceroute_missing_command(monkeypatch) -> None:
    def _raise_not_found(*args, **kwargs):
        raise FileNotFoundError("command not found")

    monkeypatch.setattr(traceroute_service.subprocess, "run", _raise_not_found)

    result = traceroute_service.run_traceroute("example.com")

    assert result.ok is False
    assert "not found" in (result.error_message or "").lower()
