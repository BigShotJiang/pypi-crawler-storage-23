"""Cost Guard — Budget management, anomaly detection, and cost optimization."""
