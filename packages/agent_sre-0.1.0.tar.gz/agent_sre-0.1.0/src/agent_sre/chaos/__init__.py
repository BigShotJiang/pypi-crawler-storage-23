"""Chaos Engine — Fault injection and resilience testing for agents."""
