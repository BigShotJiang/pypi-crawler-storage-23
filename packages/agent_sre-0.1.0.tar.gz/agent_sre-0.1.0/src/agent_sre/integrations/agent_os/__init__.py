"""Agent OS integration — policy signals and shadow mode."""
