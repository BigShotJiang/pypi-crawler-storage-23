"""Agent Mesh integration — telemetry and trust signals."""
