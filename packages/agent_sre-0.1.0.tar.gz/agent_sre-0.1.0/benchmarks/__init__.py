"""Agent SRE performance benchmarks."""
