#!/bin/bash 
wget https://download.pytorch.org/tutorial/hymenoptera_data.zip
unzip hymenoptera_data.zip
rm hymenoptera_data.zip