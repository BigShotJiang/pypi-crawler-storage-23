#!/bin/bash

wget https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-320.tgz
tar xzf imagenette2-320.tgz
rm imagenette2-320.tgz