.. currentmodule:: pytorch_accelerated.finetuning

Fine-tuning
***********

ModelFreezer
=======================
.. autoclass:: ModelFreezer
    :members: