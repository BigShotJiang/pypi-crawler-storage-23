Installation
**************

`pytorch\-accelerated` can be installed from pip using the following command::

    pip install pytorch-accelerated


To make the package as slim as possible, the packages required to run the examples are not included by default. To include these packages, you can use the following command::

    pip install pytorch-accelerated[examples]
