.. currentmodule:: pytorch_accelerated.run_config

Run Config
***********

RunConfig
=======================
.. autoclass:: TrainerRunConfig
    :members: