"""Install OpenCode commands and workflows.

Copies bundled resources to ~/.config/opencode/ for global access.

Requirements: GLOB-03 (OpenCode command files), GLOB-04 (bundled workflows)
"""

from __future__ import annotations

from importlib.resources import files
from pathlib import Path
from typing import Optional

import typer


def install_commands(
    opencode_dir: Optional[Path] = typer.Option(
        None,
        "--opencode-dir",
        "-o",
        help="Custom OpenCode config directory (default: ~/.config/opencode/)",
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Overwrite existing command files"
    ),
) -> None:
    """Install OpenCode command files to ~/.config/opencode/commands/.

    Installs:
    - Commands to ~/.config/opencode/commands/gsd-rlm/
    - Workflows to ~/.config/opencode/gsd-rlm/workflows/
    """
    # Determine target directory
    if opencode_dir is None:
        opencode_dir = Path.home() / ".config" / "opencode"

    if not opencode_dir.exists():
        typer.secho(
            f"Error: OpenCode directory not found: {opencode_dir}", fg=typer.colors.RED
        )
        typer.echo("Please install OpenCode first: https://opencode.ai")
        raise typer.Exit(1)

    commands_dir = opencode_dir / "commands" / "gsd-rlm"
    workflows_dir = opencode_dir / "gsd-rlm" / "workflows"

    commands_dir.mkdir(parents=True, exist_ok=True)
    workflows_dir.mkdir(parents=True, exist_ok=True)

    # Install commands
    installed_commands = _install_resources("commands", commands_dir, force)
    installed_workflows = _install_resources("workflows", workflows_dir, force)

    typer.secho("\n[OK] Installation complete!", fg=typer.colors.GREEN, bold=True)
    typer.echo(f"\nCommands installed to: {commands_dir}")
    typer.echo(f"Workflows installed to: {workflows_dir}")

    if installed_commands:
        typer.echo("\nAvailable commands:")
        for cmd in installed_commands:
            name = cmd[:-3] if cmd.endswith(".md") else cmd
            typer.echo(f"  /{name}")
    else:
        typer.echo("\nNo new commands installed (use --force to overwrite)")


def _install_resources(resource_type: str, target_dir: Path, force: bool) -> list[str]:
    """Install bundled resources of a given type.

    Args:
        resource_type: 'commands' or 'workflows'
        target_dir: Destination directory
        force: Overwrite existing files

    Returns:
        List of installed file names
    """
    installed = []

    try:
        bundled = files("gsd_rlm.bundled").joinpath(resource_type)

        for resource in bundled.iterdir():
            if resource.name.endswith(".md") and resource.name != ".gitkeep":
                target = target_dir / resource.name

                if target.exists() and not force:
                    typer.echo(f"  Skipping {resource.name} (exists, use --force)")
                    continue

                content = resource.read_text(encoding="utf-8")
                target.write_text(content, encoding="utf-8")
                installed.append(resource.name)

    except Exception as e:
        typer.secho(
            f"Warning: Could not install {resource_type}: {e}", fg=typer.colors.YELLOW
        )

    return installed
