"""
Workflow module for spec-driven execution.

Provides components for ROADMAP→PLAN→EXECUTE→VERIFY workflow
with must-have validation (EXEC-10, EXEC-11, EXEC-12).

Components:
- SpecLoader: Load ROADMAP.md and REQUIREMENTS.md
- PhaseTracker: Track phase progression
- verify_phase_completion: Goal-backward verification
"""

from gsd_rlm.workflow.spec_loader import (
    PhaseSpec,
    SpecLoader,
    load_roadmap,
    load_requirements,
)
from gsd_rlm.workflow.phase_tracker import (
    PhaseStatus,
    PhaseProgress,
    PhaseTracker,
)
from gsd_rlm.workflow.verification import (
    MustHaves,
    VerificationResult,
    verify_phase_completion,
    load_must_haves_from_plan,
    verify_artifact_exports,
    verify_key_link_pattern,
)

__all__ = [
    # Spec loader
    "PhaseSpec",
    "SpecLoader",
    "load_roadmap",
    "load_requirements",
    # Phase tracker
    "PhaseStatus",
    "PhaseProgress",
    "PhaseTracker",
    # Verification
    "MustHaves",
    "VerificationResult",
    "verify_phase_completion",
    "load_must_haves_from_plan",
    "verify_artifact_exports",
    "verify_key_link_pattern",
]
