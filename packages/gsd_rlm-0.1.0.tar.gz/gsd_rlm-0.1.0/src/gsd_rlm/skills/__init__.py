"""
Skill discovery and loading system for GSD-RLM.

This module provides tools for discovering and loading agent capabilities
as reusable skills defined in SKILL.md files.

Requirements: INT-01, INT-02, INT-03

Usage:
    >>> from gsd_rlm.skills import SkillRegistry, discover_skills
    >>> registry = SkillRegistry(Path("skills"))
    >>> registry.load()
    >>> skill = registry.get("gsd-rlm-plan-phase")
"""

from gsd_rlm.skills.base import SkillDefinition, SkillFrontmatter
from gsd_rlm.skills.discovery import SkillRegistry, discover_skills

__all__ = [
    "SkillFrontmatter",
    "SkillDefinition",
    "discover_skills",
    "SkillRegistry",
]
