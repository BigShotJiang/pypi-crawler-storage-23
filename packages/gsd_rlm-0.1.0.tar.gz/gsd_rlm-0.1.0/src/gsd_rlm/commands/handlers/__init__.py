"""
Command handlers for GSD-RLM commands.

This module provides handlers for /gsd-rlm-* commands that invoke
orchestrator entry points for project management, planning, and execution.

Requirements: INT-04 (command handlers), INT-05 (orchestrator integration)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from gsd_rlm.commands.router import CommandRouter

logger = logging.getLogger(__name__)


def register_default_handlers(router: "CommandRouter") -> None:
    """Register all default command handlers with a router.

    Args:
        router: CommandRouter instance to register handlers with
    """
    from gsd_rlm.commands.handlers.new_project import new_project_command
    from gsd_rlm.commands.handlers.plan_phase import plan_phase_command
    from gsd_rlm.commands.handlers.execute_phase import execute_phase_command

    router.register("new-project", new_project_command)
    router.register("plan-phase", plan_phase_command)
    router.register("execute-phase", execute_phase_command)

    logger.info(
        "Registered default command handlers: new-project, plan-phase, execute-phase"
    )


__all__ = [
    "register_default_handlers",
]
