"""
Command routing system for GSD-RLM.

This module provides the command router and result types for mapping
/gsd-rlm-* commands to orchestrator entry points.

Requirements: INT-04 (command routing), INT-05 (handler mapping), INT-08 (provider routing)
"""

from gsd_rlm.commands.router import (
    CommandConfig,
    CommandResult,
    CommandRouter,
    route_command,
    create_router_with_defaults,
)

__all__ = [
    "CommandConfig",
    "CommandResult",
    "CommandRouter",
    "route_command",
    "create_router_with_defaults",
]
