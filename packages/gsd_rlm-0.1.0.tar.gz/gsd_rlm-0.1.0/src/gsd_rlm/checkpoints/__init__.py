"""
Checkpoint system for human-in-the-loop interaction.

This module provides checkpoint types and management for pausing
execution to wait for user input at critical decision points.
"""

from gsd_rlm.checkpoints.types import Checkpoint, CheckpointType
from gsd_rlm.checkpoints.manager import CheckpointManager

__all__ = [
    "Checkpoint",
    "CheckpointType",
    "CheckpointManager",
]
