"""
Memory Bridge Module for GSD-RLM.

Provides multi-level persistent context storage integrated with
the .planning directory structure (MEM-09).

Level hierarchy:
- L0_SESSION: Session-scoped facts (temporary, in .planning/sessions/)
- L1_PHASE: Phase-scoped facts (persists with phase in .planning/phases/*/)
- L2_PROJECT: Project-scoped facts (persists with project)
- L3_WORKSPACE: Workspace-scoped facts (user-level, ~/.gsd-rlm/)

Usage:
    from gsd_rlm.memory.bridge import BridgeFact, BridgeLevel, MemoryBridge

    # Create a fact
    fact = BridgeFact.create(
        level=BridgeLevel.L1_PHASE,
        scope_id="03-memory-systems-infiniretri",
        key="preferred_python_version",
        value="3.12",
        source="user_input"
    )

    # Store via MemoryBridge
    bridge = MemoryBridge(project_root=Path("."))
    bridge.store_fact(fact)
"""

from gsd_rlm.memory.bridge.facts import BridgeFact, BridgeLevel
from gsd_rlm.memory.bridge.store import MemoryBridge
from gsd_rlm.memory.bridge.router import MemoryStoreType, MemoryRoute, MemoryRouter

__all__ = [
    "BridgeFact",
    "BridgeLevel",
    "MemoryBridge",
    "MemoryStoreType",
    "MemoryRoute",
    "MemoryRouter",
]
