"""
Memory Integration Module for GSD-RLM.

Provides unified context assembly from multiple memory stores,
combining MemoryRouter with actual data retrieval, plus git hooks
for automatic fact extraction and session resumption.

Key components:
- ContextAssembler: Combines data from multiple stores into unified context
- GitFactExtractor: Extracts facts from git commits to Memory Bridge
- install_git_hooks: Installs post-commit hook for automatic extraction
- SessionResumption: Restores full context for session resumption
- ResumptionContext: Dataclass containing all restored context
"""

from gsd_rlm.memory.integration.context import ContextAssembler
from gsd_rlm.memory.integration.git_hooks import (
    GitFactExtractor,
    GitCommitInfo,
    install_git_hooks,
    run_extraction,
    uninstall_git_hooks,
)
from gsd_rlm.memory.integration.session_bridge import (
    SessionResumption,
    ResumptionContext,
)

__all__ = [
    "ContextAssembler",
    "GitFactExtractor",
    "GitCommitInfo",
    "install_git_hooks",
    "run_extraction",
    "uninstall_git_hooks",
    "SessionResumption",
    "ResumptionContext",
]
