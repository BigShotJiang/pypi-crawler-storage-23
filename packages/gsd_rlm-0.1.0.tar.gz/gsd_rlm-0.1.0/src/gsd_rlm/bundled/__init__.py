"""Bundled resources for GSD-RLM.

Contains OpenCode command templates and workflow files that get installed
to ~/.config/opencode/ when users run gsd-rlm install-commands.
"""

from __future__ import annotations
