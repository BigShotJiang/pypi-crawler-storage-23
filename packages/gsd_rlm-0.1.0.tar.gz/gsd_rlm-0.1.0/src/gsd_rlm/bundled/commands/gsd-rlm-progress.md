---
name: gsd-rlm-progress
description: Show current project progress and metrics
argument-hint: ""
allowed-tools:
  - read
  - bash
---

<objective>
Display project progress including phase completion, plan status, and velocity metrics.

Reads STATE.md and phase directories to build progress report.
</objective>

<process>
1. Read STATE.md for current position
2. Scan phases/ directory for completed plans
3. Calculate velocity metrics
4. Display formatted progress report
</process>
