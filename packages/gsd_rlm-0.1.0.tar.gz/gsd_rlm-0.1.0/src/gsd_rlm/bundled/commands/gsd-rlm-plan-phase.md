---
name: gsd-rlm-plan-phase
description: Plan a phase by creating executable PLAN.md files
argument-hint: "PHASE_NUMBER"
allowed-tools:
  - read
  - bash
  - write
  - grep
  - glob
---

<objective>
Create execution plans for a phase based on ROADMAP requirements.

Reads ROADMAP.md, CONTEXT.md, RESEARCH.md and generates PLAN.md files with tasks.
</objective>

<execution_context>
@~/.config/opencode/gsd-rlm/workflows/plan-phase.md
</execution_context>

<process>
1. Load ROADMAP.md and REQUIREMENTS.md
2. Load phase CONTEXT.md and RESEARCH.md if available
3. Analyze requirements and dependencies
4. Generate PLAN.md files with tasks, dependencies, waves
5. Update ROADMAP.md with plan list
</process>
