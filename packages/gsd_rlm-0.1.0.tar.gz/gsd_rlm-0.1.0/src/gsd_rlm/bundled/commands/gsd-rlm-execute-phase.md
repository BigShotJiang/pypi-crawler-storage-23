---
name: gsd-rlm-execute-phase
description: Execute plans in a phase with verification
argument-hint: "PHASE_NUMBER [--plan PLAN_ID]"
allowed-tools:
  - read
  - bash
  - write
  - edit
  - grep
  - glob
---

<objective>
Execute PLAN.md files for a phase, running tasks in wave order.

Each task is executed, verified, and committed before moving to the next.
</objective>

<execution_context>
@~/.config/opencode/gsd-rlm/workflows/execute-phase.md
</execution_context>

<process>
1. Load phase PLAN.md files
2. Sort by wave dependency order
3. For each plan:
   a. Execute tasks sequentially
   b. Run verification after each task
   c. Create SUMMARY.md when complete
4. Update STATE.md with progress
</process>
