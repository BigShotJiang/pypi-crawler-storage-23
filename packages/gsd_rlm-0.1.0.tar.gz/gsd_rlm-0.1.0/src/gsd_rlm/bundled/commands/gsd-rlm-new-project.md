---
name: gsd-rlm-new-project
description: Initialize a new GSD-RLM project with planning structure
argument-hint: "[--name NAME]"
allowed-tools:
  - read
  - bash
  - write
  - question
---

<objective>
Initialize a new GSD-RLM project in the current directory.

Creates .planning/ structure with PROJECT.md, ROADMAP.md, STATE.md, and phases/ directory.
</objective>

<execution_context>
@~/.config/opencode/gsd-rlm/workflows/new-project.md
</execution_context>

<process>
1. Check if .planning/ already exists
2. Ask user for project name (default: current directory name)
3. Ask user for project description
4. Create .planning/ directory structure
5. Generate PROJECT.md, ROADMAP.md, STATE.md from templates
6. Show next steps to user
</process>
