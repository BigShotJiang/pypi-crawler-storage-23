# Workflow: Phase Planning

## Overview

This workflow creates executable PLAN.md files for a phase.

## Prerequisites

- .planning/ROADMAP.md exists
- Phase context gathered (CONTEXT.md, RESEARCH.md optional)

## Steps

### Step 1: Load Context

Read ROADMAP.md for phase requirements and goals.

### Step 2: Analyze Dependencies

Map task dependencies and group into waves.

### Step 3: Generate Plans

Create PLAN.md files with:
- Frontmatter (wave, depends_on, files_modified, autonomous)
- Tasks with action, verify, done elements
- Verification criteria
- Success criteria

### Step 4: Update ROADMAP

Add plan list to phase entry in ROADMAP.md.
