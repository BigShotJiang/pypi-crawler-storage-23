# Workflow: New Project Initialization

## Overview

This workflow creates a new GSD-RLM project structure in the current directory.

## Steps

### Step 1: Gather Information

Ask the user:
- Project name (default: current directory name)
- Project description (brief overview)
- Initial phase ideas (optional)

### Step 2: Create Directory Structure

```
.planning/
├── PROJECT.md      # Project overview and decisions
├── ROADMAP.md      # Phase and plan tracking
├── STATE.md        # Current position and metrics
├── REQUIREMENTS.md # Requirements list (optional)
└── phases/         # Phase plan directories
```

### Step 3: Generate Files

Use templates with user-provided information.

### Step 4: Confirm and Next Steps

Show created files and suggest next steps.
