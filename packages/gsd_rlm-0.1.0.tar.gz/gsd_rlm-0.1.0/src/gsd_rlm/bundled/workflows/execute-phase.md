# Workflow: Phase Execution

## Overview

This workflow executes PLAN.md files in dependency order.

## Steps

### Step 1: Load Plans

Read all PLAN.md files for the phase.

### Step 2: Sort by Wave

Order plans by wave number, respecting dependencies.

### Step 3: Execute Plans

For each plan:
1. Execute tasks sequentially
2. Run <verify> command after each task
3. Create SUMMARY.md when all tasks complete
4. Commit changes

### Step 4: Update State

Update STATE.md with progress and metrics.
