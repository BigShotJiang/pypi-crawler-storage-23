Memory systems for GSD-RLM.
