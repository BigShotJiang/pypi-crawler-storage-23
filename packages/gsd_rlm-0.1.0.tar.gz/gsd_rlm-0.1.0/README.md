# GSD-RLM

Get Shit Done with Reinforcement Learning for Multi-Agent Systems.

A YAML-based agent definition system with automatic validation, per-agent tool
whitelisting, and multi-provider LLM configuration. Built on RLM-Toolkit.
