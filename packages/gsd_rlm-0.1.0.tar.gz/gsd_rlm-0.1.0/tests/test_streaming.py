"""
Tests for real-time output streaming system.

Tests cover StreamEvent creation, OutputStream functionality,
and stream_task convenience method.
"""

import anyio
import pytest
from datetime import datetime

from gsd_rlm.execution.streaming import (
    StreamEvent,
    StreamEventType,
    OutputStream,
)


class TestStreamEvent:
    """Tests for StreamEvent dataclass."""

    def test_stream_event_creation(self):
        """StreamEvent created with correct fields."""
        event = StreamEvent(
            task_id="task-1",
            event_type=StreamEventType.REASONING,
            content="Thinking about the problem...",
        )

        assert event.task_id == "task-1"
        assert event.event_type == StreamEventType.REASONING
        assert event.content == "Thinking about the problem..."
        assert event.timestamp is not None
        assert event.metadata == {}

    def test_stream_event_timestamp_auto(self):
        """Timestamp auto-generated if not provided."""
        before = datetime.utcnow().isoformat()
        event = StreamEvent(
            task_id="task-1",
            event_type=StreamEventType.OUTPUT,
            content="result",
        )
        after = datetime.utcnow().isoformat()

        # Timestamp should be between before and after
        assert before <= event.timestamp <= after

    def test_stream_event_with_metadata(self):
        """StreamEvent can include metadata."""
        event = StreamEvent(
            task_id="task-1",
            event_type=StreamEventType.PROGRESS,
            content="Processing...",
            metadata={"percent": 50, "step": "validation"},
        )

        assert event.metadata["percent"] == 50
        assert event.metadata["step"] == "validation"

    def test_stream_event_all_types(self):
        """All StreamEventType values work."""
        types = [
            StreamEventType.REASONING,
            StreamEventType.OUTPUT,
            StreamEventType.ERROR,
            StreamEventType.COMPLETE,
            StreamEventType.PROGRESS,
        ]

        for event_type in types:
            event = StreamEvent(
                task_id="task-1",
                event_type=event_type,
                content="test",
            )
            assert event.event_type == event_type


class TestOutputStream:
    """Tests for OutputStream class."""

    @pytest.mark.anyio
    async def test_output_stream_create(self):
        """Stream creation returns receive stream."""
        streamer = OutputStream()
        receive = await streamer.create_stream("task-1")

        assert receive is not None
        assert streamer.has_stream("task-1")
        assert "task-1" in streamer.active_streams()

        await streamer.close_stream("task-1")

    @pytest.mark.anyio
    async def test_output_stream_create_duplicate_error(self):
        """Creating duplicate stream raises error."""
        streamer = OutputStream()
        await streamer.create_stream("task-1")

        with pytest.raises(ValueError, match="already exists"):
            await streamer.create_stream("task-1")

        await streamer.close_stream("task-1")

    @pytest.mark.anyio
    async def test_output_stream_emit(self):
        """Emit sends event to receive stream."""
        streamer = OutputStream()
        receive = await streamer.create_stream("task-1")

        await streamer.emit("task-1", StreamEventType.REASONING, "thinking...")

        event = await receive.receive()
        assert event.event_type == StreamEventType.REASONING
        assert event.content == "thinking..."
        assert event.task_id == "task-1"

        await streamer.close_stream("task-1")

    @pytest.mark.anyio
    async def test_output_stream_close(self):
        """Close removes stream from active streams."""
        streamer = OutputStream()
        await streamer.create_stream("task-1")

        assert streamer.has_stream("task-1")

        await streamer.close_stream("task-1")

        assert not streamer.has_stream("task-1")
        assert "task-1" not in streamer.active_streams()

    @pytest.mark.anyio
    async def test_output_stream_emit_no_stream(self):
        """Emit to non-existent stream does not error."""
        streamer = OutputStream()
        # Should not raise, just log and return
        await streamer.emit("non-existent", StreamEventType.OUTPUT, "test")

    @pytest.mark.anyio
    async def test_output_stream_close_no_stream(self):
        """Close non-existent stream does not error."""
        streamer = OutputStream()
        # Should not raise
        await streamer.close_stream("non-existent")

    @pytest.mark.anyio
    async def test_output_stream_multiple_events(self):
        """Multiple events received in order."""
        streamer = OutputStream()
        receive = await streamer.create_stream("task-1")

        await streamer.emit("task-1", StreamEventType.REASONING, "step 1")
        await streamer.emit("task-1", StreamEventType.REASONING, "step 2")
        await streamer.emit("task-1", StreamEventType.OUTPUT, "result")

        event1 = await receive.receive()
        event2 = await receive.receive()
        event3 = await receive.receive()

        assert event1.content == "step 1"
        assert event2.content == "step 2"
        assert event3.content == "result"

        await streamer.close_stream("task-1")

    @pytest.mark.anyio
    async def test_output_stream_event_types(self):
        """All event types work correctly."""
        streamer = OutputStream()
        receive = await streamer.create_stream("task-1")

        await streamer.emit("task-1", StreamEventType.REASONING, "thinking")
        await streamer.emit("task-1", StreamEventType.OUTPUT, "output")
        await streamer.emit("task-1", StreamEventType.ERROR, "error")
        await streamer.emit("task-1", StreamEventType.COMPLETE, "")
        await streamer.emit("task-1", StreamEventType.PROGRESS, "50%")

        for expected_type in [
            StreamEventType.REASONING,
            StreamEventType.OUTPUT,
            StreamEventType.ERROR,
            StreamEventType.COMPLETE,
            StreamEventType.PROGRESS,
        ]:
            event = await receive.receive()
            assert event.event_type == expected_type

        await streamer.close_stream("task-1")

    @pytest.mark.anyio
    async def test_output_stream_buffer_size(self):
        """Buffer size is respected."""
        streamer = OutputStream(buffer_size=5)
        receive = await streamer.create_stream("task-1")

        # Fill buffer
        for i in range(5):
            await streamer.emit("task-1", StreamEventType.OUTPUT, f"msg-{i}")

        # Read back
        for i in range(5):
            event = await receive.receive()
            assert event.content == f"msg-{i}"

        await streamer.close_stream("task-1")

    @pytest.mark.anyio
    async def test_output_stream_with_metadata(self):
        """Emit with metadata preserves it in event."""
        streamer = OutputStream()
        receive = await streamer.create_stream("task-1")

        await streamer.emit(
            "task-1",
            StreamEventType.PROGRESS,
            "Processing...",
            metadata={"percent": 75, "items_processed": 150},
        )

        event = await receive.receive()
        assert event.metadata["percent"] == 75
        assert event.metadata["items_processed"] == 150

        await streamer.close_stream("task-1")


class TestStreamTask:
    """Tests for stream_task convenience method."""

    @pytest.mark.anyio
    async def test_stream_task_yields_events(self):
        """stream_task yields events from executor."""
        streamer = OutputStream()
        events_received = []

        async def my_executor(task_id: str):
            await streamer.emit(task_id, StreamEventType.REASONING, "thinking")
            await streamer.emit(task_id, StreamEventType.OUTPUT, "result")

        async for event in streamer.stream_task("task-1", my_executor):
            events_received.append(event)

        assert len(events_received) >= 2
        assert any(e.event_type == StreamEventType.REASONING for e in events_received)
        assert any(e.event_type == StreamEventType.OUTPUT for e in events_received)

    @pytest.mark.anyio
    async def test_stream_task_complete_event(self):
        """Complete event emitted at end."""
        streamer = OutputStream()
        complete_received = False

        async def my_executor(task_id: str):
            await streamer.emit(task_id, StreamEventType.OUTPUT, "done")

        async for event in streamer.stream_task("task-1", my_executor):
            if event.event_type == StreamEventType.COMPLETE:
                complete_received = True

        assert complete_received

    @pytest.mark.anyio
    async def test_stream_task_error_handling(self):
        """Error event emitted on exception."""
        streamer = OutputStream()
        events_received = []

        async def failing_executor(task_id: str):
            await streamer.emit(task_id, StreamEventType.REASONING, "starting")
            raise ValueError("Something went wrong")

        async for event in streamer.stream_task("task-1", failing_executor):
            events_received.append(event)

        # Should have error event and complete event
        error_events = [
            e for e in events_received if e.event_type == StreamEventType.ERROR
        ]
        assert len(error_events) == 1
        assert "Something went wrong" in error_events[0].content

        # Should still have complete event
        complete_events = [
            e for e in events_received if e.event_type == StreamEventType.COMPLETE
        ]
        assert len(complete_events) >= 1

    @pytest.mark.anyio
    async def test_stream_task_stream_closed_after_completion(self):
        """Stream is closed after stream_task completes."""
        streamer = OutputStream()

        async def my_executor(task_id: str):
            pass

        async for _ in streamer.stream_task("task-1", my_executor):
            pass

        # Stream should be closed
        assert not streamer.has_stream("task-1")

    @pytest.mark.anyio
    async def test_stream_task_multiple_events_in_order(self):
        """Events yielded in order they were emitted."""
        streamer = OutputStream()
        contents = []

        async def my_executor(task_id: str):
            for i in range(5):
                await streamer.emit(task_id, StreamEventType.OUTPUT, f"step-{i}")

        async for event in streamer.stream_task("task-1", my_executor):
            if event.event_type == StreamEventType.OUTPUT:
                contents.append(event.content)

        assert contents == ["step-0", "step-1", "step-2", "step-3", "step-4"]


class TestMultipleStreams:
    """Tests for multiple concurrent streams."""

    @pytest.mark.anyio
    async def test_multiple_streams_independent(self):
        """Multiple streams are independent."""
        streamer = OutputStream()

        receive1 = await streamer.create_stream("task-1")
        receive2 = await streamer.create_stream("task-2")

        await streamer.emit("task-1", StreamEventType.OUTPUT, "result-1")
        await streamer.emit("task-2", StreamEventType.OUTPUT, "result-2")

        event1 = await receive1.receive()
        event2 = await receive2.receive()

        assert event1.content == "result-1"
        assert event2.content == "result-2"

        await streamer.close_stream("task-1")
        await streamer.close_stream("task-2")

    @pytest.mark.anyio
    async def test_active_streams_tracking(self):
        """Active streams are tracked correctly."""
        streamer = OutputStream()

        assert streamer.active_streams() == []

        await streamer.create_stream("task-1")
        assert streamer.active_streams() == ["task-1"]

        await streamer.create_stream("task-2")
        assert set(streamer.active_streams()) == {"task-1", "task-2"}

        await streamer.close_stream("task-1")
        assert streamer.active_streams() == ["task-2"]

        await streamer.close_stream("task-2")
        assert streamer.active_streams() == []
