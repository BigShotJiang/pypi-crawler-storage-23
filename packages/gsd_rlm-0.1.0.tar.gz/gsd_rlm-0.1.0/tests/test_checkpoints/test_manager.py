"""
Tests for CheckpointManager.

Tests pause/resume flow, persistence, checkpoint factories, and timeout handling.
"""

import pytest
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock

from gsd_rlm.session.memory import FileSessionMemory
from gsd_rlm.checkpoints.types import Checkpoint, CheckpointType
from gsd_rlm.checkpoints.manager import CheckpointManager


@pytest.fixture
def temp_sessions_dir():
    """Create a temporary directory for session files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def session_memory(temp_sessions_dir):
    """Create FileSessionMemory with temp directory."""
    return FileSessionMemory(temp_sessions_dir)


@pytest.fixture
def manager(session_memory):
    """Create CheckpointManager with session memory."""
    return CheckpointManager(session_memory)


class TestCheckpointManagerInit:
    """Tests for CheckpointManager initialization."""

    def test_init_with_session_memory(self, session_memory):
        """Can initialize with session memory."""
        manager = CheckpointManager(session_memory)
        assert manager.session_memory is session_memory
        assert manager.on_checkpoint is None
        assert manager.pending_checkpoints == {}

    def test_init_with_callback(self, session_memory):
        """Can initialize with callback."""

        def callback(cp):
            return "response"

        manager = CheckpointManager(session_memory, on_checkpoint=callback)
        assert manager.on_checkpoint is callback


class TestCheckpointFactories:
    """Tests for checkpoint factory methods."""

    def test_create_human_verify(self, manager):
        """create_human_verify creates valid checkpoint."""
        checkpoint = manager.create_human_verify(
            what_built="Login form",
            how_to_verify="Test login",
            session_id="sess-001",
        )

        assert checkpoint.type == CheckpointType.HUMAN_VERIFY
        assert checkpoint.gate == "blocking"
        assert checkpoint.what_built == "Login form"
        assert checkpoint.how_to_verify == "Test login"
        assert checkpoint.session_id == "sess-001"
        assert checkpoint.checkpoint_id.startswith("cp-")

    def test_create_human_verify_with_options(self, manager):
        """create_human_verify accepts optional parameters."""
        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
            gate="non-blocking",
            resume_signal="Approve?",
            timeout_seconds=300,
        )

        assert checkpoint.gate == "non-blocking"
        assert checkpoint.resume_signal == "Approve?"
        assert checkpoint.timeout_seconds == 300

    def test_create_decision(self, manager):
        """create_decision creates valid checkpoint."""
        options = [
            {"name": "PostgreSQL", "pros": "ACID", "cons": "Schema"},
            {"name": "MongoDB", "pros": "Flexible", "cons": "No ACID"},
        ]
        checkpoint = manager.create_decision(
            decision="Choose database",
            context="Need ACID compliance",
            options=options,
            session_id="sess-001",
        )

        assert checkpoint.type == CheckpointType.DECISION
        assert checkpoint.decision == "Choose database"
        assert checkpoint.context == "Need ACID compliance"
        assert checkpoint.options == options
        assert checkpoint.session_id == "sess-001"

    def test_create_decision_with_options(self, manager):
        """create_decision accepts optional parameters."""
        checkpoint = manager.create_decision(
            decision="Pick one",
            context="Important",
            options=[{"name": "A"}],
            session_id="sess-001",
            gate="non-blocking",
            timeout_seconds=60,
        )

        assert checkpoint.gate == "non-blocking"
        assert checkpoint.timeout_seconds == 60

    def test_create_human_action(self, manager):
        """create_human_action creates valid checkpoint."""
        checkpoint = manager.create_human_action(
            action="Click verification link",
            instructions="Check your email",
            verification="Run 'auth status'",
            session_id="sess-001",
        )

        assert checkpoint.type == CheckpointType.HUMAN_ACTION
        assert checkpoint.action == "Click verification link"
        assert checkpoint.instructions == "Check your email"
        assert checkpoint.verification == "Run 'auth status'"
        assert checkpoint.session_id == "sess-001"

    def test_create_human_action_with_options(self, manager):
        """create_human_action accepts optional parameters."""
        checkpoint = manager.create_human_action(
            action="Do something",
            instructions="How to do it",
            verification="How to check",
            session_id="sess-001",
            gate="non-blocking",
            resume_signal="Type done",
            timeout_seconds=120,
        )

        assert checkpoint.gate == "non-blocking"
        assert checkpoint.resume_signal == "Type done"
        assert checkpoint.timeout_seconds == 120

    def test_unique_checkpoint_ids(self, manager):
        """Each factory call generates unique checkpoint IDs."""
        cp1 = manager.create_human_verify("A", "Test A", "sess-001")
        cp2 = manager.create_human_verify("B", "Test B", "sess-001")
        cp3 = manager.create_decision("C", "Context", [{"name": "X"}], "sess-001")

        assert cp1.checkpoint_id != cp2.checkpoint_id
        assert cp2.checkpoint_id != cp3.checkpoint_id


class TestPauseResumeFlow:
    """Tests for pause/resume flow."""

    @pytest.mark.anyio
    async def test_pause_returns_approved_without_callback(self, manager):
        """pause() returns 'approved' when no callback is set."""
        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )

        response = await manager.pause(checkpoint)
        assert response == "approved"

    @pytest.mark.anyio
    async def test_pause_calls_callback(self, session_memory):
        """pause() calls on_checkpoint callback."""

        def callback(cp):
            return "user_response"

        manager = CheckpointManager(session_memory, on_checkpoint=callback)
        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )

        response = await manager.pause(checkpoint)
        assert response == "user_response"

    @pytest.mark.anyio
    async def test_pause_calls_async_callback(self, session_memory):
        """pause() handles async callbacks."""

        async def callback(cp):
            return "async_response"

        manager = CheckpointManager(session_memory, on_checkpoint=callback)
        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )

        response = await manager.pause(checkpoint)
        assert response == "async_response"

    @pytest.mark.anyio
    async def test_pause_clears_pending_after_response(self, manager):
        """pause() clears pending checkpoint after response."""
        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )

        await manager.pause(checkpoint)

        # Pending should be cleared
        assert "sess-001" not in manager.pending_checkpoints


class TestPersistence:
    """Tests for checkpoint persistence."""

    @pytest.mark.anyio
    async def test_persist_during_pause(self, manager, session_memory):
        """Checkpoint is persisted to session during pause."""
        # Create session first
        session = session_memory.create("sess-001", "test-agent")

        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )

        # Pause stores the checkpoint
        await manager.pause(checkpoint)

        # After pause completes, checkpoint should be cleared from session
        session = session_memory.load("sess-001")
        assert "pending_checkpoint" not in session.metadata

    @pytest.mark.anyio
    async def test_resume_pending_from_memory(self, manager):
        """resume_pending() returns checkpoint from memory dict."""
        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )

        # Manually store in pending
        manager.pending_checkpoints["sess-001"] = checkpoint

        resumed = manager.resume_pending("sess-001")
        assert resumed is not None
        assert resumed.checkpoint_id == checkpoint.checkpoint_id

    @pytest.mark.anyio
    async def test_resume_pending_from_session(self, manager, session_memory):
        """resume_pending() restores checkpoint from session metadata."""
        # Create session with pending checkpoint in metadata
        session = session_memory.create("sess-001", "test-agent")
        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )
        session.metadata["pending_checkpoint"] = checkpoint.to_dict()
        session_memory.save(session)

        # Resume should find it
        resumed = manager.resume_pending("sess-001")
        assert resumed is not None
        assert resumed.checkpoint_id == checkpoint.checkpoint_id
        assert "sess-001" in manager.pending_checkpoints  # Should be cached

    def test_resume_pending_returns_none_when_not_found(self, manager):
        """resume_pending() returns None when no pending checkpoint."""
        resumed = manager.resume_pending("nonexistent-session")
        assert resumed is None


class TestTimeoutHandling:
    """Tests for timeout handling."""

    @pytest.mark.anyio
    async def test_pause_with_timeout_returns_response(self, manager):
        """pause_with_timeout() returns response if received before timeout."""
        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )

        response = await manager.pause_with_timeout(checkpoint, 60.0)
        assert response == "approved"

    @pytest.mark.anyio
    async def test_pause_with_timeout_returns_timeout(self, session_memory):
        """pause_with_timeout() returns 'timeout' if exceeded."""

        async def slow_callback(cp):
            import anyio

            await anyio.sleep(10)  # Longer than timeout
            return "too late"

        manager = CheckpointManager(session_memory, on_checkpoint=slow_callback)
        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )

        response = await manager.pause_with_timeout(checkpoint, 0.1)
        assert response == "timeout"

    @pytest.mark.anyio
    async def test_pause_with_timeout_clears_pending(self, session_memory):
        """pause_with_timeout() clears pending checkpoint on timeout."""

        async def slow_callback(cp):
            import anyio

            await anyio.sleep(10)
            return "too late"

        manager = CheckpointManager(session_memory, on_checkpoint=slow_callback)
        session = session_memory.create("sess-001", "test-agent")

        checkpoint = manager.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )

        await manager.pause_with_timeout(checkpoint, 0.1)

        # Pending should be cleared
        assert "sess-001" not in manager.pending_checkpoints


class TestIntegration:
    """Integration tests for full checkpoint workflow."""

    @pytest.mark.anyio
    async def test_full_workflow_human_verify(self, manager, session_memory):
        """Full workflow for HUMAN_VERIFY checkpoint."""
        # Create session
        session_memory.create("sess-001", "test-agent")

        # Create checkpoint
        checkpoint = manager.create_human_verify(
            what_built="Login form with validation",
            how_to_verify="Visit /login and test credentials",
            session_id="sess-001",
        )

        # Pause and get response
        response = await manager.pause(checkpoint)

        # Verify response
        assert response == "approved"

        # Verify no pending checkpoints
        assert manager.resume_pending("sess-001") is None

    @pytest.mark.anyio
    async def test_full_workflow_decision(self, manager, session_memory):
        """Full workflow for DECISION checkpoint."""
        # Create session
        session_memory.create("sess-002", "test-agent")

        # Create checkpoint
        options = [
            {"name": "PostgreSQL", "pros": "ACID", "cons": "Schema"},
            {"name": "MongoDB", "pros": "Flexible", "cons": "No ACID"},
        ]
        checkpoint = manager.create_decision(
            decision="Choose database",
            context="Need ACID compliance for financial data",
            options=options,
            session_id="sess-002",
        )

        # Pause and get response
        response = await manager.pause(checkpoint)

        assert response == "approved"

    @pytest.mark.anyio
    async def test_full_workflow_human_action(self, manager, session_memory):
        """Full workflow for HUMAN_ACTION checkpoint."""
        # Create session
        session_memory.create("sess-003", "test-agent")

        # Create checkpoint
        checkpoint = manager.create_human_action(
            action="Click verification link in email",
            instructions="Check your inbox for the verification email",
            verification="Run 'auth status' to confirm verification",
            session_id="sess-003",
        )

        # Pause and get response
        response = await manager.pause(checkpoint)

        assert response == "approved"

    @pytest.mark.anyio
    async def test_persistence_across_sessions(self, session_memory):
        """Checkpoint persists across CheckpointManager instances."""
        # Create session
        session_memory.create("sess-001", "test-agent")

        # First manager stores checkpoint
        manager1 = CheckpointManager(session_memory)
        checkpoint = manager1.create_human_verify(
            what_built="Feature",
            how_to_verify="Test it",
            session_id="sess-001",
        )
        manager1.pending_checkpoints["sess-001"] = checkpoint

        # Manually persist (simulating crash before pause completes)
        session = session_memory.load("sess-001")
        session.metadata["pending_checkpoint"] = checkpoint.to_dict()
        session_memory.save(session)

        # New manager instance should find it
        manager2 = CheckpointManager(session_memory)
        resumed = manager2.resume_pending("sess-001")

        assert resumed is not None
        assert resumed.checkpoint_id == checkpoint.checkpoint_id
        assert resumed.what_built == "Feature"
