"""
Tests for optimization scheduling (SEC-08).

Covers:
- OptimizationRun record
- OptimizationMetricsTracker history and stats
- OptimizationScheduler threshold and interval triggers
- Background loop management
"""

import asyncio
import json
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock, patch

import pytest

from gsd_rlm.optimization.scheduler import (
    OptimizationRun,
    OptimizationMetricsTracker,
    OptimizationScheduler,
    HAS_DSPY,
)
from gsd_rlm.optimization.optimizer import OptimizationResult


# Fixtures
@pytest.fixture
def temp_metrics_path(tmp_path: Path) -> str:
    """Create a temporary path for metrics file."""
    return str(tmp_path / "optimization_metrics.json")


@pytest.fixture
def sample_run() -> OptimizationRun:
    """Create a sample successful optimization run."""
    return OptimizationRun(
        run_id="opt_001",
        timestamp="2024-01-01T00:00:00Z",
        traces_used=50,
        score_before=0.6,
        score_after=0.85,
        improvement=0.25,
        success=True,
        duration_ms=5000,
    )


@pytest.fixture
def failed_run() -> OptimizationRun:
    """Create a sample failed optimization run."""
    return OptimizationRun(
        run_id="opt_002",
        timestamp="2024-01-02T00:00:00Z",
        traces_used=30,
        score_before=0.0,
        score_after=0.0,
        improvement=0.0,
        success=False,
        duration_ms=1000,
        error="Optimization failed due to insufficient data",
    )


@pytest.fixture
def mock_trace_collector():
    """Mock TraceCollector with configurable trace count."""
    collector = MagicMock()
    collector.get_successful_traces.return_value = [MagicMock() for _ in range(60)]
    collector.get_training_dataset.return_value = [MagicMock() for _ in range(60)]
    return collector


@pytest.fixture
def mock_trace_collector_low():
    """Mock TraceCollector with low trace count (below threshold)."""
    collector = MagicMock()
    collector.get_successful_traces.return_value = [MagicMock() for _ in range(10)]
    collector.get_training_dataset.return_value = [MagicMock() for _ in range(10)]
    return collector


@pytest.fixture
def mock_optimizer():
    """Mock AgentOptimizer."""
    optimizer = MagicMock()
    optimizer.optimize.return_value = OptimizationResult(
        success=True,
        score_before=0.6,
        score_after=0.85,
        improvement=0.25,
        traces_used=60,
    )
    return optimizer


@pytest.fixture
def mock_optimizer_error():
    """Mock AgentOptimizer that raises an error."""
    optimizer = MagicMock()
    optimizer.optimize.side_effect = RuntimeError("Optimization failed")
    return optimizer


class TestOptimizationRun:
    """Tests for OptimizationRun dataclass."""

    def test_run_creation(self, sample_run):
        """Test creating an optimization run."""
        assert sample_run.run_id == "opt_001"
        assert sample_run.traces_used == 50
        assert sample_run.score_before == 0.6
        assert sample_run.score_after == 0.85
        assert sample_run.improvement == 0.25
        assert sample_run.success is True
        assert sample_run.duration_ms == 5000
        assert sample_run.error is None

    def test_run_serialization(self, sample_run):
        """Test to_dict and from_dict round-trip."""
        data = sample_run.to_dict()

        assert data["run_id"] == "opt_001"
        assert data["traces_used"] == 50
        assert data["success"] is True

        # Round-trip
        restored = OptimizationRun.from_dict(data)
        assert restored.run_id == sample_run.run_id
        assert restored.traces_used == sample_run.traces_used
        assert restored.score_before == sample_run.score_before
        assert restored.success == sample_run.success

    def test_run_with_error(self):
        """Test creating a run with error information."""
        run = OptimizationRun(
            run_id="opt_err",
            timestamp="2024-01-01T00:00:00Z",
            traces_used=0,
            score_before=0.0,
            score_after=0.0,
            improvement=0.0,
            success=False,
            duration_ms=100,
            error="Test error",
        )

        assert run.success is False
        assert run.error == "Test error"

        data = run.to_dict()
        assert data["error"] == "Test error"


class TestOptimizationMetricsTracker:
    """Tests for OptimizationMetricsTracker."""

    def test_tracker_init(self):
        """Test tracker initialization without path."""
        tracker = OptimizationMetricsTracker()
        assert tracker.runs == []
        assert tracker.metrics_path is None

    def test_tracker_init_with_path(self, temp_metrics_path):
        """Test tracker initialization with path."""
        tracker = OptimizationMetricsTracker(temp_metrics_path)
        assert tracker.runs == []
        assert tracker.metrics_path == temp_metrics_path

    def test_record_run(self, temp_metrics_path, sample_run):
        """Test recording an optimization run."""
        tracker = OptimizationMetricsTracker(temp_metrics_path)
        tracker.record(sample_run)

        assert len(tracker.runs) == 1
        assert tracker.runs[0].run_id == "opt_001"

    def test_get_latest(self, temp_metrics_path, sample_run, failed_run):
        """Test getting the latest run."""
        tracker = OptimizationMetricsTracker(temp_metrics_path)
        tracker.record(sample_run)
        tracker.record(failed_run)

        latest = tracker.get_latest()
        assert latest is not None
        assert latest.run_id == "opt_002"

    def test_get_latest_empty(self):
        """Test getting latest when no runs recorded."""
        tracker = OptimizationMetricsTracker()
        assert tracker.get_latest() is None

    def test_get_average_improvement(self, temp_metrics_path):
        """Test calculating average improvement."""
        tracker = OptimizationMetricsTracker(temp_metrics_path)

        # Add successful runs with different improvements
        for i, improvement in enumerate([0.1, 0.2, 0.3]):
            run = OptimizationRun(
                run_id=f"opt_{i}",
                timestamp=f"2024-01-0{i}T00:00:00Z",
                traces_used=10,
                score_before=0.5,
                score_after=0.5 + improvement,
                improvement=improvement,
                success=True,
            )
            tracker.record(run)

        # Add a failed run (should be excluded)
        failed = OptimizationRun(
            run_id="opt_fail",
            timestamp="2024-01-10T00:00:00Z",
            traces_used=10,
            score_before=0.5,
            score_after=0.5,
            improvement=0.0,
            success=False,
        )
        tracker.record(failed)

        # Average of 0.1, 0.2, 0.3 = 0.2
        avg = tracker.get_average_improvement()
        assert avg == pytest.approx(0.2)

    def test_get_average_improvement_empty(self):
        """Test average improvement with no runs."""
        tracker = OptimizationMetricsTracker()
        assert tracker.get_average_improvement() == 0.0

    def test_get_success_rate(self, temp_metrics_path):
        """Test calculating success rate."""
        tracker = OptimizationMetricsTracker(temp_metrics_path)

        # 3 successful, 2 failed
        for i in range(5):
            run = OptimizationRun(
                run_id=f"opt_{i}",
                timestamp=f"2024-01-0{i}T00:00:00Z",
                traces_used=10,
                score_before=0.5,
                score_after=0.7,
                improvement=0.2,
                success=(i < 3),  # First 3 succeed
            )
            tracker.record(run)

        rate = tracker.get_success_rate()
        assert rate == pytest.approx(0.6)  # 3/5

    def test_get_success_rate_empty(self):
        """Test success rate with no runs."""
        tracker = OptimizationMetricsTracker()
        assert tracker.get_success_rate() == 0.0

    def test_get_total_runs(self, temp_metrics_path, sample_run):
        """Test getting total run count."""
        tracker = OptimizationMetricsTracker(temp_metrics_path)

        assert tracker.get_total_runs() == 0
        tracker.record(sample_run)
        assert tracker.get_total_runs() == 1

        for i in range(5):
            tracker.record(
                OptimizationRun(
                    run_id=f"opt_{i}",
                    timestamp=f"2024-01-0{i}T00:00:00Z",
                    traces_used=10,
                    score_before=0.5,
                    score_after=0.7,
                    improvement=0.2,
                    success=True,
                )
            )

        assert tracker.get_total_runs() == 6

    def test_persistence(self, temp_metrics_path, sample_run, failed_run):
        """Test metrics persistence to file."""
        # Create and populate tracker
        tracker1 = OptimizationMetricsTracker(temp_metrics_path)
        tracker1.record(sample_run)
        tracker1.record(failed_run)

        # Create new tracker from same path
        tracker2 = OptimizationMetricsTracker(temp_metrics_path)

        assert len(tracker2.runs) == 2
        assert tracker2.runs[0].run_id == "opt_001"
        assert tracker2.runs[1].run_id == "opt_002"

    def test_load_corrupted_file(self, temp_metrics_path):
        """Test loading from corrupted JSON file."""
        # Write invalid JSON
        with open(temp_metrics_path, "w") as f:
            f.write("not valid json {{{")

        # Should not raise, just start empty
        tracker = OptimizationMetricsTracker(temp_metrics_path)
        assert tracker.runs == []

    def test_load_missing_file(self, temp_metrics_path):
        """Test loading when file doesn't exist."""
        missing_path = str(Path(temp_metrics_path).parent / "nonexistent.json")
        tracker = OptimizationMetricsTracker(missing_path)
        assert tracker.runs == []


class TestOptimizationScheduler:
    """Tests for OptimizationScheduler."""

    @pytest.mark.asyncio
    async def test_scheduler_init(self, mock_trace_collector, mock_optimizer):
        """Test scheduler initialization."""
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector,
            optimizer=mock_optimizer,
        )

        assert scheduler.trace_collector is mock_trace_collector
        assert scheduler.optimizer is mock_optimizer
        assert (
            scheduler.interval_seconds == OptimizationScheduler.DEFAULT_INTERVAL_SECONDS
        )
        assert (
            scheduler.trace_threshold == OptimizationScheduler.DEFAULT_TRACE_THRESHOLD
        )
        assert scheduler.is_running is False
        assert scheduler.last_run is None

    @pytest.mark.asyncio
    async def test_scheduler_init_custom_params(
        self, mock_trace_collector, mock_optimizer, temp_metrics_path
    ):
        """Test scheduler with custom parameters."""
        tracker = OptimizationMetricsTracker(temp_metrics_path)
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector,
            optimizer=mock_optimizer,
            metrics_tracker=tracker,
            interval_seconds=1800,
            trace_threshold=100,
        )

        assert scheduler.interval_seconds == 1800
        assert scheduler.trace_threshold == 100
        assert scheduler.metrics is tracker

    @pytest.mark.asyncio
    async def test_should_optimize_below_threshold(
        self, mock_trace_collector_low, mock_optimizer
    ):
        """Test that optimization is not triggered below threshold."""
        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", True):
            scheduler = OptimizationScheduler(
                trace_collector=mock_trace_collector_low,
                optimizer=mock_optimizer,
                trace_threshold=50,
            )

            # Should return False since only 10 traces available
            assert scheduler._should_optimize() is False

    @pytest.mark.asyncio
    async def test_should_optimize_above_threshold(
        self, mock_trace_collector, mock_optimizer
    ):
        """Test that optimization is triggered above threshold."""
        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", True):
            scheduler = OptimizationScheduler(
                trace_collector=mock_trace_collector,
                optimizer=mock_optimizer,
                trace_threshold=50,
            )

            # Should return True since 60 traces available
            assert scheduler._should_optimize() is True

    @pytest.mark.asyncio
    async def test_run_once_below_threshold_returns_none(
        self, mock_trace_collector_low, mock_optimizer
    ):
        """Test run_once returns None when below threshold."""
        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", True):
            scheduler = OptimizationScheduler(
                trace_collector=mock_trace_collector_low,
                optimizer=mock_optimizer,
                trace_threshold=50,
            )

            result = await scheduler.run_once()
            assert result is None
            # Optimizer should not be called
            mock_optimizer.optimize.assert_not_called()

    @pytest.mark.asyncio
    async def test_run_once_above_threshold_runs_optimization(
        self, mock_trace_collector, mock_optimizer
    ):
        """Test run_once runs optimization when above threshold."""
        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", True):
            scheduler = OptimizationScheduler(
                trace_collector=mock_trace_collector,
                optimizer=mock_optimizer,
                trace_threshold=50,
            )

            result = await scheduler.run_once()

            assert result is not None
            assert result.success is True
            assert result.improvement == 0.25
            mock_optimizer.optimize.assert_called_once()

    @pytest.mark.asyncio
    async def test_force_run_bypasses_threshold(
        self, mock_trace_collector_low, mock_optimizer
    ):
        """Test force_run runs optimization even below threshold."""
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector_low,
            optimizer=mock_optimizer,
            trace_threshold=50,
        )

        result = await scheduler.force_run()

        assert result is not None
        assert result.success is True
        mock_optimizer.optimize.assert_called_once()

    @pytest.mark.asyncio
    async def test_start_stop_loop(self, mock_trace_collector, mock_optimizer):
        """Test starting and stopping the background loop."""
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector,
            optimizer=mock_optimizer,
            interval_seconds=0.1,  # Short interval for testing
        )

        assert scheduler.is_running is False

        await scheduler.start()
        assert scheduler.is_running is True

        # Let it run briefly
        await asyncio.sleep(0.05)

        await scheduler.stop()
        assert scheduler.is_running is False

    @pytest.mark.asyncio
    async def test_records_metrics_on_run(self, mock_trace_collector, mock_optimizer):
        """Test that metrics are recorded on optimization run."""
        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", True):
            tracker = OptimizationMetricsTracker()
            scheduler = OptimizationScheduler(
                trace_collector=mock_trace_collector,
                optimizer=mock_optimizer,
                metrics_tracker=tracker,
                trace_threshold=50,
            )

            result = await scheduler.run_once()

            assert result is not None
            assert tracker.get_total_runs() == 1
            assert tracker.get_latest().run_id == result.run_id

    @pytest.mark.asyncio
    async def test_updates_last_run_timestamp(
        self, mock_trace_collector, mock_optimizer
    ):
        """Test that last_run is updated after optimization."""
        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", True):
            scheduler = OptimizationScheduler(
                trace_collector=mock_trace_collector,
                optimizer=mock_optimizer,
                trace_threshold=50,
            )

            assert scheduler.last_run is None

            result = await scheduler.run_once()

            assert scheduler.last_run is not None
            assert scheduler.last_run == result.timestamp


class TestOptimizationSchedulerEdgeCases:
    """Tests for edge cases and error handling."""

    @pytest.mark.asyncio
    async def test_handles_optimizer_error(
        self, mock_trace_collector, mock_optimizer_error
    ):
        """Test handling of optimizer errors."""
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector,
            optimizer=mock_optimizer_error,
            trace_threshold=50,
        )

        result = await scheduler.force_run()

        assert result is not None
        assert result.success is False
        assert "Optimization failed" in result.error

    @pytest.mark.asyncio
    async def test_handles_insufficient_traces(self, mock_optimizer):
        """Test handling when training dataset is too small."""
        collector = MagicMock()
        # Below MIN_TRAINSET_SIZE
        collector.get_successful_traces.return_value = [MagicMock() for _ in range(5)]
        collector.get_training_dataset.return_value = [MagicMock() for _ in range(5)]

        scheduler = OptimizationScheduler(
            trace_collector=collector,
            optimizer=mock_optimizer,
            trace_threshold=3,  # Low threshold to pass _should_optimize
        )

        # force_run should still handle insufficient data
        result = await scheduler.force_run()

        assert result is not None
        assert result.success is False
        assert "Insufficient training data" in result.error

    @pytest.mark.asyncio
    async def test_double_start_is_safe(self, mock_trace_collector, mock_optimizer):
        """Test that calling start twice is safe."""
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector,
            optimizer=mock_optimizer,
        )

        await scheduler.start()
        assert scheduler.is_running is True

        # Second start should be no-op
        await scheduler.start()
        assert scheduler.is_running is True

        await scheduler.stop()

    @pytest.mark.asyncio
    async def test_stop_when_not_running_is_safe(
        self, mock_trace_collector, mock_optimizer
    ):
        """Test that stopping when not running is safe."""
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector,
            optimizer=mock_optimizer,
        )

        assert scheduler.is_running is False

        # Should not raise
        await scheduler.stop()
        assert scheduler.is_running is False

    @pytest.mark.asyncio
    async def test_respects_dspy_availability(
        self, mock_trace_collector, mock_optimizer
    ):
        """Test that scheduler respects DSPy availability."""
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector,
            optimizer=mock_optimizer,
            trace_threshold=50,
        )

        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", False):
            should = scheduler._should_optimize()
            assert should is False

    @pytest.mark.asyncio
    async def test_loop_continues_on_error(
        self, mock_trace_collector, mock_optimizer_error
    ):
        """Test that the optimization loop continues after errors."""
        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", True):
            scheduler = OptimizationScheduler(
                trace_collector=mock_trace_collector,
                optimizer=mock_optimizer_error,
                interval_seconds=0.05,
                trace_threshold=50,
            )

            await scheduler.start()

            # Let it try a few iterations
            await asyncio.sleep(0.2)

            await scheduler.stop()

            # Should have recorded failed runs
            assert scheduler.metrics.get_total_runs() >= 1

    @pytest.mark.asyncio
    async def test_loop_only_optimizes_when_threshold_met(
        self, mock_trace_collector_low, mock_optimizer
    ):
        """Test that loop only runs optimization when threshold is met."""
        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", True):
            scheduler = OptimizationScheduler(
                trace_collector=mock_trace_collector_low,
                optimizer=mock_optimizer,
                interval_seconds=0.05,
                trace_threshold=50,
            )

            await scheduler.start()

            # Let it run a few check cycles
            await asyncio.sleep(0.2)

            await scheduler.stop()

            # Optimizer should not have been called (threshold not met)
            mock_optimizer.optimize.assert_not_called()

    @pytest.mark.asyncio
    async def test_metrics_property(
        self, mock_trace_collector, mock_optimizer, temp_metrics_path
    ):
        """Test the metrics property accessor."""
        tracker = OptimizationMetricsTracker(temp_metrics_path)
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector,
            optimizer=mock_optimizer,
            metrics_tracker=tracker,
        )

        assert scheduler.metrics is tracker


class TestOptimizationSchedulerIntegration:
    """Integration-style tests for scheduler."""

    @pytest.mark.asyncio
    async def test_full_optimization_cycle(
        self, mock_trace_collector, mock_optimizer, temp_metrics_path
    ):
        """Test a full optimization cycle with metrics persistence."""
        with patch("gsd_rlm.optimization.scheduler.HAS_DSPY", True):
            tracker = OptimizationMetricsTracker(temp_metrics_path)
            scheduler = OptimizationScheduler(
                trace_collector=mock_trace_collector,
                optimizer=mock_optimizer,
                metrics_tracker=tracker,
                trace_threshold=50,
            )

            # Run optimization
            result = await scheduler.run_once()

            assert result is not None
            assert result.success is True
            assert scheduler.last_run == result.timestamp

            # Check metrics were recorded
            assert tracker.get_total_runs() == 1
            latest = tracker.get_latest()
            assert latest.run_id == result.run_id
            assert latest.improvement == 0.25

            # Verify persistence
            tracker2 = OptimizationMetricsTracker(temp_metrics_path)
            assert tracker2.get_total_runs() == 1
            assert tracker2.get_latest().run_id == result.run_id

    @pytest.mark.asyncio
    async def test_multiple_optimization_runs(
        self, mock_trace_collector, mock_optimizer
    ):
        """Test multiple optimization runs are tracked correctly."""
        tracker = OptimizationMetricsTracker()
        scheduler = OptimizationScheduler(
            trace_collector=mock_trace_collector,
            optimizer=mock_optimizer,
            metrics_tracker=tracker,
            trace_threshold=50,
        )

        # Run multiple times
        for i in range(3):
            result = await scheduler.force_run()
            assert result is not None

        assert tracker.get_total_runs() == 3
        assert tracker.get_success_rate() == 1.0  # All successful
