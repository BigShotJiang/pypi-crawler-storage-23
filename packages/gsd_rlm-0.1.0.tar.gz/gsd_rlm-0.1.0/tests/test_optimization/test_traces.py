"""
Tests for ExecutionTrace dataclass and TraceCollector.

Covers trace creation, serialization, DSPy integration,
and SQLite persistence.
"""

import json
import pytest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch, MagicMock

from gsd_rlm.optimization.traces import (
    ExecutionTrace,
    TraceCollector,
    HAS_DSPY,
    _utc_now_iso,
    _generate_trace_id,
)


class TestExecutionTraceDataclass:
    """Tests for ExecutionTrace dataclass."""

    def test_trace_creation(self):
        """Test basic trace creation with required fields."""
        trace = ExecutionTrace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
        )

        assert trace.trace_id == "trace_001"
        assert trace.agent_id == "agent_001"
        assert trace.session_id == "session_001"
        assert trace.success is False
        assert trace.task_input == {}
        assert trace.task_output == {}
        assert trace.context == ""
        assert trace.reward == 0.0
        assert trace.tokens_used == 0
        assert trace.duration_ms == 0
        assert trace.tags == []
        assert trace.timestamp is not None

    def test_trace_creation_with_all_fields(self):
        """Test trace creation with all fields populated."""
        trace = ExecutionTrace(
            trace_id="trace_002",
            agent_id="agent_001",
            session_id="session_001",
            task_input={"query": "test query", "context": "some context"},
            task_output={"result": "test result", "status": "completed"},
            success=True,
            context="Additional context for the task",
            reward=0.95,
            timestamp="2025-01-15T10:30:00+00:00",
            tokens_used=150,
            duration_ms=2500,
            tags=["planning", "successful"],
        )

        assert trace.trace_id == "trace_002"
        assert trace.task_input == {"query": "test query", "context": "some context"}
        assert trace.task_output == {"result": "test result", "status": "completed"}
        assert trace.success is True
        assert trace.context == "Additional context for the task"
        assert trace.reward == 0.95
        assert trace.timestamp == "2025-01-15T10:30:00+00:00"
        assert trace.tokens_used == 150
        assert trace.duration_ms == 2500
        assert trace.tags == ["planning", "successful"]

    def test_trace_serialization(self):
        """Test to_dict() serialization."""
        trace = ExecutionTrace(
            trace_id="trace_003",
            agent_id="agent_001",
            session_id="session_001",
            task_input={"query": "test"},
            task_output={"result": "ok"},
            success=True,
            reward=0.8,
            tags=["test"],
        )

        data = trace.to_dict()

        assert isinstance(data, dict)
        assert data["trace_id"] == "trace_003"
        assert data["agent_id"] == "agent_001"
        assert data["session_id"] == "session_001"
        assert data["task_input"] == {"query": "test"}
        assert data["task_output"] == {"result": "ok"}
        assert data["success"] is True
        assert data["reward"] == 0.8
        assert data["tags"] == ["test"]
        # Verify JSON serializable
        json_str = json.dumps(data)
        assert json_str is not None

    def test_trace_from_dict(self):
        """Test from_dict() deserialization."""
        data = {
            "trace_id": "trace_004",
            "agent_id": "agent_002",
            "session_id": "session_002",
            "task_input": {"command": "execute"},
            "task_output": {"status": "done"},
            "success": True,
            "context": "Test context",
            "reward": 0.75,
            "timestamp": "2025-01-15T12:00:00+00:00",
            "tokens_used": 200,
            "duration_ms": 1500,
            "tags": ["execution"],
        }

        trace = ExecutionTrace.from_dict(data)

        assert trace.trace_id == "trace_004"
        assert trace.agent_id == "agent_002"
        assert trace.session_id == "session_002"
        assert trace.task_input == {"command": "execute"}
        assert trace.task_output == {"status": "done"}
        assert trace.success is True
        assert trace.context == "Test context"
        assert trace.reward == 0.75
        assert trace.timestamp == "2025-01-15T12:00:00+00:00"
        assert trace.tokens_used == 200
        assert trace.duration_ms == 1500
        assert trace.tags == ["execution"]

    def test_to_dspy_example_returns_example_when_dspy_available(self):
        """Test to_dspy_example() returns DSPy Example when available."""
        trace = ExecutionTrace(
            trace_id="trace_005",
            agent_id="agent_001",
            session_id="session_001",
            task_input={"query": "test"},
            task_output={"result": "ok"},
            success=True,
            context="Test context",
            reward=0.9,
        )

        # Patch HAS_DSPY to True for this test
        with patch("gsd_rlm.optimization.traces.HAS_DSPY", True):
            # Mock dspy.Example
            mock_example = MagicMock()
            mock_example.with_inputs.return_value = mock_example

            with patch("gsd_rlm.optimization.traces.dspy") as mock_dspy:
                mock_dspy.Example.return_value = mock_example

                example = trace.to_dspy_example()

                # Verify dspy.Example was called
                mock_dspy.Example.assert_called_once()
                call_kwargs = mock_dspy.Example.call_args[1]
                assert "task_input" in call_kwargs
                assert "task_output" in call_kwargs
                assert "context" in call_kwargs
                assert call_kwargs["context"] == "Test context"

    def test_to_dspy_example_returns_none_when_dspy_unavailable(self):
        """Test to_dspy_example() returns None when DSPy is not available."""
        trace = ExecutionTrace(
            trace_id="trace_006",
            agent_id="agent_001",
            session_id="session_001",
            task_input={"query": "test"},
            task_output={"result": "ok"},
        )

        # Patch HAS_DSPY to False
        with patch("gsd_rlm.optimization.traces.HAS_DSPY", False):
            example = trace.to_dspy_example()
            assert example is None

    def test_trace_default_values(self):
        """Test that default values are correctly set."""
        trace = ExecutionTrace(
            trace_id="trace_007",
            agent_id="agent_001",
            session_id="session_001",
        )

        # Check all defaults
        assert trace.task_input == {}
        assert trace.task_output == {}
        assert trace.success is False
        assert trace.context == ""
        assert trace.reward == 0.0
        assert trace.tokens_used == 0
        assert trace.duration_ms == 0
        assert trace.tags == []
        # Timestamp should be auto-generated
        assert trace.timestamp is not None
        assert len(trace.timestamp) > 0

    def test_trace_post_init_normalizes_none_values(self):
        """Test __post_init__ normalizes None values to defaults."""
        # Create with None values (bypassing type hints)
        trace = ExecutionTrace(
            trace_id="trace_008",
            agent_id="agent_001",
            session_id="session_001",
            task_input=None,
            task_output=None,
            tags=None,
        )

        # __post_init__ should have normalized these
        assert trace.task_input == {}
        assert trace.task_output == {}
        assert trace.tags == []

    def test_add_tag(self):
        """Test add_tag method."""
        trace = ExecutionTrace(
            trace_id="trace_009",
            agent_id="agent_001",
            session_id="session_001",
        )

        trace.add_tag("planning")
        assert "planning" in trace.tags

        trace.add_tag("planning")  # Should not duplicate
        assert trace.tags.count("planning") == 1

        trace.add_tag("execution")
        assert "execution" in trace.tags
        assert len(trace.tags) == 2

    def test_remove_tag(self):
        """Test remove_tag method."""
        trace = ExecutionTrace(
            trace_id="trace_010",
            agent_id="agent_001",
            session_id="session_001",
            tags=["planning", "execution"],
        )

        result = trace.remove_tag("planning")
        assert result is True
        assert "planning" not in trace.tags
        assert "execution" in trace.tags

        result = trace.remove_tag("nonexistent")
        assert result is False


class TestTraceCollector:
    """Tests for TraceCollector SQLite persistence."""

    def test_collector_init_creates_db(self, tmp_path):
        """Test that collector creates database file on init."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        assert db_path.exists()
        assert collector.db_path == db_path

    def test_collector_init_creates_parent_directories(self, tmp_path):
        """Test that collector creates parent directories."""
        db_path = tmp_path / "nested" / "dir" / "traces.db"
        collector = TraceCollector(str(db_path))

        assert db_path.parent.exists()
        assert db_path.exists()

    def test_store_and_retrieve_trace(self, tmp_path):
        """Test storing and retrieving a trace."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        trace = ExecutionTrace(
            trace_id="trace_001",
            agent_id="agent_001",
            session_id="session_001",
            task_input={"query": "test query"},
            task_output={"result": "test result"},
            success=True,
            reward=0.9,
            tags=["test"],
        )

        collector.record(trace)

        retrieved = collector.get("trace_001")

        assert retrieved is not None
        assert retrieved.trace_id == "trace_001"
        assert retrieved.agent_id == "agent_001"
        assert retrieved.session_id == "session_001"
        assert retrieved.task_input == {"query": "test query"}
        assert retrieved.task_output == {"result": "test result"}
        assert retrieved.success is True
        assert retrieved.reward == 0.9
        assert retrieved.tags == ["test"]

    def test_get_traces_for_agent(self, tmp_path):
        """Test retrieving traces for a specific agent."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        # Create traces for different agents
        for i in range(3):
            collector.record(
                ExecutionTrace(
                    trace_id=f"trace_agent1_{i}",
                    agent_id="agent_001",
                    session_id="session_001",
                    success=True,
                )
            )

        for i in range(2):
            collector.record(
                ExecutionTrace(
                    trace_id=f"trace_agent2_{i}",
                    agent_id="agent_002",
                    session_id="session_001",
                    success=True,
                )
            )

        agent1_traces = collector.get_traces_for_agent("agent_001")
        agent2_traces = collector.get_traces_for_agent("agent_002")

        assert len(agent1_traces) == 3
        assert len(agent2_traces) == 2
        assert all(t.agent_id == "agent_001" for t in agent1_traces)
        assert all(t.agent_id == "agent_002" for t in agent2_traces)

    def test_get_traces_for_session(self, tmp_path):
        """Test retrieving traces for a specific session."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        # Create traces for different sessions
        for i in range(3):
            collector.record(
                ExecutionTrace(
                    trace_id=f"trace_s1_{i}",
                    agent_id="agent_001",
                    session_id="session_001",
                    success=True,
                )
            )

        for i in range(4):
            collector.record(
                ExecutionTrace(
                    trace_id=f"trace_s2_{i}",
                    agent_id="agent_001",
                    session_id="session_002",
                    success=True,
                )
            )

        session1_traces = collector.get_traces_for_session("session_001")
        session2_traces = collector.get_traces_for_session("session_002")

        assert len(session1_traces) == 3
        assert len(session2_traces) == 4
        assert all(t.session_id == "session_001" for t in session1_traces)
        assert all(t.session_id == "session_002" for t in session2_traces)

    def test_get_successful_traces_filters_by_success(self, tmp_path):
        """Test that get_successful_traces only returns successful traces."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        # Create mix of successful and failed traces
        for i in range(5):
            collector.record(
                ExecutionTrace(
                    trace_id=f"trace_success_{i}",
                    agent_id="agent_001",
                    session_id="session_001",
                    success=True,
                )
            )

        for i in range(3):
            collector.record(
                ExecutionTrace(
                    trace_id=f"trace_fail_{i}",
                    agent_id="agent_001",
                    session_id="session_001",
                    success=False,
                )
            )

        successful = collector.get_successful_traces()

        assert len(successful) == 5
        assert all(t.success is True for t in successful)

    def test_get_successful_traces_respects_limit(self, tmp_path):
        """Test that get_successful_traces respects the limit parameter."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        # Create more successful traces than the limit
        for i in range(20):
            collector.record(
                ExecutionTrace(
                    trace_id=f"trace_{i}",
                    agent_id="agent_001",
                    session_id="session_001",
                    success=True,
                )
            )

        limited = collector.get_successful_traces(limit=5)

        assert len(limited) == 5

    def test_get_training_dataset_returns_dspy_examples(self, tmp_path):
        """Test get_training_dataset returns DSPy Examples when available."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        # Create successful traces
        for i in range(3):
            collector.record(
                ExecutionTrace(
                    trace_id=f"trace_{i}",
                    agent_id="agent_001",
                    session_id="session_001",
                    task_input={"query": f"query_{i}"},
                    task_output={"result": f"result_{i}"},
                    success=True,
                )
            )

        # Create a failed trace (should be excluded)
        collector.record(
            ExecutionTrace(
                trace_id="trace_failed",
                agent_id="agent_001",
                session_id="session_001",
                success=False,
            )
        )

        # Mock DSPy availability
        with patch("gsd_rlm.optimization.traces.HAS_DSPY", True):
            mock_example = MagicMock()
            mock_example.with_inputs.return_value = mock_example

            with patch("gsd_rlm.optimization.traces.dspy") as mock_dspy:
                mock_dspy.Example.return_value = mock_example

                examples = collector.get_training_dataset()

                # Should only return successful traces (3)
                assert len(examples) == 3

    def test_get_training_dataset_returns_empty_when_dspy_unavailable(self, tmp_path):
        """Test get_training_dataset returns empty list when DSPy unavailable."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        # Create successful traces
        collector.record(
            ExecutionTrace(
                trace_id="trace_001",
                agent_id="agent_001",
                session_id="session_001",
                success=True,
            )
        )

        with patch("gsd_rlm.optimization.traces.HAS_DSPY", False):
            examples = collector.get_training_dataset()
            assert examples == []

    def test_persistence_across_restarts(self, tmp_path):
        """Test that traces persist across collector restarts."""
        db_path = tmp_path / "test_traces.db"

        # First collector instance
        collector1 = TraceCollector(str(db_path))
        collector1.record(
            ExecutionTrace(
                trace_id="trace_persist",
                agent_id="agent_001",
                session_id="session_001",
                task_input={"key": "value"},
                success=True,
            )
        )

        # Second collector instance (simulates restart)
        collector2 = TraceCollector(str(db_path))
        retrieved = collector2.get("trace_persist")

        assert retrieved is not None
        assert retrieved.trace_id == "trace_persist"
        assert retrieved.task_input == {"key": "value"}

    def test_count(self, tmp_path):
        """Test count method."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        assert collector.count() == 0

        for i in range(5):
            collector.record(
                ExecutionTrace(
                    trace_id=f"trace_{i}",
                    agent_id="agent_001",
                    session_id="session_001",
                )
            )

        assert collector.count() == 5

    def test_delete(self, tmp_path):
        """Test delete method."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        collector.record(
            ExecutionTrace(
                trace_id="trace_to_delete",
                agent_id="agent_001",
                session_id="session_001",
            )
        )

        assert collector.get("trace_to_delete") is not None

        result = collector.delete("trace_to_delete")

        assert result is True
        assert collector.get("trace_to_delete") is None

        # Delete non-existent should return False
        result = collector.delete("nonexistent")
        assert result is False

    def test_upsert_with_insert_or_replace(self, tmp_path):
        """Test that INSERT OR REPLACE updates existing traces."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        # Insert initial trace
        collector.record(
            ExecutionTrace(
                trace_id="trace_upsert",
                agent_id="agent_001",
                session_id="session_001",
                task_input={"version": 1},
                success=False,
            )
        )

        # Update with same trace_id
        collector.record(
            ExecutionTrace(
                trace_id="trace_upsert",
                agent_id="agent_001",
                session_id="session_001",
                task_input={"version": 2},
                success=True,
            )
        )

        # Should have only one trace, with updated values
        assert collector.count() == 1
        retrieved = collector.get("trace_upsert")
        assert retrieved.task_input == {"version": 2}
        assert retrieved.success is True

    def test_get_nonexistent_trace(self, tmp_path):
        """Test get returns None for non-existent trace."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        result = collector.get("nonexistent")
        assert result is None

    def test_complex_json_in_task_input_output(self, tmp_path):
        """Test that complex nested JSON is properly serialized."""
        db_path = tmp_path / "test_traces.db"
        collector = TraceCollector(str(db_path))

        complex_input = {
            "nested": {
                "deeply": {
                    "value": 42,
                    "list": [1, 2, 3],
                }
            },
            "list_of_dicts": [
                {"a": 1, "b": 2},
                {"c": 3, "d": 4},
            ],
        }

        complex_output = {
            "results": [
                {"status": "ok", "data": [1, 2, 3]},
                {"status": "ok", "data": [4, 5, 6]},
            ],
            "metadata": {"count": 2, "total": 6},
        }

        trace = ExecutionTrace(
            trace_id="trace_complex",
            agent_id="agent_001",
            session_id="session_001",
            task_input=complex_input,
            task_output=complex_output,
            success=True,
        )

        collector.record(trace)
        retrieved = collector.get("trace_complex")

        assert retrieved.task_input == complex_input
        assert retrieved.task_output == complex_output


class TestUtilityFunctions:
    """Tests for utility functions."""

    def test_utc_now_iso_format(self):
        """Test _utc_now_iso returns valid ISO format."""
        result = _utc_now_iso()

        # Should be parseable as ISO format
        parsed = datetime.fromisoformat(result.replace("Z", "+00:00"))
        assert parsed is not None

        # Should be timezone-aware
        assert parsed.tzinfo is not None

    def test_generate_trace_id_format(self):
        """Test _generate_trace_id returns correct format."""
        trace_id = _generate_trace_id()

        assert trace_id.startswith("trace_")
        assert len(trace_id) == len("trace_") + 12  # 12 hex chars

        # Should be unique
        trace_id2 = _generate_trace_id()
        assert trace_id != trace_id2
