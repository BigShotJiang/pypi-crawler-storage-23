"""
Tests for optimization metrics and AgentOptimizer.

Covers metric evaluation, MIPROv2 wrapper functionality,
and edge cases with mocked DSPy.
"""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock, PropertyMock
from datetime import datetime, timezone

from gsd_rlm.optimization.metrics import (
    task_success_metric,
    quality_metric,
    latency_metric,
    composite_metric,
    MetricRegistry,
    HAS_DSPY,
)
from gsd_rlm.optimization.optimizer import (
    AgentOptimizer,
    OptimizationResult,
)


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def mock_dspy_available():
    """Fixture to ensure HAS_DSPY is True for tests."""
    with patch("gsd_rlm.optimization.metrics.HAS_DSPY", True):
        yield


@pytest.fixture
def mock_pred_success():
    """Create a mock prediction with success=True."""
    pred = MagicMock()
    pred.success = True
    return pred


@pytest.fixture
def mock_pred_failure():
    """Create a mock prediction with success=False."""
    pred = MagicMock()
    pred.success = False
    return pred


@pytest.fixture
def mock_pred_with_answer():
    """Create a mock prediction with answer field (no success attribute)."""
    pred = MagicMock(spec=["answer", "task_output"])
    pred.answer = "expected_answer"
    return pred


@pytest.fixture
def mock_example_with_answer():
    """Create a mock example with answer field."""
    example = MagicMock()
    example.answer = "expected_answer"
    return example


@pytest.fixture
def mock_pred_with_output():
    """Create a mock prediction with task_output dict (no success attribute)."""
    pred = MagicMock(spec=["task_output"])
    pred.task_output = {"result": "ok", "success": True}
    return pred


@pytest.fixture
def mock_optimizer_module():
    """Create a mock DSPy module for optimizer tests."""
    module = MagicMock()
    module.__class__.__name__ = "MockModule"
    module.signature = "question -> answer"
    module.demos = []
    return module


@pytest.fixture
def mock_trainset():
    """Create a mock training set with 15 examples."""
    examples = []
    for i in range(15):
        example = MagicMock()
        example.task_input = f"question_{i}"
        example.inputs = MagicMock(return_value={"task_input": f"question_{i}"})
        examples.append(example)
    return examples


# ============================================================================
# TestTaskSuccessMetric
# ============================================================================


class TestTaskSuccessMetric:
    """Tests for task_success_metric function."""

    def test_metric_returns_1_for_success(self, mock_dspy_available, mock_pred_success):
        """Metric returns 1.0 when prediction has success=True."""
        example = MagicMock()
        score = task_success_metric(example, mock_pred_success)
        assert score == 1.0

    def test_metric_returns_0_for_failure(self, mock_dspy_available, mock_pred_failure):
        """Metric returns 0.0 when prediction has success=False."""
        example = MagicMock()
        score = task_success_metric(example, mock_pred_failure)
        assert score == 0.0

    def test_metric_returns_1_for_matching_answer(
        self, mock_dspy_available, mock_pred_with_answer, mock_example_with_answer
    ):
        """Metric returns 1.0 when answers match."""
        score = task_success_metric(mock_example_with_answer, mock_pred_with_answer)
        assert score == 1.0

    def test_metric_returns_0_for_non_matching_answer(self, mock_dspy_available):
        """Metric returns 0.0 when answers don't match."""
        example = MagicMock()
        example.answer = "expected"
        pred = MagicMock(spec=["answer"])  # No success attribute
        pred.answer = "different"

        score = task_success_metric(example, pred)
        assert score == 0.0

    def test_metric_returns_1_for_successful_task_output(
        self, mock_dspy_available, mock_pred_with_output
    ):
        """Metric returns 1.0 when task_output has success=True."""
        example = MagicMock()
        example.task_output = {"result": "ok"}

        score = task_success_metric(example, mock_pred_with_output)
        assert score == 1.0

    def test_metric_returns_1_for_non_null_prediction(self, mock_dspy_available):
        """Metric returns 1.0 for any non-null prediction without specific fields."""
        example = MagicMock()
        pred = MagicMock(spec=[])  # No attributes

        score = task_success_metric(example, pred)
        assert score == 1.0

    def test_metric_returns_0_for_null_prediction(self, mock_dspy_available):
        """Metric returns 0.0 for null prediction."""
        example = MagicMock()
        score = task_success_metric(example, None)
        assert score == 0.0

    def test_metric_returns_0_when_dspy_unavailable(self):
        """Metric returns 0.0 when DSPy is not available."""
        with patch("gsd_rlm.optimization.metrics.HAS_DSPY", False):
            example = MagicMock()
            pred = MagicMock()
            pred.success = True

            score = task_success_metric(example, pred)
            assert score == 0.0


# ============================================================================
# TestQualityMetric
# ============================================================================


class TestQualityMetric:
    """Tests for quality_metric function."""

    def test_quality_metric_with_complete_output(self, mock_dspy_available):
        """Quality metric scores complete outputs higher."""
        pred = MagicMock()
        pred.task_output = {"result": "ok", "status": "done"}
        pred.context = "Some context"

        example = MagicMock()
        score = quality_metric(example, pred)

        # Should have high score: 0.4 (complete) + 0.3 (context) + 0.3 (dict format)
        assert score >= 0.9

    def test_quality_metric_with_incomplete_output(self, mock_dspy_available):
        """Quality metric scores incomplete outputs lower."""
        pred = MagicMock(spec=["task_output"])  # Only task_output, no context
        pred.task_output = {"result": "ok"}  # Missing status

        example = MagicMock()
        score = quality_metric(example, pred)

        # Should have lower score: 0.2 (completeness) + 0.3 (format) = 0.5
        assert 0.0 <= score <= 0.7

    def test_quality_metric_returns_0_when_dspy_unavailable(self):
        """Quality metric returns 0.0 when DSPy is not available."""
        with patch("gsd_rlm.optimization.metrics.HAS_DSPY", False):
            pred = MagicMock()
            pred.task_output = {"result": "ok"}

            example = MagicMock()
            score = quality_metric(example, pred)
            assert score == 0.0


# ============================================================================
# TestLatencyMetric
# ============================================================================


class TestLatencyMetric:
    """Tests for latency_metric function."""

    def test_latency_metric_returns_1_for_fast_response(self, mock_dspy_available):
        """Latency metric returns 1.0 for responses under target."""
        pred = MagicMock()
        pred.duration_ms = 1000  # Under default target of 5000

        example = MagicMock()
        score = latency_metric(example, pred)
        assert score == 1.0

    def test_latency_metric_returns_0_for_slow_response(self, mock_dspy_available):
        """Latency metric returns 0.0 for responses over max."""
        pred = MagicMock()
        pred.duration_ms = 35000  # Over default max of 30000

        example = MagicMock()
        score = latency_metric(example, pred)
        assert score == 0.0

    def test_latency_metric_scales_between_target_and_max(self, mock_dspy_available):
        """Latency metric scales linearly between target and max."""
        pred = MagicMock()
        pred.duration_ms = 17500  # Halfway between 5000 and 30000

        example = MagicMock()
        score = latency_metric(example, pred)

        # Should be around 0.5 (halfway)
        assert 0.4 <= score <= 0.6

    def test_latency_metric_returns_neutral_without_timing(self, mock_dspy_available):
        """Latency metric returns 0.5 when no timing info available."""
        pred = MagicMock(spec=[])  # No duration_ms
        example = MagicMock(spec=[])

        score = latency_metric(example, pred)
        assert score == 0.5

    def test_latency_metric_uses_trace_timing(self, mock_dspy_available):
        """Latency metric uses timing from trace if available."""
        pred = MagicMock(spec=[])
        example = MagicMock(spec=[])
        trace = MagicMock()
        trace.duration_ms = 2000

        score = latency_metric(example, pred, trace)
        assert score == 1.0


# ============================================================================
# TestCompositeMetric
# ============================================================================


class TestCompositeMetric:
    """Tests for composite_metric function."""

    def test_composite_uses_default_weights(self, mock_dspy_available):
        """Composite metric uses default weights when none provided."""
        pred = MagicMock()
        pred.success = True
        pred.task_output = {"result": "ok", "status": "done"}
        pred.context = "context"
        pred.duration_ms = 2000

        example = MagicMock()
        score = composite_metric(example, pred)

        # Should be high with all components scoring well
        assert 0.7 <= score <= 1.0

    def test_composite_applies_custom_weights(self, mock_dspy_available):
        """Composite metric applies custom weights correctly."""
        pred = MagicMock()
        pred.success = True
        pred.duration_ms = 1000

        example = MagicMock()
        weights = {"success": 1.0, "quality": 0.0, "latency": 0.0}

        score = composite_metric(example, pred, weights=weights)
        assert score == 1.0  # Only success matters

    def test_composite_returns_0_with_empty_weights(self, mock_dspy_available):
        """Composite metric returns 0.0 when weights sum to 0."""
        pred = MagicMock()
        pred.success = True

        example = MagicMock()
        weights = {}  # Empty weights

        score = composite_metric(example, pred, weights=weights)
        assert score == 0.0


# ============================================================================
# TestMetricRegistry
# ============================================================================


class TestMetricRegistry:
    """Tests for MetricRegistry class."""

    def setup_method(self):
        """Clear registry before each test."""
        MetricRegistry.clear()

    def test_register_and_get_metric(self):
        """Can register and retrieve a metric."""
        custom_metric = lambda e, p, t: 0.5
        MetricRegistry.register("custom", custom_metric)

        retrieved = MetricRegistry.get("custom")
        assert retrieved == custom_metric

    def test_register_empty_name_raises(self):
        """Registering with empty name raises ValueError."""
        with pytest.raises(ValueError, match="cannot be empty"):
            MetricRegistry.register("", lambda e, p, t: 0.5)

    def test_register_non_callable_raises(self):
        """Registering non-callable raises ValueError."""
        with pytest.raises(ValueError, match="must be callable"):
            MetricRegistry.register("test", "not a function")

    def test_get_builtin_metric(self):
        """Can retrieve built-in metrics."""
        metric = MetricRegistry.get("task_success")
        assert metric == task_success_metric

    def test_get_nonexistent_returns_none(self):
        """Getting nonexistent metric returns None."""
        result = MetricRegistry.get("nonexistent_metric")
        assert result is None

    def test_list_metrics_includes_builtin(self):
        """list_metrics includes built-in metrics."""
        metrics = MetricRegistry.list_metrics()
        assert "task_success" in metrics
        assert "quality" in metrics
        assert "latency" in metrics
        assert "composite" in metrics

    def test_list_metrics_includes_custom(self):
        """list_metrics includes custom registered metrics."""
        MetricRegistry.register("my_custom", lambda e, p, t: 0.5)
        metrics = MetricRegistry.list_metrics()
        assert "my_custom" in metrics

    def test_unregister_removes_metric(self):
        """unregister removes custom metric."""
        MetricRegistry.register("to_remove", lambda e, p, t: 0.5)
        result = MetricRegistry.unregister("to_remove")
        assert result is True
        assert MetricRegistry.get("to_remove") is None

    def test_unregister_nonexistent_returns_false(self):
        """unregister returns False for nonexistent metric."""
        result = MetricRegistry.unregister("nonexistent")
        assert result is False

    def test_clear_removes_all_custom(self):
        """clear removes all custom metrics."""
        MetricRegistry.register("custom1", lambda e, p, t: 0.5)
        MetricRegistry.register("custom2", lambda e, p, t: 0.5)
        MetricRegistry.clear()

        # Built-ins should still be available
        assert MetricRegistry.get("task_success") is not None


# ============================================================================
# TestOptimizationResult
# ============================================================================


class TestOptimizationResult:
    """Tests for OptimizationResult dataclass."""

    def test_result_creation(self):
        """OptimizationResult creates with correct values."""
        result = OptimizationResult(
            success=True,
            score_before=0.5,
            score_after=0.8,
            improvement=0.3,
            traces_used=15,
        )

        assert result.success is True
        assert result.score_before == 0.5
        assert result.score_after == 0.8
        assert result.improvement == 0.3
        assert result.traces_used == 15
        assert result.error is None
        assert result.timestamp is not None

    def test_improvement_calculation(self):
        """Improvement is calculated correctly."""
        result = OptimizationResult(
            success=True,
            score_before=0.3,
            score_after=0.7,
            improvement=0.4,  # 0.7 - 0.3
            traces_used=10,
        )

        assert result.improvement == 0.4

    def test_result_with_error(self):
        """OptimizationResult captures error correctly."""
        result = OptimizationResult(
            success=False,
            score_before=0.0,
            score_after=0.0,
            improvement=0.0,
            traces_used=10,
            error="Something went wrong",
        )

        assert result.success is False
        assert result.error == "Something went wrong"

    def test_result_serialization(self):
        """OptimizationResult can be serialized to dict."""
        result = OptimizationResult(
            success=True,
            score_before=0.5,
            score_after=0.8,
            improvement=0.3,
            traces_used=15,
            optimizer_config={"auto": "light"},
        )

        data = result.to_dict()

        assert data["success"] is True
        assert data["score_before"] == 0.5
        assert data["score_after"] == 0.8
        assert data["improvement"] == 0.3
        assert data["traces_used"] == 15
        assert data["optimizer_config"]["auto"] == "light"
        assert "optimized_program" not in data  # Should be excluded

    def test_result_deserialization(self):
        """OptimizationResult can be created from dict."""
        data = {
            "success": True,
            "score_before": 0.4,
            "score_after": 0.9,
            "improvement": 0.5,
            "traces_used": 20,
            "optimizer_config": {"auto": "medium"},
        }

        result = OptimizationResult.from_dict(data)

        assert result.success is True
        assert result.score_before == 0.4
        assert result.score_after == 0.9
        assert result.improvement == 0.5
        assert result.traces_used == 20


# ============================================================================
# TestAgentOptimizer
# ============================================================================


class TestAgentOptimizer:
    """Tests for AgentOptimizer class."""

    def test_init_requires_dspy(self):
        """AgentOptimizer raises ImportError when DSPy unavailable."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", False):
            with pytest.raises(ImportError, match="DSPy is required"):
                AgentOptimizer()

    def test_init_with_dspy_available(self):
        """AgentOptimizer initializes correctly when DSPy available."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer()
            assert optimizer.auto == "light"
            assert optimizer.max_rounds == 3
            assert optimizer.metric == task_success_metric

    def test_init_with_custom_params(self):
        """AgentOptimizer accepts custom parameters."""
        custom_metric = lambda e, p, t: 0.5
        mock_module = MagicMock()

        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer(
                agent_module=mock_module,
                metric=custom_metric,
                auto="heavy",
                max_rounds=5,
                num_threads=4,
            )

            assert optimizer.agent_module == mock_module
            assert optimizer.metric == custom_metric
            assert optimizer.auto == "heavy"
            assert optimizer.max_rounds == 5
            assert optimizer.num_threads == 4

    def test_optimize_validates_trainset_size(self):
        """optimize raises ValueError for small trainset."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer(agent_module=MagicMock())
            small_trainset = [MagicMock() for _ in range(5)]  # Only 5 examples

            with pytest.raises(ValueError, match="at least 10"):
                optimizer.optimize(small_trainset)

    def test_optimize_validates_agent_module(self):
        """optimize raises ValueError when agent_module is None."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer()  # No agent_module
            trainset = [MagicMock() for _ in range(15)]

            with pytest.raises(ValueError, match="agent_module is required"):
                optimizer.optimize(trainset)

    def test_optimize_runs_mipro_compile(self, mock_trainset):
        """optimize calls MIPROv2.compile with correct parameters."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            mock_mipro = MagicMock()
            mock_mipro.compile.return_value = MagicMock()

            mock_module = MagicMock()

            with patch(
                "gsd_rlm.optimization.optimizer.MIPROv2", return_value=mock_mipro
            ):
                optimizer = AgentOptimizer(
                    agent_module=mock_module,
                    auto="light",
                )

                result = optimizer.optimize(mock_trainset)

                # Verify MIPROv2 was created and compile was called
                mock_mipro.compile.assert_called_once()
                assert result.success is True
                assert result.traces_used == 15

    def test_optimize_calculates_improvement(
        self, mock_trainset, mock_optimizer_module
    ):
        """optimize calculates before/after scores correctly."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            mock_mipro = MagicMock()
            optimized = MagicMock()
            optimized.__class__.__name__ = "OptimizedModule"
            mock_mipro.compile.return_value = optimized

            with patch(
                "gsd_rlm.optimization.optimizer.MIPROv2", return_value=mock_mipro
            ):
                optimizer = AgentOptimizer(agent_module=mock_optimizer_module)

                # Mock evaluate to return different scores
                optimizer._evaluate = MagicMock(side_effect=[0.5, 0.8])

                result = optimizer.optimize(mock_trainset)

                assert result.score_before == pytest.approx(0.5)
                assert result.score_after == pytest.approx(0.8)
                assert result.improvement == pytest.approx(0.3)

    def test_optimize_returns_error_on_failure(self, mock_trainset):
        """optimize returns error result when optimization fails."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            mock_mipro = MagicMock()
            mock_mipro.compile.side_effect = RuntimeError("Optimization failed")

            with patch(
                "gsd_rlm.optimization.optimizer.MIPROv2", return_value=mock_mipro
            ):
                optimizer = AgentOptimizer(agent_module=MagicMock())
                result = optimizer.optimize(mock_trainset)

                assert result.success is False
                assert "Optimization failed" in result.error

    def test_save_program_to_file(self, tmp_path):
        """save writes program to file."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            mock_program = MagicMock()
            mock_program.save = MagicMock()

            optimizer = AgentOptimizer()
            save_path = tmp_path / "optimized_program.json"

            optimizer.save(mock_program, save_path)

            mock_program.save.assert_called_once_with(str(save_path))

    def test_save_program_fallback_json(self, tmp_path):
        """save uses JSON fallback when program has no save method."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            mock_program = MagicMock(spec=[])  # No save method
            mock_program.__class__.__name__ = "TestModule"
            mock_program.signature = "input -> output"
            mock_program.demos = ["demo1", "demo2"]

            optimizer = AgentOptimizer()
            save_path = tmp_path / "optimized_program.json"

            optimizer.save(mock_program, save_path)

            assert save_path.exists()
            with open(save_path, "r") as f:
                data = json.load(f)

            assert data["type"] == "TestModule"
            assert data["signature"] == "input -> output"
            assert len(data["demos"]) == 2

    def test_load_program_from_file(self, tmp_path):
        """load reads program from file."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer()

            # Create a saved file
            save_path = tmp_path / "program.json"
            save_path.write_text('{"type": "TestModule"}')

            result = optimizer.load(save_path)

            assert result is not None
            assert result["type"] == "TestModule"

    def test_load_nonexistent_file_returns_none(self, tmp_path):
        """load returns None for nonexistent file."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer()
            result = optimizer.load(tmp_path / "nonexistent.json")
            assert result is None

    def test_get_history(self):
        """get_history returns optimization history."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer()

            # Manually add to history
            optimizer._history.append(
                OptimizationResult(
                    success=True,
                    score_before=0.5,
                    score_after=0.8,
                    improvement=0.3,
                    traces_used=10,
                )
            )

            history = optimizer.get_history()
            assert len(history) == 1
            assert history[0].success is True

    def test_clear_history(self):
        """clear_history removes all history entries."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer()
            optimizer._history.append(
                OptimizationResult(
                    success=True,
                    score_before=0.5,
                    score_after=0.8,
                    improvement=0.3,
                    traces_used=10,
                )
            )

            optimizer.clear_history()
            assert len(optimizer.get_history()) == 0

    def test_last_result_property(self):
        """last_result returns most recent optimization result."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer()

            assert optimizer.last_result is None

            optimizer._history.append(
                OptimizationResult(
                    success=True,
                    score_before=0.5,
                    score_after=0.8,
                    improvement=0.3,
                    traces_used=10,
                )
            )

            assert optimizer.last_result.traces_used == 10


# ============================================================================
# TestAgentOptimizerEdgeCases
# ============================================================================


class TestAgentOptimizerEdgeCases:
    """Edge case tests for AgentOptimizer."""

    def test_optimize_with_empty_trainset_raises(self):
        """optimize raises ValueError for empty trainset."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer(agent_module=MagicMock())

            with pytest.raises(ValueError, match="at least 10"):
                optimizer.optimize([])

    def test_handles_dspy_error_gracefully(self, mock_trainset):
        """optimize handles DSPy errors and returns error result."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            with patch("gsd_rlm.optimization.optimizer.MIPROv2") as MockMIPRO:
                MockMIPRO.side_effect = ImportError("DSPy internal error")

                optimizer = AgentOptimizer(agent_module=MagicMock())
                result = optimizer.optimize(mock_trainset)

                assert result.success is False
                assert "DSPy internal error" in result.error

    def test_evaluate_with_empty_dataset(self):
        """_evaluate returns 0.0 for empty dataset."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            optimizer = AgentOptimizer()

            score = optimizer._evaluate(MagicMock(), [])
            assert score == 0.0

    def test_evaluate_with_program_errors(self):
        """_evaluate handles program execution errors gracefully."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            mock_program = MagicMock()
            mock_program.side_effect = RuntimeError("Program failed")

            example = MagicMock()
            example.task_input = "test"
            example.inputs = MagicMock(return_value={"task_input": "test"})

            optimizer = AgentOptimizer()
            optimizer.metric = lambda e, p: 1.0  # Simple metric

            # Should not raise, returns 0.0 for failed predictions
            score = optimizer._evaluate(mock_program, [example])
            assert score == 0.0

    def test_auto_sets_num_trials(self, mock_trainset):
        """auto parameter sets appropriate num_trials."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            mock_mipro = MagicMock()
            mock_mipro.compile.return_value = MagicMock()

            with patch(
                "gsd_rlm.optimization.optimizer.MIPROv2", return_value=mock_mipro
            ):
                # Test light
                optimizer = AgentOptimizer(agent_module=MagicMock(), auto="light")
                optimizer.optimize(mock_trainset)
                call_kwargs = mock_mipro.compile.call_args[1]
                assert call_kwargs["num_trials"] == 10

                # Test medium
                optimizer = AgentOptimizer(agent_module=MagicMock(), auto="medium")
                optimizer.optimize(mock_trainset)
                call_kwargs = mock_mipro.compile.call_args[1]
                assert call_kwargs["num_trials"] == 25

                # Test heavy
                optimizer = AgentOptimizer(agent_module=MagicMock(), auto="heavy")
                optimizer.optimize(mock_trainset)
                call_kwargs = mock_mipro.compile.call_args[1]
                assert call_kwargs["num_trials"] == 50

    def test_custom_num_trials_overrides_auto(self, mock_trainset):
        """Custom num_trials overrides auto setting."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            mock_mipro = MagicMock()
            mock_mipro.compile.return_value = MagicMock()

            with patch(
                "gsd_rlm.optimization.optimizer.MIPROv2", return_value=mock_mipro
            ):
                optimizer = AgentOptimizer(agent_module=MagicMock(), auto="light")
                optimizer.optimize(mock_trainset, num_trials=100)

                call_kwargs = mock_mipro.compile.call_args[1]
                assert call_kwargs["num_trials"] == 100

    def test_valset_passed_to_compile(self, mock_trainset):
        """Validation set is passed to compile if provided."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            mock_mipro = MagicMock()
            mock_mipro.compile.return_value = MagicMock()

            valset = [MagicMock() for _ in range(5)]

            with patch(
                "gsd_rlm.optimization.optimizer.MIPROv2", return_value=mock_mipro
            ):
                optimizer = AgentOptimizer(agent_module=MagicMock())
                optimizer.optimize(mock_trainset, valset=valset)

                call_kwargs = mock_mipro.compile.call_args[1]
                assert call_kwargs["valset"] == valset

    def test_load_returns_none_when_dspy_unavailable(self, tmp_path):
        """load returns None when DSPy is not available."""
        save_path = tmp_path / "program.json"
        save_path.write_text('{"type": "TestModule"}')

        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", False):
            optimizer = AgentOptimizer.__new__(AgentOptimizer)
            result = optimizer.load(save_path)
            assert result is None


# ============================================================================
# Integration-style tests (with DSPy patterns)
# ============================================================================


class TestIntegrationPatterns:
    """Tests that verify integration patterns with mock DSPy."""

    def test_full_optimization_workflow(self, tmp_path):
        """Test full optimization workflow from traces to saved program."""
        with patch("gsd_rlm.optimization.optimizer.HAS_DSPY", True):
            # Create mock module and trainset
            mock_module = MagicMock()
            mock_module.__class__.__name__ = "AgentModule"

            trainset = []
            for i in range(15):
                example = MagicMock()
                example.task_input = f"task_{i}"
                example.inputs = MagicMock(return_value={"task_input": f"task_{i}"})
                trainset.append(example)

            # Mock MIPROv2
            mock_mipro = MagicMock()
            optimized = MagicMock()
            optimized.__class__.__name__ = "OptimizedModule"
            optimized.save = MagicMock()
            mock_mipro.compile.return_value = optimized

            with patch(
                "gsd_rlm.optimization.optimizer.MIPROv2", return_value=mock_mipro
            ):
                # Initialize optimizer
                optimizer = AgentOptimizer(
                    agent_module=mock_module,
                    auto="light",
                )

                # Run optimization
                result = optimizer.optimize(trainset)

                # Verify result
                assert result.success is True
                assert result.traces_used == 15

                # Save optimized program
                save_path = tmp_path / "optimized.json"
                optimizer.save(result.optimized_program, save_path)

                # Verify save was called
                optimized.save.assert_called_once()

    def test_metric_integration_with_traces(self):
        """Test metrics work with trace-like objects."""
        with patch("gsd_rlm.optimization.metrics.HAS_DSPY", True):
            # Create trace-like example and prediction
            example = MagicMock()
            example.task_input = {"query": "test"}
            example.task_output = {"result": "expected", "status": "done"}

            pred = MagicMock()
            pred.task_output = {"result": "expected", "status": "done", "success": True}
            pred.context = "Additional context"
            pred.duration_ms = 2000

            # Test all metrics work
            success = task_success_metric(example, pred)
            quality = quality_metric(example, pred)
            latency = latency_metric(example, pred)
            composite = composite_metric(example, pred)

            assert success == 1.0
            assert quality >= 0.5
            assert latency == 1.0
            assert composite >= 0.5
