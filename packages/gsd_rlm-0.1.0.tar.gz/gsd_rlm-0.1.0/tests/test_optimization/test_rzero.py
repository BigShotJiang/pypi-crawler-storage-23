"""
Tests for R-Zero challenger-solver self-refinement loops.

Covers ChallengerFeedback, RefinementResult, and RZeroLoop.
"""

import pytest
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Any

from gsd_rlm.optimization.rzero import (
    ChallengerFeedback,
    RefinementStatus,
    RefinementResult,
    RZeroLoop,
    RewardFunction,
    HAS_DSPY,
    _utc_now_iso,
)


class TestChallengerFeedback:
    """Tests for ChallengerFeedback dataclass."""

    def test_feedback_creation(self):
        """Test basic feedback creation with required fields."""
        feedback = ChallengerFeedback(
            critique="The solution is incomplete",
            alternative_approach="Try using a different algorithm",
        )

        assert feedback.critique == "The solution is incomplete"
        assert feedback.alternative_approach == "Try using a different algorithm"
        assert feedback.suggested_improvements == []
        assert feedback.confidence == 0.5
        assert feedback.timestamp is not None

    def test_feedback_creation_with_all_fields(self):
        """Test feedback creation with all fields populated."""
        feedback = ChallengerFeedback(
            critique="Solution has edge cases",
            alternative_approach="Add validation",
            suggested_improvements=["Check for null", "Handle empty input"],
            confidence=0.8,
            timestamp="2025-01-15T10:30:00+00:00",
        )

        assert feedback.critique == "Solution has edge cases"
        assert feedback.alternative_approach == "Add validation"
        assert feedback.suggested_improvements == [
            "Check for null",
            "Handle empty input",
        ]
        assert feedback.confidence == 0.8
        assert feedback.timestamp == "2025-01-15T10:30:00+00:00"

    def test_feedback_serialization(self):
        """Test to_dict() serialization."""
        feedback = ChallengerFeedback(
            critique="Test critique",
            alternative_approach="Test approach",
            suggested_improvements=["improvement1"],
            confidence=0.7,
        )

        data = feedback.to_dict()

        assert isinstance(data, dict)
        assert data["critique"] == "Test critique"
        assert data["alternative_approach"] == "Test approach"
        assert data["suggested_improvements"] == ["improvement1"]
        assert data["confidence"] == 0.7
        assert "timestamp" in data

    def test_feedback_from_dict(self):
        """Test from_dict() deserialization."""
        data = {
            "critique": "Dict critique",
            "alternative_approach": "Dict approach",
            "suggested_improvements": ["imp1", "imp2"],
            "confidence": 0.9,
            "timestamp": "2025-01-15T12:00:00+00:00",
        }

        feedback = ChallengerFeedback.from_dict(data)

        assert feedback.critique == "Dict critique"
        assert feedback.alternative_approach == "Dict approach"
        assert feedback.suggested_improvements == ["imp1", "imp2"]
        assert feedback.confidence == 0.9
        assert feedback.timestamp == "2025-01-15T12:00:00+00:00"

    def test_feedback_default_values(self):
        """Test that default values are correctly set."""
        feedback = ChallengerFeedback(
            critique="test",
            alternative_approach="test",
        )

        assert feedback.suggested_improvements == []
        assert feedback.confidence == 0.5
        assert feedback.timestamp is not None
        assert len(feedback.timestamp) > 0

    def test_feedback_confidence_clamped_high(self):
        """Test confidence is clamped to max 1.0."""
        feedback = ChallengerFeedback(
            critique="test",
            alternative_approach="test",
            confidence=1.5,
        )
        assert feedback.confidence == 1.0

    def test_feedback_confidence_clamped_low(self):
        """Test confidence is clamped to min 0.0."""
        feedback = ChallengerFeedback(
            critique="test",
            alternative_approach="test",
            confidence=-0.5,
        )
        assert feedback.confidence == 0.0

    def test_feedback_post_init_normalizes_none_values(self):
        """Test __post_init__ normalizes None values to defaults."""
        feedback = ChallengerFeedback(
            critique="test",
            alternative_approach="test",
            suggested_improvements=None,
        )
        assert feedback.suggested_improvements == []


class TestRefinementStatus:
    """Tests for RefinementStatus enum."""

    def test_status_values(self):
        """Test all status values exist."""
        assert RefinementStatus.IN_PROGRESS.value == "in_progress"
        assert RefinementStatus.THRESHOLD_MET.value == "threshold_met"
        assert RefinementStatus.MAX_ROUNDS_REACHED.value == "max_rounds_reached"
        assert RefinementStatus.ERROR.value == "error"

    def test_status_count(self):
        """Test that we have expected number of statuses."""
        assert len(list(RefinementStatus)) == 4


class TestRefinementResult:
    """Tests for RefinementResult dataclass."""

    def test_result_creation(self):
        """Test basic result creation."""
        result = RefinementResult(
            final_solution={"answer": 42},
            final_reward=0.95,
            status=RefinementStatus.THRESHOLD_MET,
            rounds_completed=2,
        )

        assert result.final_solution == {"answer": 42}
        assert result.final_reward == 0.95
        assert result.status == RefinementStatus.THRESHOLD_MET
        assert result.rounds_completed == 2
        assert result.improvement_history == []
        assert result.feedback_history == []
        assert result.error_message is None

    def test_result_improved_property_true(self):
        """Test improved property returns True when improvement occurred."""
        result = RefinementResult(
            final_solution="improved",
            final_reward=0.8,
            status=RefinementStatus.MAX_ROUNDS_REACHED,
            rounds_completed=3,
            improvement_history=[0.5, 0.6, 0.8],
        )

        assert result.improved is True

    def test_result_improved_property_false(self):
        """Test improved property returns False when no improvement."""
        result = RefinementResult(
            final_solution="not_improved",
            final_reward=0.4,
            status=RefinementStatus.MAX_ROUNDS_REACHED,
            rounds_completed=3,
            improvement_history=[0.5, 0.4, 0.4],
        )

        assert result.improved is False

    def test_result_improved_property_single_value(self):
        """Test improved property returns False with single value."""
        result = RefinementResult(
            final_solution="single",
            final_reward=0.5,
            status=RefinementStatus.THRESHOLD_MET,
            rounds_completed=1,
            improvement_history=[0.5],
        )

        assert result.improved is False

    def test_result_improved_property_empty_history(self):
        """Test improved property returns False with empty history."""
        result = RefinementResult(
            final_solution="empty",
            final_reward=0.0,
            status=RefinementStatus.ERROR,
            rounds_completed=0,
            improvement_history=[],
        )

        assert result.improved is False

    def test_result_serialization(self):
        """Test to_dict() serialization."""
        feedback = ChallengerFeedback(
            critique="test",
            alternative_approach="test",
        )
        result = RefinementResult(
            final_solution="solution",
            final_reward=0.9,
            status=RefinementStatus.THRESHOLD_MET,
            rounds_completed=2,
            improvement_history=[0.5, 0.9],
            feedback_history=[feedback],
        )

        data = result.to_dict()

        assert data["final_solution"] == "solution"
        assert data["final_reward"] == 0.9
        assert data["status"] == "threshold_met"
        assert data["rounds_completed"] == 2
        assert data["improvement_history"] == [0.5, 0.9]
        assert len(data["feedback_history"]) == 1
        assert data["error_message"] is None

    def test_result_from_dict(self):
        """Test from_dict() deserialization."""
        data = {
            "final_solution": {"result": "test"},
            "final_reward": 0.85,
            "status": "max_rounds_reached",
            "rounds_completed": 3,
            "improvement_history": [0.4, 0.6, 0.85],
            "feedback_history": [
                {
                    "critique": "c1",
                    "alternative_approach": "a1",
                    "suggested_improvements": [],
                    "confidence": 0.5,
                }
            ],
            "error_message": None,
        }

        result = RefinementResult.from_dict(data)

        assert result.final_solution == {"result": "test"}
        assert result.final_reward == 0.85
        assert result.status == RefinementStatus.MAX_ROUNDS_REACHED
        assert result.rounds_completed == 3
        assert result.improvement_history == [0.4, 0.6, 0.85]
        assert len(result.feedback_history) == 1
        assert result.feedback_history[0].critique == "c1"


class TestRZeroLoop:
    """Tests for RZeroLoop."""

    @pytest.fixture
    def mock_solver(self):
        """Create a mock solver that returns predictable results."""
        return MagicMock(return_value={"result": "solution", "reward": 0.7})

    @pytest.fixture
    def mock_async_solver(self):
        """Create an async mock solver."""

        async def solver(task, context="", hint=None):
            return {"result": "async_solution", "reward": 0.8}

        return solver

    @pytest.fixture
    def mock_challenger(self):
        """Create a mock challenger that returns feedback."""

        def challenger(solution, context, reward, round_num):
            return {
                "critique": "Could be better",
                "alternative_approach": "Try X",
                "improvements": ["Add error handling"],
                "confidence": 0.6,
            }

        return challenger

    @pytest.fixture
    def mock_async_challenger(self):
        """Create an async mock challenger."""

        async def challenger(solution, context, reward, round_num):
            return ChallengerFeedback(
                critique="Async critique",
                alternative_approach="Async approach",
                suggested_improvements=["Async improvement"],
            )

        return challenger

    @pytest.fixture
    def mock_reward_fn(self):
        """Create a mock reward function."""

        def reward_fn(input_data, prediction, context=""):
            if isinstance(prediction, dict):
                return prediction.get("reward", 0.5)
            return 0.5

        return reward_fn

    def test_loop_creation(self, mock_solver):
        """Test RZeroLoop initialization."""
        loop = RZeroLoop(
            solver=mock_solver,
            max_rounds=5,
            threshold=0.95,
        )

        assert loop.solver == mock_solver
        assert loop.challenger is None
        assert loop.max_rounds == 5
        assert loop.threshold == 0.95

    def test_loop_creation_defaults(self, mock_solver):
        """Test RZeroLoop with default values."""
        loop = RZeroLoop(solver=mock_solver)

        assert loop.max_rounds == RZeroLoop.DEFAULT_MAX_ROUNDS
        assert loop.threshold == RZeroLoop.DEFAULT_THRESHOLD

    @pytest.mark.asyncio
    async def test_execute_returns_result(self, mock_solver, mock_reward_fn):
        """Test that execute returns a RefinementResult."""
        loop = RZeroLoop(
            solver=mock_solver,
            reward_fn=mock_reward_fn,
            max_rounds=2,
        )

        result = await loop.execute(task="Test task")

        assert isinstance(result, RefinementResult)
        assert result.rounds_completed > 0
        assert result.status in [
            RefinementStatus.THRESHOLD_MET,
            RefinementStatus.MAX_ROUNDS_REACHED,
        ]

    @pytest.mark.asyncio
    async def test_stops_on_threshold_met(self, mock_solver, mock_challenger):
        """Test that loop stops when threshold is met."""

        # Create a reward function that returns high reward
        def high_reward(input_data, prediction, context=""):
            return 0.95

        loop = RZeroLoop(
            solver=mock_solver,
            challenger=mock_challenger,
            reward_fn=high_reward,
            threshold=0.9,
            max_rounds=10,
        )

        result = await loop.execute(task="Test task")

        assert result.status == RefinementStatus.THRESHOLD_MET
        assert result.rounds_completed == 1  # Should stop after first round

    @pytest.mark.asyncio
    async def test_stops_on_max_rounds(self, mock_solver, mock_challenger):
        """Test that loop stops when max rounds reached."""

        def low_reward(input_data, prediction, context=""):
            return 0.3  # Never reaches threshold

        loop = RZeroLoop(
            solver=mock_solver,
            challenger=mock_challenger,
            reward_fn=low_reward,
            threshold=0.9,
            max_rounds=3,
        )

        result = await loop.execute(task="Test task")

        assert result.status == RefinementStatus.MAX_ROUNDS_REACHED
        assert result.rounds_completed == 3

    @pytest.mark.asyncio
    async def test_tracks_improvement_history(self, mock_solver, mock_reward_fn):
        """Test that improvement history is tracked."""
        call_count = [0]

        def improving_reward(input_data, prediction, context=""):
            call_count[0] += 1
            return min(0.5 + call_count[0] * 0.1, 0.99)

        loop = RZeroLoop(
            solver=mock_solver,
            reward_fn=improving_reward,
            max_rounds=3,
        )

        result = await loop.execute(task="Test task")

        assert len(result.improvement_history) == result.rounds_completed
        # Check that rewards are being recorded
        assert all(r >= 0 for r in result.improvement_history)

    @pytest.mark.asyncio
    async def test_works_without_challenger(self, mock_solver, mock_reward_fn):
        """Test that loop works without a challenger."""
        loop = RZeroLoop(
            solver=mock_solver,
            challenger=None,  # No challenger
            reward_fn=mock_reward_fn,
            max_rounds=2,
        )

        result = await loop.execute(task="Test task")

        assert isinstance(result, RefinementResult)
        assert len(result.feedback_history) == 0  # No feedback recorded

    @pytest.mark.asyncio
    async def test_uses_challenger_feedback(
        self, mock_solver, mock_challenger, mock_reward_fn
    ):
        """Test that challenger feedback is collected."""
        loop = RZeroLoop(
            solver=mock_solver,
            challenger=mock_challenger,
            reward_fn=mock_reward_fn,
            max_rounds=2,
        )

        result = await loop.execute(task="Test task")

        # Should have feedback from each round except the last if threshold met
        if result.status == RefinementStatus.MAX_ROUNDS_REACHED:
            assert len(result.feedback_history) == 2

    @pytest.mark.asyncio
    async def test_async_solver(self, mock_async_solver, mock_reward_fn):
        """Test with async solver."""
        loop = RZeroLoop(
            solver=mock_async_solver,
            reward_fn=mock_reward_fn,
            max_rounds=2,
        )

        result = await loop.execute(task="Test task")

        assert isinstance(result, RefinementResult)
        assert result.final_solution is not None

    @pytest.mark.asyncio
    async def test_async_challenger(
        self, mock_solver, mock_async_challenger, mock_reward_fn
    ):
        """Test with async challenger."""
        loop = RZeroLoop(
            solver=mock_solver,
            challenger=mock_async_challenger,
            reward_fn=mock_reward_fn,
            max_rounds=2,
        )

        result = await loop.execute(task="Test task")

        assert isinstance(result, RefinementResult)
        # Check feedback was collected
        if result.feedback_history:
            assert isinstance(result.feedback_history[0], ChallengerFeedback)

    def test_default_reward_function(self, mock_solver):
        """Test the default reward function behavior."""
        loop = RZeroLoop(solver=mock_solver)

        # Test None prediction
        assert loop._default_reward("task", None, "") == 0.0

        # Test dict with reward key
        assert loop._default_reward("task", {"reward": 0.8}, "") == 0.8

        # Test dict without reward key
        assert loop._default_reward("task", {"other": "value"}, "") == 0.5

        # Test non-empty string
        assert loop._default_reward("task", "some solution", "") == 0.5


class TestRZeroLoopEdgeCases:
    """Tests for RZeroLoop edge cases and error handling."""

    @pytest.fixture
    def error_solver(self):
        """Create a solver that raises an error."""

        def solver(task, context="", hint=None):
            raise RuntimeError("Solver error")

        return solver

    @pytest.fixture
    def error_challenger(self):
        """Create a challenger that raises an error."""

        def challenger(solution, context, reward, round_num):
            raise RuntimeError("Challenger error")

        return challenger

    @pytest.fixture
    def returning_none_solver(self):
        """Create a solver that returns None."""
        return MagicMock(return_value=None)

    @pytest.fixture
    def improving_solver(self):
        """Create a solver that improves with hints."""
        call_count = [0]

        def solver(task, context="", hint=None):
            call_count[0] += 1
            # Improve based on call count
            reward = min(0.3 + call_count[0] * 0.3, 0.99)
            return {"result": f"solution_{call_count[0]}", "reward": reward}

        return solver

    @pytest.mark.asyncio
    async def test_handles_solver_error(self, error_solver):
        """Test that solver errors are handled gracefully."""
        loop = RZeroLoop(
            solver=error_solver,
            max_rounds=3,
        )

        result = await loop.execute(task="Test task")

        assert result.status == RefinementStatus.ERROR
        assert result.error_message == "Solver error"
        assert result.rounds_completed == 1

    @pytest.mark.asyncio
    async def test_handles_challenger_error(self, improving_solver, error_challenger):
        """Test that challenger errors don't break the loop."""

        def reward_fn(input_data, prediction, context=""):
            if isinstance(prediction, dict):
                return prediction.get("reward", 0.5)
            return 0.5

        loop = RZeroLoop(
            solver=improving_solver,
            challenger=error_challenger,
            reward_fn=reward_fn,
            max_rounds=3,
        )

        result = await loop.execute(task="Test task")

        # Loop should complete despite challenger errors
        assert result.status in [
            RefinementStatus.THRESHOLD_MET,
            RefinementStatus.MAX_ROUNDS_REACHED,
        ]
        # No feedback should be recorded (challenger failed)
        assert len(result.feedback_history) == 0

    @pytest.mark.asyncio
    async def test_handles_none_prediction(self, returning_none_solver):
        """Test handling of None predictions."""
        loop = RZeroLoop(
            solver=returning_none_solver,
            max_rounds=2,
        )

        result = await loop.execute(task="Test task")

        assert isinstance(result, RefinementResult)
        # Default reward for None is 0.0
        assert result.final_reward == 0.0

    @pytest.mark.asyncio
    async def test_returns_best_result_even_if_not_threshold(self):
        """Test that best result is returned even if threshold not met."""
        rewards = [0.3, 0.5, 0.4]  # Best is 0.5
        call_count = [0]

        def varying_solver(task, context="", hint=None):
            call_count[0] += 1
            idx = min(call_count[0] - 1, len(rewards) - 1)
            return {"result": f"solution_{idx}", "reward": rewards[idx]}

        def reward_fn(input_data, prediction, context=""):
            if isinstance(prediction, dict):
                return prediction.get("reward", 0.5)
            return 0.5

        loop = RZeroLoop(
            solver=varying_solver,
            reward_fn=reward_fn,
            max_rounds=3,
            threshold=0.9,  # Never reached
        )

        result = await loop.execute(task="Test task")

        assert result.status == RefinementStatus.MAX_ROUNDS_REACHED
        assert result.final_reward == 0.5  # Best reward found

    @pytest.mark.asyncio
    async def test_initial_hint_passed_to_solver(self):
        """Test that initial hint is passed to first solver call."""
        received_hints = []

        def hint_capturing_solver(task, context="", hint=None):
            received_hints.append(hint)
            return {"result": "done", "reward": 0.95}

        loop = RZeroLoop(
            solver=hint_capturing_solver,
            threshold=0.9,
        )

        await loop.execute(task="Test task", initial_hint="Start with this")

        assert received_hints[0] == "Start with this"

    @pytest.mark.asyncio
    async def test_context_passed_to_solver_and_challenger(self):
        """Test that context is passed correctly."""
        received_context = {"solver": [], "challenger": []}

        def context_solver(task, context="", hint=None):
            received_context["solver"].append(context)
            return {"result": "done", "reward": 0.6}

        def context_challenger(solution, context, reward, round_num):
            received_context["challenger"].append(context)
            return {
                "critique": "ok",
                "alternative_approach": "none",
                "improvements": [],
            }

        loop = RZeroLoop(
            solver=context_solver,
            challenger=context_challenger,
            max_rounds=2,
        )

        await loop.execute(task="Test task", context="Important context")

        assert all(c == "Important context" for c in received_context["solver"])
        assert all(c == "Important context" for c in received_context["challenger"])

    @pytest.mark.asyncio
    async def test_format_hint(self):
        """Test _format_hint method."""
        loop = RZeroLoop(solver=MagicMock())

        feedback = ChallengerFeedback(
            critique="Needs work",
            alternative_approach="Try this instead",
            suggested_improvements=["Fix X", "Add Y"],
        )

        hint = loop._format_hint(feedback)

        assert "Critique: Needs work" in hint
        assert "Alternative approach: Try this instead" in hint
        assert "Fix X" in hint
        assert "Add Y" in hint


class TestRZeroLoopDSPyIntegration:
    """Tests for DSPy integration in RZeroLoop."""

    @pytest.mark.skipif(not HAS_DSPY, reason="DSPy not installed")
    def test_challenger_signature_exists(self):
        """Test that ChallengerSignature is defined when DSPy is available."""
        from gsd_rlm.optimization.rzero import ChallengerSignature

        assert ChallengerSignature is not None

    def test_challenger_signature_none_without_dspy(self):
        """Test that ChallengerSignature is None when DSPy is not available."""
        with patch("gsd_rlm.optimization.rzero.HAS_DSPY", False):
            # Re-import to get the None value
            import importlib
            import gsd_rlm.optimization.rzero as rzero_module

            importlib.reload(rzero_module)

            # ChallengerSignature should be None
            assert rzero_module.ChallengerSignature is None

    @pytest.mark.asyncio
    async def test_dspy_module_solver(self):
        """Test with mock DSPy module as solver."""
        if not HAS_DSPY:
            pytest.skip("DSPy not installed")

        # Create a mock DSPy module
        mock_dspy_module = MagicMock()
        mock_dspy_module.return_value = {"result": "dspy_solution", "reward": 0.85}

        def reward_fn(input_data, prediction, context=""):
            if isinstance(prediction, dict):
                return prediction.get("reward", 0.5)
            return 0.5

        # Patch dspy.Module check
        with patch("gsd_rlm.optimization.rzero.HAS_DSPY", True):
            with patch("gsd_rlm.optimization.rzero.dspy") as mock_dspy:
                mock_dspy.Module = type(mock_dspy_module.__class__)

                loop = RZeroLoop(
                    solver=mock_dspy_module,
                    reward_fn=reward_fn,
                    max_rounds=2,
                )

                result = await loop.execute(task="Test task")

                assert isinstance(result, RefinementResult)


class TestUtilityFunctions:
    """Tests for utility functions."""

    def test_utc_now_iso_format(self):
        """Test _utc_now_iso returns valid ISO format."""
        result = _utc_now_iso()

        # Should be parseable as ISO format
        parsed = datetime.fromisoformat(result.replace("Z", "+00:00"))
        assert parsed is not None

        # Should be timezone-aware
        assert parsed.tzinfo is not None
