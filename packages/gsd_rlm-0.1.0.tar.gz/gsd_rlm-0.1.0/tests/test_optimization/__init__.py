"""Tests for optimization module."""
