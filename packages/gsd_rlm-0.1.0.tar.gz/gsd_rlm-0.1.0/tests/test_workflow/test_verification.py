"""
Tests for goal-backward verification.

Tests must-have validation for phase completion
(EXEC-10, EXEC-11, EXEC-12).
"""

import pytest
from pathlib import Path

from gsd_rlm.workflow.verification import (
    MustHaves,
    VerificationResult,
    verify_phase_completion,
    load_must_haves_from_plan,
    verify_artifact_exports,
    verify_key_link_pattern,
)


class TestMustHaves:
    """Tests for MustHaves dataclass."""

    def test_create_must_haves(self):
        """Test creating MustHaves instance."""
        must_haves = MustHaves(
            truths=["System does X"],
            artifacts=[{"path": "src/module.py", "provides": "Feature"}],
            key_links=[{"from": "src/a.py", "to": "src/b.py"}],
        )
        assert len(must_haves.truths) == 1
        assert len(must_haves.artifacts) == 1
        assert len(must_haves.key_links) == 1

    def test_empty_must_haves(self):
        """Test creating empty MustHaves."""
        must_haves = MustHaves()
        assert must_haves.truths == []
        assert must_haves.artifacts == []
        assert must_haves.key_links == []

    def test_from_dict(self):
        """Test creating MustHaves from dictionary."""
        data = {
            "truths": ["Truth 1", "Truth 2"],
            "artifacts": [{"path": "file.py"}],
            "key_links": [{"from": "a.py", "to": "b.py"}],
        }
        must_haves = MustHaves.from_dict(data)
        assert len(must_haves.truths) == 2
        assert len(must_haves.artifacts) == 1


class TestVerificationResult:
    """Tests for VerificationResult dataclass."""

    def test_passed_result(self):
        """Test creating passed verification result."""
        result = VerificationResult(
            passed=True,
            truths_checked=2,
            artifacts_found=3,
            artifacts_missing=0,
            key_links_valid=2,
            key_links_broken=0,
        )
        assert result.passed
        assert result.artifacts_missing == 0

    def test_failed_result(self):
        """Test creating failed verification result."""
        result = VerificationResult(
            passed=False,
            artifacts_missing=1,
            details=["Missing artifact: file.py"],
        )
        assert not result.passed
        assert "Missing artifact: file.py" in result.details

    def test_str_representation(self):
        """Test string representation of result."""
        result = VerificationResult(
            passed=True,
            truths_checked=2,
            artifacts_found=3,
            artifacts_missing=0,
            key_links_valid=1,
            key_links_broken=0,
        )
        s = str(result)
        assert "PASSED" in s
        assert "Truths: 2" in s
        assert "Artifacts: 3 found" in s

    def test_result_with_warnings(self):
        """Test result with warnings."""
        result = VerificationResult(
            passed=True,
            warnings=["Missing optional export"],
        )
        assert len(result.warnings) == 1


class TestVerifyPhaseCompletion:
    """Tests for verify_phase_completion function."""

    def test_verify_empty_must_haves(self, tmp_path: Path):
        """Test verification with empty must-haves."""
        must_haves = MustHaves()
        result = verify_phase_completion(tmp_path, must_haves)

        assert result.passed
        assert result.truths_checked == 0
        assert result.artifacts_found == 0
        assert result.artifacts_missing == 0

    def test_verify_artifact_found(self, tmp_path: Path):
        """Test verification when artifact exists."""
        # Create artifact
        artifact_path = tmp_path / "src" / "module.py"
        artifact_path.parent.mkdir(parents=True)
        artifact_path.write_text("def feature(): pass", encoding="utf-8")

        must_haves = MustHaves(
            artifacts=[{"path": "src/module.py", "provides": "Feature"}]
        )
        result = verify_phase_completion(tmp_path, must_haves)

        assert result.passed
        assert result.artifacts_found == 1
        assert result.artifacts_missing == 0

    def test_verify_artifact_missing(self, tmp_path: Path):
        """Test verification when artifact is missing."""
        must_haves = MustHaves(
            artifacts=[{"path": "src/missing.py", "provides": "Feature"}]
        )
        result = verify_phase_completion(tmp_path, must_haves)

        assert not result.passed
        assert result.artifacts_found == 0
        assert result.artifacts_missing == 1

    def test_verify_multiple_artifacts(self, tmp_path: Path):
        """Test verification with multiple artifacts."""
        # Create some artifacts
        (tmp_path / "file1.py").write_text("# File 1", encoding="utf-8")
        (tmp_path / "file2.py").write_text("# File 2", encoding="utf-8")

        must_haves = MustHaves(
            artifacts=[
                {"path": "file1.py", "provides": "Feature 1"},
                {"path": "file2.py", "provides": "Feature 2"},
                {"path": "file3.py", "provides": "Feature 3"},
            ]
        )
        result = verify_phase_completion(tmp_path, must_haves)

        assert not result.passed
        assert result.artifacts_found == 2
        assert result.artifacts_missing == 1

    def test_verify_artifact_exports(self, tmp_path: Path):
        """Test verification of artifact exports."""
        # Create artifact with exports
        artifact_path = tmp_path / "module.py"
        artifact_path.write_text(
            "class MyClass:\n    pass\n\ndef my_function():\n    pass",
            encoding="utf-8",
        )

        must_haves = MustHaves(
            artifacts=[
                {
                    "path": "module.py",
                    "provides": "Module",
                    "exports": ["MyClass", "my_function"],
                }
            ]
        )
        result = verify_phase_completion(tmp_path, must_haves)

        assert result.passed
        # Check that exports were verified
        assert any("Export found" in d for d in result.details)

    def test_verify_artifact_missing_export(self, tmp_path: Path):
        """Test verification when export is missing."""
        artifact_path = tmp_path / "module.py"
        artifact_path.write_text("class OtherClass:\n    pass", encoding="utf-8")

        must_haves = MustHaves(
            artifacts=[
                {
                    "path": "module.py",
                    "provides": "Module",
                    "exports": ["MyClass"],
                }
            ]
        )
        result = verify_phase_completion(tmp_path, must_haves)

        # Should still pass (artifact exists), but with warning
        assert result.passed
        assert len(result.warnings) > 0

    def test_verify_key_link_valid(self, tmp_path: Path):
        """Test verification of valid key link."""
        # Create source file with pattern
        source_path = tmp_path / "src" / "verification.py"
        source_path.parent.mkdir(parents=True)
        source_path.write_text(
            "import yaml\nresult = yaml.safe_load(content)",
            encoding="utf-8",
        )

        must_haves = MustHaves(
            key_links=[
                {
                    "from": "src/verification.py",
                    "to": "config",
                    "via": "reads config",
                    "pattern": r"yaml.*safe_load",
                }
            ]
        )
        result = verify_phase_completion(tmp_path, must_haves)

        assert result.passed
        assert result.key_links_valid == 1
        assert result.key_links_broken == 0

    def test_verify_key_link_broken_pattern(self, tmp_path: Path):
        """Test verification when key link pattern not found."""
        source_path = tmp_path / "src" / "module.py"
        source_path.parent.mkdir(parents=True)
        source_path.write_text("# No yaml here", encoding="utf-8")

        must_haves = MustHaves(
            key_links=[
                {
                    "from": "src/module.py",
                    "to": "config",
                    "pattern": r"yaml.*safe_load",
                }
            ]
        )
        result = verify_phase_completion(tmp_path, must_haves)

        assert not result.passed
        assert result.key_links_valid == 0
        assert result.key_links_broken == 1

    def test_verify_key_link_missing_file(self, tmp_path: Path):
        """Test verification when key link file missing."""
        must_haves = MustHaves(key_links=[{"from": "missing.py", "to": "target"}])
        result = verify_phase_completion(tmp_path, must_haves)

        assert not result.passed
        assert result.key_links_broken == 1

    def test_verify_truths_enumerated(self, tmp_path: Path):
        """Test that truths are enumerated in details."""
        must_haves = MustHaves(
            truths=[
                "System loads ROADMAP.md",
                "System tracks phase progression",
            ]
        )
        result = verify_phase_completion(tmp_path, must_haves)

        assert result.passed
        assert result.truths_checked == 2
        # Check that truths are in details
        assert any("Truth #1" in d for d in result.details)
        assert any("Truth #2" in d for d in result.details)

    def test_verify_artifact_missing_path(self, tmp_path: Path):
        """Test warning when artifact missing path field."""
        must_haves = MustHaves(artifacts=[{"provides": "Feature"}])
        result = verify_phase_completion(tmp_path, must_haves)

        assert result.passed
        assert any("missing 'path'" in w for w in result.warnings)

    def test_verify_key_link_missing_from(self, tmp_path: Path):
        """Test warning when key link missing from field."""
        must_haves = MustHaves(key_links=[{"to": "target"}])
        result = verify_phase_completion(tmp_path, must_haves)

        assert result.passed
        assert any("missing 'from'" in w for w in result.warnings)


class TestLoadMustHavesFromPlan:
    """Tests for load_must_haves_from_plan function."""

    def test_load_from_plan(self, tmp_path: Path):
        """Test loading must-haves from PLAN.md."""
        plan_content = """---
phase: 05
plan: 04
must_haves:
  truths:
    - "System does X"
    - "System does Y"
  artifacts:
    - path: "src/module.py"
      provides: "Feature"
  key_links:
    - from: "src/a.py"
      to: "src/b.py"
---

# Plan
"""
        plan_path = tmp_path / "PLAN.md"
        plan_path.write_text(plan_content, encoding="utf-8")

        must_haves = load_must_haves_from_plan(plan_path)

        assert must_haves is not None
        assert len(must_haves.truths) == 2
        assert len(must_haves.artifacts) == 1
        assert len(must_haves.key_links) == 1

    def test_load_from_plan_no_frontmatter(self, tmp_path: Path):
        """Test loading from plan without frontmatter."""
        plan_path = tmp_path / "PLAN.md"
        plan_path.write_text("# Plan\n\nNo frontmatter", encoding="utf-8")

        must_haves = load_must_haves_from_plan(plan_path)
        assert must_haves is None

    def test_load_from_plan_no_must_haves(self, tmp_path: Path):
        """Test loading from plan without must_haves section."""
        plan_content = """---
phase: 05
plan: 04
---

# Plan
"""
        plan_path = tmp_path / "PLAN.md"
        plan_path.write_text(plan_content, encoding="utf-8")

        must_haves = load_must_haves_from_plan(plan_path)
        assert must_haves is None

    def test_load_from_nonexistent_file(self, tmp_path: Path):
        """Test loading from non-existent file."""
        must_haves = load_must_haves_from_plan(tmp_path / "missing.md")
        assert must_haves is None

    def test_load_from_invalid_yaml(self, tmp_path: Path):
        """Test loading from file with invalid YAML."""
        plan_content = """---
invalid: yaml: content:
---

# Plan
"""
        plan_path = tmp_path / "PLAN.md"
        plan_path.write_text(plan_content, encoding="utf-8")

        must_haves = load_must_haves_from_plan(plan_path)
        assert must_haves is None


class TestVerifyArtifactExports:
    """Tests for verify_artifact_exports function."""

    def test_verify_exports_all_found(self, tmp_path: Path):
        """Test when all exports are found."""
        artifact_path = tmp_path / "module.py"
        artifact_path.write_text(
            "class MyClass:\n    pass\n\ndef my_func():\n    pass",
            encoding="utf-8",
        )

        found, missing = verify_artifact_exports(artifact_path, ["MyClass", "my_func"])

        assert found
        assert missing == []

    def test_verify_exports_some_missing(self, tmp_path: Path):
        """Test when some exports are missing."""
        artifact_path = tmp_path / "module.py"
        artifact_path.write_text("class MyClass:\n    pass", encoding="utf-8")

        found, missing = verify_artifact_exports(
            artifact_path, ["MyClass", "MissingClass"]
        )

        assert not found
        assert "MissingClass" in missing

    def test_verify_exports_file_missing(self, tmp_path: Path):
        """Test when artifact file doesn't exist."""
        found, missing = verify_artifact_exports(tmp_path / "missing.py", ["MyClass"])

        assert not found
        assert missing == ["MyClass"]

    def test_verify_exports_async_function(self, tmp_path: Path):
        """Test detecting async function exports."""
        artifact_path = tmp_path / "module.py"
        artifact_path.write_text("async def async_func():\n    pass", encoding="utf-8")

        found, missing = verify_artifact_exports(artifact_path, ["async_func"])

        assert found

    def test_verify_exports_variable(self, tmp_path: Path):
        """Test detecting variable exports."""
        artifact_path = tmp_path / "module.py"
        artifact_path.write_text("MY_CONSTANT = 42", encoding="utf-8")

        found, missing = verify_artifact_exports(artifact_path, ["MY_CONSTANT"])

        assert found


class TestVerifyKeyLinkPattern:
    """Tests for verify_key_link_pattern function."""

    def test_pattern_found(self, tmp_path: Path):
        """Test when pattern is found."""
        source_path = tmp_path / "module.py"
        source_path.write_text("import yaml\nyaml.safe_load(data)", encoding="utf-8")

        result = verify_key_link_pattern(source_path, r"yaml.*safe_load")
        assert result

    def test_pattern_not_found(self, tmp_path: Path):
        """Test when pattern is not found."""
        source_path = tmp_path / "module.py"
        source_path.write_text("# No imports", encoding="utf-8")

        result = verify_key_link_pattern(source_path, r"yaml.*safe_load")
        assert not result

    def test_file_missing(self, tmp_path: Path):
        """Test when file doesn't exist."""
        result = verify_key_link_pattern(tmp_path / "missing.py", r"pattern")
        assert not result

    def test_invalid_regex(self, tmp_path: Path):
        """Test with invalid regex pattern."""
        source_path = tmp_path / "module.py"
        source_path.write_text("content", encoding="utf-8")

        # Invalid regex should return False
        result = verify_key_link_pattern(source_path, r"[invalid")
        assert not result


class TestVerificationIntegration:
    """Integration tests for verification."""

    def test_full_verification_pass(self, tmp_path: Path):
        """Test full verification that passes."""
        # Create artifacts
        spec_loader = tmp_path / "src" / "workflow" / "spec_loader.py"
        spec_loader.parent.mkdir(parents=True)
        spec_loader.write_text(
            "class SpecLoader:\n    pass\n\ndef load_roadmap():\n    pass",
            encoding="utf-8",
        )

        verification = tmp_path / "src" / "workflow" / "verification.py"
        verification.write_text(
            "import yaml\nresult = yaml.safe_load(content)",
            encoding="utf-8",
        )

        must_haves = MustHaves(
            truths=[
                "System loads ROADMAP.md and REQUIREMENTS.md",
                "System tracks phase progression",
            ],
            artifacts=[
                {
                    "path": "src/workflow/spec_loader.py",
                    "provides": "Spec loading",
                    "exports": ["SpecLoader", "load_roadmap"],
                }
            ],
            key_links=[
                {
                    "from": "src/workflow/verification.py",
                    "to": "PLAN.md",
                    "via": "reads must_haves",
                    "pattern": r"yaml.*safe_load",
                }
            ],
        )

        result = verify_phase_completion(tmp_path, must_haves)

        assert result.passed
        assert result.truths_checked == 2
        assert result.artifacts_found == 1
        assert result.key_links_valid == 1

    def test_full_verification_fail_missing_artifact(self, tmp_path: Path):
        """Test full verification that fails due to missing artifact."""
        must_haves = MustHaves(
            artifacts=[{"path": "src/missing.py", "provides": "Missing feature"}],
        )

        result = verify_phase_completion(tmp_path, must_haves)

        assert not result.passed
        assert result.artifacts_missing == 1
