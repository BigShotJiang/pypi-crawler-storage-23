"""
Tests for skill discovery and registry.

This module contains comprehensive tests for:
- discover_skills function
- SkillRegistry class
- Edge case handling (missing dir, invalid files, duplicates)

Run with: pytest tests/test_skills/test_discovery.py -v
"""

import pytest
from pathlib import Path
from unittest.mock import patch
import logging

from gsd_rlm.skills.discovery import (
    discover_skills,
    SkillRegistry,
    get_skill_registry,
)
from gsd_rlm.skills.base import SkillDefinition


class TestDiscoverSkills:
    """Tests for discover_skills function."""

    def test_discover_single_skill(self, tmp_path):
        """Discover a single SKILL.md file."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        skill_file = skill_dir / "SKILL.md"
        skill_file.write_text(
            """---
name: test-skill
description: A test skill
---

Content here.
""",
            encoding="utf-8",
        )

        skills = discover_skills(skill_dir)

        assert len(skills) == 1
        assert skills[0].name == "test-skill"

    def test_discover_nested_skills(self, tmp_path):
        """Discover SKILL.md files in nested directories."""
        # Create nested structure
        skill_dir = tmp_path / "skills"
        planner_dir = skill_dir / "planner"
        executor_dir = skill_dir / "executor"
        planner_dir.mkdir(parents=True)
        executor_dir.mkdir(parents=True)

        # Create skills in different directories
        (planner_dir / "SKILL.md").write_text(
            """---
name: planner-skill
description: Planning skill
---

Planner content.
""",
            encoding="utf-8",
        )
        (executor_dir / "SKILL.md").write_text(
            """---
name: executor-skill
description: Execution skill
---

Executor content.
""",
            encoding="utf-8",
        )

        skills = discover_skills(skill_dir)

        assert len(skills) == 2
        names = {s.name for s in skills}
        assert "planner-skill" in names
        assert "executor-skill" in names

    def test_discover_deeply_nested(self, tmp_path):
        """Discover SKILL.md files in deeply nested directories."""
        skill_dir = tmp_path / "skills"
        deep_dir = skill_dir / "a" / "b" / "c" / "d"
        deep_dir.mkdir(parents=True)

        (deep_dir / "SKILL.md").write_text(
            """---
name: deep-skill
description: Deeply nested skill
---

Content.
""",
            encoding="utf-8",
        )

        skills = discover_skills(skill_dir)

        assert len(skills) == 1
        assert skills[0].name == "deep-skill"

    def test_discover_missing_directory(self, tmp_path):
        """Missing directory should return empty list."""
        missing_dir = tmp_path / "nonexistent"
        skills = discover_skills(missing_dir)
        assert skills == []

    def test_discover_empty_directory(self, tmp_path):
        """Empty directory should return empty list."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        skills = discover_skills(empty_dir)
        assert skills == []

    def test_discover_invalid_skill_skipped(self, tmp_path, caplog):
        """Invalid SKILL.md files should be skipped with warning."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()

        # Valid skill
        (skill_dir / "SKILL.md").write_text(
            """---
name: valid-skill
description: Valid skill
---

Content.
""",
            encoding="utf-8",
        )

        # Invalid skill (missing frontmatter)
        (skill_dir / "invalid").mkdir()
        (skill_dir / "invalid" / "SKILL.md").write_text(
            "No frontmatter here",
            encoding="utf-8",
        )

        with caplog.at_level(logging.WARNING):
            skills = discover_skills(skill_dir)

        assert len(skills) == 1
        assert skills[0].name == "valid-skill"
        assert "Failed to load skill" in caplog.text

    def test_discover_empty_content_skipped(self, tmp_path, caplog):
        """Skills with empty content should be skipped."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()

        (skill_dir / "SKILL.md").write_text(
            """---
name: empty-skill
description: Empty skill
---

""",
            encoding="utf-8",
        )

        with caplog.at_level(logging.WARNING):
            skills = discover_skills(skill_dir)

        assert len(skills) == 0
        assert "empty content" in caplog.text.lower()

    def test_discover_no_skill_md_files(self, tmp_path):
        """Directory with other files but no SKILL.md should return empty."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "README.md").write_text("Not a skill", encoding="utf-8")
        (skill_dir / "config.yaml").write_text("key: value", encoding="utf-8")

        skills = discover_skills(skill_dir)
        assert skills == []


class TestSkillRegistry:
    """Tests for SkillRegistry class."""

    def test_registry_load(self, tmp_path):
        """Load skills into registry."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            """---
name: test-skill
description: Test skill
---

Content.
""",
            encoding="utf-8",
        )

        registry = SkillRegistry(skills_dir=skill_dir)
        count = registry.load()

        assert count == 1
        assert len(registry) == 1

    def test_registry_get(self, tmp_path):
        """Get skill by name."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            """---
name: my-skill
description: My skill
---

Content.
""",
            encoding="utf-8",
        )

        registry = SkillRegistry(skills_dir=skill_dir)
        registry.load()

        skill = registry.get("my-skill")
        assert skill is not None
        assert skill.name == "my-skill"

    def test_registry_get_not_found(self, tmp_path):
        """Get non-existent skill returns None."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()

        registry = SkillRegistry(skills_dir=skill_dir)
        registry.load()

        skill = registry.get("nonexistent")
        assert skill is None

    def test_registry_list(self, tmp_path):
        """List all skill names."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "a").mkdir()
        (skill_dir / "a" / "SKILL.md").write_text(
            """---
name: skill-a
description: Skill A
---

Content.
""",
            encoding="utf-8",
        )
        (skill_dir / "b").mkdir()
        (skill_dir / "b" / "SKILL.md").write_text(
            """---
name: skill-b
description: Skill B
---

Content.
""",
            encoding="utf-8",
        )

        registry = SkillRegistry(skills_dir=skill_dir)
        registry.load()

        names = registry.list()
        assert set(names) == {"skill-a", "skill-b"}

    def test_registry_reload(self, tmp_path):
        """Reload clears and reloads skills."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            """---
name: skill-1
description: First skill
---

Content.
""",
            encoding="utf-8",
        )

        registry = SkillRegistry(skills_dir=skill_dir)
        registry.load()
        assert len(registry) == 1

        # Add another skill
        (skill_dir / "new").mkdir()
        (skill_dir / "new" / "SKILL.md").write_text(
            """---
name: skill-2
description: Second skill
---

Content.
""",
            encoding="utf-8",
        )

        # Reload
        count = registry.reload()
        assert count == 2
        assert len(registry) == 2

    def test_registry_no_directory(self, caplog):
        """Registry without directory returns 0 on load."""
        registry = SkillRegistry()
        with caplog.at_level(logging.WARNING):
            count = registry.load()
        assert count == 0
        assert "No skills directory" in caplog.text

    def test_registry_missing_directory(self, tmp_path, caplog):
        """Registry with missing directory returns empty."""
        missing_dir = tmp_path / "nonexistent"
        registry = SkillRegistry(skills_dir=missing_dir)

        with caplog.at_level(logging.WARNING):
            count = registry.load()

        assert count == 0
        assert "not found" in caplog.text.lower()

    def test_registry_duplicate_names(self, tmp_path, caplog):
        """Duplicate skill names - last one wins."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "a").mkdir()
        (skill_dir / "a" / "SKILL.md").write_text(
            """---
name: duplicate
description: First duplicate
---

First content.
""",
            encoding="utf-8",
        )
        (skill_dir / "b").mkdir()
        (skill_dir / "b" / "SKILL.md").write_text(
            """---
name: duplicate
description: Second duplicate
---

Second content.
""",
            encoding="utf-8",
        )

        with caplog.at_level(logging.WARNING):
            registry = SkillRegistry(skills_dir=skill_dir)
            count = registry.load()

        assert count == 1
        skill = registry.get("duplicate")
        # Last one wins (order may vary, so just check it exists)
        assert skill is not None
        assert "Duplicate skill name" in caplog.text

    def test_registry_contains(self, tmp_path):
        """Check if skill is in registry using 'in' operator."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            """---
name: test-skill
description: Test
---

Content.
""",
            encoding="utf-8",
        )

        registry = SkillRegistry(skills_dir=skill_dir)
        registry.load()

        assert "test-skill" in registry
        assert "nonexistent" not in registry

    def test_registry_len(self, tmp_path):
        """Check registry length with len()."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            """---
name: test-skill
description: Test
---

Content.
""",
            encoding="utf-8",
        )

        registry = SkillRegistry(skills_dir=skill_dir)
        assert len(registry) == 0
        registry.load()
        assert len(registry) == 1


class TestGetSkillRegistry:
    """Tests for get_skill_registry function."""

    def test_get_skill_registry_uncached(self, tmp_path):
        """Get registry without cache."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            """---
name: test-skill
description: Test
---

Content.
""",
            encoding="utf-8",
        )

        registry = get_skill_registry(skill_dir, use_cache=False)
        assert len(registry) == 1
        assert registry.get("test-skill") is not None

    def test_get_skill_registry_cached(self, tmp_path):
        """Get registry with cache returns same instance."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            """---
name: cached-skill
description: Cached
---

Content.
""",
            encoding="utf-8",
        )

        # Clear the cache first
        get_skill_registry.__code__.co_freevars  # Just accessing to verify function exists

        registry1 = get_skill_registry(skill_dir, use_cache=True)
        registry2 = get_skill_registry(skill_dir, use_cache=True)

        # Both should have the skill
        assert len(registry1) == 1
        assert len(registry2) == 1


class TestSkillRegistryO1Lookup:
    """Tests for O(1) lookup requirement."""

    def test_o1_lookup_performance(self, tmp_path):
        """Verify O(1) lookup using dictionary."""
        skill_dir = tmp_path / "skills"
        skill_dir.mkdir()

        # Create multiple skills
        for i in range(100):
            skill_subdir = skill_dir / f"skill-{i}"
            skill_subdir.mkdir()
            (skill_subdir / "SKILL.md").write_text(
                f"""---
name: skill-{i}
description: Skill number {i}
---

Content for skill {i}.
""",
                encoding="utf-8",
            )

        registry = SkillRegistry(skills_dir=skill_dir)
        registry.load()

        # Lookups should be O(1) - dictionary access
        import time

        start = time.perf_counter()
        for i in range(100):
            _ = registry.get(f"skill-{i}")
        elapsed = time.perf_counter() - start

        # 100 lookups should be very fast (< 1ms total for dict access)
        assert elapsed < 0.01  # 10ms should be more than enough
        assert len(registry) == 100
