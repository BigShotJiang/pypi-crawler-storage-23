"""
Tests for skill base classes.

This module contains comprehensive tests for:
- SkillFrontmatter validation
- SkillDefinition loading from SKILL.md files
- Error handling for invalid skill files

Run with: pytest tests/test_skills/test_base.py -v
"""

import pytest
from pathlib import Path
from pydantic import ValidationError

from gsd_rlm.skills.base import SkillFrontmatter, SkillDefinition


class TestSkillFrontmatter:
    """Tests for SkillFrontmatter model."""

    def test_valid_frontmatter(self):
        """Valid frontmatter should parse correctly."""
        fm = SkillFrontmatter(
            name="test-skill",
            description="A test skill",
        )
        assert fm.name == "test-skill"
        assert fm.description == "A test skill"
        assert fm.tools == {}
        assert fm.color == "#00FFAA"

    def test_frontmatter_with_tools(self):
        """Frontmatter can include tool permissions."""
        fm = SkillFrontmatter(
            name="test-skill",
            description="A test skill",
            tools={"read": True, "write": True, "bash": False},
        )
        assert fm.tools["read"] is True
        assert fm.tools["write"] is True
        assert fm.tools["bash"] is False

    def test_frontmatter_with_custom_color(self):
        """Frontmatter can have custom display color."""
        fm = SkillFrontmatter(
            name="test-skill",
            description="A test skill",
            color="#FF5500",
        )
        assert fm.color == "#FF5500"

    def test_empty_name_rejected(self):
        """Empty name should fail validation."""
        with pytest.raises(ValidationError):
            SkillFrontmatter(name="", description="test")

    def test_whitespace_name_rejected(self):
        """Whitespace-only name should fail validation."""
        with pytest.raises(ValidationError):
            SkillFrontmatter(name="   ", description="test")

    def test_empty_description_rejected(self):
        """Empty description should fail validation."""
        with pytest.raises(ValidationError):
            SkillFrontmatter(name="test", description="")

    def test_whitespace_description_rejected(self):
        """Whitespace-only description should fail validation."""
        with pytest.raises(ValidationError):
            SkillFrontmatter(name="test", description="   ")

    def test_unknown_fields_rejected(self):
        """Unknown fields should cause validation error."""
        with pytest.raises(ValidationError):
            SkillFrontmatter(
                name="test",
                description="test",
                unknown_field="should fail",
            )

    def test_name_stripped(self):
        """Name should be stripped of leading/trailing whitespace."""
        fm = SkillFrontmatter(name="  test-skill  ", description="test")
        assert fm.name == "test-skill"

    def test_description_stripped(self):
        """Description should be stripped of leading/trailing whitespace."""
        fm = SkillFrontmatter(name="test", description="  A test skill  ")
        assert fm.description == "A test skill"


class TestSkillDefinition:
    """Tests for SkillDefinition class."""

    def test_from_file_valid(self, tmp_path):
        """Load valid SKILL.md file."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test-skill
description: A test skill for unit testing
tools:
  read: true
  write: true
color: "#00AAFF"
---

# Test Skill

This is the skill content.

<role>
You are a test assistant.
</role>
""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)

        assert skill.name == "test-skill"
        assert skill.description == "A test skill for unit testing"
        assert skill.tools["read"] is True
        assert skill.tools["write"] is True
        assert skill.frontmatter.color == "#00AAFF"
        assert "# Test Skill" in skill.content
        assert "You are a test assistant" in skill.content
        assert skill.path == skill_file

    def test_from_file_minimal(self, tmp_path):
        """Load SKILL.md with minimal frontmatter."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: minimal-skill
description: Minimal skill
---

Simple content here.
""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)

        assert skill.name == "minimal-skill"
        assert skill.description == "Minimal skill"
        assert skill.tools == {}
        assert "Simple content here." in skill.content

    def test_from_file_missing_frontmatter(self, tmp_path):
        """File without frontmatter should raise error."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            "# No Frontmatter\n\nThis file has no frontmatter.",
            encoding="utf-8",
        )

        with pytest.raises(ValueError) as exc_info:
            SkillDefinition.from_file(skill_file)
        assert "must start with YAML frontmatter" in str(exc_info.value)

    def test_from_file_unclosed_frontmatter(self, tmp_path):
        """File with unclosed frontmatter should raise error."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test
description: test

# Content""",
            encoding="utf-8",
        )

        with pytest.raises(ValueError) as exc_info:
            SkillDefinition.from_file(skill_file)
        assert "missing closing ---" in str(exc_info.value)

    def test_from_file_invalid_yaml(self, tmp_path):
        """File with invalid YAML should raise error."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: [invalid
description: test
---

Content""",
            encoding="utf-8",
        )

        with pytest.raises(Exception):  # YAML parse error
            SkillDefinition.from_file(skill_file)

    def test_from_file_missing_required_field(self, tmp_path):
        """File with missing required field should raise error."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test
---

Content""",
            encoding="utf-8",
        )

        with pytest.raises(ValidationError):
            SkillDefinition.from_file(skill_file)

    def test_from_file_not_found(self):
        """Non-existent file should raise FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            SkillDefinition.from_file(Path("nonexistent/SKILL.md"))

    def test_validate_method_valid(self, tmp_path):
        """validate() should return True for valid skill."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test
description: test
---

Valid content here.
""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)
        assert skill.validate() is True

    def test_validate_method_empty_content(self, tmp_path):
        """validate() should return False for empty content."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test
description: test
---

""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)
        assert skill.validate() is False

    def test_validate_method_whitespace_content(self, tmp_path):
        """validate() should return False for whitespace-only content."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test
description: test
---

   
   
""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)
        assert skill.validate() is False

    def test_name_property(self, tmp_path):
        """name property should return frontmatter name."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: my-skill
description: test
---

Content""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)
        assert skill.name == "my-skill"

    def test_description_property(self, tmp_path):
        """description property should return frontmatter description."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test
description: My skill description
---

Content""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)
        assert skill.description == "My skill description"

    def test_tools_property(self, tmp_path):
        """tools property should return frontmatter tools."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test
description: test
tools:
  read: true
  bash: false
---

Content""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)
        assert skill.tools == {"read": True, "bash": False}

    def test_has_tool_enabled(self, tmp_path):
        """has_tool should return True for enabled tools."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test
description: test
tools:
  read: true
  bash: false
---

Content""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)
        assert skill.has_tool("read") is True
        assert skill.has_tool("bash") is False
        assert skill.has_tool("write") is False  # Not specified

    def test_path_attribute(self, tmp_path):
        """path attribute should be set correctly."""
        skill_file = tmp_path / "SKILL.md"
        skill_file.write_text(
            """---
name: test
description: test
---

Content""",
            encoding="utf-8",
        )

        skill = SkillDefinition.from_file(skill_file)
        assert skill.path == skill_file
        assert skill.path.is_absolute()

    def test_multiline_content(self, tmp_path):
        """Should handle multiline content correctly."""
        skill_file = tmp_path / "SKILL.md"
        content = """---
name: test
description: test
---

# Header

Some paragraph.

## Section

- Item 1
- Item 2

```python
def example():
    pass
```
"""
        skill_file.write_text(content, encoding="utf-8")

        skill = SkillDefinition.from_file(skill_file)
        assert "# Header" in skill.content
        assert "## Section" in skill.content
        assert "def example():" in skill.content
