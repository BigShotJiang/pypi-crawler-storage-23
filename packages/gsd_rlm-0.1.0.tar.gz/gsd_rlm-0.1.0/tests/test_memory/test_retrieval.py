"""
Comprehensive tests for Memory Retrieval system (MEM-05, MEM-08).

Tests cover:
- HMEMRetrieval for semantic memory search
- MemoryStoreType enum and MemoryRoute dataclass
- MemoryRouter for query routing
- ContextAssembler for unified context assembly
"""

import os
import tempfile
from pathlib import Path
from typing import List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from gsd_rlm.memory.hmem import (
    Episode,
    EpisodeType,
    EpisodeStore,
    HMEMRetrieval,
    SearchResult,
)
from gsd_rlm.memory.bridge import (
    BridgeFact,
    BridgeLevel,
    MemoryBridge,
    MemoryStoreType,
    MemoryRoute,
    MemoryRouter,
)
from gsd_rlm.memory.integration import ContextAssembler
from gsd_rlm.memory.integration.context import AssembledContext


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def tmp_db_path(tmp_path: Path) -> str:
    """Provide a temporary database path for each test."""
    return str(tmp_path / "test_hmem.db")


@pytest.fixture
def tmp_project_root(tmp_path: Path) -> Path:
    """Provide a temporary project root for MemoryBridge."""
    return tmp_path / "project"


@pytest.fixture
def mock_embedding_model():
    """Provide a mock embedding model that returns fixed embeddings."""

    async def embed(text: str) -> List[float]:
        # Return a deterministic embedding based on text length
        base = [0.1, 0.2, 0.3, 0.4, 0.5]
        length_factor = min(len(text) / 100, 1.0)
        return [v * (1 + length_factor) for v in base]

    return embed


@pytest.fixture
def populated_episode_store(tmp_db_path: str) -> EpisodeStore:
    """Provide an EpisodeStore populated with test episodes."""
    store = EpisodeStore(tmp_db_path)

    episodes = [
        Episode(
            episode_id="ep-001",
            agent_id="agent-coder",
            session_id="sess-001",
            episode_type=EpisodeType.TASK_EXECUTION,
            context="User requested feature implementation",
            action="Created new API endpoint for user authentication",
            outcome="Successfully implemented JWT authentication",
            success=True,
            embedding=[0.1, 0.2, 0.3, 0.4, 0.5],
            tags=["api", "authentication", "jwt"],
        ),
        Episode(
            episode_id="ep-002",
            agent_id="agent-coder",
            session_id="sess-001",
            episode_type=EpisodeType.PROBLEM_SOLVING,
            context="API returning 500 errors",
            action="Debugged database connection issue",
            outcome="Fixed connection pool configuration",
            success=True,
            embedding=[0.2, 0.3, 0.4, 0.5, 0.6],
            tags=["debugging", "database", "connection"],
        ),
        Episode(
            episode_id="ep-003",
            agent_id="agent-planner",
            session_id="sess-002",
            episode_type=EpisodeType.LEARNING,
            context="Studied new framework documentation",
            action="Read through FastAPI best practices",
            outcome="Understood dependency injection patterns",
            success=True,
            embedding=[0.3, 0.4, 0.5, 0.6, 0.7],
            tags=["learning", "fastapi", "documentation"],
        ),
    ]

    for ep in episodes:
        store.store(ep)

    return store


@pytest.fixture
def mock_memory_bridge(tmp_project_root: Path) -> MemoryBridge:
    """Provide a MemoryBridge with test facts."""
    bridge = MemoryBridge(tmp_project_root)

    # Store some test facts
    fact1 = BridgeFact.create(
        level=BridgeLevel.L2_PROJECT,
        scope_id="project",
        key="python_version",
        value="3.12",
        source="user_input",
    )
    bridge.store_fact(fact1)

    fact2 = BridgeFact.create(
        level=BridgeLevel.L1_PHASE,
        scope_id="03-memory-systems",
        key="focus_area",
        value="memory_integration",
        source="planning",
    )
    bridge.store_fact(fact2)

    return bridge


# =============================================================================
# HMEMRetrieval Tests
# =============================================================================


class TestHMEMRetrievalInit:
    """Tests for HMEMRetrieval initialization."""

    def test_hmem_retrieval_init_default(self, tmp_db_path: str):
        """HMEMRetrieval should initialize with default parameters."""
        retrieval = HMEMRetrieval(db_path=tmp_db_path)

        assert retrieval.episode_store is None
        assert retrieval.embedding_model is None
        assert retrieval.embedding_cache == {}

    def test_hmem_retrieval_init_with_store(
        self, populated_episode_store: EpisodeStore, tmp_db_path: str
    ):
        """HMEMRetrieval should accept EpisodeStore."""
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        assert retrieval.episode_store is populated_episode_store

    def test_hmem_retrieval_init_with_embedding_model(
        self, mock_embedding_model, tmp_db_path: str
    ):
        """HMEMRetrieval should accept embedding model."""
        retrieval = HMEMRetrieval(
            embedding_model=mock_embedding_model, db_path=tmp_db_path
        )

        assert retrieval.embedding_model is mock_embedding_model


class TestHMEMRetrievalSearch:
    """Tests for HMEMRetrieval search functionality."""

    @pytest.mark.asyncio
    async def test_hmem_retrieval_search_episodes(
        self, populated_episode_store: EpisodeStore, tmp_db_path: str
    ):
        """HMEMRetrieval should search episodes and return results."""
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        results = await retrieval.search("authentication API", k=5, levels=["episode"])

        assert isinstance(results, list)
        # Should return results from populated store
        assert len(results) >= 0  # May have results depending on embeddings

    @pytest.mark.asyncio
    async def test_hmem_retrieval_search_traces(
        self, populated_episode_store: EpisodeStore, tmp_db_path: str
    ):
        """HMEMRetrieval should handle trace level search."""
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        # Should not error even if no traces exist
        results = await retrieval.search("work session", k=5, levels=["trace"])

        assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_hmem_retrieval_without_embedding(
        self, populated_episode_store: EpisodeStore, tmp_db_path: str
    ):
        """HMEMRetrieval should work without embedding model (keyword fallback)."""
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store,
            embedding_model=None,  # No embedding model
            db_path=tmp_db_path,
        )

        results = await retrieval.search("debugging", k=5)

        assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_hmem_retrieval_levels(
        self, populated_episode_store: EpisodeStore, tmp_db_path: str
    ):
        """HMEMRetrieval should respect levels parameter."""
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        # Search only episodes
        results_episode = await retrieval.search("test", k=5, levels=["episode"])
        assert isinstance(results_episode, list)

        # Search only traces
        results_trace = await retrieval.search("test", k=5, levels=["trace"])
        assert isinstance(results_trace, list)

        # Search both
        results_both = await retrieval.search("test", k=5, levels=["episode", "trace"])
        assert isinstance(results_both, list)

    @pytest.mark.asyncio
    async def test_hmem_retrieval_invalid_level(self, tmp_db_path: str):
        """HMEMRetrieval should raise error for invalid levels."""
        retrieval = HMEMRetrieval(db_path=tmp_db_path)

        with pytest.raises(ValueError, match="Invalid levels"):
            await retrieval.search("test", k=5, levels=["invalid_level"])

    @pytest.mark.asyncio
    async def test_hmem_retrieval_search_with_content(
        self, populated_episode_store: EpisodeStore, tmp_db_path: str
    ):
        """HMEMRetrieval.search_with_content should return SearchResult objects."""
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        results = await retrieval.search_with_content("authentication", k=5)

        assert isinstance(results, list)
        for result in results:
            assert isinstance(result, SearchResult)
            assert result.memory_id
            assert result.memory_type in ["episode", "trace"]
            assert result.similarity_score >= 0

    @pytest.mark.asyncio
    async def test_hmem_retrieval_clear_cache(self, tmp_db_path: str):
        """HMEMRetrieval.clear_cache should clear the embedding cache."""
        retrieval = HMEMRetrieval(db_path=tmp_db_path)
        retrieval.embedding_cache["test"] = [0.1, 0.2]

        retrieval.clear_cache()

        assert retrieval.embedding_cache == {}

    @pytest.mark.asyncio
    async def test_hmem_retrieval_with_mock_embedding(
        self,
        populated_episode_store: EpisodeStore,
        mock_embedding_model,
        tmp_db_path: str,
    ):
        """HMEMRetrieval should use embedding model when provided."""
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store,
            embedding_model=mock_embedding_model,
            db_path=tmp_db_path,
        )

        results = await retrieval.search("test query", k=5)

        assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_hmem_retrieval_empty_db(self, tmp_path: Path):
        """HMEMRetrieval should handle non-existent database gracefully."""
        retrieval = HMEMRetrieval(db_path=str(tmp_path / "nonexistent.db"))

        results = await retrieval.search("test", k=5)

        assert isinstance(results, list)
        assert len(results) == 0


class TestSearchResult:
    """Tests for SearchResult dataclass."""

    def test_search_result_creation(self):
        """SearchResult should be created with all fields."""
        result = SearchResult(
            memory_id="ep-001",
            similarity_score=0.95,
            memory_type="episode",
            content="Test content",
            metadata={"agent_id": "agent-1"},
        )

        assert result.memory_id == "ep-001"
        assert result.similarity_score == 0.95
        assert result.memory_type == "episode"
        assert result.content == "Test content"
        assert result.metadata == {"agent_id": "agent-1"}

    def test_search_result_to_dict(self):
        """SearchResult.to_dict should return proper dictionary."""
        result = SearchResult(
            memory_id="ep-001",
            similarity_score=0.95,
            memory_type="episode",
            content="Test content",
        )

        data = result.to_dict()

        assert data["memory_id"] == "ep-001"
        assert data["similarity_score"] == 0.95
        assert data["memory_type"] == "episode"


# =============================================================================
# MemoryStoreType Enum Tests
# =============================================================================


class TestMemoryStoreTypeEnum:
    """Tests for MemoryStoreType enum."""

    def test_memory_store_type_has_ten_values(self):
        """MemoryStoreType should have exactly 10 values."""
        types = list(MemoryStoreType)
        assert len(types) == 10

    def test_memory_store_type_values(self):
        """MemoryStoreType should have expected values."""
        assert MemoryStoreType.SESSION.value == "SESSION"
        assert MemoryStoreType.HMEM_EPISODE.value == "HMEM_EPISODE"
        assert MemoryStoreType.HMEM_TRACE.value == "HMEM_TRACE"
        assert MemoryStoreType.HMEM_CATEGORY.value == "HMEM_CATEGORY"
        assert MemoryStoreType.HMEM_DOMAIN.value == "HMEM_DOMAIN"
        assert MemoryStoreType.BRIDGE_L0.value == "BRIDGE_L0"
        assert MemoryStoreType.BRIDGE_L1.value == "BRIDGE_L1"
        assert MemoryStoreType.BRIDGE_L2.value == "BRIDGE_L2"
        assert MemoryStoreType.BRIDGE_L3.value == "BRIDGE_L3"
        assert MemoryStoreType.INFINIRETRI.value == "INFINIRETRI"

    def test_memory_store_type_description(self):
        """MemoryStoreType should have descriptions."""
        assert "conversation" in MemoryStoreType.SESSION.description.lower()
        assert "experiences" in MemoryStoreType.HMEM_EPISODE.description.lower()
        assert "sessions" in MemoryStoreType.HMEM_TRACE.description.lower()
        assert "project" in MemoryStoreType.BRIDGE_L2.description.lower()

    def test_memory_store_type_category(self):
        """MemoryStoreType should have categories."""
        assert MemoryStoreType.SESSION.category == "session"
        assert MemoryStoreType.HMEM_EPISODE.category == "hmem"
        assert MemoryStoreType.BRIDGE_L0.category == "bridge"
        assert MemoryStoreType.INFINIRETRI.category == "retrieval"


# =============================================================================
# MemoryRoute Tests
# =============================================================================


class TestMemoryRoute:
    """Tests for MemoryRoute dataclass."""

    def test_memory_route_creation(self):
        """MemoryRoute should be created with required fields."""
        route = MemoryRoute(
            store_type=MemoryStoreType.HMEM_EPISODE,
            relevance_score=0.85,
        )

        assert route.store_type == MemoryStoreType.HMEM_EPISODE
        assert route.relevance_score == 0.85
        assert route.query_embedding is None

    def test_memory_route_with_embedding(self):
        """MemoryRoute should accept optional embedding."""
        route = MemoryRoute(
            store_type=MemoryStoreType.SESSION,
            relevance_score=0.9,
            query_embedding=[0.1, 0.2, 0.3],
        )

        assert route.query_embedding == [0.1, 0.2, 0.3]

    def test_memory_route_to_dict(self):
        """MemoryRoute.to_dict should return proper dictionary."""
        route = MemoryRoute(
            store_type=MemoryStoreType.BRIDGE_L2,
            relevance_score=0.75,
        )

        data = route.to_dict()

        assert data["store_type"] == "BRIDGE_L2"
        assert data["relevance_score"] == 0.75


# =============================================================================
# MemoryRouter Tests
# =============================================================================


class TestMemoryRouterInit:
    """Tests for MemoryRouter initialization."""

    def test_memory_router_init_default(self):
        """MemoryRouter should initialize with default parameters."""
        router = MemoryRouter()

        assert router.embedding_model is None
        assert router._store_embeddings == {}
        assert router._initialized is False

    def test_memory_router_init_with_embedding_model(self, mock_embedding_model):
        """MemoryRouter should accept embedding model."""
        router = MemoryRouter(embedding_model=mock_embedding_model)

        assert router.embedding_model is mock_embedding_model

    def test_memory_router_has_store_descriptions(self):
        """MemoryRouter should have store descriptions."""
        router = MemoryRouter()

        assert len(router.STORE_DESCRIPTIONS) == 10
        assert MemoryStoreType.SESSION in router.STORE_DESCRIPTIONS


class TestMemoryRouterRouting:
    """Tests for MemoryRouter routing functionality."""

    @pytest.mark.asyncio
    async def test_memory_router_route(self):
        """MemoryRouter should route queries to stores."""
        router = MemoryRouter()

        routes = await router.route("fix the bug")

        assert isinstance(routes, list)
        assert len(routes) > 0
        for route in routes:
            assert isinstance(route, MemoryRoute)
            assert route.relevance_score >= 0

    @pytest.mark.asyncio
    async def test_memory_router_relevance_ranking(self):
        """MemoryRouter should rank stores by relevance."""
        router = MemoryRouter()

        routes = await router.route("debugging issue with code")

        # Routes should be sorted by relevance (descending)
        scores = [route.relevance_score for route in routes]
        assert scores == sorted(scores, reverse=True)

    @pytest.mark.asyncio
    async def test_memory_router_without_embedding(self):
        """MemoryRouter should work without embedding model (keyword fallback)."""
        router = MemoryRouter(embedding_model=None)

        routes = await router.route("session conversation")

        assert isinstance(routes, list)
        # SESSION should be relevant for "session" query
        store_types = [r.store_type for r in routes]
        assert MemoryStoreType.SESSION in store_types

    @pytest.mark.asyncio
    async def test_memory_router_available_stores(self):
        """MemoryRouter should respect available_stores parameter."""
        router = MemoryRouter()

        available = [MemoryStoreType.SESSION, MemoryStoreType.HMEM_EPISODE]
        routes = await router.route("test query", available_stores=available)

        for route in routes:
            assert route.store_type in available

    def test_memory_router_get_top_stores(self):
        """MemoryRouter.get_top_stores should return top store types."""
        router = MemoryRouter()

        routes = [
            MemoryRoute(MemoryStoreType.SESSION, 0.9),
            MemoryRoute(MemoryStoreType.HMEM_EPISODE, 0.8),
            MemoryRoute(MemoryStoreType.BRIDGE_L2, 0.7),
        ]

        top_stores = router.get_top_stores(routes, k=2)

        assert len(top_stores) == 2
        assert top_stores[0] == MemoryStoreType.SESSION
        assert top_stores[1] == MemoryStoreType.HMEM_EPISODE


# =============================================================================
# ContextAssembler Tests
# =============================================================================


class TestContextAssemblerInit:
    """Tests for ContextAssembler initialization."""

    def test_context_assembler_init_default(self):
        """ContextAssembler should initialize with default parameters."""
        assembler = ContextAssembler()

        assert assembler.session_memory is None
        assert assembler.episode_store is None
        assert assembler.memory_bridge is None
        assert assembler.memory_router is None
        assert assembler.hmem_retrieval is None

    def test_context_assembler_init_with_components(
        self,
        populated_episode_store: EpisodeStore,
        mock_memory_bridge: MemoryBridge,
        tmp_db_path: str,
    ):
        """ContextAssembler should accept all components."""
        router = MemoryRouter()
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        assembler = ContextAssembler(
            episode_store=populated_episode_store,
            memory_bridge=mock_memory_bridge,
            memory_router=router,
            hmem_retrieval=retrieval,
        )

        assert assembler.episode_store is populated_episode_store
        assert assembler.memory_bridge is mock_memory_bridge
        assert assembler.memory_router is router
        assert assembler.hmem_retrieval is retrieval


class TestContextAssemblerContext:
    """Tests for ContextAssembler context assembly."""

    @pytest.mark.asyncio
    async def test_context_assembler_get_context(
        self,
        populated_episode_store: EpisodeStore,
        mock_memory_bridge: MemoryBridge,
        tmp_db_path: str,
    ):
        """ContextAssembler should assemble context from multiple stores."""
        router = MemoryRouter()
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        assembler = ContextAssembler(
            episode_store=populated_episode_store,
            memory_bridge=mock_memory_bridge,
            memory_router=router,
            hmem_retrieval=retrieval,
        )

        context = await assembler.get_context_for_task(
            session_id="sess-001", task="implement authentication"
        )

        assert isinstance(context, AssembledContext)
        assert isinstance(context.routes_used, list)
        assert len(context.routes_used) > 0

    @pytest.mark.asyncio
    async def test_context_assembler_max_stores(
        self,
        populated_episode_store: EpisodeStore,
        tmp_db_path: str,
    ):
        """ContextAssembler should respect max_stores limit."""
        router = MemoryRouter()
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        assembler = ContextAssembler(
            episode_store=populated_episode_store,
            memory_router=router,
            hmem_retrieval=retrieval,
        )

        context = await assembler.get_context_for_task(
            session_id="sess-001", task="test task", max_stores=2
        )

        assert len(context.routes_used) <= 2

    @pytest.mark.asyncio
    async def test_context_assembler_to_dict(self):
        """AssembledContext.to_dict should return proper dictionary."""
        context = AssembledContext(
            session={"messages": ["test"]},
            recent_episodes=[{"action": "test"}],
            project_facts={"key": "value"},
        )

        data = context.to_dict()

        assert "session" in data
        assert "recent_episodes" in data
        assert "project_facts" in data
        assert data["session"]["messages"] == ["test"]

    def test_assembled_context_to_llm_context(self):
        """AssembledContext.to_llm_context should format for LLM."""
        context = AssembledContext(
            session={"messages": ["User asked for help"], "recent_tasks": []},
            recent_episodes=[
                {"action": "Fixed bug", "outcome": "Success", "success": True}
            ],
            project_facts={"python_version": "3.12"},
        )

        llm_context = context.to_llm_context()

        assert isinstance(llm_context, str)
        assert "Current Session" in llm_context
        assert "Recent Episodes" in llm_context
        assert "Project Facts" in llm_context

    def test_assembled_context_empty(self):
        """AssembledContext.to_llm_context should handle empty context."""
        context = AssembledContext()

        llm_context = context.to_llm_context()

        assert "No relevant context" in llm_context


# =============================================================================
# Integration Tests
# =============================================================================


class TestRetrievalIntegration:
    """End-to-end integration tests for retrieval system."""

    @pytest.mark.asyncio
    async def test_retrieval_integration(
        self,
        populated_episode_store: EpisodeStore,
        mock_memory_bridge: MemoryBridge,
        tmp_db_path: str,
    ):
        """Full integration test of retrieval flow."""
        # Create components
        router = MemoryRouter()
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )
        assembler = ContextAssembler(
            episode_store=populated_episode_store,
            memory_bridge=mock_memory_bridge,
            memory_router=router,
            hmem_retrieval=retrieval,
        )

        # Route query
        routes = await router.route("debug database connection issue")
        assert len(routes) > 0

        # Search H-MEM
        search_results = await retrieval.search("database connection", k=5)
        assert isinstance(search_results, list)

        # Assemble context
        context = await assembler.get_context_for_task(
            session_id="sess-001", task="debug database connection", max_stores=3
        )

        assert isinstance(context, AssembledContext)
        assert len(context.routes_used) <= 3

        # Convert to LLM context
        llm_context = context.to_llm_context()
        assert isinstance(llm_context, str)

    @pytest.mark.asyncio
    async def test_router_to_retrieval_flow(
        self, populated_episode_store: EpisodeStore, tmp_db_path: str
    ):
        """Test flow from router decision to retrieval execution."""
        router = MemoryRouter()
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        query = "fix authentication bug"

        # Get routing decision
        routes = await router.route(query)

        # Find H-MEM related routes
        hmem_routes = [
            r
            for r in routes
            if r.store_type
            in [
                MemoryStoreType.HMEM_EPISODE,
                MemoryStoreType.HMEM_TRACE,
            ]
        ]

        # Execute search if H-MEM is relevant
        if hmem_routes:
            results = await retrieval.search(query, k=5, levels=["episode", "trace"])
            assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_full_context_assembly_with_data(
        self,
        populated_episode_store: EpisodeStore,
        mock_memory_bridge: MemoryBridge,
        tmp_db_path: str,
    ):
        """Test context assembly with real data from all stores."""
        router = MemoryRouter()
        retrieval = HMEMRetrieval(
            episode_store=populated_episode_store, db_path=tmp_db_path
        )

        assembler = ContextAssembler(
            episode_store=populated_episode_store,
            memory_bridge=mock_memory_bridge,
            memory_router=router,
            hmem_retrieval=retrieval,
        )

        # Assemble context for a debugging task
        context = await assembler.get_context_for_task(
            session_id="sess-001", task="debug API connection issue", max_stores=5
        )

        # Verify context structure
        assert isinstance(context.session, dict)
        assert isinstance(context.recent_episodes, list)
        assert isinstance(context.project_facts, dict)
        assert isinstance(context.relevant_traces, list)
        assert isinstance(context.bridge_facts, dict)
        assert isinstance(context.routes_used, list)

        # Verify context can be serialized
        data = context.to_dict()
        assert isinstance(data, dict)

        # Verify LLM formatting works
        llm_context = context.to_llm_context()
        assert isinstance(llm_context, str)
        assert len(llm_context) > 0
