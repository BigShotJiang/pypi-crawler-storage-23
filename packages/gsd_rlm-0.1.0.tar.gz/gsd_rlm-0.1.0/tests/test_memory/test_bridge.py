"""
Comprehensive tests for Memory Bridge module (MEM-09).

Tests cover:
- BridgeFact dataclass creation and validation
- BridgeLevel enum
- BridgeFact serialization/deserialization
- MemoryBridge L0-L3 hierarchy
- Fact persistence at all levels
- Fact retrieval and search
- Fact deletion
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch
import os

import pytest

from gsd_rlm.memory.bridge import BridgeFact, BridgeLevel, MemoryBridge


# =================================================================
# Fixtures
# =================================================================


@pytest.fixture
def tmp_project_root(tmp_path: Path) -> Path:
    """Create a temporary project root with .planning directory."""
    project_root = tmp_path / "test_project"
    project_root.mkdir()
    planning_dir = project_root / ".planning"
    planning_dir.mkdir()
    (planning_dir / "sessions").mkdir()
    (planning_dir / "phases").mkdir()
    return project_root


@pytest.fixture
def tmp_workspace(tmp_path: Path) -> Path:
    """Create a temporary workspace directory for L3 facts."""
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    return workspace


@pytest.fixture
def memory_bridge(tmp_project_root: Path, tmp_workspace: Path) -> MemoryBridge:
    """Create a MemoryBridge with isolated directories."""
    return MemoryBridge(
        project_root=tmp_project_root,
        workspace_dir=tmp_workspace,
    )


@pytest.fixture
def sample_fact() -> BridgeFact:
    """Create a sample BridgeFact for testing."""
    return BridgeFact(
        fact_id="fact_test123",
        level=BridgeLevel.L1_PHASE,
        scope_id="03-memory-systems",
        key="python_version",
        value="3.12",
        source="user_input",
        confidence=0.95,
    )


@pytest.fixture
def sample_session_fact() -> BridgeFact:
    """Create a sample L0 session fact."""
    return BridgeFact.create(
        level=BridgeLevel.L0_SESSION,
        scope_id="session_abc123",
        key="current_task",
        value="implementing memory bridge",
        source="inferred",
    )


@pytest.fixture
def sample_project_fact() -> BridgeFact:
    """Create a sample L2 project fact."""
    return BridgeFact.create(
        level=BridgeLevel.L2_PROJECT,
        scope_id="project",
        key="project_name",
        value="GSD-RLM",
        source="config",
    )


@pytest.fixture
def sample_workspace_fact() -> BridgeFact:
    """Create a sample L3 workspace fact."""
    return BridgeFact.create(
        level=BridgeLevel.L3_WORKSPACE,
        scope_id="user_preferences",
        key="preferred_editor",
        value="vscode",
        source="user_input",
    )


# =================================================================
# BridgeLevel Tests
# =================================================================


class TestBridgeLevel:
    """Tests for BridgeLevel enum."""

    def test_all_levels_exist(self):
        """Verify all 4 levels are defined."""
        assert hasattr(BridgeLevel, "L0_SESSION")
        assert hasattr(BridgeLevel, "L1_PHASE")
        assert hasattr(BridgeLevel, "L2_PROJECT")
        assert hasattr(BridgeLevel, "L3_WORKSPACE")

    def test_level_values(self):
        """Verify level string values."""
        assert BridgeLevel.L0_SESSION.value == "L0_SESSION"
        assert BridgeLevel.L1_PHASE.value == "L1_PHASE"
        assert BridgeLevel.L2_PROJECT.value == "L2_PROJECT"
        assert BridgeLevel.L3_WORKSPACE.value == "L3_WORKSPACE"

    def test_level_priority(self):
        """Verify level priorities increase with scope."""
        assert BridgeLevel.L0_SESSION.priority == 0
        assert BridgeLevel.L1_PHASE.priority == 1
        assert BridgeLevel.L2_PROJECT.priority == 2
        assert BridgeLevel.L3_WORKSPACE.priority == 3

    def test_from_string_valid(self):
        """Verify string to enum conversion."""
        assert BridgeLevel.from_string("L0_SESSION") == BridgeLevel.L0_SESSION
        assert BridgeLevel.from_string("l1_phase") == BridgeLevel.L1_PHASE
        assert BridgeLevel.from_string("L2_PROJECT") == BridgeLevel.L2_PROJECT
        assert BridgeLevel.from_string("L3_WORKSPACE") == BridgeLevel.L3_WORKSPACE

    def test_from_string_invalid(self):
        """Verify invalid string raises ValueError."""
        with pytest.raises(ValueError, match="Invalid BridgeLevel"):
            BridgeLevel.from_string("INVALID_LEVEL")


# =================================================================
# BridgeFact Tests
# =================================================================


class TestBridgeFact:
    """Tests for BridgeFact dataclass."""

    def test_bridge_fact_creation(self, sample_fact: BridgeFact):
        """Verify all fields are set correctly."""
        assert sample_fact.fact_id == "fact_test123"
        assert sample_fact.level == BridgeLevel.L1_PHASE
        assert sample_fact.scope_id == "03-memory-systems"
        assert sample_fact.key == "python_version"
        assert sample_fact.value == "3.12"
        assert sample_fact.source == "user_input"
        assert sample_fact.confidence == 0.95
        assert sample_fact.ttl is None
        assert sample_fact.embedding is None

    def test_bridge_fact_default_values(self):
        """Verify default values are set correctly."""
        fact = BridgeFact(
            fact_id="test",
            level=BridgeLevel.L0_SESSION,
            scope_id="session",
            key="test_key",
            value="test_value",
        )
        assert fact.source == "unknown"
        assert fact.confidence == 1.0
        assert fact.ttl is None
        assert fact.embedding is None
        assert fact.created_at is not None

    def test_bridge_fact_confidence_validation(self):
        """Verify confidence must be between 0 and 1."""
        # Valid confidence values
        BridgeFact(
            fact_id="test",
            level=BridgeLevel.L0_SESSION,
            scope_id="session",
            key="test",
            value="val",
            confidence=0.0,
        )
        BridgeFact(
            fact_id="test",
            level=BridgeLevel.L0_SESSION,
            scope_id="session",
            key="test",
            value="val",
            confidence=1.0,
        )

        # Invalid confidence
        with pytest.raises(ValueError, match="Confidence must be between"):
            BridgeFact(
                fact_id="test",
                level=BridgeLevel.L0_SESSION,
                scope_id="session",
                key="test",
                value="val",
                confidence=1.5,
            )

    def test_bridge_fact_empty_validation(self):
        """Verify empty fact_id, key, scope_id are rejected."""
        with pytest.raises(ValueError, match="fact_id cannot be empty"):
            BridgeFact(
                fact_id="",
                level=BridgeLevel.L0_SESSION,
                scope_id="session",
                key="test",
                value="val",
            )

        with pytest.raises(ValueError, match="key cannot be empty"):
            BridgeFact(
                fact_id="test",
                level=BridgeLevel.L0_SESSION,
                scope_id="session",
                key="",
                value="val",
            )

        with pytest.raises(ValueError, match="scope_id cannot be empty"):
            BridgeFact(
                fact_id="test",
                level=BridgeLevel.L0_SESSION,
                scope_id="",
                key="test",
                value="val",
            )

    def test_bridge_fact_serialization(self, sample_fact: BridgeFact):
        """Verify to_dict and from_dict roundtrip."""
        data = sample_fact.to_dict()

        assert data["fact_id"] == "fact_test123"
        assert data["level"] == "L1_PHASE"
        assert data["scope_id"] == "03-memory-systems"
        assert data["key"] == "python_version"
        assert data["value"] == "3.12"

        # Roundtrip
        restored = BridgeFact.from_dict(data)
        assert restored.fact_id == sample_fact.fact_id
        assert restored.level == sample_fact.level
        assert restored.scope_id == sample_fact.scope_id
        assert restored.key == sample_fact.key
        assert restored.value == sample_fact.value

    def test_bridge_fact_create_factory(self):
        """Verify factory method creates valid facts."""
        fact = BridgeFact.create(
            level=BridgeLevel.L2_PROJECT,
            scope_id="my_project",
            key="setting",
            value={"nested": "dict"},
            source="config",
        )

        assert fact.fact_id.startswith("fact_")
        assert fact.level == BridgeLevel.L2_PROJECT
        assert fact.key == "setting"
        assert fact.value == {"nested": "dict"}

    def test_bridge_fact_is_expired(self):
        """Verify TTL expiration check."""
        # No TTL = never expired
        permanent_fact = BridgeFact(
            fact_id="test",
            level=BridgeLevel.L0_SESSION,
            scope_id="session",
            key="test",
            value="val",
            ttl=None,
        )
        assert not permanent_fact.is_expired()

        # Future TTL = not expired
        future_time = datetime.utcnow() + timedelta(hours=1)
        fresh_fact = BridgeFact(
            fact_id="test",
            level=BridgeLevel.L0_SESSION,
            scope_id="session",
            key="test",
            value="val",
            ttl=3600,  # 1 hour
            created_at=datetime.utcnow().isoformat(),
        )
        assert not fresh_fact.is_expired()

        # Past TTL = expired
        old_time = datetime.utcnow() - timedelta(hours=2)
        expired_fact = BridgeFact(
            fact_id="test",
            level=BridgeLevel.L0_SESSION,
            scope_id="session",
            key="test",
            value="val",
            ttl=3600,  # 1 hour TTL
            created_at=old_time.isoformat(),
        )
        assert expired_fact.is_expired()

    def test_bridge_fact_str_repr(self, sample_fact: BridgeFact):
        """Verify string representations."""
        str_repr = str(sample_fact)
        assert "python_version" in str_repr
        assert "3.12" in str_repr
        assert "L1_PHASE" in str_repr

        repr_str = repr(sample_fact)
        assert "fact_test123" in repr_str
        assert "python_version" in repr_str


# =================================================================
# MemoryBridge Tests
# =================================================================


class TestMemoryBridge:
    """Tests for MemoryBridge class."""

    def test_memory_bridge_init(self, tmp_project_root: Path, tmp_workspace: Path):
        """Verify MemoryBridge initializes correctly."""
        bridge = MemoryBridge(
            project_root=tmp_project_root,
            workspace_dir=tmp_workspace,
        )

        assert bridge.project_root == tmp_project_root
        assert bridge.planning_dir == tmp_project_root / ".planning"
        assert bridge.workspace_dir == tmp_workspace

        # Verify directories were created
        assert bridge.planning_dir.exists()
        assert (bridge.planning_dir / "sessions").exists()
        assert bridge.workspace_dir.exists()

    def test_store_session_fact(
        self,
        memory_bridge: MemoryBridge,
        sample_session_fact: BridgeFact,
    ):
        """Verify L0 session facts are stored correctly."""
        memory_bridge.store_fact(sample_session_fact)

        # Verify file was created
        session_file = (
            memory_bridge.planning_dir
            / "sessions"
            / f"{sample_session_fact.scope_id}.json"
        )
        assert session_file.exists()

        # Verify content
        data = json.loads(session_file.read_text())
        assert sample_session_fact.key in data
        assert data[sample_session_fact.key]["value"] == sample_session_fact.value

    def test_store_phase_fact(
        self,
        memory_bridge: MemoryBridge,
        sample_fact: BridgeFact,
    ):
        """Verify L1 phase facts are stored in FACTS.md."""
        memory_bridge.store_fact(sample_fact)

        # Verify file was created
        facts_file = (
            memory_bridge.planning_dir / "phases" / sample_fact.scope_id / "FACTS.md"
        )
        assert facts_file.exists()

        # Verify content
        content = facts_file.read_text()
        assert sample_fact.key in content
        assert "L1_PHASE" in content

    def test_store_project_fact(
        self,
        memory_bridge: MemoryBridge,
        sample_project_fact: BridgeFact,
    ):
        """Verify L2 project facts are stored correctly."""
        memory_bridge.store_fact(sample_project_fact)

        # Verify file was created
        facts_file = memory_bridge.planning_dir / "facts.json"
        assert facts_file.exists()

        # Verify content
        data = json.loads(facts_file.read_text())
        assert sample_project_fact.key in data

    def test_store_workspace_fact(
        self,
        memory_bridge: MemoryBridge,
        sample_workspace_fact: BridgeFact,
    ):
        """Verify L3 workspace facts are stored correctly."""
        memory_bridge.store_fact(sample_workspace_fact)

        # Verify file was created
        facts_file = memory_bridge.workspace_dir / "workspace_facts.json"
        assert facts_file.exists()

        # Verify content
        data = json.loads(facts_file.read_text())
        assert sample_workspace_fact.scope_id in data
        assert sample_workspace_fact.key in data[sample_workspace_fact.scope_id]

    def test_get_facts_by_level(
        self,
        memory_bridge: MemoryBridge,
        sample_fact: BridgeFact,
        sample_session_fact: BridgeFact,
    ):
        """Verify facts can be retrieved by level."""
        memory_bridge.store_fact(sample_fact)
        memory_bridge.store_fact(sample_session_fact)

        # Get phase facts
        phase_facts = memory_bridge.get_facts(
            BridgeLevel.L1_PHASE,
            sample_fact.scope_id,
        )
        assert sample_fact.key in phase_facts

        # Get session facts
        session_facts = memory_bridge.get_facts(
            BridgeLevel.L0_SESSION,
            sample_session_fact.scope_id,
        )
        assert sample_session_fact.key in session_facts

    def test_get_facts_with_key_filter(
        self,
        memory_bridge: MemoryBridge,
        sample_fact: BridgeFact,
    ):
        """Verify key filtering works."""
        # Store two facts
        fact1 = BridgeFact.create(
            level=BridgeLevel.L1_PHASE,
            scope_id=sample_fact.scope_id,
            key="fact1",
            value="value1",
        )
        fact2 = BridgeFact.create(
            level=BridgeLevel.L1_PHASE,
            scope_id=sample_fact.scope_id,
            key="fact2",
            value="value2",
        )
        memory_bridge.store_fact(fact1)
        memory_bridge.store_fact(fact2)

        # Get only fact1
        facts = memory_bridge.get_facts(
            BridgeLevel.L1_PHASE,
            sample_fact.scope_id,
            keys=["fact1"],
        )
        assert len(facts) == 1
        assert "fact1" in facts
        assert "fact2" not in facts

    def test_fact_persistence(self, tmp_project_root: Path, tmp_workspace: Path):
        """Verify facts persist across bridge recreation."""
        # Create and store fact
        bridge1 = MemoryBridge(
            project_root=tmp_project_root,
            workspace_dir=tmp_workspace,
        )
        fact = BridgeFact.create(
            level=BridgeLevel.L2_PROJECT,
            scope_id="project",
            key="persistent_key",
            value="persistent_value",
        )
        bridge1.store_fact(fact)

        # Create new bridge and retrieve
        bridge2 = MemoryBridge(
            project_root=tmp_project_root,
            workspace_dir=tmp_workspace,
        )
        facts = bridge2.get_facts(BridgeLevel.L2_PROJECT, "project")

        assert "persistent_key" in facts
        assert facts["persistent_key"].value == "persistent_value"

    def test_fact_overwrite(
        self,
        memory_bridge: MemoryBridge,
        sample_fact: BridgeFact,
    ):
        """Verify same key overwrites previous value."""
        # Store initial fact
        fact1 = BridgeFact.create(
            level=sample_fact.level,
            scope_id=sample_fact.scope_id,
            key="overwrite_test",
            value="initial_value",
        )
        memory_bridge.store_fact(fact1)

        # Store with same key, different value
        fact2 = BridgeFact.create(
            level=sample_fact.level,
            scope_id=sample_fact.scope_id,
            key="overwrite_test",
            value="new_value",
        )
        memory_bridge.store_fact(fact2)

        # Retrieve and verify
        facts = memory_bridge.get_facts(sample_fact.level, sample_fact.scope_id)
        assert len([k for k in facts if k == "overwrite_test"]) == 1
        assert facts["overwrite_test"].value == "new_value"

    def test_fact_deletion(
        self,
        memory_bridge: MemoryBridge,
        sample_fact: BridgeFact,
    ):
        """Verify delete_fact removes fact."""
        memory_bridge.store_fact(sample_fact)

        # Verify stored
        facts = memory_bridge.get_facts(sample_fact.level, sample_fact.scope_id)
        assert sample_fact.key in facts

        # Delete
        result = memory_bridge.delete_fact(sample_fact.fact_id)
        assert result is True

        # Verify deleted
        facts = memory_bridge.get_facts(sample_fact.level, sample_fact.scope_id)
        assert sample_fact.key not in facts

    def test_delete_nonexistent_fact(self, memory_bridge: MemoryBridge):
        """Verify deleting non-existent fact returns False."""
        result = memory_bridge.delete_fact("nonexistent_fact_id")
        assert result is False

    def test_search_facts(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify fact search works."""
        # Store multiple facts
        facts = [
            BridgeFact.create(
                level=BridgeLevel.L1_PHASE,
                scope_id="phase1",
                key="python_version",
                value="3.11",
            ),
            BridgeFact.create(
                level=BridgeLevel.L1_PHASE,
                scope_id="phase1",
                key="node_version",
                value="18.0",
            ),
            BridgeFact.create(
                level=BridgeLevel.L2_PROJECT,
                scope_id="project",
                key="python_path",
                value="/usr/bin/python",
            ),
        ]

        for fact in facts:
            memory_bridge.store_fact(fact)

        # Search for python
        results = memory_bridge.search_facts("python")
        assert len(results) >= 2  # python_version and python_path

        # Verify results contain python facts
        keys = [f.key for f in results]
        assert any("python" in k for k in keys)

    def test_get_fact_by_id(
        self,
        memory_bridge: MemoryBridge,
        sample_fact: BridgeFact,
    ):
        """Verify get_fact_by_id retrieves correct fact."""
        memory_bridge.store_fact(sample_fact)

        retrieved = memory_bridge.get_fact_by_id(sample_fact.fact_id)
        assert retrieved is not None
        assert retrieved.fact_id == sample_fact.fact_id
        assert retrieved.key == sample_fact.key

    def test_expired_facts_not_returned(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify expired facts are filtered out."""
        # Create expired fact
        old_time = datetime.utcnow() - timedelta(hours=2)
        expired_fact = BridgeFact(
            fact_id="expired_fact",
            level=BridgeLevel.L1_PHASE,
            scope_id="test_phase",
            key="expired_key",
            value="expired_value",
            ttl=3600,  # 1 hour TTL
            created_at=old_time.isoformat(),
        )
        memory_bridge.store_fact(expired_fact)

        # Retrieve facts - should not include expired
        facts = memory_bridge.get_facts(BridgeLevel.L1_PHASE, "test_phase")
        assert "expired_key" not in facts

    def test_complex_value_serialization(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify complex values (dict, list) serialize correctly."""
        complex_fact = BridgeFact.create(
            level=BridgeLevel.L2_PROJECT,
            scope_id="project",
            key="config",
            value={
                "nested": {
                    "deeply": ["list", "of", "values"],
                },
                "number": 42,
                "boolean": True,
            },
        )
        memory_bridge.store_fact(complex_fact)

        # Retrieve and verify
        facts = memory_bridge.get_facts(BridgeLevel.L2_PROJECT, "project")
        assert "config" in facts
        assert facts["config"].value["nested"]["deeply"] == ["list", "of", "values"]
        assert facts["config"].value["number"] == 42


# =================================================================
# Integration Tests
# =================================================================


class TestMemoryBridgeIntegration:
    """Integration tests for MemoryBridge with real file system."""

    def test_full_lifecycle(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Test complete lifecycle: create, store, retrieve, delete."""
        # Create
        fact = BridgeFact.create(
            level=BridgeLevel.L1_PHASE,
            scope_id="integration_test",
            key="lifecycle_key",
            value="lifecycle_value",
            source="integration_test",
            confidence=0.8,
        )

        # Store
        memory_bridge.store_fact(fact)

        # Retrieve
        facts = memory_bridge.get_facts(BridgeLevel.L1_PHASE, "integration_test")
        assert "lifecycle_key" in facts
        retrieved = facts["lifecycle_key"]
        assert retrieved.value == "lifecycle_value"
        assert retrieved.source == "integration_test"
        assert retrieved.confidence == 0.8

        # Delete
        memory_bridge.delete_fact(retrieved.fact_id)

        # Verify deleted
        facts = memory_bridge.get_facts(BridgeLevel.L1_PHASE, "integration_test")
        assert "lifecycle_key" not in facts

    def test_multi_level_storage(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Test storing facts at all 4 levels."""
        facts = [
            BridgeFact.create(
                level=BridgeLevel.L0_SESSION,
                scope_id="session_1",
                key="temp_data",
                value="session_value",
            ),
            BridgeFact.create(
                level=BridgeLevel.L1_PHASE,
                scope_id="phase_1",
                key="phase_data",
                value="phase_value",
            ),
            BridgeFact.create(
                level=BridgeLevel.L2_PROJECT,
                scope_id="project",
                key="project_data",
                value="project_value",
            ),
            BridgeFact.create(
                level=BridgeLevel.L3_WORKSPACE,
                scope_id="workspace",
                key="workspace_data",
                value="workspace_value",
            ),
        ]

        for fact in facts:
            memory_bridge.store_fact(fact)

        # Verify all stored
        for fact in facts:
            retrieved = memory_bridge.get_facts(fact.level, fact.scope_id)
            assert fact.key in retrieved
            assert retrieved[fact.key].value == fact.value


# =================================================================
# Edge Case Tests for Improved Coverage
# =================================================================


class TestMemoryBridgeEdgeCases:
    """Edge case tests for improved coverage."""

    def test_search_with_level_filter(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify search respects level filter."""
        # Store at different levels
        fact1 = BridgeFact.create(
            level=BridgeLevel.L1_PHASE,
            scope_id="phase1",
            key="test_key",
            value="phase_value",
        )
        fact2 = BridgeFact.create(
            level=BridgeLevel.L2_PROJECT,
            scope_id="project",
            key="test_key",
            value="project_value",
        )
        memory_bridge.store_fact(fact1)
        memory_bridge.store_fact(fact2)

        # Search only L1
        results = memory_bridge.search_facts(
            "test_key",
            levels=[BridgeLevel.L1_PHASE],
        )
        assert len(results) == 1
        assert results[0].level == BridgeLevel.L1_PHASE

    def test_search_by_source(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify search matches source field."""
        fact = BridgeFact.create(
            level=BridgeLevel.L2_PROJECT,
            scope_id="project",
            key="unique_key_xyz",
            value="value",
            source="special_source_abc",
        )
        memory_bridge.store_fact(fact)

        results = memory_bridge.search_facts("special_source_abc")
        assert len(results) >= 1
        assert any(f.source == "special_source_abc" for f in results)

    def test_list_value_serialization(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify list values serialize correctly."""
        fact = BridgeFact.create(
            level=BridgeLevel.L2_PROJECT,
            scope_id="project",
            key="tags",
            value=["tag1", "tag2", "tag3"],
        )
        memory_bridge.store_fact(fact)

        facts = memory_bridge.get_facts(BridgeLevel.L2_PROJECT, "project")
        assert "tags" in facts
        assert facts["tags"].value == ["tag1", "tag2", "tag3"]

    def test_get_fact_by_id_not_found(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify get_fact_by_id returns None for non-existent fact."""
        result = memory_bridge.get_fact_by_id("nonexistent_id_xyz")
        assert result is None

    def test_corrupted_json_handling(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify corrupted JSON files are handled gracefully."""
        # Write invalid JSON
        facts_file = memory_bridge.planning_dir / "facts.json"
        facts_file.write_text("{ invalid json }")

        # Should return empty dict instead of crashing
        facts = memory_bridge.get_facts(BridgeLevel.L2_PROJECT, "project")
        assert facts == {}

    def test_empty_planning_dir(
        self,
        tmp_path: Path,
        tmp_workspace: Path,
    ):
        """Verify bridge works with empty planning directory."""
        project_root = tmp_path / "empty_project"
        project_root.mkdir()

        bridge = MemoryBridge(
            project_root=project_root,
            workspace_dir=tmp_workspace,
        )

        # Should not crash, just return empty
        facts = bridge.get_facts(BridgeLevel.L0_SESSION, "any_session")
        assert facts == {}

    def test_fact_with_embedding(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify facts with embeddings are stored correctly."""
        fact = BridgeFact.create(
            level=BridgeLevel.L2_PROJECT,
            scope_id="project",
            key="embedded_fact",
            value="has_embedding",
            embedding=[0.1, 0.2, 0.3, 0.4, 0.5],
        )
        memory_bridge.store_fact(fact)

        facts = memory_bridge.get_facts(BridgeLevel.L2_PROJECT, "project")
        assert "embedded_fact" in facts
        assert facts["embedded_fact"].embedding == [0.1, 0.2, 0.3, 0.4, 0.5]

    def test_delete_from_each_level(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify deletion works from all levels."""
        facts = [
            BridgeFact.create(
                level=BridgeLevel.L0_SESSION,
                scope_id="del_session",
                key="del_key",
                value="val",
            ),
            BridgeFact.create(
                level=BridgeLevel.L1_PHASE,
                scope_id="del_phase",
                key="del_key",
                value="val",
            ),
            BridgeFact.create(
                level=BridgeLevel.L2_PROJECT,
                scope_id="project",
                key="del_key_proj",
                value="val",
            ),
            BridgeFact.create(
                level=BridgeLevel.L3_WORKSPACE,
                scope_id="del_workspace",
                key="del_key",
                value="val",
            ),
        ]

        for fact in facts:
            memory_bridge.store_fact(fact)

        # Delete each one
        for fact in facts:
            result = memory_bridge.delete_fact(fact.fact_id)
            assert result is True

            # Verify deleted
            remaining = memory_bridge.get_facts(fact.level, fact.scope_id)
            assert fact.key not in remaining

    def test_search_empty_query(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify search with empty query matches all facts (empty string in string is always True)."""
        fact = BridgeFact.create(
            level=BridgeLevel.L2_PROJECT,
            scope_id="project",
            key="some_key",
            value="some_value",
        )
        memory_bridge.store_fact(fact)

        results = memory_bridge.search_facts("")
        # Empty query matches all facts ("" in any_string is True)
        assert len(results) >= 1

    def test_phase_fact_markdown_format(
        self,
        memory_bridge: MemoryBridge,
    ):
        """Verify L1 phase facts are stored in proper markdown format."""
        fact = BridgeFact.create(
            level=BridgeLevel.L1_PHASE,
            scope_id="md_test_phase",
            key="markdown_test",
            value="test_value",
        )
        memory_bridge.store_fact(fact)

        facts_file = (
            memory_bridge.planning_dir / "phases" / "md_test_phase" / "FACTS.md"
        )
        content = facts_file.read_text()

        # Verify markdown structure
        assert "# Phase Facts" in content
        assert "markdown_test" in content
        assert "```yaml" in content
        assert "```" in content
