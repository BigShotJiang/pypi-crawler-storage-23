import pytest
import tempfile
from pathlib import Path
from datetime import datetime

from gsd_rlm.session.memory import (
    FileSessionMemory,
    SessionState,
    SessionMessage,
    TaskOutput,
)
from gsd_rlm.session.persistence import (
    save_json,
    load_json,
    SessionFileManager,
)


@pytest.fixture
def temp_sessions_dir():
    """Create a temporary sessions directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


class TestSessionMessage:
    def test_message_creation(self):
        """Message should be created with required fields."""
        msg = SessionMessage(
            role="user",
            content="Hello",
            timestamp="2024-01-01T00:00:00",
        )
        assert msg.role == "user"
        assert msg.content == "Hello"
        assert msg.metadata == {}

    def test_message_serialization(self):
        """Message should serialize to/from dict."""
        msg = SessionMessage(
            role="agent",
            content="Response",
            timestamp="2024-01-01T00:00:00",
            metadata={"key": "value"},
        )

        data = msg.to_dict()
        restored = SessionMessage.from_dict(data)

        assert restored.role == msg.role
        assert restored.content == msg.content
        assert restored.metadata == msg.metadata


class TestTaskOutput:
    def test_task_output_creation(self):
        """TaskOutput should track success/failure."""
        success = TaskOutput(
            task="Test task",
            result="Done",
            success=True,
        )
        assert success.success is True

        failure = TaskOutput(
            task="Failed task",
            result=None,
            success=False,
            error="Something went wrong",
        )
        assert failure.success is False
        assert failure.error == "Something went wrong"


class TestSessionState:
    def test_session_creation(self):
        """Session should initialize correctly."""
        session = SessionState(
            session_id="test-123",
            agent_name="TestAgent",
            created_at="2024-01-01T00:00:00",
            updated_at="2024-01-01T00:00:00",
            messages=[],
            task_outputs=[],
        )
        assert session.session_id == "test-123"
        assert session.message_count == 0
        assert session.task_count == 0

    def test_session_serialization(self):
        """Session should serialize to/from dict."""
        session = SessionState(
            session_id="test",
            agent_name="Agent",
            created_at="2024-01-01",
            updated_at="2024-01-01",
            messages=[
                SessionMessage(role="user", content="Hi", timestamp="2024-01-01")
            ],
            task_outputs=[TaskOutput(task="Task", result="Done", success=True)],
        )

        data = session.to_dict()
        restored = SessionState.from_dict(data)

        assert restored.session_id == session.session_id
        assert len(restored.messages) == 1
        assert len(restored.task_outputs) == 1


class TestFileSessionMemory:
    def test_create_session(self, temp_sessions_dir):
        """Should create new session."""
        memory = FileSessionMemory(temp_sessions_dir)
        session = memory.create("test-session", "TestAgent")

        assert session.session_id == "test-session"
        assert session.agent_name == "TestAgent"
        assert session.message_count == 0

        # File should exist
        assert memory._session_file("test-session").exists()

    def test_load_session(self, temp_sessions_dir):
        """Should load existing session."""
        memory = FileSessionMemory(temp_sessions_dir)

        # Create and save
        session = memory.create("test", "Agent")
        memory.add_message(session, "user", "Hello")

        # Load fresh
        loaded = memory.load("test")
        assert loaded is not None
        assert loaded.message_count == 1
        assert loaded.messages[0].content == "Hello"

    def test_load_nonexistent(self, temp_sessions_dir):
        """Should return None for nonexistent session."""
        memory = FileSessionMemory(temp_sessions_dir)
        loaded = memory.load("nonexistent")
        assert loaded is None

    def test_add_message(self, temp_sessions_dir):
        """Should add message and persist."""
        memory = FileSessionMemory(temp_sessions_dir)
        session = memory.create("test", "Agent")

        memory.add_message(session, "user", "Hello")
        memory.add_message(session, "agent", "Hi there!")

        assert session.message_count == 2

        # Verify persistence
        loaded = memory.load("test")
        assert loaded.message_count == 2

    def test_get_context_for_llm(self, temp_sessions_dir):
        """Should return LLM-ready format."""
        memory = FileSessionMemory(temp_sessions_dir)
        session = memory.create("test", "Agent")

        memory.add_message(session, "user", "Hello")
        memory.add_message(session, "agent", "Hi!")

        context = memory.get_context_for_llm(session)
        assert len(context) == 2
        assert context[0] == {"role": "user", "content": "Hello"}
        assert context[1] == {"role": "agent", "content": "Hi!"}

    def test_list_sessions(self, temp_sessions_dir):
        """Should list all sessions."""
        memory = FileSessionMemory(temp_sessions_dir)

        memory.create("session-1", "Agent1")
        memory.create("session-2", "Agent2")

        sessions = memory.list_sessions()
        assert len(sessions) == 2

        session_ids = {s["session_id"] for s in sessions}
        assert "session-1" in session_ids
        assert "session-2" in session_ids

    def test_delete_session(self, temp_sessions_dir):
        """Should delete session."""
        memory = FileSessionMemory(temp_sessions_dir)
        memory.create("test", "Agent")

        assert memory.load("test") is not None
        assert memory.delete("test") is True
        assert memory.load("test") is None

    def test_get_or_create(self, temp_sessions_dir):
        """Should get existing or create new."""
        memory = FileSessionMemory(temp_sessions_dir)

        # Create new
        session1 = memory.get_or_create("test", "Agent")
        assert session1.session_id == "test"

        # Get existing
        session2 = memory.get_or_create("test", "DifferentAgent")
        assert session2.agent_name == "Agent"  # Original name preserved


class TestPersistence:
    def test_save_and_load_json(self, temp_sessions_dir):
        """Should save and load JSON."""
        data = {"key": "value", "number": 42}
        path = temp_sessions_dir / "test.json"

        save_json(data, path)
        loaded = load_json(path)

        assert loaded == data

    def test_load_nonexistent_returns_default(self, temp_sessions_dir):
        """Should return default for missing file."""
        path = temp_sessions_dir / "missing.json"
        result = load_json(path, default={"default": True})
        assert result == {"default": True}

    def test_session_file_manager(self, temp_sessions_dir):
        """SessionFileManager should work."""
        manager = SessionFileManager(temp_sessions_dir)
        manager.setup()

        assert manager.sessions_dir.exists()
        assert manager.exports_dir.exists()
