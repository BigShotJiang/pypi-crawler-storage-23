import pytest
import tempfile
from pathlib import Path

from gsd_rlm.tools.file_tools import (
    ReadFileTool,
    WriteFileTool,
    EditFileTool,
    GlobTool,
    GrepTool,
)


@pytest.fixture
def temp_project():
    """Create a temporary project directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        project = Path(tmpdir)

        # Create test files
        (project / "src").mkdir()
        (project / "src" / "main.py").write_text('def main():\n    print("hello")\n')
        (project / "src" / "utils.py").write_text(
            "# Utilities\n\ndef helper():\n    pass\n"
        )
        (project / "README.md").write_text("# Test Project\n")

        yield project


class TestReadFileTool:
    def test_read_existing_file(self, temp_project):
        """Read should return file contents with line numbers."""
        tool = ReadFileTool(temp_project)
        result = tool.run("README.md")

        assert "Test Project" in result
        assert "1:" in result  # Line numbers

    def test_read_nonexistent_file(self, temp_project):
        """Read should return error for missing file."""
        tool = ReadFileTool(temp_project)
        result = tool.run("nonexistent.txt")

        assert "Error" in result
        assert "not found" in result

    def test_read_outside_project_denied(self, temp_project):
        """Read should deny access outside project."""
        tool = ReadFileTool(temp_project)
        result = tool.run("../../../etc/passwd")

        assert "Error" in result


class TestWriteFileTool:
    def test_write_new_file(self, temp_project):
        """Write should create new file."""
        tool = WriteFileTool(temp_project)
        result = tool.run("new.txt|||Hello, World!")

        assert "Successfully wrote" in result
        assert (temp_project / "new.txt").read_text() == "Hello, World!"

    def test_write_creates_directories(self, temp_project):
        """Write should create parent directories."""
        tool = WriteFileTool(temp_project)
        result = tool.run("deep/nested/path.txt|||content")

        assert "Successfully wrote" in result
        assert (temp_project / "deep/nested/path.txt").exists()


class TestEditFileTool:
    def test_edit_exact_match(self, temp_project):
        """Edit should replace exact match."""
        tool = EditFileTool(temp_project)
        result = tool.run("README.md|||# Test Project|||# Updated Project")

        assert "Successfully edited" in result
        assert "Updated Project" in (temp_project / "README.md").read_text()

    def test_edit_no_match(self, temp_project):
        """Edit should report when old_string not found."""
        tool = EditFileTool(temp_project)
        result = tool.run("README.md|||Nonexistent|||New")

        assert "Error" in result
        assert "not found" in result

    def test_edit_multiple_matches_rejected(self, temp_project):
        """Edit should reject ambiguous matches."""
        # Create file with duplicates
        (temp_project / "dup.txt").write_text("foo\nbar\nfoo\n")

        tool = EditFileTool(temp_project)
        result = tool.run("dup.txt|||foo|||replaced")

        assert "Error" in result
        assert "2 times" in result


class TestGlobTool:
    def test_glob_find_python_files(self, temp_project):
        """Glob should find files by pattern."""
        tool = GlobTool(temp_project)
        result = tool.run("**/*.py")

        assert "main.py" in result
        assert "utils.py" in result

    def test_glob_no_matches(self, temp_project):
        """Glob should report no matches."""
        tool = GlobTool(temp_project)
        result = tool.run("**/*.nonexistent")

        assert "No files found" in result


class TestGrepTool:
    def test_grep_find_pattern(self, temp_project):
        """Grep should find pattern in files."""
        tool = GrepTool(temp_project)
        result = tool.run("def \\w+")

        assert "def main" in result or "def helper" in result

    def test_grep_no_matches(self, temp_project):
        """Grep should report no matches."""
        tool = GrepTool(temp_project)
        result = tool.run("nonexistent_pattern_xyz123")

        assert "No matches found" in result

    def test_grep_invalid_regex(self, temp_project):
        """Grep should report invalid regex."""
        tool = GrepTool(temp_project)
        result = tool.run("[invalid")

        assert "Error" in result
        assert "Invalid regex" in result
