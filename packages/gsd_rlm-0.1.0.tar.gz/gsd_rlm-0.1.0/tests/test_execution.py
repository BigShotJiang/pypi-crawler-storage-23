"""
Tests for execution components.

This module tests the sequential task runner, retry/fallback logic,
progress reporting, and input/output validation.

Requirements: AGENT-02, AGENT-06, AGENT-07, AGENT-08
"""

import pytest
from unittest.mock import Mock, MagicMock
from pathlib import Path
import tempfile
import os

from gsd_rlm.execution.runner import (
    SequentialTaskRunner,
    TaskResult,
    AgentMessage,
    MultiAgentRuntime,
)
from gsd_rlm.execution.retry import (
    RetryableAgent,
    RetryConfig,
    AgentExecutionError,
    FallbackExhaustedError,
    with_retry,
)
from gsd_rlm.execution.progress import ProgressReporter, ProgressStatus, ProgressEvent
from gsd_rlm.execution.validation import (
    validate_input,
    validate_output,
    ValidationError,
    ValidationRule,
    create_custom_validator,
)
from gsd_rlm.session.memory import FileSessionMemory


class TestSequentialTaskRunner:
    """Tests for SequentialTaskRunner."""

    def test_runner_initialization(self):
        """Runner should initialize with required dependencies."""
        runtime = Mock()
        session = Mock()
        runner = SequentialTaskRunner(runtime, session)
        assert runner.runtime == runtime
        assert runner.session == session

    def test_empty_tasks_returns_error(self):
        """Empty task list should return error result."""
        runtime = Mock()
        session = Mock()
        session.load.return_value = None
        session.create.return_value = Mock(messages=[], task_outputs=[])

        runner = SequentialTaskRunner(runtime, session)
        result = runner.run_tasks([], "test-session", ["agent1"])

        assert result.success is False
        assert "No tasks" in result.error

    def test_single_task_execution(self):
        """Single task should execute and return result."""
        with tempfile.TemporaryDirectory() as tmpdir:
            session_memory = FileSessionMemory(Path(tmpdir))
            runtime = MultiAgentRuntime(agents=[])

            runner = SequentialTaskRunner(runtime, session_memory)
            result = runner.run_tasks(["Hello, world!"], "test-session-1", ["agent1"])

            assert result.success is True
            assert result.task == "Hello, world!"

    def test_context_passing_between_tasks(self):
        """Tasks should receive context from previous tasks."""
        with tempfile.TemporaryDirectory() as tmpdir:
            session_memory = FileSessionMemory(Path(tmpdir))

            # Create agent that appends to content
            agent = Mock()
            agent.name = "test-agent"
            agent.process = lambda msg: [
                AgentMessage(
                    task_id=msg.task_id,
                    content=f"processed: {msg.content}",
                    history=msg.history,
                    routing=msg.routing,
                )
            ]

            runtime = MultiAgentRuntime(agents=[agent])
            runner = SequentialTaskRunner(runtime, session_memory)

            result = runner.run_tasks(["task1", "task2"], "test-session-2", ["agent1"])

            assert result.success is True
            # Second task should have context from first
            assert "processed:" in str(result.content)


class TestAgentMessage:
    """Tests for AgentMessage dataclass."""

    def test_message_creation(self):
        """Message should be created with all fields."""
        msg = AgentMessage(
            task_id="test-123",
            content="Hello",
            history=[{"role": "user", "content": "Hi"}],
            routing=["agent1", "agent2"],
        )
        assert msg.task_id == "test-123"
        assert msg.content == "Hello"
        assert len(msg.history) == 1
        assert len(msg.routing) == 2

    def test_message_defaults(self):
        """Message should have sensible defaults."""
        msg = AgentMessage(task_id="test", content="test")
        assert msg.history == []
        assert msg.routing == []
        assert msg.metadata == {}


class TestMultiAgentRuntime:
    """Tests for MultiAgentRuntime."""

    def test_empty_runtime(self):
        """Runtime with no agents should pass through message."""
        runtime = MultiAgentRuntime(agents=[])
        msg = AgentMessage(task_id="test", content="input")
        result = runtime.run(msg)
        assert result.content == "input"

    def test_runtime_with_agents(self):
        """Runtime should process through all agents."""
        agent = Mock()
        agent.process = lambda msg: [
            AgentMessage(
                task_id=msg.task_id,
                content="transformed",
                history=msg.history,
                routing=msg.routing,
            )
        ]

        runtime = MultiAgentRuntime(agents=[agent])
        msg = AgentMessage(task_id="test", content="input")
        result = runtime.run(msg)
        assert result.content == "transformed"


class TestRetryableAgent:
    """Tests for RetryableAgent."""

    def test_successful_execution_no_retry(self):
        """Successful execution should not trigger retry."""
        primary = Mock()
        primary.name = "primary"
        primary.process.return_value = [Mock(content="success")]

        retryable = RetryableAgent(primary, config=RetryConfig(max_attempts=1))
        result = retryable.execute(Mock())

        assert result is not None

    def test_fallback_on_primary_failure(self):
        """Fallback agent should be tried after primary fails."""
        primary = Mock()
        primary.name = "primary"
        primary.process.side_effect = Exception("primary failed")

        fallback = Mock()
        fallback.name = "fallback"
        fallback.process.return_value = [Mock(content="fallback success")]

        retryable = RetryableAgent(
            primary, fallback_agents=[fallback], config=RetryConfig(max_attempts=1)
        )

        result = retryable.execute(Mock())
        assert result is not None

    def test_all_agents_failed_raises_error(self):
        """Should raise FallbackExhaustedError when all agents fail."""
        primary = Mock()
        primary.name = "primary"
        primary.process.side_effect = Exception("failed")

        retryable = RetryableAgent(primary, config=RetryConfig(max_attempts=1))

        with pytest.raises(FallbackExhaustedError):
            retryable.execute(Mock())


class TestProgressReporter:
    """Tests for ProgressReporter."""

    def test_progress_events_tracked(self):
        """Progress events should be tracked."""
        reporter = ProgressReporter()
        reporter.starting("task1", "Starting task 1")
        reporter.completed("task1", "Done")

        history = reporter.get_history()
        assert len(history) == 2
        assert history[0].status == ProgressStatus.STARTING
        assert history[1].status == ProgressStatus.COMPLETED

    def test_callback_invoked(self):
        """Callback should be invoked on each event."""
        events = []

        def callback(event):
            events.append(event)

        reporter = ProgressReporter(callback=callback)
        reporter.starting("task1")

        assert len(events) == 1

    def test_summary_calculation(self):
        """Summary should calculate success rate."""
        reporter = ProgressReporter()
        reporter.starting("task1")
        reporter.completed("task1")
        reporter.starting("task2")
        reporter.failed("task2", "error")

        summary = reporter.get_summary()
        assert summary["completed"] == 1
        assert summary["failed"] == 1
        assert summary["success_rate"] == 0.5

    def test_all_status_types(self):
        """All status types should be reportable."""
        reporter = ProgressReporter()
        reporter.pending("t1")
        reporter.starting("t2")
        reporter.running("t3")
        reporter.completed("t4")
        reporter.failed("t5")
        reporter.retrying("t6")

        history = reporter.get_history()
        assert len(history) == 6
        assert history[0].status == ProgressStatus.PENDING
        assert history[1].status == ProgressStatus.STARTING
        assert history[2].status == ProgressStatus.RUNNING
        assert history[3].status == ProgressStatus.COMPLETED
        assert history[4].status == ProgressStatus.FAILED
        assert history[5].status == ProgressStatus.RETRYING


class TestProgressEvent:
    """Tests for ProgressEvent."""

    def test_event_has_timestamp(self):
        """Event should auto-generate timestamp."""
        event = ProgressEvent(
            status=ProgressStatus.COMPLETED, task="test", detail="done"
        )
        assert event.timestamp is not None
        assert len(event.timestamp) > 0

    def test_event_metadata(self):
        """Event should support metadata."""
        event = ProgressEvent(
            status=ProgressStatus.COMPLETED,
            task="test",
            detail="done",
            metadata={"key": "value", "count": 42},
        )
        assert event.metadata["key"] == "value"
        assert event.metadata["count"] == 42


class TestValidation:
    """Tests for input/output validation."""

    def test_valid_input_passes(self):
        """Valid input should pass validation."""
        assert validate_input("Hello, world!")
        assert validate_input({"key": "value"})

    def test_sql_injection_blocked(self):
        """SQL injection patterns should be blocked."""
        with pytest.raises(ValidationError):
            validate_input("SELECT * FROM users; DROP TABLE users;--")

    def test_command_injection_blocked(self):
        """Command injection patterns should be blocked."""
        with pytest.raises(ValidationError):
            validate_input("file.txt; rm -rf /")

    def test_max_length_enforced(self):
        """Max length should be enforced."""
        long_input = "x" * 200000
        with pytest.raises(ValidationError):
            validate_input(long_input)

    def test_output_validation(self):
        """Output validation should work."""
        assert validate_output("Normal output")

        # Too long output
        long_output = "x" * 2000000
        with pytest.raises(ValidationError):
            validate_output(long_output)

    def test_custom_validator(self):
        """Custom validator should work."""
        validator = create_custom_validator(
            forbidden_patterns=[r"secret"], max_length=100
        )

        assert validator("normal text")

        with pytest.raises(ValidationError):
            validator("this is secret data")

    def test_custom_rules(self):
        """Custom validation rules should work."""
        custom_rule = ValidationRule(name="no_numbers", forbidden_patterns=[r"\d+"])

        assert validate_input("hello world", rules=[custom_rule])

        with pytest.raises(ValidationError):
            validate_input("hello 123 world", rules=[custom_rule])


class TestValidationRule:
    """Tests for ValidationRule."""

    def test_rule_defaults(self):
        """Rule should have sensible defaults."""
        rule = ValidationRule(name="test")
        assert rule.forbidden_patterns == []
        assert rule.pattern is None
        assert rule.max_length is None
        assert rule.min_length is None

    def test_rule_with_all_fields(self):
        """Rule should accept all fields."""
        rule = ValidationRule(
            name="test",
            pattern=r"^\w+$",
            max_length=100,
            min_length=5,
            forbidden_patterns=[r"bad"],
        )
        assert rule.name == "test"
        assert rule.max_length == 100
        assert rule.min_length == 5


class TestRetryConfig:
    """Tests for RetryConfig."""

    def test_default_config(self):
        """Default config should have sensible values."""
        config = RetryConfig()
        assert config.max_attempts == 3
        assert config.max_delay == 60.0
        assert config.min_wait == 2.0
        assert config.max_wait == 30.0

    def test_custom_config(self):
        """Custom config values should be set."""
        config = RetryConfig(
            max_attempts=5, max_delay=120.0, min_wait=1.0, max_wait=60.0
        )
        assert config.max_attempts == 5
        assert config.max_delay == 120.0


class TestWithRetryDecorator:
    """Tests for with_retry decorator."""

    def test_decorator_retries_on_failure(self):
        """Decorator should retry failed functions."""
        call_count = 0

        @with_retry(max_attempts=3, min_wait=0.1, max_wait=0.5)
        def flaky_function():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Not yet")
            return "success"

        result = flaky_function()
        assert result == "success"
        assert call_count == 3


class TestIntegration:
    """Integration tests for execution components."""

    def test_full_execution_flow(self):
        """Test complete execution flow with all components."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Setup
            session_memory = FileSessionMemory(Path(tmpdir))

            # Create a simple agent
            agent = Mock()
            agent.name = "test-agent"
            agent.process = lambda msg: [
                AgentMessage(
                    task_id=msg.task_id,
                    content=f"Result: {msg.content}",
                    history=msg.history,
                    routing=msg.routing,
                )
            ]

            runtime = MultiAgentRuntime(agents=[agent])

            # Track progress
            progress_events = []

            def progress_callback(status, task, detail):
                progress_events.append((status, task, detail))

            runner = SequentialTaskRunner(
                runtime, session_memory, on_progress=progress_callback
            )

            # Execute
            result = runner.run_tasks(
                ["First task", "Second task"], "integration-test", ["agent1"]
            )

            # Verify
            assert result.success is True
            assert len(progress_events) >= 4  # start + complete for each task

            # Check session was persisted
            session = session_memory.load("integration-test")
            assert session is not None
            assert len(session.task_outputs) == 2
