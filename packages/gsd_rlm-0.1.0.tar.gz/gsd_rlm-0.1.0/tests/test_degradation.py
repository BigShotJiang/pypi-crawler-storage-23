"""
Tests for graceful degradation components.

This module tests the GracefulDegradation class, PartialResult dataclass,
TaskStatus enum, and the extended RetryableAgent with degradation support.

Requirements: EXEC-13 (retry), EXEC-14 (fallback), EXEC-15 (partial results)
"""

import pytest
from unittest.mock import Mock, MagicMock
from dataclasses import dataclass
from typing import Any, Optional, Set

from gsd_rlm.execution.degradation import (
    TaskStatus,
    PartialResult,
    GracefulDegradation,
    DependencyGraphProtocol,
)
from gsd_rlm.execution.retry import (
    RetryableAgent,
    RetryConfig,
    FallbackExhaustedError,
)


# Helper for creating mock task results
@dataclass
class MockTaskResult:
    """Mock task result for testing."""

    task_id: str
    content: Any
    success: bool
    error: Optional[str] = None


class TestTaskStatusEnum:
    """Tests for TaskStatus enum."""

    def test_all_status_values_exist(self):
        """All status values should be defined."""
        assert TaskStatus.PENDING == "pending"
        assert TaskStatus.RUNNING == "running"
        assert TaskStatus.COMPLETED == "completed"
        assert TaskStatus.FAILED == "failed"
        assert TaskStatus.SKIPPED == "skipped"

    def test_status_count(self):
        """Should have exactly 5 status types."""
        assert len(TaskStatus) == 5

    def test_status_is_string_enum(self):
        """TaskStatus should be a string enum."""
        assert isinstance(TaskStatus.PENDING, str)
        assert TaskStatus.COMPLETED.value == "completed"


class TestPartialResultCreation:
    """Tests for PartialResult dataclass creation."""

    def test_partial_result_basic_creation(self):
        """PartialResult should be created with required fields."""
        result = PartialResult(wave_id=0, total_tasks=5)
        assert result.wave_id == 0
        assert result.total_tasks == 5

    def test_partial_result_defaults(self):
        """PartialResult should have sensible defaults."""
        result = PartialResult(wave_id=1, total_tasks=3)
        assert result.completed_tasks == 0
        assert result.failed_tasks == 0
        assert result.skipped_tasks == 0
        assert result.results == {}
        assert result.errors == {}
        assert result.task_status == {}

    def test_partial_result_with_data(self):
        """PartialResult should accept all fields."""
        result = PartialResult(
            wave_id=2,
            total_tasks=4,
            completed_tasks=2,
            failed_tasks=1,
            skipped_tasks=1,
            results={"a": "result_a", "b": "result_b"},
            errors={"c": "error_c"},
            task_status={"a": TaskStatus.COMPLETED, "c": TaskStatus.FAILED},
        )
        assert result.completed_tasks == 2
        assert result.failed_tasks == 1
        assert result.skipped_tasks == 1
        assert len(result.results) == 2
        assert len(result.errors) == 1


class TestPartialResultSuccessRate:
    """Tests for PartialResult.success_rate property."""

    def test_success_rate_zero_tasks(self):
        """Success rate should be 0.0 when no tasks."""
        result = PartialResult(wave_id=0, total_tasks=0)
        assert result.success_rate == 0.0

    def test_success_rate_all_succeeded(self):
        """Success rate should be 1.0 when all tasks succeeded."""
        result = PartialResult(wave_id=0, total_tasks=3, completed_tasks=3)
        assert result.success_rate == 1.0

    def test_success_rate_partial(self):
        """Success rate should reflect actual success ratio."""
        result = PartialResult(wave_id=0, total_tasks=3, completed_tasks=2)
        assert result.success_rate == pytest.approx(2 / 3)

    def test_success_rate_none_succeeded(self):
        """Success rate should be 0.0 when no tasks succeeded."""
        result = PartialResult(wave_id=0, total_tasks=3, completed_tasks=0)
        assert result.success_rate == 0.0


class TestPartialResultIsPartialSuccess:
    """Tests for PartialResult.is_partial_success property."""

    def test_is_partial_success_true(self):
        """Should be True when some succeeded and some failed."""
        result = PartialResult(
            wave_id=0, total_tasks=3, completed_tasks=2, failed_tasks=1
        )
        assert result.is_partial_success is True

    def test_is_partial_success_all_succeeded(self):
        """Should be False when all succeeded."""
        result = PartialResult(
            wave_id=0, total_tasks=3, completed_tasks=3, failed_tasks=0
        )
        assert result.is_partial_success is False

    def test_is_partial_success_all_failed(self):
        """Should be False when all failed."""
        result = PartialResult(
            wave_id=0, total_tasks=3, completed_tasks=0, failed_tasks=3
        )
        assert result.is_partial_success is False


class TestPartialResultCanContinue:
    """Tests for PartialResult.can_continue property."""

    def test_can_continue_with_success(self):
        """Should be True if at least one task succeeded."""
        result = PartialResult(wave_id=0, total_tasks=3, completed_tasks=1)
        assert result.can_continue is True

    def test_can_continue_no_success(self):
        """Should be False if no tasks succeeded."""
        result = PartialResult(wave_id=0, total_tasks=3, completed_tasks=0)
        assert result.can_continue is False


class TestGracefulDegradationCollect:
    """Tests for GracefulDegradation.collect_partial_results method."""

    def test_collect_empty_results(self):
        """Should handle empty task results."""
        gd = GracefulDegradation()
        result = gd.collect_partial_results(wave_id=0, task_results=[])
        assert result.total_tasks == 0
        assert result.completed_tasks == 0
        assert result.failed_tasks == 0

    def test_collect_all_succeeded(self):
        """Should collect all successful results."""
        gd = GracefulDegradation()
        task_results = [
            MockTaskResult("a", "result_a", True),
            MockTaskResult("b", "result_b", True),
        ]
        result = gd.collect_partial_results(wave_id=1, task_results=task_results)

        assert result.total_tasks == 2
        assert result.completed_tasks == 2
        assert result.failed_tasks == 0
        assert result.results["a"] == "result_a"
        assert result.results["b"] == "result_b"
        assert result.task_status["a"] == TaskStatus.COMPLETED

    def test_collect_mixed_results(self):
        """Should collect mixed success/failure results."""
        gd = GracefulDegradation()
        task_results = [
            MockTaskResult("a", "result_a", True),
            MockTaskResult("b", None, False, "error_b"),
            MockTaskResult("c", "result_c", True),
        ]
        result = gd.collect_partial_results(wave_id=0, task_results=task_results)

        assert result.completed_tasks == 2
        assert result.failed_tasks == 1
        assert result.results["a"] == "result_a"
        assert result.errors["b"] == "error_b"
        assert result.task_status["b"] == TaskStatus.FAILED


class TestGracefulDegradationShouldContinue:
    """Tests for GracefulDegradation.should_continue method."""

    def test_should_continue_above_threshold(self):
        """Should continue if success rate >= threshold."""
        gd = GracefulDegradation(min_success_rate=0.5)
        result = PartialResult(wave_id=0, total_tasks=3, completed_tasks=2)
        assert gd.should_continue(result) is True

    def test_should_continue_below_threshold_with_success(self):
        """Should continue if at least one success (critical path)."""
        gd = GracefulDegradation(min_success_rate=0.8)
        result = PartialResult(wave_id=0, total_tasks=10, completed_tasks=1)
        # 1/10 = 0.1 < 0.8, but still continues due to critical path
        assert gd.should_continue(result) is True

    def test_should_continue_no_tasks(self):
        """Should not continue if no tasks."""
        gd = GracefulDegradation()
        result = PartialResult(wave_id=0, total_tasks=0)
        assert gd.should_continue(result) is False


class TestGracefulDegradationMinRate:
    """Tests for GracefulDegradation min_success_rate configuration."""

    def test_min_rate_respected_high(self):
        """High min_rate should require more successes."""
        gd = GracefulDegradation(min_success_rate=0.9)
        result = PartialResult(wave_id=0, total_tasks=10, completed_tasks=8)
        # 8/10 = 0.8 < 0.9, but still True due to critical path
        assert gd.should_continue(result) is True

    def test_min_rate_respected_low(self):
        """Low min_rate should be more lenient."""
        gd = GracefulDegradation(min_success_rate=0.3)
        result = PartialResult(wave_id=0, total_tasks=10, completed_tasks=4)
        # 4/10 = 0.4 >= 0.3
        assert gd.should_continue(result) is True


class MockDependencyGraph:
    """Mock dependency graph for testing."""

    def __init__(self, dependencies: dict):
        """Initialize with task dependencies mapping."""
        self.dependencies = dependencies

    def get_dependents(self, task_id: str) -> Set[str]:
        """Get tasks that depend on the given task."""
        return self.dependencies.get(task_id, set())


class TestGracefulDegradationMarkSkipped:
    """Tests for GracefulDegradation.mark_skipped_dependents method."""

    def test_mark_skipped_single_dependent(self):
        """Should mark single dependent as skipped."""
        gd = GracefulDegradation()
        graph = MockDependencyGraph({"task-a": {"task-b"}})
        partial = PartialResult(
            wave_id=0,
            total_tasks=2,
            task_status={"task-a": TaskStatus.FAILED, "task-b": TaskStatus.PENDING},
        )

        gd.mark_skipped_dependents("task-a", graph, partial)

        assert partial.task_status["task-b"] == TaskStatus.SKIPPED
        assert partial.skipped_tasks == 1
        assert "task-a" in partial.errors["task-b"]

    def test_mark_skipped_multiple_dependents(self):
        """Should mark all dependents as skipped."""
        gd = GracefulDegradation()
        graph = MockDependencyGraph({"task-a": {"task-b", "task-c", "task-d"}})
        partial = PartialResult(
            wave_id=0,
            total_tasks=4,
            task_status={
                "task-a": TaskStatus.FAILED,
                "task-b": TaskStatus.PENDING,
                "task-c": TaskStatus.PENDING,
                "task-d": TaskStatus.PENDING,
            },
        )

        gd.mark_skipped_dependents("task-a", graph, partial)

        assert partial.skipped_tasks == 3
        assert partial.task_status["task-b"] == TaskStatus.SKIPPED
        assert partial.task_status["task-c"] == TaskStatus.SKIPPED
        assert partial.task_status["task-d"] == TaskStatus.SKIPPED

    def test_mark_skipped_no_dependents(self):
        """Should handle task with no dependents."""
        gd = GracefulDegradation()
        graph = MockDependencyGraph({})
        partial = PartialResult(
            wave_id=0,
            total_tasks=1,
            task_status={"task-a": TaskStatus.FAILED},
        )

        gd.mark_skipped_dependents("task-a", graph, partial)

        assert partial.skipped_tasks == 0

    def test_mark_skipped_already_completed(self):
        """Should not mark already completed tasks as skipped."""
        gd = GracefulDegradation()
        graph = MockDependencyGraph({"task-a": {"task-b"}})
        partial = PartialResult(
            wave_id=0,
            total_tasks=2,
            task_status={
                "task-a": TaskStatus.FAILED,
                "task-b": TaskStatus.COMPLETED,  # Already completed
            },
        )

        gd.mark_skipped_dependents("task-a", graph, partial)

        # Should not change status of completed task
        assert partial.task_status["task-b"] == TaskStatus.COMPLETED
        assert partial.skipped_tasks == 0


class TestRetryableAgentWithDegradation:
    """Tests for RetryableAgent with degradation support."""

    def test_retryable_agent_with_degradation_returns_none_on_failure(self):
        """Agent with degradation should return None instead of raising."""
        primary = Mock()
        primary.name = "primary"
        primary.process.side_effect = Exception("always fails")

        gd = GracefulDegradation()
        retryable = RetryableAgent(
            primary,
            config=RetryConfig(max_attempts=1),
            degradation=gd,
        )

        result = retryable.execute(Mock())
        assert result is None

    def test_retryable_agent_without_degradation_raises(self):
        """Agent without degradation should raise FallbackExhaustedError."""
        primary = Mock()
        primary.name = "primary"
        primary.process.side_effect = Exception("always fails")

        retryable = RetryableAgent(
            primary,
            config=RetryConfig(max_attempts=1),
        )

        with pytest.raises(FallbackExhaustedError):
            retryable.execute(Mock())

    def test_retryable_agent_with_degradation_success(self):
        """Agent with degradation should return result on success."""
        primary = Mock()
        primary.name = "primary"
        primary.process.return_value = [Mock(content="success")]

        gd = GracefulDegradation()
        retryable = RetryableAgent(
            primary,
            config=RetryConfig(max_attempts=1),
            degradation=gd,
        )

        result = retryable.execute(Mock())
        assert result is not None


class TestRetryableAgentPartialCallback:
    """Tests for RetryableAgent on_partial_success callback."""

    def test_callback_fires_on_partial_success(self):
        """Callback should be called when partial success occurs."""
        primary = Mock()
        primary.name = "primary"
        primary.process.side_effect = Exception("always fails")

        callback_called = []
        partial_received = []

        def on_partial(partial):
            callback_called.append(True)
            partial_received.append(partial)

        gd = GracefulDegradation()
        retryable = RetryableAgent(
            primary,
            config=RetryConfig(max_attempts=1),
            degradation=gd,
            on_partial_success=on_partial,
        )

        # Use execute_with_degradation to get partial result
        result, partial = retryable.execute_with_degradation(Mock())

        assert result is None
        assert partial is not None
        # Callback should have been called during execute_with_degradation
        assert len(callback_called) == 1
        assert partial_received[0].total_tasks == 1
        assert partial_received[0].failed_tasks == 1

    def test_callback_exception_handled(self):
        """Callback exceptions should be caught and logged."""
        primary = Mock()
        primary.name = "primary"
        primary.process.side_effect = Exception("always fails")

        def bad_callback(partial):
            raise RuntimeError("Callback error!")

        gd = GracefulDegradation()
        retryable = RetryableAgent(
            primary,
            config=RetryConfig(max_attempts=1),
            degradation=gd,
            on_partial_success=bad_callback,
        )

        # Should not raise, callback exception should be handled
        result, partial = retryable.execute_with_degradation(Mock())
        assert result is None
        assert partial is not None


class TestRetryableAgentExecuteWithDegradation:
    """Tests for RetryableAgent.execute_with_degradation method."""

    def test_execute_with_degradation_success(self):
        """Should return (result, None) on success."""
        primary = Mock()
        primary.name = "primary"
        primary.process.return_value = [Mock(content="success")]

        gd = GracefulDegradation()
        retryable = RetryableAgent(
            primary,
            config=RetryConfig(max_attempts=1),
            degradation=gd,
        )

        result, partial = retryable.execute_with_degradation(Mock())

        assert result is not None
        assert partial is None

    def test_execute_with_degradation_failure(self):
        """Should return (None, partial) on failure."""
        primary = Mock()
        primary.name = "primary"
        primary.process.side_effect = Exception("always fails")

        gd = GracefulDegradation()
        retryable = RetryableAgent(
            primary,
            config=RetryConfig(max_attempts=1),
            degradation=gd,
        )

        result, partial = retryable.execute_with_degradation(Mock())

        assert result is None
        assert partial is not None
        assert partial.failed_tasks == 1
        assert partial.total_tasks == 1

    def test_execute_with_degradation_no_degradation_raises(self):
        """Should raise FallbackExhaustedError if no degradation configured."""
        primary = Mock()
        primary.name = "primary"
        primary.process.side_effect = Exception("always fails")

        retryable = RetryableAgent(
            primary,
            config=RetryConfig(max_attempts=1),
            # No degradation configured
        )

        with pytest.raises(FallbackExhaustedError):
            retryable.execute_with_degradation(Mock())

    def test_execute_with_degradation_tracks_fallbacks(self):
        """Should track all fallback attempts in partial result."""
        primary = Mock()
        primary.name = "primary"
        primary.process.side_effect = Exception("primary fails")

        fallback1 = Mock()
        fallback1.name = "fallback1"
        fallback1.process.side_effect = Exception("fallback1 fails")

        fallback2 = Mock()
        fallback2.name = "fallback2"
        fallback2.process.side_effect = Exception("fallback2 fails")

        gd = GracefulDegradation()
        retryable = RetryableAgent(
            primary,
            fallback_agents=[fallback1, fallback2],
            config=RetryConfig(max_attempts=1),
            degradation=gd,
        )

        result, partial = retryable.execute_with_degradation(Mock())

        assert result is None
        assert partial is not None
        # Should have primary + 2 fallbacks = 3 failures
        assert partial.total_tasks == 3
        assert partial.failed_tasks == 3
        assert "primary" in partial.task_status
        assert "fallback-0" in partial.task_status
        assert "fallback-1" in partial.task_status
