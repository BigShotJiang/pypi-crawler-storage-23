"""
Tests for atomic commit creation with traceability (INT-14, INT-15).

Tests cover:
- CommitType enum values
- CommitMetadata dataclass and message generation
- stage_files with existing and missing files
- create_atomic_commit in git repository
- Error handling for non-git directories
"""

import os
import subprocess
import tempfile
from pathlib import Path

import pytest

from gsd_rlm.git.commits import (
    CommitMetadata,
    CommitType,
    GitError,
    GitCommandError,
    NotAGitRepositoryError,
    create_atomic_commit,
    get_commit_hash,
    get_staged_files,
    get_uncommitted_changes,
    is_git_repository,
    stage_files,
)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def temp_git_repo():
    """Create a temporary git repository for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Initialize git repo
        subprocess.run(["git", "init"], cwd=tmpdir, check=True, capture_output=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=tmpdir,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=tmpdir,
            check=True,
            capture_output=True,
        )
        # Create initial commit so HEAD exists
        readme = Path(tmpdir) / "README.md"
        readme.write_text("# Test Repo")
        subprocess.run(
            ["git", "add", "README.md"], cwd=tmpdir, check=True, capture_output=True
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=tmpdir,
            check=True,
            capture_output=True,
        )
        yield tmpdir


@pytest.fixture
def temp_non_git_dir():
    """Create a temporary non-git directory for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def sample_metadata() -> CommitMetadata:
    """Provide sample CommitMetadata for testing."""
    return CommitMetadata(
        phase="05",
        plan="01",
        task="03",
        type=CommitType.FEAT,
        description="add checkpoint pause/resume logic",
        files=["src/checkpoints/pause.py", "src/checkpoints/resume.py"],
    )


# =============================================================================
# CommitType Tests
# =============================================================================


class TestCommitType:
    """Tests for CommitType enum."""

    def test_commit_type_values(self):
        """CommitType should have all conventional commit types."""
        assert CommitType.FEAT.value == "feat"
        assert CommitType.FIX.value == "fix"
        assert CommitType.TEST.value == "test"
        assert CommitType.DOCS.value == "docs"
        assert CommitType.REFACTOR.value == "refactor"
        assert CommitType.STYLE.value == "style"
        assert CommitType.CHORE.value == "chore"

    def test_commit_type_str_conversion(self):
        """CommitType should convert to string correctly."""
        assert str(CommitType.FEAT) == "feat"
        assert str(CommitType.FIX) == "fix"


# =============================================================================
# CommitMetadata Tests
# =============================================================================


class TestCommitMetadata:
    """Tests for CommitMetadata dataclass."""

    def test_to_message_basic(self, sample_metadata: CommitMetadata):
        """to_message should generate correct format."""
        message = sample_metadata.to_message()
        assert message == "feat(05-01-03): add checkpoint pause/resume logic"

    def test_to_message_with_body(self, sample_metadata: CommitMetadata):
        """to_message should include body if provided."""
        sample_metadata.body = "Extended description\n\n- Bullet 1\n- Bullet 2"
        message = sample_metadata.to_message()
        assert message.startswith("feat(05-01-03): add checkpoint pause/resume logic")
        assert "\n\n" in message
        assert "Extended description" in message

    def test_to_message_different_types(self):
        """to_message should work with different commit types."""
        for commit_type in CommitType:
            metadata = CommitMetadata(
                phase="01",
                plan="02",
                task="03",
                type=commit_type,
                description="test description",
            )
            message = metadata.to_message()
            assert message.startswith(f"{commit_type}(01-02-03):")

    def test_to_dict(self, sample_metadata: CommitMetadata):
        """to_dict should serialize all fields."""
        data = sample_metadata.to_dict()

        assert data["phase"] == "05"
        assert data["plan"] == "01"
        assert data["task"] == "03"
        assert data["type"] == "feat"
        assert data["description"] == "add checkpoint pause/resume logic"
        assert "message" in data
        assert data["files"] == sample_metadata.files

    def test_default_files(self):
        """CommitMetadata should default to empty files list."""
        metadata = CommitMetadata(
            phase="01",
            plan="01",
            task="01",
            type=CommitType.FEAT,
            description="test",
        )
        assert metadata.files == []

    def test_phase_with_version(self):
        """CommitMetadata should support phase with version like 05.1."""
        metadata = CommitMetadata(
            phase="05.1",
            plan="02",
            task="03",
            type=CommitType.FEAT,
            description="test",
        )
        message = metadata.to_message()
        assert "(05.1-02-03):" in message


# =============================================================================
# Git Repository Detection Tests
# =============================================================================


class TestIsGitRepository:
    """Tests for is_git_repository function."""

    def test_is_git_repository_true(self, temp_git_repo: str):
        """is_git_repository should return True for git repo."""
        assert is_git_repository(temp_git_repo) is True

    def test_is_git_repository_false(self, temp_non_git_dir: str):
        """is_git_repository should return False for non-git dir."""
        assert is_git_repository(temp_non_git_dir) is False

    def test_is_git_repository_subdirectory(self, temp_git_repo: str):
        """is_git_repository should return True for subdirectory of git repo."""
        subdir = Path(temp_git_repo) / "subdir"
        subdir.mkdir()
        assert is_git_repository(str(subdir)) is True


# =============================================================================
# Stage Files Tests
# =============================================================================


class TestStageFiles:
    """Tests for stage_files function."""

    def test_stage_files_existing(self, temp_git_repo: str):
        """stage_files should stage existing files."""
        # Create files
        file1 = Path(temp_git_repo) / "file1.py"
        file2 = Path(temp_git_repo) / "file2.py"
        file1.write_text("# File 1")
        file2.write_text("# File 2")

        staged, skipped = stage_files(["file1.py", "file2.py"], temp_git_repo)

        assert len(staged) == 2
        assert len(skipped) == 0
        assert "file1.py" in staged
        assert "file2.py" in staged

    def test_stage_files_missing(self, temp_git_repo: str):
        """stage_files should skip missing files."""
        staged, skipped = stage_files(["nonexistent.py"], temp_git_repo)

        assert len(staged) == 0
        assert len(skipped) == 1
        assert "nonexistent.py" in skipped

    def test_stage_files_mixed(self, temp_git_repo: str):
        """stage_files should handle mix of existing and missing."""
        # Create one file
        file1 = Path(temp_git_repo) / "exists.py"
        file1.write_text("# Exists")

        staged, skipped = stage_files(
            ["exists.py", "missing.py"],
            temp_git_repo,
        )

        assert len(staged) == 1
        assert len(skipped) == 1
        assert "exists.py" in staged
        assert "missing.py" in skipped

    def test_stage_files_subdirectory(self, temp_git_repo: str):
        """stage_files should handle files in subdirectories."""
        subdir = Path(temp_git_repo) / "src" / "module"
        subdir.mkdir(parents=True)
        file1 = subdir / "code.py"
        file1.write_text("# Code")

        staged, skipped = stage_files(
            ["src/module/code.py"],
            temp_git_repo,
        )

        assert len(staged) == 1
        assert "src/module/code.py" in staged


# =============================================================================
# Get Commit Hash Tests
# =============================================================================


class TestGetCommitHash:
    """Tests for get_commit_hash function."""

    def test_get_commit_hash_short(self, temp_git_repo: str):
        """get_commit_hash should return short hash by default."""
        hash_val = get_commit_hash(temp_git_repo, short=True)

        assert len(hash_val) == 7
        assert all(c in "0123456789abcdef" for c in hash_val)

    def test_get_commit_hash_full(self, temp_git_repo: str):
        """get_commit_hash should return full hash when short=False."""
        hash_val = get_commit_hash(temp_git_repo, short=False)

        assert len(hash_val) == 40
        assert all(c in "0123456789abcdef" for c in hash_val)

    def test_get_commit_hash_default_short(self, temp_git_repo: str):
        """get_commit_hash should default to short hash."""
        hash_val = get_commit_hash(temp_git_repo)

        assert len(hash_val) == 7


# =============================================================================
# Create Atomic Commit Tests
# =============================================================================


class TestCreateAtomicCommit:
    """Tests for create_atomic_commit function."""

    def test_create_atomic_commit_success(self, temp_git_repo: str):
        """create_atomic_commit should create commit and return hash."""
        # Create file
        file1 = Path(temp_git_repo) / "test.py"
        file1.write_text("# Test")

        metadata = CommitMetadata(
            phase="05",
            plan="01",
            task="03",
            type=CommitType.FEAT,
            description="add test functionality",
            files=["test.py"],
        )

        commit_hash = create_atomic_commit(metadata, temp_git_repo)

        assert len(commit_hash) == 7

        # Verify commit was created with correct message
        result = subprocess.run(
            ["git", "log", "-1", "--format=%s"],
            cwd=temp_git_repo,
            capture_output=True,
            text=True,
            check=True,
        )
        assert "feat(05-01-03): add test functionality" in result.stdout

    def test_create_atomic_commit_not_git_repo(self, temp_non_git_dir: str):
        """create_atomic_commit should raise NotAGitRepositoryError."""
        metadata = CommitMetadata(
            phase="01",
            plan="01",
            task="01",
            type=CommitType.FEAT,
            description="test",
            files=["test.py"],
        )

        with pytest.raises(NotAGitRepositoryError):
            create_atomic_commit(metadata, temp_non_git_dir)

    def test_create_atomic_commit_no_files(self, temp_git_repo: str):
        """create_atomic_commit should raise error if no files to commit."""
        metadata = CommitMetadata(
            phase="01",
            plan="01",
            task="01",
            type=CommitType.FEAT,
            description="test",
            files=["nonexistent.py"],
        )

        with pytest.raises(GitError, match="No files to commit"):
            create_atomic_commit(metadata, temp_git_repo)

    def test_create_atomic_commit_with_body(self, temp_git_repo: str):
        """create_atomic_commit should include body in commit message."""
        file1 = Path(temp_git_repo) / "test.py"
        file1.write_text("# Test")

        metadata = CommitMetadata(
            phase="05",
            plan="02",
            task="01",
            type=CommitType.FEAT,
            description="add feature",
            files=["test.py"],
            body="Extended description\n\n- Bullet 1\n- Bullet 2",
        )

        commit_hash = create_atomic_commit(metadata, temp_git_repo)

        # Verify commit message includes body
        result = subprocess.run(
            ["git", "log", "-1", "--format=%B"],
            cwd=temp_git_repo,
            capture_output=True,
            text=True,
            check=True,
        )
        assert "Extended description" in result.stdout
        assert "Bullet 1" in result.stdout


# =============================================================================
# Get Staged Files Tests
# =============================================================================


class TestGetStagedFiles:
    """Tests for get_staged_files function."""

    def test_get_staged_files_empty(self, temp_git_repo: str):
        """get_staged_files should return empty list when nothing staged."""
        staged = get_staged_files(temp_git_repo)
        assert staged == []

    def test_get_staged_files_with_files(self, temp_git_repo: str):
        """get_staged_files should return list of staged files."""
        file1 = Path(temp_git_repo) / "staged.py"
        file1.write_text("# Staged")
        subprocess.run(["git", "add", "staged.py"], cwd=temp_git_repo, check=True)

        staged = get_staged_files(temp_git_repo)
        assert "staged.py" in staged


# =============================================================================
# Get Uncommitted Changes Tests
# =============================================================================


class TestGetUncommittedChanges:
    """Tests for get_uncommitted_changes function."""

    def test_get_uncommitted_changes_empty(self, temp_git_repo: str):
        """get_uncommitted_changes should return empty lists when clean."""
        changes = get_uncommitted_changes(temp_git_repo)

        assert changes["staged"] == []
        assert changes["unstaged"] == []
        assert changes["untracked"] == []

    def test_get_uncommitted_changes_untracked(self, temp_git_repo: str):
        """get_uncommitted_changes should detect untracked files."""
        file1 = Path(temp_git_repo) / "untracked.py"
        file1.write_text("# Untracked")

        changes = get_uncommitted_changes(temp_git_repo)

        assert "untracked.py" in changes["untracked"]

    def test_get_uncommitted_changes_staged(self, temp_git_repo: str):
        """get_uncommitted_changes should detect staged files."""
        file1 = Path(temp_git_repo) / "staged.py"
        file1.write_text("# Staged")
        subprocess.run(["git", "add", "staged.py"], cwd=temp_git_repo, check=True)

        changes = get_uncommitted_changes(temp_git_repo)

        assert "staged.py" in changes["staged"]

    def test_get_uncommitted_changes_unstaged(self, temp_git_repo: str):
        """get_uncommitted_changes should detect unstaged modifications."""
        # Modify README.md (which was committed in fixture)
        readme = Path(temp_git_repo) / "README.md"
        readme.write_text("# Modified")

        changes = get_uncommitted_changes(temp_git_repo)

        assert "README.md" in changes["unstaged"]
