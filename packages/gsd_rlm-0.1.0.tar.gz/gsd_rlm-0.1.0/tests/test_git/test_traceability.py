"""
Tests for commit message validation and traceability extraction (INT-14, INT-15).

Tests cover:
- COMMIT_PATTERN regex matching
- validate_commit_message function
- extract_traceability parsing
- get_commit_history filtering
- generate_commit_report markdown output
"""

import subprocess
import tempfile
from pathlib import Path

import pytest

from gsd_rlm.git.traceability import (
    COMMIT_PATTERN,
    TraceabilityInfo,
    extract_traceability,
    generate_commit_report,
    get_commit_history,
    get_commits_by_plan,
    get_commits_by_task,
    get_phase_summary,
    validate_commit_message,
)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def temp_git_repo_with_commits():
    """Create a temporary git repository with traceable commits."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Initialize git repo
        subprocess.run(["git", "init"], cwd=tmpdir, check=True, capture_output=True)
        subprocess.run(
            ["git", "config", "user.email", "test@example.com"],
            cwd=tmpdir,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.name", "Test User"],
            cwd=tmpdir,
            check=True,
            capture_output=True,
        )

        # Create initial commit
        readme = Path(tmpdir) / "README.md"
        readme.write_text("# Test Repo")
        subprocess.run(
            ["git", "add", "README.md"], cwd=tmpdir, check=True, capture_output=True
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=tmpdir,
            check=True,
            capture_output=True,
        )

        # Create traceable commits
        commits_to_create = [
            ("feat(05-01-01): add feature one", "file1.py"),
            ("feat(05-01-02): add feature two", "file2.py"),
            ("fix(05-01-03): fix bug in feature", "file1.py"),
            ("test(05-02-01): add tests for feature", "test_file1.py"),
            ("docs(05-02-02): update documentation", "README.md"),
            ("feat(04-01-01): previous phase feature", "old_file.py"),
        ]

        for i, (message, filename) in enumerate(commits_to_create):
            filepath = Path(tmpdir) / filename
            # Append counter to ensure content changes for repeated files
            filepath.write_text(f"# {filename}\n# Version {i + 1}")
            subprocess.run(
                ["git", "add", filename], cwd=tmpdir, check=True, capture_output=True
            )
            subprocess.run(
                ["git", "commit", "-m", message],
                cwd=tmpdir,
                check=True,
                capture_output=True,
            )

        yield tmpdir


# =============================================================================
# COMMIT_PATTERN Tests
# =============================================================================


class TestCommitPattern:
    """Tests for COMMIT_PATTERN regex."""

    def test_pattern_matches_feat(self):
        """Pattern should match feat commits."""
        match = COMMIT_PATTERN.match("feat(05-01-03): add feature")
        assert match is not None
        assert match.group(1) == "feat"
        assert match.group(2) == "05"
        assert match.group(3) == "01"
        assert match.group(4) == "03"

    def test_pattern_matches_fix(self):
        """Pattern should match fix commits."""
        match = COMMIT_PATTERN.match("fix(04-02-01): fix bug")
        assert match is not None
        assert match.group(1) == "fix"

    def test_pattern_matches_all_types(self):
        """Pattern should match all commit types."""
        types = ["feat", "fix", "test", "docs", "refactor", "style", "chore"]
        for commit_type in types:
            message = f"{commit_type}(01-01-01): test"
            match = COMMIT_PATTERN.match(message)
            assert match is not None, f"Failed to match {commit_type}"

    def test_pattern_matches_phase_with_version(self):
        """Pattern should match phase with version like 05.1."""
        match = COMMIT_PATTERN.match("feat(05.1-02-03): add feature")
        assert match is not None
        assert match.group(2) == "05.1"

    def test_pattern_rejects_invalid_type(self):
        """Pattern should reject invalid commit types."""
        match = COMMIT_PATTERN.match("invalid(01-01-01): test")
        assert match is None

    def test_pattern_rejects_missing_parens(self):
        """Pattern should reject commits without traceability."""
        match = COMMIT_PATTERN.match("feat: add feature")
        assert match is None

    def test_pattern_rejects_wrong_format(self):
        """Pattern should reject wrong traceability format."""
        match = COMMIT_PATTERN.match("feat(01/02/03): test")
        assert match is None

    def test_pattern_rejects_empty_description(self):
        """Pattern should reject empty description."""
        # Note: Our pattern requires at least one character after ": "
        match = COMMIT_PATTERN.match("feat(01-01-01):")
        assert match is None


# =============================================================================
# validate_commit_message Tests
# =============================================================================


class TestValidateCommitMessage:
    """Tests for validate_commit_message function."""

    def test_validate_valid_message(self):
        """validate_commit_message should return True for valid messages."""
        assert validate_commit_message("feat(05-01-03): add feature") is True

    def test_validate_valid_message_with_body(self):
        """validate_commit_message should handle multi-line messages."""
        message = "feat(05-01-03): add feature\n\nExtended body"
        assert validate_commit_message(message) is True

    def test_validate_invalid_message(self):
        """validate_commit_message should return False for invalid messages."""
        assert validate_commit_message("invalid commit message") is False

    def test_validate_empty_message(self):
        """validate_commit_message should return False for empty message."""
        assert validate_commit_message("") is False

    def test_validate_missing_traceability(self):
        """validate_commit_message should return False without traceability."""
        assert validate_commit_message("feat: add feature") is False

    def test_validate_all_types(self):
        """validate_commit_message should accept all commit types."""
        for commit_type in [
            "feat",
            "fix",
            "test",
            "docs",
            "refactor",
            "style",
            "chore",
        ]:
            message = f"{commit_type}(01-01-01): test"
            assert validate_commit_message(message) is True


# =============================================================================
# extract_traceability Tests
# =============================================================================


class TestExtractTraceability:
    """Tests for extract_traceability function."""

    def test_extract_basic(self):
        """extract_traceability should parse valid message."""
        info = extract_traceability("feat(05-01-03): add feature", "abc1234")

        assert info is not None
        assert info.commit_type == "feat"
        assert info.phase == "05"
        assert info.plan == "01"
        assert info.task == "03"
        assert info.description == "add feature"
        assert info.commit_hash == "abc1234"

    def test_extract_invalid_message(self):
        """extract_traceability should return None for invalid message."""
        info = extract_traceability("invalid message", "abc1234")
        assert info is None

    def test_extract_with_multiline(self):
        """extract_traceability should only parse first line."""
        message = "feat(05-01-03): add feature\n\nBody text"
        info = extract_traceability(message, "abc1234")

        assert info is not None
        assert info.description == "add feature"

    def test_extract_without_hash(self):
        """extract_traceability should work without commit hash."""
        info = extract_traceability("feat(05-01-03): add feature")

        assert info is not None
        assert info.commit_hash == ""

    def test_extract_phase_with_version(self):
        """extract_traceability should parse phase with version."""
        info = extract_traceability("feat(05.1-02-03): test", "abc1234")

        assert info is not None
        assert info.phase == "05.1"


class TestTraceabilityInfo:
    """Tests for TraceabilityInfo dataclass."""

    def test_to_dict(self):
        """TraceabilityInfo.to_dict should serialize correctly."""
        info = TraceabilityInfo(
            commit_type="feat",
            phase="05",
            plan="01",
            task="03",
            description="add feature",
            commit_hash="abc1234",
        )

        data = info.to_dict()
        assert data["commit_type"] == "feat"
        assert data["phase"] == "05"
        assert data["plan"] == "01"
        assert data["task"] == "03"
        assert data["description"] == "add feature"
        assert data["commit_hash"] == "abc1234"

    def test_trace_id(self):
        """TraceabilityInfo.trace_id should return phase-plan-task."""
        info = TraceabilityInfo(
            commit_type="feat",
            phase="05",
            plan="01",
            task="03",
            description="test",
            commit_hash="abc",
        )

        assert info.trace_id == "05-01-03"


# =============================================================================
# get_commit_history Tests
# =============================================================================


class TestGetCommitHistory:
    """Tests for get_commit_history function."""

    def test_get_commit_history_all(self, temp_git_repo_with_commits: str):
        """get_commit_history should return all traceable commits."""
        history = get_commit_history(temp_git_repo_with_commits)

        # Should not include "Initial commit"
        assert len(history) == 6

    def test_get_commit_history_filter_by_phase(self, temp_git_repo_with_commits: str):
        """get_commit_history should filter by phase."""
        history = get_commit_history(temp_git_repo_with_commits, phase="05")

        assert len(history) == 5
        for info in history:
            assert info.phase == "05"

    def test_get_commit_history_filter_phase_04(self, temp_git_repo_with_commits: str):
        """get_commit_history should filter to phase 04."""
        history = get_commit_history(temp_git_repo_with_commits, phase="04")

        assert len(history) == 1
        assert history[0].plan == "01"

    def test_get_commit_history_limit(self, temp_git_repo_with_commits: str):
        """get_commit_history should respect limit parameter."""
        history = get_commit_history(temp_git_repo_with_commits, limit=2)

        assert len(history) <= 2


# =============================================================================
# get_commits_by_plan Tests
# =============================================================================


class TestGetCommitsByPlan:
    """Tests for get_commits_by_plan function."""

    def test_get_commits_by_plan(self, temp_git_repo_with_commits: str):
        """get_commits_by_plan should filter to specific plan."""
        commits = get_commits_by_plan(
            phase="05", plan="01", working_dir=temp_git_repo_with_commits
        )

        assert len(commits) == 3
        for info in commits:
            assert info.plan == "01"

    def test_get_commits_by_plan_empty(self, temp_git_repo_with_commits: str):
        """get_commits_by_plan should return empty for non-existent plan."""
        commits = get_commits_by_plan(
            phase="05", plan="99", working_dir=temp_git_repo_with_commits
        )

        assert len(commits) == 0


# =============================================================================
# get_commits_by_task Tests
# =============================================================================


class TestGetCommitsByTask:
    """Tests for get_commits_by_task function."""

    def test_get_commits_by_task(self, temp_git_repo_with_commits: str):
        """get_commits_by_task should filter to specific task."""
        commits = get_commits_by_task(
            phase="05",
            plan="01",
            task="01",
            working_dir=temp_git_repo_with_commits,
        )

        assert len(commits) == 1
        assert commits[0].task == "01"

    def test_get_commits_by_task_empty(self, temp_git_repo_with_commits: str):
        """get_commits_by_task should return empty for non-existent task."""
        commits = get_commits_by_task(
            phase="05",
            plan="01",
            task="99",
            working_dir=temp_git_repo_with_commits,
        )

        assert len(commits) == 0


# =============================================================================
# generate_commit_report Tests
# =============================================================================


class TestGenerateCommitReport:
    """Tests for generate_commit_report function."""

    def test_generate_report(self, temp_git_repo_with_commits: str):
        """generate_commit_report should generate markdown report."""
        report = generate_commit_report("05", temp_git_repo_with_commits)

        assert "# Phase 05 Commit Report" in report
        assert "Total Commits:** 5" in report
        assert "## Plan 05-01" in report
        assert "## Plan 05-02" in report

    def test_generate_report_includes_commits(self, temp_git_repo_with_commits: str):
        """generate_commit_report should include commit details."""
        report = generate_commit_report("05", temp_git_repo_with_commits)

        assert "add feature one" in report
        assert "add feature two" in report
        assert "fix bug in feature" in report

    def test_generate_report_empty(self):
        """generate_commit_report should handle no commits."""
        with tempfile.TemporaryDirectory() as tmpdir:
            subprocess.run(["git", "init"], cwd=tmpdir, check=True, capture_output=True)
            subprocess.run(
                ["git", "config", "user.email", "test@example.com"],
                cwd=tmpdir,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "config", "user.name", "Test"],
                cwd=tmpdir,
                check=True,
                capture_output=True,
            )
            readme = Path(tmpdir) / "README.md"
            readme.write_text("# Test")
            subprocess.run(
                ["git", "add", "README.md"], cwd=tmpdir, check=True, capture_output=True
            )
            subprocess.run(
                ["git", "commit", "-m", "Initial"],
                cwd=tmpdir,
                check=True,
                capture_output=True,
            )

            report = generate_commit_report("99", tmpdir)

            assert "No traceable commits found" in report

    def test_generate_report_custom_title(self, temp_git_repo_with_commits: str):
        """generate_commit_report should use custom title."""
        report = generate_commit_report(
            "05",
            temp_git_repo_with_commits,
            title="Custom Report Title",
        )

        assert "# Custom Report Title" in report


# =============================================================================
# get_phase_summary Tests
# =============================================================================


class TestGetPhaseSummary:
    """Tests for get_phase_summary function."""

    def test_get_phase_summary(self, temp_git_repo_with_commits: str):
        """get_phase_summary should return summary statistics."""
        summary = get_phase_summary(phase="05", working_dir=temp_git_repo_with_commits)

        assert summary["phase"] == "05"
        assert summary["total_commits"] == 5
        assert "01" in summary["plans"]
        assert "02" in summary["plans"]

    def test_get_phase_summary_by_type(self, temp_git_repo_with_commits: str):
        """get_phase_summary should count commits by type."""
        summary = get_phase_summary(phase="05", working_dir=temp_git_repo_with_commits)

        assert summary["commits_by_type"]["feat"] == 2
        assert summary["commits_by_type"]["fix"] == 1
        assert summary["commits_by_type"]["test"] == 1
        assert summary["commits_by_type"]["docs"] == 1

    def test_get_phase_summary_by_plan(self, temp_git_repo_with_commits: str):
        """get_phase_summary should count commits by plan."""
        summary = get_phase_summary(phase="05", working_dir=temp_git_repo_with_commits)

        assert summary["commits_by_plan"]["01"] == 3
        assert summary["commits_by_plan"]["02"] == 2

    def test_get_phase_summary_empty(self):
        """get_phase_summary should handle no commits."""
        with tempfile.TemporaryDirectory() as tmpdir:
            subprocess.run(["git", "init"], cwd=tmpdir, check=True, capture_output=True)
            subprocess.run(
                ["git", "config", "user.email", "test@example.com"],
                cwd=tmpdir,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "config", "user.name", "Test"],
                cwd=tmpdir,
                check=True,
                capture_output=True,
            )
            readme = Path(tmpdir) / "README.md"
            readme.write_text("# Test")
            subprocess.run(
                ["git", "add", "README.md"], cwd=tmpdir, check=True, capture_output=True
            )
            subprocess.run(
                ["git", "commit", "-m", "Initial"],
                cwd=tmpdir,
                check=True,
                capture_output=True,
            )

            summary = get_phase_summary(phase="99", working_dir=tmpdir)

            assert summary["total_commits"] == 0
            assert summary["plans"] == []
