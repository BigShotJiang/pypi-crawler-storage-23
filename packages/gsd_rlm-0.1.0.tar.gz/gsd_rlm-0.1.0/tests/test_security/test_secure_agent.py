"""
Comprehensive tests for SecureAgent (SEC-01, SEC-02, SEC-03, SEC-04).

Tests cover:
- SecureAgent creation and configuration
- Zone assignment and property access
- Access validation integration
- Grant access functionality
- Episode creation with zone tags
- Violation logging
"""

import logging
import os
import tempfile

import pytest
from pydantic import ValidationError

from gsd_rlm.security import (
    SecureAgent,
    SecureAgentConfig,
    ZoneAccessManager,
    TrustZone,
    MemoryEncryptor,
)
from gsd_rlm.agents.definition import AgentDefinition
from gsd_rlm.memory.hmem import EpisodeType


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def access_manager():
    """Provide a fresh ZoneAccessManager for each test."""
    return ZoneAccessManager()


@pytest.fixture
def agent_definition():
    """Provide a sample agent definition."""
    return AgentDefinition(
        name="Test Agent",
        role="Tester",
        goal="Test the secure agent",
        backstory="A test agent for security testing",
    )


@pytest.fixture
def secure_agent(access_manager, agent_definition):
    """Provide a SecureAgent with SECRET zone."""
    config = SecureAgentConfig(
        agent_id="secret-agent",
        zone=TrustZone.SECRET,
    )
    return SecureAgent(agent_definition, config, access_manager)


@pytest.fixture
def public_agent(access_manager, agent_definition):
    """Provide a SecureAgent with PUBLIC zone."""
    config = SecureAgentConfig(
        agent_id="public-agent",
        zone=TrustZone.PUBLIC,
    )
    return SecureAgent(agent_definition, config, access_manager)


@pytest.fixture
def internal_agent(access_manager, agent_definition):
    """Provide a SecureAgent with INTERNAL zone."""
    config = SecureAgentConfig(
        agent_id="internal-agent",
        zone=TrustZone.INTERNAL,
    )
    return SecureAgent(agent_definition, config, access_manager)


# =============================================================================
# SecureAgentConfig Tests
# =============================================================================


class TestSecureAgentConfig:
    """Tests for SecureAgentConfig Pydantic model."""

    def test_secure_agent_config_creation(self):
        """SecureAgentConfig should be created with required fields."""
        config = SecureAgentConfig(agent_id="test-agent")

        assert config.agent_id == "test-agent"
        assert config.zone == TrustZone.INTERNAL  # Default
        assert config.encryption_enabled is True  # Default

    def test_secure_agent_config_custom_zone(self):
        """SecureAgentConfig should accept custom zone."""
        config = SecureAgentConfig(
            agent_id="secret-agent",
            zone=TrustZone.SECRET,
        )

        assert config.zone == TrustZone.SECRET

    def test_secure_agent_config_encryption_disabled(self):
        """SecureAgentConfig should allow disabling encryption."""
        config = SecureAgentConfig(
            agent_id="no-encryption-agent",
            encryption_enabled=False,
        )

        assert config.encryption_enabled is False

    def test_secure_agent_config_extra_forbidden(self):
        """SecureAgentConfig should reject unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            SecureAgentConfig(
                agent_id="test-agent",
                unknown_field="should_fail",  # type: ignore
            )

        assert "extra" in str(exc_info.value).lower()

    def test_secure_agent_config_empty_agent_id_fails(self):
        """SecureAgentConfig should reject empty agent_id."""
        with pytest.raises(ValidationError):
            SecureAgentConfig(agent_id="")

    def test_secure_agent_config_key_path(self):
        """SecureAgentConfig should accept optional key_path."""
        config = SecureAgentConfig(
            agent_id="key-agent",
            key_path="/path/to/key",
        )

        assert config.key_path == "/path/to/key"


# =============================================================================
# SecureAgent Creation Tests
# =============================================================================


class TestSecureAgentCreation:
    """Tests for SecureAgent instantiation."""

    def test_secure_agent_creation(self, access_manager, agent_definition):
        """SecureAgent should be created successfully."""
        config = SecureAgentConfig(
            agent_id="test-agent",
            zone=TrustZone.CONFIDENTIAL,
        )
        agent = SecureAgent(agent_definition, config, access_manager)

        assert agent.agent_id == "test-agent"
        assert agent.zone == TrustZone.CONFIDENTIAL
        assert agent.definition == agent_definition

    def test_secure_agent_zone_property(self, secure_agent):
        """zone property should return config zone."""
        assert secure_agent.zone == TrustZone.SECRET

    def test_secure_agent_registered_with_manager(self, secure_agent, access_manager):
        """Agent should be registered with ZoneAccessManager."""
        zone = access_manager.get_agent_zone("secret-agent")
        assert zone == TrustZone.SECRET

    def test_secure_agent_has_encryptor_by_default(self, secure_agent):
        """SecureAgent should have encryptor when encryption enabled."""
        assert secure_agent.encryptor is not None
        assert isinstance(secure_agent.encryptor, MemoryEncryptor)

    def test_secure_agent_no_encryptor_when_disabled(
        self, access_manager, agent_definition
    ):
        """SecureAgent should not have encryptor when encryption disabled."""
        config = SecureAgentConfig(
            agent_id="no-encrypt-agent",
            encryption_enabled=False,
        )
        agent = SecureAgent(agent_definition, config, access_manager)

        assert agent.encryptor is None

    def test_secure_agent_with_key_path(self, access_manager, agent_definition):
        """SecureAgent should load key from file."""
        # Create temp key file
        key = MemoryEncryptor.generate_key()
        fd, key_path = tempfile.mkstemp()
        os.write(fd, key)
        os.close(fd)

        try:
            config = SecureAgentConfig(
                agent_id="key-file-agent",
                key_path=key_path,
            )
            agent = SecureAgent(agent_definition, config, access_manager)

            assert agent.encryptor is not None
            assert agent.encryptor.key == key
        finally:
            os.unlink(key_path)


# =============================================================================
# SecureAgent Access Validation Tests
# =============================================================================


class TestSecureAgentAccessValidation:
    """Tests for access validation (SEC-04)."""

    def test_can_access_same_agent(self, secure_agent):
        """Agent should always have access to itself."""
        assert secure_agent.can_access("secret-agent") is True

    def test_can_access_higher_zone_denied(
        self, public_agent, secure_agent, access_manager
    ):
        """PUBLIC agent should not access SECRET agent."""
        # Register the other agent
        access_manager.assign_agent_to_zone("secret-agent", TrustZone.SECRET)

        assert public_agent.can_access("secret-agent") is False

    def test_can_access_lower_zone_allowed(
        self, secure_agent, public_agent, access_manager
    ):
        """SECRET agent should access PUBLIC agent."""
        # Register the other agent
        access_manager.assign_agent_to_zone("public-agent", TrustZone.PUBLIC)

        assert secure_agent.can_access("public-agent") is True

    def test_can_access_with_operation(
        self, secure_agent, public_agent, access_manager
    ):
        """can_access should accept operation parameter."""
        access_manager.assign_agent_to_zone("public-agent", TrustZone.PUBLIC)

        assert secure_agent.can_access("public-agent", "read") is True
        assert secure_agent.can_access("public-agent", "write") is True

    def test_violation_logged_on_denied_access(self, public_agent, access_manager):
        """Denied access should log a violation."""
        access_manager.assign_agent_to_zone("secret-target", TrustZone.SECRET)

        # Attempt access (should be denied)
        result = public_agent.can_access("secret-target")
        assert result is False

        # Check violation was logged
        violations = access_manager.get_violations()
        assert len(violations) >= 1

        violation = violations[-1]
        assert violation.source_agent_id == "public-agent"
        assert violation.target_agent_id == "secret-target"


# =============================================================================
# SecureAgent Grant Access Tests
# =============================================================================


class TestSecureAgentGrantAccess:
    """Tests for grant access functionality (SEC-03)."""

    def test_grant_access_to_creates_grant(self, public_agent, access_manager):
        """grant_access_to should create an AccessGrant."""
        access_manager.assign_agent_to_zone("secret-target", TrustZone.SECRET)

        grant = public_agent.grant_access_to(
            target_agent_id="secret-target",
            granted_by="admin",
        )

        assert grant is not None
        assert grant.source_agent_id == "public-agent"
        assert grant.target_agent_id == "secret-target"
        assert grant.granted_by == "admin"

    def test_grant_access_with_operations(self, public_agent, access_manager):
        """grant_access_to should accept custom operations."""
        access_manager.assign_agent_to_zone("secret-target", TrustZone.SECRET)

        grant = public_agent.grant_access_to(
            target_agent_id="secret-target",
            granted_by="admin",
            allowed_operations={"read", "write"},
        )

        assert grant.allowed_operations == {"read", "write"}

    def test_grant_enables_access(self, public_agent, access_manager):
        """After grant, access should be allowed."""
        access_manager.assign_agent_to_zone("secret-target", TrustZone.SECRET)

        # Initially denied
        assert public_agent.can_access("secret-target") is False

        # Grant access
        public_agent.grant_access_to(
            target_agent_id="secret-target",
            granted_by="admin",
        )

        # Now allowed
        assert public_agent.can_access("secret-target") is True


# =============================================================================
# SecureAgent Episode Creation Tests
# =============================================================================


class TestSecureAgentEpisodeCreation:
    """Tests for episode creation with zone tags."""

    def test_create_episode_has_zone_tag(self, secure_agent):
        """Created episode should have zone tag."""
        episode = secure_agent.create_episode(
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Test context",
            action="Test action",
            outcome="Test outcome",
        )

        assert "zone:secret" in episode.tags

    def test_create_episode_basic_fields(self, secure_agent):
        """Created episode should have correct basic fields."""
        episode = secure_agent.create_episode(
            episode_type=EpisodeType.PROBLEM_SOLVING,
            context="Problem context",
            action="Solution action",
            outcome="Result outcome",
            success=True,
            session_id="session-123",
        )

        assert episode.agent_id == "secret-agent"
        assert episode.session_id == "session-123"
        assert episode.episode_type == EpisodeType.PROBLEM_SOLVING
        assert episode.context == "Problem context"
        assert episode.action == "Solution action"
        assert episode.outcome == "Result outcome"
        assert episode.success is True

    def test_create_episode_unique_id(self, secure_agent):
        """Each episode should have unique ID."""
        ep1 = secure_agent.create_episode(
            episode_type=EpisodeType.TASK_EXECUTION,
            context="First",
            action="Action",
            outcome="Outcome",
        )
        ep2 = secure_agent.create_episode(
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Second",
            action="Action",
            outcome="Outcome",
        )

        assert ep1.episode_id != ep2.episode_id

    def test_create_episode_default_values(self, secure_agent):
        """Created episode should have sensible defaults."""
        episode = secure_agent.create_episode(
            episode_type=EpisodeType.LEARNING,
            context="Context",
            action="Action",
            outcome="Outcome",
        )

        assert episode.success is False  # Default
        assert episode.session_id == ""  # Default
        assert episode.tokens_used == 0  # Default
        assert episode.duration_ms == 0  # Default

    def test_create_episode_public_zone_tag(self, public_agent):
        """PUBLIC agent episode should have zone:public tag."""
        episode = public_agent.create_episode(
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Context",
            action="Action",
            outcome="Outcome",
        )

        assert "zone:public" in episode.tags


# =============================================================================
# SecureAgent Zone Assignment Tests
# =============================================================================


class TestSecureAgentZoneAssignment:
    """Tests for zone assignment retrieval."""

    def test_get_zone_assignment(self, secure_agent):
        """get_zone_assignment should return ZoneAssignment."""
        assignment = secure_agent.get_zone_assignment()

        assert assignment.agent_id == "secret-agent"
        assert assignment.zone == TrustZone.SECRET
        assert assignment.assigned_by == "system"

    def test_get_zone_assignment_has_reason(self, secure_agent):
        """ZoneAssignment should have assignment reason."""
        assignment = secure_agent.get_zone_assignment()

        assert assignment.reason is not None
        assert "initialization" in assignment.reason.lower()


# =============================================================================
# SecureAgent Logging Tests
# =============================================================================


class TestSecureAgentLogging:
    """Tests for violation logging."""

    def test_violation_logged_on_denied_access(
        self, public_agent, access_manager, caplog
    ):
        """Warning should be logged on access denial."""
        access_manager.assign_agent_to_zone("secret-target", TrustZone.SECRET)

        with caplog.at_level(logging.WARNING, logger="gsd_rlm.security"):
            result = public_agent.can_access("secret-target")

        assert result is False
        assert any("violation" in record.message.lower() for record in caplog.records)

    def test_no_log_on_allowed_access(self, secure_agent, access_manager, caplog):
        """No warning should be logged on allowed access."""
        access_manager.assign_agent_to_zone("public-target", TrustZone.PUBLIC)

        with caplog.at_level(logging.WARNING, logger="gsd_rlm.security"):
            result = secure_agent.can_access("public-target")

        assert result is True
        assert not any(
            "violation" in record.message.lower() for record in caplog.records
        )


# =============================================================================
# Integration Tests
# =============================================================================


class TestSecureAgentIntegration:
    """Integration tests for SecureAgent with all components."""

    def test_full_secure_workflow(self, access_manager, agent_definition):
        """Test complete workflow with encryption, zones, and access."""
        # Create agents in different zones
        secret_config = SecureAgentConfig(agent_id="secret-1", zone=TrustZone.SECRET)
        public_config = SecureAgentConfig(agent_id="public-1", zone=TrustZone.PUBLIC)

        secret_agent = SecureAgent(agent_definition, secret_config, access_manager)
        public_agent = SecureAgent(agent_definition, public_config, access_manager)

        # Create encrypted episodes
        secret_ep = secret_agent.create_episode(
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Secret context",
            action="Secret action",
            outcome="Secret outcome",
        )
        public_ep = public_agent.create_episode(
            episode_type=EpisodeType.TASK_EXECUTION,
            context="Public context",
            action="Public action",
            outcome="Public outcome",
        )

        # Verify zone tags
        assert "zone:secret" in secret_ep.tags
        assert "zone:public" in public_ep.tags

        # Verify access control
        assert secret_agent.can_access("public-1") is True
        assert public_agent.can_access("secret-1") is False

        # Grant access and verify
        public_agent.grant_access_to("secret-1", granted_by="admin")
        assert public_agent.can_access("secret-1") is True

    def test_multiple_agents_same_zone(self, access_manager, agent_definition):
        """Agents in same zone should access each other."""
        config1 = SecureAgentConfig(agent_id="internal-1", zone=TrustZone.INTERNAL)
        config2 = SecureAgentConfig(agent_id="internal-2", zone=TrustZone.INTERNAL)

        agent1 = SecureAgent(agent_definition, config1, access_manager)
        agent2 = SecureAgent(agent_definition, config2, access_manager)

        # Same zone - should have access
        assert agent1.can_access("internal-2") is True
        assert agent2.can_access("internal-1") is True
