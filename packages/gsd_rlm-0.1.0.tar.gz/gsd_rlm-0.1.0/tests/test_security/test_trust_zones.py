"""
Comprehensive tests for trust zones (SEC-02).

Tests cover:
- TrustZone enum values and ordering
- Priority-based access control
- ZoneAssignment Pydantic model
- Validation and defaults
"""

from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from gsd_rlm.security import TrustZone, ZoneAssignment


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def secret_assignment() -> ZoneAssignment:
    """Provide a zone assignment with SECRET level."""
    return ZoneAssignment(
        agent_id="agent-secret-001",
        zone=TrustZone.SECRET,
        assigned_by="admin",
        reason="Handles sensitive financial data",
    )


@pytest.fixture
def public_assignment() -> ZoneAssignment:
    """Provide a zone assignment with PUBLIC level."""
    return ZoneAssignment(
        agent_id="agent-public-001",
        zone=TrustZone.PUBLIC,
    )


# =============================================================================
# TrustZone Enum Tests
# =============================================================================


class TestTrustZoneEnum:
    """Tests for TrustZone enum."""

    def test_trust_zone_has_four_values(self):
        """TrustZone should have exactly 4 values."""
        zones = list(TrustZone)
        assert len(zones) == 4

    def test_trust_zone_values(self):
        """TrustZone should have expected string values."""
        assert TrustZone.PUBLIC.value == "public"
        assert TrustZone.INTERNAL.value == "internal"
        assert TrustZone.CONFIDENTIAL.value == "confidential"
        assert TrustZone.SECRET.value == "secret"

    def test_trust_zone_from_string(self):
        """TrustZone should be creatable from string."""
        zone = TrustZone("secret")
        assert zone == TrustZone.SECRET

    def test_trust_zone_string_inheritance(self):
        """TrustZone should inherit from str for easy serialization."""
        assert isinstance(TrustZone.SECRET, str)
        assert TrustZone.SECRET == "secret"


# =============================================================================
# TrustZone Priority Tests
# =============================================================================


class TestTrustZonePriority:
    """Tests for TrustZone priority ordering."""

    def test_trust_zone_priority_ordering(self):
        """TrustZone priorities should follow hierarchy."""
        assert TrustZone.PUBLIC.priority == 0
        assert TrustZone.INTERNAL.priority == 1
        assert TrustZone.CONFIDENTIAL.priority == 2
        assert TrustZone.SECRET.priority == 3

        # Ordering check
        assert TrustZone.SECRET.priority > TrustZone.CONFIDENTIAL.priority
        assert TrustZone.CONFIDENTIAL.priority > TrustZone.INTERNAL.priority
        assert TrustZone.INTERNAL.priority > TrustZone.PUBLIC.priority

    def test_trust_zone_comparison_operators(self):
        """TrustZone should support comparison operators."""
        assert TrustZone.PUBLIC < TrustZone.INTERNAL
        assert TrustZone.INTERNAL < TrustZone.CONFIDENTIAL
        assert TrustZone.CONFIDENTIAL < TrustZone.SECRET

        assert TrustZone.SECRET > TrustZone.CONFIDENTIAL
        assert TrustZone.PUBLIC <= TrustZone.INTERNAL
        assert TrustZone.SECRET >= TrustZone.SECRET

    def test_trust_zone_sorting(self):
        """TrustZone should be sortable by priority."""
        zones = [
            TrustZone.SECRET,
            TrustZone.PUBLIC,
            TrustZone.CONFIDENTIAL,
            TrustZone.INTERNAL,
        ]

        sorted_zones = sorted(zones)

        assert sorted_zones == [
            TrustZone.PUBLIC,
            TrustZone.INTERNAL,
            TrustZone.CONFIDENTIAL,
            TrustZone.SECRET,
        ]


# =============================================================================
# TrustZone Access Control Tests
# =============================================================================


class TestTrustZoneAccessControl:
    """Tests for TrustZone access control logic."""

    def test_trust_zone_allows_access_from_same_zone(self):
        """Same zone should always have access."""
        for zone in TrustZone:
            assert zone.allows_access_from(zone) is True

    def test_trust_zone_allows_access_from_higher_zone(self):
        """Higher priority zones should access lower priority data."""
        # SECRET (3) can access CONFIDENTIAL (2)
        assert TrustZone.CONFIDENTIAL.allows_access_from(TrustZone.SECRET) is True

        # SECRET (3) can access INTERNAL (1)
        assert TrustZone.INTERNAL.allows_access_from(TrustZone.SECRET) is True

        # SECRET (3) can access PUBLIC (0)
        assert TrustZone.PUBLIC.allows_access_from(TrustZone.SECRET) is True

        # CONFIDENTIAL (2) can access INTERNAL (1)
        assert TrustZone.INTERNAL.allows_access_from(TrustZone.CONFIDENTIAL) is True

    def test_trust_zone_denies_access_from_lower_zone(self):
        """Lower priority zones should NOT access higher priority data."""
        # PUBLIC (0) cannot access SECRET (3)
        assert TrustZone.SECRET.allows_access_from(TrustZone.PUBLIC) is False

        # PUBLIC (0) cannot access CONFIDENTIAL (2)
        assert TrustZone.CONFIDENTIAL.allows_access_from(TrustZone.PUBLIC) is False

        # PUBLIC (0) cannot access INTERNAL (1)
        assert TrustZone.INTERNAL.allows_access_from(TrustZone.PUBLIC) is False

        # INTERNAL (1) cannot access SECRET (3)
        assert TrustZone.SECRET.allows_access_from(TrustZone.INTERNAL) is False

        # INTERNAL (1) cannot access CONFIDENTIAL (2)
        assert TrustZone.CONFIDENTIAL.allows_access_from(TrustZone.INTERNAL) is False

    def test_trust_zone_access_matrix(self):
        """Test complete access matrix for all zone combinations."""
        # Source zone -> Target zone -> Expected access
        # Higher or equal priority can access lower or equal zone
        for source in TrustZone:
            for target in TrustZone:
                expected = source.priority >= target.priority
                actual = target.allows_access_from(source)
                assert actual == expected, (
                    f"Access from {source.value} to {target.value}: "
                    f"expected {expected}, got {actual}"
                )


# =============================================================================
# ZoneAssignment Pydantic Model Tests
# =============================================================================


class TestZoneAssignmentModel:
    """Tests for ZoneAssignment Pydantic model."""

    def test_zone_assignment_creation(self, secret_assignment: ZoneAssignment):
        """ZoneAssignment should be created with all fields."""
        assert secret_assignment.agent_id == "agent-secret-001"
        assert secret_assignment.zone == TrustZone.SECRET
        assert secret_assignment.assigned_by == "admin"
        assert secret_assignment.reason == "Handles sensitive financial data"

    def test_zone_assignment_defaults(self):
        """ZoneAssignment should have sensible defaults."""
        assignment = ZoneAssignment(
            agent_id="agent-001",
            zone=TrustZone.INTERNAL,
        )

        assert assignment.assigned_by == "system"
        assert assignment.reason is None
        assert assignment.assigned_at is not None

    def test_zone_assignment_auto_timestamp(self):
        """ZoneAssignment should auto-generate UTC timestamp."""
        before = datetime.now(timezone.utc)
        assignment = ZoneAssignment(
            agent_id="agent-001",
            zone=TrustZone.PUBLIC,
        )
        after = datetime.now(timezone.utc)

        assert before <= assignment.assigned_at <= after
        # Ensure timezone-aware
        assert assignment.assigned_at.tzinfo == timezone.utc

    def test_zone_assignment_extra_forbidden(self):
        """ZoneAssignment should reject unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            ZoneAssignment(
                agent_id="agent-001",
                zone=TrustZone.PUBLIC,
                unknown_field="should_fail",  # type: ignore
            )

        assert "extra" in str(exc_info.value).lower()

    def test_zone_assignment_empty_agent_id_fails(self):
        """ZoneAssignment should reject empty agent_id."""
        with pytest.raises(ValidationError):
            ZoneAssignment(
                agent_id="",
                zone=TrustZone.PUBLIC,
            )

    def test_zone_assignment_min_length_validation(self):
        """ZoneAssignment should enforce min_length on agent_id."""
        # min_length=1 prevents empty strings
        with pytest.raises(ValidationError):
            ZoneAssignment(
                agent_id="",
                zone=TrustZone.PUBLIC,
            )

        # Note: whitespace-only strings pass min_length (length check only)
        # Custom strip validator would be needed to reject them

    def test_zone_assignment_empty_assigned_by_fails(self):
        """ZoneAssignment should reject empty assigned_by."""
        with pytest.raises(ValidationError):
            ZoneAssignment(
                agent_id="agent-001",
                zone=TrustZone.PUBLIC,
                assigned_by="",
            )


# =============================================================================
# ZoneAssignment Access Method Tests
# =============================================================================


class TestZoneAssignmentAccess:
    """Tests for ZoneAssignment.can_access method."""

    def test_zone_assignment_can_access_same_zone(
        self, secret_assignment: ZoneAssignment
    ):
        """Agent should access data in same zone."""
        assert secret_assignment.can_access(TrustZone.SECRET) is True

    def test_zone_assignment_can_access_lower_zone(
        self, secret_assignment: ZoneAssignment
    ):
        """SECRET agent should access all lower zones."""
        assert secret_assignment.can_access(TrustZone.CONFIDENTIAL) is True
        assert secret_assignment.can_access(TrustZone.INTERNAL) is True
        assert secret_assignment.can_access(TrustZone.PUBLIC) is True

    def test_zone_assignment_cannot_access_higher_zone(
        self, public_assignment: ZoneAssignment
    ):
        """PUBLIC agent should not access higher zones."""
        assert public_assignment.can_access(TrustZone.INTERNAL) is False
        assert public_assignment.can_access(TrustZone.CONFIDENTIAL) is False
        assert public_assignment.can_access(TrustZone.SECRET) is False

    def test_zone_assignment_repr(self, secret_assignment: ZoneAssignment):
        """ZoneAssignment repr should be informative."""
        repr_str = repr(secret_assignment)

        assert "ZoneAssignment" in repr_str
        assert "agent-secret-001" in repr_str
        assert "secret" in repr_str
        assert "admin" in repr_str


# =============================================================================
# Integration Tests
# =============================================================================


class TestSecurityIntegration:
    """Integration tests for security components."""

    def test_trust_zone_with_string_serialization(self):
        """TrustZone should serialize to string for JSON/storage."""
        zone = TrustZone.SECRET

        # Should be usable as string via value
        assert zone.value == "secret"
        assert zone.value == "secret"
        # For f-string, use .value explicitly
        assert f"zone:{zone.value}" == "zone:secret"

    def test_zone_assignment_json_serialization(self):
        """ZoneAssignment should serialize to JSON."""
        assignment = ZoneAssignment(
            agent_id="agent-001",
            zone=TrustZone.CONFIDENTIAL,
            assigned_by="admin",
        )

        # Pydantic model_dump
        data = assignment.model_dump()

        assert data["agent_id"] == "agent-001"
        assert data["zone"] == TrustZone.CONFIDENTIAL
        assert data["assigned_by"] == "admin"

    def test_zone_assignment_json_deserialization(self):
        """ZoneAssignment should deserialize from JSON."""
        data = {
            "agent_id": "agent-002",
            "zone": "secret",  # String value
            "assigned_by": "system",
            "assigned_at": "2024-01-15T10:00:00+00:00",
        }

        assignment = ZoneAssignment(**data)

        assert assignment.agent_id == "agent-002"
        assert assignment.zone == TrustZone.SECRET
        assert assignment.assigned_by == "system"
