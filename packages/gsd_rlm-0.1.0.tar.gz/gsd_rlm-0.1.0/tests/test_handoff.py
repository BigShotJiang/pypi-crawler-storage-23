"""
Tests for agent handoff system (AGENT-05).

Tests the handoff mechanism that enables agents to delegate specialized work
while maintaining full conversation history and task context.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch
from datetime import datetime
from pathlib import Path

from gsd_rlm.execution.handoff import HandoffContext, AgentHandoff
from gsd_rlm.execution.runner import AgentMessage, MultiAgentRuntime
from gsd_rlm.session.memory import (
    FileSessionMemory,
    SessionState,
    SessionMessage,
    TaskOutput,
)


class TestHandoffContext:
    """Tests for HandoffContext dataclass."""

    def test_handoff_context_creation(self):
        """HandoffContext created with all fields."""
        ctx = HandoffContext(
            source_agent="generalist",
            target_agent="specialist",
            handoff_reason="Needs domain expertise",
            conversation_history=[{"role": "user", "content": "Hello"}],
            current_task="Analyze financial data",
            task_outputs=[{"task": "prev", "result": "done"}],
            routing_chain=["generalist"],
            metadata={"priority": "high"},
        )

        assert ctx.source_agent == "generalist"
        assert ctx.target_agent == "specialist"
        assert ctx.handoff_reason == "Needs domain expertise"
        assert len(ctx.conversation_history) == 1
        assert ctx.current_task == "Analyze financial data"
        assert len(ctx.task_outputs) == 1
        assert ctx.routing_chain == ["generalist"]
        assert ctx.metadata == {"priority": "high"}

    def test_handoff_context_timestamp_auto(self):
        """Timestamp auto-generated when not provided."""
        before = datetime.utcnow().isoformat()
        ctx = HandoffContext(
            source_agent="agent-a", target_agent="agent-b", handoff_reason="test"
        )
        after = datetime.utcnow().isoformat()

        # Timestamp should be between before and after
        assert before <= ctx.timestamp <= after

    def test_handoff_context_to_agent_message(self):
        """Conversion to AgentMessage works correctly."""
        ctx = HandoffContext(
            source_agent="generalist",
            target_agent="specialist",
            handoff_reason="Needs domain expertise",
            conversation_history=[{"role": "user", "content": "Hello"}],
            current_task="Analyze financial data",
            routing_chain=["generalist"],
        )

        msg = ctx.to_agent_message()

        assert isinstance(msg, AgentMessage)
        assert msg.task_id == "generalist->specialist"
        assert msg.content == "Analyze financial data"
        assert len(msg.history) == 1
        assert msg.history[0] == {"role": "user", "content": "Hello"}

    def test_handoff_context_routing_chain_extended(self):
        """Target agent added to routing chain."""
        ctx = HandoffContext(
            source_agent="agent-a",
            target_agent="agent-b",
            handoff_reason="Delegation",
            routing_chain=["agent-a"],
        )

        msg = ctx.to_agent_message()

        # Routing should include both source and target
        assert "agent-a" in msg.routing
        assert "agent-b" in msg.routing
        # Target should be added at the end
        assert msg.routing == ["agent-a", "agent-b"]

    def test_handoff_context_preserves_history(self):
        """Conversation history preserved in AgentMessage."""
        history = [
            {"role": "user", "content": "First message"},
            {"role": "agent", "content": "First response"},
            {"role": "user", "content": "Second message"},
        ]

        ctx = HandoffContext(
            source_agent="agent-a",
            target_agent="agent-b",
            handoff_reason="test",
            conversation_history=history,
        )

        msg = ctx.to_agent_message()

        assert msg.history == history
        assert len(msg.history) == 3

    def test_handoff_context_preserves_outputs(self):
        """Task outputs preserved in context."""
        outputs = [
            {"task": "task-1", "result": "result-1", "success": True},
            {"task": "task-2", "result": "result-2", "success": True},
        ]

        ctx = HandoffContext(
            source_agent="agent-a",
            target_agent="agent-b",
            handoff_reason="test",
            task_outputs=outputs,
        )

        assert ctx.task_outputs == outputs
        assert len(ctx.task_outputs) == 2

    def test_handoff_context_default_values(self):
        """Default values for optional fields."""
        ctx = HandoffContext(
            source_agent="agent-a", target_agent="agent-b", handoff_reason="test"
        )

        assert ctx.conversation_history == []
        assert ctx.current_task == ""
        assert ctx.task_outputs == []
        assert ctx.routing_chain == []
        assert ctx.metadata == {}


class TestAgentHandoff:
    """Tests for AgentHandoff class."""

    @pytest.fixture
    def mock_session_memory(self):
        """Create mock FileSessionMemory."""
        mock = Mock(spec=FileSessionMemory)
        return mock

    @pytest.fixture
    def mock_session(self):
        """Create mock SessionState."""
        session = SessionState(
            session_id="test-session",
            agent_name="generalist",
            created_at="2024-01-01T00:00:00Z",
            updated_at="2024-01-01T00:00:00Z",
            messages=[
                SessionMessage(
                    role="user", content="Hello", timestamp="2024-01-01T00:00:00Z"
                ),
                SessionMessage(
                    role="agent", content="Hi!", timestamp="2024-01-01T00:00:01Z"
                ),
            ],
            task_outputs=[
                TaskOutput(
                    task="task-1", result="done", success=True, routing=["generalist"]
                ),
            ],
        )
        return session

    def test_agent_handoff_create(self, mock_session_memory, mock_session):
        """AgentHandoff.create_handoff works with mock session."""
        mock_session_memory.load.return_value = mock_session
        mock_session_memory.get_context_for_llm.return_value = [
            {"role": "user", "content": "Hello"},
            {"role": "agent", "content": "Hi!"},
        ]
        mock_session_memory.get_recent_task_outputs.return_value = [
            {"task": "task-1", "result": "done", "success": True}
        ]

        handoff = AgentHandoff(mock_session_memory)
        ctx = handoff.create_handoff(
            source_agent="generalist",
            target_agent="specialist",
            reason="Needs expertise",
            session_id="test-session",
            task="Complex analysis",
        )

        assert ctx.source_agent == "generalist"
        assert ctx.target_agent == "specialist"
        assert ctx.handoff_reason == "Needs expertise"
        assert ctx.current_task == "Complex analysis"
        mock_session_memory.load.assert_called_once_with("test-session")

    def test_agent_handoff_routing_chain_built(self, mock_session_memory, mock_session):
        """Routing chain extracted from session task outputs."""
        mock_session.task_outputs = [
            TaskOutput(task="t1", result="r1", success=True, routing=["agent-a"]),
            TaskOutput(
                task="t2", result="r2", success=True, routing=["agent-a", "agent-b"]
            ),
            TaskOutput(
                task="t3", result="r3", success=True, routing=["agent-b", "agent-c"]
            ),
        ]
        mock_session_memory.load.return_value = mock_session
        mock_session_memory.get_context_for_llm.return_value = []
        mock_session_memory.get_recent_task_outputs.return_value = []

        handoff = AgentHandoff(mock_session_memory)
        ctx = handoff.create_handoff(
            source_agent="agent-c",
            target_agent="agent-d",
            reason="Delegation",
            session_id="test-session",
            task="Next task",
        )

        # Routing chain should dedupe while preserving order
        assert ctx.routing_chain == ["agent-a", "agent-b", "agent-c"]

    def test_agent_handoff_execute(self, mock_session_memory):
        """Execute handoff through mock runtime."""
        handoff = AgentHandoff(mock_session_memory)

        ctx = HandoffContext(
            source_agent="agent-a",
            target_agent="agent-b",
            handoff_reason="test",
            current_task="Do work",
        )

        # Create mock runtime that returns a processed message
        mock_runtime = Mock(spec=MultiAgentRuntime)
        expected_result = AgentMessage(
            task_id="agent-a->agent-b",
            content="Work done",
            routing=["agent-a", "agent-b"],
        )
        mock_runtime.run.return_value = expected_result

        result = handoff.execute_handoff(ctx, mock_runtime)

        assert result == expected_result
        mock_runtime.run.assert_called_once()

        # Verify the message passed to runtime
        call_args = mock_runtime.run.call_args[0][0]
        assert isinstance(call_args, AgentMessage)
        assert call_args.task_id == "agent-a->agent-b"

    def test_agent_handoff_record(self, mock_session_memory, mock_session):
        """Handoff recorded in session."""
        mock_session_memory.load.return_value = mock_session

        handoff = AgentHandoff(mock_session_memory)

        ctx = HandoffContext(
            source_agent="agent-a",
            target_agent="agent-b",
            handoff_reason="Specialization needed",
            current_task="Complex task",
        )

        result = AgentMessage(
            task_id="agent-a->agent-b",
            content="Task completed successfully",
            routing=["agent-a", "agent-b"],
        )

        handoff.record_handoff("test-session", ctx, result)

        # Verify session was updated and saved
        mock_session_memory.save.assert_called_once()

        # Verify handoff message was added
        assert len(mock_session.messages) == 3  # Original 2 + handoff record
        handoff_msg = mock_session.messages[-1]
        assert handoff_msg.role == "system"
        assert "agent-a -> agent-b" in handoff_msg.content
        assert "Specialization needed" in handoff_msg.content

    def test_agent_handoff_create_session_not_found(self, mock_session_memory):
        """create_handoff raises ValueError if session not found."""
        mock_session_memory.load.return_value = None

        handoff = AgentHandoff(mock_session_memory)

        with pytest.raises(ValueError, match="Session not found"):
            handoff.create_handoff(
                source_agent="agent-a",
                target_agent="agent-b",
                reason="test",
                session_id="nonexistent",
                task="task",
            )

    def test_agent_handoff_record_session_deleted(self, mock_session_memory):
        """record_handoff handles deleted session gracefully."""
        mock_session_memory.load.return_value = None

        handoff = AgentHandoff(mock_session_memory)

        ctx = HandoffContext(
            source_agent="agent-a",
            target_agent="agent-b",
            handoff_reason="test",
            current_task="task",
        )

        # Should not raise, just return without error
        handoff.record_handoff("deleted-session", ctx, "result")

        # Save should not be called since session doesn't exist
        mock_session_memory.save.assert_not_called()

    def test_agent_handoff_full_workflow(self, mock_session_memory, mock_session):
        """Full handoff workflow: create -> execute -> record."""
        mock_session_memory.load.return_value = mock_session
        mock_session_memory.get_context_for_llm.return_value = [
            {"role": "user", "content": "Analyze this data"},
        ]
        mock_session_memory.get_recent_task_outputs.return_value = []

        handoff = AgentHandoff(mock_session_memory)

        # Step 1: Create handoff
        ctx = handoff.create_handoff(
            source_agent="generalist",
            target_agent="financial-analyst",
            reason="Needs financial domain expertise",
            session_id="test-session",
            task="Perform financial analysis",
        )

        assert ctx.source_agent == "generalist"
        assert ctx.target_agent == "financial-analyst"

        # Step 2: Execute handoff
        mock_runtime = Mock(spec=MultiAgentRuntime)
        mock_runtime.run.return_value = AgentMessage(
            task_id="generalist->financial-analyst",
            content="Analysis complete: positive outlook",
            routing=["generalist", "financial-analyst"],
        )

        result = handoff.execute_handoff(ctx, mock_runtime)

        assert result.content == "Analysis complete: positive outlook"
        assert "financial-analyst" in result.routing

        # Step 3: Record handoff
        handoff.record_handoff("test-session", ctx, result)

        mock_session_memory.save.assert_called()


class TestRoutingChainEdgeCases:
    """Edge cases for routing chain extraction."""

    def test_empty_routing_chain(self):
        """Empty routing chain when no task outputs."""
        mock_memory = Mock(spec=FileSessionMemory)
        session = SessionState(
            session_id="test",
            agent_name="agent",
            created_at="2024-01-01T00:00:00Z",
            updated_at="2024-01-01T00:00:00Z",
            messages=[],
            task_outputs=[],  # No outputs
        )
        mock_memory.load.return_value = session
        mock_memory.get_context_for_llm.return_value = []
        mock_memory.get_recent_task_outputs.return_value = []

        handoff = AgentHandoff(mock_memory)
        ctx = handoff.create_handoff(
            source_agent="a",
            target_agent="b",
            reason="test",
            session_id="test",
            task="task",
        )

        assert ctx.routing_chain == []

    def test_routing_chain_no_routing_field(self):
        """Routing chain handles outputs without routing field."""
        mock_memory = Mock(spec=FileSessionMemory)
        session = SessionState(
            session_id="test",
            agent_name="agent",
            created_at="2024-01-01T00:00:00Z",
            updated_at="2024-01-01T00:00:00Z",
            messages=[],
            task_outputs=[
                TaskOutput(task="t1", result="r1", success=True, routing=None),
            ],
        )
        mock_memory.load.return_value = session
        mock_memory.get_context_for_llm.return_value = []
        mock_memory.get_recent_task_outputs.return_value = []

        handoff = AgentHandoff(mock_memory)
        ctx = handoff.create_handoff(
            source_agent="a",
            target_agent="b",
            reason="test",
            session_id="test",
            task="task",
        )

        assert ctx.routing_chain == []

    def test_routing_chain_deduplication_preserves_order(self):
        """Routing chain deduplicates while preserving first appearance order."""
        mock_memory = Mock(spec=FileSessionMemory)
        session = SessionState(
            session_id="test",
            agent_name="agent",
            created_at="2024-01-01T00:00:00Z",
            updated_at="2024-01-01T00:00:00Z",
            messages=[],
            task_outputs=[
                TaskOutput(
                    task="t1", result="r1", success=True, routing=["c", "a", "b"]
                ),
                TaskOutput(
                    task="t2", result="r2", success=True, routing=["a", "d", "c"]
                ),
            ],
        )
        mock_memory.load.return_value = session
        mock_memory.get_context_for_llm.return_value = []
        mock_memory.get_recent_task_outputs.return_value = []

        handoff = AgentHandoff(mock_memory)
        ctx = handoff.create_handoff(
            source_agent="d",
            target_agent="e",
            reason="test",
            session_id="test",
            task="task",
        )

        # Order: c, a, b, d (first appearances)
        assert ctx.routing_chain == ["c", "a", "b", "d"]
