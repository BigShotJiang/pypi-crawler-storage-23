# Stack Research

**Domain:** Multi-Agent Development Workflow Systems with RLM-Toolkit Integration
**Researched:** 2025-02-27
**Confidence:** HIGH (Context7 verified for versions, official docs for RLM-Toolkit)

## Recommended Stack

### Core Technologies

| Technology | Version | Purpose | Why Recommended |
|------------|---------|---------|-----------------|
| **Python** | 3.10+ | Runtime | Required for modern async (`asyncio` improvements), pattern matching, and RLM-Toolkit compatibility. 3.10+ required for type union syntax (`X \| Y`) used in Pydantic v2 and DSPy. |
| **RLM-Toolkit** | 2.1.0+ | Agent Framework | Project foundation. Provides SecureAgent, EvolvingAgent, H-MEM hierarchical memory, InfiniRetri (10M+ tokens), Memory Bridge (L0-L3 hierarchy), DSPy optimization, 75 LLM providers. Replaces LangChain with security-first design. |
| **Pydantic** | 2.10+ | Data Validation | Required by RLM-Toolkit, DSPy, Pydantic AI. Pydantic v2 is Rust-based for performance. Use for all agent I/O schemas, configuration, and structured outputs. |
| **DSPy** | 2.5+ / 3.x | Prompt Optimization | Declarative LLM programming with MIPROv2 optimizer for automatic prompt tuning. Integrated into RLM-Toolkit's `optimize` module. Eliminates manual prompt engineering. |
| **SQLite** | 3.40+ | Agent Memory Storage | Native Python support via `sqlite3`. Used by RLM-Toolkit H-MEM, Memory Bridge, and OpenAI Agents SDK sessions. Zero-config, embedded, perfect for agent persistence. |

### Supporting Libraries

| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| **Pydantic AI** | 0.1+ | Type-safe Agent Framework | Alternative/complement to RLM-Toolkit for structured agent outputs. Use when you need FastAPI-like DX for agents with model-agnostic support. |
| **aiohttp** | 3.9+ | Async HTTP Client/Server | Agent-to-agent P2P communication, WebSocket connections for real-time coordination. Use for hybrid runtime orchestrator + P2P pattern. |
| **Rich** | 13.9+ | Terminal UI | CLI output formatting, progress bars, status indicators for agent execution visibility. Essential for developer experience. |
| **PyYAML** | 6.0+ | Configuration | SKILL.md parsing, config files, workflow definitions. Used by OpenCode skills system. |
| **pytest** | 8.0+ | Testing | Unit, integration, e2e tests. Use with pytest-asyncio for async agent tests. |
| **pytest-asyncio** | 0.24+ | Async Testing | Required for testing async agent methods and workflows. Use `async def test_*` with `@pytest.mark.asyncio`. |
| **SQLAlchemy** | 2.0+ | ORM (Optional) | If complex queries needed for Memory Bridge. Otherwise use raw sqlite3 for simplicity. |
| **OpenAI Python** | 1.68+ | LLM Client | Primary provider via RLM-Toolkit. Also useful for direct calls if needed. |

### Development Tools

| Tool | Purpose | Notes |
|------|---------|-------|
| **uv** | Package Manager | Fast Python package installer (10-100x faster than pip). Use for dependency management. |
| **ruff** | Linter/Formatter | Replaces flake8, isort, black. Rust-based, extremely fast. Configure in `pyproject.toml`. |
| **mypy** | Type Checker | Essential for Pydantic models and agent I/O contracts. Use `--strict` for production. |

## Installation

```bash
# Core (using uv for speed)
uv pip install rlm-toolkit>=2.1.0 pydantic>=2.10 dspy-ai>=2.5 aiohttp>=3.9 rich>=13.9 pyyaml>=6.0

# Testing
uv pip install pytest>=8.0 pytest-asyncio>=0.24 pytest-cov

# Development
uv pip install ruff mypy

# Alternative: requirements.txt
cat > requirements.txt << 'EOF'
rlm-toolkit>=2.1.0
pydantic>=2.10
dspy-ai>=2.5
aiohttp>=3.9
rich>=13.9
pyyaml>=6.0
pytest>=8.0
pytest-asyncio>=0.24
ruff>=0.8
mypy>=1.13
EOF
```

## Alternatives Considered

| Recommended | Alternative | When to Use Alternative |
|-------------|-------------|-------------------------|
| **RLM-Toolkit** | LangChain/LangGraph | If you need LangGraph's durable execution and don't need built-in security. LangGraph better for pure graph-based workflows without agent security requirements. |
| **RLM-Toolkit** | CrewAI | If you want role-based agent abstraction with flows. CrewAI has excellent DX but lacks RLM-Toolkit's memory systems and security. |
| **RLM-Toolkit** | OpenAI Agents SDK | If committed to OpenAI-only stack. SDK has SQLiteSession, handoffs, guardrails but lacks RLM-Toolkit's H-MEM and InfiniRetri. |
| **SQLite** | PostgreSQL | If you need multi-writer concurrent access at scale. SQLite is single-writer but sufficient for single-user agent workflows. |

## What NOT to Use

| Avoid | Why | Use Instead |
|-------|-----|-------------|
| **LangChain Core** | Heavy abstraction, callback hell, poor performance. RLM-Toolkit is specifically designed as a LangChain replacement with security. | RLM-Toolkit providers and agents |
| **Centralized Orchestrator Only** | Creates bottleneck, single point of failure, doesn't scale. PROJECT.md specifies hybrid runtime (orchestrator + P2P). | Hybrid: thin orchestrator for coordination, P2P for agent communication |
| **LangGraph StateGraph** | Overkill for GSD-style wave execution. Adds complexity without benefit for this use case. | GSD wave execution pattern with RLM-Toolkit agents |
| **CrewAI Hierarchical Process** | Manager agent pattern conflicts with decentralized RLM-Toolkit design. | P2P agent communication with RLM-Toolkit's SecureAgent |
| **Global Shared State** | Context degradation, race conditions, debugging nightmare. | Per-agent context via RLM-Toolkit Memory Bridge, fresh context per spawn |
| **LangSmith/LangFuse** | Vendor lock-in, doesn't integrate with RLM-Toolkit observability. | RLM-Toolkit's built-in `observability` module (tracer, cost_tracker, exporters) |

## Stack Patterns by Variant

**If building for OpenCode integration:**
- Use OpenCode skills system (`SKILL.md` + scripts)
- Commands for user-facing orchestration (`/gsd-rlm-*`)
- RLM-Toolkit agents as skill implementations
- JSON config for skill parameters

**If building standalone CLI:**
- Use Rich for terminal UI
- Typer or Click for CLI framework
- RLM-Toolkit CLI module (`rlm_toolkit.cli`)
- SQLite for all persistence

**If building API/Service:**
- Use FastAPI (Pydantic native)
- aiohttp for agent-to-agent WebSockets
- RLM-Toolkit as async agent runtime
- Redis optional for distributed state

## RLM-Toolkit Module Reference

Based on AISecurity-rlm-v2.3.1 source analysis:

| Module | Components | Purpose |
|--------|------------|---------|
| `rlm_toolkit.agents` | SecureAgent, EvolvingAgent, SecureEvolvingAgent | Multi-agent runtime with security and self-improvement |
| `rlm_toolkit.memory_bridge` | L0-L3 hierarchy, TTL, router, embeddings | Project-level persistent context |
| `rlm_toolkit.retrieval` | InfiniRetri, embeddings | Infinite context processing (10M+ tokens, 56x compression) |
| `rlm_toolkit.optimize` | DSPy integration, MIPROv2 | Prompt optimization |
| `rlm_toolkit.providers` | OpenAI, Ollama, Anthropic, Google, 75+ providers | LLM provider abstraction |
| `rlm_toolkit.storage` | SQLite backend | Persistent storage |
| `rlm_toolkit.crystal` | Extractor, compressor, hierarchy, indexer | Context extraction and compression |
| `rlm_toolkit.observability` | Tracer, cost_tracker, exporters | Observability and monitoring |
| `rlm_toolkit.security` | Virtual FS, platform guards, attack detector | Security sandboxing |
| `rlm_toolkit.mcp` | MCP server | Model Context Protocol integration |
| `rlm_toolkit.testing` | Mocks, fixtures | Testing utilities |

## Version Compatibility

| Package A | Compatible With | Notes |
|-----------|-----------------|-------|
| Python 3.10+ | Pydantic 2.x | Required for `X \| Y` type union syntax |
| Pydantic 2.x | DSPy 2.5+ | DSPy uses Pydantic for signatures |
| RLM-Toolkit 2.1+ | Python 3.10+ | Uses modern async patterns |
| pytest-asyncio 0.24+ | pytest 8.0+ | Required for async test support |
| aiohttp 3.9+ | Python 3.10+ | Native async/await support |

## Context Engineering Patterns (from GSD)

The GSD system demonstrates effective patterns that should be preserved:

1. **Thin Orchestrator Pattern**
   - Orchestrator spawns specialized agents
   - Each agent gets fresh context (no degradation)
   - Orchestrator coordinates but doesn't execute

2. **Wave Execution**
   - Parallel execution for independent tasks
   - Sequential for dependencies
   - Dependency resolution built-in

3. **Atomic Commits**
   - Each task produces a commit
   - Traceability from requirement to code
   - Easy rollback if needed

4. **Structured XML Prompts**
   - Context engineering with clear sections
   - Role definitions, constraints, output formats
   - Reduces ambiguity in agent instructions

## Sources

- **Context7 `/stanfordnlp/dspy`** — DSPy MIPROv2 optimizer, prompt optimization patterns
- **Context7 `/pydantic/pydantic`** — Pydantic v2 data validation, BaseModel patterns
- **Context7 `/pydantic/pydantic-ai`** — Type-safe agent framework, structured outputs
- **Context7 `/openai/openai-agents-python`** — Multi-agent workflows, handoffs, guardrails, sessions
- **Context7 `/crewaiinc/crewai`** — Multi-agent orchestration, hierarchical process, flows
- **Context7 `/langchain-ai/langgraph`** — State graph-based orchestration (analyzed, not recommended)
- **Context7 `/aio-libs/aiohttp`** — Async HTTP, WebSocket patterns
- **Context7 `/pytest-dev/pytest`** — Testing framework, fixtures, parametrization
- **Context7 `/textualize/rich`** — Terminal UI, progress bars
- **AISecurity-rlm-v2.3.1 source** — RLM-Toolkit module structure, H-MEM, InfiniRetri, Memory Bridge
- **GSD new-project.md** — Orchestrator patterns, wave execution, agent spawning

---
*Stack research for: Multi-Agent Development Workflow with RLM-Toolkit Integration*
*Researched: 2025-02-27*
