# Architecture Research

**Domain:** Multi-Agent Development Workflow Systems
**Researched:** 2025-02-27
**Confidence:** HIGH (Context7 + official GSD documentation)

## Standard Architecture

### System Overview

Multi-agent development workflow systems follow a layered architecture with three primary coordination patterns:

```
┌─────────────────────────────────────────────────────────────────────┐
│                        USER INTERFACE LAYER                         │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────────────┐ │
│  │   Commands     │  │    Skills      │  │    Orchestrators       │ │
│  │  (/gsd-*)      │  │  (SKILL.md)    │  │   (Command handlers)   │ │
│  └───────┬────────┘  └───────┬────────┘  └───────────┬────────────┘ │
├──────────┴───────────────────┴────────────────────────┴─────────────┤
│                     COORDINATION LAYER                              │
│  ┌─────────────────────────────────────────────────────────────────┐│
│  │              Hybrid Orchestrator + P2P Router                    ││
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  ││
│  │  │   Wave      │  │ Dependency  │  │    Agent Spawner/       │  ││
│  │  │  Scheduler  │  │   Resolver  │  │      Task Router        │  ││
│  │  └─────────────┘  └─────────────┘  └─────────────────────────┘  ││
│  └─────────────────────────────────────────────────────────────────┘│
├─────────────────────────────────────────────────────────────────────┤
│                        AGENT LAYER                                  │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │
│  │  Researcher │  │   Planner   │  │   Executor  │  │  Verifier  │ │
│  │   Agent     │  │   Agent     │  │    Agent    │  │   Agent    │ │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └─────┬──────┘ │
├─────────┴────────────────┴────────────────┴────────────────┴────────┤
│                        MEMORY LAYER                                 │
│  ┌─────────────────────────────────────────────────────────────────┐│
│  │                    H-MEM + Memory Bridge                         ││
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐   ││
│  │  │  Episodic    │  │   Semantic   │  │   Project Context    │   ││
│  │  │  Memory      │  │   Retrieval  │  │   (Memory Bridge)    │   ││
│  │  └──────────────┘  └──────────────┘  └──────────────────────┘   ││
│  └─────────────────────────────────────────────────────────────────┘│
├─────────────────────────────────────────────────────────────────────┤
│                      INFRASTRUCTURE LAYER                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │
│  │  LLM        │  │   State     │  │    Git      │  │   Storage  │ │
│  │  Providers  │  │  Checkpoint │  │  Integration│  │  (SQLite)  │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

### Component Responsibilities

| Component | Responsibility | Typical Implementation |
|-----------|----------------|------------------------|
| **Commands** | User-facing orchestration interface, triggers workflows | `/gsd-*` command handlers with argument parsing |
| **Skills** | Reusable agent capabilities, packaged behaviors | SKILL.md definitions with scripts/rules |
| **Orchestrator** | Coordinates multi-agent execution, manages state | Thin coordinator that spawns specialized agents |
| **Wave Scheduler** | Groups parallel-executable tasks by dependency | Dependency graph analysis, wave assignment |
| **Agent Spawner** | Creates fresh agent instances with isolated context | Task-based agent spawning with model selection |
| **Researcher Agent** | Investigates domain ecosystem, produces research | Parallel researchers (stack, features, architecture, pitfalls) |
| **Planner Agent** | Creates executable phase plans with task breakdown | Goal-backward methodology, dependency analysis |
| **Executor Agent** | Implements plans atomically with deviation handling | Auto-fix rules, checkpoint protocols, git commits |
| **Verifier Agent** | Validates goal achievement vs task completion | Three-level artifact verification (exists, substantive, wired) |
| **H-MEM** | Hierarchical agent memory (Episode→Trace→Category→Domain) | Long-term learning, experience compression |
| **Memory Bridge** | Project-level persistent context (L0-L3) | Git-based fact persistence, semantic routing |
| **InfiniRetri** | Unlimited context processing (10M+ tokens) | 56x compression through semantic routing |

## Recommended Project Structure

```
src/
├── orchestrators/           # Workflow coordinators
│   ├── new-project.ts       # Project initialization workflow
│   ├── plan-phase.ts        # Phase planning workflow
│   ├── execute-phase.ts     # Phase execution workflow
│   └── verify-phase.ts      # Phase verification workflow
├── agents/                  # Specialized agent definitions
│   ├── researcher/          # Domain research agents
│   │   ├── stack.ts         # Technology stack researcher
│   │   ├── features.ts      # Feature landscape researcher
│   │   ├── architecture.ts  # Architecture patterns researcher
│   │   └── pitfalls.ts      # Domain pitfalls researcher
│   ├── planner.ts           # Plan creation agent
│   ├── executor.ts          # Plan execution agent
│   ├── verifier.ts          # Goal verification agent
│   └── synthesizer.ts       # Research synthesis agent
├── memory/                  # Memory systems
│   ├── h-mem/               # Hierarchical agent memory
│   │   ├── episode.ts       # Episode storage
│   │   ├── trace.ts         # Trace aggregation
│   │   ├── category.ts      # Category organization
│   │   └── domain.ts        # Domain knowledge
│   ├── bridge/              # Memory Bridge
│   │   ├── l0-session.ts    # Session context
│   │   ├── l1-phase.ts      # Phase context
│   │   ├── l2-project.ts    # Project context
│   │   └── l3-workspace.ts  # Workspace context
│   └── retrieval/           # Context retrieval
│       ├── infini-retri.ts  # Infinite context processing
│       └── semantic-router.ts # Semantic context routing
├── coordination/            # Multi-agent coordination
│   ├── wave-scheduler.ts    # Parallel wave execution
│   ├── dependency-resolver.ts # Dependency graph analysis
│   ├── p2p-router.ts        # Agent-to-agent communication
│   └── state-checkpoint.ts  # State persistence
├── skills/                  # Reusable capabilities
│   ├── gsd-rlm-*/           # GSD-RLM specific skills
│   │   └── SKILL.md         # Skill definition
│   └── scripts/             # Skill helper scripts
├── commands/                # User-facing commands
│   └── gsd-rlm-*.ts         # Command implementations
├── providers/               # LLM provider integrations
│   ├── base.ts              # Provider interface
│   ├── openai.ts            # OpenAI provider
│   ├── anthropic.ts         # Anthropic provider
│   └── ollama.ts            # Local Ollama provider
└── infrastructure/          # Core infrastructure
    ├── git-hooks.ts         # Git auto-extraction hooks
    ├── storage.ts           # SQLite storage layer
    └── config.ts            # Configuration management
```

### Structure Rationale

- **orchestrators/**: Thin coordinators that spawn agents - follows GSD pattern of "orchestrator spawns, agent executes"
- **agents/**: Specialized roles with isolated context - each agent type has specific tools and responsibilities
- **memory/**: Dual memory systems - H-MEM for agent learning, Bridge for project persistence
- **coordination/**: Wave-based execution enables parallelization while respecting dependencies
- **skills/**: Packaged capabilities with SKILL.md definitions for discoverability
- **commands/**: User-facing interface following OpenCode command pattern

## Architectural Patterns

### Pattern 1: Hybrid Orchestrator + P2P

**What:** Central orchestrator coordinates workflow phases, but agents communicate peer-to-peer for task-level collaboration.

**When to use:** Complex workflows requiring both coordination and flexibility. Best for development workflows with clear phases but dynamic task interactions.

**Trade-offs:**
- ✅ Combines coordination benefits of hierarchical with flexibility of P2P
- ✅ Reduces orchestrator bottleneck for agent-to-agent communication
- ✅ Enables parallel execution with dependency awareness
- ⚠️ More complex than pure hierarchical
- ⚠️ Requires careful state management between coordination and P2P layers

**Example:**
```python
# Orchestrator spawns agents with context
orchestrator.spawn("researcher", task=research_task, model=smart_model)
orchestrator.spawn("planner", task=planning_task, depends_on=["researcher"])

# Agents communicate P2P through shared memory/topics
class ResearcherAgent:
    def publish_findings(self, findings):
        # Publish to shared topic - other agents subscribe
        self.publish("research.complete", findings)

class PlannerAgent:
    @subscriber("research.complete")
    def on_research_complete(self, findings):
        # Receives P2P notification, builds plan
        self.create_plan(findings)
```

### Pattern 2: Wave-Based Parallel Execution

**What:** Tasks grouped into "waves" based on dependency analysis. All tasks in a wave execute in parallel; waves execute sequentially.

**When to use:** Any multi-task workflow with partial independence. Default for most development workflows.

**Trade-offs:**
- ✅ Maximizes parallelization while respecting dependencies
- ✅ Clear execution order prevents race conditions
- ✅ Easy to reason about execution flow
- ⚠️ Requires upfront dependency analysis
- ⚠️ Coarse-grained parallelism (wave-level, not task-level)

**Example:**
```yaml
# Wave assignment from dependency graph
waves:
  - wave: 1
    plans: ["01-user-model", "01-product-model"]  # Independent
  - wave: 2
    plans: ["02-user-api", "02-product-api"]      # Depend on Wave 1
  - wave: 3
    plans: ["03-dashboard"]                        # Depends on Wave 2
```

### Pattern 3: Goal-Backward Verification

**What:** Verification starts from the goal outcome and works backwards to verify artifacts and wiring, rather than checking task completion.

**When to use:** Quality-critical workflows where task completion ≠ goal achievement. Essential for development verification.

**Trade-offs:**
- ✅ Catches "file exists but is stub" problems
- ✅ Focuses on actual outcomes, not activity
- ✅ Three-level verification (exists, substantive, wired)
- ⚠️ More expensive than task-based verification
- ⚠️ Requires clear goal definition upfront

**Example:**
```yaml
must_haves:
  truths:
    - "User can see existing messages"
    - "User can send a message"
    - "Messages persist across refresh"
  artifacts:
    - path: "src/components/Chat.tsx"
      provides: "Message list rendering"
      min_lines: 30
  key_links:
    - from: "Chat.tsx"
      to: "/api/chat"
      via: "fetch in useEffect"
```

### Pattern 4: Hierarchical Memory (H-MEM)

**What:** Four-level memory hierarchy that compresses agent experiences from episodes to domain knowledge.

**When to use:** Agents that need to learn and improve over time. Long-running projects with repeated patterns.

**Trade-offs:**
- ✅ Enables agent learning and improvement
- ✅ Progressive compression reduces storage
- ✅ Domain knowledge persists across projects
- ⚠️ Requires careful compression logic
- ⚠️ May lose detail at higher levels

**Example:**
```
Episode (L0) → "Fixed auth bug by adding null check"
    ↓ (aggregation)
Trace (L1) → "Auth bugs often involve null checks"
    ↓ (categorization)
Category (L2) → "Null safety is critical for auth"
    ↓ (generalization)
Domain (L3) → "Always validate inputs before processing"
```

### Pattern 5: Memory Bridge (Project Context)

**What:** Git-backed persistent context hierarchy (L0-L3) for project-level knowledge that survives context compaction.

**When to use:** Long-running projects where context must persist across sessions. Essential for continuity.

**Trade-offs:**
- ✅ Context survives agent restarts
- ✅ Git integration provides version history
- ✅ Hierarchical scoping (session → workspace)
- ⚠️ Git operations add latency
- ⚠️ Merge conflicts possible on concurrent access

**Example:**
```
L0 (Session)  → Current conversation state
L1 (Phase)    → Current phase decisions and progress
L2 (Project)  → PROJECT.md, REQUIREMENTS.md, ROADMAP.md
L3 (Workspace) → Cross-project patterns and preferences
```

## Data Flow

### Request Flow

```
User Action (/gsd-new-project)
    ↓
Command Handler → Orchestrator → Agent Spawner
    ↓                    ↓              ↓
Config Load      Dependency Check   Fresh Context
    ↓                    ↓              ↓
Agent Selection ← Wave Assignment ← Task Parsing
    ↓
Parallel Agent Spawn (researchers, planner, etc.)
    ↓                    ↓              ↓
P2P Communication ← Shared Memory ← State Updates
    ↓
Result Aggregation → Verification → Git Commit
```

### State Management

```
[STATE.md]
    ↓ (read at spawn)
[Agent Context] ←→ [H-MEM] ←→ [Memory Bridge]
    ↓                    ↓              ↓
[Task Execution] → [Episode Storage] → [Git Persistence]
    ↓
[State Update] → [Checkpoint] → [STATE.md Update]
```

### Key Data Flows

1. **Orchestration Flow:** Command → Orchestrator → Wave Scheduler → Agent Spawner → Parallel Agents
2. **Memory Flow:** Agent Execution → Episode (L0) → Trace (L1) → Category (L2) → Domain (L3)
3. **Context Flow:** Memory Bridge (L2) → Semantic Router → Compressed Context → Agent Prompt
4. **Verification Flow:** Goal → Truths → Artifacts → Wiring → Status Report
5. **Persistence Flow:** State Changes → Git Hooks → Memory Bridge → Git Commit

## Scaling Considerations

| Scale | Architecture Adjustments |
|-------|--------------------------|
| **Single project** | Single orchestrator, local H-MEM, in-memory state |
| **Multiple projects** | Per-project Memory Bridge, shared domain memory (L3) |
| **Team usage** | Centralized Memory Bridge server, conflict resolution |
| **Enterprise** | Distributed orchestrators, sharded memory, audit logging |

### Scaling Priorities

1. **First bottleneck:** Context window limits → InfiniRetri + semantic compression (56x)
2. **Second bottleneck:** Sequential execution → Wave parallelization + dependency resolution
3. **Third bottleneck:** Memory growth → Hierarchical compression (Episode → Domain)
4. **Fourth bottleneck:** Agent coordination overhead → P2P communication bypassing orchestrator

## Anti-Patterns

### Anti-Pattern 1: Monolithic Orchestrator

**What people do:** Single orchestrator handles all coordination, all agents report back through it.

**Why it's wrong:** Creates bottleneck, doesn't scale, single point of failure, limits parallelism.

**Do this instead:** Thin orchestrator spawns agents, agents communicate P2P through topics/shared memory. Orchestrator coordinates phases, not every interaction.

### Anti-Pattern 2: Task-Based Verification

**What people do:** Check that tasks were completed (files created, commands run).

**Why it's wrong:** Task completion ≠ goal achievement. Files can exist but be stubs. Connections can be missing.

**Do this instead:** Goal-backward verification. Start from "what must be TRUE for goal to be achieved?" Verify artifacts are substantive and wired.

### Anti-Pattern 3: Flat Memory Architecture

**What people do:** Store all agent experiences in flat structure, retrieve by recency or semantic similarity only.

**Why it's wrong:** Context explosion, no learning/compression, repetitive mistakes across sessions.

**Do this instead:** Hierarchical memory (H-MEM). Episodes aggregate to traces, traces to categories, categories to domain knowledge. Progressive compression enables learning.

### Anti-Pattern 4: Context-Laden Orchestrator

**What people do:** Orchestrator accumulates all context, passes everything to spawned agents.

**Why it's wrong:** Context degradation curve - quality drops as context fills. Spawned agents inherit degraded context.

**Do this instead:** Fresh context per agent. Orchestrator passes minimal context, agents load what they need from Memory Bridge. Each agent starts at peak quality.

### Anti-Pattern 5: Synchronous Everything

**What people do:** All agent communication waits for responses, sequential execution even when independent.

**Why it's wrong:** Wastes parallelization opportunities, slow execution, underutilizes multiple LLM calls.

**Do this instead:** Wave-based execution. Analyze dependencies upfront, group independent tasks into waves, execute waves in parallel.

## Integration Points

### External Services

| Service | Integration Pattern | Notes |
|---------|---------------------|-------|
| **LLM Providers** | Provider abstraction layer | Support 75+ providers via unified interface |
| **Git** | Hook-based auto-extraction | Facts extracted on commit for Memory Bridge |
| **SQLite** | Local storage for H-MEM | Agent memory persistence |
| **File System** | Memory Bridge storage | PROJECT.md, STATE.md, REQUIREMENTS.md |

### Internal Boundaries

| Boundary | Communication | Notes |
|----------|---------------|-------|
| Orchestrator ↔ Agents | Spawn/Result | Thin orchestration, fresh agent contexts |
| Agent ↔ Agent | P2P via topics | Direct communication bypasses orchestrator |
| Agent ↔ Memory | Read/Write APIs | H-MEM for learning, Bridge for persistence |
| Wave ↔ Wave | Sequential | Waves execute in order, tasks in wave parallel |
| Command ↔ Orchestrator | Direct call | Commands delegate to orchestrators |

## Component Build Order

Based on dependencies, recommended implementation order:

### Phase 1: Foundation
1. **Infrastructure Layer** - Storage, config, provider abstraction
2. **State Checkpoint** - State persistence and recovery
3. **Agent Spawner** - Basic agent spawning capability

### Phase 2: Memory Systems
4. **H-MEM (Episode/Trace)** - Basic agent memory
5. **Memory Bridge (L0-L2)** - Project context persistence
6. **Semantic Router** - Context loading optimization

### Phase 3: Coordination
7. **Wave Scheduler** - Dependency resolution and wave assignment
8. **P2P Router** - Agent-to-agent communication
9. **Orchestrator Core** - Basic workflow coordination

### Phase 4: Agents
10. **Researcher Agent** - Domain research capability
11. **Planner Agent** - Plan creation with goal-backward
12. **Executor Agent** - Plan execution with deviation handling
13. **Verifier Agent** - Goal verification

### Phase 5: Interface
14. **Skills System** - SKILL.md definitions and loading
15. **Commands** - User-facing /gsd-* commands
16. **Git Hooks** - Auto-extraction for Memory Bridge

### Phase 6: Advanced
17. **InfiniRetri** - Unlimited context processing
18. **H-MEM (Category/Domain)** - Advanced learning
19. **Memory Bridge (L3)** - Workspace-level context

## Sources

- **CrewAI Documentation** (Context7) - Multi-agent orchestration patterns, hierarchical vs sequential processes, memory systems
- **AutoGen Documentation** (Context7) - Group chat architecture, P2P agent communication via topics, distributed runtime
- **LangGraph Documentation** (Context7) - State management, checkpointing, memory systems, conditional routing
- **GSD System** (Local) - Orchestrator patterns, agent definitions, wave execution, goal-backward verification
- **OpenCode Architecture** (Local) - Skills/commands pattern, agent spawning, context engineering

---

*Architecture research for: Multi-Agent Development Workflow Systems*
*Researched: 2025-02-27*
