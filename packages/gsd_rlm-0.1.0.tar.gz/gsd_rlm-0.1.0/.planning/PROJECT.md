# GSD-RLM: Multi-Agent Development Workflow

## What This Is

Universal multi-agent development workflow system built on RLM-Toolkit, integrated with OpenCode. Orchestrates specialized AI agents (researchers, planners, executors, verifiers) through spec-driven development process with infinite context capabilities and self-evolving optimization.

Works for any programming language and project type - from Python web apps to enterprise systems. Each agent has access to hierarchical memory (H-MEM), semantic context routing, and can improve its performance through usage.

## Core Value

Transform project ideas into production-ready code through coordinated multi-agent execution with infinite context, persistent memory, and self-improving agents - eliminating context degradation and manual coordination overhead.

## Requirements

### Validated

(None yet — ship to validate)

### Active

- [ ] Core workflow: new-project → discuss → plan → execute → verify → complete
- [ ] Hybrid runtime: orchestrator coordinates, agents communicate P2P
- [ ] H-MEM integration for agent memory (Episode→Trace→Category→Domain)
- [ ] Memory Bridge integration for project context (L0-L3 hierarchy)
- [ ] InfiniRetri for infinite context processing (10M+ tokens)
- [ ] Semantic routing for context loading (56x compression)
- [ ] Git auto-extraction hooks for fact persistence
- [ ] OpenCode integration: Skills (gsd-rlm-*) + Commands (/gsd-rlm-*)
- [ ] SecureAgent with Trust Zones and encryption
- [ ] EvolvingAgent with R-Zero self-improvement
- [ ] SecureEvolvingAgent combining security + evolution
- [ ] DSPy-style prompt optimization
- [ ] Parallel wave execution with dependency resolution
- [ ] Atomic git commits per task
- [ ] Full test coverage (unit, integration, e2e)
- [ ] Complete documentation (README, API docs, guides, examples)

### Out of Scope

- Mobile applications — initial focus on desktop/server workflows
- Real-time collaboration features — single-user development focus initially
- Cloud deployment orchestration — workflow runs locally first
- Non-OpenCode runtimes — Claude Code, Gemini, Codex not in v1

## Context

**Foundation:** RLM-Toolkit v2.1.0+ provides the core building blocks:
- `rlm_toolkit.agents` — Multi-agent runtime (SecureAgent, EvolvingAgent)
- `rlm_toolkit.memory` — H-MEM hierarchical memory system
- `rlm_toolkit.memory_bridge` — Project-level persistent context
- `rlm_toolkit.retrieval` — InfiniRetri for unlimited context
- `rlm_toolkit.optimize` — DSPy-style prompt optimization
- `rlm_toolkit.providers` — 75 LLM providers

**Inspiration:** Get-Shit-Done (GSD) system demonstrates effective multi-agent orchestration patterns:
- Thin orchestrator spawns specialized agents
- Context engineering with structured XML prompts
- Fresh context per agent prevents degradation
- Atomic commits with traceability
- Wave execution for parallel/sequential balance

**Integration Point:** OpenCode skills system allows packaging agents as reusable capabilities with SKILL.md definitions. Commands provide user-facing orchestration interface.

## Constraints

- **Python Runtime:** RLM-Toolkit is Python-based — agents execute in Python environment
- **OpenCode Required:** Integration targets OpenCode specifically (not Claude Code/Gemini)
- **LLM Dependency:** Requires configured LLM provider (Ollama local, OpenAI, Anthropic, etc.)
- **Memory Storage:** Persistent memory requires local storage (SQLite/JSON for H-MEM, Git for Bridge)

## Key Decisions

| Decision | Rationale | Outcome |
|----------|-----------|---------|
| Hybrid runtime (orchestrator + P2P) | Combines GSD coordination with RLM decentralized benefits | — Pending |
| H-MEM + Memory Bridge combo | H-MEM for agent learning, Bridge for project persistence | — Pending |
| Skills + Commands integration | Skills for agent capabilities, Commands for workflow control | — Pending |
| All agent types (Secure + Evolving + Optimized) | Maximum flexibility for different use cases | — Pending |
| Full test + doc coverage | Production-ready from day one | — Pending |

---
*Last updated: 2025-02-27 after initialization*
