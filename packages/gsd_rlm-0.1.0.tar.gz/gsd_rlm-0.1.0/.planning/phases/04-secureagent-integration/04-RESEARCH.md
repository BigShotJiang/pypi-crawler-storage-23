# Phase 4: SecureAgent Integration - Research

**Researched:** 2026-02-27
**Domain:** Security (encryption, access control, trust zones)
**Confidence:** HIGH

## Summary

Phase 4 implements security for the GSD-RLM multi-agent system through encrypted memory storage and trust zone boundaries. The primary technical domains are:

1. **AES-256-GCM Encryption** - Using Python's `cryptography` library for encrypting agent memories at rest
2. **Trust Zone Model** - A hierarchical access control system for agent isolation
3. **Access Control Lists** - User-managed permissions for cross-zone operations

The existing codebase provides excellent patterns to follow: Pydantic models with strict validation (`extra='forbid'`), SQLite-backed persistence, atomic file writes, and comprehensive pytest coverage. The security layer should integrate seamlessly with the existing `EpisodeStore` and `MemoryBridge` systems.

**Primary recommendation:** Use the `cryptography` library's `AESGCM` class directly (not Fernet) for AES-256-GCM encryption, allowing explicit control over IV/nonce generation and associated data for trust zone context binding.

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| `cryptography` | 42.0+ | AES-256-GCM encryption | Industry standard, pyca-maintained, extensive docs |
| `pydantic` | 2.0+ | Security model validation | Already used throughout codebase |
| `sqlite3` | stdlib | Encrypted memory persistence | Already used in EpisodeStore |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| `secrets` | stdlib | Secure random generation | Key/IV generation, token creation |
| `hashlib` | stdlib | Key derivation | PBKDF2 for password-to-key conversion |
| `typing` | stdlib | Protocol definitions | TrustZone interface definitions |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| `cryptography.AESGCM` | `cryptography.Fernet` | Fernet is simpler but uses AES-128-CBC internally; we need AES-256-GCM explicitly per SEC-01 |
| `cryptography.AESGCM` | `PyCryptodome` | PyCryptodome is a drop-in replacement but `cryptography` is more actively maintained by pyca |
| Custom key storage | OS keyring (keyring lib) | OS keyring is more secure but adds external dependency; start with encrypted file storage |

**Installation:**
```bash
pip install cryptography>=42.0.0
# No additional packages needed - pydantic and sqlite3 already in use
```

## Architecture Patterns

### Recommended Project Structure
```
src/gsd_rlm/
├── security/
│   ├── __init__.py           # Exports: SecureAgent, TrustZone, ZoneAccessManager
│   ├── encryption.py         # AES-256-GCM encryptor/decryptor (SEC-01)
│   ├── trust_zones.py        # TrustZone enum and ZoneAssignment (SEC-02)
│   ├── access_control.py     # ZoneAccessManager, AccessGrant (SEC-03, SEC-04)
│   └── secure_storage.py     # EncryptedEpisodeStore wrapper
└── agents/
    └── secure_agent.py       # SecureAgent class extending base agent
```

### Pattern 1: AES-256-GCM Encryption Service

**What:** A singleton encryption service that manages keys and provides encrypt/decrypt operations for agent memories.

**When to use:** All persistent memory storage operations (episodes, traces, categories, domain knowledge).

**Example:**
```python
# Source: Context7 /pyca/cryptography - AES-GCM encryption
import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from dataclasses import dataclass
from typing import Optional

@dataclass
class EncryptedData:
    """Container for encrypted data with IV and tag."""
    iv: bytes  # 12 bytes for GCM
    ciphertext: bytes  # Includes authentication tag
    associated_data: Optional[bytes] = None

class MemoryEncryptor:
    """AES-256-GCM encryptor for agent memories (SEC-01)."""
    
    KEY_SIZE = 32  # 256 bits
    IV_SIZE = 12   # 96 bits (recommended for GCM)
    
    def __init__(self, key: Optional[bytes] = None):
        """Initialize with existing key or generate new one."""
        self.key = key or os.urandom(self.KEY_SIZE)
        self._aesgcm = AESGCM(self.key)
    
    @classmethod
    def generate_key(cls) -> bytes:
        """Generate a new encryption key."""
        return os.urandom(cls.KEY_SIZE)
    
    def encrypt(
        self, 
        plaintext: bytes, 
        associated_data: Optional[bytes] = None
    ) -> EncryptedData:
        """Encrypt plaintext with optional associated data for binding context."""
        iv = os.urandom(self.IV_SIZE)
        ciphertext = self._aesgcm.encrypt(iv, plaintext, associated_data)
        return EncryptedData(iv=iv, ciphertext=ciphertext, associated_data=associated_data)
    
    def decrypt(self, encrypted: EncryptedData) -> bytes:
        """Decrypt and verify integrity. Raises InvalidTag if tampered."""
        return self._aesgcm.decrypt(
            encrypted.iv, 
            encrypted.ciphertext, 
            encrypted.associated_data
        )
```

### Pattern 2: Trust Zone Model

**What:** A hierarchical trust zone system with clear security boundaries.

**When to use:** Agent assignment, cross-zone operation validation, access control decisions.

**Example:**
```python
# Trust zone enum following existing Enum patterns in codebase
from enum import Enum
from pydantic import BaseModel, Field
from typing import Set, Dict, List, Optional
from datetime import datetime

class TrustZone(str, Enum):
    """Trust zone levels for agent isolation (SEC-02)."""
    
    PUBLIC = "public"           # Fully shared, no restrictions
    INTERNAL = "internal"       # Project-level sharing
    CONFIDENTIAL = "confidential"  # Phase-specific, limited access
    SECRET = "secret"           # Agent-specific, no sharing
    
    @property
    def priority(self) -> int:
        """Higher priority = more restricted."""
        return {"public": 0, "internal": 1, "confidential": 2, "secret": 3}[self.value]
    
    def allows_access_from(self, source: "TrustZone") -> bool:
        """Check if source zone can access this zone's data."""
        return source.priority >= self.priority


class ZoneAssignment(BaseModel):
    """Agent-to-zone assignment with metadata (SEC-02)."""
    
    model_config = {"extra": "forbid"}
    
    agent_id: str = Field(..., min_length=1)
    zone: TrustZone
    assigned_at: datetime = Field(default_factory=datetime.utcnow)
    assigned_by: str = "system"  # User or system that made assignment
    
    # Optional context for why this zone was assigned
    reason: Optional[str] = None
```

### Pattern 3: Access Control Manager

**What:** User-managed access grants for cross-zone operations.

**When to use:** When SEC-03 requires user to grant/revoke access between agents.

**Example:**
```python
# Access control following existing Pydantic patterns
from pydantic import BaseModel, Field
from typing import Dict, Set, Optional
from datetime import datetime

class AccessGrant(BaseModel):
    """A grant allowing cross-zone access (SEC-03)."""
    
    model_config = {"extra": "forbid"}
    
    grant_id: str = Field(..., min_length=1)
    source_agent_id: str
    target_agent_id: str
    granted_by: str  # User ID who granted access
    granted_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = None
    
    # What operations are allowed
    allowed_operations: Set[str] = Field(default_factory=lambda: {"read"})
    
    def is_expired(self) -> bool:
        """Check if grant has expired."""
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at


class ZoneAccessManager:
    """Manages cross-zone access grants and validation (SEC-03, SEC-04)."""
    
    def __init__(self):
        self._grants: Dict[str, AccessGrant] = {}
        self._agent_zones: Dict[str, TrustZone] = {}
    
    def assign_agent_to_zone(self, agent_id: str, zone: TrustZone) -> None:
        """Assign an agent to a trust zone."""
        self._agent_zones[agent_id] = zone
    
    def grant_access(
        self,
        source_agent_id: str,
        target_agent_id: str,
        granted_by: str,
        allowed_operations: Optional[Set[str]] = None,
        expires_at: Optional[datetime] = None,
    ) -> AccessGrant:
        """Grant cross-zone access (SEC-03)."""
        import uuid
        grant = AccessGrant(
            grant_id=str(uuid.uuid4()),
            source_agent_id=source_agent_id,
            target_agent_id=target_agent_id,
            granted_by=granted_by,
            allowed_operations=allowed_operations or {"read"},
            expires_at=expires_at,
        )
        self._grants[grant.grant_id] = grant
        return grant
    
    def revoke_access(self, grant_id: str) -> bool:
        """Revoke cross-zone access (SEC-03)."""
        if grant_id in self._grants:
            del self._grants[grant_id]
            return True
        return False
    
    def validate_access(
        self,
        source_agent_id: str,
        target_agent_id: str,
        operation: str = "read",
    ) -> bool:
        """Validate cross-zone access (SEC-04)."""
        # Same agent always has access
        if source_agent_id == target_agent_id:
            return True
        
        # Get zones
        source_zone = self._agent_zones.get(source_agent_id)
        target_zone = self._agent_zones.get(target_agent_id)
        
        if source_zone is None or target_zone is None:
            return False
        
        # Check hierarchical access (higher zones can access lower)
        if source_zone.allows_access_from(target_zone):
            return True
        
        # Check explicit grants
        for grant in self._grants.values():
            if (grant.source_agent_id == source_agent_id and
                grant.target_agent_id == target_agent_id and
                not grant.is_expired() and
                operation in grant.allowed_operations):
                return True
        
        return False
```

### Pattern 4: Secure Storage Wrapper

**What:** Wrapper around existing EpisodeStore that encrypts/decrypts transparently.

**When to use:** All H-MEM storage operations to ensure encryption at rest.

**Example:**
```python
# Following existing EpisodeStore pattern from src/gsd_rlm/memory/hmem/store.py
from gsd_rlm.memory.hmem import Episode, EpisodeStore
from gsd_rlm.security.encryption import MemoryEncryptor, EncryptedData
import json
from typing import Optional, List

class EncryptedEpisodeStore:
    """EpisodeStore wrapper with AES-256-GCM encryption (SEC-01)."""
    
    def __init__(
        self, 
        db_path: str = "memory/hmem.db",
        encryptor: Optional[MemoryEncryptor] = None,
    ):
        self._store = EpisodeStore(db_path)
        self._encryptor = encryptor or MemoryEncryptor()
    
    def store(self, episode: Episode) -> None:
        """Store episode with encrypted memory content."""
        # Encrypt sensitive fields
        episode_dict = episode.to_dict()
        
        # Encrypt context, action, outcome (the memory content)
        memory_content = json.dumps({
            "context": episode.context,
            "action": episode.action,
            "outcome": episode.outcome,
        }).encode("utf-8")
        
        encrypted = self._encryptor.encrypt(memory_content)
        
        # Create encrypted episode representation
        encrypted_episode = Episode(
            episode_id=episode.episode_id,
            agent_id=episode.agent_id,
            session_id=episode.session_id,
            episode_type=episode.episode_type,
            # Store encrypted data as base64 in context field
            context=self._encode_encrypted(encrypted),
            action="[ENCRYPTED]",
            outcome="[ENCRYPTED]",
            success=episode.success,
            timestamp=episode.timestamp,
            tokens_used=episode.tokens_used,
            duration_ms=episode.duration_ms,
            # Embedding and tags are NOT encrypted (metadata)
            embedding=episode.embedding,
            tags=episode.tags + ["encrypted"],
            trace_id=episode.trace_id,
        )
        
        self._store.store(encrypted_episode)
    
    def get(self, episode_id: str) -> Optional[Episode]:
        """Retrieve and decrypt episode."""
        encrypted_episode = self._store.get(episode_id)
        if encrypted_episode is None:
            return None
        
        # Check if encrypted
        if "encrypted" not in encrypted_episode.tags:
            return encrypted_episode
        
        # Decrypt memory content
        encrypted = self._decode_encrypted(encrypted_episode.context)
        memory_content = self._encryptor.decrypt(encrypted)
        memory_dict = json.loads(memory_content.decode("utf-8"))
        
        # Return decrypted episode
        return Episode(
            episode_id=encrypted_episode.episode_id,
            agent_id=encrypted_episode.agent_id,
            session_id=encrypted_episode.session_id,
            episode_type=encrypted_episode.episode_type,
            context=memory_dict["context"],
            action=memory_dict["action"],
            outcome=memory_dict["outcome"],
            success=encrypted_episode.success,
            timestamp=encrypted_episode.timestamp,
            tokens_used=encrypted_episode.tokens_used,
            duration_ms=encrypted_episode.duration_ms,
            embedding=encrypted_episode.embedding,
            tags=[t for t in encrypted_episode.tags if t != "encrypted"],
            trace_id=encrypted_episode.trace_id,
        )
    
    def _encode_encrypted(self, encrypted: EncryptedData) -> str:
        """Encode encrypted data as base64 string."""
        import base64
        return base64.b64encode(
            encrypted.iv + encrypted.ciphertext
        ).decode("utf-8")
    
    def _decode_encrypted(self, encoded: str) -> EncryptedData:
        """Decode base64 string to EncryptedData."""
        import base64
        data = base64.b64decode(encoded.encode("utf-8"))
        return EncryptedData(
            iv=data[:12],  # First 12 bytes are IV
            ciphertext=data[12:],  # Rest is ciphertext + tag
        )
```

### Anti-Patterns to Avoid

- **Storing encryption keys in code or config files:** Keys should be stored securely (environment variables, key files with restricted permissions, or external key management)
- **Reusing IVs/nonces:** Each encryption operation MUST use a unique random IV; IV reuse completely breaks GCM security
- **Encrypting at wrong layer:** Don't encrypt individual fields - encrypt the entire memory payload for efficiency and security
- **Ignoring associated data:** Use associated data to bind trust zone context to encrypted data for tamper resistance
- **Silent access denial:** Always log trust zone violations with context for debugging and auditing

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|------|
| Encryption | Custom AES implementation | `cryptography.AESGCM` | Side-channel vulnerabilities, padding oracle attacks |
| Random number generation | `random` module | `secrets` or `os.urandom` | `random` is not cryptographically secure |
| Key derivation | Custom hash iterations | `PBKDF2HMAC` from cryptography | Proper salt handling, configurable iterations |
| Access control | Custom permission matrix | `ZoneAccessManager` pattern | Audit logging, expiration, explicit grants |
| IV/nonce generation | Sequential or timestamp-based | `os.urandom(12)` | Predictability enables attacks |

**Key insight:** Security code is the worst place for "not invented here" syndrome. Every custom implementation is a potential vulnerability. Use well-audited libraries.

## Common Pitfalls

### Pitfall 1: IV Reuse in GCM Mode
**What goes wrong:** Using the same IV with the same key for multiple encryptions allows attackers to recover the authentication key and forge messages.
**Why it happens:** Developers may try to use sequential IVs or derive IVs from data to save space.
**How to avoid:** Always use `os.urandom(12)` for GCM IVs. Never reuse a key-IV pair.
**Warning signs:** IVs that look sequential, IVs derived from timestamps, IV stored separately from key.

### Pitfall 2: Key Storage in Code
**What goes wrong:** Hardcoded keys can be extracted from source code, compiled binaries, or Docker images.
**Why it happens:** Convenience during development, forgotten TODO comments.
**How to avoid:** 
1. Generate keys at runtime with `MemoryEncryptor.generate_key()`
2. Store keys in files with 0600 permissions
3. Load key paths from environment variables
4. Consider OS keyring for production
**Warning signs:** `key = "..."` or `KEY = b"..."` in source files.

### Pitfall 3: Trust Zone Bypass via Metadata
**What goes wrong:** Agents in restricted zones might access data through unencrypted metadata fields (tags, timestamps).
**Why it happens:** Forgetting that metadata can leak information.
**How to avoid:** Apply trust zone checks to ALL data access, not just primary content. Consider encrypting metadata if it could be sensitive.
**Warning signs:** Accessing `episode.tags` without zone validation, using `embedding` vectors without zone checks.

### Pitfall 4: Missing Audit Trail
**What goes wrong:** Security violations happen silently, making debugging impossible and compliance auditing failed.
**Why it happens:** Developers return `False` or raise exceptions without logging.
**How to avoid:** Log ALL access decisions (granted and denied) with timestamp, source agent, target agent, operation, and zone context.
**Warning signs:** `validate_access()` returning boolean without logging, no violation counter in metrics.

## Code Examples

### Complete SecureAgent Integration

```python
# Source: Derived from existing codebase patterns + cryptography library
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime

from gsd_rlm.agents.definition import AgentDefinition
from gsd_rlm.security.trust_zones import TrustZone, ZoneAssignment
from gsd_rlm.security.access_control import ZoneAccessManager
from gsd_rlm.security.encryption import MemoryEncryptor
from gsd_rlm.memory.hmem import Episode, EpisodeType

class SecureAgentConfig(BaseModel):
    """Configuration for SecureAgent (SEC-01, SEC-02)."""
    
    model_config = {"extra": "forbid"}
    
    agent_id: str
    zone: TrustZone = TrustZone.INTERNAL
    encryption_enabled: bool = True
    key_path: Optional[str] = None  # Path to encryption key file


class SecureAgent:
    """
    Agent wrapper with trust zone enforcement and encrypted memories.
    
    Implements SEC-01 (encryption), SEC-02 (trust zones), SEC-03 (access grants).
    """
    
    def __init__(
        self,
        definition: AgentDefinition,
        config: SecureAgentConfig,
        access_manager: ZoneAccessManager,
    ):
        self.definition = definition
        self.config = config
        self.agent_id = config.agent_id
        self._access_manager = access_manager
        
        # Initialize encryption if enabled
        self._encryptor: Optional[MemoryEncryptor] = None
        if config.encryption_enabled:
            if config.key_path:
                with open(config.key_path, "rb") as f:
                    key = f.read()
                self._encryptor = MemoryEncryptor(key=key)
            else:
                self._encryptor = MemoryEncryptor()
        
        # Register with access manager
        self._access_manager.assign_agent_to_zone(
            self.agent_id, 
            config.zone
        )
    
    def can_access(self, target_agent_id: str, operation: str = "read") -> bool:
        """Check if this agent can access another agent's data (SEC-04)."""
        result = self._access_manager.validate_access(
            source_agent_id=self.agent_id,
            target_agent_id=target_agent_id,
            operation=operation,
        )
        
        if not result:
            # Log violation (SEC-04 requirement)
            self._log_violation(target_agent_id, operation)
        
        return result
    
    def create_episode(
        self,
        episode_type: EpisodeType,
        context: str,
        action: str,
        outcome: str,
        success: bool = False,
        session_id: str = "",
    ) -> Episode:
        """Create an episode with encryption applied (SEC-01)."""
        episode = Episode(
            episode_id=f"ep-{self.agent_id}-{datetime.utcnow().timestamp()}",
            agent_id=self.agent_id,
            session_id=session_id,
            episode_type=episode_type,
            context=context,
            action=action,
            outcome=outcome,
            success=success,
            tags=[f"zone:{self.config.zone.value}"],
        )
        
        return episode
    
    def _log_violation(self, target_agent_id: str, operation: str) -> None:
        """Log trust zone violation for audit (SEC-04)."""
        import logging
        logger = logging.getLogger("gsd_rlm.security")
        logger.warning(
            f"Trust zone violation: agent={self.agent_id} "
            f"attempted {operation} on target={target_agent_id} "
            f"zone={self.config.zone.value}"
        )
```

### Key File Management

```python
# Source: Best practice pattern
import os
import json
from pathlib import Path
from typing import Optional
from datetime import datetime

class KeyManager:
    """Manages encryption key storage and retrieval."""
    
    KEY_FILE_PERMISSION = 0o600  # Owner read/write only
    
    def __init__(self, keys_dir: Path):
        self.keys_dir = keys_dir
        self.keys_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    
    def get_or_create_key(self, agent_id: str) -> bytes:
        """Get existing key or create new one for agent."""
        key_file = self.keys_dir / f"{agent_id}.key"
        
        if key_file.exists():
            return key_file.read_bytes()
        
        # Generate new key
        key = MemoryEncryptor.generate_key()
        
        # Write with restricted permissions
        key_file.write_bytes(key)
        os.chmod(key_file, self.KEY_FILE_PERMISSION)
        
        return key
    
    def rotate_key(self, agent_id: str) -> bytes:
        """Rotate key for agent (creates backup of old key)."""
        key_file = self.keys_dir / f"{agent_id}.key"
        
        if key_file.exists():
            # Backup old key
            backup_file = self.keys_dir / f"{agent_id}.key.{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.bak"
            key_file.rename(backup_file)
        
        return self.get_or_create_key(agent_id)
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|----------|
| AES-128-CBC (Fernet) | AES-256-GCM | Explicit requirement | GCM provides authenticated encryption, no padding attacks |
| Role-based access control | Zone-based isolation | This phase | Simpler model for multi-agent systems |
| Encrypted connections | Encrypted at rest | This phase | Memory persistence requires at-rest encryption |
| Single encryption key | Per-agent keys | This phase | Compromise isolation, key rotation support |

**Deprecated/outdated:**
- **AES-ECB mode:** Never use - patterns in plaintext visible in ciphertext
- **MD5/SHA1 for integrity:** Use GCM's built-in authentication or SHA-256+
- **Custom encryption schemes:** Always use well-audited libraries

## Open Questions

1. **Key rotation strategy for long-running agents**
   - What we know: Keys should be rotated periodically, but existing encrypted data needs re-encryption
   - What's unclear: Should rotation be automatic (time-based) or manual (user-triggered)?
   - Recommendation: Start with manual rotation via KeyManager; add automatic rotation in Phase 6

2. **Memory Bridge encryption scope**
   - What we know: Memory Bridge stores facts at L0-L3 levels in JSON/MD files
   - What's unclear: Should all Bridge facts be encrypted or only sensitive ones?
   - Recommendation: Encrypt all Bridge facts by default; allow per-fact opt-out via metadata flag

3. **Cross-zone collaboration workflows**
   - What we know: SEC-03 allows users to grant cross-zone access
   - What's unclear: Should grants be time-limited by default? What's the default expiration?
   - Recommendation: Default 24-hour expiration for cross-zone grants; configurable per-grant

## Sources

### Primary (HIGH confidence)
- `/pyca/cryptography` - AES-256-GCM encryption, Fernet, PBKDF2HMAC key derivation
- `/pydantic/pydantic` - Model validation, ConfigDict, field validators
- Project codebase: `src/gsd_rlm/memory/hmem/store.py`, `src/gsd_rlm/agents/definition.py`

### Secondary (MEDIUM confidence)
- Existing test patterns from `tests/test_memory/test_episode.py` and `tests/test_memory/test_bridge.py`
- Configuration patterns from `src/gsd_rlm/config/settings.py`

### Tertiary (LOW confidence)
- None - all findings verified against primary sources

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - cryptography library is industry standard, well-documented
- Architecture: HIGH - patterns follow existing codebase conventions exactly
- Pitfalls: HIGH - based on well-known cryptographic vulnerabilities

**Research date:** 2026-02-27
**Valid until:** 30 days - cryptography best practices are stable
