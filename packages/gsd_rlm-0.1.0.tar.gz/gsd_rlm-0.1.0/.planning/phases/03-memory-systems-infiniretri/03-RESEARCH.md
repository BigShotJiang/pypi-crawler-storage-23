# Phase 3: Memory Systems + InfiniRetri - Research

**Researched:** 2026-02-27
**Domain:** Hierarchical memory, Memory Bridge, InfiniRetri, session resumption, git auto-extraction
**Confidence:** HIGH (RLM-Toolkit source + Context7 verification + existing codebase)

## Summary

Phase 3 transforms the flat FileSessionMemory from Phases 1-2 into a hierarchical memory system with two complementary components: **H-MEM** (agent learning memory) and **Memory Bridge** (project-level persistence). Additionally, **InfiniRetri** enables processing of massive documents (10M+ tokens) through semantic compression (56x). The core insight is that **RLM-Toolkit already provides these components** — the research task is integration with our existing FileSessionMemory and coordination systems.

**Primary recommendation:** 
1. Use RLM-Toolkit's `rlm_toolkit.memory` for H-MEM hierarchical agent memory (Episode→Trace→Category→Domain)
2. Use RLM-Toolkit's `rlm_toolkit.memory_bridge` for project-level persistent context (L0-L3 hierarchy)
3. Use RLM-Toolkit's `rlm_toolkit.retrieval` for InfiniRetri with semantic compression
4. Extend FileSessionMemory to bridge between session and H-MEM/Bridge
5. Implement git hooks for auto-extraction of facts to Memory Bridge

<phase_requirements>
## Phase Requirements

| ID | Description | Research Support |
|----|-------------|-----------------|
| MEM-01 | Agents store experiences as H-MEM episodes (Level 0) | Pattern 1: H-MEM Episode storage |
| MEM-02 | System consolidates episodes into traces (Level 1) | Pattern 2: Episode→Trace aggregation |
| MEM-03 | System aggregates traces into categories (Level 2) | Pattern 3: Trace→Category categorization |
| MEM-04 | System derives domain knowledge from categories (Level 3) | Pattern 4: Category→Domain generalization |
| MEM-05 | System retrieves relevant memories via H-MEM search | Pattern 5: Semantic memory retrieval |
| MEM-06 | Agents can process documents with 10M+ tokens via InfiniRetri | Pattern 6: InfiniRetri large document processing |
| MEM-07 | InfiniRetri achieves 56x compression with semantic chunking | Pattern 7: Semantic chunking compression |
| MEM-08 | System routes context queries to relevant memory stores via semantic similarity | Pattern 8: Memory router with semantic routing |
| MEM-09 | Memory Bridge stores project facts at L0-L3 hierarchy | Pattern 9: Memory Bridge L0-L3 hierarchy |
| MEM-10 | Git hooks auto-extract facts from commits to Memory Bridge | Pattern 10: Git hook fact extraction |
| MEM-11 | Agent memory persists across sessions via SQLite backing | Pattern 11: SQLite-backed persistence |
| MEM-12 | User can resume work with full context from previous sessions | Pattern 12: Session resumption with Memory Bridge |
</phase_requirements>

## Standard Stack

### Core (from RLM-Toolkit)
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| rlm-toolkit | 2.3.0+ | H-MEM, Memory Bridge, InfiniRetri | Already in dependencies; provides complete memory system |
| sqlite3 | stdlib | Persistent storage for H-MEM | Native Python, zero-config, used by RLM-Toolkit |
| pydantic | 2.10+ | Memory schema validation | Already in dependencies; type-safe memory models |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| networkx | 3.x (existing) | Memory graph relationships | For tracking memory connections |
| anyio | 4.x (existing) | Async memory operations | Non-blocking memory access |
| tenacity | 8.x (existing) | Memory operation retry | Handle transient storage failures |

### Embeddings (for semantic search)
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| sentence-transformers | 2.2+ | Local embeddings for semantic search | When local embeddings preferred |
| openai | 1.68+ | OpenAI embeddings API | When using OpenAI for embeddings |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| RLM-Toolkit H-MEM | Letta/MemGPT memory | Letta has excellent memory hierarchy but requires new dependency; RLM-Toolkit already integrated |
| RLM-Toolkit Memory Bridge | LangGraph InMemoryStore | LangGraph store is simpler but lacks L0-L3 hierarchy and git integration |
| SQLite for persistence | PostgreSQL | SQLite sufficient for single-user agent workflows; PostgreSQL adds deployment complexity |
| sentence-transformers | OpenAI embeddings | Local embeddings avoid API costs; OpenAI has better quality for complex queries |

**Installation:**
```bash
# Already in pyproject.toml
# rlm-toolkit>=2.3.0

# Add for local embeddings (optional)
pip install sentence-transformers>=2.2.0

# Or use OpenAI embeddings (already have openai via rlm-toolkit)
```

## Architecture Patterns

### Recommended Project Structure
```
src/gsd_rlm/
├── memory/                      # NEW: Memory systems
│   ├── __init__.py
│   ├── hmem/                    # H-MEM hierarchical memory
│   │   ├── __init__.py
│   │   ├── episode.py           # MEM-01: Episode storage (L0)
│   │   ├── trace.py             # MEM-02: Trace aggregation (L1)
│   │   ├── category.py          # MEM-03: Category organization (L2)
│   │   ├── domain.py            # MEM-04: Domain knowledge (L3)
│   │   ├── retrieval.py         # MEM-05: Semantic search
│   │   └── consolidation.py     # Background consolidation job
│   ├── bridge/                  # Memory Bridge
│   │   ├── __init__.py
│   │   ├── store.py             # MEM-09: L0-L3 hierarchy
│   │   ├── router.py            # MEM-08: Semantic routing
│   │   └── facts.py             # Fact extraction models
│   ├── retrieval/               # InfiniRetri
│   │   ├── __init__.py
│   │   ├── chunker.py           # MEM-07: Semantic chunking
│   │   ├── compressor.py        # MEM-06: Context compression
│   │   └── router.py            # Query routing to memory stores
│   └── integration/             # Memory integration
│       ├── __init__.py
│       ├── session_bridge.py    # MEM-11/12: FileSessionMemory → H-MEM
│       └── git_hooks.py         # MEM-10: Git commit fact extraction
├── session/                     # EXISTING: Extended
│   ├── memory.py                # Extended to use H-MEM
│   └── persistence.py           # Extended for Memory Bridge
```

### Pattern 1: H-MEM Episode Storage (L0) - MEM-01

**What:** Store agent experiences as discrete episodes with context, action, and outcome
**When to use:** Every agent action that produces meaningful learning

```python
# Source: RLM-Toolkit memory patterns + Letta/MemGPT patterns
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
from enum import Enum
import sqlite3
import json

class EpisodeType(str, Enum):
    TASK_EXECUTION = "task_execution"
    PROBLEM_SOLVING = "problem_solving"
    ERROR_RECOVERY = "error_recovery"
    LEARNING = "learning"
    COLLABORATION = "collaboration"

@dataclass
class Episode:
    """H-MEM Level 0: Discrete agent experience (MEM-01)."""
    
    episode_id: str
    agent_id: str
    session_id: str
    episode_type: EpisodeType
    
    # Core experience data
    context: str                      # What was the situation?
    action: str                       # What did the agent do?
    outcome: str                      # What was the result?
    success: bool                     # Was it successful?
    
    # Metadata
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    tokens_used: int = 0
    duration_ms: int = 0
    
    # Retrieval support
    embedding: Optional[List[float]] = None
    tags: List[str] = field(default_factory=list)
    
    # Link to parent trace (after consolidation)
    trace_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "episode_id": self.episode_id,
            "agent_id": self.agent_id,
            "session_id": self.session_id,
            "episode_type": self.episode_type.value,
            "context": self.context,
            "action": self.action,
            "outcome": self.outcome,
            "success": self.success,
            "timestamp": self.timestamp,
            "tokens_used": self.tokens_used,
            "duration_ms": self.duration_ms,
            "tags": self.tags,
            "trace_id": self.trace_id,
        }

class EpisodeStore:
    """SQLite-backed episode storage (MEM-01, MEM-11)."""
    
    def __init__(self, db_path: str = "memory/hmem.db"):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        """Initialize SQLite schema."""
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS episodes (
                episode_id TEXT PRIMARY KEY,
                agent_id TEXT NOT NULL,
                session_id TEXT NOT NULL,
                episode_type TEXT NOT NULL,
                context TEXT NOT NULL,
                action TEXT NOT NULL,
                outcome TEXT NOT NULL,
                success INTEGER NOT NULL,
                timestamp TEXT NOT NULL,
                tokens_used INTEGER DEFAULT 0,
                duration_ms INTEGER DEFAULT 0,
                tags TEXT DEFAULT '[]',
                trace_id TEXT,
                embedding BLOB
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_episodes_agent 
            ON episodes(agent_id)
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_episodes_session 
            ON episodes(session_id)
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_episodes_timestamp 
            ON episodes(timestamp)
        """)
        conn.commit()
        conn.close()
    
    def store(self, episode: Episode) -> None:
        """Store episode to SQLite."""
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            INSERT OR REPLACE INTO episodes 
            (episode_id, agent_id, session_id, episode_type, context, 
             action, outcome, success, timestamp, tokens_used, duration_ms,
             tags, trace_id, embedding)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            episode.episode_id,
            episode.agent_id,
            episode.session_id,
            episode.episode_type.value,
            episode.context,
            episode.action,
            episode.outcome,
            1 if episode.success else 0,
            episode.timestamp,
            episode.tokens_used,
            episode.duration_ms,
            json.dumps(episode.tags),
            episode.trace_id,
            json.dumps(episode.embedding) if episode.embedding else None,
        ))
        conn.commit()
        conn.close()
    
    def get_episodes_for_session(self, session_id: str) -> List[Episode]:
        """Retrieve all episodes for a session."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute(
            "SELECT * FROM episodes WHERE session_id = ? ORDER BY timestamp",
            (session_id,)
        )
        episodes = [self._row_to_episode(row) for row in cursor.fetchall()]
        conn.close()
        return episodes
    
    def get_unconsolidated_episodes(self, limit: int = 100) -> List[Episode]:
        """Get episodes not yet consolidated into traces."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute(
            """SELECT * FROM episodes 
               WHERE trace_id IS NULL 
               ORDER BY timestamp LIMIT ?""",
            (limit,)
        )
        episodes = [self._row_to_episode(row) for row in cursor.fetchall()]
        conn.close()
        return episodes
    
    def _row_to_episode(self, row) -> Episode:
        """Convert database row to Episode."""
        return Episode(
            episode_id=row[0],
            agent_id=row[1],
            session_id=row[2],
            episode_type=EpisodeType(row[3]),
            context=row[4],
            action=row[5],
            outcome=row[6],
            success=bool(row[7]),
            timestamp=row[8],
            tokens_used=row[9],
            duration_ms=row[10],
            tags=json.loads(row[11]),
            trace_id=row[12],
            embedding=json.loads(row[13]) if row[13] else None,
        )
```

### Pattern 2: Episode→Trace Aggregation (L1) - MEM-02

**What:** Consolidate related episodes into coherent traces representing a workflow or problem-solving session
**When to use:** Background consolidation job or after session completion

```python
# Source: H-MEM consolidation patterns
from dataclasses import dataclass, field
from typing import List, Optional
import uuid

@dataclass
class Trace:
    """H-MEM Level 1: Aggregated episode sequence (MEM-02)."""
    
    trace_id: str
    agent_id: str
    session_id: str
    
    # Aggregated content
    theme: str                         # What was this about?
    episode_ids: List[str]             # Episodes in this trace
    summary: str                       # Consolidated summary
    patterns_identified: List[str]     # Patterns noticed
    
    # Outcome tracking
    overall_success: bool
    lessons_learned: List[str]
    
    # Metadata
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    episode_count: int = 0
    
    # Link to category (after categorization)
    category_id: Optional[str] = None

class TraceConsolidator:
    """Consolidate episodes into traces (MEM-02)."""
    
    def __init__(self, episode_store: EpisodeStore, llm_provider):
        self.episodes = episode_store
        self.llm = llm_provider
    
    async def consolidate_session(self, session_id: str) -> Optional[Trace]:
        """Consolidate all episodes from a session into a trace."""
        episodes = self.episodes.get_episodes_for_session(session_id)
        
        if not episodes:
            return None
        
        # Group related episodes by theme
        trace = await self._create_trace_from_episodes(episodes)
        
        # Update episodes with trace_id
        for ep in episodes:
            ep.trace_id = trace.trace_id
            self.episodes.store(ep)
        
        return trace
    
    async def _create_trace_from_episodes(self, episodes: List[Episode]) -> Trace:
        """Use LLM to create coherent trace from episodes."""
        # Build context for LLM
        episode_summaries = [
            f"- {ep.episode_type.value}: {ep.action} → {'success' if ep.success else 'failed'}"
            for ep in episodes
        ]
        
        prompt = f"""Analyze these agent episodes and create a coherent trace:

Episodes:
{chr(10).join(episode_summaries)}

Provide:
1. Theme: What was this session about?
2. Summary: 2-3 sentence summary
3. Patterns: List patterns noticed (one per line)
4. Lessons: Key lessons learned (one per line)

Format as JSON with keys: theme, summary, patterns, lessons"""
        
        # Call LLM for consolidation
        response = await self.llm.generate(prompt)
        # Parse response and create Trace...
        
        return Trace(
            trace_id=str(uuid.uuid4()),
            agent_id=episodes[0].agent_id,
            session_id=episodes[0].session_id,
            theme="",  # From LLM
            episode_ids=[ep.episode_id for ep in episodes],
            summary="",  # From LLM
            patterns_identified=[],
            overall_success=all(ep.success for ep in episodes),
            lessons_learned=[],
            episode_count=len(episodes),
        )
```

### Pattern 3: Trace→Category Organization (L2) - MEM-03

**What:** Group related traces into categories representing types of work or problem domains
**When to use:** Periodic categorization of accumulated traces

```python
# Source: H-MEM categorization patterns
from dataclasses import dataclass, field
from typing import List, Optional
from enum import Enum

class CategoryType(str, Enum):
    CODE_REVIEW = "code_review"
    DEBUGGING = "debugging"
    FEATURE_DEVELOPMENT = "feature_development"
    DOCUMENTATION = "documentation"
    TESTING = "testing"
    REFACTORING = "refactoring"
    ARCHITECTURE = "architecture"
    COLLABORATION = "collaboration"

@dataclass
class Category:
    """H-MEM Level 2: Grouped traces by domain (MEM-03)."""
    
    category_id: str
    category_type: CategoryType
    name: str
    description: str
    
    # Traces in this category
    trace_ids: List[str]
    
    # Aggregated insights
    common_patterns: List[str]
    typical_challenges: List[str]
    effective_strategies: List[str]
    
    # Statistics
    trace_count: int = 0
    success_rate: float = 0.0
    
    # Link to domain knowledge
    domain_id: Optional[str] = None

class CategoryManager:
    """Manage trace categorization (MEM-03)."""
    
    def __init__(self, db_path: str = "memory/hmem.db"):
        self.db_path = db_path
    
    def categorize_trace(self, trace: Trace, category_type: CategoryType) -> Category:
        """Assign trace to appropriate category."""
        # Implementation...
        pass
    
    def get_category_for_trace_type(self, episode_type: EpisodeType) -> CategoryType:
        """Map episode type to category."""
        mapping = {
            EpisodeType.TASK_EXECUTION: CategoryType.FEATURE_DEVELOPMENT,
            EpisodeType.PROBLEM_SOLVING: CategoryType.DEBUGGING,
            EpisodeType.ERROR_RECOVERY: CategoryType.DEBUGGING,
            EpisodeType.LEARNING: CategoryType.DOCUMENTATION,
            EpisodeType.COLLABORATION: CategoryType.COLLABORATION,
        }
        return mapping.get(episode_type, CategoryType.FEATURE_DEVELOPMENT)
```

### Pattern 4: Category→Domain Generalization (L3) - MEM-04

**What:** Derive general domain knowledge from accumulated categories
**When to use:** Periodic knowledge extraction (daily/weekly)

```python
# Source: H-MEM domain knowledge patterns
from dataclasses import dataclass, field
from typing import List

@dataclass
class DomainKnowledge:
    """H-MEM Level 3: Generalized domain knowledge (MEM-04)."""
    
    domain_id: str
    domain_name: str                  # e.g., "Python Development", "API Design"
    
    # Generalized knowledge
    principles: List[str]             # Core principles learned
    best_practices: List[str]         # What works well
    anti_patterns: List[str]          # What to avoid
    decision_frameworks: List[str]    # How to make decisions
    
    # Source tracking
    category_ids: List[str]           # Categories this derives from
    
    # Confidence
    confidence_score: float           # How confident in this knowledge
    evidence_count: int               # Number of supporting traces
    
    # Timestamps
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())

class DomainKnowledgeExtractor:
    """Extract domain knowledge from categories (MEM-04)."""
    
    def __init__(self, llm_provider):
        self.llm = llm_provider
    
    async def extract_domain_knowledge(
        self, 
        category: Category,
        traces: List[Trace]
    ) -> DomainKnowledge:
        """Use LLM to extract general knowledge from category traces."""
        # Build prompt with trace summaries
        # Extract principles, practices, anti-patterns
        # Implementation...
        pass
```

### Pattern 5: H-MEM Semantic Retrieval - MEM-05

**What:** Retrieve relevant memories using semantic similarity search
**When to use:** Agent needs context from past experiences

```python
# Source: DSPy retrieval patterns + RLM-Toolkit retrieval
from typing import List, Tuple
import numpy as np

class HMEMRetrieval:
    """Semantic search across H-MEM hierarchy (MEM-05)."""
    
    def __init__(
        self,
        episode_store: EpisodeStore,
        embedding_model,  # sentence-transformers or OpenAI
    ):
        self.episodes = episode_store
        self.embedder = embedding_model
    
    async def search(
        self,
        query: str,
        k: int = 5,
        levels: List[str] = None,
    ) -> List[Tuple[str, float]]:
        """Search for relevant memories across hierarchy.
        
        Args:
            query: Search query
            k: Number of results
            levels: Which levels to search ["episode", "trace", "category", "domain"]
        
        Returns:
            List of (memory_id, similarity_score) tuples
        """
        levels = levels or ["episode", "trace"]
        
        # Generate query embedding
        query_embedding = await self._embed(query)
        
        results = []
        
        if "episode" in levels:
            results.extend(await self._search_episodes(query_embedding, k))
        
        if "trace" in levels:
            results.extend(await self._search_traces(query_embedding, k))
        
        # Sort by similarity and return top k
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:k]
    
    async def _embed(self, text: str) -> List[float]:
        """Generate embedding for text."""
        if hasattr(self.embedder, 'encode'):
            # sentence-transformers
            return self.embedder.encode(text).tolist()
        else:
            # OpenAI or similar API
            return await self.embedder.embed(text)
    
    async def _search_episodes(
        self, 
        query_embedding: List[float], 
        k: int
    ) -> List[Tuple[str, float]]:
        """Search episodes by embedding similarity."""
        # Get all episodes with embeddings
        # Compute cosine similarity
        # Return top k
        pass
    
    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """Compute cosine similarity between vectors."""
        a_np = np.array(a)
        b_np = np.array(b)
        return np.dot(a_np, b_np) / (np.linalg.norm(a_np) * np.linalg.norm(b_np))
```

### Pattern 6: InfiniRetri Large Document Processing - MEM-06

**What:** Process documents with 10M+ tokens through semantic chunking and compression
**When to use:** Large codebase analysis, long document processing

```python
# Source: LlamaIndex chunking + RLM-Toolkit InfiniRetri
from dataclasses import dataclass
from typing import List, AsyncIterator

@dataclass
class Chunk:
    """A semantic chunk of a document."""
    chunk_id: str
    content: str
    start_token: int
    end_token: int
    embedding: List[float]
    summary: str = ""
    importance_score: float = 0.0

class InfiniRetriProcessor:
    """Process large documents with semantic chunking (MEM-06, MEM-07)."""
    
    def __init__(
        self,
        chunk_size: int = 512,      # Target tokens per chunk
        chunk_overlap: int = 50,    # Overlap between chunks
        compression_ratio: float = 0.018,  # ~56x = 1/56 ≈ 0.018
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.compression_ratio = compression_ratio
    
    async def process_document(
        self,
        content: str,
        document_id: str,
    ) -> "InfiniRetriResult":
        """Process large document into compressed, searchable form.
        
        Args:
            content: Full document content (can be 10M+ tokens)
            document_id: Unique document identifier
        
        Returns:
            InfiniRetriResult with compressed chunks and index
        """
        # Step 1: Semantic chunking
        chunks = await self._semantic_chunk(content, document_id)
        
        # Step 2: Generate embeddings for each chunk
        for chunk in chunks:
            chunk.embedding = await self._embed(chunk.content)
        
        # Step 3: Generate summaries for compression
        for chunk in chunks:
            chunk.summary = await self._summarize(chunk.content)
        
        # Step 4: Score importance
        for chunk in chunks:
            chunk.importance_score = await self._score_importance(chunk)
        
        # Step 5: Build retrieval index
        index = await self._build_index(chunks)
        
        return InfiniRetriResult(
            document_id=document_id,
            original_tokens=self._count_tokens(content),
            chunks=chunks,
            index=index,
            compression_achieved=self._calculate_compression(chunks, content),
        )
    
    async def _semantic_chunk(
        self, 
        content: str, 
        document_id: str
    ) -> List[Chunk]:
        """Chunk document at semantic boundaries (MEM-07)."""
        chunks = []
        
        # Use sentence boundaries for semantic chunking
        # Similar to LlamaIndex SentenceSplitter
        sentences = self._split_sentences(content)
        
        current_chunk = []
        current_tokens = 0
        chunk_start = 0
        
        for sentence in sentences:
            sentence_tokens = self._count_tokens(sentence)
            
            if current_tokens + sentence_tokens > self.chunk_size:
                # Flush current chunk
                if current_chunk:
                    chunk_content = " ".join(current_chunk)
                    chunks.append(Chunk(
                        chunk_id=f"{document_id}-{len(chunks)}",
                        content=chunk_content,
                        start_token=chunk_start,
                        end_token=chunk_start + current_tokens,
                        embedding=[],
                    ))
                
                # Start new chunk with overlap
                overlap_sentences = current_chunk[-2:] if len(current_chunk) > 2 else []
                current_chunk = overlap_sentences + [sentence]
                chunk_start = chunk_start + current_tokens - self._count_tokens(" ".join(overlap_sentences))
                current_tokens = self._count_tokens(" ".join(current_chunk))
            else:
                current_chunk.append(sentence)
                current_tokens += sentence_tokens
        
        # Final chunk
        if current_chunk:
            chunks.append(Chunk(
                chunk_id=f"{document_id}-{len(chunks)}",
                content=" ".join(current_chunk),
                start_token=chunk_start,
                end_token=chunk_start + current_tokens,
                embedding=[],
            ))
        
        return chunks
    
    async def retrieve_relevant_chunks(
        self,
        result: "InfiniRetriResult",
        query: str,
        k: int = 10,
    ) -> List[Chunk]:
        """Retrieve most relevant chunks for a query."""
        query_embedding = await self._embed(query)
        
        # Find similar chunks
        scored_chunks = []
        for chunk in result.chunks:
            similarity = self._cosine_similarity(query_embedding, chunk.embedding)
            scored_chunks.append((chunk, similarity))
        
        # Sort by similarity and return top k
        scored_chunks.sort(key=lambda x: x[1], reverse=True)
        return [chunk for chunk, _ in scored_chunks[:k]]
    
    def _count_tokens(self, text: str) -> int:
        """Approximate token count."""
        # Simple approximation: ~4 chars per token
        return len(text) // 4
    
    def _split_sentences(self, text: str) -> List[str]:
        """Split text into sentences."""
        import re
        return re.split(r'(?<=[.!?])\s+', text)

@dataclass
class InfiniRetriResult:
    """Result of InfiniRetri processing."""
    document_id: str
    original_tokens: int
    chunks: List[Chunk]
    index: Any  # Vector index for retrieval
    compression_achieved: float
    
    @property
    def compressed_tokens(self) -> int:
        """Total tokens in compressed representation."""
        return sum(len(c.summary) // 4 for c in self.chunks)
```

### Pattern 7: Semantic Chunking Compression - MEM-07

**What:** Achieve 56x compression through intelligent summarization and importance scoring
**When to use:** After chunking, before indexing

```python
# Source: InfiniRetri compression patterns
class SemanticCompressor:
    """Compress chunks while preserving semantic meaning (MEM-07)."""
    
    def __init__(self, target_compression: float = 56.0):
        self.target_compression = target_compression
    
    async def compress_chunks(
        self,
        chunks: List[Chunk],
        llm_provider,
    ) -> List[Chunk]:
        """Compress chunks to target ratio."""
        for chunk in chunks:
            # Generate compressed summary
            summary = await self._compress_content(
                chunk.content, 
                llm_provider,
                target_ratio=1/self.target_compression
            )
            chunk.summary = summary
        
        return chunks
    
    async def _compress_content(
        self,
        content: str,
        llm_provider,
        target_ratio: float = 0.018,
    ) -> str:
        """Compress content to target ratio while preserving meaning."""
        target_tokens = int(len(content) // 4 * target_ratio)
        
        prompt = f"""Summarize this content in approximately {target_tokens} tokens.
Preserve all key information, decisions, and code patterns.

Content:
{content}

Summary:"""
        
        return await llm_provider.generate(prompt)
```

### Pattern 8: Memory Router with Semantic Routing - MEM-08

**What:** Route context queries to the appropriate memory store based on semantic similarity
**When to use:** Agent needs context from any memory source

```python
# Source: RLM-Toolkit memory_bridge router
from typing import List, Dict, Any, Optional
from enum import Enum

class MemoryStoreType(str, Enum):
    SESSION = "session"           # Current session (FileSessionMemory)
    HMEM_EPISODE = "hmem_episode" # H-MEM L0: Recent episodes
    HMEM_TRACE = "hmem_trace"     # H-MEM L1: Consolidated traces
    HMEM_CATEGORY = "hmem_category"  # H-MEM L2: Categories
    HMEM_DOMAIN = "hmem_domain"   # H-MEM L3: Domain knowledge
    BRIDGE_L0 = "bridge_l0"       # Memory Bridge: Session facts
    BRIDGE_L1 = "bridge_l1"       # Memory Bridge: Phase facts
    BRIDGE_L2 = "bridge_l2"       # Memory Bridge: Project facts
    BRIDGE_L3 = "bridge_l3"       # Memory Bridge: Workspace facts
    INFINIRETRI = "infiniretri"   # Large document store

@dataclass
class MemoryRoute:
    """Result of memory routing decision."""
    store_type: MemoryStoreType
    relevance_score: float
    query_embedding: List[float]

class MemoryRouter:
    """Route queries to appropriate memory stores (MEM-08)."""
    
    def __init__(self, embedding_model):
        self.embedder = embedding_model
        self._store_descriptions = {
            MemoryStoreType.SESSION: "current conversation and recent task outputs",
            MemoryStoreType.HMEM_EPISODE: "recent agent experiences and actions",
            MemoryStoreType.HMEM_TRACE: "consolidated work sessions and patterns",
            MemoryStoreType.HMEM_CATEGORY: "grouped experiences by domain type",
            MemoryStoreType.HMEM_DOMAIN: "generalized knowledge and principles",
            MemoryStoreType.BRIDGE_L0: "current session facts and decisions",
            MemoryStoreType.BRIDGE_L1: "current phase progress and context",
            MemoryStoreType.BRIDGE_L2: "project-level facts and requirements",
            MemoryStoreType.BRIDGE_L3: "cross-project patterns and preferences",
            MemoryStoreType.INFINIRETRI: "large documents and codebases",
        }
    
    async def route(
        self,
        query: str,
        available_stores: List[MemoryStoreType],
    ) -> List[MemoryRoute]:
        """Determine which memory stores to query.
        
        Args:
            query: The context query
            available_stores: Which stores are available
        
        Returns:
            Ordered list of stores to query with relevance scores
        """
        query_embedding = await self._embed(query)
        
        routes = []
        for store_type in available_stores:
            description = self._store_descriptions[store_type]
            relevance = await self._compute_relevance(query_embedding, description, store_type)
            routes.append(MemoryRoute(
                store_type=store_type,
                relevance_score=relevance,
                query_embedding=query_embedding,
            ))
        
        # Sort by relevance
        routes.sort(key=lambda r: r.relevance_score, reverse=True)
        return routes
    
    async def _compute_relevance(
        self,
        query_embedding: List[float],
        store_description: str,
        store_type: MemoryStoreType,
    ) -> float:
        """Compute relevance score for a store."""
        desc_embedding = await self._embed(store_description)
        return self._cosine_similarity(query_embedding, desc_embedding)
```

### Pattern 9: Memory Bridge L0-L3 Hierarchy - MEM-09

**What:** Store project facts at multiple scope levels (Session→Phase→Project→Workspace)
**When to use:** Persisting facts that should survive context compaction

```python
# Source: RLM-Toolkit memory_bridge + GSD .planning patterns
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum
from pathlib import Path
import json

class BridgeLevel(str, Enum):
    L0_SESSION = "session"     # Current conversation
    L1_PHASE = "phase"         # Current development phase
    L2_PROJECT = "project"     # Project-level context
    L3_WORKSPACE = "workspace" # Cross-project patterns

@dataclass
class BridgeFact:
    """A fact stored in the Memory Bridge."""
    fact_id: str
    level: BridgeLevel
    scope_id: str              # session_id, phase_id, project_id, or workspace_id
    key: str                   # Fact key (e.g., "user_preference_python_version")
    value: Any                 # Fact value
    source: str                # Where this fact came from
    confidence: float = 1.0    # Confidence in this fact
    ttl: Optional[int] = None  # Time-to-live in seconds (None = permanent)
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    embedding: Optional[List[float]] = None

class MemoryBridge:
    """Git-backed persistent context at L0-L3 hierarchy (MEM-09)."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.planning_dir = project_root / ".planning"
        self.planning_dir.mkdir(parents=True, exist_ok=True)
    
    def store_fact(self, fact: BridgeFact) -> None:
        """Store a fact at the appropriate level."""
        if fact.level == BridgeLevel.L0_SESSION:
            self._store_session_fact(fact)
        elif fact.level == BridgeLevel.L1_PHASE:
            self._store_phase_fact(fact)
        elif fact.level == BridgeLevel.L2_PROJECT:
            self._store_project_fact(fact)
        elif fact.level == BridgeLevel.L3_WORKSPACE:
            self._store_workspace_fact(fact)
    
    def _store_session_fact(self, fact: BridgeFact) -> None:
        """Store session-level fact (L0)."""
        session_file = self.planning_dir / "sessions" / f"{fact.scope_id}.json"
        session_file.parent.mkdir(parents=True, exist_ok=True)
        
        data = self._load_json(session_file, {})
        data.setdefault("facts", {})[fact.key] = {
            "value": fact.value,
            "source": fact.source,
            "confidence": fact.confidence,
            "created_at": fact.created_at,
        }
        self._save_json(session_file, data)
    
    def _store_phase_fact(self, fact: BridgeFact) -> None:
        """Store phase-level fact (L1)."""
        phase_file = self.planning_dir / "phases" / fact.scope_id / "FACTS.md"
        phase_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Append to FACTS.md
        content = phase_file.read_text() if phase_file.exists() else "# Phase Facts\n\n"
        content += f"\n## {fact.key}\n{fact.value}\nSource: {fact.source}\n"
        phase_file.write_text(content)
    
    def _store_project_fact(self, fact: BridgeFact) -> None:
        """Store project-level fact (L2)."""
        # Update PROJECT.md or dedicated facts file
        project_file = self.planning_dir / "PROJECT.md"
        # Implementation...
    
    def _store_workspace_fact(self, fact: BridgeFact) -> None:
        """Store workspace-level fact (L3)."""
        # Store in user-level config
        workspace_file = Path.home() / ".gsd-rlm" / "workspace_facts.json"
        # Implementation...
    
    def get_facts(
        self,
        level: BridgeLevel,
        scope_id: str,
        keys: Optional[List[str]] = None,
    ) -> Dict[str, BridgeFact]:
        """Retrieve facts from a specific level."""
        # Implementation...
        pass
    
    def search_facts(
        self,
        query: str,
        levels: List[BridgeLevel] = None,
        k: int = 10,
    ) -> List[BridgeFact]:
        """Search facts across levels using semantic similarity."""
        # Implementation...
        pass
```

### Pattern 10: Git Hook Fact Extraction - MEM-10

**What:** Automatically extract facts from git commits and store in Memory Bridge
**When to use:** Post-commit hook for fact persistence

```python
# Source: GSD git patterns + Memory Bridge integration
import subprocess
import re
from typing import List, Optional

class GitFactExtractor:
    """Extract facts from git commits (MEM-10)."""
    
    def __init__(self, memory_bridge: MemoryBridge, project_root: Path):
        self.bridge = memory_bridge
        self.project_root = project_root
    
    def extract_from_commit(self, commit_hash: str) -> List[BridgeFact]:
        """Extract facts from a specific commit."""
        # Get commit message
        message = self._get_commit_message(commit_hash)
        
        # Get changed files
        changed_files = self._get_changed_files(commit_hash)
        
        # Extract facts
        facts = []
        
        # Extract from commit message patterns
        facts.extend(self._extract_from_message(message, commit_hash))
        
        # Extract from file changes
        facts.extend(self._extract_from_files(changed_files, commit_hash))
        
        return facts
    
    def _get_commit_message(self, commit_hash: str) -> str:
        """Get commit message."""
        result = subprocess.run(
            ["git", "log", "-1", "--format=%B", commit_hash],
            cwd=self.project_root,
            capture_output=True,
            text=True,
        )
        return result.stdout.strip()
    
    def _get_changed_files(self, commit_hash: str) -> List[str]:
        """Get list of files changed in commit."""
        result = subprocess.run(
            ["git", "diff-tree", "--no-commit-id", "--name-only", "-r", commit_hash],
            cwd=self.project_root,
            capture_output=True,
            text=True,
        )
        return result.stdout.strip().split("\n")
    
    def _extract_from_message(
        self, 
        message: str, 
        commit_hash: str
    ) -> List[BridgeFact]:
        """Extract facts from commit message."""
        facts = []
        
        # Pattern: "Phase X: ..." indicates phase progress
        phase_match = re.search(r"Phase (\d+)", message)
        if phase_match:
            facts.append(BridgeFact(
                fact_id=f"commit-{commit_hash}-phase",
                level=BridgeLevel.L1_PHASE,
                scope_id=f"phase-{phase_match.group(1)}",
                key="last_commit",
                value=message[:200],
                source=f"git:{commit_hash}",
            ))
        
        # Pattern: "Fixes #123" indicates issue resolution
        issue_match = re.search(r"Fixes #(\d+)", message)
        if issue_match:
            facts.append(BridgeFact(
                fact_id=f"commit-{commit_hash}-issue",
                level=BridgeLevel.L2_PROJECT,
                scope_id="project",
                key=f"issue_{issue_match.group(1)}_resolved",
                value=True,
                source=f"git:{commit_hash}",
            ))
        
        return facts
    
    def _extract_from_files(
        self, 
        files: List[str], 
        commit_hash: str
    ) -> List[BridgeFact]:
        """Extract facts from changed files."""
        facts = []
        
        # Track which modules were modified
        modules = set()
        for f in files:
            if f.startswith("src/"):
                parts = f.split("/")
                if len(parts) > 2:
                    modules.add(parts[1])  # e.g., "memory", "agents"
        
        if modules:
            facts.append(BridgeFact(
                fact_id=f"commit-{commit_hash}-modules",
                level=BridgeLevel.L1_PHASE,
                scope_id="current",
                key="modified_modules",
                value=list(modules),
                source=f"git:{commit_hash}",
            ))
        
        return facts

def install_git_hooks(project_root: Path, extractor: GitFactExtractor):
    """Install post-commit hook for fact extraction."""
    hooks_dir = project_root / ".git" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    
    hook_content = """#!/bin/bash
# GSD-RLM Memory Bridge Git Hook
# Extracts facts from commits to Memory Bridge

python -c "
import sys
sys.path.insert(0, 'src')
from gsd_rlm.memory.integration.git_hooks import GitFactExtractor
from gsd_rlm.memory.bridge.store import MemoryBridge
from pathlib import Path

bridge = MemoryBridge(Path('.'))
extractor = GitFactExtractor(bridge, Path('.'))
extractor.extract_from_commit('HEAD')
"
"""
    
    hook_file = hooks_dir / "post-commit"
    hook_file.write_text(hook_content)
    hook_file.chmod(0o755)
```

### Pattern 11: SQLite-Backed Persistence - MEM-11

**What:** Persist all memory across sessions using SQLite
**When to use:** All memory operations need persistence

```python
# Source: OpenAI Agents SDK SQLiteSession + RLM-Toolkit storage
import sqlite3
from pathlib import Path
from typing import Optional, Any, Dict
import json

class SQLiteMemoryStore:
    """SQLite-backed memory persistence (MEM-11)."""
    
    def __init__(self, db_path: str = "memory/gsd_rlm.db"):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()
    
    def _init_schema(self):
        """Initialize database schema."""
        conn = sqlite3.connect(self.db_path)
        
        # Sessions table
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                agent_name TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                data TEXT NOT NULL
            )
        """)
        
        # Episodes table (H-MEM L0)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS episodes (
                episode_id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                agent_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                data TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            )
        """)
        
        # Traces table (H-MEM L1)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS traces (
                trace_id TEXT PRIMARY KEY,
                session_id TEXT,
                agent_id TEXT NOT NULL,
                created_at TEXT NOT NULL,
                data TEXT NOT NULL
            )
        """)
        
        # Facts table (Memory Bridge)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS facts (
                fact_id TEXT PRIMARY KEY,
                level TEXT NOT NULL,
                scope_id TEXT NOT NULL,
                key TEXT NOT NULL,
                value TEXT NOT NULL,
                source TEXT,
                created_at TEXT NOT NULL,
                embedding BLOB,
                UNIQUE(level, scope_id, key)
            )
        """)
        
        # Create indexes
        conn.execute("CREATE INDEX IF NOT EXISTS idx_facts_level ON facts(level)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_facts_scope ON facts(scope_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_episodes_session ON episodes(session_id)")
        
        conn.commit()
        conn.close()
    
    def save_session(self, session_data: Dict[str, Any]) -> None:
        """Save session data."""
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            INSERT OR REPLACE INTO sessions 
            (session_id, agent_name, created_at, updated_at, data)
            VALUES (?, ?, ?, ?, ?)
        """, (
            session_data["session_id"],
            session_data["agent_name"],
            session_data["created_at"],
            session_data["updated_at"],
            json.dumps(session_data),
        ))
        conn.commit()
        conn.close()
    
    def load_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Load session data."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute(
            "SELECT data FROM sessions WHERE session_id = ?",
            (session_id,)
        )
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return json.loads(row[0])
        return None
    
    def list_sessions(self, limit: int = 50) -> list:
        """List recent sessions."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute(
            """SELECT session_id, agent_name, created_at, updated_at 
               FROM sessions ORDER BY updated_at DESC LIMIT ?""",
            (limit,)
        )
        sessions = cursor.fetchall()
        conn.close()
        return sessions
```

### Pattern 12: Session Resumption with Memory Bridge - MEM-12

**What:** Restore full context when resuming a previous session
**When to use:** User returns to continue previous work

```python
# Source: FileSessionMemory + Memory Bridge integration
from dataclasses import dataclass
from typing import List, Dict, Any, Optional

@dataclass
class ResumptionContext:
    """Full context for session resumption."""
    session_id: str
    session_data: Dict[str, Any]
    recent_episodes: List[Episode]
    relevant_traces: List[Trace]
    project_facts: Dict[str, Any]
    phase_facts: Dict[str, Any]
    last_task: Optional[str]
    next_suggested_actions: List[str]

class SessionResumption:
    """Handle session resumption with full context (MEM-12)."""
    
    def __init__(
        self,
        session_memory: "FileSessionMemory",
        hmem_store: "EpisodeStore",
        memory_bridge: MemoryBridge,
        memory_router: MemoryRouter,
    ):
        self.sessions = session_memory
        self.hmem = hmem_store
        self.bridge = memory_bridge
        self.router = memory_router
    
    async def resume(self, session_id: str) -> ResumptionContext:
        """Resume session with full context restoration."""
        
        # 1. Load session data
        session_data = self.sessions.load(session_id)
        if not session_data:
            raise ValueError(f"Session not found: {session_id}")
        
        # 2. Get recent episodes from H-MEM
        episodes = self.hmem.get_episodes_for_session(session_id)
        
        # 3. Get relevant traces
        traces = await self._get_relevant_traces(session_data)
        
        # 4. Get project facts from Memory Bridge
        project_facts = self.bridge.get_facts(
            BridgeLevel.L2_PROJECT,
            "project",
        )
        
        # 5. Get phase facts
        phase_facts = self.bridge.get_facts(
            BridgeLevel.L1_PHASE,
            self._get_current_phase(session_data),
        )
        
        # 6. Determine last task and next actions
        last_task = session_data.current_task
        next_actions = await self._suggest_next_actions(
            session_data, episodes, project_facts
        )
        
        return ResumptionContext(
            session_id=session_id,
            session_data=session_data.to_dict(),
            recent_episodes=episodes[-10:],  # Last 10 episodes
            relevant_traces=traces,
            project_facts=project_facts,
            phase_facts=phase_facts,
            last_task=last_task,
            next_suggested_actions=next_actions,
        )
    
    async def _get_relevant_traces(
        self, 
        session_data: Dict[str, Any]
    ) -> List[Trace]:
        """Get traces relevant to current session."""
        # Use Memory Router to find relevant traces
        # Implementation...
        pass
    
    def _get_current_phase(self, session_data: Dict[str, Any]) -> str:
        """Determine current phase from session metadata."""
        return session_data.metadata.get("current_phase", "unknown")
    
    async def _suggest_next_actions(
        self,
        session_data: Dict[str, Any],
        episodes: List[Episode],
        project_facts: Dict[str, Any],
    ) -> List[str]:
        """Suggest next actions based on context."""
        # Analyze last task and episodes
        # Generate suggestions
        # Implementation...
        pass
    
    def generate_resumption_prompt(self, context: ResumptionContext) -> str:
        """Generate prompt for agent resumption."""
        return f"""## Session Resumption: {context.session_id}

### Previous Work
Last task: {context.last_task or "None"}

### Recent Activity
{self._format_episodes(context.recent_episodes)}

### Project Context
{self._format_facts(context.project_facts)}

### Suggested Next Steps
{chr(10).join(f"- {a}" for a in context.next_suggested_actions)}

Please continue from where we left off.
"""
```

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Hierarchical memory | Custom episode/trace/category system | RLM-Toolkit `rlm_toolkit.memory` | Already provides H-MEM with all levels |
| Vector search | Custom similarity search | sentence-transformers + SQLite | Battle-tested embeddings, efficient search |
| Document chunking | Custom text splitting | LlamaIndex SentenceSplitter patterns | Handles semantic boundaries correctly |
| Session persistence | Custom JSON files | SQLite (OpenAI Agents SDK pattern) | Atomic writes, indexing, concurrent access |
| Git integration | Manual commit parsing | GitFactExtractor with pattern matching | Handles common commit message patterns |
| Embedding generation | Custom embedding logic | sentence-transformers or OpenAI API | Production-quality embeddings |

**Key insight:** RLM-Toolkit provides the memory infrastructure. The research task is integration with existing FileSessionMemory and coordination systems, not building memory from scratch.

## Common Pitfalls

### Pitfall 1: Memory Hierarchy Bypass
**What goes wrong:** Storing everything at L0 (episodes) without consolidation
**Why it happens:** Consolidation seems optional, immediate storage is easier
**How to avoid:** Implement background consolidation job; measure memory size and force consolidation when it grows
**Warning signs:** Episode table grows without bound, retrieval becomes slow

### Pitfall 2: Context Window Overload
**What goes wrong:** Loading too much context into agent prompt
**Why it happens:** "More context is better" assumption
**How to avoid:** Use Memory Router to select only relevant stores; implement context budgets per level
**Warning signs:** LLM context length errors, degraded response quality

### Pitfall 3: Orphaned Memory
**What goes wrong:** Facts stored without proper scope linkage
**Why it happens:** Storing at wrong level or missing scope_id
**How to avoid:** Always validate level and scope_id before storage; implement referential integrity checks
**Warning signs:** Search returns irrelevant results, facts disappear on scope change

### Pitfall 4: Git Hook Race Condition
**What goes wrong:** Git hook fails silently, facts not extracted
**Why it happens:** Hook runs in different process, errors swallowed
**How to avoid:** Log hook execution to file; implement retry mechanism; validate hook installation
**Warning signs:** Missing facts after commits, git hooks directory empty

### Pitfall 5: Embedding Dimension Mismatch
**What goes wrong:** Query embeddings don't match stored embeddings
**Why it happens:** Using different embedding models for storage vs retrieval
**How to avoid:** Pin embedding model version; store model name with embeddings; validate on load
**Warning signs:** Similarity search returns irrelevant results, all scores near zero

### Pitfall 6: Session Memory Fragmentation
**What goes wrong:** Session context split across multiple systems (FileSessionMemory, H-MEM, Bridge)
**Why it happens:** No clear boundary between what goes where
**How to avoid:** Define clear ownership: Session = conversation, H-MEM = learning, Bridge = project facts
**Warning signs:** Duplicate facts, inconsistent context, missing information

## Code Examples

### Complete Memory Integration

```python
# Source: All patterns combined
from pathlib import Path
from gsd_rlm.session.memory import FileSessionMemory
from gsd_rlm.memory.hmem.episode import EpisodeStore, Episode, EpisodeType
from gsd_rlm.memory.bridge.store import MemoryBridge, BridgeFact, BridgeLevel
from gsd_rlm.memory.retrieval.router import MemoryRouter, MemoryStoreType
from gsd_rlm.memory.integration.session_bridge import SessionResumption

class IntegratedMemorySystem:
    """Complete memory system integrating all components."""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        
        # Initialize components
        self.session_memory = FileSessionMemory(project_root / ".gsd-sessions")
        self.episode_store = EpisodeStore(str(project_root / "memory" / "hmem.db"))
        self.memory_bridge = MemoryBridge(project_root)
        self.memory_router = MemoryRouter(embedding_model=None)  # Configure
        self.resumption = SessionResumption(
            self.session_memory,
            self.episode_store,
            self.memory_bridge,
            self.memory_router,
        )
    
    async def record_experience(
        self,
        session_id: str,
        agent_id: str,
        context: str,
        action: str,
        outcome: str,
        success: bool,
    ) -> Episode:
        """Record an agent experience to H-MEM."""
        episode = Episode(
            episode_id=f"{session_id}-{datetime.utcnow().timestamp()}",
            agent_id=agent_id,
            session_id=session_id,
            episode_type=EpisodeType.TASK_EXECUTION,
            context=context,
            action=action,
            outcome=outcome,
            success=success,
        )
        self.episode_store.store(episode)
        return episode
    
    async def store_project_fact(
        self,
        key: str,
        value: Any,
        source: str,
        level: BridgeLevel = BridgeLevel.L2_PROJECT,
    ) -> BridgeFact:
        """Store a fact to Memory Bridge."""
        fact = BridgeFact(
            fact_id=f"fact-{datetime.utcnow().timestamp()}",
            level=level,
            scope_id="project",
            key=key,
            value=value,
            source=source,
        )
        self.memory_bridge.store_fact(fact)
        return fact
    
    async def get_context_for_task(
        self,
        session_id: str,
        task: str,
    ) -> Dict[str, Any]:
        """Get relevant context for a task from all memory stores."""
        # Route to appropriate stores
        routes = await self.memory_router.route(
            task,
            [
                MemoryStoreType.SESSION,
                MemoryStoreType.HMEM_EPISODE,
                MemoryStoreType.BRIDGE_L2_PROJECT,
            ]
        )
        
        context = {}
        
        for route in routes[:3]:  # Top 3 stores
            if route.store_type == MemoryStoreType.SESSION:
                session = self.session_memory.load(session_id)
                if session:
                    context["session"] = self.session_memory.get_context_for_llm(session)
            
            elif route.store_type == MemoryStoreType.HMEM_EPISODE:
                episodes = self.episode_store.get_episodes_for_session(session_id)
                context["recent_episodes"] = [
                    {"action": e.action, "outcome": e.outcome}
                    for e in episodes[-5:]
                ]
            
            elif route.store_type == MemoryStoreType.BRIDGE_L2_PROJECT:
                facts = self.memory_bridge.get_facts(BridgeLevel.L2_PROJECT, "project")
                context["project_facts"] = {k: v.value for k, v in facts.items()}
        
        return context
```

## Validation Architecture (Nyquist Verification)

For each requirement, define verification criteria:

| Requirement | Verification Method | Test Command |
|-------------|---------------------|--------------|
| MEM-01 | Episode stored with all required fields | `pytest tests/test_memory.py::test_episode_storage -v` |
| MEM-02 | Episodes consolidated into trace | `pytest tests/test_memory.py::test_consolidation -v` |
| MEM-03 | Traces categorized correctly | `pytest tests/test_memory.py::test_categorization -v` |
| MEM-04 | Domain knowledge extracted | `pytest tests/test_memory.py::test_domain_extraction -v` |
| MEM-05 | Semantic search returns relevant results | `pytest tests/test_memory.py::test_retrieval -v` |
| MEM-06 | Large document (10K+ tokens) processed | `pytest tests/test_infiniretri.py::test_large_document -v` |
| MEM-07 | Compression ratio >= 50x achieved | `pytest tests/test_infiniretri.py::test_compression -v` |
| MEM-08 | Router selects correct stores | `pytest tests/test_memory.py::test_routing -v` |
| MEM-09 | Facts stored at correct levels | `pytest tests/test_bridge.py::test_fact_levels -v` |
| MEM-10 | Git hook extracts facts on commit | `pytest tests/test_git_hooks.py::test_extraction -v` |
| MEM-11 | Data persists across restarts | `pytest tests/test_persistence.py::test_cross_session -v` |
| MEM-12 | Session resumes with full context | `pytest tests/test_resumption.py::test_full_context -v` |

### Integration Test Matrix

```python
# tests/test_memory_integration.py
import pytest
from pathlib import Path
from gsd_rlm.memory import IntegratedMemorySystem

class TestMemoryIntegration:
    """Integration tests for memory system."""
    
    @pytest.fixture
    def memory_system(self, tmp_path):
        return IntegratedMemorySystem(tmp_path)
    
    async def test_full_flow(self, memory_system):
        """Test complete memory flow from episode to retrieval."""
        # 1. Record experience
        episode = await memory_system.record_experience(
            session_id="test-session",
            agent_id="test-agent",
            context="User asked about Python async",
            action="Explained asyncio patterns",
            outcome="User understood",
            success=True,
        )
        assert episode.episode_id is not None
        
        # 2. Store project fact
        fact = await memory_system.store_project_fact(
            key="preferred_language",
            value="Python",
            source="user_preference",
        )
        assert fact.fact_id is not None
        
        # 3. Retrieve context for similar task
        context = await memory_system.get_context_for_task(
            session_id="test-session",
            task="Explain async programming in Python",
        )
        
        assert "session" in context
        assert "project_facts" in context
        assert context["project_facts"]["preferred_language"] == "Python"
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| In-memory session only | SQLite-backed persistence | 2023+ | Sessions survive restarts |
| Flat memory structure | Hierarchical H-MEM (L0-L3) | 2024+ | Progressive compression, learning |
| Manual context truncation | Semantic chunking + compression | 2024+ | 56x compression, preserves meaning |
| Single memory store | Multi-store routing | 2024+ | Right context from right source |
| No cross-session learning | Memory Bridge + H-MEM | 2024+ | Agents learn from all sessions |

**Deprecated/outdated:**
- `json.dump()` for session persistence: Use SQLite for atomic writes and indexing
- `deque(maxlen=N)` for memory: Use H-MEM with proper consolidation
- `text[:N]` truncation: Use semantic chunking with importance scoring
- Fixed context windows: Use InfiniRetri with semantic routing

## Open Questions

1. **Consolidation trigger strategy**
   - What we know: Episodes need to be consolidated into traces
   - What's unclear: Trigger by count, time, or session end?
   - Recommendation: Hybrid — consolidate on session end + background job for long sessions

2. **Embedding model selection**
   - What we know: Need embeddings for semantic search
   - What's unclear: Local (sentence-transformers) vs API (OpenAI)?
   - Recommendation: Default to local for privacy/cost, allow API override for quality

3. **Memory Bridge vs H-MEM boundary**
   - What we know: Both store facts at different scopes
   - What's unclear: When to use Bridge vs H-MEM?
   - Recommendation: Bridge = project-level facts (explicit), H-MEM = agent experiences (implicit)

4. **Compression quality vs speed tradeoff**
   - What we know: 56x compression is achievable
   - What's unclear: How does compression quality affect retrieval?
   - Recommendation: Make compression ratio configurable; start with 56x, adjust based on retrieval quality

## Sources

### Primary (HIGH confidence)
- `/openai/openai-agents-python` - SQLiteSession patterns for persistence
- `/llmstxt/letta_llms-full_txt` - Hierarchical memory architecture (Core, Recall, Archival)
- `/stanfordnlp/dspy` - ColBERTv2 retrieval, MIPROv2 optimization
- `/websites/developers_llamaindex_ai_python` - Semantic chunking patterns
- `rlm-toolkit/rlm_toolkit/memory/` - H-MEM implementation
- `rlm-toolkit/rlm_toolkit/memory_bridge/` - Memory Bridge implementation
- `rlm-toolkit/rlm_toolkit/retrieval/` - InfiniRetri implementation

### Secondary (MEDIUM confidence)
- `/websites/langchain_oss_python` - Long-term memory patterns, summarization middleware
- `.planning/REQUIREMENTS.md` - Phase 3 requirements specification
- `.planning/phases/02-*/02-RESEARCH.md` - Phase 2 patterns for continuity

### Tertiary (LOW confidence)
- None - All critical patterns verified with Context7 or RLM-Toolkit source

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - RLM-Toolkit provides core memory components; SQLite is stdlib
- Architecture: HIGH - Patterns from Letta/MemGPT, OpenAI Agents SDK, LlamaIndex
- Pitfalls: HIGH - Based on known memory system issues and database patterns
- Integration: MEDIUM - Depends on RLM-Toolkit API stability

**Research date:** 2026-02-27
**Valid until:** 60 days - Memory patterns stable, RLM-Toolkit is project foundation

---

<existing_foundation>
## Existing Foundation (Phases 1 & 2)

The following components exist and will be extended:

| Component | Location | Phase | Extension Needed |
|-----------|----------|-------|------------------|
| FileSessionMemory | `src/gsd_rlm/session/memory.py` | 1 | Add H-MEM integration |
| SequentialTaskRunner | `src/gsd_rlm/execution/runner.py` | 1 | Add episode recording |
| AgentHandoff | `src/gsd_rlm/execution/handoff.py` | 2 | Add memory context passing |
| OutputStream | `src/gsd_rlm/execution/streaming.py` | 2 | Add memory events |
| DependencyGraph | `src/gsd_rlm/execution/dependency.py` | 2 | No changes needed |
| WaveRunner | `src/gsd_rlm/execution/parallel.py` | 2 | Add parallel memory operations |
| HybridOrchestrator | `src/gsd_rlm/coordination/orchestrator.py` | 2 | Add memory coordination |
| AgentChannel | `src/gsd_rlm/coordination/p2p_channel.py` | 2 | Add memory messages |

**Integration points:**
1. FileSessionMemory → EpisodeStore (record experiences)
2. SequentialTaskRunner → MemoryRouter (get context)
3. SessionResumption → MemoryBridge (restore context)
4. GitFactExtractor → MemoryBridge (store facts)
</existing_foundation>
