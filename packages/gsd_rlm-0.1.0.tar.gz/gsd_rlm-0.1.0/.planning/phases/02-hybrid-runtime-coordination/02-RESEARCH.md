# Phase 2: Hybrid Runtime + Coordination - Research

**Researched:** 2026-02-27
**Domain:** Parallel execution, dependency resolution, real-time streaming, agent coordination
**Confidence:** HIGH

## Summary

Phase 2 transforms the sequential execution engine from Phase 1 into a parallel, wave-based execution system with dependency-aware scheduling. The core insight is that **NetworkX's `topological_generations()` perfectly maps to wave execution** - each generation is a set of independent tasks that can run concurrently. AnyIO's structured concurrency primitives (task groups, memory object streams) provide the foundation for parallel execution and inter-agent communication.

**Primary recommendation:** Use NetworkX for dependency graph and wave grouping, AnyIO task groups for parallel execution, and AnyIO memory object streams for P2P agent communication and real-time output streaming.

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| networkx | 3.x | Dependency graph, topological sort, wave grouping | Industry standard for graph algorithms; `topological_generations()` directly solves wave grouping |
| anyio | 4.x (existing) | Structured concurrency, task groups, streaming | Already in dependencies; trio-compatible; superior to asyncio.Queue for streaming |
| tenacity | 8.x (existing) | Retry with exponential backoff, fallback chains | Already in dependencies; already used in Phase 1 RetryableAgent |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| pydantic | 2.x (existing) | Data validation for wave results, execution state | Type safety for WaveResult, TaskExecution state |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| NetworkX | Custom topological sort | NetworkX handles cycles, disconnected graphs, and edge cases |
| AnyIO streams | asyncio.Queue | Memory object streams support cloning for multiple consumers, better cancellation |
| Tenacity | Manual retry loops | Declarative configuration, built-in logging hooks, battle-tested |

**Installation:**
```bash
# Add to pyproject.toml dependencies
pip install networkx>=3.0.0
```

## Architecture Patterns

### Recommended Project Structure
```
src/gsd_rlm/
├── execution/
│   ├── runner.py           # SequentialTaskRunner (Phase 1)
│   ├── retry.py            # RetryableAgent (Phase 1)
│   ├── progress.py         # ProgressReporter (Phase 1)
│   ├── validation.py       # Input/output validation (Phase 1)
│   ├── dependency.py       # NEW: DependencyGraph, WaveAnalyzer
│   ├── parallel.py         # NEW: ParallelExecutor, WaveRunner
│   ├── streaming.py        # NEW: OutputStream, ReasoningStream
│   ├── handoff.py          # NEW: AgentHandoff, ContextPreserver
│   └── degradation.py      # NEW: PartialResultCollector, GracefulDegradation
├── coordination/
│   ├── __init__.py
│   ├── orchestrator.py     # NEW: HybridOrchestrator (thin coordinator)
│   ├── p2p_channel.py      # NEW: AgentChannel for P2P communication
│   └── wave_scheduler.py   # NEW: WaveScheduler for dependency-aware execution
```

### Pattern 1: Dependency Graph with Wave Grouping

**What:** Use NetworkX DiGraph to represent task dependencies, then `topological_generations()` to group independent tasks into parallel waves.

**When to use:** All plan/task execution where dependencies exist between tasks.

**Example:**
```python
import networkx as nx
from typing import List, Dict, Set

class DependencyGraph:
    """Analyze task dependencies and group into waves (EXEC-01, EXEC-02, EXEC-03)."""
    
    def __init__(self):
        self.graph = nx.DiGraph()
    
    def add_task(self, task_id: str, depends_on: List[str] = None):
        """Add a task with its dependencies."""
        self.graph.add_node(task_id)
        if depends_on:
            for dep in depends_on:
                self.graph.add_edge(dep, task_id)  # dep -> task (dep must complete first)
    
    def get_waves(self) -> List[List[str]]:
        """Group tasks into waves of independent tasks.
        
        Returns:
            List of waves, where each wave contains task IDs that can run in parallel.
            Wave 0 has no dependencies, Wave 1 depends on Wave 0, etc.
        """
        try:
            return [list(gen) for gen in nx.topological_generations(self.graph)]
        except nx.NetworkXUnfeasible:
            # Graph contains a cycle - should not happen with valid plans
            raise ValueError("Task dependency graph contains a cycle")
    
    def get_dependencies(self, task_id: str) -> Set[str]:
        """Get all tasks this task depends on (predecessors)."""
        return set(self.graph.predecessors(task_id))
    
    def get_dependents(self, task_id: str) -> Set[str]:
        """Get all tasks that depend on this task (successors)."""
        return set(self.graph.successors(task_id))

# Usage example
graph = DependencyGraph()
graph.add_task("task-a", depends_on=[])
graph.add_task("task-b", depends_on=[])
graph.add_task("task-c", depends_on=["task-a", "task-b"])
graph.add_task("task-d", depends_on=["task-c"])

waves = graph.get_waves()
# Result: [["task-a", "task-b"], ["task-c"], ["task-d"]]
# Wave 0: task-a, task-b (parallel)
# Wave 1: task-c (waits for Wave 0)
# Wave 2: task-d (waits for Wave 1)
```

### Pattern 2: Parallel Execution with AnyIO Task Groups

**What:** Use AnyIO's `create_task_group()` for structured concurrency. Each wave spawns concurrent tasks, and the task group ensures all complete before proceeding to the next wave.

**When to use:** Wave execution where all tasks in a wave run independently.

**Example:**
```python
import anyio
from typing import List, Dict, Any, Callable
from dataclasses import dataclass

@dataclass
class TaskResult:
    task_id: str
    content: Any
    success: bool
    error: str = None

class WaveRunner:
    """Execute a wave of independent tasks in parallel (EXEC-02)."""
    
    def __init__(self, max_concurrent: int = 10):
        self.max_concurrent = max_concurrent
    
    async def run_wave(
        self,
        tasks: List[str],
        executor: Callable[[str], Any],
        on_progress: Callable[[str, str, str], None] = None,
    ) -> List[TaskResult]:
        """Run all tasks in a wave concurrently.
        
        Args:
            tasks: List of task IDs to execute
            executor: Async function that executes a single task
            on_progress: Progress callback
            
        Returns:
            List of TaskResult for each task
        """
        results: Dict[str, TaskResult] = {}
        
        async def run_single(task_id: str):
            try:
                if on_progress:
                    on_progress("starting", task_id, "")
                
                content = await executor(task_id)
                results[task_id] = TaskResult(
                    task_id=task_id,
                    content=content,
                    success=True,
                )
                
                if on_progress:
                    on_progress("completed", task_id, str(content)[:100])
                    
            except Exception as e:
                results[task_id] = TaskResult(
                    task_id=task_id,
                    content=None,
                    success=False,
                    error=str(e),
                )
                if on_progress:
                    on_progress("failed", task_id, str(e))
        
        # Run all tasks concurrently within the task group
        async with anyio.create_task_group() as tg:
            for task_id in tasks:
                tg.start_soon(run_single, task_id)
        
        return [results[t] for t in tasks]

# Usage
async def main():
    runner = WaveRunner()
    
    async def execute_task(task_id: str) -> str:
        # Simulate work
        await anyio.sleep(0.5)
        return f"Result of {task_id}"
    
    wave_results = await runner.run_wave(
        tasks=["task-1", "task-2", "task-3"],
        executor=execute_task,
        on_progress=lambda s, t, d: print(f"[{s}] {t}")
    )

anyio.run(main)
```

### Pattern 3: Real-time Output Streaming with Memory Object Streams

**What:** Use AnyIO's `create_memory_object_stream()` for real-time output streaming. The producer (agent) sends output chunks, and consumers (UI, logger) receive them in real-time.

**When to use:** Real-time visibility of agent reasoning and output (EXEC-08, EXEC-09).

**Example:**
```python
import anyio
from anyio.streams.memory import MemoryObjectSendStream, MemoryObjectReceiveStream
from dataclasses import dataclass
from typing import AsyncIterator
from enum import Enum

class StreamEventType(str, Enum):
    REASONING = "reasoning"  # Agent's thinking process
    OUTPUT = "output"        # Final output chunks
    ERROR = "error"          # Error messages
    COMPLETE = "complete"    # Task completed

@dataclass
class StreamEvent:
    task_id: str
    event_type: StreamEventType
    content: str
    timestamp: str = None

class OutputStream:
    """Real-time output streaming for agent execution (EXEC-08, EXEC-09)."""
    
    def __init__(self, buffer_size: int = 100):
        self.buffer_size = buffer_size
        self._streams: Dict[str, MemoryObjectSendStream] = {}
    
    async def create_stream(self, task_id: str) -> MemoryObjectReceiveStream:
        """Create a new stream for a task. Returns receive stream for consumer."""
        send_stream, receive_stream = anyio.create_memory_object_stream[
            StreamEvent
        ](max_buffer_size=self.buffer_size)
        self._streams[task_id] = send_stream
        return receive_stream
    
    async def emit(self, task_id: str, event_type: StreamEventType, content: str):
        """Emit a stream event for real-time visibility."""
        from datetime import datetime
        
        if task_id in self._streams:
            event = StreamEvent(
                task_id=task_id,
                event_type=event_type,
                content=content,
                timestamp=datetime.utcnow().isoformat(),
            )
            await self._streams[task_id].send(event)
    
    async def close_stream(self, task_id: str):
        """Close the stream when task completes."""
        if task_id in self._streams:
            await self._streams[task_id].aclose()
            del self._streams[task_id]
    
    async def stream_task(
        self,
        task_id: str,
        agent_executor: Callable,
    ) -> AsyncIterator[StreamEvent]:
        """Execute task and yield stream events in real-time."""
        receive_stream = await self.create_stream(task_id)
        
        async def execute_and_stream():
            try:
                # Emit reasoning start
                await self.emit(task_id, StreamEventType.REASONING, "Starting task...")
                
                result = await agent_executor(task_id)
                
                # Emit final output
                await self.emit(task_id, StreamEventType.OUTPUT, str(result))
                await self.emit(task_id, StreamEventType.COMPLETE, "")
                
            except Exception as e:
                await self.emit(task_id, StreamEventType.ERROR, str(e))
            finally:
                await self.close_stream(task_id)
        
        # Run execution in background while yielding events
        async with anyio.create_task_group() as tg:
            tg.start_soon(execute_and_stream)
            
            async for event in receive_stream:
                yield event
                if event.event_type == StreamEventType.COMPLETE:
                    break

# Usage: Consumer receives real-time events
async def consume_stream():
    streamer = OutputStream()
    
    async for event in streamer.stream_task("task-1", my_agent.execute):
        print(f"[{event.event_type.value}] {event.content}")
```

### Pattern 4: Agent Handoff with Context Preservation

**What:** Pass full context (conversation history, task outputs, routing chain) when handing off to specialist agents. The existing `AgentMessage` dataclass already supports this pattern.

**When to use:** AGENT-05 - When an agent delegates specialized work to another agent.

**Example:**
```python
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime

@dataclass
class HandoffContext:
    """Full context for agent handoff (AGENT-05)."""
    
    # Source information
    source_agent: str
    target_agent: str
    handoff_reason: str
    
    # Conversation context
    conversation_history: List[Dict[str, str]] = field(default_factory=list)
    
    # Task context
    current_task: str = ""
    task_outputs: List[Dict[str, Any]] = field(default_factory=list)
    
    # Routing chain (who has processed this so far)
    routing_chain: List[str] = field(default_factory=list)
    
    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    def to_agent_message(self) -> "AgentMessage":
        """Convert to AgentMessage for execution."""
        return AgentMessage(
            task_id=f"{self.source_agent}->{self.target_agent}",
            content=self.current_task,
            history=self.conversation_history,
            routing=self.routing_chain + [self.target_agent],
            metadata={
                "handoff_reason": self.handoff_reason,
                "source_agent": self.source_agent,
                **self.metadata
            }
        )

class AgentHandoff:
    """Manage handoffs between agents with full context preservation."""
    
    def __init__(self, session_memory: "FileSessionMemory"):
        self.session = session_memory
    
    def create_handoff(
        self,
        source_agent: str,
        target_agent: str,
        reason: str,
        session_id: str,
        task: str,
    ) -> HandoffContext:
        """Create a handoff context with full session context."""
        session = self.session.load(session_id)
        
        return HandoffContext(
            source_agent=source_agent,
            target_agent=target_agent,
            handoff_reason=reason,
            conversation_history=self.session.get_context_for_llm(session),
            current_task=task,
            task_outputs=self.session.get_recent_task_outputs(session),
            routing_chain=self._get_routing_chain(session),
        )
    
    def _get_routing_chain(self, session) -> List[str]:
        """Extract routing chain from session task outputs."""
        chain = []
        for output in session.task_outputs:
            if output.routing:
                chain.extend(output.routing)
        return list(dict.fromkeys(chain))  # Dedupe while preserving order
```

### Pattern 5: Graceful Degradation with Partial Results

**What:** Collect partial results when some tasks fail, allowing the system to return useful output even with failures. Combines with existing retry/fallback from Phase 1.

**When to use:** EXEC-15 - When unrecoverable errors occur, return what succeeded.

**Example:**
```python
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum

class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"  # Skipped due to dependency failure

@dataclass
class PartialResult:
    """Result collection with graceful degradation (EXEC-15)."""
    
    wave_id: int
    total_tasks: int
    completed_tasks: int = 0
    failed_tasks: int = 0
    skipped_tasks: int = 0
    
    results: Dict[str, Any] = field(default_factory=dict)
    errors: Dict[str, str] = field(default_factory=dict)
    task_status: Dict[str, TaskStatus] = field(default_factory=dict)
    
    @property
    def success_rate(self) -> float:
        if self.total_tasks == 0:
            return 0.0
        return self.completed_tasks / self.total_tasks
    
    @property
    def is_partial_success(self) -> bool:
        """True if some tasks succeeded even with failures."""
        return self.completed_tasks > 0 and self.failed_tasks > 0
    
    @property
    def can_continue(self) -> bool:
        """True if we have enough results to continue to next wave."""
        # Continue if at least one task succeeded
        return self.completed_tasks > 0

class GracefulDegradation:
    """Handle partial failures gracefully."""
    
    def __init__(self, min_success_rate: float = 0.5):
        self.min_success_rate = min_success_rate
    
    def collect_partial_results(
        self,
        wave_id: int,
        task_results: List["TaskResult"],
    ) -> PartialResult:
        """Collect results, tracking success/failure/skipped."""
        result = PartialResult(
            wave_id=wave_id,
            total_tasks=len(task_results),
        )
        
        for tr in task_results:
            result.task_status[tr.task_id] = (
                TaskStatus.COMPLETED if tr.success else TaskStatus.FAILED
            )
            
            if tr.success:
                result.completed_tasks += 1
                result.results[tr.task_id] = tr.content
            else:
                result.failed_tasks += 1
                result.errors[tr.task_id] = tr.error
        
        return result
    
    def should_continue(self, partial: PartialResult) -> bool:
        """Determine if execution should continue despite failures."""
        if partial.total_tasks == 0:
            return False
        
        # Continue if success rate is acceptable
        if partial.success_rate >= self.min_success_rate:
            return True
        
        # Or if at least one task succeeded (for critical path)
        return partial.completed_tasks > 0
    
    def mark_skipped_dependents(
        self,
        failed_task_id: str,
        dependency_graph: "DependencyGraph",
        partial: PartialResult,
    ) -> None:
        """Mark all tasks that depend on a failed task as skipped."""
        dependents = dependency_graph.get_dependents(failed_task_id)
        
        for dep_id in dependents:
            if partial.task_status.get(dep_id) == TaskStatus.PENDING:
                partial.task_status[dep_id] = TaskStatus.SKIPPED
                partial.skipped_tasks += 1
                partial.errors[dep_id] = f"Skipped: dependency {failed_task_id} failed"
```

### Anti-Patterns to Avoid

- **Unbounded parallelism:** Don't spawn unlimited concurrent tasks. Use `max_concurrent` limit to prevent resource exhaustion.
- **Synchronous waits in async context:** Don't use `time.sleep()` or blocking I/O inside async task groups.
- **Ignoring cancellation:** Task groups cancel all tasks on exception. Handle `anyio.get_cancelled_exc_class()` properly.
- **Stale dependency graphs:** Re-analyze dependencies when tasks are added/removed dynamically.
- **Lost context on handoff:** Always pass full conversation history and task outputs to specialist agents.

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| Topological sort / wave grouping | Custom BFS/DFS algorithm | NetworkX `topological_generations()` | Handles cycles, disconnected graphs, edge cases |
| Async task coordination | Manual task tracking with flags | AnyIO `create_task_group()` | Structured concurrency, automatic cleanup, cancellation |
| Inter-task communication | Custom queue with locks | AnyIO `create_memory_object_stream()` | Cloning for multiple consumers, proper async iteration |
| Retry with backoff | Manual while loops with sleep | Tenacity (existing) | Declarative, battle-tested, logging hooks |
| Dependency tracking | Dict of lists with manual cycle detection | NetworkX `DiGraph` | Cycle detection, transitive closure, graph algorithms |

**Key insight:** Python's async ecosystem (AnyIO, NetworkX, Tenacity) already solves these problems. Focus on orchestrating these primitives, not reimplementing them.

## Common Pitfalls

### Pitfall 1: Cycle in Dependency Graph
**What goes wrong:** Tasks depend on each other in a cycle, causing `topological_generations()` to fail.
**Why it happens:** Circular references in plan definitions (A depends on B depends on A).
**How to avoid:** Validate plan definitions before execution; use NetworkX cycle detection.
**Warning signs:** `NetworkXUnfeasible` exception during wave grouping.

```python
# Detection
if not nx.is_directed_acyclic_graph(G):
    cycles = list(nx.simple_cycles(G))
    raise ValueError(f"Dependency cycles detected: {cycles}")
```

### Pitfall 2: Resource Exhaustion from Unbounded Parallelism
**What goes wrong:** Spawning 100+ concurrent tasks overwhelms the system.
**Why it happens:** No limit on concurrent task execution.
**How to avoid:** Use a semaphore or limit tasks per wave.
**Warning signs:** Slow execution, memory growth, connection timeouts.

```python
# Solution: Limit concurrency
async with anyio.create_task_group() as tg:
    # Use semaphore to limit concurrent tasks
    semaphore = anyio.Semaphore(10)  # Max 10 concurrent
    
    async def limited_run(task_id):
        async with semaphore:
            await run_task(task_id)
    
    for task_id in tasks:
        tg.start_soon(limited_run, task_id)
```

### Pitfall 3: Lost Context on Agent Handoff
**What goes wrong:** Specialist agent doesn't have conversation history or previous outputs.
**Why it happens:** Handoff only passes the task, not the full context.
**How to avoid:** Always include `conversation_history` and `task_outputs` in handoff.
**Warning signs:** Specialist agent asks questions that were already answered.

### Pitfall 4: Silent Task Failures in Parallel Execution
**What goes wrong:** A task fails but the error is swallowed, execution continues with incomplete results.
**Why it happens:** Task group exception handling, missing error callbacks.
**How to avoid:** Collect all results including failures; use GracefulDegradation pattern.
**Warning signs:** Missing results, unexpected partial output.

### Pitfall 5: Deadlock in Stream Consumer
**What goes wrong:** Consumer waits forever for stream events that never come.
**Why it happens:** Producer crashes without closing the stream.
**How to avoid:** Always close streams in `finally` block; use timeouts on receive.
**Warning signs:** Consumer hangs indefinitely.

```python
# Solution: Always close in finally
async def produce(send_stream, task_id):
    try:
        # ... produce events ...
    finally:
        await send_stream.aclose()
```

## Code Examples

### Complete Wave Execution Pipeline

```python
import anyio
import networkx as nx
from typing import List, Dict, Any
from dataclasses import dataclass

@dataclass
class WaveResult:
    wave_id: int
    task_ids: List[str]
    results: Dict[str, Any]
    errors: Dict[str, str]
    success: bool

class HybridOrchestrator:
    """Thin orchestrator for hybrid runtime (EXEC-04)."""
    
    def __init__(
        self,
        dependency_graph: DependencyGraph,
        wave_runner: WaveRunner,
        max_concurrent: int = 10,
    ):
        self.graph = dependency_graph
        self.runner = wave_runner
        self.max_concurrent = max_concurrent
    
    async def execute(
        self,
        executor: Callable[[str], Any],
        on_wave_complete: Callable[[WaveResult], None] = None,
        on_progress: Callable[[str, str, str], None] = None,
    ) -> List[WaveResult]:
        """Execute all tasks in dependency-aware waves."""
        waves = self.graph.get_waves()
        wave_results = []
        
        for wave_id, task_ids in enumerate(waves):
            # Execute wave in parallel
            task_results = await self.runner.run_wave(
                tasks=task_ids,
                executor=executor,
                on_progress=on_progress,
            )
            
            # Collect results
            results = {tr.task_id: tr.content for tr in task_results if tr.success}
            errors = {tr.task_id: tr.error for tr in task_results if not tr.success}
            
            wave_result = WaveResult(
                wave_id=wave_id,
                task_ids=task_ids,
                results=results,
                errors=errors,
                success=len(errors) == 0,
            )
            
            wave_results.append(wave_result)
            
            if on_wave_complete:
                on_wave_complete(wave_result)
            
            # Check if we should continue (graceful degradation)
            if not wave_result.success and not self._can_continue(wave_result):
                break
        
        return wave_results
    
    def _can_continue(self, wave_result: WaveResult) -> bool:
        """Check if execution should continue despite failures."""
        # Continue if at least one task succeeded
        return len(wave_result.results) > 0
```

### P2P Agent Communication Channel

```python
class AgentChannel:
    """P2P communication channel between agents (EXEC-04)."""
    
    def __init__(self, buffer_size: int = 50):
        self.buffer_size = buffer_size
        self._channels: Dict[Tuple[str, str], MemoryObjectSendStream] = {}
    
    async def create_channel(
        self,
        from_agent: str,
        to_agent: str,
    ) -> MemoryObjectReceiveStream:
        """Create a communication channel between two agents."""
        key = (from_agent, to_agent)
        send, receive = anyio.create_memory_object_stream(
            max_buffer_size=self.buffer_size
        )
        self._channels[key] = send
        return receive
    
    async def send(
        self,
        from_agent: str,
        to_agent: str,
        message: Any,
    ) -> None:
        """Send a message from one agent to another."""
        key = (from_agent, to_agent)
        if key in self._channels:
            await self._channels[key].send(message)
    
    async def close_channel(self, from_agent: str, to_agent: str) -> None:
        """Close a communication channel."""
        key = (from_agent, to_agent)
        if key in self._channels:
            await self._channels[key].aclose()
            del self._channels[key]
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| asyncio.gather() for parallelism | AnyIO task groups | 2020+ | Structured concurrency, automatic cleanup, cancellation |
| asyncio.Queue for streaming | AnyIO memory object streams | 2020+ | Cloning for multiple consumers, better async iteration |
| Manual topological sort | NetworkX topological_generations() | 2015+ | Handles edge cases, cycle detection, disconnected graphs |
| Callback-based retry | Tenacity decorators | 2017+ | Declarative configuration, composable strategies |

**Deprecated/outdated:**
- `asyncio.gather()` without cancellation handling: Use AnyIO task groups instead
- `asyncio.Queue` for producer-consumer: Use AnyIO memory object streams instead
- Manual retry loops with `time.sleep()`: Use Tenacity instead

## Open Questions

1. **How to handle dynamic task addition during execution?**
   - What we know: Current design assumes static dependency graph
   - What's unclear: Should we support adding tasks mid-execution? How to recompute waves?
   - Recommendation: Start with static graphs; dynamic addition can be Phase 5 enhancement

2. **What's the optimal max_concurrent value?**
   - What we know: Default 10 is conservative
   - What's unclear: Should this be configurable per-agent? Auto-tuned based on system resources?
   - Recommendation: Make configurable with sensible default; auto-tuning is future enhancement

3. **How to handle agent-to-agent requests (pull vs push)?**
   - What we know: P2P channels support push (send to another agent)
   - What's unclear: Should agents be able to request information from other agents?
   - Recommendation: Start with push model (handoff); pull model can be added if needed

## Sources

### Primary (HIGH confidence)
- `/agronholm/anyio` - Task groups, memory object streams, structured concurrency
- `/websites/networkx_stable` - topological_generations, DiGraph, cycle detection
- `/jd/tenacity` - Retry decorators, exponential backoff, before_sleep_log

### Secondary (MEDIUM confidence)
- Phase 1 codebase analysis - Existing patterns (RetryableAgent, SequentialTaskRunner, FileSessionMemory)
- ROADMAP.md and REQUIREMENTS.md - Phase 2 requirements specification

### Tertiary (LOW confidence)
- None - All patterns verified with Context7 and existing codebase

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - All libraries verified via Context7, already using AnyIO/Tenacity
- Architecture: HIGH - Patterns directly from library documentation and Phase 1 patterns
- Pitfalls: HIGH - Based on known async programming issues and library documentation

**Research date:** 2026-02-27
**Valid until:** 30 days (stable libraries, low churn)

---

<phase_requirements>
## Phase Requirements

| ID | Description | Research Support |
|----|-------------|-----------------|
| AGENT-05 | Agents can hand off conversation context to specialist agents | Pattern 4: AgentHandoff with HandoffContext preserves full conversation history, task outputs, routing chain |
| EXEC-01 | System analyzes plan dependencies and groups into waves | Pattern 1: DependencyGraph with NetworkX topological_generations() |
| EXEC-02 | Independent plans in same wave execute in parallel | Pattern 2: WaveRunner with AnyIO task groups |
| EXEC-03 | Dependent plans wait for prerequisite waves to complete | Pattern 1: Wave ordering from topological_generations() ensures dependency order |
| EXEC-04 | Orchestrator coordinates wave execution with P2P agent communication | Pattern: AgentChannel for P2P, HybridOrchestrator for coordination |
| EXEC-08 | Agent output streams in real-time during execution | Pattern 3: OutputStream with AnyIO memory object streams |
| EXEC-09 | User sees agent reasoning as it happens, not just final result | Pattern 3: StreamEventType.REASONING for thinking process |
| EXEC-13 | System retries failed tasks with exponential backoff | Existing: RetryableAgent with Tenacity (Phase 1) |
| EXEC-14 | System falls back to alternative agents when primary fails | Existing: RetryableAgent.fallback_agents chain (Phase 1) |
| EXEC-15 | System degrades gracefully with partial results on unrecoverable errors | Pattern 5: GracefulDegradation with PartialResult collection |
</phase_requirements>
