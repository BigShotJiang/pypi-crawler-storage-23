# Phase 7: Global OpenCode Integration - Context

## User Vision

**Goal:** User can install GSD-RLM globally (`pip install gsd-rlm`) and use it in ANY project by running OpenCode. No local installation needed — everything works from the global package.

**Use Case:**
```bash
# One-time setup
pip install gsd-rlm

# In ANY project folder
cd ~/projects/my-app
opencode
> /gsd-rlm-new-project
> /gsd-rlm-plan-phase 1
> /gsd-rlm-execute-phase 1
```

## Current State

### What's Built (Phases 1-6)

| Phase | Capability | Status |
|-------|------------|--------|
| 01 | Agent definition (YAML), sequential execution, file/shell tools | ✅ |
| 02 | Parallel execution, wave scheduling, P2P channels | ✅ |
| 03 | H-MEM, Memory Bridge, InfiniRetri | ✅ |
| 04 | SecureAgent, Trust Zones, encryption | ✅ |
| 05 | Skills, commands, checkpoints, verification | ✅ |
| 06 | DSPy optimization, R-Zero self-refinement | ✅ |

### Current Package Structure

```
src/gsd_rlm/
├── __init__.py
├── agents/           # AgentDefinition, AgentLoader
├── commands/         # CommandRouter, handlers
├── coordination/     # Orchestrator, P2P channels
├── execution/        # Parallel, retry, streaming
├── memory/           # H-MEM, Bridge, InfiniRetri
├── optimization/     # DSPy, R-Zero
├── security/         # Trust Zones, encryption
├── skills/           # Skill base classes
└── workflow/         # Workflow orchestration
```

### Missing for Global Installation

1. **CLI entry point** — No `gsd-rlm` command
2. **OpenCode command files** — Not in ~/.config/opencode/commands/
3. **Bundled workflows** — Not packaged with pip
4. **Global config** — No ~/.gsd-rlm/ directory

## OpenCode Architecture (Discovered)

### Commands Location

```
~/.config/opencode/commands/
└── gsd/
    ├── gsd-new-project.md      # /gsd-new-project
    ├── gsd-plan-phase.md       # /gsd-plan-phase
    └── ...                     # etc
```

### Command File Format

```yaml
---
name: gsd-new-project
description: Initialize a new project
argument-hint: "[--auto]"
allowed-tools:
  - read
  - bash
  - write
  - task
  - question
---
<objective>
What this command does
</objective>

<execution_context>
@~/.config/opencode/get-shit-done/workflows/new-project.md
</execution_context>

<process>
Execute the workflow from @path end-to-end.
</process>
```

### Skills Location

```
~/.config/opencode/skills/
└── skill-name/
    └── SKILL.md
```

### GSD Pattern (Reference)

```
~/.config/opencode/get-shit-done/
├── workflows/           # Detailed workflow instructions
├── bin/gsd-tools.cjs    # CLI helper tools
├── templates/           # File templates
└── references/          # Reference docs
```

## Requirements for Phase 7

### GLOB-01: pip-installable package
- pyproject.toml with entry_points for CLI
- Proper package structure for PyPI
- Version management

### GLOB-02: CLI entry point
- `gsd-rlm init` — Initialize .planning/ in current directory
- `gsd-rlm status` — Show current project status
- `gsd-rlm version` — Show version info
- `gsd-rlm install-commands` — Install OpenCode commands to ~/.config/opencode/

### GLOB-03: OpenCode command files
- Generate command files during `gsd-rlm install-commands`
- Commands: /gsd-rlm-new-project, /gsd-rlm-plan-phase, /gsd-rlm-execute-phase, /gsd-rlm-progress

### GLOB-04: Bundled workflows
- Package workflows/ directory with the pip package
- Reference via package resource paths

### GLOB-05: Global configuration
- ~/.gsd-rlm/config.json — User preferences
- ~/.gsd-rlm/cache/ — Cached data
- Environment variable support (GSD_RLM_*)

### GLOB-06: Cross-platform support
- Windows, macOS, Linux
- Path handling for all platforms
- Shell compatibility

### GLOB-07: Version management
- Semantic versioning
- Upgrade path without data loss
- Backward compatibility

## Decisions

### Locked Decisions (from user)

1. **Global installation via pip** — Primary distribution method
2. **OpenCode as runtime** — Not Claude Code, Gemini, or others
3. **Any-project usage** — Must work in any folder without local setup

### OpenCode's Discretion

1. **CLI framework** — typer vs click vs argparse (recommend: typer for modern async support)
2. **Package name** — gsd-rlm vs gsd_rlm (recommend: gsd-rlm for CLI)
3. **Config format** — JSON vs TOML vs YAML (recommend: JSON for OpenCode compatibility)
4. **Workflow format** — Bundle as files vs embed in code (recommend: files for editability)

## Technical Constraints

1. **Python 3.10+** — Already in pyproject.toml
2. **No binary compilation** — Pure Python package
3. **Minimal dependencies** — Don't add unnecessary deps
4. **Windows-first** — User is on Windows

## Key Questions for Discussion

1. Should we support multiple OpenCode profiles (work/personal)?
2. Should `gsd-rlm init` also run `git init` if no git repo?
3. Should we auto-detect existing .planning/ and offer to migrate?
4. How to handle updates when command format changes?

## References

- OpenCode GSD commands: ~/.config/opencode/commands/gsd/
- GSD workflows: ~/.config/opencode/get-shit-done/workflows/
- Current pyproject.toml: ./pyproject.toml
- Current package: ./src/gsd_rlm/

---
*Context gathered: 2026-02-28*
