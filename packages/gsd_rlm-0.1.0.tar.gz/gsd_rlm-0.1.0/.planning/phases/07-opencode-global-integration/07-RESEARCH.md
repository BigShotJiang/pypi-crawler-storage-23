# Phase 7: Global OpenCode Integration - Research

**Researched:** 2026-02-28
**Domain:** Python packaging, CLI development, cross-platform configuration
**Confidence:** HIGH

## Summary

This phase transforms GSD-RLM from a local project into a globally installable Python package. Users should be able to run `pip install gsd-rlm` once, then use `/gsd-rlm-*` commands in ANY project via OpenCode. The technical challenge is threefold: (1) creating a proper CLI entry point with typer, (2) bundling OpenCode command files and workflows with the pip package, and (3) managing global configuration in a cross-platform user directory.

The existing codebase already has the core machinery (agents, commands, coordination, memory, etc.). This phase focuses on packaging and distribution infrastructure, not new agent capabilities.

**Primary recommendation:** Use typer for CLI, platformdirs for cross-platform config paths, and hatch's package data bundling for including command/workflow files. Follow the GSD command format exactly for OpenCode compatibility.

<user_constraints>
## User Constraints (from CONTEXT.md)

### Locked Decisions
1. **Global installation via pip** — Primary distribution method
2. **OpenCode as runtime** — Not Claude Code, Gemini, or others
3. **Any-project usage** — Must work in any folder without local setup

### OpenCode's Discretion
1. **CLI framework** — typer vs click vs argparse (recommend: typer for modern async support)
2. **Package name** — gsd-rlm vs gsd_rlm (recommend: gsd-rlm for CLI)
3. **Config format** — JSON vs TOML vs YAML (recommend: JSON for OpenCode compatibility)
4. **Workflow format** — Bundle as files vs embed in code (recommend: files for editability)

### Deferred Ideas (OUT OF SCOPE)
- Multiple OpenCode profiles (work/personal)
- Auto-detecting and migrating existing .planning/ directories
</user_constraints>

<phase_requirements>
## Phase Requirements

| ID | Description | Research Support |
|----|-------------|-----------------|
| GLOB-01 | pip-installable package | pyproject.toml with entry_points for CLI, proper package structure |
| GLOB-02 | CLI entry point (init, status, version, install-commands) | Typer CLI framework with subcommands |
| GLOB-03 | OpenCode command files | Package data bundling, template generation |
| GLOB-04 | Bundled workflows | Package data bundling with hatch/hatchling |
| GLOB-05 | Global configuration (~/.gsd-rlm/) | platformdirs for cross-platform user config directory |
| GLOB-06 | Cross-platform support | pathlib + platformdirs for Windows/macOS/Linux paths |
| GLOB-07 | Version management | Semantic versioning in pyproject.toml and __init__.py |
</phase_requirements>

## Standard Stack

### Core
| Library | Version | Purpose | Why Standard |
|---------|---------|---------|--------------|
| typer | >=0.9.0 | CLI framework with subcommands | Modern, type-safe, async-friendly, Click-compatible |
| platformdirs | >=4.0.0 | Cross-platform user directories | Handles Windows/macOS/Linux differences correctly |
| hatchling | >=1.0.0 | Build backend (already in use) | Modern PEP 621 compliant, package data support |

### Supporting
| Library | Version | Purpose | When to Use |
|---------|---------|---------|-------------|
| rich | >=13.0.0 | CLI output formatting (typer dependency) | Automatic with typer |
| importlib.resources | stdlib | Access bundled package files | For reading command/workflow templates |

### Alternatives Considered
| Instead of | Could Use | Tradeoff |
|------------|-----------|----------|
| typer | click | typer has type hints, better async; click is more mature but verbose |
| typer | argparse | argparse is stdlib but no subcommand groups, verbose for complex CLIs |
| platformdirs | appdirs | appdirs is deprecated; platformdirs is the maintained fork |
| JSON config | TOML config | TOML is more readable but JSON matches OpenCode's preference |

**Installation:**
```bash
# Add to dependencies in pyproject.toml
dependencies = [
    # ... existing ...
    "typer>=0.9.0",
    "platformdirs>=4.0.0",
]
```

## Architecture Patterns

### Recommended Package Structure

```
src/gsd_rlm/
├── __init__.py           # Version, public API exports
├── cli/                  # NEW: CLI module
│   ├── __init__.py       # Typer app, main entry point
│   ├── main.py           # gsd-rlm main command
│   ├── init.py           # gsd-rlm init subcommand
│   ├── install.py        # gsd-rlm install-commands subcommand
│   └── status.py         # gsd-rlm status subcommand
├── commands/             # Existing command routing
├── agents/               # Existing agent system
├── coordination/         # Existing orchestrator
├── execution/            # Existing execution engine
├── memory/               # Existing memory systems
├── optimization/         # Existing DSPy/R-Zero
├── security/             # Existing SecureAgent
├── skills/               # Existing skill discovery
├── workflow/             # Existing workflow orchestration
├── config/               # Existing settings
├── tools/                # Existing tool implementations
├── git/                  # Existing git traceability
├── session/              # Existing session persistence
├── checkpoints/          # Existing checkpoint system
└── bundled/              # NEW: Bundled resources
    ├── commands/         # OpenCode command templates
    │   ├── gsd-rlm-new-project.md
    │   ├── gsd-rlm-plan-phase.md
    │   ├── gsd-rlm-execute-phase.md
    │   └── gsd-rlm-progress.md
    └── workflows/        # Workflow templates (mirrors GSD structure)
        ├── new-project.md
        ├── plan-phase.md
        ├── execute-phase.md
        └── ...
```

### Pattern 1: Typer CLI with Subcommands

**What:** Use typer's `app.add_typer()` for command groups and `@app.command()` for individual commands.

**When to use:** All CLI entry points for gsd-rlm.

**Example:**
```python
# src/gsd_rlm/cli/__init__.py
import typer

app = typer.Typer(
    name="gsd-rlm",
    help="Get Shit Done with Reinforcement Learning for Multi-Agent Systems"
)

# Import subcommands
from gsd_rlm.cli.init import init
from gsd_rlm.cli.install import install_commands
from gsd_rlm.cli.status import status

# Register commands
app.command()(init)
app.command(name="install-commands")(install_commands)
app.command()(status)

# Entry point function
def main():
    """Entry point for gsd-rlm CLI."""
    app()

if __name__ == "__main__":
    main()
```

```python
# src/gsd_rlm/cli/init.py
import typer
from pathlib import Path
from gsd_rlm.config.global_config import GlobalConfig

@app.command()
def init(
    path: Path = typer.Argument(".", help="Directory to initialize"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing files")
):
    """Initialize .planning/ structure in the current or specified directory."""
    target_dir = path.resolve()
    planning_dir = target_dir / ".planning"
    
    if planning_dir.exists() and not force:
        typer.secho(f"Error: {planning_dir} already exists. Use --force to overwrite.", fg=typer.colors.RED)
        raise typer.Exit(1)
    
    # Create .planning/ structure
    planning_dir.mkdir(parents=True, exist_ok=force)
    (planning_dir / "phases").mkdir(exist_ok=True)
    
    # Create default files
    # ...
    
    typer.secho(f"✓ Initialized .planning/ in {target_dir}", fg=typer.colors.GREEN)
```

**Source:** Context7 /fastapi/typer

### Pattern 2: Cross-Platform Config Directory

**What:** Use platformdirs to get the correct user config directory on each platform.

**When to use:** Global configuration storage (~/.gsd-rlm/).

**Example:**
```python
# src/gsd_rlm/config/global_config.py
from pathlib import Path
from platformdirs import user_config_dir, user_data_dir
import json
from typing import Optional
from pydantic import BaseModel

class GlobalConfig(BaseModel):
    """Global GSD-RLM configuration stored in user directory."""
    version: str = "1.0"
    default_provider: str = "ollama"
    last_update_check: Optional[str] = None
    
    class Config:
        extra = "forbid"

def get_config_dir() -> Path:
    """Get the global config directory (~/.gsd-rlm/ or platform equivalent)."""
    config_dir = Path(user_config_dir("gsd-rlm", "gsd-rlm", ensure_exists=True))
    return config_dir

def get_data_dir() -> Path:
    """Get the global data directory for caches, etc."""
    data_dir = Path(user_data_dir("gsd-rlm", "gsd-rlm", ensure_exists=True))
    return data_dir

def load_global_config() -> GlobalConfig:
    """Load global configuration from ~/.gsd-rlm/config.json."""
    config_path = get_config_dir() / "config.json"
    if config_path.exists():
        return GlobalConfig(**json.loads(config_path.read_text()))
    return GlobalConfig()

def save_global_config(config: GlobalConfig) -> None:
    """Save global configuration to ~/.gsd-rlm/config.json."""
    config_path = get_config_dir() / "config.json"
    config_path.write_text(config.model_dump_json(indent=2))
```

**Platform paths:**
- **Windows:** `C:\Users\<user>\AppData\Local\gsd-rlm\gsd-rlm\`
- **macOS:** `/Users/<user>/Library/Application Support/gsd-rlm/`
- **Linux:** `/home/<user>/.config/gsd-rlm/`

**Source:** Context7 /tox-dev/platformdirs

### Pattern 3: pyproject.toml Entry Points

**What:** Define CLI entry point in pyproject.toml under `[project.scripts]`.

**When to use:** Making `gsd-rlm` command available after pip install.

**Example:**
```toml
# pyproject.toml additions
[project.scripts]
gsd-rlm = "gsd_rlm.cli:main"

[tool.hatch.build.targets.wheel]
packages = ["src/gsd_rlm"]
# Include bundled resources
artifacts = ["src/gsd_rlm/bundled/"]
```

**Source:** Context7 /pypa/hatch

### Pattern 4: Bundled Resource Access

**What:** Use importlib.resources to access bundled files from within the package.

**When to use:** Reading command templates and workflow files at runtime.

**Example:**
```python
# src/gsd_rlm/cli/install.py
import typer
from pathlib import Path
from importlib.resources import files, as_file

@app.command(name="install-commands")
def install_commands(
    opencode_dir: Path = typer.Option(
        None,
        "--opencode-dir",
        "-o",
        help="Custom OpenCode config directory (default: ~/.config/opencode/)"
    )
):
    """Install OpenCode command files to ~/.config/opencode/commands/."""
    # Determine target directory
    if opencode_dir is None:
        opencode_dir = Path.home() / ".config" / "opencode"
    
    commands_dir = opencode_dir / "commands" / "gsd-rlm"
    commands_dir.mkdir(parents=True, exist_ok=True)
    
    # Get bundled commands from package
    bundled_commands = files("gsd_rlm.bundled").joinpath("commands")
    
    # Copy each command file
    installed = []
    for resource in bundled_commands.iterdir():
        if resource.name.endswith(".md"):
            target = commands_dir / resource.name
            with as_file(resource) as path:
                target.write_text(path.read_text())
            installed.append(resource.name)
    
    typer.secho(f"✓ Installed {len(installed)} commands to {commands_dir}", fg=typer.colors.GREEN)
    for cmd in installed:
        typer.echo(f"  • /{cmd[:-3]}")  # Remove .md extension
```

**Source:** Python stdlib importlib.resources (Python 3.10+)

### Pattern 5: OpenCode Command File Format

**What:** YAML frontmatter + markdown body format for OpenCode commands.

**When to use:** Creating command templates that OpenCode can parse.

**Example:**
```yaml
---
name: gsd-rlm-new-project
description: Initialize a new project with deep context gathering
argument-hint: "[--auto]"
allowed-tools:
  - read
  - bash
  - write
  - task
  - question
---
<objective>
Initialize a new project through unified flow: questioning → research (optional) → requirements → roadmap.
</objective>

<execution_context>
@~/.config/opencode/gsd-rlm/workflows/new-project.md
</execution_context>

<process>
Execute the new-project workflow end-to-end.
</process>
```

**Source:** Existing GSD command files in ~/.config/opencode/commands/gsd/

### Anti-Patterns to Avoid

- **Hardcoding ~/.gsd-rlm/:** Use platformdirs for cross-platform compatibility
- **Embedding large files in code:** Use package data bundling instead
- **Using click directly when typer is available:** typer provides type hints and better DX
- **Forgetting Windows path separators:** Use pathlib.Path everywhere, not string concatenation
- **Not handling missing config gracefully:** Config should be optional with sensible defaults

## Don't Hand-Roll

| Problem | Don't Build | Use Instead | Why |
|---------|-------------|-------------|-----|
| CLI argument parsing | Custom argparse | typer | Type hints, subcommands, rich output built-in |
| Cross-platform paths | os.path + platform checks | platformdirs | Handles Windows/macOS/Linux correctly |
| Config directory location | ~/.gsd-rlm hardcoded | platformdirs.user_config_dir | Roaming profiles, XDG compliance |
| Package resource access | __file__ manipulation | importlib.resources | Works in zipped eggs, namespace packages |
| Version management | Custom version parsing | pyproject.toml + __init__.__version__ | Standard Python packaging |

**Key insight:** Python packaging has matured significantly. Use the modern stack (hatchling, typer, platformdirs) rather than reimplementing what's already solved.

## Common Pitfalls

### Pitfall 1: Windows Path Handling
**What goes wrong:** Hardcoded Unix paths fail on Windows; backslash issues in config files.
**Why it happens:** Developers test on Unix, deploy to Windows users.
**How to avoid:** Always use `pathlib.Path()`, never concatenate strings with `/` or `\`.
**Warning signs:** Code with `f"{dir}/{file}"` or `os.path.join()` with string manipulation.

### Pitfall 2: Entry Point Not Found After Install
**What goes wrong:** `gsd-rlm: command not found` after `pip install`.
**Why it happens:** Entry point function signature wrong, or module path incorrect in pyproject.toml.
**How to avoid:** Entry point must be `module.path:function_name`, function takes no arguments.
**Warning signs:** `[project.scripts]` pointing to non-existent function.

### Pitfall 3: Bundled Resources Not Found
**What goes wrong:** `FileNotFoundError` when accessing bundled command templates.
**Why it happens:** Hatch doesn't include non-.py files by default; need to configure artifacts.
**How to avoid:** Add `artifacts = ["src/gsd_rlm/bundled/"]` to hatch build config.
**Warning signs:** Tests pass locally but fail after pip install.

### Pitfall 4: Config Permission Errors
**What goes wrong:** Cannot write to ~/.gsd-rlm/ due to permissions.
**Why it happens:** Running in restricted environments, or directory ownership issues.
**How to avoid:** Use `ensure_exists=True` in platformdirs, handle PermissionError gracefully.
**Warning signs:** No error handling around config file writes.

### Pitfall 5: OpenCode Command Not Recognized
**What goes wrong:** `/gsd-rlm-new-project` doesn't appear in OpenCode after install.
**Why it happens:** Command file format invalid, or not in correct directory.
**How to avoid:** Follow exact GSD command format (YAML frontmatter with required fields).
**Warning signs:** Command file missing `name:` in frontmatter.

## Code Examples

### Complete CLI Entry Point

```python
# src/gsd_rlm/cli/__init__.py
"""GSD-RLM CLI entry point."""
import typer
from typing import Optional

app = typer.Typer(
    name="gsd-rlm",
    help="Get Shit Done with Reinforcement Learning for Multi-Agent Systems",
    no_args_is_help=True
)

def main():
    """Entry point called by pip-installed script."""
    app()

# Import and register subcommands
from gsd_rlm.cli import init, install, status, version

app.command()(init.init)
app.command(name="install-commands")(install.install_commands)
app.command()(status.status)
app.command()(version.version)
```

### Version Command

```python
# src/gsd_rlm/cli/version.py
import typer
from gsd_rlm import __version__

def version():
    """Show GSD-RLM version information."""
    typer.secho(f"GSD-RLM version: {__version__}", fg=typer.colors.CYAN)
    typer.echo("Get Shit Done with Reinforcement Learning for Multi-Agent Systems")
    typer.echo("")
    typer.echo("Documentation: https://github.com/gsd-rlm/gsd-rlm")
```

### Install Commands with Verification

```python
# src/gsd_rlm/cli/install.py
import typer
from pathlib import Path
from importlib.resources import files
from typing import Optional

def install_commands(
    opencode_dir: Optional[Path] = typer.Option(
        None,
        "--opencode-dir", "-o",
        help="Custom OpenCode config directory"
    ),
    force: bool = typer.Option(
        False,
        "--force", "-f",
        help="Overwrite existing command files"
    )
):
    """Install OpenCode command files to ~/.config/opencode/commands/."""
    # Determine target directory
    if opencode_dir is None:
        opencode_dir = Path.home() / ".config" / "opencode"
    
    if not opencode_dir.exists():
        typer.secho(f"Error: OpenCode directory not found: {opencode_dir}", fg=typer.colors.RED)
        typer.echo("Please install OpenCode first: https://opencode.ai")
        raise typer.Exit(1)
    
    commands_dir = opencode_dir / "commands" / "gsd-rlm"
    workflows_dir = opencode_dir / "gsd-rlm" / "workflows"
    
    commands_dir.mkdir(parents=True, exist_ok=True)
    workflows_dir.mkdir(parents=True, exist_ok=True)
    
    installed_commands = _install_resources("commands", commands_dir, force)
    installed_workflows = _install_resources("workflows", workflows_dir, force)
    
    typer.secho("\n✓ Installation complete!", fg=typer.colors.GREEN, bold=True)
    typer.echo(f"\nCommands installed to: {commands_dir}")
    typer.echo(f"Workflows installed to: {workflows_dir}")
    typer.echo("\nAvailable commands:")
    for cmd in installed_commands:
        name = cmd[:-3] if cmd.endswith(".md") else cmd
        typer.echo(f"  /{name}")

def _install_resources(resource_type: str, target_dir: Path, force: bool) -> list[str]:
    """Install bundled resources of a given type."""
    bundled = files("gsd_rlm.bundled").joinpath(resource_type)
    installed = []
    
    for resource in bundled.iterdir():
        if resource.name.endswith(".md"):
            target = target_dir / resource.name
            if target.exists() and not force:
                typer.echo(f"  Skipping {resource.name} (exists, use --force to overwrite)")
                continue
            
            content = resource.read_text()
            target.write_text(content)
            installed.append(resource.name)
    
    return installed
```

## State of the Art

| Old Approach | Current Approach | When Changed | Impact |
|--------------|------------------|--------------|--------|
| setup.py with setuptools | pyproject.toml with hatchling | 2020+ (PEP 621) | Single config file, modern build |
| argparse for CLIs | typer with type hints | 2020+ | Auto-generated help, validation |
| appdirs (deprecated) | platformdirs | 2022 | Maintained fork, active development |
| __file__ for resources | importlib.resources | Python 3.7+ | Works in zipped packages |

**Deprecated/outdated:**
- **appdirs:** Deprecated in 2022, use platformdirs instead
- **setup.py:** Legacy, use pyproject.toml with hatchling
- **pkg_resources:** Slow, use importlib.resources

## Open Questions

1. **Should `gsd-rlm init` also run `git init` if no git repo?**
   - What we know: GSD workflow expects git for traceability
   - What's unclear: Should this be automatic or prompted?
   - Recommendation: Prompt user with `--git` flag, don't auto-init

2. **How to handle updates when command format changes?**
   - What we know: Commands are static files, not versioned
   - What's unclear: Migration path for breaking changes
   - Recommendation: Version the command files (e.g., v1/, v2/) or include version in frontmatter

3. **Should workflows be editable by users?**
   - What we know: Workflows are copied to user directory
   - What's unclear: Should `gsd-rlm install-commands` overwrite user modifications?
   - Recommendation: Only overwrite if `--force`, warn about local changes

## Sources

### Primary (HIGH confidence)
- Context7 /fastapi/typer - Typer CLI framework with subcommands, type hints
- Context7 /pypa/hatch - pyproject.toml entry points, package configuration
- Context7 /tox-dev/platformdirs - Cross-platform user directory paths
- ~/.config/opencode/commands/gsd/*.md - Existing GSD command format examples
- ~/.config/opencode/get-shit-done/workflows/*.md - Existing workflow file patterns

### Secondary (MEDIUM confidence)
- Python stdlib importlib.resources documentation - Package resource access
- PEP 621 - pyproject.toml metadata specification

### Tertiary (LOW confidence)
- None - All core patterns verified with primary sources

## Metadata

**Confidence breakdown:**
- Standard stack: HIGH - All libraries verified via Context7, well-established patterns
- Architecture: HIGH - Based on existing GSD patterns and Python packaging best practices
- Pitfalls: HIGH - Common issues documented in official docs and community resources

**Research date:** 2026-02-28
**Valid until:** 30 days - Python packaging patterns are stable, but verify versions before implementation
