# simplecrypt

A simple Python library for encryption and decryption using Fernet.

## Installation

```bash
pip install anacondaencryptx