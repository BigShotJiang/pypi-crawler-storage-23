from cryptography.fernet import Fernet

class AnacondaEncryptX:
    def __init__(self, key: bytes = None):
        if key is None:
            key = Fernet.generate_key()
        self.key = key
        self.cipher = Fernet(self.key)

    def encrypt(self, text: str) -> bytes:
        return self.cipher.encrypt(text.encode())

    def decrypt(self, token: bytes) -> str:
        return self.cipher.decrypt(token).decode()

    @staticmethod
    def generate_key() -> bytes:
        return Fernet.generate_key()