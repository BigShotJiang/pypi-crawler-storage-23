# Mob Construction — Session Plan

> **Usage:** The AI fills this plan during the session and updates status as stages complete.
> If the session is interrupted, the next session reads this file to resume.
> One plan per Bolt. Copy this file for each new Bolt.

| Field | Value |
|-------|-------|
| **Intent** | (filled from intents/intent-primary.md) |
| **Mode** | greenfield / brownfield |
| **Bolt** | (bolt number, e.g., Bolt 1) |
| **Unit** | (unit name) |
| **Started** | (date) |
| **Last Updated** | (date) |
| **Current Stage** | (number) |

---

## Progress

| # | Stage | Status | Artifacts |
|---|-------|--------|-----------|
| 0 | Pre-flight Check | ⬜ Pending | — |
| 1 | Domain Modeling | ⬜ Pending | mob-construction/[bolt]/domain_model.md |
| 2 | Integration Design (brownfield only) | ⬜ Pending | mob-construction/[bolt]/integration_design.md |
| 3 | Logical Design | ⬜ Pending | mob-construction/[bolt]/logical_design.md |
| 4 | Code Generation | ⬜ Pending | [project_folder]/ |
{{#enterprise}}
| 5 | Test & Validation | ⬜ Pending | [project_folder]/tests/, guardrails_report.md |
{{/enterprise}}
{{#standard}}
| 5 | Test & Validation | ⬜ Pending | [project_folder]/tests/ |
{{/standard}}

Status legend: ⬜ Pending · 🔄 In Progress · ✅ Done · ⏭️ Skipped (N/A)

---

## Stories in This Bolt

| Story ID | Title | Status |
|----------|-------|--------|
| | | |

---

## Session Notes

(AI and team notes, interruptions, decisions to revisit)
