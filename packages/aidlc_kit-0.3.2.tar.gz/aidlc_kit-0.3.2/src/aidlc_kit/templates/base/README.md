# {{PROJECT_NAME}} — AI-DLC Project

| Field | Value |
|-------|-------|
| Project | {{PROJECT_NAME}} |
| Mode | {{MODE}} |
| Platform | {{PLATFORM}} |
| Tier | {{TIER}} |
| Created | {{DATE}} |
{{#enterprise}}
| EGS Version | (fill after customizing egs_definition.md) |
{{/enterprise}}
| Team | (list team members and roles) |
| Facilitator | (name) |

---

{{IDE_SETUP}}
## Folder Guide

| Folder | Purpose |
|--------|---------|
{{#enterprise}}
| `egs_definition.md` | Enterprise Guardrails Specification: your project's "constitution" |
{{/enterprise}}
| `intents/` | High-level feature descriptions that drive Mob Elaboration |
| `prompts/` | AI-DLC prompt templates (used automatically by IDE routers, or paste manually) |
{{#enterprise}}
| `mob-elaboration/` | Mob Elaboration outputs: plan, stories, compliance matrix |
| `mob-construction/` | Per-bolt outputs: domain model, logical design, code, compliance report |
| `code-elevation/` | (Brownfield) Code Elevation outputs: static/dynamic models, tech debt, gap analysis |
| `decisions/` | Decision log with traceability to guardrails |
| `overrides/` | Documented guardrail exceptions with compensating controls |
{{/enterprise}}
{{#standard}}
| `mob-elaboration/` | Mob Elaboration outputs: plan, stories, units, NFRs |
| `mob-construction/` | Per-bolt outputs: domain model, logical design, code |
| `code-elevation/` | (Brownfield) Code Elevation outputs: static/dynamic models, tech debt |
| `decisions/` | Decision log with architectural decisions |
{{/standard}}
| `completion/` | Completion prompts: bolt criteria, consistency check, intent consolidation |
| `retrospectives/` | Post-session retrospective template |
| `archive/` | Completed intents moved here for historical reference |

## Workflow

{{#enterprise}}
1. Customize `egs_definition.md` with your project's guardrails
2. Write your intent in `intents/intent-primary.md`
{{/enterprise}}
{{#standard}}
1. Write your intent in `intents/intent-primary.md`
{{/standard}}
2. (Brownfield only) Run Code Elevation to analyze the existing codebase
3. Start Mob Elaboration to break the intent into stories, units, and bolts
4. Start Mob Construction bolt by bolt
5. Between bolts: run a consistency check or validate bolt completion criteria
6. After all bolts: run intent consolidation, then archive to `archive/`

Ask your AI assistant by name (if IDE router is set up) or paste the prompt from `prompts/` or `completion/`.
