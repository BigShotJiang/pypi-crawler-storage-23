# Intent: [Name]

> Replace this template with your intent. An intent describes WHAT you want to build and WHY, not HOW.

**Type:** feature | bugfix | maintenance
<!-- Choose one. feature = new capability, bugfix = fix defect in existing code, maintenance = refactor/upgrade/tech debt -->

## Summary

(One paragraph: what does this feature do and why does it matter?)
<!-- For bugfix: describe the bug, expected vs actual behavior, and reproduction steps -->
<!-- For maintenance: describe what needs to change and why (e.g., dependency upgrade, refactor) -->

## Users / Actors

(Who interacts with this feature?)

## Key Scenarios

1. (Scenario 1: user does X, system does Y)
2. (Scenario 2)
3. (Scenario 3)

## Constraints

- (Any known constraints: regulatory, technical, timeline)

## Out of Scope

- (What this intent explicitly does NOT cover)

## Success Criteria

- (How do you know this intent is done?)
