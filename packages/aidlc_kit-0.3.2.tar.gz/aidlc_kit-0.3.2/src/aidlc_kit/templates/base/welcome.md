This project follows the **AI Development Lifecycle (AI-DLC)** methodology, a structured approach to building software with AI assistance.

AI-DLC is described in *Reimagine, Don't Retrofit* by Ricardo González Vargas. This tool (aidlc-kit) provides the project scaffolding, prompt templates, and consistency checks to put the methodology into practice.

### How it works
- **Rituals** are the core workflows (Mob Elaboration, Mob Construction, and Code Elevation for brownfield). Each ritual has a prompt file that the AI reads and follows step by step.
- **Phases/Stages** break each ritual into checkpoints. The AI asks for your approval before moving to the next one.
- **Bolts** are the smallest units of deliverable work. Each bolt goes through domain modeling, design, code generation, and testing.
- **Completion actions** (consistency check, intent consolidation, bolt criteria, retrospective) are available between or after rituals for quality assurance.

### Your role
You decide what to build, approve plans, and validate outputs. The AI drives the workflow, asks clarifying questions, and generates artifacts. You stay in control at every checkpoint.

### Getting started
Ask for a ritual by name (e.g., "start Mob Elaboration") and the AI will read the prompt file and guide you through it.

---
aidlc-kit is licensed under the Business Source License 1.1. Free to use for your projects. See LICENSE for details.
