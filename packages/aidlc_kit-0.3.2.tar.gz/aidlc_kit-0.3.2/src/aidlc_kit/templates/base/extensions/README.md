# Extensions

Extensions are cross-cutting rules that the AI enforces at every phase and stage
of an AI-DLC ritual. They work alongside (not instead of) the standard prompt
instructions.

## How It Works

1. During pre-flight, the AI scans this directory for `.md` files.
2. Each extension file contains rules with verification criteria.
3. If an extension has an **Applicability Question**, the AI asks it during the
   first ritual and records the answer in `aidlc-docs/aidlc-state.md`.
4. Enabled extensions are enforced as **blocking constraints**: a stage cannot
   complete until all applicable rules pass or are marked N/A.
5. Non-compliant findings are logged in `aidlc-docs/audit/audit-log.md`.

## Included Extensions

| File | Description |
|------|-------------|
| `security-extensions.md` | Security rules organized by AI-DLC phase (design, build, ops) with checklist enforcement |

## Adding Your Own

Drop any `.md` file in this directory following the format:

```markdown
# Extension Name

## Overview
What this extension enforces and why.

## Applicability Question
(Optional) A question the AI asks to enable/disable this extension.

## Rule EXT-01: Rule Name
**Rule**: What must be true.
**Verification**: How to check it.

## Enforcement Integration
Summary of how rules apply across stages.
```

## Removing Extensions

Delete the file. The AI will no longer enforce those rules.
