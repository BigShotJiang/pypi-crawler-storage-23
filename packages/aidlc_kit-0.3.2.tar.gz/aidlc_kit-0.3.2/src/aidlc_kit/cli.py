"""CLI entry point for aidlc-kit."""

import atexit
import json
import shutil
import time
from pathlib import Path
from urllib.request import urlopen

import click

from aidlc_kit import __version__
from aidlc_kit.scaffold import IDES, TIERS, archive_project, check_project, consistency_check, scaffold_project, status_project, update_project

_CACHE_DIR = Path.home() / ".aidlc-kit"
_CACHE_FILE = _CACHE_DIR / "last-update-check"
_CHECK_INTERVAL = 86400  # 24 hours
_PYPI_URL = "https://pypi.org/pypi/aidlc-kit/json"
_TIMEOUT = 2


_UPDATE_MSG = "\n⚠ Update available: {} → {}\n  pip install --upgrade aidlc-kit  |  uv tool upgrade aidlc-kit  |  uvx aidlc-kit@latest"


def _check_for_update() -> None:
    """Print a notice if a newer version is available. Cached daily, never errors."""
    try:
        if _CACHE_FILE.exists():
            data = json.loads(_CACHE_FILE.read_text())
            if time.time() - data.get("ts", 0) < _CHECK_INTERVAL:
                latest = data.get("v", __version__)
                if latest != __version__:
                    click.echo(_UPDATE_MSG.format(__version__, latest))
                return
        resp = urlopen(_PYPI_URL, timeout=_TIMEOUT)
        latest = json.loads(resp.read()).get("info", {}).get("version", __version__)
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _CACHE_FILE.write_text(json.dumps({"v": latest, "ts": time.time()}))
        if latest != __version__:
            click.echo(_UPDATE_MSG.format(__version__, latest))
    except Exception:
        pass

atexit.register(_check_for_update)


@click.group()
@click.version_option(version=__version__)
def main():
    """AI-DLC project scaffolding tool."""


def _parse_ides(raw: tuple[str, ...]) -> list[str] | None:
    """Flatten comma-separated and repeated --ide values; validate each."""
    if not raw:
        return None
    names: list[str] = []
    for token in raw:
        names.extend(t.strip().lower() for t in token.split(",") if t.strip())
    if "all" in names:
        return list(IDES)
    invalid = [n for n in names if n not in IDES]
    if invalid:
        raise click.ClickException(
            f"Unknown IDE(s): {', '.join(invalid)}. Choose from: {', '.join(IDES)}, or 'all'."
        )
    # deduplicate preserving order
    seen: set[str] = set()
    return [n for n in names if not (n in seen or seen.add(n))]


_IDE_HELP = (
    "IDE router configs to generate. Repeat or comma-separate: "
    "--ide kiro --ide cursor or --ide kiro,cursor. "
    f"Use 'all' for every IDE. Supported: {', '.join(IDES)}."
)


_MODES = ["greenfield", "brownfield"]
_PLATFORMS = ["aws", "azure", "gcp", "onprem", "agnostic"]
_TIERS = ["enterprise", "standard"]


def _pick(label: str, options: list[str], descriptions: dict[str, str] | None = None) -> str:
    """Numbered picker — returns chosen value."""
    click.echo(f"\n{label}:")
    for i, opt in enumerate(options, 1):
        desc = f"  — {descriptions[opt]}" if descriptions and opt in descriptions else ""
        click.echo(f"  {i}. {opt}{desc}")
    while True:
        raw = click.prompt(">", prompt_suffix=" ").strip().lower()
        if raw in options:
            return raw
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1]
        click.echo(f"  Invalid choice. Enter 1-{len(options)} or a name.")


def _pick_ides() -> list[str] | None:
    """IDE picker — returns list, empty list for none, or full list for all."""
    ide_list = list(IDES)
    click.echo("\nIDE config (required — pick one or more, comma-separate for multiple):")
    cols = 3
    for i, name in enumerate(ide_list, 1):
        end = "\n" if i % cols == 0 else ""
        click.echo(f"  {i:>2}. {name:<16}", nl=False)
        if end:
            click.echo()
    if len(ide_list) % cols:
        click.echo()
    click.echo(f"   a. all — every IDE")
    click.echo(f"   n. none — skip (add later with 'aidlc-kit update --ide')")
    while True:
        raw = click.prompt(">", prompt_suffix=" ").strip().lower()
        if raw == "n" or raw == "none":
            click.echo("  ℹ No IDE config generated. Run 'aidlc-kit update --ide <name>' to add later.")
            return None
        if raw == "a" or raw == "all":
            return list(IDES)
        tokens = [t.strip() for t in raw.replace(",", " ").split() if t.strip()]
        resolved: list[str] = []
        bad = False
        for t in tokens:
            if t in ide_list:
                resolved.append(t)
            elif t.isdigit() and 1 <= int(t) <= len(ide_list):
                resolved.append(ide_list[int(t) - 1])
            else:
                click.echo(f"  Unknown: '{t}'. Enter numbers, names, 'a', or 'n'.")
                bad = True
                break
        if bad:
            continue
        if not resolved:
            click.echo("  Pick at least one, 'a' for all, or 'n' for none.")
            continue
        seen: set[str] = set()
        return [r for r in resolved if not (r in seen or seen.add(r))]


@main.command()
@click.argument("target", default=".")
@click.option("--mode", default=None,
              help="Project mode: greenfield (new) or brownfield (existing codebase).")
@click.option("--platform", default=None,
              help="Deployment platform: aws, azure, gcp, onprem, agnostic.")
@click.option("--name", default=None, help="Project name. Defaults to target directory name.")
@click.option("--force", is_flag=True, help="Overwrite existing aidlc-docs/ if present.")
@click.option("--ide", multiple=True, default=None,
              help=_IDE_HELP)
@click.option("--tier", default=None,
              help="Prompt tier: enterprise (with EGS guardrails) or standard (no guardrails). Default: standard.")
def init(target: str, mode: str | None, platform: str | None, name: str | None, force: bool, ide: tuple[str, ...], tier: str | None):
    """Scaffold an AI-DLC project at TARGET directory.

    TARGET defaults to the current directory (.).
    """
    # Validate if passed on CLI
    if mode and mode.lower() not in _MODES:
        raise click.ClickException(f"Invalid mode '{mode}'. Choose from: {', '.join(_MODES)}")
    if platform and platform.lower() not in _PLATFORMS:
        raise click.ClickException(f"Invalid platform '{platform}'. Choose from: {', '.join(_PLATFORMS)}")
    if tier and tier.lower() not in _TIERS:
        raise click.ClickException(f"Invalid tier '{tier}'. Choose from: {', '.join(_TIERS)}")
    if mode:
        mode = mode.lower()
    if platform:
        platform = platform.lower()
    if tier:
        tier = tier.lower()

    wizard = mode is None or platform is None
    if wizard:
        click.echo("🔧 aidlc-kit init — project setup")
    if mode is None:
        mode = _pick("Mode (required)", _MODES, {
            "greenfield": "new project, no existing code",
            "brownfield": "existing codebase to improve",
        })
    if platform is None:
        platform = _pick("Platform (required)", _PLATFORMS)
    if tier is None and wizard:
        pass  # tier stays None, resolved to "standard" below
    tier = tier or "standard"
    ides = _parse_ides(ide)
    if ides is None and wizard:
        ides = _pick_ides()
    scaffold_project(target, mode, name, force, platform, ides, tier)


@main.command()
@click.argument("target", default=".")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
@click.option(
    "--platform",
    type=click.Choice(["aws", "azure", "gcp", "onprem", "agnostic"], case_sensitive=False),
    default=None,
    help="Deployment platform. Auto-detected from README; required if README lacks Platform row.",
)
@click.option("--ide", multiple=True, default=None,
              help=f"Regenerate {_IDE_HELP}")
@click.option("--tier", default=None,
              help="Override tier: enterprise or standard. Auto-detected from README.")
def update(target: str, yes: bool, platform: str | None, ide: tuple[str, ...], tier: str | None):
    """Update kit-owned templates in an existing AI-DLC project.

    Overwrites prompts, blank templates, and completion criteria.
    Preserves user content: intents, archive, and README.
    """
    ides = _parse_ides(ide)
    update_project(target, yes, platform, ides, tier)


@main.command()
@click.argument("target", default=".")
@click.option("--name", default=None, help="Archive folder name. Defaults to intent name.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def archive(target: str, name: str | None, yes: bool):
    """Archive completed intent and reset workspace for the next one.

    Moves intents, elaboration, construction, decisions, and retrospectives
    into archive/<name>-<date>/. Restores blank templates.
    """
    archive_project(target, name, yes)


@main.command()
@click.argument("target", default=".")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON.")
def check(target: str, output_json: bool):
    """Check health of an existing AI-DLC project.

    Validates required files, customization status, plan progress,
    and template drift.
    """
    check_project(target, as_json=output_json)


@main.command()
@click.argument("target", default=".")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON.")
def status(target: str, output_json: bool):
    """Show current project status dashboard."""
    status_project(target, as_json=output_json)


@main.command()
@click.argument("target", default=".")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON.")
def consistency(target: str, output_json: bool):
    """Run structural consistency checks across project artifacts.

    Checks stories↔bolts, dependencies, decision log, EGS structure,
    retro action items, unit mapping, bolt plan completeness, and audit log.
    """
    consistency_check(target, as_json=output_json)


@main.command(name="export-egs")
@click.argument("target", default=".")
@click.argument("output", default="egs_definition.md")
def export_egs(target: str, output: str):
    """Export the project's EGS definition to a file.

    \b
    Usage examples:
      aidlc-kit export-egs myproject /tmp/shared-egs.md
      aidlc-kit export-egs myproject                      # saves to ./egs_definition.md
    """
    src = Path(target).resolve() / "aidlc-docs" / "egs_definition.md"
    if not src.exists():
        raise click.ClickException(
            f"No EGS found at {src}.\n\n"
            "Usage: aidlc-kit export-egs <project-dir> [output-file]\n"
            "  Example: aidlc-kit export-egs myproject /tmp/shared-egs.md"
        )
    dst = Path(output).resolve()
    shutil.copy2(src, dst)
    click.echo(f"✓ EGS exported to {dst}")
    click.echo(f"\nTo import into another project:")
    click.echo(f"  aidlc-kit import-egs {dst} /path/to/project")


@main.command(name="import-egs")
@click.argument("source", required=False, default=None)
@click.argument("target", default=".")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def import_egs(source: str | None, target: str, yes: bool):
    """Import an external EGS definition into the project.

    \b
    Usage examples:
      aidlc-kit import-egs /tmp/shared-egs.md myproject
      aidlc-kit import-egs /tmp/shared-egs.md              # imports into current dir
    """
    if source is None:
        raise click.ClickException(
            "Missing SOURCE file.\n\n"
            "Usage: aidlc-kit import-egs <egs-file> [project-dir]\n"
            "  Example: aidlc-kit import-egs /tmp/shared-egs.md myproject"
        )
    src = Path(source).resolve()
    if not src.exists():
        raise click.ClickException(f"Source file not found: {src}")
    dst = Path(target).resolve() / "aidlc-docs" / "egs_definition.md"
    if not dst.parent.is_dir():
        raise click.ClickException(f"No aidlc-docs/ found at {dst.parent}. Run 'init' first.")
    if dst.exists() and not yes:
        text = dst.read_text(encoding="utf-8")
        if "Generic Template" not in text:
            click.confirm("EGS is already customized. Overwrite?", abort=True)
    shutil.copy2(src, dst)
    click.echo(f"✓ EGS imported from {src}")
    click.echo(f"\nNext steps:")
    click.echo(f"  1. Review {dst} and adjust org name, thresholds, and policies for this project")
    click.echo(f"  2. Run 'aidlc-kit check {target}' to validate EGS structure")
