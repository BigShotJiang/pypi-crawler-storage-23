"""Core scaffolding logic: copy base + mode templates, render README."""

import json
import re
import shutil
from datetime import date
from importlib import resources
from pathlib import Path

import click


TEMPLATES = resources.files("aidlc_kit") / "templates"

# Dirs/files to archive (move into archive folder)
ARCHIVABLE = {"intents", "mob-elaboration", "mob-construction", "code-elevation",
              "decisions", "retrospectives", "audit"}

# Files/dirs that belong to the user — never overwrite on update
USER_OWNED = {"intents", "archive", "README.md", "decision-log.md", "egs_definition.md", "audit"}


PLATFORMS = ("aws", "azure", "gcp", "onprem", "agnostic")

# IDE config: ide_key → (directory relative to project root, filename, format)
# format: "plain" = markdown, "cursor" = .mdc with alwaysApply, "kiro" = inclusion: always, "frontmatter" = YAML description header
IDE_CONFIGS = {
    "agents-md": ("", "AGENTS.md", "plain"),
    "aider": ("", "CONVENTIONS.md", "plain"),
    "amp": (".agents/rules", "aidlc-router.md", "plain"),
    "auggie": (".augment/rules", "aidlc-router.md", "frontmatter"),
    "claude-code": ("", "CLAUDE.md", "plain"),
    "cline": (".clinerules", "aidlc-router.md", "plain"),
    "codebuddy": (".codebuddy/rules", "aidlc-router.md", "frontmatter"),
    "codex": ("", "AGENTS.md", "plain"),
    "copilot": (".github", "copilot-instructions.md", "plain"),
    "copilot-cli": (".github", "copilot-instructions.md", "plain"),
    "costrict": (".cospec/rules", "aidlc-router.md", "frontmatter"),
    "crush": (".crush/rules", "aidlc-router.md", "frontmatter"),
    "cursor": (".cursor/rules", "aidlc-router.mdc", "cursor"),
    "factory-droid": (".factory/rules", "aidlc-router.md", "frontmatter"),
    "gemini": (".gemini/settings", "aidlc-router.md", "plain"),
    "gemini-cli": ("", "GEMINI.md", "plain"),
    "iflow": (".iflow/rules", "aidlc-router.md", "frontmatter"),
    "kilo-code": (".kilocode/workflows", "aidlc-router.md", "plain"),
    "kiro": (".kiro/steering", "aidlc-router.md", "kiro"),
    "opencode": (".opencode/rules", "aidlc-router.md", "frontmatter"),
    "q-developer": (".amazonq/rules", "aidlc-router.md", "plain"),
    "qoder": (".qoder/rules", "aidlc-router.md", "frontmatter"),
    "roo-code": (".roo/rules", "aidlc-router.md", "plain"),
    "windsurf": (".windsurf/workflows", "aidlc-router.md", "frontmatter"),
}
IDES = tuple(IDE_CONFIGS.keys())

TIERS = ("enterprise", "standard")

# Files/dirs removed from scaffold when tier=standard
_ENTERPRISE_ONLY = (
    "egs_definition.md",
    "egs_variants",
    "overrides",
    "guardrails_compliance_matrix.md",
    "guardrails_gap_analysis.md",
)

_TIER_BLOCK_RE = re.compile(r"{{#(enterprise|standard)}}[ \t]*\n(.*?){{/\1}}[ \t]*\n", re.DOTALL)


def _strip_tier_blocks(text: str, tier: str) -> str:
    """Remove conditional blocks for the opposite tier, keep blocks for *tier*."""
    def _replace(m: re.Match) -> str:
        return m.group(2) if m.group(1) == tier else ""
    return _TIER_BLOCK_RE.sub(_replace, text)


def scaffold_project(target: str, mode: str, name: str | None, force: bool, platform: str, ides: list[str] | None = None, tier: str = "standard") -> None:
    target_path = Path(target).resolve()

    if target != ".":
        target_path.mkdir(parents=True, exist_ok=True)

    if not target_path.is_dir():
        raise click.ClickException(f"Target is not a directory: {target_path}")

    docs_path = target_path / "aidlc-docs"

    if docs_path.exists() and not force:
        raise click.ClickException(
            f"{docs_path} already exists. Use --force to overwrite."
        )

    project_name = name or target_path.name

    # Clean slate if forcing
    if docs_path.exists() and force:
        shutil.rmtree(docs_path)

    # Copy base templates
    _copy_tree(TEMPLATES / "base", docs_path, exclude={"egs_variants", "welcome.md"}, tier=tier)

    # Replace generic EGS with platform-specific variant
    variant = TEMPLATES / "base" / "egs_variants" / f"egs_definition_{platform}.md"
    if variant.exists():
        shutil.copy2(variant, docs_path / "egs_definition.md")

    # Copy mode-specific templates (merge into docs_path)
    _copy_tree(TEMPLATES / mode, docs_path, tier=tier)

    # Remove enterprise-only files when tier=standard
    if tier == "standard":
        for name_to_remove in _ENTERPRISE_ONLY:
            for p in docs_path.rglob(name_to_remove):
                if p.is_dir():
                    shutil.rmtree(p)
                elif p.is_file():
                    p.unlink()

    if ides:
        for ide in ides:
            _generate_ide_config(target_path, mode, ide, tier)

    # Render the project README (after IDE configs so we know which IDEs were set up)
    _render_readme(docs_path / "README.md", project_name, mode, platform, ides, tier)

    # Render mode-aware state file
    _render_state(docs_path / "aidlc-state.md", mode, tier)

    tier_label = f", {tier} tier" if tier != "standard" else ""
    click.echo(f"✓ AI-DLC project scaffolded at {docs_path} ({mode} mode, {platform} platform{tier_label})")
    click.echo()
    click.echo("Next steps:")
    step = 1
    if tier == "enterprise":
        click.echo(f"  {step}. Customize {docs_path / 'egs_definition.md'} for your project")
        step += 1
    click.echo(f"  {step}. Write your intent in {docs_path / 'intents' / 'intent-primary.md'}")
    step += 1
    if ides:
        ide_name = ides[0].replace("-", " ").title()
        click.echo(f"  {step}. Open your project in {ide_name} and ask: \"Start Mob Elaboration\"")
    else:
        click.echo(f"  {step}. Paste the prompt from {docs_path / 'prompts' / 'mob-elaboration.md'} into your AI assistant")


def _copy_tree(src: Path, dst: Path, exclude: set[str] | None = None, tier: str = "enterprise") -> None:
    """Recursively copy a template directory, preserving structure."""
    for item in src.iterdir():
        if exclude and item.name in exclude:
            continue
        dest_item = dst / item.name
        if item.is_dir():
            dest_item.mkdir(parents=True, exist_ok=True)
            _copy_tree(item, dest_item, exclude, tier)
        else:
            dest_item.parent.mkdir(parents=True, exist_ok=True)
            if item.suffix == ".md":
                text = item.read_text(encoding="utf-8")
                dest_item.write_text(_strip_tier_blocks(text, tier), encoding="utf-8")
            else:
                shutil.copy2(item, dest_item)


def _render_readme(path: Path, project_name: str, mode: str, platform: str = "aws", ides: list[str] | None = None, tier: str = "enterprise") -> None:
    """Replace placeholders in the project README template."""
    content = path.read_text(encoding="utf-8")
    content = _strip_tier_blocks(content, tier)
    content = content.replace("{{PROJECT_NAME}}", project_name)
    content = content.replace("{{DATE}}", date.today().isoformat())
    content = content.replace("{{MODE}}", mode)
    content = content.replace("{{PLATFORM}}", platform)
    content = content.replace("{{TIER}}", tier)

    # Build IDE setup section
    if ides:
        ide_lines = ["## IDE Setup", ""]
        ide_lines.append("Router files were generated for your AI coding assistant(s). "
                         "The router tells the AI agent where to find prompts and artifacts, "
                         "so you can request rituals by name instead of pasting prompts manually.")
        ide_lines.append("")
        ide_lines.append("| IDE | Router File |")
        ide_lines.append("|-----|-------------|")
        for ide in ides:
            dir_rel, filename, _ = IDE_CONFIGS[ide]
            router_path = f"{dir_rel}/{filename}" if dir_rel else filename
            ide_lines.append(f"| {ide.replace('-', ' ').title()} | `{router_path}` |")
        ide_lines.append("")
        ide_lines.append("**How to use:** Open your project in the IDE and ask your AI assistant:")
        ide_lines.append("")
        if mode == "brownfield":
            ide_lines.append('- "Start Code Elevation"')
        ide_lines.append('- "Start Mob Elaboration"')
        ide_lines.append('- "Start Mob Construction"')
        ide_lines.append('- "Run a consistency check"')
        ide_lines.append('- "Check bolt completion criteria"')
        ide_lines.append("")
        content = content.replace("{{IDE_SETUP}}", "\n".join(ide_lines))
    else:
        content = content.replace("{{IDE_SETUP}}\n", "")

    path.write_text(content, encoding="utf-8")


def _build_router_body(mode: str, tier: str = "enterprise") -> str:
    """Build the markdown body for an IDE router file."""
    welcome = (TEMPLATES / "base" / "welcome.md").read_text(encoding="utf-8").strip()

    rituals = [
        ("Mob Elaboration", "aidlc-docs/prompts/mob-elaboration.md",
         "Breaking intent into stories, units, and bolts"),
        ("Mob Construction", "aidlc-docs/prompts/mob-construction.md",
         "Building code bolt by bolt"),
    ]
    if mode == "brownfield":
        rituals.insert(0, ("Code Elevation", "aidlc-docs/prompts/code-elevation.md",
                           "Analyzing existing codebase before elaboration"))

    rows = "\n".join(f"| {r[0]} | `{r[1]}` | {r[2]} |" for r in rituals)

    egs_line = ""
    overrides_line = ""
    if tier == "enterprise":
        egs_line = '\n- **EGS**: `aidlc-docs/egs_definition.md` — enterprise guardrails and standards'
        overrides_line = '\n- **Overrides**: `aidlc-docs/overrides/guardrails_overrides.md` — guardrail customizations'

    return f"""# AI-DLC Project Router

This is an AI-DLC **{mode}** project. All methodology artifacts are in `aidlc-docs/`.

## Session Start

When the user's first message is a greeting or a general question about the project, respond with the welcome below and list the available rituals. If the first message is a specific request (e.g., "start Mob Elaboration"), skip the welcome and proceed directly. Only display this welcome ONCE per conversation. If the user asks about project status or where they left off, check `aidlc-docs/aidlc-state.md`.

{welcome}

## Available Rituals

When the user requests a ritual, read the corresponding prompt file and follow its instructions completely.

| Ritual | Prompt File | Purpose |
|--------|------------|---------|
{rows}

## Completion & Diagnostics

Use when the user requests a check, review, or wrap-up action.

| Action | Prompt File | When to Use |
|--------|------------|-------------|
| Consistency Check | `aidlc-docs/completion/consistency-check-prompt.md` | Between bolts or before milestones |
| Intent Consolidation | `aidlc-docs/completion/intent-consolidation-prompt.md` | After all bolts for the current intent are complete |
| Bolt Completion Criteria | `aidlc-docs/completion/bolt-completion-criteria.md` | Validate a bolt meets "done" before closing it |
| Session Retrospective | `aidlc-docs/retrospectives/session-retrospective.md` | End of session |

## Key Project Files

- **State**: `aidlc-docs/aidlc-state.md` — current phase/stage progress
- **Intent**: `aidlc-docs/intents/intent-primary.md` — what we're building{egs_line}
- **Decisions**: `aidlc-docs/decisions/decision-log.md` — architectural decisions
- **Intent Summaries**: `aidlc-docs/intent-summaries/` — context from previous intents{overrides_line}
- **Audit Log**: `aidlc-docs/audit/audit-log.md` — session activity log
- **Standards**: `aidlc-docs/standards/` — content validation, error handling, and question format rules

## Rules

- Do NOT start any ritual without the user explicitly requesting it.
- Always read the full prompt file before beginning a ritual.
- Follow the pre-flight checks defined in each prompt.
- Ask for user confirmation at phase/stage boundaries.
- For completion actions, read the prompt file and follow its instructions. Do not modify project artifacts unless the prompt explicitly says to.
"""


_RITUAL_PROGRESS_GREENFIELD = """\
### Mob Elaboration
- [ ] Phase 1 — Intent Clarification
- [ ] Phase 2 — Story Generation
- [ ] Phase 3 — Unit Division
- [ ] Phase 4 — Risk & NFR Analysis
- [ ] Phase 5 — Bolt Planning

### Mob Construction
<!-- Update per bolt as construction progresses -->"""

_RITUAL_PROGRESS_GREENFIELD_ENT = """\
### Mob Elaboration
- [ ] Phase 1 — Intent Clarification
- [ ] Phase 2 — Story Generation
- [ ] Phase 3 — Unit Division
- [ ] Phase 4 — Risk, NFR & Guardrails Analysis
- [ ] Phase 5 — Bolt Planning

### Mob Construction
<!-- Update per bolt as construction progresses -->"""

_RITUAL_PROGRESS_BROWNFIELD = """\
### Code Elevation
- [ ] Stage 1 — Static Analysis
- [ ] Stage 2 — Dynamic Analysis
- [ ] Stage 3 — Technical Debt Inventory

### Mob Elaboration
- [ ] Phase 1 — Intent Clarification
- [ ] Phase 2 — Impact & Compatibility Analysis
- [ ] Phase 3 — Story Generation
- [ ] Phase 4 — Unit Division
- [ ] Phase 5 — Risk & NFR Analysis
- [ ] Phase 6 — Bolt Planning

### Mob Construction
<!-- Update per bolt as construction progresses -->"""

_RITUAL_PROGRESS_BROWNFIELD_ENT = """\
### Code Elevation
- [ ] Stage 1 — Static Analysis
- [ ] Stage 2 — Dynamic Analysis
- [ ] Stage 3 — Technical Debt & Guardrails Gap Analysis

### Mob Elaboration
- [ ] Phase 1 — Intent Clarification
- [ ] Phase 2 — Impact & Compatibility Analysis
- [ ] Phase 3 — Story Generation
- [ ] Phase 4 — Unit Division
- [ ] Phase 5 — Risk, NFR & Guardrails Analysis
- [ ] Phase 6 — Bolt Planning

### Mob Construction
<!-- Update per bolt as construction progresses -->"""


def _render_state(path: Path, mode: str, tier: str = "enterprise") -> None:
    """Replace {{RITUAL_PROGRESS}} in the state file with mode-specific phases."""
    if tier == "enterprise":
        progress = _RITUAL_PROGRESS_BROWNFIELD_ENT if mode == "brownfield" else _RITUAL_PROGRESS_GREENFIELD_ENT
    else:
        progress = _RITUAL_PROGRESS_BROWNFIELD if mode == "brownfield" else _RITUAL_PROGRESS_GREENFIELD
    text = path.read_text(encoding="utf-8")
    path.write_text(text.replace("{{RITUAL_PROGRESS}}", progress), encoding="utf-8")


def _generate_ide_config(project_root: Path, mode: str, ide: str, overwrite: bool = False, tier: str = "enterprise") -> None:
    """Generate an IDE-specific router file pointing to aidlc-docs prompts."""
    dir_rel, filename, fmt = IDE_CONFIGS[ide]
    target_dir = project_root / dir_rel if dir_rel else project_root
    target_file = target_dir / filename

    if target_file.exists() and not overwrite:
        click.echo(f"⚠ {target_file.relative_to(project_root)} already exists, skipping.")
        return

    body = _build_router_body(mode, tier)

    if fmt == "cursor":
        content = ('---\n'
                   'description: "AI-DLC project router — methodology rituals and artifact locations"\n'
                   'alwaysApply: true\n'
                   '---\n\n') + body
    elif fmt == "kiro":
        content = ('---\n'
                   'inclusion: always\n'
                   '---\n\n') + body
    elif fmt == "frontmatter":
        content = ('---\n'
                   'description: "AI-DLC project router — methodology rituals and artifact locations"\n'
                   '---\n\n') + body
    else:
        content = body

    target_dir.mkdir(parents=True, exist_ok=True)
    target_file.write_text(content, encoding="utf-8")
    click.echo(f"✓ IDE config written to {target_file.relative_to(project_root)}")


def update_project(target: str, yes: bool = False, platform: str | None = None, ides: list[str] | None = None, tier: str | None = None) -> None:
    """Update kit-owned templates in an existing aidlc-docs/ project."""
    docs_path = Path(target).resolve() / "aidlc-docs"

    if not docs_path.is_dir():
        raise click.ClickException(f"No aidlc-docs/ found at {docs_path}. Run 'init' first.")

    mode = _detect_mode(docs_path)
    detected_tier = _detect_tier(docs_path)
    t = tier or detected_tier or "standard"
    upgrading_tier = detected_tier == "standard" and t == "enterprise"
    detected_platform = _detect_platform(docs_path)
    plat = platform or detected_platform
    if not plat:
        raise click.ClickException(
            "Cannot detect platform from README.md. "
            "Pass --platform explicitly (aws|azure|gcp|onprem|agnostic)."
        )
    if plat not in PLATFORMS:
        raise click.ClickException(f"Unknown platform '{plat}'. Choose from: {', '.join(PLATFORMS)}")

    exclude = {"egs_variants", "egs_definition.md", "welcome.md"}
    changed = []

    for src_dir in (TEMPLATES / "base", TEMPLATES / mode):
        changed += _find_changed(src_dir, docs_path, exclude=exclude)

    # State file: copy if missing (new template for old projects), never overwrite
    changed = [(r, s, d) for r, s, d in changed if not r.endswith("aidlc-state.md") or not d.exists()]

    if not changed:
        click.echo("✓ All templates already up to date.")
    else:
        click.echo(f"Found {len(changed)} template(s) with changes ({mode} mode, {plat} platform):\n")

        updated = 0
        for rel, src, dest in changed:
            if yes or click.confirm(f"  Update {rel}?"):
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dest)
                click.echo(f"    ↻ {rel}")
                updated += 1
            else:
                click.echo(f"    ⏭ {rel} skipped")

        # Add Platform row to README if missing
        if not detected_platform:
            readme = docs_path / "README.md"
            content = readme.read_text(encoding="utf-8")
            content = re.sub(
                r"(\|\s*Mode\s*\|\s*\w+\s*\|)",
                rf"\1\n| Platform | {plat} |",
                content,
            )
            readme.write_text(content, encoding="utf-8")
            click.echo(f"    + Added Platform row ({plat}) to README.md")

        click.echo(f"\n✓ Updated {updated}/{len(changed)} template(s) in {docs_path}.")

    # --- Tier upgrade: standard → enterprise ---
    if upgrading_tier:
        click.echo("\n⬆ Upgrading tier: standard → enterprise")
        added = 0
        for src_dir in (TEMPLATES / "base", TEMPLATES / mode):
            for ent_name in _ENTERPRISE_ONLY:
                for src_file in src_dir.rglob(ent_name):
                    if src_file.is_dir():
                        continue
                    rel = src_file.relative_to(src_dir)
                    dest = docs_path / rel
                    if not dest.exists():
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(src_file, dest)
                        click.echo(f"    + {rel}")
                        added += 1
        # Update README tier
        readme = docs_path / "README.md"
        content = readme.read_text(encoding="utf-8")
        content = re.sub(r"(\|\s*Tier\s*\|\s*)\w+(\s*\|)", r"\1enterprise\2", content)
        readme.write_text(content, encoding="utf-8")
        # Update state file
        _render_state(docs_path / "aidlc-state.md", mode, "enterprise")
        click.echo(f"    ↻ README.md tier → enterprise")
        click.echo(f"    ↻ aidlc-state.md → enterprise")
        click.echo(f"✓ Tier upgrade complete — {added} enterprise file(s) added.")
        click.echo("  ℹ Customize egs_definition.md with your project's guardrails.")
        click.echo("  ℹ Run 'aidlc-kit update' again to refresh templates with enterprise content.")

    if ides:
        project_root = docs_path.parent
        for ide in ides:
            _generate_ide_config(project_root, mode, ide, overwrite=True, tier=t)


def _detect_mode(docs_path: Path) -> str:
    """Read the project mode from the rendered README metadata table."""
    readme = docs_path / "README.md"
    if not readme.exists():
        raise click.ClickException("README.md missing — cannot detect project mode.")

    match = re.search(r"\|\s*Mode\s*\|\s*(\w+)\s*\|", readme.read_text(encoding="utf-8"))
    if not match:
        raise click.ClickException("Cannot detect mode from README.md. Re-run 'init'.")
    return match.group(1).lower()


def _detect_platform(docs_path: Path) -> str | None:
    """Read the project platform from the rendered README metadata table."""
    readme = docs_path / "README.md"
    if not readme.exists():
        return None
    match = re.search(r"\|\s*Platform\s*\|\s*(\w+)\s*\|", readme.read_text(encoding="utf-8"))
    return match.group(1).lower() if match else None


def _detect_tier(docs_path: Path) -> str | None:
    """Read the project tier from the rendered README metadata table."""
    readme = docs_path / "README.md"
    if not readme.exists():
        return None
    match = re.search(r"\|\s*Tier\s*\|\s*(\w+)\s*\|", readme.read_text(encoding="utf-8"))
    return match.group(1).lower() if match else None


def _find_changed(src: Path, dst: Path, exclude: set[str] | None = None) -> list[tuple[str, Path, Path]]:
    """Find kit-owned files that differ from the installed version.

    Returns list of (relative_path, src_path, dest_path) for changed files.
    """
    changed = []
    for item in src.iterdir():
        if item.name in USER_OWNED:
            continue
        if exclude and item.name in exclude:
            continue
        dest_item = dst / item.name
        if item.is_dir():
            dest_item.mkdir(parents=True, exist_ok=True)
            changed += _find_changed(item, dest_item)
        elif item.name == ".gitkeep":
            if not dest_item.exists():
                changed.append((str(dest_item.relative_to(dst)), item, dest_item))
        else:
            src_content = item.read_bytes()
            if not dest_item.exists() or dest_item.read_bytes() != src_content:
                changed.append((str(dest_item.relative_to(dst)), item, dest_item))
    return changed


def archive_project(target: str, name: str | None = None, yes: bool = False) -> None:
    """Archive completed intent artifacts and reset workspace for next intent."""
    docs_path = Path(target).resolve() / "aidlc-docs"

    if not docs_path.is_dir():
        raise click.ClickException(f"No aidlc-docs/ found at {docs_path}. Run 'init' first.")

    mode = _detect_mode(docs_path)
    archive_name = name or _derive_intent_name(docs_path)
    archive_dir = docs_path / "archive" / f"{archive_name}-{date.today().isoformat()}"

    if archive_dir.exists():
        raise click.ClickException(f"Archive already exists: {archive_dir}")

    # Collect what will be moved
    to_move = [d for d in ARCHIVABLE if (docs_path / d).exists()
               and any((docs_path / d).iterdir())]

    if not to_move:
        raise click.ClickException("Nothing to archive — workspace appears empty.")

    # Warn if no intent summary exists
    summaries_dir = docs_path / "intent-summaries"
    has_summary = summaries_dir.is_dir() and any(summaries_dir.glob("*.md"))
    if not has_summary:
        click.echo("⚠ No intent summary found in intent-summaries/.")
        click.echo("  Without a summary, future intents will have no context about")
        click.echo("  what was built, decisions made, or patterns established.")
        click.echo("  To create one, run the consolidation prompt in your AI session")
        click.echo("  (see aidlc-docs/completion/intent-consolidation-prompt.md).\n")
        if not yes:
            click.confirm("  Archive without consolidation?", abort=True)

    click.echo(f"Will archive to: {archive_dir.relative_to(docs_path)}")
    for d in sorted(to_move):
        click.echo(f"  → {d}/")

    if not yes:
        click.confirm("\nArchive these and reset workspace?", abort=True)

    archive_dir.mkdir(parents=True)
    for d in to_move:
        shutil.move(str(docs_path / d), str(archive_dir / d))

    # Reset: restore blank templates from kit
    for src_dir in (TEMPLATES / "base", TEMPLATES / mode):
        for d in to_move:
            src_item = src_dir / d
            if src_item.is_dir():
                _copy_tree(src_item, docs_path / d)

    click.echo(f"\n✓ Archived to {archive_dir.relative_to(docs_path)}")

    # Update state file: append to Archive History, reset current fields
    state_file = docs_path / "aidlc-state.md"
    if state_file.exists():
        st = state_file.read_text(encoding="utf-8")
        # Insert into Archive History table
        ah_marker = "## Archive History"
        if ah_marker in st:
            ah_section = st[st.index(ah_marker):]
            archive_count = len(re.findall(r"^\|\s*\d+\s*\|", ah_section, re.MULTILINE))
            row = f"| {archive_count + 1} | {archive_name} | {date.today().isoformat()} |"
            ah_start = st.index(ah_marker)
            # Find the placeholder or last numbered row within Archive History
            ah_section = st[ah_start:]
            if "| — | — | — |" in ah_section:
                st = st[:ah_start] + ah_section.replace("| — | — | — |", row, 1)
            else:
                lines = st.splitlines()
                ah_line = next(i for i, l in enumerate(lines) if ah_marker in l)
                last_row_idx = None
                for i in range(ah_line, len(lines)):
                    if re.match(r"\|\s*\d+\s*\|", lines[i]):
                        last_row_idx = i
                if last_row_idx is not None:
                    lines.insert(last_row_idx + 1, row)
                    st = "\n".join(lines) + "\n"
        # Reset current position fields
        for field in ("Current Ritual", "Current Position", "Next Step"):
            st = re.sub(
                rf"(\|\s*{field}\s*\|)[^|]+\|",
                rf"\1 [pending next intent] |",
                st,
            )
        st = re.sub(
            r"(\|\s*Last Updated\s*\|)[^|]+\|",
            rf"\1 {date.today().isoformat()} |",
            st,
        )
        state_file.write_text(st, encoding="utf-8")

    click.echo("  Workspace reset — ready for next intent.")


def _derive_intent_name(docs_path: Path) -> str:
    """Extract intent name from the primary intent file heading."""
    intent_file = docs_path / "intents" / "intent-primary.md"
    if intent_file.exists():
        first_line = intent_file.read_text(encoding="utf-8").split("\n", 1)[0]
        match = re.match(r"#\s*Intent:\s*(.+)", first_line)
        if match:
            raw = match.group(1).strip()
            if raw and raw != "[Name]":
                return re.sub(r"[^\w\-]+", "-", raw.lower()).strip("-")
    return "unnamed-intent"


def _show_phase_progress(plan: Path, label: str, unit_word: str) -> None:
    """Display numbered-row progress for a plan file."""
    if not plan.exists():
        click.echo(f"  {label:<22} missing")
        return
    rows = [l for l in plan.read_text(encoding="utf-8").splitlines()
            if re.match(r"\|\s*\d+\s*\|", l)]
    total = len(rows)
    done = sum(1 for r in rows if "✅" in r)
    skipped = sum(1 for r in rows if "⏭️" in r)
    active = sum(1 for r in rows if "🔄" in r)
    completed = done + skipped
    if active:
        active_row = next((r for r in rows if "🔄" in r), "")
        cols = [c.strip() for c in active_row.split("|") if c.strip()]
        current = cols[1] if len(cols) > 1 else ""
        click.echo(f"  {label:<22} {completed}/{total} {unit_word}s  🔄 {current}")
    elif completed == total and total > 0:
        click.echo(f"  {label:<22} {completed}/{total} {unit_word}s  ✅ complete")
    elif completed:
        click.echo(f"  {label:<22} {completed}/{total} {unit_word}s")
    else:
        click.echo(f"  {label:<22} {total} {unit_word}s  ⬜ not started")


def _show_bolt_detail(plan: Path) -> None:
    """Show current bolt's stage progress as an indented sub-line."""
    if not plan.exists():
        return
    rows = [l for l in plan.read_text(encoding="utf-8").splitlines()
            if re.match(r"\|\s*\d+\s*\|", l)]
    if not rows:
        return
    done = sum(1 for r in rows if "✅" in r)
    skipped = sum(1 for r in rows if "⏭️" in r)
    active = sum(1 for r in rows if "🔄" in r)
    completed = done + skipped
    total = len(rows)
    if active:
        active_row = next((r for r in rows if "🔄" in r), "")
        cols = [c.strip() for c in active_row.split("|") if c.strip()]
        current = cols[1] if len(cols) > 1 else ""
        click.echo(f"    └ Current bolt       {completed}/{total} stages  🔄 {current}")
    elif completed == total and total > 0:
        click.echo(f"    └ Current bolt       {completed}/{total} stages  ✅ complete")
    elif completed:
        click.echo(f"    └ Current bolt       {completed}/{total} stages")


def status_project(target: str, as_json: bool = False) -> None:
    """Show current project status dashboard."""
    docs = Path(target).resolve() / "aidlc-docs"
    if not docs.is_dir():
        raise click.ClickException(f"No aidlc-docs/ found at {docs}. Run 'init' first.")

    data = _status_data(docs)

    if as_json:
        click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        return

    click.echo(f"Project:  {data['project']}")
    click.echo(f"Mode:     {data['mode']}")
    click.echo(f"Platform: {data['platform'] or 'not set ⚠️'}")
    click.echo(f"Intent:   {data['intent']['name'].replace('-', ' ').title()}  "
               f"({'defined ✅' if data['intent']['defined'] else 'not defined ⬜'})")
    click.echo(f"EGS:      {'customized ✅' if data['egs_customized'] else 'not customized ⬜'}")

    if data.get("state") and not data["workspace_idle"]:
        s = data["state"]
        if s.get("ritual"):
            click.echo(f"Ritual:   {s['ritual']}")
        if s.get("position"):
            click.echo(f"Position: {s['position']}")
        if s.get("next_step"):
            click.echo(f"Next:     {s['next_step']}")

    if data["workspace_idle"]:
        click.echo("\nRitual Progress:  idle (workspace reset after archive)")
    else:
        click.echo("\nRitual Progress:")

    if not data["workspace_idle"]:
        for rp in data.get("ritual_progress", []):
            click.echo(f"  {rp}")

    click.echo(f"\nDecisions:  {data['decisions']} {'entry' if data['decisions'] == 1 else 'entries'}")

    a = data.get("audit", {})
    if a.get("found"):
        if a.get("last_entry"):
            click.echo(f"Last audit: {a['last_entry']}")
        click.echo(f"Audit log:  {a['count']} entries")
    elif a.get("found") is False:
        click.echo("Audit log:  not found ⚠️")
    else:
        click.echo("Audit log:  no entries yet")

    arc = data.get("archives", [])
    if arc:
        click.echo(f"Archives:   {len(arc)} ({', '.join(arc)})")
    else:
        click.echo("Archives:   none")

    if data["workspace_idle"]:
        click.echo(f"\n✅ All {len(arc)} intent(s) archived — workspace ready for next intent or project complete.")


def _status_data(docs: Path) -> dict:
    """Collect status data into a dict."""
    mode = _detect_mode(docs)
    platform = _detect_platform(docs)

    readme = docs / "README.md"
    name_match = re.search(r"^\#\s*(.+?)\s*—", readme.read_text(encoding="utf-8"))
    project_name = name_match.group(1) if name_match else docs.parent.name

    intent_name = _derive_intent_name(docs)
    intent_defined = intent_name != "unnamed-intent"

    egs = docs / "egs_definition.md"
    egs_ok = egs.exists() and "Generic Template" not in egs.read_text(encoding="utf-8")

    state_info: dict = {}
    state_file = docs / "aidlc-state.md"
    if state_file.exists():
        st = state_file.read_text(encoding="utf-8")
        def _sf(field: str) -> str:
            m = re.search(rf"\|\s*{field}\s*\|\s*(.+?)\s*\|", st)
            val = m.group(1).strip() if m else ""
            return "" if val.startswith("[") else val
        state_info = {"ritual": _sf("Current Ritual"), "position": _sf("Current Position"),
                      "next_step": _sf("Next Step")}

    archive = docs / "archive"
    archived = sorted(p.name for p in archive.iterdir() if p.is_dir()) if archive.is_dir() else []
    workspace_idle = bool(archived and not intent_defined)

    # Ritual progress lines (reuse existing display helpers)
    progress_lines: list[str] = []
    if not workspace_idle:
        import io
        _orig_echo = click.echo
        buf: list[str] = []
        click.echo = lambda msg="", **kw: buf.append(str(msg))  # type: ignore[assignment]
        try:
            elab_plan = docs / "mob-elaboration" / "mob_elaboration_plan.md"
            elev_plan = docs / "code-elevation" / "code_elevation_plan.md"
            if mode == "brownfield":
                _show_phase_progress(elev_plan, "Code Elevation", "stage")
            _show_phase_progress(elab_plan, "Mob Elaboration", "phase")
            if elab_plan.exists():
                text = elab_plan.read_text(encoding="utf-8")
                in_bolt_table = False
                bolt_rows_local: list[tuple[str, str]] = []
                for line in text.splitlines():
                    if re.match(r"\|\s*Bolt\s*\|", line):
                        in_bolt_table = True
                        continue
                    if in_bolt_table:
                        if not line.startswith("|"):
                            break
                        if "---" in line:
                            continue
                        cols = [c.strip() for c in line.split("|") if c.strip()]
                        if cols:
                            bolt_rows_local.append((cols[0], line))
                if bolt_rows_local:
                    total_b = len(bolt_rows_local)
                    done_b = sum(1 for _, r in bolt_rows_local if "✅" in r)
                    skipped_b = sum(1 for _, r in bolt_rows_local if "⏭️" in r)
                    active_b = sum(1 for _, r in bolt_rows_local if "🔄" in r)
                    completed_b = done_b + skipped_b
                    if active_b:
                        name = next((n for n, r in bolt_rows_local if "🔄" in r), "")
                        buf.append(f"  {'Mob Construction':<22} {completed_b}/{total_b} bolts  🔄 {name}")
                        bolt_num = re.search(r"\d+", name)
                        if bolt_num:
                            active_plan = docs / "mob-construction" / f"bolt-{bolt_num.group()}" / "mob_construction_plan.md"
                            _show_bolt_detail(active_plan)
                    elif completed_b == total_b and total_b > 0:
                        buf.append(f"  {'Mob Construction':<22} {completed_b}/{total_b} bolts  ✅ complete")
                    elif completed_b:
                        buf.append(f"  {'Mob Construction':<22} {completed_b}/{total_b} bolts")
                        bolt_dirs = sorted((docs / "mob-construction").glob("bolt-*/mob_construction_plan.md"))
                        if bolt_dirs:
                            _show_bolt_detail(bolt_dirs[-1])
                    else:
                        buf.append(f"  {'Mob Construction':<22} {total_b} bolts  ⬜ not started")
                else:
                    bolt_dirs = sorted((docs / "mob-construction").glob("bolt-*/mob_construction_plan.md"))
                    if bolt_dirs:
                        _show_phase_progress(bolt_dirs[-1], "Mob Construction", "stage")
                    else:
                        buf.append(f"  {'Mob Construction':<22} not started")
        finally:
            click.echo = _orig_echo  # type: ignore[assignment]
        progress_lines = buf

    # Decisions
    dlog = docs / "decisions" / "decision-log.md"
    dec_count = 0
    if dlog.exists():
        text = dlog.read_text(encoding="utf-8")
        for block in re.findall(r"### Decision \d+.*?(?=### Decision|\Z)", text, re.DOTALL):
            m = re.search(r"\*\*Decision\*\*\s*\|\s*(.+)", block)
            if m:
                val = m.group(1).strip().strip("|").strip()
                if val and val not in ("[What was decided]",):
                    dec_count += 1

    # Audit
    audit_info: dict = {"found": False}
    audit_log = docs / "audit" / "audit-log.md"
    if audit_log.exists():
        text = audit_log.read_text(encoding="utf-8")
        entries = list(re.finditer(r"^### \[(.+?)\] — (.+)", text, re.MULTILINE))
        audit_info = {"found": True, "count": len(entries)}
        if entries:
            last = entries[-1]
            audit_info["last_entry"] = f"{last.group(1)} — {last.group(2)}"

    return {
        "project": project_name, "mode": mode, "platform": platform,
        "intent": {"name": intent_name, "defined": intent_defined},
        "egs_customized": egs_ok, "state": state_info,
        "workspace_idle": workspace_idle, "ritual_progress": progress_lines,
        "decisions": dec_count, "audit": audit_info, "archives": archived,
    }


def _parse_bolt_rows(plan: Path) -> list[dict]:
    """Parse bolt plan table into list of dicts with keys: num, unit, stories, deps, raw."""
    if not plan.exists():
        return []
    rows = []
    for line in plan.read_text(encoding="utf-8").splitlines():
        # Match "| 1 |" or "| **BE-1** |" style rows
        if not (re.match(r"\|\s*\d+\s*\|", line) or re.match(r"\|\s*\*{0,2}[A-Z]+-\d+\*{0,2}\s*\|", line)):
            continue
        cols = [c.strip().strip("*") for c in line.split("|") if c.strip()]
        rows.append({
            "num": cols[0] if len(cols) > 0 else "",
            "unit": cols[1] if len(cols) > 1 else "",
            "stories": cols[2] if len(cols) > 2 else "",
            "deps": cols[3] if len(cols) > 3 else (cols[-1] if cols else ""),
            "raw": line,
        })
    return rows


def consistency_check(target: str, as_json: bool = False) -> None:
    """Run structural consistency checks across project artifacts."""
    docs = Path(target).resolve() / "aidlc-docs"
    if not docs.is_dir():
        raise click.ClickException(f"No aidlc-docs/ found at {docs}. Run 'init' first.")

    mode = _detect_mode(docs)

    # Idle workspace — all intents archived, nothing to check
    archive = docs / "archive"
    has_archives = archive.is_dir() and any(p.is_dir() for p in archive.iterdir())
    intent = docs / "intents" / "intent-primary.md"
    intent_blank = intent.exists() and (
        "# Intent: [Name]" in intent.read_text(encoding="utf-8")
        or "Replace this template" in intent.read_text(encoding="utf-8")
    )
    if has_archives and intent_blank:
        archived = sorted(p.name for p in archive.iterdir() if p.is_dir())
        data = {"project": str(docs), "workspace_idle": True,
                "archives": len(archived), "dimensions": []}
        if as_json:
            click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        else:
            click.echo(f"Consistency Check — {docs}\n")
            click.echo(f"  Workspace idle — {len(archived)} intent(s) archived. Nothing to check.")
        return

    data = _consistency_data(docs, mode)

    if as_json:
        click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        if any(d["status"] == "red" for d in data["dimensions"]):
            raise SystemExit(1)
        return

    click.echo(f"Consistency Check — {docs}\n")
    for d in data["dimensions"]:
        emoji = {"red": "🔴", "yellow": "🟡", "green": "🟢"}[d["status"]]
        click.echo(f"  {d['name']:<30} {emoji} {d['detail']}")

    reds = sum(1 for d in data["dimensions"] if d["status"] == "red")
    yellows = sum(1 for d in data["dimensions"] if d["status"] == "yellow")
    click.echo()
    if reds or yellows:
        click.echo(f"  {reds} conflict(s), {yellows} drift(s)")
    else:
        click.echo("  All structural checks passed.")
    click.echo("\n  For semantic checks (code↔stories, decisions↔design, EGS↔implementation),")
    click.echo("  run the consistency check prompt in your AI session.")

    if reds:
        raise SystemExit(1)


def _consistency_data(docs: Path, mode: str) -> dict:
    """Collect consistency check data into a dict."""
    results: list[dict] = []

    elab_plan = docs / "mob-elaboration" / "mob_elaboration_plan.md"
    # Bolt plan may be in elaboration output (bolt_plan.md) or per-bolt construction folders
    bolt_plan = docs / "mob-elaboration" / "bolt_plan.md"
    bolt_rows = _parse_bolt_rows(bolt_plan)
    if not bolt_rows:
        # Try per-bolt construction plans
        for bp in sorted((docs / "mob-construction").glob("bolt-*/mob_construction_plan.md")):
            bolt_rows.extend(_parse_bolt_rows(bp))
    elab_rows = _parse_bolt_rows(elab_plan)

    # 1. Stories → Bolt Coverage
    if bolt_rows:
        empty = [r for r in bolt_rows if not r["stories"].strip() or r["stories"].strip() == "-"]
        if empty:
            results.append({"name": "Stories → Bolt Coverage", "status": "red",
                            "detail": f"bolt(s) {', '.join(r['num'] for r in empty)} missing Stories"})
        else:
            results.append({"name": "Stories → Bolt Coverage", "status": "green", "detail": f"{len(bolt_rows)}/{len(bolt_rows)} bolts have stories"})
    elif elab_rows:
        results.append({"name": "Stories → Bolt Coverage", "status": "yellow", "detail": "Elaboration plan exists but no construction bolt plan yet"})
    else:
        results.append({"name": "Stories → Bolt Coverage", "status": "yellow", "detail": "No plans found"})

    # 2. Bolt Dependencies → Status
    dep_issues = []
    for r in bolt_rows:
        deps_text = r["deps"].strip().lower()
        if not deps_text or deps_text in ("none", "-", "none (independent)"):
            continue
        # Extract bolt IDs: "BE-1", "FE-2", "bolt 1", "bolt-1"
        dep_ids = re.findall(r"[a-z]+-\d+|bolt[- ]?\d+", deps_text, re.IGNORECASE)
        for did in dep_ids:
            dep_row = next((b for b in bolt_rows if b["num"].strip().lower() == did), None)
            if dep_row and "✅" not in dep_row["raw"]:
                dep_issues.append(f"{r['num']} depends on {did} (not ✅)")
    if bolt_rows:
        if dep_issues:
            results.append({"name": "Bolt Dependencies → Status", "status": "yellow", "detail": "; ".join(dep_issues)})
        else:
            results.append({"name": "Bolt Dependencies → Status", "status": "green", "detail": "All dependencies satisfied"})
    else:
        results.append({"name": "Bolt Dependencies → Status", "status": "yellow", "detail": "No bolt plan"})

    # 3. Decision Log
    dlog = docs / "decisions" / "decision-log.md"
    if dlog.exists():
        entries = re.findall(r"^###\s+", dlog.read_text(encoding="utf-8"), re.MULTILINE)
        if entries:
            results.append({"name": "Decision Log", "status": "green", "detail": f"{len(entries)} entries"})
        else:
            results.append({"name": "Decision Log", "status": "yellow", "detail": "File exists but no entries (### headings) found"})
    else:
        results.append({"name": "Decision Log", "status": "red", "detail": "Missing: decisions/decision-log.md"})

    # 4. EGS Structure
    egs = docs / "egs_definition.md"
    if egs.exists():
        text = egs.read_text(encoding="utf-8")
        expected = [
            "Security Baseline", "Compliance Constraints", "Architectural Guardrails",
            "Coding Standards", "Operational Readiness", "Cost Guardrails",
            "AI/GenAI Guardrails", "Reliability Guardrails",
            "Performance Efficiency Guardrails", "Sustainability Guardrails",
        ]
        missing = [c for c in expected if c not in text]
        if missing:
            results.append({"name": "EGS Structure", "status": "red", "detail": f"Missing {len(missing)} categories: {', '.join(missing)}"})
        else:
            results.append({"name": "EGS Structure", "status": "green", "detail": "10/10 categories present"})
    else:
        results.append({"name": "EGS Structure", "status": "red", "detail": "Missing: egs_definition.md"})

    # 5. Retro Action Items
    retro_dir = docs / "retrospectives"
    open_items = 0
    retro_count = 0
    if retro_dir.is_dir():
        for rf in sorted(retro_dir.glob("retro_*.md")):
            retro_count += 1
            text = rf.read_text(encoding="utf-8")
            # Count unchecked items in "What to Change" or "Action Items" sections
            open_items += len(re.findall(r"^- \[ \]", text, re.MULTILINE))
    if retro_count:
        if open_items:
            results.append({"name": "Retro Action Items", "status": "yellow", "detail": f"{open_items} unresolved across {retro_count} retro(s)"})
        else:
            results.append({"name": "Retro Action Items", "status": "green", "detail": f"{retro_count} retro(s), no open items"})
    else:
        results.append({"name": "Retro Action Items", "status": "green", "detail": "No retros yet (expected early in project)"})

    # 6. Unit → Bolt Mapping
    unit_defs = docs / "mob-elaboration" / "unit_definitions.md"
    if unit_defs.exists() and bolt_rows:
        # Extract unit names from headings like "## Unit 1: Core API" or "## Core API"
        unit_names = set()
        for m in re.finditer(r"^##\s+(?:Unit\s*\d*:\s*)?(.+)", unit_defs.read_text(encoding="utf-8"), re.MULTILINE):
            unit_names.add(m.group(1).strip().lower())
        bolt_units = {r["unit"].strip().lower() for r in bolt_rows if r["unit"].strip()}
        unmapped = unit_names - bolt_units
        if unmapped and unit_names:
            results.append({"name": "Unit → Bolt Mapping", "status": "yellow",
                            "detail": f"Units not in bolt plan: {', '.join(sorted(unmapped))}"})
        elif unit_names:
            results.append({"name": "Unit → Bolt Mapping", "status": "green", "detail": f"{len(unit_names)} unit(s) covered"})
        else:
            results.append({"name": "Unit → Bolt Mapping", "status": "yellow", "detail": "No unit headings found in unit_definitions.md"})
    elif bolt_rows:
        results.append({"name": "Unit → Bolt Mapping", "status": "yellow", "detail": "No unit_definitions.md to cross-reference"})
    else:
        results.append({"name": "Unit → Bolt Mapping", "status": "yellow", "detail": "No elaboration artifacts"})

    # 7. Bolt Plan Completeness
    if bolt_rows:
        incomplete = [r for r in bolt_rows
                      if not r["unit"].strip() or not r["stories"].strip()
                      or r["unit"].strip() == "-" or r["stories"].strip() == "-"]
        if incomplete:
            results.append({"name": "Bolt Plan Completeness", "status": "red",
                            "detail": f"bolt(s) {', '.join(r['num'] for r in incomplete)} missing Unit or Stories"})
        else:
            results.append({"name": "Bolt Plan Completeness", "status": "green", "detail": f"{len(bolt_rows)} bolts fully defined"})
    else:
        results.append({"name": "Bolt Plan Completeness", "status": "yellow", "detail": "No bolt plan"})

    # 8. Audit Log
    audit_log = docs / "audit" / "audit-log.md"
    if audit_log.exists():
        text = audit_log.read_text(encoding="utf-8")
        entries = re.findall(r"^### \[", text, re.MULTILINE)
        if entries:
            results.append({"name": "Audit Log", "status": "green", "detail": f"{len(entries)} entries"})
        else:
            results.append({"name": "Audit Log", "status": "yellow", "detail": "File exists but no entries (### [ headings) found"})
    else:
        results.append({"name": "Audit Log", "status": "red", "detail": "Missing: audit/audit-log.md"})

    return {"project": str(docs), "workspace_idle": False, "dimensions": results}


def check_project(target: str, as_json: bool = False) -> None:
    """Run health checks on an existing aidlc-docs/ project."""
    docs_path = Path(target).resolve() / "aidlc-docs"

    if not docs_path.is_dir():
        raise click.ClickException(f"No aidlc-docs/ found at {docs_path}. Run 'init' first.")

    data = _check_data(docs_path)

    if as_json:
        click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        if data["issues"]:
            raise SystemExit(1)
        return

    click.echo(f"Project: {docs_path} ({data['mode']} mode, {data['platform'] or 'no platform'} platform)\n")

    if data["issues"]:
        click.echo(f"⚠ {len(data['issues'])} issue(s):")
        for i in data["issues"]:
            click.echo(f"  ✗ [{i['severity'].title()}] {i['message']}")
    else:
        click.echo("✓ No issues found.")

    if data["info"]:
        click.echo()
        for i in data["info"]:
            click.echo(f"  ℹ {i}")

    if data["issues"]:
        raise SystemExit(1)


def _check_data(docs_path: Path) -> dict:
    """Collect check data into a dict."""
    mode = _detect_mode(docs_path)
    platform = _detect_platform(docs_path)
    issues: list[dict] = []
    info: list[str] = []

    # --- Platform metadata ---
    if not platform:
        issues.append({"severity": "medium", "message": "Platform not set in README.md (run 'aidlc-kit update --platform <platform>' to fix)"})

    # --- Required files ---
    required = {
        "egs_definition.md": "EGS (project constitution)",
        "intents/intent-primary.md": "Primary intent",
        "prompts/mob-elaboration.md": "Mob Elaboration prompt",
        "prompts/mob-construction.md": "Mob Construction prompt",
        "plan-templates/mob_elaboration_plan.md": "Elaboration plan template",
        "plan-templates/mob_construction_plan.md": "Construction plan template",
        "decisions/decision-log.md": "Decision log",
        "overrides/guardrails_overrides.md": "Guardrails overrides",
        "audit/audit-log.md": "Audit log",
        "standards/content-validation.md": "Content validation standards",
        "standards/error-handling.md": "Error handling procedures",
        "standards/question-format.md": "Question format standards",
    }
    if mode == "brownfield":
        required["prompts/code-elevation.md"] = "Code Elevation prompt"
        required["plan-templates/code_elevation_plan.md"] = "Code Elevation plan template"

    for rel, label in required.items():
        if not (docs_path / rel).exists():
            issues.append({"severity": "critical", "message": f"Missing: {rel} ({label})"})

    # --- Intent filled? ---
    archive = docs_path / "archive"
    has_archives = archive.is_dir() and any(p.is_dir() for p in archive.iterdir())
    intent = docs_path / "intents" / "intent-primary.md"
    if intent.exists():
        text = intent.read_text(encoding="utf-8")
        if "# Intent: [Name]" in text or "Replace this template" in text:
            if has_archives:
                info.append("Workspace idle — intent not defined (previous intents archived)")
            else:
                issues.append({"severity": "high", "message": "Intent not filled in: intents/intent-primary.md"})

    # --- EGS customized? ---
    egs = docs_path / "egs_definition.md"
    if egs.exists():
        text = egs.read_text(encoding="utf-8")
        if "Generic Template" in text:
            issues.append({"severity": "medium", "message":
                "EGS not customized: egs_definition.md still has the generic template title. "
                "Edit it with your project's org name, compliance scope, and thresholds, "
                "or the AI will review overrides during pre-flight."})
        # Structural check: verify all 10 guardrail categories are present
        expected = [
            "Security Baseline", "Compliance Constraints", "Architectural Guardrails",
            "Coding Standards", "Operational Readiness", "Cost Guardrails",
            "AI/GenAI Guardrails", "Reliability Guardrails",
            "Performance Efficiency Guardrails", "Sustainability Guardrails",
        ]
        missing = [c for c in expected if c not in text]
        if missing:
            issues.append({"severity": "high", "message":
                f"EGS missing {len(missing)} category heading(s): {', '.join(missing)}. "
                "These may have been added in a newer kit version."})

    # --- Plan progress ---
    for plan_rel, label in [
        ("mob-elaboration/mob_elaboration_plan.md", "Mob Elaboration"),
        ("code-elevation/code_elevation_plan.md", "Code Elevation"),
    ]:
        plan = docs_path / plan_rel
        if plan.exists():
            rows = [l for l in plan.read_text(encoding="utf-8").splitlines()
                    if re.match(r"\|\s*\d+\s*\|", l)]
            done = sum(1 for r in rows if "✅" in r or "⏭️" in r)
            progress = sum(1 for r in rows if "🔄" in r)
            if progress:
                info.append(f"{label}: in progress ({done} done, {progress} active)")
            elif done:
                info.append(f"{label}: {done} phase(s)/stage(s) completed")

    # Mob Construction — scan bolt folders for per-bolt plans
    cons_dir = docs_path / "mob-construction"
    if cons_dir.is_dir():
        bolt_plans = sorted(cons_dir.glob("bolt-*/mob_construction_plan.md"))
        if bolt_plans:
            total_bolts = len(bolt_plans)
            done_bolts = 0
            active_bolt = None
            for bp in bolt_plans:
                rows = [l for l in bp.read_text(encoding="utf-8").splitlines()
                        if re.match(r"\|\s*\d+\s*\|", l)]
                stages_done = sum(1 for r in rows if "✅" in r or "⏭️" in r)
                stages_active = sum(1 for r in rows if "🔄" in r)
                if rows and stages_done == len(rows):
                    done_bolts += 1
                elif stages_active and not active_bolt:
                    active_bolt = bp.parent.name
            if active_bolt:
                info.append(f"Mob Construction: {done_bolts}/{total_bolts} bolts complete, 🔄 {active_bolt}")
            elif done_bolts == total_bolts:
                info.append(f"Mob Construction: {done_bolts}/{total_bolts} bolts complete")
            elif done_bolts:
                info.append(f"Mob Construction: {done_bolts}/{total_bolts} bolts complete")

    # --- Cross-phase dependency checks ---
    elab_plan = docs_path / "mob-elaboration" / "mob_elaboration_plan.md"
    cons_has_bolts = cons_dir.is_dir() and any(
        f for bd in cons_dir.glob("bolt-*") if bd.is_dir()
        for f in bd.iterdir() if f.name != ".gitkeep"
    )
    elab_has_plan = elab_plan.exists() and elab_plan.stat().st_size > 100

    if cons_has_bolts and not elab_has_plan:
        issues.append({"severity": "critical", "message": "Construction bolts exist but no elaboration plan found — "
                      "run Mob Elaboration before continuing construction"})

    if mode == "brownfield":
        ce_dir = docs_path / "code-elevation"
        ce_has_output = ce_dir.is_dir() and any(ce_dir.glob("*.md"))
        elab_started = elab_has_plan
        if elab_started and not ce_has_output:
            issues.append({"severity": "critical", "message": "Brownfield elaboration started but no Code Elevation "
                          "artifacts found — run Code Elevation first"})
        # Validate individual Code Elevation artifacts when CE has started
        if ce_has_output:
            ce_expected = {
                "static_model.md": "Static Model (Stage 1)",
                "dynamic_model.md": "Dynamic Model (Stage 2)",
                "technical_debt.md": "Technical Debt Inventory (Stage 3)",
            }
            for fname, label in ce_expected.items():
                fpath = ce_dir / fname
                if not fpath.exists() or fpath.stat().st_size < 200:
                    issues.append({"severity": "warning", "message":
                                  f"Code Elevation {label} missing or empty — {fname}"})

    # --- State file consistency (skip when workspace idle — state reflects archived intent) ---
    workspace_idle = has_archives and intent.exists() and (
        "# Intent: [Name]" in intent.read_text(encoding="utf-8")
        or "Replace this template" in intent.read_text(encoding="utf-8")
    )
    state_file = docs_path / "aidlc-state.md"
    if state_file.exists() and not workspace_idle:
        st = state_file.read_text(encoding="utf-8")
        # Check if state says elaboration complete but no elaboration artifacts
        if "- [x]" in st and "Mob Elaboration" in st:
            elab_done_in_state = bool(re.search(
                r"- \[x\].*Phase 4.*Bolt Planning", st, re.IGNORECASE
            ))
            if elab_done_in_state and not elab_has_plan:
                issues.append({"severity": "high", "message": "State file says Mob Elaboration complete but no "
                              "elaboration plan found — state may be out of sync"})

    # --- Template drift ---
    exclude = {"egs_variants", "egs_definition.md", "aidlc-state.md", "welcome.md"}
    changed = []
    for src_dir in (TEMPLATES / "base", TEMPLATES / mode):
        changed += _find_changed(src_dir, docs_path, exclude=exclude)
    if changed:
        info.append(f"{len(changed)} template(s) differ from kit (run 'aidlc-kit update' to review)")

    # --- IDE router drift ---
    project_root = docs_path.parent
    for ide_key, (dir_rel, filename, fmt) in IDE_CONFIGS.items():
        router = (project_root / dir_rel / filename) if dir_rel else (project_root / filename)
        if router.exists():
            expected = _build_router_body(mode)
            if fmt == "cursor":
                expected = ('---\n'
                            'description: "AI-DLC project router — methodology rituals and artifact locations"\n'
                            'alwaysApply: true\n'
                            '---\n\n') + expected
            elif fmt == "frontmatter":
                expected = ('---\n'
                            'description: "AI-DLC project router — methodology rituals and artifact locations"\n'
                            '---\n\n') + expected
            if router.read_text(encoding="utf-8") != expected:
                info.append(f"IDE config outdated: {router.relative_to(project_root)} (run 'aidlc-kit update --ide {ide_key}' to refresh)")

    # --- Archive history ---
    archive = docs_path / "archive"
    if archive.is_dir():
        archived = [p for p in archive.iterdir() if p.is_dir()]
        if archived:
            info.append(f"{len(archived)} archived intent(s): {', '.join(p.name for p in sorted(archived))}")

    return {"project": str(docs_path), "mode": mode, "platform": platform,
            "issues": issues, "info": info}
