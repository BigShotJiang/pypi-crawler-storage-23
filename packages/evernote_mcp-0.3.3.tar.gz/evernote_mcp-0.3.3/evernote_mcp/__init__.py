"""Evernote MCP Server - Model Context Protocol server for Evernote operations."""

__version__ = "0.3.3"
