"""MCP tools for Evernote operations."""
