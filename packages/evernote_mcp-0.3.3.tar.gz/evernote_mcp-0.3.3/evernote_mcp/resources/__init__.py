"""MCP resources for Evernote data access."""
