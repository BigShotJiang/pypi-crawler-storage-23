"""Utility functions for Evernote MCP server."""
