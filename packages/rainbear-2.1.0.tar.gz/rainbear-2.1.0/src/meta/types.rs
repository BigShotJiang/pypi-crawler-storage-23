use std::collections::{BTreeMap, BTreeSet};
use std::fmt::Display;
use std::sync::Arc;

use polars::prelude::{
    DataType as PlDataType, Field, Schema,
    TimeUnit,
};
use smallvec::SmallVec;
use zarrs::array::ChunkGrid;

use crate::{IStr, IntoIStr};

// =============================================================================
// Unified Hierarchical Metadata Types
// =============================================================================

/// Unified metadata for any zarr store (flat or hierarchical).
/// A flat dataset is simply a tree where `root.children` is empty.
#[derive(Debug, Clone)]
pub struct ZarrMeta {
    /// Root node of the hierarchy
    pub root: ZarrNode,
    /// Dimension analysis across the entire tree
    pub dim_analysis: DimensionAnalysis,
    /// Fast lookup: array path (e.g., "model_a/temperature") -> array metadata
    pub path_to_array:
        BTreeMap<IStr, ZarrArrayMeta>,
}

/// A node in the zarr hierarchy (group or root).
#[derive(Debug, Clone)]
pub struct ZarrNode {
    /// Path from store root (e.g., "/" or "/model_a" or "/level_1/level_2")
    pub path: IStr,
    /// Arrays directly in this node (keyed by leaf name, not full path)
    pub arrays: BTreeMap<IStr, ZarrArrayMeta>,
    /// Child groups (keyed by child name)
    pub children: BTreeMap<IStr, ZarrNode>,
    /// Dimensions used by arrays in this node
    pub local_dims: Vec<IStr>,
    /// Data variable names (non-coordinate arrays) in this node
    pub data_vars: Vec<IStr>,
}

/// Dimension analysis across a tree - tracks how dimensions relate across nodes.
#[derive(Debug, Clone, Default)]
pub struct DimensionAnalysis {
    /// All unique dimensions across the tree, in output order (root dims first)
    pub all_dims: Vec<IStr>,
    /// Dimensions from the root node
    pub root_dims: Vec<IStr>,
    /// For each node path, its dimension set
    pub node_dims: BTreeMap<IStr, Vec<IStr>>,
    /// Dimension name -> length
    pub dim_lengths: BTreeMap<IStr, u64>,
}
impl DimensionAnalysis {
    /// Compute output dimension order: root dims first, then extras by first appearance.
    /// Recursively collects dimensions from all nodes in the tree.
    pub fn compute(root: &ZarrNode) -> Self {
        let mut all_dims: Vec<IStr> = Vec::new();
        let mut node_dims: BTreeMap<
            IStr,
            Vec<IStr>,
        > = BTreeMap::new();
        let mut dim_lengths: BTreeMap<IStr, u64> =
            BTreeMap::new();

        // Collect root dims first (they define primary order)
        let root_dims = root.local_dims.clone();
        for dim in &root_dims {
            if !all_dims.contains(dim) {
                all_dims.push(dim.clone());
            }
        }

        // Recursively collect from all nodes
        Self::collect_node(
            root,
            &mut all_dims,
            &mut node_dims,
            &mut dim_lengths,
        );

        Self {
            all_dims,
            root_dims,
            node_dims,
            dim_lengths,
        }
    }

    fn collect_node(
        node: &ZarrNode,
        all_dims: &mut Vec<IStr>,
        node_dims: &mut BTreeMap<IStr, Vec<IStr>>,
        dim_lengths: &mut BTreeMap<IStr, u64>,
    ) {
        // Record this node's dimensions
        node_dims.insert(
            node.path.clone(),
            node.local_dims.clone(),
        );

        // Add any new dimensions not yet seen
        for dim in &node.local_dims {
            if !all_dims.contains(dim) {
                all_dims.push(dim.clone());
            }
        }

        // Infer dim lengths from array shapes
        for (_, arr) in &node.arrays {
            for (i, dim) in
                arr.dims.iter().enumerate()
            {
                if i < arr.shape.len() {
                    dim_lengths
                        .entry(dim.clone())
                        .or_insert(arr.shape[i]);
                }
            }
        }

        // Recurse into children
        for (_, child) in &node.children {
            Self::collect_node(
                child,
                all_dims,
                node_dims,
                dim_lengths,
            );
        }
    }
}

impl ZarrMeta {
    /// True if there are any child groups
    pub fn is_hierarchical(&self) -> bool {
        !self.root.children.is_empty()
    }

    /// Normalize a user path to a canonical key in path_to_array.
    pub fn normalize_array_path(
        &self,
        path: &str,
    ) -> Option<IStr> {
        let raw = path.istr();
        if self.path_to_array.contains_key(&raw) {
            return Some(raw);
        }

        let trimmed =
            path.trim_start_matches('/');
        let with_slash =
            format!("/{}", trimmed).istr();
        if self
            .path_to_array
            .contains_key(&with_slash)
        {
            return Some(with_slash);
        }

        let trimmed_key = trimmed.istr();
        if self
            .path_to_array
            .contains_key(&trimmed_key)
        {
            return Some(trimmed_key);
        }

        None
    }

    /// Get array meta by a normalized path (adds leading '/' if needed).
    pub fn array_by_path(
        &self,
        path: &str,
    ) -> Option<&ZarrArrayMeta> {
        let key =
            self.normalize_array_path(path)?;
        self.path_to_array.get(&key)
    }

    /// Legacy meta for planning, includes all data var paths for hierarchical stores.
    pub fn planning_meta(
        &self,
    ) -> ZarrDatasetMeta {
        let mut legacy =
            ZarrDatasetMeta::from(self);
        if self.is_hierarchical() {
            legacy.data_vars =
                self.all_data_var_paths();
        }
        legacy
    }

    /// All data variable paths (flat: just names, hierarchical: includes "group/var" paths)
    pub fn all_data_var_paths(
        &self,
    ) -> Vec<IStr> {
        let mut out = Vec::new();
        self.collect_data_var_paths(
            &self.root, &mut out,
        );
        out
    }

    fn collect_data_var_paths(
        &self,
        node: &ZarrNode,
        out: &mut Vec<IStr>,
    ) {
        // Root node data vars use just the var name
        let path_str: &str = node.path.as_ref();
        let prefix = if path_str == "/" {
            String::new()
        } else {
            format!(
                "{}/",
                path_str.trim_start_matches('/')
            )
        };

        for var in &node.data_vars {
            let path = if prefix.is_empty() {
                var.clone()
            } else {
                format!("{}{}", prefix, var)
                    .istr()
            };
            out.push(path);
        }

        for (_, child) in &node.children {
            self.collect_data_var_paths(
                child, out,
            );
        }
    }

    /// Generate a Polars schema for the tidy DataFrame output.
    ///
    /// For flat datasets, this is the same as ZarrDatasetMeta::tidy_schema.
    /// For hierarchical datasets, child groups become struct columns.
    pub fn tidy_schema(
        &self,
        variables: Option<&[IStr]>,
    ) -> Schema {
        let var_set: Option<BTreeSet<&str>> =
            variables.map(|v| {
                v.iter()
                    .map(|s| s.as_ref())
                    .collect()
            });

        let mut fields: Vec<Field> = Vec::new();

        // Add dimension columns (from combined dimension analysis)
        for dim in &self.dim_analysis.all_dims {
            let dtype = self
                .path_to_array
                .get(dim)
                .map(|m| m.polars_dtype.clone())
                .unwrap_or(PlDataType::Int64);
            let dim_str: &str = dim.as_ref();
            fields.push(Field::new(
                dim_str.into(),
                dtype,
            ));
        }

        // Add root data variable columns
        for var in &self.root.data_vars {
            let var_str: &str = var.as_ref();
            if var_set
                .as_ref()
                .map_or(true, |vs| {
                    vs.contains(var_str)
                })
            {
                if let Some(m) =
                    self.root.arrays.get(var)
                {
                    fields.push(Field::new(
                        var_str.into(),
                        m.polars_dtype.clone(),
                    ));
                }
            }
        }

        // Add child group struct columns
        for (child_name, child_node) in
            &self.root.children
        {
            let child_name_str: &str =
                child_name.as_ref();
            // Check if this group or any of its vars are in the selection
            let should_include =
                var_set.as_ref().map_or(true, |vs| {
                    vs.contains(child_name_str)
                        || child_node.data_vars.iter().any(
                            |v| {
                                let v_str: &str =
                                    v.as_ref();
                                vs.contains(v_str)
                                    || vs.contains(
                                        &format!(
                                            "{}/{}",
                                            child_name_str,
                                            v_str
                                        )
                                        .as_str(),
                                    )
                            },
                        )
                });

            if should_include {
                let struct_dtype = self
                    .node_to_struct_dtype(
                        child_node,
                    );
                fields.push(Field::new(
                    child_name_str.into(),
                    struct_dtype,
                ));
            }
        }

        fields.into_iter().collect()
    }

    /// Convert a ZarrNode to a Struct dtype for schema generation.
    fn node_to_struct_dtype(
        &self,
        node: &ZarrNode,
    ) -> PlDataType {
        let mut struct_fields: Vec<Field> =
            Vec::new();

        // Add data variable fields
        for var in &node.data_vars {
            if let Some(arr_meta) =
                node.arrays.get(var)
            {
                let var_str: &str = var.as_ref();
                struct_fields.push(Field::new(
                    var_str.into(),
                    arr_meta.polars_dtype.clone(),
                ));
            }
        }

        // Recursively add nested child groups
        for (child_name, child_node) in
            &node.children
        {
            let child_name_str: &str =
                child_name.as_ref();
            let nested_dtype = self
                .node_to_struct_dtype(child_node);
            struct_fields.push(Field::new(
                child_name_str.into(),
                nested_dtype,
            ));
        }

        PlDataType::Struct(struct_fields)
    }
}

impl ZarrNode {
    /// Create a new empty node at the given path
    pub fn new(path: IStr) -> Self {
        Self {
            path,
            arrays: BTreeMap::new(),
            children: BTreeMap::new(),
            local_dims: Vec::new(),
            data_vars: Vec::new(),
        }
    }
}

impl Display for ZarrNode {
    fn fmt(
        &self,
        f: &mut std::fmt::Formatter<'_>,
    ) -> std::fmt::Result {
        write!(
            f,
            "ZarrNode(path='{}')",
            self.path
        )
    }
}
impl Display for ZarrMeta {
    fn fmt(
        &self,
        f: &mut std::fmt::Formatter<'_>,
    ) -> std::fmt::Result {
        write!(
            f,
            "ZarrMeta(root='{}')",
            self.root
        )
    }
}

/// CF-conventions time encoding information parsed from Zarr attributes.
#[derive(Debug, Clone)]
pub struct TimeEncoding {
    /// The epoch (reference timestamp) in nanoseconds since Unix epoch.
    pub epoch_ns: i64,
    /// Multiplier to convert stored units to nanoseconds.
    pub unit_ns: i64,
    /// Whether this is a duration (timedelta) rather than a datetime.
    pub is_duration: bool,
}

impl TimeEncoding {
    #[inline]
    pub fn decode(&self, raw: i64) -> i64 {
        if self.is_duration {
            raw.saturating_mul(self.unit_ns)
        } else {
            raw.saturating_mul(self.unit_ns)
                .saturating_add(self.epoch_ns)
        }
    }

    pub fn to_polars_dtype(&self) -> PlDataType {
        if self.is_duration {
            PlDataType::Duration(
                TimeUnit::Nanoseconds,
            )
        } else {
            PlDataType::Datetime(
                TimeUnit::Nanoseconds,
                None,
            )
        }
    }
}

#[derive(Debug, Clone)]
pub struct ZarrArrayMeta {
    pub path: IStr,
    /// Shape wrapped in Arc for cheap cloning.
    pub shape: Arc<[u64]>,
    /// Regular chunk shape (edge chunks may be smaller).
    pub chunk_shape: Arc<[u64]>,
    pub chunk_grid: Arc<ChunkGrid>,
    pub dims: SmallVec<[IStr; 4]>,
    pub polars_dtype: PlDataType,
    pub time_encoding: Option<TimeEncoding>,
    /// Raw zarrs ArrayMetadata from traverse (for unconsolidated stores)
    pub array_metadata:
        Option<Arc<zarrs::array::ArrayMetadata>>,
}

#[derive(Debug, Clone)]
pub struct ZarrDatasetMeta {
    pub arrays: BTreeMap<IStr, ZarrArrayMeta>,
    pub dims: Vec<IStr>,
    pub data_vars: Vec<IStr>,
}

impl ZarrDatasetMeta {
    pub fn tidy_schema(
        &self,
        variables: Option<&[IStr]>,
    ) -> Schema {
        let var_set: Option<BTreeSet<&str>> =
            variables.map(|v| {
                v.iter()
                    .map(|s| s.as_ref())
                    .collect()
            });

        let mut fields: Vec<Field> = Vec::new();

        for dim in &self.dims {
            let dtype = self
                .arrays
                .get(dim)
                .map(|m| m.polars_dtype.clone())
                .unwrap_or(PlDataType::Int64);
            fields.push(Field::new(
                (<IStr as AsRef<str>>::as_ref(
                    dim,
                ))
                .into(),
                dtype,
            ));
        }

        let vars_iter: Box<
            dyn Iterator<Item = &str>,
        > = if let Some(var_set) = &var_set {
            Box::new(
                self.data_vars
                    .iter()
                    .map(|s| s.as_ref())
                    .filter(|v| {
                        var_set.contains(v)
                    }),
            )
        } else {
            Box::new(
                self.data_vars
                    .iter()
                    .map(|s| s.as_ref()),
            )
        };

        for v in vars_iter {
            if let Some(m) =
                self.arrays.get(&v.istr())
            {
                fields.push(Field::new(
                    v.into(),
                    m.polars_dtype.clone(),
                ));
            }
        }

        fields.into_iter().collect()
    }
}

// =============================================================================
// Conversions between ZarrMeta and ZarrDatasetMeta
// =============================================================================

impl From<ZarrDatasetMeta> for ZarrMeta {
    /// Convert a flat ZarrDatasetMeta to the unified ZarrMeta format
    fn from(legacy: ZarrDatasetMeta) -> Self {
        let mut root = ZarrNode::new("/".istr());
        root.arrays = legacy.arrays.clone();
        root.local_dims = legacy.dims.clone();
        root.data_vars = legacy.data_vars.clone();

        let dim_analysis =
            DimensionAnalysis::compute(&root);

        let mut path_to_array = BTreeMap::new();
        for (name, arr) in &legacy.arrays {
            path_to_array.insert(
                name.clone(),
                arr.clone(),
            );
        }

        ZarrMeta {
            root,
            dim_analysis,
            path_to_array,
        }
    }
}

impl From<&ZarrMeta> for ZarrDatasetMeta {
    /// Convert a ZarrMeta back to flat ZarrDatasetMeta.
    ///
    /// This preserves hierarchical paths in `arrays` by including:
    /// - Full path with leading slash (e.g., `/model_a/temperature`)
    /// - Path without leading slash (e.g., `model_a/temperature`)
    /// - Leaf name for root arrays (e.g., `temperature`)
    ///
    /// `data_vars` contains only root-level variables for schema compatibility.
    /// Use `arrays` to look up variables by path.
    fn from(meta: &ZarrMeta) -> Self {
        let mut arrays = BTreeMap::new();

        // Add all paths from path_to_array
        for (path, arr) in &meta.path_to_array {
            let path_str: &str = path.as_ref();
            arrays.insert(
                path.clone(),
                arr.clone(),
            );

            // Also add without leading slash for user convenience
            if path_str.starts_with('/') {
                let no_slash = path_str
                    .trim_start_matches('/')
                    .istr();
                arrays
                    .entry(no_slash)
                    .or_insert_with(|| {
                        arr.clone()
                    });
            }
        }

        ZarrDatasetMeta {
            arrays,
            dims: meta
                .dim_analysis
                .root_dims
                .clone(),
            // Keep only root-level data vars for schema compatibility
            data_vars: meta
                .root
                .data_vars
                .clone(),
        }
    }
}
