/// Errors for the rainbear library.
mod backend;

pub(crate) use backend::BackendError;
