"""rainbear test suite."""
