import json
from datetime import datetime
from typing import Any

import pydantic
from aiohttp import web
from aiohttp.web import Request, Response
from yarl import URL

from alxhttp.req_id import get_request_id


def json_default(x: Any) -> Any:
  if isinstance(x, datetime):
    return x.timestamp()
  elif isinstance(x, URL):
    return str(x)
  elif isinstance(x, pydantic.BaseModel):
    return x.model_dump(mode='json')
  return str(x)


def strip_nulls(value: Any) -> Any:
  """Recursively strip null bytes from strings in dict keys, dict values, lists, etc."""
  if isinstance(value, str):
    # Clean string values
    return value.replace('\x00', '')
  elif isinstance(value, pydantic.BaseModel):
    return strip_nulls(value.model_dump(mode='json'))
  elif isinstance(value, list):
    # Clean list elements
    return [strip_nulls(v) for v in value]
  elif isinstance(value, dict):
    # Clean keys AND values
    clean_dict = {}
    for k, v in value.items():
      # Ensure key is a string before replacing (JSON only allows string keys anyway)
      if isinstance(k, str):
        clean_k = k.replace('\x00', '')
      else:
        clean_k = k  # if it's not a string, we leave it as-is
      clean_dict[clean_k] = strip_nulls(v)
    return clean_dict
  else:
    return value


def json_dumps(x: Any) -> str:
  return json.dumps(x, indent=0, sort_keys=True, default=json_default)


def json_response(x: Any, status: int = 200) -> web.Response:
  return web.json_response(text=json_dumps(x), status=status)


def json_error_response(req: Request, error: str, status_code: int, rest: dict[str, Any] | None = None) -> Response:
  rest = rest or {}

  return json_response(
    {
      'error': error,
      'status_code': status_code,
      'request_id': get_request_id(req),
    }
    | rest,
    status=status_code,
  )
