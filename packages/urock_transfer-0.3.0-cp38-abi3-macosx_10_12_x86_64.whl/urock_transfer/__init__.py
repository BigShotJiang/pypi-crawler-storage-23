"""Urock Transfer Python Bindings

Provides both synchronous and asynchronous clients for reliable data transfer.
"""

import json as _json
from typing import Any, Optional, List, Callable

# Import from Rust extension
from urock_transfer._urock_transfer import (
    TransferClient,
    AsyncTransferClient as _AsyncTransferClient,
    ProcessResult,
    Priority,
    Protocol,
    TransferError,
    # Chunk Transfer types
    Transfer,
    TransferState,
    TransferResult,
    Progress,
)

__all__ = [
    "TransferClient",
    "AsyncTransferClient",
    "ProcessResult",
    "Priority",
    "Protocol",
    "TransferError",
    # Chunk Transfer types
    "Transfer",
    "TransferState",
    "TransferResult",
    "Progress",
]


class AsyncTransferClient:
    """Asynchronous Transfer Client

    Use this for GUI applications and concurrent operations.
    Integrates with Python's asyncio.

    Example:
        ```python
        import asyncio
        from urock_transfer import AsyncTransferClient, Priority

        async def main():
            client = AsyncTransferClient()

            # Set policies
            def drop_policy(request, error):
                # Keep Critical priority
                return request["options"].get("priority") != "Critical"
            await client.set_drop_policy(drop_policy)

            def idle_policy(context):
                return context["network_metrics"]["status"] == "Online"
            await client.set_idle_policy(idle_policy)

            def on_drop(request, error):
                print(f"Dropped: {request}")
            await client.set_on_drop(on_drop)

            # Deferred send
            request_id = await client.send(
                data={"event": "click"},
                endpoint="https://api.example.com",
                immediate=False,
            )

            # Start queue
            await client.start_queue(interval_ms=5000)

            # Stop queue
            await client.stop_queue()

        asyncio.run(main())
        ```
    """

    def __init__(self):
        """Create a new AsyncTransferClient"""
        self._inner = _AsyncTransferClient()

    async def send(
        self,
        data: Any,
        endpoint: str,
        priority=None,
        protocol=None,
        immediate=None,
        retry_count=None,
        timeout=None,
        content_encoding=None,
    ) -> str:
        """Send data to the specified endpoint (async)

        Args:
            data: Data to send (dict, list, or any JSON-serializable object)
            endpoint: Target URL
            priority: Request priority (default: Normal)
            protocol: Protocol to use (default: Http)
            immediate: Send immediately without queuing (default: True)
            retry_count: Number of retries on failure
            timeout: Request timeout in milliseconds
            content_encoding: Content-Encoding header value (e.g., "gzip", "br")

        Returns:
            Request ID string
        """
        return await self._inner.send(
            data, endpoint, priority, protocol, immediate, retry_count, timeout, content_encoding
        )

    async def list_pending(self) -> List[str]:
        """List all pending request IDs (async)

        Returns:
            List of request ID strings
        """
        return await self._inner.list_pending()

    async def delete(self, request_id: str) -> None:
        """Delete a request by ID (async)

        Args:
            request_id: The request ID to delete
        """
        return await self._inner.delete(request_id)

    async def load(self, request_id: str) -> Optional[dict]:
        """Load a request by ID (async)

        Args:
            request_id: The request ID to load

        Returns:
            Full request as dict with data, options, created_at, attempt_count, next_retry_at
            or None if not found
        """
        result = await self._inner.load(request_id)
        if result is None:
            return None
        # Convert JSON string to dict (full request object)
        return _json.loads(result)

    async def clear_storage(self) -> None:
        """Clear all pending requests from storage (async)"""
        return await self._inner.clear_storage()

    # ========================================================================
    # Policy Methods
    # ========================================================================

    async def set_drop_policy(self, callback: Callable[[dict, str], bool]) -> None:
        """Set drop policy callback (async)

        Called when a request exceeds max_retries to decide if it should be dropped.

        Args:
            callback: Function (request: dict, error: str) -> bool
                      Returns True to drop, False to keep

        Example:
            def drop_policy(request, error):
                # Keep Critical priority
                return request["options"].get("priority") != "Critical"
            await client.set_drop_policy(drop_policy)
        """
        return await self._inner.set_drop_policy(callback)

    async def set_idle_policy(self, callback: Callable[[dict], bool]) -> None:
        """Set idle policy callback (async)

        Called to determine if the system is idle and should process queued requests.

        Args:
            callback: Function (context: dict) -> bool
                      Returns True if idle, False otherwise

        Context dict contains:
            - network_metrics: {status: "Online"|"Offline"|"Slow", latency_ms, bandwidth_mbps}
            - pending_count: int
            - last_send_time: int (optional, Unix timestamp ms)

        Example:
            def idle_policy(context):
                return context["network_metrics"]["status"] == "Online"
            await client.set_idle_policy(idle_policy)
        """
        return await self._inner.set_idle_policy(callback)

    async def set_on_drop(self, callback: Callable[[dict, str], None]) -> None:
        """Set on_drop callback (async)

        Called when a request is dropped after exceeding max_retries.

        Args:
            callback: Function (request: dict, error: str) -> None

        Example:
            def on_drop(request, error):
                print(f"Dropped: {request}, Error: {error}")
            await client.set_on_drop(on_drop)
        """
        return await self._inner.set_on_drop(callback)

    # ========================================================================
    # Queue Processing Methods
    # ========================================================================

    async def start_queue(
        self,
        interval_ms: Optional[int] = None,
        batch_size: Optional[int] = None,
        max_retries: Optional[int] = None,
    ) -> None:
        """Start background queue processing (async)

        Args:
            interval_ms: Processing interval in milliseconds (default: 5000)
            batch_size: Number of requests to process per tick (default: 5)
            max_retries: Maximum retry attempts before dropping (default: 3)
        """
        return await self._inner.start_queue(interval_ms, batch_size, max_retries)

    async def stop_queue(self) -> None:
        """Stop background queue processing (async)"""
        return await self._inner.stop_queue()

    def is_queue_running(self) -> bool:
        """Check if queue is running

        Returns:
            True if queue is running, False otherwise
        """
        return self._inner.is_queue_running()

    async def process_once(self) -> ProcessResult:
        """Process pending requests once (async, manual trigger)

        Uses AlwaysIdle policy to force processing regardless of network status.

        Returns:
            ProcessResult with status and counts
        """
        return await self._inner.process_once()

    # ========================================================================
    # Chunk Transfer Methods
    # ========================================================================

    def create_transfer(
        self,
        data: Any,
        endpoint: str,
        chunk_size: Optional[int] = None,
        chunk_endpoint: Optional[str] = None,
    ) -> "Transfer":
        """Create a chunk transfer for large data uploads

        Provides chunked upload with progress tracking, pause/resume, and cancel.

        Args:
            data: Data to send (dict, list, or any JSON-serializable object)
            endpoint: Target URL for the upload
            chunk_size: Chunk size in bytes (default: 65536)
            chunk_endpoint: Optional separate endpoint for chunk uploads

        Returns:
            Transfer object with methods: on_progress, complete, pause, resume, cancel

        Example:
            ```python
            async def main():
                client = AsyncTransferClient()
                transfer = client.create_transfer(
                    data=large_data,
                    endpoint="https://api.example.com/upload",
                    chunk_size=65536,
                )

                def on_progress(progress):
                    print(f"{progress.percent:.1f}%")
                transfer.on_progress(on_progress)

                result = transfer.complete()
                print(result)
            ```
        """
        return self._inner.create_transfer(
            data, endpoint, chunk_size, chunk_endpoint
        )
