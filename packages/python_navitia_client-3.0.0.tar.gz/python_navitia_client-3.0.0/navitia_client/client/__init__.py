# ruff: noqa: F401

from .navitia_client import NavitiaClient
