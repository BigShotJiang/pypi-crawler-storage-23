from dataclasses import dataclass


@dataclass
class Note:
    id: str
    value: str
