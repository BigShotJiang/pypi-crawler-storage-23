from enum import Enum


class Corpora(str, Enum):
    """
    Bodies of items (files/documents) to which the query applies.
    Prefer 'user' or 'drive' to 'allDrives' for efficiency.
    By default, corpora is set to 'user'.
    """

    USER = "user"
    DOMAIN = "domain"
    DRIVE = "drive"
    ALL_DRIVES = "allDrives"


class OrderBy(str, Enum):
    """
    Sort keys for ordering files in Google Drive.
    Each key has both ascending and descending options.
    """

    CREATED_TIME = (
        # When the file was created (ascending)
        "createdTime"
    )
    CREATED_TIME_DESC = (
        # When the file was created (descending)
        "createdTime desc"
    )
    FOLDER = (
        # The folder ID, sorted using alphabetical ordering (ascending)
        "folder"
    )
    FOLDER_DESC = (
        # The folder ID, sorted using alphabetical ordering (descending)
        "folder desc"
    )
    MODIFIED_BY_ME_TIME = (
        # The last time the file was modified by the user (ascending)
        "modifiedByMeTime"
    )
    MODIFIED_BY_ME_TIME_DESC = (
        # The last time the file was modified by the user (descending)
        "modifiedByMeTime desc"
    )
    MODIFIED_TIME = (
        # The last time the file was modified by anyone (ascending)
        "modifiedTime"
    )
    MODIFIED_TIME_DESC = (
        # The last time the file was modified by anyone (descending)
        "modifiedTime desc"
    )
    NAME = (
        # The name of the file, sorted using alphabetical ordering (e.g., 1, 12, 2, 22) (ascending)
        "name"
    )
    NAME_DESC = (
        # The name of the file, sorted using alphabetical ordering (e.g., 1, 12, 2, 22) (descending)
        "name desc"
    )
    NAME_NATURAL = (
        # The name of the file, sorted using natural sort ordering (e.g., 1, 2, 12, 22) (ascending)
        "name_natural"
    )
    NAME_NATURAL_DESC = (
        # The name of the file, sorted using natural sort ordering (e.g., 1, 2, 12, 22) (descending)
        "name_natural desc"
    )
    QUOTA_BYTES_USED = (
        # The number of storage quota bytes used by the file (ascending)
        "quotaBytesUsed"
    )
    QUOTA_BYTES_USED_DESC = (
        # The number of storage quota bytes used by the file (descending)
        "quotaBytesUsed desc"
    )
    RECENCY = (
        # The most recent timestamp from the file's date-time fields (ascending)
        "recency"
    )
    RECENCY_DESC = (
        # The most recent timestamp from the file's date-time fields (descending)
        "recency desc"
    )
    SHARED_WITH_ME_TIME = (
        # When the file was shared with the user, if applicable (ascending)
        "sharedWithMeTime"
    )
    SHARED_WITH_ME_TIME_DESC = (
        # When the file was shared with the user, if applicable (descending)
        "sharedWithMeTime desc"
    )
    STARRED = (
        # Whether the user has starred the file (ascending)
        "starred"
    )
    STARRED_DESC = (
        # Whether the user has starred the file (descending)
        "starred desc"
    )
    VIEWED_BY_ME_TIME = (
        # The last time the file was viewed by the user (ascending)
        "viewedByMeTime"
    )
    VIEWED_BY_ME_TIME_DESC = (
        # The last time the file was viewed by the user (descending)
        "viewedByMeTime desc"
    )


class DocumentFormat(str, Enum):
    MARKDOWN = "markdown"
    HTML = "html"
    GOOGLE_API_JSON = "google_api_json"


class PermissionRole(str, Enum):
    """Permission roles for sharing Google Drive files and folders."""

    READER = "reader"  # Can view and download
    COMMENTER = "commenter"  # Can view, download, and comment
    WRITER = "writer"  # Can view, download, comment, and edit
    OWNER = "owner"  # Full control (transfer ownership)


class UploadMimeType(str, Enum):
    """Supported file types for uploading to Google Drive.

    This tool can only upload regular files - it cannot create Google Workspace files
    (Google Docs, Sheets, Slides). Use these MIME types based on your file content.
    """

    # Text-based files (can be provided as plain text content)
    PLAIN_TEXT = "text/plain"  # .txt files
    CSV = "text/csv"  # .csv spreadsheet data
    JSON = "application/json"  # .json data files
    HTML = "text/html"  # .html web pages
    MARKDOWN = "text/markdown"  # .md documentation

    # Documents (provide as base64-encoded content)
    PDF = "application/pdf"  # .pdf documents

    # Images (provide as base64-encoded content)
    PNG = "image/png"  # .png images
    JPEG = "image/jpeg"  # .jpg/.jpeg images
    GIF = "image/gif"  # .gif images
    WEBP = "image/webp"  # .webp images
    SVG = "image/svg+xml"  # .svg vector graphics


class ExportFormat(str, Enum):
    """Export formats for Google Workspace files (Docs, Sheets, Slides, and Drawings)."""

    # Document formats
    PDF = "pdf"
    DOCX = "docx"
    ODT = "odt"
    RTF = "rtf"
    TXT = "txt"
    HTML = "html"
    EPUB = "epub"

    # Spreadsheet formats
    XLSX = "xlsx"
    ODS = "ods"
    CSV = "csv"
    TSV = "tsv"

    # Presentation formats
    PPTX = "pptx"
    ODP = "odp"

    # Drawing formats
    SVG = "svg"
    PNG = "png"
    JPEG = "jpeg"

    def _to_api_value(self) -> str:
        """Convert the enum value to the Google Drive API MIME type."""
        mime_type_map = {
            "pdf": "application/pdf",
            "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "odt": "application/vnd.oasis.opendocument.text",
            "rtf": "application/rtf",
            "txt": "text/plain",
            "html": "text/html",
            "epub": "application/epub+zip",
            "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "ods": "application/vnd.oasis.opendocument.spreadsheet",
            "csv": "text/csv",
            "tsv": "text/tab-separated-values",
            "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "odp": "application/vnd.oasis.opendocument.presentation",
            "svg": "image/svg+xml",
            "png": "image/png",
            "jpeg": "image/jpeg",
        }
        return mime_type_map[self.value]
