"""
cli module exceptions.
"""

from infrahouse_toolkit.exceptions import IHException


class IHCLIError(IHException):
    """Command line errors."""
