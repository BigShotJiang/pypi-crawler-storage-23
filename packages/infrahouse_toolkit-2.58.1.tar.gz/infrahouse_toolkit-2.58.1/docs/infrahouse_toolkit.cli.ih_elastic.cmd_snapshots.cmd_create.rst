infrahouse\_toolkit.cli.ih\_elastic.cmd\_snapshots.cmd\_create package
======================================================================

Module contents
---------------

.. automodule:: infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_create
   :members:
   :undoc-members:
   :show-inheritance:
