infrahouse\_toolkit.cli.ih\_openvpn.cmd\_revoke package
=======================================================

Module contents
---------------

.. automodule:: infrahouse_toolkit.cli.ih_openvpn.cmd_revoke
   :members:
   :undoc-members:
   :show-inheritance:
