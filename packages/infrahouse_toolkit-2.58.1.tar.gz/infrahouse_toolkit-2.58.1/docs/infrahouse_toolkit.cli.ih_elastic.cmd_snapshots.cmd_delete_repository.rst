infrahouse\_toolkit.cli.ih\_elastic.cmd\_snapshots.cmd\_delete\_repository package
==================================================================================

Module contents
---------------

.. automodule:: infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_delete_repository
   :members:
   :undoc-members:
   :show-inheritance:
