infrahouse\_toolkit.cli.ih\_elastic.cmd\_snapshots.cmd\_create\_repository package
==================================================================================

Module contents
---------------

.. automodule:: infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_create_repository
   :members:
   :undoc-members:
   :show-inheritance:
