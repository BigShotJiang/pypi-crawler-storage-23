=======
Credits
=======

Development Lead
----------------

* `Oleksandr Kuzminskyi <https://github.com/akuzminsky>`_

Contributors
------------

* `Pasha Dudka <https://github.com/paveldudka>`_
