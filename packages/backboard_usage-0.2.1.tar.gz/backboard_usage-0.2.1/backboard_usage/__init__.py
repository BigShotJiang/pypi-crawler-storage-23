"""
Backboard Usage — live token and cost visibility for Backboard apps.

  pip install backboard-usage
  backboard-usage-server   # start server, open http://localhost:8766

  In your Backboard app:
    from backboard_usage import UsageTracker
    tracker = UsageTracker()
    response = await client.add_message(...)
    await tracker.record(response, agent="Idea Analyzer")
    await tracker.finish()
"""

__version__ = "0.2.1"
from backboard_usage.tracker import UsageTracker

__all__ = ["UsageTracker", "__version__"]
