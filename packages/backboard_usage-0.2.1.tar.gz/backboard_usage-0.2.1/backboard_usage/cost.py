"""
Model cost estimates ($ per 1M tokens: input, output).
Used when the Backboard API does not return cost.
"""

_MODEL_COST_PER_1M = {
    "openai/gpt-4o": (2.50, 10.00),
    "openai/gpt-4o-mini": (0.15, 0.60),
    "openai/gpt-4-turbo": (10.00, 30.00),
    "openai/gpt-3.5-turbo": (0.50, 1.50),
    "anthropic/claude-3-5-sonnet": (3.00, 15.00),
    "anthropic/claude-3-7-sonnet": (3.00, 15.00),
    "anthropic/claude-3-7-sonnet-20250219": (3.00, 15.00),
    "anthropic/claude-3-opus": (15.00, 75.00),
    "anthropic/claude-3-haiku": (0.25, 1.25),
}


def estimate_cost(
    model: str | None, input_tokens: int, output_tokens: int
) -> float:
    """Estimate cost in USD from model name and token counts."""
    if not model or (not input_tokens and not output_tokens):
        return 0.0
    key = model.lower() if model else ""
    rates = _MODEL_COST_PER_1M.get(key)
    if not rates:
        for k, v in _MODEL_COST_PER_1M.items():
            if k in key or key in k:
                rates = v
                break
    if not rates:
        rates = (2.0, 6.0)
    inp_cost = (input_tokens / 1_000_000) * rates[0]
    out_cost = (output_tokens / 1_000_000) * rates[1]
    return round(inp_cost + out_cost, 6)
