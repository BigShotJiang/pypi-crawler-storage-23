"""
Comprehensive tests for crypto_utils.py — ephemeral cryptographic identity,
message signing/verification, nonce tracking, and key lifecycle.

Coverage mapping:
  OWASP Top 10 2021:
    A02 Cryptographic Failures — key generation, signature validation, HMAC integrity
    A07 Auth Failures          — token verification, constant-time comparison
    A08 Integrity Failures     — message tampering detection, replay prevention
  OWASP LLM Top 10 2025:
    LLM02 Sensitive Info Disclosure — key material handling
    LLM04 Data Poisoning            — message integrity prevents poisoned state
  MITRE ATT&CK:
    T1040 Network Sniffing     — signed messages resist passive interception
    T1134 Token Manipulation   — HMAC prevents forged auth
    T1185 Session Hijacking    — nonce replay prevention
    T1539 Steal Session Cookie — ephemeral keys, no persistent secrets
    T1550 Alternate Auth       — token-based HMAC
    T1557 Adversary-in-Middle  — Ed25519 signatures detect tampering
    T1565 Data Manipulation    — signed payloads detect modification
"""

from __future__ import annotations

import hashlib
import hmac as hmac_module
import os
import struct
import time

import pytest

# Import from parent (scripts/) via conftest sys.path manipulation
from crypto_utils import (
    NonceTracker,
    _lazy_nacl,
    generate_nonce,
    generate_session_keys,
    sign_message,
    verify_hmac,
    zero_key,
)

# ═══════════════════════════════════════════════════════════════════════════════
# 1. KEY GENERATION — OWASP A02; MITRE T1539
# ═══════════════════════════════════════════════════════════════════════════════


class TestKeyGeneration:
    """Ed25519 ephemeral keypair generation."""

    @pytest.mark.owasp_a02
    def test_generates_32_byte_private_key(self):
        priv, pub, verify = generate_session_keys()
        assert isinstance(priv, bytes)
        assert len(priv) == 32

    @pytest.mark.owasp_a02
    def test_public_key_is_hex_string(self):
        priv, pub, verify = generate_session_keys()
        assert isinstance(pub, str)
        # Must be valid hex
        bytes.fromhex(pub)

    @pytest.mark.owasp_a02
    def test_verify_key_matches_public_key(self):
        priv, pub, verify = generate_session_keys()
        assert pub == verify

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1539
    def test_keys_are_unique_per_call(self):
        """Each call generates a different keypair (ephemeral per session)."""
        keys = [generate_session_keys() for _ in range(10)]
        private_keys = [k[0] for k in keys]
        # All private keys should be unique
        assert len(set(private_keys)) == 10

    @pytest.mark.owasp_a02
    def test_public_key_length_ed25519(self):
        """Ed25519 public key is 32 bytes = 64 hex chars."""
        nacl = _lazy_nacl()
        if nacl is None:
            pytest.skip("PyNaCl not available")
        priv, pub, verify = generate_session_keys()
        assert len(pub) == 64

    @pytest.mark.owasp_a02
    def test_fallback_without_nacl(self):
        """When PyNaCl is not available, fallback produces valid output."""
        # We can't easily mock the import, but we can verify the contract
        priv, pub, verify = generate_session_keys()
        assert len(priv) == 32
        assert isinstance(pub, str)
        assert isinstance(verify, str)


# ═══════════════════════════════════════════════════════════════════════════════
# 2. NONCE GENERATION — OWASP A02; MITRE T1185
# ═══════════════════════════════════════════════════════════════════════════════


class TestNonceGeneration:
    """Nonce uniqueness and structure."""

    @pytest.mark.owasp_a02
    def test_nonce_is_hex_string(self):
        nonce = generate_nonce()
        assert isinstance(nonce, str)
        bytes.fromhex(nonce)  # must be valid hex

    @pytest.mark.owasp_a02
    def test_nonce_length(self):
        """Nonce = 8 (timestamp) + 8 (random) + 8 (counter) = 24 bytes = 48 hex chars."""
        nonce = generate_nonce()
        assert len(nonce) == 48

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1185
    def test_nonces_are_unique(self):
        """Generate many nonces; all must be unique."""
        nonces = [generate_nonce() for _ in range(10_000)]
        assert len(set(nonces)) == 10_000

    @pytest.mark.owasp_a02
    def test_nonce_contains_timestamp(self):
        """First 8 bytes encode the current time in ms."""
        before = int(time.time() * 1000)
        nonce = generate_nonce()
        after = int(time.time() * 1000)
        ts_bytes = bytes.fromhex(nonce[:16])
        ts_ms = struct.unpack(">Q", ts_bytes)[0]
        assert before <= ts_ms <= after + 1

    @pytest.mark.owasp_a02
    def test_nonce_counter_increments(self):
        """Counter portion should increment monotonically."""
        n1 = generate_nonce()
        n2 = generate_nonce()
        c1 = struct.unpack(">Q", bytes.fromhex(n1[32:48]))[0]
        c2 = struct.unpack(">Q", bytes.fromhex(n2[32:48]))[0]
        assert c2 > c1


# ═══════════════════════════════════════════════════════════════════════════════
# 3. MESSAGE SIGNING (server→browser) — OWASP A02, A08; MITRE T1557, T1565
# ═══════════════════════════════════════════════════════════════════════════════


class TestMessageSigning:
    """Ed25519 signature generation and verification."""

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1557
    def test_sign_produces_hex_signature(self, session_keys):
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        sig = sign_message(priv, '{"type":"test"}', nonce)
        assert isinstance(sig, str)
        bytes.fromhex(sig)  # valid hex

    @pytest.mark.owasp_a02
    def test_signature_length(self, session_keys):
        """Ed25519 signature is 64 bytes = 128 hex chars."""
        nacl = _lazy_nacl()
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        sig = sign_message(priv, '{"type":"test"}', nonce)
        if nacl:
            assert len(sig) == 128
        else:
            # HMAC-SHA256 fallback: 32 bytes = 64 hex chars
            assert len(sig) == 64

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1565
    def test_different_payload_different_signature(self, session_keys):
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        sig1 = sign_message(priv, '{"a":1}', nonce)
        sig2 = sign_message(priv, '{"a":2}', nonce)
        assert sig1 != sig2

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1565
    def test_different_nonce_different_signature(self, session_keys):
        priv, pub, _ = session_keys
        payload = '{"type":"test"}'
        sig1 = sign_message(priv, payload, "nonce_aaa")
        sig2 = sign_message(priv, payload, "nonce_bbb")
        assert sig1 != sig2

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1557
    def test_signature_verifies_with_nacl(self, session_keys):
        """Verify the signature with nacl.signing.VerifyKey."""
        nacl = _lazy_nacl()
        if nacl is None:
            pytest.skip("PyNaCl not available")
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        payload = '{"type":"state_updated","data":{}}'
        sig = sign_message(priv, payload, nonce)

        verify_key = nacl.signing.VerifyKey(bytes.fromhex(pub))
        message = (nonce + payload).encode("utf-8")
        sig_bytes = bytes.fromhex(sig)
        # This raises nacl.exceptions.BadSignatureError on failure
        verify_key.verify(message, sig_bytes)

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1565
    def test_tampered_payload_fails_verification(self, session_keys):
        """Modifying the payload after signing must fail verification."""
        nacl = _lazy_nacl()
        if nacl is None:
            pytest.skip("PyNaCl not available")
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        sig = sign_message(priv, '{"type":"original"}', nonce)

        verify_key = nacl.signing.VerifyKey(bytes.fromhex(pub))
        tampered = (nonce + '{"type":"tampered"}').encode("utf-8")
        sig_bytes = bytes.fromhex(sig)
        with pytest.raises(Exception):  # nacl.exceptions.BadSignatureError
            verify_key.verify(tampered, sig_bytes)

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1557
    def test_wrong_key_fails_verification(self):
        """Signature from one key cannot verify with a different key."""
        nacl = _lazy_nacl()
        if nacl is None:
            pytest.skip("PyNaCl not available")
        priv1, pub1, _ = generate_session_keys()
        priv2, pub2, _ = generate_session_keys()
        nonce = generate_nonce()
        sig = sign_message(priv1, "payload", nonce)

        verify_key2 = nacl.signing.VerifyKey(bytes.fromhex(pub2))
        with pytest.raises(Exception):
            verify_key2.verify((nonce + "payload").encode(), bytes.fromhex(sig))

    @pytest.mark.owasp_a02
    def test_sign_empty_payload(self, session_keys):
        """Signing an empty payload should work without error."""
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        sig = sign_message(priv, "", nonce)
        assert len(sig) > 0

    @pytest.mark.owasp_a02
    def test_sign_unicode_payload(self, session_keys):
        """Signing a payload with unicode should work."""
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        sig = sign_message(priv, '{"msg":"日本語テスト 🎉"}', nonce)
        assert len(sig) > 0


# ═══════════════════════════════════════════════════════════════════════════════
# 4. HMAC VERIFICATION (browser→server) — OWASP A02, A07; MITRE T1134, T1550
# ═══════════════════════════════════════════════════════════════════════════════


class TestHMACVerification:
    """HMAC-SHA256 verification for browser→server messages."""

    @pytest.mark.owasp_a07
    @pytest.mark.mitre_t1550
    def test_valid_hmac_passes(self, session_token):
        """A correctly computed HMAC must verify."""
        nonce = generate_nonce()
        payload = '{"type":"action","data":{}}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        assert verify_hmac(session_token, payload, nonce, sig) is True

    @pytest.mark.owasp_a07
    @pytest.mark.mitre_t1134
    def test_wrong_token_fails(self, session_token):
        """HMAC with wrong token must fail."""
        nonce = generate_nonce()
        payload = '{"type":"action"}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        assert verify_hmac("wrong_token_value", payload, nonce, sig) is False

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1565
    def test_tampered_payload_fails(self, session_token):
        """Modifying payload after signing must fail."""
        nonce = generate_nonce()
        payload = '{"type":"action","data":{"key":"original"}}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        assert verify_hmac(session_token, '{"type":"action","data":{"key":"tampered"}}', nonce, sig) is False

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1565
    def test_tampered_nonce_fails(self, session_token):
        """Changing nonce after signing must fail."""
        nonce = generate_nonce()
        payload = '{"type":"action"}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        assert verify_hmac(session_token, payload, "different_nonce", sig) is False

    @pytest.mark.owasp_a02
    def test_invalid_hex_signature_fails(self, session_token):
        """Non-hex signature must fail gracefully (not crash)."""
        assert verify_hmac(session_token, "payload", "nonce", "not_valid_hex!") is False

    @pytest.mark.owasp_a02
    def test_empty_signature_fails(self, session_token):
        assert verify_hmac(session_token, "payload", "nonce", "") is False

    @pytest.mark.owasp_a02
    def test_truncated_signature_fails(self, session_token):
        nonce = generate_nonce()
        payload = "test"
        message = (nonce + payload).encode("utf-8")
        full_sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        truncated = full_sig[:32]  # Only half
        assert verify_hmac(session_token, payload, nonce, truncated) is False

    @pytest.mark.owasp_a07
    @pytest.mark.mitre_t1134
    def test_constant_time_comparison(self, session_token):
        """verify_hmac uses hmac.compare_digest (constant-time) to prevent
        timing side-channel attacks. We verify this by checking the source code
        uses compare_digest, and by ensuring both True and False results work."""
        nonce = generate_nonce()
        payload = "test"
        message = (nonce + payload).encode("utf-8")
        correct_sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()

        # Correct: should be True
        assert verify_hmac(session_token, payload, nonce, correct_sig) is True

        # Wrong: should be False (and use constant-time comparison internally)
        wrong_sig = "00" * 32
        assert verify_hmac(session_token, payload, nonce, wrong_sig) is False

    @pytest.mark.owasp_a02
    def test_hmac_empty_token(self):
        """HMAC with empty token should still produce a result (not crash)."""
        nonce = generate_nonce()
        payload = "test"
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(b"", message, hashlib.sha256).hexdigest()
        assert verify_hmac("", payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    def test_hmac_unicode_payload(self, session_token):
        """HMAC over unicode payload works correctly."""
        nonce = generate_nonce()
        payload = '{"msg":"Ünïcödé 日本語"}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        assert verify_hmac(session_token, payload, nonce, sig) is True


# ═══════════════════════════════════════════════════════════════════════════════
# 5. NONCE REPLAY PROTECTION — OWASP A08; MITRE T1185
# ═══════════════════════════════════════════════════════════════════════════════


class TestNonceTracker:
    """NonceTracker prevents replay attacks."""

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1185
    def test_fresh_nonce_accepted(self, nonce_tracker):
        assert nonce_tracker.check_and_record("nonce_001") is True

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1185
    def test_replayed_nonce_rejected(self, nonce_tracker):
        assert nonce_tracker.check_and_record("nonce_001") is True
        assert nonce_tracker.check_and_record("nonce_001") is False

    @pytest.mark.owasp_a08
    def test_different_nonces_accepted(self, nonce_tracker):
        assert nonce_tracker.check_and_record("a") is True
        assert nonce_tracker.check_and_record("b") is True
        assert nonce_tracker.check_and_record("c") is True

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1185
    def test_many_replays_all_rejected(self, nonce_tracker):
        nonce_tracker.check_and_record("nonce_x")
        for _ in range(100):
            assert nonce_tracker.check_and_record("nonce_x") is False

    @pytest.mark.owasp_a08
    def test_expired_nonces_pruned(self):
        """Nonces older than the window are pruned and no longer tracked."""
        tracker = NonceTracker(window_seconds=1)
        tracker.check_and_record("old_nonce")
        time.sleep(1.1)
        # After the window, the nonce is pruned; a fresh check would accept it
        # (but in practice the nonce includes a timestamp so old nonces should
        # be rejected by other means)
        tracker._prune(time.time())
        assert "old_nonce" not in tracker._seen

    @pytest.mark.owasp_a08
    def test_clear_removes_all_nonces(self, nonce_tracker):
        for i in range(50):
            nonce_tracker.check_and_record(f"n{i}")
        nonce_tracker.clear()
        # After clear, all nonces should be accepted again
        assert nonce_tracker.check_and_record("n0") is True

    @pytest.mark.owasp_a08
    def test_concurrent_nonce_storm(self, nonce_tracker):
        """Simulate rapid nonce submission — all unique nonces accepted."""
        nonces = [generate_nonce() for _ in range(1000)]
        results = [nonce_tracker.check_and_record(n) for n in nonces]
        assert all(results), "All unique nonces should be accepted"
        # Replay should fail
        assert nonce_tracker.check_and_record(nonces[0]) is False

    @pytest.mark.mitre_t1185
    def test_replay_window_boundary(self):
        """Nonces right at the window boundary."""
        tracker = NonceTracker(window_seconds=2)
        tracker.check_and_record("boundary")
        time.sleep(1.0)
        # Still within window — replay should be caught
        assert tracker.check_and_record("boundary") is False
        time.sleep(1.5)
        # Beyond window — nonce should be pruned
        tracker._prune(time.time())
        assert "boundary" not in tracker._seen


# ═══════════════════════════════════════════════════════════════════════════════
# 6. KEY LIFECYCLE — OWASP A02; MITRE T1539; LLM02
# ═══════════════════════════════════════════════════════════════════════════════


class TestKeyLifecycle:
    """Ephemeral key management and cleanup."""

    @pytest.mark.owasp_a02
    @pytest.mark.llm02
    @pytest.mark.mitre_t1539
    def test_zero_key_does_not_crash(self):
        """zero_key should not raise even on arbitrary bytes."""
        key = os.urandom(32)
        zero_key(key)
        # We can't guarantee the zeroing worked (Python GC), but it shouldn't crash

    @pytest.mark.owasp_a02
    def test_zero_key_empty_bytes(self):
        """Zeroing empty bytes should not crash."""
        zero_key(b"")

    @pytest.mark.owasp_a02
    def test_keys_never_written_to_disk(self, tmp_path):
        """Keys should only exist in memory. This is a design verification test."""
        priv, pub, _ = generate_session_keys()
        # Verify no files were created by key generation
        assert list(tmp_path.iterdir()) == []

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1539
    def test_sign_after_zero_may_fail(self):
        """After zeroing, signing should either fail or produce garbage.
        This verifies that zero_key at least attempts to destroy key material."""
        priv, _, _ = generate_session_keys()
        nonce = generate_nonce()
        # Sign before zeroing — should work
        sig1 = sign_message(priv, "test", nonce)
        assert len(sig1) > 0

        # Zero the key
        zero_key(priv)
        # sign_message might still work (Python copies bytes) or produce different output
        # The point is that zero_key was called and didn't crash


# ═══════════════════════════════════════════════════════════════════════════════
# 7. END-TO-END SIGNING FLOW — MITRE T1557, T1565
# ═══════════════════════════════════════════════════════════════════════════════


class TestEndToEndSigning:
    """Full server→browser→server message flow with signing."""

    @pytest.mark.mitre_t1557
    @pytest.mark.mitre_t1565
    def test_full_round_trip(self, session_token):
        """Simulate: server signs state → browser receives → browser signs action → server verifies."""
        # --- Server side: sign a state update ---
        server_priv, server_pub, _ = generate_session_keys()
        state_payload = '{"type":"state_updated","data":{"version":1}}'
        state_nonce = generate_nonce()
        state_sig = sign_message(server_priv, state_payload, state_nonce)

        # --- Browser side: verify server signature ---
        nacl = _lazy_nacl()
        if nacl:
            verify_key = nacl.signing.VerifyKey(bytes.fromhex(server_pub))
            message = (state_nonce + state_payload).encode("utf-8")
            verify_key.verify(message, bytes.fromhex(state_sig))  # Should not raise

        # --- Browser side: sign an action response ---
        action_payload = '{"type":"action","data":{"action_id":"approve_1","type":"approve","value":true}}'
        action_nonce = generate_nonce()
        action_message = (action_nonce + action_payload).encode("utf-8")
        action_sig = hmac_module.new(session_token.encode(), action_message, hashlib.sha256).hexdigest()

        # --- Server side: verify browser HMAC ---
        assert verify_hmac(session_token, action_payload, action_nonce, action_sig) is True

    @pytest.mark.mitre_t1557
    @pytest.mark.mitre_t1565
    def test_mitm_tamper_detected_server_to_browser(self, session_token):
        """A MITM modifying a server→browser message is detected."""
        server_priv, server_pub, _ = generate_session_keys()
        nacl = _lazy_nacl()
        if nacl is None:
            pytest.skip("PyNaCl not available")

        payload = '{"type":"state_updated","data":{"status":"ready"}}'
        nonce = generate_nonce()
        sig = sign_message(server_priv, payload, nonce)

        # MITM modifies the payload
        tampered_payload = '{"type":"state_updated","data":{"status":"compromised"}}'

        verify_key = nacl.signing.VerifyKey(bytes.fromhex(server_pub))
        with pytest.raises(Exception):
            verify_key.verify(
                (nonce + tampered_payload).encode("utf-8"),
                bytes.fromhex(sig),
            )

    @pytest.mark.mitre_t1557
    @pytest.mark.mitre_t1565
    def test_mitm_tamper_detected_browser_to_server(self, session_token):
        """A MITM modifying a browser→server message is detected."""
        payload = '{"type":"action","data":{"action_id":"submit","type":"submit","value":{}}}'
        nonce = generate_nonce()
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()

        # MITM tampers
        tampered = '{"type":"action","data":{"action_id":"submit","type":"delete","value":{}}}'
        assert verify_hmac(session_token, tampered, nonce, sig) is False


class TestHMACFallbackKeys:
    """Tests for HMAC fallback key generation when PyNaCl is unavailable (H4 hardening)."""

    @pytest.mark.owasp_a02
    def test_hmac_fallback_returns_empty_verify_hex(self):
        """When PyNaCl is absent, verify_hex must be empty string (not a fake public key)."""
        import unittest.mock

        with unittest.mock.patch("crypto_utils._lazy_nacl", return_value=None):
            priv, pub, verify = generate_session_keys()
            assert isinstance(priv, bytes)
            assert len(priv) == 32  # HMAC key is 32-byte SHA256 digest
            assert pub == "", "HMAC fallback must return empty public key"
            assert verify == "", "HMAC fallback must return empty verify key"

    @pytest.mark.owasp_a02
    def test_hmac_fallback_key_is_derived(self):
        """HMAC fallback key should be derived from random seed, not the seed itself."""
        import unittest.mock

        with unittest.mock.patch("crypto_utils._lazy_nacl", return_value=None):
            priv1, _, _ = generate_session_keys()
            priv2, _, _ = generate_session_keys()
            assert priv1 != priv2, "Each call should produce a unique HMAC key"

    @pytest.mark.owasp_a02
    def test_hmac_fallback_signing_still_works(self):
        """HMAC-only mode should still produce valid signatures."""
        import unittest.mock

        with unittest.mock.patch("crypto_utils._lazy_nacl", return_value=None):
            priv, _, _ = generate_session_keys()
            sig = sign_message(priv, "test-payload", "test-nonce")
            assert isinstance(sig, str)
            assert len(sig) == 64  # HMAC-SHA256 produces 32 bytes = 64 hex chars


class TestNonceTrackerCapacity:
    """Tests for NonceTracker capacity handling (M2 hardening)."""

    @pytest.mark.owasp_a05
    def test_aggressive_prune_at_capacity(self):
        """When at MAX_NONCE_COUNT, aggressive prune with halved window should free space."""
        tracker = NonceTracker(window_seconds=10)
        now = time.time()
        # Fill to capacity with nonces from 6 seconds ago (within full window, outside half-window)
        for i in range(tracker.MAX_NONCE_COUNT):
            tracker._seen[f"nonce-{i}"] = now - 6  # 6s ago (within 10s window, but outside 5s half-window)

        # The next check_and_record should trigger aggressive prune and succeed
        result = tracker.check_and_record("fresh-nonce")
        assert result is True, "Should succeed after aggressive prune frees space"
        assert "fresh-nonce" in tracker._seen

    @pytest.mark.owasp_a05
    def test_capacity_hard_reject_when_all_recent(self):
        """When ALL nonces are very recent, even aggressive prune can't free space."""
        tracker = NonceTracker(window_seconds=10)
        now = time.time()
        # Fill to capacity with nonces from just now
        for i in range(tracker.MAX_NONCE_COUNT):
            tracker._seen[f"nonce-{i}"] = now

        result = tracker.check_and_record("fresh-nonce")
        assert result is False, "Should reject when no nonces can be pruned"

    @pytest.mark.owasp_a05
    def test_nonce_tracker_prune_with_window_override(self):
        """_prune with window_override should use the overridden window."""
        tracker = NonceTracker(window_seconds=60)
        now = time.time()
        tracker._seen["old"] = now - 20  # 20s ago
        tracker._seen["recent"] = now - 5  # 5s ago

        # Prune with 10s override window should remove 'old' but keep 'recent'
        tracker._prune(now, window_override=10)
        assert "old" not in tracker._seen
        assert "recent" in tracker._seen


# ═══════════════════════════════════════════════════════════════════════════════
# 8. PyNaCl success paths — OWASP A02
# ═══════════════════════════════════════════════════════════════════════════════


class TestNaClSuccessPaths:
    """Cover the Ed25519 code paths (lines 24-26, 55-58, 109-111) when PyNaCl is available."""

    @pytest.mark.owasp_a02
    def test_lazy_nacl_returns_module(self):
        """_lazy_nacl() should return the nacl module when installed."""
        nacl = _lazy_nacl()
        if nacl is None:
            pytest.skip("PyNaCl not installed")
        assert hasattr(nacl, "signing")
        assert hasattr(nacl, "encoding")

    @pytest.mark.owasp_a02
    def test_ed25519_keygen_with_nacl(self):
        """When PyNaCl is available, keys should be Ed25519."""
        nacl = _lazy_nacl()
        if nacl is None:
            pytest.skip("PyNaCl not installed")
        priv, pub, verify = generate_session_keys()
        assert len(pub) == 64  # Ed25519 public key is 32 bytes = 64 hex
        assert pub == verify

    @pytest.mark.owasp_a02
    def test_ed25519_signing_with_nacl(self):
        """When PyNaCl is available, sign_message uses Ed25519."""
        nacl = _lazy_nacl()
        if nacl is None:
            pytest.skip("PyNaCl not installed")
        priv, pub, _ = generate_session_keys()
        nonce = generate_nonce()
        sig = sign_message(priv, "test-payload", nonce)
        assert len(sig) == 128  # Ed25519 signature is 64 bytes = 128 hex

    @pytest.mark.owasp_a02
    def test_nacl_sign_and_verify_roundtrip(self):
        """Ed25519 sign + verify roundtrip."""
        nacl = _lazy_nacl()
        if nacl is None:
            pytest.skip("PyNaCl not installed")
        priv, pub, _ = generate_session_keys()
        nonce = generate_nonce()
        payload = '{"action": "test"}'
        sig = sign_message(priv, payload, nonce)
        verify_key = nacl.signing.VerifyKey(bytes.fromhex(pub))
        message = (nonce + payload).encode("utf-8")
        verify_key.verify(message, bytes.fromhex(sig))  # Should not raise


# ═══════════════════════════════════════════════════════════════════════════════
# 9. zero_key edge cases — OWASP A02
# ═══════════════════════════════════════════════════════════════════════════════


class TestZeroKeyEdgeCases:
    """Cover zero_key bytearray path (lines 205-207), non-cpython (213), ctypes error (218-219)."""

    @pytest.mark.owasp_a02
    def test_zero_key_bytearray(self):
        """Zeroing a bytearray should zero all bytes."""
        key = bytearray(b"secret-key-data!")
        zero_key(key)
        assert all(b == 0 for b in key)

    @pytest.mark.owasp_a02
    def test_zero_key_empty_bytearray(self):
        """Zeroing empty bytearray should not crash."""
        key = bytearray(b"")
        zero_key(key)
        assert len(key) == 0

    @pytest.mark.owasp_a02
    def test_zero_key_non_cpython(self):
        """On non-CPython, zero_key should return early without error."""
        import unittest.mock

        key = b"some-key-material"
        with unittest.mock.patch("sys.implementation") as mock_impl:
            mock_impl.name = "pypy"
            zero_key(key)  # Should not raise

    @pytest.mark.owasp_a02
    def test_zero_key_ctypes_failure(self):
        """When ctypes operations fail, zero_key should not crash."""
        import ctypes
        import unittest.mock

        key = b"some-key-material"
        with unittest.mock.patch.object(
            ctypes.pythonapi,
            "PyBytes_AsString",
            side_effect=Exception("ctypes failure"),
        ):
            zero_key(key)  # Should not raise


# ═══════════════════════════════════════════════════════════════════════════════
# 10. PyNaCl mocked paths — cover lines 24-26, 55-58, 109-111
# ═══════════════════════════════════════════════════════════════════════════════


class TestNaClMockedPaths:
    """Cover Ed25519 code paths by mocking the nacl module."""

    @pytest.mark.owasp_a02
    def test_lazy_nacl_import_success(self):
        """Cover the import success path of _lazy_nacl (lines 24-26)."""
        import unittest.mock

        # Create a mock nacl module
        mock_nacl = unittest.mock.MagicMock()
        mock_nacl.signing = unittest.mock.MagicMock()
        mock_nacl.encoding = unittest.mock.MagicMock()

        with unittest.mock.patch.dict(
            "sys.modules",
            {
                "nacl": mock_nacl,
                "nacl.signing": mock_nacl.signing,
                "nacl.encoding": mock_nacl.encoding,
            },
        ):
            result = _lazy_nacl()
            assert result is not None

    @pytest.mark.owasp_a02
    def test_ed25519_keygen_mocked(self):
        """Cover Ed25519 key generation path (lines 55-58) with mocked nacl."""
        import unittest.mock

        mock_nacl = unittest.mock.MagicMock()

        class FakeSigningKey:
            def __init__(self):
                self.verify_key = unittest.mock.MagicMock()
                self.verify_key.encode.return_value.decode.return_value = "ab" * 32
                self._seed = b"x" * 32

            def __bytes__(self):
                return self._seed

        mock_nacl.signing.SigningKey.generate.return_value = FakeSigningKey()
        mock_nacl.encoding.HexEncoder = unittest.mock.MagicMock()

        with unittest.mock.patch("crypto_utils._lazy_nacl", return_value=mock_nacl):
            priv, pub, verify = generate_session_keys()
            assert len(priv) == 32
            assert pub == "ab" * 32
            assert verify == pub

    @pytest.mark.owasp_a02
    def test_ed25519_sign_mocked(self):
        """Cover Ed25519 signing path (lines 109-111) with mocked nacl."""
        import unittest.mock

        mock_nacl = unittest.mock.MagicMock()
        mock_signed = unittest.mock.MagicMock()
        mock_signed.signature = b"\x00" * 64
        mock_nacl.signing.SigningKey.return_value.sign.return_value = mock_signed

        with unittest.mock.patch("crypto_utils._lazy_nacl", return_value=mock_nacl):
            sig = sign_message(b"k" * 32, "payload", "nonce")
            assert isinstance(sig, str)
            assert len(sig) == 128  # 64 bytes = 128 hex


# ═══════════════════════════════════════════════════════════════════════════════
# EDGE CASE TESTS — Tokens with null bytes, control chars, encoding,
# empty/long nonces, HMAC boundary conditions
# ═══════════════════════════════════════════════════════════════════════════════


class TestHMACTokenEdgeCases:
    """HMAC verification with unusual token and nonce values."""

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1134
    def test_token_with_null_bytes(self):
        """HMAC should handle tokens containing null bytes without error."""
        token = "abc\x00def"
        nonce = generate_nonce()
        payload = '{"type":"action"}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1134
    def test_token_with_null_bytes_wrong_sig_rejected(self):
        """HMAC with null-byte token must reject wrong signatures."""
        token = "abc\x00def"
        nonce = generate_nonce()
        payload = '{"type":"action"}'
        assert verify_hmac(token, payload, nonce, "00" * 32) is False

    @pytest.mark.owasp_a02
    def test_token_with_newlines_and_tabs(self):
        """HMAC should handle tokens with newlines and tab characters."""
        token = "abc\ndef\ttab"
        nonce = generate_nonce()
        payload = '{"type":"action"}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    def test_token_with_control_characters(self):
        """HMAC should handle tokens with various ASCII control characters."""
        token = "tok\x01\x02\x03\x7fend"
        nonce = generate_nonce()
        payload = "test"
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    def test_token_with_utf8_multibyte_chars(self):
        """HMAC should handle tokens with UTF-8 multi-byte characters."""
        token = "tok\u00e9n_\u65e5\u672c\u8a9e"
        nonce = generate_nonce()
        payload = '{"data":"test"}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    def test_token_with_emoji(self):
        """HMAC should handle tokens containing emoji (4-byte UTF-8)."""
        token = "secret\U0001f512key"
        nonce = generate_nonce()
        payload = "test"
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    def test_token_encoding_consistency(self):
        """HMAC must produce consistent results for the same token+nonce+payload."""
        token = "consistent_token_\u00e9"
        nonce = generate_nonce()
        payload = '{"key":"value"}'
        message = (nonce + payload).encode("utf-8")
        sig1 = hmac_module.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        sig2 = hmac_module.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert sig1 == sig2
        assert verify_hmac(token, payload, nonce, sig1) is True
        assert verify_hmac(token, payload, nonce, sig2) is True


class TestHMACNonceEdgeCases:
    """HMAC verification with unusual nonce values."""

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1185
    def test_empty_nonce(self, session_token):
        """HMAC with empty nonce string should still produce a valid result."""
        nonce = ""
        payload = '{"type":"action"}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        assert verify_hmac(session_token, payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1185
    def test_empty_nonce_wrong_sig_rejected(self, session_token):
        """HMAC with empty nonce must still reject wrong signatures."""
        assert verify_hmac(session_token, "payload", "", "00" * 32) is False

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1185
    def test_very_long_nonce(self, session_token):
        """HMAC with a very long nonce should work without error."""
        nonce = "a" * 10_000
        payload = '{"type":"action"}'
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        assert verify_hmac(session_token, payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    def test_nonce_with_special_chars(self, session_token):
        """HMAC with a nonce containing non-hex characters should work."""
        nonce = "nonce-with-special!@#$%^&*()"
        payload = "test"
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        assert verify_hmac(session_token, payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    def test_nonce_with_null_bytes(self, session_token):
        """HMAC with a nonce containing null bytes should work correctly."""
        nonce = "abc\x00def"
        payload = "test"
        message = (nonce + payload).encode("utf-8")
        sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
        assert verify_hmac(session_token, payload, nonce, sig) is True

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1185
    def test_nonce_format_mismatch_no_crash(self, session_token):
        """Using a non-standard nonce format should not crash verify_hmac."""
        # Generate a proper HMAC with a non-standard nonce, then verify
        odd_nonces = ["", "x", "0" * 100, "\xff\xfe", "not-hex-at-all"]
        for nonce in odd_nonces:
            payload = "test"
            message = (nonce + payload).encode("utf-8")
            sig = hmac_module.new(session_token.encode(), message, hashlib.sha256).hexdigest()
            result = verify_hmac(session_token, payload, nonce, sig)
            assert result is True, f"Valid HMAC with nonce {nonce!r} should verify"


class TestNonceTrackerEdgeCases:
    """Edge cases for NonceTracker replay protection."""

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1185
    def test_empty_string_nonce_tracked(self, nonce_tracker):
        """Empty string nonce should be tracked and replay-detected."""
        assert nonce_tracker.check_and_record("") is True
        assert nonce_tracker.check_and_record("") is False

    @pytest.mark.owasp_a08
    def test_nonce_with_null_bytes_tracked(self, nonce_tracker):
        """Nonces with null bytes should be tracked correctly."""
        assert nonce_tracker.check_and_record("abc\x00def") is True
        assert nonce_tracker.check_and_record("abc\x00def") is False
        # A different nonce should still be accepted
        assert nonce_tracker.check_and_record("abc\x00ghi") is True

    @pytest.mark.owasp_a08
    def test_very_long_nonce_tracked(self, nonce_tracker):
        """Very long nonces should be tracked without error."""
        long_nonce = "x" * 100_000
        assert nonce_tracker.check_and_record(long_nonce) is True
        assert nonce_tracker.check_and_record(long_nonce) is False

    @pytest.mark.owasp_a08
    def test_unicode_nonces_tracked(self, nonce_tracker):
        """Unicode nonces should be tracked correctly."""
        assert nonce_tracker.check_and_record("\u65e5\u672c\u8a9e") is True
        assert nonce_tracker.check_and_record("\u65e5\u672c\u8a9e") is False
        assert nonce_tracker.check_and_record("\u65e5\u672c\u8a9f") is True  # different char

    @pytest.mark.owasp_a08
    @pytest.mark.mitre_t1185
    def test_clear_allows_reuse(self, nonce_tracker):
        """After clear(), previously seen nonces should be accepted again."""
        assert nonce_tracker.check_and_record("nonce_a") is True
        assert nonce_tracker.check_and_record("nonce_a") is False
        nonce_tracker.clear()
        assert nonce_tracker.check_and_record("nonce_a") is True


class TestSignMessageEdgeCases:
    """Edge cases for sign_message with unusual inputs."""

    @pytest.mark.owasp_a02
    def test_sign_payload_with_null_bytes(self, session_keys):
        """Signing a payload containing null bytes should not error."""
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        sig = sign_message(priv, '{"msg":"abc\x00def"}', nonce)
        assert isinstance(sig, str)
        assert len(sig) > 0

    @pytest.mark.owasp_a02
    def test_sign_payload_with_control_chars(self, session_keys):
        """Signing a payload with control characters should work."""
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        sig = sign_message(priv, "line1\nline2\ttab\rcarriage", nonce)
        assert isinstance(sig, str)
        assert len(sig) > 0

    @pytest.mark.owasp_a02
    def test_sign_very_large_payload(self, session_keys):
        """Signing a very large payload should work without error."""
        priv, pub, _ = session_keys
        nonce = generate_nonce()
        large_payload = '{"data":"' + "x" * 100_000 + '"}'
        sig = sign_message(priv, large_payload, nonce)
        assert isinstance(sig, str)
        assert len(sig) > 0

    @pytest.mark.owasp_a02
    def test_sign_empty_nonce(self, session_keys):
        """Signing with an empty nonce should work (no crash)."""
        priv, pub, _ = session_keys
        sig = sign_message(priv, '{"type":"test"}', "")
        assert isinstance(sig, str)
        assert len(sig) > 0

    @pytest.mark.owasp_a02
    def test_sign_with_long_nonce(self, session_keys):
        """Signing with a very long nonce should work without error."""
        priv, pub, _ = session_keys
        long_nonce = "n" * 50_000
        sig = sign_message(priv, '{"type":"test"}', long_nonce)
        assert isinstance(sig, str)
        assert len(sig) > 0

    @pytest.mark.owasp_a02
    @pytest.mark.mitre_t1565
    def test_sign_deterministic_per_key_and_input(self, session_keys):
        """Same key, payload, nonce should produce same signature (deterministic)."""
        priv, pub, _ = session_keys
        nonce = "fixed_nonce_for_determinism"
        payload = '{"type":"test"}'
        sig1 = sign_message(priv, payload, nonce)
        sig2 = sign_message(priv, payload, nonce)
        assert sig1 == sig2, "Same inputs must produce identical signatures"


# ═══════════════════════════════════════════════════════════════════════════════
# HMAC EDGE CASES — Boundary and Bypass Tests (M11)
# ═══════════════════════════════════════════════════════════════════════════════


class TestHMACEdgeCases:
    """Edge case tests for HMAC verification added during v0.8.2 security audit."""

    def test_empty_payload_valid_signature(self):
        """Empty payload with valid HMAC should verify."""
        token = "test_secret_token"
        payload = ""
        nonce = "nonce123"
        # Compute expected HMAC
        import hashlib
        import hmac as hmac_mod

        message = (nonce + payload).encode("utf-8")
        sig = hmac_mod.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    def test_empty_nonce_valid_signature(self):
        """Empty nonce with valid HMAC should verify."""
        token = "test_secret_token"
        payload = '{"action": "test"}'
        nonce = ""
        import hashlib
        import hmac as hmac_mod

        message = (nonce + payload).encode("utf-8")
        sig = hmac_mod.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    def test_empty_token_valid_signature(self):
        """Empty token with matching HMAC should verify (but is weak)."""
        token = ""
        payload = '{"data": "test"}'
        nonce = "nonce1"
        import hashlib
        import hmac as hmac_mod

        message = (nonce + payload).encode("utf-8")
        sig = hmac_mod.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    def test_wrong_signature_rejected(self):
        """Incorrect HMAC signature should be rejected."""
        assert verify_hmac("token", "payload", "nonce", "deadbeef" * 8) is False

    def test_truncated_signature_rejected(self):
        """Truncated (too short) hex signature should be rejected."""
        assert verify_hmac("token", "payload", "nonce", "abcd") is False

    def test_invalid_hex_signature_rejected(self):
        """Non-hex signature string should be rejected (not crash)."""
        assert verify_hmac("token", "payload", "nonce", "not-valid-hex!!!") is False

    def test_empty_signature_rejected(self):
        """Empty signature string should be rejected."""
        assert verify_hmac("token", "payload", "nonce", "") is False

    def test_unicode_payload_hmac(self):
        """Unicode characters in payload should be handled correctly."""
        token = "secret"
        payload = '{"title": "café ☕ 日本語"}'
        nonce = "u-nonce"
        import hashlib
        import hmac as hmac_mod

        message = (nonce + payload).encode("utf-8")
        sig = hmac_mod.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    def test_unicode_token_hmac(self):
        """Unicode characters in token should be handled correctly."""
        token = "sécret_tökën_🔑"
        payload = '{"data": 1}'
        nonce = "n1"
        import hashlib
        import hmac as hmac_mod

        message = (nonce + payload).encode("utf-8")
        sig = hmac_mod.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    def test_very_long_payload_hmac(self):
        """Very long payload should still verify correctly."""
        token = "secret"
        payload = "x" * 100_000
        nonce = "long-nonce"
        import hashlib
        import hmac as hmac_mod

        message = (nonce + payload).encode("utf-8")
        sig = hmac_mod.new(token.encode("utf-8"), message, hashlib.sha256).hexdigest()
        assert verify_hmac(token, payload, nonce, sig) is True

    def test_timing_safe_comparison(self):
        """Verify that hmac.compare_digest is used (constant-time comparison)."""
        import inspect

        src = inspect.getsource(verify_hmac)
        assert "compare_digest" in src, "Must use hmac.compare_digest for timing-safe comparison"

    def test_nonce_payload_boundary_not_confused(self):
        """Ensure nonce='ab' + payload='cd' != nonce='a' + payload='bcd'.

        The HMAC message is nonce+payload concatenated. If an attacker can
        shift bytes between nonce and payload, they could forge signatures.
        This test verifies that different nonce/payload splits produce
        different signatures even with the same concatenation.
        """
        token = "secret"
        import hashlib
        import hmac as hmac_mod

        # Same concatenation "abcd" but different split points
        msg1 = ("ab" + "cd").encode("utf-8")
        sig1 = hmac_mod.new(token.encode("utf-8"), msg1, hashlib.sha256).hexdigest()

        msg2 = ("a" + "bcd").encode("utf-8")
        sig2 = hmac_mod.new(token.encode("utf-8"), msg2, hashlib.sha256).hexdigest()

        # These will actually be the same since nonce+payload is just string concat
        # This documents the known limitation — the protocol relies on nonce format
        # (UUID-like) to prevent this confusion in practice
        assert sig1 == sig2, "Same concatenation produces same HMAC (known limitation)"
        # But verify_hmac with different nonce/payload split should still verify
        assert verify_hmac(token, "cd", "ab", sig1) is True
        assert verify_hmac(token, "bcd", "a", sig2) is True
