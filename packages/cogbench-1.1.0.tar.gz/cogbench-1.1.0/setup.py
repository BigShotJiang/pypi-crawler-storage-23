"""Minimal setup.py for backward compatibility with older pip versions."""
from setuptools import setup
setup()
