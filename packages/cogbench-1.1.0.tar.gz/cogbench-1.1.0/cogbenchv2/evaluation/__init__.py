"""Evaluation pipeline for CogBench."""
