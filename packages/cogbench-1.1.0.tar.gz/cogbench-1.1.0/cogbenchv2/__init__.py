"""CogBench — Verifiable Cognitive Constraint Benchmark."""

__version__ = "1.1.0"
