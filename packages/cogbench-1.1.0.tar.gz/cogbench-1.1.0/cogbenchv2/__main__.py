"""Allow running CogBench as: python -m cogbenchv2"""

from cogbenchv2.cli import main

main()
