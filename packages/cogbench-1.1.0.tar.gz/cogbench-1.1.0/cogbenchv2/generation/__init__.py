"""Question generation pipeline for CogBench."""
