"""Analysis, figures, and tables for CogBench."""
