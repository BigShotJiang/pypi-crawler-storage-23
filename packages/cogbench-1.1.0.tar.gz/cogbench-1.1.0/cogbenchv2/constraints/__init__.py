"""Constraint checkers for CogBench."""
