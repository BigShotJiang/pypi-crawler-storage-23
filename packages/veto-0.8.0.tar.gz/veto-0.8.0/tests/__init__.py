# Pytest configuration for Veto Python SDK tests
