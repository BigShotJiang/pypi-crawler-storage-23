# MaterialBase

::: pynmms.base.MaterialBase
    options:
      show_source: true
      members:
        - __init__
        - language
        - consequences
        - add_atom
        - add_consequence
        - is_axiom
        - to_dict
        - from_dict
        - to_file
        - from_file
