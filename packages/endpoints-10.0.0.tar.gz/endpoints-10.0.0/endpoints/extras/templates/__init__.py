# -*- coding: utf-8 -*-

from .core import Templates
from .decorators import template

