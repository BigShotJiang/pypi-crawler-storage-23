# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2026-02-28

### Added
- Embeddings support: `LLMRotator.embed()` with full rotation, circuit breaker, and quota logic
- `EmbeddingResponse` and `EmbeddingUsage` types for embedding results
- `EmbeddingNotSupportedError` for providers without embedding API (e.g., Anthropic)
- `OpenAIClient.embed()` — OpenAI-compatible embedding endpoint
- `GeminiClient.embed()` — Google Gemini batch embedding endpoint
- `__version__` attribute via `importlib.metadata` for programmatic version access
- `CHANGELOG.md` with retroactive history

## [0.2.0] - 2026-02-27

### Added
- Tool calling support with unified OpenAI-compatible format and per-provider translation
- Structured logging with `RoutingTrace` — full routing chain in a single log line
- Quota warning system with callback and lifecycle hook when usage crosses threshold (default 80%)
- LangChain integration: `RotatorChatModel(BaseChatModel)` as optional drop-in for chains/agents
- `ToolCall` type for tool call responses
- Redis state backend (`RedisBackend`) for multi-instance deployments
- Anthropic Claude Messages API client
- JSON config loading with environment variable substitution (`RotatorConfig.from_json()`)
- E2E tests for live Anthropic API and tool calling

## [0.1.0] - 2026-02-26

### Added
- Initial release
- Core `LLMRotator` orchestrator with Model-First Chain of Responsibility
- Circuit breaker pattern for automatic failure detection and recovery
- Token and request quota management with daily UTC and rolling window resets
- `OpenAIClient` for OpenAI-compatible APIs (OpenAI, OpenRouter, Groq, etc.)
- `GeminiClient` for Google Gemini REST API
- `InMemoryBackend` state backend with injectable clock for testability
- Pydantic v2 configuration models
- Streaming support with mid-stream error recovery
- Tier ceiling routing with `RoutingContext`
- Lifecycle hooks protocol for extensibility
