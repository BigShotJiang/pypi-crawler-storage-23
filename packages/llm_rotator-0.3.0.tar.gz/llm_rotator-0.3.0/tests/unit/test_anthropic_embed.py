"""Unit tests for Anthropic client embed() — should raise EmbeddingNotSupportedError."""

from __future__ import annotations

import pytest

from llm_rotator.clients.anthropic import AnthropicClient
from llm_rotator.exceptions import EmbeddingNotSupportedError


class TestAnthropicEmbed:
    async def test_embed_raises_not_supported(self):
        client = AnthropicClient()
        with pytest.raises(EmbeddingNotSupportedError, match="AnthropicClient"):
            await client.embed(
                input=["test"],
                model="claude-3-haiku",
                api_key="sk-ant-1234",
            )

    async def test_embed_not_supported_has_provider(self):
        client = AnthropicClient()
        with pytest.raises(EmbeddingNotSupportedError) as exc_info:
            await client.embed(
                input=["test"],
                model="any-model",
                api_key="sk-ant-1234",
            )
        assert exc_info.value.provider == "AnthropicClient"
