"""
PyPI package placeholder (rename 'tvminer' to your package name).
Exposes Miner and predict_batch that delegate to the inference module.
"""

from pathlib import Path
from typing import List, Tuple

from numpy import ndarray
from pydantic import BaseModel

# Bundled extension in this package (tvminer/inference.*.so).
from . import inference  # type: ignore


class BoundingBox(BaseModel):
    x1: int
    y1: int
    x2: int
    y2: int
    cls_id: int
    conf: float


class TVFrameResult(BaseModel):
    frame_id: int
    boxes: List[BoundingBox]
    keypoints: List[Tuple[int, int]]


class Miner:
    """Client that loads the inference model and runs predict_batch."""

    def __init__(self, path_hf_repo: Path) -> None:
        self.inference = inference.load_model(path_hf_repo)

    def __repr__(self) -> str:
        return f"Miner(inference={self.inference})"

    def predict_batch(
        self,
        batch_images: List[ndarray],
        offset: int,
        n_keypoints: int,
    ) -> List[TVFrameResult]:
        return self.inference.predict_batch(batch_images, offset, n_keypoints)


def load_model(path_hf_repo: Path) -> Miner:
    """Load the inference model and return a Miner instance."""
    if not isinstance(path_hf_repo, Path):
        path_hf_repo = Path(path_hf_repo)
    return Miner(path_hf_repo)


__all__ = [
    "BoundingBox",
    "TVFrameResult",
    "Miner",
    "load_model",
]
