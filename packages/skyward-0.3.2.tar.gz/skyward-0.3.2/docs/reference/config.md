# Configuration

::: skyward.PoolSpec

::: skyward.Image

::: skyward.DEFAULT_IMAGE

::: skyward.AllocationStrategy

::: skyward.api.spec.PoolState
