
BASE_URL = "/api/v1"
DEFAULT_ROOT_DIR = "."
DEFAULT_INVENTORY_TYPE = "local"
NED_WHEEL_DIR = "packages/neds/"
