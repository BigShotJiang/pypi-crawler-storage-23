# License Apache 2.0: (c) 2026 Yoan Sallami (Synalinks Team)

"""Synalinks Memory CLI."""

from synalinks_memory_cli.version import __version__
