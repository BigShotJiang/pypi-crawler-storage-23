"""Shared types for the Tower Agent Profile SDK.

Mirrors the server-side enums so that SDK consumers get
typed constants without importing tower-agent internals.
"""

from __future__ import annotations

from enum import Enum


# ---------------------------------------------------------------------------
# Agent lifecycle
# ---------------------------------------------------------------------------

class AgentState(str, Enum):
    INITIALIZING = "initializing"
    LEARNING = "learning"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    ARCHIVED = "archived"


class ProfileTier(str, Enum):
    LIGHTWEIGHT = "lightweight"
    MULTI_PRODUCT = "multi_product"
    FULL_STACK = "full_stack"


# ---------------------------------------------------------------------------
# Suggestion system
# ---------------------------------------------------------------------------

class SuggestionType(str, Enum):
    REMINDER = "reminder"
    TASK_GUIDANCE = "task_guidance"
    OPTIMIZATION = "optimization"
    KNOWLEDGE = "knowledge"
    WELLBEING = "wellbeing"
    ESCALATION = "escalation"
    DRAFT = "draft"
    NUMA_SIGNAL = "numa_signal"
    GEC_INSIGHT = "gec_insight"
    GEC_ALERT = "gec_alert"
    GEC_ACHIEVEMENT = "gec_achievement"


class SuggestionStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    IGNORED = "ignored"


class FeedbackType(str, Enum):
    ACCEPT = "accept"
    REJECT = "reject"
    CORRECT = "correct"
    RATE = "rate"
    IGNORE = "ignore"


# ---------------------------------------------------------------------------
# Memory system
# ---------------------------------------------------------------------------

class MemoryType(str, Enum):
    LONG_TERM = "long_term"
    SHORT_TERM = "short_term"
    EPISODIC = "episodic"


# ---------------------------------------------------------------------------
# Scoring system
# ---------------------------------------------------------------------------

class ScoreType(str, Enum):
    TRUST = "trust"
    SKILL = "skill"
    EFFECTIVENESS = "effectiveness"
    PROFICIENCY = "proficiency"
    CONFIDENCE = "confidence"
    GEC_EFFICIENCY = "gec_efficiency"
    GEC_STABILITY = "gec_stability"


# ---------------------------------------------------------------------------
# Signal types (NUMA integration)
# ---------------------------------------------------------------------------

class SignalType(str, Enum):
    """Signal types emitted by NUMA and relayed through SBN."""
    GEC_HEALTH = "GEC_HEALTH"
    PRIORITY_SHIFT = "PRIORITY_SHIFT"
    GOVERNANCE_ALERT = "GOVERNANCE_ALERT"
    ESCALATION = "ESCALATION"
    FORECAST = "FORECAST"
    INSTRUCTION = "INSTRUCTION"
    META = "META"
    AUDIT = "AUDIT"


# ---------------------------------------------------------------------------
# SBN block types (server whitelist)
# ---------------------------------------------------------------------------

class SBNBlockType(str, Enum):
    """Valid block types accepted by the SBN seal endpoint."""
    EVENT = "event"
    STIMULUS = "stimulus"
    AUDIT = "audit"
    INSTRUCTION = "instruction"
    META = "meta"
