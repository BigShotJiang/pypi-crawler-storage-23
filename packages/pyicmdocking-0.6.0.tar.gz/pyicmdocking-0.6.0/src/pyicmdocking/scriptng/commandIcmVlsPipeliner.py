# =================================================================================
#    IcmDocking Pipeline
#    Copyright (C) 2024  Jordy Homing Lam, jhmlam, JHML. Ho Ming LAM. All rights reserved.
#
#    Acknowledgement 
#    * We would like to thank Ruben Abagyan, Eugene Raush and Maxim Totrov for writing the 
#      very powerful ICM program in Molsoft Ltd.
#    * We would like to thank Vsevolod Katritch for purchasing a license from Molsoft and teaching
#      us how to use the program correctly.
#    * JHML would like to thank Tessa Ferrari for testing this out together with me when we started on 
#      one of the docking projects that went to black hole
# 
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the Apache 2.0 License as published
#    by the Apache Foundation.
#
#    Redistribution and use in source and binary forms, with or without
#    modification, are permitted provided that the following conditions are
#    met:
#
#    * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation and/or 
#    other materials provided with the distribution.
#    * Cite our work at XXXXXXXXX
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    Apache License for more details.
# ==================================================================================



import subprocess


import tqdm


import glob
from importlib.resources import files, as_file


from pyicmdocking.scriptng.commandIcmSupporting import *



# =====================
# Instruction
# =====================
# Restrict the file name to alphanumeric only as filenames can be come pretty complicated ni later stages


# =====================
# I/O
# =====================



# ====================
# Body
# ====================


# TODO Give the short script encrouage to make a class istead IcmVlsPipeliner
class IcmPipeliner:
    def __init__(self,  DIR_Container = "", 
                        ICM_Rigid = True, 
                        ICM_Water = False,
                        n_replica = 1, 
                        Outputlabel = "MT1", 
                        DIR_ICM64 =  "/home/homingla/Software/icm-3.9-2e/icm64"):


            Supporting_MkdirList([DIR_Container])
            self.DIR_ICM64 = DIR_ICM64
            self.DIR_Container = DIR_Container
            self.ICM_Rigid = ICM_Rigid
            self.ICM_Water = ICM_Water

            self.n_replica = n_replica

            self.Templates_BasicDocking = (
                files("pyicmdocking.scriptng")
                .joinpath("Templates")
                .joinpath("BasicDocking")
            )

    def Prep_LigandUnspecified(self, DIR_RawSdfFolder = "", 
                               SdfSearchKey = "*.sdf", 
                               DIR_ProcessedSdfFolder = "", 
                               Outputlabel = "MT1"):


        Supporting_MkdirList([DIR_ProcessedSdfFolder])
        DIR_RawSdfList = sorted(glob.glob('%s/%s' %(DIR_RawSdfFolder, SdfSearchKey)))
        #print(DIR_RawSdfList, DIR_RawSdfFolder, SdfSearchKey)

        for sdffile in tqdm.tqdm(DIR_RawSdfList):
            sdfname = sdffile.split("/")[-1].split(".sdf")[0]

            with self.Templates_BasicDocking.joinpath("IcmLigandPrepUnspecified.icm").open("r", encoding="utf-8") as f:
                filedata = f.read()
            
            icmmacrofolder = str(self.DIR_ICM64)
            icmmacrofolder = icmmacrofolder.replace("icm64", "")
            filedata = filedata.replace('REPLACE_DIRICM64', '%s' %(icmmacrofolder))

            filedata = filedata.replace('REPLACE_RAWSDFFOLDER', '%s' %(DIR_RawSdfFolder))
            filedata = filedata.replace('REPLACE_SDFNAME', '%s' %(sdfname))
            filedata = filedata.replace('REPLACE_PROCESSEDSDFFOLDER', "%s" %(DIR_ProcessedSdfFolder))
            
            with open('%s/script_IcmLigandPrep_%s_%s.icm'%(DIR_ProcessedSdfFolder, Outputlabel, sdfname), 'w') as f:
                f.write(filedata)

            
            subprocess.call("%s %s/script_IcmLigandPrep_%s_%s.icm" %(self.DIR_ICM64, DIR_ProcessedSdfFolder, Outputlabel, sdfname),shell = True)
            # I decided not  to do conformation enumeration here
            #subprocess.call("icm ")

        return


    def Prep_MoltConfUnspecified(self, SdfSearchKey = "*.sdf", DIR_ProcessedSdfFolder = "", User_NumConf = 30):


        Supporting_MkdirList([DIR_ProcessedSdfFolder])
        DIR_IcmSdfList = sorted(glob.glob('%s/%s' %(DIR_ProcessedSdfFolder, SdfSearchKey)))
        #print(DIR_RawSdfList, DIR_RawSdfFolder, SdfSearchKey)

        for sdffile in tqdm.tqdm(DIR_IcmSdfList):
            sdfname = sdffile.split("/")[-1].split(".sdf")[0]
            
            subprocess.call("%s _confGen -f -c -r -A -C mnconf=%s %s/%s.sdf %s/%s.molt" %(
                            self.DIR_ICM64, User_NumConf, 
                            DIR_ProcessedSdfFolder, sdfname,
                            DIR_ProcessedSdfFolder, sdfname,
                            ),
                            shell = True)



        return




    def Prep_LigandSmiToSdf(self, 
                               SmiSearchKey = "*.smi",
                               User_numConf = 1,
                               DIR_RawSdfFolder = "", 
                               DIR_RawSmiFolder = ""):
        DIR_SmiList = sorted(glob.glob('%s/%s' %(DIR_RawSmiFolder, SmiSearchKey)))


        for smi in DIR_SmiList:
            sminame = smi.split("/")[-1].split(".")[0]
            subprocess.call("%s _confGen %s %s/Smi%s.sdf effort=5. -f mnconf=1 -q" %(self.DIR_ICM64, smi, DIR_RawSdfFolder, sminame.replace("_","")), shell = True)

        return
        

    def Prep_Ligand(self, DIR_RawSdfFolder = "", SdfSearchKey = "*.sdf", DIR_ProcessedSdfFolder = "", Outputlabel = "MT1"):


        Supporting_MkdirList([DIR_ProcessedSdfFolder])
        DIR_RawSdfList = sorted(glob.glob('%s/%s' %(DIR_RawSdfFolder, SdfSearchKey)))
        #print(DIR_RawSdfList, DIR_RawSdfFolder, SdfSearchKey)

        for sdffile in tqdm.tqdm(DIR_RawSdfList):
            sdfname = sdffile.split("/")[-1].split(".sdf")[0]

            with self.Templates_BasicDocking.joinpath("IcmLigandPrep.icm").open("r", encoding="utf-8") as f:
                filedata = f.read()

            
            icmmacrofolder = str(self.DIR_ICM64)
            icmmacrofolder = icmmacrofolder.replace("icm64", "")
            filedata = filedata.replace('REPLACE_DIRICM64', '%s' %(icmmacrofolder))

            filedata = filedata.replace('REPLACE_RAWSDFFOLDER', '%s' %(DIR_RawSdfFolder))
            filedata = filedata.replace('REPLACE_SDFNAME', '%s' %(sdfname))
            filedata = filedata.replace('REPLACE_PROCESSEDSDFFOLDER', "%s" %(DIR_ProcessedSdfFolder))
            
            with open('%s/script_IcmLigandPrep_%s_%s.icm'%(DIR_ProcessedSdfFolder, Outputlabel, sdfname), 'w') as f:
                f.write(filedata)

            # TODO Any chance to make this multiprocessing (queued for single thread. is this thread safe?)
            subprocess.call("%s %s/script_IcmLigandPrep_%s_%s.icm" %(self.DIR_ICM64, DIR_ProcessedSdfFolder, Outputlabel, sdfname),shell = True)
            # I decided not  to do conformation enumeration
            #subprocess.call("icm ")

        return


    def Prep_Receptor(self,DIR_RawPdbFolder = "", 
                      PdbSearchKey = "*.pdb", 
                      DIR_ProcessedPdbFolder = "", 
                      Outputlabel = "MT1"):
        # NOTE You will need to inspect the output icb. This script only support till mesh and it will ask for prompt in deciding which mesh you want it as the receptor's box
        Supporting_MkdirList([DIR_ProcessedPdbFolder])
        DIR_RawPdbList = sorted(glob.glob('%s/%s' %(DIR_RawPdbFolder, PdbSearchKey)))



        for pdbfile in tqdm.tqdm(DIR_RawPdbList):

            #TODO water and no water Auto.
            for w in [True, False] :    

                if w:
                    keepwater = 3
                else:
                    keepwater = 1



                pdbname = pdbfile.split("/")[-1].split(".pdb")[0]
                print(pdbname)


                with self.Templates_BasicDocking.joinpath("IcmPrepReceptor.icm").open("r", encoding="utf-8") as f :
                    filedata = f.read()
                icmmacrofolder = str(self.DIR_ICM64)
                icmmacrofolder = icmmacrofolder.replace("icm64", "")
                filedata = filedata.replace('REPLACE_DIRICM64', '%s' %(icmmacrofolder))
                filedata = filedata.replace('REPLACE_RAWPDBFOLDER', '%s' %(DIR_RawPdbFolder))
                filedata = filedata.replace('REPLACE_PDBNAME', '%s' %(pdbname))
                filedata = filedata.replace('REPLACE_PROCESSEDPDBFOLDER', "%s" %(DIR_ProcessedPdbFolder))
                filedata = filedata.replace('REPLACE_KEEPWATER', "%s" %(keepwater))
                filedata = filedata.replace('REPLACE_OUTPUTLABEL', "%s" %(Outputlabel))
                filedata = filedata.replace('REPLACE_RIGIDWATERLABEL', "%s" %("R%s_W%s" %(int(self.ICM_Rigid == True), int(w == True))))
                with open('%s/script_IcmPrepReceptor_%s_%s_R%s_W%s.icm'%(DIR_ProcessedPdbFolder, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), 'w') as f:
                        f.write(filedata)

                subprocess.call("%s -g %s/script_IcmPrepReceptor_%s_%s_R%s_W%s.icm" %(self.DIR_ICM64, DIR_ProcessedPdbFolder, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)),shell = True)
                print("==============================================================================")
                print("IMPORTANT. G Pocket not created. Run the following lines in GUI. ")
                print("================================================================================")
                
                print("icmPocketFinder a_%sRECEPTOR. & a_*.!H,W 4.6 yes yes yes"%(pdbname))
                print("""s_out = "%s/PrepReceptor_%s_%s_R%s_W%s.icb" """ %(DIR_ProcessedPdbFolder, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)))
                print("""writeProject s_out s_currentProject!="" """)

                subprocess.call("%s -g %s/PrepReceptor_%s_%s_R%s_W%s.icb" %(self.DIR_ICM64, DIR_ProcessedPdbFolder, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), shell = True)



    def Prep_ReceptorUnspecified(self,
                     User_mol2name = 'crystalligand',
                    DIR_RawPdbFolder = "", PdbSearchKey = "*.pdb", 
                    DIR_ProcessedPdbFolder = "", Outputlabel = "MT1",
                    User_KeepHetatm = True):
        # NOTE You will need to inspect the output icb. This script only support till mesh and it will ask for prompt in deciding which mesh you want it as the receptor's box
        Supporting_MkdirList([DIR_ProcessedPdbFolder])
        DIR_RawPdbList = sorted(glob.glob('%s/%s' %(DIR_RawPdbFolder, PdbSearchKey)))



        for pdbfile in tqdm.tqdm(DIR_RawPdbList):

            #TODO water and no water Auto.
            for w in [True, False] :    

                if w:
                    keepwater = 3
                else:
                    keepwater = 1



                pdbname = pdbfile.split("/")[-1].split(".pdb")[0]
                print(pdbname)

                with self.Templates_BasicDocking.joinpath("IcmPrepReceptorUnspecified.icm").open("r", encoding="utf-8") as f:
                    filedata = f.read()

                icmmacrofolder = str(self.DIR_ICM64)
                icmmacrofolder = icmmacrofolder.replace("icm64", "")
                filedata = filedata.replace('REPLACE_DIRICM64', '%s' %(icmmacrofolder))
                filedata = filedata.replace('REPLACE_RAWPDBFOLDER', '%s' %(DIR_RawPdbFolder))
                filedata = filedata.replace('REPLACE_CRYSTALMOL2NAME', '%s' %(User_mol2name))
                
                filedata = filedata.replace('REPLACE_PDBNAME', '%s' %(pdbname))
                filedata = filedata.replace('REPLACE_PROCESSEDPDBFOLDER', "%s" %(DIR_ProcessedPdbFolder))
                filedata = filedata.replace('REPLACE_KEEPWATER', "%s" %(keepwater))
                filedata = filedata.replace('REPLACE_OUTPUTLABEL', "%s" %(Outputlabel))
                filedata = filedata.replace('REPLACE_RIGIDWATERLABEL', "%s" %("R%s_W%s" %(int(self.ICM_Rigid == True), int(w == True))))
                if User_KeepHetatm & w:
                    filedata = filedata.replace('delete a_H', "")
                with open('%s/script_IcmPrepReceptor_%s_%s_R%s_W%s.icm'%(DIR_ProcessedPdbFolder, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), 'w') as f:
                        f.write(filedata)

                subprocess.call("%s -g %s/script_IcmPrepReceptor_%s_%s_R%s_W%s.icm" %(self.DIR_ICM64, DIR_ProcessedPdbFolder, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)),shell = True)
                



    def Prep_Map(self, IcbSearchKey = "*.icb", DIR_ProcessedPdbFolder = "", Outputlabel = "MT1", ChosenPocketDict = {"Mtr1aW1":2}):
        # NOTE You will need to inspect the output icb. This script only support till mesh and it will ask for prompt in deciding which mesh you want it as the receptor's box
        DIR_IcbList = sorted(glob.glob('%s/%s' %(DIR_ProcessedPdbFolder, IcbSearchKey)))


        for icbfile in tqdm.tqdm(DIR_IcbList):

        #for w in [True, False] :
            w = (icbfile.split("/")[-1].split(".icb")[0].split("_")[-1] == "W1")
            pdbname = icbfile.split("/")[-1].split(".icb")[0].split("_")[-3]
            print(pdbname)
            pocketid = ChosenPocketDict[pdbname]




            Supporting_MkdirList(["%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))])


            with self.Templates_BasicDocking.joinpath("IcmPrepMap.icm").open("r", encoding="utf-8") as f :
                filedata = f.read()

            #filedata = filedata.replace('REPLACE_RAWPDBFOLDER', '%s' %(DIR_RawPdbFolder))
            icmmacrofolder = str(self.DIR_ICM64)
            icmmacrofolder = icmmacrofolder.replace("icm64", "")
            filedata = filedata.replace('REPLACE_DIRICM64', '%s' %(icmmacrofolder))
            filedata = filedata.replace('REPLACE_PDBNAME', '%s' %(pdbname))
            filedata = filedata.replace('REPLACE_PROCESSEDPDBFOLDER', "%s" %(DIR_ProcessedPdbFolder))
            filedata = filedata.replace('REPLACE_OUTPUTLABEL', "%s" %(Outputlabel))
            filedata = filedata.replace('REPLACE_CONTAINER', "%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)))
            filedata = filedata.replace('REPLACE_POCKETINDEX', "%s" %(pocketid))
            filedata = filedata.replace('REPLACE_RIGIDWATERLABEL', "%s" %("R%s_W%s" %(int(self.ICM_Rigid == True), int(w))))

            with open('%s/script_IcmPrepMap.icm'%("%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))), 'w') as f:
                f.write(filedata)

            subprocess.call("%s -g %s/script_IcmPrepMap.icm" %(self.DIR_ICM64, "%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container,Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))),shell = True)
            print("===============================================================")
            print("IMPORTANT. Map not yet set up. Run the following lines in GUI. Note that g_pocket_* maybe replaced by a selected object (e.g. a peptide) using as_graph. In that case use Sphere( as_graph a_%sRECEPTOR. 3.2 ) & a_{projectname}RECEPTOR.")
            print("===============================================================")
            print("""set directory "%s" """ %("%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))))
            print("""dock2SetupReceptor "DOCK_%s" a_%sRECEPTOR. Sphere( g_pocket_%sRECEPTOR%s a_%sRECEPTOR. 3.2 ) yes no ? "enhancedBorn" : "none" """ %(pdbname, pdbname, pdbname, pocketid,pdbname))
            print("""N\nN\ncurrentDockProj.data[8] = "yes" """)
            print("""if( yes & currentDockProj.l_readyReceptor ) dock5CalcMaps "DOCK_%s" 0.5 4.0 no""" %(pdbname))
            
            print("""currentDockProj.data[1] = "DOCK_%s" """ %(pdbname))
            print("""dockSetScorePreferences currentDockProj.data[1] "2016" "Enhanced GB" no """)





            #print("currentDockProj.i_nProc = 28")
            #print("currentDockProj.i_nMCProc = 1")

            subprocess.call("%s -g %s/PrepMap_%s_%s_R%s_W%s.icb" %(self.DIR_ICM64, "%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container,Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), shell = True)




    def Prep_MapUnspecified(self, IcbSearchKey = "*.icb", DIR_ProcessedPdbFolder = "", Outputlabel = "MT1", ChosenPocketDict = {"Mtr1aW1":2}):
        # NOTE You will need to inspect the output icb. This script only support till mesh and it will ask for prompt in deciding which mesh you want it as the receptor's box
        DIR_IcbList = sorted(glob.glob('%s/%s' %(DIR_ProcessedPdbFolder, IcbSearchKey)))


        for icbfile in tqdm.tqdm(DIR_IcbList):

        #for w in [True, False] :
            w = (icbfile.split("/")[-1].split(".icb")[0].split("_")[-1] == "W1")
            pdbname = icbfile.split("/")[-1].split(".icb")[0].split("_")[-3]
            print(pdbname)
            pocketid = ChosenPocketDict[pdbname]




            Supporting_MkdirList(["%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))])

            with self.Templates_BasicDocking.joinpath("IcmPrepMapUnspecified.icm").open("r", encoding="utf-8") as f :
                filedata = f.read()

            #filedata = filedata.replace('REPLACE_RAWPDBFOLDER', '%s' %(DIR_RawPdbFolder))
            icmmacrofolder = str(self.DIR_ICM64)
            icmmacrofolder = icmmacrofolder.replace("icm64", "")
            filedata = filedata.replace('REPLACE_DIRICM64', '%s' %(icmmacrofolder))
            filedata = filedata.replace('REPLACE_PDBNAME', '%s' %(pdbname))
            filedata = filedata.replace('REPLACE_PROCESSEDPDBFOLDER', "%s" %(DIR_ProcessedPdbFolder))
            filedata = filedata.replace('REPLACE_OUTPUTLABEL', "%s" %(Outputlabel))
            filedata = filedata.replace('REPLACE_CONTAINER', "%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)))
            filedata = filedata.replace('REPLACE_POCKETINDEX', "%s" %(pocketid))
            filedata = filedata.replace('REPLACE_RIGIDWATERLABEL', "%s" %("R%s_W%s" %(int(self.ICM_Rigid == True), int(w))))

            with open('%s/script_IcmPrepMap.icm'%("%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))), 'w') as f:
                f.write(filedata)

            #subprocess.call("%s -g %s/script_IcmPrepMap.icm" %(self.DIR_ICM64, "%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container,Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))),shell = True)

            subprocess.call("echo -e '\n\n\n\n' | %s -g %s/script_IcmPrepMap.icm" %(self.DIR_ICM64, "%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container,Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))),shell = True)





    def Dock_PerSdf(self, DIR_ProcessedSdfFolder = "", 
                    SdfSearchKey = "LigInitEnum_*.sdf",
                    DIR_ProcessedPdbFolder = "", 
                    IcbSearchKey = "*.icb",  
                    Outputlabel = "MT1", n_effort = 30.0 , n_conformer = 10, n_processor = 28):

        print("=================================================")
        print("After this script. cd ../ResultXXX/ and bash the bash script there")
        print("===================================================")
        DIR_ProcessedSdfList = sorted(glob.glob('%s/%s' %(DIR_ProcessedSdfFolder, SdfSearchKey)))
        DIR_IcbList = sorted(glob.glob('%s/%s' %(DIR_ProcessedPdbFolder, IcbSearchKey)))


        # =================
        # Docking
        # =================
        write_line = []
        inspection_line = []

        for icbfile in DIR_IcbList:


            w = (icbfile.split("/")[-1].split(".icb")[0].split("_")[-1] == "W1")

            pdbname = icbfile.split("/")[-1].split(".icb")[0].split("_")[-3]
            print(pdbname)
            Receptor_Template_directory = "%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))
            Run_directory_prefix = Receptor_Template_directory.split("Template")[0]
            write_line.append('mkdir %s/Repository_%s_%s' %(self.DIR_Container, Outputlabel, pdbname))
            write_line.append('mkdir %s/Inspection_%s_%s' %(self.DIR_Container, Outputlabel, pdbname))

            Supporting_MkdirList(["%s/Repository_%s_%s" %(self.DIR_Container, Outputlabel, pdbname), "%s/Inspection_%s_%s" %(self.DIR_Container, Outputlabel, pdbname)])


            write_line.append('cp %s/%s_%s_R%s_W%s_Template/PrepMap_%s_%s_R%s_W%s.icb %s/Inspection_%s_%s/InspectDock_%s_%s_R%s_W%s.icb' %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w), Outputlabel, pdbname,int(self.ICM_Rigid == True), int(w), self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)))

            inspection_line.append("""show version \n call _macro _bioinfo _cheminfo _rebel _ligedit _docking \n read library \n read libraries \n call "%s/_cheminfo" \n read library \n read libraries \ns_tempDir = "/tmp" """ %(self.DIR_ICM64.split("/icm64")[0]))
            inspection_line.append("""openFile "%s" 0 yes no no no " append" """ %("%s/Inspection_%s_%s/InspectDock_%s_%s_R%s_W%s.icb" %(self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))))



            for sdffile in tqdm.tqdm(DIR_ProcessedSdfList):
            # if not .finished
                sdfname = sdffile.split("/")[-1].split(".sdf")[0]
                
                if sdfname.split("_")[0] != "LigInitEnum":

                    print("=============================================================")
                    print("Incorrect Set Up. You did not enumerate ligands. Aborted.")
                    print("=============================================================")
                    continue

                # Copy 
                Run_directory_suffix = sdfname.split("LigInitEnum_")[-1]
                Run_directory = Run_directory_prefix + Run_directory_suffix 
                Supporting_CopyAnything(Receptor_Template_directory, Run_directory)
                identifier = "%s_%s_R%s_W%s_%s"%(Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w), Run_directory_suffix)

                # Write to a run.sh
                write_line.append("cd %s" %(Run_directory))
                write_line.append("""  if [[ -f "./dock.finished" ]]""")
                write_line.append(  "  then")
                write_line.append("""      echo "%s finished" """ %(identifier))
                write_line.append(  "  else")
                # /scratch1/homingla/Icm392e/icmng -vlscluster _dockScan $ProjectName input=$inx_file effort=${effort_1} proc=${nproc} scoreCutoff=${ScoreThreshold} name=${inx_name} > ${SlurmJobName}_${ii}_${RunIndex}_${inx_name}.log
                #echo ${inx_name}
                #echo 'write index mol ''"'${sdfPath}/${inx_name}.sdf'"''"'${sdfPath}/${inx_name}.inx'"' >> icm_fixindex.icm
                #echo 'printf ''"'${inx_file}'\n"' >> icm_fixindex.icm
                #echo 'quit' >> icm_fixindex.icm
                #cp ../../../Script/Template/Icm/icm_fixindex.icm ./icm_fixindex_${inx_name}.icm #WorkingDir/EPOCH${EPOCH}/run${RunIndex}/
                #/scratch1/homingla/Icm392e/icmng  icm_fixindex_${inx_name}.icm > fixindex.log


                write_line.append("""      %s _dockScan "DOCK_%s" input="%s" -S confs=%s -s effort=%s name="answers_%s" proc=%s -a scoreCutoff=0.0 output="answers_%s.sdf" > log_%s.ou""" %(
                    self.DIR_ICM64,pdbname, sdffile, n_conformer, n_effort, identifier, n_processor, identifier, identifier))
                write_line.append(  "      cp answers_%s.sdf ../Repository_%s_%s/"%(identifier, Outputlabel, pdbname))
                write_line.append(  "      echo `date` > dock.finished")
                write_line.append(  "  fi")
                write_line.append("cd ..")


                # Write to a inspectrion icm and later sh
                inspection_line.append("""openFile "%s" 0 yes no no no " append" """ %("%s/Repository_%s_%s/answers_%s.sdf" %(self.DIR_Container, Outputlabel, pdbname, identifier)))
                inspection_line.append("""openFile "%s" 0 yes no no no " append" """ %("%s/LigInitRaw_%s.sdf" %(DIR_ProcessedSdfFolder, sdfname.split("_")[-1])))        
                inspection_line.append("""openFile "%s" 0 yes no no no " append" """ %("%s/LigInitEnum_%s.sdf" %(DIR_ProcessedSdfFolder, sdfname.split("_")[-1])))

                inspection_line.append("""make plot answers_%s "x=mol;y=Score;color=molPAINS;shape=nof_Chirals" """ %(identifier))

                inspection_line.append("""group answers_%s.mol  answers_%s.Score "min,Score" all "refmin,Score" name="answers_%s_Best" """ %(identifier,identifier,identifier))
                inspection_line.append("set property display answers_%s_Best" %(identifier))


                print("""makeMCStree Name( answers_%s_Best table) Field( Name( variable answers_%s_Best.IX ) 2 ".") yes"""%(identifier,identifier) )
                inspection_line.append("""make tree answers_%s_Best full "UPGMA" split="cl" """ %(identifier) + """ sstructure label="%NAME;" name="" ecfp """)
                inspection_line.append("sort answers_%s_Best.Score" %(identifier))



                # If dereived from chembl
                inspection_line.append("""add column answers_%s_Best Rarray(Nof(answers_%s_Best))  name="pAct"\n
        add column answers_%s_Best Iarray(Nof(answers_%s_Best))  name="confidence_score"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best), "")  name="bao_label"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best), "")  name="activity_comment"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best), "")  name="Uniprot_Accession"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best), "")  name="assay_type"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best))  name="target_chembl_id"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best))  name="assay_chembl_id"\n""" %(identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier))
                inspection_line.append("""add column answers_%s_Best Rarray(Nof(answers_%s_Best))  name="log10molWeight"\n""" %(identifier,identifier))
                inspection_line.append("""for i=1, Nof(answers_%s_Best)\n
        k = answers_%s_Best.idx_1[i]\n
        j = LigInitEnum_%s.IX[k]\n
        answers_%s_Best.pAct[i] = LigInitRaw_%s.pAct[j]\n
        answers_%s_Best.confidence_score[i] = LigInitRaw_%s.confidence_score[j]\n
        answers_%s_Best.bao_label[i] = LigInitRaw_%s.bao_label[j]\n
        answers_%s_Best.activity_comment[i] = LigInitRaw_%s.activity_comment[j]\n
        answers_%s_Best.Uniprot_Accession[i] = LigInitRaw_%s.Uniprot_Accession[j]\n
        answers_%s_Best.assay_type[i] = LigInitRaw_%s.assay_type[j]\n
        answers_%s_Best.target_chembl_id[i] = LigInitRaw_%s.target_chembl_id[j]\n
        answers_%s_Best.assay_chembl_id[i] = LigInitRaw_%s.assay_chembl_id[j]\n
        answers_%s_Best.log10molWeight[i] = Log(answers_%s_Best.molWeight[i])\n
        endfor\n""" %(identifier,identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier, identifier))

                inspection_line.append("""make plot answers_%s_Best "x=pAct;y=Score;color=molPAINS;shape=assay_chembl_id;size=confidence_score" name="Activity_Correspondence" """ %(identifier))
                inspection_line.append("""make plot answers_%s_Best "x=log10molWeight;y=Score;color=molPAINS;shape=assay_chembl_id;size=confidence_score" name="Virtual_LE" """ %(identifier))
                inspection_line.append("delete LigInitRaw_%s" %(identifier.split("_")[-1]))
                inspection_line.append("delete LigInitEnum_%s" %(identifier.split("_")[-1]))


        with open('%s/Run_%s_%s_R%s_W%s.sh' %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), 'w') as f:
            for item in write_line:
                f.write("%s\n" % item) 

        with open('%s/Inspection_%s_%s/script_Inspect_%s_%s_R%s_W%s.icm' %(self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), 'w') as f:
            for item in inspection_line:
                f.write("%s\n" % item)

            f.write("undisplay store a_%s.\n" %(pdbname))
            f.write("display ribbon  Mol( Res(a_*.//DD) )\n")
            f.write("undisplay wire Res(a_*.//DD)\n")
            #f.write("undisplay store g_pocket_%sRECEPTOR%s\n")
            f.write("""s_out = "%s/Inspection_%s_%s/InspectDock_%s_%s_R%s_W%s.icb"\n """ %(self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)))
            f.write("""writeProject s_out s_currentProject!=""\n """)
            f.write("quit")


        # =====================
        # Inspection
        # =====================
        with open('%s/Inspection_%s_%s/script_Inspect_%s_%s_R%s_W%s.sh' %(self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), 'w') as f:
            f.write("%s -g mymenus.gui %s/Inspection_%s_%s/script_Inspect_%s_%s_R%s_W%s.icm\n" %(self.DIR_ICM64, self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)))






    # NOTE THis is only a script to write script 
    def Dock_PerSdfUnspecified(self, DIR_ProcessedSdfFolder = "", 
                  SdfSearchKey = "LigInitEnum_*.sdf", # NOTE use these to restrictwhat you want to dock
                  DIR_ProcessedPdbFolder = "", 
                  IcbSearchKey = "*.icb",   # NOTE use these to restrictwhat you want to dock
                  User_OnCarc = False,
                  User_ScoreThreshold = 0.0,
                  Outputlabel = "MT1", n_effort = 2.0 , n_conformer = 10, n_processor = 28):

        #print("=================================================")
        #print("After this script. cd ../ResultXXX/ and bash the bash script there")
        #print("===================================================")
        DIR_ProcessedSdfList = sorted(glob.glob('%s/%s' %(DIR_ProcessedSdfFolder, SdfSearchKey)))
        DIR_IcbList = sorted(glob.glob('%s/%s' %(DIR_ProcessedPdbFolder, IcbSearchKey)))


        # =================
        # Docking
        # =================
        write_line = []
        inspection_line = []

        for icbfile in DIR_IcbList:


            w = (icbfile.split("/")[-1].split(".icb")[0].split("_")[-1] == "W1")

            pdbname = icbfile.split("/")[-1].split(".icb")[0].split("_")[-3]
            #print(pdbname)
            Receptor_Template_directory = "%s/%s_%s_R%s_W%s_Template" %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))
            Run_directory_prefix = Receptor_Template_directory.split("Template")[0]


            #write_line.append('mkdir %s/Repository_%s_%s' %(self.DIR_Container, Outputlabel, pdbname))
            #write_line.append('mkdir %s/Inspection_%s_%s' %(self.DIR_Container, Outputlabel, pdbname))

            write_line.append('mkdir %s/Repository_%s_%s' %("./", Outputlabel, pdbname))
            write_line.append('mkdir %s/Inspection_%s_%s' %("./", Outputlabel, pdbname))

            Supporting_MkdirList([
                 "%s/Repository_%s_%s" %(self.DIR_Container, Outputlabel, pdbname), 
                 "%s/Inspection_%s_%s" %(self.DIR_Container, Outputlabel, pdbname)])


            write_line.append('cp %s/%s_%s_R%s_W%s_Template/PrepMap_%s_%s_R%s_W%s.icb %s/Inspection_%s_%s/InspectDock_%s_%s_R%s_W%s.icb' %(
                 "./", Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w), Outputlabel, pdbname,int(self.ICM_Rigid == True), int(w), 
                 './', Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)))

            inspection_line.append("""show version \n call _macro _bioinfo _cheminfo _rebel _ligedit _docking \n read library \n read libraries \n call "%s/_cheminfo" \n read library \n read libraries \ns_tempDir = "/tmp" """ %(
                 self.DIR_ICM64.split("/icm64")[0]))
            inspection_line.append(
                 """openFile "%s" 0 yes no no no " append" """ %("%s/Inspection_%s_%s/InspectDock_%s_%s_R%s_W%s.icb" %(
                      './', Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w))))



            for sdffile in tqdm.tqdm(DIR_ProcessedSdfList):
            # if not .finished
                sdfname = sdffile.split("/")[-1].split(".sdf")[0]
                
                if sdfname.split("_")[0] != "LigInitEnum":

                    print("=============================================================")
                    print("Incorrect Set Up. You did not enumerate ligands. Aborted.")
                    print("=============================================================")
                    continue

                # Copy 
                Run_directory_suffix = sdfname.split("LigInitEnum_")[-1]
                Run_directory = Run_directory_prefix + Run_directory_suffix 
                Supporting_CopyAnything(Receptor_Template_directory, Run_directory)
                identifier = "%s_%s_R%s_W%s_%s"%(
                     Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w), Run_directory_suffix)

                # Write to a run.sh
                #print(Run_directory.split('/'))
                write_line.append("cd %s" %("./%s"%(Run_directory.split('/')[-1])) )#%(Run_directory))
                write_line.append("""  if [[ -f "./%s.finished" ]] && [[ -f "answers_%s.sdf" ]]""" %(identifier, identifier))
                write_line.append(  "  then")
                write_line.append("""      echo "%s finished" """ %(identifier))
                write_line.append(  "  else")
                # /scratch1/homingla/Icm392e/icmng -vlscluster _dockScan $ProjectName input=$inx_file effort=${effort_1} proc=${nproc} scoreCutoff=${ScoreThreshold} name=${inx_name} > ${SlurmJobName}_${ii}_${RunIndex}_${inx_name}.log
                #echo ${inx_name}
                #echo 'write index mol ''"'${sdfPath}/${inx_name}.sdf'"''"'${sdfPath}/${inx_name}.inx'"' >> icm_fixindex.icm
                #echo 'printf ''"'${inx_file}'\n"' >> icm_fixindex.icm
                #echo 'quit' >> icm_fixindex.icm
                #cp ../../../Script/Template/Icm/icm_fixindex.icm ./icm_fixindex_${inx_name}.icm #WorkingDir/EPOCH${EPOCH}/run${RunIndex}/
                #/scratch1/homingla/Icm392e/icmng  icm_fixindex_${inx_name}.icm > fixindex.log


                # /project/katritch_502/Icm392e//icmng -vlscluster _dockScan $ProjectName input=$inx_file effort=${effort_1} proc=${nproc} scoreCutoff=${ScoreThreshold} name=${inx_name} > ${SlurmJobName}_${ii}_${RunIndex}_${inx_name}.log
                # /usr/icm-3.9-3b/icmng64 -vlscluster _dockScan DOCK_receptor input=../../Icm_SDF/LigInitEnum_activesfinal.inx effort=2.0 proc=2 scoreCutoff=0.0 name=haha > haha.log
                #write_line.append("""      %s _dockScan "DOCK_%s" input="%s" -S confs=%s -s effort=%s name="answers_%s" proc=%s -a scoreCutoff=0.0 output="answers_%s.sdf" > log_%s.ou""" %(
                #    self.DIR_ICM64,pdbname, sdffile, n_conformer, n_effort, identifier, n_processor, identifier, identifier))

                # NOTE remark. -E : rescore all stack conformations, but save only the best one

                #if User_OnCarc:
                #    write_line.append("""      %s -vlscluster _dockScan -E "DOCK_%s" input="../../Icm_SDF/%s.inx" effort=%s scoreCutoff=%s name=%s output="answers_%s.sdf" > log_%s.log""" %(
                #    self.DIR_ICM64,pdbname, sdfname, n_effort, User_ScoreThreshold, sdfname, sdfname, sdfname))
                #else:
                write_line.append("""      %s -vlscluster _dockScan -E "DOCK_%s" input="../../Icm_SDF/%s.inx" effort=%s proc=%s scoreCutoff=%s name=%s output="answers_%s.sdf" > log_%s.log""" %(
                self.DIR_ICM64,pdbname, sdfname, n_effort, n_processor, User_ScoreThreshold, sdfname, sdfname, sdfname))
                write_line.append(  "      cp answers_%s.sdf ../Repository_%s_%s/"%(identifier, Outputlabel, pdbname))
                write_line.append(  "      echo `date` > %s.finished" %(identifier))
                write_line.append(  "  fi")
                write_line.append("cd ..")


                # Write to a inspectrion icm and later sh
                inspection_line.append("""openFile "%s" 0 yes no no no " append" """ %("%s/Repository_%s_%s/answers_%s.sdf" %(
                     self.DIR_Container, Outputlabel, pdbname, identifier)))
                inspection_line.append("""openFile "%s" 0 yes no no no " append" """ %("%s/LigInitRaw_%s.sdf" %(DIR_ProcessedSdfFolder, sdfname.split("_")[-1])))        
                inspection_line.append("""openFile "%s" 0 yes no no no " append" """ %("%s/LigInitEnum_%s.sdf" %(DIR_ProcessedSdfFolder, sdfname.split("_")[-1])))

                inspection_line.append("""make plot answers_%s "x=mol;y=Score;color=molPAINS;shape=nof_Chirals" """ %(identifier))

                inspection_line.append("""group answers_%s.mol  answers_%s.Score "min,Score" all "refmin,Score" name="answers_%s_Best" """ %(identifier,identifier,identifier))
                inspection_line.append("set property display answers_%s_Best" %(identifier))


                #print("""makeMCStree Name( answers_%s_Best table) Field( Name( variable answers_%s_Best.IX ) 2 ".") yes"""%(identifier,identifier) )
                inspection_line.append("""make tree answers_%s_Best full "UPGMA" split="cl" """ %(identifier) + """ sstructure label="%NAME;" name="" ecfp """)
                inspection_line.append("sort answers_%s_Best.Score" %(identifier))



                # If dereived from chembl
                inspection_line.append("""add column answers_%s_Best Rarray(Nof(answers_%s_Best))  name="pAct"\n
        add column answers_%s_Best Iarray(Nof(answers_%s_Best))  name="confidence_score"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best), "")  name="bao_label"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best), "")  name="activity_comment"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best), "")  name="Uniprot_Accession"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best), "")  name="assay_type"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best))  name="target_chembl_id"\n
        add column answers_%s_Best Sarray(Nof(answers_%s_Best))  name="assay_chembl_id"\n""" %(identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier,identifier))
                inspection_line.append("""add column answers_%s_Best Rarray(Nof(answers_%s_Best))  name="log10molWeight"\n""" %(identifier,identifier))
                inspection_line.append("""for i=1, Nof(answers_%s_Best)\n
        k = answers_%s_Best.idx_1[i]\n
        j = LigInitEnum_%s.IX[k]\n
        answers_%s_Best.pAct[i] = LigInitRaw_%s.pAct[j]\n
        answers_%s_Best.confidence_score[i] = LigInitRaw_%s.confidence_score[j]\n
        answers_%s_Best.bao_label[i] = LigInitRaw_%s.bao_label[j]\n
        answers_%s_Best.activity_comment[i] = LigInitRaw_%s.activity_comment[j]\n
        answers_%s_Best.Uniprot_Accession[i] = LigInitRaw_%s.Uniprot_Accession[j]\n
        answers_%s_Best.assay_type[i] = LigInitRaw_%s.assay_type[j]\n
        answers_%s_Best.target_chembl_id[i] = LigInitRaw_%s.target_chembl_id[j]\n
        answers_%s_Best.assay_chembl_id[i] = LigInitRaw_%s.assay_chembl_id[j]\n
        answers_%s_Best.log10molWeight[i] = Log(answers_%s_Best.molWeight[i])\n
        endfor\n""" %(identifier,identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier,identifier.split("_")[-1],identifier, identifier))

                inspection_line.append("""make plot answers_%s_Best "x=pAct;y=Score;color=molPAINS;shape=assay_chembl_id;size=confidence_score" name="Activity_Correspondence" """ %(identifier))
                inspection_line.append("""make plot answers_%s_Best "x=log10molWeight;y=Score;color=molPAINS;shape=assay_chembl_id;size=confidence_score" name="Virtual_LE" """ %(identifier))
                inspection_line.append("delete LigInitRaw_%s" %(identifier.split("_")[-1]))
                inspection_line.append("delete LigInitEnum_%s" %(identifier.split("_")[-1]))


        with open('%s/Run_%s_%s_R%s_W%s.sh' %(self.DIR_Container, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), 'w') as f:
                for item in write_line:
                    f.write("%s\n" % item) 

        with open('%s/Inspection_%s_%s/script_Inspect_%s_%s_R%s_W%s.icm' %(self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), 'w') as f:
                for item in inspection_line:
                    f.write("%s\n" % item)

                f.write("undisplay store a_%s.\n" %(pdbname))
                f.write("display ribbon  Mol( Res(a_*.//DD) )\n")
                f.write("undisplay wire Res(a_*.//DD)\n")
                #f.write("undisplay store g_pocket_%sRECEPTOR%s\n")
                f.write("""s_out = "%s/Inspection_%s_%s/InspectDock_%s_%s_R%s_W%s.icb"\n """ %(self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)))
                f.write("""writeProject s_out s_currentProject!=""\n """)
                f.write("quit")


        # =====================
        # Inspection
        # =====================
        with open('%s/Inspection_%s_%s/script_Inspect_%s_%s_R%s_W%s.sh' %(self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)), 'w') as f:
            f.write("%s -g mymenus.gui %s/Inspection_%s_%s/script_Inspect_%s_%s_R%s_W%s.icm\n" %(self.DIR_ICM64, self.DIR_Container, Outputlabel, pdbname, Outputlabel, pdbname, int(self.ICM_Rigid == True), int(w)))


    # Slurm Preparation
    # NOTE This should the slurm that execute the .sh. Complete with a deploy.sh



# =================================================================================
#    IcmDocking Pipeline
#    Copyright (C) 2024  Jordy Homing Lam, jhmlam, JHML. Ho Ming LAM. All rights reserved.
#
#    Acknowledgement 
#    * We would like to thank Ruben Abagyan, Eugene Raush and Maxim Totrov for writing the 
#      very powerful ICM program in Molsoft Ltd.
#    * We would like to thank Vsevolod Katritch for purchasing a license from Molsoft and teaching
#      us how to use the program correctly.
#    * JHML would like to thank Tessa Ferrari for testing this out when we started on 
#      one of the docking projects that went to black hole
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the Apache 2.0 License as published
#    by the Apache Foundation.
#
#    Redistribution and use in source and binary forms, with or without
#    modification, are permitted provided that the following conditions are
#    met:
#
#    * Redistributions of source code must retain the above copyright notice, 
#    this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright notice, 
#    this list of conditions and the following disclaimer in the documentation and/or 
#    other materials provided with the distribution.
#    * Cite our work at XXXXXXXXX
# 
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    Apache License for more details.
# ==================================================================================