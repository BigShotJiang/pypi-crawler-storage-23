from yta_editor_nodes_cpu.processor.video.waving_frame import WavingFrameVideoNodeProcessorCPU


__all__ = [
    'WavingFrameVideoNodeProcessorCPU'
]