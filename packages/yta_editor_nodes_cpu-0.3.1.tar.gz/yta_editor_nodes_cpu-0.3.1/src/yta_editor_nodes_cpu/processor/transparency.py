from yta_editor_nodes_cpu.processor.abstract import _NodeProcessorCPU, _NodeProcessorCoreCPU
from yta_editor_utils.texture import TextureUtils
from typing import Union

import numpy as np


class TransparencyNodeProcessorCPU(_NodeProcessorCPU):
    """
    The node to modify the transparency of an input
    by using the CPU.

    This class can be instantiated many different
    times with different parameters, but will always
    call the same `Singleton` node processor instance
    to process the `input`.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    
    def __init__(
        self
    ):
        super().__init__(
            node_processor = _TransparencyNodeProcessorCoreCPU()
        )

    def process(
        self,
        inputs: dict[str, np.ndarray],
        evaluation_context: 'EvaluationContext',
        output_size: Union[tuple[int, int], None],
        transparency: float = 1.0,
        **kwargs
    ) -> np.ndarray:
        """
        Process the `base_input` provided in the `inputs`
        parameter by using the node processor instance
        associated to this node, and return the output.
        """
        return self.node_processor.process(
            input = inputs['base_input'],
            output_size = output_size,
            transparency = transparency
        )
    
class _TransparencyNodeProcessorCoreCPU(_NodeProcessorCoreCPU):
    """
    *For internal use only*

    *Singleton class*

    Node processor to modify the transparency of
    the input by multiplying it by a transparency
    factor.

    Depending on the factor:
    - `transparency==1.0` = Completely transparent
    - `transparency==0.5` = Half transparent
    - `transparency==0.0` = Completely opaque
    """

    def process(
        self,
        input: np.ndarray,
        output_size: Union[tuple[int, int], None],
        transparency: float,
        **kwargs
    ):
        """
        The `input` must be `float32` and the output will
        be also `float32`.
        """
        # Ensure float32 [0, 1]
        source = TextureUtils.numpy_to_float32(input)

        # Copy to avoid mutating upstream buffers
        output = source.copy()

        # Apply transparency (alpha only)
        output[..., 3] *= (1.0 - transparency)

        # Clamp
        output = np.clip(output, 0.0, 1.0)

        return output