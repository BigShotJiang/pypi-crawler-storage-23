from yta_editor_nodes_common import _Node

import numpy as np


class _NodeCPU(_Node):
    """
    *For internal use only*
    
    *Abstract class*

    An abstract class to handle the mandatory and
    optional parameters that can be used in the node.
    """

    mandatory_inputs = []
    optional_inputs = []

    def _validate_inputs(
        self,
        inputs: dict[str, np.ndarray]
    ) -> None:
        return super()._validate_inputs(
            inputs = inputs,
            type = np.ndarray
        )