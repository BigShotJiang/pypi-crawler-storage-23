from oscar.apps.basket import apps


class BasketConfig(apps.BasketConfig):
    name = "sandbox.basket"
