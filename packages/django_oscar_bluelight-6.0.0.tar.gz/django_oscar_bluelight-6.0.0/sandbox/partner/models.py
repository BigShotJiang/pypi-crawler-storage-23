from oscar.apps.partner.models import *  # noqa
