from oscar.apps.dashboard.offers.models import *  # noqa
