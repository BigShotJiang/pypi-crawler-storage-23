from .results import OfferApplications  # NOQA
