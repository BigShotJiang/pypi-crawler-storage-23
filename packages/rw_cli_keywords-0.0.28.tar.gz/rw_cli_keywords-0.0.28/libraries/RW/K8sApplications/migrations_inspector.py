# determines migration library/tool and then fetches migration table info
