from .k8s_log import K8sLog

__version__ = "1.0.0" 