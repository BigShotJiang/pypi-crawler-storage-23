"""I/O helpers for reading/writing CSV and Parquet tabular data."""

from __future__ import annotations

import csv
from pathlib import Path

import pandas as pd

from .datetime_utils import ensure_utc_datetime
from .errors import ParquetUnavailableError


def _suffix(path: Path) -> str:
    """Return lowercase file suffix without leading dot."""
    return path.suffix.lower().lstrip(".")


def read_table(path: Path, *, nrows: int | None = None) -> pd.DataFrame:
    """Read CSV/Parquet input into a DataFrame with optional row limit."""
    suffix = _suffix(path)
    if suffix == "csv":
        return pd.read_csv(path, nrows=nrows)
    if suffix == "parquet":
        # Parquet doesn't support nrows directly in read_parquet but we can workaround or use pyarrow if needed
        # For now, let's just read and head if nrows is set, as parquet details are tricky
        # Actually pd.read_parquet doesn't support nrows. 
        # But we can use pyarrow dataset or just read all and head.
        # Given the request for performance, for parquet we might need a better way if files are huge.
        # But for now let's just read and head.
        df = pd.read_parquet(path)
        if nrows is not None:
            return df.head(nrows)
        return df
    raise ValueError(f"Unsupported input format: {path}")


def write_table(
    df: pd.DataFrame, path: Path, *, parquet_metadata: dict[bytes, bytes] | None = None
) -> None:
    """Write DataFrame to CSV/Parquet and optionally embed Parquet metadata."""
    suffix = _suffix(path)
    if suffix == "csv":
        # Ensure datetime columns are properly converted to UTC before formatting
        df_copy = df.copy()
        for col in df_copy.columns:
            if pd.api.types.is_datetime64_any_dtype(df_copy[col]):
                df_copy[col] = ensure_utc_datetime(df_copy[col])
        
        df_copy.to_csv(
            path,
            index=False,
            date_format="%Y-%m-%dT%H:%M:%SZ",
            quoting=csv.QUOTE_NONNUMERIC,  # quote strings/objects, not numbers
            quotechar='"',  # default
            doublequote=True,  # escape quotes by doubling them
            na_rep="",  # optional: how to write NaNs
        )
        return

    if suffix != "parquet":
        raise ValueError(f"Unsupported output format: {path}")

    # For parquet, we want to embed key/value metadata when available.
    if parquet_metadata:
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except Exception as e:  # pragma: no cover
            raise ParquetUnavailableError(
                "Parquet metadata embedding requires pyarrow. Install with: pip install -e \".[parquet]\""
            ) from e

        table = pa.Table.from_pandas(df, preserve_index=False)
        schema = table.schema
        merged = dict(schema.metadata or {})
        merged.update(parquet_metadata)
        table = table.cast(schema.with_metadata(merged))
        pq.write_table(table, path)
        return

    df.to_parquet(path, index=False)
