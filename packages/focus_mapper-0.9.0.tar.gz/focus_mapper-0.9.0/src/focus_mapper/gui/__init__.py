"""
Focus Mapper Desktop GUI
"""
