"""Bundled FOCUS v1.3 specification package."""
