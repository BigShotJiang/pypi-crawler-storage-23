"""Bundled FOCUS v1.2 specification package."""
