"""Bundled FOCUS v1.1 specification package."""
