"""LANlord – Terminal-based Network IP & Port Scanner."""

__version__ = "1.0.0"
