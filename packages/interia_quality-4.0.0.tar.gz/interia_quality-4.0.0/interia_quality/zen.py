
def zen():
    """
    Return a short InterIA-style “zen” text.

    This is a human-facing helper, not used in the core quality engine.
    """
    return """
InterIA Zen — Version 1.0

Clarity is structure.
Quality is respect.
Elegance is intelligence.
Precision is beauty.
Rigor is love.

Code is a mirror.
Write with intention.
"""
