# ⚡ InterIA Quality Pack v4 — Quickstart

<details><summary><b>🇫🇷 Français</b> — cliquer pour déployer</summary>

## 🇫🇷 Rapide

### ▶ 1. Lancer la qualité

```bash
make
```

Génère :

- `quality_report.json`
- `refactor_plan.json`
- `refactor_plan.md`

### ▶ 2. Générer la requête IA

```bash
make ai-request (ou make ai-prompt)
```

→ crée `ai_request.json` (à envoyer à ChatGPT/Claude/Gemini)

### ▶ 3. Prévisualiser les edits IA

```bash
make ai-preview
```

→ ouvre `ai_preview.html`

### ▶ 4. Appliquer les edits IA

```bash
make ai-apply
```

→ backups automatiques, modifications sûres

---

</details>

<details open><summary><b>🇬🇧 English</b> — click to collapse</summary>

## 🇬🇧 Quick

### ▶ 1. Run quality

```bash
make
```

### ▶ 2. Build AI request

```bash
make ai-request (or make ai-prompt)
```

### ▶ 3. Preview AI edits

```bash
make ai-preview
```

### ▶ 4. Apply edits

```bash
make ai-apply
```

---

Minimal, clean, safe.

</details>
