# AIV Toolkit


This repository contains common CI workflows for testing, packaging and releasing CTAO Computing subsystems.

Please refer to the [docs](http://cta-computing.gitlab-pages.cta-observatory.org/common/aiv-toolkit/latest/index.html) for more information.
