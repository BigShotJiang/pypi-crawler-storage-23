aivkit v4.0.0 (2026-01-29)
--------------------------


API Changes
~~~~~~~~~~~

- As part of the move to the common toolkit for DPPS and SUSS,
  the environment variable in CI ``DPPS_AIV_TOOLKIT_DIR`` has been changed
  to ``AIV_TOOLKIT_DIR`` and the default location is now ``$CI_PROJECT_DIR/aiv-toolkit``. [`!353 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/353>`__]

- Make the computing system configurable.   This change removes all hard-coded instances of "DPPS" from the code
  and introduces the new configuration variable ``AIV_SYSTEM``, which should   be set to ``DPPS`` or ``SUSS`` for the corresponding projects.

  Variables that started with ``DPPS_`` should be replaced by removing the
  ``DPPS_`` prefix. [`!357 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/357>`__]


New Features
~~~~~~~~~~~~

- Add a reusable job testing upgrade. [`!210 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/210>`__]

- Allow to read release plan from remote URL, reducing the number of submodules. [`!340 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/340>`__]

- Add a CLI command to build dev image. [`!340 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/340>`__]


- Publish the toolkit chart to harbor. This allows to install it to subsystems without accessing the git repository. [`!340 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/340>`__]

- Use pixi task to build documentation. [`!342 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/342>`__]

- Work without aiv-config.yml: needed when installing kit. [`!351 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/351>`__]

- Add ``aiv install`` command, installing or updating aiv toolkit into a repository. [`!351 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/351>`__]

- The toolkit now supports getting jama information via the new jama-gateway,  which allows read-only access to Jama's rest API using general credentials.
  To use it, configure the CI secrets ``JAMA_GATEWAY_USER`` and ``JAMA_GATEWAY_PASSWORD``,  ask the AIV team to get the necessary credentials. [`!356 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/356>`__]

- In the container build job, allow to override the default ``Dockerfile`` with ``AIV_DOCKERFILE`` variable. [`!367 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/367>`__]

- Install LFS in pypi publish job. This allows to compute version correctly in repositories using LFS. [`!368 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/368>`__]

- The CI pipeline now automatically detects the previous release tag and uses it by default for the k8s upgrade tests.   The detected tag can still be overridden by setting ``UPGRADE_BASE_REF``. [`!371 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/371>`__]


Maintenance
~~~~~~~~~~~

- Refactor config loading for aiv-deploy, allowing to load defaults from env variables and config.

  Adding additional mechanism for loading config motivated removing almost all default config values within Makefile. Makefile now serves only as a mechanism to establish dependencies between aiv-deploy CLI tasks. [`!340 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/340>`__]

- Remove all references and links to old sonar, which is now decommissioned. [`!343 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/343>`__]

aivkit v3.3.0 (2025-12-15)
--------------------------


API Changes
~~~~~~~~~~~

- Verify images used in the deployment to make sure they are pulled from harbor (with some exceptions). [`!293 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/293>`__]


Bug Fixes
~~~~~~~~~

- The error when project is not found in sonar is now more comprehensive. [`!332 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/332>`__]

- Fix CWL docker image hint patching for Workflows. Patching is now performed only for command line tools. [`!383 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/383>`__]


New Features
~~~~~~~~~~~~

- Allow to randomize release names, making sure that they are not explicitly assumed in the code, simplifying eventual integration and deployment. [`!329 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/329>`__]

- Add overview table of sonarqube quality gates. [`!318 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/318>`__]

- Automatically detect platform, allowing to support dev environment in Mac. [`!326 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/326>`__]

- Remove all test pods before upgrade. This allows to directly upgrade the deployment with failed tests. [`!321 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/321>`__]

- If job fails during first attempts but eventually succeeds, there failed pods are now removed, allowing to complete with clean successful deployment.
  Failed pods are reported as a warning. [`!332 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/332>`__]

- Retry pulling images to be resilient against temporary failures. [`!322 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/322>`__]

- Add an example GUI test with playwright. [`!323 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/323>`__]

- Add optional autocomplete for AIV-deploy. [`!327 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/327>`__]

- Switch dev test to python, preserving make interface. [`!327 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/327>`__]

- cert-generator grid now stores the hash-based alias symlinks for the ca certificate and the crl in the corresponding kubernetes secret. [`!331 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/331>`__]

- Add an option to the ci-docs step to install dependencies using ``pixi``.
  Set ``PYTHON_INSTALL_METHOD=pixi`` in your variables to use pixi instead of pip. [`!339 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/339>`__]


~~~~~~~~~~~~~~~~~~~~~~~~~~~~

aivkit v3.2.0 (2025-10-07)
--------------------------


Bug Fixes
~~~~~~~~~

- Fix sonarqube quality gate reporting raising a KeyError "actualValue" in some cases. [`!314 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/314>`__]


New Features
~~~~~~~~~~~~

- Update default DPPS release to v0.4.0 [`!313 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/313>`__]


aivkit v3.1.0 (2025-09-25)
--------------------------


API Changes
~~~~~~~~~~~

- Remove variable ``SONAR_HOST_URL`` from ``ci-sonar.yml``. Projects should
  set the host url in ``sonar-project.properties`` if they do not already do so. [`!248 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/248>`__]

- Introduce restriction on required python version above 3.12. [`!287 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/287>`__]

- List of UCs for given DPPS release can now be read from Jama. [`!289 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/289>`__]


Bug Fixes
~~~~~~~~~

- Fix a bug that if during report generation it is not possible to fetch sonar results, the resulting latex does not compile.
  Instead, it should compile and show an error. [`!288 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/288>`__]


New Features
~~~~~~~~~~~~

- Allow to specify CHART_VALUES environment variable specifying an alternative Helm chart values file.
  This feature can be used to test different deployment scenarios, for example lighter more focused ones. [`!256 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/256>`__]

- Add proxy registry definitions for quay.io and ghcr.io. [`!281 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/281>`__]

- Each DPPS AIV Toolkit version now contains an aligned version of DPPS release used for determining UCs and Requirements to verify.
  This version is used by default if no version is specified in subsystem's ``aiv-config.yaml``. [`!289 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/289>`__]

- "Revised" UC status is now set if a UC occurred in previous releases, not read directly from table. [`!289 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/289>`__]

- All requests with request library are now cached by default. This accelerates a lot repeated requests to Jama and GitLab.
  One should keep in mind that if remote state (e.g. gitlab job state) changes, local cache might need to be manually invalidated. [`!289 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/289>`__]

- Pipelines are now automatically cancelled when new commits are pushed to
  the same merge request. [`!298 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/298>`__]

- The toolkit now packages a chart before running helm upgrade,
  which enables overriding the chart's app version.
  This should make overriding the dev image tag unnecessary in pipelines. [`!299 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/299>`__]


DPPS AIV Toolkit v3.0.0 (2025-07-29)
------------------------------------


API Changes
~~~~~~~~~~~

- By default, the toolkit will no longer modify the user'
  global kubeconfig in ``$HOME/.kube/config`` but instead write
  the config to ``kubeconfig-<cluster-name>.yaml`` in the current directory.

  To interact with the cluster, directly set:

  .. code::

     $ export KUBECONFIG=$(pwd)/kubeconfig-<cluster-name>.yaml [`!254 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/254>`__]

- Remove hard-coded options for sonar-scanner in the ``ci-sonar.yml`` step.
  These options conflict with the new sonarqube server and are also better
  set in the per-project configuration either via CI variables or in the
  ``sonar-project.properties``.

  The following options are removed, and might need to be defined now in the
  project specific settings:

  * ``sonar.python.coverage.reportPaths='*/coverage.xml'``
  * ``sonar.language=python`` [`!257 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/257>`__]

- The toolkit now puts all the files it generates (downloaded binaries, logs, etc.)
  into a ``.toolkit`` directory instead of the local directory to avoid cluttering
  the base directory of the repository and make ignoring the files easier.

  Add ``.toolkit`` to your ``.gitignore``. [`!259 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/259>`__]


Bug Fixes
~~~~~~~~~

- Fix git-info step using an image not providing git and failing silently. [`!250 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/250>`__]

- Use ``GITLAB_TOKEN`` for changelog step in case it is defined.
  ``CI_JOB_TOKEN`` is missing permissions to query MRs. [`!265 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/265>`__]

- Links to MRs do not redirect anymore: fix to correct current repository. [`!277 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/277>`__]


New Features
~~~~~~~~~~~~

- Parse configured towncrier snippet names from the towncrier configuration
  in ``ci-changelog.yml`` instead of using a hardcoded list of types. [`!241 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/241>`__]

- Add DEV_DOCKER_EXTRA_ARGS args variable in command to build docker image,
  allowing subsystems to pass additional options to the docker build:
  ``DEV_DOCKER_EXTRA_ARGS=--build-arg DATAPIPE_VERSION=v0.2.1``. [`!253 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/253>`__]

- Allow to select custom helm repository list by setting ``HELM_REPO_CONFIG`` variable for the make. [`!260 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/260>`__]

- Add make target ``fetch-cluster-certs`` to download cluster certificates in ``.toolkit`` directory. These certificates can be used to access cluster services through proxy pass or ingress.
  This is an advanced developer feature and it is not by default advised to developers who do not realise its implications. [`!262 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/262>`__]

- Generate kind cluster configuration dynamically, based on new configuration variables (ENABLE_REGISTRY_MIRRORS, ENABLE_INGRESS, MOUNT_REPO).

  Refactor ``helm upgrade`` functionality, relying more on python and less on Makefile.
  To install controller before your application chart, add this rule to your application Makefile: ``install-chart: ingress-controller``. [`!266 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/266>`__]

- Simplify name of default kubeconfig, is now always just ``./.toolkit/kubeconfig.yaml``.
  This means you can ``export KUBECONFIG=.toolkit/kubeconfig.yaml`` and switch between directories
  of projects without having to change ``KUBECONFIG``. [`!269 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/269>`__]

- Support projects on multiple sonarqube servers.

  This also adds support for private projects or servers globally enforcing
  authentication by adding the option to get tokens from environment variables.

  Since the token is only valid for a specific server, the expected definition is:

  .. code::

     SONAR_API_TOKEN_1=sonar1.example.com,squ_asdsadsadsa
     SONAR_API_TOKEN_2=sonar2.example.com,squ_kjlkjkljkkj

  The tokens need to be "User" tokens, not "Project Analysis" tokens. [`!270 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/270>`__]

- Make the generated user certificates configurable. By default, generate 3 users. [`!273 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/273>`__]


Maintenance
~~~~~~~~~~~

- Update fluent-bit to 0.49.1 and get docker image from harbor. [`!244 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/244>`__]

- Added a note on toolkit configuration source. [`!260 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/260>`__]

- Improve quickstart and configuration docs. [`!274 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/274>`__]


Refactoring and Optimization
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- De-deduplicate images to be pulled by ``aiv-deploy kind-pull-images``. [`!245 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/245>`__]

DPPS AIV Toolkit v2.1.0 (2025-06-24)
------------------------------------


API Changes
~~~~~~~~~~~

- Use dpps-aiv-toolkit python module as part of the deployment process. It means that this module now has to be installed for local testing. [`!222 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/222>`__]

- Toolkit operations now rely on the toolkit python package. [`!225 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/225>`__]


Bug Fixes
~~~~~~~~~

- Fix ``k8s-integration-tests`` hanging in case of test failure
  until pipeline timeout is reached. [`!227 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/227>`__]


New Features
~~~~~~~~~~~~

- Detect, pull, and load to kind cluster all chart images: more controlled and faster startup. [`!222 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/222>`__]

- Derive name of local kind cluster from the directory in which it is started. This allows to run several local clusters at the same time, with different directories. [`!222 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/222>`__]

- Test job artifacts now include structured statistics about image pulls. [`!229 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/229>`__]

- Allow to override default kind config with KIND_CONFIG variable in aiv-config.yaml or from environment. [`!235 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/235>`__]

- If the unit test table is very long, summarize it instead of listing. [`!236 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/236>`__]


Maintenance
~~~~~~~~~~~

- Update kind to 0.29.0 . Security and performance upgrade. [`!221 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/221>`__]


DPPS AIV Toolkit v2.0.0 (2025-05-28)
------------------------------------


API Changes
~~~~~~~~~~~

- Add new job ``helm-lint`` for linting helm charts.
  This job is enabled by default for repositories containing
  a helm chart (if ``$CHART_LOCATION/Chart.yaml`` exists).

  This check might fail in case ``helm lint`` finds issues in the helm chart.
  In this case the pipeline will not pass until the issues are fixed or the job is disabled. [`!193 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/193>`__]

- Add kubeconform: a linter enforcing validity of k8s manifests.

  This can be a breaking change if the charts are not compliant! [`!203 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/203>`__]

- Disable any support for harbor pull secrets. All our images are public. [`!205 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/205>`__]


Bug Fixes
~~~~~~~~~


New Features
~~~~~~~~~~~~

- Add new CI job ``check-changelog`` that checks if a merge request contains
  a towncrier changelog snippet.
  The check is skipped if the project does not have the ``docs/changes`` directory
  or the MR is labelled with ``no-changelog-needed``. [`!191 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/191>`__]

- Add kube-linter. It's not totally stable, so not enforced.
  Also added kube-score. It's useful but too strict currently, not enforced. [`!203 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/203>`__]

- Freeze helm version in lint jobs [`!211 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/211>`__]


Maintenance
~~~~~~~~~~~


Refactoring and Optimization
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

DPPS AIV Toolkit v1.0.1 (2025-05-12)
------------------------------------


API Changes
~~~~~~~~~~~

- According to latest dev version of ICD Pipeline - WMS, docker hint for pipeline image is added to all CWL tools.
  Also, CWL is formatted with cwl-format to be more homogeneous. [`!150 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/150>`__]

- At this time, AIV_TOOLKIT_DIR variable should NOT be set to "dpps-aiv-toolkit".
  It should be set to full directory path, or it can be dropped completely. [`!181 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/181>`__]

- ``test`` job is not anymore the source of the artifacts.

  All jobs provided as dependencies for the ``collect-test-artifacts`` job will be merged into final test artifacts used in the test report.

  The test jobs in the dependencies should provide artifacts as ``DIR/report.xml`` where ``DIR`` is any directory name. ``DIR`` directory names should be different in different test jobs.


New Features
~~~~~~~~~~~~

- Read artifacts from other repositories, producing simple combined report.
  List "deployment UCs", demonstrated by pipeline passes. [`!44 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/44>`__]

- Allow to use in the report custom full application names. E.g. full name of "BDMS" is "DPPS BDMS". [`!71 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/71>`__]

- Collect logs with fluetbit, allowing to:
  * steam logs to stdout as they come.
  * store all logs also for jobs which do not exist at the end of the execution.
  * inspect logs in the app to verify observability. [`!119 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/119>`__]

- Allow to configure log collection and streaming. [`!125 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/125>`__]

- Include UCs from previous releases, and add a column indicating if the UC is added, revised, or simply retested. [`!134 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/134>`__]

- Support linting and publishing of CWL files. [`!142 <https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/merge_requests/142>`__]

- Add a note about report build: the toolkit version and build time.


Refactoring and Optimization
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- Refactor autoreport argument generation to enable running all generators at once.
