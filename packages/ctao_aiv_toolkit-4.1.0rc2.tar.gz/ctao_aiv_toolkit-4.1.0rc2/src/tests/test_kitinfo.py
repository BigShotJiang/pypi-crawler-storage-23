import logging


def test_kitversion(config_dpps_reference):
    from aivkit.autoreport.generators import toolkitinfo

    latex_content = toolkitinfo.generate(config_dpps_reference)
    logging.info(latex_content)
