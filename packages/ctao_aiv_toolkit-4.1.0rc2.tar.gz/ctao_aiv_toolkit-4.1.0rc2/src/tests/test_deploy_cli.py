import re

import pytest

from tests.conftest import get_deploy_cli


def test_as_bool():
    from aivkit.deploy.cli import as_bool

    assert as_bool("true") is True
    assert as_bool("false") is False
    assert as_bool(True) is True
    assert as_bool(False) is False
    assert as_bool(" TRUE ") is True
    assert as_bool(" False ") is False

    with pytest.raises(ValueError, match="Cannot convert not-a-bool to boolean"):
        as_bool("not-a-bool")


def test_deploy_cli(capsys):
    with pytest.raises(SystemExit):
        get_deploy_cli()(["--help"])

    assert re.search(
        "--chart-location CHART_LOCATION\\s+Location of the Helm chart to upgrade. \\(default: charts/cert-generator-grid\\)",
        capsys.readouterr().out,
    )


def test_deploy_cli_var_override(capsys, monkeypatch):
    monkeypatch.setenv("CHART_LOCATION", "custom-chart-location")

    with pytest.raises(SystemExit):
        get_deploy_cli()(["--help"])

    assert re.search(
        "--chart-location CHART_LOCATION\\s+Location of the Helm chart to upgrade. \\(default: custom-chart-location\\)",
        capsys.readouterr().out,
    )


def test_deploy_cli_var_substitute(monkeypatch):
    monkeypatch.setenv("AIVKIT_DEPLOY_CLI_LOG_LEVEL", "DEBUG")
    monkeypatch.setenv("SOME_VAR", "custom-some-var-location")
    monkeypatch.setenv("CHART_LOCATION", "$SOME_VAR")

    args = get_deploy_cli()(["--just-print-args", "helm-upgrade"])

    assert args.chart_location == "custom-some-var-location"


def test_deploy_help_variables(monkeypatch, caplog):
    monkeypatch.setenv("AIVKIT_DEPLOY_CLI_LOG_LEVEL", "DEBUG")
    monkeypatch.setenv("SOME_VAR", "custom-some-var-location")
    monkeypatch.setenv("CHART_LOCATION", "$SOME_VAR")

    get_deploy_cli()(["help-variables"])

    assert re.search(
        "MOUNT_REPO.*?Mount the repository in the kind cluster",
        caplog.text,
    )
