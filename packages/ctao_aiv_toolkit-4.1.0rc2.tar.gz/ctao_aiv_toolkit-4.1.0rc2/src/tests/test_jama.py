import json
import logging
from functools import partial

import pytest

test_jama_project_id = 14  # CTAO Backyard project ID, where test setup is made


@pytest.fixture(scope="session")
def jama_session():
    """Fixture to create a session for the Jama API."""
    from aivkit.autoreport.jama.session import get_session

    return get_session()


@pytest.mark.jama
def test_get_projects(jama_session):
    """Test the print_projects function."""
    from aivkit.autoreport.jama.base import get_projects
    from aivkit.autoreport.jama.projects import list_projects

    projects = get_projects(jama_session)

    assert isinstance(projects, list)
    assert len(projects) > 0

    list_projects(jama_session)


@pytest.mark.jama
def test_get_tags(jama_session):
    """Test the tags function."""
    from aivkit.autoreport.jama.base import get_tags

    tags = get_tags(jama_session, test_jama_project_id)

    assert isinstance(tags, list)
    assert len(tags) > 0


@pytest.mark.jama
def test_get_all_tags(jama_session):
    """Test the get_all_tags function."""
    from aivkit.autoreport.jama.items import get_all_tags

    tags = get_all_tags(jama_session, test_jama_project_id)

    logging.info("Tags: %s", tags)

    assert isinstance(tags, list)
    assert len(tags) > 0


@pytest.mark.jama
@pytest.mark.parametrize(
    ("release_tag", "parent_id", "parent_name", "expected_count"),
    [
        ("DPPS 0.2", None, None, 16),
        ("DPPS 0.3", None, None, 4),
        ("DPPS 0.3", None, "Manage Data Products", 1),
    ],
)
def test_get_dpps_release_tag_items(
    jama_session, release_tag, parent_id, parent_name, expected_count
):
    from aivkit.autoreport.jama.items import (
        get_item_by_id,
        get_tagged_items,
        select_by_parent_id_or_name,
    )

    r = get_tagged_items(
        jama_session,
        test_jama_project_id,
        tag=release_tag,
        selector=partial(
            select_by_parent_id_or_name,
            jama_session,
            parent_name=parent_name,
            parent_id=parent_id,
        ),
    )

    for item in r:
        logging.info("Item: %s", json.dumps(item, indent=2))

    for item in r:
        logging.info(
            "%20s %20s %20s %s (%s: %s)",
            item["documentKey"],
            item["globalId"],
            item["fields"].get("legacy_id$76"),
            item["fields"]["name"],
            item["location"]["parent"]["item"],
            get_item_by_id(jama_session, item["location"]["parent"]["item"])["data"][
                "fields"
            ]["name"],
        )

    assert isinstance(r, list)
    assert len(r) == expected_count


@pytest.mark.jama
def test_one_and_only_one_item():
    """Test the one_and_only_one_item function."""

    from aivkit.autoreport.jama.items import one_and_only_one_item

    assert one_and_only_one_item([1], None) == 1

    assert one_and_only_one_item([0, 1], lambda x: x > 0) == 1

    with pytest.raises(ValueError, match="Expected one item, found 0 items."):
        one_and_only_one_item([], None)

    with pytest.raises(ValueError, match="Expected one item, found 2 items."):
        one_and_only_one_item([0, 1], None)

    with pytest.raises(ValueError, match="Expected one item, found 0 items."):
        one_and_only_one_item([0, 1], lambda x: x > 2)

    with pytest.raises(ValueError, match="Expected one item, found 2 items."):
        one_and_only_one_item([0, 1], lambda x: x > -1)


@pytest.mark.jama
def test_compute_subtree_path_names(jama_session):
    from aivkit.autoreport.jama.items import compute_subtree_path_names, get_item_by_id

    item = get_item_by_id(jama_session, 46905)["data"]

    subtree_names = compute_subtree_path_names(jama_session, item)

    assert subtree_names == [
        "Manage Computing",
        "Manage Storage and Computing Resources",
        "Process and Preserve Data",
        "DPPS Use Cases",
        "DPPS",
        "Computing",
        "Use Cases",
    ]
