import logging
import re

import pytest

from aivkit.autoreport.projectinfo import (
    load_artifacts,
    load_gitlab_name,
    load_gitlab_short_name,
)


def test_parse_tests_xml(config):
    from aivkit.autoreport.tests import parse_tests_xml

    tests = parse_tests_xml(config["test_report_xml_fn"])

    assert len(tests) == 9

    usecases = {
        "DPPS-UC-110-1.1.3": 1,
    }
    requirements = {
        "C-BDMS-0330": 1,
        "C-BDMS-0210": 1,
    }

    for uc_id, expected_count in usecases.items():
        assert len([t for t in tests if uc_id in t["usecase_ids"]]) == expected_count

    for req_id, expected_count in requirements.items():
        assert (
            len([t for t in tests if req_id in t["requirement_ids"]]) == expected_count
        )


def test_integration_tests(config):
    from aivkit.autoreport.generators import integration_tests

    latex_content = integration_tests.generate(config)

    logging.info(latex_content)

    assert len(re.findall(r"^.*&.*passed.?\}?", latex_content, re.MULTILINE)) == 2

    assert len(re.findall(r"^.*&.*missing.?\}?", latex_content, re.MULTILINE)) == 4
    assert len(re.findall(r"^.*&.*full.?\}?", latex_content, re.MULTILINE)) == 2


def test_traceability(config):
    from aivkit.autoreport.generators import traceability_matrix

    latex_content = traceability_matrix.generate(config)
    logging.info(latex_content)


def test_read_traceability_matrix(config):
    from aivkit.autoreport.generators.traceability_matrix import (
        read_traceability_matrix,
        reqs_for_uc,
    )

    df = read_traceability_matrix(config)

    assert len(df) == 665

    assert "DPPS-UC-110-1.1" in df["uc_id"].values
    assert "DPPS-UC-110-1.2" in df["uc_id"].values

    assert reqs_for_uc("DPPS-UC-110-1.1", df) == ["C-BDMS-0010"]
    assert reqs_for_uc("DPPS-UC-110-1.2", df) == ["C-BDMS-0330"]


def test_customization(config):
    from aivkit.autoreport.generators import customization

    latex_content = customization.generate(config)
    logging.info(latex_content)

    assert "ApplicationFullName}{DPPS test-kit}" in latex_content
    assert "ApplicationName}{test-kit}" in latex_content

    config_dpps_case = config.copy()
    expected_fullname = "Data Processing and Preservation System (DPPS)"
    config_dpps_case["application_name"] = "DPPS"
    config_dpps_case["application_full_name"] = expected_fullname

    latex_content = customization.generate(config_dpps_case)
    logging.info(latex_content)

    assert r"ComputingSystem}{DPPS}" in latex_content
    assert f"ApplicationFullName}}{{{expected_fullname}}}" in latex_content
    assert "ApplicationName}{DPPS}" in latex_content


@pytest.mark.jama
def test_integration_tests_remote():
    from aivkit.autoreport.deps import iterate_dependencies
    from aivkit.autoreport.generators import integration_tests
    from aivkit.autoreport.projectinfo import (
        load_remote_git_project_info,
    )
    from aivkit.autoreport.tests import collect_tests_xml

    config = {
        "gitlab_path": "cta-computing/dpps/dpps",
        "revision": "v0.4.0",
        "release_plan_from_jama": False,
        "ignore_ci_vars": True,
        "local": False,
    }

    load_remote_git_project_info(config)
    config["dependencies"] = iterate_dependencies(config)

    tests = collect_tests_xml(config)

    for test in tests:
        logging.debug(test)

    assert len(tests) == 663

    for t in tests:
        logging.info(t)

    latex_content = integration_tests.generate(config)

    logging.info(latex_content)

    # tests table
    assert len(re.findall(r"^.*passed\}?", latex_content, re.MULTILINE)) == 128

    # uc table
    assert len(re.findall(r"^.*full\}", latex_content, re.MULTILINE)) == 44
    assert len(re.findall(r"^.*missing\}", latex_content, re.MULTILINE)) == 0


def test_integration_tests_remote_only_sonar():
    from aivkit.autoreport.deps import iterate_dependencies
    from aivkit.autoreport.tests import collect_tests_xml

    config = {
        "gitlab_path": "cta-computing/dpps/dpps",
        "application_name": "dpps",
        "revision": "v0.4.0",
        "ref_name": "v0.4.0",
        "ignore_ci_vars": True,
        "local": False,
        "dependencies": [
            {
                "gitlab_path": "cta-computing/dpps/simpipe/simpipe",
                "revision": "main",
                "sonar_project_key": "cta-computing_dpps_simpipe_simpipe_AZVsTStjKfQtQkaMmqBj",
            },
        ],
    }

    load_artifacts(config)
    load_gitlab_name(config)
    load_gitlab_short_name(config)

    config["dependencies"] = iterate_dependencies(config)

    collect_tests_xml(config)


@pytest.mark.parametrize("unittest_table_max_length", [2, 50])
def test_unittests(config, unittest_table_max_length):
    from aivkit.autoreport.generators import unittests
    from aivkit.autoreport.tests import collect_tests_xml

    tests = collect_tests_xml(config)

    latex_content = unittests.generate_latex_content(tests, unittest_table_max_length)

    logging.info(latex_content)

    if len(tests) > unittest_table_max_length:
        assert re.search(r"Total Unit Tests: 5", latex_content, re.MULTILINE)
        assert re.search(
            r"more than 2 unit tests, so only a summary is provided.",
            latex_content,
            re.MULTILINE,
        )
    else:
        assert len(re.findall(r"^.*&.*passed.?\}?", latex_content, re.MULTILINE)) == 5
