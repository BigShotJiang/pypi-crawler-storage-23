import logging

import pytest
from packaging.version import InvalidVersion

from aivkit.autoreport.releaseplan import get_release_plan_uclist

test_jama_project_id = 14  # CTAO Backyard project ID, where test setup is made, may be different from the one used in test_jama.py


@pytest.mark.parametrize(
    (
        "dpps_release",
        "release_plan_from_jama",
        "dpps_uc_groups",
        "dpps_uc_subtree_name",
        "include_past",
        "expected_uc_count",
        "expected_revised_uc_count",
        "expected_current_uc_count",
    ),
    [
        ("v0.0.0", False, "ALL", None, True, 9, 0, 9),
        ("v0.0.0", False, "ALL", None, False, 9, 0, 9),
        ("v0.1.0", False, "ALL", None, True, 28, 2, 21),
        ("v0.1.0", False, "ALL", None, False, 21, 0, 21),
        ("v9.9.9", False, "ALL", None, False, 0, 0, 0),
        pytest.param(
            "v0.3.0",
            True,
            "ALL",
            "Manage Data Products",
            True,
            6,
            1,
            1,
            marks=pytest.mark.jama,
        ),
        pytest.param(
            "v0.2.0",
            True,
            "ALL",
            "Manage Computing",
            True,
            1,
            0,
            0,
            marks=pytest.mark.jama,
        ),
        pytest.param(
            "v0.3.0",
            True,
            "ALL",
            "Manage Data Products,Manage Computing",
            True,
            7,
            1,
            1,
            marks=pytest.mark.jama,
        ),
        pytest.param(
            "v0.3.0",
            True,
            "ALL",
            "Process and Preserve Data",
            True,
            42,
            3,
            4,
            marks=pytest.mark.jama,
        ),
    ],
)
def test_release_plan_ucs(
    dpps_release,
    release_plan_from_jama,
    dpps_uc_subtree_name,
    dpps_uc_groups,
    include_past,
    expected_uc_count,
    expected_revised_uc_count,
    expected_current_uc_count,
    dpps_release_plan_url,
):
    config = {
        "aiv_system": "DPPS",
        "release_plan_fn": dpps_release_plan_url,
        "release": dpps_release,
        "uc_groups": dpps_uc_groups,
        "uc_subtree_name": dpps_uc_subtree_name,
        "release_plan_from_jama": release_plan_from_jama,
        "jama_project_id": test_jama_project_id,
    }

    uclist = get_release_plan_uclist(config, include_past_releases=include_past)

    for uc in uclist:
        logging.info(
            "UC (Jama %10s) %20s %7s %7s in %30s: %s",
            uc.get("jama_id"),
            uc["id"],
            "Revised" if uc["is_revised"] else "",
            "Current" if uc["is_current_release"] else "",
            uc.get("dpps_releases", []),
            uc["name"],
        )

        assert uc["id"].strip() == uc["id"]

    assert len(uclist) == expected_uc_count
    assert len([uc for uc in uclist if uc["is_revised"]]) == expected_revised_uc_count
    assert (
        len([uc for uc in uclist if uc["is_current_release"]])
        == expected_current_uc_count
    )


def test_parse_release_plan(config):
    from aivkit.autoreport import releaseplan

    uclists = releaseplan.parse_release_plan(config)
    assert len(uclists["v0.0.0"]) == 9


def test_release_plan_selection_document(config):
    from aivkit.autoreport.releaseplan import get_release_plan_uclist

    config["release"] = "v0.0.0"
    config["uc_groups"] = "ALL"

    uclist = get_release_plan_uclist(config, include_past_releases=False)

    for uc in uclist:
        logging.info("UC %s %s", uc["id"], uc["name"])

    assert len(uclist) == 9


def test_jama_tag_format_conversion():
    # Jama tags are global for Jama, so they start with "DPPS " and may be different in other ways

    from aivkit.autoreport.releaseplan import jama_tag_to_release, release_to_jama_tag

    assert release_to_jama_tag("v0.2.0", "DPPS") == "DPPS 0.2"
    assert release_to_jama_tag("v0.2.1", "DPPS") == "DPPS 0.2"
    assert release_to_jama_tag("v1.0.0", "SUSS") == "SUSS 1.0"

    assert jama_tag_to_release("DPPS 0.2", "DPPS") == "v0.2.0"
    assert jama_tag_to_release("DPPS 1.0", "DPPS") == "v1.0.0"
    assert jama_tag_to_release("DPPS 0.2.1", "DPPS") == "v0.2.1"

    with pytest.raises(InvalidVersion):
        jama_tag_to_release("DPPS 1.0", "SUSS")
