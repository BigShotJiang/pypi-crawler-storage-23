import logging
import subprocess as sp
from pathlib import Path

import pytest
from ruamel.yaml import YAML

from aivkit.cli import main as aiv_cli_main
from aivkit.git import ctx_clone_computing_group_repo


def set_test_committer():
    """Set git committer info for tests."""
    sp.run(
        [
            "git",
            "config",
            "user.name",
            "Test Committer",
        ],
        check=True,
    )
    sp.run(
        ["git", "config", "user.email", "test@example.com"],
        check=True,
    )


def test_aivcli_no_args():
    """Test that the CLI raises SystemExit when no arguments are provided."""

    with pytest.raises(SystemExit) as excinfo:
        aiv_cli_main([])

    assert excinfo.value.code != 0  # Non-zero exit code indicates error


def check_toolkit_config():
    with open(".gitmodules") as f:
        gitmodules_content = f.read()
        logging.debug(".gitmodules content:\n%s", gitmodules_content)
        assert "aiv-toolkit" in gitmodules_content

    with open(".gitlab-ci.yml") as f:
        gitlab_ci_content = f.read()
        logging.debug(".gitlab-ci.yml content:\n%s", gitlab_ci_content)

        gitlab_ci_yaml = YAML().load(gitlab_ci_content)

        include_entries = gitlab_ci_yaml.get("include", [])
        toolkit_included = any(
            entry.get("project", "").endswith("/aiv-toolkit")
            for entry in include_entries
            if isinstance(entry, dict)
        )
        assert (
            toolkit_included
        ), "aiv-toolkit not found in .gitlab-ci.yml include entries"

        # make sure dpps-aiv-toolkit reference is removed
        for entry in include_entries:
            if isinstance(entry, dict):
                project = entry.get("project", "")
                assert (
                    "/dpps-aiv-toolkit" not in project
                ), "dpps-aiv-toolkit reference found in .gitlab-ci.yml include entries"

        # make sure to have one and only include one entry for aiv-config.yml
        aiv_config_includes = [
            entry for entry in include_entries if entry == "aiv-config.yml"
        ]

        assert (
            len(aiv_config_includes) == 1
        ), f"Expected exactly one include entry for aiv-config.yml, found {len(aiv_config_includes)}"


@pytest.mark.parametrize(
    ("repo", "rev"),
    [
        ("dpps/dpps", "v0.4.0-rc1"),
        ("suss/scienceportal/prototypes/ctao-data-explorer", "master"),
    ],
)
def test_aivcli_check_commit_changes(repo, rev):
    with ctx_clone_computing_group_repo(path_fragment=repo, revision=rev):
        set_test_committer()

        aiv_cli_main(["install", "--commit", "--update-toolkit", "main"])
        check_toolkit_config()

        sonar_config = Path("sonar-project.properties")
        if sonar_config.is_file():
            assert "dpps-aiv-toolkit" not in sonar_config.read_text()

        # check that running again does not make changes
        aiv_cli_main(["install", "--commit", "--update-toolkit", "main"])
        check_toolkit_config()

        # add pre-commit hook, using some older commit hash
        aiv_cli_main(
            [
                "add-hook",
                "--commit",
                "--version",
                "6c843e711550c550f2c6a938d246bc0bf534b9ad",
            ]
        )

        # run pre-commit to see that it works
        sp.run(["pre-commit", "install"], check=True)
        sp.run(
            ["pre-commit", "run", "--all-files"], check=False
        )  # may fail if there are issues
        sp.run(["pre-commit", "run", "--all-files"], check=True)  # should pass now
