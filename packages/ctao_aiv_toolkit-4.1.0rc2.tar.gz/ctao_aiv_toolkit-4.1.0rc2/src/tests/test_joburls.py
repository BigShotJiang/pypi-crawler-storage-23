from aivkit.autoreport.projectinfo import get_gitlab_job_info_for_ref


def test_joburls():
    assert (
        get_gitlab_job_info_for_ref(
            "cta-computing/dpps/dpps", "v0.4.0", "k8s-integration-tests"
        )["job_url"]
        == "https://gitlab.cta-observatory.org/cta-computing/dpps/dpps/-/jobs/518888"
    )
