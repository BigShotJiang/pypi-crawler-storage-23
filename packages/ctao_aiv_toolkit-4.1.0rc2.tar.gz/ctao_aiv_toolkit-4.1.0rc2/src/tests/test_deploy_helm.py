import io
import logging
from functools import partial
from pathlib import Path

import pytest
import yaml

from aivkit.deploy.helm import package_chart, wait_for_pods
from aivkit.deploy.images import preload_image
from aivkit.deploy.kind import kind_cluster as kind_cluster_original
from aivkit.deploy.tools import helm_bin
from aivkit.runcmd import run_subprocess_tracing_logging
from tests.conftest import get_deploy_cli

kind_cluster = partial(
    kind_cluster_original,
    preload_images=[
        "harbor.cta-observatory.org/proxy_cache/alpine:3.22.2",
        "harbor.cta-observatory.org/proxy_cache/alpine/kubectl:1.34.2",
    ],
)


test_allowed_image_prefixes = "harbor.cta-observatory.org/dpps,harbor.cta-observatory.org/proxy_cache,registry.k8s.io,docker.io/kindest"


@pytest.mark.usefixtures("_k8s_tools")
def test_helm_test(tmp_path, monkeypatch):
    deploy_cli = get_deploy_cli()

    kubeconfig = Path(".toolkit/kubeconfig.yaml").absolute()
    monkeypatch.setenv("KUBECONFIG", str(kubeconfig))

    with kind_cluster():
        logging.info("Kind cluster created for helm test")

        # here we install the test chart using pure Helm commands to test upgrade functionality separately
        upgrade_args = [
            helm_bin(),
            "--debug",
            "upgrade",
            "--install",
            "unit-test-helm",
            "test-chart",
        ]
        run_subprocess_tracing_logging(upgrade_args)

        wait_for_pods()

        args = [
            "--randomized-release-name=false",
            "helm-test",
            "--release-name=unit-test-helm",
            "--filter='*'",
            "--timeout=15m",
        ]

        deploy_cli(args)


@pytest.mark.usefixtures("_k8s_tools")
def test_helm_upgrade(tmp_path, monkeypatch):
    deploy_cli = get_deploy_cli()
    deploy_cli = partial(deploy_cli, configure_log=False)

    kubeconfig = Path(".toolkit/kubeconfig.yaml").absolute()
    monkeypatch.setenv("KUBECONFIG", str(kubeconfig))

    with kind_cluster():
        logging.info("Kind cluster created for helm upgrade")

        computed_values_file = tmp_path / "helm-debug.txt"
        args = [
            "--chart-location=test-chart",
            "helm-upgrade",
            "--release-name=unit-test-helm",
            f"--allowed-image-prefixes={test_allowed_image_prefixes}",
            "--upgrade-statistics-json=upgrade-statistics.json",
            f"--computed-values-file={computed_values_file}",
            "--analyse-upgrade-events",
        ]

        deploy_cli(args, configure_log=False)
        assert computed_values_file.is_file()
        assert computed_values_file.read_text().startswith("COMPUTED VALUES")


@pytest.mark.usefixtures("_k8s_tools")
def test_helm_install_failtest_upgrade(tmp_path, monkeypatch):
    deploy_cli = get_deploy_cli()

    deploy_cli = partial(deploy_cli, configure_log=False)

    kubeconfig = Path(".toolkit/kubeconfig.yaml").absolute()
    monkeypatch.setenv("KUBECONFIG", str(kubeconfig))

    with kind_cluster():
        logging.info("Kind cluster created for helm upgrade")

        computed_values_file = tmp_path / "helm-debug.txt"
        deploy_cli(
            [
                "--chart-location=test-chart",
                "helm-upgrade",
                "--release-name=unit-test-helm",
                "--upgrade-statistics-json=upgrade-statistics.json",
                f"--computed-values-file={computed_values_file}",
                "--analyse-upgrade-events",
                "--chart-extra-values=--set fail_test=false",
            ]
        )

        # run the test

        deploy_cli(
            [
                "helm-test",
                "--release-name=unit-test-helm",
            ]
        )

        # deploy with fail_test=true to make the test fail
        deploy_cli(
            [
                "--chart-location=test-chart",
                "helm-upgrade",
                "--release-name=unit-test-helm",
                "--upgrade-statistics-json=upgrade-statistics.json",
                f"--computed-values-file={computed_values_file}",
                "--analyse-upgrade-events",
                "--chart-extra-values=--set fail_test=true",
            ]
        )

        # run the test - it should fail
        with pytest.raises(SystemExit):
            deploy_cli(
                [
                    "helm-test",
                    "--release-name=unit-test-helm",
                    "--timeout=5s",
                ]
            )

        # deploy with fail_test=false to make the test pass
        deploy_cli(
            [
                "--chart-location=test-chart",
                "helm-upgrade",
                "--release-name=unit-test-helm",
                "--upgrade-statistics-json=upgrade-statistics.json",
                f"--computed-values-file={computed_values_file}",
                "--analyse-upgrade-events",
                "--chart-extra-values=--set fail_test=false",
            ]
        )

        # run the test - it should pass
        deploy_cli(
            [
                "helm-test",
                "--release-name=unit-test-helm",
            ]
        )


def test_generate_random_instance_names(tmp_path):
    deploy_cli = get_deploy_cli()

    output_file = tmp_path / "random-names.yaml"
    base_name = "testbase"

    def get_names(*args):
        deploy_cli(
            [
                "--base-name",
                base_name,
                "--instance-names-file",
                str(output_file),
            ]
            + list(args)
            + ["get-instance-name"],
        )
        return yaml.safe_load(output_file.read_text())

    names = get_names()
    assert names["release_name"].startswith(f"{base_name}-")

    # Run again without overwrite, should not change
    assert names == get_names()

    # Run again with overwrite, should change
    assert names != get_names("--overwrite-instance-names-file")


def test_generate_non_random_instance_names(tmp_path):
    deploy_cli = get_deploy_cli()

    output_file = tmp_path / "random-names.yaml"
    base_name = "testbase"

    def get_names(*args):
        deploy_cli(
            [
                "--base-name",
                base_name,
                "--instance-names-file",
                str(output_file),
                "--randomized-release-name=false",
            ]
            + list(args)
            + [
                "get-instance-name",
            ]
        )
        return yaml.safe_load(output_file.read_text())

    names = get_names()
    assert names["release_name"] == base_name

    # Run again without overwrite, should not change
    assert names == get_names()

    # Run again with overwrite, should also not change since not random
    assert names == get_names("--overwrite-instance-names-file")


@pytest.mark.usefixtures("_k8s_tools")
def test_helm_dev(tmp_path, monkeypatch):
    deploy_cli = get_deploy_cli()
    from aivkit.deploy.kind import kind_cluster

    deploy_cli = partial(deploy_cli, configure_log=False)

    kubeconfig = Path(".toolkit/kubeconfig.yaml").absolute()
    monkeypatch.setenv("KUBECONFIG", str(kubeconfig))

    with kind_cluster() as kind_cluster_name:
        logging.info("Kind cluster created for helm upgrade")

        preload_image(
            "harbor.cta-observatory.org/proxy_cache/bitnamilegacy/kubectl:latest",
            kind_cluster_name,
        )

        computed_values_file = tmp_path / "helm-debug.txt"

        deploy_cli(
            [
                "helm-upgrade",
                "--release-name=unit-test-helm",
                "--upgrade-statistics-json=upgrade-statistics.json",
                f"--computed-values-file={computed_values_file}",
                "--analyse-upgrade-events",
            ]
        )

        args = [
            "--chart-location=test-chart",
            "helm-dev",
            "--release-name=unit-test-helm",
            "--test-pod=unit-test-helm-test-pod",
            # for some reason the tty attached by kubectl can not be intercepted by pytest's capsys, so we disable it here
            "--capture-stdin",
        ]

        monkeypatch.setattr("sys.stdin", io.StringIO("pwd\nexit\n"))
        deploy_cli(args, configure_log=False)


@pytest.mark.usefixtures("_k8s_tools")
def test_helm_upgrade_from_gitlab(tmp_path, monkeypatch):
    deploy_cli = get_deploy_cli()

    kubeconfig = Path(".toolkit/kubeconfig.yaml").absolute()
    monkeypatch.setenv("KUBECONFIG", str(kubeconfig))

    with kind_cluster():
        logging.info("Kind cluster created for helm upgrade")

        args = [
            "--chart-location=https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit:main",
            "helm-upgrade",
            "--release-name=dpps",
        ]

        deploy_cli(args)


@pytest.mark.parametrize(
    "add_symlink", [True, False], ids=["with-symlink", "without-symlink"]
)
def test_package_chart(tmp_path, add_symlink):
    """Test that the chart can be packaged without errors and the output file is created."""

    chart_path = tmp_path / "mock-chart"

    run_subprocess_tracing_logging(
        [
            "helm",
            "create",
            str(chart_path),
        ]
    )

    if add_symlink:
        # Add a symlink to test that it is handled correctly
        (chart_path / "symlink").symlink_to(chart_path / "templates")

    destination = tmp_path / "output"
    destination.mkdir(exist_ok=True)

    chart_package = Path(
        package_chart(
            chart_location=str(chart_path), app_version="0.1.0", destination=destination
        )
    )
    assert chart_package.is_file()

    assert chart_package.name == "mock-chart-0.1.0.tgz"
