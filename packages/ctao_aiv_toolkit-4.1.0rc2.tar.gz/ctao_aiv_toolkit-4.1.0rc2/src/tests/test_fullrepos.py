import logging
import os
import pathlib
import re
import shutil
import subprocess
from pathlib import Path

import pytest

from aivkit.git import ctx_clone_dpps_group_repo
from aivkit.gitlab import (
    get_artifact_file,
    get_test_artifacts,
)

aiv_full_test_repos = os.getenv("AIV_FULL_TEST_REPOS")
release_plan_subpath = (
    "dpps-release-plan/release_development_document/dpps-release-plan.tex"
)


def gitlab_path_from_dpps_fragment(dpps_fragment):
    return f"cta-computing/dpps/{dpps_fragment}"


def copy_path(src, dst):
    """Copies src to dst, works for src being a directory and a file"""
    src = pathlib.Path(src)
    if src.is_file():
        shutil.copy(src, dst)
    elif src.is_dir():
        shutil.copytree(src, dst)
    else:
        raise ValueError("src must be a file or a directory.")


@pytest.mark.parametrize(
    "repo_at_rev", [] if aiv_full_test_repos is None else aiv_full_test_repos.split(",")
)
def test_full_dpps(repo_at_rev, dpps_release_plan):
    try:
        repo_subpath, revision = repo_at_rev.split("@")
    except Exception:
        raise ValueError(f"Invalid repo@rev: {repo_at_rev}")

    testdir = pathlib.Path.cwd()

    with ctx_clone_dpps_group_repo(repo_subpath, revision) as tmpdir_str:
        tmpdir = pathlib.Path(tmpdir_str)

        # TODO: this is incomplete
        subprocess.check_call(["git", "submodule", "update", "--init", "--recursive"])

        toolkit_dir = tmpdir / Path("aiv-toolkit")
        # old repo using dpps-aiv-toolkit
        if not toolkit_dir.exists():
            toolkit_dir = tmpdir / Path("dpps-aiv-toolkit")
        assert toolkit_dir.exists()

        shutil.move(toolkit_dir, toolkit_dir.with_name(toolkit_dir.name + "_moved"))
        subprocess.check_call(
            [
                "rsync",
                "-avu",
                "--exclude=.git",
                f"{testdir}/",
                "--exclude=build",
                f"{toolkit_dir}/",
            ]
        )

        # copy release plan to expected location
        release_plan = toolkit_dir / release_plan_subpath
        release_plan.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(dpps_release_plan, release_plan)

        # copy job artifacts TODO: make this an option in normal flow
        for k, v in get_test_artifacts(
            gitlab_path_from_dpps_fragment(repo_subpath),
            revision,
        ).items():
            copy_path(v["fn"], tmpdir / k)

        pylint_artifacts = get_artifact_file(
            gitlab_path_from_dpps_fragment(repo_subpath), revision, "pylint"
        )

        if pylint_artifacts:
            for k, v in pylint_artifacts.items():
                copy_path(v["fn"], tmpdir / k)
        else:
            logging.warning(
                "No pylint artifacts found, this is expected for some repos"
            )
            with open(tmpdir / "pylint.json", "w") as f:
                f.write("{}")

        env = os.environ.copy()
        # make sure python uses dev toolkit
        env["PYTHONPATH"] = str(toolkit_dir / "src")

        # toolkit config
        env["TEST_ARTIFACTS_PATH"] = str(tmpdir)
        env["AIV_TOOLKIT_DIR"] = str(toolkit_dir)
        env["BASE_PROJECT_DIR"] = str(tmpdir)

        # gitlab-CI related variables
        env["CI_COMMIT_REF_NAME"] = revision
        env["CI_JOB_URL"] = "https://example.com"
        env["CI_JOB_ID"] = "99999"
        env.pop("CI_MERGE_REQUEST_IID", None)

        try:
            subprocess.check_call(
                ["make", "-C", str(toolkit_dir), "-B", "report"],
                env=env,
            )
        except subprocess.CalledProcessError as e:
            logging.error("Failed to build report: %s", e)
            raise

        shutil.copy(
            toolkit_dir / "report/build/test_report.pdf",
            testdir
            / f"test_report_{re.sub('[^0-9a-zA-Z]+', '_', repo_subpath)}_{revision}.pdf",
        )

        version_stub = re.sub("[^0-9a-zA-Z]+", "_", repo_subpath) + "_" + revision

        shutil.copy(
            toolkit_dir / "report/build/test_report.pdf",
            testdir / f"test_report_{version_stub}.pdf",
        )

        # this is useful for local testing
        subprocess.check_call(
            [
                "rsync",
                "-avu",
                f"{toolkit_dir}/report/build/",
                str(testdir / f"report-{version_stub}"),
            ]
        )

        with (toolkit_dir / "report/build/integration_tests.tex").open() as f:
            for line in f.readlines():
                logging.info(line)
