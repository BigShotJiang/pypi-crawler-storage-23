import json
import logging
import socket
from functools import partial
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread
from urllib.parse import urlparse

import pytest

from aivkit.autoreport.coderevision import colorize_project_version
from aivkit.autoreport.generators.sonarqube import get_sonar_tokens


def test_for_tag(config_dpps_reference):
    from aivkit.autoreport.generators import sonarqube

    name, latex_content, gate = sonarqube.generate_for_sonar_project(
        config_dpps_reference
    )
    assert name == "Data Processing and Preservation System"
    assert gate is True

    logging.info(latex_content)

    assert (
        "\\subsection{Project analysis: Data Processing and Preservation System (version \\textbf{\\color{orange}v0.4.0-rc1})}"
        in latex_content
    )


def test_for_tag_full(config_dpps_reference):
    from aivkit.autoreport.generators import sonarqube

    latex_content = sonarqube.generate(config_dpps_reference)

    logging.info(latex_content)

    assert (
        "\\subsection{Project analysis: Data Processing and Preservation System (version \\textbf{\\color{orange}v0.4.0-rc1})}"
        in latex_content
    )


def test_sonar_local():
    from aivkit.autoreport.generators import sonarqube
    from aivkit.autoreport.projectinfo import (
        load_aiv_config,
        load_local_git_project_info,
    )

    config = {"ignore_ci_vars": True, "local": True, "config_path": "aiv-config.yml"}

    load_aiv_config(config)
    load_local_git_project_info(config)

    # override ref so we are guaranteed that a sonarqube result exists
    config["ref_name"] = "main"
    # remove PR info in case we are on a PR
    config.pop("pull_request", None)

    name, latex_content, _ = sonarqube.generate_for_sonar_project(config)
    assert name == "DPPS AIV Toolkit"

    logging.info(latex_content)

    expected_version = colorize_project_version(config["application_version"])

    assert (
        "\\subsection{Project analysis: DPPS AIV Toolkit (version " + expected_version
        in latex_content
    )


def test_get_sonar_tokens(monkeypatch):
    from aivkit.autoreport.generators.sonarqube import get_sonar_tokens

    monkeypatch.setenv("SONAR_API_TOKEN_1", "test1.sonarqube.local,foo")
    monkeypatch.setenv("SONAR_API_TOKEN_2", "test2.sonarqube.local,bar")

    try:
        get_sonar_tokens.cache_clear()
        tokens = get_sonar_tokens()
    finally:
        get_sonar_tokens.cache_clear()

    assert tokens["test1.sonarqube.local"] == "foo"
    assert tokens["test2.sonarqube.local"] == "bar"


class SonarQubeDummy(BaseHTTPRequestHandler):
    def __init__(self, *args, version="9.9.6.123", **kwargs):
        self.version = version
        super().__init__(*args, **kwargs)

    def do_GET(self):  # noqa: N802
        path = urlparse(self.path).path

        body = ""
        if path == "/api/server/version":
            self.send_response(200)
            body = self.version
        elif path == "/api/metrics/search":
            auth = self.headers.get("Authorization")

            valid_auth = auth is not None and (
                (self.version.startswith("9.") and "Basic" in auth) or "Bearer" in auth
            )
            if valid_auth:
                self.send_response(200)
                body = json.dumps({"metrics": [{"key": "foo", "value": "bar"}]})
            else:
                self.send_response(401)
        else:
            self.send_error(404)

        self.end_headers()
        self.wfile.write(body.encode("utf-8"))


def get_free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("", 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]
    finally:
        s.close()


@pytest.fixture(scope="session", params=["9.9.6.123", "2025.3.1.109879"])
def sonarqube_mock_server(request):
    version = request.param

    port = get_free_port()
    handler_class = partial(SonarQubeDummy, version=version)

    server = HTTPServer(("localhost", port), handler_class)
    thread = Thread(target=server.serve_forever)

    with server:
        thread.start()
        yield f"http://localhost:{port}", version

        server.shutdown()
        thread.join()


def test_sonar_version(sonarqube_mock_server):
    from aivkit.autoreport.generators.sonarqube import get_sonar_server_version

    url, version = sonarqube_mock_server
    assert get_sonar_server_version(url) == version


def test_sonar_auth(sonarqube_mock_server, monkeypatch):
    from aivkit.autoreport.generators.sonarqube import get_available_metrics

    url, _ = sonarqube_mock_server

    get_sonar_tokens.cache_clear()
    monkeypatch.setenv("SONAR_API_TOKEN_TEST_UNUSED", "otherlocalhost,squ_1234")
    monkeypatch.setenv("SONAR_API_TOKEN_TEST", "localhost,squ_123")
    monkeypatch.setenv("SONAR_API_TOKEN_TEST_STILL_UNUSED", "otherlocalhost,squ_12345")

    metrics = get_available_metrics(url)
    assert metrics == {"foo": {"key": "foo", "value": "bar"}}
