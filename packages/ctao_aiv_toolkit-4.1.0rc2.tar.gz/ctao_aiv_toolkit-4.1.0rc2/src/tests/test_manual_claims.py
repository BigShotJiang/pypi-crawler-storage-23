import logging
import re

import pytest


@pytest.mark.parametrize(
    ("string_with_claims", "claims"),
    [
        (
            r"\\ManualTestCase{UC_ID}{uc_status}{uc_comment}",
            [
                {
                    "test_class": "manual",
                    "test_name": "manual",
                    "test_status": "uc_status",
                    "requirement_ids": [],
                    "usecase_ids": ["UC_ID"],
                    "comment": "uc_comment",
                }
            ],
        ),
        (
            r"\\ManualTestCase{UC_ID}{uc_status}{uc_comment}\n\\ManualTestCase{UC_ID_2}{uc_status}{uc_comment_2}\n",
            [
                {
                    "test_class": "manual",
                    "test_name": "manual",
                    "test_status": "uc_status",
                    "requirement_ids": [],
                    "usecase_ids": ["UC_ID"],
                    "comment": "uc_comment",
                },
                {
                    "test_class": "manual",
                    "test_name": "manual",
                    "test_status": "uc_status",
                    "requirement_ids": [],
                    "usecase_ids": ["UC_ID_2"],
                    "comment": "uc_comment_2",
                },
            ],
        ),
    ],
)
def test_manual_claims(string_with_claims, claims):
    from aivkit.autoreport.manual import extract_test_cases_from_text

    result = extract_test_cases_from_text(string_with_claims)

    assert len(result) == len(claims)

    logging.debug("Result: %s", result)

    for claim in claims:
        assert claim in result


def test_write_manual_claims(tmp_path):
    from aivkit.autoreport.manual import write_manual_report_xml
    from aivkit.autoreport.tests import parse_tests_xml

    manual_tests = [
        {
            "test_class": "manual",
            "test_name": "manual",
            "test_status": "uc_status",
            "requirement_ids": [],
            "usecase_ids": ["UC_ID"],
            "comment": "uc_comment",
        },
        {
            "test_class": "manual",
            "test_name": "manual",
            "test_status": "uc_status",
            "requirement_ids": [],
            "usecase_ids": ["UC_ID_2"],
            "comment": "uc_comment_2",
        },
        # this entry duplicates the one already in the report.xml, and should be ignored
        {
            "test_class": "src.bdms.tests.test_basic_rucio_functionality",
            "test_name": "test_replication",
            "test_status": "passed",
            "requirement_ids": [],
            "usecase_ids": [],
            "comment": "uc_comment_3",
        },
    ]

    report_xml = tmp_path / "report.xml"

    write_manual_report_xml(manual_tests, report_xml)

    tests_with_manual = parse_tests_xml(report_xml)

    assert len(tests_with_manual) == 3


def test_add_manual_claims(artifacts_dir, tmp_path, config):
    """Test both writing of manual claims and merging them with automated test report, resembing production process."""

    from aivkit.autoreport.junit import merge_junit
    from aivkit.autoreport.manual import write_manual_report_xml
    from aivkit.autoreport.tests import parse_tests_xml

    manual_tests = [
        {
            "test_class": "manual",
            "test_name": "manual",
            "test_status": "uc_status",
            "requirement_ids": [],
            "usecase_ids": ["DPPS-UC-110-1.1.1"],
            "comment": "uc_comment",
        },
        {
            "test_class": "manual",
            "test_name": "manual",
            "test_status": "uc_status",
            "requirement_ids": [],
            "usecase_ids": ["DPPS-UC-110-1.1.3"],
            "comment": "uc_comment_2",
        },
        # duplicated
        {
            "test_class": "manual",
            "test_name": "manual",
            "test_status": "uc_status",
            "requirement_ids": [],
            "usecase_ids": ["DPPS-UC-110-1.1.3"],
            "comment": "uc_comment_2",
        },
    ]

    report_xml = artifacts_dir / "report.xml"

    tests_without_manual = parse_tests_xml(report_xml)

    manual_report_xml = tmp_path / "manual-report.xml"

    write_manual_report_xml(manual_tests, manual_report_xml)

    tests_manual = parse_tests_xml(manual_report_xml)
    assert len(tests_manual) == 3

    merged_report_xml = tmp_path / "merged.xml"

    merge_junit([report_xml, manual_report_xml], merged_report_xml)

    tests_with_manual = parse_tests_xml(merged_report_xml)

    # one test less due to deduplication while merging
    assert len(tests_with_manual) == len(tests_without_manual) + 2

    # check that the manual test cases are in the merged report
    from aivkit.autoreport.generators import integration_tests

    config["release_plan_from_jama"] = False
    config["test_report_xml_fn"] = merged_report_xml
    latex_content = integration_tests.generate(config)

    logging.info(latex_content)

    assert len(re.findall(r"^.*&.*manual.?\}?", latex_content, re.MULTILINE)) == 2
