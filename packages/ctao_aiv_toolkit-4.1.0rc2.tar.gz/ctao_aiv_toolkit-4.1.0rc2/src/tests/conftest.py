import contextlib
import os
import pathlib
import subprocess as sp
import urllib
from functools import partial

import pytest
import requests_cache
from dotenv import load_dotenv

from aivkit.autoreport.projectinfo import load_local_git_project_info
from aivkit.deploy.cli import main as deploy_cli
from aivkit.deploy.kind import kind_bin
from aivkit.deploy.tools import find_bin
from aivkit.git import ctx_clone_dpps_group_repo
from aivkit.runcmd import run_subprocess_tracing_logging

load_dotenv()


def get_deploy_cli():
    """Get deploy CLI with logging disabled.

    This is to avoid interference with pytest's logging capture.
    """

    return partial(deploy_cli, configure_log=False)


@pytest.fixture(scope="session", autouse=True)
def _cache_all_requests():
    """Fixture to cache all requests in the session.
    Affects all tests in the session, but in particular Jama and GitLab requests.
    Accelerates tests in single run as well as in repeated local runs.

    Should be used with care, as it may lead to stale data in local tests.
    """

    requests_cache.install_cache(
        ".toolkit/requests_cache_tests", expire_after=3600, backend="filesystem"
    )


@pytest.fixture
def artifacts_dir() -> pathlib.Path:
    return pathlib.Path(__file__).parent.parent.parent / "test_files"


@pytest.fixture
def dpps_traceability_csv():
    return "https://gitlab.cta-observatory.org/cta-computing/dpps/dpps-project-management/requirements-traceability/-/raw/main/DPPS_Requirements_Traceability_Matrix.csv"


@pytest.fixture
def dpps_release_plan_url():
    return "https://gitlab.cta-observatory.org/cta-computing/dpps/dpps-project-management/dpps-release-plan/-/raw/main/release_development_document/dpps-release-plan.tex"


@pytest.fixture(scope="session")
def dpps_release_plan():
    """Pre-downloaded dpps release plan, needed for full release report tests using old versions of subsystems"""
    path = "dpps-project-management/dpps-release-plan"
    with ctx_clone_dpps_group_repo(
        path_fragment=path, revision="main", chdir=False
    ) as repo:
        yield f"{repo}/release_development_document/dpps-release-plan.tex"


@pytest.fixture
def config(artifacts_dir, dpps_release_plan_url, dpps_traceability_csv):
    return {
        "application_name": "test-kit",
        "application_author": "Test Author",
        "application_author_organization": "Test Organization",
        "traceability_csv_fn": dpps_traceability_csv,
        "release_plan_fn": dpps_release_plan_url,
        "release_plan_from_jama": False,
        "test_report_xml_fn": artifacts_dir / "report.xml",
        "test_report_xml_job_url": "report.xml",
        "aiv_system": "DPPS",
        "release": "v0.4.0",
        "uc_groups": "BDMS",
        "gitlab_path": "cta-computing/dpps/bdms/bdms",
        "ref_name": "v0.4.0",
    }


@pytest.fixture(scope="session")
def config_dpps_reference():
    config = {
        "gitlab_path": "cta-computing/dpps/dpps",
        "revision": "v0.4.0",
        "ignore_ci_vars": True,
    }

    with ctx_clone_dpps_group_repo(path_fragment="dpps", revision=config["revision"]):
        # delete tag part for released version, else local git describe will pick it up
        sp.run(
            [
                "git",
                "tag",
                "-d",
                "v0.4.0",
            ],
            check=True,
        )

        load_local_git_project_info(config)

        assert config["git_full_version"] == "v0.4.0-rc1"

    # TODO: this should be set on clone
    config["ref_name"] = config["revision"]

    return config


@pytest.fixture
def datapipe_example_cwl(tmp_path):
    fn = tmp_path / "process_dl0_dl1.cwl"
    url = "https://gitlab.cta-observatory.org/cta-computing/dpps/datapipe/datapipe/-/raw/v0.1.0-rc1/workflows/process_dl0_dl1.cwl"

    with open(fn, "wb") as f:
        f.write(urllib.request.urlopen(url).read())

    return fn


@pytest.fixture
def kind_cluster():
    """Fixture to create a kind cluster for testing."""

    from aivkit.deploy.kind import kind_cluster

    with context_k8s_tools():
        with kind_cluster() as kind_cluster_name:
            yield kind_cluster_name


@pytest.fixture(scope="session")
def helm():
    sp.run(["make", "./.toolkit/bin/helm"], check=True)
    return pathlib.Path("./.toolkit/bin/helm").absolute()


@contextlib.contextmanager
def context_k8s_tools():
    """Context manager to set up k8s tools environment."""
    vars_to_unset = []
    try:
        run_subprocess_tracing_logging(["make", "install-tools"])

        for tool in ["kind", "kubectl", "helm"]:
            env_name = tool.upper()
            if env_name not in os.environ:
                os.environ[env_name] = str(find_bin(tool))
                vars_to_unset.append(env_name)
        yield
    finally:
        for env_name in vars_to_unset:
            del os.environ[env_name]


@pytest.fixture(scope="session")
def _k8s_tools():
    with context_k8s_tools():
        yield


@pytest.fixture
def _clear_all_kind_clusters(_k8s_tools):
    """Fixture to delete all kind clusters before and after tests."""

    sp.run([kind_bin(), "delete", "clusters", "--all"], check=True)
    yield
    sp.run([kind_bin(), "delete", "clusters", "--all"], check=True)
