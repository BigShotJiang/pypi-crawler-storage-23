def test_path_from_gitlab_url():
    from aivkit.git import path_from_gitlab_url

    assert (
        path_from_gitlab_url(
            "https://gitlab.cta-observatory.org/cta-computing/dpps/dpps"
        )
        == "/cta-computing/dpps/dpps"
    )

    assert (
        path_from_gitlab_url("git@gitlab.cta-observatory.org:cta-computing/dpps/dpps")
        == "/cta-computing/dpps/dpps"
    )

    assert (
        path_from_gitlab_url(
            "https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit.git"
        )
        == "/cta-computing/common/aiv-toolkit"
    )
