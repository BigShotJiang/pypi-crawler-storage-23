"""Unit tests for the autoreport CLI."""

from aivkit.autoreport.cli import main


def test_autoreport_cli(monkeypatch):
    """Test the autoreport CLI main function."""

    monkeypatch.setenv("CI_COMMIT_REF_NAME", "main")
    monkeypatch.delenv("CI_MERGE_REQUEST_IID", raising=False)

    main(
        [
            "--config",
            "aiv-config.yml",
            "--cache-requests",
            "all",
            "test_files/coverage.xml",
            "test_files/report.xml",
            "test_files/pylint.json",
            "test_files/report.xml",
        ]
    )

    # test just one file selectively
    with open("unittests.tex") as f:
        content = f.read()
        assert (
            "test\\_basic\\_rucio\\_functionality & server\\_version & passed"
            in content
        )
