import shutil
from textwrap import dedent

import pytest
import yaml

new_test_image = "test_image:latest"


def get_patched_file_content(tmp_path, original_file_content, image):
    from aivkit.cwl import patch_image_in_file

    cwl_file_path = tmp_path / "test.cwl"

    # Create a sample CWL file
    with open(cwl_file_path, "w") as f:
        f.write(original_file_content)

    patch_image_in_file(cwl_file_path, image)

    with open(cwl_file_path) as f:
        return f.read()


def test_main(tmp_path):
    from aivkit.cwl import main as cwl_main

    test_cwl = dedent(
        """\
        cwlVersion: v1.0
        class: CommandLineTool
        """
    )
    input_cwl_path = tmp_path / "test.cwl"
    input_cwl_path.write_text(test_cwl)

    cwl_main(["patch-image", str(input_cwl_path), "test-image:test-tag"])

    with input_cwl_path.open("r") as f:
        fixed_cwl = yaml.safe_load(f)

    inserted_image = (
        fixed_cwl.get("hints", {}).get("DockerRequirement", {}).get("dockerPull", "")
    )
    assert inserted_image == "test-image:test-tag"


def test_cwl_file_patch_update_hint(tmp_path):
    """Test the patching of CWL files."""

    assert f"dockerPull: {new_test_image}" in get_patched_file_content(
        tmp_path,
        dedent(
            """\
            cwlVersion: v1.0
            class: CommandLineTool
            hints:
              DockerRequirement:
                dockerPull: old_image:latest
            """
        ),
        new_test_image,
    )


def test_cwl_file_patch_new_hint(tmp_path):
    """Test the patching of CWL files."""

    assert "dockerPull: test_image:latest" in get_patched_file_content(
        tmp_path,
        dedent(
            """\
            cwlVersion: v1.0
            class: CommandLineTool
            """
        ),
        new_test_image,
    )


def test_cwl_file_patch_no_chage(tmp_path):
    """Test the patching of CWL files."""

    original = dedent(
        """\
            cwlVersion: v1.0
            class: CommandLineTool
            hints:
              DockerRequirement:
                dockerPull: test_image:latest
            """
    )

    assert original == get_patched_file_content(
        tmp_path,
        original,
        new_test_image,
    )


def test_cwl_file_patch_requirement(tmp_path):
    """Test the patching of CWL files."""

    with pytest.raises(
        ValueError, match=".*DockerRequirement is set in CWL as requirement*"
    ):
        get_patched_file_content(
            tmp_path,
            dedent(
                """\
            cwlVersion: v1.0
            class: CommandLineTool
            requirements:
              DockerRequirement:
                dockerPull: old_image:latest
            """
            ),
            new_test_image,
        )


def test_real_example_cwl(
    datapipe_example_cwl,
):
    """Test the patching of CWL files."""

    from aivkit.cwl import patch_image_in_file

    original_file = datapipe_example_cwl.with_suffix(".bak")
    shutil.copy(datapipe_example_cwl, original_file)

    patch_image_in_file(datapipe_example_cwl, new_test_image)

    with open(datapipe_example_cwl) as f:
        cwl = yaml.safe_load(f)

    # Check if the image was patched correctly
    assert (
        cwl.get("hints", {}).get("DockerRequirement", {}).get("dockerPull", "")
        == new_test_image
    )

    with open(original_file) as f_original, open(datapipe_example_cwl) as f_patched:
        assert (
            f_original.readlines()
            + [
                "hints:\n",
                "  DockerRequirement:\n",
                "    dockerPull: test_image:latest\n",
            ]
            == f_patched.readlines()
        )


def test_cwl_workflow_patch(tmp_path):
    assert "dockerPull: test_image:latest" not in get_patched_file_content(
        tmp_path,
        dedent(
            """\
            cwlVersion: v1.0
            class: Workflow
            """
        ),
        new_test_image,
    )


def test_cwl_expressiontool_patch(tmp_path):
    assert "dockerPull: test_image:latest" not in get_patched_file_content(
        tmp_path,
        dedent(
            """\
            cwlVersion: v1.0
            class: ExpressionTool
            """
        ),
        new_test_image,
    )
