import logging
import os

import pytest


@pytest.mark.parametrize(
    ("settings", "expected_choice"),
    [
        pytest.param(["var", "default", "global"], "environment variable", id="var"),
        pytest.param(["global"], "global PATH", id="global"),
        pytest.param(["default", "global"], "default path", id="default+global"),
        pytest.param(["var", "default"], "environment variable", id="var"),
        pytest.param(["default"], "default path", id="default"),
    ],
)
@pytest.mark.parametrize("binary", ["kind", "kubectl", "helm"])
def test_find_tools(monkeypatch, settings, expected_choice, binary, caplog):
    """Test the find_bin function to ensure it finds binaries correctly."""
    from aivkit.deploy import tools

    # remove .toolkit/bin from PATH to avoid interference
    original_path = os.environ.get("PATH", "")
    path_parts = original_path.split(os.pathsep)
    path_parts = [p for p in path_parts if p != "./.toolkit/bin"]
    os.environ["PATH"] = os.pathsep.join(path_parts)

    # remove all files from .toolkit/bin to avoid interference
    for filename in os.listdir("./.toolkit/bin"):
        file_path = os.path.join("./.toolkit/bin", filename)
        if os.path.isfile(file_path):
            os.remove(file_path)

    monkeypatch.delenv(binary.upper(), raising=False)
    caplog.set_level(logging.DEBUG)

    # this sets up the environment in different ways, expecting different tool discovery outcomes
    for mode in settings:
        if mode == "var":
            monkeypatch.setenv(binary.upper(), f"./.toolkit/bin/{binary}")
            logging.info(
                "Setting %s environment variable to ./toolkit/bin/%s",
                binary.upper(),
                binary,
            )
        elif mode == "default":
            logging.info("Assuming default path for %s", binary)

            # copy the binary to the default location, important for the test to avoid lots of downloads
            tools.install_tools(from_global=True)

        elif mode == "global":
            monkeypatch.setenv("PATH", "./.toolkit/bin", prepend=os.pathsep)
            logging.info("Adding ./.toolkit/bin to PATH")
        else:
            raise ValueError(f"Unknown mode: {mode}")

    logging.info(
        "Testing find_bin for %s with settings %s, expected choice %s",
        binary,
        settings,
        expected_choice,
    )

    assert tools.find_bin(binary, binary.upper()) == getattr(tools, f"{binary}_bin")()

    assert f"Using {binary} from {expected_choice}" in caplog.text
