"""
Test make commands used by the users.

These tests are not safe to run in parallel since they work with single named repository.
"""

import json
import os
import re
import subprocess as sp
from pathlib import Path
from textwrap import dedent

import pytest

from aivkit.runcmd import run_subprocess_tracing_logging


def run_make(args, env=None):
    """Run a Makefile command with the given arguments and return the output."""
    return run_subprocess_tracing_logging(["make"] + args, env=env)


@pytest.mark.usefixtures("_clear_all_kind_clusters", "_k8s_tools")
def test_make_setup_k8s_cluster_defaults():
    """Test the Makefile setup-k8s-cluster target with default parameters."""

    run_make(["destroy-k8s-cluster"])
    r = run_make(["setup-k8s-cluster"])

    assert re.search(r"Kind cluster .*? created in .*? seconds", r)
    assert re.search(
        r"Creating kind cluster .*? with config .*/.toolkit/kind-config.yaml",
        r,
    )


@pytest.mark.usefixtures("_clear_all_kind_clusters", "_k8s_tools")
def test_make_setup_k8s_cluster_set_kind_config_reuse():
    """Test the Makefile setup-k8s-cluster target with a custom kind config and reuse option."""

    from aivkit.deploy.kind import write_kind_config

    kind_config_path = Path("kind-config-custom.yaml")

    write_kind_config(
        kind_config_path,
        enable_registry_mirrors=True,
        enable_ingress=True,
        mount_repo=True,
    )

    r = run_make(
        [
            "setup-k8s-cluster",
            f"KIND_CONFIG={kind_config_path}",
        ]
    )
    assert re.search(r"Kind cluster .*? created in .*? seconds", r)

    r = run_make(
        [
            "setup-k8s-cluster",
            f"KIND_CONFIG={kind_config_path}",
            "IF_CLUSTER_EXISTS=reuse",
        ]
    )

    assert not re.search(r"Kind cluster .*? created in .*? seconds", r)
    assert re.search(r"Reusing existing cluster", r)
    assert not re.search(r"Creating kind cluster.*", r)


@pytest.mark.usefixtures("_clear_all_kind_clusters", "_k8s_tools")
def test_make_setup_k8s_cluster_settings_ingress_to_config_recreate():
    """Test the Makefile setup-k8s-cluster target with a custom kind config and recreate option."""

    r = run_make(
        ["setup-k8s-cluster", "IF_CLUSTER_EXISTS=recreate", "ENABLE_INGRESS=true"]
    )

    assert re.search(
        r"Creating kind cluster .*? with config .*?\.toolkit/kind-config.yaml",
        r,
    )
    assert re.search(r"Kind cluster .*? created in .*? seconds", r)
    # assert re.search(r"- containerPort: 443", r)


@pytest.mark.usefixtures("_clear_all_kind_clusters", "_k8s_tools")
def test_make_setup_k8s_cluster_settings_registry_mirrors_to_config_recreate():
    """Test the Makefile setup-k8s-cluster target with a custom kind config and recreate option."""

    r = run_make(
        [
            "setup-k8s-cluster",
            "IF_CLUSTER_EXISTS=recreate",
            "ENABLE_REGISTRY_MIRRORS=true",
        ]
    )

    assert re.search(
        r"Creating kind cluster .*? with config .*?\.toolkit/kind-config.yaml",
        r,
    )
    assert re.search(r"Kind cluster .*? created in .*? seconds", r)
    assert not re.search(r"- containerPort: 443", r)


@pytest.mark.parametrize(
    ("values_file_content", "expected_secret_names"),
    [
        pytest.param("", ["{release_name}-dppsuser-certkey"], id="default_values"),
        pytest.param(
            dedent("""\
                    users:
                    - name: DPPS User
                      suffix:
                    - name: DPPS User Two
                      suffix: testsuffix2
                """),
            [
                "{release_name}-dppsuser-certkey",
                "{release_name}-dppsusertestsuffix2-certkey",
            ],
            id="extra_user",
        ),
    ],
)
@pytest.mark.usefixtures("_clear_all_kind_clusters", "_k8s_tools")
def test_make_alternative_values(values_file_content, expected_secret_names, tmp_path):
    """Test the Makefile install-chart target with alternative values."""

    from aivkit.deploy.kind import kind_cluster
    from aivkit.deploy.random_names import get_instance_names
    from aivkit.deploy.tools import kubectl_bin

    values_file_path = tmp_path / "values.yaml"
    values_file_content = dedent(values_file_content).strip()

    with open(values_file_path, "w") as f:
        f.write(values_file_content)

    with kind_cluster() as cluster_name:
        r = run_make(
            [
                "load-toolkit-dev",  # this is a special case to load the toolkit image
                "install-chart",
                f"CHART_VALUES={values_file_path}",
                f"KUBECLUSTER={cluster_name}",
            ]
        )

        release_name = get_instance_names(
            "cert-generator-grid",
            Path(".toolkit/random-instance-names.yaml"),
            name="release_name",
        )

        secrets = sp.run(
            [kubectl_bin(), "get", "secrets", "-o", "json"],
            check=True,
            capture_output=True,
        )

        secret_names = [
            s["metadata"]["name"] for s in json.loads(secrets.stdout)["items"]
        ]

        for expected_secret_name in expected_secret_names:
            formatted_expected_secret_name = expected_secret_name.format(
                release_name=release_name
            )
            assert (
                formatted_expected_secret_name in secret_names
            ), f"Expected secret {formatted_expected_secret_name} not found in {secret_names}"

        assert re.search(r"Reusing existing cluster", r)


@pytest.mark.parametrize(
    ("image", "set_allowed", "raises_error"),
    [
        pytest.param(
            "harbor.cta-observatory.org/proxy_cache/alpine:3.22.1",
            False,
            False,
            id="allowed_image_prefixes_default",
        ),
        pytest.param("alpine:3.22.1", True, False, id="allowed_image_prefixes_present"),
        pytest.param("alpine:3.22.1", False, True, id="disallowed_image"),
    ],
)
@pytest.mark.usefixtures("_clear_all_kind_clusters", "_k8s_tools")
def test_make_install_test_chart(image, set_allowed, raises_error):
    """Test the Makefile install-chart target with alternative values."""

    from aivkit.deploy.images import default_allowed_image_prefixes

    cluster_name = "test-make-install-chart"

    cmd = [
        "load-toolkit-dev",  # this is a special case to load the toolkit image
        "install-chart",
    ]

    image_repository, image_tag = image.split(":")

    env = os.environ.copy()
    env.update(
        {
            "KUBECLUSTER": cluster_name,
            "CHART_NAME": "test-chart",
            "CHART_LOCATION": "test-chart",
            "CHART_EXTRA_VALUES": f"--set image.repository={image_repository} --set image.tag={image_tag}",
        }
    )

    if set_allowed:
        env["ALLOWED_IMAGE_PREFIXES"] = ",".join(
            default_allowed_image_prefixes + [image_repository]
        )

    if raises_error:
        with pytest.raises(RuntimeError):
            run_make(cmd, env=env)
    else:
        run_make(cmd, env=env)
