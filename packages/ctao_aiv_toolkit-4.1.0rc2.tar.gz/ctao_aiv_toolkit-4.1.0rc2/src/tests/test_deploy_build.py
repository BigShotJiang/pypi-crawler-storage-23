import subprocess as sp


def test_build_image(kind_cluster):
    """Test the Makefile build-image target."""

    from aivkit.deploy.cli import main as run_cli_command

    run_cli_command(
        [
            "--kind-cluster-name",
            kind_cluster,
            "image-build",
            "--context-path",
            "docker-image",
            "--dockerfile",
            "docker-image/Dockerfile",
            "--image-name",
            "test-image:v1.0.0",
        ]
    )

    sp.run(
        [
            "docker",
            "exec",
            f"{kind_cluster}-control-plane",
            "crictl",
            "inspecti",
            "test-image:v1.0.0",
        ],
        check=True,
    )
