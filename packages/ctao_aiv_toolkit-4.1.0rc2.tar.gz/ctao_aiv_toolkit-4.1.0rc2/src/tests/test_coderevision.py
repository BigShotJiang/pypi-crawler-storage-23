import pytest


@pytest.mark.parametrize(
    ("version", "color"),
    [
        ("v0.1.0", None),
        ("v0.1.0.post1", None),
        ("v0.3.0-rc1", "orange"),
        ("v0.3.0-b1", "red"),
        ("v0.3.0-a1", "red"),
        ("v0.3.0-dev5", "red"),
        ("v0.3.0.dev5+gdsa213", "red"),
        ("main", "red"),
    ],
)
def test_colorize_version(version, color):
    from aivkit.autoreport.coderevision import colorize_project_version

    result = colorize_project_version(version)
    if color is not None:
        assert rf"\color{{{color}}}" in result
    else:
        assert r"\color" not in result
