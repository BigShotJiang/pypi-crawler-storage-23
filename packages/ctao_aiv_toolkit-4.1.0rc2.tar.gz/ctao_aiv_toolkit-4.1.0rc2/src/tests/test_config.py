import json
import logging

from aivkit.autoreport.deps import iterate_dependencies
from aivkit.autoreport.projectinfo import (
    load_aiv_config,
    load_local_git_project_info,
    load_remote_git_project_info,
)
from aivkit.git import ctx_clone_dpps_group_repo


def test_config_own_repo():
    config = {"ignore_ci_vars": True, "local": True, "config_path": "aiv-config.yml"}

    load_aiv_config(config)
    load_local_git_project_info(config)

    logging.info(json.dumps(config, indent=2))

    assert config["gitlab_path"] == "cta-computing/common/aiv-toolkit"
    assert not config["allow_sonar_failures"]


def test_coderevision_dpps():
    with ctx_clone_dpps_group_repo("dpps", "v0.4.0"):
        config = {"ignore_ci_vars": True}

        load_local_git_project_info(config)

        assert config["gitlab_path"] == "cta-computing/dpps/dpps"

        assert config["application_version"] == "v0.4.0"


def test_coderevision_bdms():
    with ctx_clone_dpps_group_repo("bdms/bdms", "v0.4.0"):
        config = {"ignore_ci_vars": True}

        load_local_git_project_info(config)

        assert config["gitlab_path"] == "cta-computing/dpps/bdms/bdms"


def test_config_remote_dpps():
    config = {
        "gitlab_path": "cta-computing/dpps/dpps",
        "revision": "v0.4.0",
        "ignore_ci_vars": True,
    }
    load_remote_git_project_info(config)

    assert config["application_version"] == "v0.4.0"


def test_config_remote_bdms():
    config = {
        "gitlab_path": "cta-computing/dpps/bdms/bdms",
        "revision": "v0.4.0",
        "ignore_ci_vars": True,
    }
    load_remote_git_project_info(config)

    assert config["application_version"] == "v0.4.0"


def test_config_remote_wms():
    config = {
        "gitlab_path": "cta-computing/dpps/workload/wms",
        "revision": "v0.4.0",
        "ignore_ci_vars": True,
    }
    load_remote_git_project_info(config)
    iterate_dependencies(config)

    assert config["application_version"] == "v0.4.0"

    print(json.dumps(config, indent=2))


def test_clone_rev_and_compare():
    path_fragment = "bdms/bdms"
    revision = "v0.4.0"

    with ctx_clone_dpps_group_repo(path_fragment, revision):
        config = {
            "ignore_ci_vars": True,
            "gitlab_path": "cta-computing/dpps/bdms/bdms",
            "revision": "v0.4.0",
        }

        load_local_git_project_info(config)

        assert config["gitlab_path"] == "cta-computing/dpps/bdms/bdms"
        assert config["application_version"] == "v0.4.0"

        load_remote_git_project_info(config)

        assert config["gitlab_path"] == "cta-computing/dpps/bdms/bdms"
        assert config["application_version"] == "v0.4.0"
        assert config["dependencies"] == [
            {
                "gitlab_path": "cta-computing/dpps/bdms/bdms-rucio-policy",
                "revision": "v0.2.0",
            }
        ]
