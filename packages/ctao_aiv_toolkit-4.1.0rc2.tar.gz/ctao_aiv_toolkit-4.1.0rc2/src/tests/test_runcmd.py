"""
Test cases for the run_subprocess_tracing_logging function in aivkit.runcmd module.
"""


def test_runcmd():
    """Test the run_subprocess_tracing_logging function."""
    from aivkit.runcmd import run_subprocess_tracing_logging

    cmd = [
        "bash",
        "-c",
        "for i in {1..3}; do echo Hello, World!;  echo 'hello stderr' >&2; sleep 0.1; done",
    ]
    result = run_subprocess_tracing_logging(cmd)

    assert "Hello, World!" in result
    assert "hello stderr" in result
