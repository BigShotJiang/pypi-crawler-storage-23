import json
import logging
import random
import string
import subprocess as sp
from textwrap import dedent

import pytest


def randomword(length):
    letters = string.ascii_lowercase
    return "".join(random.choice(letters) for i in range(length))


@pytest.mark.parametrize(
    ("imagelist", "expected_exception"),
    [
        (
            dedent("""\
                harbor.cta-observatory.org/proxy_cache/alpine:3.22.1
                harbor.cta-observatory.org/dpps/cert-generator-grid-bootstrap:dev
                """),
            None,
        ),
        (
            dedent("""\
                harbor.cta-observatory.org/proxy_cache/alpine:3.22.1
                harbor.cta-observatory.org/dpps/cert-generator-grid-bootstrap:non-existent-tag
                """),
            RuntimeError(
                "Some images failed to pull: harbor.cta-observatory.org/dpps/cert-generator-grid-bootstrap:non-existent-tag"
            ),
        ),
    ],
)
def test_pull_images(tmp_path, imagelist, expected_exception, kind_cluster, caplog):
    """Test pulling images in a kind cluster."""
    from aivkit.deploy.cli import main

    image_list_fn = tmp_path / "chart-image-list.txt"
    with image_list_fn.open("w") as f:
        f.write(imagelist)

    statistics_json = tmp_path / "statistics.json"

    def run_main():
        return main(
            [
                "--kind-cluster-name",
                kind_cluster,
                "kind-pull-images",
                "--image-list-file",
                str(image_list_fn),
                "--max-pull-jobs",
                "1",
                "--statistics-json",
                str(statistics_json),
                "--allowed-image-prefixes",
                "harbor.cta-observatory.org",
                "--max-attempts",
                "3",
                "--sleep-between-attempts",
                "0.1",
            ]
        )

    if expected_exception is None:
        run_main()

        with statistics_json.open("r") as stats_file:
            stats = json.load(stats_file)
        assert stats["n_images"] == 2
        assert stats["total_size_mb"] > 0
        assert stats["time_seconds"] > 0
        assert len(stats["image_pull_results"]) == 2

        pull_results = stats["image_pull_results"]
        assert all(
            result["attempts"] <= 1 for result in pull_results
        ), "Images should be fetched in first attempt"
        assert all(
            result["success"] for result in pull_results
        ), "All images should have been pulled successfully"
        assert all(
            result["size_mb"] > 0 or "dev" in result["image"] for result in pull_results
        ), "All images should have a valid size"
        assert all(
            result["bandwidth_mb_per_s"] > 0 or "dev" in result["image"]
            for result in pull_results
        ), "All images should have a valid bandwidth"

    else:
        with caplog.at_level(logging.INFO):
            caplog.clear()
            with pytest.raises(
                expected_exception.__class__, match=expected_exception.args[0]
            ):
                run_main()

        assert "Pulling 2 images in attempt 1" in caplog.text
        assert "Pulling 1 images in attempt 2" in caplog.text
        assert "Pulling 1 images in attempt 3" in caplog.text
        assert "1 images failed to pull" in caplog.text
        assert "Successfully pulled 1 of 2 images" in caplog.text


@pytest.fixture
def host_ports():
    import socket
    from contextlib import closing

    ports = []
    args = (socket.AF_INET, socket.SOCK_STREAM)

    # bind two sockets to get two free ports
    with closing(socket.socket(*args)) as s1, closing(socket.socket(*args)) as s2:
        for s in (s1, s2):
            s.bind(("", 0))
            ports.append(s.getsockname()[1])

    return tuple(ports)


@pytest.mark.usefixtures("_k8s_tools")
@pytest.mark.parametrize("create_cluster", [True, False])
@pytest.mark.parametrize(
    "params",
    [
        {
            "enable_registry_mirrors": True,
            "enable_ingress": False,
            "mount_repo": False,
        },
        {"enable_registry_mirrors": True, "enable_ingress": True, "mount_repo": True},
    ],
)
def test_kind_config(create_cluster, params, host_ports, tmp_path, monkeypatch):
    """Test kind_config context manager and kind_cluster.

    Tests that parameters are correctly converted to kind config written to file.
    If create_cluster is True, it will create a kind cluster with the generated config to verify it works.
    """

    from aivkit.deploy.kind import kind_cluster, write_kind_config

    kubeconfig = tmp_path / "kubeconfig.yaml"
    monkeypatch.setenv("KUBECONFIG", str(kubeconfig))

    host_port_http, host_port_https = host_ports
    config_path = write_kind_config(
        **params, host_port_http=host_port_http, host_port_https=host_port_https
    )
    logging.info("Using kind config at %s", config_path)
    assert config_path.is_file()

    logging.info("Content of kind config:")
    with config_path.open("r") as f:
        content = f.read()
        logging.info(content)
        assert "kind:" in content
        assert "nodes:" in content
        assert "maxPods: 250" in content

        if params["enable_registry_mirrors"]:
            assert "registry.mirrors" in content
            assert "docker.io" in content
        else:
            assert "registry.mirrors" not in content

        if params["enable_ingress"]:
            assert "extraPortMappings" in content
            assert "containerPort: 80" in content
            assert "containerPort: 443" in content
        else:
            assert "extraPortMappings" not in content

        if create_cluster:
            cluster_name = f"test-cluster-{randomword(8)}"
            with kind_cluster(cluster_name, True, config_path):
                logging.info("Kind cluster created with config %s", config_path)
                cmd = ["kubectl", "get", "nodes", "-o", "json"]
                ret = sp.run(cmd, capture_output=True, encoding="utf-8")
                assert ret.returncode == 0, ret.stderr
                nodes = json.loads(ret.stdout)
                for node in nodes["items"]:
                    assert int(node["status"]["capacity"]["pods"]) == 250


def test_verify_allowed_images():
    from aivkit.deploy.images import verify_allowed_images

    images = [
        "harbor.cta-observatory.org/dpps/cert-generator-grid-bootstrap:dev",
        "cr.fluentbit.io/fluent/fluent-bit:3.2.8",
        "harbor.cta-observatory.org/proxy_cache/python:3.12.11-alpine3.22",
    ]
    allowed_prefixes = "harbor.cta-observatory.org,cr.fluentbit.io"

    # This should not raise an exception
    verify_allowed_images(images, allowed_prefixes)

    # Now test with a disallowed image
    images.append("docker.io/library/nginx:latest")
    with pytest.raises(
        RuntimeError,
        match="1 images in the cluster are not allowed: docker.io/library/nginx:latest",
    ):
        verify_allowed_images(images, allowed_prefixes)


def test_kind_purge():
    from aivkit.deploy.kind import kind_purge, kind_up, list_clusters

    cluster_name = "test-kind-purge-" + randomword(8)
    another_cluster_name = "test-kind-purge-" + randomword(8)

    assert list_clusters() == []

    kind_up(cluster_name)

    # try to create second time, should reuse existing
    kind_up(cluster_name)

    assert list_clusters() == [cluster_name]

    kind_up(another_cluster_name)

    assert set(list_clusters()) == {cluster_name, another_cluster_name}

    kind_purge()

    assert list_clusters() == []
