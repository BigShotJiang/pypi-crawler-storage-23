"""AIVKit Command Line Interface (CLI) module."""

import logging

from aivkit.argparser import ArgumentParserWithEnvConfigDefaults
from aivkit.install import (
    add_aiv_config,
    add_precommit_hook,
    add_toolkit_submodule_if_missing,
    check_submodule_commit,
    do_commit,
    remove_submodule,
    update_sonar_properties,
    update_toolkit_submodule,
)
from aivkit.log import add_logging_args, configure_logging_from_args


def add_install_subparser(subparsers):
    """Add the 'install' subparser to the CLI."""
    install_parser = subparsers.add_parser(
        "install",
        help="Check the configuration and environment",
    )
    install_parser.add_argument(
        "-c",
        "--commit",
        action="store_true",
        help="Commit changes made during installation",
    )
    install_parser.add_argument(
        "-u",
        "--update-toolkit",
        help="Update the aiv-toolkit submodule to the specified revision. @latest-tag for latest tag, @latest-release for latest release, 'skip' to skip update.",
        type=str,
        default="skip",
    )
    install_parser.set_defaults(func=main_install)


def add_add_hook_subparser(subparsers):
    """Add the 'add-hook' subparser to the CLI."""
    add_hook_parser = subparsers.add_parser(
        "add-hook",
        help="Add pre-commit hook for AIVKit",
    )
    add_hook_parser.add_argument(
        "--version",
        type=str,
        default=None,
        help="Specify the version of the pre-commit hook to add",
    )
    add_hook_parser.add_argument(
        "-c",
        "--commit",
        action="store_true",
        help="Commit changes made when adding the pre-commit hook",
    )
    add_hook_parser.set_defaults(func=main_add_hook)


def get_parser() -> ArgumentParserWithEnvConfigDefaults:
    """Get the argument parser for the CLI."""
    parser = ArgumentParserWithEnvConfigDefaults(
        description="AIvKit Command Line Interface",
    )

    add_logging_args(parser)

    subparsers = parser.add_subparsers(dest="command", required=True)

    add_install_subparser(subparsers)
    add_add_hook_subparser(subparsers)

    return parser


def flatten(list_of_lists):
    """Flatten a list of lists."""
    for item in list_of_lists:
        if isinstance(item, list):
            yield from flatten(item)


def main_install(args):
    """Handle the 'install' command."""
    logging.debug("Running 'install' command")

    changes = [
        add_aiv_config(),
        add_toolkit_submodule_if_missing(),
        update_toolkit_submodule("aiv-toolkit", args.update_toolkit),
        check_submodule_commit("aiv-toolkit"),
        remove_submodule("dpps-aiv-toolkit"),  # Deprecated submodule
        update_sonar_properties("dpps-aiv-toolkit", "aiv-toolkit"),
    ]

    # Flatten the list of changes and filter out None values
    changes = list(flatten(changes))

    if changes and args.commit:
        do_commit(
            "Update AIVKit installation:\n"
            + "\n".join(f"- {change}" for change in changes)
        )


def main_add_hook(args):
    """Handle the 'add-hook' command."""
    logging.debug("Running 'add-hook' command")

    change = add_precommit_hook(version=args.version)

    if change and args.commit:
        do_commit(f"Add pre-commit hook:\n- {change}")


def main(args=None):
    """Run main entry point for the autoreport CLI."""
    parser = get_parser()

    parsed_args = parser.parse_args(args)

    configure_logging_from_args(parsed_args)

    logging.debug("Parsed arguments: %s", parsed_args)

    parsed_args.func(parsed_args)
