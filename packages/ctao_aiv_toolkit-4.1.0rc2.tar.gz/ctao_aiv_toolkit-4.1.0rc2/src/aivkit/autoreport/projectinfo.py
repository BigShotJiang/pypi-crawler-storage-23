"""Load project information from a git repository."""

import logging
import os
import re
import subprocess
from io import StringIO, TextIOWrapper

import requests
import toml
import yaml
from packaging.requirements import Requirement

from aivkit.gitlab import (
    get_gitlab_file,
    get_gitlab_job_info_for_ref,
    get_gitlab_project,
    get_local_full_version,
    get_test_artifacts,
)

# default DPPS release if not specified in aiv-config.yml. Updated periodically to avoid requiring subsystem updates for every new DPPS release.
DEFAULT_RELEASE = {
    "DPPS": "v0.5.0",
    "SUSS": "v0.0.0",
}


# used in legacy projects/tags
DEFAULT_SONAR_SERVER = "https://sonar-ctao.zeuthen.desy.de/"


def load_local_git_project_info(config):
    """Load the project information from local git repository."""
    load_common(config, local=True)


def load_remote_git_project_info(config):
    """Load the project information from remote git repository."""
    load_common(config, local=False)


def load_common(config, local=False):
    """Load the project information from a git repository."""
    config["local"] = local

    if not local:
        # for remote repositories we need to load their aiv-config.yml
        load_aiv_config(config)

    if local:
        # for local repositories we can load the code revision information from the local git repository and files
        load_local_project_default_gitlab_repo(config)
        load_code_revision_ci_or_local(config)

    identify_application_version(config)

    if not config.get("ignore_ci_vars", False):
        load_gitlab_ci_vars(config)

    load_gitlab_mr_for_branch(config)

    load_sonar(config)

    if not local:
        load_artifacts(config)

    load_gitlab_name(config)
    load_gitlab_short_name(config)
    load_pyproject(config)
    load_helm_chart(config)
    load_job_urls(config)


def load_gitlab_mr_for_branch(config):
    """Load the merge request for the branch from the gitlab repository."""
    project = get_gitlab_project(config["gitlab_path"])

    project_mrs = project.mergerequests.list(
        state="opened", source_branch=config["ref_name"]
    )

    project_mr = project_mrs[0] if project_mrs else None

    if project_mr:
        if "pull_request" in config:
            if int(config["pull_request"]) != int(project_mr.iid):
                logging.error(
                    "Loaded pull_request %s for branch %s, but already had %s",
                    int(project_mr.iid),
                    config["ref_name"],
                    int(config["pull_request"]),
                )
                raise ValueError(
                    "Loaded pull_request for branch, but already had one and it's different"
                )

        config["pull_request"] = project_mr.iid
        config["pull_request_url"] = project_mr.web_url

        logging.info(
            "Loaded pull_request %s for branch %s",
            config["pull_request"],
            config["ref_name"],
        )


def load_gitlab_ci_vars(config):
    """Load the gitlab ci variables."""
    cidict = {
        key.lower(): value for key, value in os.environ.items() if key.startswith("CI_")
    }

    if len(cidict) == 0:
        logging.warning("Failed to load gitlab ci variables for %s", config)
        return

    logging.info("Loaded gitlab ci variables %s", cidict)

    # add some shorthands
    cidict["ref_name"] = cidict["ci_commit_ref_name"]
    if mr_id := cidict.get("ci_merge_request_iid"):
        cidict["pull_request"] = mr_id

    config.update(cidict)


def load_code_revision_ci_or_local(config):
    """Load the current code revision information either from gitlab environment variables or from local git."""
    ignore_ci_vars = config.get("ignore_ci_vars", False)
    if ignore_ci_vars:
        project_path = os.getenv("BASE_PROJECT_DIR")
    else:
        project_path = os.getenv("CI_PROJECT_DIR", os.getenv("BASE_PROJECT_DIR"))

    cwd = project_path
    logging.info("Getting git information from path '%s'", cwd)

    if not ignore_ci_vars and "CI_COMMIT_REF_NAME" in os.environ:
        config["ref_name"] = os.environ["CI_COMMIT_REF_NAME"]
    else:
        r = None
        # this finds branch
        try:
            r = subprocess.check_output(
                ["git", "symbolic-ref", "-q", "--short", "HEAD"], cwd=cwd
            )
        except subprocess.CalledProcessError:
            logging.warning("Failed to get branch name from git symbolic-ref")

        # this finds tag
        try:
            r = subprocess.check_output(
                ["git", "describe", "--tags", "--exact-match"], cwd=cwd
            )
        except subprocess.CalledProcessError:
            logging.warning("Failed to get tag name from git describe")

        # # fallback
        # try:
        #     r = subprocess.check_output(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=cwd)
        # except subprocess.CalledProcessError:
        #     logging.warning("Failed to get branch name from git rev-parse")

        if r is None:
            logging.error(
                "Failed to get branch name from git, will rely on other sources"
            )
        else:
            config["ref_name"] = r.strip().decode("utf-8")


def load_gitlab_short_name(config):
    """Load the short name of the gitlab repository."""
    config["gitlab_short_name"] = config["gitlab_path"].split("/")[-1]


def load_local_project_default_gitlab_repo(config):
    """
    Load the project information from local git repository.

    In principle we want to allow to fully support treatment local files in report generations.
    But to get some basic information we need to load it from gitlab: like the project name on gitlab.
    This has to assume that the local repository is a clone of a gitlab repository with default remote name origin.
    """
    cwd = os.getenv("BASE_PROJECT_DIR")
    logging.info("Getting git information from path '%s'", cwd or os.getcwd())
    config["gitlab_remote"] = (
        subprocess.check_output(["git", "remote", "get-url", "origin"], cwd=cwd)
        .decode("utf-8")
        .strip()
    )

    m = re.match(r".*?gitlab.cta-observatory.org[:/](.*)", config["gitlab_remote"])
    if m is None:
        raise ValueError("Could not parse git remote url")
    config["gitlab_path"] = m.group(1).removesuffix(".git")

    config["git_full_version"] = get_local_full_version(os.getenv("BASE_PROJECT_DIR"))

    logging.info(
        "Loaded gitlab path %s from remote %s",
        config["gitlab_path"],
        config["gitlab_remote"],
    )


def get_gitlab_file_yaml(path, revision, file):
    """Load a yaml file from a gitlab repository."""
    return yaml.load(
        StringIO(get_gitlab_file(path, revision, file)), Loader=yaml.SafeLoader
    )


def set_if_not_empty(d, k, v):
    """Set a dictionary key to a value if the value is not None, empty or an empty list."""
    if d.get(k) in (None, "", []):
        logging.info("Setting %s to default value %s", k, v)
        d[k] = v
    else:
        logging.info("Keeping existing %s value %s", k, d[k])


def load_aiv_config_defaults(config: dict) -> None:
    """Load the default values for aiv-config variables."""
    # for backwards compatibility with dpps-aiv-toolkit
    for var in ("release", "uc_groups", "uc_subtree_name"):
        old_var = f"dpps_{var}"
        if old_var in config:
            logging.warning(
                "Setting %s is deprecated, use %s.", old_var.upper, var.upper()
            )
            config[var] = config.pop(old_var)

    set_if_not_empty(config, "aiv_system", "DPPS")
    set_if_not_empty(config, "release", DEFAULT_RELEASE[config["aiv_system"]])

    set_if_not_empty(config, "sonar_server", DEFAULT_SONAR_SERVER)
    set_if_not_empty(config, "release_plan_from_jama", False)
    set_if_not_empty(
        config, "jama_project_id", "14"
    )  # CTAO Backyard project ID, where test setup is made


def load_aiv_config(config: dict) -> None:
    """Load the aiv-config from local git or gitlab repository."""
    logging.info("Loading aiv-config for %s", config)

    if "config_path" not in config:
        config["config_path"] = "aiv-config.yml"

    try:
        if config.get("local", True):
            with open_local_repo_file(config["config_path"]) as f:
                aiv_config_raw = yaml.load(f, Loader=yaml.SafeLoader)
        else:
            aiv_config_raw = get_gitlab_file_yaml(
                config["gitlab_path"], config["revision"], config["config_path"]
            )

        config.update({k.lower(): v for k, v in aiv_config_raw["variables"].items()})

    except FileNotFoundError as e:
        logging.info(
            "Failed to load aiv-config.yml for %s: %s, probably fine.", config, e
        )
        # TODO: use gitlab project name as application name
        config["application_name"] = config["gitlab_path"].split("/")[-1]

    # lowercase is compatible with the argparse namespace, uppercase and variable - with CI variables file

    logging.debug("Loaded aiv-config %s", config)

    # load dependencies from aiv-config-dependencies.yml

    try:
        if config.get("local", True):
            with open_local_repo_file("aiv-config-dependencies.yml") as f:
                config["dependencies"] = yaml.load(f, Loader=yaml.SafeLoader)[
                    "dependencies"
                ]
        else:
            config["dependencies"] = get_gitlab_file_yaml(
                config["gitlab_path"], config["revision"], "aiv-config-dependencies.yml"
            )["dependencies"]
    except FileNotFoundError as e:
        logging.info("Failed to load aiv-config-dependencies.yml for %s: %s", config, e)
        config["dependencies"] = []

    # TODO: eventually use pydantic for validation?
    for k, v in os.environ.items():
        r = re.match(r"AIV_VAR_(.*)", k)

        if r:
            if v == "true":
                v = True
            elif v == "false":
                v = False

            config[r.group(1).lower()] = v
            logging.debug("Loaded AIV_VAR_%s %s", r.group(1), v)

    load_aiv_config_defaults(config)


def load_job_urls(config):
    """Load the job urls for the test report xml depending on whether it is local or remote."""
    config.update(
        get_gitlab_job_info_for_ref(config["gitlab_path"], config["ref_name"], "test")
    )


def load_sonar(dependency: dict) -> None:
    """Load the sonar properties from the sonar-project.properties file."""
    if "sonar_project_key" in dependency:
        logging.info(
            "Using sonar_project_key override as sonar_key for %s",
            dependency["sonar_project_key"],
        )
        dependency["sonar_key"] = dependency["sonar_project_key"]
        dependency["sonar_server"] = dependency.get(
            "sonar_server", DEFAULT_SONAR_SERVER
        )

        return

    try:
        if dependency["local"]:
            with open_local_repo_file("sonar-project.properties") as f:
                dependency["sonar-project.properties_content"] = f.read()
        else:
            dependency["sonar-project.properties_content"] = get_gitlab_file(
                dependency["gitlab_path"],
                dependency["revision"],
                "sonar-project.properties",
            )
        dependency["sonar_key"] = re.search(
            r"sonar\.projectKey=(.*)", dependency["sonar-project.properties_content"]
        ).group(1)
        m = re.search(
            r"sonar\.host\.url=(.*)", dependency["sonar-project.properties_content"]
        )
        if m is not None:
            dependency["sonar_server"] = m.group(1)
        else:
            dependency["sonar_server"] = DEFAULT_SONAR_SERVER
    except FileNotFoundError as e:
        logging.error(
            "Failed to load sonar-project.properties for %s: %s", dependency, e
        )
        raise


def load_artifacts(config: dict) -> None:
    """Load test artifacts from the gitlab repository."""
    config["artifacts"] = {
        "test": get_test_artifacts(config["gitlab_path"], config["revision"])
    }

    if config["artifacts"]["test"] is not None:
        config["test_report_xml_fn"] = config["artifacts"]["test"]["report.xml"]["fn"]
        config["test_report_xml_job_url"] = config["artifacts"]["test"]["report.xml"][
            "job_url"
        ]


def open_local_repo_file(file_path: str) -> TextIOWrapper:
    """Get a file from a local repository."""
    return open(os.path.join(os.getenv("BASE_PROJECT_DIR", "."), file_path))


def parse_python_dependency(python_dependency: list) -> dict:
    """Parse the python dependencies from the pyproject.toml file."""
    try:
        req = Requirement(python_dependency)
    except ValueError:
        logging.error("Failed to parse python dependency %s", python_dependency)
        raise

    return dict(name=req.name, version=str(req.specifier))


def load_pyproject(config: dict) -> None:
    """Load the information from the pyproject.toml file."""
    # "name_pyproject": pyproject["project"]["name"],

    try:
        if config["local"]:
            with open_local_repo_file("pyproject.toml") as f:
                pyproject = toml.load(f)
        else:
            pyproject = toml.load(
                StringIO(
                    get_gitlab_file(
                        config["gitlab_path"],
                        config["revision"],
                        "pyproject.toml",
                    )
                )
            )

        config["python_dependencies"] = [
            {
                **parse_python_dependency(dep),
                "parent_project": config["gitlab_short_name"],
            }
            for dep in pyproject["project"].get("dependencies", [])
        ]

        config["pyproject_name"] = pyproject["project"]["name"]

        logging.debug("Loaded python dependencies %s", config["python_dependencies"])

    except requests.exceptions.HTTPError as e:
        logging.warning("Failed to load pyproject.toml for %s: %s", config, e)


def load_gitlab_name(config: dict) -> None:
    """Load the gitlab name from the gitlab repository."""
    project = get_gitlab_project(config["gitlab_path"])

    config["gitlab_name"] = project.name
    config["gitlab_url"] = project.web_url

    logging.info("Loaded gitlab name %s", config["gitlab_name"])


def load_helm_chart(config: dict) -> None:
    """Load the helm dependencies from the Chart.yaml file."""
    try:
        if config["local"]:
            # TODO: use variable location for this path
            with open_local_repo_file("chart/Chart.yaml") as f:
                helm_chart_file = yaml.load(f, Loader=yaml.SafeLoader)
        else:
            helm_chart_file = yaml.load(
                StringIO(
                    get_gitlab_file(
                        config["gitlab_path"],
                        config["revision"],
                        "chart/Chart.yaml",
                    )
                ),
                Loader=yaml.SafeLoader,
            )

        config["helm_dependencies"] = helm_chart_file.get("dependencies", [])

        for dep in config["helm_dependencies"]:
            dep["parent_project"] = config["gitlab_short_name"]

        config["helm_name"] = helm_chart_file["name"]

        logging.debug("Loaded helm dependencies %s", config["helm_dependencies"])

    except FileNotFoundError as e:
        logging.info("Failed to load helmfile.yaml for %s: %s", config, e)


def identify_application_version(config):
    """
    Identify the application version from various loaded properties.

    The version should correspond to `git describe --tags` output given when the repository is checked out.

    But for remote repositories we can't use the local git repository directly, instead we already have the reference by which we are checking out the repository.
    TODO: cross-check that checked-out version matches the request

    And when running in gitlab CI we should use the CI_* variables (or at least cross-check).
    TODO: cross-check CI and local
    """
    # TODO: finish
    # TODO: add flag if it is local

    if "ref_name" in config:
        # when in gitlab CI
        logging.info(
            "Identified application version from ref_name %s", config["ref_name"]
        )
        config["application_version"] = config["ref_name"]
        config["application_version_origin"] = "ref_name"

    elif "revision" in config:
        # when cloning a remote repository by revision
        logging.info(
            "Identified application version from revision %s", config["revision"]
        )
        config["application_version"] = config["revision"]
        config["application_version_origin"] = "revision"
        config["ref_name"] = config["revision"]

    elif "git_full_version" in config:
        # local case
        logging.info(
            "Identified application version from git_full_version %s",
            config["git_full_version"],
        )
        config["application_version"] = config["git_full_version"]
        config["application_version_origin"] = "git_full_version"
        # TODO: this is temporary default, should be read
        config["ref_name"] = "main"

    else:
        logging.error("Failed to identify application version for %s", config)
        raise ValueError("Failed to identify application version")
