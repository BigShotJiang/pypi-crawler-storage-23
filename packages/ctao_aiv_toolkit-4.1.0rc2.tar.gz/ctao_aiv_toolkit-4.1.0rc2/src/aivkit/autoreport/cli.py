"""CLI for the autoreport package."""

import argparse
import importlib
import logging
import os
from pkgutil import iter_modules

import requests_cache

from aivkit.autoreport.config import load_config_from_args
from aivkit.autoreport.junit import merge_junit
from aivkit.autoreport.manual import (
    extract_test_cases_from_files,
    write_manual_report_xml,
)
from aivkit.log import add_logging_args, configure_logging_from_args

from . import generators
from .latex import write_latex_file

script_dir = os.path.dirname(os.path.abspath(__file__))


def construct_parser():
    """Construct the argument parser for the CLI."""
    parser = argparse.ArgumentParser(
        description="Process a test/lint artifact and generate a LaTeX file."
    )
    # this option is not part of normal config since config loading is in part dependent on it
    parser.add_argument(
        "--cache-requests",
        dest="cache_requests",
        help="Cache the requests.",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "-c",
        "--config",
        dest="config_path",
        help="The path to the configuration file.",
        default=os.getenv("AIV_CONFIG", "aiv-config.yml"),
        type=str,
    )
    parser.add_argument(
        "--output", help="The path to the output .tex file.", default=None, type=str
    )
    parser.add_argument(
        "--enriched-config-cache",
        dest="enriched_config_cache",
        help="Cache the enriched configuration.",
        type=str,
    )

    add_logging_args(parser)

    subparsers = parser.add_subparsers(
        dest="operation", help="The operation to perform."
    )

    subparser_all = subparsers.add_parser(
        "all",
        help="Generate all reports.",
        description="Generate all reports.",
    )

    generator_functions = {}

    for generator_module_info in iter_modules(generators.__path__):
        generator_name = generator_module_info.name

        generator_module = importlib.import_module(
            f"{generators.__name__}.{generator_module_info.name}"
        )

        if getattr(generator_module, "__generator_disabled__", False):
            continue

        subparser = subparsers.add_parser(
            generator_name,
            help=generator_module.__doc__,
            description=generator_module.__doc__,
        )

        subparser_all.add_argument(
            f"--{generator_name}-output",
            help=f"The path to the output .tex file for {generator_name}.",
            default=f"{generator_name}.tex",
            type=str,
        )

        for arg in getattr(generator_module, "get_args", lambda: [])():
            subparser.add_argument(
                arg["name"],
                help=arg["help"],
                type=arg["type"],
                nargs="?",
                default=arg.get("default"),
            )

            subparser_all.add_argument(
                arg["name"],
                help=arg["help"] + f" for {generator_name}.",
                type=arg["type"],
                nargs="?",
                default=arg.get("default"),
            )

        generator_functions[generator_name] = generator_module.generate

    manual_parser = subparsers.add_parser(
        "extract-from-manual", help="Extract from manual."
    )
    manual_parser.add_argument(
        "manual_files",
        help="Files to extract from.",
        type=str,
        nargs="+",
    )
    manual_parser.add_argument(
        "--report-xml",
        help="Path to the report XML file.",
        type=str,
        default="report.xml",
    )

    merge_parser = subparsers.add_parser(
        "merge-junit",
        help="Merge JUnit XML files.",
        description="Merge JUnit XML files.",
    )
    merge_parser.add_argument(
        "junit_files",
        help="JUnit XML files to merge.",
        type=str,
        nargs="+",
    )
    merge_parser.add_argument(
        "--output",
        help="Output file for merged JUnit XML.",
        type=str,
        default="merged_report.xml",
    )

    return parser, generator_functions


def generate_all(config, generator_functions, args, script_dir):
    """Generate all reports."""
    for generator_name, operation_call in generator_functions.items():
        output_file = getattr(args, f"{generator_name}_output", None)
        if output_file is None:
            output_file = os.path.realpath(
                os.path.join(script_dir, "..", "build", f"{generator_name}.tex")
            )

        logging.info("Generating %s...", output_file)

        latex_content = operation_call(config)
        write_latex_file(latex_content, output_file)

        if args.debug:
            logging.debug(latex_content)

        logging.info(
            "%s generated successfully with %s lines.",
            output_file,
            len(latex_content.splitlines()),
        )


def main(args_list: list[str] | None = None):
    """Process test artifacts and generate LaTeX report."""
    parser, generator_functions = construct_parser()
    args = parser.parse_args(args_list)

    configure_logging_from_args(args)

    if args.cache_requests:
        logging.info("Caching requests.")
        requests_cache.install_cache(
            ".toolkit/tests_cache", expire_after=36000, backend="filesystem"
        )

    if args.operation == "extract-from-manual":
        logging.info("Extracting from manual files: %s", args.manual_files)

        test_cases = extract_test_cases_from_files(args.manual_files)
        write_manual_report_xml(test_cases, args.report_xml)

        logging.info("Extracted test cases: %s", test_cases)
    elif args.operation == "merge-junit":
        merge_junit(
            args.junit_files,
            args.output,
        )

    else:
        generation_operations(args, generator_functions)


def generation_operations(args, generator_functions):
    """Perform generation operations based on args."""
    config = load_config_from_args(args)

    logging.info("Full configuration: %s", config)

    if args.output:
        output_file = args.output
    else:
        output_file = os.path.realpath(
            os.path.join(script_dir, "..", "build", f"{args.operation}.tex")
        )

    if args.operation == "all":
        generate_all(config, generator_functions, args, script_dir)

    elif args.operation not in generator_functions:
        operation_call = generator_functions[args.operation]

        logging.info("Generating %s from %s...", output_file, config["release_plan_fn"])

        latex_content = operation_call(config)
        write_latex_file(latex_content, output_file)

        if args.verbose:
            logging.debug(latex_content)

        logging.info(
            "%s generated successfully with %s lines.",
            output_file,
            len(latex_content.splitlines()),
        )

    else:
        logging.error(
            "unknown operation %s, known: %s",
            args.operation,
            list(generator_functions.keys()),
        )


if __name__ == "__main__":
    main()
