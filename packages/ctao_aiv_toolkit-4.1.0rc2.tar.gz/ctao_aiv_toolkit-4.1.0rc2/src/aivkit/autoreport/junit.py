"""Manipulate JUnit XML files."""

import logging
from xml.etree import ElementTree as ET


def tc_equivalence(tc1: ET.Element, tc2: ET.Element) -> bool:
    """Check if two test cases, as represented by XML elements in JUnit-style XML, are equivalent."""
    return (
        tc1.attrib["name"] == tc2.attrib["name"]
        and tc1.attrib["classname"] == tc2.attrib["classname"]
        and tc1.attrib["status"] == tc2.attrib.get("status", "passed")
        and tc1.attrib.get("reason") == tc2.attrib.get("reason")
    )


def merge_junit(
    junit_files: list[str], output_file: str, deduplicate: bool = True
) -> None:
    """Merge JUnit XML files into a single file."""
    test_cases = []

    for junit_file in junit_files:
        tree = ET.parse(junit_file)
        root = tree.getroot()

        test_cases.extend(root.findall(".//testcase"))

    if deduplicate:
        test_cases = deduplicate_tests(test_cases)

    write_junit(test_cases, output_file)


def deduplicate_tests(test_cases: list[ET.Element]) -> list[ET.Element]:
    """Remove duplicates from test list."""
    dedup_list = []

    logger = logging.getLogger("deduplicate_tests")

    for tc in test_cases:
        if all(not tc_equivalence(tc, _tc) for _tc in dedup_list):
            dedup_list.append(tc)
            logger.info("not duplicated: %s", tc.attrib)
        else:
            logger.warning("skipping duplicated test %s", tc)

    return dedup_list


def write_junit(test_cases: list[ET.Element], report_xml: str) -> None:
    """Write test cases to a JUnit XML file."""
    root = ET.Element(
        "testsuites",
    )
    testsuite = ET.Element("testsuite")
    root.append(testsuite)

    testsuite.extend(test_cases)

    with open(report_xml, "wb") as f:
        f.write(ET.tostring(root))

    logging.info("Report XML written to %s", report_xml)
