"""Generate release plan from LaTeX file."""

import logging
import os
import re
from pathlib import Path

from packaging.version import InvalidVersion, Version

from aivkit.autoreport.jama.items import (
    compute_subtree_path_names,
    get_all_tags,
    get_tagged_items,
)
from aivkit.autoreport.jama.session import get_session
from aivkit.autoreport.ucreqids import to_full_uc_id
from aivkit.gitlab import get_gitlab_file, match_gitlab_file


def interpret_table_boolean(value: str) -> bool:
    """Interpret a table boolean value."""
    if value == "x":
        return True
    elif value == "":
        return False
    else:
        raise ValueError(f"Invalid boolean value: {value}")


def parse_release_plan(config: dict) -> dict:
    """Parse the release plan LaTeX file and return dictionary of use case lists."""
    r = match_gitlab_file(config["release_plan_fn"])
    if r:
        release_plan_latex = get_gitlab_file(
            r.group("project"), r.group("ref"), r.group("file")
        )

        logging.info(
            "Downloaded release plan from GitLab %s/%s/%s",
            r.group("project"),
            r.group("ref"),
            r.group("file"),
        )

    else:
        basepath = Path(os.getenv("BASE_PROJECT_DIR", "."))
        release_plan = basepath / config["release_plan_fn"]

        logging.info("Reading release plan from %s", os.path.realpath(release_plan))

        with open(release_plan) as f:
            release_plan_latex = f.read()

    release_plan_latex = re.sub(r"\n *\\hline *\n", "\n", release_plan_latex)

    system = config["aiv_system"]
    uclist_content = re.findall(
        r"\\uclist{"
        + system
        + r" (.*?) Use Cases \\label{tab:uc-v\d.\d\.\d}}{(.*?)\n *} *\n",
        release_plan_latex,
        re.DOTALL,
    )

    uclists = {}

    for rel, rows in uclist_content:
        uclist = []
        logging.info("found Rel %s", rel)
        for row in rows.split(r"\\"):
            if row != "":
                cols = [col.strip() for col in row.strip().split("&")]

                if len(cols) == 3:
                    # Add empty string means False for "is_revised", its the default
                    cols += [""]
                elif len(cols) != 4:
                    raise ValueError(f"Expected 3 or 4 columns, got {cols} from {row}")

                entries = dict(zip(["group", "name", "id", "is_revised"], cols))

                entries["is_revised"] = interpret_table_boolean(entries["is_revised"])

                logging.debug(entries)
                uclist.append(entries)

        uclists[rel] = uclist

    return uclists


def normalize_version_number(version: str) -> str:
    """If the release lacks a patch version, add it as 0."""
    if re.match(r"^v\d+\.\d+$", version):
        updated_version = version + ".0"
        logging.warning("Normalizing version %s to %s", version, updated_version)
        return updated_version

    return version


def get_release_plan_uclist(
    config: dict, include_past_releases: bool = True
) -> list[dict]:
    """Get the use case list for a specific subsystem from the release plan."""
    if config.get("release_plan_from_jama", False):
        logging.warning("Using release plan information from jama")
        jama_session = get_session()
        uclists = get_release_plan_uclists_from_jama(
            jama_session, config["aiv_system"], config["jama_project_id"]
        )
    else:
        logging.warning('config["release_plan_fn"] %s', config["release_plan_fn"])
        uclists = parse_release_plan(config)

    for release, uclist in uclists.items():
        logging.debug("Release %s has %d UCs", release, len(uclist))

    return get_release_plan_uclist_from_uclists(
        uclists, config, include_past_releases=include_past_releases
    )


# Jama tags are global for Jama, so they start with "DPPS " and may be different in other ways
def jama_tag_to_release(tag: str, system: str) -> str:
    """Convert a Jama tag to a release version."""
    tag = tag.removeprefix(system).strip()
    version = Version(tag)
    # Convert to a string in the format vX.Y.Z
    return f"v{version.major}.{version.minor}.{version.micro}"


def release_to_jama_tag(release: str, system: str) -> str:
    """Convert a release version to a Jama tag."""
    version = Version(release)
    return f"{system} {version.major}.{version.minor}"


def get_release_plan_uclists_from_jama(
    jama_session,
    system: str,
    jama_project_id=None,
    system_releases=None,
) -> dict[str, list[dict]]:
    """Get the use case lists for all DPPS releases from Jama."""
    uclists = {}

    if system_releases is None:
        logging.info("Getting list of existing %s releases from Jama", system)

        system_releases = []
        for tag_data in get_all_tags(jama_session, project_id=jama_project_id):
            tag = tag_data["name"]

            if not tag.startswith(system):
                continue

            try:
                system_releases.append(jama_tag_to_release(tag, system))
            except InvalidVersion:
                logging.info(
                    "Ignoring jama tag: %s, did not parse as system release version",
                    tag,
                )
                continue

        logging.info("Found %s releases: %s", system, system_releases)

    for system_release in system_releases:
        uclists[system_release] = []

        logging.info("Getting use cases for DPPS release %s", system_release)
        tag = release_to_jama_tag(system_release, system)
        for item in get_tagged_items(jama_session, jama_project_id, tag):
            logging.info("Found item in Jama: %s", item["globalId"])

            try:
                uclists[system_release].append(
                    dict(
                        id=to_full_uc_id(item["fields"]["legacy_id$76"], system),
                        name=item["fields"]["name"],
                        jama_id=item["globalId"],
                        subtree_id=item["location"]["parent"]["item"],
                        subtree_names=compute_subtree_path_names(jama_session, item),
                    )
                )
            except KeyError as e:
                logging.error(
                    "Error producing use case from item %s, release %s: %s",
                    item,
                    system_release,
                    e,
                )
                continue

    return uclists


def uc_included(config: dict, uc: dict) -> bool:
    """Check if a use case is used in the release plan based on the config."""
    if config["release_plan_from_jama"]:
        return any(
            subtree_name in config["uc_subtree_name"].split(",")
            for subtree_name in uc["subtree_names"]
        )
    else:
        uc_groups = config["uc_groups"].split(",")
        return uc["group"] in uc_groups or "ALL" in uc_groups


def update_selected_ucs(
    config: dict,
    selected_ucs: dict,
    system_release: str,
    uc: dict,
):
    """Update the selected use cases with the given use case if it is included."""
    if uc_included(config, uc):
        logging.info(
            'selecting UC %s "%s" for %s release %s',
            uc["id"],
            uc["name"],
            config["aiv_system"],
            system_release,
        )

        if uc["id"] in selected_ucs:
            selected_uc = selected_ucs[uc["id"]]
        else:
            selected_uc = {}
            selected_ucs[uc["id"]] = selected_uc
            selected_uc.update(uc)

        if "system_releases" not in selected_uc:
            selected_uc["system_releases"] = []

        selected_uc["system_releases"].append(system_release)


def get_release_plan_uclist_from_uclists(
    uclists: dict, config: dict, include_past_releases: bool = True
) -> list[dict]:
    """Get the use case list for a specific DPPS release from the parsed uclists."""
    # We started with release versions without patch level, like 0.0, but now we use SemVer, like 0.0.0.
    # At the moment, we support legacy two-digit versions in both release table and aiv-config.yml
    # This will be dropped once https://gitlab.cta-observatory.org/cta-computing/dpps/aiv/dpps-aiv-toolkit/-/issues/157 is done.

    system = config["aiv_system"]
    uclists = {normalize_version_number(k): v for k, v in uclists.items()}

    current_release = normalize_version_number(config["release"])
    uclists = list(sorted(uclists.items(), key=lambda kv: Version(kv[0])))

    # we use a dict and go through the releases in order
    # thus we get only unique uc ids and the latest definition
    selected_ucs = {}

    for system_release, release_uclist in uclists:
        if current_release == system_release or (
            include_past_releases
            and Version(system_release) <= Version(current_release)
        ):
            logging.info("selected release %s", system_release)

            for uc in release_uclist:
                uc["id"] = to_full_uc_id(uc["id"], system)

                update_selected_ucs(config, selected_ucs, system_release, uc)

        else:
            logging.info(
                "skipping release %s, while current %s and include_past_releases=%s",
                system_release,
                current_release,
                include_past_releases,
            )

    for selected_uc in selected_ucs.values():
        selected_uc["is_current_release"] = (
            current_release in selected_uc["system_releases"]
        )
        selected_uc["is_revised"] = (
            len(selected_uc["system_releases"]) > 1
            and selected_uc["is_current_release"]
        )

    return sorted(selected_ucs.values(), key=lambda uc: uc["id"])
