"""Extract claims from manually written text."""

import logging
import re
import xml.etree.ElementTree as ET

from aivkit.autoreport.junit import write_junit


def extract_test_cases_from_text(text) -> list:
    """
    Extract test cases from a given text.

    Args:
        text (str): The input text containing test cases.

    Returns
    -------
        list: A list of extracted test cases.
    """
    r = re.findall(
        r"\\ManualTestCase\{(?P<uc>.*?)\}\{(?P<status>.*?)\}\{(?P<comment>.*?)\}", text
    )

    logging.debug("Extracted test cases: %s", r)

    return [
        dict(
            test_class="manual",
            test_name="manual",
            test_status=status,
            requirement_ids=[],
            usecase_ids=[uc],
            comment=comment,
        )
        for uc, status, comment in r
    ]


def extract_test_cases_from_files(file_list) -> list:
    """
    Extract test cases from a list of files.

    Args:
        file_list (list): List of file paths to extract test cases from.

    Returns
    -------
        list: A list of extracted test cases.
    """
    test_cases = []
    for file in file_list:
        with open(file) as f:
            text = f.read()
            test_cases.extend(extract_test_cases_from_text(text))

    return test_cases


def write_manual_report_xml(manual_test_cases: list, report_xml: str):
    """
    Add test cases to the report XML.

    Overwrites report XML, but creates a backup with .bak extension.

    Args:
        test_cases (list): List of test cases to add.
        report_xml (str): Path to the report XML file.
    """
    test_cases = []

    for new_test_case in manual_test_cases:
        tc = ET.Element(
            "testcase",
            classname=new_test_case["test_class"],
            name=new_test_case["test_name"],
            status=new_test_case["test_status"],
            reason=new_test_case["comment"],
        )

        tc.append(ET.Element("properties"))
        properties = tc.find("properties")

        # add UC ids as properties
        if new_test_case["usecase_ids"]:
            for uc_id in new_test_case["usecase_ids"]:
                prop = ET.Element("property", name="usecase_id", value=uc_id)
                properties.append(prop)

        logging.info("test case attributes: %s", tc.attrib)
        if tc.find("properties") is not None:
            for prop in tc.find("properties"):
                logging.info("prop: %s", prop.attrib)

        test_cases.append(tc)

    write_junit(test_cases, report_xml)
