"""Utility functions for processing use case and requirement IDs."""

import logging
import re

import pandas as pd


def to_full_uc_id(uc_id: str, system: str) -> str:
    """Convert a shortened use case ID to the full format."""
    if uc_id != uc_id.strip():
        logging.warning('Use case ID "%s" has leading or trailing whitespace', uc_id)
        uc_id = uc_id.strip()

    if uc_id.startswith(f"{system}-UC-"):
        return uc_id
    elif uc_id.startswith("UC-"):
        return f"{system}-{uc_id}"
    else:
        raise ValueError(f'Invalid use case ID: "{uc_id}"')


def to_full_req_id(req_id: str, system: str) -> str:
    """Convert a shortened requirement ID to the full format."""
    regex = rf"^[BC]-{system}-(.*)"

    if re.match(regex, req_id):
        return req_id
    else:
        raise ValueError(f'Invalid requirement ID: "{req_id}", does not match {regex}')


def shorten_uc_id(uc_id: str, system: str) -> str:
    """Shorten a use case ID to a narrower string."""
    regex = rf"{system}-UC-(\d+.*)"

    r = re.search(regex, to_full_uc_id(uc_id, system))
    if r is None or not r.group(1):
        raise ValueError(f'Invalid use case ID: "{uc_id}", does not match {regex}')

    return r.group(1)


def shorten_req_id(req_id: str, system: str) -> str:
    """Shorten a requirement ID to a narrower string."""
    regex = r"[CB]-(.*)"

    r = re.search(regex, to_full_req_id(req_id, system))

    if r is None or not r.group(1):
        raise ValueError(f'Invalid requirement ID: "{req_id}", does not match {regex}')

    return r.group(1)


def shorten_row_entries(row: pd.Series, system: str) -> pd.Series:
    """Shorten the entries of a row in Traceability Matrix."""
    new_row = pd.Series()

    new_row["UC ID"] = shorten_uc_id(row["Use Case ID"], system)
    new_row["UC Name"] = row["Use Case Name"]
    new_row["Req ID"] = shorten_req_id(row["Requirement ID"], system)

    if pd.isna(row["Requirement Name"]):
        new_row["Req Name"] = None
    else:
        new_row["Req Name"] = re.sub(
            rf'^{row["Requirement ID"]}', "", row["Requirement Name"]
        )

    for column in new_row.index:
        if not pd.isna(new_row[column]):
            try:
                new_row[column] = re.sub(r"[\r\n\t ]+", " ", new_row[column].strip())
            except Exception as e:
                logging.error(
                    "Error processing column %s with value %s: %s",
                    column,
                    new_row[column],
                    e,
                )
                raise

    return new_row
