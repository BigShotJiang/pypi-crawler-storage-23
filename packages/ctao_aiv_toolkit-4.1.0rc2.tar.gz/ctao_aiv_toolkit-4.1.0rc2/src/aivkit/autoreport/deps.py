"""Load the dependencies from the configuration file and gitlab."""

import copy
import logging
from io import StringIO

import yaml

from aivkit.autoreport.projectinfo import (
    load_remote_git_project_info,
)
from aivkit.gitlab import get_gitlab_file, get_repo_full_version


def iterate_dependencies(config: dict) -> list[dict]:
    """Load the dependencies from the configuration file and gitlab."""
    dependencies = copy.deepcopy(config.get("dependencies", []))

    new_dependencies = []

    for dependency in dependencies:
        logging.info("Loading dependency %s", dependency)

        dependency["application_version"] = get_repo_full_version(
            dependency["gitlab_path"], dependency["revision"]
        )

        dependency["ignore_ci_vars"] = True

        load_remote_git_project_info(dependency)

        if config.get("recusive_dependencies", True):
            logging.info(
                "Recursively loading dependencies of %s", dependency["gitlab_path"]
            )

            try:
                nested_dependencies_config = yaml.load(
                    StringIO(
                        get_gitlab_file(
                            dependency["gitlab_path"],
                            dependency["revision"],
                            "aiv-config-dependencies.yml",
                        )
                    ),
                    Loader=yaml.SafeLoader,
                )

                logging.info(
                    "Loaded nested dependencies %s", nested_dependencies_config
                )

                nested_dependencies = iterate_dependencies(nested_dependencies_config)

                for nested_dependency in nested_dependencies:
                    if not any(
                        d["gitlab_path"] == nested_dependency["gitlab_path"]
                        and d["revision"] == nested_dependency["revision"]
                        for d in dependencies + new_dependencies
                    ):
                        new_dependencies.append(nested_dependency)

                logging.info(
                    "Loaded nested dependencies of %s: %s",
                    dependency["gitlab_path"],
                    nested_dependencies,
                )

            except FileNotFoundError as e:
                logging.warning(
                    "Failed to load aiv-config-dependencies.yml for %s: %s",
                    dependency,
                    e,
                )

        logging.info("Found new dependencies %s", new_dependencies)

    return dependencies + new_dependencies
