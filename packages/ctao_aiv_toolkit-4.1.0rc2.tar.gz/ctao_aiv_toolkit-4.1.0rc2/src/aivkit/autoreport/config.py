"""Configuration handling for the autoreport tool."""

from aivkit.autoreport.deps import iterate_dependencies
from aivkit.autoreport.projectinfo import load_aiv_config, load_local_git_project_info


def enrich_config(config: dict) -> None:
    """Enrich the configuration with additional information (in-place)."""
    load_local_git_project_info(config)

    # recursively iterate over dependencies and load their project info
    config["dependencies"] = iterate_dependencies(config)


def load_config_from_args(args):
    """Load the configuration from a file and enrich it with additional information."""
    config = {"config_path": args.config_path, "local": True}

    load_aiv_config(config)

    config.update(args.__dict__)

    enrich_config(config)

    return config
