"""Modules for generating report components."""
