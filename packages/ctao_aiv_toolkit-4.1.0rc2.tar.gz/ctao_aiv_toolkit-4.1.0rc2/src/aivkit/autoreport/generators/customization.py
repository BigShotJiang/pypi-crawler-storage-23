"""Generates the customization file for the LaTeX report, from a dictionary of values in config (aiv-config.yml typically)."""

import logging
from textwrap import dedent

from aivkit.autoreport.coderevision import colorize_project_version


def dollar_template(template, data):
    """Replace dollar-sign-enclosed template variables with values from data."""
    for key, value in data.items():
        logging.debug('Replacing "%s" with "%s"', key, value)
        template = template.replace(f"${key}$", value)

    return template


def generate(config):
    """Generate the customization file for the LaTeX report."""
    config_adapted = config.copy()
    system = config["aiv_system"]

    full_version = colorize_project_version(config.get("application_version", ""))

    if v := config.get("pull_request"):
        full_version += f" {{\\color{{red}}(PR: {v})}}"

    config_adapted["application_full_version"] = full_version

    if "application_full_name" not in config:
        config_adapted["application_full_name"] = (
            f"{system} {config['application_name']}"
        )

    # references, defined in report/references.bib per system
    config_adapted["qa_plan_reference"] = f"{system.lower()}-software-qa-plan"
    config_adapted["sdlc_reference"] = f"{system.lower()}-sdlc"
    config_adapted["release_plan_reference"] = f"{system.lower()}-release-plan"

    return dollar_template(
        dedent(
            """
        \\newcommand{\\ComputingSystem}{$aiv_system$}
        \\newcommand{\\ComputingSystemReleaseTarget}{$release$}

        \\newcommand{\\ApplicationName}{$application_name$}
        \\newcommand{\\ApplicationFullName}{$application_full_name$}
        \\newcommand{\\ApplicationAuthor}{$application_author$}
        \\newcommand{\\ApplicationAuthorOrganization}{$application_author_organization$}
        \\newcommand{\\ApplicationVersion}{$application_full_version$}

        \\newcommand{\\ReferenceQAPlan}{$qa_plan_reference$}
        \\newcommand{\\ReferenceSDLC}{$sdlc_reference$}
        \\newcommand{\\ReferenceReleasePlan}{$release_plan_reference$}
    """
        ),
        {k: v for k, v in config_adapted.items() if isinstance(v, str)},
    )
