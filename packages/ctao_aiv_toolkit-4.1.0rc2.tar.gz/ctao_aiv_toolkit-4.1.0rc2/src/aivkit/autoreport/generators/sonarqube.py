"""Generates latex with SonarQube metrics."""

import json
import logging
import os
from functools import cache, lru_cache
from urllib.parse import urlparse

import requests

from aivkit.autoreport.coderevision import colorize_project_version

from ..latex import escape_latex, generate_latex_table


def get_args():
    """Get the command line arguments."""
    return []


@cache
def get_sonar_tokens() -> dict[str, str]:
    """Load sonar API tokens from the environment.

    To support multiple sonarqube servers, we load all env variables that
    start with SONAR_API_TOKEN and expect the value to be of form <url>,<token>.

    So you could define e.g. for the current setup in your CI variables:

    - SONAR_API_TOKEN_0=sonar-ctao.zeuthen.desy.de,bar
    - SONAR_API_TOKEN_1=sonar-some-other-future-instance.zeuthen.desy.de,foo

    The token must be a sonarqube user token (different from the project analysis token
    you set in SONAR_TOKEN).

    This token is required in case the project is private or the sonarqube globally
    enforces authentication.
    """
    tokens = {}

    for key, value in os.environ.items():
        if key.startswith("SONAR_API_TOKEN"):
            url, _, token = value.partition(",")
            tokens[url] = token

    return tokens


@cache
def get_sonar_server_version(sonarqube_url):
    """Get the version of the sonarqube server."""
    url = f"{sonarqube_url.rstrip('/')}/api/server/version"
    response = requests.get(url)
    response.raise_for_status()
    return response.text.strip()


def sonar_api_get(sonarqube_url, endpoint, params=None, headers=None):
    """Make a get request to the sonarqube API."""
    default_headers = {
        "Accept": "application/json",
    }

    logging.info(
        "Making request to SonarQube API %s/%s with params %s",
        sonarqube_url,
        endpoint,
        params,
    )

    if headers is None:
        headers = default_headers
    else:
        headers = {**default_headers, **headers}

    auth = None
    token = get_sonar_tokens().get(urlparse(sonarqube_url).hostname)

    if token is not None:
        logging.debug("Using token for %s", sonarqube_url)
        server_version = get_sonar_server_version(sonarqube_url)

        if server_version.startswith("9."):
            logging.info(
                "Sonar version is %s so using old (v9) basic auth scheme for %s",
                server_version,
                sonarqube_url,
            )
            auth = (token, "")
        else:
            logging.info(
                "Sonar version is %s so using new Authorization Bearer scheme for %s",
                server_version,
                sonarqube_url,
            )
            headers["Authorization"] = f"Bearer {token}"

    url = f"{sonarqube_url.rstrip('/')}/{endpoint.lstrip('/')}"

    response = requests.get(url, params=params, headers=headers, auth=auth)
    response.raise_for_status()
    return response.json()


def get_project_dicts(config) -> list[dict]:
    """Get the SonarQube project config from the config."""
    project_dicts = config.get("dependencies", [])

    logging.debug("Using SonarQube project dicts from config: %s", project_dicts)

    return [config] + project_dicts


def get_available_metrics(url, debug: bool = False) -> dict:
    """Get the available SonarQube metrics."""
    available_metrics = sonar_api_get(url, "api/metrics/search", params=dict(ps=500))

    if debug:
        with open("metrics.json", "w") as f:
            f.write(json.dumps(available_metrics))

    return {metric["key"]: metric for metric in available_metrics["metrics"]}


def get_sonar_measures_data(
    sonarqube_url: str,
    sonar_project_key: str,
    metric_names: list | None = None,
    debug: bool = False,
) -> list[dict]:
    """Get the SonarQube measures data for a project."""
    available_metrics_by_key = get_available_metrics(sonarqube_url)

    if metric_names is None:
        metric_names = list(available_metrics_by_key.keys())

    data = sonar_api_get(
        sonarqube_url,
        "api/measures/component",
        params=dict(
            metricKeys=",".join(metric_names),
            component=sonar_project_key,
            # branches can not be used with the community edition! we always report the main branch, which is the correct case for main tag
            # branch=".."
        ),
    )

    if debug:
        with open("measures.json", "w") as f:
            f.write(json.dumps(data))

    measures = data["component"]["measures"]

    metrics_data = []
    for measure in measures:
        if value := measure.get("value"):
            metrics_data.append({"Metric": measure["metric"], "Value": value})

    return metrics_data


def get_sonar_issues_data(
    sonarqube_url, sonar_project_key, debug: bool = False
) -> list[dict]:
    """Get the SonarQube issues data for a project."""
    issues = sonar_api_get(
        sonarqube_url,
        "api/issues/search",
        params=dict(
            componentKeys=sonar_project_key,
            # branches can not be used with the community edition! we always report the main branch
            # branch=branch
        ),
    )

    if debug:
        with open("issues.json", "w") as f:
            f.write(json.dumps(issues))

    issues_table_data = []
    for issue in issues["issues"]:
        # TODO: put details for all issues
        if issue["status"] == "OPEN" and issue["severity"] not in ["INFO", "MINOR"]:
            issues_table_data.append(
                {
                    "Rule": issue["rule"],
                    "Severity": issue["severity"],
                    "Message": issue["message"],
                }
            )

    return issues_table_data


def get_sonar_project_analyses(
    sonarqube_url: str,
    sonar_project_key: str,
    current_revision: str,
    debug: bool = False,
) -> dict:
    """Get the SonarQube analyses for a project."""
    # TODO: use in the future
    logging.warning("current_revision %s is currently ignored", current_revision)

    analyses = sonar_api_get(
        sonarqube_url,
        "api/project_analyses/search",
        params=dict(
            project=sonar_project_key,
        ),
    )

    if debug:
        with open("analyses.json", "w") as f:
            f.write(json.dumps(analyses))

    return analyses


def get_qualitygate_status(
    sonarqube_url: str,
    sonar_project_key: str,
    branch: str | None = None,
    pull_request: int | None = None,
    debug: bool = False,
) -> str:
    """Get the SonarQube quality gate status for a project."""
    params: dict[str, str | int] = dict(
        projectKey=sonar_project_key,
    )

    if pull_request is not None:
        params["pullRequest"] = pull_request
    # pull request is a priority
    elif branch is not None:
        params["branch"] = branch

    qualitygate = sonar_api_get(
        sonarqube_url,
        "api/qualitygates/project_status",
        params=params,
    )

    if debug:
        with open("qualitygate_status.json", "w") as f:
            f.write(json.dumps(qualitygate))

    return qualitygate


@lru_cache
def get_project_names_by_key(sonarqube_url: str, debug: bool = False) -> dict:
    """Get the SonarQube project names by key."""
    components = sonar_api_get(
        sonarqube_url,
        "api/components/search",
        params=dict(
            qualifiers="TRK",
        ),
    )

    if debug:
        with open("components.json", "w") as f:
            f.write(json.dumps(components))

    return {component["key"]: component for component in components["components"]}


def sonar_url(
    sonarqube_url: str, sonar_project_key: str, pull_request: str = None
) -> str:
    """Get the SonarQube project URL."""
    if pull_request not in [None, ""]:
        return f"{sonarqube_url}/dashboard?id={sonar_project_key}&pullRequest={pull_request}"
    else:
        return f"{sonarqube_url}/dashboard?id={sonar_project_key}"


def generate(config):
    """Generate a LaTeX report from a SonarQube project."""
    debug = config.get("debug", False)

    project_sections = []
    gates = []

    for dependency_project in get_project_dicts(config):
        try:
            name, project_section, passed = generate_for_sonar_project(
                dependency_project, debug=debug
            )
            if passed:
                icon = r"\textcolor{success}{\faIcon{check-circle}}"
            else:
                icon = r"\textcolor{failure}{\faIcon{times-circle}}"
            gates.append({"Project": name, "Quality Gate": icon})
            project_sections.append(project_section)
        except Exception as e:
            logging.error("Failed to generate SonarQube report: %s", repr(e))

            if dependency_project.get("required", True):
                raise

            project_sections.append(
                "\\textbf{\\color{red}Failed to generate SonarQube report for project "
                + dependency_project["sonar_key"].replace("_", "\\_")
                + "}\\newline\\newline\n"
            )

    table = generate_latex_table(
        [
            dict(colname="Project"),
            dict(colname="Quality Gate", escape_latex=False, spec="Q[r]"),
        ],
        gates,
    )
    latex_content = table + "\n\n" + "\n\n".join(project_sections)
    logging.info(latex_content)

    return latex_content


def generate_for_sonar_project(config, debug=False) -> tuple[str, str, bool]:
    """Generate a LaTeX report from a SonarQube project."""
    logging.info("Generating SonarQube report for %s", config)

    sonar_project_key = config["sonar_key"]
    sonarqube_url = config["sonar_server"]

    # for sonar, this can be also a tag
    # TODO: see how is branch/tag is passed, maybe we can also pass commit the same way?
    if "sonar_branch" in config:
        branch = config["sonar_branch"]
        pull_request = None
    else:
        branch = config["ref_name"]
        pull_request = config.get("pull_request", None)

    # TODO: add gitlab urls
    project_name = get_project_names_by_key(sonarqube_url, debug=debug)[
        sonar_project_key
    ]["name"]

    project_version = config.get("application_version", "unknown")

    formatted_project_version = colorize_project_version(project_version)

    latex_content = f"\n\n\\subsection{{Project analysis: {project_name} (version {formatted_project_version})}}\n\n"

    latex_content += f"\\href{{https://gitlab.cta-observatory.org/{config['gitlab_path']}}}{{View GitLab project}}\\newline\\newline\n"

    try:
        qualitygate_status = get_qualitygate_status(
            sonarqube_url,
            sonar_project_key=sonar_project_key,
            branch=branch,
            pull_request=pull_request,
            debug=debug,
        )
    except requests.HTTPError as e:
        logging.error(
            "Failed to get quality gate status for project %s branch %s pull request %s: %s",
            sonar_project_key,
            branch,
            pull_request,
            e,
        )
        qualitygate_status = {}

    try:
        qualitygate_status_combined = qualitygate_status["projectStatus"]["status"]
        latex_content += "The project SonarQube quality gate status is: "
    except KeyError as e:
        logging.error("qualitygate_status is invalid (%s): %s", e, qualitygate_status)

        if config.get("allow_sonar_failures", True):
            return (
                project_name,
                (
                    "\\textbf{\\color{red}Failed to obtain sonarqube quality gate information for project "
                    + escape_latex(sonar_project_key)
                    + " branch "
                    + escape_latex(branch)
                    + " and pull request "
                    + escape_latex(str(pull_request))
                    + "}\\newline\\newline\n"
                ),
                False,
            )
        else:
            logging.error("SonarQube report generation is required, failing")
            raise

    if qualitygate_status_combined == "OK":
        gate_passed = True
        latex_content += f"\\textbf{{\\color{{success}}{qualitygate_status_combined}}}.\\newline\\newline\n"
    else:
        gate_passed = False
        latex_content += f"\\textbf{{\\color{{failure}}{qualitygate_status_combined}}}.\\newline\\newline\n"

    project_url = sonar_url(sonarqube_url, sonar_project_key, pull_request)
    latex_content += (
        f"\\href{{{project_url}}}{{View the project in SonarQube}}.\\newline\\newline\n"
    )

    metrics_by_key = get_available_metrics(sonarqube_url, debug=debug)

    latex_content += "\n\n\\subsubsection{QA metrics}\n\n"

    latex_content += generate_latex_table(
        [
            dict(colname="Metric", spec="X"),
            dict(colname="Value"),
            dict(colname="Threshold"),
            dict(colname="Status"),
        ],
        [
            {
                "Metric": metrics_by_key[condition["metricKey"]]["name"],
                "Value": condition.get("actualValue", "N/A"),
                "Threshold": condition.get("errorThreshold", "N/A"),
                "Status": condition.get("status", "N/A"),
            }
            for condition in qualitygate_status["projectStatus"]["conditions"]
        ],
    )

    sonar_issues = get_sonar_issues_data(sonarqube_url, sonar_project_key, debug=debug)

    latex_content += "\n\n\\subsubsection{Issues}\n\n"

    if sonar_issues:
        latex_content += (
            "The project has the following issues (excluding MINOR issues):"
        )
        latex_content += generate_latex_table(
            [
                dict(colname="Severity"),
                dict(colname="Message", spec="X"),
            ],
            sonar_issues,
        )
    else:
        latex_content += "SonarQube detected no issues in this project."

    return project_name, latex_content, gate_passed
