"""Generates LaTeX content summarizing code coverage information from a coverage XML file."""

import os
import xml.etree.ElementTree as ET  # noqa: N817


def get_args():
    """Get the command line arguments."""
    return [
        {
            "name": "coverage_xml_fn",
            "help": "The path to the coverage XML file.",
            "type": str,
            "nargs": "?",
        }
    ]


def parse_coverage_xml(xml_file):
    """
    Parse a coverage XML file and extract coverage information.

    Args:
        xml_file (str): Path to the coverage XML file.

    Returns
    -------
        tuple: A tuple containing:
            - lines_valid (int): Total number of valid lines.
            - lines_covered (int): Total number of covered lines.
            - line_rate (float): Overall line coverage rate.
            - packages (list of tuples): A list of tuples where each tuple contains:
                - package_name (str): The name of the package.
                - package_line_rate (float): The line coverage rate for the package.
    """
    if not os.path.exists(xml_file):
        raise FileNotFoundError(f"Coverage XML file not found: {xml_file}")

    tree = ET.parse(xml_file)
    root = tree.getroot()

    lines_valid = int(root.attrib["lines-valid"])
    lines_covered = int(root.attrib["lines-covered"])
    line_rate = float(root.attrib["line-rate"])

    packages = []
    for package in root.findall(".//package"):
        package_name = package.attrib["name"]
        package_line_rate = float(package.attrib["line-rate"])
        packages.append((package_name, package_line_rate))

    return lines_valid, lines_covered, line_rate, packages


def generate_latex_content(lines_valid, lines_covered, line_rate, packages):
    """
    Generate LaTeX formatted content summarizing code coverage information.

    Args:
        lines_valid (int): The total number of valid lines of code.
        lines_covered (int): The number of lines of code that are covered by tests.
        line_rate (float): The overall coverage rate as a float between 0 and 1.
        packages (list of tuples): A list of tuples where each tuple contains the package name (str)
                                   and its corresponding coverage rate (float).

    Returns
    -------
        str: A string containing the LaTeX formatted content.
    """
    latex_content = "\\begin{verbatim}\n"

    latex_content += f"Total Lines Valid: {lines_valid}\n"
    latex_content += f"Total Lines Covered: {lines_covered}\n"
    latex_content += f"Overall Coverage Rate: {line_rate:.2%}\n\n"

    for package_name, package_line_rate in packages:
        latex_content += (
            f"Package: {package_name}, Coverage rate: {package_line_rate:.2%} \n"
        )

    latex_content += "\\end{verbatim}\n"

    return latex_content


def generate(config):
    """
    Generate LaTeX content summarizing code coverage information.

    Args:
        test_artifact (str): Path to the coverage XML file.

    Returns
    -------
        str: A string containing the LaTeX formatted content.
    """
    test_artifact = config["coverage_xml_fn"]

    lines_valid, lines_covered, line_rate, packages = parse_coverage_xml(test_artifact)
    return generate_latex_content(lines_valid, lines_covered, line_rate, packages)
