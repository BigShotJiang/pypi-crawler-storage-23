"""Generate a LaTeX report from a pylint output file in json2 format file."""

import json
import logging
from pathlib import Path
from textwrap import dedent


def get_args():
    """Get the command line arguments."""
    return [
        {
            "name": "pylint_report_fn",
            "help": "The path to the pylint report.",
            "type": str,
            "nargs": "?",
        }
    ]


def generate(config: dict):
    """Generate a LaTeX report from a pylint output in json2 format."""
    logging.info("Generating pylint report from %s", config["pylint_report_fn"])
    path = Path(config["pylint_report_fn"])
    if not path.is_file():
        content = "The code in this project was not analyzed by pylint"
    else:
        try:
            report = json.loads(path.read_text())
            rating = report["statistics"]["score"]

            content = f"The code in this project has been rated at {rating}."

        except (json.JSONDecodeError, KeyError) as e:
            content = f"Error reading pylint report: {e}"

    latex_content = dedent(
        f"""
        \\section{{Pylint Report}}
        \\begin{{verbatim}}
        {content}
        \\end{{verbatim}}
    """
    )

    return latex_content
