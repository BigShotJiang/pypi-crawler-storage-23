"""Generates dependencies tables."""

import logging

from aivkit.autoreport.coderevision import colorize_project_version
from aivkit.autoreport.latex import generate_latex_table


def generate(config):
    """Generate a dependencies table."""
    rows = []

    for dependency in config["dependencies"]:
        logging.info("Generating dependency row %s", dependency)
        row = {
            "Version": colorize_project_version(dependency["application_version"]),
            "Component": dependency["application_name"],
            "Gitlab Project": f'\\href{{{dependency["gitlab_url"]}}}{{{dependency["gitlab_name"]}}}',
            "pyproject name": dependency.get("pyproject_name", ""),
            "Helm name": dependency.get("helm_name", ""),
        }
        rows.append(row)

    return generate_latex_table(
        [
            dict(
                colname="Component",
                spec="X[l]",
            ),
            dict(
                colname="Gitlab Project",
                escape_latex=False,
                spec="X[l]",
            ),
            dict(
                colname="Helm name",
            ),
            dict(
                colname="pyproject name",
                spec="X[l]",
            ),
            dict(
                colname="Version",
                escape_latex=False,
            ),
        ],
        rows,
    )
