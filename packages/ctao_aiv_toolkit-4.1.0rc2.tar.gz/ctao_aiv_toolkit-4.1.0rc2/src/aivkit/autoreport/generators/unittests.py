"""Generate a LaTeX report from a unittests XML test report."""

import logging
from textwrap import dedent

from ..latex import generate_latex_table
from ..tests import collect_tests_xml


def get_args():
    """Get the command line arguments."""
    return [
        {
            "name": "test_report_xml_fn",
            "help": "The path to the unittests XML file.",
            "type": str,
            "nargs": "?",
        }
    ]


def is_unit_test(test):
    """Decide if test is a unit test or not."""
    return (
        len(test.get("requirement_ids", [])) == 0
        and len(test.get("usecase_ids", [])) == 0
    )


def summarize_unit_tests(tests):
    """Summarize unit tests."""
    unit_tests = list(filter(is_unit_test, tests))
    return {
        "total": len(unit_tests),
        "passed": sum(1 for test in unit_tests if test["test_status"] == "passed"),
        "failed": sum(1 for test in unit_tests if test["test_status"] == "failed"),
    }


def generate_latex_content(tests, unittest_table_max_length):
    """Generate LaTeX content for the unittests report."""
    unit_tests = list(filter(is_unit_test, tests))

    if len(unit_tests) == 0:
        return "\\textbf{No unit tests found.}"
    elif len(unit_tests) > unittest_table_max_length:
        logging.warning(
            "Too many unit tests (%d) to display in a table, summarizing instead.",
            len(unit_tests),
        )
        return dedent("""\
            \\textbf{{Unit Tests Summary:}}
            This report contains more than {unittest_table_max_length:d} unit tests, so only a summary is provided.
            \\begin{{itemize}}
            \\item Total Unit Tests: {total:d}
            \\item Passed: {passed:d}
            \\item Failed: {failed:d}
            \\end{{itemize}}
            """).format(
            **summarize_unit_tests(unit_tests),
            unittest_table_max_length=unittest_table_max_length,
        )
    else:
        table_columns = [
            {"title": "Test Group Name", "colname": "test_class"},
            {"title": "Test Name", "colname": "test_name", "spec": "X"},
            {"title": "Status", "colname": "test_status"},
        ]
        return generate_latex_table(table_columns, unit_tests)


def generate(config):
    """Generate a LaTeX report from a JUnit-style XML test report."""
    latex_content = generate_latex_content(
        collect_tests_xml(config),
        unittest_table_max_length=config.get("unittest_table_max_length", 300),
    )
    return latex_content
