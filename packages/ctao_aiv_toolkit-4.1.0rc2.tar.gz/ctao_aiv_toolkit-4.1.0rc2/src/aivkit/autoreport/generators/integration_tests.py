"""Generate a LaTeX report from an integration tests XML test report."""

import logging
from collections import Counter, defaultdict
from functools import partial
from textwrap import dedent

from ..latex import escape_latex, generate_latex_table
from ..releaseplan import get_release_plan_uclist
from ..tests import collect_tests_xml
from ..ucreqids import shorten_uc_id
from .traceability_matrix import (
    to_full_uc_id,
)

UC_STATUS_COLORS = {
    "full": "success",
    "missing": "failure",
    "partial": "orange",
}


def get_args():
    """Get the command line arguments."""
    return [
        {
            "name": "test_report_xml_fn",
            "help": "The path to the integration tests XML file.",
            "type": str,
            "nargs": "?",
        }
    ]


def format_test_job_url(test):
    """Format the test job URL."""
    # TODO: restore; note that there is bug, "is" takes precedence over walrus, and url becomes True
    # if (url := test.get("job_url")) is not None:
    # if url := test.get("job_url") is not None:
    #    return f"\\href{{{url}}}{{{test['test_status']}}}"

    return test["test_status"]


def uc_revision_current_column_value(row):
    """Format the new/rev column value."""
    if row.get("is_revised"):
        return "Rev."
    elif row.get("is_current_release"):
        return "New"


def normalize_uc_ids_in_tests(test: dict, system: str):
    """Normalize UC IDs in the tests to the full format."""
    if "usecase_ids" in test:
        try:
            test["usecase_ids"] = [
                to_full_uc_id(uc, system) for uc in test["usecase_ids"]
            ]
        except ValueError as e:
            logging.exception(
                "Error normalizing usecase_ids: %s for test %s",
                test["usecase_ids"],
                test,
                exc_info=e,
            )
            raise

    return test


def uc_implementation_status(uc):
    """Get UC implementation status.

    A use case is implemented if all tests assigned to that use case
    are passing. It is partially implemented, if there is at least
    one test passing but not all. Otherwise it is not implemented.
    """
    if uc["n_test_cases"] > 0 and uc["n_test_cases_passed"] > 0:
        if uc["n_test_cases"] == uc["n_test_cases_passed"]:
            return "full"
        else:
            return "partial"
    else:
        return "missing"


def format_uc_status(uc):
    """Add color to uc status for table."""
    status = uc["status"]
    color = UC_STATUS_COLORS[status]
    return r"\textcolor{" + color + "}{" + uc["status"] + "}"


def format_uc_ids(test, release_uc_ids, system):
    """Remove system prefix and make single string from list of ids."""
    uc_ids = []

    for uc_id in test["usecase_ids"]:
        formatted_uc_id = escape_latex(shorten_uc_id(uc_id, system))

        # mark use cases of the current release in bold
        if uc_id in release_uc_ids:
            formatted_uc_id = r"\textbf{" + formatted_uc_id + "}"

        uc_ids.append(formatted_uc_id)

    return ", ".join(uc_ids)


def fill_test_information(ucs, tests):
    """Add test summary information to use cases."""
    passed = defaultdict(int)
    total = defaultdict(int)

    for test in tests:
        for uc_id in test["usecase_ids"]:
            total[uc_id] += 1
            passed[uc_id] += test["test_status"] == "passed"

    for uc in ucs:
        uc["n_test_cases"] = total[uc["id"]]
        uc["n_test_cases_passed"] = passed[uc["id"]]
        uc["status"] = uc_implementation_status(uc)


def get_release_completion_stats(ucs):
    """Get the number of completed UCs and requirements in the current release."""
    counts = Counter(uc["status"] for uc in ucs)
    return dict(
        partial=counts["partial"],
        full=counts["full"],
        total=len(ucs),
    )


def generate(config):
    """Generate a LaTeX report from an integration tests XML test report."""
    system = config["aiv_system"]
    tests = collect_tests_xml(config)

    release_ucs = get_release_plan_uclist(config)

    integration_tests = [
        normalize_uc_ids_in_tests(test, system)
        for test in tests
        if len(test.get("usecase_ids", [])) > 0
    ]

    fill_test_information(release_ucs, integration_tests)

    logging.info("total ucs %d", len(integration_tests))
    for uc in release_ucs:
        logging.info("found uc: %s", uc)

    logging.info("total integration tests %d", len(integration_tests))
    for test in integration_tests:
        logging.info("found integration test: %s", test)

    uc_table_columns = [
        dict(colname="UC ID", gen=lambda uc: shorten_uc_id(uc["id"], system=system)),
        dict(title="Name", colname="name", spec="X[l]"),
        dict(colname=r"Rev.\TblrNote{1}", gen=uc_revision_current_column_value),
        dict(colname="TCs", gen=lambda r: str(r["n_test_cases"]), spec="Q[r]"),
        dict(
            colname=r"\faIcon{check}",
            gen=lambda r: str(r["n_test_cases_passed"]),
            spec="Q[r]",
        ),
        dict(colname="Status", gen=format_uc_status, escape_latex=False),
    ]

    uc_table = generate_latex_table(
        uc_table_columns,
        release_ucs,
        table_options="note{1}={UC revision status, new means added in this release, rev. means use case has been revised from the version in an earlier release.}",
    )
    uc_table = r"{\small" + uc_table + "\n}"

    release_uc_ids = {uc["id"] for uc in release_ucs}
    test_table_columns = [
        dict(title="Project", colname="project"),
        dict(title="Test Case ID", colname="test_name", spec="X[3,l]"),
        dict(
            colname="UCs",
            gen=partial(format_uc_ids, release_uc_ids=release_uc_ids, system=system),
            spec="X[1,l]",
            escape_latex=False,
        ),
        dict(
            colname="Result",
            gen=format_test_job_url,
            escape_latex=False,
        ),
    ]
    test_table = generate_latex_table(test_table_columns, integration_tests)

    stats = get_release_completion_stats(release_ucs)
    logging.info(
        "UCs (full, partial, total): %d / %d / %d",
        stats["full"],
        stats["partial"],
        stats["total"],
    )
    has_partial = stats["partial"] > 0
    partial_ucs = f"{stats['partial']} partially completed," if has_partial else ""
    summary = dedent(f"""
    Use case summary: {partial_ucs}
    {stats["full"]} completed
    of {stats['total']} total.
    """)
    uc_heading = dedent(r"""\section{Use Case Verification Status}

    The table contains all Use Cases tested in \ComputingSystem{} Release \ComputingSystemReleaseTarget{}.
    This includes the Use Cases added in \ComputingSystemReleaseTarget{} as well as
    the Use Cases already present in the previous release,
    following \citeapplicable{\ReferenceReleasePlan}.
    """)

    test_heading = dedent(r"""
    \section{Tests directly linked to Use Cases and Requirements}

    This section lists automated integration tests that verify the behavior of the entire \ApplicationName{} system.
    These tests directly verify \ComputingSystem{} Use Cases. % and Requirements.

    Use cases of the current release are highlighted in bold.
    """)

    return "\n\n".join([uc_heading, summary, uc_table, test_heading, test_table])
