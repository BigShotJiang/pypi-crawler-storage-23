"""Generates dependencies tables, detailed."""

import logging

from aivkit.autoreport.coderevision import colorize_project_version
from aivkit.autoreport.latex import escape_latex, generate_latex_table


def generate(config):
    """Generate a detailed dependencies table."""
    rows = []

    all_python_dependencies = config.get("python_dependencies", [])
    all_helm_dependencies = config.get("helm_dependencies", [])

    for dependency in config["dependencies"]:
        # this accumulates python dependencies from all repository AIV dependencies
        for python_dependency in dependency.get("python_dependencies", []):
            all_python_dependencies.append(
                {**python_dependency, "parent_project": dependency["gitlab_short_name"]}
            )

        for helm_dependency in dependency.get("helm_dependencies", []):
            all_helm_dependencies.append(
                {**helm_dependency, "parent_project": dependency["gitlab_short_name"]}
            )

    for dependency in config["dependencies"]:
        # formats the AIV dependencies into rows
        rows.append(
            {
                "Dependency": dependency["application_name"],
                "Version": colorize_project_version(dependency["application_version"]),
                "Group": "AIV",
                "Project": config["gitlab_short_name"],
            }
        )

    # formats the python dependencies and helm dependencies into rows
    for python_dependency in all_python_dependencies:
        logging.info("Generating detailed dependency row python %s", python_dependency)
        row = {
            "Dependency": python_dependency["name"],
            "Version": escape_latex(python_dependency["version"]),
            "Project": python_dependency["parent_project"],
            "Group": "Python",
        }

        logging.info("Row: %s", row)

        if row not in rows:
            rows.append(row)

    for helm_dependency in all_helm_dependencies:
        logging.info("Generating dependency row helm %s", helm_dependency)
        row = {
            "Dependency": helm_dependency["name"],
            "Version": colorize_project_version(helm_dependency["version"]),
            "Project": helm_dependency["parent_project"],
            "Group": "Helm",
        }

        if row not in rows:
            rows.append(row)

    return generate_latex_table(
        [
            dict(
                colname="Group",
            ),
            dict(
                colname="Project",
                escape_latex=False,
            ),
            dict(
                colname="Dependency",
                spec="X",
            ),
            dict(
                colname="Version",
                escape_latex=False,
            ),
        ],
        sorted(rows, key=lambda r: r["Group"]),
    )
