"""Generates a detailed report for a SonarQube project."""

import logging

from ..latex import generate_latex_table
from .sonarqube import get_sonar_measures_data, sonar_url

__generator_disabled__ = True


def generate(config):
    """Generate a report for a SonarQube project."""
    code_revision_info = config.get("code_revision_info", {})
    branch = code_revision_info.get("branch")
    pull_request = code_revision_info.get("pull_request")
    sonar_project_key = config.get("sonar_project_key")
    sonarqube_url = config.get("sonar_server")
    debug = config.get("debug", False)

    latex_content = ""

    if branch != "main":
        logging.warning(
            "Detailed branch information requests are not supported in the community edition of SonarQube. Report will be generated for the main with a warning."
        )
        latex_content += (
            "\\textbf{\\color{red}WARNING: \\newline\n"
            "Detailed branch information requests are not supported in the community edition of SonarQube.\\newline\n"
            "The report is generated for the main branch. \\newline\n"
            "To view the branch-specific report, please consult \\href{"
            + sonar_url(sonar_project_key, pull_request)
            + "}{SonarQube UI} and Merge Request comments."
            "}\\newline\\newline\n"
        )

    latex_content += "The project has the following metrics:"
    latex_content += generate_latex_table(
        [
            dict(colname="Metric", spec="X"),
            dict(colname="Value"),
        ],
        get_sonar_measures_data(
            sonarqube_url=sonarqube_url,
            sonar_project_key=sonar_project_key,
            # ["alert_status", "coverage", "bugs", "vulnerabilities", "code_smells", "comment_lines_density"]
            debug=debug,
        ),
    )

    # TODO: use the latest analysis
    # project_analyses = get_sonar_project_analyses(
    #     sonar_project_key, current_revision, debug=debug
    # )

    return latex_content
