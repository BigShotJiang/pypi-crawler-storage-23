"""Generates release reports."""
