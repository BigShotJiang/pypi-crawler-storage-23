"""Code revision information."""

from packaging.version import InvalidVersion, Version

from aivkit.autoreport.latex import escape_latex


def _bold_color(text, color):
    return f"\\textbf{{\\color{{{color}}}{escape_latex(text)}}}"


def colorize_project_version(project_version: str) -> str:
    """Colorize the project version according to the version format, red/orange for non-standard versions."""
    try:
        version = Version(project_version)
    except InvalidVersion:
        return _bold_color(project_version, "red")

    # no special markup for proper releases
    if not (version.is_prerelease or version.is_devrelease):
        return project_version

    # release candidates in orange
    if version.pre is not None and version.pre[0] == "rc":
        return _bold_color(project_version, "orange")

    # everything else in red
    return _bold_color(project_version, "red")
