"""Client for interacting with items in Jama."""

import json
import logging

import requests

from .session import api_url


def assert_one_and_only_one(*args):
    """Assert that exactly one of the arguments is truthy."""
    if sum(bool(arg) for arg in args) != 1:
        raise ValueError("Exactly one argument must be truthy.")


def populate_item_recursively(
    item,
    session: requests.Session,
    add_tags=True,
    add_relationships=True,
    recursion_direction="upstream",
):
    """Populate an item in-place with its details, tags, and relationships."""
    logging.info(
        "Populating item %s %s", item["id"], item.get("fields", {}).get("name", "")
    )
    logging.debug("Item before population: %s", json.dumps(item, indent=2))

    if add_tags:
        response = session.get(f"{api_url()}/items/{item['id']}/tags")
        response.raise_for_status()

        item["tags"] = [tag["name"] for tag in response.json()["data"]]

    if add_relationships:
        item["relationships"] = {}

        for kind in ["upstream", "downstream"]:
            logging.debug("Fetching %s relationships for item %s", kind, item["id"])
            response = session.get(
                f"{api_url()}/items/{item['id']}/{kind}relationships"
            )
            response.raise_for_status()

            item["relationships"][kind] = response.json()["data"]

            for rel in item["relationships"][kind]:
                logging.debug(
                    "Relationship %s: %s",
                    rel["id"],
                    json.dumps(rel, indent=2),
                )
                item_id = rel["fromItem" if kind == "upstream" else "toItem"]
                rel["related_item"] = session.get(f"{api_url()}/items/{item_id}").json()

                if recursion_direction == kind:
                    populate_item_recursively(rel["related_item"]["data"], session)


def get_items_with_pagination(
    session, url, root_only=False, add_tags=False, add_relationships=False
):
    """Get items from a URL with pagination."""
    items = []

    start_at = 0
    max_results = 50

    while True:
        response = session.get(
            url,
            params={
                "startAt": start_at,
                "maxResults": max_results,
                "rootOnly": root_only,
            },
        )

        if response.status_code != 200:
            logging.error("Failed to get items from %s: %s", url, response.text)
            response.raise_for_status()

        for item in response.json()["data"]:
            logging.debug("%d  item json: %s", len(items), json.dumps(item, indent=2))
            logging.debug(
                "%d  item: %s %s",
                len(items),
                item.get("fields", {}).get("name"),
                item["id"],
            )

            populate_item_recursively(item, session, add_tags, add_relationships)

            items.append(item)

        if len(response.json()["data"]) < max_results:
            break

        start_at += max_results

    return items


def one_and_only_one_item(items: list, filter_func):
    """Assert that there is exactly one item in the list."""
    if filter_func is not None:
        items = [item for item in items if filter_func(item)]

    if len(items) != 1:
        raise ValueError(f"Expected one item, found {len(items)} items.")

    return items[0]


def named_item_from_item_list(items: list, name: str):
    """Get an item with a specific name from a list of items."""
    item = one_and_only_one_item(
        items,
        lambda item: item.get("fields", {}).get("name") == name
        or item.get("name") == name,
    )

    logging.debug("Found item with name %s: %s", name, json.dumps(item, indent=2))

    return item


def get_all_tags(s, project_id):
    """Get all tags for a specific project."""
    url = (
        f"{api_url()}/projects/{project_id}/tags" if project_id else f"{api_url()}/tags"
    )
    return get_items_with_pagination(s, url)


def select_by_parent_id_or_name(s, item, parent_id=None, parent_name=None):
    """Select an item by its parent's ID or name."""
    if parent_id is not None and parent_name is not None:
        raise ValueError("Specify at most one of parent_id or parent_name.")

    item_parent_id = item["location"]["parent"]["item"]

    if parent_id is not None:
        return item_parent_id == parent_id
    elif parent_name is not None:
        item_parent_name = get_item_by_id(s, item_parent_id)["data"]["fields"]["name"]
        return item_parent_name == parent_name
    else:
        return True


def get_tagged_items(s, project_id, tag, selector=None):
    """Get all items tagged with a specific tag."""
    tag_id = named_item_from_item_list(get_all_tags(s, project_id), tag)["id"]

    url = f"{api_url()}/tags/{tag_id}/items"

    return [
        item
        for item in get_items_with_pagination(
            s, url, add_tags=True, add_relationships=True
        )
        if selector is None or selector(item)
    ]


def get_item_by_id(s, item_id):
    """Get a specific item by its ID."""
    logging.debug("Fetching item by ID: %s", item_id)
    r = s.get(f"{api_url()}/items/{item_id}")
    r.raise_for_status()

    return r.json()


def compute_subtree_path_names(jama_session, item) -> list[str]:
    """Compute the path of subtree names for an item."""
    subtree_names = []

    logging.debug("Computing subtree path names for item %s", item)

    while True:
        parent_item = item["location"]["parent"].get("item")
        if parent_item is None:
            break
        item = get_item_by_id(jama_session, parent_item)
        subtree_names.append(item["data"]["fields"]["name"])
        item = item["data"]

    return subtree_names
