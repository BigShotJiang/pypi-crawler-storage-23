"""Jama API client."""

import logging
import os

import requests

log = logging.getLogger(__name__)
jama_server = "https://jama.cta-observatory.org"
token_url = f"{jama_server}/rest/oauth/token"
jama_gateway = "https://jama-gateway.cta-test.zeuthen.desy.de"


def use_gateway():
    """Determine whether gateway or main server should be used."""
    return "JAMA_GATEWAY_PASSWORD" in os.environ


def api_url():
    """Return the URL for the jama rest API.

    If gateway credentials are defined in the environment, gateway is used, else main server.
    """
    if use_gateway():
        server = jama_gateway
    else:
        server = jama_server

    return f"{server}/rest/v1"


def get_session(s=None):
    """Get a requests session with the necessary headers for the Jama API.

    Jama API is rather slow, so we use a cached session by default.
    """
    if s is None:
        s = requests.session()
        s.headers["Accept"] = "application/json"

        try:
            s.auth = load_jama_gateway_credentials()
            return s
        except Exception as e:
            log.error(
                "Error loading jama gateway credentials, falling back to direct jama access: %s",
                e,
            )

        try:
            token = get_token()
            s.headers["Authorization"] = f"Bearer {token}"
            log.warning(
                "Using direct jama API access, consider switching to using jama gateway"
            )
        except Exception:
            raise OSError(
                "Could not load any jama API credentials. Please set JAMA_GATEWAY_USER and JAMA_GATEWAY_PASSWORD."
            )

    return s


def load_jama_gateway_credentials():
    """Load the credentials for the jama gateway."""
    if (
        "JAMA_GATEWAY_USER" not in os.environ
        or "JAMA_GATEWAY_PASSWORD" not in os.environ
    ):
        raise OSError(
            "JAMA_GATEWAY_USER and JAMA_GATEWAY_PASSWORD environment variables must be set."
        )

    return os.environ["JAMA_GATEWAY_USER"], os.environ["JAMA_GATEWAY_PASSWORD"]


def load_jama_credentials():
    """Load Jama credentials from environment variables."""
    if "JAMA_CLIENT_ID" not in os.environ or "JAMA_CLIENT_SECRET" not in os.environ:
        raise OSError("Jama client ID and secret must be set in environment variables.")

    return os.environ["JAMA_CLIENT_ID"], os.environ["JAMA_CLIENT_SECRET"]


def get_token():
    """Get an access token for the Jama API."""
    auth = load_jama_credentials()

    ret = requests.post(
        token_url,
        auth=auth,
        data={"grant_type": "client_credentials"},
        headers={"Accept": "application/json"},
    )
    ret.raise_for_status()
    return ret.json()["access_token"]
