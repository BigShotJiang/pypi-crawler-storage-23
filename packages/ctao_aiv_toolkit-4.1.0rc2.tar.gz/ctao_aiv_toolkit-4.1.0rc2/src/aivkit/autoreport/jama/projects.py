"""Projects management in Jama server."""

import logging

from aivkit.autoreport.jama.base import get_projects


def list_projects(s):
    """List all projects in the Jama server."""
    result = get_projects(s)
    for project in result:
        logging.info("project: %s %s", project["fields"]["name"], project["id"])
