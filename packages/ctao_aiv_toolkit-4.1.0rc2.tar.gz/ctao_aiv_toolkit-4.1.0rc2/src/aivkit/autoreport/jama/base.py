"""Jama API client."""

import logging

from .session import api_url


def get_generalized_product_id(item):
    """Get the generalized product ID from an item."""
    for product_id_name in [
        "product_id$62",
        "addressed_product_id$65",
    ]:
        if product_id_name in item["fields"]:
            return item["fields"][product_id_name]


def get_projects(session):
    """Get all projects from the Jama server."""
    r = session.get(f"{api_url()}/projects")

    if not r.ok:
        logging.error("Failed to get projects from Jama: %s", r.text)
        r.raise_for_status()

    for project in r.json()["data"]:
        logging.info("project: %s %s", project["fields"]["name"], project["id"])

    return r.json()["data"]


def get_tags(session, project_id):
    """Get all tags from the Jama server."""
    r = session.get(f"{api_url()}/tags", params={"project": project_id})

    logging.info("Tags in Jama: %s", r.json())

    for tag in r.json()["data"]:
        logging.info("tag: %s", tag)

    return r.json()["data"]
