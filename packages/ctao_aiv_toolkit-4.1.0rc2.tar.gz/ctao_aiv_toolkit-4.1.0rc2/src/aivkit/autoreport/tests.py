"""Gathers test results from a JUnit-style XML test report."""

import logging
import xml.etree.ElementTree as ET

from aivkit.gitlab import get_gitlab_job_info_for_ref  # noqa: N817


def parse_tests_xml(xml_file_path: str) -> list:
    """
    Parse a JUnit-style XML test report and extract test case information.

    Args:
        xml_file (str): Path to the XML file containing the test report.

    Returns
    -------
        list of tuple: A list of tuples where each tuple contains:
            - test_class (str): The name of the test class.
            - test_name (str): The name of the test case.
            - test_status (str): The status of the test case, which can be 'passed', 'failed', or 'skipped'.
    """
    logger = logging.getLogger("parse_tests_xml")

    tree = ET.parse(xml_file_path)
    root = tree.getroot()

    tests = []
    for testcase in root.findall(".//testcase"):
        logger.debug("found test %s", testcase.attrib)

        test_name = testcase.attrib["name"].replace("test_", "", 1)
        full_classname = testcase.attrib["classname"]
        test_class = full_classname.split(".")[-1]
        failure = testcase.find("failure") is not None
        error = testcase.find("error") is not None
        skipped = testcase.find("skipped") is not None

        requirement_ids = []
        usecase_ids = []
        properties = testcase.find("properties")
        if properties is not None:
            for prop in properties.findall("property"):
                logger.debug("property %s", prop.attrib)
                if prop.attrib["name"] == "requirement_id":
                    requirement_ids.append(prop.attrib["value"])
                elif prop.attrib["name"] == "usecase_id":
                    usecase_ids.append(prop.attrib["value"])
        logger.debug("requirement_ids %s", requirement_ids)
        logger.debug("usecase_ids %s", usecase_ids)

        if failure or error:
            test_status = "failed"
        elif skipped:
            test_status = "skipped"
        else:
            test_status = "passed"

        tests.append(
            dict(
                test_class=test_class,
                test_name=test_name,
                test_status=test_status,
                requirement_ids=requirement_ids,
                usecase_ids=usecase_ids,
            )
        )

    return tests


def collect_tests_xml(config: dict) -> list:
    """Collect test results from a JUnit-style XML test reports of all dependencies."""
    this_pipeline_test_job_info = get_gitlab_job_info_for_ref(
        config["gitlab_path"], config["ref_name"], "test"
    )

    tests = parse_tests_xml(config["test_report_xml_fn"])
    for test in tests:
        test["project"] = config["application_name"]
        test.update(this_pipeline_test_job_info)
        # test["job_url"] = config["test_report_xml_job_url"]

    for dependency in config.get("dependencies", []):
        logging.info(
            "Loading xml test report from dependency %s", dependency["gitlab_path"]
        )

        # TODO: replace with project short name
        project = dependency["gitlab_path"].split("/")[-1]

        test_artifacts = dependency["artifacts"]["test"]

        if test_artifacts is not None:
            dep_tests = parse_tests_xml(test_artifacts["report.xml"]["fn"])
            for test in dep_tests:
                test["project"] = project
                test["job_url"] = test_artifacts["report.xml"]["job_url"]
                tests.append(test)

    if config.get("deployment_ucs", "") != "":
        for deployment_uc in config["deployment_ucs"].split(","):
            tests.append(
                {
                    "test_class": "deployment",
                    "test_name": "deployment",
                    "test_status": "passed",
                    "usecase_ids": [deployment_uc],
                    "requirement_ids": [],
                    **this_pipeline_test_job_info,
                }
            )

    return tests
