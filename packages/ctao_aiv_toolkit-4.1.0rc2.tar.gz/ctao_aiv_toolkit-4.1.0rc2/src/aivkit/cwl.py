"""Patch CWL files to add DockerRequirement hints."""

import argparse
import logging

from ruamel.yaml import YAML

parser = argparse.ArgumentParser(
    description="Operations for processing DPPS CWL files."
)

parser.add_argument(
    "-v",
    "--verbose",
    help="Print verbose output.",
    action="store_true",
    default=False,
)

subparsers = parser.add_subparsers(dest="operation", help="The operation to perform.")
subparser_path_image = subparsers.add_parser(
    "patch-image",
    help="Patch image files in CWL.",
    description="Patch image files in CWL.",
)

subparser_path_image.add_argument(
    "cwl_file",
    help="The path to the CWL file.",
    type=str,
)

subparser_path_image.add_argument(
    "image",
    help="The image to patch with.",
    type=str,
)


def req_docker_pull(cwl_yaml: dict) -> str | None:
    """Get the DockerRequirement dockerPull from the requirements section of the CWL YAML file."""
    return (
        cwl_yaml.get("requirements", {})
        .get("DockerRequirement", {})
        .get("dockerPull", None)
    )


def hint_docker_pull(cwl_yaml: dict) -> str | None:
    """Get the DockerRequirement dockerPull from the hints section of the CWL YAML file."""
    return (
        cwl_yaml.get("hints", {}).get("DockerRequirement", {}).get("dockerPull", None)
    )


def patch_image(cwl_yaml: dict, image: str) -> None:
    """Add a hint DockerRequirement image to the CWL YAML file. Raise an error if an image is already set."""
    cwl_class = cwl_yaml["class"]

    if req_docker_pull(cwl_yaml) is not None:
        raise ValueError(
            f'DockerRequirement is set in CWL as requirement (to "{req_docker_pull(cwl_yaml)}"), but it should be a hint. Will not patch, please fix the CWL file!'
        )

    if hint_docker_pull(cwl_yaml) is not None:
        if cwl_class != "CommandLineTool":
            raise ValueError(
                f'DockerRequirement is set in CWL as hint (to "{hint_docker_pull(cwl_yaml)}"), but the CWL class is "{cwl_class}", expected "CommandLineTool". Will not patch, please fix the CWL file!'
            )
        else:
            logging.warning(
                'DockerRequirement is already set in CWL as hint (to "%s"), will overwrite it with "%s"',
                hint_docker_pull(cwl_yaml),
                image,
            )

    if cwl_class == "CommandLineTool":
        logging.info(
            'Patching DockerRequirement hint in CWL CommandLineTool to "%s"', image
        )
        add_docker_hint(cwl_yaml, image)
    else:
        logging.info(
            "CWL class is %s, not CommandLineTool, will not add DockerRequirement hint.",
            cwl_class,
        )


def add_docker_hint(cwl_yaml: dict, image: str) -> None:
    """Add a hint DockerRequirement image to the CWL CommandLineTool YAML."""
    if "hints" not in cwl_yaml:
        cwl_yaml["hints"] = {}

    if "DockerRequirement" not in cwl_yaml["hints"]:
        cwl_yaml["hints"]["DockerRequirement"] = {}

    cwl_yaml["hints"]["DockerRequirement"]["dockerPull"] = image


def patch_image_in_file(cwl_file_path: str, image: str) -> None:
    """Patch the image in the CWL file, in-place."""
    yaml = YAML()
    yaml.preserve_quotes = True
    yaml.indent(mapping=2, sequence=4, offset=2)

    with open(cwl_file_path) as cwl_file:
        cwl_yaml = yaml.load(cwl_file)

    logging.debug("Loaded CWL YAML: %s", cwl_yaml)

    patch_image(cwl_yaml, image)

    with open(cwl_file_path, "w") as cwl_file:
        yaml.dump(cwl_yaml, cwl_file)


def main(args=None):
    """Patch CWL files."""
    args = parser.parse_args(args=args)

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)

    if args.operation == "patch-image":
        logging.info(
            "Patching image in CWL file %s with image %s", args.cwl_file, args.image
        )

        patch_image_in_file(args.cwl_file, args.image)


if __name__ == "__main__":
    main()
