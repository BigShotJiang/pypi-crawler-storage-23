"""Gitlab utilities."""

import base64
import glob
import logging
import os
import re
import subprocess
import tempfile
import zipfile
from io import BytesIO

import gitlab

from aivkit.git import (
    checkout_git_revision,
    get_private_token,
)


def get_gitlab():
    """Get a gitlab connection."""
    gl = gitlab.Gitlab(
        "https://gitlab.cta-observatory.org", private_token=get_private_token()
    )

    return gl


def get_gitlab_project(gitlab_repo: str):
    """Get a gitlab project."""
    gl = get_gitlab()

    try:
        project = gl.projects.get(gitlab_repo)
    except gitlab.exceptions.GitlabGetError as e:
        logging.error("Failed to get project %s: %s", gitlab_repo, e)
        raise

    return project


def match_gitlab_file(fn: str) -> re.Match | None:
    """Match a gitlab file URL."""
    r = re.match(
        r"^https://gitlab.cta-observatory.org/(?P<project>.*)/-/raw/(?P<ref>[a-zA-Z0-9._-]*)/(?P<file>.*)",
        str(fn),
    )
    if r:
        logging.info(
            "Matched GitLab file %s: project=%s, ref=%s, file=%s",
            fn,
            r.group("project"),
            r.group("ref"),
            r.group("file"),
        )
    else:
        logging.info("No match for GitLab file %s", fn)
    return r


def get_gitlab_file(gitlab_repo: str, gitlab_rev: str, file_path: str) -> str:
    """Get a file from a gitlab repository."""
    project = get_gitlab_project(gitlab_repo)

    logging.debug(
        "Getting file %s from %s, project %s, gitlab_rev: %s",
        file_path,
        gitlab_repo,
        project,
        gitlab_rev,
    )

    try:
        file_data = project.files.get(file_path, ref=gitlab_rev)
    except gitlab.exceptions.GitlabGetError as e:
        logging.info(
            "Failed to get file %s from revision %s of project %s: %s",
            file_path,
            gitlab_rev,
            gitlab_repo,
            e,
        )
        raise FileNotFoundError
    else:
        content = base64.b64decode(file_data.content).decode()

        logging.debug("Downloaded artifact file of %s", len(content))

        return content

    # gitlab_url = f"https://gitlab.cta-observatory.org/{gitlab_repo}/-/raw/{gitlab_rev}/{file_path}"
    # logging.debug("Getting file from %s", gitlab_url)
    # r = requests.get(gitlab_url, headers={"PRIVATE-TOKEN": get_private_token()})
    # r.raise_for_status()
    # return r.text


def get_artifact_file(gitlab_repo: str, gitlab_rev: str, job_name: str) -> dict | None:
    """Get an artifact from a gitlab repository."""
    project = get_gitlab_project(gitlab_repo)

    logging.debug(
        "Getting artifact from %s, project %s, gitlab_rev: %s, job name %s",
        gitlab_repo,
        project.id,
        gitlab_rev,
        job_name,
    )

    try:
        artifact_data = project.artifacts.download(ref_name=gitlab_rev, job=job_name)
        logging.info("artifact of %s kb", len(artifact_data) / 1024)

    except gitlab.exceptions.GitlabGetError as e:
        logging.warning(
            "No artifact found for job %s in revision %s of project %s: %s",
            job_name,
            gitlab_rev,
            gitlab_repo,
            e,
        )
        return None

    else:
        basedir = os.getenv("BUILD_DIR", os.getenv("TMPDIR", "/tmp"))
        directory_to_extract_to = os.path.join(
            basedir, "aivkit", "artifacts", gitlab_repo, gitlab_rev, job_name
        )

        try:
            with zipfile.ZipFile(BytesIO(artifact_data), "r") as zip_ref:
                zip_ref.extractall(directory_to_extract_to)
        except zipfile.BadZipFile as e:
            logging.error("Failed to extract zip file: %s", e)
            raise

        job_artifacts = {}

        for subfn in glob.glob(f"{directory_to_extract_to}/*"):
            logging.info("Downloaded artifact %s", subfn)
            filename = os.path.basename(subfn)

            job_info = get_gitlab_job_info_for_ref(gitlab_repo, gitlab_rev, job_name)

            job_artifacts[filename] = {
                "fn": subfn,
                # TODO: get the URL from the job we downloaded the artifact from?
                **job_info,
            }

            if job_artifacts[filename].get("job_url") is None:
                raise ValueError(
                    f"No job URL found for artifact, gitlab job info is {job_info}",
                )

        logging.info("Downloaded artifacts %s", job_artifacts)

        return job_artifacts


def get_test_artifacts(gitlab_repo: str, gitlab_rev: str):
    """Get the test artifacts from a gitlab repository."""
    r = get_artifact_file(gitlab_repo, gitlab_rev, "collect-test-artifacts")

    if r is not None:
        return r
    else:
        logging.warning(
            "No artifacts found for job `collect-test-artifacts` in revision %s of project %s, will try from job `test` (deprecated)",
            gitlab_rev,
            gitlab_repo,
        )
        r = get_artifact_file(gitlab_repo, gitlab_rev, "test")

        if r is not None:
            logging.warning(
                "Found artifacts for job `test` in revision %s of project %s, this is deprecated",
                gitlab_rev,
                gitlab_repo,
            )
            return r

        logging.warning(
            "No artifacts found for job `collect-test-artifacts` or `test` in revision %s of project %s",
            gitlab_rev,
            gitlab_repo,
        )


def get_job_log(gitlab_repo: str, gitlab_rev: str, job_name: str) -> dict | None:
    """Get the log of a job."""
    project = get_gitlab_project(gitlab_repo)

    logging.debug(
        "Getting job log from %s, project %s, gitlab_rev: %s job name %s",
        gitlab_repo,
        project,
        gitlab_rev,
        job_name,
    )

    try:
        job = project.jobs.list(ref=gitlab_rev, per_page=1, name=job_name)[0]
    except IndexError:
        logging.warning(
            "No job found for job %s in revision %s of project %s",
            job_name,
            gitlab_rev,
            gitlab_repo,
        )
        return None

    try:
        job_log = job.trace()
    except gitlab.exceptions.GitlabGetError as e:
        logging.warning(
            "Failed to get job log for job %s in revision %s of project %s: %s",
            job_name,
            gitlab_rev,
            gitlab_repo,
            e,
        )
        return None

    return job_log


def get_local_full_version(cwd):
    """Get the full version of a local repository."""
    return (
        subprocess.check_output(["git", "describe", "--tags", "--always"], cwd=cwd)
        .strip()
        .decode("utf-8")
    )


def get_repo_full_version(gitlab_repo: str, gitlab_rev: str) -> str:
    """Get the full version of a gitlab repository."""
    with tempfile.TemporaryDirectory() as tmpdir:
        logging.info("Cloning %s to %s", gitlab_repo, tmpdir)

        checkout_git_revision(gitlab_repo, gitlab_rev, tmpdir)

        return get_local_full_version(tmpdir)


def get_gitlab_job_info_for_ref(project_name, ref, job_name):
    """Get the job id for a specific job name and ref."""
    project = get_gitlab_project(project_name)

    logging.info("Getting job url for %s %s %s", project_name, ref, job_name)

    pipelines = project.pipelines.list(
        ref=ref, per_page=1, page=1, order_by="id", sort="desc"
    )

    if not pipelines:
        logging.info("No pipelines found for %s ref %s", project_name, ref)
        return {}

    logging.info("Found pipelines %s", pipelines)

    for pipeline in pipelines:
        for job in pipeline.jobs.list(iterator=True):
            if job.name == job_name:
                logging.info("Found job %s", job)
                return {
                    "job_commit": job.commit,
                    "job_id": job.id,
                    "job_url": job.web_url,
                }

    logging.info("Job %s not found in %s %s", job_name, project_name, ref)

    return {}
