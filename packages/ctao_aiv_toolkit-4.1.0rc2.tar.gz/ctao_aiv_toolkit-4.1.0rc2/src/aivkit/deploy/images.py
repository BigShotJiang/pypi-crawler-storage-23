"""Commands for deployment."""

import json
import logging
import multiprocessing
import pathlib
import subprocess as sp
import time
from functools import partial
from typing import NamedTuple

import aivkit
from aivkit.deploy.tools import kind_bin
from aivkit.runcmd import run_subprocess_tracing_logging

default_allowed_image_prefixes = [
    # CTAO-hosted images
    "harbor.cta-observatory.org",
    # these images are built-in in kind node image
    "registry.k8s.io/coredns/coredns",
    "registry.k8s.io/etcd",
    "registry.k8s.io/kube-apiserver",
    "registry.k8s.io/kube-controller-manager",
    "registry.k8s.io/kube-proxy",
    "registry.k8s.io/kube-scheduler",
    "docker.io/kindest/kindnetd",
    "docker.io/kindest/local-path-provisioner",
]


class PullResult(NamedTuple):
    """Result of pulling an image."""

    success: bool
    image: str
    size: float = 0.0  # Size in B
    duration: float = 0.0  # Duration in seconds
    attempts: int = 0  # number of attempts before succeeding


def pull_image(image: str, cluster_name: str, attempt: int) -> PullResult:
    """Pull image."""
    if image.endswith("dev"):
        logging.info("Skip pulling dev image: %s", image)
        return PullResult(success=True, image=image)

    logging.info("Pulling image %s in cluster %s", image, cluster_name)

    try:
        tstart = time.time()
        sp.run(
            [
                "docker",
                "exec",
                f"{cluster_name}-control-plane",
                "crictl",
                "pull",
                image,
            ],
            check=True,
        )
        tend = time.time()

        image_info = json.loads(
            sp.check_output(
                [
                    "docker",
                    "exec",
                    f"{cluster_name}-control-plane",
                    "crictl",
                    "inspecti",
                    image,
                ],
            ).decode()
        )

        logging.info(
            "Successfully pulled image %s of %.3f MB in cluster %s, time: %.3f seconds, bandwidth: %.3f MB/s",
            image,
            float(image_info["status"]["size"]) / 1024**2,
            cluster_name,
            tend - tstart,
            float(image_info["status"]["size"]) / 1024**2 / (tend - tstart),
        )
        return PullResult(
            success=True,
            image=image,
            size=float(image_info["status"]["size"]),
            duration=tend - tstart,
            attempts=attempt,
        )

    except sp.CalledProcessError as e:
        logging.error(
            "Failed to pull image %s in cluster %s: %s", image, cluster_name, e
        )
        return PullResult(success=False, image=image)


def preload_image(img, kind_cluster_name: str):
    """Pull an image to the host and load it into kind cluster.

    This avoids pulling the image from the internet multiple times from within kind nodes.
    This variation of pull_image is only useful if kind cluster is recreated multiple times on the same host, and a proxy is not used.
    So this is only useful for tests.

    In tests, it's not quite useful to start proxy for pulling images, since tests are testing kind cluster creation itself.
    """
    t0 = time.time()
    sp.run(
        [
            "docker",
            "pull",
            img,
        ],
        check=True,
    )
    logging.info("Pre-pulled image %s in %.1f seconds", img, time.time() - t0)

    t0 = time.time()
    r = sp.run(
        [
            kind_bin(),
            "load",
            "docker-image",
            "-n",
            kind_cluster_name,
            img,
        ],
        capture_output=True,
    )
    if r.returncode != 0:
        logging.error(
            "Failed to load image %s into kind cluster %s: %s",
            img,
            kind_cluster_name,
            r.stderr.decode(),
        )
        raise RuntimeError(
            f"Failed to load image {img} into kind cluster: {kind_cluster_name} error: {r.stderr.decode()}"
        )

    logging.info("Pre-loaded image %s into kind in %.1f seconds", img, time.time() - t0)


def _pull_images(kind_cluster_name, images, max_pull_jobs, attempt):
    with multiprocessing.Pool(max_pull_jobs) as pool:
        results = pool.map(
            partial(pull_image, cluster_name=kind_cluster_name, attempt=attempt),
            images,
        )
    return results


def pull_images(
    image_list_file: str | pathlib.Path,
    max_pull_jobs: int,
    kind_cluster_name: str,
    statistics_json: pathlib.Path | None = None,
    allowed_image_prefixes: list[str] | None = None,
    max_attempts: int = 3,
    sleep_between_attempts: float = 30,
):
    """Pull images in parallel."""
    with image_list_file as f:
        images = [line.strip() for line in f]

    verify_allowed_images(images, allowed_image_prefixes)

    start_time = time.time()
    attempt = 1
    remaining_images = images

    results = {}
    while len(remaining_images) > 0 and attempt <= max_attempts:
        if attempt > 1:
            logging.error("Waiting %d seconds before retrying", sleep_between_attempts)
            time.sleep(sleep_between_attempts)

        logging.info("Pulling %d images in attempt %d", len(remaining_images), attempt)
        new_results = _pull_images(
            kind_cluster_name, remaining_images, max_pull_jobs, attempt=attempt
        )
        results.update({result.image: result for result in new_results})
        remaining_images = [
            result.image for result in new_results if not result.success
        ]

        if attempt > 1 and len(remaining_images) > 0:
            logging.error(
                "%d images failed to pull: %s", len(remaining_images), remaining_images
            )

        attempt += 1

    end_time = time.time()

    results = list(results.values())
    n_images = sum(1 for result in results if result.success)
    total_size_mb = sum(result.size for result in results if result.success) / (1024**2)

    logging.info(
        "Successfully pulled %d of %d images in %.3f seconds. Total size: %.3f MB, bandwidth: %.3f MB/s",
        n_images,
        len(images),
        end_time - start_time,
        total_size_mb,
        total_size_mb / (end_time - start_time) if end_time - start_time > 0 else 0,
    )

    if statistics_json is not None:
        with pathlib.Path(statistics_json).open("w") as stats_file:
            json.dump(
                {
                    "aivkit-version": aivkit.__version__,
                    "n_images": n_images,
                    "total_size_mb": total_size_mb,
                    "time_seconds": end_time - start_time,
                    "image_pull_results": [
                        {
                            **result._asdict(),
                            "size_mb": result.size / 1024**2,
                            "bandwidth_mb_per_s": (
                                result.size / 1024**2 / result.duration
                                if result.duration > 0
                                else 0
                            ),
                        }
                        for result in results
                    ],
                },
                stats_file,
            )
        logging.info("Statistics saved to %s", statistics_json)

    if len(remaining_images) > 0:
        raise RuntimeError(
            "Some images failed to pull: "
            + ", ".join(result.image for result in results if not result.success)
        )


def list_cluster_images(kubeconfig_args):
    """List images in a kind cluster."""
    from aivkit.deploy.tools import kubectl_bin

    result = sp.run(
        [
            kubectl_bin(),
            "get",
            "pods",
            "--all-namespaces",
            "-o",
            "jsonpath={.items[*].spec.containers[*].image}",
            *kubeconfig_args,
        ],
        check=True,
        capture_output=True,
    )

    images = result.stdout.decode().strip().split()
    return images


def verify_cluster_images(
    kubeconfig_args, allowed_image_prefixes: str | list[str] | tuple[str] | None = None
):
    """Ensure that all images in the cluster are local images."""
    images = list_cluster_images(kubeconfig_args)
    verify_allowed_images(images, allowed_image_prefixes)


def verify_allowed_images(
    images: list[str], allowed_image_prefixes: str | list[str] | tuple[str] | None
) -> None:
    """Verify that all images are in allowed prefixes."""
    logging.info(
        "Verifying %d images in the cluster, requested allowed prefixes: %s",
        len(images),
        allowed_image_prefixes,
    )

    if allowed_image_prefixes in (None, [], ""):
        allowed_image_prefixes_list = []
    elif isinstance(allowed_image_prefixes, list | tuple):
        allowed_image_prefixes_list = list(allowed_image_prefixes)
    elif isinstance(allowed_image_prefixes, str):
        allowed_image_prefixes_list = [
            prefix.strip() for prefix in allowed_image_prefixes.split(",")
        ]
    else:
        raise ValueError(
            "allowed_image_prefixes must be None, str, list or tuple, got "
            + str(type(allowed_image_prefixes))
        )

    allowed_image_prefixes_list.extend(default_allowed_image_prefixes)

    logging.info(
        "Allowed image prefixes including defaults: %s", allowed_image_prefixes_list
    )

    forbidden_images = [
        img
        for img in images
        if not any(img.startswith(prefix) for prefix in allowed_image_prefixes_list)
    ]

    if forbidden_images:
        for img in forbidden_images:
            logging.error("Cluster image %s is not allowed", img)
        raise RuntimeError(
            f"{len(forbidden_images)} images in the cluster are not allowed: {', '.join(forbidden_images)}, allowed prefixes: {allowed_image_prefixes_list}"
        )

    logging.info("All %d images in the cluster are allowed", len(images))


def build_image(
    image_name: str,
    context_path: str | pathlib.Path,
    dockerfile: str | pathlib.Path,
    kind_cluster_name: str | None = None,
    build_args: str = "",
) -> None:
    """Build a Docker image."""
    logging.info("Building image %s from context %s", image_name, context_path)

    t0 = time.time()
    cmd = [
        "docker",
        "build",
        "-t",
        image_name,
        "-f",
        str(dockerfile),
        str(context_path),
    ]

    for arg in build_args.split(","):
        arg = arg.strip()
        if arg:
            cmd.append("--build-arg")
            cmd.append(arg)

    run_subprocess_tracing_logging(cmd)
    logging.info("Built image %s in %.1f seconds", image_name, time.time() - t0)

    if kind_cluster_name is not None:
        t0 = time.time()
        run_subprocess_tracing_logging(
            [
                kind_bin(),
                "load",
                "docker-image",
                image_name,
                "--name",
                kind_cluster_name,
            ],
        )
        logging.info(
            "Loaded image %s into kind cluster %s in %.1f seconds",
            image_name,
            kind_cluster_name,
            time.time() - t0,
        )
