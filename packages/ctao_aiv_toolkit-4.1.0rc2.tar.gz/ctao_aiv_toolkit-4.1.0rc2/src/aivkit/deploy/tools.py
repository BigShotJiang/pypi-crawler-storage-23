"""Mechanism to find and manage Kubernetes tools like kind, kubectl, and helm."""

import logging
import os
import pathlib
import shutil

from aivkit.runcmd import run_subprocess_tracing_logging


def find_bin(name, var_name=None) -> str:
    """Find the binary in the PATH or return the path from the environment variable.

    When running inside the makefile, we need to respect the environment variables KIND, KUBECTL, HELM.
    If the variable is not set, it will use default paths in the toolkit directory.
    If not found there, it will look in the global PATH.

    """
    logging.debug("Finding binary for %s", name)

    if var_name is None:
        var_name = name.upper()

    env_path = os.environ.get(var_name)
    logging.debug("Environment variable location %s=%s", var_name, env_path)

    default_path = f"./.toolkit/bin/{name}"
    logging.debug("Default location for %s=%s", name, default_path)

    global_path = shutil.which(name)
    logging.debug("Global location for %s=%s", name, global_path)

    logging.debug(
        "Looking for %s binary with environment variable %s=%s, global path %s, default path %s",
        name,
        var_name,
        env_path,
        global_path,
        default_path,
    )

    if env_path:
        logging.debug(
            "Using %s from environment variable %s: %s", name, var_name, env_path
        )
        path = pathlib.Path(env_path).absolute()
    elif os.path.exists(default_path):
        logging.debug("Using %s from default path: %s", name, default_path)
        path = pathlib.Path(default_path).absolute()
    elif global_path:
        logging.debug("Using %s from global PATH: %s", name, global_path)
        path = pathlib.Path(global_path).absolute()
    else:
        raise RuntimeError(
            f"{name} binary not found, variable {var_name} is " "not set"
            if env_path is None
            else f"and {name} binary not found in PATH, "
            f" default path is not available: {default_path}"
        )
    return str(path)


def kind_bin():
    """Get the executable for kind binary."""
    return find_bin("kind")


def kubectl_bin():
    """Get the executable for kubectl binary."""
    return find_bin("kubectl")


def helm_bin():
    """Get the executable for helm binary."""
    return find_bin("helm")


def install_tools(from_global: bool = False):
    """Install the required tools for kind cluster ops."""
    if from_global:
        for tool in ["kind", "kubectl", "helm"]:
            global_path = shutil.which(tool)
            if not global_path:
                raise RuntimeError(
                    f"Cannot install {tool} from global PATH, "
                    f"{tool} not found in PATH."
                )
            dest_path = pathlib.Path(f"./.toolkit/bin/{tool}")
            logging.info("Copying %s to %s", global_path, dest_path)
            shutil.copy(global_path, dest_path)
    else:
        run_subprocess_tracing_logging(["make", "install-tools"])
