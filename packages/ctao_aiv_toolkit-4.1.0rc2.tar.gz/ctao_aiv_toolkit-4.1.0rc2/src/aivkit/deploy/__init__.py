"""Functions for deploying DPPS applications in test and dev environments."""
