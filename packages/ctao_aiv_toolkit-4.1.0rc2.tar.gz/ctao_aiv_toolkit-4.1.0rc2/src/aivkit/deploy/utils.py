"""Utility functions for deployment tasks."""

import logging
import time
from collections.abc import Callable


def retry_call(
    func,
    *args,
    exception_type: type[Exception],
    max_attempts=5,
    delay=5,
    return_attempts=False,
    **kwargs,
):
    """Retry a function call with exponential backoff (inner function for decorator)."""
    attempts = []
    t0 = time.time()
    while len(attempts) < max_attempts:
        try:
            r = func(*args, **kwargs)
            logging.info(
                "Function succeeded on attempt %d/%d after %d seconds",
                len(attempts),
                max_attempts,
                int(time.time() - t0),
            )

            attempts.append(
                {
                    "attempt": len(attempts) + 1,
                    "time": time.time(),
                    "success": True,
                    "duration": time.time() - t0,
                }
            )

            if return_attempts:
                return r, attempts
            else:
                return r

        except exception_type as e:
            attempts.append(
                {
                    "attempt": len(attempts) + 1,
                    "time": time.time(),
                    "success": False,
                    "exception": str(e) if "e" in locals() else None,
                    "duration": time.time() - t0,
                }
            )

            if len(attempts) == max_attempts:
                logging.error("Max attempts reached. Function failed: %s", e)
                raise
            else:
                logging.warning(
                    "Function failed on attempt %d/%d: %s, %d s since start. Retrying in %d seconds...",
                    len(attempts),
                    max_attempts,
                    e,
                    int(time.time() - t0),
                    delay,
                )
                time.sleep(delay)
                delay *= 2  # Exponential backoff


def retry(
    exception_type: type[Exception], max_attempts=5, delay=5, return_attempts=False
) -> Callable:
    """Retry function with exponential backoff decorator."""

    def decorator(func):
        def wrapper(*args, **kwargs):
            return retry_call(
                func,
                *args,
                exception_type=exception_type,
                max_attempts=max_attempts,
                delay=delay,
                return_attempts=return_attempts,
                **kwargs,
            )

        return wrapper

    return decorator
