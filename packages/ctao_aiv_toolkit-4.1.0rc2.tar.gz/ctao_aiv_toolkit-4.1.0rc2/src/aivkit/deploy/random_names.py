"""Generate random instance names for deployments."""

import logging
import pathlib
import uuid

from ruamel.yaml import YAML


def get_instance_names(
    base_name: str,
    output_file: pathlib.Path,
    overwrite: bool = False,
    name: str | None = None,
    randomized: bool = True,
) -> dict | str:
    """Generate random instance names and save to a YAML file.

    At the moment only release name is generated, other names will be added in the future (ingressclass, storageclass, namespace).
    """
    if output_file.exists() and not overwrite:
        names = YAML(typ="safe").load(output_file.read_text())
        if names and all(key in names for key in ["release_name"]):
            logging.info(
                "Random names already exist in %s, skipping generation.", output_file
            )
    else:
        if not randomized:
            logging.warning(
                "Generating non-randomized instance names as requested, this may lead to poorly behaving charts causing issues during integration and deployment."
            )
            names = {
                "release_name": f"{base_name}",
            }
        else:
            names = {
                "release_name": f"{base_name}-{uuid.uuid4().hex[:7]}",
            }

        logging.info("Generated random names writing to %s", output_file)

        output_file.parent.mkdir(exist_ok=True, parents=True)
        with output_file.open("w") as f:
            YAML(typ="safe").dump(names, f)

    logging.info("Random names are:")
    for key, value in sorted(names.items()):
        logging.info("  %s: %s", key, value)

    if name is not None:
        return names[name]
    else:
        return names
