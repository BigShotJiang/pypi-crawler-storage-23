"""Functions to run helm-test in CI and dev."""

import argparse
import json
import logging
import os
import pathlib
import re
import subprocess as sp
import time
from threading import Thread
from typing import NamedTuple

from packaging.version import Version
from ruamel.yaml import YAML

from aivkit.deploy.images import verify_cluster_images
from aivkit.deploy.tools import helm_bin, kubectl_bin
from aivkit.deploy.utils import retry
from aivkit.git import ctx_clone_computing_group_repo
from aivkit.runcmd import RequestStop, run_subprocess_tracing_logging


class HelmTestFailure(Exception):  # noqa: N818
    """Exception raised in case helm test fails."""

    def __init__(self, code):
        super().__init__(f"helm test failed with exit code: {code}")
        self.code = code


class HelmUpgradeFailure(Exception):  # noqa: N818
    """Exception raised in case helm upgrade fails."""

    def __init__(self, code):
        super().__init__(f"helm upgrade failed with exit code: {code}")
        self.code = code


def start_helm_test(release_name, helm: str, timeout: str, chart_test_filter: str):
    """Create a subprocess for helm test."""
    cmd = [
        helm,
        "test",
        f"--timeout={timeout}",
        "--debug",
        release_name,
    ]

    if chart_test_filter is not None:
        cmd.append(f"--filter={chart_test_filter}")

    process = sp.Popen(
        cmd,
        text=True,
        stdout=sp.PIPE,
    )

    return process


def start_log_watcher(kubectl: str):
    """Create a subprocess for reading the testkit log output."""
    cmd = [
        kubectl,
        "exec",
        "deployments/testkit",
        "--",
        "tail",
        "-n",
        "100000",
        "-f",
        "/test-results/logs.txt",
    ]

    return sp.Popen(cmd)


def read_helm_output(process, values_file, exception_class):
    """Read the stdout of the helm process.

    This prints the output of helm test until the COMPUTED VALUES are reached.
    All following output is written to `helm-debug.txt` instead.
    """
    logging.info("Reading helm output and storing computed values in %s", values_file)
    debug = False
    with open(values_file, "w") as f:
        while True:
            line = process.stdout.readline()
            if not line:
                break

            line = line.rstrip("\n")

            if "COMPUTED VALUES" in line:
                debug = True

            if debug:
                f.write(line + "\n")
            else:
                logging.info(line)

    # wait for some time after EOF on stdout for the process to truly terminate
    process.stdout.close()
    process.wait(timeout=5)

    if process.returncode != 0:
        raise exception_class(process.returncode)


def helm_test(
    release_name,
    helm: str | None = None,
    kubectl: str | None = None,
    timeout: str | None = None,
    chart_test_filter: str | None = None,
    request_stop: RequestStop | None = None,
):
    """
    Run helm test for projects using the aivkit.

    This command is meant to run inside the Makefile after
    the app has already been installed into the kind cluster.

    If `exit_after_message` is provided, the function will return sp.Popen
    as soon as that message is found in the helm output
    """
    logging.info("Running helm test for release: %s", release_name)

    # helm also tries to do the cleanup of previous tests, but we do it here to be sure
    delete_live_helm_tests()

    if helm is None:
        helm = helm_bin()

    if kubectl is None:
        kubectl = kubectl_bin()

    log_process = None
    try:
        log_process = start_log_watcher(kubectl)

        cmd = [
            helm,
            "test",
            f"--timeout={timeout}",
            "--debug",
            f"--filter={chart_test_filter}",
            release_name,
        ]

        run_subprocess_tracing_logging(
            cmd,
            request_stop=request_stop,
            exception_class=HelmTestFailure,
            stop_collection_on_regex="COMPUTED VALUES",
        )

    finally:
        if log_process is not None:
            log_process.terminate()
            try:
                log_process.wait(5)
            except sp.TimeoutExpired:
                log_process.kill()


def cleanup_failed_job_pods() -> list[str]:
    """Clean up Errored pods made by jobs, return names of deleted pods."""
    deleted_pods = []

    jobs = (
        sp.check_output(
            [kubectl_bin(), "get", "jobs", "-o", "jsonpath={.items[*].metadata.name}"],
            text=True,
        )
        .strip()
        .split()
    )

    logging.info("Checking %d jobs for failed pods: %s", len(jobs), ", ".join(jobs))

    for job in jobs:
        pod_names = (
            sp.check_output(
                [
                    kubectl_bin(),
                    "get",
                    "pods",
                    "-o",
                    f"jsonpath={{.items[?(@.metadata.ownerReferences[0].name=='{job}')].metadata.name}}",
                ],
                text=True,
            )
            .strip()
            .split()
        )

        logging.info(
            "Found %d pods for job %s: %s", len(pod_names), job, ", ".join(pod_names)
        )

        for pod_name in pod_names:
            pod_status = sp.check_output(
                [
                    kubectl_bin(),
                    "get",
                    "pod",
                    pod_name,
                    "-o",
                    "jsonpath={.status.phase}",
                ],
                text=True,
            ).strip()

            if pod_status == "Failed":
                logging.info("Deleting failed pod %s of job %s", pod_name, job)
                sp.run([kubectl_bin(), "delete", "pod", pod_name], check=True)
                deleted_pods.append(pod_name)

    return deleted_pods


def pod_is_ready(pod: dict) -> bool:
    """Check if a pod is in Ready state."""
    if pod["status"]["phase"] == "Running":
        # We need to have pods not just in Running state, but also Ready to respond to requests
        conditions = pod["status"].get("conditions", [])
        for condition in conditions:
            if condition["type"] == "Ready" and condition["status"] == "True":
                return True
    elif pod["status"]["phase"] == "Succeeded":
        # Completed jobs will have Succeeded state
        return True
    return False


def wait_for_pods(wait_attempts=20, wait_sleep_time=5):
    """Wait for all pods to be in Running or Completed state.

    Some applications will create pods with delay, so we need to have our specific logic for waiting.

    The application pods may not have the labels we can use to select them, so we check all pods.
    """
    attempts = []

    get_pods_cmd = [kubectl_bin(), "get", "pods", "-o", "json"]

    deleted_pods = []

    while len(attempts) < wait_attempts:
        deleted_pods.extend(cleanup_failed_job_pods())

        output = sp.check_output(
            get_pods_cmd,
            text=True,
        )

        unready_pods = [
            pod for pod in json.loads(output)["items"] if not pod_is_ready(pod)
        ]

        attempts.append(
            {
                "attempt": len(attempts),
                "time": time.time(),
                "unready_pods": unready_pods,
            }
        )

        if not unready_pods:
            logging.info("All pods are running or succeeded.")

            if deleted_pods:
                logging.warning(
                    "Deleted the following failed job pods during wait: %s",
                    ", ".join(deleted_pods),
                )

            return attempts, deleted_pods
        else:
            logging.warning(
                "Found %d pods not Ready: %s",
                len(unready_pods),
                ", ".join(
                    f'{pod["metadata"]["name"]}({pod["status"]["phase"]})'
                    for pod in unready_pods
                ),
            )

        logging.info(
            "Waiting for pods to be ready, attempt %s/%s",
            len(attempts),
            wait_attempts,
        )

        time.sleep(wait_sleep_time)

    raise RuntimeError(
        "Not all pods are running after waiting for the specified attempts."
    )


def package_chart(
    chart_location: str, app_version: str, destination: pathlib.Path, helm: str = None
) -> str:
    """Package helm chart into destination using app_version."""
    package_args = [
        helm if helm is not None else helm_bin(),
        "package",
        str(chart_location),
        f"--destination={destination}",
        f"--app-version={app_version}",
    ]

    output = run_subprocess_tracing_logging(package_args)

    packaged_chart_path = re.search(
        r"Successfully packaged chart and saved it to: (.*)", output
    ).group(1)

    logging.info(
        "Stored chart in %s using app-version=%s", packaged_chart_path, app_version
    )
    return pathlib.Path(packaged_chart_path).absolute().as_posix()


def timestamp_to_seconds(ts: str) -> float:
    """Convert a timestamp string to seconds since epoch."""
    return time.mktime(time.strptime(ts, "%Y-%m-%dT%H:%M:%SZ"))


def get_helm_upgrade_analysis(kubeconfig: pathlib.Path | None = None):
    """Get analysis of the last helm upgrade."""
    analysis = {}

    # get all events and sort them by timestamp
    cmd = [kubectl_bin()]
    if kubeconfig:
        cmd.extend(["--kubeconfig", str(kubeconfig)])
    cmd.extend(["get", "events", "--all-namespaces", "-o", "json"])
    output = sp.check_output(cmd, text=True)
    events = json.loads(output)["items"]
    events.sort(key=lambda e: e["metadata"]["creationTimestamp"])
    analysis["events"] = events

    first_event = events[0]["metadata"]["creationTimestamp"]

    for event in events:
        logging.info(
            "T0 + %4d s : %30.30s %s",
            timestamp_to_seconds(event["metadata"]["creationTimestamp"])
            - timestamp_to_seconds(first_event),
            event["involvedObject"]["name"],
            event.get("message"),
        )

    # TODO: add more analysis, e.g. pod restarts, details per episode, etc.

    return analysis


def delete_live_helm_tests():
    """Delete all running, completed, and failed helm tests."""
    logging.info(
        "Deleting any running, completed, and failed helm tests if they exist."
    )

    pods = sp.run(
        [
            kubectl_bin(),
            "get",
            "pods",
            "-o",
            r"jsonpath={.items[?(@.metadata.annotations['helm\.sh/hook']=='test')].metadata.name}",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    pod_names = pods.stdout.strip().split()

    logging.info("Found helm test pods: %s", pod_names)

    if len(pod_names) > 0:
        logging.info("Deleting helm test pods: %s", pod_names)
        sp.run(
            [kubectl_bin(), "delete", "pod"] + pod_names,
            check=True,
        )
        # wait for pods to be deleted
        for pod_name in pod_names:
            sp.run(
                [
                    kubectl_bin(),
                    "wait",
                    "--for=delete",
                    f"pod/{pod_name}",
                    "--timeout=60s",
                ],
                check=True,
            )
    else:
        logging.info("No helm test pods found to delete.")


def helm_upgrade_run(
    install_args, computed_values_file, wait_attempts, wait_sleep_time
):
    """Run the helm upgrade process and monitor its output."""
    delete_live_helm_tests()

    process = sp.Popen(install_args, stdout=sp.PIPE, stderr=sp.STDOUT, text=True)

    read_helm_output(process, computed_values_file, HelmUpgradeFailure)

    attempts, deleted_pods = wait_for_pods(
        wait_attempts=wait_attempts,
        wait_sleep_time=wait_sleep_time,
    )

    return deleted_pods, attempts


class WaitConfig(NamedTuple):
    """Configuration for waiting during helm upgrade and dev."""

    helm_upgrade_timeout: str = "600s"
    helm_upgrade_attempts: int = 10
    helm_sleep_time: int = 10
    wait_attempts: int = 10
    wait_sleep_time: int = 3
    helm_dev_wait_attempts: int = 30
    helm_dev_wait_sleep_time: int = 2

    @classmethod
    def from_args(cls, args: argparse.Namespace) -> "WaitConfig":
        """Create WaitConfig from argparse Namespace."""
        return cls(
            **{
                key: getattr(args, key)
                for key in cls.__annotations__.keys()
                if hasattr(args, key)
            },
        )


def helm_upgrade(
    release_name: str,
    chart_location: str = "test-chart",
    app_version: str = "dev",
    values_file: pathlib.Path | None = None,
    chart_extra_values: str = "",
    kubeconfig: pathlib.Path | None = None,
    upgrade_statistics_json: pathlib.Path | None = None,
    computed_values_file: pathlib.Path | None = None,
    analyse_upgrade_events: bool = False,
    allowed_image_prefixes: str | None = None,
    wait_config: WaitConfig = None,
):
    """Upgrade or install a Helm chart."""
    if wait_config is None:
        wait_config = WaitConfig()

    install_args = [
        helm_bin(),
        "upgrade",
        "--install",
        "--debug",
        "--timeout",
        wait_config.helm_upgrade_timeout,
        "--reset-values",
        release_name,
    ]

    if values_file is not None:
        install_args.extend(["--values", str(values_file)])

    if chart_extra_values:
        install_args.extend(chart_extra_values.split())

    if kubeconfig:
        install_args.extend(["--kubeconfig", str(kubeconfig)])

    if computed_values_file is None:
        computed_values_file = pathlib.Path(".toolkit/helm-computed.txt")

    if r := re.match(
        r"https://gitlab.cta-observatory.org/cta-computing/(.*?):(.*)",
        chart_location,
    ):
        helm = helm_bin()
        destination = pathlib.Path(".toolkit").absolute()
        destination.mkdir(parents=True, exist_ok=True)
        with ctx_clone_computing_group_repo(r.group(1), r.group(2)) as cloned_path:
            run_subprocess_tracing_logging(
                [helm, "dependency", "update", f"{cloned_path}/chart"],
            )

            try:
                # need to validate that the version is correct, but use the original version string
                Version(r.group(2))
                app_version = r.group(2)
                logging.info("Using app_version from git tag: %s", app_version)
            except Exception:
                logging.info(
                    "Could not parse app_version from git tag: %s, using default: %s",
                    r.group(2),
                    app_version,
                )

            aiv_config = YAML().load(open(f"{cloned_path}/aiv-config.yml"))

            packaged_chart_path = package_chart(
                pathlib.Path(cloned_path)
                / aiv_config["variables"].get("CHART_LOCATION", "chart"),
                app_version,
                destination,
                helm,
            )
            install_args.append(packaged_chart_path)
    elif chart_location.startswith(("https://", "oci://")):
        install_args.append(chart_location)
    else:
        packaged_chart_path = package_chart(
            chart_location, app_version, pathlib.Path(".toolkit").absolute()
        )
        install_args.append(packaged_chart_path)

    logging.info("Running helm upgrade: %s", " ".join(install_args))

    helm_upgrade_run_with_retry = retry(
        exception_type=sp.CalledProcessError,
        max_attempts=wait_config.helm_upgrade_attempts,
        delay=wait_config.helm_sleep_time,
        return_attempts=True,
    )(helm_upgrade_run)

    (wait_pods_attempts, deleted_pods), attempts = helm_upgrade_run_with_retry(
        install_args,
        computed_values_file,
        wait_config.wait_attempts,
        wait_config.wait_sleep_time,
    )

    logging.info(
        "Helm upgrade completed successfully in %.2f seconds, deleted %d failed job pods during wait, waited for pods in %d attempts",
        attempts[-1]["duration"],
        len(deleted_pods),
        len(wait_pods_attempts),
    )

    if upgrade_statistics_json:
        upgrade_statistics: dict = {
            "attempts": attempts,
        }

        if analyse_upgrade_events:
            upgrade_statistics["events"] = get_helm_upgrade_analysis(kubeconfig)

        pathlib.Path(upgrade_statistics_json).parent.mkdir(parents=True, exist_ok=True)

        with open(upgrade_statistics_json, "w") as f:
            json.dump(upgrade_statistics, f)

    verify_cluster_images(
        ["--kubeconfig", str(kubeconfig)] if kubeconfig else [], allowed_image_prefixes
    )


def attach_to_pod(pod_name: str, capture_stdin: bool = False):
    """Attach to a pod with an interactive bash session."""
    sp.run(
        [
            kubectl_bin(),
            "exec",
            "-it",
            pod_name,
            "--",
            "bash",
        ],
        stdin=sp.PIPE if capture_stdin else None,
    )


def wait_for_dev_helm_test_pod(
    test_pod: str,
    helm_dev_wait_attempts: int = 30,
    helm_dev_wait_sleep_time: int = 2,
):
    """Wait for the dev helm test pod to be running."""
    for helm_dev_wait_attempt in range(helm_dev_wait_attempts):
        pod_status_by_name = sp.check_output(
            [
                kubectl_bin(),
                "get",
                "pods",
                "-o",
                r"jsonpath={range .items[*]}{.metadata.name}:{.status.phase} {end}",
            ],
            text=True,
        )

        logging.info("Pod status by name: %s", pod_status_by_name)

        pod_status_dict = dict(
            entry.split(":") for entry in pod_status_by_name.strip().split()
        )
        if test_pod in pod_status_dict:
            if pod_status_dict[test_pod] == "Running":
                logging.info("Dev helm test pod is running.")
                break

        if test_pod not in pod_status_dict:
            logging.info(
                "Dev helm test pod %s not found (yet?), have pods: %s",
                test_pod,
                ",".join(pod_status_dict.keys()),
            )

        logging.info(
            "(%s/%s) Waiting for dev helm test pod %s to be running, current status: %s, all pods: %s",
            helm_dev_wait_attempt + 1,
            helm_dev_wait_attempts,
            test_pod,
            pod_status_dict.get(test_pod, "Unknown"),
            ",".join(f"{name}({status})" for name, status in pod_status_dict.items()),
        )
        time.sleep(helm_dev_wait_sleep_time)


def helm_dev(
    release_name: str,
    chart_location: str,
    test_pod: str,
    values_file: pathlib.Path | None = None,
    chart_extra_values: str = "",
    wait_config: WaitConfig = None,
    just_attach: bool = False,
    leave_running: bool = False,
    capture_stdin: bool = False,
    allowed_image_prefixes: str | None = None,
):
    """Run helm test in dev mode."""
    if just_attach:
        logging.info("Attaching to existing dev helm test pod %s", test_pod)
        attach_to_pod(test_pod, capture_stdin=capture_stdin)
    else:
        dev_values = [
            "--set dev.client_image_tag=dev",
            "--set dev.run_tests=false",
            "--set dev.sleep=true",
            "--set dev.mount_repo=true",
            f"--set dev.runAsUser={os.getuid()}",
            f"--set dev.runAsGroup={os.getgid()}",
        ]
        chart_extra_values = " ".join(chart_extra_values.split() + dev_values)
        helm_upgrade(
            release_name=release_name,
            chart_location=chart_location,
            app_version="dev",
            values_file=values_file,
            chart_extra_values=chart_extra_values,
            allowed_image_prefixes=allowed_image_prefixes,
            wait_config=wait_config,
        )

        # run helm test in a thread
        #
        # an alternative would be to use asyncio, but threading is simpler here
        #
        # another alternative is to run subprocess and read its output, but it's hard to identify when to stop reading and outputting subprocess stdout/stderr
        # if we could rely on helm test reporting pod status reliably, it would be enough to just wait for this message in the output, but it's not always the case

        request_stop = RequestStop()

        logging.info("Starting helm test for dev pod %s", test_pod)

        Thread(
            target=helm_test,
            kwargs={
                "release_name": release_name,
                "helm": None,
                "kubectl": None,
                "timeout": "0s",
                "chart_test_filter": f"name={test_pod}",
                "request_stop": request_stop,
            },
        ).start()

        wait_for_dev_helm_test_pod(
            test_pod,
            helm_dev_wait_attempts=wait_config.helm_dev_wait_attempts,
            helm_dev_wait_sleep_time=wait_config.helm_dev_wait_sleep_time,
        )

        logging.info("Attaching to dev helm test pod %s", test_pod)

        attach_to_pod(test_pod, capture_stdin=capture_stdin)

        logging.info("Stopping to follow dev helm test pod %s logs", test_pod)
        request_stop.set()

        if leave_running:
            logging.info("Leaving dev helm test pod %s running", test_pod)
        else:
            logging.info("Deleting test pod %s", test_pod)
            sp.run(
                [
                    kubectl_bin(),
                    "delete",
                    "pod",
                    test_pod,
                ]
            )
