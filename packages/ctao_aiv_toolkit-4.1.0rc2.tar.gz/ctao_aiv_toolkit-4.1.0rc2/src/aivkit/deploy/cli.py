"""Command line interface for deployment of DPPS applications."""

import argparse
import logging

from aivkit.pretty import bold

try:
    import argcomplete
except ImportError:
    # argcomplete is an optional dependency
    argcomplete = None

import pathlib
import sys

from aivkit.argparser import (
    ArgumentParserWithEnvConfigDefaults,
    as_bool,
    configure_argparsing_logger,
)
from aivkit.deploy.helm import (
    HelmTestFailure,
    HelmUpgradeFailure,
    WaitConfig,
    helm_dev,
    helm_test,
    helm_upgrade,
    wait_for_pods,
)
from aivkit.deploy.images import build_image, pull_images
from aivkit.deploy.kind import kind_down, kind_purge, kind_up
from aivkit.deploy.random_names import get_instance_names
from aivkit.log import configure_logging


def format_kind_config(args):
    """Format kind config based on command line arguments."""
    if args.kind_config is not None and args.kind_config != "":
        return args.kind_config
    else:
        return {
            "enable_registry_mirrors": as_bool(args.enable_registry_mirrors),
            "enable_ingress": as_bool(args.enable_ingress),
            "mount_repo": as_bool(args.mount_repo),
        }


def _add_subparser_kind_pull_images(subparsers):
    _ = subparsers.add_parser(
        "kind-pull-images",
        help="Pull Docker images for the DPPS application in kind cluster.",
    )
    _.add_argument(
        "--max-pull-jobs",
        type=int,
        default=1,
    )
    _.add_argument(
        "--image-list-file",
        type=argparse.FileType("r"),
        help="File containing the list of images to pull.",
        required=True,
    )
    _.add_argument(
        "--statistics-json",
        type=pathlib.Path,
        help="File to save statistics about the image pulling process.",
        default=None,
    )
    _.add_argument(
        "--max-attempts",
        type=int,
        default=3,
        help="Maximum number of attempts to pull images.",
    )
    _.add_argument(
        "--sleep-between-attempts",
        type=float,
        default=30.0,
        help="Seconds to sleep between attempts to pull images.",
    )
    _add_argument_allowed_image_prefixes(_)


def deduce_chart_name(explain=False) -> str:
    """Deduces chart name from current working directory."""
    if explain:
        return "Deducing chart name from current working directory."

    else:
        cwd = pathlib.Path.cwd()
        chart_name = cwd.name
        return chart_name


def _add_subparser_helm_test(subparsers):
    _ = subparsers.add_parser(
        "helm-test", help="Run helm tests for a deployed application."
    )
    _add_common_helm_arguments(_)
    _.add_argument(
        "--timeout",
        help="helm test timeout",
        default="6000m",
        env_var_name="HELM_TEST_TIMEOUT",
    )
    _.add_argument(
        "--filter",
        help="helm test filter",
        default="*",
    )
    _.add_argument(
        "--computed-values-file",
        help="File to store the computed values in",
        default="helm-debug.txt",
    )


def _add_subparser_kind_up(subparsers):
    _ = subparsers.add_parser(
        "kind-up",
        help="Start a kind cluster",
    )
    _.add_argument(
        "--kind-config",
        type=str,
        default="",
        help="Path to the kind config file.",
    )
    _.add_argument(
        "--if-cluster-exists",
        type=str,
        default="reuse",
        choices=["reuse", "raise", "recreate"],
        help="Action to take if the cluster already exists.",
        env_var_name="IF_CLUSTER_EXISTS",
    )
    _.add_argument(
        "--kubeconfig",
        type=str,
        default=None,
        help="Path to the kubeconfig file.",
    )
    _.add_argument(
        "--enable-registry-mirrors",
        type=as_bool,
        choices=[True, False],
        default=True,
        help="Enable registry mirrors in the kind cluster.",
        env_var_name="ENABLE_REGISTRY_MIRRORS",
    )
    _.add_argument(
        "--enable-ingress",
        type=as_bool,
        choices=[True, False],
        default=True,
        help="Enable ingress in the kind cluster.",
        env_var_name="ENABLE_INGRESS",
    )
    _.add_argument(
        "--mount-repo",
        type=as_bool,
        choices=[True, False],
        default=True,
        help="Mount the repository in the kind cluster.",
        env_var_name="MOUNT_REPO",
    )
    _add_argument_allowed_image_prefixes(_)


def _add_subparser_helm_upgrade(subparsers):
    _ = subparsers.add_parser("helm-upgrade", help="Upgrade an application using Helm.")

    _add_common_helm_arguments(_)

    _.add_argument(
        "--helm-upgrade-timeout",
        type=str,
        default="600m",
        help="Timeout for the Helm upgrade command.",
        env_var_name="HELM_UPGRADE_TIMEOUT",
    )
    _.add_argument(
        "--helm-upgrade-attempts",
        type=int,
        default=3,
        help="Number of attempts to run the Helm upgrade command.",
        env_var_name="HELM_UPGRADE_ATTEMPTS",
    )
    _.add_argument(
        "--helm-sleep-time",
        type=int,
        default=10,
        help="Sleep time between Helm upgrade attempts.",
        env_var_name="HELM_SLEEP_TIME",
    )
    _.add_argument(
        "--wait-attempts",
        type=int,
        default=60,
        help="Number of attempts to wait for the Helm upgrade to complete.",
        env_var_name="WAIT_ATTEMPTS",
    )
    _.add_argument(
        "--wait-sleep-time",
        type=int,
        default=10,
        help="Sleep time between wait attempts.",
        env_var_name="WAIT_SLEEP_TIME",
    )
    _.add_argument(
        "--upgrade-statistics-json",
        type=pathlib.Path,
        default="$TOOLKITDIR/stats/testkit-helm-upgrade-statistics.json",
        help="File to save upgrade statistics to.",
    )
    _.add_argument(
        "--computed-values-file",
        type=pathlib.Path,
        default="$TOOLKITDIR/helm-computed.txt",
        help="File to store computed values for the Helm chart.",
    )
    _.add_argument(
        "--analyse-upgrade-events",
        action="store_true",
        help="Analyse Kubernetes events during the Helm upgrade process.",
    )
    _add_argument_allowed_image_prefixes(_)


def _add_subparser_wait_for_pods(subparsers):
    _ = subparsers.add_parser("wait-for-pods", help="Wait for all pods to be ready.")
    _.add_argument(
        "--wait-sleep-time",
        type=int,
        default=10,
        help="Sleep time in seconds between checks for pod readiness.",
    )
    _.add_argument(
        "--wait-attempts",
        type=int,
        default=3,
        help="Number of attempts to wait for pods to be ready.",
    )


def _add_subparser_kind_down(subparsers):
    _ = subparsers.add_parser(
        "kind-down",
        help="Stop a kind cluster",
    )


def _add_subparser_kind_purge(subparsers):
    _ = subparsers.add_parser(
        "kind-purge",
        help="Purge all kind clusters",
    )


def _add_subparser_get_instance_name(subparsers):
    _ = subparsers.add_parser("get-instance-name", help="Get computed instance names.")
    _.add_argument(
        "--name",
        type=str,
        default=None,
        help="If specified, return only the value for this name.",
    )
    _.add_argument(
        "--randomized",
        type=as_bool,
        choices=[True, False],
        default=False,
        help="Whether to generate randomized names.",
    )


def _add_common_helm_arguments(_):
    _.add_argument(
        "--release-name",
        type=str,
        help="Name of the Helm release.",
        env_var_name="RELEASE_NAME",
        default="$CHART_NAME",
    )
    _.add_argument(
        "--chart-extra-values",
        type=str,
        default="",
        help="Extra values to pass to the Helm chart.",
    )
    _.add_argument(
        "--version",
        type=str,
        help="Chart version to use.",
        default=None,
        env_var_name="CHART_VERSION",
    )
    _.add_argument(
        "--values-file",
        type=str,
        default=None,
        help="Location of the values file to use for the Helm upgrade.",
        env_var_name="CHART_VALUES",
    )
    _.add_argument(
        "--helm",
        help="Path to the helm executable",
        default="./.toolkit/bin/helm",
        env_var_name="HELM",
    )


def _add_subparser_helm_dev(subparsers):
    _ = subparsers.add_parser(
        "helm-dev", help="Start a development session for a Helm chart."
    )

    _add_common_helm_arguments(_)

    _.add_argument(
        "--test-pod",
        type=str,
        default="$RELEASE_NAME-pytest",
        help="Name of the test pod to attach to.",
    )
    _.add_argument(
        "--leave-running",
        action="store_true",
        help="Leave the deployed resources running after exiting the dev session.",
    )
    _.add_argument(
        "--just-attach",
        action="store_true",
        help="Just attach to the test pod without deploying the chart.",
    )
    _.add_argument(
        "--capture-stdin",
        action="store_true",
        help="Capture standard input and forward it to the test pod.",
    )
    _.add_argument(
        "--wait-attempts",
        type=int,
        default=60,
        help="Number of attempts to wait for the Helm upgrade to complete.",
        env_var_name="WAIT_ATTEMPTS",
    )
    _.add_argument(
        "--wait-sleep-time",
        type=int,
        default=10,
        help="Sleep time between wait attempts.",
        env_var_name="WAIT_SLEEP_TIME",
    )

    _add_argument_allowed_image_prefixes(_)


def _add_argument_allowed_image_prefixes(arg_parser):
    arg_parser.add_argument(
        "--allowed-image-prefixes",
        type=str,
        default=None,
        help="List of allowed image prefixes.",
        env_var_name="ALLOWED_IMAGE_PREFIXES",
    )


def _add_subparser_image_build(subparsers):
    _ = subparsers.add_parser(
        "image-build",
        help="Build Docker images for the DPPS application.",
    )
    _.add_argument(
        "--image-name",
        type=str,
        help="Name of the image to build.",
        env_var_name="CI_HARBOR_REGISTRY_IMAGE",
        default="harbor.cta-observatory.org/dpps/$CHART_NAME:$APP_VERSION",
    )
    _.add_argument(
        "--context-path",
        type=str,
        help="Path to the build context.",
        default="$PWD",
        env_var_name="AIV_DOCKER_IMAGE_CONTEXT",
    )
    _.add_argument(
        "--dockerfile",
        type=str,
        help="Path to the Dockerfile.",
        default="$AIV_DOCKER_IMAGE_CONTEXT/Dockerfile",
        env_var_name="AIV_DOCKERFILE",
    )
    _.add_argument(
        "--build-args",
        type=str,
        help="Build arguments to pass to the Docker build command.",
        default="",
        env_var_name="DOCKER_BUILD_ARGS",
    )


def _add_subparser_help_variables(subparsers):
    _ = subparsers.add_parser(
        "help-variables",
        help="Show help about available variables for configuration.",
    )


def parse_args(
    args=None,
) -> tuple[argparse.Namespace, ArgumentParserWithEnvConfigDefaults]:
    """Get argument parser for deployment commands."""
    arg_parser = ArgumentParserWithEnvConfigDefaults(
        description="Commands for deployment of DPPS applications.",
    )
    arg_parser.add_argument(
        "--just-print-args",
        action="store_true",
        help="If set, just parse and return the arguments without executing any command.",
    )
    arg_parser.add_argument(
        "--toolkitdir",
        type=str,
        default="$PWD/.toolkit",
        help="Path to the toolkit directory.",
    )

    arg_parser.add_argument(
        "--randomized-release-name",
        type=as_bool,
        choices=[True, False],
        default=True,
        help="Use a randomized release name.",
        env_var_name="RANDOMIZED_RELEASE_NAME",
    )
    arg_parser.add_argument(
        "--base-name",
        type=str,
        default="$CHART_NAME",
        help="Base name for generating random instance names.",
    )
    arg_parser.add_argument(
        "--instance-names-file",
        type=str,
        default="$TOOLKITDIR/random-instance-names.yaml",
        help="Path to the output YAML file to save the generated names.",
    )
    arg_parser.add_argument(
        "--overwrite-instance-names-file",
        action="store_true",
        help="Overwrite the output file if it already exists.",
    )

    arg_parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        help="Set the logging level.",
    )
    arg_parser.add_argument(
        "--kind-cluster-name",
        type=str,
        default="aiv-local-$CHART_NAME",
        help="Name of the kind cluster",
    )

    arg_parser.add_argument("--chart-name", type=str, default=deduce_chart_name)
    arg_parser.add_argument(
        "--chart-location",
        type=str,
        help="Location of the Helm chart to upgrade.",
        env_var_name="CHART_LOCATION",
        default="$PWD/chart",
    )
    arg_parser.add_argument(
        "--app-version",
        type=str,
        default="dev",
        help="Application version to use in the Helm chart.",
        env_var_name="CHART_APP_VERSION",
    )

    arg_parser.add_argument(
        "--kubectl",
        help="Path to the kubectl executable",
        default="./.toolkit/bin/kubectl",
        env_var_name="KUBECTL",
    )
    arg_parser.add_argument(
        "--kubeconfig",
        type=str,
        default=None,
        help="Path to the kubeconfig file.",
    )

    subparsers = arg_parser.add_subparsers(dest="command", required=True)

    _add_subparser_help_variables(subparsers)

    _add_subparser_kind_pull_images(subparsers)
    _add_subparser_kind_up(subparsers)
    _add_subparser_kind_down(subparsers)
    _add_subparser_kind_purge(subparsers)

    _add_subparser_image_build(subparsers)

    _add_subparser_helm_test(subparsers)
    _add_subparser_helm_upgrade(subparsers)
    _add_subparser_helm_dev(subparsers)
    _add_subparser_wait_for_pods(subparsers)

    _add_subparser_get_instance_name(subparsers)

    if argcomplete is not None:
        argcomplete.autocomplete(arg_parser)

    parsed_args = arg_parser.parse_args(args)

    return parsed_args, arg_parser


def main_kind(args):
    """Run main function for kind commands."""
    if args.command == "kind-pull-images":
        pull_images(
            image_list_file=args.image_list_file,
            max_pull_jobs=args.max_pull_jobs,
            kind_cluster_name=args.kind_cluster_name,
            statistics_json=args.statistics_json,
            max_attempts=args.max_attempts,
            sleep_between_attempts=args.sleep_between_attempts,
            allowed_image_prefixes=args.allowed_image_prefixes,
        )
    elif args.command == "kind-up":
        kind_up(
            args.kind_cluster_name,
            format_kind_config(args),
            args.if_cluster_exists,
            args.kubeconfig,
            args.allowed_image_prefixes,
        )
    elif args.command == "kind-down":
        kind_down(args.kind_cluster_name)
    elif args.command == "kind-purge":
        kind_purge()
    else:
        raise ValueError(f"Unknown kind command: {args.command}")


def main_helm(args):
    """Run main function for helm commands."""
    if args.command == "helm-upgrade":
        try:
            helm_upgrade(
                release_name=args.release_name,
                chart_location=args.chart_location,
                app_version=args.app_version,
                values_file=args.values_file,
                chart_extra_values=args.chart_extra_values,
                kubeconfig=pathlib.Path(args.kubeconfig) if args.kubeconfig else None,
                upgrade_statistics_json=args.upgrade_statistics_json,
                computed_values_file=args.computed_values_file,
                analyse_upgrade_events=args.analyse_upgrade_events,
                allowed_image_prefixes=args.allowed_image_prefixes,
                wait_config=WaitConfig.from_args(args),
            )
        except HelmUpgradeFailure as e:
            sys.exit(e.code)
    elif args.command == "helm-test":
        try:
            helm_test(
                release_name=args.release_name,
                helm=args.helm,
                kubectl=args.kubectl,
                timeout=args.timeout,
                chart_test_filter=args.filter,
            )
        except (HelmTestFailure, HelmUpgradeFailure) as e:
            sys.exit(e.code)
    elif args.command == "helm-dev":
        helm_dev(
            release_name=args.release_name,
            chart_location=args.chart_location,
            test_pod=args.test_pod,
            values_file=args.values_file,
            chart_extra_values=args.chart_extra_values,
            leave_running=args.leave_running,
            just_attach=args.just_attach,
            capture_stdin=args.capture_stdin,
            wait_config=WaitConfig.from_args(args),
            allowed_image_prefixes=args.allowed_image_prefixes,
        )


def main_help_variables(argtrace: dict):
    """Print help about available variables for configuration."""
    logging.info(
        "The following variables that can be used as environment variables or in aiv-config.yml:\n"
    )
    for (arg_parser, arg_name), traces in sorted(argtrace.items()):
        if arg_name not in ("help", "command"):
            env_var_name = [
                trace for trace in traces if trace.startswith("env_var_name: ")
            ][0].split(": ", 1)[1]
            help_text = [trace for trace in traces if trace.startswith("help: ")][
                0
            ].split(": ", 1)[1]
            help_text = " ".join(help_text.splitlines("\n")[:-1]).replace("\n", " ")
            logging.info("%-60s %s", bold(env_var_name), help_text)


def main(args_list: list[str] | None = None, configure_log: bool = True):
    """Run main."""
    configure_argparsing_logger()

    args, argparser = parse_args(args_list)

    if configure_log:
        configure_logging(
            args.log_level.upper(),
            format="%(asctime)s %(levelname)s [%(process)d]: %(message)s",
        )

    if args.just_print_args:
        logging.info("returning parsed args without executing command")
        return args

    if args.randomized_release_name:
        # this is an alternative way to get randomized release name
        logging.info("Using randomized release name as requested.")
        args.release_name = get_instance_names(
            base_name=args.base_name,
            output_file=pathlib.Path(args.instance_names_file),
            overwrite=args.overwrite_instance_names_file,
            name="release_name",
        )

    if args.command == "help-variables":
        main_help_variables(argparser.collect_arg_traces())

    elif args.command.startswith("kind-"):
        main_kind(args)
    elif args.command.startswith("helm-"):
        main_helm(args)
    elif args.command == "wait-for-pods":
        wait_for_pods(
            wait_attempts=args.wait_attempts,
            wait_sleep_time=args.wait_sleep_time,
        )
    elif args.command == "image-build":
        build_image(
            args.image_name,
            context_path=pathlib.Path(args.context_path),
            dockerfile=pathlib.Path(args.dockerfile),
            kind_cluster_name=args.kind_cluster_name,
            build_args=args.build_args,
        )
    elif args.command == "get-instance-name":
        names = get_instance_names(
            base_name=args.base_name,
            output_file=pathlib.Path(args.instance_names_file),
            overwrite=args.overwrite_instance_names_file,
            name=args.name,
            randomized=args.randomized,
        )
        if isinstance(names, str):
            # here the tool should print only the requested name, no logging decoration
            print(names)
    else:
        raise ValueError(f"Unknown command: {args.command}")


if __name__ == "__main__":
    main()
