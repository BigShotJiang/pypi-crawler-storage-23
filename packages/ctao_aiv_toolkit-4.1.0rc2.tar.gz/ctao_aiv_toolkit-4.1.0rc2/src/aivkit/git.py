"""Git related utilities. See gitlab.py for GitLab-specific utilities."""

import contextlib
import logging
import os
import re
import subprocess
import tempfile

default_dpps_release = "v0.4.0"


def get_private_token():
    """Get the private token."""
    return os.getenv("GITLAB_TOKEN")


@contextlib.contextmanager
def ctx_clone_computing_group_repo(
    path_fragment="dpps/dpps", revision=default_dpps_release, chdir=True
):
    """Context cloning dpps group repository in a temporary directory, destroyed after context exist."""
    with tempfile.TemporaryDirectory() as tmpdir:
        logging.info("Cloning %s repo rev %s to %s", path_fragment, revision, tmpdir)
        checkout_git_revision("cta-computing/" + path_fragment, revision, tmpdir)

        if chdir:
            with contextlib.chdir(tmpdir):
                yield tmpdir
        else:
            yield tmpdir


@contextlib.contextmanager
def ctx_clone_dpps_group_repo(
    path_fragment="dpps", revision=default_dpps_release, chdir=True
):
    """Context cloning dpps group repository in a temporary directory, destroyed after context exist."""
    with ctx_clone_computing_group_repo(
        path_fragment="dpps/" + path_fragment,
        revision=revision,
        chdir=chdir,
    ) as tmpdir:
        yield tmpdir


def checkout_git_revision(gitlab_repo: str, gitlab_rev: str, tmpdir: str) -> None:
    """Checkout a git revision."""
    access_token = get_private_token()

    with tempfile.TemporaryFile() as pipe:
        extra_args = dict(cwd=tmpdir, stderr=pipe, stdout=pipe)

        subprocess.check_call(["git", "init"], **extra_args)
        subprocess.check_call(
            [
                "git",
                "remote",
                "add",
                "origin",
                f"https://oauth2:{access_token}@gitlab.cta-observatory.org/{gitlab_repo}.git",
            ],
            **extra_args,
        )
        subprocess.check_call(
            ["git", "fetch", "-t", "--depth=1", "origin", gitlab_rev], **extra_args
        )
        subprocess.check_call(["git", "checkout", gitlab_rev], **extra_args)


def path_from_gitlab_url(url: str) -> str:
    """Get the repository path from a gitlab URL."""
    patterns = [
        "https://(?:.*?@)?gitlab.cta-observatory.org/(.*)",
        "git@gitlab.cta-observatory.org:(.*)",
    ]

    repo_path = None
    for pattern in patterns:
        match = re.match(pattern, url)
        if match:
            repo_path = match.group(1)
            break

    if repo_path is None:
        raise ValueError(
            f"Could not determine repository path from URL: {url}, expected patterns: {patterns}"
        )

    return "/" + repo_path.removesuffix(".git").lstrip("/")
