"""Pretty terminal output utilities."""


def bold(text: str) -> str:
    """Return bold text for terminal output."""
    return f"\033[1m{text}\033[0m"
