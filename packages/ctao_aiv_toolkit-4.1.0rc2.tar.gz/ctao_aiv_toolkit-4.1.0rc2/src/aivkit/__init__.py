"""Provides functions to interact with the AIV organization within GitLab."""

from .version import __version__

__all__ = [
    "__version__",
]
