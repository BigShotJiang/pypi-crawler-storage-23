"""Module to handle installation and submodule checks for AIvKit."""

import logging
import os
from functools import partial
from pathlib import Path
from urllib.request import urlopen

from packaging.version import Version
from ruamel.yaml import YAML

from aivkit.git import path_from_gitlab_url
from aivkit.runcmd import (
    run_subprocess_tracing_logging as _run_subprocess_tracing_logging,
)
from aivkit.version import __version__ as toolkit_version

run_subprocess_tracing_logging = partial(
    _run_subprocess_tracing_logging,
    stdout_level=logging.DEBUG,
    stderr_level=logging.DEBUG,
)

aivkit_path = "cta-computing/common/aiv-toolkit"
aivkit_url = f"https://gitlab.cta-observatory.org/{aivkit_path}.git"

gitlab_ci_filename = ".gitlab-ci.yml"
aiv_config_fn = "aiv-config.yml"


def get_relative_submodule_path(url) -> str:
    """Get the relative path for the submodule from the gitlab URL."""
    origin = run_subprocess_tracing_logging(
        ["git", "remote", "get-url", "origin"], stdout_level=logging.DEBUG
    ).strip()
    repo_path = path_from_gitlab_url(origin)
    toolkit_path = path_from_gitlab_url(url)

    relative_path = Path(toolkit_path).relative_to(
        repo_path,
        walk_up=True,
    )

    return str(relative_path)


def remove_submodule(path) -> str | None:
    """Remove the submodule at the specified path if it exists.

    Returns a message if the submodule was removed, None otherwise.
    """
    logging.info("Removing submodule at %s", path)

    if not os.path.isdir(path):
        logging.info("Submodule path %s does not exist. Nothing to remove.", path)
        return

    run_subprocess_tracing_logging(
        ["git", "rm", "-f", path],
        stdout_level=logging.DEBUG,
    )

    return f"Remove submodule at {path}"


def add_toolkit_submodule_if_missing(submodule_path: str = "aiv-toolkit") -> str | None:
    """Add the aiv-toolkit submodule if it is missing.

    Returns a message if the submodule was added, None otherwise.
    """
    run_subprocess_tracing_logging(
        ["git", "submodule", "update", "--init", "--recursive"],
        stdout_level=logging.DEBUG,
    )

    if not os.path.isdir(submodule_path):
        logging.info(
            "Submodule path %s does not exist. Adding submodule.", submodule_path
        )
        relative_path = get_relative_submodule_path(aivkit_url)

        run_subprocess_tracing_logging(
            ["git", "submodule", "add", str(relative_path), str(submodule_path)],
            stdout_level=logging.DEBUG,
        )

        return "Add aiv-toolkit submodule to the repository"
    else:
        logging.info("Submodule path %s already exists.", submodule_path)
        return None


def do_commit(message):
    """Commit the specified file with the given message."""
    logging.info("Committing with message: %s", message)
    run_subprocess_tracing_logging(["git", "commit", "-a", "-m", message])


def do_checkout(path, commit: str) -> None:
    """Checkout the path to the specified commit/tag."""
    logging.info("Checking out %s to commit/tag %s", path, commit)
    run_subprocess_tracing_logging(["git", "-C", path, "checkout", commit])


def get_repo_tags(submodule_path: str) -> list[str]:
    """Get the list of tags in the submodule repository, sorted by version descending."""
    logging.info("Getting tags for submodule %s", submodule_path)
    tags = (
        run_subprocess_tracing_logging(
            ["git", "-C", submodule_path, "tag", "--list", "--sort=-v:refname"]
        )
        .strip()
        .splitlines()
    )
    return tags


def update_toolkit_submodule(
    submodule_path: str = "aiv-toolkit", revision: str = "skip"
) -> str | None:
    """Update the aiv-toolkit submodule to the latest commit on main branch.

    Returns a message if the submodule was updated, None otherwise.
    """
    if revision == "skip":
        logging.info("Skipping update of submodule %s", submodule_path)
        return None
    elif revision in ["@latest-tag"]:
        logging.info("Updating submodule %s to latest tag", submodule_path)
        latest_tag = get_repo_tags(submodule_path)[0]
        logging.info("Latest tag in %s is %s", submodule_path, latest_tag)
        run_subprocess_tracing_logging(
            ["git", "-C", submodule_path, "checkout", latest_tag]
        )
        return f"Update {submodule_path} to latest tag {latest_tag}"
    elif revision in ["@latest-release"]:
        logging.info("Updating submodule %s to latest release", submodule_path)
        tags = get_repo_tags(submodule_path)
        release_tags = [
            tag
            for tag in tags
            if not Version(tag).is_devrelease and not Version(tag).is_prerelease
        ]
        if not release_tags:
            raise ValueError(f"No release tags found in submodule {submodule_path}")

        latest_release_tag = release_tags[0]
        do_checkout(submodule_path, latest_release_tag)
        return f"Update {submodule_path} to latest release tag {latest_release_tag}"
    elif revision.startswith("@"):
        branch = revision.lstrip("@")
        # set branch to track remote branch
        logging.info(
            "Updating submodule %s to latest commit on branch %s",
            submodule_path,
            branch,
        )
        run_subprocess_tracing_logging(
            ["git", "-C", submodule_path, "checkout", branch]
        )
        run_subprocess_tracing_logging(
            ["git", "-C", submodule_path, "pull", "origin", branch]
        )
        return f"Update {submodule_path} to latest commit on branch {branch}"
    else:
        logging.info(
            "Updating submodule %s to specified revision %s", submodule_path, revision
        )
        do_checkout(submodule_path, revision)

        return f"Update {submodule_path} to revision {revision}"


def _get_submodule_staged_commit(submodule_path: str) -> str:
    staged_commit = (
        run_subprocess_tracing_logging(
            ["git", "submodule", "status", "--cached", "--", submodule_path]
        )
        .split()[0]
        .lstrip("+")
    )
    logging.info("Staged commit in %s is %s", submodule_path, staged_commit)
    return staged_commit


def _get_submodule_own_commit(submodule_path: str) -> str:
    submodule_commit = run_subprocess_tracing_logging(
        ["git", "-C", submodule_path, "rev-parse", "HEAD"]
    ).strip()
    logging.info("Submodule commit in %s is %s", submodule_path, submodule_commit)
    return submodule_commit


def _get_committed_submodule_commit(submodule_path: str) -> str | None:
    try:
        committed_commit = run_subprocess_tracing_logging(
            ["git", "rev-parse", f"HEAD:{submodule_path}"]
        ).strip()
    except Exception as e:
        logging.warning(
            "Could not get committed commit for %s: %s, probably not committed yet?",
            submodule_path,
            e,
        )
        committed_commit = None

    logging.info("Committed commit in %s is %s", submodule_path, committed_commit)
    return committed_commit


def patch_project_path(
    include: dict, submodule_path, replace_obsolete_path, staged_commit: str
) -> tuple[bool, list[str]]:
    """Patch the project path in the include dictionary.

    Returns True if the submodule reference was found, False otherwise.
    """
    project_path = include["project"]
    project_name = project_path.strip().split("/")[-1]

    submodule_reference_found = False

    changes = []

    if project_name == replace_obsolete_path:
        logging.info(
            "Updating obsolete submodule path %s to %s in %s",
            replace_obsolete_path,
            submodule_path,
            gitlab_ci_filename,
        )
        include["project"] = path_from_gitlab_url(aivkit_url).strip("/")
        project_name = submodule_path
        changes.append(
            f"Update obsolete submodule path {replace_obsolete_path} to {submodule_path} in {gitlab_ci_filename}"
        )

    if project_name == submodule_path:
        submodule_reference_found = True
        if include.get("ref") != staged_commit:
            logging.warning(
                "Updating ref for %s in %s to %s",
                submodule_path,
                gitlab_ci_filename,
                staged_commit,
            )
            include["ref"] = staged_commit
            changes.append(
                f"Update ref for {submodule_path} in {gitlab_ci_filename} to {staged_commit}"
            )

    return submodule_reference_found, changes


def patch_includes(
    ci_config: dict, submodule_path, replace_obsolete_path, staged_commit: str
) -> list[str]:
    """Patch the includes in the CI configuration.

    Returns a list of changes made.
    """
    submodule_reference_found = False
    aiv_config_reference_found = False

    changes = []

    if "include" not in ci_config:
        ci_config["include"] = []

    for include in ci_config.get("include", []):
        if include == aiv_config_fn:
            aiv_config_reference_found = True

        elif isinstance(include, dict) and "project" in include:
            submodule_reference_found, _changes = (
                patch_project_path(
                    include, submodule_path, replace_obsolete_path, staged_commit
                )
                or submodule_reference_found
            )
            changes.extend(_changes)

    if not submodule_reference_found:
        logging.info(
            "Adding ref for %s in %s to %s",
            submodule_path,
            gitlab_ci_filename,
            staged_commit,
        )
        ci_config["include"].append(
            {
                "project": f"cta-computing/common/{submodule_path}",
                "ref": staged_commit,
                "file": "ci-functions.yml",
            }
        )

    if not aiv_config_reference_found:
        logging.info("Adding reference to %s in %s", aiv_config_fn, gitlab_ci_filename)
        ci_config.setdefault("include", []).append(aiv_config_fn)
        changes.append(f"Add reference to {aiv_config_fn} in {gitlab_ci_filename}")

    return changes


def check_submodule_commit(
    submodule_path: str,
    replace_obsolete_path: str = "dpps-aiv-toolkit",
) -> str | None:
    """Check if the CI configuration references the correct submodule commit.

    If CI configuration does not reference the correct commit, update it.

    Returns a message if the CI configuration was updated, None otherwise.
    """
    logging.info("Checking submodule in %s", submodule_path)

    if not os.path.isdir(submodule_path):
        raise ValueError(f"Submodule path {submodule_path} does not exist.")

    committed_commit = _get_committed_submodule_commit(submodule_path)
    staged_commit = _get_submodule_staged_commit(submodule_path)
    submodule_commit = _get_submodule_own_commit(submodule_path)

    if submodule_commit != staged_commit:
        logging.warning(
            "NOTE: %s staged commit differs from submodule commit: did you want to 'git add'?",
            submodule_path,
        )

    yaml = YAML()
    yaml.preserve_quotes = True
    yaml.indent(mapping=2, sequence=4, offset=2)

    with open(gitlab_ci_filename) as f:
        ci_config = yaml.load(f)

    changed = patch_includes(
        ci_config, submodule_path, replace_obsolete_path, staged_commit
    )

    if changed:
        with open(gitlab_ci_filename, "w") as f:
            yaml.dump(ci_config, f)

    if committed_commit != staged_commit:
        logging.warning(
            "NOTE: %s committed commit differs from staged commit: did you want to 'git add'?",
            submodule_path,
        )

    if changed:
        return f"Update {gitlab_ci_filename} to reference {submodule_path} at commit {staged_commit}"
    else:
        return None


def add_aiv_config(config_path: str = aiv_config_fn) -> str | None:
    """Add aiv-config.yml to the repository if it does not exist.

    Returns a message if the file was added, None otherwise.
    """
    if not os.path.isfile(config_path):
        logging.info("Adding default %s to the repository", config_path)

        with urlopen(
            f"https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit/-/raw/main/{aiv_config_fn}",
        ) as response:
            content = response.read().decode()

            with open(config_path, "w") as f:
                f.write(
                    f"# Default {aiv_config_fn} added by aivkit install. Please review and customize as needed.\n"
                )
                for line in content.splitlines():
                    if line.strip() == "variables:":
                        line = "variables: {}"
                    else:
                        line = f"# {line}"
                    f.write(line + "\n")

        # read the file and dump it again for debug
        with open(config_path) as f:
            logging.debug("%s content:\n%s", config_path, f.read())

        return "Add default aiv-config.yml to the repository"

    else:
        logging.info("%s already exists in the repository", config_path)
        return None


def add_precommit_hook(version: str | None = None) -> list[str]:
    """Add pre-commit hook to ensure submodules are up to date before commit."""
    yaml = YAML()
    yaml.preserve_quotes = True
    yaml.indent(mapping=2, sequence=4, offset=2)

    precommit_config_path = ".pre-commit-config.yaml"

    reference_found = False

    changes = []

    if not os.path.isfile(precommit_config_path):
        logging.info(
            "%s does not exist. Creating new pre-commit configuration.",
            precommit_config_path,
        )
        repos = []
        changes.append(f"Create new {precommit_config_path}")
    else:
        with open(precommit_config_path) as f:
            precommit_config = yaml.load(f)
            repos = precommit_config.get("repos", [])

    updated_repos = []

    if version is None:
        version = toolkit_version

    for repo in repos:
        if (
            repo.get("repo")
            == "https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit.git"
        ):
            logging.info("Pre-commit hook for aiv-toolkit already exists.")

            if repo["rev"] != version:
                logging.info("Updating pre-commit hook to version %s", version)
                repo["rev"] = version
                changes.append(
                    f"Update pre-commit hook for aiv-toolkit to version {version}"
                )

            reference_found = True

        if repo.get("repo") == "local" and [
            hook.get("id") for hook in repo.get("hooks", [])
        ] == ["CI yaml check"]:
            logging.info("Removing obsolete local pre-commit hook for CI yaml check.")
            changes.append("Remove obsolete local pre-commit hook for CI yaml check.")
        else:
            updated_repos.append(repo)

    repos = updated_repos

    if not reference_found:
        logging.info(
            "Adding pre-commit hook for aiv-toolkit version %s",
            version,
        )

        repos.append(
            {
                "repo": "https://gitlab.cta-observatory.org/cta-computing/common/aiv-toolkit.git",
                "rev": version,
                "hooks": [
                    {
                        "id": "ctao-aiv-toolkit",
                    }
                ],
            }
        )
        changes.append(f"Add pre-commit hook for aiv-toolkit version {version}")

    if changes:
        precommit_config = {"repos": repos}
        with open(precommit_config_path, "w") as f:
            yaml.dump(precommit_config, f)

        run_subprocess_tracing_logging(
            ["git", "add", precommit_config_path],
            stdout_level=logging.DEBUG,
        )

    return changes


def update_sonar_properties(old_path, new_path):
    """Replace mentions of old_path with new_path in sonar configuration."""
    path = Path("sonar-project.properties")
    if not path.is_file():
        return []

    config = path.read_text()
    if old_path not in config:
        return []

    logging.info("Updating references to %s to in %s", old_path, path)
    config = config.replace(old_path, new_path)
    path.write_text(config)

    return [f"Update mentions of {old_path} to {new_path} in sonar-project.properties"]
