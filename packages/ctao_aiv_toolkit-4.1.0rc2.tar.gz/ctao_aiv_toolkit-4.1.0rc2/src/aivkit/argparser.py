"""Argument parser with environment variable and config file defaults."""

import argparse
import logging
import os
import pathlib
import re
from collections import defaultdict

from ruamel.yaml import YAML

from aivkit.pretty import bold

# need a separate logger for argparsing to avoid interference with user logging config set by args
argparsing_logger = logging.getLogger("argparsing")


def configure_argparsing_logger():
    """Configure argparsing logger based on environment variable before any argument parsing."""
    # argparse logging needs to be configured before parsing args, since args affect logging
    # it should be configured once, but not at import time to allow environment variable to be set before parsing

    cli_log_level = os.getenv("AIVKIT_DEPLOY_CLI_LOG_LEVEL", "INFO")
    logging.basicConfig(level=cli_log_level)
    argparsing_logger.setLevel(getattr(logging, cli_log_level))


# we could use existing modules, but this functionality should be without dependencies
def as_bool(value: str | bool) -> bool:
    """Convert a string or boolean to a boolean."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        value = value.lower().strip()

        if value == "true":
            return True
        elif value == "false":
            return False
        else:
            raise ValueError(
                f"Cannot convert {value} to boolean: must be 'true' or 'false' but got '{value}'"
            )


class ArgumentParserWithEnvConfigDefaults(argparse.ArgumentParser):
    """Argument parser that shows default values in help and default values from environment variables and aiv-config.yml if they are set."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs, formatter_class=argparse.RawTextHelpFormatter)
        self.argtrace = defaultdict(list)

    def _trace(self, arg_name: str, message: str):
        self.argtrace[(self.prog, arg_name)].append(message)

    def collect_arg_traces(self) -> dict:
        """Collect argument traces from this parser and all subparsers."""
        all_traces = self.argtrace.copy()

        subparsers = getattr(self, "_subparsers", None)

        if subparsers is not None:
            for subparser in subparsers._actions:
                if isinstance(subparser, argparse._SubParsersAction):
                    for subparser in subparser.choices.values():
                        all_traces.update(subparser.collect_arg_traces())

        return all_traces

    def _format_argument_help(self, kwargs, comment: str | None):
        if kwargs.get("default") is not None and kwargs["default"] != argparse.SUPPRESS:
            # this allows default to be a callable that returns the default value, e.g., a function that determines the default at runtime
            # the function should also support explain=True to return a string explanation of the default
            if callable(kwargs["default"]):
                default = kwargs["default"]()
                default_comment = kwargs["default"](explain=True)
                kwargs["default"] = default
                kwargs["help"] += f"(default: {default}, {default_comment})"

            else:
                kwargs["help"] += f" (default: {kwargs['default']})"

        if comment:
            kwargs["help"] += "\n" + comment

    def add_argument(self, *args, **kwargs):
        """Add argument with default value from env var and aiv-config.yml."""
        if args[0] not in ("-h", "--help"):
            if "help" not in kwargs:
                kwargs["help"] = ""

            env_var_name = kwargs.pop("env_var_name", None)
            arg_name = args[0].strip("-").replace("-", "_")
            arg_type = kwargs.get("type", str)

            if "default" in kwargs:
                argparsing_logger.debug(
                    "Argument %s has default in code: %s",
                    arg_name,
                    kwargs["default"],
                )
                self._trace(arg_name, f"default in code: {kwargs['default']}")

            default, comment = self._get_default_value_for_argument(
                arg_name, arg_type, env_var_name
            )

            # if new default is found, it is preferred over existing default provided by code
            if default is not None:
                kwargs["default"] = default
                argparsing_logger.debug(
                    "Argument %s default set to: %s", arg_name, kwargs["default"]
                )

            # note that default values are not checked to be compatible with argument type until actual parsing
            # this is a general feature of argparse module and we do not add such checks here since it would complicate the code significantly

            self._format_argument_help(kwargs, comment)
            self._trace(arg_name, "help: " + kwargs["help"])

        kwargs["help"] += "\n"

        super().add_argument(*args, **kwargs)

    def _validate_value_type(self, value, arg_type: type):
        """Validate that the value can be converted to the given type."""
        if value is None:
            return
        elif callable(arg_type):
            # all types we support are callable. File objects are not supported.
            return arg_type(value)
        else:
            raise argparse.ArgumentTypeError(
                f"Unsupported argument type for env var conversion: {arg_type}"
            )

    def _get_envvar_name(self, arg_name: str) -> str:
        """Get the environment variable name for a given parser and argument name."""
        parser_name = self.prog

        env_var = ""

        if parser_name is not None:
            env_var = parser_name.replace(" ", "_").replace("-", "_").upper()
            env_var += "_"

        env_var += arg_name.strip("-").upper().replace("-", "_")

        return env_var

    def _aiv_config(self) -> dict:
        try:
            with open("aiv-config.yml") as f:
                yaml = YAML()
                config = yaml.load(f)
                return config["variables"]
        except (FileNotFoundError, KeyError, PermissionError, RuntimeError):
            argparsing_logger.warning(
                '"%s" No accessible aiv-config.yml found, proceeding without it',
                self.prog,
            )
            return {}

    def _get_config_value(self, var_name: str):
        return self._aiv_config().get(var_name)

    def _get_default_value_for_argument(
        self, arg_name: str, arg_type: type = str, env_var_name: str | None = None
    ):
        if env_var_name is None:
            env_var_name = self._get_envvar_name(arg_name)

        value_config = self._get_config_value(env_var_name)
        self._validate_value_type(value_config, arg_type)

        value_env = os.getenv(env_var_name)
        self._validate_value_type(value_env, arg_type)

        self._trace(arg_name, f"env_var_name: {env_var_name}")

        if value_env is not None:
            value = value_env
            comment = f"{bold('set from environment variable')}, can also be set in aiv-config.yml, {bold(env_var_name)}"
            argparsing_logger.debug(
                "Argument %s default set from env var %s: %s",
                arg_name,
                env_var_name,
                value,
            )
            self._trace(arg_name, f"set from env var {env_var_name}: {value}")

        elif value_config is not None:
            value = value_config
            comment = f"{bold('set from aiv-config.yml')}, can also be set from environment variable {bold(env_var_name)}"
            argparsing_logger.debug(
                "Argument %s default set from aiv-config.yml %s: %s",
                arg_name,
                env_var_name,
                value,
            )
            self._trace(arg_name, f"set from aiv-config.yml {env_var_name}: {value}")
        else:
            value = None
            comment = f"can be set from environment variable or aiv-config.yml as {bold(env_var_name)}"
            argparsing_logger.debug(
                "Argument %s has no default from env or config", arg_name
            )
            self._trace(arg_name, "no default from env or config")

        return value, comment

    def _substitute_env_vars_in_value(self, arg, value: str, unresolved_names) -> str:
        value = str(value)
        new_value = os.path.expandvars(value)

        if new_value != value:
            argparsing_logger.debug(
                "Substituted arg %s: %s -> %s", arg, value, new_value
            )

        if re.search(r"\$[A-Za-z_]\w*", new_value):
            unresolved_names.add(f"{arg}: {new_value}")
            argparsing_logger.debug(
                "Warning: unresolved env vars in arg %s: %s", arg, new_value
            )
        else:
            argparsing_logger.debug("Arg %s fully resolved to: %s", arg, new_value)

        return new_value

    def _set_args_as_env_vars(self, args):
        config_variables = self._aiv_config()

        for arg, value in vars(args).items():
            if isinstance(value, str):
                varname = arg.upper().replace("-", "_")
                config_variables.pop(varname, None)
                argparsing_logger.debug(
                    '"%s" setting env var for arg %s, %s: %s',
                    self.prog,
                    arg,
                    varname,
                    value,
                )
                os.environ[varname] = value

        # some variables may be in aiv-config.yml but not as args, like DATAPIPE_VERSION
        for varname, value in config_variables.items():
            argparsing_logger.debug(
                'unmatched "%s" setting env var from config variable %s: %s',
                self.prog,
                varname,
                value,
            )
            os.environ[varname] = str(value)

    def _substitute_env_vars_iteration(
        self, arg, value, args, changed, unresolved_names
    ):
        if isinstance(value, str) or isinstance(value, pathlib.Path):
            new_value = self._substitute_env_vars_in_value(
                arg, str(value), unresolved_names
            )
            changed = changed or (new_value != value)
            setattr(args, arg, new_value)

            if new_value != value:
                self._trace(arg, f"substituted {value} to {new_value}")
        else:
            argparsing_logger.debug(
                "Arg %s is not a string or Path, skipping: %s", arg, value
            )

        return changed

    def _substitute_env_vars(self, args):
        """Substitute environment variables in argument values."""
        changed = True

        # hard limit to avoid infinite loops
        remaining_iterations = 10

        while changed:
            changed = False
            unresolved_names = set()
            # substitute env vars in all string and Path args
            for arg, value in vars(args).items():
                changed = (
                    self._substitute_env_vars_iteration(
                        arg, value, args, changed, unresolved_names
                    )
                    or changed
                )

            self._set_args_as_env_vars(args)

            remaining_iterations -= 1
            if remaining_iterations <= 0:
                raise RuntimeError(
                    "Too many iterations substituting env vars, possible infinite loop"
                )

        if unresolved_names:
            raise RuntimeError(
                f"Unresolved env vars in args\nprog \"{self.prog}\"\n"
                f"- unresolved: {unresolved_names}\n"
                f"- have args:\n{'\n'.join(f'-- {k}: {v}' for k, v in vars(args).items())}"
            )

        return args

    def parse_args(self, *args, **kwargs):
        """Parse arguments and collect argument traces."""
        argparsing_logger.debug(
            "\n%s Parsing args: %s, %s", bold(str(self.prog)), args, kwargs
        )

        r = super().parse_args(*args, **kwargs)

        argparsing_logger.debug("%s Parsed args: %s", bold(str(self.prog)), r)

        # only top-level parser does env var substitution
        # space in prog indicates a subparser by default argparse behavior (and we do not override it)
        if " " not in self.prog:
            r = self._substitute_env_vars(r)

        self.log_argument_traces(r)

        return r

    def log_argument_traces(self, parsed_args):
        """Log argument traces collected during parsing."""
        # Log all parsed arguments and their origin traces
        for arg in vars(parsed_args):
            value = getattr(parsed_args, arg)
            argparsing_logger.debug("Argument %s: %s", arg, value)
            for trace in self.argtrace[(self.prog, arg)]:
                argparsing_logger.debug("  %s: %s", arg, trace)

        for trace in self.argtrace:
            argparsing_logger.debug("Arg trace for %s: %s", trace, self.argtrace[trace])
