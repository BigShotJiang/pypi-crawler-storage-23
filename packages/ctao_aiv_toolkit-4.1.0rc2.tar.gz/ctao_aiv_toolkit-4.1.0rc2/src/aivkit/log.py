"""Logging configuration for AIVKit."""

import logging

try:
    import coloredlogs
except ModuleNotFoundError:
    coloredlogs = None


def configure_logging_from_args(args):
    """Configure logging from command line arguments."""
    if args.debug:
        level = logging.DEBUG
    elif args.quiet:
        level = logging.WARNING
    elif args.silent:
        level = logging.ERROR
    else:
        level = logging.INFO

    configure_logging(level)


def configure_logging(
    level: int, format: str = "%(asctime)s %(levelname)s [%(process)d]: %(message)s"
):
    """Configure the logging level."""
    if coloredlogs:
        coloredlogs.install(level=level, fmt=format, force=True)
    else:
        logging.basicConfig(level=level, format=format, force=True)

    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)


def add_logging_args(parser):
    """Add logging related arguments to an argument parser."""
    parser.add_argument(
        "-q",
        "--quiet",
        dest="quiet",
        help="Print only warnings and errors.",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "-s",
        "--silent",
        dest="silent",
        help="Print only errors.",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "-vv",
        "-d",
        "--debug",
        dest="debug",
        help="Print debug output.",
        action="store_true",
        default=False,
    )
