"""Provides a utility function to run subprocess commands, captures both stdout and stderr, outputs them to logging in real-time, and returns the combined output."""

import logging
import re
import selectors
import shlex
import subprocess as sp
import threading


class RequestStop(threading.Event):
    """
    Control class to manage subprocess execution.

    It allows requesting a stop of the subprocess output reading.
    More explicit than threading primitives.
    """

    pass


def refine_helm_output(line: str, is_stderr: bool) -> tuple[bool, str]:
    """Refine Helm output lines to correctly classify them as stdout or stderr."""
    if r := re.match(
        r"^.*?\.go:\d+:\s+\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d+ [+-]\d{4} [A-Z]+ m=\+\d+\.\d+ \[debug\](.*)",
        line,
    ):
        # Helm debug line, treat as stdout
        is_stderr = False
        # Remove the prefix
        line = r.group(1)

    return is_stderr, line


def parse_data(
    data,
    is_stderr,
    stop_collection_on_regex: str | None = None,
    stdout_level=logging.INFO,
    stderr_level=logging.WARNING,
) -> tuple[list[str], list[str], list[str], bool]:
    """Parse data from the subprocess output, log it, and append to the appropriate lists."""
    stderr, stdout, combined = [], [], []

    for line in data.splitlines():
        is_stderr, line = refine_helm_output(line, is_stderr)

        if stop_collection_on_regex and re.search(stop_collection_on_regex, line):
            logging.info(
                "Stopping collection on regex match: %s", stop_collection_on_regex
            )
            return stderr, stdout, combined, False

        if is_stderr:
            logging.log(stderr_level, line.strip())
            stderr.append(line.strip())
        else:
            logging.log(stdout_level, line.strip())
            stdout.append(line.strip())

        combined.append(line.strip())

    return stderr, stdout, combined, True


def read_lines(
    sel,
    result: sp.Popen,
    request_stop: RequestStop | None = None,
    stop_collection_on_regex: str | None = None,
    stdout_level=logging.INFO,
    stderr_level=logging.WARNING,
) -> tuple[list[str], list[str], list[str]]:
    """Read lines from the subprocess output and log them."""
    stderr = []
    stdout = []
    combined = []

    logging.debug("Starting to read lines from subprocess output")

    collecting = True

    while len(sel.get_map()) != 0:
        for key, _ in sel.select(timeout=1):
            data = key.fileobj.readline()

            if not data:
                sel.unregister(key.fileobj)
                continue

            if collecting:
                stderr_part, stdout_part, combined_part, collecting = parse_data(
                    data,
                    key.fileobj is result.stderr,
                    stop_collection_on_regex,
                    stdout_level=stdout_level,
                    stderr_level=stderr_level,
                )

                stderr.extend(stderr_part)
                stdout.extend(stdout_part)
                combined.extend(combined_part)

        if request_stop is not None and request_stop.is_set():
            logging.info("Stopping subprocess output reading as requested")
            break

    return stderr, stdout, combined


def run_subprocess_tracing_logging(
    cmd,
    request_stop: RequestStop | None = None,
    bufsize: int = 1,
    exception_class: type = RuntimeError,
    stop_collection_on_regex: str | None = None,
    env: dict | None = None,
    stdout_level=logging.INFO,
    stderr_level=logging.WARNING,
) -> str:
    """Run a subprocess with logging and return its output."""
    logging.debug("Running command: %s", shlex.join(cmd))

    result = sp.Popen(
        cmd, stdout=sp.PIPE, stderr=sp.PIPE, bufsize=bufsize, text=True, env=env
    )

    if result.stdout is None or result.stderr is None:
        raise RuntimeError("Failed to capture stdout or stderr from the subprocess.")

    sel = selectors.DefaultSelector()
    for stream in [result.stdout, result.stderr]:
        sel.register(stream, selectors.EVENT_READ)

    stderr, _, combined = read_lines(
        sel,
        result,
        request_stop,
        stop_collection_on_regex,
        stdout_level=stdout_level,
        stderr_level=stderr_level,
    )

    if request_stop is not None and request_stop.is_set():
        logging.debug("Stopping subprocess as requested")
        result.kill()

    else:
        logging.debug("Subprocess completed, waiting for it to finish")

        for stream in [result.stdout, result.stderr]:
            stream.close()

        result.wait(timeout=5)

        if result.returncode != 0:
            logging.error(
                "Command failed with error code %s: %s",
                result.returncode,
                "\n".join(stderr),
            )
            raise exception_class(
                f"command {shlex.join(cmd)} failed: {result.returncode}\n{'\n'.join(stderr)}"
            )

    return "\n".join(combined)
