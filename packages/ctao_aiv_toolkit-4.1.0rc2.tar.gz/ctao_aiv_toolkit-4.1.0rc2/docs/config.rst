.. _aiv-config:

AIV Config
==========

Source of truth
~~~~~~~~~~~~~~~

The **source of truth** for the AIV toolkit configuration is in the ``aiv-config.yaml`` file, which consists of a set of key-value pairs within top-level key ``variables``.

aiv-config.yml is used to set variables for CI pipelines.

Env variables (local or CI) are used by Makefile as precedence over aiv-config.yml.

Makefile has it's own defaults for variables not set in aiv-config.yml or environment variables. # TODO: remove this

Makefile calls python CLI with variables from Makefile as defaults.

python CLI defaults use aiv-config.yml as defaults, unless overridden by environment variables or CLI arguments.


In CI pipelines
~~~~~~~~~~~~~~~~~~~~~

This file is directly imported by the gitlab CI pipelines as **CI variables**.

It is possible to override these variables in the Gitlab CI settings or in the pipeline configuration files (e.g. ``.gitlab-ci.yml``), but it is recommended to keep the configuration in the ``aiv-config.yaml`` file.

In local development
~~~~~~~~~~~~~~~~~~~~

Values from ``aiv-config.yaml`` are used as defaults for ``aiv-toolkit/Makefile`` variables.

It is possible to override these variables in the project-level Makefile (which includes ``aiv-toolkit/Makefile``), but it is recommended to keep the configuration in the ``aiv-config.yaml`` file.


Example
~~~~~~~

.. literalinclude:: ../aiv-config.yml
   :language: yaml
   :caption: Example of aiv-config.yaml

For further details on available variables, grouped per CI job, see :ref:`ci-pipelines`.


Dependencies
------------

CTAO projects often depend on other projects and packages, some of which are managed by CTAO. The AIV toolkit can track these dependencies and include them in the AIV report.

The AIV toolkit automatically detects python and helm dependencies, specified in ``pyproject.toml`` and in ``Chart.yaml`` files.

For the dependencies managed by CTAO (we call them *AIV Dependencies*), AIV requires additional verification:

* Code quality
* Nested dependencies

AIV Dependencies are specified in ``aiv-config-dependencies.yml``, for example:

.. code:: yaml

    dependencies:
    - gitlab_path: cta-computing/dpps/bdms/bdms
        revision: v0.1.0-rc1


To take into account these dependencies, the ``aiv-config.yaml`` **must** contain the following entry:

.. code:: yaml

    EXTRA_CONFIG_FILES: aiv-config-dependencies.yml


Dependency versions
-------------------

If any of the dependencies have unreleased versions, they will be marked as red in the report.
