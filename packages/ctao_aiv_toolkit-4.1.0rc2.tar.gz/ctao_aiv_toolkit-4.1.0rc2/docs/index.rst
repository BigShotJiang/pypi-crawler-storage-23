AIV Toolkit handbook
====================

**Version**: |version| **Date**: |today|

.. toctree::
    :maxdepth: 1
    :caption: Contents:

    quick-start
    config
    gitlab-ci/index
    support
    reference
    changelog



Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
