Support model
=============

Since DPPS AIV Toolkit is used in all DPPS subsystems, AIV team takes seriously supporting it in good shape.

* AIV team does their best to announce changes of the AIV toolkit to the subsystem AIV representatives as needed, but we only guarantee the announcements in the following cases:
   * for Releases of the toolkit versions
   * on the AIV meetings
   * any breaking changes, in accordance with SemVer
* Any discovered bugs of the toolkit are addressed with high priority, reports from subsystems are much appreciated.

Subsystems can safely use the last released toolkit version.

DPPS Releases are performed using released AIV toolkit versions. DPPS release candidates may use either released or release candidate versions of the AIV toolkit.

In some cases, the subsystem may want to follow the latest development version of the toolkit in order to test new features early. In this case, the subsystem developers should expect higher likelihood of issues. DPPS AIV appreciates effort of subsystem developers who choose to test latest development toolkit early.
