pre-commit
==========

``ci-precommit.yml`` defines a job ``pre-commit`` running the `pre-commit <https://pre-commit.com/>`_ checks.
