Test Report
===========

The CTAO Test Report Generator uses integration pipeline artifacts produced by the AIV Toolkit
and traceability information to generate PDF reports as required for the release.
The reports can be generated both for subsystems and the entire system.

The test report and static analysis rely on artifacts from the :ref:`collect-test-artifacts job <collect-test-artifacts>`.

The test report includes information from sonarqube on the quality gate,
coverage and static analysis issues.

It also includes a report on verified use cases for the given release,
which relies on annotations in a junit test report created by the test suite
and information about which uses cases are planned in which release of the system.
This information should now be taken from JAMA, via the jama gateway that allows
read-only access to the JAMA api, which is restricted to paid, named licenses.

This needs the ``JAMA_GATEWAY_USER`` and the ``JAMA_GATEWAY_PASSWORD`` :ref:`CI secrets <ci-secrets>`.

The server of each analyzes project is taken from the ``sonar-project.properties``.

In case of private projects or a server having the "Force authentication"
setting activated, a sonar "USER" token for the corresponding server is required.

You can set these tokens by creating :ref:`CI secrets <ci-secrets>` of the form

.. code::

   SONAR_API_TOKEN_<name>=<url>,<token>

e.g.:

.. code::

   SONAR_API_TOKEN_1=sonar-ctao.zeuthen.desy.de,squ_zzzzz
