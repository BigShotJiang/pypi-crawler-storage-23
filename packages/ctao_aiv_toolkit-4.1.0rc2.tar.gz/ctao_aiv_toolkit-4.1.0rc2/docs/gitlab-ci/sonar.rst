SonarQube Analysis
==================

``ci-sonar.yml`` defines the ``sonar`` job running the SonarQube
analysis tool and publishing the results to a SonarQube server
as configured in the ``sonar-project.properties``.

Needs the ``SONAR_TOKEN`` CI secret, see :ref:`ci-secrets`.
