Towncrier Changelog Snippets
============================

The file ``ci-changelog.yml`` defines the ``check-changelog`` job that
verifies that a merge request contains a corresponding change log snippet.

The check only runs in case ``docs/changes`` exists.

For small merge requests that do not introduce significant changes to
the project, the check can be skipped by adding the label ``no-changelog-needed``.

This steps needs the ``GITLAB_TOKEN`` :ref:`CI Secret <ci-secrets>`.
