Publish Python Packages
=======================

``ci-publish-pypi.yaml`` defines two jobs:

- ``build-python-dist`` creating python package artifacts (sdist + wheel by default)
- ``pypi`` publishing using `twine <https://twine.readthedocs.io/en/stable/>`_

With the default configuration of this job, it is assumed to use the trusted publishing workflow,
which is possible for projects uploaded to the `CTAO pypi organization <https://pypi.org/org/ctao/>`_.

A token for uploading will be generated automatically by the pipeline and verified by PyPI as
valid for the given project. Find more details on trusted publishing `in the PyPI docs <https://docs.pypi.org/trusted-publishers/>`_.

A trusted publisher can also be created for not-yet-existing projects to enable the first upload.
Contact the maintainers of the PyPI organization to set this up, currently these are Maximilian Linhoff
and Karl Kosack.

Alternatively, you can specify a ``PYPI_TOKEN`` secret, for official projects however, the trusted publishing approach
should be used.

Variables
---------

- ``PYTHON_PROJECT_DIR``: the directory containing the ``pyproject.toml`` to build.
  By default, the base of the repository will be used (``CI_PROJECT_DIR``).

For more variables, see the `twine docs on environment variables <https://twine.readthedocs.io/en/stable/#environment-variables>`_.
