.. _ci-publish:

Publish Helm Charts
===================

``ci-publish.yml`` defines the job ``publish-chart`` that
packages and publishes helm charts to an OCI registry,
by default to the `CTAO Harbor <https://harbor.cta-observatory.org/>`_.

Needs the ``HARBOR_TOKEN`` and ``HARBOR_LOGIN`` secrets, see :ref:`ci-secrets`.
