Linters
=======

The file ``ci-lint.yml`` defines several jobs for linting tools.

``hadolint``
------------

Runs the ``Dockerfile`` linter `hadolint <https://github.com/hadolint/hadolint>`_.

``helm-lint``
-------------
Runs `helm lint <https://helm.sh/docs/helm/helm_lint/>`_ for helm charts.

``pylint``
----------

Runs the `pylint <https://pylint.readthedocs.io/en/latest/>`_ for python code.

``kubeconform``
---------------

Runs the `kubeconform <https://github.com/yannh/kubeconform>`_ linter for Kubernetes manifests.
This check must pass for the pipeline to succeed.

``kube-lint``
-------------

Runs the `kube-lint <https://github.com/stackrox/kube-linter>`_ static analysis for Kubernetes manifests.
This is an advisory check, it is allowed to fail.
It's output is useful to inspect to improve the code.

``kube-score``
--------------

Runs the `kube-score <https://github.com/zegl/kube-score>`_ static analysis for Kubernetes manifests.
This is an advisory check, it is allowed to fail.
It's output is useful to inspect to improve the code.
