.. _ci-build:

Build Docker Images
===================


The file ``ci-build.yml`` defines two jobs related to building docker images.

``build``
---------

The ``build`` job is using `kaniko <https://github.com/GoogleContainerTools/kaniko>`_ to build docker images and
publish them to a OCI registry, by default the `CTAO Harbor <https://harbor.cta-observatory.org>`_.

This jobs needs the ``HARBOR_LOGIN`` and ``HARBOR_TOKEN`` CI/CD secrets, see :ref:`ci-secrets`.

By default, one image is build and the tag is created based on the Git tag information.


To build multiple images, you can parametrize the job using ``parallel.matrix`` and ``variables``
like in the example below:

.. code:: yaml

   build:
     parallel:
       matrix:
         - IMAGE: ["server", "client"]
     variables:
       CI_HARBOR_REGISTRY_IMAGE: harbor.cta-observatory.org/dpps/${CI_PROJECT_NAME}-${IMAGE}:${DOCKER_TAG}
       AIV_DOCKER_IMAGE_CONTEXT: docker/${IMAGE}


``sign``
--------

This step is signing the build docker images of the ``build`` step using `cosign <https://github.com/sigstore/cosign>`_.

This needs the ``COSIGN_PRIVATE_KEY`` secret to be setup, see :ref:`ci-secrets`.

This step is currently disabled by default until it's clear how to provide the proper signature certificates.
