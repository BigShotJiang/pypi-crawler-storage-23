"""Run a CWL file with the given input data and return the result."""

# We considered cwltest "..a testing tool for checking the output of Tools and Workflows described with the Common Workflow Language.""
# It also has a pytest plugin which works well.
# We did not use it because:
# * it does not allow to just use our "verifies" markers without complex workarounds
# * its output matching is not sufficient for us, we need to inspect the output files in peculiar ways
# https://gitlab.cta-observatory.org/cta-computing/dpps/aiv/dpps-aiv-toolkit/-/merge_requests/142#note_249442

import json
import logging
import subprocess
from os import PathLike
from pathlib import Path


def run_cwl_with_input_file(
    cwl_file: PathLike,
    input_data: PathLike,
    use_apptainer: bool = False,
    allow_container: bool = False,
    cwd: PathLike = None,
) -> tuple[subprocess.CompletedProcess, dict]:
    """Run a CWL file with the given input data file and return the result."""
    summary_fn = cwd / "summary.json"

    command = [
        "cwl-runner",
        "--debug",
        "--write-summary",
        str(summary_fn),
    ]

    if allow_container:
        if use_apptainer:
            command.extend(
                [
                    "--singularity",
                ]
            )

    else:
        if use_apptainer:
            raise RuntimeError("Container is not allowed, but apptainer is requested!")

        command.append("--no-container")

    command.extend(
        [
            str(cwl_file),
            str(input_data),
        ]
    )

    logging.debug("Running command: %s", " ".join(command))

    r = subprocess.run(
        command,
        capture_output=True,
        check=False,
        cwd=cwd,
    )

    logging.debug("Command output: %s", r.stdout.decode("utf-8"))
    logging.debug("Command error: %s", r.stderr.decode("utf-8"))

    return r, summary_fn


def load_summary_files(summary: dict) -> None:
    """Load contents of files listed in the summary into the dictionary."""
    for k, v in summary.items():
        if isinstance(v, dict) and v.get("location", "").startswith("file://"):
            fn = v["location"].replace("file://", "")
            logging.debug("Loading file %s", fn)
            with open(fn) as f:
                summary[k] = f.read().strip()


def run_cwl(
    cwl_file: PathLike,
    input_data: dict | PathLike,
    use_apptainer: bool = False,
    allow_container: bool = False,
    load_files: bool = False,
    raise_on_return: bool = True,
    cwd: PathLike = None,
) -> dict:
    """Run a CWL file with the given input data as a dictionary or a file path."""
    if isinstance(input_data, dict):
        input_data_fn = cwd / "input.json"
        with input_data_fn.open("w") as temp_input_file:
            json.dump(input_data, temp_input_file)
    else:
        input_data_fn = input_data

    cwl_file = Path(cwl_file)

    process_result, summary_fn = run_cwl_with_input_file(
        cwl_file.absolute(),
        input_data_fn.absolute(),
        use_apptainer,
        allow_container,
        cwd,
    )

    if process_result.returncode != 0:
        logging.error("CWL tool failed with return code %d", process_result.returncode)
        if raise_on_return:
            # this is a more readable error message than the one from subprocess exception
            raise RuntimeError(
                f"CWL tool failed: {process_result.stderr.decode('utf-8')}"
            )

    try:
        with open(summary_fn) as summary_file:
            summary = json.load(summary_file)
    except json.JSONDecodeError as e:
        with open(summary_fn) as summary_file:
            raise RuntimeError(
                f"Failed to parse summary file {summary_fn}: {e}, content: {summary_file.read()}"
            ) from e

    if load_files:
        load_summary_files(summary)

    return dict(
        stdout=process_result.stdout.decode("utf-8"),
        stderr=process_result.stderr.decode("utf-8"),
        returncode=process_result.returncode,
        summary=summary,
    )
