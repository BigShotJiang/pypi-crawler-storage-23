"""Unit tests for CWL tools and workflows."""

import pytest
from cwlcall import run_cwl


def test_echo_tool(tmp_path):
    """Run the echo workflow with a string input and check the output."""
    r = run_cwl(
        "workflows/echo-workflow.cwl",
        input_data=dict(input_string="Hello, World!"),
        load_files=True,
        raise_on_return=True,
        cwd=tmp_path,
    )

    assert r["summary"]["output_string"] == "Hello, World!"


def test_echo_tool_container(tmp_path):
    """Check that we can still run containerized tool by skipping the container."""
    r = run_cwl(
        "workflows/subdir/echo-tool-container.cwl",
        input_data=dict(input_string="Hello, World!"),
        load_files=True,
        raise_on_return=True,
        allow_container=False,
        cwd=tmp_path,
    )

    assert r["summary"]["output_string"] == "Hello, World!"


@pytest.mark.verifies_usecase("DPPS-UC-999-9.9")
def test_echo_workflow(tmp_path):
    """Run the echo tool with a string input and check the output."""
    r = run_cwl(
        "workflows/echo-tool.cwl",
        input_data=dict(input_string="test input string"),
        load_files=True,
        cwd=tmp_path,
    )

    assert r["summary"]["output_string"] == "test input string"
