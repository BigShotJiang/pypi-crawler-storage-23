"""A simple HTTP server that accepts PUT requests to save files."""

import json
import logging
import os
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse


class Handler(BaseHTTPRequestHandler):
    """A simple HTTP server that accepts PUT requests to save files."""

    def do_GET(self):  # noqa: N802
        """Return file content."""
        path = urlparse(self.path).path

        print(f"Received GET request for {path}")

        if path == "/logs.ndjson":
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()

            with open("logs.ndjson", "rb") as logfile:
                self.wfile.write(logfile.read())

        elif path == "/":
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()

            message = "Hello, World! Here is the testsvc server.\n"
            self.wfile.write(bytes(message, "utf8"))

        else:
            self.send_response(404)
            self.send_header("Content-type", "text/plain")
            self.end_headers()
            self.wfile.write(b"404 Not Found\n")

    def write_log(self, message_dict_list: list[dict]) -> None:
        """Write logs to file."""
        with open("logs.ndjson", "ab+") as logfile:
            for message_dict in message_dict_list:
                logfile.write(json.dumps(message_dict).encode("utf-8") + b"\n")

        # we also write to a human-readable log file as well, to avoid requiring json parsing at client side
        with open("logs.txt", "a+") as logfile:
            for message_dict in message_dict_list:
                if (
                    os.environ["STREAM_ONLY_TESTS"] == "true"
                    and message_dict.get("kubernetes", {})
                    .get("annotations", {})
                    .get("helm.sh/hook")
                    != "test"
                ):
                    continue

                short_date = datetime.fromtimestamp(message_dict["date"]).strftime(
                    "%H:%M:%S"
                )
                logfile.write(
                    f"\033[32m{message_dict['kubernetes']['pod_name']}\033[0m \033[33m{short_date}\033[0m {message_dict['log']}\n"
                )

    def do_POST(self):  # noqa: N802
        """Dump posted logs.

        This is a simple backend for storing logs collected by fluentbit
        """
        content_length = int(self.headers["Content-Length"])
        post_data = self.rfile.read(content_length)

        # We are flushing the buffer for every write to make stream easier to view.

        try:
            # Attempt to parse as JSON. If successful, print formatted
            message_dict_list = json.loads(post_data.decode("utf-8"))

            self.write_log(message_dict_list)

        except json.JSONDecodeError:
            # If not JSON, print raw data
            logging.error("unable to decode log: %s", post_data.decode("utf-8"))

        self.send_response(200)
        self.send_header("Content-type", "text/plain")
        self.end_headers()
        self.wfile.write(b"POST request received and processed.\n")

    def do_PUT(self):  # noqa: N802
        """Save a file following a HTTP PUT request."""
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        path = parsed.path

        origin = query.get("origin", ["default"])[0]

        logging.info("Received PUT request for %s, parsed as %s", self.path, parsed)
        logging.info("Origin: %s", origin)

        filename = os.path.basename(path)

        if filename not in ["report.xml", "coverage.xml"]:
            self.send_response(400, "Bad Request")
            self.end_headers()
            reply_body = 'Only "report.xml" and "coverage.xml" are supported\n'
            self.wfile.write(reply_body.encode("utf-8"))

        file_length = int(self.headers["Content-Length"])
        with open(filename, "wb") as output_file:
            output_file.write(self.rfile.read(file_length))

        self.send_response(201, "Created")
        self.end_headers()
        reply_body = f'Saved "{filename}"\n'
        self.wfile.write(reply_body.encode("utf-8"))


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    with HTTPServer(("0.0.0.0", 8000), Handler) as server:
        server.serve_forever()
