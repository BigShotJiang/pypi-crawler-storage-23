import json
import logging

import requests


def test_inspect_service_log():
    found = {"log": False, "events": False}

    lines = []
    selected_events = []

    for line in requests.get("http://testkit:8000/logs.ndjson").content.splitlines():
        try:
            line_dict = json.loads(line.decode("utf-8"))
        except json.JSONDecodeError:
            logging.error("Could not parse line as JSON: '%s'", line)
            raise

        if (
            line_dict.get("kubernetes", {}).get("container_name")
            == "generate-certificates"
        ):
            lines.append(line_dict["log"])
            if (
                "Certificates generated and stored" in line_dict["log"]
                or "Certificates already generated" in line_dict["log"]
            ):
                found["log"] = True

        if (
            line_dict.get("involvedObject", {}).get("name", None)
            == "cert-generator-grid-generate-certificates"
        ):
            selected_events.append(line_dict)

            if line_dict.get("message") == "Job completed":
                logging.info(
                    "found all requested events within %s seconds: %s",
                    selected_events[-1]["date"] - selected_events[0]["date"],
                    [f"{c['date']}: {c['message']}" for c in selected_events],
                )

                found["events"] = True

        if found["log"] and found["events"]:
            break

    assert found["log"], "Did not find expected entries in logs, lines: " + (
        "\n".join(lines)
    )
