# adopted from https://gitlab.cta-observatory.org/cta-computing/dpps/aiv/dpps-docker-compose/-/blob/1e306f2b46e4a3ca33b76767dd6edfb97b828186/generate_certificates.sh

#!/bin/bash
# -*- coding: utf-8 -*-
# Copyright European Organization for Nuclear Research (CERN) since 2012
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
export PASSPHRASE=123456

DAYS=9000
mkdir -p certs dirac/server/certs/ssh dirac/client/certs dirac/ce/certs/ssh
cp openssl_config_ca.cnf certs/openssl_config_ca.cnf
cd certs

# Development CA
if [ -f ../dpps_test_ca.key.pem ]; then
  echo "CA certificates already exist, will not regenerate it"
  cp -fv ../dpps_test_ca.key.pem ../dpps_test_ca.pem .
  openssl x509 -noout -text -in dpps_test_ca.pem
else
  ls -ltro ..
  echo "Generating CA certificates"
  openssl genrsa -out dpps_test_ca.key.pem -passout env:PASSPHRASE 2048
  openssl req -x509 -new -batch -key dpps_test_ca.key.pem -days $DAYS -out dpps_test_ca.pem -subj "/CN=DPPS Development CA" -passin env:PASSPHRASE
fi

hash=$(openssl x509 -noout -hash -in dpps_test_ca.pem)
ln -sf dpps_test_ca.pem $hash.0

# Generate CRL
touch index.txt
echo 1000 > crlnumber
openssl ca -config openssl_config_ca.cnf -keyfile dpps_test_ca.key.pem -cert dpps_test_ca.pem -gencrl -out dpps_test_ca.crl.r0
ln -sf dpps_test_ca.crl.r0 $hash.r0

echo "Generating certificates for Rucio server and $EXTRA_SERVER_NAMES"

# The service certificates
for CN in ${HELM_RELEASE_NAME}-rucio-server $EXTRA_SERVER_NAMES
do
  SAN="subjectAltName=DNS:$CN,DNS:${HELM_RELEASE_NAME}-$CN,DNS:localhost,DNS:$CN.$CN_BASE_DOMAIN,DNS:*.$CN.$CN_BASE_DOMAIN"
  openssl req -new -newkey rsa:2048 -noenc -keyout "hostcert_$CN.key.pem" -subj "/CN=$CN" > "hostcert_$CN.csr"
  openssl x509 -req -days $DAYS -CAcreateserial -extfile <(printf "%s" "$SAN") -in "hostcert_$CN.csr" -CA dpps_test_ca.pem -CAkey dpps_test_ca.key.pem -out "hostcert_$CN.pem" -passin env:PASSPHRASE
done


mv hostcert_${HELM_RELEASE_NAME}-rucio-server.pem hostcert_rucio-server.pem
mv hostcert_${HELM_RELEASE_NAME}-rucio-server.key.pem hostcert_rucio-server.key.pem

cat "hostcert_rucio-server.pem" "hostcert_rucio-server.key.pem" > "hostcert_rucio-server.certkey.pem"

rm ./*.csr

chmod 644 *.pem

function store-file-as-secret() {
  suffix=${1:?}
  shift 1
  key_fns=$@

  # if secret already exists, do not recreate it
  if kubectl get secret ${HELM_RELEASE_NAME}-${suffix}; then
    echo "Secret ${HELM_RELEASE_NAME}-${suffix} already exists, will not recreate it."
  else
    echo "Creating secret ${HELM_RELEASE_NAME}-${suffix}..."
    kubectl create secret generic ${HELM_RELEASE_NAME}-${suffix} \
        $(for key_fn in $key_fns; do echo --from-file=${key_fn}; done) \
          --dry-run=client -o yaml | kubectl apply -f -
  fi
}

function create-user-certificate {
  name="${1:?}"
  suffix="${2}"

  openssl req -new -newkey rsa:2048 -noenc \
    -keyout dppsuser$suffix.key.pem \
    -subj "/CN=$name" \
    -addext "subjectAltName=email:dpps-test$suffix@cta-observatory.org" \
    > dppsuser$suffix.csr
  openssl x509 -req -days $DAYS -CAcreateserial -extfile <(printf "keyUsage = critical, digitalSignature, keyEncipherment") \
          -in dppsuser$suffix.csr -CA dpps_test_ca.pem -CAkey dpps_test_ca.key.pem -out dppsuser$suffix.pem
  cat "dppsuser$suffix.pem" "dppsuser$suffix.key.pem" > "dppsuser$suffix.certkey.pem"

  chmod 600 dppsuser$suffix.pem
  chmod 400 dppsuser$suffix.key.pem

  store-file-as-secret dppsuser$suffix-certkey \
      dppsuser.pem=dppsuser$suffix.pem  \
      dppsuser.key.pem=dppsuser$suffix.key.pem  \
      dppsuser.certkey.pem=dppsuser$suffix.certkey.pem
}
