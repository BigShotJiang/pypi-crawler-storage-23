# hash=$(openssl x509 -noout -hash -in /etc/grid-security/ca.pem)

mkdir -pv /etc/grid-security/certificates
update-ca-trust force-enable

# ln -sf /etc/grid-security/ca.pem /etc/grid-security/certificates/$hash.0
cp -fv /etc/grid-security/ca.pem  /etc/pki/ca-trust/source/anchors/rucio-ca.pem
update-ca-trust extract
ls -lotr /etc/pki/tls/certs/ca-bundle.crt

# openssl x509 -in /etc/grid-security/ca.pem -noout -text

while true; do
    openssl s_client -connect bdms-rucio-server:443 && break
    sleep 3
done
