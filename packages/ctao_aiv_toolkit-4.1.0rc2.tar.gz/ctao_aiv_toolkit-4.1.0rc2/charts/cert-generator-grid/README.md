This chart generates certificates for the subsystems in the AIV project when it is installed.
It runs a Job that creates certificates as Secrets in the Kubernetes cluster.

In the future the certificates will be created by cert-manager, but for now they are created by a Job.

The purpose of this chart is to provide a way to generate certificates which is independent of the subsystems themselves. Once cert-manager is in place, the certificates are generated dynamically.

In the production environment, the certificates will be signed by the AIV CA and/or by the Let's Encrypt CA.
