#!/bin/bash

set -e

echo "working in $(pwd)"
for SUBMODULE in $@; do
    if [[ ! -d $SUBMODULE ]]; then
        echo "$SUBMODULE is not a directory, ignoring"
        continue
    fi
    echo "Checking submodule in ${SUBMODULE}"

    echo $(git -C $SUBMODULE log -n 1)

    staged_commit=$(git submodule status --cached -- $SUBMODULE | awk '{sub(/^\+/, "", $1); print $1}')
    echo "staged    commit in $SUBMODULE is ${staged_commit:?submodule commit is empty, something is wrong in the repo!}"

    submodule_commit=$(git -C $SUBMODULE rev-parse HEAD)
    echo "submodule commit in $SUBMODULE is ${submodule_commit:?submodule commit is empty, something is wrong in the repo!}"

    committed_commit=$(git rev-parse HEAD:"$SUBMODULE")
    echo "committed commit in $SUBMODULE is ${committed_commit:?last commit is empty, something is wrong in the repo!}"

    if [ $submodule_commit != $staged_commit ]; then
        echo "NOTE: $SUBMODULE staged commit differs from submodule commit: did you want to 'git add'?"
    fi

    # awk is more delicate than yq or pyyaml, but it does not modify yaml structure and is more available
    awk 'pick == 1 && /ref:/ {
        gsub("ref:.*", "ref: " newref, $0)
           }

           /- project:/ {
        split($(NF), split_path, "/");
        included_submodule = split_path[length(split_path)];
        gsub("'"'"'", "", included_submodule);

        if ( included_submodule == submodule ) {
           pick = 1;
        } else {
           pick = 0;
        }
           }
           1' \
        newref=$staged_commit submodule=$SUBMODULE \
        .gitlab-ci.yml > .tmp.gitlab-ci.yml

    if diff .tmp.gitlab-ci.yml .gitlab-ci.yml; then
        echo "NOT updated .gitlab-ci.yml"
        rm .tmp.gitlab-ci.yml
    else
        echo "updated .gitlab-ci.yml"
        mv -fv .tmp.gitlab-ci.yml .gitlab-ci.yml
    fi

done
