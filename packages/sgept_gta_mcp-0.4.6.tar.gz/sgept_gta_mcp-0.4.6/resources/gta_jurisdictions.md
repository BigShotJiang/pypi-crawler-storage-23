# GTA Jurisdictions Reference

## Important Notes

### India Code Anomaly

⚠️ **India uses GTA jurisdiction code 699, NOT the standard UN M49 code 356.**

The MCP server handles this automatically via ISO code conversion (IND → 699), but agents using
raw UN M49 codes must be aware of this discrepancy. Always use ISO code "IND" when calling MCP tools.

### EU Jurisdiction Handling

The European Union presents special jurisdiction assignment rules:

- **EU Regulations** → implementing_jurisdiction = "European Union" (applies EU-wide immediately)
- **EU Directives** → each member state transposes separately (implementing_jurisdiction = individual member state)
- **EU State Aid decisions** → implementing_jurisdiction = the beneficiary member state, NOT "European Union"

When analyzing EU measures, check the intervention type and legal instrument to determine correct jurisdiction assignment.

### IFI/NFI Jurisdiction Assignment

When an international financial institution (World Bank, EIB, EBRD, etc.) or national financial
institution provides a loan, grant, or guarantee:

- **Implementing jurisdiction** = beneficiary country (where the funds are used)
- **NOT** the IFI headquarters location

Example: A World Bank loan to Kenya for infrastructure → implementing_jurisdiction = "Kenya", not "United States".

## Jurisdiction Table

|jurisdiction_id|jurisdiction_name|gta_jurisdiction_id|iso_code|jurisdiction_name_short|jurisdiction_name_adj|slug|name_short|name_adj|web_id|
|---------------|-----------------|-------------------|--------|-----------------------|---------------------|----|----------|--------|------|
|4|Afghanistan|1|AFG|Afghanistan|Afghan|afghanistan|Afghanistan|Afghan|AF|
|8|Albania|2|ALB|Albania|Albanian|albania|Albania|Albanian|AL|
|12|Algeria|3|DZA|Algeria|Algerian|algeria|Algeria|Algerian|DZ|
|16|American Samoa|4|ASM|American Samoa|American Samoan|american-samoa|American Samoa|American Samoan|AS|
|20|Andorra|5|AND|Andorra|Andorran|andorra|Andorra|Andorran|AD|
|24|Angola|6|AGO|Angola|Angolan|angola|Angola|Angolan|AO|
|28|Antigua & Barbuda|8|ATG|Antigua & Barbuda|Antiguan|antigua-barbuda|Antigua & Barbuda|Antiguan|AG|
|31|Azerbaijan|14|AZE|Azerbaijan|Azerbaijani|azerbaijan|Azerbaijan|Azerbaijani|AZ|
|32|Argentina|9|ARG|Argentina|Argentinian|argentina|Argentina|Argentinian|AR|
|36|Australia|12|AUS|Australia|Australian|australia|Australia|Australian|AU|
|40|Austria|13|AUT|Austria|Austrian|austria|Austria|Austrian|AT|
|44|Bahamas|15|BHS|Bahamas|Bahamian|bahamas|Bahamas|Bahamian|BS|
|48|Bahrain|16|BHR|Bahrain|Bahraini|bahrain|Bahrain|Bahraini|BH|
|50|Bangladesh|17|BGD|Bangladesh|Bangladeshi|bangladesh|Bangladesh|Bangladeshi|BD|
|51|Armenia|10|ARM|Armenia|Armenian|armenia|Armenia|Armenian|AM|
|52|Barbados|18|BRB|Barbados|Barbadian|barbados|Barbados|Barbadian|BB|
|56|Belgium|20|BEL|Belgium|Belgian|belgium|Belgium|Belgian|BE|
|60|Bermuda|23|BMU|Bermuda|Bermudian|bermuda|Bermuda|Bermudian|BM|
|64|Bhutan|24|BTN|Bhutan|Bhutanese|bhutan|Bhutan|Bhutanese|BT|
|68|Bolivia|25|BOL|Bolivia|Bolivian|bolivia|Bolivia|Bolivian|BO|
|70|Bosnia & Herzegovina|26|BIH|Bosnia & Herzegovina|Bosnian|bosnia-herzegovina|Bosnia & Herzegovina|Bosnian|BA|
|72|Botswana|27|BWA|Botswana|Botswanian|botswana|Botswana|Botswanian|BW|
|76|Brazil|28|BRA|Brazil|Brazilian|brazil|Brazil|Brazilian|BR|
|84|Belize|21|BLZ|Belize|Belizean|belize|Belize|Belizean|BZ|
|90|Solomon Islands|193|SLB|Solomon Islands|Solomon Island|solomon-islands|Solomon Islands|Solomon Island|SB|
|92|British Virgin Islands|29|VGB|British Virgin Islands|British Virgin Island|british-virgin-islands|British Virgin Islands|British Virgin Island|VG|
|96|Brunei Darussalam|30|BRN|Brunei Darussalam|Bruneian|brunei-darussalam|Brunei Darussalam|Bruneian|BN|
|100|Bulgaria|31|BGR|Bulgaria|Bulgarian|bulgaria|Bulgaria|Bulgarian|BG|
|104|Myanmar|140|MMR|Myanmar|Burmese|myanmar|Myanmar|Burmese|MM|
|108|Burundi|33|BDI|Burundi|Burundian|burundi|Burundi|Burundian|BI|
|112|Belarus|19|BLR|Belarus|Belarusian|belarus|Belarus|Belarusian|BY|
|116|Cambodia|34|KHM|Cambodia|Cambodian|cambodia|Cambodia|Cambodian|KH|
|120|Cameroon|35|CMR|Cameroon|Cameroonian|cameroon|Cameroon|Cameroonian|CM|
|124|Canada|36|CAN|Canada|Canadian|canada|Canada|Canadian|CA|
|132|Cape Verde|37|CPV|Cape Verde|Cape Verdean|cape-verde|Cape Verde|Cape Verdean|CV|
|136|Cayman Islands|38|CYM|Cayman Islands|Caymanian|cayman-islands|Cayman Islands|Caymanian|KY|
|140|Central African Republic|39|CAF|Central African Republic|Central African |central-african-republic|Central African Republic|Central African |CF|
|144|Sri Lanka|197|LKA|Sri Lanka|Sri Lankan|sri-lanka|Sri Lanka|Sri Lankan|LK|
|148|Chad|40|TCD|Chad|Chadian|chad|Chad|Chadian|TD|
|152|Chile|41|CHL|Chile|Chilean|chile|Chile|Chilean|CL|
|156|China|42|CHN|China|Chinese |china|China|Chinese |CN|
|158|Chinese Taipei|43|TWN|Chinese Taipei|Taiwanese|chinese-taipei|Chinese Taipei|Taiwanese|TW|
|170|Colombia|44|COL|Colombia|Colombian|colombia|Colombia|Colombian|CO|
|174|Comoros|45|COM|Comoros|Comorian|comoros|Comoros|Comorian|KM|
|175|Mayotte|131|MYT|Mayotte|Mahoran|mayotte|Mayotte|Mahoran|YT|
|178|Congo|46|COG|Congo|Congolese|congo|Congo|Congolese|CG|
|180|DR Congo|55|COD|DR Congo|Congolese|dr-congo|DR Congo|Congolese|CD|
|184|Cook Islands|47|COK|Cook Islands|Cook Island|cook-islands|Cook Islands|Cook Island|CK|
|188|Costa Rica|48|CRI|Costa Rica|Costa Rican|costa-rica|Costa Rica|Costa Rican|CR|
|191|Croatia|50|HRV|Croatia|Croatian|croatia|Croatia|Croatian|HR|
|192|Cuba|51|CUB|Cuba|Cuban|cuba|Cuba|Cuban|CU|
|196|Cyprus|52|CYP|Cyprus|Cypriot|cyprus|Cyprus|Cypriot|CY|
|203|Czechia|53|CZE|Czechia|Czech|czechia|Czechia|Czech|CZ|
|204|Benin|22|BEN|Benin|Beninese|benin|Benin|Beninese|BJ|
|208|Denmark|56|DNK|Denmark|Danish|denmark|Denmark|Danish|DK|
|212|Dominica|58|DMA|Dominica|Dominican |dominica|Dominica|Dominican |DM|
|214|Dominican Republic|59|DOM|Dominican Republic|Dominican|dominican-republic|Dominican Republic|Dominican|DO|
|218|Ecuador|60|ECU|Ecuador|Ecuadorian|ecuador|Ecuador|Ecuadorian|EC|
|222|El Salvador|62|SLV|El Salvador|Salvadorean|el-salvador|El Salvador|Salvadorean|SV|
|226|Equatorial Guinea|63|GNQ|Equatorial Guinea|Equatorial Guinean|equatorial-guinea|Equatorial Guinea|Equatorial Guinean|GQ|
|231|Ethiopia|66|ETH|Ethiopia|Ethiopian|ethiopia|Ethiopia|Ethiopian|ET|
|232|Eritrea|64|ERI|Eritrea|Eritrean|eritrea|Eritrea|Eritrean|ER|
|233|Estonia|65|EST|Estonia|Estonian|estonia|Estonia|Estonian|EE|
|234|Faeroe Islands|68|FRO|Faeroe Islands|Faeroese|faeroe-islands|Faeroe Islands|Faeroese|FO|
|238|Falkland Islands|69|FLK|Falkland Islands|Falkland Island|falkland-islands|Falkland Islands|Falkland Island|FK|
|242|Fiji|70|FJI|Fiji|Fijian|fiji|Fiji|Fijian|FJ|
|246|Finland|71|FIN|Finland|Finnish|finland|Finland|Finnish|FI|
|251|France|72|FRA|France|French|france|France|French|FR|
|254|French Guiana|73|GUF|French Guiana|French Guianese|french-guiana|French Guiana|French Guianese|GF|
|258|French Polynesia|74|PYF|French Polynesia|French Polynesian|french-polynesia|French Polynesia|French Polynesian|PF|
|262|Djibouti|57|DJI|Djibouti|Djiboutian|djibouti|Djibouti|Djiboutian|DJ|
|266|Gabon|75|GAB|Gabon|Gabonese|gabon|Gabon|Gabonese|GA|
|268|Georgia|77|GEO|Georgia|Georgian|georgia|Georgia|Georgian|GE|
|270|Gambia|76|GMB|Gambia|Gambian|gambia|Gambia|Gambian|GM|
|275|State of Palestine|158|PSE|State of Palestine|Palestinian|state-of-palestine|State of Palestine|Palestinian|PS|
|276|Germany|78|DEU|Germany|German|germany|Germany|German|DE|
|288|Ghana|79|GHA|Ghana|Ghanaian|ghana|Ghana|Ghanaian|GH|
|296|Kiribati|107|KIR|Kiribati|Kiribati|kiribati|Kiribati|Kiribati|KI|
|300|Greece|80|GRC|Greece|Greek|greece|Greece|Greek|GR|
|304|Greenland|81|GRL|Greenland|Greenlandic|greenland|Greenland|Greenlandic|GL|
|308|Grenada|82|GRD|Grenada|Grenadian|grenada|Grenada|Grenadian|GD|
|312|Guadeloupe|83|GLP|Guadeloupe|Guadeloupean|guadeloupe|Guadeloupe|Guadeloupean|GP|
|316|Guam|84|GUM|Guam|Guamanian|guam|Guam|Guamanian|GU|
|320|Guatemala|85|GTM|Guatemala|Guatemalan|guatemala|Guatemala|Guatemalan|GT|
|324|Guinea|86|GIN|Guinea|Guinean|guinea|Guinea|Guinean|GN|
|328|Guyana|88|GUY|Guyana|Guyanese|guyana|Guyana|Guyanese|GY|
|332|Haiti|89|HTI|Haiti|Haitian|haiti|Haiti|Haitian|HT|
|336|Vatican|90|VAT|Vatican|Vatican|vatican|Vatican|Vatican|VA|
|340|Honduras|91|HND|Honduras|Honduran|honduras|Honduras|Honduran|HN|
|344|Hong Kong|92|HKG|Hong Kong|Hong Kong|hong-kong|Hong Kong|Hong Kong|HK|
|348|Hungary|93|HUN|Hungary|Hungarian|hungary|Hungary|Hungarian|HU|
|352|Iceland|94|ISL|Iceland|Icelandic|iceland|Iceland|Icelandic|IS|
|360|Indonesia|96|IDN|Indonesia|Indonesian|indonesia|Indonesia|Indonesian|ID|
|364|Iran|97|IRN|Iran|Iranian|iran|Iran|Iranian|IR|
|368|Iraq|98|IRQ|Iraq|Iraqi|iraq|Iraq|Iraqi|IQ|
|372|Ireland|99|IRL|Ireland|Irish|ireland|Ireland|Irish|IE|
|376|Israel|100|ISR|Israel|Israeli|israel|Israel|Israeli|IL|
|381|Italy|101|ITA|Italy|Italian|italy|Italy|Italian|IT|
|384|Ivory Coast|49|CIV|Ivory Coast|Ivorian|ivory-coast|Ivory Coast|Ivorian|CI|
|388|Jamaica|102|JAM|Jamaica|Jamaican|jamaica|Jamaica|Jamaican|JM|
|392|Japan|103|JPN|Japan|Japanese|japan|Japan|Japanese|JP|
|398|Kazakhstan|105|KAZ|Kazakhstan|Kazakhstani|kazakhstan|Kazakhstan|Kazakhstani|KZ|
|400|Jordan|104|JOR|Jordan|Jordanian|jordan|Jordan|Jordanian|JO|
|404|Kenya|106|KEN|Kenya|Kenyan|kenya|Kenya|Kenyan|KE|
|408|DPR Korea|234|PRK|DPR Korea|North Korean|dpr-korea|DPR Korea|North Korean|KP|
|410|Republic of Korea|54|KOR|Republic of Korea|South Korean|republic-of-korea|Republic of Korea|South Korean|KR|
|414|Kuwait|108|KWT|Kuwait|Kuwaiti|kuwait|Kuwait|Kuwaiti|KW|
|417|Kyrgyzstan|109|KGZ|Kyrgyzstan|Kyrgyz|kyrgyzstan|Kyrgyzstan|Kyrgyz|KG|
|418|Lao|110|LAO|Lao|Lao|lao|Lao|Lao|LA|
|422|Lebanon|112|LBN|Lebanon|Lebanese|lebanon|Lebanon|Lebanese|LB|
|426|Lesotho|113|LSO|Lesotho|Basotho|lesotho|Lesotho|Basotho|LS|
|428|Latvia|111|LVA|Latvia|Latvian|latvia|Latvia|Latvian|LV|
|430|Liberia|114|LBR|Liberia|Liberian|liberia|Liberia|Liberian|LR|
|434|Libya|115|LBY|Libya|Libyan|libya|Libya|Libyan|LY|
|438|Liechtenstein|116|LIE|Liechtenstein|Liechtensteinian|liechtenstein|Liechtenstein|Liechtensteinian|LI|
|440|Lithuania|117|LTU|Lithuania|Lithuanian|lithuania|Lithuania|Lithuanian|LT|
|442|Luxembourg|118|LUX|Luxembourg|Luxembourgian|luxembourg|Luxembourg|Luxembourgian|LU|
|446|Macao|119|MAC|Macao|Macanese|macao|Macao|Macanese|MO|
|450|Madagascar|121|MDG|Madagascar|Madagascan|madagascar|Madagascar|Madagascan|MG|
|454|Malawi|122|MWI|Malawi|Malawian|malawi|Malawi|Malawian|MW|
|458|Malaysia|123|MYS|Malaysia|Malaysian|malaysia|Malaysia|Malaysian|MY|
|462|Maldives|124|MDV|Maldives|Maldivian|maldives|Maldives|Maldivian|MV|
|466|Mali|125|MLI|Mali|Malian|mali|Mali|Malian|ML|
|470|Malta|126|MLT|Malta|Maltese|malta|Malta|Maltese|MT|
|474|Martinique|128|MTQ|Martinique|Martinican|martinique|Martinique|Martinican|MQ|
|478|Mauritania|129|MRT|Mauritania|Mauritanian|mauritania|Mauritania|Mauritanian|MR|
|480|Mauritius|130|MUS|Mauritius|Mauritanian|mauritius|Mauritius|Mauritanian|MU|
|484|Mexico|132|MEX|Mexico|Mexican|mexico|Mexico|Mexican|MX|
|492|Monaco|134|MCO|Monaco|Monacan|monaco|Monaco|Monacan|MC|
|496|Mongolia|135|MNG|Mongolia|Mongolian|mongolia|Mongolia|Mongolian|MN|
|498|Republic of Moldova|170|MDA|Republic of Moldova|Moldovan|republic-of-moldova|Republic of Moldova|Moldovan|MD|
|499|Montenegro|136|MNE|Montenegro|Montenegrin|montenegro|Montenegro|Montenegrin|ME|
|500|Montserrat|137|MSR|Montserrat|Montserratian|montserrat|Montserrat|Montserratian|MS|
|504|Morocco|138|MAR|Morocco|Moroccan|morocco|Morocco|Moroccan|MA|
|508|Mozambique|139|MOZ|Mozambique|Mozambican|mozambique|Mozambique|Mozambican|MZ|
|512|Oman|155|OMN|Oman|Omani|oman|Oman|Omani|OM|
|516|Namibia|141|NAM|Namibia|Namibian|namibia|Namibia|Namibian|NA|
|520|Nauru|142|NRU|Nauru|Nauruan|nauru|Nauru|Nauruan|NR|
|524|Nepal|143|NPL|Nepal|Nepalese|nepal|Nepal|Nepalese|NP|
|528|Netherlands|144|NLD|Netherlands|Dutch|netherlands|Netherlands|Dutch|NL|
|532|Netherlands Antilles|145|ANT|Netherlands Antilles|Dutch Antilles|netherlands-antilles|Netherlands Antilles|Dutch Antilles|AN|
|533|Aruba|11|ABW|Aruba|Aruban|aruba|Aruba|Aruban|AW|
|540|New Caledonia|146|NCL|New Caledonia|New Caledonian|new-caledonia|New Caledonia|New Caledonian|NC|
|548|Vanuatu|226|VUT|Vanuatu|Vanuatuan|vanuatu|Vanuatu|Vanuatuan|VU|
|554|New Zealand|147|NZL|New Zealand|New Zealand |new-zealand|New Zealand|New Zealand |NZ|
|558|Nicaragua|148|NIC|Nicaragua|Nicaraguan|nicaragua|Nicaragua|Nicaraguan|NI|
|562|Niger|149|NER|Niger|Nigerien|niger|Niger|Nigerien|NE|
|566|Nigeria|150|NGA|Nigeria|Nigerian|nigeria|Nigeria|Nigerian|NG|
|570|Niue|151|NIU|Niue|Niuean|niue|Niue|Niuean|NU|
|574|Norfolk Island|152|NFK|Norfolk Island|Norfolk Island |norfolk-island|Norfolk Island|Norfolk Island |NF|
|578|Norway|154|NOR|Norway|Norwegian|norway|Norway|Norwegian|NO|
|580|Northern Mariana Islands|153|MNP|Northern Mariana Islands|Northern Mariana Islands |northern-mariana-islands|Northern Mariana Islands|Northern Mariana Islands |MP|
|583|Micronesia|133|FSM|Micronesia|Micronesian|micronesia|Micronesia|Micronesian|FM|
|584|Marshall Islands|127|MHL|Marshall Islands|Marshallese|marshall-islands|Marshall Islands|Marshallese|MH|
|585|Palau|157|PLW|Palau|Palauan|palau|Palau|Palauan|PW|
|586|Pakistan|156|PAK|Pakistan|Pakistani|pakistan|Pakistan|Pakistani|PK|
|591|Panama|159|PAN|Panama|Panamanian|panama|Panama|Panamanian|PA|
|598|Papua New Guinea|160|PNG|Papua New Guinea|Papuan|papua-new-guinea|Papua New Guinea|Papuan|PG|
|600|Paraguay|161|PRY|Paraguay|Paraguayan|paraguay|Paraguay|Paraguayan|PY|
|604|Peru|162|PER|Peru|Peruvian|peru|Peru|Peruvian|PE|
|608|Philippines|163|PHL|Philippines|Filipino|philippines|Philippines|Filipino|PH|
|612|Pitcairn|164|PCN|Pitcairn|Pitcairn |pitcairn|Pitcairn|Pitcairn |PN|
|616|Poland|165|POL|Poland|Polish|poland|Poland|Polish|PL|
|620|Portugal|166|PRT|Portugal|Portuguese|portugal|Portugal|Portuguese|PT|
|624|Guinea-Bissau|87|GNB|Guinea-Bissau|Bissau-Guinean|guinea-bissau|Guinea-Bissau|Bissau-Guinean|GW|
|626|Timor-Leste|207|TLS|Timor-Leste|Timorese|timor-leste|Timor-Leste|Timorese|TL|
|630|Puerto Rico|167|PRI|Puerto Rico|Puerto Rican|puerto-rico|Puerto Rico|Puerto Rican|PR|
|634|Qatar|168|QAT|Qatar|Qatari|qatar|Qatar|Qatari|QA|
|638|Réunion|171|REU|Réunion|Réunionese|reunion|Réunion|Réunionese|RE|
|642|Romania|172|ROU|Romania|Romanian|romania|Romania|Romanian|RO|
|643|Russia|173|RUS|Russia|Russian|russia|Russia|Russian|RU|
|646|Rwanda|174|RWA|Rwanda|Rwandan|rwanda|Rwanda|Rwandan|RW|
|652|Saint-Barthélemy|180|BLM|Saint-Barthélemy|Barthélemois|saint-barthelemy|Saint-Barthélemy|Barthélemois|BL|
|654|Saint Helena|175|SHN|Saint Helena|Saint Helenian|saint-helena|Saint Helena|Saint Helenian|SH|
|659|Saint Kitts & Nevis|176|KNA|Saint Kitts & Nevis|Kittitian|saint-kitts-nevis|Saint Kitts & Nevis|Kittitian|KN|
|660|Anguilla|7|AIA|Anguilla|Anguillan|anguilla|Anguilla|Anguillan|AI|
|662|Saint Lucia|177|LCA|Saint Lucia|Saint Lucian|saint-lucia|Saint Lucia|Saint Lucian|LC|
|663|Saint-Martin|181|MAF|Saint-Martin|Saint-Martinoise|saint-martin|Saint-Martin|Saint-Martinoise|MF|
|666|Saint Pierre & Miquelon|178|SPM|Saint Pierre & Miquelon|Saint-Pierrais|saint-pierre-miquelon|Saint Pierre & Miquelon|Saint-Pierrais|PM|
|670|Saint Vincent & the Grenadines|179|VCT|Saint Vincent & the Grenadines|Saint Vincentian|saint-vincent-the-grenadines|Saint Vincent & the Grenadines|Saint Vincentian|VC|
|674|San Marino|183|SMR|San Marino|Sammarinese|san-marino|San Marino|Sammarinese|SM|
|678|Sao Tome & Principe|184|STP|Sao Tome & Principe|São Toméan|sao-tome-principe|Sao Tome & Principe|São Toméan|ST|
|682|Saudi Arabia|185|SAU|Saudi Arabia|Saudi|saudi-arabia|Saudi Arabia|Saudi|SA|
|686|Senegal|186|SEN|Senegal|Senegalese|senegal|Senegal|Senegalese|SN|
|688|Serbia|187|SRB|Serbia|Serbian|serbia|Serbia|Serbian|RS|
|690|Seychelles|188|SYC|Seychelles|Seychellois|seychelles|Seychelles|Seychellois|SC|
|694|Sierra Leone|189|SLE|Sierra Leone|Sierra Leonean|sierra-leone|Sierra Leone|Sierra Leonean|SL|
|699|India|95|IND|India|Indian|india|India|Indian|IN|
|702|Singapore|190|SGP|Singapore|Singaporean|singapore|Singapore|Singaporean|SG|
|703|Slovakia|191|SVK|Slovakia|Slovak|slovakia|Slovakia|Slovak|SK|
|704|Vietnam|228|VNM|Vietnam|Vietnamese|vietnam|Vietnam|Vietnamese|VN|
|705|Slovenia|192|SVN|Slovenia|Slovenian|slovenia|Slovenia|Slovenian|SI|
|706|Somalia|194|SOM|Somalia|Somali|somalia|Somalia|Somali|SO|
|710|South Africa|195|ZAF|South Africa|South African|south-africa|South Africa|South African|ZA|
|716|Zimbabwe|233|ZWE|Zimbabwe|Zimbabwean|zimbabwe|Zimbabwe|Zimbabwean|ZW|
|724|Spain|196|ESP|Spain|Spanish|spain|Spain|Spanish|ES|
|728|South Sudan|251|SSD|South Sudan|South Sudanese|south-sudan|South Sudan|South Sudanese|SS|
|729|Republic of the Sudan|198|SDN|Republic of the Sudan|Sudanese|republic-of-the-sudan|Republic of the Sudan|Sudanese|SD|
|732|Western Sahara|230|ESH|Western Sahara|Sahrawi|western-sahara|Western Sahara|Sahrawi|EH|
|740|Suriname|199|SUR|Suriname|Surinamese|suriname|Suriname|Surinamese|SR|
|744|Svalbard & Jan Mayen Islands|200|SJM|Svalbard & Jan Mayen Islands|Svalbard|svalbard-jan-mayen-islands|Svalbard & Jan Mayen Islands|Svalbard|SJ|
|748|Eswatini|201|SWZ|Eswatini|Eswatinian|eswatini|Eswatini|Eswatinian|SZ|
|752|Sweden|202|SWE|Sweden|Swedish|sweden|Sweden|Swedish|SE|
|756|Switzerland|203|CHE|Switzerland|Swiss|switzerland|Switzerland|Swiss|CH|
|760|Syria|204|SYR|Syria|Syrian|syria|Syria|Syrian|SY|
|762|Tajikistan|205|TJK|Tajikistan|Tajikistani|tajikistan|Tajikistan|Tajikistani|TJ|
|764|Thailand|206|THA|Thailand|Thai|thailand|Thailand|Thai|TH|
|768|Togo|208|TGO|Togo|Togolese|togo|Togo|Togolese|TG|
|772|Tokelau|209|TKL|Tokelau|Tokelauan|tokelau|Tokelau|Tokelauan|TK|
|776|Tonga|210|TON|Tonga|Tongan|tonga|Tonga|Tongan|TO|
|780|Trinidad & Tobago|211|TTO|Trinidad & Tobago|Trinidadian|trinidad-tobago|Trinidad & Tobago|Trinidadian|TT|
|784|United Arab Emirates|219|ARE|United Arab Emirates|Emirati|united-arab-emirates|United Arab Emirates|Emirati|AE|
|788|Tunisia|212|TUN|Tunisia|Tunisian|tunisia|Tunisia|Tunisian|TN|
|792|Turkiye|213|TUR|Turkiye|Turkish|turkiye|Turkiye|Turkish|TR|
|795|Turkmenistan|214|TKM|Turkmenistan|Turkmen|turkmenistan|Turkmenistan|Turkmen|TM|
|796|Turks & Caicos Islands|215|TCA|Turks & Caicos Islands|Turks & Caicos Islands |turks-caicos-islands|Turks & Caicos Islands|Turks & Caicos Islands |TC|
|798|Tuvalu|216|TUV|Tuvalu|Tuvaluan|tuvalu|Tuvalu|Tuvaluan|TV|
|800|Uganda|217|UGA|Uganda|Ugandan|uganda|Uganda|Ugandan|UG|
|804|Ukraine|218|UKR|Ukraine|Ukrainian|ukraine|Ukraine|Ukrainian|UA|
|807|Macedonia|120|MKD|Macedonia|Macedonian|macedonia|Macedonia|Macedonian|MK|
|818|Egypt|61|EGY|Egypt|Egyptian|egypt|Egypt|Egyptian|EG|
|826|United Kingdom|220|GBR|United Kingdom|British|united-kingdom|United Kingdom|British|GB|
|834|Tanzania|221|TZA|Tanzania|Tanzanian|tanzania|Tanzania|Tanzanian|TZ|
|840|United States of America|222|USA|United States|American|united-states-of-america|United States|American|US|
|850|US Virgin Islands|223|VIR|US Virgin Islands|US Virgin Island|us-virgin-islands|US Virgin Islands|US Virgin Island|VI|
|854|Burkina Faso|32|BFA|Burkina Faso|Burkinabé|burkina-faso|Burkina Faso|Burkinabé|BF|
|858|Uruguay|224|URY|Uruguay|Uruguayan|uruguay|Uruguay|Uruguayan|UY|
|860|Uzbekistan|225|UZB|Uzbekistan|Uzbekistani|uzbekistan|Uzbekistan|Uzbekistani|UZ|
|862|Venezuela|227|VEN|Venezuela|Venezuelan|venezuela|Venezuela|Venezuelan|VE|
|876|Wallis & Futuna Islands|229|WLF|Wallis & Futuna Islands|Wallis & Futuna|wallis-futuna-islands|Wallis & Futuna Islands|Wallis & Futuna|WF|
|882|Samoa|182|WSM|Samoa|Samoan|samoa|Samoa|Samoan|WS|
|887|Yemen|231|YEM|Yemen|Yemeni|yemen|Yemen|Yemeni|YE|
|894|Zambia|232|ZMB|Zambia|Zambian|zambia|Zambia|Zambian|ZM|
|999|Republic of Kosovo|252|XXK|Kosovo|Kosovan|republic-of-kosovo|Kosovo|Kosovan|XK|
