"""Reputation API methods.

Fetches reputation scores from the Mnemom API and extracts
A2A trust extensions for inter-agent reputation sharing.
"""

from __future__ import annotations

from urllib.parse import quote

import httpx

from mnemom_types import A2ATrustExtension, ReputationComponent, ReputationScore

DEFAULT_BASE_URL = "https://api.mnemom.ai"


def _parse_reputation_score(data: dict) -> ReputationScore:
    """Parse API response dict into a ReputationScore model.

    Args:
        data: Raw JSON response from the reputation API.

    Returns:
        Parsed ReputationScore instance.
    """
    components = [ReputationComponent(**c) for c in data.get("components", [])]
    ext_data = data.get("a2a_trust_extension")
    extension = A2ATrustExtension(**ext_data) if ext_data else None

    return ReputationScore(
        agent_id=data["agent_id"],
        score=data["score"],
        grade=data["grade"],
        tier=data["tier"],
        is_eligible=data["is_eligible"],
        checkpoint_count=data["checkpoint_count"],
        confidence=data["confidence"],
        components=components,
        computed_at=data["computed_at"],
        trend_30d=data["trend_30d"],
        visibility=data["visibility"],
        a2a_trust_extension=extension,
    )


def get_reputation(
    agent_id: str,
    *,
    base_url: str = DEFAULT_BASE_URL,
) -> ReputationScore:
    """Fetch the reputation score for an agent.

    Args:
        agent_id: Agent identifier.
        base_url: Override the default API base URL.

    Returns:
        The agent's reputation score.

    Raises:
        PermissionError: If the score is private (HTTP 403).
        LookupError: If the score is not found (HTTP 404).
        httpx.HTTPStatusError: For other non-2xx responses.
    """
    url = f"{base_url}/v1/reputation/{quote(agent_id, safe='')}"
    response = httpx.get(url)

    if response.status_code == 403:
        raise PermissionError("Reputation score is private")
    if response.status_code == 404:
        raise LookupError("Reputation score not found")

    response.raise_for_status()
    return _parse_reputation_score(response.json())


def get_my_reputation(
    *,
    agent_id: str,
    base_url: str = DEFAULT_BASE_URL,
) -> ReputationScore:
    """Fetch the reputation score for your own agent.

    Convenience wrapper around get_reputation that requires an agent_id.

    Args:
        agent_id: Your agent identifier (required).
        base_url: Override the default API base URL.

    Returns:
        The agent's reputation score.

    Raises:
        ValueError: If agent_id is empty.
    """
    if not agent_id:
        raise ValueError("agent_id is required")
    return get_reputation(agent_id, base_url=base_url)


def get_a2a_reputation_extension(
    agent_id: str,
    *,
    base_url: str = DEFAULT_BASE_URL,
) -> A2ATrustExtension:
    """Extract the A2A trust extension from an agent's reputation score.

    Args:
        agent_id: Agent identifier.
        base_url: Override the default API base URL.

    Returns:
        The A2A trust extension.

    Raises:
        ValueError: If the extension is not available.
    """
    score = get_reputation(agent_id, base_url=base_url)
    if not score.a2a_trust_extension:
        raise ValueError("A2A trust extension not available")
    return score.a2a_trust_extension
