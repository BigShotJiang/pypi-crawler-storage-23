"""Reputation gate for access control based on agent reputation.

Provides a simple mechanism to gate agent interactions based on
minimum reputation score or grade thresholds.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field

from mnemom_types import GRADE_ORDINALS, ReputationGateConfig, ReputationScore

from .api import get_reputation


class GateResult(BaseModel):
    """Result of a reputation gate check."""

    allowed: bool = Field(..., description="Whether the agent passed the gate")
    score: Optional[ReputationScore] = Field(
        None, description="The agent's reputation score (None on fetch error)"
    )
    reason: Optional[str] = Field(
        None, description="Reason for denial (None if allowed)"
    )


class ReputationGate:
    """Gate that checks agent reputation before allowing interaction.

    Example::

        from mnemom_types import ReputationGateConfig
        gate = ReputationGate(ReputationGateConfig(min_score=60, min_grade="BBB"))
        result = gate.check("agent-123")
        if result.allowed:
            # proceed with interaction
            pass
        else:
            print(f"Denied: {result.reason}")
    """

    def __init__(self, config: ReputationGateConfig) -> None:
        self.config = config

    def check(self, agent_id: str) -> GateResult:
        """Check whether an agent meets the reputation requirements.

        Args:
            agent_id: Agent identifier to check.

        Returns:
            GateResult indicating whether the agent is allowed and why.
        """
        try:
            score = get_reputation(agent_id, base_url=self.config.base_url)
        except Exception as e:
            return GateResult(allowed=False, score=None, reason=str(e))

        if self.config.min_score is not None and score.score < self.config.min_score:
            return GateResult(
                allowed=False,
                score=score,
                reason=f"Score {score.score} is below minimum {self.config.min_score}",
            )

        if self.config.min_grade is not None:
            required = GRADE_ORDINALS.get(self.config.min_grade, 0)
            actual = GRADE_ORDINALS.get(score.grade, 0)
            if actual < required:
                return GateResult(
                    allowed=False,
                    score=score,
                    reason=f"Grade {score.grade} is below minimum {self.config.min_grade}",
                )

        return GateResult(allowed=True, score=score)
