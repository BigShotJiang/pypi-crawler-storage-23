"""mnemom-reputation — Client SDK for Mnemom reputation scores.

Example::

    from mnemom_reputation import get_reputation, ReputationGate

    score = get_reputation("agent-123")
    print(score.grade, score.score)

    from mnemom_types import ReputationGateConfig
    gate = ReputationGate(ReputationGateConfig(min_score=600, min_grade="BBB"))
    result = gate.check("agent-456")
"""

from mnemom_reputation.api import (
    get_a2a_reputation_extension,
    get_my_reputation,
    get_reputation,
)
from mnemom_reputation.gate import GateResult, ReputationGate

__all__ = [
    "get_reputation",
    "get_my_reputation",
    "get_a2a_reputation_extension",
    "GateResult",
    "ReputationGate",
]
