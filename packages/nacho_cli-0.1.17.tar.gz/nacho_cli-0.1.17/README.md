# Nacho CLI

Push, pull, and search context files on [nacho.bot](https://nacho.bot). Also sets up the Nacho builder.

## Installation

```bash
pip install nacho-cli
```

## Usage

```bash
# Set up AI integration and launch the builder wizard
nacho init

# Log in
nacho login
nacho token <your-api-token>

# Push a context file
nacho push my-context.md --name my-context --title "My Context"

# Pull a context file
nacho pull username/context-name

# Search
nacho search "python testing"
```

## Links

- [nacho.bot](https://nacho.bot)
- [Documentation](https://nacho.bot/docs)
