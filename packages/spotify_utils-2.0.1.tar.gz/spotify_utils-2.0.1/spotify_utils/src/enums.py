from enum import Enum


class OutputFormat(Enum):
    HTML = "html"
    JSON = "json"


class OutputFormatJson(Enum):
    JSON = "json"
