# geotemp-travel

Python client library for the GeoTemp MCP travel intelligence tools.

## Install

```bash
pip install geotemp-travel
```

## Quick example

```python
from geotemp_client import GeoTempClient

client = GeoTempClient(mode="local")
print(client.get_dataset_stats())
```

For full setup and advanced usage, see `QUICKSTART.md`.
