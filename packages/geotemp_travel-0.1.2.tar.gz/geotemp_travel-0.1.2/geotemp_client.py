"""
GeoTemp Travel MCP — Python Client
===================================
Simple Python client for the GeoTemp MCP Server

Installation:
    pip install requests

Usage (Hosted Server):
    from geotemp_client import GeoTempClient

    client = GeoTempClient(api_key="your_api_key_here")

    # Find warm beach cities in Europe
    results = client.search_destinations(
        continent="Europe",
        is_coastal=True,
        max_daily_budget_usd=80,
        min_safety_score=4
    )

    # Plan a trip
    trip = client.plan_trip(
        month=8,
        activities=["swimming", "nightlife", "food_tourism"],
        max_budget_usd=100,
        continent="Europe"
    )

Usage (Local MCP Server):
    client = GeoTempClient(mode="local")
"""

import requests
from typing import Optional, List, Dict, Any, Literal

__version__ = "0.1.0"
__all__ = ["GeoTempClient", "__version__"]


class GeoTempClient:
    """
    Python client for GeoTemp Travel MCP Server.

    Supports both hosted (via API key) and local (via MCP protocol) modes.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "http://127.0.0.1:8000/api",
        mode: Literal["hosted", "local", "auto"] = "auto",
        timeout_seconds: int = 30,
        max_retries: int = 2,
    ):
        """
        Initialize the GeoTemp client.

        Args:
            api_key: API key for hosted mode (required if mode="hosted")
            base_url: Base URL of the hosted server
            mode: "hosted" for cloud API, "local" for MCP server, "auto" to infer from api_key
        """
        self.mode = "hosted" if (mode == "auto" and api_key) else ("local" if mode == "auto" else mode)
        self.base_url = base_url
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries

        if self.mode == "hosted" and not api_key:
            raise ValueError("API key required for hosted mode.")

    def _call_tool(self, tool_name: str, **kwargs) -> Dict[str, Any]:
        """
        Internal method to call an MCP tool.

        Args:
            tool_name: Name of the tool to call
            **kwargs: Tool parameters

        Returns:
            Tool response as dict
        """
        if self.mode == "hosted":
            raw = self._call_hosted(tool_name, kwargs)
        else:
            raw = self._call_local(tool_name, kwargs)
        return self._normalize_response(tool_name, raw)

    def _call_hosted(self, tool_name: str, params: Dict) -> Dict:
        """Call the hosted API."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        last_exc: Exception | None = None
        for _ in range(self.max_retries + 1):
            try:
                response = requests.post(
                    f"{self.base_url}/tools/{tool_name}",
                    json=params,
                    headers=headers,
                    timeout=self.timeout_seconds,
                )
                response.raise_for_status()
                return response.json()
            except Exception as exc:
                last_exc = exc
        raise RuntimeError(f"Hosted call failed for tool '{tool_name}': {last_exc}")

    def _call_local(self, tool_name: str, params: Dict) -> Dict:
        """Call the local MCP server."""
        import asyncio
        from mcp_server import server as mcp_srv

        # Important: geotemp-use examples call tools many times from sync code.
        # The server module keeps a module-level AsyncClient which is bound to
        # the event loop that created it; each asyncio.run() creates/closes a loop.
        # Resetting avoids "Event loop is closed" on subsequent calls.
        mcp_srv._client = None
        _dispatch = mcp_srv._dispatch

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, _dispatch(tool_name, params)).result()
        return asyncio.run(_dispatch(tool_name, params))

    def _normalize_response(self, tool_name: str, raw: Any) -> Dict[str, Any]:
        """Normalize small response-shape differences across server versions."""
        if not isinstance(raw, dict):
            return {"result": raw}

        out = dict(raw)

        if tool_name == "search_destinations":
            if "destinations" not in out and "cities" in out:
                out["destinations"] = out.get("cities", [])

        if tool_name == "compare_cities":
            if "comparisons" not in out and "cities" in out:
                out["comparisons"] = out.get("cities", [])

        if tool_name == "find_best_month":
            if "rankings" not in out and "ranking" in out and isinstance(out["ranking"], list):
                out["rankings"] = []
                for row in out["ranking"]:
                    if not isinstance(row, dict):
                        continue
                    out["rankings"].append({
                        "month": row.get("month_num", row.get("month")),
                        "month_name": row.get("month"),
                        "score": row.get("score"),
                        "avg_temp": row.get("avg_temp_c"),
                        "total_precip_mm": row.get("total_rain_mm"),
                        "avg_sunshine_hours": row.get("avg_sunshine_hours"),
                        "avg_humidity_pct": row.get("avg_humidity_pct"),
                    })
            if "rankings" in out and isinstance(out["rankings"], list):
                for row in out["rankings"]:
                    if isinstance(row, dict):
                        if "avg_temp" not in row and "weather" in row and isinstance(row["weather"], dict):
                            row["avg_temp"] = row["weather"].get("avg_temp")

        if tool_name in {"plan_trip", "compare_cities", "get_seasonal_calendar"}:
            def _normalize_weather(weather: dict[str, Any] | None) -> dict[str, Any]:
                w = dict(weather or {})
                if "avg_temp" not in w:
                    w["avg_temp"] = w.get("avg_temp_c", w.get("temperature_mean"))
                if "precipitation" not in w:
                    w["precipitation"] = w.get("precipitation_mm", w.get("total_precip_mm", w.get("avg_precip_mm", 0)))
                if "sunshine" not in w:
                    w["sunshine"] = w.get("sunshine_hrs", w.get("avg_sunshine_hrs", w.get("sunshine_hours", 0)))
                if "humidity_mean" not in w:
                    w["humidity_mean"] = w.get("avg_humidity_pct", w.get("avg_humidity", 0))
                return w

            if "destinations" in out and isinstance(out["destinations"], list):
                for d in out["destinations"]:
                    if isinstance(d, dict) and "weather" in d:
                        d["weather"] = _normalize_weather(d.get("weather"))
            if "comparisons" in out and isinstance(out["comparisons"], list):
                for d in out["comparisons"]:
                    if not isinstance(d, dict):
                        continue
                    if "weather" not in d:
                        month_weather_key = next((k for k in d.keys() if isinstance(k, str) and k.startswith("weather_")), None)
                        if month_weather_key and isinstance(d.get(month_weather_key), dict):
                            mw = d.get(month_weather_key, {})
                            d["weather"] = {
                                "avg_temp": mw.get("avg_temperature_mean"),
                                "precipitation": mw.get("total_precipitation_mm"),
                                "sunshine": mw.get("avg_sunshine_hours"),
                                "humidity_mean": mw.get("avg_humidity_mean"),
                            }
                    if "weather" in d:
                        d["weather"] = _normalize_weather(d.get("weather"))
            if "calendar" in out and isinstance(out["calendar"], list):
                for d in out["calendar"]:
                    if isinstance(d, dict) and "weather" in d:
                        d["weather"] = _normalize_weather(d.get("weather"))

        return out

    # ═══════════════════════════════════════════════════════════════
    # Discovery & Search Tools
    # ═══════════════════════════════════════════════════════════════

    def search_destinations(
        self,
        continent: Optional[str] = None,
        country: Optional[str] = None,
        is_coastal: Optional[bool] = None,
        min_safety_score: Optional[int] = None,
        max_daily_budget_usd: Optional[int] = None,
        min_population: Optional[int] = None,
        climate_zone: Optional[str] = None,
        limit: int = 20
    ) -> Dict:
        """
        Search 384 destinations by criteria.

        Args:
            continent: Africa, Asia, Europe, North America, South America, Oceania, Middle East
            country: Country name (case-insensitive)
            is_coastal: True=coastal, False=inland
            min_safety_score: Min safety (1-5, where 5 is safest)
            max_daily_budget_usd: Max daily budget in USD
            min_population: Min city population
            climate_zone: Köppen code (e.g., Cfa, BWh)
            limit: Max results (default 20, max 50)

        Returns:
            {"destinations": [...], "count": N}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("search_destinations", **params)

    def search_by_activity(
        self,
        activity: str,
        month: Optional[int] = None,
        min_score: int = 60,
        continent: Optional[str] = None,
        limit: int = 15
    ) -> Dict:
        """
        Find cities offering a specific activity.

        Args:
            activity: One of 29 activities (e.g., "swimming", "skiing", "nightlife")
            month: Month (1-12) to check scores for
            min_score: Min score threshold (0-100, default 60)
            continent: Continent filter
            limit: Max results

        Returns:
            {"activity": str, "destinations": [...], "count": N}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("search_by_activity", **params)

    def multi_activity_search(
        self,
        activities: List[str],
        month: Optional[int] = None,
        min_score: int = 40,
        continent: Optional[str] = None,
        limit: int = 15
    ) -> Dict:
        """
        Find cities offering MULTIPLE activities at once (AND logic).

        Args:
            activities: 2-6 activity names (cities must have ALL)
            month: Month to check scores (1-12)
            min_score: Min score per activity
            continent: Continent filter
            limit: Max results

        Returns:
            {"activities_required": [...], "destinations": [...]}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("multi_activity_search", **params)

    def find_nearby_destinations(
        self,
        city_name: Optional[str] = None,
        latitude: Optional[float] = None,
        longitude: Optional[float] = None,
        radius_km: int = 500,
        limit: int = 15
    ) -> Dict:
        """
        Find destinations within a radius using spatial search.

        Args:
            city_name: Reference city name (provides coordinates)
            latitude: Decimal degrees (alternative to city_name)
            longitude: Decimal degrees (alternative to city_name)
            radius_km: Search radius in km (default 500)
            limit: Max results

        Returns:
            {"reference": {...}, "nearby_destinations": [...]}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("find_nearby_destinations", **params)

    def find_similar_cities(
        self,
        city_name: str,
        limit: int = 10
    ) -> Dict:
        """
        Find cities similar to a reference city.

        Args:
            city_name: Reference city (e.g., "Barcelona")
            limit: Max results

        Returns:
            {"reference_city": str, "similar_destinations": [...]}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("find_similar_cities", **params)

    # ═══════════════════════════════════════════════════════════════
    # Trip Planning
    # ═══════════════════════════════════════════════════════════════

    def plan_trip(
        self,
        month: int,
        activities: Optional[List[str]] = None,
        max_budget_usd: Optional[int] = None,
        continent: Optional[str] = None,
        min_safety: Optional[int] = None,
        is_coastal: Optional[bool] = None,
        limit: int = 15
    ) -> Dict:
        """
        THE primary "Where should I go?" tool.

        Args:
            month: Travel month (1=January, 12=December)
            activities: Desired activities (cities must have ALL)
            max_budget_usd: Max daily budget
            continent: Continent filter
            min_safety: Min safety score (1-5)
            is_coastal: True=coastal only, False=inland only
            limit: Max results

        Returns:
            {"destinations": [...], "count": N}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("plan_trip", **params)

    # ═══════════════════════════════════════════════════════════════
    # City Intelligence
    # ═══════════════════════════════════════════════════════════════

    def get_city_profile(
        self,
        city_name: Optional[str] = None,
        city_id: Optional[str] = None
    ) -> Dict:
        """
        Get comprehensive city profile.

        Args:
            city_name: City name
            city_id: City UUID (alternative)

        Returns:
            {"city": {...}}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("get_city_profile", **params)

    def get_weather(
        self,
        city_name: str,
        month: Optional[int] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> Dict:
        """
        Get weather data for a city.

        Args:
            city_name: City name
            month: Month (1-12) for averages
            start_date: YYYY-MM-DD (use with end_date for daily range)
            end_date: YYYY-MM-DD

        Returns:
            {"city": str, "weather": [...]}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("get_weather", **params)

    def get_attractions(
        self,
        city_name: str,
        category: Optional[str] = None,
        limit: int = 20
    ) -> Dict:
        """
        Get tourist attractions for a city.

        Args:
            city_name: City name
            category: Filter (museum, monument, castle, viewpoint, etc.)
            limit: Max results

        Returns:
            {"city": str, "attractions": [...], "count": N}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("get_attractions", **params)

    def get_seasonal_calendar(self, city_name: str) -> Dict:
        """
        Get 12-month calendar with weather + top activities.

        Args:
            city_name: City name

        Returns:
            {"city": str, "calendar": [{month: 1, weather: {...}, top_activities: [...]}]}
        """
        return self._call_tool("get_seasonal_calendar", city_name=city_name)

    def find_best_month(
        self,
        city_name: str,
        prefer_warm: bool = True,
        max_rain_mm: Optional[float] = None,
        min_sunshine_hours: Optional[float] = None
    ) -> Dict:
        """
        Rank months by weather suitability.

        Args:
            city_name: City name
            prefer_warm: True=warmer is better
            max_rain_mm: Penalize months above this
            min_sunshine_hours: Penalize months below this

        Returns:
            {"city": str, "rankings": [...]}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("find_best_month", **params)

    def compare_cities(
        self,
        city_names: List[str],
        month: Optional[int] = None
    ) -> Dict:
        """
        Compare 2-5 cities side by side.

        Args:
            city_names: 2-5 city names
            month: Month to compare (1-12)

        Returns:
            {"month": int, "comparisons": [...]}
        """
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("compare_cities", **params)

    # ═══════════════════════════════════════════════════════════════
    # Meta
    # ═══════════════════════════════════════════════════════════════

    def get_dataset_stats(self) -> Dict:
        """
        Get overview of the entire dataset.

        Returns:
            {"cities": N, "countries": N, "continents": {...}, ...}
        """
        return self._call_tool("get_dataset_stats")

    # ═══════════════════════════════════════════════════════════════
    # Advanced intelligence tools (v2)
    # ═══════════════════════════════════════════════════════════════

    def get_weather_predictions(self, city_name: str, year: Optional[int] = None, month: Optional[int] = None, limit: int = 12) -> Dict:
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("get_weather_predictions", **params)

    def get_climate_normals(self, city: str) -> Dict:
        return self._call_tool("get_climate_normals", city=city)

    def get_climate_risk(self, city_name: str, month: int) -> Dict:
        return self._call_tool("get_climate_risk", city_name=city_name, month=month)

    def get_air_quality(self, city: str) -> Dict:
        return self._call_tool("get_air_quality", city=city)

    def get_golden_hours(self, city: str) -> Dict:
        return self._call_tool("get_golden_hours", city=city)

    def get_terrain(self, city: str) -> Dict:
        return self._call_tool("get_terrain", city=city)

    def get_crowd_calendar(self, city: str) -> Dict:
        return self._call_tool("get_crowd_calendar", city=city)

    def get_water_bodies(self, city: str, water_type: Optional[str] = None) -> Dict:
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("get_water_bodies", **params)

    def search_by_phenomenon(self, phenomenon: str, month: Optional[int] = None, limit: int = 15) -> Dict:
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("search_by_phenomenon", **params)

    def get_travel_intelligence(self, city: str, month: int) -> Dict:
        return self._call_tool("get_travel_intelligence", city=city, month=month)

    def rank_destinations_smart(
        self,
        month: int,
        continent: Optional[str] = None,
        max_crowd: int = 70,
        max_aqi: int = 100,
        terrain: Optional[str] = None,
        activities: Optional[List[str]] = None,
        limit: int = 20,
    ) -> Dict:
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("rank_destinations_smart", **params)

    def get_translations(
        self,
        lang: str,
        entity_type: Optional[str] = None,
        city_name: Optional[str] = None,
        entity_ids: Optional[List[str]] = None,
        limit: int = 50,
    ) -> Dict:
        """Get multilingual translations for cities, attractions, or activities."""
        params = {k: v for k, v in locals().items() if k != 'self' and v is not None}
        return self._call_tool("get_translations", **params)


# ═══════════════════════════════════════════════════════════════
# Convenience Functions
# ═══════════════════════════════════════════════════════════════

def quick_search(query: str, api_key: Optional[str] = None) -> Dict:
    """
    Natural language search (requires OpenAI).

    Args:
        query: "Find warm beach cities in Europe under $80/day"
        api_key: GeoTemp API key (for hosted mode)

    Returns:
        Search results
    """
    # This would use an LLM to parse the query and call the appropriate tools
    # For simplicity, this is a placeholder
    raise NotImplementedError("Use client.search_destinations() with explicit parameters")
