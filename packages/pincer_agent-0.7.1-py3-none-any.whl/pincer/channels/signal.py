"""Signal channel."""
