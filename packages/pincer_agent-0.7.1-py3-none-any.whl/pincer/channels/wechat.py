"""WeChat channel."""
