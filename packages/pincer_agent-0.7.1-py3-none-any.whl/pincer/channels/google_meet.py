"""Google Meet channel."""
