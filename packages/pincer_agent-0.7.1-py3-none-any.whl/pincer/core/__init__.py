"""Core agent components."""
