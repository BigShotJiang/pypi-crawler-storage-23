"""Ollama provider."""
