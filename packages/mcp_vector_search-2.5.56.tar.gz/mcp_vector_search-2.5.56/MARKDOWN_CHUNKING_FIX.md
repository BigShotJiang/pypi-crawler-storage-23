# Markdown Chunking Fix

## Problem
Markdown files (.md) were discovered during file scanning but NOT parsed into chunks during indexing. The KG builder reported 0 markdown chunks, preventing tags extraction from working.

## Root Cause
In `src/mcp_vector_search/parsers/text.py`, line 353 had an incorrect calculation:

```python
chunk_size = TEXT_CHUNK_SIZE // 80  # Approximate lines per chunk
```

With `TEXT_CHUNK_SIZE = 30` (defined in `constants.py` as "Number of lines per text/markdown chunk"), the integer division `30 // 80 = 0` resulted in `chunk_size = 0`.

This caused the chunking loop to fail:
```python
for i in range(0, len(lines), chunk_size):  # range(0, len(lines), 0) - infinite loop or no iteration
```

## The Fix
Changed line 353 to use `TEXT_CHUNK_SIZE` directly:

```python
chunk_size = TEXT_CHUNK_SIZE  # Use TEXT_CHUNK_SIZE as lines per chunk
```

This matches the behavior in the async `parse_content` method (line 126), which correctly uses `TEXT_CHUNK_SIZE` as the chunk size in lines.

## Verification

### Test Case 1: Markdown with Frontmatter
```python
from pathlib import Path
from mcp_vector_search.parsers.text import TextParser

parser = TextParser()
chunks = parser.parse_file_sync(Path('/tmp/test.md'))

# Before fix: 0 chunks
# After fix: 1+ chunks with:
#   - chunk_type="text"
#   - language="text"
#   - tags=["test-tag", "another-tag"]
```

### Test Case 2: Repository README.md
```bash
# Before fix: 0 chunks
# After fix: 208 chunks
```

### Test Case 3: KG Builder Integration
```python
# Chunks now pass the KG builder filter:
c.language == "text" or str(c.file_path).endswith(".md")
# ✓ True (because language="text")
```

## Impact
- ✅ Markdown files now produce chunks during indexing
- ✅ Frontmatter tags are extracted and stored on chunks
- ✅ KG builder can process markdown chunks
- ✅ Tags extraction from markdown works end-to-end

## Files Changed
- `src/mcp_vector_search/parsers/text.py` (1 line)

## Testing
Run the test script to verify:
```bash
uv run python -c "
from pathlib import Path
from mcp_vector_search.parsers.text import TextParser

# Create test file
with open('/tmp/test-frontmatter.md', 'w') as f:
    f.write('''---
tags: [test-tag, another-tag]
---
# Test Document
Some content here.
''')

# Parse and verify
parser = TextParser()
chunks = parser.parse_file_sync(Path('/tmp/test-frontmatter.md'))

assert len(chunks) > 0, 'Should produce chunks'
assert chunks[0].language == 'text', 'Language should be text'
assert chunks[0].tags == ['test-tag', 'another-tag'], 'Tags should be extracted'

print('✓ All tests passed!')
"
```

## Related Issues
This fix resolves the issue where the KG builder reported "0 markdown chunks" during indexing, which prevented tags extraction from working on markdown documentation files.
