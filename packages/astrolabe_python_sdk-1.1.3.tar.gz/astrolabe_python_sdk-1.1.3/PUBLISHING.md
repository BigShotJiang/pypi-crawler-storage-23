# Publishing to PyPI

This guide explains how to publish the Astrolabe Python SDK to PyPI.

## Prerequisites

1. Install build tools:
```bash
pip install build twine
```

2. Create PyPI account at https://pypi.org/account/register/

3. Generate API token at https://pypi.org/manage/account/token/

## Build the Package

1. Clean previous builds:
```bash
rm -rf dist/ build/ *.egg-info/
```

2. Build the package:
```bash
python -m build
```

This creates both wheel (.whl) and source distribution (.tar.gz) in the `dist/` directory.

## Upload to PyPI

### Test on TestPyPI first (recommended)

1. Upload to TestPyPI:
```bash
python -m twine upload --repository testpypi dist/*
```

2. Test installation from TestPyPI:
```bash
pip install --index-url https://test.pypi.org/simple/ astrolabe-python-sdk
```

### Upload to Production PyPI

```bash
python -m twine upload dist/*
```

## Authentication

You'll be prompted for credentials. Use:
- Username: `__token__`
- Password: Your PyPI API token (starts with `pypi-`)

## Automated Publishing with GitHub Actions

Publishing is automated via GitHub Actions. When you create a release on GitHub, the workflow will build, test, and publish to PyPI automatically.

**Setup:** Add your PyPI API token as a GitHub secret named `PYPI_API_TOKEN`.

## Version Management

Versions are derived automatically from Git tags using `setuptools-scm`. No manual version edits are needed.

To release a new version:
1. Create a git tag: `git tag v1.2.0`
2. Push the tag: `git push origin v1.2.0`
3. Create a GitHub release from the tag
4. The workflow will automatically publish the package with the correct version

## Verification

After publishing, verify the package:
1. Check on PyPI: https://pypi.org/project/astrolabe-python-sdk/
2. Install and test: `pip install astrolabe-python-sdk`
3. Import and use: `from astrolabe import AstrolabeClient`
