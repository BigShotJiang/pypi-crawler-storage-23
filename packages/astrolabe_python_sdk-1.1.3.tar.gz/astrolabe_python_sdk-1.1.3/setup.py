"""
Setup configuration for Astrolabe Python SDK
This file is kept for backward compatibility, but pyproject.toml is the primary configuration.
"""

from setuptools import setup

# Configuration is now in pyproject.toml
setup()
