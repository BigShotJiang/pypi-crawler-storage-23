#!/usr/bin/env python3
"""
Test script to verify logging behavior with different configurations
"""

import os
import logging
from astrolabe import AstrolabeClient

def test_no_logging():
    """Test that no logging occurs by default"""
    print("=== Test 1: No logging (default behavior) ===")
    if 'ASTROLABE_DEBUG_LOGGING_ENABLED' in os.environ:
        del os.environ['ASTROLABE_DEBUG_LOGGING_ENABLED']
    
    client = AstrolabeClient("development")
    result = client.get_bool("test/flag", False)
    print(f"Flag result: {result}")
    print("Should see no Astrolabe log messages above\n")

def test_with_env_var():
    """Test that logging occurs when environment variable is set"""
    print("=== Test 2: Logging enabled via environment variable ===")
    os.environ['ASTROLABE_DEBUG_LOGGING_ENABLED'] = 'true'
    
    client = AstrolabeClient("development")
    result = client.get_bool("test/flag", False)
    print(f"Flag result: {result}")
    print("Should see Astrolabe log messages above\n")
    
    del os.environ['ASTROLABE_DEBUG_LOGGING_ENABLED']

def test_with_external_logger():
    """Test that logging occurs when external logger is provided"""
    print("=== Test 3: Logging with external logger ===")
    if 'ASTROLABE_DEBUG_LOGGING_ENABLED' in os.environ:
        del os.environ['ASTROLABE_DEBUG_LOGGING_ENABLED']
    
    external_logger = logging.getLogger("test_logger")
    external_logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('EXTERNAL: %(message)s'))
    external_logger.addHandler(handler)
    
    client = AstrolabeClient("development", logger=external_logger)
    result = client.get_bool("test/flag", False)
    print(f"Flag result: {result}")
    print("Should see EXTERNAL log messages above\n")

if __name__ == "__main__":
    test_no_logging()
    test_with_env_var()
    test_with_external_logger()
    print("All tests completed!")
