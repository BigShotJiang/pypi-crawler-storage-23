"""
Unit tests for astrolabe-python-sdk
"""
