"""
Test script to verify environment mapping functionality
"""

from astrolabe.client import normalize_environment, AstrolabeClient


def test_environment_mapping():
    """Test various environment input formats"""

    # Development environment mappings
    dev_inputs = [
        "dev",
        "Dev",
        "DEV",
        "develop",
        "Develop",
        "development",
        "Development",
        "DEVELOPMENT",
    ]
    for input_env in dev_inputs:
        result = normalize_environment(input_env)
        assert result == "development", f"Failed for input: {input_env}"
        print(f"✓ '{input_env}' -> '{result}'")

    # Staging environment mappings
    stg_inputs = [
        "stg",
        "Stg",
        "STG",
        "stag",
        "Stag",
        "STAG",
        "staging",
        "Staging",
        "STAGING",
    ]
    for input_env in stg_inputs:
        result = normalize_environment(input_env)
        assert result == "staging", f"Failed for input: {input_env}"
        print(f"✓ '{input_env}' -> '{result}'")

    # Production environment mappings
    prod_inputs = ["prod", "Prod", "PROD", "production", "Production", "PRODUCTION"]
    for input_env in prod_inputs:
        result = normalize_environment(input_env)
        assert result == "production", f"Failed for input: {input_env}"
        print(f"✓ '{input_env}' -> '{result}'")

    print("\n✓ All environment mapping tests passed!")


def test_client_initialization():
    """Test that AstrolabeClient accepts various environment formats"""

    # Test development variations
    for env in ["dev", "Dev", "development"]:
        try:
            client = AstrolabeClient(env, subscribed_projects=["test"])
            assert client.env.value == "development"
            print(f"✓ Client initialized with '{env}' -> {client.env.value}")
        except Exception as e:
            print(f"✗ Failed to initialize client with '{env}': {e}")
            raise

    # Test staging variations
    for env in ["stg", "staging"]:
        try:
            client = AstrolabeClient(env, subscribed_projects=["test"])
            assert client.env.value == "staging"
            print(f"✓ Client initialized with '{env}' -> {client.env.value}")
        except Exception as e:
            print(f"✗ Failed to initialize client with '{env}': {e}")
            raise

    # Test production variations
    for env in ["prod", "production"]:
        try:
            client = AstrolabeClient(env, subscribed_projects=["test"])
            assert client.env.value == "production"
            print(f"✓ Client initialized with '{env}' -> {client.env.value}")
        except Exception as e:
            print(f"✗ Failed to initialize client with '{env}': {e}")
            raise

    print("\n✓ All client initialization tests passed!")


def test_invalid_environment():
    """Test that invalid environments raise appropriate errors"""

    invalid_envs = ["invalid", "test", "local", ""]

    for env in invalid_envs:
        try:
            normalize_environment(env)
            print(f"✗ Should have failed for invalid environment: '{env}'")
            assert False, f"Should have raised ValueError for '{env}'"
        except ValueError as e:
            print(f"✓ Correctly rejected invalid environment '{env}': {e}")

    print("\n✓ All invalid environment tests passed!")


if __name__ == "__main__":
    print("Testing environment mapping functionality...\n")

    test_environment_mapping()
    test_client_initialization()
    test_invalid_environment()

    print("\n🎉 All tests passed! Environment mapping is working correctly.")
