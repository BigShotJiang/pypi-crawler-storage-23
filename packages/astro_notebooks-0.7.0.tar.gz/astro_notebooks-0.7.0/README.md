# astro-notebooks

[![PyPI - Version](https://img.shields.io/pypi/v/astro-notebooks.svg)](https://pypi.org/project/astro-notebooks)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/astro-notebooks.svg)](https://pypi.org/project/astro-notebooks)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install astro-notebooks
```

## License

`astro-notebooks` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
