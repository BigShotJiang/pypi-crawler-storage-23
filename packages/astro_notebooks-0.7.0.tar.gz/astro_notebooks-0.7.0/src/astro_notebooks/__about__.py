# SPDX-FileCopyrightText: 2024-present Matt Craig <mattwcraig@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
