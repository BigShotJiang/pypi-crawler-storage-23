# Display Context Refactor

## Problem

Assembling the "full view" of an item requires 4-5 separate calls:

```python
item = kp.get(id)
version_nav = kp.get_version_nav(id, version)
similar_items = kp.get_similar_for_display(id, limit)
similar_offsets = {s.id: kp.get_version_offset(s) for s in similar_items}
meta_sections = kp.resolve_meta(id, limit_per_doc)
```

This is copy-pasted across 6+ CLI command handlers.  Over REST, it's multiple round-trips for what should be one request.

## Design: Single Implementation, Three Consumers

### The shared layer

```python
# protocol.py — the shape

@dataclass
class SimilarRef:
    id: str           # base doc id
    offset: int       # version offset (0 = current)
    score: float | None
    date: str         # local date string
    summary: str

@dataclass  
class MetaRef:
    id: str
    summary: str

@dataclass
class VersionRef:
    offset: int       # absolute offset (1 = previous, 2 = two ago)
    date: str
    summary: str

@dataclass
class PartRef:
    part_num: int
    summary: str

@dataclass
class ItemContext:
    """Complete display context for a single item.  
    This is the wire format — JSON-serializable, 
    shared between CLI and REST."""
    
    id: str
    summary: str
    tags: dict[str, str]
    score: float | None
    viewing_offset: int              # 0 = current version
    similar: list[SimilarRef]
    meta: dict[str, list[MetaRef]]   # {learnings: [...], ...}
    parts: list[PartRef]
    prev: list[VersionRef]
    next: list[VersionRef]
    
    def to_dict(self) -> dict:
        """Serialize to JSON-ready dict."""
        ...
    
    @classmethod
    def from_dict(cls, d: dict) -> "ItemContext":
        """Deserialize from JSON dict."""
        ...
```

### The single assembly point

```python
# api.py — Keeper

def get_context(
    self,
    doc_id: str,
    *,
    version: str | None = None,
    similar_limit: int = 3,
    meta_limit: int = 3,
    include_similar: bool = True,
    include_meta: bool = True,
    include_parts: bool = True,
    include_versions: bool = True,
) -> ItemContext:
    """Assemble complete display context.  Single implementation."""
    item = self.get(doc_id, version=version)
    
    similar = []
    if include_similar:
        raw = self.get_similar_for_display(doc_id, limit=similar_limit)
        similar = [
            SimilarRef(
                id=s.tags.get("_base_id", s.id),
                offset=self.get_version_offset(s),
                score=s.score,
                date=local_date(s.tags.get("_updated", s.tags.get("_created", ""))),
                summary=s.summary,
            )
            for s in raw
        ]
    
    meta = {}
    if include_meta:
        raw_meta = self.resolve_meta(doc_id, limit_per_doc=meta_limit)
        meta = {
            name: [MetaRef(id=mi.id, summary=mi.summary) for mi in items]
            for name, items in raw_meta.items()
        }
    
    # ... parts, version_nav similarly
    
    return ItemContext(
        id=doc_id, summary=item.summary, tags=item.tags,
        score=item.score, viewing_offset=offset,
        similar=similar, meta=meta, parts=parts,
        prev=prev_refs, next=next_refs,
    )
```

### Three consumers, no duplication

```
┌─────────────┐
│  Keeper      │
│ get_context()│ ← single assembly, lives in api.py
└──────┬───────┘
       │ returns ItemContext
       ├──────────────────────────────┐
       │                              │
  CLI (local)                    REST service
       │                              │
  ItemContext                    ItemContext
       │                              │
  ┌────┴─────┐                   .to_dict()
  │ renderer │                        │
  │ (cli.py) │                   JSON response
  └──────────┘                        
       │                              
  YAML frontmatter                    
  or JSON output                      
                                      
  CLI (remote)                        
       │                              
  HTTP GET → JSON                     
       │                              
  ItemContext.from_dict()             
       │                              
  same renderer                       
```

**CLI local**: `Keeper.get_context()` → `ItemContext` → renderer
**CLI remote**: `GET /context` → JSON → `ItemContext.from_dict()` → same renderer  
**REST service**: `Keeper.get_context()` → `ItemContext.to_dict()` → JSON response

The renderer (`cli.py`) only ever sees `ItemContext`.  It never calls assembly methods.
The REST service never renders — it just serializes.
`remote.py` just deserializes and hands off to the same renderer.

### REST endpoint

```
GET /v1/notes/{id}/context?similar=3&meta=3&versions=true&parts=true
```

Response body is `ItemContext.to_dict()`.

For `now`:
```
GET /v1/now/context?similar=10&meta=3
```

### CLI rendering

```python
# cli.py

def format_context(ctx: ItemContext, as_json: bool = False) -> str:
    """Single renderer for ItemContext."""
    if as_json:
        return json.dumps(ctx.to_dict())
    return _render_frontmatter(ctx)

def _render_frontmatter(ctx: ItemContext) -> str:
    """YAML frontmatter output."""
    lines = ["---", f"id: {ctx.id}"]
    if ctx.tags:
        lines.append(f"tags: {{{...}}}")
    if ctx.similar:
        lines.append("similar:")
        for s in ctx.similar:
            lines.append(f"  - {s.id} ({s.score:.2f}) {s.date} {s.summary}")
    if ctx.meta:
        for name, refs in ctx.meta.items():
            lines.append(f"meta/{name}:")
            for r in refs:
                lines.append(f"  - {r.id} {r.summary}")
    if ctx.parts:
        lines.append("parts:")
        for p in ctx.parts:
            lines.append(f"  - @P{{{p.part_num}}} {p.summary}")
    if ctx.prev:
        lines.append("prev:")
        for v in ctx.prev:
            lines.append(f"  - @V{{{v.offset}}} {v.date} {v.summary}")
    lines.append("---")
    lines.append(ctx.summary)
    return "\n".join(lines)
```

Every CLI command that currently does the 5-call assembly dance becomes:

```python
ctx = kp.get_context(doc_id, similar_limit=limit)
typer.echo(format_context(ctx, as_json=json_flag))
```

## What moves where

| Current | New location |
|---------|-------------|
| Assembly (scattered across 6 CLI handlers) | `Keeper.get_context()` in api.py |
| `_format_yaml_frontmatter(item, version_nav, similar, ...)` | `_render_frontmatter(ctx: ItemContext)` in cli.py |
| `_format_item` JSON path | `ctx.to_dict()` |
| `remote.get_similar_for_display` + `get_version_nav` + ... | `remote.get_context()` → single HTTP call |
| keepmem routes (multiple data fetches) | `keeper.get_context()` → serialize |

## What doesn't change

- Underlying query methods (`get_similar_for_display`, `get_version_nav`, `resolve_meta`) remain as internal implementation
- `get()` without context stays for lightweight access (list views, search)
- Summary-line format for list output stays separate

## Scope

- ~100 lines: `ItemContext` + ref dataclasses in protocol.py
- ~80 lines: `get_context()` in api.py  
- ~60 lines: `format_context()` / `_render_frontmatter()` in cli.py
- ~30 lines: `get_context()` in remote.py (HTTP + deserialize)
- ~150 lines deleted: duplicated assembly in CLI handlers + redundant params in `_format_item`
- Net: roughly even on lines, significantly cleaner
