---
tags:
  category: system
  context: tag-value
---
# act: `offer`

A pre-commissive speech act — proposing to do something, not yet committed. Offers can be accepted (becoming commitments) or withdrawn. Tracked with `status`.

Example: "I could refactor the cache layer", "Would it help if I wrote tests for this?".
