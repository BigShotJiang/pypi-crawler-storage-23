"""pmtvs-distance: Signal analysis primitives."""
__version__ = "0.0.1"
