from ibkr_porez.gui.main import main

if __name__ == "__main__":
    raise SystemExit(main())
