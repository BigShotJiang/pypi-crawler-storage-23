"""Tests for safe psutil utility wrappers."""

from unittest.mock import MagicMock, patch

import psutil
import pytest

from process_watchman.model import ProcessInfo, WatcherConfig
from process_watchman.utils import (
    collect_process_info,
    safe_create_time,
    safe_process,
    truncate_cmdline,
)


class TestSafeProcess:
    @patch("process_watchman.utils.psutil.Process")
    def test_returns_process(self, mock_cls):
        proc = MagicMock()
        mock_cls.return_value = proc
        assert safe_process(123) is proc
        mock_cls.assert_called_once_with(123)

    @patch("process_watchman.utils.psutil.Process", side_effect=psutil.NoSuchProcess(999))
    def test_returns_none_for_missing(self, mock_cls):
        assert safe_process(999) is None


class TestSafeCreateTime:
    def test_returns_float(self):
        proc = MagicMock()
        proc.create_time.return_value = 1234.5
        assert safe_create_time(proc) == 1234.5

    def test_returns_none_on_no_such_process(self):
        proc = MagicMock()
        proc.create_time.side_effect = psutil.NoSuchProcess(1)
        assert safe_create_time(proc) is None

    def test_returns_none_on_access_denied(self):
        proc = MagicMock()
        proc.create_time.side_effect = psutil.AccessDenied(1)
        assert safe_create_time(proc) is None

    def test_returns_none_on_zombie(self):
        proc = MagicMock()
        proc.create_time.side_effect = psutil.ZombieProcess(1)
        assert safe_create_time(proc) is None


class TestTruncateCmdline:
    def test_short_cmdline(self):
        assert truncate_cmdline(["python", "app.py"], 200) == "python app.py"

    def test_exact_limit(self):
        assert truncate_cmdline(["abc"], 3) == "abc"

    def test_truncation(self):
        result = truncate_cmdline(["python", "-c", "x" * 300], 20)
        assert len(result) == 20
        assert result == "python -c " + "x" * 10

    def test_empty(self):
        assert truncate_cmdline([], 200) == ""


class TestCollectProcessInfo:
    def _make_proc(self, pid=10, ppid=1, ct=100.0, name="sleep",
                   cmdline=None, status="running"):
        proc = MagicMock()
        proc.pid = pid
        proc.ppid.return_value = ppid
        proc.create_time.return_value = ct
        proc.name.return_value = name
        proc.cmdline.return_value = cmdline or ["sleep", "60"]
        proc.status.return_value = status
        return proc

    def test_full_info(self):
        proc = self._make_proc()
        cfg = WatcherConfig()
        info = collect_process_info(proc, cfg)
        assert info is not None
        assert info.pid == 10
        assert info.ppid == 1
        assert info.create_time == 100.0
        assert info.name == "sleep"
        assert info.cmdline == "sleep 60"
        assert info.status == "running"

    def test_returns_none_on_no_such_process(self):
        proc = MagicMock()
        proc.pid = 10
        proc.ppid.side_effect = psutil.NoSuchProcess(10)
        cfg = WatcherConfig()
        assert collect_process_info(proc, cfg) is None

    def test_partial_on_access_denied_ppid(self):
        proc = MagicMock()
        proc.pid = 10
        proc.ppid.side_effect = psutil.AccessDenied(10)
        cfg = WatcherConfig()
        info = collect_process_info(proc, cfg, tolerate=True)
        assert info is not None
        assert info.pid == 10
        assert info.ppid == 0

    def test_raises_on_access_denied_when_not_tolerate(self):
        proc = MagicMock()
        proc.pid = 10
        proc.ppid.side_effect = psutil.AccessDenied(10)
        cfg = WatcherConfig()
        with pytest.raises(psutil.AccessDenied):
            collect_process_info(proc, cfg, tolerate=False)

    def test_name_access_denied_tolerated(self):
        proc = self._make_proc()
        proc.name.side_effect = psutil.AccessDenied(10)
        cfg = WatcherConfig()
        info = collect_process_info(proc, cfg, tolerate=True)
        assert info is not None
        assert info.name is None
        assert info.cmdline == "sleep 60"  # other fields still collected

    def test_cmdline_truncated(self):
        proc = self._make_proc(cmdline=["python", "x" * 300])
        cfg = WatcherConfig(cmdline_max_chars=15)
        info = collect_process_info(proc, cfg)
        assert info is not None
        assert len(info.cmdline) == 15

    def test_capture_flags_off(self):
        proc = self._make_proc()
        cfg = WatcherConfig(capture_name=False, capture_cmdline=False, capture_status=False)
        info = collect_process_info(proc, cfg)
        assert info is not None
        assert info.name is None
        assert info.cmdline is None
        assert info.status is None
        proc.name.assert_not_called()
        proc.cmdline.assert_not_called()
        proc.status.assert_not_called()
