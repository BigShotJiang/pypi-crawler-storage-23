"""Tests for data model classes."""

from process_watchman.model import ProcessIdentity, ProcessInfo, WatcherConfig


class TestProcessIdentity:
    def test_fields(self):
        pi = ProcessIdentity(pid=100, create_time=1000.5)
        assert pi.pid == 100
        assert pi.create_time == 1000.5

    def test_frozen(self):
        pi = ProcessIdentity(pid=100, create_time=1000.5)
        try:
            pi.pid = 200  # type: ignore[misc]
            assert False, "Should have raised"
        except AttributeError:
            pass

    def test_equality(self):
        a = ProcessIdentity(pid=1, create_time=1.0)
        b = ProcessIdentity(pid=1, create_time=1.0)
        c = ProcessIdentity(pid=1, create_time=2.0)
        assert a == b
        assert a != c

    def test_hashable(self):
        a = ProcessIdentity(pid=1, create_time=1.0)
        b = ProcessIdentity(pid=1, create_time=1.0)
        assert hash(a) == hash(b)
        assert len({a, b}) == 1


class TestProcessInfo:
    def test_required_fields(self):
        info = ProcessInfo(pid=10, ppid=1)
        assert info.pid == 10
        assert info.ppid == 1
        assert info.create_time is None
        assert info.name is None
        assert info.cmdline is None
        assert info.status is None

    def test_all_fields(self):
        info = ProcessInfo(
            pid=10, ppid=1, create_time=100.0,
            name="python", cmdline="python app.py", status="running",
        )
        assert info.name == "python"
        assert info.cmdline == "python app.py"
        assert info.status == "running"


class TestWatcherConfig:
    def test_defaults(self):
        cfg = WatcherConfig()
        assert cfg.max_depth == 16
        assert cfg.include_root is False
        assert cfg.max_descendants == 5000
        assert cfg.capture_name is True
        assert cfg.capture_cmdline is True
        assert cfg.cmdline_max_chars == 200
        assert cfg.capture_status is True
        assert cfg.strategy == "children_recursive"
        assert cfg.drop_exited is True
        assert cfg.keep_tombstones is False
        assert cfg.tolerate_access_denied is True

    def test_override(self):
        cfg = WatcherConfig(max_depth=4, strategy="scan_ppid", keep_tombstones=True)
        assert cfg.max_depth == 4
        assert cfg.strategy == "scan_ppid"
        assert cfg.keep_tombstones is True
