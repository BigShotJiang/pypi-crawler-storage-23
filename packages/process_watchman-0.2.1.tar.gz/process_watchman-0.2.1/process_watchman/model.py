"""Core data model: ProcessIdentity, ProcessInfo, WatcherConfig."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ProcessIdentity:
    """Unique identity of a process, safe against PID reuse."""

    pid: int
    create_time: float


@dataclass
class ProcessInfo:
    """Minimal information about a single process."""

    pid: int
    ppid: int
    create_time: float | None = None
    name: str | None = None
    cmdline: str | None = None
    status: str | None = None


@dataclass
class WatcherConfig:
    """Configuration for ProcessTreeWatcher."""

    max_depth: int = 16
    include_root: bool = False
    max_descendants: int = 5000

    # data capture
    capture_name: bool = True
    capture_cmdline: bool = True
    cmdline_max_chars: int = 200
    capture_status: bool = True

    # discovery strategy
    strategy: str = "children_recursive"  # children_recursive | scan_ppid

    # behavior
    drop_exited: bool = True
    keep_tombstones: bool = False
    tolerate_access_denied: bool = True
