"""ProcessTreeWatcher: core polling engine."""

from __future__ import annotations

import time
from collections import deque

import psutil

from .delta import Delta
from .model import ProcessIdentity, ProcessInfo, WatcherConfig
from .snapshot import Snapshot
from .utils import collect_process_info, safe_create_time, safe_process


class ProcessTreeWatcher:
    """Tracks the live descendant set of a root process via polling."""

    def __init__(
        self,
        root: ProcessIdentity,
        config: WatcherConfig | None = None,
    ) -> None:
        self._root = root
        self._config = config or WatcherConfig()
        self._prev_pids: set[int] = set()
        self._prev_processes: dict[int, ProcessInfo] = {}
        self._tombstones: dict[int, ProcessInfo] = {}

    @classmethod
    def attach(
        cls,
        root_pid: int,
        config: WatcherConfig | None = None,
    ) -> ProcessTreeWatcher:
        """Attach to a running process, resolving create_time immediately."""
        proc = safe_process(root_pid)
        if proc is None:
            raise psutil.NoSuchProcess(root_pid)
        ct = safe_create_time(proc)
        if ct is None:
            raise psutil.AccessDenied(root_pid)
        return cls(root=ProcessIdentity(pid=root_pid, create_time=ct), config=config)

    def live_pids(self) -> set[int]:
        """Return the current set of live descendant PIDs."""
        return set(self._prev_pids)

    def poll(self) -> Snapshot:
        """Poll the process tree and return a Snapshot."""
        ts = time.time()
        warnings: list[str] = []
        cfg = self._config
        tolerate = cfg.tolerate_access_denied

        # --- verify root ---
        root_alive, root_matches, root_proc = self._verify_root(warnings)

        # --- discover descendants ---
        current_processes: dict[int, ProcessInfo] = {}
        if root_alive and root_matches and root_proc is not None:
            current_processes = self._discover(root_proc, warnings, tolerate)

        # --- optionally include root ---
        if cfg.include_root and root_proc is not None and root_alive and root_matches:
            info = collect_process_info(root_proc, cfg, tolerate=tolerate)
            if info is not None:
                current_processes[self._root.pid] = info

        # --- delta ---
        current_pids = set(current_processes)
        added_pids = sorted(current_pids - self._prev_pids)
        removed_pids = sorted(self._prev_pids - current_pids)

        added = {pid: current_processes[pid] for pid in added_pids}
        removed = {pid: self._prev_processes[pid] for pid in removed_pids if pid in self._prev_processes}

        delta = Delta(
            added_pids=added_pids,
            removed_pids=removed_pids,
            added=added,
            removed=removed,
        )

        # --- tombstones ---
        if cfg.keep_tombstones:
            for pid in removed_pids:
                if pid in self._prev_processes:
                    self._tombstones[pid] = self._prev_processes[pid]

        # --- update state ---
        self._prev_pids = current_pids
        self._prev_processes = current_processes

        return Snapshot(
            ts=ts,
            root=self._root,
            root_alive=root_alive,
            root_matches_identity=root_matches,
            processes=current_processes,
            delta=delta,
            warnings=warnings,
        )

    # ------------------------------------------------------------------
    # internal helpers
    # ------------------------------------------------------------------

    def _verify_root(
        self, warnings: list[str]
    ) -> tuple[bool, bool, psutil.Process | None]:
        """Check root is alive and identity matches.

        Returns (root_alive, root_matches_identity, psutil.Process | None).
        """
        proc = safe_process(self._root.pid)
        if proc is None:
            return False, False, None

        ct = safe_create_time(proc)
        if ct is None:
            warnings.append(
                f"Cannot read create_time for root pid={self._root.pid}"
            )
            return True, False, proc

        if ct != self._root.create_time:
            warnings.append(
                f"PID reuse detected for pid={self._root.pid}: "
                f"expected create_time={self._root.create_time}, got {ct}"
            )
            return True, False, proc

        return True, True, proc

    def _discover(
        self,
        root_proc: psutil.Process,
        warnings: list[str],
        tolerate: bool,
    ) -> dict[int, ProcessInfo]:
        """Discover descendants using the configured strategy."""
        cfg = self._config
        if cfg.strategy == "children_recursive":
            return self._discover_children_recursive(root_proc, warnings, tolerate)
        if cfg.strategy == "scan_ppid":
            return self._discover_scan_ppid(warnings, tolerate)
        warnings.append(f"Unknown strategy {cfg.strategy!r}, falling back to children_recursive")
        return self._discover_children_recursive(root_proc, warnings, tolerate)

    def _discover_children_recursive(
        self,
        root_proc: psutil.Process,
        warnings: list[str],
        tolerate: bool,
    ) -> dict[int, ProcessInfo]:
        cfg = self._config
        try:
            children = root_proc.children(recursive=True)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess) as exc:
            warnings.append(f"children(recursive=True) failed: {exc}")
            return {}

        result: dict[int, ProcessInfo] = {}
        for child in children:
            if len(result) >= cfg.max_descendants:
                warnings.append(
                    f"max_descendants={cfg.max_descendants} reached, truncating"
                )
                break
            if cfg.drop_exited and self._is_exited(child):
                continue
            info = collect_process_info(child, cfg, tolerate=tolerate)
            if info is not None:
                result[child.pid] = info

        return result

    def _discover_scan_ppid(
        self,
        warnings: list[str],
        tolerate: bool,
    ) -> dict[int, ProcessInfo]:
        cfg = self._config
        attrs = ["pid", "ppid"]

        # build adjacency: ppid -> [pid]
        adjacency: dict[int, list[int]] = {}
        proc_map: dict[int, psutil.Process] = {}
        for proc in psutil.process_iter(attrs):
            try:
                info_dict = proc.info  # type: ignore[attr-defined]
                pid = info_dict["pid"]
                ppid = info_dict["ppid"]
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
            adjacency.setdefault(ppid, []).append(pid)
            proc_map[pid] = proc

        # BFS from root up to max_depth
        result: dict[int, ProcessInfo] = {}
        queue: deque[tuple[int, int]] = deque()  # (pid, depth)
        for child_pid in adjacency.get(self._root.pid, []):
            queue.append((child_pid, 1))

        while queue:
            pid, depth = queue.popleft()
            if depth > cfg.max_depth:
                continue
            if len(result) >= cfg.max_descendants:
                warnings.append(
                    f"max_descendants={cfg.max_descendants} reached, truncating"
                )
                break
            if pid in result:
                continue

            proc = proc_map.get(pid)
            if proc is None:
                continue
            if cfg.drop_exited and self._is_exited(proc):
                continue
            info = collect_process_info(proc, cfg, tolerate=tolerate)
            if info is not None:
                result[pid] = info

            for grandchild_pid in adjacency.get(pid, []):
                queue.append((grandchild_pid, depth + 1))

        return result

    @staticmethod
    def _is_exited(proc: psutil.Process) -> bool:
        """Return True if the process is a zombie or dead."""
        try:
            return proc.status() in (psutil.STATUS_ZOMBIE, psutil.STATUS_DEAD)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return True
