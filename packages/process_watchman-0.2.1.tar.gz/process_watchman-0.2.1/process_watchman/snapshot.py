"""Snapshot: point-in-time observation of the process tree."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .delta import Delta
    from .model import ProcessIdentity, ProcessInfo


@dataclass
class Snapshot:
    """Point-in-time observation of the process tree."""

    ts: float
    root: ProcessIdentity
    root_alive: bool
    root_matches_identity: bool
    processes: dict[int, ProcessInfo]
    delta: Delta
    warnings: list[str] = field(default_factory=list)
