"""Delta: changes between consecutive polls."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .model import ProcessInfo


@dataclass
class Delta:
    """Changes observed between two consecutive snapshots."""

    added_pids: list[int] = field(default_factory=list)
    removed_pids: list[int] = field(default_factory=list)
    added: dict[int, ProcessInfo] = field(default_factory=dict)
    removed: dict[int, ProcessInfo] = field(default_factory=dict)
