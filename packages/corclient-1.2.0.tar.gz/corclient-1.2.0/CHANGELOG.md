# [1.2.0](https://github.com/ProjectCORTeam/corcli/compare/v1.1.1...v1.2.0) (2026-02-25)


### Features

* add services commands ([976f7bf](https://github.com/ProjectCORTeam/corcli/commit/976f7bf17362c19c2c2d77a4a029f2b2fbfd6199))
* **service:** add service init, push, pull, sync and deploy commands ([1f9dece](https://github.com/ProjectCORTeam/corcli/commit/1f9decee337898ccef96bb5852aac06bfe11a108))
* **service:** add status command and deploy via Graph API proxy ([bdba938](https://github.com/ProjectCORTeam/corcli/commit/bdba9380154f7c2b2e19d9307390087955d7a7bc))

## [1.1.1](https://github.com/ProjectCORTeam/corcli/compare/v1.1.0...v1.1.1) (2026-02-13)


### Bug Fixes

* update homebrew pipeline ([aefae18](https://github.com/ProjectCORTeam/corcli/commit/aefae182a5184c781e3494959d31f2fe51d7a1f8))

# [1.1.0](https://github.com/ProjectCORTeam/corcli/compare/v1.0.2...v1.1.0) (2026-02-13)


### Features

* add companybackup commands and GraphQL client ([8f2fc3c](https://github.com/ProjectCORTeam/corcli/commit/8f2fc3c66777623a5e0bcdd6fd059415d8dbe63f))

## [1.0.2](https://github.com/ProjectCORTeam/corcli/compare/v1.0.1...v1.0.2) (2026-02-13)


### Bug Fixes

* add new cognito client id ([fb7a5ea](https://github.com/ProjectCORTeam/corcli/commit/fb7a5eaae6b4eedf1cf844e4db30d3c623354d05))

## [1.0.1](https://github.com/ProjectCORTeam/corcli/compare/v1.0.0...v1.0.1) (2025-09-30)


### Bug Fixes

* release flow ([d8ee1ed](https://github.com/ProjectCORTeam/corcli/commit/d8ee1ed79024d4ce292233fed073054445733469))
* remove setup.py to fix version detection with setuptools-scm ([4fcb24c](https://github.com/ProjectCORTeam/corcli/commit/4fcb24c6ab847fc90d9c517784e98fa589fbf6ad))

# 1.0.0 (2025-09-30)


### Features

* add linting and code quality tools ([a0a8a28](https://github.com/ProjectCORTeam/corcli/commit/a0a8a28f310005ddc3de4bf3dcb11c2722f2faf8))
* add linting and code quality tools ([e5ee76d](https://github.com/ProjectCORTeam/corcli/commit/e5ee76d89a853f83b6681c30756c0207b34aa469))
* configure semantic-release for Python project ([6944590](https://github.com/ProjectCORTeam/corcli/commit/6944590667bf498fea5c9938b35b3a16659f40cc))
* configure semantic-release for Python with setuptools-scm ([b43fea1](https://github.com/ProjectCORTeam/corcli/commit/b43fea15f4d658f2cc8209a42ef770a86f257494))
* initial version ([deac096](https://github.com/ProjectCORTeam/corcli/commit/deac0960690fdf43208efcd893472ce3f95283ee))
