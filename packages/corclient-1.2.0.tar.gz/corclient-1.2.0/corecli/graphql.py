"""
Cliente GraphQL para la API de Amplify (AppSync) usando el id_token de Cognito.
Requiere haber hecho login antes (`cor login`).

Configuración:
  - COR_GRAPHQL_URL: URL del endpoint GraphQL (ej. https://api.cor-dev.com/graphql
    o https://xxxx.appsync-api.us-east-2.amazonaws.com/graphql)
"""

import os
import time
from typing import Any, Optional, cast

import requests

from corecli import auth
from corecli.utils import decode_jwt, load_tokens


def _get_graphql_url() -> str:
    url = os.environ.get("COR_GRAPHQL_URL", "").strip()
    if not url:
        # Default para cor-dev con custom domain
        url = "https://api.cor-dev.com/graphql"
    if not url.endswith("/graphql"):
        url = url.rstrip("/") + "/graphql"
    return url


def _get_valid_id_token() -> Optional[str]:
    """Devuelve un id_token válido (refresca si está expirado)."""
    tokens = load_tokens()
    if not tokens or "id_token" not in tokens:
        return None
    id_token = tokens["id_token"]
    try:
        payload = decode_jwt(id_token)
        exp = payload.get("exp") or 0
        # Refrescar si expira en menos de 60 segundos
        if exp < time.time() + 60:
            auth.refresh_tokens()
            tokens = load_tokens()
            id_token = (tokens or {}).get("id_token")
    except Exception:
        pass
    return cast(Optional[str], id_token)


def graphql_request(
    query: str,
    variables: Optional[dict[str, Any]] = None,
    operation_name: Optional[str] = None,
) -> dict[str, Any]:
    """
    Envía una petición GraphQL a la API de Amplify (AppSync) autenticada con el User Pool.

    Args:
        query: Documento GraphQL (ej. "query ListTeams { listTeams { items { id name } } }")
        variables: Variables opcionales del query
        operation_name: Nombre de la operación si el documento tiene varias

    Returns:
        El JSON de respuesta de AppSync (típicamente {"data": ...} o {"errors": ...})

    Raises:
        RuntimeError: Si no hay sesión (hacer `cor login` antes)
        requests.HTTPError: Si la petición falla
    """
    id_token = _get_valid_id_token()
    if not id_token:
        raise RuntimeError("No hay sesión activa. Ejecuta `cor login` antes de llamar a la API.")

    url = _get_graphql_url()
    payload: dict[str, Any] = {"query": query}
    if variables is not None:
        payload["variables"] = variables
    if operation_name is not None:
        payload["operationName"] = operation_name

    try:
        resp = requests.post(
            url,
            json=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {id_token}",
            },
            timeout=30,
        )
        resp.raise_for_status()
    except requests.exceptions.ConnectionError as e:
        raise RuntimeError(
            f"No se pudo conectar a la API Graph ({url}). Comprueba red y COR_GRAPHQL_URL."
        ) from e
    except requests.exceptions.Timeout as e:
        raise RuntimeError(f"Timeout al conectar con la API Graph ({url}).") from e
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(
            f"La API Graph respondió con error: {e.response.status_code if e.response is not None else '?'}."
        ) from e
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Error de red al llamar a la API Graph: {e}") from e

    try:
        return cast(dict[str, Any], resp.json())
    except ValueError as e:
        raise RuntimeError(
            f"La API Graph devolvió una respuesta no JSON (status {resp.status_code})."
        ) from e


def graphql_query(query: str, variables: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Alias de graphql_request para queries (mismo comportamiento)."""
    return graphql_request(query, variables=variables)
