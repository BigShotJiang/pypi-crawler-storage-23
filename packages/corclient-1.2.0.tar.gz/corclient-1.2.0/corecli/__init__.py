"""CoreCLI - CLI para autenticación con AWS Cognito usando PKCE."""

from corecli._version import __version__

__all__ = ["__version__"]
