"""
Comandos para solicitar y consultar backups de compañía (Company Backup).
Requiere sesión activa (`cor login`) y API GraphQL configurada (COR_GRAPHQL_URL).
"""

from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from corecli.graphql import graphql_request
from corecli.utils import decode_jwt, load_tokens

console = Console()


def _get_requested_by() -> str:
    """Obtiene el email del usuario actual desde el id_token."""
    tokens = load_tokens()
    if not tokens or "id_token" not in tokens:
        raise RuntimeError("No hay sesión activa. Ejecuta `cor login` primero.")
    claims = decode_jwt(tokens["id_token"])
    return claims.get("email") or claims.get("cognito:username") or "unknown"


def _format_dt(iso: Optional[str]) -> str:
    """Formatea fecha ISO a legible (fecha y hora)."""
    if not iso:
        return "—"
    try:
        from datetime import datetime

        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except Exception:
        return iso or "—"


# -----------------------------------------------------------------------------
# create
# -----------------------------------------------------------------------------
def create(domain: str, notify_to: list[str]) -> None:
    """Crea una solicitud de backup para el dominio indicado."""
    requested_by = _get_requested_by()
    notify_users = [e.strip() for e in notify_to if e.strip()]

    mutation = """
    mutation CreateCompanyBackupRequest($input: CreateCompanyBackupRequestInput!) {
      createCompanyBackupRequest(input: $input) {
        id
        company_domain
        status
        requestedBy
        notify_users
        createdAt
      }
    }
    """
    variables = {
        "input": {
            "company_domain": domain.strip(),
            "status": "PENDING",
            "requestedBy": requested_by,
            "notify_users": notify_users if notify_users else None,
        }
    }

    result = graphql_request(mutation, variables=variables)
    errors = result.get("errors")
    if errors:
        msg = errors[0].get("message", str(errors))
        console.print(Panel(f"[red]{msg}[/red]", title="Error", border_style="red"))
        raise SystemExit(1)

    data = result.get("data", {}).get("createCompanyBackupRequest") or {}
    console.print(
        Panel.fit(
            f"[green]Solicitud creada.[/green]\n\n"
            f"Dominio: [cyan]{data.get('company_domain', domain)}[/cyan]\n"
            f"Estado: [cyan]{data.get('status', 'PENDING')}[/cyan]\n"
            f"ID: [dim]{data.get('id', '')}[/dim]",
            title="Company Backup",
            border_style="green",
        )
    )


# -----------------------------------------------------------------------------
# get
# -----------------------------------------------------------------------------
def get(domain: str) -> None:
    """Muestra estado y progreso del backup más reciente para el dominio."""
    query = """
    query ListCompanyBackupRequests($filter: ModelCompanyBackupRequestFilterInput, $limit: Int) {
      listCompanyBackupRequests(filter: $filter, limit: $limit) {
        items {
          id
          company_domain
          status
          progress_status
          chunksQty
          chunksLeft
          errorMessage
          createdAt
          updatedAt
        }
      }
    }
    """
    variables = {
        "filter": {"company_domain": {"eq": domain.strip()}},
        "limit": 10,
    }

    result = graphql_request(query, variables=variables)
    errors = result.get("errors")
    if errors:
        console.print(
            Panel(
                f"[red]{errors[0].get('message', str(errors))}[/red]",
                title="Error",
                border_style="red",
            )
        )
        raise SystemExit(1)

    items = (result.get("data") or {}).get("listCompanyBackupRequests") or {}
    items = items.get("items") or []
    if not items:
        console.print(
            Panel.fit(
                f"No hay solicitudes de backup para el dominio [cyan]{domain}[/cyan].",
                title="Company Backup",
                border_style="yellow",
            )
        )
        return

    # Más reciente primero (por createdAt)
    items_sorted = sorted(items, key=lambda x: (x.get("createdAt") or ""), reverse=True)
    latest = items_sorted[0]

    status = latest.get("status") or "—"
    progress = latest.get("progress_status")
    progress_str = f"{progress}%" if progress is not None else "—"
    err = latest.get("errorMessage")

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("Dominio", latest.get("company_domain", domain))
    table.add_row("Estado", str(status))
    table.add_row("Progreso", progress_str)
    if err:
        table.add_row("Error", f"[red]{err}[/red]")
    table.add_row("Solicitado", _format_dt(latest.get("createdAt")))
    table.add_row("Última actualización", _format_dt(latest.get("updatedAt")))

    console.print(Panel(table, title="Company Backup · Estado", border_style="cyan"))


# -----------------------------------------------------------------------------
# list
# -----------------------------------------------------------------------------
def list_requests(status: Optional[str], limit: int) -> None:
    """Lista solicitudes de backup (por defecto todas; opcionalmente filtradas por status). Orden cronológico."""
    query = """
    query ListCompanyBackupRequests($filter: ModelCompanyBackupRequestFilterInput, $limit: Int) {
      listCompanyBackupRequests(filter: $filter, limit: $limit) {
        items {
          id
          company_domain
          status
          requestedBy
          progress_status
          createdAt
          updatedAt
        }
      }
    }
    """
    variables: dict = {"limit": min(limit, 100)}
    if status:
        variables["filter"] = {"status": {"eq": status.upper()}}

    result = graphql_request(query, variables=variables)
    errors = result.get("errors")
    if errors:
        console.print(
            Panel(
                f"[red]{errors[0].get('message', str(errors))}[/red]",
                title="Error",
                border_style="red",
            )
        )
        raise SystemExit(1)

    items = (result.get("data") or {}).get("listCompanyBackupRequests") or {}
    items = items.get("items") or []
    # Orden cronológico: más recientes primero
    items = sorted(items, key=lambda x: (x.get("createdAt") or ""), reverse=True)[:limit]

    if not items:
        console.print(
            Panel.fit(
                "No hay solicitudes que mostrar.", title="Company Backup", border_style="yellow"
            )
        )
        return

    table = Table(title="Company Backup · Últimas solicitudes", box=None, padding=(0, 1))
    table.add_column("Dominio", style="cyan")
    table.add_column("Estado", style="white")
    table.add_column("Solicitado por", style="dim")
    table.add_column("Progreso", justify="right")
    table.add_column("Fecha solicitud", style="dim")
    table.add_column("Fecha lista", style="dim")

    for row in items:
        progress = row.get("progress_status")
        progress_str = f"{progress}%" if progress is not None else "—"
        status_val = row.get("status") or "—"
        # "Fecha lista" = updatedAt cuando está FINISHED/FAILED, sino "—"
        done_at = _format_dt(row.get("updatedAt")) if status_val in ("FINISHED", "FAILED") else "—"
        table.add_row(
            row.get("company_domain", "—"),
            status_val,
            row.get("requestedBy", "—"),
            progress_str,
            _format_dt(row.get("createdAt")),
            done_at,
        )

    console.print(Panel(table, border_style="cyan"))
