"""
Comando: cor service deploy
Dispara el workflow terraform-aws-build-deploy.yaml vía API Graph (proxy a GitHub).
Requiere cor login; no usa credenciales locales de GitHub.
"""

from __future__ import annotations

import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import questionary
import typer
from questionary import Choice, Style
from rich.console import Console
from rich.prompt import Prompt

from corecli.service._config_sync import get_repo_root
from corecli.service.github_proxy import trigger_workflow_dispatch

console = Console()

WORKFLOW_FILENAME = "terraform-aws-build-deploy.yaml"
WORKFLOW_PATH = f".github/workflows/{WORKFLOW_FILENAME}"

# Todos los stages válidos (por CLI)
STAGES = [
    "production",
    "beta",
    "staging1",
    "staging2",
    "staging3",
    "staging4",
    "staging5",
    "staging6",
    "staging7",
    "staging8",
    "staging9",
    "staging10",
]

# Solo staging en la lista seleccionable
STAGES_SELECTABLE = [s for s in STAGES if s.startswith("staging")]

RUNNERS = ["k8s-runners-stg", "ubuntu-latest"]
DEFAULT_REF = "master"


def _run(cmd: list[str], cwd: Path | None = None, check: bool = False) -> tuple[int, str, str]:
    import subprocess

    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return r.returncode, r.stdout.strip(), r.stderr.strip()


def get_owner_repo(repo_root: Path) -> tuple[str, str] | None:
    """Obtiene owner y repo desde git remote origin. Devuelve (owner, repo) o None."""
    code, out, _ = _run(["git", "remote", "get-url", "origin"], cwd=repo_root)
    if code != 0 or not out:
        return None
    # git@github.com:ProjectCORTeam/cor-os.git o https://github.com/ProjectCORTeam/cor-os.git
    match = re.match(
        r"(?:git@github\.com:|https?://(?:[^@]+@)?github\.com/)([^/]+)/([^/]+?)(?:\.git)?$",
        out.strip(),
    )
    if match:
        return match.group(1), match.group(2)
    return None


def has_workflow(repo_root: Path) -> bool:
    return (repo_root / WORKFLOW_PATH).is_file()


def get_default_branch(repo_root: Path) -> str:
    """Rama actual o la por defecto del remoto."""
    code, out, _ = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_root)
    if code == 0 and out and out != "HEAD":
        return out
    code, out, _ = _run(["git", "symbolic-ref", "refs/remotes/origin/HEAD"], cwd=repo_root)
    if code == 0 and out:
        return out.replace("refs/remotes/origin/", "")
    return DEFAULT_REF


# Estilo para questionary (teclado: flechas, Space para marcar, Enter para confirmar)
_choice_style = Style(
    [
        ("qmark", "fg:cyan bold"),
        ("question", "bold"),
        ("answer", "fg:green bold"),
        ("pointer", "fg:cyan bold"),
        ("highlighted", "fg:cyan bold"),
        ("selected", "fg:green"),
    ]
)


def choose_stages_interactive() -> list[str]:
    """Lista múltiple con teclado: Space para marcar/desmarcar, Enter para continuar."""
    if not sys.stdin.isatty():
        return []
    try:
        chosen = questionary.checkbox(
            "Seleccione stage(s) - solo staging (Space para marcar, Enter para continuar):",
            choices=STAGES_SELECTABLE,
            style=_choice_style,
        ).ask()
    except (EOFError, KeyboardInterrupt):
        return []
    return list(chosen) if chosen else []


def choose_runner_interactive() -> str | None:
    """Lista simple con teclado: flechas para mover, Enter para elegir."""
    if not sys.stdin.isatty():
        return None
    try:
        result = questionary.select(
            "Seleccione runner:",
            choices=RUNNERS,
            style=_choice_style,
        ).ask()
        return str(result) if result is not None else None
    except (EOFError, KeyboardInterrupt):
        return None


BUILD_OPT_ONLY = "Only build (solo build, sin deploy)"
BUILD_OPT_FORCE = "Force build"


def choose_build_options_interactive(
    default_build: bool = False,
    default_force: bool = False,
) -> tuple[bool, bool]:
    """Checkbox: Only build y Force build. Space para marcar, Enter para continuar."""
    if not sys.stdin.isatty():
        return default_build, default_force
    try:
        chosen = questionary.checkbox(
            "Opciones de build (Space para marcar, Enter para continuar):",
            choices=[
                Choice(BUILD_OPT_ONLY, checked=default_build),
                Choice(BUILD_OPT_FORCE, checked=default_force),
            ],
            style=_choice_style,
        ).ask()
    except (EOFError, KeyboardInterrupt):
        return default_build, default_force
    if chosen is None:
        return default_build, default_force
    return BUILD_OPT_ONLY in chosen, BUILD_OPT_FORCE in chosen


def trigger_workflow(
    owner: str,
    repo: str,
    ref: str,
    environment: str,
    only_build: bool,
    force_build: bool = False,
    runner: str | None = None,
) -> bool:
    """Dispara el workflow vía API Graph (proxy a GitHub). Requiere cor login."""
    runner = runner or RUNNERS[0]
    success, message = trigger_workflow_dispatch(
        owner=owner,
        repo=repo,
        ref=ref,
        workflow_file=WORKFLOW_FILENAME,
        inputs={
            "environment": environment,
            "only-build": "true" if only_build else "false",
            "force-build": "true" if force_build else "false",
            "runner": runner,
        },
    )
    if not success and message:
        console.print(f"[red]✖[/red] {message}")
    return success


def register(app: typer.Typer) -> None:
    @app.command("deploy")
    def deploy(
        stage: list[str] | None = typer.Option(  # noqa: B008
            None,
            "--stage",
            "-s",
            help="Stage(s) a disparar (puede repetirse: -s staging1 -s staging2). Si no se pasa, lista seleccionable (solo staging).",
        ),
        service: str | None = typer.Option(  # noqa: B008
            None,
            "--service",
            help="Repositorio como owner/repo (ej. ProjectCORTeam/cor-os). Por defecto: repo actual si tiene el workflow.",
        ),
        build: bool = typer.Option(
            False,
            "--build",
            "-b",
            help="Solo build (only-build=true), sin ejecutar deploy.",
        ),
        force_build: bool = typer.Option(
            False,
            "--force-build",
            "-fb",
            help="Forzar build (force-build=true).",
        ),
        runner: str | None = typer.Option(  # noqa: B008
            None,
            "--runner",
            "-r",
            help="Runner de GitHub. Si no se pasa, se muestra lista seleccionable.",
        ),
        ref: str | None = typer.Option(  # noqa: B008
            None,
            "--ref",
            help=f"Rama o ref (por defecto: {DEFAULT_REF}).",
        ),
        yes: bool = typer.Option(
            False,
            "--yes",
            "-y",
            help="No pedir confirmación antes de disparar.",
        ),
    ):
        """Dispara el workflow terraform-aws-build-deploy vía GitHub API (no requiere gh). Múltiples stages en paralelo."""
        repo_root = get_repo_root()
        owner: str | None = None
        repo_name: str | None = None

        if service:
            if "/" in service:
                parts = service.strip().split("/", 1)
                owner, repo_name = parts[0], parts[1]
            else:
                console.print(
                    "[red]✖[/red] --service debe ser owner/repo (ej. ProjectCORTeam/cor-os)."
                )
                raise SystemExit(1)
        else:
            owner_repo = get_owner_repo(repo_root)
            if owner_repo and has_workflow(repo_root):
                owner, repo_name = owner_repo
                console.print(f"[dim]Repo detectado: [bold]{owner}/{repo_name}[/bold][/dim]")
            else:
                if not sys.stdin.isatty():
                    console.print(
                        "[red]✖[/red] No se detectó repo con el workflow. Use --service owner/repo."
                    )
                    raise SystemExit(1)
                console.print(
                    "No se encontró el workflow en el repo actual. Indique el repositorio."
                )
                try:
                    service = Prompt.ask("owner/repo (ej. ProjectCORTeam/cor-os)")
                except (EOFError, KeyboardInterrupt):
                    raise SystemExit(0) from None
                if not service or "/" not in service:
                    console.print("[red]✖[/red] Formato: owner/repo")
                    raise SystemExit(1)
                owner, repo_name = service.strip().split("/", 1)

        # Stages: validar los pasados por CLI o mostrar lista (solo staging)
        stages_to_run: list[str] = []
        if stage:
            for s in stage:
                if s in STAGES:
                    stages_to_run.append(s)
                else:
                    console.print(f"[yellow]⚠ Stage ignorado (inválido): {s}[/yellow]")
        if not stages_to_run:
            stages_to_run = choose_stages_interactive()
        if not stages_to_run:
            if not sys.stdin.isatty():
                console.print(
                    "[red]✖[/red] Indique --stage (staging1..staging10) o use la lista interactiva."
                )
            else:
                console.print("Cancelado.")
            raise SystemExit(1)

        # Runner: pasado por CLI o lista seleccionable
        runner_choice = runner
        if runner_choice and runner_choice not in RUNNERS:
            console.print(
                f"[yellow]⚠ Runner '{runner_choice}' no está en la lista; usando {RUNNERS[0]}.[/yellow]"
            )
            runner_choice = RUNNERS[0]
        if not runner_choice:
            runner_choice = choose_runner_interactive()
        if not runner_choice:
            runner_choice = RUNNERS[0]

        # Only build / Force build: pasado por CLI o cuestionario
        if sys.stdin.isatty():
            build, force_build = choose_build_options_interactive(build, force_build)

        # Ref: por defecto master
        if ref:
            branch = ref
        elif owner and repo_name and get_owner_repo(repo_root) == (owner, repo_name):
            branch = get_default_branch(repo_root)
        else:
            branch = DEFAULT_REF

        console.print("\n[bold blue]▶ Resumen[/bold blue]")
        console.print(f"  [dim]Repo:       {owner}/{repo_name}[/dim]")
        console.print(f"  [dim]Ref:       {branch}[/dim]")
        console.print(f"  [dim]Stages:     {', '.join(stages_to_run)}[/dim]")
        console.print(f"  [dim]Runner:     {runner_choice}[/dim]")
        console.print(f"  [dim]Only build: {build}[/dim]")
        console.print(f"  [dim]Force build: {force_build}[/dim]")

        if not yes and sys.stdin.isatty():
            try:
                reply = Prompt.ask("\n¿Confirmar?", default="y").strip().lower()
            except (EOFError, KeyboardInterrupt):
                console.print("Cancelado.")
                raise SystemExit(0) from None
            if reply and reply not in ("y", "yes", "s", "si"):
                console.print("Cancelado.")
                raise SystemExit(0)

        console.print("\n[bold blue]▶ Disparando workflow(s)[/bold blue]")

        assert owner is not None and repo_name is not None
        failed: list[str] = []
        ok_count = 0
        with ThreadPoolExecutor(max_workers=min(len(stages_to_run), 10)) as executor:
            futures = {
                executor.submit(
                    trigger_workflow,
                    owner,
                    repo_name,
                    branch,
                    st,
                    build,
                    force_build,
                    runner_choice,
                ): st
                for st in stages_to_run
            }
            for fut in as_completed(futures):
                st = futures[fut]
                try:
                    if fut.result():
                        ok_count += 1
                        console.print(f"  [green]✔[/green] {st}")
                    else:
                        failed.append(st)
                except Exception as e:
                    failed.append(st)
                    console.print(f"  [red]✖[/red] {st}: {e}")
        if failed:
            console.print(f"\n[red]✖[/red] Fallaron: {', '.join(failed)}")
            raise SystemExit(1) from None
        workflow_url = (
            f"https://github.com/{owner}/{repo_name}/actions/workflows/{WORKFLOW_FILENAME}"
        )
        console.print(f"\n[green]✔[/green] {ok_count} workflow(s) disparado(s).")
        console.print(f"  [bold]Ver ejecución:[/bold] [link={workflow_url}]{workflow_url}[/link]\n")
