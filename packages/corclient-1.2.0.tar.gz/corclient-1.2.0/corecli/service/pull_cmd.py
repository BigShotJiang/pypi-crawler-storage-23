"""
Comando: cor service pull
Descarga el JSON de config desde S3 al repo local.
"""

from __future__ import annotations

import typer
from rich.console import Console

from corecli.service._config_sync import (
    S3_BUCKET,
    S3_PREFIX,
    aws_s3_cp,
    generate_tfvars,
    get_repo_root,
    resolve_for_pull,
)

console = Console()


def register(app: typer.Typer) -> None:
    @app.command("pull")
    def pull(
        service: str | None = typer.Option(
            None,
            "--service",
            "-s",
            help="Nombre del servicio (descarga a .infra/ProjectCORTeam/<service>.json)",
        ),
        config: str | None = typer.Option(
            None,
            "--config",
            "-c",
            help="Ruta destino del JSON (o nombre de archivo en S3 si es pull)",
        ),
        no_sync: bool = typer.Option(
            False,
            "--no-sync",
            help="No generar terraform.auto.tfvars.json tras descargar",
        ),
    ):
        """Descarga el JSON de config desde S3 al repo local."""
        repo_root = get_repo_root()
        try:
            s3_name, local_path = resolve_for_pull(repo_root, config, service)
        except SystemExit:
            raise
        src_s3 = f"s3://{S3_BUCKET}/{S3_PREFIX}/{s3_name}"
        console.print("\n[bold blue]▶ Descargando archivo[/bold blue]")
        console.print(f"  [dim]Origen:  {src_s3}[/dim]")
        console.print(f"  [dim]Destino: {local_path}[/dim]")
        local_path.parent.mkdir(parents=True, exist_ok=True)
        aws_s3_cp(src_s3, str(local_path))
        console.print("[green]✔[/green] Descarga completada")
        if not no_sync:
            console.print("[bold blue]▶[/bold blue] Generando terraform.auto.tfvars.json")
            generate_tfvars(local_path, repo_root)
        console.print()
