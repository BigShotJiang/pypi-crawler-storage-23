"""
Proxy a GitHub API vía la API Graph (Amplify/AppSync).
Usa corecli.graphql.graphql_request y las operaciones del backend:
  - githubApiGet (query): GET con path
  - githubApiRequest (mutation): method, path, body

Referencia: gs-cloudbackoffice-backend-amplify/amplify/data (resource.ts, github-api-handler).
Requiere cor login; no usa credenciales locales de GitHub.
"""

from __future__ import annotations

import json
from typing import Any, cast

from corecli.graphql import graphql_request


def _parse_aws_json(value: Any) -> dict[str, Any]:
    """AWSJSON puede llegar como dict (ya parseado) o como string JSON."""
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            return cast(dict[str, Any], json.loads(value))
        except json.JSONDecodeError:
            pass
    raise RuntimeError("Respuesta no es un objeto JSON válido")


def _github_get(path: str) -> dict[str, Any]:
    """
    GET a la API de GitHub vía githubApiGet.
    path: sin host, ej. /repos/owner/repo/actions/workflows
    Devuelve el cuerpo JSON de la respuesta. Lanza RuntimeError si falla.
    """
    # githubApiGet devuelve AWSJSON (escalar); no se puede sub-seleccionar
    query = """
    query GithubApiGet($path: String!) {
      githubApiGet(path: $path)
    }
    """
    result = graphql_request(query, variables={"path": path})
    errors = result.get("errors")
    if errors:
        msg = errors[0].get("message", str(errors))
        if str(msg).strip().lower() == "fetch failed":
            msg = (
                "fetch failed (el proxy del backend no pudo conectar con GitHub; "
                "comprueba que el backend tenga red y acceso a api.github.com)."
            )
        raise RuntimeError(msg)
    raw = (result.get("data") or {}).get("githubApiGet")
    if raw is None:
        raise RuntimeError("Respuesta sin githubApiGet")
    try:
        payload = _parse_aws_json(raw)
    except RuntimeError:
        raise
    if not payload.get("ok"):
        status = payload.get("statusCode", "?")
        data = payload.get("data")
        err_msg = str(data) if data is not None else f"HTTP {status}"
        if err_msg.strip().lower() == "fetch failed":
            err_msg = (
                "fetch failed (el proxy del backend no pudo conectar con GitHub; "
                "comprueba que el backend tenga red y acceso a api.github.com)."
            )
        raise RuntimeError(err_msg)
    data = payload.get("data")
    return data if isinstance(data, dict) else {}


def _github_request(method: str, path: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
    """
    POST/PATCH/PUT/DELETE vía githubApiRequest.
    Devuelve el cuerpo JSON de la respuesta. Lanza RuntimeError si falla.
    """
    # githubApiRequest devuelve AWSJSON (escalar); no se puede sub-seleccionar
    mutation = """
    mutation GithubApiRequest($method: String!, $path: String!, $body: AWSJSON) {
      githubApiRequest(method: $method, path: $path, body: $body)
    }
    """
    variables: dict[str, Any] = {"method": method, "path": path}
    if body is not None:
        variables["body"] = body
    result = graphql_request(mutation, variables=variables)
    errors = result.get("errors")
    if errors:
        msg = errors[0].get("message", str(errors))
        if str(msg).strip().lower() == "fetch failed":
            msg = (
                "fetch failed (el proxy del backend no pudo conectar con GitHub; "
                "comprueba que el backend tenga red y acceso a api.github.com)."
            )
        raise RuntimeError(msg)
    raw = (result.get("data") or {}).get("githubApiRequest")
    if raw is None:
        raise RuntimeError("Respuesta sin githubApiRequest")
    try:
        payload = _parse_aws_json(raw)
    except RuntimeError:
        raise
    if not payload.get("ok"):
        status = payload.get("statusCode", "?")
        data = payload.get("data")
        err_msg = str(data) if data is not None else f"HTTP {status}"
        if err_msg.strip().lower() == "fetch failed":
            err_msg = (
                "fetch failed (el proxy del backend no pudo conectar con GitHub; "
                "comprueba que el backend tenga red y acceso a api.github.com)."
            )
        raise RuntimeError(err_msg)
    data = payload.get("data")
    return data if isinstance(data, dict) else {}


def get_workflow_runs(
    owner: str,
    repo: str,
    workflow_file: str,
    per_page: int = 20,
) -> list[dict[str, Any]]:
    """
    Lista los workflow runs: primero resuelve el workflow id por nombre de archivo,
    luego GET workflow runs. Usa githubApiGet (API Graph = proxy backend).
    """
    # 1) Listar workflows y obtener id del que coincide con workflow_file
    path_workflows = f"/repos/{owner}/{repo}/actions/workflows"
    workflows_res = _github_get(path_workflows)
    workflow_id: int | None = None
    for w in workflows_res.get("workflows") or []:
        if (w.get("path") or "").endswith(workflow_file):
            workflow_id = w.get("id")
            break
    if not workflow_id:
        return []

    # 2) Listar runs de ese workflow
    path_runs = f"/repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs?per_page={per_page}"
    runs_res = _github_get(path_runs)
    runs = runs_res.get("workflow_runs") or []
    return runs if isinstance(runs, list) else []


def get_run_jobs(owner: str, repo: str, run_id: int) -> list[dict[str, Any]]:
    """
    Lista los jobs de un run (para progreso). Usa githubApiGet.
    """
    path = f"/repos/{owner}/{repo}/actions/runs/{run_id}/jobs"
    res = _github_get(path)
    jobs = res.get("jobs") or []
    return jobs if isinstance(jobs, list) else []


def trigger_workflow_dispatch(
    owner: str,
    repo: str,
    ref: str,
    workflow_file: str,
    inputs: dict[str, str],
) -> tuple[bool, str]:
    """
    Dispara workflow_dispatch vía githubApiRequest (POST).
    Devuelve (success, message).
    """
    path = f"/repos/{owner}/{repo}/actions/workflows/{workflow_file}/dispatches"
    body = {"ref": ref, "inputs": inputs}
    try:
        _github_request("POST", path, body)
        return True, ""
    except RuntimeError as e:
        return False, str(e)
