"""
Módulo service: comandos de servicio e infraestructura (init, push, pull, sync).
Cada comando vive en su propio archivo para mantener modularidad.
"""

import typer

from corecli.service import (
    deploy_cmd,
    init_cmd,
    pull_cmd,
    push_cmd,
    status_cmd,
    sync_cmd,
)

service_app = typer.Typer(help="Comandos de servicio e infraestructura")

# Registrar comandos (uno por archivo)
init_cmd.register(service_app)
push_cmd.register(service_app)
pull_cmd.register(service_app)
sync_cmd.register(service_app)
deploy_cmd.register(service_app)
status_cmd.register(service_app)

__all__ = ["service_app"]
