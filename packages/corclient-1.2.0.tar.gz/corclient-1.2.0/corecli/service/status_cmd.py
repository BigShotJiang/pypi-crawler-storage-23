"""
Comando: cor service status
Muestra el estado de los deploys del workflow terraform-aws-build-deploy (corriendo o últimos 5).
Usa la API Graph (proxy a GitHub); requiere cor login.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, cast

import typer
from rich.console import Console
from rich.table import Table

from corecli.service._config_sync import get_repo_root
from corecli.service.deploy_cmd import (
    WORKFLOW_FILENAME,
    get_owner_repo,
    has_workflow,
)
from corecli.service.github_proxy import get_run_jobs, get_workflow_runs

console = Console()


def _step_progress(owner: str, repo: str, run_id: int) -> tuple[int, int]:
    """Devuelve (completados, total) de pasos del run vía API Graph."""
    jobs = get_run_jobs(owner, repo, run_id)
    total = 0
    completed = 0
    for job in jobs:
        steps = job.get("steps", [])
        total += len(steps)
        completed += sum(1 for s in steps if s.get("status") == "completed")
    return completed, total


def _parse_iso(s: str) -> datetime | None:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None


def _format_duration(created: datetime | None, updated: datetime | None, running: bool) -> str:
    if not created:
        return "—"
    end = updated if (updated and not running) else datetime.now(timezone.utc)
    if created.tzinfo is None:
        created = created.replace(tzinfo=timezone.utc)
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)
    delta = end - created
    total_secs = int(delta.total_seconds())
    if total_secs < 60:
        return f"{total_secs}s"
    if total_secs < 3600:
        return f"{total_secs // 60}m {total_secs % 60}s"
    return f"{total_secs // 3600}h {(total_secs % 3600) // 60}m"


def _run_status(run: dict[str, Any]) -> str:
    status = run.get("status", "")
    conclusion = run.get("conclusion") or ""
    if status in ("queued", "in_progress"):
        return cast(str, status)
    return cast(str, conclusion or status)


def register(app: typer.Typer) -> None:
    @app.command("status")
    def status(
        service: str | None = typer.Option(  # noqa: B008
            None,
            "--service",
            help="Repositorio como owner/repo (por defecto: repo actual si tiene el workflow).",
        ),
    ):
        """Estado de los deploys: corriendo (con progreso) o últimos 5 completados (duración y resultado)."""
        repo_root = get_repo_root()
        owner: str | None = None
        repo_name: str | None = None
        if service and "/" in service:
            owner, repo_name = service.strip().split("/", 1)
        else:
            orp = get_owner_repo(repo_root)
            if orp and has_workflow(repo_root):
                owner, repo_name = orp
            else:
                console.print(
                    "[red]✖[/red] No se detectó repo con el workflow. Use --service owner/repo."
                )
                raise SystemExit(1)

        assert owner and repo_name
        try:
            runs = get_workflow_runs(owner, repo_name, WORKFLOW_FILENAME)
        except RuntimeError as e:
            console.print(f"[red]✖[/red] {e}")
            raise SystemExit(1) from e
        running = [r for r in runs if r.get("status") in ("queued", "in_progress")]
        completed = [r for r in runs if r.get("status") == "completed"][:5]

        if running:
            table = Table(
                title=f"Deploys en curso — {owner}/{repo_name}",
                show_header=True,
                header_style="bold cyan",
            )
            table.add_column("Workflow", style="dim")
            table.add_column("ID", style="cyan")
            table.add_column("Lleva", justify="right")
            table.add_column("Progreso", justify="right")
            for run in running:
                name = run.get("name") or run.get("display_title") or WORKFLOW_FILENAME
                run_id = run.get("id", "")
                run_url = f"https://github.com/{owner}/{repo_name}/actions/runs/{run_id}"
                created = _parse_iso(run.get("created_at", ""))
                running_for = _format_duration(created, None, running=True)
                run_id_int = int(run["id"]) if isinstance(run["id"], str) else run["id"]
                completed_steps, total_steps = _step_progress(owner, repo_name, run_id_int)
                pct = (100 * completed_steps // total_steps) if total_steps else 0
                table.add_row(
                    name,
                    f"[link={run_url}]{run_id}[/link]",
                    running_for,
                    f"{pct}%",
                )
            console.print(table)
            console.print()
            return

        if not completed:
            console.print("[dim]No hay runs recientes del workflow.[/dim]\n")
            return

        table = Table(
            title=f"Últimos 5 deploys — {owner}/{repo_name}",
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("Workflow", style="dim")
        table.add_column("ID", style="cyan")
        table.add_column("Duración", justify="right")
        table.add_column("Estado", justify="center")
        for run in completed:
            name = run.get("name") or run.get("display_title") or WORKFLOW_FILENAME
            run_id = run.get("id", "")
            run_url = f"https://github.com/{owner}/{repo_name}/actions/runs/{run_id}"
            created = _parse_iso(run.get("created_at", ""))
            updated = _parse_iso(run.get("updated_at", ""))
            duration = _format_duration(created, updated, running=False)
            conclusion = (run.get("conclusion") or "unknown").lower()
            if conclusion == "success":
                status_str = "[green]success[/green]"
            elif conclusion == "failure":
                status_str = "[red]failed[/red]"
            else:
                status_str = f"[dim]{conclusion}[/dim]"
            table.add_row(
                name,
                f"[link={run_url}]{run_id}[/link]",
                duration,
                status_str,
            )
        console.print(table)
        console.print()
