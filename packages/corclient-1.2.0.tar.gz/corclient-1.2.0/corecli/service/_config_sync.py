"""
Lógica compartida para push/pull/sync de config (S3 ↔ .infra/ProjectCORTeam).
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from rich.console import Console

console = Console()

# S3 / AWS
AWS_REGION = "us-east-2"
AWS_PROFILE = "cor-infra"
S3_BUCKET = "cor-infra-us-east-2-services-configs"
S3_PREFIX = "ProjectCORTeam"  # full path: s3://bucket/ProjectCORTeam/

# tfvars
ACCOUNT_IDS = {
    "prod": "228470217310",
    "staging": "175965032279",
    "security": "379257709427",
    "shared": "170071165762",
    "cicd": "882729272159",
    "infra": "583588181265",
}
TERRAFORM_ROLE_NAME = "projectcor-aws-organizations"


def _run(
    cmd: list[str], cwd: Path | None = None, check: bool = True
) -> subprocess.CompletedProcess:
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if check and result.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}\n{result.stderr or result.stdout}")
    return result


def get_repo_root(cwd: Path | None = None) -> Path:
    """Raíz del repo git actual (donde se ejecuta el comando)."""
    base = Path(cwd or os.getcwd()).resolve()
    try:
        r = _run(["git", "rev-parse", "--show-toplevel"], cwd=base)
        return Path(r.stdout.strip())
    except (RuntimeError, FileNotFoundError):
        return base


def local_config_dir(repo_root: Path) -> Path:
    return repo_root / ".infra" / "ProjectCORTeam"


def resolve_local_file(
    repo_root: Path,
    config_path: str | None = None,
    service_name: str | None = None,
) -> Path | None:
    """
    Resuelve el archivo JSON local a usar.
    Prioridad: config_path > service_name (> .infra/ProjectCORTeam/<name>.json) > auto (un solo JSON).
    """
    ldir = local_config_dir(repo_root)
    if config_path:
        p = Path(config_path)
        if not p.is_absolute():
            p = (Path.cwd() / p).resolve()
        if not p.exists():
            p = repo_root / config_path
        if p.is_file():
            return p
        if (ldir / config_path).is_file():
            return ldir / config_path
        return None
    if service_name:
        name = service_name if service_name.endswith(".json") else f"{service_name}.json"
        candidate = ldir / name
        return candidate if candidate.is_file() else None
    # Auto: un solo JSON en .infra/ProjectCORTeam
    jsons = list(ldir.glob("*.json")) if ldir.exists() else []
    if len(jsons) == 1:
        return jsons[0]
    if len(jsons) > 1:
        return None  # caller can use choose_interactive
    return None


def list_local_jsons(repo_root: Path) -> list[Path]:
    """Lista todos los JSON en .infra/ProjectCORTeam."""
    ldir = local_config_dir(repo_root)
    if not ldir.exists():
        return []
    return sorted(ldir.glob("*.json"))


def choose_local_json_interactive(repo_root: Path) -> Path | None:
    """Si hay varios JSON, pide elegir por teclado."""
    items = list_local_jsons(repo_root)
    if not items:
        return None
    if len(items) == 1:
        return items[0]
    if not sys.stdin.isatty():
        return None
    console.print(f"\n[dim]Múltiples archivos en {local_config_dir(repo_root)}:[/dim]")
    for i, p in enumerate(items, 1):
        console.print(f"  [cyan]{i}[/cyan] {p.name}")
    while True:
        try:
            choice = input("Seleccione número (o 'q' salir): ").strip()
        except (EOFError, KeyboardInterrupt):
            return None
        if choice.lower() == "q":
            return None
        if choice.isdigit() and 1 <= int(choice) <= len(items):
            return items[int(choice) - 1]
        console.print("[yellow]Selección inválida.[/yellow]")


def get_remote_json_names() -> list[str]:
    """Lista nombres de archivos .json en S3 prefix."""
    try:
        r = _run(
            [
                "aws",
                "s3",
                "ls",
                f"s3://{S3_BUCKET}/{S3_PREFIX}/",
                "--profile",
                AWS_PROFILE,
                "--region",
                AWS_REGION,
            ]
        )
    except RuntimeError:
        return []
    names = []
    for line in r.stdout.strip().splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[-1].endswith(".json"):
            names.append(parts[-1])
    return names


def choose_remote_json_interactive() -> str | None:
    """Si hay varios en S3, pide elegir."""
    names = get_remote_json_names()
    if not names:
        return None
    if len(names) == 1:
        return names[0]
    if not sys.stdin.isatty():
        return None
    console.print(f"\n[dim]Múltiples archivos en s3://{S3_BUCKET}/{S3_PREFIX}/:[/dim]")
    for i, n in enumerate(names, 1):
        console.print(f"  [cyan]{i}[/cyan] {n}")
    while True:
        try:
            choice = input("Seleccione número (o 'q' salir): ").strip()
        except (EOFError, KeyboardInterrupt):
            return None
        if choice.lower() == "q":
            return None
        if choice.isdigit() and 1 <= int(choice) <= len(names):
            return names[int(choice) - 1]
        console.print("[yellow]Selección inválida.[/yellow]")


def generate_tfvars(json_path: Path, repo_root: Path) -> None:
    """Genera .infra/terraform/terraform.auto.tfvars.json desde el JSON de config."""
    with open(json_path, encoding="utf-8") as f:
        config = json.load(f)
    try:
        r = _run(["git", "rev-parse", "HEAD"], cwd=repo_root)
        sha = r.stdout.strip()[:7]
    except RuntimeError:
        sha = ""
    new_env = os.environ.get("NEW_ENV", "false").lower() in ("1", "true", "yes")
    config["commit_id"] = sha
    config["account_id_list"] = ACCOUNT_IDS
    config["terraform_role_name"] = TERRAFORM_ROLE_NAME
    config["github_token"] = os.environ.get("COR_GITHUB_TOKEN", "")
    for env in config.get("env_settings") or []:
        if isinstance(env, dict):
            env["new_env"] = new_env
    out = repo_root / ".infra" / "terraform" / "terraform.auto.tfvars.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)
    console.print("[green]✔[/green] Generado: .infra/terraform/terraform.auto.tfvars.json")


def aws_s3_cp(src: str, dest: str) -> None:
    """Ejecuta aws s3 cp con perfil y región."""
    _run(
        [
            "aws",
            "s3",
            "cp",
            src,
            dest,
            "--profile",
            AWS_PROFILE,
            "--region",
            AWS_REGION,
        ]
    )


def resolve_for_push(
    repo_root: Path,
    config_path: str | None,
    service_name: str | None,
) -> Path | None:
    """Resuelve el archivo local a subir; si hay varios y no se especificó, pide elegir."""
    out = resolve_local_file(repo_root, config_path, service_name)
    if out is not None:
        return out
    return choose_local_json_interactive(repo_root)


def resolve_for_pull(
    repo_root: Path,
    config_path: str | None,
    service_name: str | None,
) -> tuple[str, Path]:
    """
    Devuelve (s3_filename, local_path) para pull.
    """
    ldir = local_config_dir(repo_root)
    ldir.mkdir(parents=True, exist_ok=True)
    result_name: str
    if config_path:
        p = Path(config_path)
        result_name = p.name if p.suffix == ".json" else f"{p.name}.json"
        local_file = p if p.is_absolute() and p.parent.exists() else ldir / result_name
    elif service_name:
        result_name = service_name if service_name.endswith(".json") else f"{service_name}.json"
        local_file = ldir / result_name
    else:
        remotes = get_remote_json_names()
        if len(remotes) == 1:
            result_name = remotes[0]
            local_file = ldir / result_name
        else:
            chosen = choose_remote_json_interactive()
            if not chosen:
                raise SystemExit(1)
            result_name = chosen
            local_file = ldir / result_name
    return result_name, Path(local_file)
