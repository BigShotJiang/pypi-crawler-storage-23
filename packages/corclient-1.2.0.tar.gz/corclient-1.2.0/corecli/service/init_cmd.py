"""
Comando: cor service init
Inicializa un servicio usando plantillas de infra-service-templates.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import typer
from rich.console import Console

console = Console()

# Defaults (overridable via env)
DEFAULT_REPO_URL = "git@github.com:ProjectCORTeam/infra-service-templates.git"
DEFAULT_BRANCH = "master"
DEFAULT_SUBDIR = "templates"
DEFAULT_DEPLOYMENT_TYPE = "eks"
ACCOUNT_IDS = {
    "prod": "228470217310",
    "staging": "175965032279",
    "security": "379257709427",
    "shared": "170071165762",
    "cicd": "882729272159",
    "infra": "583588181265",
}
TERRAFORM_ROLE_NAME = "projectcor-aws-organizations"
NOTIFICATION_EMAIL = "cloud@projectcor.com"


def _run(
    cmd: list[str], cwd: Path | None = None, check: bool = True
) -> subprocess.CompletedProcess:
    """Run command; raises on failure if check=True."""
    result = subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if check and result.returncode != 0:
        raise RuntimeError(
            f"Command failed: {' '.join(cmd)}\nstderr: {result.stderr or result.stdout}"
        )
    return result


def _get_github_sha(repo_path: Path) -> str:
    """Return short commit SHA (7 chars) for repo_path."""
    r = _run(["git", "rev-parse", "HEAD"], cwd=repo_path)
    out: str = r.stdout.strip()
    return out[:7] if out else ""


def _run_init(
    service_name: str,
    service_type: str = "ms",
    service_owner: str = "cloud-solutions",
    repo_url: str | None = None,
    branch: str | None = None,
    subdir: str | None = None,
    deployment_type: str | None = None,
    dest_dir: Path | None = None,
) -> None:
    """Lógica de inicialización con plantillas de infra-service-templates."""
    repo_path = Path(dest_dir or os.getcwd()).resolve()
    repo_url_str: str = repo_url or os.environ.get("REPO_URL", "") or DEFAULT_REPO_URL
    branch_str: str = branch or os.environ.get("BRANCH", "") or DEFAULT_BRANCH
    subdir_str: str = subdir or os.environ.get("SUBDIR", "") or DEFAULT_SUBDIR
    deployment_type_str: str = (
        deployment_type or os.environ.get("DEPLOYMENT_TYPE", "") or DEFAULT_DEPLOYMENT_TYPE
    )
    temporal = repo_path / "temporal"
    s3_config = (
        f"s3://cor-infra-us-east-2-services-configs/ProjectCORTeam/"
        f"{service_type}-{service_name}.json"
    )
    target_config_file = (
        repo_path / ".infra" / "ProjectCORTeam" / f"{service_type}-{service_name}.json"
    )

    console.print("\n[bold blue]▶ Configuración[/bold blue]")
    console.print(f"  [dim]Service name:      {service_name}[/dim]")
    console.print(f"  [dim]Service type:      {service_type}[/dim]")
    console.print(f"  [dim]Service owner:     {service_owner}[/dim]")
    console.print(f"  [dim]Deployment type:   {deployment_type_str}[/dim]")
    console.print(f"  [dim]Local repo path:   {repo_path}[/dim]")
    console.print(f"  [dim]Repo url:          {repo_url_str}[/dim]")
    console.print(f"  [dim]Branch:            {branch_str}[/dim]")
    console.print(f"  [dim]Subdir:            {subdir_str}[/dim]")
    console.print(f"  [dim]Destino temporal:  {temporal}[/dim]")
    console.print(f"  [dim]S3 config file:    {s3_config}[/dim]")

    temporal.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        repo_clone = tmp_path / "repo"

        console.print("\n[bold blue]▶ Clonado con sparse checkout[/bold blue]")
        console.print("  [cyan]•[/cyan] Clonando repositorio (depth=1, filter=blob:none, sparse)")
        try:
            _run(
                [
                    "git",
                    "clone",
                    "--depth=1",
                    "--filter=blob:none",
                    "--sparse",
                    repo_url_str,
                    str(repo_clone),
                ]
            )
        except RuntimeError as e:
            console.print("[red]✖ Error al clonar el repositorio. Verifica acceso SSH/URL.[/red]")
            console.print(f"[dim]{e}[/dim]")
            raise SystemExit(1) from e

        try:
            _run(["git", "rev-parse", "--verify", f"origin/{branch_str}"], cwd=repo_clone)
            _run(["git", "switch", "--detach", f"origin/{branch_str}"], cwd=repo_clone)
        except RuntimeError:
            console.print(
                f"  [yellow]⚠ La rama '{branch_str}' no existe. Usando rama por defecto.[/yellow]"
            )

        try:
            _run(["git", "sparse-checkout", "set", subdir_str], cwd=repo_clone)
        except RuntimeError as e:
            console.print(
                f"[red]✖ La subcarpeta '{subdir_str}' no existe en la rama seleccionada.[/red]"
            )
            raise SystemExit(1) from e

        src_subdir = repo_clone / subdir_str
        if not src_subdir.exists():
            console.print(f"[red]✖ No se encontró {subdir_str}/ en el clone.[/red]")
            raise SystemExit(1)

        console.print(f"  [cyan]•[/cyan] Copiando contenido a '{temporal}'")
        if shutil.which("rsync"):
            _run(["rsync", "-a", f"{src_subdir}/", f"{temporal}/"])
        else:
            for item in src_subdir.iterdir():
                dest = temporal / item.name
                if item.is_dir():
                    shutil.copytree(item, dest, dirs_exist_ok=True)
                else:
                    shutil.copy2(item, dest)

    console.print("[green]  ✔[/green] Descarga completada")
    console.print("  [dim]Listado parcial de destino:[/dim]")
    for p in sorted(temporal.iterdir())[:20]:
        console.print(f"    [dim]{p.name}[/dim]")
    if sum(1 for _ in temporal.iterdir()) > 20:
        console.print("    [dim]...[/dim]")

    console.print("\n[bold blue]▶ Copiado de artefactos al repo[/bold blue]")
    (repo_path / ".infra" / "terraform").mkdir(parents=True, exist_ok=True)
    (repo_path / ".infra" / "kubernetes").mkdir(parents=True, exist_ok=True)
    (repo_path / ".infra" / "cicd").mkdir(parents=True, exist_ok=True)
    (repo_path / ".infra" / "ProjectCORTeam").mkdir(parents=True, exist_ok=True)

    cicd_src = temporal / "cicd"
    simple_base = temporal / "simple-service-persistence"
    simple_deploy = simple_base / f"simple-{deployment_type_str}"

    if not simple_deploy.exists():
        console.print(
            f"[red]✖ No existe plantilla simple-{deployment_type_str} (kubernetes/cicd).[/red]"
        )
        raise SystemExit(1)

    shutil.copy2(cicd_src / ".releaserc.json", repo_path / ".releaserc.json")
    shutil.copy2(cicd_src / ".pre-commit-config.yaml", repo_path / ".pre-commit-config.yaml")
    gh_src = cicd_src / ".github"
    gh_dst = repo_path / ".github"
    if gh_src.exists():
        if gh_dst.exists():
            shutil.rmtree(gh_dst)
        shutil.copytree(gh_src, gh_dst)
    for src_dir, dst_dir in [
        (simple_base / "base" / "terraform", repo_path / ".infra" / "terraform"),
        (simple_deploy / "kubernetes", repo_path / ".infra" / "kubernetes"),
        (simple_deploy / "cicd", repo_path / ".infra" / "cicd"),
    ]:
        if not src_dir.exists():
            continue
        for item in src_dir.iterdir():
            dest_item = dst_dir / item.name
            if item.is_dir():
                if dest_item.exists():
                    shutil.rmtree(dest_item)
                shutil.copytree(item, dest_item)
            else:
                shutil.copy2(item, dest_item)

    target_config_file.parent.mkdir(parents=True, exist_ok=True)
    console.print("\n[bold blue]▶ Configuración del servicio[/bold blue]")
    console.print("  [cyan]•[/cyan] Descargando config desde S3 si existe")
    try:
        _run(
            [
                "aws",
                "s3",
                "cp",
                s3_config,
                str(target_config_file),
                "--profile",
                "cor-infra",
            ]
        )
        console.print(f"  [green]✔[/green] Config descargado desde S3 → {target_config_file.name}")
    except RuntimeError:
        console.print(
            "  [yellow]⚠ No se encontró en S3 o error de acceso. Generando config desde template.[/yellow]"
        )
        template_config = simple_deploy / "infra-config.json"
        if not template_config.exists():
            console.print(f"[red]✖ No existe {template_config}[/red]")
            raise SystemExit(1) from None
        shutil.copy2(template_config, target_config_file)

    console.print("\n[bold blue]▶ Reemplazos de variables[/bold blue]")
    infra_dir = repo_path / ".infra"
    replacements = [
        ("$TEMPLATE_SERVICE_TYPE", service_type),
        ("$TEMPLATE_SERVICE_NAME", service_name),
        ("$TEMPLATE_SERVICE_OWNER_TEAM", service_owner),
        ("$TEMPLATE_SERVICE_NOTIFICATION_EMAIL_LIST", NOTIFICATION_EMAIL),
    ]
    for root, _dirs, files in os.walk(infra_dir):
        for name in files:
            path = Path(root) / name
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            new_text = text
            for placeholder, value in replacements:
                new_text = new_text.replace(placeholder, value)
            if new_text != text:
                path.write_text(new_text, encoding="utf-8")
    console.print("  [green]✔[/green] Reemplazos completados")

    new_env = os.environ.get("NEW_ENV", "true").lower() in ("1", "true", "yes")
    github_sha = _get_github_sha(repo_path)
    github_token = os.environ.get("COR_GITHUB_TOKEN", "")

    with open(target_config_file, encoding="utf-8") as f:
        config = json.load(f)
    config["commit_id"] = github_sha
    config["account_id_list"] = ACCOUNT_IDS
    config["terraform_role_name"] = TERRAFORM_ROLE_NAME
    config["github_token"] = github_token
    env_settings = config.get("env_settings") or []
    for env in env_settings:
        if isinstance(env, dict):
            env["new_env"] = new_env
    config["env_settings"] = env_settings

    tfvars_path = repo_path / ".infra" / "terraform" / "terraform.auto.tfvars.json"
    with open(tfvars_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)
    console.print(
        "\n[green]✔[/green] Archivo generado: .infra/terraform/terraform.auto.tfvars.json"
    )

    console.print("\n[bold blue]▶ Limpieza[/bold blue]")
    if temporal.exists():
        shutil.rmtree(temporal)
    console.print("  [green]✔[/green] Directorio temporal eliminado")
    console.print()


def register(app: typer.Typer) -> None:
    """Registra el comando init en la app de service."""

    @app.command("init")
    def init(
        service_name: str = typer.Argument(..., help="Nombre del servicio a inicializar"),
        service_type: str = typer.Option(
            "ms", "--type", "-t", help="Tipo de servicio (default: ms)"
        ),
        service_owner: str = typer.Option(
            "cloud-solutions",
            "--owner",
            "-o",
            help="Equipo propietario (default: cloud-solutions)",
        ),
        repo_url: str | None = typer.Option(
            None,
            "--repo-url",
            help="URL del repo de plantillas (default: infra-service-templates)",
        ),
        branch: str | None = typer.Option(
            None, "--branch", "-b", help="Rama del repo (default: master)"
        ),
        deployment_type: str | None = typer.Option(
            None,
            "--deployment",
            "-d",
            help="Tipo de despliegue, ej. eks (default: desde env DEPLOYMENT_TYPE o eks)",
        ),
        cwd: str | None = typer.Option(
            None,
            "--cwd",
            help="Directorio del repo donde inicializar (default: directorio actual)",
        ),
    ):
        """Inicializa un servicio con plantillas de infra-service-templates (clona repo, copia .infra, aplica variables)."""
        dest: Path | None = None if cwd is None else Path(cwd).resolve()
        _run_init(
            service_name=service_name,
            service_type=service_type,
            service_owner=service_owner,
            repo_url=repo_url,
            branch=branch,
            deployment_type=deployment_type,
            dest_dir=dest,
        )
