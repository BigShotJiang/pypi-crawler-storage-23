"""
Comando: cor service push
Sube el JSON de config local a S3.
"""

from __future__ import annotations

import sys

import typer
from rich.console import Console

from corecli.service._config_sync import (
    S3_BUCKET,
    S3_PREFIX,
    aws_s3_cp,
    get_repo_root,
    resolve_for_push,
)

console = Console()


def register(app: typer.Typer) -> None:
    @app.command("push")
    def push(
        service: str | None = typer.Option(
            None,
            "--service",
            "-s",
            help="Nombre del servicio (archivo .infra/ProjectCORTeam/<service>.json)",
        ),
        config: str | None = typer.Option(
            None,
            "--config",
            "-c",
            help="Ruta al JSON local a subir",
        ),
        yes: bool = typer.Option(
            False,
            "--yes",
            "-y",
            help="No pedir confirmación al subir",
        ),
    ):
        """Sube el JSON de config del servicio a S3 (cor-infra)."""
        repo_root = get_repo_root()
        src = resolve_for_push(repo_root, config, service)
        if not src or not src.is_file():
            console.print(
                "[red]✖[/red] No se encontró archivo JSON. Use --config PATH o --service NAME."
            )
            raise SystemExit(1)
        dest_s3 = f"s3://{S3_BUCKET}/{S3_PREFIX}/{src.name}"
        console.print("\n[bold blue]▶ Subiendo archivo[/bold blue]")
        console.print(f"  [dim]Local: {src}[/dim]")
        console.print(f"  [dim]S3:    {dest_s3}[/dim]")
        if not yes and sys.stdin.isatty():
            try:
                reply = input("¿Confirmar? [Y/n]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                raise SystemExit(0) from None
            if reply and reply not in ("y", "yes"):
                console.print("Operación cancelada.")
                raise SystemExit(0)
        aws_s3_cp(str(src), dest_s3)
        console.print("[green]✔[/green] Subida completada\n")
