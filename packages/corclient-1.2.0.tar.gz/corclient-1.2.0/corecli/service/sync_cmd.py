"""
Comando: cor service sync
Regenera terraform.auto.tfvars.json desde el JSON de config local (sin S3).
"""

from __future__ import annotations

import typer
from rich.console import Console

from corecli.service._config_sync import (
    choose_local_json_interactive,
    generate_tfvars,
    get_repo_root,
    resolve_local_file,
)

console = Console()


def register(app: typer.Typer) -> None:
    @app.command("sync")
    def sync(
        service: str | None = typer.Option(
            None,
            "--service",
            "-s",
            help="Nombre del servicio (archivo .infra/ProjectCORTeam/<service>.json)",
        ),
        config: str | None = typer.Option(
            None,
            "--config",
            "-c",
            help="Ruta al JSON local",
        ),
    ):
        """Regenera .infra/terraform/terraform.auto.tfvars.json desde el JSON de config local."""
        repo_root = get_repo_root()
        json_path = resolve_local_file(repo_root, config, service)
        if json_path is None:
            json_path = choose_local_json_interactive(repo_root)
        if not json_path or not json_path.is_file():
            console.print(
                "[red]✖[/red] No se encontró archivo JSON. Use --config PATH o --service NAME."
            )
            raise SystemExit(1)
        console.print("\n[bold blue]▶ Generando terraform.auto.tfvars.json[/bold blue]")
        console.print(f"  [dim]Fuente: {json_path}[/dim]")
        generate_tfvars(json_path, repo_root)
        console.print()
