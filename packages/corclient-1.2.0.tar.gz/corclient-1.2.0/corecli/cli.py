from typing import Optional

import typer

from corecli import auth, companybackup, service

app = typer.Typer(help="CoreCLI - CLI de ejemplo con login en Cognito usando PKCE")

# Sub-app: companybackup
companybackup_app = typer.Typer(help="Solicitar y consultar backups de compañía")
app.add_typer(companybackup_app, name="companybackup")

# Sub-app: service (init, push, pull, etc.)
app.add_typer(service.service_app, name="service")


@app.command()
def login(
    app_redirect: Optional[str] = typer.Option(
        None,
        "--app-redirect",
        "-r",
        help="URL o esquema (p.ej. myapp://callback) al que redirigir tras login",
    ),
):
    """Inicia el flujo de autenticación con Cognito (Hosted UI + PKCE)."""
    auth.login(app_redirect=app_redirect)


@app.command()
def refresh():
    """Refresca los tokens usando refresh_token guardado."""
    auth.refresh_tokens()


@app.command()
def whoami():
    """Muestra información del usuario autenticado (id_token)."""
    auth.whoami()


@app.command()
def logout():
    """Cierra sesión local (revoca/borrado de tokens)."""
    auth.logout()


# ---------- companybackup ----------
@companybackup_app.command("create")
def companybackup_create(
    domain: str = typer.Option(..., "--domain", "-d", help="Dominio de la compañía a respaldar"),
    notify_to: str = typer.Option(
        "",
        "--notifyTo",
        "--notify-to",
        "-n",
        help="Emails a notificar (separados por coma): mail1,mail2",
    ),
):
    """Crea una solicitud de backup para el dominio indicado."""
    emails = [e.strip() for e in notify_to.split(",")] if notify_to else []
    companybackup.create(domain=domain, notify_to=emails)


@companybackup_app.command("get")
def companybackup_get(
    domain: str = typer.Option(..., "--domain", "-d", help="Dominio de la compañía"),
):
    """Muestra estado y progreso del backup más reciente para el dominio."""
    companybackup.get(domain=domain)


@companybackup_app.command("list")
def companybackup_list(
    status: Optional[str] = typer.Option(
        None,
        "--status",
        "-s",
        help="Filtrar por estado (opcional): PENDING, IN_PROGRESS, FINISHED, FAILED. Por defecto trae todas.",
    ),
    limit: int = typer.Option(5, "--limit", "-l", help="Número máximo de registros (default: 5)"),
):
    """Lista solicitudes de backup (por defecto todas; orden cronológico)."""
    companybackup.list_requests(status=status, limit=limit)


def main():
    """Compatibilidad: permite ejecutar como 'python -m corecli.cli' o entrypoint antiguo."""
    app()
