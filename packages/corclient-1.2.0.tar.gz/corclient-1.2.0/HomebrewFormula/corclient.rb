class Corclient < Formula
  include Language::Python::Virtualenv

  desc "Internal CLI tool for microservices management and infrastructure administration"
  homepage "https://github.com/ProjectCORTeam/corcli"
  url "https://files.pythonhosted.org/packages/source/c/corclient/corclient-1.1.1.tar.gz"
  sha256 "0cbe98ad0f61a0fe575b11e1f299940964a16f7bc340b8a33f8e9d5bf531ff04"
  license "MIT"

  depends_on "python@3.11"

  resource "typer" do
    url "https://files.pythonhosted.org/packages/source/t/typer/typer-0.12.5.tar.gz"
    sha256 "f592f089bedcc8ec1b974125d64851029c3b1af145f04aca64d69410f0c9b722"
  end

  resource "rich" do
    url "https://files.pythonhosted.org/packages/source/r/rich/rich-13.7.1.tar.gz"
    sha256 "9be308cb1fe2f1f57d67ce99e95af38a1e2bc71ad9813b0e247cf7ffbcc3a432"
  end

  resource "click" do
    url "https://files.pythonhosted.org/packages/source/c/click/click-8.1.7.tar.gz"
    sha256 "ca9853ad459e787e2192211578cc907e7594e294c7ccc834310722b41b9ca6de"
  end

  resource "flask" do
    url "https://files.pythonhosted.org/packages/source/f/flask/flask-3.0.3.tar.gz"
    sha256 "ceb27b0af3823ea2737928a4d99d125a06175b8512c445cbd9a9ce200ef76842"
  end

  resource "requests" do
    url "https://files.pythonhosted.org/packages/source/r/requests/requests-2.31.0.tar.gz"
    sha256 "942c5a758f98d790eaed1a29cb6eefc7ffb0d1cf7af05c3d2791656dbd6ad1e1"
  end

  def install
    virtualenv_install_with_resources
  end

  test do
    assert_match "CoreCLI", shell_output("#{bin}/cor --help")
  end
end
