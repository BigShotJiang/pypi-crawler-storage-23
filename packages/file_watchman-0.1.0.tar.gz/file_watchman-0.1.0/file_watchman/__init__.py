"""file-watchman: Work directory manifest and delta library."""

__version__ = "0.1.0"

from file_watchman.diff import diff_manifests
from file_watchman.io import dump_manifest, load_manifest, write_manifest_atomic
from file_watchman.model import Delta, Manifest, ManifestEntry
from file_watchman.rules import HashPolicy, ScanRules
from file_watchman.scan import scan_manifest

__all__ = [
    "Delta",
    "HashPolicy",
    "Manifest",
    "ManifestEntry",
    "ScanRules",
    "diff_manifests",
    "dump_manifest",
    "load_manifest",
    "scan_manifest",
    "write_manifest_atomic",
]
