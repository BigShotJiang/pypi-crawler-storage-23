"""Scan rules, hash policy, and categorization helpers."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from file_watchman.utils import matches_glob


@dataclass
class ScanRules:
    """Configuration controlling which files are discovered during a scan."""

    includes: list[str] = field(default_factory=lambda: ["**/*"])
    excludes: list[str] = field(default_factory=list)
    follow_symlinks: bool = False
    max_files: int = 50_000
    max_depth: int | None = None
    include_dirs: bool = False


@dataclass
class HashPolicy:
    """Configuration controlling when SHA-256 hashes are computed."""

    required_categories: set[str] = field(default_factory=set)
    optional_categories: set[str] = field(default_factory=set)
    never_categories: set[str] = field(default_factory=set)
    max_hash_bytes: int = 512 * 1024 * 1024
    chunk_size: int = 8 * 1024 * 1024


def should_hash(category: str, size: int, policy: HashPolicy) -> bool:
    """Decide whether a file should be hashed based on its category and size."""
    if category in policy.required_categories:
        return True
    if category in policy.never_categories:
        return False
    if category in policy.optional_categories:
        return size <= policy.max_hash_bytes
    # Default: do not hash
    return False


def make_categorizer(
    rules: list[tuple[str, str]],
) -> Callable[[str], str]:
    """Build a first-match-wins categorizer from a list of (glob, category) rules.

    Returns a callable that maps a relative path to a category string.
    Defaults to ``"other"`` if no rule matches.
    """

    def categorize(relpath: str) -> str:
        for pattern, category in rules:
            if matches_glob(relpath, pattern):
                return category
        return "other"

    return categorize


def default_excludes() -> list[str]:
    """Return the default list of exclude glob patterns."""
    return [
        ".git/**",
        "**/__pycache__/**",
        "**/*.tmp",
        "**/.DS_Store",
    ]
