"""Directory scanning to produce a Manifest."""

from __future__ import annotations

import os
import time
from collections.abc import Callable
from pathlib import Path

from file_watchman.hash import sha256_file
from file_watchman.model import Manifest, ManifestEntry
from file_watchman.rules import HashPolicy, ScanRules, should_hash
from file_watchman.utils import matches_glob, normalize_path


def scan_manifest(
    root: str,
    rules: ScanRules,
    hash_policy: HashPolicy,
    categorize: Callable[[str], str] | None = None,
    job_id: str | None = None,
) -> Manifest:
    """Scan *root* and return a :class:`Manifest` describing its files.

    Parameters
    ----------
    root:
        Absolute path to the directory to scan.
    rules:
        Controls which files are included/excluded, depth, etc.
    hash_policy:
        Controls which files get SHA-256 hashes.
    categorize:
        Optional callable ``(relpath) -> category``.  Defaults to
        returning ``"other"`` for every file.
    job_id:
        Optional job identifier stored in the manifest.
    """
    if categorize is None:
        categorize = lambda relpath: "other"  # noqa: E731

    abs_root = str(Path(root).resolve())
    entries: list[ManifestEntry] = []

    for relpath in _discover_files(abs_root, rules):
        abs_path = os.path.join(abs_root, relpath)

        try:
            st = os.stat(abs_path, follow_symlinks=rules.follow_symlinks)
        except OSError:
            continue

        if not rules.include_dirs and not os.path.isfile(abs_path):
            continue

        size = st.st_size
        mtime = st.st_mtime
        category = categorize(relpath)

        sha: str | None = None
        if should_hash(category, size, hash_policy):
            sha = sha256_file(abs_path, chunk_size=hash_policy.chunk_size)

        entries.append(
            ManifestEntry(
                path=relpath,
                size=size,
                mtime=mtime,
                sha256=sha,
                category=category,
            )
        )

    entries.sort(key=lambda e: e.path)
    summary = _compute_summary(entries)

    return Manifest(
        created_at=time.time(),
        root=abs_root,
        entries=entries,
        summary=summary,
        job_id=job_id,
    )


def _discover_files(abs_root: str, rules: ScanRules) -> list[str]:
    """Walk *abs_root* and return relative POSIX paths matching *rules*."""
    candidates: list[str] = []

    for dirpath, dirnames, filenames in os.walk(
        abs_root, followlinks=rules.follow_symlinks
    ):
        # Compute depth relative to root
        rel_dir = os.path.relpath(dirpath, abs_root)
        if rel_dir == ".":
            depth = 0
        else:
            depth = rel_dir.count(os.sep) + 1

        # Enforce max_depth: skip files and prune subdirectories
        if rules.max_depth is not None and depth >= rules.max_depth:
            dirnames.clear()
            continue

        # Skip symlink directories when not following symlinks
        if not rules.follow_symlinks:
            dirnames[:] = [
                d for d in dirnames if not os.path.islink(os.path.join(dirpath, d))
            ]

        for name in filenames:
            abs_path = os.path.join(dirpath, name)

            # Skip symlink files when not following symlinks
            if not rules.follow_symlinks and os.path.islink(abs_path):
                continue

            relpath = normalize_path(abs_path, abs_root)

            # Apply includes: file must match at least one include pattern
            if not any(matches_glob(relpath, pat) for pat in rules.includes):
                continue

            # Apply excludes: file must not match any exclude pattern
            if any(matches_glob(relpath, pat) for pat in rules.excludes):
                continue

            candidates.append(relpath)

            # Enforce max_files
            if len(candidates) >= rules.max_files:
                return candidates

    return candidates


def _compute_summary(entries: list[ManifestEntry]) -> dict:
    """Compute summary statistics from a list of entries."""
    total_bytes = 0
    by_category: dict[str, dict[str, int]] = {}

    for entry in entries:
        total_bytes += entry.size
        cat = entry.category
        if cat not in by_category:
            by_category[cat] = {"count": 0, "bytes": 0}
        by_category[cat]["count"] += 1
        by_category[cat]["bytes"] += entry.size

    return {
        "count": len(entries),
        "total_bytes": total_bytes,
        "by_category": by_category,
    }
