"""Manifest diff — compute a Delta between two Manifests."""

from __future__ import annotations

from file_watchman.model import Delta, Manifest, ManifestEntry


def diff_manifests(prev: Manifest, new: Manifest) -> Delta:
    """Compare *prev* and *new* manifests and return a :class:`Delta`.

    Change detection cascade for entries sharing the same path:

    1. ``size`` differs → changed (reason ``"size"``)
    2. ``mtime`` differs → changed (reason ``"mtime"``)
    3. Both have ``sha256`` and they differ → changed (reason ``"sha256"``)
    4. Otherwise → unchanged

    If ``sha256`` is present in only one manifest it is **not** treated
    as a change on its own.
    """
    prev_map: dict[str, ManifestEntry] = {e.path: e for e in prev.entries}
    new_map: dict[str, ManifestEntry] = {e.path: e for e in new.entries}

    uploads: list[ManifestEntry] = []
    deletions: list[str] = []
    changed: dict[str, str] = {}

    # New and changed files
    for path, new_entry in new_map.items():
        if path not in prev_map:
            uploads.append(new_entry)
            changed[path] = "new"
            continue

        prev_entry = prev_map[path]
        reason = _change_reason(prev_entry, new_entry)
        if reason is not None:
            uploads.append(new_entry)
            changed[path] = reason

    # Deleted files
    for path in prev_map:
        if path not in new_map:
            deletions.append(path)
            changed[path] = "deleted"

    deletions.sort()

    return Delta(uploads=uploads, deletions=deletions, changed=changed)


def _change_reason(prev: ManifestEntry, new: ManifestEntry) -> str | None:
    """Return the reason two entries differ, or ``None`` if unchanged."""
    if prev.size != new.size:
        return "size"
    if prev.mtime != new.mtime:
        return "mtime"
    if prev.sha256 is not None and new.sha256 is not None:
        if prev.sha256 != new.sha256:
            return "sha256"
    return None
