"""SHA-256 streaming file hash."""

from __future__ import annotations

import hashlib

DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024  # 8 MB


def sha256_file(path: str, chunk_size: int = DEFAULT_CHUNK_SIZE) -> str:
    """Return the hex SHA-256 digest of the file at *path*.

    Reads the file in *chunk_size* byte chunks so that large files
    are never fully loaded into memory.
    """
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()
