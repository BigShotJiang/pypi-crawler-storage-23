"""Manifest I/O — serialization, deserialization, and atomic writes."""

from __future__ import annotations

import json
import os

from file_watchman.model import Manifest, ManifestEntry


def dump_manifest(manifest: Manifest) -> dict:
    """Serialize a :class:`Manifest` to a JSON-serializable dict.

    Uses manual serialization (not ``dataclasses.asdict``) for explicit
    schema control and forward/backward compatibility.
    """
    return {
        "version": manifest.version,
        "tool": manifest.tool,
        "created_at": manifest.created_at,
        "root": manifest.root,
        "job_id": manifest.job_id,
        "summary": manifest.summary,
        "entries": [
            {
                "path": e.path,
                "size": e.size,
                "mtime": e.mtime,
                "sha256": e.sha256,
                "category": e.category,
            }
            for e in manifest.entries
        ],
    }


def load_manifest(path: str) -> Manifest:
    """Load a :class:`Manifest` from a JSON file at *path*.

    Validates the version field and entry paths.  Unknown fields in the
    JSON are silently ignored for forward compatibility.
    """
    with open(path, "r") as f:
        data = json.load(f)

    version = data.get("version")
    if version != 1:
        raise ValueError(f"Unsupported manifest version: {version!r}")

    root = data.get("root", "")

    entries: list[ManifestEntry] = []
    for raw in data.get("entries", []):
        entry_path = raw["path"]
        # Validate path normalization: no absolute paths, no '..' segments
        if entry_path.startswith("/"):
            raise ValueError(f"Entry path is absolute: {entry_path!r}")
        if ".." in entry_path.split("/"):
            raise ValueError(f"Entry path contains '..': {entry_path!r}")

        entries.append(
            ManifestEntry(
                path=entry_path,
                size=raw["size"],
                mtime=raw["mtime"],
                sha256=raw.get("sha256"),
                category=raw.get("category", "other"),
            )
        )

    return Manifest(
        version=version,
        tool=data.get("tool", "file-watchman"),
        created_at=data.get("created_at", 0.0),
        root=root,
        job_id=data.get("job_id"),
        summary=data.get("summary", {}),
        entries=entries,
    )


def write_manifest_atomic(path: str, manifest: Manifest) -> None:
    """Write *manifest* to *path* atomically.

    Writes to ``path + ".tmp"``, fsyncs, then ``os.replace`` to the
    final *path*.  Both files must be on the same filesystem.
    """
    tmp_path = path + ".tmp"
    data = dump_manifest(manifest)

    with open(tmp_path, "w") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())

    os.replace(tmp_path, path)
