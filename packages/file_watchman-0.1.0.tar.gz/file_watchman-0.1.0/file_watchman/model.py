"""Core data models for file-watchman."""

from __future__ import annotations

from dataclasses import dataclass, field

VALID_CATEGORIES: frozenset[str] = frozenset(
    {"checkpoint", "restart", "log", "trajectory", "other"}
)


@dataclass(slots=True)
class ManifestEntry:
    """A single file entry in a manifest."""

    path: str
    size: int
    mtime: float
    sha256: str | None
    category: str


@dataclass
class Manifest:
    """A complete snapshot of a directory at a point in time."""

    created_at: float
    root: str
    entries: list[ManifestEntry]
    summary: dict = field(default_factory=dict)
    version: int = 1
    job_id: str | None = None
    tool: str = "file-watchman"


@dataclass
class Delta:
    """Difference between two manifests."""

    uploads: list[ManifestEntry] = field(default_factory=list)
    deletions: list[str] = field(default_factory=list)
    changed: dict = field(default_factory=dict)
