"""Path normalization and glob matching utilities."""

from __future__ import annotations

import fnmatch
import re


def normalize_path(path: str, root: str) -> str:
    """Convert *path* to a relative POSIX path under *root*.

    Raises ``ValueError`` if the result contains ``..`` segments,
    is absolute, or escapes the root directory.
    """
    # Resolve to get a canonical absolute path, then make relative to root
    from pathlib import Path

    abs_path = Path(path).resolve()
    abs_root = Path(root).resolve()

    try:
        rel = abs_path.relative_to(abs_root)
    except ValueError:
        raise ValueError(f"Path {path!r} is not under root {root!r}") from None

    posix = rel.as_posix()

    if posix.startswith("/"):
        raise ValueError(f"Normalized path is absolute: {posix!r}")
    if ".." in posix.split("/"):
        raise ValueError(f"Normalized path contains '..': {posix!r}")

    return posix


def matches_glob(relpath: str, pattern: str) -> bool:
    """Test whether *relpath* matches the glob *pattern*.

    Uses regex conversion for patterns containing ``**`` (to reliably
    handle zero-or-more directory matching on all Python versions),
    and ``fnmatch.fnmatch`` otherwise.
    """
    if "**" in pattern:
        return bool(re.fullmatch(_glob_to_regex(pattern), relpath))
    return fnmatch.fnmatch(relpath, pattern)


def _glob_to_regex(pattern: str) -> str:
    """Convert a glob *pattern* with ``**`` support to a regex string."""
    result: list[str] = []
    i = 0
    n = len(pattern)
    while i < n:
        if pattern[i : i + 2] == "**":
            result.append(".*")
            i += 2
            # A ``/`` immediately after ``**`` is made optional so that
            # ``**/x`` matches both ``x`` (zero dirs) and ``dir/x``.
            if i < n and pattern[i] == "/":
                result.append("/?")
                i += 1
        elif pattern[i] == "*":
            result.append("[^/]*")
            i += 1
        elif pattern[i] == "?":
            result.append("[^/]")
            i += 1
        else:
            result.append(re.escape(pattern[i]))
            i += 1
    return "".join(result)
