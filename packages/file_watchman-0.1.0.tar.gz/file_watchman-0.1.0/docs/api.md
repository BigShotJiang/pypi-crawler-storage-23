# API Reference

## Overview

`file-watchman` exports its public API from the top-level package:

```python
from file_watchman import (
    ManifestEntry, Manifest, Delta,
    ScanRules, HashPolicy,
    scan_manifest, diff_manifests,
    dump_manifest, load_manifest, write_manifest_atomic,
)
```

Additional helpers are available via submodule imports:

```python
from file_watchman.rules import make_categorizer, default_excludes, should_hash
from file_watchman.hash import sha256_file
from file_watchman.utils import normalize_path, matches_glob
from file_watchman.model import VALID_CATEGORIES
```

---

## Data Model (`file_watchman.model`)

### `ManifestEntry`

A single file entry in a manifest. Uses `@dataclass(slots=True)` for memory efficiency.

```python
@dataclass(slots=True)
class ManifestEntry:
    path: str
    size: int
    mtime: float
    sha256: str | None
    category: str
```

| Field | Type | Description |
|-------|------|-------------|
| `path` | `str` | Relative POSIX path (no leading `/`, no `..`) |
| `size` | `int` | File size in bytes |
| `mtime` | `float` | Modification time as Unix timestamp |
| `sha256` | `str \| None` | Hex SHA-256 digest, or `None` if not hashed |
| `category` | `str` | One of `checkpoint`, `restart`, `log`, `trajectory`, `other` |

### `Manifest`

A complete snapshot of a directory at a point in time.

```python
@dataclass
class Manifest:
    created_at: float
    root: str
    entries: list[ManifestEntry]
    summary: dict = field(default_factory=dict)
    version: int = 1
    job_id: str | None = None
    tool: str = "file-watchman"
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `created_at` | `float` | *(required)* | Unix timestamp when the manifest was created |
| `root` | `str` | *(required)* | Absolute path of the scanned directory |
| `entries` | `list[ManifestEntry]` | *(required)* | File entries, sorted by path |
| `summary` | `dict` | `{}` | Statistics: `count`, `total_bytes`, `by_category` |
| `version` | `int` | `1` | Manifest schema version |
| `job_id` | `str \| None` | `None` | Optional job identifier |
| `tool` | `str` | `"file-watchman"` | Tool that produced this manifest |

### `Delta`

Difference between two manifests.

```python
@dataclass
class Delta:
    uploads: list[ManifestEntry] = field(default_factory=list)
    deletions: list[str] = field(default_factory=list)
    changed: dict = field(default_factory=dict)
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `uploads` | `list[ManifestEntry]` | `[]` | New or changed file entries (from the new manifest) |
| `deletions` | `list[str]` | `[]` | Relative paths of deleted files (sorted) |
| `changed` | `dict` | `{}` | Maps path to change reason: `"new"`, `"deleted"`, `"size"`, `"mtime"`, or `"sha256"` |

### `VALID_CATEGORIES`

```python
VALID_CATEGORIES: frozenset[str] = frozenset(
    {"checkpoint", "restart", "log", "trajectory", "other"}
)
```

---

## Scan Rules & Policy (`file_watchman.rules`)

### `ScanRules`

Configuration controlling which files are discovered during a scan.

```python
@dataclass
class ScanRules:
    includes: list[str] = field(default_factory=lambda: ["**/*"])
    excludes: list[str] = field(default_factory=list)
    follow_symlinks: bool = False
    max_files: int = 50_000
    max_depth: int | None = None
    include_dirs: bool = False
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `includes` | `list[str]` | `["**/*"]` | Glob patterns — file must match at least one |
| `excludes` | `list[str]` | `[]` | Glob patterns — matching files are filtered out |
| `follow_symlinks` | `bool` | `False` | Whether to follow symbolic links |
| `max_files` | `int` | `50000` | Maximum number of files to include |
| `max_depth` | `int \| None` | `None` | Maximum directory depth (None = unlimited) |
| `include_dirs` | `bool` | `False` | Whether to include directories as entries |

### `HashPolicy`

Configuration controlling when SHA-256 hashes are computed.

```python
@dataclass
class HashPolicy:
    required_categories: set[str] = field(default_factory=set)
    optional_categories: set[str] = field(default_factory=set)
    never_categories: set[str] = field(default_factory=set)
    max_hash_bytes: int = 512 * 1024 * 1024
    chunk_size: int = 8 * 1024 * 1024
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `required_categories` | `set[str]` | `set()` | Always hash, regardless of file size |
| `optional_categories` | `set[str]` | `set()` | Hash only if size <= `max_hash_bytes` |
| `never_categories` | `set[str]` | `set()` | Never hash |
| `max_hash_bytes` | `int` | `536870912` (512 MB) | Size threshold for optional hashing |
| `chunk_size` | `int` | `8388608` (8 MB) | Read chunk size for streaming hash |

Categories not listed in any set default to **not hashed**.

### `should_hash(category, size, policy)`

```python
def should_hash(category: str, size: int, policy: HashPolicy) -> bool
```

Decide whether a file should be hashed based on its category and size.

**Logic:**
1. Category in `required_categories` → `True` (always)
2. Category in `never_categories` → `False` (never)
3. Category in `optional_categories` → `True` if `size <= max_hash_bytes`
4. Otherwise → `False`

### `make_categorizer(rules)`

```python
def make_categorizer(rules: list[tuple[str, str]]) -> Callable[[str], str]
```

Build a first-match-wins categorizer from a list of `(glob_pattern, category)` tuples. Returns a callable `(relpath) -> category` that defaults to `"other"` if no rule matches.

**Example:**

```python
categorize = make_categorizer([
    ("**/cpt_*.pkl", "checkpoint"),
    ("**/*.rst7", "restart"),
    ("**/*.log", "log"),
    ("**/*.nc", "trajectory"),
])

categorize("data/cpt_01.pkl")  # "checkpoint"
categorize("readme.txt")       # "other"
```

### `default_excludes()`

```python
def default_excludes() -> list[str]
```

Returns the default exclude patterns:

```python
[".git/**", "**/__pycache__/**", "**/*.tmp", "**/.DS_Store"]
```

---

## Scanning (`file_watchman.scan`)

### `scan_manifest(root, rules, hash_policy, categorize, job_id)`

```python
def scan_manifest(
    root: str,
    rules: ScanRules,
    hash_policy: HashPolicy,
    categorize: Callable[[str], str] | None = None,
    job_id: str | None = None,
) -> Manifest
```

Scan a directory and return a `Manifest` describing its files.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `root` | `str` | *(required)* | Absolute path to the directory to scan |
| `rules` | `ScanRules` | *(required)* | Controls file discovery (includes, excludes, limits) |
| `hash_policy` | `HashPolicy` | *(required)* | Controls which files get SHA-256 hashes |
| `categorize` | `Callable \| None` | `None` | Optional `(relpath) -> category` callback. Defaults to `"other"` |
| `job_id` | `str \| None` | `None` | Optional job identifier stored in the manifest |

**Returns:** `Manifest` with entries sorted by path and summary statistics computed.

**Algorithm:**
1. Walk directory tree from `root`
2. Normalize paths to relative POSIX format
3. Apply include/exclude glob rules
4. Enforce `max_files` and `max_depth` limits
5. Stat each file (size, mtime)
6. Categorize via callback or default
7. Hash per policy
8. Sort entries by path and compute summary

---

## Diffing (`file_watchman.diff`)

### `diff_manifests(prev, new)`

```python
def diff_manifests(prev: Manifest, new: Manifest) -> Delta
```

Compare two manifests and return a `Delta`.

| Parameter | Type | Description |
|-----------|------|-------------|
| `prev` | `Manifest` | The previous (baseline) manifest |
| `new` | `Manifest` | The new (current) manifest |

**Returns:** `Delta` with `uploads`, `deletions`, and `changed`.

**Change detection cascade** for entries sharing the same path:

| Priority | Condition | Reason |
|----------|-----------|--------|
| 1 | `size` differs | `"size"` |
| 2 | `mtime` differs | `"mtime"` |
| 3 | Both have `sha256` and they differ | `"sha256"` |
| 4 | Otherwise | Unchanged |

**Note:** If `sha256` is present in only one manifest, it is **not** treated as a change.

- **`uploads`** = entries only in `new` (reason `"new"`) + entries changed (from `new`)
- **`deletions`** = paths only in `prev` (reason `"deleted"`)

---

## I/O (`file_watchman.io`)

### `dump_manifest(manifest)`

```python
def dump_manifest(manifest: Manifest) -> dict
```

Serialize a `Manifest` to a JSON-serializable dict. Uses manual serialization (not `dataclasses.asdict`) for explicit schema control.

**Returns:** Dict matching the v1 JSON schema.

### `load_manifest(path)`

```python
def load_manifest(path: str) -> Manifest
```

Load a `Manifest` from a JSON file.

| Parameter | Type | Description |
|-----------|------|-------------|
| `path` | `str` | Path to the JSON manifest file |

**Returns:** Reconstructed `Manifest` object.

**Raises:**
- `ValueError` — if version is not `1`, or entry paths are absolute or contain `..`

**Behavior:** Unknown fields in the JSON are silently ignored for forward compatibility.

### `write_manifest_atomic(path, manifest)`

```python
def write_manifest_atomic(path: str, manifest: Manifest) -> None
```

Write a manifest atomically: writes to `path.tmp`, fsyncs, then `os.replace` to the final path. Both files must be on the same filesystem.

### JSON Schema (v1)

```json
{
  "version": 1,
  "tool": "file-watchman",
  "created_at": 1730000123.456,
  "root": "/scratch/job_123",
  "job_id": "job-123",
  "summary": {
    "count": 123,
    "total_bytes": 987654321,
    "by_category": {
      "checkpoint": {"count": 2, "bytes": 12345},
      "restart": {"count": 48, "bytes": 55555},
      "log": {"count": 4, "bytes": 9999},
      "trajectory": {"count": 6, "bytes": 900000000},
      "other": {"count": 63, "bytes": 11111}
    }
  },
  "entries": [
    {
      "path": "run.log",
      "size": 1000,
      "mtime": 1730000100.0,
      "sha256": null,
      "category": "log"
    }
  ]
}
```

---

## Hashing (`file_watchman.hash`)

### `sha256_file(path, chunk_size)`

```python
def sha256_file(path: str, chunk_size: int = 8_388_608) -> str
```

Return the hex SHA-256 digest of a file, reading in chunks.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `path` | `str` | *(required)* | Path to the file |
| `chunk_size` | `int` | `8388608` (8 MB) | Read chunk size in bytes |

**Returns:** Hex digest string (64 characters).

**Raises:** `OSError` if the file does not exist.

---

## Utilities (`file_watchman.utils`)

### `normalize_path(path, root)`

```python
def normalize_path(path: str, root: str) -> str
```

Convert a path to a relative POSIX path under a root directory.

| Parameter | Type | Description |
|-----------|------|-------------|
| `path` | `str` | The path to normalize |
| `root` | `str` | The root directory |

**Returns:** Relative POSIX path string (e.g., `"data/file.txt"`).

**Raises:** `ValueError` if the path is not under root, is absolute after normalization, or contains `..` segments.

### `matches_glob(relpath, pattern)`

```python
def matches_glob(relpath: str, pattern: str) -> bool
```

Test whether a relative path matches a glob pattern. Supports `**` for matching zero or more directory segments.

| Parameter | Type | Description |
|-----------|------|-------------|
| `relpath` | `str` | The relative path to test |
| `pattern` | `str` | Glob pattern (supports `*`, `?`, `**`) |

**Returns:** `True` if the path matches, `False` otherwise.
