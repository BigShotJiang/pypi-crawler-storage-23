"""Tests for manifest I/O."""

import json
import os

import pytest

from file_watchman.io import dump_manifest, load_manifest, write_manifest_atomic
from file_watchman.model import Manifest, ManifestEntry


def _sample_manifest():
    return Manifest(
        created_at=1700000000.0,
        root="/scratch/job_1",
        entries=[
            ManifestEntry(
                path="data/file.txt",
                size=1024,
                mtime=1700000000.0,
                sha256="abc123",
                category="checkpoint",
            ),
            ManifestEntry(
                path="run.log",
                size=500,
                mtime=1700000001.0,
                sha256=None,
                category="log",
            ),
        ],
        summary={"count": 2, "total_bytes": 1524},
        job_id="job-1",
    )


class TestDumpManifest:
    def test_produces_dict(self):
        d = dump_manifest(_sample_manifest())
        assert isinstance(d, dict)
        assert d["version"] == 1
        assert d["tool"] == "file-watchman"
        assert d["created_at"] == 1700000000.0
        assert d["root"] == "/scratch/job_1"
        assert d["job_id"] == "job-1"
        assert len(d["entries"]) == 2

    def test_entry_fields(self):
        d = dump_manifest(_sample_manifest())
        entry = d["entries"][0]
        assert entry["path"] == "data/file.txt"
        assert entry["size"] == 1024
        assert entry["mtime"] == 1700000000.0
        assert entry["sha256"] == "abc123"
        assert entry["category"] == "checkpoint"

    def test_null_sha256(self):
        d = dump_manifest(_sample_manifest())
        assert d["entries"][1]["sha256"] is None

    def test_json_serializable(self):
        d = dump_manifest(_sample_manifest())
        # Should not raise
        json.dumps(d)


class TestRoundTrip:
    def test_round_trip(self, tmp_path):
        original = _sample_manifest()
        path = str(tmp_path / "manifest.json")

        with open(path, "w") as f:
            json.dump(dump_manifest(original), f)

        loaded = load_manifest(path)

        assert loaded.version == original.version
        assert loaded.tool == original.tool
        assert loaded.created_at == original.created_at
        assert loaded.root == original.root
        assert loaded.job_id == original.job_id
        assert loaded.summary == original.summary
        assert len(loaded.entries) == len(original.entries)

        for orig_e, load_e in zip(original.entries, loaded.entries):
            assert load_e.path == orig_e.path
            assert load_e.size == orig_e.size
            assert load_e.mtime == orig_e.mtime
            assert load_e.sha256 == orig_e.sha256
            assert load_e.category == orig_e.category


class TestLoadManifest:
    def test_rejects_unsupported_version(self, tmp_path):
        path = str(tmp_path / "bad.json")
        with open(path, "w") as f:
            json.dump({"version": 99, "entries": []}, f)

        with pytest.raises(ValueError, match="Unsupported manifest version"):
            load_manifest(path)

    def test_rejects_absolute_entry_path(self, tmp_path):
        path = str(tmp_path / "bad.json")
        data = {
            "version": 1,
            "entries": [{"path": "/etc/passwd", "size": 10, "mtime": 1.0}],
        }
        with open(path, "w") as f:
            json.dump(data, f)

        with pytest.raises(ValueError, match="absolute"):
            load_manifest(path)

    def test_rejects_dotdot_entry_path(self, tmp_path):
        path = str(tmp_path / "bad.json")
        data = {
            "version": 1,
            "entries": [{"path": "../escape.txt", "size": 10, "mtime": 1.0}],
        }
        with open(path, "w") as f:
            json.dump(data, f)

        with pytest.raises(ValueError, match="\\.\\."):
            load_manifest(path)

    def test_tolerates_unknown_fields(self, tmp_path):
        path = str(tmp_path / "future.json")
        data = {
            "version": 1,
            "tool": "file-watchman",
            "created_at": 1.0,
            "root": "/tmp",
            "future_field": "hello",
            "entries": [
                {
                    "path": "a.txt",
                    "size": 10,
                    "mtime": 1.0,
                    "sha256": None,
                    "category": "other",
                    "new_field": 42,
                }
            ],
        }
        with open(path, "w") as f:
            json.dump(data, f)

        m = load_manifest(path)
        assert len(m.entries) == 1
        assert m.entries[0].path == "a.txt"

    def test_missing_version(self, tmp_path):
        path = str(tmp_path / "no_version.json")
        with open(path, "w") as f:
            json.dump({"entries": []}, f)

        with pytest.raises(ValueError, match="Unsupported manifest version"):
            load_manifest(path)


class TestWriteManifestAtomic:
    def test_creates_file(self, tmp_path):
        path = str(tmp_path / "manifest.json")
        write_manifest_atomic(path, _sample_manifest())
        assert os.path.exists(path)

    def test_no_leftover_tmp(self, tmp_path):
        path = str(tmp_path / "manifest.json")
        write_manifest_atomic(path, _sample_manifest())
        assert not os.path.exists(path + ".tmp")

    def test_content_valid_json(self, tmp_path):
        path = str(tmp_path / "manifest.json")
        write_manifest_atomic(path, _sample_manifest())

        with open(path) as f:
            data = json.load(f)
        assert data["version"] == 1
        assert len(data["entries"]) == 2

    def test_atomic_round_trip(self, tmp_path):
        path = str(tmp_path / "manifest.json")
        original = _sample_manifest()
        write_manifest_atomic(path, original)
        loaded = load_manifest(path)

        assert loaded.version == original.version
        assert len(loaded.entries) == len(original.entries)
