"""Integration tests — full scan -> mutate -> scan -> diff workflow."""

import os

from file_watchman.diff import diff_manifests
from file_watchman.io import load_manifest, write_manifest_atomic
from file_watchman.rules import HashPolicy, ScanRules, make_categorizer
from file_watchman.scan import scan_manifest


def _make_file(root, relpath, content=b"data"):
    full = os.path.join(root, relpath)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "wb") as f:
        f.write(content)
    return full


class TestFullWorkflow:
    """scan -> mutate -> scan -> diff."""

    def test_add_modify_delete(self, tmp_path):
        root = str(tmp_path)

        # Initial state: 3 files
        _make_file(root, "keep.txt", b"unchanged")
        _make_file(root, "modify.txt", b"original")
        _make_file(root, "remove.txt", b"will be deleted")

        rules = ScanRules()
        policy = HashPolicy()

        manifest_prev = scan_manifest(root=root, rules=rules, hash_policy=policy)
        assert len(manifest_prev.entries) == 3

        # Mutate: add a file, modify one, delete one
        _make_file(root, "added.txt", b"new file")

        modify_path = os.path.join(root, "modify.txt")
        with open(modify_path, "wb") as f:
            f.write(b"modified content that is longer")

        os.remove(os.path.join(root, "remove.txt"))

        manifest_new = scan_manifest(root=root, rules=rules, hash_policy=policy)
        assert len(manifest_new.entries) == 3  # keep, modify, added

        delta = diff_manifests(manifest_prev, manifest_new)

        upload_paths = sorted(e.path for e in delta.uploads)
        assert "added.txt" in upload_paths
        assert "modify.txt" in upload_paths
        assert delta.deletions == ["remove.txt"]
        assert delta.changed["added.txt"] == "new"
        assert delta.changed["modify.txt"] == "size"
        assert delta.changed["remove.txt"] == "deleted"
        assert "keep.txt" not in delta.changed

    def test_no_changes(self, tmp_path):
        root = str(tmp_path)
        _make_file(root, "stable.txt", b"content")

        rules = ScanRules()
        policy = HashPolicy()

        m1 = scan_manifest(root=root, rules=rules, hash_policy=policy)
        m2 = scan_manifest(root=root, rules=rules, hash_policy=policy)

        delta = diff_manifests(m1, m2)
        assert delta.uploads == []
        assert delta.deletions == []


class TestHashingIntegration:
    """Verify category-based hashing in the full pipeline."""

    def test_checkpoint_hashed_trajectory_not(self, tmp_path):
        root = str(tmp_path)
        _make_file(root, "cpt_01.pkl", b"checkpoint data")
        _make_file(root, "traj.nc", b"trajectory data")
        _make_file(root, "run.log", b"log content")

        rules = ScanRules()
        policy = HashPolicy(
            required_categories={"checkpoint"},
            never_categories={"trajectory"},
            optional_categories={"log"},
            max_hash_bytes=1024 * 1024,
        )
        categorize = make_categorizer(
            [
                ("**/cpt_*.pkl", "checkpoint"),
                ("**/*.nc", "trajectory"),
                ("**/*.log", "log"),
            ]
        )

        m = scan_manifest(
            root=root, rules=rules, hash_policy=policy, categorize=categorize
        )
        by_path = {e.path: e for e in m.entries}

        assert by_path["cpt_01.pkl"].sha256 is not None
        assert by_path["cpt_01.pkl"].category == "checkpoint"
        assert by_path["traj.nc"].sha256 is None
        assert by_path["traj.nc"].category == "trajectory"
        assert by_path["run.log"].sha256 is not None
        assert by_path["run.log"].category == "log"

    def test_sha256_detects_content_change(self, tmp_path):
        """Content-only change (same size) detected via sha256."""
        root = str(tmp_path)
        _make_file(root, "cpt.pkl", b"AAAA")

        rules = ScanRules()
        policy = HashPolicy(required_categories={"checkpoint"})

        def categorize(p):
            return "checkpoint"

        m1 = scan_manifest(
            root=root, rules=rules, hash_policy=policy, categorize=categorize
        )

        # Overwrite with same size but different content
        cpt_path = os.path.join(root, "cpt.pkl")
        # Preserve mtime so only sha256 differs
        stat_before = os.stat(cpt_path)
        with open(cpt_path, "wb") as f:
            f.write(b"BBBB")
        os.utime(cpt_path, (stat_before.st_atime, stat_before.st_mtime))

        m2 = scan_manifest(
            root=root, rules=rules, hash_policy=policy, categorize=categorize
        )

        # Verify size and mtime are the same
        e1 = m1.entries[0]
        e2 = m2.entries[0]
        assert e1.size == e2.size
        assert e1.mtime == e2.mtime
        assert e1.sha256 != e2.sha256

        delta = diff_manifests(m1, m2)
        assert len(delta.uploads) == 1
        assert delta.changed["cpt.pkl"] == "sha256"


class TestManifestIOIntegration:
    """Verify write -> load round-trip with scanned manifests."""

    def test_scan_write_load_diff(self, tmp_path):
        root = str(tmp_path / "workdir")
        os.makedirs(root)
        _make_file(root, "a.txt", b"hello")
        _make_file(root, "b.txt", b"world")

        rules = ScanRules()
        policy = HashPolicy()

        m1 = scan_manifest(root=root, rules=rules, hash_policy=policy)

        manifest_path = str(tmp_path / "manifest.json")
        write_manifest_atomic(manifest_path, m1)
        m1_loaded = load_manifest(manifest_path)

        # Mutate
        _make_file(root, "c.txt", b"new")
        m2 = scan_manifest(root=root, rules=rules, hash_policy=policy)

        delta = diff_manifests(m1_loaded, m2)
        assert len(delta.uploads) == 1
        assert delta.uploads[0].path == "c.txt"
        assert delta.changed["c.txt"] == "new"
