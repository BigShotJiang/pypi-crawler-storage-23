"""Tests for the data model."""

import time

from file_watchman.model import (
    VALID_CATEGORIES,
    Delta,
    Manifest,
    ManifestEntry,
)


class TestManifestEntry:
    def test_instantiation(self):
        entry = ManifestEntry(
            path="data/file.txt",
            size=1024,
            mtime=1700000000.0,
            sha256="abc123",
            category="checkpoint",
        )
        assert entry.path == "data/file.txt"
        assert entry.size == 1024
        assert entry.mtime == 1700000000.0
        assert entry.sha256 == "abc123"
        assert entry.category == "checkpoint"

    def test_sha256_none(self):
        entry = ManifestEntry(
            path="run.log",
            size=500,
            mtime=1700000000.0,
            sha256=None,
            category="log",
        )
        assert entry.sha256 is None

    def test_slots(self):
        entry = ManifestEntry(
            path="f.txt", size=0, mtime=0.0, sha256=None, category="other"
        )
        assert not hasattr(entry, "__dict__")


class TestManifest:
    def test_instantiation(self):
        now = time.time()
        manifest = Manifest(
            created_at=now,
            root="/scratch/job_1",
            entries=[],
        )
        assert manifest.version == 1
        assert manifest.created_at == now
        assert manifest.root == "/scratch/job_1"
        assert manifest.job_id is None
        assert manifest.tool == "file-watchman"
        assert manifest.entries == []
        assert manifest.summary == {}

    def test_custom_fields(self):
        entry = ManifestEntry(
            path="a.txt", size=10, mtime=1.0, sha256=None, category="other"
        )
        manifest = Manifest(
            created_at=1.0,
            root="/tmp",
            entries=[entry],
            summary={"count": 1},
            version=1,
            job_id="job-42",
            tool="file-watchman",
        )
        assert manifest.job_id == "job-42"
        assert len(manifest.entries) == 1
        assert manifest.summary == {"count": 1}


class TestDelta:
    def test_defaults(self):
        delta = Delta()
        assert delta.uploads == []
        assert delta.deletions == []
        assert delta.changed == {}

    def test_with_data(self):
        entry = ManifestEntry(
            path="new.txt", size=100, mtime=1.0, sha256=None, category="other"
        )
        delta = Delta(
            uploads=[entry],
            deletions=["old.txt"],
            changed={"new.txt": "new"},
        )
        assert len(delta.uploads) == 1
        assert delta.deletions == ["old.txt"]
        assert delta.changed == {"new.txt": "new"}


class TestValidCategories:
    def test_expected_categories(self):
        expected = {"checkpoint", "restart", "log", "trajectory", "other"}
        assert VALID_CATEGORIES == expected

    def test_frozenset(self):
        assert isinstance(VALID_CATEGORIES, frozenset)
