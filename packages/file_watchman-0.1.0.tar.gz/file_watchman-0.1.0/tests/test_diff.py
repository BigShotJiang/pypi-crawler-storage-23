"""Tests for manifest diff."""

from file_watchman.diff import diff_manifests
from file_watchman.model import Manifest, ManifestEntry


def _manifest(entries):
    """Helper to build a Manifest from a list of ManifestEntry."""
    return Manifest(created_at=1.0, root="/tmp", entries=entries)


def _entry(path, size=100, mtime=1.0, sha256=None, category="other"):
    return ManifestEntry(
        path=path, size=size, mtime=mtime, sha256=sha256, category=category
    )


class TestNoChanges:
    def test_identical_manifests(self):
        entries = [_entry("a.txt"), _entry("b.txt")]
        delta = diff_manifests(_manifest(entries), _manifest(entries))
        assert delta.uploads == []
        assert delta.deletions == []
        assert delta.changed == {}

    def test_both_empty(self):
        delta = diff_manifests(_manifest([]), _manifest([]))
        assert delta.uploads == []
        assert delta.deletions == []


class TestNewFile:
    def test_new_file_detected(self):
        prev = _manifest([_entry("a.txt")])
        new = _manifest([_entry("a.txt"), _entry("b.txt")])
        delta = diff_manifests(prev, new)
        assert len(delta.uploads) == 1
        assert delta.uploads[0].path == "b.txt"
        assert delta.changed["b.txt"] == "new"

    def test_all_new(self):
        delta = diff_manifests(_manifest([]), _manifest([_entry("x.txt")]))
        assert len(delta.uploads) == 1
        assert delta.changed["x.txt"] == "new"


class TestDeletedFile:
    def test_deleted_file_detected(self):
        prev = _manifest([_entry("a.txt"), _entry("b.txt")])
        new = _manifest([_entry("a.txt")])
        delta = diff_manifests(prev, new)
        assert delta.deletions == ["b.txt"]
        assert delta.changed["b.txt"] == "deleted"

    def test_all_deleted(self):
        delta = diff_manifests(_manifest([_entry("a.txt")]), _manifest([]))
        assert delta.deletions == ["a.txt"]


class TestSizeChange:
    def test_size_change(self):
        prev = _manifest([_entry("a.txt", size=100)])
        new = _manifest([_entry("a.txt", size=200)])
        delta = diff_manifests(prev, new)
        assert len(delta.uploads) == 1
        assert delta.changed["a.txt"] == "size"


class TestMtimeChange:
    def test_mtime_change(self):
        prev = _manifest([_entry("a.txt", mtime=1.0)])
        new = _manifest([_entry("a.txt", mtime=2.0)])
        delta = diff_manifests(prev, new)
        assert len(delta.uploads) == 1
        assert delta.changed["a.txt"] == "mtime"


class TestSha256Change:
    def test_sha256_change(self):
        prev = _manifest([_entry("a.txt", sha256="aaa")])
        new = _manifest([_entry("a.txt", sha256="bbb")])
        delta = diff_manifests(prev, new)
        assert len(delta.uploads) == 1
        assert delta.changed["a.txt"] == "sha256"

    def test_one_sided_sha256_not_changed(self):
        # sha256 present in only one side should NOT be treated as a change
        prev = _manifest([_entry("a.txt", sha256=None)])
        new = _manifest([_entry("a.txt", sha256="abc123")])
        delta = diff_manifests(prev, new)
        assert delta.uploads == []
        assert delta.changed == {}

    def test_one_sided_sha256_reverse(self):
        prev = _manifest([_entry("a.txt", sha256="abc123")])
        new = _manifest([_entry("a.txt", sha256=None)])
        delta = diff_manifests(prev, new)
        assert delta.uploads == []
        assert delta.changed == {}


class TestCascadePriority:
    def test_size_takes_priority_over_mtime(self):
        prev = _manifest([_entry("a.txt", size=100, mtime=1.0)])
        new = _manifest([_entry("a.txt", size=200, mtime=2.0)])
        delta = diff_manifests(prev, new)
        assert delta.changed["a.txt"] == "size"

    def test_mtime_takes_priority_over_sha256(self):
        prev = _manifest([_entry("a.txt", mtime=1.0, sha256="aaa")])
        new = _manifest([_entry("a.txt", mtime=2.0, sha256="bbb")])
        delta = diff_manifests(prev, new)
        assert delta.changed["a.txt"] == "mtime"


class TestMixedScenario:
    def test_mixed(self):
        prev = _manifest(
            [
                _entry("unchanged.txt", size=10, mtime=1.0),
                _entry("modified.txt", size=10, mtime=1.0),
                _entry("deleted.txt", size=10, mtime=1.0),
            ]
        )
        new = _manifest(
            [
                _entry("unchanged.txt", size=10, mtime=1.0),
                _entry("modified.txt", size=20, mtime=2.0),
                _entry("added.txt", size=5, mtime=3.0),
            ]
        )
        delta = diff_manifests(prev, new)

        upload_paths = sorted(e.path for e in delta.uploads)
        assert upload_paths == ["added.txt", "modified.txt"]
        assert delta.deletions == ["deleted.txt"]
        assert delta.changed["added.txt"] == "new"
        assert delta.changed["modified.txt"] == "size"
        assert delta.changed["deleted.txt"] == "deleted"
        assert "unchanged.txt" not in delta.changed
