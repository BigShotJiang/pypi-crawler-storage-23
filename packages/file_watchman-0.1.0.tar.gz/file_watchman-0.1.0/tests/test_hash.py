"""Tests for SHA-256 streaming file hash."""

import hashlib

import pytest

from file_watchman.hash import sha256_file


class TestSha256File:
    def test_known_content(self, tmp_path):
        f = tmp_path / "hello.txt"
        f.write_bytes(b"hello world")
        expected = hashlib.sha256(b"hello world").hexdigest()
        assert sha256_file(str(f)) == expected

    def test_empty_file(self, tmp_path):
        f = tmp_path / "empty.txt"
        f.write_bytes(b"")
        expected = hashlib.sha256(b"").hexdigest()
        assert sha256_file(str(f)) == expected

    def test_multi_chunk(self, tmp_path):
        # Use a small chunk size so the file spans multiple chunks
        chunk_size = 16
        content = b"A" * 100
        f = tmp_path / "big.bin"
        f.write_bytes(content)
        expected = hashlib.sha256(content).hexdigest()
        assert sha256_file(str(f), chunk_size=chunk_size) == expected

    def test_missing_file(self, tmp_path):
        with pytest.raises(OSError):
            sha256_file(str(tmp_path / "nonexistent.txt"))

    def test_binary_content(self, tmp_path):
        content = bytes(range(256))
        f = tmp_path / "binary.bin"
        f.write_bytes(content)
        expected = hashlib.sha256(content).hexdigest()
        assert sha256_file(str(f)) == expected
