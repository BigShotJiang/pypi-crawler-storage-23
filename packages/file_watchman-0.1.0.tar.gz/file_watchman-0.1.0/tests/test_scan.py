"""Tests for directory scanning."""

from file_watchman.model import Manifest
from file_watchman.rules import HashPolicy, ScanRules
from file_watchman.scan import scan_manifest


def _make_file(tmp_path, relpath, content=b"data"):
    """Helper to create a file under tmp_path."""
    full = tmp_path / relpath
    full.parent.mkdir(parents=True, exist_ok=True)
    full.write_bytes(content)
    return full


class TestScanBasic:
    def test_basic_scan(self, tmp_path):
        _make_file(tmp_path, "a.txt")
        _make_file(tmp_path, "b.txt")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
        )
        assert isinstance(m, Manifest)
        assert len(m.entries) == 2
        paths = [e.path for e in m.entries]
        assert paths == ["a.txt", "b.txt"]

    def test_empty_directory(self, tmp_path):
        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
        )
        assert len(m.entries) == 0
        assert m.summary["count"] == 0

    def test_nested_files(self, tmp_path):
        _make_file(tmp_path, "dir/sub/file.txt")
        _make_file(tmp_path, "top.txt")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
        )
        paths = [e.path for e in m.entries]
        assert "dir/sub/file.txt" in paths
        assert "top.txt" in paths

    def test_sorted_entries(self, tmp_path):
        _make_file(tmp_path, "c.txt")
        _make_file(tmp_path, "a.txt")
        _make_file(tmp_path, "b.txt")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
        )
        paths = [e.path for e in m.entries]
        assert paths == ["a.txt", "b.txt", "c.txt"]


class TestScanExcludes:
    def test_excludes_pattern(self, tmp_path):
        _make_file(tmp_path, "keep.txt")
        _make_file(tmp_path, "remove.tmp")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(excludes=["**/*.tmp"]),
            hash_policy=HashPolicy(),
        )
        paths = [e.path for e in m.entries]
        assert "keep.txt" in paths
        assert "remove.tmp" not in paths

    def test_excludes_directory(self, tmp_path):
        _make_file(tmp_path, "good.txt")
        _make_file(tmp_path, ".git/config")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(excludes=[".git/**"]),
            hash_policy=HashPolicy(),
        )
        paths = [e.path for e in m.entries]
        assert "good.txt" in paths
        assert ".git/config" not in paths


class TestScanIncludes:
    def test_includes_limits_scan(self, tmp_path):
        _make_file(tmp_path, "data.csv")
        _make_file(tmp_path, "notes.txt")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(includes=["**/*.csv"]),
            hash_policy=HashPolicy(),
        )
        paths = [e.path for e in m.entries]
        assert paths == ["data.csv"]


class TestScanMaxFiles:
    def test_max_files(self, tmp_path):
        for i in range(20):
            _make_file(tmp_path, f"file_{i:02d}.txt")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(max_files=5),
            hash_policy=HashPolicy(),
        )
        assert len(m.entries) <= 5


class TestScanMaxDepth:
    def test_max_depth(self, tmp_path):
        _make_file(tmp_path, "level0.txt")
        _make_file(tmp_path, "a/level1.txt")
        _make_file(tmp_path, "a/b/level2.txt")
        _make_file(tmp_path, "a/b/c/level3.txt")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(max_depth=2),
            hash_policy=HashPolicy(),
        )
        paths = [e.path for e in m.entries]
        assert "level0.txt" in paths
        assert "a/level1.txt" in paths
        assert "a/b/level2.txt" not in paths
        assert "a/b/c/level3.txt" not in paths


class TestScanCategorization:
    def test_custom_categorizer(self, tmp_path):
        _make_file(tmp_path, "run.log")
        _make_file(tmp_path, "data.nc")

        def categorize(relpath):
            if relpath.endswith(".log"):
                return "log"
            if relpath.endswith(".nc"):
                return "trajectory"
            return "other"

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
            categorize=categorize,
        )
        cats = {e.path: e.category for e in m.entries}
        assert cats["run.log"] == "log"
        assert cats["data.nc"] == "trajectory"

    def test_default_categorizer(self, tmp_path):
        _make_file(tmp_path, "file.txt")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
        )
        assert m.entries[0].category == "other"


class TestScanHashing:
    def test_required_category_hashed(self, tmp_path):
        _make_file(tmp_path, "cpt.pkl", b"checkpoint data")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(required_categories={"checkpoint"}),
            categorize=lambda _: "checkpoint",
        )
        assert m.entries[0].sha256 is not None

    def test_never_category_not_hashed(self, tmp_path):
        _make_file(tmp_path, "traj.nc", b"trajectory data")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(never_categories={"trajectory"}),
            categorize=lambda _: "trajectory",
        )
        assert m.entries[0].sha256 is None

    def test_default_not_hashed(self, tmp_path):
        _make_file(tmp_path, "file.txt", b"some data")

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
        )
        assert m.entries[0].sha256 is None


class TestScanSymlinks:
    def test_symlinks_skipped_by_default(self, tmp_path):
        real = _make_file(tmp_path, "real.txt")
        link = tmp_path / "link.txt"
        link.symlink_to(real)

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(follow_symlinks=False),
            hash_policy=HashPolicy(),
        )
        paths = [e.path for e in m.entries]
        assert "real.txt" in paths
        assert "link.txt" not in paths


class TestScanSummary:
    def test_summary_statistics(self, tmp_path):
        _make_file(tmp_path, "a.log", b"log data")
        _make_file(tmp_path, "b.nc", b"traj")

        def categorize(relpath):
            if relpath.endswith(".log"):
                return "log"
            return "trajectory"

        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
            categorize=categorize,
        )
        assert m.summary["count"] == 2
        assert m.summary["total_bytes"] == len(b"log data") + len(b"traj")
        assert m.summary["by_category"]["log"]["count"] == 1
        assert m.summary["by_category"]["trajectory"]["count"] == 1

    def test_job_id(self, tmp_path):
        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
            job_id="test-job-42",
        )
        assert m.job_id == "test-job-42"

    def test_manifest_metadata(self, tmp_path):
        m = scan_manifest(
            root=str(tmp_path),
            rules=ScanRules(),
            hash_policy=HashPolicy(),
        )
        assert m.version == 1
        assert m.tool == "file-watchman"
        assert m.created_at > 0
