"""Tests for scan rules, hash policy, and categorization."""

from file_watchman.rules import (
    HashPolicy,
    ScanRules,
    default_excludes,
    make_categorizer,
    should_hash,
)


class TestScanRulesDefaults:
    def test_defaults(self):
        rules = ScanRules()
        assert rules.includes == ["**/*"]
        assert rules.excludes == []
        assert rules.follow_symlinks is False
        assert rules.max_files == 50_000
        assert rules.max_depth is None
        assert rules.include_dirs is False


class TestHashPolicy:
    def test_defaults(self):
        policy = HashPolicy()
        assert policy.required_categories == set()
        assert policy.optional_categories == set()
        assert policy.never_categories == set()
        assert policy.max_hash_bytes == 512 * 1024 * 1024
        assert policy.chunk_size == 8 * 1024 * 1024


class TestShouldHash:
    def setup_method(self):
        self.policy = HashPolicy(
            required_categories={"checkpoint", "restart"},
            optional_categories={"log"},
            never_categories={"trajectory"},
            max_hash_bytes=100,
        )

    def test_required_always_hashed(self):
        assert should_hash("checkpoint", 999999, self.policy) is True
        assert should_hash("restart", 999999, self.policy) is True

    def test_never_never_hashed(self):
        assert should_hash("trajectory", 1, self.policy) is False

    def test_optional_under_limit(self):
        assert should_hash("log", 50, self.policy) is True

    def test_optional_at_limit(self):
        assert should_hash("log", 100, self.policy) is True

    def test_optional_over_limit(self):
        assert should_hash("log", 101, self.policy) is False

    def test_default_category_not_hashed(self):
        assert should_hash("other", 10, self.policy) is False

    def test_unknown_category_not_hashed(self):
        assert should_hash("unknown", 10, self.policy) is False


class TestMakeCategorizer:
    def setup_method(self):
        self.rules = [
            ("**/cpt_*.pkl", "checkpoint"),
            ("**/*.rst7", "restart"),
            ("**/*.log", "log"),
            ("**/*.nc", "trajectory"),
        ]
        self.categorize = make_categorizer(self.rules)

    def test_checkpoint(self):
        assert self.categorize("data/cpt_01.pkl") == "checkpoint"

    def test_restart(self):
        assert self.categorize("run/step.rst7") == "restart"

    def test_log(self):
        assert self.categorize("output/run.log") == "log"

    def test_trajectory(self):
        assert self.categorize("traj/prod.nc") == "trajectory"

    def test_default_other(self):
        assert self.categorize("readme.txt") == "other"

    def test_first_match_wins(self):
        # A file matching both checkpoint and log patterns
        rules = [
            ("**/*.log", "log"),
            ("**/special.log", "checkpoint"),
        ]
        categorize = make_categorizer(rules)
        # First rule wins
        assert categorize("data/special.log") == "log"


class TestDefaultExcludes:
    def test_returns_list(self):
        excludes = default_excludes()
        assert isinstance(excludes, list)
        assert len(excludes) > 0

    def test_contains_expected_patterns(self):
        excludes = default_excludes()
        assert ".git/**" in excludes
        assert "**/__pycache__/**" in excludes
        assert "**/*.tmp" in excludes
        assert "**/.DS_Store" in excludes
