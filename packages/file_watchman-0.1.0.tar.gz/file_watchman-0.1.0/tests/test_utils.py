"""Tests for path normalization and glob matching utilities."""

import tempfile

import pytest

from file_watchman.utils import matches_glob, normalize_path


class TestNormalizePath:
    def test_relative_posix(self, tmp_path):
        sub = tmp_path / "data" / "file.txt"
        sub.parent.mkdir(parents=True)
        sub.touch()
        result = normalize_path(str(sub), str(tmp_path))
        assert result == "data/file.txt"

    def test_file_in_root(self, tmp_path):
        f = tmp_path / "readme.md"
        f.touch()
        result = normalize_path(str(f), str(tmp_path))
        assert result == "readme.md"

    def test_rejects_path_outside_root(self, tmp_path):
        outside = tmp_path / ".." / "outside.txt"
        with pytest.raises(ValueError, match="not under root"):
            normalize_path(str(outside), str(tmp_path / "subdir"))

    def test_rejects_absolute_result_via_escape(self, tmp_path):
        # A path that resolves outside the root should be rejected
        other = tempfile.mkdtemp()
        with pytest.raises(ValueError, match="not under root"):
            normalize_path(other, str(tmp_path))

    def test_nested_deep(self, tmp_path):
        deep = tmp_path / "a" / "b" / "c" / "d.txt"
        deep.parent.mkdir(parents=True)
        deep.touch()
        result = normalize_path(str(deep), str(tmp_path))
        assert result == "a/b/c/d.txt"


class TestMatchesGlob:
    def test_double_star_pattern(self):
        assert matches_glob("data/checkpoints/cpt_01.pkl", "**/cpt_*.pkl")

    def test_double_star_deep_match(self):
        assert matches_glob("a/b/c/file.log", "**/*.log")

    def test_double_star_no_match(self):
        assert not matches_glob("data/file.txt", "**/*.log")

    def test_simple_fnmatch(self):
        assert matches_glob("file.log", "*.log")

    def test_simple_fnmatch_no_match(self):
        assert not matches_glob("file.txt", "*.log")

    def test_exact_name(self):
        assert matches_glob(".DS_Store", ".DS_Store")

    def test_double_star_directory_pattern(self):
        assert matches_glob("src/__pycache__/mod.pyc", "**/__pycache__/**")

    def test_git_directory_pattern(self):
        assert matches_glob(".git/objects/pack", ".git/**")
