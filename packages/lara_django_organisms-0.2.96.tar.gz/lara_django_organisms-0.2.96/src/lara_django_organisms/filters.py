"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data filter app *

:details: lara_django_data filter app. 
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""


from django_filters.rest_framework import FilterSet, CharFilter, DateRangeFilter

from .models import (
    ExtraData,
    HabitatClass,
    HabitatParameter,
    Habitat,
    Trait,
    Domain,
    Regnum,
    Phylum,
    Classis,
    Ordo,
    Familia,
    Genus,
    Species,
    Subspecies,
    Variant,
    Cultivar,
    Organism,
    OrganismsSubset
)


class ExtraDataFilterSet(FilterSet):
    class Meta:
        model = ExtraData
        fields = {
            "name_display": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_full": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            "datetime_created": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }


class HabitatClassFilterSet(FilterSet):
    class Meta:
        model = HabitatClass
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class HabitatParameterFilterSet(FilterSet):
    class Meta:
        model = HabitatParameter
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class HabitatFilterSet(FilterSet):
    class Meta:
        model = Habitat
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class TraitFilterSet(FilterSet):
    class Meta:
        model = Trait
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class DomainFilterSet(FilterSet):
    class Meta:
        model = Domain
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class RegnumFilterSet(FilterSet):
    class Meta:
        model = Regnum
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class PhylumFilterSet(FilterSet):
    class Meta:
        model = Phylum
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class ClassisFilterSet(FilterSet):
    class Meta:
        model = Classis
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class OrdoFilterSet(FilterSet):
    class Meta:
        model = Ordo
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class FamiliaFilterSet(FilterSet):
    class Meta:
        model = Familia
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class GenusFilterSet(FilterSet):
    class Meta:
        model = Genus
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class SpeciesFilterSet(FilterSet):
    class Meta:
        model = Species
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class SubspeciesFilterSet(FilterSet):
    class Meta:
        model = Subspecies
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class VariantFilterSet(FilterSet):
    class Meta:
        model = Variant
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class CultivarFilterSet(FilterSet):
    class Meta:
        model = Cultivar
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class OrganismFilterSet(FilterSet):
    class Meta:
        model = Organism
        fields = {
            "name": ["exact", "contains"],
            "name_common": ["exact", "contains"],
            "domain__name": ["exact", "contains"],
            "familia__name": ["exact", "contains"],
            "genus__name": ["exact", "contains"],
            "species__name": ["exact", "contains"],
            "subspecies__name": ["exact", "contains"],
            "variant__name": ["exact", "contains"],
            "cultivar__name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class OrganismsSubsetFilterSet(FilterSet):
    class Meta:
        model = OrganismsSubset
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }