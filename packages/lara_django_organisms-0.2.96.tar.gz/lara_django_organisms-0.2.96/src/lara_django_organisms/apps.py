"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms app *

:details: lara_django_organisms app configuration. 
         This provides a generic django app configuration mechanism.
         For more details see:
         https://docs.djangoproject.com/en/4.0/ref/applications/
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""


from django.apps import AppConfig


class LaraDjangoOrganismsConfig(AppConfig):
    name = 'lara_django_organisms'
    url_path = 'organisms/'
    # enter a verbose name for your app: lara_django_organisms here - this will be used in the admin interface
    verbose_name = 'LARA-django Organisms'
    # lara_app_icon = 'lara_django_organisms_icon.svg'  # this will be used to display an icon, e.g. in the main LARA menu.
    lara_app_color = 'lime'  # this will be used to highlight the app in the main LARA sidebar and app page

    def ready(self):
        # add urlpatterns 
        from django.urls import path, include
        from lara_django.urls import urlpatterns

        urlpatterns += [ 
            path(self.url_path, include('lara_django_organisms.urls', namespace='lara_django_organisms')),
        ]
