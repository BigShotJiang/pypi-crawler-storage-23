"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms admin *

:details: lara_django_organisms admin module admin backend configuration.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator lara_django_organisms >> admin.py" to update this file
________________________________________________________________________
"""
# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import (
    ExtraData,
    HabitatClass,
    HabitatParameter,
    Habitat,
    Trait,
    Domain,
    Regnum,
    Phylum,
    Classis,
    Ordo,
    Familia,
    Genus,
    Species,
    Subspecies,
    Variant,
    Cultivar,
    Organism,
    OrganismsSubset,
)


@admin.register(ExtraData)
class ExtraDataAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "data_type",
        "media_type",
        "iri",
        "url",
        "description",
        "file",
        "extradata_id",
    )
    list_filter = ("data_type", "namespace", "media_type")


@admin.register(HabitatClass)
class HabitatClassAdmin(admin.ModelAdmin):
    list_display = ("habitatclass_id", "name", "description")
    search_fields = ("name",)


@admin.register(HabitatParameter)
class HabitatParameterAdmin(admin.ModelAdmin):
    list_display = (
        "habitatparameter_id",
        "name",
        "unit",
        "description",
    )
    list_filter = ("unit",)
    raw_id_fields = ("data_extra",)
    search_fields = ("name",)


@admin.register(Habitat)
class HabitatAdmin(admin.ModelAdmin):
    list_display = ("habitat_id", "name", "description")
    raw_id_fields = ("habitat_class", "parameters")
    search_fields = ("name",)


@admin.register(Trait)
class TraitAdmin(admin.ModelAdmin):
    list_display = ("trait_id", "name", "unit", "description")
    list_filter = ("unit",)


@admin.register(Domain)
class DomainAdmin(admin.ModelAdmin):
    list_display = ("domain_id", "name", "description")
    search_fields = ("name",)


@admin.register(Regnum)
class RegnumAdmin(admin.ModelAdmin):
    list_display = ("regnum_id", "name", "description")
    search_fields = ("name",)


@admin.register(Phylum)
class PhylumAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "characteristics",
        "description",
        "phylum_id",
    )
    search_fields = ("name",)


@admin.register(Classis)
class ClassisAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "characteristics",
        "description",
        "classis_id",
    )
    search_fields = ("name",)


@admin.register(Ordo)
class OrdoAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "characteristics",
        "description",
        "ordo_id",
    )
    search_fields = ("name",)


@admin.register(Familia)
class FamiliaAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "characteristics",
        "description",
        
    )
    search_fields = ("name",)


@admin.register(Genus)
class GenusAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "characteristics",
        "description",
        "genus_id",
    )
    search_fields = ("name",)


@admin.register(Species)
class SpeciesAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "characteristics",
        "description",
        "species_id",
    )
    search_fields = ("name",)


@admin.register(Subspecies)
class SubspeciesAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "characteristics",
        "description",
        "subspecies_id",
    )
    search_fields = ("name",)


@admin.register(Variant)
class VariantAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "characteristics",
        "description",
        "variant_id",
    )
    search_fields = ("name",)


@admin.register(Cultivar)
class CultivarAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "characteristics",
        "description",
        "cultivar_id",
    )
    search_fields = ("name",)


@admin.register(Organism)
class OrganismAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "name_common",
        "domain",
        "regnum",
        "phylum",
        "classis",
        "ordo",
        "familia",
        "genus",
        "species",
        "subspecies",
        "variant",
        "cultivar",
        "description",
        "organism_id",
    )
    list_filter = (
        "domain",
        "regnum",
        "phylum",
        "classis",
        "ordo",
        "familia",
        "genus",
        "species",
        "subspecies",
        "variant",
        "cultivar",
        "habitats",
    )
    raw_id_fields = ("traits", "data_extra")
    search_fields = ("name",)

@admin.register(OrganismsSubset)
class OrganismsSubsetAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "description",
        "organismssubset_id",
    )
    list_filter = ("namespace",)
    raw_id_fields = ("organisms",)
    search_fields = ("name",)