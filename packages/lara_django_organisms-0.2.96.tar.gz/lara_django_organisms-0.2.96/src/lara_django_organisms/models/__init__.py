"""Models package for lara_django_organisms.

This package contains all models organized into logical modules:
- base: Generic/base models (ExtraData, Trait)
- habitat: Habitat-related models (HabitatClass, HabitatParameter, Habitat)
- taxonomy: Taxonomic hierarchy models (Domain, Regnum, Phylum, etc.)
- organisms: Main organism models (Organism, OrganismsSubset, OrderedOrganismsSubset)

:authors: mark doerr <mark.doerr@uni-greifswald.de>
"""

from django.conf import settings

# Import base models
from .base import ExtraData, Trait

# Import habitat models
from .habitat import Habitat, HabitatClass, HabitatParameter

# Import organisms models
from .organisms import OrderedOrganismsSubset, Organism, OrganismsSubset

# Import taxonomy models
from .taxonomy import (
    Classis,
    Cultivar,
    Domain,
    Familia,
    Genus,
    Ordo,
    Phylum,
    Regnum,
    Species,
    Subspecies,
    Variant,
)

# Configure fixtures
settings.FIXTURES += [
    "1_habitat_class_fix",
    "2_domain_fix",
    "3_regnum_fix",
    # "4_phylum_fix",
    # "5_classis_fix",
    # "6_ordo_fix",
    "7_familia_fix",
    "8_genus_fix",
    # "9_species_fix",
    # "10_subspecies_fix",
    # "11_variant_fix",
    # "12_cultivar_fix",
]

__all__ = [
    # Base models
    "ExtraData",
    "Trait",
    # Habitat models
    "HabitatClass",
    "HabitatParameter",
    "Habitat",
    # Taxonomy models
    "Domain",
    "Regnum",
    "Phylum",
    "Classis",
    "Ordo",
    "Familia",
    "Genus",
    "Species",
    "Subspecies",
    "Variant",
    "Cultivar",
    # Organism models
    "Organism",
    "OrganismsSubset",
    "OrderedOrganismsSubset",
]
