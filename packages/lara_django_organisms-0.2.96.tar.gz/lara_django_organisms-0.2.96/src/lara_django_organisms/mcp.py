"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_organisms Model Context Protocol (MCP) handler *

:details: lara_django_organisms Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

from mcp_server import ModelQueryToolset

from .models import (
    Classis,
    Cultivar,
    Domain,
    ExtraData,
    Familia,
    Genus,
    Habitat,
    HabitatClass,
    HabitatParameter,
    OrderedOrganismsSubset,
    Ordo,
    Organism,
    OrganismsSubset,
    Phylum,
    Regnum,
    Species,
    Subspecies,
    Trait,
    Variant,
)


class ExtraDataQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ExtraData`."""

    model = ExtraData


class HabitatClassQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `HabitatClass`."""

    model = HabitatClass


class HabitatParameterQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `HabitatParameter`."""

    model = HabitatParameter


class HabitatQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Habitat`."""

    model = Habitat


class TraitQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Trait`."""

    model = Trait


class DomainQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Domain`."""

    model = Domain


class RegnumQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Regnum`."""

    model = Regnum


class PhylumQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Phylum`."""

    model = Phylum


class ClassisQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Classis`."""

    model = Classis


class OrdoQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Ordo`."""

    model = Ordo


class FamiliaQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Familia`."""

    model = Familia


class GenusQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Genus`."""

    model = Genus


class SpeciesQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Species`."""

    model = Species


class SubspeciesQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Subspecies`."""

    model = Subspecies


class VariantQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Variant`."""

    model = Variant


class CultivarQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Cultivar`."""

    model = Cultivar


class OrganismQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Organism`."""

    model = Organism


class OrganismsSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrganismsSubset`."""

    model = OrganismsSubset


class OrderedOrganismsSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrderedOrganismsSubset`."""

    model = OrderedOrganismsSubset
