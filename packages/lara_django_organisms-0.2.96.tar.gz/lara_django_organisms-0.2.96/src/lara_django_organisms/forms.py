"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms forms *

:details: lara_django_organisms forms module with DaisyUI styling.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev forms_generator -c lara_django_organisms > forms.py" to update this file
________________________________________________________________________
"""
# django crispy forms s. https://github.com/django-crispy-forms/django-crispy-forms for []
# generated with django-extensions forms_generator -c  [] > forms.py (LARA-version)

from typing import ClassVar

from django import forms
from django.forms.renderers import TemplatesSetting

from .models import (
    Classis,
    Cultivar,
    Domain,
    ExtraData,
    Familia,
    Genus,
    Habitat,
    HabitatClass,
    HabitatParameter,
    Ordo,
    Organism,
    Phylum,
    Regnum,
    Species,
    Subspecies,
    Trait,
    Variant,
)


class CustomFormRenderer(TemplatesSetting):
    """Custom form renderer for LARA forms."""
    
    field_template_name = "lara_django_organisms/forms/field_group.html"


class SearchableSelectMultiple(forms.SelectMultiple):
    """Custom widget for searchable multi-select using Alpine.js."""
    
    template_name = "lara_django_organisms/widgets/searchable_select_multiple.html"
    
    def __init__(self, attrs=None):
        default_attrs = {"class": "searchable-select-multiple"}
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs)


## -------------- ExtraData -------------- ##


class ExtraDataCreateForm(forms.ModelForm):
    """Form for creating new ExtraData with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
        )

        text_fields_required: ClassVar = ("data_type", "name_display")

        text_fields: ClassVar = (
            "name",
            "name_full",
            "version",
            "hash_sha256",
            "media_type",
        )

        textarea_fields: ClassVar = ("data_json", "description")

        url_fields: ClassVar = ("iri", "url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class ExtraDataUpdateForm(forms.ModelForm):
    """Form for updating existing ExtraData with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
        )

        text_fields_required: ClassVar = ("data_type", "name_display")

        text_fields: ClassVar = (
            "name",
            "name_full",
            "version",
            "hash_sha256",
            "media_type",
        )

        textarea_fields: ClassVar = ("data_json", "description")

        url_fields: ClassVar = ("iri", "url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


## -------------- HabitatClass -------------- ##


class HabitatClassCreateForm(forms.ModelForm):
    """Form for creating new HabitatClass."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = HabitatClass
        fields = ("name", "iri", "description")

        text_fields_required: ClassVar = ("name",)

        textarea_fields: ClassVar = ("description",)

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
        }


class HabitatClassUpdateForm(forms.ModelForm):
    """Form for updating existing HabitatClass."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = HabitatClass
        fields = ("name", "iri", "description")

        text_fields_required: ClassVar = ("name",)

        textarea_fields: ClassVar = ("description",)

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
        }


## -------------- HabitatParameter -------------- ##


class HabitatParameterCreateForm(forms.ModelForm):
    """Form for creating new HabitatParameter."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = HabitatParameter
        fields = ("name_display", "name", "iri", "value_range", "unit", "data_extra", "description")

        text_fields_required: ClassVar = ("name_display", "name")

        textarea_fields: ClassVar = ("value_range", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "unit": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
        }


class HabitatParameterUpdateForm(forms.ModelForm):
    """Form for updating existing HabitatParameter."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = HabitatParameter
        fields = ("name_display", "name", "iri", "value_range", "unit", "data_extra", "description")

        text_fields_required: ClassVar = ("name_display", "name")

        textarea_fields: ClassVar = ("value_range", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "unit": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
        }


## -------------- Habitat -------------- ##


class HabitatCreateForm(forms.ModelForm):
    """Form for creating new Habitat."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Habitat
        fields = ("name_display", "name", "iri", "habitat_class", "parameters", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name",)

        textarea_fields: ClassVar = ("description",)

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "habitat_class": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "parameters": SearchableSelectMultiple(),
        }


class HabitatUpdateForm(forms.ModelForm):
    """Form for updating existing Habitat."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Habitat
        fields = ("name_display", "name", "iri", "habitat_class", "parameters", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name",)

        textarea_fields: ClassVar = ("description",)

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "habitat_class": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "parameters": SearchableSelectMultiple(),
        }


## -------------- Trait -------------- ##


class TraitCreateForm(forms.ModelForm):
    """Form for creating new Trait."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Trait
        fields = ("name_display", "name", "value_range", "characteristics", "unit", "iri", "description")

        text_fields_required: ClassVar = ("name_display", "name")

        textarea_fields: ClassVar = ("value_range", "characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "unit": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


class TraitUpdateForm(forms.ModelForm):
    """Form for updating existing Trait."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Trait
        fields = ("name_display", "name", "value_range", "characteristics", "unit", "iri", "description")

        text_fields_required: ClassVar = ("name_display", "name")

        textarea_fields: ClassVar = ("value_range", "characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "unit": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
        }


## -------------- Domain -------------- ##


class DomainCreateForm(forms.ModelForm):
    """Form for creating new Domain."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Domain
        fields = ("name_display", "name", "iri", "traits", "characteristics", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name",)

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class DomainUpdateForm(forms.ModelForm):
    """Form for updating existing Domain."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Domain
        fields = ("name_display", "name", "iri", "traits", "characteristics", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name",)

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Regnum -------------- ##


class RegnumCreateForm(forms.ModelForm):
    """Form for creating new Regnum."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Regnum
        fields = ("name_display", "name", "iri", "traits", "characteristics", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name",)

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class RegnumUpdateForm(forms.ModelForm):
    """Form for updating existing Regnum."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Regnum
        fields = ("name_display", "name", "iri", "traits", "characteristics", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name",)

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Phylum -------------- ##


class PhylumCreateForm(forms.ModelForm):
    """Form for creating new Phylum."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Phylum
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class PhylumUpdateForm(forms.ModelForm):
    """Form for updating existing Phylum."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Phylum
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Classis -------------- ##


class ClassisCreateForm(forms.ModelForm):
    """Form for creating new Classis."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Classis
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class ClassisUpdateForm(forms.ModelForm):
    """Form for updating existing Classis."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Classis
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Ordo -------------- ##


class OrdoCreateForm(forms.ModelForm):
    """Form for creating new Ordo."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Ordo
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class OrdoUpdateForm(forms.ModelForm):
    """Form for updating existing Ordo."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Ordo
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Familia -------------- ##


class FamiliaCreateForm(forms.ModelForm):
    """Form for creating new Familia."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Familia
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class FamiliaUpdateForm(forms.ModelForm):
    """Form for updating existing Familia."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Familia
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Genus -------------- ##


class GenusCreateForm(forms.ModelForm):
    """Form for creating new Genus."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Genus
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class GenusUpdateForm(forms.ModelForm):
    """Form for updating existing Genus."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Genus
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Species -------------- ##


class SpeciesCreateForm(forms.ModelForm):
    """Form for creating new Species."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Species
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class SpeciesUpdateForm(forms.ModelForm):
    """Form for updating existing Species."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Species
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Subspecies -------------- ##


class SubspeciesCreateForm(forms.ModelForm):
    """Form for creating new Subspecies."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Subspecies
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class SubspeciesUpdateForm(forms.ModelForm):
    """Form for updating existing Subspecies."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Subspecies
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Variant -------------- ##


class VariantCreateForm(forms.ModelForm):
    """Form for creating new Variant."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Variant
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class VariantUpdateForm(forms.ModelForm):
    """Form for updating existing Variant."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Variant
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Cultivar -------------- ##


class CultivarCreateForm(forms.ModelForm):
    """Form for creating new Cultivar."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Cultivar
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


class CultivarUpdateForm(forms.ModelForm):
    """Form for updating existing Cultivar."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Cultivar
        fields = ("name_display", "name", "name_common", "traits", "characteristics", "iri", "description")

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "traits": SearchableSelectMultiple(),
        }


## -------------- Organism -------------- ##


class OrganismCreateForm(forms.ModelForm):
    """Form for creating new Organism."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Organism
        fields = (
            "name_display",
            "name",
            "name_common",
            "iri",
            "pac_id",
            "domain",
            "regnum",
            "phylum",
            "classis",
            "ordo",
            "familia",
            "genus",
            "species",
            "subspecies",
            "variant",
            "cultivar",
            "habitats",
            "organisms",
            "traits",
            "characteristics",
            "genome",
            "hybrid",
            "chimera",
            "description",
            "data_extra",
            "tags",
        )

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri", "pac_id", "genome")

        boolean_fields: ClassVar = ("hybrid", "chimera")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            **{
                field: forms.CheckboxInput(attrs={"class": "checkbox checkbox-sm"})
                for field in boolean_fields
            },
            "domain": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "regnum": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "phylum": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "classis": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "ordo": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "familia": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "genus": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "species": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "subspecies": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "variant": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "cultivar": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "habitats": SearchableSelectMultiple(),
            "organisms": SearchableSelectMultiple(),
            "traits": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
        }


class OrganismUpdateForm(forms.ModelForm):
    """Form for updating existing Organism."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Organism
        fields = (
            "name_display",
            "name",
            "name_common",
            "iri",
            "pac_id",
            "domain",
            "regnum",
            "phylum",
            "classis",
            "ordo",
            "familia",
            "genus",
            "species",
            "subspecies",
            "variant",
            "cultivar",
            "habitats",
            "organisms",
            "traits",
            "characteristics",
            "genome",
            "hybrid",
            "chimera",
            "description",
            "data_extra",
            "tags",
        )

        text_fields_required: ClassVar = ("name_display",)

        text_fields: ClassVar = ("name", "name_common")

        textarea_fields: ClassVar = ("characteristics", "description")

        url_fields: ClassVar = ("iri", "pac_id", "genome")

        boolean_fields: ClassVar = ("hybrid", "chimera")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            **{
                field: forms.CheckboxInput(attrs={"class": "checkbox checkbox-sm"})
                for field in boolean_fields
            },
            "domain": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "regnum": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "phylum": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "classis": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "ordo": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "familia": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "genus": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "species": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "subspecies": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "variant": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "cultivar": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "habitats": SearchableSelectMultiple(),
            "organisms": SearchableSelectMultiple(),
            "traits": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
        }
