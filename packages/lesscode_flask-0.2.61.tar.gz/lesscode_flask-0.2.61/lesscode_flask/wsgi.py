# -*- coding: utf-8 -*-
# 解决MonkeyPatchWarning
import logging
import os
import platform
from importlib import import_module

import psutil

# from gevent import monkey  # 导入补丁模块

# 创建补丁
# from funcy import iteritems
try:
    gunicorn_app_base = import_module("gunicorn.app.base")
except ImportError as e:
    raise Exception(f"gunicorn is not exist,run:pip install gunicorn==23.0.0")

try:
    gevent_monkey = import_module("gevent.monkey")
except ImportError as e:
    raise Exception(f"gevent is not exist,run:pip install gevent==24.10.2")

gevent_monkey.patch_all()


class Application(gunicorn_app_base.BaseApplication):
    def __init__(self, app):
        self.app = app
        self.platform_system = platform.system()  # Linux, Windows, Darwin(macOS)

        # 检测是否在容器环境中运行
        is_container = self._is_running_in_container()

        # 获取CPU和内存资源
        if is_container:
            cpu_count = self._get_container_cpu_limit()
            mem_total = self._get_container_memory_limit()
            env_type = "container"
        else:
            cpu_count = os.cpu_count() or 4  # 默认4核
            mem_info = psutil.virtual_memory()
            mem_total = mem_info.total // (1024 * 1024)
            env_type = "physical"

        # 动态计算Worker数量（根据内存适配）
        if mem_total < 2048:  # 内存 < 2G
            workers = 1
        elif mem_total < 4096:  # 内存 2G-4G
            workers = min(cpu_count, 2)
        elif mem_total < 8192:  # 内存 4G-8G
            workers = min(cpu_count * 2, cpu_count + 2)
        else:  # 内存 >=8G
            workers = min(cpu_count * 2 + 1, cpu_count + 4)

        logging.info(
            f"Platform: {self.platform_system}, Environment: {env_type}, CPU: {cpu_count}, Memory: {mem_total}MB, Workers: {workers}")
        options = {
            'bind': f"0.0.0.0:{app.config.get('PORT', 5002)}",  # 绑定地址和端口
            'workers': workers,  # 指定 workers 数量
            'accesslog': "-",  # 输出到标准输出，取消gunicorn接管日志输出
            'worker_class': 'gevent',  # worker 运行方式
            'timeout': 300
        }
        self.options = options
        super(Application, self).__init__()
        self.application = None
        # self.logger = logging  # 自定义一直输出，如果项目中已经使用了其他的日志框架，而不想让gunicorn接管日志输出，需要将日志框架的对象指定给这里

    def _is_running_in_container(self):
        """检测是否在容器环境中运行（支持Docker、Kubernetes等）"""
        # 非Linux系统，仅通过环境变量检测
        if self.platform_system != 'Linux':
            return bool(os.getenv('KUBERNETES_SERVICE_HOST') or os.getenv('DOCKER_CONTAINER'))

        # Linux系统：检查 /.dockerenv 文件（Docker特征）
        if os.path.exists('/.dockerenv'):
            return True

        # 检查 cgroup 文件（容器通用特征）
        try:
            with open('/proc/1/cgroup', 'r') as f:
                content = f.read()
                if 'docker' in content or 'kubepods' in content or 'containerd' in content:
                    return True
        except (FileNotFoundError, PermissionError):
            pass

        # 检查环境变量（Kubernetes特征）
        if os.getenv('KUBERNETES_SERVICE_HOST'):
            return True

        return False

    def _get_container_cpu_limit(self):
        """获取容器CPU限制（支持cgroups v1和v2）"""
        cpu_count = os.cpu_count() or 4

        try:
            # 尝试读取 cgroups v2 (统一层级)
            cpu_max_path = '/sys/fs/cgroup/cpu.max'
            if os.path.exists(cpu_max_path):
                with open(cpu_max_path, 'r') as f:
                    content = f.read().strip().split()
                    if content[0] != 'max':
                        quota = int(content[0])
                        period = int(content[1])
                        cpu_limit = quota / period
                        return max(1, int(cpu_limit))

            # 尝试读取 cgroups v1
            quota_path = '/sys/fs/cgroup/cpu/cpu.cfs_quota_us'
            period_path = '/sys/fs/cgroup/cpu/cpu.cfs_period_us'
            if os.path.exists(quota_path) and os.path.exists(period_path):
                with open(quota_path, 'r') as f:
                    quota = int(f.read().strip())
                with open(period_path, 'r') as f:
                    period = int(f.read().strip())
                if quota > 0 and period > 0:
                    cpu_limit = quota / period
                    return max(1, int(cpu_limit))

        except (FileNotFoundError, PermissionError, ValueError):
            pass

        return cpu_count

    def _get_container_memory_limit(self):
        """获取容器内存限制（支持cgroups v1和v2），单位MB"""
        try:
            # 尝试读取 cgroups v2
            mem_max_path = '/sys/fs/cgroup/memory.max'
            if os.path.exists(mem_max_path):
                with open(mem_max_path, 'r') as f:
                    content = f.read().strip()
                    if content != 'max':
                        mem_bytes = int(content)
                        return mem_bytes // (1024 * 1024)

            # 尝试读取 cgroups v1
            mem_limit_path = '/sys/fs/cgroup/memory/memory.limit_in_bytes'
            if os.path.exists(mem_limit_path):
                with open(mem_limit_path, 'r') as f:
                    mem_bytes = int(f.read().strip())
                    # 检查是否为实际限制（不是最大值）
                    if mem_bytes < (1 << 62):  # 小于一个很大的数，说明有实际限制
                        return mem_bytes // (1024 * 1024)

        except (FileNotFoundError, PermissionError, ValueError):
            pass

        # 回退到物理内存
        mem_info = psutil.virtual_memory()
        return mem_info.total // (1024 * 1024)

    def load_config(self):
        try:
            funcy = import_module("funcy")
        except ImportError:
            raise Exception(f"pystache is not exist,run:pip install pystache==0.6.5")
        config = {key: value for key, value in funcy.iteritems(self.options)
                  if key in self.cfg.settings and value is not None}
        for key, value in funcy.iteritems(config):
            self.cfg.set(key.lower(), value)

    def load(self):
        return self.app
