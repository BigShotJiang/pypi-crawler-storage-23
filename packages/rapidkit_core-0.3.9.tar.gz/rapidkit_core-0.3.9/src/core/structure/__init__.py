"""Core structure components for RapidKit.

This module contains structure building functionality.
"""

from typing import List as _List

__all__: _List[str] = []
