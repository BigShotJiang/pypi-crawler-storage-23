"""NestJS framework plugin for the Cart module."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Mapping

from modules.shared.frameworks import FrameworkPlugin

MODULE_BASE = "src/modules/free/billing/cart"


class NestJSPlugin(FrameworkPlugin):
    """Generate NestJS bindings for the Cart runtime."""

    @property
    def name(self) -> str:  # noqa: D401 - short alias
        return "nestjs"

    @property
    def language(self) -> str:  # noqa: D401 - short alias
        return "typescript"

    @property
    def display_name(self) -> str:  # noqa: D401 - short alias
        return "NestJS"

    def get_template_mappings(self) -> Dict[str, str]:
        return {
            "service": "templates/variants/nestjs/cart.service.ts.j2",
            "controller": "templates/variants/nestjs/cart.controller.ts.j2",
            "module": "templates/variants/nestjs/cart.module.ts.j2",
            "configuration": "templates/variants/nestjs/cart.configuration.ts.j2",
            "health": "templates/variants/nestjs/cart.health.ts.j2",
            "routes": "templates/variants/nestjs/cart.routes.ts.j2",
            "tests": "templates/variants/nestjs/cart.spec.ts.j2",
        }

    def get_output_paths(self) -> Dict[str, str]:
        return {
            "service": f"{MODULE_BASE}/cart.service.ts",
            "controller": f"{MODULE_BASE}/cart.controller.ts",
            "module": f"{MODULE_BASE}/cart.module.ts",
            "configuration": f"{MODULE_BASE}/cart.configuration.ts",
            "health": f"{MODULE_BASE}/cart.health.ts",
            "routes": f"{MODULE_BASE}/cart.routes.ts",
            "tests": "test/cart/cart.spec.ts",
        }

    def get_context_enrichments(self, base_context: Mapping[str, Any]) -> Dict[str, Any]:
        return {
            **base_context,
            "framework": "nestjs",
            "framework_display_name": "NestJS",
            "language": "typescript",
        }

    def validate_requirements(self) -> List[str]:
        return []

    def pre_generation_hook(self, output_dir: Path) -> None:
        (output_dir / "src" / "modules" / "free" / "billing" / "cart").mkdir(
            parents=True, exist_ok=True
        )
        (output_dir / "nestjs").mkdir(parents=True, exist_ok=True)
        (output_dir / "test" / "cart").mkdir(parents=True, exist_ok=True)

    def post_generation_hook(self, output_dir: Path) -> None:  # noqa: ARG002
        return None

    def get_documentation_urls(self) -> Dict[str, str]:
        return {
            "nestjs": "https://docs.nestjs.com/",
        }

    def get_example_configurations(self) -> Dict[str, Any]:
        return {
            "cart": {
                "providers": ["CartService"],
                "controllers": ["CartController"],
            }
        }

    def get_dependencies(self) -> List[str]:
        return [
            "@nestjs/common",
            "@nestjs/core",
        ]

    def get_dev_dependencies(self) -> List[str]:
        return [
            "typescript",
        ]


__all__ = ["NestJSPlugin"]
