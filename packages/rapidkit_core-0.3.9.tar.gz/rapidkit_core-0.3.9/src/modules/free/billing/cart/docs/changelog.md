# Changelog — free/billing/cart

## 0.1.5 — Automated patch release triggered by content hash change (2026-02-11)

- chore: Automated patch release triggered by content hash change

## 0.1.4 — Automated patch release triggered by content hash change (2026-01-04)

- chore: Automated patch release triggered by content hash change

## 0.1.3 — Automated patch release triggered by content hash change (2025-12-15)

- chore: Automated patch release triggered by content hash change

## 0.1.2 — Automated patch release triggered by content hash change (2025-12-15)

- chore: Automated patch release triggered by content hash change

## 0.1.1 — Automated patch release triggered by content hash change (2025-12-14)

- chore: Automated patch release triggered by content hash change

## 0.1.0 — Initial baseline (2025-12-04)

- Initial public baseline.
