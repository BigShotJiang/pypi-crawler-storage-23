# Migration

Track upgrade guidance between Inventory releases.

## Breaking Changes

No breaking changes have been recorded yet.
