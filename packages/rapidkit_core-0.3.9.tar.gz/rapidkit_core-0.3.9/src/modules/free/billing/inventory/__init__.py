"""Runtime package for the Inventory module."""

__all__ = ["InventoryService"]
