# Changelog — free/auth/api_keys

## 0.1.1 — Automated patch release triggered by content hash change (2026-02-11)

- chore: Automated patch release triggered by content hash change

## 0.1.0 — Initial baseline (2025-12-04)

- Initial public baseline.
