# Changelog — free/auth/core

## 0.1.10 — Automated patch release triggered by content hash change (2026-02-15)

- chore: Automated patch release triggered by content hash change

## 0.1.9 — Automated patch release triggered by content hash change (2026-02-15)

- chore: Automated patch release triggered by content hash change

## 0.1.8 — Automated patch release triggered by content hash change (2026-02-15)

- chore: Automated patch release triggered by content hash change

## 0.1.7 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.6 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.5 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.4 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.3 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.2 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.1 — Automated patch release triggered by content hash change (2026-02-11)

- chore: Automated patch release triggered by content hash change

## 0.1.0 — Initial baseline (2025-12-04)

- Initial public baseline.
