"""Auth core integration tests package placeholder."""
