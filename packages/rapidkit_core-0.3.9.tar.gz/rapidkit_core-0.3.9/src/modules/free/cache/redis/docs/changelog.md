# Changelog — free/cache/redis

## 0.1.17 — Automated patch release triggered by content hash change (2026-02-15)

- chore: Automated patch release triggered by content hash change

## 0.1.16 — Automated patch release triggered by content hash change (2026-02-15)

- chore: Automated patch release triggered by content hash change

## 0.1.15 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.14 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.13 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.12 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.11 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.10 — Automated patch release triggered by content hash change (2026-02-14)

- chore: Automated patch release triggered by content hash change

## 0.1.9 — Automated patch release triggered by content hash change (2026-02-11)

- chore: Automated patch release triggered by content hash change

## 0.1.8 — Migration: enforce canonical src.modules imports in redis health templates (2025-12-14)

- chore: Migration: enforce canonical src.modules imports in redis health templates

## 0.1.7 — Automated patch release triggered by content hash change (2025-12-10)

- chore: Automated patch release triggered by content hash change

## 0.1.6 — Automated patch release triggered by content hash change (2025-12-10)

- chore: Automated patch release triggered by content hash change

## 0.1.5 — Automated patch release triggered by content hash change (2025-12-10)

- chore: Automated patch release triggered by content hash change

## 0.1.4 — Automated patch release triggered by content hash change (2025-12-10)

- chore: Automated patch release triggered by content hash change

## 0.1.3 — Metadata alignment (2025-12-06)

- Fixed unit test manifest paths to point at `tests/modules/free/cache/redis` for doctor/parity
  runs.
- Regenerated module state to capture the corrected manifest.

## 0.1.0 — Initial baseline (2025-12-04)

- Initial public baseline.
