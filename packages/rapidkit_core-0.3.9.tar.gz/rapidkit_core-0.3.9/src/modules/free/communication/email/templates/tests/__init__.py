"""Test templates package for the Email module."""
