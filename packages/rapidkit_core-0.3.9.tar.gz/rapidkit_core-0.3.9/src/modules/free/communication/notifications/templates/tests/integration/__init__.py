"""Integration test templates for notifications module."""
