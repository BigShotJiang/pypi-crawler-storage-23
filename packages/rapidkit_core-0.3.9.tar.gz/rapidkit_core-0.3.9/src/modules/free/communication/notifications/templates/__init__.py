"""Notifications module templates package."""
