# Ai Assistant Troubleshooting

| Symptom       | Diagnostic Steps                               | Resolution                     |
| ------------- | ---------------------------------------------- | ------------------------------ |
| Example issue | `rapidkit modules doctor free/ai/ai_assistant` | Document the remediation steps |

Update the table as production incidents surface to build a reliable operational playbook.
