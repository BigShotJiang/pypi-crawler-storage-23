"""NestJS kit implementations for RapidKit."""
