from __future__ import annotations

from .reader_api.reader_api import ReaderAPIAdapter as ReaderAPIAdapter
