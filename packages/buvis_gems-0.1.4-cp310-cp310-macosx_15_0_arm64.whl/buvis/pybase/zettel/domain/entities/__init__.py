from __future__ import annotations

from .project.project import ProjectZettel
from .zettel.zettel import Zettel

__all__ = [
    "ProjectZettel",
    "Zettel",
]
