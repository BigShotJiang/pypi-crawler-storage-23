import logging
import jwt

from django.conf import settings
from zappa.websocket import on_connect, on_disconnect, send_message

logger = logging.getLogger(__name__)

def get_user_from_token(token: str):
    from django.contrib.auth import get_user_model
    User = get_user_model()
    
    try:
        from shared_auth.models import SharedToken
        drf_token = SharedToken.objects.filter(key=token).first()
        if drf_token:
            return drf_token.user
    except ImportError:
        pass
    
    return None

@on_connect
def handle_connect(event, context):
    request_context = event.get("requestContext", {})
    connection_id = request_context.get("connectionId")
    domain = request_context.get("domainName")
    stage = request_context.get("stage")
    
    endpoint_url = None
    if domain and stage:
        endpoint_url = f"https://{domain}/{stage}"
    
    # Busca o token na query string OU nos headers
    query_params = event.get("queryStringParameters") or {}
    token = query_params.get("token")
    
    if not token:
        headers = {k.lower(): v for k, v in event.get("headers", {}).items()}
        auth_header = headers.get("authorization", "")
        if auth_header.lower().startswith("token ") or auth_header.lower().startswith("bearer "):
            token = auth_header.split(" ", 1)[1]
            
    if not token:
        logger.warning(f"Connection {connection_id} refused: NO_TOKEN.")
        return {"statusCode": 401}
        
    user = get_user_from_token(token)
    if not user:
        logger.warning(f"Connection {connection_id} refused: INVALID_TOKEN.")
        return {"statusCode": 401}
        
    # Salva usando o model dinâmico para respeitar Intranet vs Lib
    try:
        from shared_auth.models import User
        from .models import SharedAuthWebSocketConnectionModel as ModelClass
    except ImportError:
        from .models import WebSocketConnectionModel as ModelClass
        
    ModelClass.objects.create(
        connection_id=connection_id,
        user_id=user.id,
        endpoint_url=endpoint_url
    )
    logger.info(f"dj-ws-zappa: Client connected: {connection_id} - User {user.id}")
    return {"statusCode": 200}

@on_disconnect
def handle_disconnect(event, context):
    connection_id = event.get("requestContext", {}).get("connectionId")
    
    try:
        from shared_auth.models import User
        from .models import SharedAuthWebSocketConnectionModel as ModelClass
    except ImportError:
        from .models import WebSocketConnectionModel as ModelClass
        
    ModelClass.objects.filter(connection_id=connection_id).delete()
    logger.info(f"dj-ws-zappa: Client disconnected: {connection_id}")
    return {"statusCode": 200}
