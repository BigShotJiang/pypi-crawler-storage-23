from django.db import models
from django.conf import settings
from shared_auth.mixins import OrganizationUserMixin, TimestampedMixin

class WebSocketConnectionModel(models.Model):
    """
    Modelo padrão sem dependências do shared_auth.
    """
    user_id = models.IntegerField(db_index=True)
    connection_id = models.CharField(max_length=255, unique=True, db_index=True)
    endpoint_url = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Conexão WebSocket"
        verbose_name_plural = "Conexões WebSocket"

    def __str__(self):
        return f"User {self.user_id} - {self.connection_id}"

class SharedAuthWebSocketConnectionModel(OrganizationUserMixin, TimestampedMixin):
    """
    Modelo estendido com os mixins do maquinaweb-shared-auth.
    """
    connection_id = models.CharField(max_length=255, unique=True, db_index=True)

    class Meta:
        verbose_name = "Conexão WebSocket (Shared Auth)"
        verbose_name_plural = "Conexões WebSocket (Shared Auth)"

    def __str__(self):
        return f"User {self.user_id} - {self.connection_id}"
