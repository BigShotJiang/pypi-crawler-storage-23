mod resolver;

pub use resolver::{DohConfig, DohResolver, HttpsRecord};
