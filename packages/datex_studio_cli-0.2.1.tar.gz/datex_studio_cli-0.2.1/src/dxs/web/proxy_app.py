"""FastAPI proxy application for forwarding requests to Datex Studio apps."""

import json
import re
import sys
from collections.abc import Callable
from datetime import datetime
from pathlib import Path

import httpx
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse


def load_persisted_tokens(tokens_path: Path) -> dict[str, str | None]:
    """Load tokens from disk if they exist."""
    tokens: dict[str, str | None] = {
        "access_token": None,
        "refresh_token": None,
        "id_token": None,
    }
    if tokens_path.exists():
        try:
            with open(tokens_path) as f:
                data = json.load(f)
                tokens["access_token"] = data.get("access_token")
                tokens["refresh_token"] = data.get("refresh_token")
                tokens["id_token"] = data.get("id_token")
        except (json.JSONDecodeError, OSError):
            pass
    return tokens


def save_tokens_to_disk(tokens: dict[str, str | None], tokens_path: Path) -> None:
    """Save tokens to disk with secure permissions."""
    try:
        with open(tokens_path, "w") as f:
            json.dump(
                {
                    "access_token": tokens.get("access_token"),
                    "refresh_token": tokens.get("refresh_token"),
                    "id_token": tokens.get("id_token"),
                    "saved_at": datetime.now().isoformat(),
                },
                f,
                indent=2,
            )
        # Set secure permissions (owner read/write only)
        tokens_path.chmod(0o600)
    except OSError:
        pass

# ANSI color codes for terminal output
_COLORS = {
    "reset": "\033[0m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "red": "\033[31m",
    "cyan": "\033[36m",
    "dim": "\033[2m",
}


def _log(
    method: str,
    path: str,
    status: int | None = None,
    upstream_url: str | None = None,
    error: str | None = None,
) -> None:
    """Log a proxy request to stderr."""
    timestamp = datetime.now().strftime("%H:%M:%S")

    # Color code based on status
    if error:
        status_color = _COLORS["red"]
        status_text = f"ERR {error}"
    elif status is None:
        status_color = _COLORS["cyan"]
        status_text = ">>>"
    elif 200 <= status < 300:
        status_color = _COLORS["green"]
        status_text = str(status)
    elif 400 <= status < 500:
        status_color = _COLORS["yellow"]
        status_text = str(status)
    else:
        status_color = _COLORS["red"]
        status_text = str(status)

    # Build log line
    line = (
        f"{_COLORS['dim']}{timestamp}{_COLORS['reset']} "
        f"{status_color}{status_text:>3}{_COLORS['reset']} "
        f"{method:7} {path}"
    )

    if upstream_url:
        line += f" {_COLORS['dim']}-> {upstream_url}{_COLORS['reset']}"

    print(line, file=sys.stderr)


# Headers to forward from client to upstream
_FORWARD_HEADERS = {
    "content-type",
    "accept",
    "accept-language",
    "accept-encoding",
    "cache-control",
    "pragma",
}

# Headers that start with these prefixes are forwarded
_FORWARD_PREFIXES = ("x-",)

# Hop-by-hop headers that should never be forwarded
_HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
}


def create_proxy_app(
    target_url: str,
    api_key: str,
    get_token_func: Callable[[], str],
) -> FastAPI:
    """Create a FastAPI proxy application.

    Args:
        target_url: The target URL to forward requests to (e.g., https://footprint.acme.io/)
        api_key: The API key required for authentication
        get_token_func: Function to get the Datex auth token

    Returns:
        Configured FastAPI application
    """
    app = FastAPI(title="Datex Proxy", docs_url=None, redoc_url=None)

    def _validate_api_key(request: Request) -> bool:
        """Validate API key from request headers.

        Accepts either:
        - X-API-Key header
        - Authorization: Bearer <key>
        """
        # Check X-API-Key header
        x_api_key = request.headers.get("x-api-key")
        if x_api_key == api_key:
            return True

        # Check Authorization: Bearer header
        auth_header = request.headers.get("authorization", "")
        if auth_header.lower().startswith("bearer "):
            bearer_token = auth_header[7:].strip()
            if bearer_token == api_key:
                return True

        return False

    def _filter_request_headers(request: Request) -> dict[str, str]:
        """Filter headers to forward to upstream."""
        headers: dict[str, str] = {}

        for name, value in request.headers.items():
            name_lower = name.lower()

            # Skip hop-by-hop and sensitive headers
            if name_lower in _HOP_BY_HOP_HEADERS:
                continue
            if name_lower in ("host", "authorization", "x-api-key"):
                continue

            # Forward allowed headers
            if name_lower in _FORWARD_HEADERS:
                headers[name] = value
            elif any(name_lower.startswith(prefix) for prefix in _FORWARD_PREFIXES):
                headers[name] = value

        return headers

    def _filter_response_headers(response: httpx.Response) -> dict[str, str]:
        """Filter headers to return to client."""
        headers: dict[str, str] = {}

        for name, value in response.headers.items():
            name_lower = name.lower()

            # Skip hop-by-hop headers
            if name_lower in _HOP_BY_HOP_HEADERS:
                continue
            # Skip content-encoding since httpx decodes for us
            if name_lower in ("content-encoding", "content-length"):
                continue

            headers[name] = value

        return headers

    @app.api_route(
        "/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]
    )
    async def proxy_request(request: Request, path: str) -> Response:
        """Forward request to target URL with Datex credentials."""
        request_path = f"/{path}"
        if request.url.query:
            request_path = f"{request_path}?{request.url.query}"

        # Validate API key
        if not _validate_api_key(request):
            _log(request.method, request_path, status=401, error="Invalid API key")
            return JSONResponse(
                status_code=401,
                content={
                    "error": "Unauthorized",
                    "message": "Invalid or missing API key",
                    "details": "Provide API key via X-API-Key header or Authorization: Bearer <key>",
                },
            )

        # Get Datex token
        try:
            datex_token = get_token_func()
        except Exception as e:
            _log(request.method, request_path, status=502, error="Token failed")
            return JSONResponse(
                status_code=502,
                content={
                    "error": "Bad Gateway",
                    "message": "Failed to acquire Datex authentication token",
                    "details": str(e),
                },
            )

        # Build upstream URL
        upstream_url = f"{target_url.rstrip('/')}/{path}"
        if request.url.query:
            upstream_url = f"{upstream_url}?{request.url.query}"

        # Build headers
        headers = _filter_request_headers(request)
        headers["Authorization"] = f"Bearer {datex_token}"

        # Get request body
        body = await request.body()

        # Forward request
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.request(
                    method=request.method,
                    url=upstream_url,
                    headers=headers,
                    content=body if body else None,
                    follow_redirects=True,
                )

            # Log the request and response
            _log(request.method, request_path, status=response.status_code, upstream_url=upstream_url)

            # Build response headers
            response_headers = _filter_response_headers(response)

            # Return streaming response
            return StreamingResponse(
                iter([response.content]),
                status_code=response.status_code,
                headers=response_headers,
                media_type=response.headers.get("content-type"),
            )

        except httpx.TimeoutException:
            _log(request.method, request_path, status=504, error="Timeout")
            return JSONResponse(
                status_code=504,
                content={
                    "error": "Gateway Timeout",
                    "message": "Request to upstream server timed out",
                },
            )
        except httpx.RequestError as e:
            _log(request.method, request_path, status=502, error=str(e)[:30])
            return JSONResponse(
                status_code=502,
                content={
                    "error": "Bad Gateway",
                    "message": "Failed to connect to upstream server",
                    "details": str(e),
                },
            )

    @app.get("/")
    async def root_proxy(request: Request) -> Response:
        """Handle root path proxy."""
        request_path = "/"
        if request.url.query:
            request_path = f"/?{request.url.query}"

        # Validate API key
        if not _validate_api_key(request):
            _log(request.method, request_path, status=401, error="Invalid API key")
            return JSONResponse(
                status_code=401,
                content={
                    "error": "Unauthorized",
                    "message": "Invalid or missing API key",
                    "details": "Provide API key via X-API-Key header or Authorization: Bearer <key>",
                },
            )

        # Get Datex token
        try:
            datex_token = get_token_func()
        except Exception as e:
            _log(request.method, request_path, status=502, error="Token failed")
            return JSONResponse(
                status_code=502,
                content={
                    "error": "Bad Gateway",
                    "message": "Failed to acquire Datex authentication token",
                    "details": str(e),
                },
            )

        # Build upstream URL
        upstream_url = target_url.rstrip("/")
        if request.url.query:
            upstream_url = f"{upstream_url}?{request.url.query}"

        # Build headers
        headers = _filter_request_headers(request)
        headers["Authorization"] = f"Bearer {datex_token}"

        # Forward request
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.request(
                    method=request.method,
                    url=upstream_url,
                    headers=headers,
                    follow_redirects=True,
                )

            # Log the request and response
            _log(request.method, request_path, status=response.status_code, upstream_url=upstream_url)

            response_headers = _filter_response_headers(response)

            return StreamingResponse(
                iter([response.content]),
                status_code=response.status_code,
                headers=response_headers,
                media_type=response.headers.get("content-type"),
            )

        except httpx.TimeoutException:
            _log(request.method, request_path, status=504, error="Timeout")
            return JSONResponse(
                status_code=504,
                content={
                    "error": "Gateway Timeout",
                    "message": "Request to upstream server timed out",
                },
            )
        except httpx.RequestError as e:
            _log(request.method, request_path, status=502, error=str(e)[:30])
            return JSONResponse(
                status_code=502,
                content={
                    "error": "Bad Gateway",
                    "message": "Failed to connect to upstream server",
                    "details": str(e),
                },
            )

    return app


def create_transparent_proxy_app(
    target_url: str,
    token_endpoint_patterns: list[str] | None = None,
    tokens_path: Path | None = None,
    api_key: str | None = None,
) -> FastAPI:
    """Create a transparent proxy that intercepts OAuth tokens.

    This proxy:
    1. Forwards all requests to the target without requiring authentication
    2. Intercepts responses from OAuth token endpoints
    3. Captures and stores access/refresh tokens
    4. Injects captured tokens into subsequent API requests

    Args:
        target_url: The target URL to proxy (e.g., https://footprint.acme.io/)
        token_endpoint_patterns: URL patterns that indicate token responses
            (default: common Azure AD token endpoints)

    Returns:
        Configured FastAPI application
    """
    app = FastAPI(title="Datex Transparent Proxy", docs_url=None, redoc_url=None)

    # Default token endpoint patterns (Azure AD)
    if token_endpoint_patterns is None:
        token_endpoint_patterns = [
            "/oauth2/v2.0/token",
            "/oauth2/token",
            "login.microsoftonline.com",
        ]

    # Token storage - load from disk if available
    captured_tokens: dict[str, str | None]
    if tokens_path:
        captured_tokens = load_persisted_tokens(tokens_path)
        if captured_tokens.get("access_token"):
            print(
                f"{_COLORS['green']}✓ Loaded persisted tokens from {tokens_path}{_COLORS['reset']}",
                file=sys.stderr,
            )
    else:
        captured_tokens = {
            "access_token": None,
            "refresh_token": None,
            "id_token": None,
        }

    def _save_tokens() -> None:
        """Save tokens to disk if persistence is enabled."""
        if tokens_path:
            save_tokens_to_disk(captured_tokens, tokens_path)

    def _is_token_endpoint(url: str) -> bool:
        """Check if URL matches a token endpoint pattern."""
        return any(pattern in url for pattern in token_endpoint_patterns)

    def _validate_api_key(request: Request) -> bool:
        """Validate API key from request headers (if API key is required).

        Returns True if:
        - No API key is configured (login mode), OR
        - Request has valid X-API-Key header, OR
        - Request has valid Authorization: Bearer <api_key>
        """
        if api_key is None:
            return True  # No API key required (login mode)

        # Check X-API-Key header
        x_api_key = request.headers.get("x-api-key")
        if x_api_key == api_key:
            return True

        # Check Authorization: Bearer header (but only if it matches our API key)
        auth_header = request.headers.get("authorization", "")
        if auth_header.lower().startswith("bearer "):
            bearer_token = auth_header[7:].strip()
            if bearer_token == api_key:
                return True

        return False

    # JavaScript to inject into HTML pages to intercept token responses
    _TOKEN_CAPTURE_SCRIPT = """
<script>
(function() {
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        const response = await originalFetch.apply(this, args);
        const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';

        // Check if this is a token endpoint response
        if (url.includes('login.microsoftonline.com') && url.includes('/oauth2/')) {
            try {
                const clone = response.clone();
                const data = await clone.json();
                if (data.access_token || data.refresh_token) {
                    // Send tokens to proxy capture endpoint
                    fetch('/_proxy/capture', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            access_token: data.access_token,
                            refresh_token: data.refresh_token,
                            id_token: data.id_token,
                            expires_in: data.expires_in
                        })
                    }).catch(() => {});
                }
            } catch (e) {}
        }
        return response;
    };
    console.log('[Datex Proxy] Token capture initialized');
})();
</script>
"""

    def _capture_token_from_request(request: Request) -> None:
        """Capture Bearer token from incoming request Authorization header."""
        auth_header = request.headers.get("authorization", "")
        if auth_header.lower().startswith("bearer "):
            token = auth_header[7:].strip()
            if token and token != captured_tokens["access_token"]:
                captured_tokens["access_token"] = token
                print(
                    f"{_COLORS['green']}✓ Captured access_token from request header{_COLORS['reset']}",
                    file=sys.stderr,
                )
                _save_tokens()

    def _extract_tokens_from_response(content: bytes, content_type: str | None) -> bool:
        """Extract tokens from response body. Returns True if tokens were found."""
        if not content_type or "json" not in content_type.lower():
            return False

        try:
            data = json.loads(content)
            found = False

            if "access_token" in data:
                captured_tokens["access_token"] = data["access_token"]
                print(
                    f"{_COLORS['green']}✓ Captured access_token{_COLORS['reset']}",
                    file=sys.stderr,
                )
                found = True

            if "refresh_token" in data:
                captured_tokens["refresh_token"] = data["refresh_token"]
                print(
                    f"{_COLORS['green']}✓ Captured refresh_token{_COLORS['reset']}",
                    file=sys.stderr,
                )
                found = True

            if "id_token" in data:
                captured_tokens["id_token"] = data["id_token"]
                print(
                    f"{_COLORS['green']}✓ Captured id_token{_COLORS['reset']}",
                    file=sys.stderr,
                )
                found = True

            return found
        except (json.JSONDecodeError, KeyError):
            return False

    def _filter_request_headers(request: Request, inject_token: bool = False) -> dict[str, str]:
        """Filter headers to forward to upstream."""
        headers: dict[str, str] = {}
        has_auth = False

        for name, value in request.headers.items():
            name_lower = name.lower()

            # Skip hop-by-hop headers
            if name_lower in _HOP_BY_HOP_HEADERS:
                continue
            if name_lower == "host":
                continue

            if name_lower == "authorization":
                has_auth = True

            headers[name] = value

        # Only inject captured token if request doesn't already have auth
        if inject_token and not has_auth and captured_tokens["access_token"]:
            headers["Authorization"] = f"Bearer {captured_tokens['access_token']}"

        return headers

    def _filter_response_headers(
        response: httpx.Response, request_host: str
    ) -> dict[str, str]:
        """Filter headers to return to client, rewriting redirects to localhost."""
        headers: dict[str, str] = {}

        for name, value in response.headers.items():
            name_lower = name.lower()

            # Skip hop-by-hop headers
            if name_lower in _HOP_BY_HOP_HEADERS:
                continue
            # Skip content-encoding since httpx decodes for us
            if name_lower in ("content-encoding", "content-length"):
                continue

            # Rewrite Location header to point to our proxy
            if name_lower == "location" and target_url.rstrip("/") in value:
                value = value.replace(target_url.rstrip("/"), f"http://{request_host}")

            headers[name] = value

        return headers

    @app.get("/_proxy/status")
    async def proxy_status() -> dict[str, object]:
        """Check proxy status and captured tokens."""
        return {
            "target_url": target_url,
            "has_access_token": captured_tokens["access_token"] is not None,
            "has_refresh_token": captured_tokens["refresh_token"] is not None,
            "has_id_token": captured_tokens["id_token"] is not None,
        }

    @app.post("/_proxy/clear")
    async def clear_tokens() -> dict[str, str]:
        """Clear captured tokens."""
        captured_tokens["access_token"] = None
        captured_tokens["refresh_token"] = None
        captured_tokens["id_token"] = None
        return {"status": "cleared"}

    @app.post("/_proxy/capture")
    async def capture_tokens(request: Request) -> dict[str, str]:
        """Receive tokens from injected JavaScript."""
        try:
            data = await request.json()
            captured_any = False
            if data.get("access_token"):
                captured_tokens["access_token"] = data["access_token"]
                print(
                    f"{_COLORS['green']}✓ Captured access_token via JS injection{_COLORS['reset']}",
                    file=sys.stderr,
                )
                captured_any = True
            if data.get("refresh_token"):
                captured_tokens["refresh_token"] = data["refresh_token"]
                print(
                    f"{_COLORS['green']}✓ Captured refresh_token via JS injection{_COLORS['reset']}",
                    file=sys.stderr,
                )
                captured_any = True
            if data.get("id_token"):
                captured_tokens["id_token"] = data["id_token"]
                print(
                    f"{_COLORS['green']}✓ Captured id_token via JS injection{_COLORS['reset']}",
                    file=sys.stderr,
                )
                captured_any = True
            if captured_any:
                _save_tokens()
            return {"status": "captured"}
        except Exception:
            return {"status": "error"}

    @app.api_route(
        "/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]
    )
    async def transparent_proxy(request: Request, path: str) -> Response:
        """Transparently proxy request, intercepting tokens."""
        request_path = f"/{path}"
        if request.url.query:
            request_path = f"{request_path}?{request.url.query}"

        # Validate API key if required (skip for _proxy endpoints)
        if not path.startswith("_proxy") and not _validate_api_key(request):
            _log(request.method, request_path, status=401, error="Invalid API key")
            return JSONResponse(
                status_code=401,
                content={
                    "error": "Unauthorized",
                    "message": "Invalid or missing API key",
                    "details": "Provide API key via X-API-Key header or Authorization: Bearer <key>",
                },
            )

        # Capture token from incoming request if present
        _capture_token_from_request(request)

        # Build upstream URL
        upstream_url = f"{target_url.rstrip('/')}/{path}"
        if request.url.query:
            upstream_url = f"{upstream_url}?{request.url.query}"

        # Check if this is an API request that needs the token injected
        # (requests to the target app's API, not to external auth endpoints)
        is_api_request = (
            target_url.rstrip("/") in upstream_url
            and not _is_token_endpoint(upstream_url)
            and ("api/" in path.lower() or path.lower().startswith("api"))
        )

        # Build headers
        headers = _filter_request_headers(request, inject_token=is_api_request)

        # Get request body
        body = await request.body()

        # Forward request (don't follow redirects - we want to intercept them)
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.request(
                    method=request.method,
                    url=upstream_url,
                    headers=headers,
                    content=body if body else None,
                    follow_redirects=False,
                )

            # Check if this response contains tokens
            content = response.content
            content_type = response.headers.get("content-type", "")

            if _is_token_endpoint(upstream_url) or _is_token_endpoint(str(response.url)):
                _extract_tokens_from_response(content, content_type)

            # Inject token capture script into HTML responses
            if "text/html" in content_type and response.status_code == 200:
                try:
                    html = content.decode("utf-8")
                    # Inject script after <head> tag
                    if "<head>" in html.lower():
                        # Find the position after <head> (case-insensitive)
                        match = re.search(r"<head[^>]*>", html, re.IGNORECASE)
                        if match:
                            pos = match.end()
                            html = html[:pos] + _TOKEN_CAPTURE_SCRIPT + html[pos:]
                            content = html.encode("utf-8")
                except (UnicodeDecodeError, Exception):
                    pass  # Keep original content if injection fails

            # Log the request
            token_status = ""
            if captured_tokens["access_token"]:
                token_status = f" {_COLORS['green']}[token]{_COLORS['reset']}"
            _log(request.method, request_path, status=response.status_code, upstream_url=upstream_url)
            if token_status:
                print(f"  {token_status}", file=sys.stderr)

            # Build response headers
            request_host = request.headers.get("host", "localhost")
            response_headers = _filter_response_headers(response, request_host)

            # Return response
            return StreamingResponse(
                iter([content]),
                status_code=response.status_code,
                headers=response_headers,
                media_type=content_type,
            )

        except httpx.TimeoutException:
            _log(request.method, request_path, status=504, error="Timeout")
            return JSONResponse(
                status_code=504,
                content={"error": "Gateway Timeout", "message": "Request timed out"},
            )
        except httpx.RequestError as e:
            _log(request.method, request_path, status=502, error=str(e)[:30])
            return JSONResponse(
                status_code=502,
                content={"error": "Bad Gateway", "message": str(e)},
            )

    @app.get("/")
    async def root_transparent_proxy(request: Request) -> Response:
        """Handle root path."""
        # Validate API key if required
        if not _validate_api_key(request):
            _log(request.method, "/", status=401, error="Invalid API key")
            return JSONResponse(
                status_code=401,
                content={
                    "error": "Unauthorized",
                    "message": "Invalid or missing API key",
                    "details": "Provide API key via X-API-Key header or Authorization: Bearer <key>",
                },
            )

        upstream_url = target_url.rstrip("/")
        if request.url.query:
            upstream_url = f"{upstream_url}?{request.url.query}"

        headers = _filter_request_headers(request, inject_token=False)

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.request(
                    method=request.method,
                    url=upstream_url,
                    headers=headers,
                    follow_redirects=False,
                )

            _log(request.method, "/", status=response.status_code, upstream_url=upstream_url)

            content = response.content
            content_type = response.headers.get("content-type", "")

            # Inject token capture script into HTML responses
            if "text/html" in content_type and response.status_code == 200:
                try:
                    html = content.decode("utf-8")
                    if "<head>" in html.lower():
                        match = re.search(r"<head[^>]*>", html, re.IGNORECASE)
                        if match:
                            pos = match.end()
                            html = html[:pos] + _TOKEN_CAPTURE_SCRIPT + html[pos:]
                            content = html.encode("utf-8")
                except (UnicodeDecodeError, Exception):
                    pass

            request_host = request.headers.get("host", "localhost")
            response_headers = _filter_response_headers(response, request_host)

            return StreamingResponse(
                iter([content]),
                status_code=response.status_code,
                headers=response_headers,
                media_type=content_type,
            )

        except httpx.TimeoutException:
            _log(request.method, "/", status=504, error="Timeout")
            return JSONResponse(
                status_code=504,
                content={"error": "Gateway Timeout", "message": "Request timed out"},
            )
        except httpx.RequestError as e:
            _log(request.method, "/", status=502, error=str(e)[:30])
            return JSONResponse(
                status_code=502,
                content={"error": "Bad Gateway", "message": str(e)},
            )

    return app
