"""Datex Studio CLI - Command-line interface for Datex Studio platform."""

__version__ = "0.2.1"
__app_name__ = "dxs"
