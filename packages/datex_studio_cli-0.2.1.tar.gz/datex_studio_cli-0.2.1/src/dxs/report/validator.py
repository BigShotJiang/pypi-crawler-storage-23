"""Validation for RDL report definitions.

Performs structural, spatial, and semantic checks.
"""

from __future__ import annotations

import re
from typing import Any

from dxs.report.models import ReportDefinition, ReportItem
from dxs.report.schema import BARCODE_SYMBOLOGIES


def validate_report(report_def: ReportDefinition) -> dict[str, Any]:
    """Validate a report definition.

    Args:
        report_def: The report definition to validate.

    Returns:
        Dict with keys: valid (bool), errors (list), warnings (list).
    """
    errors: list[dict[str, str]] = []
    warnings: list[dict[str, str]] = []

    _validate_structural(report_def, errors, warnings)
    _validate_spatial(report_def, errors, warnings)
    _validate_semantic(report_def, errors, warnings)

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
    }


# ── Size Parsing ─────────────────────────────────────────────────────────

_SIZE_PATTERN = re.compile(r"^(-?\d+(?:\.\d+)?)\s*(in|cm|mm|pt)$")


def _parse_size_inches(size_str: str | None) -> float | None:
    """Parse a size string to inches. Returns None if unparseable."""
    if not size_str:
        return None

    match = _SIZE_PATTERN.match(size_str.strip())
    if not match:
        return None

    value = float(match.group(1))
    unit = match.group(2)

    if unit == "in":
        return value
    elif unit == "cm":
        return value / 2.54
    elif unit == "mm":
        return value / 25.4
    elif unit == "pt":
        return value / 72.0
    return None


# ── Structural Checks ───────────────────────────────────────────────────


def _validate_structural(
    report_def: ReportDefinition,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Check required fields and basic structure."""
    if not report_def.ReportSections:
        errors.append({
            "element": "(report)",
            "message": "Report has no sections",
            "suggestion": "Add at least one ReportSection",
        })
        return

    # Check for duplicate names
    names: dict[str, int] = {}
    for item in report_def.all_items():
        names[item.Name] = names.get(item.Name, 0) + 1

    for name, count in names.items():
        if count > 1:
            errors.append({
                "element": name,
                "message": f"Duplicate element name (appears {count} times)",
                "suggestion": "Element names must be unique within a report",
            })

    # Check required fields per item type
    for item in report_def.all_items():
        _validate_item_required_fields(item, errors)


def _validate_item_required_fields(
    item: ReportItem,
    errors: list[dict[str, str]],
) -> None:
    """Check required fields for a specific item type."""
    if item.Type == "barcode":
        extra = item.model_extra or {}
        if "Symbology" not in extra:
            errors.append({
                "element": item.Name,
                "message": "Barcode missing required 'Symbology' property",
                "suggestion": "Add --symbology (e.g., Code128, QRCode)",
            })
        if not item.Value:
            errors.append({
                "element": item.Name,
                "message": "Barcode missing required 'Value' property",
                "suggestion": "Add --value with data to encode",
            })

    elif item.Type == "image":
        extra = item.model_extra or {}
        if "Source" not in extra:
            errors.append({
                "element": item.Name,
                "message": "Image missing required 'Source' property",
                "suggestion": "Add --source (External, Embedded, or Database)",
            })
        if not item.Value:
            errors.append({
                "element": item.Name,
                "message": "Image missing required 'Value' property",
                "suggestion": "Add --value with URL or expression",
            })

    elif item.Type == "table":
        extra = item.model_extra or {}
        if "DataSetName" not in extra:
            errors.append({
                "element": item.Name,
                "message": "Table missing required 'DataSetName' property",
                "suggestion": "Add --dataset with the name of the data source",
            })


# ── Spatial Checks ───────────────────────────────────────────────────────


def _validate_spatial(
    report_def: ReportDefinition,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Check element positions against page bounds.

    ActiveReportsJS Body coordinates are relative to the content area
    (inside margins), so Left=0in means the left edge of the printable
    area.  The content area width = PageWidth - LeftMargin - RightMargin.
    """
    page = report_def.Page
    page_width = _parse_size_inches(page.PageWidth)
    page_height = _parse_size_inches(page.PageHeight)

    for section in report_def.ReportSections:
        section_page = section.Page or page
        s_width = _parse_size_inches(section_page.PageWidth)
        s_height = _parse_size_inches(section_page.PageHeight)
        s_left = _parse_size_inches(section_page.LeftMargin) or 0
        s_right = _parse_size_inches(section_page.RightMargin) or 0
        s_top = _parse_size_inches(section_page.TopMargin) or 0
        s_bottom = _parse_size_inches(section_page.BottomMargin) or 0

        effective_width = s_width or page_width
        effective_height = s_height or page_height

        if effective_width is None or effective_height is None:
            continue

        # Content area dimensions (body coordinates are relative to this)
        content_width = effective_width - s_left - s_right
        content_height = effective_height - s_top - s_bottom

        for item in section.Body.ReportItems:
            item_left = _parse_size_inches(item.Left)
            item_top = _parse_size_inches(item.Top)
            item_width = _parse_size_inches(item.Width)
            item_height = _parse_size_inches(item.Height)

            if item_left is None or item_top is None:
                continue

            # Check right boundary (item exceeds content area width)
            if item_width is not None:
                item_right = item_left + item_width
                if item_right > content_width:
                    overshoot = item_right - content_width
                    warnings.append({
                        "element": item.Name,
                        "message": f"Extends {overshoot:.2f}in beyond right page margin",
                        "suggestion": f"Reduce width or move left (content area is {content_width:.2f}in wide)",
                    })

            # Check bottom boundary (item exceeds content area height)
            if item_height is not None:
                item_bottom = item_top + item_height
                if item_bottom > content_height:
                    overshoot = item_bottom - content_height
                    warnings.append({
                        "element": item.Name,
                        "message": f"Extends {overshoot:.2f}in beyond bottom page margin",
                        "suggestion": f"Reduce height or move up (content area is {content_height:.2f}in tall)",
                    })

            # Check negative positions (off-page to the left/top)
            if item_left < 0:
                warnings.append({
                    "element": item.Name,
                    "message": f"Negative left position ({item_left:.2f}in) extends outside content area",
                    "suggestion": "Move element right to at least 0in",
                })

            if item_top < 0:
                warnings.append({
                    "element": item.Name,
                    "message": f"Negative top position ({item_top:.2f}in) extends outside content area",
                    "suggestion": "Move element down to at least 0in",
                })


# ── Semantic Checks ──────────────────────────────────────────────────────

_EXPRESSION_PATTERN = re.compile(r"^=")
_FIELDS_REF_PATTERN = re.compile(r"Fields!\w+\.Value")


def _validate_semantic(
    report_def: ReportDefinition,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Check expression syntax, barcode symbologies, and other semantic rules."""
    for item in report_def.all_items():
        # Check expression syntax
        if item.Value and _EXPRESSION_PATTERN.match(item.Value):
            _validate_expression(item, errors, warnings)

        # Check barcode symbology
        if item.Type == "barcode":
            extra = item.model_extra or {}
            symbology = extra.get("Symbology")
            if symbology and not _is_valid_symbology(symbology):
                # Find close matches
                close = _find_close_symbology(symbology)
                suggestion = f"Did you mean '{close}'?" if close else "See 'dxs report schema barcodes' for valid symbologies"
                errors.append({
                    "element": item.Name,
                    "message": f"Unknown barcode symbology '{symbology}'",
                    "suggestion": suggestion,
                })

        # Check font size is parseable
        if item.Style and "FontSize" in item.Style:
            fs = item.Style["FontSize"]
            if not re.match(r"^\d+(\.\d+)?(pt|px|em|rem)$", str(fs)):
                warnings.append({
                    "element": item.Name,
                    "message": f"Font size '{fs}' may not be valid",
                    "suggestion": "Use format like '10pt', '12pt', '14pt'",
                })


def _validate_expression(
    item: ReportItem,
    errors: list[dict[str, str]],
    warnings: list[dict[str, str]],
) -> None:
    """Validate an expression value."""
    expr = item.Value
    if expr is None:
        return

    # Check for common mistakes
    if expr.startswith("=") and "Fields." in expr and "Fields!" not in expr:
        errors.append({
            "element": item.Name,
            "message": "Expression uses 'Fields.' instead of 'Fields!'",
            "suggestion": "Use '=Fields!FieldName.Value' syntax (replace '.' after Fields with '!')",
        })

    # Check unbalanced parentheses
    if expr.count("(") != expr.count(")"):
        errors.append({
            "element": item.Name,
            "message": "Unbalanced parentheses in expression",
            "suggestion": "Check for missing opening or closing parenthesis",
        })


def _is_valid_symbology(symbology: str) -> bool:
    """Check if a barcode symbology is valid (case-insensitive)."""
    return any(
        name.lower() == symbology.lower()
        for name in BARCODE_SYMBOLOGIES
    )


def _find_close_symbology(symbology: str) -> str | None:
    """Find a close match for a misspelled symbology."""
    sym_lower = symbology.lower()
    for name in BARCODE_SYMBOLOGIES:
        # Simple prefix/suffix match
        if name.lower().startswith(sym_lower[:4]) or sym_lower.startswith(name.lower()[:4]):
            return name
    return None
