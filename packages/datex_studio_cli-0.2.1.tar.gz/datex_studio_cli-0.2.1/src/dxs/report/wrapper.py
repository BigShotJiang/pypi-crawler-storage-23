"""Datex Studio report wrapper format translation.

Translates between local RDL (RDLX-JSON) format and the Datex Studio
report configuration wrapper format.

The Datex Studio format wraps the RDL definition inside a larger envelope:
{
    "datasourceConfigs": [...],
    "report": {
        "definition": { <RDL content> },
        "id": "reference_name",
        "displayName": "Display Name"
    },
    "reportType": "CPL",
    "configurationTypeId": 15,
    ...
}
"""

from __future__ import annotations

import re
from typing import Any


def _sanitize_reference_name(name: str) -> str:
    """Convert a display name to a valid reference name.

    Args:
        name: Display name to sanitize.

    Returns:
        Snake_case reference name.
    """
    # Replace non-alphanumeric with underscores, collapse multiples, strip edges
    ref = re.sub(r"[^a-zA-Z0-9]+", "_", name.strip())
    ref = ref.strip("_").lower()
    return ref


def rdl_to_datex_wrapper(
    rdl_definition: dict[str, Any],
    report_name: str,
    reference_name: str | None = None,
    description: str | None = None,
    report_type: str = "CPL",
    datasource_configs: list[dict[str, Any]] | None = None,
    in_params: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Wrap a local RDL definition into Datex Studio report format.

    Args:
        rdl_definition: The RDL JSON content (what goes in report.definition).
        report_name: Display name for the report.
        reference_name: Reference name (defaults to sanitized report_name).
        description: Report description.
        report_type: Report type code (default: CPL).
        datasource_configs: Optional datasource configuration mappings.
        in_params: Optional input parameters.

    Returns:
        Complete Datex Studio report wrapper dict.
    """
    if reference_name is None:
        reference_name = _sanitize_reference_name(report_name)

    wrapper: dict[str, Any] = {
        "datasourceConfigs": datasource_configs or [],
        "report": {
            "definition": rdl_definition,
            "id": reference_name,
            "displayName": report_name,
        },
        "reportType": report_type,
        "configurationTypeId": 15,
        "id": None,
        "referenceName": reference_name,
        "title": report_name,
        "description": description or report_name,
        "inParams": in_params or [],
        "outParams": None,
        "vars": None,
        "events": None,
        "accessModifier": "public",
        "datasources": None,
    }

    return wrapper


def datex_wrapper_to_rdl(wrapper: dict[str, Any]) -> dict[str, Any]:
    """Extract RDL definition from a Datex Studio report wrapper.

    Args:
        wrapper: Datex Studio report configuration response.

    Returns:
        The RDL definition dict suitable for saving as .rdlx-json.

    Raises:
        ValueError: If the wrapper doesn't contain a valid report definition.
    """
    report = wrapper.get("report")
    if not isinstance(report, dict):
        raise ValueError("Wrapper missing 'report' object")

    definition = report.get("definition")
    if not isinstance(definition, dict):
        raise ValueError("Wrapper missing 'report.definition' object")

    return definition
