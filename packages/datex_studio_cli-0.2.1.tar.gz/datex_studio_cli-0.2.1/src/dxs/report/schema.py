"""Schema reference data for RDL report items.

Provides structured metadata about report item types, barcode symbologies,
and expression syntax for agent discovery.
"""

from typing import Any

# ── Report Item Type Definitions ──────────────────────────────────────────

ITEM_TYPES: dict[str, dict[str, Any]] = {
    "textbox": {
        "description": "Text content with optional data binding and formatting",
        "properties": {
            "Value": {
                "type": "string",
                "description": "Static text or expression (e.g., =Fields!Name.Value)",
                "required": False,
            },
            "CanGrow": {
                "type": "boolean",
                "description": "Allow textbox to grow vertically to fit content",
                "default": False,
            },
            "KeepTogether": {
                "type": "boolean",
                "description": "Keep content together on one page",
                "default": True,
            },
        },
        "style_properties": {
            "FontSize": {
                "type": "size",
                "description": "Font size",
                "default": "10pt",
                "examples": ["8pt", "10pt", "12pt", "14pt", "18pt", "24pt"],
            },
            "FontWeight": {
                "type": "enum",
                "values": ["Normal", "Bold"],
                "default": "Normal",
            },
            "FontFamily": {
                "type": "string",
                "description": "Font family name",
                "default": "Arial",
                "examples": ["Arial", "Times New Roman", "Courier New", "Helvetica"],
            },
            "FontStyle": {
                "type": "enum",
                "values": ["Normal", "Italic"],
                "default": "Normal",
            },
            "Color": {
                "type": "color",
                "description": "Text color",
                "default": "Black",
                "examples": ["Black", "Red", "#FF0000", "DarkBlue"],
            },
            "BackgroundColor": {
                "type": "color",
                "description": "Background fill color",
                "examples": ["White", "LightGray", "#F0F0F0"],
            },
            "TextAlign": {
                "type": "enum",
                "values": ["Left", "Center", "Right", "Justify"],
                "default": "Left",
            },
            "VerticalAlign": {
                "type": "enum",
                "values": ["Top", "Middle", "Bottom"],
                "default": "Top",
            },
            "TextDecoration": {
                "type": "enum",
                "values": ["None", "Underline", "LineThrough"],
                "default": "None",
            },
            "Format": {
                "type": "string",
                "description": "Format string for numbers/dates",
                "examples": ["#,##0", "#,##0.00", "MM/dd/yyyy", "0%"],
            },
        },
        "common_uses": [
            "Labels and headings",
            "Address blocks",
            "Reference numbers",
            "Dates and timestamps",
            "Data-bound field display",
        ],
    },
    "barcode": {
        "description": "1D/2D barcode with configurable symbology",
        "properties": {
            "Symbology": {
                "type": "enum",
                "description": "Barcode type/format",
                "values": [
                    "Code128",
                    "QRCode",
                    "PDF417",
                    "Code39",
                    "EAN13",
                    "EAN8",
                    "UPCA",
                    "UPCE",
                    "DataMatrix",
                    "Aztec",
                    "Code93",
                    "ITF14",
                    "MSI",
                    "Pharmacode",
                    "Codabar",
                    "GS1_128",
                    "IntelligentMail",
                    "Postnet",
                    "Maxicode",
                ],
                "required": True,
            },
            "Value": {
                "type": "string",
                "description": "Data to encode (expression supported)",
                "required": True,
            },
            "Caption": {
                "type": "boolean",
                "description": "Show human-readable text below barcode",
                "default": True,
            },
            "CaptionLocation": {
                "type": "enum",
                "values": ["Below", "Above", "None"],
                "default": "Below",
            },
        },
        "style_properties": {
            "Color": {
                "type": "color",
                "description": "Barcode bar color",
                "default": "Black",
            },
            "BackgroundColor": {
                "type": "color",
                "description": "Barcode background color",
                "default": "White",
            },
        },
        "common_uses": [
            "Tracking numbers (PRO, BOL)",
            "PO and reference numbers",
            "Routing codes",
            "License plate numbers (LPN)",
            "QR codes for URLs or metadata",
        ],
    },
    "image": {
        "description": "Embedded or external image",
        "properties": {
            "Source": {
                "type": "enum",
                "description": "Image source type",
                "values": ["External", "Embedded", "Database"],
                "required": True,
            },
            "Value": {
                "type": "string",
                "description": "URL, embedded name, or expression for image data",
                "required": True,
            },
            "MIMEType": {
                "type": "string",
                "description": "Image MIME type",
                "default": "image/png",
                "examples": ["image/png", "image/jpeg", "image/svg+xml"],
            },
            "Sizing": {
                "type": "enum",
                "values": ["AutoSize", "Fit", "FitProportional", "Clip"],
                "default": "FitProportional",
            },
        },
        "common_uses": [
            "Company logos",
            "Carrier logos",
            "Certification marks",
            "Hazmat symbols",
        ],
    },
    "table": {
        "description": "Tabular data layout with headers, details, and footers",
        "properties": {
            "DataSetName": {
                "type": "string",
                "description": "Name of the dataset to bind to",
                "required": True,
            },
            "TableColumns": {
                "type": "array",
                "description": "Column width definitions [{Width: '2in'}, ...]",
            },
            "Header": {
                "type": "object",
                "description": "Header row group (TableRows with TableCells)",
            },
            "Details": {
                "type": "object",
                "description": "Detail row group (repeats per data row)",
            },
            "Footer": {
                "type": "object",
                "description": "Footer row group",
            },
        },
        "common_uses": [
            "Line item detail tables",
            "Charge/rate breakdowns",
            "Package lists",
            "Reference number lists",
        ],
    },
    "line": {
        "description": "Horizontal or vertical line separator",
        "positioning": "Lines use StartPoint/EndPoint (NOT Left/Top/Width/Height)",
        "positioning_example": {
            "Type": "line",
            "Name": "Divider",
            "StartPoint": {"X": "0in", "Y": "1in"},
            "EndPoint": {"X": "3.75in", "Y": "1in"},
            "LineWidth": "2pt",
        },
        "properties": {
            "StartPoint": {
                "type": "object",
                "description": "Line start coordinate {X, Y} in content area",
                "required": True,
            },
            "EndPoint": {
                "type": "object",
                "description": "Line end coordinate {X, Y} in content area",
                "required": True,
            },
            "LineWidth": {
                "type": "size",
                "description": "Line thickness (top-level property, NOT inside Style)",
                "default": "1pt",
                "examples": ["1pt", "2pt", "3pt"],
            },
            "LineStyle": {
                "type": "enum",
                "values": ["Solid", "Dashed", "Dotted"],
                "default": "Solid",
            },
        },
        "style_properties": {},
        "notes": [
            "Lines do NOT use Left/Top/Width/Height — those are silently mapped to (0,0)/(0,0)",
            "Lines do NOT use Style.Border — use top-level LineWidth/LineStyle instead",
            "Horizontal line: same Y for StartPoint and EndPoint",
            "Vertical line: same X for StartPoint and EndPoint",
        ],
        "common_uses": [
            "Section dividers",
            "Header/footer separators",
            "Box outlines (combined with rectangle)",
        ],
    },
    "rectangle": {
        "description": "Rectangular container or decorative border",
        "properties": {
            "ReportItems": {
                "type": "array",
                "description": "Child report items contained within the rectangle",
            },
        },
        "style_properties": {
            "BackgroundColor": {
                "type": "color",
                "description": "Fill color",
            },
            "Border": {
                "type": "object",
                "description": "Nested border object with Style, Width, Color",
                "example": {"Style": "Solid", "Width": "2pt", "Color": "Black"},
            },
        },
        "notes": [
            "Rectangles use nested Style.Border object (NOT flat BorderStyle/BorderWidth)",
            "Example: \"Style\": { \"Border\": { \"Style\": \"Solid\", \"Width\": \"2pt\", \"Color\": \"Black\" } }",
        ],
        "common_uses": [
            "Grouping related elements",
            "Section borders",
            "Background shading areas",
        ],
    },
    "shape": {
        "description": "Geometric shape (ellipse, triangle, cross, etc.)",
        "properties": {
            "ShapeType": {
                "type": "enum",
                "values": [
                    "Rectangle",
                    "RoundedRectangle",
                    "Ellipse",
                    "Triangle",
                    "Cross",
                    "Diamond",
                    "Pentagon",
                    "Hexagon",
                    "Star",
                    "Arrow",
                ],
                "default": "Rectangle",
            },
        },
        "style_properties": {
            "BackgroundColor": {
                "type": "color",
            },
            "BorderStyle": {
                "type": "enum",
                "values": ["None", "Solid", "Dashed", "Dotted"],
            },
            "BorderColor": {
                "type": "color",
            },
            "BorderWidth": {
                "type": "size",
            },
        },
        "common_uses": [
            "Decorative elements",
            "Callout shapes",
            "Status indicators",
        ],
    },
}

# ── Barcode Symbologies ──────────────────────────────────────────────────

BARCODE_SYMBOLOGIES: dict[str, dict[str, Any]] = {
    "Code128": {
        "type": "1D",
        "description": "High-density alphanumeric barcode. Most common in shipping/logistics.",
        "data_types": "ASCII characters (0-127)",
        "max_length": "Unlimited (practical limit ~80 chars)",
        "common_uses": ["PRO numbers", "BOL numbers", "Tracking codes", "GS1-128 applications"],
    },
    "QRCode": {
        "type": "2D",
        "description": "Matrix barcode supporting large data payloads. Scannable from any angle.",
        "data_types": "Numeric, alphanumeric, binary, Kanji",
        "max_length": "~4,296 alphanumeric characters",
        "common_uses": ["URLs", "Complex data encoding", "Mobile scanning", "Packing slips"],
    },
    "PDF417": {
        "type": "2D",
        "description": "Stacked barcode used in transport and ID documents.",
        "data_types": "Text, binary, numeric",
        "max_length": "~1,850 characters",
        "common_uses": ["Shipping labels", "ID documents", "Airline boarding passes"],
    },
    "Code39": {
        "type": "1D",
        "description": "Self-checking alphanumeric barcode. Widely supported but low density.",
        "data_types": "A-Z, 0-9, space, - . $ / + %",
        "max_length": "~40 characters practical",
        "common_uses": ["Part numbers", "Asset tags", "Military/government (LOGMARS)"],
    },
    "EAN13": {
        "type": "1D",
        "description": "European Article Number. Standard retail product barcode.",
        "data_types": "13 digits",
        "max_length": "13 digits (12 + check)",
        "common_uses": ["Retail products", "ISBN books"],
    },
    "EAN8": {
        "type": "1D",
        "description": "Compact version of EAN-13 for small packages.",
        "data_types": "8 digits",
        "max_length": "8 digits (7 + check)",
        "common_uses": ["Small retail items"],
    },
    "UPCA": {
        "type": "1D",
        "description": "Universal Product Code (North America). Standard retail barcode.",
        "data_types": "12 digits",
        "max_length": "12 digits (11 + check)",
        "common_uses": ["Retail products (US/Canada)"],
    },
    "UPCE": {
        "type": "1D",
        "description": "Compact UPC for small items.",
        "data_types": "8 digits",
        "max_length": "8 digits",
        "common_uses": ["Small retail items"],
    },
    "DataMatrix": {
        "type": "2D",
        "description": "Compact 2D matrix code. Very small footprint.",
        "data_types": "Text, numeric, binary",
        "max_length": "~2,335 alphanumeric characters",
        "common_uses": ["Small parts marking", "Electronics", "Pharma"],
    },
    "Aztec": {
        "type": "2D",
        "description": "Compact 2D code, no quiet zone required.",
        "data_types": "Text, binary",
        "max_length": "~3,832 digits or ~3,067 characters",
        "common_uses": ["Transport tickets", "Boarding passes"],
    },
    "Code93": {
        "type": "1D",
        "description": "Higher density version of Code 39.",
        "data_types": "Full ASCII",
        "max_length": "~40 characters practical",
        "common_uses": ["Inventory", "Internal tracking"],
    },
    "ITF14": {
        "type": "1D",
        "description": "Interleaved 2-of-5 for shipping containers.",
        "data_types": "14 digits",
        "max_length": "14 digits",
        "common_uses": ["Shipping cartons", "Pallets", "Case-level GTIN"],
    },
    "GS1_128": {
        "type": "1D",
        "description": "GS1-128 (formerly UCC/EAN-128). Standard for shipping labels.",
        "data_types": "ASCII with GS1 Application Identifiers",
        "max_length": "~48 characters per symbol",
        "common_uses": [
            "SSCC (Serial Shipping Container Code)",
            "Shipping labels (GS1 compliant)",
            "Pallet labels",
        ],
    },
    "IntelligentMail": {
        "type": "1D",
        "description": "USPS Intelligent Mail barcode for mail tracking.",
        "data_types": "Numeric (20, 25, 29, or 31 digits)",
        "max_length": "31 digits",
        "common_uses": ["USPS mail tracking", "Postal routing"],
    },
    "Postnet": {
        "type": "1D",
        "description": "USPS postal barcode (legacy).",
        "data_types": "5, 9, or 11 digits",
        "max_length": "11 digits",
        "common_uses": ["ZIP code encoding (legacy)"],
    },
    "Maxicode": {
        "type": "2D",
        "description": "Fixed-size 2D code used by UPS.",
        "data_types": "Numeric and alphanumeric",
        "max_length": "93 characters",
        "common_uses": ["UPS shipping labels", "Package sorting"],
    },
    "MSI": {
        "type": "1D",
        "description": "MSI (Modified Plessey) barcode.",
        "data_types": "Numeric only",
        "max_length": "Unlimited",
        "common_uses": ["Inventory control", "Warehouse shelving"],
    },
    "Pharmacode": {
        "type": "1D",
        "description": "Pharmaceutical binary code.",
        "data_types": "Numeric (3-131070)",
        "max_length": "6 digits",
        "common_uses": ["Pharmaceutical packaging"],
    },
    "Codabar": {
        "type": "1D",
        "description": "Self-checking barcode for libraries and blood banks.",
        "data_types": "0-9, - $ : / . +",
        "max_length": "~40 characters",
        "common_uses": ["Libraries", "Blood banks", "Overnight delivery"],
    },
}

# ── Expression Syntax Reference ──────────────────────────────────────────

EXPRESSION_REFERENCE: dict[str, Any] = {
    "overview": (
        "RDL expressions start with '=' and reference data fields, parameters, "
        "or built-in functions. Expressions without '=' are treated as literal text."
    ),
    "field_reference": {
        "syntax": "=Fields!FieldName.Value",
        "description": "Reference a field from the current dataset",
        "examples": [
            "=Fields!ShipperName.Value",
            "=Fields!PRONumber.Value",
            "=Fields!OrderDate.Value",
        ],
    },
    "parameter_reference": {
        "syntax": "=Parameters!ParamName.Value",
        "description": "Reference a report parameter",
        "examples": [
            "=Parameters!orderId.Value",
            "=Parameters!ReportDate.Value",
        ],
    },
    "concatenation": {
        "syntax": '=expression & " " & expression',
        "description": "Combine text and field values",
        "examples": [
            '=Fields!FirstName.Value & " " & Fields!LastName.Value',
            '="Order: " & Fields!OrderNumber.Value',
            '=Fields!City.Value & ", " & Fields!State.Value & " " & Fields!Zip.Value',
        ],
    },
    "conditional": {
        "syntax": "=IIf(condition, true_value, false_value)",
        "description": "Conditional expression",
        "examples": [
            '=IIf(Fields!Status.Value = "Active", "Yes", "No")',
            '=IIf(Fields!Weight.Value > 150, "HEAVY", "")',
        ],
    },
    "formatting": {
        "syntax": "=Format(expression, format_string)",
        "description": "Format numbers and dates",
        "examples": [
            '=Format(Fields!Weight.Value, "#,##0.00")',
            '=Format(Fields!OrderDate.Value, "MM/dd/yyyy")',
            '=Format(Fields!Amount.Value, "$#,##0.00")',
        ],
    },
    "aggregates": {
        "syntax": "=Aggregate(Fields!Field.Value)",
        "description": "Aggregate functions for use in group headers/footers",
        "functions": [
            {"name": "Sum", "example": "=Sum(Fields!Amount.Value)"},
            {"name": "Count", "example": "=Count(Fields!Id.Value)"},
            {"name": "Avg", "example": "=Avg(Fields!Weight.Value)"},
            {"name": "Min", "example": "=Min(Fields!Date.Value)"},
            {"name": "Max", "example": "=Max(Fields!Date.Value)"},
            {"name": "First", "example": "=First(Fields!Name.Value)"},
            {"name": "Last", "example": "=Last(Fields!Name.Value)"},
        ],
    },
    "globals": {
        "description": "Built-in global values",
        "values": [
            {"name": "=Globals!PageNumber", "description": "Current page number"},
            {"name": "=Globals!TotalPages", "description": "Total page count"},
            {"name": "=Globals!ExecutionTime", "description": "Report execution timestamp"},
            {"name": "=Globals!ReportName", "description": "Report name"},
        ],
    },
}

# ── Common Page Sizes ────────────────────────────────────────────────────

PAGE_SIZES: dict[str, dict[str, str]] = {
    "letter": {"width": "8.5in", "height": "11in", "description": "US Letter (8.5 x 11)"},
    "legal": {"width": "8.5in", "height": "14in", "description": "US Legal (8.5 x 14)"},
    "a4": {"width": "8.27in", "height": "11.69in", "description": "A4 (210 x 297mm)"},
    "4x6": {"width": "4in", "height": "6in", "description": "Shipping label (4 x 6)"},
    "4x8": {"width": "4in", "height": "8in", "description": "Extended label (4 x 8)"},
}

# ── Document Structure Reference ────────────────────────────────────────

DOCUMENT_STRUCTURE: dict[str, Any] = {
    "overview": (
        "An RDLX-JSON file is a JSON object representing an ActiveReportsJS report. "
        "The top-level object is a ReportDefinition containing page settings, "
        "one or more report sections (each with a body of report items), "
        "data sources, datasets, and optional parameters. "
        "Field names use PascalCase. Sizes use CSS-like units (e.g., '8.5in', '0.5in', '10pt')."
    ),
    "sections": {
        "root": {
            "description": "Top-level ReportDefinition object — the root of every .rdlx-json file",
            "fields": {
                "Name": {
                    "type": "string",
                    "description": "Report name identifier",
                    "default": "Report",
                },
                "Width": {
                    "type": "size",
                    "description": "Report body width (content area, excluding margins)",
                    "default": "6.5in",
                },
                "Page": {
                    "type": "PageSettings",
                    "description": "Top-level page dimensions and margins (see page_settings section)",
                },
                "ReportSections": {
                    "type": "array<ReportSection>",
                    "description": "Report sections — typically one. Each has its own Body with ReportItems (see report_section)",
                },
                "DataSources": {
                    "type": "array<DataSource>",
                    "description": "Data source connections (see data_source section). Usually one with JSONEMBED provider.",
                },
                "DataSets": {
                    "type": "array<DataSet>",
                    "description": "Named datasets that provide fields for data binding (see data_set section)",
                },
                "ReportParameters": {
                    "type": "array<ReportParameter>",
                    "description": "Report parameters passed at render time (see report_parameter section)",
                },
                "CustomProperties": {
                    "type": "array<{Name, Value}>",
                    "description": "Key-value metadata. Common: DisplayType='Page', SizeType='Default'",
                },
                "Layers": {
                    "type": "array<{Name}>",
                    "description": "Report layers. Default: [{Name: 'default'}]",
                    "default": [{"Name": "default"}],
                },
                "Version": {
                    "type": "string",
                    "description": "RDL schema version",
                    "default": "10.0.1",
                },
            },
        },
        "page_settings": {
            "description": "Page dimensions, margins, and orientation. Used at top-level and per-section.",
            "fields": {
                "PageWidth": {
                    "type": "size",
                    "description": "Physical page width",
                    "default": "8.5in",
                    "examples": ["8.5in", "4in", "11in"],
                },
                "PageHeight": {
                    "type": "size",
                    "description": "Physical page height",
                    "default": "11in",
                    "examples": ["11in", "6in", "8.5in"],
                },
                "TopMargin": {
                    "type": "size",
                    "description": "Top margin",
                    "default": "0.5in",
                },
                "BottomMargin": {
                    "type": "size",
                    "description": "Bottom margin",
                    "default": "0.5in",
                },
                "LeftMargin": {
                    "type": "size",
                    "description": "Left margin",
                    "default": "0.5in",
                },
                "RightMargin": {
                    "type": "size",
                    "description": "Right margin",
                    "default": "0.5in",
                },
                "Columns": {
                    "type": "integer",
                    "description": "Number of columns on the page",
                    "default": 1,
                },
                "ColumnSpacing": {
                    "type": "size",
                    "description": "Space between columns",
                    "default": "0in",
                },
                "PaperOrientation": {
                    "type": "enum",
                    "description": "Page orientation",
                    "values": ["Portrait", "Landscape"],
                    "default": "Portrait",
                },
            },
        },
        "report_section": {
            "description": "A section of the report. Most reports have one section. Each has its own Body and optional page overrides.",
            "fields": {
                "Type": {
                    "type": "enum",
                    "description": "Section type",
                    "values": ["Continuous"],
                    "default": "Continuous",
                },
                "Name": {
                    "type": "string",
                    "description": "Section identifier",
                    "default": "Section1",
                },
                "Page": {
                    "type": "PageSettings",
                    "description": "Section-level page settings (overrides top-level Page)",
                },
                "Width": {
                    "type": "size",
                    "description": "Section content width (PageWidth - LeftMargin - RightMargin)",
                },
                "Body": {
                    "type": "Body",
                    "description": "Section body containing report items (see body section)",
                },
            },
        },
        "body": {
            "description": "The body of a report section. Contains the report items (textboxes, barcodes, images, etc.).",
            "fields": {
                "Height": {
                    "type": "size",
                    "description": "Body height (PageHeight - TopMargin - BottomMargin)",
                    "default": "5in",
                },
                "ReportItems": {
                    "type": "array<ReportItem>",
                    "description": "Array of report items. Use 'dxs report schema items' for available types and 'dxs report schema item <type>' for properties.",
                },
            },
        },
        "data_source": {
            "description": "A data connection. Datex Studio reports use JSONEMBED provider with data injected at render time.",
            "fields": {
                "Name": {
                    "type": "string",
                    "description": "Data source name referenced by datasets",
                    "default": "Datasource",
                },
                "ConnectionProperties": {
                    "type": "object",
                    "description": "Connection configuration",
                    "fields": {
                        "DataProvider": {
                            "type": "string",
                            "description": "Provider type",
                            "default": "JSONEMBED",
                        },
                        "ConnectString": {
                            "type": "string",
                            "description": "Connection string",
                            "default": "jsondata={}",
                        },
                    },
                },
            },
        },
        "data_set": {
            "description": "A named dataset providing fields for expressions (=Fields!Name.Value). Bound to a data source.",
            "fields": {
                "Name": {
                    "type": "string",
                    "description": "Dataset name (referenced by tables and expressions)",
                },
                "Fields": {
                    "type": "array<{Name, DataField}>",
                    "description": "Field definitions. Name is the field identifier used in expressions, DataField is the source property name.",
                },
                "Query": {
                    "type": "object",
                    "description": "Query definition",
                    "fields": {
                        "DataSourceName": {
                            "type": "string",
                            "description": "Name of the data source to query",
                            "default": "Datasource",
                        },
                        "CommandText": {
                            "type": "string",
                            "description": "Query command (JSONPath for JSONEMBED)",
                            "default": "jpath=$.*",
                        },
                    },
                },
            },
        },
        "report_parameter": {
            "description": "A parameter passed to the report at render time. Referenced via =Parameters!Name.Value.",
            "fields": {
                "Name": {
                    "type": "string",
                    "description": "Parameter name (used in =Parameters!Name.Value)",
                },
                "DataType": {
                    "type": "enum",
                    "description": "Parameter data type",
                    "values": ["String", "Integer", "Float", "Boolean", "DateTime"],
                    "default": "String",
                },
                "Hidden": {
                    "type": "boolean",
                    "description": "Hide from parameter prompts",
                    "default": False,
                },
            },
        },
    },
    "page_sizes": PAGE_SIZES,
    "minimal_example": {
        "Name": "MyReport",
        "Width": "7.5in",
        "Page": {
            "PageWidth": "8.5in",
            "PageHeight": "11in",
            "TopMargin": "0.5in",
            "BottomMargin": "0.5in",
            "LeftMargin": "0.5in",
            "RightMargin": "0.5in",
            "Columns": 1,
            "ColumnSpacing": "0in",
            "PaperOrientation": "Portrait",
        },
        "ReportSections": [
            {
                "Type": "Continuous",
                "Name": "Section1",
                "Page": {
                    "PageWidth": "8.5in",
                    "PageHeight": "11in",
                    "TopMargin": "0.5in",
                    "BottomMargin": "0.5in",
                    "LeftMargin": "0.5in",
                    "RightMargin": "0.5in",
                },
                "Width": "7.5in",
                "Body": {
                    "Height": "10in",
                    "ReportItems": [],
                },
            }
        ],
        "DataSources": [
            {
                "Name": "Datasource",
                "ConnectionProperties": {
                    "DataProvider": "JSONEMBED",
                    "ConnectString": "jsondata={}",
                },
            }
        ],
        "DataSets": [],
        "ReportParameters": [],
        "CustomProperties": [
            {"Name": "DisplayType", "Value": "Page"},
            {"Name": "SizeType", "Value": "Default"},
        ],
        "Layers": [{"Name": "default"}],
        "Version": "10.0.1",
    },
}


def get_item_type_info(item_type: str) -> dict[str, Any] | None:
    """Get schema info for a report item type."""
    return ITEM_TYPES.get(item_type.lower())


def get_barcode_info(symbology: str) -> dict[str, Any] | None:
    """Get info for a barcode symbology (case-insensitive)."""
    for name, info in BARCODE_SYMBOLOGIES.items():
        if name.lower() == symbology.lower():
            return {**info, "name": name}
    return None


def list_item_types() -> list[dict[str, str]]:
    """List all available item types with descriptions."""
    return [
        {"type": name, "description": info["description"]}
        for name, info in ITEM_TYPES.items()
    ]


def list_barcode_symbologies() -> list[dict[str, Any]]:
    """List all barcode symbologies with metadata."""
    return [
        {
            "symbology": name,
            "type": info["type"],
            "description": info["description"],
            "common_uses": info["common_uses"],
        }
        for name, info in BARCODE_SYMBOLOGIES.items()
    ]


def get_document_structure() -> dict[str, Any]:
    """Get the full RDL-JSON document structure reference."""
    return DOCUMENT_STRUCTURE
