"""Report preview rendering via ActiveReportJS in a headless browser.

Uses agent-browser to load an ARJS viewer page, wait for render completion,
and screenshot the output as a PNG image.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import threading
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any

from dxs.utils.errors import ValidationError

# ── Unit conversion ──────────────────────────────────────────────────────


_UNIT_TO_INCHES: dict[str, float] = {
    "in": 1.0,
    "cm": 1.0 / 2.54,
    "mm": 1.0 / 25.4,
    "pt": 1.0 / 72.0,
}

_UNIT_RE = re.compile(r"^([\d.]+)\s*(in|cm|mm|pt)$", re.IGNORECASE)


def _parse_dimension(value: str) -> float:
    """Parse a dimension string (e.g. '4in', '10cm') to inches."""
    m = _UNIT_RE.match(value.strip())
    if not m:
        raise ValueError(f"Cannot parse dimension: {value!r}")
    number = float(m.group(1))
    unit = m.group(2).lower()
    return number * _UNIT_TO_INCHES[unit]


def page_size_to_pixels(
    page_width: str,
    page_height: str,
    target_width: int = 800,
) -> tuple[int, int]:
    """Convert report page dimensions to pixel viewport size.

    Args:
        page_width: Page width with unit (e.g. '4in').
        page_height: Page height with unit (e.g. '6in').
        target_width: Desired pixel width for the output.

    Returns:
        Tuple of (width_px, height_px).
    """
    w_in = _parse_dimension(page_width)
    h_in = _parse_dimension(page_height)
    if w_in <= 0:
        raise ValueError(f"Page width must be positive, got {page_width!r}")
    aspect = h_in / w_in
    return target_width, round(target_width * aspect)


# ── Preview HTTP server ──────────────────────────────────────────────────


class _PreviewHandler(SimpleHTTPRequestHandler):
    """HTTP handler that serves ARJS assets + report/data API endpoints."""

    report_json_data: str = "{}"
    data_json_data: str = "null"

    def do_GET(self) -> None:
        if self.path == "/api/report":
            self._json_response(self.report_json_data)
        elif self.path == "/api/data":
            self._json_response(self.data_json_data)
        elif self.path == "/":
            # Serve the preview HTML page
            self._serve_file("report-preview.html", "text/html")
        else:
            super().do_GET()

    def _json_response(self, body: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        encoded = body.encode("utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def _serve_file(self, filename: str, content_type: str) -> None:
        """Serve a file from the public/ subdirectory."""
        path = Path(self.directory) / "public" / filename  # type: ignore[attr-defined]
        if path.exists():
            content = path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        else:
            self.send_error(404, f"File not found: {filename}")

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default logging."""
        pass


def _find_free_port() -> int:
    """Find an available TCP port."""
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]  # type: ignore[no-any-return]


class PreviewServer:
    """Lightweight HTTP server for report preview rendering.

    Serves the ARJS viewer HTML page, node_modules assets, and
    API endpoints for the report definition and sample data.
    """

    def __init__(
        self,
        serve_dir: str | Path,
        report_json: str,
        data_json: str = "null",
    ) -> None:
        self.port = _find_free_port()
        serve_dir_str = str(serve_dir)

        # Create a handler subclass with the data baked in
        class Handler(_PreviewHandler):
            report_json_data = report_json
            data_json_data = data_json

            def __init__(self, *args: Any, **kwargs: Any) -> None:
                kwargs["directory"] = serve_dir_str
                super().__init__(*args, **kwargs)

        self._server = HTTPServer(("127.0.0.1", self.port), Handler)
        self._thread: threading.Thread | None = None

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def start(self) -> None:
        """Start serving in a background thread."""
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Shut down the server."""
        self._server.shutdown()
        if self._thread is not None:
            self._thread.join(timeout=5)


# ── Prerequisite checks ─────────────────────────────────────────────────


def _check_agent_browser() -> str:
    """Verify agent-browser is installed and return its path.

    Returns:
        Path to the agent-browser executable.

    Raises:
        ValidationError: If agent-browser is not found.
    """
    path = shutil.which("agent-browser")
    if path is None:
        raise ValidationError(
            message="agent-browser is not installed",
            code="DXS-RPT-040",
            suggestions=[
                "Install with: npm install -g @anthropic-ai/agent-browser",
                "Then run: agent-browser install",
            ],
        )
    return path


def _check_frontend_deps(frontend_dir: Path) -> None:
    """Verify frontend node_modules contain ARJS.

    Raises:
        ValidationError: If node_modules or ARJS package is missing.
    """
    arjs_dir = frontend_dir / "node_modules" / "@mescius" / "activereportsjs"
    if not arjs_dir.exists():
        raise ValidationError(
            message="ActiveReportsJS not found in frontend node_modules",
            code="DXS-RPT-041",
            suggestions=[
                f"Run: cd {frontend_dir} && npm install",
                "This installs the @mescius/activereportsjs package needed for preview rendering",
            ],
        )


# ── Main render pipeline ────────────────────────────────────────────────


def _get_frontend_dir() -> Path:
    """Get the frontend directory path."""
    return Path(__file__).resolve().parent.parent / "web" / "frontend"


def _get_public_dir() -> Path:
    """Get the frontend public directory path (where report-preview.html lives)."""
    return _get_frontend_dir() / "public"


def render_preview(
    report_data: dict[str, Any],
    output_path: str | Path,
    sample_data: dict[str, Any] | None = None,
    target_width: int = 800,
    per_page: bool = False,
    timeout: int = 30,
) -> dict[str, Any]:
    """Render a report to PNG via headless browser.

    Args:
        report_data: Parsed report definition (RDLX-JSON content).
        output_path: Path for the output PNG file.
        sample_data: Optional sample data keyed by dataset name.
        target_width: Pixel width for the rendered output.
        per_page: If True, output separate PNGs per page.
        timeout: Seconds to wait for render completion.

    Returns:
        Dict with output metadata (file, output_path, pages, dimensions).

    Raises:
        ValidationError: If prerequisites are missing or rendering fails.
    """
    ab_path = _check_agent_browser()
    frontend_dir = _get_frontend_dir()
    _check_frontend_deps(frontend_dir)

    output_path = Path(output_path)

    # Extract page dimensions from report
    page = report_data.get("Page", {})
    page_width = page.get("PageWidth", "8.5in")
    page_height = page.get("PageHeight", "11in")
    vp_width, vp_height = page_size_to_pixels(page_width, page_height, target_width)

    # Prepare JSON payloads
    report_json = json.dumps(report_data)
    data_json = json.dumps(sample_data) if sample_data else "null"

    # Start preview server — serve from frontend dir so node_modules are accessible
    server = PreviewServer(
        serve_dir=frontend_dir,
        report_json=report_json,
        data_json=data_json,
    )
    server.start()

    try:
        result = _run_agent_browser(
            ab_path=ab_path,
            url=server.url,
            output_path=output_path,
            vp_width=vp_width,
            vp_height=vp_height,
            per_page=per_page,
            timeout=timeout,
        )
    finally:
        server.stop()

    return result


def _ab_exec(
    ab_path: str,
    args: list[str],
    timeout: int,
    session: str = "dxs-preview",
) -> subprocess.CompletedProcess[str]:
    """Run a single agent-browser command.

    All arguments are passed as a list to subprocess.run (no shell invocation),
    preventing command injection.

    Returns:
        CompletedProcess result.

    Raises:
        ValidationError: On non-zero exit or timeout.
    """
    cmd = [ab_path, "--session", session, *args]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            stdout = result.stdout.strip()
            detail = stderr or stdout or "Unknown error"
            raise ValidationError(
                message=f"agent-browser '{args[0]}' failed: {detail}",
                code="DXS-RPT-042",
                suggestions=[
                    "Ensure agent-browser is installed: agent-browser install",
                    "Check that the report file is valid: dxs report validate <file>",
                ],
            )
        return result
    except subprocess.TimeoutExpired as exc:
        raise ValidationError(
            message=f"agent-browser '{args[0]}' timed out after {timeout}s",
            code="DXS-RPT-043",
            suggestions=[
                "The report may be too complex or agent-browser may be hung",
                "Try increasing --timeout or simplifying the report",
            ],
        ) from exc


def _run_agent_browser(
    ab_path: str,
    url: str,
    output_path: Path,
    vp_width: int,
    vp_height: int,
    per_page: bool,
    timeout: int,
) -> dict[str, Any]:
    """Execute agent-browser commands to capture the rendered report.

    Each command is a separate CLI invocation sharing the same named session.

    Returns:
        Dict with output metadata.

    Raises:
        ValidationError: If agent-browser commands fail.
    """
    session = f"dxs-preview-{_find_free_port()}"  # unique session name

    try:
        # 1. Open the page
        _ab_exec(ab_path, ["open", url], timeout=15, session=session)

        # 2. Wait for report to finish rendering
        _ab_exec(
            ab_path,
            ["wait", "[data-render-complete]"],
            timeout=timeout + 10,
            session=session,
        )

        # 3. Set viewport to match page aspect ratio
        _ab_exec(
            ab_path,
            ["set", "viewport", str(vp_width), str(vp_height)],
            timeout=10,
            session=session,
        )

        # 4. Take screenshot
        _ab_exec(
            ab_path,
            ["screenshot", str(output_path), "--full"],
            timeout=15,
            session=session,
        )
    finally:
        # 5. Always close the browser session
        try:
            _ab_exec(ab_path, ["close"], timeout=10, session=session)
        except (ValidationError, Exception):
            pass  # best-effort cleanup

    if not output_path.exists():
        raise ValidationError(
            message=f"Screenshot file was not created: {output_path}",
            code="DXS-RPT-044",
            suggestions=[
                "agent-browser may have failed silently",
                "Try running with --verbose for more details",
            ],
        )

    return {
        "file": str(output_path),
        "output_path": str(output_path.resolve()),
        "pages": 1,
        "width_px": vp_width,
        "height_px": vp_height,
    }


def stitch_pages(page_paths: list[Path], output_path: Path) -> None:
    """Stitch multiple page PNGs into a single vertical image.

    Requires Pillow (installed via `datex-studio-cli[preview]`).

    Args:
        page_paths: Ordered list of page PNG file paths.
        output_path: Output path for the stitched image.

    Raises:
        ValidationError: If Pillow is not installed.
    """
    try:
        from PIL import Image
    except ImportError as exc:
        raise ValidationError(
            message="Pillow is required for multi-page stitching",
            code="DXS-RPT-045",
            suggestions=[
                "Install with: uv pip install 'datex-studio-cli[preview]'",
                "Or: pip install Pillow>=10.0.0",
            ],
        ) from exc

    images = [Image.open(p) for p in page_paths]
    total_width = max(img.width for img in images)
    total_height = sum(img.height for img in images)

    stitched = Image.new("RGB", (total_width, total_height), (255, 255, 255))
    y_offset = 0
    for img in images:
        stitched.paste(img, (0, y_offset))
        y_offset += img.height

    stitched.save(str(output_path))

    for img in images:
        img.close()
