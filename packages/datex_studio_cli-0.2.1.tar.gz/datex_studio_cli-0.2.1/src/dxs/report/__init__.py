"""Report authoring module for RDL (RDLX-JSON) report definitions."""
