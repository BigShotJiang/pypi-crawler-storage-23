"""Core engine for reading, writing, and mutating RDL report definitions.

Handles report creation, scaffolding from templates, and element manipulation.
"""

from __future__ import annotations

import json
from importlib import resources
from typing import Any

from dxs.report.models import (
    Body,
    CustomProperty,
    DataSource,
    Layer,
    PageSettings,
    ReportDefinition,
    ReportItem,
    ReportSection,
)
from dxs.report.schema import PAGE_SIZES
from dxs.utils.errors import ValidationError


def parse_page_size(page_size: str) -> tuple[str, str]:
    """Parse a page size string into width and height.

    Args:
        page_size: Named size (letter, legal, a4, 4x6, 4x8) or WxH format.

    Returns:
        Tuple of (width, height) as strings.

    Raises:
        ValidationError: If page size format is invalid.
    """
    # Check named sizes
    if page_size.lower() in PAGE_SIZES:
        info = PAGE_SIZES[page_size.lower()]
        return info["width"], info["height"]

    # Try WxH format (e.g., "8.5inx11in" or "4inx6in")
    parts = page_size.lower().split("x")
    if len(parts) == 2:
        w, h = parts[0].strip(), parts[1].strip()
        # Ensure they have units
        if not any(w.endswith(u) for u in ("in", "cm", "mm", "pt")):
            w += "in"
        if not any(h.endswith(u) for u in ("in", "cm", "mm", "pt")):
            h += "in"
        return w, h

    raise ValidationError(
        message=f"Invalid page size: '{page_size}'",
        code="DXS-RPT-013",
        suggestions=[
            f"Named sizes: {', '.join(PAGE_SIZES.keys())}",
            "Or use WxH format: 8.5inx11in, 4inx6in",
        ],
    )


def create_blank_report(
    name: str = "Report",
    page_size: str = "letter",
    margins: str = "0.5in",
    landscape: bool = False,
) -> ReportDefinition:
    """Create a blank report definition with page setup.

    Args:
        name: Report name.
        page_size: Named size or WxH format.
        margins: Margin size for all sides.
        landscape: Use landscape orientation.

    Returns:
        New ReportDefinition with one empty section.
    """
    width, height = parse_page_size(page_size)

    if landscape:
        width, height = height, width

    page = PageSettings(
        PageWidth=width,
        PageHeight=height,
        TopMargin=margins,
        BottomMargin=margins,
        LeftMargin=margins,
        RightMargin=margins,
    )

    # Calculate content width (page width minus margins)
    section = ReportSection(
        Type="Continuous",
        Name="Section1",
        Page=page,
        Body=Body(ReportItems=[]),
    )

    return ReportDefinition(
        Name=name,
        Width=width,
        Page=page,
        ReportSections=[section],
        DataSources=[DataSource(Name="Datasource")],
        CustomProperties=[
            CustomProperty(Name="DisplayType", Value="Page"),
            CustomProperty(Name="SizeType", Value="Default"),
        ],
        Layers=[Layer(Name="default")],
    )


def scaffold_report(
    template_name: str,
    page_size_override: str | None = None,
) -> ReportDefinition:
    """Create a report from a built-in template.

    Args:
        template_name: Template identifier (bill-of-lading, shipping-label).
        page_size_override: Optional page size to override template default.

    Returns:
        ReportDefinition populated from the template.

    Raises:
        ValidationError: If template not found.
    """
    # Map template names to filenames
    template_files = {
        "bill-of-lading": "bill_of_lading.rdlx-json",
        "shipping-label": "shipping_label.rdlx-json",
    }

    filename = template_files.get(template_name.lower())
    if filename is None:
        raise ValidationError(
            message=f"Unknown template: '{template_name}'",
            code="DXS-RPT-014",
            suggestions=[f"Available templates: {', '.join(template_files.keys())}"],
        )

    # Load from package resources
    template_data = _load_template(filename)
    report_def = ReportDefinition.model_validate(template_data)

    # Apply page size override if provided
    if page_size_override:
        width, height = parse_page_size(page_size_override)
        report_def.Page.PageWidth = width
        report_def.Page.PageHeight = height
        report_def.Width = width
        for section in report_def.ReportSections:
            if section.Page:
                section.Page.PageWidth = width
                section.Page.PageHeight = height

    return report_def


def _load_template(filename: str) -> dict[str, Any]:
    """Load a template file from package resources.

    Args:
        filename: Template filename.

    Returns:
        Parsed template data.
    """
    template_pkg = resources.files("dxs.report.templates")
    template_file = template_pkg.joinpath(filename)
    content = template_file.read_text(encoding="utf-8")
    return json.loads(content)  # type: ignore[no-any-return]


def add_item(report_def: ReportDefinition, item_props: dict[str, Any], section_index: int = 0) -> ReportItem:
    """Add a new report item to a section.

    Args:
        report_def: The report definition to modify.
        item_props: Properties for the new item.
        section_index: Which section to add to (default: first).

    Returns:
        The created ReportItem.

    Raises:
        ValidationError: If name already exists.
    """
    name = item_props.get("Name", "")

    # Check for duplicate names
    existing = report_def.find_item(name)
    if existing is not None:
        raise ValidationError(
            message=f"Element name '{name}' already exists in report",
            code="DXS-RPT-015",
            suggestions=[f"Choose a unique name (existing: {', '.join(i.Name for i in report_def.all_items())})"],
        )

    # Ensure section exists
    section = report_def.get_section(section_index)

    item = ReportItem.model_validate(item_props)
    section.Body.ReportItems.append(item)
    return item


def set_item_properties(item: ReportItem, updates: dict[str, Any]) -> None:
    """Update properties on an existing report item.

    Args:
        item: The report item to update.
        updates: Dictionary of property updates.
    """
    for key, value in updates.items():
        if key == "Style":
            # Merge style properties rather than replacing
            if item.Style is None:
                item.Style = {}
            item.Style.update(value)
        elif hasattr(item, key):
            setattr(item, key, value)
        else:
            # Store as extra field
            if item.model_extra is None:
                object.__setattr__(item, "__pydantic_extra__", {})
            if item.model_extra is not None:
                item.model_extra[key] = value


def remove_item(report_def: ReportDefinition, name: str) -> bool:
    """Remove a report item by name.

    Args:
        report_def: The report definition to modify.
        name: Name of the item to remove.

    Returns:
        True if item was found and removed, False otherwise.
    """
    location = report_def.find_item_location(name)
    if location is None:
        return False

    si, ii = location
    report_def.ReportSections[si].Body.ReportItems.pop(ii)
    return True
