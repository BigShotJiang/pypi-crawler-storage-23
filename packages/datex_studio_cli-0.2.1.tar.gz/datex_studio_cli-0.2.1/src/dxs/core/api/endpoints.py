"""API endpoint path definitions for Datex Studio API.

Note: Paths are relative to the base URL (e.g., https://wavelength.host/api).
Do not include /api prefix as it's part of the base URL.
"""

from typing import Any


class SourceControlEndpoints:
    """Source control API endpoints.

    Base: /sourcecontrol (relative to api_base_url)
    """

    @staticmethod
    def locks(repo_id: int) -> str:
        """Get all locks for a repository."""
        return f"/sourcecontrol/{repo_id}/locks"

    @staticmethod
    def history(repo_id: int) -> str:
        """Get commit history for a repository."""
        return f"/sourcecontrol/{repo_id}/history"

    @staticmethod
    def branch_history(branch_id: int) -> str:
        """Get commit history for a specific branch."""
        return f"/sourcecontrol/application/{branch_id}/history"

    @staticmethod
    def configuration_history(branch_id: int, reference_name: str) -> str:
        """Get version history for a specific configuration."""
        return f"/sourcecontrol/{branch_id}/configuration/{reference_name}/history"

    @staticmethod
    def upstream_changes(branch_id: int) -> str:
        """Get upstream (base branch) changes."""
        return f"/sourcecontrol/{branch_id}/upstreamChanges"

    @staticmethod
    def feature_branch_changes(branch_id: int) -> str:
        """Get feature branch changes compared to base."""
        return f"/sourcecontrol/{branch_id}/featureBranchChanges"

    @staticmethod
    def history_branch_changes(branch_id: int) -> str:
        """Get branch changes with commit details."""
        return f"/sourcecontrol/{branch_id}/historyBranchChanges"

    @staticmethod
    def replacements_history(branch_id: int) -> str:
        """Get history of configuration replacement changes."""
        return f"/sourcecontrol/{branch_id}/replacements/history"

    @staticmethod
    def settings_and_references_history(branch_id: int) -> str:
        """Get history of settings and references changes."""
        return f"/sourcecontrol/{branch_id}/settings-and-references/history"

    @staticmethod
    def operations_and_roles_history(branch_id: int) -> str:
        """Get history of operations and roles changes."""
        return f"/sourcecontrol/{branch_id}/operations-and-roles/history"

    # Lock operations (for future use)
    @staticmethod
    def lock_config(branch_id: int, reference_name: str) -> str:
        """Lock a specific configuration."""
        return f"/sourcecontrol/{branch_id}/config/{reference_name}/lock"

    @staticmethod
    def unlock_config(branch_id: int, reference_name: str) -> str:
        """Unlock a specific configuration."""
        return f"/sourcecontrol/{branch_id}/config/{reference_name}/unlock"

    @staticmethod
    def commit(branch_id: int) -> str:
        """Commit changes."""
        return f"/sourcecontrol/{branch_id}/commit"

    @staticmethod
    def pull(branch_id: int) -> str:
        """Pull changes from base branch."""
        return f"/sourcecontrol/{branch_id}/pull"

    @staticmethod
    def create_feature_branch(branch_id: int) -> str:
        """Create a feature branch."""
        return f"/sourcecontrol/{branch_id}/createFeatureBranch"

    @staticmethod
    def suggest(branch_id: int) -> str:
        """Get AI-suggested commit message from SideKick."""
        return f"/sourcecontrol/{branch_id}/suggest"


class OrganizationEndpoints:
    """Organization API endpoints."""

    @staticmethod
    def list() -> str:
        """List all organizations."""
        return "/organizations"

    @staticmethod
    def get(org_id: int) -> str:
        """Get organization by ID."""
        return f"/organizations/{org_id}"

    @staticmethod
    def mine() -> str:
        """Get current user's organization."""
        return "/organizations/mine"


class RepoEndpoints:
    """Repository (ApplicationDefinition) API endpoints."""

    @staticmethod
    def list(org_id: int | None = None) -> tuple[str, dict[str, int]]:
        """List repositories, optionally filtered by organization.

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        params: dict[str, int] = {}
        if org_id:
            params["organizationId"] = org_id
        return "/applicationdefinitions", params

    @staticmethod
    def get(repo_id: int) -> str:
        """Get repository by ID."""
        return f"/applicationdefinitions/{repo_id}"


class ApplicationGroupEndpoints:
    """Application Group API endpoints.

    Groups organize branches within a repository. Each repository has one or more
    groups (typically a "Default" group). Service Pack groups allow creating
    maintenance branches from published versions.

    Group Types:
        0 = Default (main development group)
        1 = ServicePack (maintenance branch from published version)
    """

    @staticmethod
    def list(repo_id: int, group_type_id: int | None = None) -> tuple[str, dict[str, int]]:
        """List application groups for a repository.

        Args:
            repo_id: Repository (ApplicationDefinition) ID
            group_type_id: Optional filter by group type (0=Default, 1=ServicePack)

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        params: dict[str, int] = {"applicationDefinitionId": repo_id}
        if group_type_id is not None:
            params["applicationGroupTypeId"] = group_type_id
        return "/applicationgroups", params

    @staticmethod
    def get(group_id: int) -> str:
        """Get application group by ID."""
        return f"/applicationgroups/{group_id}"

    @staticmethod
    def create() -> str:
        """Create a service pack group."""
        return "/applicationgroups"

    @staticmethod
    def delete(group_id: int) -> str:
        """Delete an application group."""
        return f"/applicationgroups/{group_id}"


class BranchEndpoints:
    """Branch (Application) API endpoints."""

    @staticmethod
    def list(group_id: int, status_ids: list[int] | None = None) -> tuple[str, dict[str, Any]]:
        """List branches by application group ID.

        Args:
            group_id: Application group ID (from ApplicationGroupEndpoints.list())
            status_ids: Optional list of status IDs to filter by (1=draft, 2=inactive, 3=active, 4=history)

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
            httpx serialises list values as repeated query parameters (e.g. ?key=1&key=2).
        """
        params: dict[str, Any] = {"applicationGroupId": group_id}
        if status_ids:
            params["applicationStatusIds"] = status_ids
        return "/applications", params

    @staticmethod
    def get(branch_id: int) -> str:
        """Get branch by ID."""
        return f"/applications/{branch_id}"

    @staticmethod
    def roles(branch_id: int) -> str:
        """Get branch roles."""
        return f"/applications/{branch_id}/roles"

    @staticmethod
    def shell(branch_id: int) -> str:
        """Get branch shell configuration."""
        return f"/applications/{branch_id}/shell"

    @staticmethod
    def validate(branch_id: int) -> str:
        """Validate branch."""
        return f"/applications/{branch_id}/validate"

    @staticmethod
    def candelete(branch_id: int) -> str:
        """Check if branch can be deleted."""
        return f"/applications/{branch_id}/candelete"

    @staticmethod
    def delete(branch_id: int) -> str:
        """Delete a branch."""
        return f"/applications/{branch_id}"

    @staticmethod
    def replacements(branch_id: int) -> str:
        """Get configuration replacements for a branch."""
        return f"/applications/{branch_id}/configurationreplacements"

    @staticmethod
    def settings(branch_id: int) -> str:
        """Get application settings for a branch."""
        return f"/applications/{branch_id}/settings"

    @staticmethod
    def operations(branch_id: int) -> str:
        """Get operations for a branch."""
        return f"/applications/{branch_id}/operations"

    @staticmethod
    def publish(branch_id: int) -> str:
        """Publish a branch to the marketplace."""
        return f"/applications/{branch_id}/publish"


class UserEndpoints:
    """User API endpoints."""

    @staticmethod
    def list() -> str:
        """List all users."""
        return "/users"

    @staticmethod
    def get(user_id: int) -> str:
        """Get user by ID."""
        return f"/users/{user_id}"

    @staticmethod
    def studio_access(user_id: int) -> str:
        """Update user studio access."""
        return f"/users/{user_id}/studioaccess"


class MarketplaceEndpoints:
    """Marketplace application and version API endpoints."""

    @staticmethod
    def list(org_id: int | None = None) -> str:
        """List marketplace applications, optionally filtered by organization."""
        if org_id:
            return f"/marketplaceapplications?organizationId={org_id}"
        return "/marketplaceapplications"

    @staticmethod
    def get(app_id: int) -> str:
        """Get marketplace application by ID."""
        return f"/marketplaceapplications/{app_id}"

    @staticmethod
    def versions(app_id: int) -> str:
        """List published versions of a marketplace application."""
        return f"/marketplaceapplications/{app_id}/versions"

    @staticmethod
    def version(version_id: int) -> str:
        """Get marketplace application version by ID."""
        return f"/marketplaceapplicationversions/{version_id}"


class DependencyEndpoints:
    """Application dependency (references) API endpoints."""

    @staticmethod
    def list(branch_id: int) -> str:
        """List direct dependencies for a branch."""
        return f"/applications/{branch_id}/references"

    @staticmethod
    def all_references(branch_id: int) -> str:
        """List all references including transitive dependencies."""
        return f"/applications/{branch_id}/allreferences"


class WorkitemEndpoints:
    """Application work items API endpoints."""

    @staticmethod
    def list(branch_id: int) -> str:
        """List work items linked to a branch."""
        return f"/applications/{branch_id}/applicationworkitems"


class ConfigurationEndpoints:
    """Configuration content API endpoints."""

    # Canonical singular config type names used in API endpoint paths.
    # The featureBranchChanges API sometimes returns plural forms (e.g., "endpoints")
    # but the config content endpoints require singular (e.g., "endpoint").
    KNOWN_TYPES = frozenset({
        "grid", "hub", "form", "editor", "shell", "calendar", "list", "widget",
        "selector", "datasource", "flow", "frontendflow", "wizard", "card",
        "report", "embed", "codeeditor", "visualization", "localization",
        "storage", "customtype", "endpoint", "securitypolicy", "footprintflow",
        "footprintdatasource", "footprintworkflow", "backendtest",
    })

    @staticmethod
    def normalize_type(config_type: str) -> str:
        """Normalize a config type to its singular endpoint form.

        The featureBranchChanges API returns configurationTypeId in inconsistent
        forms — sometimes singular ("flow"), sometimes plural ("endpoints").
        Config content endpoints always require the singular form.
        """
        if config_type in ConfigurationEndpoints.KNOWN_TYPES:
            return config_type
        # Try stripping trailing 's' for plural forms
        if config_type.endswith("s") and config_type[:-1] in ConfigurationEndpoints.KNOWN_TYPES:
            return config_type[:-1]
        return config_type

    @staticmethod
    def list_all(branch_id: int, config_type: str) -> str:
        """List all configurations of a type for a branch."""
        config_type = ConfigurationEndpoints.normalize_type(config_type)
        return f"/applications/{branch_id}/{config_type}configurations"

    @staticmethod
    def get_content(branch_id: int, config_type: str, config_id: int) -> str:
        """Get configuration content by ID."""
        config_type = ConfigurationEndpoints.normalize_type(config_type)
        return f"/applications/{branch_id}/{config_type}configurations/{config_id}"

    @staticmethod
    def get_by_reference(branch_id: int, config_type: str, ref_name: str) -> str:
        """Get configuration by reference name."""
        config_type = ConfigurationEndpoints.normalize_type(config_type)
        return f"/applications/{branch_id}/{config_type}configurations/referenceName/{ref_name}"

    @staticmethod
    def create(branch_id: int, config_type: str) -> str:
        """Create a new configuration (POST)."""
        return f"/applications/{branch_id}/{config_type}configurations"

    @staticmethod
    def update(branch_id: int, config_type: str, config_id: int) -> str:
        """Update an existing configuration (PUT)."""
        return f"/applications/{branch_id}/{config_type}configurations/{config_id}"


class EnvironmentEndpoints:
    """Environment API endpoints."""

    @staticmethod
    def list(org_id: int | None = None) -> str:
        """List environments, optionally filtered by organization."""
        if org_id:
            return f"/environments?organizationId={org_id}"
        return "/environments"

    @staticmethod
    def get(env_id: int) -> str:
        """Get environment by ID."""
        return f"/environments/{env_id}"


class EnvironmentComponentsEndpoints:
    """Environment components API endpoints."""

    @staticmethod
    def list(env_id: int | None = None) -> str:
        """List environment components, optionally filtered by environment."""
        if env_id:
            return f"/environmentcomponents?environmentId={env_id}"
        return "/environmentcomponents"

    @staticmethod
    def get(component_id: int) -> str:
        """Get environment component by ID."""
        return f"/environmentcomponents/{component_id}"

    @staticmethod
    def active_authorized() -> str:
        """Get active environment components the user is authorized to access."""
        return "/environmentcomponents/active/authorized"

    @staticmethod
    def settings(component_id: int) -> str:
        """Get settings for an environment component."""
        return f"/environmentcomponents/{component_id}/settings"

    @staticmethod
    def deploy(component_id: int) -> str:
        """Deploy to an environment component."""
        return f"/environmentcomponents/{component_id}/deploy"


class EnvironmentComponentDefinitionsEndpoints:
    """Environment component definitions API endpoints.

    These provide information about deployed apps including their URLs.
    """

    @staticmethod
    def list(env_id: int) -> str:
        """List component definitions for an environment."""
        return f"/environmentcomponentdefinitions?environmentId={env_id}"

    @staticmethod
    def get(definition_id: int) -> str:
        """Get component definition by ID."""
        return f"/environmentcomponentdefinitions/{definition_id}"


class ApiConnectionEndpoints:
    """API Connection endpoints for OData query execution.

    Uses:
    - /apiconnections for listing all connection types
    - /footprintapiconnections/{id} for getting Footprint connection details
    """

    @staticmethod
    def list(org_id: int | None = None, connection_type_id: int | None = None) -> str:
        """List API connections, optionally filtered by organization or type.

        Args:
            org_id: Filter by organization ID
            connection_type_id: Filter by connection type ID (e.g., Footprint type)
        """
        params = []
        if org_id:
            params.append(f"organizationId={org_id}")
        if connection_type_id:
            params.append(f"apiConnectionTypeId={connection_type_id}")
        if params:
            return f"/apiconnections?{'&'.join(params)}"
        return "/apiconnections"

    @staticmethod
    def get(connection_id: int) -> str:
        """Get API connection info by ID (includes connectionString)."""
        return f"/apiconnections/{connection_id}/info"

    @staticmethod
    def footprint_metadata(connection_id: int) -> str:
        """Get Footprint API connection full metadata (OData schema)."""
        return f"/footprintapiconnections/{connection_id}"

    @staticmethod
    def footprint_info(connection_id: int) -> str:
        """Get Footprint API connection info."""
        return f"/footprintapiconnections/{connection_id}/info"


class ODataEndpoints:
    """OData query execution endpoints."""

    @staticmethod
    def execute() -> str:
        """Execute an OData query."""
        return "/odata/execute"


class FootPrintMetadataEndpoints:
    """Footprint API metadata browsing endpoints.

    These endpoints provide granular access to parsed OData metadata,
    supporting progressive schema discovery with standard OData query parameters.
    """

    @staticmethod
    def _build_odata_params(
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        expand: str | None = None,
        search: str | None = None,
    ) -> dict[str, str | int]:
        """Build OData query parameter dict for httpx URL encoding.

        Returns:
            Dict of OData parameters (only non-None values included).
        """
        params: dict[str, str | int] = {}
        if filter:
            params["$filter"] = filter
        if select:
            params["$select"] = select
        if orderby:
            params["$orderby"] = orderby
        if top:
            params["$top"] = top
        if skip:
            params["$skip"] = skip
        if expand:
            params["$expand"] = expand
        if search:
            params["$search"] = search
        return params

    @staticmethod
    def entity_types(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        expand: str | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List entity types with optional OData query parameters.

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/EntityTypes"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            expand=expand, search=search,
        )

    @staticmethod
    def properties(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List properties with optional OData query parameters.

        Supports $search (server-side substring match on Name, EntityTypeId, TypeId)
        and $filter=EntityTypeId eq '...' to narrow results to a specific entity type.

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/Properties"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            search=search,
        )

    @staticmethod
    def navigation_properties(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List navigation properties with optional OData query parameters.

        Supports $search (server-side substring match on Name, EntityTypeId, TypeId)
        and $filter=EntityTypeId eq '...' to narrow results to a specific entity type.

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/NavigationProperties"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            search=search,
        )

    @staticmethod
    def entity_sets(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        expand: str | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List entity sets with optional OData query parameters.

        Supports $search (server-side substring match on Name, TypeId) and
        $expand=EntityType to embed entity type info (keys, namespace, etc.) in one call.

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/EntitySets"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            expand=expand, search=search,
        )

    @staticmethod
    def enum_types(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List enum types with optional OData query parameters.

        Supports $search (server-side substring match on Name, Namespace, TypeId).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/EnumTypes"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            search=search,
        )

    @staticmethod
    def actions(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List OData actions with optional OData query parameters.

        Supports $search (server-side substring match on Name, Namespace, ActionId).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/Actions"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            search=search,
        )

    @staticmethod
    def functions(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List OData functions with optional OData query parameters.

        Supports $search (server-side substring match on Name, Namespace, FunctionId).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/Functions"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            search=search,
        )

    @staticmethod
    def complex_types(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        expand: str | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List complex types with optional OData query parameters.

        Supports $search (server-side substring match on Name, Namespace, TypeId).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/ComplexTypes"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            expand=expand, search=search,
        )

    @staticmethod
    def singletons(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List singletons with optional OData query parameters.

        Supports $search (server-side substring match on Name, TypeId).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/Singletons"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            search=search,
        )

    @staticmethod
    def action_imports(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List action imports with optional OData query parameters.

        Action imports are named entry points into OData actions exposed in the
        EntityContainer. Supports $search (server-side substring match on Name, ActionId).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/ActionImports"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            search=search,
        )

    @staticmethod
    def function_imports(
        connection_id: int,
        filter: str | None = None,
        select: str | None = None,
        orderby: str | None = None,
        top: int | None = None,
        skip: int | None = None,
        search: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """List function imports with optional OData query parameters.

        Function imports are named entry points into OData functions exposed in the
        EntityContainer. Supports $search (server-side substring match on Name, FunctionId).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/FunctionImports"
        return path, FootPrintMetadataEndpoints._build_odata_params(
            filter=filter, select=select, orderby=orderby, top=top, skip=skip,
            search=search,
        )

    # ===== Key-based (by-ID) endpoints =====

    @staticmethod
    def entity_type_by_key(
        connection_id: int,
        type_id: str,
        expand: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single entity type by its TypeId (key endpoint).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/EntityTypes('{type_id}')"
        params: dict[str, str | int] = {}
        if expand:
            params["$expand"] = expand
        return path, params

    @staticmethod
    def complex_type_by_key(
        connection_id: int,
        type_id: str,
        expand: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single complex type by its TypeId (key endpoint).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/ComplexTypes('{type_id}')"
        params: dict[str, str | int] = {}
        if expand:
            params["$expand"] = expand
        return path, params

    @staticmethod
    def enum_type_by_key(
        connection_id: int,
        type_id: str,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single enum type by its TypeId (key endpoint).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/EnumTypes('{type_id}')"
        return path, {}

    @staticmethod
    def entity_set_by_key(
        connection_id: int,
        name: str,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single entity set by its Name (key endpoint).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/EntitySets('{name}')"
        return path, {}

    @staticmethod
    def action_by_key(
        connection_id: int,
        action_id: str,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single action by its ActionId (key endpoint).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/Actions('{action_id}')"
        return path, {}

    @staticmethod
    def function_by_key(
        connection_id: int,
        function_id: str,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single function by its FunctionId (key endpoint).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/Functions('{function_id}')"
        return path, {}

    @staticmethod
    def action_import_by_key(
        connection_id: int,
        name: str,
        expand: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single action import by its Name (key endpoint).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/ActionImports('{name}')"
        params: dict[str, str | int] = {}
        if expand:
            params["$expand"] = expand
        return path, params

    @staticmethod
    def function_import_by_key(
        connection_id: int,
        name: str,
        expand: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single function import by its Name (key endpoint).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/FunctionImports('{name}')"
        params: dict[str, str | int] = {}
        if expand:
            params["$expand"] = expand
        return path, params

    @staticmethod
    def singleton_by_key(
        connection_id: int,
        name: str,
        expand: str | None = None,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single singleton by its Name (key endpoint).

        Args:
            expand: Optional OData $expand expression. Use
                "EntityType($expand=Properties,NavigationProperties)" to get the
                full entity type schema in a single call.

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = f"/footprintapiconnections/{connection_id}/schema/Singletons('{name}')"
        params: dict[str, str | int] = {}
        if expand:
            params["$expand"] = expand
        return path, params

    @staticmethod
    def property_by_key(
        connection_id: int,
        entity_type_id: str,
        name: str,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single property by its composite key (EntityTypeId + Name).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = (
            f"/footprintapiconnections/{connection_id}/schema"
            f"/Properties(EntityTypeId='{entity_type_id}',Name='{name}')"
        )
        return path, {}

    @staticmethod
    def navigation_property_by_key(
        connection_id: int,
        entity_type_id: str,
        name: str,
    ) -> tuple[str, dict[str, str | int]]:
        """Get a single navigation property by its composite key (EntityTypeId + Name).

        Returns:
            Tuple of (path, params_dict) for proper URL encoding by httpx.
        """
        path = (
            f"/footprintapiconnections/{connection_id}/schema"
            f"/NavigationProperties(EntityTypeId='{entity_type_id}',Name='{name}')"
        )
        return path, {}

    @staticmethod
    def batch(connection_id: int) -> str:
        """Get the OData $batch endpoint path.

        The $batch endpoint is registered as a separate route component in Startup.cs
        using DefaultODataBatchHandler, allowing multiple schema API requests to be
        batched into a single HTTP call.

        Format: POST /api/FootPrintApiConnections/{id}/schema/$batch

        Returns:
            Path string for the batch endpoint.
        """
        return f"/footprintapiconnections/{connection_id}/schema/$batch"

    @staticmethod
    def metadata(connection_id: int) -> str:
        """Get OData metadata document (EDMX XML).

        The $metadata endpoint is served automatically by the OData framework for
        every registered route component. The custom controller method was removed
        in the API refactoring (2026-02-20) — the framework handles it natively.

        Returns:
            Path string (no query parameters for metadata endpoint).
        """
        return f"/footprintapiconnections/{connection_id}/schema/$metadata"
