"""CPL report configuration generator."""

from __future__ import annotations

import json
from typing import Any

from dxs.core.report_data.field_parser import ParsedCollection, parse_fields

# Page dimensions (width, height) by (size, orientation)
_PAGE_DIMENSIONS: dict[tuple[str, str], tuple[str, str]] = {
    ("letter", "portrait"): ("8.5in", "11in"),
    ("letter", "landscape"): ("11in", "8.5in"),
    ("a4", "portrait"): ("8.27in", "11.69in"),
    ("a4", "landscape"): ("11.69in", "8.27in"),
    ("a3", "portrait"): ("11.69in", "16.54in"),
    ("a3", "landscape"): ("16.54in", "11.69in"),
}


def _parse_inches(value: str) -> float:
    """Parse '8.5in' → 8.5."""
    return float(value.rstrip("in"))


def _format_inches(value: float) -> str:
    """Format float as clean inch string.

    Examples: 6.5 → '6.5in', 9.0 → '9in', 6.27 → '6.27in'
    """
    if value == 0:
        return "0in"
    formatted = f"{value:.2f}".rstrip("0").rstrip(".")
    return f"{formatted}in"


def _flatten_name(path: str) -> str:
    """Convert dotted path to CPL field name: 'Account.Name' → 'Account_Name'."""
    return path.replace(".", "_")


def _distribute_widths(
    fields: list[tuple[str, str, str | None, str | None]],
    usable_width: float,
) -> list[str]:
    """Distribute column widths, auto-distributing for fields without explicit widths.

    Args:
        fields: List of (path, label, width_or_none, format_or_none) tuples.
        usable_width: Total available width in inches.

    Returns:
        List of width strings (e.g., ['1in', '3.25in', '3.25in']).
    """
    explicit_total = sum(_parse_inches(w) for _, _, w, _ in fields if w)
    auto_count = sum(1 for _, _, w, _ in fields if not w)

    auto_width = (usable_width - explicit_total) / auto_count if auto_count else 0.0

    return [w if w else _format_inches(auto_width) for _, _, w, _ in fields]


def _resolve_alias(value: str, alias_set: set[str]) -> tuple[str, str]:
    """Resolve alias prefix from a path/collection string.

    If ``value`` starts with a known alias followed by '.', return (alias, rest).
    Otherwise return ('', value).
    """
    if "." in value:
        prefix, rest = value.split(".", 1)
        if prefix in alias_set:
            return prefix, rest
    return "", value


class ReportGenerator:
    """Generates CPL report configuration dicts from structured inputs."""

    def generate(
        self,
        *,
        reference_name: str,
        title: str,
        description: str | None,
        datasources: list[dict[str, Any]],
        in_params: list[tuple[str, str]],
        datasource_params: list[tuple[str, str]],
        datasource_params_by_alias: dict[str, list[tuple[str, str]]] | None = None,
        datasource_param_types: dict[str, str] | None = None,
        per_alias_param_types: dict[str, dict[str, str]] | None = None,
        datasource_param_required: dict[str, bool | None] | None = None,
        per_alias_param_required: dict[str, dict[str, bool | None]] | None = None,
        report_param_required: dict[str, bool] | None = None,
        report_sections: list[dict[str, Any]],
        orientation: str,
        page_size: str,
        static_data: dict[str, list[dict[str, Any]]] | None = None,
    ) -> dict[str, Any]:
        """Build the full report configuration dict."""
        page_width_str, page_height_str = _PAGE_DIMENSIONS[(page_size, orientation)]
        page_width = _parse_inches(page_width_str)
        usable_width = page_width - 2.0  # 1in margin each side

        counter = [1]  # Monotonic textbox name counter
        static_aliases: set[str] = set(static_data.keys()) if static_data else set()

        # Build alias set and extract primary datasource info
        alias_set = {ds["alias"] for ds in datasources}
        primary = datasources[0] if datasources else {"alias": "__empty__"}
        primary_alias = primary["alias"]

        ds_config_entries = []
        for ds in datasources:
            if ds.get("is_static"):
                continue  # Static/inline datasources don't need an API datasource config
            alias = ds["alias"]
            if datasource_params_by_alias is not None:
                # Per-alias routing: global ("") params apply to all; alias-specific only to their target
                global_params = datasource_params_by_alias.get("", [])
                alias_params = datasource_params_by_alias.get(alias, [])
                effective_params = global_params + alias_params
                param_types = (per_alias_param_types or {}).get(alias) or (datasource_param_types or {})
                param_req = (per_alias_param_required or {}).get(alias) or (datasource_param_required or {})
            else:
                # Legacy: same params for all datasources
                effective_params = datasource_params
                param_types = datasource_param_types or {}
                param_req = datasource_param_required or {}
            ds_config_entries.append(
                self._build_datasource_config(
                    config_id=ds["config_id"],
                    module_id=ds["module_id"],
                    alias=alias,
                    config_out_parameters=ds["config_out_parameters"],
                    key_def=ds.get("key_def"),
                    datasource_params=effective_params,
                    param_types=param_types,
                    param_required=param_req,
                )
            )

        section_page = {
            "PageWidth": page_width_str,
            "PageHeight": page_height_str,
            "RightMargin": "1in",
            "LeftMargin": "1in",
            "TopMargin": "1in",
            "BottomMargin": "1in",
            "Columns": 1,
            "ColumnSpacing": "0in",
        }

        # Parse all datasource schemas once
        # alias → (is_coll, flat_fields, collections)
        alias_to_parsed: dict[str, tuple[bool, Any, list[ParsedCollection]]] = {}
        alias_to_field_type_map: dict[str, dict[str, str]] = {}
        for ds in datasources:
            cop = ds.get("config_out_parameters") or []
            _, flat_fields, collections = parse_fields(cop)
            alias_to_parsed[ds["alias"]] = (ds["is_collection"], flat_fields, collections)
            # Build field_type_map for this alias: path → type
            ftm: dict[str, str] = {}
            for pf in flat_fields:
                ftm[pf.path] = pf.type
            alias_to_field_type_map[ds["alias"]] = ftm

        # Build a combined field_type_map across all aliases (for lookup by path alone)
        combined_field_type_map: dict[str, str] = {}
        for ftm in alias_to_field_type_map.values():
            combined_field_type_map.update(ftm)

        datasets: list[dict[str, Any]] = []
        sections: list[dict[str, Any]] = []

        # --- Build datasets ---

        # Collect card sections grouped by alias
        # alias → list of (path, label, width_or_none)
        card_fields_by_alias: dict[str, list[tuple[str, str, str | None]]] = {}
        for s in report_sections:
            if s["type"] == "card":
                alias = s.get("alias") or primary_alias
                if alias not in card_fields_by_alias:
                    card_fields_by_alias[alias] = []
                card_fields_by_alias[alias].extend(s["fields"])

        # Nav-collection reference fields per alias (for $dataset: resolution)
        # alias → set of collection names
        nav_collections_by_alias: dict[str, set[str]] = {}
        for s in report_sections:
            if s["type"] == "table":
                coll = s.get("collection") or ""
                # Resolve which alias this table belongs to
                table_alias = s.get("alias") or primary_alias
                if coll and coll not in alias_set:
                    if table_alias not in nav_collections_by_alias:
                        nav_collections_by_alias[table_alias] = set()
                    nav_collections_by_alias[table_alias].add(coll)

        # Build card/root datasets
        # We build one dataset per alias that has card fields or nav collections
        all_card_aliases = set(card_fields_by_alias.keys()) | set(nav_collections_by_alias.keys())
        # Also ensure primary alias has a dataset if there are nav-property tables
        for s in report_sections:
            if s["type"] == "table":
                coll = s.get("collection") or ""
                if coll and coll not in alias_set:
                    table_alias = s.get("alias") or primary_alias
                    all_card_aliases.add(table_alias)

        for alias in all_card_aliases:
            card_f = card_fields_by_alias.get(alias, [])
            nav_f: list[tuple[str, str, str | None, str | None]] = [
                (coll, coll, None, None) for coll in sorted(nav_collections_by_alias.get(alias, set()))
            ]
            combined_fields = card_f + nav_f
            if combined_fields:
                ds_info = next((d for d in datasources if d["alias"] == alias), primary)
                ds_is_coll = ds_info["is_collection"]
                json_path = f"$.{alias}.result.*" if ds_is_coll else f"$.{alias}.result"
                ftm = alias_to_field_type_map.get(alias, {})
                datasets.append(self._build_dataset(alias, combined_fields, json_path, field_type_map=ftm))

        # Build table datasets
        table_idx = 1
        for s in report_sections:
            if s["type"] == "table":
                collection = s.get("collection") or ""
                table_alias = s.get("alias") or primary_alias
                if collection in static_aliases:
                    # Inline static datasource — data is embedded in StaticDatasource
                    ds_name = collection
                    ftm = alias_to_field_type_map.get(collection, {})
                    datasets.append(self._build_dataset(
                        ds_name,
                        s["fields"],
                        query={"DataSourceName": "StaticDatasource", "CommandText": f"$.{collection}.*"},
                        field_type_map=ftm,
                    ))
                elif collection in alias_set:
                    # Collection matches a secondary datasource alias
                    ds_name = collection
                    ds_info = next(d for d in datasources if d["alias"] == collection)
                    ds_is_coll = ds_info["is_collection"]
                    json_path = f"$.{collection}.result.*" if ds_is_coll else f"$.{collection}.result"
                    ftm = alias_to_field_type_map.get(collection, {})
                    datasets.append(self._build_dataset(ds_name, s["fields"], json_path, field_type_map=ftm))
                elif collection:
                    # Nav property within a datasource
                    ds_name = f"{table_alias}_{collection}"
                    ftm = alias_to_field_type_map.get(table_alias, {})
                    datasets.append(
                        self._build_dataset(
                            ds_name,
                            s["fields"],
                            query={"DataSourceName": f"$dataset:{table_alias}/{collection}"},
                            field_type_map=ftm,
                        )
                    )
                    # Build nested collection datasets recursively
                    _, _, parsed_collections = alias_to_parsed.get(table_alias, (False, [], []))
                    matching_coll = next(
                        (c for c in parsed_collections if c.path == collection), None
                    )
                    if matching_coll and matching_coll.collections:
                        self._build_nested_datasets(
                            ds_name, matching_coll, datasets, combined_field_type_map
                        )
                else:
                    # Flat table on the alias datasource root
                    ds_info = next((d for d in datasources if d["alias"] == table_alias), primary)
                    ds_is_coll = ds_info["is_collection"]
                    json_path = f"$.{table_alias}.result.*" if ds_is_coll else f"$.{table_alias}.result"
                    ds_name = f"{table_alias}_t{table_idx}"
                    table_idx += 1
                    ftm = alias_to_field_type_map.get(table_alias, {})
                    datasets.append(self._build_dataset(ds_name, s["fields"], json_path, field_type_map=ftm))

        # Collect summary sections keyed by (alias, collection) for lookup during section building
        summary_map: dict[tuple[str, str], list[tuple[str, str, str | None]]] = {}
        for s in report_sections:
            if s["type"] == "summary":
                coll = s.get("collection") or ""
                s_alias = s.get("alias") or primary_alias
                key = (s_alias, coll)
                if key not in summary_map:
                    summary_map[key] = []
                summary_map[key].extend(s["fields"])

        # Build CPL sections (skip summary — they are consumed by table sections)
        table_idx = 1
        table_widget_n = 0
        section_n = 0
        for s in report_sections:
            if s["type"] == "summary":
                continue  # consumed by table

            section_n += 1
            section_name = f"ContinuousSection{section_n}"

            if s["type"] == "card":
                alias = s.get("alias") or primary_alias
                sections.append(
                    self._build_card_section(
                        name=section_name,
                        dataset_name=alias,
                        fields=s["fields"],
                        usable_width=usable_width,
                        section_page=section_page,
                        counter=counter,
                        value_alias=alias if alias != primary_alias else None,
                    )
                )

            elif s["type"] == "table":
                table_widget_n += 1
                collection = s.get("collection") or ""
                table_alias = s.get("alias") or primary_alias
                if collection in static_aliases or collection in alias_set:
                    ds_name = collection
                elif collection:
                    ds_name = f"{table_alias}_{collection}"
                else:
                    ds_name = f"{table_alias}_t{table_idx}"
                    table_idx += 1
                widths = _distribute_widths(s["fields"], usable_width)
                sum_key = (table_alias, collection)
                summary_fields = summary_map.get(sum_key)
                sections.append(
                    self._build_table_section(
                        name=section_name,
                        table_name=f"Table{table_widget_n}",
                        dataset_name=ds_name,
                        fields=s["fields"],
                        widths=widths,
                        usable_width=usable_width,
                        section_page=section_page,
                        counter=counter,
                        summary_fields=summary_fields,
                    )
                )

            elif s["type"] == "image":
                alias = s.get("alias") or primary_alias
                field_name = _flatten_name(s["fields"][0][0]) if s["fields"] else ""
                sections.append(
                    self._build_image_section(
                        name=section_name,
                        dataset_name=alias,
                        field_name=field_name,
                        section_page=section_page,
                        usable_width=usable_width,
                    )
                )

            elif s["type"] == "label":
                text = s["fields"][0][0] if s["fields"] else ""
                sections.append(
                    self._build_label_section(
                        name=section_name,
                        text=text,
                        section_page=section_page,
                        usable_width=usable_width,
                        counter=counter,
                    )
                )

        definition: dict[str, Any] = {
            "Name": "multisectionreport1",
            "Width": "0in",
            "Layers": [{"Name": "default"}],
            "CustomProperties": [
                {"Name": "DisplayType", "Value": "Page"},
                {"Name": "SizeType", "Value": "Default"},
                {"Name": "PaperOrientation", "Value": orientation.capitalize()},
            ],
            "Page": {
                "PageWidth": page_width_str,
                "PageHeight": page_height_str,
                "RightMargin": "0in",
                "LeftMargin": "0in",
                "TopMargin": "0in",
                "BottomMargin": "0in",
                "Columns": 1,
                "ColumnSpacing": "0.5in",
            },
            "DataSources": self._build_data_sources(static_data),
            "DataSets": datasets,
            "ReportSections": sections,
        }

        return {
            "configurationTypeId": 15,
            "referenceName": reference_name,
            "title": title,
            "description": description,
            "accessModifier": "public",
            "inParams": [
                {
                    "id": name,
                    "type": typ,
                    "required": (report_param_required or {}).get(name, True),
                }
                for name, typ in in_params
            ],
            "datasourceConfigs": ds_config_entries,
            "reportType": "CPL",
            "report": {"definition": definition},
        }

    def _build_data_sources(
        self,
        static_data: dict[str, list[dict[str, Any]]] | None,
    ) -> list[dict[str, Any]]:
        """Build the DataSources list, adding StaticDatasource when static data is present."""
        sources: list[dict[str, Any]] = [
            {
                "Name": "Datasource",
                "ConnectionProperties": {
                    "DataProvider": "JSONEMBED",
                    "ConnectString": "jsondata={}",
                },
            }
        ]
        if static_data:
            sources.append({
                "Name": "StaticDatasource",
                "ConnectionProperties": {
                    "DataProvider": "JSONEMBED",
                    "ConnectString": f"jsondata={json.dumps(static_data)}",
                },
            })
        return sources

    def _build_nested_datasets(
        self,
        parent_name: str,
        parsed_collection: ParsedCollection,
        all_datasets: list[dict[str, Any]],
        field_type_map: dict[str, str],
    ) -> None:
        """Recursively build nested collection DataSets for sub-collections."""
        for nc in parsed_collection.collections:
            ds_name = f"{parent_name}_{_flatten_name(nc.path)}"
            all_datasets.append(
                self._build_dataset(
                    ds_name,
                    [(f.path, f.path, None, None) for f in nc.fields],
                    query={"DataSourceName": f"$dataset:{parent_name}/{nc.path}"},
                    field_type_map=field_type_map,
                )
            )
            if nc.collections:
                self._build_nested_datasets(ds_name, nc, all_datasets, field_type_map)

    def _build_datasource_config(
        self,
        *,
        config_id: str,
        module_id: str | None,
        alias: str,
        config_out_parameters: list[dict[str, Any]],
        key_def: list[dict[str, Any]] | None = None,
        datasource_params: list[tuple[str, str]],
        param_types: dict[str, str],
        param_required: dict[str, bool | None] | None = None,
    ) -> dict[str, Any]:
        """Build the datasourceConfigs[] entry."""
        config_parameters = [
            {
                "parameter": {
                    "id": ds_param,
                    "type": param_types.get(ds_param, "string"),
                    "required": (param_required or {}).get(ds_param),
                },
                "value": expr,
            }
            for ds_param, expr in datasource_params
        ]
        return {
            "datasourceConfig": {
                "configId": config_id,
                "moduleId": module_id,
                "isOwned": None,
                "configOutParameters": config_out_parameters,
                "configParameters": config_parameters,
                "datasourceKeyDef": key_def or None,
            },
            "alias": alias,
        }

    def _build_dataset(
        self,
        name: str,
        fields: list[tuple[str, str, str | None, str | None]],
        json_path: str | None = None,
        *,
        query: dict[str, Any] | None = None,
        field_type_map: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Build a DataSet entry for the CPL definition."""
        ftm = field_type_map or {}
        ds_fields = []
        for path, _, _, _ in fields:
            data_field = path
            if ftm.get(path) == "date":
                data_field = f"{path}[Date|YYYY-MM-DDTHH:mm:ss.fffffff]"
            ds_fields.append({"Name": _flatten_name(path), "DataField": data_field})

        resolved_query: dict[str, Any] = (
            query if query is not None
            else {"DataSourceName": "Datasource", "CommandText": json_path}
        )
        return {
            "Name": name,
            "Fields": ds_fields,
            "Query": resolved_query,
            "CaseSensitivity": "Auto",
            "KanatypeSensitivity": "Auto",
            "AccentSensitivity": "Auto",
            "WidthSensitivity": "Auto",
        }

    def _build_table_section(
        self,
        *,
        name: str,
        table_name: str = "Table1",
        dataset_name: str,
        fields: list[tuple[str, str, str | None, str | None]],
        widths: list[str],
        usable_width: float,
        section_page: dict[str, Any],
        counter: list[int],
        summary_fields: list[tuple[str, str, str | None, str | None]] | None = None,
    ) -> dict[str, Any]:
        """Build a ReportSection with a table ReportItem."""
        usable_str = _format_inches(usable_width)
        table_columns = [{"Width": w} for w in widths]

        padding_style = {
            "PaddingLeft": "2pt",
            "PaddingRight": "2pt",
            "PaddingTop": "2pt",
            "PaddingBottom": "2pt",
        }

        header_cells = []
        for i, (_, label, _, _) in enumerate(fields):
            tb_name = f"TextBox{counter[0]}"
            counter[0] += 1
            header_cells.append({
                "Item": {
                    "Type": "textbox",
                    "Name": tb_name,
                    "CanGrow": True,
                    "KeepTogether": True,
                    "Value": label,
                    "Style": {"FontWeight": "Bold", **padding_style},
                    "Width": widths[i],
                    "Height": "0.25in",
                }
            })

        detail_cells = []
        for i, (path, _, _, fmt) in enumerate(fields):
            cpf_name = _flatten_name(path)
            tb_name = f"TextBox{counter[0]}"
            counter[0] += 1
            cell_style: dict[str, Any] = dict(padding_style)
            if fmt:
                cell_style["Format"] = fmt
            detail_cells.append({
                "Item": {
                    "Type": "textbox",
                    "Name": tb_name,
                    "DataElementName": cpf_name,
                    "CanGrow": True,
                    "KeepTogether": True,
                    "Value": f"=Fields!{cpf_name}.Value",
                    "Style": cell_style,
                    "Width": widths[i],
                    "Height": "0.25in",
                }
            })

        # Build summary lookup: field path → label (from summary_fields)
        summary_by_path: dict[str, str] = {}
        if summary_fields:
            for path, label, _, _ in summary_fields:
                summary_by_path[path] = label

        footer_cells = []
        for i, (path, _, _, _) in enumerate(fields):
            tb_name = f"TextBox{counter[0]}"
            counter[0] += 1
            cpf_name = _flatten_name(path)
            if path in summary_by_path:
                footer_item: dict[str, Any] = {
                    "Type": "textbox",
                    "Name": tb_name,
                    "CanGrow": True,
                    "KeepTogether": True,
                    "Value": f"=Sum(Fields!{cpf_name}.Value)",
                    "Style": padding_style,
                    "Width": widths[i],
                    "Height": "0.25in",
                }
            else:
                footer_item = {
                    "Type": "textbox",
                    "Name": tb_name,
                    "CanGrow": True,
                    "KeepTogether": True,
                    "Style": padding_style,
                    "Width": widths[i],
                    "Height": "0.25in",
                }
            footer_cells.append({"Item": footer_item})

        table: dict[str, Any] = {
            "Type": "table",
            "Name": table_name,
            "ZIndex": 1,
            "DataSetName": dataset_name,
            "TableColumns": table_columns,
            "Header": {
                "TableRows": [{"Height": "0.25in", "TableCells": header_cells}],
                "RepeatOnNewPage": True,
            },
            "Details": {
                "TableRows": [{"Height": "0.25in", "TableCells": detail_cells}],
            },
            "Footer": {
                "TableRows": [{"Height": "0.25in", "TableCells": footer_cells}],
            },
            "Top": "0in",
            "Width": usable_str,
            "Height": "0.75in",
        }

        return {
            "Type": "Continuous",
            "Name": name,
            "Page": section_page,
            "Width": usable_str,
            "Body": {
                "Height": "0.75in",
                "ReportItems": [table],
            },
        }

    def _build_card_section(
        self,
        *,
        name: str,
        dataset_name: str,
        fields: list[tuple[str, str, str | None, str | None]],
        usable_width: float,
        section_page: dict[str, Any],
        counter: list[int],
        value_alias: str | None = None,
    ) -> dict[str, Any]:
        """Build a ReportSection with label/value textbox pairs."""
        usable_str = _format_inches(usable_width)
        label_width = "2in"
        value_width = _format_inches(usable_width - 2.0)

        padding_style = {
            "PaddingLeft": "2pt",
            "PaddingRight": "2pt",
            "PaddingTop": "2pt",
            "PaddingBottom": "2pt",
        }

        items: list[dict[str, Any]] = []
        for row_idx, (path, label, _, fmt) in enumerate(fields):
            cpf_name = _flatten_name(path)
            top = _format_inches(row_idx * 0.25)

            label_tb = f"TextBox{counter[0]}"
            counter[0] += 1
            items.append({
                "Type": "textbox",
                "Name": label_tb,
                "CanGrow": True,
                "KeepTogether": True,
                "Value": label,
                "Style": {"FontWeight": "Bold", **padding_style},
                "Top": top,
                "Left": "0in",
                "Width": label_width,
                "Height": "0.25in",
            })

            value_tb = f"TextBox{counter[0]}"
            counter[0] += 1

            if value_alias:
                # Non-primary alias: use First(..., "alias") for cross-dataset reference
                value_expr = f'=First(Fields!{cpf_name}.Value, "{value_alias}")'
            else:
                value_expr = f"=Fields!{cpf_name}.Value"

            value_style: dict[str, Any] = dict(padding_style)
            if fmt:
                value_style["Format"] = fmt
            items.append({
                "Type": "textbox",
                "Name": value_tb,
                "DataElementName": cpf_name,
                "CanGrow": True,
                "KeepTogether": True,
                "Value": value_expr,
                "Style": value_style,
                "Top": top,
                "Left": "2in",
                "Width": value_width,
                "Height": "0.25in",
            })

        body_height = _format_inches(len(fields) * 0.25)

        return {
            "Type": "Continuous",
            "Name": name,
            "Page": section_page,
            "Width": usable_str,
            "Body": {
                "Height": body_height,
                "ReportItems": items,
            },
        }

    def _build_image_section(
        self,
        *,
        name: str,
        dataset_name: str,
        field_name: str,
        section_page: dict[str, Any],
        usable_width: float,
    ) -> dict[str, Any]:
        """Build a ReportSection containing a single image ReportItem."""
        usable_str = _format_inches(usable_width)
        image_item: dict[str, Any] = {
            "Type": "image",
            "Source": "Database",
            "Value": f'=First(Fields!{field_name}.Value, "{dataset_name}")',
            "MIMEType": "image/png",
            "Sizing": "FitProportional",
            "Width": usable_str,
            "Height": "1in",
        }
        return {
            "Type": "Continuous",
            "Name": name,
            "Page": section_page,
            "Width": usable_str,
            "Body": {
                "Height": "1in",
                "ReportItems": [image_item],
            },
        }

    def _build_label_section(
        self,
        *,
        name: str,
        text: str,
        section_page: dict[str, Any],
        usable_width: float,
        counter: list[int],
    ) -> dict[str, Any]:
        """Build a ReportSection containing a single static textbox."""
        usable_str = _format_inches(usable_width)
        tb_name = f"TextBox{counter[0]}"
        counter[0] += 1
        padding_style = {
            "PaddingLeft": "2pt",
            "PaddingRight": "2pt",
            "PaddingTop": "2pt",
            "PaddingBottom": "2pt",
        }
        textbox: dict[str, Any] = {
            "Type": "textbox",
            "Name": tb_name,
            "CanGrow": True,
            "KeepTogether": True,
            "Value": text,
            "Style": padding_style,
        }
        return {
            "Type": "Continuous",
            "Name": name,
            "Page": section_page,
            "Width": usable_str,
            "Body": {
                "Height": "0.25in",
                "ReportItems": [textbox],
            },
        }
