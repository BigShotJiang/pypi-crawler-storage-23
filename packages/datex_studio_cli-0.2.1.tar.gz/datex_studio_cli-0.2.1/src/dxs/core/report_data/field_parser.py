"""Parse datasource configOutParameters into flat fields and nested collections."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ParsedField:
    """A single scalar or object-path field."""

    path: str
    type: str


@dataclass
class ParsedCollection:
    """A collection navigation property with its own subfields."""

    path: str
    fields: list[ParsedField] = field(default_factory=list)
    collections: list[ParsedCollection] = field(default_factory=list)


def parse_fields(
    config_out_parameters: list[dict[str, Any]],
) -> tuple[bool, list[ParsedField], list[ParsedCollection]]:
    """Parse datasource configOutParameters into structured field lists.

    Recursively walks the objectTypeDef tree:
    - Scalar fields → flat_fields
    - Object fields (non-collection) → recurse, dotted path prefix
    - Collection fields → collections[] with their own subfields

    Args:
        config_out_parameters: The configOutParameters list from a datasource config.

    Returns:
        Tuple of (is_collection, flat_fields, collections) where:
        - is_collection: True if the root result is a collection datasource
        - flat_fields: List of (path, type) for all non-collection fields
        - collections: List of (path, subfields) for collection navigation properties
    """
    if not config_out_parameters:
        return False, [], []

    result_param = config_out_parameters[0]
    is_collection = result_param.get("isCollection", False)
    object_type_def = result_param.get("objectTypeDef") or []

    flat_fields: list[ParsedField] = []
    collections: list[ParsedCollection] = []

    _walk_fields(object_type_def, prefix="", flat_fields=flat_fields, collections=collections)

    return is_collection, flat_fields, collections


def _walk_fields(
    type_def: list[dict[str, Any]],
    prefix: str,
    flat_fields: list[ParsedField],
    collections: list[ParsedCollection],
) -> None:
    """Recursively walk objectTypeDef, building dotted paths."""
    for field_def in type_def:
        field_id = field_def.get("id", "")
        field_type = field_def.get("type", "string")
        is_coll = field_def.get("isCollection", False)
        sub_def = field_def.get("objectTypeDef") or []

        path = f"{prefix}.{field_id}" if prefix else field_id

        if is_coll:
            # Collection nav property — recurse to gather its subfields
            sub_fields: list[ParsedField] = []
            sub_collections: list[ParsedCollection] = []
            _walk_fields(sub_def, prefix="", flat_fields=sub_fields, collections=sub_collections)
            collections.append(ParsedCollection(path=path, fields=sub_fields, collections=sub_collections))
        elif sub_def:
            # Nested object (non-collection) — recurse with dotted prefix
            _walk_fields(sub_def, prefix=path, flat_fields=flat_fields, collections=collections)
        else:
            # Scalar field
            flat_fields.append(ParsedField(path=path, type=field_type))
