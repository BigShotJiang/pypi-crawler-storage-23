"""Report configuration generation package."""

from dxs.core.report_data.generator import ReportGenerator

__all__ = ["ReportGenerator"]
