"""Datasource configuration validator.

Validates datasource JSON configurations against schema and business rules.
"""

import re
from typing import Any

from pydantic import ValidationError as PydanticValidationError

from dxs.core.datasource.models import DatasourceConfig
from dxs.utils.errors import ValidationError

# JavaScript reserved words that cannot be used as identifiers
JS_RESERVED_WORDS = {
    "abstract", "arguments", "await", "boolean", "break", "byte", "case", "catch",
    "char", "class", "const", "continue", "debugger", "default", "delete", "do",
    "double", "else", "enum", "eval", "export", "extends", "false", "final",
    "finally", "float", "for", "function", "goto", "if", "implements", "import",
    "in", "instanceof", "int", "interface", "let", "long", "native", "new",
    "null", "package", "private", "protected", "public", "return", "short",
    "static", "super", "switch", "synchronized", "this", "throw", "throws",
    "transient", "true", "try", "typeof", "var", "void", "volatile", "while",
    "with", "yield",
}


class DatasourceValidator:
    """Validator for datasource JSON configurations."""

    def __init__(self) -> None:
        """Initialize validator."""
        pass

    def _is_valid_js_identifier(self, name: str) -> tuple[bool, str | None]:
        """Check if a string is a valid JavaScript identifier.

        Args:
            name: String to validate

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not name:
            return False, "referenceName cannot be empty"

        # Check if it's a reserved word
        if name.lower() in JS_RESERVED_WORDS:
            return False, f"referenceName '{name}' is a JavaScript reserved word"

        # Valid JavaScript identifier pattern:
        # - Must start with letter (a-z, A-Z), underscore (_), or dollar sign ($)
        # - Can contain letters, digits (0-9), underscores, or dollar signs
        js_identifier_pattern = r"^[a-zA-Z_$][a-zA-Z0-9_$]*$"

        if not re.match(js_identifier_pattern, name):
            return False, (
                f"referenceName '{name}' is not a valid JavaScript identifier "
                "(must start with letter, _, or $ and contain only letters, digits, _, or $)"
            )

        return True, None

    def validate(self, config_dict: dict[str, Any]) -> tuple[bool, list[str]]:
        """Validate datasource configuration.

        Args:
            config_dict: Datasource configuration as dictionary

        Returns:
            Tuple of (is_valid, error_messages)
        """
        errors: list[str] = []

        # 1. Validate against Pydantic schema
        try:
            config = DatasourceConfig(**config_dict)
        except PydanticValidationError as e:
            for error in e.errors():
                loc = ".".join(str(x) for x in error["loc"])
                errors.append(f"{loc}: {error['msg']}")
            return False, errors

        # 2. Business rule validations
        errors.extend(self._validate_business_rules(config))

        return len(errors) == 0, errors

    def _validate_business_rules(self, config: DatasourceConfig) -> list[str]:
        """Validate business rules beyond schema validation.

        Args:
            config: Validated datasource configuration

        Returns:
            List of validation error messages
        """
        errors: list[str] = []

        # Rule: configurationTypeId must be 6
        if config.configurationTypeId != 6:
            errors.append("configurationTypeId must be 6 for datasource configurations")

        # Rule: referenceName must be a valid JavaScript identifier
        if config.referenceName:
            is_valid, error_msg = self._is_valid_js_identifier(config.referenceName)
            if not is_valid:
                errors.append(error_msg or "Invalid referenceName")

        # Rule: paths must have at least one entitySet segment
        if config.paths:
            has_entity_set = any(
                hasattr(seg, "type") and seg.type == "entitySet" for seg in config.paths
            )
            if not has_entity_set:
                errors.append("paths must contain at least one entitySet segment")

        # Rule: if using apply transformations, applyKeyDef must be defined
        if config.queryOptions and config.queryOptions.apply:
            has_groupby = any(
                apply_config.transformation == "groupby" for apply_config in config.queryOptions.apply
            )
            if has_groupby and not config.queryOptions.applyKeyDef:
                errors.append("applyKeyDef must be defined when using groupby transformations")

        # Rule: hasTop/hasSkip flags must match presence of top/skip values
        if config.queryOptions:
            if config.queryOptions.hasTop and not config.queryOptions.top:
                errors.append("hasTop is true but top value is missing")
            if config.queryOptions.hasSkip and not config.queryOptions.skip:
                errors.append("hasSkip is true but skip value is missing")

        # Rule: filter expressions with hasCondition must have condition defined
        if config.queryOptions and config.queryOptions.filters:
            for i, filter_config in enumerate(config.queryOptions.filters):
                if filter_config.hasCondition and not filter_config.condition:
                    errors.append(f"filters[{i}]: hasCondition is true but condition is missing")

        # Rule: linked datasources must reference valid datasources
        if config.linkedDatasources:
            for i, link in enumerate(config.linkedDatasources):
                if not link.datasourceConfig.configId:
                    errors.append(
                        f"linkedDatasources[{i}]: datasourceConfig.configId must not be empty"
                    )

        # Rule: custom columns with explicit type must use a valid JSType
        if config.customColumns:
            valid_types = {"string", "number", "boolean", "date", "object"}
            for i, col in enumerate(config.customColumns):
                if col.type is not None and col.type not in valid_types:
                    errors.append(
                        f"customColumns[{i}].type: '{col.type}' is not a valid JSType"
                    )

        return errors

    def validate_and_raise(self, config_dict: dict[str, Any]) -> DatasourceConfig:
        """Validate and return configuration, or raise ValidationError.

        Args:
            config_dict: Datasource configuration as dictionary

        Returns:
            Validated DatasourceConfig instance

        Raises:
            ValidationError: If validation fails
        """
        is_valid, errors = self.validate(config_dict)

        if not is_valid:
            raise ValidationError(
                message="Datasource configuration validation failed",
                code="DXS-DATASOURCE-VALIDATE-001",
                suggestions=errors,
            )

        return DatasourceConfig(**config_dict)
