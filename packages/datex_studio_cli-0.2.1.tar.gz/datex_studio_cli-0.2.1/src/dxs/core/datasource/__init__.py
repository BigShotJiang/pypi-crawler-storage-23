"""Datasource configuration generation and validation.

This module provides tools for creating Datex datasource JSON configurations
from OData queries, enabling programmatic datasource creation for AI agents.
"""

from dxs.core.datasource.generator import DatasourceGenerator
from dxs.core.datasource.validator import DatasourceValidator

__all__ = ["DatasourceGenerator", "DatasourceValidator"]
