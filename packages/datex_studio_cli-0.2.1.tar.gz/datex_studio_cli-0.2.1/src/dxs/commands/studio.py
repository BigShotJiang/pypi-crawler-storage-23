"""Studio command: dxs studio — launch local web UI for OData exploration."""

import atexit
import shutil
import socket
import subprocess
import sys
from pathlib import Path

import click


@click.command()
@click.option("--port", "-p", type=int, default=5051, help="Port to run the server on")
@click.option(
    "--no-browser",
    is_flag=True,
    default=False,
    help="Don't auto-open browser on startup",
)
@click.option(
    "--dev",
    is_flag=True,
    default=False,
    help="Dev mode: spawns Next.js dev server and proxies frontend requests to it",
)
def studio(port: int, no_browser: bool, dev: bool) -> None:
    """Launch a local web UI for OData data exploration.

    Opens a browser-based interface for visually exploring OData data
    from Footprint API connections. Requires prior authentication
    via 'dxs auth login'.

    \b
    Examples:
        dxs studio
        dxs studio --port 5050
        dxs studio --no-browser
        dxs studio --dev
    """
    try:
        import uvicorn  # noqa: F401
    except ImportError as e:
        raise click.ClickException(
            "Studio requires extra dependencies. Install with:\n\n"
            "  uv pip install 'datex-studio-cli[studio]'\n\n"
            "Or if developing locally:\n\n"
            "  uv sync --extra studio"
        ) from e

    from dxs.core.auth.token_cache import MultiIdentityTokenCache

    # Verify auth before starting server
    cache = MultiIdentityTokenCache()
    identity = cache.get_active_identity()
    if identity is None:
        raise click.ClickException(
            "Not authenticated. Run 'dxs auth login' first."
        )

    next_dev_url: str | None = None

    if dev:
        next_port = _find_free_port()
        frontend_dir = Path(__file__).resolve().parent.parent / "web" / "frontend"
        if not (frontend_dir / "package.json").exists():
            raise click.ClickException(
                f"Frontend directory not found at {frontend_dir}.\n"
                "Dev mode requires the frontend source checkout."
            )

        click.echo(
            f"Starting Next.js dev server on port {next_port}...",
            err=True,
        )
        npm_path = shutil.which("npm") or "npm"
        next_proc = subprocess.Popen(
            [npm_path, "run", "dev", "--", "--port", str(next_port)],
            cwd=str(frontend_dir),
            stdout=sys.stderr,
            stderr=sys.stderr,
        )
        atexit.register(next_proc.terminate)
        next_dev_url = f"http://localhost:{next_port}"

        click.echo(
            f"Starting Datex Studio in dev mode on http://127.0.0.1:{port}\n"
            f"  Proxying frontend to {next_dev_url}",
            err=True,
        )
    else:
        click.echo(f"Starting Datex Studio on http://127.0.0.1:{port}", err=True)

    if not no_browser:
        import threading
        import webbrowser

        def _open_browser() -> None:
            import time

            time.sleep(1)
            webbrowser.open(f"http://127.0.0.1:{port}")

        threading.Thread(target=_open_browser, daemon=True).start()

    from dxs.web.app import create_app

    app = create_app(dev_url=next_dev_url)
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


def _find_free_port() -> int:
    """Find an available TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        port: int = s.getsockname()[1]
        return port
