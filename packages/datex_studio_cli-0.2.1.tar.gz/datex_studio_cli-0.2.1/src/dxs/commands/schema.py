"""Schema discovery commands for progressive OData entity model exploration.

Provides token-efficient commands for AI agents to discover OData entity structures
by consuming metadata endpoints from datex-application-api.
"""

import json
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import click

from dxs.cli import DxsContext, pass_context
from dxs.core.api.client import ApiClient
from dxs.core.api.endpoints import FootPrintMetadataEndpoints
from dxs.core.api.metadata_models import (
    ActionDto,
    ActionImportDto,
    AnnotationDto,
    ComplexTypeDto,
    EntitySetDto,
    EntityTypeDto,
    EnumTypeDto,
    FunctionDto,
    FunctionImportDto,
    NavigationPropertyDto,
    ODataListResponse,
    PropertyDto,
    ReferentialConstraintDto,
    SingletonDto,
)
from dxs.core.auth import require_auth
from dxs.utils.errors import ApiError, ValidationError
from dxs.utils.resolvers import resolve_connection_option
from dxs.utils.responses import list_response, single


def _escape_odata_string(value: str) -> str:
    """Escape a string value for safe inclusion in an OData $filter expression."""
    return value.replace("'", "''")


def _resolve_connection(
    ctx: DxsContext, connection_id: int | None, connection: str | None, org: str | None
) -> int:
    """Resolve connection ID from either direct ID or name-based lookup."""
    return resolve_connection_option(connection_id, connection, org)


def _fetch_entity_sets(
    client: ApiClient,
    connection_id: int,
    top: int | None = None,
    skip: int | None = None,
    filter_expr: str | None = None,
    orderby: str | None = None,
) -> list[EntitySetDto]:
    """Fetch entity sets for a connection.

    Args:
        client: Authenticated API client
        connection_id: Connection ID
        top: Maximum number of entity sets to return
        skip: Number of entity sets to skip (for pagination)
        filter_expr: OData $filter expression
        orderby: OData $orderby expression

    Returns:
        List of entity sets
    """
    path, params = FootPrintMetadataEndpoints.entity_sets(
        connection_id, top=top, skip=skip, filter=filter_expr, orderby=orderby
    )
    response = client.get(path, params=params)
    odata_response = ODataListResponse[EntitySetDto](**response)
    return odata_response.value


def _fetch_entity_type(
    client: ApiClient, connection_id: int, type_id: str, expand: str | None = None
) -> EntityTypeDto | None:
    """Fetch a specific entity type by ID using the key endpoint.

    Args:
        client: Authenticated API client
        connection_id: Connection ID
        type_id: Entity type ID (e.g., "Demo.Warehouse")
        expand: Optional OData $expand expression (e.g., "Properties,NavigationProperties")

    Returns:
        Entity type or None if not found
    """
    path, params = FootPrintMetadataEndpoints.entity_type_by_key(
        connection_id, type_id, expand=expand
    )
    response = client.get(path, params=params)
    if not response:
        return None
    return EntityTypeDto(**response)


def _fetch_properties(
    client: ApiClient, connection_id: int, entity_type_id: str
) -> list[PropertyDto]:
    """Fetch all properties for an entity type.

    Args:
        client: Authenticated API client
        connection_id: Connection ID
        entity_type_id: Entity type ID

    Returns:
        List of properties
    """
    path, params = FootPrintMetadataEndpoints.properties(
        connection_id, filter=f"EntityTypeId eq '{_escape_odata_string(entity_type_id)}'"
    )
    response = client.get(path, params=params)
    odata_response = ODataListResponse[PropertyDto](**response)
    return odata_response.value


def _fetch_navigation_properties(
    client: ApiClient, connection_id: int, entity_type_id: str
) -> list[NavigationPropertyDto]:
    """Fetch all navigation properties for an entity type.

    Args:
        client: Authenticated API client
        connection_id: Connection ID
        entity_type_id: Entity type ID

    Returns:
        List of navigation properties
    """
    path, params = FootPrintMetadataEndpoints.navigation_properties(
        connection_id, filter=f"EntityTypeId eq '{_escape_odata_string(entity_type_id)}'"
    )
    response = client.get(path, params=params)
    odata_response = ODataListResponse[NavigationPropertyDto](**response)
    return odata_response.value


# ========== Bulk Fetch Functions (Optimized Pattern) ==========


def _fetch_all_entity_types(client: ApiClient, connection_id: int) -> list[EntityTypeDto]:
    """Fetch ALL entity types for a connection in a single HTTP call.

    This is more efficient than fetching entity types individually with filters
    when you need data for multiple entities.

    Args:
        client: Authenticated API client
        connection_id: Connection ID

    Returns:
        List of all entity types
    """
    path, params = FootPrintMetadataEndpoints.entity_types(connection_id)  # No filter!
    response = client.get(path, params=params)
    odata_response = ODataListResponse[EntityTypeDto](**response)
    return odata_response.value


def _fetch_all_properties(client: ApiClient, connection_id: int) -> list[PropertyDto]:
    """Fetch ALL properties for a connection in a single HTTP call.

    This is more efficient than fetching properties per-entity when you need
    property data for multiple entities. Use _group_by_key() to organize results.

    Args:
        client: Authenticated API client
        connection_id: Connection ID

    Returns:
        List of all properties across all entity types
    """
    path, params = FootPrintMetadataEndpoints.properties(connection_id)  # No filter!
    response = client.get(path, params=params)
    odata_response = ODataListResponse[PropertyDto](**response)
    return odata_response.value


def _fetch_all_navigation_properties(
    client: ApiClient, connection_id: int
) -> list[NavigationPropertyDto]:
    """Fetch ALL navigation properties for a connection in a single HTTP call.

    This is more efficient than fetching nav properties per-entity when you need
    nav property data for multiple entities. Use _group_by_key() to organize results.

    Args:
        client: Authenticated API client
        connection_id: Connection ID

    Returns:
        List of all navigation properties across all entity types
    """
    path, params = FootPrintMetadataEndpoints.navigation_properties(connection_id)  # No filter!
    response = client.get(path, params=params)
    odata_response = ODataListResponse[NavigationPropertyDto](**response)
    return odata_response.value


def _group_by_key(items: list[Any], key_attr: str) -> dict[str, list[Any]]:
    """Group a list of items by a key attribute.

    Args:
        items: List of objects to group
        key_attr: Attribute name to group by (e.g., 'entity_type_id')

    Returns:
        Dictionary mapping key values to lists of items
    """
    result: dict[str, list[Any]] = {}
    for item in items:
        key_value = getattr(item, key_attr)
        if key_value not in result:
            result[key_value] = []
        result[key_value].append(item)
    return result


def _parse_json_field(json_string: str | None) -> Any:
    """Parse a JSON string field, returning None if invalid or empty.

    Args:
        json_string: JSON string to parse

    Returns:
        Parsed JSON object or None
    """
    if not json_string:
        return None
    try:
        return json.loads(json_string)
    except (json.JSONDecodeError, TypeError):
        return None


def _parse_referential_constraints(
    constraints: list[ReferentialConstraintDto] | None,
) -> dict[str, str] | None:
    """Parse referential constraints list into a property→referencedProperty mapping.

    Args:
        constraints: List of ReferentialConstraintDto objects from the API.

    Returns:
        Dictionary mapping FK property name to referenced property name, or None
        if no valid constraints are present.
    """
    if not constraints:
        return None
    result = {
        c.property: c.referenced_property
        for c in constraints
        if c.property and c.referenced_property
    }
    return result if result else None


def _format_annotations(annotations: list[AnnotationDto] | None) -> list[dict] | None:
    """Format annotation list for output, returning None if empty."""
    if not annotations:
        return None
    return [
        {k: v for k, v in {"term": a.term, "value": a.value, "type": a.type}.items() if v is not None}
        for a in annotations
    ]


def _get_filter_example_value(edm_type: str) -> str:
    """Generate appropriate filter value example based on EDM type.

    Args:
        edm_type: OData EDM type (e.g., 'Edm.Int32', 'Edm.String')

    Returns:
        Example value in correct OData literal format
    """
    # Numeric types
    if edm_type in ("Edm.Int16", "Edm.Int32", "Edm.Int64", "Edm.Byte", "Edm.SByte"):
        return "123"
    if edm_type in ("Edm.Single", "Edm.Double", "Edm.Decimal"):
        return "99.99"

    # Boolean
    if edm_type == "Edm.Boolean":
        return "true"

    # Date/Time types
    if edm_type == "Edm.DateTimeOffset":
        return "2024-01-01T00:00:00Z"
    if edm_type == "Edm.Date":
        return "2024-01-01"
    if edm_type == "Edm.TimeOfDay":
        return "12:30:00"
    if edm_type == "Edm.Duration":
        return "duration'P1D'"

    # GUID
    if edm_type == "Edm.Guid":
        return "12345678-1234-1234-1234-123456789012"

    # Binary
    if edm_type == "Edm.Binary":
        return "binary'T0RhdGE'"

    # String and default
    return "'value'"


def _resolve_entity(
    client: ApiClient,
    connection_id: int,
    entity_name: str,
) -> tuple[EntitySetDto | None, str]:
    """Resolve entity name to entity set and entity type_id using server-side filtering.

    Tries exact match on entity set name first, then falls back to entity type name.
    Uses OData $filter to avoid fetching all entities.

    Args:
        client: Authenticated API client
        connection_id: Connection ID
        entity_name: Entity name (set or type)

    Returns:
        Tuple of (entity_set, type_id) — entity_set may be None if resolved by type name only

    Raises:
        ValidationError: If entity not found
    """
    # Try exact match on entity set name (server-side filter)
    safe_name = _escape_odata_string(entity_name)
    path, params = FootPrintMetadataEndpoints.entity_sets(
        connection_id,
        filter=f"name eq '{safe_name}'"
    )
    response = client.get(path, params=params)
    entity_sets = ODataListResponse[EntitySetDto](**response).value

    if entity_sets:
        entity_set = entity_sets[0]
        return entity_set, entity_set.type_id

    # Try matching on entity type name or full type ID (targeted server-side filter)
    path, params = FootPrintMetadataEndpoints.entity_types(
        connection_id,
        filter=f"name eq '{safe_name}' or typeId eq '{safe_name}'"
    )
    response = client.get(path, params=params)
    matched_types = ODataListResponse[EntityTypeDto](**response).value

    if matched_types:
        entity_type = matched_types[0]
        # Find the entity set for this type
        path, params = FootPrintMetadataEndpoints.entity_sets(
            connection_id,
            filter=f"typeId eq '{_escape_odata_string(entity_type.type_id)}'"
        )
        response = client.get(path, params=params)
        entity_sets = ODataListResponse[EntitySetDto](**response).value
        entity_set = entity_sets[0] if entity_sets else None
        return entity_set, entity_type.type_id

    # Not found - fetch a few examples for error message
    path, params = FootPrintMetadataEndpoints.entity_sets(connection_id, top=5)
    response = client.get(path, params=params)
    sample_sets = ODataListResponse[EntitySetDto](**response).value
    available = [es.name for es in sample_sets]

    suggestions = [
        "Use 'dxs schema search <term>' to find entities by name",
        "Use 'dxs schema list' to see all entities",
    ]
    if available:
        suggestions.append(f"Available entities include: {', '.join(available)}")

    raise ValidationError(
        message=f"Entity '{entity_name}' not found",
        code="DXS-SCHEMA-001",
        suggestions=suggestions,
    )


@click.group(name="schema")
def schema() -> None:
    """Progressive OData entity model discovery.

    Commands for exploring entity structures with token-efficient output,
    optimized for AI agents building OData queries.
    """
    pass


@schema.command(name="list")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of entities to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of entities to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"contains(Name, 'Ship')\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name desc\")",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of entities (no data)",
)
@pass_context
@require_auth
def list_entities(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    count: bool,
) -> None:
    """List all entities in the catalog.

    Shows entity names, types, and key properties only.
    Optimized for minimal data transfer and token usage.

    \b
    Examples:
        dxs schema list --connection-id 32
        dxs schema list --connection Demo --org MyOrg
        dxs schema list --connection-id 32 --top 10
        dxs schema list --connection-id 32 --filter "contains(Name, 'Ship')"
        dxs schema list --connection-id 32 --orderby "Name desc"
        dxs schema list --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.entity_sets(
            resolved_id, top=0, filter=filter_expr, orderby=orderby
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="entity_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Single HTTP call: $expand=EntityType embeds key info so no separate entity type fetch
    path, params = FootPrintMetadataEndpoints.entity_sets(
        resolved_id, top=top, skip=skip, filter=filter_expr, orderby=orderby,
        expand="EntityType",
    )
    response = client.get(path, params=params)
    entity_sets = ODataListResponse[EntitySetDto](**response).value

    # Build summary list using embedded entity type (no N+1 queries)
    entities_summary = []
    for entity_set in entity_sets:
        entity_type = entity_set.entity_type
        if not entity_type:
            continue

        entities_summary.append(
            {
                "name": entity_set.name,
                "entity_type": entity_type.type_id,
                "key_properties": entity_type.key_names,
            }
        )

    # Build response
    response = list_response(
        items=entities_summary,
        semantic_key="entity_sets",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe")
@click.argument("entity_name")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def describe_entity(
    ctx: DxsContext,
    entity_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show complete schema for an entity.

    Displays properties (name, type, nullable), keys, and navigation properties.
    Includes query_hints in metadata with example OData queries.

    \b
    Examples:
        dxs schema describe Warehouses --connection-id 32
        dxs schema describe Items --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Single call: resolve entity set and fetch entity type with all metadata
    path, params = FootPrintMetadataEndpoints.entity_sets(
        resolved_id,
        filter=f"name eq '{_escape_odata_string(entity_name)}'",
        expand="EntityType($expand=Properties,NavigationProperties)",
    )
    response = client.get(path, params=params)
    result_sets = ODataListResponse[EntitySetDto](**response).value

    if result_sets and result_sets[0].entity_type:
        entity_set = result_sets[0]
        entity_type = entity_set.entity_type
        type_id = entity_set.type_id
    else:
        # Fallback: entity was passed as type name or qualified type ID
        entity_set, type_id = _resolve_entity(client, resolved_id, entity_name)
        entity_type = _fetch_entity_type(client, resolved_id, type_id, expand="Properties,NavigationProperties")
        if not entity_type:
            raise ValidationError(
                message=f"Entity type '{type_id}' not found",
                code="DXS-SCHEMA-001",
                suggestions=["The entity metadata may be incomplete"],
            )

    properties = entity_type.properties or []
    nav_properties = entity_type.navigation_properties or []

    # Build property list
    property_list = []
    for prop in properties:
        prop_dict = {
            "name": prop.name,
            "type": prop.type_id,
            "nullable": prop.is_nullable,
            "is_key": prop.is_key,
        }

        # Add optional standard fields if present
        if prop.is_computed:
            prop_dict["is_computed"] = True
        if prop.max_length is not None:
            prop_dict["max_length"] = prop.max_length

        # Add OData v4 facets if present (API developer recently added these)
        if prop.precision is not None:
            prop_dict["precision"] = prop.precision
        if prop.scale is not None:
            prop_dict["scale"] = prop.scale
        if prop.unicode is not None:
            prop_dict["unicode"] = prop.unicode
        if prop.default_value is not None:
            prop_dict["default_value"] = prop.default_value
        if prop.srid is not None:
            prop_dict["srid"] = prop.srid
        if prop.annotations:
            formatted = _format_annotations(prop.annotations)
            if formatted:
                prop_dict["annotations"] = formatted

        property_list.append(prop_dict)

    # Build navigation property list
    nav_property_list = []
    for nav in nav_properties:
        nav_dict = {
            "name": nav.name,
            "type": nav.type_id,
            "multiplicity": "many" if nav.is_collection else "one",
            "partner": nav.partner_name,
        }

        # Parse and add referential constraints if present
        if nav.referential_constraints:
            constraints = _parse_referential_constraints(nav.referential_constraints)
            if constraints:
                # Format as readable "ForeignKeyProperty -> TargetKeyProperty" pairs
                formatted_constraints = [
                    f"{fk_prop} -> {ref_prop}"
                    for fk_prop, ref_prop in constraints.items()
                ]
                nav_dict["referential_constraint"] = formatted_constraints if len(formatted_constraints) > 1 else formatted_constraints[0] if formatted_constraints else None

        nav_property_list.append(nav_dict)

    # Generate query hints
    entity_name_for_query = entity_set.name if entity_set else entity_name
    non_computed_props = [p for p in properties if not p.is_computed]
    property_names = [p.name for p in non_computed_props][:5]

    # Select example
    select_hint = f"{entity_name_for_query}?$select={','.join(property_names)}"

    # Filter example with correct type-based literals
    filter_hint = None
    if non_computed_props:
        first_prop = non_computed_props[0]
        filter_value = _get_filter_example_value(first_prop.type_id)
        filter_hint = f"{entity_name_for_query}?$filter={first_prop.name} eq {filter_value}"

    # Expand examples - simple and nested
    expand_hints = []
    if nav_properties:
        # Simple expand
        expand_hints.append(f"$expand={nav_properties[0].name}")

        # Nested $select example for single navigation property
        if nav_properties:
            # Extract target type (works for both single and collection navs)
            first_nav_type = nav_properties[0].type_id
            if first_nav_type.startswith("Collection(") and first_nav_type.endswith(")"):
                first_nav_type = first_nav_type[11:-1]

            # Add nested select example
            expand_hints.append(f"$expand={nav_properties[0].name}($select=Id)")

        # Multiple expands (if at least 2 nav properties)
        if len(nav_properties) >= 2:
            expand_hints.append(f"$expand={nav_properties[0].name},{nav_properties[1].name}")

        # Filtered expand and nested select examples (for collection nav properties)
        collection_navs = [n for n in nav_properties if n.is_collection]
        if collection_navs:
            # Generic filter example (use common property names that likely exist)
            expand_hints.append(
                f"$expand={collection_navs[0].name}($filter=Id eq 123)"
            )
            # Nested $select example - show pattern without fetching actual properties
            expand_hints.append(
                f"$expand={collection_navs[0].name}($select=Id,Name)"
            )

    # Count example
    count_hint = f"{entity_name_for_query}?$count=true&$top=10"

    # Top/Skip pagination example
    pagination_hint = f"{entity_name_for_query}?$top=10&$skip=20"

    # OrderBy example
    orderby_hint = None
    if property_names:
        orderby_hint = f"{entity_name_for_query}?$orderby={property_names[0]} desc"

    query_hints = {
        "select_example": select_hint,
        "filter_example": filter_hint,
        "expand_examples": expand_hints if expand_hints else None,
        "orderby_example": orderby_hint,
        "count_example": count_hint,
        "pagination_example": pagination_hint,
    }

    # Build entity details
    entity_details = {
        "entity_set_name": entity_set.name if entity_set else None,
        "entity_type": type_id,
        "namespace": entity_type.namespace,
        "keys": entity_type.key_names,
        "properties": property_list,
        "navigation_properties": nav_property_list,
    }

    # Add base type if present (inheritance hierarchy)
    if entity_type.base_type_id:
        entity_details["base_type"] = entity_type.base_type_id

    # Add has_stream if true (media entity — supports $value for binary content)
    if entity_type.has_stream:
        entity_details["has_stream"] = True

    # Build response
    response = single(
        item=entity_details,
        semantic_key="entity",
        connection_id=resolved_id,
        query_hints=query_hints,
    )

    ctx.output(response)


@schema.command(name="relationships")
@click.argument("entity_name")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def list_relationships(
    ctx: DxsContext,
    entity_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show detailed relationship information for an entity.

    Displays navigation properties with target entity details and expand syntax.
    Optimized for building $expand queries.

    \b
    Examples:
        dxs schema relationships Warehouses --connection-id 32
        dxs schema relationships Items --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Resolve entity using server-side filtering (returns entity_set + type_id)
    entity_set, type_id = _resolve_entity(client, resolved_id, entity_name)

    # Bulk fetch all metadata for target lookups — run in parallel (independent calls)
    # Note: We fetch all entity sets/types to avoid N+1 queries when looking up
    # target entities for navigation properties (could be 50+ targets)
    with ThreadPoolExecutor(max_workers=2) as executor:
        future_sets = executor.submit(_fetch_entity_sets, client, resolved_id)
        future_types = executor.submit(_fetch_all_entity_types, client, resolved_id)
        entity_sets = future_sets.result()
        all_entity_types = future_types.result()

    # Build lookups for efficient in-memory joins
    entity_set_by_type = {es.type_id: es for es in entity_sets}
    entity_type_by_id = {et.type_id: et for et in all_entity_types}

    # Fetch navigation properties for this specific entity
    nav_properties = _fetch_navigation_properties(client, resolved_id, type_id)

    # Build relationship details using in-memory lookups
    relationships = []
    for nav in nav_properties:
        # Extract target type ID (remove Collection() wrapper if present)
        target_type_id = nav.type_id
        if target_type_id.startswith("Collection(") and target_type_id.endswith(")"):
            target_type_id = target_type_id[11:-1]

        # Lookup target entity set and type (no HTTP calls)
        target_entity_set_obj = entity_set_by_type.get(target_type_id)
        target_type = entity_type_by_id.get(target_type_id)

        # Get target keys if type found
        target_keys = target_type.key_names if target_type else None

        rel_dict = {
            "name": nav.name,
            "target_entity_type": target_type_id,
            "target_entity_set": target_entity_set_obj.name if target_entity_set_obj else None,
            "multiplicity": "many" if nav.is_collection else "one",
            "partner": nav.partner_name,
            "expand_path": f"{entity_set.name if entity_set else entity_name}?$expand={nav.name}",
            "target_key_properties": target_keys,
        }

        # Parse and add referential constraints if present
        if nav.referential_constraints:
            constraints = _parse_referential_constraints(nav.referential_constraints)
            if constraints:
                # Format as readable "ForeignKeyProperty -> TargetKeyProperty" pairs
                formatted_constraints = [
                    f"{fk_prop} -> {ref_prop}"
                    for fk_prop, ref_prop in constraints.items()
                ]
                rel_dict["referential_constraint"] = formatted_constraints if len(formatted_constraints) > 1 else formatted_constraints[0] if formatted_constraints else None

        relationships.append(rel_dict)

    # Generate simple nested expand example (without fetching properties)
    nested_expand_example = None
    if relationships:
        expand_parts = [rel["name"] for rel in relationships[:2]]
        if expand_parts:
            nested_expand_example = (
                f"{entity_set.name if entity_set else entity_name}?"
                f"$expand={','.join(expand_parts)}"
            )

    # Build response
    response = list_response(
        items=relationships,
        semantic_key="relationships",
        connection_id=resolved_id,
        entity=entity_set.name if entity_set else entity_name,
        query_hints={"nested_expand_example": nested_expand_example},
    )

    ctx.output(response)


@schema.command(name="search")
@click.argument("query")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of results to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of results to skip (for pagination)",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name desc\")",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of matching entities (no data)",
)
@pass_context
@require_auth
def search_entities(
    ctx: DxsContext,
    query: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    orderby: str | None,
    count: bool,
) -> None:
    """Search entities by name (case-insensitive substring match).

    Uses the server-side $search parameter for efficient full-text search across
    entity set name and type ID. Returns filtered entity list with same structure
    as 'list' command.

    \b
    Examples:
        dxs schema search "warehouse" --connection-id 32
        dxs schema search "item" --connection Demo --org MyOrg
        dxs schema search "invoice" --connection-id 32 --top 10
        dxs schema search "invoice" --connection-id 32 --count
    """
    # Validate query parameter
    if not query or not query.strip():
        raise click.UsageError(
            "Search query cannot be empty. Provide a search term (e.g., 'invoice', 'warehouse')"
        )

    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    search_term = query.strip()

    # If count-only requested, use $count=true with $search
    if count:
        path, params = FootPrintMetadataEndpoints.entity_sets(
            resolved_id, top=0, search=search_term
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value, "query": query},
            semantic_key="search_result_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Single HTTP call: $search + $expand=EntityType
    # $search matches Name and TypeId (server-side substring match)
    # $expand=EntityType embeds key info so no separate entity type fetch needed
    path, params = FootPrintMetadataEndpoints.entity_sets(
        resolved_id,
        top=top,
        skip=skip,
        orderby=orderby,
        search=search_term,
        expand="EntityType",
    )
    response = client.get(path, params=params)
    filtered_sets = ODataListResponse[EntitySetDto](**response).value

    # Build summary list using embedded entity type
    entities_summary = []
    for entity_set in filtered_sets:
        entity_type = entity_set.entity_type
        if not entity_type:
            continue

        entities_summary.append(
            {
                "name": entity_set.name,
                "entity_type": entity_type.type_id,
                "key_properties": entity_type.key_names,
            }
        )

    # Build response with search metadata
    response = list_response(
        items=entities_summary,
        semantic_key="entity_sets",
        connection_id=resolved_id,
        query=query,
        count=len(entities_summary),
    )

    ctx.output(response)


@schema.command(name="enums")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of enum types to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of enum types to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"Name eq 'StatusType'\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name desc\")",
)
@click.option(
    "--search",
    type=str,
    default=None,
    help="Search term (server-side match on Name, Namespace, TypeId)",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of enum types (no data)",
)
@pass_context
@require_auth
def list_enums(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all enumeration types in the OData model.

    Shows enum names, namespaces, and underlying types.
    Useful for understanding allowed values for enum properties.

    \b
    Examples:
        dxs schema enums --connection-id 32
        dxs schema enums --connection Demo --org MyOrg
        dxs schema enums --connection-id 32 --top 5
        dxs schema enums --connection-id 32 --search "status"
        dxs schema enums --connection-id 32 --filter "Name eq 'StatusType'"
        dxs schema enums --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.enum_types(
            resolved_id, top=0, filter=filter_expr, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="enum_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Fetch enum types (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.enum_types(
        resolved_id, top=top, skip=skip, filter=filter_expr, orderby=orderby, search=search
    )
    response = client.get(path, params=params)
    enum_types = ODataListResponse[EnumTypeDto](**response).value

    _ENUM_MEMBERS_LIST_LIMIT = 5

    # Build summary list
    enums_summary = []
    for enum in enum_types:
        enum_dict = {
            "name": enum.name,
            "type_id": enum.type_id,
            "namespace": enum.namespace,
            "underlying_type": enum.underlying_type,
            "is_flags": enum.is_flags,
        }

        # Add members if present — truncate in list view to avoid flooding output
        if enum.members:
            total = len(enum.members)
            shown = enum.members[:_ENUM_MEMBERS_LIST_LIMIT]
            enum_dict["members"] = [{"name": m.name, "value": m.value} for m in shown]
            if total > _ENUM_MEMBERS_LIST_LIMIT:
                enum_dict["members_truncated"] = True
                enum_dict["members_total"] = total

        enums_summary.append(enum_dict)

    # Build response
    response = list_response(
        items=enums_summary,
        semantic_key="enum_types",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-enum")
@click.argument("type_id")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def describe_enum(
    ctx: DxsContext,
    type_id: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific enumeration type.

    TYPE_ID is the fully-qualified enum TypeId (e.g. Datex.FootPrint.Api.SomeName).
    Use 'dxs schema enums' to list available enums and their TypeIds.

    Displays enum members with their names and values.

    \b
    Examples:
        dxs schema describe-enum Datex.FootPrint.Api.AsnOutstandingQuantitiesBehaviorEnum --connection-id 32
        dxs schema describe-enum Datex.FootPrint.Api.ReserveIdEntityEnum --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    path, params = FootPrintMetadataEndpoints.enum_type_by_key(resolved_id, type_id)
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            raise ValidationError(
                message=f"Enum type '{type_id}' not found",
                code="DXS-SCHEMA-002",
                suggestions=[
                    f"Use 'dxs schema enums -c {resolved_id}' to find the TypeId",
                    "TypeIds are case-sensitive (e.g. Datex.FootPrint.Api.SomeName)",
                ],
            ) from e
        raise
    enum_type = EnumTypeDto(**response)

    # Build enum details
    enum_details = {
        "name": enum_type.name,
        "type_id": enum_type.type_id,
        "namespace": enum_type.namespace,
        "underlying_type": enum_type.underlying_type,
        "is_flags": enum_type.is_flags,
    }

    # Add members if present (now a typed list, not a JSON string)
    if enum_type.members:
        enum_details["members"] = [
            {"name": m.name, "value": m.value}
            for m in enum_type.members
        ]

    # Build response
    response = single(
        item=enum_details,
        semantic_key="enum_type",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="actions")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of actions to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of actions to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"contains(Name, 'Create')\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name asc\")",
)
@click.option(
    "--search",
    type=str,
    default=None,
    help="Search term (server-side match on Name, Namespace, ActionId)",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of actions (no data)",
)
@pass_context
@require_auth
def list_actions(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all OData actions (state-changing operations).

    Shows action names, binding types, and return types.
    Actions are callable via POST requests.

    \b
    Examples:
        dxs schema actions --connection-id 32
        dxs schema actions --connection Demo --org MyOrg
        dxs schema actions --connection-id 32 --top 10
        dxs schema actions --connection-id 32 --search "create"
        dxs schema actions --connection-id 32 --filter "contains(Name, 'Create')"
        dxs schema actions --connection-id 32 --orderby "Name asc"
        dxs schema actions --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.actions(
            resolved_id, top=0, filter=filter_expr, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="action_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Fetch actions (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.actions(
        resolved_id, top=top, skip=skip, filter=filter_expr, orderby=orderby, search=search
    )
    response = client.get(path, params=params)
    actions = ODataListResponse[ActionDto](**response).value

    # Build summary list
    actions_summary = []
    for action in actions:
        action_dict = {
            "name": action.name,
            "namespace": action.namespace,
            "is_bound": action.is_bound,
        }

        # Parse parameters (now a typed list, not a JSON string)
        parameters = None
        binding_type = None
        if action.parameters:
            parameters = []
            for param in action.parameters:
                if param.name == "bindingParameter":
                    binding_type = param.type_id
                else:
                    parameters.append({
                        "name": param.name,
                        "type": param.type_id,
                        "nullable": param.nullable,
                        "is_collection": param.is_collection,
                    })

        # Add binding type if found
        if binding_type:
            action_dict["binding_type"] = binding_type

        # Return type is now a typed object, not a JSON string
        if action.return_type:
            action_dict["return_type"] = action.return_type.type_id
            if action.return_type.is_collection:
                action_dict["return_type_collection"] = True

        # Add parameters if any (excluding binding parameter)
        if parameters:
            action_dict["parameters"] = parameters

        actions_summary.append(action_dict)

    # Build response
    response = list_response(
        items=actions_summary,
        semantic_key="actions",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-action")
@click.argument("action_id")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def describe_action(
    ctx: DxsContext,
    action_id: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific OData action.

    ACTION_ID is the fully-qualified action ID (e.g. Datex.FootPrint.Api.SomeName).
    Use 'dxs schema actions' to list available actions and their IDs.

    Displays action parameters, return type, and binding information.

    \b
    Examples:
        dxs schema describe-action Datex.FootPrint.Api.ActivateBillingContract --connection-id 32
        dxs schema describe-action Datex.FootPrint.Api.ProcessOrder --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    path, params = FootPrintMetadataEndpoints.action_by_key(resolved_id, action_id)
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            raise ValidationError(
                message=f"Action '{action_id}' not found",
                code="DXS-SCHEMA-003",
                suggestions=[
                    f"Use 'dxs schema actions -c {resolved_id}' to find the ActionId",
                    "ActionIds are case-sensitive (e.g. Datex.FootPrint.Api.SomeName)",
                ],
            ) from e
        raise
    action = ActionDto(**response)

    # Build action details
    action_details = {
        "name": action.name,
        "namespace": action.namespace,
        "is_bound": action.is_bound,
    }

    # Parse parameters (now a typed list, not a JSON string)
    parameters = []
    binding_type = None
    if action.parameters:
        for param in action.parameters:
            if param.name == "bindingParameter":
                binding_type = param.type_id
            else:
                parameters.append({
                    "name": param.name,
                    "type": param.type_id,
                    "nullable": param.nullable,
                    "is_collection": param.is_collection,
                })

    if binding_type:
        action_details["binding_type"] = binding_type

    # Return type is now a typed object, not a JSON string
    if action.return_type:
        action_details["return_type"] = action.return_type.type_id
        if action.return_type.is_collection:
            action_details["return_type_collection"] = True

    if parameters:
        action_details["parameters"] = parameters

    # Build response
    response = single(
        item=action_details,
        semantic_key="action",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="functions")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of functions to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of functions to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"contains(Name, 'Get')\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name asc\")",
)
@click.option(
    "--search",
    type=str,
    default=None,
    help="Search term (server-side match on Name, Namespace, FunctionId)",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of functions (no data)",
)
@pass_context
@require_auth
def list_functions(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all OData functions (read-only operations).

    Shows function names, binding types, return types, and composability.
    Functions are callable via GET requests.

    \b
    Examples:
        dxs schema functions --connection-id 32
        dxs schema functions --connection Demo --org MyOrg
        dxs schema functions --connection-id 32 --top 10
        dxs schema functions --connection-id 32 --search "get"
        dxs schema functions --connection-id 32 --filter "contains(Name, 'Get')"
        dxs schema functions --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.functions(
            resolved_id, top=0, filter=filter_expr, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="function_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Fetch functions (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.functions(
        resolved_id, top=top, skip=skip, filter=filter_expr, orderby=orderby, search=search
    )
    response = client.get(path, params=params)
    functions = ODataListResponse[FunctionDto](**response).value

    # Build summary list
    functions_summary = []
    for func in functions:
        func_dict = {
            "name": func.name,
            "namespace": func.namespace,
            "is_bound": func.is_bound,
            "is_composable": func.is_composable,
        }

        # Parse parameters (now a typed list, not a JSON string)
        parameters = None
        binding_type = None
        if func.parameters:
            parameters = []
            for param in func.parameters:
                if param.name == "bindingParameter":
                    binding_type = param.type_id
                else:
                    parameters.append({
                        "name": param.name,
                        "type": param.type_id,
                        "nullable": param.nullable,
                        "is_collection": param.is_collection,
                    })

        # Add binding type if found
        if binding_type:
            func_dict["binding_type"] = binding_type

        # Return type is now a typed object, not a JSON string
        if func.return_type:
            func_dict["return_type"] = func.return_type.type_id
            if func.return_type.is_collection:
                func_dict["return_type_collection"] = True

        # Add parameters if any (excluding binding parameter)
        if parameters:
            func_dict["parameters"] = parameters

        functions_summary.append(func_dict)

    # Build response
    response = list_response(
        items=functions_summary,
        semantic_key="functions",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-function")
@click.argument("function_id")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def describe_function(
    ctx: DxsContext,
    function_id: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific OData function.

    FUNCTION_ID is the fully-qualified function ID (e.g. Datex.FootPrint.Api.SomeName).
    Use 'dxs schema functions' to list available functions and their IDs.

    Displays function parameters, return type, and composability information.

    \b
    Examples:
        dxs schema describe-function Datex.FootPrint.Api.GetInvoiceTotal --connection-id 32
        dxs schema describe-function Datex.FootPrint.Api.CalculateShipping --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    path, params = FootPrintMetadataEndpoints.function_by_key(resolved_id, function_id)
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            raise ValidationError(
                message=f"Function '{function_id}' not found",
                code="DXS-SCHEMA-004",
                suggestions=[
                    f"Use 'dxs schema functions -c {resolved_id}' to find the FunctionId",
                    "FunctionIds are case-sensitive (e.g. Datex.FootPrint.Api.SomeName)",
                ],
            ) from e
        raise
    func = FunctionDto(**response)

    # Build function details
    func_details = {
        "name": func.name,
        "namespace": func.namespace,
        "is_bound": func.is_bound,
        "is_composable": func.is_composable,
    }

    # Parse parameters (now a typed list, not a JSON string)
    parameters = []
    binding_type = None
    if func.parameters:
        for param in func.parameters:
            if param.name == "bindingParameter":
                binding_type = param.type_id
            else:
                parameters.append({
                    "name": param.name,
                    "type": param.type_id,
                    "nullable": param.nullable,
                    "is_collection": param.is_collection,
                })

    if binding_type:
        func_details["binding_type"] = binding_type

    # Return type is now a typed object, not a JSON string
    if func.return_type:
        func_details["return_type"] = func.return_type.type_id
        if func.return_type.is_collection:
            func_details["return_type_collection"] = True

    if parameters:
        func_details["parameters"] = parameters

    # Build response
    response = single(
        item=func_details,
        semantic_key="function",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="complex-types")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of complex types to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of complex types to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"contains(Name, 'Request')\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name asc\")",
)
@click.option(
    "--search",
    type=str,
    default=None,
    help="Search term (server-side match on Name, Namespace, TypeId)",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of complex types (no data)",
)
@pass_context
@require_auth
def list_complex_types(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all complex types in the OData model.

    Complex types are structured types that are not entities (no keys, not directly queryable).
    They are used as property types within entities.

    \b
    Examples:
        dxs schema complex-types --connection-id 32
        dxs schema complex-types --connection Demo --org MyOrg
        dxs schema complex-types --connection-id 32 --top 20
        dxs schema complex-types --connection-id 32 --search "request"
        dxs schema complex-types --connection-id 32 --filter "contains(Name, 'Request')"
        dxs schema complex-types --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.complex_types(
            resolved_id, top=0, filter=filter_expr, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="complex_type_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Fetch complex types (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.complex_types(
        resolved_id, top=top, skip=skip, filter=filter_expr, orderby=orderby, search=search
    )
    response = client.get(path, params=params)
    complex_types = ODataListResponse[ComplexTypeDto](**response).value

    # Build summary list
    complex_types_summary = []
    for complex_type in complex_types:
        complex_dict = {
            "name": complex_type.name,
            "type_id": complex_type.type_id,
            "namespace": complex_type.namespace,
            "is_open_type": complex_type.is_open_type,
        }

        # Add base type if present (inheritance hierarchy)
        if complex_type.base_type_id:
            complex_dict["base_type"] = complex_type.base_type_id

        complex_types_summary.append(complex_dict)

    # Build response
    response = list_response(
        items=complex_types_summary,
        semantic_key="complex_types",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-complex-type")
@click.argument("type_id")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def describe_complex_type(
    ctx: DxsContext,
    type_id: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific complex type.

    TYPE_ID is the fully-qualified complex type TypeId (e.g. Datex.FootPrint.Api.SomeName).
    Use 'dxs schema complex-types' to list available types and their TypeIds.

    Displays complex type properties, navigation properties, and inheritance information.

    \b
    Examples:
        dxs schema describe-complex-type Datex.FootPrint.Api.Address --connection-id 32
        dxs schema describe-complex-type Datex.FootPrint.Api.ContactInfo --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Single call: key-based lookup + expand properties in one request
    path, params = FootPrintMetadataEndpoints.complex_type_by_key(
        resolved_id, type_id, expand="Properties,NavigationProperties"
    )
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            raise ValidationError(
                message=f"Complex type '{type_id}' not found",
                code="DXS-SCHEMA-005",
                suggestions=[
                    f"Use 'dxs schema complex-types -c {resolved_id}' to find the TypeId",
                    "TypeIds are case-sensitive (e.g. Datex.FootPrint.Api.SomeName)",
                ],
            ) from e
        raise

    complex_type = ComplexTypeDto(**response)

    # Build complex type details
    type_details = {
        "name": complex_type.name,
        "type_id": complex_type.type_id,
        "namespace": complex_type.namespace,
        "is_open_type": complex_type.is_open_type,
    }

    if complex_type.base_type_id:
        type_details["base_type"] = complex_type.base_type_id

    # Build property list from expanded Properties navigation property
    if complex_type.properties:
        property_list = []
        for prop in complex_type.properties:
            prop_dict = {
                "name": prop.name,
                "type": prop.type_id,
                "nullable": prop.is_nullable,
            }
            if prop.is_key:
                prop_dict["is_key"] = True
            if prop.max_length is not None:
                prop_dict["max_length"] = prop.max_length
            if prop.annotations:
                formatted = _format_annotations(prop.annotations)
                if formatted:
                    prop_dict["annotations"] = formatted
            property_list.append(prop_dict)
        type_details["properties"] = property_list

    # Build navigation property list from expanded NavigationProperties
    if complex_type.navigation_properties:
        nav_property_list = []
        for nav in complex_type.navigation_properties:
            nav_dict = {
                "name": nav.name,
                "type": nav.type_id,
                "multiplicity": "many" if nav.is_collection else "one",
            }
            if nav.partner_name:
                nav_dict["partner"] = nav.partner_name
            nav_property_list.append(nav_dict)
        type_details["navigation_properties"] = nav_property_list

    # Build response
    response = single(
        item=type_details,
        semantic_key="complex_type",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="singletons")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of singletons to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of singletons to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"Name eq 'Config'\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name asc\")",
)
@click.option(
    "--search",
    type=str,
    default=None,
    help="Search term (server-side match on Name, TypeId)",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of singletons (no data)",
)
@pass_context
@require_auth
def list_singletons(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all singletons in the OData model.

    Singletons are single-instance entities exposed by the API.
    They are typically used for configuration or system-wide settings.

    \b
    Examples:
        dxs schema singletons --connection-id 32
        dxs schema singletons --connection Demo --org MyOrg
        dxs schema singletons --connection-id 32 --search "config"
        dxs schema singletons --connection-id 32 --filter "Name eq 'Config'"
        dxs schema singletons --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.singletons(
            resolved_id, top=0, filter=filter_expr, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="singleton_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Fetch singletons (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.singletons(
        resolved_id, top=top, skip=skip, filter=filter_expr, orderby=orderby, search=search
    )
    response = client.get(path, params=params)
    singletons = ODataListResponse[SingletonDto](**response).value

    # Build summary list
    singletons_summary = []
    for singleton in singletons:
        singletons_summary.append({
            "name": singleton.name,
            "namespace": singleton.namespace,
            "entity_type": singleton.type_id,
        })

    # Build response
    response = list_response(
        items=singletons_summary,
        semantic_key="singletons",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-singleton")
@click.argument("singleton_name")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def describe_singleton(
    ctx: DxsContext,
    singleton_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific singleton.

    Displays singleton entity type and properties.

    \b
    Examples:
        dxs schema describe-singleton SystemConfig --connection-id 32
        dxs schema describe-singleton Settings --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Single HTTP call: $expand=EntityType with nested Properties and NavigationProperties
    path, params = FootPrintMetadataEndpoints.singleton_by_key(
        resolved_id, singleton_name,
        expand="EntityType($expand=Properties,NavigationProperties)",
    )
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            raise ValidationError(
                message=f"Singleton '{singleton_name}' not found",
                code="DXS-SCHEMA-006",
                suggestions=[
                    f"Use 'dxs schema singletons -c {resolved_id}' to see all singletons",
                    "Singleton names are case-sensitive",
                ],
            ) from e
        raise
    singleton = SingletonDto(**response)

    entity_type = singleton.entity_type
    if not entity_type:
        raise ValidationError(
            message=f"Entity type for singleton '{singleton_name}' could not be resolved",
            code="DXS-SCHEMA-007",
        )

    properties = entity_type.properties or []
    nav_properties = entity_type.navigation_properties or []

    # Build property list
    property_list = []
    for prop in properties:
        prop_dict = {
            "name": prop.name,
            "type": prop.type_id,
            "nullable": prop.is_nullable,
            "is_key": prop.is_key,
        }
        if prop.is_computed:
            prop_dict["is_computed"] = True
        if prop.max_length is not None:
            prop_dict["max_length"] = prop.max_length
        if prop.annotations:
            formatted = _format_annotations(prop.annotations)
            if formatted:
                prop_dict["annotations"] = formatted
        property_list.append(prop_dict)

    # Build navigation property list
    nav_property_list = []
    for nav in nav_properties:
        nav_dict = {
            "name": nav.name,
            "type": nav.type_id,
            "multiplicity": "many" if nav.is_collection else "one",
            "partner": nav.partner_name,
        }
        if nav.referential_constraints:
            constraints = _parse_referential_constraints(nav.referential_constraints)
            if constraints:
                formatted_constraints = [
                    f"{fk_prop} -> {ref_prop}"
                    for fk_prop, ref_prop in constraints.items()
                ]
                nav_dict["referential_constraint"] = formatted_constraints if len(formatted_constraints) > 1 else formatted_constraints[0] if formatted_constraints else None
        nav_property_list.append(nav_dict)

    # Build singleton details
    singleton_details = {
        "name": singleton.name,
        "namespace": singleton.namespace,
        "entity_type": entity_type.type_id,
        "keys": entity_type.key_names,
        "properties": property_list,
        "navigation_properties": nav_property_list,
    }

    if entity_type.base_type_id:
        singleton_details["base_type"] = entity_type.base_type_id

    # Build response
    response = single(
        item=singleton_details,
        semantic_key="singleton",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="action-imports")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of action imports to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of action imports to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"contains(Name, 'Execute')\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name asc\")",
)
@click.option(
    "--search",
    type=str,
    default=None,
    help="Search term (server-side match on Name, ActionId)",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of action imports (no data)",
)
@pass_context
@require_auth
def list_action_imports(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all OData action imports (named action entry points in EntityContainer).

    Action imports are unbound action references declared in the EntityContainer,
    providing named HTTP entry points for OData actions.

    \b
    Examples:
        dxs schema action-imports --connection-id 32
        dxs schema action-imports --connection Demo --org MyOrg
        dxs schema action-imports --connection-id 32 --top 10
        dxs schema action-imports --connection-id 32 --search "execute"
        dxs schema action-imports --connection-id 32 --filter "contains(Name, 'Execute')"
        dxs schema action-imports --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.action_imports(
            resolved_id, top=0, filter=filter_expr, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="action_import_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Fetch action imports (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.action_imports(
        resolved_id, top=top, skip=skip, filter=filter_expr, orderby=orderby, search=search
    )
    response = client.get(path, params=params)
    action_imports = ODataListResponse[ActionImportDto](**response).value

    # Build summary list
    imports_summary = [
        {"name": ai.name, "action_id": ai.action_id}
        for ai in action_imports
    ]

    response = list_response(
        items=imports_summary,
        semantic_key="action_imports",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="function-imports")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of function imports to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of function imports to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"Name eq 'GetTotal'\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name asc\")",
)
@click.option(
    "--search",
    type=str,
    default=None,
    help="Search term (server-side match on Name, FunctionId)",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of function imports (no data)",
)
@pass_context
@require_auth
def list_function_imports(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List all OData function imports (named function entry points in EntityContainer).

    Function imports are unbound function references declared in the EntityContainer,
    providing named HTTP entry points for OData functions.

    \b
    Examples:
        dxs schema function-imports --connection-id 32
        dxs schema function-imports --connection Demo --org MyOrg
        dxs schema function-imports --connection-id 32 --search "total"
        dxs schema function-imports --connection-id 32 --filter "Name eq 'GetTotal'"
        dxs schema function-imports --connection-id 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.function_imports(
            resolved_id, top=0, filter=filter_expr, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="function_import_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Fetch function imports (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.function_imports(
        resolved_id, top=top, skip=skip, filter=filter_expr, orderby=orderby, search=search
    )
    response = client.get(path, params=params)
    function_imports = ODataListResponse[FunctionImportDto](**response).value

    # Build summary list
    imports_summary = [
        {"name": fi.name, "function_id": fi.function_id}
        for fi in function_imports
    ]

    response = list_response(
        items=imports_summary,
        semantic_key="function_imports",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="describe-action-import")
@click.argument("import_name")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def describe_action_import(
    ctx: DxsContext,
    import_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific OData action import.

    Fetches the action import with its full action definition ($expand=Action)
    in a single call, including parameters and return type.

    \b
    Examples:
        dxs schema describe-action-import ExecuteShipment --connection-id 32
        dxs schema describe-action-import CreateOrder --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Fetch action import with expanded Action in one call (key endpoint + $expand)
    path, params = FootPrintMetadataEndpoints.action_import_by_key(
        resolved_id, import_name, expand="Action"
    )
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            raise ValidationError(
                message=f"Action import '{import_name}' not found",
                code="DXS-SCHEMA-008",
                suggestions=[
                    f"Use 'dxs schema action-imports -c {resolved_id}' to see all action imports",
                    "Action import names are case-sensitive",
                ],
            ) from e
        raise
    action_import = ActionImportDto(**response)

    import_details: dict = {
        "name": action_import.name,
        "action_id": action_import.action_id,
    }

    # Include expanded action definition
    if action_import.action:
        act = action_import.action
        action_details: dict = {
            "name": act.name,
            "namespace": act.namespace,
            "is_bound": act.is_bound,
        }
        parameters = []
        if act.parameters:
            for param in act.parameters:
                if param.name != "bindingParameter":
                    parameters.append({
                        "name": param.name,
                        "type": param.type_id,
                        "nullable": param.nullable,
                        "is_collection": param.is_collection,
                    })
        if act.return_type:
            action_details["return_type"] = act.return_type.type_id
            if act.return_type.is_collection:
                action_details["return_type_collection"] = True
        if parameters:
            action_details["parameters"] = parameters
        import_details["action"] = action_details

    response_out = single(
        item=import_details,
        semantic_key="action_import",
        connection_id=resolved_id,
    )

    ctx.output(response_out)


@schema.command(name="describe-function-import")
@click.argument("import_name")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def describe_function_import(
    ctx: DxsContext,
    import_name: str,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
) -> None:
    """Show details for a specific OData function import.

    Fetches the function import with its full function definition ($expand=Function)
    in a single call, including parameters and return type.

    \b
    Examples:
        dxs schema describe-function-import GetShipmentCost --connection-id 32
        dxs schema describe-function-import CalculateTotal --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Fetch function import with expanded Function in one call (key endpoint + $expand)
    path, params = FootPrintMetadataEndpoints.function_import_by_key(
        resolved_id, import_name, expand="Function"
    )
    try:
        response = client.get(path, params=params)
    except ApiError as e:
        if e.code == "DXS-404-001":
            raise ValidationError(
                message=f"Function import '{import_name}' not found",
                code="DXS-SCHEMA-009",
                suggestions=[
                    f"Use 'dxs schema function-imports -c {resolved_id}' to see all function imports",
                    "Function import names are case-sensitive",
                ],
            ) from e
        raise
    function_import = FunctionImportDto(**response)

    import_details: dict = {
        "name": function_import.name,
        "function_id": function_import.function_id,
    }

    # Include expanded function definition
    if function_import.function:
        func = function_import.function
        func_details: dict = {
            "name": func.name,
            "namespace": func.namespace,
            "is_bound": func.is_bound,
            "is_composable": func.is_composable,
        }
        parameters = []
        if func.parameters:
            for param in func.parameters:
                if param.name != "bindingParameter":
                    parameters.append({
                        "name": param.name,
                        "type": param.type_id,
                        "nullable": param.nullable,
                        "is_collection": param.is_collection,
                    })
        if func.return_type:
            func_details["return_type"] = func.return_type.type_id
            if func.return_type.is_collection:
                func_details["return_type_collection"] = True
        if parameters:
            func_details["parameters"] = parameters
        import_details["function"] = func_details

    response_out = single(
        item=import_details,
        semantic_key="function_import",
        connection_id=resolved_id,
    )

    ctx.output(response_out)


@schema.command(name="properties")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--entity-type",
    "-e",
    type=str,
    default=None,
    help="Filter by entity type ID (e.g. 'Demo.Warehouse')",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of properties to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of properties to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"TypeId eq 'Edm.String'\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name asc\")",
)
@click.option(
    "--search",
    type=str,
    default=None,
    help="Search term (server-side match on Name, EntityTypeId, TypeId)",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of matching properties (no data)",
)
@pass_context
@require_auth
def list_properties(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    entity_type: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List properties across all entity types.

    Queries the Properties endpoint directly — useful for finding which entities
    have a specific property name or type without describing each entity individually.

    \b
    Examples:
        dxs schema properties -c 32 --entity-type Demo.Warehouse
        dxs schema properties -c 32 --search "status"
        dxs schema properties -c 32 --filter "TypeId eq 'Edm.String' and IsKey eq true"
        dxs schema properties -c 32 --entity-type Demo.Invoice --top 20
        dxs schema properties -c 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    if entity_type and "." not in entity_type:
        raise click.UsageError(
            f"--entity-type requires a fully-qualified TypeId (e.g. Datex.FootPrint.Api.{entity_type}). "
            f"Run 'dxs schema properties -c {resolved_id}' or "
            f"'dxs schema list -c {resolved_id}' and use the entity_type_id / type_id value."
        )

    client = ApiClient()

    # Build combined filter (entity_type filter + user filter)
    filter_parts = []
    if entity_type:
        safe_type = entity_type.replace("'", "''")
        filter_parts.append(f"EntityTypeId eq '{safe_type}'")
    if filter_expr:
        filter_parts.append(filter_expr)
    combined_filter = " and ".join(filter_parts) if filter_parts else None

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.properties(
            resolved_id, top=0, filter=combined_filter, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="property_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Fetch properties (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.properties(
        resolved_id, top=top, skip=skip, filter=combined_filter, orderby=orderby, search=search
    )
    response = client.get(path, params=params)
    props = ODataListResponse[PropertyDto](**response).value

    # Build summary list
    props_summary = []
    for prop in props:
        prop_dict = {
            "entity_type_id": prop.entity_type_id,
            "name": prop.name,
            "type": prop.type_id,
            "nullable": prop.is_nullable,
            "is_key": prop.is_key,
        }
        if prop.is_computed:
            prop_dict["is_computed"] = True
        if prop.is_udf:
            prop_dict["is_udf"] = True
        if prop.max_length is not None:
            prop_dict["max_length"] = prop.max_length
        props_summary.append(prop_dict)

    # Build response
    response = list_response(
        items=props_summary,
        semantic_key="properties",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="navigation-properties")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@click.option(
    "--entity-type",
    "-e",
    type=str,
    default=None,
    help="Filter by entity type ID (e.g. 'Demo.Warehouse')",
)
@click.option(
    "--top",
    "-n",
    type=int,
    default=None,
    help="Maximum number of navigation properties to return",
)
@click.option(
    "--skip",
    type=int,
    default=None,
    help="Number of navigation properties to skip (for pagination)",
)
@click.option(
    "--filter",
    "filter_expr",
    type=str,
    default=None,
    help="OData $filter expression (e.g. \"IsCollection eq true\")",
)
@click.option(
    "--orderby",
    type=str,
    default=None,
    help="OData $orderby expression (e.g. \"Name asc\")",
)
@click.option(
    "--search",
    type=str,
    default=None,
    help="Search term (server-side match on Name, EntityTypeId, TypeId)",
)
@click.option(
    "--count",
    is_flag=True,
    default=False,
    help="Return only the count of matching navigation properties (no data)",
)
@pass_context
@require_auth
def list_navigation_properties(
    ctx: DxsContext,
    connection_id: int | None,
    connection: str | None,
    org: str | None,
    entity_type: str | None,
    top: int | None,
    skip: int | None,
    filter_expr: str | None,
    orderby: str | None,
    search: str | None,
    count: bool,
) -> None:
    """List navigation properties across all entity types.

    Queries the NavigationProperties endpoint directly — useful for discovering
    $expand paths and relationships without describing each entity individually.

    \b
    Examples:
        dxs schema navigation-properties -c 32 --entity-type Demo.Warehouse
        dxs schema navigation-properties -c 32 --search "order"
        dxs schema navigation-properties -c 32 --filter "IsCollection eq true"
        dxs schema navigation-properties -c 32 --count
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    if entity_type and "." not in entity_type:
        raise click.UsageError(
            f"--entity-type requires a fully-qualified TypeId (e.g. Datex.FootPrint.Api.{entity_type}). "
            f"Run 'dxs schema navigation-properties -c {resolved_id}' or "
            f"'dxs schema list -c {resolved_id}' and use the entity_type_id / type_id value."
        )

    client = ApiClient()

    # Build combined filter (entity_type filter + user filter)
    filter_parts = []
    if entity_type:
        safe_type = entity_type.replace("'", "''")
        filter_parts.append(f"EntityTypeId eq '{safe_type}'")
    if filter_expr:
        filter_parts.append(filter_expr)
    combined_filter = " and ".join(filter_parts) if filter_parts else None

    # If count-only requested, use $count=true query parameter
    if count:
        path, params = FootPrintMetadataEndpoints.navigation_properties(
            resolved_id, top=0, filter=combined_filter, orderby=orderby, search=search
        )
        params["$count"] = "true"
        result = client.get(path, params=params)
        count_value = result.get("@odata.count", 0)

        response = single(
            item={"count": count_value},
            semantic_key="nav_property_count",
            connection_id=resolved_id,
        )
        ctx.output(response)
        return

    # Fetch navigation properties (1 HTTP call)
    path, params = FootPrintMetadataEndpoints.navigation_properties(
        resolved_id, top=top, skip=skip, filter=combined_filter, orderby=orderby, search=search
    )
    response = client.get(path, params=params)
    nav_props = ODataListResponse[NavigationPropertyDto](**response).value

    # Build summary list
    nav_props_summary = []
    for nav in nav_props:
        nav_dict = {
            "entity_type_id": nav.entity_type_id,
            "name": nav.name,
            "target_type": nav.type_id,
            "multiplicity": "many" if nav.is_collection else "one",
        }
        if nav.partner_name:
            nav_dict["partner"] = nav.partner_name
        if nav.referential_constraints:
            constraints = _parse_referential_constraints(nav.referential_constraints)
            if constraints:
                nav_dict["referential_constraint"] = [
                    f"{fk} -> {ref}" for fk, ref in constraints.items()
                ]
        nav_props_summary.append(nav_dict)

    # Build response
    response = list_response(
        items=nav_props_summary,
        semantic_key="navigation_properties",
        connection_id=resolved_id,
    )

    ctx.output(response)


@schema.command(name="metadata")
@click.option(
    "--connection-id",
    "-c",
    type=int,
    default=None,
    help="API connection ID",
)
@click.option(
    "--connection",
    type=str,
    default=None,
    help="API connection name (requires --org)",
)
@click.option(
    "--org",
    "-o",
    type=str,
    default=None,
    help="Organization name (required when using --connection by name)",
)
@pass_context
@require_auth
def get_metadata(
    ctx: DxsContext, connection_id: int | None, connection: str | None, org: str | None
) -> None:
    """Get raw OData metadata document (EDMX XML) for the schema discovery API.

    Returns the EDMX XML that describes the schema API itself — i.e. the
    entity types, properties and navigation properties of the metadata
    endpoints (EntityTypeDto, PropertyDto, NavigationPropertyDto, etc.).

    This is NOT the Footprint business-domain EDMX (Warehouses, Orders, …).
    Use 'dxs odata metadata' or the individual schema subcommands to explore
    the business model.

    \b
    Examples:
        dxs schema metadata --connection-id 32
        dxs schema metadata --connection Demo --org MyOrg
    """
    resolved_id = _resolve_connection(ctx, connection_id, connection, org)

    client = ApiClient()

    # Fetch raw metadata XML (1 HTTP call)
    path = FootPrintMetadataEndpoints.metadata(resolved_id)
    xml_content = client.get_text(path)

    # Build response
    response = single(
        item={"xml": xml_content},
        semantic_key="edmx",  # Changed from "metadata" to avoid collision with response metadata
        connection_id=resolved_id,
    )

    ctx.output(response)
