"""Datasource configuration commands.

Commands for generating, enhancing, and uploading Datex datasource
configurations from OData queries in a single step.
"""

import click

from dxs.cli import DxsContext, pass_context
from dxs.core.api.client import ApiClient
from dxs.core.api.endpoints import ConfigurationEndpoints
from dxs.core.auth import require_auth
from dxs.core.datasource import DatasourceGenerator
from dxs.core.datasource.models import (
    DSDynamicOrderByConfig,
    DSLinkedDatasourceConfig,
    DSLinkedDatasourceConfigRef,
    DSValueConfig,
    TypeConfig,
)
from dxs.core.datasource.validator import DatasourceValidator
from dxs.utils.errors import ApiError, ValidationError
from dxs.utils.responses import single


def _parse_dynamic_filter(value: str) -> TypeConfig:
    """Parse 'property:type' → TypeConfig. Raises UsageError if malformed."""
    parts = value.split(":", 1)
    if len(parts) != 2:
        raise click.UsageError(f"--dynamic-filter must be 'property:type', got: {value!r}")
    prop, typ = parts
    valid_types = {"string", "number", "date", "boolean"}
    if typ not in valid_types:
        raise click.UsageError(f"--dynamic-filter type must be one of {valid_types}, got: {typ!r}")
    return TypeConfig(id=prop, type=typ)  # type: ignore[arg-type]


def _parse_dynamic_orderby(value: str) -> DSDynamicOrderByConfig:
    """Parse 'Property' or 'Owner.Name' → DSDynamicOrderByConfig."""
    return DSDynamicOrderByConfig(property=value.split("."))


def _parse_linked(value: str) -> DSLinkedDatasourceConfig:
    """Parse linked datasource spec → DSLinkedDatasourceConfig.

    Format:
      oneToOne/oneToMany:    'name:type:target'            (mergeByValue is always null for these types)
      oneToOneWithMerge:     'name:type:target:mergeBy'    (mergeByValue required)

    A 4th component is accepted for all types for convenience but is silently
    discarded for oneToOne/oneToMany — the C# validator and Handlebars template
    do not use mergeByValue for those types (the UI always sets it to null).
    """
    parts = value.split(":", 3)
    if len(parts) < 3:
        raise click.UsageError(
            f"--linked must be 'name:type:target[:mergeBy]', got: {value!r}"
        )
    name, typ = parts[0], parts[1]
    valid_types = {"oneToOne", "oneToMany", "oneToOneWithMerge"}
    if typ not in valid_types:
        raise click.UsageError(f"--linked type must be one of {valid_types}, got: {typ!r}")
    target = parts[2]
    if typ == "oneToOneWithMerge":
        if len(parts) < 4 or not parts[3]:
            raise click.UsageError(
                "--linked oneToOneWithMerge requires a mergeBy expression: 'name:type:target:mergeBy'"
            )
        merge_by: str | None = parts[3]
    else:
        # oneToOne / oneToMany: mergeByValue must be null — the template does not use it
        # and the C# validator type-checks any non-null value against the entity type.
        merge_by = None
    return DSLinkedDatasourceConfig(
        name=name,
        type=typ,  # type: ignore[arg-type]
        datasourceConfig=DSLinkedDatasourceConfigRef(configId=target),
        mergeByValue=merge_by,
    )


def _parse_custom_column(value: str) -> DSValueConfig:
    """Parse 'name:type:expression' → DSValueConfig (splits on first 2 colons)."""
    parts = value.split(":", 2)
    if len(parts) != 3:
        raise click.UsageError(
            f"--custom-column must be 'name:type:expression', got: {value!r}"
        )
    name, typ, expression = parts
    valid_types = {"string", "number", "boolean", "date", "object"}
    if typ not in valid_types:
        raise click.UsageError(f"--custom-column type must be one of {valid_types}, got: {typ!r}")
    return DSValueConfig(name=name, type=typ, value=expression)  # type: ignore[arg-type]


def _parse_linked_top(value: str) -> tuple[str, str]:
    """Parse 'name:value' → (linked_name, top_value) for --linked-top."""
    parts = value.split(":", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise click.UsageError(f"--linked-top must be 'name:value', got: {value!r}")
    return parts[0], parts[1]


@click.group()
def datasource() -> None:
    """Datasource configuration generation and management.

    Generate, enhance, and upload Datex datasource configurations
    from OData queries in a single step. Always requires a target branch.

    \b
    IMPORTANT REQUIREMENTS:
    1. All $expand clauses MUST include $select with explicit field list
    2. ALWAYS provide --description to document the datasource purpose
    3. Reference names must be valid JavaScript identifiers

    Use 'dxs schema describe EntityName' to discover available properties.

    \b
    Examples:
        # Generate and upload to branch
        dxs datasource upsert -c 1 \\
          -q 'Orders?$select=Id,StatusId&$expand=Status($select=Name)' \\
          -r ds_orders -t "Orders" -d "Orders with status" \\
          --branch 123

        # With dynamic filters, orderbys, and upload
        dxs datasource upsert -c 1 \\
          -q 'Orders?$select=Id,StatusId&$expand=Status($select=Name)' \\
          -r ds_orders -t "Orders" -d "Orders with status" \\
          --dynamic-filter StatusId:number \\
          --dynamic-orderby OrderDate \\
          --branch 123
    """
    pass


@datasource.command()
@click.option(
    "--connection-id",
    "-c",
    type=int,
    required=True,
    help="FootPrint API connection ID for schema/metadata lookup",
)
@click.option(
    "--query",
    "-q",
    type=str,
    required=True,
    help="OData query string",
)
@click.option(
    "--reference-name",
    "-r",
    type=str,
    required=True,
    help="Unique datasource reference name (valid JS identifier)",
)
@click.option(
    "--title",
    "-t",
    type=str,
    required=True,
    help="Display title",
)
@click.option(
    "--description",
    "-d",
    type=str,
    default=None,
    help="Description of the datasource purpose",
)
@click.option(
    "--api-setting-name",
    type=str,
    default="FootPrintAPI",
    help="API connection setting name (default: FootPrintAPI)",
)
@click.option(
    "--param-keys",
    is_flag=True,
    default=False,
    help="Convert key segment values to input parameters",
)
@click.option(
    "--key-param-name",
    type=str,
    default=None,
    help="Custom parameter name for key",
)
@click.option(
    "--detect-params",
    is_flag=True,
    default=False,
    help="Auto-detect input parameters from filter expressions",
)
@click.option(
    "--dynamic-filter",
    "dynamic_filters",
    multiple=True,
    metavar="PROPERTY:TYPE",
    help=(
        "Add dynamic filter. Format: property:type "
        "(type: string|number|date|boolean). Repeatable."
    ),
)
@click.option(
    "--dynamic-orderby",
    "dynamic_orderbys",
    multiple=True,
    metavar="PROPERTY",
    help="Add dynamic orderby. Use dot notation for nested: Owner.Name. Repeatable.",
)
@click.option(
    "--linked",
    "linked_datasources",
    multiple=True,
    metavar="NAME:TYPE:TARGET:MERGE_BY",
    help=(
        "Add linked datasource. Format: name:type:target:mergeBy "
        "(type: oneToOne|oneToMany|oneToOneWithMerge). Repeatable."
    ),
)
@click.option(
    "--custom-column",
    "custom_columns",
    multiple=True,
    metavar="NAME:TYPE:EXPRESSION",
    help=(
        "Add custom computed column. Format: name:type:expression "
        "(splits on first 2 colons). Repeatable."
    ),
)
@click.option(
    "--output-single",
    "output_single",
    is_flag=True,
    default=False,
    help="Set outputResultAsSingleObject=True (single-entity result pattern).",
)
@click.option(
    "--all-dynamic-filters",
    "all_dynamic_filters",
    is_flag=True,
    default=False,
    help="Set allSelectedIsDynamicFilters=True (treat all result fields as potential filters).",
)
@click.option(
    "--all-dynamic-orderbys",
    "all_dynamic_orderbys",
    is_flag=True,
    default=False,
    help="Set allSelectedIsDynamicOrderBys=True (treat all result fields as potential orderbys).",
)
@click.option(
    "--linked-top",
    "linked_tops",
    multiple=True,
    metavar="NAME:VALUE",
    help=(
        "Set top limit on a named linked datasource. "
        "Format: name:value (sets hasTop=True, top=value). Repeatable."
    ),
)
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Target branch ID for upload (falls back to global -b/--branch context)",
)
@pass_context
@require_auth
def upsert(
    ctx: DxsContext,
    connection_id: int,
    query: str,
    reference_name: str,
    title: str,
    description: str | None,
    api_setting_name: str,
    param_keys: bool,
    key_param_name: str | None,
    detect_params: bool,
    dynamic_filters: tuple[str, ...],
    dynamic_orderbys: tuple[str, ...],
    linked_datasources: tuple[str, ...],
    custom_columns: tuple[str, ...],
    output_single: bool,
    all_dynamic_filters: bool,
    all_dynamic_orderbys: bool,
    linked_tops: tuple[str, ...],
    branch: int | None,
) -> None:
    """Generate, enhance, and upload a datasource configuration to a branch.

    Combines generation, enhancement, and upload into a single command.
    Performs an upsert (create or update) on the target branch.
    Branch must be specified via --branch or the global -b/--branch flag.

    \b
    CRITICAL REQUIREMENTS:
    1. All $expand clauses MUST include $select with explicit field list
    2. ALWAYS provide --description to document the datasource purpose
    3. Reference names must be valid JavaScript identifiers

    \b
    Examples:
        # Simple upload
        dxs datasource upsert -c 1 \\
          -q 'Orders?$select=Id,Name&$top=10' \\
          -r ds_orders -t "Orders" -d "Order list" \\
          --branch 123

        # With dynamic filters and sorting
        dxs datasource upsert -c 1 \\
          -q 'Orders?$select=Id,StatusId&$expand=Status($select=Name)' \\
          -r ds_orders -t "Orders" -d "Orders with status" \\
          --dynamic-filter StatusId:number \\
          --dynamic-filter OrderDate:date \\
          --dynamic-orderby OrderDate \\
          --branch 123

        # With linked datasource (oneToOne/oneToMany: 3 parts, no mergeBy)
        dxs datasource upsert -c 1 \\
          -q 'Orders?$select=Id,OwnerId' \\
          -r ds_orders -t "Orders" -d "Orders with owner" \\
          --linked 'owner:oneToOne:ds_person' \\
          --branch 123

        # With linked datasource (oneToOneWithMerge: 4 parts, mergeBy required)
        dxs datasource upsert -c 1 \\
          -q 'Orders?$select=Id,OwnerId' \\
          -r ds_orders -t "Orders" -d "Orders merged with owner" \\
          --linked 'owner:oneToOneWithMerge:ds_person:$entity.OwnerId' \\
          --branch 123

        # With custom column (use $entity, single quotes)
        dxs datasource upsert -c 1 \\
          -q 'Orders?$select=Id,CreatedDate' \\
          -r ds_orders -t "Orders" -d "Orders with age" \\
          --custom-column 'DaysOld:number:Math.floor((new Date()-new Date($entity.CreatedDate))/86400000)' \\
          --branch 123
    """
    ctx.log(f"Generating datasource configuration for: {query[:80]}...")

    # 1. Generate base config
    api_client = ApiClient()
    generator = DatasourceGenerator(api_client)

    try:
        config = generator.generate(
            connection_id=connection_id,
            query=query,
            reference_name=reference_name,
            title=title,
            api_setting_name=api_setting_name,
            description=description,
            detect_params=detect_params,
            param_keys=param_keys,
            key_param_name=key_param_name,
            output_single=output_single,
        )
    except ValidationError as e:
        ctx.output_error(e)
        raise SystemExit(1) from None

    # 2. Apply enhancements
    if dynamic_filters:
        config.dynamicFilters = [_parse_dynamic_filter(f) for f in dynamic_filters]

    if all_dynamic_filters:
        config.allSelectedIsDynamicFilters = True
    elif dynamic_filters:
        config.allSelectedIsDynamicFilters = False

    if dynamic_orderbys:
        config.dynamicOrderBys = [_parse_dynamic_orderby(o) for o in dynamic_orderbys]

    if all_dynamic_orderbys:
        config.allSelectedIsDynamicOrderBys = True
    elif dynamic_orderbys:
        config.allSelectedIsDynamicOrderBys = False

    if linked_datasources:
        config.linkedDatasources = [_parse_linked(ld) for ld in linked_datasources]

    if linked_tops:
        if not config.linkedDatasources:
            raise click.UsageError("--linked-top requires at least one --linked datasource")
        linked_by_name = {ld.name: ld for ld in config.linkedDatasources}
        for top_spec in linked_tops:
            name, top_value = _parse_linked_top(top_spec)
            if name not in linked_by_name:
                raise click.UsageError(
                    f"--linked-top: no linked datasource named '{name}'. "
                    f"Available: {list(linked_by_name)}"
                )
            linked_by_name[name].hasTop = True
            linked_by_name[name].top = top_value

    if custom_columns:
        config.customColumns = [_parse_custom_column(c) for c in custom_columns]

    # 3. Validate the final configuration before upload
    try:
        DatasourceValidator().validate_and_raise(config.model_dump())
    except ValidationError as e:
        ctx.output_error(e)
        raise SystemExit(1) from None

    # 4. Serialize
    config_dict = config.model_dump(by_alias=True, mode='python', exclude_none=False)

    # 4. Resolve branch and upload
    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    try:
        existing = api_client.get(
            ConfigurationEndpoints.get_by_reference(branch_id, "datasource", reference_name)
        )
        config_id = existing["id"]
        api_client.put(
            ConfigurationEndpoints.update(branch_id, "datasource", config_id),
            data=config_dict,
        )
        action = "updated"
    except ApiError as e:
        if e.code == "DXS-404-001":
            api_client.post(
                ConfigurationEndpoints.create(branch_id, "datasource"),
                data=config_dict,
            )
            action = "created"
        else:
            raise

    ctx.output(single(
        item={
            "referenceName": reference_name,
            "title": title,
            "branch_id": branch_id,
            "action": action,
        },
        semantic_key="datasource",
    ))


