"""Report authoring commands: dxs report [...].

Provides RDL (RDLX-JSON) report authoring for ActiveReportsJS reports
in the Datex Studio platform. Commands support schema discovery,
scaffolding, element placement, validation, and upload/download.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import click

from dxs.cli import DxsContext, handle_errors, pass_context
from dxs.core.auth import require_auth
from dxs.utils.responses import list_response, single


@click.group()
def report() -> None:
    """Report authoring commands (RDL/RDLX-JSON).

    Create, modify, validate, and upload ActiveReportsJS reports
    for the Datex Studio platform. Reports are .rdlx-json files
    containing positioned elements (textboxes, barcodes, images,
    tables, lines, rectangles, shapes) with data binding via
    expressions like =Fields!Name.Value.

    \b
    Workflow:
      1. Discover:  dxs report schema items/barcodes/expressions/document
      2. Create:    dxs report create <file> [--page ...] OR
                    dxs report scaffold <file> --template <name>
      3. Build:     dxs report add <type> <file> --name ... --left ... --top ...
                    dxs report set <file> <element> --value ... --font-size ...
                    dxs report move <file> <element> --left ... --top ...
                    dxs report remove <file> <element>
      4. Inspect:   dxs report inspect <file>
      5. Validate:  dxs report validate <file>
      6. Deploy:    dxs report upload <file> --branch <id> --name "..."
                    dxs report download <file> --branch <id> --report-id <id>

    \b
    Coordinate system:
      Positions (--left, --top) are relative to the content area
      (inside margins). Left=0in, Top=0in is the top-left corner
      of the printable area. All sizes use CSS-like units (in, cm, mm, pt).

    \b
    Quick start:
        dxs report create bol.rdlx-json --page letter --landscape
        dxs report add textbox bol.rdlx-json --name Title --left 0in --top 0in --width 3in --height 0.3in --value "Bill of Lading" --font-size 18pt --font-weight Bold
        dxs report add barcode bol.rdlx-json --name ProBarcode --symbology Code128 --left 5in --top 0in --width 2.5in --height 0.75in --value "=Fields!PRONumber.Value"
        dxs report validate bol.rdlx-json
    """


# ── Schema Commands ──────────────────────────────────────────────────────


@report.group()
def schema() -> None:
    """RDL schema reference for agent discovery.

    Discover available report item types, barcode symbologies,
    expression syntax, and document structure.

    \b
    Examples:
        dxs report schema document
        dxs report schema items
        dxs report schema item textbox
        dxs report schema barcodes
        dxs report schema expressions
    """


@schema.command("items")
@pass_context
@handle_errors
def schema_items(ctx: DxsContext) -> None:
    """List all available report item types."""
    from dxs.report.schema import list_item_types

    items = list_item_types()
    ctx.output(list_response(items, "item_types"))


@schema.command("item")
@click.argument("item_type")
@pass_context
@handle_errors
def schema_item(ctx: DxsContext, item_type: str) -> None:
    """Describe a report item type and its properties.

    \b
    Available types: textbox, barcode, image, table, line, rectangle, shape
    """
    from dxs.report.schema import get_item_type_info
    from dxs.utils.errors import ValidationError

    info = get_item_type_info(item_type)
    if info is None:
        from dxs.report.schema import ITEM_TYPES

        available = ", ".join(ITEM_TYPES.keys())
        raise ValidationError(
            message=f"Unknown item type: '{item_type}'",
            code="DXS-RPT-001",
            suggestions=[f"Available types: {available}"],
        )

    ctx.output(single({"type": item_type, **info}, "item_type"))


@schema.command("barcodes")
@pass_context
@handle_errors
def schema_barcodes(ctx: DxsContext) -> None:
    """List all barcode symbologies with details."""
    from dxs.report.schema import list_barcode_symbologies

    symbologies = list_barcode_symbologies()
    ctx.output(list_response(symbologies, "barcode_symbologies"))


@schema.command("expressions")
@pass_context
@handle_errors
def schema_expressions(ctx: DxsContext) -> None:
    """Expression syntax reference for data binding."""
    from dxs.report.schema import EXPRESSION_REFERENCE

    ctx.output(single(EXPRESSION_REFERENCE, "expression_reference"))


@schema.command("document")
@pass_context
@handle_errors
def schema_document(ctx: DxsContext) -> None:
    """Full RDL-JSON document structure reference.

    Shows the top-level structure of an RDLX-JSON report file:
    page settings, sections, body, data sources, datasets,
    parameters, and a minimal example.
    """
    from dxs.report.schema import get_document_structure

    structure = get_document_structure()
    ctx.output(single(structure, "document_structure"))


# ── File Operations ──────────────────────────────────────────────────────


def _read_report(file_path: str) -> dict[str, Any]:
    """Read and parse an RDLX-JSON file.

    Args:
        file_path: Path to the .rdlx-json file.

    Returns:
        Parsed report definition dict.

    Raises:
        ValidationError: If file doesn't exist or isn't valid JSON.
    """
    from dxs.utils.errors import ValidationError

    path = Path(file_path)
    if not path.exists():
        raise ValidationError(
            message=f"Report file not found: {file_path}",
            code="DXS-RPT-010",
            suggestions=[
                "Check the file path",
                "Use 'dxs report scaffold' or 'dxs report create' to create a new report",
            ],
        )

    try:
        text = path.read_text(encoding="utf-8")
        return json.loads(text)  # type: ignore[no-any-return]
    except json.JSONDecodeError as e:
        raise ValidationError(
            message=f"Invalid JSON in {file_path}: {e}",
            code="DXS-RPT-011",
        ) from e


def _write_report(file_path: str, data: dict[str, Any]) -> None:
    """Write report definition to an RDLX-JSON file.

    Args:
        file_path: Path to write the .rdlx-json file.
        data: Report definition dict.
    """
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=4) + "\n", encoding="utf-8")


def _parse_report(data: dict[str, Any]) -> Any:
    """Parse raw dict into a ReportDefinition model.

    Args:
        data: Raw report definition dict.

    Returns:
        ReportDefinition model instance.
    """
    from dxs.report.models import ReportDefinition

    return ReportDefinition.model_validate(data)


def _serialize_report(report_def: Any) -> dict[str, Any]:
    """Serialize a ReportDefinition model to dict.

    Args:
        report_def: ReportDefinition model instance.

    Returns:
        Serialized dict suitable for JSON output.
    """
    return report_def.model_dump(exclude_none=True)  # type: ignore[no-any-return]


# ── Create / Scaffold Commands ───────────────────────────────────────────


@report.command("create")
@click.argument("file", type=click.Path(dir_okay=False))
@click.option(
    "--page",
    "page_size",
    default="letter",
    help="Page size: letter, legal, a4, 4x6, 4x8, or WxH (e.g., 8.5inx11in)",
)
@click.option("--margins", default="0.5in", help="Page margins (all sides, e.g., 0.5in)")
@click.option("--name", "report_name", default=None, help="Report name (defaults to filename)")
@click.option("--landscape", is_flag=True, default=False, help="Use landscape orientation")
@pass_context
@handle_errors
def create(
    ctx: DxsContext,
    file: str,
    page_size: str,
    margins: str,
    report_name: str | None,
    landscape: bool,
) -> None:
    """Create a blank report with page setup.

    Creates an empty .rdlx-json file with the specified page size and
    margins but no report items. Use 'dxs report add' to add elements
    afterward. For pre-built layouts, use 'dxs report scaffold' instead.

    \b
    Page sizes: letter (8.5x11), legal (8.5x14), a4, 4x6, 4x8,
    or custom WxH (e.g., 8.5inx11in).

    \b
    Examples:
        dxs report create bol.rdlx-json
        dxs report create label.rdlx-json --page 4x6 --margins 0.25in
        dxs report create report.rdlx-json --page letter --landscape
    """
    from dxs.report.engine import create_blank_report

    path = Path(file)
    if path.exists():
        from dxs.utils.errors import ValidationError

        raise ValidationError(
            message=f"File already exists: {file}",
            code="DXS-RPT-012",
            suggestions=["Choose a different filename or delete the existing file"],
        )

    if report_name is None:
        report_name = path.stem

    report_def = create_blank_report(
        name=report_name,
        page_size=page_size,
        margins=margins,
        landscape=landscape,
    )

    _write_report(file, _serialize_report(report_def))
    ctx.output(
        single(
            {"file": file, "page_size": page_size, "margins": margins, "name": report_name},
            "report_created",
        )
    )


@report.command("scaffold")
@click.argument("file", type=click.Path(dir_okay=False))
@click.option(
    "--template",
    "-t",
    "template_name",
    required=True,
    type=click.Choice(["bill-of-lading", "shipping-label"], case_sensitive=False),
    help="Template to use",
)
@click.option("--page", "page_size", default=None, help="Override page size (e.g., 4x6)")
@pass_context
@handle_errors
def scaffold(
    ctx: DxsContext,
    file: str,
    template_name: str,
    page_size: str | None,
) -> None:
    """Create a report from a built-in template.

    \b
    Templates:
        bill-of-lading    Standard BOL layout (8.5x11, landscape)
        shipping-label    4x6 shipping label

    \b
    Examples:
        dxs report scaffold bol.rdlx-json --template bill-of-lading
        dxs report scaffold label.rdlx-json --template shipping-label
    """
    from dxs.report.engine import scaffold_report
    from dxs.utils.errors import ValidationError

    path = Path(file)
    if path.exists():
        raise ValidationError(
            message=f"File already exists: {file}",
            code="DXS-RPT-012",
            suggestions=["Choose a different filename or delete the existing file"],
        )

    report_def = scaffold_report(template_name, page_size_override=page_size)
    _write_report(file, _serialize_report(report_def))

    item_count = len(report_def.all_items())
    ctx.output(
        single(
            {
                "file": file,
                "template": template_name,
                "items_count": item_count,
            },
            "report_scaffolded",
        )
    )


# ── Inspect Command ──────────────────────────────────────────────────────


@report.command("inspect")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@pass_context
@handle_errors
def inspect(ctx: DxsContext, file: str) -> None:
    """Show spatial overview of all elements in a report.

    Lists every element with its type, name, position (left, top),
    size (width, height), value, and page settings. Use this to
    understand the current layout before making changes.

    \b
    Examples:
        dxs report inspect bol.rdlx-json
    """
    data = _read_report(file)
    report_def = _parse_report(data)

    page = report_def.Page
    items_info = []
    for item in report_def.all_items():
        item_dict: dict[str, Any] = {
            "name": item.Name,
            "type": item.Type,
            "position": {"left": item.Left or "0in", "top": item.Top or "0in"},
            "size": {"width": item.Width or "0in", "height": item.Height or "0in"},
        }
        if item.Value:
            item_dict["value"] = item.Value
        if item.Type == "barcode":
            extra = item.model_extra or {}
            if "Symbology" in extra:
                item_dict["symbology"] = extra["Symbology"]
        if item.Type == "table":
            extra = item.model_extra or {}
            if "DataSetName" in extra:
                item_dict["dataset"] = extra["DataSetName"]
        items_info.append(item_dict)

    result = {
        "file": file,
        "page": {
            "width": page.PageWidth,
            "height": page.PageHeight,
            "margins": {
                "top": page.TopMargin,
                "bottom": page.BottomMargin,
                "left": page.LeftMargin,
                "right": page.RightMargin,
            },
        },
        "items": items_info,
    }

    ctx.output(single(result, "report", count=len(items_info)))


# ── Add Commands ─────────────────────────────────────────────────────────


@report.group("add")
def add() -> None:
    """Add an element to a report.

    \b
    Element types: textbox, barcode, image, table, line, rectangle, shape

    \b
    Examples:
        dxs report add textbox report.rdlx-json --name Title --left 1in --top 0.5in --width 3in --height 0.3in --value "Title"
        dxs report add barcode report.rdlx-json --name ProBarcode --symbology Code128 --left 5in --top 0.5in --width 2in --height 0.5in --value "=Fields!PRO.Value"
    """


# Common options for positioning
def _position_options(f: Any) -> Any:
    """Add common position/size options to a command."""
    f = click.option("--left", default="0in", help="Left position (e.g., 1in, 2.5in)")(f)
    f = click.option("--top", default="0in", help="Top position")(f)
    f = click.option("--width", default="1in", help="Element width")(f)
    f = click.option("--height", default="0.25in", help="Element height")(f)
    return f


def _style_options(f: Any) -> Any:
    """Add common style options to a command."""
    f = click.option("--font-size", default=None, help="Font size (e.g., 10pt, 12pt)")(f)
    f = click.option(
        "--font-weight",
        default=None,
        type=click.Choice(["Normal", "Bold"], case_sensitive=False),
        help="Font weight",
    )(f)
    f = click.option("--font-family", default=None, help="Font family (e.g., Arial)")(f)
    f = click.option("--color", default=None, help="Text/foreground color")(f)
    f = click.option("--background-color", default=None, help="Background color")(f)
    f = click.option(
        "--text-align",
        default=None,
        type=click.Choice(["Left", "Center", "Right", "Justify"], case_sensitive=False),
        help="Text alignment",
    )(f)
    f = click.option(
        "--vertical-align",
        default=None,
        type=click.Choice(["Top", "Middle", "Bottom"], case_sensitive=False),
        help="Vertical alignment",
    )(f)
    f = click.option(
        "--border-style", default=None, help="Border style (None, Solid, Dashed, Dotted)"
    )(f)
    f = click.option("--border-color", default=None, help="Border color")(f)
    f = click.option("--border-width", default=None, help="Border width (e.g., 1pt)")(f)
    f = click.option("--padding", default=None, help="Padding all sides (e.g., 2pt)")(f)
    return f


def _build_style(
    font_size: str | None = None,
    font_weight: str | None = None,
    font_family: str | None = None,
    color: str | None = None,
    background_color: str | None = None,
    text_align: str | None = None,
    vertical_align: str | None = None,
    border_style: str | None = None,
    border_color: str | None = None,
    border_width: str | None = None,
    padding: str | None = None,
) -> dict[str, str] | None:
    """Build a Style dict from individual options."""
    style: dict[str, str] = {}
    if font_size:
        style["FontSize"] = font_size
    if font_weight:
        style["FontWeight"] = font_weight
    if font_family:
        style["FontFamily"] = font_family
    if color:
        style["Color"] = color
    if background_color:
        style["BackgroundColor"] = background_color
    if text_align:
        style["TextAlign"] = text_align
    if vertical_align:
        style["VerticalAlign"] = vertical_align
    if border_style or border_color or border_width:
        border: dict[str, str] = {}
        if border_style:
            border["Style"] = border_style
        if border_width:
            border["Width"] = border_width
        if border_color:
            border["Color"] = border_color
        style["Border"] = border
    if padding:
        style["PaddingLeft"] = padding
        style["PaddingRight"] = padding
        style["PaddingTop"] = padding
        style["PaddingBottom"] = padding
    return style or None


@add.command("textbox")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@click.option("--value", default=None, help="Text content or expression (e.g., =Fields!Name.Value)")
@click.option("--can-grow", is_flag=True, default=False, help="Allow textbox to grow vertically")
@_style_options
@pass_context
@handle_errors
def add_textbox(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    value: str | None,
    can_grow: bool,
    **style_kwargs: Any,
) -> None:
    """Add a textbox element.

    \b
    Examples:
        dxs report add textbox report.rdlx-json --name Title --left 1in --top 0in --width 3in --height 0.3in --value "Bill of Lading"
        dxs report add textbox report.rdlx-json --name ShipperName --left 0.5in --top 1in --width 3in --height 0.3in --value "=Fields!ShipperName.Value" --font-size 12pt --font-weight Bold
    """
    from dxs.report.engine import add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "textbox",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
    }
    if value is not None:
        item_props["Value"] = value
    if can_grow:
        item_props["CanGrow"] = True
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {
                "file": file,
                "element": name,
                "type": "textbox",
                "position": {"left": left, "top": top},
            },
            "element_added",
        )
    )


@add.command("barcode")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@click.option("--symbology", required=True, help="Barcode type (e.g., Code128, QRCode, PDF417)")
@_position_options
@click.option("--value", required=True, help="Data to encode (expression supported)")
@click.option("--caption/--no-caption", default=True, help="Show human-readable text")
@_style_options
@pass_context
@handle_errors
def add_barcode(
    ctx: DxsContext,
    file: str,
    name: str,
    symbology: str,
    left: str,
    top: str,
    width: str,
    height: str,
    value: str,
    caption: bool,
    **style_kwargs: Any,
) -> None:
    """Add a barcode element.

    \b
    Examples:
        dxs report add barcode report.rdlx-json --name ProBarcode --symbology Code128 --left 5in --top 0.5in --width 2.5in --height 0.75in --value "=Fields!PRONumber.Value"
        dxs report add barcode report.rdlx-json --name QR --symbology QRCode --left 6in --top 0in --width 1.5in --height 1.5in --value "=Fields!TrackingURL.Value" --no-caption
    """
    from dxs.report.engine import add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "barcode",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "Value": value,
        "Symbology": symbology,
        "Caption": caption,
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "barcode", "symbology": symbology},
            "element_added",
        )
    )


@add.command("image")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@click.option(
    "--source",
    required=True,
    type=click.Choice(["External", "Embedded", "Database"], case_sensitive=False),
    help="Image source type",
)
@click.option("--value", required=True, help="URL, embedded name, or expression")
@click.option("--mime-type", default="image/png", help="Image MIME type")
@click.option(
    "--sizing",
    default="FitProportional",
    type=click.Choice(["AutoSize", "Fit", "FitProportional", "Clip"], case_sensitive=False),
    help="Image sizing mode",
)
@_style_options
@pass_context
@handle_errors
def add_image(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    source: str,
    value: str,
    mime_type: str,
    sizing: str,
    **style_kwargs: Any,
) -> None:
    """Add an image element.

    \b
    Examples:
        dxs report add image report.rdlx-json --name Logo --source External --value "https://example.com/logo.png" --left 0in --top 0in --width 2in --height 1in
    """
    from dxs.report.engine import add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "image",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "Source": source,
        "Value": value,
        "MIMEType": mime_type,
        "Sizing": sizing,
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "image", "source": source},
            "element_added",
        )
    )


@add.command("table")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@click.option("--dataset", required=True, help="Dataset name to bind to")
@click.option(
    "--columns",
    default=None,
    help='Column widths as comma-separated values (e.g., "2in,3in,1.5in")',
)
@_style_options
@pass_context
@handle_errors
def add_table(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    dataset: str,
    columns: str | None,
    **style_kwargs: Any,
) -> None:
    """Add a table element.

    \b
    Examples:
        dxs report add table report.rdlx-json --name LineItems --left 0.5in --top 3in --width 7in --height 4in --dataset Lines --columns "1in,3in,1in,1in,1in"
    """
    from dxs.report.engine import add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "table",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "DataSetName": dataset,
    }

    if columns:
        col_widths = [c.strip() for c in columns.split(",")]
        item_props["TableColumns"] = [{"Width": w} for w in col_widths]

    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "table", "dataset": dataset},
            "element_added",
        )
    )


@add.command("line")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@click.option("--start-x", required=True, help="Start X coordinate (e.g., 0in)")
@click.option("--start-y", required=True, help="Start Y coordinate (e.g., 1in)")
@click.option("--end-x", required=True, help="End X coordinate (e.g., 3.75in)")
@click.option("--end-y", required=True, help="End Y coordinate (e.g., 1in)")
@click.option("--line-width", default=None, help="Line thickness (e.g., 1pt, 2pt, 3pt)")
@click.option(
    "--line-style",
    default=None,
    type=click.Choice(["Solid", "Dashed", "Dotted"]),
    help="Line style",
)
@pass_context
@handle_errors
def add_line(
    ctx: DxsContext,
    file: str,
    name: str,
    start_x: str,
    start_y: str,
    end_x: str,
    end_y: str,
    line_width: str | None,
    line_style: str | None,
) -> None:
    """Add a line element.

    Lines use StartPoint/EndPoint coordinates, not Left/Top/Width/Height.

    \b
    Examples:
        dxs report add line report.rdlx-json --name Divider --start-x 0in --start-y 2in --end-x 7in --end-y 2in --line-width 2pt
        dxs report add line report.rdlx-json --name VLine --start-x 1.875in --start-y 0in --end-x 1.875in --end-y 0.7in
    """
    from dxs.report.engine import add_item

    item_props: dict[str, Any] = {
        "Type": "line",
        "Name": name,
        "StartPoint": {"X": start_x, "Y": start_y},
        "EndPoint": {"X": end_x, "Y": end_y},
    }
    if line_width:
        item_props["LineWidth"] = line_width
    if line_style:
        item_props["LineStyle"] = line_style

    data = _read_report(file)
    report_def = _parse_report(data)
    add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "line"},
            "element_added",
        )
    )


@add.command("rectangle")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@_style_options
@pass_context
@handle_errors
def add_rectangle(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    **style_kwargs: Any,
) -> None:
    """Add a rectangle element.

    \b
    Examples:
        dxs report add rectangle report.rdlx-json --name Section1 --left 0.5in --top 0.5in --width 7in --height 3in --border-style Solid --border-width 1pt
    """
    from dxs.report.engine import add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "rectangle",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "rectangle"},
            "element_added",
        )
    )


@add.command("shape")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--name", required=True, help="Element name (unique identifier)")
@_position_options
@click.option(
    "--shape-type",
    default="Rectangle",
    type=click.Choice(
        [
            "Rectangle",
            "RoundedRectangle",
            "Ellipse",
            "Triangle",
            "Cross",
            "Diamond",
            "Pentagon",
            "Hexagon",
            "Star",
            "Arrow",
        ],
        case_sensitive=False,
    ),
    help="Shape type",
)
@_style_options
@pass_context
@handle_errors
def add_shape(
    ctx: DxsContext,
    file: str,
    name: str,
    left: str,
    top: str,
    width: str,
    height: str,
    shape_type: str,
    **style_kwargs: Any,
) -> None:
    """Add a shape element.

    \b
    Examples:
        dxs report add shape report.rdlx-json --name Bullet --shape-type Ellipse --left 0.5in --top 0.5in --width 0.25in --height 0.25in --background-color Red
    """
    from dxs.report.engine import add_item

    style = _build_style(**style_kwargs)
    item_props: dict[str, Any] = {
        "Type": "shape",
        "Name": name,
        "Left": left,
        "Top": top,
        "Width": width,
        "Height": height,
        "ShapeType": shape_type,
    }
    if style:
        item_props["Style"] = style

    data = _read_report(file)
    report_def = _parse_report(data)
    add_item(report_def, item_props)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": name, "type": "shape", "shape_type": shape_type},
            "element_added",
        )
    )


# ── Set / Move / Remove Commands ─────────────────────────────────────────


@report.command("set")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.argument("element_name")
@click.option("--value", default=None, help="New value/text content")
@_style_options
@click.option("--can-grow", default=None, type=bool, help="Allow textbox to grow")
@click.option("--symbology", default=None, help="Barcode symbology")
@click.option("--caption", default=None, type=bool, help="Show barcode caption")
@click.option("--sizing", default=None, help="Image sizing mode")
@click.option("--dataset", default=None, help="Table dataset name")
@click.option("--shape-type", default=None, help="Shape type")
@pass_context
@handle_errors
def set_props(
    ctx: DxsContext,
    file: str,
    element_name: str,
    value: str | None,
    can_grow: bool | None,
    symbology: str | None,
    caption: bool | None,
    sizing: str | None,
    dataset: str | None,
    shape_type: str | None,
    **style_kwargs: Any,
) -> None:
    """Modify properties of an existing element.

    Updates value, style, or type-specific properties on a named
    element. At least one property option must be provided. Style
    properties are merged (existing styles are preserved unless
    overridden). Use 'dxs report move' for position/size changes.

    \b
    Examples:
        dxs report set report.rdlx-json ShipperName --font-size 12pt --font-weight Bold
        dxs report set report.rdlx-json ProBarcode --symbology QRCode
        dxs report set report.rdlx-json Title --value "Updated Title"
    """
    from dxs.report.engine import set_item_properties
    from dxs.utils.errors import ValidationError

    data = _read_report(file)
    report_def = _parse_report(data)

    item = report_def.find_item(element_name)
    if item is None:
        all_names = [i.Name for i in report_def.all_items()]
        raise ValidationError(
            message=f"Element '{element_name}' not found in {file}",
            code="DXS-RPT-020",
            suggestions=[f"Available elements: {', '.join(all_names)}"] if all_names else [],
        )

    # Build property updates
    updates: dict[str, Any] = {}
    if value is not None:
        updates["Value"] = value
    if can_grow is not None:
        updates["CanGrow"] = can_grow
    if symbology is not None:
        updates["Symbology"] = symbology
    if caption is not None:
        updates["Caption"] = caption
    if sizing is not None:
        updates["Sizing"] = sizing
    if dataset is not None:
        updates["DataSetName"] = dataset
    if shape_type is not None:
        updates["ShapeType"] = shape_type

    style = _build_style(**style_kwargs)
    if style:
        updates["Style"] = style

    if not updates:
        raise ValidationError(
            message="No properties specified to update",
            code="DXS-RPT-021",
            suggestions=["Specify at least one property to change (e.g., --value, --font-size)"],
        )

    set_item_properties(item, updates)
    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": element_name, "updated_properties": list(updates.keys())},
            "element_updated",
        )
    )


@report.command("move")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.argument("element_name")
@click.option("--left", default=None, help="New left position")
@click.option("--top", default=None, help="New top position")
@click.option("--width", default=None, help="New width")
@click.option("--height", default=None, help="New height")
@pass_context
@handle_errors
def move(
    ctx: DxsContext,
    file: str,
    element_name: str,
    left: str | None,
    top: str | None,
    width: str | None,
    height: str | None,
) -> None:
    """Reposition or resize an element.

    Changes position (--left, --top) and/or size (--width, --height)
    of a named element. At least one option is required. Only the
    specified properties are updated; others remain unchanged.

    \b
    Examples:
        dxs report move report.rdlx-json ProBarcode --left 5in --top 0.75in
        dxs report move report.rdlx-json Title --width 4in --height 0.5in
    """
    from dxs.utils.errors import ValidationError

    data = _read_report(file)
    report_def = _parse_report(data)

    item = report_def.find_item(element_name)
    if item is None:
        all_names = [i.Name for i in report_def.all_items()]
        raise ValidationError(
            message=f"Element '{element_name}' not found in {file}",
            code="DXS-RPT-020",
            suggestions=[f"Available elements: {', '.join(all_names)}"] if all_names else [],
        )

    changed: dict[str, str] = {}
    if left is not None:
        item.Left = left
        changed["left"] = left
    if top is not None:
        item.Top = top
        changed["top"] = top
    if width is not None:
        item.Width = width
        changed["width"] = width
    if height is not None:
        item.Height = height
        changed["height"] = height

    if not changed:
        raise ValidationError(
            message="No position/size changes specified",
            code="DXS-RPT-022",
            suggestions=["Specify at least one of: --left, --top, --width, --height"],
        )

    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": element_name, "changes": changed},
            "element_moved",
        )
    )


@report.command("remove")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.argument("element_name")
@pass_context
@handle_errors
def remove(ctx: DxsContext, file: str, element_name: str) -> None:
    """Remove an element by name.

    \b
    Examples:
        dxs report remove report.rdlx-json OldElement
    """
    from dxs.report.engine import remove_item
    from dxs.utils.errors import ValidationError

    data = _read_report(file)
    report_def = _parse_report(data)

    if not remove_item(report_def, element_name):
        all_names = [i.Name for i in report_def.all_items()]
        raise ValidationError(
            message=f"Element '{element_name}' not found in {file}",
            code="DXS-RPT-020",
            suggestions=[f"Available elements: {', '.join(all_names)}"] if all_names else [],
        )

    _write_report(file, _serialize_report(report_def))

    ctx.output(
        single(
            {"file": file, "element": element_name},
            "element_removed",
        )
    )


# ── Validate Command ─────────────────────────────────────────────────────


@report.command("validate")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@pass_context
@handle_errors
def validate(ctx: DxsContext, file: str) -> None:
    """Validate report structure, layout, and expressions.

    Checks for: duplicate element names, missing required properties
    (e.g., barcode Symbology, image Source), elements positioned outside
    the page content area, invalid barcode symbologies, and malformed
    expressions. Returns errors (must fix) and warnings (may fix).

    \b
    Examples:
        dxs report validate bol.rdlx-json
    """
    from dxs.report.validator import validate_report

    data = _read_report(file)
    report_def = _parse_report(data)
    result = validate_report(report_def)

    ctx.output(
        single(
            {
                "file": file,
                "valid": result["valid"],
                "errors": result["errors"],
                "warnings": result["warnings"],
            },
            "validation",
        )
    )


# ── Preview Command ──────────────────────────────────────────────────────


@report.command("preview")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option(
    "--data",
    "-d",
    type=click.Path(exists=True, dir_okay=False),
    help="Sample data JSON file for data binding",
)
@click.option(
    "--output",
    "-o",
    "output_path",
    type=click.Path(),
    help="Output PNG path (default: <file>-preview.png)",
)
@click.option(
    "--per-page",
    is_flag=True,
    default=False,
    help="Separate PNG per page instead of single stitched image",
)
@click.option("--width", type=int, default=800, help="Image width in pixels")
@click.option("--timeout", type=int, default=30, help="Render timeout in seconds")
@pass_context
@handle_errors
def preview(
    ctx: DxsContext,
    file: str,
    data: str | None,
    output_path: str | None,
    per_page: bool,
    width: int,
    timeout: int,
) -> None:
    """Render report to PNG image using ActiveReportsJS.

    Uses the ActiveReportsJS viewer in a headless browser to produce a
    pixel-accurate preview. Requires agent-browser to be installed
    (npm install -g @anthropic-ai/agent-browser && agent-browser install).

    By default renders all pages into a single tall PNG suitable for
    LLM vision inspection. Use --per-page for separate page images.

    \b
    Examples:
        dxs report preview label.rdlx-json
        dxs report preview label.rdlx-json --data sample.json -o preview.png
        dxs report preview bol.rdlx-json --per-page --width 1200
    """
    from dxs.report.preview import render_preview

    # Read report definition
    report_data = _read_report(file)

    # Read optional sample data
    sample_data = None
    if data:
        sample_data = _read_report(data)

    # Determine output path
    if output_path is None:
        stem = Path(file).stem
        output_path = f"{stem}-preview.png"

    result = render_preview(
        report_data=report_data,
        output_path=output_path,
        sample_data=sample_data,
        target_width=width,
        per_page=per_page,
        timeout=timeout,
    )

    ctx.output(single(result, "preview"))


# ── Upload / Download Commands ───────────────────────────────────────────


@report.command("upload")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--branch", "-b", type=int, required=True, help="Branch ID to upload to")
@click.option("--name", "report_name", required=True, help="Report display name in Datex Studio")
@click.option(
    "--reference-name", default=None, help="Report reference name (defaults to sanitized name)"
)
@click.option("--description", "report_description", default=None, help="Report description")
@click.option("--report-type", default="CPL", help="Report type (default: CPL)")
@click.option(
    "--datasource-config",
    default=None,
    type=click.Path(exists=True, dir_okay=False),
    help="Datasource config JSON file",
)
@pass_context
@require_auth
@handle_errors
def upload(
    ctx: DxsContext,
    file: str,
    branch: int,
    report_name: str,
    reference_name: str | None,
    report_description: str | None,
    report_type: str,
    datasource_config: str | None,
) -> None:
    """Upload report to Datex Studio as a report configuration.

    Wraps the local .rdlx-json file in the Datex Studio envelope
    format and uploads it via the API. If a report with the same
    reference name already exists on the branch, it is updated
    in place; otherwise a new configuration is created.

    \b
    Examples:
        dxs report upload bol.rdlx-json --branch 123 --name "Carrier BOL v2"
        dxs report upload label.rdlx-json --branch 123 --name "Shipping Label" --reference-name shipping_label
    """
    from dxs.core.api import ApiClient
    from dxs.report.wrapper import rdl_to_datex_wrapper

    # Read the local RDL file
    data = _read_report(file)

    # Load optional datasource config
    ds_configs = None
    if datasource_config:
        ds_data = _read_report(datasource_config)
        ds_configs = ds_data if isinstance(ds_data, list) else [ds_data]

    # Build Datex Studio wrapper
    wrapper = rdl_to_datex_wrapper(
        rdl_definition=data,
        report_name=report_name,
        reference_name=reference_name,
        description=report_description,
        report_type=report_type,
        datasource_configs=ds_configs,
    )

    # Upload via API — update existing config if found, otherwise create
    client = ApiClient()
    endpoint = f"/applications/{branch}/reportconfigurations"
    ref_name = wrapper.get("referenceName")

    # Check for existing config by reference name
    existing_id = None
    try:
        configs = client.get(endpoint)
        if isinstance(configs, list):
            for cfg in configs:
                if isinstance(cfg, dict) and cfg.get("referenceName") == ref_name:
                    existing_id = cfg.get("id")
                    break
    except Exception:
        pass  # If listing fails, fall through to create

    if existing_id is not None:
        # Update existing config
        wrapper["id"] = existing_id
        response = client.put(f"{endpoint}/{existing_id}", data=wrapper)
        action = "updated"
    else:
        # Create new config
        response = client.post(endpoint, data=wrapper)
        action = "created"

    config_id = existing_id
    if isinstance(response, dict):
        config_id = response.get("id", config_id)

    ctx.output(
        single(
            {
                "file": file,
                "branch_id": branch,
                "name": report_name,
                "reference_name": ref_name,
                "config_id": config_id,
                "action": action,
            },
            "report_uploaded",
        )
    )


@report.command("download")
@click.argument("file", type=click.Path(dir_okay=False))
@click.option("--branch", "-b", type=int, required=True, help="Branch ID")
@click.option("--report-id", type=int, default=None, help="Report configuration ID")
@click.option("--reference-name", default=None, help="Report reference name")
@click.option("--force", is_flag=True, default=False, help="Overwrite existing file")
@pass_context
@require_auth
@handle_errors
def download(
    ctx: DxsContext,
    file: str,
    branch: int,
    report_id: int | None,
    reference_name: str | None,
    force: bool,
) -> None:
    """Download a report from Datex Studio to a local file.

    Fetches the report configuration from the API, extracts the RDL
    definition from the Datex Studio envelope, and saves it as a local
    .rdlx-json file. Either --report-id or --reference-name is required
    to identify the report.

    \b
    Examples:
        dxs report download bol.rdlx-json --branch 123 --report-id 456
        dxs report download bol.rdlx-json --branch 123 --reference-name receiving_report
    """
    from dxs.core.api import ApiClient
    from dxs.report.wrapper import datex_wrapper_to_rdl
    from dxs.utils.errors import ValidationError

    if report_id is None and reference_name is None:
        raise ValidationError(
            message="Either --report-id or --reference-name is required",
            code="DXS-RPT-030",
            suggestions=["Provide --report-id <id> or --reference-name <name>"],
        )

    path = Path(file)
    if path.exists() and not force:
        raise ValidationError(
            message=f"File already exists: {file}",
            code="DXS-RPT-012",
            suggestions=["Use --force to overwrite or choose a different filename"],
        )

    client = ApiClient()

    if report_id is not None:
        endpoint = f"/applications/{branch}/reportconfigurations/{report_id}"
    else:
        endpoint = f"/applications/{branch}/reportconfigurations/referenceName/{reference_name}"

    response = client.get(endpoint)

    if not isinstance(response, dict):
        raise ValidationError(
            message="Unexpected API response format",
            code="DXS-RPT-031",
        )

    # Extract RDL definition from wrapper
    rdl_definition = datex_wrapper_to_rdl(response)
    _write_report(file, rdl_definition)

    ctx.output(
        single(
            {
                "file": file,
                "branch_id": branch,
                "name": response.get("title"),
                "reference_name": response.get("referenceName"),
            },
            "report_downloaded",
        )
    )
