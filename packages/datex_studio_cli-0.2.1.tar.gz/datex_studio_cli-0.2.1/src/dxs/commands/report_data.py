"""Report configuration commands.

Commands for generating and uploading Datex Studio report configurations
from datasource references in a single step.
"""

import json
import re

import click

from dxs.cli import DxsContext, pass_context
from dxs.core.api.client import ApiClient
from dxs.core.api.endpoints import ConfigurationEndpoints
from dxs.core.auth import require_auth
from dxs.core.report_data import ReportGenerator
from dxs.core.report_data.field_parser import ParsedCollection, ParsedField, parse_fields
from dxs.utils.errors import ApiError
from dxs.utils.responses import list_response, single


def _parse_section_entry(value: str) -> tuple[str, str, str, str, str | None, str | None]:
    """Parse a '--section' value into (type, collection, path, label, width, format).

    Formats:
        card:PATH:LABEL[:WIDTH[:FORMAT]]
        table:COLLECTION:PATH:LABEL[:WIDTH[:FORMAT]]   (COLLECTION may be empty: table::PATH:LABEL)
        image:FIELD
        label:TEXT CONTENT (may contain colons)
        summary:COLLECTION:PATH:LABEL[:WIDTH[:FORMAT]]

    Returns:
        (type, collection, path, label, width_or_none, format_or_none)
    """
    parts = value.split(":", 1)
    if len(parts) < 2:
        raise click.UsageError(
            f"--section must be 'card:PATH:LABEL[:WIDTH[:FORMAT]]', "
            f"'table:COLLECTION:PATH:LABEL[:WIDTH[:FORMAT]]', 'image:FIELD', "
            f"'label:TEXT', or 'summary:COLLECTION:PATH:LABEL[:WIDTH[:FORMAT]]', got: {value!r}"
        )
    section_type = parts[0].lower()
    rest = parts[1]

    if section_type == "card":
        field_parts = rest.split(":", 3)
        if len(field_parts) < 2:
            raise click.UsageError(
                f"--section card requires at least PATH:LABEL, got: {value!r}"
            )
        path, label = field_parts[0], field_parts[1]
        width = field_parts[2] if len(field_parts) >= 3 else None
        fmt = field_parts[3] if len(field_parts) == 4 else None
        return ("card", "", path, label, width, fmt)

    elif section_type in ("table", "summary"):
        coll_rest = rest.split(":", 1)
        collection = coll_rest[0]  # may be empty string
        field_str = coll_rest[1] if len(coll_rest) > 1 else ""
        field_parts = field_str.split(":", 3)
        if len(field_parts) < 2:
            raise click.UsageError(
                f"--section {section_type} requires COLLECTION:PATH:LABEL[:WIDTH[:FORMAT]], got: {value!r}"
            )
        path, label = field_parts[0], field_parts[1]
        width = field_parts[2] if len(field_parts) >= 3 else None
        fmt = field_parts[3] if len(field_parts) == 4 else None
        return (section_type, collection, path, label, width, fmt)

    elif section_type == "image":
        # rest is the full field path (alias.FIELD or just FIELD)
        return ("image", "", rest, "", None, None)

    elif section_type == "label":
        # rest is the full text content (may contain colons)
        return ("label", "", rest, "", None, None)

    else:
        raise click.UsageError(
            f"--section type must be 'card', 'table', 'image', 'label', or 'summary', "
            f"got: {section_type!r}"
        )


def _group_sections(
    entries: list[tuple[str, str, str, str, str | None, str | None]],
    alias_set: set[str] | None = None,
) -> list[dict]:
    """Group consecutive same-(type, alias, collection) entries into section dicts.

    Each section dict has:
        type: "card" | "table" | "image" | "label" | "summary"
        alias: str (resolved alias prefix, may be "")
        collection: str (nav property for table/summary; "" for card/image/label)
        fields: [(path, label, width_or_none, format_or_none), ...]

    For "image" and "label", each entry always forms its own section (unique grouping key).
    Alias prefixes (e.g. "orders.Path") are stripped from path/collection; stored in "alias".
    """
    from dxs.core.report_data.generator import _resolve_alias as resolve_alias

    _alias_set = alias_set or set()

    if not entries:
        return []

    sections: list[dict] = []
    _unique_counter = [0]

    def _entry_key(section_type: str, alias: str, collection: str) -> tuple:
        if section_type in ("image", "label"):
            _unique_counter[0] += 1
            return (section_type, alias, collection, _unique_counter[0])
        return (section_type, alias, collection)

    def _resolve_entry(section_type: str, raw_collection: str, raw_path: str) -> tuple[str, str, str]:
        """Return (resolved_alias, clean_collection, clean_path)."""
        if section_type in ("table", "summary"):
            alias, clean_coll = resolve_alias(raw_collection, _alias_set)
            return alias, clean_coll, raw_path
        elif section_type == "card":
            alias, clean_path = resolve_alias(raw_path, _alias_set)
            return alias, "", clean_path
        elif section_type == "image":
            alias, clean_path = resolve_alias(raw_path, _alias_set)
            return alias, "", clean_path
        else:
            # label: no alias resolution
            return "", "", raw_path

    first_type, first_raw_coll, first_raw_path, first_label, first_width, first_fmt = entries[0]
    first_alias, first_clean_coll, first_clean_path = _resolve_entry(first_type, first_raw_coll, first_raw_path)
    current_key = _entry_key(first_type, first_alias, first_clean_coll)
    current_type = first_type
    current_alias = first_alias
    current_coll = first_clean_coll
    current_fields: list[tuple[str, str, str | None, str | None]] = [
        (first_clean_path, first_label, first_width, first_fmt)
    ]

    for section_type, raw_collection, raw_path, label, width, fmt in entries[1:]:
        alias, clean_coll, clean_path = _resolve_entry(section_type, raw_collection, raw_path)
        key = _entry_key(section_type, alias, clean_coll)
        if key == current_key:
            current_fields.append((clean_path, label, width, fmt))
        else:
            sections.append({
                "type": current_type,
                "alias": current_alias,
                "collection": current_coll,
                "fields": current_fields,
            })
            current_key = key
            current_type = section_type
            current_alias = alias
            current_coll = clean_coll
            current_fields = [(clean_path, label, width, fmt)]

    sections.append({
        "type": current_type,
        "alias": current_alias,
        "collection": current_coll,
        "fields": current_fields,
    })
    return sections


def _parse_use_datasource(value: str) -> tuple[str, str | None, str]:
    """Parse '--use-datasource' value into (config_id, module_id, alias).

    Formats:
        'ds_ref:alias'          ? config_id='ds_ref', module_id=None, alias='alias'
        'pkg/ds_ref:alias'      ? config_id='ds_ref', module_id='pkg', alias='alias'
    """
    if ":" not in value:
        raise click.UsageError(
            f"--use-datasource must be 'ref:alias' or 'pkg/ref:alias', got: {value!r}"
        )
    ref_part, alias = value.rsplit(":", 1)
    if "/" in ref_part:
        module_id, config_id = ref_part.split("/", 1)
    else:
        config_id = ref_part
        module_id = None
    return config_id, module_id, alias


def _parse_param(value: str) -> tuple[str, str]:
    """Parse 'name:type' ? (name, type)."""
    parts = value.split(":", 1)
    if len(parts) != 2:
        raise click.UsageError(f"--param must be 'name:type', got: {value!r}")
    return parts[0], parts[1]


def _parse_datasource_param(value: str) -> tuple[str, str, str]:
    """Parse '[Alias.]ds_param=expr' ? (alias_or_empty, ds_param, expr).

    Formats:
        'ds_param=expr'           ? ('', 'ds_param', 'expr')   # applies to all datasources
        'Alias.ds_param=expr'     ? ('Alias', 'ds_param', 'expr')  # alias-specific routing
    """
    if "=" not in value:
        raise click.UsageError(
            f"--datasource-param must be 'ds_param=expression' or 'Alias.ds_param=expression', got: {value!r}"
        )
    key, expr = value.split("=", 1)
    if "." in key:
        alias_prefix, ds_param = key.split(".", 1)
        return alias_prefix, ds_param, expr
    return "", key, expr


def _parse_inline_data(value: str) -> tuple[str, list[dict]]:
    """Parse 'ALIAS:JSON_ARRAY' into (alias, rows).

    Example:
        'alpha:[{"upper":"A","lower":"a"}]'  ->  ('alpha', [{'upper': 'A', 'lower': 'a'}])
    """
    if ":" not in value:
        raise click.UsageError(f"--inline-data must be 'alias:JSON_ARRAY', got: {value!r}")
    alias, json_str = value.split(":", 1)
    alias = alias.strip()
    try:
        rows = json.loads(json_str)
        if not isinstance(rows, list):
            raise ValueError("value must be a JSON array")
    except (json.JSONDecodeError, ValueError) as e:
        raise click.UsageError(f"--inline-data JSON error for alias '{alias}': {e}") from e
    return alias, rows


def _schema_from_rows(alias: str, rows: list[dict]) -> list[dict]:
    """Derive configOutParameters from the first row's keys."""
    if not rows:
        return []
    sample = rows[0]
    fields = []
    for key, val in sample.items():
        typ = "number" if isinstance(val, (int, float)) and not isinstance(val, bool) else "string"
        fields.append({"id": key, "type": typ, "isCollection": False})
    return [{"id": "result", "type": "object", "isCollection": True, "objectTypeDef": fields}]


def _suggested_alias(reference_name: str) -> str:
    """Derive a suggested alias from datasource referenceName.

    'ds_shipment_bol' ? 'shipment_bol'
    'ds_orders' ? 'orders'
    'my_ds' ? 'my_ds' (no ds_ prefix to strip)
    """
    if reference_name.startswith("ds_"):
        return reference_name[3:]
    return reference_name


@click.group(name="report-data")
def report_data() -> None:
    """Report configuration generation and management.

    Generate and upload Datex Studio report configurations
    that reference existing datasources.

    \\b
    Examples:
        # Inspect datasource fields
        dxs report-data fields ds_shipment_bol --branch 61

        # Create a table report
        dxs report-data upsert -r rep_orders -t "Orders" -d "Order list" \\
          --use-datasource ds_orders:orders \\
          --section "table::Id:Order ID:1in" \\
          --section "table::LookupCode:Reference" \\
          --branch 61

        # Create a document report (header card + lines table)
        dxs report-data upsert -r rep_bol -t "Bill of Lading" -d "BOL for one shipment" \\
          --use-datasource ds_shipment_bol:shipment \\
          --section "card:LookupCode:Shipment #:1in" \\
          --section "card:Account.Name:Shipper" \\
          --section "table:ShipmentLines:LineNumber:Line #:0.5in" \\
          --section "table:ShipmentLines:GrossWeight:Weight" \\
          --param id:number \\
          --datasource-param "id=$report.inParams.id" \\
          --branch 61
    """
    pass


@report_data.command()
@click.argument("datasource_ref")
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID to fetch the datasource from",
)
@pass_context
@require_auth
def fields(ctx: DxsContext, datasource_ref: str, branch: int | None) -> None:
    """Show fields available from a datasource for use in a report.

    Fetches the uploaded datasource from the branch and displays its
    configOutParameters as a structured field list.

    \\b
    Example:
        dxs report-data fields ds_shipment_bol --branch 61
    """
    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    api_client = ApiClient()
    ds = api_client.get(
        ConfigurationEndpoints.get_by_reference(branch_id, "datasource", datasource_ref)
    )

    ds_json: dict = ds.get("json") or {}
    type_def = ds_json.get("queryOptionsObjectTypeDef") or []
    is_coll = ds_json.get("resultIsCollection", False)
    config_out_parameters: list[dict] = (
        [{"id": "result", "type": "object", "isCollection": is_coll, "objectTypeDef": type_def}]
        if type_def else []
    )
    is_collection, flat_fields, collections = parse_fields(config_out_parameters)

    def _field_entry(f: ParsedField) -> dict:
        return {"path": f.path, "type": f.type}

    def _collection_entry(c: ParsedCollection) -> dict:
        return {
            "path": c.path,
            "fields": [_field_entry(f) for f in c.fields],
        }

    ds_in_params: list[dict] = ds_json.get("inParams") or []
    in_params_out = [
        {"id": p["id"], "type": p.get("type", "string")}
        for p in ds_in_params
        if "id" in p
    ]

    output = {
        "datasource": datasource_ref,
        "result_type": "collection" if is_collection else "single",
        "suggested_alias": _suggested_alias(datasource_ref),
        "in_params": in_params_out,
        "fields": [_field_entry(f) for f in flat_fields],
        "collections": [_collection_entry(c) for c in collections],
    }

    ctx.output(single(item=output, semantic_key="datasource_fields"))


@report_data.command()
@click.option(
    "--reference-name",
    "-r",
    type=str,
    required=True,
    help="Unique report reference name (valid JS identifier, conventionally rep_...)",
)
@click.option(
    "--title",
    "-t",
    type=str,
    required=True,
    help="Display title",
)
@click.option(
    "--description",
    "-d",
    type=str,
    required=True,
    help="Description of the report purpose",
)
@click.option(
    "--use-datasource",
    "use_datasource",
    multiple=True,
    required=False,
    metavar="REF:ALIAS",
    help=(
        "Datasource to use. Repeatable. Format: 'ref:alias' or 'pkg/ref:alias' for cross-package. "
        "Example: ds_shipment_bol:shipment"
    ),
)
@click.option(
    "--section",
    "sections_raw",
    multiple=True,
    metavar="TYPE:...",
    help=(
        "Report section entry. Repeatable. Consecutive same-(type,collection) entries "
        "form one section. Formats: "
        "'card:PATH:LABEL[:WIDTH]' or "
        "'table:COLLECTION:PATH:LABEL[:WIDTH]' (empty collection for flat table: table::PATH:LABEL)."
    ),
)
@click.option(
    "--param",
    "params_raw",
    multiple=True,
    metavar="NAME:TYPE",
    help="Report input parameter. Format: name:type. Repeatable.",
)
@click.option(
    "--datasource-param",
    "datasource_params_raw",
    multiple=True,
    metavar="PARAM=EXPRESSION",
    help=(
        "Parameter passed to datasource. Format: ds_param=expression. "
        "Example: id=$report.inParams.id. Repeatable."
    ),
)
@click.option(
    "--orientation",
    type=click.Choice(["portrait", "landscape"], case_sensitive=False),
    default="portrait",
    help="Page orientation (default: portrait)",
)
@click.option(
    "--page-size",
    type=click.Choice(["letter", "a4", "a3"], case_sensitive=False),
    default="letter",
    help="Page size (default: letter)",
)
@click.option(
    "--inline-data",
    "inline_data_raw",
    multiple=True,
    metavar="ALIAS:JSON_ARRAY",
    help=(
        "Inline static data for a table section. Format: 'alias:[{...},{...},...]'. "
        "Repeatable. The alias can be used in --section as the collection name: "
        "'table:alias:field:Label'. No --use-datasource needed for inline data."
    ),
)
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Target branch ID (falls back to global -b/--branch context)",
)
@pass_context
@require_auth
def upsert(
    ctx: DxsContext,
    reference_name: str,
    title: str,
    description: str,
    use_datasource: tuple[str, ...],
    sections_raw: tuple[str, ...],
    params_raw: tuple[str, ...],
    datasource_params_raw: tuple[str, ...],
    inline_data_raw: tuple[str, ...],
    orientation: str,
    page_size: str,
    branch: int | None,
) -> None:
    """Generate and upload a report configuration to a branch.

    Performs an upsert (create or update) on the target branch.
    Fetches the datasource from the same branch to copy its configOutParameters.

    \\b
    CRITICAL REQUIREMENTS:
    1. The datasource must already be uploaded to the branch (use 'dxs datasource upsert' first)
    2. Reference names must be valid JavaScript identifiers (conventionally rep_...)
    3. At least one --section is required

    \\b
    Examples:
        # Table report
        dxs report-data upsert -r rep_orders -t "Orders" -d "List of orders" \\
          --use-datasource ds_orders:orders \\
          --section "table::Id:Order ID:1in" \\
          --section "table::LookupCode:Reference" \\
          --branch 61

        # Document report (BOL): card header + table lines
        dxs report-data upsert -r rep_bol -t "Bill of Lading" -d "BOL for one shipment" \\
          --use-datasource ds_shipment_bol:shipment \\
          --section "card:LookupCode:Shipment #" \\
          --section "card:Account.Name:Shipper" \\
          --section "table:ShipmentLines:LineNumber:Line #:0.5in" \\
          --section "table:ShipmentLines:OrderLine.Material.Name:Description" \\
          --param id:number \\
          --datasource-param "id=$report.inParams.id" \\
          --branch 61
    """
    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    # Parse inline data first
    parsed_inline: list[tuple[str, list[dict]]] = [_parse_inline_data(v) for v in inline_data_raw]
    inline_alias_set = {alias for alias, _ in parsed_inline}

    if not use_datasource and not parsed_inline:
        raise click.UsageError("At least one --use-datasource or --inline-data is required.")

    if not sections_raw:
        raise click.UsageError("At least one --section is required.")

    # Parse options
    all_ds_specs = [_parse_use_datasource(d) for d in use_datasource]
    alias_set = {alias for _, _, alias in all_ds_specs} | inline_alias_set

    parsed_entries = [_parse_section_entry(s) for s in sections_raw]
    report_sections = _group_sections(parsed_entries, alias_set=alias_set)
    parsed_params = [_parse_param(p) for p in params_raw]
    # Each element is (ds_alias_or_empty, ds_param, expr)
    parsed_ds_params_raw = [_parse_datasource_param(p) for p in datasource_params_raw]

    # Build per-alias param map: "" key = global (applies to all datasources)
    datasource_params_by_alias: dict[str, list[tuple[str, str]]] = {}
    for ds_alias, param, expr in parsed_ds_params_raw:
        datasource_params_by_alias.setdefault(ds_alias, []).append((param, expr))

    # Fetch all datasources from the branch
    api_client = ApiClient()
    datasources_spec: list[dict] = []
    primary_ds_param_types: dict[str, str] = {}
    primary_ds_param_required: dict[str, bool | None] = {}
    per_alias_param_types: dict[str, dict[str, str]] = {}
    per_alias_param_required: dict[str, dict[str, bool | None]] = {}

    # Register inline (static) datasources — no API fetch needed
    for alias, rows in parsed_inline:
        config_out_parameters = _schema_from_rows(alias, rows)
        datasources_spec.append({
            "config_id": alias,
            "module_id": "static",
            "alias": alias,
            "config_out_parameters": config_out_parameters,
            "is_collection": True,
            "is_static": True,
            "key_def": None,
        })
        per_alias_param_types[alias] = {}
        per_alias_param_required[alias] = {}

    for i, (ds_config_id, ds_module_id, alias) in enumerate(all_ds_specs):
        ctx.log(f"Fetching datasource: {ds_config_id}")
        ds = api_client.get(
            ConfigurationEndpoints.get_by_reference(branch_id, "datasource", ds_config_id)
        )
        ds_json: dict = ds.get("json") or {}
        type_def = ds_json.get("queryOptionsObjectTypeDef") or []
        is_coll = ds_json.get("resultIsCollection", False)
        config_out_parameters: list[dict] = (
            [{"id": "result", "type": "object", "isCollection": is_coll, "objectTypeDef": type_def}]
            if type_def else []
        )
        datasources_spec.append({
            "config_id": ds_config_id,
            "module_id": ds_module_id,
            "alias": alias,
            "config_out_parameters": config_out_parameters,
            "is_collection": bool(config_out_parameters and config_out_parameters[0].get("isCollection", False)),
            "key_def": ds_json.get("keyDef") or None,
        })
        # Collect inParams type/required for each datasource alias
        ds_in_params: list[dict] = ds_json.get("inParams") or []
        per_alias_param_types[alias] = {p["id"]: p.get("type", "string") for p in ds_in_params if "id" in p}
        per_alias_param_required[alias] = {p["id"]: p.get("required") for p in ds_in_params if "id" in p}
        if i == 0:
            primary_ds_param_types = per_alias_param_types[alias]
            primary_ds_param_required = per_alias_param_required[alias]

    # Map report param names ? required flag by tracing --datasource-param expressions.
    # For alias-prefixed params, use the matching alias's inParams; for global params use primary.
    # Only propagate explicit True/False; if the datasource param has no required field, leave the
    # report_param_required dict empty for that name so the generator defaults to True.
    _report_param_re = re.compile(r"\$report\.inParams\.(\w+)")
    report_param_required: dict[str, bool] = {}
    for ds_alias, ds_param, expr in parsed_ds_params_raw:
        if ds_alias:
            param_req_map = per_alias_param_required.get(ds_alias, primary_ds_param_required)
        else:
            param_req_map = primary_ds_param_required
        required = param_req_map.get(ds_param)
        if required is not None:
            for report_param_name in _report_param_re.findall(expr):
                report_param_required[report_param_name] = required

    # Build static data dict for generator
    static_data_dict: dict[str, list[dict]] | None = (
        dict(parsed_inline) if parsed_inline else None
    )

    # Generate report config
    generator = ReportGenerator()
    config_dict = generator.generate(
        reference_name=reference_name,
        title=title,
        description=description,
        datasources=datasources_spec,
        in_params=parsed_params,
        datasource_params=datasource_params_by_alias.get("", []),
        datasource_params_by_alias=datasource_params_by_alias,
        datasource_param_types=primary_ds_param_types,
        per_alias_param_types=per_alias_param_types,
        datasource_param_required=primary_ds_param_required,
        per_alias_param_required=per_alias_param_required,
        report_param_required=report_param_required,
        report_sections=report_sections,
        orientation=orientation,
        page_size=page_size,
        static_data=static_data_dict,
    )

    # Upsert: GET ? 404 ? POST, else PUT
    try:
        existing = api_client.get(
            ConfigurationEndpoints.get_by_reference(branch_id, "report", reference_name)
        )
        config_id = existing["id"]
        api_client.put(
            ConfigurationEndpoints.update(branch_id, "report", config_id),
            data=config_dict,
        )
        action = "updated"
    except ApiError as e:
        if e.code == "DXS-404-001":
            api_client.post(
                ConfigurationEndpoints.create(branch_id, "report"),
                data=config_dict,
            )
            action = "created"
        else:
            raise

    ctx.output(single(
        item={
            "referenceName": reference_name,
            "title": title,
            "branch_id": branch_id,
            "sections": len(report_sections),
            "action": action,
        },
        semantic_key="report",
    ))


@report_data.command()
@click.argument("reference_name")
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID",
)
@pass_context
@require_auth
def get(ctx: DxsContext, reference_name: str, branch: int | None) -> None:
    """Get a report configuration by reference name.

    \\b
    Example:
        dxs report-data get rep_shipment_bol --branch 61
    """
    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    api_client = ApiClient()
    result = api_client.get(
        ConfigurationEndpoints.get_by_reference(branch_id, "report", reference_name)
    )
    ctx.output(single(item=result, semantic_key="report"))


@report_data.command(name="list")
@click.option(
    "--branch",
    "-b",
    type=int,
    default=None,
    help="Branch ID",
)
@pass_context
@require_auth
def list_reports(ctx: DxsContext, branch: int | None) -> None:
    """List all report configurations in a branch.

    \\b
    Example:
        dxs report-data list --branch 61
    """
    branch_id = branch or ctx.branch
    if not branch_id:
        raise click.UsageError("A branch is required. Use --branch or the global -b/--branch flag.")

    api_client = ApiClient()
    result = api_client.get(ConfigurationEndpoints.list_all(branch_id, "report"))
    items = result if isinstance(result, list) else result.get("value", [])
    ctx.output(list_response(items=items, semantic_key="reports"))
