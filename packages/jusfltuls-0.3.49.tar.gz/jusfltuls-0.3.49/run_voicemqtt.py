#!/usr/bin/env python3
"""Wrapper to run voicemqtt."""
from jusfltuls.voicemqtt.cli import main

if __name__ == '__main__':
    main()
