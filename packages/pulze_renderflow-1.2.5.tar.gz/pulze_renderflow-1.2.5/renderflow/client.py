"""RenderFlow API Client for Python."""

from typing import Optional, Any, Dict, List, Callable
import json
import threading
import httpx

from .models import (
    IJob, IJobTask, INode, IPool, IUser, IError, IServiceInfo,
    IPublicJobCreate, IPublicJobUpdate, RenderFlowEvent
)


def _parse_event(raw: dict) -> RenderFlowEvent:
    return RenderFlowEvent(
        type=raw.get("operationType", ""),
        document=raw.get("fullDocument") or {},
        updated=(raw.get("updateDescription") or {}).get("updatedFields"),
        time=raw.get("wallTime", 0),
    )


class EventListener:
    """Listens to SSE events in a background thread."""

    def __init__(self, url: str, headers: Dict[str, str], callback: Callable[[RenderFlowEvent], None], on_error: Optional[Callable[[Exception], None]] = None):
        self._closed = False
        self._thread = threading.Thread(target=self._run, args=(url, headers, callback, on_error), daemon=True)
        self._thread.start()

    def _run(self, url: str, headers: Dict[str, str], callback: Callable[[RenderFlowEvent], None], on_error: Optional[Callable[[Exception], None]]):
        try:
            with httpx.Client(timeout=None) as client:
                with client.stream("GET", url, headers={**headers, "Accept": "text/event-stream"}) as response:
                    response.raise_for_status()
                    buffer = ""
                    for chunk in response.iter_text():
                        if self._closed:
                            break
                        buffer += chunk
                        while "\n\n" in buffer:
                            part, buffer = buffer.split("\n\n", 1)
                            line = part.strip()
                            if not line or line.startswith(":"):
                                continue
                            for sub_line in line.split("\n"):
                                if sub_line.startswith("data: "):
                                    try:
                                        raw = json.loads(sub_line[6:])
                                        callback(_parse_event(raw))
                                    except (json.JSONDecodeError, Exception):
                                        pass
        except Exception as err:
            if not self._closed and on_error:
                on_error(err)

    def close(self):
        """Close the event listener."""
        self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class _BaseAPI:
    """Base class for API endpoints."""

    def __init__(self, client: httpx.Client, base_url: str = "", headers: Optional[Dict[str, str]] = None):
        self._client = client
        self._base_url = base_url
        self._headers = headers or {}

    def _get(self, path: str, params: Optional[Dict] = None) -> Any:
        response = self._client.get(path, params=params)
        response.raise_for_status()
        return response.json()

    def _post(self, path: str, json: Optional[Dict] = None) -> Any:
        response = self._client.post(path, json=json)
        response.raise_for_status()
        return response.json()

    def _put(self, path: str, json: Optional[Dict] = None) -> Any:
        response = self._client.put(path, json=json)
        response.raise_for_status()
        return response.json()

    def _delete(self, path: str) -> Any:
        response = self._client.delete(path)
        response.raise_for_status()
        return response.json()


class InfoAPI(_BaseAPI):
    """Service info endpoint."""

    def get(self) -> IServiceInfo:
        """Get service information."""
        return IServiceInfo.model_validate(self._get("/info"))


class JobsAPI(_BaseAPI):
    """Jobs endpoints."""

    def list(self) -> List[IJob]:
        """List all jobs."""
        data = self._get("/jobs")
        return [IJob.model_validate(j) for j in data]

    def get(self, job_id: str) -> IJob:
        """Get a job by ID."""
        return IJob.model_validate(self._get(f"/jobs/{job_id}"))

    def create(self, data: IPublicJobCreate) -> IJob:
        """Create a new job."""
        return IJob.model_validate(self._post("/jobs", json=data.model_dump(by_alias=True, exclude_none=True)))

    def update(self, job_id: str, data: IPublicJobUpdate) -> IJob:
        """Update a job."""
        return IJob.model_validate(self._put(f"/jobs/{job_id}", json=data.model_dump(by_alias=True, exclude_none=True)))

    def delete(self, job_id: str) -> Dict:
        """Delete a job."""
        return self._delete(f"/jobs/{job_id}")

    def start(self, job_id: str) -> IJob:
        """Start a job."""
        return IJob.model_validate(self._post(f"/jobs/{job_id}/start"))

    def stop(self, job_id: str) -> IJob:
        """Stop a job."""
        return IJob.model_validate(self._post(f"/jobs/{job_id}/stop"))

    def reset(self, job_id: str) -> IJob:
        """Reset a job."""
        return IJob.model_validate(self._post(f"/jobs/{job_id}/reset"))

    def archive(self, job_id: str) -> IJob:
        """Archive a job."""
        return IJob.model_validate(self._post(f"/jobs/{job_id}/archive"))

    def update_pool(self, job_id: str, pool_id: str) -> IJob:
        """Update job pool."""
        return IJob.model_validate(self._put(f"/jobs/{job_id}/pool", json={"poolId": pool_id}))

    def on(self, callback: Callable[[RenderFlowEvent], None], on_error: Optional[Callable[[Exception], None]] = None) -> EventListener:
        """Subscribe to real-time job events."""
        return EventListener(f"{self._base_url}/jobs/events", self._headers, callback, on_error)


class TasksAPI(_BaseAPI):
    """Tasks endpoints."""

    def list(self, job_id: str, page: int = 1, limit: int = 20) -> List[IJobTask]:
        """List tasks for a job."""
        data = self._get(f"/jobs/{job_id}/tasks", params={"pageInput": page, "limit": limit})
        return [IJobTask.model_validate(t) for t in data]

    def get(self, task_id: str) -> IJobTask:
        """Get a task by ID."""
        return IJobTask.model_validate(self._get(f"/tasks/{task_id}"))

    def logs(self, task_id: str, offset: int = 0, limit: int = 200) -> Dict:
        """Get task logs."""
        return self._get(f"/tasks/{task_id}/logs", params={"offset": offset, "limit": limit})

    def thumbnail(self, task_id: str) -> bytes:
        """Get task thumbnail."""
        response = self._client.get(f"/tasks/{task_id}/thumbnail")
        response.raise_for_status()
        return response.content

    def on(self, job_id: str, callback: Callable[[RenderFlowEvent], None], on_error: Optional[Callable[[Exception], None]] = None) -> EventListener:
        """Subscribe to real-time task events for a specific job."""
        return EventListener(f"{self._base_url}/tasks/events/{job_id}", self._headers, callback, on_error)


class NodesAPI(_BaseAPI):
    """Nodes endpoints."""

    def list(self) -> List[INode]:
        """List all nodes."""
        data = self._get("/nodes")
        return [INode.model_validate(n) for n in data]

    def get(self, node_id: str) -> INode:
        """Get a node by ID."""
        return INode.model_validate(self._get(f"/nodes/{node_id}"))

    def delete(self, node_id: str) -> Dict:
        """Delete a node."""
        return self._delete(f"/nodes/{node_id}")

    def update_status(self, node_id: str, status: str) -> INode:
        """Update node status."""
        return INode.model_validate(self._put(f"/nodes/{node_id}/status", json={"status": status}))

    def update_pool(self, node_id: str, pool_id: str) -> INode:
        """Update node pool."""
        return INode.model_validate(self._put(f"/nodes/{node_id}/pool", json={"poolId": pool_id}))

    def utilization(self, node_id: str) -> Dict:
        """Get node utilization."""
        return self._get(f"/nodes/{node_id}/utilization")

    def benchmarks(self, type: Optional[str] = None) -> List[Dict]:
        """Get node benchmark rankings."""
        params = {"type": type} if type else None
        return self._get("/nodes/benchmarks", params=params)

    def on(self, callback: Callable[[RenderFlowEvent], None], on_error: Optional[Callable[[Exception], None]] = None) -> EventListener:
        """Subscribe to real-time node events."""
        return EventListener(f"{self._base_url}/nodes/events", self._headers, callback, on_error)


class PoolsAPI(_BaseAPI):
    """Pools endpoints."""

    def list(self) -> List[IPool]:
        """List all pools."""
        data = self._get("/pools")
        return [IPool.model_validate(p) for p in data]

    def get(self, pool_id: str) -> IPool:
        """Get a pool by ID."""
        return IPool.model_validate(self._get(f"/pools/{pool_id}"))


class UsersAPI(_BaseAPI):
    """Users endpoints."""

    def list(self) -> List[IUser]:
        """List all users."""
        data = self._get("/users")
        return [IUser.model_validate(u) for u in data]

    def get(self, user_id: str) -> IUser:
        """Get a user by ID."""
        return IUser.model_validate(self._get(f"/users/{user_id}"))


class ErrorsAPI(_BaseAPI):
    """Errors endpoints."""

    def list(self) -> List[IError]:
        """List all errors."""
        data = self._get("/errors")
        return [IError.model_validate(e) for e in data]

    def by_job(self, job_id: str) -> List[IError]:
        """Get errors for a job."""
        data = self._get(f"/errors/job/{job_id}")
        return [IError.model_validate(e) for e in data]

    def by_node(self, node_id: str) -> List[IError]:
        """Get errors for a node."""
        data = self._get(f"/errors/node/{node_id}")
        return [IError.model_validate(e) for e in data]


class RenderFlow:
    """RenderFlow API client."""

    def __init__(
        self,
        base_url: str = "http://localhost:44442/api/v1",
        api_key: Optional[str] = None,
        timeout: float = 30.0,
    ):
        headers = {}
        if api_key:
            headers["x-renderflow-api-key"] = api_key

        self._client = httpx.Client(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
        )

        self.info = InfoAPI(self._client, base_url, headers)
        self.jobs = JobsAPI(self._client, base_url, headers)
        self.tasks = TasksAPI(self._client, base_url, headers)
        self.nodes = NodesAPI(self._client, base_url, headers)
        self.pools = PoolsAPI(self._client, base_url, headers)
        self.users = UsersAPI(self._client, base_url, headers)
        self.errors = ErrorsAPI(self._client, base_url, headers)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._client.close()

    def close(self):
        """Close the HTTP client."""
        self._client.close()
