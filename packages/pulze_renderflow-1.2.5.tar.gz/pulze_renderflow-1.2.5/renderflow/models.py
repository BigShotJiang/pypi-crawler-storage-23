"""Generated models from OpenAPI spec. Do not edit manually."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# Type alias for MongoDB ObjectId
ObjectId = str


class TaskType(str, Enum):
    renderflow_test = "renderflow.test"
    _3dsmax_render = "3dsmax.render"
    _3dsmax_scene_manager_render = "3dsmax.scene_manager.render"
    _3dsmax_export = "3dsmax.export"
    _3dsmax_phoenix_simulate = "3dsmax.phoenix.simulate"
    _3dsmax_tyflow_simulate = "3dsmax.tyflow.simulate"
    _3dsmax_preview = "3dsmax.preview"
    _3dsmax_script = "3dsmax.script"
    _3dsmax_bake = "3dsmax.bake"
    arnold_render = "arnold.render"
    after_render = "after.render"
    blender_render = "blender.render"
    cinema4d_render = "cinema4d.render"
    corona_image_editor = "corona_image_editor"
    corona_dr = "corona.dr"
    houdini_render = "houdini.render"
    keyshot_render = "keyshot.render"
    ffmpeg = "ffmpeg"
    imager = "imager"
    fusion_render = "fusion.render"
    maya_render = "maya.render"
    nuke_render = "nuke.render"
    photoshop = "photoshop"
    powershell = "powershell"
    python = "python"
    revit_export = "revit.export"
    rhino_export = "rhino.export"
    sketchup_export = "sketchup.export"
    topaz_video = "topaz_video"
    unreal = "unreal"
    vantage_render = "vantage.render"
    vray_dr = "vray.dr"
    vray_dr_spawner = "vray.dr.spawner"
    vray_standalone = "vray_standalone"

class JobEnv(str, Enum):
    local = "local"
    cloud = "cloud"

class JobPropType(str, Enum):
    file_input = "file.input"
    file_browser = "file.browser"
    multi_file_input = "multi.file.input"
    resolution = "resolution"
    camera = "camera"
    frame = "frame"
    tiled = "tiled"
    image_output = "image.output"
    render_settings = "render.settings"
    config = "config"
    name = "name"
    distributed = "distributed"
    phoenix = "phoenix"
    tyflow = "tyflow"
    imager = "imager"
    corona_image_editor = "corona.image-editor"
    script_file = "script.file"
    script_snippet = "script.snippet"
    preview = "preview"
    export = "export"
    ffmpeg_command = "ffmpeg.command"
    ffmpeg_convert_sequence = "ffmpeg.convert-sequence"
    topaz_video = "topaz.video"
    scene_manager = "scene-manager"
    args = "args"

class JobCallbackType(str, Enum):
    post_setup = "post-setup"
    pre_render = "pre-render"
    pre_frame = "pre-frame"
    post_frame = "post-frame"
    post_render = "post-render"

class JobPropCategory(str, Enum):
    _0 = "0"
    _1 = "1"

class Status(str, Enum):
    working = "working"
    finishing = "finishing"
    pending = "pending"
    preparing = "preparing"
    failed = "failed"
    archived = "archived"
    suspended = "suspended"
    scheduled = "scheduled"
    queued = "queued"
    completed = "completed"
    disabled = "disabled"
    unknown = "unknown"

class DistributionOrder(str, Enum):
    pool_priority_date = "pool_priority_date"
    pool_priority_balanced = "pool_priority_balanced"

class NodeType(str, Enum):
    monitor = "monitor"
    node = "node"
    workstation = "workstation"
    server = "server"
    test = "test"

class NodeStatus(str, Enum):
    offline = "offline"
    loading = "loading"
    reserved = "reserved"
    suspended = "suspended"
    idle = "idle"
    busy = "busy"
    finishing = "finishing"
    error = "error"

class SoftwareId(str, Enum):
    _3dsmax = "3dsmax"
    after = "after"
    arnold = "arnold"
    blender = "blender"
    chaos_cloud = "chaos_cloud"
    cinema4d = "cinema4d"
    corona_image_editor = "corona_image_editor"
    fusion = "fusion"
    fusion_render_node = "fusion_render_node"
    houdini = "houdini"
    keyshot = "keyshot"
    maya = "maya"
    nuke = "nuke"
    powershell = "powershell"
    photoshop = "photoshop"
    python = "python"
    revit = "revit"
    rhino = "rhino"
    topaz_video = "topaz_video"
    sketchup = "sketchup"
    vray = "vray"
    vray_standalone = "vray_standalone"
    vray_standalone_spawner = "vray_standalone_spawner"
    vantage = "vantage"
    ffmpeg = "ffmpeg"
    unreal = "unreal"
    renderflow = "renderflow"
    scene_manager = "scene_manager"

class SpawnerType(str, Enum):
    corona = "corona"
    vray = "vray"

class SoftwareType(str, Enum):
    host = "host"
    engine = "engine"
    plugin = "plugin"
    system = "system"
    utils = "utils"

class BenchmarkType(str, Enum):
    blender = "blender"
    cpuz = "cpuz"
    cinebench = "cinebench"
    corona = "corona"
    fstorm = "fstorm"
    custom_max = "custom-max"
    octane = "octane"
    phoenix = "phoenix"
    redshift = "redshift"
    vray = "vray"
    vray_gpu_cuda = "vray-gpu-cuda"
    vray_gpu_rtx = "vray-gpu-rtx"
    y_cruncher = "y-cruncher"

class ErrorLevel(str, Enum):
    info = "info"
    warning = "warning"
    critical = "critical"
    fatal = "fatal"

class ErrorNotificationType(str, Enum):
    none = "none"
    owner = "owner"
    admin = "admin"
    group = "group"
    pool = "pool"
    all = "all"

class ReqCategory(str, Enum):
    _0 = "0"
    _1 = "1"
    _2 = "2"
    _3 = "3"

class HardwareType(str, Enum):
    cpu = "cpu"
    gpu = "gpu"
    ram = "ram"
    storage = "storage"

class AssetType(str, Enum):
    _0 = "0"
    _1 = "1"
    _2 = "2"
    _99 = "99"

class ValidationLevel(str, Enum):
    _0 = "0"
    _1 = "1"
    _2 = "2"
    _3 = "3"

class JobStepIOType(str, Enum):
    image_single = "image.single"
    image_sequence = "image.sequence"

class JobNodeStatus(str, Enum):
    blocked = "blocked"
    required = "required"
    waiting = "waiting"
    active = "active"
    failed = "failed"
    completed = "completed"

class ForceFinish(str, Enum):
    _0 = "0"
    _1 = "1"
    _2 = "2"

class JobPriority(str, Enum):
    _0 = "0"
    _25 = "25"
    _50 = "50"
    _75 = "75"
    _100 = "100"

class CleanupType(str, Enum):
    none = "none"
    delete = "delete"
    archive = "archive"

class NotificationChannel(str, Enum):
    mobile = "mobile"
    desktop = "desktop"
    email = "email"
    webhook = "webhook"
    slack = "slack"
    teams = "teams"
    discord = "discord"

class NotificationType(str, Enum):
    job_completed = "job-completed"
    job_error = "job-error"

class AssetState(str, Enum):
    _0 = "0"
    _1 = "1"
    _2 = "2"
    _3 = "3"
    _4 = "4"
    _5 = "5"

class ChargeStatus(str, Enum):
    success = "success"
    failed = "failed"

class EngineId(str, Enum):
    arnold = "arnold"
    corona = "corona"
    fstorm = "fstorm"
    redshift = "redshift"
    vray = "vray"


class IDevice(BaseModel):
    id: str
    device_id: str
    name: str
    manufacturer: str
    model: str
    platform: str
    fcm_token: str | None = None


class IUser(BaseModel):
    id: str
    field_id: ObjectId = Field(alias="_id")
    principal: str
    name: str
    alias: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    role: str | None = None
    email: str | None = None
    password: str | None = None
    avatar: str | None = None
    group_id: ObjectId | None = None
    created_at: float
    updated_at: float
    devices: list[IDevice]
    field_schemaVersion: float = Field(alias="_schemaVersion")


class IJobProp(BaseModel):
    id: str | None = None
    type: JobPropType
    name: str
    value: Any
    props: Any
    callback: JobCallbackType | None = None
    category: JobPropCategory | None = None
    v: float | None = None


class IProgress(BaseModel):
    elapsed_time: float
    remaining_time: float
    total_render_time: float | None = None
    average_time: float | None = None
    percent: float
    info: str


class IJobTaskThumbnail(BaseModel):
    path: str
    updated_at: float


class IResult(BaseModel):
    type: str


class IJobTask(BaseModel):
    id: str
    field_id: ObjectId = Field(alias="_id")
    index: float
    account_id: ObjectId | None = None
    node_id: ObjectId | None = None
    job_id: ObjectId
    step_id: ObjectId
    type: TaskType
    env: JobEnv | None = None
    props: list[IJobProp]
    status: Status
    progress: IProgress
    thumbnail: IJobTaskThumbnail | None = None
    result: IResult | None = None
    started_at: float | None = None
    finished_at: float | None = None
    helper: bool
    field_schemaVersion: float = Field(alias="_schemaVersion")


class IPool(BaseModel):
    field_id: ObjectId = Field(alias="_id")
    name: str
    color: str
    icon: str
    description: str
    priority: float
    node_limit: float
    order: DistributionOrder
    readonly: bool
    created_at: float


class INodeJob(BaseModel):
    field_id: ObjectId = Field(alias="_id")
    step_id: ObjectId
    tasks: list[ObjectId]


class INodeSpawner(BaseModel):
    job_id: ObjectId | None = None
    soft_id: SoftwareId
    version: str
    type: SpawnerType
    status: Status


class IOperatingSystem(BaseModel):
    platform: str
    distro: str
    release: str
    build: str


class ICpu(BaseModel):
    manufacturer: str
    brand: str
    speed: float
    cores: float
    physical: float
    processors: float
    utilization: float | None = None
    temperature: float | None = None


class IGpu(BaseModel):
    id: float
    vendor: str
    model: str
    vram: float | None = None
    utilization: float | None = None
    temperature: float | None = None


class IRamModule(BaseModel):
    index: float
    manufacturer: str | None = None
    type: str
    speed: float | None = None


class IRam(BaseModel):
    total: float
    free: float
    used: float | None = None
    layout: list[IRamModule]


class ISystem(BaseModel):
    manufacturer: str
    model: str
    virtual: bool


class IDrive(BaseModel):
    id: float
    name: str | None = None
    local: str
    remote: str | None = None


class ISystemDrive(BaseModel):
    mount: str
    total: float
    free: float
    used: float | None = None


class INetwork(BaseModel):
    ip: str
    mac: str
    default: bool
    speed: float | None = None
    type: str
    name: str
    internal: bool
    virtual: bool


class IHardware(BaseModel):
    field_id: ObjectId | None = Field(default=None, alias="_id")
    node_id: ObjectId | None = None
    os: IOperatingSystem | None = None
    cpu: ICpu | None = None
    gpu: list[IGpu]
    ram: IRam | None = None
    system: ISystem | None = None
    drives: list[IDrive]
    system_drive: ISystemDrive | None = None
    network: list[INetwork]
    uptime: float | None = None
    work_threads: float


class IPaths(BaseModel):
    name: str
    value: str | list[str] | None = None


class ISoftware(BaseModel):
    field_id: ObjectId | None = Field(default=None, alias="_id")
    node_id: ObjectId | None = None
    soft_id: SoftwareId | str
    name: str
    version: str
    display_version: str
    type: SoftwareType
    paths: list[IPaths] | None = None
    plugins: list[ISoftware] | None = None


class IBenchmarkResult(BaseModel):
    node_id: ObjectId
    type: BenchmarkType
    version: str | None = None
    date: float
    value: Any
    guess: bool | None = None


class IError(BaseModel):
    id: str
    field_id: ObjectId = Field(alias="_id")
    tag: str
    level: ErrorLevel
    title: str
    notify: ErrorNotificationType
    detail: str | None = None
    help: Any | None = None
    node_id: ObjectId
    account_id: ObjectId | None = None
    job_id: ObjectId | None = None
    step_id: ObjectId | None = None
    task_id: ObjectId | None = None
    count: float
    created_at: float
    updated_at: float
    deleted_at: float | None = None


class INodeUser(BaseModel):
    id: str
    name: str
    alias: str | None = None


class INode(BaseModel):
    id: str
    field_id: ObjectId = Field(alias="_id")
    system_id: str
    name: str
    alias: str | None = None
    color: str
    pool_id: ObjectId | None = None
    group_id: ObjectId | None = None
    tags: list[str]
    type: NodeType
    user_id: ObjectId | None = None
    license: ObjectId | None = None
    status: NodeStatus
    info: str
    alive: float
    last_seen: float | None = None
    version: str | None = None
    job: INodeJob | None = None
    spawner: INodeSpawner | None = None
    idle_since: float | None = None
    hardware: IHardware | None = None
    software: list[ISoftware] | None = None
    benchmarks: list[IBenchmarkResult] | None = None
    errors: list[IError] | None = None
    user: INodeUser | None = None


class IReq(BaseModel):
    id: str
    enabled: bool
    category: ReqCategory
    category_type: SoftwareType | HardwareType | AssetType
    value: Any
    validation_level: ValidationLevel | None = None


class IJobStepIOProps(BaseModel):
    width: float | None = None
    height: float | None = None
    fps: float | None = None
    start_frame: float | None = None
    end_frame: float | None = None
    frame_step: float | None = None
    digits: float | None = None
    pattern: str | None = None
    original: str
    display: str
    basename: str
    folder: str
    extension: str


class IJobStepIO(BaseModel):
    id: str
    prop_index: float
    name: str
    type: JobStepIOType
    value: str
    props: IJobStepIOProps | None = None


class IJobNode(BaseModel):
    id: ObjectId
    node_id: ObjectId
    name: str
    status: JobNodeStatus
    attempts: float


class IJobTaskInfo(BaseModel):
    step: float
    order: float
    all_list: str
    pending_list: str
    suspended_list: str
    working_list: str
    completed_list: str
    failed_list: str
    all_count: float
    pending_count: float
    suspended_count: float
    working_count: float
    completed_count: float
    failed_count: float


class IJobStepSettings(BaseModel):
    limit: float
    maximum: float
    fixed_limit: bool
    max_batch_size: float
    force_finish: ForceFinish
    timeout: float
    max_attempts: float
    wait_for_previous: bool
    resumable: bool


class IJobStep(BaseModel):
    id: str
    field_id: ObjectId = Field(alias="_id")
    index: float
    name: str
    type: TaskType
    reqs: list[IReq]
    props: list[IJobProp]
    output: list[IJobStepIO]
    nodes: list[IJobNode]
    whitelisted_nodes: list[str]
    task_info: IJobTaskInfo
    settings: IJobStepSettings
    tasks: list[IJobTask] | list[ObjectId] | list[str]
    progress: IProgress


class IDependency(BaseModel):
    id: str
    job_id: str
    resolved: bool
    type: str | None = None
    key: str | None = None
    value: Any | None = None


class IMetadata(BaseModel):
    id: str
    label: str
    value: str | float
    type: str
    icon: str


class ICleanup(BaseModel):
    type: CleanupType
    delay: float


class INotification(BaseModel):
    id: str
    enabled: bool
    channel: NotificationChannel
    type: NotificationType
    label: str
    value: str


class IAsset(BaseModel):
    id: str
    type: str
    source: str
    filepath: str
    filename: str
    target_filename: str | None = None
    retarget: bool | None = None
    state: AssetState
    size: float
    hash: str


class ICharge(BaseModel):
    transaction_id: str | None = None
    amount: float
    task_id: str
    frame: float
    node_id: str | None = None
    created_at: float
    status: ChargeStatus


class IJob(BaseModel):
    id: str
    field_id: ObjectId = Field(alias="_id")
    user_id: ObjectId | None = None
    account_id: ObjectId | None = None
    team_id: ObjectId | None = None
    name: str
    env: JobEnv
    icon: str | None = None
    description: str
    thumbnail: str | None = None
    color: str | None = None
    tags: list[str]
    pool_id: ObjectId
    group_id: ObjectId
    storage_id: ObjectId
    status: Status
    steps: list[IJobStep]
    priority: JobPriority | float
    dependencies: list[IDependency]
    metadata: list[IMetadata]
    progress: IProgress
    cleanup: ICleanup
    notifications: list[INotification]
    assets: list[IAsset]
    errors: list[IError] | None = None
    charges: list[ICharge] | None = None
    schedule_date: float | None = None
    created_at: float | None = None
    started_at: float | None = None
    finished_at: float | None = None
    removed_at: float | None = None
    archived_at: float | None = None
    field_schemaVersion: float = Field(alias="_schemaVersion")


class ISoftwareValue(BaseModel):
    id: SoftwareId
    name: str
    version: str


class IEngineValue(BaseModel):
    id: EngineId
    name: str
    version: str


class IPluginValue(BaseModel):
    id: str
    name: str
    version: str


class IJobPropOutputValue(BaseModel):
    type: float
    enabled: bool
    path: str


class IPublicJobCreate(BaseModel):
    name: str
    file: str
    type: TaskType
    status: str
    host: ISoftwareValue
    engine: IEngineValue | None = None
    plugins: list[IPluginValue] | None = None
    resolution: str | None = None
    output: list[IJobPropOutputValue] | None = None
    frame: str | None = None
    pool_id: str | None = None
    priority: float | None = None
    dependencies: list[str] | None = None
    nodes: list[str] | None = None


class IPublicJobUpdate(BaseModel):
    priority: float | None = None
    limit: float | None = None
    max_batch_size: float | None = None
    whitelisted_nodes: list[str] | None = None


class IAccount(BaseModel):
    id: str
    name: str
    nickname: str
    picture: str
    updated_at: str


class IServiceInfo(BaseModel):
    node_id: str | None = None
    version: str | None = None
    build_type: str | None = None
    node_type: NodeType
    platform: str
    hostname: str
    account: IAccount | None = None
