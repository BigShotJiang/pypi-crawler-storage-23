# Publishing qorm to PyPI

## Prerequisites

```bash
pip install build twine
```

## Build

```bash
python -m build
```

Creates `dist/qorm-<version>.tar.gz` and `dist/qorm-<version>-py3-none-any.whl`.

## Upload

```bash
python -m twine upload dist/*
```

- Username: `__token__`
- Password: your PyPI API token

## Version bump

1. Update `version` in `pyproject.toml`
2. Commit and push
3. Clean old builds: `rm -rf dist/`
4. Build: `python -m build`
5. Upload: `python -m twine upload dist/*`

## Test PyPI (dry run)

```bash
python -m twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ qorm
```
