"""qorm — Python ORM for q/kdb+.

Usage::

    from qorm import Model, Engine, Session, Symbol, Float, Long, Timestamp, avg_, aj

    class Trade(Model):
        __tablename__ = 'trade'
        sym: Symbol
        price: Float
        size: Long
        time: Timestamp

    engine = Engine(host="localhost", port=5000)

    with Session(engine) as session:
        session.create_table(Trade)
        result = session.exec(
            Trade.select(Trade.sym, avg_price=avg_(Trade.price))
                 .where(Trade.price > 100)
                 .by(Trade.sym)
        )
        for row in result:
            print(row.sym, row.avg_price)
"""

from .types import (
    Boolean, Guid, Byte, Short, Int, Long,
    Real, Float, Char, Symbol,
    Timestamp, Month, Date, DateTime,
    Timespan, Minute, Second, Time,
    List,
    QType, QTypeCode, QNull,
    q_list,
    q_boolean, q_guid, q_byte, q_short, q_int, q_long,
    q_real, q_float, q_char, q_symbol, q_timestamp, q_month,
    q_date, q_datetime, q_timespan, q_minute, q_second, q_time,
    infer_qtype, is_null,
)
from .model.base import Model
from .model.keyed import KeyedModel
from .model.fields import Field, field
from .model.reflect import build_model_from_meta
from .engine import Engine
from .session import Session, AsyncSession, ModelResultSet
from .registry import EngineRegistry, EngineGroup
from .rpc import QFunction, q_api
from .query.expressions import (
    Expr, Column, Literal, BinOp, AggFunc,
    FbyExpr, EachExpr, _QSentinel,
    avg_, sum_, min_, max_, count_, first_, last_, med_, dev_, var_,
    xbar_, today_, now_,
    fby_,
    each_, peach_,
)
from .query.select import SelectQuery
from .query.update import UpdateQuery
from .query.delete import DeleteQuery
from .query.insert import InsertQuery
from .query.exec_ import ExecQuery
from .query.joins import aj, lj, ij, wj
from .pagination import paginate, async_paginate
from .retry import RetryPolicy
from .config import load_config, engines_from_config, group_from_config
from .connection.sync_conn import SyncConnection
from .connection.async_conn import AsyncConnection
from .connection.pool import SyncPool, AsyncPool
from .subscription import Subscriber
from .exc import (
    QormError, ConnectionError, HandshakeError, AuthenticationError,
    SerializationError, DeserializationError, QueryError, QError,
    ModelError, SchemaError, PoolError, PoolExhaustedError,
    EngineNotFoundError, ReflectionError,
    QNSError, QNSConfigError, QNSRegistryError, QNSServiceNotFoundError,
)
from .qns import QNS, ServiceInfo

__version__ = "0.1.0"

__all__ = [
    # Core
    'Model', 'KeyedModel', 'Field', 'field',
    'Engine', 'Session', 'AsyncSession', 'ModelResultSet',
    'EngineRegistry', 'EngineGroup',
    'QFunction', 'q_api',
    'build_model_from_meta',
    'Subscriber',
    # Types
    'Boolean', 'Guid', 'Byte', 'Short', 'Int', 'Long',
    'Real', 'Float', 'Char', 'Symbol',
    'Timestamp', 'Month', 'Date', 'DateTime',
    'Timespan', 'Minute', 'Second', 'Time',
    'List',
    'QType', 'QTypeCode', 'QNull',
    'infer_qtype', 'is_null',
    # Queries
    'Expr', 'Column', 'Literal', 'BinOp', 'AggFunc',
    'SelectQuery', 'UpdateQuery', 'DeleteQuery', 'InsertQuery',
    'ExecQuery',
    'avg_', 'sum_', 'min_', 'max_', 'count_', 'first_', 'last_',
    'med_', 'dev_', 'var_',
    'xbar_', 'today_', 'now_',
    'fby_', 'FbyExpr',
    'each_', 'peach_', 'EachExpr',
    'aj', 'lj', 'ij', 'wj',
    # Pagination
    'paginate', 'async_paginate',
    # Retry
    'RetryPolicy',
    # Config
    'load_config', 'engines_from_config', 'group_from_config',
    # Connections
    'SyncConnection', 'AsyncConnection', 'SyncPool', 'AsyncPool',
    # Exceptions
    'QormError', 'ConnectionError', 'HandshakeError', 'AuthenticationError',
    'SerializationError', 'DeserializationError', 'QueryError', 'QError',
    'ModelError', 'SchemaError', 'PoolError', 'PoolExhaustedError',
    'EngineNotFoundError', 'ReflectionError',
    'QNSError', 'QNSConfigError', 'QNSRegistryError', 'QNSServiceNotFoundError',
    # QNS
    'QNS', 'ServiceInfo',
]
