"""Claude Storm - Dual-agent brainstorming system using Claude Code CLI sessions."""

from __future__ import annotations

from importlib.metadata import version

__version__ = version("claude-storm")
