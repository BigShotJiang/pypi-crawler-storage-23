"""Entry point for python -m claude_storm."""

from __future__ import annotations

from claude_storm.cli import app

app()
