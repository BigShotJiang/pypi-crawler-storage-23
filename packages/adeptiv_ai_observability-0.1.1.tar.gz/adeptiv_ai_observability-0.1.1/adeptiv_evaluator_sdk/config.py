class SDKConfig:
    api_key: str = None
    project_name = "adeptiv-AI"
    otlp_endpoint = "https://c6phw2so4i.execute-api.ap-south-1.amazonaws.com"
    otlp_api_key: str = "gz9vj5RGRiB80PWQ3Tem3fVUU5vVrLZ8KagAlVGi"
    redact = True

config = SDKConfig()