# Adeptiv GenAI Tracing SDK

**Adeptiv GenAI** is a lightweight, vendor-neutral **OpenTelemetry tracing SDK** for **LLMs, agents, and AI workflows**.

It captures **latency, execution flow, hashes, and metadata** for all AI use cases.

---

## Key Features

- **Trace-only observability** (no response normalization)
- Works with **any LLM** (OpenAI, Anthropic, Gemini, local models)
- Supports **chat, summarization, agents, tools, RAG**
- **Sync & async** compatible
- **Enterprise-safe** (hashing, redaction, previews)
- **OpenTelemetry compatible**

This ensures **zero lock-in** and **maximum compatibility**.

---

## Installation

```bash
pip install adeptiv-evaluator-sdk
```

---

## Quick Start

### Configuration

```python
from adeptiv_evaluator_sdk import config

# SDK configuration
config.api_key = "your-api-key-here"  # Required: Your Adeptiv API key
```

---

## Usage Examples

### Tracing an LLM Call

```python
from adeptiv_evaluator_sdk import trace_llm, config

# Configure SDK
config.api_key = "your-api-key-here"

@trace_llm(name="chat_completion", model="gpt-4o", operation="chat")
def chat(prompt):
    # Your LLM call here (OpenAI, Anthropic, LiteLLM, etc.)
    return llm.invoke(prompt)

result = chat("Hello world")
```

### Tracing an Agent (Sync)

```python
from adeptiv_evaluator_sdk import trace_agent, config

# Configure SDK
config.api_key = "your-api-key-here"

@trace_agent(agent_name="support_agent", model="gpt-4o")
def run_agent(query):
    # Your agent logic here
    return process_query(query)

result = run_agent("How can I help you?")
```

### Tracing an Agent (Async)

```python
from adeptiv_evaluator_sdk import trace_agent, config

# Configure SDK
config.api_key = "your-api-key-here"

@trace_agent(agent_name="support_agent", model="gpt-4o")
async def run_agent(query):
    # Your async agent logic here
    return await agent.run(query)

result = await run_agent("How can I help you?")
```

### Multi-Agent Workflow

```python
from adeptiv_evaluator_sdk import trace_agent, config

config.api_key = "your-api-key-here"

@trace_agent(agent_name="planner", model="gpt-4o-mini")
def planner_agent(question: str):
    return f"Plan to answer: {question}"

@trace_agent(agent_name="researcher", model="gpt-4o-mini")
def researcher_agent(question: str):
    return f"Research notes about: {question}"

@trace_agent(agent_name="writer", model="gpt-4o-mini")
def writer_agent(research_output: str):
    return f"Final answer based on: {research_output}"

# Execute workflow
question = "What is an LLM?"
plan = planner_agent(question)
research = researcher_agent(question)
answer = writer_agent(research)
```

