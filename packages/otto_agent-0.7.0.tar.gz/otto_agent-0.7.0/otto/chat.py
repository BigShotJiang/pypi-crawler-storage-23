from __future__ import annotations

import asyncio
import fnmatch
import logging
import os
import re
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, Protocol

from otto.agent import run
from otto.auth import AuthStorage
from otto.config import OTTO_HOME, Config, save_config
from otto.gateway import Gateway
from otto.memory import Memory
from otto.prompts import (
    IDENTITY_KEY,
    build_system_prompt,
)
from otto.scheduler import Scheduler
from otto.sessions import SessionStore
from otto.skills import BUILTIN_SKILLS_DIR, discover
from otto.tools import create_session_tools

# Reverse of auth/registry._PREFIX_MAP: litellm_provider -> otto_prefix
_OTTO_PREFIX_MAP: dict[str, str] = {
    "anthropic": "claude-code",
    "vertex_ai": "gemini-cli",
    "google": "gemini-cli",
}

_DEFAULT_MODEL_PATTERNS: list[str] = [
    "claude-sonnet-*",
    "claude-haiku-*",
    "gpt-4o*",
    "gemini-2.5*",
]

_MAX_PICKER_MODELS = 20

_PROVIDER_DISPLAY_NAMES: dict[str, str] = {
    "claude-code": "Anthropic",
    "openai": "OpenAI",
    "gemini-cli": "Google",
    "vertex_ai": "Google",
    "google": "Google",
}

# Maps otto model prefix → (auth_storage provider key, env var to check).
_PROVIDER_AUTH_CHECK: dict[str, tuple[str, str | None]] = {
    "claude-code": ("anthropic", "ANTHROPIC_API_KEY"),
    "openai": ("openai", "OPENAI_API_KEY"),
    "gemini-cli": ("google", "GOOGLE_API_KEY"),
}


def _active_provider_prefixes(auth_storage: AuthStorage | None) -> set[str] | None:
    """Return the set of otto model prefixes with active credentials.

    Checks both OAuth credentials in auth_storage and environment variables.
    Returns None if detection is unavailable (no auth_storage and no env vars),
    meaning all providers should be shown.
    """
    active: set[str] = set()
    for prefix, (auth_key, env_var) in _PROVIDER_AUTH_CHECK.items():
        if auth_storage and auth_storage.get_credentials(auth_key):
            active.add(prefix)
        elif env_var and os.environ.get(env_var):
            active.add(prefix)
    # Also include prefixless models (e.g. bare "gpt-4o") if openai is active.
    if "openai" in active:
        active.add("")
    return active if active else None


def _to_otto_model_id(litellm_key: str) -> str:
    """Convert a litellm model key to an Otto-prefixed model identifier."""
    if "/" in litellm_key:
        provider, model = litellm_key.split("/", 1)
    else:
        provider, model = "", litellm_key
    otto_prefix = _OTTO_PREFIX_MAP.get(provider)
    if otto_prefix:
        return f"{otto_prefix}/{model}"
    return litellm_key


def _make_display_name(model_key: str) -> str:
    """Build a human-readable display name from a litellm model key."""
    # Strip provider prefix
    if "/" in model_key:
        _, name = model_key.split("/", 1)
    else:
        name = model_key
    # Remove date suffixes like -20250514
    name = re.sub(r"-\d{8}$", "", name)
    # Replace hyphens with spaces, titlecase
    return name.replace("-", " ").replace("_", " ").title()


def _dedup_base_name(key: str) -> str:
    """Return the base name without dated suffix for dedup grouping."""
    if "/" in key:
        _, name = key.split("/", 1)
    else:
        name = key
    return re.sub(r"-\d{8}$", "", name)


def _build_model_presets(model_list: list[str]) -> list[tuple[str, str]]:
    """Build model presets dynamically from litellm's model registry.

    Returns a list of (display_name, otto_model_id) tuples.
    """
    try:
        import litellm
    except ImportError:
        return []

    patterns = model_list if model_list else _DEFAULT_MODEL_PATTERNS
    all_keys = list(litellm.model_cost.keys())

    # Filter keys matching any pattern
    matched: list[str] = []
    for key in all_keys:
        # Match against the model name part (without provider prefix)
        if "/" in key:
            _, model_part = key.split("/", 1)
        else:
            model_part = key
        for pattern in patterns:
            if fnmatch.fnmatch(model_part, pattern) or fnmatch.fnmatch(key, pattern):
                matched.append(key)
                break

    # Deduplicate: for models with dated versions, keep only the latest
    base_groups: dict[str, list[str]] = {}
    for key in matched:
        base = _dedup_base_name(key)
        base_groups.setdefault(base, []).append(key)

    deduped: list[str] = []
    for group in base_groups.values():
        # Sort to get the latest date suffix last; pick it
        group.sort()
        deduped.append(group[-1])

    # Build display name + otto ID pairs
    results: list[tuple[str, str]] = []
    for key in deduped:
        display = _make_display_name(key)
        otto_id = _to_otto_model_id(key)
        results.append((display, otto_id))

    # Sort by provider then display name
    def _sort_key(item: tuple[str, str]) -> tuple[str, str]:
        otto_id = item[1]
        if "/" in otto_id:
            provider, _ = otto_id.split("/", 1)
        else:
            provider = ""
        return (provider, item[0])

    results.sort(key=_sort_key)

    return results[:_MAX_PICKER_MODELS]


def _group_presets_by_provider(
    presets: list[tuple[str, str]],
    active_prefixes: set[str] | None = None,
) -> dict[str, list[tuple[str, str]]]:
    """Group model presets by provider prefix extracted from otto_model_id.

    When *active_prefixes* is provided, only models whose prefix is in the set
    are included.  When ``None``, all models are shown.

    Returns a dict mapping display provider name to list of (label, model_id) tuples.
    """
    groups: dict[str, list[tuple[str, str]]] = {}
    for label, otto_id in presets:
        if "/" in otto_id:
            prefix = otto_id.split("/", 1)[0]
        else:
            prefix = ""
        if active_prefixes is not None and prefix not in active_prefixes:
            continue
        display_name = _PROVIDER_DISPLAY_NAMES.get(prefix)
        if display_name is None:
            display_name = prefix.title() if prefix else "Other"
        groups.setdefault(display_name, []).append((label, otto_id))
    return groups


def _provider_key_from_otto_id(otto_id: str) -> str:
    """Extract the raw provider prefix from an otto model id."""
    if "/" in otto_id:
        return otto_id.split("/", 1)[0]
    return ""


def _resolve_provider_filter(
    arg: str, grouped: dict[str, list[tuple[str, str]]]
) -> tuple[str, list[tuple[str, str]]] | None:
    """Match a user argument to a provider (case-insensitive).

    Checks against both display names and raw provider keys.
    Returns (display_name, models) or None if no match.
    """
    lower = arg.lower()
    # Check display names first
    for display_name, models in grouped.items():
        if display_name.lower() == lower:
            return display_name, models
    # Check raw provider keys
    for key, display_name in _PROVIDER_DISPLAY_NAMES.items():
        if key.lower() == lower and display_name in grouped:
            return display_name, grouped[display_name]
    return None


def build_provider_picker(
    config: Config,
    auth_storage: AuthStorage | None = None,
) -> tuple[str, list[list[tuple[str, str]]]]:
    """Return (text, buttons) for the provider picker view.

    Used by telegram.py for the top-level /model callback.
    When auth_storage is provided, only providers with active credentials are shown.
    """
    current = config.agent.model
    presets = _build_model_presets(config.agent.model_list)
    if not presets:
        presets = [
            ("Claude Sonnet", "claude-code/claude-sonnet-4-5-20250514"),
            ("Claude Haiku", "claude-code/claude-haiku-4-5-20251001"),
            ("GPT-4o", "gpt-4o"),
            ("GPT-4o Mini", "gpt-4o-mini"),
        ]
    active = _active_provider_prefixes(auth_storage)
    grouped = _group_presets_by_provider(presets, active_prefixes=active)
    # Build provider key -> display name mapping for buttons
    # Use the first model's prefix as the provider key
    provider_items: list[tuple[str, str]] = []
    for display_name, models in grouped.items():
        key = _provider_key_from_otto_id(models[0][1])
        provider_items.append((key, display_name))

    text = f"**Current Model**\n{current}\n\nSelect a provider:"
    buttons = [[(display_name, f"model:provider:{key}")] for key, display_name in provider_items]
    buttons.append([("Custom...", "model:custom"), ("Cancel", "model:cancel")])
    return text, buttons


def get_provider_model_buttons(
    config: Config, provider_key: str
) -> tuple[str, list[list[tuple[str, str]]]]:
    """Return (text, buttons) for a provider's model list.

    Used by telegram.py callback handler for provider drilldown.
    """
    presets = _build_model_presets(config.agent.model_list)
    if not presets:
        presets = [
            ("Claude Sonnet", "claude-code/claude-sonnet-4-5-20250514"),
            ("Claude Haiku", "claude-code/claude-haiku-4-5-20251001"),
            ("GPT-4o", "gpt-4o"),
            ("GPT-4o Mini", "gpt-4o-mini"),
        ]
    # Filter to models matching the provider key
    filtered = [
        (label, mid) for label, mid in presets if _provider_key_from_otto_id(mid) == provider_key
    ]
    display_name = _PROVIDER_DISPLAY_NAMES.get(provider_key, provider_key.title() or "Other")
    if not filtered:
        text = f"No models found for {display_name}."
        buttons: list[list[tuple[str, str]]] = [[("« Back", "model:back")]]
        return text, buttons
    text = f"**{display_name} Models**\n\nSelect a model:"
    buttons = [
        [(label, f"model:{model_id}") for label, model_id in filtered[i : i + 2]]
        for i in range(0, len(filtered), 2)
    ]
    buttons.append([("« Back", "model:back"), ("Cancel", "model:cancel")])
    return text, buttons


class Renderer(Protocol):
    output_format: str

    def on_text(self, chunk: str) -> None:
        """Receive a streaming text chunk."""
        ...

    def on_tool_start(self, name: str, args: dict) -> None:
        """Handle tool execution start."""
        ...

    def on_tool_end(self, name: str, result: str) -> None:
        """Handle tool execution completion."""
        ...

    async def send_text(self, text: str) -> None:
        """Send a complete text message."""
        ...

    async def send_with_buttons(self, text: str, buttons: list[list[tuple[str, str]]]) -> None:
        """Send text with optional inline buttons. buttons: list of rows, each row is list of (label, callback_data) tuples."""
        ...

    async def show_error(self, error: str) -> None:
        """Display an error message."""
        ...

    async def send_file(self, path: str, caption: str | None = None) -> None:
        """Send a file to the user."""
        ...

    async def flush(self) -> None:
        """Flush any buffered content."""
        ...


type CommandHandler = Callable[["Chat", str, str, str | None, "Renderer"], Awaitable[None]]


HELP_CATEGORIES: dict[str, dict[str, Any]] = {
    "chat": {
        "label": "Chat",
        "summary": "New, clear, stop",
        "title": "Chat Commands",
        "commands": [
            ("/new", "Start fresh session"),
            ("/clear", "Clear session history"),
            ("/resume", "Resume an archived session"),
            ("/stop", "Cancel current response"),
        ],
    },
    "ai": {
        "label": "AI",
        "summary": "Model, status, tools, agents",
        "title": "AI Commands",
        "commands": [
            ("/model", "Show or change current model"),
            ("/status", "System status"),
            ("/agents", "Show delegated agent jobs"),
            ("/tools", "List available tools"),
        ],
    },
    "info": {
        "label": "Info",
        "summary": "History, memory",
        "title": "Info Commands",
        "commands": [
            ("/history", "Show session info"),
            ("/help", "Show this help menu"),
            ("/status", "Show model and memory status"),
        ],
    },
}

HELP_QUICK_COMMANDS = ["status", "new", "model"]


def get_help_data() -> dict[str, Any]:
    """Return structured help data used by command + callback handlers."""
    categories: dict[str, dict[str, Any]] = {}
    for key, value in HELP_CATEGORIES.items():
        categories[key] = {
            "label": value["label"],
            "summary": value["summary"],
            "title": value["title"],
            "commands": list(value["commands"]),
        }
    return {
        "title": "Otto Commands",
        "categories": categories,
        "quick_launch": list(HELP_QUICK_COMMANDS),
    }


def build_help_main_view() -> tuple[str, list[list[tuple[str, str]]]]:
    help_data = get_help_data()
    categories: dict[str, dict[str, Any]] = help_data["categories"]
    category_order = ["chat", "ai", "info"]
    lines = [
        "**Otto Commands**",
        "",
    ]
    for key in category_order:
        category = categories[key]
        lines.append(f"**{category['label']}** — {category['summary']}")
    lines.extend(["", "Tap a category below."])
    buttons = [
        [(categories[key]["label"], f"help:{key}") for key in category_order],
        [(f"/{command}", f"help:run:{command}") for command in help_data["quick_launch"]],
    ]
    return "\n".join(lines), buttons


def build_help_category_view(category_key: str) -> tuple[str, list[list[tuple[str, str]]]] | None:
    help_data = get_help_data()
    categories: dict[str, dict[str, Any]] = help_data["categories"]
    category = categories.get(category_key)
    if category is None:
        return None
    lines = [f"**{category['title']}**", ""]
    for command, description in category["commands"]:
        lines.append(f"{command} — {description}")
    buttons = [[("« Back", "help:back")]]
    return "\n".join(lines), buttons


def build_help_plaintext(*, cli: bool = False) -> str:
    help_data = get_help_data()
    categories: dict[str, dict[str, Any]] = help_data["categories"]
    lines = ["**Commands**", ""]
    for category_key in ["chat", "ai", "info"]:
        category = categories[category_key]
        for command, description in category["commands"]:
            lines.append(f"  {command}  {description}")
    if cli:
        lines.append("")
        lines.append("  /exit  Exit the CLI")
    return "\n".join(lines)


async def _cmd_help(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = chat, chat_id, args, bot_id
    fmt = getattr(renderer, "output_format", "telegram_html")
    if fmt == "markdown":
        await renderer.send_text(build_help_plaintext(cli=True))
    else:
        text, buttons = build_help_main_view()
        await renderer.send_with_buttons(text, buttons)


async def _cmd_status(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    model = chat._model_overrides.get(chat_id, chat._config.agent.model)
    session = chat._session_store.load(chat_id)
    tools = chat._gateway.tools()
    lines = [
        "**Status**",
        "",
        f"**Model:**  {model}",
        f"**Session:**  {len(session.messages)} messages",
        f"**Tools:**  {len(tools)} registered",
        "**Memory:**  active",
    ]
    fmt = getattr(renderer, "output_format", "telegram_html")
    if fmt == "markdown":
        await renderer.send_text("\n".join(lines))
    else:
        buttons = [
            [("Change Model", "status:model"), ("New Session", "status:new")],
            [("Refresh", "status:refresh")],
        ]
        await renderer.send_with_buttons("\n".join(lines), buttons)


async def _cmd_model(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    model_name = args.strip()
    current = chat._model_overrides.get(chat_id, chat._config.agent.model)
    presets = _build_model_presets(chat._config.agent.model_list)
    if not presets:
        # Fallback when litellm is unavailable
        presets = [
            ("Claude Sonnet", "claude-code/claude-sonnet-4-5-20250514"),
            ("Claude Haiku", "claude-code/claude-haiku-4-5-20251001"),
            ("GPT-4o", "gpt-4o"),
            ("GPT-4o Mini", "gpt-4o-mini"),
        ]
    active = _active_provider_prefixes(chat._auth_storage)
    grouped = _group_presets_by_provider(presets, active_prefixes=active)

    if model_name:
        # Check if arg is a provider filter (CLI only)
        fmt = getattr(renderer, "output_format", "telegram_html")
        if fmt == "markdown":
            match = _resolve_provider_filter(model_name, grouped)
            if match is not None:
                display_name, models = match
                lines = [f"**Current model:** {current}", "", f"**{display_name}**"]
                for label, model_id in models:
                    lines.append(f"  {label}  /model {model_id}")
                await renderer.send_text("\n".join(lines))
                return
        # Not a provider filter — set model directly
        chat._model_overrides[chat_id] = model_name
        _persist_model(chat._config, model_name, bot_id=bot_id)
        on_change = getattr(renderer, "on_model_change", None)
        if callable(on_change):
            on_change(model_name)
        await renderer.send_text(f"Model set: {model_name}")
        return

    fmt = getattr(renderer, "output_format", "telegram_html")
    if fmt == "markdown":
        lines = [f"**Current model:** {current}", ""]
        for display_name, models in grouped.items():
            lines.append(f"**{display_name}**")
            for label, model_id in models:
                lines.append(f"  {label}  /model {model_id}")
            lines.append("")
        await renderer.send_text("\n".join(lines).rstrip())
    else:
        text, buttons = build_provider_picker(chat._config, auth_storage=chat._auth_storage)
        # Use per-chat current model instead of config default
        text = f"**Current Model**\n{current}\n\nSelect a provider:"
        await renderer.send_with_buttons(text, buttons)


def _persist_model(config: Config, model: str, *, bot_id: str | None = None) -> None:
    """Persist model selection to config.toml."""
    if bot_id:
        # Find the matching bot and update its model
        if config.telegram:
            new_bots = []
            for bot_cfg in config.telegram.bots:
                if bot_cfg.alias == bot_id:
                    new_bot = object.__new__(type(bot_cfg))
                    object.__setattr__(new_bot, "alias", bot_cfg.alias)
                    object.__setattr__(new_bot, "token", bot_cfg.token)
                    object.__setattr__(new_bot, "model", model)
                    new_bots.append(new_bot)
                else:
                    new_bots.append(bot_cfg)
            tc = config.telegram
            new_tc = type(tc)(
                token=tc.token,
                owner_id=tc.owner_id,
                allowed_users=tc.allowed_users,
                bootstrap=tc.bootstrap,
                bots=new_bots,
            )
            object.__setattr__(config, "telegram", new_tc)
    else:
        new_agent = type(config.agent)(
            model=model,
            model_list=config.agent.model_list,
            history_tool_results_keep=config.agent.history_tool_results_keep,
        )
        object.__setattr__(config, "agent", new_agent)
    try:
        save_config(config)
    except Exception:
        pass


async def _cmd_new(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    chat._session_store.rotate(chat_id)
    chat._memory.delete_prefix(f"chat:{chat_id}:")
    from otto.repo_context import clear_context as _clear_repo_ctx

    _clear_repo_ctx(chat_id)
    await renderer.send_text("New session started.")


async def _cmd_clear(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    chat._session_store.rotate(chat_id)
    chat._memory.delete_prefix(f"chat:{chat_id}:")
    from otto.repo_context import clear_context as _clear_repo_ctx

    _clear_repo_ctx(chat_id)
    await renderer.send_text("Session history cleared.")


async def _cmd_resume(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = bot_id
    ts = args.strip()
    if ts:
        ok = chat._session_store.restore(chat_id, ts)
        if ok:
            # Let the renderer replay history if it supports it
            on_restored = getattr(renderer, "on_session_restored", None)
            if callable(on_restored):
                on_restored(chat_id, chat._session_store)
            else:
                await renderer.send_text(f"Resumed session from {ts}.")
        else:
            await renderer.send_text(f"No archived session found for '{ts}'.")
        return

    archives = chat._session_store.list_archived(chat_id)
    if not archives:
        await renderer.send_text("No archived sessions.")
        return

    lines = ["**Archived sessions:**", ""]
    for i, arc in enumerate(archives, 1):
        preview = arc["preview"] or "(empty)"
        lines.append(f"{i}. `{arc['ts']}` — {arc['msg_count']} msgs — {preview}")
    lines.append("")
    lines.append("Use `/resume <timestamp>` to restore.")
    await renderer.send_text("\n".join(lines))


async def _cmd_history(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    session = chat._session_store.load(chat_id)
    model = chat._model_overrides.get(chat_id, chat._config.agent.model)
    await renderer.send_text(
        "\n".join(
            [
                f"Chat ID: {chat_id}",
                f"Messages: {len(session.messages)}",
                f"Model: {model}",
            ]
        )
    )


async def _cmd_tools(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    gateway_tools = chat._gateway.tools()
    session_tools = create_session_tools(
        chat_id=chat_id,
        scheduler=chat._scheduler,
        notify=lambda t: None,  # type: ignore[arg-type, return-value]
        send_file=lambda p, c: None,  # type: ignore[arg-type, return-value]
        workspace_mode=chat._workspace_mode,
        workspace_root=chat._workspace_root,
        workspace_sandbox=chat._workspace_sandbox,
        workspace_sandbox_network=chat._workspace_sandbox_network,
    )
    all_tools = gateway_tools + session_tools
    if not all_tools:
        await renderer.send_text("No tools available.")
        return
    tool_lines = [f"- {tool.name}" for tool in all_tools]
    await renderer.send_text("Available tools:\n" + "\n".join(tool_lines))


def _is_path_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _classify_skill_scope(
    skills_dir: Path,
    *,
    bot_name_hint: str | None = None,
) -> tuple[str | None, str | None]:
    """Return (scope, bot_name) for a skills directory.

    scope is one of: bot-local, global, builtin, None.
    """
    resolved = skills_dir.resolve(strict=False)
    global_root = (OTTO_HOME / "skills").resolve(strict=False)
    bots_root = (OTTO_HOME / "bots").resolve(strict=False)
    builtin_root = BUILTIN_SKILLS_DIR.resolve(strict=False)

    if _is_path_within(resolved, builtin_root):
        return "builtin", None
    if _is_path_within(resolved, global_root):
        return "global", None
    if _is_path_within(resolved, bots_root):
        rel = resolved.relative_to(bots_root)
        bot_name = rel.parts[0] if rel.parts else None
        return "bot-local", bot_name

    # Any remaining resolved skills dir is treated as bot-local workspace skills.
    return "bot-local", bot_name_hint


def _format_scoped_skills_list(
    skills_dirs: list[Path],
    *,
    filter: str = "",
    bot_name_hint: str | None = None,
) -> str:
    keyword = filter.strip().lower()
    bot_local: list[str] = []
    global_skills: list[str] = []

    seen_entries: set[tuple[str, str, str | None]] = set()
    for skills_dir in skills_dirs:
        scope, dir_bot_name = _classify_skill_scope(skills_dir, bot_name_hint=bot_name_hint)
        if scope not in {"bot-local", "global"}:
            continue

        for skill in discover(skills_dir):
            haystack = f"{skill.name} {skill.description} {skill.path}".lower()
            if keyword and keyword not in haystack:
                continue

            dedup_key = (scope, skill.name, dir_bot_name)
            if dedup_key in seen_entries:
                continue
            seen_entries.add(dedup_key)

            if scope == "bot-local":
                if dir_bot_name:
                    bot_local.append(
                        f"- `{skill.name}` — {skill.description} (bot: {dir_bot_name})"
                    )
                else:
                    bot_local.append(f"- `{skill.name}` — {skill.description}")
            else:
                global_skills.append(f"- `{skill.name}` — {skill.description}")

    if not bot_local and not global_skills:
        if keyword:
            return f"No bot-local or global skills matching '{filter.strip()}'."
        return "No bot-local or global skills installed."

    lines = ["**Installed Skills**", ""]
    lines.append("**Bot-local skills**")
    if bot_local:
        lines.extend(bot_local)
    else:
        lines.append("- (none)")

    lines.append("")
    lines.append("**Global skills**")
    if global_skills:
        lines.extend(global_skills)
    else:
        lines.append("- (none)")

    return "\n".join(lines)


async def _cmd_skills(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    """List bot-local and global installed skills."""
    from otto.tools import _resolve_skill_dirs

    _ = chat_id, bot_id
    resolved_dirs = _resolve_skill_dirs(chat._skills_dirs)
    await renderer.send_text(
        _format_scoped_skills_list(
            resolved_dirs,
            filter=args.strip(),
            bot_name_hint=chat._bot_name,
        )
    )


def _agent_duration_label(seconds: float | None) -> str | None:
    if seconds is None:
        return None
    if seconds < 60:
        return f"{seconds:.0f}s"
    if seconds < 3600:
        return f"{seconds / 60:.1f}m"
    return f"{seconds / 3600:.1f}h"


async def _cmd_agents(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = chat, chat_id, bot_id
    mode = args.strip().lower()
    if mode in {"all", "*", "full"}:
        view = "all"
    elif mode in {"past", "done", "history"}:
        view = "past"
    else:
        view = "active"

    from otto.orchestrator import get_orchestrator

    jobs = await get_orchestrator().list_jobs()
    statuses: dict[str, set[str]] = {
        "active": {"in_progress", "ready"},
        "past": {"done", "failed", "cancelled"},
        "all": {"ready", "in_progress", "delivered", "done", "failed", "blocked", "cancelled"},
    }
    filtered = [j for j in jobs if j.get("status") in statuses[view]]
    filtered.sort(key=lambda j: str(j.get("createdAt", "")), reverse=True)

    if not filtered:
        msg = {
            "active": "No running or pending agent jobs.",
            "past": "No completed/failed/cancelled agent jobs yet.",
            "all": "No delegated agent jobs yet.",
        }[view]
        await renderer.send_text(msg)
        return

    title = {
        "active": "**Agents (running + pending)**",
        "past": "**Agents (past jobs)**",
        "all": "**Agents (all jobs)**",
    }[view]
    icon = {
        "ready": "⏳",
        "in_progress": "🔧",
        "delivered": "📦",
        "done": "✅",
        "failed": "❌",
        "blocked": "🚧",
        "cancelled": "🚫",
    }

    lines = [title, ""]
    for job in filtered:
        status = str(job.get("status", "unknown"))
        task = str(job.get("description", job.get("title", "")))
        task = " ".join(task.split())
        preview = task[:72] + ("..." if len(task) > 72 else "")
        lines.append(f"{icon.get(status, '•')} `{job['id']}` — {status.upper()}: {preview}")

        details: list[str] = []
        deps = job.get("blockedBy", [])
        if deps and status == "ready":
            details.append(f"depends: {', '.join(deps)}")
        otto_ext = job.get("x-otto", {})
        attempts = int(otto_ext.get("attempts", 0))
        if attempts > 1:
            details.append(f"attempts: {attempts}")
        duration = _agent_duration_label(job.get("contract", {}).get("metrics", {}).get("duration"))
        if duration:
            details.append(f"duration: {duration}")
        if details:
            lines.append("  " + " | ".join(details))

    lines.extend(["", "Use `/agents all` or `/agents past` for other views."])
    text = "\n".join(lines)

    fmt = getattr(renderer, "output_format", "telegram_html")
    if fmt == "telegram_html":
        buttons: list[list[tuple[str, str]]] = []
        top: list[tuple[str, str]] = []
        if view != "active":
            top.append(("Active", "agents:active"))
        if view != "all":
            top.append(("Show All", "agents:all"))
        if view != "past":
            top.append(("Past Jobs", "agents:past"))
        if top:
            buttons.append(top)
        await renderer.send_with_buttons(text, buttons)
        return

    await renderer.send_text(text)


async def _cmd_stop(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    if chat.stop(chat_id):
        await renderer.send_text("Stopping...")
    else:
        await renderer.send_text("Nothing running.")


_log = logging.getLogger(__name__)


def _model_supports_vision(model: str) -> bool:
    """Check if a model supports vision/image inputs via litellm model info."""
    try:
        import litellm

        litellm_model = model.split("/", 1)[-1] if "/" in model else model
        info = litellm.get_model_info(model=litellm_model)
        return bool(info.get("supports_vision", False))
    except Exception:
        return False


def _build_content_blocks(
    text: str,
    attachments: list[dict],
    model: str,
) -> list[dict]:
    """Build OpenAI-style content blocks from text and attachments.

    Returns a list of content block dicts suitable for the user message
    sent to the LLM. Image attachments are converted to image_url blocks
    with data URIs; if the model lacks vision support, a text note is
    substituted instead.
    """
    blocks: list[dict] = [{"type": "text", "text": text or ""}]
    has_vision = _model_supports_vision(model)
    for att in attachments:
        if att["type"] == "image":
            if has_vision:
                blocks.append(
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:{att['mime']};base64,{att['data']}"},
                    }
                )
            else:
                blocks.append(
                    {
                        "type": "text",
                        "text": (
                            "(User sent an image, but the current model does not support vision.)"
                        ),
                    }
                )
        elif att["type"] == "text":
            label = att.get("filename", "attachment")
            blocks.append({"type": "text", "text": f"[{label}]\n{att['content']}"})
    return blocks


def _attachment_summary(text: str, attachments: list[dict]) -> str:
    """Build a text-only summary for session storage (no base64 data)."""
    parts = [text] if text else []
    for att in attachments:
        if att["type"] == "image":
            parts.append("[User sent an image]")
        elif att["type"] == "text":
            label = att.get("filename", "attachment")
            parts.append(f"[{label}] {att['content']}")
    return "\n".join(parts) if parts else ""


def _count_tokens(messages: list[dict], model: str = "claude-sonnet-4-5-20250514") -> int:
    """Count tokens in messages using litellm, falling back to len-based estimate."""
    try:
        import litellm

        litellm_model = model.split("/", 1)[-1] if "/" in model else model
        return litellm.token_counter(model=litellm_model, messages=messages)
    except Exception:
        total = 0
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total += len(content)
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, dict):
                        total += len(str(part.get("text", "")))
            # Account for tool_calls
            if "tool_calls" in msg:
                for tc in msg["tool_calls"]:
                    fn = tc.get("function", {})
                    total += len(str(fn.get("name", ""))) + len(str(fn.get("arguments", "")))
        return len(messages) * 500


def _cap_session_history(
    messages: list[dict], max_tokens: int = 30_000, min_keep: int = 6
) -> list[dict]:
    """Trim session history from the front to fit within a token budget.

    Preserves at least min_keep recent messages. Never splits an assistant
    message with tool_calls from its subsequent tool result messages.
    """
    if not messages:
        return messages

    token_count = _count_tokens(messages)
    if token_count <= max_tokens:
        return messages

    if len(messages) <= min_keep:
        return messages

    # Build "turn groups" — sequences of messages that must stay together.
    # A turn group is one of:
    #   - A user message (standalone)
    #   - An assistant message WITHOUT tool_calls (standalone)
    #   - An assistant message WITH tool_calls + all following tool messages
    groups: list[list[int]] = []
    i = 0
    while i < len(messages):
        msg = messages[i]
        if msg.get("role") == "assistant" and "tool_calls" in msg:
            # Collect this assistant + all following tool messages
            group = [i]
            j = i + 1
            while j < len(messages) and messages[j].get("role") == "tool":
                group.append(j)
                j += 1
            groups.append(group)
            i = j
        else:
            groups.append([i])
            i += 1

    # Find the minimum number of groups from the end that covers min_keep messages
    kept_msg_count = 0
    min_groups_from_end = 0
    for g in reversed(groups):
        if kept_msg_count >= min_keep:
            break
        kept_msg_count += len(g)
        min_groups_from_end += 1

    # Try trimming groups from the front until under budget
    trim_from = 0
    max_trim = len(groups) - min_groups_from_end
    for trim_from in range(1, max_trim + 1):
        kept_indices = []
        for g in groups[trim_from:]:
            kept_indices.extend(g)
        kept = [messages[idx] for idx in kept_indices]
        if _count_tokens(kept) <= max_tokens:
            break
    else:
        # Even trimming to min_keep didn't fit — just keep min_keep messages
        trim_from = max_trim

    kept_indices = []
    for g in groups[trim_from:]:
        kept_indices.extend(g)
    result = [messages[idx] for idx in kept_indices]

    if trim_from > 0:
        result.insert(
            0,
            {
                "role": "user",
                "content": "[Earlier conversation history was trimmed to save context]",
            },
        )

    return result


def _collapse_tool_rounds(messages: list[dict], original_count: int) -> list[dict]:
    """Remove intermediate tool call/result messages added during agent.run().

    Everything from original_count onward was appended by the agent loop
    (assistant+tool_calls and tool result messages). Strip those out — the
    final assistant text response gets appended separately after this call.
    """
    if original_count >= len(messages):
        return messages

    # Keep everything before the agent run started
    return list(messages[:original_count])


COMMANDS: dict[str, CommandHandler] = {
    "help": _cmd_help,
    "status": _cmd_status,
    "model": _cmd_model,
    "new": _cmd_new,
    "clear": _cmd_clear,
    "resume": _cmd_resume,
    "history": _cmd_history,
    "tools": _cmd_tools,
    "skills": _cmd_skills,
    "agents": _cmd_agents,
    "stop": _cmd_stop,
    "setup": None,  # Lazy import — resolved at dispatch time
}


class Chat:
    def __init__(
        self,
        config: Config,
        gateway: Gateway,
        session_store: SessionStore,
        memory: Memory,
        scheduler: Scheduler | None = None,
        *,
        bot_name: str | None = None,
        workspace_mode: str | None = None,
        workspace_root: str | None = None,
        workspace_sandbox: str | None = None,
        workspace_sandbox_network: bool | None = None,
        skills_dirs: list[str | Path] | None = None,
    ):
        self._config = config
        self._gateway = gateway
        self._session_store = session_store
        self._memory = memory
        self._scheduler = scheduler
        self._bot_name = bot_name
        self._workspace_mode = workspace_mode
        self._workspace_root = workspace_root
        self._workspace_sandbox = workspace_sandbox
        self._workspace_sandbox_network = workspace_sandbox_network
        self._skills_dirs = [Path(str(path)).expanduser() for path in (skills_dirs or [])]
        self._model_overrides: dict[str, str] = {}
        self._auth_storage = AuthStorage()
        self._active_tasks: dict[str, asyncio.Task] = {}

    @staticmethod
    def _context_key(chat_id: str, *, bot_id: str | None = None) -> str:
        """Return the context key for a chat.

        With per-bot Chat instances, scoping is handled by having separate
        Chat/Memory/SessionStore per bot. The bot_id parameter is accepted
        for backward compatibility with telegram.py but ignored.
        """
        return chat_id

    def stop(self, chat_id: str, bot_id: str | None = None) -> bool:
        """Cancel any active agent run for this chat. Returns True if a task was cancelled."""
        task = self._active_tasks.get(chat_id)
        if task and not task.done():
            task.cancel()
            return True
        return False

    async def handle_message(
        self,
        chat_id: str,
        text: str,
        renderer: Renderer,
        bot_id: str | None = None,
        *,
        background: bool = False,
        attachments: list[dict] | None = None,
    ) -> None:
        """Main entry point. Routes slash commands or runs the agent.

        Args:
            bot_id: Accepted for backward compatibility but ignored. Scoping is
                    handled by per-bot Chat instances.
            background: True when invoked by the scheduler. Enables the send_message
                        tool so the agent can proactively notify the user. During normal
                        chat the streaming response already reaches the user via flush(),
                        so send_message is omitted to prevent duplicate delivery loops.
        """
        if text.startswith("/"):
            command_text = text[1:].strip()
            if not command_text:
                await renderer.show_error("Unknown command: /")
                return
            parts = command_text.split(None, 1)
            command = parts[0]
            args = parts[1] if len(parts) > 1 else ""
            await self.handle_command(
                chat_id=chat_id,
                command=command,
                args=args,
                renderer=renderer,
                bot_id=bot_id,
            )
            return

        task = asyncio.current_task()
        if task:
            self._active_tasks[chat_id] = task

        try:
            # Save user message to full session history (text-only, no base64)
            session = self._session_store.load(chat_id)
            if attachments:
                session_text = _attachment_summary(text, attachments)
            else:
                session_text = text
            session.messages.append({"role": "user", "content": session_text})
            self._session_store.save(session)

            # Check for active setup flow — route to setup handler instead of LLM
            setup_state_raw = self._memory.get(f"__setup_state:{chat_id}")
            if setup_state_raw:
                import json as _json

                from otto.setup_commands import handle_setup_continuation

                await handle_setup_continuation(
                    self, chat_id, text, bot_id, renderer, _json.loads(setup_state_raw)
                )
                return

            # Build LLM context with pruning + compaction
            tool_results_keep = self._config.agent.history_tool_results_keep
            llm_messages = self._session_store.load_for_llm(
                chat_id, tool_results_keep=tool_results_keep
            )
            llm_messages = _cap_session_history(llm_messages)

            # Replace last user message with multimodal content blocks if needed
            if attachments and llm_messages:
                model = self._model_overrides.get(chat_id, self._config.agent.model)
                content_blocks = _build_content_blocks(text, attachments, model)
                # Find the last user message and replace its content
                for i in range(len(llm_messages) - 1, -1, -1):
                    if llm_messages[i].get("role") == "user":
                        llm_messages[i] = dict(llm_messages[i])
                        llm_messages[i]["content"] = content_blocks
                        break

            memory_context: list[dict] = []
            try:
                memory_context = self._memory.search(text, limit=5)
            except Exception:
                memory_context = []

            identity = self._memory.get(IDENTITY_KEY)
            fmt = getattr(renderer, "output_format", "telegram_html")

            # Retrieve cached repo context for system prompt injection.
            from otto.repo_context import format_for_prompt, get_context

            repo_ctx = get_context(chat_id)
            repo_ctx_str = format_for_prompt(repo_ctx) if repo_ctx else None

            model = self._model_overrides.get(chat_id, self._config.agent.model)
            gateway_tools = self._gateway.tools()

            async def _notify(text: str) -> None:
                await renderer.send_text(text)

            async def _send_file(path: str, caption: str | None = None) -> None:
                await renderer.send_file(path, caption)

            # Build base tools first so delegation can pass them to sub-agents.
            base_tools = gateway_tools
            session_tools = create_session_tools(
                chat_id=chat_id,
                scheduler=self._scheduler,
                notify=_notify if background else None,
                delegate_notify=_notify,
                send_file=_send_file,
                workspace_mode=self._workspace_mode,
                workspace_root=self._workspace_root,
                workspace_sandbox=self._workspace_sandbox,
                workspace_sandbox_network=self._workspace_sandbox_network,
                base_tools=base_tools,
                session_model=model,
                auth_storage=self._auth_storage,
                output_format=fmt,
            )
            all_tools = gateway_tools + session_tools
            active_tool_names = list(dict.fromkeys(tool.name for tool in all_tools))

            system_prompt = build_system_prompt(
                memory_context=memory_context,
                identity=identity,
                output_format=fmt,
                repo_context=repo_ctx_str,
                active_tools=active_tool_names,
                skills_dirs=self._skills_dirs or None,
            )

            result = await run(
                model=model,
                system=system_prompt,
                messages=llm_messages,
                tools=all_tools,
                auth_storage=self._auth_storage,
                compaction_enabled=self._config.agent.compaction_enabled,
                compaction_threshold=self._config.agent.compaction_threshold,
                compaction_keep_recent_messages=self._config.agent.compaction_keep_recent_messages,
                on_text=renderer.on_text,
                on_tool_start=renderer.on_tool_start,
                on_tool_end=renderer.on_tool_end,
            )
            await renderer.flush()

            # Save assistant response to full session (reload to get latest)
            session = self._session_store.load(chat_id)
            session.messages.append({"role": "assistant", "content": result.text})
            self._session_store.save(session)

        finally:
            if task and self._active_tasks.get(chat_id) is task:
                self._active_tasks.pop(chat_id, None)

    async def handle_command(
        self,
        chat_id: str,
        command: str,
        args: str,
        renderer: Renderer,
        bot_id: str | None = None,
    ) -> None:
        """Dispatch slash commands."""
        name = command.strip().lstrip("/").lower()

        # /cancel clears any active setup flow
        if name == "cancel":
            from otto.setup_commands import _clear_setup_state, _get_setup_state

            if _get_setup_state(self, chat_id):
                _clear_setup_state(self, chat_id)
                await renderer.send_text("Setup cancelled.")
                return
            await renderer.show_error("Nothing to cancel.")
            return

        # Lazy import for /setup
        if name == "setup":
            from otto.setup_commands import cmd_setup

            await cmd_setup(self, chat_id, args, bot_id, renderer)
            return

        handler = COMMANDS.get(name)
        if handler:
            await handler(self, chat_id, args, bot_id, renderer)
        else:
            await renderer.show_error(f"Unknown command: /{name}")
