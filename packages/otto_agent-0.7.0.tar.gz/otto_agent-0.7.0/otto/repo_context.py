"""Per-session repo map context store.

Provides a module-level dict keyed by ``chat_id`` so the ``repo_map`` tool
(session-scoped) can publish a freshly-built skeleton and
``build_system_prompt`` can inject it into subsequent turns without
re-calling the tool.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class RepoContext:
    """Cached repo map skeleton for a single project root."""

    root: Path
    skeleton: str
    created_at: float = field(default_factory=time.monotonic)


# ---- module-level store, keyed by chat_id ----
_active: dict[str, RepoContext] = {}


def set_context(chat_id: str, root: Path, skeleton: str) -> None:
    """Store (or replace) the active repo context for a chat session."""
    _active[chat_id] = RepoContext(root=root, skeleton=skeleton)


def get_context(chat_id: str) -> RepoContext | None:
    """Return the active repo context, or *None* if unset."""
    return _active.get(chat_id)


def clear_context(chat_id: str) -> None:
    """Remove the repo context for a chat session (e.g. on /new or /clear)."""
    _active.pop(chat_id, None)


def format_for_prompt(ctx: RepoContext) -> str:
    """Wrap a :class:`RepoContext` as a block suitable for the system prompt."""
    return f'\n<repo_context path="{ctx.root}">\n{ctx.skeleton}\n</repo_context>'
