"""Version information for `deepagents-cli`."""

__version__ = "0.0.25"  # x-release-please-version
