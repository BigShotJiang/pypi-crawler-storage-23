import json
import re
from typing import Any, List

def get_nested_value(data: list, path: List[int], default: Any = None) -> Any:
    """Safely get a value from a nested list by a sequence of indices."""
    current = data
    for key in path:
        try:
            current = current[key]
        except (IndexError, TypeError, KeyError):
            return default
    if current is None and default is not None:
        return default
    return current

def extract_json_from_response(text: str) -> list:
    """Clean and extract the JSON content from a Google API response."""
    # Google's response is often a stream of JSONs, usually formatted as:
    # length\n[[data]]\nlength\n[[data]]
    # or starts with )]}'
    
    all_data = []
    lines = text.splitlines()
    for line in lines:
        line = line.strip()
        if not line: continue
        
        # Skip prefix
        if line.startswith(")]}'"):
            line = line[4:].strip()
            if not line: continue
            
        # Skip pure length lines
        if line.isdigit():
            continue
            
        try:
            parsed = json.loads(line)
            if isinstance(parsed, list):
                all_data.extend(parsed)
            else:
                all_data.append(parsed)
        except json.JSONDecodeError:
            continue
            
    if not all_data:
        raise ValueError("Could not find any valid JSON object or array in the response.")
    return all_data
