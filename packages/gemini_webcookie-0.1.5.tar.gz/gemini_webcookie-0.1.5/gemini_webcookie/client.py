import asyncio
import json
import re
import random
import string
from typing import Optional, List, Union, Dict, Any
from pathlib import Path
import httpx

import itertools
from .types import ModelOutput, Candidate, WebImage, GeneratedImage, Gem, GemJar, RPCData
from .exceptions import APIError, TimeoutError, AuthError
from .constants import Endpoint, Headers, Model, GRPC
from .utils import extract_json_from_response, get_nested_value


class GeminiClient:
    """
    Client tương thích với Gemini-WebAPI.
    """
    def __init__(
        self,
        secure_1psid: str | None = None,
        secure_1psidts: str | None = None,
        proxy: str | None = None,
        **kwargs,
    ):
        self.cookies = {}
        self.anonymous = False
        if secure_1psid:
            self.cookies["__Secure-1PSID"] = secure_1psid
        else:
            self.anonymous = True
            
        if secure_1psidts:
            self.cookies["__Secure-1PSIDTS"] = secure_1psidts
            
        self.proxy = proxy
        self.kwargs = kwargs
        self.client: Optional[httpx.AsyncClient] = None
        self.access_token: Optional[str] = None
        
        # No-cookie attributes
        self.f_sid = f"-{''.join(random.choices(string.digits, k=18))}" if self.anonymous else None
        self.req_id = random.randint(1000000, 9000000)
        self.conv_token = ""
        self.at_token = ""
        self.bl = "boq_assistant-bard-web-server_20260223.07_p5"
        
        # Compatibility attributes
        self.auto_close = False
        self.timeout = 300
        self.auto_refresh = True
        self.refresh_interval = 540
        self.refresh_task: Optional[asyncio.Task] = None
        self._gems: Optional[GemJar] = None

    @property
    def gems(self) -> GemJar:
        if self._gems is None:
            raise RuntimeError(
                "Gems not fetched yet. Call `GeminiClient.fetch_gems()` method to fetch gems from gemini.google.com."
            )
        return self._gems

    async def init(
        self,
        timeout: float = 300,
        auto_close: bool = False,
        close_delay: float = 300,
        auto_refresh: bool = True,
        refresh_interval: float = 540,
        verbose: bool = True,
    ) -> None:
        """
        Khởi tạo client, lấy access token (SNlM0e).
        """
        self.timeout = timeout
        self.auto_close = auto_close
        self.auto_refresh = auto_refresh
        self.refresh_interval = refresh_interval
        
        headers = Headers.GEMINI.value.copy()
        if self.anonymous:
            headers.update({
                "X-Same-Domain": "1",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Dest": "empty",
            })

        self.client = httpx.AsyncClient(
            cookies=self.cookies,
            proxy=self.proxy,
            timeout=timeout,
            follow_redirects=True,
            headers=headers,
            verify=False, # Relax verification as in Gemini-WebAPI
            **self.kwargs
        )
        
        if self.anonymous:
            if verbose:
                print("GeminiClient initialized in anonymous mode.")
            return

        # Lấy SNlM0e
        try:
            # First try google.com to get extra cookies (sometimes needed, as in Gemini-WebAPI)
            try:
                await self.client.get(Endpoint.GOOGLE.value)
            except Exception:
                pass # Fail silently, main goal is Endpoint.INIT

            response = await self.client.get(Endpoint.INIT)
            response.raise_for_status()
            
            match = re.search(r'"SNlM0e":"(.*?)"', response.text)
            if match:
                self.access_token = match.group(1)
                if verbose:
                    print("GeminiClient initialized successfully.")
            else:
                 # Debug info if token missing
                 # Usually means not logged in (cookies invalid) or blocked
                 if verbose:
                     print(f"DEBUG: Failed response from {Endpoint.INIT}. Status: {response.status_code}")
                     if "Sign in" in response.text:
                         print("DEBUG: Response contains 'Sign in', cookies likely invalid or expired.")
                 raise AuthError("Could not find SNlM0e access token. Cookies might be invalid (redirected to login?).")
                
            if self.auto_refresh:
                if self.refresh_task:
                    self.refresh_task.cancel()
                self.refresh_task = asyncio.create_task(self._auto_refresh_loop())

        except Exception as e:
            await self.close()
            # Preserve original AuthError if raised above
            if isinstance(e, AuthError): raise
            raise AuthError(f"Failed to initialize: {str(e)}")

    async def _auto_refresh_loop(self):
        while True:
            await asyncio.sleep(self.refresh_interval)
            try:
                new_1psidts = await self._rotate_1psidts()
                if new_1psidts:
                    self.cookies["__Secure-1PSIDTS"] = new_1psidts
                    if self.client:
                        self.client.cookies.set("__Secure-1PSIDTS", new_1psidts)
                    # print("Cookies refreshed.")
            except Exception as e:
                # print(f"Cookie refresh failed: {e}")
                pass

    async def _rotate_1psidts(self) -> str | None:
        if not self.client: return None
        try:
             # Use a temporary client or the existing one? Existing one has headers for Gemini, 
             # but RotateCookies might need different headers.
             # Based on Gemini-WebAPI, it uses a fresh client for rotation often to avoid messing up state,
             # but let's try using a separate request with correct headers.
             
             async with httpx.AsyncClient(cookies=self.cookies, proxy=self.proxy, timeout=30) as client:
                 response = await client.post(
                     url=Endpoint.ROTATE_COOKIES.value,
                     headers=Headers.ROTATE_COOKIES.value,
                     data='[000,"-0000000000000000000"]',
                 )
                 if response.status_code == 200:
                     return response.cookies.get("__Secure-1PSIDTS")
        except Exception:
            pass
        return None

    async def _batch_execute(self, payloads: List[RPCData], **kwargs) -> httpx.Response:
        if not self.client or not self.access_token:
            raise AuthError("Client not initialized")

        f_req = json.dumps([[p.serialize() for p in payloads]])
        data = {
            "at": self.access_token,
            "f.req": f_req,
        }
        
        response = await self.client.post(
            Endpoint.BATCH_EXEC,
            data=data,
            **kwargs,
        )
        response.raise_for_status()
        return response

    async def fetch_gems(self, include_hidden: bool = False, **kwargs) -> GemJar:
        response = await self._batch_execute(
            [
                RPCData(
                    rpcid=GRPC.LIST_GEMS,
                    payload="[4]" if include_hidden else "[3]",
                    identifier="system",
                ),
                RPCData(
                    rpcid=GRPC.LIST_GEMS,
                    payload="[2]",
                    identifier="custom",
                ),
            ],
            **kwargs,
        )
        
        predefined_gems, custom_gems = [], []
        try:
            # Response parsing logic from Gemini-WebAPI
            # They split strictly by newline, taking index 2?
            # Let's try to be robust. 
            lines = response.text.split("\n")
            # Usually the relevant JSON is in one of the lines, formatted ")]}'\n..."
            # Gemini-WebAPI: json.loads(response.text.split("\n")[2])
            # We will search for the line that looks like valid JSON array
            response_json = None
            for line in lines:
                if line.startswith("[["):
                    try:
                        response_json = json.loads(line)
                        break
                    except: pass
            
            if not response_json and len(lines) > 2:
                 # Fallback to hardcoded index if search fails
                 try: response_json = json.loads(lines[2])
                 except: pass

            if response_json:
                for part in response_json:
                     # part structure: [index, id, json_str, identifier]
                     # identifier is at index 3?
                     # RPCData sends identifier, checking if it comes back
                     if len(part) > 3:
                        if part[-1] == "system":
                            predefined_gems = json.loads(part[2])[2]
                        elif part[-1] == "custom":
                            container = json.loads(part[2])
                            if container: custom_gems = container[2]
            
        except Exception as e:
            raise APIError(f"Failed to parse gems response: {e}")

        # Construct GemJar
        self._gems = GemJar()
        
        # Predefined
        if predefined_gems:
            for gem in predefined_gems:
                gid = gem[0]
                gname = gem[1][0]
                gdesc = gem[1][1]
                gprompt = gem[2][0] if gem[2] else None
                self._gems[gid] = Gem(id=gid, name=gname, description=gdesc or "", prompt=gprompt or "", predefined=True)

        # Custom
        if custom_gems:
             for gem in custom_gems:
                gid = gem[0]
                gname = gem[1][0]
                gdesc = gem[1][1]
                gprompt = gem[2][0] if gem[2] else None
                self._gems[gid] = Gem(id=gid, name=gname, description=gdesc or "", prompt=gprompt or "", predefined=False)
        
        return self._gems

    async def create_gem(self, name: str, prompt: str, description: str = "") -> Gem:
        payload = json.dumps([
             [name, description, prompt, None, None, None, None, None, 0, None, 1, None, None, None, []]
        ])
        
        response = await self._batch_execute(
            [RPCData(rpcid=GRPC.CREATE_GEM, payload=payload)]
        )
        
        # Parse response to get ID
        gem_id = None
        try:
             # Similar parsing strategy
             lines = response.text.split("\n")
             response_json = None
             for line in lines:
                 if line.startswith("[["):
                     response_json = json.loads(line)
                     break
             if not response_json and len(lines) > 2:
                 response_json = json.loads(lines[2])
             
             if response_json:
                 # response_json[0] -> part
                 # part[2] -> inner json string
                 inner = json.loads(response_json[0][2])
                 gem_id = inner[0]
        except:
             pass
             
        if not gem_id:
             raise APIError("Failed to create gem (could not parse ID).")

        return Gem(id=gem_id, name=name, description=description, prompt=prompt, predefined=False)

    async def update_gem(self, gem: Union[Gem, str], name: str, prompt: str, description: str = "") -> Gem:
        gem_id = gem.id if isinstance(gem, Gem) else gem
        
        payload = json.dumps([
            gem_id,
            [name, description, prompt, None, None, None, None, None, 0, None, 1, None, None, None, [], 0]
        ])
        
        await self._batch_execute(
             [RPCData(rpcid=GRPC.UPDATE_GEM, payload=payload)]
        )
        
        return Gem(id=gem_id, name=name, description=description, prompt=prompt, predefined=False)

    async def delete_gem(self, gem: Union[Gem, str]) -> None:
        gem_id = gem.id if isinstance(gem, Gem) else gem
        payload = json.dumps([gem_id])
        await self._batch_execute(
            [RPCData(rpcid=GRPC.DELETE_GEM, payload=payload)]
        )


    async def generate_content(
        self,
        prompt: str,
        files: List[Union[str, Path]] | None = None,
        model: Union[str, Dict] = Model.UNSPECIFIED,
        gem: Union["Gem", str, None] = None,
        chat: Optional["ChatSession"] = None,
        **kwargs,
    ) -> ModelOutput:
        """
        Tạo nội dung thực sự từ Google API.
        """
        if not self.client:
            await self.init()

        if not self.anonymous and not self.access_token:
            await self.init()

        # Handle Model enum or string/dict
        if isinstance(model, str):
            model_obj = Model.from_name(model)
        elif isinstance(model, dict):
            # Simple wrapper for custom model dict
            class CustomModel:
                model_header = model.get("model_header", {})
                model_name = model.get("model_name", "custom")
            model_obj = CustomModel()
        else:
            model_obj = model
            
        # Handle Gem object
        gem_id = None
        if gem:
            if isinstance(gem, Gem):
                gem_id = gem.id
            else:
                gem_id = gem

        # Construct payload
        # Structure based on reverse engineering in Gemini-WebAPI
        
        # Simple text prompt payload structure
        if files:
            uploaded_files = []
            for file in files:
                file_path = Path(file)
                if not file_path.is_file():
                     raise ValueError(f"{file_path} is not a valid file.")
                
                # Upload file
                # Docstring says it uploads to content-push.googleapis.com
                # Helper method to upload
                file_url = await self._upload_file(file_path)
                uploaded_files.append([
                    [[file_url], file_path.name]
                ])
                
            req_content = [
                prompt,
                0,
                None, 
                uploaded_files # Files go here at index 3
            ]
        else:
            req_content = [prompt]
        
        # Chat history metadata
        chat_metadata = chat.metadata if chat else None
        
        # Full payload
        if self.anonymous:
            # Multi-turn payload for anonymous mode - Matches test_repl.py
            req_content_anon = [prompt, 0, None, None, None, None, 0]
            # [cid, rid, rcid, null, null, null, null, null, null, conv_token]
            meta_content_anon = [
                chat.cid if chat else None,
                chat.rid if chat else None,
                chat.rcid if chat else None,
                None,
                None,
                None,
                None,
                None,
                None,
                self.conv_token
            ]
            payload_inner = [req_content_anon, ["vi"], meta_content_anon]
        else:
            payload_inner = [
                req_content,  
                None,
                chat_metadata,
            ]
        
        if gem_id:
             payload_inner.extend([None] * 16 + [gem_id])


        f_req = json.dumps([None, json.dumps(payload_inner)])

        data = {
            "at": self.access_token if self.access_token else self.at_token,
            "f.req": f_req,
        }

        params = {}
        if self.anonymous:
            params = {
                "bl": self.bl,
                "f.sid": self.f_sid,
                "hl": "vi",
                "_reqid": str(self.req_id),
                "rt": "c"
            }

        try:
            response = await self.client.post(
                Endpoint.GENERATE,
                headers=model_obj.model_header,
                params=params,
                data=data,
                **kwargs
            )
            if self.anonymous:
                self.req_id += 100000
            
            # Debug log for anonymous mode response
            # if self.anonymous:
            #     print(f"[DEBUG] Response Status: {response.status_code}")
            #     print(f"[DEBUG] Response Headers: {dict(response.headers)}")
            #     print(f"[DEBUG] Response Body Preview: {response.text[:500]}")
                
            response.raise_for_status()
        except httpx.ReadTimeout:
             raise TimeoutError("Request timed out.")
        
        # Parse Response
        try:
            # clean_text = response.text
            # if clean_text.startswith(")]}'"):
            #     clean_text = clean_text[4:]
            
            # Use the robust extraction utility
            response_json = extract_json_from_response(response.text)
            
            if not isinstance(response_json, list):
                raise APIError(f"Unexpected response format: expected list, got {type(response_json)}")

            # Find the body with data (Move this up so we can use 'body' for anonymous tokens)
            body = None
            body_index = 0
            for idx, part in enumerate(response_json):
                # part structure is usually [index, id, json_str, ...]
                # we look for json_str at index 2
                part_body_str = get_nested_value(part, [2])
                if not part_body_str: continue
                
                try:
                    part_body = json.loads(part_body_str)
                    # Check if it has candidates at index 4
                    if get_nested_value(part_body, [4]):
                        body = part_body
                        body_index = idx
                        break
                except:
                    continue

            # Extract anonymous tokens and metadata if available
            if self.anonymous:
                # First, check the main body if we already found it
                if body:
                    # conv_token is often at index 3 of the body
                    potential_conv = get_nested_value(body, [3])
                    if isinstance(potential_conv, str) and potential_conv.startswith('!'):
                        self.conv_token = potential_conv

                for part in response_json:
                    if not isinstance(part, list) or len(part) < 3:
                        continue
                    
                    part_body_str = part[2]
                    if not part_body_str or not isinstance(part_body_str, str):
                        continue
                        
                    try:
                        part_data = json.loads(part_body_str)
                        if not isinstance(part_data, list):
                            continue
                            
                        # Trích xuất 'at' token từ chunk r_... (thường là index 20)
                        if len(part_data) > 20 and isinstance(part_data[20], list) and len(part_data[20]) > 0:
                            self.at_token = part_data[20][0]
                        # Trích xuất 'conversation token' (index 3 trong part_data)
                        if len(part_data) > 3 and isinstance(part_data[3], str) and part_data[3].startswith('!'):
                            self.conv_token = part_data[3]
                        
                        # Trích xuất CID/RID/RCID từ metadata ở index 1
                        if len(part_data) > 1 and isinstance(part_data[1], list) and len(part_data[1]) >= 2:
                            if part_data[1][0] and str(part_data[1][0]).startswith('c_'):
                                if chat: 
                                    chat.cid = part_data[1][0]
                            if part_data[1][1] and str(part_data[1][1]).startswith('r_'):
                                if chat: 
                                    chat.rid = part_data[1][1]
                            if len(part_data[1]) >= 3 and part_data[1][2] and str(part_data[1][2]).startswith('rc_'):
                                if chat: 
                                    chat.rcid = part_data[1][2]
                        
                        # Trích xuất RCID từ candidates nếu có
                        if len(part_data) > 4 and isinstance(part_data[4], list):
                            for cand in part_data[4]:
                                if len(cand) > 0 and isinstance(cand[0], str) and cand[0].startswith('rc_'):
                                    if chat: chat.rcid = cand[0]
                                
                    except (json.JSONDecodeError, TypeError):
                        continue

                # Double check conv_token from the main body if available
                if body:
                    potential_conv = get_nested_value(body, [3])
                    if isinstance(potential_conv, str) and potential_conv.startswith('!'):
                        self.conv_token = potential_conv
                                
                    # Also check metadata in body[1] as fallback
                    body_meta = get_nested_value(body, [1])
                    if body_meta and isinstance(body_meta, list) and len(body_meta) >= 2:
                        if not (chat and chat.cid) and body_meta[0] and str(body_meta[0]).startswith('c_'):
                            if chat: chat.cid = body_meta[0]
                        if not (chat and chat.rid) and body_meta[1] and str(body_meta[1]).startswith('r_'):
                            if chat: chat.rid = body_meta[1]
                        if len(body_meta) >= 3 and not (chat and chat.rcid) and body_meta[2] and str(body_meta[2]).startswith('rc_'):
                            if chat: chat.rcid = body_meta[2]
                                
                    # Some responses have a very long token at index 8 or 9
                    potential_long_token = get_nested_value(body, [9])
                    if isinstance(potential_long_token, str) and potential_long_token.startswith('!'):
                        self.conv_token = potential_long_token

            if not body:
                raise APIError("No content found in response.")

            candidates_data = get_nested_value(body, [4], [])
            output_candidates = []
            
            for index, cand in enumerate(candidates_data):
                rcid = get_nested_value(cand, [0])
                text = get_nested_value(cand, [1, 0])
                if not text: continue
                
                # Thoughts if available
                thoughts = get_nested_value(cand, [37, 0, 0])

                # Web Images
                web_images = []
                for web_img_data in get_nested_value(cand, [12, 1], []):
                    url = get_nested_value(web_img_data, [0, 0, 0])
                    if url:
                         web_images.append(WebImage(
                             url=url,
                             title=get_nested_value(web_img_data, [7, 0], ""),
                             alt=get_nested_value(web_img_data, [0, 4], ""),
                             proxy=self.proxy
                         ))

                # Generated Images
                generated_images = []
                # Check for generated images marker
                if get_nested_value(cand, [12, 7, 0]):
                     # Need to look for image data in subsequent parts of response_json
                     img_body = None
                     for img_part_index, part in enumerate(response_json):
                         if img_part_index < body_index: continue
                         try:
                             img_part_body_str = get_nested_value(part, [2])
                             if not img_part_body_str: continue
                             img_part_json = json.loads(img_part_body_str)
                             if get_nested_value(img_part_json, [4, index, 12, 7, 0]):
                                 img_body = img_part_json
                                 break
                         except: continue
                    
                     if img_body:
                         img_candidate = get_nested_value(img_body, [4, index], [])
                         # Update text if changed (sometimes text changes after image gen)
                         finished_text = get_nested_value(img_candidate, [1, 0])
                         if finished_text:
                              text = re.sub(r"http://googleusercontent\.com/image_generation_content/\d+","", finished_text).rstrip()
                        
                         for gen_img_data in get_nested_value(img_candidate, [12, 7, 0], []):
                             url = get_nested_value(gen_img_data, [0, 3, 3])
                             if url:
                                 generated_images.append(GeneratedImage(
                                     url=url,
                                     title=f"[Generated Image]",
                                     alt=get_nested_value(gen_img_data, [3, 5, 0], ""),
                                     proxy=self.proxy,
                                     cookies=self.cookies
                                 ))

                output_candidates.append(Candidate(
                    rcid=rcid,
                    text=text,
                    thoughts=thoughts,
                    web_images=web_images,
                    generated_images=generated_images
                ))

            if not output_candidates:
                raise APIError("No candidates returned.")

            output = ModelOutput(
                metadata=get_nested_value(body, [1], []), # New metadata for conversation
                candidates=output_candidates
            )
            
            if chat:
                chat.last_output = output
                # Update anonymous IDs and run background tasks
                if self.anonymous:
                    # Run background history tasks for anonymous mode
                    asyncio.create_task(self._run_anonymous_history(chat))
                
            return output

        except Exception as e:
            if isinstance(e, APIError): raise
            raise APIError(f"Failed to parse response: {str(e)}")

    async def _run_anonymous_history(self, chat: "ChatSession"):
        """Run the required background rpcids for anonymous mode history"""
        if not self.anonymous or not chat.cid or not chat.rid:
            return
            
        rpcids = ["PCck7e", "aPya6c", "cYRIkd", "DYBcR", "ku4Jyf"]
        for rpcid in rpcids:
            try:
                source_path = f"/app/{chat.cid}"
                params = {
                    "rpcids": rpcid,
                    "source-path": source_path,
                    "bl": self.bl,
                    "f.sid": self.f_sid,
                    "hl": "vi",
                    "_reqid": str(self.req_id),
                    "rt": "c",
                }
                
                if rpcid == "PCck7e":
                    inner = json.dumps([chat.rid, chat.rcid] if chat.rid else [])
                elif rpcid == "aPya6c":
                    inner = "[]"
                elif rpcid in ["cYRIkd", "DYBcR"]:
                    inner = json.dumps(["vi"])
                elif rpcid == "ku4Jyf":
                    inner = json.dumps(["vi", None, None, None, 4, None, None, [2, 3, 7, 17], None, []])
                else:
                    inner = "[]"
                    
                payload = [[[rpcid, inner, None, "generic"]]]
                # Use current at_token if access_token is empty
                at_val = self.access_token if self.access_token else self.at_token
                
                await self.client.post(
                    Endpoint.BATCH_EXEC,
                    params=params,
                    data={"at": at_val, "f.req": json.dumps(payload)}
                )
                self.req_id += 100000
            except:
                pass

    async def _upload_file(self, file_path: Path) -> str:
        """Internal helper to upload file"""
        if not file_path.exists():
            raise ValueError(f"File not found: {file_path}")
            
        with open(file_path, "rb") as f:
            file_content = f.read()

        # Temporary client for upload if needed, or use main client with different headers
        async with httpx.AsyncClient(proxy=self.proxy, verify=False, timeout=self.timeout) as client:
             response = await client.post(
                 url=Endpoint.UPLOAD.value,
                 headers=Headers.UPLOAD.value,
                 files={"file": (file_path.name, file_content)},
                 follow_redirects=True,
             )
             response.raise_for_status()
             return response.text

    def start_chat(self, **kwargs) -> "ChatSession":
        """
        Bắt đầu phiên chat.
        """
        return ChatSession(geminiclient=self, **kwargs)

    async def close(self, delay: float = 0):
        if delay:
            await asyncio.sleep(delay)
        
        if self.refresh_task:
            self.refresh_task.cancel()
            
        if self.client:
            await self.client.aclose()


class ChatSession:
    def __init__(
        self,
        geminiclient: GeminiClient,
        metadata: List[str | None] | None = None,
        cid: str | None = None,
        rid: str | None = None,
        rcid: str | None = None,
        model: Union[str, Dict] = "Unspecified",
        gem: Union["Gem", str, None] = None,
    ):
        self.geminiclient = geminiclient
        self.__metadata = [None, None, None]

        if metadata:
            self.metadata = metadata
        if cid: self.cid = cid
        if rid: self.rid = rid
        if rcid: self.rcid = rcid
        
        self.model = model
        self.gem = gem
        self.last_output: Optional[ModelOutput] = None

    def choose_candidate(self, index: int) -> ModelOutput:
        """
        Choose a candidate from the last `ModelOutput`.
        """
        if not self.last_output:
            raise ValueError("No previous output data found in this chat session.")

        if index >= len(self.last_output.candidates):
            raise ValueError(
                f"Index {index} exceeds the number of candidates in last model output."
            )

        self.last_output.chosen = index
        self.rcid = self.last_output.rcid
        return self.last_output


    @property
    def metadata(self):
        return self.__metadata

    @metadata.setter
    def metadata(self, value: List[str]):
        if len(value) > 3:
             # Logic gốc raise ValueError, ta cũng vậy
             raise ValueError("Metadata too long")
        self.__metadata[:len(value)] = value

    @property
    def cid(self): return self.__metadata[0]
    @cid.setter
    def cid(self, value): self.__metadata[0] = value

    @property
    def rid(self): return self.__metadata[1]
    @rid.setter
    def rid(self, value): self.__metadata[1] = value

    @property
    def rcid(self): return self.__metadata[2]
    @rcid.setter
    def rcid(self, value): self.__metadata[2] = value

    async def send_message(
        self,
        prompt: str,
        files: List[Union[str, Path]] | None = None,
        **kwargs,
    ) -> ModelOutput:
        output = await self.geminiclient.generate_content(
            prompt=prompt,
            files=files,
            model=self.model,
            gem=self.gem,
            chat=self,
            **kwargs
        )
        self.last_output = output
        return output
