from dataclasses import dataclass, field
from typing import Any, List, Optional

@dataclass
class WebImage:
    url: str
    title: str = ""
    alt: str = ""
    proxy: Optional[str] = None

@dataclass
class GeneratedImage:
    url: str
    title: str = ""
    alt: str = ""
    proxy: Optional[str] = None
    cookies: Optional[dict] = None

@dataclass
class Candidate:
    rcid: str
    text: str
    thoughts: Optional[str] = None
    web_images: List[WebImage] = field(default_factory=list)
    generated_images: List[GeneratedImage] = field(default_factory=list)

@dataclass
class ModelOutput:
    metadata: List[str]
    candidates: List[Candidate]
    chosen: int = 0

    @property
    def text(self) -> str:
        if not self.candidates:
            return ""
        return self.candidates[self.chosen].text

    @property
    def images(self) -> List[GeneratedImage]:
        if not self.candidates:
            return []
        return self.candidates[self.chosen].generated_images
    
    @property
    def rcid(self) -> str:
        if not self.candidates:
            return ""
        return self.candidates[self.chosen].rcid


    def __str__(self):
        return self.text

@dataclass
class Gem:
    id: str
    name: str
    description: str = ""
    prompt: str = ""
    predefined: bool = False
    

    def __str__(self):
        return self.name

class GemJar(dict):
    """
    Helper class for handling a collection of `Gem` objects, stored by their ID.
    """
    
    def get(
        self, id: str | None = None, name: str | None = None, default: "Gem | None" = None
    ) -> "Gem | None":
        if id is not None:
            gem = super().get(id)
            if gem:
                if name is not None and gem.name != name:
                    return default
                return gem
            return default
        elif name is not None:
             for gem in self.values():
                 if gem.name == name:
                     return gem
             return default
        return default

    def filter(self, predefined: bool | None = None, name: str | None = None) -> "GemJar":
        filtered = GemJar()
        for gid, gem in self.items():
            if predefined is not None and gem.predefined != predefined:
                continue
            if name is not None and gem.name != name:
                continue
            filtered[gid] = gem
        return filtered

@dataclass
class RPCData:
    rpcid: str
    payload: str
    identifier: str = "generic"

    def serialize(self) -> list:
        return [self.rpcid, self.payload, None, self.identifier]

