class GeminiError(Exception):
    """Base exception for Gemini-WebCookie."""
    pass

class APIError(GeminiError):
    pass

class AuthError(GeminiError):
    pass

class TimeoutError(GeminiError):
    pass
