# Gemini-WebCookie

A powerful and flexible library for interacting with Google Gemini Web, supporting both Cookie-based and **Anonymous (No-Cookie)** modes.

## Highlights (From Version 0.1.4)

Starting from version `0.1.4`, Gemini-WebCookie is no longer just a replacement for `Gemini-WebAPI` but has evolved with powerful independent features:

- **Anonymous Mode**: Operates completely without cookies (`__Secure-1PSID`).
- **Context Preservation**: Automatically manages chat history (CID, RID, RCID) even in anonymous mode.
- **Background Auto-Refresh**: System automatically updates tokens and maintains sessions in the background.
- **Full Feature Support**: Chat, Image Generation, Gems Management, and File Uploads.

## Installation

```bash
pip install gemini-webcookie
```

## Usage

### 1. Anonymous Mode (No Cookies Required)

This is a major feature that goes beyond standard Gemini wrappers:

```python
import asyncio
from gemini_webcookie import GeminiClient

async def main():
    # Initialize without parameters for anonymous mode
    client = GeminiClient()
    await client.init()
    
    chat = client.start_chat()
    response = await chat.send_message("Hello, who are you?")
    print(f"AI: {response.text}")
    
    # Context is automatically preserved for the next question
    response2 = await chat.send_message("What can you help me with?")
    print(f"AI: {response2.text}")

    await client.close()

asyncio.run(main())
```

### 2. Cookie-based Mode (Full Features)

```python
from gemini_webcookie import GeminiClient

client = GeminiClient(
    secure_1psid="YOUR_1PSID",
    secure_1psidts="YOUR_1PSIDTS"
)
```

## License

This project is dual-licensed under the **MIT License** and the **Apache License 2.0**. You may choose either license according to your needs.
