# Application Development Memory Graph Framework

## Purpose

This framework defines how to capture the **journey** of building applications - not just what was built, but how understanding evolved, what mistakes were made, what principles emerged, and how decisions felt. The goal is to escape the "starting fresh" delusion where developers forget their journey and repeat mistakes.

**Core Insight:** Knowledge evolved from knowledge is the only true knowledge. Isolated facts are inert data.

---

## Philosophical Foundation

### Temporal Causality

Every piece of knowledge exists in time. There is no knowledge that exists independent of when it was discovered, what preceded it, or what it influenced. The graph must preserve this temporal structure in **relationships**, not just text annotations.

### Epistemology Emerges from Ontology

We don't impose structure top-down ("this is the optimization phase"). We capture base reality (sessions, decisions, challenges) and let structure emerge from queries. If you want to know "what phases did we go through?" - traverse the graph. The answer emerges from the relationships.

### Affective Quality is Foundational

How decisions *felt* - the frustration before a breakthrough, the relief when tests finally passed, the embarrassment of discovering inefficiency - is not separate from knowledge. It IS part of what makes that knowledge meaningful. Capture it on any node where it influenced the outcome.

### Cross-Project Knowledge Evolution

A project is just another node. Knowledge doesn't respect project boundaries. When you use streaming in Project B because you learned it in Project A, that decision EVOLVES_FROM the original. The graph captures this causal chain across projects.

---

## MCP Tools Available

The `mem-appdev` MCP server provides these tools:

| Tool | Purpose |
|------|---------|
| `create_entities` | Create new nodes with name, type, and observations |
| `create_relations` | Create directed relationships between entities |
| `add_observations` | Append facts to existing entities |
| `search_memories` | Fulltext search across entities |
| `find_memories_by_name` | Exact name lookup |
| `delete_entities` / `delete_observations` / `delete_relations` | Cleanup operations |

---

## Entity Types

### DevelopmentSession

**Purpose:** Temporal anchor for a working session. Every other entity from that day links to this.

**Naming Convention:** `Session_YYYY-MM-DD` or `Session_YYYY-MM-DD_{topic}` if multiple sessions per day.

**Required Observations:**
- Date
- Duration (approximate)
- Type (implementation, debugging, optimization, exploration, etc.)
- Contributors
- Primary deliverables or focus

**Affective Observations:**
- How the session felt overall
- Key emotional moments (frustration, breakthrough, relief)
- What drove decisions beyond pure logic

**Example:**
```
Name: Session_2025-12-01
Type: DevelopmentSession
Observations:
  - "Date: 2025-12-01"
  - "Duration: ~4 hours"
  - "Type: Performance optimization, architectural refactoring"
  - "Contributors: Conor, Claude, Brad (email catalyst)"
  - "Affective quality: Discovery energy - finding that 90% of work was unnecessary felt revelatory"
  - "Key quote: 'Batches are for people who create silly Power BIs for team meetings'"
```

### Project

**Purpose:** The application or system being built. Just another node - not a container.

**Naming Convention:** `ProjectName` or `Project_ShortName`

**Key Observations:**
- What it is and why it exists
- When it started
- Core philosophy or driving insight
- Current status

**Cross-Project Note:** Multiple sessions can WORKS_ON the same project. When a new project starts, create a new Project entity. Knowledge (decisions, insights, principles) can link across projects via EVOLVED_FROM.

### Decision

**Purpose:** A choice that was made with its rationale.

**Naming Convention:** `Decision_ShortDescription`

**Required Observations:**
- When it was made
- Context (what problem or question prompted it)
- The decision itself
- Rationale (numbered if multiple reasons)
- Alternatives considered and why rejected

**Affective Observations:**
- How confident the decision felt
- Any hesitation or reservations
- Whether it "felt right" beyond logic

**Example:**
```
Name: Decision_StreamingOverBatching
Type: Decision
Observations:
  - "Made: 2025-12-01"
  - "Context: Even with query optimization, 16s pagination overhead remained"
  - "Decision: Replace job-based batch retrieval with streaming export mode"
  - "Rationale 1: No waiting for 'complete batch' - data streams as discovered"
  - "Rationale 2: Aligns with ontology philosophy - capture the moment, then move on"
  - "Alternatives considered: Keep batching with smaller batches (rejected - still has overhead)"
  - "This felt philosophically right, not just technically better"
```

### Insight

**Purpose:** An "aha" moment - something learned that changes understanding.

**Naming Convention:** `Insight_ShortDescription`

**Required Observations:**
- When discovered
- Context (what you were doing when it clicked)
- The insight itself
- How it was discovered
- Generalizability (project-specific, domain-specific, or universal)

**Affective Observations:**
- How the insight arrived (sudden clarity, gradual recognition, painful realization)
- Emotional weight (mild, significant, transformative)

### Challenge

**Purpose:** A problem or blocker that was faced.

**Naming Convention:** `Challenge_ShortDescription`

**Required Observations:**
- When encountered
- Context
- What made it challenging
- How it manifested (symptoms)
- Resolution (link to Decision, Insight, or describe directly)

**Affective Observations:**
- How frustrating or difficult it felt
- Any moments of being stuck

### Mistake

**Purpose:** Something that went wrong and what was learned from it.

**Naming Convention:** `Mistake_ShortDescription`

**Required Observations:**
- When it occurred
- Description of what went wrong
- Root cause
- How it was discovered
- Time/cost of the mistake
- What was learned (link to Insight if applicable)

**Affective Observations:**
- How it felt to discover the mistake
- Any reluctance to acknowledge it

**Note:** Mistakes are epistemologically valuable. Don't skip them out of embarrassment.

### Principle

**Purpose:** A core belief or rule that guides decisions across contexts.

**Naming Convention:** `Principle_ShortName`

**Required Observations:**
- The principle stated clearly
- How/when it emerged
- Why it matters
- Implications for decision-making

**Note:** Principles are often born from painful experience. Link them to the mistakes or challenges that birthed them.

### Artifact

**Purpose:** Something created - code, documentation, configuration.

**Naming Convention:** `Artifact_Name_vN` where N is version number

**Required Observations:**
- When created
- File(s) involved
- Purpose
- Key characteristics
- What decisions led to this artifact

**Evolution:** When an artifact changes significantly, create a new version and link via EVOLVED_INTO. This preserves the history of how implementations changed.

### Catalyst

**Purpose:** An external trigger that prompted change - an email, a bug report, user feedback.

**Naming Convention:** `Catalyst_ShortDescription`

**Required Observations:**
- Date
- Source (who/what)
- Summary of the trigger
- What it prompted

**Note:** Catalysts are important for understanding causality. "Why did we make this change?" often traces back to an external catalyst.

---

## Relationship Types

### Temporal Chain
| Relation | Meaning |
|----------|---------|
| `NEXT_SESSION` | Links consecutive DevelopmentSession nodes |

### Session Connections
| Relation | Meaning |
|----------|---------|
| `WORKS_ON` | Session -> Project |
| `PRODUCED` | Session -> Decision, Insight, Artifact, Mistake |
| `DISCOVERED` | Session -> Insight |
| `FACED` | Session -> Challenge |

### Causal Flow
| Relation | Meaning |
|----------|---------|
| `TRIGGERED` | Catalyst -> Session or Decision |
| `RESOLVED_BY` | Challenge -> Decision or Insight |
| `LED_TO` | Decision -> Artifact; Insight -> Principle; Mistake -> Principle |
| `EVOLVED_INTO` | Artifact_v1 -> Artifact_v2; OldUnderstanding -> NewUnderstanding |
| `EVOLVED_FROM` | (Reverse of EVOLVED_INTO - use when creating the newer node) |

### Philosophical Grounding
| Relation | Meaning |
|----------|---------|
| `GUIDED_BY` | Decision -> Principle (this principle informed this decision) |
| `VIOLATED` | Mistake -> Principle (this mistake violated this principle) |
| `HONORED` | Decision -> Principle (this decision successfully applied this principle) |

### Cross-Project
| Relation | Meaning |
|----------|---------|
| `SIMILAR_TO` | Challenge -> Challenge (across projects) |
| `APPLIES_PATTERN` | Decision -> earlier Decision it learned from |

---

## Session Protocol

### Starting a New Session

1. **Create the DevelopmentSession entity first**
   ```
   Name: Session_YYYY-MM-DD
   Type: DevelopmentSession
   Observations: [date, type, contributors, initial focus]
   ```

2. **Link to Project**
   ```
   Session_YYYY-MM-DD -[WORKS_ON]-> ProjectName
   ```

3. **Link to Previous Session** (if continuing work)
   ```
   Session_Previous -[NEXT_SESSION]-> Session_YYYY-MM-DD
   ```

### During the Session

As work progresses, create entities for:
- **Decisions** made (with rationale)
- **Challenges** encountered
- **Insights** discovered
- **Artifacts** created or modified

Link them to the session:
```
Session -[PRODUCED]-> Decision
Session -[FACED]-> Challenge
Session -[DISCOVERED]-> Insight
```

### Ending a Session

Add closing observations to the session:
- Summary of what was accomplished vs. intended
- What felt significant (not just what was done)
- Open questions or next steps

---

## Cross-Project Knowledge Evolution

When starting a new project that builds on prior knowledge:

1. **Create the new Project entity**

2. **When making decisions informed by prior work:**
   - Create the Decision in the new project's session
   - Add observation: "Informed by [prior decision/insight]"
   - Create relation: `NewDecision -[EVOLVED_FROM]-> PriorDecision`

3. **When facing similar challenges:**
   - Create the Challenge
   - Create relation: `NewChallenge -[SIMILAR_TO]-> PriorChallenge`
   - Check if prior resolution applies

4. **When principles from prior work apply:**
   - Create relation: `NewDecision -[GUIDED_BY]-> ExistingPrinciple`
   - If the principle proves valuable again, add observation to the Principle

**Example:**
```
# In ServiceNow project, choosing streaming architecture
Decision_ServiceNow_Streaming -[EVOLVED_FROM]-> Decision_StreamingOverBatching
Decision_ServiceNow_Streaming -[GUIDED_BY]-> Principle_TemporalCausality
```

The graph now shows that streaming in ServiceNow wasn't invented fresh - it descended from FortiGate learning.

---

## Querying the Graph

### Find Phases (Emergent)
```
"Show me sessions where the primary challenge was [X]"
"Show me sessions that produced principles"
"Show me sessions that faced challenges"
```
Phases emerge from the patterns in relationships, not imposed labels.

### Trace Knowledge Evolution
```
"How did the extractor artifact evolve?"
-> Follow EVOLVED_INTO chain: v1 -> v2 -> v3

"What decisions were guided by temporal causality?"
-> Find all decisions with GUIDED_BY -> Principle_TemporalCausality
```

### Cross-Project Learning
```
"What challenges in Project B were similar to Project A?"
-> Find SIMILAR_TO relations between challenges

"What decisions evolved from other projects?"
-> Find EVOLVED_FROM relations crossing project boundaries
```

### Find Painful Lessons
```
"What mistakes did we make?"
"What principles came from mistakes?"
-> Follow Mistake -[LED_TO]-> Principle
```

---

## Best Practices

### Be Honest About Affective State
- Don't sanitize the frustration out of challenges
- Record when something "felt wrong" even if you couldn't articulate why
- Note embarrassment, relief, excitement - these are epistemologically meaningful

### Capture the Negative Path
- Record alternatives you considered and rejected
- Note when you went down a wrong path before finding the right one
- Mistakes are as valuable as successes for future learning

### Link Across Time
- When today's decision relates to last week's insight, create the relationship
- When a new project reuses old learning, make that explicit
- The value of the graph is in the connections, not the isolated nodes

### Preserve Quotes
- When someone says something that captures an insight perfectly, quote it
- "Batches are for people who create silly Power BIs" is more memorable than "streaming is better than batching"
- Quotes preserve voice and context

### Version Artifacts
- Don't overwrite - create v2, v3, etc.
- The evolution chain (v1 -> v2 -> v3) tells a story
- What changed between versions is often more informative than the final state

---

## Starting Fresh on a New Project

1. **Search for relevant prior knowledge:**
   ```
   search_memories("streaming batching")
   search_memories("schema alignment")
   search_memories("splunk integration")
   ```

2. **Review principles that might apply:**
   ```
   search_memories("Principle")
   ```

3. **Create new Project entity**

4. **Create first Session and link:**
   - WORKS_ON -> new Project
   - Review prior challenges/decisions that might be relevant

5. **As you work, link back:**
   - EVOLVED_FROM prior decisions
   - GUIDED_BY existing principles
   - SIMILAR_TO prior challenges

---

## The Fundamental Truth

There is no such thing as "starting fresh." Every developer brings their history into every project. The question is whether that history is:

- **Implicit:** Forgotten, repeated mistakes, rediscovered lessons
- **Explicit:** Captured in a graph, queryable, building on itself

This framework makes the implicit explicit. The journey is in the graph. You just have to follow it.

---

*Framework Version: 1.0*
*Created: 2025-12-04*
*Based on: FortiGate ETL Pipeline development journey (Nov 24 - Dec 2, 2025)*
