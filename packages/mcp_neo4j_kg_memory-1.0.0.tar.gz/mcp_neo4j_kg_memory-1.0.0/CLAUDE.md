# mcp-neo4j-kg-memory — Development Guide

## Current State (v1.0.0)

Unified Neo4j Knowledge Graph MCP Server — 15 tools in 4 categories:

| Category | Tools | Count |
|----------|-------|-------|
| CRUD | create_entities, create_relations, add_observations, delete_entities, delete_observations, delete_relations | 6 |
| Query | search_memories, find_memories_by_name | 2 |
| Cypher | get_neo4j_schema, read_neo4j_cypher | 2 |
| GDS | gds_create_projection, gds_drop_projection, gds_pagerank, gds_louvain, gds_wcc | 5 |

**Package:** `mcp-neo4j-kg-memory` on PyPI
**Internal module:** `mcp_neo4j_memory` (unchanged)
**Entry point:** `mcp-neo4j-kg-memory` CLI

## Architectural Principles

### Bounded Traversal
All query tools implement bounded traversal to prevent context window exhaustion:
- `search_memories`: limit param (default 10, max 50)
- `find_memories_by_name`: limit param (default 20, max 50)
- `read_neo4j_cypher`: read-only guard + timeout + 200k char truncation
- GDS tools: result_limit param (default 20, max 1000)
- Relationships constrained to only returned entities (WHERE...IN pattern)

### No Write Cypher
`write_neo4j_cypher` is intentionally excluded. All mutations go through bounded CRUD tools to preserve temporal invariants. This is a permanent design decision.

### Result Sanitization
`_value_sanitize()` strips embedding-like lists (128+ elements) from Cypher results. Prevents vector embeddings from polluting LLM context.

## Key Files

| File | Purpose |
|------|---------|
| `src/mcp_neo4j_memory/server.py` | MCP tool definitions (15 tools), FastMCP server setup |
| `src/mcp_neo4j_memory/neo4j_memory.py` | Neo4jMemory class, Pydantic models, Cypher queries |
| `src/mcp_neo4j_memory/utils.py` | Config processing, `_is_write_query`, `_value_sanitize` |
| `src/mcp_neo4j_memory/__init__.py` | CLI entry point, argparse |
| `tests/unit/test_server.py` | Namespace and tool count tests |
| `tests/unit/test_utils.py` | Config processing tests |

## Testing

```bash
# Unit tests (no Neo4j required)
uv run pytest tests/unit/ -v

# Integration tests (requires Neo4j via testcontainers)
uv run pytest tests/integration/ -v

# Build
uv build
```

## Phase 2 Hints — Temporal Metadata

Future work may add temporal metadata to the knowledge graph:
- Timestamp fields on Memory nodes (created_at, updated_at)
- Temporal relationship types (NEXT_DAY, EVOLVED_FROM)
- Time-bounded queries (search within date ranges)
- Temporal chain traversal tools

These would be additive — no existing tools change.
