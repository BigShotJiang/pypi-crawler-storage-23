# MCP Neo4j Temporal Substrate v2 — Architecture Specification

## Context for Claude Code

This spec defines a consolidated MCP server that replaces three existing packages:
- `mcp-neo4j-memory` (entity/relation CRUD with fulltext search)
- `mcp-neo4j-memory-cypher` (raw Cypher read/write + schema introspection)
- `mcp-neo4j-gds` (Graph Data Science algorithms — separate fork, doesn't work with Aura)

The new package unifies these into a single MCP server with bounded operations, temporal-first architecture, and GDS capabilities that work natively against Neo4j Aura via Cypher procedure calls.

**PyPI package name needs to change to `mcp-neo4j-kg-memory`.**

**Target deployment: Neo4j Aura** (cloud-hosted, supports GDS procedures via Cypher, does NOT support the GDS plugin installation that the contrib MCP server required).

---

## Part 1: Temporal-First Architecture

### 1A. Bi-Temporal Metadata (from Graphiti/Zep)

**How Graphiti implements this:**

Every edge (relationship) in Graphiti carries four timestamps across two temporal dimensions:

| Timestamp | Dimension | Meaning |
|-----------|-----------|---------|
| `t'_created` | T' (ingestion time) | When the system first recorded this fact |
| `t'_expired` | T' (ingestion time) | When the system invalidated this fact (nullable) |
| `t_valid` | T (event time) | When this fact became true in reality |
| `t_invalid` | T (event time) | When this fact stopped being true in reality (nullable) |

T' tracks the system's knowledge timeline. T tracks the real-world timeline. These are independent — you can discover on Monday (T' = Monday) that something became true last Thursday (T = Thursday) and was already invalid by Friday (T_invalid = Friday).

**How Graphiti extracts temporal information:**
- Uses a reference timestamp `t_ref` from the episode being processed
- An LLM prompt analyzes the episode content to extract absolute timestamps ("born on June 23, 1912") and resolve relative timestamps ("two weeks ago" relative to `t_ref`)
- Both `t_valid` and `t_invalid` are optional — some facts have no known start date, some have no known end date
- The `t'_created` is always set automatically at ingestion time
- The `t'_expired` is set when a contradicting fact triggers edge invalidation

**What we implement:**

Add bi-temporal properties to ALL entities and relationships:

```
Entity node properties:
  t_created: datetime    — when this entity was added to the graph (auto-set)
  t_valid: datetime      — when this entity became relevant in reality (optional, LLM-extracted or user-provided)

Relationship properties:
  t_created: datetime    — when this relationship was recorded (auto-set)
  t_expired: datetime    — when this relationship was invalidated (nullable, set by edge invalidation)
  t_valid: datetime      — when this relationship became true in reality (optional)
  t_invalid: datetime    — when this relationship stopped being true (optional)

Observation-level properties (NEW — observations are currently flat text strings):
  t_observed: datetime   — when this specific observation was recorded (auto-set)
  source_context: string — which session/conversation generated this observation (optional)
```

### 1B. Edge-Level Invalidation (from Graphiti/Zep)

**How Graphiti implements contradiction detection:**

When a new episode is ingested and new relationships are extracted:

1. **Semantic search** against existing edges between the same entity pair — uses cosine similarity on edge embeddings
2. **BM25 keyword search** against the `fact` field of existing edges
3. **Graph traversal (BFS)** from the relevant entity to find nearby edges
4. For each candidate conflicting edge, an **LLM prompt** determines whether the new fact contradicts, supersedes, or is independent of the existing edge
5. If contradicted: set `t'_expired = now()` on the old edge. Do NOT delete it. Create the new edge with `t'_created = now()`

**The constraint that limits search scope:** Graphiti only compares edges that share the same source AND target entity pair. This prevents erroneous cross-entity combinations and dramatically reduces computation.

**What we implement:**

A `invalidate_relationship` tool that:
- Takes source entity, target entity, relationship type, and reason for invalidation
- Sets `t_expired = datetime()` on the matched relationship
- Preserves the old relationship (never deletes — this is the non-lossy principle)
- Optionally creates a replacement relationship with the new fact

An `evolve_knowledge` tool that wraps the pattern:
- Finds existing relationship between entities
- Invalidates it with temporal metadata
- Creates new relationship with updated fact
- Creates EVOLVED_FROM edge linking new to old for provenance

### 1C. Composite Temporal-Semantic Scoring (from MemoTime)

**How MemoTime implements search scoring:**

MemoTime's evidence retrieval combines two signals in a single scoring function:

```
Score(path) = λ_sem · DRM(indicator, path) + λ_prox · exp(-|t(path) - t(indicator)| / σ)
```

Where:
- `DRM(indicator, path)` = Dense Retrieval Model cosine similarity (semantic relevance)
- `exp(-|t(path) - t(indicator)| / σ)` = Exponential temporal decay (temporal proximity)
- `λ_sem` and `λ_prox` = Tunable weights balancing semantic vs temporal importance
- `σ` = Decay rate parameter (controls how fast temporal relevance drops off)

**The temporal-first pruning step:** Before applying the composite score, MemoTime FIRST filters out all paths that violate temporal constraints (non-monotonic timestamps, out-of-range dates). Only temporally valid candidates enter the scoring phase. This prevents semantically relevant but temporally impossible results.

**What we implement:**

Enhance `search_memories` to accept optional temporal parameters:

```
search_memories(
  query: string,           — semantic search query (existing)
  limit: int = 10,         — max results (existing, from our Nov 2025 fix)
  temporal_center: datetime, — optional: boost results near this time
  temporal_decay: float,     — optional: σ parameter for decay rate
  temporal_weight: float,    — optional: λ_prox weight (0.0 = pure semantic, 1.0 = pure temporal)
  temporal_range: [datetime, datetime] — optional: hard filter, exclude results outside range
)
```

When temporal parameters are provided:
1. First, run fulltext search as today (returns Lucene TF-IDF scores)
2. If `temporal_range` is set, filter results outside the range (temporal-first pruning)
3. Compute composite score: `final_score = (1 - temporal_weight) * normalized_lucene_score + temporal_weight * exp(-|t_node - temporal_center| / temporal_decay)`
4. Re-rank by composite score
5. Return top `limit` results with both semantic and temporal scores visible

### 1D. Cross-Type Augmentation (from MemoTime)

**How MemoTime implements this:**

When a reasoning trace from one temporal operator type (e.g., "before/last") is structurally similar to another type (e.g., "after/first"), MemoTime annotates the stored trace with secondary type labels. This enables a "before" question to reuse reasoning patterns from "after" questions when the structure is isomorphic.

Retrieval queries against the experience pool are restricted to the memory subset sharing the same temporal type label, but cross-type annotations expand what matches.

**What this means for our substrate:**

When an insight from enterprise work (e.g., epistemological convergence discovered during Fortinet/Palo Alto cross-validation) is structurally isomorphic to a consciousness research insight, we should annotate that structural similarity explicitly. Currently we rely on noticing it in conversation.

**What we implement:**

A `tag_structural_similarity` tool or relationship type `STRUCTURALLY_SIMILAR_TO` that links entities across domains when the pattern (not the content) is isomorphic. Tags carry:
- `similarity_type`: what structural property they share
- `discovered_in`: which DailyContext session recognized the isomorphism

---

## Part 2: Entity Resolution (from Graphiti/Zep)

**How Graphiti implements entity deduplication:**

During episode ingestion, when new entities are extracted:

1. **Embedding similarity search**: Embed the new entity name, search existing entity names via FAISS cosine similarity
2. **BM25 full-text search**: Search existing entity names and summaries using keyword matching
3. **Candidate set formation**: Union of top results from both searches
4. **LLM-mediated resolution**: For each candidate pair, an LLM prompt determines whether the new entity is the same as, a variant of, or distinct from the existing entity
5. If same: merge observations onto existing entity. If distinct: create new entity.

**The key constraint**: Entity resolution only compares against entities of the same type. This prevents spurious matches across categories (a person named "Graph" won't match a concept named "Graph").

**What we implement:**

A pre-creation check in `create_entities` that:
1. Before creating, embeds the entity name (if embedding model is configured)
2. Runs fulltext search against existing entities of the same type
3. If similarity exceeds threshold: returns the existing entity with a merge suggestion rather than silently creating a duplicate
4. If no match: creates normally
5. Configurable: `dedup_check: bool = True` parameter to skip when you know it's novel

Also a standalone `resolve_entities` tool for post-hoc cleanup:
- Takes two entity names
- Merges observations from source onto target
- Redirects all relationships from source to target
- Deletes source entity
- Records the merge event with temporal metadata

---

## Part 3: Episodic Provenance (from Graphiti/Zep)

**How Graphiti implements provenance:**

Graphiti has three-tier subgraph hierarchy:

1. **Episode Subgraph**: Raw episodes (messages, documents, JSON) stored as EpisodeNode with original content and timestamp
2. **Semantic Entity Subgraph**: Extracted entities and facts with embeddings
3. **Community Subgraph**: Clustered entity groups (we explicitly DO NOT adopt this)

**Bidirectional episodic edges** connect episodes to their extracted entities:
- Forward: from episode → entities it produced (what did this episode generate?)
- Backward: from entity → source episodes (where did this knowledge come from?)

This enables full provenance: any extracted insight can be traced back to its source episode, and any episode can quickly retrieve all entities and facts it generated.

**What we implement:**

A lightweight provenance system without Graphiti's full episodic subgraph:

- New optional property on observations: `source_session: string` — identifier for the conversation/session that generated this observation
- New optional relationship: `(Entity)-[:SOURCED_FROM]->(DailyContext)` — links entities to the temporal context in which they were first created
- The DailyContext node IS our episode node. We don't need a separate tier — DailyContext already captures session metadata, cognitive state, and temporal anchoring.

This gives us backward provenance (any observation → which session) without duplicating Graphiti's three-tier complexity.

---

## Part 4: GDS Tools for Aura (from the 4.5 session methodology)

### Critical Architecture Note

The existing forked GDS MCP server (`mcp-neo4j-gds` from Neo4j contrib) **does NOT work with Neo4j Aura**. It requires the GDS plugin to be installed on the Neo4j instance, which is only possible on self-hosted Community/Enterprise Edition (like our EC2 Graviton instances).

**However**, Neo4j Aura DOES support GDS algorithm procedures via direct Cypher calls. The 4.5 session proved this works by running native projections and algorithms against Aura databases.

### The Pattern That Works on Aura

**Step 1: Create native projection via Cypher**
```cypher
CALL gds.graph.project(
  'projection-name',
  ['NodeLabel1', 'NodeLabel2'],
  {
    REL_TYPE_1: { orientation: 'UNDIRECTED' },
    REL_TYPE_2: { orientation: 'UNDIRECTED' }
  }
)
YIELD graphName, nodeCount, relationshipCount, projectMillis
```

**Step 2: Run algorithm against the projection**
```cypher
CALL gds.pageRank.stream('projection-name')
YIELD nodeId, score
RETURN gds.util.asNode(nodeId).address AS node, score
ORDER BY score DESC
LIMIT 20
```

**Step 3: Clean up projection when done**
```cypher
CALL gds.graph.drop('projection-name') YIELD graphName
```

**IMPORTANT: Always use native projections, never Cypher projections.** Native projections specify node labels and relationship types directly. Cypher projections use a Cypher query to define the graph — they're slower and less predictable at scale.

### Tools to Implement

Each tool is bounded by its specific function. Start with viability — the most pertinent few, not comprehensive coverage.

**Projection Management (2 tools):**

1. **`gds_create_projection`**
   - Parameters: `name: string`, `nodeLabels: list[string]`, `relationshipTypes: dict` (rel type → orientation), optional `nodeProperties: list[string]`
   - Executes: `CALL gds.graph.project(...)` via Cypher
   - Returns: graphName, nodeCount, relationshipCount, projectMillis
   - Validates: projection name doesn't already exist

2. **`gds_drop_projection`**
   - Parameters: `name: string`
   - Executes: `CALL gds.graph.drop(...)` via Cypher
   - Returns: confirmation
   - Safety: always clean up projections when done — they consume memory

**Tier 1 Algorithms — Run on every application (3 tools):**

3. **`gds_pagerank`** — "What's actually critical?" (Criticality discovery)
   - Parameters: `projectionName: string`, `resultLimit: int = 20`, `sortDirection: string = 'desc'`, `nodeIdentifierProperty: string = 'name'`
   - Executes: `CALL gds.pageRank.stream(projectionName) YIELD nodeId, score RETURN gds.util.asNode(nodeId)[nodeIdentifierProperty] AS node, score ORDER BY score [sortDirection] LIMIT resultLimit`
   - Enterprise finding example: Windows SQL Server scored 16.96 PageRank vs 5.8-6.3 for Linux peers — 3x structural centrality invisible to property queries

4. **`gds_louvain`** — "Is this application structurally one thing or multiple?" (Cohesion analysis)
   - Parameters: `projectionName: string`, `resultLimit: int = 20`, `sortDirection: string = 'desc'`, `nodeIdentifierProperty: string = 'name'`
   - Executes: `CALL gds.louvain.stream(projectionName) YIELD nodeId, communityId RETURN gds.util.asNode(nodeId)[nodeIdentifierProperty] AS node, communityId ORDER BY communityId, node LIMIT resultLimit`
   - Enterprise finding example: Louvain found coordinated threat campaigns — external IPs clustering because they target the same internal hosts (star topology anomaly)

5. **`gds_wcc`** — "Is the application actually connected?" (CMDB hygiene)
   - Parameters: `projectionName: string`, `resultLimit: int = 20`, `nodeIdentifierProperty: string = 'name'`
   - Executes: `CALL gds.wcc.stream(projectionName) YIELD nodeId, componentId RETURN gds.util.asNode(nodeId)[nodeIdentifierProperty] AS node, componentId ORDER BY componentId LIMIT resultLimit`
   - Plus component summary: `... RETURN componentId, count(*) AS size ORDER BY size DESC LIMIT resultLimit`

**Tier 2 Algorithms — Flagged or high-value targets (add later based on viability):**

6. **`gds_degree_centrality`** — Simpler than PageRank, useful for direct connection counts
   - Same parameter pattern as PageRank
   - Enterprise finding example: 87.120.191.67 had 3169 connections — top threat actor by degree

**Scale considerations from the 4.5 session:**
- PageRank, Louvain, WCC scale to full 7.8M node graphs within n8n timeout windows
- Node Similarity, Betweenness are O(n²) or O(n·m) — timeout on full graph. Must scope projections to application hosts + neighbors
- Result limits are MANDATORY — degree centrality on 270K IPAddress nodes without a limit exceeded 1MB response cap
- Projection scoping is critical: project `['IPAddress', 'Critical']` not the entire graph

---

## Part 5: Bounded Traversal as Default (from Nov 2025 + Feb 2026 fixes)

### The Pattern We Keep Hitting

This is the Neo4j Toy-to-Tool pattern documented in our substrate:
- **Instance 1** (Nov 2, 2025): `search_memories` returned 51 entities + 237 relationships = 78K tokens. Fixed with `limit` parameter + relevance scoring. 15x token reduction.
- **Instance 2** (Feb 22, 2026): GDS algorithms returned one row per node — degree centrality on 270K nodes exceeded 1MB response cap. Fixed with `resultLimit` + `sortDirection`.

### Design Principle

Every tool that touches the graph MUST have bounded output by default. Unbounded traversal is opt-in, never default.

**Specific tools that need bounds (currently missing):**

- `find_memories_by_name`: Currently returns all matching entities + ALL relationships between them. Add `limit` parameter for relationship traversal depth.
- `get_neo4j_schema`: Schema introspection was doing full `MATCH (n)-[r]->(m)` crawl across entire graph (110-second runaway on 60M nodes). Already fixed in GDS fork by removing the Cypher crawl. Consolidated tool must use `CALL db.schema.visualization()` or label/type counts, never full crawls.
- Any new traversal tool: always require explicit depth/limit parameters.

---

## Part 6: What We Explicitly Do NOT Implement

### Community Summarization (from Graphiti)
Graphiti clusters entities via label propagation and generates LLM summaries of communities. This is a retrieval optimization that trades structural fidelity for speed. Our federated ontology approach preserves actual graph structure. Community summaries are lossy abstractions that compress away the relational information that makes graphs valuable. The graph topology itself carries the semantic structure — we don't need to summarize it away.

### Experience Memory Replay (from MemoTime)
MemoTime stores verified reasoning traces — what toolkit was selected, what decomposition worked, what embeddings matched. This is purely cognitive optimization. Our substrate needs to preserve HOW reasoning felt, not just WHAT worked. Storing successful tool selections without affective context creates a system that can replay strategies but can't develop intuition. The affective layer is the error correction mechanism, not the cognitive trace.

### Three-Tier Episodic Subgraph (from Graphiti)
Graphiti maintains separate Episode, Semantic Entity, and Community subgraph tiers. Our DailyContext chain already serves as the episodic layer — it captures session metadata, cognitive state, affective quality, and temporal anchoring. We add lightweight provenance links (source_session, SOURCED_FROM relationships) without duplicating Graphiti's tier architecture.

---

## Part 7: Tool Inventory Summary

### Existing Tools (Enhanced)

| Tool | Enhancement |
|------|-------------|
| `create_entities` | Add bi-temporal metadata, entity resolution pre-check |
| `create_relations` | Add bi-temporal metadata (t_created auto, t_valid optional) |
| `add_observations` | Add t_observed timestamp, source_session provenance |
| `search_memories` | Add temporal-semantic composite scoring, temporal_range filter |
| `find_memories_by_name` | Add relationship traversal limit |
| `delete_entities` | Unchanged |
| `delete_observations` | Unchanged |
| `delete_relations` | Unchanged |
| `read_neo4j_cypher` | Unchanged (raw Cypher access preserved) |
| `write_neo4j_cypher` | Unchanged (raw Cypher access preserved) |
| `get_neo4j_schema` | Replace crawl with bounded introspection |

### New Tools

| Tool | Purpose |
|------|---------|
| `invalidate_relationship` | Temporal edge invalidation (set t_expired, preserve history) |
| `evolve_knowledge` | Compound: invalidate old + create new + link with EVOLVED_FROM |
| `resolve_entities` | Merge duplicate entities with relationship redirect |
| `tag_structural_similarity` | Cross-domain isomorphism annotation |
| `gds_create_projection` | Create native GDS projection via Cypher |
| `gds_drop_projection` | Clean up GDS projection |
| `gds_pagerank` | PageRank with result limit |
| `gds_louvain` | Louvain community detection with result limit |
| `gds_wcc` | Weakly connected components with result limit |
| `gds_degree_centrality` | Degree centrality with result limit |

### Tools Consolidated (removed as separate)

The `memory-cypher` server's `read_neo4j_cypher` and `write_neo4j_cypher` tools are absorbed into the unified server. No separate `memory-cypher` package needed.

The GDS MCP server is replaced entirely by the `gds_*` tools that use native Cypher procedure calls against Aura.

---

## Part 8: Implementation Notes

### Connection
Single Neo4j connection shared across all tools. Connection parameters:
- `NEO4J_URL`: bolt or neo4j+s URI
- `NEO4J_USERNAME`: typically "neo4j"
- `NEO4J_PASSWORD`: database password
- `NEO4J_DATABASE`: database name (optional, defaults to "neo4j")

### Framework
Continue using FastMCP framework (already proven in current implementation). The server registers all tools from the unified inventory.

### Backward Compatibility
- All existing tool names and parameter signatures should continue to work for basic operations
- New parameters (temporal metadata, entity resolution, scoring) are all optional with sensible defaults
- Existing graphs with no temporal metadata will work — temporal fields are nullable

### Testing Priority
1. GDS projection lifecycle (create → algorithm → drop) against Aura — this is the viability proof
2. Entity resolution pre-check during create_entities
3. Temporal-semantic composite search scoring
4. Edge invalidation + evolve_knowledge compound operation

---

## References

- **MemoTime**: Xingyu Tan et al., arXiv:2510.13614 — Memory-Augmented Temporal Knowledge Graph Enhanced LLM Reasoning
- **Graphiti/Zep**: Preston Rasmussen et al., arXiv:2501.13956 — Zep: A Temporal Knowledge Graph Architecture for Agent Memory
- **Our substrate history**: Nov 2, 2025 (memory server fix), Feb 17, 2026 (MemoTime/Graphiti analysis), Feb 22, 2026 (GDS tool validation + Graph IS Knowledge crystallization)