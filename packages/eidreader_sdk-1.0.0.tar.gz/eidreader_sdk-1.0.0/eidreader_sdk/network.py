"""Network utilities: LAN IP detection and port selection."""

from __future__ import annotations

import random
import socket

# Common virtual/container adapter name fragments to filter out
_VIRTUAL_NAMES = frozenset(
    {
        "vethernet",
        "docker",
        "vmnet",
        "utun",
        "bridge",
        "loopback",
        "virtual",
        "hyperv",
        "vbox",
        "npcap",
        "tailscale",
        "zerotier",
    }
)


def get_lan_ip() -> str:
    """Detect the primary LAN IPv4 address.

    Uses the UDP connect trick: opening a UDP socket to an external address
    (without sending anything) forces the OS to select the correct outbound
    interface. Falls back to hostname resolution if that fails.

    Per the spec, loopback (127.x) and link-local (169.254.x) addresses are
    excluded. On complex machines (multiple NICs, Docker, etc.) the developer
    should pass ``host=`` to EIDReaderSession instead.
    """
    # Primary method: UDP connect trick — no packet actually sent
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127.") and not ip.startswith("169.254."):
            return ip
    except Exception:
        pass

    # Fallback: hostname resolution
    try:
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        if ip and ip != "127.0.0.1" and not ip.startswith("169.254."):
            return ip
    except Exception:
        pass

    return "127.0.0.1"


def find_available_port(
    host: str,
    min_port: int = 49152,
    max_port: int = 65535,
    max_attempts: int = 10,
) -> int:
    """Find a random available TCP port in the ephemeral range.

    Attempts up to ``max_attempts`` random ports before raising RuntimeError.
    """
    for _ in range(max_attempts):
        port = random.randint(min_port, max_port)
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, port))
            s.close()
            return port
        except OSError:
            continue
    raise RuntimeError(
        f"Unable to find an available port after {max_attempts} attempts. "
        "Check that your firewall allows incoming connections."
    )
