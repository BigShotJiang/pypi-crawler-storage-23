"""Cryptographic operations: ECDH, HKDF, AES-256-GCM, SAS."""

from __future__ import annotations

import base64
import hmac
import json
import os
from typing import Tuple

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.ec import (
    ECDH,
    SECP256R1,
    EllipticCurvePrivateKey,
    EllipticCurvePublicKey,
    generate_private_key,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.serialization import load_der_public_key


def generate_keypair() -> Tuple[EllipticCurvePrivateKey, EllipticCurvePublicKey]:
    """Generate an ephemeral ECDH P-256 keypair."""
    privkey = generate_private_key(SECP256R1())
    return privkey, privkey.public_key()


def serialize_pubkey(pubkey: EllipticCurvePublicKey) -> str:
    """Serialize a public key to base64url-encoded DER (no padding)."""
    der = pubkey.public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return base64.urlsafe_b64encode(der).rstrip(b"=").decode()


def deserialize_pubkey(b64: str) -> EllipticCurvePublicKey:
    """Deserialize a base64url-encoded DER public key."""
    # Restore padding
    padding = "=" * (4 - len(b64) % 4) if len(b64) % 4 else ""
    der = base64.urlsafe_b64decode(b64 + padding)
    return load_der_public_key(der)


def derive_shared_secret(
    privkey: EllipticCurvePrivateKey,
    phone_pubkey: EllipticCurvePublicKey,
) -> bytes:
    """Perform ECDH to derive the shared secret."""
    return privkey.exchange(ECDH(), phone_pubkey)


def derive_aes_key(shared_secret: bytes, session_id: str) -> bytes:
    """Derive a 256-bit AES key from the shared secret using HKDF-SHA256.

    Uses session_id as the HKDF salt and "eidreader-v1" as the info string,
    ensuring each session produces a unique key even from the same shared secret.
    """
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=session_id.encode("utf-8"),
        info=b"eidreader-v1",
    )
    return hkdf.derive(shared_secret)


def compute_sas(shared_secret: bytes, session_id: str) -> str:
    """Compute the 6-digit Short Authentication String (SAS).

    Both sides independently compute this from the shared secret.
    A MITM attacker cannot forge it without knowing both private keys.

    Returns a string like "482 931" (two 3-digit groups).
    """
    mac = hmac.new(shared_secret, session_id.encode("utf-8"), "sha256").digest()
    sas_int = int.from_bytes(mac[0:3], "big") % 1_000_000
    raw = f"{sas_int:06d}"
    return f"{raw[:3]} {raw[3:]}"


def decrypt_payload(aes_key: bytes, payload: dict) -> dict:
    """Decrypt an AES-256-GCM encrypted DATA message payload.

    The GCM authentication tag is appended to the ciphertext by the phone
    (tag_included: true), so AESGCM.decrypt() handles tag verification automatically.
    """
    nonce = base64.urlsafe_b64decode(payload["nonce"] + "==")
    ciphertext = base64.urlsafe_b64decode(payload["ciphertext"] + "==")
    aesgcm = AESGCM(aes_key)
    plaintext = aesgcm.decrypt(nonce, ciphertext, None)
    return json.loads(plaintext)


def encrypt_payload(aes_key: bytes, plaintext_dict: dict) -> dict:
    """Encrypt a payload with AES-256-GCM (for testing / phone-side simulation).

    Returns the payload dict suitable for embedding in a DATA message.
    """
    nonce = os.urandom(12)
    aesgcm = AESGCM(aes_key)
    plaintext = json.dumps(plaintext_dict).encode("utf-8")
    ciphertext = aesgcm.encrypt(nonce, plaintext, None)  # GCM tag appended
    return {
        "nonce": base64.urlsafe_b64encode(nonce).rstrip(b"=").decode(),
        "ciphertext": base64.urlsafe_b64encode(ciphertext).rstrip(b"=").decode(),
        "tag_included": True,
    }
