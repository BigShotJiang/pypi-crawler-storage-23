"""QR code PNG generation from a URI string."""

from __future__ import annotations

import io


def generate_qr_png(uri: str) -> bytes:
    """Generate a QR code PNG from the given URI string.

    Returns raw PNG bytes. Requires the ``qrcode`` package.
    Install with: ``pip install 'qrcode[pil]'`` for best results,
    or ``pip install qrcode`` for the pure-Python PNG backend.
    """
    try:
        import qrcode  # type: ignore[import]
    except ImportError as exc:
        raise ImportError(
            "The 'qrcode' package is required for QR code generation. "
            "Install it with: pip install 'qrcode[pil]'"
        ) from exc

    qr = qrcode.QRCode(
        version=None,  # auto-size to fit content
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=4,
    )
    qr.add_data(uri)
    qr.make(fit=True)

    # Prefer PIL/Pillow for higher-quality PNG output
    try:
        from PIL import Image  # type: ignore[import]  # noqa: F401

        img = qr.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    except ImportError:
        pass

    # Fall back to the pure-Python PNG writer bundled with qrcode
    try:
        from qrcode.image.pure import PyPNGImage  # type: ignore[import]

        img = qr.make_image(image_factory=PyPNGImage)
        buf = io.BytesIO()
        img.save(buf)
        return buf.getvalue()
    except ImportError as exc:
        raise ImportError(
            "Could not generate QR code PNG. "
            "Install Pillow: pip install Pillow"
        ) from exc
