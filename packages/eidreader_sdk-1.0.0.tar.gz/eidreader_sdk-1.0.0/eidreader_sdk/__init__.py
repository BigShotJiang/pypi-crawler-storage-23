"""eID Reader SDK — serverless P2P identity data transfer.

Receive identity data scanned by the eID Reader mobile app directly in your
application — no cloud server, no data storage, no intermediaries.

Quick start::

    from eidreader_sdk import EIDReaderSession

    session = EIDReaderSession()
    session.on_paired(lambda: print(f"SAS: {session.sas_code}"))
    session.on_data(lambda data: print(data.personal.full_name))
    session.start()

    # Render session.qr_code_png in your UI
    # When the user confirms SAS codes match:
    session.confirm_sas()
"""

from .session import EIDReaderSession
from .types import (
    DocumentType,
    EIDData,
    EIDDocument,
    EIDError,
    EIDImage,
    EIDMeta,
    EIDMrz,
    EIDPersonal,
    Gender,
    SessionState,
)

__version__ = "1.0.0"
__all__ = [
    "EIDReaderSession",
    "EIDData",
    "EIDMeta",
    "EIDPersonal",
    "EIDDocument",
    "EIDMrz",
    "EIDImage",
    "EIDError",
    "DocumentType",
    "Gender",
    "SessionState",
]
