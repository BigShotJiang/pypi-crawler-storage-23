"""EIDReaderSession — the main public class of the eID Reader SDK."""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
import uuid
from typing import Callable, Optional

try:
    import websockets
    import websockets.exceptions
    from websockets.server import WebSocketServerProtocol, serve as ws_serve
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "The 'websockets' package is required. Install it with: pip install websockets"
    ) from exc

from .crypto import (
    compute_sas,
    decrypt_payload,
    derive_aes_key,
    derive_shared_secret,
    deserialize_pubkey,
    generate_keypair,
    serialize_pubkey,
)
from .network import find_available_port, get_lan_ip
from .protocol import (
    DEFAULT_TTL,
    PORT_RANGE_MAX,
    PORT_RANGE_MIN,
    MsgType,
    build_message,
    build_qr_uri,
)
from .qrcode_gen import generate_qr_png
from .types import EIDData, EIDError, SessionState

logger = logging.getLogger(__name__)


class EIDReaderSession:
    """A single pairing session between the host application and the eID Reader app.

    Usage (synchronous, callback-based)::

        session = EIDReaderSession()
        session.on_paired(lambda: print(f"SAS: {session.sas_code}"))
        session.on_data(lambda data: print(data.personal.full_name))
        session.on_expired(lambda: print("Expired — generate a new QR."))
        session.on_error(lambda err: print(f"Error: {err}"))

        session.start()
        display_qr(session.qr_code_png)

        # Later, when user confirms SAS codes match:
        session.confirm_sas()

    Usage (async)::

        async def main():
            session = EIDReaderSession()
            session.on_data(lambda data: print(data.personal.full_name))
            await session.start_async()
            display_qr(session.qr_code_base64)
            data = await session.wait_for_data()

    See EIDReaderSession constructor for configuration options.
    """

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        ttl: int = DEFAULT_TTL,
        require_sas: bool = True,
    ) -> None:
        """Create a new session.

        Args:
            host: Override the auto-detected LAN IP. Useful on multi-NIC machines
                  or in Docker/VM environments.
            port: Override the random port. Must be in range 49152–65535.
            ttl:  Session lifetime in seconds (default 180). After expiry the QR
                  becomes invalid and a new session must be created.
            require_sas: If True (default), the host waits for both the phone's
                  CONFIRM and developer's confirm_sas() before sending CONFIRM_ACK.
                  Set to False only in automated test scenarios.
        """
        self._host_override = host
        self._port_override = port
        self._ttl = ttl
        self._require_sas = require_sas

        # Session identity
        self._session_id: Optional[str] = None
        self._host_ip: Optional[str] = None
        self._port_num: Optional[int] = None
        self._expires: Optional[int] = None

        # State machine
        self._state = SessionState.IDLE

        # Cryptographic material — held only in memory, cleared after session
        self._privkey = None
        self._shared_secret: Optional[bytes] = None
        self._aes_key: Optional[bytes] = None

        # UI data
        self._qr_png: Optional[bytes] = None
        self._sas_code: Optional[str] = None

        # Callbacks
        self._cb_paired: Optional[Callable] = None
        self._cb_data: Optional[Callable] = None
        self._cb_expired: Optional[Callable] = None
        self._cb_error: Optional[Callable] = None
        self._cb_ready: Optional[Callable] = None

        # Async primitives — created in the correct event loop (see _init_async_primitives)
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._sas_confirmed_event: Optional[asyncio.Event] = None
        self._phone_confirmed_event: Optional[asyncio.Event] = None
        self._data_event: Optional[asyncio.Event] = None
        self._server_task: Optional[asyncio.Task] = None

        # WebSocket references
        self._server = None
        self._ws: Optional[WebSocketServerProtocol] = None

        # Received data
        self._eid_data: Optional[EIDData] = None

        # Sequence counter for outbound messages
        self._seq_out: int = 0
        # Last received inbound sequence number
        self._seq_in: int = 0

        # Threading primitives for sync start()
        self._ready_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ---------------------------------------------------------------------------
    # Properties
    # ---------------------------------------------------------------------------

    @property
    def id(self) -> Optional[str]:
        """The session UUID (available after start())."""
        return self._session_id

    @property
    def state(self) -> SessionState:
        """Current session state."""
        return self._state

    @property
    def qr_code_png(self) -> Optional[bytes]:
        """Raw PNG bytes of the QR code. Available after start()."""
        return self._qr_png

    @property
    def qr_code_base64(self) -> Optional[str]:
        """Base64-encoded PNG of the QR code. Available after start()."""
        if self._qr_png:
            import base64
            return base64.b64encode(self._qr_png).decode()
        return None

    @property
    def sas_code(self) -> Optional[str]:
        """6-digit SAS code (e.g. "482 931"). Available after the phone connects."""
        return self._sas_code

    # ---------------------------------------------------------------------------
    # Callback registration (fluent interface)
    # ---------------------------------------------------------------------------

    def on_paired(self, callback: Callable[[], None]) -> "EIDReaderSession":
        """Register a callback fired when the phone connects and SAS is ready."""
        self._cb_paired = callback
        return self

    def on_data(self, callback: Callable[[EIDData], None]) -> "EIDReaderSession":
        """Register a callback fired when eID data is received and decrypted."""
        self._cb_data = callback
        return self

    def on_expired(self, callback: Callable[[], None]) -> "EIDReaderSession":
        """Register a callback fired when the session TTL expires."""
        self._cb_expired = callback
        return self

    def on_error(self, callback: Callable[[EIDError], None]) -> "EIDReaderSession":
        """Register a callback fired on any protocol or crypto error."""
        self._cb_error = callback
        return self

    def on_ready(self, callback: Callable[[], None]) -> "EIDReaderSession":
        """Register a callback fired when the server is listening and QR is ready."""
        self._cb_ready = callback
        return self

    # ---------------------------------------------------------------------------
    # Public API
    # ---------------------------------------------------------------------------

    def start(self) -> "EIDReaderSession":
        """Start the session in a background daemon thread (non-blocking).

        Blocks until the WebSocket server is listening and the QR code is ready
        (or raises RuntimeError on timeout). The calling thread is then free to
        render the QR code and wait for callbacks.

        Returns:
            self, for method chaining.
        """
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._thread_main, daemon=True)
        self._thread.start()
        if not self._ready_event.wait(timeout=15):
            raise RuntimeError(
                "EIDReaderSession failed to start within 15 seconds. "
                "Check that the host IP is reachable and the port is not blocked."
            )
        return self

    async def start_async(self) -> "EIDReaderSession":
        """Start the session within the current asyncio event loop (non-blocking).

        Waits until the WebSocket server is listening and the QR code is ready,
        then returns. The server continues running as a background task.

        Returns:
            self, for method chaining.
        """
        self._loop = asyncio.get_running_loop()
        self._init_async_primitives()

        ready_future: asyncio.Future = self._loop.create_future()
        self._server_task = asyncio.create_task(self._async_main(ready_future))
        await ready_future
        return self

    async def wait_for_data(self) -> Optional[EIDData]:
        """Wait (async) until eID data is received.

        Must be called after start_async(). Returns the EIDData object,
        or None if the session expired/errored before data arrived.
        """
        if self._data_event:
            await self._data_event.wait()
        return self._eid_data

    def confirm_sas(self) -> None:
        """Confirm that the SAS codes match on the host side.

        Call this after your user verbally or visually confirms that the 6-digit
        code displayed in your app matches the code on the phone. This sends
        CONFIRM_ACK to the phone and transitions the session to active data
        transfer.

        Thread-safe — can be called from any thread.
        """
        if self._loop and self._sas_confirmed_event:
            self._loop.call_soon_threadsafe(self._sas_confirmed_event.set)

    def close(self) -> None:
        """Gracefully close the session.

        Sends a CLOSE message to the phone, stops the WebSocket server, and
        clears all cryptographic material from memory. Thread-safe.
        """
        if self._loop and not self._loop.is_closed():
            asyncio.run_coroutine_threadsafe(self._async_close(), self._loop)

    # ---------------------------------------------------------------------------
    # Internal — threading entry point
    # ---------------------------------------------------------------------------

    def _thread_main(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._init_async_primitives()
        try:
            self._loop.run_until_complete(self._thread_async_main())
        except Exception as exc:
            logger.debug("Session loop exited with exception: %s", exc)
        finally:
            self._loop.close()

    async def _thread_async_main(self) -> None:
        await self._setup()
        # Signal to start() that the server is ready
        self._ready_event.set()
        if self._cb_ready:
            self._cb_ready()
        await self._run_server_with_ttl()

    # ---------------------------------------------------------------------------
    # Internal — async entry point (used by start_async)
    # ---------------------------------------------------------------------------

    async def _async_main(self, ready_future: asyncio.Future) -> None:
        await self._setup()
        if not ready_future.done():
            ready_future.set_result(True)
        if self._cb_ready:
            self._cb_ready()
        await self._run_server_with_ttl()

    # ---------------------------------------------------------------------------
    # Internal — session setup (keypair, QR, network)
    # ---------------------------------------------------------------------------

    def _init_async_primitives(self) -> None:
        self._sas_confirmed_event = asyncio.Event()
        self._phone_confirmed_event = asyncio.Event()
        self._data_event = asyncio.Event()

    async def _setup(self) -> None:
        # 1. Generate session UUID
        self._session_id = str(uuid.uuid4())
        self._seq_out = 0
        self._seq_in = 0

        # 2. Generate ephemeral ECDH P-256 keypair
        self._privkey, pubkey = generate_keypair()
        pubkey_b64 = serialize_pubkey(pubkey)

        # 3. Detect/validate LAN IP
        self._host_ip = self._host_override or get_lan_ip()

        # 4. Pick an available port
        self._port_num = self._port_override or find_available_port(
            self._host_ip, PORT_RANGE_MIN, PORT_RANGE_MAX
        )

        # 5. Compute session expiry
        self._expires = int(time.time()) + self._ttl

        # 6. Build QR URI and generate PNG
        uri = build_qr_uri(
            self._host_ip,
            self._port_num,
            pubkey_b64,
            self._session_id,
            self._expires,
        )
        self._qr_png = generate_qr_png(uri)

        self._state = SessionState.LISTENING
        logger.debug(
            "Session %s listening on %s:%s (TTL %ss)",
            self._session_id,
            self._host_ip,
            self._port_num,
            self._ttl,
        )

    # ---------------------------------------------------------------------------
    # Internal — WebSocket server
    # ---------------------------------------------------------------------------

    async def _run_server_with_ttl(self) -> None:
        try:
            async with ws_serve(
                self._handle_connection,
                self._host_ip,
                self._port_num,
                ping_interval=None,
                ping_timeout=None,
            ) as server:
                self._server = server
                try:
                    await asyncio.wait_for(self._wait_until_done(), timeout=self._ttl)
                except asyncio.TimeoutError:
                    await self._handle_expiry()
        except OSError as exc:
            err = EIDError(EIDError.E_BIND_FAILED, str(exc))
            self._state = SessionState.ERROR
            logger.error("Failed to bind WebSocket server: %s", exc)
            if self._cb_error:
                self._cb_error(err)
        finally:
            self._clear_keys()

    async def _wait_until_done(self) -> None:
        terminal = {SessionState.COMPLETE, SessionState.EXPIRED, SessionState.ERROR}
        while self._state not in terminal:
            await asyncio.sleep(0.1)

    async def _handle_expiry(self) -> None:
        if self._state in {SessionState.COMPLETE, SessionState.ERROR}:
            return  # already finished normally
        self._state = SessionState.EXPIRED
        if self._ws:
            try:
                msg = build_message(
                    MsgType.ERROR,
                    self._session_id,
                    self._next_seq_out(),
                    {"code": EIDError.E_EXPIRED, "message": "Session has expired"},
                )
                await self._ws.send(json.dumps(msg))
                await self._ws.close()
            except Exception:
                pass
        self._clear_keys()
        if self._cb_expired:
            self._cb_expired()
        if self._data_event:
            self._data_event.set()  # unblock wait_for_data()

    # ---------------------------------------------------------------------------
    # Internal — WebSocket connection handler
    # ---------------------------------------------------------------------------

    async def _handle_connection(self, ws: WebSocketServerProtocol) -> None:
        # Only accept one connection per session
        if self._ws is not None:
            await ws.close(1008, "Session already in use")
            return

        self._ws = ws
        logger.debug("Connection from %s", ws.remote_address)

        try:
            async for raw in ws:
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8")
                await self._dispatch(ws, raw)
                if self._state in {
                    SessionState.COMPLETE,
                    SessionState.EXPIRED,
                    SessionState.ERROR,
                }:
                    break
        except websockets.exceptions.ConnectionClosed:
            logger.debug("Connection closed by remote")
        except Exception as exc:
            logger.exception("Unexpected error in connection handler: %s", exc)
            err = EIDError("E_INTERNAL", str(exc))
            self._state = SessionState.ERROR
            if self._cb_error:
                self._cb_error(err)
        finally:
            self._ws = None

    async def _dispatch(self, ws: WebSocketServerProtocol, raw: str) -> None:
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            await self._send_error(ws, EIDError.E_UNKNOWN_TYPE, "Invalid JSON")
            return

        msg_type = msg.get("type")
        session = msg.get("session")
        seq = msg.get("seq")
        payload = msg.get("payload") or {}

        # Validate session ID
        if session != self._session_id:
            await self._send_error(ws, EIDError.E_SESSION_MISMATCH, "Session ID mismatch")
            await ws.close()
            return

        # Validate sequence number
        if seq is not None:
            expected = self._seq_in + 1
            if seq != expected:
                await self._send_error(
                    ws,
                    EIDError.E_SEQUENCE_ERROR,
                    f"Expected seq {expected}, got {seq}",
                )
                await ws.close()
                return
            self._seq_in = seq

        handlers = {
            MsgType.HELLO: self._on_hello,
            MsgType.CONFIRM: self._on_confirm,
            MsgType.DATA: self._on_data_msg,
            MsgType.CLOSE: self._on_close,
            MsgType.ERROR: self._on_error_msg,
        }

        handler = handlers.get(msg_type)
        if handler:
            await handler(ws, payload)
        else:
            await self._send_error(ws, EIDError.E_UNKNOWN_TYPE, f"Unknown type: {msg_type}")

    # ---------------------------------------------------------------------------
    # Internal — message handlers
    # ---------------------------------------------------------------------------

    async def _on_hello(self, ws: WebSocketServerProtocol, payload: dict) -> None:
        self._state = SessionState.HANDSHAKING

        phone_pubkey_b64 = payload.get("pubkey")
        if not phone_pubkey_b64:
            await self._send_error(ws, EIDError.E_CRYPTO_FAILED, "Missing pubkey in HELLO")
            return

        try:
            phone_pubkey = deserialize_pubkey(phone_pubkey_b64)
            self._shared_secret = derive_shared_secret(self._privkey, phone_pubkey)
            self._aes_key = derive_aes_key(self._shared_secret, self._session_id)
            self._sas_code = compute_sas(self._shared_secret, self._session_id)
        except Exception as exc:
            await self._send_error(ws, EIDError.E_CRYPTO_FAILED, str(exc))
            return

        # Send HELLO_ACK — both sides now compute and display SAS
        ack = build_message(MsgType.HELLO_ACK, self._session_id, self._next_seq_out(), {})
        await ws.send(json.dumps(ack))

        self._state = SessionState.PAIRED
        logger.debug("SAS code: %s", self._sas_code)

        if self._cb_paired:
            self._cb_paired()

    async def _on_confirm(self, ws: WebSocketServerProtocol, payload: dict) -> None:
        # Phone user has confirmed the SAS code
        self._phone_confirmed_event.set()

        if self._require_sas:
            # Wait for the developer to also call confirm_sas()
            await self._sas_confirmed_event.wait()

        # Check if the session timed out while we were waiting
        if self._state == SessionState.EXPIRED:
            return

        ack = build_message(MsgType.CONFIRM_ACK, self._session_id, self._next_seq_out(), {})
        await ws.send(json.dumps(ack))
        logger.debug("SAS confirmed on both sides — session active")

    async def _on_data_msg(self, ws: WebSocketServerProtocol, payload: dict) -> None:
        self._state = SessionState.TRANSFERRING

        try:
            plaintext = decrypt_payload(self._aes_key, payload)
            eid_data = EIDData.from_dict(plaintext)
        except Exception as exc:
            await self._send_error(ws, EIDError.E_CRYPTO_FAILED, f"Decryption failed: {exc}")
            return

        # Acknowledge receipt
        ack = build_message(MsgType.DATA_ACK, self._session_id, self._next_seq_out(), {})
        await ws.send(json.dumps(ack))

        self._eid_data = eid_data
        self._state = SessionState.COMPLETE
        self._clear_keys()

        if self._data_event:
            self._data_event.set()

        if self._cb_data:
            self._cb_data(eid_data)

        logger.debug("eID data received and decrypted successfully")

    async def _on_close(self, ws: WebSocketServerProtocol, payload: dict) -> None:
        self._state = SessionState.COMPLETE
        self._clear_keys()
        if self._data_event:
            self._data_event.set()
        await ws.close()

    async def _on_error_msg(self, ws: WebSocketServerProtocol, payload: dict) -> None:
        code = payload.get("code", "E_UNKNOWN")
        message = payload.get("message", "Phone reported an error")
        err = EIDError(code, message)
        self._state = SessionState.ERROR
        self._clear_keys()
        if self._data_event:
            self._data_event.set()
        if self._cb_error:
            self._cb_error(err)
        await ws.close()

    # ---------------------------------------------------------------------------
    # Internal — helpers
    # ---------------------------------------------------------------------------

    async def _send_error(self, ws: WebSocketServerProtocol, code: str, message: str) -> None:
        msg = build_message(
            MsgType.ERROR,
            self._session_id or "",
            self._next_seq_out(),
            {"code": code, "message": message},
        )
        try:
            await ws.send(json.dumps(msg))
        except Exception:
            pass
        self._state = SessionState.ERROR
        if self._data_event:
            self._data_event.set()
        err = EIDError(code, message)
        if self._cb_error:
            self._cb_error(err)

    async def _async_close(self) -> None:
        if self._ws:
            try:
                msg = build_message(
                    MsgType.CLOSE,
                    self._session_id or "",
                    self._next_seq_out(),
                    {},
                )
                await self._ws.send(json.dumps(msg))
                await self._ws.close()
            except Exception:
                pass
        if self._server:
            self._server.close()
            try:
                await asyncio.wait_for(self._server.wait_closed(), timeout=5.0)
            except asyncio.TimeoutError:
                pass
        self._clear_keys()
        self._state = SessionState.COMPLETE
        if self._data_event:
            self._data_event.set()

    def _clear_keys(self) -> None:
        """Remove all cryptographic material from memory."""
        self._privkey = None
        self._shared_secret = None
        self._aes_key = None

    def _next_seq_out(self) -> int:
        self._seq_out += 1
        return self._seq_out
