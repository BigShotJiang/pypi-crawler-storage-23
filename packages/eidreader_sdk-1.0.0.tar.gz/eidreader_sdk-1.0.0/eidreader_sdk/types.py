"""Data models for eID Reader SDK."""

from __future__ import annotations

import base64
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Optional


class DocumentType(str, Enum):
    PASSPORT = "PASSPORT"
    ID_CARD = "ID_CARD"
    RESIDENCE_PERMIT = "RESIDENCE_PERMIT"


class Gender(str, Enum):
    MALE = "M"
    FEMALE = "F"
    OTHER = "X"


class SessionState(str, Enum):
    IDLE = "IDLE"
    LISTENING = "LISTENING"
    HANDSHAKING = "HANDSHAKING"
    PAIRED = "PAIRED"
    TRANSFERRING = "TRANSFERRING"
    COMPLETE = "COMPLETE"
    EXPIRED = "EXPIRED"
    ERROR = "ERROR"


@dataclass
class EIDMeta:
    document_type: Optional[DocumentType] = None
    issuing_country: Optional[str] = None
    scan_timestamp: Optional[datetime] = None
    sdk_version: Optional[str] = None


@dataclass
class EIDPersonal:
    surname: Optional[str] = None
    given_names: Optional[str] = None
    date_of_birth: Optional[date] = None
    gender: Optional[Gender] = None
    nationality: Optional[str] = None
    personal_number: Optional[str] = None
    place_of_birth: Optional[str] = None

    @property
    def full_name(self) -> Optional[str]:
        parts = [p for p in [self.given_names, self.surname] if p]
        return " ".join(parts) if parts else None


@dataclass
class EIDDocument:
    number: Optional[str] = None
    expiry_date: Optional[date] = None
    issue_date: Optional[date] = None
    issuing_authority: Optional[str] = None
    issuing_country: Optional[str] = None


@dataclass
class EIDMrz:
    line1: Optional[str] = None
    line2: Optional[str] = None
    is_valid: Optional[bool] = None


@dataclass
class EIDImage:
    face_photo: Optional[bytes] = None
    signature: Optional[bytes] = None


@dataclass
class EIDData:
    meta: EIDMeta = field(default_factory=EIDMeta)
    personal: EIDPersonal = field(default_factory=EIDPersonal)
    document: EIDDocument = field(default_factory=EIDDocument)
    mrz: EIDMrz = field(default_factory=EIDMrz)
    image: EIDImage = field(default_factory=EIDImage)

    @classmethod
    def from_dict(cls, data: dict) -> "EIDData":
        obj = cls()

        meta_d = data.get("meta") or {}
        doc_type = meta_d.get("document_type")
        obj.meta.document_type = DocumentType(doc_type) if doc_type else None
        obj.meta.issuing_country = meta_d.get("issuing_country")
        ts = meta_d.get("scan_timestamp")
        if ts:
            try:
                obj.meta.scan_timestamp = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                pass
        obj.meta.sdk_version = meta_d.get("sdk_version")

        pers_d = data.get("personal") or {}
        obj.personal.surname = pers_d.get("surname")
        obj.personal.given_names = pers_d.get("given_names")
        dob = pers_d.get("date_of_birth")
        if dob:
            try:
                obj.personal.date_of_birth = date.fromisoformat(dob)
            except (ValueError, AttributeError):
                pass
        gender = pers_d.get("gender")
        # Accept both enum values and common string representations
        gender_map = {
            "M": Gender.MALE,
            "F": Gender.FEMALE,
            "X": Gender.OTHER,
            "MALE": Gender.MALE,
            "FEMALE": Gender.FEMALE,
            "OTHER": Gender.OTHER,
        }
        if gender:
            try:
                obj.personal.gender = Gender(gender)
            except ValueError:
                obj.personal.gender = gender_map.get(str(gender).upper(), None)
        else:
            obj.personal.gender = None
        obj.personal.nationality = pers_d.get("nationality")
        obj.personal.personal_number = pers_d.get("personal_number")
        obj.personal.place_of_birth = pers_d.get("place_of_birth")

        doc_d = data.get("document") or {}
        obj.document.number = doc_d.get("number")
        for attr, key in [("expiry_date", "expiry_date"), ("issue_date", "issue_date")]:
            val = doc_d.get(key)
            if val:
                try:
                    setattr(obj.document, attr, date.fromisoformat(val))
                except (ValueError, AttributeError):
                    pass
        obj.document.issuing_authority = doc_d.get("issuing_authority")
        obj.document.issuing_country = doc_d.get("issuing_country")

        mrz_d = data.get("mrz") or {}
        obj.mrz.line1 = mrz_d.get("line1")
        obj.mrz.line2 = mrz_d.get("line2")
        obj.mrz.is_valid = mrz_d.get("valid")

        img_d = data.get("image") or {}
        for attr, key in [("face_photo", "face_photo"), ("signature", "signature")]:
            val = img_d.get(key)
            if val:
                try:
                    setattr(obj.image, attr, base64.b64decode(val))
                except Exception:
                    pass

        return obj


class EIDError(Exception):
    # Standard error codes
    E_SESSION_MISMATCH = "E_SESSION_MISMATCH"
    E_SEQUENCE_ERROR = "E_SEQUENCE_ERROR"
    E_EXPIRED = "E_EXPIRED"
    E_CRYPTO_FAILED = "E_CRYPTO_FAILED"
    E_SAS_REJECTED = "E_SAS_REJECTED"
    E_PROTOCOL_VERSION = "E_PROTOCOL_VERSION"
    E_UNKNOWN_TYPE = "E_UNKNOWN_TYPE"
    E_BIND_FAILED = "E_BIND_FAILED"

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"{code}: {message}")

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"
