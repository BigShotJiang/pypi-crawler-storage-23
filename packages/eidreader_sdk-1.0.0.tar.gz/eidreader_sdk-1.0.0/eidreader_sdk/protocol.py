"""Protocol constants, message types, and QR URI builder."""

from __future__ import annotations

from enum import Enum
from typing import Any


class MsgType(str, Enum):
    HELLO = "HELLO"
    HELLO_ACK = "HELLO_ACK"
    CONFIRM = "CONFIRM"
    CONFIRM_ACK = "CONFIRM_ACK"
    DATA = "DATA"
    DATA_ACK = "DATA_ACK"
    CLOSE = "CLOSE"
    ERROR = "ERROR"


PROTOCOL_VERSION = 1
PORT_RANGE_MIN = 49152
PORT_RANGE_MAX = 65535
DEFAULT_TTL = 180


def build_qr_uri(
    ip: str,
    port: int,
    pubkey_b64: str,
    session_id: str,
    expires: int,
) -> str:
    """Build the eidreader:// URI that gets encoded into the QR code."""
    return (
        f"eidreader://pair"
        f"?ip={ip}"
        f"&port={port}"
        f"&pubkey={pubkey_b64}"
        f"&session={session_id}"
        f"&expires={expires}"
        f"&v={PROTOCOL_VERSION}"
    )


def build_message(msg_type: str, session_id: str, seq: int, payload: Any) -> dict:
    """Build a WebSocket message envelope."""
    return {
        "type": msg_type,
        "session": session_id,
        "seq": seq,
        "payload": payload,
    }
