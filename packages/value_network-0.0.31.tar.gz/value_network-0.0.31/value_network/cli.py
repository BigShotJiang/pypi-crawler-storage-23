import re
import click
import torch
import numpy as np
import cv2
import json
import webbrowser
import http.server
import socketserver
from pathlib import Path
from PIL import Image

from einops import rearrange

from memmap_replay_buffer import ReplayBuffer

from value_network.value_network import (
    SigLIPValueNetwork,
    ValueNetworkTrainer,
    ValueNetworkTrainerWithTD,
    preprocess_image
)

def exists(val):
    return val is not None

def get_video_frame_count(video_path):
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return 0
    count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()
    return count

def video_to_images(video_path):
    cap = cv2.VideoCapture(str(video_path))
    images = []
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        images.append(frame)
    cap.release()
    images = np.array(images)
    if images.ndim == 0:
        return np.zeros((0, 3, 224, 224), dtype = np.uint8)
    images = rearrange(images, 't h w c -> t c h w')
    return images

def get_next_path(base_path):
    base_path = Path(base_path)
    if not base_path.exists():
        return base_path
    
    stem = base_path.stem
    ext = base_path.suffix
    
    # search for existing name.N.ext
    pattern = re.compile(rf'^{re.escape(stem)}\.(\d+){re.escape(ext)}$')
    
    max_num = 0
    base_exists = False

    for f in base_path.parent.glob(f'{stem}*{ext}'):
        if f.name == base_path.name:
            base_exists = True
            continue

        match = pattern.match(f.name)
        if match:
            max_num = max(max_num, int(match.group(1)))
            
    if not base_exists:
        return base_path

    return base_path.parent / f'{stem}.{max_num + 1}{ext}'

def do_generate_memmap_files(
    path,
    output_folder,
    max_episodes,
    max_timesteps
):
    path = Path(path)
    output_folder = Path(output_folder)
    
    video_extensions = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
    
    # recursive search for videos

    video_files = []
    for ext in video_extensions:
        video_files.extend(list(path.rglob(f'*{ext}')))
    
    if not video_files:
        click.echo(f'no video files found in {path}')
        return None

    # sort files for consistency

    video_files.sort()

    # initialize replay buffer

    click.echo(f'determining image shape from {video_files[0].name}...')

    sample_images = video_to_images(video_files[0])
    if sample_images.shape[0] == 0:
        click.echo(f'failed to load images from {video_files[0]}')
        return None
        
    image_shape = sample_images.shape[1:]
    
    click.echo(f'image shape: {image_shape}')

    replay_buffer = ReplayBuffer(
        str(output_folder),
        fields = dict(
            images = ('int', image_shape, 0),
            rewards = ('float', (), 0.),
            progress = ('float', (), np.nan)
        ),
        meta_fields = dict(
            success = ('bool', (), False),
            episode_lens = ('int', (), 0)
        ),
        max_episodes = max_episodes,
        max_timesteps = max_timesteps,
        circular = True
    )

    # process videos

    with click.progressbar(video_files, label = 'processing videos') as bar:
        for video_file in bar:
            
            # 1. extract images

            images = video_to_images(video_file)
            episode_len = images.shape[0]
            
            if episode_len == 0:
                continue
                
            if episode_len > max_timesteps:
                images = images[:max_timesteps]
                episode_len = max_timesteps

            # 2. handle rewards

            rewards = np.zeros(episode_len, dtype = np.float32)
            
            # search for reward file

            stem = video_file.stem
            stem_without_success = re.sub(r'\.(0|1)$', '', stem)

            possible_reward_files = [
                video_file.with_suffix('.pt'),
                video_file.parent / f'{stem_without_success}.pt',
                video_file.parent.parent / 'data' / f'{video_file.stem}.pt',
                video_file.parent.parent / 'data' / f'{stem_without_success}.pt'
            ]
            
            reward_pt_file = None
            for p in possible_reward_files:
                if p.exists():
                    reward_pt_file = p
                    break
                    
            if exists(reward_pt_file):
                try:
                    reward_data = torch.load(reward_pt_file, weights_only = True)
                    
                    if torch.is_tensor(reward_data) and reward_data.ndim == 1:
                        r_len = min(episode_len, reward_data.shape[0])
                        rewards[:r_len] = reward_data[:r_len].cpu().numpy()
                    elif isinstance(reward_data, list) and len(reward_data) > 0 and isinstance(reward_data[0], dict) and 'reward' in reward_data[0]:
                        r_len = min(episode_len, len(reward_data))
                        for i in range(r_len):
                            rewards[i] = reward_data[i]['reward']
                except Exception:
                    pass

            # 3. handle success suffix

            success = False
            match = re.search(r'\.(0|1)$', video_file.stem)
            
            if exists(match):
                success = bool(int(match.group(1)))

            # 3.1 terminal reward based on success or failure

            rewards[episode_len - 1] = 1.0 if success else -1.0

            # 4. calculate progress

            progress = np.full(episode_len, np.nan, dtype = np.float32)

            if success:
                progress[:] = np.linspace(0, 1, episode_len)

            # 5. store in replay buffer

            with replay_buffer.one_episode(success = success):
                for i in range(episode_len):
                    replay_buffer.store(
                        images = images[i],
                        rewards = rewards[i],
                        progress = progress[i]
                    )

    click.echo(f'finished processing {len(video_files)} episodes. replay buffer saved to {output_folder}')
    return output_folder

@click.group()
def main():
    pass

@main.command(name = 'generate-memmap-files')
@click.argument('path', type = click.Path(exists = True))
@click.option('--output-folder', default = './replay_buffer', help = 'Path to save the replay buffer')
@click.option('--max-episodes', default = 1000, help = 'Max episodes in replay buffer')
@click.option('--max-timesteps', default = 1000, help = 'Max timesteps per episode')
def generate_memmap_files_cmd(
    path,
    output_folder,
    max_episodes,
    max_timesteps
):
    do_generate_memmap_files(path, output_folder, max_episodes, max_timesteps)

@main.command()
@click.argument('path', required = False, type = click.Path(exists = True))
@click.option('--trajectories-folder', 'trajectories_folder', type = click.Path(exists = True), help = 'Path to trajectories folder to generate memmap from')
@click.option('--batch-size', default = 16, help = 'Batch size for training')
@click.option('--lr', default = 3e-4, help = 'Learning rate')
@click.option('--max-steps', 'override_steps', type = int, help = 'Override number of training steps')
@click.option('--max-grad-norm', default = 0.5, help = 'Max gradient norm')
@click.option('--checkpoint', default = None, help = 'Path to model checkpoint to resume from')
@click.option('--model-output-path', 'output_path', default = './model.pt', help = 'Path to save the trained model')
@click.option('--use-td-trainer', is_flag = True, help = 'Use the TD trainer with failure masking')
@click.option('--discount', default = 0.99, help = 'Discount factor for TD learning')
@click.option('--ema', is_flag = True, help = 'Use EMA for TD learning targets')
@click.option('--td-loss-weight', 'td_loss_weight', default = 1.0, help = 'Weight for TD loss')
@click.option('--td-steps', 'td_steps', default = 0, help = 'Number of steps for TD training (Phase 2)')
@click.option('--loss-module', 'loss_module_name', type = click.Choice(['mse', 'hlgauss', 'categorical']), default = 'mse', help = 'Loss module to use')
@click.option('--hl-gauss-num-bins', default = 100, help = 'Number of bins for HL-Gauss loss')
@click.option('--hl-gauss-min', default = -2.0, help = 'Min value for HL-Gauss support')
@click.option('--hl-gauss-max', default = 2.0, help = 'Max value for HL-Gauss support')
@click.option('--categorical-num-bins', default = 201, help = 'Number of bins for categorical loss')
@click.option('--categorical-min', default = 0.0, help = 'Min value for categorical loss')
@click.option('--categorical-max', default = 1.0, help = 'Max value for categorical loss')
@click.option('--categorical-temperature', default = 0.1, help = 'Temperature for categorical loss')
@click.option('--categorical-encoding', type = click.Choice(['two_hot', 'gaussian']), default = 'two_hot', help = 'Encoding for categorical loss')
@click.option('--categorical-use-symexp', is_flag = True, help = 'Use sym-exp for categorical loss')
def train(
    path,
    trajectories_folder,
    batch_size,
    lr,
    override_steps,
    max_grad_norm,
    checkpoint,
    output_path,
    use_td_trainer,
    discount,
    ema,
    td_loss_weight,
    td_steps,
    loss_module_name,
    hl_gauss_num_bins,
    hl_gauss_min,
    hl_gauss_max,
    categorical_num_bins,
    categorical_min,
    categorical_max,
    categorical_temperature,
    categorical_encoding,
    categorical_use_symexp
):
    if exists(trajectories_folder):
        path = Path(trajectories_folder)
    elif exists(path):
        path = Path(path)
    else:
        click.echo('must provide either a buffer path or a trajectories folder via --trajectories-folder')
        return

    # handle model output path suffixing
    
    # ... rest of logic ...
    
    output_path = get_next_path(output_path)
    click.echo(f'model will be saved to {output_path}')

    # if it's not a replay buffer folder (no metadata.pkl), assume it's a video folder
    
    if not (path / 'metadata.pkl').exists():
        click.echo(f'{path} is not a replay buffer, attempting to generate from videos...')
        
        buffer_path = path.with_suffix('.memmap')
        
        if buffer_path.exists():
            if click.confirm(f'Memory-mapped buffer folder {buffer_path} already exists. Overwrite?', default = False):
                import shutil
                shutil.rmtree(buffer_path)
            else:
                return

        # determine max timesteps from videos
        video_extensions = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
        video_files = []
        for ext in video_extensions:
            video_files.extend(list(path.rglob(f'*{ext}')))
        
        if not video_files:
            click.echo(f'no video files found in {path}')
            return

        total_frames = 0
        max_video_len = 0
        for v in video_files:
            count = get_video_frame_count(v)
            total_frames += count
            max_video_len = max(max_video_len, count)

        steps = total_frames 

        do_generate_memmap_files(
            path,
            output_folder = buffer_path,
            max_episodes = 1000,
            max_timesteps = max_video_len + 10 # small buffer
        )
    else:
        buffer_path = path
        # if using existing buffer, we don't know the frames easily, so default to 1000
        steps = 1000

    if exists(override_steps):
        steps = override_steps

    # model
    
    loss_module_kwargs = dict()
    if loss_module_name == 'hlgauss':
        loss_module_kwargs = dict(
            num_bins = hl_gauss_num_bins,
            min_value = hl_gauss_min,
            max_value = hl_gauss_max
        )
    elif loss_module_name == "categorical":
        loss_module_kwargs = dict(
            num_bins = categorical_num_bins,
            min_value = categorical_min,
            max_value = categorical_max,
            temperature = categorical_temperature,
            encoding = categorical_encoding,
            use_symexp = categorical_use_symexp
        )
    model = SigLIPValueNetwork(
        loss_module_name = loss_module_name,
        loss_module_kwargs = loss_module_kwargs
    )

    if exists(checkpoint):
        model.load(checkpoint)
        click.echo(f'loaded model from {checkpoint}')
    else:
        model.load_siglip() 
        click.echo('starting from pretrained siglip weights')

    # phase 1 - base trainer

    if steps > 0:
        click.echo(f'phase 1: training for {steps} steps (progress only)...')
        
        trainer = ValueNetworkTrainer(
            model = model,
            replay_buffer = buffer_path,
            batch_size = batch_size,
            lr = lr,
            max_grad_norm = max_grad_norm
        )

        trainer.train(num_train_steps = steps)
        model = trainer.accelerator.unwrap_model(model)

    # phase 2 - TD trainer

    if td_steps > 0 or use_td_trainer:
        td_training_steps = td_steps if td_steps > 0 else steps
        
        click.echo(f'phase 2: training for {td_training_steps} steps (TD + progress)...')

        trainer = ValueNetworkTrainerWithTD(
            model = model,
            replay_buffer = buffer_path,
            batch_size = batch_size,
            lr = lr,
            max_grad_norm = max_grad_norm,
            discount_factor = discount,
            use_ema = ema,
            td_loss_weight = td_loss_weight
        )

        trainer.train(num_train_steps = td_training_steps)
        model = trainer.accelerator.unwrap_model(model)

    # save final model

    model.save(output_path)
    
    click.echo(f'model saved to {output_path}')

@main.command()
@click.argument('model_path', type = click.Path(exists = True))
@click.argument('input_path', type = click.Path(exists = True))
@click.option('--cuda', is_flag = True, help = 'Use CUDA if available')
@click.option('--output-path', 'output_path', type = click.Path(), help = 'Path to save prediction tensor')
@click.option('--loss-module', 'loss_module_name', type = click.Choice(['mse', 'hlgauss', 'categorical']), default = 'mse', help = 'Loss module to use (if not loading from checkpoint)')
@click.option('--hl-gauss-num-bins', default = 100, help = 'Number of bins for HL-Gauss loss')
@click.option('--hl-gauss-min', default = -2.0, help = 'Min value for HL-Gauss support')
@click.option('--hl-gauss-max', default = 2.0, help = 'Max value for HL-Gauss support')
@click.option('--categorical-num-bins', default = 201, help = 'Number of bins for categorical loss')
@click.option('--categorical-min', default = 0.0, help = 'Min value for categorical loss')
@click.option('--categorical-max', default = 1.0, help = 'Max value for categorical loss')
@click.option('--categorical-temperature', default = 0.1, help = 'Temperature for categorical loss')
@click.option('--categorical-encoding', type = click.Choice(['two_hot', 'gaussian']), default = 'two_hot', help = 'Encoding for categorical loss')
@click.option('--categorical-use-symexp', is_flag = True, help = 'Use sym-exp for categorical loss')
@click.option('--batch-size', default = 16, help = 'Batch size for video prediction')
@torch.no_grad()
def predict_value(
    model_path,
    input_path,
    batch_size,
    cuda,
    output_path,
    loss_module_name,
    hl_gauss_num_bins,
    hl_gauss_min,
    hl_gauss_max,
    categorical_num_bins,
    categorical_min,
    categorical_max,
    categorical_temperature,
    categorical_encoding,
    categorical_use_symexp
):
    # load model
    
    loss_module_kwargs = dict()
    if loss_module_name == 'hlgauss':
        loss_module_kwargs = dict(
            num_bins = hl_gauss_num_bins,
            min_value = hl_gauss_min,
            max_value = hl_gauss_max
        )
    elif loss_module_name == 'categorical':
        loss_module_kwargs = dict(
            num_bins = categorical_num_bins,
            min_value = categorical_min,
            max_value = categorical_max,
            temperature = categorical_temperature,
            encoding = categorical_encoding,
            use_symexp = categorical_use_symexp
        )

    model = SigLIPValueNetwork(
        loss_module_name = loss_module_name,
        loss_module_kwargs = loss_module_kwargs
    )
    model.load(model_path)
    model.eval()
    
    device = torch.device('cuda' if cuda and torch.cuda.is_available() else 'cpu')
    model.to(device)
    
    input_path = Path(input_path)
    video_extensions = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
    
    if input_path.suffix.lower() in video_extensions:
        # load video and process
        images = video_to_images(input_path)
        
        if images.shape[0] == 0:
            click.echo('no frames found in video')
            return

        values = []
        
        # process in batches
        for i in range(0, images.shape[0], batch_size):
            batch_images = images[i : i + batch_size]
            
            # preprocess each image in the batch
            batch_tensors = []
            for img in batch_images:
                batch_tensors.append(preprocess_image(img))
            
            batch_tensor = torch.stack(batch_tensors).to(device)
            batch_values = model(batch_tensor)
            values.append(batch_values)
        
        values = torch.cat(values, dim = 0)
        values_np = values.cpu().numpy()
        
        # save as .npy
        if exists(output_path):
            output_npy_path = Path(output_path)
        else:
            output_npy_path = get_next_path(input_path.with_suffix('.npy'))

        np.save(output_npy_path, values_np)
        
        click.echo(f'predicted values saved to {output_npy_path}')
        click.echo(f'shape: {values_np.shape}')
        
    else:
        # existing image logic
        image = Image.open(input_path).convert('RGB')
        image = np.array(image)
        image = rearrange(image, 'h w c -> c h w')
        
        image_tensor = preprocess_image(image)
        image_batch = rearrange(image_tensor, 'c h w -> 1 c h w').to(device)

        # predict
        
        value = model(image_batch)
        
        click.echo(f'predicted value: {value.item():.4f}')

@main.command()
@click.argument('video_path', type = click.Path(exists = True))
@click.argument('npy_path', type = click.Path(exists = True))
@click.option('--port', default = 8080, help = 'Port for the visualization dashboard')
def visualize(
    video_path,
    npy_path,
    port
):
    import subprocess as sp
    import tempfile

    video_path = Path(video_path).absolute()
    npy_path = Path(npy_path).absolute()

    template_path = Path(__file__).parent / 'templates' / 'dashboard.html'
    assert template_path.exists(), f'dashboard template not found at {template_path}'

    # check if video needs re-encoding to h264 for browser playback

    needs_reencode = True

    try:
        probe = sp.run(
            ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
             '-show_entries', 'stream=codec_name', '-of', 'csv=p=0',
             str(video_path)],
            capture_output = True, text = True
        )
        if probe.returncode == 0 and probe.stdout.strip() == 'h264':
            needs_reencode = False
    except FileNotFoundError:
        needs_reencode = False  # no ffmpeg available, serve as-is

    if needs_reencode:
        click.echo('Re-encoding video to H.264 for browser playback...')
        tmp = tempfile.NamedTemporaryFile(suffix = '.mp4', delete = False)
        tmp.close()

        result = sp.run(
            ['ffmpeg', '-y', '-i', str(video_path),
             '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
             '-movflags', '+faststart', tmp.name],
            capture_output = True
        )
        assert result.returncode == 0, f'ffmpeg re-encode failed: {result.stderr.decode()}'

        serve_video_path = Path(tmp.name)
        click.echo('Re-encoding complete.')
    else:
        serve_video_path = video_path

    # load values

    values = np.load(npy_path)
    if values.ndim > 1:
        values = values.flatten()

    payload = json.dumps({
        'filename': video_path.name,
        'values': values.tolist()
    }).encode()

    # request handler

    class Handler(http.server.BaseHTTPRequestHandler):
        def serve_file(self, path, content_type):
            size = path.stat().st_size
            range_header = self.headers.get('Range')

            if range_header:
                match = re.match(r'bytes=(\d+)-(\d*)', range_header)
                if match:
                    start = int(match.group(1))
                    end = int(match.group(2)) if match.group(2) else size - 1
                    end = min(end, size - 1)

                    if start >= size:
                        self.send_error(416)
                        return

                    length = end - start + 1
                    self.send_response(206)
                    self.send_header('Content-Type', content_type)
                    self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
                    self.send_header('Content-Length', str(length))
                    self.send_header('Accept-Ranges', 'bytes')
                    self.end_headers()

                    with open(path, 'rb') as f:
                        f.seek(start)
                        remaining = length
                        while remaining > 0:
                            chunk = f.read(min(8192, remaining))
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                            remaining -= len(chunk)
                    return

            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(size))
            self.send_header('Accept-Ranges', 'bytes')
            self.end_headers()

            with open(path, 'rb') as f:
                while chunk := f.read(8192):
                    self.wfile.write(chunk)

        def do_GET(self):
            try:
                if self.path == '/':
                    html = template_path.read_bytes()
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/html')
                    self.send_header('Content-Length', str(len(html)))
                    self.end_headers()
                    self.wfile.write(html)
                elif self.path == '/video':
                    self.serve_file(serve_video_path, 'video/mp4')
                elif self.path == '/data':
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Content-Length', str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                else:
                    self.send_error(404)
            except (ConnectionResetError, BrokenPipeError):
                pass

        def log_message(self, format, *args):
            return

    class ThreadedServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
        allow_reuse_address = True
        daemon_threads = True

    click.echo(f'Dashboard at http://localhost:{port}')
    click.echo('Press Ctrl+C to stop')

    webbrowser.open(f'http://localhost:{port}')

    with ThreadedServer(('', port), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            click.echo('\nStopping...')

if __name__ == '__main__':
    main()
