import os
import shutil
from pathlib import Path

import numpy as np
import pytest
import sh
from memmap_replay_buffer import ReplayBuffer

@pytest.fixture
def python_cmd():
    project_root = Path(__file__).parent.parent
    return sh.python3.bake(_env={
        **os.environ,
        'PYTHONPATH': str(project_root),
        'ACCELERATE_USE_CPU': 'true'
    })

@pytest.mark.parametrize("use_td_trainer, use_ema", [
    (False, False),
    (True, False),
    (True, True)
])
def test_e2e_pipeline(python_cmd, use_td_trainer, use_ema):
    project_root = Path(__file__).parent.parent
    fixtures_dir = project_root / 'tests' / 'fixtures'
    auto_output_buffer = fixtures_dir.with_suffix('.memmap')
    
    suffix = "td" if use_td_trainer else "base"
    if use_ema:
        suffix += "_ema"

    trained_model = project_root / 'tests' / f'e2e_model_{suffix}.pt'

    # 1. clean up
    if auto_output_buffer.exists():
        shutil.rmtree(auto_output_buffer)
    
    if trained_model.exists():
        os.remove(trained_model)

    # 2. run train
    kwargs = {}
    if use_td_trainer: kwargs['use_td_trainer'] = True
    if use_ema: kwargs['ema'] = True

    python_cmd(
        '-m', 'value_network.cli', 'train',
        '--trajectories-folder', fixtures_dir,
        '--max-steps', 1,
        '--batch-size', 2,
        '--model-output-path', trained_model,
        **kwargs
    )

    assert trained_model.exists()
    assert auto_output_buffer.exists()

    # 3. run predict-value
    test_frame = fixtures_dir / 'test_frame.png'
    out = python_cmd('-m', 'value_network.cli', 'predict-value', trained_model, test_frame)
    assert 'predicted value:' in out

def test_e2e_sequential_training(python_cmd):
    project_root = Path(__file__).parent.parent
    fixtures_dir = project_root / 'tests' / 'fixtures'
    auto_output_buffer = fixtures_dir.with_suffix('.memmap')
    trained_model = project_root / 'tests' / 'e2e_model_sequential.pt'

    if auto_output_buffer.exists(): shutil.rmtree(auto_output_buffer)
    if trained_model.exists(): os.remove(trained_model)

    python_cmd(
        '-m', 'value_network.cli', 'train',
        '--trajectories-folder', fixtures_dir,
        '--max-steps', 1,
        '--td-steps', 1,
        '--batch-size', 2,
        '--model-output-path', trained_model
    )

    assert trained_model.exists()
    
    test_frame = fixtures_dir / 'test_frame.png'
    out = python_cmd('-m', 'value_network.cli', 'predict-value', trained_model, test_frame)
    assert 'predicted value:' in out

def test_e2e_video_prediction(python_cmd):
    project_root = Path(__file__).parent.parent
    fixtures_dir = project_root / 'tests' / 'fixtures'
    trained_model = project_root / 'tests' / 'e2e_model_base.pt'
    test_video = fixtures_dir / 'short.mp4'
    output_npy = test_video.with_suffix('.npy')

    for f in fixtures_dir.glob('short*.npy'): os.remove(f)

    # run predict-value on video
    python_cmd(
        '-m', 'value_network.cli', 'predict-value',
        trained_model, test_video,
        '--batch-size', 4,
        '--cuda'
    )

    assert output_npy.exists()
    data = np.load(output_npy)
    assert data.shape[0] == 2

    # collision check
    python_cmd(
        '-m', 'value_network.cli', 'predict-value',
        trained_model, test_video,
        '--batch-size', 4,
        '--cuda'
    )
    
    assert (fixtures_dir / 'short.1.npy').exists()

def test_e2e_hl_gauss(python_cmd):
    project_root = Path(__file__).parent.parent
    fixtures_dir = project_root / 'tests' / 'fixtures'
    auto_output_buffer = fixtures_dir.with_suffix('.memmap')
    trained_model = project_root / 'tests' / 'e2e_model_hlgauss.pt'

    if auto_output_buffer.exists(): shutil.rmtree(auto_output_buffer)
    if trained_model.exists(): os.remove(trained_model)

    python_cmd(
        '-m', 'value_network.cli', 'train',
        '--trajectories-folder', fixtures_dir,
        '--max-steps', 1,
        '--batch-size', 2,
        '--model-output-path', trained_model,
        '--loss-module', 'hlgauss',
        '--hl-gauss-num-bins', 100,
        '--hl-gauss-min', -2,
        '--hl-gauss-max', 2
    )

    assert trained_model.exists()

def test_e2e_categorical(python_cmd):
    project_root = Path(__file__).parent.parent
    fixtures_dir = project_root / 'tests' / 'fixtures'
    auto_output_buffer = fixtures_dir.with_suffix('.memmap')
    trained_model = project_root / 'tests' / 'e2e_model_categorical.pt'

    if auto_output_buffer.exists(): shutil.rmtree(auto_output_buffer)
    if trained_model.exists(): os.remove(trained_model)

    python_cmd(
        '-m', 'value_network.cli', 'train',
        '--trajectories-folder', fixtures_dir,
        '--max-steps', 1,
        '--batch-size', 2,
        '--model-output-path', trained_model,
        '--loss-module', 'categorical',
        '--categorical-num-bins', 51,
        '--categorical-min', 0.0,
        '--categorical-max', 1.0
    )

    assert trained_model.exists()
    
    test_frame = fixtures_dir / 'test_frame.png'
    out = python_cmd(
        '-m', 'value_network.cli', 'predict-value',
        trained_model, test_frame,
        '--loss-module', 'categorical',
        '--categorical-num-bins', 51,
        '--categorical-min', 0.0,
        '--categorical-max', 1.0
    )
    
    assert 'predicted value:' in out
