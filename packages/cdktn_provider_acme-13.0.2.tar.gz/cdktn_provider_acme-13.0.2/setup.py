import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "cdktn-provider-acme",
    "version": "13.0.2",
    "description": "Prebuilt acme Provider for CDK Terrain (cdktn)",
    "license": "MPL-2.0",
    "url": "https://github.com/cdktn-io/cdktn-provider-acme.git",
    "long_description_content_type": "text/markdown",
    "author": "CDK Terrain Maintainers",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/cdktn-io/cdktn-provider-acme.git"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "cdktn_provider_acme",
        "cdktn_provider_acme._jsii",
        "cdktn_provider_acme.certificate",
        "cdktn_provider_acme.data_acme_server_url",
        "cdktn_provider_acme.provider",
        "cdktn_provider_acme.registration"
    ],
    "package_data": {
        "cdktn_provider_acme._jsii": [
            "provider-acme@13.0.2.jsii.tgz"
        ],
        "cdktn_provider_acme": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.9",
    "install_requires": [
        "cdktn>=0.22.0, <0.23.0",
        "constructs>=10.4.2, <11.0.0",
        "jsii>=1.126.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard==2.13.3"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed",
        "Development Status :: 5 - Production/Stable",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
