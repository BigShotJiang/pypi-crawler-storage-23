"""drift command entrypoint."""

from specfact_cli.modules.drift.src.commands import app


__all__ = ["app"]
