"""auth command entrypoint."""

from specfact_cli.modules.auth.src.commands import app


__all__ = ["app"]
