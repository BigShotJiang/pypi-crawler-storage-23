"""Allow running the CLI as python -m specfact_cli."""

if __name__ == "__main__":
    from specfact_cli.cli import cli_main

    cli_main()
