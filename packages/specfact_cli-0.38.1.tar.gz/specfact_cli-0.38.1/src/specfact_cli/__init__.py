"""
SpecFact CLI - The swiss knife CLI for agile DevOps teams.

This package provides command-line tools for:
- Turning code into clear specs and plans
- Keeping backlog, specs, tests, and code in sync
- Enforcing validation and contract checks before production
- Supporting agile ceremonies and team workflows
"""

__version__ = "0.38.1"

__all__ = ["__version__"]
