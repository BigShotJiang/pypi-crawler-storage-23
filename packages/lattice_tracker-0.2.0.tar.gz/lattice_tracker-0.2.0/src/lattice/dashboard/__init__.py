"""Read-only local web dashboard."""
