"""Filesystem storage operations."""
