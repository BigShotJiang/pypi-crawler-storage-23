"""Lattice: file-based, agent-native task tracker with an event-sourced core."""

__version__ = "0.1.0"
