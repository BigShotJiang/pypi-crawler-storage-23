"""Bundled skill files for agent tool integrations."""
