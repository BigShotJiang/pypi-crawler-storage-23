"""Core business logic (no filesystem I/O)."""
