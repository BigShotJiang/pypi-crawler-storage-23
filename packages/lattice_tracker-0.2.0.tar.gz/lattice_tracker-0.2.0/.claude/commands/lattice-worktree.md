This command has moved. The worktree protocol is now part of the unified `/lattice` skill.

See: `src/lattice/skills/lattice/references/worktree-guide.md`
