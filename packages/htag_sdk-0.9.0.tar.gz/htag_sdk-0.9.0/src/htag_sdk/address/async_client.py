"""Asynchronous client for the Address API domain."""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from htag_sdk.address.models import (
    AddressInsightsResponse,
    AddressSearchResponse,
    BatchStandardiseResponse,
    DemographicsResponse,
    EnvironmentResponse,
    GeocodeResponse,
)

if TYPE_CHECKING:
    from htag_sdk._base import AsyncRequestMixin


class AsyncAddressClient:
    """Asynchronous client for address search, insights, and standardisation.

    This class is not instantiated directly. Access it via ``client.address``.
    """

    _client: "AsyncRequestMixin"

    def __init__(self, client: "AsyncRequestMixin") -> None:
        self._client = client

    async def search(
        self,
        q: str,
        *,
        threshold: float = 0.3,
        limit: int = 10,
    ) -> AddressSearchResponse:
        """Search for addresses by free-text query.

        Args:
            q: Search query string (minimum 3 characters).
            threshold: Minimum relevance score between 0.1 and 1.0.
            limit: Maximum number of results to return (1-50).

        Returns:
            An :class:`AddressSearchResponse` containing matching addresses
            with relevance scores.
        """
        data = await self._client._request(
            "GET",
            "/address/search",
            params={
                "q": q,
                "threshold": threshold,
                "limit": limit,
            },
        )
        return AddressSearchResponse.model_validate(data)

    async def insights(
        self,
        *,
        address: Optional[str] = None,
        address_keys: Optional[List[str]] = None,
        legal_parcel_id: Optional[str] = None,
        street_loc_pid: Optional[str] = None,
        mb_category_2021: Optional[List[str]] = None,
    ) -> AddressInsightsResponse:
        """Retrieve enriched insights for an address.

        Exactly one of ``address``, ``address_keys``, or ``legal_parcel_id``
        must be provided as the primary lookup key.

        Args:
            address: Full address string to look up.
            address_keys: One or more GNAF address keys.
            legal_parcel_id: Legal parcel identifier.
            street_loc_pid: Street locality PID filter.
            mb_category_2021: Mesh-block category filter.

        Returns:
            An :class:`AddressInsightsResponse` with enriched address records.
        """
        params = {
            "address": address,
            "address_keys": address_keys,
            "legal_parcel_id": legal_parcel_id,
            "street_loc_pid": street_loc_pid,
            "mb_category_2021": mb_category_2021,
        }
        data = await self._client._request("GET", "/address/insights", params=params)
        return AddressInsightsResponse.model_validate(data)

    async def standardise(
        self,
        addresses: List[str],
    ) -> BatchStandardiseResponse:
        """Standardise a batch of free-text Australian addresses.

        Args:
            addresses: List of address strings to standardise (max 50).

        Returns:
            A :class:`BatchStandardiseResponse` with standardised components
            for each input address.
        """
        data = await self._client._request(
            "POST",
            "/address/standardise",
            json={"addresses": addresses},
        )
        return BatchStandardiseResponse.model_validate(data)

    async def geocode(
        self,
        address: str,
        *,
        mb_category_2021: Optional[List[str]] = None,
        limit: int = 10,
    ) -> GeocodeResponse:
        """Geocode an address to geographic identifiers.

        Args:
            address: Free-text address string (3-200 characters).
            mb_category_2021: Mesh-block category filter.
            limit: Maximum number of results (1-50).

        Returns:
            A :class:`GeocodeResponse` with geocoded address records.
        """
        params = {
            "address": address,
            "mb_category_2021": mb_category_2021,
            "limit": limit,
        }
        data = await self._client._request("GET", "/address/geocode", params=params)
        return GeocodeResponse.model_validate(data)

    async def environment(
        self,
        *,
        address: Optional[str] = None,
        address_keys: Optional[List[str]] = None,
        legal_parcel_id: Optional[str] = None,
        mb_category_2021: Optional[List[str]] = None,
    ) -> EnvironmentResponse:
        """Retrieve environmental risk data for an address.

        Exactly one of ``address``, ``address_keys``, or ``legal_parcel_id``
        must be provided.

        Args:
            address: Full address string to look up.
            address_keys: One or more GNAF address keys.
            legal_parcel_id: Legal parcel identifier.
            mb_category_2021: Mesh-block category filter.

        Returns:
            An :class:`EnvironmentResponse` with environment records.
        """
        params = {
            "address": address,
            "address_keys": address_keys,
            "legal_parcel_id": legal_parcel_id,
            "mb_category_2021": mb_category_2021,
        }
        data = await self._client._request("GET", "/address/environment", params=params)
        return EnvironmentResponse.model_validate(data)

    async def demographics(
        self,
        *,
        address: Optional[str] = None,
        address_keys: Optional[List[str]] = None,
        legal_parcel_id: Optional[str] = None,
        mb_category_2021: Optional[List[str]] = None,
    ) -> DemographicsResponse:
        """Retrieve demographic indices for an address.

        Exactly one of ``address``, ``address_keys``, or ``legal_parcel_id``
        must be provided.

        Args:
            address: Full address string to look up.
            address_keys: One or more GNAF address keys.
            legal_parcel_id: Legal parcel identifier.
            mb_category_2021: Mesh-block category filter.

        Returns:
            A :class:`DemographicsResponse` with demographic records.
        """
        params = {
            "address": address,
            "address_keys": address_keys,
            "legal_parcel_id": legal_parcel_id,
            "mb_category_2021": mb_category_2021,
        }
        data = await self._client._request("GET", "/address/demographics", params=params)
        return DemographicsResponse.model_validate(data)
