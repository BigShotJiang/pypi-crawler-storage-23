"""Synchronous client for the Reference API domain."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from htag_sdk.reference.models import LgaResponse, LocalityResponse

if TYPE_CHECKING:
    from htag_sdk._base import SyncRequestMixin


class ReferenceClient:
    """Synchronous client for reference data (localities, LGAs).

    This class is not instantiated directly. Access it via ``client.reference``.
    """

    _client: "SyncRequestMixin"

    def __init__(self, client: "SyncRequestMixin") -> None:
        self._client = client

    def locality(
        self,
        *,
        loc_pid: Optional[str] = None,
        state_name: Optional[str] = None,
        lga_pid: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> LocalityResponse:
        """Look up locality (suburb) reference data.

        Args:
            loc_pid: Filter by locality PID.
            state_name: Filter by state (e.g. ``"NSW"``, ``"VIC"``).
            lga_pid: Filter by LGA PID.
            limit: Maximum results (1-1000, default 100).
            offset: Pagination offset.

        Returns:
            A :class:`LocalityResponse` with matching locality records.
        """
        params = {
            "loc_pid": loc_pid,
            "state_name": state_name,
            "lga_pid": lga_pid,
            "limit": limit,
            "offset": offset,
        }
        data = self._client._request("GET", "/reference/locality", params=params)
        return LocalityResponse.model_validate(data)

    def lga(
        self,
        *,
        state_name: Optional[str] = None,
        lga_pid: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> LgaResponse:
        """Look up Local Government Area reference data.

        Args:
            state_name: Filter by state (e.g. ``"NSW"``, ``"VIC"``).
            lga_pid: Filter by LGA PID.
            limit: Maximum results (1-1000, default 100).
            offset: Pagination offset.

        Returns:
            A :class:`LgaResponse` with matching LGA records.
        """
        params = {
            "state_name": state_name,
            "lga_pid": lga_pid,
            "limit": limit,
            "offset": offset,
        }
        data = self._client._request("GET", "/reference/lga", params=params)
        return LgaResponse.model_validate(data)
