"""Reference API domain — locality and LGA lookups."""

from htag_sdk.reference.async_client import AsyncReferenceClient
from htag_sdk.reference.client import ReferenceClient
from htag_sdk.reference.models import (
    LgaRecord,
    LgaResponse,
    LocalityRecord,
    LocalityResponse,
)

__all__ = [
    "AsyncReferenceClient",
    "ReferenceClient",
    "LgaRecord",
    "LgaResponse",
    "LocalityRecord",
    "LocalityResponse",
]
