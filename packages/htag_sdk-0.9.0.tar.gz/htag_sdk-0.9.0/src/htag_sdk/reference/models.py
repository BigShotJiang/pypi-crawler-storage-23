"""Pydantic models for the Reference API domain."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class LocalityRecord(BaseModel):
    """A locality (suburb) reference record."""

    model_config = ConfigDict(populate_by_name=True)

    loc_pid: Optional[str] = None
    locality: Optional[str] = None
    postcode: Optional[str] = None
    state_name: Optional[str] = None
    suburb_key: Optional[str] = None
    lga_pid_ref: Optional[str] = None


class LocalityResponse(BaseModel):
    """Response from the reference locality endpoint."""

    model_config = ConfigDict(populate_by_name=True)

    total: int
    results: List[LocalityRecord]


class LgaRecord(BaseModel):
    """A Local Government Area reference record."""

    model_config = ConfigDict(populate_by_name=True)

    lga_pid: Optional[str] = None
    lga_name: Optional[str] = None
    state_name: Optional[str] = None
    lga_key: Optional[str] = None


class LgaResponse(BaseModel):
    """Response from the reference LGA endpoint."""

    model_config = ConfigDict(populate_by_name=True)

    total: int
    results: List[LgaRecord]
