User Guide
==========

This section provides detailed guidance on using routilux.

.. toctree::
   :maxdepth: 2

   routines
   builtin_routines
   flows
   connections
   aggregation_pattern
   state_management
   error_handling
   job_state
   serialization
   identifiers

