Slot API
========

.. automodule:: routilux.slot
   :members:
   :undoc-members:
   :show-inheritance:

