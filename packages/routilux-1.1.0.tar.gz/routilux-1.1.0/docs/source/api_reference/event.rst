Event API
=========

.. automodule:: routilux.event
   :members:
   :undoc-members:
   :show-inheritance:

