Design Documentation
=====================

This section provides detailed design documentation for routilux.

.. toctree::
   :maxdepth: 2

   overview
   architecture
   optimization
   code_review

