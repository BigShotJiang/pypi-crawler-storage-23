Examples
========

This section contains practical examples demonstrating routilux usage.

.. toctree::
   :maxdepth: 2

   basic_example
   data_processing
   error_handling_example
   state_management_example
   concurrent_flow_demo
   llm_agent_cross_host

