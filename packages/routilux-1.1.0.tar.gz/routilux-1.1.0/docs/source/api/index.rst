API Documentation
=================

This section contains detailed API documentation for Routilux.

.. toctree::
   :maxdepth: 2

   contract
   error_handling
