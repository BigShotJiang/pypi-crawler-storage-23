"""Routilux CLI package for workflow management."""

from routilux import __version__

__all__ = ["__version__"]
