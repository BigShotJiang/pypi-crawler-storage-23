"""
Utility routines.

General-purpose utility routines for common operations.
"""

__all__: list[str] = []
