"""
Event class for sending data to other routines.

Output events for transmitting data to connected slots.
"""

from __future__ import annotations

import threading
from datetime import datetime
from typing import TYPE_CHECKING, Any

from serilux import Serializable

from routilux.core.interfaces import IEventHandler

if TYPE_CHECKING:
    from routilux.core.routine import Routine
    from routilux.core.slot import Slot
    from routilux.core.worker import WorkerState


# Note: Not using @register_serializable to avoid conflict with legacy module
class Event(Serializable):
    """Output event for transmitting data to other routines.

    An Event represents an output point in a Routine that can transmit data
    to connected Slots. Events enable one-to-many data distribution.

    Key Concepts:
        - Events are defined in routines using add_event()
        - Events are emitted using emit() or Routine.emit()
        - Events can connect to multiple slots (broadcast pattern)

    Examples:
        >>> class MyRoutine(Routine):
        ...     def setup(self):
        ...         self.add_event("output")
        ...
        ...     def logic(self, *args, **kwargs):
        ...         self.emit("output", result="success")
    """

    def __init__(
        self,
        name: str = "",
        routine: Routine | None = None,
        output_params: list[str] | None = None,
    ):
        """Initialize an Event.

        Args:
            name: Event name
            routine: Parent Routine object
            output_params: List of output parameter names (for documentation)
        """
        super().__init__()
        self.name: str = name
        self.routine: Routine | None = routine
        self.output_params: list[str] = output_params or []
        self.connected_slots: list[Slot] = []
        self._connection_lock: threading.RLock = threading.RLock()

        # Register serializable fields
        self.add_serializable_fields(["name", "output_params"])

    def __repr__(self) -> str:
        """Return string representation."""
        if self.routine:
            return f"Event[{getattr(self.routine, '_id', 'unknown')}.{self.name}]"
        return f"Event[{self.name}]"

    def connect(self, slot: Slot) -> None:
        """Connect to a slot (thread-safe)."""
        lock1, lock2 = sorted((self._connection_lock, slot._connection_lock), key=id)
        with lock1, lock2:
            if slot not in self.connected_slots:
                self.connected_slots.append(slot)
                if self not in slot.connected_events:
                    slot.connected_events.append(self)

    def disconnect(self, slot: Slot) -> None:
        """Disconnect from a slot (thread-safe)."""
        lock1, lock2 = sorted((self._connection_lock, slot._connection_lock), key=id)
        with lock1, lock2:
            if slot in self.connected_slots:
                self.connected_slots.remove(slot)
                if self in slot.connected_events:
                    slot.connected_events.remove(self)

    def emit(self, runtime: IEventHandler, worker_state: WorkerState, **kwargs: Any) -> None:
        """Emit the event and route data to connected slots.

        This method packs data with metadata and creates an EventRoutingTask
        that will be processed in the WorkerExecutor's event loop thread.

        Args:
            runtime: Event handler (Runtime or compatible)
            worker_state: WorkerState for this execution
            **kwargs: Data to transmit

        Examples:
            >>> event.emit(runtime=runtime, worker_state=worker_state, result="data")

        **Context Variable (contextvar) Requirements:**

        This method automatically retrieves the current ``JobContext`` from the
        thread-local context using ``get_current_job()``. The job_context is then
        passed to the EventRoutingTask for proper breakpoint checking and job tracking.

        **Important for Testing:**
        When calling ``emit()`` directly in tests (outside of normal routine execution),
        you must set the job_context in the current thread's context:

        .. code-block:: python

            from routilux.core.context import set_current_job

            # In your test
            worker_state, job_context = runtime.post(...)
            set_current_job(job_context)  # Required for breakpoint checking

            # Now emit will have access to job_context
            source.output.emit(runtime=runtime, worker_state=worker_state, data="test")

        **Why this matters:**
        - Breakpoint checking requires job_context to match breakpoints by job_id
        - Without job_context, breakpoints will not trigger even if conditions match
        - The job_context is automatically set during normal routine execution
        - In tests, you must manually set it when calling emit() directly

        **Normal Usage (within routine logic):**
        When called from within a routine's logic method, the job_context is
        automatically available because WorkerExecutor sets it in the context
        before executing the routine.
        """
        # Pack data with metadata
        emitted_from = "unknown"
        if self.routine:
            emitted_from = getattr(self.routine, "_id", None) or self.routine.__class__.__name__

        event_data = {
            "data": kwargs,
            "metadata": {
                "emitted_at": datetime.now(),
                "emitted_from": emitted_from,
                "event_name": self.name,
            },
        }

        # Get WorkerExecutor from worker_state
        worker_executor = getattr(worker_state, "_executor", None)
        if worker_executor is None:
            raise RuntimeError(
                "WorkerExecutor not found in worker_state. Event routing requires a WorkerExecutor."
            )

        # Get current job context for propagation
        from routilux.core.context import get_current_job

        job_context = get_current_job()

        # Create routing task and submit to event loop thread
        from routilux.core.task import EventRoutingTask

        routing_task = EventRoutingTask(
            event=self,
            event_data=event_data,
            worker_state=worker_state,
            runtime=runtime,
            job_context=job_context,  # Pass job_context for propagation
        )

        worker_executor.enqueue_task(routing_task)

    def serialize(self) -> dict[str, Any]:
        """Serialize the Event."""
        return super().serialize()

    def deserialize(
        self, data: dict[str, Any], strict: bool = False, registry: Any | None = None
    ) -> None:
        """Deserialize the Event."""
        super().deserialize(data, strict=strict, registry=registry)
