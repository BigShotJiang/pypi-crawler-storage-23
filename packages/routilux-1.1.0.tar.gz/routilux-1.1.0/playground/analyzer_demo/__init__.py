"""
Analyzer Demo - Routine and Workflow Analysis Tool

This demo provides comprehensive analysis and export functionality for
routilux routines and workflows.
"""

