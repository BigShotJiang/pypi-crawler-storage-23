"""Retry and serialization demonstration for routilux."""

