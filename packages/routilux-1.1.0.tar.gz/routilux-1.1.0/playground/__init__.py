"""
Playground for routilux demonstrations and examples.

This package contains various demo systems showcasing routilux capabilities.
"""

__version__ = "1.0.0"

