"""Misconfiguration demo package."""

