"""
测试工具函数
"""


def setup_test_environment():
    """设置测试环境"""
    # 确保可以导入 routilux
    pass
