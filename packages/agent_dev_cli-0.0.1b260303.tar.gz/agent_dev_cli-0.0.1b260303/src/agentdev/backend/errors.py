class ExecutorInputNotSupported(TypeError):
    pass