"""Core data models for the workflow SDK."""

from dataclasses import dataclass
from typing import List, Dict, Any, Optional


@dataclass
class MessagePayload:
    """Payload containing message text with optional selectable options.

    Used as return type for methods that generate messages with optional options lists.

    Attributes:
        message: The message text to display to the user
        options: Optional list of option dicts for selection.
                 Each dict has 'text' (display text) and 'subtext' (secondary text) keys.
        is_selectable: Whether user must select from options (True) or can type freely (False)
    """
    message: str
    options: Optional[List[Dict[str, Any]]] = None
    is_selectable: bool = False


class WorkflowResult(str):
    """A workflow execution result that extends str with rich metadata.

    This is a str subclass, so all standard string operations work:
        result == "some string"
        result.startswith("__WORKFLOW_INTERRUPT__")
        result.split("|")
        print(result)

    Prefer accessing the structured attributes instead of treating the result
    as a raw string — this makes migration easier when WorkflowResult becomes
    a plain structured object in a future release.

    Attributes:
        value: The raw string result (interrupt prompt, outcome message, etc.).
        text: Clean message text without interrupt prefixes.
        options: List of option dicts for the consumer to render
                 (e.g., as WhatsApp quick reply buttons or list items).
                 Each dict has 'text' (display text) and 'subtext' (secondary text) keys.
        is_selectable: Whether the user must select from options (True)
                       or can also type freely (False).
        field_details: List of dicts describing the current collector node's
                       fields, their values, and any validation errors.
                       Each entry: {"name": str, "value": Any} with optional "label": str and "error": str
                       Empty list when no collector node is active.

    Example::

        result = workflow.execute(thread_id="t1", user_message="bad@", initial_context={})

        # Structured access (preferred — future-proof):
        print(result.text)            # Clean message text
        print(result.options)         # [{"text": "VIP", "subtext": ""}, ...]
        print(result.is_selectable)   # True
        for field in result.field_details:
            if field["error"]:
                print(f"{field['name']}: {field['error']} (was: {field['value']})")

        # String access (still works, backward-compatible):
        if result.startswith("__WORKFLOW_INTERRUPT__"):
            prompt = result.split("|")[3]
    """

    value: str
    text: str
    options: List[Dict[str, Any]]
    is_selectable: bool
    field_details: List[Dict[str, Any]]

    def __new__(
        cls,
        value: str,
        field_details: List[Dict[str, Any]] = None,
        text: str = None,
        options: List[Dict[str, Any]] = None,
        is_selectable: bool = False,
    ):
        instance = super().__new__(cls, value)
        instance.value = str(value)
        instance.text = text if text is not None else str(value)
        instance.options = options if options is not None else []
        instance.is_selectable = is_selectable
        instance.field_details = field_details if field_details is not None else []
        return instance

    def __repr__(self) -> str:
        base = super().__repr__()
        if self.field_details:
            return f"WorkflowResult({base}, field_details={self.field_details!r})"
        return f"WorkflowResult({base})"
