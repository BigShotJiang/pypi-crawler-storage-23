"""
Workflow Tools - Wraps workflows as callable tools for agent frameworks
"""
from __future__ import annotations
import json
import uuid
from typing import Optional, Dict, Any, List, Union
from .utils.logger import logger

from langfuse.langchain import CallbackHandler

from .core.engine import load_workflow
from .core.constants import MFAConfig, InterruptType, WorkflowKeys
from .core.models import WorkflowResult


class WorkflowTool:
    """Wraps a conversational workflow as a tool for agent orchestration

    This allows workflows to be used as tools in LangGraph, CrewAI, or other
    agent frameworks. The supervisor agent can decide which workflow to invoke
    based on user intent.
    """

    def __init__(
        self,
        yaml_path: str,
        name: str,
        description: str,
        checkpointer=None,
        config: Optional[Dict]=None,
        mfa_config: Optional[MFAConfig] = None
    ):
        """Initialize workflow tool

        Args:
            yaml_path: Path to workflow YAML file
            name: Tool name (used by agents to reference this tool)
            description: Tool description (helps agent decide when to use it)
            checkpointer: Optional checkpointer for persistence
        """
        self.yaml_path = yaml_path
        self.name = name
        self.description = description
        self.checkpointer = checkpointer
        self.mfa_config = mfa_config

        # Load workflow
        self.graph, self.engine = load_workflow(
            yaml_path, checkpointer=checkpointer,
            config=config, mfa_config=mfa_config
        )

    def execute(
        self,
        thread_id: Optional[str] = None,
        user_message: Optional[str] = None,
        initial_context: Optional[Dict[str, Any]] = None,
        target_language: Optional[str] = None,
        target_script: Optional[str] = None
    ) -> WorkflowResult:
        """Execute the workflow with automatic state detection

        Checks workflow state and automatically resumes if interrupted,
        or starts fresh if not started/completed.

        Args:
            thread_id: Thread ID for state tracking
            user_message: User's message (used for resume if workflow is interrupted)
            initial_context: Context to inject for fresh starts (e.g., {"order_id": "123"})
            target_language: Target language for this turn (e.g., "Tamil", "Hindi")
            target_script: Target script for this turn (e.g., "Tamil", "Devanagari")

        Returns:
            WorkflowResult (str subclass) with .field_details for the active collector node
        """
        from langgraph.types import Command
        from soprano_sdk.utils.tracing import trace_workflow_execution

        if thread_id is None:
            thread_id = str(uuid.uuid4())

        # Build localization state for this turn
        localization_state = {}
        if target_language:
            localization_state[WorkflowKeys.TARGET_LANGUAGE] = target_language
        if target_script:
            localization_state[WorkflowKeys.TARGET_SCRIPT] = target_script

        with trace_workflow_execution(
            workflow_name=self.engine.workflow_name,
            thread_id=thread_id,
            has_initial_context=initial_context is not None
        ) as span:
            callback_handler = CallbackHandler()
            config = {"configurable": {"thread_id": thread_id}, "callbacks": [callback_handler]}

            state = self.graph.get_state(config)

            # Intelligently update context based on workflow state
            if state.next:
                # Workflow is resuming - only update fields that haven't been collected yet
                span.set_attribute("workflow.resumed", True)
                logger.info(f"[WorkflowTool] Resuming interrupted workflow {self.name} (thread: {thread_id})")

                filtered_context = self._filter_already_collected_fields(state.values, initial_context)
                self.engine.update_context(filtered_context)

                span.add_event("context.updated", {
                    "fields": list(filtered_context.keys()),
                    "filtered_out": list(set(initial_context.keys()) - set(filtered_context.keys()))
                })

                # Merge localization state with filtered context
                update_state = {**filtered_context, **localization_state}
                result = self.graph.invoke(
                    Command(resume=user_message or "", update=update_state),
                    config=config
                )

            else:
                # Fresh start - update all fields from initial_context
                span.set_attribute("workflow.resumed", False)
                logger.info(f"[WorkflowTool] Starting fresh workflow {self.name} (thread: {thread_id})")

                self.engine.update_context(initial_context)
                span.add_event("context.updated", {"fields": list(initial_context.keys())})

                # Merge localization state with initial context
                invoke_state = {**(initial_context or {}), **localization_state}
                result = self.graph.invoke(invoke_state, config=config)
            
            final_state = self.graph.get_state(config)
            if not final_state.next and self.checkpointer:
                self.checkpointer.delete_thread(thread_id)

            # If workflow needs user input or async operation, return structured interrupt data
            if "__interrupt__" in result and result["__interrupt__"]:
                interrupt_value = result["__interrupt__"][0].value
                
                # Get the actual state
                current_state = final_state.values
                
                if final_state.next and len(final_state.next) > 0:
                    field_details_state = current_state
                    field_details_node_id = final_state.next[0]
                else:
                    field_details_state = current_state
                    field_details_node_id = None

                # Check if this is an async interrupt
                if isinstance(interrupt_value, dict) and interrupt_value.get("type") == "async":
                    span.set_attribute("workflow.status", "async_interrupted")
                    span.set_attribute("async.step_id", interrupt_value.get("step_id", ""))
                    pending_metadata = json.dumps(interrupt_value.get("pending", {}))
                    return self._build_result(
                        f"{InterruptType.ASYNC}|{thread_id}|{self.name}|{pending_metadata}", 
                        field_details_state,
                        node_id=field_details_node_id
                    )

                # Check if this is an out-of-scope interrupt
                if isinstance(interrupt_value, dict) and interrupt_value.get("type") == "out_of_scope":
                    span.set_attribute("workflow.status", "out_of_scope")
                    span.set_attribute("out_of_scope.step_id", interrupt_value.get("step_id", ""))
                    payload = json.dumps({
                        "reason": interrupt_value.get("reason", "User query is out of scope"),
                        "user_message": interrupt_value.get("user_message", "")
                    })
                    return self._build_result(
                        f"{InterruptType.OUT_OF_SCOPE}|{thread_id}|{self.name}|{payload}", 
                        field_details_state,
                        node_id=field_details_node_id
                    )

                # User input interrupt — may be a structured dict or plain string
                span.set_attribute("workflow.status", "interrupted")
                if isinstance(interrupt_value, dict) and "text" in interrupt_value:
                    prompt = interrupt_value["text"]
                    options = interrupt_value.get("options", [])
                    is_selectable = interrupt_value.get("is_selectable", False)
                else:
                    prompt = str(interrupt_value)
                    options = []
                    is_selectable = False
                return self._build_result(
                    f"{InterruptType.USER_INPUT}|{thread_id}|{self.name}|{prompt}",
                    field_details_state,
                    text=prompt, options=options, is_selectable=is_selectable,
                    node_id=field_details_node_id
                )

            # Workflow completed without interrupting
            span.set_attribute("workflow.status", "completed")
            outcome = self.engine.get_outcome_message(result, thread_id=thread_id, workflow_name=self.name)
            return self._build_result(outcome.message, result, options=outcome.options, is_selectable=outcome.is_selectable)

    def _filter_already_collected_fields(
        self,
        current_state: Dict[str, Any],
        initial_context: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Filter initial_context to exclude fields that are referenced by any
        input collector node. On resume, initial_context should not override
        any state fields used by collector nodes — initial_context is intended
        only for the first invocation of the workflow.

        Args:
            current_state: Current workflow state
            initial_context: Context to filter

        Returns:
            Filtered context excluding all collector node fields
        """
        if not initial_context:
            return {}

        node_to_field_map = self.engine.collector_node_field_map

        # Gather ALL fields referenced by ANY collector node
        collector_fields = set()
        for field_or_fields in node_to_field_map.values():
            if isinstance(field_or_fields, list):
                collector_fields.update(field_or_fields)
            else:
                collector_fields.add(field_or_fields)

        # Filter initial_context to exclude all collector node fields
        filtered_context = {
            field: value
            for field, value in initial_context.items()
            if field not in collector_fields
        }

        excluded = set(initial_context.keys()) & collector_fields
        if excluded:
            logger.info(
                f"[WorkflowTool] Resuming workflow — filtered out collector node fields "
                f"from initial_context: {excluded}. "
                f"Passing through non-collector fields: {list(filtered_context.keys())}"
            )

        return filtered_context

    def _build_result(
        self,
        message: str,
        state: Dict[str, Any],
        text: Optional[str] = None,
        options: Optional[List] = None,
        is_selectable: bool = False,
        node_id: Optional[str] = None,
    ) -> WorkflowResult:
        """Wrap a string result with field details and rendering hints.

        Args:
            message: The raw string result (interrupt prompt, outcome, etc.)
            state: The workflow state dictionary
            text: Clean message text (defaults to message if not provided)
            options: List of options for consumer rendering
            is_selectable: Whether user must select from options
            node_id: Optional node ID to use for building field details (when STATUS isn't set)

        Returns:
            WorkflowResult with structured attributes for consumer rendering.
        """
        # Build field details using node_id if provided, otherwise use STATUS from state
        field_details = self.engine.build_field_details(state, node_id=node_id)
        
        return WorkflowResult(
            message,
            field_details=field_details,
            text=text or message,
            options=options or [],
            is_selectable=is_selectable,
        )

    def resume(
        self,
        thread_id: str,
        resume_value: Union[str, Dict[str, Any]],
        target_language: Optional[str] = None,
        target_script: Optional[str] = None
    ) -> WorkflowResult:
        """Resume an interrupted workflow with user input or async result

        Args:
            thread_id: Thread ID of the interrupted workflow
            resume_value: User's response (str) or async operation result (dict)
            target_language: Target language for this turn (e.g., "Tamil", "Hindi")
            target_script: Target script for this turn (e.g., "Tamil", "Devanagari")

        Returns:
            WorkflowResult (str subclass) with .field_details for the active collector node
        """
        from langgraph.types import Command

        # Build localization state for this turn
        localization_state = {}
        if target_language:
            localization_state[WorkflowKeys.TARGET_LANGUAGE] = target_language
        if target_script:
            localization_state[WorkflowKeys.TARGET_SCRIPT] = target_script

        config = {"configurable": {"thread_id": thread_id}}
        if localization_state:
            result = self.graph.invoke(Command(resume=resume_value, update=localization_state), config=config)
        else:
            result = self.graph.invoke(Command(resume=resume_value), config=config)

        # Check if workflow needs more input or has another async operation
        if "__interrupt__" in result and result["__interrupt__"]:
            interrupt_value = result["__interrupt__"][0].value

            # Check if this is an async interrupt
            if isinstance(interrupt_value, dict) and interrupt_value.get("type") == "async":
                pending_metadata = json.dumps(interrupt_value.get("pending", {}))
                return self._build_result(
                    f"{InterruptType.ASYNC}|{thread_id}|{self.name}|{pending_metadata}", 
                    self.graph.get_state(config).values  # Get actual state
                )

            # Check if this is an out-of-scope interrupt
            if isinstance(interrupt_value, dict) and interrupt_value.get("type") == "out_of_scope":
                payload = json.dumps({
                    "reason": interrupt_value.get("reason", "User query is out of scope"),
                    "user_message": interrupt_value.get("user_message", "")
                })
                return self._build_result(
                    f"{InterruptType.OUT_OF_SCOPE}|{thread_id}|{self.name}|{payload}", 
                    self.graph.get_state(config).values  # Get actual state
                )

            # User input interrupt — may be a structured dict or plain string
            if isinstance(interrupt_value, dict) and "text" in interrupt_value:
                prompt = interrupt_value["text"]
                options = interrupt_value.get("options", [])
                is_selectable = interrupt_value.get("is_selectable", False)
            else:
                prompt = str(interrupt_value)
                options = []
                is_selectable = False
            return self._build_result(
                f"{InterruptType.USER_INPUT}|{thread_id}|{self.name}|{prompt}",
                self.graph.get_state(config).values,  # Get actual state
                text=prompt, options=options, is_selectable=is_selectable
            )

        # Workflow completed
        outcome = self.engine.get_outcome_message(result, thread_id=thread_id, workflow_name=self.name)
        return self._build_result(outcome.message, result, options=outcome.options, is_selectable=outcome.is_selectable)

    def to_langchain_tool(self):
        """Convert to LangChain tool format

        Returns:
            LangChain Tool that can be used by LangGraph agents
        """
        from langchain_core.tools import tool

        # Create function with proper name and docstring
        def workflow_tool(context: str = "") -> str:
            """Execute workflow with optional context"""
            # Parse context if provided (simple key=value format)
            initial_context = {}
            if context:
                for pair in context.split(","):
                    if "=" in pair:
                        key, value = pair.split("=", 1)
                        initial_context[key.strip()] = value.strip()

            return self.execute(initial_context=initial_context)

        # Set function name and docstring from tool definition
        workflow_tool.__name__ = self.name
        workflow_tool.__doc__ = self.description

        # Decorate and return
        return tool(workflow_tool)

    def to_crewai_tool(self):
        """Convert to CrewAI tool format

        Returns:
            CrewAI BaseTool that can be used by CrewAI agents
        """
        from crewai.tools import BaseTool

        # Capture self in closure
        workflow_tool = self

        # Create a custom CrewAI tool class
        class WorkflowCrewAITool(BaseTool):
            name: str = workflow_tool.name
            description: str = workflow_tool.description

            def _run(self, context: str = "") -> str:
                """Execute workflow with optional context"""
                # Parse context if provided (simple key=value format)
                initial_context = {}
                if context:
                    for pair in context.split(","):
                        if "=" in pair:
                            key, value = pair.split("=", 1)
                            initial_context[key.strip()] = value.strip()

                return workflow_tool.execute(initial_context=initial_context)

        # Return an instance of the tool
        return WorkflowCrewAITool()

    def get_mermaid_diagram(self) -> str:
        return self.graph.get_graph().draw_mermaid()

    def __call__(self, **kwargs) -> str:
        """Allow tool to be called directly

        Args:
            **kwargs: Context to pass to workflow

        Returns:
            Workflow result
        """
        return self.execute(initial_context=kwargs)
