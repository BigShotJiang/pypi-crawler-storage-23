#pragma once
#include <Eigen/Dense>
#include <SFML/Graphics.hpp>