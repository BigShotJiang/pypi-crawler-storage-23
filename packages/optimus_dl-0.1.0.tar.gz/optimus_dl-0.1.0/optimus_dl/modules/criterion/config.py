from dataclasses import dataclass

from optimus_dl.core.registry import RegistryConfig


@dataclass
class CriterionConfig(RegistryConfig):
    pass
