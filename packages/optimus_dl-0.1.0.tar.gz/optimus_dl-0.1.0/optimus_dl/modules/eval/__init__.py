from optimus_dl.core.bootstrap import bootstrap_module

from .model import LLMBaselinesModel

bootstrap_module(__name__)
