from dataclasses import dataclass

from optimus_dl.core.registry import RegistryConfig


@dataclass
class ModelConfig(RegistryConfig):
    pass
