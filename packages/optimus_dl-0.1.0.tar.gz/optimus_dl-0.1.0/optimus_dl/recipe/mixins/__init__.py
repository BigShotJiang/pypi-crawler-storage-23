"""Shared mixins that can be used across different recipe types."""

from .model_builder import ModelBuilder

__all__ = ["ModelBuilder"]
