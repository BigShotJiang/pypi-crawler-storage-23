from optimus_dl.core.bootstrap import bootstrap_module

bootstrap_module(__name__)
