"""
Setup script for LFC Demo Library

Note: This setup.py is maintained for backward compatibility.
All configuration is in pyproject.toml (PEP 621).
This file exists only for legacy tools that don't support pyproject.toml.
"""

from setuptools import setup

# All configuration is in pyproject.toml
# This minimal setup.py exists only for backward compatibility
setup()
