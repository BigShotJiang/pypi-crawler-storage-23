"""OnnxInputAdapter tests — format support, validation, and error handling."""

from __future__ import annotations

import pytest

from matrice_export.adapters.onnx_input import OnnxInputAdapter

# ------------------------------------------------------------------ #
# 1. Supported formats
# ------------------------------------------------------------------ #


class TestOnnxInputAdapterSupportedFormats:
    def test_contains_expected_formats(self):
        """SUPPORTED_FORMATS contains the core downstream formats."""
        expected = {"openvino", "engine", "coreml", "tflite"}
        actual = set(OnnxInputAdapter.SUPPORTED_FORMATS)
        assert expected == actual

    def test_is_non_empty(self):
        """SUPPORTED_FORMATS is a non-empty list."""
        assert len(OnnxInputAdapter.SUPPORTED_FORMATS) > 0


# ------------------------------------------------------------------ #
# 2. Invalid format
# ------------------------------------------------------------------ #


class TestOnnxInputAdapterInvalidFormat:
    def test_unsupported_format_raises_value_error(self, onnx_model_path, tmp_path):
        """Requesting an unsupported format raises ValueError."""
        adapter = OnnxInputAdapter()
        with pytest.raises(ValueError, match="Unsupported"):
            adapter.export(onnx_model_path, "totally_fake_xyz", str(tmp_path))

    def test_error_message_lists_supported(self, onnx_model_path, tmp_path):
        """The ValueError mentions the supported formats."""
        adapter = OnnxInputAdapter()
        with pytest.raises(ValueError, match="openvino"):
            adapter.export(onnx_model_path, "fake_format", str(tmp_path))


# ------------------------------------------------------------------ #
# 3. File not found
# ------------------------------------------------------------------ #


class TestOnnxInputAdapterFileNotFound:
    def test_nonexistent_onnx_raises(self, tmp_path):
        """Passing a non-existent ONNX file raises FileNotFoundError."""
        adapter = OnnxInputAdapter()
        with pytest.raises(FileNotFoundError, match="ONNX model not found"):
            adapter.export(str(tmp_path / "nonexistent.onnx"), "openvino", str(tmp_path))

    def test_nonexistent_with_engine_format(self, tmp_path):
        """FileNotFoundError also raised for engine format."""
        adapter = OnnxInputAdapter()
        with pytest.raises(FileNotFoundError):
            adapter.export(str(tmp_path / "nope.onnx"), "engine", str(tmp_path))


# ------------------------------------------------------------------ #
# 4. Bad file (not a real ONNX)
# ------------------------------------------------------------------ #


class TestOnnxInputAdapterBadFile:
    def test_non_onnx_file_detected_by_adapter(self, tmp_path):
        """Passing a directory (not a file) as onnx_path raises FileNotFoundError."""
        # Use a directory path — os.path.isfile will fail
        adapter = OnnxInputAdapter()
        with pytest.raises(FileNotFoundError):
            adapter.export(str(tmp_path), "openvino", str(tmp_path / "out"))
