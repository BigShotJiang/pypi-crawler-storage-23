"""Base exporter interface for all export formats."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import torch

logger = logging.getLogger(__name__)


class BaseExporter(ABC):
    """Abstract base class for model format exporters.

    Each format (ONNX, TorchScript, TensorRT, etc.) implements this interface.
    The ExportPipeline dispatches to the appropriate exporter based on format name.
    """

    @abstractmethod
    def export(
        self,
        model: torch.nn.Module,
        sample_input: torch.Tensor,
        output_dir: str | Path,
        file_stem: str = "model",
        **kwargs,
    ) -> str:
        """Export a PyTorch model to this format.

        Args:
            model: PyTorch model in eval mode.
            sample_input: Sample input tensor (BCHW format).
            output_dir: Directory to save exported model.
            file_stem: Base filename without extension.
            **kwargs: Format-specific options (half, dynamic, simplify, etc.).

        Returns:
            Path to the exported model file or directory.
        """

    @property
    @abstractmethod
    def format_name(self) -> str:
        """Canonical format name used in ExportPipeline registry (e.g. 'onnx', 'torchscript')."""

    @property
    @abstractmethod
    def suffix(self) -> str:
        """File extension or directory suffix (e.g. '.onnx', '.torchscript', '_openvino_model')."""

    @property
    def requires_gpu(self) -> bool:
        """Whether this format requires a GPU for export."""
        return False
