"""Edge GPU deployment tools (CoreML, MPS, DirectML).

This sub-package provides optimised inference and export paths for
edge / on-device GPU hardware:

* :mod:`~matrice_export.edge.coreml_opt` -- Apple Neural Engine optimised CoreML
  export and validation.
* :mod:`~matrice_export.edge.mps_inference` -- MPS (Apple Silicon GPU) model
  loading, inference, and benchmarking.
* :mod:`~matrice_export.edge.directml` -- Windows iGPU inference via DirectML +
  ONNX Runtime, with benchmarking.
"""

from matrice_export.edge.coreml_opt import export_coreml_optimized, validate_coreml
from matrice_export.edge.directml import (
    benchmark_directml,
    get_directml_info,
    load_onnx_directml,
    run_inference_directml,
)
from matrice_export.edge.mps_inference import (
    benchmark_mps,
    load_model_mps,
    run_inference_mps,
)

__all__ = [
    # CoreML optimised
    "export_coreml_optimized",
    "validate_coreml",
    # MPS
    "load_model_mps",
    "run_inference_mps",
    "benchmark_mps",
    # DirectML
    "load_onnx_directml",
    "run_inference_directml",
    "get_directml_info",
    "benchmark_directml",
]
