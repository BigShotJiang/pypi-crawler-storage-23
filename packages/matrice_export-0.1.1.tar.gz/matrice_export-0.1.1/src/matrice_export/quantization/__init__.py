"""Quantization tools (FP16, INT8) and benchmarking.

This sub-package provides ONNX model quantization utilities and a
comparison benchmarking framework:

* :mod:`~matrice_export.quantization.fp16` -- FP16 (half-precision) conversion
  via ``onnxconverter-common``.
* :mod:`~matrice_export.quantization.int8` -- Dynamic and static INT8 quantization
  via ``onnxruntime.quantization``.
* :mod:`~matrice_export.quantization.benchmark` -- Side-by-side comparison of
  model size, latency, and accuracy across quantization variants.
"""

from matrice_export.quantization.benchmark import benchmark_quantization
from matrice_export.quantization.fp16 import get_fp16_model_info, quantize_fp16
from matrice_export.quantization.int8 import quantize_int8, quantize_int8_static

__all__ = [
    # FP16
    "quantize_fp16",
    "get_fp16_model_info",
    # INT8
    "quantize_int8",
    "quantize_int8_static",
    # Benchmark
    "benchmark_quantization",
]
