"""Contextvars-based trace context propagation."""

import contextvars
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

_current_context: contextvars.ContextVar = contextvars.ContextVar(
    "llmtracer_ctx", default=None
)


@dataclass
class TraceContext:
    trace_id: str
    span_id: str
    tags: Dict[str, Any]
    parent_span_id: Optional[str] = None


def get_current() -> Optional[TraceContext]:
    return _current_context.get()


def push(tags: Dict[str, Any]) -> tuple:
    """Push a new trace context. Returns (token, context) for cleanup."""
    parent = _current_context.get()

    ctx = TraceContext(
        trace_id=parent.trace_id if parent else str(uuid.uuid4()),
        span_id=str(uuid.uuid4()),
        tags={**(parent.tags if parent else {}), **tags},
        parent_span_id=parent.span_id if parent else None,
    )

    token = _current_context.set(ctx)
    return token, ctx


def pop(token):
    """Restore previous context."""
    _current_context.reset(token)
