"""Crash-proof monkey-patch wrappers for sync and async LLM calls."""

import functools
import time

from . import _config, _caller, _context, _schema, _transport

# ── Cost table ($ per 1M tokens) ──────────────────────────────────────────────
# Used only for debug-mode pretty printing. Not exhaustive.

_COST_PER_M = {
    "gpt-4o": (2.50, 10.00),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4-turbo": (10.00, 30.00),
    "gpt-4": (30.00, 60.00),
    "gpt-3.5-turbo": (0.50, 1.50),
    "o1": (15.00, 60.00),
    "o1-mini": (3.00, 12.00),
    "o3-mini": (1.10, 4.40),
    "claude-3-5-sonnet-20241022": (3.00, 15.00),
    "claude-3-5-haiku-20241022": (0.80, 4.00),
    "claude-3-opus-20240229": (15.00, 75.00),
    "claude-sonnet-4-5-20250929": (3.00, 15.00),
    "claude-haiku-4-5-20251001": (0.80, 4.00),
    "claude-opus-4-6": (15.00, 75.00),
}


def _estimate_cost(model, input_tokens, output_tokens):
    """Rough cost estimate for debug printing."""
    in_rate, out_rate = _COST_PER_M.get(model, (0, 0))
    return (input_tokens * in_rate + output_tokens * out_rate) / 1_000_000


def _print_capture(event):
    """Pretty-print a captured event in debug mode."""
    provider = event.get("provider", "?")
    model = event.get("model", "?")
    inp = event.get("input_tokens", 0)
    out = event.get("output_tokens", 0)
    latency = event.get("latency_ms", 0)
    caller = event.get("caller_file", "?")
    line = event.get("caller_line", "?")
    cost = _estimate_cost(model, inp, out)

    # Shorten caller path to just filename
    if "/" in caller:
        caller = caller.rsplit("/", 1)[-1]
    elif "\\" in caller:
        caller = caller.rsplit("\\", 1)[-1]

    parts = [
        f"[llmtracer] {provider}/{model}",
        f"{inp:,}\u2192{out:,} tokens",
    ]
    if cost > 0:
        parts.append(f"${cost:.4f}")
    parts.append(f"{latency / 1000:.1f}s")
    parts.append(f"({caller}:{line})")

    trace_ctx = _context.get_current()
    if trace_ctx and trace_ctx.tags:
        first_tag = next(iter(trace_ctx.tags.values()), None)
        if first_tag:
            parts.append(f"trace:{first_tag}")

    print("  ".join(parts))


def _build_context(provider, kwargs):
    """Capture trace context and caller info for an LLM call."""
    ctx = _context.get_current()
    context_data = {}
    if ctx:
        context_data = {
            "trace_id": ctx.trace_id,
            "span_id": ctx.span_id,
            "parent_span_id": ctx.parent_span_id,
            "tags": dict(ctx.tags),
        }
    caller_info = _caller.get_caller_info(depth=3)
    return {"context": context_data, "caller": caller_info, "provider": provider}


def _build_and_enqueue(context, response_data, elapsed_ms):
    """Build event from context + response and enqueue for transport."""
    event = _schema.build_event(
        context_data=context.get("context"),
        response_data=response_data,
        latency_ms=elapsed_ms,
        caller_info=context.get("caller", {}),
    )
    _transport.enqueue(event)
    if _config.debug:
        _print_capture(event)


def make_sync_wrapper(original_fn, provider, parse_response_fn, wrap_stream_fn):
    """Create a crash-proof sync wrapper."""

    @functools.wraps(original_fn)
    def wrapper(*args, **kwargs):
        if not _config.enabled:
            return original_fn(*args, **kwargs)

        # 1. Capture context (safe, no-throw)
        try:
            context = _build_context(provider, kwargs)
        except Exception:
            context = None

        # 2. Detect streaming
        is_stream = kwargs.get("stream", False)

        # 3. ALWAYS call original — never blocked, never modified
        start = time.monotonic()
        result = original_fn(*args, **kwargs)
        elapsed_ms = int((time.monotonic() - start) * 1000)

        # 4. Handle result
        if is_stream and context:
            try:
                return wrap_stream_fn(result, context, elapsed_ms, kwargs)
            except Exception:
                return result  # wrapping failed -> return raw stream

        if context:
            try:
                _build_and_enqueue(context, parse_response_fn(result), elapsed_ms)
            except Exception:
                pass  # swallow silently

        return result

    return wrapper


def make_async_wrapper(original_fn, provider, parse_response_fn, wrap_stream_fn):
    """Create a crash-proof async wrapper."""

    @functools.wraps(original_fn)
    async def wrapper(*args, **kwargs):
        if not _config.enabled:
            return await original_fn(*args, **kwargs)

        try:
            context = _build_context(provider, kwargs)
        except Exception:
            context = None

        is_stream = kwargs.get("stream", False)

        start = time.monotonic()
        result = await original_fn(*args, **kwargs)
        elapsed_ms = int((time.monotonic() - start) * 1000)

        if is_stream and context:
            try:
                return wrap_stream_fn(result, context, elapsed_ms, kwargs)
            except Exception:
                return result

        if context:
            try:
                _build_and_enqueue(context, parse_response_fn(result), elapsed_ms)
            except Exception:
                pass

        return result

    return wrapper


def make_stream_wrapper(original_fn, provider, parse_response_fn, wrap_manager_fn):
    """Create a crash-proof wrapper for .stream() methods.

    .stream() is always a sync method (on both Messages and AsyncMessages)
    that returns a context manager.  The wrapper captures timing context
    up-front and delegates to wrap_manager_fn to intercept __exit__/__aexit__.
    """

    @functools.wraps(original_fn)
    def wrapper(*args, **kwargs):
        if not _config.enabled:
            return original_fn(*args, **kwargs)

        try:
            context = _build_context(provider, kwargs)
        except Exception:
            context = None

        start = time.monotonic()
        result = original_fn(*args, **kwargs)

        if context:
            try:
                return wrap_manager_fn(result, context, start, kwargs)
            except Exception:
                return result

        return result

    return wrapper
