# dagster-deltalake-polars

The docs for `dagster-deltalake-polars` can be found
[here](https://docs.dagster.io/integrations/libraries/deltalake/dagster-deltalake-polars).
