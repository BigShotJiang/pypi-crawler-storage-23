# `perfuse`

Perfusion of tissue/cell culture systems with XCaliburD syringes.

With the first public release, `0.1.0`, development of this package is considered complete and will
not undergo major changes moving forward. The software has been tested in our fluidics system and is
robust/stable enough for our use-case in an academic research setting.

Note that this release is for documentation purposes only; use at your own risk.
