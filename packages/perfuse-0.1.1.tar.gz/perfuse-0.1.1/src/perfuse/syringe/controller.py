"""Module `perfuse.syringe.controller`."""

import functools as ft
import inspect
import logging
import time
from typing import TYPE_CHECKING, final, overload

from tecancavro.models import XCaliburD

from perfuse.syringe.constants import (
    ETHANOL_PORT,
    MEDIA_PORT,
    WASTE_PORT,
    WATER_PORT,
)
from perfuse.syringe.quantities import Speed, Time, Volume
from perfuse.syringe.valve import Direction, Port

if TYPE_CHECKING:
    from collections.abc import Callable
    from logging import Logger
    from pathlib import Path
    from typing import (
        Any,
        ClassVar,
        Concatenate,
        Final,
        Literal,
        LiteralString,
        Self,
    )

    from perfuse.syringe._interfaces import _Pump, _Serial


__all__: Final[list[LiteralString]] = [
    "Controller",
]


@overload
def wait_ready[T: Controller[_Pump], R: Any, **P](
    f: Callable[Concatenate[T, P], R], /
) -> Callable[Concatenate[T, P], R]: ...


@overload
def wait_ready[T: Controller[_Pump], R: Any, **P](
    *,
    timeout: int = 10,
    polling_interval: float = 0.3,
    delay: float | None = None,
) -> Callable[
    [Callable[Concatenate[T, P], R]], Callable[Concatenate[T, P], R]
]: ...


def wait_ready[T: Controller[_Pump], R: Any, **P](
    _f: Callable[Concatenate[T, P], R] | None = None,
    /,
    *,
    timeout: int = 10,
    polling_interval: float = 0.3,
    delay: float | None = None,
) -> (
    Callable[[Callable[Concatenate[T, P], R]], Callable[Concatenate[T, P], R]]
    | Callable[Concatenate[T, P], R]
):
    """Wait for pump's ready state before and after method execution."""

    def decorator(
        f: Callable[Concatenate[T, P], R], /
    ) -> Callable[Concatenate[T, P], R]:
        """Decorator."""

        @ft.wraps(f)
        def wrapper(self: T, *args: P.args, **kwargs: P.kwargs) -> R:
            """Wrap `Controller` method."""

            self.pump.waitReady(
                timeout=timeout, polling_interval=polling_interval, delay=delay
            )

            result: R = f(self, *args, **kwargs)

            self.pump.waitReady(
                timeout=timeout, polling_interval=polling_interval, delay=delay
            )

            return result

        return wrapper

    if _f is None:
        return decorator
    else:
        return decorator(_f)


@final
class Controller[T: _Pump]:
    """Syringe controller class."""

    _logger: ClassVar[Logger] = logging.getLogger("Controller")

    def __init__(self: Self, /) -> None:
        """Instantiate controller without any syringe."""

    @property
    def pump(self: Self, /) -> T:
        """Syringe getter."""

        if (pump := getattr(self, "_pump", None)) is None:
            raise RuntimeError("Pump not assigned.")

        return pump

    def log(
        self: Self, message: str, /, *, log_level: int = logging.DEBUG
    ) -> None:
        """Attach caller name to log."""

        return self.__class__._logger.log(
            log_level,
            message,
            extra={"caller_name": inspect.stack().pop(2).function},
        )

    def log_debug(self: Self, message: str, /) -> None:
        """Log message with `logging.DEBUG` severity."""

        return self.log(message, log_level=logging.DEBUG)

    def log_info(self: Self, message: str, /) -> None:
        """Log message with `logging.INFO` severity."""

        return self.log(message, log_level=logging.INFO)

    def log_warning(self: Self, message: str, /) -> None:
        """Log message with `logging.WARNING` severity."""

        return self.log(message, log_level=logging.WARNING)

    def log_error(self: Self, message: str, /) -> None:
        """Log message with `logging.ERROR` severity."""

        return self.log(message, log_level=logging.ERROR)

    def log_critical(self: Self, message: str, /) -> None:
        """Log message with `logging.CRITICAL` severity."""

        return self.log(message, log_level=logging.CRITICAL)

    def set_pump(self: Self, pump: T, /) -> None:
        """Wrap already initialized pump."""

        self._pump = pump

    def init(
        self: Self,
        /,
        *,
        init_force: Speed | None = None,
        direction: Direction | None = None,
        in_port: Port | None = None,
        out_port: Port | None = WASTE_PORT,
        verbose: bool = False,
    ) -> Literal[0]:
        """Initialize pump."""

        if verbose:
            self.log_debug("Initializing pump.")

        return self.pump.init(
            init_force=init_force
            if init_force is None
            else init_force.to_code(),
            direction=direction if direction is None else direction.value,
            in_port=in_port if in_port is None else in_port.value,
            out_port=out_port if out_port is None else out_port.value,
        )

    @wait_ready(timeout=1)  # pyrefly: ignore[bad-specialization]
    def get_current_port(self: Self, /, *, verbose: bool = False) -> Port:
        """Retrieve current active port in valve."""

        port: int = self.pump.getCurPort()

        try:
            current_port: Port = Port(port)
        except ValueError:
            raise RuntimeError(port)

        if verbose:
            self.log_debug(f"Current port: `{current_port!s}`.")

        return current_port

    @wait_ready  # pyrefly: ignore[no-matching-overload]
    def change_port(
        self: Self,
        /,
        *,
        to_port: Port,
        verbose: bool = False,
        dry_run: bool = False,
    ) -> None:
        """Move valve to target port."""

        current_port: Port = self.get_current_port(verbose=verbose)

        if current_port != to_port:
            if verbose:
                self.log_debug(
                    "Moving from port `{from_port}` to `{to_port}`.".format(
                        from_port=current_port, to_port=to_port
                    )
                )

            self.pump.changePort(
                to_port.value,
                from_port=current_port.value,
                execute=not dry_run,  # type: ignore[unexpected-keyword]
            )

        else:
            if verbose:
                self.log_debug(
                    "Valve already at port `{to_port}`.".format(
                        to_port=to_port
                    )
                )

    @wait_ready(timeout=2)  # pyrefly: ignore[bad-specialization]
    def set_speed(
        self: Self,
        dispensing_speed: Speed,
        /,
        *,
        verbose: bool = False,
        dry_run: bool = False,
    ) -> None:
        """Set syringe speed of operation."""

        if verbose:
            self.log_debug(
                "Setting speed to `{value!s}` {units!s} "
                "(code `{code!s}`).".format(
                    value=dispensing_speed.value,
                    units=dispensing_speed.units,
                    code=dispensing_speed.to_code(),
                )
            )

        self.pump.setSpeed(dispensing_speed.to_code(), execute=not dry_run)  # type: ignore[unexpected-keyword]

    @overload
    def move_plunger(
        self: Self,
        volume: Volume,
        /,
        *,
        verbose: bool = False,
        dry_run: bool = False,
    ) -> None: ...

    @overload
    def move_plunger(
        self: Self,
        absolute_position: int = 0,
        /,
        *,
        verbose: bool = False,
        dry_run: bool = False,
    ) -> None: ...

    @wait_ready  # pyrefly: ignore[no-matching-overload]
    def move_plunger(
        self: Self,
        *args: Volume | int,
        verbose: bool = False,
        dry_run: bool = False,
    ) -> None:
        """Move syringe plunger by number of steps or desired volume."""

        steps: int

        match args:
            case (int() as steps,):
                pass
            case (Volume(value=value, units=_),):
                steps = int(self.pump._ulToSteps(value))
            case ():
                steps = 0
            case _:
                raise ValueError(args)

        if verbose:
            self.log_debug(f"Moving plunger to absolute position `{steps!s}`.")

        self.pump.movePlungerAbs(steps, execute=not dry_run)  # type: ignore[unexpected-keyword]

    @wait_ready  # pyrefly: ignore[no-matching-overload]
    def transfer_liquid(
        self: Self,
        /,
        *,
        volume: Volume,
        from_port: Port = WATER_PORT,
        to_port: Port = WASTE_PORT,
        dispensing_speed: Speed | None = None,
        loading_speed: Speed | None = None,
        wait_time: Time | None = None,
        verbose: bool = False,
        dry_run: bool = False,
    ) -> None:
        """Dispense liquid from one port to another."""

        if dispensing_speed is None:
            dispensing_speed = Speed.from_code(self.pump.init_force)

        if loading_speed is None:
            loading_speed = Speed.from_code(self.pump.init_force)

        if verbose:
            self.log_debug("Started liquid dispensing subroutine.")

        self.set_speed(loading_speed, verbose=verbose, dry_run=dry_run)
        self.change_port(to_port=from_port, verbose=verbose, dry_run=dry_run)

        if verbose:
            self.log_debug(
                "Loading `{value!s}` {units!s} into syringe.".format(
                    value=volume.value, units=volume.units
                )
            )

        self.move_plunger(volume, verbose=verbose, dry_run=dry_run)

        if verbose:
            self.log_debug(
                "Preparing to dispense `{value!s}` {units!s}.".format(
                    value=volume.value, units=volume.units
                )
            )

        self.set_speed(dispensing_speed, verbose=verbose, dry_run=dry_run)
        self.change_port(to_port=to_port, verbose=verbose, dry_run=dry_run)

        if wait_time is not None:
            if verbose:
                self.log_debug(
                    "Waiting for `{value!s}` {units!s}.".format(
                        value=volume.value, units=volume.units
                    )
                )

            time.sleep(wait_time.value if wait_time.value >= 0 else 0)

        if verbose:
            self.log_debug(
                "Dispensing `{value!s}` {units!s}.".format(
                    value=volume.value, units=volume.units
                )
            )

        self.move_plunger(verbose=verbose, dry_run=dry_run)
        self.change_port(to_port=from_port, verbose=verbose, dry_run=dry_run)

        return None

    @wait_ready  # pyrefly: ignore[no-matching-overload]
    def perfuse_iteratively(
        self: Self,
        /,
        *,
        dispensing_volume: Volume,
        dead_volume_pump: Volume,
        dead_volume_stock: Volume,
        dispensing_ports: list[Port],
        suction_ports: list[Port],
        flush_volume: Volume = Volume.from_microliters(1000),
        media_port: Port = MEDIA_PORT,
        ethanol_port: Port = ETHANOL_PORT,
        water_port: Port = WATER_PORT,
        dispensing_speed: Speed = Speed.from_code(35),
        interval_time: Time = Time.from_hours(24),
        iteration_number: int = 1000,
        wash_time: Time = Time.from_seconds(600),
        flush_first: bool = True,
        verbose: bool = False,
        dry_run: bool = False,
    ) -> None:
        """Perfuse selected wells iteratively."""

        if interval_time.value <= 0:
            raise ValueError("Interval time cannot be zero or negative.")

        total_volume: Volume
        current_iteration: int = 0

        while current_iteration < iteration_number:
            start_time: float = time.time()

            self.log_info(f"Starting iteration #{current_iteration + 1!s}.")

            if flush_first:
                if current_iteration == 0:
                    self.log_info("First iteration; flushing media.")

                    self.transfer_liquid(
                        volume=dead_volume_stock,
                        from_port=media_port,
                        to_port=Port(self.pump.waste_port),
                        verbose=verbose,
                        dry_run=dry_run,
                    )
                    total_volume = dispensing_volume + dead_volume_pump
                else:
                    total_volume = dispensing_volume
            else:
                total_volume = dispensing_volume

            self.log_info("Dispensing fresh media into wells.")

            for port in dispensing_ports:
                self.log_info(f"Dispensing into port `{port.value!s}`.")

                self.transfer_liquid(
                    volume=total_volume,
                    from_port=media_port,
                    to_port=port,
                    dispensing_speed=dispensing_speed,
                    verbose=verbose,
                    dry_run=dry_run,
                )

            self.log_info("Removing excessive media from wells.")

            for port in suction_ports:
                self.log_info(
                    f"Removing excess media from port `{port.value!s}`."
                )

                self.transfer_liquid(
                    volume=Volume.from_milliliters(2),
                    from_port=port,
                    to_port=WASTE_PORT,
                    loading_speed=dispensing_speed,
                    verbose=verbose,
                    dry_run=dry_run,
                )

            self.log_info("Cleaning pump with ethanol.")

            self.transfer_liquid(
                volume=flush_volume,
                from_port=ethanol_port,
                to_port=WASTE_PORT,
                wait_time=wash_time,
                verbose=verbose,
                dry_run=dry_run,
            )

            self.log_info("Rinsing pump with water.")

            self.transfer_liquid(
                volume=flush_volume,
                from_port=water_port,
                to_port=WASTE_PORT,
                verbose=verbose,
                dry_run=dry_run,
            )

            elapsed_time: float = time.time() - start_time
            wait_time: float = interval_time.value - elapsed_time

            next_time: str = time.strftime(
                "%Y-%m-%d %H:%M:%S",
                time.localtime(
                    time.time() + (interval_time.value - elapsed_time)
                ),
            )

            if wait_time <= 0:
                wait_time = 0
                self.log_warning(
                    "Handling time exceeded iteration time; proceeding to "
                    "next iteration immediately."
                )
            else:
                self.log_info(f"Waiting until: {next_time!s}")

            time.sleep(wait_time)

            current_iteration += 1

    @classmethod
    def from_pump(cls: type[Self], pump: T, /) -> Self:
        """Instantiate from pre-initialized pump."""

        self: Self = cls()

        self.set_pump(pump)

        return self

    @staticmethod
    def from_xcaliburd(
        *,
        com_link: _Serial,
        total_ports: int = len(Port.__members__),
        syringe_volume: Volume = Volume.from_milliliters(1),
        direction: Direction = Direction.CW,
        microstep: bool = False,
        waste_port: Port = WASTE_PORT,
        slope: int = 14,
        init_force: Speed = Speed.from_code(0),
        debug: bool = False,
        debug_log_path: str | Path = ".",
    ) -> Controller[XCaliburD]:
        """Instantiate with pump constructed from spec."""

        pump: XCaliburD = XCaliburD(
            com_link=com_link,
            num_ports=total_ports,
            syringe_ul=syringe_volume.value,
            direction=direction.value,
            microstep=microstep,
            waste_port=waste_port.value,
            slope=slope,
            init_force=init_force.to_code(),
            debug=debug,
            debug_log_path=str(debug_log_path),
        )

        return Controller.from_pump(pump)
