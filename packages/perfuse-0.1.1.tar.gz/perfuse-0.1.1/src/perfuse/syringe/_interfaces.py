"""Module `perfuse.syringe._interfaces`."""

from typing import TYPE_CHECKING, Protocol, final

if TYPE_CHECKING:
    from logging import Logger
    from typing import Any, Literal, Self


@final
class _Serial(Protocol):
    """Minimal serial interface."""

    ser_info: dict[str, Any]

    def __init__(
        self: Self,
        /,
        tecan_addr: int,
        ser_port: str,
        ser_baud: bytes,
        ser_timeout: float = 0.1,
        max_attempts: int = 5,
    ) -> None: ...

    def sendRcv(self: Self, /, cmd: str) -> dict[str, Any]: ...


@final
class _Pump(Protocol):
    """Minimal syringe pump interface compatible with a controller."""

    com_link: Any
    debug: bool
    direction: str
    init_force: int
    logger: Logger
    num_ports: int
    state: dict[str, Any]
    syringe_ul: int
    waste_port: int

    def __init__(
        self: Self,
        /,
        com_link: Any,
        num_ports: int = 9,
        syringe_ul: int = 1000,
        direction: str = "CW",
        microstep: bool = False,
        waste_port: int = 9,
        slope: int = 14,
        init_force: int = 0,
        debug: bool = False,
        debug_log_path: str = ".",
    ) -> None: ...

    def _ulToSteps(
        self: Self, /, volume_ul: int, microstep: bool | None = None
    ) -> float: ...

    def init(
        self: Self,
        /,
        init_force: int | None = None,
        direction: str | None = None,
        in_port: int | None = None,
        out_port: int | None = None,
    ) -> Literal[0]: ...

    def changePort(
        self: Self,
        /,
        to_port: int,
        from_port: int | None = None,
        direction: str = "CW",
    ) -> None: ...

    def getCurPort(self: Self, /) -> int: ...

    def movePlungerAbs(self: Self, /, abs_position: int) -> None: ...

    def setSpeed(self: Self, /, speed_code: int) -> None: ...

    def sendRcv(self: Self, /, cmd_string: str) -> bytes | None: ...

    def waitReady(
        self: Self,
        /,
        timeout: int = 10,
        polling_interval: float = 0.3,
        delay: float | None = None,
    ) -> None: ...
