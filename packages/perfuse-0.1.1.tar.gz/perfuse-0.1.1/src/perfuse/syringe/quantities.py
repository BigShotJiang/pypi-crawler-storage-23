"""Module `perfuse.syringe.quantities`."""

import operator
from abc import ABC, abstractmethod
from decimal import Decimal
from typing import (
    TYPE_CHECKING,
    TypedDict,
    final,
    overload,
    override,
)

from pint import Quantity, UnitRegistry
from pint.facets.plain import PlainQuantity

if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Any, ClassVar, Final, LiteralString, Self

    from pint.facets.plain import PlainUnit


__all__: Final[list[LiteralString]] = [
    "Speed",
    "Time",
    "Volume",
]


UREG: Final[UnitRegistry[PlainUnit]] = UnitRegistry()


type Numeric = int | float | Decimal


@final
class _QuantityKwargs(TypedDict):
    """Minimal keyword arguments to define a quantity."""

    value: Numeric
    units: PlainUnit


class _ConstrainedQuantity(ABC):
    """Base class for quantities constrained to a single unit."""

    UNITS: ClassVar[PlainUnit]

    __match_args__: tuple[LiteralString, ...] = ("value", "units")

    def __init_subclass__(
        cls: type[Self], /, *args: Any, units: PlainUnit, **kwargs: Any
    ) -> None:
        """Store target units in class."""

        super().__init_subclass__(*args, **kwargs)

        cls.UNITS = units

    @overload
    def __init__(self: Self, quantity: PlainQuantity[Any], /) -> None: ...

    @overload
    def __init__(
        self: Self, /, *, value: Numeric, units: PlainUnit | None = None
    ) -> None: ...

    def __init__(self: Self, *args: Any, **kwargs: Any) -> None:
        """Coerce quantity into class units."""

        match args, kwargs:
            case (PlainQuantity(magnitude=value, units=units),), {}:
                quantity = PlainQuantity(value=value, units=units)
            case (), {"value": value, "units": units}:
                quantity = PlainQuantity(
                    value=value,
                    units=self.__class__.UNITS if units is None else units,
                )
            case (), {"value": value}:
                quantity = PlainQuantity(
                    value=value, units=self.__class__.UNITS
                )
            case _:
                raise ValueError(
                    f"Invalid set of arguments: {args!s}; {kwargs!s}."
                )

        self._value: int = self.__class__.convert(quantity).magnitude

        self.validate()

    def __add__(self: Self, other: Self, /) -> Self:
        """Implement addition."""

        return self.__class__._operate(operator.add, self, other)

    def __sub__(self: Self, other: Self, /) -> Self:
        """Implement subtraction."""

        return self.__class__._operate(operator.sub, self, other)

    def __mul__(self: Self, other: Self, /) -> Self:
        """Implement multiplication."""

        return self.__class__._operate(operator.mul, self, other)

    def __floordiv__(self: Self, other: Self, /) -> Self:
        """Implement floor division."""

        return self.__class__._operate(operator.floordiv, self, other)

    @classmethod
    def _operate(
        cls: type[Self],
        op: Callable[[Numeric, Numeric], Numeric],
        first: Self,
        second: Self,
        /,
    ) -> Self:
        """Apply operator."""

        return cls(value=op(first._value, second._value))

    @property
    def value(self: Self, /) -> int:
        """Numeric value."""

        return self._value

    @property
    def units(self: Self, /) -> PlainUnit:
        """Target units."""

        return self.__class__.UNITS

    @classmethod
    def from_quantity(
        cls: type[Self], quantity: PlainQuantity[Any], /
    ) -> Self:
        """Instantiate from quantity."""

        return cls(cls.convert(quantity))

    @classmethod
    def convert(
        cls: type[Self], quantity: PlainQuantity[Any], /
    ) -> PlainQuantity[int]:
        """Coerce quantity to target units."""

        try:
            converted: PlainQuantity[int] = PlainQuantity(
                value=int(quantity.to(cls.UNITS).magnitude), units=cls.UNITS
            )
        except Exception:
            raise ValueError(
                f"Unable to convert quantity with units `{quantity.units!s}` "
                f"to `{cls.UNITS!s}`."
            )

        return converted

    @abstractmethod
    def validate(self: Self, /) -> None: ...


@final
class Speed(_ConstrainedQuantity, units=UREG.hertz):
    """Speed constrained to integer Hertz."""

    SPEED_CODES: ClassVar[dict[int, int]] = {
        0: 6000,
        1: 5600,
        2: 5000,
        3: 4400,
        4: 3800,
        5: 3200,
        6: 2600,
        7: 2200,
        8: 2000,
        9: 1800,
        10: 1600,
        11: 1400,
        12: 1200,
        13: 1000,
        14: 800,
        15: 600,
        16: 400,
        17: 200,
        18: 190,
        19: 180,
        20: 170,
        21: 160,
        22: 150,
        23: 140,
        24: 130,
        25: 120,
        26: 110,
        27: 100,
        28: 90,
        29: 80,
        30: 70,
        31: 60,
        32: 50,
        33: 40,
        34: 30,
        35: 20,
        36: 18,
        37: 16,
        38: 14,
        39: 12,
        40: 10,
    }
    SPEED_HZ: ClassVar[dict[int, int]] = {
        value: key for key, value in SPEED_CODES.items()
    }

    @override
    def validate(self: Self, /) -> None:
        """Ensure that speed has a corresponding code."""

        if self.value not in self.__class__.SPEED_CODES.values():
            raise ValueError(
                f"Invalid speed `{self.value!s}` {self.__class__.UNITS!s}; no "
                "corresponding speed code found."
            )

    def to_code(self: Self, /) -> int:
        """Return matching speed code."""

        return self.__class__.SPEED_HZ[self.value]

    @classmethod
    def from_hertz(cls: type[Self], hertz: int, /) -> Self:
        """Intantiate from Hertz."""

        return cls(PlainQuantity(value=hertz, units=UREG.hertz))

    @classmethod
    def from_code(cls: type[Self], speed_code: int, /) -> Self:
        """Instantiate from valid speed code."""

        if (hertz := cls.SPEED_CODES.get(speed_code, None)) is None:
            raise ValueError(
                "Invalid speed code `{speed_code!s}`; must be integer in the "
                "({min_value!s}, {max_value!s}) range.".format(
                    speed_code=speed_code,
                    min_value=min(cls.SPEED_CODES),
                    max_value=max(cls.SPEED_CODES),
                )
            )

        return cls.from_hertz(hertz)


@final
class Time(_ConstrainedQuantity, units=UREG.s):
    """Time constrained to integer number of seconds."""

    MAX: ClassVar[int] = 10 * 24 * 60 * 60
    MIN: ClassVar[int] = 0

    @override
    def validate(self: Self, /) -> None:
        """Ensure that time is within range."""

        max_value: int = self.__class__.MAX
        min_value: int = self.__class__.MIN

        if self.value > max_value or self.value < min_value:
            raise ValueError(
                "Invalid time of `{value!s}` {units!s}; must be integer "
                "between `{min_value!s}` and `{max_value!s}`.".format(
                    value=self.value,
                    units=self.__class__.UNITS,
                    min_value=self.__class__.MIN,
                    max_value=self.__class__.MAX,
                )
            )

    @classmethod
    def from_seconds(cls: type[Self], seconds: int, /) -> Self:
        """Instantiate from integer number of seconds."""

        return cls(value=seconds)

    @classmethod
    def from_minutes(cls: type[Self], minutes: Numeric, /) -> Self:
        """Coerce any number of minutes into seconds."""

        seconds: PlainQuantity[int] = cls.convert(
            PlainQuantity(value=minutes, units=UREG.min)
        )

        return cls.from_seconds(seconds.magnitude)

    @classmethod
    def from_hours(cls: type[Self], hours: Numeric, /) -> Self:
        """Coerce any number of hours into seconds."""

        seconds: PlainQuantity[int] = cls.convert(
            Quantity(value=hours, units=UREG.h)
        )

        return cls.from_seconds(seconds.magnitude)


@final
class Volume(_ConstrainedQuantity, units=UREG.ul):
    """Volume constrained to microliters."""

    MAX: ClassVar[int] = 5000
    MIN: ClassVar[int] = 0

    @override
    def validate(self: Self, /) -> None:
        """Ensure that volume is within range."""

        max_value: int = self.__class__.MAX
        min_value: int = self.__class__.MIN

        if self.value > max_value or self.value < min_value:
            raise ValueError(
                "Invalid time of `{value!s}` {units!s}; must be integer "
                "between `{min_value!s}` and `{max_value!s}`.".format(
                    value=self.value,
                    units=self.__class__.UNITS,
                    min_value=self.__class__.MIN,
                    max_value=self.__class__.MAX,
                )
            )

    @classmethod
    def from_microliters(cls: type[Self], microliters: int, /) -> Self:
        """Instantiate from integer number of microliters."""

        return cls(value=microliters)

    @classmethod
    def from_milliliters(cls: type[Self], mililiters: Numeric, /) -> Self:
        """Coerce from any number of milliliters."""

        microliters: PlainQuantity[int] = cls.convert(
            PlainQuantity(value=mililiters, units=UREG.ml)
        )

        return cls.from_microliters(microliters.magnitude)
