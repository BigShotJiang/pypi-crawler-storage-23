"""Module `perfuse.workflow.workflow`."""

from typing import TYPE_CHECKING

from perfuse.syringe.constants import (
    DEAD_VOLUME_PUMP,
    DEAD_VOLUME_STOCK,
    MEDIA_PORT,
    WASTE_PORT,
)
from perfuse.syringe.quantities import Speed, Time, Volume
from perfuse.syringe.valve import Port
from perfuse.workflow.startup import (
    intercept_interrupt,
    prepare_logger,
    start_controller,
)

if TYPE_CHECKING:
    from typing import Final, LiteralString

    from tecancavro.models import XCaliburD

    from perfuse.syringe.controller import Controller


__all__: Final[list[LiteralString]] = [
    "clean_system",
    "start_timelapse",
]


@start_controller
@prepare_logger
@intercept_interrupt
def clean_system(
    controller: Controller[XCaliburD],
    /,
    *,
    dispensing_ports: list[Port],
    suction_ports: list[Port],
    flush_volume: Volume = Volume.from_milliliters(2),
    flush_rounds: int = 5,
    verbose: bool = False,
    dry_run: bool = False,
) -> None:
    """Start a system cleanup."""

    controller.log_info("Priming pump for washes.")

    controller.transfer_liquid(
        volume=DEAD_VOLUME_STOCK,
        from_port=MEDIA_PORT,
        to_port=WASTE_PORT,
        dispensing_speed=Speed(value=10),
        verbose=verbose,
        dry_run=dry_run,
    )

    for round in range(flush_rounds):
        controller.log_info(f"Starting wash round #{round + 1!s}.")

        for port in dispensing_ports:
            controller.transfer_liquid(
                volume=flush_volume,
                from_port=MEDIA_PORT,
                to_port=port,
                dispensing_speed=Speed(value=20),
                wait_time=Time.from_minutes(1),
                verbose=verbose,
                dry_run=dry_run,
            )

        for port in suction_ports:
            controller.transfer_liquid(
                volume=flush_volume,
                from_port=port,
                to_port=WASTE_PORT,
                loading_speed=Speed(value=20),
                verbose=verbose,
                dry_run=dry_run,
            )

    controller.log_info("System wash complete.")


@start_controller
@prepare_logger
@intercept_interrupt
def start_timelapse(
    controller: Controller[XCaliburD],
    /,
    *,
    dispensing_ports: list[Port],
    suction_ports: list[Port],
    dispensing_volume: Volume = Volume.from_microliters(100),
    dead_volume_pump: Volume = DEAD_VOLUME_PUMP,
    flush_volume: Volume = Volume.from_milliliters(1),
    flush_first: bool = True,
    interval_time: Time = Time.from_hours(4),
    iteration_number: int = 1000,
    wash_time: Time = Time.from_seconds(600),
    verbose: bool = False,
    dry_run: bool = False,
) -> None:
    """Start a timelapse workflow."""

    controller.log_info("Starting timelapse.")

    controller.perfuse_iteratively(
        dispensing_ports=dispensing_ports,
        suction_ports=suction_ports,
        dispensing_volume=dispensing_volume,
        dead_volume_pump=dead_volume_pump,
        dead_volume_stock=DEAD_VOLUME_STOCK,
        flush_volume=flush_volume,
        flush_first=flush_first,
        interval_time=interval_time,
        iteration_number=iteration_number,
        wash_time=wash_time,
        verbose=verbose,
        dry_run=dry_run,
    )

    controller.log_info("Timelapse ended.")
