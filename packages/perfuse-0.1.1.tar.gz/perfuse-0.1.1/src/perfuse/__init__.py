"""Module `perfuse`."""

from typing import TYPE_CHECKING

from perfuse._utils import _get_version
from perfuse.cli import Cli

if TYPE_CHECKING:
    from typing import Final


VERSION: Final[str] = _get_version()


def main() -> None:
    """Script entry point."""

    return Cli().execute()  # pyrefly: ignore[missing-attribute]
