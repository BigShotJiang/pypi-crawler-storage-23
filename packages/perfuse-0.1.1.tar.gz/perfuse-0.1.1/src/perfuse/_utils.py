"""Private utility functions."""

import tomllib
from pathlib import Path
from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from datetime import date, datetime, time


# Type aliases for valid TOML data:
type TomlValue = (
    None
    | bool
    | int
    | float
    | str
    | date
    | datetime
    | time
    | list[TomlValue]
    | dict[str, TomlValue]
)
type TomlDict = dict[str, TomlValue]


def _get_pyproject() -> TomlDict:
    """Load data from `pyproject.toml`."""

    path: Path = Path(__file__).parent.parent.parent.joinpath("pyproject.toml")

    return tomllib.loads(path.read_text())


def _get_pyproject_field(key_path: str, /) -> TomlValue:
    """Find field in `pyproject.toml` for a given key-path."""

    toml_data: TomlValue | TomlDict = _get_pyproject()

    for key in key_path.split("."):
        if not isinstance(toml_data, dict):
            raise TypeError(type(toml_data))

        toml_data = toml_data[key]

    return cast(TomlValue, toml_data)


def _get_version() -> str:
    """Retrieve program's version."""

    return cast(str, _get_pyproject_field("project.version"))
