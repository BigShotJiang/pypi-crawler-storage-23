from pathlib import Path

# Make the package dir available in the module
PACKAGE_DIR  = Path(__file__).parent
PACKAGE_NAME = PACKAGE_DIR.name
CONFIG_DIR   = PACKAGE_DIR / 'configs'
TEMPLATE_DIR = PACKAGE_DIR / 'templates'
SCRIPTS_DIR  = PACKAGE_DIR / 'css_and_scripts'

from .report import Report as Report #noqa: E402
