"""LLM integration layer."""

from acorn.llm.litellm_client import call_llm

__all__ = ["call_llm"]
