"""Tests for KafkaSpanExporter (OTEL native span exporter to Kafka)."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from autonomize_observer.core.config import KafkaConfig
from autonomize_observer.core.phi_config import PHIDetectionConfig
from autonomize_observer.exporters.otel.kafka_span_exporter import KafkaSpanExporter
from autonomize_observer.schemas.genai_conventions import GenAIAttributes


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_span_context(trace_id: int = 0x1234, span_id: int = 0x5678):
    """Create a mock span context."""
    ctx = MagicMock()
    ctx.trace_id = trace_id
    ctx.span_id = span_id
    return ctx


def _make_span(
    name: str = "test-span",
    attributes: dict | None = None,
    trace_id: int = 0x1234,
    span_id: int = 0x5678,
    parent: MagicMock | None = None,
    status_code_value: int = 0,
    status_description: str | None = None,
    start_time: int = 1_000_000_000,
    end_time: int = 2_000_000_000,
    resource_attrs: dict | None = None,
) -> MagicMock:
    """Create a minimal mock ReadableSpan."""
    span = MagicMock()
    span.name = name
    span.attributes = attributes or {}
    span.get_span_context.return_value = _make_span_context(trace_id, span_id)
    span.parent = parent
    span.start_time = start_time
    span.end_time = end_time

    # Status
    span.status.status_code.value = status_code_value
    span.status.description = status_description

    # Resource
    if resource_attrs:
        span.resource.attributes.get = lambda k, default=None: resource_attrs.get(
            k, default
        )
    else:
        span.resource = None

    return span


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def kafka_config():
    """Minimal KafkaConfig for tests."""
    return KafkaConfig(
        bootstrap_servers="localhost:9092",
        client_id="test",
        trace_topic="test-traces",
        restricted_topic="test-restricted",
    )


@pytest.fixture
def mock_producer():
    """Mock the confluent-kafka Producer."""
    with patch(
        "autonomize_observer.exporters.otel.kafka_span_exporter.ConfluentProducer"
    ) as mock_cls:
        producer = MagicMock()
        producer.produce = MagicMock()
        producer.poll = MagicMock(return_value=0)
        producer.flush = MagicMock(return_value=0)
        mock_cls.return_value = producer
        yield producer


# ---------------------------------------------------------------------------
# Init / Config
# ---------------------------------------------------------------------------


class TestKafkaSpanExporterInit:
    """Tests for KafkaSpanExporter constructor and config building."""

    def test_init_defaults(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        assert exporter._topic == "test-traces"
        assert exporter._restricted_topic == "test-restricted"
        assert exporter._usecase_id == "GenericApp"
        assert exporter._transform_to_genai is True
        assert exporter._low_latency is True
        assert exporter._spans_exported == 0
        assert exporter._spans_failed == 0

    def test_init_custom_topic(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config, topic="custom-topic")
        assert exporter._topic == "custom-topic"

    def test_init_custom_usecase(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config, usecase_id="MyApp")
        assert exporter._usecase_id == "MyApp"

    def test_init_no_transform(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(
            kafka_config=kafka_config, transform_to_genai=False
        )
        assert exporter._transform_to_genai is False

    def test_init_custom_phi_config(self, kafka_config, mock_producer):
        phi_cfg = PHIDetectionConfig(patterns=["custom_phi"])
        exporter = KafkaSpanExporter(kafka_config=kafka_config, phi_config=phi_cfg)
        assert exporter._phi_config is phi_cfg

    def test_build_producer_config_low_latency(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config, low_latency=True)
        cfg = exporter._build_producer_config()
        assert cfg["linger.ms"] == 0
        assert cfg["batch.size"] == 1
        assert cfg["request.required.acks"] == 0

    def test_build_producer_config_normal(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config, low_latency=False)
        cfg = exporter._build_producer_config()
        assert cfg["linger.ms"] == kafka_config.linger_ms
        assert cfg["request.required.acks"] == 1  # acks="all"

    def test_build_producer_config_security(self, mock_producer):
        config = KafkaConfig(
            security_protocol="SASL_SSL",
            sasl_mechanism="PLAIN",
            sasl_username="user",
            sasl_password="pass",
        )
        exporter = KafkaSpanExporter(kafka_config=config)
        cfg = exporter._build_producer_config()
        assert cfg["security.protocol"] == "SASL_SSL"
        assert cfg["sasl.mechanism"] == "PLAIN"
        assert cfg["sasl.username"] == "user"
        assert cfg["sasl.password"] == "pass"
        assert cfg["enable.ssl.certificate.verification"] is True

    def test_get_producer_lazy(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        assert exporter._producer is None
        producer = exporter._get_producer()
        assert producer is mock_producer


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------


class TestKafkaSpanExporterExport:
    """Tests for the export() method."""

    def test_export_empty_span_list(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        from opentelemetry.sdk.trace.export import SpanExportResult

        assert exporter.export([]) == SpanExportResult.SUCCESS

    def test_export_single_span(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span("basic-op")
        from opentelemetry.sdk.trace.export import SpanExportResult

        result = exporter.export([span])
        assert result == SpanExportResult.SUCCESS
        assert exporter._spans_exported == 1
        mock_producer.produce.assert_called_once()
        mock_producer.poll.assert_called_once_with(0)

    def test_export_multiple_spans(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        spans = [_make_span(f"span-{i}") for i in range(5)]
        from opentelemetry.sdk.trace.export import SpanExportResult

        result = exporter.export(spans)
        assert result == SpanExportResult.SUCCESS
        assert exporter._spans_exported == 5
        assert mock_producer.produce.call_count == 5

    def test_export_producer_creation_failure(self, kafka_config):
        """If producer can't be created, export returns FAILURE."""
        with patch(
            "autonomize_observer.exporters.otel.kafka_span_exporter.ConfluentProducer",
            side_effect=Exception("Connection refused"),
        ):
            exporter = KafkaSpanExporter(kafka_config=kafka_config)
            from opentelemetry.sdk.trace.export import SpanExportResult

            result = exporter.export([_make_span()])
            assert result == SpanExportResult.FAILURE
            assert exporter._spans_failed == 1

    def test_export_produce_failure_per_span(self, kafka_config, mock_producer):
        """If produce() fails for one span, that span is counted as failed."""
        mock_producer.produce.side_effect = Exception("Buffer full")
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        from opentelemetry.sdk.trace.export import SpanExportResult

        result = exporter.export([_make_span()])
        # Still returns SUCCESS because the outer try succeeded
        assert result == SpanExportResult.SUCCESS
        assert exporter._spans_failed == 1

    def test_export_routes_to_correct_topic(self, kafka_config, mock_producer):
        """Non-PHI spans go to the normal topic."""
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        exporter.export([_make_span("normal-operation")])

        call_kwargs = mock_producer.produce.call_args
        assert call_kwargs[1]["topic"] == "test-traces"

    def test_export_routes_phi_to_restricted_topic(self, kafka_config, mock_producer):
        """PHI spans go to the restricted topic."""
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span("patient-data", attributes={"contains_phi": True})
        exporter.export([span])

        call_kwargs = mock_producer.produce.call_args
        assert call_kwargs[1]["topic"] == "test-restricted"

    def test_export_phi_span_no_restricted_topic(self, mock_producer):
        """PHI span with no restricted topic stays on regular topic (with warning)."""
        config = KafkaConfig(trace_topic="my-topic", restricted_topic=None)
        exporter = KafkaSpanExporter(kafka_config=config)
        span = _make_span("patient-data", attributes={"contains_phi": True})
        exporter.export([span])

        call_kwargs = mock_producer.produce.call_args
        assert call_kwargs[1]["topic"] == "my-topic"


# ---------------------------------------------------------------------------
# PHI Detection
# ---------------------------------------------------------------------------


class TestKafkaSpanExporterPHI:
    """Tests for PHI detection logic."""

    def test_phi_flag_in_attributes(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span(attributes={"contains_phi": True})
        assert exporter._is_phi_span(span) is True

    def test_phi_detected_in_span_name(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span("process patient record")
        assert exporter._is_phi_span(span) is True

    def test_non_phi_span(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span("compute_sum")
        assert exporter._is_phi_span(span) is False

    def test_phi_word_boundary_false_positive(self, kafka_config, mock_producer):
        """'member' is not in defaults, so 'team_member_count' should NOT match."""
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span("team_member_count")
        assert exporter._is_phi_span(span) is False


# ---------------------------------------------------------------------------
# Span Transformation
# ---------------------------------------------------------------------------


class TestKafkaSpanExporterTransform:
    """Tests for span-to-event transformation."""

    def test_span_to_event_basic(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span(
            name="chat gpt-4o",
            trace_id=0xABCD,
            span_id=0x1234,
            resource_attrs={
                "autonomize.organization_id": "org-1",
                "autonomize.project_id": "proj-1",
            },
        )
        event = exporter._span_to_event(span)

        assert event["name"] == "chat gpt-4o"
        assert event["usecase_id"] == "GenericApp"
        assert event["organization_id"] == "org-1"
        assert event["project_id"] == "proj-1"
        assert event["context"]["trace_id"] == format(0xABCD, "032x")
        assert event["context"]["span_id"] == format(0x1234, "016x")
        assert event["parent_id"] is None
        assert event["application_type"] == "gen_ai"

    def test_span_to_event_with_parent(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        parent = MagicMock()
        parent.span_id = 0x9999
        span = _make_span(parent=parent)
        event = exporter._span_to_event(span)
        assert event["parent_id"] == format(0x9999, "016x")

    def test_extract_attributes_genai_transform(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config, transform_to_genai=True)
        span = _make_span(
            name="chat",
            attributes={
                "gen_ai.request.model": "gpt-4o",
                "gen_ai.operation.name": "chat",
                "model": "gpt-4o",
            },
        )
        attrs = exporter._extract_attributes(span)
        assert GenAIAttributes.OPERATION_NAME in attrs
        assert attrs[GenAIAttributes.OPERATION_NAME] == "chat"

    def test_extract_attributes_no_transform(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(
            kafka_config=kafka_config, transform_to_genai=False
        )
        span = _make_span(attributes={"custom_key": "value"})
        attrs = exporter._extract_attributes(span)
        assert attrs == {"custom_key": "value"}

    def test_map_legacy_attributes(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        assert exporter._map_attribute_key("model") == GenAIAttributes.REQUEST_MODEL
        assert exporter._map_attribute_key("provider") == GenAIAttributes.PROVIDER_NAME
        assert exporter._map_attribute_key("unknown") is None

    def test_infer_operation(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        assert exporter._infer_operation(_make_span("chat gpt-4o")) == "chat"
        assert (
            exporter._infer_operation(_make_span("text_completion"))
            == "text_completion"
        )
        assert exporter._infer_operation(_make_span("embeddings-v2")) == "embeddings"
        assert (
            exporter._infer_operation(_make_span("execute_tool search"))
            == "execute_tool"
        )
        assert (
            exporter._infer_operation(_make_span("invoke_agent Bot")) == "invoke_agent"
        )
        assert exporter._infer_operation(_make_span("unknown-span")) == "chat"

    def test_format_time(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        assert exporter._format_time(None) is None
        # 1 second in nanoseconds
        result = exporter._format_time(1_000_000_000)
        assert "1970-01-01" in result

    def test_get_partition_key(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span(trace_id=0xFF)
        key = exporter._get_partition_key(span)
        assert key == format(0xFF, "032x")


# ---------------------------------------------------------------------------
# Shutdown / Flush / Stats
# ---------------------------------------------------------------------------


class TestKafkaSpanExporterLifecycle:
    """Tests for shutdown, flush, stats, delivery callback."""

    def test_shutdown_with_producer(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        exporter._get_producer()  # initialize producer
        exporter.shutdown()
        mock_producer.flush.assert_called_once()

    def test_shutdown_no_producer(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        exporter.shutdown()  # Should not raise

    def test_force_flush_success(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        exporter._get_producer()
        mock_producer.flush.return_value = 0
        assert exporter.force_flush(timeout_millis=5000) is True

    def test_force_flush_remaining(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        exporter._get_producer()
        mock_producer.flush.return_value = 3
        assert exporter.force_flush() is False

    def test_force_flush_no_producer(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        assert exporter.force_flush() is True

    def test_stats(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        exporter._spans_exported = 10
        exporter._spans_failed = 2
        stats = exporter.stats
        assert stats["spans_exported"] == 10
        assert stats["spans_failed"] == 2

    def test_delivery_callback_success(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        exporter._delivery_callback(None, MagicMock())
        assert exporter._spans_failed == 0

    def test_delivery_callback_error(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        exporter._delivery_callback("delivery error", MagicMock())
        assert exporter._spans_failed == 1

    def test_extract_resource_attribute_present(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span(resource_attrs={"autonomize.organization_id": "org-1"})
        assert (
            exporter._extract_resource_attribute(span, "autonomize.organization_id")
            == "org-1"
        )

    def test_extract_resource_attribute_missing(self, kafka_config, mock_producer):
        exporter = KafkaSpanExporter(kafka_config=kafka_config)
        span = _make_span()  # resource is None
        assert exporter._extract_resource_attribute(span, "missing_key") is None
