from __future__ import annotations

import importlib
import sys
import types
from contextlib import contextmanager
from unittest.mock import MagicMock, patch

import pytest

from autonomize_observer.core.native_otel_config import NativeOTELConfig
from autonomize_observer.core.otlp_config import OTLPConfig
from autonomize_observer.schemas.genai_conventions import (
    GenAIAttributes,
    GenAIOperations,
    build_genai_span_name,
    create_agent_attributes,
    create_genai_attributes,
    create_tool_attributes,
)
from autonomize_observer.tracing.native_otel_manager import NativeOTELManager


def test_init_requires_native_otel():
    config = NativeOTELConfig(enabled=True)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", False
    ):
        with pytest.raises(ImportError):
            NativeOTELManager(config=config)


def test_configure_uses_batch_processor():
    config = NativeOTELConfig(
        enabled=True,
        enable_console=True,
        register_lifecycle_hooks=False,
        batch_export=True,
        set_global_provider=True,
    )
    provider = MagicMock()
    provider.get_tracer.return_value = MagicMock()
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.OTelResource"
    ) as mock_resource, patch(
        "autonomize_observer.tracing.native_otel_manager.TracerProvider"
    ) as mock_provider_cls, patch(
        "autonomize_observer.tracing.native_otel_manager.BatchSpanProcessor"
    ) as mock_batch, patch(
        "autonomize_observer.tracing.native_otel_manager.SimpleSpanProcessor"
    ) as mock_simple, patch(
        "autonomize_observer.tracing.native_otel_manager.otel_trace"
    ) as mock_otel_trace, patch.object(
        NativeOTELManager, "_create_console_exporter", return_value=MagicMock()
    ):
        mock_resource.create.return_value = MagicMock()
        mock_provider_cls.return_value = provider
        manager = NativeOTELManager(config=config)
        assert manager.is_available is True
        mock_batch.assert_called()
        mock_simple.assert_not_called()
        mock_otel_trace.set_tracer_provider.assert_called_with(provider)


def test_configure_is_idempotent():
    config = NativeOTELConfig(
        enabled=True,
        enable_console=True,
        register_lifecycle_hooks=False,
        batch_export=True,
        set_global_provider=False,
    )
    provider = MagicMock()
    provider.get_tracer.return_value = MagicMock()
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.OTelResource"
    ) as mock_resource, patch(
        "autonomize_observer.tracing.native_otel_manager.TracerProvider"
    ) as mock_provider_cls, patch(
        "autonomize_observer.tracing.native_otel_manager.BatchSpanProcessor"
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.SimpleSpanProcessor"
    ), patch.object(
        NativeOTELManager, "_create_console_exporter", return_value=MagicMock()
    ):
        mock_resource.create.return_value = MagicMock()
        mock_provider_cls.return_value = provider
        manager = NativeOTELManager(config=config)
        assert manager.is_available is True

        with patch.object(manager, "_setup_exporters") as mock_setup, patch.object(
            manager, "_register_lifecycle_hooks"
        ) as mock_hooks:
            manager._configure()
            mock_setup.assert_not_called()
            mock_hooks.assert_not_called()


def test_configure_uses_simple_processor():
    config = NativeOTELConfig(
        enabled=True,
        enable_console=True,
        register_lifecycle_hooks=False,
        batch_export=False,
    )
    provider = MagicMock()
    provider.get_tracer.return_value = MagicMock()
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.OTelResource"
    ) as mock_resource, patch(
        "autonomize_observer.tracing.native_otel_manager.TracerProvider"
    ) as mock_provider_cls, patch(
        "autonomize_observer.tracing.native_otel_manager.BatchSpanProcessor"
    ) as mock_batch, patch(
        "autonomize_observer.tracing.native_otel_manager.SimpleSpanProcessor"
    ) as mock_simple, patch.object(
        NativeOTELManager, "_create_console_exporter", return_value=MagicMock()
    ):
        mock_resource.create.return_value = MagicMock()
        mock_provider_cls.return_value = provider
        NativeOTELManager(config=config)
        mock_simple.assert_called()
        mock_batch.assert_not_called()


def test_span_returns_noop_when_unavailable():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        with manager.span("noop") as span:
            span.set_attribute("a", 1)
            span.end()


def test_start_span_returns_noop_when_unavailable():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        span = manager.start_span("noop")
        span.set_attribute("a", 1)
        span.end()


def test_end_span_with_error():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.Status"
    ) as mock_status, patch(
        "autonomize_observer.tracing.native_otel_manager.StatusCode"
    ) as mock_status_code:
        mock_status_code.ERROR = "error"
        manager = NativeOTELManager(config=config)
        span = MagicMock()
        manager.end_span(span, error=RuntimeError("boom"))
        mock_status.assert_called_with("error", "boom")
        span.record_exception.assert_called_once()
        span.end.assert_called_once()


def test_end_span_without_error():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.Status"
    ) as mock_status, patch(
        "autonomize_observer.tracing.native_otel_manager.StatusCode"
    ) as mock_status_code:
        mock_status_code.OK = "ok"
        manager = NativeOTELManager(config=config)
        span = MagicMock()
        manager.end_span(span)
        mock_status.assert_called_with("ok")
        span.end.assert_called_once()


def test_llm_span_calls_span():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.SpanKind"
    ) as mock_span_kind:
        mock_span_kind.CLIENT = "client"
        manager = NativeOTELManager(config=config)
        yielded_span = MagicMock()

        def span_cm(*args, **kwargs):
            @contextmanager
            def _cm():
                yield yielded_span

            return _cm()

        manager.span = MagicMock(side_effect=span_cm)
        with manager.llm_span(provider="openai", model="gpt-4o", input_tokens=1):
            pass
        call = manager.span.call_args
        assert call.args[0] == "chat gpt-4o"
        assert call.kwargs["kind"] == "client"
        attrs = call.kwargs["attributes"]
        assert attrs[GenAIAttributes.REQUEST_MODEL] == "gpt-4o"


def test_tool_span_calls_span():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.SpanKind"
    ) as mock_span_kind:
        mock_span_kind.INTERNAL = "internal"
        manager = NativeOTELManager(config=config)
        yielded_span = MagicMock()

        def span_cm(*args, **kwargs):
            @contextmanager
            def _cm():
                yield yielded_span

            return _cm()

        manager.span = MagicMock(side_effect=span_cm)
        with manager.tool_span("search", arguments={"q": "a"}):
            pass
        call = manager.span.call_args
        assert call.args[0] == "execute_tool search"
        assert call.kwargs["kind"] == "internal"
        attrs = call.kwargs["attributes"]
        assert attrs[GenAIAttributes.TOOL_NAME] == "search"


def test_agent_span_calls_span():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.SpanKind"
    ) as mock_span_kind:
        mock_span_kind.INTERNAL = "internal"
        manager = NativeOTELManager(config=config)
        yielded_span = MagicMock()

        def span_cm(*args, **kwargs):
            @contextmanager
            def _cm():
                yield yielded_span

            return _cm()

        manager.span = MagicMock(side_effect=span_cm)
        with manager.agent_span("Agent", model="gpt-4o", provider="openai"):
            pass
        call = manager.span.call_args
        assert call.args[0] == "invoke_agent Agent"
        assert call.kwargs["kind"] == "internal"
        attrs = call.kwargs["attributes"]
        assert attrs[GenAIAttributes.AGENT_NAME] == "Agent"


def test_force_flush_and_shutdown():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        provider = MagicMock()
        provider.force_flush.return_value = True
        manager._provider = provider
        assert manager.force_flush() is True
        manager.shutdown()
        provider.shutdown.assert_called_once()


def test_register_lifecycle_hooks_handles_signal_error():
    config = NativeOTELConfig(enabled=False, register_lifecycle_hooks=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch("atexit.register") as mock_register, patch(
        "signal.signal", side_effect=ValueError("no")
    ):
        manager = NativeOTELManager(config=config)
        manager._register_lifecycle_hooks()
        mock_register.assert_called_once()


def test_setup_exporters_adds_enabled_exporters():
    config = NativeOTELConfig(
        enabled=False,
        enable_kafka=True,
        enable_eventhub=True,
        enable_otlp_grpc=True,
        enable_otlp_http=True,
        enable_console=True,
    )
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        kafka_exporter = object()
        eventhub_exporter = object()
        grpc_exporter = object()
        http_exporter = object()
        console_exporter = object()

        with patch.object(
            manager, "_create_kafka_exporter", return_value=kafka_exporter
        ), patch.object(
            manager, "_create_event_hub_exporter", return_value=eventhub_exporter
        ), patch.object(
            manager, "_create_otlp_exporter", side_effect=[grpc_exporter, http_exporter]
        ), patch.object(
            manager, "_create_console_exporter", return_value=console_exporter
        ):
            manager._setup_exporters()

        assert manager._exporters == [
            kafka_exporter,
            eventhub_exporter,
            grpc_exporter,
            http_exporter,
            console_exporter,
        ]


def test_create_otlp_exporter_grpc_success():
    config = NativeOTELConfig(
        enabled=False,
        otlp_config=OTLPConfig(endpoint="http://localhost:4317"),
    )
    module = types.SimpleNamespace(OTLPSpanExporter=MagicMock(return_value="exporter"))
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch.dict(
        "sys.modules",
        {"opentelemetry.exporter.otlp.proto.grpc.trace_exporter": module},
    ):
        manager = NativeOTELManager(config=config)
        exporter = manager._create_otlp_exporter("grpc")
        assert exporter == "exporter"


def test_create_otlp_exporter_http_success():
    config = NativeOTELConfig(
        enabled=False,
        otlp_config=OTLPConfig(endpoint="http://localhost:4317"),
    )
    module = types.SimpleNamespace(OTLPSpanExporter=MagicMock(return_value="http"))
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch.dict(
        "sys.modules",
        {"opentelemetry.exporter.otlp.proto.http.trace_exporter": module},
    ):
        manager = NativeOTELManager(config=config)
        exporter = manager._create_otlp_exporter("http")
        assert exporter == "http"


def test_create_otlp_exporter_import_error():
    config = NativeOTELConfig(
        enabled=False,
        otlp_config=OTLPConfig(endpoint="http://localhost:4317"),
    )
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        exporter = manager._create_otlp_exporter("grpc")
        assert exporter is None


def test_create_otlp_exporter_missing_config_returns_none():
    config = NativeOTELConfig(enabled=False, otlp_config=None)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        exporter = manager._create_otlp_exporter("grpc")
        assert exporter is None


def test_create_otlp_exporter_handles_generic_exception():
    config = NativeOTELConfig(
        enabled=False,
        otlp_config=OTLPConfig(endpoint="http://localhost:4317"),
    )
    module = types.SimpleNamespace(
        OTLPSpanExporter=MagicMock(side_effect=RuntimeError("boom"))
    )
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch.dict(
        "sys.modules",
        {"opentelemetry.exporter.otlp.proto.grpc.trace_exporter": module},
    ):
        manager = NativeOTELManager(config=config)
        exporter = manager._create_otlp_exporter("grpc")
        assert exporter is None


def test_create_event_hub_exporter_missing_sdk():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.AZURE_EVENTHUB_AVAILABLE",
        False,
    ):
        manager = NativeOTELManager(config=config)
        assert manager._create_event_hub_exporter() is None


def test_create_event_hub_exporter_missing_config():
    config = NativeOTELConfig(enabled=False, event_hub_config=None)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        assert manager._create_event_hub_exporter() is None


def test_create_event_hub_exporter_success():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.AZURE_EVENTHUB_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.EventHubSpanExporter",
        return_value="eventhub",
        create=True,
    ):
        manager = NativeOTELManager(config=config)
        assert manager._create_event_hub_exporter() == "eventhub"


def test_create_console_exporter_success():
    config = NativeOTELConfig(enabled=False)
    module = types.SimpleNamespace(ConsoleSpanExporter=MagicMock(return_value="console"))
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch.dict(
        "sys.modules",
        {"opentelemetry.sdk.trace.export": module},
    ):
        manager = NativeOTELManager(config=config)
        exporter = manager._create_console_exporter()
        assert exporter == "console"


def test_exporters_init_without_native(monkeypatch):
    """Test exporters package when native OTEL is unavailable."""
    monkeypatch.setattr(
        "autonomize_observer.core.imports.NATIVE_OTEL_AVAILABLE", False, raising=False
    )
    sys.modules.pop("autonomize_observer.exporters.otel", None)

    module = importlib.import_module("autonomize_observer.exporters.otel")

    assert module.__all__ == []


def test_exporters_init_with_eventhub(monkeypatch):
    """Test exporters package exposes EventHubSpanExporter when Azure is available."""
    monkeypatch.setattr(
        "autonomize_observer.core.imports.NATIVE_OTEL_AVAILABLE", True, raising=False
    )
    monkeypatch.setattr(
        "autonomize_observer.core.imports.AZURE_EVENTHUB_AVAILABLE", True, raising=False
    )
    sys.modules.pop("autonomize_observer.exporters.otel", None)

    module = importlib.import_module("autonomize_observer.exporters.otel")

    assert "KafkaSpanExporter" in module.__all__
    assert "CompositeSpanExporter" in module.__all__
    assert "EventHubSpanExporter" in module.__all__


def test_exporters_top_init_without_native(monkeypatch):
    """Test top-level exporters package when native OTEL is unavailable."""
    monkeypatch.setattr(
        "autonomize_observer.core.imports.NATIVE_OTEL_AVAILABLE", False, raising=False
    )
    sys.modules.pop("autonomize_observer.exporters", None)

    module = importlib.import_module("autonomize_observer.exporters")

    assert "BaseExporter" in module.__all__
    assert "ExportResult" in module.__all__
    assert "KafkaExporter" in module.__all__
    assert "BaseKafkaProducer" in module.__all__
    assert "KafkaSpanExporter" not in module.__all__
    assert "CompositeSpanExporter" not in module.__all__
    assert "EventHubSpanExporter" not in module.__all__


def test_exporters_top_init_with_eventhub(monkeypatch):
    """Test top-level exporters package exposes native exporters when available."""
    monkeypatch.setattr(
        "autonomize_observer.core.imports.NATIVE_OTEL_AVAILABLE", True, raising=False
    )
    monkeypatch.setattr(
        "autonomize_observer.core.imports.AZURE_EVENTHUB_AVAILABLE", True, raising=False
    )
    sys.modules.pop("autonomize_observer.exporters", None)
    sys.modules.pop("autonomize_observer.exporters.otel", None)

    module = importlib.import_module("autonomize_observer.exporters")

    assert "KafkaSpanExporter" in module.__all__
    assert "CompositeSpanExporter" in module.__all__
    assert "EventHubSpanExporter" in module.__all__


class TestGenAISemanticHelpers:
    """Tests for GenAI semantic convention helpers."""

    def test_build_genai_span_name(self):
        """Test span name building."""
        assert build_genai_span_name("chat", "gpt-4o") == "chat gpt-4o"
        assert build_genai_span_name("embeddings", None, "openai") == "openai.embeddings"
        assert build_genai_span_name("chat") == "chat"

    def test_create_genai_attributes_basic(self):
        """Test creating basic GenAI attributes."""
        attrs = create_genai_attributes(
            operation="chat",
            provider="openai",
            model="gpt-4o",
            input_tokens=10,
            output_tokens=5,
            response_id="id-1",
            finish_reasons=["stop"],
            temperature=0.5,
            max_tokens=100,
            cost=0.01,
            custom="value",
        )

        assert attrs[GenAIAttributes.OPERATION_NAME] == "chat"
        assert attrs[GenAIAttributes.PROVIDER_NAME] == "openai"
        assert attrs[GenAIAttributes.REQUEST_MODEL] == "gpt-4o"
        assert attrs[GenAIAttributes.RESPONSE_MODEL] == "gpt-4o"
        assert attrs[GenAIAttributes.USAGE_INPUT_TOKENS] == 10
        assert attrs[GenAIAttributes.USAGE_OUTPUT_TOKENS] == 5
        assert attrs[GenAIAttributes.USAGE_TOTAL_TOKENS] == 15
        assert attrs[GenAIAttributes.RESPONSE_ID] == "id-1"
        assert attrs[GenAIAttributes.RESPONSE_FINISH_REASONS] == ["stop"]
        assert attrs[GenAIAttributes.REQUEST_TEMPERATURE] == 0.5
        assert attrs[GenAIAttributes.REQUEST_MAX_TOKENS] == 100
        assert attrs[GenAIAttributes.COST] == 0.01
        assert attrs["gen_ai.custom"] == "value"

    def test_create_tool_attributes(self):
        """Test creating tool attributes."""
        attrs = create_tool_attributes(
            tool_name="search",
            tool_call_id="call-1",
            arguments={"q": "x"},
            result={"ok": True},
        )

        assert attrs[GenAIAttributes.OPERATION_NAME] == GenAIOperations.EXECUTE_TOOL
        assert attrs[GenAIAttributes.TOOL_NAME] == "search"
        assert attrs[GenAIAttributes.TOOL_CALL_ID] == "call-1"
        assert attrs[GenAIAttributes.TOOL_CALL_ARGUMENTS] == {"q": "x"}
        assert attrs[GenAIAttributes.TOOL_CALL_RESULT] == {"ok": True}

    def test_create_agent_attributes(self):
        """Test creating agent attributes."""
        attrs = create_agent_attributes(
            agent_name="Agent",
            agent_id="agent-1",
            description="desc",
            model="gpt-4o",
            provider="openai",
            system_instructions="sys",
        )

        assert attrs[GenAIAttributes.OPERATION_NAME] == GenAIOperations.INVOKE_AGENT
        assert attrs[GenAIAttributes.AGENT_NAME] == "Agent"
        assert attrs[GenAIAttributes.AGENT_ID] == "agent-1"
        assert attrs[GenAIAttributes.AGENT_DESCRIPTION] == "desc"
        assert attrs[GenAIAttributes.REQUEST_MODEL] == "gpt-4o"
        assert attrs[GenAIAttributes.PROVIDER_NAME] == "openai"
        assert attrs[GenAIAttributes.SYSTEM_INSTRUCTIONS] == "sys"


def test_register_lifecycle_hooks_success():
    config = NativeOTELConfig(enabled=False, register_lifecycle_hooks=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch("atexit.register") as mock_register, patch(
        "signal.signal"
    ) as mock_signal:
        manager = NativeOTELManager(config=config)
        with patch.object(manager, "shutdown") as mock_shutdown:
            manager._register_lifecycle_hooks()
            handler = mock_signal.call_args[0][1]
            handler(15, None)
            mock_register.assert_called_once()
            mock_shutdown.assert_called()


def test_span_with_tracer_and_transform():
    config = NativeOTELConfig(
        enabled=True,
        register_lifecycle_hooks=False,
        set_global_provider=False,
        genai_semantic_conventions=True,
    )
    provider = MagicMock()
    tracer = MagicMock()
    yielded_span = MagicMock()

    def span_cm(*args, **kwargs):
        @contextmanager
        def _cm():
            yield yielded_span

        return _cm()

    tracer.start_as_current_span.side_effect = span_cm
    provider.get_tracer.return_value = tracer
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.OTelResource"
    ) as mock_resource, patch(
        "autonomize_observer.tracing.native_otel_manager.TracerProvider",
        return_value=provider,
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.BatchSpanProcessor"
    ) as mock_batch, patch(
        "autonomize_observer.tracing.native_otel_manager.SimpleSpanProcessor"
    ) as mock_simple, patch(
        "autonomize_observer.tracing.span_transformer.transform_to_genai",
        side_effect=lambda attrs: attrs | {"gen_ai.extra": True},
    ) as mock_transform:
        mock_resource.create.return_value = MagicMock()
        manager = NativeOTELManager(config=config)
        with manager.span("test", attributes={"model": "gpt-4o"}, provider="openai"):
            pass
        assert mock_transform.called
        tracer.start_as_current_span.assert_called()


def test_span_with_tracer_without_transform():
    config = NativeOTELConfig(
        enabled=True,
        register_lifecycle_hooks=False,
        set_global_provider=False,
        genai_semantic_conventions=False,
    )
    provider = MagicMock()
    tracer = MagicMock()

    def span_cm(*args, **kwargs):
        @contextmanager
        def _cm():
            yield MagicMock()

        return _cm()

    tracer.start_as_current_span.side_effect = span_cm
    provider.get_tracer.return_value = tracer
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.OTelResource"
    ) as mock_resource, patch(
        "autonomize_observer.tracing.native_otel_manager.TracerProvider",
        return_value=provider,
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.BatchSpanProcessor"
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.SimpleSpanProcessor"
    ):
        mock_resource.create.return_value = MagicMock()
        manager = NativeOTELManager(config=config)
        with manager.span("test", attributes={"model": "gpt-4o"}):
            pass
        tracer.start_as_current_span.assert_called()


def test_start_span_with_tracer_and_transform():
    config = NativeOTELConfig(
        enabled=True,
        register_lifecycle_hooks=False,
        set_global_provider=False,
        genai_semantic_conventions=True,
    )
    provider = MagicMock()
    tracer = MagicMock()
    provider.get_tracer.return_value = tracer
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.OTelResource"
    ) as mock_resource, patch(
        "autonomize_observer.tracing.native_otel_manager.TracerProvider",
        return_value=provider,
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.BatchSpanProcessor"
    ) as mock_batch, patch(
        "autonomize_observer.tracing.native_otel_manager.SimpleSpanProcessor"
    ) as mock_simple, patch(
        "autonomize_observer.tracing.span_transformer.transform_to_genai",
        side_effect=lambda attrs: attrs | {"gen_ai.extra": True},
    ) as mock_transform:
        mock_resource.create.return_value = MagicMock()
        manager = NativeOTELManager(config=config)
        span = manager.start_span("test", attributes={"model": "gpt-4o"})
        assert mock_transform.called
        tracer.start_span.assert_called()


def test_start_span_with_tracer_without_transform():
    config = NativeOTELConfig(
        enabled=True,
        register_lifecycle_hooks=False,
        set_global_provider=False,
        genai_semantic_conventions=False,
    )
    provider = MagicMock()
    tracer = MagicMock()
    provider.get_tracer.return_value = tracer
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.OTelResource"
    ) as mock_resource, patch(
        "autonomize_observer.tracing.native_otel_manager.TracerProvider",
        return_value=provider,
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.BatchSpanProcessor"
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.SimpleSpanProcessor"
    ):
        mock_resource.create.return_value = MagicMock()
        manager = NativeOTELManager(config=config)
        span = manager.start_span("test", attributes={"model": "gpt-4o"})
        assert span is not None
        tracer.start_span.assert_called()


def test_end_span_handles_exception():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.Status"
    ) as mock_status, patch(
        "autonomize_observer.tracing.native_otel_manager.StatusCode"
    ) as mock_status_code:
        mock_status_code.OK = "ok"
        manager = NativeOTELManager(config=config)
        span = MagicMock()
        span.end.side_effect = Exception("fail")
        manager.end_span(span)
        mock_status.assert_called_with("ok")


def test_end_span_none_is_noop():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        manager.end_span(None)


def test_noop_span_methods():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        span = manager._create_noop_span()
        span.set_attributes({})
        span.add_event("x", {})
        span.record_exception(Exception("e"))
        span.set_status("ok")
        with span:
            pass
        span.end()


def test_force_flush_no_provider_returns_true():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        assert manager.force_flush() is True


def test_tracer_property_returns_tracer():
    config = NativeOTELConfig(
        enabled=True,
        register_lifecycle_hooks=False,
        set_global_provider=False,
    )
    provider = MagicMock()
    tracer = MagicMock()
    provider.get_tracer.return_value = tracer
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.OTelResource"
    ) as mock_resource, patch(
        "autonomize_observer.tracing.native_otel_manager.TracerProvider",
        return_value=provider,
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.BatchSpanProcessor"
    ), patch(
        "autonomize_observer.tracing.native_otel_manager.SimpleSpanProcessor"
    ):
        mock_resource.create.return_value = MagicMock()
        manager = NativeOTELManager(config=config)
        assert manager.tracer is tracer


def test_manager_context_manager_shutdown():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        with patch.object(NativeOTELManager, "shutdown") as mock_shutdown:
            with manager as m:
                assert m is manager
            mock_shutdown.assert_called()


def test_shutdown_without_provider_is_noop():
    config = NativeOTELConfig(enabled=False)
    with patch(
        "autonomize_observer.tracing.native_otel_manager.NATIVE_OTEL_AVAILABLE", True
    ):
        manager = NativeOTELManager(config=config)
        assert manager._provider is None
        manager.shutdown()
