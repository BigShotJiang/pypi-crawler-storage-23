from __future__ import annotations

import pytest

from autonomize_observer.schemas.genai_conventions import (
    GenAIAttributes,
    GenAIOperations,
)
from autonomize_observer.tracing.span_transformer import (
    SpanTransformer,
    get_transformer,
    transform_to_genai,
)


def test_transform_attributes_maps_and_unmapped():
    transformer = SpanTransformer()
    result = transformer.transform_attributes(
        {
            "model": "gpt-4o",
            "provider": "openai",
            "input_tokens": 3.0,
            "output_tokens": 4,
            "finish_reason": "stop",
            "gen_ai.custom": "x",
            "unknown": "y",
            "none": None,
        }
    )
    assert result[GenAIAttributes.REQUEST_MODEL] == "gpt-4o"
    assert result[GenAIAttributes.PROVIDER_NAME] == "openai"
    assert result[GenAIAttributes.USAGE_INPUT_TOKENS] == 3
    assert result[GenAIAttributes.USAGE_OUTPUT_TOKENS] == 4
    assert result[GenAIAttributes.RESPONSE_FINISH_REASONS] == ["stop"]
    assert result["gen_ai.custom"] == "x"
    assert result["gen_ai.unknown"] == "y"
    assert result[GenAIAttributes.OPERATION_NAME] == GenAIOperations.CHAT
    assert result[GenAIAttributes.USAGE_TOTAL_TOKENS] == 7


def test_transform_attributes_excludes_unmapped():
    transformer = SpanTransformer(include_unmapped=False)
    result = transformer.transform_attributes({"unknown": 1, "component_type": "tool"})
    assert "unknown" not in result
    assert result[GenAIAttributes.OPERATION_NAME] == GenAIOperations.EXECUTE_TOOL


def test_transform_attributes_unmapped_without_prefix():
    transformer = SpanTransformer(include_unmapped=True, prefix_unmapped=False)
    result = transformer.transform_attributes({"extra": 1, "component_type": "agent"})
    assert result["extra"] == 1
    assert result[GenAIAttributes.OPERATION_NAME] == GenAIOperations.INVOKE_AGENT


def test_transform_attributes_operation_override():
    transformer = SpanTransformer()
    result = transformer.transform_attributes(
        {"tool_name": "search"}, operation="custom-op"
    )
    assert result[GenAIAttributes.TOOL_NAME] == "search"
    assert result[GenAIAttributes.OPERATION_NAME] == "custom-op"


def test_transform_attributes_preserves_operation_and_tokens():
    transformer = SpanTransformer()
    result = transformer.transform_attributes(
        {
            "gen_ai.operation.name": "preset",
            "finish_reasons": ["stop"],
            "input_tokens": 2,
        }
    )
    assert result[GenAIAttributes.OPERATION_NAME] == "preset"
    assert result[GenAIAttributes.RESPONSE_FINISH_REASONS] == ["stop"]
    assert GenAIAttributes.USAGE_TOTAL_TOKENS not in result


def test_infer_operation_from_attributes_tool_and_agent():
    transformer = SpanTransformer()
    assert (
        transformer._infer_operation({"tool_name": "search"})
        == GenAIOperations.EXECUTE_TOOL
    )
    assert (
        transformer._infer_operation({"agent_id": "agent"})
        == GenAIOperations.INVOKE_AGENT
    )


def test_transform_span_name_with_component_and_model():
    transformer = SpanTransformer()
    result = transformer.transform_span_name(
        "anything", component_type="tool", model="gpt-4o"
    )
    assert result == f"{GenAIOperations.EXECUTE_TOOL} gpt-4o"


def test_transform_span_name_infers_from_name():
    transformer = SpanTransformer()
    assert transformer.transform_span_name("embedding run") == GenAIOperations.EMBEDDINGS
    assert transformer.transform_span_name("unknown") == GenAIOperations.CHAT


@pytest.mark.parametrize(
    "name,expected",
    [
        ("chat request", GenAIOperations.CHAT),
        ("completion job", GenAIOperations.TEXT_COMPLETION),
        ("embedding", GenAIOperations.EMBEDDINGS),
        ("tool call", GenAIOperations.EXECUTE_TOOL),
        ("function run", GenAIOperations.EXECUTE_TOOL),
        ("agent action", GenAIOperations.INVOKE_AGENT),
        ("image render", GenAIOperations.IMAGE_GENERATION),
        ("audio transcription", GenAIOperations.AUDIO_TRANSCRIPTION),
        ("unknown", GenAIOperations.CHAT),
    ],
)
def test_infer_operation_from_span_name(name, expected):
    transformer = SpanTransformer()
    assert transformer.infer_operation_from_span_name(name) == expected


def test_get_transformer_singleton_and_transform_to_genai():
    first = get_transformer()
    second = get_transformer()
    assert first is second
    result = transform_to_genai({"model": "gpt-4o"})
    assert result[GenAIAttributes.REQUEST_MODEL] == "gpt-4o"
