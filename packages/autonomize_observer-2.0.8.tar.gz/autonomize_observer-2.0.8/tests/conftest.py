"""Pytest configuration and fixtures."""

from unittest.mock import MagicMock, patch

import pytest

from autonomize_observer.core.config import KafkaConfig, ObserverConfig


@pytest.fixture
def kafka_config():
    """Create a test Kafka configuration."""
    return KafkaConfig(
        bootstrap_servers="localhost:9092",
        client_id="test-client",
        audit_topic="test-audit-events",
    )


@pytest.fixture(autouse=True)
def mock_imports():
    """Mock optional imports."""
    mock_kafka = MagicMock()
    mock_otel = MagicMock()

    # We use a dictionary to update sys.modules
    # We need to preserve existing modules if they are installed,
    # but since this is for handling missing dependencies, we can just patch them if we are sure they are missing,
    # or just patch them always for unit tests to isolate from environment.
    # Given the previous errors, they are likely missing.
    modules_to_patch = {
        "confluent_kafka": mock_kafka,
        "opentelemetry": mock_otel,
        "opentelemetry.trace": mock_otel.trace,
        "opentelemetry.trace.propagation": mock_otel.trace.propagation,
        "opentelemetry.trace.propagation.tracecontext": mock_otel.trace.propagation.tracecontext,
    }

    with patch.dict("sys.modules", modules_to_patch):
        yield


@pytest.fixture
def observer_config(kafka_config):
    """Create a test observer configuration."""
    return ObserverConfig(
        service_name="test-service",
        service_version="1.0.0",
        environment="test",
        kafka=kafka_config,
    )


@pytest.fixture
def mock_kafka_producer():
    """Create a mock Kafka producer."""
    with patch("confluent_kafka.Producer") as mock:
        producer = MagicMock()
        producer.produce = MagicMock()
        producer.poll = MagicMock(return_value=0)
        producer.flush = MagicMock(return_value=0)
        mock.return_value = producer
        yield producer


@pytest.fixture
def mock_logfire():
    """Create a mock logfire module."""
    mock_module = MagicMock()
    mock_module.configure = MagicMock()
    mock_module.instrument_openai = MagicMock()
    mock_module.instrument_anthropic = MagicMock()
    mock_module.span = MagicMock()

    # We need to mock both the module in sys.modules (for imports)
    # AND the availability flag in core.imports
    with patch.dict("sys.modules", {"logfire": mock_module}):
        with patch("autonomize_observer.core.imports.LOGFIRE_AVAILABLE", True):
            # Also patch the imports where they might have already been resolved or failed
            # and patch the core imports
            with patch("autonomize_observer.core.imports.logfire", mock_module):
                yield {
                    "configure": mock_module.configure,
                    "instrument_openai": mock_module.instrument_openai,
                    "instrument_anthropic": mock_module.instrument_anthropic,
                    "span": mock_module.span,
                    "instrument_fastapi": mock_module.instrument_fastapi,
                    "instrument_flask": mock_module.instrument_flask,
                    "instrument_django": mock_module.instrument_django,
                    "instrument_starlette": mock_module.instrument_starlette,
                    "instrument_sqlalchemy": mock_module.instrument_sqlalchemy,
                    "instrument_psycopg": mock_module.instrument_psycopg,
                    "instrument_asyncpg": mock_module.instrument_asyncpg,
                    "instrument_pymongo": mock_module.instrument_pymongo,
                    "instrument_redis": mock_module.instrument_redis,
                    "module": mock_module,
                }


@pytest.fixture
def sample_keycloak_token():
    """Create a sample Keycloak JWT payload."""
    return {
        "sub": "user-123",
        "email": "test@example.com",
        "name": "Test User",
        "preferred_username": "testuser",
        "realm_access": {"roles": ["admin", "user"]},
        "groups": ["/org/team"],
        "session_state": "session-456",
    }
