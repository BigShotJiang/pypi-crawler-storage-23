from __future__ import annotations

import json
import types
from unittest.mock import MagicMock, patch

import pytest

from autonomize_observer.core.native_otel_config import EventHubConfig
from autonomize_observer.core.phi_config import PHIDetectionConfig
from autonomize_observer.exporters.otel.eventhub_span_exporter import EventHubSpanExporter
from autonomize_observer.schemas.genai_conventions import GenAIAttributes


class SpanExportResultStub:
    SUCCESS = "success"
    FAILURE = "failure"


class FakeEventData:
    def __init__(self, body: bytes):
        self.body = body
        self.properties: dict[str, str] = {}


class FakeBatch:
    def __init__(self, max_items: int):
        self._items: list[FakeEventData] = []
        self._max_items = max_items

    def add(self, event: FakeEventData) -> None:
        if len(self._items) >= self._max_items:
            raise ValueError("batch full")
        self._items.append(event)

    def __len__(self) -> int:
        return len(self._items)


def _make_span_context(trace_id: int = 0x1234, span_id: int = 0x5678):
    ctx = MagicMock()
    ctx.trace_id = trace_id
    ctx.span_id = span_id
    return ctx


def _make_span(
    name: str = "test-span",
    attributes: dict | None = None,
    trace_id: int = 0x1234,
    span_id: int = 0x5678,
    parent: MagicMock | None = None,
    status_code_value: int = 0,
    status_description: str | None = None,
    start_time: int = 1_000_000_000,
    end_time: int = 2_000_000_000,
    resource_attrs: dict | None = None,
) -> MagicMock:
    span = MagicMock()
    span.name = name
    span.attributes = attributes or {}
    span.get_span_context.return_value = _make_span_context(trace_id, span_id)
    span.parent = parent
    span.start_time = start_time
    span.end_time = end_time
    span.status.status_code.value = status_code_value
    span.status.description = status_description
    if resource_attrs is not None:
        span.resource = MagicMock()
        span.resource.attributes = resource_attrs
    else:
        span.resource = None
    return span


@pytest.fixture
def eventhub_config():
    return EventHubConfig(
        connection_string="Endpoint=sb://test.servicebus.windows.net/;SharedAccessKeyName=Key;SharedAccessKey=abc",
        eventhub_name="otel-traces",
        restricted_eventhub_name="otel-phi-traces",
        usecase_id="TestApp",
    )


@pytest.fixture
def exporter_setup(eventhub_config):
    with patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.NATIVE_OTEL_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.AZURE_EVENTHUB_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.SpanExportResult",
        SpanExportResultStub,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventData",
        FakeEventData,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventHubProducerClient"
    ) as mock_client, patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.DefaultAzureCredential"
    ):
        producer = MagicMock()
        mock_client.from_connection_string.return_value = producer
        mock_client.return_value = producer
        exporter = EventHubSpanExporter(config=eventhub_config)
        yield exporter, mock_client, producer


def test_init_requires_native_otel(eventhub_config):
    with patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.NATIVE_OTEL_AVAILABLE",
        False,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.AZURE_EVENTHUB_AVAILABLE",
        True,
    ):
        with pytest.raises(ImportError):
            EventHubSpanExporter(config=eventhub_config)


def test_init_requires_eventhub(eventhub_config):
    with patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.NATIVE_OTEL_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.AZURE_EVENTHUB_AVAILABLE",
        False,
    ):
        with pytest.raises(ImportError):
            EventHubSpanExporter(config=eventhub_config)


def test_create_producer_connection_string(exporter_setup, eventhub_config):
    exporter, mock_client, _ = exporter_setup
    exporter._create_producer("custom")
    mock_client.from_connection_string.assert_called_with(
        conn_str=eventhub_config.connection_string,
        eventhub_name="custom",
    )


def test_create_producer_namespace():
    config = EventHubConfig(
        fully_qualified_namespace="ns.servicebus.windows.net",
        eventhub_name="otel-traces",
        usecase_id="TestApp",
    )
    with patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.NATIVE_OTEL_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.AZURE_EVENTHUB_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.SpanExportResult",
        SpanExportResultStub,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventData",
        FakeEventData,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventHubProducerClient"
    ) as mock_client, patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.DefaultAzureCredential"
    ):
        producer = MagicMock()
        mock_client.return_value = producer
        exporter = EventHubSpanExporter(config=config)
        exporter._get_credential = MagicMock(return_value="cred")
        exporter._create_producer("otel-traces")
        mock_client.assert_called_with(
            fully_qualified_namespace="ns.servicebus.windows.net",
            eventhub_name="otel-traces",
            credential="cred",
        )


def test_get_producer_caches(exporter_setup):
    exporter, _, producer = exporter_setup
    exporter._create_producer = MagicMock(return_value=producer)
    first = exporter._get_producer()
    second = exporter._get_producer()
    assert first is second
    exporter._create_producer.assert_called_once()


def test_get_producer_restricted_uses_restricted_name(
    exporter_setup, eventhub_config
):
    exporter, _, producer = exporter_setup
    exporter._create_producer = MagicMock(return_value=producer)
    restricted = exporter._get_producer(restricted=True)
    assert restricted is producer
    exporter._create_producer.assert_called_once_with(
        eventhub_config.restricted_eventhub_name
    )


def test_get_producer_restricted_cached(exporter_setup):
    exporter, _, producer = exporter_setup
    exporter._restricted_producer = producer
    restricted = exporter._get_producer(restricted=True)
    assert restricted is producer


def test_export_empty_returns_success(exporter_setup):
    exporter, _, _ = exporter_setup
    assert exporter.export([]) == SpanExportResultStub.SUCCESS


def test_export_routes_phi_and_regular(exporter_setup):
    exporter, _, _ = exporter_setup
    regular = _make_span("normal")
    phi = _make_span("patient data", attributes={"contains_phi": True})
    producer_regular = MagicMock()
    producer_restricted = MagicMock()
    exporter._get_producer = MagicMock(
        side_effect=[producer_regular, producer_restricted]
    )
    exporter._send_batch = MagicMock()
    result = exporter.export([regular, phi])
    assert result == SpanExportResultStub.SUCCESS
    assert exporter._send_batch.call_count == 2
    calls = exporter._send_batch.call_args_list
    assert calls[0].args[0] is producer_regular
    assert calls[1].args[0] is producer_restricted


def test_export_phi_without_restricted():
    config = EventHubConfig(
        connection_string="Endpoint=sb://test.servicebus.windows.net/;SharedAccessKeyName=Key;SharedAccessKey=abc",
        eventhub_name="otel-traces",
        restricted_eventhub_name=None,
        usecase_id="TestApp",
    )
    with patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.NATIVE_OTEL_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.AZURE_EVENTHUB_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.SpanExportResult",
        SpanExportResultStub,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventData",
        FakeEventData,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventHubProducerClient"
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.DefaultAzureCredential"
    ):
        exporter = EventHubSpanExporter(config=config)
        exporter._get_producer = MagicMock(return_value=MagicMock())
        exporter._send_batch = MagicMock()
        phi = _make_span("patient-data", attributes={"contains_phi": True})
        exporter.export([phi])
        exporter._send_batch.assert_called_once()


def test_export_counts_failed_span_conversion(exporter_setup):
    exporter, _, _ = exporter_setup
    span_ok = _make_span("ok")
    span_bad = _make_span("bad")
    exporter._span_to_event_data = MagicMock(
        side_effect=[FakeEventData(b"ok"), RuntimeError("fail")]
    )
    exporter._get_producer = MagicMock(return_value=MagicMock())
    exporter._send_batch = MagicMock()
    result = exporter.export([span_ok, span_bad])
    assert result == SpanExportResultStub.SUCCESS
    assert exporter._spans_failed == 1
    exporter._send_batch.assert_called_once()


def test_export_returns_failure_on_unhandled_error(exporter_setup):
    exporter, _, _ = exporter_setup
    exporter._get_producer = MagicMock(side_effect=RuntimeError("boom"))
    span = _make_span("regular")
    result = exporter.export([span])
    assert result == SpanExportResultStub.FAILURE
    assert exporter._spans_failed == 1


def test_span_to_event_data_properties(exporter_setup):
    exporter, _, _ = exporter_setup
    span = _make_span("chat gpt-4o", trace_id=0xABCD, span_id=0x1234)
    event = exporter._span_to_event_data(span)
    payload = json.loads(event.body.decode("utf-8"))
    assert payload["name"] == "chat gpt-4o"
    assert event.properties["usecase_id"] == "TestApp"
    assert event.properties["trace_id"] == format(0xABCD, "032x")
    assert event.properties["span_name"] == "chat gpt-4o"


def test_extract_attributes_transforms(exporter_setup):
    exporter, _, _ = exporter_setup
    span = _make_span(
        "chat gpt-4o",
        attributes={"provider": "openai", "input_tokens": 3},
    )
    attrs = exporter._extract_attributes(span)
    assert attrs[GenAIAttributes.PROVIDER_NAME] == "openai"
    assert attrs[GenAIAttributes.USAGE_INPUT_TOKENS] == 3
    assert GenAIAttributes.OPERATION_NAME in attrs


def test_extract_attributes_no_transform(exporter_setup):
    exporter, _, _ = exporter_setup
    exporter._transform_to_genai = False
    span = _make_span(attributes={"custom": 1})
    assert exporter._extract_attributes(span) == {"custom": 1}


def test_extract_attributes_maps_and_infers_operation(exporter_setup):
    exporter, _, _ = exporter_setup
    span = _make_span(
        "tool call",
        attributes={
            "gen_ai.custom": "x",
            "model": "gpt-4o",
        },
    )
    attrs = exporter._extract_attributes(span)
    assert attrs["gen_ai.custom"] == "x"
    assert attrs[GenAIAttributes.REQUEST_MODEL] == "gpt-4o"
    assert attrs[GenAIAttributes.OPERATION_NAME] == "execute_tool"


def test_extract_attributes_preserves_operation(exporter_setup):
    exporter, _, _ = exporter_setup
    span = _make_span(
        "chat",
        attributes={
            "gen_ai.operation.name": "custom",
            "provider": "openai",
        },
    )
    attrs = exporter._extract_attributes(span)
    assert attrs[GenAIAttributes.OPERATION_NAME] == "custom"


def test_extract_resource_attribute_handles_resource(exporter_setup):
    exporter, _, _ = exporter_setup
    span = _make_span(resource_attrs={"autonomize.organization_id": "org"})
    assert (
        exporter._extract_resource_attribute(span, "autonomize.organization_id")
        == "org"
    )
    span.resource = None
    assert (
        exporter._extract_resource_attribute(span, "autonomize.organization_id")
        is None
    )


def test_infer_operation_from_name(exporter_setup):
    exporter, _, _ = exporter_setup
    assert exporter._infer_operation(_make_span("chat")) == "chat"
    assert exporter._infer_operation(_make_span("execute_tool search")) == "execute_tool"
    assert exporter._infer_operation(_make_span("invoke_agent alpha")) == "invoke_agent"


def test_is_phi_span_attribute_flag(exporter_setup):
    exporter, _, _ = exporter_setup
    span = _make_span(attributes={"contains_phi": True})
    assert exporter._is_phi_span(span) is True


def test_is_phi_span_word_boundary(exporter_setup):
    exporter, _, _ = exporter_setup
    exporter._phi_config = PHIDetectionConfig(patterns=["patient"])
    span = _make_span("process patient record")
    assert exporter._is_phi_span(span) is True


def test_send_batch_batches_and_counts(exporter_setup):
    exporter, _, _ = exporter_setup
    producer = MagicMock()
    batch1 = FakeBatch(max_items=1)
    batch2 = FakeBatch(max_items=1)
    producer.create_batch.side_effect = [batch1, batch2]
    exporter._send_with_retry = MagicMock()
    event1 = FakeEventData(b"1")
    event2 = FakeEventData(b"2")
    exporter._send_batch(producer, [event1, event2])
    assert exporter._send_with_retry.call_count == 2
    assert exporter._spans_exported == 2


def test_send_batch_empty_does_not_send(exporter_setup):
    exporter, _, _ = exporter_setup
    producer = MagicMock()
    producer.create_batch.return_value = FakeBatch(max_items=10)
    exporter._send_with_retry = MagicMock()
    exporter._send_batch(producer, [])
    exporter._send_with_retry.assert_not_called()
    assert exporter._spans_exported == 0


def test_send_with_retry_retries(exporter_setup):
    exporter, _, _ = exporter_setup
    producer = MagicMock()
    producer.send_batch.side_effect = [Exception("timeout"), None]
    with patch("time.sleep"):
        exporter._send_with_retry(producer, MagicMock())
    assert producer.send_batch.call_count == 2


def test_send_with_retry_raises_non_retryable(exporter_setup):
    exporter, _, _ = exporter_setup
    producer = MagicMock()
    producer.send_batch.side_effect = [Exception("bad request")]
    with pytest.raises(Exception):
        exporter._send_with_retry(producer, MagicMock())


def test_send_with_retry_raises_after_exhaustion(exporter_setup):
    exporter, _, _ = exporter_setup
    exporter._config.max_retries = 0
    producer = MagicMock()
    producer.send_batch.side_effect = [Exception("bad request")]
    with pytest.raises(Exception):
        exporter._send_with_retry(producer, MagicMock())


def test_send_with_retry_no_attempts_when_disabled(exporter_setup):
    exporter, _, _ = exporter_setup
    exporter._config.max_retries = -1
    producer = MagicMock()
    exporter._send_with_retry(producer, MagicMock())
    producer.send_batch.assert_not_called()


def test_shutdown_closes_producers(exporter_setup):
    exporter, _, _ = exporter_setup
    producer = MagicMock()
    restricted = MagicMock()
    exporter._producer = producer
    exporter._restricted_producer = restricted
    exporter.shutdown()
    producer.close.assert_called_once()
    restricted.close.assert_called_once()
    assert exporter._producer is None
    assert exporter._restricted_producer is None


def test_shutdown_handles_empty_producers(exporter_setup):
    exporter, _, _ = exporter_setup
    exporter._producer = None
    exporter._restricted_producer = None
    exporter.shutdown()


def test_force_flush_returns_true(exporter_setup):
    exporter, _, _ = exporter_setup
    assert exporter.force_flush() is True


def test_stats(exporter_setup):
    exporter, _, _ = exporter_setup
    exporter._spans_exported = 7
    exporter._spans_failed = 2
    stats = exporter.stats
    assert stats["spans_exported"] == 7
    assert stats["spans_failed"] == 2


def test_create_producer_requires_config():
    config = EventHubConfig(
        connection_string=None,
        fully_qualified_namespace=None,
        eventhub_name="otel-traces",
        usecase_id="TestApp",
    )
    with patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.NATIVE_OTEL_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.AZURE_EVENTHUB_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.SpanExportResult",
        SpanExportResultStub,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventData",
        FakeEventData,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventHubProducerClient"
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.DefaultAzureCredential"
    ):
        exporter = EventHubSpanExporter(config=config)
        with pytest.raises(ValueError):
            exporter._create_producer("otel-traces")


def test_get_credential_types(eventhub_config):
    module = types.SimpleNamespace(
        ManagedIdentityCredential=MagicMock(return_value="managed"),
        WorkloadIdentityCredential=MagicMock(return_value="workload"),
    )
    with patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.NATIVE_OTEL_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.AZURE_EVENTHUB_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.SpanExportResult",
        SpanExportResultStub,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventData",
        FakeEventData,
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.EventHubProducerClient"
    ), patch(
        "autonomize_observer.exporters.otel.eventhub_span_exporter.DefaultAzureCredential",
        return_value="default",
    ), patch.dict("sys.modules", {"azure.identity": module}):
        config = EventHubConfig(
            connection_string=eventhub_config.connection_string,
            eventhub_name="otel-traces",
            usecase_id="TestApp",
            credential_type="managed",
        )
        exporter = EventHubSpanExporter(config=config)
        assert exporter._get_credential() == "managed"
        exporter._config.credential_type = "workload"
        assert exporter._get_credential() == "workload"
        exporter._config.credential_type = "default"
        assert exporter._get_credential() == "default"
        exporter._config.credential_type = "unknown"
        assert exporter._get_credential() == "default"


def test_format_time_handles_none(exporter_setup):
    exporter, _, _ = exporter_setup
    assert exporter._format_time(None) is None
