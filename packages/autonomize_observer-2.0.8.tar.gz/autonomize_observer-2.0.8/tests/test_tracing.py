"""Tests for tracing logfire integration module."""

from unittest.mock import MagicMock, patch

import pytest

from autonomize_observer.tracing.logfire_integration import (
    configure_logfire,
    get_logfire,
    instrument_database,
    instrument_llms,
    instrument_web_framework,
)


class TestConfigureLogfire:
    """Tests for configure_logfire function."""

    def test_basic_configure(self, mock_logfire):
        """Test basic logfire configuration."""

        # Reset global state
        configure_logfire(service_name="test-service", send_to_logfire=False)

        # We need to manually reset the validation logic in configure_logfire if it relies on side effects
        # But here we just check if configure was called on the mock
        mock_logfire["configure"].assert_called_once()
        call_kwargs = mock_logfire["configure"].call_args[1]
        assert call_kwargs["service_name"] == "test-service"
        assert call_kwargs["send_to_logfire"] is False

    def test_configure_with_all_options(self, mock_logfire):
        """Test configuration with all options."""
        configure_logfire(
            service_name="my-service",
            service_version="2.0.0",
            environment="staging",
            send_to_logfire=True,
            console=False,
            additional_span_processors=[MagicMock()],
        )

        call_kwargs = mock_logfire["configure"].call_args[1]
        assert call_kwargs["service_name"] == "my-service"
        assert call_kwargs["service_version"] == "2.0.0"
        assert call_kwargs["environment"] == "staging"
        assert call_kwargs["send_to_logfire"] is True
        assert call_kwargs["console"] is False
        assert "additional_span_processors" in call_kwargs

    def test_configure_with_kwargs(self, mock_logfire):
        """Test configuration with extra kwargs."""
        configure_logfire(
            service_name="test",
            custom_option="custom_value",
        )

        call_kwargs = mock_logfire["configure"].call_args[1]
        assert call_kwargs["custom_option"] == "custom_value"


class TestGetLogfire:
    """Tests for get_logfire function."""

    def test_get_logfire_not_configured(self):
        """Test getting logfire when not configured."""
        import autonomize_observer.tracing.logfire_integration as module

        original = module._logfire_instance
        module._logfire_instance = None

        try:
            with pytest.raises(RuntimeError) as exc_info:
                get_logfire()
            assert "not configured" in str(exc_info.value).lower()
        finally:
            module._logfire_instance = original

    def test_get_logfire_configured(self):
        """Test getting logfire after configuration."""
        import autonomize_observer.tracing.logfire_integration as module

        mock_logfire = MagicMock()
        original = module._logfire_instance
        module._logfire_instance = mock_logfire

        try:
            result = get_logfire()
            assert result is mock_logfire
        finally:
            module._logfire_instance = original


class TestInstrumentLLMs:
    """Tests for instrument_llms function."""

    def test_instrument_openai(self, mock_logfire):
        """Test instrumenting OpenAI."""
        # Use get_logfire to ensure we are mocking the instance retrieval or patch it
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_llms(openai=True, anthropic=False)

            mock_logfire["instrument_openai"].assert_called_once()
            mock_logfire["instrument_anthropic"].assert_not_called()

    def test_instrument_anthropic(self, mock_logfire):
        """Test instrumenting Anthropic."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_llms(openai=False, anthropic=True)

            mock_logfire["instrument_openai"].assert_not_called()
            mock_logfire["instrument_anthropic"].assert_called_once()

    def test_instrument_both(self, mock_logfire):
        """Test instrumenting both providers."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_llms(openai=True, anthropic=True)

            mock_logfire["instrument_openai"].assert_called_once()
            mock_logfire["instrument_anthropic"].assert_called_once()

    def test_instrument_with_options(self, mock_logfire):
        """Test instrumenting with provider options."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_llms(
                openai=True,
                anthropic=False,
                openai_options={"capture_messages": True},
            )

            mock_logfire["instrument_openai"].assert_called_once_with(
                capture_messages=True
            )

    def test_instrument_openai_failure(self, mock_logfire):
        """Test handling OpenAI instrumentation failure."""
        mock_logfire["instrument_openai"].side_effect = Exception(
            "OpenAI not installed"
        )

        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            # Should not raise
            instrument_llms(openai=True, anthropic=False)

    def test_instrument_anthropic_failure(self, mock_logfire):
        """Test handling Anthropic instrumentation failure."""
        mock_logfire["instrument_anthropic"].side_effect = Exception(
            "Anthropic not installed"
        )

        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            # Should not raise
            instrument_llms(openai=False, anthropic=True)


class TestInstrumentWebFramework:
    """Tests for instrument_web_framework function."""

    def test_instrument_fastapi(self, mock_logfire):
        """Test instrumenting FastAPI."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_web_framework("fastapi")
            mock_logfire["instrument_fastapi"].assert_called_once()

    def test_instrument_flask(self, mock_logfire):
        """Test instrumenting Flask."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_web_framework("flask")
            mock_logfire["instrument_flask"].assert_called_once()

    def test_instrument_django(self, mock_logfire):
        """Test instrumenting Django."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_web_framework("django")
            mock_logfire["instrument_django"].assert_called_once()

    def test_instrument_starlette(self, mock_logfire):
        """Test instrumenting Starlette."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_web_framework("starlette")
            mock_logfire["instrument_starlette"].assert_called_once()

    def test_instrument_unknown_framework(self, mock_logfire):
        """Test instrumenting unknown framework."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            with pytest.raises(ValueError) as exc_info:
                instrument_web_framework("unknown")
            assert "unknown framework" in str(exc_info.value).lower()

    def test_instrument_framework_with_kwargs(self, mock_logfire):
        """Test instrumenting framework with options."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            mock_app = MagicMock()
            instrument_web_framework("fastapi", app=mock_app)
            mock_logfire["instrument_fastapi"].assert_called_once_with(app=mock_app)

    def test_instrument_framework_failure(self, mock_logfire):
        """Test handling framework instrumentation failure."""
        mock_logfire["instrument_fastapi"].side_effect = Exception(
            "FastAPI not installed"
        )

        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            # Should not raise
            instrument_web_framework("fastapi")


class TestInstrumentDatabase:
    """Tests for instrument_database function."""

    def test_instrument_sqlalchemy(self, mock_logfire):
        """Test instrumenting SQLAlchemy."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_database("sqlalchemy")
            mock_logfire["instrument_sqlalchemy"].assert_called_once()

    def test_instrument_psycopg(self, mock_logfire):
        """Test instrumenting psycopg."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_database("psycopg")
            mock_logfire["instrument_psycopg"].assert_called_once()

    def test_instrument_asyncpg(self, mock_logfire):
        """Test instrumenting asyncpg."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_database("asyncpg")
            mock_logfire["instrument_asyncpg"].assert_called_once()

    def test_instrument_pymongo(self, mock_logfire):
        """Test instrumenting pymongo."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_database("pymongo")
            mock_logfire["instrument_pymongo"].assert_called_once()

    def test_instrument_redis(self, mock_logfire):
        """Test instrumenting redis."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_database("redis")
            mock_logfire["instrument_redis"].assert_called_once()

    def test_instrument_unknown_database(self, mock_logfire):
        """Test instrumenting unknown database."""
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            with pytest.raises(ValueError) as exc_info:
                instrument_database("unknown")
            assert "unknown database" in str(exc_info.value).lower()

    def test_instrument_database_with_kwargs(self, mock_logfire):
        """Test instrumenting database with options."""
        mock_engine = MagicMock()
        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            instrument_database("sqlalchemy", engine=mock_engine)
            mock_logfire["instrument_sqlalchemy"].assert_called_once_with(
                engine=mock_engine
            )

    def test_instrument_database_failure(self, mock_logfire):
        """Test handling database instrumentation failure."""
        mock_logfire["instrument_sqlalchemy"].side_effect = Exception(
            "SQLAlchemy not installed"
        )

        with patch(
            "autonomize_observer.tracing.logfire_integration.get_logfire",
            return_value=mock_logfire["module"],
        ):
            # Should not raise
            instrument_database("sqlalchemy")
