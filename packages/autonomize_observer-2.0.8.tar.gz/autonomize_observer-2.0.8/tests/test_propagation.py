"""Tests for trace context propagation."""

from unittest.mock import MagicMock, patch

from autonomize_observer.tracing.propagation import (
    inject_trace_context,
    extract_trace_context,
    kafka_headers_to_dict,
    dict_to_kafka_headers,
    consume_with_trace,
)


class TestPropagation:
    """Tests for propagation helpers."""

    def test_kafka_headers_conversion(self):
        """Test conversion between dict and Kafka headers."""
        headers_dict = {"traceparent": "00-123-456-01"}

        # Dict to Kafka
        kafka_headers = dict_to_kafka_headers(headers_dict)
        assert len(kafka_headers) == 1
        assert kafka_headers[0] == ("traceparent", b"00-123-456-01")

        # Kafka to Dict
        restored_dict = kafka_headers_to_dict(kafka_headers)
        assert restored_dict == headers_dict

    def test_kafka_headers_to_dict_empty(self):
        """Test kafka_headers_to_dict handles empty inputs."""
        assert kafka_headers_to_dict(None) == {}
        assert kafka_headers_to_dict([]) == {}

    def test_inject_trace_context_not_available(self):
        """Test inject when generic OTEL is not available."""
        with patch("autonomize_observer.tracing.propagation.otel_trace", None):
            carrier = inject_trace_context()
            assert carrier == {}

    def test_extract_trace_context_not_available(self):
        """Test extract when generic OTEL is not available."""
        with patch("autonomize_observer.tracing.propagation.otel_trace", None):
            ctx = extract_trace_context({})
            assert ctx is None

    def test_inject_trace_context_success(self):
        """Test successful injection."""
        # Setup the mock for TraceContextTextMapPropagator
        mock_propagator = MagicMock()
        mock_prop_cls = MagicMock(return_value=mock_propagator)

        # Access the mocked module from sys.modules
        import opentelemetry.trace.propagation.tracecontext as tracecontext_module

        tracecontext_module.TraceContextTextMapPropagator = mock_prop_cls

        with patch("autonomize_observer.tracing.propagation.otel_trace", MagicMock()):
            inject_trace_context()

            mock_propagator.inject.assert_called_once()

    def test_extract_trace_context_success(self):
        """Test successful extraction."""
        # Setup the mock for TraceContextTextMapPropagator
        mock_propagator = MagicMock()
        mock_prop_cls = MagicMock(return_value=mock_propagator)

        # Access the mocked module from sys.modules
        import opentelemetry.trace.propagation.tracecontext as tracecontext_module

        tracecontext_module.TraceContextTextMapPropagator = mock_prop_cls

        with patch("autonomize_observer.tracing.propagation.otel_trace", MagicMock()):
            headers = {"traceparent": "00-123-456-01"}
            extract_trace_context(headers)

            mock_propagator.extract.assert_called_once_with(carrier=headers)


class TestConsumeWithTrace:
    """Tests for consume_with_trace context manager."""

    def test_consume_no_message(self):
        """Test consume when no message returned."""
        mock_manager = MagicMock()
        mock_consumer = MagicMock()
        mock_consumer.poll.return_value = None

        with consume_with_trace(mock_manager, mock_consumer, "test") as (msg, span):
            assert msg is None
            assert span is None

    def test_consume_error(self):
        """Test consume when message has error."""
        mock_manager = MagicMock()
        mock_consumer = MagicMock()
        mock_msg = MagicMock()
        mock_msg.error.return_value = "Some error"
        mock_consumer.poll.return_value = mock_msg

        with consume_with_trace(mock_manager, mock_consumer, "test") as (msg, span):
            assert msg is None
            assert span is None

    def test_consume_success(self):
        """Test successful consumption with tracing."""
        mock_manager = MagicMock()
        mock_span = MagicMock()
        mock_manager.tracer.start_as_current_span.return_value.__enter__.return_value = mock_span

        mock_consumer = MagicMock()
        mock_msg = MagicMock()
        mock_msg.error.return_value = None
        mock_msg.headers.return_value = [("traceparent", b"00-123-456-01")]
        mock_consumer.poll.return_value = mock_msg

        # We need to mock extract_trace_context or the underlying OTEL
        with patch(
            "autonomize_observer.tracing.propagation.extract_trace_context"
        ) as mock_extract:
            mock_ctx = MagicMock()
            mock_extract.return_value = mock_ctx

            with consume_with_trace(mock_manager, mock_consumer, "process-msg") as (
                msg,
                span,
            ):
                assert msg is mock_msg
                assert span is mock_span

                # Check if attributes were set
                mock_span.set_attribute.assert_called_with("messaging.system", "kafka")

            # Check if start_as_current_span was called with extracted context
            mock_manager.tracer.start_as_current_span.assert_called_once()
            call_kwargs = mock_manager.tracer.start_as_current_span.call_args[1]
            assert call_kwargs["context"] is mock_ctx
            # SpanKind is passed - just verify it exists
            assert "kind" in call_kwargs
