"""Tests for OTLP Configuration."""

from autonomize_observer.core.otlp_config import OTLPConfig


def test_otlp_config_defaults():
    """Test OTLPConfig default values."""
    config = OTLPConfig()

    assert config.endpoint == "http://localhost:4317"
    assert config.headers == {}
    assert config.insecure is True
    assert config.compression == "gzip"


def test_otlp_config_custom():
    """Test OTLPConfig custom values."""
    config = OTLPConfig(
        endpoint="https://otel.example.com",
        headers={"Authorization": "Bearer token"},
        insecure=False,
        compression="none",
    )

    assert config.endpoint == "https://otel.example.com"
    assert config.headers == {"Authorization": "Bearer token"}
    assert config.insecure is False
    assert config.compression == "none"


def test_otlp_config_from_env(monkeypatch):
    """Test OTLPConfig.from_env parses environment variables."""
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "https://otel.example.com")
    monkeypatch.setenv(
        "OTEL_EXPORTER_OTLP_HEADERS", "Authorization=Bearer token, X-Test=abc"
    )
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_INSECURE", "false")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_COMPRESSION", "none")

    config = OTLPConfig.from_env()

    assert config.endpoint == "https://otel.example.com"
    assert config.headers == {"Authorization": "Bearer token", "X-Test": "abc"}
    assert config.insecure is False
    assert config.compression == "none"


def test_otlp_config_from_env_ignores_invalid_pairs(monkeypatch):
    """Test OTLPConfig.from_env ignores header entries without '='."""
    monkeypatch.setenv(
        "OTEL_EXPORTER_OTLP_HEADERS",
        "Authorization=Bearer token,InvalidHeader",
    )

    config = OTLPConfig.from_env()

    assert config.headers == {"Authorization": "Bearer token"}


def test_otlp_config_is_configured():
    """Test OTLPConfig.is_configured."""
    assert OTLPConfig().is_configured is False
    assert OTLPConfig(endpoint="https://otel.example.com").is_configured is True
