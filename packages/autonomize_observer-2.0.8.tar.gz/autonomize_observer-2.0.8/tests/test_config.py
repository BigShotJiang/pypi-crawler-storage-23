"""Tests for configuration module."""

import os
from unittest.mock import patch


from autonomize_observer.core.config import KafkaConfig, LogLevel, ObserverConfig
from autonomize_observer.core.native_otel_config import EventHubConfig, NativeOTELConfig
from autonomize_observer.core.phi_config import PHIDetectionConfig


class TestKafkaConfig:
    """Tests for KafkaConfig."""

    def test_default_values(self):
        """Test default configuration values."""
        config = KafkaConfig()
        assert config.bootstrap_servers == "localhost:9092"
        assert config.client_id == "autonomize-observer"
        assert config.audit_topic == "genesis-audit-events"
        assert config.security_protocol is None
        assert config.sasl_mechanism is None
        assert config.sasl_username is None
        assert config.sasl_password is None

    def test_custom_values(self):
        """Test custom configuration values."""
        config = KafkaConfig(
            bootstrap_servers="kafka:9092",
            client_id="custom-client",
            audit_topic="custom-audit",
            security_protocol="SASL_SSL",
            sasl_mechanism="PLAIN",
            sasl_username="user",
            sasl_password="pass",
        )
        assert config.bootstrap_servers == "kafka:9092"
        assert config.client_id == "custom-client"
        assert config.audit_topic == "custom-audit"
        assert config.security_protocol == "SASL_SSL"
        assert config.sasl_mechanism == "PLAIN"
        assert config.sasl_username == "user"
        assert config.sasl_password == "pass"

    def test_from_env(self):
        """Test configuration from environment variables."""
        env_vars = {
            "KAFKA_BOOTSTRAP_SERVERS": "env-kafka:9092",
            "KAFKA_CLIENT_ID": "env-client",
            "KAFKA_AUDIT_TOPIC": "env-audit",
            "KAFKA_SECURITY_PROTOCOL": "SASL_PLAINTEXT",
            "KAFKA_SASL_MECHANISM": "SCRAM-SHA-256",
            "KAFKA_SASL_USERNAME": "env-user",
            "KAFKA_SASL_PASSWORD": "env-pass",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            config = KafkaConfig.from_env()
            assert config.bootstrap_servers == "env-kafka:9092"
            assert config.client_id == "env-client"
            assert config.audit_topic == "env-audit"
            assert config.security_protocol == "SASL_PLAINTEXT"
            assert config.sasl_mechanism == "SCRAM-SHA-256"
            assert config.sasl_username == "env-user"
            assert config.sasl_password == "env-pass"


class TestObserverConfig:
    """Tests for ObserverConfig."""

    def test_default_values(self):
        """Test default configuration values."""
        config = ObserverConfig()
        assert config.service_name == "autonomize-service"
        assert config.service_version == "1.0.0"
        assert config.environment == "production"
        assert config.send_to_logfire is False
        assert config.kafka_enabled is True
        assert config.audit_enabled is True
        assert config.audit_retention_days == 365
        assert config.log_level == LogLevel.INFO

    def test_custom_values(self):
        """Test custom configuration values."""
        config = ObserverConfig(
            service_name="my-service",
            service_version="2.0.0",
            environment="staging",
            send_to_logfire=True,
            kafka_enabled=False,
            audit_enabled=False,
            audit_retention_days=90,
            log_level=LogLevel.DEBUG,
        )
        assert config.service_name == "my-service"
        assert config.service_version == "2.0.0"
        assert config.environment == "staging"
        assert config.send_to_logfire is True
        assert config.kafka_enabled is False
        assert config.audit_enabled is False
        assert config.audit_retention_days == 90
        assert config.log_level == LogLevel.DEBUG

    def test_from_env(self):
        """Test configuration from environment variables."""
        env_vars = {
            "SERVICE_NAME": "env-service",
            "SERVICE_VERSION": "3.0.0",
            "ENVIRONMENT": "development",
            "SEND_TO_LOGFIRE": "true",
            "KAFKA_ENABLED": "false",
            "AUDIT_ENABLED": "false",
            "AUDIT_RETENTION_DAYS": "30",
            "LOG_LEVEL": "debug",
        }
        with patch.dict(os.environ, env_vars, clear=False):
            config = ObserverConfig.from_env()
            assert config.service_name == "env-service"
            assert config.service_version == "3.0.0"
            assert config.environment == "development"
            assert config.send_to_logfire is True
            assert config.kafka_enabled is False
            assert config.audit_enabled is False
            assert config.audit_retention_days == 30
            assert config.log_level == LogLevel.DEBUG

    def test_kafka_config_nested(self):
        """Test nested Kafka configuration."""
        kafka = KafkaConfig(bootstrap_servers="custom:9092")
        config = ObserverConfig(kafka=kafka)
        assert config.kafka.bootstrap_servers == "custom:9092"

    def test_keycloak_claim_mappings(self):
        """Test Keycloak claim mappings."""
        mappings = {"tenant_id": "custom_tenant"}
        config = ObserverConfig(keycloak_claim_mappings=mappings)
        assert config.keycloak_claim_mappings == mappings

    def test_actor_context_provider(self):
        """Test custom actor context provider."""

        def custom_provider():
            return None

        config = ObserverConfig(actor_context_provider=custom_provider)
        assert config.actor_context_provider is custom_provider


class TestEventHubConfig:
    """Tests for EventHubConfig."""

    def test_from_env(self, monkeypatch):
        """Test EventHubConfig.from_env."""
        monkeypatch.setenv("AZURE_EVENTHUB_CONNECTION_STRING", "Endpoint=sb://test/")
        monkeypatch.setenv("AZURE_EVENTHUB_NAMESPACE", "ns.servicebus.windows.net")
        monkeypatch.setenv("AZURE_EVENTHUB_NAME", "otel-traces")
        monkeypatch.setenv("AZURE_EVENTHUB_RESTRICTED_NAME", "otel-phi")
        monkeypatch.setenv("AZURE_USE_MANAGED_IDENTITY", "true")
        monkeypatch.setenv("AZURE_CREDENTIAL_TYPE", "workload")
        monkeypatch.setenv("AZURE_EVENTHUB_BATCH_SIZE", "250")
        monkeypatch.setenv("AZURE_EVENTHUB_USECASE_ID", "test-app")

        config = EventHubConfig.from_env()

        assert config.connection_string == "Endpoint=sb://test/"
        assert config.fully_qualified_namespace == "ns.servicebus.windows.net"
        assert config.eventhub_name == "otel-traces"
        assert config.restricted_eventhub_name == "otel-phi"
        assert config.use_managed_identity is True
        assert config.credential_type == "workload"
        assert config.max_batch_size == 250
        assert config.usecase_id == "test-app"
        assert config.is_configured is True

    def test_is_configured_false(self):
        """Test EventHubConfig.is_configured when unset."""
        config = EventHubConfig()
        assert config.is_configured is False


class TestNativeOTELConfig:
    """Tests for NativeOTELConfig."""

    def test_from_env(self, monkeypatch):
        """Test NativeOTELConfig.from_env."""
        monkeypatch.setenv("NATIVE_OTEL_ENABLED", "true")
        monkeypatch.setenv("SERVICE_NAME", "svc")
        monkeypatch.setenv("SERVICE_VERSION", "2.0.0")
        monkeypatch.setenv("ENVIRONMENT", "staging")
        monkeypatch.setenv("NATIVE_OTEL_ENABLE_KAFKA", "true")
        monkeypatch.setenv("NATIVE_OTEL_ENABLE_EVENTHUB", "true")
        monkeypatch.setenv("NATIVE_OTEL_ENABLE_OTLP_GRPC", "true")
        monkeypatch.setenv("NATIVE_OTEL_ENABLE_OTLP_HTTP", "true")
        monkeypatch.setenv("NATIVE_OTEL_ENABLE_CONSOLE", "true")
        monkeypatch.setenv("NATIVE_OTEL_BATCH_EXPORT", "false")
        monkeypatch.setenv("NATIVE_OTEL_EXPORT_TIMEOUT_MS", "5000")
        monkeypatch.setenv("NATIVE_OTEL_BATCH_SIZE", "42")
        monkeypatch.setenv("NATIVE_OTEL_SCHEDULE_DELAY_MS", "1200")
        monkeypatch.setenv("NATIVE_OTEL_GENAI_CONVENTIONS", "false")

        config = NativeOTELConfig.from_env()

        assert config.enabled is True
        assert config.service_name == "svc"
        assert config.service_version == "2.0.0"
        assert config.environment == "staging"
        assert config.enable_kafka is True
        assert config.enable_eventhub is True
        assert config.enable_otlp_grpc is True
        assert config.enable_otlp_http is True
        assert config.enable_console is True
        assert config.batch_export is False
        assert config.export_timeout_ms == 5000
        assert config.max_export_batch_size == 42
        assert config.schedule_delay_ms == 1200
        assert config.genai_semantic_conventions is False
        assert config.otlp_config is not None
        assert config.kafka_config is not None
        assert config.event_hub_config is not None

    def test_exporter_flag_properties(self):
        """Test uses_* flag properties."""
        config = NativeOTELConfig(
            enabled=True,
            enable_kafka=True,
            enable_eventhub=True,
            enable_otlp_grpc=True,
            enable_otlp_http=True,
            enable_console=True,
        )

        assert config.uses_kafka is True
        assert config.uses_event_hub is True
        assert config.uses_otlp_grpc is True
        assert config.uses_otlp_http is True
        assert config.uses_console is True
        assert config.has_any_exporter_enabled is True

    def test_validate_no_exporters(self):
        """Test validate reports missing exporters."""
        config = NativeOTELConfig(enabled=True)
        errors = config.validate()
        assert any("No exporters enabled" in error for error in errors)

    def test_validate_missing_kafka_config(self):
        """Test validate reports missing Kafka config."""
        config = NativeOTELConfig(enabled=True, enable_kafka=True)
        errors = config.validate()
        assert "Kafka export enabled but kafka_config not provided" in errors

    def test_validate_eventhub_not_configured(self):
        """Test validate reports unconfigured Event Hub."""
        config = NativeOTELConfig(enabled=True, enable_eventhub=True)
        errors = config.validate()
        assert any(
            "Event Hub export enabled but Event Hub not configured" in error
            for error in errors
        )

    def test_validate_missing_otlp_config(self):
        """Test validate reports missing OTLP config."""
        config = NativeOTELConfig(enabled=True, enable_otlp_grpc=True, otlp_config=None)
        errors = config.validate()
        assert "OTLP gRPC export enabled but no OTLP configuration provided" in errors

        config = NativeOTELConfig(enabled=True, enable_otlp_http=True, otlp_config=None)
        errors = config.validate()
        assert "OTLP HTTP export enabled but no OTLP configuration provided" in errors

    def test_validate_disabled_returns_no_errors(self):
        """Test validate returns empty list when disabled."""
        config = NativeOTELConfig(enabled=False, enable_kafka=True)
        errors = config.validate()
        assert errors == []

    def test_validate_eventhub_config_none(self):
        """Test validate reports missing Event Hub config."""
        config = NativeOTELConfig(
            enabled=True, enable_eventhub=True, event_hub_config=None
        )
        errors = config.validate()
        assert "Event Hub export enabled but event_hub_config not provided" in errors

    def test_validate_eventhub_configured_no_error(self):
        """Test validate does not report error when Event Hub is configured."""
        eventhub = EventHubConfig(connection_string="Endpoint=sb://test/")
        config = NativeOTELConfig(
            enabled=True, enable_eventhub=True, event_hub_config=eventhub
        )
        errors = config.validate()
        assert not any("Event Hub export enabled" in error for error in errors)


class TestPHIDetectionConfig:
    """Tests for PHIDetectionConfig."""

    def test_matches_with_word_boundaries(self):
        """Test matching with word boundaries enabled."""
        config = PHIDetectionConfig()
        assert config.matches("patient-record") is True
        assert config.matches("outpatient") is False

    def test_matches_without_word_boundaries(self):
        """Test matching without word boundaries."""
        config = PHIDetectionConfig(patterns=["patient"], use_word_boundaries=False)
        assert config.matches("outpatient") is True

    def test_matches_disabled(self):
        """Test matching when disabled."""
        config = PHIDetectionConfig(enabled=False)
        assert config.matches("patient-record") is False

    def test_add_and_remove_pattern(self):
        """Test adding and removing patterns."""
        config = PHIDetectionConfig(patterns=["phi"])
        config.add_pattern("ssn")
        assert config.matches("ssn") is True
        config.remove_pattern("phi")
        assert config.matches("phi") is False

    def test_add_pattern_existing_noop(self):
        """Test add_pattern is a no-op when pattern already present."""
        config = PHIDetectionConfig(patterns=["phi"])
        config.add_pattern("phi")
        assert config.patterns.count("phi") == 1

    def test_remove_pattern_missing_noop(self):
        """Test remove_pattern is a no-op when pattern missing."""
        config = PHIDetectionConfig(patterns=["phi"])
        config.remove_pattern("ssn")
        assert "phi" in config.patterns

    def test_empty_patterns_disable_matching(self):
        """Test empty patterns result in no compiled regex."""
        config = PHIDetectionConfig(patterns=[])
        assert config._compiled_pattern is None
        assert config.matches("phi") is False

    def test_from_env(self, monkeypatch):
        """Test PHIDetectionConfig.from_env."""
        monkeypatch.setenv("PHI_DETECTION_ENABLED", "false")
        monkeypatch.setenv("PHI_DETECTION_PATTERNS", "patient,ssn")
        monkeypatch.setenv("PHI_DETECTION_ATTRIBUTE", "phi_flag")
        monkeypatch.setenv("PHI_DETECTION_WORD_BOUNDARIES", "false")

        config = PHIDetectionConfig.from_env()

        assert config.enabled is False
        assert config.patterns == ["patient", "ssn"]
        assert config.attribute_flag == "phi_flag"
        assert config.use_word_boundaries is False


class TestLogLevel:
    """Tests for LogLevel enum."""

    def test_log_levels(self):
        """Test all log level values."""
        assert LogLevel.DEBUG.value == "debug"
        assert LogLevel.INFO.value == "info"
        assert LogLevel.WARNING.value == "warning"
        assert LogLevel.ERROR.value == "error"

    def test_log_level_from_string(self):
        """Test creating log level from string."""
        assert LogLevel("debug") == LogLevel.DEBUG
        assert LogLevel("info") == LogLevel.INFO
        assert LogLevel("warning") == LogLevel.WARNING
        assert LogLevel("error") == LogLevel.ERROR
