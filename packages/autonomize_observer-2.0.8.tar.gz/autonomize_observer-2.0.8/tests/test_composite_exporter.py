from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from autonomize_observer.exporters.otel.composite_exporter import CompositeSpanExporter
from autonomize_observer.exporters.base import BaseExporter, ExportResult


class SpanExportResultStub:
    SUCCESS = "success"
    FAILURE = "failure"


class ExporterBase:
    def __init__(
        self,
        result: str = SpanExportResultStub.SUCCESS,
        raise_on_export: bool = False,
        stats: dict | None = None,
        force_flush_result: bool = True,
        shutdown_error: Exception | None = None,
    ) -> None:
        self._result = result
        self._raise_on_export = raise_on_export
        self._stats = stats or {}
        self._force_flush_result = force_flush_result
        self._shutdown_error = shutdown_error
        self.export_calls = 0
        self.shutdown_calls = 0

    def export(self, spans):
        self.export_calls += 1
        if self._raise_on_export:
            raise RuntimeError("boom")
        return self._result

    def shutdown(self):
        self.shutdown_calls += 1
        if self._shutdown_error:
            raise self._shutdown_error

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self._force_flush_result

    @property
    def stats(self):
        return self._stats


class ExporterA(ExporterBase):
    pass


class ExporterB(ExporterBase):
    pass


class ExporterNoStats:
    def export(self, spans):
        return SpanExportResultStub.SUCCESS

    def shutdown(self):
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


@pytest.fixture
def patched_module():
    with patch(
        "autonomize_observer.exporters.otel.composite_exporter.NATIVE_OTEL_AVAILABLE",
        True,
    ), patch(
        "autonomize_observer.exporters.otel.composite_exporter.SpanExportResult",
        SpanExportResultStub,
    ):
        yield


def test_init_requires_native_otel():
    with patch(
        "autonomize_observer.exporters.otel.composite_exporter.NATIVE_OTEL_AVAILABLE",
        False,
    ):
        with pytest.raises(ImportError):
            CompositeSpanExporter([ExporterA()])


def test_init_requires_exporters(patched_module):
    with pytest.raises(ValueError):
        CompositeSpanExporter([])


def test_base_exporter_shutdown_resets_initialized():
    class DummyExporter(BaseExporter):
        def initialize(self) -> None:
            self._initialized = True

        def export_audit(self, audit_event) -> ExportResult:
            return ExportResult.ok()

        def flush(self, timeout: float = 5.0) -> int:
            return 0

    exporter = DummyExporter(name="dummy")
    exporter.initialize()
    assert exporter.is_initialized is True
    exporter.shutdown()
    assert exporter.is_initialized is False


def test_export_empty_returns_success(patched_module):
    composite = CompositeSpanExporter([ExporterA()])
    assert composite.export([]) == SpanExportResultStub.SUCCESS


def test_export_sequential_success(patched_module):
    composite = CompositeSpanExporter([ExporterA(), ExporterB()], parallel=False)
    result = composite.export([MagicMock()])
    assert result == SpanExportResultStub.SUCCESS
    assert composite.stats["export_attempts"] == 1
    assert composite.stats["export_successes"] == 1


def test_export_sequential_partial_failure_no_fail_fast(patched_module):
    composite = CompositeSpanExporter(
        [ExporterA(result=SpanExportResultStub.FAILURE), ExporterB()],
        parallel=False,
        fail_fast=False,
    )
    result = composite.export([MagicMock()])
    assert result == SpanExportResultStub.SUCCESS
    assert composite.stats["export_attempts"] == 1
    assert composite.stats["export_successes"] == 1


def test_export_sequential_fail_fast_stops(patched_module):
    exporter_a = ExporterA(result=SpanExportResultStub.FAILURE)
    exporter_b = ExporterB()
    composite = CompositeSpanExporter(
        [exporter_a, exporter_b],
        parallel=False,
        fail_fast=True,
    )
    result = composite.export([MagicMock()])
    assert result == SpanExportResultStub.FAILURE
    assert exporter_a.export_calls == 1
    assert exporter_b.export_calls == 0


def test_export_parallel_exception(patched_module):
    exporter_a = ExporterA(raise_on_export=True)
    exporter_b = ExporterB()
    composite = CompositeSpanExporter(
        [exporter_a, exporter_b],
        parallel=True,
        fail_fast=False,
    )
    result = composite.export([MagicMock()])
    assert result == SpanExportResultStub.SUCCESS


def test_export_parallel_fail_fast_on_failure(patched_module):
    exporter_a = ExporterA(result=SpanExportResultStub.FAILURE)
    exporter_b = ExporterB()
    exporter_b.export = MagicMock(
        side_effect=lambda spans: (
            __import__("time").sleep(0.01) or SpanExportResultStub.SUCCESS
        )
    )
    composite = CompositeSpanExporter(
        [exporter_a, exporter_b],
        parallel=True,
        fail_fast=True,
    )
    result = composite.export([MagicMock()])
    assert result == SpanExportResultStub.FAILURE


def test_export_parallel_fail_fast_on_exception(patched_module):
    exporter_a = ExporterA(raise_on_export=True)
    exporter_b = ExporterB()
    exporter_b.export = MagicMock(
        side_effect=lambda spans: (
            __import__("time").sleep(0.01) or SpanExportResultStub.SUCCESS
        )
    )
    composite = CompositeSpanExporter(
        [exporter_a, exporter_b],
        parallel=True,
        fail_fast=True,
    )
    result = composite.export([MagicMock()])
    assert result == SpanExportResultStub.FAILURE


def test_aggregate_results_empty(patched_module):
    composite = CompositeSpanExporter([ExporterA()], parallel=False)
    assert composite._aggregate_results([], []) == SpanExportResultStub.FAILURE


def test_aggregate_results_fail_fast_success(patched_module):
    composite = CompositeSpanExporter([ExporterA()], parallel=False, fail_fast=True)
    result = composite._aggregate_results([SpanExportResultStub.SUCCESS], [])
    assert result == SpanExportResultStub.SUCCESS


def test_aggregate_results_fail_fast_failure(patched_module):
    composite = CompositeSpanExporter([ExporterA()], parallel=False, fail_fast=True)
    result = composite._aggregate_results([SpanExportResultStub.FAILURE], ["err"])
    assert result == SpanExportResultStub.FAILURE


def test_aggregate_results_non_fail_fast_all_fail(patched_module):
    composite = CompositeSpanExporter([ExporterA()], parallel=False, fail_fast=False)
    result = composite._aggregate_results([SpanExportResultStub.FAILURE], ["err"])
    assert result == SpanExportResultStub.FAILURE


def test_force_flush_returns_false_if_any_fail(patched_module):
    composite = CompositeSpanExporter(
        [ExporterA(force_flush_result=True), ExporterB(force_flush_result=False)],
        parallel=False,
    )
    assert composite.force_flush() is False


def test_force_flush_handles_exception(patched_module):
    exporter_a = ExporterA(force_flush_result=True)
    exporter_b = ExporterB()
    exporter_b.force_flush = MagicMock(side_effect=RuntimeError("flush"))
    composite = CompositeSpanExporter([exporter_a, exporter_b], parallel=False)
    assert composite.force_flush() is False


def test_export_sequential_exception_fail_fast(patched_module):
    exporter_a = ExporterA(raise_on_export=True)
    exporter_b = ExporterB()
    composite = CompositeSpanExporter(
        [exporter_a, exporter_b],
        parallel=False,
        fail_fast=True,
    )
    result = composite.export([MagicMock()])
    assert result == SpanExportResultStub.FAILURE


def test_shutdown_calls_all_even_on_error(patched_module):
    exporter_a = ExporterA(shutdown_error=RuntimeError("shutdown"))
    exporter_b = ExporterB()
    composite = CompositeSpanExporter([exporter_a, exporter_b], parallel=False)
    composite.shutdown()
    assert exporter_a.shutdown_calls == 1
    assert exporter_b.shutdown_calls == 1


def test_stats_aggregates(patched_module):
    exporter_a = ExporterA(stats={"spans_exported": 2})
    exporter_b = ExporterB(stats={"spans_exported": 3})
    composite = CompositeSpanExporter([exporter_a, exporter_b], parallel=False)
    composite.export([MagicMock()])
    stats = composite.stats
    assert stats["export_attempts"] == 1
    assert stats["exporters"]["ExporterA"]["spans_exported"] == 2
    assert stats["exporters"]["ExporterB"]["spans_exported"] == 3
    assert composite.exporter_count == 2


def test_stats_skips_exporter_without_stats(patched_module):
    composite = CompositeSpanExporter([ExporterNoStats()], parallel=False)
    composite.export([MagicMock()])
    stats = composite.stats
    assert stats["exporters"] == {}
