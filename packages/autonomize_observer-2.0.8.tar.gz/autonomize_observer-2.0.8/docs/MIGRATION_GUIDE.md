# Migration Guide: Logfire to Dual SDK

This guide covers migrating from Logfire-only tracing to the dual SDK approach with `NativeOTELManager`.

## Overview

The `autonomize-observer` library now supports two tracing backends:

1. **Logfire** - Pydantic's hosted observability platform
2. **Native OTEL** - Direct OpenTelemetry SDK with Kafka/Event Hub/OTLP export

You can use either or both simultaneously.

## When to Use Each SDK

| Use Case | Recommended SDK |
|----------|-----------------|
| Local development with Logfire dashboard | Logfire (`init()`) |
| Production with Kafka/Event Hub export | Native OTEL (`NativeOTELManager`) |
| Both local debugging and production export | Both (dual SDK) |
| Services without LLM tracing needs | Native OTEL only |
| Services with OpenAI/Anthropic auto-instrumentation | Logfire (has built-in support) |

## Migration Steps

### Step 1: Update Dependencies

```bash
# Install native OTEL support
pip install autonomize-observer[native-otel]

# For Azure Event Hub export
pip install autonomize-observer[native-otel-all]

# For FastAPI native instrumentation
pip install autonomize-observer[fastapi-native]
```

### Step 2: Create NativeOTELManager

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig, ExporterType
from autonomize_observer.core.config import KafkaConfig

# Configure for Kafka export
config = NativeOTELConfig(
    enabled=True,
    service_name="my-service",
    service_version="1.0.0",
    environment="production",
    exporter_type=ExporterType.KAFKA,
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-traces",
    ),
    # Multi-tenancy
    organization_id="org-123",
    project_id="proj-456",
)

manager = NativeOTELManager(config=config)
```

### Step 3: Update FastAPI Setup

**Before (Logfire only):**
```python
from autonomize_observer.integrations import setup_fastapi

setup_fastapi(app, service_name="my-api")
```

**After (Native OTEL):**
```python
from autonomize_observer.integrations import setup_fastapi_native
from autonomize_observer.tracing import NativeOTELManager

manager = NativeOTELManager(config=config)
setup_fastapi_native(app, manager=manager, keycloak_enabled=True)
```

### Step 4: Update Span Creation

**Before (Logfire):**
```python
import logfire

with logfire.span("process-data"):
    result = process()
```

**After (Native OTEL):**
```python
with manager.span("process-data") as span:
    span.set_attribute("data.count", 100)
    result = process()

# Or use convenience methods
with manager.llm_span(provider="openai", model="gpt-4o") as span:
    response = openai.chat.completions.create(...)
```

### Step 5: Environment Variables

Configure via environment for production:

```bash
# Enable native OTEL
export NATIVE_OTEL_ENABLED=true
export SERVICE_NAME=my-service
export ENVIRONMENT=production

# Kafka export
export NATIVE_OTEL_EXPORTER=kafka
export KAFKA_BOOTSTRAP_SERVERS=kafka:9092
export KAFKA_TRACE_TOPIC=otel-traces

# Multi-tenancy (optional)
export ORGANIZATION_ID=org-123
export PROJECT_ID=proj-456
```

Then use:
```python
config = NativeOTELConfig.from_env()
manager = NativeOTELManager(config=config)
```

## Dual SDK Setup (Both Logfire + Native OTEL)

For services that need both local Logfire debugging and production Kafka export:

```python
from autonomize_observer import init
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig

# Initialize Logfire for local dev / LLM auto-instrumentation
init(
    service_name="my-service",
    send_to_logfire=False,  # Keep data local
    instrument_openai=True,
    instrument_anthropic=True,
)

# Initialize Native OTEL for production export
native_config = NativeOTELConfig.from_env()
native_manager = NativeOTELManager(config=native_config)

# Use either/both for spans
with native_manager.span("critical-operation") as span:
    # This span goes to Kafka/Event Hub
    pass
```

## ASGI Lifespan Integration

For proper shutdown handling in production:

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    config = NativeOTELConfig.from_env()
    manager = NativeOTELManager(config=config)
    app.state.otel_manager = manager

    yield

    # Shutdown - flush pending spans
    manager.force_flush(timeout_millis=5000)
    manager.shutdown()

app = FastAPI(lifespan=lifespan)
```

## PHI Routing

For HIPAA compliance, configure PHI routing to separate topics:

```python
from autonomize_observer.core.phi_config import PHIDetectionConfig

phi_config = PHIDetectionConfig(
    enabled=True,
    patterns=["patient", "ssn", "diagnosis", "prescription"],
    attribute_flag="contains_phi",
)

# Kafka with PHI routing
from autonomize_observer.exporters.otel import KafkaSpanExporter

exporter = KafkaSpanExporter(
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-traces",
        restricted_topic="otel-phi-traces",  # PHI spans go here
    ),
    phi_config=phi_config,
)
```

## Common Issues

### 1. "opentelemetry-sdk not installed"

Install the native OTEL dependencies:
```bash
pip install autonomize-observer[native-otel]
```

### 2. Spans not appearing in Kafka

Check that:
- `NATIVE_OTEL_ENABLED=true`
- Kafka bootstrap servers are reachable
- Topic exists or auto-creation is enabled

### 3. Signal handlers not working

Signal handlers only work in the main thread. For web servers with multiple workers, use ASGI lifespan events instead.

## Related Documentation

- [TRACING_AND_TOOLS.md](./TRACING_AND_TOOLS.md) - Distributed tracing patterns
- [AZURE_EVENTHUB_OTEL_IMPLEMENTATION.md](./AZURE_EVENTHUB_OTEL_IMPLEMENTATION.md) - Event Hub setup
- [SERVICE_INTEGRATION_MATRIX.md](./SERVICE_INTEGRATION_MATRIX.md) - Service recommendations
