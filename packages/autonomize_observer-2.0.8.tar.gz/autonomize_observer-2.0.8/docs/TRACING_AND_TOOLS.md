# Autonomize Observer - Comprehensive Tracing & Tools Documentation

A production-ready observability SDK built as a thin wrapper around Pydantic Logfire for tracing and genai-prices for LLM cost calculation. Provides specialized support for:

- **AI/LLM Tracing** - Agent and workflow tracing with automatic token extraction
- **Audit Logging** - Compliance-ready audit trails with GDPR, HIPAA, SOC2 support
- **Kafka Export** - Real-time event streaming
- **Langflow/AI Studio Integration** - First-class support for Langflow flows
- **Cost Calculation** - Automatic LLM cost tracking (28+ providers)

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [Agent Tracing](#agent-tracing)
3. [Workflow Tracing](#workflow-tracing)
4. [Audit Logging](#audit-logging)
5. [Cost Calculation](#cost-calculation)
6. [Langflow Integration](#langflow-integration)
7. [Configuration](#configuration)
8. [Data Models & Schemas](#data-models--schemas)
9. [Exporters](#exporters)
10. [Native OpenTelemetry SDK](#native-otel-manager-for-azure-event-hub--kafka-export)
11. [Distributed Tracing & Context Propagation](#distributed-tracing--context-propagation)
12. [Best Practices](#best-practices)

---

## Quick Start

### Installation

```bash
# Basic installation (Logfire optional)
pip install autonomize-observer

# With Native OTEL support (Kafka + Azure Event Hub)
pip install autonomize-observer[native-otel-all]

# With OTLP support
pip install autonomize-observer[otlp]

# Full installation (including Logfire and all exporters)
pip install autonomize-observer[all]
```

### Basic Initialization

```python
from autonomize_observer import init, KafkaConfig

# Minimal setup (local-only tracing, no Logfire unless installed)
init(service_name="my-service")

# With Kafka streaming (using Native OTEL)
init(
    service_name="my-service",
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        audit_topic="audit-events",
        trace_topic="genesis-traces-streaming",
    ),
    kafka_enabled=True,
)

# With Logfire cloud (requires 'logfire' installed)
init(
    service_name="my-service",
    send_to_logfire=True,
)
```

### From Environment Variables

```python
from autonomize_observer import configure, ObserverConfig

config = ObserverConfig.from_env()
configure(config)
```

---

## Agent Tracing

The `AgentTracer` is the primary tracer for AI/LLM applications, designed for Langflow and AI Studio flows with streaming capabilities.

### Import

```python
from autonomize_observer.tracing import AgentTracer
from uuid import uuid4
```

### Constructor Parameters

| Parameter                 | Type   | Default                      | Description               |
| ------------------------- | ------ | ---------------------------- | ------------------------- |
| `trace_name`              | `str`  | required                     | Name of the flow/trace    |
| `trace_id`                | `UUID` | required                     | Unique trace identifier   |
| `flow_id`                 | `str`  | required                     | Langflow flow identifier  |
| `project_name`            | `str`  | `"GenesisStudio"`            | Project context           |
| `user_id`                 | `str`  | `None`                       | User identifier           |
| `session_id`              | `str`  | `None`                       | Session identifier        |
| `enable_otel`             | `bool` | `False`                      | Enable OTEL span creation |
| `send_to_logfire`         | `bool` | `False`                      | Send to Logfire cloud     |
| `kafka_bootstrap_servers` | `str`  | `None`                       | Kafka brokers             |
| `kafka_topic`             | `str`  | `"genesis-traces-streaming"` | Kafka topic               |
| `kafka_username`          | `str`  | `None`                       | SASL username             |
| `kafka_password`          | `str`  | `None`                       | SASL password             |

### Basic Usage Example

```python
from autonomize_observer.tracing import AgentTracer
from uuid import uuid4

# Create tracer
tracer = AgentTracer(
    trace_name="Customer Support Bot",
    trace_id=uuid4(),
    flow_id="flow-support-v1",
    user_id="user-123",
    session_id="session-abc",
    enable_otel=True,
)

# Start the trace
tracer.start_trace()

# Add a component span (e.g., LLM call)
tracer.add_trace(
    trace_id="query-classifier",
    trace_name="QueryClassifier",
    trace_type="llm",
    inputs={"query": "How do I reset my password?"},
    metadata={"model": "gpt-4o"}
)

# Simulate LLM work...
result = {"classification": "account", "confidence": 0.95}

# End the component span
tracer.end_trace(
    trace_id="query-classifier",
    trace_name="QueryClassifier",
    outputs={
        "classification": "account",
        "model": "gpt-4o",
        "usage": {
            "prompt_tokens": 50,
            "completion_tokens": 10,
        }
    },
)

# End the entire trace
tracer.end(
    inputs={"query": "How do I reset my password?"},
    outputs={"response": "To reset your password, go to Settings..."},
)

# Cleanup
tracer.close()
```

### Expected Kafka Events

When using Kafka, the above example produces these events:

**1. trace_start event:**

```json
{
  "event_type": "trace_start",
  "trace_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "flow_id": "flow-support-v1",
  "flow_name": "Customer Support Bot",
  "user_id": "user-123",
  "session_id": "session-abc",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "project_name": "GenesisStudio"
}
```

**2. span_start event:**

```json
{
  "event_type": "span_start",
  "trace_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "span_id": "query-classifier",
  "component_name": "QueryClassifier",
  "component_type": "llm",
  "input_data": { "query": "How do I reset my password?" },
  "timestamp": "2024-01-15T10:30:00.100Z"
}
```

**3. span_end event:**

```json
{
  "event_type": "span_end",
  "trace_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "span_id": "query-classifier",
  "component_name": "QueryClassifier",
  "duration_ms": 1250,
  "output_data": { "classification": "account" },
  "model": "gpt-4o",
  "provider": "openai",
  "input_tokens": 50,
  "output_tokens": 10,
  "cost": 0.0009,
  "timestamp": "2024-01-15T10:30:01.350Z"
}
```

**4. trace_end event:**

```json
{
  "event_type": "trace_end",
  "trace_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "flow_name": "Customer Support Bot",
  "duration_ms": 1500,
  "total_input_tokens": 50,
  "total_output_tokens": 10,
  "total_cost": 0.0009,
  "input_data": { "query": "..." },
  "output_data": { "response": "..." },
  "timestamp": "2024-01-15T10:30:01.500Z"
}
```

### Multi-Component Flow Example

```python
from autonomize_observer.tracing import AgentTracer
from uuid import uuid4

tracer = AgentTracer(
    trace_name="RAG Pipeline",
    trace_id=uuid4(),
    flow_id="rag-v2",
    enable_otel=True,
    kafka_bootstrap_servers="localhost:9092",
)

tracer.start_trace()
tracer.add_tags(["production", "rag"])
tracer.log_param("retrieval_k", 5)

# Component 1: Embedding
tracer.add_trace(
    trace_id="embed-query",
    trace_name="QueryEmbedder",
    trace_type="embedding",
    inputs={"text": "What is machine learning?"},
)
# ... embedding work ...
tracer.end_trace(
    trace_id="embed-query",
    trace_name="QueryEmbedder",
    outputs={"embedding_dim": 1536, "model": "text-embedding-3-small"},
)

# Component 2: Retrieval
tracer.add_trace(
    trace_id="retrieve-docs",
    trace_name="VectorRetriever",
    trace_type="retrieval",
    inputs={"query_embedding": "[...]", "k": 5},
)
# ... retrieval work ...
tracer.end_trace(
    trace_id="retrieve-docs",
    trace_name="VectorRetriever",
    outputs={"documents_count": 5, "top_score": 0.92},
)

# Component 3: LLM Generation
tracer.add_trace(
    trace_id="generate-answer",
    trace_name="AnswerGenerator",
    trace_type="llm",
    inputs={"context": "[retrieved docs]", "question": "What is ML?"},
)
# ... LLM work ...
tracer.end_trace(
    trace_id="generate-answer",
    trace_name="AnswerGenerator",
    outputs={
        "answer": "Machine learning is...",
        "model": "gpt-4o",
        "usage": {"prompt_tokens": 500, "completion_tokens": 150},
    },
)

tracer.log_metric("total_documents_retrieved", 5)

# End trace
tracer.end(
    inputs={"question": "What is machine learning?"},
    outputs={"answer": "Machine learning is..."},
)
tracer.close()
```

### Automatic Token Extraction

The `AgentTracer` automatically extracts tokens from various LLM output formats:

**OpenAI Format:**

```python
outputs = {
    "usage": {
        "prompt_tokens": 100,
        "completion_tokens": 50,
    },
    "model": "gpt-4o"
}
```

**Anthropic Format:**

```python
outputs = {
    "usage": {
        "input_tokens": 100,
        "output_tokens": 50,
    },
    "model": "claude-3-5-sonnet"
}
```

**LangChain Format:**

```python
outputs = {
    "response_metadata": {
        "token_usage": {
            "prompt_tokens": 100,
            "completion_tokens": 50,
        },
        "model_name": "gpt-4o"
    }
}
```

**Direct Fields:**

```python
outputs = {
    "input_tokens": 100,
    "output_tokens": 50,
    "model": "gpt-4o"
}
```

---

## Workflow Tracing

The `WorkflowTracer` provides simple step-based tracing for general workflows (not just LLMs).

### Import

```python
from autonomize_observer.tracing import WorkflowTracer, trace_workflow
```

### Basic Usage with Context Manager

```python
from autonomize_observer.tracing import WorkflowTracer

with WorkflowTracer("order-processing", order_id="ORD-12345") as tracer:
    tracer.log("Starting order processing")

    with tracer.step("validate_order") as step:
        step.set("items_count", 5)
        step.set("total_amount", 299.99)
        # ... validation logic ...

    with tracer.step("process_payment") as step:
        step.set("payment_method", "credit_card")
        step.set("amount", 299.99)
        # ... payment logic ...

    with tracer.step("create_shipment") as step:
        step.set("carrier", "FedEx")
        step.set("estimated_delivery", "2024-01-20")
        # ... shipment logic ...

    summary = tracer.get_summary()
    print(f"Total duration: {summary['duration_ms']}ms")
```

### Expected Output (Summary)

```python
{
    "name": "order-processing",
    "status": "completed",  # or "failed" if any step errored
    "duration_ms": 1523.45,
    "attributes": {"order_id": "ORD-12345"},
    "steps": [
        {
            "name": "validate_order",
            "duration_ms": 45.2,
            "attributes": {"items_count": 5, "total_amount": 299.99},
            "error": None
        },
        {
            "name": "process_payment",
            "duration_ms": 1234.5,
            "attributes": {"payment_method": "credit_card", "amount": 299.99},
            "error": None
        },
        {
            "name": "create_shipment",
            "duration_ms": 243.75,
            "attributes": {"carrier": "FedEx", "estimated_delivery": "2024-01-20"},
            "error": None
        }
    ]
}
```

### Convenience Function

```python
from autonomize_observer.tracing import trace_workflow

with trace_workflow("data-pipeline", source="s3", destination="postgres") as tracer:
    with tracer.step("extract"):
        data = extract_from_s3()

    with tracer.step("transform"):
        transformed = transform_data(data)

    with tracer.step("load"):
        load_to_postgres(transformed)
```

### With Kafka Export

```python
from autonomize_observer.tracing import WorkflowTracer

with WorkflowTracer(
    "etl-pipeline",
    service_name="data-service",
    kafka_bootstrap_servers="localhost:9092",
    kafka_topic="workflow-traces",
    pipeline_id="ETL-001",
) as tracer:
    with tracer.step("extract"):
        tracer.log("Extracting from source")
        # ... extraction ...

    with tracer.step("transform"):
        tracer.log("Transforming data")
        # ... transformation ...

    with tracer.step("load"):
        tracer.log("Loading to destination")
        # ... loading ...
```

### Expected Kafka Events

**1. workflow_start:**

```json
{
  "event_type": "workflow_start",
  "workflow_name": "etl-pipeline",
  "attributes": { "pipeline_id": "ETL-001" },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**2. step_start (for each step):**

```json
{
  "event_type": "step_start",
  "workflow_name": "etl-pipeline",
  "step_name": "extract",
  "timestamp": "2024-01-15T10:30:00.100Z"
}
```

**3. step_end (for each step):**

```json
{
  "event_type": "step_end",
  "workflow_name": "etl-pipeline",
  "step_name": "extract",
  "duration_ms": 5432.1,
  "attributes": {},
  "error": null,
  "timestamp": "2024-01-15T10:30:05.532Z"
}
```

**4. workflow_end:**

```json
{
  "event_type": "workflow_end",
  "workflow_name": "etl-pipeline",
  "status": "completed",
  "duration_ms": 15678.9,
  "steps_count": 3,
  "timestamp": "2024-01-15T10:30:15.679Z"
}
```

### Error Handling

```python
from autonomize_observer.tracing import WorkflowTracer

with WorkflowTracer("risky-operation") as tracer:
    with tracer.step("setup"):
        # ... setup ...
        pass

    try:
        with tracer.step("risky_step") as step:
            step.set("attempt", 1)
            raise ValueError("Something went wrong")
    except ValueError:
        # Error is automatically captured in step metrics
        tracer.log("Risky step failed, continuing with fallback")

    with tracer.step("fallback"):
        # ... fallback logic ...
        pass

    summary = tracer.get_summary()
    # summary["steps"][1]["error"] will contain the error message
```

---

## Audit Logging

Compliance-ready audit logging with support for GDPR, HIPAA, SOC2, and PCI-DSS.

### Import

```python
from autonomize_observer import audit, ResourceType, ChangeRecord
from autonomize_observer.audit import AuditLogger
```

### CRUD Operations

```python
from autonomize_observer import audit, ResourceType, ChangeRecord

# Create
audit.log_create(
    resource_type=ResourceType.DOCUMENT,
    resource_id="doc-12345",
    resource_name="Project Proposal Q1",
    details={"author": "john.doe", "department": "Engineering"},
)

# Read
audit.log_read(
    resource_type=ResourceType.FILE,
    resource_id="file-67890",
    resource_name="financial-report.pdf",
)

# Update
audit.log_update(
    resource_type=ResourceType.USER,
    resource_id="user-456",
    resource_name="Jane Smith",
    changes=[
        ChangeRecord(
            field="email",
            old_value="jane.old@example.com",
            new_value="jane.new@example.com"
        ),
        ChangeRecord(
            field="role",
            old_value="viewer",
            new_value="editor"
        ),
    ],
)

# Delete
audit.log_delete(
    resource_type=ResourceType.FLOW,
    resource_id="flow-789",
    resource_name="Deprecated Pipeline",
    reason="No longer in use",
)
```

### Expected Audit Event

```json
{
  "event_id": "a1b2c3d4e5f67890",
  "event_category": "audit",
  "event_type": "resource_updated",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "timestamp_unix_nano": 1705315800000000000,
  "trace_id": null,
  "user_id": "user-current",
  "session_id": "session-abc",
  "project_name": "GenesisStudio",
  "service_name": "my-service",
  "action": "update",
  "resource_type": "user",
  "resource_id": "user-456",
  "resource_name": "Jane Smith",
  "outcome": "success",
  "severity": "medium",
  "changes": [
    {
      "field": "email",
      "old_value": "jane.old@example.com",
      "new_value": "jane.new@example.com"
    },
    {
      "field": "role",
      "old_value": "viewer",
      "new_value": "editor"
    }
  ],
  "attributes": {},
  "metadata": {},
  "tags": []
}
```

### Authentication Events

```python
# Successful login
audit.log_login(
    user_id="user-123",
    success=True,
    details={"ip": "192.168.1.100", "method": "oauth"},
)

# Failed login
audit.log_login(
    user_id="user-123",
    success=False,
    details={"reason": "invalid_password", "attempts": 3},
)

# Logout
audit.log_logout(user_id="user-123")
```

### LLM Interaction Logging

```python
audit.log_llm_interaction(
    flow_id="flow-support-v1",
    model="gpt-4o",
    provider="openai",
    input_tokens=150,
    output_tokens=75,
    cost=0.0025,
    details={
        "prompt_type": "customer_support",
        "classification": "account_inquiry",
    },
)
```

### Expected LLM Audit Event

```json
{
  "event_type": "llm_interaction",
  "flow_id": "flow-support-v1",
  "model": "gpt-4o",
  "provider": "openai",
  "input_tokens": 150,
  "output_tokens": 75,
  "total_tokens": 225,
  "cost": 0.0025,
  "details": {
    "prompt_type": "customer_support",
    "classification": "account_inquiry"
  }
}
```

### Custom Audit Events

```python
from autonomize_observer.audit.schemas import AuditEventType, AuditAction, AuditSeverity

audit.log(
    event_type=AuditEventType.SENSITIVE_DATA_ACCESS,
    action=AuditAction.READ,
    resource_type=ResourceType.DATABASE,
    resource_id="db-production",
    resource_name="customer_pii_table",
    severity=AuditSeverity.HIGH,
    details={"columns_accessed": ["ssn", "email", "phone"]},
    compliance_frameworks=["GDPR", "HIPAA"],
)
```

### Resource Types

| Resource Type | Description         |
| ------------- | ------------------- |
| `USER`        | User accounts       |
| `DOCUMENT`    | Documents           |
| `FILE`        | Files               |
| `DATABASE`    | Database resources  |
| `API`         | API endpoints       |
| `MODEL`       | ML/AI models        |
| `FLOW`        | Langflow flows      |
| `COMPONENT`   | Flow components     |
| `SECRET`      | Secrets/credentials |
| `PERMISSION`  | Permission grants   |

---

## Cost Calculation

Automatic LLM cost calculation supporting 28+ providers via the `genai-prices` library.

### Import

```python
from autonomize_observer import calculate_cost, get_price
from autonomize_observer.cost import PriceInfo, CostResult
```

### Get Pricing Information

```python
from autonomize_observer import get_price

# Get pricing for a model
price = get_price("openai", "gpt-4o")
if price:
    print(f"Provider: {price.provider}")
    print(f"Model: {price.model}")
    print(f"Input: ${price.input_price_per_token * 1000:.4f}/1K tokens")
    print(f"Output: ${price.output_price_per_token * 1000:.4f}/1K tokens")
```

### Expected Output

```
Provider: openai
Model: gpt-4o
Input: $0.0025/1K tokens
Output: $0.0100/1K tokens
```

### Calculate Cost

```python
from autonomize_observer import calculate_cost

result = calculate_cost(
    provider="openai",
    model="gpt-4o",
    input_tokens=1500,
    output_tokens=500,
)

print(f"Input tokens: {result.input_tokens}")
print(f"Output tokens: {result.output_tokens}")
print(f"Input cost: ${result.input_cost:.4f}")
print(f"Output cost: ${result.output_cost:.4f}")
print(f"Total cost: ${result.total_cost:.4f}")
print(f"Currency: {result.currency}")
```

### Expected Output

```
Input tokens: 1500
Output tokens: 500
Input cost: $0.0038
Output cost: $0.0050
Total cost: $0.0088
Currency: USD
```

### Supported Providers

| Provider        | Example Models                                   |
| --------------- | ------------------------------------------------ |
| `openai`        | gpt-4o, gpt-4-turbo, gpt-3.5-turbo               |
| `anthropic`     | claude-3-5-sonnet, claude-3-opus, claude-3-haiku |
| `google`        | gemini-1.5-pro, gemini-1.5-flash                 |
| `meta`          | llama-3.1-70b, llama-3.1-8b                      |
| `mistral`       | mistral-large, mixtral-8x7b                      |
| `cohere`        | command-r-plus, command-r                        |
| `ai21`          | jamba-1.5-large, jamba-1.5-mini                  |
| And 20+ more... |                                                  |

### Model Name Cleaning

The library automatically handles model name variations:

```python
from autonomize_observer.utils.model_utils import clean_model_name

# Azure OpenAI format
clean_model_name("azure/gpt-4o")  # Returns: "gpt-4o"

# Bedrock format
clean_model_name("bedrock/anthropic.claude-3-sonnet")  # Returns: "claude-3-sonnet"

# Version suffixes
clean_model_name("gpt-4o-2024-05-13")  # Returns: "gpt-4o"
```

---

## Langflow Integration

First-class integration with Langflow and AI Studio.

### Import

```python
from autonomize_observer.integrations.langflow import (
    trace_flow,
    trace_component,
    FlowTracer,
    FlowContext,
    get_flow_context,
    set_flow_context,
)
```

### Decorator-Based Tracing

```python
from autonomize_observer.integrations.langflow import trace_flow, trace_component

@trace_flow(
    flow_id="flow-customer-support",
    flow_name="Customer Support Bot",
    session_id="session-abc",
    user_id="user-123",
)
def run_support_flow(query: str) -> str:
    # Flow context is automatically set for child components
    classified = classify_query(query)
    response = generate_response(query, classified)
    return response

@trace_component("classifier", "QueryClassifier")
def classify_query(query: str) -> str:
    # This will be traced as a child span
    return "account_inquiry"

@trace_component("generator", "ResponseGenerator")
def generate_response(query: str, classification: str) -> str:
    # This will also be traced as a child span
    return "Here's how to reset your password..."
```

### Manual Tracing

```python
from autonomize_observer.integrations.langflow import FlowTracer

with FlowTracer(
    flow_id="flow-rag",
    flow_name="RAG Pipeline",
    user_id="user-123",
) as tracer:
    with tracer.component("embedder", "QueryEmbedder") as comp:
        comp.set("model", "text-embedding-3-small")
        embedding = get_embedding(query)

    with tracer.component("retriever", "VectorRetriever") as comp:
        comp.set("k", 5)
        docs = retrieve_documents(embedding)

    with tracer.component("generator", "LLMGenerator") as comp:
        comp.set("model", "gpt-4o")
        response = generate_answer(query, docs)
```

### Flow Context Access

```python
from autonomize_observer.integrations.langflow import get_flow_context, set_flow_context, FlowContext

# Get current flow context
ctx = get_flow_context()
if ctx:
    print(f"Flow ID: {ctx.flow_id}")
    print(f"User ID: {ctx.user_id}")

# Set flow context manually
set_flow_context(FlowContext(
    flow_id="custom-flow",
    flow_name="Custom Pipeline",
    user_id="user-456",
    metadata={"environment": "production"},
))
```

---

## Configuration

### KafkaConfig

```python
from autonomize_observer import KafkaConfig

config = KafkaConfig(
    # Connection
    bootstrap_servers="kafka1:9092,kafka2:9092",
    client_id="my-service",

    # Topics
    audit_topic="genesis-audit-events",
    trace_topic="genesis-traces-streaming",
    workflow_topic="workflow-traces",

    # Security (SASL)
    security_protocol="SASL_SSL",
    sasl_mechanism="SCRAM-SHA-256",
    sasl_username="user",
    sasl_password="password",

    # Performance
    linger_ms=5,
    batch_size=100,
    acks="all",
    retries=3,
)
```

### ObserverConfig

```python
from autonomize_observer import ObserverConfig, KafkaConfig, LogLevel

config = ObserverConfig(
    # Service identification
    service_name="my-service",
    service_version="1.0.0",
    environment="production",

    # Logfire settings
    send_to_logfire=True,

    # Kafka settings
    kafka=KafkaConfig(...),
    kafka_enabled=True,

    # Audit settings
    audit_enabled=True,
    audit_retention_days=365,

    # Logging
    log_level=LogLevel.INFO,
)
```

### NativeOTELConfig (Native OTEL SDK)

```python
from autonomize_observer.core.native_otel_config import (
    NativeOTELConfig,
    EventHubConfig,
)
from autonomize_observer.core.otlp_config import OTLPConfig

config = NativeOTELConfig(
    # Enable/disable
    enabled=True,

    # Service identification
    service_name="my-service",
    service_version="1.0.0",
    environment="production",

    # Exporter selection (Enable multiple simultaneously)
    enable_kafka=True,
    enable_eventhub=True,
    enable_otlp_grpc=True,
    enable_otlp_http=False,
    enable_console=False,

    # Kafka config (uses existing KafkaConfig)
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        security_protocol="SASL_SSL",
        sasl_mechanism="PLAIN",
    ),

    # Event Hub config
    event_hub_config=EventHubConfig(
        fully_qualified_namespace="myns.servicebus.windows.net",
        use_managed_identity=True,
    ),

    # OTLP config (Shared or Protocol-specific)
    otlp_grpc_config=OTLPConfig(endpoint="http://localhost:4317"),
    otlp_http_config=OTLPConfig(endpoint="http://localhost:4318/v1/traces"),

    # Semantic conventions
    genai_semantic_conventions=True,  # Transform to GenAI format

    # Batch processing
    batch_export=True,
    max_export_batch_size=512,
    schedule_delay_ms=5000,
    export_timeout_ms=30000,
)
```

### EventHubConfig

```python
from autonomize_observer.core.native_otel_config import EventHubConfig

config = EventHubConfig(
    # Authentication (choose one)
    connection_string="Endpoint=sb://...",  # OR
    fully_qualified_namespace="myns.servicebus.windows.net",
    use_managed_identity=True,

    # Event Hub names
    eventhub_name="ai-obs-comm-eh",
    restricted_eventhub_name="ai-obs-restricted-eh",  # For PHI

    # Application identifier
    usecase_id="LIS",
)
```

### Environment Variables

| Variable                         | Default                      | Description                       |
| -------------------------------- | ---------------------------- | --------------------------------- |
| `SERVICE_NAME`                   | `"autonomize-service"`       | Service name                      |
| `SERVICE_VERSION`                | `"1.0.0"`                    | Service version                   |
| `ENVIRONMENT`                    | `"production"`               | Environment                       |
| `NATIVE_OTEL_ENABLED`            | `"false"`                    | Enable Native OTEL SDK            |
| `NATIVE_OTEL_ENABLE_KAFKA`       | `"false"`                    | Enable Kafka span exporter        |
| `NATIVE_OTEL_ENABLE_EVENTHUB`    | `"false"`                    | Enable Event Hub span exporter    |
| `NATIVE_OTEL_ENABLE_OTLP_GRPC`   | `"false"`                    | Enable OTLP gRPC exporter         |
| `NATIVE_OTEL_ENABLE_OTLP_HTTP`   | `"false"`                    | Enable OTLP HTTP exporter         |
| `OTEL_EXPORTER_OTLP_ENDPOINT`    | `shared`                     | OTLP endpoint URL                 |
| `OTEL_EXPORTER_OTLP_COMPRESSION` | `"gzip"`                     | compression for OTLP (gzip, none) |
| `SEND_TO_LOGFIRE`                | `"false"`                    | Send to Logfire cloud             |
| `KAFKA_ENABLED`                  | `"true"`                     | Enable Kafka export               |
| `KAFKA_BOOTSTRAP_SERVERS`        | `"localhost:9092"`           | Kafka brokers                     |
| `KAFKA_AUDIT_TOPIC`              | `"genesis-audit-events"`     | Audit events topic                |
| `KAFKA_TRACE_TOPIC`              | `"genesis-traces-streaming"` | Trace events topic                |
| `KAFKA_SECURITY_PROTOCOL`        | -                            | `"SASL_SSL"`, etc.                |
| `KAFKA_SASL_MECHANISM`           | -                            | `"PLAIN"`, `"SCRAM-SHA-256"`      |
| `KAFKA_SASL_USERNAME`            | -                            | SASL username                     |
| `KAFKA_SASL_PASSWORD`            | -                            | SASL password                     |
| `AUDIT_ENABLED`                  | `"true"`                     | Enable audit logging              |
| `AUDIT_RETENTION_DAYS`           | `"365"`                      | Audit retention period            |
| `LOG_LEVEL`                      | `"info"`                     | Logging level                     |
| `NATIVE_OTEL_ENABLED`            | `"false"`                    | Enable native OTEL SDK            |
| `NATIVE_OTEL_EXPORTER`           | `"kafka"`                    | `kafka`, `eventhub`, or `both`    |
| `NATIVE_OTEL_GENAI_CONVENTIONS`  | `"true"`                     | Use GenAI semantic conventions    |
| `AZURE_EVENTHUB_NAMESPACE`       | -                            | Event Hub namespace               |
| `AZURE_EVENTHUB_NAME`            | `"otel-traces"`              | Event Hub name                    |
| `AZURE_EVENTHUB_RESTRICTED_NAME` | -                            | Restricted Event Hub for PHI      |
| `AZURE_USE_MANAGED_IDENTITY`     | `"false"`                    | Use Azure managed identity        |
| `AZURE_EVENTHUB_USECASE_ID`      | -                            | Application ID                    |

---

## Data Models & Schemas

### BaseEvent

All events inherit from `BaseEvent`:

```python
{
    # Event Identity
    "event_id": "a1b2c3d4e5f67890",  # 16 hex chars
    "event_category": "trace",  # trace, audit, system, metric
    "event_type": "span_end",
    "timestamp": "2024-01-15T10:30:00.000Z",
    "timestamp_unix_nano": 1705315800000000000,

    # Correlation (W3C TraceContext)
    "trace_id": "abcd1234abcd1234abcd1234abcd1234",  # 32 hex chars
    "span_id": "1234abcd1234abcd",  # 16 hex chars
    "parent_span_id": null,
    "correlation_id": null,

    # Context
    "user_id": "user-123",
    "session_id": "session-abc",
    "project_name": "GenesisStudio",
    "environment": "production",

    # Source
    "service_name": "my-service",
    "service_version": "1.0.0",
    "source_ip": "192.168.1.100",
    "user_agent": null,

    # Extensibility
    "attributes": {},
    "metadata": {},
    "tags": ["production", "rag"]
}
```

### TraceEvent (Streaming)

Extended schema for Kafka streaming:

```python
{
    # All BaseEvent fields plus:
    "flow_id": "flow-support-v1",
    "flow_name": "Customer Support Bot",
    "component_name": "QueryClassifier",
    "component_type": "llm",
    "component_index": 0,
    "duration_ms": 1250.5,
    "input_data": {"query": "..."},
    "output_data": {"classification": "..."},
    "error": null,

    # LLM-specific (for span_end)
    "model": "gpt-4o",
    "provider": "openai",
    "input_tokens": 50,
    "output_tokens": 10,
    "cost": 0.0009
}
```

### Event Categories

| Category | Description                         |
| -------- | ----------------------------------- |
| `TRACE`  | OTEL traces/spans for observability |
| `AUDIT`  | User/system actions for compliance  |
| `SYSTEM` | Internal system events              |
| `METRIC` | Aggregated metrics                  |

### Streaming Event Types

| Event Type       | Description                   |
| ---------------- | ----------------------------- |
| `TRACE_START`    | Beginning of a trace/flow     |
| `TRACE_END`      | End of a trace/flow           |
| `SPAN_START`     | Beginning of a component span |
| `SPAN_END`       | End of a component span       |
| `LLM_CALL_START` | LLM API call started          |
| `LLM_CALL_END`   | LLM API call completed        |
| `CUSTOM`         | Custom events                 |

---

## Exporters

### Kafka Exporter

```python
from autonomize_observer.exporters import KafkaExporter
from autonomize_observer import KafkaConfig

exporter = KafkaExporter(
    config=KafkaConfig(
        bootstrap_servers="localhost:9092",
        audit_topic="audit-events",
    ),
)

exporter.initialize()

# Export audit events
result = exporter.export_audit(audit_event)
if result.success:
    print(f"Exported {result.events_exported} events")
else:
    print(f"Export failed: {result.message}")

# Flush pending messages
exporter.flush(timeout=5.0)

# Cleanup
exporter.shutdown()
```

### OTEL Manager (Logfire-based)

```python
from autonomize_observer.tracing import OTELManager

otel = OTELManager(
    service_name="my-service",
    send_to_logfire=True,
)

# Create spans
with otel.span("my-operation", tags=["important"]) as span:
    otel.set_span_attribute(span, "key", "value")
    # ... do work ...

# Manual span management
span = otel.start_span("manual-operation")
try:
    # ... do work ...
except Exception as e:
    otel.end_span(span, error=e)
    raise
else:
    otel.end_span(span)

# Logging
otel.log_info("Operation completed", count=5)
otel.log_warning("Slow query detected", duration_ms=5000)
otel.log_error("Operation failed", error="Connection timeout")
```

### Native OTEL Manager (for Azure Event Hub / Kafka Export)

The `NativeOTELManager` provides native OpenTelemetry SDK integration as a **parallel option** alongside the Logfire-based implementation. It supports dual export to Kafka and/or Azure Event Hub.

**Installation:**

```bash
# Native OTEL with Kafka export only
pip install autonomize-observer[native-otel]

# Native OTEL with Azure Event Hub
pip install autonomize-observer[azure]

# Full native OTEL features (Kafka + Azure)
pip install autonomize-observer[native-otel-all]
```

**Basic Usage with Kafka:**

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig, ExporterType
from autonomize_observer import KafkaConfig

config = NativeOTELConfig(
    enabled=True,
    service_name="my-llm-service",
    enable_kafka=True,
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-genai-traces",
        security_protocol="SASL_SSL",  # Optional: for secure connections
    ),
)

manager = NativeOTELManager(config=config)

# Create spans with GenAI semantic conventions
with manager.llm_span(
    provider="openai",
    model="gpt-4o",
) as span:
    response = openai_client.chat.completions.create(...)
    span.set_attribute("gen_ai.usage.input_tokens", response.usage.prompt_tokens)
    span.set_attribute("gen_ai.usage.output_tokens", response.usage.completion_tokens)
```

**Azure Event Hub Export:**

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import (
    NativeOTELConfig,
    EventHubConfig,
    ExporterType,
)

config = NativeOTELConfig(
    enabled=True,
    service_name="my-azure-service",
    enable_eventhub=True,
    event_hub_config=EventHubConfig(
        fully_qualified_namespace="ai-obs-ehn-prod.servicebus.windows.net",
        eventhub_name="ai-obs-comm-eh",
        restricted_eventhub_name="ai-obs-restricted-eh",  # For PHI data
        use_managed_identity=True,
        usecase_id="LIS",  # Application identifier
    ),
)

manager = NativeOTELManager(config=config)
```

**Dual Export (Kafka + Azure Event Hub):**

```python
config = NativeOTELConfig(
    enabled=True,
    service_name="my-multi-cloud-service",
    enable_kafka=True,
    enable_eventhub=True,
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-traces",
    ),
    event_hub_config=EventHubConfig(
        connection_string="Endpoint=sb://...",
        eventhub_name="otel-traces",
        usecase_id="AgentSpark",
    ),
)

manager = NativeOTELManager(config=config)

# All spans exported to BOTH Kafka and Azure Event Hub
with manager.span("my-operation") as span:
    do_work()
```

**Convenience Methods for LLM Tracing:**

```python
# LLM span with automatic GenAI attributes
with manager.llm_span(
    operation="chat",
    provider="openai",
    model="gpt-4o",
    input_tokens=150,
) as span:
    response = llm.chat(...)
    span.set_attribute("gen_ai.usage.output_tokens", 500)

# Tool/function call span
with manager.tool_span(
    tool_name="get_weather",
    tool_call_id="call_123",
    arguments={"city": "NYC"},
) as span:
    result = get_weather("NYC")
    span.set_attribute("gen_ai.tool.call.result", str(result))

# Agent invocation span
with manager.agent_span(
    agent_name="CustomerSupportAgent",
    agent_id="agent_456",
    model="gpt-4o",
    provider="openai",
) as span:
    response = agent.run(query)
```

**GenAI Semantic Conventions:**

The Native OTEL Manager follows [OpenTelemetry GenAI Semantic Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/):

```python
from autonomize_observer.schemas import (
    GenAIAttributes,
    create_genai_attributes,
)

# Create attributes programmatically
attrs = create_genai_attributes(
    operation="chat",
    provider="openai",
    model="gpt-4o",
    input_tokens=150,
    output_tokens=500,
)

# Or use attribute constants directly
with manager.span("llm-call") as span:
    span.set_attribute(GenAIAttributes.OPERATION_NAME, "chat")
    span.set_attribute(GenAIAttributes.PROVIDER_NAME, "openai")
    span.set_attribute(GenAIAttributes.REQUEST_MODEL, "gpt-4o")
    span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, 150)
    span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, 500)
```

**Expected Event Format:**

```json
{
  "usecase_id": "LIS",
  "CTxID": "LIS-9f04c0b6029b4f2f9bc4d9dba7e3db9b",
  "context": {
    "trace_id": "9f04c0b6029b4f2f9bc4d9dba7e3db9b",
    "span_id": "b6c4b1ac5f3b4d5a"
  },
  "parent_id": "98b4fe4392f54681",
  "name": "chat gpt-4o",
  "status": { "code": 1, "message": null },
  "start_time": "2025-12-15T10:23:45Z",
  "end_time": "2025-12-15T10:23:45.8Z",
  "application_type": "gen_ai",
  "attributes": {
    "gen_ai.operation.name": "chat",
    "gen_ai.provider.name": "openai",
    "gen_ai.request.model": "gpt-4o",
    "gen_ai.usage.input_tokens": 150,
    "gen_ai.usage.output_tokens": 500
  }
}
```

**PHI Routing:**

Spans containing PHI are automatically routed to the restricted Event Hub:

```python
with manager.span("process-member-data") as span:
    span.set_attribute("contains_phi", True)  # Routes to restricted EH
    process_sensitive_data()
```

**Using Both Logfire AND Native OTEL:**

```python
from autonomize_observer.tracing import OTELManager, NativeOTELManager

# Logfire for local dev/debugging
logfire_manager = OTELManager(
    service_name="my-service",
    send_to_logfire=True,
)

# Native OTEL for production export
native_manager = NativeOTELManager(config=native_config)

# Use Logfire for general tracing
with logfire_manager.span("debug-operation"):
    debug_work()

# Use Native OTEL for LLM operations
with native_manager.llm_span(provider="openai", model="gpt-4o") as span:
    llm_call()
```

---

## Distributed Pipeline Tracing (Multi-Service)

For pipelines spanning multiple services/repos communicating via Kafka, propagate trace context through Kafka message headers to create a unified trace.

### Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Single Trace (trace_id: abc123)             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Service A (Orchestrator)                                           │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ Span: data-pipeline (root span)                              │   │
│  │   └── Produces to Kafka with traceparent header              │   │
│  └─────────────────────────────────────────────────────────────┘   │
│           │                              │                          │
│           ▼                              ▼                          │
│  ┌────────────────────┐        ┌────────────────────┐              │
│  │ service-b-input    │        │ service-c-input    │   (Kafka)    │
│  └────────────────────┘        └────────────────────┘              │
│           │                              │                          │
│           ▼                              ▼                          │
│  Service B (Processor)          Service C (Embedder)               │
│  ┌──────────────────────┐      ┌──────────────────────┐            │
│  │ Span: process-data   │      │ Span: gen-embeddings │            │
│  │   └── llm_span: chat │      │   └── llm_span: embed│            │
│  └──────────────────────┘      └──────────────────────┘            │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Service A: Pipeline Orchestrator (Producer)

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig, ExporterType
from autonomize_observer import KafkaConfig
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
from opentelemetry.trace import SpanKind
from confluent_kafka import Producer
import json

# Setup - all services export to same trace topic
config = NativeOTELConfig(
    enabled=True,
    service_name="pipeline-orchestrator",
    exporter_type=ExporterType.KAFKA,
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-traces",  # Same topic for all services
    ),
)
manager = NativeOTELManager(config=config)
propagator = TraceContextTextMapPropagator()

producer = Producer({"bootstrap.servers": "kafka:9092"})

def start_pipeline(data: dict):
    # Root span for entire pipeline
    with manager.span("data-pipeline", kind=SpanKind.PRODUCER) as pipeline_span:
        pipeline_span.set_attribute("pipeline.name", "etl-pipeline")
        pipeline_span.set_attribute("pipeline.version", "v2")

        # Inject trace context into headers (W3C TraceContext format)
        carrier = {}
        propagator.inject(carrier)

        # Convert to Kafka header format: list of (key, bytes) tuples
        kafka_headers = [(k, v.encode("utf-8")) for k, v in carrier.items()]

        # Send to downstream services
        producer.produce(
            topic="service-b-input",
            value=json.dumps(data).encode(),
            headers=kafka_headers,
        )

        producer.produce(
            topic="service-c-input",
            value=json.dumps(data).encode(),
            headers=kafka_headers,
        )

        producer.flush()
        pipeline_span.set_attribute("messages.sent", 2)

# Start the pipeline
start_pipeline({"query": "What is machine learning?", "user_id": "user-123"})
```

### Service B: Processor (Consumer)

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig, ExporterType
from autonomize_observer import KafkaConfig
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
from opentelemetry.trace import SpanKind
from opentelemetry import trace
from confluent_kafka import Consumer
import json

# Setup - same trace topic, different service name
config = NativeOTELConfig(
    enabled=True,
    service_name="service-b-processor",  # Unique service name
    exporter_type=ExporterType.KAFKA,
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-traces",  # Same topic
    ),
)
manager = NativeOTELManager(config=config)
propagator = TraceContextTextMapPropagator()

consumer = Consumer({
    "bootstrap.servers": "kafka:9092",
    "group.id": "service-b-group",
    "auto.offset.reset": "earliest",
})
consumer.subscribe(["service-b-input"])

def process_messages():
    while True:
        msg = consumer.poll(1.0)
        if msg is None:
            continue
        if msg.error():
            continue

        # Extract trace context from Kafka headers
        headers = {k: v.decode("utf-8") for k, v in (msg.headers() or [])}

        # Restore parent trace context
        parent_ctx = propagator.extract(carrier=headers)

        # Create child span linked to parent trace
        with manager.tracer.start_as_current_span(
            "process-data",
            context=parent_ctx,
            kind=SpanKind.CONSUMER,
        ) as span:
            span.set_attribute("messaging.system", "kafka")
            span.set_attribute("messaging.destination", "service-b-input")
            span.set_attribute("messaging.operation", "receive")

            # Parse and process data
            data = json.loads(msg.value())
            span.set_attribute("data.user_id", data.get("user_id"))

            # Nested LLM call (automatically child of current span)
            with manager.llm_span(
                provider="openai",
                model="gpt-4o",
                operation="chat",
            ) as llm_span:
                # Call LLM
                response = call_openai(data["query"])
                llm_span.set_attribute("gen_ai.usage.input_tokens", 150)
                llm_span.set_attribute("gen_ai.usage.output_tokens", 200)

            span.set_attribute("processing.status", "success")

process_messages()
```

### Service C: Embedder (Another Consumer)

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig, ExporterType
from autonomize_observer import KafkaConfig
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
from opentelemetry.trace import SpanKind
from confluent_kafka import Consumer
import json

# Setup
config = NativeOTELConfig(
    enabled=True,
    service_name="service-c-embedder",  # Unique service name
    exporter_type=ExporterType.KAFKA,
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-traces",
    ),
)
manager = NativeOTELManager(config=config)
propagator = TraceContextTextMapPropagator()

consumer = Consumer({
    "bootstrap.servers": "kafka:9092",
    "group.id": "service-c-group",
    "auto.offset.reset": "earliest",
})
consumer.subscribe(["service-c-input"])

def process_embedding_requests():
    while True:
        msg = consumer.poll(1.0)
        if msg is None:
            continue

        # Extract parent context from headers
        headers = {k: v.decode("utf-8") for k, v in (msg.headers() or [])}
        parent_ctx = propagator.extract(carrier=headers)

        with manager.tracer.start_as_current_span(
            "generate-embeddings",
            context=parent_ctx,
            kind=SpanKind.CONSUMER,
        ) as span:
            data = json.loads(msg.value())

            # Embedding LLM call
            with manager.llm_span(
                operation="embeddings",
                provider="openai",
                model="text-embedding-3-small",
            ) as embed_span:
                embeddings = get_embeddings(data["query"])
                embed_span.set_attribute("gen_ai.usage.input_tokens", 50)
                embed_span.set_attribute("embedding.dimensions", 1536)

            span.set_attribute("vectors.generated", len(embeddings))

process_embedding_requests()
```

### Resulting Unified Trace

All spans share the same `trace_id` and form a parent-child hierarchy:

```
Trace ID: abc123def456789012345678abcdef12
│
├── data-pipeline (service: pipeline-orchestrator, span_id: 001)
│   │   Attributes:
│   │     - pipeline.name: "etl-pipeline"
│   │     - messages.sent: 2
│   │
│   ├── process-data (service: service-b-processor, span_id: 002, parent: 001)
│   │   │   Attributes:
│   │   │     - messaging.system: "kafka"
│   │   │     - messaging.destination: "service-b-input"
│   │   │
│   │   └── chat gpt-4o (span_id: 003, parent: 002)
│   │           Attributes:
│   │             - gen_ai.operation.name: "chat"
│   │             - gen_ai.usage.input_tokens: 150
│   │             - gen_ai.usage.output_tokens: 200
│   │
│   └── generate-embeddings (service: service-c-embedder, span_id: 004, parent: 001)
│       │   Attributes:
│       │     - messaging.system: "kafka"
│       │     - vectors.generated: 1
│       │
│       └── embeddings text-embedding-3-small (span_id: 005, parent: 004)
│               Attributes:
│                 - gen_ai.operation.name: "embeddings"
│                 - gen_ai.usage.input_tokens: 50
```

### Kafka Message Format

```
Topic: service-b-input
Headers:
  traceparent: "00-abc123def456789012345678abcdef12-001a2b3c4d5e6f78-01"
  tracestate: ""
Value: {"query": "What is machine learning?", "user_id": "user-123"}
```

### Key Points for Distributed Tracing

| Requirement                | How to Achieve                                   |
| -------------------------- | ------------------------------------------------ |
| Same trace across services | Pass `traceparent` header via Kafka              |
| Parent-child relationship  | Use `propagator.extract()` to restore context    |
| Different service names    | Each service has unique `service_name` in config |
| Same trace destination     | All services export to same `trace_topic`        |
| Nested spans               | Create spans within the extracted context        |

### Helper: Traced Kafka Consumer

```python
from contextlib import contextmanager
from typing import Generator, Tuple, Any

@contextmanager
def consume_with_trace(
    manager: NativeOTELManager,
    consumer: Consumer,
    span_name: str,
    timeout: float = 1.0,
) -> Generator[Tuple[Any, Any], None, None]:
    """Consume Kafka message with automatic trace context restoration."""
    msg = consumer.poll(timeout)

    if msg is None or msg.error():
        yield None, None
        return

    # Extract trace context from headers
    headers = {k: v.decode("utf-8") for k, v in (msg.headers() or [])}
    parent_ctx = TraceContextTextMapPropagator().extract(carrier=headers)

    # Create child span
    with manager.tracer.start_as_current_span(
        span_name,
        context=parent_ctx,
        kind=SpanKind.CONSUMER,
    ) as span:
        span.set_attribute("messaging.system", "kafka")
        yield msg, span

# Usage
with consume_with_trace(manager, consumer, "process-data") as (msg, span):
    if msg:
        data = json.loads(msg.value())
        span.set_attribute("records.count", len(data))
        process(data)
```

---

## Distributed Tracing & Context Propagation

The library provides built-in support for propagating trace context across service boundaries (e.g., via HTTP headers or Kafka messages).

### Import

```python
from autonomize_observer.tracing.propagation import (
    inject_trace_context,
    extract_trace_context,
    consume_with_trace,
)
```

### Injecting Context (Producer)

When a service makes an outbound call or produces a message, inject the current trace context:

```python
# Create headers dictionary with traceparent
headers = inject_trace_context()

# HTTP Request
requests.post(url, headers=headers)

# Kafka Message
producer.produce(topic, value=data, headers=dict_to_kafka_headers(headers))
```

### Extracting Context (Consumer)

When a service receives a request or message, extract the context to continue the trace:

```python
# HTTP Handler (e.g., FastAPI)
def handle_request(request):
    parent_ctx = extract_trace_context(request.headers)

    with tracer.start_as_current_span("handle_request", context=parent_ctx):
        # ... processing ...
```

### Kafka Consumer Helper

A convenience context manager `consume_with_trace` automates context extraction and span creation for Kafka consumers:

```python
from autonomize_observer.tracing.propagation import consume_with_trace

while True:
    # Automatically extracts context from headers and starts a 'consumer' span
    with consume_with_trace(
        manager=native_otel_manager,
        consumer=kafka_consumer,
        span_name="process_message",
        timeout=1.0,
    ) as (msg, span):

        if msg is None:
            continue

        # Add attributes to the span
        span.set_attribute("message.offset", msg.offset())

        # Process the message
        process(msg.value())
```

### Organization Context

The library automatically propagates organization and project identifiers via span resource attributes. This ensures that all traces are correctly attributed in multi-tenant environments.

Ensure these are configured during initialization:

```python
config = NativeOTELConfig(
    # ...
    organization_id="org-123",
    project_id="proj-456",
)
```

---

## Best Practices

### 1. Always Close Tracers

```python
tracer = AgentTracer(...)
try:
    tracer.start_trace()
    # ... work ...
    tracer.end(inputs={...}, outputs={...})
finally:
    tracer.close()  # Ensures Kafka flush and cleanup
```

Or use context managers:

```python
with WorkflowTracer("my-workflow") as tracer:
    # Automatic cleanup on exit
    pass
```

### 2. Use Meaningful Trace Names

```python
# Good
tracer = AgentTracer(trace_name="Customer Support Query Classification")

# Bad
tracer = AgentTracer(trace_name="flow1")
```

### 3. Add Tags and Metadata

```python
tracer.add_tags(["production", "high-priority", "customer-facing"])
tracer.log_param("model_version", "v2.1")
tracer.log_param("retrieval_k", 5)
tracer.log_metric("documents_retrieved", 10)
```

### 4. Handle Errors Gracefully

```python
tracer.add_trace(trace_id="component-1", ...)
try:
    result = do_work()
    tracer.end_trace(trace_id="component-1", outputs=result)
except Exception as e:
    tracer.end_trace(
        trace_id="component-1",
        outputs={},
        error=str(e),
    )
    raise
```

### 5. Use Environment Variables for Configuration

```bash
export KAFKA_BOOTSTRAP_SERVERS="kafka:9092"
export KAFKA_SASL_USERNAME="myuser"
export KAFKA_SASL_PASSWORD="mypassword"
export SEND_TO_LOGFIRE="true"
```

```python
from autonomize_observer import configure, ObserverConfig

configure(ObserverConfig.from_env())
```

### 6. Include Cost Tracking for LLM Flows

The `AgentTracer` automatically calculates costs when token usage is available. Ensure your LLM outputs include token counts:

```python
tracer.end_trace(
    trace_id="llm-call",
    trace_name="LLMComponent",
    outputs={
        "response": "...",
        "model": "gpt-4o",
        "usage": {
            "prompt_tokens": 500,
            "completion_tokens": 150,
        }
    },
)
```

### 7. Use Compliance Tags for Audit Logs

```python
audit.log(
    event_type=AuditEventType.SENSITIVE_DATA_ACCESS,
    resource_type=ResourceType.DATABASE,
    resource_id="customer-pii",
    compliance_frameworks=["GDPR", "HIPAA"],
    severity=AuditSeverity.HIGH,
)
```

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Application Code                          │
├─────────────────────────────────────────────────────────────┤
│  AgentTracer │ WorkflowTracer │ AuditLogger │ Decorators    │
├─────────────────────────────────────────────────────────────┤
│                   Token Extractors                           │
│   (OpenAI, Anthropic, LangChain, Direct Fields)             │
├─────────────────────────────────────────────────────────────┤
│                   Cost Calculator                            │
│              (genai-prices - 28+ providers)                  │
├─────────────────────┬───────────────────────────────────────┤
│   OTELManager       │        NativeOTELManager              │
│  (Logfire-based)    │      (Native OTEL SDK)                │
│  [EXISTING]         │          [NEW]                        │
├─────────────────────┼───────────────────────────────────────┤
│  Pydantic Logfire   │  ┌─────────────┬─────────────────┐   │
│                     │  │KafkaSpan    │EventHubSpan     │   │
│                     │  │Exporter     │Exporter         │   │
│                     │  └─────────────┴─────────────────┘   │
├─────────────────────┼───────────────────────────────────────┤
│  Logfire Cloud      │  Kafka        │  Azure Event Hub     │
│  (Optional)         │  Topics       │  ai-obs-comm-eh      │
│                     │               │  ai-obs-restricted-eh│
└─────────────────────┴───────────────┴──────────────────────┘
```

### When to Use Which SDK

| Use Case                        | Recommended SDK                           |
| ------------------------------- | ----------------------------------------- |
| Local development/debugging     | OTELManager (Logfire)                     |
| Production with Kafka           | NativeOTELManager + KafkaSpanExporter     |
| Production with Azure Event Hub | NativeOTELManager + EventHubSpanExporter  |
| Dual export (Kafka + Event Hub) | NativeOTELManager + CompositeSpanExporter |
| Legacy AI Studio integration    | OTELManager (Logfire)                     |
| Enterprise/Healthcare           | NativeOTELManager                         |

---

## Graceful Degradation

The library gracefully degrades when optional dependencies are unavailable:

| Dependency          | When Missing                                           |
| ------------------- | ------------------------------------------------------ |
| `logfire`           | OTEL spans disabled for OTELManager, local-only mode   |
| `confluent-kafka`   | Kafka export disabled, events logged locally           |
| `genai-prices`      | Cost calculation returns "unknown" provider            |
| `opentelemetry-sdk` | NativeOTELManager unavailable, use OTELManager instead |
| `azure-eventhub`    | Azure Event Hub export disabled                        |
| `azure-identity`    | Managed identity auth unavailable for Event Hub        |

This means you can use the library without any external services during development and enable them in production.

### Checking Dependency Availability

```python
from autonomize_observer.core.imports import (
    NATIVE_OTEL_AVAILABLE,
    AZURE_EVENTHUB_AVAILABLE,
    check_native_otel_available,
    check_azure_eventhub_available,
)

# Check at import time
if NATIVE_OTEL_AVAILABLE:
    from autonomize_observer.tracing import NativeOTELManager
    # Use native OTEL

# Or check with functions
if check_azure_eventhub_available():
    from autonomize_observer.exporters.otel import EventHubSpanExporter
    # Use Event Hub export
```
