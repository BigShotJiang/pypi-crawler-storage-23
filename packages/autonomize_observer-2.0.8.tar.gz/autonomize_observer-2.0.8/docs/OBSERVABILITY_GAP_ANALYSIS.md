# Observability Plan — Gap Analysis

> **Reviewer**: AI Platform Code Review
> **Date**: 2026-02-13
> **Scope**: `autonomize-observer` docs, implementation, and multi-service readiness
> **Branch**: `feature/native-otel-sdk`
> **Status**: Review Complete — 12 gaps identified

---

## Executive Summary

The `autonomize-observer` library has a solid foundation: dual-SDK architecture (Logfire + Native OTEL), clean optional-dependency management, GenAI semantic conventions, and Event Hub PHI routing. However, **12 gaps** were identified that affect multi-service adoption, platform compliance, and production readiness.

**Critical path for multi-service adoption:**
1. Make Logfire an optional dependency (currently blocks all non-AI-Studio services)
2. Add `organization_id` to trace context (required by platform multi-tenancy)
3. Add OTLP exporter or expose the TracerProvider globally (enables standard OTEL ecosystem)

---

## Gap Registry

### GAP-1: Hard Logfire Dependency Blocks Multi-Service Adoption

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Effort** | Low |
| **Affected Files** | `pyproject.toml:33`, `__init__.py:131` |
| **Affects** | All non-AI-Studio services wanting to adopt this library |

#### Problem

`logfire>=4.0.0` is a **hard dependency** in `pyproject.toml`. The `init()` function does `import logfire` unconditionally. Every service that installs `autonomize-observer` — even if they only want the Native OTEL path — is forced to install Logfire and all its transitive dependencies.

For services like `genesis-authz`, `prompt-management`, or `knowledge-hub` that only need Kafka/EventHub tracing, this is unnecessary bloat and a potential version conflict source.

#### Current Behavior

```toml
# pyproject.toml — logfire is required
dependencies = [
    "logfire>=4.0.0",  # <-- forced on everyone
    ...
]
```

```python
# __init__.py — unconditional import
def init(...):
    import logfire  # <-- fails if logfire not installed
    logfire.configure(...)
```

#### Recommended Fix

1. Move `logfire` to optional dependencies:

```toml
[project.optional-dependencies]
logfire = ["logfire>=4.0.0"]
```

2. Gate all Logfire usage behind `LOGFIRE_AVAILABLE` checks (pattern already exists in `core/imports.py`)

3. Make `init()` work without Logfire when `NativeOTELManager` is the chosen path:

```python
def init(...):
    if send_to_logfire or instrument_openai or instrument_anthropic:
        if not LOGFIRE_AVAILABLE:
            logger.warning("Logfire features requested but logfire not installed")
            return
        import logfire
        logfire.configure(...)
```

#### Acceptance Criteria

- [ ] `pip install autonomize-observer` works without logfire installed
- [ ] `pip install autonomize-observer[logfire]` installs logfire
- [ ] `NativeOTELManager` works independently of logfire
- [ ] `init()` gracefully degrades when logfire is absent

---

### GAP-2: No `organization_id` / Multi-Tenancy in Trace Context

| Field | Value |
|-------|-------|
| **Severity** | HIGH |
| **Effort** | Low |
| **Affected Files** | `schemas/base.py`, `schemas/streaming.py`, `core/native_otel_config.py`, `tracing/native_otel_manager.py` |
| **Affects** | All platform services, downstream trace consumers (ModelHub observer, analytics) |

#### Problem

Per the AAI platform architecture, **every operation must carry `organization_id`**. The current trace schemas and span attributes have no tenant context:

- `BaseEvent` has `user_id`, `session_id`, `project_name` — but **no `organization_id`**
- `NativeOTELManager` has no concept of tenant context
- Kafka trace events have no `organization_id` field
- Event Hub event format has no tenant scoping

Without this, traces from different tenants mix in dashboards, violating multi-tenant isolation.

#### Current Event Format (missing tenant context)

```json
{
  "usecase_id": "LIS",
  "context": { "trace_id": "...", "span_id": "..." },
  "name": "chat gpt-4o",
  "attributes": { "gen_ai.operation.name": "chat" }
}
```

#### Recommended Event Format

```json
{
  "usecase_id": "LIS",
  "organization_id": "org-abc-123",
  "project_id": "proj-456",
  "context": { "trace_id": "...", "span_id": "..." },
  "name": "chat gpt-4o",
  "attributes": { "gen_ai.operation.name": "chat" }
}
```

#### Recommended Fix

1. Add `organization_id` and `project_id` to `NativeOTELConfig.resource_attributes`:

```python
@dataclass
class NativeOTELConfig:
    organization_id: str | None = None
    project_id: str | None = None
```

2. Propagate to OTEL resource attributes:

```python
resource_attrs = {
    "service.name": self._config.service_name,
    "autonomize.organization_id": self._config.organization_id,
    "autonomize.project_id": self._config.project_id,
}
```

3. Include in exported event format (both Kafka and Event Hub exporters)

4. Add `organization_id` to `BaseEvent` schema

#### Acceptance Criteria

- [ ] `organization_id` present in all exported spans
- [ ] `project_id` present in all exported spans
- [ ] Downstream consumers can filter/scope by organization
- [ ] `BaseEvent` schema includes `organization_id`

---

### GAP-3: No OTLP/HTTP/gRPC Exporter Support

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM-HIGH |
| **Effort** | Medium |
| **Affected Files** | `core/native_otel_config.py`, `tracing/native_otel_manager.py` |
| **Affects** | Services wanting to send traces to Jaeger, Tempo, Datadog, New Relic, or any OTLP-compatible backend |

#### Problem

The `ExporterType` enum only supports `KAFKA`, `EVENT_HUB`, and `BOTH`. There is no standard **OTLP exporter** (HTTP or gRPC). This is a significant gap:

- OTLP is the OpenTelemetry ecosystem's default export protocol
- Services outside AI Studio may use different observability backends (Jaeger, Tempo, Datadog)
- Other genesis services (`genesis-authz`, `knowledge-hub`) may have different backend requirements

#### Current Enum

```python
class ExporterType(str, Enum):
    KAFKA = "kafka"
    EVENT_HUB = "eventhub"
    BOTH = "both"
```

#### Recommended Fix

```python
class ExporterType(str, Enum):
    KAFKA = "kafka"
    EVENT_HUB = "eventhub"
    OTLP_GRPC = "otlp_grpc"
    OTLP_HTTP = "otlp_http"
    BOTH = "both"          # Kafka + Event Hub (legacy name)
    COMPOSITE = "composite" # Any combination
```

Add optional dependency:

```toml
[project.optional-dependencies]
otlp = [
    "opentelemetry-exporter-otlp-proto-grpc>=1.27.0",
    "opentelemetry-exporter-otlp-proto-http>=1.27.0",
]
```

Add OTLP config:

```python
@dataclass
class OTLPConfig:
    endpoint: str = "http://localhost:4317"  # gRPC default
    headers: dict[str, str] = field(default_factory=dict)
    insecure: bool = True
    compression: str = "gzip"
```

#### Acceptance Criteria

- [ ] `ExporterType.OTLP_GRPC` and `ExporterType.OTLP_HTTP` available
- [ ] OTLP exporter works with standard backends (Jaeger, Tempo)
- [ ] `OTLPConfig` supports endpoint, headers, TLS, compression
- [ ] OTLP dependencies are optional

---

### GAP-4: `NativeOTELManager` Doesn't Set Global TracerProvider

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Effort** | Low |
| **Affected Files** | `tracing/native_otel_manager.py:147` |
| **Affects** | Auto-instrumentation libraries, W3C trace context propagation |

#### Problem

The `TracerProvider` is created in `_configure()` but **never registered as the global provider** via `otel_trace.set_tracer_provider()`. This means:

- Auto-instrumentation libraries (`opentelemetry-instrumentation-httpx`, `-sqlalchemy`, `-fastapi`) won't pick up this provider
- W3C trace context propagation from HTTP middleware won't attach to the same provider
- The distributed tracing docs work around this by accessing `manager.tracer` directly, but this breaks composability with the OTEL ecosystem

#### Current Code

```python
def _configure(self) -> None:
    self._provider = TracerProvider(resource=resource)
    # ... setup exporters ...
    self._tracer = self._provider.get_tracer(...)
    # NOTE: provider is NOT registered globally
```

#### Recommended Fix

```python
@dataclass
class NativeOTELConfig:
    set_global_provider: bool = True  # New field

def _configure(self) -> None:
    self._provider = TracerProvider(resource=resource)
    # ... setup exporters ...

    if self._config.set_global_provider:
        otel_trace.set_tracer_provider(self._provider)

    self._tracer = self._provider.get_tracer(...)
```

#### Acceptance Criteria

- [ ] `set_global_provider` config option available (default: `True`)
- [ ] When enabled, `otel_trace.get_tracer_provider()` returns the manager's provider
- [ ] Auto-instrumentation libraries work out of the box
- [ ] When disabled, provider remains isolated (for testing/embedding scenarios)

---

### GAP-5: No Metrics or Logging Signal — Traces Only

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Effort** | High |
| **Affected Files** | N/A (new feature) |
| **Affects** | Services needing operational metrics (token usage rates, cost per org, latency histograms, error rates) |

#### Problem

The library only covers **traces/spans**. OpenTelemetry defines three signals: traces, metrics, and logs. For a cross-service observability SDK:

- **Metrics** — Token usage rates, cost per organization, latency histograms, error rates should be exportable as OTEL metrics, not just embedded in span attributes
- **Structured logging** — The `AuditLogger` writes to Kafka but doesn't integrate with OTEL's `LoggerProvider` for trace-log correlation

Services like `genesis-authz` likely need metrics more than traces.

#### Recommended Approach (Phased)

**Phase 1 (Document):** Explicitly state that metrics are out of scope for v1. Add a "Future Work" section to docs.

**Phase 2 (Metrics):** Add a `MetricsManager` that exposes:

```python
class MetricsManager:
    def record_llm_tokens(self, provider, model, input_tokens, output_tokens): ...
    def record_llm_cost(self, provider, model, cost): ...
    def record_llm_latency(self, provider, model, duration_ms): ...
    def record_error(self, operation, error_type): ...
```

**Phase 3 (Logging):** Integrate `AuditLogger` with OTEL `LoggerProvider` for correlation.

#### Acceptance Criteria (Phase 1)

- [ ] Docs clearly state metrics/logging are out of scope for v1
- [ ] "Future Work" section added with the phased plan

---

### GAP-6: Event Hub Exporter Uses Synchronous Calls

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Effort** | Medium |
| **Affected Files** | `exporters/otel/eventhub_span_exporter.py:349-369` |
| **Affects** | High-throughput services exporting to Event Hub |

#### Problem

The `_send_batch()` method calls `producer.create_batch()` and `producer.send_batch()` **synchronously**. The Azure Event Hub SDK supports async via `EventHubProducerClient.send_batch()` (async variant).

When running inside the OTEL `BatchSpanProcessor`, this is called from a background thread, so it doesn't block the event loop directly — but it holds the thread. For high-throughput services, this could bottleneck the span processor's thread pool.

Additionally, `force_flush()` returns `True` immediately claiming "Event Hub sends synchronously" — but spans queued in the `BatchSpanProcessor` may not have been delivered to the exporter yet. The flush contract covers the processor queue, not just the exporter.

#### Current Code

```python
def _send_batch(self, producer, events):
    batch = producer.create_batch(partition_key=self._usecase_id)  # sync
    for event in events:
        batch.add(event)
    producer.send_batch(batch)  # sync, blocks thread
```

#### Recommended Fix

1. Consider using `EventHubProducerClient` with `send_batch` in a thread pool, or provide an async variant
2. Fix `force_flush` documentation to clarify it only applies to the exporter, not the processor queue
3. Add connection pooling / retry logic for transient Azure failures

#### Acceptance Criteria

- [ ] `_send_batch` handles transient Azure failures with retry
- [ ] `force_flush` documentation is accurate
- [ ] Performance benchmarked under high throughput (>1000 spans/sec)

---

### GAP-7: PHI Detection is Keyword-Based and Fragile

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Effort** | Medium |
| **Affected Files** | `exporters/otel/eventhub_span_exporter.py:314-347` |
| **Affects** | HIPAA compliance, healthcare integrations |

#### Problem

PHI detection relies on span name substring matching:

```python
phi_indicators = [
    "phi", "pii", "hipaa", "member", "patient",
    "ssn", "dob", "medical", "health_record",
]
name_lower = span.name.lower()
for indicator in phi_indicators:
    if indicator in name_lower:
        return True
```

Issues:
- **False positives**: `member` matches "team_member_count", "membership_tier"
- **False negatives**: A span named "process_data" containing actual PHI in attributes is missed
- **No attribute-level scanning**: Only span name is checked, not attribute values
- **Kafka exporter has no PHI routing at all**: PHI spans go to the regular Kafka topic unprotected

#### Recommended Fix

1. Make PHI detection configurable:

```python
@dataclass
class PHIDetectionConfig:
    enabled: bool = True
    span_name_patterns: list[str] = field(default_factory=lambda: [
        r"\bphi\b", r"\bpii\b", r"\bhipaa\b",
        r"\bpatient\b", r"\bssn\b", r"\bdob\b",
        r"\bmedical\b", r"\bhealth.record\b",
    ])
    attribute_key_patterns: list[str] = field(default_factory=lambda: [
        r"contains_phi", r"phi_level",
    ])
    # Use word boundary regex instead of substring
    use_word_boundaries: bool = True
```

2. Add attribute-value scanning (check if any attribute values match PHI patterns)

3. Add PHI routing to the **Kafka exporter** (separate topic for restricted spans)

4. Remove `member` from default patterns (too many false positives), or use `\bpatient\b` with word boundaries

#### Acceptance Criteria

- [ ] PHI detection configurable via `PHIDetectionConfig`
- [ ] Word boundary matching prevents false positives on "member"
- [ ] Attribute-level PHI flag checking (`contains_phi` attribute)
- [ ] Kafka exporter supports PHI routing to a restricted topic
- [ ] False positive rate documented/tested

---

### GAP-8: No FastAPI/ASGI Integration for NativeOTELManager

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Effort** | Medium |
| **Affected Files** | `integrations/fastapi.py` |
| **Affects** | Services adopting NativeOTELManager with FastAPI |

#### Problem

`integrations/fastapi.py` only supports Logfire-based instrumentation (`logfire.instrument_fastapi(app)`). Services adopting `NativeOTELManager` get **no request-level tracing middleware**.

For services outside AI Studio, the typical need is: "instrument my FastAPI app with OTEL and export to Kafka." Currently they'd need to manually set up `opentelemetry-instrumentation-fastapi` and wire it to the NativeOTELManager's provider.

#### Recommended Fix

Add `setup_fastapi_native()`:

```python
def setup_fastapi_native(
    app: Any,
    manager: NativeOTELManager,
    keycloak_enabled: bool = True,
    keycloak_claim_mappings: dict[str, str] | None = None,
) -> None:
    """Set up FastAPI with Native OTEL instrumentation."""
    # Register provider globally so auto-instrumentation works
    if manager._provider:
        otel_trace.set_tracer_provider(manager._provider)

    # Instrument FastAPI via OTEL
    try:
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        FastAPIInstrumentor.instrument_app(app)
    except ImportError:
        logger.warning("opentelemetry-instrumentation-fastapi not installed")

    # Add Keycloak middleware (same as current)
    if keycloak_enabled:
        middleware = create_fastapi_middleware(keycloak_claim_mappings)
        app.middleware("http")(middleware)
```

#### Acceptance Criteria

- [ ] `setup_fastapi_native(app, manager)` available
- [ ] Request spans automatically created for all HTTP endpoints
- [ ] Keycloak middleware works with native OTEL path
- [ ] `opentelemetry-instrumentation-fastapi` added as optional dependency

---

### GAP-9: No Context Propagation Helpers in the SDK

| Field | Value |
|-------|-------|
| **Severity** | MEDIUM |
| **Effort** | Low |
| **Affected Files** | N/A (new module) |
| **Affects** | Multi-service distributed tracing adoption |

#### Problem

The docs show a full distributed tracing example with W3C `TraceContextTextMapPropagator` and a `consume_with_trace` helper — but this helper is **doc-only**, not shipped in the library.

For multi-service adoption, context propagation through Kafka is the most common integration need.

#### Recommended Fix

Create `autonomize_observer/tracing/propagation.py`:

```python
"""Trace context propagation helpers for distributed tracing."""

from contextlib import contextmanager
from typing import Any, Generator, Tuple

from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
from opentelemetry.trace import SpanKind


def inject_trace_context() -> dict[str, str]:
    """Inject current trace context into a carrier dict.

    Returns:
        Dict with traceparent/tracestate headers.
        Convert to Kafka headers: [(k, v.encode()) for k, v in carrier.items()]
    """
    carrier: dict[str, str] = {}
    TraceContextTextMapPropagator().inject(carrier)
    return carrier


def extract_trace_context(headers: dict[str, str]):
    """Extract parent trace context from headers.

    Args:
        headers: Dict of string headers (e.g., from Kafka message)

    Returns:
        OpenTelemetry Context for use with start_as_current_span
    """
    return TraceContextTextMapPropagator().extract(carrier=headers)


def kafka_headers_to_dict(headers: list[tuple[str, bytes]] | None) -> dict[str, str]:
    """Convert Kafka header format to string dict."""
    if not headers:
        return {}
    return {k: v.decode("utf-8") for k, v in headers}


def dict_to_kafka_headers(carrier: dict[str, str]) -> list[tuple[str, bytes]]:
    """Convert string dict to Kafka header format."""
    return [(k, v.encode("utf-8")) for k, v in carrier.items()]


@contextmanager
def consume_with_trace(
    manager,
    consumer,
    span_name: str,
    timeout: float = 1.0,
) -> Generator[Tuple[Any, Any], None, None]:
    """Consume a Kafka message with automatic trace context restoration.

    Usage:
        with consume_with_trace(manager, consumer, "process-data") as (msg, span):
            if msg:
                data = json.loads(msg.value())
                span.set_attribute("records.count", len(data))
                process(data)
    """
    msg = consumer.poll(timeout)

    if msg is None or msg.error():
        yield None, None
        return

    headers = kafka_headers_to_dict(msg.headers())
    parent_ctx = extract_trace_context(headers)

    with manager.tracer.start_as_current_span(
        span_name,
        context=parent_ctx,
        kind=SpanKind.CONSUMER,
    ) as span:
        span.set_attribute("messaging.system", "kafka")
        yield msg, span
```

#### Acceptance Criteria

- [ ] `inject_trace_context()` and `extract_trace_context()` shipped in SDK
- [ ] `consume_with_trace()` context manager shipped in SDK
- [ ] `kafka_headers_to_dict()` / `dict_to_kafka_headers()` utilities available
- [ ] Documented in `TRACING_AND_TOOLS.md`

---

### GAP-10: Logging Patterns Don't Follow AAI Checklist

| Field | Value |
|-------|-------|
| **Severity** | LOW-MEDIUM |
| **Effort** | Low |
| **Affected Files** | `tracing/native_otel_manager.py`, `exporters/otel/eventhub_span_exporter.py`, `exporters/otel/kafka_span_exporter.py` |
| **Affects** | Code quality, structured log aggregation |

#### Problem

Per the AAI code review checklist, logging should use structured kwargs, not f-strings. Current code uses f-string interpolation:

```python
# Current — f-string interpolation
logger.warning(f"Configuration errors: {errors}")
logger.error(f"Failed to convert span to event: {e}")
logger.info(f"NativeOTELManager configured for {self._config.service_name} ...")
```

Additionally, the native OTEL path doesn't use the exception hierarchy from `core/exceptions.py` — it raises generic `ImportError`, `ValueError`, `Exception`.

#### Recommended Fix

```python
# Correct — structured logging
logger.warning("Configuration errors detected", errors=errors)
logger.error("Failed to convert span to event", error=str(e), span_name=span.name)
logger.info(
    "NativeOTELManager configured",
    service_name=self._config.service_name,
    exporter_count=len(self._exporters),
)
```

Use exceptions from `core/exceptions.py` where appropriate.

#### Acceptance Criteria

- [ ] All logger calls in native OTEL path use structured kwargs
- [ ] No f-string interpolation in log messages
- [ ] Custom exceptions used instead of generic ones where appropriate

---

### GAP-11: No Shutdown/Lifecycle Hook Integration

| Field | Value |
|-------|-------|
| **Severity** | LOW |
| **Effort** | Low |
| **Affected Files** | `tracing/native_otel_manager.py` |
| **Affects** | Span loss during Kubernetes pod termination |

#### Problem

The `NativeOTELManager` has `shutdown()` and `force_flush()`, but there's no `atexit` registration or signal handler. If a service crashes or gets `SIGTERM`'d (common in Kubernetes), pending spans in the `BatchSpanProcessor` queue may be lost.

#### Recommended Fix

```python
import atexit

def _configure(self) -> None:
    # ... existing setup ...

    # Register shutdown hook
    atexit.register(self.shutdown)

    self._configured = True
```

Document that services should also call `manager.shutdown()` in their ASGI lifespan:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    manager.shutdown()  # Flush pending spans on shutdown
```

#### Acceptance Criteria

- [ ] `atexit.register(self.shutdown)` called during configuration
- [ ] ASGI lifespan integration documented
- [ ] Verified spans are flushed on SIGTERM

---

### GAP-12: Documentation Gaps

| Field | Value |
|-------|-------|
| **Severity** | LOW |
| **Effort** | Medium |
| **Affected Files** | `docs/TRACING_AND_TOOLS.md`, `docs/AZURE_EVENTHUB_OTEL_IMPLEMENTATION.md` |
| **Affects** | Onboarding speed for other teams |

#### Problem

1. **No migration guide** — The docs don't explain how an existing AI Studio service using Logfire should migrate to (or add) NativeOTELManager alongside Logfire
2. **No service integration matrix** — Which genesis services should use which SDK? (`genesis-authz`, `knowledge-hub`, `modelhub`, `prompt-management`)
3. **No performance benchmarks** — What's the overhead per span? What batch sizes work best?
4. **No schema versioning** — The Event Hub JSON format has no `schema_version` field, making future evolution harder

#### Recommended Additions

**Migration guide section:**

```markdown
## Migrating from Logfire-Only to Dual SDK

### Step 1: Add native-otel dependency
pip install autonomize-observer[native-otel]

### Step 2: Create NativeOTELManager alongside existing Logfire
native_manager = NativeOTELManager(config=NativeOTELConfig(...))

### Step 3: Use NativeOTELManager for production export
# Keep Logfire for local dev, add Native OTEL for production Kafka/EH export
```

**Service integration matrix:**

| Service | Recommended SDK | Exporter | Rationale |
|---------|----------------|----------|-----------|
| ai-studio-v2-backend | Both (Logfire + Native) | Kafka + Event Hub | Full observability + legacy compat |
| genesis-authz | Native OTEL only | Kafka or OTLP | No LLM tracing needed |
| knowledge-hub-v3 | Native OTEL | Kafka | Document processing traces |
| prompt-management | Native OTEL | Kafka | Prompt execution traces |
| genesis-service-modelhub | Native OTEL | Kafka | ML lifecycle traces |

**Schema versioning:**

```json
{
  "schema_version": "1.0.0",
  "usecase_id": "LIS",
  "context": { "trace_id": "...", "span_id": "..." },
  ...
}
```

#### Acceptance Criteria

- [ ] Migration guide added to docs
- [ ] Service integration matrix added
- [ ] Schema versioning field added to event format
- [ ] Performance benchmarks documented (after testing)

---

## Priority Matrix

| Gap | Severity | Effort | Multi-Service Impact | Recommended Phase |
|-----|----------|--------|---------------------|-------------------|
| GAP-1: Hard Logfire dependency | HIGH | Low | Blocks adoption | **Phase 1** |
| GAP-2: No org_id in traces | HIGH | Low | Breaks multi-tenancy | **Phase 1** |
| GAP-3: No OTLP exporter | MED-HIGH | Medium | Limits backend flexibility | **Phase 1** |
| GAP-4: No global provider | MEDIUM | Low | Breaks auto-instrumentation | **Phase 1** |
| GAP-9: No propagation helpers | MEDIUM | Low | Adoption friction | **Phase 1** |
| GAP-11: No lifecycle hooks | LOW | Low | Data loss risk | **Phase 1** |
| GAP-10: Logging patterns | LOW-MED | Low | Code quality | **Phase 1** |
| GAP-8: No FastAPI native integration | MEDIUM | Medium | Adoption friction | **Phase 2** |
| GAP-7: Fragile PHI detection | MEDIUM | Medium | Compliance risk | **Phase 2** |
| GAP-6: Sync Event Hub calls | MEDIUM | Medium | Performance at scale | **Phase 2** |
| GAP-12: Documentation gaps | LOW | Medium | Onboarding friction | **Phase 2** |
| GAP-5: No metrics signal | MEDIUM | High | Incomplete observability | **Phase 3** |

### Phase 1 — Multi-Service Readiness (Low effort, high impact)

Fix GAP-1, GAP-2, GAP-3, GAP-4, GAP-9, GAP-10, GAP-11. These are all low-effort changes that unblock adoption by other genesis services.

### Phase 2 — Production Hardening (Medium effort)

Fix GAP-6, GAP-7, GAP-8, GAP-12. These improve reliability, compliance, and developer experience for teams actively integrating.

### Phase 3 — Full Observability (High effort)

Fix GAP-5. Adds metrics signal support, making this a complete OTEL SDK.
