# Service Integration Matrix

This document provides guidance on which SDK and instrumentation approach to use for different service types and use cases.

## Quick Reference Matrix

| Service Type | Recommended SDK | Integration Function | PHI Support | Notes |
|-------------|-----------------|---------------------|-------------|-------|
| FastAPI (Dev) | Logfire | `setup_fastapi()` | N/A | Best for local debugging with Logfire dashboard |
| FastAPI (Prod) | Native OTEL | `setup_fastapi_native()` | Yes | Kafka/Event Hub export with PHI routing |
| FastAPI (Hybrid) | Both | `init()` + `setup_fastapi_native()` | Yes | LLM auto-instrumentation + production export |
| Background Worker | Native OTEL | `NativeOTELManager` | Yes | Manual spans with `manager.span()` |
| Kafka Consumer | Native OTEL | `manager.span()` | Yes | Extract context from headers |
| LangChain/LangGraph | Logfire | `init(instrument_langchain=True)` | No | Built-in LangChain instrumentation |
| OpenAI Integration | Logfire | `init(instrument_openai=True)` | No | Auto-traces all OpenAI calls |
| Anthropic Integration | Logfire | `init(instrument_anthropic=True)` | No | Auto-traces all Anthropic calls |
| CLI Tool | Native OTEL | `NativeOTELManager` | Yes | Lightweight, no Logfire overhead |

## Detailed Integration Patterns

### Pattern 1: FastAPI with Logfire (Development)

Best for local development with the Logfire dashboard for real-time debugging.

```python
from fastapi import FastAPI
from autonomize_observer import init
from autonomize_observer.integrations import setup_fastapi

app = FastAPI()

# Initialize Logfire
init(
    service_name="my-api",
    send_to_logfire=True,  # Send to Logfire dashboard
    instrument_openai=True,
    instrument_anthropic=True,
)

# Instrument FastAPI
setup_fastapi(app, service_name="my-api")
```

**Pros:**
- Real-time debugging with Logfire dashboard
- Auto-instrumentation for LLM providers
- Simple setup

**Cons:**
- Requires Logfire account
- Data sent to external service

---

### Pattern 2: FastAPI with Native OTEL (Production)

Best for production deployments with Kafka or Event Hub export.

```python
from fastapi import FastAPI
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig
from autonomize_observer.integrations import setup_fastapi_native

app = FastAPI()

# Configure Native OTEL
config = NativeOTELConfig(
    enabled=True,
    service_name="my-api",
    environment="production",
    enable_kafka=True,
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-traces",
        restricted_topic="otel-phi-traces",  # PHI routing
    ),
    organization_id="org-123",
    project_id="proj-456",
)

manager = NativeOTELManager(config=config)

# Instrument FastAPI with Native OTEL
setup_fastapi_native(
    app,
    manager=manager,
    keycloak_enabled=True,
)
```

**Pros:**
- Full control over data export
- PHI routing to restricted topics
- Multi-tenancy support
- No external dependencies

**Cons:**
- No LLM auto-instrumentation
- Manual span creation for LLM calls

---

### Pattern 3: Dual SDK (Hybrid)

Best for services that need both LLM auto-instrumentation and production export.

```python
from fastapi import FastAPI
from autonomize_observer import init
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig
from autonomize_observer.integrations import setup_fastapi_native

app = FastAPI()

# Initialize Logfire for LLM auto-instrumentation (local only)
init(
    service_name="my-api",
    send_to_logfire=False,  # Keep data local
    instrument_openai=True,
    instrument_anthropic=True,
)

# Initialize Native OTEL for production export
config = NativeOTELConfig.from_env()
manager = NativeOTELManager(config=config)

# Use Native OTEL for HTTP instrumentation
setup_fastapi_native(app, manager=manager)

# Use manager.llm_span() for LLM calls that need production export
with manager.llm_span(provider="openai", model="gpt-4o") as span:
    response = openai.chat.completions.create(...)
    span.set_attribute("gen_ai.usage.input_tokens", response.usage.prompt_tokens)
```

---

### Pattern 4: Background Worker

For async workers, batch processors, or scheduled jobs.

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig

config = NativeOTELConfig.from_env()
manager = NativeOTELManager(config=config)

def process_job(job_id: str):
    with manager.span("process-job") as span:
        span.set_attribute("job.id", job_id)

        # Sub-operations
        with manager.span("fetch-data") as fetch_span:
            data = fetch_from_database(job_id)
            fetch_span.set_attribute("data.count", len(data))

        with manager.span("transform-data") as transform_span:
            result = transform(data)

        return result

# Graceful shutdown on SIGTERM
# (Handled automatically by NativeOTELManager signal handlers)
```

---

### Pattern 5: Kafka Consumer with Context Propagation

For services consuming from Kafka that need to continue traces.

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.tracing.otel_utils import extract_context_from_headers

config = NativeOTELConfig.from_env()
manager = NativeOTELManager(config=config)

def consume_message(message):
    # Extract trace context from Kafka headers
    headers = {h[0]: h[1].decode() for h in message.headers() or []}
    parent_context = extract_context_from_headers(headers)

    # Continue the trace
    with manager.span("process-message", context=parent_context) as span:
        span.set_attribute("kafka.topic", message.topic())
        span.set_attribute("kafka.partition", message.partition())

        process(message.value())
```

---

## Exporter Selection Guide

| Exporter | Use Case | Enable Flag |
|----------|----------|-------------|
| **Kafka** | High-throughput, streaming analytics | `enable_kafka=True` |
| **Event Hub** | Azure-native, enterprise integration | `enable_eventhub=True` |
| **OTLP gRPC** | Standard OTEL collectors, Jaeger | `enable_otlp_grpc=True` |
| **OTLP HTTP** | Firewall-friendly, load balancers | `enable_otlp_http=True` |
| **Console** | Debugging, local development | `enable_console=True` |
| **Multiple** | Multiple destinations | Enable multiple flags simultaneously |

### Kafka Configuration

```python
from autonomize_observer.core.config import KafkaConfig

kafka_config = KafkaConfig(
    bootstrap_servers="kafka:9092",
    trace_topic="otel-traces",
    restricted_topic="otel-phi-traces",  # PHI routing
    security_protocol="SASL_SSL",
    sasl_mechanism="PLAIN",
    sasl_username="user",
    sasl_password="password",
)
```

### Event Hub Configuration

```python
from autonomize_observer.core.native_otel_config import EventHubConfig

eventhub_config = EventHubConfig(
    fully_qualified_namespace="myns.servicebus.windows.net",
    eventhub_name="otel-traces",
    restricted_eventhub_name="otel-phi-traces",  # PHI routing
    credential_type="managed",  # Use managed identity
)
```

### OTLP Configuration

```python
from autonomize_observer.core.native_otel_config import OTLPConfig

otlp_config = OTLPConfig(
    endpoint="http://otel-collector:4317",  # gRPC
    # endpoint="http://otel-collector:4318/v1/traces",  # HTTP
    headers={"Authorization": "Bearer token"},
    compression="gzip",
)
```

---

## PHI Handling Decision Tree

```
Does your service process PHI/PII data?
├── No → Use standard topic/event hub
└── Yes → Configure PHI routing
    ├── Explicit marking: Set `contains_phi=True` on spans
    └── Auto-detection: PHIDetectionConfig patterns
        └── Routes to restricted_topic/restricted_eventhub_name
```

### PHI Detection Configuration

```python
from autonomize_observer.core.phi_config import PHIDetectionConfig

phi_config = PHIDetectionConfig(
    enabled=True,
    patterns=[
        "phi", "pii", "hipaa", "patient", "ssn",
        "dob", "medical", "health_record", "diagnosis",
    ],
    attribute_flag="contains_phi",
    use_word_boundaries=True,  # Prevents "member" matching "team_member_count"
)
```

---

## Environment-Based Configuration

For production deployments, use environment variables:

```bash
# Core settings
export NATIVE_OTEL_ENABLED=true
export SERVICE_NAME=my-service
export ENVIRONMENT=production

# Exporter selection (enable one or more)
export NATIVE_OTEL_ENABLE_KAFKA=true
export NATIVE_OTEL_ENABLE_EVENTHUB=false
export NATIVE_OTEL_ENABLE_OTLP_GRPC=false
export NATIVE_OTEL_ENABLE_OTLP_HTTP=false
export NATIVE_OTEL_ENABLE_CONSOLE=false  # For debugging

# Legacy (deprecated): Use individual flags above instead
# export NATIVE_OTEL_EXPORTER=kafka  # or: eventhub, otlp_grpc, otlp_http, both

# Kafka settings (if NATIVE_OTEL_ENABLE_KAFKA=true)
export KAFKA_BOOTSTRAP_SERVERS=kafka:9092
export KAFKA_TRACE_TOPIC=otel-traces
export KAFKA_RESTRICTED_TOPIC=otel-phi-traces

# OTLP settings (if NATIVE_OTEL_ENABLE_OTLP_* enabled)
export OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317
export OTEL_EXPORTER_OTLP_HEADERS=Authorization=Bearer token
export OTEL_EXPORTER_OTLP_COMPRESSION=gzip

# Multi-tenancy
export ORGANIZATION_ID=org-123
export PROJECT_ID=proj-456

# Optional: Disable auto signal handlers (for ASGI lifespan management)
export NATIVE_OTEL_REGISTER_LIFECYCLE_HOOKS=false
```

Then in code:

```python
config = NativeOTELConfig.from_env()
manager = NativeOTELManager(config=config)
```

Or configure programmatically with multiple exporters:

```python
config = NativeOTELConfig(
    enabled=True,
    service_name="my-service",
    enable_kafka=True,      # Enable Kafka
    enable_console=True,    # Also enable console for debugging
    kafka_config=KafkaConfig(bootstrap_servers="kafka:9092"),
)
manager = NativeOTELManager(config=config)
```

---

## Migration Checklist

When migrating from Logfire-only to Native OTEL:

- [ ] Install `autonomize-observer[native-otel]` or `autonomize-observer[native-otel-all]`
- [ ] Create `NativeOTELConfig` with appropriate exporter
- [ ] Initialize `NativeOTELManager`
- [ ] Replace `setup_fastapi()` with `setup_fastapi_native()` if using Native OTEL for HTTP tracing
- [ ] Update span creation from `logfire.span()` to `manager.span()`
- [ ] Configure PHI routing if handling sensitive data
- [ ] Set up ASGI lifespan for graceful shutdown (recommended for web servers)
- [ ] Test trace propagation across services

See [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) for detailed migration instructions.

---

## Related Documentation

- [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) - Step-by-step migration guide
- [TRACING_AND_TOOLS.md](./TRACING_AND_TOOLS.md) - Distributed tracing patterns
- [AZURE_EVENTHUB_OTEL_IMPLEMENTATION.md](./AZURE_EVENTHUB_OTEL_IMPLEMENTATION.md) - Event Hub setup
- [GAP_ANALYSIS_STATUS.md](./GAP_ANALYSIS_STATUS.md) - Implementation status
