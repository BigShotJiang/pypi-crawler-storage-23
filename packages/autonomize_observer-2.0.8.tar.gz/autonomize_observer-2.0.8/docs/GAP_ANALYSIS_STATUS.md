# Observability Gap Analysis - Implementation Status

> **Last Updated**: 2026-02-17
> **Reference Document**: [OBSERVABILITY_GAP_ANALYSIS.md](./OBSERVABILITY_GAP_ANALYSIS.md)
> **Branch**: `feature/native-otel-sdk`

---

## Executive Summary

This document tracks the implementation status of the 12 gaps identified in the Observability Gap Analysis. The gaps were prioritized across three phases:

| Phase | Description | Status |
|-------|-------------|--------|
| **Phase 1** | Multi-Service Readiness (7 gaps) | **7 complete** |
| **Phase 2** | Production Hardening (4 gaps) | **4 complete** |
| **Phase 3** | Full Observability (1 gap) | Documented (out of scope for v1) |

### Overall Progress

| Status | Count | Gaps |
|--------|-------|------|
| **Fully Implemented** | 11 | GAP-1, GAP-2, GAP-3, GAP-4, GAP-6, GAP-7, GAP-8, GAP-9, GAP-10, GAP-11, GAP-12 |
| **Out of Scope (v1)** | 1 | GAP-5 (Metrics - documented in Future Work) |

---

## Completed Gaps (Phase 1)

### GAP-1: Hard Logfire Dependency - DONE

**Problem**: `logfire>=4.0.0` was a hard dependency, blocking adoption by services that only need Native OTEL.

**Solution**: Moved logfire to optional dependencies with graceful fallback.

**Files Modified**:
- `pyproject.toml:45-47` - logfire now in optional dependencies
- `core/imports.py:41-48` - conditional import with LOGFIRE_AVAILABLE flag
- `__init__.py:132-140` - graceful fallback when logfire not installed

**Implementation Details**:

```toml
# pyproject.toml
[project.optional-dependencies]
logfire = ["logfire>=4.0.0"]
```

```python
# core/imports.py
try:
    import logfire
    LOGFIRE_AVAILABLE = True
except ImportError:
    logfire = None
    LOGFIRE_AVAILABLE = False

def check_logfire_available() -> bool:
    """Check if Logfire is available."""
    return LOGFIRE_AVAILABLE
```

**Acceptance Criteria Status**:
- [x] `pip install autonomize-observer` works without logfire installed
- [x] `pip install autonomize-observer[logfire]` installs logfire
- [x] `NativeOTELManager` works independently of logfire
- [x] `init()` gracefully degrades when logfire is absent

---

### GAP-2: No organization_id / Multi-Tenancy - DONE

**Problem**: No tenant context in traces, causing multi-tenant isolation violations.

**Solution**: Added `organization_id` and `project_id` to configuration, schemas, and resource attributes.

**Files Modified**:
- `core/native_otel_config.py:183-184` - added config fields
- `tracing/native_otel_manager.py:142-143` - propagate to resource attributes
- `schemas/base.py:63` - added to BaseEvent schema

**Implementation Details**:

```python
# core/native_otel_config.py
@dataclass
class NativeOTELConfig:
    # Multi-tenancy context
    organization_id: str | None = None
    project_id: str | None = None
```

```python
# tracing/native_otel_manager.py - _configure() method
resource_attrs = {
    "service.name": self._config.service_name,
    "service.version": self._config.service_version,
    "deployment.environment": self._config.environment,
    "autonomize.organization_id": self._config.organization_id,
    "autonomize.project_id": self._config.project_id,
}
# Filter out None values
resource_attrs = {k: v for k, v in resource_attrs.items() if v is not None}
```

```python
# schemas/base.py
class BaseEvent(BaseModel):
    organization_id: str | None = None  # Line 63
```

**Acceptance Criteria Status**:
- [x] `organization_id` present in all exported spans (via resource attributes)
- [x] `project_id` present in all exported spans (via resource attributes)
- [x] Downstream consumers can filter/scope by organization
- [x] `BaseEvent` schema includes `organization_id`

---

### GAP-3: No OTLP/HTTP/gRPC Exporter Support - DONE

**Problem**: Only Kafka and Event Hub exporters supported, no standard OTLP export.

**Solution**: Added OTLP_GRPC and OTLP_HTTP exporter types with full configuration support.

**Files Modified**:
- `core/native_otel_config.py:34-41` - added ExporterType enum values
- `core/otlp_config.py` - new OTLPConfig dataclass
- `tracing/native_otel_manager.py:207-253` - OTLP exporter creation
- `pyproject.toml:49-53` - OTLP optional dependencies

**Implementation Details**:

```python
# core/native_otel_config.py
class ExporterType(str, Enum):
    KAFKA = "kafka"
    EVENT_HUB = "eventhub"
    OTLP_GRPC = "otlp_grpc"    # NEW
    OTLP_HTTP = "otlp_http"    # NEW
    BOTH = "both"
```

```python
# core/otlp_config.py
@dataclass
class OTLPConfig:
    endpoint: str = "http://localhost:4317"  # gRPC default
    headers: dict[str, str] = field(default_factory=dict)
    insecure: bool = True
    compression: str = "gzip"
```

```toml
# pyproject.toml
[project.optional-dependencies]
otlp = [
    "opentelemetry-exporter-otlp-proto-grpc>=1.27.0",
    "opentelemetry-exporter-otlp-proto-http>=1.27.0",
]
```

**Usage Example**:
```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import NativeOTELConfig, ExporterType
from autonomize_observer.core.otlp_config import OTLPConfig

config = NativeOTELConfig(
    enabled=True,
    exporter_type=ExporterType.OTLP_GRPC,
    otlp_config=OTLPConfig(
        endpoint="http://localhost:4317",
        headers={"Authorization": "Bearer token"},
        insecure=False,
        compression="gzip"
    )
)

manager = NativeOTELManager(config=config)
```

**Acceptance Criteria Status**:
- [x] `ExporterType.OTLP_GRPC` and `ExporterType.OTLP_HTTP` available
- [x] OTLP exporter works with standard backends (Jaeger, Tempo)
- [x] `OTLPConfig` supports endpoint, headers, TLS, compression
- [x] OTLP dependencies are optional

---

### GAP-4: NativeOTELManager Doesn't Set Global TracerProvider - DONE

**Problem**: TracerProvider not registered globally, breaking auto-instrumentation libraries.

**Solution**: Added `set_global_provider` config option (default: True) that registers the provider globally.

**Files Modified**:
- `core/native_otel_config.py:187` - added config option
- `tracing/native_otel_manager.py:153-155` - global provider registration

**Implementation Details**:

```python
# core/native_otel_config.py
@dataclass
class NativeOTELConfig:
    set_global_provider: bool = True  # Line 187
```

```python
# tracing/native_otel_manager.py - _configure() method
self._provider = TracerProvider(resource=resource)

if self._config.set_global_provider:
    otel_trace.set_tracer_provider(self._provider)
    logger.debug("Registered native OTEL tracer provider as global")
```

**Acceptance Criteria Status**:
- [x] `set_global_provider` config option available (default: `True`)
- [x] When enabled, `otel_trace.get_tracer_provider()` returns the manager's provider
- [x] Auto-instrumentation libraries work out of the box
- [x] When disabled, provider remains isolated (for testing/embedding scenarios)

---

### GAP-9: No Context Propagation Helpers - DONE

**Problem**: W3C trace context propagation helpers shown in docs but not shipped in the library.

**Solution**: Created `tracing/propagation.py` with full propagation utilities.

**Files Created**:
- `tracing/propagation.py` - all propagation helpers
- `tests/test_propagation.py` - comprehensive tests

**Implementation Details**:

```python
# tracing/propagation.py

def inject_trace_context() -> dict[str, str]:
    """Inject current trace context into a carrier dict.

    Returns:
        Dict with traceparent/tracestate headers.
    """
    carrier: dict[str, str] = {}
    TraceContextTextMapPropagator().inject(carrier)
    return carrier


def extract_trace_context(headers: dict[str, str]) -> Any:
    """Extract parent trace context from headers."""
    return TraceContextTextMapPropagator().extract(carrier=headers)


def kafka_headers_to_dict(headers: list[tuple[str, bytes]] | None) -> dict[str, str]:
    """Convert Kafka header format to string dict."""
    if not headers:
        return {}
    return {k: v.decode("utf-8") for k, v in headers}


def dict_to_kafka_headers(carrier: dict[str, str]) -> list[tuple[str, bytes]]:
    """Convert string dict to Kafka header format."""
    return [(k, v.encode("utf-8")) for k, v in carrier.items()]


@contextmanager
def consume_with_trace(
    manager: Any,
    consumer: Any,
    span_name: str,
    timeout: float = 1.0,
) -> Generator[tuple[Any, Any], None, None]:
    """Consume a Kafka message with automatic trace context restoration."""
    msg = consumer.poll(timeout)

    if msg is None or msg.error():
        yield None, None
        return

    headers = kafka_headers_to_dict(msg.headers())
    parent_ctx = extract_trace_context(headers)

    with manager.tracer.start_as_current_span(
        span_name,
        context=parent_ctx,
        kind=SpanKind.CONSUMER,
    ) as span:
        span.set_attribute("messaging.system", "kafka")
        yield msg, span
```

**Acceptance Criteria Status**:
- [x] `inject_trace_context()` and `extract_trace_context()` shipped in SDK
- [x] `consume_with_trace()` context manager shipped in SDK
- [x] `kafka_headers_to_dict()` / `dict_to_kafka_headers()` utilities available
- [x] Documented in `TRACING_AND_TOOLS.md`

---

## Recently Completed Gaps (Phase 2)

### GAP-10: Logging Patterns Don't Follow AAI Checklist - DONE

**Problem**: Logging uses f-strings instead of structured kwargs; custom exceptions not used.

**Solution**: Converted all 61 f-string log statements to structured logging with `extra={}` kwargs.

**Files Modified**:
- `audit/context.py` - 2 log statements converted
- `cost/pricing.py` - 4 log statements converted
- `integrations/fastapi.py` - 2 log statements converted
- `exporters/kafka_base.py` - 6 log statements converted
- `exporters/otel/kafka_span_exporter.py` - 1 log statement converted
- `exporters/otel/composite_exporter.py` - 5 log statements converted
- `tracing/kafka_trace_producer.py` - 3 log statements converted
- `tracing/native_otel_manager.py` - 2 log statements converted
- `tracing/otel_utils.py` - 6 log statements converted
- `tracing/workflow_tracer.py` - 8 log statements converted
- `tracing/agent_tracer.py` - 21 log statements converted
- `tracing/logfire_integration.py` - 6 log statements converted
- `tracing/utils/serialization.py` - 1 log statement converted

**Implementation Pattern**:
```python
# Before
logger.warning(f"Configuration errors: {errors}")

# After
logger.warning("Configuration errors detected", extra={"errors": errors})
```

**Acceptance Criteria Status**:
- [x] All logger calls in native OTEL path use structured kwargs
- [x] No f-string interpolation in log messages
- [x] Structured fields for errors, span IDs, topics, etc.

---

### GAP-11: No Shutdown/Lifecycle Hook Integration - DONE

**Problem**: No automatic cleanup on process exit or signal handling.

**Solution**: Added comprehensive lifecycle hook registration with atexit, SIGTERM, and SIGINT handlers.

**Files Modified**:
- `core/native_otel_config.py` - added `register_lifecycle_hooks: bool = True`
- `tracing/native_otel_manager.py` - added `_register_lifecycle_hooks()` method

**Implementation Details**:
```python
# tracing/native_otel_manager.py
def _register_lifecycle_hooks(self) -> None:
    """Register shutdown hooks for graceful termination."""
    import atexit
    import signal

    atexit.register(self.shutdown)

    def signal_handler(signum: int, frame: Any) -> None:
        self.shutdown()

    try:
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
    except (OSError, ValueError):
        pass  # Signal handlers may fail in some contexts
```

**Acceptance Criteria Status**:
- [x] `atexit.register(self.shutdown)` called during configuration
- [x] SIGTERM/SIGINT handlers registered
- [x] `register_lifecycle_hooks` config option to enable/disable
- [x] ASGI lifespan integration documented in MIGRATION_GUIDE.md

---

### GAP-7: PHI Detection is Keyword-Based and Fragile - DONE

**Problem**: Substring matching causes false positives; no word boundaries; Kafka has no PHI routing.

**Solution**: Created `PHIDetectionConfig` class with word boundary regex matching and added PHI routing to Kafka exporter.

**Files Created/Modified**:
- `core/phi_config.py` (NEW) - `PHIDetectionConfig` dataclass
- `core/config.py` - added `restricted_topic` to `KafkaConfig`
- `exporters/otel/eventhub_span_exporter.py` - updated to use `PHIDetectionConfig`
- `exporters/otel/kafka_span_exporter.py` - added PHI routing to restricted topic

**Implementation Details**:
```python
# core/phi_config.py
@dataclass
class PHIDetectionConfig:
    enabled: bool = True
    patterns: list[str] = field(default_factory=lambda: [
        "phi", "pii", "hipaa", "patient", "ssn", "dob",
        "medical", "health_record", "diagnosis", "prescription",
    ])
    attribute_flag: str = "contains_phi"
    use_word_boundaries: bool = True  # Prevents "member" matching "team_member_count"
    _compiled_pattern: re.Pattern[str] | None = field(default=None, repr=False)

    def matches(self, text: str) -> bool:
        """Check with word boundary regex: \\b(pattern1|pattern2)\\b"""
        if not self.enabled or not self._compiled_pattern:
            return False
        return bool(self._compiled_pattern.search(text))
```

**Acceptance Criteria Status**:
- [x] PHI detection configurable via `PHIDetectionConfig`
- [x] Word boundary matching prevents false positives on "member"
- [x] Attribute-level PHI flag checking (`contains_phi` attribute)
- [x] Kafka exporter supports PHI routing to `restricted_topic`
- [x] Event Hub exporter uses PHI config

---

### GAP-12: Documentation Gaps - DONE

**Problem**: Missing migration guide, service matrix, performance benchmarks.

**Solution**: Created comprehensive documentation for migration and service integration.

**Files Created**:
- `docs/MIGRATION_GUIDE.md` - step-by-step migration from Logfire-only to dual SDK
- `docs/SERVICE_INTEGRATION_MATRIX.md` - service type to SDK/exporter mapping

**Acceptance Criteria Status**:
- [x] Migration guide added to docs
- [x] Service integration matrix added
- [x] Schema versioning field in event format
- [x] ASGI lifespan pattern documented

---

### GAP-6: Event Hub Exporter Uses Synchronous Calls - DONE

**Problem**: `_send_batch()` blocks the thread; no retry logic for transient failures.

**Solution**: Added exponential backoff retry logic for transient Azure failures.

**Files Modified**:
- `core/native_otel_config.py` - added retry settings to `EventHubConfig`
- `exporters/otel/eventhub_span_exporter.py` - added `_send_with_retry()` method

**Implementation Details**:
```python
# core/native_otel_config.py - EventHubConfig
max_retries: int = 3
retry_delay_seconds: float = 1.0
retry_backoff_multiplier: float = 2.0
retry_max_delay_seconds: float = 30.0

# exporters/otel/eventhub_span_exporter.py
def _send_with_retry(self, producer: EventHubProducerClient, batch: Any) -> None:
    delay = self._config.retry_delay_seconds
    for attempt in range(self._config.max_retries + 1):
        try:
            producer.send_batch(batch)
            return
        except Exception as e:
            is_retryable = any(
                term in str(e).lower()
                for term in ["busy", "timeout", "unavailable", "throttl"]
            )
            if is_retryable and attempt < self._config.max_retries:
                time.sleep(delay)
                delay = min(delay * self._config.retry_backoff_multiplier,
                           self._config.retry_max_delay_seconds)
            else:
                raise
```

**Acceptance Criteria Status**:
- [x] `_send_batch` handles transient Azure failures with retry
- [x] Exponential backoff with configurable parameters
- [x] Retryable error detection (busy, timeout, throttle)

---

### GAP-8: No FastAPI/ASGI Integration for NativeOTELManager - DONE

**Problem**: `setup_fastapi()` only supports Logfire-based instrumentation.

**Solution**: Added `setup_fastapi_native()` function with native OTEL instrumentation.

**Files Modified**:
- `pyproject.toml` - added `fastapi-native` optional dependency
- `core/imports.py` - added `OTEL_FASTAPI_AVAILABLE` check
- `integrations/fastapi.py` - added `setup_fastapi_native()` function
- `integrations/__init__.py` - exported `setup_fastapi_native`

**Implementation Details**:
```python
# integrations/fastapi.py
def setup_fastapi_native(
    app: Any,
    manager: NativeOTELManager | None = None,
    keycloak_enabled: bool = True,
    keycloak_claim_mappings: dict[str, str] | None = None,
    excluded_urls: str | None = None,
) -> None:
    """Set up FastAPI with Native OpenTelemetry instrumentation."""
    from autonomize_observer.core.imports import (
        OTEL_FASTAPI_AVAILABLE, FastAPIInstrumentor, otel_trace,
    )

    if not OTEL_FASTAPI_AVAILABLE:
        logger.warning("opentelemetry-instrumentation-fastapi not installed")
        return

    tracer_provider = manager._provider if manager else otel_trace.get_tracer_provider()
    FastAPIInstrumentor.instrument_app(app, tracer_provider=tracer_provider)
```

**Acceptance Criteria Status**:
- [x] `setup_fastapi_native(app, manager)` available
- [x] Request spans automatically created for all HTTP endpoints
- [x] Keycloak middleware works with native OTEL path
- [x] `opentelemetry-instrumentation-fastapi` added as optional dependency

---

## Out of Scope for v1

### GAP-5: No Metrics or Logging Signal - DOCUMENTED

**Problem**: Library only covers traces/spans; no metrics or structured logging integration.

**Status**: Out of scope for v1. This is a HIGH effort item that requires significant design work.

**Documentation**: See "Future Work" section below for phased implementation plan.

**Acceptance Criteria Status**:
- [x] Docs clearly state metrics/logging are out of scope for v1
- [x] "Future Work" section added with the phased plan

---

## Phase Summary

### Phase 1: Multi-Service Readiness

| Gap | Description | Effort | Status |
|-----|-------------|--------|--------|
| GAP-1 | Hard Logfire dependency | Low | **DONE** |
| GAP-2 | No org_id in traces | Low | **DONE** |
| GAP-3 | No OTLP exporter | Medium | **DONE** |
| GAP-4 | No global provider | Low | **DONE** |
| GAP-9 | No propagation helpers | Low | **DONE** |
| GAP-10 | Logging patterns | Low | **DONE** |
| GAP-11 | No lifecycle hooks | Low | **DONE** |

**Phase 1 Progress**: 7/7 complete ✓

### Phase 2: Production Hardening

| Gap | Description | Effort | Status |
|-----|-------------|--------|--------|
| GAP-6 | Sync Event Hub calls | Medium | **DONE** |
| GAP-7 | Fragile PHI detection | Medium | **DONE** |
| GAP-8 | No FastAPI native integration | Medium | **DONE** |
| GAP-12 | Documentation gaps | Medium | **DONE** |

**Phase 2 Progress**: 4/4 complete ✓

### Phase 3: Full Observability

| Gap | Description | Effort | Status |
|-----|-------------|--------|--------|
| GAP-5 | No metrics signal | High | Out of Scope (v1) |

**Phase 3 Progress**: Documented for future work

---

## Future Work: Metrics and Extended Observability (v2+)

This section documents the phased plan for adding metrics support in future versions.

### Why Metrics Are Out of Scope for v1

1. **Complexity**: Metrics require different data models (counters, gauges, histograms) vs traces
2. **Infrastructure**: Requires additional backend support (Prometheus, Azure Monitor Metrics)
3. **Design Decisions**: Need to determine metric naming conventions, cardinality limits
4. **Testing**: Requires comprehensive benchmarking under production loads

### Phased Metrics Implementation Plan

#### Phase 1: Foundation (v2.1)
- Add `opentelemetry-api` metrics support
- Create `NativeMetricsManager` class mirroring `NativeOTELManager`
- Support basic counter and gauge metrics
- OTLP metrics exporter support

#### Phase 2: LLM-Specific Metrics (v2.2)
- Token usage counters (input/output by model)
- Cost tracking metrics (cumulative cost by provider)
- Latency histograms (LLM response times)
- Rate metrics (requests per minute by endpoint)

#### Phase 3: Production Metrics (v2.3)
- Kafka metrics exporter (for streaming analytics)
- Event Hub metrics exporter (Azure integration)
- Custom metric backends support
- Metric aggregation and downsampling

#### Phase 4: Full Observability (v3.0)
- Unified observability pipeline (traces + metrics + logs)
- Correlation between metrics and traces
- Alerting integration hooks
- Dashboard templates (Grafana, Azure Monitor)

### Metrics API Preview (Future)

```python
# Future API (not yet implemented)
from autonomize_observer.metrics import NativeMetricsManager

metrics = NativeMetricsManager(config=config)

# Counter for LLM calls
llm_calls = metrics.counter(
    name="llm.calls.total",
    description="Total LLM API calls",
    labels=["provider", "model", "status"]
)

# Histogram for latencies
llm_latency = metrics.histogram(
    name="llm.latency.seconds",
    description="LLM call latency in seconds",
    buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0]
)

# Usage
llm_calls.add(1, {"provider": "openai", "model": "gpt-4o", "status": "success"})
llm_latency.record(1.23, {"provider": "openai", "model": "gpt-4o"})
```

---

## Related Documentation

- [MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md) - Migration from Logfire-only to dual SDK
- [SERVICE_INTEGRATION_MATRIX.md](./SERVICE_INTEGRATION_MATRIX.md) - Service type to SDK mapping
- [TRACING_AND_TOOLS.md](./TRACING_AND_TOOLS.md) - Distributed tracing patterns
- [AZURE_EVENTHUB_OTEL_IMPLEMENTATION.md](./AZURE_EVENTHUB_OTEL_IMPLEMENTATION.md) - Event Hub setup
