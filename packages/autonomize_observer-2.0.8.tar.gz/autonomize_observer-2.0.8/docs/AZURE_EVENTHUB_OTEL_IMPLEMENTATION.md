# Azure Event Hub & Native OpenTelemetry SDK Implementation

## Executive Summary

This document describes the implementation of the **Native OpenTelemetry SDK** added to the autonomize-observer library to meet the Observability requirements.

**Key Design Decision**: The Native OTEL SDK is implemented as a **parallel option** alongside the existing Logfire-based implementation. Both can coexist and be used simultaneously.

### What Was Implemented

1. **Native OpenTelemetry SDK** - Added as parallel option (Logfire NOT replaced)
2. **Azure Event Hub Exporter** - Central event destination
3. **Kafka Span Exporter** - Native OTEL export to Kafka
4. **Dual Export Support** - Export to Kafka AND/OR Azure Event Hub
5. **OTLP Export Support** - Standard OTLP gRPC/HTTP export
6. **OpenTelemetry GenAI Semantic Conventions** - Standard schema support
7. **PHI/Restricted Event Routing** - Compliance requirements

---

## Architecture

### Dual SDK Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Application Code                          │
├─────────────────────────────────────────────────────────────┤
│              AgentTracer / WorkflowTracer                    │
├─────────────────────┬───────────────────────────────────────┤
│   OTELManager       │        NativeOTELManager              │
│  (Logfire-based)    │      (Native OTEL SDK)                │
│  [EXISTING]         │          [NEW]                        │
├─────────────────────┼───────────────────────────────────────┤
│  Pydantic Logfire   │  ┌─────────────┬─────────────────┐   │
│                     │  │KafkaSpan    │EventHubSpan     │   │
│                     │  │Exporter     │Exporter         │   │
│                     │  └─────────────┴─────────────────┘   │
├─────────────────────┼───────────────────────────────────────┤
│  Logfire Cloud      │  Kafka        │  Azure Event Hub     │
│  (Optional)         │  Topics       │  ai-obs-comm-eh      │
│                     │               │  ai-obs-restricted-eh│
└─────────────────────┴───────────────┴──────────────────────┘
```

### When to Use Which

| Use Case                        | Recommended SDK                           |
| ------------------------------- | ----------------------------------------- |
| Local development/debugging     | OTELManager (Logfire)                     |
| Production with Kafka           | NativeOTELManager + KafkaSpanExporter     |
| Production with Azure Event Hub | NativeOTELManager + EventHubSpanExporter  |
| Dual export (Kafka + Event Hub) | NativeOTELManager + CompositeSpanExporter |
| Legacy AI Studio integration    | OTELManager (Logfire)                     |
| Healthcare integration          | NativeOTELManager                         |

---

## Installation

```bash
# Native OTEL with Kafka export only
pip install autonomize-observer[native-otel]

# Native OTEL with Azure Event Hub
pip install autonomize-observer[azure]

# Full native OTEL features (Kafka + Azure)
pip install autonomize-observer[native-otel-all]

# Everything (including Logfire features)
pip install autonomize-observer[all]
```

---

## Quick Start

### Native OTEL with Kafka Export

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.config import KafkaConfig
from autonomize_observer.core.native_otel_config import NativeOTELConfig

# Configure
config = NativeOTELConfig(
    enabled=True,
    service_name="my-llm-service",
    enable_kafka=True,  # Enable Kafka exporter explicitly
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-genai-traces",
        security_protocol="SASL_SSL",  # Optional: for secure connections
        sasl_mechanism="PLAIN",
        sasl_username="admin",
        sasl_password="password",
    ),
)

# Create manager
manager = NativeOTELManager(config=config)

# Create spans with GenAI conventions
with manager.llm_span(
    provider="openai",
    model="gpt-4o",
) as span:
    response = openai_client.chat.completions.create(...)
    span.set_attribute("gen_ai.usage.input_tokens", response.usage.prompt_tokens)
    span.set_attribute("gen_ai.usage.output_tokens", response.usage.completion_tokens)
```

### Native OTEL with Azure Event Hub

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import (
    NativeOTELConfig,
    EventHubConfig,
)

config = NativeOTELConfig(
    enabled=True,
    service_name="my-azure-service",
    enable_eventhub=True,  # Enable Event Hub exporter explicitly
    event_hub_config=EventHubConfig(
        fully_qualified_namespace="ai-obs-ehn-prod.servicebus.windows.net",
        eventhub_name="ai-obs-comm-eh",
        restricted_eventhub_name="ai-obs-restricted-eh",  # For PHI
        use_managed_identity=True,
        usecase_id="LIS",  # Application identifier
    ),
)

manager = NativeOTELManager(config=config)
```

### Dual Export (Kafka + Event Hub)

```python
config = NativeOTELConfig(
    enabled=True,
    service_name="my-multi-cloud-service",
    enable_kafka=True,     # Export to Kafka
    enable_eventhub=True,  # AND Event Hub simultaneously
    kafka_config=KafkaConfig(
        bootstrap_servers="kafka:9092",
        trace_topic="otel-traces",
    ),
    event_hub_config=EventHubConfig(
        connection_string="Endpoint=sb://...",
        eventhub_name="otel-traces",
        usecase_id="AgentSpark",
    ),
)

manager = NativeOTELManager(config=config)

# All spans exported to BOTH destinations
with manager.span("my-operation") as span:
    do_work()
```

### OTLP Export (gRPC/HTTP)

```python
from autonomize_observer.tracing import NativeOTELManager
from autonomize_observer.core.native_otel_config import (
    NativeOTELConfig,
)
from autonomize_observer.core.otlp_config import OTLPConfig

# Option 1: Shared OTLP config
config = NativeOTELConfig(
    enabled=True,
    service_name="my-service",
    enable_otlp_grpc=True,
    otlp_config=OTLPConfig(
        endpoint="http://otel-collector:4317",
        insecure=True,
    ),
)

# Option 2: Protocol-specific configs (recommended if enabling both)
config = NativeOTELConfig(
    enabled=True,
    service_name="my-service",
    enable_otlp_grpc=True,
    enable_otlp_http=True,
    otlp_grpc_config=OTLPConfig(endpoint="http://localhost:4317"),
    otlp_http_config=OTLPConfig(endpoint="http://localhost:4318/v1/traces"),
)

manager = NativeOTELManager(config=config)
```

### Using Both Logfire AND Native OTEL

```python
from autonomize_observer.tracing import OTELManager, NativeOTELManager

# Logfire for local dev/debugging
logfire_manager = OTELManager(
    service_name="my-service",
    send_to_logfire=True,
)

# Native OTEL for production export
native_manager = NativeOTELManager(config=native_config)

# Use Logfire for general tracing
with logfire_manager.span("debug-operation"):
    debug_work()

# Use Native OTEL for LLM operations
with native_manager.llm_span(provider="openai", model="gpt-4o") as span:
    llm_call()
```

---

## Configuration

### NativeOTELConfig

| Field                        | Type             | Default                | Description                   |
| ---------------------------- | ---------------- | ---------------------- | ----------------------------- |
| `enabled`                    | `bool`           | `False`                | Enable native OTEL            |
| `service_name`               | `str`            | `"autonomize-service"` | Service name for spans        |
| `enable_kafka`               | `bool`           | `False`                | Enable Kafka exporter         |
| `enable_eventhub`            | `bool`           | `False`                | Enable Event Hub exporter     |
| `enable_otlp_grpc`           | `bool`           | `False`                | Enable OTLP gRPC exporter     |
| `enable_otlp_http`           | `bool`           | `False`                | Enable OTLP HTTP exporter     |
| `enable_console`             | `bool`           | `False`                | Enable Console exporter       |
| `kafka_config`               | `KafkaConfig`    | `None`                 | Kafka configuration           |
| `event_hub_config`           | `EventHubConfig` | `field(...)`           | Event Hub configuration       |
| `otlp_config`                | `OTLPConfig`     | `None`                 | Shared OTLP configuration     |
| `otlp_grpc_config`           | `OTLPConfig`     | `None`                 | Protocol-specific gRPC config |
| `otlp_http_config`           | `OTLPConfig`     | `None`                 | Protocol-specific HTTP config |
| `set_global_provider`        | `bool`           | `True`                 | Register as global provider   |
| `batch_export`               | `bool`           | `True`                 | Use batch span processor      |
| `genai_semantic_conventions` | `bool`           | `True`                 | Transform to GenAI format     |

### EventHubConfig

| Field                       | Type   | Default         | Description                         |
| --------------------------- | ------ | --------------- | ----------------------------------- |
| `connection_string`         | `str`  | `None`          | Full connection string              |
| `fully_qualified_namespace` | `str`  | `None`          | e.g., `myns.servicebus.windows.net` |
| `eventhub_name`             | `str`  | `"otel-traces"` | Event Hub name                      |
| `restricted_eventhub_name`  | `str`  | `None`          | Restricted Event Hub for PHI        |
| `use_managed_identity`      | `bool` | `False`         | Use Azure managed identity          |
| `usecase_id`                | `str`  | `None`          | Application ID                      |

### OTLPConfig

| Field         | Type   | Default                   | Description             |
| ------------- | ------ | ------------------------- | ----------------------- |
| `endpoint`    | `str`  | `"http://localhost:4317"` | OTLP collector endpoint |
| `headers`     | `dict` | `{}`                      | Custom headers          |
| `insecure`    | `bool` | `True`                    | Use insecure GRPC       |
| `compression` | `str`  | `"gzip"`                  | Compression method      |

### Environment Variables

```bash
# Enable native OTEL
export NATIVE_OTEL_ENABLED=true
export NATIVE_OTEL_GENAI_CONVENTIONS=true

# Exporter Selection
export NATIVE_OTEL_ENABLE_KAFKA=true
export NATIVE_OTEL_ENABLE_EVENTHUB=true
export NATIVE_OTEL_ENABLE_OTLP_GRPC=false
export NATIVE_OTEL_ENABLE_OTLP_HTTP=false
export NATIVE_OTEL_ENABLE_CONSOLE=false

# Kafka config
export KAFKA_BOOTSTRAP_SERVERS=kafka:9092
export KAFKA_TRACE_TOPIC=otel-genai-traces
export KAFKA_SECURITY_PROTOCOL=SASL_SSL  # Optional
export KAFKA_SASL_MECHANISM=PLAIN

# Azure Event Hub
export AZURE_EVENTHUB_NAMESPACE=ai-obs-ehn-prod.servicebus.windows.net
export AZURE_EVENTHUB_NAME=ai-obs-comm-eh
export AZURE_EVENTHUB_RESTRICTED_NAME=ai-obs-restricted-eh
export AZURE_USE_MANAGED_IDENTITY=true
export AZURE_EVENTHUB_USECASE_ID=LIS

# OTLP config
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
export OTEL_EXPORTER_OTLP_INSECURE=true
export OTEL_EXPORTER_OTLP_COMPRESSION=gzip  # or none
```

---

## GenAI Semantic Conventions

The implementation follows the [OpenTelemetry GenAI Semantic Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/).

### Using Convenience Methods

```python
# LLM span with automatic GenAI attributes
with manager.llm_span(
    operation="chat",
    provider="openai",
    model="gpt-4o",
    input_tokens=150,
) as span:
    response = llm.chat(...)
    span.set_attribute("gen_ai.usage.output_tokens", 500)

# Tool span
with manager.tool_span(
    tool_name="get_weather",
    tool_call_id="call_123",
    arguments={"city": "NYC"},
) as span:
    result = get_weather("NYC")
    span.set_attribute("gen_ai.tool.call.result", str(result))

# Agent span
with manager.agent_span(
    agent_name="CustomerSupportAgent",
    agent_id="agent_456",
    model="gpt-4o",
    provider="openai",
) as span:
    response = agent.run(query)
```

### Using Attribute Helpers

```python
from autonomize_observer.schemas import (
    GenAIAttributes,
    create_genai_attributes,
)

# Create attributes
attrs = create_genai_attributes(
    operation="chat",
    provider="openai",
    model="gpt-4o",
    input_tokens=150,
    output_tokens=500,
)

# Use in span
with manager.span("my-operation", attributes=attrs) as span:
    pass

# Or set attributes directly
with manager.span("llm-call") as span:
    span.set_attribute(GenAIAttributes.OPERATION_NAME, "chat")
    span.set_attribute(GenAIAttributes.PROVIDER_NAME, "openai")
    span.set_attribute(GenAIAttributes.REQUEST_MODEL, "gpt-4o")
```

---

## Event Format

Events exported to Azure Event Hub:

```json
{
  "usecase_id": "LIS",
  "CTxID": "LIS-9f04c0b6029b4f2f9bc4d9dba7e3db9b",
  "context": {
    "trace_id": "9f04c0b6029b4f2f9bc4d9dba7e3db9b",
    "span_id": "b6c4b1ac5f3b4d5a"
  },
  "parent_id": "98b4fe4392f54681",
  "name": "chat",
  "status": { "code": 1, "message": null },
  "start_time": "2025-12-15T10:23:45Z",
  "end_time": "2025-12-15T10:23:45.8Z",
  "application_type": "gen_ai",
  "attributes": {
    "gen_ai.operation.name": "chat",
    "gen_ai.provider.name": "openai",
    "gen_ai.request.model": "gpt-4o",
    "gen_ai.response.model": "gpt-4o",
    "gen_ai.usage.input_tokens": 150,
    "gen_ai.usage.output_tokens": 500
  }
}
```

---

## PHI Routing

Spans containing PHI (Protected Health Information) are automatically routed to the restricted Event Hub if configured:

```python
# Configure restricted Event Hub
config = NativeOTELConfig(
    event_hub_config=EventHubConfig(
        eventhub_name="ai-obs-comm-eh",
        restricted_eventhub_name="ai-obs-restricted-eh",  # PHI goes here
    ),
)

# Explicitly mark span as containing PHI
with manager.span("process-member-data") as span:
    span.set_attribute("contains_phi", True)  # Routes to restricted EH
    process_sensitive_data()
```

PHI detection also triggers automatically for span names containing:

- `phi`, `pii`, `hipaa`, `member`, `patient`
- `ssn`, `dob`, `medical`, `health_record`

---

## New Files Added

| File                                       | Description                         |
| ------------------------------------------ | ----------------------------------- |
| `core/native_otel_config.py`               | Configuration classes               |
| `schemas/genai_conventions.py`             | GenAI semantic convention constants |
| `tracing/native_otel_manager.py`           | Core NativeOTELManager class        |
| `tracing/span_transformer.py`              | Attribute transformation            |
| `exporters/otel/__init__.py`               | OTEL exporters package              |
| `exporters/otel/kafka_span_exporter.py`    | Kafka SpanExporter                  |
| `exporters/otel/eventhub_span_exporter.py` | Azure Event Hub SpanExporter        |
| `exporters/otel/composite_exporter.py`     | Dual export support                 |

---

## API Reference

### NativeOTELManager

```python
class NativeOTELManager:
    def __init__(config: NativeOTELConfig): ...

    # Context manager spans
    def span(name, kind, attributes, **extra) -> Span: ...
    def llm_span(operation, provider, model, ...) -> Span: ...
    def tool_span(tool_name, tool_call_id, arguments) -> Span: ...
    def agent_span(agent_name, agent_id, model, provider) -> Span: ...

    # Manual span management
    def start_span(name, kind, attributes) -> Span: ...
    def end_span(span, error=None): ...

    # Lifecycle
    def shutdown(): ...
    def force_flush(timeout_millis) -> bool: ...

    # Properties
    @property is_available -> bool: ...
    @property tracer -> Tracer: ...
```

### GenAIAttributes

```python
class GenAIAttributes:
    OPERATION_NAME = "gen_ai.operation.name"
    PROVIDER_NAME = "gen_ai.provider.name"
    REQUEST_MODEL = "gen_ai.request.model"
    RESPONSE_MODEL = "gen_ai.response.model"
    USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
    # ... and more
```

### Helper Functions

```python
# Create GenAI attributes
create_genai_attributes(operation, provider, model, input_tokens, output_tokens, ...)
create_tool_attributes(tool_name, tool_call_id, arguments, result)
create_agent_attributes(agent_name, agent_id, model, provider, system_instructions)

# Transform legacy attributes
transform_to_genai(attributes, operation=None)
```
