"""Exporters for sending audit events to various destinations.

For OTEL trace/span export, use Logfire's built-in OTLP exporter,
or the native OTEL exporters (KafkaSpanExporter, EventHubSpanExporter).

These exporters focus on audit events, custom Kafka events,
and native OTEL span export.
"""

from autonomize_observer.core.imports import (
    AZURE_EVENTHUB_AVAILABLE,
    NATIVE_OTEL_AVAILABLE,
)
from autonomize_observer.exporters.base import BaseExporter, ExportResult
from autonomize_observer.exporters.kafka import KafkaExporter
from autonomize_observer.exporters.kafka_base import BaseKafkaProducer

__all__ = [
    "BaseExporter",
    "ExportResult",
    "KafkaExporter",
    "BaseKafkaProducer",
]

# Conditionally export native OTEL span exporters
if NATIVE_OTEL_AVAILABLE:
    from autonomize_observer.exporters.otel import (
        CompositeSpanExporter,
        KafkaSpanExporter,
    )

    __all__.extend([
        "KafkaSpanExporter",
        "CompositeSpanExporter",
    ])

    if AZURE_EVENTHUB_AVAILABLE:
        from autonomize_observer.exporters.otel import EventHubSpanExporter

        __all__.append("EventHubSpanExporter")
