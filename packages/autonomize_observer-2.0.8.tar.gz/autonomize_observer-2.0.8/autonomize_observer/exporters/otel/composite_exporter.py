"""Composite SpanExporter for dual export to multiple destinations.

Exports OTEL spans to multiple destinations simultaneously.

Usage:
    from autonomize_observer.exporters.otel import (
        CompositeSpanExporter,
        KafkaSpanExporter,
        EventHubSpanExporter,
    )

    # Create individual exporters
    kafka_exporter = KafkaSpanExporter(kafka_config=config)
    eventhub_exporter = EventHubSpanExporter(config=eventhub_config)

    # Create composite exporter
    composite = CompositeSpanExporter([kafka_exporter, eventhub_exporter])

    # Use with TracerProvider
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(composite))
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING, Sequence

from autonomize_observer.core.imports import (
    NATIVE_OTEL_AVAILABLE,
    SpanExporter,
    SpanExportResult,
)

if TYPE_CHECKING:
    from autonomize_observer.core.imports import ReadableSpan

logger = logging.getLogger(__name__)


class CompositeSpanExporter(SpanExporter):  # type: ignore[misc]
    """Composite exporter for simultaneous multi-destination export.

    Wraps multiple SpanExporter instances and exports spans to all
    destinations. Supports both parallel and sequential export modes.

    Features:
    - Export to multiple destinations (Kafka + Event Hub, etc.)
    - Parallel export for better performance
    - Partial success handling (continues if one exporter fails)
    - Unified statistics across all exporters

    Example:
        >>> from autonomize_observer.exporters.otel import (
        ...     CompositeSpanExporter,
        ...     KafkaSpanExporter,
        ...     EventHubSpanExporter,
        ... )
        >>>
        >>> composite = CompositeSpanExporter([
        ...     KafkaSpanExporter(kafka_config=config),
        ...     EventHubSpanExporter(config=eventhub_config),
        ... ])
    """

    def __init__(
        self,
        exporters: list[SpanExporter],
        parallel: bool = True,
        max_workers: int = 4,
        fail_fast: bool = False,
    ) -> None:
        """Initialize composite exporter.

        Args:
            exporters: List of SpanExporter instances
            parallel: Export to all destinations in parallel
            max_workers: Max threads for parallel export
            fail_fast: Stop on first failure (default: continue with others)

        Raises:
            ImportError: If opentelemetry-sdk not installed
            ValueError: If no exporters provided
        """
        if not NATIVE_OTEL_AVAILABLE:
            raise ImportError(
                "opentelemetry-sdk not installed. "
                "Install with: pip install opentelemetry-sdk opentelemetry-api"
            )

        if not exporters:
            raise ValueError("At least one exporter must be provided")

        self._exporters = exporters
        self._parallel = parallel
        self._max_workers = max_workers
        self._fail_fast = fail_fast

        # Statistics
        self._export_attempts = 0
        self._export_successes = 0
        self._export_failures = 0

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """Export spans to all destinations.

        Args:
            spans: Sequence of spans to export

        Returns:
            SpanExportResult.SUCCESS if all exporters succeed,
            SpanExportResult.FAILURE if any fail (unless fail_fast=False,
            in which case returns SUCCESS if at least one succeeds)
        """
        if not spans:
            return SpanExportResult.SUCCESS

        self._export_attempts += 1

        if self._parallel:
            result = self._export_parallel(spans)
        else:
            result = self._export_sequential(spans)

        if result == SpanExportResult.SUCCESS:
            self._export_successes += 1
        else:
            self._export_failures += 1

        return result

    def _export_parallel(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """Export spans to all destinations in parallel."""
        results: list[SpanExportResult] = []
        errors: list[str] = []

        with ThreadPoolExecutor(max_workers=self._max_workers) as executor:
            futures = {
                executor.submit(exporter.export, spans): exporter
                for exporter in self._exporters
            }

            for future in as_completed(futures):
                exporter = futures[future]
                exporter_name = type(exporter).__name__

                try:
                    result = future.result()
                    results.append(result)

                    if result == SpanExportResult.FAILURE:
                        errors.append(f"{exporter_name}: export failed")
                        if self._fail_fast:
                            break

                except Exception as e:
                    logger.error(
                        "Exporter raised exception",
                        extra={"exporter": exporter_name, "error": str(e)},
                    )
                    results.append(SpanExportResult.FAILURE)
                    errors.append(f"{exporter_name}: {e}")
                    if self._fail_fast:
                        break

        return self._aggregate_results(results, errors)

    def _export_sequential(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """Export spans to all destinations sequentially."""
        results: list[SpanExportResult] = []
        errors: list[str] = []

        for exporter in self._exporters:
            exporter_name = type(exporter).__name__

            try:
                result = exporter.export(spans)
                results.append(result)

                if result == SpanExportResult.FAILURE:
                    errors.append(f"{exporter_name}: export failed")
                    if self._fail_fast:
                        break

            except Exception as e:
                logger.error(
                    "Exporter raised exception",
                    extra={"exporter": exporter_name, "error": str(e)},
                )
                results.append(SpanExportResult.FAILURE)
                errors.append(f"{exporter_name}: {e}")
                if self._fail_fast:
                    break

        return self._aggregate_results(results, errors)

    def _aggregate_results(
        self,
        results: list[SpanExportResult],
        errors: list[str],
    ) -> SpanExportResult:
        """Aggregate results from multiple exporters.

        Args:
            results: List of export results
            errors: List of error messages

        Returns:
            SUCCESS if all succeed, or at least one succeeds (if not fail_fast)
            FAILURE if all fail, or any fail (if fail_fast)
        """
        if not results:
            return SpanExportResult.FAILURE

        successes = sum(1 for r in results if r == SpanExportResult.SUCCESS)
        failures = len(results) - successes

        if errors:
            logger.warning(
                f"Composite export partial failure: {failures}/{len(results)} "
                f"exporters failed. Errors: {errors}"
            )

        if self._fail_fast:
            # Any failure = overall failure
            if failures > 0:
                return SpanExportResult.FAILURE
            return SpanExportResult.SUCCESS
        else:
            # At least one success = overall success
            if successes > 0:
                return SpanExportResult.SUCCESS
            return SpanExportResult.FAILURE

    def shutdown(self) -> None:
        """Shutdown all exporters."""
        for exporter in self._exporters:
            try:
                exporter.shutdown()
            except Exception as e:
                logger.error(
                    "Error shutting down exporter",
                    extra={"exporter": type(exporter).__name__, "error": str(e)},
                )

        logger.debug(
            "Composite exporter shutdown",
            extra={
                "attempts": self._export_attempts,
                "successes": self._export_successes,
                "failures": self._export_failures,
            },
        )

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush all exporters.

        Args:
            timeout_millis: Timeout in milliseconds (divided among exporters)

        Returns:
            True if all exporters flushed successfully
        """
        timeout_per_exporter = timeout_millis // max(len(self._exporters), 1)
        all_flushed = True

        for exporter in self._exporters:
            try:
                if not exporter.force_flush(timeout_per_exporter):
                    all_flushed = False
            except Exception as e:
                logger.error(
                    "Error flushing exporter",
                    extra={"exporter": type(exporter).__name__, "error": str(e)},
                )
                all_flushed = False

        return all_flushed

    @property
    def stats(self) -> dict[str, Any]:
        """Get aggregated statistics from all exporters."""
        stats: dict[str, Any] = {
            "export_attempts": self._export_attempts,
            "export_successes": self._export_successes,
            "export_failures": self._export_failures,
            "exporters": {},
        }

        for exporter in self._exporters:
            exporter_name = type(exporter).__name__
            if hasattr(exporter, "stats"):
                stats["exporters"][exporter_name] = exporter.stats

        return stats

    @property
    def exporter_count(self) -> int:
        """Get number of wrapped exporters."""
        return len(self._exporters)


# Type import for type hints in stats property
from typing import Any

__all__ = ["CompositeSpanExporter"]
