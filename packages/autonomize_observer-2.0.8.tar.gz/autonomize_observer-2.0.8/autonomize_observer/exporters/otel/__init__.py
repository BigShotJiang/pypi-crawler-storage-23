"""OpenTelemetry Span Exporters for Native OTEL SDK.

This package provides SpanExporter implementations for exporting
OTEL spans to Kafka and Azure Event Hub.

Usage:
    from autonomize_observer.exporters.otel import (
        KafkaSpanExporter,
        EventHubSpanExporter,
        CompositeSpanExporter,
    )

    # Kafka export
    kafka_exporter = KafkaSpanExporter(kafka_config=config)

    # Event Hub export
    eventhub_exporter = EventHubSpanExporter(config=eventhub_config)

    # Both (composite)
    composite_exporter = CompositeSpanExporter([kafka_exporter, eventhub_exporter])
"""

from __future__ import annotations

from autonomize_observer.core.imports import (
    AZURE_EVENTHUB_AVAILABLE,
    NATIVE_OTEL_AVAILABLE,
)

# Conditional imports based on availability
if NATIVE_OTEL_AVAILABLE:
    from autonomize_observer.exporters.otel.composite_exporter import (
        CompositeSpanExporter,
    )
    from autonomize_observer.exporters.otel.kafka_span_exporter import (
        KafkaSpanExporter,
    )

    __all__ = [
        "KafkaSpanExporter",
        "CompositeSpanExporter",
    ]

    if AZURE_EVENTHUB_AVAILABLE:
        from autonomize_observer.exporters.otel.eventhub_span_exporter import (
            EventHubSpanExporter,
        )

        __all__.append("EventHubSpanExporter")
else:
    __all__ = []
