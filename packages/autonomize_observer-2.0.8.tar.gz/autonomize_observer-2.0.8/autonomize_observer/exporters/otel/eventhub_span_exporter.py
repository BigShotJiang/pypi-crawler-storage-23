"""Azure Event Hub SpanExporter for Native OpenTelemetry SDK.

Exports OTEL spans to Azure Event Hub in GenAI semantic convention format.

Usage:
    from autonomize_observer.exporters.otel import EventHubSpanExporter
    from autonomize_observer.core.native_otel_config import EventHubConfig

    exporter = EventHubSpanExporter(
        config=EventHubConfig(
            fully_qualified_namespace="myns.servicebus.windows.net",
            eventhub_name="otel-traces",
        ),
    )

    # Use with TracerProvider
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(exporter))
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any, Sequence

from autonomize_observer.core.imports import (
    AZURE_EVENTHUB_AVAILABLE,
    NATIVE_OTEL_AVAILABLE,
    DefaultAzureCredential,
    EventData,
    EventHubProducerClient,
    SpanExporter,
    SpanExportResult,
)
from autonomize_observer.schemas.genai_conventions import GenAIAttributes

if TYPE_CHECKING:
    from autonomize_observer.core.imports import ReadableSpan
    from autonomize_observer.core.native_otel_config import EventHubConfig

from autonomize_observer.core.phi_config import PHIDetectionConfig

logger = logging.getLogger(__name__)


class EventHubSpanExporter(SpanExporter):  # type: ignore[misc]
    """OpenTelemetry SpanExporter that sends spans to Azure Event Hub.

    Exports spans in the OTEL GenAI semantic convention format,
    compatible with the AI observability requirements.

    Features:
    - Azure Identity authentication (managed identity, workload identity)
    - Connection string authentication
    - PHI routing to restricted Event Hub
    - Batch sending for efficiency
    - Partitioning by trace_id/usecase_id

    Example:
        >>> from autonomize_observer.exporters.otel import EventHubSpanExporter
        >>> from autonomize_observer.core.native_otel_config import EventHubConfig
        >>>
        >>> exporter = EventHubSpanExporter(
        ...     config=EventHubConfig(
        ...         fully_qualified_namespace="myns.servicebus.windows.net",
        ...         eventhub_name="otel-traces",
        ...         use_managed_identity=True,
        ...     ),
        ... )
    """

    def __init__(
        self,
        config: EventHubConfig,
        transform_to_genai: bool = True,
        phi_config: PHIDetectionConfig | None = None,
    ) -> None:
        """Initialize Event Hub span exporter.

        Args:
            config: Event Hub configuration
            transform_to_genai: Transform spans to GenAI convention format
            phi_config: PHI detection configuration (uses defaults if not provided)

        Raises:
            ImportError: If required dependencies not installed
        """
        if not NATIVE_OTEL_AVAILABLE:
            raise ImportError(
                "opentelemetry-sdk not installed. "
                "Install with: pip install opentelemetry-sdk opentelemetry-api"
            )

        if not AZURE_EVENTHUB_AVAILABLE:
            raise ImportError(
                "azure-eventhub not installed. "
                "Install with: pip install azure-eventhub azure-identity"
            )

        self._config = config
        self._transform_to_genai = transform_to_genai
        self._usecase_id = config.usecase_id or "GenericApp"
        self._phi_config = phi_config or PHIDetectionConfig()

        # Producers (lazy initialized)
        self._producer: EventHubProducerClient | None = None
        self._restricted_producer: EventHubProducerClient | None = None

        # Statistics
        self._spans_exported = 0
        self._spans_failed = 0

    def _get_producer(self, restricted: bool = False) -> EventHubProducerClient:
        """Get or create Event Hub producer (lazy initialization)."""
        if restricted:
            if self._restricted_producer is None:
                eventhub_name = (
                    self._config.restricted_eventhub_name or self._config.eventhub_name
                )
                self._restricted_producer = self._create_producer(eventhub_name)
            return self._restricted_producer
        else:
            if self._producer is None:
                self._producer = self._create_producer(self._config.eventhub_name)
            return self._producer

    def _create_producer(self, eventhub_name: str) -> EventHubProducerClient:
        """Create an Event Hub producer client."""
        if self._config.connection_string:
            # Connection string authentication
            return EventHubProducerClient.from_connection_string(
                conn_str=self._config.connection_string,
                eventhub_name=eventhub_name,
            )
        elif self._config.fully_qualified_namespace:
            # Azure Identity authentication
            credential = self._get_credential()
            return EventHubProducerClient(
                fully_qualified_namespace=self._config.fully_qualified_namespace,
                eventhub_name=eventhub_name,
                credential=credential,
            )
        else:
            raise ValueError(
                "Event Hub not configured: provide connection_string or "
                "fully_qualified_namespace"
            )

    def _get_credential(self) -> Any:
        """Get Azure credential based on configuration."""
        if self._config.credential_type == "default":
            return DefaultAzureCredential()
        elif self._config.credential_type == "managed":
            from azure.identity import ManagedIdentityCredential

            return ManagedIdentityCredential()
        elif self._config.credential_type == "workload":
            from azure.identity import WorkloadIdentityCredential

            return WorkloadIdentityCredential()
        else:
            return DefaultAzureCredential()

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """Export spans to Azure Event Hub.

        Args:
            spans: Sequence of spans to export

        Returns:
            SpanExportResult.SUCCESS or SpanExportResult.FAILURE
        """
        if not spans:
            return SpanExportResult.SUCCESS

        try:
            # Separate PHI and non-PHI spans
            regular_events: list[EventData] = []
            restricted_events: list[EventData] = []

            for span in spans:
                try:
                    event = self._span_to_event_data(span)
                    if self._is_phi_span(span):
                        restricted_events.append(event)
                    else:
                        regular_events.append(event)
                except Exception as e:
                    logger.error(
                        "Failed to convert span to event: %s (span=%s)",
                        e,
                        span.name,
                    )
                    self._spans_failed += 1

            # Send regular events
            if regular_events:
                self._send_batch(self._get_producer(restricted=False), regular_events)

            # Send restricted events
            if restricted_events:
                if self._config.restricted_eventhub_name:
                    self._send_batch(
                        self._get_producer(restricted=True), restricted_events
                    )
                else:
                    # No restricted Event Hub configured, send to regular
                    logger.warning(
                        "PHI spans detected but no restricted Event Hub configured. Sending to regular Event Hub.",
                        extra={"span_count": len(restricted_events)},
                    )
                    self._send_batch(
                        self._get_producer(restricted=False), restricted_events
                    )

            return SpanExportResult.SUCCESS

        except Exception as e:
            self._spans_failed += len(spans)
            logger.error(
                "Failed to export spans to Event Hub: [%s] %s (count=%d)",
                type(e).__name__,
                e,
                len(spans),
                exc_info=True,
            )
            return SpanExportResult.FAILURE

    def _span_to_event_data(self, span: ReadableSpan) -> EventData:
        """Convert OTEL span to Event Hub EventData.

        Args:
            span: OpenTelemetry span

        Returns:
            EventData for Event Hub
        """
        event_dict = self._span_to_dict(span)
        body = json.dumps(event_dict).encode("utf-8")

        event = EventData(body)

        # Set properties for routing/filtering
        context = span.get_span_context()
        event.properties = {
            "usecase_id": self._usecase_id,
            "trace_id": format(context.trace_id, "032x"),
            "span_name": span.name,
        }

        return event

    def _span_to_dict(self, span: ReadableSpan) -> dict[str, Any]:
        """Convert OTEL span to required format dictionary."""
        context = span.get_span_context()
        trace_id = format(context.trace_id, "032x")
        span_id = format(context.span_id, "016x")

        event: dict[str, Any] = {
            "usecase_id": self._usecase_id,
            "organization_id": self._extract_resource_attribute(
                span, "autonomize.organization_id"
            ),
            "project_id": self._extract_resource_attribute(
                span, "autonomize.project_id"
            ),
            "CTxID": f"{self._usecase_id}-{trace_id}",
            "context": {
                "trace_id": trace_id,
                "span_id": span_id,
            },
            "parent_id": (format(span.parent.span_id, "016x") if span.parent else None),
            "name": span.name,
            "status": {
                "code": span.status.status_code.value if span.status else 0,
                "message": span.status.description if span.status else None,
            },
            "start_time": self._format_time(span.start_time),
            "end_time": self._format_time(span.end_time),
            "application_type": "gen_ai",
            "attributes": self._extract_attributes(span),
        }

        return event

    def _extract_attributes(self, span: ReadableSpan) -> dict[str, Any]:
        """Extract and optionally transform span attributes."""
        attrs = dict(span.attributes or {})

        if not self._transform_to_genai:
            return attrs

        genai_attrs: dict[str, Any] = {}

        for key, value in attrs.items():
            if key.startswith("gen_ai."):
                genai_attrs[key] = value
            else:
                mapped_key = self._map_attribute_key(key)
                if mapped_key:
                    genai_attrs[mapped_key] = value

        if GenAIAttributes.OPERATION_NAME not in genai_attrs:
            genai_attrs[GenAIAttributes.OPERATION_NAME] = self._infer_operation(span)

        return genai_attrs

    def _map_attribute_key(self, key: str) -> str | None:
        """Map legacy attribute key to GenAI convention."""
        mapping = {
            "model": GenAIAttributes.REQUEST_MODEL,
            "provider": GenAIAttributes.PROVIDER_NAME,
            "input_tokens": GenAIAttributes.USAGE_INPUT_TOKENS,
            "output_tokens": GenAIAttributes.USAGE_OUTPUT_TOKENS,
            "cost": GenAIAttributes.COST,
        }
        return mapping.get(key)

    def _extract_resource_attribute(self, span: ReadableSpan, key: str) -> str | None:
        """Extract attribute from span resource."""
        if hasattr(span, "resource") and span.resource:
            return span.resource.attributes.get(key)  # type: ignore
        return None

    def _infer_operation(self, span: ReadableSpan) -> str:
        """Infer GenAI operation from span name."""
        name_lower = span.name.lower()

        if "chat" in name_lower:
            return "chat"
        if "tool" in name_lower:
            return "execute_tool"
        if "agent" in name_lower:
            return "invoke_agent"

        return "chat"

    def _is_phi_span(self, span: ReadableSpan) -> bool:
        """Check if span contains PHI data using configurable detection.

        Uses PHIDetectionConfig for word boundary regex matching to prevent
        false positives (e.g., "member" won't match "team_member_count").

        Args:
            span: Span to check

        Returns:
            True if span should go to restricted Event Hub
        """
        attrs = span.attributes or {}

        # Check for explicit PHI flag (configurable attribute name)
        if attrs.get(self._phi_config.attribute_flag, False):
            return True

        # Check span name using word boundary regex matching
        return self._phi_config.matches(span.name)

    def _send_batch(
        self,
        producer: EventHubProducerClient,
        events: list[EventData],
    ) -> None:
        """Send a batch of events to Event Hub with retry support."""
        # Create batch with partition key for ordering
        batch = producer.create_batch(partition_key=self._usecase_id)

        for event in events:
            try:
                batch.add(event)
            except ValueError:
                # Batch full, send and create new
                self._send_with_retry(producer, batch)
                batch = producer.create_batch(partition_key=self._usecase_id)
                batch.add(event)

        # Send remaining
        if len(batch) > 0:
            self._send_with_retry(producer, batch)
            self._spans_exported += len(events)

    def _send_with_retry(
        self,
        producer: EventHubProducerClient,
        batch: Any,
    ) -> None:
        """Send batch with exponential backoff retry for transient failures.

        Args:
            producer: Event Hub producer client
            batch: Event batch to send
        """
        import time

        delay = self._config.retry_delay_seconds
        last_error: Exception | None = None

        for attempt in range(self._config.max_retries + 1):
            try:
                producer.send_batch(batch)
                return
            except Exception as e:
                # Check if it's a retryable error
                error_str = str(e).lower()
                is_retryable = any(
                    term in error_str
                    for term in ["busy", "timeout", "unavailable", "throttl"]
                )

                if is_retryable and attempt < self._config.max_retries:
                    last_error = e
                    logger.warning(
                        "Event Hub transient error, retrying",
                        extra={
                            "attempt": attempt + 1,
                            "max_retries": self._config.max_retries,
                            "delay_seconds": delay,
                            "error": str(e),
                        },
                    )
                    time.sleep(delay)
                    delay = min(
                        delay * self._config.retry_backoff_multiplier,
                        self._config.retry_max_delay_seconds,
                    )
                else:
                    # Non-retryable error or max retries exceeded
                    logger.error(
                        "Event Hub send failed",
                        extra={
                            "error": str(e),
                            "attempt": attempt + 1,
                            "retryable": is_retryable,
                        },
                    )
                    last_error = e
                    break

        # All retries exhausted (shouldn't reach here, but just in case)
        if last_error:
            raise last_error

    def _format_time(self, ns_timestamp: int | None) -> str | None:
        """Format nanosecond timestamp to ISO format."""
        if ns_timestamp is None:
            return None
        from datetime import datetime, timezone

        dt = datetime.fromtimestamp(ns_timestamp / 1e9, tz=timezone.utc)
        return dt.isoformat()

    def shutdown(self) -> None:
        """Shutdown the exporter."""
        if self._producer:
            self._producer.close()
            self._producer = None

        if self._restricted_producer:
            self._restricted_producer.close()
            self._restricted_producer = None

        logger.debug(
            f"Event Hub exporter shutdown. Exported: {self._spans_exported}, "
            f"Failed: {self._spans_failed}"
        )

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush pending spans.

        Args:
            timeout_millis: Timeout in milliseconds (not used for Event Hub)

        Returns:
            True (Event Hub sends synchronously)
        """
        # Event Hub client sends synchronously, no flush needed
        return True

    @property
    def stats(self) -> dict[str, int]:
        """Get exporter statistics."""
        return {
            "spans_exported": self._spans_exported,
            "spans_failed": self._spans_failed,
        }


__all__ = ["EventHubSpanExporter"]
