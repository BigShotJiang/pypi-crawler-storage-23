"""Kafka SpanExporter for Native OpenTelemetry SDK.

Exports OTEL spans to Kafka in GenAI semantic convention format.

Usage:
    from autonomize_observer.exporters.otel import KafkaSpanExporter
    from autonomize_observer.core.config import KafkaConfig

    exporter = KafkaSpanExporter(
        kafka_config=KafkaConfig(bootstrap_servers="kafka:9092"),
        topic="otel-genai-traces",
    )

    # Use with TracerProvider
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(exporter))
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any, Sequence

from autonomize_observer.core.imports import (
    CONFLUENT_KAFKA_AVAILABLE,
    NATIVE_OTEL_AVAILABLE,
    ConfluentProducer,
    SpanExporter,
    SpanExportResult,
)
from autonomize_observer.schemas.genai_conventions import GenAIAttributes

if TYPE_CHECKING:
    from autonomize_observer.core.config import KafkaConfig
    from autonomize_observer.core.imports import ReadableSpan

from autonomize_observer.core.phi_config import PHIDetectionConfig

logger = logging.getLogger(__name__)


class KafkaSpanExporter(SpanExporter):  # type: ignore[misc]
    """OpenTelemetry SpanExporter that sends spans to Kafka.

    Exports spans in the OTEL GenAI semantic convention format,
    compatible with the AI observability requirements.

    Features:
    - Batch export support
    - Partitioning by trace_id for ordering
    - GenAI attribute transformation
    - Fire-and-forget mode for low latency

    Example:
        >>> from autonomize_observer.exporters.otel import KafkaSpanExporter
        >>> from autonomize_observer.core.config import KafkaConfig
        >>>
        >>> exporter = KafkaSpanExporter(
        ...     kafka_config=KafkaConfig(bootstrap_servers="kafka:9092"),
        ...     topic="otel-traces",
        ... )
    """

    def __init__(
        self,
        kafka_config: KafkaConfig,
        topic: str | None = None,
        restricted_topic: str | None = None,
        usecase_id: str = "GenericApp",
        transform_to_genai: bool = True,
        low_latency: bool = True,
        phi_config: PHIDetectionConfig | None = None,
    ) -> None:
        """Initialize Kafka span exporter.

        Args:
            kafka_config: Kafka configuration
            topic: Override topic (defaults to kafka_config.trace_topic)
            restricted_topic: Topic for PHI/PII spans (defaults to kafka_config.restricted_topic)
            usecase_id: Application identifier
            transform_to_genai: Transform spans to GenAI convention format
            low_latency: Use fire-and-forget mode for low latency
            phi_config: PHI detection configuration (uses defaults if not provided)

        Raises:
            ImportError: If required dependencies not installed
        """
        if not NATIVE_OTEL_AVAILABLE:
            raise ImportError(
                "opentelemetry-sdk not installed. "
                "Install with: pip install opentelemetry-sdk opentelemetry-api"
            )

        if not CONFLUENT_KAFKA_AVAILABLE:
            raise ImportError(
                "confluent-kafka not installed. "
                "Install with: pip install confluent-kafka"
            )

        self._config = kafka_config
        self._topic = topic or kafka_config.trace_topic
        self._restricted_topic = restricted_topic or kafka_config.restricted_topic
        self._usecase_id = usecase_id
        self._transform_to_genai = transform_to_genai
        self._low_latency = low_latency
        self._phi_config = phi_config or PHIDetectionConfig()
        self._producer: Any | None = None

        # Statistics
        self._spans_exported = 0
        self._spans_failed = 0

    def _get_producer(self) -> Any:
        """Get or create Kafka producer (lazy initialization)."""
        if self._producer is None:
            config = self._build_producer_config()
            self._producer = ConfluentProducer(config)
            logger.debug("Kafka producer initialized", extra={"topic": self._topic})
        return self._producer

    def _build_producer_config(self) -> dict[str, Any]:
        """Build Kafka producer configuration."""
        config: dict[str, Any] = {
            "bootstrap.servers": self._config.bootstrap_servers,
            "client.id": f"{self._config.client_id}-otel-exporter",
        }

        # Low latency settings
        if self._low_latency:
            config.update(
                {
                    "linger.ms": 0,
                    "batch.size": 1,  # Minimum allowed by librdkafka (0 is invalid)
                    "request.required.acks": 0,
                    "socket.nagle.disable": True,
                }
            )
        else:
            config.update(
                {
                    "linger.ms": self._config.linger_ms,
                    "batch.size": self._config.batch_size * 1024,
                    "request.required.acks": 1 if self._config.acks == "all" else 0,
                }
            )

        # Security settings
        if self._config.security_protocol:
            config["security.protocol"] = self._config.security_protocol

        if self._config.sasl_mechanism:
            config["sasl.mechanism"] = self._config.sasl_mechanism

        if self._config.sasl_username:
            config["sasl.username"] = self._config.sasl_username

        if self._config.sasl_password:
            config["sasl.password"] = self._config.sasl_password

        # SSL settings (required for SASL_SSL)
        if (
            self._config.security_protocol
            and "SSL" in self._config.security_protocol.upper()
        ):
            ssl_ca_location = getattr(self._config, "ssl_ca_location", None)
            if ssl_ca_location:
                config["ssl.ca.location"] = ssl_ca_location
            else:
                # Use system CA certificates by default (probe for common paths)
                config["enable.ssl.certificate.verification"] = True

        return config

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """Export spans to Kafka with PHI routing support.

        PHI spans are routed to the restricted topic if configured.
        Non-PHI spans go to the regular topic.

        Args:
            spans: Sequence of spans to export

        Returns:
            SpanExportResult.SUCCESS or SpanExportResult.FAILURE
        """
        if not spans:
            return SpanExportResult.SUCCESS

        try:
            producer = self._get_producer()

            for span in spans:
                try:
                    event = self._span_to_event(span)
                    key = self._get_partition_key(span)

                    # Determine target topic based on PHI status
                    target_topic = self._topic
                    if self._is_phi_span(span):
                        if self._restricted_topic:
                            target_topic = self._restricted_topic
                        else:
                            logger.warning(
                                "PHI span detected but no restricted topic configured",
                                extra={"span_name": span.name},
                            )

                    producer.produce(
                        topic=target_topic,
                        key=key.encode("utf-8") if key else None,
                        value=json.dumps(event).encode("utf-8"),
                        callback=self._delivery_callback,
                    )
                    self._spans_exported += 1

                except Exception as e:
                    logger.error(
                        "Failed to produce span to Kafka: %s (span=%s)",
                        e,
                        span.name,
                    )
                    self._spans_failed += 1

            # Trigger delivery (non-blocking)
            producer.poll(0)

            return SpanExportResult.SUCCESS

        except Exception as e:
            self._spans_failed += len(spans)
            logger.error(
                "Failed to export spans to Kafka: [%s] %s (count=%d)",
                type(e).__name__,
                e,
                len(spans),
                exc_info=True,
            )
            return SpanExportResult.FAILURE

    def _is_phi_span(self, span: ReadableSpan) -> bool:
        """Check if span contains PHI data using configurable detection.

        Uses PHIDetectionConfig for word boundary regex matching to prevent
        false positives (e.g., "member" won't match "team_member_count").

        Args:
            span: Span to check

        Returns:
            True if span should go to restricted topic
        """
        attrs = span.attributes or {}

        # Check for explicit PHI flag (configurable attribute name)
        if attrs.get(self._phi_config.attribute_flag, False):
            return True

        # Check span name using word boundary regex matching
        return self._phi_config.matches(span.name)

    def _span_to_event(self, span: ReadableSpan) -> dict[str, Any]:
        """Convert OTEL span to required format event.

        Args:
            span: OpenTelemetry span

        Returns:
            Event dictionary in required format
        """
        context = span.get_span_context()
        trace_id = format(context.trace_id, "032x")
        span_id = format(context.span_id, "016x")

        # Build base event structure
        event: dict[str, Any] = {
            "usecase_id": self._usecase_id,
            "organization_id": self._extract_resource_attribute(
                span, "autonomize.organization_id"
            ),
            "project_id": self._extract_resource_attribute(
                span, "autonomize.project_id"
            ),
            "CTxID": f"{self._usecase_id}-{trace_id}",
            "context": {
                "trace_id": trace_id,
                "span_id": span_id,
            },
            "parent_id": (format(span.parent.span_id, "016x") if span.parent else None),
            "name": span.name,
            "status": {
                "code": span.status.status_code.value if span.status else 0,
                "message": span.status.description if span.status else None,
            },
            "start_time": self._format_time(span.start_time),
            "end_time": self._format_time(span.end_time),
            "application_type": "gen_ai",
            "attributes": self._extract_attributes(span),
        }

        return event

    def _extract_attributes(self, span: ReadableSpan) -> dict[str, Any]:
        """Extract and optionally transform span attributes."""
        attrs = dict(span.attributes or {})

        if not self._transform_to_genai:
            return attrs

        # Ensure GenAI attributes are present
        genai_attrs: dict[str, Any] = {}

        for key, value in attrs.items():
            if key.startswith("gen_ai."):
                genai_attrs[key] = value
            else:
                # Map legacy attributes to GenAI conventions
                mapped_key = self._map_attribute_key(key)
                if mapped_key:
                    genai_attrs[mapped_key] = value

        # Ensure operation name is set
        if GenAIAttributes.OPERATION_NAME not in genai_attrs:
            genai_attrs[GenAIAttributes.OPERATION_NAME] = self._infer_operation(span)

        return genai_attrs

    def _map_attribute_key(self, key: str) -> str | None:
        """Map legacy attribute key to GenAI convention."""
        mapping = {
            "model": GenAIAttributes.REQUEST_MODEL,
            "provider": GenAIAttributes.PROVIDER_NAME,
            "input_tokens": GenAIAttributes.USAGE_INPUT_TOKENS,
            "output_tokens": GenAIAttributes.USAGE_OUTPUT_TOKENS,
            "total_tokens": GenAIAttributes.USAGE_TOTAL_TOKENS,
            "temperature": GenAIAttributes.REQUEST_TEMPERATURE,
            "max_tokens": GenAIAttributes.REQUEST_MAX_TOKENS,
            "response_id": GenAIAttributes.RESPONSE_ID,
            "cost": GenAIAttributes.COST,
            "system_prompt": GenAIAttributes.SYSTEM_INSTRUCTIONS,
            "tool_name": GenAIAttributes.TOOL_NAME,
            "tool_call_id": GenAIAttributes.TOOL_CALL_ID,
            "agent_name": GenAIAttributes.AGENT_NAME,
            "agent_id": GenAIAttributes.AGENT_ID,
        }
        return mapping.get(key)

    def _infer_operation(self, span: ReadableSpan) -> str:
        """Infer GenAI operation from span name."""
        name_lower = span.name.lower()

        if "chat" in name_lower:
            return "chat"
        if "complet" in name_lower:
            return "text_completion"
        if "embed" in name_lower:
            return "embeddings"
        if "tool" in name_lower or "function" in name_lower:
            return "execute_tool"
        if "agent" in name_lower:
            return "invoke_agent"

        return "chat"  # Default

    def _extract_resource_attribute(self, span: ReadableSpan, key: str) -> str | None:
        """Extract attribute from span resource."""
        if hasattr(span, "resource") and span.resource:
            return span.resource.attributes.get(key)  # type: ignore
        return None

    def _get_partition_key(self, span: ReadableSpan) -> str:
        """Get partition key for Kafka message."""
        context = span.get_span_context()
        return format(context.trace_id, "032x")

    def _format_time(self, ns_timestamp: int | None) -> str | None:
        """Format nanosecond timestamp to ISO format."""
        if ns_timestamp is None:
            return None
        from datetime import datetime, timezone

        dt = datetime.fromtimestamp(ns_timestamp / 1e9, tz=timezone.utc)
        return dt.isoformat()

    def _delivery_callback(self, err: Any, msg: Any) -> None:
        """Callback for Kafka delivery reports."""
        if err is not None:
            logger.warning("Span delivery failed", extra={"error": str(err)})
            self._spans_failed += 1

    def shutdown(self) -> None:
        """Shutdown the exporter."""
        if self._producer:
            self._producer.flush(timeout=5.0)
            logger.debug(
                f"Kafka exporter shutdown. Exported: {self._spans_exported}, "
                f"Failed: {self._spans_failed}"
            )

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush pending spans.

        Args:
            timeout_millis: Timeout in milliseconds

        Returns:
            True if flush succeeded
        """
        if self._producer:
            remaining = self._producer.flush(timeout=timeout_millis / 1000)
            return remaining == 0
        return True

    @property
    def stats(self) -> dict[str, int]:
        """Get exporter statistics."""
        return {
            "spans_exported": self._spans_exported,
            "spans_failed": self._spans_failed,
        }


__all__ = ["KafkaSpanExporter"]
