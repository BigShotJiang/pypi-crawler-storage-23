"""Schema definitions for Autonomize Observer.

Provides audit event schemas, enums, and GenAI semantic conventions.
For OTEL spans, Logfire handles the schema internally.
"""

from autonomize_observer.schemas.audit import AuditEvent, ChangeRecord
from autonomize_observer.schemas.base import BaseEvent
from autonomize_observer.schemas.enums import (
    AuditAction,
    AuditEventType,
    AuditOutcome,
    AuditSeverity,
    ComplianceFramework,
    EventCategory,
    ResourceType,
)
from autonomize_observer.schemas.genai_conventions import (
    GenAIAttributes,
    GenAIOperations,
    GenAIProviders,
    build_genai_span_name,
    create_agent_attributes,
    create_genai_attributes,
    create_tool_attributes,
)

__all__ = [
    # Base
    "BaseEvent",
    # Enums
    "EventCategory",
    "AuditEventType",
    "AuditAction",
    "AuditSeverity",
    "AuditOutcome",
    "ComplianceFramework",
    "ResourceType",
    # Audit
    "AuditEvent",
    "ChangeRecord",
    # GenAI Semantic Conventions
    "GenAIAttributes",
    "GenAIOperations",
    "GenAIProviders",
    "build_genai_span_name",
    "create_genai_attributes",
    "create_tool_attributes",
    "create_agent_attributes",
]
