"""OpenTelemetry GenAI Semantic Conventions.

This module provides constants and utilities for the OpenTelemetry
GenAI semantic conventions as defined in the OTEL specification.

Reference: https://opentelemetry.io/docs/specs/semconv/gen-ai/

Usage:
    from autonomize_observer.schemas.genai_conventions import (
        GenAIAttributes,
        GenAIOperations,
        create_genai_attributes,
    )

    # Use constants for attribute names
    span.set_attribute(GenAIAttributes.OPERATION_NAME, GenAIOperations.CHAT)
    span.set_attribute(GenAIAttributes.REQUEST_MODEL, "gpt-4o")

    # Or use helper function
    attrs = create_genai_attributes(
        operation="chat",
        provider="openai",
        model="gpt-4o",
        input_tokens=100,
        output_tokens=50,
    )
"""

from __future__ import annotations

from typing import Any


class GenAIAttributes:
    """OpenTelemetry GenAI semantic convention attribute names.

    These follow the OTEL GenAI specification:
    https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-spans/
    """

    # =========================================================================
    # Operation Attributes (Required)
    # =========================================================================
    OPERATION_NAME = "gen_ai.operation.name"
    """The name of the operation being performed (e.g., chat, text_completion)."""

    # =========================================================================
    # System/Provider Attributes
    # =========================================================================
    SYSTEM = "gen_ai.system"
    """The Generative AI system (e.g., openai, anthropic)."""

    PROVIDER_NAME = "gen_ai.provider.name"
    """The name of the GenAI provider (e.g., openai, anthropic, azure)."""

    # =========================================================================
    # Request Attributes
    # =========================================================================
    REQUEST_MODEL = "gen_ai.request.model"
    """The name of the model being requested."""

    REQUEST_TEMPERATURE = "gen_ai.request.temperature"
    """The temperature setting for the GenAI request."""

    REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
    """The maximum number of tokens to generate."""

    REQUEST_TOP_P = "gen_ai.request.top_p"
    """The top_p (nucleus sampling) setting."""

    REQUEST_TOP_K = "gen_ai.request.top_k"
    """The top_k setting for token sampling."""

    REQUEST_STOP_SEQUENCES = "gen_ai.request.stop_sequences"
    """List of stop sequences."""

    REQUEST_FREQUENCY_PENALTY = "gen_ai.request.frequency_penalty"
    """Frequency penalty setting."""

    REQUEST_PRESENCE_PENALTY = "gen_ai.request.presence_penalty"
    """Presence penalty setting."""

    # =========================================================================
    # Response Attributes
    # =========================================================================
    RESPONSE_MODEL = "gen_ai.response.model"
    """The name of the model that generated the response."""

    RESPONSE_ID = "gen_ai.response.id"
    """The unique identifier for the response."""

    RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons"
    """The reason(s) the model stopped generating tokens."""

    # =========================================================================
    # Usage/Token Attributes
    # =========================================================================
    USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    """The number of tokens in the input/prompt."""

    USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
    """The number of tokens in the output/completion."""

    USAGE_TOTAL_TOKENS = "gen_ai.usage.total_tokens"
    """The total number of tokens (input + output)."""

    # =========================================================================
    # Content Attributes (opt-in, may contain sensitive data)
    # =========================================================================
    INPUT_MESSAGES = "gen_ai.input.messages"
    """The input messages/prompt (may contain PII)."""

    OUTPUT_MESSAGES = "gen_ai.output.messages"
    """The output messages/completion (may contain PII)."""

    SYSTEM_INSTRUCTIONS = "gen_ai.system_instructions"
    """The system message or instructions provided."""

    # =========================================================================
    # Tool/Function Calling Attributes
    # =========================================================================
    TOOL_NAME = "gen_ai.tool.name"
    """The name of the tool being called."""

    TOOL_CALL_ID = "gen_ai.tool.call.id"
    """The unique identifier for the tool call."""

    TOOL_CALL_ARGUMENTS = "gen_ai.tool.call.arguments"
    """The arguments passed to the tool call."""

    TOOL_CALL_RESULT = "gen_ai.tool.call.result"
    """The result returned by the tool call."""

    # =========================================================================
    # Agent Attributes
    # =========================================================================
    AGENT_ID = "gen_ai.agent.id"
    """Unique identifier of the GenAI agent."""

    AGENT_NAME = "gen_ai.agent.name"
    """Human-readable name of the GenAI agent."""

    AGENT_DESCRIPTION = "gen_ai.agent.description"
    """Free-form description of the GenAI agent."""

    # =========================================================================
    # Conversation/Session Attributes
    # =========================================================================
    CONVERSATION_ID = "gen_ai.conversation.id"
    """The conversation/thread identifier."""

    # =========================================================================
    # Custom Extensions (not in OTEL spec)
    # =========================================================================
    COST = "gen_ai.cost"
    """The estimated cost of the operation (USD)."""

    COST_CURRENCY = "gen_ai.cost.currency"
    """The currency of the cost (default: USD)."""

    LATENCY_MS = "gen_ai.latency_ms"
    """The latency of the operation in milliseconds."""


class GenAIOperations:
    """Standard operation names for GenAI spans."""

    CHAT = "chat"
    """Chat completion operation."""

    TEXT_COMPLETION = "text_completion"
    """Text completion operation."""

    EMBEDDINGS = "embeddings"
    """Embeddings generation operation."""

    INVOKE_AGENT = "invoke_agent"
    """Agent invocation operation."""

    EXECUTE_TOOL = "execute_tool"
    """Tool/function execution operation."""

    IMAGE_GENERATION = "image_generation"
    """Image generation operation."""

    AUDIO_TRANSCRIPTION = "audio_transcription"
    """Audio transcription operation."""

    AUDIO_GENERATION = "audio_generation"
    """Audio/speech generation operation."""


class GenAIProviders:
    """Known GenAI provider names."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    AZURE = "azure"
    AWS_BEDROCK = "aws.bedrock"
    COHERE = "cohere"
    MISTRAL = "mistral"
    META = "meta"
    HUGGINGFACE = "huggingface"


def build_genai_span_name(
    operation: str,
    model: str | None = None,
    provider: str | None = None,
) -> str:
    """Build a span name following GenAI conventions.

    Args:
        operation: The operation name (e.g., "chat", "embeddings")
        model: Optional model name
        provider: Optional provider name

    Returns:
        A span name like "chat gpt-4o" or "openai.chat"

    Examples:
        >>> build_genai_span_name("chat", "gpt-4o")
        'chat gpt-4o'
        >>> build_genai_span_name("embeddings", provider="openai")
        'openai.embeddings'
    """
    if model:
        return f"{operation} {model}"
    if provider:
        return f"{provider}.{operation}"
    return operation


def create_genai_attributes(
    operation: str,
    provider: str | None = None,
    model: str | None = None,
    input_tokens: int | None = None,
    output_tokens: int | None = None,
    response_id: str | None = None,
    finish_reasons: list[str] | None = None,
    temperature: float | None = None,
    max_tokens: int | None = None,
    cost: float | None = None,
    **extra: Any,
) -> dict[str, Any]:
    """Create a dictionary of GenAI attributes.

    This is a convenience function for building GenAI-compliant
    span attributes.

    Args:
        operation: The operation name (required)
        provider: Provider name (e.g., "openai")
        model: Model name (e.g., "gpt-4o")
        input_tokens: Number of input tokens
        output_tokens: Number of output tokens
        response_id: Response identifier
        finish_reasons: List of finish reasons
        temperature: Temperature setting
        max_tokens: Max tokens setting
        cost: Estimated cost (USD)
        **extra: Additional attributes (will be prefixed with gen_ai. if not already)

    Returns:
        Dictionary of GenAI attributes

    Examples:
        >>> attrs = create_genai_attributes(
        ...     operation="chat",
        ...     provider="openai",
        ...     model="gpt-4o",
        ...     input_tokens=150,
        ...     output_tokens=500,
        ... )
        >>> attrs[GenAIAttributes.OPERATION_NAME]
        'chat'
    """
    attrs: dict[str, Any] = {
        GenAIAttributes.OPERATION_NAME: operation,
    }

    if provider is not None:
        attrs[GenAIAttributes.PROVIDER_NAME] = provider

    if model is not None:
        attrs[GenAIAttributes.REQUEST_MODEL] = model
        attrs[GenAIAttributes.RESPONSE_MODEL] = model

    if input_tokens is not None:
        attrs[GenAIAttributes.USAGE_INPUT_TOKENS] = input_tokens

    if output_tokens is not None:
        attrs[GenAIAttributes.USAGE_OUTPUT_TOKENS] = output_tokens

    if input_tokens is not None and output_tokens is not None:
        attrs[GenAIAttributes.USAGE_TOTAL_TOKENS] = input_tokens + output_tokens

    if response_id is not None:
        attrs[GenAIAttributes.RESPONSE_ID] = response_id

    if finish_reasons is not None:
        attrs[GenAIAttributes.RESPONSE_FINISH_REASONS] = finish_reasons

    if temperature is not None:
        attrs[GenAIAttributes.REQUEST_TEMPERATURE] = temperature

    if max_tokens is not None:
        attrs[GenAIAttributes.REQUEST_MAX_TOKENS] = max_tokens

    if cost is not None:
        attrs[GenAIAttributes.COST] = cost

    # Add extra attributes
    for key, value in extra.items():
        if value is not None:
            # Prefix with gen_ai. if not already prefixed
            if not key.startswith("gen_ai."):
                key = f"gen_ai.{key}"
            attrs[key] = value

    return attrs


def create_tool_attributes(
    tool_name: str,
    tool_call_id: str | None = None,
    arguments: Any = None,
    result: Any = None,
) -> dict[str, Any]:
    """Create attributes for a tool call span.

    Args:
        tool_name: Name of the tool
        tool_call_id: Identifier for the tool call
        arguments: Arguments passed to the tool
        result: Result from the tool

    Returns:
        Dictionary of tool-related GenAI attributes
    """
    attrs: dict[str, Any] = {
        GenAIAttributes.OPERATION_NAME: GenAIOperations.EXECUTE_TOOL,
        GenAIAttributes.TOOL_NAME: tool_name,
    }

    if tool_call_id is not None:
        attrs[GenAIAttributes.TOOL_CALL_ID] = tool_call_id

    if arguments is not None:
        attrs[GenAIAttributes.TOOL_CALL_ARGUMENTS] = arguments

    if result is not None:
        attrs[GenAIAttributes.TOOL_CALL_RESULT] = result

    return attrs


def create_agent_attributes(
    agent_name: str,
    agent_id: str | None = None,
    description: str | None = None,
    model: str | None = None,
    provider: str | None = None,
    system_instructions: str | None = None,
) -> dict[str, Any]:
    """Create attributes for an agent span.

    Args:
        agent_name: Human-readable name of the agent
        agent_id: Unique identifier for the agent
        description: Description of the agent
        model: Model used by the agent
        provider: Provider of the model
        system_instructions: System prompt/instructions

    Returns:
        Dictionary of agent-related GenAI attributes
    """
    attrs: dict[str, Any] = {
        GenAIAttributes.OPERATION_NAME: GenAIOperations.INVOKE_AGENT,
        GenAIAttributes.AGENT_NAME: agent_name,
    }

    if agent_id is not None:
        attrs[GenAIAttributes.AGENT_ID] = agent_id

    if description is not None:
        attrs[GenAIAttributes.AGENT_DESCRIPTION] = description

    if model is not None:
        attrs[GenAIAttributes.REQUEST_MODEL] = model

    if provider is not None:
        attrs[GenAIAttributes.PROVIDER_NAME] = provider

    if system_instructions is not None:
        attrs[GenAIAttributes.SYSTEM_INSTRUCTIONS] = system_instructions

    return attrs


__all__ = [
    # Classes
    "GenAIAttributes",
    "GenAIOperations",
    "GenAIProviders",
    # Functions
    "build_genai_span_name",
    "create_genai_attributes",
    "create_tool_attributes",
    "create_agent_attributes",
]
