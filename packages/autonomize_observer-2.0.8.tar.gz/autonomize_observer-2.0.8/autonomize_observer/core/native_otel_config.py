"""Configuration for Native OpenTelemetry SDK.

This module provides configuration classes for the native OTEL SDK,
supporting export to Kafka, Azure Event Hub, OTLP, and console.

Usage:
    from autonomize_observer.core.native_otel_config import (
        NativeOTELConfig,
        EventHubConfig,
    )

    # Enable multiple exporters simultaneously
    config = NativeOTELConfig(
        enabled=True,
        enable_kafka=True,
        enable_eventhub=True,
        enable_console=True,  # For debugging
        kafka_config=KafkaConfig(...),
        event_hub_config=EventHubConfig(...),
    )
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from autonomize_observer.core.config import KafkaConfig

from autonomize_observer.core.otlp_config import OTLPConfig


@dataclass
class EventHubConfig:
    """Azure Event Hub configuration.

    Supports both connection string and Azure Identity authentication.

    Examples:
        # Connection string auth
        config = EventHubConfig(
            connection_string="Endpoint=sb://...",
            eventhub_name="otel-traces",
        )

        # Managed identity auth
        config = EventHubConfig(
            fully_qualified_namespace="myns.servicebus.windows.net",
            eventhub_name="otel-traces",
            use_managed_identity=True,
        )
    """

    # Connection options (one of these required)
    connection_string: str | None = None
    fully_qualified_namespace: str | None = None

    # Event Hub name
    eventhub_name: str = "otel-traces"
    restricted_eventhub_name: str | None = None  # For PHI workloads

    # Authentication
    use_managed_identity: bool = False
    credential_type: str = "default"  # default, workload, managed

    # Partitioning
    partition_key_field: str = "trace_id"  # Field to use as partition key

    # Batching
    max_batch_size: int = 100
    max_wait_time_seconds: float = 1.0

    # Retry settings for transient failures
    max_retries: int = 3
    retry_delay_seconds: float = 1.0
    retry_backoff_multiplier: float = 2.0
    retry_max_delay_seconds: float = 30.0

    # Application context
    usecase_id: str | None = None

    def __post_init__(self) -> None:
        """Validate configuration."""
        if not self.connection_string and not self.fully_qualified_namespace:
            # Allow empty config for optional setup
            pass

    @classmethod
    def from_env(cls) -> EventHubConfig:
        """Create EventHubConfig from environment variables.

        Environment variables:
            AZURE_EVENTHUB_CONNECTION_STRING: Full connection string
            AZURE_EVENTHUB_NAMESPACE: Fully qualified namespace
            AZURE_EVENTHUB_NAME: Event Hub name (default: otel-traces)
            AZURE_EVENTHUB_RESTRICTED_NAME: Restricted Event Hub for PHI
            AZURE_USE_MANAGED_IDENTITY: Use managed identity (default: false)
            AZURE_CREDENTIAL_TYPE: Credential type (default, workload, managed)
            AZURE_EVENTHUB_BATCH_SIZE: Max batch size (default: 100)
            AZURE_EVENTHUB_USECASE_ID: Application identifier
        """
        return cls(
            connection_string=os.getenv("AZURE_EVENTHUB_CONNECTION_STRING"),
            fully_qualified_namespace=os.getenv("AZURE_EVENTHUB_NAMESPACE"),
            eventhub_name=os.getenv("AZURE_EVENTHUB_NAME", "otel-traces"),
            restricted_eventhub_name=os.getenv(
                "AZURE_EVENTHUB_RESTRICTED_NAME", "otel-phi-traces"
            ),
            use_managed_identity=os.getenv(
                "AZURE_USE_MANAGED_IDENTITY", "false"
            ).lower()
            == "true",
            credential_type=os.getenv("AZURE_CREDENTIAL_TYPE", "default"),
            max_batch_size=int(os.getenv("AZURE_EVENTHUB_BATCH_SIZE", "100")),
            usecase_id=os.getenv("AZURE_EVENTHUB_USECASE_ID"),
        )

    @property
    def is_configured(self) -> bool:
        """Check if Event Hub is configured."""
        return bool(self.connection_string or self.fully_qualified_namespace)


@dataclass
class NativeOTELConfig:
    """Configuration for Native OpenTelemetry SDK.

    This configuration enables the native OTEL SDK with support for
    exporting to Kafka, Azure Event Hub, OTLP, and console.

    Use enable_kafka, enable_eventhub, enable_otlp_grpc, enable_otlp_http,
    and enable_console to independently enable each exporter.

    Examples:
        # Kafka only
        config = NativeOTELConfig(
            enabled=True,
            enable_kafka=True,
            kafka_config=KafkaConfig(bootstrap_servers="kafka:9092"),
        )

        # Multiple exporters (Kafka + Event Hub)
        config = NativeOTELConfig(
            enabled=True,
            enable_kafka=True,
            enable_eventhub=True,
            kafka_config=KafkaConfig(...),
            event_hub_config=EventHubConfig(...),
        )

        # Console only (for local testing)
        config = NativeOTELConfig(
            enabled=True,
            enable_console=True,
        )

        # OTLP gRPC with console fallback
        config = NativeOTELConfig(
            enabled=True,
            enable_otlp_grpc=True,
            enable_console=True,
            otlp_config=OTLPConfig(endpoint="http://localhost:4317"),
        )
    """

    # Enable/disable
    enabled: bool = False

    # Service identification
    service_name: str = "autonomize-service"
    service_version: str = "1.0.0"
    environment: str = "production"

    # Individual exporter enable flags
    enable_kafka: bool = False
    enable_eventhub: bool = False
    enable_otlp_grpc: bool = False
    enable_otlp_http: bool = False
    enable_console: bool = False

    # Exporter configurations
    kafka_config: KafkaConfig | None = None
    event_hub_config: EventHubConfig | None = field(default_factory=EventHubConfig)

    # Span processing
    batch_export: bool = True
    export_timeout_ms: int = 30000
    max_export_batch_size: int = 512
    schedule_delay_ms: int = 5000

    # GenAI semantic conventions
    genai_semantic_conventions: bool = True

    # Multi-tenancy context
    organization_id: str | None = None
    project_id: str | None = None

    # Global tracer provider
    set_global_provider: bool = True

    # Lifecycle hooks (atexit + signal handlers)
    register_lifecycle_hooks: bool = True

    # OTLP Configuration
    otlp_config: OTLPConfig | None = None
    otlp_grpc_config: OTLPConfig | None = None
    otlp_http_config: OTLPConfig | None = None

    # Additional resource attributes
    resource_attributes: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> NativeOTELConfig:
        """Create NativeOTELConfig from environment variables.

        Environment variables:
            NATIVE_OTEL_ENABLED: Enable native OTEL (default: false)
            SERVICE_NAME: Service name (default: autonomize-service)
            SERVICE_VERSION: Service version (default: 1.0.0)
            ENVIRONMENT: Environment (default: production)

            Exporter flags:
            NATIVE_OTEL_ENABLE_KAFKA: Enable Kafka exporter (default: false)
            NATIVE_OTEL_ENABLE_EVENTHUB: Enable Event Hub exporter (default: false)
            NATIVE_OTEL_ENABLE_OTLP_GRPC: Enable OTLP gRPC exporter (default: false)
            NATIVE_OTEL_ENABLE_OTLP_HTTP: Enable OTLP HTTP exporter (default: false)
            NATIVE_OTEL_ENABLE_CONSOLE: Enable Console exporter (default: false)

            Other settings:
            NATIVE_OTEL_BATCH_EXPORT: Use batch processor (default: true)
            NATIVE_OTEL_EXPORT_TIMEOUT_MS: Export timeout (default: 30000)
            NATIVE_OTEL_BATCH_SIZE: Max batch size (default: 512)
            NATIVE_OTEL_SCHEDULE_DELAY_MS: Schedule delay (default: 5000)
            NATIVE_OTEL_GENAI_CONVENTIONS: Use GenAI conventions (default: true)
        """
        # Import here to avoid circular dependency
        from autonomize_observer.core.config import KafkaConfig

        otlp_base = OTLPConfig.from_env()

        return cls(
            enabled=os.getenv("NATIVE_OTEL_ENABLED", "false").lower() == "true",
            service_name=os.getenv("SERVICE_NAME", "autonomize-service"),
            service_version=os.getenv("SERVICE_VERSION", "1.0.0"),
            environment=os.getenv("ENVIRONMENT", "production"),
            enable_kafka=os.getenv("NATIVE_OTEL_ENABLE_KAFKA", "false").lower()
            == "true",
            enable_eventhub=os.getenv("NATIVE_OTEL_ENABLE_EVENTHUB", "false").lower()
            == "true",
            enable_otlp_grpc=os.getenv("NATIVE_OTEL_ENABLE_OTLP_GRPC", "false").lower()
            == "true",
            enable_otlp_http=os.getenv("NATIVE_OTEL_ENABLE_OTLP_HTTP", "false").lower()
            == "true",
            enable_console=os.getenv("NATIVE_OTEL_ENABLE_CONSOLE", "false").lower()
            == "true",
            kafka_config=KafkaConfig.from_env(),
            event_hub_config=EventHubConfig.from_env(),
            otlp_config=otlp_base,
            batch_export=os.getenv("NATIVE_OTEL_BATCH_EXPORT", "true").lower()
            == "true",
            export_timeout_ms=int(os.getenv("NATIVE_OTEL_EXPORT_TIMEOUT_MS", "30000")),
            max_export_batch_size=int(os.getenv("NATIVE_OTEL_BATCH_SIZE", "512")),
            schedule_delay_ms=int(os.getenv("NATIVE_OTEL_SCHEDULE_DELAY_MS", "5000")),
            genai_semantic_conventions=os.getenv(
                "NATIVE_OTEL_GENAI_CONVENTIONS", "true"
            ).lower()
            == "true",
        )

    @property
    def uses_kafka(self) -> bool:
        """Check if Kafka export is enabled."""
        return self.enable_kafka

    @property
    def uses_event_hub(self) -> bool:
        """Check if Event Hub export is enabled."""
        return self.enable_eventhub

    @property
    def uses_otlp_grpc(self) -> bool:
        """Check if OTLP gRPC export is enabled."""
        return self.enable_otlp_grpc

    @property
    def uses_otlp_http(self) -> bool:
        """Check if OTLP HTTP export is enabled."""
        return self.enable_otlp_http

    @property
    def uses_console(self) -> bool:
        """Check if Console export is enabled."""
        return self.enable_console

    @property
    def has_any_exporter_enabled(self) -> bool:
        """Check if at least one exporter is enabled."""
        return (
            self.enable_kafka
            or self.enable_eventhub
            or self.enable_otlp_grpc
            or self.enable_otlp_http
            or self.enable_console
        )

    def validate(self) -> list[str]:
        """Validate configuration and return list of errors."""
        errors: list[str] = []

        if not self.enabled:
            return errors

        # Check that at least one exporter is enabled
        if not self.has_any_exporter_enabled:
            errors.append(
                "No exporters enabled. Enable at least one: "
                "enable_kafka, enable_eventhub, enable_otlp_grpc, enable_otlp_http, or enable_console"
            )

        if self.enable_kafka and not self.kafka_config:
            errors.append("Kafka export enabled but kafka_config not provided")

        if self.enable_eventhub:
            if not self.event_hub_config:
                errors.append(
                    "Event Hub export enabled but event_hub_config not provided"
                )
            elif not self.event_hub_config.is_configured:
                errors.append(
                    "Event Hub export enabled but Event Hub not configured "
                    "(provide connection_string or fully_qualified_namespace)"
                )

        if self.enable_otlp_grpc and not (self.otlp_grpc_config or self.otlp_config):
            errors.append("OTLP gRPC export enabled but no OTLP configuration provided")

        if self.enable_otlp_http and not (self.otlp_http_config or self.otlp_config):
            errors.append("OTLP HTTP export enabled but no OTLP configuration provided")

        return errors


__all__ = [
    "EventHubConfig",
    "NativeOTELConfig",
]
