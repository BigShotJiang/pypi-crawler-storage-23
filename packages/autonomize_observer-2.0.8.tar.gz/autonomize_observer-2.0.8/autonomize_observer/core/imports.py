"""Centralized optional dependency checks.

This module provides availability flags for optional dependencies,
eliminating duplicated import checks across the codebase.

Usage:
    from autonomize_observer.core.imports import (
        CONFLUENT_KAFKA_AVAILABLE,
        ConfluentProducer,
        LOGFIRE_AVAILABLE,
        logfire,
    )

    if CONFLUENT_KAFKA_AVAILABLE:
        producer = ConfluentProducer(config)
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# =============================================================================
# Confluent Kafka (production-grade Kafka client)
# =============================================================================
try:
    from confluent_kafka import KafkaError as ConfluentKafkaError
    from confluent_kafka import Producer as ConfluentProducer

    CONFLUENT_KAFKA_AVAILABLE = True
except ImportError:
    CONFLUENT_KAFKA_AVAILABLE = False
    ConfluentProducer = None  # type: ignore[misc, assignment]
    ConfluentKafkaError = None  # type: ignore[misc, assignment]

# =============================================================================
# Logfire (OTEL tracing via Pydantic)
# =============================================================================
try:
    import logfire as _logfire

    LOGFIRE_AVAILABLE = True
    logfire: Any = _logfire
except ImportError:
    LOGFIRE_AVAILABLE = False
    logfire = None  # type: ignore[assignment]

# =============================================================================
# genai-prices (LLM cost calculation)
# =============================================================================
try:
    from genai_prices import get_model_price

    GENAI_PRICES_AVAILABLE = True
except ImportError:
    GENAI_PRICES_AVAILABLE = False
    get_model_price = None  # type: ignore[misc, assignment]

# =============================================================================
# OpenTelemetry SDK (Native OTEL - parallel to Logfire)
# =============================================================================
try:
    from opentelemetry import trace as otel_trace
    from opentelemetry.sdk.resources import Resource as OTelResource
    from opentelemetry.sdk.trace import ReadableSpan, TracerProvider
    from opentelemetry.sdk.trace.export import (
        BatchSpanProcessor,
        SimpleSpanProcessor,
        SpanExporter,
        SpanExportResult,
    )
    from opentelemetry.trace import SpanKind, Status, StatusCode

    NATIVE_OTEL_AVAILABLE = True
except ImportError:
    NATIVE_OTEL_AVAILABLE = False
    otel_trace = None  # type: ignore[misc, assignment]
    OTelResource = None  # type: ignore[misc, assignment]
    ReadableSpan = None  # type: ignore[misc, assignment]
    TracerProvider = None  # type: ignore[misc, assignment]
    BatchSpanProcessor = None  # type: ignore[misc, assignment]
    SimpleSpanProcessor = None  # type: ignore[misc, assignment]
    SpanExporter = None  # type: ignore[misc, assignment]
    SpanExportResult = None  # type: ignore[misc, assignment]

    class SpanKind:  # type: ignore[no-redef]
        INTERNAL = 0
        SERVER = 1
        CLIENT = 2
        PRODUCER = 3
        CONSUMER = 4

    class Status:  # type: ignore[no-redef]
        def __init__(self, status_code: Any, description: str | None = None):
            pass

    class StatusCode:  # type: ignore[no-redef]
        OK = 0
        UNSET = 1
        ERROR = 2


# =============================================================================
# Azure Event Hub (for native OTEL export)
# =============================================================================
try:
    from azure.eventhub import EventData, EventHubProducerClient
    from azure.identity import DefaultAzureCredential

    AZURE_EVENTHUB_AVAILABLE = True
except ImportError:
    AZURE_EVENTHUB_AVAILABLE = False
    EventHubProducerClient = None  # type: ignore[misc, assignment]
    EventData = None  # type: ignore[misc, assignment]
    DefaultAzureCredential = None  # type: ignore[misc, assignment]

# =============================================================================
# OpenTelemetry FastAPI Instrumentation (for native OTEL + FastAPI)
# =============================================================================
try:
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

    OTEL_FASTAPI_AVAILABLE = True
except ImportError:
    OTEL_FASTAPI_AVAILABLE = False
    FastAPIInstrumentor = None  # type: ignore[misc, assignment]


def check_kafka_available() -> bool:
    """Check if Kafka client is available.

    Returns:
        True if confluent-kafka is installed
    """
    if not CONFLUENT_KAFKA_AVAILABLE:
        logger.warning(
            "confluent-kafka not installed. Install with: pip install confluent-kafka"
        )
        return False
    return True


def check_logfire_available() -> bool:
    """Check if Logfire is available.

    Returns:
        True if logfire is installed
    """
    if not LOGFIRE_AVAILABLE:
        logger.debug(
            "logfire not installed. OTEL tracing disabled. "
            "Install with: pip install logfire"
        )
        return False
    return True


def check_native_otel_available() -> bool:
    """Check if native OpenTelemetry SDK is available.

    Returns:
        True if opentelemetry-sdk is installed
    """
    if not NATIVE_OTEL_AVAILABLE:
        logger.warning(
            "opentelemetry-sdk not installed. Native OTEL tracing disabled. "
            "Install with: pip install opentelemetry-sdk opentelemetry-api"
        )
        return False
    return True


def check_azure_eventhub_available() -> bool:
    """Check if Azure Event Hub SDK is available.

    Returns:
        True if azure-eventhub is installed
    """
    if not AZURE_EVENTHUB_AVAILABLE:
        logger.warning(
            "azure-eventhub not installed. Event Hub export disabled. "
            "Install with: pip install azure-eventhub azure-identity"
        )
        return False
    return True


def check_otel_fastapi_available() -> bool:
    """Check if OpenTelemetry FastAPI instrumentation is available.

    Returns:
        True if opentelemetry-instrumentation-fastapi is installed
    """
    if not OTEL_FASTAPI_AVAILABLE:
        logger.warning(
            "opentelemetry-instrumentation-fastapi not installed. "
            "Install with: pip install autonomize-observer[fastapi-native]"
        )
        return False
    return True


__all__ = [
    # Confluent Kafka
    "CONFLUENT_KAFKA_AVAILABLE",
    "ConfluentProducer",
    "ConfluentKafkaError",
    "check_kafka_available",
    # Logfire
    "LOGFIRE_AVAILABLE",
    "logfire",
    "check_logfire_available",
    # genai-prices
    "GENAI_PRICES_AVAILABLE",
    "get_model_price",
    # Native OpenTelemetry SDK
    "NATIVE_OTEL_AVAILABLE",
    "otel_trace",
    "OTelResource",
    "ReadableSpan",
    "TracerProvider",
    "BatchSpanProcessor",
    "SimpleSpanProcessor",
    "SpanExporter",
    "SpanExportResult",
    "SpanKind",
    "Status",
    "StatusCode",
    "check_native_otel_available",
    # Azure Event Hub
    "AZURE_EVENTHUB_AVAILABLE",
    "EventHubProducerClient",
    "EventData",
    "DefaultAzureCredential",
    "check_azure_eventhub_available",
    # OpenTelemetry FastAPI Instrumentation
    "OTEL_FASTAPI_AVAILABLE",
    "FastAPIInstrumentor",
    "check_otel_fastapi_available",
]
