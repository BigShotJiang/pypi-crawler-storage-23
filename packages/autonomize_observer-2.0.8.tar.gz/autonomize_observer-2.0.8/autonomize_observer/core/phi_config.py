"""PHI Detection Configuration.

Provides configurable PHI (Protected Health Information) detection
with regex-based word boundary matching to prevent false positives.

Usage:
    from autonomize_observer.core.phi_config import PHIDetectionConfig

    # Default configuration
    config = PHIDetectionConfig()

    # Custom patterns
    config = PHIDetectionConfig(
        patterns=["patient", "ssn", "diagnosis"],
        attribute_flag="contains_phi",
    )

    # Check if text contains PHI indicators
    if config.matches("patient_record"):
        # Route to restricted topic/Event Hub
        pass
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field


@dataclass
class PHIDetectionConfig:
    """Configuration for PHI detection.

    Uses word boundary regex patterns to prevent false positives.
    For example, "patient" will match "patient_record" but not "outpatient"
    when using the default word boundary matching.

    Attributes:
        enabled: Enable/disable PHI detection
        patterns: List of PHI indicator patterns (wrapped with word boundaries)
        attribute_flag: Attribute name for explicit PHI flag on spans
        check_attribute_values: Whether to check span attribute values for PHI
        use_word_boundaries: Use regex word boundaries for matching

    Example:
        >>> config = PHIDetectionConfig(patterns=["patient", "ssn"])
        >>> config.matches("patient_data")
        True
        >>> config.matches("outpatient")
        False  # No match due to word boundary
    """

    # Enable/disable PHI detection
    enabled: bool = True

    # PHI indicator patterns (will be wrapped with word boundaries)
    # Note: "member" removed from defaults to prevent false positives
    # like "team_member_count" or "membership_status"
    patterns: list[str] = field(
        default_factory=lambda: [
            "phi",
            "pii",
            "hipaa",
            "patient",
            "ssn",
            "dob",
            "medical",
            "health_record",
            "diagnosis",
            "prescription",
        ]
    )

    # Attribute name for explicit PHI flag on spans
    attribute_flag: str = "contains_phi"

    # Whether to check span attribute values (not just names)
    check_attribute_values: bool = False

    # Use word boundaries in regex matching
    use_word_boundaries: bool = True

    # Compiled regex pattern (lazy initialization)
    _compiled_pattern: re.Pattern[str] | None = field(
        default=None, repr=False, compare=False
    )

    def __post_init__(self) -> None:
        """Compile the regex pattern after initialization."""
        self._compile_pattern()

    def _compile_pattern(self) -> None:
        """Compile patterns into a single regex with optional word boundaries."""
        if not self.patterns:
            self._compiled_pattern = None
            return

        # Escape special regex characters in patterns
        escaped = [re.escape(p) for p in self.patterns]

        if self.use_word_boundaries:
            # Build pattern with word boundaries: \b(pattern1|pattern2|...)\b
            pattern_str = r"\b(" + "|".join(escaped) + r")\b"
        else:
            # Simple alternation without word boundaries
            pattern_str = "(" + "|".join(escaped) + ")"

        self._compiled_pattern = re.compile(pattern_str, re.IGNORECASE)

    def matches(self, text: str) -> bool:
        """Check if text contains PHI indicators using word boundary matching.

        Args:
            text: Text to check (e.g., span name, attribute key)

        Returns:
            True if PHI indicator found in text
        """
        if not self.enabled or not self._compiled_pattern:
            return False
        return bool(self._compiled_pattern.search(text))

    def add_pattern(self, pattern: str) -> None:
        """Add a new PHI pattern.

        Args:
            pattern: Pattern to add
        """
        if pattern not in self.patterns:
            self.patterns.append(pattern)
            self._compile_pattern()

    def remove_pattern(self, pattern: str) -> None:
        """Remove a PHI pattern.

        Args:
            pattern: Pattern to remove
        """
        if pattern in self.patterns:
            self.patterns.remove(pattern)
            self._compile_pattern()

    @classmethod
    def from_env(cls) -> PHIDetectionConfig:
        """Create PHIDetectionConfig from environment variables.

        Environment variables:
            PHI_DETECTION_ENABLED: Enable PHI detection (default: true)
            PHI_DETECTION_PATTERNS: Comma-separated list of patterns
            PHI_DETECTION_ATTRIBUTE: Attribute flag name (default: contains_phi)
            PHI_DETECTION_WORD_BOUNDARIES: Use word boundaries (default: true)

        Returns:
            PHIDetectionConfig instance
        """
        patterns_str = os.getenv("PHI_DETECTION_PATTERNS", "")
        patterns = (
            [p.strip() for p in patterns_str.split(",") if p.strip()]
            if patterns_str
            else None
        )

        return cls(
            enabled=os.getenv("PHI_DETECTION_ENABLED", "true").lower() == "true",
            patterns=(
                patterns
                if patterns
                else cls.__dataclass_fields__["patterns"].default_factory()
            ),
            attribute_flag=os.getenv("PHI_DETECTION_ATTRIBUTE", "contains_phi"),
            use_word_boundaries=os.getenv(
                "PHI_DETECTION_WORD_BOUNDARIES", "true"
            ).lower()
            == "true",
        )


__all__ = ["PHIDetectionConfig"]
