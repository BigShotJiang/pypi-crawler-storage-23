from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class OTLPConfig:
    """Configuration for OTLP Exporter.

    Supports both gRPC and HTTP protocols.

    Environment variables:
        OTEL_EXPORTER_OTLP_ENDPOINT: OTLP endpoint URL
        OTEL_EXPORTER_OTLP_HEADERS: Comma-separated key=value pairs
        OTEL_EXPORTER_OTLP_INSECURE: Use insecure connection (default: true)
        OTEL_EXPORTER_OTLP_COMPRESSION: Compression type (gzip, none)

    Example:
        config = OTLPConfig(
            endpoint="http://localhost:4317",
            headers={"Authorization": "Bearer token"},
            insecure=False,
            compression="gzip",
        )
    """

    endpoint: str = "http://localhost:4317"  # gRPC default
    headers: dict[str, str] = field(default_factory=dict)
    insecure: bool = True
    compression: str = "gzip"

    @classmethod
    def from_env(cls) -> OTLPConfig:
        """Create OTLPConfig from environment variables.

        Environment variables:
            OTEL_EXPORTER_OTLP_ENDPOINT: OTLP endpoint (default: http://localhost:4317)
            OTEL_EXPORTER_OTLP_HEADERS: Comma-separated key=value pairs
            OTEL_EXPORTER_OTLP_INSECURE: Use insecure connection (default: true)
            OTEL_EXPORTER_OTLP_COMPRESSION: Compression type (default: gzip)
        """
        # Parse headers from env (format: "key1=value1,key2=value2")
        headers_str = os.getenv("OTEL_EXPORTER_OTLP_HEADERS", "")
        headers: dict[str, str] = {}
        if headers_str:
            for pair in headers_str.split(","):
                if "=" in pair:
                    key, value = pair.split("=", 1)
                    headers[key.strip()] = value.strip()

        return cls(
            endpoint=os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317"),
            headers=headers,
            insecure=os.getenv("OTEL_EXPORTER_OTLP_INSECURE", "true").lower() == "true",
            compression=os.getenv("OTEL_EXPORTER_OTLP_COMPRESSION", "gzip").lower(),
        )

    @property
    def is_configured(self) -> bool:
        """Check if OTLP endpoint is configured (not the default localhost)."""
        return self.endpoint != "http://localhost:4317"
