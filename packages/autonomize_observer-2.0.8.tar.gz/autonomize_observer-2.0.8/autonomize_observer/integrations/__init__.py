"""Integrations for Langflow, FastAPI, and other frameworks.

These integrations support both Logfire and Native OTEL for tracing,
adding Autonomize-specific functionality like audit logging and Keycloak.
"""

from autonomize_observer.integrations.fastapi import (
    create_fastapi_middleware,
    setup_fastapi,
    setup_fastapi_native,
)
from autonomize_observer.integrations.langflow import (
    FlowContext,
    trace_component,
    trace_flow,
)

__all__ = [
    # FastAPI
    "create_fastapi_middleware",
    "setup_fastapi",
    "setup_fastapi_native",
    # Langflow
    "FlowContext",
    "trace_flow",
    "trace_component",
]
