"""Span attribute transformer for GenAI semantic conventions.

Transforms legacy/internal span attributes to OpenTelemetry GenAI
semantic convention format.

Usage:
    from autonomize_observer.tracing.span_transformer import SpanTransformer

    transformer = SpanTransformer()

    # Transform attributes
    genai_attrs = transformer.transform_attributes({
        "model": "gpt-4o",
        "provider": "openai",
        "input_tokens": 100,
    })
    # Result: {"gen_ai.request.model": "gpt-4o", "gen_ai.provider.name": "openai", ...}
"""

from __future__ import annotations

from typing import Any

from autonomize_observer.schemas.genai_conventions import (
    GenAIAttributes,
    GenAIOperations,
)


class SpanTransformer:
    """Transform span attributes to GenAI semantic convention format.

    This class provides utilities for converting internal/legacy
    span attributes to the standard OpenTelemetry GenAI format.
    """

    # Mapping from legacy attribute names to GenAI convention names
    ATTRIBUTE_MAPPING: dict[str, str] = {
        # Model/Provider
        "model": GenAIAttributes.REQUEST_MODEL,
        "model_name": GenAIAttributes.REQUEST_MODEL,
        "response_model": GenAIAttributes.RESPONSE_MODEL,
        "provider": GenAIAttributes.PROVIDER_NAME,
        "provider_name": GenAIAttributes.PROVIDER_NAME,
        "system": GenAIAttributes.SYSTEM,
        # Token usage
        "input_tokens": GenAIAttributes.USAGE_INPUT_TOKENS,
        "prompt_tokens": GenAIAttributes.USAGE_INPUT_TOKENS,
        "output_tokens": GenAIAttributes.USAGE_OUTPUT_TOKENS,
        "completion_tokens": GenAIAttributes.USAGE_OUTPUT_TOKENS,
        "total_tokens": GenAIAttributes.USAGE_TOTAL_TOKENS,
        # Request parameters
        "temperature": GenAIAttributes.REQUEST_TEMPERATURE,
        "max_tokens": GenAIAttributes.REQUEST_MAX_TOKENS,
        "top_p": GenAIAttributes.REQUEST_TOP_P,
        "top_k": GenAIAttributes.REQUEST_TOP_K,
        "frequency_penalty": GenAIAttributes.REQUEST_FREQUENCY_PENALTY,
        "presence_penalty": GenAIAttributes.REQUEST_PRESENCE_PENALTY,
        "stop_sequences": GenAIAttributes.REQUEST_STOP_SEQUENCES,
        # Response
        "response_id": GenAIAttributes.RESPONSE_ID,
        "finish_reason": GenAIAttributes.RESPONSE_FINISH_REASONS,
        "finish_reasons": GenAIAttributes.RESPONSE_FINISH_REASONS,
        # Content (may contain PII)
        "input_messages": GenAIAttributes.INPUT_MESSAGES,
        "prompt": GenAIAttributes.INPUT_MESSAGES,
        "messages": GenAIAttributes.INPUT_MESSAGES,
        "output_messages": GenAIAttributes.OUTPUT_MESSAGES,
        "completion": GenAIAttributes.OUTPUT_MESSAGES,
        "response": GenAIAttributes.OUTPUT_MESSAGES,
        "system_prompt": GenAIAttributes.SYSTEM_INSTRUCTIONS,
        "system_instructions": GenAIAttributes.SYSTEM_INSTRUCTIONS,
        "system_message": GenAIAttributes.SYSTEM_INSTRUCTIONS,
        # Tool
        "tool_name": GenAIAttributes.TOOL_NAME,
        "function_name": GenAIAttributes.TOOL_NAME,
        "tool_call_id": GenAIAttributes.TOOL_CALL_ID,
        "function_call_id": GenAIAttributes.TOOL_CALL_ID,
        "tool_arguments": GenAIAttributes.TOOL_CALL_ARGUMENTS,
        "function_arguments": GenAIAttributes.TOOL_CALL_ARGUMENTS,
        "tool_result": GenAIAttributes.TOOL_CALL_RESULT,
        "function_result": GenAIAttributes.TOOL_CALL_RESULT,
        # Agent
        "agent_id": GenAIAttributes.AGENT_ID,
        "agent_name": GenAIAttributes.AGENT_NAME,
        "agent_description": GenAIAttributes.AGENT_DESCRIPTION,
        # Session
        "conversation_id": GenAIAttributes.CONVERSATION_ID,
        "session_id": GenAIAttributes.CONVERSATION_ID,
        "thread_id": GenAIAttributes.CONVERSATION_ID,
        # Cost (custom extension)
        "cost": GenAIAttributes.COST,
        "estimated_cost": GenAIAttributes.COST,
        "latency_ms": GenAIAttributes.LATENCY_MS,
        "duration_ms": GenAIAttributes.LATENCY_MS,
    }

    # Mapping from component types to operation names
    COMPONENT_TYPE_MAPPING: dict[str, str] = {
        "llm": GenAIOperations.CHAT,
        "chat": GenAIOperations.CHAT,
        "model": GenAIOperations.CHAT,
        "completion": GenAIOperations.TEXT_COMPLETION,
        "text_completion": GenAIOperations.TEXT_COMPLETION,
        "embeddings": GenAIOperations.EMBEDDINGS,
        "embedding": GenAIOperations.EMBEDDINGS,
        "tool": GenAIOperations.EXECUTE_TOOL,
        "function": GenAIOperations.EXECUTE_TOOL,
        "agent": GenAIOperations.INVOKE_AGENT,
        "image": GenAIOperations.IMAGE_GENERATION,
        "audio": GenAIOperations.AUDIO_TRANSCRIPTION,
    }

    def __init__(
        self,
        include_unmapped: bool = True,
        prefix_unmapped: bool = True,
    ) -> None:
        """Initialize the transformer.

        Args:
            include_unmapped: Include attributes that don't have a mapping
            prefix_unmapped: Add 'gen_ai.' prefix to unmapped attributes
        """
        self._include_unmapped = include_unmapped
        self._prefix_unmapped = prefix_unmapped

    def transform_attributes(
        self,
        attributes: dict[str, Any],
        operation: str | None = None,
    ) -> dict[str, Any]:
        """Transform attributes to GenAI convention format.

        Args:
            attributes: Input attributes (legacy format)
            operation: Optional operation name override

        Returns:
            Transformed attributes in GenAI format
        """
        result: dict[str, Any] = {}

        for key, value in attributes.items():
            if value is None:
                continue

            # Already has gen_ai prefix - keep as is
            if key.startswith("gen_ai."):
                result[key] = value
                continue

            # Try to map the attribute
            mapped_key = self.ATTRIBUTE_MAPPING.get(key)

            if mapped_key:
                result[mapped_key] = self._transform_value(mapped_key, value)
            elif self._include_unmapped:
                if self._prefix_unmapped:
                    result[f"gen_ai.{key}"] = value
                else:
                    result[key] = value

        # Ensure operation name is set
        if GenAIAttributes.OPERATION_NAME not in result:
            if operation:
                result[GenAIAttributes.OPERATION_NAME] = operation
            else:
                result[GenAIAttributes.OPERATION_NAME] = self._infer_operation(
                    attributes
                )

        # Calculate total tokens if not present
        if GenAIAttributes.USAGE_TOTAL_TOKENS not in result:
            input_tokens = result.get(GenAIAttributes.USAGE_INPUT_TOKENS)
            output_tokens = result.get(GenAIAttributes.USAGE_OUTPUT_TOKENS)
            if input_tokens is not None and output_tokens is not None:
                result[GenAIAttributes.USAGE_TOTAL_TOKENS] = input_tokens + output_tokens

        return result

    def _transform_value(self, key: str, value: Any) -> Any:
        """Transform a value if needed.

        Args:
            key: The GenAI attribute key
            value: The value to transform

        Returns:
            Transformed value
        """
        # Ensure finish_reasons is a list
        if key == GenAIAttributes.RESPONSE_FINISH_REASONS:
            if isinstance(value, str):
                return [value]

        # Ensure token counts are integers
        if key in (
            GenAIAttributes.USAGE_INPUT_TOKENS,
            GenAIAttributes.USAGE_OUTPUT_TOKENS,
            GenAIAttributes.USAGE_TOTAL_TOKENS,
        ):
            if isinstance(value, float):
                return int(value)

        return value

    def _infer_operation(self, attributes: dict[str, Any]) -> str:
        """Infer operation name from attributes.

        Args:
            attributes: Input attributes

        Returns:
            Inferred operation name
        """
        # Check for tool-related attributes
        if any(k in attributes for k in ["tool_name", "function_name", "tool_call_id"]):
            return GenAIOperations.EXECUTE_TOOL

        # Check for agent-related attributes
        if any(k in attributes for k in ["agent_id", "agent_name"]):
            return GenAIOperations.INVOKE_AGENT

        # Check component type
        component_type = attributes.get("component_type", "").lower()
        if component_type in self.COMPONENT_TYPE_MAPPING:
            return self.COMPONENT_TYPE_MAPPING[component_type]

        # Default to chat
        return GenAIOperations.CHAT

    def transform_span_name(
        self,
        name: str,
        component_type: str | None = None,
        model: str | None = None,
    ) -> str:
        """Transform span name to GenAI convention format.

        Args:
            name: Original span name
            component_type: Component type if available
            model: Model name if available

        Returns:
            Transformed span name
        """
        # Determine operation from component type or name
        operation = None

        if component_type:
            operation = self.COMPONENT_TYPE_MAPPING.get(component_type.lower())

        if not operation:
            # Try to infer from name
            name_lower = name.lower()
            for key, op in self.COMPONENT_TYPE_MAPPING.items():
                if key in name_lower:
                    operation = op
                    break

        if not operation:
            operation = GenAIOperations.CHAT

        # Build span name
        if model:
            return f"{operation} {model}"
        return operation

    def infer_operation_from_span_name(self, name: str) -> str:
        """Infer GenAI operation from span name.

        Args:
            name: Span name

        Returns:
            Inferred operation name
        """
        name_lower = name.lower()

        if "chat" in name_lower:
            return GenAIOperations.CHAT
        if "complet" in name_lower:
            return GenAIOperations.TEXT_COMPLETION
        if "embed" in name_lower:
            return GenAIOperations.EMBEDDINGS
        if "tool" in name_lower or "function" in name_lower:
            return GenAIOperations.EXECUTE_TOOL
        if "agent" in name_lower:
            return GenAIOperations.INVOKE_AGENT
        if "image" in name_lower:
            return GenAIOperations.IMAGE_GENERATION
        if "audio" in name_lower or "transcri" in name_lower:
            return GenAIOperations.AUDIO_TRANSCRIPTION

        return GenAIOperations.CHAT


# Singleton instance for convenience
_default_transformer: SpanTransformer | None = None


def get_transformer() -> SpanTransformer:
    """Get the default span transformer instance."""
    global _default_transformer
    if _default_transformer is None:
        _default_transformer = SpanTransformer()
    return _default_transformer


def transform_to_genai(
    attributes: dict[str, Any],
    operation: str | None = None,
) -> dict[str, Any]:
    """Convenience function to transform attributes to GenAI format.

    Args:
        attributes: Input attributes
        operation: Optional operation name

    Returns:
        Transformed attributes
    """
    return get_transformer().transform_attributes(attributes, operation)


__all__ = [
    "SpanTransformer",
    "get_transformer",
    "transform_to_genai",
]
