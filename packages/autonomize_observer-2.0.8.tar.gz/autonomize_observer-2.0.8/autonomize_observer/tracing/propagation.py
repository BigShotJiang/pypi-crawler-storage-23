"""Trace context propagation helpers for distributed tracing."""

import logging
from contextlib import contextmanager
from typing import Any, Generator, Tuple

from autonomize_observer.core.imports import (
    SpanKind,
    otel_trace,
)

logger = logging.getLogger(__name__)


def inject_trace_context() -> dict[str, str]:
    """Inject current trace context into a carrier dict.

    Returns:
        Dict with traceparent/tracestate headers.
    """
    if not otel_trace:
        return {}

    carrier: dict[str, str] = {}
    from opentelemetry.trace.propagation.tracecontext import (
        TraceContextTextMapPropagator,
    )

    TraceContextTextMapPropagator().inject(carrier)
    return carrier


def extract_trace_context(headers: dict[str, str]) -> Any:
    """Extract parent trace context from headers.

    Args:
        headers: Dict of string headers (e.g., from Kafka message)

    Returns:
        OpenTelemetry Context for use with start_as_current_span
    """
    if not otel_trace:
        return None

    from opentelemetry.trace.propagation.tracecontext import (
        TraceContextTextMapPropagator,
    )

    return TraceContextTextMapPropagator().extract(carrier=headers)


def kafka_headers_to_dict(headers: list[tuple[str, bytes]] | None) -> dict[str, str]:
    """Convert Kafka header format to string dict."""
    if not headers:
        return {}
    return {k: v.decode("utf-8") for k, v in headers}


def dict_to_kafka_headers(carrier: dict[str, str]) -> list[tuple[str, bytes]]:
    """Convert string dict to Kafka header format."""
    return [(k, v.encode("utf-8")) for k, v in carrier.items()]


@contextmanager
def consume_with_trace(
    manager: Any,
    consumer: Any,
    span_name: str,
    timeout: float = 1.0,
) -> Generator[tuple[Any, Any], None, None]:
    """Consume a Kafka message with automatic trace context restoration.

    Usage:
        with consume_with_trace(manager, consumer, "process-data") as (msg, span):
            if msg:
                data = json.loads(msg.value())
                span.set_attribute("records.count", len(data))
                process(data)
    """
    msg = consumer.poll(timeout)

    if msg is None or msg.error():
        yield None, None
        return

    headers = kafka_headers_to_dict(msg.headers())
    parent_ctx = extract_trace_context(headers)

    with manager.tracer.start_as_current_span(
        span_name,
        context=parent_ctx,
        kind=SpanKind.CONSUMER,
    ) as span:
        span.set_attribute("messaging.system", "kafka")
        yield msg, span
