"""Native OpenTelemetry SDK Manager.

Provides native OTEL SDK integration as an alternative to Logfire,
with support for export to Kafka, Azure Event Hub, OTLP, and console.

This runs PARALLEL to the existing OTELManager (Logfire-based) -
both can coexist and be used simultaneously.

Usage:
    from autonomize_observer.tracing import NativeOTELManager
    from autonomize_observer.core.native_otel_config import NativeOTELConfig

    # Configure with individual enable flags
    config = NativeOTELConfig(
        enabled=True,
        service_name="my-service",
        enable_kafka=True,
        enable_eventhub=True,
        enable_console=True,  # For debugging
        kafka_config=KafkaConfig(...),
        event_hub_config=EventHubConfig(...),
    )

    # Create manager
    manager = NativeOTELManager(config=config)

    # Create spans
    with manager.span("chat", model="gpt-4o") as span:
        span.set_attribute("gen_ai.usage.input_tokens", 150)
        response = llm.chat(...)
        span.set_attribute("gen_ai.usage.output_tokens", 500)
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Generator

from autonomize_observer.core.imports import (
    AZURE_EVENTHUB_AVAILABLE,
    NATIVE_OTEL_AVAILABLE,
    BatchSpanProcessor,
    OTelResource,
    SimpleSpanProcessor,
    SpanExporter,
    SpanKind,
    Status,
    StatusCode,
    TracerProvider,
    otel_trace,
)
from autonomize_observer.core.native_otel_config import NativeOTELConfig
from autonomize_observer.schemas.genai_conventions import (
    GenAIAttributes,
    GenAIOperations,
    create_agent_attributes,
    create_genai_attributes,
    create_tool_attributes,
)

if TYPE_CHECKING:
    from opentelemetry.trace import Span, Tracer

logger = logging.getLogger(__name__)


class NativeOTELManager:
    """Native OpenTelemetry SDK manager with dual export support.

    This manager provides native OTEL SDK integration WITHOUT Logfire,
    supporting export to Kafka and/or Azure Event Hub.

    Key features:
    - Native OTEL SDK (no Logfire dependency for OTEL)
    - Dual export to Kafka and Event Hub
    - GenAI semantic conventions support
    - Convenience methods for LLM, Agent, and Tool spans

    Example:
        >>> from autonomize_observer.tracing import NativeOTELManager
        >>> from autonomize_observer.core.native_otel_config import NativeOTELConfig
        >>>
        >>> config = NativeOTELConfig(enabled=True, enable_kafka=True)
        >>> manager = NativeOTELManager(config=config)
        >>>
        >>> with manager.span("chat") as span:
        ...     span.set_attribute("gen_ai.request.model", "gpt-4o")
        ...     result = call_llm()
    """

    # Class-level tracking
    _global_provider: TracerProvider | None = None
    _initialized: bool = False

    def __init__(
        self,
        config: NativeOTELConfig,
        kafka_exporter: SpanExporter | None = None,
        event_hub_exporter: SpanExporter | None = None,
    ) -> None:
        """Initialize native OTEL manager.

        Args:
            config: Native OTEL configuration
            kafka_exporter: Pre-configured Kafka exporter (optional, will create if needed)
            event_hub_exporter: Pre-configured Event Hub exporter (optional, will create if needed)

        Raises:
            ImportError: If opentelemetry-sdk not installed
        """
        if not NATIVE_OTEL_AVAILABLE:
            raise ImportError(
                "opentelemetry-sdk not installed. "
                "Install with: pip install autonomize-observer[native-otel]"
            )

        self._config = config
        self._kafka_exporter = kafka_exporter
        self._event_hub_exporter = event_hub_exporter
        self._provider: TracerProvider | None = None
        self._tracer: Tracer | None = None
        self._exporters: list[SpanExporter] = []
        self._configured = False

        if config.enabled:
            self._configure()

    def _configure(self) -> None:
        """Configure the TracerProvider with exporters."""
        if self._configured:
            return

        # Validate configuration
        errors = self._config.validate()
        if errors:
            logger.warning("Configuration errors detected", extra={"errors": errors})

        # Create resource
        resource_attrs = {
            "service.name": self._config.service_name,
            "service.version": self._config.service_version,
            "deployment.environment": self._config.environment,
            "autonomize.organization_id": self._config.organization_id,
            "autonomize.project_id": self._config.project_id,
        }
        resource_attrs.update(self._config.resource_attributes)
        # Filter out None values
        resource_attrs = {k: v for k, v in resource_attrs.items() if v is not None}
        resource = OTelResource.create(resource_attrs)

        # Create TracerProvider
        self._provider = TracerProvider(resource=resource)

        if self._config.set_global_provider:
            otel_trace.set_tracer_provider(self._provider)
            logger.debug("Registered native OTEL tracer provider as global")

        # Setup exporters
        self._setup_exporters()

        # Add span processors
        for exporter in self._exporters:
            if self._config.batch_export:
                processor = BatchSpanProcessor(
                    exporter,
                    max_export_batch_size=self._config.max_export_batch_size,
                    schedule_delay_millis=self._config.schedule_delay_ms,
                    export_timeout_millis=self._config.export_timeout_ms,
                )
            else:
                processor = SimpleSpanProcessor(exporter)
            self._provider.add_span_processor(processor)

        # Get tracer
        self._tracer = self._provider.get_tracer(
            self._config.service_name,
            self._config.service_version,
        )

        self._configured = True

        # Register lifecycle hooks (atexit + signal handlers)
        if self._config.register_lifecycle_hooks:
            self._register_lifecycle_hooks()

        logger.info(
            "NativeOTELManager configured",
            extra={
                "service_name": self._config.service_name,
                "exporter_count": len(self._exporters),
            },
        )

    def _register_lifecycle_hooks(self) -> None:
        """Register shutdown hooks for graceful termination.

        Registers:
        - atexit handler for normal process exit
        - SIGTERM handler for container/K8s termination
        - SIGINT handler for Ctrl+C
        """
        import atexit
        import signal

        # atexit hook for normal exit
        atexit.register(self.shutdown)

        # Signal handlers for graceful shutdown
        def signal_handler(signum: int, frame: Any) -> None:
            logger.info(
                "Received termination signal, shutting down OTEL",
                extra={"signal": signum},
            )
            self.shutdown()

        # Only register signal handlers if in main thread
        try:
            signal.signal(signal.SIGTERM, signal_handler)
            signal.signal(signal.SIGINT, signal_handler)
            logger.debug("Registered SIGTERM/SIGINT handlers for graceful shutdown")
        except (OSError, ValueError) as e:
            # May fail in non-main threads or certain environments
            logger.debug(
                "Could not register signal handlers (non-main thread or unsupported)",
                extra={"error": str(e)},
            )

    def _setup_exporters(self) -> None:
        """Setup exporters based on configuration.

        Supports multiple exporters enabled simultaneously via individual flags:
        - enable_kafka: Kafka exporter
        - enable_eventhub: Azure Event Hub exporter
        - enable_otlp_grpc: OTLP gRPC exporter
        - enable_otlp_http: OTLP HTTP exporter
        - enable_console: Console exporter (for debugging)
        """
        # Kafka exporter
        if self._config.uses_kafka:
            exporter = self._kafka_exporter or self._create_kafka_exporter()
            if exporter:
                self._exporters.append(exporter)
                logger.debug("Added Kafka span exporter")

        # Event Hub exporter
        if self._config.uses_event_hub:
            exporter = self._event_hub_exporter or self._create_event_hub_exporter()
            if exporter:
                self._exporters.append(exporter)
                logger.debug("Added Event Hub span exporter")

        # OTLP gRPC exporter
        if self._config.uses_otlp_grpc:
            exporter = self._create_otlp_exporter("grpc")
            if exporter:
                self._exporters.append(exporter)
                logger.debug("Added OTLP gRPC span exporter")

        # OTLP HTTP exporter
        if self._config.uses_otlp_http:
            exporter = self._create_otlp_exporter("http")
            if exporter:
                self._exporters.append(exporter)
                logger.debug("Added OTLP HTTP span exporter")

        # Console exporter (for debugging/testing)
        if self._config.uses_console:
            exporter = self._create_console_exporter()
            if exporter:
                self._exporters.append(exporter)
                logger.debug("Added Console span exporter")

        if not self._exporters:
            logger.warning("No exporters configured - spans will not be exported")

    def _create_otlp_exporter(self, protocol: str) -> SpanExporter | None:
        """Create OTLP exporter (gRPC or HTTP)."""
        # Pick the correct config (protocol-specific or fallback to shared)
        otlp_config = self._config.otlp_config
        if protocol == "grpc" and self._config.otlp_grpc_config:
            otlp_config = self._config.otlp_grpc_config
        elif protocol == "http" and self._config.otlp_http_config:
            otlp_config = self._config.otlp_http_config

        if not otlp_config:
            return None

        try:
            # Prepare common arguments
            # Note: HTTP exporter does NOT accept 'insecure' parameter in recent versions,
            # it uses 'http' vs 'https' in the endpoint URL instead.
            exporter_kwargs = {
                "endpoint": otlp_config.endpoint,
                "headers": otlp_config.headers,
                "compression": None
                if otlp_config.compression == "none"
                else otlp_config.compression,
            }

            if protocol == "grpc":
                from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
                    OTLPSpanExporter,
                )

                exporter_kwargs["insecure"] = otlp_config.insecure
            else:
                from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
                    OTLPSpanExporter,
                )

            return OTLPSpanExporter(**exporter_kwargs)
        except ImportError:
            logger.warning(
                f"opentelemetry-exporter-otlp-proto-{protocol} not installed. "
                "Install with: pip install autonomize-observer[otlp]"
            )
            return None
        except Exception as e:
            logger.error(
                f"Failed to create OTLP {protocol} exporter",
                extra={"error": str(e)},
                exc_info=True,
            )
            return None

    def _create_kafka_exporter(self) -> SpanExporter | None:
        """Create Kafka span exporter."""
        if not self._config.kafka_config:
            return None

        try:
            from autonomize_observer.exporters.otel import KafkaSpanExporter

            return KafkaSpanExporter(
                kafka_config=self._config.kafka_config,
                usecase_id=self._config.event_hub_config.usecase_id
                if self._config.event_hub_config
                else "GenericApp",
                transform_to_genai=self._config.genai_semantic_conventions,
            )
        except ImportError as e:
            logger.warning("Failed to create Kafka exporter", extra={"error": str(e)})
            return None

    def _create_event_hub_exporter(self) -> SpanExporter | None:
        """Create Event Hub span exporter."""
        if not self._config.event_hub_config:
            return None

        if not AZURE_EVENTHUB_AVAILABLE:
            logger.warning(
                "Azure Event Hub SDK not installed. "
                "Install with: pip install autonomize-observer[azure]"
            )
            return None

        try:
            from autonomize_observer.exporters.otel import EventHubSpanExporter

            return EventHubSpanExporter(
                config=self._config.event_hub_config,
                transform_to_genai=self._config.genai_semantic_conventions,
            )
        except ImportError as e:
            logger.warning(
                "Failed to create Event Hub exporter", extra={"error": str(e)}
            )
            return None

    def _create_console_exporter(self) -> SpanExporter | None:
        """Create Console span exporter for debugging/testing."""
        try:
            from opentelemetry.sdk.trace.export import ConsoleSpanExporter

            return ConsoleSpanExporter()
        except ImportError as e:
            logger.warning("Failed to create Console exporter", extra={"error": str(e)})
            return None

    @property
    def is_available(self) -> bool:
        """Check if native OTEL is available and configured."""
        return self._configured and self._tracer is not None

    @property
    def tracer(self) -> Tracer | None:
        """Get the configured tracer."""
        return self._tracer

    @contextmanager
    def span(
        self,
        name: str,
        kind: SpanKind = SpanKind.INTERNAL,
        attributes: dict[str, Any] | None = None,
        **extra_attributes: Any,
    ) -> Generator[Span, None, None]:
        """Create a span using context manager.

        Args:
            name: Span name
            kind: Span kind (INTERNAL, CLIENT, SERVER, PRODUCER, CONSUMER)
            attributes: Initial span attributes
            **extra_attributes: Additional attributes

        Yields:
            The active span

        Example:
            >>> with manager.span("chat", model="gpt-4o") as span:
            ...     span.set_attribute("gen_ai.usage.input_tokens", 100)
            ...     result = call_llm()
        """
        if not self.is_available or not self._tracer:
            # Return a no-op span context
            yield self._create_noop_span()
            return

        # Merge attributes
        all_attrs = attributes or {}
        all_attrs.update(extra_attributes)

        # Transform to GenAI conventions if enabled
        if self._config.genai_semantic_conventions:
            from autonomize_observer.tracing.span_transformer import transform_to_genai

            all_attrs = transform_to_genai(all_attrs)

        with self._tracer.start_as_current_span(
            name,
            kind=kind,
            attributes=all_attrs or None,
        ) as span:
            yield span

    def start_span(
        self,
        name: str,
        kind: SpanKind = SpanKind.INTERNAL,
        attributes: dict[str, Any] | None = None,
        **extra_attributes: Any,
    ) -> Span:
        """Start a span manually (for non-context-manager use).

        You must call end_span() when done.

        Args:
            name: Span name
            kind: Span kind
            attributes: Initial attributes
            **extra_attributes: Additional attributes

        Returns:
            The started span

        Example:
            >>> span = manager.start_span("long-operation")
            >>> try:
            ...     do_work()
            ... finally:
            ...     manager.end_span(span)
        """
        if not self.is_available or not self._tracer:
            return self._create_noop_span()

        all_attrs = attributes or {}
        all_attrs.update(extra_attributes)

        if self._config.genai_semantic_conventions:
            from autonomize_observer.tracing.span_transformer import transform_to_genai

            all_attrs = transform_to_genai(all_attrs)

        return self._tracer.start_span(
            name,
            kind=kind,
            attributes=all_attrs or None,
        )

    def end_span(
        self,
        span: Span,
        error: Exception | None = None,
    ) -> None:
        """End a manually started span.

        Args:
            span: The span to end
            error: Optional exception that occurred
        """
        if span is None:
            return

        try:
            if error:
                span.set_status(Status(StatusCode.ERROR, str(error)))
                span.record_exception(error)
            else:
                span.set_status(Status(StatusCode.OK))
            span.end()
        except Exception as e:
            logger.warning("Error ending span", extra={"error": str(e)})

    @contextmanager
    def llm_span(
        self,
        operation: str = GenAIOperations.CHAT,
        provider: str | None = None,
        model: str | None = None,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        **extra_attributes: Any,
    ) -> Generator[Span, None, None]:
        """Create an LLM span with GenAI attributes.

        Convenience method for creating LLM call spans with
        proper GenAI semantic conventions.

        Args:
            operation: Operation name (chat, text_completion, embeddings)
            provider: Provider name (openai, anthropic, etc.)
            model: Model name
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
            **extra_attributes: Additional attributes

        Yields:
            The active span

        Example:
            >>> with manager.llm_span(
            ...     provider="openai",
            ...     model="gpt-4o",
            ...     input_tokens=150,
            ... ) as span:
            ...     response = openai.chat.completions.create(...)
            ...     span.set_attribute("gen_ai.usage.output_tokens", 500)
        """
        attrs = create_genai_attributes(
            operation=operation,
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            **extra_attributes,
        )

        span_name = f"{operation} {model}" if model else operation

        with self.span(span_name, kind=SpanKind.CLIENT, attributes=attrs) as span:
            yield span

    @contextmanager
    def tool_span(
        self,
        tool_name: str,
        tool_call_id: str | None = None,
        arguments: Any = None,
        **extra_attributes: Any,
    ) -> Generator[Span, None, None]:
        """Create a tool/function call span.

        Args:
            tool_name: Name of the tool
            tool_call_id: Tool call identifier
            arguments: Arguments passed to the tool
            **extra_attributes: Additional attributes

        Yields:
            The active span

        Example:
            >>> with manager.tool_span("get_weather", arguments={"city": "NYC"}) as span:
            ...     result = get_weather("NYC")
            ...     span.set_attribute("gen_ai.tool.call.result", str(result))
        """
        attrs = create_tool_attributes(
            tool_name=tool_name,
            tool_call_id=tool_call_id,
            arguments=arguments,
        )
        attrs.update(extra_attributes)

        span_name = f"execute_tool {tool_name}"

        with self.span(span_name, kind=SpanKind.INTERNAL, attributes=attrs) as span:
            yield span

    @contextmanager
    def agent_span(
        self,
        agent_name: str,
        agent_id: str | None = None,
        model: str | None = None,
        provider: str | None = None,
        system_instructions: str | None = None,
        **extra_attributes: Any,
    ) -> Generator[Span, None, None]:
        """Create an agent invocation span.

        Args:
            agent_name: Human-readable name of the agent
            agent_id: Unique identifier for the agent
            model: Model used by the agent
            provider: Provider of the model
            system_instructions: System prompt/instructions
            **extra_attributes: Additional attributes

        Yields:
            The active span

        Example:
            >>> with manager.agent_span(
            ...     agent_name="CustomerSupportAgent",
            ...     model="gpt-4o",
            ...     provider="openai",
            ... ) as span:
            ...     result = agent.run(query)
        """
        attrs = create_agent_attributes(
            agent_name=agent_name,
            agent_id=agent_id,
            model=model,
            provider=provider,
            system_instructions=system_instructions,
        )
        attrs.update(extra_attributes)

        span_name = f"invoke_agent {agent_name}"

        with self.span(span_name, kind=SpanKind.INTERNAL, attributes=attrs) as span:
            yield span

    def _create_noop_span(self) -> Any:
        """Create a no-op span for when OTEL is not available."""

        class NoOpSpan:
            """No-op span that does nothing."""

            def set_attribute(self, key: str, value: Any) -> None:
                pass

            def set_attributes(self, attributes: dict[str, Any]) -> None:
                pass

            def add_event(
                self, name: str, attributes: dict[str, Any] | None = None
            ) -> None:
                pass

            def record_exception(self, exception: Exception) -> None:
                pass

            def set_status(self, status: Any) -> None:
                pass

            def end(self) -> None:
                pass

            def __enter__(self) -> NoOpSpan:
                return self

            def __exit__(self, *args: Any) -> None:
                pass

        return NoOpSpan()

    def shutdown(self) -> None:
        """Shutdown the manager and flush all exporters."""
        if self._provider:
            self._provider.shutdown()
            logger.debug("NativeOTELManager shutdown complete")

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush all span processors.

        Args:
            timeout_millis: Timeout in milliseconds

        Returns:
            True if flush succeeded
        """
        if self._provider:
            return self._provider.force_flush(timeout_millis)
        return True

    def __enter__(self) -> NativeOTELManager:
        """Context manager entry."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit - shutdown manager."""
        self.shutdown()


__all__ = ["NativeOTELManager"]
