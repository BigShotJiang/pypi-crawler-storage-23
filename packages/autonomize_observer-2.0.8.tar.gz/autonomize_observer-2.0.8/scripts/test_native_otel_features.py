#!/usr/bin/env python3
"""
Comprehensive test script for Native OTEL SDK features.

This script demonstrates all features of the Native OTEL SDK:
- Multiple exporter types (Kafka, Event Hub, OTLP, Console)
- Nested spans (parent-child relationships)
- LLM spans with GenAI semantic conventions
- PHI detection and routing
- Multi-tenancy (organization_id, project_id)
- Context propagation
- Signal handlers / lifecycle hooks
- FastAPI integration

Usage:
    1. Fill in the configuration variables below
    2. Run: python scripts/test_native_otel_features.py
"""

import logging
import time

# Configure logging to see structured logs
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s - %(extra)s"
    if hasattr(logging, "extra")
    else "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# =============================================================================
# CONFIGURATION - Fill these in before running
# =============================================================================

# --- General Config ---
SERVICE_NAME = "native-otel-test-service"
SERVICE_VERSION = "1.0.0"
ENVIRONMENT = "development"  # development, staging, production

# --- Multi-Tenancy ---
ORGANIZATION_ID = "org-test-123"
PROJECT_ID = "proj-test-456"

# --- Exporter Selection (enable one or more) ---
ENABLE_CONSOLE = True  # Console output for local testing (no external dependencies)
ENABLE_KAFKA = True  # Kafka exporter (requires Kafka config below)
ENABLE_EVENTHUB = True  # Azure Event Hub exporter (requires Event Hub config below)
ENABLE_OTLP_GRPC = True  # OTLP gRPC exporter (e.g., to Jaeger, Tempo)
ENABLE_OTLP_HTTP = True  # OTLP HTTP exporter

# --- Kafka Configuration (if ENABLE_KAFKA = True) ---
KAFKA_BOOTSTRAP_SERVERS = (
    "bootstrap.sprint.autonomize.dev:443"  # e.g., "kafka1:9092,kafka2:9092"
)
KAFKA_TRACE_TOPIC = "otel-traces"
KAFKA_RESTRICTED_TOPIC = "otel-phi-traces"  # For PHI routing
# NOTE: Port 443 with SASL authentication requires SASL_SSL (not PLAINTEXT)
KAFKA_SECURITY_PROTOCOL = "SASL_SSL"  # PLAINTEXT, SASL_SSL, SASL_PLAINTEXT
KAFKA_SASL_MECHANISM = "PLAIN"  # PLAIN, SCRAM-SHA-256, SCRAM-SHA-512
KAFKA_USERNAME = ""  # Set if using SASL authentication
KAFKA_PASSWORD = ""  # Set if using SASL authentication

# --- Event Hub Configuration (if ENABLE_EVENTHUB = True) ---
# Option 1: Use connection string (recommended for testing)
# Format: Endpoint=sb://<namespace>.servicebus.windows.net/;SharedAccessKeyName=<keyname>;SharedAccessKey=<key>
EVENTHUB_CONNECTION_STRING = ""  # Full connection string, e.g.:

# Option 2: Use managed identity (for Azure-hosted apps)
# Note: EVENTHUB_NAMESPACE should NOT have https:// or port, just the hostname
EVENTHUB_NAMESPACE = (
    "genesis-platform.servicebus.windows.net"  # Just hostname, no https://
)
EVENTHUB_CREDENTIAL_TYPE = "default"  # "default", "managed", or "workload"

# Event Hub names
EVENTHUB_NAME = "otel-traces"
EVENTHUB_RESTRICTED_NAME = "otel-phi-traces"  # For PHI routing
# Retry settings
EVENTHUB_MAX_RETRIES = 3
EVENTHUB_RETRY_DELAY = 1.0
EVENTHUB_RETRY_BACKOFF = 2.0

# --- OTLP Configuration (if ENABLE_OTLP_GRPC or ENABLE_OTLP_HTTP = True) ---
OTLP_ENDPOINT_GRPC = "http://localhost:4317"  # gRPC endpoint
OTLP_ENDPOINT_HTTP = "http://localhost:4318/v1/traces"  # HTTP endpoint
OTLP_HEADERS = {}  # e.g., {"Authorization": "Bearer token"}
OTLP_INSECURE = True  # Set False for TLS
OTLP_COMPRESSION = "none"  # "gzip" or "none"

# --- PHI Detection ---
PHI_DETECTION_ENABLED = True
PHI_PATTERNS = ["phi", "pii", "hipaa", "patient", "ssn", "dob", "medical"]
PHI_USE_WORD_BOUNDARIES = (
    True  # Prevents false positives like "member" in "team_member"
)

# --- Lifecycle Hooks ---
REGISTER_LIFECYCLE_HOOKS = True  # Register atexit, SIGTERM, SIGINT handlers

# --- Batch Processing ---
BATCH_EXPORT = True
MAX_EXPORT_BATCH_SIZE = 512
SCHEDULE_DELAY_MS = 5000
EXPORT_TIMEOUT_MS = 30000

# =============================================================================
# IMPORTS AND SETUP
# =============================================================================


def create_manager():
    """Create NativeOTELManager with the configured settings.

    Uses the new individual enable flags (enable_kafka, enable_eventhub, etc.)
    instead of the deprecated exporter_type enum.
    """
    from autonomize_observer.core.config import KafkaConfig
    from autonomize_observer.core.native_otel_config import (
        EventHubConfig,
        NativeOTELConfig,
    )
    from autonomize_observer.core.otlp_config import OTLPConfig
    from autonomize_observer.tracing import NativeOTELManager

    # Build Kafka config (if enabled)
    kafka_config = None
    if ENABLE_KAFKA:
        kafka_config = KafkaConfig(
            bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
            trace_topic=KAFKA_TRACE_TOPIC,
            restricted_topic=KAFKA_RESTRICTED_TOPIC,
            security_protocol=KAFKA_SECURITY_PROTOCOL,
            sasl_mechanism=KAFKA_SASL_MECHANISM,
            sasl_username=KAFKA_USERNAME,
            sasl_password=KAFKA_PASSWORD,
        )

    # Build Event Hub config (if enabled)
    event_hub_config = None
    if ENABLE_EVENTHUB:
        # Use connection string if provided, otherwise use managed identity
        if EVENTHUB_CONNECTION_STRING:
            event_hub_config = EventHubConfig(
                connection_string=EVENTHUB_CONNECTION_STRING,
                eventhub_name=EVENTHUB_NAME,
                restricted_eventhub_name=EVENTHUB_RESTRICTED_NAME,
                max_retries=EVENTHUB_MAX_RETRIES,
                retry_delay_seconds=EVENTHUB_RETRY_DELAY,
                retry_backoff_multiplier=EVENTHUB_RETRY_BACKOFF,
            )
        else:
            event_hub_config = EventHubConfig(
                fully_qualified_namespace=EVENTHUB_NAMESPACE,
                eventhub_name=EVENTHUB_NAME,
                restricted_eventhub_name=EVENTHUB_RESTRICTED_NAME,
                credential_type=EVENTHUB_CREDENTIAL_TYPE,
                max_retries=EVENTHUB_MAX_RETRIES,
                retry_delay_seconds=EVENTHUB_RETRY_DELAY,
                retry_backoff_multiplier=EVENTHUB_RETRY_BACKOFF,
            )

    # Build OTLP configs (new separate approach)
    otlp_grpc_config = None
    if ENABLE_OTLP_GRPC:
        otlp_grpc_config = OTLPConfig(
            endpoint=OTLP_ENDPOINT_GRPC,
            headers=OTLP_HEADERS,
            insecure=OTLP_INSECURE,
            compression=OTLP_COMPRESSION,
        )

    otlp_http_config = None
    if ENABLE_OTLP_HTTP:
        otlp_http_config = OTLPConfig(
            endpoint=OTLP_ENDPOINT_HTTP,
            headers=OTLP_HEADERS,
            insecure=OTLP_INSECURE,
            compression=OTLP_COMPRESSION,
        )

    # Create config with individual enable flags (new approach)
    # No need to compute exporter_type - each exporter has its own flag
    config = NativeOTELConfig(
        enabled=True,
        service_name=SERVICE_NAME,
        service_version=SERVICE_VERSION,
        environment=ENVIRONMENT,
        organization_id=ORGANIZATION_ID,
        project_id=PROJECT_ID,
        # Individual exporter enable flags (new approach)
        enable_kafka=ENABLE_KAFKA,
        enable_eventhub=ENABLE_EVENTHUB,
        enable_otlp_grpc=ENABLE_OTLP_GRPC,
        enable_otlp_http=ENABLE_OTLP_HTTP,
        enable_console=ENABLE_CONSOLE,
        # Exporter configurations
        kafka_config=kafka_config,
        event_hub_config=event_hub_config,
        otlp_grpc_config=otlp_grpc_config,
        otlp_http_config=otlp_http_config,
        otlp_config=otlp_grpc_config or otlp_http_config,
        # Processing settings
        register_lifecycle_hooks=REGISTER_LIFECYCLE_HOOKS,
        batch_export=BATCH_EXPORT
        if not ENABLE_CONSOLE
        else False,  # Simple processor for console
        max_export_batch_size=MAX_EXPORT_BATCH_SIZE,
        schedule_delay_ms=SCHEDULE_DELAY_MS,
        export_timeout_ms=EXPORT_TIMEOUT_MS,
        set_global_provider=True,
    )

    # Create manager - exporters are automatically set up based on enable flags
    manager = NativeOTELManager(config=config)

    # Build list of enabled exporters for display
    enabled_exporters = []
    if config.uses_console:
        enabled_exporters.append("Console")
    if config.uses_kafka:
        enabled_exporters.append("Kafka")
    if config.uses_event_hub:
        enabled_exporters.append("Event Hub")
    if config.uses_otlp_grpc:
        enabled_exporters.append("OTLP gRPC")
    if config.uses_otlp_http:
        enabled_exporters.append("OTLP HTTP")

    print(f"\n{'=' * 60}")
    print("NativeOTELManager Created")
    print(f"{'=' * 60}")
    print(f"Service: {SERVICE_NAME} v{SERVICE_VERSION}")
    print(f"Environment: {ENVIRONMENT}")
    print(f"Exporters: {', '.join(enabled_exporters) if enabled_exporters else 'None'}")
    print(f"Organization: {ORGANIZATION_ID}")
    print(f"Project: {PROJECT_ID}")
    print(f"PHI Detection: {PHI_DETECTION_ENABLED} (configured at exporter level)")
    print(f"Lifecycle Hooks: {REGISTER_LIFECYCLE_HOOKS}")
    print(f"{'=' * 60}\n")

    return manager


# =============================================================================
# TEST SCENARIOS
# =============================================================================


def test_basic_span(manager):
    """Test 1: Basic span creation."""
    print("\n--- Test 1: Basic Span ---")

    with manager.span("child-span") as _span:
        _span.set_attribute("is_child", True)
        _span.set_attribute("test.value", 42)
        time.sleep(0.1)  # Simulate work
        print("  Created basic span with attributes")


def test_nested_spans(manager):
    """Test 2: Nested spans (parent-child relationships)."""
    print("\n--- Test 2: Nested Spans (3 levels deep) ---")

    with manager.span("parent-operation") as parent_span:
        parent_span.set_attribute("level", 1)
        parent_span.set_attribute("operation.type", "parent")
        print("  Level 1: Parent span started")

        time.sleep(0.05)

        with manager.span("child-operation-1") as child_span_1:
            child_span_1.set_attribute("level", 2)
            child_span_1.set_attribute("operation.type", "child")
            child_span_1.set_attribute("child.index", 1)
            print("    Level 2: Child span 1 started")

            time.sleep(0.05)

            with manager.span("grandchild-operation") as grandchild_span:
                grandchild_span.set_attribute("level", 3)
                grandchild_span.set_attribute("operation.type", "grandchild")
                print("      Level 3: Grandchild span started")
                time.sleep(0.05)
                print("      Level 3: Grandchild span completed")

            print("    Level 2: Child span 1 completed")

        with manager.span("child-operation-2") as child_span_2:
            child_span_2.set_attribute("level", 2)
            child_span_2.set_attribute("operation.type", "child")
            child_span_2.set_attribute("child.index", 2)
            print("    Level 2: Child span 2 started")
            time.sleep(0.05)
            print("    Level 2: Child span 2 completed")

        print("  Level 1: Parent span completed")


def test_deeply_nested_spans(manager):
    """Test 3: Deeply nested spans (5 levels)."""
    print("\n--- Test 3: Deeply Nested Spans (5 levels) ---")

    def create_nested_span(manager, level: int, max_level: int = 5):
        """Recursively create nested spans."""
        indent = "  " * level
        with manager.span(f"level-{level}-span") as span:
            span.set_attribute("depth.level", level)
            span.set_attribute("depth.max", max_level)
            print(f"{indent}Level {level} span started")

            time.sleep(0.02)

            if level < max_level:
                create_nested_span(manager, level + 1, max_level)

            print(f"{indent}Level {level} span completed")

    create_nested_span(manager, 1, 5)


def test_llm_span(manager):
    """Test 4: LLM span with GenAI semantic conventions."""
    print("\n--- Test 4: LLM Span (GenAI Conventions) ---")

    with manager.llm_span(
        operation="chat",
        provider="openai",
        model="gpt-4o",
        input_tokens=150,
        output_tokens=75,
    ) as span:
        # Additional attributes via set_attribute
        span.set_attribute("gen_ai.request.temperature", 0.7)
        span.set_attribute("gen_ai.request.max_tokens", 1000)
        span.set_attribute("gen_ai.request.id", "req-12345")
        span.set_attribute("gen_ai.system", "You are a helpful assistant")
        time.sleep(0.1)

        # Simulate token usage update after response
        span.set_attribute("gen_ai.usage.input_tokens", 152)
        span.set_attribute("gen_ai.usage.output_tokens", 78)
        span.set_attribute("gen_ai.usage.total_tokens", 230)

        print("  Created LLM span with GenAI attributes")


def test_nested_llm_spans(manager):
    """Test 5: Nested LLM spans (agent with multiple LLM calls)."""
    print("\n--- Test 5: Nested LLM Spans (Agent Workflow) ---")

    with manager.span("agent-workflow") as agent_span:
        agent_span.set_attribute("agent.name", "research-agent")
        agent_span.set_attribute("agent.task", "summarize-document")
        print("  Agent workflow started")

        # First LLM call - planning
        with manager.llm_span(
            operation="chat",
            provider="openai",
            model="gpt-4o",
        ) as planning_span:
            planning_span.set_attribute("step", "planning")
            planning_span.set_attribute("gen_ai.usage.input_tokens", 200)
            planning_span.set_attribute("gen_ai.usage.output_tokens", 50)
            time.sleep(0.05)
            print("    Planning LLM call completed")

        # Second LLM call - execution
        with manager.llm_span(
            operation="chat",
            provider="anthropic",
            model="claude-3-5-sonnet",
        ) as execution_span:
            execution_span.set_attribute("step", "execution")
            execution_span.set_attribute("gen_ai.usage.input_tokens", 500)
            execution_span.set_attribute("gen_ai.usage.output_tokens", 300)
            time.sleep(0.05)
            print("    Execution LLM call completed")

        # Third LLM call - summarization
        with manager.llm_span(
            operation="chat",
            provider="openai",
            model="gpt-4o-mini",
        ) as summary_span:
            summary_span.set_attribute("step", "summarization")
            summary_span.set_attribute("gen_ai.usage.input_tokens", 400)
            summary_span.set_attribute("gen_ai.usage.output_tokens", 100)
            time.sleep(0.05)
            print("    Summarization LLM call completed")

        print("  Agent workflow completed")


def test_phi_detection(manager):
    """Test 6: PHI detection and routing."""
    print("\n--- Test 6: PHI Detection ---")

    # Non-PHI span
    with manager.span("fetch-user-preferences") as span:
        span.set_attribute("user.id", "user-123")
        span.set_attribute("preferences.theme", "dark")
        print("  Non-PHI span: fetch-user-preferences")

    # PHI span - detected by name pattern
    with manager.span("fetch-patient-records") as span:
        span.set_attribute("record.count", 5)
        print("  PHI span (name pattern): fetch-patient-records")

    # PHI span - detected by attribute flag
    with manager.span("process-medical-data") as span:
        span.set_attribute("contains_phi", True)  # Explicit PHI flag
        span.set_attribute("data.type", "diagnosis")
        print("  PHI span (explicit flag): process-medical-data")

    # PHI span - HIPAA related
    with manager.span("hipaa-compliance-check") as span:
        span.set_attribute("compliance.status", "passed")
        print("  PHI span (hipaa keyword): hipaa-compliance-check")

    # Non-PHI span with "member" (should NOT trigger due to word boundaries)
    with manager.span("fetch-team-member-count") as span:
        span.set_attribute("team.size", 10)
        print("  Non-PHI span (word boundary test): fetch-team-member-count")


def test_error_handling(manager):
    """Test 7: Error handling and exception recording."""
    print("\n--- Test 7: Error Handling ---")

    try:
        with manager.span("operation-with-error") as span:
            span.set_attribute("attempt", 1)
            print("  Starting operation that will fail...")
            time.sleep(0.05)
            raise ValueError("Simulated error for testing")
    except ValueError as e:
        print(f"  Caught expected error: {e}")
        print("  Error was recorded in span")


def test_manual_span_management(manager):
    """Test 8: Manual span start/end (non-context-manager)."""
    print("\n--- Test 8: Manual Span Management ---")

    # Start span manually
    span = manager.start_span(
        "manual-operation",
        kind="internal",
        attributes={"manual": True},
    )
    print("  Manual span started")

    try:
        time.sleep(0.05)
        span.set_attribute("status", "processing")
        time.sleep(0.05)
        span.set_attribute("status", "completed")
        print("  Manual span processing completed")
    finally:
        manager.end_span(span)
        print("  Manual span ended")


def test_context_propagation(manager):
    """Test 9: Context propagation helpers."""
    print("\n--- Test 9: Context Propagation ---")

    try:
        from autonomize_observer.tracing.propagation import (
            dict_to_kafka_headers,
            extract_trace_context,
            inject_trace_context,
            kafka_headers_to_dict,
        )

        with manager.span("producer-operation") as span:
            # Inject context for propagation
            carrier = inject_trace_context()
            print(f"  Injected trace context: {carrier}")

            # Convert to Kafka headers format
            kafka_headers = dict_to_kafka_headers(carrier)
            print(f"  Kafka headers: {kafka_headers}")

            # Simulate receiving on consumer side
            received_headers = kafka_headers_to_dict(kafka_headers)
            print(f"  Received headers: {received_headers}")

            # Extract context
            parent_context = extract_trace_context(received_headers)
            print(f"  Extracted context: {parent_context}")

    except ImportError as e:
        print(f"  Skipped: {e}")


def test_multi_tenancy(manager):
    """Test 10: Multi-tenancy attributes in spans."""
    print("\n--- Test 10: Multi-Tenancy ---")

    with manager.span("tenant-operation") as span:
        # These are automatically added from config, but can be overridden
        span.set_attribute("autonomize.organization_id", ORGANIZATION_ID)
        span.set_attribute("autonomize.project_id", PROJECT_ID)
        span.set_attribute("autonomize.tenant_context", "verified")
        print(f"  Span with org={ORGANIZATION_ID}, project={PROJECT_ID}")


def test_parallel_spans(manager):
    """Test 11: Parallel operations with sibling spans."""
    print("\n--- Test 11: Parallel Sibling Spans ---")

    import concurrent.futures

    def process_item(item_id: int) -> str:
        with manager.span(f"process-item-{item_id}") as span:
            span.set_attribute("item.id", item_id)
            span.set_attribute("processing.parallel", True)
            time.sleep(0.05)
            return f"processed-{item_id}"

    with manager.span("batch-processing") as parent_span:
        parent_span.set_attribute("batch.size", 3)
        print("  Starting parallel processing...")

        # Note: In real usage, each thread would need proper context propagation
        # This demonstrates the pattern
        results = []
        for i in range(3):
            result = process_item(i)
            results.append(result)
            print(f"    Processed item {i}")

        parent_span.set_attribute("batch.results", len(results))
        print(f"  Batch processing completed: {results}")


def test_workflow_pattern(manager):
    """Test 12: Complete workflow pattern with mixed span types."""
    print("\n--- Test 12: Complete Workflow Pattern ---")

    with manager.span("complete-workflow") as workflow_span:
        workflow_span.set_attribute("workflow.name", "document-analysis")
        workflow_span.set_attribute("workflow.version", "2.0")
        print("  Workflow: document-analysis started")

        # Step 1: Fetch document
        with manager.span("fetch-document") as fetch_span:
            fetch_span.set_attribute("step", 1)
            fetch_span.set_attribute("document.id", "doc-789")
            time.sleep(0.03)
            print("    Step 1: Document fetched")

        # Step 2: Extract text (with nested operations)
        with manager.span("extract-text") as extract_span:
            extract_span.set_attribute("step", 2)

            with manager.span("parse-pdf") as parse_span:
                parse_span.set_attribute("parser", "pdfminer")
                time.sleep(0.02)

            with manager.span("clean-text") as clean_span:
                clean_span.set_attribute("operations", ["normalize", "dedupe"])
                time.sleep(0.02)

            print("    Step 2: Text extracted")

        # Step 3: Analyze with LLM
        with manager.span("analyze-content") as analyze_span:
            analyze_span.set_attribute("step", 3)

            with manager.llm_span(
                operation="chat",
                provider="openai",
                model="gpt-4o",
                input_tokens=1500,
                output_tokens=500,
            ) as llm_span:
                llm_span.set_attribute("analysis.type", "summarization")
                time.sleep(0.05)

            print("    Step 3: Content analyzed")

        # Step 4: Store results
        with manager.span("store-results") as store_span:
            store_span.set_attribute("step", 4)
            store_span.set_attribute("storage.type", "database")
            time.sleep(0.02)
            print("    Step 4: Results stored")

        workflow_span.set_attribute("workflow.status", "completed")
        print("  Workflow: document-analysis completed")


# =============================================================================
# MAIN EXECUTION
# =============================================================================


def main():
    """Run all test scenarios."""
    print("\n" + "=" * 70)
    print("Native OTEL SDK Feature Test")
    print("=" * 70)

    # Create manager
    manager = create_manager()

    if not manager.is_available:
        print("ERROR: Manager failed to configure. Check your settings.")
        return

    # Run all tests
    test_functions = [
        test_basic_span,
        test_nested_spans,
        test_deeply_nested_spans,
        test_llm_span,
        test_nested_llm_spans,
        test_phi_detection,
        test_error_handling,
        test_manual_span_management,
        test_context_propagation,
        test_multi_tenancy,
        test_parallel_spans,
        test_workflow_pattern,
    ]

    for test_func in test_functions:
        try:
            test_func(manager)
        except Exception as e:
            print(f"  ERROR in {test_func.__name__}: {e}")
            import traceback

            traceback.print_exc()

    # Flush and shutdown
    print("\n" + "=" * 70)
    print("Flushing and shutting down...")
    print("=" * 70)

    manager.shutdown()

    print("\n" + "=" * 70)
    print("All tests completed!")
    print("=" * 70)


if __name__ == "__main__":
    main()
