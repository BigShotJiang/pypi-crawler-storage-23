import asyncio
from azure.eventhub.aio import EventHubConsumerClient

CONNECTION_STRING = ""
EVENTHUB_NAME = "otel-traces"
CONSUMER_GROUP = "$Default"


async def on_event(partition_context, event):
    print("Received:", event.body_as_str())
    await partition_context.update_checkpoint(event)


async def main():
    client = EventHubConsumerClient.from_connection_string(
        conn_str=CONNECTION_STRING,
        consumer_group=CONSUMER_GROUP,
        eventhub_name=EVENTHUB_NAME,
    )
    async with client:
        await client.receive(
            on_event=on_event,
            starting_position="-1",  # from beginning
        )


asyncio.run(main())
