# Agent Instructions

## Plan First, Then Act

Before making any code changes, always:
1. Explain your understanding of the task
2. Present a detailed plan of changes (which files will be created/modified, what exactly will change)
3. Ask for explicit confirmation before proceeding with implementation

Do NOT write or modify any code until the user explicitly approves the plan.

## Publishing Documentation

After committing and pushing changes to `docs/` or `mkdocs.yml`, always publish the documentation to GitHub Pages automatically — do not ask the user:

```bash
pip install -r requirements-docs.txt
source .venv/bin/activate && mkdocs gh-deploy --force
```

Documentation dependencies are listed in `requirements-docs.txt`.

The site is hosted at: https://oduist.github.io/oduflow/
