# Odoo 19 Development Guide

Constraint: All code must strictly adhere to Odoo 19.0 standards.
