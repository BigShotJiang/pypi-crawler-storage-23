# Odoo 15 Development Guide

Constraint: All code must strictly adhere to Odoo 15.0 standards.
