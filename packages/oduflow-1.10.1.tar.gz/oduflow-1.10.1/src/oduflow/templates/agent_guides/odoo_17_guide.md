# Odoo 17 Development Guide

Constraint: All code must strictly adhere to Odoo 17.0 standards.
