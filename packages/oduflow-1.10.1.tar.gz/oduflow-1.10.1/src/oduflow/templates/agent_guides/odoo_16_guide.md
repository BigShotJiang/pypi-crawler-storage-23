# Odoo 16 Development Guide

Constraint: All code must strictly adhere to Odoo 16.0 standards.
