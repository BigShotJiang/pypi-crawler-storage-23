# Odoo 18 Development Guide

Constraint: All code must strictly adhere to Odoo 18.0 standards.
