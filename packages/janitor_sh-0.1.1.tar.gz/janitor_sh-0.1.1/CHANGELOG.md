# Changelog

All notable changes to the `janitor-sh` CLI are documented in this file.

## [0.1.1] - 2026-02-23

- Updated README for PyPI by removing private/internal setup content.
- Added public documentation link: https://docs.janitor.sh/.

## [0.1.0] - 2026-02-22

- Initial Rust CLI release with environment-aware orchestration.
- Added tool execution support for Ruff, Biome, Clippy, Cargo Fmt, and rumdl.
- Added commit preference flags (`--auto-commit`, `--no-commit`).

