// @ts-check
import { defineConfig } from 'astro/config';
import starlight from '@astrojs/starlight';
import cloudflare from '@astrojs/cloudflare';

export default defineConfig({
  integrations: [
    starlight({
      title: 'janitor-sh Docs',
      description: 'Automated formatting and linting workflows for local development and CI/CD.',
      logo: {
        light: './src/assets/logo.png',
        dark: './src/assets/logo.png',
        alt: 'janitor-sh logo',
      },
      social: [
        { icon: 'github', label: 'GitHub Action', href: 'https://github.com/janitor-sh/action' },
        { icon: 'gitlab', label: 'GitLab CI Template', href: 'https://github.com/janitor-sh/gitlab-ci' },
        {
          icon: 'github',
          label: 'Examples',
          href: 'https://github.com/orgs/janitor-sh/repositories?q=example',
        },
      ],
      customCss: ['./src/styles/custom.css'],
      sidebar: [
        {
          label: 'Setup',
          items: [
            { slug: 'setup/installation' },
            { slug: 'setup/getting-started' },
          ],
        },
        {
          label: 'CI/CD',
          items: [
            { slug: 'ci/github-action' },
            { slug: 'ci/gitlab-ci' },
          ],
        },
        {
          label: 'Examples',
          items: [
            { slug: 'examples' },
            { slug: 'examples/python' },
            { slug: 'examples/go' },
            { slug: 'examples/rust' },
            { slug: 'examples/typescript' },
            { slug: 'examples/markdown' },
          ],
        },
        {
          label: 'Reference',
          items: [
            { slug: 'reference/cli' },
            { slug: 'reference/action-inputs' },
            { slug: 'reference/gitlab-variables' },
          ],
        },
      ],
    }),
  ],

  adapter: cloudflare({
    platformProxy: {
      enabled: true,
    },
    imageService: 'cloudflare',
  }),
});
