# janitor-sh Documentation Site

This directory contains the public documentation website built with Astro + Starlight and deployed to Cloudflare Pages.

## Local development

Run from `/Users/drew.simmons/developer/github/personal/janitor-sh/cli/docs`.

```bash
bun install
bun run dev
```

The dev server starts on `http://localhost:4321` by default.

## Build and preview

```bash
bun run build
bun run preview
```

## Deploy

Deployment is handled by the repository workflow (`CLI Docs Pages`), but manual deploy is available:

```bash
bun run deploy
```

## Content layout

- Docs content: `src/content/docs/`
- Starlight config: `astro.config.mjs`
- Theme overrides: `src/styles/custom.css`
- Public assets: `public/`
