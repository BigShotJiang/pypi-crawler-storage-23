---
title: TypeScript Example
description: Minimal TypeScript repository example for validating janitor behavior.
---

Repository: [janitor-sh/typescript-example](https://github.com/janitor-sh/typescript-example)

## Run locally

```bash
npm install
npm run dev
```

## Build locally

```bash
npm run build
```

## Validate janitor locally

```bash
janitor --no-commit
```

## CI behavior

The example workflow runs on pushes and pull requests to `main` and executes janitor using:

```yaml
- uses: janitor-sh/action@v1
  with:
    github_token: ${{ secrets.GITHUB_TOKEN }}
    no_commit: "true"
```
