---
title: Rust Example
description: Minimal Rust repository example for validating janitor behavior.
---

Repository: [janitor-sh/rust-example](https://github.com/janitor-sh/rust-example)

## Run locally

```bash
cargo run
```

## Validate janitor locally

```bash
janitor --no-commit
```

## CI behavior

The example workflow runs on pushes and pull requests to `main` and executes janitor using:

```yaml
- uses: janitor-sh/action@v1
  with:
    github_token: ${{ secrets.GITHUB_TOKEN }}
    no_commit: "true"
```
