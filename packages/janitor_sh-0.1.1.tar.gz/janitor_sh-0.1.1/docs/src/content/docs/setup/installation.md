---
title: Installation
description: Install janitor-sh for local use and CI workflows.
---

## Recommended: install from PyPI with uv

```bash
uv tool install janitor-sh
```

Verify installation:

```bash
janitor --help
```

## Prerequisites

- `uv` installed on your machine
- A repository that contains code or documentation files janitor can process

## Source build fallback

Use this if you are testing local source changes or cannot use PyPI.

1. Build from a local checkout:

```bash
cargo build --release
```

2. Run the binary directly:

```bash
./target/release/janitor --help
```

3. Optional install from local source:

```bash
uv tool install . --force
```

## Next step

Continue with [Getting Started](/setup/getting-started/) to run janitor safely in local repositories.
