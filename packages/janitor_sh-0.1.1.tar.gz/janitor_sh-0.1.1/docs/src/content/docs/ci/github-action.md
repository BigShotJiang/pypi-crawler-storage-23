---
title: GitHub Action
description: Integrate janitor-sh into GitHub Actions using janitor-sh/action@v1.
---

Use the official action:

```yaml
name: janitor

on:
  pull_request: {}

permissions:
  contents: write

jobs:
  janitor:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Run janitor
        uses: janitor-sh/action@v1
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          auto_commit: "true"
```

## Inputs

| Input | Description | Default |
| :--- | :--- | :--- |
| `tool` | Run only one tool (for example: `ruff`, `biome`, or `clippy`). | all tools |
| `auto_commit` | When `"true"`, passes `--auto-commit`. | `"false"` |
| `no_commit` | When `"true"`, passes `--no-commit`. | `"false"` |
| `github_token` | Token exposed to janitor for authenticated operations. | `${{ github.token }}` |
| `skip_install` | When `"true"`, skips `uv` and `janitor-sh` installation and uses `janitor` from `PATH`. | `"false"` |

## Rules and behavior

- `auto_commit` and `no_commit` cannot both be `"true"`.
- If both are `"false"`, janitor CLI default behavior is used.
- Use `permissions: contents: write` when janitor may commit changes.
- Use `actions/checkout` with `fetch-depth: 0` when commit creation is enabled.

## Minimal no-commit workflow

```yaml
name: janitor-check

on:
  pull_request: {}

permissions:
  contents: write

jobs:
  janitor:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - uses: janitor-sh/action@v1
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          no_commit: "true"
```
