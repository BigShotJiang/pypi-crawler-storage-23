---
title: GitLab CI/CD
description: Integrate janitor-sh into GitLab pipelines with the reusable janitor-sh template.
---

## Include the template

```yaml
include:
  - remote: 'https://raw.githubusercontent.com/janitor-sh/gitlab-ci/main/.gitlab-ci.yml'

stages:
  - lint

janitor:
  stage: lint
  variables:
    JANITOR_COMMIT_MODE: auto
```

## `JANITOR_COMMIT_MODE`

| Value | Effect |
| :--- | :--- |
| `default` | Run `janitor` with CLI default commit behavior. |
| `auto` | Run `janitor --auto-commit`. |
| `none` | Run `janitor --no-commit`. |

Invalid values fail the job with an explicit error.

## Pipeline behavior in the template

The shared template runs for:

- merge request pipelines (`$CI_PIPELINE_SOURCE == "merge_request_event"`)
- default branch pipelines (`$CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH`)

## Optional template self-tests

For maintainers of the template repository, self-tests can be enabled with:

```yaml
variables:
  JANITOR_TEMPLATE_SELF_TEST: "1"
```

This executes template jobs that verify `JANITOR_COMMIT_MODE` flag mapping (`auto`, `none`, `default`) and invalid-mode failure behavior.
