---
title: CLI Reference
description: Command behavior, flags, and supported tool values for janitor.
---

## Command

```bash
janitor [--tool <name>] [--auto-commit | --no-commit]
```

## Flags

| Flag | Description |
| :--- | :--- |
| `--tool <name>` | Run only one tool. |
| `--auto-commit` | Force commit creation after fixes are applied. |
| `--no-commit` | Force no commit creation. |

`--auto-commit` and `--no-commit` are mutually exclusive.

## Platform-aware defaults

When neither commit flag is set:

- GitHub Actions: auto-commit enabled
- GitLab CI: auto-commit enabled
- Local terminal: auto-commit disabled

## Auto-commit details

When auto-commit is active and tracked files changed:

1. `git add -u`
2. `git commit -m "chore(janitor): apply automated lint/format fixes"`

Auto-commit requires running inside a git repository.

## Supported `--tool` values

| Tool value | Command janitor runs |
| :--- | :--- |
| `ruff` | `ruff check --fix .` |
| `biome` | `biome check --write .` |
| `clippy` | `cargo clippy --fix --allow-dirty -- -D warnings` |
| `cargo-fmt` | `cargo fmt` |
| `rumdl` | `rumdl fmt .` |

If `rumdl` is selected in the full tool run but no Markdown files are present, janitor skips `rumdl`.
