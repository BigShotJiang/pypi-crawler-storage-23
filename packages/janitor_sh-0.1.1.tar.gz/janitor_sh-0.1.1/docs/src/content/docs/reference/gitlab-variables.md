---
title: GitLab Variables Reference
description: Variable contract for janitor-sh GitLab CI template.
---

## `JANITOR_COMMIT_MODE`

Controls which janitor command is executed in the template runner script.

| Value | Executed command |
| :--- | :--- |
| `default` | `janitor` |
| `auto` | `janitor --auto-commit` |
| `none` | `janitor --no-commit` |

Any other value fails the job with:

```text
JANITOR_COMMIT_MODE must be one of: auto, none, default
```

## `JANITOR_TEMPLATE_SELF_TEST`

Used only for template maintenance.

- Set to `"1"` to enable template self-test jobs that validate command mapping behavior.
- Leave unset in normal consumer pipelines.
