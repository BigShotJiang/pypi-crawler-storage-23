---
title: Action Inputs Reference
description: Exact input contract for janitor-sh/action.
---

## Inputs

| Input | Required | Default | Description |
| :--- | :---: | :--- | :--- |
| `tool` | No | none | Run only one tool (for example: `ruff`, `biome`, `clippy`). |
| `auto_commit` | No | `"false"` | When `"true"`, passes `--auto-commit`. |
| `no_commit` | No | `"false"` | When `"true"`, passes `--no-commit`. |
| `github_token` | No | `${{ github.token }}` | Token exposed to janitor for authenticated GitHub operations. |
| `skip_install` | No | `"false"` | When `"true"`, skips `uv` + janitor install and uses `janitor` from `PATH`. |

## Validation rules

- `auto_commit` and `no_commit` cannot both be `"true"`.
- If neither is `"true"`, CLI default commit behavior is used.

## Internal action flow

1. Install `uv` (unless `skip_install == "true"`).
2. Install `janitor-sh` with `uv tool install janitor-sh --force`.
3. Configure git identity as `janitor-sh[bot]`.
4. Build CLI argument list from action inputs.
5. Run `janitor`.
