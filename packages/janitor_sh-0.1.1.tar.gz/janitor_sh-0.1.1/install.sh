#!/bin/bash
set -e

# Detect OS
OS="$(uname -s)"
case "${OS}" in
    Linux*)     OS_TYPE=linux;;
    Darwin*)    OS_TYPE=macos;;
    *)          OS_TYPE=unknown;;
esac

echo "Installing janitor-sh for ${OS_TYPE}..."

# Ensure uv is installed
if ! command -v uv &> /dev/null
then
    echo "uv could not be found. Please install it first: https://github.com/astral-sh/uv"
    exit 1
fi

# Build Rust CLI
echo "Building core CLI..."
cargo build --release

# Note: Installation via `uv tool install .` may fail in some environments (like macOS Seatbelt).
# You can manually link the binary or use `cargo install --path .` if uv fails.
echo "To finish installation, try: uv tool install ."

echo "janitor-sh has been installed! You can now run it with 'janitor'."
