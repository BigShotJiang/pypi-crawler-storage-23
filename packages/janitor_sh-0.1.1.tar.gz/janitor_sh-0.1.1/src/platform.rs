#[derive(Debug, PartialEq)]
pub enum Platform {
    GitHubActions,
    GitLabCI,
    Local,
}

use std::env;
use std::fs;
use std::path::Path;

pub fn detect_platform() -> Platform {
    if env::var("GITHUB_ACTIONS").is_ok() {
        Platform::GitHubActions
    } else if env::var("GITLAB_CI").is_ok() {
        Platform::GitLabCI
    } else {
        Platform::Local
    }
}

pub fn has_markdown_files<P: AsRef<Path>>(dir: P) -> bool {
    if let Ok(entries) = fs::read_dir(dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                let file_name = path.file_name().and_then(|n| n.to_str());
                if file_name == Some(".git") || file_name == Some("target") {
                    continue;
                }
                if has_markdown_files(&path) {
                    return true;
                }
            } else if path
                .extension()
                .and_then(|s| s.to_str())
                .map(|s| s.to_ascii_lowercase())
                == Some("md".to_string())
            {
                return true;
            }
        }
    }
    false
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;

    #[test]
    fn test_detect_github_actions() {
        unsafe {
            env::set_var("GITHUB_ACTIONS", "true");
            env::remove_var("GITLAB_CI");
        }
        assert_eq!(detect_platform(), Platform::GitHubActions);
    }

    #[test]
    fn test_detect_gitlab_ci() {
        unsafe {
            env::remove_var("GITHUB_ACTIONS");
            env::set_var("GITLAB_CI", "true");
        }
        assert_eq!(detect_platform(), Platform::GitLabCI);
    }

    #[test]
    fn test_detect_local() {
        unsafe {
            env::remove_var("GITHUB_ACTIONS");
            env::remove_var("GITLAB_CI");
        }
        assert_eq!(detect_platform(), Platform::Local);
    }

    #[test]
    fn test_has_markdown() {
        // Since test.md exists in the repo root, this should be true.
        assert!(has_markdown_files("."));
    }

    #[test]
    fn test_no_markdown_in_src() {
        // No .md files in src directory.
        assert!(!has_markdown_files("./src"));
    }
}
