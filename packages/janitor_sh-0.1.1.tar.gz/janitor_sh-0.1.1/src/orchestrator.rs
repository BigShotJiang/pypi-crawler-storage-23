pub trait LintTool {
    fn name(&self) -> &str;
    fn get_command(&self) -> Vec<String>;
}

pub struct Ruff;
impl LintTool for Ruff {
    fn name(&self) -> &str {
        "ruff"
    }
    fn get_command(&self) -> Vec<String> {
        vec![
            "ruff".to_string(),
            "check".to_string(),
            "--fix".to_string(),
            ".".to_string(),
        ]
    }
}

pub struct Biome;
impl LintTool for Biome {
    fn name(&self) -> &str {
        "biome"
    }
    fn get_command(&self) -> Vec<String> {
        vec![
            "biome".to_string(),
            "check".to_string(),
            "--write".to_string(),
            ".".to_string(),
        ]
    }
}

pub struct Clippy;
impl LintTool for Clippy {
    fn name(&self) -> &str {
        "clippy"
    }
    fn get_command(&self) -> Vec<String> {
        vec![
            "cargo".to_string(),
            "clippy".to_string(),
            "--fix".to_string(),
            "--allow-dirty".to_string(),
            "--".to_string(),
            "-D".to_string(),
            "warnings".to_string(),
        ]
    }
}

pub struct CargoFmt;
impl LintTool for CargoFmt {
    fn name(&self) -> &str {
        "cargo-fmt"
    }
    fn get_command(&self) -> Vec<String> {
        vec!["cargo".to_string(), "fmt".to_string()]
    }
}

pub struct Rumdl;
impl LintTool for Rumdl {
    fn name(&self) -> &str {
        "rumdl"
    }
    fn get_command(&self) -> Vec<String> {
        vec!["rumdl".to_string(), "fmt".to_string(), ".".to_string()]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ruff_command() {
        let tool = Ruff;
        assert_eq!(tool.name(), "ruff");
        assert_eq!(tool.get_command(), vec!["ruff", "check", "--fix", "."]);
    }

    #[test]
    fn test_biome_command() {
        let tool = Biome;
        assert_eq!(tool.name(), "biome");
        assert_eq!(tool.get_command(), vec!["biome", "check", "--write", "."]);
    }

    #[test]
    fn test_clippy_command() {
        let tool = Clippy;
        assert_eq!(tool.name(), "clippy");
        assert_eq!(
            tool.get_command(),
            vec![
                "cargo",
                "clippy",
                "--fix",
                "--allow-dirty",
                "--",
                "-D",
                "warnings"
            ]
        );
    }

    #[test]
    fn test_cargo_fmt_command() {
        let tool = CargoFmt;
        assert_eq!(tool.name(), "cargo-fmt");
        assert_eq!(tool.get_command(), vec!["cargo", "fmt"]);
    }

    #[test]
    fn test_rumdl_command() {
        let tool = Rumdl;
        assert_eq!(tool.name(), "rumdl");
        assert_eq!(tool.get_command(), vec!["rumdl", "fmt", "."]);
    }
}
