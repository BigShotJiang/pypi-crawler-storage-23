mod orchestrator;
mod platform;

use crate::orchestrator::{Biome, CargoFmt, Clippy, LintTool, Ruff, Rumdl};
use crate::platform::{Platform, detect_platform, has_markdown_files};

use std::env;
use std::process::Command;

const AUTO_COMMIT_MESSAGE: &str = "chore(janitor): apply automated lint/format fixes";

#[derive(Clone, Copy, Debug, PartialEq)]
enum CommitPreference {
    Default,
    AutoCommit,
    NoCommit,
}

#[derive(Debug, PartialEq)]
struct CliOptions {
    tool: Option<String>,
    commit_preference: CommitPreference,
}

fn parse_args(args: &[String]) -> Result<CliOptions, String> {
    let mut tool: Option<String> = None;
    let mut commit_preference = CommitPreference::Default;

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--tool" => {
                if i + 1 >= args.len() {
                    return Err("--tool requires a value".to_string());
                }
                tool = Some(args[i + 1].clone());
                i += 2;
            }
            "--auto-commit" => {
                if commit_preference == CommitPreference::NoCommit {
                    return Err("--auto-commit cannot be used with --no-commit".to_string());
                }
                commit_preference = CommitPreference::AutoCommit;
                i += 1;
            }
            "--no-commit" => {
                if commit_preference == CommitPreference::AutoCommit {
                    return Err("--no-commit cannot be used with --auto-commit".to_string());
                }
                commit_preference = CommitPreference::NoCommit;
                i += 1;
            }
            arg => {
                return Err(format!("unknown argument: {arg}"));
            }
        }
    }

    Ok(CliOptions {
        tool,
        commit_preference,
    })
}

fn should_auto_commit(platform: Platform, preference: CommitPreference) -> bool {
    match preference {
        CommitPreference::AutoCommit => true,
        CommitPreference::NoCommit => false,
        CommitPreference::Default => {
            platform == Platform::GitHubActions || platform == Platform::GitLabCI
        }
    }
}

fn is_git_repository() -> bool {
    Command::new("git")
        .args(["rev-parse", "--is-inside-work-tree"])
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

fn has_tracked_changes() -> bool {
    let unstaged_clean = Command::new("git")
        .args(["diff", "--quiet", "--"])
        .status()
        .map(|status| status.success())
        .unwrap_or(true);

    let staged_clean = Command::new("git")
        .args(["diff", "--cached", "--quiet", "--"])
        .status()
        .map(|status| status.success())
        .unwrap_or(true);

    !(unstaged_clean && staged_clean)
}

fn create_auto_commit() -> Result<(), String> {
    let add_status = Command::new("git")
        .args(["add", "-u"])
        .status()
        .map_err(|e| format!("Failed to stage files: {e}"))?;
    if !add_status.success() {
        return Err("Failed to stage files with git add -u".to_string());
    }

    let commit_status = Command::new("git")
        .args(["commit", "-m", AUTO_COMMIT_MESSAGE])
        .status()
        .map_err(|e| format!("Failed to create commit: {e}"))?;
    if !commit_status.success() {
        return Err("git commit failed".to_string());
    }

    Ok(())
}

fn build_tools(tool_filter: Option<&str>) -> Result<Vec<Box<dyn LintTool>>, String> {
    let all_tools: Vec<Box<dyn LintTool>> = vec![
        Box::new(Ruff),
        Box::new(Biome),
        Box::new(Clippy),
        Box::new(CargoFmt),
        Box::new(Rumdl),
    ];

    if let Some(filter) = tool_filter {
        let mut selected = Vec::new();
        for tool in all_tools {
            if tool.name() == filter {
                selected.push(tool);
            }
        }
        if selected.is_empty() {
            return Err(format!("Unsupported tool: {filter}"));
        }
        return Ok(selected);
    }

    Ok(all_tools)
}

fn run() -> Result<(), String> {
    let args: Vec<String> = env::args().skip(1).collect();
    let options = parse_args(&args)?;
    let platform = detect_platform();
    let auto_commit_enabled = should_auto_commit(platform, options.commit_preference);

    let tools = build_tools(options.tool.as_deref())?;

    for tool in tools {
        if tool.name() == "rumdl" && !has_markdown_files(".") {
            continue;
        }
        let cmd_parts = tool.get_command();
        if cmd_parts.is_empty() {
            continue;
        }

        let mut command = Command::new(&cmd_parts[0]);
        for arg in &cmd_parts[1..] {
            command.arg(arg);
        }

        match command.status() {
            Ok(status) => {
                if !status.success() {
                    return Err(format!("{} failed with status {}", tool.name(), status));
                }
            }
            Err(e) => {
                return Err(format!("Failed to execute {}: {}", tool.name(), e));
            }
        }
    }

    if auto_commit_enabled {
        if !is_git_repository() {
            return Err(
                "Auto-commit requested, but current directory is not a git repository".to_string(),
            );
        }
        if has_tracked_changes() {
            create_auto_commit()?;
        }
    }

    Ok(())
}

fn main() {
    if let Err(err) = run() {
        eprintln!("Error: {err}");
        std::process::exit(1);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::path::PathBuf;
    use std::sync::{Mutex, OnceLock};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn test_lock() -> &'static Mutex<()> {
        static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
        LOCK.get_or_init(|| Mutex::new(()))
    }

    fn unique_temp_dir(name: &str) -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!("janitor-{name}-{}-{nanos}", std::process::id()))
    }

    fn run_git(args: &[&str]) {
        let status = Command::new("git").args(args).status().unwrap();
        assert!(
            status.success(),
            "git command failed: git {}",
            args.join(" ")
        );
    }

    fn run_git_output(args: &[&str]) -> String {
        let output = Command::new("git").args(args).output().unwrap();
        assert!(
            output.status.success(),
            "git command failed: git {}",
            args.join(" ")
        );
        String::from_utf8(output.stdout).unwrap().trim().to_string()
    }

    fn setup_temp_repo(name: &str) -> (PathBuf, PathBuf) {
        let original_dir = std::env::current_dir().unwrap();
        let repo_dir = unique_temp_dir(name);
        fs::create_dir_all(&repo_dir).unwrap();
        std::env::set_current_dir(&repo_dir).unwrap();

        run_git(&["init"]);
        run_git(&["config", "user.name", "janitor-test"]);
        run_git(&["config", "user.email", "janitor-test@example.com"]);
        run_git(&["config", "commit.gpgsign", "false"]);

        fs::write(repo_dir.join("tracked.txt"), "initial\n").unwrap();
        run_git(&["add", "tracked.txt"]);
        run_git(&["commit", "-m", "chore: seed"]);

        (repo_dir, original_dir)
    }

    fn teardown_temp_repo(repo_dir: PathBuf, original_dir: PathBuf) {
        std::env::set_current_dir(original_dir).unwrap();
        fs::remove_dir_all(repo_dir).unwrap();
    }

    #[test]
    fn test_parse_args_no_flags() {
        let args: Vec<String> = vec![];
        let parsed = parse_args(&args).unwrap();
        assert_eq!(
            parsed,
            CliOptions {
                tool: None,
                commit_preference: CommitPreference::Default
            }
        );
    }

    #[test]
    fn test_parse_args_tool() {
        let args: Vec<String> = vec!["--tool".to_string(), "ruff".to_string()];
        let parsed = parse_args(&args).unwrap();
        assert_eq!(
            parsed,
            CliOptions {
                tool: Some("ruff".to_string()),
                commit_preference: CommitPreference::Default
            }
        );
    }

    #[test]
    fn test_parse_args_auto_commit() {
        let args: Vec<String> = vec!["--auto-commit".to_string()];
        let parsed = parse_args(&args).unwrap();
        assert_eq!(parsed.commit_preference, CommitPreference::AutoCommit);
    }

    #[test]
    fn test_parse_args_no_commit() {
        let args: Vec<String> = vec!["--no-commit".to_string()];
        let parsed = parse_args(&args).unwrap();
        assert_eq!(parsed.commit_preference, CommitPreference::NoCommit);
    }

    #[test]
    fn test_parse_args_rejects_conflicting_flags() {
        let args: Vec<String> = vec!["--auto-commit".to_string(), "--no-commit".to_string()];
        let parsed = parse_args(&args);
        assert!(parsed.is_err());
    }

    #[test]
    fn test_should_auto_commit_default_local() {
        assert!(!should_auto_commit(
            Platform::Local,
            CommitPreference::Default
        ));
    }

    #[test]
    fn test_should_auto_commit_default_github_actions() {
        assert!(should_auto_commit(
            Platform::GitHubActions,
            CommitPreference::Default
        ));
    }

    #[test]
    fn test_should_auto_commit_default_gitlab_ci() {
        assert!(should_auto_commit(
            Platform::GitLabCI,
            CommitPreference::Default
        ));
    }

    #[test]
    fn test_should_auto_commit_explicit_override() {
        assert!(should_auto_commit(
            Platform::Local,
            CommitPreference::AutoCommit
        ));
        assert!(!should_auto_commit(
            Platform::GitHubActions,
            CommitPreference::NoCommit
        ));
    }

    #[test]
    fn test_build_tools_filter() {
        let selected = build_tools(Some("ruff")).unwrap();
        assert_eq!(selected.len(), 1);
        assert_eq!(selected[0].name(), "ruff");
    }

    #[test]
    fn test_build_tools_invalid_filter() {
        let selected = build_tools(Some("unknown-tool"));
        assert!(selected.is_err());
    }

    #[test]
    fn test_create_auto_commit_on_tracked_change() {
        let _guard = test_lock().lock().unwrap_or_else(|e| e.into_inner());
        let (repo_dir, original_dir) = setup_temp_repo("auto-commit-tracked");
        fs::write(repo_dir.join("tracked.txt"), "updated\n").unwrap();

        assert!(has_tracked_changes());
        create_auto_commit().unwrap();
        assert!(!has_tracked_changes());

        let subject = run_git_output(&["log", "-1", "--pretty=%s"]);
        assert_eq!(subject, AUTO_COMMIT_MESSAGE);

        teardown_temp_repo(repo_dir, original_dir);
    }

    #[test]
    fn test_auto_commit_does_not_stage_untracked_files() {
        let _guard = test_lock().lock().unwrap_or_else(|e| e.into_inner());
        let (repo_dir, original_dir) = setup_temp_repo("auto-commit-untracked");
        fs::write(repo_dir.join("tracked.txt"), "updated\n").unwrap();
        fs::write(repo_dir.join("new_untracked.txt"), "untracked\n").unwrap();

        create_auto_commit().unwrap();

        let tracked_in_head = run_git_output(&["ls-tree", "--name-only", "HEAD"]);
        assert!(tracked_in_head.lines().any(|line| line == "tracked.txt"));
        assert!(
            !tracked_in_head
                .lines()
                .any(|line| line == "new_untracked.txt")
        );

        let status = run_git_output(&["status", "--porcelain"]);
        assert!(
            status
                .lines()
                .any(|line| line.ends_with("new_untracked.txt"))
        );

        teardown_temp_repo(repo_dir, original_dir);
    }
}
