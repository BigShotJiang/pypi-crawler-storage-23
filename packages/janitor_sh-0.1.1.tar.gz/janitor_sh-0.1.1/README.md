# janitor-sh CLI 🧹

The core Rust-based engine for the **janitor-sh** organization. This CLI
provides high-performance, automated code formatting and linting orchestration
across CI/CD environments.

Documentation: [https://docs.janitor.sh/](https://docs.janitor.sh/)

## Features

- **Multi-Platform Detection:** Automatically identifies if it's running in
  GitHub Actions, GitLab CI, or another shell environment.
- **Smart Orchestration:** Invokes industry-standard tools based on the project
  structure:
  - **Ruff:** For lightning-fast Python linting and formatting.
  - **Biome:** For high-performance JavaScript/TypeScript orchestration.
  - **rumdl:** For consistent formatting of Markdown and documentation files.
  - **Clippy & Cargo Fmt:** For maintaining Rust code quality.
- **Automated Fixes:** Designed to automatically apply and commit fixes to
  minimize developer overhead.

## Installation

Install with `uv`:

```bash
uv tool install janitor-sh
```

## Usage

Run the janitor CLI from the root of any supported repository:

```bash
janitor
```

The tool will automatically detect your environment and run the appropriate
suite of formatters and linters.

### Commit Mode Flags

- `--auto-commit`: force creation of an automated conventional commit when janitor applies fixes.
- `--no-commit`: force janitor to skip commit creation.
- default behavior:
  - in CI (`GitHub Actions` and `GitLab CI`): auto-commit enabled.
  - outside CI: no auto-commit.

You can also scope execution to a single tool:

```bash
janitor --tool ruff
```

## Development

### Running Tests

We maintain high standards for correctness and platform compatibility.

```bash
cargo test
```

### Linting & Formatting

Ensure your contributions follow our style guidelines:

```bash
cargo clippy -- -D warnings
cargo fmt -- --check
```

## Release Runbook

One-time repository setup:

- Create GitHub environment `pypi` (recommended: protect with tag-only deploy rules).
- Configure a PyPI Trusted Publisher for this repository/workflow/environment.
- Set Cloudflare deployment settings:
  - secret: `CLOUDFLARE_API_TOKEN`
  - secret: `CLOUDFLARE_ACCOUNT_ID`
  - variable: `CLOUDFLARE_PAGES_PROJECT`

1. Update `version` in `/Users/drew.simmons/developer/github/personal/janitor-sh/cli/pyproject.toml`.
2. Update `/Users/drew.simmons/developer/github/personal/janitor-sh/cli/CHANGELOG.md`.
3. Update `/Users/drew.simmons/developer/github/personal/janitor-sh/cli/docs/src/pages/docs/release-notes.md`.
4. Merge to `main` and create a GitHub Release tag in the form `vX.Y.Z`.
5. Monitor these workflows:
   - `/Users/drew.simmons/developer/github/personal/janitor-sh/.github/workflows/cli-release.yml`
   - `/Users/drew.simmons/developer/github/personal/janitor-sh/.github/workflows/cli-docs-pages.yml`
6. Verify successful publication on PyPI and docs deployment on Cloudflare Pages.
