"""NA-Tools 入口模块。"""

from na_tools.cli import main

if __name__ == "__main__":
    main()
