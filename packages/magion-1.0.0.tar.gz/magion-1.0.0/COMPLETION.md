# 🧲 MAGION Shell Completion

MAGION provides shell completion for bash, zsh, and fish shells.

---

## Installation

### Bash
```bash
eval "$(_MAGION_COMPLETE=bash_source magion)"
```

Zsh

```zsh
eval "$(_MAGION_COMPLETE=zsh_source magion)"
```

Fish

```fish
eval (env _MAGION_COMPLETE=fish_source magion)
```

---

Available Commands

Core Commands

Command Description
magion monitor Real-time SEI monitoring
magion sei Calculate Shield Efficiency Index
magion forecast Generate 6-hour SEI forecast
magion dashboard Launch interactive dashboard
magion stations List neutron monitor stations
magion alerts Check active space weather alerts

Parameter Commands

```bash
magion monitor rs          # Magnetopause Standoff Distance
magion monitor nmf         # Neutron Monitor Flux
magion monitor kp          # Geomagnetic Index
magion monitor np          # Solar Wind Proton Density
magion monitor rc          # Rigidity Cutoff
magion monitor tec         # Total Electron Content
magion monitor va          # Alfvén Velocity
magion monitor fd          # Forbush Decrease
magion monitor sei         # Composite SEI Score
```

Station Commands

```bash
magion stations list                          # List all 52 neutron monitor stations
magion stations show --code NEWK               # Show station details (Newark)
magion stations compare --s1 THUL --s2 MCMURD  # Compare two stations
magion stations region --latitude polar        # Filter by latitude band
```

SEI Thresholds

```bash
magion sei --status quiet          # SEI 95-100% ⚪
magion sei --status unsettled      # SEI 80-94% 🟢
magion sei --status storm-alert    # SEI 60-79% 🟡
magion sei --status severe-blast    # SEI 40-59% 🟠
magion sei --status critical        # SEI 0-39% 🔴
```

Space Weather Monitoring

```bash
magion magnetopause status         # Current standoff distance
magion rigidity map --region global # Show rigidity cutoff map
magion forbush detect --threshold 5% # Detect Forbush decreases
magion tec anomaly --lat 60 --lon -100 # Check TEC at location
```

---

Examples

```bash
# Monitor real-time SEI
magion monitor --source all --update 60

# Forecast for next 6 hours
magion forecast --hours 6 --model lstm --output json

# Check active alerts
magion alerts --status active --severity critical

# List all stations with SEI contribution > 10%
magion stations list --sei-min 10 --details

# Calculate SEI for specific time
magion sei --timestamp 2026-03-04T12:00:00Z --verbose

# Run historical analysis
magion analyze --storm halloween-2003 --parameters all

# Launch dashboard
magion dashboard --port 8501 --map-type global

# Simulate CME impact
magion simulate --cme-speed 2000 --density 50 --bz -30
```

---

Tab Completion Features

Station Name Completion

· Auto-completes from 52 neutron monitor stations
· Groups by latitude (polar, mid-latitude, equatorial)

Parameter Completion

· All 8 SEI parameters
· Parameter groups (magnetospheric, ionospheric, cosmic ray)

Region Completion

· polar-north (>60°N)
· polar-south (<-60°S)
· mid-latitude-north (30-60°N)
· mid-latitude-south (30-60°S)
· equatorial (-30-30°)

SEI Status Colors

· ⚪ QUIET        (SEI 95-100%)
· 🟢 UNSETTLED    (SEI 80-94%)
· 🟡 STORM ALERT  (SEI 60-79%)
· 🟠 SEVERE BLAST (SEI 40-59%)
· 🔴 CRITICAL     (SEI 0-39%)

---

Environment Variables

```bash
export MAGION_CONFIG=~/.magion/config.yaml
export MAGION_DATA_DIR=/data/magion
export NOAA_SWPC_KEY=your_key_here
export NASA_ACE_TOKEN=your_token_here
export NMDB_API_KEY=your_key_here
export INTERMAGNET_TOKEN=your_token_here
export IGS_TEC_KEY=your_key_here
```

---

Live Resources

· Dashboard: https://magion.space
· Documentation: https://magion.readthedocs.io
· NOAA SWPC: https://swpc.noaa.gov
· NASA ACE: https://www.swpc.noaa.gov/ace
· NMDB: http://www.nmdb.eu
· IGS TEC: https://igs.org/maps

---

🧲 The magnetosphere has protected Earth for 3.5 billion years. MAGION ensures we know when it falters.
