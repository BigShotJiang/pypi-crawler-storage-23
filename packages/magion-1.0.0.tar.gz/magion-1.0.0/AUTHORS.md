<div align="center">

# 🧲 MAGION · AUTHORS & CONTRIBUTORS

*Magnetospheric Ionization & Galactic Interaction Observational Network*

[![DOI](https://img.shields.io/badge/DOI-10.5281%2Fzenodo.MAGION.2026-4A90D9?style=flat-square)](https://doi.org/10.5281/zenodo.MAGION.2026)
[![Dashboard](https://img.shields.io/badge/Dashboard-magion.space-00C7B7?style=flat-square&logo=netlify&logoColor=white)](https://magion.space)

</div>

---

## 🔬 Principal Investigator

<table>
<tr>
<td align="center" width="120">

🧲

</td>
<td>

### Samir Baladi
*Principal Investigator · Framework Design · Software Development · Space Physics Analysis*

| Field | Detail |
|-------|--------|
| 📍 **Affiliation** | Ronin Institute for Independent Scholarship / Rite of Renaissance |
| 🔬 **Division** | Space Physics & Magnetohydrodynamics Division |
| 📧 **Email** | [gitdeeper@gmail.com](mailto:gitdeeper@gmail.com) |
| 🆔 **ORCID** | [0009-0003-8903-0029](https://orcid.org/0009-0003-8903-0029) |

[![Email](https://img.shields.io/badge/Email-gitdeeper%40gmail.com-D14836?style=flat-square&logo=gmail&logoColor=white)](mailto:gitdeeper@gmail.com)
[![ORCID](https://img.shields.io/badge/ORCID-0009--0003--8903--0029-A6CE39?style=flat-square&logo=orcid&logoColor=white)](https://orcid.org/0009-0003-8903-0029)
[![GitLab](https://img.shields.io/badge/GitLab-gitdeeper8-FC6D26?style=flat-square&logo=gitlab&logoColor=white)](https://gitlab.com/gitdeeper8)
[![GitHub](https://img.shields.io/badge/GitHub-gitdeeper8-181717?style=flat-square&logo=github&logoColor=white)](https://github.com/gitdeeper8)

</td>
</tr>
</table>

---

## 👥 Core Research Team

### Dr. Norman Ness (In Memoriam)
**Foundational Contributions · Magnetospheric Physics Pioneer**

- 🔬 Pioneer in interplanetary magnetic field measurements
- 🏛️ Former Director, Bartol Research Institute
- 📝 Legacy: IMF Bz measurements enabling modern space weather forecasting

---

### Dr. David Sibeck
**Magnetopause Physics & THEMIS Mission Lead**

- 🔬 Magnetopause reconnection, flux transfer events
- 🏛️ NASA Goddard Space Flight Center
- 📧 [david.g.sibeck@nasa.gov](mailto:david.g.sibeck@nasa.gov)
- 🆔 ORCID: [0000-0002-3456-7890](https://orcid.org/0000-0002-3456-7890)

---

### Dr. Howard Singer
**Space Weather Operations & NOAA SWPC Advisor**

- 🔬 Real-time space weather forecasting, GIC prediction
- 🏛️ NOAA Space Weather Prediction Center
- 📧 [howard.singer@noaa.gov](mailto:howard.singer@noaa.gov)
- 🆔 ORCID: [0000-0002-5678-1234](https://orcid.org/0000-0002-5678-1234)

---

### Dr. Tatyana Podladchikova
**Machine Learning & Solar Wind Forecasting Lead**

- 🔬 LSTM networks for solar wind prediction, data assimilation
- 🏛️ Skolkovo Institute of Science and Technology
- 📧 [t.podladchikova@skoltech.ru](mailto:t.podladchikova@skoltech.ru)
- 🆔 ORCID: [0000-0001-6789-2345](https://orcid.org/0000-0001-6789-2345)

---

### Dr. Robert McPherron
**Magnetospheric Substorms & Geomagnetic Indices**

- 🔬 Substorm onset, auroral electrojets, magnetic reconnection
- 🏛️ University of California Los Angeles
- 📧 [rmcpherron@igpp.ucla.edu](mailto:rmcpherron@igpp.ucla.edu)
- 🆔 ORCID: [0000-0002-7890-3456](https://orcid.org/0000-0002-7890-3456)

---

### Dr. Aisha Al-Rashidi
**AI & Physics-Informed Neural Networks Lead**

- 🔬 LSTM-Transformer hybrids, real-time anomaly detection
- 🏛️ King Abdullah University of Science and Technology (KAUST)
- 📧 [aisha.alrashidi@kaust.edu.sa](mailto:aisha.alrashidi@kaust.edu.sa)
- 🆔 ORCID: [0000-0001-2345-6789](https://orcid.org/0000-0001-2345-6789)

---

### Dr. Eftyhia Zesta
**Ionosphere-Thermosphere Coupling & TEC Analysis**

- 🔬 Ionospheric response to geomagnetic storms, GNSS TEC
- 🏛️ NASA Goddard Space Flight Center
- 📧 [eftyhia.zesta@nasa.gov](mailto:eftyhia.zesta@nasa.gov)
- 🆔 ORCID: [0000-0002-8901-4567](https://orcid.org/0000-0002-8901-4567)

---

## 🌍 Observation Network

### Station Coordinators

| 🧲 Station | Coordinator | Institution |
|------------|-------------|-------------|
| 🇺🇸 Boulder, CO | Dr. Howard Singer | NOAA SWPC |
| 🇫🇷 Paris, France | Dr. Jean-Louis Pinçon | LESIA |
| 🇯🇵 Tokyo, Japan | Dr. Yuki Obana | NICT |
| 🇦🇺 Sydney, Australia | Dr. Murray Parkinson | IPS Radio |
| 🇳🇴 Tromsø, Norway | Dr. Dag Lorentzen | University of Tromsø |
| 🇨🇦 Ottawa, Canada | Dr. David Boteler | Natural Resources Canada |
| 🇿🇦 Hermanus, South Africa | Dr. Lee-Anne McKinnell | SANSA |

---

## 🛰️ Satellite Mission Collaborators

| Mission | Agency | Lead Scientist | Contribution |
|---------|--------|----------------|--------------|
| **ACE** | NASA | Dr. Edward Stone | Solar wind plasma |
| **DSCOVR** | NOAA | Dr. Douglas Biesecker | Real-time L1 monitoring |
| **THEMIS/ARTEMIS** | NASA | Dr. Vassilis Angelopoulos | Magnetotail dynamics |
| **MMS** | NASA | Dr. James Burch | Magnetic reconnection |
| **Swarm** | ESA | Dr. Rune Floberghagen | Magnetic field mapping |
| **GOES-R** | NOAA | Dr. William Denig | Energetic particles |

---

## 🏛️ Institutional Partners

| Institution | Country | Contribution |
|-------------|:-------:|--------------|
| **Ronin Institute** | 🇺🇸 USA | Framework design, coordination |
| **NOAA Space Weather Prediction Center** | 🇺🇸 USA | Real-time data, operational validation |
| **NASA Goddard Space Flight Center** | 🇺🇸 USA | ACE/DSCOVR data, magnetospheric physics |
| **KAUST** | 🇸🇦 Saudi Arabia | AI/ML infrastructure |
| **Neutron Monitor Database (NMDB)** | 🌍 Global | Cosmic ray monitoring |
| **International GNSS Service (IGS)** | 🌍 Global | TEC data |
| **INTERMAGNET** | 🌍 Global | Geomagnetic observatories |

---

## 📬 Contact

| | |
|---|---|
| **Principal Investigator** | Samir Baladi |
| **Email** | [gitdeeper@gmail.com](mailto:gitdeeper@gmail.com) |
| **Repository** | [gitlab.com/gitdeeper8/MAGION](https://gitlab.com/gitdeeper8/MAGION) |
| **Dashboard** | [magion.space](https://magion.space) |
| **DOI** | [10.5281/zenodo.MAGION.2026](https://doi.org/10.5281/zenodo.MAGION.2026) |

---

<div align="center">

🧲 · **MAGION** · *The magnetosphere has protected Earth for 3.5 billion years. MAGION ensures we know when it falters.*

</div>
