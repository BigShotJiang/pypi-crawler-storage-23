#!/bin/bash
# MAGION Setup Script
# Creates virtual environment and installs dependencies

echo "========================================="
echo "🧲 MAGION - Setup Script"
echo "========================================="

# Check Python version
python_version=$(python3 --version 2>&1 | cut -d' ' -f2)
echo "Python version: $python_version"

# Create virtual environment
echo -n "Creating virtual environment..."
python3 -m venv .venv
if [ $? -eq 0 ]; then
    echo " ✓"
else
    echo " ✗"
    exit 1
fi

# Activate virtual environment
echo -n "Activating virtual environment..."
source .venv/bin/activate
if [ $? -eq 0 ]; then
    echo " ✓"
else
    echo " ✗"
    exit 1
fi

# Upgrade pip
echo -n "Upgrading pip..."
pip install --upgrade pip > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo " ✓"
else
    echo " ✗"
fi

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Install in development mode
echo -n "Installing MAGION in development mode..."
pip install -e . > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo " ✓"
else
    echo " ✗"
    exit 1
fi

# Install pre-commit hooks
echo -n "Installing pre-commit hooks..."
pre-commit install > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo " ✓"
else
    echo " ✗ (optional)"
fi

echo ""
echo "========================================="
echo "✅ Setup complete! 🧲"
echo "========================================="
echo ""
echo "To activate the environment:"
echo "  source .venv/bin/activate"
echo ""
echo "To test installation:"
echo "  python -c 'import magion; print(magion.__version__)'"
echo ""
echo "To run examples:"
echo "  python examples/basic_usage.py"
echo ""
