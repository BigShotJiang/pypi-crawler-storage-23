#!/bin/bash
# MAGION Data Download Script
# Downloads sample data for testing and development

echo "========================================="
echo "🧲 MAGION - Data Download Script"
echo "========================================="

# Create data directories
mkdir -p data/raw/solar_wind
mkdir -p data/raw/neutron
mkdir -p data/raw/indices
mkdir -p data/processed

echo "✓ Created data directories"

# Download sample ACE data (simulated)
echo ""
echo "Downloading sample ACE data..."
cat > data/raw/solar_wind/ace_sample.json << 'INNEREOF'
[
    ["time_tag", "density", "speed", "temperature"],
    ["2026-03-04 00:00:00", 5.2, 410, 85000],
    ["2026-03-04 00:01:00", 5.3, 412, 85200],
    ["2026-03-04 00:02:00", 5.1, 408, 84800]
]
INNEREOF
echo "✓ ACE data downloaded"

# Download sample DSCOVR data
echo "Downloading sample DSCOVR data..."
cat > data/raw/solar_wind/dscovr_sample.json << 'INNEREOF'
[
    ["time_tag", "bx", "by", "bz", "bt"],
    ["2026-03-04 00:00:00", 2.1, 1.5, 0.3, 5.2],
    ["2026-03-04 00:01:00", 2.2, 1.4, 0.1, 5.1],
    ["2026-03-04 00:02:00", 2.0, 1.6, -0.2, 5.3]
]
INNEREOF
echo "✓ DSCOVR data downloaded"

# Download sample neutron monitor data
echo "Downloading sample neutron monitor data..."
cat > data/raw/neutron/nmdb_sample.csv << 'INNEREOF'
station,time,counts,pressure
NEWK,2026-03-04T00:00:00,98.5,1013
NEWK,2026-03-04T00:01:00,98.7,1013
NEWK,2026-03-04T00:02:00,98.3,1013
THUL,2026-03-04T00:00:00,112.2,1005
THUL,2026-03-04T00:01:00,112.5,1005
THUL,2026-03-04T00:02:00,112.0,1005
INNEREOF
echo "✓ Neutron monitor data downloaded"

# Download sample Kp data
echo "Downloading sample Kp data..."
cat > data/raw/indices/kp_sample.json << 'INNEREOF'
[
    ["2026-03-04 00:00:00", 2.3],
    ["2026-03-04 03:00:00", 2.7],
    ["2026-03-04 06:00:00", 3.0],
    ["2026-03-04 09:00:00", 2.3]
]
INNEREOF
echo "✓ Kp data downloaded"

# Create processed data directory structure
echo ""
echo "Creating processed data structure..."
mkdir -p data/processed/2026/03

# Create sample SEI output
cat > data/processed/sei_sample.json << 'INNEREOF'
{
    "timestamp": "2026-03-04T12:00:00Z",
    "sei": 87.3,
    "alert_level": "UNSETTLED",
    "parameters": {
        "rs": 0.92,
        "nmf": 0.88,
        "kp": 0.85,
        "np": 0.90,
        "rc": 0.87,
        "tec": 0.89,
        "va": 0.86,
        "fd": 0.95
    }
}
INNEREOF
echo "✓ Processed data created"

# Create README for data directory
cat > data/README.md << 'INNEREOF'
# MAGION Data Directory

This directory contains space weather data for MAGION framework.

## Structure

- `raw/`: Raw data from various sources
  - `solar_wind/`: ACE and DSCOVR satellite data
  - `neutron/`: Neutron monitor data from NMDB
  - `indices/`: Geomagnetic indices (Kp, Dst, AE)

- `processed/`: Processed and calibrated data
  - `YYYY/MM/`: Organized by year and month

## Data Sources

- ACE: Advanced Composition Explorer (NASA)
- DSCOVR: Deep Space Climate Observatory (NOAA)
- NMDB: Neutron Monitor Database
- NOAA SWPC: Space Weather Prediction Center

## File Formats

- JSON: Structured data with timestamps
- CSV: Tabular data for time series
- IONEX: TEC maps (when available)

For real-time data, use the MAGION data ingestion pipeline.
INNEREOF
echo "✓ README created"

echo ""
echo "========================================="
echo "✅ Data download complete!"
echo "========================================="
echo ""
echo "Data location: ./data/"
echo "To process this data:"
echo "  python examples/basic_usage.py"
echo ""
