#!/bin/bash
# MAGION Docker Build Script
# Builds and tags Docker image

echo "========================================="
echo "🧲 MAGION - Docker Build Script"
echo "========================================="

# Set version
VERSION="1.0.0"
IMAGE_NAME="magion"

echo "Building Docker image: $IMAGE_NAME:$VERSION"

# Build Docker image
docker build -t $IMAGE_NAME:$VERSION -t $IMAGE_NAME:latest .

# Check build result
if [ $? -eq 0 ]; then
    echo "✅ Docker image built successfully!"
else
    echo "❌ Docker build failed"
    exit 1
fi

# Show image info
echo ""
echo "Image details:"
docker images $IMAGE_NAME:$VERSION

echo ""
echo "To run the container:"
echo "  docker run -p 8000:8000 -p 8501:8501 $IMAGE_NAME:$VERSION"
echo ""
echo "========================================="
