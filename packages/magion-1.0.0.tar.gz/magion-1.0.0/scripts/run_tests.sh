#!/bin/bash
# MAGION Test Runner
# Runs all tests with coverage report

echo "========================================="
echo "🧲 MAGION - Test Runner"
echo "========================================="

# Activate virtual environment if it exists
if [ -d ".venv" ]; then
    source .venv/bin/activate
    echo "✓ Virtual environment activated"
fi

# Run tests with coverage
echo ""
echo "Running unit tests..."
python -m pytest tests/ -v --cov=magion --cov-report=term --cov-report=html

# Check test result
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ All tests passed!"
else
    echo ""
    echo "❌ Some tests failed"
    exit 1
fi

# Show coverage report location
echo ""
echo "Coverage report: htmlcov/index.html"

# Run specific test modules if requested
if [ "$1" == "parameters" ]; then
    echo ""
    echo "Running parameter tests only..."
    python -m pytest tests/test_parameters.py -v
elif [ "$1" == "physics" ]; then
    echo ""
    echo "Running physics tests only..."
    python -m pytest tests/test_physics.py -v
elif [ "$1" == "integration" ]; then
    echo ""
    echo "Running integration tests only..."
    python -m pytest tests/test_integration.py -v
fi

echo ""
echo "========================================="
