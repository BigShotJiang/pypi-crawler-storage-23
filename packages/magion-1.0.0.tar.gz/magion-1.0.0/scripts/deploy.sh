#!/bin/bash
# MAGION Deployment Script
# Deploys to production environment

echo "========================================="
echo "🧲 MAGION - Deployment Script"
echo "========================================="

# Check environment
if [ -z "$MAGION_ENV" ]; then
    export MAGION_ENV="production"
fi

echo "Environment: $MAGION_ENV"

# Load environment variables
if [ -f ".env" ]; then
    echo "Loading environment variables from .env"
    export $(cat .env | xargs)
fi

# Run tests before deployment
echo ""
echo "Running tests..."
./scripts/run_tests.sh

if [ $? -ne 0 ]; then
    echo "❌ Tests failed. Aborting deployment."
    exit 1
fi

# Build Docker image
echo ""
echo "Building Docker image..."
./scripts/build_docker.sh

if [ $? -ne 0 ]; then
    echo "❌ Docker build failed. Aborting deployment."
    exit 1
fi

# Deploy based on environment
if [ "$MAGION_ENV" == "production" ]; then
    echo ""
    echo "Deploying to production..."
    
    # Push to registry (example)
    # docker push your-registry/magion:latest
    
    # Deploy with docker-compose
    docker-compose up -d
    
    echo "✅ Production deployment complete!"
    
elif [ "$MAGION_ENV" == "staging" ]; then
    echo ""
    echo "Deploying to staging..."
    
    # Staging deployment
    docker-compose -f docker-compose.staging.yml up -d
    
    echo "✅ Staging deployment complete!"
    
else
    echo ""
    echo "Local deployment only (no production push)"
fi

echo ""
echo "========================================="
echo "✅ Deployment complete!"
echo "========================================="
