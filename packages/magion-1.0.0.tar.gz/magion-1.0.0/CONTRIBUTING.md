# 🧲 CONTRIBUTING TO MAGION

First off, thank you for considering contributing to MAGION! We welcome contributions from space physicists, magnetospheric scientists, data scientists, software engineers, and anyone passionate about understanding and forecasting Earth's space weather environment.

---

## Code of Conduct

This project adheres to a [Code of Conduct](CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code.

---

## Types of Contributions

### 🛰️ Scientific Contributions
- New magnetospheric datasets (ACE, DSCOVR, THEMIS, MMS)
- Solar wind plasma measurements (density, velocity, temperature)
- Interplanetary magnetic field (IMF) data
- Neutron monitor count rates (NMDB stations)
- Geomagnetic indices (Kp, Dst, AE, SYM-H)
- Ionospheric TEC measurements (GNSS networks)
- Forbush decrease observations and analysis
- Rigidity cutoff calculations and validations

### 💻 Code Contributions
- SEI calculation engine improvements
- MHD solver enhancements for magnetopause standoff
- LSTM forecasting model improvements
- Parameter module development
- Real-time data ingestion pipelines
- Dashboard and visualization tools
- API extensions
- Alert system enhancements

### 📊 Data Contributions
- Real-time solar wind data streams
- Neutron monitor station data (1-minute resolution)
- Geomagnetic observatory measurements
- GNSS TEC maps
- Historical storm event databases
- Satellite anomaly reports during storms

### 📝 Documentation Contributions
- Tutorials and examples
- API documentation
- Parameter explanations
- Case study write-ups (historical storms)
- Translation of documentation
- User guides for satellite operators, aviation, power grid

---

## Getting Started

### Prerequisites
- **Python 3.8–3.11**
- **Git**
- **Basic knowledge of space physics or magnetohydrodynamics**

### Setup Development Environment

```bash
# Fork the repository, then clone
git clone https://gitlab.com/YOUR_USERNAME/MAGION.git
cd MAGION

# Create virtual environment
python -m venv .venv
source .venv/bin/activate

# Install development dependencies
pip install -e ".[dev]"
pre-commit install
```

Verify Setup

```bash
# Run basic validation
python scripts/validate_environment.py

# Run tests
pytest tests/unit/ -v

# Check SEI calculations
python scripts/check_sei.py --expected 94.2

# Test data ingestion
python scripts/test_data_sources.py --source ace
```

---

Development Workflow

1. Create an issue describing your proposed changes
2. Fork and branch:
   ```bash
   git checkout -b feature/your-feature-name
   git checkout -b fix/issue-description
   git checkout -b parameter/new-parameter
   ```
3. Make changes following our standards
4. Write/update tests
5. Run tests locally
6. Commit with clear messages
7. Push to your fork
8. Open a Merge Request

---

Coding Standards

Python

· Format: Black (line length 88)
· Imports: isort with black profile
· Type Hints: Required for all public functions
· Docstrings: Google style

Example Parameter Module

```python
"""Rs - Magnetopause Standoff Distance parameter."""

from typing import Optional, Tuple
import numpy as np

from magion.core import ParameterBase
from magion.physics.mhd import calculate_standoff


class MagnetopauseStandoff(ParameterBase):
    """Rs: Magnetopause Standoff Distance.
    
    Calculates the subsolar magnetopause distance using MHD pressure balance
    between solar wind dynamic pressure and Earth's magnetic field pressure.
    
    Attributes:
        rho: Solar wind mass density [kg/m³]
        v: Solar wind velocity [m/s]
        b_earth: Earth's magnetic field at surface [T]
        mu0: Permeability of free space [H/m]
    """
    
    def compute(self, solar_wind_data: dict) -> float:
        """Compute normalized Rs score.
        
        Args:
            solar_wind_data: Dictionary with 'density', 'velocity', 'bz'
            
        Returns:
            Normalized Rs value (0-1) where 1 = nominal position (10 Rₑ)
        """
        # Implementation using pressure balance:
        # ρv² = B²/(2μ₀)
        # Rs = (B₀² Rₑ⁶ / 2μ₀ρv²)^(1/6)
        
        density = solar_wind_data['density']  # cm⁻³ → kg/m³
        velocity = solar_wind_data['velocity']  # km/s → m/s
        bz = solar_wind_data['bz']  # nT → T
        
        # Convert to SI
        rho_si = density * 1.67e-21  # proton mass * density
        v_si = velocity * 1000
        b_earth = 3.12e-5  # T at equator
        mu0 = 4 * np.pi * 1e-7
        
        # Dynamic pressure
        p_dyn = rho_si * v_si**2
        
        # Standoff distance (Earth radii)
        Rs = (b_earth**2 * 6371e3**6 / (2 * mu0 * p_dyn)) ** (1/6) / 6371e3
        
        # Normalize (nominal = 10 Rₑ)
        normalized = min(1.0, Rs / 10.0)
        
        return normalized
```

---

Testing Guidelines

Test Structure

```
tests/
├── unit/                    # Unit tests
│   ├── parameters/
│   │   ├── test_rs.py
│   │   ├── test_nmf.py
│   │   └── test_rc.py
│   ├── models/
│   │   └── test_lstm.py
│   └── physics/
│       └── test_mhd.py
├── integration/             # Integration tests
│   ├── test_data_ingestion.py
│   └── test_sei_pipeline.py
├── storms/                  # Historical storm validation
│   ├── test_halloween_2003.py
│   └── test_stpatrick_2015.py
└── fixtures/                # Test data
    ├── ace_sample.json
    └── nmdb_sample.csv
```

Running Tests

```bash
# All tests
pytest

# Parameter tests
pytest tests/unit/parameters/ -v

# Storm validation
pytest tests/storms/ -v --sei-threshold 94.2

# With coverage
pytest --cov=magion --cov-report=html
```

---

Data Contributions

New Data Source

When adding a new data source, include:

1. Source metadata (agency, satellite/station, location)
2. Data format specification (JSON, CSV, CDF)
3. Access method (API, FTP, public URL)
4. Update frequency (1-min, 3-hour, daily)
5. Quality control procedures
6. Validation against existing sources

Data Format Requirements

Parameter Source Format Required Fields
Rs ACE/DSCOVR JSON density, velocity, bz, time
Nmf NMDB CSV station_code, count_rate, time
Kp GFZ CSV kp_value, time, status
np ACE/SWEPAM JSON proton_density, time
Rc MAGION calc NetCDF latitude, longitude, rigidity, time
TEC IGS IONEX tec_map, time
VA MAGION calc JSON alfven_velocity, time
Fd NMDB CSV percent_decrease, onset_time

---

Data Ethics and Attribution

Any contribution involving data must:

1. Properly attribute all data sources (NASA, NOAA, NMDB, IGS, INTERMAGNET)
2. Respect data use policies of each provider
3. Cite original papers for scientific datasets
4. Include DOIs for published datasets
5. Do not redistribute restricted data without permission

Contact: data@magion.space

---

Adding New Parameters

If you propose a new parameter for SEI:

1. Literature review - Demonstrate physical relevance to magnetospheric shielding
2. Physical independence - Show correlation <0.3 with existing parameters
3. Measurement protocol - Define clear methodology and data source
4. Validation data - Provide dataset showing predictive power for storms
5. Weight proposal - Suggest initial weight (<5% typically for new parameters)
6. Computational cost - Estimate processing requirements

---

Reporting Issues

Bug Reports

Include:

· Clear title and description
· Steps to reproduce
· Expected vs actual behavior
· Environment details (OS, Python version)
· Logs or screenshots
· Data source and timestamp if applicable

Feature Requests

Include:

· Use case description
· Expected behavior
· Scientific justification
· References to similar work
· Potential data sources

---

Contact

Purpose Contact
General inquiries gitdeeper@gmail.com
Code of Conduct conduct@magion.space
Data contributions data@magion.space
Scientific questions science@magion.space
Forecast validation forecast@magion.space

Repository: https://gitlab.com/gitdeeper8/MAGION
Dashboard: https://magion.space
DOI: 10.5281/zenodo.MAGION.2026

---

🧲 The magnetosphere has protected Earth for 3.5 billion years. MAGION ensures we know when it falters.

Last Updated: March 2026
