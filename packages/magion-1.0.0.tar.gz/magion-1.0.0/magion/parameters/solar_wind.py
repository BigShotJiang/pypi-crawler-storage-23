"""
Solar Wind Proton Density (np) Parameter
Controls dynamic pressure and CME impact severity.
"""

import numpy as np
from typing import Dict, Optional


class SolarWindDensity:
    """
    np: Solar Wind Proton Number Density
    
    Measures proton density in solar wind plasma.
    Typical values: 1-100 cm⁻³
    - Quiet: 5 cm⁻³
    - CME: 20-50 cm⁻³
    - Extreme: >100 cm⁻³
    """
    
    def __init__(self):
        """Initialize solar wind density parameter."""
        self.quiet_density = 5.0  # cm⁻³
        self.cme_threshold = 20.0  # cm⁻³
        self.extreme_threshold = 50.0  # cm⁻³
        
    def compute(self, data: Dict) -> float:
        """
        Compute normalized np score.
        
        Args:
            data: Dictionary containing:
                - density: Proton density [cm⁻³]
                - or density_1min: Recent density measurements
                
        Returns:
            Normalized np score (0-1)
        """
        # Get density
        if 'density' in data:
            density = data['density']
        elif 'density_1min' in data:
            # Use most recent
            density = data['density_1min'][-1]
        else:
            # Default to quiet
            return 0.95
        
        # Normalize: lower density = higher SEI contribution
        # 1 at quiet (5 cm⁻³), 0 at extreme (>50 cm⁻³)
        if density <= self.quiet_density:
            return 1.0
        elif density >= self.extreme_threshold:
            return 0.0
        else:
            # Linear decrease
            return 1.0 - (density - self.quiet_density) / (self.extreme_threshold - self.quiet_density)
    
    def get_dynamic_pressure(self, density_cm3: float, velocity_kms: float) -> float:
        """
        Calculate solar wind dynamic pressure.
        
        Equation:
            P_dyn = (1.67e-6) * n * v² [nPa]
        
        where n in cm⁻³, v in km/s
        """
        return 1.67e-6 * density_cm3 * velocity_kms**2
    
    def classify_cme(self, density: float, velocity: float) -> str:
        """Classify if this is a CME based on density and velocity."""
        if density > 20 and velocity > 500:
            return "CME"
        elif density > 10 and velocity > 400:
            return "CIR"
        else:
            return "AMBIENT"
    
    def get_sei_contribution(self, density: float) -> float:
        """Wrapper for compute."""
        return self.compute({'density': density})
