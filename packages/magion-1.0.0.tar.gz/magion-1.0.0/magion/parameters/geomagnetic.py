"""
Kp Geomagnetic Index Parameter
Planetary geomagnetic activity index from global magnetometer network.
"""

import numpy as np
from typing import Dict, Optional


class GeomagneticIndex:
    """
    Kp: Planetary geomagnetic activity index
    
    Measures global field disturbance amplitude on 0-9 scale.
    Derived from 13 mid-latitude magnetometer stations.
    """
    
    # Kp to SEI mapping (inverse relationship)
    KP_TO_SEI_MAP = {
        0: 1.00, 1: 0.95, 2: 0.90,
        3: 0.80, 4: 0.70, 5: 0.55,
        6: 0.40, 7: 0.25, 8: 0.10,
        9: 0.00
    }
    
    def __init__(self):
        """Initialize Kp parameter calculator."""
        self.quiet_threshold = 2
        self.storm_threshold = 5
        
    def compute(self, data: Dict) -> float:
        """
        Compute normalized Kp score.
        
        Args:
            data: Dictionary containing:
                - kp: Current Kp value (0-9)
                - or kp_3hour: List of last 3 Kp values
                
        Returns:
            Normalized Kp score (0-1)
        """
        # Get current Kp
        if 'kp' in data:
            kp = data['kp']
        elif 'kp_3hour' in data:
            # Use most recent
            kp = data['kp_3hour'][-1]
        else:
            # Default to quiet conditions
            return 0.85
        
        # Convert to SEI contribution
        # Interpolate for non-integer Kp
        kp_low = int(np.floor(kp))
        kp_high = int(np.ceil(kp))
        
        if kp_low == kp_high:
            return self.KP_TO_SEI_MAP.get(kp_low, 0.5)
        
        # Linear interpolation
        frac = kp - kp_low
        sei_low = self.KP_TO_SEI_MAP.get(kp_low, 0.5)
        sei_high = self.KP_TO_SEI_MAP.get(kp_high, 0.5)
        
        return sei_low + frac * (sei_high - sei_low)
    
    def get_ap_index(self, kp: float) -> float:
        """
        Convert Kp to ap index (linear amplitude).
        
        Equation:
            ap = 10^(kp/3 - 0.5)
        """
        return 10 ** (kp/3 - 0.5)
    
    def get_storm_severity(self, kp: float) -> str:
        """Classify storm severity based on Kp."""
        if kp < 5:
            return "QUIET"
        elif kp < 6:
            return "MINOR_STORM"
        elif kp < 7:
            return "MODERATE_STORM"
        elif kp < 8:
            return "MAJOR_STORM"
        else:
            return "SEVERE_STORM"
    
    def get_sei_contribution(self, kp: float) -> float:
        """Wrapper for compute."""
        return self.compute({'kp': kp})
