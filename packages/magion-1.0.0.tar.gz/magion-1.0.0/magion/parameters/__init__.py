"""
MAGION Parameter Modules
Eight orthogonal geophysical parameters for Shield Efficiency Index calculation.
"""

from magion.parameters.magnetopause import MagnetopauseStandoff
from magion.parameters.cosmic_rays import CosmicRayFlux
from magion.parameters.geomagnetic import GeomagneticIndex
from magion.parameters.solar_wind import SolarWindDensity
from magion.parameters.rigidity_cutoff import RigidityCutoff
from magion.parameters.ionosphere import TotalElectronContent
from magion.parameters.alfven import AlfvenVelocity
from magion.parameters.forbush import ForbushDecrease

__all__ = [
    "MagnetopauseStandoff",
    "CosmicRayFlux",
    "GeomagneticIndex",
    "SolarWindDensity",
    "RigidityCutoff",
    "TotalElectronContent",
    "AlfvenVelocity",
    "ForbushDecrease",
]
