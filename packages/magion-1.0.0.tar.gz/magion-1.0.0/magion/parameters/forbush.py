"""
Forbush Decrease (Fd) Parameter
Transient suppression of galactic cosmic ray flux during solar events.
"""

import numpy as np
from typing import Dict, Optional, List


class ForbushDecrease:
    """
    Fd: Forbush Decrease
    
    Rapid decrease in cosmic ray intensity caused by solar wind disturbances.
    Tracks interplanetary shock passage and CME magnetic structures.
    """
    
    def __init__(self):
        """Initialize Forbush decrease parameter."""
        # Detection thresholds
        self.minor_threshold = 3.0  # %
        self.moderate_threshold = 5.0  # %
        self.major_threshold = 10.0  # %
        
        # Recovery times (days)
        self.typical_recovery = 5
        self.slow_recovery = 10
        
    def compute(self, data: Dict) -> float:
        """
        Compute normalized Fd score.
        
        Args:
            data: Dictionary containing:
                - decrease_percent: Current Forbush decrease [%]
                - or neutron_series: Time series of neutron counts
                
        Returns:
            Normalized Fd score (0-1)
        """
        if 'decrease_percent' in data:
            decrease = data['decrease_percent']
        elif 'neutron_series' in data:
            # Detect decrease from time series
            detection = self.detect_decrease(data['neutron_series'])
            decrease = detection['decrease_percent']
        else:
            # No Forbush decrease
            return 1.0
        
        # Normalize: larger decrease = lower SEI contribution
        if decrease <= self.minor_threshold:
            return 1.0
        elif decrease >= self.major_threshold:
            return 0.0
        else:
            # Linear decrease
            return 1.0 - (decrease - self.minor_threshold) / (self.major_threshold - self.minor_threshold)
    
    def detect_decrease(
        self,
        neutron_series: List[float],
        window_hours: int = 24
    ) -> Dict:
        """
        Detect Forbush decrease in neutron monitor data.
        
        Args:
            neutron_series: Time series of neutron counts
            window_hours: Detection window in hours
            
        Returns:
            Dictionary with detection information
        """
        if len(neutron_series) < window_hours:
            return {
                'detected': False,
                'decrease_percent': 0.0,
                'severity': 'NONE'
            }
        
        # Calculate baseline (pre-event)
        baseline = np.mean(neutron_series[:window_hours//2])
        
        # Find minimum during event
        minimum = np.min(neutron_series)
        min_idx = np.argmin(neutron_series)
        
        # Calculate decrease percentage
        decrease_percent = (1 - minimum / baseline) * 100
        
        # Determine severity
        if decrease_percent >= self.major_threshold:
            severity = 'MAJOR'
        elif decrease_percent >= self.moderate_threshold:
            severity = 'MODERATE'
        elif decrease_percent >= self.minor_threshold:
            severity = 'MINOR'
        else:
            severity = 'NONE'
        
        # Estimate recovery time (simplified)
        if min_idx < len(neutron_series) - 1:
            recovery_level = baseline * 0.9  # 90% recovery
            recovery_time = None
            
            for i in range(min_idx, len(neutron_series)):
                if neutron_series[i] >= recovery_level:
                    recovery_time = i - min_idx
                    break
            
            if recovery_time is None:
                recovery_time = self.typical_recovery * 24  # hours
        else:
            recovery_time = self.typical_recovery * 24
        
        return {
            'detected': decrease_percent >= self.minor_threshold,
            'decrease_percent': decrease_percent,
            'severity': severity,
            'baseline': baseline,
            'minimum': minimum,
            'minimum_time': min_idx,
            'estimated_recovery_hours': recovery_time
        }
    
    def classify_mc_type(self, decrease_profile: List[float]) -> str:
        """
        Classify magnetic cloud type from decrease profile.
        
        - Two-step decrease: indicates ICME with sheath + MC
        - Gradual decrease: indicates CIR
        - Sharp decrease: indicates shock
        """
        if len(decrease_profile) < 10:
            return "UNKNOWN"
        
        # Calculate derivatives
        derivatives = np.diff(decrease_profile)
        
        # Check for two-step decrease
        neg_derivatives = derivatives[derivatives < 0]
        if len(neg_derivatives) > 2:
            # Look for two distinct negative periods
            changes = np.where(np.diff(np.signbit(derivatives)))[0]
            if len(changes) >= 3:
                return "ICME_WITH_SHEATH"
        
        # Check for gradual decrease
        if np.mean(np.abs(derivatives)) < 0.1:
            return "CIR"
        
        # Check for sharp decrease
        if np.min(derivatives) < -1.0:
            return "SHOCK"
        
        return "SIMPLE_MC"
    
    def get_sei_contribution(self, decrease_percent: float) -> float:
        """Wrapper for compute."""
        return self.compute({'decrease_percent': decrease_percent})
