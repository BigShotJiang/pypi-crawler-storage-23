"""
Rigidity Cutoff (Rc) Parameter
Calculates minimum rigidity for cosmic ray penetration using Störmer theory.
"""

import numpy as np
from typing import Dict, Optional, Tuple
from magion.physics.cosmic_rays import StoermerTheory, TsyganenkoFieldModel


class RigidityCutoff:
    """
    Rc: Minimum particle rigidity for atmospheric penetration
    
    Latitude-dependent shield threshold calculated from:
    - Dipole field (Störmer theory)
    - Disturbed field (Tsyganenko models)
    - Ring current effects during storms
    """
    
    def __init__(self):
        self.stoermer = StoermerTheory()
        self.tsyganenko = TsyganenkoFieldModel()
        
        # Reference values
        self.EQUATORIAL_RC = 17.0  # GV
        self.POLAR_RC = 1.0     # GV
        self.MIDLAT_RC = 5.0    # GV
    
    def compute(self, data: Dict) -> float:
        """
        Compute normalized global average Rc score.
        
        Args:
            data: Dictionary containing:
                - dst: Dst index [nT]
                - solar_wind_pressure: Dynamic pressure [nPa]
                - latitude: Optional specific latitude
        
        Returns:
            Normalized Rc score (0-1)
        """
        # Extract data
        dst = data.get('dst', 0.0)
        pressure = data.get('solar_wind_pressure', 2.0)
        
        # Calculate global average cutoff
        # Weighted average: 30% polar, 40% mid-lat, 30% equatorial
        rc_polar = self.cutoff_at_latitude(70, dst, pressure)
        rc_mid = self.cutoff_at_latitude(45, dst, pressure)
        rc_eq = self.cutoff_at_latitude(0, dst, pressure)
        
        rc_avg = 0.3 * rc_polar + 0.4 * rc_mid + 0.3 * rc_eq
        
        # Normalize to [0,1]
        return self._normalize(rc_avg)
    
    def cutoff_at_latitude(
        self,
        latitude: float,
        dst: float = 0.0,
        pressure: float = 2.0,
        altitude_km: float = 0.0
    ) -> float:
        """
        Calculate rigidity cutoff at specific latitude.
        
        Equation:
            Rc = (M cos⁴λ) / (4r²) * f(Dst) * g(pressure)
        """
        # Dipole cutoff
        rc_dipole = self.stoermer.vertical_cutoff_rigidity(
            latitude,
            1.0 + altitude_km / 6371.0
        )
        
        # Storm-time modification
        if dst < -50:  # Moderate to severe storm
            rc_modified = self.tsyganenko.cutoff_modification(
                rc_dipole, dst, pressure
            )
        else:
            rc_modified = rc_dipole
        
        return rc_modified
    
    def compute_global_map(
        self,
        resolution: float = 5.0,
        dst: float = 0.0,
        pressure: float = 2.0
    ) -> Dict:
        """
        Generate global rigidity cutoff map.
        
        Returns:
            Dictionary with latitude/longitude grid and cutoff values
        """
        latitudes = np.arange(-90, 91, resolution)
        longitudes = np.arange(0, 360, resolution)
        
        # Create 2D grid
        lats_2d, lons_2d = np.meshgrid(latitudes, longitudes)
        cutoffs = np.zeros_like(lats_2d)
        
        for i, lat in enumerate(latitudes):
            for j, lon in enumerate(longitudes):
                # Longitude dependence through magnetic declination
                # Simplified - assume symmetric about dipole axis
                cutoffs[j, i] = self.cutoff_at_latitude(lat, dst, pressure)
        
        return {
            'latitudes': latitudes,
            'longitudes': longitudes,
            'cutoffs': cutoffs,
            'mean': np.mean(cutoffs),
            'min': np.min(cutoffs),
            'max': np.max(cutoffs),
            'dst': dst,
            'pressure': pressure
        }
    
    def get_penetration_latitude(
        self,
        rigidity_gv: float,
        dst: float = 0.0,
        pressure: float = 2.0
    ) -> float:
        """
        Find lowest latitude where given rigidity can penetrate.
        """
        for lat in np.arange(90, -91, -1):
            rc = self.cutoff_at_latitude(lat, dst, pressure)
            if rigidity_gv >= rc:
                return lat
        return -90  # Can't penetrate even at pole
    
    def get_dose_rate_estimate(
        self,
        latitude: float,
        altitude_km: float = 12.0,  # Cruise altitude
        nm_flux: float = 1.0
    ) -> float:
        """
        Estimate radiation dose rate at given location.
        
        Returns:
            Dose rate in μSv/hour
        """
        rc = self.cutoff_at_latitude(latitude, altitude_km=altitude_km)
        
        # Base dose rate at pole (μSv/hour)
        base_dose = 5.0
        
        # Scale by cutoff (lower cutoff = higher dose)
        if rc < 1:
            dose = base_dose * 2.0  # Polar enhancement
        elif rc > 15:
            dose = base_dose * 0.2  # Equatorial suppression
        else:
            dose = base_dose * (1.0 / np.sqrt(rc))
        
        # Scale by neutron monitor flux
        dose *= nm_flux
        
        return dose
    
    def _normalize(self, rc: float) -> float:
        """Normalize Rc to [0,1] for SEI contribution."""
        # Normalize: 1 at polar (low cutoff = weak shield)
        #            0 at equatorial (high cutoff = strong shield)
        
        # Clamp to physical range
        rc_clipped = np.clip(rc, 0.1, 20.0)
        
        # Inverse relationship (lower cutoff = lower SEI contribution)
        # Because low cutoff means particles penetrate easily
        normalized = 1.0 - (rc_clipped / 20.0)
        
        return np.clip(normalized, 0.0, 1.0)
    
    def get_sei_contribution(self, rc: float) -> float:
        """Get Rc contribution to SEI (wrapper for _normalize)."""
        return self._normalize(rc)
