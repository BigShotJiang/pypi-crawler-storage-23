"""
Alfvén Velocity (VA) Parameter
Magnetohydrodynamic wave propagation speed in magnetospheric plasma.
"""

import numpy as np
from typing import Dict, Optional
from magion.physics.wave_theory import AlfvenWavePhysics


class AlfvenVelocity:
    """
    VA: Alfvén Velocity
    
    Speed of Alfvén waves in magnetospheric plasma:
    V_A = B / √(μ₀ρ)
    
    Determines reconnection rate and energy transfer from solar wind.
    """
    
    def __init__(self):
        """Initialize Alfvén velocity parameter."""
        self.alfven = AlfvenWavePhysics()
        
        # Typical values
        self.quiet_va = 1000.0  # km/s in solar wind
        self.magnetosheath_va = 200.0  # km/s in magnetosheath
        self.plasmasphere_va = 500.0  # km/s in plasmasphere
        
    def compute(self, data: Dict) -> float:
        """
        Compute normalized VA score.
        
        Args:
            data: Dictionary containing:
                - b_field: Magnetic field [nT]
                - density: Plasma density [cm⁻³]
                - region: 'solar_wind', 'magnetosheath', 'plasmasphere'
                
        Returns:
            Normalized VA score (0-1)
        """
        # Extract parameters
        b_field = data.get('b_field', 5.0)  # nT
        density = data.get('density', 5.0)  # cm⁻³
        region = data.get('region', 'solar_wind')
        
        # Calculate Alfvén velocity
        va = self.alfven.alfven_velocity_from_parameters(b_field, density)
        
        # Get expected VA for region
        if region == 'solar_wind':
            expected = self.quiet_va
        elif region == 'magnetosheath':
            expected = self.magnetosheath_va
        elif region == 'plasmasphere':
            expected = self.plasmasphere_va
        else:
            expected = 500.0
        
        # Normalize: higher VA = more efficient coupling
        # But extremely high VA can indicate compression
        ratio = va / expected
        
        if ratio > 2.0:
            # Too high - indicates compression
            return 0.5
        elif ratio > 1.0:
            # Enhanced but not extreme
            return 1.0
        else:
            # Reduced - weaker coupling
            return max(0.3, ratio)
    
    def calculate_from_omni(self, b_nt: float, n_cm3: float) -> float:
        """Calculate Alfvén velocity from OMNI data."""
        return self.alfven.alfven_velocity_from_parameters(b_nt, n_cm3)
    
    def get_alfven_mach(self, v_sw_kms: float, b_nt: float, n_cm3: float) -> float:
        """
        Calculate Alfvén Mach number.
        
        M_A = V_sw / V_A
        """
        va = self.calculate_from_omni(b_nt, n_cm3)
        return v_sw_kms / va if va > 0 else 0
    
    def estimate_reconnection_rate(
        self,
        b_nt: float,
        n_cm3: float,
        shear_angle: float
    ) -> float:
        """
        Estimate magnetic reconnection rate.
        
        Equation:
            E_rec = 0.1 * V_A * B * sin(θ/2)
        """
        va = self.calculate_from_omni(b_nt, n_cm3) * 1000  # km/s to m/s
        b_si = b_nt * 1e-9
        
        return 0.1 * va * b_si * np.sin(np.radians(shear_angle/2)) * 1000  # mV/m
    
    def get_sei_contribution(self, va: float, region: str = 'solar_wind') -> float:
        """Wrapper for compute."""
        return self.compute({
            'b_field': 5.0,  # Placeholder
            'density': 5.0,  # Placeholder
            'region': region
        })
