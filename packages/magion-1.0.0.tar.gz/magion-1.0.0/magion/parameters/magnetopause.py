"""
Magnetopause Standoff Distance (Rs) Parameter
Calculates subsolar magnetopause distance using MHD pressure balance.
"""

import numpy as np
from typing import Dict, Optional
from magion.physics.magnetosphere import MagnetosphereMHD


class MagnetopauseStandoff:
    """
    Rs: Magnetopause Standoff Distance
    
    Primary indicator of magnetospheric compression.
    Calculated from solar wind dynamic pressure:
    Rs = (B₀² Rₑ⁶ / 2μ₀ρv²)^(1/6)
    """
    
    def __init__(self):
        """Initialize magnetopause standoff calculator."""
        self.mhd = MagnetosphereMHD()
        self.nominal_rs = 10.0  # Earth radii
        self.critical_rs = 6.5   # Critical compression threshold
        
    def compute(self, data: Dict) -> float:
        """
        Compute normalized Rs score.
        
        Args:
            data: Dictionary containing:
                - density: Solar wind density [cm⁻³]
                - velocity: Solar wind velocity [km/s]
                - bz: IMF Bz [nT] (optional, for empirical model)
                
        Returns:
            Normalized Rs score (0-1)
        """
        # Extract solar wind parameters
        density = data.get('density', 5.0)
        velocity = data.get('velocity', 400.0)
        bz = data.get('bz', 0.0)
        
        # Calculate standoff distance
        if 'use_empirical' in data and data['use_empirical']:
            # Calculate dynamic pressure first
            p_dyn = 1.67e-6 * density * velocity**2  # nPa
            rs = self.mhd.shue_empirical(p_dyn, bz)
        else:
            # Use analytical MHD model
            rs = self.mhd.magnetopause_standoff_from_plasma(density, velocity)
        
        # Calculate SEI contribution
        return self._normalize(rs)
    
    def _normalize(self, rs: float) -> float:
        """
        Normalize Rs to [0,1] for SEI contribution.
        
        1.0 at nominal (10 Rₑ), decreasing linearly to 0 at critical (6.5 Rₑ)
        """
        if rs >= self.nominal_rs:
            return 1.0
        elif rs <= self.critical_rs:
            return 0.0
        else:
            # Linear interpolation
            return (rs - self.critical_rs) / (self.nominal_rs - self.critical_rs)
    
    def get_standoff_km(self, data: Dict) -> float:
        """Get standoff distance in kilometers."""
        density = data.get('density', 5.0)
        velocity = data.get('velocity', 400.0)
        bz = data.get('bz', 0.0)
        
        p_dyn = 1.67e-6 * density * velocity**2
        rs = self.mhd.shue_empirical(p_dyn, bz)
        
        return rs * 6371  # Earth radii to km
    
    def is_compressed(self, rs: float, threshold: float = 8.0) -> bool:
        """Check if magnetosphere is compressed."""
        return rs < threshold
    
    def get_sei_contribution(self, rs: float) -> float:
        """Wrapper for _normalize."""
        return self._normalize(rs)
