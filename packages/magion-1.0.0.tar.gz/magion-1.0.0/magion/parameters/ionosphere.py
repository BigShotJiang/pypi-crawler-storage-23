"""
Total Electron Content (TEC) Parameter
Integrated ionospheric electron density from GNSS measurements.
"""

import numpy as np
from typing import Dict, Optional, List


class TotalElectronContent:
    """
    TEC: Total Electron Content
    
    Integrated ionospheric electron density along line-of-sight.
    Measured in TEC units (1 TECU = 10¹⁶ electrons/m²).
    Indicates energetic electron precipitation levels.
    """
    
    def __init__(self):
        """Initialize TEC parameter."""
        # Typical TEC ranges
        self.quiet_tec = 10.0  # TECU at mid-latitudes
        self.storm_tec = 50.0   # TECU during storms
        self.extreme_tec = 100.0  # TECU during severe storms
        
        # Latitude bands
        self.polar_lat = 60
        self.equatorial_lat = 30
        
    def compute(self, data: Dict) -> float:
        """
        Compute normalized TEC score.
        
        Args:
            data: Dictionary containing:
                - tec_map: 2D array of TEC values
                - latitudes: Array of latitudes
                - longitudes: Array of longitudes
                - or tec_value: Single TEC value
                - latitude: Latitude for single value
                
        Returns:
            Normalized TEC score (0-1)
        """
        if 'tec_map' in data:
            return self._compute_from_map(data)
        elif 'tec_value' in data:
            tec = data['tec_value']
            lat = data.get('latitude', 45.0)
            return self._normalize_by_latitude(tec, lat)
        else:
            # Default to quiet
            return 0.90
    
    def _compute_from_map(self, data: Dict) -> float:
        """Compute from global TEC map."""
        tec_map = data['tec_map']
        latitudes = data.get('latitudes', np.arange(-90, 91, 10))
        
        # Weight by latitude (higher weight at polar regions for SEI)
        weights = []
        tec_values = []
        
        for i, lat in enumerate(latitudes):
            if abs(lat) >= self.polar_lat:
                weight = 2.0  # Polar regions (more sensitive)
            elif abs(lat) <= self.equatorial_lat:
                weight = 0.5  # Equatorial regions (less sensitive)
            else:
                weight = 1.0  # Mid-latitudes
            
            # Average TEC at this latitude
            if len(tec_map.shape) > 1:
                tec_lat = np.mean(tec_map[i, :])
            else:
                tec_lat = tec_map[i]
            
            weights.append(weight)
            tec_values.append(tec_lat)
        
        # Calculate weighted average
        weights = np.array(weights)
        tec_values = np.array(tec_values)
        
        avg_tec = np.average(tec_values, weights=weights)
        
        return self._normalize_global(avg_tec)
    
    def _normalize_by_latitude(self, tec: float, latitude: float) -> float:
        """Normalize TEC based on latitude."""
        # Expected quiet TEC at this latitude
        if abs(latitude) >= self.polar_lat:
            expected = 5.0  # Polar regions have lower TEC
            max_tec = 30.0
        elif abs(latitude) <= self.equatorial_lat:
            expected = 20.0  # Equatorial regions have higher TEC
            max_tec = 100.0
        else:
            expected = 10.0  # Mid-latitudes
            max_tec = 50.0
        
        # Normalize: deviation from expected indicates disturbance
        deviation = abs(tec - expected) / max_tec
        
        # SEI contribution is inverse of deviation
        return np.clip(1.0 - deviation, 0.0, 1.0)
    
    def _normalize_global(self, tec: float) -> float:
        """Normalize global average TEC."""
        # Global average TEC ~ 10 TECU
        # Higher TEC during storms (up to 100)
        if tec <= 10:
            return 1.0
        elif tec >= 50:
            return 0.0
        else:
            return 1.0 - (tec - 10) / 40
    
    def detect_storm_enhancement(
        self,
        tec_series: List[float],
        latitude: float,
        threshold_sigma: float = 2.0
    ) -> Dict:
        """
        Detect ionospheric storm enhancement.
        
        Args:
            tec_series: Time series of TEC values
            latitude: Observation latitude
            threshold_sigma: Detection threshold in standard deviations
            
        Returns:
            Dictionary with detection info
        """
        if len(tec_series) < 24:  # Need at least 24 hours
            return {'enhancement': False}
        
        # Calculate baseline (median of quiet period)
        baseline = np.median(tec_series[:12])
        std = np.std(tec_series[:12])
        
        # Current TEC (last value)
        current = tec_series[-1]
        
        # Calculate enhancement
        enhancement = (current - baseline) / std if std > 0 else 0
        
        return {
            'enhancement': enhancement > threshold_sigma,
            'enhancement_sigma': enhancement,
            'baseline': baseline,
            'current': current,
            'threshold': threshold_sigma
        }
    
    def get_sei_contribution(self, tec: float, latitude: float = 45.0) -> float:
        """Wrapper for compute."""
        return self.compute({
            'tec_value': tec,
            'latitude': latitude
        })
