"""
Cosmic Ray Flux (Nmf) Parameter
Ground-level neutron monitor count rate as proxy for cosmic ray penetration.
"""

import numpy as np
from typing import Dict, Optional, List
from magion.physics.cosmic_rays import NeutronMonitorResponse


class CosmicRayFlux:
    """
    Nmf: Neutron Monitor Flux
    
    Ground-level secondary neutron count rate from global network.
    Direct proxy for cosmic ray penetration into atmosphere.
    """
    
    # Global neutron monitor stations
    STATIONS = {
        'NEWK': {'name': 'Newark', 'latitude': 39.7, 'cutoff': 2.40},
        'THUL': {'name': 'Thule', 'latitude': 76.5, 'cutoff': 0.30},
        'MCMU': {'name': 'McMurdo', 'latitude': -77.9, 'cutoff': 0.01},
        'APTY': {'name': 'Apatity', 'latitude': 67.6, 'cutoff': 0.65},
        'INVK': {'name': 'Inuvik', 'latitude': 68.4, 'cutoff': 0.30},
        'NAIN': {'name': 'Nain', 'latitude': 56.5, 'cutoff': 0.50},
        'FSMT': {'name': 'Fort Smith', 'latitude': 60.0, 'cutoff': 0.50},
        'PWNK': {'name': 'Peawanuck', 'latitude': 55.0, 'cutoff': 0.80},
        'CALG': {'name': 'Calgary', 'latitude': 51.1, 'cutoff': 1.10},
        'LARC': {'name': 'LARC', 'latitude': -22.9, 'cutoff': 11.40},
        'KIEL': {'name': 'Kiel', 'latitude': 54.3, 'cutoff': 2.30},
        'MOSC': {'name': 'Moscow', 'latitude': 55.5, 'cutoff': 2.40},
        'ROME': {'name': 'Rome', 'latitude': 41.9, 'cutoff': 6.30},
        'ATHN': {'name': 'Athens', 'latitude': 38.0, 'cutoff': 8.50},
        'TERA': {'name': 'Terra', 'latitude': -74.1, 'cutoff': 0.10},
        'SOPO': {'name': 'South Pole', 'latitude': -90.0, 'cutoff': 0.10},
    }
    
    def __init__(self, station_code: str = 'global'):
        """
        Initialize cosmic ray flux parameter.
        
        Args:
            station_code: Specific station or 'global' for average
        """
        self.station_code = station_code
        self.stations = {}
        
        if station_code == 'global':
            # Initialize all stations
            for code, info in self.STATIONS.items():
                self.stations[code] = NeutronMonitorResponse(
                    info['latitude'],
                    info['cutoff']
                )
        else:
            # Initialize single station
            info = self.STATIONS.get(station_code)
            if info:
                self.stations[station_code] = NeutronMonitorResponse(
                    info['latitude'],
                    info['cutoff']
                )
    
    def compute(self, data: Dict) -> float:
        """
        Compute normalized Nmf score.
        
        Args:
            data: Dictionary containing:
                - neutron_counts: Dict of station: count_rate
                - pressures: Dict of station: pressure (optional)
                - quiet_time_rates: Dict of station: quiet_rate (optional)
                
        Returns:
            Normalized Nmf score (0-1)
        """
        counts = data.get('neutron_counts', {})
        pressures = data.get('pressures', {})
        quiet_rates = data.get('quiet_time_rates', {})
        
        if not counts:
            # Default to quiet conditions
            return 0.95
        
        # Calculate contribution for each station
        contributions = []
        
        for station, count_rate in counts.items():
            if station in self.stations:
                monitor = self.stations[station]
                
                # Get pressure correction
                pressure = pressures.get(station, 1013)
                
                # Get quiet time rate (or use default)
                quiet_rate = quiet_rates.get(station, 100.0)
                
                # Calculate contribution
                contrib = monitor.get_sei_contribution(
                    count_rate,
                    quiet_rate,
                    pressure
                )
                contributions.append(contrib)
        
        if not contributions:
            return 0.90
        
        # Average across stations
        return np.mean(contributions)
    
    def detect_forbush_decrease(
        self,
        count_rates: List[float],
        window_hours: int = 6,
        threshold_percent: float = 3.0
    ) -> Dict:
        """
        Detect Forbush decrease in neutron monitor data.
        
        Args:
            count_rates: Time series of count rates
            window_hours: Detection window in hours
            threshold_percent: Decrease threshold percentage
            
        Returns:
            Dictionary with detection info
        """
        if len(count_rates) < 2:
            return {'detected': False, 'decrease': 0.0}
        
        # Calculate baseline (average before decrease)
        baseline = np.mean(count_rates[:len(count_rates)//2])
        
        # Calculate minimum during window
        minimum = np.min(count_rates)
        
        # Calculate decrease percentage
        decrease_percent = (1 - minimum / baseline) * 100
        
        # Detect if threshold exceeded
        detected = decrease_percent >= threshold_percent
        
        return {
            'detected': detected,
            'decrease_percent': decrease_percent,
            'baseline': baseline,
            'minimum': minimum,
            'threshold': threshold_percent
        }
    
    def get_cutoff_rigidity(self, station_code: str) -> float:
        """Get cutoff rigidity for specific station."""
        if station_code in self.STATIONS:
            return self.STATIONS[station_code]['cutoff']
        return 0.0
    
    def get_sei_contribution(self, count_rate: float, station: str = 'NEWK') -> float:
        """Wrapper for compute for single station."""
        return self.compute({
            'neutron_counts': {station: count_rate}
        })
