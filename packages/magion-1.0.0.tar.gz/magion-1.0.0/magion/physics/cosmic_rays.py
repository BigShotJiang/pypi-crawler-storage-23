"""
Cosmic Ray Physics Module
Contains Störmer cutoff theory and rigidity calculations
from MAGION research paper (Section 2.1.2)
"""

import numpy as np
from typing import Tuple, Dict, Optional
from dataclasses import dataclass


@dataclass
class CosmicRayConstants:
    """Physical constants for cosmic ray calculations."""
    M_EARTH: float = 8e25  # Earth's magnetic dipole moment [G·cm³]
    C: float = 2.99792458e10  # Speed of light [cm/s]
    RE: float = 6.371e8  # Earth radius [cm]
    E_CHARGE: float = 4.803e-10  # Elementary charge [esu]
    PROTON_MASS_EV: float = 938.272e6  # Proton rest mass [eV]
    GY: float = 1e9  # Giga-electronvolt


class StoermerTheory:
    """
    Störmer's theory of cosmic ray trajectories in dipole field.
    
    Implements vertical cutoff rigidity equation:
    Rc = (M cos⁴λ) / (4r²)
    """
    
    def __init__(self, constants: Optional[CosmicRayConstants] = None):
        """Initialize with physical constants."""
        self.c = constants or CosmicRayConstants()
    
    def vertical_cutoff_rigidity(
        self,
        latitude: float,     # Geomagnetic latitude [degrees]
        radial_distance: float = 1.0,  # Radial distance [Rₑ]
        M: Optional[float] = None      # Magnetic moment [G·cm³]
    ) -> float:
        """
        Calculate vertical cutoff rigidity in dipole field.
        
        Equation:
            Rc = (M cos⁴λ) / (4r²)
        
        Args:
            latitude: Geomagnetic latitude in degrees
            radial_distance: Radial distance in Earth radii
            M: Earth's magnetic dipole moment (default: 8e25 G·cm³)
        
        Returns:
            Cutoff rigidity in GV
        """
        if M is None:
            M = self.c.M_EARTH
        
        # Convert latitude to radians
        lat_rad = np.radians(latitude)
        
        # Calculate in cgs units
        cos_lat = np.cos(lat_rad)
        r_cm = radial_distance * self.c.RE
        
        # Störmer formula (cgs units → rigidity in statvolts)
        rc_statvolt = (M * cos_lat**4) / (4 * r_cm**2)
        
        # Convert to GV (1 statvolt = 299.792458 V)
        rc_gv = rc_statvolt * 299.792458 / 1e9
        
        return rc_gv
    
    def cutoff_rigidity_latitude_dependence(
        self,
        latitudes: np.ndarray,
        radial_distance: float = 1.0
    ) -> np.ndarray:
        """
        Calculate rigidity cutoff across latitude grid.
        
        Shows strong latitude dependence:
        - Equator (λ=0°): ~17 GV
        - Polar (λ>60°): <1 GV
        """
        rc_values = []
        for lat in latitudes:
            rc = self.vertical_cutoff_rigidity(lat, radial_distance)
            rc_values.append(rc)
        
        return np.array(rc_values)
    
    def minimum_rigidity_for_latitude(
        self,
        target_rigidity_gv: float,
        radial_distance: float = 1.0
    ) -> float:
        """
        Find maximum latitude where given rigidity can penetrate.
        
        Args:
            target_rigidity_gv: Particle rigidity in GV
            radial_distance: Radial distance in Rₑ
        
        Returns:
            Maximum latitude [degrees] where particle can reach
        """
        # Solve for λ: cos⁴λ = (4r² Rc) / M
        rc_cgs = target_rigidity_gv * 1e9 / 299.792458
        r_cm = radial_distance * self.c.RE
        
        cos4_lat = (4 * r_cm**2 * rc_cgs) / self.c.M_EARTH
        
        if cos4_lat > 1:
            return 90.0  # Can reach all latitudes
        if cos4_lat <= 0:
            return 0.0   # Cannot reach any latitude
        
        cos_lat = cos4_lat ** 0.25
        return np.degrees(np.arccos(cos_lat))
    
    def particle_rigidity(
        self,
        energy_gev: float,
        mass_gev: float = 0.938,  # Proton mass in GeV
        charge: int = 1            # Charge in units of e
    ) -> float:
        """
        Calculate particle rigidity from energy.
        
        Equation:
            R = pc/Ze
        
        Args:
            energy_gev: Total energy in GeV
            mass_gev: Rest mass in GeV (0.938 for proton)
            charge: Charge in units of e
        
        Returns:
            Rigidity in GV
        """
        # Momentum in GeV/c
        p_gev = np.sqrt(energy_gev**2 - mass_gev**2)
        
        # Rigidity in GV
        rigidity = p_gev / charge
        
        return rigidity
    
    def penetration_depth(
        self,
        rigidity_gv: float,
        latitude: float,
        altitude_km: float = 0
    ) -> Dict:
        """
        Calculate penetration depth for given rigidity and location.
        
        Returns:
            Dictionary with penetration information
        """
        rc_local = self.vertical_cutoff_rigidity(
            latitude,
            1.0 + altitude_km / (self.c.RE / 1e5)  # Convert km to Earth radii
        )
        
        can_penetrate = rigidity_gv >= rc_local
        excess = rigidity_gv - rc_local if can_penetrate else 0
        
        return {
            'can_penetrate': can_penetrate,
            'local_cutoff': rc_local,
            'rigidity_excess': excess,
            'penetration_likelihood': 1.0 if can_penetrate else 0.0
        }


class TsyganenkoFieldModel:
    """
    Empirical magnetic field model (Tsyganenko T96/T01).
    
    Used for realistic magnetospheric field during storms.
    """
    
    def __init__(self, model_version: str = 'T96'):
        self.version = model_version
    
    def dipole_tilt(
        self,
        year: float,
        doy: float,
        ut_hours: float
    ) -> float:
        """
        Calculate dipole tilt angle.
        
        Args:
            year: Year (e.g., 2026)
            doy: Day of year
            ut_hours: Universal time in hours
        
        Returns:
            Dipole tilt in degrees
        """
        # Simplified dipole tilt calculation
        # Based on Earth's axial tilt (23.5°) and orbital position
        seasonal = 23.5 * np.cos(2 * np.pi * (doy - 80) / 365.25)
        diurnal = 11.5 * np.sin(2 * np.pi * (ut_hours - 12) / 24)
        
        return seasonal + diurnal
    
    def cutoff_modification(
        self,
        rc_dipole: float,
        dst_index: float,
        solar_wind_pressure: float
    ) -> float:
        """
        Modify cutoff rigidity during disturbed conditions.
        
        During storms (Dst < -50 nT), cutoffs can drop significantly.
        """
        # Ring current effect (Dst)
        dst_effect = 1.0 + dst_index / 500  # Dst in nT
        
        # Pressure effect
        p_effect = 1.0 / np.sqrt(solar_wind_pressure / 2.0)  # Relative to 2 nPa
        
        # Combined modification
        return rc_dipole * dst_effect * p_effect


class NeutronMonitorResponse:
    """
    Neutron monitor response to primary cosmic rays.
    """
    
    def __init__(self, station_latitude: float, cutoff_rigidity: float):
        self.latitude = station_latitude
        self.cutoff = cutoff_rigidity
    
    def response_function(
        self,
        primary_rigidity: float,
        yield_function: str = 'clement2007'
    ) -> float:
        """
        Calculate NM response to primary cosmic rays.
        
        Based on yield function (counts per primary particle).
        """
        if primary_rigidity < self.cutoff:
            return 0.0  # Below cutoff - no response
        
        # Simplified yield function (Clement et al. 2007)
        if yield_function == 'clement2007':
            if primary_rigidity < 10:
                yield_factor = 0.1 * primary_rigidity**2
            else:
                yield_factor = 10 * primary_rigidity**0.5
        else:
            # Power law approximation
            yield_factor = primary_rigidity**0.8
        
        return yield_factor
    
    def atmospheric_attenuation(
        self,
        pressure_hpa: float = 1013,
        reference_pressure: float = 1013
    ) -> float:
        """
        Atmospheric pressure correction.
        
        Equation:
            I = I₀ exp(-β(P - P₀))
        
        β ≈ 0.0075 /hPa for neutrons
        """
        beta = 0.0075  # Pressure coefficient
        return np.exp(-beta * (pressure_hpa - reference_pressure))
    
    def get_sei_contribution(
        self,
        count_rate: float,
        quiet_time_rate: float,
        pressure: float = 1013
    ) -> float:
        """
        Calculate Nmf contribution to SEI.
        
        Normalized to [0,1] where 1 = quiet time rate.
        """
        # Correct for pressure
        corrected_rate = count_rate / self.atmospheric_attenuation(pressure)
        
        # Normalize to quiet time
        ratio = corrected_rate / quiet_time_rate
        
        # Clip to reasonable range
        return np.clip(ratio, 0.5, 1.0)
