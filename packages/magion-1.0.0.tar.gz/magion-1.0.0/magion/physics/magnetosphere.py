"""
Magnetospheric Physics Module
Contains MHD equilibrium equations and magnetopause calculations
from MAGION research paper (Section 2.1.1)
"""

import numpy as np
from typing import Tuple, Dict, Optional
from dataclasses import dataclass


@dataclass
class MagnetopauseConstants:
    """Physical constants for magnetopause calculations."""
    B0: float = 3.12e-5  # Equatorial surface magnetic field [T]
    RE: float = 6371e3    # Earth radius [m]
    MU0: float = 4 * np.pi * 1e-7  # Permeability of free space [H/m]
    PROTON_MASS: float = 1.67e-27  # [kg]
    MEAN_SOLAR_WIND_VELOCITY: float = 400e3  # [m/s]
    MEAN_DENSITY: float = 5e6  # [m⁻³]


class MagnetosphereMHD:
    """
    Magnetohydrodynamic equations for magnetospheric equilibrium.
    
    Implements pressure balance equation:
    ρv² = B² / (2μ₀)
    
    And magnetopause standoff distance:
    Rs = (B₀² Rₑ⁶ / 2μ₀ρv²)^(1/6)
    """
    
    def __init__(self, constants: Optional[MagnetopauseConstants] = None):
        """Initialize with physical constants."""
        self.c = constants or MagnetopauseConstants()
    
    def dynamic_pressure(
        self,
        density: float,    # [m⁻³]
        velocity: float,   # [m/s]
        alpha: float = 1.0  # Composition factor (1.0 for pure proton)
    ) -> float:
        """
        Calculate solar wind dynamic pressure.
        
        Args:
            density: Proton number density [m⁻³]
            velocity: Solar wind velocity [m/s]
            alpha: Composition correction factor
        
        Returns:
            Dynamic pressure [Pa]
        
        Equation:
            P_dyn = ρv² = (n_p m_p) v²
        """
        mass_density = density * self.c.PROTON_MASS * alpha
        return mass_density * velocity**2
    
    def magnetic_pressure(self, b_field: float) -> float:
        """
        Calculate magnetic pressure.
        
        Args:
            b_field: Magnetic field strength [T]
        
        Returns:
            Magnetic pressure [Pa]
        
        Equation:
            P_mag = B² / (2μ₀)
        """
        return b_field**2 / (2 * self.c.MU0)
    
    def pressure_balance(
        self,
        p_dyn: float,
        b_magnetosphere: Optional[float] = None
    ) -> Tuple[float, float]:
        """
        Solve pressure balance equation.
        
        Equation:
            ρv² = B² / (2μ₀)
        
        Returns:
            Tuple of (dynamic_pressure, magnetic_pressure)
        """
        if b_magnetosphere is None:
            b_magnetosphere = self.c.B0
        
        p_mag = self.magnetic_pressure(b_magnetosphere)
        
        # At equilibrium, pressures are equal
        return p_dyn, p_mag
    
    def magnetopause_standoff(
        self,
        p_dyn: float,
        b0: Optional[float] = None
    ) -> float:
        """
        Calculate subsolar magnetopause standoff distance.
        
        Equation:
            Rs = (B₀² Rₑ⁶ / 2μ₀ρv²)^(1/6)
        
        Args:
            p_dyn: Solar wind dynamic pressure [Pa]
            b0: Equatorial surface magnetic field [T]
        
        Returns:
            Standoff distance in Earth radii [Rₑ]
        """
        if b0 is None:
            b0 = self.c.B0
        
        numerator = b0**2 * self.c.RE**6
        denominator = 2 * self.c.MU0 * p_dyn
        
        # Handle extreme values
        if denominator <= 0:
            return 3.0  # Minimum possible (extreme storm)
        
        rs_meters = (numerator / denominator) ** (1/6)
        return rs_meters / self.c.RE
    
    def magnetopause_standoff_from_plasma(
        self,
        density_cm3: float,   # [cm⁻³]
        velocity_kms: float,  # [km/s]
        b0: Optional[float] = None
    ) -> float:
        """
        Calculate standoff distance from raw plasma parameters.
        
        Args:
            density_cm3: Proton density in cm⁻³
            velocity_kms: Solar wind velocity in km/s
        
        Returns:
            Standoff distance in Earth radii
        """
        # Convert to SI units
        density_m3 = density_cm3 * 1e6
        velocity_ms = velocity_kms * 1000
        
        # Calculate dynamic pressure
        p_dyn = self.dynamic_pressure(density_m3, velocity_ms)
        
        # Calculate standoff
        return self.magnetopause_standoff(p_dyn, b0)
    
    def shue_empirical(
        self,
        p_dyn_npa: float,  # Dynamic pressure in nPa
        bz_nt: float       # IMF Bz in nT
    ) -> float:
        """
        Shue et al. (1998) empirical magnetopause model.
        
        Used in MAGION for improved accuracy during storms.
        
        Equation:
            Rs = (10.22 + 1.29 tanh(0.184(Bz + 8.14))) P_dyn^(-1/α)
            where α = 0.58 - 0.010 Bz for Bz < 0
                  α = 0.58 for Bz ≥ 0
        """
        # Convert to nPa if needed
        if p_dyn_npa < 1e-6:  # Probably in Pa
            p_dyn_npa *= 1e9
        
        # Calculate alpha (magnetopause flaring parameter)
        if bz_nt >= 0:
            alpha = 0.58
        else:
            alpha = 0.58 + 0.010 * abs(bz_nt)
        
        # Calculate term
        term = 10.22 + 1.29 * np.tanh(0.184 * (bz_nt + 8.14))
        
        # Calculate standoff
        rs = term * p_dyn_npa ** (-1/alpha)
        
        return rs
    
    def compression_ratio(self, rs_current: float, rs_nominal: float = 10.0) -> float:
        """
        Calculate magnetospheric compression ratio.
        
        Returns:
            Compression ratio (1.0 = nominal, <1.0 = compressed)
        """
        return rs_current / rs_nominal
    
    def get_shield_efficiency_contribution(
        self,
        rs: float,
        rs_min: float = 6.5,
        rs_max: float = 11.0
    ) -> float:
        """
        Calculate Rs contribution to SEI (0-1 scale).
        
        Equation:
            φ_Rs = (Rs - Rs_min) / (Rs_max - Rs_min)
        """
        rs_clipped = np.clip(rs, rs_min, rs_max)
        return (rs_clipped - rs_min) / (rs_max - rs_min)
    
    def estimate_cme_impact(
        self,
        cme_speed_kms: float,
        ambient_density_cm3: float = 5.0,
        sheath_thickness_re: float = 2.0
    ) -> Dict:
        """
        Estimate CME impact on magnetosphere.
        
        Args:
            cme_speed_kms: CME speed in km/s
            ambient_density_cm3: Background solar wind density
            sheath_thickness_re: Sheath region thickness in Rₑ
        
        Returns:
            Dictionary with impact estimates
        """
        # CME density enhancement (typical factor 4-10)
        density_cme = ambient_density_cm3 * np.random.uniform(4, 10)
        
        # Calculate pressures
        p_dyn_ambient = self.dynamic_pressure(
            ambient_density_cm3 * 1e6,
            self.c.MEAN_SOLAR_WIND_VELOCITY
        )
        
        p_dyn_cme = self.dynamic_pressure(
            density_cme * 1e6,
            cme_speed_kms * 1000
        )
        
        # Calculate standoff distances
        rs_ambient = self.magnetopause_standoff(p_dyn_ambient)
        rs_cme = self.magnetopause_standoff(p_dyn_cme)
        
        # Compression
        compression = rs_cme / rs_ambient
        
        return {
            'ambient_rs': rs_ambient,
            'cme_rs': rs_cme,
            'compression_ratio': compression,
            'sei_contribution': self.get_shield_efficiency_contribution(rs_cme),
            'pressure_ratio': p_dyn_cme / p_dyn_ambient,
            'sheath_transit_time': sheath_thickness_re * self.c.RE / (cme_speed_kms * 1000) / 60  # minutes
        }


class MagnetopauseCurrentSheet:
    """
    Chapman-Ferraro current sheet at magnetopause.
    """
    
    def __init__(self, magnetosphere: MagnetosphereMHD):
        self.m = magnetosphere
    
    def current_density(
        self,
        b_magnetosphere: float,
        b_solar_wind: float,
        mu0: float = 4 * np.pi * 1e-7
    ) -> float:
        """
        Calculate magnetopause current density.
        
        Equation:
            J = (B_mag - B_sw) / μ₀
        """
        return (b_magnetosphere - b_solar_wind) / mu0
    
    def magnetic_shear(self, bz_nt: float, by_nt: float) -> float:
        """
        Calculate magnetic shear angle at magnetopause.
        
        Important for reconnection efficiency.
        """
        b_horizontal = np.sqrt(by_nt**2)
        shear = np.arctan2(b_horizontal, abs(bz_nt))
        return np.degrees(shear)
    
    def reconnection_rate(
        self,
        shear_angle: float,
        alfven_speed_ms: float,
        b_ratio: float = 0.1
    ) -> float:
        """
        Estimate magnetic reconnection rate.
        
        Equation:
            R_rec = b_ratio * V_A * sin(shear_angle/2)
        """
        return b_ratio * alfven_speed_ms * np.sin(np.radians(shear_angle/2))
