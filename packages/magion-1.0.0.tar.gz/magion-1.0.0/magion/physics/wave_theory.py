"""
Alfvén Wave Physics Module
Contains magnetohydrodynamic wave equations from MAGION paper
"""

import numpy as np
from typing import Dict, Optional
from dataclasses import dataclass


@dataclass
class PlasmaConstants:
    """Physical constants for plasma physics."""
    MU0: float = 4 * np.pi * 1e-7  # Permeability [H/m]
    EPS0: float = 8.854e-12  # Permittivity [F/m]
    PROTON_MASS: float = 1.67e-27  # [kg]
    ELECTRON_MASS: float = 9.11e-31  # [kg]
    E_CHARGE: float = 1.602e-19  # [C]
    B_EARTH: float = 3.12e-5  # Surface field [T]


class AlfvenWavePhysics:
    """
    Alfvén wave propagation in magnetospheric plasma.
    
    Equations:
        V_A = B / √(μ₀ρ)  (Alfvén velocity)
        ω = k V_A          (Dispersion relation)
        τ = L / V_A        (Propagation time)
    """
    
    def __init__(self, constants: Optional[PlasmaConstants] = None):
        self.c = constants or PlasmaConstants()
    
    def alfven_velocity(
        self,
        b_field: float,      # Magnetic field [T]
        density: float,      # Plasma density [m⁻³]
        ion_mass: float = None  # Ion mass [kg] (default: proton)
    ) -> float:
        """
        Calculate Alfvén velocity.
        
        Equation:
            V_A = B / √(μ₀ρ)
        
        Args:
            b_field: Magnetic field strength in Tesla
            density: Plasma number density in m⁻³
            ion_mass: Ion mass in kg (default: proton mass)
        
        Returns:
            Alfvén velocity in m/s
        """
        if ion_mass is None:
            ion_mass = self.c.PROTON_MASS
        
        mass_density = density * ion_mass
        return b_field / np.sqrt(self.c.MU0 * mass_density)
    
    def alfven_velocity_from_parameters(
        self,
        b_nt: float,         # B field in nT
        density_cm3: float,  # Density in cm⁻³
        ion_mass_amu: float = 1.0  # Ion mass in AMU
    ) -> float:
        """
        Calculate Alfvén velocity from common space units.
        
        Args:
            b_nt: Magnetic field in nanotesla
            density_cm3: Density in cm⁻³
            ion_mass_amu: Ion mass in atomic mass units
        
        Returns:
            Alfvén velocity in km/s
        """
        # Convert to SI
        b_si = b_nt * 1e-9
        density_si = density_cm3 * 1e6
        ion_mass = ion_mass_amu * self.c.PROTON_MASS
        
        # Calculate and convert to km/s
        va_si = self.alfven_velocity(b_si, density_si, ion_mass)
        return va_si / 1000
    
    def alfven_mach_number(
        self,
        flow_velocity: float,  # Flow velocity [m/s]
        b_field: float,        # Magnetic field [T]
        density: float         # Density [m⁻³]
    ) -> float:
        """
        Calculate Alfvén Mach number.
        
        Equation:
            M_A = V_flow / V_A
        
        M_A > 1: Super-Alfvénic flow
        M_A < 1: Sub-Alfvénic flow
        """
        va = self.alfven_velocity(b_field, density)
        return flow_velocity / va
    
    def alfven_radius(
        self,
        flow_velocity: float,
        density: float,
        b_dipole: float,
        r_earth: float = 6371e3
    ) -> float:
        """
        Calculate Alfvén radius (where V_flow = V_A).
        
        Important for magnetopause location and reconnection.
        """
        # Magnetic field falls as 1/r³
        def b_at_r(r):
            return b_dipole * (r_earth / r)**3
        
        # Find r where V_A = V_flow
        # Binary search for simplicity
        r_min = r_earth
        r_max = 20 * r_earth
        
        for _ in range(50):
            r_mid = (r_min + r_max) / 2
            b_mid = b_at_r(r_mid)
            va_mid = self.alfven_velocity(b_mid, density)
            
            if va_mid > flow_velocity:
                r_min = r_mid
            else:
                r_max = r_mid
        
        return r_mid / r_earth  # Return in Earth radii
    
    def wave_dispersion(
        self,
        k_parallel: float,    # Wave number parallel to B [m⁻¹]
        k_perp: float,        # Wave number perpendicular [m⁻¹]
        b_field: float,
        density: float,
        ion_cyclotron_freq: Optional[float] = None
    ) -> Dict:
        """
        Calculate Alfvén wave dispersion relation.
        
        Returns:
            Dictionary with wave frequencies and modes
        """
        va = self.alfven_velocity(b_field, density)
        
        # Parallel propagation (k_perp = 0)
        omega_parallel = k_parallel * va
        
        # Perpendicular propagation (kinetic Alfvén wave)
        if ion_cyclotron_freq is None:
            ion_cyclotron_freq = self.ion_cyclotron_frequency(b_field)
        
        # Finite frequency correction
        k_perp_rho = k_perp * va / ion_cyclotron_freq
        omega_perp = k_parallel * va * np.sqrt(1 + k_perp_rho**2)
        
        return {
            'omega_parallel': omega_parallel,
            'omega_perp': omega_perp,
            'va': va,
            'k_parallel': k_parallel,
            'k_perp': k_perp,
            'ion_cyclotron_freq': ion_cyclotron_freq
        }
    
    def ion_cyclotron_frequency(self, b_field: float) -> float:
        """
        Calculate ion cyclotron frequency.
        
        Equation:
            Ω_i = eB / m_i
        """
        return self.c.E_CHARGE * b_field / self.c.PROTON_MASS
    
    def wave_propagation_time(
        self,
        distance_m: float,
        b_field: float,
        density: float
    ) -> float:
        """
        Calculate Alfvén wave propagation time.
        
        Args:
            distance_m: Distance along field line [m]
            b_field: Magnetic field [T]
            density: Plasma density [m⁻³]
        
        Returns:
            Propagation time in seconds
        """
        va = self.alfven_velocity(b_field, density)
        return distance_m / va
    
    def field_line_resonance_frequency(
        self,
        length_re: float,
        b_eq_nt: float,
        density_eq_cm3: float
    ) -> float:
        """
        Calculate field line resonance frequency.
        
        Important for ULF wave studies and particle interactions.
        
        Returns:
            Frequency in mHz
        """
        # Convert to SI
        length_m = length_re * 6371e3
        b_eq_si = b_eq_nt * 1e-9
        density_eq_si = density_eq_cm3 * 1e6
        
        # Average Alfvén velocity along field line
        # Simple approximation: average of equatorial and ionospheric
        b_iono_si = b_eq_si * (length_re/2)**3  # Rough scaling
        density_iono_si = density_eq_si * 10  # Higher density at ionosphere
        
        va_eq = self.alfven_velocity(b_eq_si, density_eq_si)
        va_iono = self.alfven_velocity(b_iono_si, density_iono_si)
        va_avg = (va_eq + va_iono) / 2
        
        # Quarter wavelength for fundamental
        period = 4 * length_m / va_avg
        freq_mhz = 1000 / period  # mHz
        
        return freq_mhz
    
    def get_sei_contribution(
        self,
        va_kms: float,
        va_quiet: float = 1000.0,  # Quiet time Alfvén speed [km/s]
        va_min: float = 300.0,
        va_max: float = 1500.0
    ) -> float:
        """
        Calculate Alfvén velocity contribution to SEI.
        
        Higher VA generally indicates more efficient energy transfer
        and stronger coupling to solar wind.
        
        Returns:
            Normalized contribution (0-1)
        """
        # Normalize: 1 at quiet time, lower during disturbed
        ratio = va_kms / va_quiet
        
        # Clip and normalize
        if ratio >= 1.0:
            return 1.0
        else:
            return np.clip(ratio, 0.5, 1.0)
