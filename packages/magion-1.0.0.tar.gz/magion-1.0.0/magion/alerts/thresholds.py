"""
Alert Thresholds Module
Configuration for SEI alert thresholds based on MAGION paper.
"""

from typing import Dict, Tuple, Optional


class AlertThresholds:
    """
    Alert threshold configuration.
    
    Based on MAGION paper Section 4.2:
    - QUIET ⚪: 95-100%
    - UNSETTLED 🟢: 80-94%
    - STORM ALERT 🟡: 60-79%
    - SEVERE BLAST 🟠: 40-59%
    - CRITICAL 🔴: 0-39%
    """
    
    # Default thresholds from paper
    DEFAULT_THRESHOLDS = {
        'QUIET': (95, 100),
        'UNSETTLED': (80, 94),
        'STORM_ALERT': (60, 79),
        'SEVERE_BLAST': (40, 59),
        'CRITICAL': (0, 39)
    }
    
    # Occurrence frequencies from paper (2000-2024)
    OCCURRENCE_FREQUENCY = {
        'QUIET': 67.3,  # % of time
        'UNSETTLED': 21.8,
        'STORM_ALERT': 7.4,
        'SEVERE_BLAST': 2.9,
        'CRITICAL': 0.6
    }
    
    def __init__(self, custom_thresholds: Optional[Dict] = None):
        """
        Initialize alert thresholds.
        
        Args:
            custom_thresholds: Optional custom threshold dictionary
        """
        self.thresholds = custom_thresholds or self.DEFAULT_THRESHOLDS.copy()
        
    def get_level(self, sei_value: float) -> str:
        """Get alert level for SEI value."""
        for level, (low, high) in self.thresholds.items():
            if low <= sei_value <= high:
                return level
        return 'UNKNOWN'
    
    def get_range(self, level: str) -> Tuple[float, float]:
        """Get SEI range for alert level."""
        return self.thresholds.get(level, (0, 0))
    
    def is_critical(self, sei_value: float) -> bool:
        """Check if SEI is in critical range."""
        return sei_value <= self.thresholds['CRITICAL'][1]
    
    def is_severe(self, sei_value: float) -> bool:
        """Check if SEI is in severe range."""
        low, high = self.thresholds['SEVERE_BLAST']
        return low <= sei_value <= high
    
    def is_storm(self, sei_value: float) -> bool:
        """Check if SEI is in storm alert range."""
        low, high = self.thresholds['STORM_ALERT']
        return low <= sei_value <= high
    
    def get_frequency(self, level: str) -> float:
        """Get occurrence frequency for alert level."""
        return self.OCCURRENCE_FREQUENCY.get(level, 0.0)
    
    def get_hours_per_year(self, level: str) -> float:
        """Get estimated hours per year for alert level."""
        frequency = self.get_frequency(level)
        return (frequency / 100) * 365.25 * 24
    
    def customize(self, level: str, low: float, high: float) -> None:
        """Customize threshold for a level."""
        if level in self.thresholds:
            self.thresholds[level] = (low, high)
    
    def reset_to_default(self) -> None:
        """Reset thresholds to defaults."""
        self.thresholds = self.DEFAULT_THRESHOLDS.copy()
    
    def __repr__(self) -> str:
        return f"AlertThresholds(levels={list(self.thresholds.keys())})"
