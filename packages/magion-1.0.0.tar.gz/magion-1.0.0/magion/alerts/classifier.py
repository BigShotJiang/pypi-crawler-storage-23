"""
Alert Classifier Module
Five-tier severity classification for operational decision support.
Based on MAGION paper Section 4.2.
"""

from typing import Dict, List, Optional
from datetime import datetime, timedelta  # ✅ إضافة timedelta هنا


class AlertClassifier:
    """
    Five-tier alert classification system.
    
    Levels:
    - QUIET ⚪ (95-100%): Nominal protection
    - UNSETTLED 🟢 (80-94%): Minor compression
    - STORM ALERT 🟡 (60-79%): Moderate degradation
    - SEVERE BLAST 🟠 (40-59%): Major storm
    - CRITICAL 🔴 (0-39%): Extreme event
    """
    
    # Thresholds from paper
    THRESHOLDS = {
        'QUIET': (95, 100),
        'UNSETTLED': (80, 94),
        'STORM_ALERT': (60, 79),
        'SEVERE_BLAST': (40, 59),
        'CRITICAL': (0, 39)
    }
    
    # Operational impacts from paper
    IMPACTS = {
        'QUIET': 'Normal operations',
        'UNSETTLED': 'Monitor HF communications',
        'STORM_ALERT': 'Increase satellite monitoring; navigation errors possible',
        'SEVERE_BLAST': 'Reroute polar flights; GIC alerts; satellite anomalies likely',
        'CRITICAL': 'Emergency protocols; transformer protection; safe-mode required'
    }
    
    # Colors for visualization
    COLORS = {
        'QUIET': '⚪',
        'UNSETTLED': '🟢',
        'STORM_ALERT': '🟡',
        'SEVERE_BLAST': '🟠',
        'CRITICAL': '🔴'
    }
    
    def __init__(self):
        """Initialize alert classifier."""
        self.alert_history = []
        self.notification_endpoints = []
        
    def classify(self, sei_value: float) -> str:
        """
        Classify SEI value into alert level.
        
        Args:
            sei_value: Shield Efficiency Index (0-100)
            
        Returns:
            Alert level string
        """
        for level, (low, high) in self.THRESHOLDS.items():
            if low <= sei_value <= high:
                return level
        
        # Fallback (should not happen)
        return 'UNKNOWN'
    
    def get_impact(self, alert_level: str) -> str:
        """Get operational impact for alert level."""
        return self.IMPACTS.get(alert_level, 'Unknown impact')
    
    def get_color(self, alert_level: str) -> str:
        """Get color emoji for alert level."""
        return self.COLORS.get(alert_level, '⚪')
    
    def should_alert(self, sei_value: float, threshold: str = 'SEVERE_BLAST') -> bool:
        """Check if alert should be triggered."""
        level = self.classify(sei_value)
        level_index = list(self.THRESHOLDS.keys()).index(level)
        threshold_index = list(self.THRESHOLDS.keys()).index(threshold)
        
        return level_index <= threshold_index  # Lower index = more severe
    
    def send_alert(self, sei_data: Dict) -> Dict:
        """
        Send alert through configured channels.
        
        Args:
            sei_data: Dictionary with SEI information
            
        Returns:
            Alert record
        """
        alert = {
            'timestamp': datetime.now().isoformat(),
            'sei_value': sei_data['value'],
            'alert_level': sei_data['alert_level'],
            'color': self.get_color(sei_data['alert_level']),
            'impact': self.get_impact(sei_data['alert_level']),
            'parameters': sei_data.get('parameters', {}),
            'sent_to': self.notification_endpoints
        }
        
        # Add to history
        self.alert_history.append(alert)
        
        # In production, this would send emails, SMS, webhooks, etc.
        print(f"\n🚨 ALERT: {alert['color']} {alert['alert_level']}")
        print(f"SEI: {alert['sei_value']:.1f}")
        print(f"Impact: {alert['impact']}")
        
        return alert
    
    def get_statistics(self, hours: int = 24) -> Dict:
        """Get alert statistics for last N hours."""
        now = datetime.now()
        cutoff = now - timedelta(hours=hours)  # ✅ الآن timedelta معرّف
        
        recent = [
            a for a in self.alert_history
            if datetime.fromisoformat(a['timestamp']) > cutoff
        ]
        
        stats = {}
        for level in self.THRESHOLDS.keys():
            count = sum(1 for a in recent if a['alert_level'] == level)
            stats[level] = count
        
        return {
            'period_hours': hours,
            'total_alerts': len(recent),
            'by_level': stats,
            'most_severe': min(recent, key=lambda x: x['sei_value']) if recent else None
        }
    
    def get_recommendation(self, alert_level: str, context: Dict = None) -> str:
        """Get operational recommendation based on alert level and context."""
        recommendations = {
            'QUIET': 'Continue normal operations. Monitor routine space weather reports.',
            'UNSETTLED': 'Monitor HF communications for degradation. Check satellite telemetry.',
            'STORM_ALERT': 'Increase satellite monitoring frequency. Prepare for possible safe-mode. Alert aviation stakeholders.',
            'SEVERE_BLAST': 'Implement protective measures. Reroute polar flights. Prepare GIC mitigation. Consider satellite safe-mode.',
            'CRITICAL': 'IMMEDIATE ACTION: Execute emergency protocols. Transition satellites to safe-mode. Protect transformers. Halt sensitive operations.'
        }
        
        base_rec = recommendations.get(alert_level, '')
        
        # Add context-specific recommendations
        if context:
            if 'satellite' in context:
                base_rec += ' Monitor specific satellites in polar orbits.'
            if 'aviation' in context:
                base_rec += ' Contact airlines operating polar routes.'
            if 'power_grid' in context:
                base_rec += ' Alert grid operators in high-latitude regions.'
        
        return base_rec
    
    def __repr__(self) -> str:
        return f"AlertClassifier(levels={list(self.THRESHOLDS.keys())})"
