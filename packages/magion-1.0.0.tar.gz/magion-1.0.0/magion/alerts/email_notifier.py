"""
Email Notifier Module
Send email alerts for space weather events.
"""

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, List, Optional
from datetime import datetime


class EmailNotifier:
    """
    Email notification system for SEI alerts.
    """
    
    def __init__(
        self,
        smtp_host: str = 'smtp.gmail.com',
        smtp_port: int = 587,
        username: Optional[str] = None,
        password: Optional[str] = None,
        from_addr: Optional[str] = None
    ):
        """
        Initialize email notifier.
        
        Args:
            smtp_host: SMTP server host
            smtp_port: SMTP server port
            username: SMTP username
            password: SMTP password
            from_addr: From email address
        """
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
        self.from_addr = from_addr or username
        
        self.recipients = []
        self.alert_history = []
        
    def add_recipient(self, email: str) -> None:
        """Add recipient to notification list."""
        if email not in self.recipients:
            self.recipients.append(email)
    
    def remove_recipient(self, email: str) -> None:
        """Remove recipient from notification list."""
        if email in self.recipients:
            self.recipients.remove(email)
    
    def send_alert(self, sei_data: Dict, level: str) -> bool:
        """
        Send email alert.
        
        Args:
            sei_data: SEI data dictionary
            level: Alert level
            
        Returns:
            True if sent successfully
        """
        if not self.recipients:
            print("No recipients configured")
            return False
        
        # Create message
        msg = MIMEMultipart()
        msg['Subject'] = f"🚨 MAGION Alert: {level} - SEI: {sei_data['value']:.1f}"
        msg['From'] = self.from_addr
        msg['To'] = ', '.join(self.recipients)
        
        # Build email body
        body = self._build_email_body(sei_data, level)
        msg.attach(MIMEText(body, 'html'))
        
        # Send email
        try:
            if self.username and self.password:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)
                server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg)
                server.quit()
                
                # Record in history
                self.alert_history.append({
                    'timestamp': datetime.now().isoformat(),
                    'level': level,
                    'sei': sei_data['value'],
                    'recipients': self.recipients.copy()
                })
                
                return True
            else:
                print("SMTP credentials not configured")
                return False
                
        except Exception as e:
            print(f"Failed to send email: {e}")
            return False
    
    def _build_email_body(self, sei_data: Dict, level: str) -> str:
        """Build HTML email body."""
        # Color mapping
        colors = {
            'QUIET': '#00FF00',
            'UNSETTLED': '#FFFF00',
            'STORM_ALERT': '#FFA500',
            'SEVERE_BLAST': '#FF4500',
            'CRITICAL': '#FF0000'
        }
        
        color = colors.get(level, '#000000')
        
        # Impacts from paper
        impacts = {
            'QUIET': 'Normal operations',
            'UNSETTLED': 'Monitor HF communications',
            'STORM_ALERT': 'Increase satellite monitoring',
            'SEVERE_BLAST': 'Reroute polar flights; GIC alerts',
            'CRITICAL': 'Emergency protocols; transformer protection'
        }
        
        html = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .alert {{ 
                    background-color: {color};
                    color: white;
                    padding: 20px;
                    text-align: center;
                    font-size: 24px;
                    font-weight: bold;
                }}
                .section {{
                    margin: 20px;
                    padding: 15px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                }}
                .value {{
                    font-size: 48px;
                    font-weight: bold;
                    color: {color};
                }}
            </style>
        </head>
        <body>
            <div class="alert">
                MAGION Space Weather Alert: {level}
            </div>
            
            <div class="section">
                <h2>Current Shield Efficiency Index</h2>
                <div class="value">{sei_data['value']:.1f}%</div>
                <p>Time: {sei_data.get('timestamp', 'N/A')}</p>
            </div>
            
            <div class="section">
                <h2>Operational Impact</h2>
                <p>{impacts.get(level, 'Unknown')}</p>
            </div>
            
            <div class="section">
                <h2>Parameter Breakdown</h2>
                <table border="1" cellpadding="5">
                    <tr>
                        <th>Parameter</th>
                        <th>Value</th>
                        <th>Contribution</th>
                    </tr>
        """
        
        # Add parameters
        params = sei_data.get('parameters', {})
        weights = {'rs': 0.20, 'nmf': 0.18, 'kp': 0.15, 'np': 0.12,
                  'rc': 0.12, 'tec': 0.10, 'va': 0.08, 'fd': 0.05}
        
        for param, value in params.items():
            weight = weights.get(param, 0)
            contribution = value * weight * 100
            html += f"""
                    <tr>
                        <td>{param.upper()}</td>
                        <td>{value:.3f}</td>
                        <td>{contribution:.1f}%</td>
                    </tr>
            """
        
        html += """
                </table>
            </div>
            
            <div class="section">
                <h2>Recommended Actions</h2>
                <ul>
        """
        
        # Recommendations based on level
        if level == 'CRITICAL':
            html += """
                <li>Immediate safe-mode for all satellites</li>
                <li>Emergency protocols for power grid operators</li>
                <li>Ground all polar flights</li>
                <li>Protect critical infrastructure</li>
            """
        elif level == 'SEVERE_BLAST':
            html += """
                <li>Prepare for satellite safe-mode</li>
                <li>Reroute polar aviation</li>
                <li>Alert grid operators in high latitudes</li>
                <li>Monitor HF communications degradation</li>
            """
        elif level == 'STORM_ALERT':
            html += """
                <li>Increase satellite monitoring frequency</li>
                <li>Check navigation systems for errors</li>
                <li>Prepare GIC mitigation plans</li>
            """
        else:
            html += """
                <li>Continue normal operations</li>
                <li>Monitor routine space weather reports</li>
            """
        
        html += """
                </ul>
            </div>
            
            <div class="section">
                <p style="color: #666; font-size: 12px;">
                    This is an automated alert from MAGION Space Weather Monitoring System.<br>
                    Visit <a href="https://magion.space">magion.space</a> for real-time updates.
                </p>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def get_history(self, limit: int = 10) -> List[Dict]:
        """Get recent alert history."""
        return self.alert_history[-limit:]
    
    def __repr__(self) -> str:
        return f"EmailNotifier(recipients={len(self.recipients)})"
