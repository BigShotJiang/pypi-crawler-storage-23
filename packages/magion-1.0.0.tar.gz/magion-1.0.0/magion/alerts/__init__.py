"""
MAGION Alert System
Five-tier severity classification for operational decision support.
"""

from magion.alerts.classifier import AlertClassifier
from magion.alerts.thresholds import AlertThresholds
from magion.alerts.email_notifier import EmailNotifier
from magion.alerts.webhook_notifier import WebhookNotifier

__all__ = [
    'AlertClassifier',
    'AlertThresholds',
    'EmailNotifier',
    'WebhookNotifier',
]
