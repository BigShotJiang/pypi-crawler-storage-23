"""
Webhook Notifier Module
Send alerts to external services via webhooks.
"""

import json
import requests
from typing import Dict, List, Optional
from datetime import datetime


class WebhookNotifier:
    """
    Webhook notification system for SEI alerts.
    Supports Slack, Discord, Teams, and custom webhooks.
    """
    
    def __init__(self):
        """Initialize webhook notifier."""
        self.webhooks = {
            'slack': [],
            'discord': [],
            'teams': [],
            'custom': []
        }
        self.alert_history = []
        
    def add_webhook(self, service: str, url: str) -> None:
        """Add webhook URL for service."""
        if service in self.webhooks:
            if url not in self.webhooks[service]:
                self.webhooks[service].append(url)
    
    def remove_webhook(self, service: str, url: str) -> None:
        """Remove webhook URL."""
        if service in self.webhooks and url in self.webhooks[service]:
            self.webhooks[service].remove(url)
    
    def send_alert(self, sei_data: Dict, level: str) -> Dict:
        """
        Send alert to all configured webhooks.
        
        Returns:
            Dictionary with results per service
        """
        results = {}
        
        # Format message for each service
        for service, urls in self.webhooks.items():
            results[service] = []
            
            for url in urls:
                if service == 'slack':
                    success = self._send_slack(url, sei_data, level)
                elif service == 'discord':
                    success = self._send_discord(url, sei_data, level)
                elif service == 'teams':
                    success = self._send_teams(url, sei_data, level)
                else:
                    success = self._send_custom(url, sei_data, level)
                
                results[service].append({
                    'url': url,
                    'success': success
                })
        
        # Record in history
        alert_record = {
            'timestamp': datetime.now().isoformat(),
            'level': level,
            'sei': sei_data['value'],
            'results': results
        }
        self.alert_history.append(alert_record)
        
        return results
    
    def _send_slack(self, webhook_url: str, sei_data: Dict, level: str) -> bool:
        """Send alert to Slack."""
        # Color mapping
        colors = {
            'QUIET': 'good',
            'UNSETTLED': 'warning',
            'STORM_ALERT': 'warning',
            'SEVERE_BLAST': 'danger',
            'CRITICAL': 'danger'
        }
        
        # Emoji mapping
        emojis = {
            'QUIET': ':white_circle:',
            'UNSETTLED': ':large_green_circle:',
            'STORM_ALERT': ':large_yellow_circle:',
            'SEVERE_BLAST': ':large_orange_circle:',
            'CRITICAL': ':red_circle:'
        }
        
        message = {
            "attachments": [
                {
                    "color": colors.get(level, 'good'),
                    "title": f"{emojis.get(level, '')} MAGION Alert: {level}",
                    "fields": [
                        {
                            "title": "Shield Efficiency Index",
                            "value": f"{sei_data['value']:.1f}%",
                            "short": True
                        },
                        {
                            "title": "Time",
                            "value": sei_data.get('timestamp', 'N/A'),
                            "short": True
                        }
                    ],
                    "footer": "MAGION Space Weather Monitoring",
                    "footer_icon": "https://magion.space/favicon.ico",
                    "ts": int(datetime.now().timestamp())
                }
            ]
        }
        
        try:
            response = requests.post(webhook_url, json=message)
            return response.status_code == 200
        except:
            return False
    
    def _send_discord(self, webhook_url: str, sei_data: Dict, level: str) -> bool:
        """Send alert to Discord."""
        # Color mapping (hex to decimal)
        colors = {
            'QUIET': 65280,      # Green
            'UNSETTLED': 16776960, # Yellow
            'STORM_ALERT': 16753920, # Orange
            'SEVERE_BLAST': 16733695, # Red-Orange
            'CRITICAL': 16711680   # Red
        }
        
        message = {
            "embeds": [
                {
                    "title": f"MAGION Alert: {level}",
                    "color": colors.get(level, 0),
                    "fields": [
                        {
                            "name": "Shield Efficiency Index",
                            "value": f"{sei_data['value']:.1f}%",
                            "inline": True
                        },
                        {
                            "name": "Time",
                            "value": sei_data.get('timestamp', 'N/A'),
                            "inline": True
                        }
                    ],
                    "footer": {
                        "text": "MAGION Space Weather"
                    },
                    "timestamp": datetime.now().isoformat()
                }
            ]
        }
        
        try:
            response = requests.post(webhook_url, json=message)
            return response.status_code == 204
        except:
            return False
    
    def _send_teams(self, webhook_url: str, sei_data: Dict, level: str) -> bool:
        """Send alert to Microsoft Teams."""
        # Theme color mapping
        colors = {
            'QUIET': '00FF00',
            'UNSETTLED': 'FFFF00',
            'STORM_ALERT': 'FFA500',
            'SEVERE_BLAST': 'FF4500',
            'CRITICAL': 'FF0000'
        }
        
        message = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": colors.get(level, '000000'),
            "title": f"MAGION Alert: {level}",
            "text": f"Shield Efficiency Index: {sei_data['value']:.1f}%",
            "sections": [
                {
                    "facts": [
                        {
                            "name": "Time:",
                            "value": sei_data.get('timestamp', 'N/A')
                        }
                    ]
                }
            ],
            "potentialAction": [
                {
                    "@type": "OpenUri",
                    "name": "View Dashboard",
                    "targets": [
                        {
                            "os": "default",
                            "uri": "https://magion.space"
                        }
                    ]
                }
            ]
        }
        
        try:
            response = requests.post(webhook_url, json=message)
            return response.status_code == 200
        except:
            return False
    
    def _send_custom(self, webhook_url: str, sei_data: Dict, level: str) -> bool:
        """Send alert to custom webhook."""
        message = {
            'alert_level': level,
            'sei_value': sei_data['value'],
            'timestamp': sei_data.get('timestamp'),
            'parameters': sei_data.get('parameters', {}),
            'source': 'MAGION'
        }
        
        try:
            response = requests.post(
                webhook_url,
                json=message,
                headers={'Content-Type': 'application/json'}
            )
            return response.status_code in [200, 201, 202, 204]
        except:
            return False
    
    def get_history(self, limit: int = 10) -> List[Dict]:
        """Get recent alert history."""
        return self.alert_history[-limit:]
    
    def __repr__(self) -> str:
        total = sum(len(urls) for urls in self.webhooks.values())
        return f"WebhookNotifier(webhooks={total})"
