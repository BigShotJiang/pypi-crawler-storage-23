"""
Magnetohydrodynamic (MHD) Solver Module
Numerical solutions for magnetospheric equilibrium
from MAGION research paper (Section 3.2)
"""

import numpy as np
from typing import Tuple, Dict, Optional
from scipy.integrate import solve_ivp
from dataclasses import dataclass


@dataclass
class MHDSolverConfig:
    """Configuration for MHD solver."""
    nx: int = 100  # Grid points in x
    ny: int = 100  # Grid points in y
    nz: int = 50   # Grid points in z
    dt: float = 0.1  # Time step [s]
    cfl: float = 0.5  # CFL number
    gamma: float = 5/3  # Adiabatic index
    mu0: float = 4 * np.pi * 1e-7
    r_earth: float = 6371e3


class MHDSolver:
    """
    Numerical MHD solver for magnetospheric configuration.
    
    Solves ideal MHD equations:
        ∂ρ/∂t + ∇·(ρv) = 0
        ∂(ρv)/∂t + ∇·(ρvv + p*I - BB/μ₀) = 0
        ∂E/∂t + ∇·((E + p*)v - B(B·v)/μ₀) = 0
        ∂B/∂t + ∇·(vB - Bv) = 0
    """
    
    def __init__(self, config: Optional[MHDSolverConfig] = None):
        self.c = config or MHDSolverConfig()
        
    def pressure_balance_residual(
        self,
        position_re: float,
        p_dyn_npa: float,
        bz_nt: float = 0.0
    ) -> float:
        """
        Calculate pressure balance residual at given position.
        
        Equation:
            R = ρv² - B²/(2μ₀)
        
        Returns zero at magnetopause.
        """
        # Magnetic pressure (dipole field)
        b_si = 3.12e-5 * (1 / position_re)**3  # B ∝ 1/r³
        p_mag = b_si**2 / (2 * self.c.mu0)
        
        # Convert to nPa for comparison
        p_mag_npa = p_mag * 1e9
        
        return p_dyn_npa - p_mag_npa
    
    def find_magnetopause(
        self,
        p_dyn_npa: float,
        bz_nt: float = 0.0,
        tolerance: float = 1e-3
    ) -> float:
        """
        Find magnetopause location via root finding.
        
        Returns:
            Standoff distance in Earth radii
        """
        from scipy.optimize import root_scalar
        
        def f(r):
            return self.pressure_balance_residual(r, p_dyn_npa, bz_nt)
        
        # Search between 5 and 15 Rₑ
        try:
            sol = root_scalar(f, bracket=[5, 15], method='brentq')
            return sol.root
        except:
            # Fallback to analytical
            return (3.12e-5**2 * self.c.r_earth**6 / 
                    (2 * self.c.mu0 * p_dyn_npa * 1e-9)) ** (1/6) / self.c.r_earth
    
    def solve_magnetosheath(
        self,
        solar_wind_params: Dict,
        grid_resolution: int = 50
    ) -> Dict:
        """
        Solve for magnetosheath properties using Rankine-Hugoniot conditions.
        
        Args:
            solar_wind_params: Dict with 'density', 'velocity', 'mach_number'
        
        Returns:
            Dictionary with post-shock properties
        """
        # Extract parameters
        rho1 = solar_wind_params.get('density', 5) * 1.67e-21  # kg/m³
        v1 = solar_wind_params.get('velocity', 400) * 1000  # m/s
        m1 = solar_wind_params.get('mach_number', 8)  # Alfvén Mach number
        
        # Rankine-Hugoniot for perpendicular shock
        # Compression ratio
        r = (self.c.gamma + 1) * m1**2 / ((self.c.gamma - 1) * m1**2 + 2)
        
        # Post-shock density and velocity
        rho2 = r * rho1
        v2 = v1 / r
        
        # Post-shock pressure (simplified)
        p2 = rho1 * v1**2 * (1 - 1/r)
        
        # Post-shock temperature
        kT = p2 / (2 * rho2 / 1.67e-27)  # eV
        
        return {
            'compression_ratio': r,
            'density_post': rho2 / 1.67e-21,  # cm⁻³
            'velocity_post': v2 / 1000,  # km/s
            'pressure_post': p2 * 1e9,  # nPa
            'temperature_post': kT  # eV
        }
    
    def trace_field_line(
        self,
        start_point: Tuple[float, float, float],
        max_steps: int = 1000,
        step_size: float = 0.1
    ) -> np.ndarray:
        """
        Trace magnetic field line using field model.
        
        Uses dipole field with optional perturbation.
        
        Returns:
            Array of points along field line
        """
        def dipole_field(x, y, z):
            r = np.sqrt(x**2 + y**2 + z**2)
            if r < 1:  # Inside Earth
                return np.array([0, 0, 0])
            
            # Dipole field in cartesian
            m = np.array([0, 0, 1])  # Dipole moment along z
            r_vec = np.array([x, y, z])
            
            b = (3 * r_vec * np.dot(m, r_vec) / r**5 - m / r**3)
            return b * 3.12e-5  # Scale to Earth's field
        
        def ode_fun(_, point):
            x, y, z = point
            b = dipole_field(x, y, z)
            return b / np.linalg.norm(b)
        
        # Solve field line tracing
        t_span = [0, max_steps * step_size]
        t_eval = np.arange(0, max_steps * step_size, step_size)
        
        sol = solve_ivp(
            ode_fun,
            t_span,
            start_point,
            t_eval=t_eval,
            method='RK45'
        )
        
        return sol.y.T
    
    def compute_alfven_speed_profile(
        self,
        x_range: Tuple[float, float] = (5, 15),
        n_points: int = 100
    ) -> Dict:
        """
        Compute Alfvén speed along Sun-Earth line.
        """
        x = np.linspace(x_range[0], x_range[1], n_points)
        va = np.zeros_like(x)
        
        for i, xi in enumerate(x):
            # Density model (simplified)
            if xi < 8:
                n = 10 * (8/xi)**4  # Plasmasphere
            else:
                n = 5 * (8/xi)**2  # Magnetosheath
            
            # Field strength
            b = 3.12e-5 * (1/xi)**3 * 1e9  # nT
            
            # Alfvén speed
            va[i] = b / np.sqrt(4 * np.pi * 1e-7 * n * 1.67e-21) / 1000
        
        return {
            'x': x,
            'alfven_speed': va,
            'min_va': np.min(va),
            'max_va': np.max(va),
            'mean_va': np.mean(va)
        }
    
    def compute_reconnection_rate(
        self,
        b1_nt: float,
        b2_nt: float,
        theta: float,
        density_cm3: float
    ) -> float:
        """
        Compute magnetic reconnection rate.
        
        Equation:
            E_rec = ε V_A B
        
        Where ε is reconnection efficiency (~0.1 for asymmetric)
        """
        # Average Alfvén speed
        b_avg = (b1_nt + b2_nt) / 2 * 1e-9
        n_si = density_cm3 * 1e6
        
        va = b_avg / np.sqrt(4 * np.pi * 1e-7 * n_si * 1.67e-27)
        
        # Reconnection efficiency (function of shear angle)
        epsilon = 0.1 * np.sin(theta / 2)
        
        # Reconnection electric field
        e_rec = epsilon * va * b_avg
        
        return e_rec * 1000  # mV/m
