"""
ShieldEfficiencyMonitor - Main class for real-time magnetospheric shield monitoring.
"""

import time
from typing import Dict, List, Optional, Union
import numpy as np

from magion.core.sei_calculator import SEICalculator


class ShieldEfficiencyMonitor:
    """
    Main class for monitoring Earth's magnetospheric shield efficiency.
    """
    
    def __init__(
        self,
        data_sources: List[str] = None,
        update_interval: int = 60,
        config_path: Optional[str] = None,
    ):
        self.data_sources = data_sources or ['ACE', 'DSCOVR', 'NMDB', 'NOAA_SWPC']
        self.update_interval = update_interval
        self.config_path = config_path
        self.sei_calculator = SEICalculator()
        self._initialized = False
        
    def _lazy_init(self):
        """Initialize components lazily to avoid circular imports."""
        if not self._initialized:
            from magion.parameters import (
                MagnetopauseStandoff,
                CosmicRayFlux,
                GeomagneticIndex,
                SolarWindDensity,
                RigidityCutoff,
                TotalElectronContent,
                AlfvenVelocity,
                ForbushDecrease
            )
            
            # Initialize parameter modules
            self.rs = MagnetopauseStandoff()
            self.nmf = CosmicRayFlux('NEWK')  # اسم متغير nmf
            self.kp = GeomagneticIndex()
            self.np = SolarWindDensity()
            self.rc = RigidityCutoff()
            self.tec = TotalElectronContent()
            self.va = AlfvenVelocity()
            self.fd = ForbushDecrease()
            
            self._initialized = True
        
    def get_current_sei(self) -> Dict:
        """Get current Shield Efficiency Index value."""
        self._lazy_init()
        
        # Calculate parameter scores - استخدم نفس الأسماء الموجودة في SEICalculator
        param_scores = {
            'rs': self.rs.compute({'density': 5.0, 'velocity': 400.0}),
            'nmf': self.nmf.compute({'neutron_counts': {'NEWK': 100}}),  # nmf وليس nm
            'kp': self.kp.compute({'kp': 2}),
            'np': self.np.compute({'density': 5.0}),
            'rc': self.rc.compute({'dst': 0, 'solar_wind_pressure': 2.0}),
            'tec': self.tec.compute({'tec_value': 10, 'latitude': 45}),
            'va': self.va.compute({'b_field': 5.0, 'density': 5.0}),
            'fd': self.fd.compute({'decrease_percent': 0.0}),
        }
        
        # Calculate SEI
        sei_value = self.sei_calculator.compute(param_scores)
        
        # Determine alert level
        alert_level = self.sei_calculator.get_alert_level(sei_value)
        
        return {
            'value': sei_value,
            'alert_level': alert_level,
            'parameters': param_scores,
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
        }
    
    def forecast_sei(self, hours: int = 6) -> Dict:
        """Forecast SEI for the next N hours."""
        self._lazy_init()
        
        # Simulate forecast
        forecast = []
        lower = []
        upper = []
        
        current = 85.0
        for i in range(hours):
            current -= np.random.normal(0, 0.5)
            forecast.append(max(0, min(100, current)))
            lower.append(max(0, current - 2 - i*0.5))
            upper.append(min(100, current + 2 + i*0.5))
        
        return {
            'forecast': forecast,
            'lower_bound': lower,
            'upper_bound': upper,
            'timesteps': list(range(1, hours + 1)),
            'precursors': []
        }
    
    def __repr__(self) -> str:
        return f"ShieldEfficiencyMonitor(sources={self.data_sources}, interval={self.update_interval}s)"
