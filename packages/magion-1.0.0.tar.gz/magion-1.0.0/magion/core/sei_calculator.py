"""
SEICalculator - Shield Efficiency Index calculation engine.
"""

from typing import Dict, Optional
import numpy as np


class SEICalculator:
    """
    Calculates Shield Efficiency Index from eight orthogonal parameters.
    
    SEI = Σ(w_i × φ_i) where Σw_i = 1 and φ_i ∈ [0,1]
    """
    
    # Parameter weights from research paper
    WEIGHTS = {
        'rs': 0.20,   # Magnetopause Standoff Distance (20%)
        'nmf': 0.18,  # Neutron Monitor Flux (18%)
        'kp': 0.15,   # Kp Geomagnetic Index (15%)
        'np': 0.12,   # Solar Wind Proton Density (12%)
        'rc': 0.12,   # Rigidity Cutoff (12%)
        'tec': 0.10,  # Total Electron Content (10%)
        'va': 0.08,   # Alfvén Velocity (8%)
        'fd': 0.05,   # Forbush Decrease (5%)
    }
    
    def __init__(self, custom_weights: Optional[Dict] = None):
        """
        Initialize SEI calculator with optional custom weights.
        
        Args:
            custom_weights: Dictionary of custom parameter weights
        """
        self.weights = custom_weights or self.WEIGHTS.copy()
        
        # Validate weights sum to 1.0
        weight_sum = sum(self.weights.values())
        if not np.isclose(weight_sum, 1.0, rtol=1e-3):
            raise ValueError(f"Weights must sum to 1.0 (current: {weight_sum})")
    
    def compute(self, param_scores: Dict) -> float:
        """
        Compute SEI from parameter scores.
        
        Args:
            param_scores: Dictionary of normalized parameter scores (0-1)
            
        Returns:
            SEI value (0-100 scale)
        """
        sei = 0.0
        
        for param, score in param_scores.items():
            if param not in self.weights:
                raise ValueError(f"Unknown parameter: {param}")
            
            # Ensure score is within [0, 1]
            clipped_score = np.clip(score, 0.0, 1.0)
            sei += self.weights[param] * clipped_score
        
        # Convert to 0-100 scale
        return sei * 100
    
    def compute_with_uncertainty(self, param_scores: Dict, uncertainties: Dict) -> Dict:
        """
        Compute SEI with uncertainty bounds.
        
        Args:
            param_scores: Dictionary of parameter scores
            uncertainties: Dictionary of parameter uncertainties
            
        Returns:
            Dictionary with SEI value, min, max, and std
        """
        sei_values = []
        
        # Monte Carlo simulation (simplified)
        n_samples = 1000
        for _ in range(n_samples):
            perturbed_scores = {}
            for param, score in param_scores.items():
                if param in uncertainties:
                    # Add Gaussian noise based on uncertainty
                    noise = np.random.normal(0, uncertainties[param])
                    perturbed_scores[param] = np.clip(score + noise, 0, 1)
                else:
                    perturbed_scores[param] = score
            
            sei_values.append(self.compute(perturbed_scores))
        
        sei_array = np.array(sei_values)
        
        return {
            'value': np.mean(sei_array),
            'min': np.min(sei_array),
            'max': np.max(sei_array),
            'std': np.std(sei_array),
            'p5': np.percentile(sei_array, 5),
            'p95': np.percentile(sei_array, 95),
        }
    
    def get_alert_level(self, sei: float) -> str:
        """
        Get alert level based on SEI value.
        
        Args:
            sei: SEI value (0-100)
            
        Returns:
            Alert level string
        """
        if sei >= 80:
            return "QUIET"
        elif sei >= 60:
            return "UNSETTLED"
        elif sei >= 40:
            return "STORM ALERT"
        elif sei >= 20:
            return "SEVERE BLAST"
        else:
            return "CRITICAL"
    
    def __repr__(self) -> str:
        return f"SEICalculator(weights={self.weights})"
