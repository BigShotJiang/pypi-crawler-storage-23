"""
MAGION: Magnetospheric Ionization & Galactic Interaction Observational Network
"""

__version__ = "1.0.0"
__author__ = "Samir Baladi"
__email__ = "gitdeeper@gmail.com"
__license__ = "CC-BY-4.0"

# استيراد مباشر للكلاسات المهمة
from magion.core.shield_monitor import ShieldEfficiencyMonitor
from magion.core.sei_calculator import SEICalculator
from magion.core.forecaster import SEIForecaster

__all__ = [
    'ShieldEfficiencyMonitor',
    'SEICalculator',
    'SEIForecaster',
    '__version__',
]
