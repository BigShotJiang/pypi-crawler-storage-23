"""
Quality Control Module (Pure Python - No scipy)
Data validation, outlier detection, and gap filling.
"""

import numpy as np
from typing import List, Dict, Any, Optional


class QualityControl:
    """
    Quality control for space weather measurements (no scipy dependency).
    """
    
    def __init__(self, sigma_threshold: float = 3.0):
        self.sigma_threshold = sigma_threshold
        self.quality_flags = {}
        
    def check_outliers(self, data: List[float]) -> Dict:
        """
        Detect outliers using IQR method (no scipy needed).
        """
        if len(data) < 4:
            return {'outliers': [], 'method': 'insufficient_data'}
        
        arr = np.array(data)
        
        # Simple IQR method
        q1 = np.percentile(arr, 25)
        q3 = np.percentile(arr, 75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        
        outliers = np.where((arr < lower_bound) | (arr > upper_bound))[0]
        
        return {
            'outliers': outliers.tolist(),
            'total_flagged': len(outliers),
            'method': 'iqr'
        }
    
    def interpolate_gaps(self, data: List[float], timestamps: List[str], max_gap_minutes: int = 30) -> List[float]:
        """
        Simple linear interpolation for gaps.
        """
        result = data.copy()
        
        for i in range(1, len(result) - 1):
            if np.isnan(result[i]) if hasattr(result[i], '__array__') else False:
                if not np.isnan(result[i-1]) and not np.isnan(result[i+1]):
                    result[i] = (result[i-1] + result[i+1]) / 2
                    
        return result
    
    def remove_spikes(self, data: List[float], window: int = 3) -> List[float]:
        """
        Simple spike removal using median.
        """
        result = data.copy()
        
        for i in range(window, len(data) - window):
            window_data = data[i-window:i+window+1]
            median_val = sorted(window_data)[len(window_data)//2]
            mean_val = sum(window_data) / len(window_data)
            std_val = (sum((x - mean_val)**2 for x in window_data) / len(window_data))**0.5
            
            if abs(data[i] - median_val) > 2 * std_val:
                result[i] = median_val
                
        return result
    
    def validate_solar_wind(self, density: float, velocity: float, bz: float) -> Dict:
        """
        Validate solar wind data consistency.
        """
        issues = []
        
        if density < 0 or density > 100:
            issues.append(f"Density out of range: {density}")
        if velocity < 200 or velocity > 1000:
            issues.append(f"Velocity out of range: {velocity}")
        if bz < -50 or bz > 50:
            issues.append(f"Bz out of range: {bz}")
        
        pressure = 1.67e-6 * density * velocity**2
        if pressure < 0.1 or pressure > 50:
            issues.append(f"Pressure out of range: {pressure:.2f} nPa")
        
        return {
            'valid': len(issues) == 0,
            'issues': issues,
            'pressure': pressure
        }
    
    def __repr__(self) -> str:
        return f"QualityControl(threshold={self.sigma_threshold}σ)"
