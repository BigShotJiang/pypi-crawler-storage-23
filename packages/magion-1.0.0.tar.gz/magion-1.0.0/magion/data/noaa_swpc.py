"""
NOAA Space Weather Prediction Center Client
Geomagnetic indices and space weather products.
"""

import requests
from typing import Dict, List, Optional
from datetime import datetime


class NOAASWPCClient:
    """
    NOAA SWPC data client.
    
    Provides Kp, Dst, AE indices and space weather forecasts.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize NOAA SWPC client.
        
        Args:
            api_key: Optional API key
        """
        self.api_key = api_key
        self.base_url = "https://services.swpc.noaa.gov"
        
    def fetch_kp(self) -> Optional[Dict]:
        """
        Fetch latest Kp index.
        
        Returns:
            Dictionary with Kp information
        """
        try:
            url = f"{self.base_url}/products/noaa-planetary-k-index.json"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data:
                    latest = data[-1]
                    return {
                        'timestamp': latest[0],
                        'kp': float(latest[1]),
                        'status': latest[2],
                        'source': 'NOAA SWPC'
                    }
                    
        except Exception as e:
            print(f"Error fetching Kp: {e}")
            
        return None
    
    def fetch_kp_forecast(self) -> Optional[List]:
        """
        Fetch 3-day Kp forecast.
        
        Returns:
            List of forecast values
        """
        try:
            url = f"{self.base_url}/products/kp-index.json"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                # Skip header row
                if len(data) > 1:
                    forecasts = []
                    for row in data[1:]:
                        forecasts.append({
                            'date': row[0],
                            'kp': [float(x) for x in row[1:9]]
                        })
                    return forecasts
                    
        except Exception as e:
            print(f"Error fetching Kp forecast: {e}")
            
        return None
    
    def fetch_dst(self) -> Optional[Dict]:
        """
        Fetch Dst index (disturbance storm time).
        
        Returns:
            Dictionary with Dst value
        """
        try:
            url = f"{self.base_url}/products/dst.json"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if len(data) > 1:
                    latest = data[-1]
                    return {
                        'timestamp': latest[0],
                        'dst': float(latest[1]),
                        'source': 'NOAA SWPC'
                    }
                    
        except Exception as e:
            print(f"Error fetching Dst: {e}")
            
        return None
    
    def fetch_ae(self) -> Optional[Dict]:
        """
        Fetch Auroral Electrojet index.
        
        Returns:
            Dictionary with AE value
        """
        try:
            url = f"{self.base_url}/products/auroral-eelectrojet.json"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if len(data) > 1:
                    latest = data[-1]
                    return {
                        'timestamp': latest[0],
                        'ae': float(latest[1]),
                        'source': 'NOAA SWPC'
                    }
                    
        except Exception as e:
            print(f"Error fetching AE: {e}")
            
        return None
    
    def fetch_all_indices(self) -> Dict:
        """Fetch all geomagnetic indices."""
        kp = self.fetch_kp()
        dst = self.fetch_dst()
        ae = self.fetch_ae()
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'source': 'NOAA SWPC'
        }
        
        if kp:
            result['kp'] = kp['kp']
            result['kp_timestamp'] = kp['timestamp']
        
        if dst:
            result['dst'] = dst['dst']
            result['dst_timestamp'] = dst['timestamp']
        
        if ae:
            result['ae'] = ae['ae']
            result['ae_timestamp'] = ae['timestamp']
        
        return result
    
    def get_storm_scale(self, kp: float) -> str:
        """Get NOAA storm scale for Kp value."""
        if kp >= 8:
            return "G5 - Extreme"
        elif kp >= 7:
            return "G4 - Severe"
        elif kp >= 6:
            return "G3 - Strong"
        elif kp >= 5:
            return "G2 - Moderate"
        elif kp >= 4:
            return "G1 - Minor"
        else:
            return "Quiet"
    
    def get_alert_message(self, kp: float) -> str:
        """Get alert message based on Kp."""
        scale = self.get_storm_scale(kp)
        
        if kp >= 8:
            return "Extreme geomagnetic storm - Possible widespread voltage problems, satellite anomalies"
        elif kp >= 7:
            return "Severe storm - Possible power grid fluctuations, spacecraft charging"
        elif kp >= 6:
            return "Strong storm - Possible aurora visible to mid-latitudes"
        elif kp >= 5:
            return "Moderate storm - Possible weak power grid fluctuations"
        elif kp >= 4:
            return "Minor storm - Possible weak aurora at high latitudes"
        else:
            return "Quiet conditions"
    
    def __repr__(self) -> str:
        return "NOAASWPCClient()"
