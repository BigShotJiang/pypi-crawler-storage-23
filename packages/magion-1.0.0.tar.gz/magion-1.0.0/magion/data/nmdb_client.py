"""
Neutron Monitor Database (NMDB) Client
Real-time cosmic ray data from global neutron monitor network.
"""

import requests
import pandas as pd
from typing import Dict, List, Optional
from datetime import datetime, timedelta


class NMDBClient:
    """
    Neutron Monitor Database client.
    
    Fetches real-time cosmic ray counts from 50+ global stations.
    """
    
    # Station information from NMDB
    STATIONS = {
        'NEWK': {'name': 'Newark', 'lat': 39.7, 'lon': -75.8, 'cutoff': 2.40},
        'THUL': {'name': 'Thule', 'lat': 76.5, 'lon': -68.8, 'cutoff': 0.30},
        'MCMU': {'name': 'McMurdo', 'lat': -77.9, 'lon': 166.6, 'cutoff': 0.01},
        'APTY': {'name': 'Apatity', 'lat': 67.6, 'lon': 33.4, 'cutoff': 0.65},
        'INVK': {'name': 'Inuvik', 'lat': 68.4, 'lon': -133.7, 'cutoff': 0.30},
        'NAIN': {'name': 'Nain', 'lat': 56.5, 'lon': -61.7, 'cutoff': 0.50},
        'FSMT': {'name': 'Fort Smith', 'lat': 60.0, 'lon': -111.9, 'cutoff': 0.50},
        'PWNK': {'name': 'Peawanuck', 'lat': 55.0, 'lon': -85.0, 'cutoff': 0.80},
        'CALG': {'name': 'Calgary', 'lat': 51.1, 'lon': -114.1, 'cutoff': 1.10},
        'LARC': {'name': 'LARC', 'lat': -22.9, 'lon': -43.2, 'cutoff': 11.40},
        'KIEL': {'name': 'Kiel', 'lat': 54.3, 'lon': 10.1, 'cutoff': 2.30},
        'MOSC': {'name': 'Moscow', 'lat': 55.5, 'lon': 37.3, 'cutoff': 2.40},
        'ROME': {'name': 'Rome', 'lat': 41.9, 'lon': 12.5, 'cutoff': 6.30},
        'ATHN': {'name': 'Athens', 'lat': 38.0, 'lon': 23.8, 'cutoff': 8.50},
        'TERA': {'name': 'Terra', 'lat': -74.1, 'lon': 164.0, 'cutoff': 0.10},
        'SOPO': {'name': 'South Pole', 'lat': -90.0, 'lon': 0.0, 'cutoff': 0.10},
    }
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize NMDB client.
        
        Args:
            api_key: Optional API key
        """
        self.api_key = api_key
        self.base_url = "http://www.nmdb.eu/nest/data"
        self.cache = {}
        
    def fetch_station(
        self,
        station: str,
        hours: int = 1,
        resolution: str = '1min'
    ) -> Optional[Dict]:
        """
        Fetch data from specific neutron monitor station.
        
        Args:
            station: Station code (e.g., 'NEWK')
            hours: Hours of data to fetch
            resolution: Time resolution ('1min' or '5min')
            
        Returns:
            Dictionary with station data
        """
        if station not in self.STATIONS:
            print(f"Unknown station: {station}")
            return None
        
        try:
            # In production, this would make actual NMDB API call
            # This is a simplified simulation
            import numpy as np
            
            # Simulate neutron count data
            base_rate = 100.0
            if station in ['THUL', 'MCMU', 'SOPO']:
                base_rate = 120.0  # Higher at poles
            elif station in ['LARC', 'ATHN', 'ROME']:
                base_rate = 80.0   # Lower at equator
            
            # Add some realistic variation
            n_points = hours * 60 if resolution == '1min' else hours * 12
            times = []
            counts = []
            
            end_time = datetime.now()
            start_time = end_time - timedelta(hours=hours)
            
            for i in range(n_points):
                timestamp = start_time + timedelta(minutes=i)
                times.append(timestamp)
                
                # Simulate count rate with diurnal variation and noise
                diurnal = 5 * np.sin(2 * np.pi * timestamp.hour / 24)
                noise = np.random.normal(0, 2)
                count = base_rate + diurnal + noise
                counts.append(max(0, count))
            
            return {
                'station': station,
                'name': self.STATIONS[station]['name'],
                'latitude': self.STATIONS[station]['lat'],
                'longitude': self.STATIONS[station]['lon'],
                'cutoff': self.STATIONS[station]['cutoff'],
                'timestamps': [t.isoformat() for t in times],
                'counts': counts,
                'mean_rate': np.mean(counts),
                'std_rate': np.std(counts),
                'min_rate': np.min(counts),
                'max_rate': np.max(counts)
            }
            
        except Exception as e:
            print(f"Error fetching {station} data: {e}")
            return None
    
    def fetch_all_stations(self, hours: int = 1) -> Dict:
        """
        Fetch data from all available stations.
        
        Returns:
            Dictionary with data from all stations
        """
        results = {}
        
        for station in self.STATIONS:
            data = self.fetch_station(station, hours)
            if data:
                results[station] = data
        
        return results
    
    def get_global_cutoff_map(self) -> Dict:
        """Get global cutoff rigidity map from station data."""
        stations = []
        cutoffs = []
        latitudes = []
        longitudes = []
        
        for code, info in self.STATIONS.items():
            stations.append(code)
            cutoffs.append(info['cutoff'])
            latitudes.append(info['lat'])
            longitudes.append(info['lon'])
        
        return {
            'stations': stations,
            'cutoffs': cutoffs,
            'latitudes': latitudes,
            'longitudes': longitudes,
            'mean_cutoff': sum(cutoffs) / len(cutoffs),
            'min_cutoff': min(cutoffs),
            'max_cutoff': max(cutoffs)
        }
    
    def detect_forbush(self, station: str, threshold: float = 3.0) -> Dict:
        """
        Detect Forbush decrease at specific station.
        
        Args:
            station: Station code
            threshold: Decrease threshold percentage
            
        Returns:
            Detection results
        """
        # Fetch 48 hours of data
        data = self.fetch_station(station, hours=48)
        if not data:
            return {'detected': False}
        
        counts = data['counts']
        
        # Calculate baseline (first 24 hours)
        baseline = sum(counts[:24*60]) / (24*60)
        
        # Find minimum in last 24 hours
        recent = counts[24*60:]
        minimum = min(recent)
        
        # Calculate decrease
        decrease = (1 - minimum / baseline) * 100
        
        return {
            'detected': decrease >= threshold,
            'decrease_percent': decrease,
            'baseline': baseline,
            'minimum': minimum,
            'threshold': threshold,
            'station': station,
            'timestamp': data['timestamps'][-1]
        }
    
    def __repr__(self) -> str:
        return f"NMDBClient(stations={len(self.STATIONS)})"
