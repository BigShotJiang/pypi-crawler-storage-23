"""
Data Cache Module
Caching layer for frequently accessed space weather data.
"""

import time
import json
from typing import Dict, Any, Optional
from datetime import datetime, timedelta


class DataCache:
    """
    Time-based cache for space weather data.
    
    Reduces API calls and improves performance.
    """
    
    def __init__(self, ttl_seconds: int = 300):
        """
        Initialize cache.
        
        Args:
            ttl_seconds: Time-to-live in seconds
        """
        self.ttl = ttl_seconds
        self.cache = {}
        self.timestamps = {}
        self.hits = 0
        self.misses = 0
        
    def get(self, key: str) -> Optional[Any]:
        """
        Get value from cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if expired/missing
        """
        if key in self.cache:
            timestamp = self.timestamps.get(key, 0)
            if time.time() - timestamp < self.ttl:
                self.hits += 1
                return self.cache[key]
            else:
                # Expired
                del self.cache[key]
                del self.timestamps[key]
        
        self.misses += 1
        return None
    
    def set(self, key: str, value: Any) -> None:
        """
        Store value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
        """
        self.cache[key] = value
        self.timestamps[key] = time.time()
    
    def clear(self) -> None:
        """Clear all cache entries."""
        self.cache.clear()
        self.timestamps.clear()
        self.hits = 0
        self.misses = 0
    
    def remove(self, key: str) -> None:
        """Remove specific key from cache."""
        if key in self.cache:
            del self.cache[key]
        if key in self.timestamps:
            del self.timestamps[key]
    
    def get_stats(self) -> Dict:
        """Get cache statistics."""
        total = self.hits + self.misses
        hit_rate = (self.hits / total * 100) if total > 0 else 0
        
        return {
            'size': len(self.cache),
            'hits': self.hits,
            'misses': self.misses,
            'hit_rate': hit_rate,
            'ttl_seconds': self.ttl,
            'oldest': min(self.timestamps.values()) if self.timestamps else None,
            'newest': max(self.timestamps.values()) if self.timestamps else None
        }
    
    def get_keys(self) -> list:
        """Get all cache keys."""
        return list(self.cache.keys())
    
    def is_fresh(self, key: str) -> bool:
        """Check if key is fresh (not expired)."""
        if key in self.timestamps:
            return time.time() - self.timestamps[key] < self.ttl
        return False
    
    def get_age(self, key: str) -> Optional[float]:
        """Get age of cache entry in seconds."""
        if key in self.timestamps:
            return time.time() - self.timestamps[key]
        return None
    
    def expire_old(self) -> int:
        """Remove expired entries. Returns count removed."""
        now = time.time()
        expired = []
        
        for key, timestamp in self.timestamps.items():
            if now - timestamp >= self.ttl:
                expired.append(key)
        
        for key in expired:
            del self.cache[key]
            del self.timestamps[key]
        
        return len(expired)
    
    def to_dict(self) -> Dict:
        """Convert cache to serializable dictionary."""
        return {
            'ttl': self.ttl,
            'entries': {
                key: {
                    'value': value,
                    'timestamp': self.timestamps.get(key)
                }
                for key, value in self.cache.items()
            },
            'stats': self.get_stats()
        }
    
    def save(self, filename: str) -> None:
        """Save cache to file."""
        with open(filename, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
    
    def load(self, filename: str) -> None:
        """Load cache from file."""
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
                self.ttl = data.get('ttl', self.ttl)
                for key, entry in data.get('entries', {}).items():
                    self.cache[key] = entry['value']
                    self.timestamps[key] = entry['timestamp']
        except FileNotFoundError:
            pass
    
    def __repr__(self) -> str:
        stats = self.get_stats()
        return f"DataCache(size={stats['size']}, hit_rate={stats['hit_rate']:.1f}%)"
