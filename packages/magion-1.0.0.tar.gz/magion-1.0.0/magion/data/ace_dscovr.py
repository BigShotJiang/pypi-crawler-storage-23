"""
ACE and DSCOVR Satellite Data Clients
Real-time solar wind and IMF data from L1 monitors.
"""

import requests
import time
from typing import Dict, Optional
from datetime import datetime


class ACEClient:
    """
    NASA ACE satellite data client.
    
    Provides real-time solar wind plasma and magnetic field data.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize ACE client.
        
        Args:
            api_key: Optional API key for authenticated access
        """
        self.api_key = api_key
        self.base_url = "https://services.swpc.noaa.gov/products/solar-wind"
        self.last_data = None
        self.last_update = None
        
    def fetch_plasma(self) -> Optional[Dict]:
        """
        Fetch solar wind plasma data.
        
        Returns:
            Dictionary with density, velocity, temperature
        """
        try:
            url = f"{self.base_url}/plasma.json"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if len(data) > 1:
                    # Skip header row
                    latest = data[-1]
                    self.last_data = {
                        'timestamp': latest[0],
                        'density': float(latest[1]),  # cm⁻³
                        'speed': float(latest[2]),    # km/s
                        'temperature': float(latest[3]), # K
                        'source': 'ACE'
                    }
                    self.last_update = datetime.now()
                    return self.last_data
                    
        except Exception as e:
            print(f"Error fetching ACE plasma data: {e}")
            
        return None
    
    def fetch_magnetic(self) -> Optional[Dict]:
        """
        Fetch interplanetary magnetic field data.
        
        Returns:
            Dictionary with Bx, By, Bz, Btotal
        """
        try:
            url = f"{self.base_url}/mag.json"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if len(data) > 1:
                    latest = data[-1]
                    return {
                        'timestamp': latest[0],
                        'bx': float(latest[1]),   # nT
                        'by': float(latest[2]),   # nT
                        'bz': float(latest[3]),   # nT
                        'bt': float(latest[4]),   # nT
                        'source': 'ACE'
                    }
                    
        except Exception as e:
            print(f"Error fetching ACE magnetic data: {e}")
            
        return None
    
    def fetch_all(self) -> Dict:
        """Fetch both plasma and magnetic data."""
        plasma = self.fetch_plasma()
        magnetic = self.fetch_magnetic()
        
        result = {'source': 'ACE', 'timestamp': datetime.now().isoformat()}
        
        if plasma:
            result.update(plasma)
        if magnetic:
            result.update(magnetic)
            
        return result


class DSCOVRClient:
    """
    NOAA DSCOVR satellite data client.
    
    Primary real-time solar wind monitor at L1.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize DSCOVR client.
        
        Args:
            api_key: Optional API key
        """
        self.api_key = api_key
        self.base_url = "https://services.swpc.noaa.gov/products/solar-wind"
        self.last_data = None
        
    def fetch_plasma(self) -> Optional[Dict]:
        """Fetch plasma data from DSCOVR."""
        try:
            url = f"{self.base_url}/dscovr-plasma.json"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if len(data) > 1:
                    latest = data[-1]
                    return {
                        'timestamp': latest[0],
                        'density': float(latest[1]),
                        'speed': float(latest[2]),
                        'temperature': float(latest[3]),
                        'source': 'DSCOVR'
                    }
                    
        except Exception as e:
            print(f"Error fetching DSCOVR plasma: {e}")
            
        return None
    
    def fetch_magnetic(self) -> Optional[Dict]:
        """Fetch magnetic field data from DSCOVR."""
        try:
            url = f"{self.base_url}/dscovr-mag.json"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if len(data) > 1:
                    latest = data[-1]
                    return {
                        'timestamp': latest[0],
                        'bx': float(latest[1]),
                        'by': float(latest[2]),
                        'bz': float(latest[3]),
                        'bt': float(latest[4]),
                        'source': 'DSCOVR'
                    }
                    
        except Exception as e:
            print(f"Error fetching DSCOVR magnetic: {e}")
            
        return None
    
    def fetch_all(self) -> Dict:
        """Fetch all DSCOVR data."""
        plasma = self.fetch_plasma()
        magnetic = self.fetch_magnetic()
        
        result = {'source': 'DSCOVR', 'timestamp': datetime.now().isoformat()}
        
        if plasma:
            result.update(plasma)
        if magnetic:
            result.update(magnetic)
            
        return result
