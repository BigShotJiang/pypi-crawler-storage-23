"""
Data Ingestion Pipeline
Real-time data acquisition from multiple space weather sources.
"""

import time
import json
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import numpy as np


class DataIngestionPipeline:
    """
    Multi-threaded data ingestion from space weather sources.
    
    Sources:
    - ACE/DSCOVR: Solar wind plasma and IMF
    - NMDB: Neutron monitor counts
    - NOAA SWPC: Geomagnetic indices
    - IGS: TEC maps
    """
    
    def __init__(self, sources: List[str]):
        """
        Initialize data ingestion pipeline.
        
        Args:
            sources: List of data sources to monitor
        """
        self.sources = sources
        self.data_cache = {}
        self.last_update = {}
        self.update_intervals = {
            'ACE': 60,      # seconds
            'DSCOVR': 60,
            'NMDB': 300,
            'NOAA_SWPC': 180,
            'IGS': 900
        }
        
    def fetch_latest(self) -> Dict:
        """
        Fetch latest data from all sources.
        
        Returns:
            Dictionary with latest data from each source
        """
        data = {
            'timestamp': datetime.now().isoformat(),
            'sources': {}
        }
        
        for source in self.sources:
            source_data = self._fetch_source(source)
            if source_data:
                data['sources'][source] = source_data
                data.update(source_data)  # Flatten for easy access
        
        # Add commonly used parameters at top level
        self._flatten_parameters(data)
        
        return data
    
    def _fetch_source(self, source: str) -> Optional[Dict]:
        """Fetch data from specific source."""
        # In production, this would make actual API calls
        # This is a simplified version with simulated data
        
        if source == 'ACE' or source == 'DSCOVR':
            return self._simulate_solar_wind()
        elif source == 'NMDB':
            return self._simulate_neutron_monitor()
        elif source == 'NOAA_SWPC':
            return self._simulate_geomagnetic()
        elif source == 'IGS':
            return self._simulate_tec()
        
        return None
    
    def _simulate_solar_wind(self) -> Dict:
        """Simulate solar wind data (ACE/DSCOVR)."""
        return {
            'density': np.random.normal(5, 2),
            'velocity': np.random.normal(400, 50),
            'temperature': np.random.normal(100000, 20000),
            'bz': np.random.normal(0, 3),
            'by': np.random.normal(0, 3),
            'bt': np.random.normal(5, 2),
            'pressure': 1.67e-6 * np.random.normal(5, 2) * (400/1000)**2
        }
    
    def _simulate_neutron_monitor(self) -> Dict:
        """Simulate neutron monitor data."""
        stations = ['NEWK', 'THUL', 'MCMU', 'APTY', 'KIEL']
        counts = {}
        
        for station in stations:
            # Normal counts around 100
            counts[station] = np.random.normal(100, 5)
        
        return {
            'counts': counts,
            'stations': stations
        }
    
    def _simulate_geomagnetic(self) -> Dict:
        """Simulate geomagnetic indices."""
        return {
            'kp': np.random.randint(0, 4),
            'kp_3hour': [np.random.randint(0, 4) for _ in range(8)],
            'dst': np.random.normal(-10, 10),
            'ap': np.random.randint(0, 20),
            'ae': np.random.normal(100, 50)
        }
    
    def _simulate_tec(self) -> Dict:
        """Simulate TEC data."""
        return {
            'global_mean': np.random.normal(15, 5),
            'polar_mean': np.random.normal(5, 2),
            'equatorial_mean': np.random.normal(25, 8),
            'maps_available': True
        }
    
    def _flatten_parameters(self, data: Dict) -> None:
        """Flatten commonly used parameters to top level."""
        sources = data.get('sources', {})
        
        # Solar wind parameters
        if 'ACE' in sources:
            ace = sources['ACE']
            data['density'] = ace.get('density')
            data['velocity'] = ace.get('velocity')
            data['bz'] = ace.get('bz')
            data['by'] = ace.get('by')
        
        # Geomagnetic indices
        if 'NOAA_SWPC' in sources:
            noaa = sources['NOAA_SWPC']
            data['kp'] = noaa.get('kp')
            data['dst'] = noaa.get('dst')
        
        # Neutron monitor (use first station)
        if 'NMDB' in sources:
            nmdb = sources['NMDB']
            counts = nmdb.get('counts', {})
            if counts:
                first_station = next(iter(counts))
                data['neutron_count'] = counts[first_station]
    
    def fetch_historical(self, hours: int = 24) -> Dict:
        """
        Fetch historical data for training/analysis.
        
        Args:
            hours: Hours of historical data
            
        Returns:
            Dictionary with historical time series
        """
        # Simulate historical data
        n_points = hours * 60  # 1-minute resolution
        
        historical = {
            'timestamps': [],
            'sei_history': [],
            'density': [],
            'velocity': [],
            'bz': [],
            'kp': []
        }
        
        base_time = datetime.now() - timedelta(hours=hours)
        
        for i in range(n_points):
            timestamp = base_time + timedelta(minutes=i)
            historical['timestamps'].append(timestamp.isoformat())
            
            # Simulate time series with some structure
            historical['density'].append(5 + 2 * np.sin(i/60) + np.random.normal(0, 0.5))
            historical['velocity'].append(400 + 30 * np.sin(i/120) + np.random.normal(0, 10))
            historical['bz'].append(0 + 2 * np.sin(i/180) + np.random.normal(0, 1))
            historical['kp'].append(2 + 0.5 * np.sin(i/360) + np.random.normal(0, 0.3))
            
            # Simulate SEI
            sei = 85 - 10 * np.sin(i/120) + np.random.normal(0, 2)
            historical['sei_history'].append(np.clip(sei, 0, 100))
        
        return historical
    
    def get_magnetic_field(self) -> Dict:
        """Get current magnetic field configuration."""
        # Simplified magnetic field model
        return {
            'dipole_moment': 8e25,  # G·cm³
            'tilt': 11.5,  # degrees
            'field_at_equator': 3.12e-5,  # T
            'model': 'dipole'
        }
    
    def status(self) -> Dict:
        """Get status of all data sources."""
        status = {}
        now = time.time()
        
        for source in self.sources:
            last = self.last_update.get(source, 0)
            interval = self.update_intervals.get(source, 300)
            
            status[source] = {
                'active': (now - last) < interval * 2,
                'last_update': datetime.fromtimestamp(last).isoformat() if last else None,
                'update_interval': interval,
                'data_in_cache': source in self.data_cache
            }
        
        return status
    
    def __repr__(self) -> str:
        return f"DataIngestionPipeline(sources={self.sources})"
