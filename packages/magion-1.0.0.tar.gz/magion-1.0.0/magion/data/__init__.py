"""
MAGION Data Ingestion Module
Real-time data acquisition from multiple space weather sources.
"""

from magion.data.ingestion import DataIngestionPipeline
from magion.data.ace_dscovr import ACEClient, DSCOVRClient
from magion.data.nmdb_client import NMDBClient
from magion.data.noaa_swpc import NOAASWPCClient
from magion.data.quality_control import QualityControl
from magion.data.cache import DataCache

__all__ = [
    'DataIngestionPipeline',
    'ACEClient',
    'DSCOVRClient',
    'NMDBClient',
    'NOAASWPCClient',
    'QualityControl',
    'DataCache',
]
