# 🧲 MAGION CODE OF CONDUCT

## Contributor Covenant Code of Conduct v2.1

### Our Pledge

We as members, contributors, and leaders pledge to make participation in our
community a harassment-free experience for everyone.

---

### Our Standards

Examples of behavior that contributes to a positive environment:

* 🧠 **Demonstrating empathy and kindness** toward other people
* 🧲 **Respecting different opinions, viewpoints, and experiences**
* 🤝 **Giving and gracefully accepting constructive feedback**
* 🌍 **Prioritizing ethical research practices**
* 🛰️ **Acknowledging open data contributions from global monitoring networks**

Examples of unacceptable behavior:

* ❌ The use of sexualized language or imagery
* ❌ Trolling, insulting or derogatory comments
* ❌ Public or private harassment
* ❌ Publishing others' private information without permission
* ❌ Data fabrication or manipulation
* ❌ Misrepresenting forecast accuracy or validation results

---

### Special Considerations for MAGION Research

As this project involves space weather monitoring and operational forecasting:

* 🛰️ **Data attribution** - All data sources (NASA, NOAA, NMDB, IGS) must be properly cited
* 🔐 **Operational responsibility** - Forecasts must clearly communicate uncertainty bounds
* 📋 **Validation transparency** - All performance metrics must be reproducible
* 🏷️ **Proper acknowledgment** of all data providers and station operators
* 🌎 **Global cooperation** - Space weather affects all nations equally

---

### Enforcement

Instances of abusive behavior may be reported to:

**Email:** conduct@magion.space  
**Principal Investigator:** gitdeeper@gmail.com

---

### Contact

For Code of Conduct issues: conduct@magion.space  
For data attribution: data@magion.space  
For forecast inquiries: forecast@magion.space  
For general inquiries: gitdeeper@gmail.com

---

**MAGION** 🧲 *The magnetosphere has protected Earth for 3.5 billion years. MAGION ensures we know when it falters.*

*Last Updated: March 2026*
