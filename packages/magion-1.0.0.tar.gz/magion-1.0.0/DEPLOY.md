# 🧲 MAGION DEPLOYMENT GUIDE

This guide covers deployment options for the MAGION framework, including the live dashboard, API services, documentation, and real-time data pipelines.

---

## Quick Deployments

### Netlify (Dashboard)

The MAGION interactive dashboard is pre-configured for Netlify deployment at [magion.space](https://magion.space).

#### Automatic Deployment

1. Connect your Git repository to Netlify
2. Use these settings:
   - Build command: `cd dashboard && npm run build` (if using Node) or leave empty
   - Publish directory: `dashboard/dist` or `dashboard`
   - Environment variables: none required

3. Or use the `netlify.toml` configuration:

```toml
[build]
  publish = "dashboard"

[build.environment]
  PYTHON_VERSION = "3.11"
  NODE_VERSION = "18"

[[redirects]]
  from = "/api/*"
  to = "https://magion.space/api/:splat"
  status = 200
  force = true

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"
    Access-Control-Allow-Origin = "https://magion.space"
```

Manual Deployment

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod --dir=dashboard
```

Live dashboard: https://magion.space
API endpoint: https://magion.space/api

---

ReadTheDocs (Documentation)

Deploy technical documentation to ReadTheDocs.

Configuration

1. Connect your Git repository to readthedocs.org
2. Use the .readthedocs.yaml configuration in this repository
3. Build documentation automatically on push

Documentation: https://magion.readthedocs.io

---

PyPI (Python Package)

Deploy the core MAGION package to PyPI.

Preparation

```bash
# Install build tools
pip install build twine

# Update version in setup.py/pyproject.toml
# Version: 1.0.0

# Create distribution files
python -m build
```

Upload to PyPI

```bash
# Upload to production PyPI
twine upload dist/*

# Install
pip install magion
```

PyPI package: https://pypi.org/project/magion

---

Docker Deployment

Build Image

```dockerfile
# Dockerfile
FROM python:3.10-slim

LABEL maintainer="gitdeeper@gmail.com"
LABEL version="1.0.0"
LABEL description="MAGION - Magnetospheric Ionization & Galactic Interaction Network"

ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    MAGION_HOME=/opt/magion \
    MAGION_CONFIG=/etc/magion/config.yaml \
    TZ=UTC

RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc \
    g++ \
    libgomp1 \
    curl \
    && rm -rf /var/lib/apt/lists/*

RUN useradd -m -u 1000 -s /bin/bash magion && \
    mkdir -p /opt/magion && \
    mkdir -p /etc/magion && \
    mkdir -p /data/solar_wind && \
    mkdir -p /data/neutron && \
    mkdir -p /data/tec && \
    mkdir -p /data/results && \
    chown -R magion:magion /opt/magion /etc/magion /data

USER magion
WORKDIR /opt/magion

COPY --chown=magion:magion requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

COPY --chown=magion:magion . .

RUN pip install --user -e .

EXPOSE 8000 8501 9090

CMD ["magion", "serve", "--all"]
```

Build and Run

```bash
# Build image
docker build -t magion:1.0.0 .

# Run container
docker run -d \
  --name magion-prod \
  -p 8000:8000 \
  -p 8501:8501 \
  -p 9090:9090 \
  -v /host/data:/data \
  -v /host/config:/etc/magion \
  -e MAGION_CONFIG=/etc/magion/config.yaml \
  -e NOAA_SWPC_KEY=your_key_here \
  -e NASA_ACE_TOKEN=your_token_here \
  -e NMDB_API_KEY=your_key_here \
  --restart unless-stopped \
  magion:1.0.0
```

Docker Compose

Use the provided docker-compose.yml for full-stack deployment:

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

---

Configuration

Production Configuration

```yaml
# config/magion.prod.yaml
# MAGION Production Configuration

version: 1.0
environment: production

server:
  host: 0.0.0.0
  api_port: 8000
  dashboard_port: 8501
  metrics_port: 9090
  workers: 4
  timeout: 120

database:
  host: postgres
  port: 5432
  name: magion
  user: magion_user
  password: ${DB_PASSWORD}
  pool_size: 20
  hypertable_chunk: 7  # days

redis:
  host: redis
  port: 6379
  db: 0
  maxmemory: 512mb

monitoring:
  sei_update_interval: 60  # seconds
  forecast_horizon: 6  # hours
  forecast_model: lstm
  ensemble_members: 10
  metrics_enabled: true

security:
  jwt_secret: ${JWT_SECRET}
  jwt_expiry_hours: 24
  rate_limit: 100/minute
  cors_origins:
    - https://magion.space
    - https://magion.readthedocs.io
    - https://magion.netlify.app

api:
  public_url: https://magion.space/api
  docs_url: https://magion.readthedocs.io/api
  version: v1

external_apis:
  noaa_swpc:
    solar_wind: https://services.swpc.noaa.gov/products/solar-wind/plasma.json
    magnetometer: https://services.swpc.noaa.gov/products/solar-wind/mag.json
    kp: https://services.swpc.noaa.gov/products/kp-index.json
    api_key: ${NOAA_SWPC_KEY}
    
  nasa_ace:
    url: https://iswa.gsfc.nasa.gov/IswaSystemWebApp/
    token: ${NASA_ACE_TOKEN}
    endpoints:
      realtime: /iSWACygnetStreamer?timestamp=latest
    
  nmdb:
    url: http://www.nmdb.eu/nest/data/
    api_key: ${NMDB_API_KEY}
    stations: 52
    
  igs_tec:
    url: https://cddis.nasa.gov/archive/gnss/data/
    key: ${IGS_TEC_KEY}
    resolution: "2.5x5"
    interval: 15  # minutes

data:
  solar_wind_dir: /data/solar_wind
  neutron_dir: /data/neutron
  tec_dir: /data/tec
  results_dir: /data/results
  max_file_size: 2GB
  retention_days:
    raw: 90
    hourly: 365
    daily: 730
    monthly: permanent

alerts:
  levels:
    critical: 39
    severe: 59
    storm: 79
    unsettled: 94
  notification_endpoints:
    email: alerts@magion.space
    webhook: https://hooks.slack.com/services/...
    pagerduty: ${PAGERDUTY_KEY}
```

---

Real-Time Data Pipeline

Data Sources Configuration

```yaml
# config/data_sources.yaml
sources:
  ace:
    type: rest_api
    url: https://services.swpc.noaa.gov/products/solar-wind/plasma.json
    interval: 60  # seconds
    format: json
    fields:
      - time
      - density
      - speed
      - temperature
      
  dscovr:
    type: rest_api
    url: https://services.swpc.noaa.gov/products/solar-wind/mag.json
    interval: 60
    format: json
    fields:
      - time
      - bx
      - by
      - bz
      - bt
      
  nmdb:
    type: ftp
    url: ftp://ftp.nmdb.eu/pub/data/
    interval: 300
    stations: all
    format: csv
    
  igs_tec:
    type: http
    url: https://cddis.nasa.gov/archive/gnss/data/
    interval: 900
    format: ionex
```

Data Ingestion Service

```bash
# Start data ingestion service
magion ingest --config config/data_sources.yaml --daemon

# Monitor ingestion status
magion status --sources all

# Force update
magion update --source ace --force
```

---

Backup & Recovery

Automated Backup Script

```bash
#!/bin/bash
# backup.sh - MAGION Backup Script

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/magion"

# Create backup directory
mkdir -p $BACKUP_DIR

# Database backup (TimescaleDB)
pg_dump -h postgres -U magion_user magion | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# Solar wind data backup
tar -czf $BACKUP_DIR/solar_wind_$DATE.tar.gz /data/solar_wind

# Neutron monitor data backup
tar -czf $BACKUP_DIR/neutron_$DATE.tar.gz /data/neutron

# TEC maps backup
tar -czf $BACKUP_DIR/tec_$DATE.tar.gz /data/tec

# Configuration backup
tar -czf $BACKUP_DIR/config_$DATE.tar.gz /etc/magion

# SEI results backup
tar -czf $BACKUP_DIR/results_$DATE.tar.gz /data/results

# Clean old backups (keep 30 days)
find $BACKUP_DIR -type f -mtime +30 -delete

# Upload to cloud (optional)
# aws s3 sync $BACKUP_DIR s3://magion-backups/

echo "Backup completed: $DATE"
```

Cron Setup

```bash
# Daily backup at 2 AM
0 2 * * * /usr/local/bin/magion-backup.sh

# Hourly database snapshot
0 * * * * /usr/local/bin/magion-snapshot.sh
```

Recovery

```bash
# Restore database
gunzip -c db_20260304_020000.sql.gz | psql -h postgres -U magion_user magion

# Restore data files
tar -xzf solar_wind_20260304_020000.tar.gz -C /data
```

---

Monitoring

Prometheus Configuration

```yaml
# prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'magion-api'
    static_configs:
      - targets: ['api:8000']
    metrics_path: /metrics
    scrape_interval: 10s
    
  - job_name: 'magion-dashboard'
    static_configs:
      - targets: ['dashboard:8501']
    metrics_path: /metrics
    
  - job_name: 'magion-worker'
    static_configs:
      - targets: ['worker:9090']
    
  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres:9187']
    
  - job_name: 'redis'
    static_configs:
      - targets: ['redis:9121']
```

Grafana Dashboard

Import the MAGION dashboard template (ID: 12345) to visualize:

· Real-time SEI with 1-minute resolution
· 6-hour SEI forecast with uncertainty bounds
· Magnetopause standoff distance
· Neutron monitor count rates (52 stations)
· Rigidity cutoff maps (global)
· TEC anomalies during storms
· Forbush decrease detection
· Alert status (5-tier)
· System health metrics
· Data ingestion latency
· Forecast accuracy tracking

Alerting Rules

```yaml
# alerts/magion.rules.yml
groups:
  - name: magion_sei
    rules:
      - alert: SEICritical
        expr: sei < 40
        for: 5m
        annotations:
          summary: "SEI in CRITICAL range (<40%)"
          description: "Magnetospheric shield severely degraded"
          
      - alert: SEISevere
        expr: sei < 60 and sei >= 40
        for: 10m
        annotations:
          summary: "SEI in SEVERE range (40-60%)"
          
      - alert: MagnetopauseCompression
        expr: rs < 7.0
        for: 5m
        annotations:
          summary: "Magnetopause compressed to <7 Rₑ"
          
      - alert: ForbushDetected
        expr: fd > 5
        for: 15m
        annotations:
          summary: "Forbush decrease >5% detected"
```

---

Scaling

Horizontal Scaling

```yaml
# docker-compose.scale.yml
version: '3.8'

services:
  api:
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '2'
          memory: 4G
          
  worker:
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '4'
          memory: 8G
          
  redis:
    image: redis:7-alpine
    command: redis-server --cluster-enabled yes
```

Load Balancing

```nginx
# nginx.conf
upstream magion_api {
    least_conn;
    server api1:8000;
    server api2:8000;
    server api3:8000;
}

upstream magion_dashboard {
    server dashboard1:8501;
    server dashboard2:8501;
}

server {
    listen 443 ssl;
    server_name magion.space;
    
    location /api/ {
        proxy_pass http://magion_api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    location / {
        proxy_pass http://magion_dashboard/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

Quick Reference

```bash
# Netlify Dashboard
https://magion.space
https://magion.space/api

# PyPI Package
pip install magion

# Docker
docker pull gitlab.com/gitdeeper8/magion:latest

# Documentation
https://magion.readthedocs.io

# Source Code
https://gitlab.com/gitdeeper8/MAGION
https://github.com/gitdeeper8/MAGION

# Data Sources
https://swpc.noaa.gov
http://www.nmdb.eu
https://igs.org/maps
https://intermagnet.org
```

---

Support

For deployment assistance:

· Dashboard: https://magion.space
· Documentation: https://magion.readthedocs.io
· Issues: https://gitlab.com/gitdeeper8/MAGION/-/issues
· Email: deploy@magion.space
· Principal Investigator: gitdeeper@gmail.com

---

🧲 The magnetosphere has protected Earth for 3.5 billion years. MAGION ensures we know when it falters.

DOI: 10.5281/zenodo.MAGION.2026
