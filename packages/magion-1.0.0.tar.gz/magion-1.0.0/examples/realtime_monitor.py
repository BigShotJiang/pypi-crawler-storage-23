#!/usr/bin/env python
"""
Real-time monitoring example.
Simulates continuous SEI monitoring with alerts.
"""

import time
import random
from datetime import datetime
from magion.core.shield_monitor import ShieldEfficiencyMonitor
from magion.alerts.classifier import AlertClassifier


class RealtimeMonitorDemo:
    """Demo of real-time SEI monitoring."""
    
    def __init__(self):
        self.monitor = ShieldEfficiencyMonitor(
            data_sources=['ACE', 'DSCOVR', 'NMDB'],
            update_interval=1
        )
        self.classifier = AlertClassifier()
        self.running = False
        
    def simulate_data(self):
        """Simulate real-time data for demo."""
        # Generate realistic SEI values
        base = 85
        variation = random.uniform(-5, 5)
        
        # Occasionally simulate storm
        if random.random() < 0.05:  # 5% chance
            sei = random.uniform(40, 60)
        else:
            sei = base + variation
            
        return max(0, min(100, sei))
    
    def run(self, duration_seconds=60):
        """Run monitoring demo."""
        print("=" * 60)
        print("MAGION - Real-Time Monitoring Demo")
        print("=" * 60)
        print(f"Duration: {duration_seconds} seconds")
        print("Press Ctrl+C to stop\n")
        
        self.running = True
        start_time = time.time()
        alerts_sent = 0
        
        try:
            while self.running and (time.time() - start_time) < duration_seconds:
                # Simulate SEI value
                sei = self.simulate_data()
                
                # Get alert level
                level = self.classifier.classify(sei)
                color = self.classifier.get_color(level)
                
                # Current time
                now = datetime.now().strftime("%H:%M:%S")
                
                # Display
                print(f"[{now}] SEI: {sei:5.1f}% | {color} {level:12s}", end="")
                
                # Check for alerts
                if self.classifier.should_alert(sei):
                    alerts_sent += 1
                    print(" ⚠️  ALERT TRIGGERED")
                    
                    # Show impact
                    impact = self.classifier.get_impact(level)
                    print(f"      Impact: {impact}")
                    
                    # Show recommendation
                    rec = self.classifier.get_recommendation(level)
                    print(f"      Action: {rec}")
                else:
                    print()
                
                # Wait for next update
                time.sleep(1)
                
        except KeyboardInterrupt:
            print("\n\nMonitoring stopped by user")
            
        finally:
            self.running = False
            
        # Summary
        elapsed = time.time() - start_time
        print("\n" + "=" * 60)
        print("Monitoring Summary")
        print("=" * 60)
        print(f"Duration: {elapsed:.1f} seconds")
        print(f"Alerts triggered: {alerts_sent}")
        
        # Statistics
        stats = self.classifier.get_statistics(hours=24)
        print(f"\nAlert Statistics (last 24h):")
        for level, count in stats['by_level'].items():
            if count > 0:
                print(f"  {level}: {count}")


def main():
    """Run the demo."""
    demo = RealtimeMonitorDemo()
    demo.run(duration_seconds=30)


if __name__ == "__main__":
    main()
