#!/usr/bin/env python
"""
Basic usage example for MAGION framework.
"""

import time
from magion import ShieldEfficiencyMonitor
from magion.core.sei_calculator import SEICalculator
from magion.parameters import (
    MagnetopauseStandoff,
    CosmicRayFlux,
    GeomagneticIndex
)


def main():
    """Run basic MAGION example."""
    print("=" * 60)
    print("MAGION - Basic Usage Example")
    print("=" * 60)
    
    # Initialize monitor
    monitor = ShieldEfficiencyMonitor(
        data_sources=['ACE', 'NMDB', 'NOAA_SWPC'],
        update_interval=60
    )
    
    print(f"\n✅ Monitor initialized: {monitor}")
    
    # Get current SEI
    print("\n📊 Fetching current SEI...")
    sei_data = monitor.get_current_sei()
    
    print(f"   SEI Value: {sei_data['value']:.1f}%")
    print(f"   Alert Level: {sei_data['alert_level']}")
    print(f"   Timestamp: {sei_data['timestamp']}")
    
    # Show parameter breakdown
    print("\n📈 Parameter Breakdown:")
    for param, value in sei_data['parameters'].items():
        print(f"   {param.upper()}: {value:.3f}")
    
    # Get forecast
    print("\n🔮 Generating 6-hour forecast...")
    forecast = monitor.forecast_sei(hours=6)
    
    print("   Forecast values:")
    for i, val in enumerate(forecast['forecast']):
        print(f"     Hour {i+1}: {val:.1f}% ({forecast['lower_bound'][i]:.1f}-{forecast['upper_bound'][i]:.1f})")
    
    # Check for precursors
    if forecast.get('precursors'):
        print("\n⚠️  Precursor Patterns Detected:")
        for p in forecast['precursors']:
            print(f"   • {p['description']}")
            print(f"     Probability: {p['probability']*100:.0f}%")
            print(f"     Lead time: {p['lead_time_hours']} hours")
    
    # Manual parameter calculation example
    print("\n🧮 Manual Parameter Calculation:")
    
    # Magnetopause standoff
    rs = MagnetopauseStandoff()
    data = {'density': 5.0, 'velocity': 400.0, 'bz': 0.0}
    rs_score = rs.compute(data)
    print(f"   Rs (Magnetopause): {rs_score:.3f}")
    
    # Neutron monitor flux
    nmf = CosmicRayFlux('NEWK')
    data = {'neutron_counts': {'NEWK': 100}}
    nmf_score = nmf.compute(data)
    print(f"   Nmf (Neutrons): {nmf_score:.3f}")
    
    # Kp index
    kp = GeomagneticIndex()
    data = {'kp': 2}
    kp_score = kp.compute(data)
    print(f"   Kp (Geomagnetic): {kp_score:.3f}")
    
    # Calculate composite SEI
    calculator = SEICalculator()
    scores = {
        'rs': rs_score,
        'nmf': nmf_score,
        'kp': kp_score,
        'np': 0.95,
        'rc': 0.90,
        'tec': 0.92,
        'va': 0.88,
        'fd': 1.00
    }
    
    sei = calculator.compute(scores)
    print(f"\n🎯 Manual SEI Calculation: {sei:.1f}%")
    
    print("\n" + "=" * 60)
    print("Example completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    main()
