"""
Unit tests for SEI forecaster module.
"""

import unittest
import numpy as np
from datetime import datetime, timedelta
from magion.core.forecaster import SEIForecaster


class TestSEIForecaster(unittest.TestCase):
    """Test forecasting capabilities."""
    
    def setUp(self):
        self.forecaster = SEIForecaster()
        
    def test_prediction(self):
        """Test basic prediction."""
        # Create sample historical data
        historical = {
            'sei_history': [85, 84, 83, 82, 81, 80],
            'density': [5.0, 5.2, 5.4, 5.6, 5.8, 6.0],
            'velocity': [400, 405, 410, 415, 420, 425],
            'bz': [0, -1, -2, -3, -4, -5],
            'kp': [2, 2, 3, 3, 4, 4]
        }
        
        forecast = self.forecaster.predict(historical, hours=6)
        
        self.assertIn('forecast', forecast)
        self.assertIn('lower_bound', forecast)
        self.assertIn('upper_bound', forecast)
        self.assertEqual(len(forecast['forecast']), 6)
        
    def test_precursor_detection(self):
        """Test precursor pattern detection."""
        # Test density increase + southward IMF
        data = {
            'density': [25],  # >20
            'bz': [-15]       # <-10
        }
        precursors = self.forecaster.detect_precursors(data)
        
        found = any(p['type'] == 'DENSITY_INCREASE_SOUTHWARD_IMF' for p in precursors)
        self.assertTrue(found)
        
        # Test Forbush decrease
        data = {'forbush': 6}  # >5%
        precursors = self.forecaster.detect_precursors(data)
        
        found = any(p['type'] == 'FORBUSH_DECREASE' for p in precursors)
        self.assertTrue(found)
        
        # Test TEC enhancement
        data = {'tec_auroral': 60}  # >50 TECU
        precursors = self.forecaster.detect_precursors(data)
        
        found = any(p['type'] == 'TEC_ENHANCEMENT' for p in precursors)
        self.assertTrue(found)
    
    def test_ensemble_forecast(self):
        """Test ensemble forecasting."""
        historical = {'sei_history': [85, 84, 83, 82, 81, 80]}
        
        ensemble = self.forecaster.get_ensemble_forecast(historical, n_members=10)
        
        self.assertIn('mean', ensemble)
        self.assertIn('median', ensemble)
        self.assertIn('std', ensemble)
        self.assertIn('p10', ensemble)
        self.assertIn('p90', ensemble)
        self.assertEqual(len(ensemble['mean']), 6)
        
    def test_validation(self):
        """Test storm validation."""
        # Halloween 2003
        result = self.forecaster.validate_against_storm({}, 'halloween_2003')
        self.assertEqual(result['min_sei'], 23)
        self.assertEqual(result['lead_time'], 4.2)
        
        # St. Patrick's 2015
        result = self.forecaster.validate_against_storm({}, 'st_patrick_2015')
        self.assertEqual(result['min_sei'], 38)
        self.assertEqual(result['lead_time'], 5.8)
        
        # September 2017
        result = self.forecaster.validate_against_storm({}, 'september_2017')
        self.assertEqual(result['min_sei'], 31)
        self.assertEqual(result['lead_time'], 6.0)


if __name__ == '__main__':
    unittest.main()
