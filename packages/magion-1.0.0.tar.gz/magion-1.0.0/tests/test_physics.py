"""
Unit tests for physics modules (with corrected values).
"""

import unittest
import numpy as np
from magion.physics.magnetosphere import MagnetosphereMHD, MagnetopauseConstants
from magion.physics.cosmic_rays import StoermerTheory, CosmicRayConstants


class TestMagnetosphereMHD(unittest.TestCase):
    """Test magnetospheric physics calculations."""
    
    def setUp(self):
        self.mhd = MagnetosphereMHD()
        self.c = MagnetopauseConstants()
        
    def test_dynamic_pressure(self):
        """Test dynamic pressure calculation."""
        density = 5e6  # m⁻³
        velocity = 400e3  # m/s
        p_dyn = self.mhd.dynamic_pressure(density, velocity)
        # 1.336e-9 Pa = 1.336 nPa
        self.assertAlmostEqual(p_dyn, 1.336e-9, places=12)
        
    def test_magnetic_pressure(self):
        """Test magnetic pressure calculation."""
        b = 3.12e-5  # Tesla
        
        # P_mag = B² / (2μ₀)
        # μ₀ = 4π × 10⁻⁷ = 1.256637e-6
        # = (3.12e-5)² / (2 × 1.256637e-6) = 3.873e-4 Pa
        p_mag = self.mhd.magnetic_pressure(b)
        
        # التحقق بالباسكال (Pa)
        self.assertAlmostEqual(p_mag, 3.873e-4, places=6)
        
    def test_magnetopause_standoff(self):
        """Test magnetopause standoff calculation."""
        p_dyn = 2e-9  # 2 nPa
        rs = self.mhd.magnetopause_standoff(p_dyn)
        self.assertAlmostEqual(rs, 7.606, places=2)


class TestStoermerTheory(unittest.TestCase):
    """Test cosmic ray physics calculations."""
    
    def setUp(self):
        self.stoermer = StoermerTheory()
        self.c = CosmicRayConstants()
        
    def test_cutoff_rigidity(self):
        """Test rigidity cutoff calculation."""
        rc_eq = self.stoermer.vertical_cutoff_rigidity(0)
        self.assertAlmostEqual(rc_eq, 14.77, places=1)
        
        rc_polar = self.stoermer.vertical_cutoff_rigidity(70)
        self.assertLess(rc_polar, 2)
        
    def test_particle_rigidity(self):
        """Test particle rigidity calculation."""
        rigidity = self.stoermer.particle_rigidity(1.0)
        self.assertAlmostEqual(rigidity, 0.346, places=2)


if __name__ == '__main__':
    unittest.main()
