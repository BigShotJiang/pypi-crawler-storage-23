"""
Integration tests for MAGION framework.
Tests end-to-end functionality.
"""

import unittest
import numpy as np
from magion.core.shield_monitor import ShieldEfficiencyMonitor
from magion.core.sei_calculator import SEICalculator
from magion.alerts.classifier import AlertClassifier
from magion.parameters import (
    MagnetopauseStandoff,
    CosmicRayFlux,
    GeomagneticIndex
)


class TestIntegration(unittest.TestCase):
    """Test complete MAGION workflow."""
    
    def setUp(self):
        """Set up test components."""
        self.monitor = ShieldEfficiencyMonitor(
            data_sources=['ACE', 'NMDB'],
            update_interval=1
        )
        self.calculator = SEICalculator()
        self.classifier = AlertClassifier()
        
    def test_end_to_end(self):
        """Test complete SEI calculation workflow."""
        # Create sample data
        data = {
            'density': 5.0,
            'velocity': 400.0,
            'bz': 0.0,
            'kp': 2,
            'neutron_counts': {'NEWK': 100},
            'dst': -10
        }
        
        # Calculate parameters manually
        rs = MagnetopauseStandoff()
        nmf = CosmicRayFlux('NEWK')
        kp = GeomagneticIndex()
        
        param_scores = {
            'rs': rs.compute(data),
            'nmf': nmf.compute({'neutron_counts': {'NEWK': 100}}),
            'kp': kp.compute({'kp': 2}),
            'np': 0.95,  # Mock values
            'rc': 0.85,
            'tec': 0.90,
            'va': 0.88,
            'fd': 1.00
        }
        
        # Calculate SEI
        sei = self.calculator.compute(param_scores)
        
        # Verify SEI is in valid range
        self.assertGreaterEqual(sei, 0)
        self.assertLessEqual(sei, 100)
        
        # Classify alert level
        level = self.classifier.classify(sei)
        self.assertIn(level, ['QUIET', 'UNSETTLED', 'STORM_ALERT', 
                              'SEVERE_BLAST', 'CRITICAL'])
        
    def test_storm_scenario(self):
        """Test storm condition simulation."""
        # Simulate CME conditions
        data = {
            'density': 25.0,    # High density
            'velocity': 800.0,   # High speed
            'bz': -15.0,         # Strong southward
            'kp': 7,             # Major storm
            'neutron_counts': {'THUL': 70},  # Depressed counts
            'dst': -150          # Severe storm
        }
        
        # Calculate parameters
        rs = MagnetopauseStandoff()
        nmf = CosmicRayFlux('THUL')
        kp = GeomagneticIndex()
        
        param_scores = {
            'rs': rs.compute(data),
            'nmf': nmf.compute({'neutron_counts': {'THUL': 70}}),
            'kp': kp.compute({'kp': 7}),
            'np': 0.3,   # Mock low values
            'rc': 0.4,
            'tec': 0.5,
            'va': 0.6,
            'fd': 0.7
        }
        
        # Calculate SEI
        sei = self.calculator.compute(param_scores)
        
        # Should be in severe range
        self.assertLess(sei, 60)
        
        # Classify
        level = self.classifier.classify(sei)
        self.assertIn(level, ['SEVERE_BLAST', 'CRITICAL'])
        
    def test_data_flow(self):
        """Test data flow through pipeline."""
        # This test would require real data sources
        # For now, just verify monitor initialization
        self.assertIsNotNone(self.monitor)
        self.assertIsNotNone(self.monitor.sei_calculator)
        self.assertIsNotNone(self.monitor.alert_classifier)


if __name__ == '__main__':
    unittest.main()
