"""
Unit tests for SEI calculator module.
"""

import unittest
import numpy as np
from magion.core.sei_calculator import SEICalculator


class TestSEICalculator(unittest.TestCase):
    """Test SEI calculation engine."""
    
    def setUp(self):
        self.calculator = SEICalculator()
        
    def test_weights_sum(self):
        """Test that weights sum to 1."""
        total = sum(self.calculator.weights.values())
        self.assertAlmostEqual(total, 1.0, places=2)
    
    def test_compute(self):
        """Test SEI computation."""
        scores = {param: 1.0 for param in self.calculator.weights}
        sei = self.calculator.compute(scores)
        self.assertAlmostEqual(sei, 100.0)
        
        scores = {param: 0.0 for param in self.calculator.weights}
        sei = self.calculator.compute(scores)
        self.assertAlmostEqual(sei, 0.0)
    
    def test_invalid_parameter(self):
        """Test handling of invalid parameter."""
        scores = {'invalid': 0.5}
        with self.assertRaises(ValueError):
            self.calculator.compute(scores)
    
    def test_custom_weights_valid(self):
        """Test valid custom weights."""
        # يجب أن يعمل بدون خطأ لأن المجموع = 1
        custom_weights = {'rs': 0.5, 'nmf': 0.5}
        calculator = SEICalculator(custom_weights)
        self.assertEqual(calculator.weights, custom_weights)
    
    def test_custom_weights_invalid(self):
        """Test invalid custom weights."""
        # يجب أن يرفع خطأ لأن المجموع != 1
        custom_weights = {'rs': 0.5, 'nmf': 0.4}
        with self.assertRaises(ValueError) as context:
            SEICalculator(custom_weights)
        self.assertIn("must sum to 1.0", str(context.exception))
    
    def test_alert_levels(self):
        """Test alert level classification."""
        levels = [
            (95, 'QUIET'),
            (85, 'QUIET'),
            (70, 'UNSETTLED'),
            (50, 'STORM ALERT'),
            (30, 'SEVERE BLAST'),
            (10, 'CRITICAL'),
        ]
        
        for sei, expected in levels:
            level = self.calculator.get_alert_level(sei)
            self.assertEqual(level, expected, f"SEI={sei} expected={expected}")
    
    def test_uncertainty(self):
        """Test uncertainty calculation."""
        scores = {param: 0.5 for param in self.calculator.weights}
        uncertainties = {param: 0.1 for param in self.calculator.weights}
        
        result = self.calculator.compute_with_uncertainty(scores, uncertainties)
        
        self.assertIn('value', result)
        self.assertIn('min', result)
        self.assertIn('max', result)
        self.assertIn('std', result)
        
        self.assertAlmostEqual(result['value'], 50.0, delta=5)
        self.assertLess(result['min'], result['value'])
        self.assertGreater(result['max'], result['value'])
    
    def test_edge_cases(self):
        """Test edge cases."""
        scores = {param: 1.5 for param in self.calculator.weights}
        sei = self.calculator.compute(scores)
        self.assertAlmostEqual(sei, 100.0)
        
        scores = {param: -0.5 for param in self.calculator.weights}
        sei = self.calculator.compute(scores)
        self.assertAlmostEqual(sei, 0.0)


if __name__ == '__main__':
    unittest.main()
