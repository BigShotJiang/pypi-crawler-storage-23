## [0.4.3](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.2...v0.4.3) (2026-02-21)


### Bug Fixes

* add krbtgt rotation and protected users group to dashboard ([93d9e4b](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/93d9e4b36c6fb417549e805788db60099735fb09))

## [0.4.2](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.1...v0.4.2) (2026-02-21)


### Bug Fixes

* column sorting bug ([158ddfa](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/158ddfafe5f1d9ae8b72bafa6a9b393f9a1d067f))

## [0.4.1](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.0...v0.4.1) (2026-02-21)


### Bug Fixes

* --no-dashboard ([3c0768a](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/3c0768a2817c41c7eaa70534a31aa869b049b05a))

## [0.4.0](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.3.12...v0.4.0) (2026-02-21)


### Features

* html security dashboard generation ([05f72ec](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/05f72ec310f02e122ce7ecbd1118b31fa04eb296))

## [0.3.12](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.3.11...v0.3.12) (2026-02-20)


### Bug Fixes

* initialize sid mappings earlier to support individual --collect adcs runs ([e2ce483](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/e2ce483ca44ad805bd1749808f3cc11ee958d5ce))

