""" Sorting Mode.
"""
from enum import Enum, auto


class SortMode(Enum):
    MODULE = auto()
    SOURCESET = auto()
