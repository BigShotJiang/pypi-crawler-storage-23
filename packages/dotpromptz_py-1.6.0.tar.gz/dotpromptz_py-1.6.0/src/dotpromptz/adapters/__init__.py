# Copyright 2025 Google LLC
# SPDX-License-Identifier: Apache-2.0

"""LLM API adapters for dotpromptz.

Each adapter converts a ``RenderedPrompt`` from ``Dotprompt.render()`` into
a provider-specific API call and returns a unified ``GenerateResponse``.

All adapters accept an optional ``base_url`` parameter (or corresponding
environment variable) to support third-party API-compatible endpoints.
"""

from typing import Any

from ._base import Adapter, GenerateResponse, ImageResult, ToolCallResult, Usage
from .anthropic import AnthropicAdapter
from .google import GoogleAdapter
from .openai import OpenAIAdapter

__all__ = [
    'Adapter',
    'AnthropicAdapter',
    'GenerateResponse',
    'GoogleAdapter',
    'ImageResult',
    'OpenAIAdapter',
    'ToolCallResult',
    'Usage',
    'get_adapter',
    'list_adapters',
]

# ---------------------------------------------------------------------------
# Adapter registry
# ---------------------------------------------------------------------------

_ADAPTERS: dict[str, type[Adapter]] = {
    'openai': OpenAIAdapter,
    'anthropic': AnthropicAdapter,
    'google': GoogleAdapter,
}


def list_adapters() -> list[str]:
    """Return the names of all registered adapters.

    Returns:
        A sorted list of adapter name strings.
    """
    return sorted(_ADAPTERS.keys())


def get_adapter(name: str, **kwargs: Any) -> Adapter:
    """Instantiate an adapter by name.

    Args:
        name: One of the registered adapter names (see ``list_adapters()``).
        **kwargs: Keyword arguments forwarded to the adapter constructor.

    Returns:
        An ``Adapter`` instance.

    Raises:
        ValueError: If the adapter name is unknown.
    """
    adapter_cls = _ADAPTERS.get(name)
    if adapter_cls is None:
        available = ', '.join(list_adapters())
        raise ValueError(f'Unknown adapter: {name!r}. Available: {available}')

    return adapter_cls(**kwargs)
