import pyperclip
from .data import OPTIONS


def main():
    try:
        choice = int(input("➜ "))

        if choice in OPTIONS:
            pyperclip.copy(OPTIONS[choice])

    except:
        pass


        
