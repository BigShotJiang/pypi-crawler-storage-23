# map1

MAP v1: deterministic identity for structured data.

**This is a name reservation. The full package has not been published yet.**

See: https://github.com/map-protocol/map1