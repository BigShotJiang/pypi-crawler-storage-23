"""MAP v1: deterministic identity for structured data.

This is a name reservation. Full package coming soon.
See: https://github.com/map-protocol/map1
"""
raise ImportError("map1 v1.0 has not been published yet.")