"""Interactive demos showcasing Octomil capabilities."""
