# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# import onnx

import amesa_core.utils.logger as logger_util
import numpy as np
import onnx
import onnxruntime
import torch
from amesa_core import Agent, Skill

from amesa_train.utils.space_utils import flatten_object_numpy

logger = logger_util.get_logger(__name__)


def validate_onnx_model(onnx_model: onnx.ModelProto, save_path: str, input_data: dict, ground_truth: torch.Tensor):
    ort_session = onnxruntime.InferenceSession(save_path, providers=["CPUExecutionProvider"])

    # compute ONNX Runtime output prediction
    try:
        ort_outs = ort_session.run(['vf_preds', "action_dist_inputs"], input_data)
    except Exception as e:
        # drop "action mask" if it is not in the input
        if "action_mask" in input_data.keys():
            input_data.pop("action_mask")
            ort_outs = ort_session.run(['vf_preds', "action_dist_inputs"], input_data)
        else:
            raise e
    # check that the ONNX Runtime output matches expected output

    # compare ONNX Runtime and PyTorch results
    if not np.allclose(ground_truth.detach().numpy(), ort_outs[1], rtol=1e-03, atol=1e-05):
        logger.warning("PyTorch and ONNX Runtime results are not equal!")

    logger.debug("Exported model has been tested with ONNXRuntime, and the result match!")


async def export_policy_and_skill_to_onnx(policy, skill: Skill, agent: Agent):
    # get the observation space from the policy
    obs_space = policy.observation_space

    torch_model = policy.model
    torch_model.eval()

    sample_obs = obs_space.sample()

    # all the methods used for validation require a batch import
    # Expand now to reduce duplicated np and torch expand operations
    sample_obs["observation"] = np.expand_dims(sample_obs["observation"], axis=0)
    sample_obs["observation"] = torch.from_numpy(sample_obs["observation"])

    # Always ensure action_mask is present, even if the sim doesn't provide it
    # This is critical for selectors which always need action masks
    if "action_mask" in sample_obs.keys():
        sample_obs["action_mask"] = flatten_object_numpy(
            sample_obs["action_mask"]
        ).astype(np.float64)
        # Expand to batch dimension to match observation
        sample_obs["action_mask"] = np.expand_dims(sample_obs["action_mask"], axis=0)
        sample_obs["action_mask"] = torch.from_numpy(
            sample_obs["action_mask"]
        ).double()
    else:
        # Create a default action_mask of all ones based on the action space
        # This ensures the ONNX model always has the action_mask input
        action_space = skill.get_action_space()
        if action_space is not None:
            # Get the action mask space to determine the shape
            try:
                action_mask_space = action_space.get_action_mask_space()
                if hasattr(action_mask_space, 'shape'):
                    mask_shape = action_mask_space.shape
                elif hasattr(action_space, 'n'):
                    # Discrete space
                    mask_shape = (action_space.n,)
                elif hasattr(action_space, 'shape'):
                    # Box space
                    mask_shape = action_space.shape
                else:
                    # Fallback: try to get size
                    mask_shape = (action_space.size if hasattr(action_space, 'size') else (1,))

                # Create default mask of all ones with batch dimension
                default_mask = np.ones(mask_shape, dtype=np.float64)
                # Expand to batch dimension to match observation
                default_mask = np.expand_dims(default_mask, axis=0)
                sample_obs["action_mask"] = torch.from_numpy(default_mask).double()
                logger.debug(
                    f"Created default action_mask with shape {mask_shape} (batch expanded) for ONNX export"
                )
            except Exception as e:
                logger.warning(f"Could not create default action_mask: {e}. Using shape (1,) as fallback.")
                default_mask = np.ones((1,), dtype=np.float64)
                default_mask = np.expand_dims(default_mask, axis=0)
                sample_obs["action_mask"] = torch.from_numpy(default_mask).double()
        else:
            # Fallback if action space is not available
            logger.warning("Action space not available, using default action_mask shape (1,)")
            default_mask = np.ones((1,), dtype=np.float64)
            default_mask = np.expand_dims(default_mask, axis=0)
            sample_obs["action_mask"] = torch.from_numpy(default_mask).double()

    sample_input = {
        "obs": sample_obs
    }
    # Get the output of the torch model, used to compare with the ONNX model
    torch_out = torch_model(sample_input)["action_dist_inputs"]

    # make it a "batch" of 1
    sample_input_onnx = ({
        "obs": sample_obs
    })

    save_path = f"{skill.get_checkpoint_uri()}/{skill.get_name()}.onnx"

    # Note on the "(sample_input_onnx, {})" :
    # The sample input gets processed in a really werid way by the ONNX exporter
    # Please refer to the following link for more information:
    # https://github.com/pytorch/pytorch/blob/main/torch/onnx/utils.py#L221-L281
    torch.onnx.export(
        torch_model,  # model being run
        (sample_input_onnx, {}),  # model input (or a tuple for multiple inputs)
        save_path,  # where to save the model (can be a file or file-like object)
        export_params=True,  # store the trained parameter weights inside the model file
        opset_version=15,  # the ONNX version to export the model to
        do_constant_folding=True,  # whether to execute constant folding for optimization
        input_names=['observation', "action_mask"],  # the model's input names
        output_names=['vf_preds', "action_dist_inputs"],  # the model's output names
    )
    onnx_model = onnx.load(save_path)
    onnx.checker.check_model(onnx_model)

    # Always include action_mask in validation input
    sample_inference_onnx_input = {
        "observation": sample_obs["observation"].detach().numpy(),
        "action_mask": sample_obs["action_mask"].detach().numpy()
    }

    validate_onnx_model(onnx_model, save_path, sample_inference_onnx_input, torch_out)
