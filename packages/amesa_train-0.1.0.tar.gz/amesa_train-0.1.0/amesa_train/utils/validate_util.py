# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Any, Dict, List, Tuple, Union

import math
import numpy as np

from amesa_train.env.env import AmesaEnv
from amesa_train.config.step_info import TeacherStepData, CoordinatedTeacherStepData
import amesa_core.utils.logger as logger_util

logger = logger_util.get_logger(__name__)


def validate_dataset(dataset: Union[Dict[str, Any], List[Union[TeacherStepData, CoordinatedTeacherStepData, Dict[str, Any]]]]) -> Tuple[bool, List[Exception]]:
    # for each key in the dataset, check that the values are consistent
    # this means that the values are the same data type, or None
    # if the values are not the same data type, raise an error
    # if the values are None, then we can't check them, so we skip them
    errors = []

    # Check that the dataset is not empty
    if not dataset or len(dataset) == 0:
        errors.append(ValueError("Dataset is empty or None"))
        return False, errors

    if not isinstance(dataset, dict):
        dict_dataset = {}
        keys = dataset[0].model_dump().keys()
        for key in keys:
            dict_dataset[key] = []

        # Convert the dataset to a dictionary for easier processing
        for item in dataset:
            for key, value in item.model_dump().items():
                dict_dataset[key] = [value]
    else:
        dict_dataset = dataset

    # first, get the keys
    # then, iterate through the keys and check the values
    for key, values in dict_dataset.items():
        added_error = False

        if len(values) == 0:
            continue

        first_value = values[0]
        if isinstance(first_value, dict):
            # if the first value is a dict, then we need to check the keys
            # and then check the values for each key
            for sub_key in first_value.keys():
                sub_values = [value[sub_key] for value in values]
                valid, sub_errors = validate_dataset({sub_key: sub_values})

                if not valid:
                    errors.extend(sub_errors)
                    added_error = True
                    break

            if added_error:
                continue
        else:
            for value in values:
                if value is None:
                    continue

                if first_value is None:
                    first_value = value
                    continue

                if type(value) is not type(first_value):
                    errors.append(
                        ValueError(
                            f"Type Mismatch, Expected '{key}'='{value}' (type: '{type(value)}'), got: '{key}'='{first_value}' (type: '{type(first_value)}')"
                        )
                    )
                    added_error = True
                elif isinstance(value, np.ndarray):
                    if value.shape != first_value.shape:
                        errors.append(
                            ValueError(
                                f"Shape Mismatch, Expected '{key}'='{value}' (shape: '{value.shape}'), got: '{key}'='{first_value}' (shape: '{first_value.shape}')"
                            )
                        )# first, get the keys
    # then, iterate through the keys and check the values
                        added_error = True

                if added_error:
                    break

    return len(errors) == 0, errors


def gather_env(env: AmesaEnv) -> dict[str, list[Any]]:
    """
    Validate the environment
    We do this by running 3 episodes and checking various teacher values and sim values
    """
    objects = {}

    # Run 5 episodes
    for _ in range(3):
        episode_objects = {
            "obs": [],
            "reward": [],
            "truncated": [],
            "done": [],
            "sim_action_mask": [],
            "teacher_reward": [],
            "teacher_action_mask": [],
            "teacher_success_criteria": [],
            "teacher_termination": [],
            "teacher_transformed_sensors": [],
            "teacher_action": [],
            "teacher_done": [],
        }

        try:
            obs, info = env.reset()
        except Exception as e:
            # reset errors are possible from both user side and sdk side
            episode_objects["reset_error"] = e
            break  # we can't continue if we can't reset

        episode_objects["obs"].append(obs)
        done = False
        counter = 0

        while not done and counter < 1000:  # in case the sim episodes are very long
            action = env.action_space.sample()
            try:
                obs, reward, done, truncated, info = env.step(action)
            except Exception as e:
                # step errors are possible from both user side and sdk side
                episode_objects["step_error"] = str(e)
                break  # we can't continue if we can't step

            episode_objects["obs"].append(obs)
            episode_objects["reward"].append(reward)
            episode_objects["truncated"].append(truncated)

            if "done" not in objects.keys():
                episode_objects["done"] = []

            episode_objects["done"].append(done)

            if isinstance(info, dict):
                if "action_mask" in info.keys():
                    episode_objects["sim_action_mask"] = info["action_mask"]
                # otherwise we don't care what sort of stuff the sim is telling us
                # it is there for logging purposes for the historian

            counter += 1

        # append the episode objects to the objects
        for key, value in episode_objects.items():
            if key not in objects.keys():
                objects[key] = []
            objects[key].extend(value)

    return objects


def adjust_resources(skill, num_samples: int, time: float) -> None:
    """
    Adjust the resources for the skill trainer
    Args:
        resources (ResourcesConfig): The resources configuration
    Returns:
        None
    """
    train_batch_size = skill.skill_config.learning.train_batch_size
    rollout_fragment_length = skill.skill_config.resources.rollout_fragment_length

    envs_per_worker = skill.skill_config.resources.envs_per_worker
    workers = skill.skill_config.resources.workers

    if rollout_fragment_length is None or rollout_fragment_length == "auto":
        # We want to set the rollout fragment length such that we have between 4000 and 4400 samples per batch per worker
        Tmin, Tmax = 4000, 4400
        k = 10

        L_min = math.ceil(Tmin / (workers * envs_per_worker * k))
        L_max = Tmax // (workers * envs_per_worker * k)

        rollout_fragment_length = max(L_min, min(L_max, train_batch_size // (workers * envs_per_worker * k)))

    samples_per_second = num_samples / time

    sample_timeout_s = 50 * rollout_fragment_length / samples_per_second

    skill.skill_config.resources.sample_timeout_s = sample_timeout_s
    skill.skill_config.resources.rollout_fragment_length = rollout_fragment_length

    logger.info(
        f"Adjusting resources for skill {skill.get_name()} with num_samples={num_samples}, time={time} seconds, "
        f"train_batch_size={train_batch_size}, rollout_fragment_length={rollout_fragment_length} "
        f"sample_timeout_s={sample_timeout_s}, envs_per_worker={envs_per_worker}, workers={workers} "
    )
