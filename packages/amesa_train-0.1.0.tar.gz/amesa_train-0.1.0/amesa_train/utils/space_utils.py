# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
Torch-dependent space utility functions for amesa_train.

This module contains all torch-dependent functions that were moved from
amesa_core.utils.space_utils to keep amesa_core free of torch dependencies.
"""

from collections import OrderedDict
from typing import Any, Dict, List, Tuple, Union

import numpy as np
import torch
from ray.rllib.utils.nested_dict import NestedDict

import amesa_core.spaces as amesa_spaces
from amesa_core.utils.space_utils import (
    make_np_array as make_np_array_core,
    combine_masks as combine_masks_core,
    flatten_object_numpy as flatten_object_numpy_core,
)


def make_tensor(
    x: Union[np.ndarray, Dict[str, np.ndarray], Tuple[np.ndarray], List[np.ndarray]],
    dtype=torch.float32,
) -> Union[
    torch.Tensor, Dict[str, torch.Tensor], Tuple[torch.Tensor], List[torch.Tensor]
]:
    """Convert numpy arrays to torch tensors, handling nested structures."""
    if isinstance(x, np.ndarray):
        return torch.tensor(x, dtype=dtype)
    elif isinstance(x, dict):
        return {k: make_tensor(v, dtype=dtype) for k, v in x.items()}
    elif isinstance(x, tuple):
        return tuple(make_tensor(v, dtype=dtype) for v in x)
    elif isinstance(x, list):
        return [make_tensor(v, dtype=dtype) for v in x]
    else:
        return torch.tensor(x, dtype=dtype)


def make_np_array(x, dtype=np.float32):
    """
    Convert various types to numpy arrays, including torch.Tensor support.

    This extends the core make_np_array function to handle torch.Tensor inputs.
    """
    if isinstance(x, torch.Tensor):
        return x.detach().numpy().astype(dtype)
    return make_np_array_core(x, dtype=dtype)


def unsquash_action_batch(action_batch, action_space_struct):
    """Unsquash a batch of actions according to the action space structure."""
    from amesa_core.utils.space_utils import unsquash_action

    unsquashed = {}
    for key in action_batch.keys():
        unsquashed[key] = [
            unsquash_action(action_i.numpy(), action_space_struct[key])
            for action_i in action_batch[key]
        ]
    return unsquashed


def combine_masks(mask1, mask2):
    """
    Combine two action masks, with torch.Tensor support.

    This extends the core combine_masks function to handle torch.Tensor inputs.
    """
    if isinstance(mask1, torch.Tensor):
        return torch.mul(mask1, mask2)
    return combine_masks_core(mask1, mask2)


def apply_mask(
    logits: Union[Dict, Tuple, List, np.ndarray],
    action_mask: Union[Dict, Tuple, List, np.ndarray],
):
    """
    Action masks comes in as a dict, tuple, list or numpy array so we apply the action mask
    according to the action space here

    The mask is applied by setting the indicices of the logits to -inf where the mask is 0

    Args:
        logits: The logits (probability output of the NN) to apply the mask to
        action_mask: The mask to apply

    Returns:
        The masked logits
    """

    if isinstance(action_mask, NestedDict):
        return apply_mask(logits, action_mask.asdict())
    if type(logits) is not type(action_mask):
        if (isinstance(logits, (dict, OrderedDict, NestedDict))
        ) and (
            isinstance(action_mask, (dict, OrderedDict, NestedDict))
        ):
            # sometimes logits and action_mask are both dicts, but ordered dict or nested dicts, which a type - type check will fail
            pass
        elif isinstance(logits, (list, tuple)) and isinstance(
            action_mask, (list, tuple)
        ):
            # sometimes logits and action_mask are both tuples or lists, which a type - type check will fail
            pass
        elif isinstance(logits, (np.ndarray, torch.Tensor)) and isinstance(
            action_mask, (np.ndarray, torch.Tensor)
        ):
            # sometimes logits and action_mask are a mix between np.ndarray and torch.Tensor, which a type - type check will fail
            pass
        else:
            try:
                logits = make_np_array(logits, dtype=np.float32)
                action_mask = make_np_array(action_mask, dtype=np.int8)
                return apply_mask(logits, action_mask)
            except Exception as e:
                raise ValueError(
                    f"Cannot apply mask of type {type(action_mask)} to logits of type \
                                 {type(logits)} -- {action_mask} -- {logits}. Tried to cast both to \
                                 np.ndarray and failed with error: {e}"
                )

    if isinstance(action_mask, np.ndarray) or isinstance(action_mask, torch.Tensor):
        if action_mask.shape != logits.shape:
            raise ValueError(
                f"Action mask shape ({action_mask.shape}) does not match logits shape ({logits.shape})"
            )

        inf_mask = torch.clamp(torch.log(action_mask), min=-np.inf)
        masked_logits = logits + inf_mask
        return masked_logits
    elif (
        isinstance(action_mask, dict)
        or isinstance(action_mask, NestedDict)
        or isinstance(action_mask, OrderedDict)
    ):
        if set(action_mask.keys()) != set(logits.keys()):
            raise ValueError(
                f"Action mask keys ({action_mask.keys()}) do not match logits keys ({logits.keys()})"
            )

        return {k: apply_mask(logits[k], action_mask[k]) for k in action_mask.keys()}
    elif isinstance(action_mask, tuple):
        if len(action_mask) != len(logits):
            raise ValueError(
                f"Action mask shape ({len(action_mask)}) does not match logits shape ({len(logits)})"
            )

        return tuple(
            apply_mask(logits[i], action_mask[i]) for i in range(len(action_mask))
        )
    elif isinstance(action_mask, list):
        if len(action_mask) != len(logits):
            raise ValueError(
                f"Action mask shape ({len(action_mask)}) does not match logits shape ({len(logits)})"
            )

        return [apply_mask(logits[i], action_mask[i]) for i in range(len(action_mask))]
    else:
        raise ValueError(f"Unsupported mask type: {type(action_mask)}")


def mask_all_zero(action_mask):
    """
    Action masks comes in as a dict, tuple, list or numpy array, we check if they are all zero here

    Args:
        action_mask: The mask to check for all zeros

    Returns:
        True if all elements are 0, otherwise False
    """
    if isinstance(action_mask, np.ndarray):
        return not np.any(action_mask)
    elif isinstance(action_mask, dict) or isinstance(action_mask, NestedDict):
        for key, value in action_mask.items():
            if not mask_all_zero(value):
                return False
        return True
    elif isinstance(action_mask, tuple) or isinstance(action_mask, list):
        for sub_mask in action_mask:
            if not mask_all_zero(sub_mask):
                return False
        return True
    elif isinstance(action_mask, torch.Tensor):
        return not torch.any(action_mask)
    else:
        raise ValueError(f"Unsupported mask type: {type(action_mask)}")


def flatten_object_torch(object):
    """Flatten an object to a 1D torch tensor."""
    if isinstance(object, np.ndarray):
        return torch.flatten(torch.from_numpy(object))
    elif isinstance(object, torch.Tensor):
        return torch.flatten(object)
    elif isinstance(object, (dict, NestedDict)):
        return torch.cat([flatten_object_torch(object[key]) for key in object.keys()])
    elif isinstance(object, (tuple, list)):
        return torch.cat([flatten_object_torch(value) for value in object])
    else:
        raise ValueError(f"Unsupported object type: {type(object)}")


def flatten_object_batch(object):
    """Flatten an object to a 2D torch tensor, preserving batch dimension."""
    if isinstance(object, np.ndarray):
        return torch.flatten(torch.from_numpy(object), start_dim=1)
    elif isinstance(object, torch.Tensor):
        return torch.flatten(object, start_dim=1)
    elif isinstance(object, (dict, NestedDict)):
        return torch.cat(
            [flatten_object_batch(object[key]) for key in object.keys()], dim=1
        )
    elif isinstance(object, (tuple, list)):
        return torch.cat([flatten_object_batch(value) for value in object], dim=1)
    else:
        raise ValueError(f"Unsupported object type: {type(object)}")


def flatten_object_numpy(obj):
    """
    Flatten an object to a 1D numpy array, with torch.Tensor and NestedDict support.

    This extends the core flatten_object_numpy function to handle torch.Tensor and Ray's NestedDict.
    """
    if isinstance(obj, torch.Tensor):
        return torch.flatten(obj).detach().numpy()
    elif isinstance(obj, NestedDict):
        # Convert NestedDict to dict and use core implementation
        return flatten_object_numpy_core(obj.asdict())
    return flatten_object_numpy_core(obj)


def unpack_logits(logits: torch.Tensor, space: amesa_spaces.Space):
    """Unpack a flattened Dict or Tuple sensor array/tensor.

    Args:
        logits: The flattened sensor tensor, with last dimension equal to
            the flat size and any number of batch dimensions. For example, for
            Box(4,), the obs may have shape [B, 4], or [B, N, M, 4] in case
            the Box was nested under two Repeated spaces.
        space: The original space prior to flattening
    """

    if isinstance(space, (amesa_spaces.Dict, amesa_spaces.Tuple)):
        # Already unpacked?
        if (
            isinstance(space, amesa_spaces.Tuple)
            and isinstance(logits, (list, tuple))
        ) or (isinstance(space, amesa_spaces.Dict) and isinstance(logits, dict)):
            return logits

        offset = 0
        batch_dims = list(logits.shape[:-1])
        if isinstance(space, amesa_spaces.Tuple):
            u = []
            for sub_space in space.spaces:
                obs_slice = logits[..., offset : offset + sub_space.size]
                offset += sub_space.size
                u.append(
                    unpack_logits(
                        torch.reshape(obs_slice, batch_dims + list(sub_space.shape)),
                        sub_space,
                    )
                )
        elif isinstance(space, amesa_spaces.Dict):
            u = OrderedDict()
            for sub_space_key, sub_space_value in space.spaces.items():
                obs_slice = logits[..., offset : offset + sub_space_value.size]
                offset += sub_space_value.size
                u[sub_space_key] = unpack_logits(
                    torch.reshape(obs_slice, batch_dims + list(sub_space_value.shape)),
                    sub_space_value,
                )
        return u
    elif isinstance(space, amesa_spaces.MultiDiscrete):
        u = []
        offset = 0
        for sub_space in space.nvec:
            obs_slice = logits[..., offset : offset + sub_space]
            offset += sub_space
            u.append(obs_slice)
        return u
    else:
        return logits

