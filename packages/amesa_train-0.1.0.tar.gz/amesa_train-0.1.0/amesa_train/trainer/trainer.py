# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import asyncio
import importlib
import sys
import time
from asyncio import Future
from typing import List, Optional, Tuple, TypeVar, Union

import amesa_core.utils.logger as logger_util
import ray
from amesa_api.controller.job_status_enum import JobStatusEnum
from amesa_api.controller.service import ControllerService
from amesa_core.agent import Skill, SkillCoordinatedSet, SkillSelector
from amesa_core.agent.agent import Agent
from amesa_core.config.trainer_config import (
    BenchmarkConfig,
    PostProcessingConfig,
    TrainerConfig,
    TrainerConfigDependencyType,
)
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)
from amesa_core.networking.status_enum import SimStatus
from amesa_core.settings import settings
from amesa_core.singletons.telemetry_historian import telemetry_historian
from amesa_core.trainer_base import TrainerBase
from amesa_core.trainer_target_enum import TrainerTargetEnum
from amesa_core.utils import async_util, sim_validator_util, warnings_util
from amesa_core.utils import debug as debug_util
from amesa_core.utils.plugin_util import fake_deepcopy_module_with_override
from ray.rllib.models import ModelCatalog
from typing_extensions import override

from amesa_train.actor.sim_mgr_actor import NetworkMgrActor
from amesa_train.env.env_mgr import EnvMgr
from amesa_train.evaluation import inference_episode_benchmark, postprocess
from amesa_train.model.skill_model import TorchActionMask
from amesa_train.skill_processors import make_skill_processor
from amesa_train.skill_processors.skill_processor_base import SkillProcessorBase
from amesa_train.trainer import create_skill_trainer
from amesa_train.utils import validate_util

T = TypeVar("T")

warnings_util.apply()

logger = logger_util.get_logger(__name__)


class Trainer(TrainerBase):
    env_mgr: EnvMgr
    sim_mgr: "ray.ObjectRef[NetworkMgrActor]"

    def __init__(self, config: dict = {}):
        super().__init__(config)

        self.trainer = None

    @override
    async def init_cluster(
        self,
        trainer_custom_modules: Union[None, List[object]] = None,
        trainer_custom_deps: Union[None, List[str]] = None,
    ):
        """
        Initialize the trainer itself
        This will typically be necessary to initialize the SimMgr and EnvMgr its dependencies

        This will depend on the target. When we have a local target, it is just localhost as ray is local
        if it is a remote target, we need to set how we can reach Ray and which packages to include

        Note: we can use `kubectl port-forward -n amesa_train-ray --address 0.0.0.0 service/raycluster-kuberay-head-svc 10001:10001` to expose the Ray Cluster locally for development

        More info: https://docs.ray.io/en/latest/ray-core/api/doc/ray.init.html
        """
        logger.info("Cluster: Initializing...")
        if (
            self.config.target.type == TrainerTargetEnum.LOCAL
            or self.config.target.type == TrainerTargetEnum.DOCKER
        ):
            self.init_cluster_normal(trainer_custom_modules, trainer_custom_deps)
        elif self.config.target.type == TrainerTargetEnum.KUBERNETES_JOB:
            self.init_cluster_kubernetes(trainer_custom_modules, trainer_custom_deps)
        elif self.config.target.type == TrainerTargetEnum.KUBERNETES:
            return
        elif self.config.target.type == TrainerTargetEnum.AMESA:
            return
        elif self.config.target.type == TrainerTargetEnum.V2:
            # V2 uses event-based architecture with Redis Streams, no Ray needed
            logger.info("- Target: 'v2' (Event-based architecture)")
            logger.info("- Protocol: 'redis-stream'")
            logger.info("- Redis URL: %s" % self.config.target.v2.redis_url)
            logger.info("Cluster: Initialized (V2 Event-based)")
            return
        else:
            raise Exception(f"Unknown target type='{self.config.target.type}'!")

        # Register the custom model we use for action masking
        ModelCatalog.register_custom_model(
            "composabl_action_masking_model", TorchActionMask
        )

        # Print the cluster resources
        cluster_resources = ray.cluster_resources()
        cluster_resources_memory_gb = (
            int(cluster_resources["memory"] / 1024 / 1024 / 1024 * 100) / 100
        )

        if "GPU" not in cluster_resources:
            cluster_resources["GPU"] = 0

        logger.info(
            f"- Resources: (CPU: {cluster_resources['CPU']}, GPU: {cluster_resources['GPU']}, Memory: {cluster_resources_memory_gb}, Nodes: {len(ray.nodes())})"
        )
        logger.info("Cluster: Initialized")

    def init_cluster_normal(
        self,
        trainer_custom_modules: Union[None, List[object]] = None,
        trainer_custom_deps: Union[None, List[str]] = None,
    ):
        """
        In the targets Local and Docker, we initialize Ray locally
        """
        deps_pip, deps_custom = self.init_cluster_gen_deps(trainer_custom_modules)
        deps_pip.extend(trainer_custom_deps if trainer_custom_deps is not None else [])
        # TODO: Clean up trainer custom dep args when dealing with remote skills.
        # We no longer need to specify them to the ray cluster.

        module_names = [m.__name__ for m in deps_custom]
        logger.info(f"- Target: '{self.config.target.type}'")
        logger.info(f"- Loading Modules: {module_names}")
        logger.info(f"- Loading Dependencies: '{deps_pip}'")

        for dep in deps_custom:
            fake_deepcopy_module_with_override(dep)

        ray.init(
            logging_level=logger_util.get_level(),
            log_to_driver=True,
            ignore_reinit_error=True,
            # https://docs.ray.io/en/latest/ray-core/handling-dependencies.html#trainer-environments
            runtime_env={
                "py_modules": deps_custom if len(deps_custom) > 0 else None,
                "pip": deps_pip if len(deps_pip) > 0 else None,
            },
        )

    def init_cluster_kubernetes(
        self,
        trainer_custom_modules: Union[None, List[object]] = None,
        trainer_custom_deps: Union[None, List[str]] = None,
    ):
        """
        In the target Kubernetes, we initialize Ray on the Kubernetes cluster
        """
        if self.config.target.type is not TrainerTargetEnum.KUBERNETES_JOB:
            raise Exception(
                "Kubernetes target can only be initialized in Kubernetes Job mode"
            )

        deps_pip, deps_custom = self.init_cluster_gen_deps(trainer_custom_modules)
        deps_pip.extend(trainer_custom_deps if trainer_custom_deps is not None else [])
        module_names = [m.__name__ for m in deps_custom]
        logger.info(f"    - Target: '{self.config.target.type}'")
        logger.info(f"    - Loading Modules: {module_names}")
        logger.info(f"    - Loading Dependencies: '{deps_pip}'")

        for dep in deps_custom:
            fake_deepcopy_module_with_override(dep)

        ray.init(
            address=self.config.trainer.ray.address,
            namespace=self.config.target.kubernetes_job.namespace,
            logging_level=logger_util.get_level(),
            ignore_reinit_error=True,
            log_to_driver=True,  # Direct worker output to driver
            # https://docs.ray.io/en/latest/ray-core/handling-dependencies.html#trainer-environments
            runtime_env={
                "py_modules": deps_custom if len(deps_custom) > 0 else None,
                "pip": deps_pip if len(deps_pip) > 0 else None,
            },
        )

    def init_cluster_gen_deps(
        self, trainer_custom_modules: Union[None, List[object]] = None
    ) -> Tuple[List[Union[str, object]], List[Union[str, object]]]:
        """
        Generate the dependencies for the trainer
        this also adds the Amesa SDK to the ray trainer depending on our environment

        e.g., if we are on dev we pass the source, else we pass the pip module

        Parameters:
        - config: The trainer config
        - trainer_custom_modules: The custom modules to include

        Returns:
        - List[Union[str, object, None]]: The pip dependencies
        - List[Union[str, object, None]]: The custom modules
        """
        if self.config is None:
            return [], []

        deps_pip = []
        deps_custom = []

        # Add the trainer custom modules
        if trainer_custom_modules is not None:
            for module in trainer_custom_modules:
                deps_custom.append(module)

        # Add extra configured dependencies
        if self.config.trainer.dependencies is not None:
            for dependency in self.config.trainer.dependencies:
                # Add extra pip packages
                if dependency.type == TrainerConfigDependencyType.PIP:
                    deps_pip.append(dependency.url)
                else:
                    raise Exception(f"Unknown dependency type='{dependency.type}'!")

        # Add Amesa as a dependency depending on the trainer env
        # DEV: Add source
        # PROD: Add PyPI package
        # Others: Add the module

        if (
            self.config.target.type == TrainerTargetEnum.KUBERNETES
            or self.config.target.type == TrainerTargetEnum.KUBERNETES_JOB
        ):
            version = debug_util.get_amesa_version()
            has_version = version == "Not installed"
            is_dev = debug_util.get_is_dev()

            if has_version and not is_dev:
                deps_pip.append(f"composabl=={version}")
            elif has_version and is_dev:
                deps_pip.append(f"composabl-dev=={version}")
            elif not has_version and is_dev:
                logger.warning(
                    "Amesa is not installed, adding the latest development version as we couldn't infer the version"
                )
                deps_pip.append("composabl-dev")
            else:
                logger.warning(
                    "Amesa is not installed, adding the latest version as we couldn't infer the version"
                )
                deps_pip.append("composabl")
        else:
            # Add Modules (resolved and imported)
            modules = [
                "composabl",
                "amesa_core",
                "amesa_train",
                "amesa_cli",
                "amesa_api",
            ]

            for m in modules:
                try:
                    m_imported = importlib.import_module(m)
                    deps_custom.append(m_imported)
                except Exception:
                    pass

        # None them if they are empty
        deps_pip = deps_pip if len(deps_pip) > 0 else []
        deps_custom = deps_custom if len(deps_custom) > 0 else []

        return deps_pip, deps_custom

    @override
    def _init_network_mgr(self, config: TrainerConfig) -> "ray.ObjectRef[NetworkMgrActor]":
        """
        Initialize the sim mgr
        This takes care of starting the simulator
        """
        return NetworkMgrActor.create_actor(config)

    @override
    def _init_env_mgr(self, actor_network_mgr: "ray.ObjectRef[NetworkMgrActor]") -> EnvMgr:
        """
        Initialize the environment mgr
        This takes care of registering the custom ray environment
        """
        env_mgr = EnvMgr(settings.RUN_ID, actor_network_mgr)
        return env_mgr

    @override
    async def init_simulator(self):
        """
        Initialize the simulator
        """
        logger.info("Simulator: Initializing")

        # First initialize the sim manager as we need it to acquire sims
        self.network_mgr = self._init_network_mgr(self.config)
        logger.info("- Sim Manager: OK")

        # Then validate the simulator
        logger.info("- Validating Simulator")
        sim_id, sim_client = await self.network_mgr.call_sim_mgr.remote(
            "create_with_client",
            self.config.target.protocol
        )
        is_valid, errors = await sim_validator_util._validate_by_client(sim_client)

        if not is_valid:
            logger.info("    - Structure: NOT OK")
            sim_validator_util.print_issues(errors)
            raise Exception("Simulator is not valid, cannot train")

        # spin down the sim
        await self.network_mgr.stop_all.remote()

        logger.info("    - Structure: OK")
        logger.info("Simulator: Initialized")

    @override
    def package(
        self, agent: Agent, skill: Optional[Union[str, Skill]] = None
    ) -> SkillProcessorBase:
        return async_util.async_to_sync(self._package)(agent, skill)

    async def _package(
        self, agent: Agent, skill: Optional[Union[str, Skill]] = None
    ) -> Future[SkillProcessorBase]:
        """
        It allows us to run inference on the trained agent
        This method creates a selector skill processor or baseskill processor that can be used for inference
        """
        if not agent.is_initialized:
            await agent.init()
        # If no skill, we export the top skill
        if skill is None:
            node = agent.get_top_skill()
            return await self._create_executable_agent(agent, node)
        skill_name = skill.get_name() if isinstance(skill, Skill) else skill
        # If skill is specified, we export that specific skill
        node = agent.get_node_by_name(skill_name)
        return await self._create_executable_agent(agent, node)

    @override
    def train(self, agent: Agent, train_cycles=100):
        """
        This is the main entry point for the application. It will process and train the agent on the specified target

        > In case "kubernetes" is the target, we push the agent towards the amesa-k8s-controller, either over the
        > no-code app or directly (in case of dev mode)

        Args:
            agent (Agent): The agent to train
            train_cycles (int): The number of training cycles to run

        Returns:
            None
        """
        return async_util.async_to_sync(self._train)(agent, train_cycles)

    def validate(self, agent: Agent) -> bool:
        return async_util.async_to_sync(self._validate)(agent)

    async def _validate(self, agent: Agent) -> bool:
        """
        Validate the agent's environment and skills before training

        Args:
            agent (Agent): The agent to validate

        Returns:
            Tuple[bool, List[str]]: A tuple containing a boolean indicating if the validation was successful and a list of errors if any
        """
        errors = {}

        for skill in agent.get_all_skills():
            skill_name = skill.get_name()
            logger.info(
                f"[{type(skill).__name__}][{skill_name}] Initializing Training for Skill"
            )

            skill_context = SkillProcessorContext(
                agent=agent,
                skill=skill,
                network_mgr=self.network_mgr,
                is_training=False,
                is_validating=True,  # we are validating
                for_skill_group=False,
            )
            t0 = time.time()
            dataset = await inference_episode_benchmark(
                skill_context=skill_context,
                benchmark_config=BenchmarkConfig(),
                scenario=None,
                target_config=self.config.target,
                env_init=self.config.env.init
            )
            t1 = time.time()

            # compute time taken for validation, in seconds
            validation_time = t1 - t0
            # validate the dataset
            is_valid, skill_errors = validate_util.validate_dataset(dataset)

            if is_valid and not skill.is_controller():
                validate_util.adjust_resources(skill, len(dataset), validation_time)

            if len(skill_errors) > 0:
                errors[skill_name] = skill_errors

        if len(errors) > 0:
            logger.error("Validation failed with the following errors:")
            for skill_name, error_list in errors.items():
                logger.error(f"Skill: {skill_name}")
                for error in error_list:
                    logger.error(f"  - {error}")
            return False
        else:
            logger.info("Agent validation successful, no errors found.")
            return True

    async def _train_execute(self, agent: Agent, train_cycles: int = 100):
        logger.info("Training the agent...")
        for skill_batch in agent.get_training_order():
            skill_batch_str = ", ".join(skill_batch)
            logger.info(f"Training batch: {skill_batch_str}")

            # TODO: We should try to train the skill_batch in parallel!
            for skill_name in skill_batch:
                skill_trained_successfully = False

                while not skill_trained_successfully:
                    skill = agent.get_node_by_name(skill_name)
                    logger.info(
                        f"[{type(skill).__name__}][{skill_name}] Initializing Training for Skill"
                    )

                    self.trainer = self._create_trainer(agent, skill, self.config)
                    self.trainer.train(train_cycles)

                    telemetry_historian.sink(
                        category="agent",
                        category_sub="skill-training",
                        data={
                            "name": skill.get_name(),
                            "type": type(skill),
                            "is_done": True,
                        },
                    )
                    skill_trained_successfully = True

                # mark all resources as unused
                # TODO: Be more careful
                # logger.info("Marking all resources as unused...")
                # await self.network_mgr.set_status_all.remote(SimStatus.SIM_CLIENT_DISCONNECTED)
        self.trainer = None

    async def _train_execute_v2(self, agent: Agent, train_cycles: int = 100):
        """
        V2 training execution that breaks the training batch into individual groups:
        1. Sim group - responsible for running simulations
        2. Remote skill - executes skill logic remotely
        3. Inference node - performs policy inference
        4. Perceptors (if needed) - pre-processes observations
        5. Controllers (if needed) - post-processes actions

        Uses event-based architecture with Redis Streams for coordination.
        """
        logger.info("Training the agent using V2 event-based architecture...")

        # Import V2 components
        from amesa_train.networking.episode_manager import EpisodeManagerEventBase

        v2_config = self.config.target.v2

        # Initialize episode manager for coordination
        episode_manager = EpisodeManagerEventBase(
            episode_manager_id=f"episode-manager-{settings.RUN_ID}",
            redis_url=v2_config.redis_url,
            sim_observation_topic=v2_config.sim_observation_topic,
            skill_action_topic=v2_config.skill_action_topic,
            output_topic=v2_config.episode_topic,
            pause_topic=v2_config.pause_topic,
            resume_topic=v2_config.resume_topic,
            consumer_group=v2_config.consumer_group,
            batch_size=v2_config.batch_size,
            max_episodes_in_memory=v2_config.max_episodes_in_memory,
            episode_timeout=v2_config.episode_timeout,
            ppo_training_samples=v2_config.ppo_training_samples,
            enable_ppo_training=v2_config.enable_ppo_training,
        )

        logger.info("Initializing V2 training groups...")

        # Get training order from agent
        for skill_batch in agent.get_training_order():
            skill_batch_str = ", ".join(skill_batch)
            logger.info(f"Training batch (V2): {skill_batch_str}")

            for skill_name in skill_batch:
                skill = agent.get_node_by_name(skill_name)
                logger.info(
                    f"[{type(skill).__name__}][{skill_name}] Setting up V2 training groups"
                )

                # Break out training into individual groups
                training_groups = self._setup_v2_training_groups(
                    agent=agent,
                    skill=skill,
                    episode_manager=episode_manager,
                    v2_config=v2_config
                )

                logger.info(f"Created {len(training_groups)} training groups:")
                for group_name in training_groups.keys():
                    logger.info(f"  - {group_name}")

                # Start all training groups
                logger.info("Starting training groups...")
                await self._start_v2_training_groups(training_groups)

                # Start episode manager
                logger.info("Starting episode manager...")
                asyncio.create_task(episode_manager.start())

                # Monitor training progress
                logger.info(f"Training {skill_name} for {train_cycles} cycles...")
                await self._monitor_v2_training(
                    episode_manager=episode_manager,
                    training_groups=training_groups,
                    train_cycles=train_cycles,
                    skill_name=skill_name
                )

                # Stop training groups
                logger.info("Stopping training groups...")
                await self._stop_v2_training_groups(training_groups)

                telemetry_historian.sink(
                    category="agent",
                    category_sub="skill-training-v2",
                    data={
                        "name": skill.get_name(),
                        "type": type(skill),
                        "is_done": True,
                        "architecture": "event-based",
                    },
                )

        logger.info("V2 training complete")
        self.trainer = None

    def _setup_v2_training_groups(
        self, agent: Agent, skill: Skill, episode_manager, v2_config
    ) -> dict:
        """
        Set up individual training groups for V2 architecture.
        Returns a dictionary of group_name -> group_instance.
        """
        training_groups = {}

        # 1. Sim Group - manages simulator instances
        if v2_config.enable_sim_group:
            logger.info("Setting up Sim Group...")
            # TODO: Implement sim group that publishes observations to Redis Stream
            training_groups["sim_group"] = {
                "type": "sim",
                "config": {
                    "redis_url": v2_config.redis_url,
                    "output_topic": v2_config.sim_observation_topic,
                    "sim_image": v2_config.sim_image,
                }
            }

        # 2. Remote Skill - executes skill logic
        if v2_config.enable_remote_skill:
            logger.info("Setting up Remote Skill Group...")
            # TODO: Implement remote skill that consumes observations and publishes actions
            training_groups["remote_skill"] = {
                "type": "remote_skill",
                "config": {
                    "redis_url": v2_config.redis_url,
                    "input_topic": v2_config.sim_observation_topic,
                    "output_topic": v2_config.skill_action_topic,
                    "skill": skill,
                    "agent": agent,
                }
            }

        # 3. Inference Node - performs policy inference
        if v2_config.enable_inference_node:
            logger.info("Setting up Inference Node...")
            # TODO: Implement inference node that receives episode data and performs inference
            training_groups["inference_node"] = {
                "type": "inference",
                "config": {
                    "redis_url": v2_config.redis_url,
                    "input_topic": v2_config.episode_topic,
                    "output_topic": v2_config.skill_action_topic,
                    "pause_topic": v2_config.pause_topic,
                    "resume_topic": v2_config.resume_topic,
                    "skill": skill,
                }
            }

        # 4. Perceptors (if needed) - pre-process observations
        if v2_config.enable_perceptors and agent.get_perceptors():
            logger.info("Setting up Perceptors...")
            training_groups["perceptors"] = {
                "type": "perceptor",
                "config": {
                    "redis_url": v2_config.redis_url,
                    "input_topic": v2_config.sim_observation_topic,
                    "output_topic": f"{v2_config.sim_observation_topic}.processed",
                    "perceptors": agent.get_perceptors(),
                }
            }

        # 5. Controllers (if needed) - post-process actions
        if v2_config.enable_controllers and agent.get_controllers():
            logger.info("Setting up Controllers...")
            training_groups["controllers"] = {
                "type": "controller",
                "config": {
                    "redis_url": v2_config.redis_url,
                    "input_topic": v2_config.skill_action_topic,
                    "output_topic": f"{v2_config.skill_action_topic}.processed",
                    "controllers": agent.get_controllers(),
                }
            }

        return training_groups

    async def _start_v2_training_groups(self, training_groups: dict):
        """Start all training groups."""
        for group_name, group_config in training_groups.items():
            logger.info(f"Starting {group_name}...")
            # TODO: Implement actual group startup logic
            # This would typically involve:
            # - Creating actors/processes for each group
            # - Connecting them to Redis
            # - Starting their event loops
            pass

    async def _monitor_v2_training(
        self, episode_manager, training_groups: dict, train_cycles: int, skill_name: str
    ):
        """Monitor V2 training progress."""
        cycles_completed = 0

        while cycles_completed < train_cycles:
            await asyncio.sleep(5)  # Check every 5 seconds

            # Get episode stats
            stats = episode_manager.get_episode_stats()

            logger.info(
                f"Training progress: {cycles_completed}/{train_cycles} cycles, "
                f"{stats.get('total_episodes', 0)} episodes, "
                f"{stats.get('ppo_training_stats', {}).get('training_samples_collected', 0)} samples collected"
            )

            # TODO: Implement actual cycle counting logic based on episodes completed
            cycles_completed += 1

    async def _stop_v2_training_groups(self, training_groups: dict):
        """Stop all training groups."""
        for group_name, group_config in training_groups.items():
            logger.info(f"Stopping {group_name}...")
            # TODO: Implement actual group shutdown logic
            pass

    @override
    async def _train(self, agent: Agent, train_cycles=100):
        """
        This is the main entry point for the application. It will process and train the agent on the specified target

        > In case "kubernetes" is the target, we push the agent towards the amesa-k8s-controller, either over the
        > no-code app or directly (in case of dev mode)

        > In case "v2" is the target, we use event-based architecture with Redis Streams and break out
        > training into individual groups (sim, remote skill, inference node, perceptors, controllers)

        Args:
            agent (Agent): The agent to train
            train_cycles (int): The number of training cycles to run

        Returns:
            None
        """
        # Handle Kubernetes
        is_kubernetes = await self.handle_kubernetes(agent, train_cycles)

        if is_kubernetes:
            logger.warning(
                "Job was submitted on Kubernetes, stopping the local trainer and handing over to the Kubernetes controller. Check the `kubectl` output for more information."
            )
            return

        # Initialize
        await self.init(agent, train_cycles)

        success = self.validate(agent)

        if not success:
            logger.error(
                "Agent validation failed, cannot train. Please fix the issues and try again."
            )
            return

        logger.info("    - Implementation: OK")
        logger.info("Train - PreChecks: OK")

        # Train the skills
        self.print_log_line("Start Training")

        # Let Kubernetes know we are started
        if self.config.target.type == TrainerTargetEnum.KUBERNETES_JOB:
            await ControllerService().send_status(JobStatusEnum.STARTED)

        # Perform the actual training
        try:
            # Route to V2 training if v2 target is specified
            if self.config.target.type == TrainerTargetEnum.V2:
                logger.info("Using V2 event-based training architecture")
                await self._train_execute_v2(agent, train_cycles)
            else:
                # Standard Ray-based training
                await self._train_execute(agent, train_cycles)
        except Exception as e:
            # Print a clean stack trace for better readability
            logger_util.print_error(logger, e)

            # Raise an exception to ensure we stop
            raise Exception("An error occurred during training, halting...")

        try:
            self.postprocess(agent, self.config.post_processing)
        except Exception as e:
            logger_util.print_error(logger, e)

            # Raise an exception to ensure we stop
            logger.info("An error occured during post processing, halting...")

        # Notify the Kubernetes controller that the job is done
        if self.config.target.type == TrainerTargetEnum.KUBERNETES_JOB:
            await ControllerService().send_status(JobStatusEnum.DONE)

        # Cleanup
        logger.debug("Training Done, Cleaning up resources...")

    def _create_trainer(
        self,
        agent: Agent,
        skill: Union[Skill, SkillSelector, SkillCoordinatedSet],
        config: TrainerConfig,
    ):
        skill_trainer = create_skill_trainer(agent, skill, config)

        return skill_trainer

    async def _create_executable_agent(
        self, agent: Agent, skill: Skill
    ) -> Future[SkillProcessorBase]:
        """
        Create an executable agent by wrapping the top skill in a processor
        """
        ModelCatalog.register_custom_model(
            "composabl_action_masking_model", TorchActionMask
        )

        config = SkillProcessorContext(
            agent=agent,
            skill=skill,
            network_mgr=self.network_mgr,
            is_training=False,
            is_validating=False,
            for_skill_group=False,
        )
        return await make_skill_processor(config)

    def is_running(self):
        return ray.is_initialized()

    def close(self):
        """
        Close the trainer

        This will stop the trainer and all the actors
        """
        return async_util.async_to_sync(self._close)()

    async def _close(self):
        """
        Close the trainer

        This will stop the trainer and all the actors
        """
        logger.info("Closing the trainer...")
        if not self.is_running():
            return

        if self.trainer is not None:
            # there is no way to stop a policy update mid-way, so we need to wait for it to finish
            # This stop is blocking on the policy update to finish and for trainer to clean itself up
            logger.info("Gracefully stopping the trainer...")
            self.trainer.export()
            self.trainer.stop()

            self.trainer = None

        # Remove all the actors
        if self.network_mgr is not None:
            try:
                await self.network_mgr.stop_all.remote()
            except Exception:
                pass
            logger.debug("- Simulators: Stopped")

            self.network_mgr.terminate.remote()
            self.network_mgr = None

        logger.debug("- Sim Manager: Stopped")

        # Finally shutdown ray
        # note: ray can be started even if the trainer is not running, so we shut it down whenever
        # it is initialized
        ray.shutdown()
        logger.debug("- Ray: Stopped")

        try:
            config_type = self.config.target.type
        except Exception:
            config_type = None

        if config_type == TrainerTargetEnum.KUBERNETES_JOB:
            await ControllerService().send_status(JobStatusEnum.STOPPED)
            logger.debug("- Kubernetes: Stopped")

        # Reset the initialized flag
        self._is_initialized = False

    def _handle_signal_interrupt(self, signal, frame):
        logger.info("\nInterrupt caught, cleaning up...")
        async_util.async_to_sync(self.close)()

        sys.exit(0)

    def postprocess(self, agent: Agent, postprocess_config: PostProcessingConfig):
        """
        Postprocess the agent

        Args:
            agent (Agent): The agent to postprocess
            options (PostProcessingConfig): The options for postprocessing

        Returns:
            None
        """
        """
        Postprocess the agent

        Args:
            agent (Agent): The agent to postprocess
            options (PostProcessingConfig): The options for postprocessing

        Returns:
            None
        """

        postprocess(
            agent=agent,
            network_mgr=self.network_mgr,
            postprocess_config=postprocess_config,
            target_config=self.config.target,
            output_dir=self.config.active_working_directory
        )
