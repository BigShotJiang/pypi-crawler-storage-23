# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Any, Dict, Iterable, SupportsFloat, Tuple, Union

import amesa_core.networking.sim.client as client
import amesa_core.utils.logger as logger_util
import numpy as np
from amesa_core.agent.scenario import Scenario
from amesa_core.agent.skill import SkillSelector, Skill
from amesa_core.agent.skill.skill_teacher import SkillTeacher
from amesa_core.networking.sim.client_config import ClientConfig
from amesa_core.networking.status_enum import SimStatus
from amesa_core.singletons.telemetry_historian import telemetry_historian
from amesa_core.spaces import convert_to_amesa_space
from amesa_core.spaces.space import Space
from amesa_core.utils import async_util, warnings_util

from ray import ObjectRef
from ray.rllib.env.apis.task_settable_env import TaskSettableEnv

from amesa_train.actor.sim_mgr_actor import NetworkMgrActor
from amesa_train.skill_processors import SkillProcessorBase, make_skill_processor
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)

logger = logger_util.get_logger(__name__)

"""
Ray uses an environment to communicate with the simulator.
We configure an environment that takes care of:
1. Creating a simulator
2. Creating a client interface to the simulator

It extends the TasksettableEnv class
- TasksettableEnv: https://github.com/ray-project/ray/blob/master/rllib/env/apis/task_settable_env.py
    * Interface is required to be used with MAML for curriculum learning
    * It allows us to go over tasks in a specific order (e.g. curriculum).
    * It is based on how humans learn, starting simpler and then moving to
      more complex tasks
    * MAML: https://paperswithcode.com/method/maml

Note: this cannot be async as it is used with the RLLib framework which requires sync method definitions
"""

warnings_util.apply()


def warm_up_scenario_flow_check(
    scenario: Scenario,
    prior_skills: Iterable[Skill],
):
    """
    Check if the scenario has a flow_id and if so, check that all prior skills' scenarios and
    see if they mastered the scenarios that have the same flow_id.
    """
    if len(scenario.get_flow_ids()) > 0:
        for flow_id in scenario.flow_ids:
            for skill in prior_skills:
                if skill.done_training:
                    continue
                scenario_idx = skill.get_scenarios_current_idx()
                if scenario_idx is None:
                    continue
                for index, prior_skill_scenario in enumerate(skill.get_scenarios()):
                    if index > scenario_idx:
                        continue
                    if flow_id in prior_skill_scenario.get_flow_ids():
                        return False
    return True


class AmesaEnv(TaskSettableEnv):
    def __init__(
        self,
        run_id,
        network_mgr_actor: "ObjectRef[NetworkMgrActor]",
        sim_id,
        env_config_amesa: ClientConfig,
    ):
        super().__init__()

        if network_mgr_actor is None:
            raise Exception("network_mgr_actor is required")

        if sim_id is None:
            raise Exception("sim_id is required")

        if env_config_amesa is None or not isinstance(
            env_config_amesa, ClientConfig
        ):
            raise Exception("env_config_amesa is required")

        # Create a Simulator Mgr actor based on the passed reference
        self.network_mgr_actor = network_mgr_actor
        self.sim_id = sim_id
        self.run_id = run_id
        self.episode_number = 0

        self.success_counter = 0
        self.current_scenario = None
        self.scenarios_trained = []

        # Enable the historian on the Worker
        telemetry_historian.enable(
            run_id=self.run_id,
            moniker_mqtt=env_config_amesa.historian_moniker,
            topic=env_config_amesa.historian_topic,
            source="sdk-rollout-worker-env-composabl",
        )

        self.sim_sensor_space = None
        self.sim_action_space = None
        self.prev_amesa_obs = None
        self.prev_sim_sensors = None

        self.env_config_amesa = env_config_amesa
        self.agent = self.env_config_amesa.agent
        self.skill = self.env_config_amesa.skill

        self.validate_env = self.env_config_amesa.validate_env

        # Initialize Everything
        async_util.async_to_sync(self.init)()

    def get_agent_ids(self):
        return self._agent_ids

    async def init(self) -> None:
        self.sim_address = await self.network_mgr_actor.call_sim_mgr.remote("sim_get_address", self.sim_id)

        if not self.sim_address:
            raise Exception(f"sim_address is required: {self.sim_address}")

        logger.debug(
            f"Initializing the Client Interface on address '{self.sim_address}'"
        )
        self.client: client.Client = await self._create_client(
            self.run_id,
            self.sim_id,
            self.sim_address,
        )

        logger.debug("Setting initial scenario")

        await self._set_scenario_async(
            self.env_config_amesa.skill.get_current_scenario()
        )

        logger.debug("Scenario set")

    async def _create_client(self, run_id, sim_id, address) -> client.Client:
        logger.debug(
            f"Creating a '{self.env_config_amesa.trainer.target.protocol}' Client Interface on address '{address}' (run_id: {run_id}, sim_id: {sim_id}, client_id: {self.env_config_amesa.id})"
        )

        if self.env_config_amesa.id is None:
            raise Exception(
                f"env_config_amesa.id is required: {self.env_config_amesa}"
            )

        client_id = self.env_config_amesa.id

        c = client.make(
            run_id,
            sim_id,
            client_id,
            address,
            self.env_config_amesa.trainer.env.init,
            self.env_config_amesa.trainer.target.protocol,
        )

        self.address = address

        # Crash if we can't find the following as it means something is wrong
        self.sim_sensor_space = convert_to_amesa_space(await c.sensor_space_info())
        self.sim_action_space = convert_to_amesa_space(await c.action_space_info())

        # propogate obs and action space to the skill object
        # Action space is needed for the skill processor
        self.set_skill_sensor_space(self.sim_sensor_space)

        self.set_action_space(self.sim_action_space)

        # Make the skill processor
        context = SkillProcessorContext(
            agent=self.agent,
            skill=self.skill,
            network_mgr=self.network_mgr_actor,
            is_training=True,
            is_validating=self.validate_env,
        )
        self.skill_processor: SkillProcessorBase = await make_skill_processor(context)

        # Set required Ray env attributes
        # note: we set the sensor and action space here as they come from the skill processor
        # the skill processor will convert this to a composabl space
        self.observation_space: Space = self.skill_processor.get_skill_sensor_space()
        self.action_space: Space = self.skill_processor.get_action_space()
        self.spec = c.spec

        # TODO: This was required by gymnasium, we should remove this?
        self.max_steps = self.env_config_amesa.max_steps

        return c

    def sensor_space_info(self):
        return self.observation_space

    def action_space_info(self):
        return self.action_space

    def get_success_rate(self) -> int:
        return self.success_counter

    def reset_success_rate(self) -> None:
        self.success_counter = 0

    def get_skill(self) -> Union[SkillSelector, Skill]:
        return self.skill

    def set_skill_sensor_space(self, sensor_space) -> None:
        if self.skill.has_custom_sensor_space():
            return
        self.env_config_amesa.skill.set_sim_sensor_space(sensor_space)
        self.env_config_amesa.agent.set_sim_sensor_space(sensor_space)
        self.env_config_amesa.agent.get_node_by_name(
            self.env_config_amesa.skill.get_name()
        ).set_sim_sensor_space(sensor_space)

        # propogate the sensor space to controllers
        self.env_config_amesa.agent.set_sim_sensor_space(sensor_space)

    def set_action_space(self, action_space) -> None:
        if self.skill.has_custom_action_space():
            return
        self.env_config_amesa.skill.set_action_space(action_space)
        self.env_config_amesa.agent.set_action_space(action_space)
        self.env_config_amesa.agent.get_node_by_name(
            self.env_config_amesa.skill.get_name()
        ).set_action_space(action_space)

        self.action_space = action_space

    def get_teacher(self) -> SkillTeacher:
        return self.skill_processor.get_teacher()

    def skill_needs_warmup(self) -> bool:
        return self.agent.skill_needs_warmup(self.skill)

    async def warmup(self, sim_sensors, info) -> None:
        # Warmup the skill
        prior_skills = self.agent.get_older_sibling_skills(self.skill)

        if not warm_up_scenario_flow_check(
            self.skill.get_current_scenario(), prior_skills
        ):
            logger.warning(
                "The prior skills have not mastered the scenario flow, continueing anyways"
            )
        sim_terminated = False
        sim_truncated = False
        teacher_terminated = False
        teacher_success = False
        prev_action = None
        for skill_name in prior_skills:
            # create a skill processor
            skill = self.agent.get_node_by_name(skill_name)
            context = SkillProcessorContext(
                agent=self.agent,
                skill=skill,
                network_mgr=self.network_mgr_actor,
                is_training=False,
                is_validating=False,
                for_skill_group=False,
            )
            skill_processor: SkillProcessorBase = await make_skill_processor(context)
            # execute the skill processor until it returns done
            while not teacher_success and not teacher_terminated:
                (
                    _amesa_sensors_filtered,
                    _unfiltered_obs,
                    _teacher_reward,
                    teacher_success,
                    teacher_terminated,
                    truncated,
                ) = await self.skill_processor.step(
                    sim_sensors,
                    0.0,
                    sim_terminated,
                    sim_truncated,
                    info,
                    prev_action,
                )
                action = await skill_processor._execute(sim_sensors)
                prev_action = action
                (
                    sim_sensors,
                    sim_reward,
                    sim_terminated,
                    sim_truncated,
                    info,
                ) = await self.client.step(action)
            if teacher_terminated or sim_terminated:
                raise Exception(
                    "Skill processor terminated before the skill was warmed up"
                )

        # TODO: check if the skill processor reports done, NOT the sim
        return sim_sensors, info

    def check_sim_sensors(self, sim_sensors) -> None:
        return self.sim_sensor_space.contains(sim_sensors)

    async def _reset(
        self, *, seed=None, options=None
    ) -> Tuple[Any, Dict[str, Any]]:
        """
        Reset the environment to an initial internal state, returning an initial sensor and info

        During a reset, we perform the following actions:
        1. Reset the teacher processor
        2. Reset the simulator and get the sensor, info
        3. Transform the sensor to the teacher's sensor space
        4. Transform the sensor to the agent's sensor space
        5. Apply the action mask to the sensor space
        6. Return the sensor, info to the agent
        """
        self.episode_number += 1

        (sim_sensors, info) = await self.client.reset()

        # Allow for more flexibility based on the sim sensors coming in
        # e.g., a box of shape (1,) will allow a single value or an array with 1 element
        sim_sensors = self.sim_sensor_space.reshape(sim_sensors)

        if self.skill_needs_warmup():
            retry_count = 0
            while retry_count < 10:
                # logger.info("Warming up the skill...")
                try:
                    sim_sensors, info = await self.warmup(sim_sensors, info)
                except Exception as e:
                    logger.warning(
                        f"Failed to warmup the skill: {e}, retrying... {retry_count} / 10"
                    )
                    retry_count += 1
                    import traceback

                    print(traceback.format_exc())
                    continue
                break
            if retry_count >= 10:
                raise Exception("Failed to warmup the skill after 10 retries")

        await self.skill_processor.reset()
        (
            amesa_sensors_filtered,
            unfiltered_obs,
        ) = await self.skill_processor.process_sim_sensors(
            sim_sensors, info.get("action_mask", None), previous_action=None
        )

        self.prev_amesa_obs = unfiltered_obs
        self.prev_sim_sensors = sim_sensors
        return amesa_sensors_filtered, info

    def reset(self, *, seed=None, options=None) -> Tuple[Any, Dict[str, Any]]:
        return async_util.async_to_sync(self._reset)(
            seed=seed, options=options
        )

    def step(self, action) -> Tuple[Any, SupportsFloat, bool, bool, Dict[str, Any]]:
        """
        https://docs.ray.io/en/latest/rllib/package_ref/env/multi_agent_env.html#ray.rllib.env.multi_agent_env.MultiAgentEnv.step
        """
        return async_util.async_to_sync(self._step)(action)

    def render(self) -> Any:
        return async_util.async_to_sync(self._render_async)()

    def get_task(self) -> Any:
        return self.current_scenario

    def set_render_mode(self, render_mode) -> None:
        async_util.async_to_sync(self._set_render_mode_async)(render_mode)

    def set_task(self, scenario) -> None:
        async_util.async_to_sync(self._set_task_async)(scenario)

    def get_scenario(self) -> Any:
        async_util.async_to_sync(self._get_scenario_async)()

    def set_scenario(self, scenario) -> None:
        async_util.async_to_sync(self._set_scenario_async)(scenario)

    def close(self) -> None:
        self._close_async()

    async def _step(
        self, action
    ) -> Tuple[Any, SupportsFloat, bool, bool, Dict[str, Any]]:
        if isinstance(self.skill, SkillSelector):
            # if the child skill's aren't already trained (in the case of env validation),
            # then we just have to assume the children behave properly (since they will also be validated for correctness)
            # A child misbehaving is no concern of the parent
            if self.validate_env:
                action_processed = (await self.client.action_space_sample()).sample()
                self.prev_action = action_processed
            else:
                # For selectors, we have to query the selector children, according to the action, and get the child's action
                (
                    action_processed,
                    selector_action,
                ) = await self.skill_processor.process_action(
                    self.prev_sim_sensors, self.prev_amesa_obs, action
                )
                self.prev_action = selector_action
        else:
            action_processed = await self.skill_processor.process_action(
                self.prev_sim_sensors,
                self.prev_amesa_obs,
                action,
                unsquash_action=False,
            )
            self.prev_action = action_processed

        # Check to make sure the action conforms to the action space
        action_processed = self.sim_action_space.coerce_sample(action_processed)

        telemetry_historian.sink(
            category="base-skill-env",
            category_sub="step",
            data={"action": action_processed},
        )
        (
            sim_sensors,
            sim_reward,
            sim_terminated,
            sim_truncated,
            info,
        ) = await self.client.step(action_processed)

        # Allow for more flexibility based on the sim sensors coming in
        # e.g., a box of shape (1,) will allow a single value or an array with 1 element
        sim_sensors = self.sim_sensor_space.reshape(sim_sensors)

        # check to make sure the obs conforms to the sensor space
        sensors_in_range = self.check_sim_sensors(sim_sensors)

        (
            amesa_sensors_filtered,
            unfiltered_obs,
            teacher_reward,
            teacher_success,
            teacher_terminated,
            truncated,
        ) = await self.skill_processor.step(
            sim_sensors,
            sim_reward,
            sim_terminated,
            sim_truncated,
            info,
            self.prev_action,
        )

        truncated = False
        terminated = teacher_terminated or teacher_success or sim_terminated or not sensors_in_range

        # if the teacher terminated, we cannot also success
        if teacher_success and not teacher_terminated:
            self.success_counter += 1
        elif teacher_terminated:
            self.success_counter -= 1
            self.success_counter = max(0, self.success_counter)

        self.prev_amesa_obs = unfiltered_obs
        self.prev_sim_sensors = sim_sensors

        # If we're at the end of the episode, get frame and put to historian
        if terminated or truncated:
            await self.get_and_send_frame_to_historian()
            telemetry_historian.sink(
                category="Training", category_sub="episode_end", data=unfiltered_obs
            )

        return amesa_sensors_filtered, teacher_reward, terminated, truncated, info

    def check_action(self, action) -> bool:
        """
        Check if the action is in the action space
        """
        return self.sim_action_space.contains(action)

    async def get_and_send_frame_to_historian(self):
        frame = None

        try:
            frame = await self.client.get_render()
        except Exception:
            pass

        if frame is None:
            return

        # If the frame is a numpy array, convert it to a string
        if isinstance(frame, np.ndarray):
            frame
            frame = np.array2string(frame, separator=",")

        telemetry_historian.sink(
            category=f"f{self.episode_number}", category_sub="end_frame", data=frame
        )

    async def _close_async(self):
        logger.debug("Closing the Client Interface")

        if self.client is not None:
            await self.client.close()

        logger.debug("Detaching the Simulator and make it available again in the pool")
        self.network_mgr_actor.sim_set_status.remote(
            self.sim_id, SimStatus.SIM_CLIENT_DISCONNECTED
        )

    async def _set_scenario_async(self, scenario):
        if not scenario:
            logger.warning("We wanted to set a scenario but it was None. Sending empty Scenario.")
            scenario = Scenario()

            return await self.client.set_scenario(scenario)

        if scenario not in self.scenarios_trained:
            self.scenarios_trained.append(scenario)

        self.current_scenario = scenario
        # Log scenario index / total as before, and also include scenario fields for easier debugging.
        try:
            scenario_fields = scenario.to_json()
        except Exception:
            scenario_fields = "N/A"

        logger.info(
            "Setting scenario to '%s' / '%s' | fields: %s",
            self.env_config_amesa.skill.get_scenarios_current_idx() + 1,
            len(self.env_config_amesa.skill.get_scenarios()),
            scenario_fields,
        )

        return await self.client.set_scenario(scenario)

    async def _get_scenario_async(self):
        return self.current_scenario

    async def _set_task_async(self, scenario):
        self.current_scenario = scenario
        return await self.client.set_scenario(scenario)

    async def _set_render_mode_async(self, render_mode):
        self.render_mode = render_mode
        return await self.client.set_render_mode(render_mode)

    async def _render_async(self):
        return await self.client.get_render()
