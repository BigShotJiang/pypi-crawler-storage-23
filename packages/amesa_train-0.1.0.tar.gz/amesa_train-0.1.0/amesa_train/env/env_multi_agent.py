# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Any, Dict, SupportsFloat, Tuple, Union

from amesa_core import SkillCoordinatedPopulation, SkillCoordinatedSet
import amesa_core.utils.logger as logger_util
from amesa_core.networking.sim.client_config import ClientConfig
from amesa_core.singletons.telemetry_historian import telemetry_historian
from amesa_core.utils import warnings_util

from .env import AmesaEnv

from ray.rllib.env.multi_agent_env import MultiAgentEnv


logger = logger_util.get_logger(__name__)

"""
Ray uses an environment to communicate with the simulator.
We configure an environment that takes care of:
1. Creating a simulator
2. Creating a client interface to the simulator

It extends the TasksettableEnv class
- TasksettableEnv: https://github.com/ray-project/ray/blob/master/rllib/env/apis/task_settable_env.py
    * Interface is required to be used with MAML for curriculum learning
    * It allows us to go over tasks in a specific order (e.g. curriculum).
    * It is based on how humans learn, starting simpler and then moving to
      more complex tasks
    * MAML: https://paperswithcode.com/method/maml
"""

warnings_util.apply()


class AmesaEnvMultiAgent(AmesaEnv, MultiAgentEnv):
    def __init__(self, run_id, sim_mgr, sim_id, env_config_amesa: ClientConfig):
        # add the populations to the env init so that the sim spawns the correct amount of agents
        self.skill = env_config_amesa.skill

        self._agent_ids = set(self.skill.get_skill_names())  # required by ray

        super().__init__(run_id, sim_mgr, sim_id, env_config_amesa)

    def get_skill(self) -> Union[SkillCoordinatedPopulation, SkillCoordinatedSet]:
        return self.skill

    async def _reset(
        self, *, seed=None, options=None
    ) -> Tuple[Any, Dict[str, Any]]:
        amesa_sensors_filtered, info = await super()._reset(seed=seed, options=options)
        info = {}
        for agent_id in self._agent_ids:
            info[agent_id] = {}
        info["__all__"] = {}
        return amesa_sensors_filtered, info  # extra policy infos dict, required by ray

    async def _step(
        self, action
    ) -> Tuple[Any, SupportsFloat, bool, bool, Dict[str, Any]]:
        action_processed = await self.skill_processor.process_action(
            self.prev_sim_sensors, self.prev_amesa_obs, action
        )
        self.prev_action = action_processed

        (
            sim_sensors,
            sim_reward,
            sim_terminated,
            sim_truncated,
            info,
        ) = await self.client.step(action_processed)

        # Allow for more flexibility based on the sim sensors coming in
        # e.g., a box of shape (1,) will allow a single value or an array with 1 element
        sim_sensors = self.sim_sensor_space.reshape(sim_sensors)

        # check to make sure the obs conforms to the sensor space
        self.check_sim_sensors(sim_sensors)
        (
            amesa_sensors_filtered,
            unfiltered_obs,
            teacher_reward,
            teacher_success,
            teacher_terminated,
            truncated,
        ) = await self.skill_processor.step(
            sim_sensors,
            sim_reward,
            sim_terminated,
            sim_truncated,
            info,
            self.prev_action,
        )

        if teacher_success["__all__"]:
            self.success_counter += 1
        elif teacher_terminated["__all__"]:
            self.success_counter -= 1
            self.success_counter = max(0, self.success_counter)

        self.prev_amesa_obs = unfiltered_obs
        self.prev_sim_sensors = sim_sensors

        # If we're at the end of the episode, get frame and put to historian
        if teacher_terminated or truncated:
            await self.get_and_send_frame_to_historian()
            telemetry_historian.sink(
                category="Training", category_sub="episode_end", data=unfiltered_obs
            )

        return (
            amesa_sensors_filtered,
            teacher_reward,
            teacher_terminated,
            truncated,
            info,
        )
