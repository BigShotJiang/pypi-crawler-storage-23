# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
from typing import Dict, List, Optional, Union
from typing_extensions import Annotated

from pydantic import BaseModel, BeforeValidator, PlainSerializer
import numpy as np


def nd_array_custom_before_validator(x):
    # custome before validation logic
    return x


def nd_array_custom_serializer(x):
    # custome serialization logic
    return str(x)


NdArray = Annotated[
    np.ndarray,
    BeforeValidator(nd_array_custom_before_validator),
    PlainSerializer(nd_array_custom_serializer, return_type=str),
]


# Create a BaseModel implemention that is a Union of an any dict with ClientConfigBase
class TeacherStepData(BaseModel):
    state: Dict[str, Union[float, dict, tuple, str]] = None
    action: Union[NdArray, int, float, dict, tuple] = None
    top_selector_action: Optional[Union[NdArray, int, float, dict, tuple]] = None
    teacher_reward: float = None
    coordinated_reward: Optional[Dict[str, float]] = None
    teacher_success: bool = None
    teacher_terminal: bool = None

    class Config:
        arbitrary_types_allowed = True


class CoordinatedTeacherStepData(BaseModel):
    state: Dict[str, Dict[str, Union[float, str]]] = None
    action: Dict[str, Union[NdArray, int, float, dict, tuple]] = None
    teacher_reward: Dict[str, float] = None
    teacher_success: Dict[str, bool] = None
    teacher_terminal: Dict[str, bool] = None
    coordinated_reward: Optional[Dict[str, Dict[str, float]]] = None
    coordinated_reward: Optional[List[float]] = None

    class Config:
        arbitrary_types_allowed = True
