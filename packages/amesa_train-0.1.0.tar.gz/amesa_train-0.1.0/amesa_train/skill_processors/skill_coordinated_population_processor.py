# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import asyncio
from copy import deepcopy

import amesa_core.spaces as amesa_spaces
import amesa_core.utils.logger as logger_util
from amesa_core import SkillCoordinatedPopulation
from amesa_core.agent.skill.skill_coach import SkillCoach
from amesa_core.decorators.ensure_is_initialized import ensure_cls_is_initialized
from amesa_core.singletons.telemetry_historian import telemetry_historian

from amesa_train.skill_processors.skill_processor_base import SkillProcessorBase
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)

logger = logger_util.get_logger(__name__)


@ensure_cls_is_initialized
class SkillCoordinatedPopulationProcessor(SkillProcessorBase):
    coach: SkillCoach

    def __init__(self, context: SkillProcessorContext):
        """
        agent: Agent - the agent
        skill: Skill - the skill that is being used to process sensors and return actions
        is_training: bool - whether or not the skill processor is being used for training currently
        """
        super().__init__(context)

        if not isinstance(self.context.skill, SkillCoordinatedPopulation):
            raise Exception(
                f"SkillCoordinatedPopulationProcessor must be used with a SkillCoordinatedPopulation, {self.context.skill.get_name()}, {type(self.context.skill)}"
            )

        # Make the teacher, which is the skill's implementation class
        self.coach = self.context.skill.get_impl_cls()()
        self.skill_processors: dict[str, SkillProcessorBase] = {}

    async def init(self):
        from amesa_train.skill_processors import make_skill_processor

        self.skill_processors = {}
        tasks: list[SkillProcessorBase] = []
        for population in self.context.skill.get_skills():
            for idx in range(population.get_amount()):
                context = SkillProcessorContext(
                    agent=self.context.agent,
                    skill=population.get_skill(),
                    is_training=self.context.is_training,
                    is_validating=self.context.is_validating,
                    is_coordinated_population=True,
                    name=f"{population.get_name()}-{idx + 1}"
                )
                tasks.append(make_skill_processor(context))
        processors: list[SkillProcessorBase] = await asyncio.gather(*tasks)
        for child_skill_processor in processors:
            self.skill_processors[
                child_skill_processor.get_name()
            ] = child_skill_processor

        self._is_initialized = True

    async def reset(self):
        self.coach = self.context.skill.get_impl_cls()()
        await asyncio.gather(
            *[
                skill_processor.reset()
                for skill_processor in self.skill_processors.values()
            ]
        )

    async def process_action(
        self, sim_sensors, amesa_obs, action, sim_action_mask=None, unsquash_action=True
    ):
        processed_actions = await self.coach.transform_action(amesa_obs, action)
        return processed_actions

    def execute(self, obs, sim_action_mask=None):
        return super().execute(obs, sim_action_mask)

    async def _execute(
        self,
        sim_sensors,
        sim_action_mask=None,
        explore=False,
        is_coordinated=True,
        previous_action=None,
        return_as_teacher_dict=False,
    ):

        if return_as_teacher_dict:
            teacher_dict = {
                "state": {},
                "action": {},
                "reward": {},
                "terminated": {},
                "success": {},
            }
        actions = {}
        if previous_action is None:
            previous_action = {}
            for skill_name, skill_processor in self.skill_processors.items():
                previous_action[skill_name] = None
        for skill_name, skill_processor in self.skill_processors.items():
            output = await skill_processor._execute(
                sim_sensors[skill_name],
                sim_action_mask,
                explore,
                is_coordinated=True,
                previous_action=previous_action,
                return_as_teacher_dict=return_as_teacher_dict,
            )
            if return_as_teacher_dict:
                teacher_dict["state"][skill_name] = output["state"]
                teacher_dict["action"][skill_name] = output["action"]
                teacher_dict["reward"][skill_name] = output["reward"]
                teacher_dict["terminated"][skill_name] = output["terminated"]
                teacher_dict["success"][skill_name] = output["success"]
                actions[skill_name] = output["action"]
            else:
                actions[skill_name] = output
        processed_actions = await self.coach.transform_action(sim_sensors, actions)

        # return the action
        if return_as_teacher_dict:
            teacher_dict["action"] = processed_actions
            return teacher_dict
        else:
            return processed_actions

    def get_skill_name(self):
        return self.context.skill.get_name()

    def get_action_space(self):
        action_space = {}
        # even though the action space won't change, might as well grab from the original source
        for skill_name, skill_processor in self.skill_processors.items():
            action_space[skill_name] = skill_processor.get_action_space()
        return amesa_spaces.Dict(action_space)

    def get_skill_sensor_space(self):
        obs_space_dict = {}

        for skill_name, skill_processor in self.skill_processors.items():
            obs_space_dict[skill_name] = skill_processor.get_skill_sensor_space()

        return amesa_spaces.Dict(obs_space_dict)

    async def process_sim_sensors(
        self, sensors, sim_action_mask=None, previous_action=None
    ):
        sensors_dict = {}
        unfiltered_sensors_dict = {}
        for skill_name, skill_processor in self.skill_processors.items():
            skill_processed_sensors = await skill_processor.process_sim_sensors(
                sensors[skill_name], sim_action_mask, previous_action
            )
            sensors_dict[skill_name] = skill_processed_sensors[0]
            unfiltered_sensors_dict[skill_name] = skill_processed_sensors[1]

        return sensors_dict, unfiltered_sensors_dict

    async def step(
        self, sim_sensors, sim_reward, sim_terminated, truncated, info, action
    ):
        """
        Stepping in a multi-agent environment in Amesa means stepping in a multi-skill environment
        we loop over the different skills and call their step functions
        we then gather these in the respective dictionaries representing these skills
        """
        (
            multi_sensors,
            multi_unfiltered_sensors,
            multi_reward,
            multi_success,
            multi_terminated,
            multi_truncated,
        ) = (
            {},
            {},
            {},
            {},
            {},
            {},
        )

        multi_truncated["__all__"] = False
        multi_success["__all__"] = True
        multi_terminated["__all__"] = False

        for skill_name, skill_processor in self.skill_processors.items():
            # Takes the sim sensor, reward, and terminated and returns
            # The filtered sensors, teacher reward, teacher success, and teacher terminated
            (
                filtered_sensors,
                amesa_sensors,
                teacher_reward,
                teacher_success,
                teacher_terminated,
                skill_truncated,
            ) = await skill_processor.step(
                sim_sensors[skill_name],
                sim_reward,
                sim_terminated,
                truncated,
                info,
                action[skill_name],
            )

            multi_sensors[skill_name] = filtered_sensors
            multi_unfiltered_sensors[skill_name] = amesa_sensors
            multi_reward[skill_name] = teacher_reward
            multi_success[skill_name] = False
            multi_terminated[skill_name] = False
            multi_truncated[skill_name] = False

        coach_reward = await self.coach.compute_reward(
            multi_sensors, action, multi_reward
        )

        # Add coach_reward to each key of multi_reward
        for skill_name in multi_reward:
            multi_reward[skill_name] += coach_reward

        multi_success["__all__"] = await self.coach.compute_success_criteria(
            sim_sensors, action
        )

        multi_terminated["__all__"] = (
            await self.coach.is_compute_done(sim_sensors, action) or sim_terminated
        )
        if multi_terminated["__all__"]:
            for skill_name in multi_terminated:
                multi_terminated[skill_name] = True
        multi_truncated["__all__"] = False

        telemetry_historian.sink(
            category="base-skill-env",
            category_sub="step",
            data={
                "multi_sensors": sim_sensors,
                "multi_unfiltered_sensors": sim_sensors,
                "multi_reward": sim_sensors,
                "multi_success": sim_sensors,
                "multi_terminated": sim_sensors,
            },
        )

        return (
            multi_sensors,
            multi_unfiltered_sensors,
            multi_reward,
            multi_success,
            multi_terminated,
            multi_truncated,
        )

    def get_teacher(self):
        return self.coach

    def get_skill(self):
        return self.context.skill
