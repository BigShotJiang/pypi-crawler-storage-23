# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import asyncio
import json
import threading
import time
from typing import Any, Dict, List, Optional, Set

import amesa_core.utils.logger as logger_util
from amesa_core.networking.event_base import EventBase, EventMessage

# Try to import PPO components - these might not be available in all environments
try:
    from ray.rllib.algorithms.ppo import PPO, PPOConfig
    from ray.rllib.env.single_agent_episode import SingleAgentEpisode
    PPO_AVAILABLE = True
except ImportError:
    PPO_AVAILABLE = False
    logger_util.get_logger(__name__).warning("Ray RLlib not available. PPO training will be disabled.")

logger = logger_util.get_logger(__name__)


class EpisodeData:
    """Container for episode data with step-based aggregation."""

    def __init__(self, episode_id: str):
        self.episode_id = episode_id
        self.steps: Dict[int, Dict[str, Any]] = {}  # step_number -> combined data
        self.sim_data: Dict[int, Dict[str, Any]] = {}  # step_number -> sim data
        self.skill_data: Dict[int, Dict[str, Any]] = {}  # step_number -> skill data
        self.created_at = time.time()
        self.last_updated = time.time()
        self.is_complete = False

    def add_sim_data(self, step_number: int, data: Dict[str, Any]) -> bool:
        """Add simulation data for a step. Returns True if step is now complete."""
        self.sim_data[step_number] = data
        self.last_updated = time.time()
        return self._update_combined_step(step_number)

    def add_skill_data(self, step_number: int, data: Dict[str, Any]) -> bool:
        """Add skill data for a step. Returns True if step is now complete."""
        self.skill_data[step_number] = data
        self.last_updated = time.time()
        return self._update_combined_step(step_number)

    def _update_combined_step(self, step_number: int) -> bool:
        """Update combined step data. Returns True if both sim and skill data are available."""
        sim_data = self.sim_data.get(step_number, {})
        skill_data = self.skill_data.get(step_number, {})

        if sim_data and skill_data:
            # Combine the data
            combined = {
                'episode_id': self.episode_id,
                'step_number': step_number,
                'timestamp': time.time(),
                'sim_data': sim_data,
                'skill_data': skill_data
            }
            self.steps[step_number] = combined
            return True
        return False

    def get_complete_steps(self) -> List[Dict[str, Any]]:
        """Get all complete steps sorted by step number."""
        return [self.steps[step] for step in sorted(self.steps.keys())]

    def get_step_count(self) -> int:
        """Get the number of complete steps."""
        return len(self.steps)

    def mark_complete(self):
        """Mark the episode as complete."""
        self.is_complete = True
        self.last_updated = time.time()

    def to_single_agent_episode(self) -> Optional['SingleAgentEpisode']:
        """Convert episode data to Ray RLlib SingleAgentEpisode format."""
        if not PPO_AVAILABLE or not self.steps:
            return None

        try:
            # Extract data in Ray RLlib format
            observations = []
            actions = []
            rewards = []
            infos = []
            terminateds = []
            truncateds = []

            for step_num in sorted(self.steps.keys()):
                step_data = self.steps[step_num]
                sim_data = step_data['sim_data']
                skill_data = step_data['skill_data']

                observations.append(sim_data.get('observation', []))
                actions.append(skill_data.get('action', []))
                rewards.append(sim_data.get('reward', 0.0))
                infos.append(sim_data.get('info', {}))
                terminateds.append(sim_data.get('done', False))
                truncateds.append(False)  # Default to False, can be set based on episode length

            # Create SingleAgentEpisode
            episode = SingleAgentEpisode(
                observations=observations,
                actions=actions,
                rewards=rewards,
                infos=infos,
                terminateds=terminateds,
                truncateds=truncateds,
                id=self.episode_id
            )

            return episode

        except Exception as e:
            logger.error(f"Error converting episode {self.episode_id} to SingleAgentEpisode: {e}")
            return None


class EpisodeManagerEventBase(EventBase):
    """
    Event-based episode manager that aggregates data from sim and skill streams.

    This manager:
    - Reads from sim observation topic and skill action topic
    - Combines data by step_number within each episode_id
    - Tracks batch sizes and manages pause/resume coordination
    - Maintains separate episode aggregations
    """

    def __init__(
        self,
        episode_manager_id: str,
        redis_url: str = "redis://localhost:6379",
        sim_observation_topic: str = "amesa.sim.observations",
        skill_action_topic: str = "amesa.skill.actions",
        output_topic: str = "amesa.episodes",
        pause_topic: str = "amesa.pause",
        resume_topic: str = "amesa.resume",
        consumer_group: str = "composabl-episode-manager-group",
        batch_size: int = 100,
        max_episodes_in_memory: int = 50,
        episode_timeout: float = 300.0,  # 5 minutes
        ppo_training_samples: int = 4000,  # Default PPO training samples
        ppo_config: Optional[Dict[str, Any]] = None,
        enable_ppo_training: bool = True,
    ):
        # Initialize EventBase with sim observations as primary input
        super().__init__(
            redis_url=redis_url,
            input_topic=sim_observation_topic,
            output_topic=output_topic,
            consumer_group=consumer_group,
        )

        self.episode_manager_id = episode_manager_id

        # Topic configuration
        self.sim_observation_topic = sim_observation_topic
        self.skill_action_topic = skill_action_topic
        self.output_topic = output_topic
        self.pause_topic = pause_topic
        self.resume_topic = resume_topic

        # Batch and episode management
        self.batch_size = batch_size
        self.max_episodes_in_memory = max_episodes_in_memory
        self.episode_timeout = episode_timeout

        # PPO training configuration
        self.ppo_training_samples = ppo_training_samples
        self.enable_ppo_training = enable_ppo_training and PPO_AVAILABLE
        self.ppo_config = ppo_config or {}
        self.ppo_algorithm: Optional[PPO] = None
        self.training_samples_collected = 0
        self.training_lock = threading.RLock()

        # Episode tracking
        self.episodes: Dict[str, EpisodeData] = {}
        self.episode_lock = threading.RLock()

        # Batch tracking
        self.current_batch_steps = 0
        self.paused_episodes: Set[str] = set()
        self.acknowledged_inference_nodes: Set[str] = set()
        self.batch_lock = threading.RLock()

        # Redis clients for multiple topics
        self.sim_client = None
        self.skill_client = None

        # Initialize PPO if enabled
        if self.enable_ppo_training:
            self._initialize_ppo()

    def get_episode_manager_id(self):
        return self.episode_manager_id

    def _initialize_ppo(self):
        """Initialize the PPO algorithm."""
        if not self.enable_ppo_training:
            return

        try:
            # Default PPO configuration
            default_config = {
                "framework": "torch",
                "num_workers": 0,  # Single-threaded for episode manager
                "train_batch_size": 4000,
                "sgd_minibatch_size": 128,
                "num_sgd_iter": 30,
                "learning_rate": 3e-4,
                "lambda": 0.95,
                "gamma": 0.99,
                "clip_param": 0.2,
                "entropy_coeff": 0.01,
                "vf_loss_coeff": 1.0,
                "use_critic": True,
                "use_gae": True,
                "use_kl_loss": False,
                "vf_clip_param": 10.0,
            }

            # Merge with user-provided config
            config = {**default_config, **self.ppo_config}

            # Create PPO algorithm
            ppo_config = PPOConfig().update_from_dict(config)
            self.ppo_algorithm = ppo_config.build()

            logger.info(f"Initialized PPO algorithm for episode manager {self.episode_manager_id}")

        except Exception as e:
            logger.error(f"Failed to initialize PPO algorithm: {e}")
            self.enable_ppo_training = False

    async def _perform_ppo_training(self, episodes: List[EpisodeData]) -> Dict[str, Any]:
        """Perform PPO training on collected episodes."""
        if not self.enable_ppo_training or not self.ppo_algorithm:
            return {"status": "disabled", "message": "PPO training not enabled"}

        try:
            with self.training_lock:
                logger.info(f"Starting PPO training with {len(episodes)} episodes")

                # Convert episodes to Ray RLlib format
                ray_episodes = []
                total_samples = 0

                for episode_data in episodes:
                    ray_episode = episode_data.to_single_agent_episode()
                    if ray_episode:
                        ray_episodes.append(ray_episode)
                        total_samples += len(ray_episode)

                if not ray_episodes:
                    return {"status": "failed", "message": "No valid episodes for training"}

                # Perform training step
                training_result = self.ppo_algorithm.train()

                # Reset training samples counter
                self.training_samples_collected = 0

                logger.info(f"PPO training completed. Processed {total_samples} samples from {len(ray_episodes)} episodes")

                return {
                    "status": "success",
                    "episodes_trained": len(ray_episodes),
                    "samples_trained": total_samples,
                    "training_info": training_result
                }

        except Exception as e:
            logger.error(f"Error during PPO training: {e}")
            return {"status": "error", "message": str(e)}

    async def _check_ppo_training_trigger(self):
        """Check if PPO training should be triggered based on collected samples."""
        if not self.enable_ppo_training:
            return

        with self.training_lock:
            if self.training_samples_collected >= self.ppo_training_samples:
                # Get completed episodes for training
                completed_episodes = []
                with self.episode_lock:
                    for episode in self.episodes.values():
                        if episode.is_complete and episode.get_step_count() > 0:
                            completed_episodes.append(episode)

                if completed_episodes:
                    logger.info(f"Triggering PPO training with {len(completed_episodes)} episodes")

                    # Perform training
                    training_result = await self._perform_ppo_training(completed_episodes)

                    # Publish training result
                    await self.publish_message(
                        {
                            "type": "ppo_training_result",
                            "episode_manager_id": self.episode_manager_id,
                            "training_result": training_result,
                            "timestamp": time.time()
                        },
                        output_topic="amesa.ppo.training_results"
                    )

                    # Clean up trained episodes
                    with self.episode_lock:
                        episodes_to_remove = [ep.episode_id for ep in completed_episodes]
                        for episode_id in episodes_to_remove:
                            if episode_id in self.episodes:
                                del self.episodes[episode_id]

                    logger.info(f"PPO training completed and cleaned up {len(episodes_to_remove)} episodes")

    async def connect(self) -> None:
        """Connect to Redis and create separate clients for each topic."""
        try:
            # Connect main client
            await super().connect()

            # Create separate clients for different topics
            self.sim_client = self.redis_client
            self.skill_client = self.redis_client

            logger.info(f"Connected to Redis for episode manager {self.episode_manager_id}")
        except Exception as e:
            logger.error(f"Failed to connect to Redis for episode manager: {e}")
            raise

    async def create_consumer_groups(self) -> None:
        """Create consumer groups for both input topics."""
        try:
            # Create consumer group for sim observations
            await self.redis_client.xgroup_create(
                self.sim_observation_topic,
                self.consumer_group,
                id="0",
                mkstream=True
            )
            logger.info(f"Created consumer group for sim observations: {self.sim_observation_topic}")
        except Exception as e:
            if "BUSYGROUP" not in str(e):
                logger.error(f"Error creating consumer group for sim observations: {e}")
                raise

        try:
            # Create consumer group for skill actions
            await self.redis_client.xgroup_create(
                self.skill_action_topic,
                f"{self.consumer_group}-skill",
                id="0",
                mkstream=True
            )
            logger.info(f"Created consumer group for skill actions: {self.skill_action_topic}")
        except Exception as e:
            if "BUSYGROUP" not in str(e):
                logger.error(f"Error creating consumer group for skill actions: {e}")
                raise

    async def process_message(self, message: EventMessage) -> Optional[Dict[str, Any]]:
        """
        Process messages from the sim observation topic.

        Args:
            message: Event message containing sim observation data

        Returns:
            None (handled internally)
        """
        try:
            # Extract episode and step information
            episode_id = message.data.get('episode_id')
            step_number = message.data.get('step_number')

            if not episode_id or step_number is None:
                logger.warning(f"Missing episode_id or step_number in sim observation: {message.data}")
                return None

            # Add sim data to episode
            with self.episode_lock:
                if episode_id not in self.episodes:
                    self.episodes[episode_id] = EpisodeData(episode_id)

                episode = self.episodes[episode_id]
                step_complete = episode.add_sim_data(step_number, message.data)

                # Check if step is now complete
                if step_complete:
                    await self._handle_complete_step(episode, step_number)

            return None

        except Exception as e:
            logger.error(f"Error processing sim observation message: {e}")
            return None

    async def _handle_complete_step(self, episode: EpisodeData, step_number: int):
        """Handle a completed step (both sim and skill data available)."""
        try:
            # Track training samples for PPO
            if self.enable_ppo_training:
                with self.training_lock:
                    self.training_samples_collected += 1

            # Check if we need to pause for batch processing
            with self.batch_lock:
                self.current_batch_steps += 1

                if self.current_batch_steps >= self.batch_size:
                    # Send pause message
                    await self._send_pause_message(episode.episode_id)
                    self.paused_episodes.add(episode.episode_id)
                    self.current_batch_steps = 0

            # Publish complete step data
            step_data = episode.steps[step_number]
            await self.publish_message(
                step_data,
                correlation_id=f"{episode.episode_id}-{step_number}"
            )

            logger.debug(f"Published complete step {step_number} for episode {episode.episode_id}")

            # Check if PPO training should be triggered
            await self._check_ppo_training_trigger()

        except Exception as e:
            logger.error(f"Error handling complete step: {e}")

    async def _send_pause_message(self, episode_id: str):
        """Send pause message to coordinate training."""
        try:
            pause_data = {
                'episode_manager_id': self.episode_manager_id,
                'episode_id': episode_id,
                'batch_size_reached': True,
                'timestamp': time.time(),
                'message': 'Pause for policy update'
            }

            await self.publish_message(
                pause_data,
                correlation_id=f"pause-{episode_id}",
                output_topic=self.pause_topic
            )

            logger.info(f"Sent pause message for episode {episode_id}")

        except Exception as e:
            logger.error(f"Error sending pause message: {e}")

    async def _handle_skill_action_message(self, message: EventMessage):
        """Handle skill action messages."""
        try:
            # Extract episode and step information
            episode_id = message.data.get('episode_id')
            step_number = message.data.get('step_number')

            if not episode_id or step_number is None:
                logger.warning(f"Missing episode_id or step_number in skill action: {message.data}")
                return

            # Add skill data to episode
            with self.episode_lock:
                if episode_id not in self.episodes:
                    self.episodes[episode_id] = EpisodeData(episode_id)

                episode = self.episodes[episode_id]
                step_complete = episode.add_skill_data(step_number, message.data)

                # Check if step is now complete
                if step_complete:
                    await self._handle_complete_step(episode, step_number)

        except Exception as e:
            logger.error(f"Error processing skill action message: {e}")

    async def handle_resume_message(self, message: EventMessage):
        """Handle resume messages from inference nodes."""
        try:
            episode_id = message.data.get('episode_id')
            inference_node_id = message.data.get('inference_node_id')

            if not episode_id or not inference_node_id:
                logger.warning(f"Missing episode_id or inference_node_id in resume message: {message.data}")
                return

            with self.batch_lock:
                # Track acknowledged inference nodes
                self.acknowledged_inference_nodes.add(inference_node_id)

                # Check if all inference nodes have acknowledged
                if episode_id in self.paused_episodes:
                    # For now, assume we can resume after any acknowledgment
                    # In a real implementation, you'd track specific inference nodes
                    self.paused_episodes.discard(episode_id)

                    # Send resume message
                    resume_data = {
                        'episode_manager_id': self.episode_manager_id,
                        'episode_id': episode_id,
                        'timestamp': time.time(),
                        'message': 'Resume episode processing'
                    }

                    await self.publish_message(
                        resume_data,
                        correlation_id=f"resume-{episode_id}",
                        output_topic=self.resume_topic
                    )

                    logger.info(f"Sent resume message for episode {episode_id}")

        except Exception as e:
            logger.error(f"Error handling resume message: {e}")

    async def start(self) -> None:
        """Start the episode management loop."""
        await self.connect()
        await self.create_consumer_groups()

        self._is_running = True
        logger.info(f"Started episode manager {self.episode_manager_id}")

        # Start cleanup thread for old episodes
        self._start_cleanup_thread()

        try:
            while self._is_running:
                try:
                    # Process sim observation messages
                    await self._process_sim_observation_messages()

                    # Process skill action messages
                    await self._process_skill_action_messages()

                    # Process resume messages
                    await self._process_resume_messages()

                    # Brief pause to prevent busy waiting
                    await asyncio.sleep(0.01)

                except Exception as e:
                    logger.error(f"Error in episode manager event loop: {e}")
                    await asyncio.sleep(1)

        finally:
            await self.disconnect()

    async def _process_sim_observation_messages(self) -> None:
        """Process messages from the sim observation topic."""
        try:
            messages = await self.read_messages_from_topic(
                self.sim_observation_topic,
                self.consumer_group,
                count=10,
                block=100
            )

            for message in messages:
                try:
                    await self.process_message(message)

                    await self.acknowledge_message_from_topic(
                        message.message_id,
                        self.sim_observation_topic,
                        self.consumer_group
                    )

                except Exception as e:
                    logger.error(f"Error processing sim observation message {message.message_id}: {e}")
                    await self.acknowledge_message_from_topic(
                        message.message_id,
                        self.sim_observation_topic,
                        self.consumer_group
                    )

        except Exception as e:
            logger.error(f"Error reading sim observation messages: {e}")

    async def _process_skill_action_messages(self) -> None:
        """Process messages from the skill action topic."""
        try:
            messages = await self.read_messages_from_topic(
                self.skill_action_topic,
                f"{self.consumer_group}-skill",
                count=10,
                block=100
            )

            for message in messages:
                try:
                    await self._handle_skill_action_message(message)

                    await self.acknowledge_message_from_topic(
                        message.message_id,
                        self.skill_action_topic,
                        f"{self.consumer_group}-skill"
                    )

                except Exception as e:
                    logger.error(f"Error processing skill action message {message.message_id}: {e}")
                    await self.acknowledge_message_from_topic(
                        message.message_id,
                        self.skill_action_topic,
                        f"{self.consumer_group}-skill"
                    )

        except Exception as e:
            logger.error(f"Error reading skill action messages: {e}")

    async def _process_resume_messages(self) -> None:
        """Process resume messages from inference nodes."""
        try:
            # Listen for resume messages on the resume topic
            messages = await self.read_messages_from_topic(
                self.resume_topic,
                f"{self.consumer_group}-resume",
                count=5,
                block=100
            )

            for message in messages:
                try:
                    await self.handle_resume_message(message)

                    await self.acknowledge_message_from_topic(
                        message.message_id,
                        self.resume_topic,
                        f"{self.consumer_group}-resume"
                    )

                except Exception as e:
                    logger.error(f"Error processing resume message {message.message_id}: {e}")
                    await self.acknowledge_message_from_topic(
                        message.message_id,
                        self.resume_topic,
                        f"{self.consumer_group}-resume"
                    )

        except Exception as e:
            logger.error(f"Error reading resume messages: {e}")

    async def read_messages_from_topic(
        self,
        topic: str,
        consumer_group: str,
        count: int = 10,
        block: int = 1000
    ) -> List[EventMessage]:
        """Read messages from a specific topic."""
        if not self.redis_client:
            raise RuntimeError("Not connected to Redis")

        try:
            messages = await self.redis_client.xreadgroup(
                consumer_group,
                self.consumer_name,
                {topic: ">"},
                count=count,
                block=block
            )

            event_messages = []
            for topic_name, msgs in messages:
                for msg_id, fields in msgs:
                    try:
                        # Parse message fields
                        data_bytes = fields.get(b'data', b'{}')
                        if isinstance(data_bytes, bytes):
                            data = json.loads(data_bytes.decode('utf-8'))
                        else:
                            data = json.loads(data_bytes)

                        timestamp_bytes = fields.get(b'timestamp', b'0')
                        if isinstance(timestamp_bytes, bytes):
                            timestamp = float(timestamp_bytes.decode('utf-8'))
                        else:
                            timestamp = float(timestamp_bytes)

                        correlation_id_bytes = fields.get(b'correlation_id', b'')
                        if isinstance(correlation_id_bytes, bytes):
                            correlation_id = correlation_id_bytes.decode('utf-8') or None
                        else:
                            correlation_id = correlation_id_bytes or None

                        unique_id_bytes = fields.get(b'unique_id', b'')
                        if isinstance(unique_id_bytes, bytes):
                            unique_id = unique_id_bytes.decode('utf-8') or None
                        else:
                            unique_id = unique_id_bytes or None

                        if isinstance(msg_id, bytes):
                            message_id = msg_id.decode('utf-8')
                        else:
                            message_id = msg_id

                        event_msg = EventMessage(
                            message_id=message_id,
                            timestamp=timestamp,
                            data=data,
                            correlation_id=correlation_id,
                            unique_id=unique_id
                        )
                        event_messages.append(event_msg)

                    except Exception as e:
                        logger.error(f"Error parsing message {msg_id}: {e}")

            return event_messages

        except Exception as e:
            logger.error(f"Error reading messages from topic {topic}: {e}")
            return []

    async def acknowledge_message_from_topic(
        self,
        message_id: str,
        topic: str,
        consumer_group: str
    ) -> None:
        """Acknowledge a message from a specific topic."""
        if not self.redis_client:
            raise RuntimeError("Not connected to Redis")

        try:
            await self.redis_client.xack(topic, consumer_group, message_id)
        except Exception as e:
            logger.error(f"Error acknowledging message {message_id} from topic {topic}: {e}")

    async def publish_message(
        self,
        data: Dict[str, Any],
        correlation_id: Optional[str] = None,
        output_topic: Optional[str] = None
    ) -> str:
        """Publish a message to the specified topic."""
        if not self.redis_client:
            raise RuntimeError("Not connected to Redis")

        topic = output_topic or self.output_topic

        try:
            message_fields = {
                "data": json.dumps(data),
                "timestamp": str(time.time()),
            }

            if correlation_id:
                message_fields["correlation_id"] = correlation_id

            msg_id = await self.redis_client.xadd(topic, message_fields)
            logger.debug(f"Published message {msg_id} to topic '{topic}'")
            return msg_id.decode('utf-8')

        except Exception as e:
            logger.error(f"Error publishing message: {e}")
            raise

    def _cleanup_old_episodes(self) -> None:
        """Clean up old episodes to prevent memory leaks."""
        current_time = time.time()

        with self.episode_lock:
            episodes_to_remove = []

            for episode_id, episode in self.episodes.items():
                # Remove episodes that are too old or if we have too many
                age = current_time - episode.created_at
                if (age > self.episode_timeout or
                        len(self.episodes) > self.max_episodes_in_memory):
                    episodes_to_remove.append(episode_id)

            for episode_id in episodes_to_remove:
                del self.episodes[episode_id]
                logger.info(f"Cleaned up old episode: {episode_id}")

    def _start_cleanup_thread(self) -> None:
        """Start the cleanup thread for old episodes."""
        def cleanup_loop():
            while self._is_running:
                try:
                    self._cleanup_old_episodes()
                    time.sleep(30)  # Clean up every 30 seconds
                except Exception as e:
                    logger.error(f"Error in cleanup thread: {e}")
                    time.sleep(30)

        cleanup_thread = threading.Thread(target=cleanup_loop, daemon=True)
        cleanup_thread.start()

    def get_episode_stats(self) -> Dict[str, Any]:
        """Get statistics about current episodes."""
        with self.episode_lock:
            stats = {
                'total_episodes': len(self.episodes),
                'episode_ids': list(self.episodes.keys()),
                'episode_details': {
                    episode_id: {
                        'step_count': episode.get_step_count(),
                        'created_at': episode.created_at,
                        'last_updated': episode.last_updated,
                        'is_complete': episode.is_complete
                    }
                    for episode_id, episode in self.episodes.items()
                },
                'batch_stats': {
                    'current_batch_steps': self.current_batch_steps,
                    'batch_size': self.batch_size,
                    'paused_episodes': list(self.paused_episodes),
                    'acknowledged_nodes': list(self.acknowledged_inference_nodes)
                }
            }

            # Add PPO training stats if enabled
            if self.enable_ppo_training:
                with self.training_lock:
                    stats['ppo_training_stats'] = {
                        'enabled': True,
                        'training_samples_collected': self.training_samples_collected,
                        'ppo_training_samples': self.ppo_training_samples,
                        'samples_remaining': max(0, self.ppo_training_samples - self.training_samples_collected),
                        'algorithm_initialized': self.ppo_algorithm is not None
                    }
            else:
                stats['ppo_training_stats'] = {
                    'enabled': False,
                    'reason': 'PPO training disabled or Ray RLlib not available'
                }

            return stats
