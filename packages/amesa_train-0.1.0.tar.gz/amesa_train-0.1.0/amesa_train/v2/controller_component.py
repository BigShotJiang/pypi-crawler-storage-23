# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
Controller Component for EventControllerProcessor.
This component provides controller processing functionality that can be used by EventControllerProcessor.
"""

from typing import Any, Dict, List, Optional, Union

import amesa_core.utils.logger as logger_util
from amesa_core.agent.skill.skill_controller import SkillController
from amesa_core.decorators.ensure_is_initialized import ensure_cls_is_initialized
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)

logger = logger_util.get_logger(__name__)


@ensure_cls_is_initialized
class ControllerComponent:
    """
    Controller Component that provides controller processing functionality.

    This component encapsulates the controller processing logic and can be used
    by EventControllerProcessor or other event-driven systems.
    """

    def __init__(self, context: SkillProcessorContext):
        """
        Initialize the controller component.

        Args:
            context: Skill processor context containing agent and controller information
        """
        self.context = context
        self.controller: Optional[SkillController] = None
        self._is_initialized = False

    async def init(self):
        """
        Initialize the controller component.
        This method initializes the controller using the standard Amesa pattern.
        """
        # Initialize controller
        await self._init_controller()

        self._is_initialized = True

        logger.info(f"ControllerComponent initialized for controller: {self.context.skill.get_name()}")

    async def _init_controller(self):
        """Initialize the controller."""
        from amesa_core.networking import network_util
        from amesa_core.utils import plugin_util

        if self.context.skill.is_remote():
            composabl_url = network_util.get_amesa_url(
                self.context.skill.get_impl_cls()
            )
            # download the controller from the URL
            try:
                version = await plugin_util.get_amesa_version(composabl_url)
            except Exception:
                version = "latest"

            # remote controller
            client_id, self.controller = await self.context.network_mgr.call_remote_controller_mgr.remote(
                "create_with_client", env_init=composabl_url, version=version
            )
        else:
            # get the controller from the agent to ensure it is enabled
            self.controller = self.context.skill.get_impl_cls_instance()

    async def compute_action(
        self,
        transformed_sensors: Union[float, int, List[float], List[int]],
        action: Optional[Union[float, int, List[float], List[int]]] = None,
    ) -> Union[float, int, List[float], List[int], Dict[str, Any]]:
        """
        Compute action using the controller.

        Args:
            transformed_sensors: Transformed sensor data
            action: Optional action data

        Returns:
            Computed action from the controller
        """
        if self.controller is None:
            raise RuntimeError("Controller not initialized")

        try:
            result = await self.controller.compute_action(transformed_sensors, action)
            return result
        except Exception as e:
            logger.error(f"Error computing action with controller: {e}")
            raise

    async def compute_success_criteria(
        self,
        transformed_sensors: Union[float, int, List[float], List[int]],
        action: Union[float, int, List[float], List[int]],
    ) -> bool:
        """
        Compute success criteria using the controller.

        Args:
            transformed_sensors: Transformed sensor data
            action: Action data

        Returns:
            Success criteria result from the controller
        """
        if self.controller is None:
            raise RuntimeError("Controller not initialized")

        try:
            result = await self.controller.compute_success_criteria(transformed_sensors, action)
            return result
        except Exception as e:
            logger.error(f"Error computing success criteria with controller: {e}")
            raise

    async def compute_termination(
        self,
        transformed_sensors: Union[float, int, List[float], List[int]],
        action: Union[float, int, List[float], List[int]],
    ) -> bool:
        """
        Compute termination criteria using the controller.

        Args:
            transformed_sensors: Transformed sensor data
            action: Action data

        Returns:
            Termination criteria result from the controller
        """
        if self.controller is None:
            raise RuntimeError("Controller not initialized")

        try:
            result = await self.controller.compute_termination(transformed_sensors, action)
            return result
        except Exception as e:
            logger.error(f"Error computing termination with controller: {e}")
            raise

    async def reset(self):
        """Reset the controller for a new episode."""
        if self.controller is not None:
            try:
                await self.controller.reset()
            except Exception as e:
                logger.warning(f"Error resetting controller: {e}")

    def get_controller(self) -> Optional[SkillController]:
        """Get the controller instance."""
        return self.controller

    def get_controller_name(self) -> str:
        """Get the controller name."""
        if self.controller is not None:
            return self.controller.get_name()
        return self.context.skill.get_name()

    def is_initialized(self) -> bool:
        """Check if the component is initialized."""
        return self._is_initialized
