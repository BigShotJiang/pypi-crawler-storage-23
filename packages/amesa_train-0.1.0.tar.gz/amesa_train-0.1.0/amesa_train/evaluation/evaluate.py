# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Any, Dict, List, Optional, Tuple, TypeVar, Union

import json
import os
import numpy as np
import cv2

from amesa_core.agent import Agent, Scenario, Skill, SkillSelector, SkillCoordinatedSet, SkillCoordinatedPopulation
import amesa_core.spaces as amesa_spaces
from amesa_core.networking.sim.client import Client
from amesa_core.config.trainer_config import (
    BenchmarkConfig,
    RecordConfig,
    PostProcessingConfig,
    TrainerTargetConfig
)
from amesa_core.utils import async_util
from amesa_core.networking.config.skill_processor_context import SkillProcessorContext
from amesa_train.config.step_info import TeacherStepData, CoordinatedTeacherStepData
from amesa_train.skill_processors import make_skill_processor
import amesa_core.utils.logger as logger_util
logger = logger_util.get_logger(__name__)


def create_frame_from_obs(obs: Union[str, np.ndarray]) -> np.ndarray:
    """
    Create a frame from the observation

    Args:
        obs (Union[str, np.ndarray]): The observation

    Returns:
        np.ndarray: The frame
    """
    if isinstance(obs, str):
        # create a frame from the text
        img = np.zeros((480, 640, 3), dtype=np.uint8)
        y_0 = 50
        dy = 20
        for i, line in enumerate(obs.split("\n")):
            cv2.putText(
                img,
                line,
                (10, y_0 + i * dy),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                1,
            )
        return img
    elif isinstance(obs, np.ndarray):
        if obs.shape != 3:
            cv2.cvtColor(obs, cv2.COLOR_RGB2BGR)
        return obs
    return obs


def record(
    agent: Agent,
    network_mgr: Any,
    record_config: RecordConfig = None,
    scenario: Optional[Scenario] = None,
    target_config: TrainerTargetConfig = None,
) -> List[np.ndarray]:
    """
    Record the agent executing in the simulator. This will create a .gif and .avi file at the
    specified location. You can set `options.gif = False` to disable the gif recording.

    By default, we record 30 seconds. To change this, set `options.max_frames`.

    Note: the simulator has to have the `get_render` method implemented to support rendering

    Args:
        agent (Agent): The agent to record
        output_dir (str): The output directory to save the recording
        options (dict): The options for the recording

    Returns:
        List[np.ndarray]: List of frames recorded
    """
    skill_context = SkillProcessorContext(
        agent=agent,
        skill=agent.get_top_skill(),
        network_mgr=network_mgr,
        is_validating=False,
        is_training=False,
        for_skill_group=False
    )

    return async_util.async_to_sync(inference_episode_record)(skill_context, record_config, scenario, target_config)


async def inference_episode_record(
    skill_context: SkillProcessorContext = None,
    record_config: RecordConfig = None,
    scenario: Optional[Scenario] = None,
    target_config: TrainerTargetConfig = None,
) -> List[Any]:
    """
    Record the agent executing in the simulator. This will create a .gif and .avi file at the
    specified location. You can set `options.gif = False` to disable the gif recording.

    By default, we record 30 seconds. To change this, set `options.max_frames`.

    Note: the simulator has to have the `get_render` method implemented to support rendering

    Args:
        agent (Agent): The agent to record
        output_dir (str): The output directory to save the recording
        options (dict): The options for the recording

    Returns:
        Nonfrom typing import Any, Dict, List, Optional, Tuple, TypeVar, Unione
    """
    if record_config is None:
        record_config = RecordConfig()

    frames = []

    sim_id, sim_client = await skill_context.network_mgr.call_sim_mgr.remote(
        "create_with_client",
        target_config.protocol,
    )
    if scenario is not None:
        await sim_client.set_scenario(scenario)

    agent_inference = await make_skill_processor(
        config=skill_context
    )

    # Reset the sim
    # we do this before get_render validation as some sims require a reset before rendering
    # see: https://github.com/openai/gym/issues/3073
    obs, info = await sim_client.reset()

    # Check if the render method is supported
    try:
        frame = await sim_client.get_render()
    except Exception:
        logger.error(
            "The simulator does not support rendering, ensure the `get_render` method is implemented and returns either a numpy array or a string."
        )

        raise AttributeError("The simulator does not support rendering")

    # Get one frame so we know the shape
    # grayscale, rgb, txt
    raw_frame = await sim_client.get_render()
    frame = create_frame_from_obs(raw_frame)

    if not isinstance(frame, np.ndarray):
        logger.error(f"Frame is not a numpy array, got {type(frame)}")
        return

    frame_shape = frame.shape
    frame_height, frame_width = frame_shape[0], frame_shape[1]

    if len(frame_shape) != 3:
        logger.error(
            f"Frame shape is not valid, expected 3 dimensions, got {len(frame_shape)}"
        )
        raise ValueError(
            "Frame shape is not valid, expected 3 dimensions, got {len(frame_shape)}"
        )

    # Print some info about the frame
    logger.info(f"- Frame Height: {frame_height}")
    logger.info(f"- Frame Width: {frame_width}")

    is_done = False

    while not is_done and len(frames) < record_config.max_frames:
        action = await agent_inference._execute(obs, explore=True)
        (
            obs,
            sim_reward,
            is_done,
            sim_terminated,
            sim_truncated,
        ) = await sim_client.step(action)
        sim_obs = await sim_client.get_render()
        frame = create_frame_from_obs(sim_obs)
        frames.append(frame)

    return frames


def benchmark(
    agent: Agent,
    network_mgr: Any,
    benchmark_config: BenchmarkConfig,
    target_config: TrainerTargetConfig = None,
):
    # for every drl skill in the agent, run the benchmark
    skill_benchmark_dict = {}
    top_skill = agent.get_top_skill()
    skill_benchmark_dict[top_skill.get_name()] = {}
    scenarios = top_skill.get_scenarios()
    for scenario in scenarios:
        scenario.convert_to_constant()

    # If no scenarios, add a None scenario to benchmark
    if len(scenarios) == 0:
        scenarios = [None]

    for index, scenario in enumerate(scenarios):
        aggregate_state = {}
        scenario_json = ""
        if scenario is not None:
            scenario_json = scenario.to_json()
        skill_benchmark_dict[top_skill.get_name()][f"scenario-{index}"] = {}
        skill_benchmark_dict[top_skill.get_name()][f"scenario-{index}"][
            "scenario_data"
        ] = scenario_json
        for episode_idx in range(benchmark_config.num_episodes_per_scenario):
            skill_context = SkillProcessorContext(
                agent=agent,
                skill=top_skill,
                network_mgr=network_mgr,
                is_validating=False,
                is_training=False,
                for_skill_group=False
            )
            episode_data = async_util.async_to_sync(
                inference_episode_benchmark
            )(
                skill_context=skill_context,
                benchmark_config=benchmark_config,
                scenario=scenario,
                target_config=target_config,
            )

            # dump to json to serialize
            json_data = []
            for step_teacher_data in episode_data:
                json_data.append(step_teacher_data.model_dump(mode="json"))

            # compute the aggregate means of all fields in episode data
            for step_data in episode_data:
                for key, value in step_data.state.items():
                    if key not in aggregate_state:
                        aggregate_state[key] = []
                    aggregate_state[key].append(value)

            skill_benchmark_dict[top_skill.get_name()][f"scenario-{index}"][
                f"episode-{episode_idx}"
            ] = json_data
        means = {}
        medians = {}
        std_dev = {}
        max = {}
        min = {}
        for key, value in aggregate_state.items():
            try:
                means[key] = np.mean(value).astype(float)
                medians[key] = np.median(value).astype(float)
                std_dev[key] = np.std(value).astype(float)
                min[key] = np.min(value).astype(float)
                max[key] = np.max(value).astype(float)
            except Exception as e:
                logger.info(f"unable to compute mean of {key} -- exception {e}")

        aggregate_dict = {
            "mean": means,
            "medians": medians,
            "std_dev": std_dev,
            "max": max,
            "min": min,
        }
        skill_benchmark_dict[top_skill.get_name()][f"scenario-{index}"][
            "aggregate"
        ] = aggregate_dict

    return skill_benchmark_dict


async def inference_episode_benchmark(
    skill_context: SkillProcessorContext,
    benchmark_config: BenchmarkConfig = BenchmarkConfig(),
    scenario: Optional[Scenario] = None,
    target_config: TrainerTargetConfig = None,
    env_init: Dict[str, Any] = {},
) -> List[Union[TeacherStepData, CoordinatedTeacherStepData]]:
    """
    Record the agent executing in the simulator. This will create a .gif and .avi file at the
    specified location. You can set `options.gif = False` to disable the gif recording.

    By default, we record 30 seconds. To change this, set `options.max_frames`.

    Note: the simulator has to have the `get_render` method implemented to support rendering

    Args:
        agent (Agent): The agent to record
        output_dir (str): The output directory to save the recording
        options (dict): The options for the recording

    Returns:
        None
    """

    # check if the skill is coordinated
    if isinstance(skill_context.skill, SkillCoordinatedSet) or isinstance(skill_context.skill, SkillCoordinatedPopulation):
        step_data_cls = CoordinatedTeacherStepData
    else:
        step_data_cls = TeacherStepData

    if isinstance(skill_context.skill, SkillCoordinatedPopulation):
        population_dict = {}
        for population in skill_context.skill.get_skills():
            population_dict[population.get_name()] = population.get_amount()
        env_init.update(population_dict)

    sim_id, sim_client = await skill_context.network_mgr.call_sim_mgr.remote(
        "create_with_client",
        target_config.protocol,
        env_init=env_init,
    )
    if scenario is not None:
        await sim_client.set_scenario(scenario)

    sim_sensor_space = await sim_client.sensor_space_info()
    sim_sensor_space = amesa_spaces.convert_to_amesa_space(sim_sensor_space)
    sim_action_space = await sim_client.action_space_info()
    sim_action_space = amesa_spaces.convert_to_amesa_space(sim_action_space)

    # Package the agent for inferencing
    skill_context.agent.set_sim_sensor_space(sim_sensor_space)
    skill_context.agent.set_action_space(sim_action_space)

    if isinstance(skill_context.skill, SkillSelector):
        skill_context.skill.set_action_space(amesa_spaces.Discrete(len(skill_context.skill.get_children())))
    else:
        skill_context.skill.set_action_space(sim_action_space)

    agent_inference = await make_skill_processor(
        config=skill_context
    )

    # Reset the sim
    # we do this before get_render validation as some sims require a reset before rendering
    # see: https://github.com/openai/gym/issues/3073
    obs, info = await sim_client.reset()
    frame_count = 0
    episode_data: list[Any] = []

    is_done = False
    prev_action = None
    MAX_STEPS = benchmark_config.num_steps_per_episode
    teacher_state = None
    while not is_done and frame_count < MAX_STEPS:
        teacher_state = await agent_inference._execute(
            obs,
            explore=False,
            previous_action=prev_action,
            return_as_teacher_dict=True,
        )

        action = teacher_state["action"]

        step_teacher_data = step_data_cls(
            state=teacher_state["state"],
            action=action,
            teacher_reward=teacher_state["reward"],
            teacher_success=teacher_state["success"],
            teacher_terminated=teacher_state["terminated"],
            top_selector_action=teacher_state.get("top_selector_action", None),
            coordinated_reward=teacher_state.get("coordinated_reward", None),
        )
        episode_data.append(step_teacher_data)
        frame_count += 1

        if isinstance(skill_context, SkillSelector):
            # If we are validating, we need to coerce the action to the sim action space
            action = sim_action_space.coerce_sample(sim_action_space.sample())
        else:
            action = sim_action_space.coerce_sample(action)

        obs, sim_reward, is_done, sim_terminated, sim_truncated = await sim_client.step(action)

        prev_action = action

    return episode_data


def postprocess(agent: Agent,
                network_mgr: Any,
                postprocess_config: PostProcessingConfig,
                target_config: TrainerTargetConfig,
                output_dir: str) -> None:
    """
    Postprocess the agent

    Args:
        agent (Agent): The agent to postprocess
        options (PostProcessingConfig): The options for postprocessing

    Returns:
        None
    """
    """
    Postprocess the agent

    Args:
        agent (Agent): The agent to postprocess
        options (PostProcessingConfig): The options for postprocessing

    Returns:
        None
    """
    logger.info("Postprocessing the agent...")
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    if postprocess_config.record is not None:
        try:
            frames = record(agent,
                            network_mgr=network_mgr,
                            record_config=postprocess_config.record,
                            scenario=None,
                            target_config=target_config
                            )
            # write ato file
            if postprocess_config.record.avi_file_name is not None:
                logger.info(
                    f"Writing video file to {output_dir + '/' + postprocess_config.record.avi_file_name}"
                )
                # Create writers for AVI and GIF
                writer_avi = cv2.VideoWriter(
                    output_dir + "/"
                    + postprocess_config.record.avi_file_name,
                    cv2.VideoWriter_fourcc(*"MJPG"),
                    24.0,
                    (frames[0].shape[1], frames[0].shape[0]),
                )
                for frame in frames:
                    writer_avi.write(frame)
                writer_avi.release()
        except Exception as e:
            logger.error("Error during recording")
            logger.error(e)
            import traceback

            traceback.print_exc()

    if postprocess_config.benchmark is not None:
        try:
            benchmark_json = benchmark(agent, network_mgr, postprocess_config.benchmark, target_config)
            logger.info(
                f"Writing benchmark.json to {output_dir + '/' + postprocess_config.benchmark.file_name}"
            )
            # write to file
            with open(
                output_dir + "/"
                + postprocess_config.benchmark.file_name,
                "w",
            ) as f:
                json.dump(benchmark_json, f)
        except Exception as e:
            logger.error("Error during benchmarking")
            logger.error(e)
            import traceback

            traceback.print_exc()

    logger.info("Postprocessing done")
