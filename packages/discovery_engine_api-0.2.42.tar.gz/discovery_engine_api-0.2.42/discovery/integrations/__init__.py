"""Optional integrations with agent frameworks (LangChain, CrewAI)."""
