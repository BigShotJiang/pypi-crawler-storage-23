"""Structured error types for the Discovery Engine SDK.

Every error includes enough context for agents to self-correct without
reading documentation or asking for help.
"""


class DiscoveryError(Exception):
    """Base error for all Discovery Engine SDK errors."""

    def __init__(self, message: str, *, suggestion: str | None = None):
        self.suggestion = suggestion
        if suggestion:
            message = f"{message}\n  Suggestion: {suggestion}"
        super().__init__(message)


class InsufficientCreditsError(DiscoveryError):
    """Raised when a run requires more credits than are available.

    Attributes:
        credits_required: Credits needed for the run.
        credits_available: Credits currently available.
    """

    def __init__(
        self,
        credits_required: int | None = None,
        credits_available: int | None = None,
        message: str | None = None,
    ):
        self.credits_required = credits_required
        self.credits_available = credits_available
        if message is None:
            parts = ["Insufficient credits."]
            if credits_required is not None and credits_available is not None:
                parts.append(f"Need {credits_required}, have {credits_available}.")
            message = " ".join(parts)
        super().__init__(
            message,
            suggestion=(
                "Run with visibility='public' (free, depth=1) or purchase credits "
                "with engine.purchase_credits()."
            ),
        )


class RateLimitError(DiscoveryError):
    """Raised when API rate limits are exceeded.

    Attributes:
        retry_after: Seconds to wait before retrying, if provided by the API.
    """

    def __init__(self, retry_after: float | None = None, message: str | None = None):
        self.retry_after = retry_after
        if message is None:
            message = "Rate limit exceeded."
            if retry_after:
                message += f" Retry after {retry_after:.0f}s."
        super().__init__(
            message,
            suggestion="Wait and retry. Rate limits reset automatically.",
        )


class AuthenticationError(DiscoveryError):
    """Raised when the API key is invalid or missing."""

    def __init__(self, message: str | None = None):
        super().__init__(
            message or "Invalid or missing API key.",
            suggestion=(
                "Check your API key. Generate one at https://disco.leap-labs.com/developers "
                "or via Engine.signup()."
            ),
        )


class RunFailedError(DiscoveryError):
    """Raised when a run fails server-side.

    Attributes:
        run_id: The ID of the failed run.
    """

    def __init__(self, run_id: str, error_message: str | None = None):
        self.run_id = run_id
        msg = f"Run {run_id} failed"
        if error_message:
            msg += f": {error_message}"
        super().__init__(msg)


class PaymentRequiredError(DiscoveryError):
    """Raised when a payment method is required but not on file."""

    def __init__(self, message: str | None = None):
        super().__init__(
            message or "No payment method on file.",
            suggestion=(
                "Attach a payment method with engine.add_payment_method(payment_method_id='pm_...'). "
                "Tokenize card details via Stripe's API first — they never touch Discovery Engine."
            ),
        )
