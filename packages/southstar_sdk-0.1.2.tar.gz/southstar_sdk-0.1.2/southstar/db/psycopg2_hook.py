"""
Instruments psycopg2 by wrapping psycopg2.connect with a cursor subclass.

psycopg2.extensions.cursor is a C extension type — its class-level attributes
are immutable, so direct monkey-patching fails. The correct approach is to:
  1. Subclass ext.cursor in Python (Python subclasses of C types are mutable).
  2. Wrap psycopg2.connect to inject our subclass as the default cursor_factory.
"""
import logging
import time

logger = logging.getLogger(__name__)

_patched = False


def _extract_sql(query, cursor=None) -> str:
    """Safely extract SQL string from various psycopg2 query types."""
    if isinstance(query, bytes):
        return query.decode('utf-8', errors='replace')
    if isinstance(query, str):
        return query
    # psycopg2.sql.Composed and sql.SQL objects
    if hasattr(query, 'as_string') and cursor is not None:
        try:
            return query.as_string(cursor)
        except Exception:
            pass
    return str(query)


def install():
    global _patched
    if _patched:
        return
    try:
        import psycopg2
        import psycopg2.extensions as ext
        from southstar.context import get_current

        _orig_connect = psycopg2.connect

        class SouthStarCursor(ext.cursor):
            def execute(self, query, vars=None):
                ctx = get_current()
                if ctx is None:
                    return super().execute(query, vars)
                start = time.perf_counter()
                try:
                    return super().execute(query, vars)
                finally:
                    elapsed = (time.perf_counter() - start) * 1000
                    try:
                        sql = _extract_sql(query, self)
                        ctx.add_query(sql, elapsed, self.rowcount or 0, 'psycopg2')
                    except Exception:
                        logger.debug('Failed to record query', exc_info=True)

            def executemany(self, query, vars_list):
                ctx = get_current()
                if ctx is None:
                    return super().executemany(query, vars_list)
                start = time.perf_counter()
                try:
                    return super().executemany(query, vars_list)
                finally:
                    elapsed = (time.perf_counter() - start) * 1000
                    try:
                        sql = _extract_sql(query, self)
                        ctx.add_query(f'[executemany] {sql}', elapsed, 0, 'psycopg2')
                    except Exception:
                        logger.debug('Failed to record query', exc_info=True)

        def _southstar_connect(*args, **kwargs):
            # Only inject our cursor_factory if the caller hasn't set one.
            kwargs.setdefault('cursor_factory', SouthStarCursor)
            return _orig_connect(*args, **kwargs)

        psycopg2.connect = _southstar_connect
        _patched = True
        logger.debug('psycopg2 instrumentation installed.')
    except ImportError:
        pass  # psycopg2 not installed — skip silently
