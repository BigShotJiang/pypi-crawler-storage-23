"""
South Star SDK — Overhead Benchmark
====================================
Measures the overhead that the SDK adds per request compared to a raw baseline.

What we measure:
  1. Baseline      — pure context creation + span assembly (no DB/HTTP hooks)
  2. Context ops   — adding N query records to a TraceContext
  3. SQL normalize — normalization + hashing of realistic SQL strings
  4. build_span    — full span assembly from a populated TraceContext
  5. enqueue       — putting a span on the shipper queue (non-blocking)

Run from the sdks/python/ directory:
    python benchmarks/benchmark_sdk.py

All numbers are per-operation averages in microseconds (µs).
Goal: each operation stays well under 1000 µs (1 ms) per request.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import time
import statistics
from typing import Callable

# ─── Imports ────────────────────────────────────────────────────────────────
from southstar.context import TraceContext, QueryRecord
from southstar.sanitizer import build_span
import southstar.shipper as shipper

# ─── Benchmark harness ──────────────────────────────────────────────────────

WARMUP_ITERS = 500
BENCH_ITERS  = 5_000

def _bench(label: str, fn: Callable, n: int = BENCH_ITERS) -> dict:
    # Warmup
    for _ in range(WARMUP_ITERS):
        fn()

    times = []
    for _ in range(n):
        t0 = time.perf_counter()
        fn()
        times.append((time.perf_counter() - t0) * 1_000_000)  # µs

    median  = statistics.median(times)
    mean    = statistics.mean(times)
    p95     = sorted(times)[int(n * 0.95)]
    p99     = sorted(times)[int(n * 0.99)]
    minimum = min(times)
    maximum = max(times)

    row = dict(label=label, median=median, mean=mean, p95=p95, p99=p99,
               min=minimum, max=maximum, n=n)
    return row


def _print_results(results: list):
    header = f"{'Benchmark':<35} {'median':>8} {'mean':>8} {'p95':>8} {'p99':>8} {'max':>8}  (µs)"
    print()
    print(header)
    print('-' * len(header))
    for r in results:
        warn = '  !!' if r['p95'] > 1000 else '   '
        print(
            f"{r['label']:<35} {r['median']:>8.1f} {r['mean']:>8.1f} "
            f"{r['p95']:>8.1f} {r['p99']:>8.1f} {r['max']:>8.1f}{warn}"
        )
    print()
    print('Goal: p95 < 1,000 us per operation  (!! = exceeds target)')
    print(f'Iterations per benchmark: {BENCH_ITERS:,}')


# ─── Benchmark definitions ───────────────────────────────────────────────────

CONFIG = {
    'service_name': 'bench-service',
    'stack': 'django',
    'environment': 'production',
    'framework_version': '4.2',
    'async_mode': False,
    'orm': 'django_orm',
    'api_key': 'sk-bench',
}

SAMPLE_SQLS = [
    "SELECT * FROM users WHERE id = 42",
    "SELECT id, name, email FROM orders WHERE status = 'pending' AND customer_id = 999 ORDER BY created_at DESC LIMIT 50",
    "UPDATE users SET last_login = '2024-01-01' WHERE id = 123",
    "INSERT INTO events (type, payload, created_at) VALUES ('login', '{}', NOW())",
    "SELECT u.id, u.name, o.total FROM users u JOIN orders o ON o.user_id = u.id WHERE u.active = 1",
]


def bench_trace_context_create():
    TraceContext(trace_id='bench-trace-001')


def bench_add_single_query():
    ctx = TraceContext(trace_id='bench-x')
    ctx.add_query(SAMPLE_SQLS[0], 25.0, 1, 'psycopg2')


def bench_add_10_queries():
    ctx = TraceContext(trace_id='bench-x')
    for i, sql in enumerate(SAMPLE_SQLS * 2):
        ctx.add_query(sql, float(i * 10 + 5), i, 'psycopg2')


def bench_sql_normalize():
    q = QueryRecord(SAMPLE_SQLS[1], 30.0, 10, 'psycopg2')
    _ = q.normalized_sql
    _ = q.query_hash


def bench_build_span_empty():
    ctx = TraceContext(trace_id='bench-empty')
    build_span(ctx, CONFIG, 'GET', '/api/users', 200, 'views.py', 'list_users', 42)


def bench_build_span_5_queries():
    ctx = TraceContext(trace_id='bench-5q')
    for sql in SAMPLE_SQLS:
        ctx.add_query(sql, 20.0, 1, 'psycopg2')
    ctx.add_outbound_call('api.stripe.com', '/v1/charges', 'POST', 200, 80.0)
    build_span(ctx, CONFIG, 'POST', '/api/orders', 201, 'views.py', 'create_order', 88)


def bench_build_span_payment_blackout():
    ctx = TraceContext(trace_id='bench-pay')
    for sql in SAMPLE_SQLS:
        ctx.add_query(sql, 20.0, 1, 'psycopg2')
    # Payment route — all data wiped by blackout
    build_span(ctx, CONFIG, 'POST', '/checkout/confirm', 200)


def bench_enqueue():
    span = {
        'trace_id': 'bench-enqueue',
        'service_name': 'bench',
        'attributes': {'http.method': 'GET', 'http.route': '/api/data', 'http.status_code': 200},
    }
    shipper.enqueue(span)


def bench_full_request_cycle():
    """
    Simulates a full lightweight request:
    - create context
    - record 3 DB queries
    - record 1 outbound call
    - build span
    - enqueue for shipping
    This is what the SDK does for every real request.
    """
    ctx = TraceContext(trace_id='bench-full')
    ctx.add_query("SELECT * FROM users WHERE id = 1", 15.0, 1, 'psycopg2')
    ctx.add_query("SELECT * FROM orders WHERE user_id = 1", 22.0, 3, 'psycopg2')
    ctx.add_query("UPDATE users SET last_seen = NOW() WHERE id = 1", 8.0, 1, 'psycopg2')
    ctx.add_outbound_call('api.sendgrid.com', '/v3/mail/send', 'POST', 202, 120.0)
    span = build_span(ctx, CONFIG, 'POST', '/api/user/login', 200, 'auth/views.py', 'login', 55)
    shipper.enqueue(span)


# ─── Run ─────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    print('South Star SDK — Overhead Benchmark')
    print('====================================')
    print(f'Python {sys.version}')

    results = [
        _bench('TraceContext.__init__',          bench_trace_context_create),
        _bench('TraceContext.add_query (×1)',     bench_add_single_query),
        _bench('TraceContext.add_query (×10)',    bench_add_10_queries),
        _bench('QueryRecord normalize + hash',   bench_sql_normalize),
        _bench('build_span (no queries)',         bench_build_span_empty),
        _bench('build_span (5 queries + 1 call)', bench_build_span_5_queries),
        _bench('build_span (payment blackout)',   bench_build_span_payment_blackout),
        _bench('shipper.enqueue',                bench_enqueue),
        _bench('FULL request cycle (3q+1out)',   bench_full_request_cycle),
    ]

    _print_results(results)

    # Summary pass/fail
    full_cycle = next(r for r in results if 'FULL' in r['label'])
    p95 = full_cycle['p95']
    print(f"\nFull request cycle p95 overhead: {p95:.1f} us", end='  ')
    if p95 < 200:
        print('EXCELLENT (< 200 us)')
    elif p95 < 500:
        print('GOOD (< 500 us)')
    elif p95 < 1000:
        print('ACCEPTABLE (< 1 ms)')
    else:
        print('INVESTIGATE (> 1 ms)')
