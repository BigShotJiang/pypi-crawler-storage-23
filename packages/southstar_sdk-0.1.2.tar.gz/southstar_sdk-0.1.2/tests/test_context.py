"""
Tests for southstar/context.py
Verifies trace context, SQL normalization, and computed properties.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from southstar.context import TraceContext, QueryRecord, get_current, set_current


class TestQueryRecord:
    def test_normalizes_string_literals(self):
        q = QueryRecord("SELECT * FROM users WHERE name = 'Alice'", 10.0, 1, 'psycopg2')
        assert 'Alice' not in q.normalized_sql
        assert '?' in q.normalized_sql

    def test_normalizes_integers(self):
        q = QueryRecord("SELECT * FROM users WHERE id = 42", 10.0, 1, 'psycopg2')
        assert '42' not in q.normalized_sql
        assert '?' in q.normalized_sql

    def test_identical_hash_for_same_structure(self):
        q1 = QueryRecord("SELECT * FROM users WHERE id = 1", 5.0, 1, 'psycopg2')
        q2 = QueryRecord("SELECT * FROM users WHERE id = 999", 5.0, 1, 'psycopg2')
        assert q1.query_hash == q2.query_hash

    def test_different_hash_for_different_structure(self):
        q1 = QueryRecord("SELECT * FROM users WHERE id = 1", 5.0, 1, 'psycopg2')
        q2 = QueryRecord("SELECT * FROM orders WHERE id = 1", 5.0, 1, 'psycopg2')
        assert q1.query_hash != q2.query_hash

    def test_query_type_detection(self):
        cases = [
            ("SELECT id FROM t", "SELECT"),
            ("INSERT INTO t VALUES (?)", "INSERT"),
            ("UPDATE t SET x = ?", "UPDATE"),
            ("DELETE FROM t WHERE id = ?", "DELETE"),
            ("WITH cte AS (SELECT 1) SELECT * FROM cte", "SELECT"),
        ]
        for sql, expected_type in cases:
            q = QueryRecord(sql, 1.0, 0, 'test')
            assert q.query_type == expected_type, f"Expected {expected_type} for {sql!r}"

    def test_normalized_sql_truncated_at_2000(self):
        long_sql = "SELECT " + "a, " * 1000 + "b FROM t"
        q = QueryRecord(long_sql, 1.0, 0, 'test')
        assert len(q.normalized_sql) <= 2000


class TestTraceContext:
    def _make_ctx(self):
        return TraceContext(trace_id='test-abc')

    def test_add_query(self):
        ctx = self._make_ctx()
        ctx.add_query("SELECT * FROM t WHERE id = 1", 50.0, 5, 'psycopg2')
        assert len(ctx.queries) == 1

    def test_db_select_count(self):
        ctx = self._make_ctx()
        ctx.add_query("SELECT * FROM a", 10.0, 1, 'psycopg2')
        ctx.add_query("SELECT * FROM b", 10.0, 1, 'psycopg2')
        ctx.add_query("INSERT INTO c VALUES (?)", 5.0, 0, 'psycopg2')
        assert ctx.db_select_count == 2
        assert ctx.db_write_count == 1

    def test_has_slow_query(self):
        ctx = self._make_ctx()
        ctx.add_query("SELECT * FROM t", 50.0, 1, 'psycopg2')
        assert not ctx.has_slow_query
        ctx.add_query("SELECT * FROM big", 500.0, 1000, 'psycopg2')
        assert ctx.has_slow_query

    def test_slowest_query_ms(self):
        ctx = self._make_ctx()
        ctx.add_query("SELECT 1", 10.0, 1, 'psycopg2')
        ctx.add_query("SELECT 2", 75.0, 1, 'psycopg2')
        assert ctx.slowest_query_ms == 75.0

    def test_slowest_query_no_queries(self):
        ctx = self._make_ctx()
        assert ctx.slowest_query_ms == 0.0

    def test_outbound_duplicate_count(self):
        ctx = self._make_ctx()
        ctx.add_outbound_call('api.stripe.com', '/charge', 'POST', 200, 100.0)
        ctx.add_outbound_call('api.stripe.com', '/charge', 'POST', 200, 100.0)
        ctx.add_outbound_call('api.sendgrid.com', '/send', 'POST', 202, 50.0)
        assert ctx.outbound_duplicate_count == 1  # stripe called twice

    def test_elapsed_ms_positive(self):
        import time
        ctx = self._make_ctx()
        time.sleep(0.01)
        assert ctx.elapsed_ms > 0

    def test_set_error(self):
        ctx = self._make_ctx()
        ctx.set_error('ValueError', 'app/views.py', 42, [])
        assert ctx.error is not None
        assert ctx.error.error_type == 'ValueError'


class TestContextVar:
    def test_get_set_current(self):
        ctx = TraceContext(trace_id='ctx-var-test')
        set_current(ctx)
        assert get_current() is ctx

    def test_clear_current(self):
        ctx = TraceContext(trace_id='ctx-var-test-2')
        set_current(ctx)
        set_current(None)
        assert get_current() is None

    def test_default_is_none(self):
        set_current(None)
        assert get_current() is None
