"""
Tests for southstar/sanitizer.py
Verifies build_span output structure, payment blackout, and field filtering.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from southstar.sanitizer import build_span, is_payment_route
from southstar.context import TraceContext


# ─── Helpers ────────────────────────────────────────────────────────────────

def _make_ctx(**kwargs):
    return TraceContext(trace_id='test-trace', **kwargs)

def _make_config(**overrides):
    base = {
        'service_name': 'my-api',
        'stack': 'django',
        'environment': 'production',
        'framework_version': '4.2',
        'async_mode': False,
        'orm': 'django_orm',
        'api_key': 'sk-test',
    }
    base.update(overrides)
    return base


# ─── is_payment_route ───────────────────────────────────────────────────────

class TestIsPaymentRoute:
    def test_payment_patterns_detected(self):
        for pattern in ['/payment', '/checkout', '/billing', '/stripe', '/invoice', '/card', '/refund']:
            assert is_payment_route(pattern), f"Expected {pattern!r} to be a payment route"

    def test_case_insensitive(self):
        assert is_payment_route('/PAYMENT/process')
        assert is_payment_route('/Checkout/step2')

    def test_partial_match_in_path(self):
        assert is_payment_route('/api/v1/stripe/webhook')
        assert is_payment_route('/user/billing/info')

    def test_non_payment_routes_not_matched(self):
        for route in ['/api/users', '/health', '/api/orders', '/api/accounts']:
            assert not is_payment_route(route), f"Expected {route!r} NOT to be a payment route"


# ─── build_span — normal routes ─────────────────────────────────────────────

class TestBuildSpanNormal:
    def _span(self, ctx=None, config=None, method='GET', route='/api/users', status=200):
        ctx = ctx or _make_ctx()
        config = config or _make_config()
        return build_span(ctx, config, method, route, status, 'views.py', 'get_users', 42)

    def test_required_top_level_keys(self):
        span = self._span()
        for key in ['trace_id', 'service_name', 'stack', 'language', 'environment',
                    'timestamp_ms', 'duration_ms', 'source_location', 'attributes']:
            assert key in span, f"Missing top-level key: {key}"

    def test_service_name_from_config(self):
        span = self._span(config=_make_config(service_name='payments-svc'))
        assert span['service_name'] == 'payments-svc'

    def test_language_always_python(self):
        span = self._span()
        assert span['language'] == 'python'

    def test_source_location_set(self):
        span = self._span()
        loc = span['source_location']
        assert loc['file'] == 'views.py'
        assert loc['function'] == 'get_users'
        assert loc['line'] == 42

    def test_attributes_http_fields(self):
        span = self._span(method='POST', route='/api/orders', status=201)
        attrs = span['attributes']
        assert attrs['http.method'] == 'POST'
        assert attrs['http.route'] == '/api/orders'
        assert attrs['http.status_code'] == 201

    def test_db_queries_included(self):
        ctx = _make_ctx()
        ctx.add_query("SELECT * FROM users WHERE id = 1", 25.0, 1, 'psycopg2')
        span = self._span(ctx=ctx)
        queries = span['attributes']['db_queries']
        assert len(queries) == 1
        q = queries[0]
        assert 'query_hash' in q
        assert 'normalized_sql' in q
        assert q['duration_ms'] == 25.0
        assert q['rows_examined'] == 1
        assert q['db_driver'] == 'psycopg2'
        assert 'query_type' in q

    def test_raw_sql_values_not_in_span(self):
        ctx = _make_ctx()
        ctx.add_query("SELECT * FROM users WHERE name = 'Alice'", 10.0, 1, 'psycopg2')
        span = self._span(ctx=ctx)
        q = span['attributes']['db_queries'][0]
        # normalized_sql must not contain the literal value
        assert 'Alice' not in q['normalized_sql']
        # raw_sql must not appear as a key at all
        assert 'raw_sql' not in q

    def test_outbound_calls_included(self):
        ctx = _make_ctx()
        ctx.add_outbound_call('api.stripe.com', '/v1/charges', 'POST', 200, 150.0)
        span = self._span(ctx=ctx)
        calls = span['attributes']['outbound_calls']
        assert len(calls) == 1
        c = calls[0]
        assert c['host'] == 'api.stripe.com'
        assert c['path'] == '/v1/charges'
        assert c['method'] == 'POST'
        assert c['status_code'] == 200
        assert c['duration_ms'] == 150.0

    def test_error_included(self):
        ctx = _make_ctx()
        ctx.set_error('ValueError', 'app/views.py', 99, [])
        span = self._span(ctx=ctx)
        err = span['attributes']['error']
        assert err is not None
        assert err['error_type'] == 'ValueError'
        assert err['error_file'] == 'app/views.py'
        assert err['error_line'] == 99

    def test_no_error_is_null(self):
        span = self._span()
        assert span['attributes']['error'] is None

    def test_computed_db_signals(self):
        ctx = _make_ctx()
        ctx.add_query("SELECT 1", 10.0, 1, 'psycopg2')
        ctx.add_query("SELECT 2", 10.0, 1, 'psycopg2')
        ctx.add_query("INSERT INTO t VALUES (?)", 5.0, 0, 'psycopg2')
        span = self._span(ctx=ctx)
        attrs = span['attributes']
        assert attrs['db_select_count'] == 2
        assert attrs['db_write_count'] == 1

    def test_has_slow_query_false(self):
        ctx = _make_ctx()
        ctx.add_query("SELECT 1", 50.0, 1, 'psycopg2')  # under 100ms threshold
        span = self._span(ctx=ctx)
        assert span['attributes']['has_slow_query'] is False

    def test_has_slow_query_true(self):
        ctx = _make_ctx()
        ctx.add_query("SELECT * FROM big_table", 500.0, 10000, 'psycopg2')
        span = self._span(ctx=ctx)
        assert span['attributes']['has_slow_query'] is True
        assert span['attributes']['slowest_query_ms'] == 500.0

    def test_outbound_duplicate_count(self):
        ctx = _make_ctx()
        ctx.add_outbound_call('api.stripe.com', '/charge', 'POST', 200, 100.0)
        ctx.add_outbound_call('api.stripe.com', '/charge', 'POST', 200, 100.0)
        span = self._span(ctx=ctx)
        assert span['attributes']['outbound_duplicate_count'] == 1

    def test_timestamp_ms_is_integer(self):
        span = self._span()
        assert isinstance(span['timestamp_ms'], int)

    def test_duration_ms_is_positive(self):
        span = self._span()
        assert span['duration_ms'] >= 0


# ─── build_span — payment blackout ──────────────────────────────────────────

class TestBuildSpanPaymentBlackout:
    def _payment_span(self, route='/checkout/confirm'):
        ctx = _make_ctx()
        ctx.add_query("SELECT * FROM orders WHERE id = 1", 20.0, 1, 'psycopg2')
        ctx.add_outbound_call('api.stripe.com', '/charge', 'POST', 200, 100.0)
        ctx.set_error('PaymentError', 'payments.py', 55, [])
        return build_span(ctx, _make_config(), 'POST', route, 200, 'checkout.py', 'confirm', 10)

    def test_route_replaced(self):
        span = self._payment_span()
        assert span['attributes']['http.route'] == '[PAYMENT ENDPOINT]'

    def test_db_queries_empty(self):
        span = self._payment_span()
        assert span['attributes']['db_queries'] == []

    def test_outbound_calls_empty(self):
        span = self._payment_span()
        assert span['attributes']['outbound_calls'] == []

    def test_error_is_null(self):
        span = self._payment_span()
        assert span['attributes']['error'] is None

    def test_db_counts_zeroed(self):
        span = self._payment_span()
        attrs = span['attributes']
        assert attrs['db_select_count'] == 0
        assert attrs['db_write_count'] == 0
        assert attrs['has_slow_query'] is False
        assert attrs['slowest_query_ms'] == 0.0
        assert attrs['outbound_duplicate_count'] == 0

    def test_duration_still_present(self):
        """Duration and status code are kept even for payment routes."""
        span = self._payment_span()
        assert span['duration_ms'] >= 0
        assert span['attributes']['http.status_code'] == 200

    def test_various_payment_routes_blacked_out(self):
        for route in ['/payment/new', '/billing/plan', '/api/stripe/hook',
                      '/invoice/123', '/card/add', '/refund/request']:
            span = build_span(_make_ctx(), _make_config(), 'POST', route, 200)
            assert span['attributes']['http.route'] == '[PAYMENT ENDPOINT]', \
                f"Expected blackout for route {route!r}"

    def test_non_payment_route_not_blacked_out(self):
        span = build_span(_make_ctx(), _make_config(), 'GET', '/api/users', 200)
        assert span['attributes']['http.route'] == '/api/users'

    def test_build_span_does_not_mutate_context(self):
        """build_span must not modify the TraceContext it receives."""
        ctx = _make_ctx()
        ctx.add_query("SELECT * FROM users", 10.0, 1, 'psycopg2')
        original_query_count = len(ctx.queries)
        build_span(ctx, _make_config(), 'POST', '/checkout', 200)
        assert len(ctx.queries) == original_query_count


# ─── build_span — edge cases ─────────────────────────────────────────────────

class TestBuildSpanEdgeCases:
    def test_no_queries_no_calls(self):
        span = build_span(_make_ctx(), _make_config(), 'GET', '/health', 200)
        assert span['attributes']['db_queries'] == []
        assert span['attributes']['outbound_calls'] == []
        assert span['attributes']['db_select_count'] == 0

    def test_source_location_defaults(self):
        """build_span can be called without source_* args."""
        ctx = _make_ctx()
        span = build_span(ctx, _make_config(), 'GET', '/ping', 200)
        loc = span['source_location']
        assert loc['file'] == ''
        assert loc['function'] == ''
        assert loc['line'] is None

    def test_config_env_propagated(self):
        cfg = _make_config(environment='staging', stack='fastapi')
        span = build_span(_make_ctx(), cfg, 'GET', '/api', 200)
        assert span['environment'] == 'staging'
        assert span['stack'] == 'fastapi'

    def test_duration_ms_rounded(self):
        ctx = _make_ctx()
        ctx.add_query("SELECT 1", 25.123456, 1, 'psycopg2')
        span = build_span(ctx, _make_config(), 'GET', '/api', 200)
        q = span['attributes']['db_queries'][0]
        # duration should be rounded to 2 decimal places
        assert q['duration_ms'] == round(25.123456, 2)
