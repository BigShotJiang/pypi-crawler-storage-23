"""
Tests for southstar/shipper.py
Verifies queue behavior, drop-on-full, and worker idempotency.
These tests do NOT make real network calls — all HTTP is patched out.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import queue
import threading
import time
from unittest.mock import patch, MagicMock


# ─── Helpers ────────────────────────────────────────────────────────────────

def _fresh_shipper():
    """
    Re-import shipper with a clean module state so each test gets an independent
    queue and _worker_started flag.
    """
    import importlib
    import southstar.shipper as mod
    # Reset module-level state between tests
    mod._queue = queue.Queue(maxsize=5000)
    mod._worker_started = False
    return mod


# ─── enqueue ────────────────────────────────────────────────────────────────

class TestEnqueue:
    def test_enqueue_adds_to_queue(self):
        sh = _fresh_shipper()
        span = {'trace_id': 'abc', 'service_name': 'test'}
        sh.enqueue(span)
        assert sh._queue.qsize() == 1

    def test_enqueue_multiple(self):
        sh = _fresh_shipper()
        for i in range(10):
            sh.enqueue({'trace_id': str(i)})
        assert sh._queue.qsize() == 10

    def test_enqueue_full_queue_drops_silently(self):
        """When the queue is full, enqueue must NOT raise or block."""
        sh = _fresh_shipper()
        sh._queue = queue.Queue(maxsize=3)
        for _ in range(3):
            sh._queue.put_nowait({'trace_id': 'x'})
        # This 4th call must not raise
        sh.enqueue({'trace_id': 'overflow'})
        assert sh._queue.qsize() == 3  # still 3, overflow dropped

    def test_enqueue_does_not_block(self):
        """enqueue must return in well under 1ms even on a full queue."""
        sh = _fresh_shipper()
        sh._queue = queue.Queue(maxsize=1)
        sh._queue.put_nowait({'a': 1})
        start = time.monotonic()
        sh.enqueue({'b': 2})
        elapsed = time.monotonic() - start
        assert elapsed < 0.01, f"enqueue blocked for {elapsed:.3f}s"


# ─── start_worker ────────────────────────────────────────────────────────────

class TestStartWorker:
    def test_start_worker_sets_flag(self):
        sh = _fresh_shipper()
        assert sh._worker_started is False
        with patch.object(threading.Thread, 'start'):
            sh.start_worker('sk-test')
        assert sh._worker_started is True

    def test_start_worker_idempotent(self):
        """Calling start_worker twice must not launch two threads."""
        sh = _fresh_shipper()
        launch_count = 0
        original_start = threading.Thread.start

        def counting_start(self_thread):
            nonlocal launch_count
            launch_count += 1

        with patch.object(threading.Thread, 'start', counting_start):
            sh.start_worker('sk-test')
            sh.start_worker('sk-test')
            sh.start_worker('sk-test')

        assert launch_count == 1, f"Expected 1 thread launch, got {launch_count}"

    def test_worker_thread_is_daemon(self):
        """The background thread must be a daemon so it doesn't prevent process exit."""
        sh = _fresh_shipper()
        created_threads = []
        original_init = threading.Thread.__init__

        def capturing_init(self_thread, *args, **kwargs):
            original_init(self_thread, *args, **kwargs)
            created_threads.append(self_thread)

        with patch.object(threading.Thread, '__init__', capturing_init):
            with patch.object(threading.Thread, 'start'):
                sh.start_worker('sk-test')

        assert any(t.daemon for t in created_threads), "Worker thread must be daemon=True"


# ─── _ship_batch (network calls mocked) ─────────────────────────────────────

class TestShipBatch:
    def _run_ship(self, sh, spans, *, daemon_ok=True, api_ok=True):
        """Run _ship_batch with mocked requests."""
        daemon_resp = MagicMock()
        daemon_resp.ok = daemon_ok

        api_resp = MagicMock()
        api_resp.ok = api_ok

        call_log = []

        def mock_post(url, **kwargs):
            call_log.append(url)
            if 'localhost' in url:
                return daemon_resp
            return api_resp

        with patch('requests.post', side_effect=mock_post):
            sh._ship_batch(spans, 'sk-test')

        return call_log

    def test_ships_to_daemon_first(self):
        sh = _fresh_shipper()
        calls = self._run_ship(sh, [{'a': 1}], daemon_ok=True)
        assert any('localhost' in c for c in calls)

    def test_falls_back_to_api_when_daemon_fails(self):
        sh = _fresh_shipper()
        calls = self._run_ship(sh, [{'a': 1}], daemon_ok=False)
        assert any('southstar' in c for c in calls), \
            "Should fall back to South Star API when daemon unreachable"

    def test_no_api_call_when_daemon_succeeds(self):
        sh = _fresh_shipper()
        calls = self._run_ship(sh, [{'a': 1}], daemon_ok=True)
        api_calls = [c for c in calls if 'southstar' in c]
        assert api_calls == [], "Should NOT call South Star API when daemon responds OK"

    def test_daemon_exception_triggers_fallback(self):
        """If daemon raises (connection refused), fall back to API silently."""
        sh = _fresh_shipper()
        api_calls = []

        def mock_post(url, **kwargs):
            if 'localhost' in url:
                raise ConnectionRefusedError("no daemon")
            api_calls.append(url)
            return MagicMock(ok=True)

        with patch('requests.post', side_effect=mock_post):
            sh._ship_batch([{'trace_id': 'x'}], 'sk-test')

        assert len(api_calls) == 1

    def test_api_exception_does_not_raise(self):
        """If both daemon and API fail, _ship_batch must NOT propagate the exception."""
        sh = _fresh_shipper()

        def always_raise(url, **kwargs):
            raise OSError("no network")

        with patch('requests.post', side_effect=always_raise):
            # Must not raise
            sh._ship_batch([{'trace_id': 'x'}], 'sk-test')

    def test_api_key_sent_in_header(self):
        sh = _fresh_shipper()
        captured_kwargs = {}

        def mock_post(url, **kwargs):
            captured_kwargs[url] = kwargs
            if 'localhost' in url:
                resp = MagicMock()
                resp.ok = False
                return resp
            return MagicMock(ok=True)

        with patch('requests.post', side_effect=mock_post):
            sh._ship_batch([{'trace_id': 'x'}], 'sk-abc123')

        api_url = next(u for u in captured_kwargs if 'southstar' in u)
        headers = captured_kwargs[api_url].get('headers', {})
        assert headers.get('X-API-Key') == 'sk-abc123'
