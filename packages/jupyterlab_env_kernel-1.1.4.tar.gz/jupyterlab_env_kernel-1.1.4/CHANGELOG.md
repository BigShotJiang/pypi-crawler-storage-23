# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 1.1.4

No merged PRs

<!-- <END NEW CHANGELOG ENTRY> -->

## 1.1.3

No merged PRs

## 1.1.2

No merged PRs

## 1.1.1

([Full Changelog](https://github.com/SofianeB/jupyterlab-env-kernel/compare/v1.1.0...3deff94de9d94cd7befa5aaa44cf5355d066d527))

### Bugs fixed

- Fix conda env path [#2](https://github.com/SofianeB/jupyterlab-env-kernel/pull/2) ([@SofianeB](https://github.com/SofianeB))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/SofianeB/jupyterlab-env-kernel/graphs/contributors?from=2026-03-02&to=2026-03-03&type=c))

@SofianeB ([activity](https://github.com/search?q=repo%3ASofianeB%2Fjupyterlab-env-kernel+involves%3ASofianeB+updated%3A2026-03-02..2026-03-03&type=Issues))

## 1.1.0

No merged PRs

## 1.0.1

No merged PRs

## 1.0.0

No merged PRs

## 0.1.8

No merged PRs

## 0.1.7

No merged PRs

## 0.1.4

No merged PRs

## 0.1.3

No merged PRs

## 0.1.1

No merged PRs

## 0.1.1

No merged PRs
