"""
IdleFinance core module. Contains the pandas accessors and centralized type definitions.
"""
