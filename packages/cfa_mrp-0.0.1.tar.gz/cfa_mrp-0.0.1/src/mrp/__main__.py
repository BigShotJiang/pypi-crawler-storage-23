from mrp.cli import main

raise SystemExit(main())
