# Credits

## Development Lead

* Manfred Dennerlein Rodelo <manfred@dennerlein.name>

## Contributors

* [cdce8p](https://github.com/cdce8p)
