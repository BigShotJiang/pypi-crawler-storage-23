"""Base interface for connecting agents to messaging platforms."""

from types import TracebackType
import asyncio
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, List, Optional

from definable.agent.auth.base import AuthRequest, resolve_auth
from definable.agent.interface.config import InterfaceConfig
from definable.agent.interface.hooks import InterfaceHook
from definable.agent.interface.message import InterfaceMessage, InterfaceResponse
from definable.agent.interface.session import InterfaceSession, SessionManager
from definable.agent.events import RunOutput
from definable.utils.log import log_error, log_info, log_warning

if TYPE_CHECKING:
  from definable.agent.agent import Agent
  from definable.agent.interface.identity import IdentityResolver


class BaseInterface(ABC):
  """Abstract base class for platform interfaces.

  Provides the full message pipeline from platform message reception
  through agent execution to response delivery, with hook support
  at every stage.

  Subclasses must implement the four abstract methods to integrate
  with a specific messaging platform.

  Args:
    agent: The Agent instance to connect.
    config: Interface configuration.
    session_manager: Optional session manager (created automatically if not provided).
    hooks: Optional list of hooks to register.
    identity_resolver: Optional resolver for mapping platform user IDs to canonical user IDs.
    auth: Optional auth provider for this interface. Receives an AuthRequest
      and returns AuthContext on success, None to reject. Set to False to
      explicitly disable auth.

  Example:
    class MyPlatformInterface(BaseInterface):
      async def _start_receiver(self): ...
      async def _stop_receiver(self): ...
      async def _convert_inbound(self, raw_message): ...
      async def _send_response(self, original_msg, response, raw_message): ...
  """

  def __init__(
    self,
    *,
    agent: Optional["Agent"] = None,
    config: InterfaceConfig,
    session_manager: Optional[SessionManager] = None,
    hooks: Optional[List[InterfaceHook]] = None,
    identity_resolver: Optional["IdentityResolver"] = None,
    auth: Optional[Any] = None,
  ) -> None:
    self.agent: Optional["Agent"] = agent
    self.config = config
    self.session_manager = session_manager or SessionManager(
      session_ttl_seconds=config.session_ttl_seconds,
    )
    self._hooks: List[InterfaceHook] = list(hooks or [])
    self._identity_resolver: Optional["IdentityResolver"] = identity_resolver
    self._identity_resolver_initialized = False
    self._auth = auth
    self._running = False
    self._request_semaphore: Optional[asyncio.Semaphore] = None

  # --- Hook management ---

  def add_hook(self, hook: InterfaceHook) -> "BaseInterface":
    """Add a hook to the interface.

    Args:
      hook: Hook instance to add.

    Returns:
      Self for method chaining.
    """
    self._hooks.append(hook)
    return self

  def bind(self, agent: "Agent") -> "BaseInterface":
    """Bind this interface to an agent.

    Args:
      agent: The Agent instance to bind.

    Returns:
      Self for method chaining.

    Raises:
      RuntimeError: If the interface is already running.
    """
    if self._running:
      raise RuntimeError("Cannot bind agent while interface is running")
    self.agent = agent
    return self

  # --- Auth ---

  async def _check_auth(self, message: InterfaceMessage) -> bool:
    """Check auth for an inbound message.

    Constructs an :class:`AuthRequest` from the message fields and passes
    it to the configured auth provider.

    Args:
      message: The normalized inbound message.

    Returns:
      True if auth passes (or no auth configured), False to reject.
    """
    if self._auth is None or self._auth is False:
      return True

    auth_request = AuthRequest(
      platform=message.platform,
      user_id=message.platform_user_id,
      username=message.username,
      chat_id=message.platform_chat_id,
      metadata=dict(message.metadata),
    )

    try:
      auth_context = await resolve_auth(self._auth, auth_request)
    except Exception as e:
      log_warning(f"[{self.config.platform}] Auth provider error: {e}")
      return False

    if auth_context is None:
      log_info(f"[{self.config.platform}] Auth rejected user={message.platform_user_id}")
      return False

    message.metadata["auth_context"] = auth_context
    return True

  # --- Lifecycle ---

  async def start(self) -> None:
    """Start the interface (begin receiving messages)."""
    if self._running:
      return
    if self.agent is None:
      raise ValueError("Interface has no agent bound. Call bind(agent) or pass agent= to constructor.")
    self._request_semaphore = asyncio.Semaphore(self.config.max_concurrent_requests)
    self._running = True
    log_info(f"[{self.config.platform}] Interface starting")
    await self._start_receiver()
    log_info(f"[{self.config.platform}] Interface started")

  async def stop(self) -> None:
    """Stop the interface (stop receiving messages)."""
    if not self._running:
      return
    self._running = False
    log_info(f"[{self.config.platform}] Interface stopping")
    await self._stop_receiver()
    log_info(f"[{self.config.platform}] Interface stopped")

  async def serve_forever(self) -> None:
    """Block until the interface is stopped (e.g. via signal or stop())."""
    if self.agent is None:
      raise ValueError("Interface has no agent bound. Call bind(agent) or pass agent= to constructor.")
    if not self._running:
      await self.start()
    try:
      while self._running:
        await asyncio.sleep(1)
    except asyncio.CancelledError:
      pass
    finally:
      await self.stop()

  async def __aenter__(self) -> "BaseInterface":
    """Async context manager entry."""
    await self.start()
    return self

  async def __aexit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: TracebackType | None) -> None:
    """Async context manager exit."""
    await self.stop()

  # --- Abstract methods (platform implementations) ---

  @abstractmethod
  async def _start_receiver(self) -> None:
    """Start the platform-specific message receiver (polling, webhook, etc.)."""
    ...

  @abstractmethod
  async def _stop_receiver(self) -> None:
    """Stop the platform-specific message receiver. Must be idempotent."""
    ...

  @abstractmethod
  async def _convert_inbound(self, raw_message: Any) -> Optional[InterfaceMessage]:
    """Convert a platform-specific message to an InterfaceMessage.

    Args:
      raw_message: The raw message from the platform.

    Returns:
      InterfaceMessage, or None to skip this message.
    """
    ...

  @abstractmethod
  async def _send_response(
    self,
    original_msg: InterfaceMessage,
    response: InterfaceResponse,
    raw_message: Any,
  ) -> None:
    """Send a response back to the platform.

    Args:
      original_msg: The original InterfaceMessage that triggered this response.
      response: The InterfaceResponse to send.
      raw_message: The raw platform message (for reply context).
    """
    ...

  # --- Message pipeline ---

  async def handle_platform_message(self, raw_message: Any) -> None:
    """Process a single platform message through the full pipeline.

    Pipeline steps:
      1. Convert inbound message
      2. Auth check (if configured)
      3. Run on_message_received hooks (can veto)
      4. Get/create session
      5. Run on_before_respond hooks (can modify message)
      6. Call agent.arun()
      7. Build InterfaceResponse from RunOutput
      8. Run on_after_respond hooks (can modify response)
      9. Send response to platform
      10. Update session history

    Args:
      raw_message: The raw message from the platform.
    """
    message: Optional[InterfaceMessage] = None
    try:
      # 1. Convert inbound
      message = await self._convert_inbound(raw_message)
      if message is None:
        return

      # 2. Auth check
      if not await self._check_auth(message):
        return

      # 3. Run on_message_received hooks
      for hook in self._hooks:
        if hasattr(hook, "on_message_received"):
          result = await hook.on_message_received(message)
          if result is False:
            return

      # 4. Get/create session
      session = self.session_manager.get_or_create(
        platform=message.platform,
        user_id=message.platform_user_id,
        chat_id=message.platform_chat_id,
      )

      # 5. Run on_before_respond hooks
      for hook in self._hooks:
        if hasattr(hook, "on_before_respond"):
          modified = await hook.on_before_respond(message, session)
          if modified is not None:
            message = modified

      # 6. Call agent
      assert self._request_semaphore is not None
      async with self._request_semaphore:
        run_output = await self._run_agent(message, session)

      # 7. Build response
      response = self._build_response(run_output)

      # 8. Run on_after_respond hooks
      for hook in self._hooks:
        if hasattr(hook, "on_after_respond"):
          modified = await hook.on_after_respond(message, response, session)  # type: ignore[assignment]
          if modified is not None:
            response = modified  # type: ignore[assignment]

      # 9. Send response
      await self._send_response(message, response, raw_message)

      # 10. Update session
      self._update_session(session, run_output)

    except Exception as e:
      await self._handle_error(e, message, raw_message)

  async def _safe_resolve_identity(self, platform: str, platform_user_id: str) -> Optional[str]:
    """Resolve a platform user ID to a canonical user ID, returning None on failure.

    Initializes the resolver on first call. Any exceptions are logged
    as warnings and None is returned (non-fatal).

    Args:
      platform: Platform name (e.g. "telegram").
      platform_user_id: User ID on the platform.

    Returns:
      Canonical user ID, or None if unresolved or on error.
    """
    assert self._identity_resolver is not None
    try:
      if not self._identity_resolver_initialized:
        await self._identity_resolver.initialize()
        self._identity_resolver_initialized = True
      return await self._identity_resolver.resolve(platform, platform_user_id)
    except Exception as e:
      log_warning(f"[{self.config.platform}] Identity resolution failed for {platform}:{platform_user_id}: {e}")
      return None

  async def _run_agent(self, message: InterfaceMessage, session: InterfaceSession) -> RunOutput:
    """Run the agent with the given message and session context.

    Args:
      message: The normalized InterfaceMessage.
      session: The session for this conversation.

    Returns:
      RunOutput from the agent.
    """
    user_id = message.platform_user_id

    # Prefer identity resolver if configured
    if self._identity_resolver is not None:
      resolved = await self._safe_resolve_identity(message.platform, message.platform_user_id)
      if resolved is not None:
        user_id = resolved
    elif "auth_context" in message.metadata:
      # Fall back to auth_context user_id if no identity resolver
      user_id = message.metadata["auth_context"].user_id

    assert self.agent is not None

    # If the agent has an explicitly configured session_id, use it for memory continuity.
    # Otherwise, use the interface session's session_id (per-user isolation for multi-user interfaces).
    run_session_id = session.session_id
    if getattr(self.agent, "_session_id_explicit", False):
      run_session_id = self.agent.session_id

    return await self.agent.arun(
      instruction=message.text or "",
      messages=session.messages,
      session_id=run_session_id,
      user_id=user_id,
      images=message.images,
      audio=message.audio,
      videos=message.videos,
      files=message.files,
    )

  def _build_response(self, run_output: RunOutput) -> InterfaceResponse:
    """Build an InterfaceResponse from the agent's RunOutput.

    Args:
      run_output: The agent's output.

    Returns:
      InterfaceResponse with content and media.
    """
    content: Optional[str] = None
    if run_output.content is not None:
      content = str(run_output.content)

    return InterfaceResponse(
      content=content,
      images=list(run_output.images) if run_output.images else None,
      videos=list(run_output.videos) if run_output.videos else None,
      audio=list(run_output.audio) if run_output.audio else None,
      files=list(run_output.files) if run_output.files else None,
    )

  def _update_session(self, session: InterfaceSession, run_output: RunOutput) -> None:
    """Update session with the agent's output.

    Args:
      session: The session to update.
      run_output: The agent's output.
    """
    session.last_run_output = run_output
    if run_output.messages:
      session.messages = list(run_output.messages)
    session.truncate_history(self.config.max_session_history)
    session.touch()

  async def _handle_error(
    self,
    error: Exception,
    message: Optional[InterfaceMessage],
    raw_message: Any,
  ) -> None:
    """Handle errors during message processing.

    Runs on_error hooks and attempts to send the configured error
    message back to the user.

    Args:
      error: The exception that occurred.
      message: The InterfaceMessage if available.
      raw_message: The raw platform message.
    """
    log_error(f"[{self.config.platform}] Error processing message: {error}")

    # Run on_error hooks
    for hook in self._hooks:
      if hasattr(hook, "on_error"):
        try:
          await hook.on_error(error, message)
        except Exception as hook_error:
          log_error(f"[{self.config.platform}] Hook on_error failed: {hook_error}")

    # Try to send error message to user
    if message is not None:
      try:
        error_response = InterfaceResponse(content=self.config.error_message)
        await self._send_response(message, error_response, raw_message)
      except Exception as send_error:
        log_error(f"[{self.config.platform}] Failed to send error message: {send_error}")
