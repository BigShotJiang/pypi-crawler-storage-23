from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from typing import Any

from rawctx.converter.base import (
    ConvertedPackage,
    ConversionError,
    DatasetIR,
    DialectExpressionIR,
    ExpressionIR,
    FieldIR,
    MetricIR,
    ProjectIR,
    RelationshipIR,
    SemanticModelIR,
)
from rawctx.formats.metricflow import ParsedMetricFlowProject, load_metricflow_project


_ALLOWED_DIALECTS = {"ANSI_SQL", "SNOWFLAKE", "MDX", "TABLEAU", "DATABRICKS"}
_REF_CALL_RE = re.compile(r"^ref\(\s*['\"]([^'\"]+)['\"]\s*\)$")
_SOURCE_CALL_RE = re.compile(r"^source\(\s*['\"]([^'\"]+)['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)$")
_SAFE_NAME_RE = re.compile(r"[^a-z0-9_-]+")


@dataclass(frozen=True)
class _EntityRef:
    model_name: str
    column_name: str
    entity_type: str


@dataclass(frozen=True)
class _BuildState:
    semantic_models: list[dict[str, Any]]
    metrics: list[dict[str, Any]]


def _clean_str(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def _ensure_no_jinja(expression: str, *, file_path: Path | None, field: str) -> None:
    if "{{" in expression or "{%" in expression:
        raise ConversionError(
            "unresolved Jinja is not supported in Round 6 conversion",
            file_path=file_path,
            field=field,
        )


def _as_expression_ir(raw: Any, *, file_path: Path | None, field: str) -> ExpressionIR:
    if isinstance(raw, dict):
        dialects_raw = raw.get("dialects")
        if not isinstance(dialects_raw, list) or not dialects_raw:
            raise ConversionError("expression.dialects must be a non-empty list", file_path=file_path, field=field)

        dialects: list[DialectExpressionIR] = []
        for idx, item in enumerate(dialects_raw):
            if not isinstance(item, dict):
                raise ConversionError("dialect expression must be an object", file_path=file_path, field=f"{field}.dialects[{idx}]")

            dialect = _clean_str(item.get("dialect"))
            expression = _clean_str(item.get("expression"))
            if dialect is None or expression is None:
                raise ConversionError("dialect expression requires dialect and expression", file_path=file_path, field=f"{field}.dialects[{idx}]")
            if dialect not in _ALLOWED_DIALECTS:
                raise ConversionError(f"unsupported dialect '{dialect}'", file_path=file_path, field=f"{field}.dialects[{idx}].dialect")
            _ensure_no_jinja(expression, file_path=file_path, field=f"{field}.dialects[{idx}].expression")
            dialects.append(DialectExpressionIR(dialect=dialect, expression=expression))

        return ExpressionIR(dialects=dialects)

    expression = _clean_str(raw)
    if expression is None:
        raise ConversionError("expression must be a non-empty string", file_path=file_path, field=field)

    _ensure_no_jinja(expression, file_path=file_path, field=field)
    return ExpressionIR(dialects=[DialectExpressionIR(dialect="ANSI_SQL", expression=expression)])


def _normalize_source(raw_source: Any, *, file_path: Path | None, field: str, fallback_name: str) -> str:
    if raw_source is None:
        return fallback_name

    if isinstance(raw_source, dict):
        for key in ("name", "relation", "model", "ref"):
            value = _clean_str(raw_source.get(key))
            if value:
                raw_source = value
                break
        else:
            raise ConversionError("unsupported model source object", file_path=file_path, field=field)

    source = _clean_str(raw_source)
    if source is None:
        return fallback_name

    _ensure_no_jinja(source, file_path=file_path, field=field)

    ref_match = _REF_CALL_RE.fullmatch(source)
    if ref_match:
        return ref_match.group(1)

    source_match = _SOURCE_CALL_RE.fullmatch(source)
    if source_match:
        return f"{source_match.group(1)}.{source_match.group(2)}"

    return source


def _field_name(raw: dict[str, Any], *, file_path: Path | None, field: str) -> str:
    name = _clean_str(raw.get("name"))
    if name is None:
        raise ConversionError("name is required", file_path=file_path, field=field)
    return name


def _resolve_expr(raw: dict[str, Any], *, fallback: str, file_path: Path | None, field: str) -> ExpressionIR:
    for key in ("expr", "expression", "sql"):
        value = raw.get(key)
        if value is not None:
            return _as_expression_ir(value, file_path=file_path, field=f"{field}.{key}")

    return _as_expression_ir(fallback, file_path=file_path, field=f"{field}.expr")


def _file_path_from_item(item: dict[str, Any]) -> Path | None:
    raw = item.get("__rawctx_source_file")
    if isinstance(raw, str) and raw:
        return Path(raw)
    return None


def _build_dataset_fields(semantic_model: dict[str, Any], *, file_path: Path | None) -> tuple[list[FieldIR], list[str], list[list[str]], dict[str, str]]:
    fields: list[FieldIR] = []
    names: set[str] = set()
    primary_key_columns: list[str] = []
    unique_keys: list[list[str]] = []
    measure_expr_by_name: dict[str, str] = {}

    entities = semantic_model.get("entities") if isinstance(semantic_model.get("entities"), list) else []
    for index, entity in enumerate(entities):
        if not isinstance(entity, dict):
            continue
        name = _field_name(entity, file_path=file_path, field=f"entities[{index}].name")
        expr = _resolve_expr(entity, fallback=name, file_path=file_path, field=f"entities[{index}]")

        if name in names:
            raise ConversionError(f"duplicate field name '{name}'", file_path=file_path, field=f"entities[{index}].name")
        names.add(name)

        fields.append(
            FieldIR(
                name=name,
                expression=expr,
                description=_clean_str(entity.get("description")),
            )
        )

        entity_type = _clean_str(entity.get("type")) or ""
        normalized_type = entity_type.lower()
        source_column = expr.dialects[0].expression
        if normalized_type == "primary":
            primary_key_columns.append(source_column)
        elif normalized_type == "unique":
            unique_keys.append([source_column])

    dimensions = semantic_model.get("dimensions") if isinstance(semantic_model.get("dimensions"), list) else []
    for index, dimension in enumerate(dimensions):
        if not isinstance(dimension, dict):
            continue
        name = _field_name(dimension, file_path=file_path, field=f"dimensions[{index}].name")
        expr = _resolve_expr(dimension, fallback=name, file_path=file_path, field=f"dimensions[{index}]")

        if name in names:
            raise ConversionError(f"duplicate field name '{name}'", file_path=file_path, field=f"dimensions[{index}].name")
        names.add(name)

        field_type = (_clean_str(dimension.get("type")) or "").lower()
        is_time = field_type in {"time", "date", "timestamp"}

        fields.append(
            FieldIR(
                name=name,
                expression=expr,
                is_time=is_time,
                description=_clean_str(dimension.get("description")),
                label=_clean_str(dimension.get("label")),
            )
        )

    measures = semantic_model.get("measures") if isinstance(semantic_model.get("measures"), list) else []
    for index, measure in enumerate(measures):
        if not isinstance(measure, dict):
            continue
        name = _field_name(measure, file_path=file_path, field=f"measures[{index}].name")
        expr = _resolve_expr(measure, fallback=name, file_path=file_path, field=f"measures[{index}]")

        if name in names:
            raise ConversionError(f"duplicate field name '{name}'", file_path=file_path, field=f"measures[{index}].name")
        names.add(name)

        measure_expr_by_name[name] = expr.dialects[0].expression

        fields.append(
            FieldIR(
                name=name,
                expression=expr,
                description=_clean_str(measure.get("description")),
                label=_clean_str(measure.get("label")),
            )
        )

    return fields, primary_key_columns, unique_keys, measure_expr_by_name


def _find_metric_expression(metric: dict[str, Any], *, file_path: Path | None, field_prefix: str) -> ExpressionIR:
    for key in ("expr", "expression", "sql"):
        if metric.get(key) is not None:
            return _as_expression_ir(metric[key], file_path=file_path, field=f"{field_prefix}.{key}")

    type_params = metric.get("type_params")
    if isinstance(type_params, dict):
        for key in ("expr", "expression", "sql"):
            if type_params.get(key) is not None:
                return _as_expression_ir(type_params[key], file_path=file_path, field=f"{field_prefix}.type_params.{key}")

        measure_name = _clean_str(type_params.get("measure"))
        if measure_name:
            return _as_expression_ir(measure_name, file_path=file_path, field=f"{field_prefix}.type_params.measure")

        numerator = _clean_str(type_params.get("numerator"))
        denominator = _clean_str(type_params.get("denominator"))
        if numerator and denominator:
            expr = f"({numerator}) / NULLIF(({denominator}), 0)"
            return _as_expression_ir(expr, file_path=file_path, field=f"{field_prefix}.type_params")

    raise ConversionError("unable to derive metric expression", file_path=file_path, field=field_prefix)


def _measure_owner_map(semantic_models: list[dict[str, Any]]) -> dict[str, str | None]:
    owners: dict[str, str | None] = {}
    for semantic_model in semantic_models:
        model_name = _clean_str(semantic_model.get("name")) or ""
        measures = semantic_model.get("measures") if isinstance(semantic_model.get("measures"), list) else []
        for measure in measures:
            if not isinstance(measure, dict):
                continue
            measure_name = _clean_str(measure.get("name"))
            if not measure_name:
                continue
            if measure_name in owners and owners[measure_name] != model_name:
                owners[measure_name] = None
            else:
                owners[measure_name] = model_name
    return owners


def _resolve_metric_owner(metric: dict[str, Any], owner_by_measure: dict[str, str | None], *, file_path: Path | None, field: str) -> str:
    semantic_model = _clean_str(metric.get("semantic_model")) or _clean_str(metric.get("model"))
    if semantic_model:
        return semantic_model

    type_params = metric.get("type_params") if isinstance(metric.get("type_params"), dict) else {}
    measure_name = _clean_str(type_params.get("measure"))
    if measure_name:
        owner = owner_by_measure.get(measure_name)
        if owner is None:
            raise ConversionError(
                f"ambiguous measure owner for metric measure '{measure_name}'",
                file_path=file_path,
                field=f"{field}.type_params.measure",
            )
        if owner:
            return owner

    raise ConversionError("unable to resolve metric owner semantic model", file_path=file_path, field=field)


def _build_relationships(semantic_models: list[dict[str, Any]]) -> dict[str, list[RelationshipIR]]:
    target_entities: dict[str, list[_EntityRef]] = {}

    for semantic_model in semantic_models:
        model_name = _clean_str(semantic_model.get("name")) or ""
        entities = semantic_model.get("entities") if isinstance(semantic_model.get("entities"), list) else []
        for entity in entities:
            if not isinstance(entity, dict):
                continue
            entity_name = _clean_str(entity.get("name"))
            entity_type = (_clean_str(entity.get("type")) or "").lower()
            if not entity_name or entity_type not in {"primary", "unique", "natural"}:
                continue
            expr = _clean_str(entity.get("expr")) or entity_name
            target_entities.setdefault(entity_name, []).append(_EntityRef(model_name=model_name, column_name=expr, entity_type=entity_type))

    relationship_map: dict[str, list[RelationshipIR]] = {}
    for semantic_model in semantic_models:
        model_name = _clean_str(semantic_model.get("name")) or ""
        file_path = _file_path_from_item(semantic_model)
        entities = semantic_model.get("entities") if isinstance(semantic_model.get("entities"), list) else []

        relationships: list[RelationshipIR] = []
        names_seen: set[str] = set()

        for index, entity in enumerate(entities):
            if not isinstance(entity, dict):
                continue

            entity_type = (_clean_str(entity.get("type")) or "").lower()
            if entity_type not in {"foreign"}:
                continue

            entity_name = _clean_str(entity.get("name"))
            if not entity_name:
                raise ConversionError("entity name is required", file_path=file_path, field=f"entities[{index}].name")

            from_column = _clean_str(entity.get("expr")) or entity_name
            _ensure_no_jinja(from_column, file_path=file_path, field=f"entities[{index}].expr")

            candidates = [item for item in target_entities.get(entity_name, []) if item.model_name != model_name]
            if not candidates:
                raise ConversionError(
                    f"cannot resolve relationship target for entity '{entity_name}'",
                    file_path=file_path,
                    field=f"entities[{index}]",
                )
            if len(candidates) > 1:
                raise ConversionError(
                    f"ambiguous relationship target for entity '{entity_name}'",
                    file_path=file_path,
                    field=f"entities[{index}]",
                )

            target = candidates[0]
            relationship_name = f"{model_name}__{entity_name}__to__{target.model_name}"
            if relationship_name in names_seen:
                raise ConversionError(
                    f"duplicate relationship name '{relationship_name}'",
                    file_path=file_path,
                    field=f"entities[{index}]",
                )
            names_seen.add(relationship_name)

            relationships.append(
                RelationshipIR(
                    name=relationship_name,
                    from_dataset=model_name,
                    to_dataset=target.model_name,
                    from_columns=[from_column],
                    to_columns=[target.column_name],
                )
            )

        relationship_map[model_name] = relationships

    return relationship_map


def metricflow_to_project_ir(path: Path) -> ProjectIR:
    parsed = load_metricflow_project(path)
    state = _BuildState(semantic_models=parsed.semantic_models, metrics=parsed.metrics)

    relationships_by_model = _build_relationships(state.semantic_models)
    owner_by_measure = _measure_owner_map(state.semantic_models)

    metrics_by_model: dict[str, list[MetricIR]] = {}

    # Top-level MetricFlow metrics
    for index, metric in enumerate(state.metrics):
        file_path = _file_path_from_item(metric)
        name = _field_name(metric, file_path=file_path, field=f"metrics[{index}].name")
        owner = _resolve_metric_owner(metric, owner_by_measure, file_path=file_path, field=f"metrics[{index}]")
        expression = _find_metric_expression(metric, file_path=file_path, field_prefix=f"metrics[{index}]")

        metric_ir = MetricIR(
            name=name,
            expression=expression,
            description=_clean_str(metric.get("description")),
        )
        metrics_by_model.setdefault(owner, []).append(metric_ir)

    semantic_models_ir: list[SemanticModelIR] = []

    for index, semantic_model in enumerate(state.semantic_models):
        file_path = _file_path_from_item(semantic_model)
        name = _field_name(semantic_model, file_path=file_path, field=f"semantic_models[{index}].name")

        fields, primary_key, unique_keys, measure_expr_by_name = _build_dataset_fields(semantic_model, file_path=file_path)
        source = _normalize_source(
            semantic_model.get("model"),
            file_path=file_path,
            field=f"semantic_models[{index}].model",
            fallback_name=name,
        )

        dataset = DatasetIR(
            name=name,
            source=source,
            description=_clean_str(semantic_model.get("description")),
            fields=fields,
            primary_key=primary_key or None,
            unique_keys=unique_keys or None,
        )

        model_metrics = metrics_by_model.get(name, []).copy()
        metric_names = {metric.name for metric in model_metrics}

        # Promote measures into OSI metrics for compatibility.
        for measure_name, measure_expr in measure_expr_by_name.items():
            if measure_name in metric_names:
                continue
            model_metrics.append(
                MetricIR(
                    name=measure_name,
                    expression=_as_expression_ir(
                        measure_expr,
                        file_path=file_path,
                        field=f"semantic_models[{index}].measures[{measure_name}]",
                    ),
                )
            )

        semantic_models_ir.append(
            SemanticModelIR(
                name=name,
                description=_clean_str(semantic_model.get("description")),
                datasets=[dataset],
                relationships=relationships_by_model.get(name, []),
                metrics=sorted(model_metrics, key=lambda item: item.name),
            )
        )

    return ProjectIR(
        project_name=parsed.project_name,
        project_version=parsed.project_version,
        semantic_models=sorted(semantic_models_ir, key=lambda item: item.name),
        source_root=parsed.root,
        dialects=["ANSI_SQL"],
        vendors=["COMMON"],
    )


def _to_osi_expression(expression: ExpressionIR) -> dict[str, Any]:
    return {
        "dialects": [
            {
                "dialect": item.dialect,
                "expression": item.expression,
            }
            for item in expression.dialects
        ]
    }


def _to_osi_field(field: FieldIR) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "name": field.name,
        "expression": _to_osi_expression(field.expression),
    }
    if field.is_time:
        payload["dimension"] = {"is_time": True}
    if field.label:
        payload["label"] = field.label
    if field.description:
        payload["description"] = field.description
    if field.ai_context is not None:
        payload["ai_context"] = field.ai_context
    return payload


def _to_osi_dataset(dataset: DatasetIR) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "name": dataset.name,
        "source": dataset.source,
    }
    if dataset.primary_key:
        payload["primary_key"] = dataset.primary_key
    if dataset.unique_keys:
        payload["unique_keys"] = dataset.unique_keys
    if dataset.description:
        payload["description"] = dataset.description
    if dataset.ai_context is not None:
        payload["ai_context"] = dataset.ai_context
    if dataset.fields:
        payload["fields"] = [_to_osi_field(item) for item in dataset.fields]
    return payload


def _to_osi_metric(metric: MetricIR) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "name": metric.name,
        "expression": _to_osi_expression(metric.expression),
    }
    if metric.description:
        payload["description"] = metric.description
    if metric.ai_context is not None:
        payload["ai_context"] = metric.ai_context
    return payload


def _to_osi_relationship(relationship: RelationshipIR) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "name": relationship.name,
        "from": relationship.from_dataset,
        "to": relationship.to_dataset,
        "from_columns": relationship.from_columns,
        "to_columns": relationship.to_columns,
    }
    if relationship.ai_context is not None:
        payload["ai_context"] = relationship.ai_context
    return payload


def _to_osi_semantic_model(model: SemanticModelIR) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "name": model.name,
        "datasets": [_to_osi_dataset(item) for item in model.datasets],
    }
    if model.description:
        payload["description"] = model.description
    if model.ai_context is not None:
        payload["ai_context"] = model.ai_context
    if model.relationships:
        payload["relationships"] = [_to_osi_relationship(item) for item in model.relationships]
    if model.metrics:
        payload["metrics"] = [_to_osi_metric(item) for item in model.metrics]
    return payload


def _safe_file_name(name: str) -> str:
    normalized = name.lower().strip().replace(" ", "-")
    normalized = _SAFE_NAME_RE.sub("-", normalized).strip("-")
    return normalized or "semantic-model"


def project_to_osi_documents(project: ProjectIR) -> dict[str, dict[str, Any]]:
    documents: dict[str, dict[str, Any]] = {}
    for model in project.semantic_models:
        file_name = f"{_safe_file_name(model.name)}.osi.yaml"
        document: dict[str, Any] = {
            "version": "1.0",
            "semantic_model": [_to_osi_semantic_model(model)],
        }
        if project.dialects:
            document["dialects"] = project.dialects
        if project.vendors:
            document["vendors"] = project.vendors
        documents[file_name] = document
    return documents


def build_converted_package(
    project: ProjectIR,
    *,
    package_name: str,
    version: str,
    source_format: str,
) -> ConvertedPackage:
    return ConvertedPackage(
        package_name=package_name,
        version=version,
        source_format=source_format,
        model_documents=project_to_osi_documents(project),
    )
