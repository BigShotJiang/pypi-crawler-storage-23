from .copyrights.harry_potter import *

__all__ = ["score"]
