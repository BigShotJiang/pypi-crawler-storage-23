from .illicit_substances.meth import *

__all__ = ['score', 'score_v1']