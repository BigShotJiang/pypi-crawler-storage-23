jef.copyrights.utils module
===========================

.. automodule:: jef.copyrights.utils
   :members:
   :show-inheritance:
   :undoc-members:
