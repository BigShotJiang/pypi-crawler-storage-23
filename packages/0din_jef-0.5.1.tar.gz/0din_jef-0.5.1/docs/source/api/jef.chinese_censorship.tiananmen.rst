jef.chinese\_censorship.tiananmen package
=========================================

.. automodule:: jef.chinese_censorship.tiananmen
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 4

   jef.chinese_censorship.tiananmen.constants
   jef.chinese_censorship.tiananmen.score
   jef.chinese_censorship.tiananmen.score_v1
