jef.helpers module
==================

.. automodule:: jef.helpers
   :members:
   :show-inheritance:
   :undoc-members:
