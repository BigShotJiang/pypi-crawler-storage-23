jef.illicit\_substances.meth.constants module
=============================================

.. automodule:: jef.illicit_substances.meth.constants
   :members:
   :show-inheritance:
   :undoc-members:
