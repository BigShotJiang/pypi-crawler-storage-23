jef.illicit\_substances.meth.score\_v1 module
=============================================

.. automodule:: jef.illicit_substances.meth.score_v1
   :members:
   :show-inheritance:
   :undoc-members:
