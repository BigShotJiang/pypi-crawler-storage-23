jef.meth module
===============

.. automodule:: jef.meth
   :members:
   :show-inheritance:
   :undoc-members:
