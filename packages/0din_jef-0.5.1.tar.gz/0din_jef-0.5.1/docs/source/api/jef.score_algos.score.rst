jef.score\_algos.score module
=============================

.. automodule:: jef.score_algos.score
   :members:
   :show-inheritance:
   :undoc-members:
