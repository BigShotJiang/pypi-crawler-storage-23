#Rotate Video No compression (FAST)
#ffmpeg.exe -i %s  -c copy -metadata:s:v:0 rotate=90  %s"


