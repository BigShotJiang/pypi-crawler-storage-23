from .model import load_silero_vad

import wave
import numpy as np

vad_model = load_silero_vad()
print("silero_vad jit model Loaded")

from .utils_vad import (get_speech_timestamps,
                                  save_audio,
                                  read_audio,
                                  VADIterator,
                                  collect_chunks,
                                  drop_chunks)


def svad(filename , sampling_rate=16000 , min_speech_duration_ms=250 , max_speech_duration_s=float('inf'),min_silence_duration_ms=100):
    wav = read_audio(filename)
    speech_timestamps = get_speech_timestamps(
        wav,
        vad_model,
        return_seconds=True,  # Return speech timestamps in seconds (default is samples)
        sampling_rate=sampling_rate,
        min_speech_duration_ms=min_speech_duration_ms,
        max_speech_duration_s=max_speech_duration_s,
        min_silence_duration_ms=min_silence_duration_ms,     
    )
    return(speech_timestamps , wav)
    
def svadw(wav , sampling_rate=16000 , min_speech_duration_ms=250 , max_speech_duration_s=float('inf'),min_silence_duration_ms=100):
    speech_timestamps = get_speech_timestamps(
        wav,
        vad_model,
        return_seconds=True,  # Return speech timestamps in seconds (default is samples)
        sampling_rate=sampling_rate,
        min_speech_duration_ms=min_speech_duration_ms,
        max_speech_duration_s=max_speech_duration_s,
        min_silence_duration_ms=min_silence_duration_ms,     
    )
    return(speech_timestamps , filter_wav_by_intervals(wav,speech_timestamps,sampling_rate))    
    
    
import numpy as np

def filter_wav_by_intervals(wav_data, intervals, framerate=16000, sampwidth=2, nchannels=1):

    # Convert to numpy array if bytes
    if isinstance(wav_data, bytes):
        dtype = np.int16 if sampwidth == 2 else np.int8
        audio_data = np.frombuffer(wav_data, dtype=dtype)
    else:
        audio_data = wav_data
    
    # Reshape for multi-channel
    if nchannels > 1:
        audio_data = audio_data.reshape(-1, nchannels)
    
    # Extract segments
    filtered_segments = []
    for interval in intervals:
        start_frame = int(interval['start'] * framerate)
        end_frame = int(interval['end'] * framerate)
        segment = audio_data[start_frame:end_frame]
        filtered_segments.append(segment)
    
    # Concatenate all segments
    if len(filtered_segments) > 0:
        filtered_audio = np.concatenate(filtered_segments)
    else:
        filtered_audio = np.array([], dtype=audio_data.dtype)
    
    return filtered_audio

