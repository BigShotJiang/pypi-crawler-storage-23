.. README.rst

**********
BeadWeaver
**********

.. image:: _build/html/_images/BWlogo.png
   :width: 600px


