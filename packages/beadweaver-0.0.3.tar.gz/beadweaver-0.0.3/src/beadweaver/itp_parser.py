#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  2 13:18:17 2025

@author: jje63
"""

def parseITP(filepath):
    sectionset = 0
    # Dictionary Info
    MoleculeName = ""
    ItpDict = {}
    
    #Atom Info
    BeadNum = 0
    BeadType = []
    Bead = []
    Charge = []
    Mass = []
    
    #Bond Info
    BondCon = []
    BondNum = []
    BondFC = []
    
    #Constrint Info
    ConsCon = []
    ConsNum = []
    ConsFC = []
    
    #Angle Info
    AngleCon = []
    AngleNum = []
    AngleFC = []    
    
    #Dihedral Info
    DihedralCon = []
    DihedralNum = []
    DihedralFC = []
    
    with open(filepath, 'r') as file:
        lines = file.readlines()
        
    for line in lines:
        
        if line.startswith(";"):
            continue
        if line.startswith("#"):
            continue
        if not line.strip():
            continue
        
        if line.startswith("["):
            line2 = line.replace("[","").replace("]","").strip('\n').strip()
            if line2 == "moleculetype":
                if sectionset != 1 :
                    ItpDict[MoleculeName] = {
                        "BeadNum": BeadNum,
                        "BeadType": BeadType,
                        "Bead": Bead,
                        "Charge":Charge,
                        "Mass":Mass,
                        "BondCon":BondCon,
                        "BondNum":BondNum,
                        "BondFC":BondFC,
                        "ConsCon":ConsCon,
                        "ConsNum":ConsNum,
                        "ConsFC":ConsFC,
                        "AngleCon":AngleCon,
                        "AngleNum":AngleNum,
                        "AngleFC":AngleFC,
                        "DihedralCon":DihedralCon,
                        "DihedralNum":DihedralNum,
                        "DihedralFC":DihedralFC
                        }
                
                    #Atom Info
                    BeadNum = 0
                    BeadType = []
                    Bead = []
                    Charge = []
                    Mass = []
                
                    #Bond Info
                    BondCon = []
                    BondNum = []
                    BondFC = []
                
                    #Constrint Info
                    ConsCon = []
                    ConsNum = []
                    ConsFC = []
                
                    #Angle Info
                    AngleCon = []
                    AngleNum = []
                    AngleFC = []
                
                    #Dihedral Info
                    DihedralCon = []
                    DihedralNum = []
                    DihedralFC = []
                sectionset = 1
                continue
                
            if line2 == "atoms":
                sectionset = 2
                continue
        
            if line2 == "bonds":
                sectionset = 3
                continue
            
            if line2 == "constraints":
                sectionset = 4
                continue
            
            if line2 == "angles":
                sectionset = 5
                continue
            
            if line2 == "dihedrals":
                sectionset = 6
                continue
            
            if line2 in ["virtual_sitesn","exclusions"] or line2.startswith("virtual_sites"):
                sectionset = 0
                continue
            
        elif sectionset != 0:
            sline = line.split()
            Readers = [moletypereader(sline, sectionset), 
                       atomreader(sline, sectionset), 
                       bondreader(sline, sectionset),
                       constraintreader(sline, sectionset),
                       anglereader(sline, sectionset),
                       dihedralreader(sline, sectionset)]
                
            for i in range(len(Readers)):
                if Readers[i] == None:
                    continue
                elif i == 0:
                    MoleculeName = Readers[i]
                
                elif i == 1:
                    BeadNum += 1
                    BeadType.append(Readers[i][0])
                    Bead.append(Readers[i][1])
                    Charge.append(Readers[i][2])
                    Mass.append(Readers[i][3])
                elif i == 2:
                    BondCon.append(Readers[i][0])
                    BondNum.append(Readers[i][1])
                    BondFC.append(Readers[i][2])    
                elif i == 3:
                    ConsCon.append(Readers[i][0])
                    ConsNum.append(Readers[i][1])
                    ConsFC.append(0)
                elif i == 4:
                    AngleCon.append(Readers[i][0])
                    AngleNum.append(Readers[i][1])
                    AngleFC.append(Readers[i][2])
                elif i == 5:
                    DihedralCon.append(Readers[i][0])
                    DihedralNum.append(Readers[i][1])
                    DihedralFC.append(Readers[i][2])
    
    return ItpDict
                
                    
                        
            
            
            
def moletypereader(sline, num):
    if num == 1:
        return sline[0]
    else:
        return None
def atomreader(sline, num):
    if num == 2:
        if len(sline) == 6:
            return [sline[1], sline[4], 0, 72]
        if len(sline) == 7:
            return [sline[1], sline[4], sline[6], 72]
        if len(sline) == 8:
            return [sline[1], sline[4], sline[6], sline[7]]
    else:
        return None
def bondreader(sline, num):
    if num == 3:
        return [f"{sline[0]}-{sline[1]}", sline[3], sline[4]]
    else:
        return None
def constraintreader(sline, num):
    if num == 4:
        return [f"{sline[0]}-{sline[1]}", sline[3]]
    else:
        return None
def anglereader(sline, num):
    if num == 5:
        return [f"{sline[0]}-{sline[1]}-{sline[2]}", sline[4], sline[5]]
    else:
        return None
def dihedralreader(sline, num):
    if num == 6:
        return [f"{sline[0]}-{sline[1]}-{sline[2]}-{sline[3]}", sline[5], sline[6]]
    else:
        return None


l = parseITP("martini_v3.0.0_small_molecules_v1.itp")
print(l["2NIMX"])