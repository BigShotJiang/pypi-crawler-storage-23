import builtins
from typing import ClassVar, Literal

from cognite_toolkit._cdf_tk.client._resource_base import (
    BaseModelObject,
    ResponseResource,
)

from ._auth import BasicAuthenticationRequest, BasicAuthenticationResponse
from ._base import SourceRequestDefinition, SourceResponseDefinition


class EventHubSource(BaseModelObject):
    type: Literal["eventhub"] = "eventhub"
    host: str
    event_hub_name: str
    consumer_group: str | None = None


class EventHubSourceRequest(EventHubSource, SourceRequestDefinition):
    non_nullable_fields: ClassVar[frozenset[str]] = frozenset({"authentication"})
    authentication: BasicAuthenticationRequest | None = None


class EventHubSourceResponse(
    SourceResponseDefinition,
    EventHubSource,
    ResponseResource[EventHubSourceRequest],
):
    authentication: BasicAuthenticationResponse | None = None

    @classmethod
    def request_cls(cls) -> builtins.type[EventHubSourceRequest]:
        return EventHubSourceRequest
