# Monitoring and Referral — AASLD 2023

## Follow-Up Intervals

| Risk Category | FIB-4 / NIT Result | Recommended Monitoring |
|---|---|---|
| **Low risk** | FIB-4 < 1.3 | Reassess FIB-4 every **1–2 years** in patients with metabolic risk factors |
| **Low risk (no metabolic risk)** | FIB-4 < 1.3 | Reassess every **2–3 years** |
| **Indeterminate** | FIB-4 1.3–2.67 with VCTE < 8 kPa | Reassess FIB-4 and VCTE in **1 year** |
| **High risk / Advanced fibrosis** | FIB-4 > 2.67 or VCTE > 12 kPa | Hepatology referral; reassess every **6–12 months** |
| **Cirrhosis confirmed** | Clinical or biopsy diagnosis | Hepatology management; HCC screening every **6 months** |

## Hepatology Referral Criteria

Direct referral to gastroenterology/hepatology should be considered when:

- **FIB-4 > 2.67** — increased risk of clinically significant fibrosis
- **Aminotransferases persistently elevated (> 6 months) above normal** — to exclude other causes of liver disease
- **VCTE > 12 kPa or ELF ≥ 9.8** — suggesting advanced fibrosis
- **Indeterminate NITs with clinical concern** — e.g., thrombocytopenia, splenomegaly, other signs of portal hypertension
- **Suspected cirrhosis** — on clinical, laboratory, or imaging grounds

## HCC Screening in NAFLD Cirrhosis

- Patients with **NAFLD-related cirrhosis** should undergo hepatocellular carcinoma (HCC) screening with **ultrasound ± alpha-fetoprotein (AFP) every 6 months**.
- HCC can develop in NAFLD without cirrhosis, but systematic screening in non-cirrhotic NAFLD is not currently recommended due to low incidence.
- Consider HCC screening in patients with **advanced fibrosis (F3)** who have additional risk factors (age > 50, diabetes, male sex).

## Cardiovascular Risk Assessment

- **Cardiovascular disease (CVD) is the leading cause of death** in patients with NAFLD — not liver-related mortality.
- All NAFLD patients should undergo formal cardiovascular risk assessment (lipid panel, blood pressure, glucose/HbA1c, smoking status).
- Statin therapy should NOT be withheld in NAFLD patients; statins are safe and indicated when cardiovascular risk criteria are met.
- SGLT2 inhibitors and GLP-1 RAs may provide dual cardiometabolic and hepatic benefit.

## Monitoring Response to Treatment

### Biochemical Monitoring

- **ALT normalization** correlates with histological improvement but is not a perfect surrogate.
- Serial ALT measurements every 3–6 months during pharmacotherapy.

### Noninvasive Fibrosis Monitoring

- Repeat FIB-4 or VCTE at **12-month intervals** to assess response to lifestyle or pharmacological intervention.
- Improvement in VCTE by ≥ 20% or normalization of FIB-4 (< 1.3) suggests meaningful improvement.
- Worsening FIB-4 or VCTE during follow-up should prompt hepatology referral or treatment escalation.

### Liver Biopsy for Monitoring

- Repeat liver biopsy is generally NOT recommended for routine monitoring.
- May be considered if treatment response is uncertain and management would change based on histological findings.

## Special Populations

### Lean NAFLD (BMI < 25 kg/m²)

- Lean NAFLD accounts for approximately 10–20% of NAFLD cases.
- May have distinct metabolic profiles; advanced fibrosis can occur.
- Same fibrosis assessment and monitoring algorithms apply.

### Pediatric NAFLD

- Screening should be considered in obese children and adolescents with metabolic risk factors.
- FIB-4 is not validated in pediatric populations; specialist referral is recommended.

## Limitations

- Optimal intervals for NIT reassessment have not been established in prospective studies.
- HCC risk in non-cirrhotic NAFLD is not well-quantified; screening recommendations may evolve.
- Cardiovascular risk reduction interventions are extrapolated from general cardiovascular guidelines, not NAFLD-specific RCTs.
- The threshold for meaningful change on serial NITs (e.g., VCTE ≥ 20% improvement) is based on expert consensus, not prospective validation.
