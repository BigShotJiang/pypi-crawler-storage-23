# Screening and Diagnosis of NAFLD/MASLD — AASLD 2023

## Definition

Nonalcoholic fatty liver disease (NAFLD) encompasses disease characterized by **≥ 5% hepatocyte macrovesicular steatosis** in individuals consuming:

- **Women:** < 20 g/day of alcohol
- **Men:** < 30 g/day of alcohol

The disease spectrum includes:

| Stage | Description |
|---|---|
| **NAFL (Nonalcoholic Fatty Liver)** | Steatosis with mild inflammation, without hepatocyte ballooning |
| **NASH (Nonalcoholic Steatohepatitis)** | Steatosis with inflammation and hepatocyte ballooning, with or without fibrosis |
| **NASH Cirrhosis** | Fibrous septa forming cirrhotic nodules |

### Nomenclature Update

The nomenclature has been updated to **Metabolic Dysfunction-Associated Steatotic Liver Disease (MASLD)** to better reflect the metabolic basis of the disease. The clinical content and thresholds remain applicable under the new nomenclature.

## Who to Screen

The AASLD recommends screening for advanced fibrosis in populations with high prevalence of clinically significant disease:

| Population | Prevalence of Advanced Fibrosis | Screening Recommended |
|---|---|---|
| **Type 2 diabetes mellitus** | 6–19% | Yes |
| **Medically complicated obesity** | 4–33% | Yes |
| **Moderate alcohol use with NAFLD** | ~17% | Yes |
| **First-degree relatives of patients with NAFLD cirrhosis** | ~18% | Yes |

Patients with prediabetes/T2DM or ≥ 2 metabolic risk factors are at higher risk for disease progression and should have more frequent monitoring (e.g., every 1–2 years).

## Initial Evaluation

### Laboratory Workup

| Test | Purpose |
|---|---|
| **Hepatic panel** (AST, ALT, alkaline phosphatase, bilirubin, albumin) | Liver injury and function assessment |
| **CBC with platelets** | Platelet count for FIB-4 calculation |
| **Fasting glucose and HbA1c** | Diabetes/pre-diabetes detection |
| **Lipid panel** | Dyslipidemia assessment |
| **HCV antibody** | Exclude hepatitis C as cause of steatosis |

### Hepatic Steatosis Confirmation

- **Ultrasound:** Widely available first-line imaging; limited sensitivity for mild steatosis
- **MRI-PDFF (proton density fat fraction):** Most accurate quantitative measure; ≥ 5% confirms steatosis
- **CAP (Controlled Attenuation Parameter via FibroScan):** ≥ 288 dB/m suggests steatosis

## Diagnosis of NASH

### Liver Biopsy Indications

Liver biopsy remains the reference standard for diagnosing NASH. Consider when:

- Diagnostic uncertainty exists regarding the cause of liver disease
- Discordant or indeterminate noninvasive test results
- Persistent ALT/AST elevation (> 6 months) above normal
- Clinical trial eligibility assessment

### Histological Hallmarks of NASH

The diagnosis of NASH requires all three features:

1. **Macrovesicular steatosis** (≥ 5% of hepatocytes)
2. **Lobular inflammation**
3. **Hepatocyte ballooning**

## Limitations

- Ultrasound has limited sensitivity for detecting mild steatosis (< 20% hepatic fat).
- Liver biopsy is subject to sampling variability and inter-observer variability.
- The transition from NAFLD to MASLD nomenclature may cause temporary confusion in literature searches.
