# Lifestyle Intervention and Pharmacotherapy — AASLD 2023

## Weight Loss Targets

Weight loss is the cornerstone of NAFLD/MASLD management and the only intervention with proven benefit across all stages of disease.

| Weight Loss | Expected Benefit |
|---|---|
| **3–5%** | Reduction in hepatic steatosis |
| **5–7%** | Resolution of steatohepatitis (NASH) |
| **7–10%** | Improvement in fibrosis |
| **≥ 10%** | NASH resolution with fibrosis regression in most patients |

### Dietary Recommendations

- Caloric restriction of **500–1000 kcal/day deficit** to achieve gradual weight loss.
- Mediterranean diet pattern is recommended: high in monounsaturated fatty acids, fiber, and antioxidants.
- **Limit fructose-containing beverages** (associated with worsening steatosis and metabolic syndrome).
- Avoid excessive alcohol consumption.

### Exercise

- **≥ 150 minutes per week** of moderate-intensity aerobic exercise (brisk walking, cycling, swimming).
- Both aerobic and resistance exercise reduce hepatic steatosis, even without significant weight loss.

## Pharmacotherapy

### Vitamin E (Alpha-Tocopherol)

- **Vitamin E 800 IU/day** may be considered for **non-diabetic adults with biopsy-proven NASH** (Conditional).
- NOT recommended in patients with diabetes, NAFLD without biopsy, or cirrhosis.
- Concerns: meta-analyses suggest a small increased risk of all-cause mortality at doses > 400 IU/day and an increased risk of prostate cancer in men.

### Pioglitazone

- **Pioglitazone 30–45 mg/day** may be considered for patients with **biopsy-proven NASH**, including patients with T2DM (Conditional).
- Improves steatohepatitis and fibrosis in clinical trials.
- Side effects: weight gain (2–4 kg), fluid retention, increased fracture risk (especially in postmenopausal women), potential bladder cancer risk.
- NOT recommended in patients with heart failure (NYHA Class III–IV).

### GLP-1 Receptor Agonists

- **Semaglutide** (0.4 mg subcutaneously once weekly in clinical trials; 2.4 mg weekly for weight management) has demonstrated NASH resolution in RCTs.
- Semaglutide did not significantly improve fibrosis in the Phase 2 trial, though post-hoc analyses suggest benefit in subgroups.
- GLP-1 RAs are particularly useful when NAFLD/NASH coexists with **T2DM and/or obesity**.
- Additional cardiometabolic benefits: improved glycemic control, weight loss, cardiovascular risk reduction.

### SGLT2 Inhibitors

- Emerging evidence suggests SGLT2 inhibitors (empagliflozin, dapagliflozin) reduce hepatic steatosis and ALT levels.
- Particularly useful in patients with coexistent T2DM, heart failure, or CKD.
- Not yet included as a formal AASLD recommendation for NASH; evidence is evolving.

## Bariatric/Metabolic Surgery

- May be considered in patients with **NAFLD/NASH and BMI ≥ 35 kg/m² with comorbidities** or **BMI ≥ 40 kg/m²** who have not responded to lifestyle intervention.
- Observational studies demonstrate resolution of NASH in > 80% and improvement in fibrosis in 30–50% of patients after bariatric surgery.
- **Contraindicated** in patients with decompensated cirrhosis.

## Medications to Avoid

| Medication | Concern in NAFLD |
|---|---|
| **Amiodarone** | Promotes steatohepatitis; use alternatives when possible |
| **Tamoxifen** | Can worsen steatosis and steatohepatitis |
| **Methotrexate** | Hepatotoxic; monitor liver function closely |
| **Corticosteroids** | Exacerbates metabolic comorbidities and steatosis |

## Limitations

- No pharmacotherapy is FDA-approved specifically for NASH/NAFLD (as of this guidance).
- Vitamin E and pioglitazone data are primarily from biopsy-proven NASH populations; generalizability to broader NAFLD is uncertain.
- Long-term safety data for semaglutide in NASH are pending from Phase 3 trials.
- Optimal duration of pharmacotherapy is unknown; treatment discontinuation may lead to disease recurrence.
