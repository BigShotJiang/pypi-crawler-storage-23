# Pharmacotherapy for Heart Failure — AHA/ACC/HFSA 2022

## Guideline-Directed Medical Therapy (GDMT) for HFrEF (LVEF ≤ 40%)

Four medication classes form the foundation of GDMT for HFrEF. All four should be initiated and uptitrated to target doses as tolerated. They may be started simultaneously at low doses or sequentially guided by clinical factors, without needing to achieve target dosing of one before starting the next.

### Pillar 1: Renin–Angiotensin System Inhibition

#### ARNi — Sacubitril/Valsartan (Class I, LOE A)

Recommended in preference to ACEi or ARB to reduce morbidity and mortality in patients with chronic symptomatic HFrEF.

| Parameter | Detail |
|---|---|
| Starting dose | 24/26 mg (sacubitril/valsartan) twice daily |
| Dose for patients not on ACEi/ARB or on low-dose | 24/26 mg twice daily |
| Target dose | 97/103 mg twice daily |
| Titration | Double dose every 2–4 weeks as tolerated |

- **Switching from ACEi:** A 36-hour washout period is required prior to initiating ARNi to reduce angioedema risk. No washout needed when switching from ARB.
- **Contraindications:** History of angioedema with ACEi or ARNi, pregnancy, concomitant use with ACEi, concomitant use with aliskiren in patients with diabetes.
- **Monitoring:** Blood pressure, renal function, potassium at 1–2 weeks after initiation and after each titration.

#### ACEi — When ARNi Is Not Feasible (Class I, LOE A)

| Drug | Starting Dose | Target Dose |
|---|---|---|
| Enalapril | 2.5 mg twice daily | 10–20 mg twice daily |
| Lisinopril | 2.5–5 mg daily | 20–40 mg daily |
| Ramipril | 1.25–2.5 mg daily | 10 mg daily |
| Captopril | 6.25 mg three times daily | 50 mg three times daily |

#### ARB — For ACEi-Intolerant Patients When ARNi Not Feasible (Class I, LOE A)

| Drug | Starting Dose | Target Dose |
|---|---|---|
| Valsartan | 20–40 mg twice daily | 160 mg twice daily |
| Losartan | 25–50 mg daily | 50–150 mg daily |
| Candesartan | 4–8 mg daily | 32 mg daily |

### Pillar 2: Beta-Blockers (Class I, LOE A)

One of the three evidence-based beta-blockers with proven mortality benefit should be used. Initiate at the lowest dose and uptitrate to the target dose or maximally tolerated dose every 2 weeks as tolerated. Patients should be euvolemic and clinically stable before initiation.

| Drug | Starting Dose | Target Dose |
|---|---|---|
| Carvedilol | 3.125 mg twice daily | 25 mg twice daily (50 mg twice daily if > 85 kg) |
| Metoprolol succinate (extended-release) | 12.5–25 mg daily | 200 mg daily |
| Bisoprolol | 1.25 mg daily | 10 mg daily |

- **Do NOT substitute** other beta-blockers (atenolol, propranolol, metoprolol tartrate) — only carvedilol, metoprolol succinate, and bisoprolol have demonstrated mortality reduction in HFrEF trials.
- **Hold or reduce dose** if heart rate < 50 bpm, symptomatic hypotension, or decompensated HF. Resume uptitration once stable.
- **Do NOT withdraw abruptly** — taper if discontinuation is required.

### Pillar 3: Mineralocorticoid Receptor Antagonists (Class I, LOE A)

Recommended to reduce morbidity and mortality in patients with HFrEF and NYHA class II–IV symptoms, unless contraindicated.

| Drug | Starting Dose | Target Dose |
|---|---|---|
| Spironolactone | 12.5–25 mg daily | 25–50 mg daily |
| Eplerenone | 25 mg daily | 50 mg daily |

- **Prerequisites:** eGFR > 30 mL/min/1.73 m² AND serum potassium < 5.0 mEq/L.
- **Monitoring:** Check serum potassium and renal function at 1 week, 4 weeks, and every 6 months thereafter.
- **Hold if:** Potassium > 5.5 mEq/L or creatinine rises > 30% from baseline.
- Eplerenone preferred over spironolactone if gynecomastia develops.
- **Contraindications:** Concomitant potassium-sparing diuretics, severe renal impairment (eGFR < 30), potassium > 5.0 mEq/L.

### Pillar 4: SGLT2 Inhibitors (Class I, LOE A)

Recommended to reduce hospitalization for HF and cardiovascular mortality in patients with symptomatic chronic HFrEF, regardless of the presence of type 2 diabetes.

| Drug | Dose |
|---|---|
| Dapagliflozin | 10 mg once daily |
| Empagliflozin | 10 mg once daily |

- No dose titration required.
- Can be initiated regardless of diabetes status.
- Monitor for genital mycotic infections, volume depletion, and diabetic ketoacidosis (in patients with diabetes).
- **Caution if eGFR < 20 mL/min/1.73 m²** (limited data; do not initiate below this threshold but can continue if eGFR declines after initiation).

---

## Additional HFrEF Therapies

### Hydralazine + Isosorbide Dinitrate (Class I, LOE A — self-identified African Americans)

Recommended to reduce morbidity and mortality for self-identified African American patients with NYHA class III–IV HFrEF receiving optimal therapy with ACEi/ARB/ARNi, beta-blocker, and MRA.

| Component | Starting Dose | Target Dose |
|---|---|---|
| Hydralazine | 37.5 mg three times daily | 75 mg three times daily (225 mg/day total) |
| Isosorbide dinitrate | 20 mg three times daily | 40 mg three times daily (120 mg/day total) |

- **Alternative indication (Class IIb, LOE C-LD):** May be considered in patients of other races/ethnicities when ACEi, ARB, and ARNi are contraindicated or not tolerated.

### Ivabradine (Class IIa, LOE B-R)

For patients with symptomatic (NYHA II–III) stable chronic HFrEF (LVEF ≤ 35%) who are in sinus rhythm with a resting heart rate ≥ 70 bpm on maximally tolerated dose of beta-blocker.

| Parameter | Detail |
|---|---|
| Starting dose | 5 mg twice daily (2.5 mg twice daily if heart rate 50–60 bpm or history of conduction defects) |
| Target dose | 7.5 mg twice daily |
| Dose adjustment | Adjust to maintain resting heart rate 50–60 bpm |

- **Prerequisites:** Must be on maximally tolerated beta-blocker dose first. Sinus rhythm required (no benefit in atrial fibrillation).
- **Contraindications:** Resting heart rate < 60 bpm prior to initiation, severe hepatic impairment, pacemaker-dependent.

### Vericiguat (Class IIb, LOE B-R)

May be considered in patients with worsening HFrEF (NYHA II–IV, LVEF < 45%) and a recent HF hospitalization or need for intravenous diuretics, already on maximally tolerated GDMT.

| Parameter | Detail |
|---|---|
| Starting dose | 2.5 mg once daily |
| Titration | Double dose every 2 weeks |
| Target dose | 10 mg once daily |

---

## Diuretic Therapy (Class I, LOE B)

Loop diuretics are recommended for relief of congestion in patients with HF and signs/symptoms of fluid overload.

- **Furosemide:** 20–40 mg IV or oral, titrate to achieve euvolemia.
- **Bumetanide:** 0.5–1 mg IV or oral (1 mg bumetanide ≈ 40 mg furosemide).
- **Torsemide:** 10–20 mg oral (may have improved oral bioavailability compared to furosemide).
- Diuretics do NOT improve mortality; use the lowest effective dose to maintain euvolemia.
- Thiazide diuretics (metolazone 2.5–5 mg, chlorothiazide) may be added for diuretic resistance (sequential nephron blockade).

---

## Potassium Binders (Class IIb, LOE B-R)

Patiromer or sodium zirconium cyclosilicate may be considered to enable initiation or uptitration of RAASi/MRA when hyperkalemia limits therapy.

---

## HFmrEF Pharmacotherapy (LVEF 41–49%)

- **SGLT2i** (dapagliflozin 10 mg or empagliflozin 10 mg): Recommended to reduce HF hospitalization and cardiovascular death (Class IIa, LOE B-R).
- **Diuretics** for congestion as needed (Class I, LOE B).
- ARNi, ACEi, ARB, MRA, and beta-blockers may be considered (Class IIb, LOE B-NR), with management guided by evidence extrapolated from HFrEF and HFpEF trials.

## HFpEF Pharmacotherapy (LVEF ≥ 50%)

- **SGLT2i** (dapagliflozin 10 mg or empagliflozin 10 mg): Recommended to reduce HF hospitalization and cardiovascular death (Class IIa, LOE B-R).
- **Diuretics** for congestion as needed (Class I, LOE B).
- Management of underlying causes and comorbidities: hypertension, obesity, coronary artery disease, atrial fibrillation, diabetes (Class I, LOE C-LD).
- MRA may be considered to reduce hospitalizations, particularly in patients with LVEF on the lower end of this range (Class IIb, LOE B-R).

## GDMT Initiation Algorithm for HFrEF

```
Patient with symptomatic HFrEF (LVEF ≤ 40%)
  → Initiate all four pillars simultaneously at starting doses OR sequentially:
      1. ARNi (or ACEi/ARB) — start sacubitril/valsartan 24/26 mg BID
      2. Beta-blocker — start carvedilol 3.125 mg BID (or metoprolol succinate 12.5–25 mg daily)
      3. MRA — start spironolactone 12.5–25 mg daily (eGFR > 30, K+ < 5.0)
      4. SGLT2i — start dapagliflozin 10 mg daily or empagliflozin 10 mg daily
  → Titrate each to target doses every 2–4 weeks as tolerated
  → At target doses, reassess:
      → Heart rate ≥ 70 bpm in sinus rhythm on max beta-blocker?
          → YES → Add ivabradine 5 mg BID → titrate to 7.5 mg BID
      → Self-identified African American with NYHA III–IV?
          → YES → Add hydralazine/isosorbide dinitrate
      → Recent HF hospitalization or worsening symptoms on max GDMT?
          → YES → Consider vericiguat 2.5 mg daily → titrate to 10 mg daily
      → Persistent congestion?
          → YES → Optimize diuretics; add thiazide if diuretic resistance
      → LVEF ≤ 35% and eligible for device therapy?
          → YES → See device therapy section
```

## Limitations

- Simultaneous initiation of all four pillars may not be feasible in patients with hypotension, renal dysfunction, or hyperkalemia; clinical judgment guides sequencing.
- Target doses are based on clinical trial protocols; some patients may not tolerate full target doses.
- HFmrEF and HFpEF have less robust evidence compared to HFrEF; many recommendations are extrapolated.
- Vericiguat evidence is based on a single trial (VICTORIA) with modest benefit; its role in routine practice remains to be fully defined.
