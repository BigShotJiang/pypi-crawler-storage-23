# Advanced VTE Management — ASH 2020

## Thrombolytic Therapy

### Proximal DVT (Recommendation 5, Conditional, Low Certainty ⨁⨁○○)

The panel suggests **anticoagulation alone over thrombolytic therapy** for most patients with proximal DVT.

**Exceptions where thrombolysis may be considered:**
- **Limb-threatening DVT** (phlegmasia cerulea dolens) — thrombolysis may be life- and limb-saving
- Select younger patients at low bleeding risk with extensive iliofemoral DVT, particularly with severe symptoms

### Hemodynamically Compromised PE (Recommendation 6, Strong, Low Certainty ⨁⨁○○)

The panel **recommends thrombolytic therapy followed by anticoagulation** over anticoagulation alone for patients with PE and hemodynamic compromise (**strong recommendation**).

- Despite low certainty of evidence, the very high mortality of massive PE (~50% at 90 days) justifies a strong recommendation.
- **Definition of hemodynamic compromise:** Systolic blood pressure < 90 mmHg for ≥ 15 minutes, or requiring vasopressors, or pulselessness.
- Standard systemic thrombolysis regimens should be used (e.g., alteplase 100 mg IV over 2 hours, or accelerated regimen of 0.6 mg/kg over 15 minutes, maximum 50 mg).

### Submassive PE (Recommendation 7, Conditional, Low Certainty ⨁⨁○○)

The panel suggests **anticoagulation alone over routine thrombolysis** for patients with PE without hemodynamic compromise (submassive PE).

- Thrombolysis may be considered in select patients: younger age, low bleeding risk, clinical deterioration despite anticoagulation.
- Harms of thrombolysis: Major bleeding RR 1.89; intracranial hemorrhage RR 3.17 compared to anticoagulation alone.

### Route of Thrombolysis

| Clinical Scenario | Preferred Route | Recommendation | Certainty |
|---|---|---|---|
| **DVT** (Rec 8) | Catheter-directed thrombolysis (CDT) over systemic | Conditional | Very Low ⨁○○○ |
| **PE** (Rec 9) | Systemic thrombolysis over catheter-directed | Conditional | Very Low ⨁○○○ |

- **CDT for PE** may be considered for patients at intermediate-high bleeding risk, where systemic thrombolysis carries excessive risk.
- Evidence for catheter-directed approaches remains limited; most data come from observational studies.

### Thrombolysis Decision Algorithm

```
Patient with confirmed VTE
  → Is it PE with hemodynamic compromise (SBP < 90 mmHg, vasopressors, pulselessness)?
      → YES → Systemic thrombolysis RECOMMENDED (Rec 6, Strong)
              Administer alteplase 100 mg IV over 2 hours
              Follow with anticoagulation
      → NO → Is it submassive PE (RV dysfunction or elevated troponin, hemodynamically stable)?
          → YES → Anticoagulation alone is preferred (Rec 7)
                   Consider thrombolysis ONLY if: young, low bleed risk, clinical deterioration
          → NO → Is it limb-threatening DVT (phlegmasia cerulea dolens)?
              → YES → Consider catheter-directed thrombolysis (Rec 5, 8)
              → NO → Anticoagulation alone (Rec 5)
```

---

## Inferior Vena Cava (IVC) Filters

### IVC Filter with Cardiopulmonary Disease (Recommendation 10, Conditional, Low Certainty ⨁⨁○○)

For patients with proximal DVT and significant preexisting cardiopulmonary disease, the panel suggests **anticoagulation alone** rather than anticoagulation plus IVC filter insertion.

### IVC Filter with Hemodynamically Compromised PE (Recommendation 11, Conditional, Low Certainty ⨁⨁○○)

For patients with PE and hemodynamic compromise, the panel suggests **anticoagulation alone** rather than anticoagulation plus IVC filter insertion.

### IVC Filter Indications

```
Patient with acute VTE
  → Can the patient receive anticoagulation?
      → YES → Anticoagulation alone (no IVC filter)
              IVC filter is NOT recommended in addition to anticoagulation (Rec 10, 11)
      → NO → Absolute contraindication to anticoagulation (active hemorrhage, recent surgery)?
          → YES → Retrievable IVC filter may be considered
                   Plan retrieval when anticoagulation can be resumed
          → NO (relative contraindication) → Individualize decision
```

---

## Compression Stockings

### Routine Use Not Recommended (Recommendations 27–28, Conditional, Very Low Certainty ⨁○○○)

The panel suggests **against the routine use of compression stockings** for prevention of post-thrombotic syndrome (PTS) after DVT.

- **Recommendation 27:** Against routine compression stockings for patients WITHOUT increased PTS risk.
- **Recommendation 28:** Against routine compression stockings for patients WITH increased PTS risk.
- Compression stockings may still help individual patients with symptomatic edema or pain after DVT, but are not recommended for PTS prevention based on available evidence (SOX trial showed no benefit).

---

## Special Considerations

### Antiphospholipid Syndrome

- DOACs are **NOT recommended** for patients with antiphospholipid antibody syndrome.
- Use warfarin with target INR 2.0–3.0 as the preferred long-term anticoagulant.
- LMWH or UFH for initial parenteral anticoagulation.

### Severe Renal Impairment (CrCl < 30 mL/min)

- DOACs generally avoided due to limited safety data and variable renal clearance.
- **UFH** preferred for initial treatment (no renal clearance).
- **Warfarin** (INR 2.0–3.0) for long-term anticoagulation.
- If LMWH is used, dose reduction required (enoxaparin 1 mg/kg once daily).

### Extremes of Body Weight

- Limited DOAC trial data in patients < 50 kg or > 120 kg (or BMI > 40 kg/m²).
- Consider anti-Xa level monitoring if DOAC used in extreme body weight.
- LMWH with anti-Xa monitoring is an alternative for initial therapy.

### Pregnancy

- Cancer-associated VTE and pregnancy-associated VTE are addressed in separate ASH guideline modules, not in this document.
- Generally, LMWH is the preferred anticoagulant in pregnancy; DOACs and warfarin are contraindicated.

> **OpenMedicine Calculators:** `calculate_wells_pe`, `calculate_wells_dvt`, `calculate_caprini`, `calculate_padua` — available via MCP for VTE risk assessment.

## Limitations

- Thrombolysis evidence for PE is largely from older trials; newer catheter-based techniques are evolving rapidly but lack robust randomized data.
- IVC filter evidence is limited; the only major RCT (PREPIC-2) showed no benefit of retrievable filters added to anticoagulation.
- Compression stocking recommendations are based primarily on the SOX trial, which contradicted earlier positive studies; individual benefit may exist but cannot be predicted.
- The guideline does not address cancer-associated VTE (separate ASH 2021 guideline), pregnancy-associated VTE, or catheter-related VTE.
