# Routine Medical Therapy in STEMI — ACCF/AHA 2013

## Initial Emergency Management

### Supplemental Oxygen

- Supplemental oxygen should be administered to patients with arterial oxygen saturation (SaO2) **< 94%** (Class I, LOE: C)
- It is reasonable to administer supplemental oxygen to all patients with uncomplicated STEMI during the **first 6 hours** (Class IIa, LOE: C)
- Routine supplemental oxygen in patients **without** hypoxemia is not recommended beyond the first 6 hours

### Nitroglycerin

- Patients with ongoing ischemic discomfort should receive **sublingual nitroglycerin 0.4 mg** every 5 minutes for a total of **3 doses**, after which assessment should be made about the need for IV nitroglycerin (Class I, LOE: C)
- **IV nitroglycerin** is indicated for the management of persistent ischemia, heart failure, or hypertension (Class I, LOE: B)
  - Start at 5-10 mcg/min; titrate up by 5-10 mcg/min every 5-10 minutes to relieve symptoms
- **Contraindications to nitroglycerin:**
  - SBP < 90 mmHg or >= 30 mmHg below baseline
  - Severe bradycardia (< 50 bpm) or tachycardia (> 100 bpm) in absence of HF
  - Right ventricular infarction
  - Phosphodiesterase-5 inhibitor use within 24 hours (48 hours for tadalafil)

### Analgesic Therapy

- **Morphine sulfate** (2 to 4 mg IV, with increments of 2 to 8 mg IV repeated at 5- to 15-minute intervals) is reasonable for management of pain unresponsive to nitroglycerin (Class IIa, LOE: C)
- Monitor for hypotension and respiratory depression
- NSAIDs (except aspirin) should **not** be administered during hospitalization for STEMI (Class III: Harm, LOE: B)

---

## Beta-Blockers

### Oral Beta-Blockers (Class I, LOE: B)

Oral beta-blockers should be initiated in the **first 24 hours** in patients with STEMI who do **not** have any of the following:

- Signs of heart failure
- Evidence of a low-output state
- Increased risk for cardiogenic shock (age > 70 years, SBP < 120 mmHg, heart rate > 110 bpm or < 60 bpm, increased time since onset of STEMI symptoms)
- PR interval > 0.24 seconds
- Second- or third-degree heart block
- Active asthma or reactive airway disease

### Oral Beta-Blocker Agents

| Agent | Initial Dose | Target Dose |
|---|---|---|
| **Metoprolol tartrate** | 25-50 mg orally every 6-12 hours | Titrate to 200 mg/day |
| **Metoprolol succinate** | 25-50 mg orally once daily | Titrate to 200 mg/day |
| **Carvedilol** | 6.25 mg orally twice daily | Titrate to 25 mg twice daily |
| **Bisoprolol** | 2.5-5 mg orally once daily | Titrate to 10 mg once daily |

### IV Beta-Blockers

- IV beta-blockers are potentially harmful when risk factors for cardiogenic shock are present (Class III: Harm, LOE: B)
- If no contraindications, IV metoprolol (5 mg IV every 5 minutes for up to 3 doses) may be considered in hypertensive patients or those with ongoing ischemia (Class IIa, LOE: B)
- **Always transition to oral beta-blocker therapy** as soon as the patient is hemodynamically stable

### Long-Term Beta-Blocker Therapy

- Beta-blocker therapy should be continued for **at least 3 years** in all patients with normal LV function after STEMI (Class I, LOE: B)
- Indefinite therapy is recommended in patients with LV systolic dysfunction (LVEF <= 40%) (Class I, LOE: A)

---

## Renin-Angiotensin-Aldosterone System (RAAS) Inhibitors

### ACE Inhibitors (Class I, LOE: A)

An ACE inhibitor should be administered within the **first 24 hours** to all patients with STEMI with **anterior location**, **heart failure**, or **LVEF <= 0.40**, unless contraindicated.

- **ACE inhibitors are reasonable** for all other patients with STEMI and no contraindications (Class IIa, LOE: A)

| Agent | Initial Dose | Target Dose |
|---|---|---|
| **Captopril** | 6.25 mg orally, titrate to 25-50 mg TID | 50 mg TID |
| **Lisinopril** | 2.5-5 mg orally once daily | 10-20 mg once daily |
| **Ramipril** | 1.25-2.5 mg orally twice daily | 5 mg twice daily or 10 mg once daily |
| **Enalapril** | 2.5 mg orally twice daily | 10-20 mg twice daily |

**Contraindications:**
- Hypotension (SBP < 100 mmHg)
- Cardiogenic shock
- Bilateral renal artery stenosis
- Known intolerance or allergy
- Pregnancy

**Initiation protocol:**
- Start at low dose
- Titrate upward as tolerated over 24-48 hours
- Hold if SBP < 100 mmHg or if patient develops symptomatic hypotension
- Monitor serum creatinine and potassium within 1-2 weeks of initiation

### ARBs (Class I, LOE: B)

- An ARB should be given to patients with STEMI who are **intolerant of ACE inhibitors** and who have either heart failure or LVEF <= 0.40
- **Valsartan** (starting dose 20 mg orally twice daily, target 160 mg twice daily) is the best-studied ARB in this setting
- Do **not** combine ACE inhibitor + ARB routinely (Class III: Harm, LOE: B)

### Aldosterone Antagonists (Class I, LOE: B)

An aldosterone antagonist should be given to patients with STEMI who are already receiving an **ACE inhibitor and a beta-blocker** and who have **all** of the following:

1. LVEF <= 0.40
2. Either **symptomatic heart failure** OR **diabetes mellitus**
3. No significant renal dysfunction:
   - Serum creatinine <= 2.5 mg/dL in men, <= 2.0 mg/dL in women
4. No hyperkalemia:
   - Serum potassium < 5.0 mEq/L

| Agent | Dose |
|---|---|
| **Eplerenone** | 25 mg once daily, titrate to 50 mg once daily |
| **Spironolactone** | 12.5-25 mg once daily |

- Monitor potassium closely; recheck within 48-72 hours of initiation and at 1 week
- Discontinue or reduce dose if potassium >= 5.5 mEq/L

---

## Statin Therapy

### High-Intensity Statin (Class I, LOE: B)

High-intensity statin therapy should be initiated or continued in **all patients** with STEMI and **no contraindications** to its use. Therapy should be started as early as possible, regardless of baseline LDL-C level.

| Agent | Dose |
|---|---|
| **Atorvastatin** | 80 mg once daily |
| **Rosuvastatin** | 20-40 mg once daily |

- High-intensity statin therapy is defined as a daily dose that lowers LDL-C by approximately >= 50%
- Continue indefinitely for secondary prevention

---

## Cardiac Rehabilitation and Secondary Prevention

- Exercise-based cardiac rehabilitation/secondary prevention programs are recommended for patients with STEMI (Class I, LOE: B)
- Smoking cessation counseling and pharmacotherapy should be offered to all patients who use tobacco (Class I, LOE: A)
- Blood pressure management to target < 140/90 mmHg (or < 130/80 mmHg if diabetes or CKD) (Class I, LOE: A)

## Therapeutic Hypothermia

- Therapeutic hypothermia (target temperature 32-34 degrees C for 12-24 hours) should be started as soon as possible in **comatose patients** with STEMI and out-of-hospital cardiac arrest caused by VF or pulseless VT, including patients who undergo primary PCI (Class I, LOE: B)
