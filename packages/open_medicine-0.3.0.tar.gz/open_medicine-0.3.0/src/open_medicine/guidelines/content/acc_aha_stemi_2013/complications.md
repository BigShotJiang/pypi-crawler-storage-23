# Complications of STEMI — ACCF/AHA 2013

## Killip Classification

The Killip classification is used for risk stratification of patients presenting with STEMI based on clinical signs of heart failure at presentation.

| Killip Class | Clinical Features | Historical In-Hospital Mortality |
|---|---|---|
| **Class I** | No signs of heart failure | ~6% |
| **Class II** | Rales or crackles in lungs, S3 gallop, elevated jugular venous pressure | ~17% |
| **Class III** | Frank acute pulmonary edema | ~38% |
| **Class IV** | Cardiogenic shock: SBP < 90 mmHg with signs of peripheral vasoconstriction (oliguria, cyanosis, diaphoresis, altered mental status) | ~81% |

Killip class is a component of the TIMI Risk Score for STEMI. Killip Class II-IV contributes 2 points to the TIMI STEMI risk score.

> **OpenMedicine Calculator:** `calculate_timi_stemi` -- available via MCP for automated TIMI STEMI risk scoring, which incorporates Killip classification.

---

## Cardiogenic Shock

### Definition

Cardiogenic shock is defined as sustained hypotension (SBP < 90 mmHg for >= 30 minutes, or need for vasopressors to maintain SBP >= 90 mmHg) plus evidence of end-organ hypoperfusion (cool extremities, oliguria, altered mental status) in the setting of adequate or elevated left ventricular filling pressures.

### Management Algorithm

1. **Immediate coronary angiography and revascularization:**
   - Emergent PCI or CABG should be performed irrespective of time delay from MI onset (Class I, LOE: B)
   - Fibrinolytic therapy should be administered if PCI or CABG cannot be performed (Class I, LOE: B)
2. **Hemodynamic support:**
   - Intra-aortic balloon pump (IABP) counterpulsation can be useful for patients who do not quickly stabilize with pharmacologic therapy (Class IIa, LOE: B)
   - Vasopressors and inotropic agents:
     - **Norepinephrine** preferred for severe hypotension (SBP < 70 mmHg)
     - **Dopamine** may be used for moderate hypotension (SBP 70-100 mmHg)
     - **Dobutamine** may be used when SBP is > 90 mmHg with low cardiac output
3. **Alternative mechanical circulatory support:**
   - Percutaneous or surgically placed LV assist devices may be considered for refractory cardiogenic shock (Class IIb, LOE: C)
4. **Beta-blockers are contraindicated** in patients with cardiogenic shock or at high risk for developing cardiogenic shock (Class III: Harm, LOE: B)
5. **Right ventricular infarction:**
   - If cardiogenic shock is due to RV infarction: aggressive volume loading (goal RA pressure 15 mmHg), avoid nitrates and diuretics, maintain AV synchrony

### Risk Factors for Cardiogenic Shock

The guideline identifies the following risk factors that increase the likelihood of cardiogenic shock after STEMI:
- Age > 70 years
- SBP < 120 mmHg
- Heart rate > 110 bpm or < 60 bpm
- Prolonged time since onset of STEMI symptoms

---

## Mechanical Complications

### Ventricular Septal Defect (VSD)

- Typically occurs **3 to 5 days** after STEMI (range 1-14 days)
- Presents with new holosystolic murmur, acute hemodynamic deterioration
- **Diagnosis:** Echocardiography with color Doppler
- **Treatment:** Emergency surgical repair regardless of hemodynamic status, as delay leads to infarct expansion and VSD enlargement (Class I, LOE: B)
- IABP or percutaneous mechanical support as bridge to surgery
- Mortality without surgery: nearly 100%

### Free Wall Rupture

- Typically occurs **3 to 5 days** after STEMI (range 1-14 days)
- Risk factors: first MI, anterior location, age > 70, female sex, no prior history of angina
- **Presentation:** Acute cardiac tamponade (hypotension, elevated JVP, muffled heart sounds)
- **Treatment:** Immediate surgical repair (Class I, LOE: B)
- Pericardiocentesis as temporizing bridge to surgery

### Papillary Muscle Rupture (Acute Mitral Regurgitation)

- Typically occurs **2 to 7 days** after STEMI
- Posteromedial papillary muscle rupture more common (single blood supply from PDA)
- **Presentation:** Acute severe mitral regurgitation, pulmonary edema, cardiogenic shock
- **Treatment:** Emergency surgical repair (mitral valve replacement or repair) (Class I, LOE: B)
- IABP and vasodilators (nitroprusside if SBP adequate) for temporary hemodynamic stabilization

### General Principles for Mechanical Complications

- CABG should be performed at the time of operative repair of mechanical defects (Class I, LOE: B)
- Do not delay surgery for hemodynamic optimization if the patient is deteriorating

---

## Arrhythmias

### Ventricular Arrhythmias

- **Sustained VT or VF** in the first 48 hours: Immediate defibrillation/cardioversion per ACLS protocol
  - Defibrillation for VF or pulseless VT (Class I, LOE: B)
  - Synchronized cardioversion for hemodynamically significant sustained monomorphic VT
  - IV amiodarone 150 mg over 10 minutes, then 1 mg/min for 6 hours, then 0.5 mg/min for 18 hours for recurrent VT or VF despite defibrillation (Class IIa, LOE: C)
  - IV lidocaine may be used as an alternative (Class IIb, LOE: C)
- **Accelerated idioventricular rhythm** (rate 60-120 bpm): No specific treatment required; this is a reperfusion arrhythmia and is generally benign
- **Prophylactic antiarrhythmic therapy** (e.g., prophylactic lidocaine) is **not recommended** (Class III: No Benefit, LOE: B)
- ICD implantation should **not** be done in the acute phase (within 40 days of MI). Reassess LVEF at 40 days post-MI to determine ICD candidacy.

### Supraventricular Arrhythmias

- **Atrial fibrillation** in STEMI:
  - Electrical cardioversion for hemodynamic compromise (Class I, LOE: C)
  - IV amiodarone for rate control and/or conversion in hemodynamically stable patients (Class IIa, LOE: C)
  - IV beta-blocker for rate control if no contraindications (Class I, LOE: C)

### Bradyarrhythmias and Conduction Defects

- **Symptomatic sinus bradycardia:** IV atropine 0.5 mg every 3-5 minutes (max 3 mg) (Class I, LOE: C)
- **Second-degree (Mobitz type II) or third-degree AV block:**
  - Temporary transvenous pacing (Class I, LOE: C)
  - Indications for temporary pacing in STEMI:
    - Asystole
    - Symptomatic bradycardia unresponsive to atropine
    - Bilateral bundle branch block (RBBB alternating with LBBB, or RBBB with alternating LAFB/LPFB)
    - New or indeterminate LBBB with first-degree AV block
    - Mobitz type II second-degree AV block
    - Third-degree (complete) AV block
- **New LBBB or RBBB in the setting of STEMI:** Monitor closely; may indicate extensive infarction with risk of progression to complete heart block

---

## Pericarditis

- **Early pericarditis** (within 1-3 days post-MI): Inflammatory response to myocardial necrosis
  - Treat with aspirin 650 mg orally every 4-6 hours (Class I, LOE: B)
  - Colchicine may be used as adjunctive therapy
  - **Avoid NSAIDs and corticosteroids** in the early post-MI period (impair healing, increase risk of mechanical complications) (Class III: Harm, LOE: B)
- If a pericardial effusion develops after STEMI, anticoagulant therapy should be discontinued unless absolutely required (Class IIa, LOE: C)

---

## Limitations

- Mortality estimates for Killip classes are derived from older studies; contemporary mortality rates with timely reperfusion are significantly lower.
- The evidence base for specific vasopressor/inotrope selection in cardiogenic shock is limited; choices are largely based on expert consensus.
- The optimal timing for mechanical complication repair continues to evolve; some centers now employ percutaneous closure for post-MI VSD in selected patients.
- ICD decision-making at 40 days post-MI must account for potential LVEF recovery with optimal medical therapy and revascularization.
