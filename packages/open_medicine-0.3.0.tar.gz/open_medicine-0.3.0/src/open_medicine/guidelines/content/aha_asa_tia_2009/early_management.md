# Early Management of Transient Ischemic Attack — AHA/ASA 2009

## Antiplatelet Therapy

### Aspirin

- **Aspirin 160–325 mg** should be administered as soon as possible after TIA onset, followed by **75–100 mg daily** for long-term secondary prevention (Class I, LOE A).
- Aspirin reduces the risk of recurrent stroke by approximately 15–20%.

### Dual Antiplatelet Therapy (DAPT)

- **Aspirin + clopidogrel** within 24 hours of high-risk TIA (ABCD2 ≥ 4) for a short duration (21–90 days) reduces recurrent stroke risk compared to aspirin alone.
- After the initial DAPT period, **monotherapy with aspirin or clopidogrel** should be continued indefinitely.
- The CHANCE trial (2013) and POINT trial (2018) provide the primary evidence, though published after this 2009 statement.

### Clopidogrel Monotherapy

- **Clopidogrel 75 mg daily** is a reasonable alternative for patients who cannot tolerate aspirin (Class IIa, LOE B).

### Aspirin + Extended-Release Dipyridamole

- **Aspirin 25 mg + dipyridamole ER 200 mg twice daily** is an alternative to aspirin alone (Class I, LOE B).
- Common side effect: headache (up to 40% of patients), which often improves with continued use.

## Anticoagulation for Cardioembolism

- If atrial fibrillation or another cardioembolic source is identified, **anticoagulation** is the preferred therapy rather than antiplatelet agents.
- DOACs (apixaban, rivaroxaban, dabigatran, edoxaban) are now preferred over warfarin for non-valvular atrial fibrillation, based on subsequent guidelines.

## Blood Pressure Management

- **Antihypertensive therapy** should be initiated or resumed after the hyperacute phase (after the first 24 hours) for patients with BP consistently > 140/90 mmHg (Class I, LOE A).
- Target: **< 140/90 mmHg** for most patients; more aggressive targets may be appropriate for some.
- **ACE inhibitors** and **thiazide diuretics** have the strongest evidence for secondary stroke prevention (PROGRESS trial).
- Acute blood pressure reduction within the first 24 hours is NOT recommended unless BP is severely elevated (> 220/120 mmHg) or there is a compelling indication.

## Statin Therapy

- **High-intensity statin therapy** (e.g., atorvastatin 80 mg daily) is recommended for patients with TIA presumed due to atherosclerotic disease, regardless of baseline LDL (Class I, LOE B).
- Target: LDL < 100 mg/dL; consider LDL < 70 mg/dL for high-risk patients.
- The SPARCL trial demonstrated that atorvastatin 80 mg reduced recurrent stroke risk by 16% in patients with prior stroke/TIA.

## Carotid Revascularization

### Carotid Endarterectomy (CEA)

- **CEA is recommended** for patients with ipsilateral **carotid stenosis 70–99%** who are surgical candidates (Class I, LOE A).
- **CEA is reasonable** for patients with ipsilateral **carotid stenosis 50–69%** depending on patient-specific factors (age, sex, comorbidities) (Class IIa, LOE B).
- CEA should be performed **within 2 weeks** of TIA for maximum benefit; the number needed to treat (NNT) increases with delay.
- CEA is NOT recommended for stenosis < 50%.

### Carotid Artery Stenting (CAS)

- **CAS is an alternative** to CEA in patients at high surgical risk (Class IIb, LOE B).
- CAS may be preferred for: high cervical or intracranial lesions, radiation-induced stenosis, restenosis after prior CEA.

## Lifestyle Modifications

| Intervention | Recommendation |
|---|---|
| **Smoking cessation** | Strongly recommended; offer pharmacotherapy (NRT, bupropion, varenicline) and counseling |
| **Physical activity** | ≥ 30 minutes of moderate-intensity exercise most days of the week |
| **Diet** | DASH or Mediterranean diet; reduce sodium to < 2.3 g/day |
| **Alcohol** | Limit to ≤ 2 drinks/day for men, ≤ 1 drink/day for women; abstinence for heavy drinkers |
| **Weight management** | Maintain BMI 18.5–24.9 kg/m² |

## Diabetes Management

- **Glycemic control** is recommended for patients with diabetes (target HbA1c generally < 7%) to reduce microvascular complications.
- The direct benefit of tight glycemic control on recurrent stroke risk is less established, but diabetes management reduces overall cardiovascular morbidity.

## Limitations

- The 2009 statement was published before the CHANCE and POINT DAPT trials; DAPT recommendations are based on subsequent evidence.
- Optimal timing and intensity of blood pressure reduction after TIA remain debated.
- ABCD2-based hospitalization criteria have been challenged by subsequent studies showing low scores can miss high-risk patients.
- Carotid stenosis management guidelines have evolved with updated data on CAS vs. CEA outcomes.
