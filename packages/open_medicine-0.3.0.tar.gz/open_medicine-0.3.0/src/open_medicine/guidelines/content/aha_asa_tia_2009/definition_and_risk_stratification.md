# Definition and Risk Stratification of Transient Ischemic Attack — AHA/ASA 2009

## TIA Definition

The AHA/ASA endorses the following tissue-based definition of transient ischemic attack (TIA):

> **TIA is a transient episode of neurological dysfunction caused by focal brain, spinal cord, or retinal ischemia, without acute infarction.**

This definition replaces the prior time-based definition (symptoms resolving within 24 hours). The key distinction is that TIA requires **both** symptom resolution **and** absence of infarction on neuroimaging. If diffusion-weighted MRI (DWI) demonstrates acute infarction despite symptom resolution, the event is classified as ischemic stroke, not TIA.

### Rationale for Tissue-Based Definition

- Approximately one-third of patients with transient symptoms lasting < 24 hours have DWI-positive lesions (acute infarction)
- Symptom duration alone does not reliably distinguish TIA from stroke
- The 24-hour time threshold was arbitrary and not evidence-based

## ABCD2 Score for Risk Stratification

The ABCD2 score (range 0–7) stratifies short-term stroke risk after TIA and is recommended for use in triage decisions.

### Score Components

| Component | Criterion | Points |
|-----------|-----------|--------|
| **A**ge | ≥ 60 years | 1 |
| **B**lood pressure | Systolic ≥ 140 mmHg or diastolic ≥ 90 mmHg at initial evaluation | 1 |
| **C**linical features | Unilateral weakness | 2 |
| **C**linical features | Speech disturbance without weakness | 1 |
| **D**uration | ≥ 60 minutes | 2 |
| **D**uration | 10–59 minutes | 1 |
| **D**iabetes | History of diabetes mellitus | 1 |

> **OpenMedicine Calculator:** `calculate_abcd2` — available via MCP for automated scoring.

### 2-Day Stroke Risk by ABCD2 Score

| Score Range | Risk Category | 2-Day Stroke Risk |
|-------------|---------------|-------------------|
| 0–3 | Low risk | 1.0% |
| 4–5 | Moderate risk | 4.1% |
| 6–7 | High risk | 8.1% |

### 7-Day and 90-Day Stroke Risk

- **7-day stroke risk:** approximately 5.9% for ABCD2 ≥ 4
- **90-day stroke risk:** overall 10–15% across all TIA patients

## Risk Factors Beyond ABCD2

The ABCD2 score does not capture all relevant risk factors. The following should also be considered:

- **DWI-positive lesion on MRI:** Indicates acute infarction; significantly increases recurrent stroke risk independent of ABCD2 score
- **Large-artery atherosclerosis (carotid stenosis ≥ 50%):** Associated with very high early recurrence risk
- **Crescendo TIAs (multiple TIAs within a short period):** Indicate unstable vascular pathology requiring urgent intervention
- **Atrial fibrillation:** Cardioembolic mechanism; requires anticoagulation rather than antiplatelet therapy

## Limitations

- The ABCD2 score was developed for population-level risk stratification and should not be used as the sole criterion for disposition decisions
- Low ABCD2 scores do not exclude the possibility of early stroke; clinical judgment is essential
- The score does not account for etiology (large artery, cardioembolic, small vessel) which drives specific treatment
