# Delayed Cerebral Ischemia — AHA/ASA 2023

## Definition and Epidemiology

- **Delayed cerebral ischemia (DCI)** is defined as focal neurological impairment (e.g., hemiparesis, aphasia), a decrease in GCS of ≥ 2 points lasting ≥ 1 hour, or cerebral infarction on imaging not attributable to other causes.
- DCI occurs in approximately **20–30%** of patients with aSAH, typically between **days 4 and 14** after hemorrhage (peak incidence days 7–10).
- Risk factors for DCI include: thick subarachnoid clot (modified Fisher 3–4), poor clinical grade (HH ≥ 3), cigarette smoking, and younger age.

> **OpenMedicine Calculator:** `calculate_fisher_grade` — available via MCP. Higher modified Fisher grades predict greater vasospasm and DCI risk.

## Monitoring and Detection

### Clinical Monitoring

- **Frequent neurological assessments** are critical during the DCI risk window (days 4–14) (Class I, LOE B-NR).
- In patients with high-grade SAH (HH 4–5) where clinical examination is limited, additional monitoring modalities are essential.

### Transcranial Doppler (TCD)

- TCD ultrasonography is useful to detect cerebral vasospasm (Class IIa, LOE B-NR).
- **MCA mean flow velocity > 120 cm/s** suggests vasospasm; **> 200 cm/s** suggests severe vasospasm.
- **Lindegaard ratio** (MCA velocity / extracranial ICA velocity) **> 3** indicates vasospasm; **> 6** indicates severe vasospasm.
- TCD should be performed serially during the DCI risk window.

### CT Angiography and CT Perfusion

- CTA and CTP can be useful to detect vasospasm and predict DCI (Class IIa, LOE B-NR).
- CTP may identify perfusion deficits before clinical symptoms manifest.

## Prevention of DCI

- **Nimodipine 60 mg orally every 4 hours for 21 days** is the cornerstone of DCI prevention (Class I, LOE A). See the Medical Management section for full dosing details.
- **Euvolemia maintenance** with isotonic crystalloids (Class IIa, LOE B-R).
- **Prophylactic induced hypertension and hypervolemia are NOT recommended** (Class III: Harm, LOE B-R).

### Therapies NOT Recommended for DCI Prevention

- **Statins:** routine use is not recommended (Class III: No Benefit, LOE B-R).
- **Intravenous magnesium:** not recommended (Class III: No Benefit, LOE A).
- **Endothelin receptor antagonists:** not recommended (Class III: No Benefit, LOE B-R).

## Treatment of Symptomatic DCI

### Step 1: Hemodynamic Augmentation (First-Line)

- **Elevating blood pressure** and maintaining euvolemia in patients with symptomatic DCI can be beneficial (Class IIb, LOE B-NR).
- **Protocol:**
  1. Ensure euvolemia with isotonic crystalloid boluses (e.g., 500 mL 0.9% NaCl over 30 minutes).
  2. If neurological deficit persists, initiate **vasopressor therapy**:
     - **Norepinephrine:** start at 0.05–0.1 mcg/kg/min, titrate to neurological improvement or target SBP (typically 180–220 mmHg, individualized).
     - **Phenylephrine:** start at 0.5–1 mcg/kg/min, titrate as above.
  3. Monitor for response within 30–60 minutes.
  4. If clinical improvement occurs, maintain augmented blood pressure and wean slowly over 24–48 hours.
  5. If no improvement, proceed to endovascular rescue.

### Step 2: Endovascular Rescue (Refractory Cases)

#### Intra-Arterial Vasodilator Therapy

- Intra-arterial vasodilators can be reasonable to reverse vasospasm (Class IIb, LOE C-LD).
- **Agents:**
  - **Verapamil:** 5–20 mg per vessel, administered slowly intra-arterially; most commonly used.
  - **Nicardipine:** 5–10 mg per vessel, administered intra-arterially.
- **Papaverine** should be avoided due to neurotoxicity risk.

#### Transluminal Balloon Angioplasty

- Reasonable for treatment of focal large-vessel vasospasm (Class IIb, LOE C-LD).
- Produces longer-lasting vasodilation compared to intra-arterial vasodilators.
- Most effective for proximal large-vessel vasospasm (ICA, M1, A1, basilar artery).

## Decision Tree for DCI Management

1. Rule out other causes: rebleeding, hydrocephalus, seizure, metabolic derangement, infection.
2. Confirm vasospasm/DCI with TCD, CTA, or CTP.
3. Initiate hemodynamic augmentation (euvolemia + induced hypertension with vasopressors).
4. If no improvement within 1–2 hours of maximal medical therapy, proceed to emergent endovascular rescue.
5. Continue nimodipine throughout.

## Limitations

- Optimal blood pressure targets for hemodynamic augmentation are not established; management must be individualized.
- Evidence for endovascular rescue therapies is largely observational.
- TCD is operator-dependent and has limited sensitivity for distal vasospasm.
- No single monitoring modality reliably predicts DCI in all patients.
