# Aneurysm Treatment and Rebleeding Prevention — AHA/ASA 2023

## Timing of Aneurysm Repair

- Surgical or endovascular treatment of the ruptured aneurysm should be performed as early as feasible, preferably **within 24 hours** of onset, to reduce rebleeding risk and improve outcome (Class I, LOE B-NR).
- Rebleeding risk is highest in the first 24 hours (4–14%), with the majority occurring within the first 6 hours.
- Delayed treatment beyond 24 hours is associated with worse outcomes due to rebleeding and medical complications.

## Treatment Modality Selection

### Anterior Circulation Aneurysms

- For patients with **good-grade aSAH** (HH 1–3) from ruptured anterior circulation aneurysms where both coiling and clipping are feasible:
  - **Primary endovascular coiling** is recommended for superior 1-year functional outcomes (Class I, LOE A).
  - **Both coiling and clipping** are reasonable to achieve favorable long-term outcomes (Class IIa, LOE B-R).
- Decisions should be made by a multidisciplinary team based on aneurysm morphology, location, patient age, and clinical status.

### Posterior Circulation Aneurysms

- For patients with aSAH from ruptured **posterior circulation** aneurysms amenable to coiling, **endovascular coiling is indicated in preference to clipping** (Class I, LOE B-R).

### Considerations Favoring Surgical Clipping

- Middle cerebral artery (MCA) aneurysms with wide necks or branch incorporation
- Large intraparenchymal hematomas requiring surgical evacuation
- Patient age < 40 years (greater durability of clipping)
- Aneurysm morphology unfavorable for endovascular treatment

### Considerations Favoring Endovascular Coiling

- Posterior circulation aneurysms
- Elderly patients (age > 70 years)
- Poor clinical grade (HH 4–5)
- Aneurysm morphology favorable for coiling

## Complete Obliteration

- Complete obliteration of the ruptured aneurysm is indicated whenever feasible to reduce the risk of rebleeding and retreatment (Class I, LOE B-NR).
- Long-term angiographic follow-up is recommended after endovascular treatment to detect aneurysm recurrence.

## Blood Pressure Management Before Aneurysm Securing

- **Frequent monitoring and control of hypertension** with short-acting titratable antihypertensive agents is recommended (Class I, LOE B-NR).
- Avoid systolic blood pressure > 160 mmHg prior to aneurysm securing.
- Avoid mean arterial pressure < 65 mmHg (risk of cerebral ischemia).
- **Short-acting IV antihypertensives** are preferred:
  - Nicardipine: continuous IV infusion, starting at 5 mg/hr, titrate by 2.5 mg/hr every 5–15 minutes, max 15 mg/hr
  - Labetalol: 10–20 mg IV bolus, may repeat every 10–20 minutes, or continuous infusion 2 mg/min
  - Clevidipine: continuous IV infusion, starting at 1–2 mg/hr, titrate by 1–2 mg/hr every 90 seconds

## Rebleeding Prevention (Prior to Definitive Treatment)

- **Early aneurysm repair** (within 24 hours) is the most effective strategy to prevent rebleeding.
- **Tranexamic acid (TXA)** is NOT recommended for routine use — it has not been shown to improve functional outcomes despite reducing rebleeding (Class III: No Benefit, LOE B-R).
- **Bed rest and avoidance of Valsalva maneuvers** are reasonable supportive measures.

## High-Grade SAH (HH 4–5)

- Patients with high-grade SAH should be treated with early and aggressive management, including aneurysm securing within 24 hours when feasible.
- Early prognostic nihilism should be avoided: meaningful recovery is possible with aggressive management.

## Limitations

- The ISAT trial enrolled predominantly good-grade patients with small anterior circulation aneurysms; generalizability may be limited.
- Long-term retreatment rates are higher with endovascular coiling than with surgical clipping.
- Treatment modality decisions should be made case-by-case by experienced multidisciplinary teams.
