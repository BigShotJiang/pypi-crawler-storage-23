# Medical Management of Aneurysmal Subarachnoid Hemorrhage — AHA/ASA 2023

## Nimodipine

- **Early initiation of enteral nimodipine** is beneficial in preventing delayed cerebral ischemia (DCI) and improving functional outcomes (Class I, LOE A).
- **Dosing:** Nimodipine 60 mg orally (or via enteral tube) every 4 hours for **21 days** from SAH onset.
- **Hemodynamic intolerance:** If the patient cannot tolerate 60 mg every 4 hours due to hypotension, reduce to **30 mg every 2 hours**.
- Nimodipine is the **only FDA-approved agent** for improving outcomes in aSAH.
- **Route:** Oral or enteral only. Intravenous nimodipine is associated with excessive hypotension and is not recommended.

## Fluid and Volume Management

- **Goal-directed treatment to maintain euvolemia** is recommended (Class IIa, LOE B-R).
- Use isotonic crystalloid solutions for volume maintenance.
- **Induced hypervolemia is NOT recommended** — it increases complications without improving outcomes (Class III: Harm, LOE B-R).
- Monitor sodium closely: hyponatremia is common (cerebral salt wasting, SIADH).
  - Avoid fluid restriction for hyponatremia in the acute phase (risk of volume contraction and DCI).
  - Hypertonic saline or fludrocortisone may be used for symptomatic or severe hyponatremia.

## Seizure Prophylaxis

- **Routine prophylactic antiseizure medication is NOT recommended** in all aSAH patients (Class III: No Benefit, LOE B-NR).
- **Consider short-term (up to 7 days) prophylaxis** in high-risk patients (Class IIb, LOE B-NR):
  - Hunt-Hess grade ≥ 3
  - Acute hydrocephalus
  - Intraparenchymal hemorrhage
  - Ruptured middle cerebral artery aneurysm
  - Cortical infarction
- **Phenytoin must be avoided** — it is associated with worse functional outcomes (Class III: Harm, LOE B-NR).
- Preferred alternative: levetiracetam.

## Venous Thromboembolism (VTE) Prophylaxis

- **Mechanical prophylaxis** (intermittent pneumatic compression devices) should be initiated on admission for all patients.
- **Pharmacologic prophylaxis** (LMWH or UFH) should be initiated **after the aneurysm is secured** (Class I, LOE B-NR).
  - LMWH (e.g., enoxaparin 40 mg subcutaneously once daily) is safe with no significant increase in bleeding risk.
  - Can be started within 24 hours of aneurysm securing.

## Glycemic Control

- **Maintain blood glucose ≤ 180 mg/dL** (Class IIa, LOE B-NR).
- Target glucose 140–180 mg/dL while strictly avoiding hypoglycemia (< 70 mg/dL).

## Temperature Management

- **Fever (temperature > 38.3°C / 101°F)** is independently associated with worse outcomes and DCI.
- Aggressive fever management is recommended (Class IIa, LOE B-NR):
  - Scheduled acetaminophen 650–1000 mg every 4–6 hours
  - Surface or intravascular cooling devices for refractory fever
  - Identify and treat infectious causes
- Normothermia (36.5–37.5°C) should be maintained.

## Hydrocephalus Management

- **Acute symptomatic hydrocephalus** should be managed by **CSF diversion** (external ventricular drain [EVD] or lumbar drain) (Class I, LOE B-NR).
- EVD placement is indicated in patients with:
  - Decreased level of consciousness (GCS ≤ 12)
  - Acute obstructive hydrocephalus on CT
  - Intraventricular hemorrhage (IVH)
- Approximately 20–30% of patients require permanent CSF diversion (ventriculoperitoneal shunt).

> **OpenMedicine Calculator:** `calculate_gcs` — available via MCP for automated GCS scoring to guide EVD placement decisions.

## Therapies NOT Recommended

| Therapy | Recommendation | COR/LOE |
|---------|---------------|---------|
| **Tranexamic acid** | No improvement in functional outcomes | Class III: No Benefit, LOE B-R |
| **Induced hypervolemia** | Increases complications without benefit | Class III: Harm, LOE B-R |
| **Routine statin therapy** | No benefit for DCI prevention | Class III: No Benefit, LOE B-R |
| **Intravenous magnesium** | No benefit for DCI prevention | Class III: No Benefit, LOE A |
| **Endothelin receptor antagonists** | Associated with adverse effects | Class III: No Benefit, LOE B-R |
| **Phenytoin** | Associated with worse outcomes | Class III: Harm, LOE B-NR |
| **Routine seizure prophylaxis** | No benefit in unselected patients | Class III: No Benefit, LOE B-NR |

## Limitations

- Optimal blood glucose and temperature targets are extrapolated from general neurocritical care literature; SAH-specific RCTs are lacking.
- The 21-day nimodipine duration is based on historical trial design; individualization may be considered.
