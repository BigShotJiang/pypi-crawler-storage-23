# Evaluation of Chronic Kidney Disease — KDIGO 2024

## Definition and Diagnosis

CKD is defined as abnormalities of kidney structure or function, present for > 3 months, with implications for health. Diagnosis requires at least one of:
- Decreased GFR: eGFR < 60 mL/min/1.73m² (confirmed on repeat testing).
- Markers of kidney damage: albuminuria (ACR ≥ 30 mg/g), urine sediment abnormalities, electrolyte abnormalities due to tubular disorders, histological abnormalities, structural abnormalities on imaging, history of kidney transplantation.

## GFR Assessment

- Use the **CKD-EPI 2021 creatinine equation** (race-free) for initial eGFR estimation (Grade 1B).
- Confirm with **cystatin C-based** or **creatinine-cystatin C combined** equation when eGFR based on creatinine alone may be inaccurate (extremes of muscle mass, diet, or body habitus).
- Measured GFR (mGFR) using exogenous markers (iohexol, iothalamate) should be considered when precise GFR is needed for clinical decisions (e.g., living kidney donation, drug dosing of narrow therapeutic index medications).

## Albuminuria Assessment

- Measure urine albumin-to-creatinine ratio (ACR) from an early morning spot urine sample.
- Confirm abnormal results on at least 2 of 3 specimens collected over 3-6 months.
- ACR categories:
  - **A1:** < 30 mg/g (normal to mildly increased)
  - **A2:** 30–300 mg/g (moderately increased — formerly "microalbuminuria")
  - **A3:** > 300 mg/g (severely increased — formerly "macroalbuminuria")

## Risk Stratification

CKD prognosis is determined by the combination of GFR category and albuminuria category using the **KDIGO heat map**:
- **Low risk (green):** G1-G2 + A1
- **Moderately increased risk (yellow):** G1-G2 + A2, or G3a + A1
- **High risk (orange):** G1-G2 + A3, G3a + A2, or G3b + A1
- **Very high risk (red):** G3a + A3, G3b + A2-A3, G4-G5 (any albuminuria)
