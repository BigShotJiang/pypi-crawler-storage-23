# Necrotizing Pancreatitis Management — ACG 2024

## Antibiotics in Acute Pancreatitis

### Prophylactic Antibiotics — Not Recommended

The ACG **suggests against** prophylactic antibiotics in patients with severe AP and/or sterile necrosis (Conditional, Low).

- Routine use of prophylactic antibiotics does NOT reduce mortality or prevent infected necrosis.

### Therapeutic Antibiotics for Infected Necrosis

When infection is **proven or strongly suspected**, the ACG **recommends** antibiotics that are known to **penetrate pancreatic necrosis** (Strong, Moderate):

| Antibiotic Class | Examples | Penetration |
|---|---|---|
| **Carbapenems** | Imipenem, meropenem | Excellent |
| **Quinolones** | Ciprofloxacin | Good |
| **Cephalosporins (3rd generation)** | Ceftriaxone, cefotaxime | Good |
| **Nitroimidazoles** | Metronidazole | Good (anaerobes) |

Antibiotics serve a **dual purpose**: treat the infection AND **delay intervention beyond 4 weeks** to allow wall maturation of the necrotic collection.

## Diagnosis of Infected Necrosis

### Fine-Needle Aspiration (FNA) — No Longer Recommended

The ACG **suggests against** routine fine-needle aspiration (FNA) in patients with suspected infected pancreatic necrosis (Conditional, Very Low).

**Rationale:** FNA results often do not change management. A negative result would not preclude antibiotic use when clinical suspicion is high, and a positive result would confirm what clinical signs already suggest.

### Clinical Criteria for Infected Necrosis

Infected necrosis typically occurs **after 14 days** and can be identified by:

| Finding | Significance |
|---|---|
| **Gas bubbles** in (peri-)pancreatic collections on CT | Highly specific for infection |
| **Persistent clinical deterioration** despite adequate treatment | Suggestive in absence of other infection sources |
| **Positive blood or body fluid cultures** | Confirmatory |
| **Elevated procalcitonin** | More specific for infection than CRP (which reflects inflammation) |

> **Key Rule:** In proven infection (positive cultures or gas in necrosis), the need for antibiotics is clear. For suspected infection, empiric antibiotics should be started on clinical grounds without waiting for FNA confirmation.

## Step-Up Approach for Infected Necrosis

The ACG endorses the **step-up approach** as the standard of care for managing infected pancreatic necrosis (Strong, High):

```
Suspected or confirmed infected necrosis
  → Step 1: ANTIBIOTICS
      → Use antibiotics that penetrate pancreatic necrosis
      → Goal: Treat infection AND delay intervention ≥ 4 weeks
          → Infection resolves with antibiotics alone? (25–60% of cases)
              → YES → No further intervention needed
              → NO → Proceed to Step 2

  → Step 2: PERCUTANEOUS OR ENDOSCOPIC DRAINAGE
      → Percutaneous catheter drainage (PCD) or endoscopic transluminal drainage
      → Delays surgical treatment, results in complete resolution
        in 25–60% of patients
          → Collection resolves?
              → YES → Continue antibiotics, monitor
              → NO → Proceed to Step 3

  → Step 3: MINIMALLY INVASIVE NECROSECTOMY
      → Preferred approaches:
          - Direct endoscopic necrosectomy
          - Video-assisted retroperitoneal debridement (VARD)
      → Open surgical necrosectomy reserved for failure of
        minimally invasive approaches
```

## Timing of Intervention

The ACG **suggests** delaying any intervention (surgical, radiologic, and/or endoscopic) in **stable** patients with pancreatic necrosis, **preferably for 4 weeks or more** (Conditional, Low).

### Rationale for Delayed Intervention

Waiting ≥ 4 weeks allows:

- **Liquefaction** of necrotic contents
- Development of a **fibrous wall** (encapsulation) around the necrosis
- Maturation from **acute necrotic collection (ANC)** to **walled-off necrosis (WOPN)**
- Safer and more effective intervention with lower complication rates

## Minimally Invasive vs. Open Surgery

The ACG **suggests** minimally invasive methods over open surgery for debridement and necrosectomy in stable patients (Conditional, Moderate).

| Approach | Advantages | Disadvantages |
|---|---|---|
| **Endoscopic transluminal** | Lowest complication rate, lower cost | May require multiple sessions |
| **VARD** | Direct visualization, effective debridement | Requires retroperitoneal access |
| **Percutaneous drainage** | Least invasive first step | May be insufficient as sole therapy |
| **Open necrosectomy** | Definitive debridement | Highest morbidity, more new-onset organ failure |

- Minimally invasive approaches result in **less postoperative new-onset organ failure** but may require **more interventions** than open surgery.
- The **endoscopic transluminal approach** compared with minimally invasive surgery reduces complications and costs.

## Asymptomatic Collections

Sterile pancreatic and/or peripancreatic necrosis that is **asymptomatic generally does not require intervention**, regardless of size, location, or extension.

## Limitations

- The optimal antibiotic regimen (specific agents, duration, de-escalation strategy) for infected necrosis is not standardized.
- The step-up approach has been validated primarily in centers with expertise in minimally invasive pancreatic intervention; outcomes may vary in less experienced settings.
- The 4-week delay is a guideline target for stable patients; unstable patients with sepsis and multi-organ failure may require earlier intervention.
- Procalcitonin-guided antibiotic therapy shows promise but requires further validation in larger multicenter trials.
