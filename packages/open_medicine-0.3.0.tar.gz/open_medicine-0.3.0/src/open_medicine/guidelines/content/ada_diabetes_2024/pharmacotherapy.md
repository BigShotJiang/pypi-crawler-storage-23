# Pharmacologic Approaches to Glycemic Treatment in Type 2 Diabetes — ADA 2024

## Core Principles

- **Recommendation 9.8 (Grade A):** Healthy lifestyle behaviors, diabetes self-management education and support, avoidance of therapeutic inertia, and social determinants of health should be addressed as part of the treatment plan.
- **Recommendation 9.9 (Grade E):** A person-centered, shared decision-making approach should guide the choice of pharmacologic agents, considering effects on cardiovascular and renal comorbidities, effectiveness, hypoglycemia risk, impact on weight, cost and access, risk for adverse reactions, and individual preferences.
- **Recommendation 9.12 (Grade A):** Treatment modification (intensification or deintensification) should not be delayed for adults not meeting individualized treatment goals.
- **Recommendation 9.14 (Grade A):** Early combination therapy can be considered at treatment initiation to shorten time to attainment of goals. When A1C is ≥ 1.5% above the individualized goal, many individuals will require dual-combination therapy or a more potent glucose-lowering agent.

---

## Type 2 Diabetes Treatment Algorithm

```
Patient with newly diagnosed type 2 diabetes
  → Does the patient have established ASCVD, high CV risk, HF, or CKD?
      → YES → See cardiovascular_risk section
              Include SGLT2i and/or GLP-1 RA with demonstrated benefit
              regardless of A1C (Rec 9.18, Grade A)
      → NO → Assess glycemic and weight management goals
          → A1C < 1.5% above goal?
              → Start monotherapy guided by weight/glycemic goals
          → A1C ≥ 1.5% above goal?
              → Consider early combination therapy (Rec 9.14, Grade A)
          → A1C > 10% OR blood glucose ≥ 300 mg/dL OR catabolic symptoms?
              → Initiate insulin therapy (Rec 9.22, Grade E)
  → Reassess A1C every 3 months; intensify if not at goal
  → If insulin is needed, prefer GLP-1 RA or dual GIP/GLP-1 RA first (Rec 9.23, Grade A)
```

---

## Medication Classes for Type 2 Diabetes

### Metformin

| Parameter | Detail |
|---|---|
| Starting dose | 500 mg once or twice daily with meals |
| Titration | Increase by 500 mg weekly as tolerated |
| Maximum dose | 2,000–2,550 mg/day in divided doses |
| Extended-release | Available; may improve GI tolerability |

- Effective, safe, inexpensive, widely available.
- Weight neutral; does not cause hypoglycemia when used as monotherapy.
- **eGFR thresholds:** May be safely used at eGFR ≥ 30 mL/min/1.73 m². Risk of lactic acidosis increases at eGFR < 30 mL/min/1.73 m². For eGFR 30–45 mL/min/1.73 m², consider dose reduction and monitor renal function more frequently.
- **Side effects:** Gastrointestinal intolerance (bloating, diarrhea); mitigated by gradual dose titration and/or extended-release formulation.
- Periodic testing of vitamin B12 levels is suggested with long-term use.

### SGLT2 Inhibitors (Recommendation 9.18–9.20, Grade A)

Recommended as part of the treatment plan for patients with type 2 diabetes and established or high risk of ASCVD, HF, and/or CKD, independent of A1C and independent of metformin use.

| Drug | Maximum Daily Dose |
|---|---|
| Canagliflozin | 300 mg once daily |
| Dapagliflozin | 10 mg once daily |
| Empagliflozin | 25 mg once daily |
| Ertugliflozin | 15 mg once daily |

- **HF (Rec 9.19, Grade A):** An SGLT2 inhibitor is recommended for adults with type 2 diabetes who have HF (with either reduced or preserved ejection fraction).
- **CKD (Rec 9.20, Grade A):** An SGLT2 inhibitor should be used in adults with type 2 diabetes who have CKD with confirmed eGFR 20–60 mL/min/1.73 m² and/or albuminuria. Glycemic benefits are reduced at eGFR < 45 mL/min/1.73 m², but cardiorenal benefits persist.
- **Advanced CKD (Rec 9.21, Grade B):** In adults with eGFR < 30 mL/min/1.73 m², a GLP-1 RA is preferred for glycemic management.
- **Adverse effects:** Genital mycotic infections, volume depletion, diabetic ketoacidosis (rare), Fournier gangrene (rare).

### GLP-1 Receptor Agonists

Recommended for cardiorenal benefit (Rec 9.18, Grade A) and preferred to insulin when intensification is needed (Rec 9.23, Grade A).

| Drug | Route | Maximum Dose | Frequency |
|---|---|---|---|
| Liraglutide | Subcutaneous | 1.8 mg | Once daily |
| Semaglutide | Subcutaneous | 2 mg | Once weekly |
| Semaglutide | Oral | 14 mg | Once daily |
| Dulaglutide | Subcutaneous | 4.5 mg | Once weekly |
| Exenatide ER | Subcutaneous | 2 mg | Once weekly |

- Semaglutide and tirzepatide have the highest glycemic and weight loss efficacy among agents approved for glycemic management.
- **Adverse effects:** Nausea, vomiting, diarrhea (usually transient; minimize by starting at lowest dose and titrating slowly). Pancreatitis (rare). Contraindicated in personal or family history of medullary thyroid carcinoma or MEN2.

### Dual GIP/GLP-1 Receptor Agonist — Tirzepatide

| Drug | Route | Maximum Dose | Frequency |
|---|---|---|---|
| Tirzepatide | Subcutaneous | 15 mg | Once weekly |

- Starting dose: 2.5 mg weekly, titrate by 2.5 mg every 4 weeks.
- Very high efficacy for glucose lowering and weight loss.

### Insulin Therapy

#### When to Initiate Insulin (Recommendation 9.22, Grade E)

Insulin should be considered regardless of background therapy if:
- Evidence of ongoing catabolism (e.g., unexpected weight loss)
- Symptoms of hyperglycemia are present
- A1C > 10% (> 86 mmol/mol) or blood glucose ≥ 300 mg/dL (≥ 16.7 mmol/L)

#### Preference Before Insulin (Recommendation 9.23, Grade A)

A GLP-1 RA or dual GIP/GLP-1 RA is preferred to insulin for treatment intensification. If insulin is used, combination with a GLP-1 RA or dual GIP/GLP-1 RA is recommended (Rec 9.24, Grade A).

#### Basal Insulin

| Parameter | Detail |
|---|---|
| Starting dose | 10 units/day or 0.1–0.2 units/kg/day |
| Titration | Adjust by 10–15% or 2–4 units once or twice weekly to reach fasting glucose target |
| Overbasalization signal | Basal dose > ~0.5 units/kg/day, bedtime-to-morning glucose differential ≥ 50 mg/dL, hypoglycemia, high variability |

**Basal insulin types:**

| Insulin | Duration |
|---|---|
| Glargine U-100 (Lantus, Basaglar, Semglee) | ~24 hours |
| Glargine U-300 (Toujeo) | > 24 hours |
| Detemir (Levemir) | ~12–24 hours |
| Degludec (Tresiba) | > 42 hours |
| NPH | ~12–18 hours |

> **OpenMedicine Calculator:** `calculate_insulin_basal_dosing` — available via MCP for automated basal insulin dose calculation.

#### Prandial Insulin

If basal insulin is insufficient (overbasalization), consider adding a GLP-1 RA or dual GIP/GLP-1 RA before adding prandial insulin (Rec 9.23, Grade A). If prandial insulin is needed:
- Start with the largest meal or the meal with greatest postprandial excursion.
- Starting dose: 4 units, 0.1 units/kg, or 10% of basal dose.

### DPP-4 Inhibitors

| Drug | Maximum Daily Dose |
|---|---|
| Sitagliptin | 100 mg once daily |
| Saxagliptin | 5 mg once daily |
| Linagliptin | 5 mg once daily |
| Alogliptin | 25 mg once daily |

- Modest A1C reduction (~0.5–0.8%).
- Weight neutral. Low hypoglycemia risk.
- **Do NOT combine with GLP-1 RA** (overlapping mechanism, no additive benefit).
- Linagliptin does not require renal dose adjustment; others require dose reduction with reduced eGFR.

### Thiazolidinediones (TZDs)

| Drug | Maximum Daily Dose |
|---|---|
| Pioglitazone | 45 mg once daily |

- Durable glycemic effect. Low hypoglycemia risk.
- **Contraindications:** NYHA class III–IV heart failure, active liver disease.
- **Adverse effects:** Weight gain, fluid retention, edema, increased fracture risk, possible increased bladder cancer risk (pioglitazone).

### Sulfonylureas (Second Generation)

| Drug | Maximum Daily Dose |
|---|---|
| Glimepiride | 8 mg once daily |
| Glipizide | 40 mg/day (in divided doses) |
| Glyburide (micronized) | 12 mg/day (in divided doses) |

- High hypoglycemia risk (especially glyburide). Weight gain.
- Inexpensive and widely available.
- **Recommendation 9.26 (Grade A):** When starting insulin therapy, reassess the need for and/or dose of sulfonylureas to minimize hypoglycemia risk.
- **Recommendation 9.29 (Grade E):** In adults with cost-related barriers, sulfonylureas remain a reasonable option.

---

## Cost Considerations (Recommendation 9.28–9.29, Grade E)

- Routinely screen all people with diabetes for financial obstacles that could impede management.
- In adults with cost-related barriers, consider lower-cost medications: metformin, sulfonylureas, thiazolidinediones, and human insulin.

## Limitations

- Treatment algorithms must be individualized; no single pathway is appropriate for all patients.
- Newer agents (GLP-1 RA, SGLT2i, tirzepatide) have superior efficacy and cardiorenal benefits but higher cost, which may limit access.
- Evidence for combination therapy at treatment initiation continues to evolve.
- Dosing tables reflect maximum approved doses; clinical practice often uses submaximal doses based on response and tolerability.
