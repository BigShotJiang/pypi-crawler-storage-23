"""
benchmark.py — Compare CPU vs GPU performance for MPS simulation.

Usage
-----
    from mps_gpu import benchmark
    benchmark(n_qubits=20, chi=64, depth=40)
"""

from __future__ import annotations
import time
import numpy as np
from typing import Optional


def _build_random_circuit(n: int, depth: int):
    """Build a random 1D brickwork circuit."""
    from mps_sim.circuits import Circuit
    rng = np.random.default_rng(42)
    c = Circuit(n)
    for layer in range(depth):
        for q in range(n):
            theta = float(rng.uniform(0, 2 * np.pi))
            c.rx(theta, q)
        start = layer % 2
        for q in range(start, n - 1, 2):
            c.cx(q, q + 1)
    return c


def benchmark(
    n_qubits: int = 16,
    chi: int = 64,
    depth: int = 30,
    backends: Optional[list] = None,
    repetitions: int = 3,
) -> dict:
    """
    Time MPS circuit simulation on every requested backend.

    Parameters
    ----------
    n_qubits : int
        Circuit width.
    chi : int
        Bond dimension (larger → more GPU benefit).
    depth : int
        Circuit depth (gate layers).
    backends : list or None
        List of backend names to test.  None = auto-detect.
    repetitions : int
        Number of runs to average.

    Returns
    -------
    dict
        {backend_name: mean_seconds}
    """
    from .backend import list_backends, get_backend
    from .simulator import GPUSimulator

    if backends is None:
        backends = list_backends()

    circuit = _build_random_circuit(n_qubits, depth)
    results = {}

    print(f"\n{'='*60}")
    print(f"  MPS GPU Benchmark")
    print(f"  n={n_qubits} qubits | chi={chi} | depth≈{depth} | {repetitions} runs")
    print(f"{'='*60}")

    for bname in backends:
        try:
            be = get_backend(bname)
        except RuntimeError as e:
            print(f"  {bname:8s}  — skipped ({e})")
            continue

        sim = GPUSimulator(chi=chi, backend=bname)
        times = []

        # Warmup
        try:
            sim.run(circuit)
        except Exception as e:
            print(f"  {bname:8s}  — FAILED: {e}")
            continue

        for _ in range(repetitions):
            t0 = time.perf_counter()
            sim.run(circuit)
            times.append(time.perf_counter() - t0)

        mean_t = np.mean(times)
        std_t = np.std(times)
        results[bname] = mean_t
        print(f"  {bname:8s}  {mean_t:.3f}s ± {std_t:.3f}s")

    # Speedup relative to CPU
    if "cpu" in results and len(results) > 1:
        cpu_t = results["cpu"]
        print(f"\n  Speedups vs CPU:")
        for bname, t in results.items():
            if bname != "cpu":
                print(f"    {bname}: {cpu_t/t:.1f}×")

    print(f"{'='*60}\n")
    return results


if __name__ == "__main__":
    benchmark()
