"""
simulator.py — GPUSimulator

Drop-in replacement for mps_sim.circuits.MPSSimulator that uses GPUMPS
internally.  All circuit-running and expectation-value logic is identical
to the original; only the underlying MPS tensors are GPU-accelerated.

Usage
-----
    from mps_gpu import GPUSimulator
    from mps_sim.circuits import Circuit

    sim = GPUSimulator(chi=128)
    circ = Circuit(20)
    circ.h(0)
    for i in range(19):
        circ.cx(i, i+1)
    state = sim.run(circ)
    print(state.expectation_pauli_z(0))
"""

from __future__ import annotations
import numpy as np
from numpy.typing import NDArray
from typing import Optional
import logging

from .backend import get_backend, BackendName
from .mps import GPUMPS

logger = logging.getLogger(__name__)


class GPUSimulator:
    """
    MPS circuit simulator with GPU tensor-op acceleration.

    Parameters
    ----------
    chi : int
        Maximum bond dimension (SVD truncation cap).
    svd_threshold : float
        Singular values below this are discarded before the bond-dim cap.
    backend : {"cuda", "mps", "cpu"} or None
        Select compute backend.  None (default) = auto-detect best available.
    pin_tensors : bool
        Keep MPS tensors resident on device between gate applications.
        Experimental; reduces host↔device transfers for large χ.
    """

    def __init__(
        self,
        chi: int,
        svd_threshold: float = 1e-14,
        backend: Optional[BackendName] = None,
        pin_tensors: bool = False,
    ):
        self.chi = chi
        self.svd_threshold = svd_threshold
        self.backend = get_backend(backend)
        self.pin_tensors = pin_tensors
        logger.info(f"GPUSimulator initialised with backend={self.backend.name}, chi={chi}")

    # ------------------------------------------------------------------
    # Public API (mirrors MPSSimulator)
    # ------------------------------------------------------------------

    def run(self, circuit) -> GPUMPS:
        """Simulate circuit from |0…0⟩ and return final GPUMPS state."""
        state = GPUMPS(circuit.n, self.chi, backend=self.backend,
                       pin_tensors=self.pin_tensors)
        self._apply_circuit(circuit, state)
        return state

    def run_from(self, circuit, state: GPUMPS) -> GPUMPS:
        """Apply circuit to an existing GPUMPS state (modifies a copy)."""
        new_state = state.copy()
        new_state.chi = self.chi
        self._apply_circuit(circuit, new_state)
        return new_state

    def expectation_value(
        self,
        state: GPUMPS,
        observable: str,
        site: int,
        site2: Optional[int] = None,
    ) -> float:
        if observable == 'Z':
            return state.expectation_pauli_z(site)
        elif observable == 'X':
            return state.expectation_pauli_x(site)
        elif observable == 'Y':
            return state.expectation_pauli_y(site)
        elif observable in ('ZZ', 'XX', 'YY') and site2 is not None:
            ops_map = {
                'ZZ': np.array([[1, 0], [0, -1]], dtype=complex),
                'XX': np.array([[0, 1], [1, 0]], dtype=complex),
                'YY': np.array([[0, -1j], [1j, 0]], dtype=complex),
            }
            op1 = ops_map[observable]
            op = np.einsum('ij,kl->ikjl', op1, op1)
            if abs(site - site2) == 1:
                return float(np.real(state.expectation_two(op, min(site, site2))))
            else:
                raise NotImplementedError("Non-adjacent two-site observables not implemented")
        else:
            raise ValueError(f"Unknown observable: {observable}")

    # ------------------------------------------------------------------
    # Internal circuit application
    # ------------------------------------------------------------------

    def _apply_circuit(self, circuit, state: GPUMPS):
        for inst in circuit.instructions:
            n_qubits = len(inst.qubits)
            if n_qubits == 1:
                self._apply_single(inst, state)
            elif n_qubits == 2:
                self._apply_two(inst, state)
            else:
                raise ValueError(f"Gates on >2 qubits not supported: {inst}")

    def _apply_single(self, inst, state: GPUMPS):
        """Single-qubit gate: GPU einsum on physical index."""
        q = inst.qubits[0]
        gate = inst.get_matrix()
        t = state.get_tensor(q)
        new_t = np.asarray(state.backend.einsum('sp,lpr->lsr', gate, t))
        state.set_tensor(q, new_t)
        state.center = None

    def _apply_two(self, inst, state: GPUMPS):
        """Two-qubit gate with GPU-accelerated SVD truncation."""
        q1, q2 = inst.qubits

        if abs(q1 - q2) != 1:
            self._apply_two_nonlocal(inst, state)
            return

        if q1 > q2:
            q1, q2 = q2, q1
            gate = inst.get_matrix().transpose(1, 0, 3, 2)
        else:
            gate = inst.get_matrix()

        A = state.get_tensor(q1)
        B = state.get_tensor(q2)

        # Build two-site tensor — GPU einsum
        theta = np.asarray(state.backend.einsum('lir,rjs->lijs', A, B))

        # Apply gate — GPU einsum
        theta = np.asarray(state.backend.einsum('abij,lijs->labs', gate, theta))

        # SVD truncation — GPU SVD (the hot-path)
        state.apply_svd_truncation(q1, theta, chi=self.chi,
                                    svd_threshold=self.svd_threshold)
        state.center = None

    def _apply_two_nonlocal(self, inst, state: GPUMPS):
        """Bring non-adjacent qubits together via SWAPs, apply gate, SWAP back."""
        from mps_sim.gates import SWAP as make_swap
        from mps_sim.circuits import GateInstruction

        q1, q2 = inst.qubits
        if q1 > q2:
            q1, q2 = q2, q1

        swap_gate = make_swap()

        for pos in range(q2, q1 + 1, -1):
            swap_inst = GateInstruction('SWAP', [pos - 1, pos], matrix=swap_gate)
            self._apply_two(swap_inst, state)

        modified_inst = GateInstruction(
            inst.name, [q1, q1 + 1], inst.params, inst.matrix, inst.label
        )
        self._apply_two(modified_inst, state)

        for pos in range(q1 + 1, q2):
            swap_inst = GateInstruction('SWAP', [pos, pos + 1], matrix=swap_gate)
            self._apply_two(swap_inst, state)
