"""
mps_gpu — GPU-accelerated Matrix Product State simulator.

Drop-in replacement for mps_sim that transparently dispatches
tensor operations to CUDA (via CuPy), Apple MPS (via PyTorch),
or CPU (NumPy) depending on what is available.

Quick start
-----------
    from mps_gpu import GPUSimulator
    from mps_sim.circuits import Circuit

    sim = GPUSimulator(chi=64)          # auto-selects best backend
    circuit = Circuit(20)
    # ... build circuit ...
    state = sim.run(circuit)
    print(state.expectation_pauli_z(0))

Backends (in priority order)
-----------------------------
1. "cuda"  — CuPy; requires NVIDIA GPU + CuPy installed
2. "mps"   — PyTorch MPS; requires Apple Silicon Mac
3. "cpu"   — NumPy (original behaviour, always available)

Force a backend:
    sim = GPUSimulator(chi=64, backend="cuda")
"""

from .backend import get_backend, list_backends
from .mps import GPUMPS
from .simulator import GPUSimulator
from .benchmark import benchmark

__all__ = ["GPUSimulator", "GPUMPS", "get_backend", "list_backends", "benchmark"]
__version__ = "1.0.0"
