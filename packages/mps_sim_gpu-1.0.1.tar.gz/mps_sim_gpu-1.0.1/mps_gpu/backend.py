"""
backend.py — Detect available compute backends and expose a unified xp interface.

Each backend object exposes the same NumPy-style API so the rest of the
code can stay backend-agnostic.  Only the heavy tensor ops (einsum, svd,
qr, diag, zeros, …) need GPU equivalents.
"""

from __future__ import annotations
import logging
from typing import Literal, Optional

import numpy as np

logger = logging.getLogger(__name__)

BackendName = Literal["cuda", "mps", "cpu"]


# ---------------------------------------------------------------------------
# Backend wrappers
# ---------------------------------------------------------------------------

class _NumpyBackend:
    """Wraps NumPy — the always-available fallback."""
    name = "cpu"
    xp = np

    def to_device(self, arr):
        return np.asarray(arr, dtype=complex)

    def to_numpy(self, arr):
        return np.asarray(arr)

    def svd(self, mat):
        return np.linalg.svd(mat, full_matrices=False)

    def qr(self, mat):
        return np.linalg.qr(mat)

    def einsum(self, subscripts, *operands):
        return np.einsum(subscripts, *operands)

    def zeros(self, shape, dtype=complex):
        return np.zeros(shape, dtype=dtype)

    def diag(self, v):
        return np.diag(v)

    def eye(self, n, dtype=complex):
        return np.eye(n, dtype=dtype)


class _CuPyBackend:
    """Wraps CuPy for NVIDIA CUDA GPUs."""
    name = "cuda"

    def __init__(self):
        import cupy as cp
        import cupy.linalg as cpla
        self.cp = cp
        self.cpla = cpla
        self.xp = cp

    def to_device(self, arr):
        return self.cp.asarray(arr, dtype=complex)

    def to_numpy(self, arr):
        return self.cp.asnumpy(arr)

    def svd(self, mat):
        return self.cpla.svd(mat, full_matrices=False)

    def qr(self, mat):
        return self.cpla.qr(mat)

    def einsum(self, subscripts, *operands):
        return self.cp.einsum(subscripts, *operands)

    def zeros(self, shape, dtype=complex):
        return self.cp.zeros(shape, dtype=dtype)

    def diag(self, v):
        return self.cp.diag(v)

    def eye(self, n, dtype=complex):
        return self.cp.eye(n, dtype=dtype)


class _TorchBackend:
    """
    Wraps PyTorch for Apple MPS (Apple Silicon) or CUDA.

    torch.linalg.svd / qr / einsum are used; results are always complex128
    to match NumPy precision.
    """
    def __init__(self, device_str: str):
        import torch
        self.torch = torch
        self.device = torch.device(device_str)
        self.name = device_str  # "mps" or "cuda"
        self.xp = None  # no direct array-protocol — use helper methods

    def _t(self, arr):
        """Convert numpy array → torch tensor on device."""
        import torch
        if isinstance(arr, torch.Tensor):
            return arr.to(self.device)
        return torch.tensor(arr, dtype=torch.complex128, device=self.device)

    def _np(self, t):
        """Convert torch tensor → numpy array."""
        return t.cpu().numpy()

    def to_device(self, arr):
        return self._t(arr)

    def to_numpy(self, arr):
        return self._np(arr)

    def svd(self, mat):
        import torch
        t = self._t(mat)
        U, S, Vh = torch.linalg.svd(t, full_matrices=False)
        return self._np(U), self._np(S.real), self._np(Vh)

    def qr(self, mat):
        import torch
        t = self._t(mat)
        Q, R = torch.linalg.qr(t)
        return self._np(Q), self._np(R)

    def einsum(self, subscripts, *operands):
        import torch
        ts = [self._t(op) for op in operands]
        result = torch.einsum(subscripts, *ts)
        return self._np(result)

    def zeros(self, shape, dtype=complex):
        import torch
        return np.zeros(shape, dtype=complex)  # stays numpy; sent to device on first use

    def diag(self, v):
        return np.diag(v)

    def eye(self, n, dtype=complex):
        return np.eye(n, dtype=dtype)


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------

def _try_cupy() -> Optional[_CuPyBackend]:
    try:
        import cupy as cp
        # Verify a GPU is actually accessible
        cp.array([1.0])
        b = _CuPyBackend()
        logger.info("GPU backend: CUDA via CuPy ✓")
        return b
    except Exception as e:
        logger.debug(f"CuPy not available: {e}")
        return None


def _try_torch_mps() -> Optional[_TorchBackend]:
    try:
        import torch
        if torch.backends.mps.is_available():
            b = _TorchBackend("mps")
            # Smoke-test
            t = torch.tensor([1.0 + 0j], device="mps")
            logger.info("GPU backend: Apple MPS via PyTorch ✓")
            return b
    except Exception as e:
        logger.debug(f"PyTorch MPS not available: {e}")
    return None


def _try_torch_cuda() -> Optional[_TorchBackend]:
    try:
        import torch
        if torch.cuda.is_available():
            b = _TorchBackend("cuda")
            logger.info("GPU backend: CUDA via PyTorch ✓")
            return b
    except Exception as e:
        logger.debug(f"PyTorch CUDA not available: {e}")
    return None


def list_backends() -> list[str]:
    """Return names of all available backends on this machine."""
    available = ["cpu"]
    if _try_cupy():
        available.insert(0, "cuda")
    elif _try_torch_cuda():
        available.insert(0, "cuda")
    if _try_torch_mps():
        available.insert(0, "mps")
    return available


def get_backend(name: Optional[BackendName] = None):
    """
    Return a backend instance.

    Parameters
    ----------
    name : {"cuda", "mps", "cpu"} or None
        Force a specific backend.  None → auto-select best available.
    """
    if name == "cpu":
        return _NumpyBackend()

    if name == "cuda":
        b = _try_cupy() or _try_torch_cuda()
        if b is None:
            raise RuntimeError(
                "CUDA backend requested but neither CuPy nor PyTorch CUDA is available."
            )
        return b

    if name == "mps":
        b = _try_torch_mps()
        if b is None:
            raise RuntimeError(
                "Apple MPS backend requested but not available. "
                "Requires Apple Silicon Mac with PyTorch ≥ 1.12."
            )
        return b

    # Auto-select
    for probe in (_try_cupy, _try_torch_mps, _try_torch_cuda):
        b = probe()
        if b is not None:
            return b

    logger.info("GPU backend: none found, falling back to CPU (NumPy)")
    return _NumpyBackend()
