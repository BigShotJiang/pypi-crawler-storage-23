from setuptools import setup, find_packages
from pathlib import Path

long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="mps_sim_gpu",
    version="1.0.1",
    description="GPU-accelerated MPS quantum circuit simulator (CUDA / Apple MPS / CPU)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="mps_sim contributors",
    license="MIT",
    packages=find_packages(exclude=["tests*"]),
    python_requires=">=3.9",
    install_requires=[
        "mps_sim>=1.0.0",
        "numpy>=1.22",
    ],
    extras_require={
        "cuda":  ["cupy-cuda12x"],   # NVIDIA GPU via CuPy
        "torch": ["torch>=2.0"],     # Apple MPS or CUDA via PyTorch
        "dev":   ["pytest>=7.0", "pytest-benchmark"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Physics",
        "Intended Audience :: Science/Research",
    ],
    keywords="quantum computing MPS tensor network GPU CUDA simulation",
    project_urls={
        "Source": "https://github.com/your-org/mps_sim_gpu",
        "Bug Tracker": "https://github.com/your-org/mps_sim_gpu/issues",
    },
)
