"""
tests/test_gpu_sim.py

Verify that GPUSimulator (CPU backend) produces results identical to
the original mps_sim MPSSimulator on a range of circuits.

Run with:  pytest tests/test_gpu_sim.py -v
"""

import math
import numpy as np
import pytest

from mps_sim.circuits import Circuit, MPSSimulator
from mps_gpu import GPUSimulator

CPU_SIM = MPSSimulator(chi=64)
GPU_SIM = GPUSimulator(chi=64, backend="cpu")


def _run_both(circuit):
    s_ref = CPU_SIM.run(circuit)
    s_gpu = GPU_SIM.run(circuit)
    return s_ref, s_gpu


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def expval_z(sim, state, n):
    return [sim.expectation_value(state, 'Z', i) for i in range(n)]


# --------------------------------------------------------------------------
# Tests
# --------------------------------------------------------------------------

class TestBellState:
    def test_z_expectation(self):
        c = Circuit(2)
        c.h(0).cx(0, 1)
        ref, gpu = _run_both(c)
        for i in range(2):
            np.testing.assert_allclose(
                ref.expectation_pauli_z(i),
                gpu.expectation_pauli_z(i),
                atol=1e-12, rtol=0,
                err_msg=f"Z[{i}] mismatch"
            )

    def test_statevector(self):
        c = Circuit(2)
        c.h(0).cx(0, 1)
        ref, gpu = _run_both(c)
        sv_ref = ref.to_statevector()
        sv_gpu = gpu.to_statevector()
        np.testing.assert_allclose(np.abs(sv_ref), np.abs(sv_gpu), atol=1e-12)

    def test_norm(self):
        c = Circuit(2)
        c.h(0).cx(0, 1)
        _, gpu = _run_both(c)
        np.testing.assert_allclose(gpu.norm(), 1.0, atol=1e-12)


class TestGHZ:
    @pytest.mark.parametrize("n", [4, 8, 12])
    def test_z_expectations(self, n):
        c = Circuit(n)
        c.h(0)
        for i in range(n - 1):
            c.cx(i, i + 1)
        ref, gpu = _run_both(c)
        for i in range(n):
            np.testing.assert_allclose(
                ref.expectation_pauli_z(i),
                gpu.expectation_pauli_z(i),
                atol=1e-11,
            )

    def test_norm(self):
        c = Circuit(10)
        c.h(0)
        for i in range(9):
            c.cx(i, i + 1)
        _, gpu = _run_both(c)
        np.testing.assert_allclose(gpu.norm(), 1.0, atol=1e-11)


class TestSingleQubitGates:
    def test_rx(self):
        c = Circuit(3)
        c.rx(math.pi / 3, 0).rx(math.pi / 7, 1).rx(math.pi / 5, 2)
        ref, gpu = _run_both(c)
        for i in range(3):
            np.testing.assert_allclose(
                ref.expectation_pauli_x(i),
                gpu.expectation_pauli_x(i),
                atol=1e-12,
            )

    def test_ry(self):
        c = Circuit(2)
        c.ry(1.23, 0).ry(0.456, 1)
        ref, gpu = _run_both(c)
        np.testing.assert_allclose(
            ref.expectation_pauli_y(0),
            gpu.expectation_pauli_y(0),
            atol=1e-12,
        )

    def test_hadamard_x(self):
        c = Circuit(1)
        c.h(0)
        ref, gpu = _run_both(c)
        np.testing.assert_allclose(
            ref.expectation_pauli_x(0),
            gpu.expectation_pauli_x(0),
            atol=1e-12,
        )


class TestTwoQubitGates:
    def test_cz(self):
        c = Circuit(3)
        c.h(0).h(1).cz(0, 1)
        ref, gpu = _run_both(c)
        for i in range(3):
            np.testing.assert_allclose(
                ref.expectation_pauli_z(i),
                gpu.expectation_pauli_z(i),
                atol=1e-12,
            )

    def test_zz_rotation(self):
        c = Circuit(4)
        c.h(0).h(1).h(2).h(3)
        c.zz(math.pi / 4, 0, 1)
        c.zz(math.pi / 6, 2, 3)
        ref, gpu = _run_both(c)
        for i in range(4):
            np.testing.assert_allclose(
                ref.expectation_pauli_z(i),
                gpu.expectation_pauli_z(i),
                atol=1e-12,
            )


class TestRandomCircuit:
    def test_random_brickwork(self):
        """Random brickwork circuit — full statevector comparison."""
        rng = np.random.default_rng(1234)
        n = 8
        c = Circuit(n)
        for _ in range(6):
            for q in range(n):
                c.rx(float(rng.uniform(0, 2 * np.pi)), q)
            for q in range(0, n - 1, 2):
                c.cx(q, q + 1)
            for q in range(1, n - 1, 2):
                c.cx(q, q + 1)

        ref, gpu = _run_both(c)
        sv_ref = ref.to_statevector()
        sv_gpu = gpu.to_statevector()
        np.testing.assert_allclose(np.abs(sv_ref), np.abs(sv_gpu), atol=1e-10)


class TestNonAdjacentGate:
    def test_non_adjacent_cx(self):
        c = Circuit(5)
        c.h(0)
        c.cx(0, 4)   # non-adjacent: needs SWAP chain
        ref, gpu = _run_both(c)
        sv_ref = ref.to_statevector()
        sv_gpu = gpu.to_statevector()
        np.testing.assert_allclose(np.abs(sv_ref), np.abs(sv_gpu), atol=1e-10)


class TestBondDimension:
    def test_truncation_error_attribute(self):
        c = Circuit(6)
        c.h(0)
        for i in range(5):
            c.cx(i, i + 1)
        _, gpu = _run_both(c)
        assert isinstance(gpu.total_truncation_error(), float)
        assert gpu.total_truncation_error() >= 0.0

    def test_bond_dimensions_bounded(self):
        c = Circuit(10)
        c.h(0)
        for i in range(9):
            c.cx(i, i + 1)
        chi = 8
        sim = GPUSimulator(chi=chi, backend="cpu")
        state = sim.run(c)
        for bd in state.bond_dimensions():
            assert bd <= chi


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
