"""The scecifics mendevi exceptions."""


class RejectError(AssertionError):
    """Raised to reject the line."""
