"""Extract from database and plot."""
