"""Define the constants."""

from .profiles import PROFILES

__all__ = ["PROFILES"]
