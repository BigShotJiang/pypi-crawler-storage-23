"""All the available encoders."""

from mendevi.encode import ENCODERS_CMD

ENCODERS = set(ENCODERS_CMD)
