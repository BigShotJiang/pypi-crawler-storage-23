"""Regressive and predictive models."""

from .base import Model

__all__ = ["Model"]
