"""Handle the data percistency."""
