from .main import linear_cross_entropy

__all__ = [
    "linear_cross_entropy",
]
