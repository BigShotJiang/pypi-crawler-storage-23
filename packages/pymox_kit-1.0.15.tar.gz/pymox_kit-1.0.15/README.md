# PyMoX-Kit

Trousse à outils utiles pour devs en PyMoX

---

## Installation

```bash
py -m venv .venv
.\.venv\Scripts\activate
py -m pip install --upgrade pip
pip install pymox_kit
```

## Utilisation

```python
from pytmox_kit import *


prnt(Hello())
```
