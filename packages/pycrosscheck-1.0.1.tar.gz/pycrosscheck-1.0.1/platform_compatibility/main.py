#!/usr/bin/env python3
"""
Platform Compatibility Tool
Main entry point for Windows compatibility detection in Python code.

This tool detects Windows compatibility issues using Bandit plugin and advanced AST rules.
"""

import argparse
import subprocess
import sys
import json
import csv
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any

# Import advanced rules system for detection
sys.path.insert(0, str(Path(__file__).parent.parent))
try:
    from advanced_integration import AdvancedCompatibilityChecker
    from compatibility_rules.advanced_rules import ADVANCED_RULES
    ADVANCED_RULES_AVAILABLE = True
except ImportError:
    ADVANCED_RULES_AVAILABLE = False

def run_bandit_detection(paths: List[str], recursive: bool = False, output_format: str = "terminal") -> bool:
    """Run complete compatibility detection (Bandit + Advanced rules)."""
    print("🔍 Running Complete Windows Compatibility Detection...")
    print("=" * 60)
    
    detection_success = True
    
    # Run Bandit detection first
    print("📋 Step 1: Bandit Plugin Detection (Function-level rules)")
    print("-" * 50)
    bandit_success = _run_bandit_only(paths, recursive, output_format)
    
    # Run Advanced rules detection
    if ADVANCED_RULES_AVAILABLE:
        print("\n📋 Step 2: Advanced AST Rules Detection (Pattern-level rules)")
        print("-" * 50)
        advanced_success = _run_advanced_detection_only(paths, recursive)
        detection_success = bandit_success and advanced_success
    else:
        print("\n⚠️  Advanced AST rules not available - skipping advanced detection")
        detection_success = bandit_success
    
    print(f"\n� Detection Summary")
    print("=" * 30)
    if detection_success:
        print("✅ Detection completed successfully")
    else:
        print("⚠️  Some issues were detected")
    
    return detection_success


def _run_bandit_only(paths: List[str], recursive: bool = False, output_format: str = "terminal") -> bool:
    """Run only the Bandit plugin detection."""
    try:
        # Use subprocess for bandit as the API is complex
        cmd = ["bandit"]
        
        if recursive:
            cmd.append("-r")
        
        if output_format == "json":
            cmd.extend(["-f", "json"])
        elif output_format == "csv":
            cmd.extend(["-f", "csv"])
        elif output_format == "xml":
            cmd.extend(["-f", "xml"])
        # Default is terminal output
        
        # Filter only our plugin
        cmd.extend(["-t", "PTB001"])
        
        cmd.extend(paths)
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print(result.stderr, file=sys.stderr)
            
        # For bandit, return code 1 just means issues were found, not an error
        # Return code 2+ indicates actual errors
        return result.returncode < 2
        
    except FileNotFoundError:
        print("❌ Error: bandit not found. Please install bandit or activate the virtual environment.")
        return False
    except Exception as e:
        print(f"❌ Error running bandit detection: {e}")
        return False


def _run_advanced_detection_only(paths: List[str], recursive: bool = False) -> bool:
    """Run only the advanced AST rules detection."""
    try:
        checker = AdvancedCompatibilityChecker()
        total_violations = 0
        
        for path_str in paths:
            path = Path(path_str)
            
            if path.is_file() and path.suffix == '.py':
                files_to_process = [path]
            elif path.is_dir():
                if recursive:
                    files_to_process = list(path.rglob('*.py'))
                else:
                    files_to_process = list(path.glob('*.py'))
            else:
                print(f"Skipping {path}: not a Python file or directory")
                continue
            
            for file_path in files_to_process:
                violations = checker.check_file(file_path)
                if violations:
                    print(f"\n📄 {file_path}:")
                    for violation in violations:
                        print(f"  Line {violation.line}: {violation.message}")
                    total_violations += len(violations)
        
        if total_violations == 0:
            print("✅ No advanced compatibility issues found!")
        else:
            print(f"\n⚠️  Found {total_violations} advanced compatibility issues")
        
        return True  # Always return True for detection, even if issues found
        
    except Exception as e:
        print(f"❌ Error running advanced detection: {e}")
        return False

def show_rules_summary():
    """Show a summary of all available rules (traditional + advanced)."""
    print("📋 Windows Compatibility Detection Rules")
    print("=" * 60)
    print("💡 Note: This tool detects and reports compatibility issues.\n")
    
    # Traditional rules summary
    print("🔧 Traditional Rules (Function-level)")
    print("-" * 40)
    try:
        from compatibility_rules import get_rules_summary
        summary = get_rules_summary()
        
        print(f"Total traditional rules: {summary['total_rules']}")
        print()
        
        print("Categories:")
        for category, info in summary['categories'].items():
            print(f"  {category}: {info['description']} ({info['count']} rules)")
        
        print("\nTags:")
        for tag, info in summary['tags'].items():
            print(f"  {tag}: {info['count']} rules")
            
    except ImportError:
        print("❌ Error: Could not import traditional compatibility rules")
    
    # Advanced rules summary
    print(f"\n🔍 Advanced AST Rules (Pattern-level)")
    print("-" * 40)
    if ADVANCED_RULES_AVAILABLE:
        print(f"Total advanced rules: {len(ADVANCED_RULES)}")
        print("\nAdvanced Rules:")
        for rule_code, rule_class in ADVANCED_RULES.items():
            rule_instance = rule_class()
            print(f"  {rule_code}: {rule_instance.__class__.__name__}")
            print(f"    Category: {rule_instance.category}")
            print(f"    Message: {rule_instance.message}")
            print(f"    Tags: {', '.join(rule_instance.tags)}")
            print()
    else:
        print("⚠️  Advanced AST rules not available")
    
    # Combined summary
    print(f"\n📊 Combined Summary")
    print("-" * 30)
    traditional_count = 0
    advanced_count = 0
    
    try:
        from compatibility_rules import get_all_rules
        traditional_count = len(get_all_rules())
    except ImportError:
        pass
    
    if ADVANCED_RULES_AVAILABLE:
        advanced_count = len(ADVANCED_RULES)
    
    total_rules = traditional_count + advanced_count
    print(f"Total compatibility rules: {total_rules}")
    print(f"  - Traditional (function-level): {traditional_count}")
    print(f"  - Advanced (pattern-level): {advanced_count}")

def validate_paths(paths: List[str]) -> bool:
    """Validate that all provided paths exist."""
    for path_str in paths:
        path = Path(path_str)
        if not path.exists():
            print(f"❌ Error: Path does not exist: {path_str}")
            return False
    return True


def collect_all_issues(paths: List[str], recursive: bool = False) -> Dict[str, Any]:
    """Collect all compatibility issues from both traditional and advanced rules."""
    issues_data = {
        "scan_info": {
            "timestamp": datetime.now().isoformat(),
            "paths_scanned": paths,
            "recursive": recursive,
            "total_traditional_rules": 56,
            "total_advanced_rules": 8 if ADVANCED_RULES_AVAILABLE else 0,
            "total_rules": 64 if ADVANCED_RULES_AVAILABLE else 56
        },
        "traditional_issues": [],
        "advanced_issues": [],
        "summary": {
            "total_files_scanned": 0,
            "files_with_issues": 0,
            "total_traditional_issues": 0,
            "total_advanced_issues": 0,
            "total_issues": 0
        }
    }
    
    files_scanned = set()
    files_with_issues = set()
    
    # Collect traditional issues (from Bandit)
    try:
        for path_str in paths:
            path = Path(path_str)
            
            if path.is_file() and path.suffix == '.py':
                files_to_process = [path]
            elif path.is_dir():
                if recursive:
                    files_to_process = list(path.rglob('*.py'))
                else:
                    files_to_process = list(path.glob('*.py'))
            else:
                continue
            
            for file_path in files_to_process:
                files_scanned.add(str(file_path))
                
                # Run bandit on individual file to get structured output
                cmd = ["bandit", "-f", "json", "-t", "PTB001", str(file_path)]
                try:
                    result = subprocess.run(cmd, capture_output=True, text=True)
                    if result.stdout:
                        bandit_data = json.loads(result.stdout)
                        for result_item in bandit_data.get("results", []):
                            files_with_issues.add(str(file_path))
                            issue = {
                                "file": str(file_path),
                                "line": result_item.get("line_number", 0),
                                "column": result_item.get("col_offset", 0),
                                "rule_id": result_item.get("test_id", "PTB001"),
                                "severity": result_item.get("issue_severity", "MEDIUM"),
                                "confidence": result_item.get("issue_confidence", "HIGH"),
                                "message": result_item.get("issue_text", ""),
                                "code": result_item.get("code", ""),
                                "category": "traditional"
                            }
                            issues_data["traditional_issues"].append(issue)
                except (subprocess.SubprocessError, json.JSONDecodeError):
                    continue
    except Exception as e:
        print(f"⚠️  Warning: Error collecting traditional issues: {e}")
    
    # Collect advanced issues (from AST rules)
    if ADVANCED_RULES_AVAILABLE:
        try:
            checker = AdvancedCompatibilityChecker()
            
            for path_str in paths:
                path = Path(path_str)
                
                if path.is_file() and path.suffix == '.py':
                    files_to_process = [path]
                elif path.is_dir():
                    if recursive:
                        files_to_process = list(path.rglob('*.py'))
                    else:
                        files_to_process = list(path.glob('*.py'))
                else:
                    continue
                
                for file_path in files_to_process:
                    files_scanned.add(str(file_path))
                    violations = checker.check_file(file_path)
                    
                    for violation in violations:
                        files_with_issues.add(str(file_path))
                        
                        # Extract rule code from violation message
                        rule_code = "RWC_UNKNOWN"
                        for code in ADVANCED_RULES.keys():
                            if code in violation.message:
                                rule_code = code
                                break
                        
                        issue = {
                            "file": str(file_path),
                            "line": violation.line or 0,
                            "column": violation.column or 0,
                            "rule_id": rule_code,
                            "severity": "MEDIUM",
                            "confidence": "HIGH",
                            "message": violation.message,
                            "category": "advanced"
                        }
                        issues_data["advanced_issues"].append(issue)
                        
        except Exception as e:
            print(f"⚠️  Warning: Error collecting advanced issues: {e}")
    
    # Update summary
    issues_data["summary"]["total_files_scanned"] = len(files_scanned)
    issues_data["summary"]["files_with_issues"] = len(files_with_issues)
    issues_data["summary"]["total_traditional_issues"] = len(issues_data["traditional_issues"])
    issues_data["summary"]["total_advanced_issues"] = len(issues_data["advanced_issues"])
    issues_data["summary"]["total_issues"] = (
        issues_data["summary"]["total_traditional_issues"] + 
        issues_data["summary"]["total_advanced_issues"]
    )
    
    return issues_data


def save_report_json(issues_data: Dict[str, Any], file_path: str):
    """Save issues report to JSON file."""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(issues_data, f, indent=2, ensure_ascii=False)
        print(f"📄 JSON report saved to: {file_path}")
    except Exception as e:
        print(f"❌ Error saving JSON report: {e}")


def save_report_csv(issues_data: Dict[str, Any], file_path: str):
    """Save issues report to CSV file."""
    try:
        with open(file_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            # Header
            writer.writerow([
                "File", "Line", "Column", "Category", "Rule_ID", "Severity", 
                "Confidence", "Message"
            ])
            
            # Traditional issues
            for issue in issues_data["traditional_issues"]:
                writer.writerow([
                    issue["file"],
                    issue["line"],
                    issue["column"],
                    issue["category"],
                    issue["rule_id"],
                    issue["severity"],
                    issue["confidence"],
                    issue["message"]
                ])
            
            # Advanced issues
            for issue in issues_data["advanced_issues"]:
                writer.writerow([
                    issue["file"],
                    issue["line"],
                    issue["column"],
                    issue["category"],
                    issue["rule_id"],
                    issue["severity"],
                    issue["confidence"],
                    issue["message"]
                ])
        
        print(f"📊 CSV report saved to: {file_path}")
    except Exception as e:
        print(f"❌ Error saving CSV report: {e}")


def generate_report_file(issues_data: Dict[str, Any], file_path: str):
    """Generate report file based on extension."""
    path = Path(file_path)
    extension = path.suffix.lower()
    
    if extension == '.json':
        save_report_json(issues_data, file_path)
    elif extension == '.csv':
        save_report_csv(issues_data, file_path)
    else:
        print(f"❌ Unsupported file format: {extension}")
        print("💡 Supported formats: .json, .csv")
        return False
    
    # Print summary
    summary = issues_data["summary"]
    print(f"\n📋 Report Summary:")
    print(f"   Files scanned: {summary['total_files_scanned']}")
    print(f"   Files with issues: {summary['files_with_issues']}")
    print(f"   Traditional issues: {summary['total_traditional_issues']}")
    print(f"   Advanced issues: {summary['total_advanced_issues']}")
    print(f"   Total issues: {summary['total_issues']}")
    
    return True

def main():
    parser = argparse.ArgumentParser(
        description="Platform Compatibility Tool - Detect Windows compatibility issues in Python code",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
This tool combines ALL compatibility rules:
• Traditional rules: Function-level compatibility checks (os.fork, os.getuid, etc.)
• Advanced AST rules: Pattern-level checks (paths, commands, imports, etc.)

Examples:
  # Detect ALL compatibility issues (Bandit + AST rules)
  python main.py detect myfile.py
  
  # Detect issues recursively in a directory 
  python main.py detect -r myproject/
  
  # Show all available rules (traditional + advanced)
  python main.py rules
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Detection command
    detect_parser = subparsers.add_parser("detect", help="Detect Windows compatibility issues")
    detect_parser.add_argument("paths", nargs="+", help="Files or directories to analyze")
    detect_parser.add_argument("-r", "--recursive", action="store_true", 
                              help="Process directories recursively")
    detect_parser.add_argument("-f", "--format", choices=["terminal", "json", "csv", "xml"], 
                              default="terminal", help="Output format")
    detect_parser.add_argument("--file", type=str, 
                              help="Save detailed report to file (supports .json, .csv formats)")
    
    # Rules command
    rules_parser = subparsers.add_parser("rules", help="Show summary of all compatibility rules")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    # Handle rules command
    if args.command == "rules":
        show_rules_summary()
        return 0
    
    # Validate paths for commands that need them
    if args.command == "detect":
        if not validate_paths(args.paths):
            return 1
    
    success = True
    
    # Execute detect command
    if args.command == "detect":
        print("🚀 Starting Complete Windows Compatibility Detection...\n")
        
        # If file output is requested, collect all issues and generate report
        if hasattr(args, 'file') and args.file:
            print(f"🔄 Collecting issues for report: {args.file}")
            issues_data = collect_all_issues(args.paths, args.recursive)
            
            # Generate and save report
            if generate_report_file(issues_data, args.file):
                # Determine exit code based on issues found
                total_issues = issues_data["summary"]["total_issues"]
                if total_issues > 0:
                    print(f"\n⚠️  {total_issues} issues found (saved to {args.file})")
                    success = False  # Issues found
                else:
                    print(f"\n✅ No issues found (report saved to {args.file})")
                    success = True
            else:
                success = False
        else:
            # Normal terminal output detection
            success = run_bandit_detection(args.paths, args.recursive, args.format)
    
    # Summary
    print("\n📊 Summary:")
    if success:
        print("✅ Operation completed successfully!")
    else:
        print("❌ Some errors occurred during processing")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
