"""
Platform Compatibility Tool Package
"""

from .main import main

__version__ = "1.0.0"
__all__ = ["main"]
