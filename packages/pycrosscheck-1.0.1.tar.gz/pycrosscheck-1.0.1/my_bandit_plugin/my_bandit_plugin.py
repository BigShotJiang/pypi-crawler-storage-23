import ast
import sys
from pathlib import Path

# Add compatibility_rules to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from bandit.core import test_properties as test
from bandit.core import issue
from bandit.core.constants import MEDIUM, HIGH
from compatibility_rules import get_bandit_rules

# Get rules from centralized configuration
BAD_OS_FUNCTIONS = get_bandit_rules()

@test.checks('Call')
@test.test_id('PTB001')
def os_windows_incompatible_functions(context):
    """Check for os module functions that are incompatible with Windows."""
    if isinstance(context.node.func, ast.Attribute):
        # Check if this is a call to an os function
        if (hasattr(context.node.func.value, 'id') and 
            context.node.func.value.id == 'os'):
            # Build the full function name with os. prefix
            full_function_name = f"os.{context.node.func.attr}"
            if full_function_name in BAD_OS_FUNCTIONS:
                return issue.Issue(
                    severity=MEDIUM,
                    confidence=HIGH,
                    text=BAD_OS_FUNCTIONS[full_function_name],
                    lineno=context.node.lineno
                )