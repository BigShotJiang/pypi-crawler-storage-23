# PyCrossCheck

**A cross-platform compatibility checker for Python code**

PyCrossCheck automatically detects platform-specific code that may cause issues on Windows, Linux, or macOS, and provides intelligent suggestions for cross-platform alternatives.

## Features

- **Cross-Platform Detection**: Identifies Windows, Linux, and macOS-specific code that may break on other platforms
- **Smart Suggestions**: Provides clear, actionable recommendations with cross-platform alternatives
- **Comprehensive Analysis**: 56+ rules organized in 10 categories covering file system, process management, user operations, and more
- **Easy Integration**: Simple CLI interface and JSON output for CI/CD pipelines
- **Bandit Plugin**: Extends Bandit static analysis with platform compatibility checks

## Installation

### From PyPI (Recommended)

```bash
pip install pycrosscheck
```

### From Source

```bash
# Clone the repository
git clone https://github.com/yourusername/pycrosscheck.git
cd pycrosscheck

# Install in development mode
pip install -e .
```

## Quick Start

### Basic Usage

After installation, you can use the `pycrosscheck` or `pycc` command:

```bash
# Check a single file
pycrosscheck detect myfile.py

# Check an entire project recursively
pycrosscheck detect -r myproject/

# Check with different output formats
pycrosscheck detect --format json myfile.py
pycrosscheck detect --format csv myfile.py
```

### View All Rules

```bash
# Display all available compatibility rules
pycrosscheck rules
```

## 📖 Usage Examples

### Example 1: Check a Python File

```bash
pycrosscheck detect script.py
```

**Sample output:**

```
🔍 Detecting Windows compatibility issues...
💡 This tool will provide suggestions for cross-platform alternatives.

Test results:
>> Issue: [PTB001:os_windows_incompatible_functions] Windows-incompatible function: os.getuid()
   Severity: Medium   Confidence: High
   Location: script.py:15
   More Info: https://bandit.readthedocs.io/en/latest/
   💡 Suggestion: Replace with getpass.getuser() - Works on Windows, Linux, and macOS.
```

### Example 2: Check Entire Project

```bash
pycc detect -r ./myproject
```

### Example 3: CI/CD Integration

```bash
# Generate JSON report for automated processing
pycrosscheck detect -r . --format json > compatibility_report.json
```

### Example 4: Using with Bandit Directly

Since PyCrossCheck is a Bandit plugin, you can also use it with Bandit:

```bash
bandit -r myproject/ -t PTB001
```

## 📋 Compatibility Rules Categories

PyCrossCheck includes 56+ rules organized into 10 categories:

| Category | Description                 | Rules    |
| -------- | --------------------------- | -------- |
| **02**   | Process Management          | 14 rules |
| **03**   | User and Group Management   | 11 rules |
| **04**   | File System Operations      | 11 rules |
| **05**   | Signal Handling             | 5 rules  |
| **06**   | Inter-Process Communication | 3 rules  |
| **07**   | System Information          | 4 rules  |
| **08**   | Terminal Control            | 1 rule   |
| **09**   | Device-Specific Operations  | 4 rules  |
| **10**   | Priority and Scheduling     | 3 rules  |

## Examples of Detected Issues

### User Management Functions

**Problematic code:**

```python
import os

# Will fail on Windows
user_id = os.getuid()
effective_user = os.geteuid()
```

**✅ PyCrossCheck suggestion:**

```
💡 Replace with getpass.getuser() - Works on Windows, Linux, and macOS.
   Import: 'import getpass'
```

**Fixed code:**

```python
import getpass

# Cross-platform solution
username = getpass.getuser()
```

### ❌ System Information

**Problematic code:**

```python
import os

# Will fail on Windows
system_info = os.uname()
```

**PyCrossCheck suggestion:**

```
💡 Replace with platform.uname() for cross-platform system information.
   Import: 'import platform'
```

**Fixed code:**

```python
import platform

# Cross-platform solution
system_info = platform.uname()
```

### ❌ Process Management

**Problematic code:**

```python
import os

# Will fail on Windows
pid = os.fork()
```

**PyCrossCheck suggestion:**

```
💡 Replace with multiprocessing.Process() for cross-platform process creation.
   Import: 'from multiprocessing import Process'
```

**Fixed code:**

```python
from multiprocessing import Process

def worker():
    # Your code here
    pass

# Cross-platform solution
process = Process(target=worker)
process.start()
```

## 🛡️ CI/CD Integration

### GitHub Actions Example

```yaml
name: Compatibility Check

on: [push, pull_request]

jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: "3.9"
      - name: Install PyCrossCheck
        run: pip install pycrosscheck
      - name: Run compatibility check
        run: pycrosscheck detect -r . --format json
```

### Pre-commit Hook

Add to `.pre-commit-config.yaml`:

```yaml
repos:
  - repo: local
    hooks:
      - id: pycrosscheck
        name: PyCrossCheck
        entry: pycrosscheck detect
        language: system
        types: [python]
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the BSD 2-Clause License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Built on top of [Bandit](https://github.com/PyCQA/bandit) security analysis tool
- Inspired by the need for better cross-platform Python code

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/pycrosscheck/issues)
- **Documentation**: [GitHub README](https://github.com/yourusername/pycrosscheck#readme)

---

Made with ❤️ for the Python community
