from setuptools import setup, find_packages

setup(
    name='platform-compatibility',
    version='1.0.0',
    description='Platform compatibility checker and fixer for Python code',
    author='Denini Gabriel',
    packages=find_packages(),
    entry_points={
        'bandit.plugins': [
            'PTB001 = my_bandit_plugin.my_bandit_plugin:os_windows_incompatible_functions',
        ],
        'console_scripts': [
            'platform-compat = platform_compatibility.main:main',
            'platcompat = platform_compatibility.main:main',
        ],
    },
    install_requires=[
        'bandit>=1.7.0',
        'astor>=0.8.0',  # For Python code generation fallback
    ],
    python_requires='>=3.7',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Topic :: Software Development :: Quality Assurance',
        'Topic :: Software Development :: Testing',
    ],
)
