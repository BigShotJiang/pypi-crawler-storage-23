#!/usr/bin/env python3
"""
Process Management - Process management functions with Windows limitations
Category 02: PTB02xxx
"""

from .base import CompatibilityRule, RuleCategories

#!/usr/bin/env python3
"""
Process Management Rules - Category 02
Functions related to process creation, waiting, and management.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# Process Management Rules (Category 02)
PROCESS_RULES = {
    "os.fork": CompatibilityRule(
        function_name="os.fork",
        bandit_message="[PROC] os.fork \u2014 use subprocess.Popen portable API",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "unix-only", "subprocess"],
        suggestion="Replace with subprocess.Popen() for cross-platform process creation. Use subprocess module instead of fork() - requires restructuring to pass logic to a separate script or function.",
        severity="HIGH"
    ),
    
    "os.forkpty": CompatibilityRule(
        function_name="os.forkpty",
        bandit_message="[PROC] os.forkpty \u2014 use subprocess.Popen portable API",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "unix-only", "subprocess", "pty"],
        suggestion="Replace with subprocess.Popen() for cross-platform process creation. PTY functionality is Unix-specific - consider using subprocess without PTY or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="HIGH"
    ),

    "os.wait": CompatibilityRule(
        function_name="os.wait",
        bandit_message="Use subprocess.wait() for cross-platform compatibility",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "wait", "subprocess"],
        suggestion="Replace with subprocess.wait() method. Use subprocess.Popen() to create process, then call .wait() on the process object for cross-platform compatibility.",
        severity="MEDIUM"
    ),

    "os.waitpid": CompatibilityRule(
        function_name="os.waitpid",
        bandit_message="Use subprocess.wait() for cross-platform compatibility",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "wait", "subprocess"],
        suggestion="Replace with subprocess.wait() method. Track subprocess objects instead of PIDs, then call .wait() on the process object for cross-platform compatibility.",
        severity="MEDIUM"
    ),

    "os.wait3": CompatibilityRule(
        function_name="os.wait3",
        bandit_message="Use subprocess.wait() for cross-platform compatibility",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "wait", "subprocess", "unix-only"],
        suggestion="Replace with subprocess.wait() method. Resource usage information is not available cross-platform - use subprocess.wait() for basic process waiting or psutil library for resource monitoring.",
        severity="MEDIUM"
    ),

    "os.wait4": CompatibilityRule(
        function_name="os.wait4",
        bandit_message="Use subprocess.wait() for cross-platform compatibility",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "wait", "subprocess", "unix-only"],
        suggestion="Replace with subprocess.wait() method. Resource usage information is not available cross-platform - use subprocess.wait() for basic process waiting or psutil library for resource monitoring.",
        severity="MEDIUM"
    ),

    "os.WIFEXITED": CompatibilityRule(
        function_name="os.WIFEXITED",
        bandit_message="Use subprocess return codes for cross-platform compatibility",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "wait", "returncode", "unix-only"],
        suggestion="Replace with subprocess returncode check. Use 'process.returncode is not None' to check if process exited normally (cross-platform alternative).",
        severity="MEDIUM"
    ),

    "os.WEXITSTATUS": CompatibilityRule(
        function_name="os.WEXITSTATUS",
        bandit_message="Use subprocess return codes for cross-platform compatibility",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "wait", "returncode", "unix-only"],
        suggestion="Replace with subprocess returncode. Use 'process.returncode' directly to get the exit status (cross-platform alternative).",
        severity="MEDIUM"
    ),

    "os.getpgid": CompatibilityRule(
        function_name="os.getpgid",
        bandit_message="Use os.getpid() or alternative for Windows compatibility",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "group", "unix-only"],
        suggestion="Windows doesn't support process groups. Use os.getpid() for basic process identification, or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="LOW"
    ),

    "os.setpgid": CompatibilityRule(
        function_name="os.setpgid",
        bandit_message="Process groups work differently on Windows",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "group", "unix-only"],
        suggestion="Windows doesn't support process groups. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),

    "os.getpgrp": CompatibilityRule(
        function_name="os.getpgrp",
        bandit_message="Process groups work differently on Windows",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "group", "unix-only"],
        suggestion="Windows doesn't support process groups. Use os.getpid() for basic process identification, or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="LOW"
    ),

    "os.setpgrp": CompatibilityRule(
        function_name="os.setpgrp",
        bandit_message="Process groups work differently on Windows",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "group", "unix-only"],
        suggestion="Windows doesn't support process groups. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),

    "os.getsid": CompatibilityRule(
        function_name="os.getsid",
        bandit_message="Sessions work differently on Windows",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "session", "unix-only"],
        suggestion="Windows doesn't support sessions. Use os.getpid() for basic process identification, or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="LOW"
    ),

    "os.setsid": CompatibilityRule(
        function_name="os.setsid",
        bandit_message="Sessions work differently on Windows",
        category=RuleCategories.PROCESS_MGMT,
        tags=["process", "session", "unix-only"],
        suggestion="Windows doesn't support sessions. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),
}
