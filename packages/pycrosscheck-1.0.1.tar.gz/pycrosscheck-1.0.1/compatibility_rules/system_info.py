#!/usr/bin/env python3
"""
System Information Rules - Category 07
Functions related to system information and configuration.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# System Information Rules (Category 07)
SYSTEM_INFO_RULES = {
    "os.uname": CompatibilityRule(
        function_name="os.uname",
        bandit_message="Use platform.uname() or sys.platform for cross-platform system info",
        category=RuleCategories.SYSTEM_INFO,
        tags=["system", "platform"],
        suggestion="Replace with platform.uname() for cross-platform system information. Import platform module. Returns similar information but works on all platforms.",
        severity="MEDIUM"
    ),

    "os.getloadavg": CompatibilityRule(
        function_name="os.getloadavg",
        bandit_message="Load average not available on Windows, use psutil.cpu_percent()",
        category=RuleCategories.SYSTEM_INFO,
        tags=["load", "performance", "unix-only"],
        suggestion="Replace with psutil.cpu_percent() for cross-platform performance monitoring. Import psutil library (pip install psutil). Provides CPU usage percentage instead of load average.",
        severity="MEDIUM"
    ),

    "os.confstr": CompatibilityRule(
        function_name="os.confstr",
        bandit_message="Configuration strings not available on Windows",
        category=RuleCategories.SYSTEM_INFO,
        tags=["configuration", "unix-only"],
        suggestion="Windows doesn't support configuration strings. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),

    "os.sysconf": CompatibilityRule(
        function_name="os.sysconf",
        bandit_message="System configuration not available on Windows",
        category=RuleCategories.SYSTEM_INFO,
        tags=["configuration", "unix-only"],
        suggestion="Windows doesn't support system configuration queries. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),
}
