#!/usr/bin/env python3
"""
File System Rules - Category 04
File system operations with platform differences.
"""

from .base import CompatibilityRule, RuleCategories

# File System Rules (Category 04)
FILE_SYSTEM_RULES = {
    "os.chown": CompatibilityRule(
        function_name="os.chown",
        bandit_message="File ownership works differently on Windows",
        category=RuleCategories.FILE_SYSTEM,
        tags=["ownership", "unix-only"],
        suggestion="Windows doesn't support Unix-style file ownership. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="HIGH"
    ),

    "os.lchown": CompatibilityRule(
        function_name="os.lchown",
        bandit_message="File ownership works differently on Windows",
        category=RuleCategories.FILE_SYSTEM,
        tags=["ownership", "symlink", "unix-only"],
        suggestion="Windows doesn't support Unix-style file ownership on symlinks. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="HIGH"
    ),

    "os.fchown": CompatibilityRule(
        function_name="os.fchown",
        bandit_message="File ownership works differently on Windows",
        category=RuleCategories.FILE_SYSTEM,
        tags=["ownership", "filedescriptor", "unix-only"],
        suggestion="Windows doesn't support Unix-style file ownership. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="HIGH"
    ),

    "os.fchdir": CompatibilityRule(
        function_name="os.fchdir",
        bandit_message="Use os.chdir() with file descriptor alternatives",
        category=RuleCategories.FILE_SYSTEM,
        tags=["directory", "filedescriptor", "unix-only"],
        suggestion="Replace with os.chdir() using path instead of file descriptor. Convert file descriptor to path first for cross-platform compatibility.",
        severity="MEDIUM"
    ),

    "os.fchmod": CompatibilityRule(
        function_name="os.fchmod",
        bandit_message="Use os.chmod() with path instead of file descriptor",
        category=RuleCategories.FILE_SYSTEM,
        tags=["permissions", "filedescriptor", "unix-only"],
        suggestion="Replace with os.chmod() using path instead of file descriptor. Convert file descriptor to path first for cross-platform compatibility.",
        severity="MEDIUM"
    ),

    "os.link": CompatibilityRule(
        function_name="os.link",
        bandit_message="[FILE] Symlinks — use pathlib or environment handling",
        category=RuleCategories.FILE_SYSTEM,
        tags=["hardlink", "unix-only"],
        suggestion="Replace with shutil.copy2() for Windows compatibility. Hard links are not reliably supported on Windows - use file copying instead. Import shutil module.",
        severity="MEDIUM"
    ),

    "os.symlink": CompatibilityRule(
        function_name="os.symlink",
        bandit_message="[FILE] Admin privileges — detect Windows permissions",
        category=RuleCategories.FILE_SYSTEM,
        tags=["symlink", "privilege"],
        suggestion="Requires administrator privileges on older Windows versions. Ensure your application handles permission errors gracefully or document the requirement.",
        severity="LOW"
    ),

    "os.readlink": CompatibilityRule(
        function_name="os.readlink",
        bandit_message="Symlink handling differs on Windows",
        category=RuleCategories.FILE_SYSTEM,
        tags=["symlink", "windows-different"],
        suggestion="Symlink behavior may differ on Windows. Test thoroughly on Windows platform and handle potential exceptions. Function works but has platform-specific differences.",
        severity="LOW"
    ),

    "os.lockf": CompatibilityRule(
        function_name="os.lockf",
        bandit_message="Use fcntl module replacement or file locking library",
        category=RuleCategories.FILE_SYSTEM,
        tags=["locking", "unix-only"],
        suggestion="Replace with msvcrt.locking() on Windows or use the filelock library for cross-platform file locking. Import msvcrt module for Windows.",
        severity="HIGH"
    ),

    "os.pathconf": CompatibilityRule(
        function_name="os.pathconf",
        bandit_message="Path configuration not available on Windows",
        category=RuleCategories.FILE_SYSTEM,
        tags=["configuration", "unix-only"],
        suggestion="Windows doesn't support path configuration queries. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),

    "os.fpathconf": CompatibilityRule(
        function_name="os.fpathconf",
        bandit_message="Path configuration not available on Windows",
        category=RuleCategories.FILE_SYSTEM,
        tags=["configuration", "filedescriptor", "unix-only"],
        suggestion="Windows doesn't support path configuration queries. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),
}
