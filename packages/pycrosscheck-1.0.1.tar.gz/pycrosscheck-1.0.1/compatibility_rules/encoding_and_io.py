#!/usr/bin/env python3
"""
Encoding and I/O Rules - Category 11
Functions related to file encoding and I/O operations with platform differences.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# We'll use category 11 for encoding and I/O
class EncodingIOCategories:
    ENCODING_IO = "11"  # File encoding and I/O patterns

# Encoding and I/O Rules (Category 11)
ENCODING_IO_RULES = {
    "open_without_encoding": CompatibilityRule(
        function_name="open",
        bandit_message="[FILE] Encoding — set explicit UTF-8 encoding in open()",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["encoding", "file-io", "utf-8"],
        suggestion="Specify encoding='utf-8' explicitly when opening text files to ensure consistent behavior across platforms. Windows uses different default encoding (cp1252) than Unix (utf-8). Example: open(filename, 'r', encoding='utf-8')",
        severity="LOW"
    ),

    "os.rename_without_close": CompatibilityRule(
        function_name="os.rename",
        bandit_message="[FILE] File locking — use context managers with explicit close",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["file-io", "windows", "rename"],
        suggestion="On Windows, files must be closed before they can be renamed. Ensure all file handles are closed before calling os.rename(). Use 'with' statement or explicitly close() files. Add platform check if needed: if platform.system() == 'Windows': file.close()",
        severity="MEDIUM"
    ),

    "os.makedirs_pattern": CompatibilityRule(
        function_name="os.makedirs",
        bandit_message="[FILE] Directory creation — use os.makedirs with exist_ok=True",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["file-io", "directory", "best-practice"],
        suggestion="Use os.makedirs(path, exist_ok=True) to avoid errors if directory already exists. This is more robust and cross-platform than checking with os.path.exists() first. Requires Python 3.2+",
        severity="LOW"
    ),

    "tempfile.NamedTemporaryFile_delete": CompatibilityRule(
        function_name="tempfile.NamedTemporaryFile",
        bandit_message="[FILE] Temp files — use delete=False for Windows compatibility",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["file-io", "tempfile", "windows", "best-practice"],
        suggestion="""On Windows, NamedTemporaryFile cannot be opened by other processes while still open. Use delete=False and manual cleanup:

with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
    f.write(data)
    f.flush()
    temp_path = f.name
# File is now closed and can be accessed
try:
    # Use temp_path here
    process_file(temp_path)
finally:
    os.remove(temp_path)  # Manual cleanup

This pattern works on all platforms.""",
        severity="MEDIUM"
    ),

    "file_permissions_testing": CompatibilityRule(
        function_name="os.stat",
        bandit_message="[FILE] Permissions — use os.access() instead of permission bits",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["file-io", "permissions", "windows", "testing"],
        suggestion="""Unix permission bits (e.g., oct(st_mode)[-3:]) don't work on Windows. Use platform-specific checks:

if os.name == 'nt':
    # Windows: check access flags
    assert os.access(path, os.R_OK)  # readable
    assert os.access(path, os.W_OK)  # writable
    assert os.access(path, os.X_OK)  # executable
else:
    # Unix: check permission bits
    assert oct(os.stat(path).st_mode)[-3:] == '700'

This is especially important in test code.""",
        severity="MEDIUM"
    ),

    "shutil.rmtree_without_close": CompatibilityRule(
        function_name="shutil.rmtree",
        bandit_message="[FILE] File removal — use context managers before shutil.rmtree()",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["file-io", "windows", "cleanup", "file-handles"],
        suggestion="""On Windows, shutil.rmtree() fails if any files in the directory tree have open handles. Close all file handles before calling rmtree():

# Close all file handles first
if hasattr(archive, 'compressor'):
    archive.compressor.close()
if hasattr(archive, 'fh'):
    archive.fh.close()

# Now safe to remove directory
shutil.rmtree(directory_path)

This is especially important in test cleanup and context managers. Consider using 'with' statements to ensure handles are closed.""",
        severity="MEDIUM"
    ),

    "shutil_which_for_executables": CompatibilityRule(
        function_name="shutil.which",
        bandit_message="[PROC] Executables — use shutil.which() for portable API",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["subprocess", "executables", "path", "cross-platform"],
        suggestion="""Use shutil.which() to locate executables in PATH instead of hardcoding paths. This works across all platforms:

# Bad: hardcoded executable name
subprocess.run(["node", "script.js"])
subprocess.run(["npm", "install"])

# Good: use shutil.which()
node_cmd = shutil.which("node")
npm_cmd = shutil.which("npm")
if node_cmd is None:
    raise RuntimeError("node command not found")
subprocess.run([node_cmd, "script.js"])
subprocess.run([npm_cmd, "install"])

On Windows, executables may have .exe extension and be in different locations. shutil.which() handles this automatically.""",
        severity="LOW"
    ),

    "os_relpath_cross_drive": CompatibilityRule(
        function_name="os.path.relpath",
        bandit_message="[FILE] Relative paths — use pathlib for drive-aware paths",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["path", "windows", "cross-drive", "file-io"],
        suggestion="""On Windows, os.path.relpath() raises ValueError if paths are on different drives (e.g., C:\ and D:\). Add a check:

import pathlib

# Check if paths are on same drive (Windows)
if os.name == 'nt':
    cwd = pathlib.Path.cwd()
    if absolute_path.anchor != cwd.anchor:
        # Can't create relative path across drives on Windows
        return absolute_path  # Use absolute path instead

# Safe to use relpath
relative_path = pathlib.Path(os.path.relpath(absolute_path, os.getcwd()))

Or use pathlib.Path.relative_to() with try/except to handle the error gracefully.""",
        severity="MEDIUM"
    ),

    "sys_executable_for_python": CompatibilityRule(
        function_name="sys.executable",
        bandit_message="[PROC] Python executable — use sys.executable in subprocess",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["subprocess", "python", "cross-platform", "testing"],
        suggestion="""Use sys.executable to invoke the current Python interpreter instead of hardcoding 'python', 'python3', etc. This ensures you use the same Python that's running the script:

import sys
import subprocess

# Bad: hardcoded Python command
subprocess.run("python3 script.py", shell=True)
subprocess.run(["python", "script.py"])

# Good: use sys.executable
subprocess.run(f"{sys.executable} script.py", shell=True)
subprocess.run([sys.executable, "script.py"])

This is especially important for:
- Virtual environments (python vs python3 vs python3.9)
- CI/CD systems with different Python paths
- Cross-platform testing (Windows python.exe vs Unix python)""",
        severity="LOW"
    ),

    "line_ending_normalization": CompatibilityRule(
        function_name="str.replace",
        bandit_message="[FILE] Line endings — normalize with explicit newline handling",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["line-endings", "testing", "windows", "output-comparison"],
        suggestion="""Windows uses CRLF (\\r\\n) while Unix uses LF (\\n) for line endings. When comparing subprocess output or file content across platforms, normalize line endings:

# Bad: direct comparison fails on Windows
output = subprocess.run(..., capture_output=True).stdout.decode("utf-8")
assert output == "expected\\n"  # Fails on Windows (\\r\\n)

# Good: normalize before comparison
output = subprocess.run(..., capture_output=True).stdout.decode("utf-8")
normalized = output.replace('\\r\\n', '\\n')  # Windows -> Unix
assert normalized == "expected\\n"  # Works on all platforms

Or use universal_newlines=True in subprocess.run() which handles this automatically.

This is especially important in test assertions comparing command output.""",
        severity="LOW"
    ),

    "case_sensitive_path_pattern": CompatibilityRule(
        function_name="os.path",
        bandit_message="[FILE] Case sensitivity — use pathlib.Path for case-normalization",
        category=EncodingIOCategories.ENCODING_IO,
        tags=["path", "case-sensitivity", "filesystem", "macos", "windows"],
        suggestion="""Filesystem case sensitivity varies:
- Linux: ALWAYS case-sensitive (File.txt ≠ file.txt)
- Windows: ALWAYS case-insensitive (File.txt = file.txt)
- macOS: Usually case-insensitive-but-preserving by default (but case-sensitive possible)

⚠️  AVOID FALSE POSITIVES:
This pattern is HARD to flag automatically. DO NOT flag:
- os.path.exists('filename') - this is fine, searches use filesystem's model
- os.path.join() - path joining is fine
- String comparisons like 'FILE' == 'file' - business logic
- Config key comparisons - application logic

ONLY flag if you see EXPLICIT case manipulation for path comparison:
```python
# Bad: assumes case matters
path = 'MyFile.txt'
if path.lower() == existing_path.lower():  # Works on Windows, breaks on Linux!
    # This comparison is filesystem-unsafe
```

Instead:
```python
# Use pathlib for robust comparison
import pathlib
if pathlib.Path(path).resolve() == pathlib.Path(existing_path).resolve():
    # More reliable, not perfect but better

# Or use os.path.samefile (best - checks actual inode)
if os.path.samefile(path, existing_path):
    # Most reliable - checks actual filesystem
```

This is subtle! Only flag EXPLICIT assumptions about case.""",
        severity="LOW"
    ),
}
