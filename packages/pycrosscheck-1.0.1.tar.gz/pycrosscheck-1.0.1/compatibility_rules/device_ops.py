#!/usr/bin/env python3
"""
Device Operations Rules - Category 09
Functions related to device-specific operations not available on Windows.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# Device Operations Rules (Category 09)
DEVICE_RULES = {
    "os.mknod": CompatibilityRule(
        function_name="os.mknod",
        bandit_message="Device node creation not supported on Windows",
        category=RuleCategories.DEVICE_OPS,
        tags=["device", "node", "unix-only"],
        suggestion="Windows doesn't support device node creation. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="HIGH"
    ),

    "os.major": CompatibilityRule(
        function_name="os.major",
        bandit_message="Device numbers not used on Windows",
        category=RuleCategories.DEVICE_OPS,
        tags=["device", "number", "unix-only"],
        suggestion="Windows doesn't use device numbers. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),

    "os.minor": CompatibilityRule(
        function_name="os.minor",
        bandit_message="Device numbers not used on Windows",
        category=RuleCategories.DEVICE_OPS,
        tags=["device", "number", "unix-only"],
        suggestion="Windows doesn't use device numbers. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),

    "os.makedev": CompatibilityRule(
        function_name="os.makedev",
        bandit_message="Device numbers not used on Windows",
        category=RuleCategories.DEVICE_OPS,
        tags=["device", "number", "unix-only"],
        suggestion="Windows doesn't use device numbers. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),
}
