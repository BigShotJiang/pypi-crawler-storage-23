#!/usr/bin/env python3
"""
User Management Rules - Category 03
Functions related to user and group identification and management.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# User Management Rules (Category 03)
USER_RULES = {
    "os.getuid": CompatibilityRule(
        function_name="os.getuid",
        bandit_message="Use getpass.getuser() for cross-platform user identification",
        category=RuleCategories.USER_MGMT,
        tags=["user", "unix-only", "getpass"],
        suggestion="Replace with getpass.getuser() - Works on Windows, Linux, and macOS. Import: 'import getpass'",
        severity="MEDIUM"
    ),

    "os.geteuid": CompatibilityRule(
        function_name="os.geteuid",
        bandit_message="Use getpass.getuser() for cross-platform user identification",
        category=RuleCategories.USER_MGMT,
        tags=["user", "unix-only", "getpass"],
        suggestion="Replace with getpass.getuser() - Works on Windows, Linux, and macOS. Import: 'import getpass'",
        severity="MEDIUM"
    ),

    "os.getgid": CompatibilityRule(
        function_name="os.getgid",
        bandit_message="Windows does not have group IDs, consider alternative approach",
        category=RuleCategories.USER_MGMT,
        tags=["group", "unix-only"],
        suggestion="Windows doesn't support group IDs. Consider using access control lists (ACLs) via the 'win32security' module or rethink the permission model.",
        severity="HIGH"
    ),

    "os.getegid": CompatibilityRule(
        function_name="os.getegid",
        bandit_message="Windows does not have group IDs, consider alternative approach",
        category=RuleCategories.USER_MGMT,
        tags=["group", "unix-only"],
        suggestion="Windows doesn't support group IDs. Consider using access control lists (ACLs) via the 'win32security' module or rethink the permission model.",
        severity="HIGH"
    ),

    "os.getgroups": CompatibilityRule(
        function_name="os.getgroups",
        bandit_message="Windows does not have group IDs, consider alternative approach",
        category=RuleCategories.USER_MGMT,
        tags=["group", "unix-only"],
        suggestion="Windows doesn't support group IDs. Consider using Windows groups API via 'win32net' module from pywin32, or remove group-based logic.",
        severity="HIGH"
    ),

    "os.setuid": CompatibilityRule(
        function_name="os.setuid",
        bandit_message="Windows does not support changing user ID",
        category=RuleCategories.USER_MGMT,
        tags=["user", "unix-only", "privilege"],
        suggestion="Windows doesn't support setuid. Consider using 'runas' command via subprocess for privilege escalation, or redesign without user switching.",
        severity="HIGH"
    ),

    "os.seteuid": CompatibilityRule(
        function_name="os.seteuid",
        bandit_message="Windows does not support changing user ID",
        category=RuleCategories.USER_MGMT,
        tags=["user", "unix-only", "privilege"],
        suggestion="Windows doesn't support seteuid. Consider using 'runas' command via subprocess for privilege escalation, or redesign without user switching.",
        severity="HIGH"
    ),

    "os.setgid": CompatibilityRule(
        function_name="os.setgid",
        bandit_message="Windows does not support changing group ID",
        category=RuleCategories.USER_MGMT,
        tags=["group", "unix-only", "privilege"],
        suggestion="Windows doesn't support setgid. Consider using access control lists (ACLs) or redesign without group switching.",
        severity="HIGH"
    ),

    "os.setegid": CompatibilityRule(
        function_name="os.setegid",
        bandit_message="Windows does not support changing group ID",
        category=RuleCategories.USER_MGMT,
        tags=["group", "unix-only", "privilege"],
        suggestion="Windows doesn't support setegid. Consider using access control lists (ACLs) or redesign without group switching.",
        severity="HIGH"
    ),

    "os.setgroups": CompatibilityRule(
        function_name="os.setgroups",
        bandit_message="Windows does not support changing group ID",
        category=RuleCategories.USER_MGMT,
        tags=["group", "unix-only", "privilege"],
        suggestion="Windows doesn't support setgroups. Consider using access control lists (ACLs) or redesign without group management.",
        severity="HIGH"
    ),

    "os.getlogin": CompatibilityRule(
        function_name="os.getlogin",
        bandit_message="Use getpass.getuser() for cross-platform user identification",
        category=RuleCategories.USER_MGMT,
        tags=["user", "login", "getpass"],
        suggestion="Replace with getpass.getuser() - More reliable across platforms. Import: 'import getpass'",
        severity="LOW"
    ),
}
