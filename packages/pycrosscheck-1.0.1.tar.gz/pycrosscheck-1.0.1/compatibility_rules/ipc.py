#!/usr/bin/env python3
"""
Inter-Process Communication Rules - Category 06
Functions related to IPC mechanisms with platform differences.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# IPC Rules (Category 06)
IPC_RULES = {
    "os.pipe": CompatibilityRule(
        function_name="os.pipe",
        bandit_message="Consider using subprocess.PIPE for cross-platform pipes",
        category=RuleCategories.IPC,
        tags=["pipe", "ipc"],
        suggestion="Replace with subprocess.PIPE for cross-platform pipes. Use subprocess.Popen() with stdin/stdout/stderr=subprocess.PIPE for process communication. Import subprocess module.",
        severity="MEDIUM"
    ),

    "os.mkfifo": CompatibilityRule(
        function_name="os.mkfifo",
        bandit_message="Named pipes work differently on Windows, use threading.Queue or multiprocessing.Queue",
        category=RuleCategories.IPC,
        tags=["namedpipe", "fifo", "unix-only"],
        suggestion="Replace with multiprocessing.Queue() or threading.Queue() for cross-platform IPC. Named pipes are Unix-specific - use queue-based communication instead. Import multiprocessing or threading module.",
        severity="HIGH"
    ),

    "os.openpty": CompatibilityRule(
        function_name="os.openpty",
        bandit_message="Pseudo-terminals work differently on Windows",
        category=RuleCategories.IPC,
        tags=["pty", "terminal", "unix-only"],
        suggestion="Replace with subprocess.Popen() for cross-platform process communication. PTY functionality is Unix-specific - use subprocess stdin/stdout/stderr instead. Import subprocess module.",
        severity="HIGH"
    ),
}
