#!/usr/bin/env python3
"""
Platform Detection Patterns - Category 12
Best practices and patterns for detecting and handling platform differences.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# We'll use category 12 for platform detection patterns
class PlatformDetectionCategories:
    PLATFORM_DETECTION = "12"  # Platform detection and conditional code patterns

# Platform Detection Pattern Rules (Category 12)
PLATFORM_DETECTION_RULES = {
    "hasattr_os_pattern": CompatibilityRule(
        function_name="hasattr",
        bandit_message="Recommended pattern: Use hasattr(os, 'function_name') to check Unix function availability",
        category=PlatformDetectionCategories.PLATFORM_DETECTION,
        tags=["platform-detection", "best-practice", "unix-functions"],
        suggestion="Before using Unix-specific os functions, check availability with hasattr(os, 'function_name'). Example: if hasattr(os, 'getuid') and os.getuid() == 0: ... This is more Pythonic than platform string comparison.",
        severity="LOW"
    ),

    "root_admin_detection_pattern": CompatibilityRule(
        function_name="os.geteuid",
        bandit_message="Recommended cross-platform pattern for detecting root/admin privileges",
        category=PlatformDetectionCategories.PLATFORM_DETECTION,
        tags=["platform-detection", "privilege", "root", "admin"],
        suggestion="""Create a cross-platform helper function to detect root/admin:

def is_root_or_admin():
    import platform
    if platform.system() == 'Windows':
        import ctypes
        try:
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        except:
            return False
    else:
        import os
        return os.geteuid() == 0

Replace direct os.geteuid() == 0 or os.getuid() == 0 checks with this function.""",
        severity="MEDIUM"
    ),

    "tempfile_gettempdir_pattern": CompatibilityRule(
        function_name="tempfile.gettempdir",
        bandit_message="Use tempfile.gettempdir() instead of hardcoded /tmp or /var paths",
        category=PlatformDetectionCategories.PLATFORM_DETECTION,
        tags=["file-io", "temporary-files", "cross-platform"],
        suggestion="Replace hardcoded temporary directories like '/tmp' with tempfile.gettempdir() for cross-platform compatibility. Import tempfile module. On Windows returns %TEMP%, on Unix returns /tmp or $TMPDIR.",
        severity="MEDIUM"
    ),

    "os_name_posix_pattern": CompatibilityRule(
        function_name="os.name",
        bandit_message="Use os.name == 'posix' to detect Unix-like systems (Linux, macOS, BSD)",
        category=PlatformDetectionCategories.PLATFORM_DETECTION,
        tags=["platform-detection", "posix", "unix"],
        suggestion="Use os.name == 'posix' to detect Unix-like systems (includes Linux, macOS, BSD). Use os.name == 'nt' for Windows. For more specific detection, use platform.system() which returns 'Linux', 'Darwin' (macOS), 'Windows', etc.",
        severity="LOW"
    ),

    "platform_system_darwin": CompatibilityRule(
        function_name="platform.system",
        bandit_message="Use platform.system() == 'Darwin' to detect macOS specifically",
        category=PlatformDetectionCategories.PLATFORM_DETECTION,
        tags=["platform-detection", "macos", "darwin"],
        suggestion="Use platform.system() == 'Darwin' to detect macOS. Common return values: 'Windows', 'Linux', 'Darwin' (macOS), 'Java'. More specific than sys.platform. Import platform module.",
        severity="LOW"
    ),

    "attributeerror_exception_pattern": CompatibilityRule(
        function_name="AttributeError",
        bandit_message="Use try/except AttributeError to handle Unix-specific function calls gracefully",
        category=PlatformDetectionCategories.PLATFORM_DETECTION,
        tags=["exception-handling", "unix-functions", "cross-platform"],
        suggestion="""Use try/except AttributeError pattern for Unix-specific functions:

try:
    uid = os.getuid()
    # Unix-specific code
except AttributeError:
    # Windows fallback or alternative logic
    uid = None

This is cleaner than checking hasattr for inline conditional code.""",
        severity="LOW"
    ),

    "xdg_runtime_dir_pattern": CompatibilityRule(
        function_name="XDG_RUNTIME_DIR",
        bandit_message="Handle XDG_RUNTIME_DIR with cross-platform fallbacks",
        category=PlatformDetectionCategories.PLATFORM_DETECTION,
        tags=["environment", "xdg", "runtime-dir", "cross-platform"],
        suggestion="""When using XDG_RUNTIME_DIR, provide cross-platform fallbacks:

import os
import tempfile
import getpass

xdg_runtime = os.environ.get('XDG_RUNTIME_DIR')
if not xdg_runtime or not os.path.isdir(xdg_runtime):
    # Cross-platform fallback
    xdg_runtime = os.path.join(tempfile.gettempdir(), f"{getpass.getuser()}_runtime")
    os.makedirs(xdg_runtime, exist_ok=True)

XDG_RUNTIME_DIR is Linux-specific and won't exist on Windows/macOS.""",
        severity="MEDIUM"
    ),

    "windows_path_separator": CompatibilityRule(
        function_name="os.path.join",
        bandit_message="Always use os.path.join() instead of hardcoded path separators",
        category=PlatformDetectionCategories.PLATFORM_DETECTION,
        tags=["file-path", "path-separator", "cross-platform"],
        suggestion="Use os.path.join() to build file paths instead of hardcoding '/' or '\\\\'. Example: os.path.join(dir, 'subdir', 'file.txt'). Also consider using pathlib.Path for modern Python code.",
        severity="MEDIUM"
    ),
}
