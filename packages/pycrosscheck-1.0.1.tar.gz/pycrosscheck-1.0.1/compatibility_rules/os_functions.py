#!/usr/bin/env python3
"""
OS Functions - Unix-specific functions not available on Windows
Category 01: PTB01xxx
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# Category 01: Unix-specific OS functions
OS_RULES = {
    'os.uname': CompatibilityRule(
        function_name='os.uname',
        bandit_message='Use platform.uname() or sys.platform for cross-platform system info',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['system-info', 'platform-detection'],
        suggestion='Replace with platform module functions for cross-platform compatibility:\n\n- For full system info: platform.uname()\n- For machine architecture: platform.machine()  # os.uname().machine\n- For OS name: platform.system()  # os.uname().sysname\n- For OS release: platform.release()  # os.uname().release\n\nExample: platform = f"linux/{os.uname().machine}" → platform = f"linux/{platform.machine().lower()}"',
        severity='MEDIUM'
    ),
    
    'os.system': CompatibilityRule(
        function_name='os.system',
        bandit_message='os.system() may behave differently on Windows - use subprocess.run() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['shell-execution', 'command-execution'],
        suggestion='Replace with subprocess.run(command, shell=True) for better cross-platform compatibility. Import subprocess module. Provides better control and error handling.',
        severity='MEDIUM'
    ),
    
    'os.popen': CompatibilityRule(
        function_name='os.popen',
        bandit_message='os.popen() may behave differently on Windows - use subprocess.Popen() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['shell-execution', 'command-execution'],
        suggestion='Replace with subprocess.Popen(command, shell=True, stdout=subprocess.PIPE) for better cross-platform compatibility. Import subprocess module. Provides better control and error handling.',
        severity='MEDIUM'
    ),
    
    'os.spawnl': CompatibilityRule(
        function_name='os.spawnl',
        bandit_message='os.spawnl() behaves differently on Windows - use subprocess.run() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['process-spawning', 'command-execution'],
        suggestion='Replace with subprocess.run([program, *args]) for cross-platform compatibility. Import subprocess module. Use list of arguments instead of separate parameters.',
        severity='MEDIUM'
    ),
    
    'os.spawnle': CompatibilityRule(
        function_name='os.spawnle',
        bandit_message='os.spawnle() behaves differently on Windows - use subprocess.run() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['process-spawning', 'command-execution'],
        suggestion='Replace with subprocess.run([program, *args], env=env) for cross-platform compatibility. Import subprocess module. Pass environment as env parameter.',
        severity='MEDIUM'
    ),
    
    'os.spawnlp': CompatibilityRule(
        function_name='os.spawnlp',
        bandit_message='os.spawnlp() behaves differently on Windows - use subprocess.run() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['process-spawning', 'command-execution'],
        suggestion='Replace with subprocess.run([program, *args]) for cross-platform compatibility. Import subprocess module. Subprocess automatically searches PATH.',
        severity='MEDIUM'
    ),
    
    'os.spawnlpe': CompatibilityRule(
        function_name='os.spawnlpe',
        bandit_message='os.spawnlpe() behaves differently on Windows - use subprocess.run() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['process-spawning', 'command-execution'],
        suggestion='Replace with subprocess.run([program, *args], env=env) for cross-platform compatibility. Import subprocess module. Pass environment as env parameter.',
        severity='MEDIUM'
    ),
    
    'os.spawnv': CompatibilityRule(
        function_name='os.spawnv',
        bandit_message='os.spawnv() behaves differently on Windows - use subprocess.run() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['process-spawning', 'command-execution'],
        suggestion='Replace with subprocess.run(args) for cross-platform compatibility. Import subprocess module. Direct replacement with argument list.',
        severity='MEDIUM'
    ),
    
    'os.spawnve': CompatibilityRule(
        function_name='os.spawnve',
        bandit_message='os.spawnve() behaves differently on Windows - use subprocess.run() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['process-spawning', 'command-execution'],
        suggestion='Replace with subprocess.run(args, env=env) for cross-platform compatibility. Import subprocess module. Pass environment as env parameter.',
        severity='MEDIUM'
    ),
    
    'os.spawnvp': CompatibilityRule(
        function_name='os.spawnvp',
        bandit_message='os.spawnvp() behaves differently on Windows - use subprocess.run() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['process-spawning', 'command-execution'],
        suggestion='Replace with subprocess.run(args) for cross-platform compatibility. Import subprocess module. Subprocess automatically searches PATH.',
        severity='MEDIUM'
    ),
    
    'os.spawnvpe': CompatibilityRule(
        function_name='os.spawnvpe',
        bandit_message='os.spawnvpe() behaves differently on Windows - use subprocess.run() instead',
        category=RuleCategories.OS_FUNCTIONS,
        tags=['process-spawning', 'command-execution'],
        suggestion='Replace with subprocess.run(args, env=env) for cross-platform compatibility. Import subprocess module. Pass environment as env parameter.',
        severity='MEDIUM'
    ),
}
