#!/usr/bin/env python3
"""
Base classes for Windows Compatibility Rules
"""

from typing import Optional, List
from dataclasses import dataclass


@dataclass
class CompatibilityRule:
    """Represents a Windows compatibility rule."""
    function_name: str
    bandit_message: str
    category: str = "general"  # Category tag
    tags: List[str] = None  # Additional tags
    suggestion: str = ""  # Recommendation for cross-platform alternative
    severity: str = "MEDIUM"
    confidence: str = "HIGH"
    
    def __post_init__(self):
        """Initialize tags if not provided."""
        if self.tags is None:
            self.tags = []


# Rule categories with prefixes
class RuleCategories:
    """Standard rule categories with their prefixes."""
    OS_FUNCTIONS = "01"  # Unix-specific OS functions
    PROCESS_MGMT = "02"  # Process management functions  
    USER_MGMT = "03"     # User/Group management functions
    FILE_SYSTEM = "04"   # File system operations
    SIGNALS = "05"       # Signal handling
    IPC = "06"          # Inter-process communication
    SYSTEM_INFO = "07"   # System information and configuration
    TERMINAL = "08"      # Terminal and device operations
    DEVICE_OPS = "09"    # Device operations
    PRIORITY = "10"      # Process priority and nice values
    ENCODING_IO = "11"   # File encoding and I/O operations
    PLATFORM_DETECTION = "12"  # Platform detection patterns
    LIBRARY_DEPS = "13"  # Library dependencies and imports
    PORT_BINDING = "14"  # Port binding and socket reuse
    RESOURCE_LIMITS = "15"  # Resource limits and quotas
    PERM = "16"  # Permissions and privilege-related operations
    
    @classmethod
    def get_all_categories(cls) -> dict:
        """Get all categories with their descriptions."""
        return {
            cls.OS_FUNCTIONS: "Unix-specific OS functions not available on Windows",
            cls.PROCESS_MGMT: "Process management functions with Windows limitations",
            cls.USER_MGMT: "User and group management functions",
            cls.FILE_SYSTEM: "File system operations with platform differences",
            cls.SIGNALS: "Signal handling functions not supported on Windows",
            cls.IPC: "Inter-process communication methods",
            cls.SYSTEM_INFO: "System information and configuration functions",
            cls.TERMINAL: "Terminal and device control operations",
            cls.DEVICE_OPS: "Device-specific operations not available on Windows",
            cls.PRIORITY: "Process priority and scheduling functions",
            cls.ENCODING_IO: "File encoding and I/O operations with platform differences",
            cls.PLATFORM_DETECTION: "Platform detection and cross-platform coding patterns",
            cls.LIBRARY_DEPS: "Library dependencies and platform-specific imports",
            cls.PORT_BINDING: "Port binding and socket reuse with platform-specific behavior",
            cls.RESOURCE_LIMITS: "Resource limits and quotas not available on all platforms",
            cls.PERM: "Permissions and privilege-related operations with platform differences"
        }
    
    @classmethod
    def get_category_name(cls, prefix: str) -> str:
        """Get category description by prefix."""
        categories = cls.get_all_categories()
        return categories.get(prefix, "Unknown category")


def generate_rule_id(category: str, sequence: int) -> str:
    """Generate a standardized rule ID."""
    return f"PTB{category}{sequence:03d}"
