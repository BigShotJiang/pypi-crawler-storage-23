#!/usr/bin/env python3
"""
Signal Handling Rules - Category 05
Functions related to signal handling not supported on Windows.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# Signal Handling Rules (Category 05)
SIGNAL_RULES = {
    "os.WIFSIGNALED": CompatibilityRule(
        function_name="os.WIFSIGNALED",
        bandit_message="Signals work differently on Windows",
        category=RuleCategories.SIGNALS,
        tags=["signal", "wait", "unix-only"],
        suggestion="Windows doesn't support Unix signals. Consider redesigning without signal handling or use platform-specific code with 'if sys.platform != \"win32\"'. For cross-platform process termination, use subprocess methods.",
        severity="HIGH"
    ),

    "os.WTERMSIG": CompatibilityRule(
        function_name="os.WTERMSIG",
        bandit_message="Signals work differently on Windows",
        category=RuleCategories.SIGNALS,
        tags=["signal", "wait", "unix-only"],
        suggestion="Windows doesn't support Unix signals. Consider redesigning without signal handling or use platform-specific code with 'if sys.platform != \"win32\"'. For cross-platform process termination, use subprocess methods.",
        severity="HIGH"
    ),

    "os.WSTOPSIG": CompatibilityRule(
        function_name="os.WSTOPSIG",
        bandit_message="Signals work differently on Windows",
        category=RuleCategories.SIGNALS,
        tags=["signal", "wait", "stop", "unix-only"],
        suggestion="Windows doesn't support Unix signals. Consider redesigning without signal handling or use platform-specific code with 'if sys.platform != \"win32\"'. For cross-platform process control, use subprocess methods.",
        severity="HIGH"
    ),

    "os.WIFSTOPPED": CompatibilityRule(
        function_name="os.WIFSTOPPED",
        bandit_message="Signals work differently on Windows",
        category=RuleCategories.SIGNALS,
        tags=["signal", "wait", "stop", "unix-only"],
        suggestion="Windows doesn't support Unix signals. Consider redesigning without signal handling or use platform-specific code with 'if sys.platform != \"win32\"'. For cross-platform process control, use subprocess methods.",
        severity="HIGH"
    ),

    "os.WIFCONTINUED": CompatibilityRule(
        function_name="os.WIFCONTINUED",
        bandit_message="Signals work differently on Windows",
        category=RuleCategories.SIGNALS,
        tags=["signal", "wait", "continue", "unix-only"],
        suggestion="Windows doesn't support Unix signals. Consider redesigning without signal handling or use platform-specific code with 'if sys.platform != \"win32\"'. For cross-platform process control, use subprocess methods.",
        severity="HIGH"
    ),
}
