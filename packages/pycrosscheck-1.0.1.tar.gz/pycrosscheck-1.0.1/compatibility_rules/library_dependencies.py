#!/usr/bin/env python3
"""
Library Dependencies Rules - Category 13
Functions related to platform-specific and optional library imports.
"""

from .base import CompatibilityRule, RuleCategories

# New category for library dependencies
class LibraryDependenciesCategories:
    LIBRARY_DEPS = "13"  # Library dependencies and imports


# Library Dependencies Rules (Category 13)
LIBRARY_DEPS_RULES = {
    "platform_specific_import_pattern": CompatibilityRule(
        function_name="import",
        bandit_message="[LIB] Platform-specific import — conditional import with fallback",
        category=LibraryDependenciesCategories.LIBRARY_DEPS,
        tags=["import", "unix-only", "dependencies", "platform-specific"],
        suggestion="""Unix-only libraries (fcntl, pwd, grp, spwd, crypt, termios) are not available on Windows. Use try/except to handle gracefully:

# Bad: assumes fcntl is always available
import fcntl
fcntl.flock(file, fcntl.LOCK_EX)

# Good: defensive import
try:
    import fcntl
except ImportError:
    fcntl = None  # Not available on Windows

if fcntl:
    fcntl.flock(file, fcntl.LOCK_EX)
else:
    # Fallback for Windows
    pass

Common platform-specific modules:
- POSIX-only: fcntl, pwd, grp, spwd, crypt, termios, tty, pty, resource
- Windows-only: msvcrt, winreg, winsound
- macOS-specific: Some features of os, platform""",
        severity="MEDIUM"
    ),

    "optional_module_import_pattern": CompatibilityRule(
        function_name="import",
        bandit_message="[LIB] Missing libraries — optional import with fallback",
        category=LibraryDependenciesCategories.LIBRARY_DEPS,
        tags=["import", "optional", "dependencies", "availability"],
        suggestion="""Some standard library modules are optional or not available on all platforms:

# Modules that might not be available:
- readline: Interactive input editing (not on Windows, requires installation on macOS)
- resource: Resource limits (Unix-only)
- curses: Terminal control (Unix-only, Windows has alternatives)
- dbm: Various database backends (implementation varies by platform)

# Correct pattern:
try:
    import readline
except ImportError:
    readline = None

# Then use conditionally:
if readline:
    readline.set_completer(completer_func)
else:
    print("readline not available - limited input editing")

This allows graceful degradation on systems without the module.""",
        severity="MEDIUM"
    ),

    "dynamic_library_extension_pattern": CompatibilityRule(
        function_name="ctypes.CDLL",
        bandit_message="[LIB] Dynamic loading — guard loading, prefer pure-Python",
        category=LibraryDependenciesCategories.LIBRARY_DEPS,
        tags=["ctypes", "dynamic-loading", "dll", "so", "platform-specific"],
        suggestion="""On Windows, shared libraries use .dll extension, on Unix they use .so (or .dylib on macOS). ctypes can handle this with util.find_library():

# Bad: hardcoded extension
lib = ctypes.CDLL('mylib.so')  # Fails on Windows

# Good: use find_library
import ctypes.util
lib_name = ctypes.util.find_library('mylib')
if lib_name:
    lib = ctypes.CDLL(lib_name)  # Works on all platforms
else:
    raise RuntimeError("mylib not found")

# Or platform-specific:
import sys
if sys.platform == 'win32':
    lib = ctypes.CDLL('mylib.dll')
elif sys.platform == 'darwin':
    lib = ctypes.CDLL('mylib.dylib')
else:
    lib = ctypes.CDLL('mylib.so')

find_library() is the preferred approach as it handles system paths correctly.""",
        severity="MEDIUM"
    ),

    "binary_wheel_compat_pattern": CompatibilityRule(
        function_name="import",
        bandit_message="[LIB] Binary wheels — install platform-appropriate wheel",
        category=LibraryDependenciesCategories.LIBRARY_DEPS,
        tags=["import", "wheel", "architecture", "binary"],
        suggestion="""Binary wheels (.whl files) are built for specific Python versions and architectures. Three common issues:

1. Python version mismatch:
   pip install package==1.0 works on Python 3.9
   but NOT on Python 3.11

2. Architecture mismatch:
   Wheels built for x86_64 don't work on ARM
   (Real issue: Python 3.9-3.10 on Apple Silicon needed special handling)

3. Platform mismatch:
   Windows wheels don't work on Linux

Prevention (in setup.py/pyproject.toml):
```toml
[project]
requires-python = ">=3.9"

[tool.bdist-wheel]
universal = false
```

At runtime, validate compatibility:
```python
import sys
import platform

if sys.version_info < (3, 9):
    raise RuntimeError("Python 3.9+ required")

if platform.machine() not in ['x86_64', 'AMD64']:
    print(f"Warning: untested on {platform.machine()}")
```

This prevents 'ImportError: DLL load failed' on binary incompatibilities.""",
        severity="LOW"
    ),
}
