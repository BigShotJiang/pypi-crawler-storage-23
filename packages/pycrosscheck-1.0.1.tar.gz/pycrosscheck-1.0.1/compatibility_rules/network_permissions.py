#!/usr/bin/env python3
"""
Network and Permissions Rules - Completion Regras
- Port reuse patterns
- Resource limits
- Symlink privileges
"""

from .base import CompatibilityRule, RuleCategories

# Port Binding Rules (Category 14)
PORT_BINDING_RULES = {
    "port_reuse_pattern": CompatibilityRule(
        function_name="socket.bind",
        bandit_message="[PROC] Port binding — catch OS-specific errors, use SO_REUSEADDR handling",
        category=RuleCategories.PORT_BINDING,
        tags=["socket", "port", "bind", "reuse", "network", "windows"],
        suggestion="""On Windows, SO_REUSEADDR behavior differs from Unix. The "Address already in use" error requires platform-specific handling:

# Unix: port can be reused quickly after close
import socket
sock = socket.socket()
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind(('', port))

# Windows: SO_REUSEADDR doesn't prevent TIME_WAIT, use SO_EXCLUSIVEADDRUSE instead
import socket
import sys
sock = socket.socket()
if sys.platform == 'win32':
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
else:
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind(('', port))

Or use SO_REUSEADDR on Unix but be aware:
- Unix: Allows bind to port in TIME_WAIT state
- Windows: SO_REUSEADDR ignored, use SO_EXCLUSIVEADDRUSE for exclusivity

This prevents "Address already in use" errors in tests and services.""",
        severity="MEDIUM"
    ),
}

# Resource Limits Rules (Category 15)
RESOURCE_LIMITS_RULES = {
    "resource_limits_pattern": CompatibilityRule(
        function_name="resource.setrlimit",
        bandit_message="[PERM] Resource limits — close files promptly, raise limits in CI",
        category=RuleCategories.RESOURCE_LIMITS,
        tags=["resource", "limits", "file-descriptors", "rlimit", "unix-only"],
        suggestion="""The 'resource' module is Unix-only. Setting resource limits requires:

1. Platform detection:
```python
import sys
if sys.platform != 'win32':
    import resource
    # Set limits on Unix/Linux/macOS only
else:
    # Windows: use different APIs or skip
```

2. Handle unavailable limits:
```python
try:
    import resource
    # Only set limits that are available on this platform
    if hasattr(resource, 'RLIMIT_NOFILE'):
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        resource.setrlimit(resource.RLIMIT_NOFILE, (min(8192, hard), hard))
except (ImportError, ValueError):
    # ImportError: Windows (no resource module)
    # ValueError: Limit not available on this OS
    pass
```

3. Common limits and platform availability:
- RLIMIT_NOFILE: Unix-only (file descriptor limit)
- RLIMIT_NPROC: Unix-only (process limit)
- RLIMIT_STACK: Unix-only (stack size)
- RLIMIT_VMEM: Unix, not all implementations

On Windows, use ctypes to interact with process handles:
```python
import ctypes
if sys.platform == 'win32':
    # Windows: use Windows API via ctypes
    kernel32 = ctypes.windll.kernel32
    # Set file handle limit differently
```""",
        severity="MEDIUM"
    ),
}

# Symlink Privileges Rules (Category 16)
SYMLINK_PRIVILEGES_RULES = {
    "symlink_privileges_pattern": CompatibilityRule(
        function_name="os.symlink",
        bandit_message="[PERM] Symlinks — detect support and use alternative (copy/hardlink)",
        category=RuleCategories.PERM,
        tags=["symlink", "permissions", "windows", "admin", "privileges"],
        suggestion="""On Windows, creating symlinks requires:
- Python 3.8+: Default behavior (requires admin for security)
- Administrator privileges (or developer mode enabled)

On Unix/Linux/macOS:
- No special privileges required (user must own source)

Correct pattern with fallback:

```python
import os
import sys

def safe_symlink(src, dst):
    \"\"\"Create symlink with Windows compatibility.\"\"\"
    try:
        os.symlink(src, dst)
    except OSError as e:
        if sys.platform == 'win32' and e.winerror == 1314:  # Access Denied
            # Windows requires admin/dev mode
            print(f"Cannot create symlink (Windows requires admin): {src} -> {dst}")
            # Fallback: copy file or use junction (mklink /J)
            if os.path.isdir(src):
                # Use junction for directories (no elevation needed)
                os.system(f'mklink /J "{dst}" "{src}"')
            else:
                # Copy file as fallback
                import shutil
                shutil.copy2(src, dst)
        else:
            raise

# Or check before attempting:
import ctypes
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return True  # Assume Unix

if sys.platform == 'win32' and not is_admin():
    print("Warning: Symlinks require admin on Windows")
    # Use alternative (copy, junction, etc.)
else:
    os.symlink(src, dst)

Key points:
- Windows junction: mklink /J (directory only, no admin needed)
- Windows hardlink: mklink /H (file only)
- Windows symlink: mklink (requires admin or dev mode)
- Test code should skip symlink tests on Windows without admin""",
        severity="MEDIUM"
    ),
}
