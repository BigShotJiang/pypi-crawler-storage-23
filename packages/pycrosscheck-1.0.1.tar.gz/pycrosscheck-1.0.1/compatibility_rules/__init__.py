#!/usr/bin/env python3
"""
Windows Compatibility Rules - Consolidated Module

This module consolidates all Windows compatibility rules from different categories:
- OS Functions (Category 01)
- Process Management (Category 02) 
- User Management (Category 03)
- File System (Category 04)
- Signals (Category 05)
- IPC (Category 06)
- System Info (Category 07)
- Terminal (Category 08)
- Device Operations (Category 09)
- Priority (Category 10)
- Encoding and I/O (Category 11)
- Platform Detection Patterns (Category 12)
- Advanced AST-based Rules (RWC Series)
"""

from .base import CompatibilityRule, RuleCategories
from .os_functions import OS_RULES
from .process_management import PROCESS_RULES
from .user_management import USER_RULES
from .file_system import FILE_SYSTEM_RULES
from .signals import SIGNAL_RULES
from .ipc import IPC_RULES
from .system_info import SYSTEM_INFO_RULES
from .terminal import TERMINAL_RULES
from .device_ops import DEVICE_RULES
from .priority import PRIORITY_RULES
from .encoding_and_io import ENCODING_IO_RULES
from .platform_detection import PLATFORM_DETECTION_RULES
from .library_dependencies import LIBRARY_DEPS_RULES
from .network_permissions import PORT_BINDING_RULES, RESOURCE_LIMITS_RULES, SYMLINK_PRIVILEGES_RULES

# Import advanced rules
try:
    from .advanced_rules import ADVANCED_RULES
    ADVANCED_RULES_AVAILABLE = True
except ImportError:
    ADVANCED_RULES = {}
    ADVANCED_RULES_AVAILABLE = False

# Consolidate all rules
ALL_RULES = {}
ALL_RULES.update(OS_RULES)
ALL_RULES.update(PROCESS_RULES)
ALL_RULES.update(USER_RULES)
ALL_RULES.update(FILE_SYSTEM_RULES)
ALL_RULES.update(SIGNAL_RULES)
ALL_RULES.update(IPC_RULES)
ALL_RULES.update(SYSTEM_INFO_RULES)
ALL_RULES.update(TERMINAL_RULES)
ALL_RULES.update(DEVICE_RULES)
ALL_RULES.update(PRIORITY_RULES)
ALL_RULES.update(ENCODING_IO_RULES)
ALL_RULES.update(PLATFORM_DETECTION_RULES)
ALL_RULES.update(LIBRARY_DEPS_RULES)
ALL_RULES.update(PORT_BINDING_RULES)
ALL_RULES.update(RESOURCE_LIMITS_RULES)
ALL_RULES.update(SYMLINK_PRIVILEGES_RULES)


def get_all_rules():
    """Get all compatibility rules."""
    return ALL_RULES


def get_advanced_rules():
    """Get advanced AST-based rules."""
    if ADVANCED_RULES_AVAILABLE:
        return ADVANCED_RULES
    return {}


def get_bandit_rules():
    """Get rules formatted for Bandit plugin."""
    return {func_name: rule.bandit_message for func_name, rule in ALL_RULES.items()}


def get_rules_by_category(category: str):
    """Get rules by category."""
    return {
        func_name: rule for func_name, rule in ALL_RULES.items()
        if rule.category == category
    }


def get_rules_by_tag(tag: str):
    """Get rules by tag."""
    return {
        func_name: rule for func_name, rule in ALL_RULES.items()
        if tag in rule.tags
    }


def get_all_categories():
    """Get all categories used in rules."""
    categories = set()
    for rule in ALL_RULES.values():
        categories.add(rule.category)
    return sorted(list(categories))


def get_all_tags():
    """Get all tags used in rules."""
    tags = set()
    for rule in ALL_RULES.values():
        tags.update(rule.tags)
    return sorted(list(tags))


def get_rules_summary():
    """Get a summary of all rules by category and tag."""
    summary = {
        "total_rules": len(ALL_RULES),
        "categories": {},
        "tags": {}
    }
    
    # Count by category
    for category in get_all_categories():
        category_rules = get_rules_by_category(category)
        summary["categories"][category] = {
            "count": len(category_rules),
            "description": RuleCategories.get_category_name(category),
            "functions": list(category_rules.keys())
        }
    
    # Count by tag
    for tag in get_all_tags():
        tag_rules = get_rules_by_tag(tag)
        summary["tags"][tag] = {
            "count": len(tag_rules),
            "functions": list(tag_rules.keys())
        }
    
    return summary


# Export main functions and classes
__all__ = [
    'CompatibilityRule',
    'RuleCategories', 
    'ALL_RULES',
    'ADVANCED_RULES_AVAILABLE',
    'get_all_rules',
    'get_advanced_rules',
    'get_bandit_rules',
    'get_rules_by_category',
    'get_rules_by_tag',
    'get_all_categories',
    'get_all_tags',
    'get_rules_summary'
]
