#!/usr/bin/env python3
"""
Terminal Operations Rules - Category 08
Functions related to terminal and device control operations.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# Terminal Operations Rules (Category 08)
TERMINAL_RULES = {
    "os.ctermid": CompatibilityRule(
        function_name="os.ctermid",
        bandit_message="Terminal control not available on Windows",
        category=RuleCategories.TERMINAL,
        tags=["terminal", "control", "unix-only"],
        suggestion="Windows doesn't support terminal control device identification. Consider redesigning without this functionality or use platform-specific code with 'if sys.platform != \"win32\"'.",
        severity="MEDIUM"
    ),
}
