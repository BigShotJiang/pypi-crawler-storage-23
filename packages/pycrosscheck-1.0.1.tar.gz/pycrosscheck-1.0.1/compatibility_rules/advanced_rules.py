#!/usr/bin/env python3
"""
Advanced Windows Compatibility Rules
Uses AST-based analysis for complex pattern detection.
"""

import ast
import re
from typing import Iterator, List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class Violation:
    """Represents a compatibility violation found in code."""
    node: ast.AST
    message: str
    line: Optional[int] = None
    column: Optional[int] = None
    
    def __post_init__(self):
        if self.line is None and hasattr(self.node, 'lineno'):
            self.line = self.node.lineno
        if self.column is None and hasattr(self.node, 'col_offset'):
            self.column = self.node.col_offset


class NodeVisitorRule(ast.NodeVisitor):
    """Base class for AST-based compatibility rules."""
    
    code: str = "RWC000"
    message: str = "Windows compatibility issue detected"
    category: str = "general"
    tags: List[str] = []
    
    def __init__(self):
        self.violations: List[Violation] = []
    
    def add_violation(self, node: ast.AST, message: str):
        """Add a violation to the list."""
        violation = Violation(node=node, message=message)
        self.violations.append(violation)
    
    def check_source(self, source_code: str) -> List[Violation]:
        """Check source code and return violations."""
        try:
            tree = ast.parse(source_code)
            self.violations = []
            self.visit(tree)
            return self.violations
        except SyntaxError:
            return []


class PathSeparatorsRule(NodeVisitorRule):
    """Detect hardcoded Unix path separators that should use os.path.join()."""
    
    code = "RWC002"
    message = "Use os.path.join() instead of hardcoded path separators for Windows compatibility"
    category = "file_system"
    tags = ["path", "separator", "cross-platform"]
    
    # Pattern to match paths with forward slashes
    PATH_PATTERN = re.compile(r'^[a-zA-Z0-9_.-]+/[a-zA-Z0-9_./\-]+$')
    
    # Common path-like patterns to check
    SUSPICIOUS_PATTERNS = [
        r'.*\.py$',      # Python files
        r'.*\.txt$',     # Text files
        r'.*\.json$',    # JSON files
        r'.*\.csv$',     # CSV files
        r'.*\.log$',     # Log files
        r'data/.*',      # Data directories
        r'config/.*',    # Config directories
        r'logs/.*',      # Log directories
        r'temp/.*',      # Temp directories
        r'tmp/.*',       # Tmp directories
        r'.*/bin/.*',    # Binary directories
        r'.*/lib/.*',    # Library directories
        r'.*/etc/.*',    # Config directories
    ]
    
    def visit_Constant(self, node: ast.Constant) -> None:
        """Check constant strings for hardcoded path separators (Python 3.8+)."""
        if isinstance(node.value, str):
            self._check_string_value(node, node.value)
    
    def _check_string_value(self, node: ast.AST, value: str) -> None:
        """Check if a string value contains problematic path separators."""
        # Skip URLs, absolute paths, and other non-file paths
        if (value.startswith(('http://', 'https://', 'ftp://', 'file://')) or
            value.startswith('/') or  # Unix absolute path
            ':' in value[:10] or  # Windows drive letter or URL scheme
            '\\' in value or  # Already using Windows separators
            len(value.split('/')) < 2):  # Not a path
            return
        
        # Check if it looks like a file path
        if self.PATH_PATTERN.match(value):
            # Additional check: see if it matches common path patterns
            is_path_like = any(
                re.match(pattern, value) 
                for pattern in self.SUSPICIOUS_PATTERNS
            )
            
            if is_path_like or '/' in value:
                message = f"{self.message}: '{value}'"
                self.add_violation(node, message)
    
    def _generate_fix(self, path: str) -> str:
        """Generate os.path.join() fix for the given path."""
        # Split the path and create os.path.join() call
        parts = path.split('/')
        # Quote each part
        quoted_parts = [f'"{part}"' for part in parts if part]
        
        if len(quoted_parts) == 1:
            return quoted_parts[0]
        
        join_call = f"os.path.join({', '.join(quoted_parts)})"
        return join_call
    
    def visit_Call(self, node: ast.Call) -> None:
        """Check function calls that might involve path operations."""
        # Check common file operations
        if isinstance(node.func, ast.Name):
            if node.func.id in ('open', 'glob', 'exists'):
                for arg in node.args:
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        value = arg.value
                        if '/' in value and not value.startswith(('http', 'ftp')):
                            message = f"{self.message} in {node.func.id}(): '{value}'"
                            self.add_violation(arg, message)
        
        # Check os module functions
        elif isinstance(node.func, ast.Attribute):
            if (isinstance(node.func.value, ast.Name) and 
                node.func.value.id == 'os' and
                node.func.attr in ('remove', 'unlink', 'rmdir', 'mkdir', 'makedirs', 'listdir', 'stat', 'chmod')):
                
                for arg in node.args:
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        value = arg.value
                        if '/' in value and not value.startswith('/'):  # Not absolute Unix path
                            message = f"{self.message} in os.{node.func.attr}(): '{value}'"
                            self.add_violation(arg, message)
        
        # Check glob module functions
        elif isinstance(node.func, ast.Attribute):
            if (isinstance(node.func.value, ast.Name) and 
                node.func.value.id == 'glob' and
                node.func.attr in ('glob', 'iglob')):
                
                for arg in node.args:
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        value = arg.value
                        if '/' in value and not value.startswith(('http', 'ftp')):
                            message = f"{self.message} in glob.{node.func.attr}(): '{value}'"
                            self.add_violation(arg, message)
        
        # Continue visiting child nodes
        self.generic_visit(node)


class ShellCommandRule(NodeVisitorRule):
    """Detect Unix-specific shell commands that won't work on Windows."""
    
    code = "RWC003"
    message = "Unix shell command detected - may not work on Windows"
    category = "system_commands"
    tags = ["shell", "commands", "unix", "cross-platform"]
    
    # Common Unix commands that don't exist on Windows
    UNIX_COMMANDS = {
        'ls': 'dir',
        'cat': 'type',
        'grep': 'findstr',
        'rm': 'del',
        'mv': 'move',
        'cp': 'copy',
        'chmod': 'attrib',
        'ps': 'tasklist',
        'kill': 'taskkill',
        'which': 'where',
        'tail': 'more',
        'head': 'more',
        'touch': 'echo. > ',
        'pwd': 'cd',
        'whoami': 'whoami',  # This one actually works
        'df': 'wmic logicaldisk',
        'du': 'dir /s',
        'find': 'dir /s /b',
        'locate': 'dir /s /b',
        'wget': 'curl',
        'curl': 'curl',  # Available on newer Windows
        'tar': 'tar',    # Available on newer Windows
        'ssh': 'ssh',    # Available via OpenSSH
        'scp': 'scp',    # Available via OpenSSH
    }
    
    # Commands that should use subprocess or specific modules
    SHELL_PATTERNS = [
        r'ls\s+',
        r'cat\s+',
        r'grep\s+',
        r'rm\s+',
        r'mv\s+',
        r'cp\s+',
        r'chmod\s+\d+',
        r'ps\s+aux',
        r'kill\s+-\d+',
        r'which\s+',
        r'tail\s+-f',
        r'head\s+-n',
        r'find\s+.*-name',
        r'locate\s+',
    ]
    
    def visit_Call(self, node: ast.Call) -> None:
        """Check subprocess and os.system calls for Unix commands."""
        if isinstance(node.func, ast.Name):
            # Check os.system calls
            if node.func.id == 'system':
                self._check_system_call(node)
        
        elif isinstance(node.func, ast.Attribute):
            # Check os.system calls
            if (isinstance(node.func.value, ast.Name) and 
                node.func.value.id == 'os' and
                node.func.attr == 'system'):
                self._check_system_call(node)
            
            # Check subprocess calls
            elif (isinstance(node.func.value, ast.Name) and 
                  node.func.value.id == 'subprocess'):
                self._check_subprocess_call(node)
        
        self.generic_visit(node)
    
    def _check_system_call(self, node: ast.Call) -> None:
        """Check os.system() calls for Unix commands."""
        if node.args and isinstance(node.args[0], ast.Constant):
            command = node.args[0].value
            if isinstance(command, str):
                self._analyze_command(node.args[0], command)
    
    def _check_subprocess_call(self, node: ast.Call) -> None:
        """Check subprocess calls for Unix commands."""
        if node.args:
            # Check if first argument is a string (shell command)
            if isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                command = node.args[0].value
                self._analyze_command(node.args[0], command)
            
            # Check if first argument is a list of strings
            elif isinstance(node.args[0], ast.List):
                for elem in node.args[0].elts:
                    if isinstance(elem, ast.Constant) and isinstance(elem.value, str):
                        command = elem.value
                        self._analyze_command(elem, command)
                        break  # Only check first element (command name)
    
    def _analyze_command(self, node: ast.AST, command: str) -> None:
        """Analyze a command string for Unix-specific patterns."""
        command = command.strip()
        
        # Check for direct Unix command usage
        cmd_parts = command.split()
        if cmd_parts:
            cmd_name = cmd_parts[0]
            if cmd_name in self.UNIX_COMMANDS:
                windows_equiv = self.UNIX_COMMANDS[cmd_name]
                message = f"{self.message}: '{cmd_name}' -> use '{windows_equiv}' on Windows"
                self.add_violation(node, message)
        
        # Check for complex Unix patterns
        for pattern in self.SHELL_PATTERNS:
            if re.search(pattern, command):
                message = f"{self.message}: Unix shell pattern detected in '{command}'"
                self.add_violation(node, message)


class EnvironmentVariableRule(NodeVisitorRule):
    """Detect Unix-specific environment variables that may not exist on Windows."""
    
    code = "RWC004"
    message = "Unix environment variable detected - may not exist on Windows"
    category = "environment"
    tags = ["environment", "variables", "unix", "cross-platform"]
    
    # Unix-specific environment variables and their Windows equivalents
    UNIX_ENV_VARS = {
        'HOME': 'USERPROFILE',
        'USER': 'USERNAME',
        'SHELL': 'COMSPEC',
        'PS1': 'PROMPT',
        'PATH': 'PATH',  # Same but different separator
        'LD_LIBRARY_PATH': 'PATH',  # Libraries in PATH on Windows
        'DISPLAY': None,  # X11 specific, no direct equivalent
        'TERM': None,     # Terminal type, Windows uses different system
        'TMPDIR': 'TEMP', # or TMP
        'EDITOR': 'EDITOR',  # May not be set
        'PAGER': None,    # Unix concept
        'MANPATH': None,  # Unix man pages
        'LANG': None,     # Use locale module instead
        'LC_ALL': None,   # Use locale module instead
        'PWD': 'CD',      # Current directory
        'OLDPWD': None,   # Previous directory
        'LOGNAME': 'USERNAME',
        'MAIL': None,     # Unix mail system
        'MAILPATH': None, # Unix mail system
    }
    
    def visit_Subscript(self, node: ast.Subscript) -> None:
        """Check os.environ[] access."""
        if (isinstance(node.value, ast.Attribute) and
            isinstance(node.value.value, ast.Name) and
            node.value.value.id == 'os' and
            node.value.attr == 'environ'):
            
            if isinstance(node.slice, ast.Constant) and isinstance(node.slice.value, str):
                env_var = node.slice.value
                self._check_env_var(node, env_var)
        
        self.generic_visit(node)
    
    def visit_Call(self, node: ast.Call) -> None:
        """Check os.getenv() and os.environ.get() calls."""
        if isinstance(node.func, ast.Attribute):
            # Check os.getenv()
            if (isinstance(node.func.value, ast.Name) and
                node.func.value.id == 'os' and
                node.func.attr == 'getenv'):
                if node.args and isinstance(node.args[0], ast.Constant):
                    env_var = node.args[0].value
                    if isinstance(env_var, str):
                        self._check_env_var(node.args[0], env_var)
            
            # Check os.environ.get()
            elif (isinstance(node.func.value, ast.Attribute) and
                  isinstance(node.func.value.value, ast.Name) and
                  node.func.value.value.id == 'os' and
                  node.func.value.attr == 'environ' and
                  node.func.attr == 'get'):
                if node.args and isinstance(node.args[0], ast.Constant):
                    env_var = node.args[0].value
                    if isinstance(env_var, str):
                        self._check_env_var(node.args[0], env_var)
        
        self.generic_visit(node)
    
    def _check_env_var(self, node: ast.AST, env_var: str) -> None:
        """Check if environment variable is Unix-specific."""
        if env_var in self.UNIX_ENV_VARS:
            windows_equiv = self.UNIX_ENV_VARS[env_var]
            if windows_equiv:
                message = f"{self.message}: '{env_var}' -> use '{windows_equiv}' on Windows"
                self.add_violation(node, message)
            else:
                message = f"{self.message}: '{env_var}' is Unix-specific and has no Windows equivalent"
                self.add_violation(node, message)


class FilePermissionsRule(NodeVisitorRule):
    """Detect Unix file permission patterns that don't work on Windows."""
    
    code = "RWC005"
    message = "Unix file permissions detected - Windows uses different permission model"
    category = "file_permissions"
    tags = ["permissions", "unix", "chmod", "file-system"]
    
    # Common Unix permission patterns
    UNIX_PERMISSION_PATTERNS = [
        r'0o[0-7]{3,4}',  # Octal permissions like 0o755
        r'0[0-7]{3,4}',   # Octal permissions like 0755
        r'stat\.S_I[RWXU].*',  # stat module constants
    ]
    
    def visit_Call(self, node: ast.Call) -> None:
        """Check chmod calls and permission-related functions."""
        if isinstance(node.func, ast.Attribute):
            # Check os.chmod() calls
            if (isinstance(node.func.value, ast.Name) and
                node.func.value.id == 'os' and
                node.func.attr == 'chmod'):
                self._check_chmod_call(node)
            
            # Check pathlib chmod() calls
            elif node.func.attr == 'chmod':
                self._check_chmod_call(node)
        
        self.generic_visit(node)
    
    def visit_Constant(self, node: ast.Constant) -> None:
        """Check for octal permission constants."""
        if isinstance(node.value, int):
            # Check if this looks like a Unix permission (3-4 digit octal)
            octal_str = oct(node.value)
            if len(octal_str) >= 5 and octal_str.startswith('0o'):  # 0o755 format
                perm_part = octal_str[2:]
                if len(perm_part) in [3, 4] and all(c in '01234567' for c in perm_part):
                    message = f"{self.message}: octal permission {octal_str} detected"
                    self.add_violation(node, message)
                if re.match(pattern, node.value):
                    message = f"{self.message}: permission pattern '{node.value}' detected"
                    self.add_violation(node, message)
    
    def _check_chmod_call(self, node: ast.Call) -> None:
        """Check chmod function call arguments."""
        if len(node.args) >= 2:
            perm_arg = node.args[1]
            if isinstance(perm_arg, ast.Constant) and isinstance(perm_arg.value, int):
                # Check if this is a Unix-style permission
                octal_str = oct(perm_arg.value)
                if len(octal_str) >= 5:  # 0o755 etc.
                    message = f"{self.message}: chmod with Unix permissions {octal_str}"
                    self.add_violation(perm_arg, message)


class SlashInRegexRule(NodeVisitorRule):
    """Detect regex patterns with hardcoded forward slashes that might be paths."""
    
    code = "RWC006"
    message = "Regex pattern with forward slashes detected - consider os.sep for path matching"
    category = "regex_patterns"
    tags = ["regex", "path", "separator", "cross-platform"]
    
    def visit_Call(self, node: ast.Call) -> None:
        """Check regex compilation and matching functions."""
        if isinstance(node.func, ast.Attribute):
            # Check re.compile(), re.match(), re.search(), etc.
            if (isinstance(node.func.value, ast.Name) and
                node.func.value.id == 're' and
                node.func.attr in ('compile', 'match', 'search', 'findall', 'sub', 'subn')):
                self._check_regex_pattern(node)
        
        elif isinstance(node.func, ast.Name):
            # Check if it's a regex function imported directly
            if node.func.id in ('compile', 'match', 'search', 'findall', 'sub', 'subn'):
                self._check_regex_pattern(node)
        
        self.generic_visit(node)
    
    def _check_regex_pattern(self, node: ast.Call) -> None:
        """Check regex pattern for path-like forward slashes."""
        if node.args and isinstance(node.args[0], ast.Constant):
            pattern = node.args[0].value
            if isinstance(pattern, str) and self._looks_like_path_regex(pattern):
                message = f"{self.message}: pattern '{pattern}' contains path separators"
                self.add_violation(node.args[0], message)
    
    def _looks_like_path_regex(self, pattern: str) -> bool:
        """Check if regex pattern looks like it's matching file paths."""
        # Look for patterns that suggest file paths
        path_indicators = [
            r'.*/',        # Ends with slash
            r'/.*',        # Starts with slash
            r'.*\..*/',    # File extension followed by slash
            r'/.*/.*',     # Multiple directory levels
            r'bin/',       # Common directory names
            r'lib/',
            r'etc/',
            r'tmp/',
            r'var/',
            r'usr/',
            r'home/',
            r'opt/',
        ]
        
        # Skip if it's clearly not a path (URL, etc.)
        if any(indicator in pattern for indicator in ['http://', 'https://', 'ftp://', '://']):
            return False
        
        # Check if pattern contains forward slashes in path-like contexts
        if '/' in pattern:
            # Simple heuristic: if it has slashes and looks like paths
            return any(re.search(indicator, pattern) for indicator in path_indicators)
        
        return False


class UnixImportsRule(NodeVisitorRule):
    """Detect imports of Unix-specific modules that don't exist on Windows."""
    
    code = "RWC007"
    message = "Unix-specific module imported - not available on Windows"
    category = "imports"
    tags = ["imports", "unix-only", "modules", "compatibility"]
    
    # Unix-specific modules and their Windows alternatives
    UNIX_MODULES = {
        'pwd': 'getpass.getuser() or os.getlogin()',
        'grp': 'No direct equivalent - use platform checks',
        'spwd': 'No Windows equivalent',
        'crypt': 'hashlib module',
        'termios': 'msvcrt module for console I/O',
        'tty': 'msvcrt module for console I/O',
        'pty': 'No Windows equivalent',
        'fcntl': 'msvcrt module for file operations',
        'syslog': 'logging module or Windows Event Log',
        'resource': 'Partial - use psutil for cross-platform resource monitoring',
        'curses': 'windows-curses package or colorama',
        'readline': 'pyreadline3 package',
        'nis': 'No Windows equivalent',
        'dbm': 'Use dbm.dumb or other database solutions',
        'gdbm': 'Use dbm.dumb or other database solutions',
    }
    
    def visit_Import(self, node: ast.Import) -> None:
        """Check import statements for Unix-specific modules."""
        for alias in node.names:
            module_name = alias.name.split('.')[0]  # Get top-level module
            if module_name in self.UNIX_MODULES:
                message = f"{self.message}: '{module_name}' module"
                self.add_violation(node, message)
        
        self.generic_visit(node)
    
    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        """Check from...import statements for Unix-specific modules."""
        if node.module:
            module_name = node.module.split('.')[0]  # Get top-level module
            if module_name in self.UNIX_MODULES:
                message = f"{self.message}: '{module_name}' module in from import"
                self.add_violation(node, message)
        
        self.generic_visit(node)


class HardcodedNewlinesRule(NodeVisitorRule):
    """Detect hardcoded Unix newlines that should use os.linesep."""
    
    code = "RWC008"
    message = "Hardcoded Unix newline detected - use os.linesep for cross-platform compatibility"
    category = "line_endings"
    tags = ["newlines", "line-endings", "cross-platform"]
    
    def visit_Constant(self, node: ast.Constant) -> None:
        """Check string constants for hardcoded newlines."""
        if isinstance(node.value, str):
            # Check for standalone \n that's not part of a larger string
            if node.value == '\n':
                message = f"{self.message}: standalone '\\n'"
                self.add_violation(node, message)
            
            # Check for strings that end with \n but not \r\n (Unix style)
            elif (node.value.endswith('\n') and 
                  not node.value.endswith('\r\n') and 
                  len(node.value) > 1):
                message = f"{self.message}: string ending with Unix newline"
                self.add_violation(node, message)
        
        self.generic_visit(node)
    
    def visit_Call(self, node: ast.Call) -> None:
        """Check file operations that might involve line endings."""
        if isinstance(node.func, ast.Attribute):
            # Check file.write() calls
            if node.func.attr == 'write':
                for arg in node.args:
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        if '\n' in arg.value and '\r\n' not in arg.value:
                            message = f"{self.message}: in write() call"
                            self.add_violation(arg, message)
            
            # Check string methods that join with newlines
            elif node.func.attr == 'join' and node.args:
                if isinstance(node.args[0], ast.Constant) and node.args[0].value == '\n':
                    message = f"{self.message}: in join() call"
                    self.add_violation(node.args[0], message)
        
        self.generic_visit(node)


class PlatformSpecificPathsRule(NodeVisitorRule):
    """Detect hardcoded platform-specific paths."""
    
    code = "RWC009"
    message = "Platform-specific path detected - use pathlib or os.path for cross-platform compatibility"
    category = "paths"
    tags = ["paths", "platform-specific", "cross-platform"]
    
    # Common Unix paths that don't exist on Windows
    UNIX_PATHS = [
        '/usr', '/bin', '/sbin', '/lib', '/etc', '/var', '/opt', '/home',
        '/tmp', '/dev', '/proc', '/sys', '/mnt', '/media', '/srv', '/root'
    ]
    
    # Common Windows paths that don't exist on Unix
    WINDOWS_PATHS = [
        'C:\\', 'D:\\', 'E:\\', 'F:\\',  # Drive letters
        'C:\\Windows', 'C:\\Program Files', 'C:\\Users',
        'C:\\Documents and Settings', 'C:\\ProgramData',
        '\\\\', # UNC paths
    ]
    
    def visit_Constant(self, node: ast.Constant) -> None:
        """Check string constants for platform-specific paths."""
        if isinstance(node.value, str):
            value = node.value.strip()
            
            # Check for Unix absolute paths
            for unix_path in self.UNIX_PATHS:
                if value.startswith(unix_path):
                    message = f"{self.message}: Unix path '{value}'"
                    self.add_violation(node, message)
                    break
            
            # Check for Windows paths
            for win_path in self.WINDOWS_PATHS:
                if value.startswith(win_path) or win_path in value:
                    message = f"{self.message}: Windows path '{value}'"
                    self.add_violation(node, message)
                    break
        
        self.generic_visit(node)


# Registry of all advanced rules
ADVANCED_RULES = {
    PathSeparatorsRule.code: PathSeparatorsRule,
    ShellCommandRule.code: ShellCommandRule,
    EnvironmentVariableRule.code: EnvironmentVariableRule,
    FilePermissionsRule.code: FilePermissionsRule,
    SlashInRegexRule.code: SlashInRegexRule,
    UnixImportsRule.code: UnixImportsRule,
    HardcodedNewlinesRule.code: HardcodedNewlinesRule,
    PlatformSpecificPathsRule.code: PlatformSpecificPathsRule,
}

# Export for use in other modules
__all__ = [
    'NodeVisitorRule',
    'Violation', 
    'PathSeparatorsRule',
    'ShellCommandRule',
    'EnvironmentVariableRule',
    'FilePermissionsRule',
    'SlashInRegexRule',
    'UnixImportsRule',
    'HardcodedNewlinesRule',
    'PlatformSpecificPathsRule',
    'ADVANCED_RULES'
]
