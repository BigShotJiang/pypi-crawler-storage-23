#!/usr/bin/env python3
"""
Process Priority Rules - Category 10
Functions related to process priority and scheduling.
"""

from .base import CompatibilityRule, RuleCategories, generate_rule_id

# Process Priority Rules (Category 10)
PRIORITY_RULES = {
    "os.nice": CompatibilityRule(
        function_name="os.nice",
        bandit_message="Use psutil for cross-platform process priority management",
        category=RuleCategories.PRIORITY,
        tags=["priority", "nice", "unix-only"],
        suggestion="Replace with psutil.Process().nice() for cross-platform priority management. Import psutil library (pip install psutil). Works on both Unix and Windows.",
        severity="MEDIUM"
    ),

    "os.getpriority": CompatibilityRule(
        function_name="os.getpriority",
        bandit_message="Use psutil for cross-platform process priority management",
        category=RuleCategories.PRIORITY,
        tags=["priority", "get", "unix-only"],
        suggestion="Replace with psutil.Process().nice() for cross-platform priority management. Import psutil library (pip install psutil). Note: which/who parameters not supported, use process-specific priority.",
        severity="MEDIUM"
    ),

    "os.setpriority": CompatibilityRule(
        function_name="os.setpriority",
        bandit_message="Use psutil for cross-platform process priority management",
        category=RuleCategories.PRIORITY,
        tags=["priority", "set", "unix-only"],
        suggestion="Replace with psutil.Process().nice(value) for cross-platform priority management. Import psutil library (pip install psutil). Note: which/who parameters not supported, use process-specific priority.",
        severity="MEDIUM"
    ),
}
