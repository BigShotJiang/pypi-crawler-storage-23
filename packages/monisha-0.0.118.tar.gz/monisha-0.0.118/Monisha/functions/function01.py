import time
import pytz
from datetime import datetime
from ..scripts import Scripted
from .collections import SMessage
#============================================================================

def timend(tsize, dsize, speed):
    moonuo = round((tsize - dsize) / speed)
    return moonuo

#============================================================================

def uptime(incoming):
    timetaken = time.time() - incoming
    hours, houro = divmod(timetaken, 3600)
    minutes, seconds = divmod(houro, 60)
    return int(hours), int(minutes), int(seconds)

#============================================================================

def tzone(location="Asia/Kolkata"):
    moonus = datetime.now(tz=pytz.timezone(location))
    return moonus

#============================================================================

def tveries(moonos):
    moonus = moonos if isinstance(moonos, int) else 0
    moones = moonus if 1 < moonus else 0
    return moones

#============================================================================

def Timesed(moonos: int) -> str:
    moonse = tveries(moonos)
    minute, seconds = divmod(moonse, 60)
    hours, minute = divmod(minute, 60)
    days, hours = divmod(hours, 24)
    week, days = divmod(days, 7)
    year, week = divmod(week, 52)
    mos = ((str(year) + "Y, ") if year else Scripted.DATA01)
    mos += ((str(week) + "w, ") if days else Scripted.DATA01)
    mos += ((str(days) + "d, ") if days else Scripted.DATA01)
    mos += ((str(hours) + "h, ") if hours else Scripted.DATA01)
    mos += ((str(minute) + "m, ") if minute else Scripted.DATA01)
    mos += ((str(seconds) + "s") if seconds else Scripted.DATA16)
    return mos.rstrip(", ") if mos else "∞"

#============================================================================

def Timemod(moonos: int) -> str:
    moonse = tveries(moonos)
    minute, seconds = divmod(moonse, 60)
    hours, minute = divmod(minute, 60)
    days, hours = divmod(hours, 24)
    week, days = divmod(days, 7)
    year, week = divmod(week, 52)
    mos = ((str(year) + "Y, ") if year else Scripted.DATA01)
    mos += ((str(week) + "w, ") if days else Scripted.DATA01)
    mos += ((str(days) + "𝚍, ") if days else Scripted.DATA01)
    mos += ((str(hours) + "𝚑, ") if hours else Scripted.DATA01)
    mos += ((str(minute) + "𝚖, ") if minute else Scripted.DATA01)
    mos += ((str(seconds) + "𝚜") if seconds else Scripted.DATA15)
    return mos.rstrip(", ") if mos else "∞"

#============================================================================

def Timesod(moonos: int) -> str:
    moonse = tveries(moonos)
    minute, seconds = divmod(moonse, 60)
    hours, minute = divmod(minute, 60)
    days, hours = divmod(hours, 24)
    week, days = divmod(days, 7)
    year, week = divmod(week, 52)
    mos = ((str(year) + "year, ") if year else Scripted.DATA01)
    mos += ((str(week) + "week, ") if days else Scripted.DATA01)
    mos += ((str(days) + "days, ") if days else Scripted.DATA01)
    mos += ((str(hours) + "hours, ") if hours else Scripted.DATA01)
    mos += ((str(minute) + "minutes, ") if minute else Scripted.DATA01)
    mos += ((str(seconds) + "seconds") if seconds else Scripted.DATA16)
    return mos.rstrip(", ") if mos else "∞"

#============================================================================
