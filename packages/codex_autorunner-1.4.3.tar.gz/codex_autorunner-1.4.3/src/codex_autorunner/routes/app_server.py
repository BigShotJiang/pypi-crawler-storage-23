"""Backward-compatible app-server routes."""

from ..surfaces.web.routes.app_server import *  # noqa: F401,F403
