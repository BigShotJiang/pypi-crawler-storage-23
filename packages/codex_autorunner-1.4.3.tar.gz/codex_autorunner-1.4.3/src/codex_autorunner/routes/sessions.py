"""Backward-compatible session routes."""

from ..surfaces.web.routes.sessions import *  # noqa: F401,F403
