"""Backward-compatible agent routes."""

from ..surfaces.web.routes.agents import *  # noqa: F401,F403
