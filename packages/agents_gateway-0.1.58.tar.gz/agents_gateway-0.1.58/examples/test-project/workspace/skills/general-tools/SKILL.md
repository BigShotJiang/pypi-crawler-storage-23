---
name: general-tools
description: General-purpose utility tools for testing and HTTP requests
tools:
  - echo
  - http-example
---

# General Tools

Utility tools available for general-purpose tasks:

- **echo**: Use to echo messages back (useful for testing)
- **http-example**: Use to make HTTP requests to external APIs
