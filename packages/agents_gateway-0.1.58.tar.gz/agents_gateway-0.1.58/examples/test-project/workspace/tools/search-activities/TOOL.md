---
name: search-activities
description: Search for activities and things to do at a destination.
parameters:
  destination:
    type: string
    description: "The city to search activities in"
    required: true
  date:
    type: string
    description: "The date for activities (YYYY-MM-DD)"
    required: true
---

# Search Activities Tool

Returns mock activity search results.
