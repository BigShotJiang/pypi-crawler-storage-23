# Example Emails

## Meeting Follow-Up

Subject: Action items from our Q1 planning session

Hi Sarah,

Thanks for a productive meeting today. Here's a quick summary of what we agreed on:

- **Launch date** moved to March 15th
- Design team will share mockups by Friday
- Engineering spike on the payment integration starts Monday

Could you update the project timeline in Notion? Let me know if anything looks off.

Best regards,
Alex

## Project Update

Subject: Weekly update — Onboarding redesign

Hi Team,

Quick update on where we stand this week:

We completed the user research interviews (12 participants) and identified three key pain points in the current flow. The findings doc is linked in Slack.

**Next steps:**
- Workshop to prioritize improvements (Thursday 2pm)
- Draft wireframes by end of next week
- Stakeholder review the following Monday

Let me know if you have questions before Thursday's workshop.

Thanks,
Jordan

## Introduction Email

Subject: Connecting you with our engineering lead

Hi Marcus,

I wanted to introduce you to Priya, our engineering lead on the payments team. She's the right person to discuss the API integration timeline.

Priya — Marcus is leading the partner onboarding project I mentioned last week. He has a few questions about webhook delivery guarantees.

I'll let you two take it from here!

Best regards,
Alex
