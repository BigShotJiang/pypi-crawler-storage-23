"""Integration tests for the API layer and Gateway class."""
