---
name: test-skill
description: A test skill for unit tests
tools:
  - echo
---

# Test Skill

When asked to test something, use the `echo` tool to echo the input back.
