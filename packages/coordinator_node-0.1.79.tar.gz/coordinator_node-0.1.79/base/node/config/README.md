# config

- `crunch_config.py`: CrunchConfig override — data-shape types, scoring, scheduled predictions, and competition settings
- `callables.env`: scoring function callable path (e.g. `SCORING_FUNCTION=crunch_mycrunch.scoring:score_prediction`)
