from setuptools import setup, find_packages

setup(
    name="myanmar-code",
    version="1.0.0",
    description="မြန်မာကုဒ် - Myanmar Programming Language",
    author="AMO MASTER 221922",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.6",
)
