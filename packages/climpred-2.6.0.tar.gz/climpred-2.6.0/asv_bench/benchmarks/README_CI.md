https://github.com/pydata/xarray/blob/main/asv_bench/benchmarks/README_CI.md
