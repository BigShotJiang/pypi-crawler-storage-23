.. include:: ../../HOWTORELEASE.rst
