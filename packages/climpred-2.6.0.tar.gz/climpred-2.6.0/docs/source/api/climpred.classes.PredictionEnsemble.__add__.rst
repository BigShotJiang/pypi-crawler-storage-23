climpred.classes.PredictionEnsemble.\_\_add\_\_
===============================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.__add__
