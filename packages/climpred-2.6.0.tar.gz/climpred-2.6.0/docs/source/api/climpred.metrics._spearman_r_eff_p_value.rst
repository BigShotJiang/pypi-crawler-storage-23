climpred.metrics.\_spearman\_r\_eff\_p\_value
=============================================

.. currentmodule:: climpred.metrics

.. autofunction:: _spearman_r_eff_p_value
