climpred.classes.PerfectModelEnsemble.\_\_init\_\_
==================================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.__init__
