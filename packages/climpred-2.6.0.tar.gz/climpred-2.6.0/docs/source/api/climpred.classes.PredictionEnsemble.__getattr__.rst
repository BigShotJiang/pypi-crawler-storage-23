climpred.classes.PredictionEnsemble.\_\_getattr\_\_
===================================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.__getattr__
