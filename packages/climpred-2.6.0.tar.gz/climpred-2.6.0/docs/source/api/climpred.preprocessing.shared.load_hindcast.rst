climpred.preprocessing.shared.load\_hindcast
============================================

.. currentmodule:: climpred.preprocessing.shared

.. autofunction:: load_hindcast
