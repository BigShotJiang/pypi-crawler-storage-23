climpred.metrics.\_discrimination
=================================

.. currentmodule:: climpred.metrics

.. autofunction:: _discrimination
