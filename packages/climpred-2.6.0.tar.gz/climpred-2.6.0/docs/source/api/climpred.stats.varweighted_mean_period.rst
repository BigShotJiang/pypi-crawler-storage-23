climpred.stats.varweighted\_mean\_period
========================================

.. currentmodule:: climpred.stats

.. autofunction:: varweighted_mean_period
