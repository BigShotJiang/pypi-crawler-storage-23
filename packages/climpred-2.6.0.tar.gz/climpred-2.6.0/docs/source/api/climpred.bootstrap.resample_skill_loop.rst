climpred.bootstrap.resample\_skill\_loop
========================================

.. currentmodule:: climpred.bootstrap

.. autofunction:: resample_skill_loop
