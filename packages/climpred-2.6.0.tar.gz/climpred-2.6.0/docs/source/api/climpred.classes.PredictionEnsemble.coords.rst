climpred.classes.PredictionEnsemble.coords
==========================================

.. currentmodule:: climpred.classes

.. autoproperty:: PredictionEnsemble.coords
