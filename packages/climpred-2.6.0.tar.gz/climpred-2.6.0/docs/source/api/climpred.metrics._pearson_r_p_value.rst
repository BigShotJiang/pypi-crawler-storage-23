climpred.metrics.\_pearson\_r\_p\_value
=======================================

.. currentmodule:: climpred.metrics

.. autofunction:: _pearson_r_p_value
