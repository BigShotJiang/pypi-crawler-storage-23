climpred.metrics.\_spearman\_r
==============================

.. currentmodule:: climpred.metrics

.. autofunction:: _spearman_r
