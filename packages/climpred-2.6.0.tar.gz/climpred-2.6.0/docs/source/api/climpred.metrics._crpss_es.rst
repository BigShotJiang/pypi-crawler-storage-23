climpred.metrics.\_crpss\_es
============================

.. currentmodule:: climpred.metrics

.. autofunction:: _crpss_es
