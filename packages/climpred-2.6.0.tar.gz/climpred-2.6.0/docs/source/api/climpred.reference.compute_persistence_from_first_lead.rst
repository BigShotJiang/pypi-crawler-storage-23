climpred.reference.compute\_persistence\_from\_first\_lead
==========================================================

.. currentmodule:: climpred.reference

.. autofunction:: compute_persistence_from_first_lead
