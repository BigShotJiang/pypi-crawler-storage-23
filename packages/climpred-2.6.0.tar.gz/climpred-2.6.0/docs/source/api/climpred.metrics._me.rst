climpred.metrics.\_me
=====================

.. currentmodule:: climpred.metrics

.. autofunction:: _me
