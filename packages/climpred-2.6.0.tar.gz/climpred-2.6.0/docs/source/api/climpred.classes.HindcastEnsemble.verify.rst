climpred.classes.HindcastEnsemble.verify
========================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.verify
