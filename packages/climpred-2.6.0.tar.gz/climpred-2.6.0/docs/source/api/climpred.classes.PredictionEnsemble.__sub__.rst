climpred.classes.PredictionEnsemble.\_\_sub\_\_
===============================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.__sub__
