climpred.classes.PredictionEnsemble.chunksizes
==============================================

.. currentmodule:: climpred.classes

.. autoproperty:: PredictionEnsemble.chunksizes
