climpred.classes.PerfectModelEnsemble.verify
============================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.verify
