climpred.bootstrap.bootstrap\_perfect\_model
============================================

.. currentmodule:: climpred.bootstrap
