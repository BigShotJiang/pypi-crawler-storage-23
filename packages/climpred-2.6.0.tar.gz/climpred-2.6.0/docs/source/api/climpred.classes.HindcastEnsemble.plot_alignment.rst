climpred.classes.HindcastEnsemble.plot\_alignment
=================================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.plot_alignment
