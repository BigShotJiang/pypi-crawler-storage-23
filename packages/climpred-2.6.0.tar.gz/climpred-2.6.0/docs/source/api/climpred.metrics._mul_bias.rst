climpred.metrics.\_mul\_bias
============================

.. currentmodule:: climpred.metrics

.. autofunction:: _mul_bias
