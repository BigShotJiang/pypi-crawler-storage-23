climpred.metrics.\_pearson\_r
=============================

.. currentmodule:: climpred.metrics

.. autofunction:: _pearson_r
