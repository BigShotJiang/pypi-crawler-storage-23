﻿climpred.comparisons.\_m2c
===========================

.. currentmodule:: climpred.comparisons

.. autofunction:: _m2c
