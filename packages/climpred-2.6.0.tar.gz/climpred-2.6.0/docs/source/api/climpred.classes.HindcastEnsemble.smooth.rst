climpred.classes.HindcastEnsemble.smooth
========================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.smooth
