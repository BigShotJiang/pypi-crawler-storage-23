climpred.graphics.plot\_bootstrapped\_skill\_over\_leadyear
===========================================================

.. currentmodule:: climpred.graphics

.. autofunction:: plot_bootstrapped_skill_over_leadyear
