climpred.classes.HindcastEnsemble.plot
======================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.plot
