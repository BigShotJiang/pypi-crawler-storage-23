climpred.classes.PredictionEnsemble.sizes
=========================================

.. currentmodule:: climpred.classes

.. autoproperty:: PredictionEnsemble.sizes
