﻿climpred.metrics.Metric.\_\_repr\_\_
=====================================

.. currentmodule:: climpred.metrics

.. automethod:: Metric.__repr__
