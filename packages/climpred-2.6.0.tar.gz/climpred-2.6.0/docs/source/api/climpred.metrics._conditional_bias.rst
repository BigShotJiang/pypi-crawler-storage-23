climpred.metrics.\_conditional\_bias
====================================

.. currentmodule:: climpred.metrics

.. autofunction:: _conditional_bias
