climpred.classes.HindcastEnsemble.get\_uninitialized
====================================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.get_uninitialized
