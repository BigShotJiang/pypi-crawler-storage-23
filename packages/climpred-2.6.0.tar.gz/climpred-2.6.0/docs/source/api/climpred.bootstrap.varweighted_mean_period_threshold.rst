climpred.bootstrap.varweighted\_mean\_period\_threshold
=======================================================

.. currentmodule:: climpred.bootstrap

.. autofunction:: varweighted_mean_period_threshold
