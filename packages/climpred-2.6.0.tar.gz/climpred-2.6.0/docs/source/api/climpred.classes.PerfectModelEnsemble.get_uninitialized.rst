climpred.classes.PerfectModelEnsemble.get\_uninitialized
========================================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.get_uninitialized
