climpred.reference.compute\_persistence
=======================================

.. currentmodule:: climpred.reference

.. autofunction:: compute_persistence
