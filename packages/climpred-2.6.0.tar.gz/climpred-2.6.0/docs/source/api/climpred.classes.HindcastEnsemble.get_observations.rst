climpred.classes.HindcastEnsemble.get\_observations
===================================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.get_observations
