climpred.horizon.horizon
========================

.. currentmodule:: climpred.horizon

.. autofunction:: horizon
