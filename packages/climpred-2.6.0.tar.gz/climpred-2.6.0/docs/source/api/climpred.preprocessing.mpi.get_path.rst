climpred.preprocessing.mpi.get\_path
====================================

.. currentmodule:: climpred.preprocessing.mpi

.. autofunction:: get_path
