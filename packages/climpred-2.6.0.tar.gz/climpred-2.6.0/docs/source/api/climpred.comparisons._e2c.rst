﻿climpred.comparisons.\_e2c
===========================

.. currentmodule:: climpred.comparisons

.. autofunction:: _e2c
