climpred.metrics.\_bias\_slope
==============================

.. currentmodule:: climpred.metrics

.. autofunction:: _bias_slope
