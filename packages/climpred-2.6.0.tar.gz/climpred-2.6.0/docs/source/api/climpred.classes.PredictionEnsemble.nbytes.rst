climpred.classes.PredictionEnsemble.nbytes
==========================================

.. currentmodule:: climpred.classes

.. autoproperty:: PredictionEnsemble.nbytes
