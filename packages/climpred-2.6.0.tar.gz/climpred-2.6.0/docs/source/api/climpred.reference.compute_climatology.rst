climpred.reference.compute\_climatology
=======================================

.. currentmodule:: climpred.reference

.. autofunction:: compute_climatology
