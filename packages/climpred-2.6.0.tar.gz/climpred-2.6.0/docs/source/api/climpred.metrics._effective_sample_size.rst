climpred.metrics.\_effective\_sample\_size
==========================================

.. currentmodule:: climpred.metrics

.. autofunction:: _effective_sample_size
