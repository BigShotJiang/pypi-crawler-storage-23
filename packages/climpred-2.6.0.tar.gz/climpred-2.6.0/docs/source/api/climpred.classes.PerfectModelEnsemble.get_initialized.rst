climpred.classes.PerfectModelEnsemble.get\_initialized
======================================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.get_initialized
