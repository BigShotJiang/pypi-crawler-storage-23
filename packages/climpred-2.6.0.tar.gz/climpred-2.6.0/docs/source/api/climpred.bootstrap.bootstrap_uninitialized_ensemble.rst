climpred.bootstrap.bootstrap\_uninitialized\_ensemble
=====================================================

.. currentmodule:: climpred.bootstrap

.. autofunction:: bootstrap_uninitialized_ensemble
