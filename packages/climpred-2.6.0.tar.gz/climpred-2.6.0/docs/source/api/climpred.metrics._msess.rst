climpred.metrics.\_msess
========================

.. currentmodule:: climpred.metrics

.. autofunction:: _msess
