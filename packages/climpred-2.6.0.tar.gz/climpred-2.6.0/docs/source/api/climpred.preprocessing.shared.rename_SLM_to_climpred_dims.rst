climpred.preprocessing.shared.rename\_SLM\_to\_climpred\_dims
=============================================================

.. currentmodule:: climpred.preprocessing.shared

.. autofunction:: rename_SLM_to_climpred_dims
