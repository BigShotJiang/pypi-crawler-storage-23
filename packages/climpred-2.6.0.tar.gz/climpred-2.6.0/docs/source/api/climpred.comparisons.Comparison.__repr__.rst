﻿climpred.comparisons.Comparison.\_\_repr\_\_
=============================================

.. currentmodule:: climpred.comparisons

.. automethod:: Comparison.__repr__
