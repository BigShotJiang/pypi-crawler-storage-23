climpred.classes.PredictionEnsemble.\_\_getitem\_\_
===================================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.__getitem__
