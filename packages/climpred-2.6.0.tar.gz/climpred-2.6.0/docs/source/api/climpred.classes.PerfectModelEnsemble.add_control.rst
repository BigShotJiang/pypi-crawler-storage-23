climpred.classes.PerfectModelEnsemble.add\_control
==================================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.add_control
