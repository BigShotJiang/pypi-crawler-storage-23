climpred.metrics.\_rps
======================

.. currentmodule:: climpred.metrics

.. autofunction:: _rps
