climpred.classes.PredictionEnsemble.chunks
==========================================

.. currentmodule:: climpred.classes

.. autoproperty:: PredictionEnsemble.chunks
