climpred.classes.HindcastEnsemble.generate\_uninitialized
=========================================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.generate_uninitialized
