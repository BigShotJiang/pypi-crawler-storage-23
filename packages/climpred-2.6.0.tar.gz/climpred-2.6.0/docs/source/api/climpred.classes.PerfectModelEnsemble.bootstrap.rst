climpred.classes.PerfectModelEnsemble.bootstrap
===============================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.bootstrap
