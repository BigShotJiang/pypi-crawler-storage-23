climpred.metrics.\_spread
=========================

.. currentmodule:: climpred.metrics

.. autofunction:: _spread
