climpred.metrics.\_mse
======================

.. currentmodule:: climpred.metrics

.. autofunction:: _mse
