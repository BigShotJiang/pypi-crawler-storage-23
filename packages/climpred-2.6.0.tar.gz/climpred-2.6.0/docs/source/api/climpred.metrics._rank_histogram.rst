climpred.metrics.\_rank\_histogram
==================================

.. currentmodule:: climpred.metrics

.. autofunction:: _rank_histogram
