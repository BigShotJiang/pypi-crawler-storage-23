climpred.classes.PerfectModelEnsemble
=====================================

.. currentmodule:: climpred.classes

.. autoclass:: PerfectModelEnsemble


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~PerfectModelEnsemble.__init__
      ~PerfectModelEnsemble.add_control
      ~PerfectModelEnsemble.bootstrap
      ~PerfectModelEnsemble.generate_uninitialized
      ~PerfectModelEnsemble.get_control
      ~PerfectModelEnsemble.get_initialized
      ~PerfectModelEnsemble.get_uninitialized
      ~PerfectModelEnsemble.plot
      ~PerfectModelEnsemble.smooth
      ~PerfectModelEnsemble.verify
