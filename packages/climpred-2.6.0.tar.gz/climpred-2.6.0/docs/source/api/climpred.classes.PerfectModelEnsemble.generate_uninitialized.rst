climpred.classes.PerfectModelEnsemble.generate\_uninitialized
=============================================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.generate_uninitialized
