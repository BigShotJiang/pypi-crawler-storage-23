climpred.classes.PredictionEnsemble.dims
========================================

.. currentmodule:: climpred.classes

.. autoproperty:: PredictionEnsemble.dims
