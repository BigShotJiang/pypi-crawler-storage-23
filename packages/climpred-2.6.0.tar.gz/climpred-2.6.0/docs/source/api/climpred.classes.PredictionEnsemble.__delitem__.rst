climpred.classes.PredictionEnsemble.\_\_delitem\_\_
===================================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.__delitem__
