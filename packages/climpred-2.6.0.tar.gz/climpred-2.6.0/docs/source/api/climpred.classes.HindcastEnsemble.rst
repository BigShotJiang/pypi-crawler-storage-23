climpred.classes.HindcastEnsemble
=================================

.. currentmodule:: climpred.classes

.. autoclass:: HindcastEnsemble


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~HindcastEnsemble.__init__
      ~HindcastEnsemble.add_observations
      ~HindcastEnsemble.add_uninitialized
      ~HindcastEnsemble.bootstrap
      ~HindcastEnsemble.get_initialized
      ~HindcastEnsemble.get_observations
      ~HindcastEnsemble.get_uninitialized
      ~HindcastEnsemble.plot
      ~HindcastEnsemble.remove_bias
      ~HindcastEnsemble.smooth
      ~HindcastEnsemble.verify
