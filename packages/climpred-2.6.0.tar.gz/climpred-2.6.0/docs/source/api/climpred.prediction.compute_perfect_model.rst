climpred.prediction.compute\_perfect\_model
===========================================

.. currentmodule:: climpred.prediction

.. autofunction:: compute_perfect_model
