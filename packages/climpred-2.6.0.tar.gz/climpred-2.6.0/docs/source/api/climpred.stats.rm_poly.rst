climpred.stats.rm\_poly
=======================

.. currentmodule:: climpred.stats

.. autofunction:: rm_poly
