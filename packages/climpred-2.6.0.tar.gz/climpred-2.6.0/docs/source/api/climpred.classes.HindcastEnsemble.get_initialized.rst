climpred.classes.HindcastEnsemble.get\_initialized
==================================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.get_initialized
