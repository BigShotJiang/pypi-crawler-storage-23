climpred.bootstrap.resample\_skill\_resample\_before
====================================================

.. currentmodule:: climpred.bootstrap

.. autofunction:: resample_skill_resample_before
