﻿climpred.metrics.Metric.\_\_init\_\_
=====================================

.. currentmodule:: climpred.metrics

.. automethod:: Metric.__init__
