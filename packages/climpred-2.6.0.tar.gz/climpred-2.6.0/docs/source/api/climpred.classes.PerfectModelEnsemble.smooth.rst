climpred.classes.PerfectModelEnsemble.smooth
============================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.smooth
