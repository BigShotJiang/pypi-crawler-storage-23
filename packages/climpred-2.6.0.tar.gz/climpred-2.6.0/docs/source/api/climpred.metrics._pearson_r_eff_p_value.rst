climpred.metrics.\_pearson\_r\_eff\_p\_value
============================================

.. currentmodule:: climpred.metrics

.. autofunction:: _pearson_r_eff_p_value
