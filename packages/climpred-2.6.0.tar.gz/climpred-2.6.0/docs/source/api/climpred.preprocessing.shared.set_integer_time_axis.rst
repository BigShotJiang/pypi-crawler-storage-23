climpred.preprocessing.shared.set\_integer\_time\_axis
======================================================

.. currentmodule:: climpred.preprocessing.shared

.. autofunction:: set_integer_time_axis
