climpred.graphics.plot\_ensemble\_perfect\_model
================================================

.. currentmodule:: climpred.graphics

.. autofunction:: plot_ensemble_perfect_model
