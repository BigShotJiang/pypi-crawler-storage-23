climpred.classes.PredictionEnsemble.equals
==========================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.equals
