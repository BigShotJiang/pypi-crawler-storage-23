climpred.metrics.\_contingency
==============================

.. currentmodule:: climpred.metrics

.. autofunction:: _contingency
