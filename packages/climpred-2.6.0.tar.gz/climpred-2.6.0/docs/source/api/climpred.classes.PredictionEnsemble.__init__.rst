climpred.classes.PredictionEnsemble.\_\_init\_\_
================================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.__init__
