climpred.utils.convert_init_lead_to_valid_time_lead
===================================================

.. currentmodule:: climpred.utils

.. autofunction:: convert_init_lead_to_valid_time_lead
