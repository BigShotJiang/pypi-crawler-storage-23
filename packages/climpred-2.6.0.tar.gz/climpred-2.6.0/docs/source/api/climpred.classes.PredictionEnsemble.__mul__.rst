climpred.classes.PredictionEnsemble.\_\_mul\_\_
===============================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.__mul__
