climpred.tutorial.load\_dataset
===============================

.. currentmodule:: climpred.tutorial

.. autofunction:: load_dataset
