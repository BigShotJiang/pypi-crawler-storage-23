climpred.classes.HindcastEnsemble.add\_observations
===================================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.add_observations
