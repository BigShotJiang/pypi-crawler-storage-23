climpred.bootstrap.resample\_skill\_exclude\_resample\_dim\_from\_dim
=====================================================================

.. currentmodule:: climpred.bootstrap

.. autofunction:: resample_skill_exclude_resample_dim_from_dim
