climpred.metrics.\_median\_absolute\_error
==========================================

.. currentmodule:: climpred.metrics

.. autofunction:: _median_absolute_error
