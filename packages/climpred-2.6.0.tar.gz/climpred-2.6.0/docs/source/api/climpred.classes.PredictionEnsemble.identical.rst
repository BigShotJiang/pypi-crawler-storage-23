climpred.classes.PredictionEnsemble.identical
=============================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.identical
