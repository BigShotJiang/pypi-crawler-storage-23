climpred.metrics.\_brier\_score
===============================

.. currentmodule:: climpred.metrics

.. autofunction:: _brier_score
