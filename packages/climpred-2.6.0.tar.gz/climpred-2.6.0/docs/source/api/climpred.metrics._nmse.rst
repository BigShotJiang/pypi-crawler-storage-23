climpred.metrics.\_nmse
=======================

.. currentmodule:: climpred.metrics

.. autofunction:: _nmse
