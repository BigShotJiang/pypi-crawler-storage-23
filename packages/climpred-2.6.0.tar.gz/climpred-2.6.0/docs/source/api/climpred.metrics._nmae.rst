climpred.metrics.\_nmae
=======================

.. currentmodule:: climpred.metrics

.. autofunction:: _nmae
