climpred.classes.PerfectModelEnsemble.get\_control
==================================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.get_control
