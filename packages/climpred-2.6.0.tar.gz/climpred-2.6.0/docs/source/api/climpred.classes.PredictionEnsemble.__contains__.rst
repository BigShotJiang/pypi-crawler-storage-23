climpred.classes.PredictionEnsemble.\_\_contains\_\_
====================================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.__contains__
