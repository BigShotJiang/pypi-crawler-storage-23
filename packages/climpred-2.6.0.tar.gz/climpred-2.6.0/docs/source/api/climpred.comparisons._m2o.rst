﻿climpred.comparisons.\_m2o
===========================

.. currentmodule:: climpred.comparisons

.. autofunction:: _m2o
