climpred.metrics.\_rmse
=======================

.. currentmodule:: climpred.metrics

.. autofunction:: _rmse
