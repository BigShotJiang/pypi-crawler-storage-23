climpred.bootstrap.bootstrap\_hindcast
======================================

.. currentmodule:: climpred.bootstrap
