climpred.prediction.compute\_hindcast
=====================================

.. currentmodule:: climpred.prediction
