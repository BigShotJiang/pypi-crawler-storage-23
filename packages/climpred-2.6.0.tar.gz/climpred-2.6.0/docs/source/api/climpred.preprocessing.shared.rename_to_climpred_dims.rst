climpred.preprocessing.shared.rename\_to\_climpred\_dims
========================================================

.. currentmodule:: climpred.preprocessing.shared

.. autofunction:: rename_to_climpred_dims
