﻿climpred.comparisons.Comparison
================================

.. currentmodule:: climpred.comparisons

.. autoclass:: Comparison


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~Comparison.__init__
