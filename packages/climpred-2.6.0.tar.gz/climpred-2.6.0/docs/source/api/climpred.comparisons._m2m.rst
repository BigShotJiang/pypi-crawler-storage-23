﻿climpred.comparisons.\_m2m
===========================

.. currentmodule:: climpred.comparisons

.. autofunction:: _m2m
