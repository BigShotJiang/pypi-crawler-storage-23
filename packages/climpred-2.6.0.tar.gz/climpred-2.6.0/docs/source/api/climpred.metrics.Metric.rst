﻿climpred.metrics.Metric
========================

.. currentmodule:: climpred.metrics

.. autoclass:: Metric


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~Metric.__init__
