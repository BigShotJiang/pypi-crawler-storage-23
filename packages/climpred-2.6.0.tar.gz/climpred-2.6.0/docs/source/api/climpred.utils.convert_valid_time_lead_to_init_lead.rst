climpred.utils.convert_valid_time_lead_to_init_lead
===================================================

.. currentmodule:: climpred.utils

.. autofunction:: convert_valid_time_lead_to_init_lead
