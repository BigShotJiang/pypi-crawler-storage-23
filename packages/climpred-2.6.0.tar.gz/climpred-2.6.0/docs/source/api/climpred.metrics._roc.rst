climpred.metrics.\_roc
======================

.. currentmodule:: climpred.metrics

.. autofunction:: _roc
