climpred.classes.PredictionEnsemble.\_\_truediv\_\_
===================================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.__truediv__
