climpred.classes.HindcastEnsemble.\_\_init\_\_
==============================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.__init__
