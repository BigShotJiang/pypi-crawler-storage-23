climpred.classes.PredictionEnsemble.plot
========================================

.. currentmodule:: climpred.classes

.. automethod:: PredictionEnsemble.plot
