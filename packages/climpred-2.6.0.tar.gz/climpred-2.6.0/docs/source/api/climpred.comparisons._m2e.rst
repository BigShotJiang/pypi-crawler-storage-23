﻿climpred.comparisons.\_m2e
===========================

.. currentmodule:: climpred.comparisons

.. autofunction:: _m2e
