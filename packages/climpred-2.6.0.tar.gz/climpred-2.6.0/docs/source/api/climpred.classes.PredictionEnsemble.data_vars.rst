climpred.classes.PredictionEnsemble.data\_vars
==============================================

.. currentmodule:: climpred.classes

.. autoproperty:: PredictionEnsemble.data_vars
