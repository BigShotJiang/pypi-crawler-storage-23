climpred.metrics.\_threshold\_brier\_score
==========================================

.. currentmodule:: climpred.metrics

.. autofunction:: _threshold_brier_score
