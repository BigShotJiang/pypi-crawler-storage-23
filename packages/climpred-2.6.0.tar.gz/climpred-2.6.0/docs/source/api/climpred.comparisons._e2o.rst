﻿climpred.comparisons.\_e2o
===========================

.. currentmodule:: climpred.comparisons

.. autofunction:: _e2o
