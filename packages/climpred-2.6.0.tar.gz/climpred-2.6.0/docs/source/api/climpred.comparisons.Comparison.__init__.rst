﻿climpred.comparisons.Comparison.\_\_init\_\_
=============================================

.. currentmodule:: climpred.comparisons

.. automethod:: Comparison.__init__
