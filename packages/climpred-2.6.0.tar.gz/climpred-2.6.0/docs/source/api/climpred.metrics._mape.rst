climpred.metrics.\_mape
=======================

.. currentmodule:: climpred.metrics

.. autofunction:: _mape
