climpred.metrics.\_std\_ratio
=============================

.. currentmodule:: climpred.metrics

.. autofunction:: _std_ratio
