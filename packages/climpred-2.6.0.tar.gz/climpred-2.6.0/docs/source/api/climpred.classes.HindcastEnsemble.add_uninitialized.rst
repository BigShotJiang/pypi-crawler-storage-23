climpred.classes.HindcastEnsemble.add\_uninitialized
====================================================

.. currentmodule:: climpred.classes

.. automethod:: HindcastEnsemble.add_uninitialized
