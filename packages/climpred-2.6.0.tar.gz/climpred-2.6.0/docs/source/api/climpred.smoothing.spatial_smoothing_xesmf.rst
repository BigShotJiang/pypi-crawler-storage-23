climpred.smoothing.spatial\_smoothing\_xesmf
============================================

.. currentmodule:: climpred.smoothing

.. autofunction:: spatial_smoothing_xesmf
