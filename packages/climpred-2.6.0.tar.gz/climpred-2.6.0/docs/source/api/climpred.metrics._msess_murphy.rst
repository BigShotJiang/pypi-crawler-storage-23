climpred.metrics.\_msess\_murphy
================================

.. currentmodule:: climpred.metrics

.. autofunction:: _msess_murphy
