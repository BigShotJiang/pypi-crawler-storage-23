climpred.classes.PerfectModelEnsemble.plot
==========================================

.. currentmodule:: climpred.classes

.. automethod:: PerfectModelEnsemble.plot
