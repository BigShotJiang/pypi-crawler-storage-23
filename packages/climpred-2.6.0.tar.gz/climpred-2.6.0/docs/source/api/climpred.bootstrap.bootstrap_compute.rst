climpred.bootstrap.bootstrap\_compute
=====================================

.. currentmodule:: climpred.bootstrap
