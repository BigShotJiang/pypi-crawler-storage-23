climpred.metrics.\_less
=======================

.. currentmodule:: climpred.metrics

.. autofunction:: _less
