climpred.stats.rm\_trend
========================

.. currentmodule:: climpred.stats

.. autofunction:: rm_trend
