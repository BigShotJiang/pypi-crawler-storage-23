climpred.metrics.\_reliability
==============================

.. currentmodule:: climpred.metrics

.. autofunction:: _reliability
