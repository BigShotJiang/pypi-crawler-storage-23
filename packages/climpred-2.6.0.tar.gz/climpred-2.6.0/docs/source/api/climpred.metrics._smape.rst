climpred.metrics.\_smape
========================

.. currentmodule:: climpred.metrics

.. autofunction:: _smape
