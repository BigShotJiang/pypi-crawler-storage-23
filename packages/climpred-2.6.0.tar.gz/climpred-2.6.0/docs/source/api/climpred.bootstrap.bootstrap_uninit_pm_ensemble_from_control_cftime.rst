climpred.bootstrap.bootstrap\_uninit\_pm\_ensemble\_from\_control\_cftime
=========================================================================

.. currentmodule:: climpred.bootstrap

.. autofunction:: bootstrap_uninit_pm_ensemble_from_control_cftime
