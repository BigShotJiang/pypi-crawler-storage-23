climpred.metrics.\_spearman\_r\_p\_value
========================================

.. currentmodule:: climpred.metrics

.. autofunction:: _spearman_r_p_value
