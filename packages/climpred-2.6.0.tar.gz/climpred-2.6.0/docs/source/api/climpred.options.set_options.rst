climpred.options.set\_options
=============================

.. currentmodule:: climpred.options

.. autoclass:: set_options


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~set_options.__init__
