climpred.metrics.\_crps
=======================

.. currentmodule:: climpred.metrics

.. autofunction:: _crps
