climpred.metrics.\_get\_norm\_factor
====================================

.. currentmodule:: climpred.metrics

.. autofunction:: _get_norm_factor
