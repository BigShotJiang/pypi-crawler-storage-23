**********
Literature
**********

References used in the documentation and used for studying predictability.

.. bibliography::
  :all:
