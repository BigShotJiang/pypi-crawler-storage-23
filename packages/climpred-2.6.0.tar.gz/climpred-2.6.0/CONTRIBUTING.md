A guide on how to contribute to `climpred` can be found on our documentation [here](https://climpred.readthedocs.io/en/stable/contributing.html).
