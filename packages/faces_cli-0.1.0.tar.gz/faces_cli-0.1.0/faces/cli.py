"""Root click application for the Faces CLI."""
from __future__ import annotations

import json
import sys
from typing import Optional

import click

from .client import FacesClient, FacesAPIError
from .config import resolve_base_url, resolve_token, resolve_api_key
from .commands.auth import auth_group
from .commands.faces import face_group
from .commands.chat import chat_group
from .commands.compile import compile_group
from .commands.keys import keys_group
from .commands.billing import billing_group
from .commands.account import account_group
from .commands.config_cmd import config_group


# Shared context object passed to all subcommands
class AppContext:
    def __init__(
        self,
        client: FacesClient,
        output_json: bool,
    ):
        self.client = client
        self.output_json = output_json

    def output(self, data: object) -> None:
        if self.output_json:
            click.echo(json.dumps(data, indent=2, default=str))
        else:
            _human_print(data)


def _human_print(data: object, indent: int = 0) -> None:
    pad = "  " * indent
    if isinstance(data, dict):
        for k, v in data.items():
            if isinstance(v, (dict, list)):
                click.echo(f"{pad}{k}:")
                _human_print(v, indent + 1)
            else:
                click.echo(f"{pad}{k}: {v}")
    elif isinstance(data, list):
        for i, item in enumerate(data):
            click.echo(f"{pad}[{i}]")
            _human_print(item, indent + 1)
    else:
        click.echo(f"{pad}{data}")


pass_app = click.make_pass_decorator(AppContext)


@click.group()
@click.option("--base-url", envvar="FACES_BASE_URL", default=None, help="API base URL")
@click.option("--token", envvar="FACES_TOKEN", default=None, help="JWT override")
@click.option("--api-key", envvar="FACES_API_KEY", default=None, help="API key override")
@click.option("--json/--no-json", "output_json", default=True, help="JSON output (default)")
@click.pass_context
def cli(ctx: click.Context, base_url: Optional[str], token: Optional[str], api_key: Optional[str], output_json: bool):
    """Faces AI platform CLI."""
    ctx.ensure_object(dict)
    resolved_base = resolve_base_url(base_url)
    resolved_token = resolve_token(token)
    resolved_key = resolve_api_key(api_key)

    client = FacesClient(
        base_url=resolved_base,
        token=resolved_token,
        api_key=resolved_key,
    )
    ctx.obj = AppContext(client=client, output_json=output_json)


cli.add_command(auth_group, name="auth")
cli.add_command(face_group, name="face")
cli.add_command(chat_group)
cli.add_command(compile_group, name="compile")
cli.add_command(keys_group, name="keys")
cli.add_command(billing_group, name="billing")
cli.add_command(account_group, name="account")
cli.add_command(config_group, name="config")


def main():
    import httpx as _httpx
    try:
        cli(standalone_mode=False)
    except FacesAPIError as e:
        click.echo(f"Error {e.status_code}: {e.message}", err=True)
        sys.exit(1)
    except _httpx.ConnectError:
        click.echo("Error: could not connect to the API. Check --base-url or FACES_BASE_URL.", err=True)
        sys.exit(1)
    except _httpx.TimeoutException:
        click.echo("Error: request timed out.", err=True)
        sys.exit(1)
    except _httpx.RequestError as e:
        click.echo(f"Network error: {e}", err=True)
        sys.exit(1)
    except click.exceptions.Exit as e:
        sys.exit(e.code)
    except click.exceptions.Abort:
        click.echo("Aborted.", err=True)
        sys.exit(1)
    except click.exceptions.UsageError as e:
        click.echo(f"Usage error: {e.format_message()}", err=True)
        sys.exit(2)
    except click.ClickException as e:
        click.echo(f"Error: {e.format_message()}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
