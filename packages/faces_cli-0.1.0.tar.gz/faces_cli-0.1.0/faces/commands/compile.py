"""Compile commands: documents and threads CRUD + prepare/sync."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import click

from ..client import FacesAPIError


@click.group("compile")
def compile_group():
    """Manage documents and threads for face memory compilation."""


# ---------------------------------------------------------------------------
# Document sub-group
# ---------------------------------------------------------------------------

@compile_group.group("doc")
def doc_group():
    """Document operations."""


@doc_group.command("create")
@click.argument("face_id")
@click.option("--label", default=None, help="Document label/title")
@click.option("--content", default=None, help="Inline text content")
@click.option("--file", "file_path", default=None, type=click.Path(exists=True), help="Read content from file")
@click.pass_context
def doc_create(ctx: click.Context, face_id: str, label: Optional[str], content: Optional[str], file_path: Optional[str]):
    """Submit a document to a face."""
    app = ctx.obj
    if file_path:
        content = Path(file_path).read_text()
    if not content:
        raise click.UsageError("Provide --content or --file.")

    payload: dict = {"content": content}
    if label:
        payload["label"] = label

    try:
        data = app.client.post(f"/v1/faces/{face_id}/compile/documents", json=payload)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@doc_group.command("list")
@click.argument("face_id")
@click.pass_context
def doc_list(ctx: click.Context, face_id: str):
    """List documents for a face."""
    app = ctx.obj
    try:
        data = app.client.get(f"/v1/faces/{face_id}/compile/documents")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@doc_group.command("get")
@click.argument("doc_id")
@click.pass_context
def doc_get(ctx: click.Context, doc_id: str):
    """Get a document by ID."""
    app = ctx.obj
    try:
        data = app.client.get(f"/v1/compile/documents/{doc_id}")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@doc_group.command("prepare")
@click.argument("doc_id")
@click.pass_context
def doc_prepare(ctx: click.Context, doc_id: str):
    """Run LLM extraction pipeline on a document."""
    app = ctx.obj
    try:
        data = app.client.post(f"/v1/compile/documents/{doc_id}/prepare")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@doc_group.command("sync")
@click.argument("doc_id")
@click.option("--yes", is_flag=True, help="Skip confirmation (quota will be charged)")
@click.pass_context
def doc_sync(ctx: click.Context, doc_id: str, yes: bool):
    """Sync a document to face memory (charges compile quota)."""
    app = ctx.obj
    if not yes:
        click.confirm("Syncing to face memory charges compile quota. Continue?", abort=True)
    try:
        data = app.client.post(f"/v1/compile/documents/{doc_id}/sync")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@doc_group.command("delete")
@click.argument("doc_id")
@click.pass_context
def doc_delete(ctx: click.Context, doc_id: str):
    """Delete a document."""
    app = ctx.obj
    try:
        data = app.client.delete(f"/v1/compile/documents/{doc_id}")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


# ---------------------------------------------------------------------------
# Thread sub-group
# ---------------------------------------------------------------------------

@compile_group.group("thread")
def thread_group():
    """Thread operations."""


@thread_group.command("create")
@click.argument("face_id")
@click.option("--label", default=None, help="Thread label")
@click.pass_context
def thread_create(ctx: click.Context, face_id: str, label: Optional[str]):
    """Start a new thread for a face."""
    app = ctx.obj
    payload: dict = {}
    if label:
        payload["label"] = label

    try:
        data = app.client.post(f"/v1/faces/{face_id}/compile/threads", json=payload)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@thread_group.command("list")
@click.argument("face_id")
@click.pass_context
def thread_list(ctx: click.Context, face_id: str):
    """List threads for a face."""
    app = ctx.obj
    try:
        data = app.client.get(f"/v1/faces/{face_id}/compile/threads")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@thread_group.command("message")
@click.argument("thread_id")
@click.option("--message", "-m", required=True, help="User message to append")
@click.pass_context
def thread_message(ctx: click.Context, thread_id: str, message: str):
    """Send a user message to a thread."""
    app = ctx.obj
    try:
        data = app.client.post(
            f"/v1/compile/threads/{thread_id}/messages",
            json={"role": "user", "content": message},
        )
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@thread_group.command("sync")
@click.argument("thread_id")
@click.pass_context
def thread_sync(ctx: click.Context, thread_id: str):
    """Archive and sync a thread to face memory."""
    app = ctx.obj
    try:
        data = app.client.post(f"/v1/compile/threads/{thread_id}/sync")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)
