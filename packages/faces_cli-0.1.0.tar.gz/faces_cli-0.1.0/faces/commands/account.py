"""Account commands: state."""
from __future__ import annotations

import click

from ..client import FacesAPIError


@click.group("account")
def account_group():
    """Account-level operations."""


@account_group.command("state")
@click.pass_context
def state(ctx: click.Context):
    """Full account routing state (plan, balance, onboarding)."""
    app = ctx.obj
    try:
        data = app.client.get("/v1/account/state")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)
