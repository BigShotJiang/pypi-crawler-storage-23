"""Authentication commands: login, logout, register, whoami, refresh."""
from __future__ import annotations

import click

from ..config import save_config, clear_config, get_config, resolve_base_url
from ..client import FacesClient, FacesAPIError


@click.group()
def auth_group():
    """Login, logout, register, and account identity."""


@auth_group.command("login")
@click.option("--email", prompt=True, help="Account email")
@click.option("--password", prompt=True, hide_input=True, help="Account password")
@click.pass_context
def login(ctx: click.Context, email: str, password: str):
    """Login and save JWT credentials."""
    app = ctx.obj
    try:
        data = app.client.post_no_auth(
            "/v1/auth/login",
            json={"email": email, "password": password},
        )
    except FacesAPIError as e:
        raise click.ClickException(f"Login failed ({e.status_code}): {e.message}")

    token = data.get("access_token") or data.get("token")
    user_id = data.get("user_id") or data.get("id") or (data.get("user") or {}).get("id")

    if not token:
        raise click.ClickException(f"Unexpected response: {data}")

    save_config({"token": token, "user_id": str(user_id) if user_id else None})
    app.output({"status": "logged_in", "user_id": user_id})


@auth_group.command("logout")
@click.pass_context
def logout(ctx: click.Context):
    """Clear saved credentials."""
    clear_config()
    click.echo("Logged out. Credentials cleared.")


@auth_group.command("register")
@click.option("--email", prompt=True, help="Email address")
@click.option("--password", prompt=True, hide_input=True, confirmation_prompt=True, help="Password")
@click.option("--name", prompt=True, help="Display name")
@click.option("--username", prompt=True, help="Username (lowercase, dashes, numbers)")
@click.option("--invite-key", default=None, help="Invite key (if required)")
@click.pass_context
def register(ctx: click.Context, email: str, password: str, name: str, username: str, invite_key: str):
    """Create a new Faces account."""
    app = ctx.obj
    payload: dict = {
        "email": email,
        "password": password,
        "name": name,
        "username": username,
    }
    if invite_key:
        payload["invite_key"] = invite_key

    try:
        data = app.client.post_no_auth("/v1/auth/register", json=payload)
    except FacesAPIError as e:
        raise click.ClickException(f"Registration failed ({e.status_code}): {e.message}")

    token = data.get("access_token") or data.get("token")
    if token:
        save_config({"token": token})

    app.output(data)


@auth_group.command("whoami")
@click.pass_context
def whoami(ctx: click.Context):
    """Print current user profile."""
    app = ctx.obj
    try:
        data = app.client.get("/v1/auth/me", require_jwt=True)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@auth_group.command("refresh")
@click.pass_context
def refresh(ctx: click.Context):
    """Exchange current JWT for a fresh one."""
    app = ctx.obj
    try:
        data = app.client.post("/v1/auth/refresh", require_jwt=True)
    except FacesAPIError as e:
        raise click.ClickException(f"Refresh failed ({e.status_code}): {e.message}")

    token = data.get("access_token") or data.get("token")
    if token:
        save_config({"token": token})
        click.echo("Token refreshed and saved.")

    app.output(data)
