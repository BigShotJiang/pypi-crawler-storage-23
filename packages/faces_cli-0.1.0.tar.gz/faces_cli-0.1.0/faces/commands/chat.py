"""Inference commands: chat, messages, responses."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import click

from ..client import FacesAPIError


@click.group("chat")
def chat_group():
    """Run inference via a face (chat, messages, responses)."""


@chat_group.command("chat")
@click.argument("face_username")
@click.option("--message", "-m", multiple=True, required=True, help="User message (repeatable)")
@click.option("--llm", default=None, help="LLM override (appended as face@llm)")
@click.option("--system", default=None, help="System prompt override")
@click.option("--stream", is_flag=True, help="Stream the response")
@click.option("--max-tokens", default=None, type=int, help="Max tokens")
@click.option("--temperature", default=None, type=float, help="Temperature")
@click.option("--file", "msg_file", default=None, type=click.Path(exists=True), help="Read message from file")
@click.pass_context
def chat(
    ctx: click.Context,
    face_username: str,
    message: tuple,
    llm: Optional[str],
    system: Optional[str],
    stream: bool,
    max_tokens: Optional[int],
    temperature: Optional[float],
    msg_file: Optional[str],
):
    """OpenAI-compatible chat completion via a face."""
    app = ctx.obj

    messages = []
    if system:
        messages.append({"role": "system", "content": system})

    if msg_file:
        content = Path(msg_file).read_text()
        messages.append({"role": "user", "content": content})
    else:
        for m in message:
            messages.append({"role": "user", "content": m})

    model = f"{face_username}@{llm}" if llm else face_username

    payload: dict = {
        "model": model,
        "messages": messages,
        "stream": stream,
    }
    if max_tokens:
        payload["max_tokens"] = max_tokens
    if temperature is not None:
        payload["temperature"] = temperature

    try:
        if stream:
            for line in app.client.stream_post("/v1/chat/completions", json=payload):
                if line.startswith("data: "):
                    chunk = line[6:]
                    if chunk.strip() == "[DONE]":
                        break
                    try:
                        obj = json.loads(chunk)
                        delta = obj.get("choices", [{}])[0].get("delta", {}).get("content", "")
                        if delta:
                            sys.stdout.write(delta)
                            sys.stdout.flush()
                    except json.JSONDecodeError:
                        pass
            sys.stdout.write("\n")
        else:
            data = app.client.post("/v1/chat/completions", json=payload)
            if app.output_json:
                app.output(data)
            else:
                content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
                click.echo(content)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")


@chat_group.command("messages")
@click.argument("face_model")
@click.option("--message", "-m", multiple=True, required=True, help="User message (repeatable)")
@click.option("--system", default=None, help="System prompt")
@click.option("--stream", is_flag=True, help="Stream the response")
@click.option("--max-tokens", default=1024, type=int, help="Max tokens")
@click.pass_context
def messages(
    ctx: click.Context,
    face_model: str,
    message: tuple,
    system: Optional[str],
    stream: bool,
    max_tokens: int,
):
    """Anthropic Messages API proxy via a face (e.g. face@claude-sonnet-4-6)."""
    app = ctx.obj

    msgs = [{"role": "user", "content": m} for m in message]

    payload: dict = {
        "model": face_model,
        "messages": msgs,
        "max_tokens": max_tokens,
        "stream": stream,
    }
    if system:
        payload["system"] = system

    try:
        if stream:
            for line in app.client.stream_post("/v1/messages", json=payload):
                if line.startswith("data: "):
                    chunk = line[6:]
                    if chunk.strip() in ("[DONE]", ""):
                        continue
                    try:
                        obj = json.loads(chunk)
                        event_kind = obj.get("type", "")
                        if event_kind == "content_block_delta":
                            delta = obj.get("delta", {}).get("text", "")
                            if delta:
                                sys.stdout.write(delta)
                                sys.stdout.flush()
                    except json.JSONDecodeError:
                        pass
            sys.stdout.write("\n")
        else:
            data = app.client.post("/v1/messages", json=payload)
            if app.output_json:
                app.output(data)
            else:
                content = ""
                for block in data.get("content", []):
                    if block.get("type") == "text":
                        content += block.get("text", "")
                click.echo(content)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")


@chat_group.command("responses")
@click.argument("face_model")
@click.option("--message", "-m", required=True, help="User input message")
@click.option("--instructions", default=None, help="System instructions")
@click.option("--stream", is_flag=True, help="Stream the response")
@click.pass_context
def responses(
    ctx: click.Context,
    face_model: str,
    message: str,
    instructions: Optional[str],
    stream: bool,
):
    """OpenAI Responses API proxy via a face."""
    app = ctx.obj

    payload: dict = {
        "model": face_model,
        "input": message,
        "stream": stream,
    }
    if instructions:
        payload["instructions"] = instructions

    try:
        if stream:
            for line in app.client.stream_post("/v1/responses", json=payload):
                if line.startswith("data: "):
                    chunk = line[6:]
                    if chunk.strip() in ("[DONE]", ""):
                        continue
                    try:
                        obj = json.loads(chunk)
                        event_kind = obj.get("type", "")
                        if event_kind == "response.output_text.delta":
                            delta = obj.get("delta", "")
                            if delta:
                                sys.stdout.write(delta)
                                sys.stdout.flush()
                    except json.JSONDecodeError:
                        pass
            sys.stdout.write("\n")
        else:
            data = app.client.post("/v1/responses", json=payload)
            if app.output_json:
                app.output(data)
            else:
                output_text = ""
                for item in data.get("output", []):
                    for block in item.get("content", []):
                        if block.get("type") == "output_text":
                            output_text += block.get("text", "")
                click.echo(output_text)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
