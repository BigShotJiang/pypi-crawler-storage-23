"""API key management commands: create, list, revoke, update."""
from __future__ import annotations

from typing import Optional

import click

from ..client import FacesAPIError


@click.group("keys")
def keys_group():
    """Manage API keys (JWT required)."""


@keys_group.command("create")
@click.option("--name", required=True, help="Key name/label")
@click.option("--expires-days", default=None, type=int, help="Expiry in days (omit for no expiry)")
@click.option("--budget", default=None, type=float, help="Spend budget in USD")
@click.option("--face", "faces", multiple=True, help="Allowed face username (repeatable)")
@click.option("--model", "models", multiple=True, help="Allowed model name (repeatable)")
@click.pass_context
def create(
    ctx: click.Context,
    name: str,
    expires_days: Optional[int],
    budget: Optional[float],
    faces: tuple,
    models: tuple,
):
    """Create a new API key (JWT required)."""
    app = ctx.obj
    payload: dict = {"name": name}
    if expires_days is not None:
        payload["expires_days"] = expires_days
    if budget is not None:
        payload["budget"] = budget
    if faces:
        payload["allowed_faces"] = list(faces)
    if models:
        payload["allowed_models"] = list(models)

    try:
        data = app.client.post("/v1/api-keys", require_jwt=True, json=payload)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@keys_group.command("list")
@click.pass_context
def list_keys(ctx: click.Context):
    """List all API keys (JWT required)."""
    app = ctx.obj
    try:
        data = app.client.get("/v1/api-keys", require_jwt=True)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@keys_group.command("revoke")
@click.argument("key_id")
@click.option("--yes", is_flag=True, help="Skip confirmation")
@click.pass_context
def revoke(ctx: click.Context, key_id: str, yes: bool):
    """Revoke an API key (JWT required)."""
    app = ctx.obj
    if not yes:
        click.confirm(f"Revoke key '{key_id}'?", abort=True)
    try:
        data = app.client.delete(f"/v1/api-keys/{key_id}", require_jwt=True)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@keys_group.command("update")
@click.argument("key_id")
@click.option("--name", default=None, help="New key name")
@click.option("--budget", default=None, type=float, help="New spend budget in USD")
@click.option("--reset-spent", is_flag=True, help="Reset spent amount to zero")
@click.pass_context
def update(
    ctx: click.Context,
    key_id: str,
    name: Optional[str],
    budget: Optional[float],
    reset_spent: bool,
):
    """Update API key metadata (JWT required)."""
    app = ctx.obj
    payload: dict = {}
    if name:
        payload["name"] = name
    if budget is not None:
        payload["budget"] = budget
    if reset_spent:
        payload["reset_spent"] = True

    if not payload:
        raise click.UsageError("Provide at least one field to update.")

    try:
        data = app.client.patch(f"/v1/api-keys/{key_id}", require_jwt=True, json=payload)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)
