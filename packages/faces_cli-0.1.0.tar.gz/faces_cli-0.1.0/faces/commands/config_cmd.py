"""Config commands: set, show, clear."""
from __future__ import annotations

import click

from ..config import set_config_key, masked_config, clear_config


@click.group("config")
def config_group():
    """Manage local CLI configuration."""


@config_group.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str):
    """Set a config value (e.g. base_url, api_key, token)."""
    set_config_key(key, value)
    click.echo(f"Set {key}.")


@config_group.command("show")
def config_show():
    """Print current config (credentials are masked)."""
    import json
    data = masked_config()
    if not data:
        click.echo("No config found at ~/.faces/config.json")
    else:
        click.echo(json.dumps(data, indent=2))


@config_group.command("clear")
@click.option("--yes", is_flag=True, help="Skip confirmation")
def config_clear(yes: bool):
    """Delete all saved credentials and config."""
    if not yes:
        click.confirm("Delete all saved credentials?", abort=True)
    clear_config()
    click.echo("Config cleared.")
