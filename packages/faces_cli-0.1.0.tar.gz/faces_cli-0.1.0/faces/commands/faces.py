"""Face management commands: create, list, get, update, delete, stats."""
from __future__ import annotations

import click

from ..client import FacesAPIError


@click.group("face")
def face_group():
    """Create and manage AI face personas."""


@face_group.command("create")
@click.option("--name", required=True, help="Display name")
@click.option("--username", required=True, help="Unique username slug")
@click.option("--attr", "attrs", multiple=True, metavar="KEY=VALUE", help="Attribute (repeatable)")
@click.option("--tool", "tools", multiple=True, help="Tool name to enable (repeatable)")
@click.pass_context
def create(ctx: click.Context, name: str, username: str, attrs: tuple, tools: tuple):
    """Create a new face."""
    app = ctx.obj
    parsed_attrs: dict = {}
    for a in attrs:
        if "=" not in a:
            raise click.BadParameter(f"Attributes must be KEY=VALUE, got: {a}")
        k, _, v = a.partition("=")
        parsed_attrs[k.strip()] = v.strip()

    payload: dict = {"name": name, "username": username}
    if parsed_attrs:
        payload["facts"] = parsed_attrs
    if tools:
        payload["tools"] = list(tools)

    try:
        data = app.client.post("/v1/faces", json=payload)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@face_group.command("list")
@click.pass_context
def list_faces(ctx: click.Context):
    """List all owned faces."""
    app = ctx.obj
    try:
        data = app.client.get("/v1/faces")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@face_group.command("get")
@click.argument("face_id")
@click.pass_context
def get_face(ctx: click.Context, face_id: str):
    """Get details for a face by ID or username."""
    app = ctx.obj
    try:
        data = app.client.get(f"/v1/faces/{face_id}")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@face_group.command("update")
@click.argument("face_id")
@click.option("--name", default=None, help="New display name")
@click.option("--attr", "attrs", multiple=True, metavar="KEY=VALUE", help="Update attribute (repeatable)")
@click.option("--tool", "tools", multiple=True, help="Tool names to set (replaces list)")
@click.pass_context
def update_face(ctx: click.Context, face_id: str, name: str, attrs: tuple, tools: tuple):
    """Update a face's metadata."""
    app = ctx.obj
    payload: dict = {}
    if name:
        payload["name"] = name
    if attrs:
        parsed: dict = {}
        for a in attrs:
            if "=" not in a:
                raise click.BadParameter(f"Attributes must be KEY=VALUE, got: {a}")
            k, _, v = a.partition("=")
            parsed[k.strip()] = v.strip()
        payload["facts"] = parsed
    if tools:
        payload["tools"] = list(tools)

    if not payload:
        raise click.UsageError("Provide at least one field to update.")

    try:
        data = app.client.patch(f"/v1/faces/{face_id}", json=payload)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@face_group.command("delete")
@click.argument("face_id")
@click.option("--yes", is_flag=True, help="Skip confirmation")
@click.pass_context
def delete_face(ctx: click.Context, face_id: str, yes: bool):
    """Delete a face permanently."""
    app = ctx.obj
    if not yes:
        click.confirm(f"Delete face '{face_id}'? This cannot be undone.", abort=True)
    try:
        data = app.client.delete(f"/v1/faces/{face_id}")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@face_group.command("stats")
@click.pass_context
def stats(ctx: click.Context):
    """Compile and chat stats for all owned faces."""
    app = ctx.obj
    try:
        data = app.client.get("/v1/faces/stats")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@face_group.command("upload")
@click.argument("face_id")
@click.option("--file", "file_path", required=True, type=click.Path(exists=True), help="File to upload")
@click.option("--kind", "doc_kind", default="document", type=click.Choice(["document", "thread"]), help="Upload kind: document or thread")
@click.pass_context
def upload(ctx: click.Context, face_id: str, file_path: str, doc_kind: str):
    """Upload a file (text/PDF/audio/video) to a face."""
    import os
    app = ctx.obj
    filename = os.path.basename(file_path)
    with open(file_path, "rb") as fh:
        try:
            data = app.client.post(
                f"/v1/faces/{face_id}/upload",
                files={"file": (filename, fh)},
                data={"type": doc_kind},
            )
        except FacesAPIError as e:
            raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)
