"""Billing commands: balance, subscription, quota, usage, topup, checkout, card-setup."""
from __future__ import annotations

from typing import Optional

import click

from ..client import FacesAPIError


@click.group("billing")
def billing_group():
    """Billing, credits, and subscription management."""


@billing_group.command("balance")
@click.pass_context
def balance(ctx: click.Context):
    """Show credit balance and payment method status."""
    app = ctx.obj
    try:
        data = app.client.get("/v1/billing/balance")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@billing_group.command("subscription")
@click.pass_context
def subscription(ctx: click.Context):
    """Show current plan, face count, and renewal date."""
    app = ctx.obj
    try:
        data = app.client.get("/v1/billing/subscription")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@billing_group.command("quota")
@click.pass_context
def quota(ctx: click.Context):
    """Show compile token quota and per-face stats."""
    app = ctx.obj
    try:
        data = app.client.get("/v1/billing/compile-quota")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@billing_group.command("usage")
@click.option("--group-by", default=None, type=click.Choice(["api_key", "model", "llm", "date"]), help="Group results")
@click.option("--from", "from_date", default=None, help="Start date (YYYY-MM-DD)")
@click.option("--to", "to_date", default=None, help="End date (YYYY-MM-DD)")
@click.pass_context
def usage(ctx: click.Context, group_by: Optional[str], from_date: Optional[str], to_date: Optional[str]):
    """Aggregated usage analytics."""
    app = ctx.obj
    params: dict = {}
    if group_by:
        params["group_by"] = group_by
    if from_date:
        params["from"] = from_date
    if to_date:
        params["to"] = to_date

    try:
        data = app.client.get("/v1/billing/usage", params=params)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@billing_group.command("topup")
@click.option("--amount", required=True, type=float, help="Top-up amount in USD (min $1)")
@click.option("--payment-ref", default=None, help="Payment reference (admin/test path)")
@click.pass_context
def topup(ctx: click.Context, amount: float, payment_ref: Optional[str]):
    """Top up credit balance using saved payment method."""
    app = ctx.obj
    if amount < 1.0:
        raise click.BadParameter("Minimum topup is $1.00", param_hint="--amount")

    payload: dict = {"amount": amount}
    if payment_ref:
        payload["payment_ref"] = payment_ref

    try:
        data = app.client.post("/v1/billing/topup", json=payload)
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@billing_group.command("checkout")
@click.option("--plan", required=True, type=click.Choice(["standard", "pro"]), help="Plan to upgrade to")
@click.pass_context
def checkout(ctx: click.Context, plan: str):
    """Get a Stripe checkout URL to upgrade your subscription plan."""
    app = ctx.obj
    try:
        data = app.client.post(f"/v1/billing/checkout?plan={plan}")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)


@billing_group.command("card-setup")
@click.pass_context
def card_setup(ctx: click.Context):
    """Get a Stripe card setup URL to save a payment method."""
    app = ctx.obj
    try:
        data = app.client.post("/v1/billing/card-setup")
    except FacesAPIError as e:
        raise click.ClickException(f"Error ({e.status_code}): {e.message}")
    app.output(data)
