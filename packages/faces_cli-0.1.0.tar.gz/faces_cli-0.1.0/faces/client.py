"""Thin httpx wrapper for the Faces platform API."""
from __future__ import annotations

import sys
from typing import Any, Iterator, Optional

import httpx


class FacesAPIError(Exception):
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(message)


def _raise_for_error(resp: httpx.Response) -> None:
    if resp.is_success:
        return
    try:
        body = resp.json()
        detail = body.get("detail") or body.get("error") or body.get("message") or str(body)
    except Exception:
        detail = resp.text or "unknown error"

    # Surface known 402/403 patterns cleanly
    if resp.status_code == 402:
        raise FacesAPIError(402, f"Payment required: {detail}")
    if resp.status_code == 403:
        msg = str(detail)
        if "budget" in msg.lower():
            raise FacesAPIError(403, f"API key budget exceeded: {detail}")
        if "face" in msg.lower() or "allowlist" in msg.lower():
            raise FacesAPIError(403, f"API key not permitted to access this face: {detail}")
        if "model" in msg.lower():
            raise FacesAPIError(403, f"API key not permitted to use this model: {detail}")
        raise FacesAPIError(403, f"Forbidden: {detail}")

    raise FacesAPIError(resp.status_code, detail)


class FacesClient:
    def __init__(
        self,
        base_url: str,
        token: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: float = 60.0,
    ):
        self.base_url = base_url.rstrip("/")
        self._token = token
        self._api_key = api_key
        self._timeout = timeout

    def _auth_header(self, require_jwt: bool = False) -> dict[str, str]:
        if require_jwt:
            if not self._token:
                print(
                    "Error: this command requires a full login. Run: faces auth login",
                    file=sys.stderr,
                )
                sys.exit(1)
            return {"Authorization": f"Bearer {self._token}"}

        if self._token:
            return {"Authorization": f"Bearer {self._token}"}
        if self._api_key:
            return {"Authorization": f"Bearer {self._api_key}"}

        print(
            "Error: no credentials found. Run: faces auth login  or set FACES_API_KEY",
            file=sys.stderr,
        )
        sys.exit(1)

    def _url(self, path: str) -> str:
        return f"{self.base_url}/{path.lstrip('/')}"

    def get(self, path: str, require_jwt: bool = False, **kwargs: Any) -> Any:
        headers = self._auth_header(require_jwt)
        resp = httpx.get(self._url(path), headers=headers, timeout=self._timeout, **kwargs)
        _raise_for_error(resp)
        return resp.json()

    def post(
        self,
        path: str,
        require_jwt: bool = False,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        params: Any = None,
    ) -> Any:
        headers = self._auth_header(require_jwt)
        resp = httpx.post(
            self._url(path),
            headers=headers,
            json=json,
            data=data,
            files=files,
            params=params,
            timeout=self._timeout,
        )
        _raise_for_error(resp)
        return resp.json()

    def patch(self, path: str, require_jwt: bool = False, json: Any = None) -> Any:
        headers = self._auth_header(require_jwt)
        resp = httpx.patch(self._url(path), headers=headers, json=json, timeout=self._timeout)
        _raise_for_error(resp)
        return resp.json()

    def put(self, path: str, require_jwt: bool = False, json: Any = None) -> Any:
        headers = self._auth_header(require_jwt)
        resp = httpx.put(self._url(path), headers=headers, json=json, timeout=self._timeout)
        _raise_for_error(resp)
        return resp.json()

    def delete(self, path: str, require_jwt: bool = False) -> Any:
        headers = self._auth_header(require_jwt)
        resp = httpx.delete(self._url(path), headers=headers, timeout=self._timeout)
        _raise_for_error(resp)
        try:
            return resp.json()
        except Exception:
            return {"status": "ok"}

    def stream_post(
        self,
        path: str,
        require_jwt: bool = False,
        json: Any = None,
    ) -> Iterator[str]:
        headers = self._auth_header(require_jwt)
        with httpx.stream(
            "POST",
            self._url(path),
            headers=headers,
            json=json,
            timeout=self._timeout,
        ) as resp:
            if not resp.is_success:
                resp.read()
                _raise_for_error(resp)
            for line in resp.iter_lines():
                if line:
                    yield line

    def post_no_auth(self, path: str, json: Any = None) -> Any:
        resp = httpx.post(self._url(path), json=json, timeout=self._timeout)
        _raise_for_error(resp)
        return resp.json()
