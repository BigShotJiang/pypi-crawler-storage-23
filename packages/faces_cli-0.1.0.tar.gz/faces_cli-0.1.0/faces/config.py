"""Credential storage and config resolution for the Faces CLI."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".faces"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_BASE_URL = "https://api.faces.sh"

_MASK_KEYS = {"token", "api_key"}


def _load_raw() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(data: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    existing = _load_raw()
    existing.update(data)
    CONFIG_FILE.write_text(json.dumps(existing, indent=2))
    CONFIG_FILE.chmod(0o600)


def clear_config() -> None:
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()


def get_config() -> dict:
    return _load_raw()


def masked_config() -> dict:
    raw = _load_raw()
    return {
        k: ("***" if k in _MASK_KEYS and v else v)
        for k, v in raw.items()
    }


def resolve_base_url(override: Optional[str] = None) -> str:
    return (
        override
        or os.environ.get("FACES_BASE_URL")
        or _load_raw().get("base_url")
        or DEFAULT_BASE_URL
    )


def resolve_token(override: Optional[str] = None) -> Optional[str]:
    return (
        override
        or os.environ.get("FACES_TOKEN")
        or _load_raw().get("token")
    )


def resolve_api_key(override: Optional[str] = None) -> Optional[str]:
    return (
        override
        or os.environ.get("FACES_API_KEY")
        or _load_raw().get("api_key")
    )


def set_config_key(key: str, value: str) -> None:
    save_config({key: value})
