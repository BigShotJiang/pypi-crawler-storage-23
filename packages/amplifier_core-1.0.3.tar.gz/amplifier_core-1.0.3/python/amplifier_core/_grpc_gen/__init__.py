"""Generated gRPC stubs for amplifier_module.proto.

Do not edit these files directly. Regenerate with:
    python -m grpc_tools.protoc -I proto \
        --python_out=python/amplifier_core/_grpc_gen \
        --grpc_python_out=python/amplifier_core/_grpc_gen \
        proto/amplifier_module.proto
"""
