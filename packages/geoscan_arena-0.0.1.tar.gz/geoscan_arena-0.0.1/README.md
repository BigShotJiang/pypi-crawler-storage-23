# Arena SDK

Прокси библиотека для отправки GRPC команд в геймкор


### Пример скрипта
```python
import time

from arena_sdk import Pioneer, GRPCCommunicator, GameCoreBase

comm = GRPCCommunicator(host="127.0.0.1", port=50051)
GameCoreBase.set_client(comm)

p1 = Pioneer("Scout-1-sky")
p2 = Pioneer("Scout-2-sky")

p1.arm()
time.sleep(1)
p1.takeoff(0.1)
time.sleep(1)
p1.land()
time.sleep(2)
```

### Запуск эхо-сервера для проверки
```python
from arena_sdk import GameCoreEchoServer
GameCoreEchoServer.serve(port=50051)
```

