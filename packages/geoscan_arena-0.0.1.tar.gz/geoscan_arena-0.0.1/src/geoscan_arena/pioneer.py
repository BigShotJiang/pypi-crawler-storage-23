from .gamecore_base import GameCoreBase

class Pioneer(GameCoreBase):

    def __init__(self, ip: str):
        self.ip = ip

    @property
    def position(self) -> list[float]:
        return self.gamecore.get_telemetry.position

    @property
    def velocity(self) -> list[float]:
        return self.gamecore.get_telemetry.velocity

    @property
    def attitude(self) -> list[float]:
        return self.gamecore.get_telemetry.attitude

    def arm(self):
        """
        Включение двигателей
        """
        self.gamecore.arm(self.ip)

    def disarm(self):
        """
        Выключение двигателей
        """
        self.gamecore.disarm(self.ip)

    def takeoff(self, altitude: float=1.5):
        """
        Взлет
        :param altitude: опционально можно указать высоту на которую надо подняться
        """
        self.gamecore.takeoff(self.ip, altitude=altitude)

    def land(self):
        """
        Посадка
        """
        self.gamecore.land(self.ip)

    def goto(self, x: float, y: float, z: float, yaw: float=0):
        """
        Следовать в точку
        :param x: x координата
        :param y: y координата
        :param z: z координата
        :param yaw: опционально угол рысканья (угол курса)
        """
        self.gamecore.goto(self.ip ,x=x, y=y, z=z, yaw=yaw)

    def led_control(self, r: int, g: int, b: int):
        """
        Установить световую индикацию в заданный цвет
        :param r: насыщенность красного 0-255
        :param g: насыщенность зеленого 0-255
        :param b: насыщенность синего 0-255
        """
        self.gamecore.led_control(self.ip, r=r, g=g, b=b)

    def check_point(self) -> bool:
        """
        Проверка точки в которой находится дрон
        :return: TODO
        """
        return self.gamecore.check_point(self.ip)
