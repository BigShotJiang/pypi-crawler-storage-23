import time

import grpc
from concurrent import futures

from arena_sdk.generated import arena_pb2_grpc, arena_pb2


# ================================
# Реализация сервиса
# ================================
class GameCoreEchoServer(arena_pb2_grpc.GameCoreServiceServicer):

    def arm(self, request, context):
        print(f"[ARM] device_id={request.device_id}")

        return arena_pb2.CommandResponse(
            success=True,
            message="Armed",
            device_id=request.device_id
        )

    def disarm(self, request, context):
        print(f"[DISARM] device_id={request.device_id}")

        return arena_pb2.CommandResponse(
            success=True,
            message="Disarmed",
            device_id=request.device_id
        )

    def takeoff(self, request, context):
        print(f"[TAKEOFF] alt={request.altitude}")

        return arena_pb2.CommandResponse(
            success=True,
            message="Takeoff started",
            device_id=request.device_id
        )

    def land(self, request, context):
        print("[LAND]")

        return arena_pb2.CommandResponse(
            success=True,
            message="Landing",
            device_id=request.device_id
        )

    def goto(self, request, context):
        print(f"[GOTO] x={request.x} y={request.y} z={request.z}")

        return arena_pb2.CommandResponse(
            success=True,
            message="Moving",
            device_id=request.device_id
        )

    def led_control(self, request, context):
        print(f"[LED] color={request.color}")

        return arena_pb2.CommandResponse(
            success=True,
            message="LED updated",
            device_id=request.device_id
        )

    def check_point(self, request, context):
        print("[CHECKPOINT]")

        return arena_pb2.CheckPointResponse(
            is_interested=True
        )

    # -------- STREAM --------
    def stream_telemetry_data(self, request, context):
        """
        unary → stream
        Клиент отправляет 1 request
        Сервер стримит TelemetryData
        """

        for i in range(10):
            yield arena_pb2.TelemetryData(
                device_id=request.device_id,
                position=1,
                velocity=2,
                attitude=3,
            )
            time.sleep(0.5)

    def get_telemetry(self, request, context):
        return arena_pb2.TelemetryData(
            device_id=request.device_id,
            position=4,
            velocity=5,
            attitude=6,
        )

    @staticmethod
    def serve(port):
        server = grpc.server(
            futures.ThreadPoolExecutor(max_workers=10)
        )

        # РЕГИСТРАЦИЯ СЕРВИСА
        arena_pb2_grpc.add_GameCoreServiceServicer_to_server(
            GameCoreEchoServer(),
            server
        )

        server.add_insecure_port(f"[::]:{port}")
        server.start()

        print(f"gRPC server started on :{port}")

        try:
            while True:
                time.sleep(86400)
        except KeyboardInterrupt:
            server.stop(0)

