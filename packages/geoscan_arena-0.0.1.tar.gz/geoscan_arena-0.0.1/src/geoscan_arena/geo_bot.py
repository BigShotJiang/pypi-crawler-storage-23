from .gamecore_base import GameCoreBase

class GeoBot(GameCoreBase):

    def __init__(self, ip: str):
        self.ip = ip

    @property
    def position(self) -> list[float]:
        return self.gamecore.get_telemetry.position

    @property
    def velocity(self) -> list[float]:
        return self.gamecore.get_telemetry.velocity

    @property
    def attitude(self) -> list[float]:
        return self.gamecore.get_telemetry.attitude


    def goto(self, x: float, y: float, yaw: float | None=None):
        self.gamecore.goto(self.ip ,x=x, y=y, z=0.0, yaw=yaw)

    def led_control(self, r: int, g: int, b: int):
        self.gamecore.led_control(self.ip, r=r, g=g, b=b)
