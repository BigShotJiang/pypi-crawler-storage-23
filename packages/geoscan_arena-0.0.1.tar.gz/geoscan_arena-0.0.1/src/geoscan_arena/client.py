import time

import grpc

from .generated import (
    GameCoreServiceStub,
    GoToRequest,
    LedRequest,
    TakeoffRequest,
    TelemetryData,
    CheckPointResponse,
    CommandResponse,
    DeviceRequest,
    Empty
)


class GRPCCommunicator:
    """
    Синхронный gRPC коммуникатор
    """

    def __init__(self, host: str = "localhost", port: int = 5656):

        self.host: str = host
        self.port: int = port

        self.channel: grpc.Channel = grpc.insecure_channel(f"{self.host}:{self.port}")
        self.stub: GameCoreServiceStub = GameCoreServiceStub(self.channel)


    def get_telemetry(self, obj_id: str) -> TelemetryData:
        return self.stub.get_telemetry(DeviceRequest(device_id=obj_id))

    def arm(self, obj_id: str):
        self.stub.arm(DeviceRequest(device_id=obj_id))

    def disarm(self, obj_id: str):
        self.stub.disarm(DeviceRequest(device_id=obj_id))

    def takeoff(self, obj_id: str, altitude: float):
        self.stub.takeoff(TakeoffRequest(device_id=obj_id, altitude=altitude))

    def land(self, obj_id: str):
        self.stub.land(DeviceRequest(device_id=obj_id))

    def goto(self, obj_id: str, **kwargs):
        self.stub.goto(GoToRequest(device_id=obj_id, **kwargs))

    def led_control(self, obj_id: str,  **kwargs):
        self.stub.led_control(LedRequest(device_id=obj_id, **kwargs))

    def check_point(self, obj_id: str) -> bool:
        return self.stub.check_point(DeviceRequest(device_id=obj_id)).is_interested

