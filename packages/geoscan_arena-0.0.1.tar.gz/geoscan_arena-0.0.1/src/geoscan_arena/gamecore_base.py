from threading import Lock
from typing import ClassVar, Optional


class GameCoreBase:
    """Базовый доступ к общему GRPC клиенту."""

    _client: ClassVar["GRPCCommunicator | None"] = None
    _lock: ClassVar[Lock] = Lock()


    @classmethod
    def set_client(cls, client: "GRPCCommunicator") -> None:
        if client is None:
            raise ValueError("client не может быть None")

        with cls._lock:
            cls._client = client

    @classmethod
    def get_client(cls) -> "GRPCCommunicator":
        client = cls._client
        if client is None:
            raise RuntimeError(
                "GRPC клиент не инициализирован. "
                "Вызовите GameCoreBase.set_client()"
            )
        return client


    @property
    def gamecore(self) -> "GRPCCommunicator":
        client = self.__class__._client

        if client is None:
            raise RuntimeError(
                "GRPC клиент не инициализирован. "
                "Вызовите GameCoreBase.set_client()"
            )

        return client
