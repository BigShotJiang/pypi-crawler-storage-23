# AgentMetadataResponse

Agent metadata for responses.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | [**RegisteredAgentProvider**](RegisteredAgentProvider.md) | Provider of the registered agent. | 
**gcp_metadata** | [**GCPAgentMetadataResponse**](GCPAgentMetadataResponse.md) |  | [optional] 
**service_names** | **List[str]** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.agent_metadata_response import AgentMetadataResponse

# TODO update the JSON string below
json = "{}"
# create an instance of AgentMetadataResponse from a JSON string
agent_metadata_response_instance = AgentMetadataResponse.from_json(json)
# print the JSON string representation of the object
print(AgentMetadataResponse.to_json())

# convert the object into a dict
agent_metadata_response_dict = agent_metadata_response_instance.to_dict()
# create an instance of AgentMetadataResponse from a dict
agent_metadata_response_from_dict = AgentMetadataResponse.from_dict(agent_metadata_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


