"""Audio postprocessor providers."""

from roomkit.voice.pipeline.postprocessor.base import AudioPostProcessor

__all__ = ["AudioPostProcessor"]
