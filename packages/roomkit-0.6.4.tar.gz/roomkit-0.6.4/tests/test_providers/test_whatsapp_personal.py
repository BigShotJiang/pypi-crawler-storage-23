"""Tests for WhatsApp Personal provider."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

from roomkit.models.enums import ChannelType
from roomkit.models.event import (
    AudioContent,
    EventSource,
    LocationContent,
    MediaContent,
    RoomEvent,
    SystemContent,
    TextContent,
    VideoContent,
)
from roomkit.providers.whatsapp.personal import WhatsAppPersonalProvider, _build_jid_str
from roomkit.sources.base import SourceStatus

# =============================================================================
# Helpers
# =============================================================================


def _make_resp() -> MagicMock:
    """Build a mock send response with a string ID."""
    resp = MagicMock()
    resp.ID = "msg-001"
    return resp


def _make_source(*, connected: bool = True) -> MagicMock:
    """Build a mock WhatsAppPersonalSourceProvider."""
    source = MagicMock()
    source.status = SourceStatus.CONNECTED if connected else SourceStatus.STOPPED
    client = AsyncMock()
    resp = _make_resp()
    client.send_message = AsyncMock(return_value=resp)
    client.send_image = AsyncMock(return_value=resp)
    client.send_document = AsyncMock(return_value=resp)
    client.send_audio = AsyncMock(return_value=resp)
    client.send_video = AsyncMock(return_value=resp)
    client.send_location = AsyncMock(return_value=resp)
    # build_audio_message returns a Message-like object with audioMessage.mimetype
    audio_msg = MagicMock()
    audio_msg.audioMessage.mimetype = "audio/ogg"
    client.build_audio_message = AsyncMock(return_value=audio_msg)
    source.client = client
    return source


def _make_event(content: object) -> RoomEvent:
    return RoomEvent(
        room_id="r1",
        source=EventSource(
            channel_id="wa-personal",
            channel_type=ChannelType.WHATSAPP_PERSONAL,
        ),
        content=content,  # type: ignore[arg-type]
    )


# =============================================================================
# Test JID building
# =============================================================================


class TestBuildJid:
    def test_plain_phone(self) -> None:
        assert _build_jid_str("1234567890") == "1234567890@s.whatsapp.net"

    def test_phone_with_plus(self) -> None:
        assert _build_jid_str("+1234567890") == "1234567890@s.whatsapp.net"

    def test_already_jid(self) -> None:
        assert _build_jid_str("1234567890@s.whatsapp.net") == "1234567890@s.whatsapp.net"


# =============================================================================
# Test provider
# =============================================================================


@patch(
    "roomkit.providers.whatsapp.personal._build_jid",
    side_effect=_build_jid_str,
)
class TestWhatsAppPersonalProvider:
    def test_constructor_stores_source(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        assert provider._source is source

    def test_name_property(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        assert provider.name == "whatsapp-personal"

    async def test_send_text_content(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        event = _make_event(TextContent(body="Hello"))

        result = await provider.send(event, "+1234567890")

        assert result.success is True
        assert result.provider_message_id is not None
        source.client.send_message.assert_called_once_with(
            "1234567890@s.whatsapp.net",
            "Hello",
        )

    async def test_send_media_content_image(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        event = _make_event(
            MediaContent(
                url="https://example.com/photo.jpg",
                mime_type="image/jpeg",
                caption="A photo",
            )
        )

        result = await provider.send(event, "1234567890")

        assert result.success is True
        source.client.send_image.assert_called_once_with(
            "1234567890@s.whatsapp.net",
            "https://example.com/photo.jpg",
            caption="A photo",
        )

    async def test_send_media_content_document(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        event = _make_event(
            MediaContent(
                url="https://example.com/report.pdf",
                mime_type="application/pdf",
                filename="report.pdf",
            )
        )

        result = await provider.send(event, "1234567890")

        assert result.success is True
        source.client.send_document.assert_called_once_with(
            "1234567890@s.whatsapp.net",
            "https://example.com/report.pdf",
            filename="report.pdf",
        )

    async def test_send_audio_content(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        event = _make_event(
            AudioContent(url="https://example.com/voice.ogg", mime_type="audio/ogg")
        )

        result = await provider.send(event, "1234567890")

        assert result.success is True
        source.client.build_audio_message.assert_called_once_with(
            "https://example.com/voice.ogg",
            ptt=True,
        )
        # Mimetype should be patched from "audio/ogg" to "audio/ogg; codecs=opus"
        audio_msg = source.client.build_audio_message.return_value
        assert audio_msg.audioMessage.mimetype == "audio/ogg; codecs=opus"
        source.client.send_message.assert_called_once_with(
            "1234567890@s.whatsapp.net",
            audio_msg,
        )

    async def test_send_video_content(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        event = _make_event(VideoContent(url="https://example.com/video.mp4"))

        result = await provider.send(event, "1234567890")

        assert result.success is True
        source.client.send_video.assert_called_once_with(
            "1234567890@s.whatsapp.net",
            "https://example.com/video.mp4",
        )

    async def test_send_location_content(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        event = _make_event(LocationContent(latitude=45.5, longitude=-73.5, label="Montreal"))

        result = await provider.send(event, "1234567890")

        assert result.success is True
        source.client.send_location.assert_called_once_with(
            "1234567890@s.whatsapp.net",
            45.5,
            -73.5,
            name="Montreal",
        )

    async def test_send_when_disconnected(self, _mock_jid: MagicMock) -> None:
        source = _make_source(connected=False)
        provider = WhatsAppPersonalProvider(source)
        event = _make_event(TextContent(body="Hello"))

        result = await provider.send(event, "1234567890")

        assert result.success is False
        assert "not connected" in (result.error or "")

    async def test_send_unsupported_content(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        event = _make_event(SystemContent(body="system message"))

        result = await provider.send(event, "1234567890")

        assert result.success is False
        assert "Unsupported" in (result.error or "")

    async def test_send_handles_exception(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        source.client.send_message = AsyncMock(side_effect=Exception("network error"))
        provider = WhatsAppPersonalProvider(source)
        event = _make_event(TextContent(body="Hello"))

        result = await provider.send(event, "1234567890")

        assert result.success is False
        assert "network error" in (result.error or "")

    async def test_close_is_noop(self, _mock_jid: MagicMock) -> None:
        source = _make_source()
        provider = WhatsAppPersonalProvider(source)
        # Should not raise
        await provider.close()
