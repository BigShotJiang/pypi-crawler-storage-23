"""MCP server for Kafka Connect."""
