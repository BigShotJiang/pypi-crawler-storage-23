"""Utility functions for the Configuration Explorer.

Provides functions for converting raw config dictionaries into ConfigTree
structures and other helper utilities.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from copy import deepcopy
from functools import lru_cache
from importlib import resources
from pathlib import Path
from typing import Any

import yaml

from .descriptions import get_choices, get_default, get_description, get_tier, is_locked
from .llm_registry import get_role_tier_defaults
from .metadata import (
    PIPELINE_STAGE_ORDER,
    get_stage_label,
    get_tags,
    resolve_stage,
)
from .models import ConfigNode, ConfigSource, ConfigTree, SettingTier, ValueType

logger = logging.getLogger(__name__)


def _get_nested(config: dict[str, Any], path: str) -> Any:
    """Get a nested value from config using dot notation."""
    parts = path.split(".")
    current = config
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _resolve_default_value(
    path: str,
    value: Any,
    full_config: dict[str, Any],
    role_tier_defaults_cache: dict[tuple[str, str], dict[str, str]] | None = None,
) -> tuple[Any, bool]:
    """Resolve 'default' values to actual values at load time.

    When a tier or model has value 'default', resolve it to the actual
    model name and mark it as using_default=True.

    Args:
        path: Dot-notation path like "llm.orchestrator.tiers.fast"
        value: The current value (may be 'default')
        full_config: Full config dict for provider lookup

    Returns:
        Tuple of (resolved_value, is_using_default)
        - resolved_value: The actual model name (or original value if not 'default')
        - is_using_default: True if original value was 'default'
    """
    # Only resolve string 'default' values
    if value != "default":
        return value, False

    # Check if this is a tier path: llm.{role}.tiers.{tier}
    if ".tiers." in path:
        parts = path.split(".")
        if len(parts) >= 4 and parts[0] == "llm":
            role = parts[1]  # orchestrator or implementation
            tier = parts[-1]  # fast, medium, or high

            if tier in ("fast", "medium", "high") and role in (
                "orchestrator",
                "implementation",
            ):
                # Get provider for this role
                provider = _get_nested(full_config, f"llm.{role}.provider")
                if not provider or provider == "per-role":
                    provider = _get_nested(full_config, "llm.provider")
                if not provider or provider == "per-role":
                    provider = "anthropic"  # Safe fallback

                # Resolve using role-tier defaults from the already-loaded config.
                # Fall back to runtime loader only if config data is missing.
                role_defaults = _get_role_tier_defaults_cached(
                    provider,
                    role,
                    full_config,
                    role_tier_defaults_cache,
                )
                resolved = role_defaults.get(tier, "default")
                return resolved, True

    # Check if this is a model path: llm.{role}.model
    if path.endswith(".model") and path.startswith("llm."):
        parts = path.split(".")
        if len(parts) == 3:  # llm.{role}.model
            role = parts[1]
            if role in ("orchestrator", "implementation"):
                # Get provider for this role
                provider = _get_nested(full_config, f"llm.{role}.provider")
                if not provider or provider == "per-role":
                    provider = _get_nested(full_config, "llm.provider")
                if not provider or provider == "per-role":
                    provider = "anthropic"

                # For model, use medium tier as the default
                role_defaults = _get_role_tier_defaults_cached(
                    provider,
                    role,
                    full_config,
                    role_tier_defaults_cache,
                )
                resolved = role_defaults.get("medium", "default")
                return resolved, True

    # Not a resolvable path, keep as-is
    return value, value == "default"


def _get_role_tier_defaults_cached(
    provider: str,
    role: str,
    full_config: dict[str, Any],
    cache: dict[tuple[str, str], dict[str, str]] | None,
) -> dict[str, str]:
    """Get role tier defaults with per-build caching.

    Priority:
    1. Read from already-loaded full_config (fast path; no I/O)
    2. Fall back to llm_registry helper (legacy/runtime compatibility)
    """
    cache_key = (provider, role)
    if cache is not None and cache_key in cache:
        return cache[cache_key]

    role_defaults: dict[str, str] = {}

    llm_section = full_config.get("llm")
    if isinstance(llm_section, dict):
        raw_role_defaults = llm_section.get("role_defaults")
        if isinstance(raw_role_defaults, dict):
            provider_defaults = raw_role_defaults.get(provider)
            if isinstance(provider_defaults, dict):
                role_map = provider_defaults.get(role)
                if isinstance(role_map, dict):
                    role_defaults = {
                        str(k): str(v)
                        for k, v in role_map.items()
                        if isinstance(k, str) and isinstance(v, str)
                    }

        if not role_defaults:
            raw_provider_defaults = llm_section.get("provider_defaults")
            if isinstance(raw_provider_defaults, dict):
                provider_map = raw_provider_defaults.get(provider)
                if isinstance(provider_map, dict):
                    role_defaults = {
                        str(k): str(v)
                        for k, v in provider_map.items()
                        if isinstance(k, str) and isinstance(v, str)
                    }

    # Fallback for edge cases where the provided config is incomplete
    if not role_defaults:
        role_defaults = get_role_tier_defaults(provider, role)

    if cache is not None:
        cache[cache_key] = role_defaults
    return role_defaults


# Fields that should never appear in the explorer (security-sensitive)
HIDDEN_FIELDS = {
    "auth_token",
    "refresh_token",
    "firebase_api_key",
    "token_expires_at",
}

# Full paths that should be hidden (dead code or derived values)
# These fields exist in config but are not used by orchestration
HIDDEN_PATHS = {
    "llm.type",  # Dead - superseded by llm.provider
    "llm.cli_command",  # Dead - derived from provider via LLM_PROVIDERS
}

# Fields that should be displayed but not editable
READONLY_FIELDS = {
    "user_email",
    "firebase_uid",
    "auth_provider",
    "display_name",
    "user_id",
    "auth_timestamp",  # Set by auth system, not user-editable
    "terms_accepted",  # Set by acceptance flow, not user-editable
}

# Account/auth fields that should be grouped together in a dedicated section
ACCOUNT_INFO_FIELDS = {
    "auth_provider",
    "auth_timestamp",
    "display_name",
    "firebase_uid",
    "user_email",
    "user_id",
    "terms_accepted",
}

# Field ordering priority within the same tier (lower = earlier)
# Used to ensure parent fields appear before dependent fields
FIELD_ORDER_PRIORITY = {
    # Top-level section ordering
    "llm": 0,  # LLM settings at top (most important)
    "features": 10,  # Features second
    "orchestration": 20,  # Orchestration settings
    # LLM field ordering (within llm section)
    "provider": 0,  # Provider must come before model (parent → child)
    "model": 1,
    "auth_method": 2,
    # Git settings (after auth, before tiers - provider-aware)
    "git": 3,
    "skip_check": 4,
    "auto_init": 5,
    # Tier ordering (fast → medium → high)
    "fast": 6,
    "medium": 7,
    "high": 8,
}


def merge_with_default_schema(local_config: dict[str, Any]) -> dict[str, Any]:
    """Merge local config with default schema for UI display."""
    defaults = load_default_config_schema()
    if not defaults:
        return deepcopy(local_config)
    return _deep_merge(defaults, local_config)


def load_default_config_schema() -> dict[str, Any]:
    """Load packaged default schema with process-local caching."""
    return deepcopy(_load_default_config_schema_cached())


@lru_cache(maxsize=1)
def _load_default_config_schema_cached() -> dict[str, Any]:
    try:
        default_path = resources.files("obra.config").joinpath("default_config.yaml")
        content = default_path.read_text(encoding="utf-8")
        data = yaml.safe_load(content) or {}
        if isinstance(data, dict):
            return data
    except Exception as exc:
        logger.debug("Failed to load packaged default_config.yaml: %s", exc)

    fallback = Path(__file__).resolve().parents[1] / "default_config.yaml"
    try:
        if fallback.exists():
            content = fallback.read_text(encoding="utf-8")
            data = yaml.safe_load(content) or {}
            if isinstance(data, dict):
                return data
    except Exception as exc:
        logger.debug("Failed to load fallback default_config.yaml: %s", exc)

    logger.warning("Default config schema unavailable; config UI may be incomplete.")
    return {}


def iter_schema_paths(
    schema: dict[str, Any],
    prefix: str = "",
) -> list[tuple[str, Any]]:
    """Return dot-paths and values from the config schema."""
    items: list[tuple[str, Any]] = []
    for key, value in schema.items():
        path = f"{prefix}.{key}" if prefix else key
        items.append((path, value))
        if isinstance(value, dict):
            items.extend(iter_schema_paths(value, path))
    return items


def iter_leaf_nodes(root: ConfigNode) -> list[ConfigNode]:
    """Return all leaf nodes from a config tree."""
    leaves: list[ConfigNode] = []

    def walk(node: ConfigNode) -> None:
        for child in node.children:
            if child.is_leaf:
                leaves.append(child)
            else:
                walk(child)

    walk(root)
    return leaves


def build_pipeline_root(root: ConfigNode) -> ConfigNode:
    """Build a pipeline-grouped root from an existing config tree."""
    stage_nodes: dict[str, ConfigNode] = {}
    pipeline_root = ConfigNode(
        key="Pipeline View",
        path="pipeline",
        value=None,
        value_type=ValueType.OBJECT,
        source=root.source,
        tier=SettingTier.STANDARD,
        description="Settings grouped by pipeline stage",
    )

    for stage in PIPELINE_STAGE_ORDER:
        label = get_stage_label(stage)
        stage_node = ConfigNode(
            key=label,
            path=f"pipeline.{stage}",
            value=None,
            value_type=ValueType.OBJECT,
            source=root.source,
            tier=SettingTier.STANDARD,
            description=f"{label} stage settings",
            stage=stage,
        )
        stage_nodes[stage] = stage_node
        pipeline_root.children.append(stage_node)

    for leaf in iter_leaf_nodes(root):
        stage = leaf.stage or "other"
        target = stage_nodes.get(stage)
        if not target:
            target = stage_nodes["other"]
        target.children.append(leaf)

    # Sort leaf nodes within each stage for consistent display
    for stage_node in pipeline_root.children:
        stage_node.children.sort(
            key=lambda n: (
                FIELD_ORDER_PRIORITY.get(str(n.key), 999),
                str(n.key),
            )
        )

    return pipeline_root


def filter_tree_by_predicate(
    root: ConfigNode,
    predicate: Callable[[ConfigNode], bool],
) -> ConfigNode | None:
    """Filter a config tree by predicate, preserving ancestor structure."""
    if root.is_leaf:
        return root if predicate(root) else None

    filtered_children: list[ConfigNode] = []
    for child in root.children:
        filtered = filter_tree_by_predicate(child, predicate)
        if filtered is not None:
            filtered_children.append(filtered)

    if not filtered_children and root.path:
        return None

    return ConfigNode(
        key=root.key,
        path=root.path,
        value=root.value,
        value_type=root.value_type,
        source=root.source,
        tier=root.tier,
        description=root.description,
        default_value=root.default_value,
        choices=root.choices,
        depends_on=root.depends_on,
        affects=list(root.affects),
        stage=root.stage,
        tags=list(root.tags),
        origin=root.origin,
        children=filtered_children,
        is_modified=root.is_modified,
        is_expanded=root.is_expanded,
        is_readonly=root.is_readonly,
        is_using_default=root.is_using_default,
    )


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _resolve_origin(
    source: ConfigSource,
    path: str,
    origins: dict[str, str] | None,
) -> str | None:
    if source == ConfigSource.SERVER:
        return "server"
    if not path:
        return None
    if origins and path in origins:
        return origins[path]
    return None


def detect_value_type(
    value: Any,
    path: str,
    full_config: dict[str, Any] | None = None,
) -> ValueType:
    """Detect the ValueType for a configuration value.

    Args:
        value: The value to inspect
        path: The dot-notation path (used to check for known enum types)
        full_config: Full config dict for provider-aware choice lookups

    Returns:
        The detected ValueType
    """
    # Check if this path has predefined choices (enum)
    if get_choices(path, full_config) is not None:
        return ValueType.ENUM

    if isinstance(value, bool):
        return ValueType.BOOLEAN
    if isinstance(value, int):
        return ValueType.INTEGER
    if isinstance(value, str):
        return ValueType.STRING
    if isinstance(value, dict):
        return ValueType.OBJECT

    # Default to string for unknown types
    return ValueType.STRING


def get_setting_tier(path: str) -> SettingTier:
    """Get the SettingTier for a configuration path.

    Args:
        path: Dot-notation path

    Returns:
        The SettingTier for this setting
    """
    tier_str = get_tier(path)
    return SettingTier(tier_str)


def dict_to_config_node(
    data: dict[str, Any],
    source: ConfigSource,
    parent_path: str = "",
    full_config: dict[str, Any] | None = None,
    origins: dict[str, str] | None = None,
    role_tier_defaults_cache: dict[tuple[str, str], dict[str, str]] | None = None,
) -> ConfigNode:
    """Convert a dictionary into a ConfigNode tree.

    Recursively builds a ConfigNode tree from a nested dictionary,
    attaching descriptions, choices, and defaults from the registry.

    Args:
        data: Dictionary of configuration values
        source: ConfigSource indicating where this config comes from
        parent_path: Parent path for building full dot-notation paths
        full_config: Full config dict for provider-aware choice lookups

    Returns:
        Root ConfigNode containing the tree structure
    """
    # Use data as full_config if not provided (top-level call)
    if full_config is None:
        full_config = data

    # Create root node for this level
    key = parent_path.split(".")[-1] if parent_path else "root"
    root = ConfigNode(
        key=key,
        path=parent_path,
        value=None,
        value_type=ValueType.OBJECT,
        source=source,
        tier=get_setting_tier(parent_path) if parent_path else SettingTier.STANDARD,
        description=get_description(parent_path) if parent_path else None,
        stage=resolve_stage(parent_path) if parent_path else None,
        tags=get_tags(parent_path) if parent_path else [],
        origin=_resolve_origin(source, parent_path, origins),
    )

    for k, v in data.items():
        # Skip sensitive fields that shouldn't be visible
        if k in HIDDEN_FIELDS:
            continue

        child_path = f"{parent_path}.{k}" if parent_path else k

        # Skip dead/deprecated paths (full path check)
        if child_path in HIDDEN_PATHS:
            continue

        if isinstance(v, dict):
            # Recursive case - nested object
            child = dict_to_config_node(
                v,
                source,
                child_path,
                full_config,
                origins,
                role_tier_defaults_cache,
            )
            child.key = k
        else:
            # Leaf case - actual value
            # Resolve 'default' values at load time, set is_using_default flag
            resolved_value, is_using_default = _resolve_default_value(
                child_path,
                v,
                full_config,
                role_tier_defaults_cache,
            )
            value_type = detect_value_type(resolved_value, child_path, full_config)
            child = ConfigNode(
                key=k,
                path=child_path,
                value=resolved_value,
                value_type=value_type,
                source=source,
                tier=get_setting_tier(child_path),
                description=get_description(child_path),
                default_value=get_default(child_path),
                choices=get_choices(child_path, full_config),
                is_readonly=is_locked(child_path) or k in READONLY_FIELDS,
                stage=resolve_stage(child_path),
                tags=get_tags(child_path),
                origin=_resolve_origin(source, child_path, origins),
                is_using_default=is_using_default,
            )

        root.children.append(child)

    # Sort children: basic first, then standard, then advanced
    # Within same tier, sort by field priority (provider before model), then alphabetically
    tier_order = {
        SettingTier.BASIC: 0,
        SettingTier.STANDARD: 1,
        SettingTier.ADVANCED: 2,
    }
    root.children.sort(
        key=lambda n: (
            tier_order.get(n.tier, 1),
            FIELD_ORDER_PRIORITY.get(str(n.key), 999),  # Fields with priority come first
            str(n.key),  # Alphabetical within same tier/priority
        )
    )

    return root


def _extract_account_nodes(node: ConfigNode) -> list[ConfigNode]:
    """Extract account/auth info nodes from tree for dedicated section.

    Args:
        node: ConfigNode to search

    Returns:
        List of account info nodes (auth_provider, user_email, etc.)
    """
    account_nodes: list[ConfigNode] = []
    children_to_keep = []

    for child in node.children:
        # Check if this is an account info field (top-level only)
        if child.key in ACCOUNT_INFO_FIELDS:
            # Mark as read-only if in READONLY_FIELDS
            if is_locked(child.path) or child.key in READONLY_FIELDS:
                child.is_readonly = True
            account_nodes.append(child)
        else:
            children_to_keep.append(child)

    node.children = children_to_keep
    return account_nodes


def _extract_advanced_nodes(node: ConfigNode, parent_context: str = "") -> list[ConfigNode]:
    """Recursively extract all advanced-tier nodes from a tree.

    Args:
        node: ConfigNode to search
        parent_context: Parent path context for better naming (e.g., "telemetry" for "enabled")

    Returns:
        List of advanced-tier nodes (both leaf and branch) with improved display names
    """
    advanced_nodes: list[ConfigNode] = []

    # Extract advanced children, keeping track of which to keep
    children_to_keep = []

    for child in node.children:
        if child.tier == SettingTier.ADVANCED:
            # This is an advanced node - extract it
            # Improve display name if we have parent context
            if parent_context and child.is_leaf:
                # e.g., "enabled" becomes "telemetry.enabled"
                child.key = f"{parent_context}.{child.key}"
            advanced_nodes.append(child)
        elif not child.is_leaf:
            # This is a non-advanced branch - recursively search it
            # Build context from parent path (skip generic names like "features")
            new_context = child.key if child.key not in {"features", "advanced"} else parent_context
            if parent_context and new_context and new_context != parent_context:
                new_context = f"{parent_context}.{new_context}"

            child_advanced = _extract_advanced_nodes(child, new_context)
            advanced_nodes.extend(child_advanced)

            # Only keep this branch if it still has children after extraction
            # This removes empty parent nodes like "advanced" after all children extracted
            if len(child.children) > 0:
                children_to_keep.append(child)
        else:
            # This is a non-advanced leaf - keep it
            children_to_keep.append(child)

    # Update node's children to exclude extracted advanced nodes and empty branches
    node.children = children_to_keep

    return advanced_nodes


# LLM role sections that should get clear labels
LLM_ROLE_SECTIONS = {"orchestrator", "implementation"}

# LLM quick setting fields (top-level overrides)
LLM_QUICK_SETTINGS = {"provider", "model"}

# Provider-specific settings that should be conditionally shown.
# Maps setting path prefix to provider values that enable it.
PROVIDER_CONDITIONAL_SETTINGS = {
    "llm.codex": ("openai", "ollama"),  # codex.* shown for codex-backed providers
}


def _organize_llm_section(root: ConfigNode, llm_config: dict[str, Any]) -> None:
    """Reorganize the LLM section for better clarity.

    Phase 4: Adds clear labels to role sections (orchestrator, implementation)
    and groups quick settings together.

    Args:
        root: Root ConfigNode to modify
        llm_config: Raw LLM config dict to check provider values
    """
    # Find the llm node
    llm_node = None
    for child in root.children:
        if child.key == "llm":
            llm_node = child
            break

    if not llm_node:
        return

    # Reorganize children: quick settings first, then roles, then other settings
    quick_settings = []
    role_sections = []
    other_settings = []

    for child in llm_node.children:
        if child.key in LLM_QUICK_SETTINGS:
            quick_settings.append(child)
        elif child.key in LLM_ROLE_SECTIONS:
            # Add clear label to role sections
            child.key = f"[{child.key.title()}]"
            role_sections.append(child)
        else:
            other_settings.append(child)

    # Rebuild children in logical order: quick settings -> roles -> other
    llm_node.children = quick_settings + role_sections + other_settings


def _filter_conditional_settings(
    root: ConfigNode,
    llm_config: dict[str, Any],
) -> None:
    """Remove provider-specific settings when not applicable.

    Phase 5: Hides settings that only apply to specific providers.
    For example, llm.codex.* settings are only shown when provider=openai.

    Args:
        root: Root ConfigNode to modify
        llm_config: Raw LLM config dict to check provider values
    """
    # Get the effective provider (considering fast-config pattern)
    top_provider = llm_config.get("provider", "per-role")

    # If provider is "per-role", we need to check role-specific providers
    # For simplicity, show codex settings if ANY role uses openai
    if top_provider == "per-role":
        providers_in_use = {top_provider}
        for role in LLM_ROLE_SECTIONS:
            role_config = llm_config.get(role, {})
            if role_provider := role_config.get("provider"):
                providers_in_use.add(role_provider)
    else:
        # Top-level provider cascades to all roles
        providers_in_use = {top_provider}

    # Find the llm node
    llm_node = None
    for child in root.children:
        if child.key == "llm":
            llm_node = child
            break

    if not llm_node:
        return

    # Filter out conditional settings that don't apply
    children_to_keep = []
    for child in llm_node.children:
        child_path = f"llm.{child.key}"

        # Check if this is a conditional setting
        should_hide = False
        for path_prefix, required_providers in PROVIDER_CONDITIONAL_SETTINGS.items():
            if child_path.startswith(path_prefix):
                if not set(required_providers).intersection(providers_in_use):
                    should_hide = True
                    break

        if not should_hide:
            children_to_keep.append(child)

    llm_node.children = children_to_keep


def dict_to_config_tree(
    local_config: dict[str, Any],
    server_config: dict[str, Any],
    origins: dict[str, str] | None = None,
) -> ConfigTree:
    """Convert local and server config dicts into a ConfigTree.

    Consolidates advanced-tier settings and account info into dedicated sections
    for better UX organization.

    Args:
        local_config: Local configuration dictionary from layered config
        server_config: Server configuration dictionary from API
        origins: Optional origins map for layered config values

    Returns:
        ConfigTree with both local and server roots populated
    """
    # Handle server config structure (may have resolved/overrides/preset keys)
    server_data = server_config.get("resolved", server_config)

    # Shared cache for role-tier default lookups during this build.
    # Avoids repeated runtime config reloads for each "default" node.
    role_tier_defaults_cache: dict[tuple[str, str], dict[str, str]] = {}

    local_root = dict_to_config_node(
        local_config,
        ConfigSource.LOCAL,
        "",
        origins=origins,
        role_tier_defaults_cache=role_tier_defaults_cache,
    )
    local_root.key = "Local Settings"

    # Phase 4: Organize LLM section with clear role labels
    llm_config = local_config.get("llm", {})
    _organize_llm_section(local_root, llm_config)

    # Phase 5: Filter provider-specific settings (e.g., hide codex when not using openai)
    _filter_conditional_settings(local_root, llm_config)

    # Extract account/auth info nodes and create dedicated section
    account_nodes = _extract_account_nodes(local_root)

    if account_nodes:
        # Create "Account Info" section
        # Note: Using ASCII-safe labels for Windows/cmd compatibility
        account_section = ConfigNode(
            key="[Account] Read Only",
            path="account_info",
            value=None,
            value_type=ValueType.OBJECT,
            source=ConfigSource.LOCAL,
            tier=SettingTier.STANDARD,
            description="Account and authentication information (read-only)",
        )

        # Sort account nodes alphabetically
        account_nodes.sort(key=lambda n: str(n.key))

        # Add account nodes as children
        account_section.children = account_nodes

        # Add Account section to local_root (will be before Advanced)
        local_root.children.append(account_section)

    # Extract all advanced-tier nodes and consolidate under "Advanced" section
    advanced_nodes = _extract_advanced_nodes(local_root)

    if advanced_nodes:
        # Create "Advanced" parent node
        advanced_section = ConfigNode(
            key="[Advanced]",
            path="advanced",
            value=None,
            value_type=ValueType.OBJECT,
            source=ConfigSource.LOCAL,
            tier=SettingTier.ADVANCED,
            description="Advanced configuration settings for expert users",
        )

        # Sort advanced nodes alphabetically
        advanced_nodes.sort(key=lambda n: str(n.key))

        # Add advanced nodes as children
        advanced_section.children = advanced_nodes

        # Add Advanced section to local_root at the end
        local_root.children.append(advanced_section)

    server_root = dict_to_config_node(
        server_data,
        ConfigSource.SERVER,
        "",
        role_tier_defaults_cache=role_tier_defaults_cache,
    )
    server_root.key = "[Server] SaaS - Read Only"

    return ConfigTree(local_root=local_root, server_root=server_root)


def flatten_config(node: ConfigNode, prefix: str = "") -> dict[str, Any]:
    """Flatten a ConfigNode tree into a dot-notation dictionary.

    Args:
        node: ConfigNode to flatten
        prefix: Current path prefix

    Returns:
        Dictionary mapping dot-notation paths to values
    """
    result: dict[str, Any] = {}

    for child in node.children:
        path = f"{prefix}.{child.key}" if prefix else child.key

        if child.is_leaf:
            result[path] = child.value
        else:
            result.update(flatten_config(child, path))

    return result


def unflatten_config(flat_config: dict[str, Any]) -> dict[str, Any]:
    """Convert a flat dot-notation dict back to nested structure.

    Args:
        flat_config: Dictionary with dot-notation keys

    Returns:
        Nested dictionary structure
    """
    result: dict[str, Any] = {}

    for path, value in flat_config.items():
        parts = path.split(".")
        current = result

        for _i, part in enumerate(parts[:-1]):
            if part not in current:
                current[part] = {}
            current = current[part]

        current[parts[-1]] = value

    return result


def get_preset_name(server_config: dict[str, Any]) -> str | None:
    """Extract preset name from server config.

    Args:
        server_config: Server configuration dictionary

    Returns:
        Preset name or None
    """
    return server_config.get("preset")


def count_children(node: ConfigNode, include_nested: bool = True) -> int:
    """Count child nodes in a config tree.

    Args:
        node: ConfigNode to count children of
        include_nested: If True, count recursively; if False, count direct children only

    Returns:
        Number of child nodes
    """
    if not include_nested:
        return len(node.children)

    count = 0
    for child in node.children:
        if child.is_leaf:
            count += 1
        else:
            count += count_children(child, include_nested=True)

    return count


def find_nodes_by_path_pattern(
    root: ConfigNode,
    pattern: str,
) -> list[ConfigNode]:
    """Find all nodes whose paths match a pattern.

    Args:
        root: Root node to search from
        pattern: Pattern to match (case-insensitive substring)

    Returns:
        List of matching ConfigNodes
    """
    matches: list[ConfigNode] = []
    pattern_lower = pattern.lower()

    def search(node: ConfigNode) -> None:
        node_path = str(node.path or "").lower()
        node_key = str(node.key).lower()
        if pattern_lower in node_path or pattern_lower in node_key:
            matches.append(node)

        for child in node.children:
            search(child)

    search(root)
    return matches
