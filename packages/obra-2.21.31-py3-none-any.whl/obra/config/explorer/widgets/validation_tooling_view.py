"""Validation & Tooling View widget (Story 0).

Provides an interface for configuring automation mode and pre-flight
validation settings that run before execution begins.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import (
    Button,
    Collapsible,
    Input,
    RadioButton,
    RadioSet,
    Select,
    Static,
    Switch,
)

from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin

if TYPE_CHECKING:
    pass


@dataclass
class AutomationMode:
    """Metadata for an automation mode option."""

    id: str
    label: str
    description: str


# Automation mode options with descriptions.
# These map to the automation_mode config (top-level setting).
AUTOMATION_MODES: list[AutomationMode] = [
    AutomationMode(
        id="off",
        label="Off",
        description="Skip all pre-flight checks",
    ),
    AutomationMode(
        id="guided",
        label="Guided",
        description="Prompt before each action",
    ),
    AutomationMode(
        id="auto_safe",
        label="Auto Safe",
        description="Auto-run safe ops, prompt for installs",
    ),
    AutomationMode(
        id="auto_full",
        label="Auto Full",
        description="Full automation, no prompts",
    ),
]

# Story 0 settings metadata.
# Maps setting path to description and type information.
# Labels are action-oriented for clarity (e.g., "Auto-create" not "Auto Environment Setup")
#
# ORDER: Grouped by widget type for visual consistency:
#   1. Toggles (bool) - on/off switches at the top
#   2. Dropdowns (select) - configuration options in the middle
#   3. Numeric inputs (int) - values at the bottom
STORY0_SETTINGS: dict[str, dict[str, Any]] = {
    # === Toggles (on/off behavior switches) ===
    "story0.enabled": {
        "label": "Enable pre-execution setup",
        "description": "Run environment preparation before execution starts",
        "type": "bool",
    },
    "story0.auto_env_setup": {
        "label": "Auto-create manifests",
        "description": "Generate missing project manifests (pyproject.toml, package.json, etc.)",
        "type": "bool",
    },
    "story0.prompt_for_env_setup": {
        "label": "Confirm environment setup",
        "description": "Ask before setting up environment (Guided mode only)",
        "type": "bool",
    },
    "story0.auto_approve": {
        "label": "Auto-confirm safe actions",
        "description": "Skip confirmation for low-risk operations (ON in Auto Safe/Full modes)",
        "type": "bool",
    },
    # === Dropdowns (configuration options) ===
    "story0.install_target": {
        "label": "Install location",
        "description": "Where to install project dependencies",
        "type": "select",
        "options": ["project_local", "existing_env_only", "system"],
        "option_labels": {
            "project_local": "Project venv (.venv/)",
            "existing_env_only": "Current environment only",
            "system": "System-wide",
        },
    },
    "story0.env_creation": {
        "label": "Virtual environment",
        "description": "When to create a new virtual environment",
        "type": "select",
        "options": ["never", "when_missing", "always"],
        "option_labels": {
            "never": "Never create",
            "when_missing": "Create if missing",
            "always": "Always create new",
        },
    },
    "story0.install_policy": {
        "label": "Dependency installation",
        "description": "How to discover and install dependencies",
        "type": "select",
        "options": ["manifest_only", "manifest_then_inferred", "manifest_or_inferred"],
        "option_labels": {
            "manifest_only": "From manifest only",
            "manifest_then_inferred": "Manifest first, then infer",
            "manifest_or_inferred": "Manifest or infer if missing",
        },
    },
    # === Numeric inputs ===
    "story0.timeout_seconds": {
        "label": "Confirmation timeout",
        "description": "Seconds to wait for user input before proceeding",
        "type": "int",
        "min": 60,
        "max": 600,
    },
}

# Discovery settings metadata.
# Maps setting path to description and type information.
DISCOVERY_SETTINGS: dict[str, dict[str, Any]] = {
    "fix.verification.discovery_enabled": {
        "label": "Auto-detect tooling",
        "description": "Use LLM to detect verification tools from project manifests",
        "type": "bool",
    },
    "fix.verification.discovery_force_refresh": {
        "label": "Force refresh on next run",
        "description": "Ignore cached discovery results (one-time)",
        "type": "bool",
    },
    "handlers.tooling_discovery.timeout_s": {
        "label": "Discovery timeout (seconds)",
        "description": "Max time for LLM tooling discovery",
        "type": "int",
        "min": 60,
        "max": 600,
    },
}

# Tool categories for custom command overrides
TOOL_CATEGORIES: list[str] = ["test", "lint", "format", "typecheck"]

# Example commands for each category (shown as placeholder hints)
TOOL_EXAMPLES: dict[str, str] = {
    "test": "pytest -v --tb=short",
    "lint": "ruff check . --fix",
    "format": "ruff format . --check",
    "typecheck": "mypy . --strict",
}


class ValidationToolingView(SaveableViewMixin, Static):
    """Validation & Tooling (Story 0) configuration view.

    Shows automation mode selection and pre-flight validation settings.
    Controls whether Obra prompts for approval or runs fully automated.

    Emits:
        Changed: When any setting value changes.
    """

    DEFAULT_CSS = """
    ValidationToolingView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    ValidationToolingView > Vertical {
        width: 100%;
        height: 100%;
    }

    ValidationToolingView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
    }

    ValidationToolingView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    ValidationToolingView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    ValidationToolingView .preflight-header {
        background: $warning-darken-3;
        color: $warning;
        padding: 1;
        margin-bottom: 2;
        width: 100%;
    }

    ValidationToolingView .mode-section {
        width: 100%;
        height: auto;
        margin-bottom: 2;
        padding: 1;
        background: $surface;
        border: solid $primary-background;
    }

    ValidationToolingView .mode-section-title {
        text-style: bold;
        margin-bottom: 1;
    }

    ValidationToolingView RadioSet {
        width: 100%;
        height: auto;
        background: transparent;
    }

    ValidationToolingView RadioButton {
        width: 100%;
        height: auto;
        padding: 0;
        margin: 0;
    }

    ValidationToolingView .setting-row {
        width: 100%;
        height: auto;
        padding: 0 1;
        margin-bottom: 1;
    }

    ValidationToolingView .setting-info {
        width: 2fr;
        height: auto;
    }

    ValidationToolingView .setting-label {
        text-style: bold;
    }

    ValidationToolingView .setting-description {
        color: $text-muted;
    }

    ValidationToolingView .setting-control {
        width: 1fr;
        height: auto;
        align: right middle;
    }

    ValidationToolingView Switch {
        width: auto;
    }

    ValidationToolingView Select {
        width: 100%;
    }

    ValidationToolingView Input {
        width: 100%;
    }

    ValidationToolingView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
        width: 100%;
    }

    ValidationToolingView .help-footer {
        color: $text-muted;
        margin-top: 2;
        padding-top: 1;
        border-top: solid $primary-background-darken-1;
        width: 100%;
    }

    ValidationToolingView Collapsible {
        width: 100%;
    }

    ValidationToolingView .tool-section-help {
        color: $text-muted;
        margin-bottom: 1;
        padding: 0 1;
    }

    ValidationToolingView .tool-row {
        width: 100%;
        height: auto;
        padding: 1;
        margin-bottom: 1;
        background: $surface;
        border: solid $primary-background;
    }

    ValidationToolingView .tool-header {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    ValidationToolingView .tool-label {
        text-style: bold;
    }

    ValidationToolingView .tool-detected {
        color: $success;
    }

    ValidationToolingView .tool-effective {
        color: $text-muted;
        margin-top: 0;
    }

    ValidationToolingView .tool-effective-custom {
        color: $warning;
        margin-top: 0;
    }

    ValidationToolingView .tool-input-row {
        width: 100%;
        height: auto;
    }

    ValidationToolingView .tool-input-row Input {
        width: 1fr;
    }

    ValidationToolingView .tool-input-row Button {
        width: auto;
        margin-left: 1;
    }

    ValidationToolingView .tool-section-footer {
        color: $text-disabled;
        margin-top: 1;
        padding: 0 1;
        text-style: italic;
    }
    """

    class Changed(Message):
        """Message emitted when a validation/tooling setting changes."""

        def __init__(self, path: str, value: Any) -> None:
            """Initialize the Changed message.

            Args:
                path: Config path that changed (e.g., 'automation_mode', 'story0.enabled')
                value: New value for the setting
            """
            super().__init__()
            self.path = path
            self.value = value

    def __init__(
        self,
        current_values: dict[str, Any] | None = None,
        working_dir: Path | None = None,
        llm_config: dict[str, Any] | None = None,
        **kwargs,
    ) -> None:
        """Initialize the ValidationToolingView.

        Args:
            current_values: Dict mapping config paths to current values
            working_dir: Project working directory for tooling discovery
            llm_config: LLM configuration for tooling discovery
        """
        super().__init__(**kwargs)
        self._current_values: dict[str, Any] = current_values or {}
        self._working_dir = working_dir
        self._llm_config = llm_config or {}

        # Cache detected commands for display in Custom Tool Commands section
        self._detected_commands: dict[str, str] = self._load_detected_commands()

        # Suppress change emissions during initial mount
        self._initializing = True
        # Take snapshot for dirty tracking
        self._snapshot_state()

    def _load_detected_commands(self) -> dict[str, str]:
        """Load detected tool commands from the tooling discovery cache.

        Returns:
            Dict mapping category (test, lint, etc.) to detected command string.
        """
        if self._working_dir is None:
            return {}

        try:
            from obra.hybrid.tooling_discovery import ToolingDiscovery

            discovery = ToolingDiscovery(self._working_dir, self._llm_config)
            cache = discovery.load_cache()
            if not cache:
                return {}

            verification = cache.get("verification", {})
            commands: dict[str, str] = {}
            for category in TOOL_CATEGORIES:
                entry = verification.get(category, {})
                if isinstance(entry, dict):
                    cmd = entry.get("command", "")
                    if cmd:
                        commands[category] = cmd
            return commands
        except Exception:
            return {}

    def on_mount(self) -> None:
        """Allow change emissions after mount completes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        # CRITICAL: Use call_after_refresh to delay setting _initializing = False
        # until AFTER all queued widget Changed events from initial value setting
        # have been processed. This prevents phantom changes from mount events.
        def finish_initialization() -> None:
            self._initializing = False
            # Re-snapshot state AFTER all mount events are processed
            self._snapshot_state()
            if is_debug_enabled():
                log_action(
                    "ValidationToolingView.on_mount.finish_init",
                    f"_initializing={self._initializing}, snapshot taken",
                )

        self.call_after_refresh(finish_initialization)

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("validation")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            # Scrollable container for main content
            with ScrollableContainer(id="content-scroll"):
                # Preflight messaging header
                yield Static(
                    "Pre-flight checks run before execution begins. They validate the "
                    "environment, install dependencies, and prepare the workspace.\n\n"
                    "Note: These checks may re-fire mid-session if new requirements are "
                    "detected (e.g., a new dependency discovered during execution).",
                    classes="preflight-header",
                )

                # Detected Tooling Panel
                from obra.config.explorer.widgets.detected_tooling_panel import (
                    DetectedToolingPanel,
                )

                yield DetectedToolingPanel(
                    working_dir=self._working_dir,
                    llm_config=self._llm_config,
                )

                # Automation mode section
                with Vertical(classes="mode-section"):
                    yield Static("Automation Mode", classes="mode-section-title")

                    # Get current automation mode
                    current_mode = self._current_values.get("automation_mode", "auto_full")

                    # RadioSet for mutual exclusion, RadioButtons only inside
                    with RadioSet(id="automation-mode-radioset"):
                        for mode in AUTOMATION_MODES:
                            yield RadioButton(
                                f"{mode.label} - {mode.description}",
                                id=f"mode-{mode.id}",
                                value=(mode.id == current_mode),
                            )

                # Story 0 settings in collapsible
                with Collapsible(title="Preflight Settings", collapsed=False, id="story0-settings"):
                    for setting_path, metadata in STORY0_SETTINGS.items():
                        yield from self._compose_setting_row(setting_path, metadata)

                # Discovery Settings section
                with Collapsible(
                    title="Discovery Settings", collapsed=True, id="discovery-settings"
                ):
                    for setting_path, metadata in DISCOVERY_SETTINGS.items():
                        yield from self._compose_setting_row(setting_path, metadata)

                # Custom Tool Commands section
                with Collapsible(
                    title="Custom Tool Commands",
                    collapsed=True,
                    id="custom-tool-commands",
                ):
                    yield Static(
                        "Customize verification commands. Add flags, change tools, "
                        "or leave blank to use auto-detected commands.",
                        classes="tool-section-help",
                    )
                    yield from self._compose_tool_command_rows()

            # Help footer with recognized files
            yield Static(
                "Recognized manifests: requirements.txt, pyproject.toml, package.json, "
                "Cargo.toml, go.mod, Gemfile, pom.xml, build.gradle, composer.json\n"
                "Tool configs: pytest.ini, ruff.toml, mypy.ini, .eslintrc, tsconfig.json, "
                "Makefile, justfile\n\n"
                "Changes are applied when you save. Use 's' to save.",
                classes="help-footer",
            )

    def _compose_setting_row(self, path: str, metadata: dict[str, Any]) -> ComposeResult:
        """Compose a single setting configuration row.

        Args:
            path: Config path for the setting
            metadata: Setting metadata dict
        """
        label = metadata.get("label", path.split(".")[-1])
        description = metadata.get("description", "")
        setting_type = metadata.get("type", "str")
        options = metadata.get("options")
        current_value = self._current_values.get(path)

        # Create unique ID from path
        widget_id = path.replace(".", "-")

        with Horizontal(classes="setting-row", id=f"setting-{widget_id}"):
            # Left: Setting info
            with Vertical(classes="setting-info"):
                yield Static(label, classes="setting-label")
                yield Static(description, classes="setting-description")

            # Right: Control widget
            with Vertical(classes="setting-control"):
                if setting_type == "bool":
                    yield Switch(
                        value=(bool(current_value) if current_value is not None else False),
                        id=f"switch-{widget_id}",
                    )
                elif setting_type == "select" and options:
                    # Use option_labels for display if provided, otherwise use raw value
                    # Textual Select format: (display_label, value)
                    option_labels = metadata.get("option_labels", {})
                    select_options = [(option_labels.get(opt, opt), opt) for opt in options]
                    yield Select(
                        select_options,
                        id=f"select-{widget_id}",
                        value=str(current_value) if current_value else options[0],
                        allow_blank=False,
                    )
                elif setting_type == "int":
                    default = 0
                    yield Input(
                        value=(str(current_value) if current_value is not None else str(default)),
                        id=f"input-{widget_id}",
                        type="integer",
                    )
                else:
                    # String or unknown type
                    yield Input(
                        value=str(current_value) if current_value is not None else "",
                        id=f"input-{widget_id}",
                    )

    def _compose_tool_command_rows(self) -> ComposeResult:
        """Compose tool command override rows for each category."""
        for category in TOOL_CATEGORIES:
            config_path = f"fix.verification.tools.{category}.command"
            current_value = self._current_values.get(config_path, "")
            detected_cmd = self._detected_commands.get(category, "")
            example_cmd = TOOL_EXAMPLES.get(category, "")

            with Vertical(classes="tool-row", id=f"tool-row-{category}"):
                # Header: Category name and detected command
                with Vertical(classes="tool-header"):
                    yield Static(f"{category.capitalize()} Command", classes="tool-label")

                    # Show detected command if available
                    if detected_cmd:
                        yield Static(f"Detected: {detected_cmd}", classes="tool-detected")

                    # Show effective command (what will actually run)
                    if current_value:
                        yield Static(
                            f"Will run: {current_value} (custom)",
                            classes="tool-effective-custom",
                        )
                    elif detected_cmd:
                        yield Static(
                            f"Will run: {detected_cmd} (auto-detected)",
                            classes="tool-effective",
                        )
                    else:
                        yield Static("Will run: (not configured)", classes="tool-effective")

                # Input row with Reset button (disabled when empty)
                with Horizontal(classes="tool-input-row"):
                    yield Input(
                        value=str(current_value) if current_value else "",
                        id=f"tool-{category}",
                        placeholder=(f"e.g., {example_cmd}" if example_cmd else "Enter command"),
                    )
                    yield Button(
                        "Reset",
                        id=f"reset-{category}",
                        variant="warning" if current_value else "default",
                        disabled=not current_value,
                    )

        # Footer guidance for advanced customization
        yield Static(
            "These are Obra's standard verification categories. "
            "For additional tools or custom scripts, edit .obra/config.yaml",
            classes="tool-section-footer",
        )

    def _emit_change(self, path: str, value: Any) -> None:
        """Emit a change message if not initializing.

        Skips emission during initial mount to prevent spurious changes.
        """
        if self._initializing:
            return
        self.post_message(self.Changed(path, value))

    def _update_tool_effective_label(self, category: str, custom_value: str) -> None:
        """Update the 'Will run' effective label for a tool category.

        Args:
            category: Tool category (test, lint, format, typecheck)
            custom_value: Custom command value, or empty string for auto-detected
        """
        detected_cmd = self._detected_commands.get(category, "")

        # Determine effective command text
        if custom_value:
            text = f"Will run: {custom_value} (custom)"
            css_class = "tool-effective-custom"
        elif detected_cmd:
            text = f"Will run: {detected_cmd} (auto-detected)"
            css_class = "tool-effective"
        else:
            text = "Will run: (not configured)"
            css_class = "tool-effective"

        # Find and update the effective label in this tool row
        try:
            tool_row = self.query_one(f"#tool-row-{category}")
            # Find the effective label (either .tool-effective or .tool-effective-custom)
            for label in tool_row.query(Static):
                label_text = str(label.render())
                if label_text.startswith("Will run:"):
                    label.update(text)
                    # Update CSS class
                    label.remove_class("tool-effective", "tool-effective-custom")
                    label.add_class(css_class)
                    break
        except Exception:
            pass

    def on_radio_set_changed(self, event: RadioSet.Changed) -> None:
        """Handle automation mode radio selection changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        if event.radio_set.id != "automation-mode-radioset":
            return

        # Get the selected radio button
        pressed = event.pressed
        if not pressed or not pressed.id:
            return

        # Extract mode ID from radio button ID (e.g., "mode-auto_full" -> "auto_full")
        if pressed.id.startswith("mode-"):
            mode_id = pressed.id.replace("mode-", "")
            self._current_values["automation_mode"] = mode_id
            self._emit_change("automation_mode", mode_id)

    def on_switch_changed(self, event: Switch.Changed) -> None:
        """Handle switch toggle changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        switch_id = event.switch.id
        if not switch_id or not switch_id.startswith("switch-"):
            return

        # Extract path from ID
        path = switch_id.replace("switch-", "").replace("-", ".")
        self._current_values[path] = event.value
        self._emit_change(path, event.value)

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select dropdown changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        select_id = event.select.id
        if not select_id or not select_id.startswith("select-"):
            return

        # Handle Select.BLANK sentinel - skip processing for blank selections
        if event.value is Select.BLANK:
            return

        # Extract path from ID
        path = select_id.replace("select-", "").replace("-", ".")
        value = str(event.value)
        self._current_values[path] = value
        self._emit_change(path, value)

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle input field changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        input_id = event.input.id
        if not input_id:
            return

        # Handle tool command inputs (e.g., "tool-test" -> "fix.verification.tools.test.command")
        if input_id.startswith("tool-"):
            category = input_id.replace("tool-", "")
            path = f"fix.verification.tools.{category}.command"
            self._current_values[path] = event.value
            self._emit_change(path, event.value)

            # Update Reset button state
            try:
                reset_btn = self.query_one(f"#reset-{category}", Button)
                has_value = bool(event.value)
                reset_btn.disabled = not has_value
                reset_btn.variant = "warning" if has_value else "default"
            except Exception:
                pass

            # Update effective label
            self._update_tool_effective_label(category, event.value)
            return

        # Regular input handling
        if not input_id.startswith("input-"):
            return

        # Extract path from ID
        path = input_id.replace("input-", "").replace("-", ".")

        # Get the setting type to convert the value
        # Check both STORY0_SETTINGS and DISCOVERY_SETTINGS
        metadata = STORY0_SETTINGS.get(path) or DISCOVERY_SETTINGS.get(path, {})
        setting_type = metadata.get("type", "str")

        value: int | str
        try:
            if setting_type == "int":
                value = int(event.value) if event.value else 0
            else:
                value = event.value
        except ValueError:
            # Invalid input, skip update
            return

        self._current_values[path] = value
        self._emit_change(path, value)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if self._initializing:
            return

        button_id = event.button.id
        if not button_id:
            return

        # Handle reset buttons for tool commands
        if button_id.startswith("reset-"):
            category = button_id.replace("reset-", "")
            path = f"fix.verification.tools.{category}.command"

            # Clear the input
            try:
                input_widget = self.query_one(f"#tool-{category}", Input)
                input_widget.value = ""
            except Exception:
                pass

            # Disable the Reset button since value is now empty
            try:
                reset_btn = self.query_one(f"#reset-{category}", Button)
                reset_btn.disabled = True
                reset_btn.variant = "default"
            except Exception:
                pass

            # Update the effective label to show auto-detected
            self._update_tool_effective_label(category, "")

            # Emit change with empty value
            self._current_values[path] = ""
            self._emit_change(path, "")

    def get_current_values(self) -> dict[str, Any]:
        """Get all current setting values.

        Returns:
            Dict mapping config paths to current values
        """
        return self._current_values.copy()

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking.

        Returns config paths mapped to current values.
        """
        return self._current_values.copy()

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and update UI."""
        self._current_values = state.copy()
        # Update all UI widgets to reflect restored state
        for path, value in state.items():
            widget_id = path.replace(".", "-")

            # Handle automation_mode specially (RadioSet)
            if path == "automation_mode":
                try:
                    for mode in AUTOMATION_MODES:
                        radio_btn = self.query_one(f"#mode-{mode.id}", RadioButton)
                        radio_btn.value = mode.id == value
                except Exception:
                    pass
                continue

            metadata = STORY0_SETTINGS.get(path, {})
            setting_type = metadata.get("type", "str")

            try:
                if setting_type == "bool":
                    switch = self.query_one(f"#switch-{widget_id}", Switch)
                    switch.value = bool(value) if value is not None else False
                elif setting_type == "select":
                    select = self.query_one(f"#select-{widget_id}", Select)
                    select.value = str(value) if value else ""
                else:
                    input_widget = self.query_one(f"#input-{widget_id}", Input)
                    input_widget.value = str(value) if value is not None else ""
            except Exception:
                pass
