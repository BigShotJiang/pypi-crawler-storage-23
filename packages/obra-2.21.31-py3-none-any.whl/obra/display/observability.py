"""Observability infrastructure for Obra CLI operations.

This module provides progressive verbosity levels and progress emission
for CLI commands, allowing users to observe LLM streaming, orchestration
phases, and execution progress in real-time.

Verbosity Levels:
    0 (QUIET): Minimal output - final results only
    1 (PROGRESS): Phase transitions with timestamps
    2 (DETAIL): Item-level details and LLM summaries
    3 (DEBUG): Full protocol info and debug messages

Usage:
    config = ObservabilityConfig(verbosity=VerbosityLevel.PROGRESS, stream=True)
    emitter = ProgressEmitter(config, console)
    emitter.phase_started("DERIVATION")
    emitter.llm_streaming("Here is my response...")
    emitter.phase_completed("DERIVATION", duration_ms=1500)

Security:
    - NEVER emit user prompts or LLM system prompts (IP protection)
    - NEVER emit API keys, credentials, or secrets
    - LLM responses are safe to show (user-requested observability)
"""

import sys
import time
from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum

from rich.console import Console

from obra.config.loaders import get_display_limit, get_spinner_config
from obra.core.interrupts import interrupt_requested
from obra.display.charset import glyphs
from obra.display.pipeline import PipelineRenderer
from obra.display.spinner import StatusSpinner, set_active_spinner


class VerbosityLevel(IntEnum):
    """Progressive verbosity levels for CLI output.

    Attributes:
        QUIET: Minimal output - final results only
        PROGRESS: Phase transitions with timestamps
        DETAIL: Item-level details and LLM summaries
        DEBUG: Full protocol info and debug messages
    """

    QUIET = 0
    PROGRESS = 1
    DETAIL = 2
    DEBUG = 3


_STAGE_USER_LABELS: dict[str, str] = {
    "intent_generation": "intent_generation — elaborating your request",
    "assumptions": "assumptions — resolving missing details",
    "analogues": "analogues — scanning similar solutions",
    "brief": "brief — consolidating intent into a planning brief",
    "derive": "derive — detailing the execution plan",
    "revise": "revise — refining the plan",
    "intent_alignment": "intent_alignment — checking intent coverage",
    "review": "review — running review agents",
    "execute": "execute — implementing plan items",
    "validator": "validator — validating review output",
}

_PHASE_STATUS_LINES: dict[str, str] = {
    "USERPLAN_GENERATION": "plan — generating the user plan",
    "DERIVATION": "derive — detailing the execution plan",
    "REFINEMENT": "revise — refining the plan",
    "REVIEW": "review — preparing review agents",
    "EXECUTION": "execute — implementing plan items",
}

_RUNTIME_VERBOSITY: int = VerbosityLevel.PROGRESS


def set_runtime_verbosity(verbosity: int) -> None:
    """Update global verbosity hint for modules that lack direct config."""
    global _RUNTIME_VERBOSITY
    _RUNTIME_VERBOSITY = int(verbosity)


def get_runtime_verbosity() -> int:
    """Return global verbosity hint for modules that lack direct config."""
    return _RUNTIME_VERBOSITY


@dataclass
class ObservabilityConfig:
    """Configuration for CLI observability features.

    Attributes:
        verbosity: Output detail level (0-3)
        stream: Whether to show LLM responses as they stream
        timestamps: Whether to include timestamps in output
        dashboard_enabled: Master toggle for dashboard UI elements
        footer_hint_enabled: Toggle for Ctrl+C footer hint
        task_tracker_enabled: Toggle for task tracker output
        task_tracker_max_next: Max number of upcoming tasks to show
    """

    verbosity: int = VerbosityLevel.PROGRESS
    stream: bool = False
    timestamps: bool = True
    dashboard_enabled: bool = True
    footer_hint_enabled: bool = True
    task_tracker_enabled: bool = True
    task_tracker_max_next: int = 3


class ProgressEmitter:
    """Emits progress events based on observability configuration.

    This class formats and displays orchestration progress events according
    to the configured verbosity level, supporting real-time LLM streaming
    and progressive detail disclosure.

    Attributes:
        config: Observability configuration (None uses defaults)
        console: Rich Console for formatted output
    """

    _ALLOWED_LLM_STATES = {"idle", "waiting", "streaming", "processing"}

    def __init__(self, config: ObservabilityConfig | None, console: Console) -> None:
        """Initialize the progress emitter.

        Args:
            config: Observability config, or None for defaults
            console: Rich Console instance for output
        """
        import threading

        self.config = config or ObservabilityConfig()
        self.console = console
        self._total_tasks: int = 0
        self._plan_version: int = 0
        self._plan_total_locked: bool = False
        self._current_task_index: int = 0
        self._files_created: int = 0
        self._files_modified: int = 0
        self._heartbeat_count: int = 0
        self._counters: dict[str, int] = {}
        stdout_is_tty = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
        console_is_terminal = False
        try:
            console_value = getattr(console, "is_terminal", False)
            if isinstance(console_value, bool):
                console_is_terminal = console_value
        except Exception:
            console_is_terminal = False
        self._is_tty = bool(stdout_is_tty or console_is_terminal)

        # Status spinner for long-running operations
        self._spinner: StatusSpinner | None = None
        if self._is_tty and get_spinner_config("enabled"):
            self._spinner = StatusSpinner(
                console,
                phrase_rotation_interval_s=float(get_spinner_config("phrase_rotation_interval_s")),
                phrase_rotation_min_s=float(get_spinner_config("phrase_rotation_min_s")),
                phrase_rotation_max_s=float(get_spinner_config("phrase_rotation_max_s")),
                accent_enabled=bool(get_spinner_config("accent_enabled")),
                accent_highlight_color=str(get_spinner_config("accent_highlight_color")),
                accent_highlight_width=int(get_spinner_config("accent_highlight_width")),
                accent_highlight_gradient=bool(get_spinner_config("accent_highlight_gradient")),
                accent_sweep_target_s=float(get_spinner_config("accent_sweep_target_s")),
                accent_step_min_ms=int(get_spinner_config("accent_step_min_ms")),
                accent_step_max_ms=int(get_spinner_config("accent_step_max_ms")),
                accent_pause_min_s=float(get_spinner_config("accent_pause_min_s")),
                accent_pause_max_s=float(get_spinner_config("accent_pause_max_s")),
                refresh_rate_hz=int(get_spinner_config("refresh_rate_hz")),
            )
            set_active_spinner(self._spinner)
        self._spinner_active_count: int = 0
        self._spinner_rotation_paused: bool = False
        self._stage_spinner_active: set[str] = set()

        self._session_id: str | None = None
        self._review_attempt: int = 0
        self._review_max_attempts: int = 0
        self._review_agents: dict[str, str] = {}
        self._review_agent_count: int | None = None
        self._review_parallel: bool | None = None
        self._active_review_item_id: str | None = None
        self._active_review_cycle_id: str | None = None
        self._lock = threading.Lock()
        self._llm_state: str = "idle"
        self._dashboard_enabled: bool = bool(self.config.dashboard_enabled)
        self._footer_hint_enabled: bool = bool(self.config.footer_hint_enabled)
        self._task_tracker_enabled: bool = bool(self.config.task_tracker_enabled)
        self._task_tracker_max_next: int = max(0, int(self.config.task_tracker_max_next))
        self._task_tracker_items: list[dict[str, str]] = []
        self._task_tracker_index: dict[str, int] = {}
        self._task_tracker_done: set[str] = set()
        self._task_tracker_current_id: str | None = None
        self._task_tracker_current_title: str | None = None
        self._plan_items: list[dict[str, object]] = []
        self._plan_index: dict[str, dict[str, object]] = {}
        self._plan_children: dict[str | None, list[str]] = {}
        self._plan_status: dict[str, str] = {}
        self._plan_order: dict[str, int] = {}
        self._completed_stories: set[str] = set()
        self._completed_epics: set[str] = set()
        self._last_completion_data: dict[str, object] = {}
        self._last_plan_render_s: float | None = None
        self._last_plan_render_reason: str | None = None
        self._plan_render_min_interval_s: float = 2.0
        self._stage_heartbeat_last_emit: dict[str, float] = {}
        self._stage_heartbeat_emit_interval_s: float = 60.0
        self._stage_heartbeat_tty_emit_interval_s: float = 30.0
        self._current_stage_context: dict | None = None
        self._active_phase_name: str | None = None
        self._active_stage_name: str | None = None
        # Footer hint rate limiting - avoid cluttering output on rapid phase changes
        self._last_footer_hint_s: float | None = None
        self._footer_hint_min_interval_s: float = 30.0
        # Unified derivation step tracking (3-step pipeline)
        self._derive_current_step: int | None = None
        self._derive_current_step_name: str | None = None
        self._derive_step_start_time: float | None = None
        self._derive_last_output_time: float | None = None
        self._last_plan_summary: dict[str, int] | None = None
        self._plan_source: str | None = None
        self._plan_mode: str | None = None
        # Track whether the full plan tree has been rendered at least once (for revise suppression)
        self._plan_tree_rendered_once: bool = False
        # Display limits cached from config (CHORE-MAGIC-VALUES-002)
        self._title_max_chars: int = get_display_limit("title_max_chars")
        self._description_max_chars: int = get_display_limit("description_max_chars")
        self._note_max_chars: int = get_display_limit("note_max_chars")
        self._seconds_before_minutes: int = get_display_limit("seconds_before_minutes")
        # Pipeline visualization for stage progress
        self._pipeline: PipelineRenderer = PipelineRenderer(console)
        self._pipeline_enabled: bool = True  # Can be disabled via config if needed
        self._last_pipeline_stage: str | None = None

    def _truncate_title(self, title: str) -> str:
        """Truncate title to configured max length with ellipsis."""
        limit = self._title_max_chars
        return title[:limit] + "..." if len(title) > limit else title

    def _truncate_description(self, text: str) -> str:
        """Truncate description/objective to configured max length with ellipsis."""
        limit = self._description_max_chars
        return text[:limit] + "..." if len(text) > limit else text

    def _truncate_note(self, text: str) -> str:
        """Truncate status note to configured max length with ellipsis."""
        limit = self._note_max_chars
        return text[:limit] + "..." if len(text) > limit else text

    def _get_stage_label(self, stage: str) -> str:
        base_stage = stage.split("_pass_")[0]
        return _STAGE_USER_LABELS.get(base_stage, base_stage.replace("_", " ").title())

    def _get_phase_status_line(self, phase: str | None) -> str | None:
        if not phase:
            return None
        return _PHASE_STATUS_LINES.get(str(phase).upper())

    def _get_stage_status_line(self, stage: str | None) -> str | None:
        if not stage:
            return None
        base_stage = str(stage).split("_pass_")[0]
        return _STAGE_USER_LABELS.get(base_stage)

    def _restore_spinner_status_line(self) -> None:
        """Restore spinner status to current stage/phase context, or clear when unknown."""
        if not self._spinner or not self._spinner.is_active:
            return

        status_line = self._get_stage_status_line(self._active_stage_name)
        if not status_line:
            status_line = self._get_phase_status_line(self._active_phase_name)

        if status_line:
            self._spinner.update_status_line(status_line, style="cyan")
        else:
            self._spinner.clear_status_line()

    def update_plan_snapshot(
        self,
        plan_items: list[dict],
        source: str | None = None,
        session_id: str | None = None,
        mode: str | None = None,
    ) -> None:
        """Update cached plan items and render the plan tree."""
        if mode == "partial":
            self._render_partial_plan_snapshot(plan_items, source)
            return
        tracker_sync_only = mode == "tracker_sync"
        if session_id:
            self._session_id = session_id
        if tracker_sync_only:
            self.set_plan_items(plan_items)
            if source:
                self._plan_source = source
            if mode:
                self._plan_mode = mode
            if self.config.verbosity >= VerbosityLevel.DEBUG:
                self._print(
                    f"[DEBUG] ProgressEmitter: tracker synced with {len(self._task_tracker_items)} executable plan items",
                    style="dim",
                )
            return

        previous_items = list(self._plan_items)
        self.set_plan_items(plan_items)

        normalized_items: list[dict[str, object]] = []
        plan_index: dict[str, dict[str, object]] = {}
        plan_children: dict[str | None, list[str]] = {}
        plan_status: dict[str, str] = {}
        plan_order: dict[str, int] = {}

        for item in plan_items:
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id") or item.get("item_id") or "").strip()
            if not item_id:
                continue
            title = str(item.get("title") or item.get("description") or "").strip()
            description = str(item.get("description") or "").strip()
            item_type = str(item.get("item_type") or "").strip().lower()
            if not item_type:
                item_type = self._infer_item_type(item_id)
            parent_id = item.get("parent_id")
            parent_id = str(parent_id).strip() if parent_id is not None else None
            depth = item.get("depth")
            try:
                depth_value = int(depth) if depth is not None else 0
            except (TypeError, ValueError):
                depth_value = 0
            order_value = item.get("order")
            try:
                order = int(order_value) if order_value is not None else -1
            except (TypeError, ValueError):
                order = -1
            status = self._normalize_status(str(item.get("status", "")).strip())

            # Extract context if present
            context = item.get("context", {})

            normalized = {
                "id": item_id,
                "title": title,
                "description": description,
                "item_type": item_type,
                "parent_id": parent_id or "",
                "depth": depth_value,
                "context": context,
            }
            normalized_items.append(normalized)
            plan_index[item_id] = normalized
            plan_status[item_id] = status
            plan_order[item_id] = order
            plan_children.setdefault(parent_id or None, []).append(item_id)

        self._plan_items = normalized_items
        self._plan_index = plan_index
        self._plan_children = plan_children
        self._plan_status = plan_status
        self._plan_order = plan_order
        if source:
            self._plan_source = source
        if mode:
            self._plan_mode = mode
        self._last_plan_summary = {
            "epic": sum(1 for item in normalized_items if item.get("item_type") == "epic"),
            "story": sum(1 for item in normalized_items if item.get("item_type") == "story"),
            "task": sum(1 for item in normalized_items if item.get("item_type") == "task"),
        }
        # Recompute completed stories/epics from plan_status so that
        # items already completed (e.g. from a previous session on resume)
        # are recognised and won't re-emit milestone messages.
        self._completed_stories.clear()
        self._completed_epics.clear()
        self._seed_completed_milestones()

        reason = "Plan updated"
        if source == "derive":
            reason = "Plan derived"
        elif source == "revise":
            reason = "Plan revised"

        # For revise: show compact diff instead of full tree after the first render.
        # Full tree is only shown at DETAIL verbosity (-vv) for subsequent revisions.
        is_first_render = self._last_plan_render_s is None
        if source == "revise" and self._plan_tree_rendered_once:
            # Show compact change summary instead of full tree
            if self.config.verbosity >= VerbosityLevel.PROGRESS:
                summary = self._summarize_plan_changes(previous_items, normalized_items)
                timestamp = self._timestamp()
                prev_count = len(previous_items)
                curr_count = len(normalized_items)
                header = f"Plan revised: {curr_count} items"
                if prev_count != curr_count:
                    header += f" (was {prev_count})"
                self._print(f"\n{timestamp}{header}", style="cyan")
                if summary:
                    self._print(summary, style="dim")
                if self._last_plan_summary:
                    epic_c = self._last_plan_summary.get("epic", 0)
                    story_c = self._last_plan_summary.get("story", 0)
                    task_c = self._last_plan_summary.get("task", 0)
                    self._print(
                        f"  Plan: {epic_c} Epics, {story_c} Stories, {task_c} Tasks",
                        style="dim",
                    )
            # Still render the full tree at DETAIL verbosity
            if self.config.verbosity >= VerbosityLevel.DETAIL:
                self.render_plan_tree(reason=reason, source=source or None, force=True)
        else:
            # First plan render (from derive) or non-revise source: show full tree
            self.render_plan_tree(reason=reason, source=source or None, force=is_first_render)
            self._plan_tree_rendered_once = True

    def _render_partial_plan_snapshot(self, plan_items: list[dict], source: str | None) -> None:
        """Render a compact, in-progress plan snapshot at DETAIL verbosity."""
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        if not plan_items:
            return

        epic_item = None
        stories: list[dict] = []
        tasks: list[dict] = []
        for item in plan_items:
            if not isinstance(item, dict):
                continue
            item_type = str(item.get("item_type") or "").lower()
            if item_type == "epic" and epic_item is None:
                epic_item = item
            elif item_type == "story":
                stories.append(item)
            elif item_type == "task":
                tasks.append(item)

        if not epic_item:
            return

        epic_id = str(epic_item.get("id", "")).strip()
        epic_title = str(epic_item.get("title", "")).strip() or "Untitled"
        header = "Plan snapshot (partial)"
        if source:
            header = f"{header}, source: {source}"
        header = f"{header} - {epic_id}: {epic_title}"

        timestamp = self._timestamp()
        self._print(f"{timestamp}{header}", style="cyan")

        story_map: dict[str, list[dict]] = {}
        for task in tasks:
            parent_id = str(task.get("parent_id") or "").strip()
            if parent_id:
                story_map.setdefault(parent_id, []).append(task)

        max_stories = 5
        max_tasks = 5
        for story in stories[:max_stories]:
            story_id = str(story.get("id", "")).strip()
            story_title = str(story.get("title", "")).strip() or "Untitled"
            task_count = len(story_map.get(story_id, []))
            self._print(
                f"  - {story_id}: {story_title} ({task_count} tasks)",
                style="dim",
            )
            for task in story_map.get(story_id, [])[:max_tasks]:
                task_id = str(task.get("id", "")).strip()
                task_title = str(task.get("title", "")).strip() or "Untitled"
                self._print(f"    - {task_id}: {task_title}", style="dim")
            if task_count > max_tasks:
                self._print(
                    f"    - +{task_count - max_tasks} more tasks",
                    style="dim",
                )

        if len(stories) > max_stories:
            self._print(
                f"  - +{len(stories) - max_stories} more stories",
                style="dim",
            )

    def item_skipped(self, item: dict) -> None:
        """Emit event when processing a plan item is skipped."""
        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        if normalized_id and normalized_id != "?":
            self._task_tracker_done.add(normalized_id)
            if self._task_tracker_current_id == normalized_id:
                self._task_tracker_current_id = None
                self._task_tracker_current_title = None
            self._plan_status[normalized_id] = "skipped"
            self._maybe_render_story_completion(normalized_id)

    def render_plan_tree(self, reason: str, source: str | None, *, force: bool = False) -> None:
        """Render the full plan tree at PROGRESS verbosity or higher."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if not self._plan_items:
            return
        if not force and self._last_plan_render_s is not None:
            now = datetime.now().timestamp()
            elapsed = now - self._last_plan_render_s
            if (
                self._last_plan_render_reason == reason
                and elapsed < self._plan_render_min_interval_s
            ):
                return

        header = "Plan"
        if source:
            header = f"{header} (source: {source})"
        if self.config.verbosity >= VerbosityLevel.DETAIL and self._plan_mode:
            header = f"{header}, mode: {self._plan_mode}"
        if reason:
            header = f"{header} - {reason}"
        self._print("")
        self._print(header, style="bold cyan")
        self._last_plan_render_s = datetime.now().timestamp()
        self._last_plan_render_reason = reason

        roots: set[str] = set()
        for item_id, item in self._plan_index.items():
            parent_id = item.get("parent_id") or None
            if not parent_id or parent_id not in self._plan_index:
                roots.add(item_id)
        roots_list = self._sort_plan_ids(list(roots))

        for root_id in roots_list:
            self._render_plan_node(root_id, level=0)

        if self._last_plan_summary:
            epic_count = self._last_plan_summary.get("epic", 0)
            story_count = self._last_plan_summary.get("story", 0)
            task_count = self._last_plan_summary.get("task", 0)
            self._print(
                f"\nPlan: {epic_count} Epics, {story_count} Stories, {task_count} Tasks",
                style="dim",
            )

    def _render_plan_node(self, item_id: str, level: int) -> None:
        item = self._plan_index.get(item_id, {})
        title = str(item.get("title", ""))
        item_type = str(item.get("item_type", "task")).upper()
        status = self._aggregate_status(item_id)
        status_label = self._format_status_label(status)
        indent = "  " * level
        display_title = title if title else "untitled"

        # Add user story traceability if present
        context = item.get("context", {})
        user_story_ids = context.get("user_story_ids", []) if isinstance(context, dict) else []
        story_suffix = f" [{', '.join(user_story_ids)}]" if user_story_ids else ""

        line = f"{indent}[{status_label}] {item_id} {item_type}: {display_title}{story_suffix}"
        self._print(line, style="dim" if status in ("pending", "skipped") else None)

        children = self._sort_plan_ids(self._plan_children.get(item_id, []))
        for child_id in children:
            self._render_plan_node(child_id, level=level + 1)

    def _sort_plan_ids(self, ids: list[str]) -> list[str]:
        def sort_key(item_id: str) -> tuple[int, str]:
            order = self._plan_order.get(item_id, -1)
            if order < 0:
                order = 1_000_000
            return (order, item_id)

        return sorted(ids, key=sort_key)

    def _normalize_status(self, status: str) -> str:
        normalized = status.lower()
        if normalized in {"completed", "complete", "done", "success", "ok"}:
            return "completed"
        if normalized in {"in_progress", "running", "started"}:
            return "in_progress"
        if normalized in {"failed", "error", "failure", "partial", "interrupted"}:
            return "failed"
        if normalized in {"skipped", "skip"}:
            return "skipped"
        return "pending"

    def _format_status_label(self, status: str) -> str:
        return {
            "completed": "done",
            "in_progress": "running",
            "failed": "failed",
            "skipped": "skipped",
            "pending": "pending",
        }.get(status, "pending")

    def _aggregate_status(self, item_id: str) -> str:
        children = self._plan_children.get(item_id)
        if not children:
            return self._plan_status.get(item_id, "pending")

        child_statuses = [self._aggregate_status(child_id) for child_id in children]
        if any(status == "failed" for status in child_statuses):
            return "failed"
        if any(status == "in_progress" for status in child_statuses):
            return "in_progress"
        if all(status in {"completed", "skipped"} for status in child_statuses):
            return "completed"
        return "pending"

    def _infer_item_type(self, item_id: str) -> str:
        if item_id.startswith("E"):
            return "epic"
        if item_id.startswith("S") and ".T" not in item_id:
            return "story"
        if ".T" in item_id:
            if item_id.count(".") >= 2:
                return "subtask"
            return "task"
        return "task"

    def _summarize_plan_changes(
        self,
        previous_items: list[dict[str, object]],
        current_items: list[dict[str, object]],
    ) -> str | None:
        if not previous_items:
            return None

        def to_map(items: list[dict[str, object]]) -> dict[str, dict[str, object]]:
            result: dict[str, dict[str, object]] = {}
            for item in items:
                item_id = str(item.get("id", "")).strip()
                if item_id:
                    result[item_id] = item
            return result

        prev_map = to_map(previous_items)
        curr_map = to_map(current_items)
        prev_ids = set(prev_map.keys())
        curr_ids = set(curr_map.keys())

        added_ids = sorted(curr_ids - prev_ids)
        removed_ids = sorted(prev_ids - curr_ids)

        updated_ids: list[str] = []
        moved_ids: list[str] = []
        for item_id in sorted(prev_ids & curr_ids):
            prev = prev_map[item_id]
            curr = curr_map[item_id]
            if (prev.get("parent_id") or "") != (curr.get("parent_id") or ""):
                moved_ids.append(item_id)
            if (
                (prev.get("title") or "") != (curr.get("title") or "")
                or (prev.get("description") or "") != (curr.get("description") or "")
                or (prev.get("item_type") or "") != (curr.get("item_type") or "")
            ):
                updated_ids.append(item_id)

        lines: list[str] = []
        max_detail_items = 3

        # Show added items with titles
        if added_ids:
            for item_id in added_ids[:max_detail_items]:
                item = curr_map.get(item_id, {})
                title = str(item.get("title", "")).strip()
                if title:
                    lines.append(f"  + {item_id}: {title}")
                else:
                    lines.append(f"  + {item_id}")
            if len(added_ids) > max_detail_items:
                lines.append(f"  + {len(added_ids) - max_detail_items} more added")

        # Show removed items with titles
        if removed_ids:
            for item_id in removed_ids[:max_detail_items]:
                item = prev_map.get(item_id, {})
                title = str(item.get("title", "")).strip()
                if title:
                    lines.append(f"  - {item_id}: {title}")
                else:
                    lines.append(f"  - {item_id}")
            if len(removed_ids) > max_detail_items:
                lines.append(f"  - {len(removed_ids) - max_detail_items} more removed")

        # Summarize updated/moved as counts
        if updated_ids:
            lines.append(f"  ~ {len(updated_ids)} items updated")
        if moved_ids:
            lines.append(f"  ~ {len(moved_ids)} items moved")

        return "\n".join(lines) if lines else None

    def _find_ancestor(self, item_id: str, target_type: str) -> str | None:
        current_id = item_id
        while current_id:
            current = self._plan_index.get(current_id)
            if not current:
                return None
            if current.get("item_type") == target_type:
                return current_id
            parent_id = current.get("parent_id") or None
            if not parent_id:
                return None
            current_id = str(parent_id)
        return None

    def _iter_descendants(self, item_id: str) -> list[str]:
        descendants: list[str] = []
        stack = list(self._plan_children.get(item_id, []))
        while stack:
            current = stack.pop()
            descendants.append(current)
            stack.extend(self._plan_children.get(current, []))
        return descendants

    def _is_story_complete(self, story_id: str) -> bool:
        descendants = self._iter_descendants(story_id)
        if not descendants:
            return False
        leaf_ids = [
            desc
            for desc in descendants
            if not self._plan_children.get(desc)
            and self._plan_index.get(desc, {}).get("item_type") in {"task", "subtask"}
        ]
        if not leaf_ids:
            return False
        return all(
            self._plan_status.get(leaf_id, "pending") in {"completed", "skipped"}
            for leaf_id in leaf_ids
        )

    def _is_epic_complete(self, epic_id: str) -> bool:
        descendants = self._iter_descendants(epic_id)
        story_ids = [
            desc
            for desc in descendants
            if self._plan_index.get(desc, {}).get("item_type") == "story"
        ]
        if not story_ids:
            return False
        return all(self._is_story_complete(story_id) for story_id in story_ids)

    def _maybe_render_story_completion(self, item_id: str) -> None:
        story_id = self._find_ancestor(item_id, "story")
        if story_id and story_id not in self._completed_stories:
            if self._is_story_complete(story_id):
                self._completed_stories.add(story_id)
                # P2-3: Print compact summary instead of full plan tree.
                # The full plan is printed once after refinement completes.
                tracker_ids = {
                    str(item.get("id", "")).strip()
                    for item in self._task_tracker_items
                    if str(item.get("id", "")).strip()
                }
                if tracker_ids:
                    total_items = len(tracker_ids)
                    done_count = len(self._task_tracker_done & tracker_ids)
                else:
                    total_items = len(self._plan_items)
                    done_count = sum(
                        1
                        for s in self._plan_status.values()
                        if s in ("completed", "skipped")
                    )
                self._print(
                    f"\u2713 Story {story_id} complete ({done_count}/{total_items} tasks done)",
                    style="green",
                )

                epic_id = self._find_ancestor(story_id, "epic")
                if epic_id and epic_id not in self._completed_epics:
                    if self._is_epic_complete(epic_id):
                        self._completed_epics.add(epic_id)
                        remaining_epics = self._count_remaining_epics()
                        self._print(
                            f"\u2713 Epic {epic_id} complete "
                            f"({done_count}/{total_items} tasks done"
                            f"{f', {remaining_epics} Epics remaining' if remaining_epics > 0 else ''})",
                            style="green",
                        )

    def _count_remaining_epics(self) -> int:
        """Count epics that are not yet completed.

        P2-3: Used for compact epic completion summary.
        """
        epic_ids = {
            str(item.get("id", ""))
            for item in self._plan_items
            if str(item.get("item_type", "")).lower() == "epic"
            or str(item.get("depth", "")) == "0"
            or str(item.get("level", "")).lower() == "epic"
        }
        return len(epic_ids - self._completed_epics)

    def _seed_completed_milestones(self) -> None:
        """Pre-compute ``_completed_stories`` and ``_completed_epics`` from ``_plan_status``.

        Called after ``_plan_status`` is populated (e.g. on resume) so that
        milestones already achieved in a prior session are recognised.
        This prevents re-emission and ensures future completions render
        correctly relative to already-done siblings.
        """
        if not self._plan_status or not self._plan_index:
            return

        # Walk every story; if all its leaf tasks are done, mark it complete.
        story_ids = [
            item_id
            for item_id, item in self._plan_index.items()
            if str(item.get("item_type", "")).lower() == "story"
        ]
        for story_id in story_ids:
            if self._is_story_complete(story_id):
                self._completed_stories.add(story_id)

        # Walk every epic; if all its stories are done, mark it complete.
        epic_ids = [
            item_id
            for item_id, item in self._plan_index.items()
            if str(item.get("item_type", "")).lower() == "epic"
        ]
        for epic_id in epic_ids:
            if self._is_epic_complete(epic_id):
                self._completed_epics.add(epic_id)

    def set_session_id(self, session_id: str) -> None:
        """Set the session ID for footer hints and correlation.

        Shows resume hint immediately so user knows how to recover
        if something goes wrong during derivation or execution.

        Args:
            session_id: Session identifier for the current run
        """
        self._session_id = session_id
        self.render_footer_hint()

    def restore_pipeline_checkmarks(self, phase: str) -> None:
        """Mark all pipeline stages before *phase* as completed.

        Call on resume so that the banner shows checkmarks for phases
        that were completed in a prior session.

        Args:
            phase: Current session phase (e.g. ``"EXECUTION"``).
        """
        if self._pipeline_enabled:
            self._pipeline.mark_stages_complete_up_to(phase)

    def set_plan_items(self, items: list[dict]) -> None:
        """Set plan items for task tracker rendering.

        Also seeds ``_task_tracker_done`` from item status when available
        (e.g. on resume, where items arrive with ``status: completed``).

        Args:
            items: List of plan item dicts with id/title fields
        """
        if not items:
            return

        staged: list[tuple[int, int | None, dict[str, str]]] = []
        # Collect status per item_id so we can seed the done set afterwards.
        status_by_id: dict[str, str] = {}
        has_explicit_order = False
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id", "")).strip()
            if not item_id:
                continue
            raw_item_type = str(item.get("item_type", "")).strip().lower()
            item_type = raw_item_type or self._infer_item_type(item_id)
            if not self._is_executable_item_type(item_type):
                continue
            title = str(item.get("title", "")).strip()
            raw_order = item.get("order")
            order_value: int | None = None
            try:
                if raw_order is not None:
                    order_value = int(raw_order)
            except (TypeError, ValueError):
                order_value = None
            if order_value is not None:
                has_explicit_order = True
            staged.append((index, order_value, {"id": item_id, "title": title}))
            # Capture status if the item carries one (resume / get_session_plan payloads).
            raw_status = str(item.get("status", "")).strip()
            if raw_status:
                status_by_id[item_id] = self._normalize_status(raw_status)

        if has_explicit_order:
            staged.sort(
                key=lambda entry: (
                    entry[1] if entry[1] is not None else 1_000_000,
                    entry[0],
                )
            )

        normalized = [entry[2] for entry in staged]
        index_map = {entry["id"]: idx for idx, entry in enumerate(normalized)}

        if not normalized:
            return

        self._task_tracker_items = normalized
        self._task_tracker_index = index_map
        self._total_tasks = len(normalized)
        # Plan snapshots are authoritative for tracker totals; prevent stale plan_total overwrites.
        self._plan_total_locked = True

        if self._task_tracker_current_id and not self._task_tracker_current_title:
            current_index = self._task_tracker_index.get(self._task_tracker_current_id)
            if current_index is not None:
                current_title = self._task_tracker_items[current_index].get("title")
                if current_title:
                    self._task_tracker_current_title = current_title

        # Preserve existing done items that still appear in the new plan …
        preserved_done = {
            task_id for task_id in self._task_tracker_done if task_id in index_map
        }
        # … and seed from item status (covers resume where items carry status).
        seeded_done = {
            item_id
            for item_id, status in status_by_id.items()
            if status in ("completed", "skipped") and item_id in index_map
        }
        self._task_tracker_done = preserved_done | seeded_done

    def _is_executable_item_type(self, item_type: str) -> bool:
        """Return True when an item should participate in task tracker queueing."""
        return item_type in {"task", "subtask"}

    def _dashboard_feature_enabled(self, enabled: bool) -> bool:
        """Return True if a dashboard UI element should render."""
        return (
            self._dashboard_enabled and enabled and self.config.verbosity >= VerbosityLevel.PROGRESS
        )

    def _timestamp(self) -> str:
        """Get current timestamp in [HH:MM:SS] format.

        Returns:
            Formatted timestamp string if timestamps enabled, empty string otherwise
        """
        if self.config.timestamps:
            return f"[{datetime.now().strftime('%H:%M:%S')}] "
        return ""

    def _format_status_line(self, status: str, message: str) -> str:
        """Format a status-first line with an optional timestamp."""
        timestamp = self._timestamp().strip()
        if timestamp:
            return f"{status} {timestamp} {message}"
        return f"{status} {message}"

    def start_spinner(self, phrase: str | None = None) -> None:
        """Start the status spinner for long operations."""
        if not self._spinner or self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if self._spinner_active_count > 0:
            if phrase:
                self._spinner.update_phrase(phrase)
            self._spinner_active_count += 1
            return
        self._spinner_active_count = 1
        self._spinner_rotation_paused = False
        self._spinner.start(phrase)

    def stop_spinner(self) -> None:
        """Stop the status spinner."""
        if not self._spinner or self._spinner_active_count <= 0:
            self._spinner_active_count = 0
            return
        self._spinner_active_count -= 1
        if self._spinner_rotation_paused:
            self._spinner.set_rotation_paused(False)
            self._spinner_rotation_paused = False
        if self._spinner_active_count <= 0:
            self._spinner.stop()
            self._spinner_active_count = 0

    def halt_spinner(self) -> None:
        """Immediately stop the status spinner, regardless of nesting depth."""
        if not self._spinner:
            self._spinner_active_count = 0
            self._stage_spinner_active.clear()
            self._spinner_rotation_paused = False
            return
        self._spinner_active_count = 0
        self._stage_spinner_active.clear()
        if self._spinner_rotation_paused:
            self._spinner.set_rotation_paused(False)
            self._spinner_rotation_paused = False
        if self._spinner.is_active:
            self._spinner.stop()

    def _start_stage_spinner(self, stage: str) -> None:
        """Start spinner for a stage if not already tracked."""
        if stage in self._stage_spinner_active:
            return
        self._stage_spinner_active.add(stage)
        self.start_spinner()

    def _stop_stage_spinner(self, stage: str) -> None:
        """Stop spinner for a stage if it was previously started."""
        if stage not in self._stage_spinner_active:
            return
        self._stage_spinner_active.remove(stage)
        self.stop_spinner()

    def _should_inline_heartbeat(self) -> bool:
        return (
            self._is_tty
            and self._spinner is not None
            and self._spinner.is_active
            and self.config.verbosity >= VerbosityLevel.PROGRESS
        )

    def use_inline_heartbeat(self) -> bool:
        """Return True if heartbeat should update the active spinner in-place."""
        return self._should_inline_heartbeat()

    def _format_elapsed(self, elapsed_s: int) -> str:
        minutes = max(0, int(elapsed_s)) // 60
        seconds = max(0, int(elapsed_s)) % 60
        return f"{minutes}m {seconds:02d}s"

    def _current_task_label(self, fallback_id: str) -> str:
        if self._task_tracker_current_id:
            title = self._task_tracker_current_title or ""
            if title:
                title = self._truncate_title(title)
                return f"{self._task_tracker_current_id}: {title}"
            return self._task_tracker_current_id
        if fallback_id.lower() == "execution":
            return "task"
        return fallback_id

    def reset_derive_step_state(self) -> None:
        """Reset unified derivation step tracking (call when step ends or derive phase ends)."""
        self._derive_current_step = None
        self._derive_current_step_name = None
        self._derive_step_start_time = None
        self._derive_last_output_time = None

    def set_total_tasks(self, total: int, plan_version: int | None = None) -> None:
        """Set the total task count and reset progress tracking.

        Args:
            total: Total number of tasks expected in this session
            plan_version: Plan version for staleness guard. When provided,
                rejects updates with a lower version than previously seen.
                Once a versioned update is accepted, unversioned updates
                are also rejected to prevent stale event overwrites.
        """
        if plan_version is not None:
            if plan_version < self._plan_version:
                return  # Stale versioned update
            is_newer_version = plan_version > self._plan_version
            prior_plan_version = self._plan_version
            self._plan_version = plan_version
            if (
                is_newer_version
                and prior_plan_version > 0
                and plan_version > 1
                and self.config.verbosity >= VerbosityLevel.PROGRESS
            ):
                self._print(f"Info: Plan revised to plan v{plan_version}.")
            if self._plan_total_locked and not is_newer_version:
                if self.config.verbosity >= VerbosityLevel.DEBUG:
                    self._print(
                        f"[DEBUG] ProgressEmitter: ignoring plan_total={total} "
                        f"(plan items locked, plan_version={plan_version})",
                        style="dim",
                    )
                return
        elif self._plan_version > 0:
            return  # Reject unversioned updates once a versioned one is seen
        elif self._plan_total_locked:
            if self.config.verbosity >= VerbosityLevel.DEBUG:
                self._print(
                    f"[DEBUG] ProgressEmitter: ignoring plan_total={total} (plan items locked)",
                    style="dim",
                )
            return

        self._total_tasks = total
        self._current_task_index = 0
        self._heartbeat_count = 0

        if self.config.verbosity >= VerbosityLevel.DEBUG:
            self._print(
                f"[DEBUG] ProgressEmitter: task count set to {total} (plan_version={plan_version})",
                style="dim",
            )

    def reset_review_state(self) -> None:
        """Reset review loop tracking state to defaults."""
        self._review_attempt = 0
        self._review_max_attempts = 0
        self._review_agents = {}
        self._active_review_item_id = None
        self._active_review_cycle_id = None

    def set_review_context(
        self,
        *,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> None:
        """Set active review context for cycle-correlated progress rendering."""
        normalized_item = str(item_id).strip() if item_id else ""
        normalized_cycle = str(review_cycle_id).strip() if review_cycle_id else ""
        if normalized_item:
            self._active_review_item_id = normalized_item
        if normalized_cycle:
            self._active_review_cycle_id = normalized_cycle

    def _review_context_matches(
        self,
        *,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> bool:
        normalized_item = str(item_id).strip() if item_id else ""
        normalized_cycle = str(review_cycle_id).strip() if review_cycle_id else ""
        if (
            self._active_review_cycle_id
            and normalized_cycle
            and normalized_cycle != self._active_review_cycle_id
        ):
            return False
        if (
            self._active_review_item_id
            and normalized_item
            and normalized_item != self._active_review_item_id
        ):
            return False
        return True

    def set_llm_state(self, state: str) -> None:
        """Set the current LLM state.

        Args:
            state: LLM state string ("idle", "waiting", "streaming", "processing")
        """
        if state not in self._ALLOWED_LLM_STATES:
            msg = f"Invalid LLM state: {state}"
            raise ValueError(msg)
        self._llm_state = state

    def get_llm_state(self) -> str:
        """Return the current LLM state."""
        return self._llm_state

    def review_loop_started(
        self,
        attempt: int,
        max_attempts: int,
        *,
        agent_count: int | None = None,
        parallel: bool | None = None,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> None:
        """Emit event when a review loop begins."""
        if not self._review_context_matches(item_id=item_id, review_cycle_id=review_cycle_id):
            if self.config.verbosity >= VerbosityLevel.DEBUG:
                self._print(
                    "[DEBUG] ProgressEmitter: dropped stale review_loop_started event",
                    style="dim",
                )
            return

        self._review_attempt = attempt
        self._review_max_attempts = max_attempts
        self._review_agents = {}
        self._review_agent_count = agent_count
        self._review_parallel = parallel
        if item_id:
            self._active_review_item_id = str(item_id).strip()
        if review_cycle_id:
            self._active_review_cycle_id = str(review_cycle_id).strip()

        item_label = ""
        if self._active_review_item_id:
            item_label = f" [{self._active_review_item_id}]"

        count_label = None
        if isinstance(agent_count, int) and agent_count > 0:
            noun = "agent" if agent_count == 1 else "agents"
            count_label = f"{agent_count} {noun}"
            # Only show "parallel" when there are multiple agents running
            # concurrently — labeling a single agent as "parallel" is misleading.
            if parallel is True and agent_count > 1:
                count_label = f"{count_label}, parallel"
            elif parallel is False and agent_count > 1:
                count_label = f"{count_label}, series"

        if self.config.verbosity == VerbosityLevel.QUIET:
            detail = f" ({count_label})" if count_label else ""
            self._print(
                f"review — running review agents{item_label}{detail} [attempt {attempt}/{max_attempts}]"
            )
            return

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Render pipeline banner for Review stage with iteration
        if self._pipeline_enabled and self._pipeline.should_render_banner("Review"):
            self._print("")  # Blank line before banner
            self._pipeline.stage_transition(
                "Review",
                iteration=attempt,
                max_iterations=max_attempts,
            )
            self._last_pipeline_stage = "Review"
            if count_label:
                timestamp = self._timestamp()
                self._print(
                    f"{timestamp}review — running review agents{item_label} ({count_label})",
                    style="cyan",
                )
        else:
            # Show iteration update without full banner
            timestamp = self._timestamp()
            detail = f" ({count_label})" if count_label else ""
            self._print(
                f"{timestamp}review — running review agents{item_label}{detail} [attempt {attempt}/{max_attempts}]",
                style="cyan",
            )

        if count_label and self._spinner and self._spinner.is_active:
            self._spinner.update_status_line(
                f"review — running review agents{item_label} ({count_label})",
                style="cyan",
            )

    def review_agent_started(self, agent_name: str) -> None:
        """Emit event when a review agent starts running."""
        with self._lock:
            self._review_agents[agent_name] = "running"

        self.start_spinner()

        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        if self.config.verbosity == VerbosityLevel.PROGRESS:
            self._print(f"  {glyphs.arrow} {agent_name} \u2014 running...", style="dim")
            return

        if self.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._timestamp()
            self._print(f"{timestamp}  {glyphs.arrow} {agent_name} \u2014 running...", style="dim")

    def review_agent_completed(
        self,
        agent_name: str,
        passed: bool,
        details: str | None = None,
        *,
        status: str | None = None,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> None:
        """Emit event when a review agent finishes."""
        if not self._review_context_matches(item_id=item_id, review_cycle_id=review_cycle_id):
            if self.config.verbosity >= VerbosityLevel.DEBUG:
                self._print(
                    "[DEBUG] ProgressEmitter: dropped stale review_agent_completed event",
                    style="dim",
                )
            return
        if item_id:
            self._active_review_item_id = str(item_id).strip()
        if review_cycle_id:
            self._active_review_cycle_id = str(review_cycle_id).strip()
        self.stop_spinner()
        normalized_status = str(status or "").strip().lower()
        if normalized_status == "skipped":
            render_status = "skipped"
            symbol = glyphs.success
            style = "yellow"
        else:
            render_status = "passed" if passed else "failed"
            symbol = glyphs.success if passed else glyphs.failure
            style = "green" if passed else "red"

        with self._lock:
            previous_status = self._review_agents.get(agent_name)
            if previous_status == render_status:
                return
            self._review_agents[agent_name] = render_status
            all_agents_finished = bool(self._review_agents) and all(
                value != "running" for value in self._review_agents.values()
            )

        if all_agents_finished:
            self._restore_spinner_status_line()

        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        if self.config.verbosity == VerbosityLevel.PROGRESS:
            self._print(f"  {symbol} {agent_name} \u2014 {render_status}", style=style)
            return

        if self.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._timestamp()
            message = f"{timestamp}  {symbol} {agent_name} \u2014 {render_status}"
            if details:
                self._print(message, style=style)
                self._print(f"  - {details}", style="dim")
            else:
                self._print(message, style=style)

    def scorecard_available(
        self,
        component_scores: dict[str, int],
        total: int,
        threshold: int,
        item_id: str | None = None,
        *,
        review_cycle_id: str | None = None,
        issue_counts: dict[str, int] | None = None,
        scorecard_source: str | None = None,
        filtered_issue_count: int | None = None,
        review_filter_applied: bool = False,
        status: str | None = None,
        decision_state: str | None = None,
        failed_agents: int | None = None,
        degraded: bool | None = None,
        total_agents: int | None = None,
        skipped_agents: int | None = None,
    ) -> None:
        """Emit event when a scorecard summary is available.

        Args:
            component_scores: Mapping of normalized category scores (0-100)
            total: Total score (0-100)
            threshold: Passing threshold
            item_id: Optional item ID for context (which item was reviewed)
            review_cycle_id: Optional review cycle identifier for stale-event filtering
            issue_counts: Optional mapping of issue counts per agent/category
            scorecard_source: Optional scorecard source marker ("direct", "post_filter")
            filtered_issue_count: Optional count of findings removed by review filtering
            review_filter_applied: Whether review filtering was applied before scoring
            status: Optional server scorecard status (e.g. "failing", "passing")
            decision_state: Optional decision state marker ("determinate", "indeterminate")
            failed_agents: Optional count of agents that errored or timed out
            degraded: Optional flag indicating agent health degradation
            total_agents: Optional total number of agents that ran
        """
        normalized_item = str(item_id).strip() if item_id else ""
        normalized_cycle = str(review_cycle_id).strip() if review_cycle_id else ""
        if self._active_review_cycle_id and not normalized_cycle:
            if self.config.verbosity >= VerbosityLevel.DEBUG:
                self._print(
                    "[DEBUG] ProgressEmitter: dropped scorecard_available without review_cycle_id",
                    style="dim",
                )
            return
        if self._active_review_item_id and not normalized_item:
            if self.config.verbosity >= VerbosityLevel.DEBUG:
                self._print(
                    "[DEBUG] ProgressEmitter: dropped scorecard_available without item_id",
                    style="dim",
                )
            return
        if not self._review_context_matches(item_id=item_id, review_cycle_id=review_cycle_id):
            if self.config.verbosity >= VerbosityLevel.DEBUG:
                self._print(
                    "[DEBUG] ProgressEmitter: dropped stale scorecard_available event",
                    style="dim",
                )
            return
        if normalized_item:
            self._active_review_item_id = normalized_item
        if normalized_cycle:
            self._active_review_cycle_id = normalized_cycle

        passed = total >= threshold
        # S1.T0: Server status field overrides numeric comparison
        if status and str(status).strip().lower() == "failing":
            passed = False
        normalized_decision_state = str(decision_state or "").strip().lower()
        all_agents_skipped = (
            isinstance(skipped_agents, int)
            and isinstance(total_agents, int)
            and skipped_agents == total_agents
            and total_agents > 0
        )
        indeterminate = normalized_decision_state == "indeterminate" or all_agents_skipped
        style = "green" if passed and not indeterminate else "yellow"
        display_status = "pass" if passed and not indeterminate else "fail"
        normalized_source = str(scorecard_source or "").strip().lower()
        is_post_filter = review_filter_applied or normalized_source == "post_filter"
        summary_label = "Adjusted review score" if is_post_filter else "Review score"

        # Format item context for display
        item_context = f" ({normalized_item})" if normalized_item else ""
        filter_suffix = ""
        if is_post_filter and isinstance(filtered_issue_count, int) and filtered_issue_count > 0:
            finding_label = "finding" if filtered_issue_count == 1 else "findings"
            filter_suffix = f" after filtering {filtered_issue_count} {finding_label}"

        # HYBRID-083: Include agent count and skip context when agents were
        # skipped, so users can distinguish fully-reviewed vs partially-reviewed
        agent_suffix = ""
        if isinstance(skipped_agents, int) and skipped_agents > 0 and isinstance(total_agents, int):
            active_count = total_agents - skipped_agents
            agent_label = "agent" if active_count == 1 else "agents"
            agent_suffix = f" ({active_count} {agent_label}, {skipped_agents} skipped)"
        elif isinstance(total_agents, int) and total_agents > 0:
            agent_label = "agent" if total_agents == 1 else "agents"
            agent_suffix = f" ({total_agents} {agent_label})"

        if self.config.verbosity == VerbosityLevel.QUIET:
            if indeterminate:
                self._print(
                    f"Score{item_context}: indeterminate{agent_suffix}",
                    style="yellow",
                )
                return
            self._print(
                f"Score{item_context}: {total}/100 (threshold: {threshold}) - {display_status}",
                style=style,
            )
            return

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # HYBRID-086: When all agents were skipped, show "unreviewed" instead of
        # a numeric score to avoid implying the code was reviewed and clean.
        if all_agents_skipped:
            self._print(
                f"Review status{item_context}: unreviewed — "
                f"{skipped_agents} {'agent' if skipped_agents == 1 else 'agents'} skipped",
                style="yellow",
            )
            return

        if indeterminate:
            reason = "review agent health degraded" if degraded else "review coverage incomplete"
            self._print(
                f"Review status{item_context}: indeterminate ({reason}){agent_suffix}",
                style="yellow",
            )
            return

        self._print(
            f"{summary_label}{item_context}: {total}/100 (pass \u2265 {threshold}){filter_suffix}{agent_suffix}",
            style=style,
        )

        if self.config.verbosity < VerbosityLevel.DETAIL:
            return

        if component_scores:
            max_score = 100
            for category, score in component_scores.items():
                self._print(f"  {glyphs.tree_mid} {category}: {score}/{max_score}", style=style)

        if issue_counts:
            for category, count in issue_counts.items():
                self._print(f"  {glyphs.tree_mid} {category} issues: {count}", style="dim")

        # S1.T1: Agent health summary when any agents errored or skipped
        has_health_issues = (
            degraded
            or (isinstance(failed_agents, int) and failed_agents > 0)
            or (isinstance(skipped_agents, int) and skipped_agents > 0)
        )
        if has_health_issues and isinstance(total_agents, int):
            ok_count = total_agents - (failed_agents or 0) - (skipped_agents or 0)
            parts = [f"{ok_count} ok"]
            if isinstance(failed_agents, int) and failed_agents > 0:
                parts.append(f"{failed_agents} err")
            if isinstance(skipped_agents, int) and skipped_agents > 0:
                parts.append(f"{skipped_agents} skipped")
            self._print(
                f"  {glyphs.tree_last} Agents: [{' / '.join(parts)}]",
                style="yellow",
            )

    def scorecard_warning(self, message: str) -> None:
        """Emit a single-line scorecard warning."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        self._print(f"Scorecard: {message}", style="yellow")

    def session_completed(
        self,
        items_completed: int,
        quality_score: float,
        session_summary: str,
        *,
        was_escalated: bool = False,
    ) -> None:
        """Record session completion for progress tracking.

        Note: Final completion message is now handled by CLI closeout builder
        (FEAT-SESSION-CLOSEOUT-001) to avoid double-printing. This method is
        retained for progress event tracking and internal state updates.

        Args:
            items_completed: Number of items completed in the session
            quality_score: Quality score (0.0-1.0 or 0-100)
            session_summary: Summary of what was accomplished
            was_escalated: If True, session ended via escalation
        """
        # Normalize quality score to 0-100 for internal tracking
        if quality_score <= 1.0:
            quality_score = quality_score * 100

        # Store for potential later use (e.g., summary queries)
        self._last_completion_data = {
            "items_completed": items_completed,
            "quality_score": quality_score,
            "session_summary": session_summary,
            "was_escalated": was_escalated,
        }

        # Note: Completion banner printing removed - CLI closeout builder handles it
        # See obra/display/closeout.py build_closeout_message()

    def increment(self, counter_name: str) -> None:
        """Increment a named telemetry counter.

        Generic counter mechanism for Rule 10 compliance. Used by parallel
        refinement paths to track event counts without requiring per-event
        dedicated methods.

        Args:
            counter_name: Identifier for the counter (e.g. "refinement_parallel_examine").
        """
        self._counters[counter_name] = self._counters.get(counter_name, 0) + 1

    def get_counter(self, counter_name: str) -> int:
        """Return current value of a named telemetry counter."""
        return self._counters.get(counter_name, 0)

    def track_file_created(self) -> None:
        """Increment the file created counter."""
        self._files_created += 1

    def track_file_modified(self) -> None:
        """Increment the file modified counter."""
        self._files_modified += 1

    def get_file_summary(self) -> str:
        """Get a summary of file activity for the current session."""
        if self._files_created == 0 and self._files_modified == 0:
            return ""
        from obra.messages.progress import build_file_summary

        return build_file_summary(self._files_created, self._files_modified)

    def parallel_batch_started(
        self, stage: str, *, workers: int, batches: int, items: int
    ) -> None:
        """Emit a console banner when parallel batch processing begins.

        Args:
            stage: Stage name (e.g. "examine", "revise").
            workers: Number of parallel workers.
            batches: Number of batches dispatched.
            items: Total plan items across all batches.
        """
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        self._print(
            f"  Parallel {stage}: {workers} workers, {batches} batches, {items} items",
            style="cyan",
        )

    def parallel_batch_completed(
        self,
        stage: str,
        *,
        wall_clock_ms: float,
        speedup_ratio: float,
        batches_failed: int,
        batches_total: int,
        batch_statuses: list[str] | None = None,
    ) -> None:
        """Emit a console summary when parallel batch processing completes.

        Args:
            stage: Stage name (e.g. "examine", "revise").
            wall_clock_ms: Total wall-clock time in milliseconds.
            speedup_ratio: Ratio of sequential total to wall clock.
            batches_failed: Number of batches that failed.
            batches_total: Total number of batches.
            batch_statuses: Per-batch outcome codes (e.g. ["success",
                "template_fallback", "success"]). Shown at DETAIL verbosity.
        """
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        secs = wall_clock_ms / 1000
        if batches_failed > 0:
            self._print(
                f"  Parallel {stage} done: {secs:.1f}s, {speedup_ratio:.1f}x speedup, "
                f"{batches_failed}/{batches_total} batches failed",
                style="yellow",
            )
        else:
            self._print(
                f"  Parallel {stage} done: {secs:.1f}s, {speedup_ratio:.1f}x speedup",
                style="green",
            )
        # Show per-batch reason codes at DETAIL verbosity when failures exist.
        if (
            batch_statuses
            and batches_failed > 0
            and self.config.verbosity >= VerbosityLevel.DETAIL
        ):
            codes = ", ".join(
                f"B{i}:{s}" for i, s in enumerate(batch_statuses)
            )
            self._print(f"    Batch outcomes: {codes}", style="dim")

    def parallel_batch_fallback(self, stage: str, *, error: str) -> None:
        """Emit a console warning when parallel processing fails entirely.

        Args:
            stage: Stage name (e.g. "examine", "revise").
            error: Error description.
        """
        self._print(
            f"  Parallel {stage} failed: {error}",
            style="bold red",
        )

    # ------------------------------------------------------------------
    # Refinement scope & review-fix progress (session 76b9473a gap fixes)
    # ------------------------------------------------------------------

    def refinement_scope_summary(
        self,
        cycle: int,
        *,
        scope_items: int,
        total_items: int,
        scope_mode: str,
        blocking_count: int,
        prev_blocking_count: int | None = None,
    ) -> None:
        """Emit a one-line refinement scope summary each examine/revise cycle.

        Args:
            cycle: Current refinement cycle number (1-based).
            scope_items: Items in examination scope this cycle.
            total_items: Total plan items.
            scope_mode: Scope mode (e.g. "strict", "scoped", "full").
            blocking_count: Current blocking issue count.
            prev_blocking_count: Previous cycle's blocking count (for trend).
        """
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        trend = ""
        if prev_blocking_count is not None:
            if blocking_count < prev_blocking_count:
                trend = f" (down from {prev_blocking_count})"
            elif blocking_count > prev_blocking_count:
                trend = f" (up from {prev_blocking_count})"
            else:
                trend = " (unchanged)"
        scope_label = f"{scope_items}/{total_items}" if scope_items < total_items else "full"
        self._print(
            f"  Cycle {cycle}: scope {scope_label} ({scope_mode}), "
            f"blocking {blocking_count}{trend}",
            style="cyan",
        )

    def review_fix_progress(
        self,
        item_id: str,
        *,
        fixes_applied: int = 0,
        fixes_failed: int = 0,
    ) -> None:
        """Emit a one-line fix progress summary per item.

        Called after a FIX action completes to show cumulative fix stats.
        The review-fix loop is server-driven (one action at a time) so
        item_index/total_items are not available client-side.

        Args:
            item_id: Plan item identifier (e.g. "E2.S3.T1").
            fixes_applied: Cumulative fixes applied this session.
            fixes_failed: Cumulative fixes failed this session.
        """
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        self._print(
            f"  Fix {item_id}: {fixes_applied} applied, {fixes_failed} failed",
            style="dim",
        )

    def escalation_summary(
        self,
        *,
        reason: str,
        failing_items: list[str] | None = None,
        fix_attempts: int = 0,
        fix_results: list[dict[str, object]] | None = None,
    ) -> None:
        """Emit a structured escalation summary with fix failure context.

        Args:
            reason: Escalation reason value.
            failing_items: List of item IDs that could not be fixed.
            fix_attempts: Total fix attempts in the session.
            fix_results: List of fix_issue_result dicts with verification details.
        """
        if self.config.verbosity < VerbosityLevel.QUIET:
            return
        self._print("")
        self._print(f"  Escalation: {reason}", style="bold yellow")
        if failing_items:
            self._print(f"  Failing items: {', '.join(failing_items)}", style="yellow")
        if fix_attempts > 0:
            self._print(f"  Fix attempts: {fix_attempts}", style="yellow")
        if fix_results:
            for fr in fix_results[:5]:
                status = fr.get("status", "unknown")
                issue_id = fr.get("issue_id", "?")
                verification_cmd = fr.get("verification_command", "")
                reason_detail = fr.get("reason", "")
                self._print(
                    f"    {issue_id}: {status} — {reason_detail}"
                    + (f" ({verification_cmd})" if verification_cmd else ""),
                    style="dim yellow",
                )

    def render_footer_hint(self, force: bool = False) -> None:
        """Render the session resume footer hint when a session ID is set.

        Rate-limited to avoid cluttering output during rapid phase transitions.
        By default, shows at most once every 30 seconds.

        Args:
            force: If True, bypass rate limiting and always render
        """
        if not self._dashboard_feature_enabled(self._footer_hint_enabled):
            return
        if self._session_id is None:
            return

        # Rate limiting: skip if rendered recently (unless forced)
        if not force and self._last_footer_hint_s is not None:
            now = datetime.now().timestamp()
            elapsed = now - self._last_footer_hint_s
            if elapsed < self._footer_hint_min_interval_s:
                return

        from obra.display.recovery_hints import build_interrupt_recovery_hints

        self._print(glyphs.divider)
        for line in build_interrupt_recovery_hints(self._session_id).splitlines():
            self._print(line, style="dim")

        # Update timestamp for rate limiting
        self._last_footer_hint_s = datetime.now().timestamp()

    def render_task_tracker(self) -> None:
        """Render task tracker summary when enabled."""
        if not self._dashboard_feature_enabled(self._task_tracker_enabled):
            return

        if (
            self._task_tracker_current_id is None
            and not self._task_tracker_items
            and self._total_tasks == 0
        ):
            return

        done_count = len(self._task_tracker_done)
        if (
            self._task_tracker_current_id
            and self._task_tracker_current_id not in self._task_tracker_done
        ):
            # Show ordinal position semantics while a task is actively running.
            done_count += 1
        if self._plan_total_locked and self._task_tracker_items:
            total_count = len(self._task_tracker_items)
        else:
            total_count = self._total_tasks if self._total_tasks > 0 else len(self._task_tracker_items)
        total_label = str(total_count) if total_count > 0 else "?"

        if self._task_tracker_current_id:
            current_title = self._task_tracker_current_title or ""
            if current_title:
                current_label = f"{self._task_tracker_current_id}: {current_title}"
            else:
                current_label = self._task_tracker_current_id
        else:
            current_label = "idle"

        max_next = self._task_tracker_max_next
        next_label = "none"
        if self._task_tracker_items and max_next > 0:
            start_index = 0
            if self._task_tracker_current_id in self._task_tracker_index:
                start_index = self._task_tracker_index[self._task_tracker_current_id] + 1

            upcoming: list[str] = []
            for item in self._task_tracker_items[start_index:]:
                item_id = item.get("id", "")
                if not item_id or item_id == self._task_tracker_current_id:
                    continue
                if item_id in self._task_tracker_done:
                    continue
                title = item.get("title", "")
                if title:
                    upcoming.append(f"{item_id}: {title}")
                else:
                    upcoming.append(item_id)
                if len(upcoming) >= max_next:
                    break
            if upcoming:
                next_label = ", ".join(upcoming)
            else:
                known_count = len(self._task_tracker_items)
                next_label = "unknown" if total_count > known_count else "none"
        elif total_count > 0:
            next_label = "n/a"

        self._print(
            f"Tracker: {done_count}/{total_label} | Current: {current_label} | Next: {next_label}",
            style="dim",
        )

    def _print(self, message: str, style: str | None = None, end: str = "\n") -> None:
        """Print message with or without Rich formatting based on TTY detection.

        When the status spinner is active, routes through print_above().

        Args:
            message: Message to print
            style: Rich style to apply (only if TTY)
            end: String appended after the message (default: newline)
        """
        # Route through spinner if active
        if self._spinner and self._spinner.is_active and end == "\n":
            self._spinner.print_above(message, style=style)
            return

        if self._is_tty:
            # TTY: use Rich formatting with markup and optional style
            self.console.print(message, style=style, end=end)
        else:
            # Plain text output for non-TTY (CI, piped output)
            # Disable markup to avoid printing raw tags
            self.console.print(message, end=end, markup=False)

    def phase_started(self, phase: str, context: dict | None = None) -> None:
        """Emit event when an orchestration phase starts.

        Args:
            phase: Phase name (e.g., "USERPLAN_GENERATION", "DERIVATION", "REFINEMENT", "EXECUTION")
            context: Optional context information about the phase
        """
        normalized_phase = str(phase).upper()
        self._active_phase_name = normalized_phase
        # Level 0 (QUIET): Show minimal phase indicator
        if self.config.verbosity == VerbosityLevel.QUIET:
            from obra.messages.status import build_phase_announcement

            # Map phase names to announcement keys
            phase_map = {
                "USERPLAN_GENERATION": "userplan",
                "DERIVATION": "derivation",
                "REFINEMENT": "refinement",
                "EXECUTION": "execution",
            }
            phase_key = phase_map.get(normalized_phase)
            phase_label = build_phase_announcement(phase_key) if phase_key else phase
            self._print(f"{phase_label}...", end="")
            return

        # Level 1+ (PROGRESS and above): Show pipeline banner
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Map phase to pipeline stage and render banner
        pipeline_stage = self._pipeline.get_pipeline_stage_from_phase(normalized_phase)
        if pipeline_stage and self._pipeline_enabled:
            # Only render banner if transitioning to a new stage
            if self._pipeline.should_render_banner(pipeline_stage):
                self._print("")  # Blank line before banner
                self._pipeline.stage_transition(pipeline_stage)
                self._last_pipeline_stage = pipeline_stage
        elif normalized_phase not in {"DERIVATION", "STORY0"}:
            # Fallback for unmapped phases (backward compatibility).
            # DERIVATION and STORY0 are intentionally unmapped — they have
            # dedicated handlers (planning_stage_started, story0_started).
            timestamp = self._timestamp()
            self._print(f"{timestamp}Phase: {phase}", style="bold cyan")

        if self.config.verbosity >= VerbosityLevel.DEBUG and context:
            # Truncate verbose context output
            ctx_str = str(context)
            max_chars = 300
            display_ctx = ctx_str if len(ctx_str) <= max_chars else ctx_str[:max_chars] + "..."
            self._print(f"[DEBUG] Context: {display_ctx}", style="dim")

        if normalized_phase in {"USERPLAN_GENERATION", "REVIEW", "EXECUTION", "DERIVATION", "REFINEMENT"}:
            self.start_spinner()
            if self._spinner and self._spinner.is_active:
                status_line = self._get_phase_status_line(normalized_phase)
                if status_line:
                    self._spinner.update_status_line(status_line, style="cyan")

        if normalized_phase == "EXECUTION":
            self._active_review_item_id = None
            self._active_review_cycle_id = None
            # Note: Footer hint removed from here - it was too noisy (showed 17+ times per session)
            # Footer hint now shows only: once at set_session_id(), and in completion footer
            self.render_task_tracker()

    def phase_completed(self, phase: str, result: dict | None = None, duration_ms: int = 0) -> None:
        """Emit event when an orchestration phase completes.

        Args:
            phase: Phase name that completed
            result: Optional result data from the phase
            duration_ms: Phase duration in milliseconds
        """
        # Update pipeline stage completion state
        normalized_phase = str(phase).upper()
        if self._active_phase_name == normalized_phase:
            self._active_phase_name = None
        if self._pipeline_enabled:
            pipeline_stage = self._pipeline.get_pipeline_stage_from_phase(normalized_phase)
            if pipeline_stage:
                self._pipeline.mark_stage_complete(pipeline_stage)

        if normalized_phase in {"USERPLAN_GENERATION", "REVIEW", "EXECUTION", "DERIVATION", "REFINEMENT"}:
            self.stop_spinner()
            self._restore_spinner_status_line()

        # Level 0 (QUIET): Complete the line with result count
        if self.config.verbosity == VerbosityLevel.QUIET:
            if phase == "USERPLAN_GENERATION":
                # S1.T7: Two-step generation feedback for UserPlan
                title = (result or {}).get("title", "UserPlan")
                self._print(" done")
                self._print(f"Generated UserPlan: {title}")
            elif phase == "DERIVATION":
                # S1.T7: Two-step generation feedback for derivation
                task_count = (result or {}).get("item_count", 0)
                self._print(" done")
                self._print(f"Derived execution plan with {task_count} tasks")
            elif result and "item_count" in result:
                item_count = result["item_count"]
                self._print(f" done ({item_count} items)")
            elif result and "issue_count" in result:
                issue_count = result["issue_count"]
                self._print(f" done ({issue_count} issues)")
            else:
                self._print(" done")
            return

        # Level 1+ (PROGRESS and above): Show with timestamp and duration
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        duration_sec = duration_ms / 1000.0

        # Refinement terminal summary
        if normalized_phase == "REFINEMENT" and isinstance(result, dict):
            cycles = result.get("refinement_cycles", 0)
            ref_duration = result.get("refinement_duration_s", 0.0)
            if cycles > 0:
                plan_summary = ""
                if self._last_plan_summary:
                    epic_c = self._last_plan_summary.get("epic", 0)
                    story_c = self._last_plan_summary.get("story", 0)
                    task_c = self._last_plan_summary.get("task", 0)
                    plan_summary = f"\n{timestamp}  Final plan: {epic_c} Epics, {story_c} Stories, {task_c} Tasks"
                self._print(
                    f"{timestamp}{glyphs.success} Plan refinement complete ({cycles} cycles, {ref_duration:.0f}s){plan_summary}",
                    style="green",
                )
                # Render final tree only when snapshot source is authoritative.
                if (
                    self._plan_tree_rendered_once
                    and self._plan_items
                    and self._plan_mode != "provisional"
                ):
                    self.render_plan_tree(
                        reason="Execution plan finalized",
                        source="authoritative",
                        force=True,
                    )
                return

        # Build completion message with item count if available
        if phase == "USERPLAN_GENERATION":
            # S1.T7: Two-step generation feedback for UserPlan (PROGRESS+ level)
            title = (result or {}).get("title", "UserPlan")
            message = f"{timestamp}Generated UserPlan: {title} ({duration_sec:.1f}s)"
            self._print(message, style="green")
        elif result and "item_count" in result:
            item_count = result["item_count"]
            message = f"{timestamp}"
            if phase == "DERIVATION":
                # S1.T7: Two-step generation feedback for derivation (PROGRESS+ level)
                message += f"Derived execution plan with {item_count} tasks ({duration_sec:.1f}s)"
            elif phase == "REFINEMENT":
                issues = result.get("issue_count", 0)
                message += f"Found {issues} issues ({duration_sec:.1f}s)"
            else:
                message += f"Phase {phase} complete ({duration_sec:.1f}s)"
            self._print(message, style="green")

            # At PROGRESS level, show item list if available
            if self.config.verbosity == VerbosityLevel.PROGRESS and "items" in result:
                for item in result["items"]:
                    item_id = item.get("id", "?")
                    item_title = item.get("title", "untitled")
                    self._print(f"           {item_id}: {item_title}")
        else:
            self._print(
                f"{timestamp}Phase {phase} complete ({duration_sec:.1f}s)",
                style="green",
            )

        if self.config.verbosity >= VerbosityLevel.DETAIL and result:
            # Show result summary at detail level
            if "items" in result and self.config.verbosity > VerbosityLevel.PROGRESS:
                # Show detailed plan items with descriptions and dependencies
                for item in result["items"]:
                    item_id = item.get("id", "?")
                    item_title = item.get("title", "untitled")
                    depends_on = item.get("depends_on", [])

                    # Show item with dependency info
                    if depends_on:
                        deps_str = ", ".join(depends_on)
                        self._print(f"  {item_id}: {item_title} (depends: {deps_str})")
                    else:
                        self._print(f"  {item_id}: {item_title}")

                    # Show description or acceptance criteria if available
                    description = item.get("description", "")
                    acceptance_criteria = item.get("acceptance_criteria", [])

                    if description:
                        # Multi-line description - show indented
                        for line in description.split("\n"):
                            if line.strip():
                                self._print(f"      - {line.strip()}", style="dim")
                    elif acceptance_criteria:
                        # Show acceptance criteria as bullet points
                        for criterion in acceptance_criteria:
                            self._print(f"      - {criterion}", style="dim")

        if self.config.verbosity >= VerbosityLevel.DEBUG and result:
            # Truncate verbose result output
            result_str = str(result)
            max_chars = 500
            display_result = (
                result_str if len(result_str) <= max_chars else result_str[:max_chars] + "..."
            )
            self._print(
                f"[DEBUG] Full result ({len(result_str)} chars): {display_result}",
                style="dim",
            )

    def stage_started(self, stage: str, context: dict | None = None) -> None:
        """Emit event when a pipeline stage starts."""
        base_stage = stage.split("_pass_")[0]
        if base_stage in {"intent_generation", "assumptions", "analogues", "brief", "derive", "revise"}:
            self.set_llm_state("waiting")
        self._active_stage_name = stage
        self._start_stage_spinner(stage)
        if self._spinner and self._spinner.is_active:
            status_line = self._get_stage_status_line(stage)
            if status_line:
                self._spinner.update_status_line(status_line, style="cyan")
        self._current_stage_context = context
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}Stage: {stage}", style="bold cyan")
        if self.config.verbosity >= VerbosityLevel.DEBUG and context:
            # Truncate verbose context output
            ctx_str = str(context)
            max_chars = 300
            display_ctx = ctx_str if len(ctx_str) <= max_chars else ctx_str[:max_chars] + "..."
            self._print(f"[DEBUG] Stage context: {display_ctx}", style="dim")

        # Show objective at derive start (DETAIL verbosity)
        if stage == "derive" and context and self.config.verbosity >= VerbosityLevel.DETAIL:
            objective = context.get("objective", "")
            if objective:
                display_obj = self._truncate_description(objective)
                self._print(f'  Deriving: "{display_obj}"', style="cyan")

    def stage_completed(self, stage: str, result: dict | None = None, duration_ms: int = 0) -> None:
        """Emit event when a pipeline stage completes."""
        if self._active_stage_name == stage:
            self._active_stage_name = None
        if self._spinner:
            self._spinner.clear_status_line()
        self.set_llm_state("idle")
        self._stop_stage_spinner(stage)
        self._restore_spinner_status_line()
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        timestamp = self._timestamp()
        duration_sec = duration_ms / 1000.0
        message = f"{timestamp}Stage {stage} complete ({duration_sec:.1f}s)"
        self._print(message, style="green")

        # Show hierarchy summary for derive stage completion (DETAIL only)
        if stage == "derive" and result:
            epic_count = result.get("epic_count", 0)
            story_count = result.get("story_count", 0)
            task_count = result.get("task_count", 0)
            if epic_count or story_count or task_count:
                epic_str = f"{epic_count} Epic" + ("s" if epic_count != 1 else "")
                story_str = f"{story_count} Stor" + ("ies" if story_count != 1 else "y")
                task_str = f"{task_count} Task" + ("s" if task_count != 1 else "")
                self._print(
                    f"  {glyphs.tree_last} Derived: {epic_str}, {story_str}, {task_str}",
                    style="green",
                )

        if self.config.verbosity >= VerbosityLevel.DEBUG and result:
            # Truncate verbose result output
            result_str = str(result)
            max_chars = 300
            display_result = (
                result_str if len(result_str) <= max_chars else result_str[:max_chars] + "..."
            )
            self._print(f"[DEBUG] Stage result: {display_result}", style="dim")
        self._current_stage_context = None

    def planning_started(self, objective: str) -> None:
        """Emit event when planning begins."""
        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print("Planning...", end="")
            return
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        display_obj = objective.strip()
        if display_obj:
            display_obj = self._truncate_description(display_obj)
            self._print(f'{timestamp}Planning "{display_obj}"...', style="bold cyan")
        else:
            self._print(f"{timestamp}Planning...", style="bold cyan")

    def planning_stage_started(self, stage: str, user_label: str) -> None:
        """Emit event when a planning stage starts (user-facing).

        Also updates pipeline state to track the active substage.
        """
        # Update pipeline substage state
        if self._pipeline_enabled:
            pipeline_stage = self._pipeline.get_pipeline_stage(stage)
            if pipeline_stage:
                # Check if we need to render banner for this stage
                # (first substage of a new pipeline stage)
                if self._pipeline.should_render_banner(pipeline_stage):
                    if self.config.verbosity >= VerbosityLevel.PROGRESS:
                        self._print("")  # Blank line before banner
                        self._pipeline.stage_transition(pipeline_stage, substage=stage)
                        self._last_pipeline_stage = pipeline_stage
                else:
                    # Subsequent substage within same pipeline stage - update and re-render
                    self._pipeline.substage_started(stage)
                    if self.config.verbosity >= VerbosityLevel.PROGRESS:
                        self._print("")
                        self._pipeline.render_banner(pipeline_stage, active_substage=stage)

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Show inline progress with arrow indicator
        timestamp = self._timestamp()
        label = user_label.strip() if user_label else self._get_stage_label(stage)
        self._print(f"{timestamp}  {glyphs.arrow} {label}...", style="cyan")

    def planning_stage_completed(
        self,
        stage: str,
        user_label: str,
        duration_s: float,
        summary: str | None = None,
    ) -> None:
        """Emit event when a planning stage completes (user-facing).

        Also updates pipeline state to mark the substage as completed.
        """
        # Update pipeline substage state
        if self._pipeline_enabled:
            self._pipeline.substage_completed(stage)

        if self.config.verbosity == VerbosityLevel.QUIET:
            if stage == "review":
                summary_line = ""
                if self._last_plan_summary:
                    epic_count = self._last_plan_summary.get("epic", 0)
                    story_count = self._last_plan_summary.get("story", 0)
                    task_count = self._last_plan_summary.get("task", 0)
                    summary_line = (
                        f" ({epic_count} epics, {story_count} stories, {task_count} tasks)"
                    )
                self._print(f" done{summary_line}")
            return
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        label = user_label.strip() if user_label else self._get_stage_label(stage)
        completion = summary or f"{label} complete"
        # Show inline completion with checkmark (indented to align with started message)
        self._print(
            f"{timestamp}  {glyphs.success} {completion} ({duration_s:.1f}s)",
            style="green",
        )

    def story0_started(self) -> None:
        """Emit event when Story 0 environment preparation starts."""
        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print("Preflight...", end="")
            return
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Render Setup pipeline banner if phase_started() hasn't already rendered it.
        # Since STORY0 is now mapped in PHASE_TO_PIPELINE, phase_started() renders the
        # banner before story0_started() is called — should_render_banner guards the duplicate.
        if self._pipeline_enabled and self._pipeline.should_render_banner("Setup"):
            self._print("")
            self._pipeline.stage_transition("Setup")

        timestamp = self._timestamp()
        self._print(f"{timestamp}Preflight: Environment & Dependencies", style="bold cyan")

    def story0_prerequisite_status(
        self,
        category: str,
        name: str,
        status: str,
        reason: str | None = None,
    ) -> None:
        """Emit progress for a Story 0 prerequisite."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        symbol_map = {
            "installed": (glyphs.success, "green"),
            "mocked": (glyphs.success, "green"),
            "skipped": (glyphs.success, "green"),
            "failed": (glyphs.failure, "red"),
            "user_input_needed": (glyphs.warning, "yellow"),
        }
        symbol, color = symbol_map.get(status, ("•", "dim"))
        timestamp = self._timestamp()
        display = f"{category}: {name}".strip()
        if status == "failed" and reason:
            display = f"{name}: {reason}"
        self._print(f"{timestamp}  {symbol} {display}", style=color)

    def story0_message(self, message: str) -> None:
        """Emit a Story 0 informational message."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        for line in str(message).splitlines():
            self._print(f"{timestamp}  • {line}", style="dim")

    def verification_preflight_started(self, message: str) -> None:
        """Emit verification preflight start message."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}  • {message}", style="dim")

    def verification_preflight_installing(self, message: str) -> None:
        """Emit verification preflight install message."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}  • {message}", style="dim")

    def verification_preflight_completed(self, message: str) -> None:
        """Emit verification preflight completion message."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}  {glyphs.success} {message}", style="green")

    def code_verify_started(self, item_id: str | None = None) -> None:
        """Emit start message for CodeVerify stage."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        item_suffix = f" ({item_id})" if item_id else ""
        self._print(f"{timestamp}Code verify{item_suffix}: running checks", style="cyan")

    def code_verify_completed(
        self,
        *,
        status: str,
        tools_used: list[str] | None = None,
        pass_count: int = 0,
        fail_count: int = 0,
        inconclusive_count: int = 0,
        item_id: str | None = None,
    ) -> None:
        """Emit completion summary for CodeVerify stage."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        normalized_status = str(status or "inconclusive").strip().lower()
        if normalized_status not in {"passed", "failed", "inconclusive"}:
            normalized_status = "inconclusive"

        if normalized_status == "passed":
            style = "green"
        elif normalized_status == "failed":
            style = "red"
        else:
            style = "yellow"

        tools = [str(tool).strip() for tool in (tools_used or []) if str(tool).strip()]
        if tools:
            tools_text = ", ".join(tools)
        else:
            tools_text = "none"

        timestamp = self._timestamp()
        item_suffix = f" ({item_id})" if item_id else ""
        self._print(
            (
                f"{timestamp}Code verify{item_suffix}: {normalized_status} "
                f"(pass={int(pass_count)}, fail={int(fail_count)}, "
                f"inconclusive={int(inconclusive_count)}; tools={tools_text})"
            ),
            style=style,
        )

    def story0_completed(self, blocking_failures: int, non_blocking_warnings: int) -> None:
        """Emit Story 0 completion summary."""
        # Pipeline state management runs regardless of verbosity (same pattern as phase_completed)
        if self._pipeline_enabled:
            self._pipeline.mark_stage_complete("setup")

        if self.config.verbosity == VerbosityLevel.QUIET:
            if blocking_failures:
                self._print(" blocked")
            else:
                self._print(" ready")
            return
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        if blocking_failures:
            self._print(
                f"{timestamp}  {glyphs.failure} Preflight blocked ({blocking_failures} failures)",
                style="red",
            )
            return
        warning_note = f" ({non_blocking_warnings} warnings)" if non_blocking_warnings else ""
        self._print(
            f"{timestamp}  {glyphs.success} Preflight complete{warning_note}",
            style="green",
        )

    def story0_blocked(self, failures_summary: str) -> None:
        """Emit aggregated Story 0 failure summary (non-TTY)."""
        if not failures_summary:
            return
        self._print(failures_summary)

    def epic_derivation_heartbeat(
        self,
        epic_index: int,
        epic_count: int,
        epic_title: str,
        items_so_far: int,
        elapsed_s: int,
    ) -> None:
        """Emit heartbeat during long per-epic derivation."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        title = self._truncate_title(epic_title)
        elapsed_str = self._format_elapsed(elapsed_s)
        detail = (
            f"{items_so_far} items, {elapsed_str}" if items_so_far > 0 else elapsed_str
        )
        message = f"Epic {epic_index}/{epic_count}: {title} deriving... ({detail})"

        if self._should_inline_heartbeat():
            # Stage heartbeat already refreshes inline status every second.
            # Suppress per-epic heartbeat prints to avoid log spam in TTY mode.
            return

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} ({detail})...",
            style="cyan",
        )

    def debug_tokens(
        self,
        total: int,
        input_tokens: int,
        output_tokens: int,
        source: str | None = None,
    ) -> None:
        """Emit token usage details at DETAIL verbosity."""
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        source_label = f" [{source}]" if source else ""
        self._print(
            f"Tokens: {total:,} (in: {input_tokens:,}, out: {output_tokens:,}){source_label}",
            style="dim",
        )

    def debug_quality(self, message: str) -> None:
        """Emit quality gate details at DETAIL verbosity."""
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        self._print(message, style="dim")

    def stage_failed(
        self,
        stage: str,
        error: str,
        duration_ms: int = 0,
        timeout_s: int | None = None,
    ) -> None:
        """Emit event when a pipeline stage fails."""
        if self._active_stage_name == stage:
            self._active_stage_name = None
        if self._spinner:
            self._spinner.clear_status_line()
        self.set_llm_state("idle")
        self._stop_stage_spinner(stage)
        self._restore_spinner_status_line()
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        duration_sec = duration_ms / 1000.0
        timeout_note = f" timeout={timeout_s}s" if timeout_s else ""
        self._print(
            f"{timestamp}Stage {stage} failed ({duration_sec:.1f}s){timeout_note}: {error}",
            style="bold red",
        )

    def stage_heartbeat(self, stage: str, elapsed_s: int) -> None:
        """Emit heartbeat during long-running stage execution.

        For derive stage, shows current derivation progress in the spinner
        (e.g., "derive running... (2m 30s) [S1 tasks...]").
        """
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        display_elapsed_s = elapsed_s
        if stage == "derive" and self._derive_step_start_time is not None:
            # Prefer step-local elapsed time so timer resets at each derive substep.
            display_elapsed_s = max(0, int(time.perf_counter() - self._derive_step_start_time))

        elapsed_str = self._format_elapsed(display_elapsed_s)
        timestamp = self._timestamp()
        base_stage = stage.split("_pass_")[0]

        # Build status indicator based on current LLM activity
        status_indicator = ""
        if self._llm_state == "waiting":
            status_indicator = " [waiting for LLM]"
        elif self._llm_state == "streaming":
            status_indicator = " [LLM streaming...]"
        elif self._llm_state == "processing":
            status_indicator = " [processing]"

        message = f"{stage} running... ({elapsed_str})"
        if stage == "derive":
            if self._derive_current_step_name == "serialize":
                message = f"Serializing plan... ({elapsed_str})"
            elif self._derive_current_step_name == "tasks":
                message = f"Detailing plan... ({elapsed_str})"
            elif self._derive_current_step_name == "structure":
                message = f"Structuring plan... ({elapsed_str})"
            else:
                message = f"Detailing plan... ({elapsed_str})"
        elif stage == "revise":
            message = f"Refining plan... ({elapsed_str})"
        else:
            label = _STAGE_USER_LABELS.get(base_stage)
            if label:
                message = f"{label}... ({elapsed_str})"

        if self._current_stage_context and self._current_stage_context.get("epic_index"):
            epic_index = self._current_stage_context.get("epic_index")
            epic_count = self._current_stage_context.get("epic_count")
            epic_title = self._current_stage_context.get("epic_title")
            if epic_index and epic_count:
                title = epic_title or "Epic"
                title = self._truncate_title(title)
                message = f"Epic {epic_index}/{epic_count}: {title} deriving... ({elapsed_str})"

        if self._should_inline_heartbeat():
            if self._spinner:
                inline_message = f"{message}{status_indicator}"
                self._spinner.update_status_line(inline_message, style="cyan")
            return

        emit_interval_s = (
            self._stage_heartbeat_tty_emit_interval_s
            if self._is_tty
            else self._stage_heartbeat_emit_interval_s
        )
        now = datetime.now().timestamp()
        last_emit = self._stage_heartbeat_last_emit.get(stage, 0.0)
        if (now - last_emit) < emit_interval_s:
            return
        self._stage_heartbeat_last_emit[stage] = now
        if status_indicator and self._is_tty:
            status_indicator = f"[dim]{status_indicator}[/dim]"
        if status_indicator:
            message = f"{message}{status_indicator}"
        self._print(f"{timestamp}{message}", style="cyan")

    def story_review_started(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        task_count: int,
    ) -> None:
        """Emit event when reviewing a story starts."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        title = self._truncate_title(story_title)
        self._print(
            f"{timestamp} Reviewing story {story_index}/{total_stories}: {title} ({task_count} tasks)...",
            style="cyan",
        )

    def story_review_completed(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        changes_required: bool,
        issue_count: int,
        duration_s: float,
    ) -> None:
        """Emit event when a story review completes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        title = self._truncate_title(story_title)
        if changes_required:
            status = f"[yellow]{issue_count} issue(s)[/yellow]"
        else:
            status = "[green]OK[/green]"
        self._print(
            self._format_status_line(
                status,
                f"Story {story_index}/{total_stories}: {title} ({duration_s:.1f}s)",
            )
        )

    def intent_alignment_started(self, epic_count: int, story_count: int) -> None:
        """Emit event when intent alignment starts."""
        self.start_spinner()
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Checking intent coverage ({epic_count} epic(s), {story_count} story/stories)...",
            style="cyan",
        )

    def intent_story_batch_started(self, story_count: int, max_concurrent: int) -> None:
        """Emit event when parallel story intent checks start."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}  → Checking {story_count} stories (parallel, {max_concurrent} workers)...",
            style="dim",
        )

    def intent_story_assessed(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        status: str,
        note: str,
    ) -> None:
        """Emit event for per-story intent assessment."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        title = self._truncate_title(story_title)
        if status == "ok":
            status_str = "[green]OK[/green]"
        elif status == "scope_creep":
            status_str = "[red]SCOPE CREEP[/red]"
        else:
            status_str = f"[yellow]{status.upper()}[/yellow]"
        msg = self._format_status_line(status_str, f"Story {story_index}/{total_stories}: {title}")
        if note and status != "ok":
            note_text = self._truncate_note(note)
            msg += f" - {note_text}"
        self._print(msg)

    def story_review_batch_started(self, story_count: int, max_concurrent: int) -> None:
        """Emit event when parallel story review starts."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}  → Reviewing {story_count} stories (parallel, {max_concurrent} workers)...",
            style="dim",
        )

    def intent_story_added(self, title: str, parent_id: str | None) -> None:
        """Emit event when intent alignment adds a story."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        title_text = self._truncate_note(title)  # Uses note limit for story additions
        self._print(f"{timestamp}  [green]+[/green] Adding story: {title_text}")

    def intent_alignment_completed(
        self,
        coverage_status: str,
        changes_required: bool,
        missing_count: int,
        scope_creep_count: int,
        stories_added: int,
        stories_removed: int,
        duration_s: float,
    ) -> None:
        """Emit event when intent alignment completes."""
        self.stop_spinner()
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if coverage_status == "pass" or (not changes_required and missing_count == 0):
            status = "[green]OK[/green]"
            detail = ""
        elif coverage_status == "warn":
            status = "[yellow]WARN[/yellow]"
            issues = []
            if missing_count > 0:
                issues.append(f"{missing_count} gap(s)")
            if scope_creep_count > 0:
                issues.append(f"{scope_creep_count} scope creep")
            detail = f" ({', '.join(issues)})" if issues else ""
        else:
            status = "[red]FAIL[/red]"
            issues = []
            if missing_count > 0:
                issues.append(f"{missing_count} gap(s)")
            if scope_creep_count > 0:
                issues.append(f"{scope_creep_count} scope creep")
            detail = f" ({', '.join(issues)})" if issues else ""

        # Show fixes if any were applied
        fixes = []
        if stories_added > 0:
            fixes.append(f"+{stories_added} story/stories")
        if stories_removed > 0:
            fixes.append(f"-{stories_removed} story/stories")
        fix_detail = f" [cyan][{', '.join(fixes)}][/cyan]" if fixes else ""

        self._print(
            self._format_status_line(
                status,
                f"Intent alignment:{detail}{fix_detail} ({duration_s:.1f}s)",
            )
        )

    def intent_alignment_fixes_applied(
        self, stories_added: list[str], stories_removed: list[str]
    ) -> None:
        """Emit event when intent alignment applies fixes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        if stories_added:
            for title in stories_added:
                self._print(f"{timestamp}  [green]+[/green] Added story: {title}")
        if stories_removed:
            for story_id in stories_removed:
                self._print(f"{timestamp}  [red]-[/red] Removed story: {story_id}")

    def intent_gap_detection_started(self, story_count: int) -> None:
        """Emit event when gap detection starts."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Checking for missing requirements ({story_count} stories)...",
            style="cyan",
        )

    def intent_gap_detection_completed(
        self,
        gaps_found: bool,
        missing_count: int,
        stories_to_add: int,
        duration_s: float,
    ) -> None:
        """Emit event when gap detection completes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if gaps_found:
            status = "[yellow]GAPS FOUND[/yellow]"
            detail = f" ({missing_count} missing)"
        else:
            status = "[green]OK[/green]"
            detail = ""
        fix_detail = (
            f" [cyan][+{stories_to_add} story/stories][/cyan]" if stories_to_add > 0 else ""
        )
        self._print(
            self._format_status_line(
                status,
                f"Gap detection:{detail}{fix_detail} ({duration_s:.1f}s)",
            )
        )

    def review_issues_found(self, story_id: str, story_title: str, issues: list[str]) -> None:
        """Emit event when review finds issues in a story."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        # Note: story_title truncation removed - was dead code (result unused)
        for issue in issues[:3]:  # Show up to 3 issues
            issue_text = self._truncate_description(issue)
            self._print(f"{timestamp}    [dim]- {issue_text}[/dim]")

    def review_no_fixes(self, item_id: str | None = None) -> None:
        """Emit event when review finds no issues (no fixes required)."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        item_label = (
            f" for {item_id}" if item_id and self.config.verbosity >= VerbosityLevel.DETAIL else ""
        )
        self._print(f"{timestamp}No fix required{item_label} (0 findings)", style="green")

    def fix_started(self, issue_count: int) -> None:
        """Emit event when fix pass starts."""
        self.start_spinner()

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Render pipeline banner for Fix stage
        if self._pipeline_enabled and self._pipeline.should_render_banner("Fix"):
            self._print("")  # Blank line before banner
            self._pipeline.stage_transition("Fix")
            self._last_pipeline_stage = "Fix"

        timestamp = self._timestamp()
        self._print(f"{timestamp}Fix started: {issue_count} issue(s)", style="cyan")

    def fix_completed(self, fixed: int, failed: int, skipped: int) -> None:
        """Emit event when fix pass completes."""
        self.stop_spinner()

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Fix completed: {fixed} fixed, {failed} failed, {skipped} skipped",
            style="green",
        )
        # Clarify that review will re-evaluate code quality (independent of fix success/failure)
        if self.config.verbosity >= VerbosityLevel.PROGRESS:
            self._print("Re-reviewing current code quality...", style="dim")

    def derivation_step_started(self, step: int, step_name: str) -> None:
        """Emit event when a unified derivation step starts (3-step pipeline).

        Updates step tracking state and prints progress at PROGRESS verbosity.

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
        """
        import time

        self.start_spinner()

        # Update tracking state
        self._derive_current_step = step
        self._derive_current_step_name = step_name
        self._derive_step_start_time = time.perf_counter()
        self._derive_last_output_time = time.perf_counter()
        if step_name == "tasks" and not self._plan_mode:
            self._plan_mode = "one-shot"

        # Update pipeline renderer for derive substep tracking
        if self._pipeline_enabled:
            self._pipeline.derive_step_started(step)

        # Emit at PROGRESS verbosity with user-friendly descriptions
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Map step names to user-friendly descriptions
        step_descriptions = {
            "structure": "identifying epics",
            "tasks": "expanding stories/tasks",
            "serialize": "serializing to JSON",
        }
        description = step_descriptions.get(step_name, step_name)

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Derivation step {step}/3: {description}...",
            style="cyan",
        )

    def epic_derivation_started(
        self,
        epic_index: int,
        epic_count: int,
        epic_id: str,
        epic_title: str,
    ) -> None:
        """Emit event when per-epic derivation starts."""
        self._current_stage_context = {
            "epic_index": epic_index,
            "epic_count": epic_count,
            "epic_title": epic_title,
        }
        self._plan_mode = "per-epic"
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        title = self._truncate_title(epic_title)
        self._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} (deriving...)",
            style="cyan",
        )

    def epic_derivation_completed(
        self,
        epic_index: int,
        epic_count: int,
        epic_id: str,
        epic_title: str | None,
        stories_derived: int,
        tasks_derived: int,
    ) -> None:
        """Emit event when per-epic derivation completes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        title = epic_title or epic_id
        title = self._truncate_title(title)
        self._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} {glyphs.arrow} {stories_derived} stories, {tasks_derived} tasks",
            style="green",
        )
        self._current_stage_context = None

    def epic_serialization_batch_started(
        self,
        epic_count: int,
        max_concurrent: int,
    ) -> None:
        """Emit event when parallel epic serialization batch starts."""
        self._current_stage_context = {
            "serialize_batch": True,
            "epic_count": epic_count,
            "max_concurrent": max_concurrent,
        }
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}  → {epic_count} epics (parallel, {max_concurrent} workers)...",
            style="dim",
        )

    def epic_serialization_completed(
        self,
        epic_index: int,
        epic_count: int,
        epic_id: str,
        epic_title: str,
        items_serialized: int,
    ) -> None:
        """Emit event when per-epic serialization completes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            self._current_stage_context = None
            return
        timestamp = self._timestamp()
        title = self._truncate_title(epic_title)
        self._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} {glyphs.arrow} {items_serialized} items",
            style="green",
        )
        self._current_stage_context = None

    def derivation_step_completed(
        self,
        step: int,
        step_name: str,
        duration_ms: int,
        items_produced: int,
        prose: str | None = None,
        raw_json: str | None = None,
    ) -> None:
        """Emit event when a unified derivation step completes.

        Clears step state and emits counts at DETAIL verbosity.

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
            duration_ms: Step duration in milliseconds
            items_produced: Number of items produced by this step
            prose: Optional prose output (for steps 1 and 2) to show at DEBUG
            raw_json: Optional raw JSON (for step 3) to show at DEBUG
        """
        self.stop_spinner()

        # Clear step state
        self.reset_derive_step_state()

        # Update pipeline renderer for derive substep tracking
        if self._pipeline_enabled:
            self._pipeline.derive_step_completed(step)

        # Emit user-facing summary at PROGRESS (only for structure step)
        if self.config.verbosity >= VerbosityLevel.PROGRESS and step_name == "structure":
            timestamp = self._timestamp()
            self._print(
                f"{timestamp}{glyphs.success} Structure: {items_produced} Epics identified",
                style="green",
            )

        if self.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._timestamp()
            self._print(
                f"{timestamp}  {glyphs.tree_last} {step_name} {glyphs.arrow} {items_produced} items",
                style="dim",
            )

        # At DEBUG verbosity (>= 3), log full prose or raw JSON
        if self.config.verbosity >= VerbosityLevel.DEBUG:
            if prose:
                self._print(f"[DEBUG] Step {step} prose output:", style="dim")
                # Truncate if too long
                max_chars = 1000
                display_prose = prose if len(prose) <= max_chars else prose[:max_chars] + "..."
                self._print(display_prose, style="dim")
            elif raw_json:
                self._print(f"[DEBUG] Step {step} raw JSON:", style="dim")
                # Truncate if too long
                max_chars = 1000
                display_json = (
                    raw_json if len(raw_json) <= max_chars else raw_json[:max_chars] + "..."
                )
                self._print(display_json, style="dim")

    def derivation_step_failed(
        self, step: int, step_name: str, error: str, duration_ms: int
    ) -> None:
        """Emit event when a unified derivation step fails.

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
            error: Error message
            duration_ms: Step duration in milliseconds
        """
        # Clear step state
        self.reset_derive_step_state()

        # Emit at PROGRESS verbosity
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        duration_sec = duration_ms / 1000.0
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}[derive] Step {step}/3 ({step_name}) failed after {duration_sec:.1f}s: {error}",
            style="red",
        )

    def derivation_stall_warning(self, step: int, step_name: str, no_output_seconds: int) -> None:
        """Emit warning when derivation step appears stalled (no output for threshold).

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
            no_output_seconds: Number of seconds without output
        """
        # Emit at PROGRESS verbosity
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}[derive] Step {step}/3 ({step_name}) appears stalled "
            f"(no output for {no_output_seconds}s)...",
            style="yellow",
        )

    def derivation_streaming_heartbeat(self, step: int, elapsed_seconds: int) -> None:
        """Update spinner during long derivation step with streaming output.

        Args:
            step: Step number (1, 2, or 3)
            elapsed_seconds: Elapsed seconds since step start
        """
        # Only update spinner at PROGRESS verbosity
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # StatusSpinner animates independently; no manual heartbeat updates needed.
        return

    def derivation_validation_started(self, pass_num: int, max_passes: int) -> None:
        """Emit event when plan validation/refinement starts.

        Args:
            pass_num: Current validation pass number (1-indexed)
            max_passes: Maximum number of validation passes
        """
        # Emit at PROGRESS verbosity
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}[derive] Validating plan... (pass {pass_num}/{max_passes})",
            style="cyan",
        )

    def derivation_validation_completed(self, pass_num: int, violations: int, passed: bool) -> None:
        """Emit event when plan validation/refinement completes.

        Args:
            pass_num: Current validation pass number (1-indexed)
            violations: Number of validation violations found
            passed: Whether validation passed (no violations)
        """
        # Emit at PROGRESS verbosity (>= 1) - surface validation progress at -v
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        if passed:
            self._print(
                self._format_status_line(
                    f"[green]{glyphs.success}[/green]",
                    f"Validation passed (pass {pass_num})",
                ),
                style=None,
            )
        else:
            self._print(
                self._format_status_line(
                    "[yellow]![/yellow]",
                    f"Validation found {violations} issues (pass {pass_num})",
                ),
                style=None,
            )

    def llm_started(self, purpose: str) -> None:
        """Emit event when an LLM invocation starts.

        Args:
            purpose: Description of what the LLM is being asked to do
        """
        self.set_llm_state("waiting")
        self.start_spinner()

        if self.config.verbosity < VerbosityLevel.DETAIL:
            return

        timestamp = self._timestamp()
        self._print(f"{timestamp}LLM invocation: {purpose}", style="yellow")

    def llm_streaming(self, chunk: str) -> None:
        """Emit LLM response chunk during streaming.

        Args:
            chunk: Text chunk from the streaming LLM response
        """
        self.set_llm_state("streaming")

        if not self.config.stream:
            return

        # Stream output with [LLM] prefix
        # Don't add timestamp per chunk (would be noisy)
        if self._is_tty:
            self.console.print(f"  [LLM] {chunk}", end="", style="blue")
        else:
            # Line-by-line for non-TTY (no streaming animation)
            self.console.print(f"  [LLM] {chunk}")

    def llm_completed(self, summary: str, tokens: int = 0) -> None:
        """Emit event when an LLM invocation completes.

        Args:
            summary: Summary of the LLM response
            tokens: Token count for the response
        """
        self.stop_spinner()

        if self.config.verbosity < VerbosityLevel.DETAIL:
            self.set_llm_state("idle")
            return

        timestamp = self._timestamp()
        token_info = f" ({tokens} tokens)" if tokens > 0 else ""
        self._print(f"{timestamp}LLM complete{token_info}: {summary}", style="green")

        if self.config.verbosity >= VerbosityLevel.DEBUG:
            self._print(f"[DEBUG] Token count: {tokens}", style="dim")

        self.set_llm_state("idle")

    def item_started(self, item: dict) -> None:
        """Emit event when processing a plan item starts.

        Args:
            item: Plan item being processed
        """
        if interrupt_requested():
            if self.config.verbosity >= VerbosityLevel.DEBUG:
                self._print(
                    "[DEBUG] ProgressEmitter: suppressed item_started after interrupt request",
                    style="dim",
                )
            return

        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        if normalized_id and normalized_id != "?":
            self._plan_status[normalized_id] = "in_progress"
        item_title = item.get("title", "")
        normalized_title = str(item_title).strip()
        if normalized_id and normalized_id != "?":
            self._task_tracker_current_id = normalized_id
            if normalized_title:
                self._task_tracker_current_title = normalized_title
            if normalized_id not in self._task_tracker_index:
                self._task_tracker_items.append({"id": normalized_id, "title": normalized_title})
                self._task_tracker_index[normalized_id] = len(self._task_tracker_items) - 1
            elif normalized_title and not self._task_tracker_items[
                self._task_tracker_index[normalized_id]
            ].get("title"):
                self._task_tracker_items[self._task_tracker_index[normalized_id]]["title"] = (
                    normalized_title
                )

        self.start_spinner()

        # Level 0 (QUIET): Show minimal "Executing TX..."
        if self.config.verbosity == VerbosityLevel.QUIET:
            progress_prefix = ""
            if self._total_tasks > 0:
                display_index = self._current_task_index + 1
                progress_prefix = f"[Attempt {display_index}/{self._total_tasks}] "
            self._print(f"{progress_prefix}Executing {item_id}...", end="")
            if self._total_tasks > 0:
                self._current_task_index += 1
            return

        # Level 1 (PROGRESS): Show item with title
        if self.config.verbosity == VerbosityLevel.PROGRESS:
            timestamp = self._timestamp()
            item_title = item.get("title", "")
            if item_title:
                self._print(
                    f"{timestamp}Executing {item_id}: {item_title}...",
                    style="cyan",
                )
            else:
                self._print(f"{timestamp}Executing {item_id}...", style="cyan")
            if self._total_tasks > 0:
                self._current_task_index += 1
            self.render_task_tracker()
            return

        # Level 2+ (DETAIL and above): Show full details
        timestamp = self._timestamp()
        item_title = item.get("title", "untitled")
        self._print(f"{timestamp}Item {item_id}: {item_title}", style="cyan")

        if self.config.verbosity >= VerbosityLevel.DEBUG:
            # Truncate verbose item output
            item_str = str(item)
            max_chars = 300
            display_item = item_str if len(item_str) <= max_chars else item_str[:max_chars] + "..."
            self._print(f"[DEBUG] Full item: {display_item}", style="dim")
        self.render_task_tracker()

    def item_completed(self, item: dict, result: dict | None = None) -> None:
        """Emit event when processing a plan item completes.

        Args:
            item: Plan item that was processed
            result: Optional result data from processing
        """
        if self._spinner:
            self._spinner.clear_status_line()
        self.stop_spinner()
        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        result_payload = result if isinstance(result, dict) else {}
        raw_status = str(result_payload.get("status", "")).strip()
        status = self._normalize_status(raw_status)
        if not raw_status:
            status = "completed"
        elif status == "pending":
            # Unknown terminal status should not render as completed.
            status = "failed"
        is_success = status in {"completed", "skipped"}

        if normalized_id and normalized_id != "?":
            if is_success:
                self._task_tracker_done.add(normalized_id)
            else:
                self._task_tracker_done.discard(normalized_id)
            if self._task_tracker_current_id == normalized_id:
                self._task_tracker_current_id = None
                self._task_tracker_current_title = None
            self._plan_status[normalized_id] = status
            if is_success:
                self._maybe_render_story_completion(normalized_id)

        # Level 0 (QUIET): Complete the line with " done"
        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print(" done" if is_success else " failed")
            return

        # Level 1 (PROGRESS): Show completion with timestamp
        if self.config.verbosity == VerbosityLevel.PROGRESS:
            timestamp = self._timestamp()
            if is_success:
                self._print(f"{timestamp}{item_id} complete", style="green")
            else:
                self._print(f"{timestamp}{item_id} failed", style="red")
            self.render_task_tracker()
            return

        # Level 2+ (DETAIL and above): Show full details
        timestamp = self._timestamp()
        if is_success:
            self._print(f"{timestamp}Item {item_id} complete", style="green")
        else:
            self._print(f"{timestamp}Item {item_id} failed", style="red")

        if self.config.verbosity >= VerbosityLevel.DEBUG and result:
            # Truncate verbose result output
            result_str = str(result)
            max_chars = 300
            display_result = (
                result_str if len(result_str) <= max_chars else result_str[:max_chars] + "..."
            )
            self._print(f"[DEBUG] Result: {display_result}", style="dim")
        self.render_task_tracker()

    def item_heartbeat(
        self,
        item_id: str,
        elapsed_s: int,
        file_count: int,
        liveness_indicators: dict | None = None,
    ) -> None:
        """Emit heartbeat during long-running item execution.

        Args:
            item_id: ID of the item being executed
            elapsed_s: Seconds elapsed since execution started
            file_count: Number of files changed so far
            liveness_indicators: Optional dict with liveness status (DETAIL level only)
                                 Expected keys: log, cpu, files, db, proc (bool values)
        """
        self._heartbeat_count += 1
        # Note: Footer hint removed from heartbeat - was too noisy
        # Footer now shows only at start and completion

        # QUIET (0): No heartbeat output
        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        elapsed_str = self._format_elapsed(elapsed_s)

        timestamp = self._timestamp()

        # PROGRESS (1): Show heartbeat with elapsed time and file count
        if self.config.verbosity == VerbosityLevel.PROGRESS:
            file_summary = self.get_file_summary()
            llm_indicator = ""
            if self._llm_state == "waiting":
                llm_indicator = " [waiting for LLM]"
            elif self._llm_state == "streaming":
                llm_indicator = " [LLM streaming...]"
            elif self._llm_state == "processing":
                llm_indicator = " [processing]"
            prefix = "" if self._is_tty else timestamp
            task_label = self._current_task_label(item_id)
            message = f"{prefix}Executing {task_label}... ({elapsed_str})"
            if file_summary:
                message = f"{message} | {file_summary}"
            if llm_indicator:
                message = f"{message}{llm_indicator}"
            if self._should_inline_heartbeat():
                if self._spinner:
                    inline_message = message
                    if inline_message.startswith(prefix) and prefix:
                        inline_message = inline_message[len(prefix) :]
                    self._spinner.update_status_line(inline_message, style="cyan")
                return
            if llm_indicator and self._is_tty:
                message = message.replace(llm_indicator, f"[dim]{llm_indicator}[/dim]")
            self._print(message, style="cyan")
            return

        # DETAIL (2+): Show heartbeat with liveness indicators
        if self.config.verbosity >= VerbosityLevel.DETAIL:
            file_str = f", {file_count} files" if file_count > 0 else ""
            base_msg = f"{timestamp}Executing {item_id}... ({elapsed_str}{file_str})"

            # Add liveness indicators if provided
            if liveness_indicators:
                indicators = []
                for key in ["log", "cpu", "files", "db", "proc"]:
                    value = liveness_indicators.get(key, False)
                    indicators.append(f"{key}={'Y' if value else 'N'}")
                liveness_str = " [liveness: " + " ".join(indicators) + "]"
                self._print(base_msg + liveness_str, style="cyan")
            else:
                self._print(base_msg, style="cyan")
            if self._task_tracker_current_id:
                self.render_task_tracker()

    def file_event(
        self,
        filepath: str,
        event_type: str,
        line_count: int | None = None,
    ) -> None:
        """Emit file change event.

        Args:
            filepath: Path to the file that changed (relative to working dir)
            event_type: Type of event - "new" or "modified"
            line_count: Number of lines in the file (DETAIL level only)
        """
        # FIX-FILE-TRACKING-001: Filter out build artifacts from file tracking
        # These are generated files that shouldn't inflate file activity counts
        excluded_patterns = (
            "build/",
            "dist/",
            "__pycache__/",
            ".coverage",
            ".pytest_cache/",
            ".tox/",
            ".egg-info/",
            "node_modules/",
            ".pyc",
            ".pyo",
            ".pyz",
            ".pkg",
            ".toc",
            ".zip",
        )
        if any(pattern in filepath for pattern in excluded_patterns):
            return  # Skip build artifacts

        if event_type == "new":
            self.track_file_created()
        elif event_type == "modified":
            self.track_file_modified()

        # QUIET (0): No file events
        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        # PROGRESS (1): Show file event with type indicator
        timestamp = self._timestamp()
        symbol = "+" if event_type == "new" else "~"

        if self.config.verbosity == VerbosityLevel.PROGRESS:
            self._print(f"{timestamp}  {symbol} {filepath} ({event_type})", style="dim")
            return

        # DETAIL (2+): Show file event with line count
        if self.config.verbosity >= VerbosityLevel.DETAIL:
            if line_count is not None:
                self._print(
                    f"{timestamp}  {symbol} {filepath} ({event_type}, {line_count} lines)",
                    style="dim",
                )
            else:
                self._print(f"{timestamp}  {symbol} {filepath} ({event_type})", style="dim")

    def render_file_list(self, recent_files: list[str], max_display: int = 5) -> None:
        """Render a recent file list at DETAIL verbosity and above.

        Args:
            recent_files: Recent file paths to display
            max_display: Max entries to show before truncating
        """
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return

        if not recent_files:
            return

        if len(recent_files) > max_display:
            display_limit = max(max_display - 1, 0)
            visible_files = recent_files[:display_limit]
            remaining = len(recent_files) - display_limit
            file_list = ", ".join(visible_files)
            if file_list:
                file_list = f"{file_list}, ... and {remaining} more"
            else:
                file_list = f"... and {remaining} more"
        else:
            file_list = ", ".join(recent_files[:max_display])
            if not file_list:
                return

        self._print(f"    {glyphs.tree_last} Recent: {file_list}", style="dim")

    def error(
        self,
        message: str,
        hint: str | None = None,
        phase: str | None = None,
        affected_items: list | None = None,
        stack_trace: str | None = None,
        raw_response: dict | None = None,
    ) -> None:
        """Display error with detail based on verbosity level.

        Args:
            message: Error message
            hint: Recovery hint (shown at all levels)
            phase: Current phase when error occurred (shown at PROGRESS+)
            affected_items: Plan items affected by error (shown at DETAIL+)
            stack_trace: Full stack trace (shown at DEBUG only)
            raw_response: Raw server/LLM response (shown at DEBUG only)
        """
        timestamp = self._timestamp()

        # Level 0 (QUIET): Basic error + hint
        self._print(f"Error: {message}", style="bold red")
        if hint:
            self._print(f"Hint: {hint}", style="yellow")

        # Level 1 (PROGRESS): + timestamp + phase context
        if self.config.verbosity >= VerbosityLevel.PROGRESS:
            if timestamp:
                self._print(f"{timestamp}Error occurred", style="dim")
            if phase:
                self._print(f"Phase: {phase}", style="dim")

        # Level 2 (DETAIL): + affected items
        if self.config.verbosity >= VerbosityLevel.DETAIL and affected_items:
            self._print("Affected items:", style="yellow")
            for item in affected_items:
                item_id = item.get("id", "?")
                item_title = item.get("title", "untitled")
                self._print(f"  - {item_id}: {item_title}", style="dim")

        # Level 3 (DEBUG): + stack trace + raw response
        if self.config.verbosity >= VerbosityLevel.DEBUG:
            if stack_trace:
                self._print("[DEBUG] Stack trace:", style="dim")
                for line in str(stack_trace).splitlines():
                    self._print(line, style="dim")
            if raw_response:
                self._print("[DEBUG] Raw response:", style="dim")
                self._print(str(raw_response), style="dim")

    def warning(self, message: str) -> None:
        """Display a warning message."""
        timestamp = self._timestamp()
        if self.config.verbosity >= VerbosityLevel.PROGRESS and timestamp:
            self._print(f"{timestamp}Warning", style="dim")
        self._print(f"Warning: {message}", style="yellow")

    def decomposition_warning(
        self,
        elapsed_s: int,
        warning_threshold_s: int,
        duration_threshold_s: int | None = None,
    ) -> None:
        """Emit warning when execution nears decomposition threshold."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        if duration_threshold_s is not None and duration_threshold_s > 0:
            message = (
                f"[decompose] Long-running task: {elapsed_s}s; "
                f"will decompose at {duration_threshold_s}s if still running."
            )
        else:
            message = (
                f"[decompose] Long-running task: {elapsed_s}s "
                f"(warning at {warning_threshold_s}s)."
            )
        self._print(
            f"{timestamp}{message}",
            style="yellow",
        )

    def decomposition_triggered(self) -> None:
        """Emit notice when adaptive decomposition is triggered."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}-> Task running longer than expected; decomposing into subtasks...",
            style="yellow",
        )

    # =========================================================================
    # Validator / SenseCheck Pipeline Events
    # =========================================================================

    def validator_started(self, stage: str) -> None:
        """Emit event when a SenseCheck validator stage starts.

        Args:
            stage: Validation stage ('intent', 'plan', 'review_filter')
        """
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        from obra.messages.validator import get_validator

        timestamp = self._timestamp()
        verbose = self.config.verbosity >= VerbosityLevel.DETAIL
        message = get_validator(f"{stage}.running", verbose=verbose)
        self._print(f"{timestamp}  {glyphs.arrow} {message}", style="cyan")
        if self._spinner and self._spinner.is_active:
            self._spinner.update_status_line(f"validator — {message}", style="cyan")

    def validator_completed(
        self,
        stage: str,
        sound: bool,
        *,
        count: int | None = None,
        duration_s: float | None = None,
    ) -> None:
        """Emit event when a SenseCheck validator stage completes.

        Args:
            stage: Validation stage ('intent', 'plan', 'review_filter')
            sound: Whether the validation found no issues (sound=True)
            count: Number of constraints/issues/decisions (if any)
            duration_s: Duration in seconds
        """
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        from obra.messages.validator import get_validator

        timestamp = self._timestamp()
        verbose = self.config.verbosity >= VerbosityLevel.DETAIL

        # Determine appropriate message key based on stage and result
        if sound:
            message = get_validator(f"{stage}.sound", verbose=verbose)
            style = "green"
            symbol = glyphs.success
        else:
            # Stage-specific result messages
            if stage == "intent":
                message = get_validator(f"{stage}.constraints", count=count or 0, verbose=verbose)
            elif stage == "plan":
                message = get_validator(f"{stage}.issues", count=count or 0, verbose=verbose)
            elif stage == "review_filter":
                decision_count = int(count or 0)
                label = "decision" if decision_count == 1 else "decisions"
                message = f"Generated {decision_count} review filter {label}"
            else:
                message = f"Validation completed ({stage})"
            style = "yellow"
            symbol = glyphs.arrow

        duration_str = f" ({duration_s:.1f}s)" if duration_s is not None else ""
        self._print(f"{timestamp}  {symbol} {message}{duration_str}", style=style)
        self._restore_spinner_status_line()

    def review_filter_applied(
        self,
        *,
        removed_count: int,
        adjusted_count: int,
        kept_count: int,
        enriched_count: int = 0,
        item_id: str | None = None,
        review_cycle_id: str | None = None,
    ) -> None:
        """Emit event when server applies review-filter decisions to reports."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        normalized_item = str(item_id).strip() if item_id else ""
        normalized_cycle = str(review_cycle_id).strip() if review_cycle_id else ""
        if self._active_review_cycle_id and not normalized_cycle:
            return
        if self._active_review_item_id and not normalized_item:
            return
        if not self._review_context_matches(item_id=item_id, review_cycle_id=review_cycle_id):
            return

        if normalized_item:
            self._active_review_item_id = normalized_item
        if normalized_cycle:
            self._active_review_cycle_id = normalized_cycle

        timestamp = self._timestamp()
        item_context = f" ({normalized_item})" if normalized_item else ""
        message = (
            f"Applied review filter{item_context}: "
            f"removed={int(removed_count)}, adjusted={int(adjusted_count)}, "
            f"kept={int(kept_count)}, enriched={int(enriched_count)}"
        )
        self._print(f"{timestamp}  {glyphs.arrow} {message}", style="yellow")

    def validator_skipped(self, stage: str) -> None:
        """Emit event when a SenseCheck validator stage is skipped (disabled).

        Args:
            stage: Validation stage ('intent', 'plan', 'review_filter')
        """
        if self.config.verbosity < VerbosityLevel.DETAIL:
            self._restore_spinner_status_line()
            return

        from obra.messages.validator import get_validator

        timestamp = self._timestamp()
        verbose = self.config.verbosity >= VerbosityLevel.DETAIL
        message = get_validator(f"{stage}.skipped", verbose=verbose)
        self._print(f"{timestamp}  {glyphs.skip} {message}", style="dim")
        self._restore_spinner_status_line()

    def validator_error(
        self,
        stage: str,
        error: str,
        *,
        duration_s: float | None = None,
    ) -> None:
        """Emit event when a SenseCheck validator stage fails.

        Args:
            stage: Validation stage ('intent', 'plan', 'review_filter')
            error: Error message
            duration_s: Duration in seconds
        """
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        from obra.messages.validator import build_validator_message

        timestamp = self._timestamp()
        verbose = self.config.verbosity >= VerbosityLevel.DETAIL
        message = build_validator_message(stage, "error", message=error, verbose=verbose)
        duration_str = f" ({duration_s:.1f}s)" if duration_s is not None else ""
        self._print(f"{timestamp}  {glyphs.failure} {message}{duration_str}", style="red")
        self._restore_spinner_status_line()

    def interactive_guard_notice(
        self,
        message: str,
        affected_items: list[dict] | None = None,
        stack_trace: str | None = None,
        raw_response: str | None = None,
    ) -> None:
        """Display an interactive guard notice."""
        timestamp = self._timestamp()
        if self.config.verbosity >= VerbosityLevel.PROGRESS and timestamp:
            self._print(f"{timestamp}Interactive guard", style="dim")
        self._print(f"Interactive guard: {message}", style="yellow")

        # Level 2 (DETAIL): + affected items + partial results
        if self.config.verbosity >= VerbosityLevel.DETAIL and affected_items:
            self._print("Affected items:", style="yellow")
            for item in affected_items:
                item_id = item.get("id", "?")
                item_title = item.get("title", "unknown")
                self._print(f"  - {item_id}: {item_title}", style="dim")

        # Level 3 (DEBUG): + stack trace + raw response
        if self.config.verbosity >= VerbosityLevel.DEBUG:
            if stack_trace:
                self._print("[DEBUG] Stack trace:", style="dim")
                for line in stack_trace.split("\n"):
                    if line.strip():
                        self._print(f"  {line}", style="dim")
            if raw_response:
                self._print(f"[DEBUG] Raw response: {raw_response}", style="dim")
