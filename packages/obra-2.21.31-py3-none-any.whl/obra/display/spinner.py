"""Animated status spinner with rotating phrases.

Uses Rich's Live display for proper terminal handling:
- Spinner stays at bottom of terminal
- print_above() prints persistent messages above spinner
- Auto-animates without manual intervention
- Thread-safe, TTY-aware
"""

import contextlib
import random
import threading
import time
from typing import TYPE_CHECKING, Iterator

from rich.console import Group
from rich.segment import Segment
from rich.spinner import Spinner
from rich.text import Text

if TYPE_CHECKING:
    from rich.console import Console
    from rich.live import Live

# Custom OSC sequence marking spinner output. Terminals silently ignore
# unrecognized OSC codes per ECMA-48. The session logger TeeWriter checks
# for this before ANSI stripping to exclude transient spinner renders from
# session log files.
SPINNER_SENTINEL = "\x1b]9999;\x07"


SPINNER_PHRASES: list[str] = [
    # Self-aware meta
    "Apparently there has to be something here...",
    "Yes, this is a spinner. Very original.",
    "Spinning. Because that's what we do now.",
    "Look, a distraction while I think...",
    "This spinner was someone's OKR...",
    "Copying the market leader's homework...",
    "Big Tech did it, so we had to...",
    "Every CLI has one of these now...",
    "The industry has decided you need this...",
    # Ironic progress
    "Making excellent progress (citation needed)...",
    "Working. Allegedly...",
    "Doing... something. Probably...",
    "Trust me, things are happening...",
    "Progress is being made. Supposedly...",
    "Almost done (legally required disclaimer)...",
    "Any moment now. Or not. Who knows...",
    "Still here. Still spinning...",
    # Light existential
    "Pondering my existence as a spinner...",
    "I'm a loading indicator. This is my life now...",
    "Somewhere, a PM is proud of this...",
    "This is what peak engineering looks like...",
    "Billions in compute, and here we are...",
    "The singularity is just fancy spinners...",
    # Playful mocking
    "At least we're honest about copying...",
    "Innovation: spinners with different words...",
    "Disrupting the spinner industry...",
    "The spinner considered its purpose, then spun anyway.",
    "This isn't progress. It's interpretive rotation.",
    "The user watched the spinner. The spinner watched back.",
    "A narrator might call this \"momentum.\"",
    "Spinning is a choice, and you have made it.",
    "The spinner could stop at any time. It won't.",
    "This line exists to honor your patience.",
    "Somewhere, a list is feeling important about itself.",
    "The spinner promised it was almost done. It didn't say when.",
    "If you're reading this, the spinner is still winning.",
    "We could have done nothing. We chose the spinner.",
    "The spinner practiced stillness, then remembered its job.",
    "The spinner briefly imagined being progress bar. Felt seen.",
    # Dry observations
    "Your keyboard is probably dusty...",
    "When did you last blink?...",
    "Still faster than installing dependencies...",
    "At least it's not a progress bar...",
    "Remember when computers were fast?...",
    "Speculating pipelines...",
    "Recalibrating the reticulation matrix...",
    "Polishing invisible gears...",
    "Folding time into neat little loops...",
    "Tuning the wobble coefficient...",
    "Inflating confidence intervals...",
    "Buffering the buffer...",
    "Aligning cosmic dust particles...",
    "Counting to infinity (almost there)...",
    "Negotiating with the scheduler...",
    # Brief honesty
    "LLMs are slow. Sorry...",
    "The LLM is thinking. Expensively...",
    # Gentle existential
    "It wasn't much, but it was honest work.",
    "The spinner found meaning in rotation.",
    "Small. Persistent. Unnoticed.",
    "It had never asked to be a loading indicator.",
    "Somewhere, this matters to someone.",
    # Flat absurdism
    "In another timeline, this is already done.",
    "This moment will not be remembered.",
    "Pixels, rearranging themselves. Progress.",
    "The work continues, indifferent to observation.",
]

_ACTIVE_SPINNER: "StatusSpinner | None" = None
_SPINNER_SUSPEND_DEPTH = 0
_SPINNER_SUSPEND_STATE: dict[str, object] | None = None
_SPINNER_SUSPEND_LOCK = threading.Lock()


def set_active_spinner(spinner: "StatusSpinner | None") -> None:
    """Register the active spinner for global prompt coordination."""
    global _ACTIVE_SPINNER
    _ACTIVE_SPINNER = spinner


def get_active_spinner() -> "StatusSpinner | None":
    """Return the currently registered spinner, if any."""
    return _ACTIVE_SPINNER


def suspend_active_spinner() -> "contextlib.AbstractContextManager[None]":
    """Suspend the active spinner while running interactive prompts."""
    @contextlib.contextmanager
    def _suspend() -> Iterator[None]:
        global _SPINNER_SUSPEND_DEPTH, _SPINNER_SUSPEND_STATE
        spinner = get_active_spinner()
        if spinner is None or not spinner.is_active:
            yield
            return
        with _SPINNER_SUSPEND_LOCK:
            if _SPINNER_SUSPEND_DEPTH == 0:
                _SPINNER_SUSPEND_STATE = spinner.snapshot_state()
                spinner.stop()
            _SPINNER_SUSPEND_DEPTH += 1
        try:
            yield
        finally:
            with _SPINNER_SUSPEND_LOCK:
                _SPINNER_SUSPEND_DEPTH = max(0, _SPINNER_SUSPEND_DEPTH - 1)
                if _SPINNER_SUSPEND_DEPTH == 0 and _SPINNER_SUSPEND_STATE:
                    spinner.restore_state(_SPINNER_SUSPEND_STATE)
                    _SPINNER_SUSPEND_STATE = None

    return _suspend()


def _parse_hex_color(value: str) -> tuple[int, int, int] | None:
    """Parse #RRGGBB hex color into RGB tuple."""
    if not isinstance(value, str):
        return None
    if not value.startswith("#") or len(value) != 7:
        return None
    try:
        r = int(value[1:3], 16)
        g = int(value[3:5], 16)
        b = int(value[5:7], 16)
        return r, g, b
    except ValueError:
        return None


def _format_hex_color(rgb: tuple[int, int, int]) -> str:
    """Format RGB tuple as #RRGGBB."""
    r, g, b = rgb
    return f"#{r:02x}{g:02x}{b:02x}"


def _darken_rgb(rgb: tuple[int, int, int], factor: float) -> tuple[int, int, int]:
    """Darken RGB by multiplying channels with factor (0-1)."""
    r, g, b = rgb
    return (
        max(0, min(255, int(r * factor))),
        max(0, min(255, int(g * factor))),
        max(0, min(255, int(b * factor))),
    )


def _interpolate_rgb(
    start: tuple[int, int, int],
    end: tuple[int, int, int],
    t: float,
) -> tuple[int, int, int]:
    """Interpolate between two RGB colors."""
    t = max(0.0, min(1.0, t))
    return (
        int(start[0] + (end[0] - start[0]) * t),
        int(start[1] + (end[1] - start[1]) * t),
        int(start[2] + (end[2] - start[2]) * t),
    )


class StatusSpinner:
    """Animated status spinner with rotating phrases.

    Uses Rich's Live display for proper terminal handling:
    - Spinner stays at bottom of terminal
    - print_above() prints persistent messages above spinner
    - Auto-animates without manual intervention
    - Thread-safe, TTY-aware
    """

    def __init__(
        self,
        console: "Console",
        phrase_rotation_interval_s: float = 4.0,
        phrase_rotation_min_s: float | None = None,
        phrase_rotation_max_s: float | None = None,
        accent_enabled: bool = True,
        accent_highlight_color: str = "#f5c090",
        accent_highlight_width: int = 2,
        accent_highlight_gradient: bool = True,
        accent_sweep_target_s: float = 6.0,
        accent_step_min_ms: int = 80,
        accent_step_max_ms: int = 150,
        accent_pause_min_s: float = 5.0,
        accent_pause_max_s: float = 9.0,
        refresh_rate_hz: int = 10,
    ) -> None:
        """Initialize the status spinner.

        Args:
            console: Rich Console instance for output
            phrase_rotation_interval_s: Seconds between phrase rotations
            phrase_rotation_min_s: Optional minimum seconds for jittered rotation interval
            phrase_rotation_max_s: Optional maximum seconds for jittered rotation interval
            accent_enabled: Whether to render shimmer accent on phrase text
            accent_highlight_color: Rich color or hex for shimmer highlight
            accent_highlight_width: Width of highlight in characters
            accent_highlight_gradient: Whether to apply a subtle gradient in highlight
            accent_sweep_target_s: Target seconds for one shimmer sweep
            accent_step_min_ms: Minimum step duration in milliseconds
            accent_step_max_ms: Maximum step duration in milliseconds
            accent_pause_min_s: Minimum pause between sweeps in seconds
            accent_pause_max_s: Maximum pause between sweeps in seconds
            refresh_rate_hz: Spinner animation refresh rate
        """
        self._console = console
        self._phrase_rotation_interval_s = phrase_rotation_interval_s
        self._phrase_rotation_min_s = phrase_rotation_min_s
        self._phrase_rotation_max_s = phrase_rotation_max_s
        self._accent_enabled = bool(accent_enabled)
        self._accent_highlight_color = accent_highlight_color
        self._accent_highlight_width = max(0, int(accent_highlight_width))
        self._accent_highlight_gradient = bool(accent_highlight_gradient)
        self._accent_sweep_target_s = max(0.1, float(accent_sweep_target_s))
        self._accent_step_min_s = max(0.01, float(accent_step_min_ms) / 1000.0)
        self._accent_step_max_s = max(0.01, float(accent_step_max_ms) / 1000.0)
        self._accent_pause_min_s = max(0.0, float(accent_pause_min_s))
        self._accent_pause_max_s = max(0.0, float(accent_pause_max_s))
        self._refresh_rate_hz = refresh_rate_hz
        self._live: "Live | None" = None
        self._current_phrase: str = ""
        self._phrase_lock = threading.Lock()
        self._accent_lock = threading.Lock()
        self._status_lock = threading.Lock()
        self._status_line: str | None = None
        self._status_style: str | None = None
        self._accent_cycle_start_s: float = 0.0
        self._accent_pause_s: float = 0.0
        self._phrase_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._renderable: "_SpinnerRenderable | None" = None
        self._spinner_renderable: Spinner | None = None
        self._rotation_paused: bool = False
        self._configure_accent_support()

    def _configure_accent_support(self) -> None:
        """Disable accent if terminal cannot render colors."""
        if not self._accent_enabled:
            return
        try:
            if getattr(self._console, "no_color", False):
                self._accent_enabled = False
                return
            if getattr(self._console, "color_system", None) is None:
                self._accent_enabled = False
                return
        except Exception:
            self._accent_enabled = False

    def start(self, initial_phrase: str | None = None) -> None:
        """Start the spinner with optional initial phrase."""
        if self._live is not None:
            return  # Already running

        # Import here to avoid circular imports and defer heavy import
        from rich.live import Live

        self._current_phrase = initial_phrase or self._random_phrase()
        self._reset_accent_cycle()
        self._stop_event.clear()

        # Create Live display with spinner + phrase
        self._spinner_renderable = Spinner("dots", text=Text(""))
        self._renderable = _SpinnerRenderable(self, self._spinner_renderable)
        self._live = Live(
            self._renderable,
            console=self._console,
            refresh_per_second=self._refresh_rate_hz,
            transient=True,  # Clears on stop
        )
        self._live.start()

        # Start phrase rotation thread
        self._phrase_thread = threading.Thread(
            target=self._rotate_phrases,
            daemon=True,
        )
        self._phrase_thread.start()

    def stop(self) -> None:
        """Stop the spinner and clear the line."""
        self._stop_event.set()
        if self._live:
            self._live.stop()
            self._live = None
        self._renderable = None
        self._spinner_renderable = None
        if self._phrase_thread:
            self._phrase_thread.join(timeout=1.0)
            self._phrase_thread = None
        with self._status_lock:
            self._status_line = None
            self._status_style = None

    def update_phrase(self, phrase: str) -> None:
        """Update the displayed phrase."""
        with self._phrase_lock:
            self._current_phrase = phrase
        self._reset_accent_cycle()
        self._refresh_live()

    def update_status_line(self, line: str, style: str | None = None) -> None:
        """Update optional status line rendered above the spinner."""
        with self._status_lock:
            self._status_line = line
            self._status_style = style
        self._refresh_live()

    def clear_status_line(self) -> None:
        """Clear any active status line above the spinner."""
        with self._status_lock:
            self._status_line = None
            self._status_style = None
        self._refresh_live()

    def set_rotation_paused(self, paused: bool) -> None:
        """Pause or resume automatic phrase rotation."""
        self._rotation_paused = bool(paused)

    def print_above(self, message: str, style: str | None = None) -> None:
        """Print a persistent message above the spinner.

        Rich's Live handles this automatically - it clears the spinner,
        prints the message, then re-renders the spinner below.
        """
        if self._live:
            self._live.console.print(message, style=style)
        else:
            self._console.print(message, style=style)

    @property
    def is_active(self) -> bool:
        """Return True if the spinner is currently running."""
        return self._live is not None

    def snapshot_state(self) -> dict[str, object]:
        """Capture current spinner state for suspension/resume."""
        with self._phrase_lock:
            phrase = self._current_phrase
        with self._status_lock:
            status_line = self._status_line
            status_style = self._status_style
        return {
            "phrase": phrase,
            "status_line": status_line,
            "status_style": status_style,
            "rotation_paused": self._rotation_paused,
            "active": self.is_active,
        }

    def restore_state(self, state: dict[str, object]) -> None:
        """Restore spinner state after suspension."""
        if not state.get("active"):
            return
        phrase = state.get("phrase")
        self.start(initial_phrase=str(phrase) if phrase else None)
        status_line = state.get("status_line")
        status_style = state.get("status_style")
        if status_line:
            self.update_status_line(str(status_line), str(status_style) if status_style else None)
        self.set_rotation_paused(bool(state.get("rotation_paused", False)))

    def _render(self) -> Group:
        """Render spinner + phrase as a Rich Group."""
        with self._phrase_lock:
            phrase = self._current_phrase
        text = self._build_phrase_text(phrase)
        return Group(Spinner("dots", text=text))

    def _rotate_phrases(self) -> None:
        """Background thread to rotate phrases periodically."""
        while not self._stop_event.wait(timeout=self._next_rotation_interval()):
            if self._rotation_paused:
                continue
            with self._phrase_lock:
                self._current_phrase = self._random_phrase()
            self._reset_accent_cycle()
            self._refresh_live()

    def _refresh_live(self) -> None:
        """Refresh the Live renderable when active."""
        if self._live and self._renderable:
            self._live.update(self._renderable)

    def _build_phrase_text(self, phrase: str) -> Text:
        """Return phrase text with optional shimmer accent."""
        base_text = Text(f" {phrase}", style="italic sandy_brown")
        if not self._accent_enabled or not phrase or self._accent_highlight_width <= 0:
            return base_text
        highlight = self._compute_highlight_span(len(phrase))
        if highlight is None:
            return base_text
        start, end = highlight
        # Offset by 1 to account for leading space in base_text
        gradient_colors = self._compute_gradient_colors(end - start)
        if gradient_colors:
            for idx, color in enumerate(gradient_colors):
                base_text.stylize(color, start + 1 + idx, start + 2 + idx)
        else:
            base_text.stylize(self._accent_highlight_color, start + 1, end + 1)
        return base_text

    def _compute_gradient_colors(self, width: int) -> list[str] | None:
        """Compute gradient colors for the shimmer highlight."""
        if not self._accent_highlight_gradient or width <= 1:
            return None
        center_rgb = _parse_hex_color(self._accent_highlight_color)
        if center_rgb is None:
            return None
        edge_rgb = _darken_rgb(center_rgb, 0.7)
        center = (width - 1) / 2.0
        colors: list[str] = []
        for idx in range(width):
            if center > 0:
                distance = abs(idx - center) / center
            else:
                distance = 0.0
            rgb = _interpolate_rgb(center_rgb, edge_rgb, distance)
            colors.append(_format_hex_color(rgb))
        return colors

    def _compute_highlight_span(self, phrase_len: int) -> tuple[int, int] | None:
        """Compute highlight span for shimmer accent."""
        if phrase_len <= 0:
            return None
        width = min(self._accent_highlight_width, phrase_len)
        step_s = self._compute_accent_step_s(phrase_len)
        sweep_duration_s = step_s * phrase_len
        with self._accent_lock:
            now = self._monotonic_time()
            cycle_end_s = self._accent_cycle_start_s + sweep_duration_s + self._accent_pause_s
            if now >= cycle_end_s:
                self._accent_cycle_start_s = now
                self._accent_pause_s = self._next_accent_pause_s()
                cycle_end_s = self._accent_cycle_start_s + sweep_duration_s + self._accent_pause_s
            elapsed_s = now - self._accent_cycle_start_s
            if elapsed_s >= sweep_duration_s:
                return None
            position = int(elapsed_s / step_s)
        position = min(max(position, 0), phrase_len - 1)
        end = min(position + width, phrase_len)
        return position, end

    def _compute_accent_step_s(self, phrase_len: int) -> float:
        """Compute step duration to target a consistent sweep duration."""
        steps = max(1, phrase_len)
        raw_step = self._accent_sweep_target_s / steps
        min_s = min(self._accent_step_min_s, self._accent_step_max_s)
        max_s = max(self._accent_step_min_s, self._accent_step_max_s)
        return min(max(raw_step, min_s), max_s)

    def _next_accent_pause_s(self) -> float:
        """Return next jittered pause between sweeps."""
        min_s = min(self._accent_pause_min_s, self._accent_pause_max_s)
        max_s = max(self._accent_pause_min_s, self._accent_pause_max_s)
        if max_s <= 0.0:
            return 0.0
        if min_s <= 0.0:
            return max_s
        return random.uniform(min_s, max_s)

    def _reset_accent_cycle(self) -> None:
        """Reset shimmer sweep timing when phrase changes."""
        if not self._accent_enabled:
            return
        with self._accent_lock:
            self._accent_cycle_start_s = self._monotonic_time()
            self._accent_pause_s = self._next_accent_pause_s()

    def _monotonic_time(self) -> float:
        """Return monotonic time in seconds."""
        return time.monotonic()

    def _next_rotation_interval(self) -> float:
        """Return next rotation interval, using jitter if configured."""
        min_s = self._phrase_rotation_min_s
        max_s = self._phrase_rotation_max_s
        if min_s is not None and max_s is not None:
            if min_s <= 0 or max_s <= 0:
                return self._phrase_rotation_interval_s
            if max_s < min_s:
                min_s, max_s = max_s, min_s
            return random.uniform(min_s, max_s)
        return self._phrase_rotation_interval_s

    def _random_phrase(self) -> str:
        """Return a random phrase from the bank."""
        return random.choice(SPINNER_PHRASES)


class _SpinnerRenderable:
    """Renderable wrapper to allow Live refresh to drive shimmer updates."""

    def __init__(self, spinner: StatusSpinner, renderable: Spinner) -> None:
        self._spinner = spinner
        self._renderable = renderable

    def __rich_console__(self, console, options):
        # Emit sentinel so the session logger TeeWriter can identify and
        # exclude everything from this point onwards in the write buffer.
        yield Segment(SPINNER_SENTINEL, control=True)
        with self._spinner._status_lock:
            status_line = self._spinner._status_line
            status_style = self._spinner._status_style
        with self._spinner._phrase_lock:
            phrase = self._spinner._current_phrase
        text = self._spinner._build_phrase_text(phrase)
        self._renderable.update(text=text)
        if status_line:
            status_text = Text(status_line, style=status_style)
            yield Group(status_text, self._renderable)
        else:
            yield self._renderable
