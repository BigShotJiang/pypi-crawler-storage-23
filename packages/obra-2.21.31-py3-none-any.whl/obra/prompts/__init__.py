"""Unified prompt registry for Obra LLM prompts.

Provides catalog and discovery utilities for all prompts across the codebase.

This package serves as the central registry for all prompts used in Obra's
LLM interactions, enabling:
- Discovery of available prompts
- Metadata queries (tier, output format)
- Centralized documentation of prompt purpose

Subpackages:
- derive: Derivation and exploration prompts
- fix: Issue context prompts
- execute: Execution assessment prompts
- review: Quality assessment and alignment prompts
- story0: Story 0 prerequisite prompts
- intent: Intent generation and conversion prompts
- agents: Agent template prompts
- fragments: Shared prompt fragments
- templates: Project initialization templates

Refactoring: REFACTOR-PROMPT-LIBRARY-001, REFACTOR-PROMPT-CONSOLIDATION-001
"""

from __future__ import annotations

from obra.prompts.registry import (
    PROMPT_CATALOG,
    get_prompt_metadata,
    get_prompts_by_tier,
    list_prompts,
)

# Define lazy-loaded exports from subpackages
_SUBMODULE_EXPORTS = {
    # fragments exports
    "build_working_directory_constraint": "obra.prompts.fragments",
    "WORKING_DIRECTORY_CONSTRAINT": "obra.prompts.fragments",
    "build_interactive_recovery_banner": "obra.prompts.fragments",
    "build_template_edit_prompt": "obra.prompts.fragments",
    "get_response_protocol_instructions": "obra.prompts.fragments",
    "RESPONSE_PROTOCOL_INSTRUCTIONS": "obra.prompts.fragments",
    # derive exports
    "FOUR_PHASE_GUIDANCE": "obra.prompts.derive",
    "PATTERN_GUIDANCE": "obra.prompts.derive",
    "SIZING_GUIDANCE": "obra.prompts.derive",
    "build_sizing_guidance_block": "obra.prompts.derive",
    "build_derivation_prompt": "obra.prompts.derive",
    "build_four_phase_guidance": "obra.prompts.derive",
    "build_refinement_prompt": "obra.prompts.derive",
    "build_step1_prompt": "obra.prompts.derive",
    "build_step1_epics_only_prompt": "obra.prompts.derive",
    "build_step2_prompt": "obra.prompts.derive",
    "build_step2_per_epic_prompt": "obra.prompts.derive",
    "build_step3_prompt": "obra.prompts.derive",
    "get_pattern_guidance": "obra.prompts.derive",
    "build_revision_prompt": "obra.prompts.derive",
    "EXPLORATION_PROMPT_TEMPLATE": "obra.prompts.derive",
    "build_exploration_prompt": "obra.prompts.derive",
    "build_task_classification_prompt": "obra.prompts.derive",
    # fix exports
    "build_batch_fix_context": "obra.prompts.fix",
    "build_issue_specific_context": "obra.prompts.fix",
    "build_test_gap_issue_context": "obra.prompts.fix",
    "build_test_gap_batch_context": "obra.prompts.fix",
    "build_test_gap_inference_prompt": "obra.prompts.fix",
    # execute exports
    "build_assessment_prompt": "obra.prompts.execute",
    # review exports
    "build_fallback_examine_prompt": "obra.prompts.review",
    "build_quality_assessment_prompt": "obra.prompts.review",
    "build_plan_intent_alignment_prompt": "obra.prompts.review",
    "build_story_intent_alignment_prompt": "obra.prompts.review",
    "build_gap_detection_prompt": "obra.prompts.review",
    "build_story_gap_prompt": "obra.prompts.review",
    "build_epic_gap_prompt": "obra.prompts.review",
    # story0 exports
    "build_story0_derivation_prompt": "obra.prompts.story0",
    "build_story0_manifest_prompt": "obra.prompts.story0",
    # intent exports
    "build_intent_generation_prompt": "obra.prompts.intent",
    "build_project_classification_prompt": "obra.prompts.intent",
    "build_intent_to_plan_prompt": "obra.prompts.intent",
    # templates exports
    "DEFAULT_OBRA_CLAUDE_MD": "obra.prompts.templates",
}

# Build __all__ from registry API + lazy exports
__all__ = [
    "PROMPT_CATALOG",
    "get_prompt_metadata",
    "get_prompts_by_tier",
    "list_prompts",
]
__all__.extend(_SUBMODULE_EXPORTS.keys())


def __getattr__(name: str):
    """PEP 562 lazy loading for submodule exports."""
    if name in _SUBMODULE_EXPORTS:
        from importlib import import_module

        module_name = _SUBMODULE_EXPORTS[name]
        module = import_module(module_name)
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


def __dir__():
    """List available exports."""
    return __all__
