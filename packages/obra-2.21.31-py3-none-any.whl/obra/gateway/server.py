"""Gateway server — FastAPI application bridging HTTP/WebSocket clients to HybridOrchestrator."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from obra.gateway.auth import generate_token, get_auth_dependency
from obra.gateway.session_manager import SessionManager

logger = logging.getLogger(__name__)

_OBRA_VERSION = "2.21.21"


def _print_startup_banner(host: str, port: int, token: str) -> None:
    """Print Rich-formatted startup banner."""
    from rich.console import Console
    from rich.panel import Panel

    console = Console()
    token_hint = token[:4] + "***" if len(token) > 4 else "***"

    lines = [
        f"[bold]Obra Gateway[/bold] v{_OBRA_VERSION}",
        "",
        f"  Listening:  [cyan]http://{host}:{port}[/cyan]",
        f"  Auth token: [yellow]{token_hint}[/yellow]",
        "",
        "[dim]Endpoints:[/dim]",
        "  POST   /v1/sessions              Create session",
        "  GET    /v1/sessions              List sessions",
        "  GET    /v1/sessions/{id}         Session details",
        "  GET    /v1/sessions/{id}/events  SSE event stream",
        "  POST   /v1/sessions/{id}/cancel  Cancel session",
        "  POST   /v1/sessions/{id}/escalation  Resolve escalation",
        "  WS     /v1/ws                    WebSocket transport",
        "  GET    /health                   Health check",
    ]

    console.print()
    console.print(Panel("\n".join(lines), border_style="green"))
    console.print("[dim]Press Ctrl+C to stop[/dim]")
    console.print()


class GatewayServer:
    """FastAPI-based gateway server for HTTP/SSE and WebSocket access to Obra sessions.

    Args:
        config: Gateway configuration dict from get_gateway_config().
    """

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config

        # Resolve auth token
        self._token: str = config.get("auth_token") or generate_token()

        # Session manager (created early so lifespan can reference it)
        self._session_manager = SessionManager(
            max_sessions=config.get("max_sessions", 5),
            escalation_timeout_s=config.get("escalation_timeout_s", 300.0),
        )

        # Lifespan with shutdown cleanup
        session_mgr = self._session_manager

        @asynccontextmanager
        async def _lifespan(app: FastAPI):  # type: ignore[type-arg]
            yield
            # Shutdown: cancel all running sessions
            for record in session_mgr.list_sessions():
                if record.status == "running":
                    try:
                        session_mgr.cancel_session(record.session_id)
                    except Exception:
                        logger.warning("Failed to cancel session %s on shutdown", record.session_id)

        # Build FastAPI app (auth added per-router, not globally, so /health stays open)
        self._auth_dep = get_auth_dependency(self._token)
        self._app = FastAPI(
            title="Obra Gateway",
            version=_OBRA_VERSION,
            lifespan=_lifespan,
        )

        # CORS middleware
        if config.get("enable_cors", False):
            self._app.add_middleware(
                CORSMiddleware,
                allow_origins=config.get("cors_origins", ["*"]),
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            )

        # Attach session manager to app state
        self._app.state.session_manager = self._session_manager
        self._app.state.gateway_token = self._token

        # Register routes
        self._register_routes()

        # Health endpoint (no auth required)
        @self._app.get("/health", include_in_schema=True)
        async def health() -> dict[str, Any]:
            running = sum(
                1 for s in self._session_manager.list_sessions() if s.status == "running"
            )
            return {
                "status": "ok",
                "active_sessions": running,
                "version": _OBRA_VERSION,
            }

    def _register_routes(self) -> None:
        """Register all route modules."""
        from obra.gateway.routes.escalations import router as escalations_router
        from obra.gateway.routes.events import router as events_router
        from obra.gateway.routes.sessions import router as sessions_router
        from obra.gateway.routes.ws import router as ws_router

        auth = [Depends(self._auth_dep)]
        self._app.include_router(sessions_router, dependencies=auth)
        self._app.include_router(events_router, dependencies=auth)
        self._app.include_router(escalations_router, dependencies=auth)
        # WS router handles its own auth via first-message pattern
        self._app.include_router(ws_router)

    @property
    def app(self) -> FastAPI:
        """The FastAPI application instance."""
        return self._app

    @property
    def token(self) -> str:
        """The auth token (for display/logging)."""
        return self._token

    def run(self, host: str | None = None, port: int | None = None) -> None:
        """Start the gateway server.

        Args:
            host: Override bind address.
            port: Override port number.
        """
        import uvicorn

        bind_host = host or self._config.get("host", "127.0.0.1")
        bind_port = port or self._config.get("port", 18790)

        _print_startup_banner(bind_host, bind_port, self._token)
        uvicorn.run(self._app, host=bind_host, port=bind_port)
