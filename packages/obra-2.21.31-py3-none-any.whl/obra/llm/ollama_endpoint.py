"""Ollama endpoint resolution helpers.

Resolves the Ollama endpoint from config/env/default with a local-first
precedence. No VM-specific tunneling logic is included.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Any

from obra.config.loaders import load_config

# Hardcoded fallback for backward compatibility
# DEPRECATED: Prefer reading from config via resolve_ollama_endpoint()
# To modify defaults, edit obra/config/default_config.yaml under llm.ollama.endpoint.
DEFAULT_OLLAMA_ENDPOINT = "http://localhost:11434"


def _get_ollama_endpoint_from_config() -> str:
    """Get Ollama endpoint from config (lazy-loaded to avoid circular imports).

    Returns:
        Ollama endpoint from llm.ollama.endpoint config key
    """
    try:
        # Lazy import to avoid circular dependency
        from obra.config.loaders import get_ollama_endpoint

        return get_ollama_endpoint()
    except (ImportError, KeyError):
        # Fall back to hardcoded default if config loading fails
        return DEFAULT_OLLAMA_ENDPOINT


def _get_nested_value(config: Mapping[str, Any], path: str) -> Any:
    """Get nested config value using dot-separated path.

    Args:
        config: Config mapping
        path: Dot-separated path (e.g., "llm.api_url")

    Returns:
        Value if found, else None
    """
    current: Any = config
    for part in path.split("."):
        if not isinstance(current, Mapping) or part not in current:
            return None
        current = current[part]
    return current


def resolve_ollama_endpoint(
    config: Mapping[str, Any] | None = None,
    env: Mapping[str, str] | None = None,
) -> str:
    """Resolve the Ollama endpoint from config/env/default.

    Precedence:
    1) llm.api_url (user config)
    2) llm.base_url (user config)
    3) OLLAMA_HOST env var
    4) llm.ollama.endpoint (default config)
    5) http://localhost:11434 (hardcoded fallback)

    Args:
        config: Optional config mapping. If None, loads user config.
        env: Optional env mapping (defaults to os.environ).

    Returns:
        Resolved endpoint URL string.
    """
    resolved_env = env if env is not None else os.environ
    resolved_config = load_config() if config is None else config

    # Priority 1: llm.api_url (user config)
    api_url = _get_nested_value(resolved_config, "llm.api_url")
    if isinstance(api_url, str) and api_url.strip():
        return api_url.strip()

    # Priority 2: llm.base_url (user config)
    base_url = _get_nested_value(resolved_config, "llm.base_url")
    if isinstance(base_url, str) and base_url.strip():
        return base_url.strip()

    # Priority 3: OLLAMA_HOST env var
    env_url = resolved_env.get("OLLAMA_HOST")
    if isinstance(env_url, str) and env_url.strip():
        return env_url.strip()

    # Priority 4: llm.ollama.endpoint from default config
    # Priority 5: Hardcoded fallback (within _get_ollama_endpoint_from_config)
    return _get_ollama_endpoint_from_config()


__all__ = ["DEFAULT_OLLAMA_ENDPOINT", "resolve_ollama_endpoint"]
