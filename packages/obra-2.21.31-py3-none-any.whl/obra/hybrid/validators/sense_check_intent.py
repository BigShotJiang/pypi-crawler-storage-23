"""SenseCheck intent response parser."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from obra.api.protocol import ValidatorResult


@dataclass
class IntentSenseCheckResult:
    """Result from intent validation."""

    sound: bool
    constraints: list[str]
    warnings: list[str]
    user_story_warnings: list[str]

    def to_constraints_markdown(self) -> str:
        """Format constraints as markdown for prompt injection."""
        if not self.constraints:
            return ""
        lines = ["## SenseCheck Constraints (Auto-Generated)", ""]
        lines.extend(f"- {constraint}" for constraint in self.constraints)
        return "\n".join(lines)


def _coerce_list(value: Any) -> list[str]:
    if not value:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [str(value).strip()] if str(value).strip() else []


def parse_intent_response(response: str) -> ValidatorResult:
    """Parse SenseCheck intent response into ValidatorResult.

    Args:
        response: Raw LLM response from intent SenseCheck prompt.

    Returns:
        ValidatorResult with constraints and warnings populated.
    """
    if response is None or not response.strip():
        raise ValueError("Intent SenseCheck response was empty")

    stripped = response.strip()
    if stripped.upper() == "SOUND":
        return ValidatorResult(sound=True)

    try:
        data = json.loads(stripped)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Intent SenseCheck response was not valid JSON: {exc!s}") from exc

    if not isinstance(data, dict):
        raise ValueError("Intent SenseCheck JSON response must be an object")

    constraints = _coerce_list(data.get("constraints"))
    warnings = _coerce_list(data.get("warnings"))
    user_story_warnings = _coerce_list(data.get("user_story_warnings"))

    result = IntentSenseCheckResult(
        sound=not constraints,
        constraints=constraints,
        warnings=warnings,
        user_story_warnings=user_story_warnings,
    )

    provenance = {}
    if result.warnings:
        provenance["warnings"] = result.warnings
    if result.user_story_warnings:
        provenance["user_story_warnings"] = result.user_story_warnings

    validator_result = ValidatorResult(
        sound=result.sound,
        constraints=result.constraints,
        provenance=provenance,
    )

    return validator_result
