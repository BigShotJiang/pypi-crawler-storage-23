"""Retention cleanup for scaffolded planning artifacts."""

from __future__ import annotations

from pathlib import Path

from obra.utils.retention import prune_files_by_mtime


def cleanup_retention(
    root: Path,
    *,
    max_files: int,
    protected_paths: set[Path] | None = None,
) -> int:
    """Delete old files under root based on count limits.

    Returns number of files deleted.
    """
    return prune_files_by_mtime(
        root.expanduser(),
        max_files=max_files,
        glob="*",
        recursive=True,
        protected_paths=protected_paths,
    )
