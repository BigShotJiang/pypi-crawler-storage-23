"""slowlane - Python CLI for Apple service automation."""

__version__ = "0.1.0"
