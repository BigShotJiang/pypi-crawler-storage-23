"""Auth module - JWT and session authentication."""
