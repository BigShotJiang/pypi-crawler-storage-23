"""
Entry point for running gravixlayer as a module with python -m gravixlayer
"""

from .cli import main

if __name__ == "__main__":
    main()
