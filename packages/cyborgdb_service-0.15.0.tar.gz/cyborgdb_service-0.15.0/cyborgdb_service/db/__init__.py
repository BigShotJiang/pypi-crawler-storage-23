# cyborgdb_service/db/__init__.py
"""
Database connectivity module.
"""
