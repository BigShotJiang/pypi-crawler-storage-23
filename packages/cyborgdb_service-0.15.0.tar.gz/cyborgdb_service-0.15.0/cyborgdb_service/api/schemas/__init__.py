# cyborgdb_service/api/schemas/__init__.py
"""
Pydantic schemas for request/response validation.
"""
