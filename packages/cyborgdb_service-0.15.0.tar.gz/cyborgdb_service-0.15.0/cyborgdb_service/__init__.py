# cyborgdb_service/__init__.py
"""
CyborgDB API service package.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("cyborgdb-service")
except PackageNotFoundError:
    __version__ = "0.0.0.dev0"

__all__ = ["__version__"]
