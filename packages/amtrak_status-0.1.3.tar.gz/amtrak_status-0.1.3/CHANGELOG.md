# Changelog

## v0.1.3 - 2026-02-21

Re-issue of v0.1.2 with initialized changelog for use in publish action: https://github.com/theFestest/amtrak-status/releases/tag/v0.1.2

### What's Changed

* fix: introduce CHANGELOG.md by @theFestest in https://github.com/theFestest/amtrak-status/pull/4
* fix: create pr rather than pushing to main by @theFestest in https://github.com/theFestest/amtrak-status/pull/5

**Full Changelog**: https://github.com/theFestest/amtrak-status/compare/v0.1.2...v0.1.3

## v0.1.2 - 2026-02-21

- Adjust publish action automation

## v0.1.1 - 2026-02-08

- Bump version to represent very minor cleanup along with tests that capture the initial state of the project
  decently well. Much more significant refactoring to come soon.

## v0.1.0 - 2026-02-08

- Initial Release: Basic functionality established but testing so far as been mostly functional and scenario
  testing during personal use.

Known issues:

- Notifications don't work correctly in connection mode
- Headings on connection view are different
- single script file structure is unwieldy
