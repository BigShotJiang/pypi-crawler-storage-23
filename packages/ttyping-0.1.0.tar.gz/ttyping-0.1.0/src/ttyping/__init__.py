"""ttyping — A minimal terminal typing test."""

__version__ = "0.1.0"
