# Copyright (c) 2024 Roboto Technologies, Inc.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

import argparse
import json
import typing

from ...domain.datasets import Dataset
from ...sentinels import NotSet, is_set, maybe_null, null
from ...updates import MetadataChangeset
from ..command import (
    KeyValuePairsAction,
    RobotoCommand,
)
from ..context import CLIContext
from .shared_helpdoc import DATASET_ID_HELP


def update(args: argparse.Namespace, context: CLIContext, parser: argparse.ArgumentParser) -> None:
    metadata_changeset = MetadataChangeset(
        put_tags=args.put_tags,
        remove_tags=args.remove_tags,
        put_fields=args.put_metadata,
        remove_fields=args.remove_metadata,
    )
    if (
        metadata_changeset.is_empty()
        and not is_set(args.description)
        and not is_set(args.name)
        and not is_set(args.device_id)
    ):
        parser.error("No dataset changes specified.")

    dataset = Dataset.from_id(args.dataset_id, context.roboto_client)

    # Build update kwargs, only including fields that were explicitly set.
    update_kwargs: dict[str, typing.Any] = {
        "metadata_changeset": metadata_changeset,
    }

    if args.description is null:
        update_kwargs["description"] = None
    elif is_set(args.description):
        update_kwargs["description"] = args.description

    if args.name is null:
        update_kwargs["name"] = None
    elif is_set(args.name):
        update_kwargs["name"] = args.name

    if args.device_id is null:
        update_kwargs["device_id"] = None
    elif is_set(args.device_id):
        update_kwargs["device_id"] = args.device_id

    dataset.update(**update_kwargs)

    print(f"Successfully updated dataset '{dataset.dataset_id}'. Record: ")
    print(json.dumps(dataset.to_dict(), indent=2))


def update_parser(parser: argparse.ArgumentParser):
    parser.add_argument("-d", "--dataset-id", type=str, required=True, help=DATASET_ID_HELP)

    parser.add_argument(
        "--description",
        type=maybe_null,
        default=NotSet,
        help="A new description to add to this dataset. Specify ``null`` to clear the description.",
    )

    parser.add_argument(
        "--name",
        type=maybe_null,
        default=NotSet,
        help="A new name for this dataset. Specify ``null`` to clear the name.",
    )

    parser.add_argument(
        "--put-tags",
        help="Add each tag in this sequence if it doesn't exist",
        nargs="*",  # 0 or more
    )

    parser.add_argument(
        "--remove-tags",
        help="Remove each tag in this sequence if it exists",
        nargs="*",  # 0 or more
    )

    parser.add_argument(
        "--put-metadata",
        required=False,
        metavar="KEY_PATH=VALUE",
        nargs="*",
        action=KeyValuePairsAction,
        help=(
            "Zero or more ``<key>=<value>`` formatted pairs. "
            "An attempt is made to parse ``value`` as JSON; if this fails, ``value`` is stored as a string. "
            "If ``key`` already exists, existing value will be overwritten. "
            "Dot notation is supported for nested keys. "
            "Examples: "
            "``--put-metadata 'key1=value1' 'key2.subkey1=value2' 'key3.sublist1=[\"a\",\"b\",\"c\"]'``"  # noqa: E501
        ),
    )

    parser.add_argument(
        "--remove-metadata",
        required=False,
        metavar="KEY_PATH",
        nargs="*",
        help=(
            "Remove each key from dataset metadata if it exists. "
            "Dot notation is supported for nested keys. e.g. ``--remove-metadata key1 key2.subkey3``"
        ),
    )

    parser.add_argument(
        "--device-id",
        type=maybe_null,
        default=NotSet,
        help="Set or update the device ID associated with this dataset. "
        "Specify ``null`` to clear the device association.",
    )


update_command = RobotoCommand(
    name="update",
    logic=update,
    setup_parser=update_parser,
    command_kwargs={"help": "Update metadata or properties of an existing dataset."},
)
