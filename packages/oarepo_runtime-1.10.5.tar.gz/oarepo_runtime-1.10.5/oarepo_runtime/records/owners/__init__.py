from .registry import OwnerEntityResolverRegistry

__all__ = ["OwnerEntityResolverRegistry"]
