from flask_babel import get_locale, gettext, lazy_gettext

__all__ = ("gettext", "lazy_gettext", "get_locale")
