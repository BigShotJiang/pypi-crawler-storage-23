from .links import pagination_links_html

__all__ = ("pagination_links_html",)