__version__ = "0.1.13"
__app_name__ = "devmemory"
