"""Deep test of constants.py: Verify all constants."""
import sys

errors = []

def check(name, condition, detail=""):
    if not condition:
        msg = f"FAIL: {name}"
        if detail:
            msg += f" -- {detail}"
        errors.append(msg)
        print(msg)
    else:
        print(f"  OK: {name}")


print("=" * 60)
print("TEST: constants.py")
print("=" * 60)

from horizon.constants import GAMMA_API_URL, DATA_API_URL, KALSHI_API_URL

check("GAMMA_API_URL is string", isinstance(GAMMA_API_URL, str))
check("GAMMA_API_URL starts with https", GAMMA_API_URL.startswith("https://"), f"got {GAMMA_API_URL}")
check("GAMMA_API_URL correct", GAMMA_API_URL == "https://gamma-api.polymarket.com", f"got {GAMMA_API_URL}")

check("DATA_API_URL is string", isinstance(DATA_API_URL, str))
check("DATA_API_URL starts with https", DATA_API_URL.startswith("https://"), f"got {DATA_API_URL}")
check("DATA_API_URL correct", DATA_API_URL == "https://data-api.polymarket.com", f"got {DATA_API_URL}")

check("KALSHI_API_URL is string", isinstance(KALSHI_API_URL, str))
check("KALSHI_API_URL starts with https", KALSHI_API_URL.startswith("https://"), f"got {KALSHI_API_URL}")
check("KALSHI_API_URL correct", KALSHI_API_URL == "https://api.elections.kalshi.com/trade-api/v2", f"got {KALSHI_API_URL}")

# Verify they are importable from the main horizon namespace indirectly via discovery/strategy
from horizon.discovery import _GAMMA_API_URL, _KALSHI_API_URL
check("discovery uses same GAMMA_API_URL", _GAMMA_API_URL == GAMMA_API_URL)
check("discovery uses same KALSHI_API_URL", _KALSHI_API_URL == KALSHI_API_URL)


print()
print("=" * 60)
print("SUMMARY")
print("=" * 60)
if errors:
    print(f"\n{len(errors)} ERRORS:")
    for e in errors:
        print(f"  {e}")
    sys.exit(1)
else:
    print("\nAll constants.py tests PASSED")
