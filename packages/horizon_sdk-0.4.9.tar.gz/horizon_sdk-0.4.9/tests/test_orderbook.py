"""Tests for L2 OrderbookSnapshot (Rust via PyO3)."""

import pytest
from horizon._horizon import OrderbookSnapshot


class TestOrderbookSnapshotConstruction:
    def test_default_empty(self):
        ob = OrderbookSnapshot()
        assert ob.bids() == []
        assert ob.asks() == []
        assert ob.timestamp == 0.0
        assert ob.source == ""

    def test_with_timestamp_and_source(self):
        ob = OrderbookSnapshot(timestamp=1000.0, source="test")
        assert ob.timestamp == 1000.0
        assert ob.source == "test"

    def test_repr(self):
        ob = OrderbookSnapshot()
        r = repr(ob)
        assert "OrderbookSnapshot" in r


class TestOrderbookSnapshotEmpty:
    def test_spread_empty(self):
        ob = OrderbookSnapshot()
        assert ob.spread() == 0.0

    def test_mid_empty(self):
        ob = OrderbookSnapshot()
        assert ob.mid() == 0.0

    def test_imbalance_empty(self):
        ob = OrderbookSnapshot()
        assert ob.imbalance() == 0.5

    def test_best_bid_none(self):
        ob = OrderbookSnapshot()
        assert ob.best_bid() is None

    def test_best_ask_none(self):
        ob = OrderbookSnapshot()
        assert ob.best_ask() is None

    def test_vwap_mid_empty(self):
        ob = OrderbookSnapshot()
        assert ob.vwap_mid() == 0.0

    def test_bid_depth_empty(self):
        ob = OrderbookSnapshot()
        assert ob.bid_depth() == 0.0

    def test_ask_depth_empty(self):
        ob = OrderbookSnapshot()
        assert ob.ask_depth() == 0.0

    def test_depth_within_empty(self):
        ob = OrderbookSnapshot()
        assert ob.depth_within(0.01) == (0.0, 0.0)

    def test_depth_levels_empty(self):
        ob = OrderbookSnapshot()
        assert ob.bid_depth_levels() == 0
        assert ob.ask_depth_levels() == 0


class TestOrderbookViaEngine:
    """Test orderbook access through Engine (the full path)."""

    def test_orderbook_snapshot_none_without_feed(self):
        from horizon._horizon import Engine
        engine = Engine()
        assert engine.orderbook_snapshot("nonexistent") is None

    def test_all_orderbook_snapshots_empty(self):
        from horizon._horizon import Engine
        engine = Engine()
        result = engine.all_orderbook_snapshots()
        assert isinstance(result, dict)
        assert len(result) == 0
