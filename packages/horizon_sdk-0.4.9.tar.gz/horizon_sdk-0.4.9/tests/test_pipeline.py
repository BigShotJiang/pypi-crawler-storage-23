"""Tests for the Python pipeline composition."""

import pytest

from horizon._horizon import Engine, Market, Quote, RiskConfig
from horizon.context import Context, FeedData, InventorySnapshot
from horizon.strategy import _build_context, _run_pipeline


@pytest.fixture
def engine():
    return Engine(risk_config=RiskConfig())


def test_single_function_pipeline(engine):
    def fair_value(ctx: Context) -> float:
        return 0.55

    ctx = Context()
    result = _run_pipeline([fair_value], ctx)
    assert abs(result - 0.55) < 1e-10


def test_two_function_pipeline(engine):
    def fair_value(ctx: Context) -> float:
        return 0.55

    def quoter(ctx: Context, fair: float) -> list[Quote]:
        return [Quote(bid=fair - 0.02, ask=fair + 0.02, size=5.0)]

    ctx = Context()
    result = _run_pipeline([fair_value, quoter], ctx)
    assert len(result) == 1
    assert abs(result[0].bid - 0.53) < 1e-10
    assert abs(result[0].ask - 0.57) < 1e-10


def test_three_function_pipeline(engine):
    def fair_value(ctx: Context) -> float:
        return 0.50

    def toxicity(ctx: Context) -> float:
        return 0.3

    def quoter(ctx: Context, fair: float, tox: float) -> list[Quote]:
        spread = 0.02 + tox * 0.04
        half = spread / 2
        return [Quote(bid=fair - half, ask=fair + half, size=5.0)]

    ctx = Context()
    result = _run_pipeline([fair_value, toxicity, quoter], ctx)
    assert len(result) == 1
    expected_spread = 0.02 + 0.3 * 0.04
    assert abs(result[0].spread() - expected_spread) < 1e-10


def test_context_has_feeds(engine):
    ctx = _build_context(engine, Market(id="test"), {"btc": None}, {"gamma": 0.1})
    assert "btc" in ctx.feeds
    assert ctx.params["gamma"] == 0.1


def test_context_inventory(engine):
    ctx = _build_context(engine, Market(id="test"), {}, {})
    assert ctx.inventory.net == 0.0
