"""Tests for data fetcher types (import check — actual API calls would need mocking)."""

import pytest
from horizon._horizon import HistoricalTrade, OHLCBar


class TestDataFetcherTypes:
    """Test that data fetcher types are importable and usable."""

    def test_historical_trade_type_exists(self):
        """HistoricalTrade should be importable as a class."""
        assert HistoricalTrade is not None

    def test_ohlc_bar_type_exists(self):
        """OHLCBar should be importable as a class."""
        assert OHLCBar is not None

    def test_fetch_functions_importable(self):
        """Fetch functions should be importable."""
        from horizon._horizon import (
            fetch_polymarket_prices,
            fetch_polymarket_trades,
            fetch_kalshi_book,
        )
        assert callable(fetch_polymarket_prices)
        assert callable(fetch_polymarket_trades)
        assert callable(fetch_kalshi_book)


class TestDataConvenienceWrappers:
    """Test Python convenience wrappers in horizon.data."""

    def test_ohlc_to_ticks(self):
        """ohlc_to_ticks should be importable and callable."""
        from horizon.data import ohlc_to_ticks
        assert callable(ohlc_to_ticks)

    def test_parse_ts_float(self):
        from horizon.data import _parse_ts
        assert _parse_ts(1234567890.0) == 1234567890.0

    def test_parse_ts_string(self):
        from horizon.data import _parse_ts
        ts = _parse_ts("2024-01-01T00:00:00+00:00")
        assert ts > 0
