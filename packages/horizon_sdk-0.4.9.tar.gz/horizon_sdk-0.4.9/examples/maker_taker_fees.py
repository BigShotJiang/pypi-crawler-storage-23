"""Compare flat fees vs maker/taker split fees on the same strategy."""

import horizon as hz
from horizon import Side, OrderSide, OrderRequest


def fair_value(ctx: hz.Context) -> float:
    return ctx.feed.price * 1.01


def quoter(ctx: hz.Context, fair: float):
    if fair > ctx.feed.price + 0.02:
        return OrderRequest(
            market_id=ctx.market_id,
            side=Side.Yes,
            order_side=OrderSide.Buy,
            price=ctx.feed.price,
            size=10.0,
        )


# Sample data
import random
random.seed(42)
price = 0.50
data = []
for i in range(500):
    price += random.gauss(0, 0.01)
    price = max(0.01, min(0.99, price))
    data.append({"timestamp": 1700000000 + i, "price": round(price, 4)})


# --- Flat fee ---
flat_result = hz.backtest(
    name="flat-fee",
    markets=["test"],
    data=data,
    pipeline=[fair_value, quoter],
    paper_fee_rate=0.001,
)

# --- Split maker/taker ---
split_result = hz.backtest(
    name="split-fee",
    markets=["test"],
    data=data,
    pipeline=[fair_value, quoter],
    paper_maker_fee_rate=0.0002,
    paper_taker_fee_rate=0.002,
)

print("=== Flat Fee (10 bps) ===")
print(flat_result.summary())
print(f"Total fees: ${flat_result.metrics.total_fees:.4f}")

print("\n=== Split Fee (2 bps maker / 20 bps taker) ===")
print(split_result.summary())
print(f"Total fees: ${split_result.metrics.total_fees:.4f}")

# Inspect maker/taker breakdown
maker_fills = [f for f in split_result.trades if f.is_maker]
taker_fills = [f for f in split_result.trades if not f.is_maker]
print(f"\nMaker fills: {len(maker_fills)}")
print(f"Taker fills: {len(taker_fills)}")
