"""Pathway Core v0.1 - Learning-aware journey state model."""

__version__ = "0.1.0"
