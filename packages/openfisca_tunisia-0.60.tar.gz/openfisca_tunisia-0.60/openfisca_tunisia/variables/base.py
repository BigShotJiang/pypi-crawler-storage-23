from openfisca_core.model_api import *  # noqa F401
from openfisca_tunisia.entities import FoyerFiscal, Individu, Menage  # noqa F401

AGE_INT_MINIMUM = -9999
