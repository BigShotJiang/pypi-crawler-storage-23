"""Revenus catégoriels."""
