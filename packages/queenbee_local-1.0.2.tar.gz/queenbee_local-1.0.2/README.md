# queenbee-local
Queenbee task provides a helper module for running queenbee recipes on a local machine

## Installation
```console
pip install queenbee-local
```

## QuickStart
```python
import queenbee_local

```
