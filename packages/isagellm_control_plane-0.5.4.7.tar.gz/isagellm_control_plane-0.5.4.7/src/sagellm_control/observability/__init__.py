"""Control-plane observability: scheduling metrics, trace propagation, and Prometheus export.

Provides:
- SchedulingMetrics / ControlPlaneMetricsCollector  – per-request and aggregate scheduling stats
- TraceContext                                       – trace_id / span_id propagation helpers
- ControlPlanePrometheusExporter                    – Prometheus metrics endpoint (optional dep)
- SchedulingSpan                                    – lightweight context-manager span decorator

Quick start::

    from sagellm_control.observability import ControlPlaneMetricsCollector, TraceContext

    collector = ControlPlaneMetricsCollector()
    with TraceContext(trace_id="abc-123", request_id="req-1"):
        collector.record_scheduling_decision(
            request_id="req-1",
            trace_id="abc-123",
            engine_id="eng-0",
            wait_ms=5.2,
            decision_ms=0.8,
            queue_length_at_decision=3,
            success=True,
        )
"""

from __future__ import annotations

from sagellm_control.observability.metrics import (
    ControlPlaneMetricsCollector,
    SchedulingMetrics,
)
from sagellm_control.observability.prometheus import (
    PROMETHEUS_AVAILABLE,
    ControlPlanePrometheusExporter,
)
from sagellm_control.observability.tracing import (
    SchedulingSpan,
    TraceContext,
    get_current_trace_context,
)

__all__ = [
    # Metrics
    "SchedulingMetrics",
    "ControlPlaneMetricsCollector",
    # Tracing
    "TraceContext",
    "SchedulingSpan",
    "get_current_trace_context",
    # Prometheus
    "ControlPlanePrometheusExporter",
    "PROMETHEUS_AVAILABLE",
]
