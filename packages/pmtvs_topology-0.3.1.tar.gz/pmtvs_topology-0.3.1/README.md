# pmtvs-topology

Topological data analysis primitives.

## Functions

- `distance_matrix(points)` - Pairwise distances
- `persistent_homology_0d(points)` - 0D persistence (connected components)
- `betti_numbers(persistence, threshold)` - Count features at threshold
- `persistence_entropy(persistence)` - Entropy of lifetimes
- `persistence_landscape(persistence, k)` - k-th landscape
- `bottleneck_distance(p1, p2)` - Distance between diagrams

## License

PolyForm Strict 1.0.0 with Additional Terms.

- **Students & individual researchers:** Free. Cite us.
- **Funded research labs (grants > $100K):** Academic Research License required. [Contact us](mailto:licensing@pmtvs.dev).
- **Commercial use:** Commercial License required. [Contact us](mailto:licensing@pmtvs.dev).

See [LICENSE](LICENSE) for full terms.
