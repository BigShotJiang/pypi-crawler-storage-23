"""Generic service account config."""

import json

from pydantic import field_validator
from pydantic_settings import BaseSettings


class ServiceAccountConfig(BaseSettings):
    """A class for OIDC settings."""

    type: str = "service_account"
    universe_domain: str = "googleapis.com"
    project_id: str
    private_key_id: str
    private_key: str
    client_email: str
    client_id: str
    auth_uri: str = "https://accounts.google.com/o/oauth2/auth"
    token_uri: str = "https://oauth2.googleapis.com/token"
    auth_provider_x509_cert_url: str = "https://www.googleapis.com/oauth2/v1/certs"

    @field_validator("private_key", mode="before")
    def replace_newlines(cls, value: str) -> str:
        """Convert keys passed as a single line into a multiline string."""
        return value.replace("\\n", "\n")

    @classmethod
    def from_json(cls, json_string: str) -> "ServiceAccountConfig":
        """Create ServiceAccountConfig from a JSON string.

        Args:
            json_string: JSON string containing service account credentials

        Returns:
            ServiceAccountConfig: A new instance parsed from the JSON string

        Raises:
            ValueError: If the JSON string is invalid or missing required fields
        """
        try:
            data = json.loads(json_string)
            return cls(**data)
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse OIDC JSON configuration: Invalid JSON - {e}") from e
        except Exception as e:
            raise ValueError(f"Failed to parse OIDC JSON configuration: {e}") from e
