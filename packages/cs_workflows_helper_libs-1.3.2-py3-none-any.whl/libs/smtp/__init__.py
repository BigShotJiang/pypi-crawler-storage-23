"""SMTP client for sending emails."""
