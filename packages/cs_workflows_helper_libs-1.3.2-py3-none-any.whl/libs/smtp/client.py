"""Client for sending emails through SMTP."""

from email.message import EmailMessage as MIMEEmailMessage
from email.utils import formatdate
import smtplib
from typing import Sequence

from libs.smtp.config import SMTPConfig
from libs.smtp.exceptions import (
    SMTPConfigException,
    SMTPSendException,
)
from libs.smtp.message import EmailMessage as EmailMessageData


class SMTPClient:
    """Client for sending emails through SMTP."""

    def __init__(self, config: SMTPConfig | None = None):
        """Initialize instance of SMTPClient.

        Args:
            config (SMTPConfig | None): SMTP configuration. If None, reads from env.

        Raises:
            SMTPConfigException: If the SMTP configuration is invalid.
        """
        self.config = config or SMTPConfig()

        if not self.config.host:
            raise SMTPConfigException("SMTP host must be configured")

    def send(self, message: EmailMessageData) -> None:
        """Send an email message using the configured SMTP server.

        Args:
            message: Structured email message containing subject, body,
                recipients, and optional metadata.

        Raises:
            SMTPConfigException: If sender or recipients are missing.
            SMTPSendException: If sending the message fails.

        Example:
            msg = EmailMessageData(
                subject="Report ready",
                body="Your report is attached.",
                to=["user@example.com"],
            )
            client.send(msg)
        """
        sender = message.sender or self.config.sender
        if not sender:
            raise SMTPConfigException("Cannot determine sender: provide message.sender or configure SMTPConfig.sender")

        if not message.to:
            raise SMTPConfigException("At least one recipient required")

        if not message.subject:
            raise SMTPConfigException("Email subject required")

        cc_list = list(self.config.cc or []) + list(message.cc)
        bcc_list = list(self.config.bcc or []) + list(message.bcc)
        all_recipients = list(message.to) + cc_list + bcc_list

        email = self._build_message(
            subject=message.subject,
            sender=sender,
            to=message.to,
            cc=cc_list,
            body=message.body,
            footer=message.footer or self.config.footer,
        )

        self._send_message(email, all_recipients)

    def _build_message(
        self,
        *,
        subject: str,
        sender: str,
        to: Sequence[str],
        cc: Sequence[str],
        body: str,
        footer: str | None,
    ) -> MIMEEmailMessage:
        """Construct a MIME email message."""
        msg = MIMEEmailMessage()
        msg["Subject"] = subject
        msg["From"] = sender
        msg["To"] = ", ".join(to)
        msg["Date"] = formatdate()

        if cc:
            msg["Cc"] = ", ".join(cc)

        if footer:
            body = f"{body}\n\n{footer}"

        msg.set_content(body)
        return msg

    def _send_message(self, message: MIMEEmailMessage, recipients: Sequence[str]) -> None:
        """Deliver an email message via SMTP."""
        try:
            with smtplib.SMTP(self.config.host, self.config.port) as smtp:
                if self.config.username and self.config.password:
                    smtp.ehlo()
                    smtp.starttls()
                    smtp.ehlo()
                    smtp.login(self.config.username, self.config.password)
                smtp.send_message(message, to_addrs=recipients)
        except smtplib.SMTPException as exc:
            raise SMTPSendException(f"SMTP error: {exc}") from exc
        except Exception as exc:
            raise SMTPSendException(f"Unexpected error: {exc}") from exc
