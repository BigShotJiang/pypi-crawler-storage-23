"""Configuration for SMTP relay connection."""

from urllib.parse import urlparse

from pydantic import field_validator
from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
)


class SMTPConfig(BaseSettings):
    """Configuration for SMTP relay connection.

    Attributes:
        host (str | None): SMTP server hostname or IP address.
        port (int | None): Port number for the SMTP server (default is 25).
        username (str | None): Username for SMTP authentication.
        password (str | None): Password for SMTP authentication.
        sender (str | None): Default sender email address used in messages.
        cc (list[str] | None): A list of email addresses to include in CC for all emails.
        bcc (list[str] | None): A list of email addresses to include in BCC for all emails.
        footer (str | None): Optional footer text to append to all email messages.
    """

    host: str | None = None
    port: int | None = 25
    username: str | None = None
    password: str | None = None
    sender: str | None = None
    cc: list[str] | None = None
    bcc: list[str] | None = None
    footer: str | None = None

    model_config = SettingsConfigDict(env_prefix="SMTP_")

    @field_validator("host")
    @classmethod
    def validate_host(cls, value: str | None):
        """Validate and normalize the SMTP host.

        Args:
            value: The raw host string from configuration.

        Returns:
            The validated hostname or None if not set.

        Raises:
            ValueError: If host includes a scheme but no hostname.
        """
        if value is None:
            return value

        parsed = urlparse(value)

        if parsed.scheme:
            if parsed.hostname:
                return parsed.hostname

            raise ValueError("SMTP host must be a hostname only (e.g. smtp.example.com)")

        return value
