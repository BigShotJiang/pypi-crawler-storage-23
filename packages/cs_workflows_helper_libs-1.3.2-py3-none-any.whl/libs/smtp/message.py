"""Message data class."""

from dataclasses import (
    dataclass,
    field,
)
from typing import Sequence


@dataclass(slots=True)
class EmailMessage:
    """
    Represents an email message to be sent via an SMTP client.

    Attributes:
        subject:
            Subject line of the email.
        body:
            Plain text body content of the email.
        to:
            Primary recipient email addresses.
        sender:
            Optional sender address. If not provided, the SMTP client's
                configured default sender will be used.
        cc:
            Carbon copy recipient email addresses.
        bcc:
            Blind carbon copy recipient email addresses.
        footer:
            Optional footer text appended to the email body. If not provided,
                the SMTP client's configured default footer may be used.

    Notes:
        - This class uses slots=True to reduce memory usage and prevent
          dynamic attribute creation.
        - Instances are intended to be immutable in structure, though
          field values remain mutable unless externally constrained.
    """

    subject: str
    body: str
    to: Sequence[str]

    sender: str | None = None
    cc: Sequence[str] = field(default_factory=list)
    bcc: Sequence[str] = field(default_factory=list)
    footer: str | None = None
