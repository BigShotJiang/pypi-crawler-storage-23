"""Exceptions for SMTP operations."""


class SMTPException(Exception):
    """Exception for an error with the SMTP client."""

    retryable: bool = True


class SMTPConfigException(SMTPException):
    """Exception for a misconfigured SMTP client."""

    retryable = False


class SMTPSendException(SMTPException):
    """Exception for an error sending an email."""
