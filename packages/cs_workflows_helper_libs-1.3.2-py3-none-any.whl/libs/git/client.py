"""Wrapper for git operations."""

import os
from pathlib import Path
import tempfile
from urllib.parse import urlparse

from git import Repo
from git.exc import GitCommandError

from libs.common.validators import http_validator
from libs.git.config import GitConfig
from libs.git.exceptions import (
    GitConfigException,
    GitException,
)


class GitClient:
    """Wrapper for git operations.

    Attributes:
        branch (str): Branch to clone
        url (str): URL to the repository
        dir (Path): Path to the temporary directory where the repository is cloned
    """

    config: GitConfig
    remote: bool = True
    branch: str
    url: str
    dir: Path

    def __init__(self, config: GitConfig | None = None):
        """Initialize the Git class.

        Checks URL validity and creates a temporary directory.

        Parameters:
            config (GitConfig): Git configuration. If None, the Git configuration is read from the environment variables.

        Raises:
            GitConfigException: If the Git configuration is invalid.
            GitException: If there is an error with the Git client.
        """
        if config is None:
            config = GitConfig()
        self.config = config

        if not self.config.url:
            raise GitConfigException("URL is required.")

        self.remote = self._is_remote()
        self.branch = self.config.branch

        if self.remote:
            self._configure_remote()
        else:
            self._configure_local()

    def _is_remote(self) -> bool:
        """Check if the repository is a remote repository.

        Returns:
            True if the repository is a remote repository, False otherwise.
        """
        try:
            http_validator(self.config.url)
        except ValueError:
            return False

        return True

    def _configure_remote(self):
        """Configure the Git client for a remote repository.

        Raises:
            GitConfigException: If the Git configuration is invalid.
        """
        self._configure_url()

        if not self.config.path:
            self.dir: Path = Path(tempfile.mkdtemp())
            return

        self.dir = Path(self.config.path)
        if not self.dir.exists():
            try:
                os.makedirs(self.dir)
            except OSError as e:
                raise GitConfigException(f"Failed to create directory {self.dir}.") from e

    def _configure_local(self):
        """Configure the Git client for a local repository.

        Raises:
            GitConfigException: If the Git configuration is invalid.
        """
        self.url = self.config.url
        self.dir: Path = Path(self.config.url)

        if not self.dir.exists():
            raise GitConfigException(
                f"Directory {self.config.url} does not exist. " "Please provide an absolute path to a valid directory."
            )

    def _configure_url(self):
        """Configure the Git client for a remote repository.

        If credentials are provided, they are added to the URL.
        """
        self.url = self.config.url

        if self.config.token is not None and self.config.user is not None:
            # Add credentials to URL
            parsed_url = urlparse(self.url)
            base_url = parsed_url.netloc + parsed_url.path
            scheme = parsed_url.scheme
            self.url = f"{scheme}://{self.config.user}:{self.config.token}@{base_url}"  # noqa: E231

    def _exists(self) -> bool:
        """Check if the repository exists and is not empty."""
        exists = self.dir.exists()
        is_empty = len(list(self.dir.glob("**/*"))) == 0
        return exists and not is_empty

    def clone(self):
        """Clone the repository.

        Raises:
            GitException: If the repository is invalid or git clone fails.
        """
        if not self.remote:
            # Local repositories can't be cloned
            return

        # Specify options to clone a single branch
        options = [f"--branch {self.branch}", "--single-branch"]

        http_proxy = os.environ.get("HTTP_PROXY")
        if http_proxy:
            options.append(f'--config "http.proxy={http_proxy}"')
        https_proxy = os.environ.get("HTTPS_PROXY")
        if https_proxy:
            options.append(f'--config "https.proxy={https_proxy}"')

        try:
            Repo.clone_from(
                self.url,
                to_path=self.dir,
                multi_options=options,
                allow_unsafe_options=True,  # Required to use --config
            )
        except GitCommandError as e:
            raise GitException(f"git clone failed: {e}") from e

        # Check if the cloned directory exists and is not empty
        if not self._exists():
            raise GitException("Failed to clone: directory does not exist or is empty")
