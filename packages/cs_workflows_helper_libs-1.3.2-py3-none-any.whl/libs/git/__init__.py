"""Git module."""
