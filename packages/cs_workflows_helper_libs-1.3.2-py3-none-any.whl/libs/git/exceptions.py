"""Exceptions for Git operations."""


class GitException(Exception):
    """Used to indicate that there was an error with the Git client."""

    retryable: bool = True


class GitConfigException(GitException):
    """Used to indicate that the Git client is misconfigured."""

    def __init__(self, message: str):
        """Initialize the exception with retryable=False."""
        super().__init__(message)
        self.message = message
        self.retryable = False
