"""Configuration for the Git client."""

from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
)


class GitConfig(BaseSettings):
    """Configuration for the Git client.

    If 'url' refers to a remote repository, it will be cloned to the 'path' directory or
    into a temporary directory.
    If 'url' refers to a local directory, it will be used as the repository.

    Attributes:
        url: URL to repository. Must be in HTTPS scheme for remote repositories.
             For local repositories, the path must be an absolute path to a valid directory.
        path: Path to the cloned repository;
              if not provided, a temporary directory is created.
        branch: Branch to use, defaults to 'main'.
        user: Username for authentication. Not required for public repositories.
        token: Personal access token. Not required for public repositories.
    """

    url: str
    path: str | None = None
    branch: str = "main"
    user: str | None = None
    token: str | None = None

    model_config = SettingsConfigDict(env_prefix="GIT_")
