"""Common functions and classes used across modules."""
