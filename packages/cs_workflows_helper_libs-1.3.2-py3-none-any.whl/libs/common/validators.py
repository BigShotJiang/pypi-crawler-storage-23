"""Common validators for pydantic models."""

from urllib.parse import urlparse


def http_validator(url: str | None) -> str | None:
    """Validate that the URL is a valid HTTP(S) URL (or None).

    Prefer HTTPS when possible.
    HTTP is allowed for local deployments and testing.
    """
    if url is None:
        return url

    parsed_url = urlparse(url)
    if parsed_url.scheme in ("http", "https"):
        return url
    raise ValueError(f"URL {url} is not a valid HTTP(S) URL")
