"""Trino config."""

from typing import Optional

from pydantic import model_validator
from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
)

from libs.service_account.config import ServiceAccountConfig


class TrinoConfig(BaseSettings):
    """A class for Trino related settings."""

    url: str
    port: int = 443
    http_scheme: str = "https"
    oidc: Optional[ServiceAccountConfig] = None
    oidc_json: Optional[str] = None

    model_config = SettingsConfigDict(
        env_prefix="TRINO_",
        env_nested_delimiter="__",
    )

    @model_validator(mode="after")
    def validate_oidc(self) -> "TrinoConfig":
        """Validate OIDC configuration from either nested fields or JSON string.

        If oidc_json is provided, it takes precedence over nested OIDC fields.
        """
        if self.oidc_json:
            # Parse JSON and create ServiceAccountConfig
            self.oidc = ServiceAccountConfig.from_json(self.oidc_json)

        if not self.oidc:
            raise ValueError(
                "OIDC configuration must be provided via either TRINO_OIDC_JSON "
                "or individual TRINO_OIDC__* environment variables"
            )

        return self
