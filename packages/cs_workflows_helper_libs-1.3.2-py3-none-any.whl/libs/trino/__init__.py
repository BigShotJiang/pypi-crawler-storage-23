"""Trino library."""
