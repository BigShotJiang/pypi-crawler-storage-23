"""Client for Mattermost API v4 calls."""

from pathlib import Path

import requests
from requests.exceptions import RequestException

from libs.mattermost.config import (
    MattermostConfig,
    MattermostMessagePayload,
)
from libs.mattermost.exceptions import (
    MattermostConfigException,
    MattermostContentException,
    MattermostException,
)


class MattermostClient:
    """Client for Mattermost API v4 calls."""

    def __init__(self, config: MattermostConfig) -> None:
        """Initialize the wrapper.

        Arguments:
            config: Mattermost config.
        """
        self.config = config
        self.url = f"{self.config.url}/api/v4"

    def upload_file(self, file: Path) -> str:
        """Upload a file via the Mattermost API.

        Docs: https://developers.mattermost.com/api-documentation/#/operations/UploadFile

        Arguments:
            file (Path): Path to the file to be uploaded.

        Returns:
            str: File ID of the uploaded file.

        Raises:
            FileNotFoundError: If the file does not exist.
            MattermostException: If the file upload fails.
            MattermostConfigException: If the Mattermost configuration is missing or invalid.
        """
        if not self.config.is_configured():
            raise MattermostConfigException("Mattermost integration is not configured.")

        if not file.exists():
            raise FileNotFoundError(f"File '{file.name}' does not exist")

        with open(file, "rb") as f:
            files = {
                "files": (file.name, f),
            }

            upload_url = f"{self.url}/files"
            headers = {
                "Authorization": f"Bearer {self.config.token}",
                "Accept": "application/json",
            }
            params = {
                "channel_id": self.config.channel,
                "filename": file.name,
            }

            # This call needs to be within the `with` block to ensure the file pointer is still open
            try:
                response = requests.post(
                    upload_url,
                    headers=headers,
                    params=params,
                    files=files,
                    timeout=60,
                )
                response.raise_for_status()
            except RequestException as e:
                raise MattermostException(f"File '{file.name}' upload failed: {e}") from e

        try:
            file_id = response.json()["file_infos"][0]["id"]
        except KeyError as e:
            raise MattermostException(f"File '{file.name}' upload failed: no file ID") from e

        return file_id

    def send_message(self, payload: MattermostMessagePayload) -> None:
        """Send a message with an attached file to the channel indicated in the config.

        Docs: https://developers.mattermost.com/api-documentation/#/operations/CreatePost

        Arguments:
            payload (MattermostMessagePayload): Message to be sent with optional file
                attachment ID.
        """
        if not self.config.is_configured():
            raise MattermostConfigException("Mattermost integration is not configured.")

        if not payload.message:
            raise MattermostContentException("Message cannot be empty")

        url = f"{self.url}/posts"
        headers = {"Authorization": "Bearer " + self.config.token, "Content-Type": "application/json"}
        file_ids = [payload.file_id] if payload.file_id else []
        data = {
            "channel_id": self.config.channel,
            "file_ids": file_ids,
            "message": payload.message,
        }

        try:
            response = requests.post(url, headers=headers, json=data, timeout=60)
            response.raise_for_status()
        except RequestException as e:
            raise MattermostException("Failed to send message to Mattermost") from e
