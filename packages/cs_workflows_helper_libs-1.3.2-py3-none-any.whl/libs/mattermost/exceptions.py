"""Exceptions for Mattermost integration."""


class MattermostException(Exception):
    """Exception for Mattermost integration."""

    retryable = True


class MattermostConfigException(Exception):
    """Exception for missing/invalid Mattermost configuration."""

    retryable = False


class MattermostContentException(Exception):
    """Exception for missing/invalid Mattermost payload."""

    retryable = False
