"""Configuration for Mattermost integration."""

from dataclasses import dataclass
from typing import Annotated

from pydantic import AfterValidator
from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
)

from libs.common.validators import http_validator


class MattermostConfig(BaseSettings):
    """Configuration for Mattermost access.

    Attributes:
        channel (str): Name of the channel on which to post messages.
        url (str): Base URL of the Mattermost server.
        token (str): Token for Mattermost API access.
    """

    channel: str | None = None
    url: Annotated[str | None, AfterValidator(http_validator)] = None
    token: str | None = None

    model_config = SettingsConfigDict(env_prefix="MATTERMOST_")

    def is_configured(self) -> bool:
        """Check if all required configuration attributes are set.

        Mattermost integration is optional, so if one value is missing
        we skip the integration instead of throwing an error.
        """
        return all([self.url, self.token, self.channel])


@dataclass
class MattermostMessagePayload:
    """Payload for a message to be sent to Mattermost.

    Attributes:
        message (str): Message to be sent.
        file_id (str): ID of the file to be attached to the message.
    """

    message: str
    file_id: str | None = None
