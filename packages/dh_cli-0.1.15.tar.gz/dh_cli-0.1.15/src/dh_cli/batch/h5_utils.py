"""H5 embedding file utilities for batch job finalization.

These functions combine, deduplicate, and optimize H5 embedding files
produced by embed-t5 batch jobs. They require h5py and numpy at runtime;
if those aren't installed, finalize will prompt the user to install them.

Adapted from dayhoff_tools.h5 (self-contained, no dayhoff_tools dependency).
"""

import os
import re
from pathlib import Path

import h5py
import numpy as np


def combine_h5_files(
    input_files: str | list[str], output_file: str, chunk_size: int = 10000
) -> None:
    """Combine several .h5 embedding files into one.

    Assumes files have two datasets: `ids` (variable-length strings)
    and `vectors` (float32 matrix).

    Args:
        input_files: Directory path or list of H5 file paths.
        output_file: Path for the combined output file.
        chunk_size: Number of rows to process at a time.

    Raises:
        FileExistsError: If the output file already exists.
    """
    if os.path.exists(output_file):
        raise FileExistsError(f"Output file '{output_file}' already exists.")

    files = _get_sorted_h5_files(input_files)

    # First pass: calculate total size and determine vector dimension
    total_rows = 0
    vector_dim = None
    for file_path in files:
        with h5py.File(file_path, "r") as h5_in:
            total_rows += h5_in["ids"].shape[0]
            if vector_dim is None:
                vector_dim = h5_in["vectors"].shape[1]

    with h5py.File(output_file, "w") as h5_out:
        id_dataset = h5_out.create_dataset(
            "ids",
            shape=(total_rows,),
            dtype=h5py.special_dtype(vlen=str),
            chunks=True,
        )
        vector_dataset = h5_out.create_dataset(
            "vectors",
            shape=(total_rows, vector_dim),
            dtype=np.float32,
            chunks=True,
        )

        current_index = 0
        for file_path in files:
            with h5py.File(file_path, "r") as h5_in:
                file_size = h5_in["ids"].shape[0]

                for i in range(0, file_size, chunk_size):
                    end = min(i + chunk_size, file_size)
                    n = end - i

                    ids = h5_in["ids"][i:end]
                    id_dataset[current_index : current_index + n] = [
                        id_val.decode("utf-8") for id_val in ids
                    ]

                    vector_dataset[current_index : current_index + n] = (
                        h5_in["vectors"][i:end]
                    )

                    current_index += n


def deduplicate_h5_file(
    input_filename: str, output_filename: str, chunk_size: int = 10000
) -> int:
    """Create a deduplicated version of an H5 embedding file.

    Keeps the first occurrence of each ID.

    Args:
        input_filename: Path to input H5 file.
        output_filename: Path for deduplicated output.
        chunk_size: Number of entries to process at a time.

    Returns:
        Number of duplicates removed.

    Raises:
        FileExistsError: If the output file already exists.
    """
    if os.path.exists(output_filename):
        raise FileExistsError(f"Output file '{output_filename}' already exists.")

    with (
        h5py.File(input_filename, "r") as input_file,
        h5py.File(output_filename, "w") as output_file,
    ):
        ids_dataset = input_file["ids"]
        vectors_dataset = input_file["vectors"]
        total_entries = ids_dataset.shape[0]

        output_ids = output_file.create_dataset(
            "ids", shape=(0,), dtype=ids_dataset.dtype, maxshape=(None,), chunks=True
        )
        output_vectors = output_file.create_dataset(
            "vectors",
            shape=(0, vectors_dataset.shape[1]),
            dtype=vectors_dataset.dtype,
            maxshape=(None, vectors_dataset.shape[1]),
            chunks=True,
        )

        unique_ids = {}

        for start_idx in range(0, total_entries, chunk_size):
            end_idx = min(start_idx + chunk_size, total_entries)

            chunk_ids = ids_dataset[start_idx:end_idx]
            chunk_vectors = vectors_dataset[start_idx:end_idx]

            for i, id_value in enumerate(chunk_ids):
                id_str = id_value.decode("utf-8")
                if id_str not in unique_ids:
                    unique_ids[id_str] = len(unique_ids)

            new_size = len(unique_ids)
            output_ids.resize((new_size,))
            output_vectors.resize((new_size, vectors_dataset.shape[1]))

            for i, id_value in enumerate(chunk_ids):
                id_str = id_value.decode("utf-8")
                index = unique_ids[id_str]
                output_ids[index] = id_value
                output_vectors[index] = chunk_vectors[i]

    duplicates_removed = total_entries - len(unique_ids)
    return duplicates_removed


def optimize_protein_embedding_chunks(
    src_path: str | Path, dst_path: str | Path, train_batch_size: int = 16384
) -> None:
    """Create a new H5 file with chunking optimized for training access patterns.

    Rechunks the vectors dataset so that each HDF5 chunk aligns with the
    training batch size, minimizing disk reads during sequential access.

    Args:
        src_path: Source H5 file path.
        dst_path: Destination H5 file path.
        train_batch_size: Batch size used during training.

    Raises:
        FileExistsError: If the destination file already exists.
        KeyError: If required datasets are missing.
        ValueError: If the input file contains empty datasets.
    """
    src_path = Path(src_path)
    dst_path = Path(dst_path)

    if dst_path.exists():
        raise FileExistsError(f"Output file '{dst_path}' already exists")

    with h5py.File(src_path, "r") as src, h5py.File(dst_path, "w") as dst:
        if "ids" not in src or "vectors" not in src:
            raise KeyError("Input file must contain 'ids' and 'vectors' datasets")

        total_vectors = src["vectors"].shape[0]
        if total_vectors == 0:
            raise ValueError("Input file contains empty datasets")

        chunk_size = min(total_vectors, train_batch_size)

        dst.create_dataset(
            "ids",
            data=src["ids"][:],
            chunks=(chunk_size,),
            dtype=h5py.special_dtype(vlen=str),
        )

        vectors_shape = src["vectors"].shape
        dst.create_dataset(
            "vectors",
            shape=vectors_shape,
            chunks=(chunk_size, vectors_shape[1]),
            dtype=np.float32,
        )

        for i in range(0, total_vectors, chunk_size):
            end_idx = min(i + chunk_size, total_vectors)
            dst["vectors"][i:end_idx] = src["vectors"][i:end_idx].astype(np.float32)


def _get_sorted_h5_files(input_files: str | list[str]) -> list[str]:
    """Resolve and sort H5 file paths by numeric suffix."""
    if isinstance(input_files, str):
        if os.path.isdir(input_files):
            files = [
                os.path.join(input_files, f)
                for f in os.listdir(input_files)
                if f.endswith(".h5")
            ]
        else:
            raise ValueError("If a string is provided, it must be a directory path.")
    elif isinstance(input_files, list):
        files = input_files
    else:
        raise TypeError("input_files must be a string (directory) or list of paths.")

    return sorted(
        files,
        key=lambda x: (
            int(m.group(1)) if (m := re.search(r"_(\d+)\.h5$", x)) else float("inf")
        ),
    )
