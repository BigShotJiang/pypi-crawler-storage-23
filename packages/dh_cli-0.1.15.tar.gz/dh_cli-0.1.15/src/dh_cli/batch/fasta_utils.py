"""Lightweight FASTA utilities for batch job submission.

These avoid depending on dayhoff_tools, so dh-cli can run standalone.
"""

from pathlib import Path


def split_fasta(
    input_path: Path,
    output_dir: Path,
    base_name: str,
    seqs_per_chunk: int,
    max_chunks: int | None = None,
) -> int:
    """Split a FASTA file into zero-padded chunks.

    Creates files named {base_name}_000.fasta, {base_name}_001.fasta, etc.

    Args:
        input_path: Path to input FASTA file
        output_dir: Directory for output chunks
        base_name: Prefix for chunk filenames
        seqs_per_chunk: Maximum sequences per output file
        max_chunks: Maximum number of chunks to create (None = unlimited)

    Returns:
        Number of chunks created
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    file_idx = 0
    seq_count = 0
    output_file = None

    try:
        with open(input_path) as fasta:
            for line in fasta:
                if line.startswith(">"):
                    # Start a new chunk if we've hit the per-chunk limit
                    if output_file is not None and seq_count >= seqs_per_chunk:
                        output_file.close()
                        output_file = None
                        file_idx += 1
                        seq_count = 0

                        # Stop if we've hit the max chunks limit
                        if max_chunks is not None and file_idx >= max_chunks:
                            break

                    # Open first file or new chunk
                    if output_file is None:
                        chunk_path = output_dir / f"{base_name}_{file_idx:03d}.fasta"
                        output_file = open(chunk_path, "w")

                    seq_count += 1

                if output_file is not None:
                    output_file.write(line)
    finally:
        if output_file is not None:
            output_file.close()

    return file_idx + 1 if seq_count > 0 else file_idx
