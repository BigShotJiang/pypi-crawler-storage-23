"""srdedupe.cli module.

Command-line interface for srdedupe deduplication pipeline.
"""

from srdedupe.cli.main import cli

__all__ = ["cli"]
