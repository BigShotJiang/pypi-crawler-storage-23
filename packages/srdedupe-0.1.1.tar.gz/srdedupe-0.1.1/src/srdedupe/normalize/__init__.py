"""Field normalization for canonical records."""

from srdedupe.normalize.normalizer import normalize

__all__ = ["normalize"]
