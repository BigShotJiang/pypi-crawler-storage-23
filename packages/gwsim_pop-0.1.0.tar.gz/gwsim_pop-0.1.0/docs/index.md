# gwsim_pop

A Python package for simulating populations of gravitational wave sources.

## Next Steps

- [Installation](user_guide/installation.md) - Detailed installation
  instructions
- [User Guide](user_guide/quick_start.md) - Guides to use this package
- [API Reference](reference/index.md) - Detailed API documentation
- [Developer Guide](CONTRIBUTING.md) - How to contribute to the project
- [Troubleshooting](dev/troubleshooting.md) - Identify and resolve common
  problems
