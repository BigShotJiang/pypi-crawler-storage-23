# Quick Start

Welcome to **gwsim_pop**! This is a Python package for simulating populations of
gravitational-wave sources.

## Next Steps

- [Request New Features](../CONTRIBUTING.md) - How to request new features or
  improvements.
- [API Reference](../reference/index.md) - Programmatic usage documentation.
