"""Unit tests for the core module."""
