"""Unit tests for gwsim_pop.config."""
