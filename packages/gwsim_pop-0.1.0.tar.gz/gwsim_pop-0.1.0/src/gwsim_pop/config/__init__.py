"""Module for configuration files."""

from __future__ import annotations

from gwsim_pop.config.main import MainConfiguration

__all__ = ["MainConfiguration"]
