"""Module of the core functions."""
