"""Top-level package for gwsim_pop."""

from __future__ import annotations

from gwsim_pop.version import __version__

__all__ = ["__version__"]
