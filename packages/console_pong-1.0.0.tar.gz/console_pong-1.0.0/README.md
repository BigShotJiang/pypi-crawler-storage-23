Hi! This is CheezeDev. 

This is a very cool, playable Ping Pong game, which has trail effects, CPUs, etc!

No need for dependencies.

To insall, you can use pip install console-pong.
