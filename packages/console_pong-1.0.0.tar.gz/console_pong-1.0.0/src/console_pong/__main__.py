from console_pong import main

main()
