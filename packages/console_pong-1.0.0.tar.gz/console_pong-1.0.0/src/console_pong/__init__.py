from .game import PongGame


def main():
    game = PongGame()
    game.run()
