## SMTConfig

Configuration validation and completion using z3 solver.

### Installation

```
pip install smtconfig
```

### Example

[see here](https://gitlab.com/knvvv/smtconfig/-/blob/master/example.py)
