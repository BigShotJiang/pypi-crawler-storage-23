"""
EngramPort Python client — sync and async.

Usage::

    from engramport_langchain import EngramPortMemory

    memory = EngramPortMemory(api_key="ek_bot_...")
    memory.remember("User lives in Tampa, FL")
    results = memory.recall("Where does the user live?")
"""

from __future__ import annotations

from typing import Optional, List

import httpx

from engramport_langchain.models import (
    RememberResponse,
    RecallMemory,
    RecallResponse,
    InsightItem,
    ReflectResponse,
    StatsResponse,
)

DEFAULT_BASE_URL = "https://mandeldb.com/api/v1/portal"
DEFAULT_TIMEOUT = 30.0


class EngramPortMemory:
    """Persistent memory client for AI bots and agents.

    Args:
        api_key: Your bot API key (starts with ``ek_bot_``).
        base_url: EngramPort API base URL. Override for self-hosted instances.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        if not api_key or not api_key.startswith("ek_bot_"):
            raise ValueError("api_key must start with 'ek_bot_'")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

    # ── Internal helpers ──────────────────────────────────────────────────

    @property
    def _headers(self) -> dict:
        return {
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
        }

    def _url(self, path: str) -> str:
        return f"{self._base_url}/{path.lstrip('/')}"

    def _handle_response(self, resp: httpx.Response) -> dict:
        if resp.status_code == 401:
            raise PermissionError(f"Invalid or expired API key: {resp.text}")
        if resp.status_code == 403:
            raise PermissionError(f"Namespace access denied: {resp.text}")
        resp.raise_for_status()
        return resp.json()

    # ── Sync API ──────────────────────────────────────────────────────────

    def remember(
        self,
        content: str,
        context: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> RememberResponse:
        """Store a memory.

        Args:
            content: The memory text to store.
            context: Optional surrounding context.
            session_id: Optional session grouping ID.

        Returns:
            RememberResponse with memory_id, namespace, stored_at, node_type.
        """
        payload: dict = {"content": content}
        if context is not None:
            payload["context"] = context
        if session_id is not None:
            payload["session_id"] = session_id

        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                self._url("remember"),
                headers=self._headers,
                json=payload,
            )
        return RememberResponse(**self._handle_response(resp))

    def recall(
        self,
        query: str,
        limit: int = 5,
    ) -> RecallResponse:
        """Semantic search across stored memories.

        Args:
            query: Natural language search query.
            limit: Max results (1-50, default 5).

        Returns:
            RecallResponse with memories list, namespace, and query echo.
        """
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                self._url("recall"),
                headers=self._headers,
                json={"query": query, "limit": limit},
            )
        return RecallResponse(**self._handle_response(resp))

    def reflect(
        self,
        topic: Optional[str] = None,
    ) -> ReflectResponse:
        """Synthesize insights from stored memories.

        Args:
            topic: Optional topic to focus the synthesis on.

        Returns:
            ReflectResponse with insights list and synthesis_cost_usd.
        """
        payload: dict = {}
        if topic is not None:
            payload["topic"] = topic

        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(
                self._url("reflect"),
                headers=self._headers,
                json=payload,
            )
        return ReflectResponse(**self._handle_response(resp))

    def stats(self) -> StatsResponse:
        """Get memory statistics for this bot.

        Returns:
            StatsResponse with memory_count, insight_count, days_active.
        """
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.get(
                self._url("stats"),
                headers=self._headers,
            )
        return StatsResponse(**self._handle_response(resp))

    # ── Async API ─────────────────────────────────────────────────────────

    async def aremember(
        self,
        content: str,
        context: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> RememberResponse:
        """Async version of :meth:`remember`."""
        payload: dict = {"content": content}
        if context is not None:
            payload["context"] = context
        if session_id is not None:
            payload["session_id"] = session_id

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                self._url("remember"),
                headers=self._headers,
                json=payload,
            )
        return RememberResponse(**self._handle_response(resp))

    async def arecall(
        self,
        query: str,
        limit: int = 5,
    ) -> RecallResponse:
        """Async version of :meth:`recall`."""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                self._url("recall"),
                headers=self._headers,
                json={"query": query, "limit": limit},
            )
        return RecallResponse(**self._handle_response(resp))

    async def areflect(
        self,
        topic: Optional[str] = None,
    ) -> ReflectResponse:
        """Async version of :meth:`reflect`."""
        payload: dict = {}
        if topic is not None:
            payload["topic"] = topic

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                self._url("reflect"),
                headers=self._headers,
                json=payload,
            )
        return ReflectResponse(**self._handle_response(resp))

    async def astats(self) -> StatsResponse:
        """Async version of :meth:`stats`."""
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.get(
                self._url("stats"),
                headers=self._headers,
            )
        return StatsResponse(**self._handle_response(resp))

    # ── Convenience ───────────────────────────────────────────────────────

    def __repr__(self) -> str:
        masked = self._api_key[:12] + "..." + self._api_key[-4:]
        return f"EngramPortMemory(api_key='{masked}', base_url='{self._base_url}')"
