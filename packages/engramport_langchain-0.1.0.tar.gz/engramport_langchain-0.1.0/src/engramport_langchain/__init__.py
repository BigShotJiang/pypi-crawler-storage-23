"""
EngramPort LangChain Integration
=================================

Persistent memory for AI bots and agents, powered by MandelDB.

Quick start::

    from engramport_langchain import EngramPortMemory

    memory = EngramPortMemory(api_key="ek_bot_...")

    # Store a memory
    memory.remember("User prefers dark mode")

    # Semantic recall
    results = memory.recall("What are the user's preferences?")

    # Synthesize insights
    insights = memory.reflect(topic="user behavior")

    # Check stats
    stats = memory.stats()
"""

from engramport_langchain.client import EngramPortMemory
from engramport_langchain.models import (
    RememberResponse,
    RecallMemory,
    RecallResponse,
    InsightItem,
    ReflectResponse,
    StatsResponse,
)

__version__ = "0.1.0"
__all__ = [
    "EngramPortMemory",
    "RememberResponse",
    "RecallMemory",
    "RecallResponse",
    "InsightItem",
    "ReflectResponse",
    "StatsResponse",
]
