"""Pydantic models matching the EngramPort API contract."""

from typing import List, Optional

from pydantic import BaseModel, Field


# ── Remember ──────────────────────────────────────────────────────────────

class RememberResponse(BaseModel):
    memory_id: str
    namespace: str
    stored_at: str
    node_type: str


# ── Recall ────────────────────────────────────────────────────────────────

class RecallMemory(BaseModel):
    id: str
    content: Optional[str] = None
    relevance_score: float
    created_at: Optional[str] = None


class RecallResponse(BaseModel):
    memories: List[RecallMemory]
    namespace: str
    query: str


# ── Reflect ───────────────────────────────────────────────────────────────

class InsightItem(BaseModel):
    content: str
    confidence: float
    source_memory_count: int


class ReflectResponse(BaseModel):
    insights: List[InsightItem]
    synthesis_cost_usd: float


# ── Stats ─────────────────────────────────────────────────────────────────

class StatsResponse(BaseModel):
    memory_count: int
    insight_count: int
    days_active: int
    last_activity: Optional[str] = None
