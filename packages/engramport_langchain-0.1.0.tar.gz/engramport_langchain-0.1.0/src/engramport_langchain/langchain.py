"""
LangChain BaseMemory integration for EngramPort.

Requires the ``langchain`` extra::

    pip install engramport-langchain[langchain]

Usage with LangChain::

    from engramport_langchain.langchain import EngramPortChatMemory
    from langchain.chains import ConversationChain
    from langchain_openai import ChatOpenAI

    memory = EngramPortChatMemory(api_key="ek_bot_...")
    chain = ConversationChain(llm=ChatOpenAI(), memory=memory)
    chain.invoke({"input": "I live in Tampa, FL"})
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

try:
    from langchain_core.memory import BaseMemory
except ImportError:
    raise ImportError(
        "LangChain integration requires langchain-core. "
        "Install with: pip install engramport-langchain[langchain]"
    )

from engramport_langchain.client import EngramPortMemory


class EngramPortChatMemory(BaseMemory):
    """LangChain memory backed by EngramPort.

    Stores each human/AI message pair as a memory, and recalls relevant
    context before every turn.

    Args:
        api_key: Bot API key (``ek_bot_*``).
        base_url: Override for self-hosted instances.
        memory_key: Key used in the chain's prompt variables.
        recall_limit: Max memories to recall per turn.
        auto_reflect: If True, trigger insight synthesis every N interactions.
        reflect_interval: Number of interactions between auto-reflects.
    """

    api_key: str
    base_url: str = "https://mandeldb.com/api/v1/portal"
    memory_key: str = "history"
    input_key: str = "input"
    output_key: str = "output"
    recall_limit: int = 5
    auto_reflect: bool = False
    reflect_interval: int = 10

    _client: Optional[EngramPortMemory] = None
    _interaction_count: int = 0

    class Config:
        arbitrary_types_allowed = True

    @property
    def client(self) -> EngramPortMemory:
        if self._client is None:
            self._client = EngramPortMemory(
                api_key=self.api_key,
                base_url=self.base_url,
            )
        return self._client

    @property
    def memory_variables(self) -> List[str]:
        return [self.memory_key]

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, str]:
        """Recall relevant memories based on the current input."""
        query = inputs.get(self.input_key, "")
        if not query:
            return {self.memory_key: ""}

        try:
            result = self.client.recall(query=query, limit=self.recall_limit)
            if not result.memories:
                return {self.memory_key: ""}

            lines = []
            for m in result.memories:
                if m.content:
                    lines.append(f"- {m.content} (relevance: {m.relevance_score:.2f})")
            context = "\n".join(lines)
            return {self.memory_key: f"Relevant memories:\n{context}"}
        except Exception:
            return {self.memory_key: ""}

    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        """Store the interaction as a memory."""
        human_input = inputs.get(self.input_key, "")
        ai_output = outputs.get(self.output_key, "")

        if human_input:
            memory_text = f"Human: {human_input}"
            if ai_output:
                memory_text += f"\nAssistant: {ai_output}"

            try:
                self.client.remember(content=memory_text)
            except Exception:
                pass

        self._interaction_count += 1
        if self.auto_reflect and self._interaction_count % self.reflect_interval == 0:
            try:
                self.client.reflect()
            except Exception:
                pass

    def clear(self) -> None:
        """Reset interaction counter. Memories persist server-side."""
        self._interaction_count = 0
