#!/usr/bin/env bash
#
# Publish engramport-langchain to PyPI
#
# Prerequisites:
#   pip install build twine
#   PyPI account at https://pypi.org/account/register/
#   API token at https://pypi.org/manage/account/token/
#
# Usage:
#   ./publish.sh              # publish to real PyPI
#   ./publish.sh --test       # publish to TestPyPI first
#
set -euo pipefail

cd "$(dirname "$0")"

echo "==> Cleaning old builds..."
rm -rf dist/ build/ *.egg-info

echo "==> Building sdist + wheel..."
python -m build

if [[ "${1:-}" == "--test" ]]; then
    echo "==> Uploading to TestPyPI..."
    python -m twine upload --repository testpypi dist/*
    echo ""
    echo "Test install with:"
    echo "  pip install --index-url https://test.pypi.org/simple/ engramport-langchain"
else
    echo "==> Uploading to PyPI..."
    python -m twine upload dist/*
    echo ""
    echo "Live at: https://pypi.org/project/engramport-langchain/"
    echo "Install: pip install engramport-langchain"
fi
