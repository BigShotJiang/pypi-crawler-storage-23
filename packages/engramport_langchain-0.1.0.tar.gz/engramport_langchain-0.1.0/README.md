# engramport-langchain

Persistent memory for AI bots and agents, powered by [EngramPort](https://engram.eideticlab.com) + MandelDB.

**3 lines to give your bot a brain:**

```python
from engramport_langchain import EngramPortMemory

memory = EngramPortMemory(api_key="ek_bot_...")
memory.remember("User prefers dark mode and lives in Tampa, FL")
```

## Install

```bash
pip install engramport-langchain
```

For LangChain integration:

```bash
pip install engramport-langchain[langchain]
```

## Quick Start

### Standalone (no LangChain required)

```python
from engramport_langchain import EngramPortMemory

memory = EngramPortMemory(api_key="ek_bot_...")

# Store memories
memory.remember("User's name is Alex")
memory.remember("User prefers concise answers")
memory.remember("User lives in Tampa, FL and checks weather often")

# Semantic recall — no keyword matching needed
results = memory.recall("What do I know about this user?")
for m in results.memories:
    print(f"  {m.content} (score: {m.relevance_score:.2f})")

# Synthesize insights across all memories
insights = memory.reflect(topic="user preferences")
for i in insights.insights:
    print(f"  {i.content} (confidence: {i.confidence:.0%})")

# Check stats
stats = memory.stats()
print(f"Memories: {stats.memory_count}, Insights: {stats.insight_count}")
```

### Async

Every method has an async counterpart:

```python
await memory.aremember("User mentioned they love hiking")
results = await memory.arecall("outdoor activities")
insights = await memory.areflect()
stats = await memory.astats()
```

### LangChain Integration

Drop-in memory for any LangChain conversation chain:

```python
from engramport_langchain.langchain import EngramPortChatMemory
from langchain.chains import ConversationChain
from langchain_openai import ChatOpenAI

memory = EngramPortChatMemory(
    api_key="ek_bot_...",
    recall_limit=5,        # memories per turn
    auto_reflect=True,     # synthesize insights automatically
    reflect_interval=10,   # every 10 interactions
)

chain = ConversationChain(llm=ChatOpenAI(), memory=memory)

# Memories persist across sessions automatically
chain.invoke({"input": "My name is Alex and I live in Tampa"})
# ... restart your app ...
chain.invoke({"input": "What's the weather like where I live?"})
# Bot recalls Tampa without being told again
```

## API Reference

| Method | Description |
|--------|-------------|
| `remember(content, context?, session_id?)` | Store a memory |
| `recall(query, limit=5)` | Semantic search across memories |
| `reflect(topic?)` | LLM-powered insight synthesis |
| `stats()` | Memory and insight counts |

All methods return typed Pydantic models. Async versions prefixed with `a`.

## Get Your API Key

```bash
curl -X POST https://mandeldb.com/api/v1/portal/register \
  -H "Content-Type: application/json" \
  -d '{"bot_name": "my-bot", "bot_type": "custom", "owner_email": "you@example.com"}'
```

## Why EngramPort?

| Feature | EngramPort | Mem0 |
|---------|-----------|------|
| Semantic recall | Yes | Yes |
| Insight synthesis | Yes — `/reflect` | No |
| Cryptographic provenance (AEGIS) | Yes | No |
| Graph-based reasoning | Yes (MandelDB) | No |
| Category-aware memory decay | Yes | No |
| Self-hosted option | Yes | Paid only |
| Pricing (hobby) | Free tier | $49/mo |

## Links

- [Documentation](https://engram.eideticlab.com/docs)
- [API Playground](https://mandeldb.com/docs#/EngramPort)
- [Enterprise Sales](mailto:sales@an2b.com)
