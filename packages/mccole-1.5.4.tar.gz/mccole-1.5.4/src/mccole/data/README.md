# Sample McCole Project

## Lessons

<div id="lessons" markdown="1">

</div>

##  Appendices

<div id="appendices" markdown="1">

1.  [License](@/license/)
1.  [Code of Conduct](@/conduct/)
1.  [Contributing](@/contributing/)
1.  [Bibliography](@/bibliography/)
1.  [Glossary](@/glossary/)

</div>

## Acknowledgments {: #acknowledgments}
