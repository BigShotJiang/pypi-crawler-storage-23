"""Version information for accumulate-client."""

__version__ = "2.1.0"
