def text_review_init_template() -> str:
    return ""
