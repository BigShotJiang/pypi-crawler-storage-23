"""LeetVibe TUI widgets."""
