"""Tests for CLI interceptor commands — sync, rules, rules remove."""

import json
import pytest
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

from tlm.cli import main
from tlm.client import TLMConnectionError, TLMServerError


# ---------------------------------------------------------------------------
# tlm sync
# ---------------------------------------------------------------------------

class TestSyncCommand:

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_sync_with_rules_learned(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.sync_session.return_value = {"status": "ok", "rules_learned": 2}
        mock_client_cls.return_value = mock_client

        # Create .tlm dir with session file
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        prompts_file = tlm_dir / "session_prompts.jsonl"
        prompts_file.write_text(
            '{"prompt": "Add auth middleware"}\n'
            '{"prompt": "Write tests for login"}\n'
        )

        runner = CliRunner()
        result = runner.invoke(main, ["sync", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "2 rule(s) learned" in result.output
        mock_client.sync_session.assert_called_once()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_sync_no_rules(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.sync_session.return_value = {"status": "ok", "rules_learned": 0}
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "session_prompts.jsonl").write_text('{"prompt": "Hello"}\n')

        runner = CliRunner()
        result = runner.invoke(main, ["sync", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "No new rules" in result.output

    def test_sync_no_tlm_dir(self, tmp_path):
        runner = CliRunner()
        result = runner.invoke(main, ["sync", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "not initialized" in result.output.lower() or "tlm install" in result.output.lower()

    @patch("tlm.cli.load_project_config")
    def test_sync_no_session_file(self, mock_config, tmp_path):
        mock_config.return_value = {"project_id": 42}
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["sync", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "No session data" in result.output

    @patch("tlm.cli.load_project_config")
    def test_sync_no_project_id(self, mock_config, tmp_path):
        mock_config.return_value = {}
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["sync", "--path", str(tmp_path)])

        assert result.exit_code == 1
        assert "No project ID" in result.output or "project" in result.output.lower()

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_sync_connection_error(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.sync_session.side_effect = TLMConnectionError("Cannot reach TLM server")
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "session_prompts.jsonl").write_text('{"prompt": "test prompt"}\n')

        runner = CliRunner()
        result = runner.invoke(main, ["sync", "--path", str(tmp_path)])

        assert result.exit_code != 0 or "Cannot reach" in result.output or "server" in result.output.lower()


# ---------------------------------------------------------------------------
# tlm rules
# ---------------------------------------------------------------------------

class TestRulesCommand:

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_rules_list_shows_table(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.get_rules.return_value = {
            "rules": [
                {"id": 1, "rule_text": "Always test", "source": "session_learning"},
                {"id": 2, "rule_text": "Use type hints", "source": "assess"},
            ]
        }
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "Always test" in result.output
        assert "Use type hints" in result.output

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_rules_list_empty(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.get_rules.return_value = {"rules": []}
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "No active rules" in result.output

    @patch("tlm.cli.load_project_config")
    def test_rules_no_project_id(self, mock_config, tmp_path):
        mock_config.return_value = {}
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path)])

        assert result.exit_code == 1

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_rules_connection_error(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.get_rules.side_effect = TLMConnectionError("Cannot reach TLM server")
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path)])

        assert result.exit_code != 0 or "Cannot reach" in result.output or "server" in result.output.lower()


# ---------------------------------------------------------------------------
# tlm rules remove
# ---------------------------------------------------------------------------

class TestRulesRemoveCommand:

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_remove_success(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.delete_rule.return_value = {"status": "deleted"}
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path), "remove", "4"])

        assert result.exit_code == 0
        assert "Rule #4 removed" in result.output

    @patch("tlm.cli.load_project_config")
    def test_remove_no_project_id(self, mock_config, tmp_path):
        mock_config.return_value = {}
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path), "remove", "4"])

        assert result.exit_code == 1

    @patch("tlm.cli.get_api_key", return_value="tlm_sk_test")
    @patch("tlm.cli.get_server_url", return_value="http://localhost:8000")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.load_project_config")
    def test_remove_server_error(self, mock_config, mock_client_cls, mock_url, mock_key, tmp_path):
        mock_config.return_value = {"project_id": 42}
        mock_client = MagicMock()
        mock_client.delete_rule.side_effect = TLMServerError("Server error (404): Rule not found")
        mock_client_cls.return_value = mock_client

        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        runner = CliRunner()
        result = runner.invoke(main, ["rules", "--path", str(tmp_path), "remove", "99"])

        assert result.exit_code != 0 or "error" in result.output.lower()
