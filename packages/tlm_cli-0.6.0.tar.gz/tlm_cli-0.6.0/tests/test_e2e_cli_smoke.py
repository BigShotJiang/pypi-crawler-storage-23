"""
CLI smoke test — run key tlm commands against a live server.

Usage:
    TLM_TEST_SERVER_URL=http://localhost:8003 \
      ./venv/bin/python -m pytest tests/test_e2e_cli_smoke.py -v

Requires a running TLM server and the dedicated e2e test user
(created by server/tests/conftest_e2e.py or automatically here).
"""

import os
import subprocess

import httpx
import pytest
from click.testing import CliRunner

from tlm.cli import main

SERVER_URL = os.environ.get("TLM_TEST_SERVER_URL", "")

pytestmark = pytest.mark.skipif(not SERVER_URL, reason="TLM_TEST_SERVER_URL not set")

E2E_EMAIL = "e2e_lifecycle@test.tlmforge.dev"
E2E_PASSWORD = "e2e_lifecycle_pass_2026"


# ── fixtures ───────────────────────────────────────────────────

@pytest.fixture(scope="module")
def e2e_api_key():
    """Get or create the dedicated e2e user and return the API key."""
    # Try signup
    r = httpx.post(f"{SERVER_URL}/api/v1/auth/signup", json={
        "email": E2E_EMAIL, "password": E2E_PASSWORD,
    })
    if r.status_code == 200:
        return r.json()["api_key"]

    # Already exists — login
    r = httpx.post(f"{SERVER_URL}/api/v1/auth/login", json={
        "email": E2E_EMAIL, "password": E2E_PASSWORD,
    })
    assert r.status_code == 200, f"Login failed: {r.text}"
    return r.json()["api_key"]


@pytest.fixture
def hello_project(tmp_path):
    """Create a hello-world project with git init."""
    root = tmp_path / "hello_world"
    root.mkdir()
    (root / "main.py").write_text(
        'def greet(name: str) -> str:\n'
        '    """Return a greeting for *name*."""\n'
        '    return f"Hello, {name}!"\n'
        '\n'
        'if __name__ == "__main__":\n'
        '    import sys\n'
        '    who = sys.argv[1] if len(sys.argv) > 1 else "World"\n'
        '    print(greet(who))\n'
    )
    (root / "requirements.txt").write_text("")
    (root / "README.md").write_text("# Hello World\n")
    subprocess.run(["git", "init"], cwd=str(root), capture_output=True, check=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=str(root), capture_output=True, check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=str(root), capture_output=True, check=True,
    )
    subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True, check=True)
    subprocess.run(
        ["git", "commit", "-m", "init"],
        cwd=str(root), capture_output=True, check=True,
    )
    return root


def _invoke(args, api_key, *, input_text=None):
    """Invoke the CLI with TLM_API_KEY and TLM_SERVER_URL set."""
    env = {
        "TLM_API_KEY": api_key,
        "TLM_SERVER_URL": SERVER_URL,
        # Prevent credential file access during tests
        "HOME": "/tmp/tlm_cli_test_home",
    }
    runner = CliRunner(env=env)
    return runner.invoke(main, args, input=input_text, catch_exceptions=False)


# ── tests ──────────────────────────────────────────────────────

class TestCLISmoke:
    """CLI smoke tests against a live server."""

    def test_01_auth(self, e2e_api_key):
        """tlm auth <api_key> — should authenticate successfully."""
        result = _invoke(
            ["auth", e2e_api_key, "--server", SERVER_URL],
            e2e_api_key,
        )
        assert result.exit_code == 0, f"auth failed: {result.output}"
        assert "authenticated" in result.output.lower()

    def test_02_install(self, e2e_api_key, hello_project):
        """tlm install --path <dir> — scan + config + approve."""
        result = _invoke(
            ["install", "--path", str(hello_project)],
            e2e_api_key,
            # Approve config + accept default quality tier
            input_text="y\na\nhigh\n",
        )
        assert result.exit_code == 0, f"install failed:\n{result.output}"
        assert "installed" in result.output.lower() or "complete" in result.output.lower()

    def test_03_status(self, e2e_api_key, hello_project):
        """tlm status --path <dir> — shows project info (needs install first)."""
        # Install first
        _invoke(
            ["install", "--path", str(hello_project)],
            e2e_api_key,
            input_text="y\na\nhigh\n",
        )
        result = _invoke(
            ["status", "--path", str(hello_project)],
            e2e_api_key,
        )
        assert result.exit_code == 0, f"status failed:\n{result.output}"
        # Should show project info
        output_lower = result.output.lower()
        assert "hello" in output_lower or "high" in output_lower or "idle" in output_lower

    def test_04_scan(self, e2e_api_key, hello_project):
        """tlm scan --path <dir> — re-scan should work after install."""
        # Install first
        _invoke(
            ["install", "--path", str(hello_project)],
            e2e_api_key,
            input_text="y\na\nhigh\n",
        )
        result = _invoke(
            ["scan", "--path", str(hello_project)],
            e2e_api_key,
        )
        assert result.exit_code == 0, f"scan failed:\n{result.output}"

    def test_05_gaps(self, e2e_api_key, hello_project):
        """tlm gaps --path <dir> — show gaps table after install."""
        # Install first
        _invoke(
            ["install", "--path", str(hello_project)],
            e2e_api_key,
            input_text="y\na\nhigh\n",
        )
        result = _invoke(
            ["gaps", "--path", str(hello_project)],
            e2e_api_key,
        )
        assert result.exit_code == 0, f"gaps failed:\n{result.output}"

    def test_06_uninstall(self, e2e_api_key, hello_project):
        """tlm uninstall --path <dir> --yes — removes .tlm directory."""
        # Install first
        _invoke(
            ["install", "--path", str(hello_project)],
            e2e_api_key,
            input_text="y\na\nhigh\n",
        )
        result = _invoke(
            ["uninstall", "--path", str(hello_project), "--yes"],
            e2e_api_key,
        )
        assert result.exit_code == 0, f"uninstall failed:\n{result.output}"
        assert "removed" in result.output.lower()
        assert not (hello_project / ".tlm").exists()
