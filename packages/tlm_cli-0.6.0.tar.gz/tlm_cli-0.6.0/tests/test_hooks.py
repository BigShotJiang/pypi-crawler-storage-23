"""Tests for hooks — active hook handlers (bash_firewall, auto_interviewer, stop)."""

import json
import time
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from tlm.hooks import (
    hook_stop,
    _find_latest_plan,
    _tlm_block,
    _tlm_caution,
    _tlm_ok,
)
from tlm.state import write_state, read_state
from tlm.config import save_project_config


@pytest.fixture
def tlm_project(tmp_path):
    """Create a project with TLM initialized."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    write_state(str(tmp_path), {"phase": "idle"})
    save_project_config(str(tmp_path), {
        "quality_control": "standard",
        "project_id": "proj_1",
    })
    return tmp_path


class TestFindLatestPlan:
    def test_finds_most_recent_plan_file(self, tmp_path):
        """Should pick the newest .md file in the plans directory."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "old.md").write_text("old plan")
        time.sleep(0.05)
        (plans_dir / "new.md").write_text("new plan")

        result = _find_latest_plan(plans_dir)
        assert result is not None
        assert result.name == "new.md"

    def test_returns_none_for_empty_dir(self, tmp_path):
        plans_dir = tmp_path / "empty_plans"
        plans_dir.mkdir()
        assert _find_latest_plan(plans_dir) is None

    def test_returns_none_for_missing_dir(self, tmp_path):
        assert _find_latest_plan(tmp_path / "nonexistent") is None


class TestHookStop:
    def test_returns_empty_when_no_tlm(self, tmp_path):
        """Should return empty when .tlm/ doesn't exist."""
        result = hook_stop(str(tmp_path))
        assert result == {}

    def test_returns_dict(self, tlm_project):
        """Should return a dict."""
        result = hook_stop(str(tlm_project))
        assert isinstance(result, dict)

    def test_resets_tlm_active_to_idle(self, tlm_project):
        """hook_stop should reset tlm_active phase back to idle."""
        write_state(str(tlm_project), {"phase": "tlm_active"})
        hook_stop(str(tlm_project))
        assert read_state(str(tlm_project))["phase"] == "idle"

    def test_does_not_reset_implementation(self, tlm_project):
        """hook_stop should NOT reset implementation phase."""
        write_state(str(tlm_project), {"phase": "implementation"})
        hook_stop(str(tlm_project))
        assert read_state(str(tlm_project))["phase"] == "implementation"

    def test_clears_plan_review_pending(self, tlm_project):
        """hook_stop should remove plan_review_pending from state."""
        write_state(str(tlm_project), {
            "phase": "tlm_active",
            "plan_review_pending": True,
        })
        hook_stop(str(tlm_project))
        state = read_state(str(tlm_project))
        assert "plan_review_pending" not in state


class TestTlmMessageHelpers:
    def test_block_returns_decision_block(self):
        result = _tlm_block("TEST", "detail")
        assert result["decision"] == "block"
        assert "TEST" in result["reason"]
        assert "\u25a0" in result["reason"]

    def test_caution_returns_additional_context(self):
        result = _tlm_caution("TEST", "detail")
        assert "additionalContext" in result
        assert "decision" not in result
        assert "\u25b2 TLM" in result["additionalContext"]
        assert "Display this TLM status" in result["additionalContext"]

    def test_ok_returns_additional_context(self):
        result = _tlm_ok("TEST", "detail")
        assert "additionalContext" in result
        assert "\u2713 TLM" in result["additionalContext"]
        assert "Display this TLM status" in result["additionalContext"]

    def test_block_has_ansi_red(self):
        result = _tlm_block("X", "Y")
        assert "\033[31m" in result["reason"]

    def test_caution_has_markdown_block(self):
        result = _tlm_caution("WARN", "info")
        assert "```" in result["additionalContext"]

    def test_ok_has_markdown_block(self):
        result = _tlm_ok("GOOD", "info")
        assert "```" in result["additionalContext"]
