"""Tests for TLMClient interceptor methods — review, command, sync, rules."""

import pytest
from unittest.mock import patch, MagicMock

import httpx

from tlm.client import TLMClient, TLMConnectionError, TLMServerError


# ── Fixture ──────────────────────────────────────────────────

@pytest.fixture
def client():
    return TLMClient(server_url="http://test-server:8000", api_key="test-key-123")


# ---------------------------------------------------------------------------
# review_plan_or_diff
# ---------------------------------------------------------------------------

class TestReviewPlanOrDiff:

    @patch("httpx.post")
    def test_success_returns_dict(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"decision": "pass", "reason": "ok", "issues": []}
        mock_post.return_value = mock_resp

        result = client.review_plan_or_diff(1, "plan content", "plan")
        assert result["decision"] == "pass"
        assert result["reason"] == "ok"
        assert result["issues"] == []

    @patch("httpx.post")
    def test_sends_correct_url_and_body(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"decision": "pass"}
        mock_post.return_value = mock_resp

        client.review_plan_or_diff(42, "diff content", "diff")

        call_url = mock_post.call_args[0][0]
        assert "/api/v2/projects/42/review" in call_url

        call_kwargs = mock_post.call_args[1]
        body = call_kwargs.get("json", {})
        assert body["content"] == "diff content"
        assert body["review_type"] == "diff"

    @patch("httpx.post")
    def test_timeout_raises_connection_error(self, mock_post, client):
        mock_post.side_effect = httpx.TimeoutException("timed out")

        with pytest.raises(TLMConnectionError):
            client.review_plan_or_diff(1, "content", "plan")

    @patch("httpx.post")
    def test_custom_timeout_passed(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"decision": "pass"}
        mock_post.return_value = mock_resp

        client.review_plan_or_diff(1, "content", "plan", timeout=5.0)

        call_kwargs = mock_post.call_args[1]
        assert call_kwargs["timeout"] == 5.0


# ---------------------------------------------------------------------------
# review_command
# ---------------------------------------------------------------------------

class TestReviewCommand:

    @patch("httpx.post")
    def test_success_returns_dict(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"decision": "block", "reason": "Destructive"}
        mock_post.return_value = mock_resp

        result = client.review_command(1, "rm -rf /")
        assert result["decision"] == "block"
        assert result["reason"] == "Destructive"

    @patch("httpx.post")
    def test_sends_correct_url_and_body(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"decision": "pass"}
        mock_post.return_value = mock_resp

        client.review_command(42, "rm -rf /")

        call_url = mock_post.call_args[0][0]
        assert "/api/v2/projects/42/review-command" in call_url

        call_kwargs = mock_post.call_args[1]
        body = call_kwargs.get("json", {})
        assert body["command"] == "rm -rf /"

    @patch("httpx.post")
    def test_connection_error(self, mock_post, client):
        mock_post.side_effect = httpx.ConnectError("refused")

        with pytest.raises(TLMConnectionError):
            client.review_command(1, "ls")


# ---------------------------------------------------------------------------
# sync_session
# ---------------------------------------------------------------------------

class TestSyncSession:

    @patch("httpx.post")
    def test_success(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"status": "ok", "rules_learned": 2}
        mock_post.return_value = mock_resp

        result = client.sync_session(1, "session summary text")
        assert result["status"] == "ok"
        assert result["rules_learned"] == 2

    @patch("httpx.post")
    def test_sends_correct_body(self, mock_post, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"status": "ok", "rules_learned": 0}
        mock_post.return_value = mock_resp

        client.sync_session(7, "my summary")

        call_kwargs = mock_post.call_args[1]
        body = call_kwargs.get("json", {})
        assert body["summary"] == "my summary"

    @patch("httpx.post")
    def test_connection_error(self, mock_post, client):
        mock_post.side_effect = httpx.TimeoutException("timed out")

        with pytest.raises(TLMConnectionError):
            client.sync_session(1, "summary")


# ---------------------------------------------------------------------------
# get_rules
# ---------------------------------------------------------------------------

class TestGetRules:

    @patch("httpx.get")
    def test_success(self, mock_get, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "rules": [
                {"id": 1, "rule_text": "Always test", "source": "session_learning"},
                {"id": 2, "rule_text": "Use types", "source": "assess"},
            ]
        }
        mock_get.return_value = mock_resp

        result = client.get_rules(5)
        assert len(result["rules"]) == 2
        assert result["rules"][0]["rule_text"] == "Always test"

    @patch("httpx.get")
    def test_uses_get_method(self, mock_get, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"rules": []}
        mock_get.return_value = mock_resp

        client.get_rules(1)
        mock_get.assert_called_once()

    @patch("httpx.get")
    def test_connection_error(self, mock_get, client):
        mock_get.side_effect = httpx.ConnectError("refused")

        with pytest.raises(TLMConnectionError):
            client.get_rules(1)


# ---------------------------------------------------------------------------
# delete_rule
# ---------------------------------------------------------------------------

class TestDeleteRule:

    @patch("httpx.delete")
    def test_success(self, mock_delete, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"status": "deleted"}
        mock_delete.return_value = mock_resp

        result = client.delete_rule(1, 42)
        assert result["status"] == "deleted"

    @patch("httpx.delete")
    def test_uses_delete_method(self, mock_delete, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"status": "deleted"}
        mock_delete.return_value = mock_resp

        client.delete_rule(1, 42)
        mock_delete.assert_called_once()

    @patch("httpx.delete")
    def test_correct_url(self, mock_delete, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"status": "deleted"}
        mock_delete.return_value = mock_resp

        client.delete_rule(1, 42)

        call_url = mock_delete.call_args[0][0]
        assert "/api/v2/projects/1/rules/42" in call_url

    @patch("httpx.delete")
    def test_404_raises_server_error(self, mock_delete, client):
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        mock_resp.json.return_value = {"detail": "Rule not found"}
        mock_delete.return_value = mock_resp

        with pytest.raises(TLMServerError):
            client.delete_rule(1, 99999)
