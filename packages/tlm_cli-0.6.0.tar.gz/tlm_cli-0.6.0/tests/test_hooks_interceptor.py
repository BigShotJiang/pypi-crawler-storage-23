"""Tests for Hook A (Auto-Interviewer) and Hook B (Bash Firewall)."""

import json
import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path

from tlm.hooks import (
    hook_auto_interviewer_plan,
    hook_bash_firewall,
    _review_diff_before_commit,
    _get_staged_diff,
    _matches_risky_pattern,
    _is_permanently_overridden,
    _add_permanent_override,
    _log_override,
    _handle_block_with_override,
)


class TestAutoInterviewerPlan:
    """Hook A trigger 1: PostToolUse on ExitPlanMode."""

    def test_no_tlm_dir_returns_empty(self, tmp_path):
        result = hook_auto_interviewer_plan(str(tmp_path), {})
        assert result == {}

    def test_no_plan_file_returns_empty(self, tmp_path):
        (tmp_path / ".tlm").mkdir()
        result = hook_auto_interviewer_plan(str(tmp_path), {}, plans_dir=tmp_path / "plans")
        assert result == {}

    def test_empty_plan_returns_empty(self, tmp_path):
        (tmp_path / ".tlm").mkdir()
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "test.md").write_text("")
        result = hook_auto_interviewer_plan(str(tmp_path), {}, plans_dir=plans_dir)
        assert result == {}

    @patch("tlm.hooks._get_review_client")
    def test_no_auth_returns_empty(self, mock_client, tmp_path):
        (tmp_path / ".tlm").mkdir()
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "test.md").write_text("# Plan\nDo some stuff with at least 20 chars here.")
        mock_client.return_value = None

        result = hook_auto_interviewer_plan(str(tmp_path), {}, plans_dir=plans_dir)
        assert result == {}

    @patch("tlm.hooks.load_project_config")
    @patch("tlm.hooks._get_review_client")
    def test_pass_decision_returns_empty(self, mock_client, mock_config, tmp_path):
        (tmp_path / ".tlm").mkdir()
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "test.md").write_text("# Plan\nImplement auth with JWT tokens for the API layer")

        mock_config.return_value = {"project_id": 42}
        client = MagicMock()
        client.review_plan_or_diff.return_value = {"decision": "pass", "reason": "Looks good"}
        mock_client.return_value = client

        result = hook_auto_interviewer_plan(str(tmp_path), {}, plans_dir=plans_dir)
        assert result == {}
        client.review_plan_or_diff.assert_called_once()

    @patch("tlm.hooks.load_project_config")
    @patch("tlm.hooks._get_review_client")
    def test_reject_decision_returns_context(self, mock_client, mock_config, tmp_path):
        (tmp_path / ".tlm").mkdir()
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "test.md").write_text("# Plan\nDeploy everything directly to production without tests")

        mock_config.return_value = {"project_id": 42}
        client = MagicMock()
        client.review_plan_or_diff.return_value = {
            "decision": "reject",
            "reason": "Missing test strategy",
            "issues": ["No tests mentioned", "Direct prod deploy"],
        }
        mock_client.return_value = client

        result = hook_auto_interviewer_plan(str(tmp_path), {}, plans_dir=plans_dir)
        assert "additionalContext" in result
        assert "TLM REJECT" in result["additionalContext"]
        assert "No tests mentioned" in result["additionalContext"]

    @patch("tlm.hooks.load_project_config")
    @patch("tlm.hooks._get_review_client")
    def test_server_timeout_returns_empty(self, mock_client, mock_config, tmp_path):
        (tmp_path / ".tlm").mkdir()
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "test.md").write_text("# Plan\nDo something important for production readiness")

        mock_config.return_value = {"project_id": 42}
        client = MagicMock()
        client.review_plan_or_diff.side_effect = TimeoutError("Connection timed out")
        mock_client.return_value = client

        result = hook_auto_interviewer_plan(str(tmp_path), {}, plans_dir=plans_dir)
        assert result == {}


class TestReviewDiffBeforeCommit:
    """Hook A trigger 2: pre-commit diff review."""

    @patch("tlm.hooks._get_staged_diff")
    def test_no_diff_returns_empty(self, mock_diff, tmp_path):
        mock_diff.return_value = None
        result = _review_diff_before_commit(str(tmp_path), "git commit -m 'test'")
        assert result == {}

    @patch("tlm.hooks._get_staged_diff")
    def test_tiny_diff_returns_empty(self, mock_diff, tmp_path):
        mock_diff.return_value = "abc"
        result = _review_diff_before_commit(str(tmp_path), "git commit -m 'test'")
        assert result == {}

    @patch("tlm.hooks.load_project_config")
    @patch("tlm.hooks._get_review_client")
    @patch("tlm.hooks._get_staged_diff")
    def test_pass_diff_returns_empty(self, mock_diff, mock_client, mock_config, tmp_path):
        mock_diff.return_value = "diff --git a/file.py b/file.py\n+print('hello')\n" * 3

        mock_config.return_value = {"project_id": 42}
        client = MagicMock()
        client.review_plan_or_diff.return_value = {"decision": "pass", "reason": "Clean diff"}
        mock_client.return_value = client

        result = _review_diff_before_commit(str(tmp_path), "git commit -m 'test'")
        assert result == {}

    @patch("tlm.hooks.load_project_config")
    @patch("tlm.hooks._get_review_client")
    @patch("tlm.hooks._get_staged_diff")
    def test_reject_diff_blocks(self, mock_diff, mock_client, mock_config, tmp_path):
        mock_diff.return_value = "diff --git a/secrets.py b/secrets.py\n+API_KEY='sk-secret123'\n" * 3

        mock_config.return_value = {"project_id": 42}
        client = MagicMock()
        client.review_plan_or_diff.return_value = {
            "decision": "reject",
            "reason": "Hardcoded secret",
            "issues": ["API key committed to source"],
        }
        mock_client.return_value = client

        result = _review_diff_before_commit(str(tmp_path), "git commit -m 'test'")
        assert result.get("decision") == "block"
        assert "PRE-COMMIT REVIEW FAILED" in result.get("reason", "")


class TestRiskyPatterns:
    """Regex pre-filter for risky commands."""

    def test_safe_commands_not_risky(self):
        assert not _matches_risky_pattern("ls -la")
        assert not _matches_risky_pattern("npm install")
        assert not _matches_risky_pattern("pip install flask")
        assert not _matches_risky_pattern("git status")
        assert not _matches_risky_pattern("git push origin feature/xyz")
        assert not _matches_risky_pattern("pytest tests/")
        assert not _matches_risky_pattern("docker build .")
        assert not _matches_risky_pattern("make test")

    def test_deploy_commands_risky(self):
        assert _matches_risky_pattern("firebase deploy")
        assert _matches_risky_pattern("firebase deploy --only hosting")
        assert _matches_risky_pattern("vercel deploy --prod")
        assert _matches_risky_pattern("fly deploy")
        assert _matches_risky_pattern("heroku deploy")
        assert _matches_risky_pattern("gcloud app deploy")

    def test_k8s_commands_risky(self):
        assert _matches_risky_pattern("kubectl apply -f deployment.yaml")
        assert _matches_risky_pattern("kubectl delete pod my-pod")
        assert _matches_risky_pattern("helm install my-chart")
        assert _matches_risky_pattern("helm upgrade my-release")

    def test_git_push_prod_risky(self):
        assert _matches_risky_pattern("git push origin main")
        assert _matches_risky_pattern("git push origin master")
        assert _matches_risky_pattern("git push origin production")
        assert _matches_risky_pattern("git push origin prod")

    def test_destructive_commands_risky(self):
        assert _matches_risky_pattern("rm -rf /var/data")
        assert _matches_risky_pattern("rm -f important.db")

    def test_terraform_risky(self):
        assert _matches_risky_pattern("terraform apply")
        assert _matches_risky_pattern("terraform destroy")

    def test_docker_push_risky(self):
        assert _matches_risky_pattern("docker push myimage:latest")

    def test_db_destructive_risky(self):
        assert _matches_risky_pattern("DROP TABLE users")
        assert _matches_risky_pattern("TRUNCATE TABLE sessions")

    def test_scripts_deploy_risky(self):
        assert _matches_risky_pattern("scripts/deploy.sh")
        assert _matches_risky_pattern("bin/release-prod.sh")

    def test_serverless_deploy_risky(self):
        assert _matches_risky_pattern("serverless deploy")
        assert _matches_risky_pattern("sam deploy")
        assert _matches_risky_pattern("cdk deploy")


class TestPermanentOverrides:
    """Override persistence in permanent_overrides.json."""

    def test_no_overrides_file_returns_empty(self, tmp_path):
        (tmp_path / ".tlm").mkdir()
        assert not _is_permanently_overridden(str(tmp_path), "firebase deploy")

    def test_add_and_check_override(self, tmp_path):
        (tmp_path / ".tlm").mkdir()
        _add_permanent_override(str(tmp_path), "firebase deploy --only hosting")
        assert _is_permanently_overridden(str(tmp_path), "firebase deploy --only hosting")
        assert not _is_permanently_overridden(str(tmp_path), "firebase deploy --only functions")

    def test_log_override_creates_file(self, tmp_path):
        (tmp_path / ".tlm").mkdir()
        _log_override(str(tmp_path), "firebase deploy", "Direct prod deploy", "OVERRIDE_ONCE")
        log_file = tmp_path / ".tlm" / "overrides.log"
        assert log_file.exists()
        content = log_file.read_text()
        assert "OVERRIDE_ONCE" in content
        assert "firebase deploy" in content


class TestHandleBlockWithOverride:
    """Interactive override prompt."""

    @patch("builtins.input", return_value="1")
    def test_override_once_allows(self, mock_input, tmp_path):
        (tmp_path / ".tlm").mkdir()
        result = _handle_block_with_override(str(tmp_path), "firebase deploy", "Prod deploy")
        assert result == {}
        # Should be logged but NOT permanently overridden
        assert not _is_permanently_overridden(str(tmp_path), "firebase deploy")

    @patch("builtins.input", return_value="2")
    def test_override_always_allows_and_saves(self, mock_input, tmp_path):
        (tmp_path / ".tlm").mkdir()
        result = _handle_block_with_override(str(tmp_path), "firebase deploy", "Prod deploy")
        assert result == {}
        assert _is_permanently_overridden(str(tmp_path), "firebase deploy")

    @patch("builtins.input", return_value="n")
    def test_block_returns_block_dict(self, mock_input, tmp_path):
        (tmp_path / ".tlm").mkdir()
        result = _handle_block_with_override(str(tmp_path), "firebase deploy", "Prod deploy")
        assert result.get("decision") == "block"

    @patch("builtins.input", side_effect=EOFError)
    def test_eof_blocks(self, mock_input, tmp_path):
        (tmp_path / ".tlm").mkdir()
        result = _handle_block_with_override(str(tmp_path), "firebase deploy", "Prod deploy")
        assert result.get("decision") == "block"


class TestBashFirewall:
    """Hook B: PreToolUse on Bash commands."""

    def test_no_tlm_dir_returns_empty(self, tmp_path):
        result = hook_bash_firewall(str(tmp_path), {"command": "ls"})
        assert result == {}

    def test_safe_command_returns_empty(self, tmp_path):
        (tmp_path / ".tlm").mkdir()
        result = hook_bash_firewall(str(tmp_path), {"command": "ls -la"})
        assert result == {}

    def test_safe_npm_returns_empty(self, tmp_path):
        (tmp_path / ".tlm").mkdir()
        result = hook_bash_firewall(str(tmp_path), {"command": "npm install express"})
        assert result == {}

    def test_safe_git_push_feature_returns_empty(self, tmp_path):
        (tmp_path / ".tlm").mkdir()
        result = hook_bash_firewall(str(tmp_path), {"command": "git push origin feature/xyz"})
        assert result == {}

    @patch("tlm.hooks._review_diff_before_commit")
    def test_git_commit_delegates_to_hook_a(self, mock_review, tmp_path):
        (tmp_path / ".tlm").mkdir()
        mock_review.return_value = {}

        result = hook_bash_firewall(str(tmp_path), {"command": "git commit -m 'test'"})
        mock_review.assert_called_once_with(str(tmp_path), "git commit -m 'test'")

    @patch("tlm.hooks._review_diff_before_commit")
    def test_git_commit_amend_delegates(self, mock_review, tmp_path):
        (tmp_path / ".tlm").mkdir()
        mock_review.return_value = {"decision": "block", "reason": "blocked"}

        result = hook_bash_firewall(str(tmp_path), {"command": "git commit --amend"})
        assert result.get("decision") == "block"
        mock_review.assert_called_once()

    def test_permanently_overridden_passes(self, tmp_path):
        (tmp_path / ".tlm").mkdir()
        _add_permanent_override(str(tmp_path), "firebase deploy --only hosting")
        result = hook_bash_firewall(str(tmp_path), {"command": "firebase deploy --only hosting"})
        assert result == {}

    @patch("tlm.hooks.load_project_config")
    @patch("tlm.hooks._get_review_client")
    def test_risky_command_server_pass(self, mock_client, mock_config, tmp_path):
        (tmp_path / ".tlm").mkdir()
        mock_config.return_value = {"project_id": 42}
        client = MagicMock()
        client.review_command.return_value = {"decision": "pass", "reason": "Safe deploy"}
        mock_client.return_value = client

        result = hook_bash_firewall(str(tmp_path), {"command": "firebase deploy --only hosting"})
        assert result == {}
        client.review_command.assert_called_once()

    @patch("builtins.input", return_value="n")
    @patch("tlm.hooks.load_project_config")
    @patch("tlm.hooks._get_review_client")
    def test_risky_command_server_block(self, mock_client, mock_config, mock_input, tmp_path):
        (tmp_path / ".tlm").mkdir()
        mock_config.return_value = {"project_id": 42}
        client = MagicMock()
        client.review_command.return_value = {"decision": "block", "reason": "Prod deploy blocked"}
        mock_client.return_value = client

        result = hook_bash_firewall(str(tmp_path), {"command": "firebase deploy"})
        assert result.get("decision") == "block"

    @patch("tlm.hooks.load_project_config")
    @patch("tlm.hooks._get_review_client")
    def test_risky_command_server_timeout_failopen(self, mock_client, mock_config, tmp_path):
        (tmp_path / ".tlm").mkdir()
        mock_config.return_value = {"project_id": 42}
        client = MagicMock()
        client.review_command.side_effect = TimeoutError("Connection timed out")
        mock_client.return_value = client

        result = hook_bash_firewall(str(tmp_path), {"command": "firebase deploy"})
        assert result == {}  # fail-open

    @patch("tlm.hooks._get_review_client")
    def test_risky_command_no_auth_failopen(self, mock_client, tmp_path):
        (tmp_path / ".tlm").mkdir()
        mock_client.return_value = None

        result = hook_bash_firewall(str(tmp_path), {"command": "firebase deploy"})
        assert result == {}  # fail-open


class TestGetStagedDiff:
    """Helper: get staged git diff."""

    def test_returns_none_in_non_git_dir(self, tmp_path):
        result = _get_staged_diff(str(tmp_path))
        # Either None or empty string — both acceptable for non-git dirs
        assert not result or result.strip() == ""
