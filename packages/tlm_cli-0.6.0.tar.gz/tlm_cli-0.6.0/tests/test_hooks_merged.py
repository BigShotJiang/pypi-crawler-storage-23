"""Tests for merged hook features — session learning on stop."""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from tlm.hooks import hook_stop
from tlm.state import write_state, read_state
from tlm.config import save_project_config


@pytest.fixture
def tlm_project(tmp_path):
    """Create a project with TLM initialized."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    write_state(str(tmp_path), {"phase": "idle"})
    save_project_config(str(tmp_path), {
        "quality_control": "standard",
        "project_id": "proj_1",
    })
    return tmp_path


# =============================================================================
# Session learning on hook_stop
# =============================================================================

class TestHookStopLearning:
    def test_stop_triggers_session_learning(self, tlm_project):
        """hook_stop should attempt session learning when prompts exist."""
        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        prompts_file.write_text(
            json.dumps({"prompt": "Add auth", "timestamp": 1234567890, "phase": "idle"}) + "\n"
            + json.dumps({"prompt": "Use JWT", "timestamp": 1234567891, "phase": "tlm_active"}) + "\n"
        )

        with patch("tlm.hooks._run_session_learning") as mock_learn:
            mock_learn.return_value = {"rules_learned": 1}
            hook_stop(str(tlm_project))
            mock_learn.assert_called_once()

    def test_stop_no_prompts_skips_learning(self, tlm_project):
        """hook_stop should skip learning when no prompts captured."""
        with patch("tlm.hooks._run_session_learning") as mock_learn:
            hook_stop(str(tlm_project))
            mock_learn.assert_not_called()

    def test_stop_cleans_session_prompts(self, tlm_project):
        """hook_stop should clean up session_prompts.jsonl."""
        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        prompts_file.write_text(json.dumps({"prompt": "test"}) + "\n")

        with patch("tlm.hooks._run_session_learning"):
            hook_stop(str(tlm_project))

        assert not prompts_file.exists()

    def test_stop_learning_failure_doesnt_crash(self, tlm_project):
        """Session learning failure should not crash hook_stop."""
        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        prompts_file.write_text(json.dumps({"prompt": "test"}) + "\n")

        with patch("tlm.hooks._run_session_learning") as mock_learn:
            mock_learn.side_effect = Exception("Network error")
            result = hook_stop(str(tlm_project))
            assert isinstance(result, dict)


# =============================================================================
# Session learning rule storage (server-side)
# =============================================================================

class TestSessionLearningRuleStorage:
    def test_session_learning_calls_sync_session(self, tlm_project):
        """_run_session_learning should call server sync_session endpoint."""
        from tlm.hooks import _run_session_learning

        prompts = [
            {"prompt": "Add JWT auth", "timestamp": 1234567890, "phase": "idle"},
            {"prompt": "Use RS256 algorithm", "timestamp": 1234567891, "phase": "tlm_active"},
        ]

        mock_client = MagicMock()

        with patch("tlm.hooks._get_review_client", return_value=mock_client):
            _run_session_learning(str(tlm_project), prompts)

        mock_client.sync_session.assert_called_once()
        args = mock_client.sync_session.call_args
        assert args[0][0] == "proj_1"
        summary = args[0][1]
        assert "Add JWT auth" in summary
        assert "Use RS256 algorithm" in summary

    def test_session_learning_sends_summary(self, tlm_project):
        """_run_session_learning should build summary from prompts and send to server."""
        from tlm.hooks import _run_session_learning

        prompts = [{"prompt": "test prompt", "timestamp": 123, "phase": "idle"}]

        mock_client = MagicMock()

        with patch("tlm.hooks._get_review_client", return_value=mock_client):
            _run_session_learning(str(tlm_project), prompts)

        mock_client.sync_session.assert_called_once()
        summary = mock_client.sync_session.call_args[0][1]
        assert "test prompt" in summary

    def test_session_learning_no_client_skips(self, tlm_project):
        """_run_session_learning should skip when no client (not authenticated)."""
        from tlm.hooks import _run_session_learning

        prompts = [{"prompt": "test", "timestamp": 123, "phase": "idle"}]

        with patch("tlm.hooks._get_review_client", return_value=None):
            _run_session_learning(str(tlm_project), prompts)

    def test_session_learning_builds_summary(self, tlm_project):
        """_run_session_learning should build session summary from all prompts."""
        from tlm.hooks import _run_session_learning

        prompts = [
            {"prompt": "Add authentication", "timestamp": 100, "phase": "idle"},
            {"prompt": "Use OAuth 2.0", "timestamp": 200, "phase": "tlm_active"},
            {"prompt": "Add refresh tokens", "timestamp": 300, "phase": "implementation"},
        ]

        mock_client = MagicMock()

        with patch("tlm.hooks._get_review_client", return_value=mock_client):
            _run_session_learning(str(tlm_project), prompts)

        mock_client.sync_session.assert_called_once()
        summary = mock_client.sync_session.call_args[0][1]
        assert "Add authentication" in summary
        assert "Use OAuth 2.0" in summary
        assert "Add refresh tokens" in summary
