"""Tests for tlm.cache -- TLMCache local cache manager."""

import json
import time
import datetime

import pytest

from tlm.cache import TLMCache


@pytest.fixture
def cache(tmp_path):
    """Create a TLMCache rooted in tmp_path with a short TTL for testing."""
    return TLMCache(str(tmp_path), ttl_seconds=3600)


# --- write_sync / read_sync ---

class TestWriteReadSync:
    def test_write_sync_and_read_sync_roundtrip(self, cache):
        data = {
            "knowledge": "# Project Knowledge\n- Rule 1\n",
            "enforcement_config": {"checks": [], "approved": True},
            "profile": "Python backend project",
        }
        cache.write_sync(data)
        result = cache.read_sync()

        assert result is not None
        assert result["knowledge"] == "# Project Knowledge\n- Rule 1\n"
        assert result["enforcement_config"]["approved"] is True
        assert result["profile"] == "Python backend project"

    def test_read_sync_returns_none_when_no_cache(self, cache):
        result = cache.read_sync()
        assert result is None


# --- is_stale ---

class TestIsStale:
    def test_is_stale_returns_true_when_no_cache(self, cache):
        assert cache.is_stale() is True

    def test_is_stale_returns_false_when_fresh(self, cache):
        cache.write_sync({"knowledge": "test"})
        assert cache.is_stale() is False

    def test_is_stale_returns_true_when_expired(self, tmp_path):
        # Use a very short TTL
        cache = TLMCache(str(tmp_path), ttl_seconds=0)
        cache.write_sync({"knowledge": "test"})
        # With ttl=0, any age > 0 is stale
        assert cache.is_stale() is True


# --- clear ---

class TestClear:
    def test_clear_removes_cache_file(self, cache):
        cache.write_sync({"knowledge": "test"})
        assert cache.read_sync() is not None

        cache.clear()
        assert cache.read_sync() is None
        assert not cache.cache_file.exists()

    def test_clear_when_no_cache_is_noop(self, cache):
        # Should not raise
        cache.clear()
        assert not cache.cache_file.exists()


# --- get_knowledge_with_fallback ---

class TestGetKnowledgeWithFallback:
    def test_returns_cached_value(self, cache):
        cache.write_sync({"knowledge": "Cached knowledge content"})
        result = cache.get_knowledge_with_fallback()
        assert result == "Cached knowledge content"

    def test_falls_back_to_knowledge_md(self, tmp_path):
        cache = TLMCache(str(tmp_path))
        knowledge_file = tmp_path / "knowledge.md"
        knowledge_file.write_text("# Fallback Knowledge\n- Rule from file\n")

        result = cache.get_knowledge_with_fallback()
        assert result == "# Fallback Knowledge\n- Rule from file\n"

    def test_returns_none_when_no_cache_and_no_file(self, tmp_path):
        cache = TLMCache(str(tmp_path))
        result = cache.get_knowledge_with_fallback()
        assert result is None

    def test_cache_takes_priority_over_file(self, tmp_path):
        cache = TLMCache(str(tmp_path))
        # Write both cache and raw file
        cache.write_sync({"knowledge": "From cache"})
        (tmp_path / "knowledge.md").write_text("From file")

        result = cache.get_knowledge_with_fallback()
        assert result == "From cache"


# --- get_enforcement_config_with_fallback ---

class TestGetEnforcementConfigWithFallback:
    def test_returns_cached_value(self, cache):
        config_data = {"checks": [{"name": "lint"}], "approved": True}
        cache.write_sync({"enforcement_config": config_data})
        result = cache.get_enforcement_config_with_fallback()
        assert result == config_data

    def test_falls_back_to_enforcement_json(self, tmp_path):
        cache = TLMCache(str(tmp_path))
        config_data = {"checks": [{"name": "test"}], "approved": False}
        (tmp_path / "enforcement.json").write_text(json.dumps(config_data))

        result = cache.get_enforcement_config_with_fallback()
        assert result == config_data

    def test_returns_none_when_no_cache_and_no_file(self, tmp_path):
        cache = TLMCache(str(tmp_path))
        result = cache.get_enforcement_config_with_fallback()
        assert result is None
