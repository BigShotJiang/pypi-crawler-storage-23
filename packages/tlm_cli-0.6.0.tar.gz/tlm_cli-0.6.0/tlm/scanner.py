"""Scanner — collects file tree, categorizes files by role, and samples content."""

import os
import re
from pathlib import Path

# Directories to always skip
SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "__pycache__",
    ".tox", ".mypy_cache", ".pytest_cache", "venv", ".venv",
    "env", ".env", "dist", "build", ".eggs", "*.egg-info",
    ".next", ".nuxt", ".output", "coverage", ".coverage",
    ".tlm", ".claude", ".tmp",
}

# File extensions to skip
SKIP_EXTENSIONS = {
    ".pyc", ".pyo", ".so", ".o", ".a", ".dylib",
    ".class", ".jar", ".war",
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg",
    ".woff", ".woff2", ".ttf", ".eot",
    ".zip", ".tar", ".gz", ".bz2", ".7z",
    ".lock", ".min.js", ".min.css",
}

# CI config directories (any file inside these is a ci_config)
_CI_DIRS = {".github/workflows", ".circleci", ".buildkite"}

# CI config filenames (standalone files at any depth)
_CI_FILENAMES = {".gitlab-ci.yml", "Jenkinsfile", "bitbucket-pipelines.yml"}

# Test directories
_TEST_DIRS = {"tests", "test", "__tests__", "spec", "specs"}

# Test filename patterns
_TEST_PATTERNS = [
    re.compile(r'^test_'),
    re.compile(r'_test\.'),
    re.compile(r'\.test\.'),
    re.compile(r'_spec\.'),
    re.compile(r'\.spec\.'),
]

# Manifest filenames (package/dependency declarations)
_MANIFEST_PATTERNS = [
    re.compile(r'^requirements.*\.txt$'),
    re.compile(r'^package\.json$'),
    re.compile(r'^pyproject\.toml$'),
    re.compile(r'^Cargo\.toml$'),
    re.compile(r'^go\.mod$'),
    re.compile(r'^go\.sum$'),
    re.compile(r'^Gemfile$'),
    re.compile(r'^pom\.xml$'),
    re.compile(r'^build\.gradle$'),
    re.compile(r'^Pipfile$'),
    re.compile(r'^setup\.py$'),
    re.compile(r'^setup\.cfg$'),
    re.compile(r'^tsconfig\.json$'),
    re.compile(r'^composer\.json$'),
]

# Script directories
_SCRIPT_DIRS = {"scripts", "bin", "tools"}

# Deploy/release keywords in file content
_DEPLOY_CONTENT_RE = re.compile(r'\b(deploy|release|push|publish)\b', re.IGNORECASE)

# Deploy/release keywords in filenames
_DEPLOY_NAME_RE = re.compile(r'^(deploy|release)', re.IGNORECASE)

# Infra extensions
_INFRA_EXTENSIONS = {".tf", ".tfvars"}

# Infra keywords in filenames
_INFRA_NAME_RE = re.compile(r'(cloudformation|ansible|pulumi)', re.IGNORECASE)

MAX_TREE_DEPTH = 8
MAX_SAMPLE_SIZE = 2000  # chars per file


_DOT_DIRS_KEEP = {".github", ".circleci", ".buildkite", ".gitlab"}


def _should_skip_dir(name: str) -> bool:
    if name in _DOT_DIRS_KEEP:
        return False
    return name in SKIP_DIRS or name.startswith(".")


def _should_skip_file(name: str) -> bool:
    _, ext = os.path.splitext(name)
    return ext.lower() in SKIP_EXTENSIONS


def _collect_tree(root: str, max_depth: int = MAX_TREE_DEPTH) -> list[str]:
    """Collect file tree as list of relative paths."""
    files = []

    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root)
        depth = 0 if rel_dir == "." else rel_dir.count(os.sep) + 1

        if depth >= max_depth:
            dirnames.clear()
            continue

        # Filter directories in-place
        dirnames[:] = [d for d in dirnames if not _should_skip_dir(d)]

        for f in sorted(filenames):
            if _should_skip_file(f):
                continue
            rel_path = os.path.join(rel_dir, f) if rel_dir != "." else f
            files.append(rel_path)

    return sorted(files)


def _categorize_file(rel_path: str, root: str) -> str | None:
    """Assign a role category to a file based on its path, name, and content.

    Returns one of: 'ci_configs', 'test_files', 'dockerfiles', 'infra',
    'manifests', 'env_files', 'deploy_scripts', 'custom_scripts', or None.
    """
    # Normalize path separators for consistent matching
    norm_path = rel_path.replace(os.sep, "/")
    parts = norm_path.split("/")
    basename = parts[-1]
    _, ext = os.path.splitext(basename)
    ext = ext.lower()

    # --- CI configs ---
    for ci_dir in _CI_DIRS:
        if norm_path.startswith(ci_dir + "/") or ("/" + ci_dir + "/") in norm_path:
            return "ci_configs"
    if basename in _CI_FILENAMES:
        return "ci_configs"

    # --- Dockerfiles ---
    if basename.startswith("Dockerfile") or basename.startswith("docker-compose"):
        return "dockerfiles"

    # --- Infra ---
    if ext in _INFRA_EXTENSIONS or _INFRA_NAME_RE.search(basename):
        return "infra"

    # --- Manifests ---
    for pattern in _MANIFEST_PATTERNS:
        if pattern.search(basename):
            return "manifests"

    # --- Env files ---
    if basename.startswith(".env") or (
        any(d in ("config", "env") for d in parts[:-1]) and "env" in basename.lower()
    ):
        return "env_files"

    # --- Test files (by directory) ---
    if any(d in _TEST_DIRS for d in parts[:-1]):
        return "test_files"

    # --- Test files (by filename pattern) ---
    for pattern in _TEST_PATTERNS:
        if pattern.search(basename):
            return "test_files"

    # --- Deploy scripts (by filename) ---
    if _DEPLOY_NAME_RE.search(basename):
        return "deploy_scripts"

    # --- Scripts in scripts/bin/tools dirs ---
    if any(d in _SCRIPT_DIRS for d in parts[:-1]):
        if ext == ".sh":
            # Check content for deploy keywords
            full_path = os.path.join(root, rel_path)
            try:
                with open(full_path, "r", encoding="utf-8", errors="ignore") as fh:
                    head = fh.read(500)
                if _DEPLOY_CONTENT_RE.search(head):
                    return "deploy_scripts"
            except OSError:
                pass
            return "custom_scripts"
        # Non-sh files in script dirs are still custom scripts
        if ext in (".py", ".rb", ".js", ".ts", ".pl"):
            return "custom_scripts"

    return None


def _categorize_and_sample(
    root: str, file_list: list[str]
) -> tuple[dict[str, list[str]], str]:
    """Categorize all files and sample those with roles.

    Returns (summary_dict, samples_string).
    """
    summary: dict[str, list[str]] = {
        "manifests": [],
        "ci_configs": [],
        "deploy_scripts": [],
        "test_files": [],
        "dockerfiles": [],
        "infra": [],
        "env_files": [],
        "custom_scripts": [],
    }

    sampled_parts = []

    for rel_path in file_list:
        role = _categorize_file(rel_path, root)
        if role is None:
            continue

        summary[role].append(rel_path)

        # Sample all categorized files (no cap)
        full_path = os.path.join(root, rel_path)
        try:
            with open(full_path, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read(MAX_SAMPLE_SIZE)
            sampled_parts.append(f"=== {rel_path} ===\n{content}")
        except (OSError, UnicodeDecodeError):
            continue

    return summary, "\n\n".join(sampled_parts)


def scan_project(root: str = ".") -> dict:
    """Scan a project directory and return file_tree, samples, and summary.

    Returns dict with 'file_tree', 'samples', and 'summary' keys.
    The summary categorizes files by role (manifests, ci_configs, deploy_scripts,
    test_files, dockerfiles, infra, env_files, custom_scripts).
    """
    root = os.path.abspath(root)
    file_list = _collect_tree(root)
    file_tree = "\n".join(file_list)

    summary, samples = _categorize_and_sample(root, file_list)
    summary["total_files"] = len(file_list)

    return {
        "file_tree": file_tree,
        "samples": samples,
        "summary": summary,
    }
