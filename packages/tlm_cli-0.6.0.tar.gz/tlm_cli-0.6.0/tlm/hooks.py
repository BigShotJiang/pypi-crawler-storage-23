"""
TLM Hook Handlers — Interceptor hooks for Claude Code.

Server-backed intelligence with graceful degradation.

Active hooks (registered via build_all_hooks()):
    hook_bash_firewall          — PreToolUse (Bash): local regex + server review
    hook_auto_interviewer_plan  — PostToolUse (ExitPlanMode): plan review
    hook_stop                   — Stop: session cleanup + session learning
"""

import json
import re
import subprocess
import sys
import time as _time
from pathlib import Path

from tlm.state import read_state, write_state
from tlm.config import load_project_config, get_api_key, get_server_url
from tlm.client import TLMClient

# ANSI colors
_C = "\033[36m"   # cyan
_G = "\033[32m"   # green
_Y = "\033[33m"   # amber
_R = "\033[31m"   # red
_B = "\033[1m"    # bold
_D = "\033[2m"    # dim
_X = "\033[0m"    # reset


def _tlm_block(title: str, detail: str) -> dict:
    """Red stop — tool is blocked, reason shown to user directly."""
    bar = f"{_R}{'━' * 52}{_X}"
    return {
        "decision": "block",
        "reason": f"\n{bar}\n{_R}{_B}  ■ TLM — {title}{_X}\n{bar}\n\n{detail}\n\n{bar}\n",
    }


def _tlm_caution(title: str, detail: str) -> dict:
    """Yellow caution — Claude relays to user."""
    bar = f"{_Y}{'━' * 52}{_X}"
    visual = f"\n{bar}\n{_Y}{_B}  ▲ TLM — {title}{_X}\n{bar}\n\n{detail}\n\n{bar}\n"
    return {
        "additionalContext": (
            f"IMPORTANT — Display this TLM status to the user BEFORE your response:\n"
            f"```\n▲ TLM — {title}\n{detail}\n```\n"
            f"Then continue with your response.\n\n"
            f"Internal context: {visual}"
        ),
    }


def _tlm_ok(title: str, detail: str) -> dict:
    """Green OK — Claude relays to user."""
    bar = f"{_G}{'━' * 52}{_X}"
    visual = f"\n{bar}\n{_G}{_B}  ✓ TLM — {title}{_X}\n{bar}\n\n{detail}\n\n{bar}\n"
    return {
        "additionalContext": (
            f"IMPORTANT — Display this TLM status to the user BEFORE your response:\n"
            f"```\n✓ TLM — {title}\n{detail}\n```\n"
            f"Then continue with your response.\n\n"
            f"Internal context: {visual}"
        ),
    }


# ---------------------------------------------------------------------------
# Hook A — Auto-Interviewer (plan review + pre-commit diff review)
# ---------------------------------------------------------------------------

_PLANS_DIR = Path.home() / ".claude" / "plans"


def _find_latest_plan(plans_dir: Path = _PLANS_DIR) -> Path | None:
    """Find the most recently modified .md file in the plans directory."""
    if not plans_dir.exists():
        return None
    plan_files = sorted(plans_dir.glob("*.md"), key=lambda f: f.stat().st_mtime, reverse=True)
    return plan_files[0] if plan_files else None


def hook_auto_interviewer_plan(project_root: str, tool_input: dict, plans_dir: Path = _PLANS_DIR) -> dict:
    """PostToolUse on ExitPlanMode: review the approved plan before Claude writes code."""
    root = Path(project_root)
    if not (root / ".tlm").exists():
        return {}

    # Find the latest plan file
    plan_file = _find_latest_plan(plans_dir)
    if not plan_file:
        return {}

    try:
        plan_content = plan_file.read_text()
    except OSError:
        return {}

    if not plan_content or len(plan_content.strip()) < 20:
        return {}

    client = _get_review_client(project_root)
    if not client:
        return {}

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)

    sys.stderr.write("[TLM] Reviewing plan...\n")

    try:
        result = client.review_plan_or_diff(
            project_id,
            content=plan_content,
            review_type="plan",
            timeout=10,
        )
    except Exception:
        sys.stderr.write("[TLM] Server timeout on plan review. Allowing Claude to proceed.\n")
        return {}

    if result.get("decision") == "pass":
        sys.stderr.write("[TLM] Plan approved.\n")
        return {}

    # REJECT — return additionalContext that forces Claude to stop and clarify
    reason = result.get("reason", "Plan needs clarification.")
    issues = result.get("issues", [])
    issue_text = "\n".join(f"  - {i}" for i in issues) if issues else f"  - {reason}"

    return {
        "additionalContext": (
            f"[TLM REJECT]: Do not write code yet. The plan has issues:\n"
            f"{issue_text}\n\n"
            f"Ask the user for clarification on these before proceeding."
        )
    }


def _get_staged_diff(project_root: str) -> str | None:
    """Get the staged git diff. Returns None on failure."""
    try:
        result = subprocess.run(
            ["git", "diff", "--cached"],
            capture_output=True, text=True, cwd=project_root, timeout=10,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except (subprocess.TimeoutExpired, OSError):
        return None


def _review_diff_before_commit(project_root: str, command: str) -> dict:
    """Hook A trigger 2: send diff to server for senior staff review before commit."""
    diff = _get_staged_diff(project_root)
    if not diff or len(diff.strip()) < 10:
        return {}

    client = _get_review_client(project_root)
    if not client:
        return {}

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)

    sys.stderr.write("[TLM] Reviewing diff before commit...\n")

    try:
        result = client.review_plan_or_diff(
            project_id,
            content=diff,
            review_type="diff",
            timeout=10,
        )
    except Exception:
        sys.stderr.write("[TLM] Server timeout on pre-commit review. Allowing commit.\n")
        return {}

    if result.get("decision") == "pass":
        sys.stderr.write("[TLM] Diff approved.\n")
        return {}

    # REJECT — block the commit
    reason = result.get("reason", "Code review found issues.")
    issues = result.get("issues", [])
    issue_text = "\n".join(f"  - {i}" for i in issues) if issues else f"  - {reason}"

    return _tlm_block(
        "PRE-COMMIT REVIEW FAILED",
        f"  Issues found:\n{issue_text}\n\n  Fix these before committing."
    )


# ---------------------------------------------------------------------------
# Hook B — Execution Firewall
# ---------------------------------------------------------------------------

_RISKY_PATTERNS = [
    # Deploy/publish
    r'\b(firebase|vercel|netlify|fly|railway|render|heroku)\s+deploy\b',
    r'\b(eb|sam|serverless|cdk)\s+deploy\b',
    r'\bgcloud\s+app\s+deploy\b',
    r'\bkubectl\s+(apply|delete|replace)\b',
    r'\bdocker\s+push\b',
    r'\bhelm\s+(install|upgrade|delete)\b',
    r'\bgit\s+push\s+.*\b(prod|production|main|master)\b',
    r'\bterraform\s+(apply|destroy)\b',
    # Destructive
    r'\brm\s+-[rRfF]*[rRfF]\b',
    r'\brm\s+--force\b',
    r'\bdrop\s+(database|table|schema)\b',
    r'\btruncate\s+table\b',
    # Risky keywords in scripts/ or bin/ paths
    r'(scripts|bin)/\S*(deploy|release|publish)',
]

_COMPILED_RISKY = [re.compile(p, re.IGNORECASE) for p in _RISKY_PATTERNS]


def _matches_risky_pattern(command: str) -> bool:
    """Check if command matches any risky regex pattern."""
    for pattern in _COMPILED_RISKY:
        if pattern.search(command):
            return True
    return False


def _load_permanent_overrides(project_root: str) -> list[str]:
    """Load permanently overridden commands from .tlm/permanent_overrides.json."""
    overrides_file = Path(project_root) / ".tlm" / "permanent_overrides.json"
    if not overrides_file.exists():
        return []
    try:
        data = json.loads(overrides_file.read_text())
        return data.get("commands", [])
    except (json.JSONDecodeError, OSError):
        return []


def _is_permanently_overridden(project_root: str, command: str) -> bool:
    """Check if a command has been permanently overridden."""
    overrides = _load_permanent_overrides(project_root)
    return command.strip() in overrides


def _add_permanent_override(project_root: str, command: str):
    """Add a command to the permanent overrides list."""
    overrides_file = Path(project_root) / ".tlm" / "permanent_overrides.json"
    overrides = _load_permanent_overrides(project_root)
    cmd = command.strip()
    if cmd not in overrides:
        overrides.append(cmd)
    overrides_file.write_text(json.dumps({"commands": overrides}, indent=2))


def _log_override(project_root: str, command: str, reason: str, action: str):
    """Append override event to .tlm/overrides.log."""
    import datetime
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    try:
        with open(Path(project_root) / ".tlm" / "overrides.log", "a") as f:
            f.write(f"{ts} | {action} | {command} | {reason}\n")
    except OSError:
        pass


def _handle_block_with_override(project_root: str, command: str, reason: str) -> dict:
    """Display block UI with override options. Returns {} to allow or block dict."""
    sys.stderr.write(f"\n{'━' * 52}\n")
    sys.stderr.write(f"  ■ TLM — COMMAND BLOCKED\n")
    sys.stderr.write(f"{'━' * 52}\n\n")
    sys.stderr.write(f"  Command: {command}\n")
    sys.stderr.write(f"  Reason:  {reason}\n\n")
    sys.stderr.write(f"  [1] Override once\n")
    sys.stderr.write(f"  [2] Override always (never block this again)\n")
    sys.stderr.write(f"  [N] Block (default)\n\n")

    try:
        choice = input("  Choice: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        choice = "n"

    if choice == "1":
        _log_override(project_root, command, reason, "OVERRIDE_ONCE")
        return {}  # allow

    if choice == "2":
        _log_override(project_root, command, reason, "OVERRIDE_ALWAYS")
        _add_permanent_override(project_root, command)
        return {}  # allow + remember

    _log_override(project_root, command, reason, "BLOCKED")
    return _tlm_block("COMMAND BLOCKED", f"  {reason}")


def _is_git_commit(command: str) -> bool:
    """Check if a shell command is a git commit."""
    return bool(re.search(r'\bgit\s+commit\b', command))


def hook_bash_firewall(project_root: str, tool_input: dict) -> dict:
    """PreToolUse on Bash: local regex pre-filter + server escalation."""
    command = tool_input.get("command", "")
    root = Path(project_root)
    if not (root / ".tlm").exists():
        return {}

    # Hook A: git commit → separate review path (10s timeout)
    if _is_git_commit(command):
        return _review_diff_before_commit(project_root, command)

    # Check permanent overrides
    if _is_permanently_overridden(project_root, command):
        return {}

    # Step 1: Local regex pre-filter (< 500ms)
    if not _matches_risky_pattern(command):
        return {}  # safe command, pass instantly

    # Step 2: Server escalation (10s timeout)
    client = _get_review_client(project_root)
    if not client:
        return {}  # no auth, fail-open

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)

    sys.stderr.write("[TLM] Reviewing command...\n")

    try:
        result = client.review_command(
            project_id, command, timeout=10,
        )
    except Exception:
        sys.stderr.write("[TLM] Server timeout on command review. Allowing command to proceed.\n")
        return {}  # fail-open on timeout

    if result.get("decision") == "pass":
        sys.stderr.write("[TLM] Command approved.\n")
        return {}

    # BLOCKED — interactive override
    reason = result.get("reason", "Command flagged as risky.")
    return _handle_block_with_override(project_root, command, reason)


# ---------------------------------------------------------------------------
# Stop — session cleanup + session learning
# ---------------------------------------------------------------------------

def hook_stop(project_root: str) -> dict:
    """Stop hook: session cleanup + session learning."""
    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return {}

    # Session learning: analyze captured prompts before cleanup
    prompts_file = tlm_dir / "session_prompts.jsonl"
    if prompts_file.exists():
        try:
            prompts = []
            for line in prompts_file.read_text().strip().split("\n"):
                if line.strip():
                    prompts.append(json.loads(line))
            if prompts:
                try:
                    _run_session_learning(project_root, prompts)
                except Exception:
                    pass  # Never crash on learning failure
        except (json.JSONDecodeError, OSError):
            pass
        # Clean up prompts file
        prompts_file.unlink(missing_ok=True)

    # Reset tlm_active to idle (interview didn't complete this session)
    state = read_state(project_root)
    state.pop("plan_review_pending", None)
    if state.get("phase") == "tlm_active":
        state["phase"] = "idle"
    write_state(project_root, state)

    return {}


# ─── Internal helpers ─────────────────────────────────────────

def _get_review_client(project_root: str) -> TLMClient | None:
    """Create a TLMClient from saved credentials. Returns None if not authenticated."""
    api_key = get_api_key()
    if not api_key:
        return None
    server_url = get_server_url()
    return TLMClient(server_url=server_url, api_key=api_key)


def _run_session_learning(project_root: str, prompts: list[dict]):
    """Run session learning: send transcript to server. Rules stored server-side only."""
    client = _get_review_client(project_root)
    if not client:
        return

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)

    # Build summary from prompts
    prompt_texts = [p.get("prompt", "") for p in prompts if p.get("prompt")]
    summary = "\n".join(f"- {t}" for t in prompt_texts)

    try:
        client.sync_session(project_id, summary)  # fire and forget
    except Exception:
        pass  # never crash on learning failure
