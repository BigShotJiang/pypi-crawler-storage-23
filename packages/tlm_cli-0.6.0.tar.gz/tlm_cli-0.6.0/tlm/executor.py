"""Executor — Claude Code subprocess invocation for plan and execute phases."""

import subprocess
import shutil


class Executor:
    """Two-phase Claude Code invocation: plan then execute."""

    def __init__(self, claude_path: str = None):
        self.claude_path = claude_path or shutil.which("claude") or "claude"

    def plan(self, system_prompt: str, instructions: str) -> str:
        """Phase 1: Generate plan using Claude Code in print mode.

        Returns the plan output text.
        """
        prompt = (
            f"{system_prompt}\n\n"
            f"## Instructions\n{instructions}\n\n"
            "Generate a detailed implementation plan. "
            "Output the plan as markdown. Do NOT execute anything yet."
        )

        result = subprocess.run(
            [self.claude_path, "-p", prompt],
            capture_output=True,
            text=True,
            timeout=300,
        )

        return result.stdout or result.stderr or ""

    def execute(self, plan: str) -> str:
        """Phase 2: Execute the approved plan using Claude Code.

        Returns the execution output.
        """
        prompt = (
            f"Execute the following implementation plan:\n\n{plan}\n\n"
            "Create all files and configurations as specified. "
            "Follow the plan exactly."
        )

        result = subprocess.run(
            [self.claude_path, "-p", prompt],
            capture_output=True,
            text=True,
            timeout=600,
        )

        return result.stdout or result.stderr or ""
