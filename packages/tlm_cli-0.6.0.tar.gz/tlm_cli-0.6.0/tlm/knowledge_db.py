"""
TLM Knowledge Store -- SQLite with vector search.

Stores rules, specs, commits, and metrics in .tlm/knowledge.db.
Embeddings stored as BLOB for cosine similarity search.
"""

import json
import sqlite3
import struct
import datetime
from pathlib import Path
from typing import Optional


class KnowledgeDB:
    """SQLite-backed knowledge store with vector search."""

    def __init__(self, tlm_dir: str):
        self.tlm_dir = Path(tlm_dir)
        self.db_path = self.tlm_dir / "knowledge.db"
        self._conn = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
        return self._conn

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    def init_db(self):
        """Create tables if they don't exist."""
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                rule_text TEXT NOT NULL,
                source TEXT NOT NULL DEFAULT 'base',
                source_commit TEXT,
                relevance_tags TEXT DEFAULT '[]',
                embedding BLOB,
                created_at TEXT NOT NULL,
                approved INTEGER DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS specs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                feature_name TEXT NOT NULL,
                spec_content TEXT NOT NULL,
                review_result TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS commits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hash TEXT UNIQUE NOT NULL,
                category TEXT,
                related_spec_id INTEGER,
                patterns_extracted TEXT DEFAULT '[]',
                analyzed_at TEXT NOT NULL,
                FOREIGN KEY (related_spec_id) REFERENCES specs(id)
            );

            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                week_number TEXT NOT NULL,
                spec_accuracy REAL,
                total_commits INTEGER DEFAULT 0,
                planned_commits INTEGER DEFAULT 0,
                unplanned_commits INTEGER DEFAULT 0,
                bugs_caught_by_review INTEGER DEFAULT 0
            );
        """)
        self.conn.commit()

    # --- Rules ---

    def add_rule(
        self,
        text: str,
        source: str = "base",
        tags: list[str] = None,
        embedding: list[float] = None,
        source_commit: str = None,
    ) -> int:
        now = datetime.datetime.now().isoformat()
        tags_json = json.dumps(tags or [])
        emb_blob = _vec_to_blob(embedding) if embedding else None

        cursor = self.conn.execute(
            """INSERT INTO rules (rule_text, source, source_commit, relevance_tags, embedding, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (text, source, source_commit, tags_json, emb_blob, now),
        )
        self.conn.commit()
        return cursor.lastrowid

    def disable_rule(self, rule_id: int):
        self.conn.execute("UPDATE rules SET approved = 0 WHERE id = ?", (rule_id,))
        self.conn.commit()

    def enable_rule(self, rule_id: int):
        self.conn.execute("UPDATE rules SET approved = 1 WHERE id = ?", (rule_id,))
        self.conn.commit()

    def list_rules(self, include_disabled: bool = False) -> list[dict]:
        if include_disabled:
            rows = self.conn.execute("SELECT * FROM rules ORDER BY id").fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM rules WHERE approved = 1 ORDER BY id"
            ).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_rule(self, rule_id: int) -> Optional[dict]:
        row = self.conn.execute("SELECT * FROM rules WHERE id = ?", (rule_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def search_rules(self, query_embedding: list[float], limit: int = 5) -> list[dict]:
        """Find most relevant rules using cosine similarity."""
        rows = self.conn.execute(
            "SELECT * FROM rules WHERE approved = 1 AND embedding IS NOT NULL"
        ).fetchall()

        if not rows:
            rows = self.conn.execute(
                "SELECT * FROM rules WHERE approved = 1 ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [_row_to_dict(r) for r in rows]

        scored = []
        for row in rows:
            stored_vec = _blob_to_vec(row["embedding"])
            if stored_vec:
                score = _cosine_similarity(query_embedding, stored_vec)
                scored.append((score, row))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [_row_to_dict(r) for _, r in scored[:limit]]

    def search_rules_by_tags(self, tags: list[str], limit: int = 5) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM rules WHERE approved = 1 ORDER BY id DESC"
        ).fetchall()

        matched = []
        tags_lower = {t.lower() for t in tags}
        for row in rows:
            try:
                rule_tags = json.loads(row["relevance_tags"] or "[]")
                rule_tags_lower = {t.lower() for t in rule_tags}
                if rule_tags_lower & tags_lower:
                    matched.append(_row_to_dict(row))
            except json.JSONDecodeError:
                pass
            if len(matched) >= limit:
                break

        return matched

    # --- Specs ---

    def add_spec(self, feature_name: str, spec_content: str, review_result: dict = None) -> int:
        now = datetime.datetime.now().isoformat()
        review_json = json.dumps(review_result) if review_result else None
        cursor = self.conn.execute(
            """INSERT INTO specs (feature_name, spec_content, review_result, created_at)
               VALUES (?, ?, ?, ?)""",
            (feature_name, spec_content, review_json, now),
        )
        self.conn.commit()
        return cursor.lastrowid

    def list_specs(self) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM specs ORDER BY id DESC").fetchall()
        return [_row_to_dict(r) for r in rows]

    # --- Commits ---

    def add_commit(self, hash: str, category: str = None,
                   related_spec_id: int = None, patterns_extracted: list = None) -> int:
        now = datetime.datetime.now().isoformat()
        patterns_json = json.dumps(patterns_extracted or [])
        try:
            cursor = self.conn.execute(
                """INSERT OR IGNORE INTO commits (hash, category, related_spec_id, patterns_extracted, analyzed_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (hash, category, related_spec_id, patterns_json, now),
            )
            self.conn.commit()
            return cursor.lastrowid
        except sqlite3.IntegrityError:
            return 0

    def list_commits(self, limit: int = 50) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM commits ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [_row_to_dict(r) for r in rows]

    # --- Metrics ---

    def add_metric(self, week_number: str, spec_accuracy: float = 0,
                   total_commits: int = 0, planned_commits: int = 0,
                   unplanned_commits: int = 0, bugs_caught_by_review: int = 0) -> int:
        cursor = self.conn.execute(
            """INSERT INTO metrics (week_number, spec_accuracy, total_commits,
               planned_commits, unplanned_commits, bugs_caught_by_review)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (week_number, spec_accuracy, total_commits, planned_commits,
             unplanned_commits, bugs_caught_by_review),
        )
        self.conn.commit()
        return cursor.lastrowid

    def list_metrics(self, limit: int = 20) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM metrics ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [_row_to_dict(r) for r in rows]

    # --- Migration ---

    def migrate_from_flat_files(self):
        """Import data from existing flat files into SQLite."""
        imported = {"rules": 0, "commits": 0, "specs": 0, "metrics": 0}

        knowledge_file = self.tlm_dir / "knowledge.md"
        if knowledge_file.exists():
            content = knowledge_file.read_text()
            for line in content.split("\n"):
                line = line.strip()
                if not line or line.startswith(("#", "---", "_")):
                    continue
                if line.startswith("- "):
                    line = line[2:]
                if len(line) > 10:
                    self.add_rule(line, source="migrated_from_knowledge_md")
                    imported["rules"] += 1

        lessons_dir = self.tlm_dir / "lessons"
        if lessons_dir.exists():
            for f in sorted(lessons_dir.glob("*-synthesis.json")):
                try:
                    synthesis = json.loads(f.read_text())
                except (json.JSONDecodeError, OSError):
                    continue
                week = synthesis.get("period", f.stem[:10])
                self.add_metric(
                    week_number=week,
                    spec_accuracy=synthesis.get("spec_accuracy_percent", 0),
                    total_commits=synthesis.get("total_commits", 0),
                    planned_commits=synthesis.get("planned_commits", 0),
                    unplanned_commits=synthesis.get("unplanned_commits", 0),
                )
                imported["metrics"] += 1
                for imp in synthesis.get("interview_improvements", []):
                    self.add_rule(imp, source="migrated_from_synthesis", tags=["interview"])
                    imported["rules"] += 1

        commits_dir = self.tlm_dir / "commits"
        if commits_dir.exists():
            for f in sorted(commits_dir.glob("*.json")):
                try:
                    data = json.loads(f.read_text())
                except (json.JSONDecodeError, OSError):
                    continue
                commit_hash = data.get("hash", f.stem.replace("-processed", ""))
                self.add_commit(
                    hash=commit_hash,
                    category=data.get("category"),
                    patterns_extracted=data.get("lessons", []),
                )
                imported["commits"] += 1

        specs_dir = self.tlm_dir / "specs"
        if specs_dir.exists():
            for f in sorted(specs_dir.glob("*.md")):
                try:
                    content = f.read_text()
                except OSError:
                    continue
                lines = content.split("\n")
                name = next(
                    (l.lstrip("# ").strip() for l in lines if l.startswith("# ")),
                    f.stem,
                )
                self.add_spec(feature_name=name, spec_content=content)
                imported["specs"] += 1

        return imported


# --- Vector helpers ---

def _vec_to_blob(vec: list[float]) -> bytes:
    return struct.pack(f"{len(vec)}f", *vec)


def _blob_to_vec(blob: bytes) -> list[float]:
    if not blob:
        return []
    n = len(blob) // 4
    return list(struct.unpack(f"{n}f", blob))


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sum(x * x for x in a) ** 0.5
    norm_b = sum(x * x for x in b) ** 0.5
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def _row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    for key in ("relevance_tags", "review_result", "patterns_extracted"):
        if key in d and isinstance(d[key], str):
            try:
                d[key] = json.loads(d[key])
            except (json.JSONDecodeError, TypeError):
                pass
    if "embedding" in d:
        d["has_embedding"] = d["embedding"] is not None
        del d["embedding"]
    return d
