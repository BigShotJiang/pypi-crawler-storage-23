- [Tecnativa](https://www.tecnativa.com):
  - David Vidal

- [Sygel](https://www.sygel.es):
  - Valentín Vinagre
  - Roger Sans
