- Modifiying the original demand after the forcing could lead to
  misscalculations.
