"""
Empty setup.py for amplifier-env-common
"""
from setuptools import setup

setup(
    name="amplifier-env-common",
    version="0.0.0",
    description="Empty placeholder package - reserved name",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
