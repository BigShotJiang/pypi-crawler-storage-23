DELETE FROM
  oban_leaders
WHERE
  name = %(name)s AND node = %(node)s
