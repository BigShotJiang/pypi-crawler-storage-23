TRUNCATE TABLE
  oban_jobs,
  oban_leaders,
  oban_producers
RESTART IDENTITY CASCADE
