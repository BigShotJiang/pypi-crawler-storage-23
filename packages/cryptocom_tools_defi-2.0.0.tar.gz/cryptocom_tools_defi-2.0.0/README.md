# cryptocom-tools-defi

DeFi tools for Crypto.com Developer Platform.

## Installation

```bash
pip install cryptocom-tools-defi
```

## Tools

### Read Tools

- **GetFarmsTool** - Get all farms for a DeFi protocol
- **GetFarmDetailsTool** - Get details for a specific farm by symbol
- **GetWhitelistedTokensTool** - Get whitelisted tokens for a protocol

## Usage

```python
from cryptocom_tools_defi import GetFarmsTool, GetFarmDetailsTool, GetWhitelistedTokensTool

# Get all farms on VVS
farms_tool = GetFarmsTool()
result = farms_tool.invoke({"protocol": "VVS"})

# Get specific farm details
farm_tool = GetFarmDetailsTool()
result = farm_tool.invoke({"protocol": "VVS", "symbol": "CRO-USDC"})

# Get whitelisted tokens
tokens_tool = GetWhitelistedTokensTool()
result = tokens_tool.invoke({"protocol": "VVS"})
```

## Environment Variables

- `CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY` - Your CDP API key (auto-read by CDPTool)

## License

MIT
