"""Shared result classes for DeFi read tools."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from cryptocom_tools_core import ToolResult


@dataclass
class FarmResult(ToolResult):
    """Result from farm query tools."""

    symbol: str
    protocol: str
    apr: float
    tvl: float
    rewards: list[str]

    def _format_result(self) -> str:
        rewards_str = ", ".join(self.rewards) if self.rewards else "None"
        return (
            f"{self.symbol} on {self.protocol}: "
            f"APR {self.apr:.2f}%, TVL ${self.tvl:,.0f}, "
            f"Rewards: {rewards_str}"
        )


@dataclass
class TokenListResult(ToolResult):
    """Result from token whitelist query."""

    protocol: str
    tokens: list[dict[str, Any]]

    def _format_result(self) -> str:
        token_count = len(self.tokens)
        return f"Found {token_count} whitelisted tokens on {self.protocol}"


__all__ = ["FarmResult", "TokenListResult"]
