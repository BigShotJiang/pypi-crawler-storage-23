"""GetFarmDetailsTool - Get details for a specific DeFi farm."""

from __future__ import annotations

from typing import Any

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field

from ._results import FarmResult


class GetFarmDetailsInput(BaseModel):
    """Input schema for GetFarmDetailsTool."""

    protocol: str = Field(description="The DeFi protocol name (e.g., VVS, MMF)")
    symbol: str = Field(description="The farm symbol (e.g., CRO-USDC, VVS-CRO)")


class GetFarmDetailsTool(CDPTool):
    """
    Get information about a specific DeFi farm by symbol.

    Example:
        tool = GetFarmDetailsTool()
        result = tool.invoke({"protocol": "VVS", "symbol": "CRO-USDC"})
    """

    name: str = "get_farm_details"
    description: str = "Get information about a specific DeFi farm by its symbol"
    args_schema: type[BaseModel] = GetFarmDetailsInput  # type: ignore[assignment]

    def _run(self, protocol: str, symbol: str) -> str:  # type: ignore[override]
        """Get farm information by symbol."""
        from crypto_com_developer_platform_client import Defi
        from crypto_com_developer_platform_client.interfaces.defi_interfaces import DefiProtocol

        try:
            protocol_enum = DefiProtocol[protocol.upper()]
            response: Any = Defi.get_farm_by_symbol(protocol_enum, symbol)

            if isinstance(response, dict):
                if response.get("status") == "Success":
                    farm_data = response.get("data", {})
                else:
                    farm_data = response
            else:
                return f"Farm {symbol} not found on {protocol}"

            if isinstance(farm_data, dict):
                result = FarmResult(
                    symbol=symbol,
                    protocol=protocol,
                    apr=float(farm_data.get("apr", 0.0)),
                    tvl=float(farm_data.get("tvl", 0.0)),
                    rewards=farm_data.get("rewards", []),
                )
                return str(result)

            return f"Farm information for {symbol} in {protocol}: {response}"

        except KeyError:
            return f"Unknown protocol: {protocol}. Valid protocols: VVS, H2, TECTONIC, FERRO"
        except Exception as e:
            return f"Error getting farm {symbol}: {e!s}"


__all__ = ["GetFarmDetailsInput", "GetFarmDetailsTool"]
