"""GetFarmsTool - Get all farms for a DeFi protocol."""

from __future__ import annotations

from typing import Any

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field

from ._results import FarmResult


class GetFarmsInput(BaseModel):
    """Input schema for GetFarmsTool."""

    protocol: str = Field(
        default="VVS",
        description="The DeFi protocol name (e.g., VVS, MMF, TECTONIC, FERRO)",
    )


class GetFarmsTool(CDPTool):
    """
    Get information about all available DeFi farms for a protocol.

    Example:
        tool = GetFarmsTool()
        result = tool.invoke({"protocol": "VVS"})
    """

    name: str = "get_farms"
    description: str = "Get information about all available DeFi farms for a protocol"
    args_schema: type[BaseModel] = GetFarmsInput  # type: ignore[assignment]

    def _run(self, protocol: str = "VVS") -> str:  # type: ignore[override]
        """Get all farms for a DeFi protocol."""
        from crypto_com_developer_platform_client import Defi
        from crypto_com_developer_platform_client.interfaces.defi_interfaces import DefiProtocol

        try:
            protocol_enum = DefiProtocol[protocol.upper()]
            response: Any = Defi.get_all_farms(protocol_enum)

            # Handle wrapped response
            if (
                isinstance(response, dict)
                and response.get("status") == "Success"
                or isinstance(response, dict)
                and "data" in response
            ):
                farms_data = response.get("data", [])
            else:
                farms_data = response if isinstance(response, list) else []

            if not farms_data:
                return f"No farms found for protocol {protocol}"

            # Ensure farms_data is a list for slicing
            farms_list = list(farms_data) if isinstance(farms_data, list) else []

            # Try to parse structured data, fallback to raw
            results = []
            for farm in farms_list[:10]:  # Limit to first 10
                if isinstance(farm, dict):
                    # API uses: lpSymbol, baseApr/baseApy, rewarders
                    symbol = farm.get("lpSymbol") or farm.get("symbol") or "Unknown"
                    apr = farm.get("baseApr") or farm.get("baseApy") or farm.get("apr") or 0.0
                    tvl = farm.get("tvl") or farm.get("liquidity") or 0.0

                    # Extract reward tokens from rewarders array
                    rewarders = farm.get("rewarders") or []
                    rewards: list[str] = []
                    for rewarder in rewarders:
                        if isinstance(rewarder, dict):
                            token = rewarder.get("token", {})
                            if isinstance(token, dict) and token.get("symbol"):
                                rewards.append(token["symbol"])

                    result = FarmResult(
                        symbol=str(symbol),
                        protocol=protocol,
                        apr=float(apr) if apr else 0.0,
                        tvl=float(tvl) if tvl else 0.0,
                        rewards=rewards,
                    )
                    results.append(str(result))

            if results:
                return f"Found {len(farms_data)} farms on {protocol}:\n" + "\n".join(results)

            # Fallback: return raw response summary
            return f"All farms for {protocol}: {len(farms_data)} farms available"

        except KeyError:
            return f"Unknown protocol: {protocol}. Valid protocols: VVS, H2, TECTONIC, FERRO"
        except Exception as e:
            return f"Error getting farms: {e!s}"


__all__ = ["GetFarmsInput", "GetFarmsTool"]
