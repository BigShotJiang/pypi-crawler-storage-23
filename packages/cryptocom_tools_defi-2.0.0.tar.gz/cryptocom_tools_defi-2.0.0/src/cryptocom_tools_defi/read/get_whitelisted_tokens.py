"""GetWhitelistedTokensTool - Get whitelisted tokens for a DeFi protocol."""

from __future__ import annotations

from typing import Any

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field

from ._results import TokenListResult


class GetWhitelistedTokensInput(BaseModel):
    """Input schema for GetWhitelistedTokensTool."""

    protocol: str = Field(
        default="VVS",
        description="The DeFi protocol name (e.g., VVS, MMF, TECTONIC, FERRO)",
    )


class GetWhitelistedTokensTool(CDPTool):
    """
    Get whitelisted tokens for a DeFi protocol.

    Example:
        tool = GetWhitelistedTokensTool()
        result = tool.invoke({"protocol": "VVS"})
    """

    name: str = "get_whitelisted_tokens"
    description: str = "Get list of whitelisted tokens for a DeFi protocol"
    args_schema: type[BaseModel] = GetWhitelistedTokensInput  # type: ignore[assignment]

    def _run(self, protocol: str = "VVS") -> str:  # type: ignore[override]
        """Get whitelisted tokens for a protocol."""
        from crypto_com_developer_platform_client import Defi
        from crypto_com_developer_platform_client.interfaces.defi_interfaces import DefiProtocol

        try:
            protocol_enum = DefiProtocol[protocol.upper()]
            response: Any = Defi.get_whitelisted_tokens(protocol_enum)

            if isinstance(response, dict) and response.get("status") == "Success":
                tokens_data = response.get("data", [])
            elif isinstance(response, list):
                tokens_data = response
            else:
                tokens_data = []

            tokens = []
            for token in tokens_data:
                if isinstance(token, dict):
                    tokens.append(
                        {
                            "symbol": token.get("symbol", "Unknown"),
                            "name": token.get("name", "Unknown Token"),
                            "address": token.get("address", ""),
                            "decimals": token.get("decimals", 18),
                        }
                    )

            result = TokenListResult(protocol=protocol, tokens=tokens)
            token_symbols = [t["symbol"] for t in tokens[:20]]
            if token_symbols:
                return f"{result}\nTokens: {', '.join(token_symbols)}{'...' if len(tokens) > 20 else ''}"
            return f"Whitelisted tokens for {protocol}: {response}"

        except KeyError:
            return f"Unknown protocol: {protocol}. Valid protocols: VVS, H2, TECTONIC, FERRO"
        except Exception as e:
            return f"Error getting tokens: {e!s}"


__all__ = ["GetWhitelistedTokensInput", "GetWhitelistedTokensTool"]
