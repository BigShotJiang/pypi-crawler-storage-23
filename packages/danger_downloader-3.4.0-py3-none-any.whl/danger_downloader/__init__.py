from .core import auto_download, detect_platform
from .cli import main