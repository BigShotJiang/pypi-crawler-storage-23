"""Heartbeat service types."""
