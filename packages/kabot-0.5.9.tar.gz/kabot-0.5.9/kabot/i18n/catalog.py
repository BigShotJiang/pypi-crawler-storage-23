"""Translation catalog for deterministic system and tool responses."""

from __future__ import annotations

from typing import Any

from kabot.i18n.locale import detect_locale

_KEY_ALIASES: dict[str, str] = {
    # Legacy keys kept for backward compatibility.
    "weather_need_location": "weather.need_location",
    "cron_remove_need_selector": "cron.remove.need_selector",
    "cron_update_need_selector": "cron.update.need_selector",
    "cron_update_incomplete": "cron.update.incomplete",
    "cron_time_unclear": "cron.time_unclear",
    "cycle_created": "cron.cycle_created",
}

_CATALOG: dict[str, dict[str, str]] = {
    "en": {
        "weather.need_location": "I need a location to check the weather. Example: check weather in Cilacap.",
        "cron.remove.need_selector": "To remove a schedule, provide `group_id` or schedule title. First run: `list reminder` to see groups.",
        "cron.update.need_selector": "To edit a schedule, provide `group_id` or schedule title. First run: `list reminder` to see groups.",
        "cron.update.incomplete": "Edit format is incomplete. Example: `update schedule grp_shift_a every 12 hours` or `rename grp_shift_a to Shift Team A`.",
        "cron.time_unclear": "I could not determine the reminder time. Example: remind me in 2 minutes, every day at 09:00 standup, or every 4 hours drink water.",
        "cron.cycle_created": "Created cycle '{title}' (group_id: {group_id}) with {job_count} jobs; repeats every {period_days} days.",
        "cron.add.error_message_required": "Error: message is required to create a schedule.",
        "cron.add.error_no_session_context": "Error: no session context available (channel/chat_id).",
        "cron.add.error_schedule_invalid": "Error: invalid schedule ({error}).",
        "cron.add.error_schedule_required": "Error: either at_time, every_seconds, or cron_expr is required.",
        "cron.add.error_policy_violation": "Error: schedule policy rejected this request ({error}).",
        "cron.add.created": "Created job '{name}' (id: {job_id})",
        "cron.add.created_group": "Created job '{name}' (id: {job_id}, group: {group_id}, title: {title})",
        "cron.list.empty": "No scheduled jobs.",
        "cron.list.header": "Scheduled jobs:",
        "cron.list_groups.empty": "No grouped schedules.",
        "cron.list_groups.header": "Schedule groups:",
        "cron.remove.error_job_id_required": "Error: job_id is required for remove.",
        "cron.remove.ok": "Removed job {job_id}",
        "cron.remove.not_found": "Job {job_id} not found",
        "cron.remove_group.error_not_found": "Error: group not found. Provide a valid group_id or title.",
        "cron.remove_group.ok": "Removed group '{title}' ({group_id}) with {removed} jobs",
        "cron.update.error_job_id_required": "Error: job_id is required for update.",
        "cron.update.ok": "Updated job '{name}' ({job_id})",
        "cron.update.not_found": "Job {job_id} not found",
        "cron.update_group.error_not_found": "Error: group not found. Provide a valid group_id or title.",
        "cron.update_group.error_schedule_invalid": "Error: invalid schedule ({error}).",
        "cron.update_group.error_nothing_to_update": "Error: nothing to update. Provide message, schedule, or new_title.",
        "cron.update_group.ok": "Updated group '{title}' ({group_id}) with {updated} jobs",
        "cron.run.error_job_id_required": "Error: job_id is required for run.",
        "cron.run.ok": "Executed job {job_id}",
        "cron.run.not_found": "Job {job_id} not found or disabled",
        "cron.runs.error_job_id_required": "Error: job_id is required for runs.",
        "cron.runs.empty": "No run history for job {job_id}",
        "cron.runs.header": "Run history for {job_id}:",
        "cron.status.running": "Running",
        "cron.status.stopped": "Stopped",
        "cron.status.summary": "Cron Service: {service_state}\nJobs: {jobs}\nNext wake: {next_wake}",
        "update.check.available": "Update available: {latest_version} (current: {current_version})",
        "update.check.up_to_date": "You're running the latest version: {current_version}",
        "update.check.commits_behind": "Your installation is {commits_behind} commits behind the latest release.",
        "update.check.error": "Could not check for updates: {error}",
        "update.install.success": "Successfully updated from {old_version} to {new_version}. Restart required.",
        "update.install.restart_confirm": "Update complete. Restart Kabot now?",
        "update.install.dirty_tree": "Cannot update: uncommitted changes in working tree. Please commit or stash first.",
        "update.install.failed": "Update failed: {error}",
        "runtime.status.queued": "Queued. Preparing your request...",
        "runtime.status.queued_merged": "Merged {count} queued message(s).",
        "runtime.status.thinking": "Processing your request, please wait...",
        "runtime.status.tool": "Running the required tools, please wait...",
        "runtime.status.done": "Done.",
        "runtime.status.error": "An error occurred while processing your request.",
    },
    "id": {
        "weather.need_location": "Saya butuh lokasi untuk cek cuaca. Contoh: cek suhu Cilacap.",
        "cron.remove.need_selector": "Untuk hapus jadwal, sebutkan `group_id` atau judul jadwal. Gunakan dulu: `list reminder` untuk melihat daftar grup.",
        "cron.update.need_selector": "Untuk edit jadwal, sebutkan `group_id` atau judul jadwal. Gunakan dulu: `list reminder` untuk melihat daftar grup.",
        "cron.update.incomplete": "Format edit belum lengkap. Contoh: `ubah jadwal grp_shift_a tiap 12 jam` atau `ubah judul grp_shift_a jadi Shift Team A`.",
        "cron.time_unclear": "Saya belum bisa memastikan waktu pengingat. Contoh: ingatkan 2 menit lagi makan, setiap hari jam 09:00 standup, atau tiap 4 jam minum air.",
        "cron.cycle_created": "Siklus '{title}' berhasil dibuat (group_id: {group_id}) dengan {job_count} job; berulang tiap {period_days} hari.",
        "cron.add.error_message_required": "Error: pesan wajib diisi untuk membuat jadwal.",
        "cron.add.error_no_session_context": "Error: konteks sesi tidak tersedia (channel/chat_id).",
        "cron.add.error_schedule_invalid": "Error: jadwal tidak valid ({error}).",
        "cron.add.error_schedule_required": "Error: isi salah satu at_time, every_seconds, atau cron_expr.",
        "cron.add.error_policy_violation": "Error: kebijakan scheduler menolak permintaan ini ({error}).",
        "cron.add.created": "Berhasil membuat job '{name}' (id: {job_id})",
        "cron.add.created_group": "Berhasil membuat job '{name}' (id: {job_id}, grup: {group_id}, judul: {title})",
        "cron.list.empty": "Tidak ada job terjadwal.",
        "cron.list.header": "Daftar job:",
        "cron.list_groups.empty": "Tidak ada grup jadwal.",
        "cron.list_groups.header": "Grup jadwal:",
        "cron.remove.error_job_id_required": "Error: job_id wajib untuk hapus.",
        "cron.remove.ok": "Berhasil menghapus job {job_id}",
        "cron.remove.not_found": "Job {job_id} tidak ditemukan",
        "cron.remove_group.error_not_found": "Error: grup tidak ditemukan. Berikan group_id atau judul yang valid.",
        "cron.remove_group.ok": "Berhasil menghapus grup '{title}' ({group_id}) dengan {removed} job",
        "cron.update.error_job_id_required": "Error: job_id wajib untuk edit.",
        "cron.update.ok": "Berhasil mengubah job '{name}' ({job_id})",
        "cron.update.not_found": "Job {job_id} tidak ditemukan",
        "cron.update_group.error_not_found": "Error: grup tidak ditemukan. Berikan group_id atau judul yang valid.",
        "cron.update_group.error_schedule_invalid": "Error: jadwal tidak valid ({error}).",
        "cron.update_group.error_nothing_to_update": "Error: tidak ada perubahan. Berikan message, schedule, atau new_title.",
        "cron.update_group.ok": "Berhasil mengubah grup '{title}' ({group_id}) dengan {updated} job",
        "cron.run.error_job_id_required": "Error: job_id wajib untuk run.",
        "cron.run.ok": "Berhasil menjalankan job {job_id}",
        "cron.run.not_found": "Job {job_id} tidak ditemukan atau nonaktif",
        "cron.runs.error_job_id_required": "Error: job_id wajib untuk melihat riwayat run.",
        "cron.runs.empty": "Belum ada riwayat run untuk job {job_id}",
        "cron.runs.header": "Riwayat run untuk {job_id}:",
        "cron.status.running": "Aktif",
        "cron.status.stopped": "Berhenti",
        "cron.status.summary": "Layanan Cron: {service_state}\nJob: {jobs}\nBangun berikutnya: {next_wake}",
        "update.check.available": "Update tersedia: {latest_version} (saat ini: {current_version})",
        "update.check.up_to_date": "Anda sudah menggunakan versi terbaru: {current_version}",
        "update.check.commits_behind": "Instalasi Anda tertinggal {commits_behind} commit dari rilis terbaru.",
        "update.check.error": "Tidak dapat memeriksa update: {error}",
        "update.install.success": "Berhasil update dari {old_version} ke {new_version}. Restart diperlukan.",
        "update.install.restart_confirm": "Update selesai. Restart Kabot sekarang?",
        "update.install.dirty_tree": "Tidak dapat update: ada perubahan yang belum di-commit. Silakan commit atau stash terlebih dahulu.",
        "update.install.failed": "Update gagal: {error}",
        "runtime.status.queued": "Antrian diterima. Menyiapkan permintaan kamu...",
        "runtime.status.queued_merged": "Menggabungkan {count} pesan antrean sebelumnya.",
        "runtime.status.thinking": "Sedang memproses permintaan kamu, mohon tunggu sebentar...",
        "runtime.status.tool": "Sedang menjalankan tools yang dibutuhkan, mohon tunggu sebentar...",
        "runtime.status.done": "Selesai.",
        "runtime.status.error": "Terjadi kendala saat memproses permintaan kamu.",
    },
    "ms": {
        "weather.need_location": "Saya perlukan lokasi untuk semak cuaca. Contoh: semak suhu di Kuala Lumpur.",
        "cron.remove.need_selector": "Untuk padam jadual, berikan `group_id` atau tajuk jadual. Jalankan dulu: `list reminder` untuk lihat senarai kumpulan.",
        "cron.update.need_selector": "Untuk kemas kini jadual, berikan `group_id` atau tajuk jadual. Jalankan dulu: `list reminder` untuk lihat senarai kumpulan.",
        "cron.update.incomplete": "Format kemas kini belum lengkap. Contoh: `update schedule grp_shift_a every 12 hours` atau `rename grp_shift_a to Shift Team A`.",
        "cron.time_unclear": "Saya tidak dapat memastikan masa peringatan. Contoh: ingatkan saya dalam 2 minit, setiap hari jam 09:00, atau setiap 4 jam minum air.",
        "cron.cycle_created": "Kitaran '{title}' berjaya dibuat (group_id: {group_id}) dengan {job_count} kerja; berulang setiap {period_days} hari.",
        "cron.add.error_message_required": "Ralat: mesej diperlukan untuk membuat jadual.",
        "cron.add.error_no_session_context": "Ralat: konteks sesi tiada (channel/chat_id).",
        "cron.add.error_schedule_invalid": "Ralat: jadual tidak sah ({error}).",
        "cron.add.error_schedule_required": "Ralat: isi salah satu at_time, every_seconds, atau cron_expr.",
        "cron.add.error_policy_violation": "Ralat: polisi scheduler menolak permintaan ini ({error}).",
        "cron.add.created": "Berjaya cipta job '{name}' (id: {job_id})",
        "cron.add.created_group": "Berjaya cipta job '{name}' (id: {job_id}, kumpulan: {group_id}, tajuk: {title})",
        "cron.list.empty": "Tiada job berjadual.",
        "cron.list.header": "Senarai job:",
        "cron.list_groups.empty": "Tiada kumpulan jadual.",
        "cron.list_groups.header": "Kumpulan jadual:",
        "cron.status.running": "Berjalan",
        "cron.status.stopped": "Berhenti",
        "cron.status.summary": "Servis Cron: {service_state}\nJob: {jobs}\nBangun seterusnya: {next_wake}",
        "update.check.available": "Kemas kini tersedia: {latest_version} (semasa: {current_version})",
        "update.check.up_to_date": "Anda sudah menggunakan versi terkini: {current_version}",
        "update.check.commits_behind": "Pemasangan anda ketinggalan {commits_behind} commit dari keluaran terbaru.",
        "update.check.error": "Tidak dapat memeriksa kemas kini: {error}",
        "update.install.success": "Berjaya kemas kini dari {old_version} ke {new_version}. Restart diperlukan.",
        "update.install.restart_confirm": "Kemas kini selesai. Restart Kabot sekarang?",
        "update.install.dirty_tree": "Tidak dapat kemas kini: ada perubahan yang belum di-commit. Sila commit atau stash dahulu.",
        "update.install.failed": "Kemas kini gagal: {error}",
        "runtime.status.queued": "Permintaan diterima. Menyiapkan permintaan anda...",
        "runtime.status.queued_merged": "Menggabungkan {count} mesej beratur sebelumnya.",
        "runtime.status.thinking": "Sedang memproses permintaan anda, sila tunggu sebentar...",
        "runtime.status.tool": "Sedang menjalankan alat yang diperlukan, sila tunggu sebentar...",
        "runtime.status.done": "Selesai.",
        "runtime.status.error": "Ralat semasa memproses permintaan anda.",
    },
    "th": {
        "weather.need_location": "ฉันต้องการตำแหน่งเพื่อเช็กสภาพอากาศ ตัวอย่าง: เช็กอุณหภูมิที่กรุงเทพฯ",
        "cron.remove.need_selector": "หากต้องการลบตาราง โปรดระบุ `group_id` หรือชื่อตาราง ใช้ `list reminder` เพื่อดูรายการกลุ่มก่อน",
        "cron.update.need_selector": "หากต้องการแก้ไขตาราง โปรดระบุ `group_id` หรือชื่อตาราง ใช้ `list reminder` เพื่อดูรายการกลุ่มก่อน",
        "cron.update.incomplete": "รูปแบบคำสั่งแก้ไขยังไม่ครบ ตัวอย่าง: `update schedule grp_shift_a every 12 hours` หรือ `rename grp_shift_a to Shift Team A`",
        "cron.time_unclear": "ฉันยังระบุเวลาการเตือนไม่ได้ ตัวอย่าง: เตือนฉันอีก 2 นาที, ทุกวันเวลา 09:00 หรือทุก 4 ชั่วโมงดื่มน้ำ",
        "cron.cycle_created": "สร้างรอบ '{title}' แล้ว (group_id: {group_id}) จำนวน {job_count} งาน; ทำซ้ำทุก {period_days} วัน",
        "update.check.available": "มีอัปเดตใหม่: {latest_version} (ปัจจุบัน: {current_version})",
        "update.check.up_to_date": "คุณใช้เวอร์ชันล่าสุดอยู่แล้ว: {current_version}",
        "update.check.commits_behind": "การติดตั้งของคุณล้าหลัง {commits_behind} commits จากรุ่นล่าสุด",
        "update.check.error": "ไม่สามารถตรวจสอบอัปเดต: {error}",
        "update.install.success": "อัปเดตสำเร็จจาก {old_version} เป็น {new_version} ต้องรีสตาร์ท",
        "update.install.restart_confirm": "อัปเดตเสร็จสิ้น รีสตาร์ท Kabot ตอนนี้เลยไหม?",
        "update.install.dirty_tree": "ไม่สามารถอัปเดต: มีการเปลี่ยนแปลงที่ยังไม่ได้ commit กรุณา commit หรือ stash ก่อน",
        "update.install.failed": "อัปเดตล้มเหลว: {error}",
    },
    "zh": {
        "weather.need_location": "我需要一个地点来查询天气。例如：查询北京天气。",
        "cron.remove.need_selector": "要删除日程，请提供 `group_id` 或日程标题。请先运行：`list reminder` 查看分组列表。",
        "cron.update.need_selector": "要编辑日程，请提供 `group_id` 或日程标题。请先运行：`list reminder` 查看分组列表。",
        "cron.update.incomplete": "编辑格式不完整。示例：`update schedule grp_shift_a every 12 hours` 或 `rename grp_shift_a to Shift Team A`。",
        "cron.time_unclear": "我还无法确定提醒时间。示例：2分钟后提醒我、每天09:00提醒站会、或每4小时喝水。",
        "cron.cycle_created": "已创建循环'{title}'（group_id: {group_id}），共 {job_count} 个任务；每 {period_days} 天重复。",
        "update.check.available": "有可用更新：{latest_version}（当前：{current_version}）",
        "update.check.up_to_date": "您正在使用最新版本：{current_version}",
        "update.check.commits_behind": "您的安装落后最新版本 {commits_behind} 个提交",
        "update.check.error": "无法检查更新：{error}",
        "update.install.success": "成功从 {old_version} 更新到 {new_version}。需要重启。",
        "update.install.restart_confirm": "更新完成。现在重启 Kabot 吗？",
        "update.install.dirty_tree": "无法更新：工作树有未提交的更改。请先提交或暂存。",
        "update.install.failed": "更新失败：{error}",
    },
    "es": {
        "weather.need_location": "Necesito una ubicación para verificar el clima. Ejemplo: verificar clima en Madrid.",
        "update.check.available": "Actualización disponible: {latest_version} (actual: {current_version})",
        "update.check.up_to_date": "Estás usando la última versión: {current_version}",
        "update.check.commits_behind": "Tu instalación está {commits_behind} commits detrás de la última versión.",
        "update.check.error": "No se pudo verificar actualizaciones: {error}",
        "update.install.success": "Actualizado exitosamente de {old_version} a {new_version}. Se requiere reinicio.",
        "update.install.restart_confirm": "Actualización completa. ¿Reiniciar Kabot ahora?",
        "update.install.dirty_tree": "No se puede actualizar: hay cambios sin confirmar en el árbol de trabajo. Por favor confirma o guarda primero.",
        "update.install.failed": "Actualización fallida: {error}",
    },
    "fr": {
        "weather.need_location": "J'ai besoin d'un emplacement pour vérifier la météo. Exemple: vérifier météo à Paris.",
        "update.check.available": "Mise à jour disponible: {latest_version} (actuelle: {current_version})",
        "update.check.up_to_date": "Vous utilisez la dernière version: {current_version}",
        "update.check.commits_behind": "Votre installation est en retard de {commits_behind} commits par rapport à la dernière version.",
        "update.check.error": "Impossible de vérifier les mises à jour: {error}",
        "update.install.success": "Mise à jour réussie de {old_version} vers {new_version}. Redémarrage requis.",
        "update.install.restart_confirm": "Mise à jour terminée. Redémarrer Kabot maintenant?",
        "update.install.dirty_tree": "Impossible de mettre à jour: il y a des modifications non validées dans l'arbre de travail. Veuillez valider ou mettre en cache d'abord.",
        "update.install.failed": "Échec de la mise à jour: {error}",
    },
    "ja": {
        "weather.need_location": "天気を確認するには場所が必要です。例：東京の天気を確認",
        "update.check.available": "アップデート可能：{latest_version}（現在：{current_version}）",
        "update.check.up_to_date": "最新バージョンを使用中：{current_version}",
        "update.check.commits_behind": "インストールは最新リリースより {commits_behind} コミット遅れています",
        "update.check.error": "アップデートを確認できませんでした：{error}",
        "update.install.success": "{old_version} から {new_version} へのアップデートに成功しました。再起動が必要です。",
        "update.install.restart_confirm": "アップデート完了。今すぐ Kabot を再起動しますか？",
        "update.install.dirty_tree": "アップデートできません：作業ツリーにコミットされていない変更があります。先にコミットまたはスタッシュしてください。",
        "update.install.failed": "アップデート失敗：{error}",
    },
    "ko": {
        "weather.need_location": "날씨를 확인하려면 위치가 필요합니다. 예: 서울 날씨 확인",
        "update.check.available": "업데이트 가능: {latest_version} (현재: {current_version})",
        "update.check.up_to_date": "최신 버전을 사용 중입니다: {current_version}",
        "update.check.commits_behind": "설치가 최신 릴리스보다 {commits_behind}개 커밋 뒤처져 있습니다",
        "update.check.error": "업데이트를 확인할 수 없습니다: {error}",
        "update.install.success": "{old_version}에서 {new_version}로 업데이트 성공. 재시작이 필요합니다.",
        "update.install.restart_confirm": "업데이트 완료. 지금 Kabot을 재시작하시겠습니까?",
        "update.install.dirty_tree": "업데이트할 수 없습니다: 작업 트리에 커밋되지 않은 변경 사항이 있습니다. 먼저 커밋하거나 스태시하세요.",
        "update.install.failed": "업데이트 실패: {error}",
    },
}


def _normalize_key(key: str) -> str:
    if key in _KEY_ALIASES:
        return _KEY_ALIASES[key]
    dotted = key.replace("_", ".")
    if dotted in _CATALOG["en"]:
        return dotted
    return key


def _looks_mojibake(value: str) -> bool:
    """Detect common UTF-8 mojibake artifacts from bad transcoding."""
    text = str(value or "")
    if not text:
        return False
    markers = ("Ã", "Â", "â€", "à¸", "Ð", "Ñ", "ã‚", "ì„", "Ãƒ")
    hits = sum(text.count(marker) for marker in markers)
    return hits >= 2


def tr(
    key: str,
    *,
    locale: str | None = None,
    text: str | None = None,
    **kwargs: Any,
) -> str:
    """Translate key to locale, falling back to English."""
    lang = locale or detect_locale(text)
    normalized_key = _normalize_key(key)
    locale_template = _CATALOG.get(lang, {}).get(normalized_key)
    english_template = _CATALOG["en"].get(normalized_key)
    if locale_template and english_template and _looks_mojibake(locale_template):
        template = english_template
    else:
        template = locale_template or english_template or key
    if not kwargs:
        return template
    try:
        return template.format(**kwargs)
    except Exception:
        # Never fail user response because of i18n formatting mismatch.
        return template
