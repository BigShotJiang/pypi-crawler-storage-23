"""CLI module for kabot."""
