"""Common utilities and shared components."""
