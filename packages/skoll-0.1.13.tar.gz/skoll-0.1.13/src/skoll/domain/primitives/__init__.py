import re
import typing as t

from attrs import define, field
from zoneinfo import available_timezones
from skoll.exceptions import InvalidField
from skoll.result import Result, ok, fail
from datetime import datetime, timedelta, UTC
from skoll.constants import CURRENCIES, COUNTRY_CODES
from skoll.utils import new_ulid, to_tz, to_snake_case, safe_call

from .object import Object, Enum

ID_REGEX = r"^[0-9a-z]{26}$"
EMAIL_REGEX = r"^[^@]+@[^@]+$"
TIME_REGEX = r"^(?:[01]?[0-9]|2[0-3]):[0-5][0-9]$"
LOCALE_PATTERN = r"^[a-z]{2,3}(-[A-Z][a-z]{3})?(-[A-Z]{2}|-[0-9]{3})?$"

__all__ = [
    "ID",
    "Map",
    "Time",
    "Enum",
    "Email",
    "Object",
    "Locale",
    "Timezone",
    "DateTime",
    "Currency",
    "Latitude",
    "Longitude",
    "CountryCode",
    "PositiveInt",
    "LocalizedText",
]


@define(kw_only=True, slots=True, frozen=True)
class ID(Object):

    value: str

    @classmethod
    def new(cls) -> t.Self:
        return cls(value=new_ulid())

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = (safe_call(str, raw) or "").strip()
        if value and re.fullmatch(ID_REGEX, value) is not None:
            return ok(value)
        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"expected": "string", "contraints": {"pattern": ID_REGEX}, "received": raw},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class PositiveInt(Object):

    value: int

    def increment(self) -> t.Self:
        return self.__class__(value=self.value + 1)

    def decrement(self) -> t.Self:
        return self.__class__(value=self.value - 1)

    @classmethod
    def zero(cls) -> t.Self:
        return cls(value=0)

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = safe_call(int, raw)
        if value is not None and value >= 0:
            return ok(value)
        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"expected": "integer", "contraints": {"min": 0}, "received": raw},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class DateTime(Object):

    value: datetime

    @property
    def timestamp(self) -> int:
        return int(self.value.timestamp() * 1000)

    @property
    def week_day(self) -> int:
        return self.value.weekday()

    @property
    def iso_format(self) -> str:
        """ """
        return self.value.strftime("%Y-%m-%dT%H:%M:%S") + "Z"

    @t.override
    def serialize(self):
        return self.timestamp

    def diff(self, other: t.Self) -> timedelta:
        if other.value > self.value:
            return other.value - self.value
        return self.value - other.value

    def plus(
        self, days: int = 0, hours: int = 0, minutes: int = 0, seconds: int = 0, delta: timedelta | None = None
    ) -> t.Self:
        new_date = (
            self.value + timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds) + (delta or timedelta())
        )
        return self.__class__(value=new_date)

    def minus(
        self, days: int = 0, hours: int = 0, minutes: int = 0, seconds: int = 0, delta: timedelta | None = None
    ) -> t.Self:
        new_date = (
            self.value - timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds) - (delta or timedelta())
        )
        return self.__class__(value=new_date)

    def __gt__(self, other: t.Self) -> bool:
        return self.value > other.value

    def __lt__(self, other: t.Self) -> bool:
        return self.value < other.value

    def __ge__(self, other: t.Self) -> bool:
        return self.value >= other.value

    def __le__(self, other: t.Self) -> bool:
        return self.value <= other.value

    def reset_second(self) -> t.Self:
        date = self.value.replace(second=0, microsecond=0)
        return self.__class__(value=date)

    def reset_part(self, hour: bool = False, minute: bool = False) -> t.Self:
        date = self.value.replace(second=0, microsecond=0)

        if hour:
            date = date.replace(hour=0, minute=0)
        elif minute:
            date = date.replace(minute=0)
        return self.__class__(value=date)

    def to_tz(self, tz_str: str = "UTC") -> t.Self:
        return self.__class__.from_timestamp(int(self.value.timestamp() * 1000), tz_str=tz_str)

    @classmethod
    def today(cls, tz_str: str = "UTC") -> t.Self:
        tz = to_tz(tz_str)
        value = datetime.combine(datetime.now(tz=tz), datetime.min.time()).replace(tzinfo=tz)
        return cls.from_timestamp(int(value.timestamp() * 1000), tz_str=tz_str)

    @classmethod
    def tomorrow(cls, tz_str: str = "UTC") -> t.Self:
        tz = to_tz(tz_str)
        value = datetime.combine(datetime.now(tz=tz) + timedelta(days=1), datetime.min.time()).replace(tzinfo=tz)
        return cls.from_timestamp(int(value.timestamp() * 1000), tz_str=tz_str)

    @classmethod
    def now(cls, tz_str: str = "UTC") -> t.Self:
        tz = to_tz(tz_str)
        value = int(datetime.now(tz=tz).timestamp() * 1000)
        return cls.from_timestamp(value, tz_str=tz_str)

    @classmethod
    def from_timestamp(cls, timestamp: int, tz_str: str = "UTC") -> t.Self:
        tz = to_tz(tz_str)
        return cls(value=datetime.fromtimestamp(timestamp / 1000, tz=tz))

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = safe_call(int, raw)
        if value is not None and value >= 0:
            return ok(datetime.fromtimestamp(value / 1000, tz=UTC))
        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"expected": "integer", "contraints": {"min": 0}, "received": raw},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class Latitude(Object):
    value: float

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = safe_call(float, raw)
        if value is not None and -90 <= value <= 90:
            return ok(value)
        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"expected": "float", "contraints": {"min": -90, "max": 90}, "received": raw},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class Longitude(Object):
    value: float

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = safe_call(float, raw)
        if value is not None and -180 <= value <= 180:
            return ok(value)
        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"expected": "float", "contraints": {"min": -180, "max": 180}, "received": raw},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class Time(Object):
    value: str

    @property
    def as_hour(self) -> float:
        return self.hour + (self.minute / 60)

    @property
    def hour(self) -> int:
        return int(self.value.split(":")[0])

    @property
    def minute(self) -> int:
        return int(self.value.split(":")[1])

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = (safe_call(str, raw) or "").strip()
        if value and re.fullmatch(TIME_REGEX, value) is not None:
            return ok(value)

        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"expected": "string", "contraints": {"pattern": TIME_REGEX}, "received": raw},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class Email(Object):

    value: str

    @property
    def name(self) -> str:
        return self.value.split("@")[0]

    @classmethod
    def anonymous(cls) -> t.Self:
        return cls(value=f"{new_ulid()}.anonymous@skoll.com")

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = (safe_call(str, raw) or "").strip()
        if value and re.fullmatch(EMAIL_REGEX, value) is not None:
            return ok(value)
        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"expected": "string", "contraints": {"pattern": EMAIL_REGEX}, "received": raw},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class Locale(Object):

    value: str

    @classmethod
    def default(cls) -> t.Self:
        return cls(value="en-US")

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = (safe_call(str, raw) or "").strip()
        if value and re.fullmatch(LOCALE_PATTERN, value) is not None:
            return ok(value)
        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"received": raw, "expected": "BCP47Locale"},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class LocalizedText(Object):

    value: dict[str, str] = field(factory=dict)

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = safe_call(dict, raw)

        if value is not None:
            keys_valid = all(isinstance(k, str) and re.fullmatch(LOCALE_PATTERN, k) for k in value.keys())
            values_valid = all(isinstance(v, str) for v in value.values())
            if keys_valid and values_valid:
                return ok(t.cast(dict[str, str], value))

        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={
                    "received": raw,
                    "expected": "Dictionaire<BCP47Locale, string>",
                    "example": {"en-US": "English", "en": "An example"},
                },
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class Map(Object):

    value: dict[str, t.Any] = field(factory=dict)

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = safe_call(dict, raw)
        if value is not None:
            return ok(t.cast(dict[str, t.Any], value))

        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"received": raw, "expected": "dict"},
            )
        )

    @classmethod
    def empty(cls) -> t.Self:
        return cls(value={})


@define(kw_only=True, slots=True, frozen=True)
class Timezone(Object):

    value: str

    @classmethod
    def default(cls) -> t.Self:
        return cls(value="UTC")

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = safe_call(str, raw)
        value = value.strip() if value is not None else None

        if value in available_timezones():
            return ok(value)

        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"received": raw, "expected": "IANA Timezone (e.g., UTC, America/New_York)"},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class Currency(Object):

    value: str

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = (safe_call(str, raw) or "").upper()

        if value in CURRENCIES:
            return ok(value)
        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"received": raw, "expected": "Currency (e.g., EUR, USD)"},
            )
        )


@define(kw_only=True, slots=True, frozen=True)
class CountryCode(Object):

    value: str

    @t.override
    @classmethod
    def prepare(cls, raw: t.Any) -> Result[t.Any]:
        value = (safe_call(str, raw) or "").upper()

        if value in COUNTRY_CODES:
            return ok(value)
        return fail(
            InvalidField(
                field=to_snake_case(cls.__name__),
                hints={"received": raw, "expected": "Country Code (e.g., US, UK)"},
            )
        )
