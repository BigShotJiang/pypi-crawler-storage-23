"""Tests for neonlink.health."""

from neonlink.config import Config


class TestHealthCheckerConfig:
    def test_health_client_id_suffix(self):
        cfg = Config(client_id="test-service")
        conf = cfg.to_confluent_config()
        assert conf["client.id"] == "test-service"
        # HealthChecker appends "-health" internally; verify config is valid.

    def test_health_with_tls_sasl(self):
        cfg = Config(
            tls_enabled=True,
            tls_ca_file="/ca.pem",
            sasl_mechanism="SCRAM-SHA-512",
            sasl_username="admin",
            sasl_password="secret",
        )
        conf = cfg.to_confluent_config()
        assert conf["security.protocol"] == "SASL_SSL"
        assert conf["ssl.ca.location"] == "/ca.pem"
        assert conf["sasl.mechanism"] == "SCRAM-SHA-512"
