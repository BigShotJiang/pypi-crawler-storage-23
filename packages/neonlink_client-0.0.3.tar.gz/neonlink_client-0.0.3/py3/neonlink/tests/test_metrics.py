"""Tests for neonlink.metrics."""

from neonlink.metrics import NoopMetrics


class TestNoopMetrics:
    def test_all_methods_callable(self):
        m = NoopMetrics()
        m.publish_success("topic", 1.0)
        m.publish_error("topic", Exception("err"))
        m.consume_success("topic", 0, 1.0)
        m.consume_error("topic", 0, Exception("err"))
        m.poison_pill_detected("topic", 0, 100)
        m.poison_pill_blocked("topic", 0, 100)
        m.consumer_lag("topic", 0, 50)
        m.circuit_breaker_state_change("name", "closed", "open")
        m.dlq_routed("topic", Exception("err"))
