You need to allow to auto-create lots in your operation type. Doing so, you'll be able
to auto-assign a lot when creating a new operation from the weighing card.

Remeber that you need to go to *Inventory > Configuration > Operation Types* and set
*Auto Create Lot* on in the type you want to.

Also take into account that only products with the *Auto Create Lot* flag will have
this feature. Set it on on the product's form traceability options.
