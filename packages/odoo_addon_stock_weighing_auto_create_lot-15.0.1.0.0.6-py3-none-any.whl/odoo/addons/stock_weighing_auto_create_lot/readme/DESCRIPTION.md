Auto-create lots when adding detailed operations from the weight kanban card.
