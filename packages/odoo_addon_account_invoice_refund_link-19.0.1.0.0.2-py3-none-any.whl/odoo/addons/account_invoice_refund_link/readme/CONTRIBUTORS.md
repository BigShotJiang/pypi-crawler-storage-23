- Pexego Sistemas Informáticos. (<http://pexego.es>)

- Nikul Chaudhary \<<nikulchaudhary2112@gmail.com>\>

- [Tecnativa](https://www.tecnativa.com):

  - Pedro M. Baeza
  - Antonio Espinosa
  - Luis M. Ontalba
  - Ernesto Tejeda
  - João Marques

- [Factor Libre](https://factorlibre.com):

  > - Luis J. Salvatierra \<<luis.salvatierra@factorlibre.com>\>

- [APSL-Nagarro](https://www.apsl.tech):

  > - Antoni Marroig \<<amarroig@apsl.net>\>
