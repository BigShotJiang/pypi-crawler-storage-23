def main() -> None:
    print("Hello from anytype-notifier!")
