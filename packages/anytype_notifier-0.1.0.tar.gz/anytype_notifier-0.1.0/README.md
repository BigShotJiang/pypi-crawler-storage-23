# Notifications for Anytype

IN DEVELOPMENT
