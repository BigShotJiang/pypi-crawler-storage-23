# dagster-fivetran

The docs for `dagster-fivetran` can be found
[here](https://docs.dagster.io/integrations/libraries/fivetran/dagster-fivetran).
