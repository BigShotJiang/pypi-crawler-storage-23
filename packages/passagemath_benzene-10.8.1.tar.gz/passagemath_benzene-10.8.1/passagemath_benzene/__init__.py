# sage_setup: distribution = sagemath-benzene

from sage.all__sagemath_benzene import *
