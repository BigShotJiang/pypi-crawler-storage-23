def test_always_true():
    assert True
