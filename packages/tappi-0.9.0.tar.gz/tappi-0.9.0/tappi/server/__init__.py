"""tappi web server — chat UI + API."""
