# deployment

Local deployment assets for this standalone node workspace.

- `model-orchestrator-local/config`: local model-orchestrator configuration and starter submission
- `report-ui/config`: report UI local settings
