# config

- `crunch_config.py`: CrunchConfig override — data-shape types, scoring, scheduled predictions, and competition settings
