"""Stable domain entities shared across coordinator implementations."""
