#!/usr/bin/env python3
"""Vicompres - Efficiently compress video files using ffmpeg."""

import argparse
import signal
import subprocess
import sys
from pathlib import Path

SUPPORTED_EXTENSIONS = {".mp4", ".mkv", ".avi", ".mov"}

# Compression presets mapped by level (1-10).
# Each level defines: (preset, crf, audio_bitrate)
COMPRESSION_PROFILES = {
    1:  ("ultrafast", 28, "192k"),
    2:  ("superfast", 27, "176k"),
    3:  ("veryfast",  26, "160k"),
    4:  ("faster",    25, "144k"),
    5:  ("medium",    23, "128k"),
    6:  ("medium",    21, "128k"),
    7:  ("slow",      19, "112k"),
    8:  ("slower",    17, "96k"),
    9:  ("veryslow",  15, "96k"),
    10: ("veryslow",  13, "80k"),
}

# Per-extension codec and container settings
EXTENSION_SETTINGS = {
    ".mp4": {"vcodec": "libx264", "acodec": "aac"},
    ".mkv": {"vcodec": "libx264", "acodec": "aac"},
    ".avi": {"vcodec": "libxvid", "acodec": "libmp3lame"},
    ".mov": {"vcodec": "libx264", "acodec": "aac"},
}

# Graceful shutdown flag
_shutdown_requested = False


def _handle_sigint(signum: int, frame) -> None:
    """Set shutdown flag on first Ctrl+C; force-exit on second."""
    global _shutdown_requested
    if _shutdown_requested:
        # Second interrupt – abort immediately
        print("\nForced shutdown.", file=sys.stderr)
        sys.exit(1)
    _shutdown_requested = True
    print("\nShutdown requested – finishing current file, then stopping…")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="vicompres",
        description="Efficiently compress video files using ffmpeg.",
    )
    parser.add_argument(
        "-d",
        "--directory",
        type=str,
        default=".",
        help="Directory containing video files to compress (default: current directory).",
    )
    parser.add_argument(
        "-c",
        "--compression",
        type=int,
        default=5,
        choices=range(1, 11),
        metavar="1-10",
        help="Compression level 1-10. Higher = better compression, slower (default: 5).",
    )
    parser.add_argument(
        "-p",
        "--prefix",
        type=str,
        default="",
        help="Only process files whose name starts with this prefix (default: all files).",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default=None,
        help="Output directory for compressed files (default: same as input).",
    )
    parser.add_argument(
        "-s",
        "--suffix",
        type=str,
        default="compressed",
        help="Suffix appended to output file names (default: 'compressed').",
    )
    parser.add_argument(
        "-r",
        "--remove-original",
        action="store_true",
        default=False,
        help="Delete original files after successful compression (default: keep originals).",
    )
    return parser.parse_args()


def check_ffmpeg() -> None:
    """Verify that ffmpeg is available on the system."""
    try:
        subprocess.run(
            ["ffmpeg", "-version"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        print("Error: ffmpeg is not installed or not found in PATH.", file=sys.stderr)
        sys.exit(1)


def collect_files(directory: str, prefix: str) -> list[Path]:
    """Return a sorted list of supported video files in *directory*."""
    dir_path = Path(directory).resolve()
    if not dir_path.is_dir():
        print(f"Error: '{directory}' is not a valid directory.", file=sys.stderr)
        sys.exit(1)

    files: list[Path] = []
    for entry in sorted(dir_path.iterdir()):
        if not entry.is_file():
            continue
        if entry.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue
        if prefix and not entry.name.startswith(prefix):
            continue
        files.append(entry)
    return files


def build_output_path(input_file: Path, output_dir: Path, suffix: str) -> Path:
    """Construct the output file path with the given suffix."""
    stem = input_file.stem
    ext = input_file.suffix
    out_name = f"{stem}_{suffix}{ext}"
    return output_dir / out_name


def build_ffmpeg_cmd(
    input_file: Path,
    output_file: Path,
    compression: int,
) -> list[str]:
    """Build the ffmpeg command list for compressing a single file."""
    ext = input_file.suffix.lower()
    preset, crf, audio_br = COMPRESSION_PROFILES[compression]
    settings = EXTENSION_SETTINGS[ext]

    cmd = [
        "ffmpeg",
        "-i", str(input_file),
        "-preset", preset,
        "-crf", str(crf),
        "-vcodec", settings["vcodec"],
        "-acodec", settings["acodec"],
        "-b:a", audio_br,
        "-y",
        str(output_file),
    ]
    return cmd


def compress_file(
    input_file: Path,
    output_file: Path,
    compression: int,
) -> bool:
    """Compress a single video file. Returns True on success."""
    cmd = build_ffmpeg_cmd(input_file, output_file, compression)
    print(f"  Compressing: {input_file.name} -> {output_file.name}")
    try:
        subprocess.run(
            cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE
        )
        return True
    except subprocess.CalledProcessError as exc:
        print(
            f"  Error compressing {input_file.name}: {exc.stderr.decode().strip()}",
            file=sys.stderr,
        )
        return False


def format_size(size_bytes: int) -> str:
    """Return a human-readable file size string."""
    for unit in ("B", "KB", "MB", "GB"):
        if abs(size_bytes) < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024  # type: ignore[assignment]
    return f"{size_bytes:.1f} TB"


def main() -> None:
    signal.signal(signal.SIGINT, _handle_sigint)

    args = parse_args()
    check_ffmpeg()

    directory = args.directory
    compression = args.compression
    prefix = args.prefix
    suffix = args.suffix
    output_dir_arg = args.output
    remove_original = args.remove_original

    files = collect_files(directory, prefix)
    if not files:
        print("No supported video files found.")
        return

    # Resolve output directory
    if output_dir_arg:
        output_dir = Path(output_dir_arg).resolve()
        output_dir.mkdir(parents=True, exist_ok=True)
    else:
        output_dir = files[0].parent

    print(f"Vicompres — compression level {compression}")
    print(f"  Input:  {Path(directory).resolve()}")
    print(f"  Output: {output_dir}")
    print(f"  Files:  {len(files)}")
    print()

    success = 0
    failed = 0
    removed = 0
    total_saved: int = 0

    for f in files:
        if _shutdown_requested:
            print("\n  Stopping – shutdown was requested.")
            break

        out_path = build_output_path(f, output_dir, suffix)

        # Skip files that already have the suffix (avoid re-compressing)
        if f.stem.endswith(f"_{suffix}"):
            print(f"  Skipping (already compressed): {f.name}")
            continue

        if compress_file(f, out_path, compression):
            original_size = f.stat().st_size
            compressed_size = out_path.stat().st_size
            saved = original_size - compressed_size
            total_saved += saved
            pct = (saved / original_size * 100) if original_size else 0
            print(
                f"    {format_size(original_size)} -> {format_size(compressed_size)}  ({pct:.1f}% saved)"
            )
            success += 1
            if remove_original:
                try:
                    f.unlink()
                    print(f"    Removed original: {f.name}")
                    removed += 1
                except OSError as exc:
                    print(f"    Failed to remove {f.name}: {exc}", file=sys.stderr)
        else:
            failed += 1

    print()
    print(f"Done. {success} succeeded, {failed} failed.")
    if removed:
        print(f"Removed {removed} original file(s).")
    if total_saved > 0:
        print(f"Total space saved: {format_size(total_saved)}")
    elif total_saved < 0:
        print(f"Total size increased by: {format_size(abs(total_saved))}")


if __name__ == "__main__":
    main()
