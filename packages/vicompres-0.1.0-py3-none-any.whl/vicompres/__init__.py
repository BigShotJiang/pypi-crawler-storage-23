"""Vicompres - Efficiently compress video files using ffmpeg."""
