class WrongDatabaseError(Exception):
    pass
