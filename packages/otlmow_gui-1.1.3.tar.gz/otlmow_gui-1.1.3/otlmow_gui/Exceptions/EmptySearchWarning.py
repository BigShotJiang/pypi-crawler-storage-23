class EmptySearchWarning(Exception):
    pass
