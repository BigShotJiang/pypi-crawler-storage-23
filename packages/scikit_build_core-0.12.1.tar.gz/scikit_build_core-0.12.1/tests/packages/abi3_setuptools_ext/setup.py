from setuptools import setup

setup(
    cmake_source_dir=".",
)
