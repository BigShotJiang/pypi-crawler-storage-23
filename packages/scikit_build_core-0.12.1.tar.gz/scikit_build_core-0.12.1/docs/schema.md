(schema)=

# Schema

The full schema for the `tool.scikit-build` table is below:

```{jsonschema} ../src/scikit_build_core/resources/scikit-build.schema.json
:auto_reference: true
```
