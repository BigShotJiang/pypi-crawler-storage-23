scikit\_build\_core.settings package
====================================

.. automodule:: scikit_build_core.settings
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

scikit\_build\_core.settings.auto\_cmake\_version module
--------------------------------------------------------

.. automodule:: scikit_build_core.settings.auto_cmake_version
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.auto\_requires module
--------------------------------------------------

.. automodule:: scikit_build_core.settings.auto_requires
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.documentation module
-------------------------------------------------

.. automodule:: scikit_build_core.settings.documentation
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.json\_schema module
------------------------------------------------

.. automodule:: scikit_build_core.settings.json_schema
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.skbuild\_docs\_readme module
---------------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_docs_readme
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.skbuild\_docs\_sphinx module
---------------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_docs_sphinx
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.skbuild\_model module
--------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_model
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.skbuild\_overrides module
------------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_overrides
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.skbuild\_read\_settings module
-----------------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_read_settings
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.skbuild\_schema module
---------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_schema
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.settings.sources module
-------------------------------------------

.. automodule:: scikit_build_core.settings.sources
   :members:
   :show-inheritance:
   :undoc-members:
