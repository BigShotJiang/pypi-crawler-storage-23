scikit\_build\_core.setuptools package
======================================

.. automodule:: scikit_build_core.setuptools
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

scikit\_build\_core.setuptools.build\_cmake module
--------------------------------------------------

.. automodule:: scikit_build_core.setuptools.build_cmake
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.setuptools.build\_meta module
-------------------------------------------------

.. automodule:: scikit_build_core.setuptools.build_meta
   :members:
   :show-inheritance:
   :undoc-members:

scikit\_build\_core.setuptools.wrapper module
---------------------------------------------

.. automodule:: scikit_build_core.setuptools.wrapper
   :members:
   :show-inheritance:
   :undoc-members:
