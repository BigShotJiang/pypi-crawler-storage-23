# Changelog

All notable changes to the EnvDrift VS Code Extension will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1](https://github.com/jainal09/envdrift/compare/vscode-v0.1.0...vscode-v0.1.1) (2026-02-21)


### Features

* add VS Code extension for auto-encrypting .env files ([#61](https://github.com/jainal09/envdrift/issues/61)) ([9ddc602](https://github.com/jainal09/envdrift/commit/9ddc602f1f098261704c812376e36521f7fdc1b7))
* **release:** add multi-package release-please configuration ([#140](https://github.com/jainal09/envdrift/issues/140)) ([338ba6a](https://github.com/jainal09/envdrift/commit/338ba6a88364ffd057d848bdf15c6c5d49b4dc92))
* **vscode:** add Phase 2E - agent status indicator ([#125](https://github.com/jainal09/envdrift/issues/125)) ([532edf1](https://github.com/jainal09/envdrift/commit/532edf133390c0c43825d17bdbdc2843674dd3bc))
