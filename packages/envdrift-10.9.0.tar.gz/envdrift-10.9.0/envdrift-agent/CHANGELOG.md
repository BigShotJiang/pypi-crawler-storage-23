# Changelog

All notable changes to the EnvDrift Agent will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 1.0.0 (2026-02-21)

### Features

* add envdrift-agent Go background encryption daemon ([#54](https://github.com/jainal09/envdrift/issues/54)) ([55f75b1](https://github.com/jainal09/envdrift/commit/55f75b1c49eacadbdd8aab87650dfcd72390ac1e))
* **agent:** add Phase 2D - per-project watching with individual configs ([#124](https://github.com/jainal09/envdrift/issues/124)) ([f7150b9](https://github.com/jainal09/envdrift/commit/f7150b91c9dd7fb2e8c22c1551b6a743de2ba148))
