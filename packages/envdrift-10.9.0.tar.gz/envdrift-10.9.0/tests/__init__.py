"""Test package marker for shared helpers."""
