# FILE-SIZE-OK: 630 lines after mixin extraction (was 1258).
# Remaining methods are tightly coupled to CacheKey and
# OpenDeviationBarCache __init__/schema lifecycle.
"""ClickHouse cache for computed open deviation bars.

This module provides the OpenDeviationBarCache class that
caches computed open deviation bars
(Tier 2) in ClickHouse. Raw tick data is stored locally using Parquet files
via the `opendeviationbar.storage` module.

Architecture:
- Tier 1 (raw ticks): Local Parquet files via `opendeviationbar.storage.TickStorage`
- Tier 2 (computed bars): ClickHouse via this module

The cache uses mise environment variables for configuration and
supports multiple GPU workstations via SSH aliases.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from importlib import resources
from typing import TYPE_CHECKING

import pandas as pd

from .._core import __version__
from ..constants import (
    EXCHANGE_SESSION_COLUMNS,
    MICROSTRUCTURE_COLUMNS,
    TIMESTAMP_COLUMNS,
    TRADE_ID_RANGE_COLUMNS,  # Issue #72
)
from ..conversion import normalize_arrow_dtypes
from ..exceptions import (
    CacheReadError,
    CacheWriteError,
)
from .bar_count_api import BarCountMixin
from .bulk_operations import BulkStoreMixin, _build_insert_settings
from .checkpoint_operations import CheckpointOperationsMixin
from .client import get_client
from .constants import FINAL_READ_SETTINGS
from .maintenance import MaintenanceMixin
from .mixin import ClickHouseClientMixin
from .preflight import (
    HostConnection,
    get_available_clickhouse_host,
)
from .query_operations import QueryOperationsMixin
from .tunnel import SSHTunnel

if TYPE_CHECKING:
    import clickhouse_connect

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CacheKey:
    """Cache key for open deviation bar lookups.

    Uniquely identifies a set of computed open deviation bars based on:
    - Symbol (e.g., "BTCUSDT")
    - Threshold in decimal basis points (dbps)
    - Time range of source data
    - Ouroboros mode for reproducibility

    Attributes
    ----------
    symbol : str
        Trading symbol
    threshold_decimal_bps : int
        Threshold in decimal basis points (1 dbps = 0.001%)
    start_ts : int
        Start timestamp in milliseconds
    end_ts : int
        End timestamp in milliseconds
    ouroboros_mode : str
        Ouroboros reset mode: "year", "month", or "week" (default: "month")
    """

    symbol: str
    threshold_decimal_bps: int
    start_ts: int
    end_ts: int
    ouroboros_mode: str = "month"  # Issue #126: align with schema DEFAULT

    @property
    def hash_key(self) -> str:
        """Get hash key for cache lookups.

        Returns
        -------
        str
            MD5 hash of cache key components
        """
        key_str = (
            f"{self.symbol}_{self.threshold_decimal_bps}_"
            f"{self.start_ts}_{self.end_ts}_{self.ouroboros_mode}"
        )
        return hashlib.md5(key_str.encode()).hexdigest()


class OpenDeviationBarCache(
    ClickHouseClientMixin,
    BulkStoreMixin,
    QueryOperationsMixin,
    CheckpointOperationsMixin,
    MaintenanceMixin,
    BarCountMixin,
):
    """ClickHouse cache for computed open deviation bars.

    Caches computed open deviation bars (Tier 2) in ClickHouse. For raw tick data
    storage (Tier 1), use `opendeviationbar.storage.TickStorage` instead.

    PREFLIGHT runs in __init__ - fails loudly if no ClickHouse available.

    Parameters
    ----------
    client : Client | None
        External ClickHouse client. If None, creates connection based on
        environment configuration (mise env vars).

    Raises
    ------
    ClickHouseNotConfiguredError
        If no ClickHouse hosts available (with guidance for setup)

    Examples
    --------
    >>> with OpenDeviationBarCache() as cache:
    ...     # Check cache
    ...     if cache.has_open_deviation_bars(key):
    ...         bars = cache.get_open_deviation_bars(key)
    ...     else:
    ...         # Compute bars and store
    ...         cache.store_open_deviation_bars(key, bars)

    See Also
    --------
    opendeviationbar.storage.TickStorage : Local Parquet storage for raw tick data
    """

    def __init__(self, client: clickhouse_connect.driver.Client | None = None) -> None:
        """Initialize cache with ClickHouse connection.

        Runs preflight check to find available ClickHouse host.
        Creates schema if it doesn't exist.
        """
        self._tunnel: SSHTunnel | None = None
        self._host_connection: HostConnection | None = None

        if client is None:
            # PREFLIGHT CHECK - runs before anything else
            # This function fails loudly if no CH available
            host_conn = get_available_clickhouse_host()
            self._host_connection = host_conn

            # Connect based on method (local, direct, or SSH tunnel)
            if host_conn.method == "local":
                self._init_client(get_client("localhost", host_conn.port))
            elif host_conn.method == "direct":
                from .preflight import _resolve_ssh_alias_to_ip

                ip = _resolve_ssh_alias_to_ip(host_conn.host)
                if ip is None:
                    msg = f"Could not resolve SSH alias: {host_conn.host}"
                    raise RuntimeError(msg)
                self._init_client(get_client(ip, host_conn.port))
            elif host_conn.method == "ssh_tunnel":
                self._tunnel = SSHTunnel(host_conn.host, host_conn.port)
                local_port = self._tunnel.start()
                self._init_client(get_client("localhost", local_port))
        else:
            self._init_client(client)

        self._ensure_schema()

    def close(self) -> None:
        """Close client and tunnel if owned."""
        super().close()
        if self._tunnel is not None:
            self._tunnel.stop()
            self._tunnel = None

    def _ensure_schema(self) -> None:
        """Create database and tables if they don't exist."""
        # Create database
        self.client.command("CREATE DATABASE IF NOT EXISTS opendeviationbar_cache")

        # Load and execute schema
        schema_sql = resources.files(__package__).joinpath("schema.sql").read_text()

        # Split by semicolon and execute each statement
        for statement in schema_sql.split(";"):
            # Check if statement contains a CREATE TABLE/MATERIALIZED VIEW
            if "CREATE TABLE" in statement or "CREATE MATERIALIZED" in statement:
                # Strip single-line comments from each line, keep the SQL
                lines = []
                for line in statement.split("\n"):
                    line = line.strip()
                    # Skip pure comment lines
                    if line.startswith("--"):
                        continue
                    # Remove trailing comments
                    if "--" in line:
                        line = line[: line.index("--")].strip()
                    if line:
                        lines.append(line)
                clean_sql = " ".join(lines)
                if clean_sql:
                    self.client.command(clean_sql)

        # Issue #90: Enable INSERT block deduplication on existing tables.
        # ALTER TABLE MODIFY SETTING is idempotent — safe to run every init.
        try:
            self.client.command(
                "ALTER TABLE opendeviationbar_cache.open_deviation_bars "
                "MODIFY SETTING non_replicated_deduplication_window = 1000"
            )
        except (OSError, RuntimeError) as e:
            # Graceful degradation: older ClickHouse may not support this setting.
            logger.debug("Could not set non_replicated_deduplication_window: %s", e)

        # Issue #158 Phase 7: Skip index for close_time_ms range queries.
        # After ORDER BY changed from close_time_ms to first_agg_trade_id,
        # time-range queries need this minmax skip index for performance.
        try:
            self.client.command(
                "ALTER TABLE opendeviationbar_cache.open_deviation_bars "
                "ADD INDEX IF NOT EXISTS idx_close_time close_time_ms "
                "TYPE minmax GRANULARITY 8192"
            )
        except (OSError, RuntimeError) as e:
            logger.debug("Could not add close_time_ms skip index: %s", e)

        # Detect legacy schema and conditionally add open_time_ms
        try:
            result = self.client.query(
                "SELECT name FROM system.columns "
                "WHERE database='opendeviationbar_cache' "
                "AND table='open_deviation_bars' AND name='timestamp_ms'"
            )
            if result.result_rows:
                logger.warning(
                    "Legacy schema detected: 'timestamp_ms' column present. "
                    "Run migration script to rename to 'close_time_ms'. "
                    "See scripts/migrate_timestamp_column.py"
                )
            else:
                # Table already migrated — safe to add open_time_ms
                try:
                    self.client.command(
                        "ALTER TABLE opendeviationbar_cache.open_deviation_bars "
                        "ADD COLUMN IF NOT EXISTS open_time_ms Int64 "
                        "DEFAULT close_time_ms - intDiv(duration_us, 1000) "
                        "AFTER close_time_ms"
                    )
                except (OSError, RuntimeError) as e:
                    logger.debug("Could not add open_time_ms column: %s", e)
        except (OSError, RuntimeError):
            pass

        # Issue #164: Time-range projection for flowsurface queries.
        # Primary ORDER BY uses first_agg_trade_id (Stathera dedup), but flowsurface
        # queries by close_time_ms. Projection enables index-optimized time-range scans.
        try:
            self.client.command(
                "ALTER TABLE opendeviationbar_cache.open_deviation_bars "
                "ADD PROJECTION IF NOT EXISTS prj_time_range "
                "(SELECT * ORDER BY (symbol, threshold_decimal_bps, close_time_ms))"
            )
        except (OSError, RuntimeError) as e:
            logger.debug("Could not add prj_time_range projection: %s", e)

        # Issue #163: Data freshness tracking table for SSE push endpoint.
        try:
            self.client.command(
                "CREATE TABLE IF NOT EXISTS opendeviationbar_cache.data_freshness ("
                "    symbol LowCardinality(String),"
                "    threshold_decimal_bps UInt32,"
                "    last_close_time_ms Int64,"
                "    last_bar_count UInt64 DEFAULT 0,"
                "    updated_at DateTime64(3) DEFAULT now64(3)"
                ") ENGINE = ReplacingMergeTree(updated_at)"
                " ORDER BY (symbol, threshold_decimal_bps)"
            )
        except (OSError, RuntimeError) as e:
            logger.debug("Could not create data_freshness table: %s", e)

        # Issue #98: Auto-migrate plugin feature columns.
        # Discovers installed FeatureProviders and ensures their columns
        # exist in the open_deviation_bars table. Idempotent (ADD COLUMN IF NOT EXISTS).
        try:
            from ..plugins.loader import _get_providers
            from ..plugins.migration import migrate_plugin_columns

            providers = _get_providers()
            if providers:
                migrate_plugin_columns(self.client, providers)
        except (ImportError, OSError, RuntimeError) as e:
            logger.debug("Plugin column migration skipped: %s", e)

    # =========================================================================
    # Open Deviation Bars Cache (Tier 2)
    # =========================================================================
    # Note: Raw tick data (Tier 1) is now stored locally using Parquet files.
    # See opendeviationbar.storage.TickStorage for tick data caching.

    def store_open_deviation_bars(
        self,
        key: CacheKey,
        bars: pd.DataFrame,
        version: str | None = None,
    ) -> int:
        """Store computed open deviation bars in cache.

        Parameters
        ----------
        key : CacheKey
            Cache key identifying these bars
        bars : pd.DataFrame
            DataFrame with OHLCV columns (from opendeviationbar processing)
        version : str | None
            opendeviationbar-core version for cache invalidation. If None (default),
            uses current package version for schema evolution tracking.

        Returns
        -------
        int
            Number of rows inserted

        Raises
        ------
        CacheWriteError
            If the insert operation fails.
        """
        if bars.empty:
            logger.debug("Skipping cache write for %s: empty DataFrame", key.symbol)
            return 0

        logger.debug(
            "Writing %d bars to cache for %s @ %d dbps",
            len(bars),
            key.symbol,
            key.threshold_decimal_bps,
        )

        df = bars.copy()

        # Handle DatetimeIndex
        if isinstance(df.index, pd.DatetimeIndex):
            df = df.reset_index()
            # After reset_index(), the DatetimeIndex becomes a column
            idx_col = bars.index.name or "index"
            df["close_time_ms"] = df[idx_col].dt.as_unit("ms").astype("int64")
            df = df.drop(columns=[idx_col], errors="ignore")
        elif "close_time_ms" not in df.columns:
            msg = "DataFrame must have DatetimeIndex or 'close_time_ms' column"
            raise ValueError(msg)

        # Normalize column names (lowercase)
        df.columns = df.columns.str.lower()

        # Add cache metadata
        df["symbol"] = key.symbol
        df["threshold_decimal_bps"] = key.threshold_decimal_bps
        df["ouroboros_mode"] = key.ouroboros_mode
        df["cache_key"] = key.hash_key
        df["opendeviationbar_version"] = version if version is not None else __version__
        df["source_start_ts"] = key.start_ts
        df["source_end_ts"] = key.end_ts

        # Select columns for insertion
        columns = [
            "symbol",
            "threshold_decimal_bps",
            "ouroboros_mode",
            "close_time_ms",
            "open",
            "high",
            "low",
            "close",
            "volume",
            "cache_key",
            "opendeviationbar_version",
            "source_start_ts",
            "source_end_ts",
        ]

        # Add optional columns if present (from constants.py SSoT)
        for col in (
            *MICROSTRUCTURE_COLUMNS,
            *EXCHANGE_SESSION_COLUMNS,
            *TRADE_ID_RANGE_COLUMNS,
            *TIMESTAMP_COLUMNS,
        ):
            if col in df.columns and col not in columns:
                columns.append(col)

        # Filter to existing columns
        columns = [c for c in columns if c in df.columns]

        # Issue #90: INSERT dedup token for idempotent writes.
        insert_settings = _build_insert_settings(
            False,
            (lambda: key.hash_key) if key.hash_key else None,
        )

        try:
            summary = self.client.insert_df(
                "opendeviationbar_cache.open_deviation_bars",
                df[columns],
                settings=insert_settings,
            )
            written = summary.written_rows
            logger.info(
                "Cached %d bars for %s @ %d dbps",
                written,
                key.symbol,
                key.threshold_decimal_bps,
            )
            return written
        except (OSError, RuntimeError) as e:
            logger.exception(
                "Cache write failed for %s @ %d dbps",
                key.symbol,
                key.threshold_decimal_bps,
            )
            msg = f"Failed to write bars for {key.symbol}: {e}"
            raise CacheWriteError(
                msg,
                symbol=key.symbol,
                operation="write",
            ) from e

    def get_open_deviation_bars(self, key: CacheKey) -> pd.DataFrame | None:
        """Get cached open deviation bars.

        Parameters
        ----------
        key : CacheKey
            Cache key to lookup

        Returns
        -------
        pd.DataFrame | None
            OHLCV DataFrame if found, None otherwise

        Raises
        ------
        CacheReadError
            If the query fails due to database errors.
        """
        query = """
            SELECT
                close_time_ms,
                open as Open,
                high as High,
                low as Low,
                close as Close,
                volume as Volume
            FROM opendeviationbar_cache.open_deviation_bars FINAL
            WHERE symbol = {symbol:String}
              AND threshold_decimal_bps = {threshold_decimal_bps:UInt32}
              AND source_start_ts = {start_ts:Int64}
              AND source_end_ts = {end_ts:Int64}
            ORDER BY close_time_ms
        """
        try:
            # Use Arrow-optimized query for 3x faster DataFrame creation
            df = self.client.query_df_arrow(
                query,
                parameters={
                    "symbol": key.symbol,
                    "threshold_decimal_bps": key.threshold_decimal_bps,
                    "start_ts": key.start_ts,
                    "end_ts": key.end_ts,
                },
                settings=FINAL_READ_SETTINGS,
            )
        except (OSError, RuntimeError) as e:
            logger.exception(
                "Cache read failed for %s @ %d dbps",
                key.symbol,
                key.threshold_decimal_bps,
            )
            msg = f"Failed to read bars for {key.symbol}: {e}"
            raise CacheReadError(
                msg,
                symbol=key.symbol,
                operation="read",
            ) from e

        if df.empty:
            logger.debug(
                "Cache miss for %s @ %d dbps (key: %s)",
                key.symbol,
                key.threshold_decimal_bps,
                key.hash_key[:8],
            )
            return None

        logger.debug(
            "Cache hit: %d bars for %s @ %d dbps",
            len(df),
            key.symbol,
            key.threshold_decimal_bps,
        )

        # Convert to TZ-aware UTC DatetimeIndex (Issue #20: consistent timestamps)
        df["timestamp"] = pd.to_datetime(df["close_time_ms"], unit="ms", utc=True)
        df = df.set_index("timestamp")
        df = df.drop(columns=["close_time_ms"])

        # Convert PyArrow dtypes to numpy for compatibility with fresh computation
        # query_df_arrow returns double[pyarrow], but process_trades returns float64
        df = normalize_arrow_dtypes(df)

        return df

    def has_open_deviation_bars(self, key: CacheKey) -> bool:
        """Check if open deviation bars exist in cache.

        Parameters
        ----------
        key : CacheKey
            Cache key to check

        Returns
        -------
        bool
            True if bars exist
        """
        query = """
            SELECT count() > 0
            FROM opendeviationbar_cache.open_deviation_bars FINAL
            WHERE symbol = {symbol:String}
              AND threshold_decimal_bps = {threshold_decimal_bps:UInt32}
              AND source_start_ts = {start_ts:Int64}
              AND source_end_ts = {end_ts:Int64}
            LIMIT 1
        """
        result = self.client.command(
            query,
            parameters={
                "symbol": key.symbol,
                "threshold_decimal_bps": key.threshold_decimal_bps,
                "start_ts": key.start_ts,
                "end_ts": key.end_ts,
            },
            settings=FINAL_READ_SETTINGS,
        )
        return bool(result)

    def invalidate_open_deviation_bars(self, key: CacheKey) -> int:
        """Invalidate (delete) cached open deviation bars.

        Parameters
        ----------
        key : CacheKey
            Cache key to invalidate

        Returns
        -------
        int
            Number of rows deleted
        """
        # Note: ClickHouse DELETE is async via mutations
        query = """
            ALTER TABLE opendeviationbar_cache.open_deviation_bars
            DELETE WHERE symbol = {symbol:String}
              AND threshold_decimal_bps = {threshold_decimal_bps:UInt32}
              AND source_start_ts = {start_ts:Int64}
              AND source_end_ts = {end_ts:Int64}
        """
        self.client.command(
            query,
            parameters={
                "symbol": key.symbol,
                "threshold_decimal_bps": key.threshold_decimal_bps,
                "start_ts": key.start_ts,
                "end_ts": key.end_ts,
            },
        )
        return 0  # ClickHouse DELETE is async, can't return count

    def invalidate_open_deviation_bars_by_range(
        self,
        symbol: str,
        threshold_decimal_bps: int,
        start_timestamp_ms: int,
        end_timestamp_ms: int,
        *,
        ouroboros_mode: str,  # Issue #126: MANDATORY — prevent cross-mode deletion
    ) -> int:
        """Invalidate (delete) cached bars within a timestamp range.

        Unlike `invalidate_open_deviation_bars()` which requires
        an exact CacheKey match,
        this method deletes all bars for a symbol/threshold within a time range.
        Useful for overlap detection during precomputation.

        Issue #126: ouroboros_mode is mandatory to prevent cross-mode data
        destruction during force_refresh operations.

        Parameters
        ----------
        symbol : str
            Trading symbol (e.g., "BTCUSDT")
        threshold_decimal_bps : int
            Threshold in decimal basis points
        start_timestamp_ms : int
            Start timestamp in milliseconds (inclusive)
        end_timestamp_ms : int
            End timestamp in milliseconds (inclusive)
        ouroboros_mode : str
            Ouroboros mode filter — only delete bars with this mode.

        Returns
        -------
        int
            Always returns 0 (ClickHouse DELETE is async via mutations)

        Examples
        --------
        >>> cache.invalidate_open_deviation_bars_by_range(
        ...     "BTCUSDT", 250,
        ...     start_timestamp_ms=1704067200000,  # 2024-01-01
        ...     end_timestamp_ms=1706745600000,    # 2024-01-31
        ...     ouroboros_mode="month",
        ... )
        """
        query = """
            ALTER TABLE opendeviationbar_cache.open_deviation_bars
            DELETE WHERE symbol = {symbol:String}
              AND threshold_decimal_bps = {threshold:UInt32}
              AND ouroboros_mode = {ouroboros:String}
              AND close_time_ms >= {start_ts:Int64}
              AND close_time_ms <= {end_ts:Int64}
        """
        self.client.command(
            query,
            parameters={
                "symbol": symbol,
                "threshold": threshold_decimal_bps,
                "ouroboros": ouroboros_mode,
                "start_ts": start_timestamp_ms,
                "end_ts": end_timestamp_ms,
            },
        )
        return 0  # ClickHouse DELETE is async, can't return count

    def get_last_bar_before(
        self,
        symbol: str,
        threshold_decimal_bps: int,
        before_timestamp_ms: int,
        ouroboros_mode: str | None = None,
    ) -> dict | None:
        """Get the last bar before a given timestamp.

        Useful for validating continuity at junction points during
        incremental precomputation.

        Parameters
        ----------
        symbol : str
            Trading symbol (e.g., "BTCUSDT")
        threshold_decimal_bps : int
            Threshold in decimal basis points
        before_timestamp_ms : int
            Timestamp boundary in milliseconds
        ouroboros_mode : str | None
            Ouroboros mode filter. If None, resolved from config.  # Issue #126

        Returns
        -------
        dict | None
            Last bar as dict with OHLCV keys, or None if no bars found

        Examples
        --------
        >>> bar = cache.get_last_bar_before("BTCUSDT", 250, 1704067200000)
        >>> if bar:
        ...     print(f"Last close: {bar['Close']}")
        """
        if ouroboros_mode is None:
            from opendeviationbar.ouroboros import get_operational_ouroboros_mode

            ouroboros_mode = get_operational_ouroboros_mode()

        query = """
            SELECT close_time_ms, open, high, low, close, volume
            FROM opendeviationbar_cache.open_deviation_bars FINAL
            WHERE symbol = {symbol:String}
              AND threshold_decimal_bps = {threshold:UInt32}
              AND ouroboros_mode = {ouroboros:String}
              AND close_time_ms < {before_ts:Int64}
            ORDER BY close_time_ms DESC
            LIMIT 1
        """
        result = self.client.query(
            query,
            parameters={
                "symbol": symbol,
                "threshold": threshold_decimal_bps,
                "ouroboros": ouroboros_mode,
                "before_ts": before_timestamp_ms,
            },
            settings=FINAL_READ_SETTINGS,
        )

        rows = result.result_rows
        if not rows:
            return None

        row = rows[0]
        return {
            "close_time_ms": row[0],
            "Open": row[1],
            "High": row[2],
            "Low": row[3],
            "Close": row[4],
            "Volume": row[5],
        }
