"""fastapi-telemetry — Prometheus metrics middleware and circuit breaker listener for FastAPI."""

__version__ = "0.0.1"
