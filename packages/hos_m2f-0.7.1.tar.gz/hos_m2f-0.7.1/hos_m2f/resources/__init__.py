"""资源管理模块"""

from hos_m2f.resources.resource_manager import ResourceManager

__all__ = ['ResourceManager']
