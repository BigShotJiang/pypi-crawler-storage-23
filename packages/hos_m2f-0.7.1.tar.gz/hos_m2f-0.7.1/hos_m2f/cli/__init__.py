"""CLI模块"""

from .cli import CLI, main

__all__ = ['CLI', 'main']
