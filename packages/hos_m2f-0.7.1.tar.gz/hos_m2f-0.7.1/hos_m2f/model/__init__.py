"""中间层模型定义包"""

from hos_m2f.model.universal_model import UniversalDocumentModel

__all__ = ["UniversalDocumentModel"]