"""HOS-M2F: Markdown to Industry Standard Format Compiler Engine"""

__version__ = "1.0.0"
__author__ = "HOS Team"

# 尝试导入Engine模块，但如果失败也不会中断
Engine = None
try:
    from hos_m2f.engine.engine import Engine
    __all__ = ["Engine"]
except ImportError:
    # 如果导入失败，只导出版本信息
    __all__ = []