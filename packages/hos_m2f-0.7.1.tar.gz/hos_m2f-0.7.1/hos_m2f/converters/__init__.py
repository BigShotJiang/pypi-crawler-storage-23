"""基础格式互转模块"""

from hos_m2f.converters.base_converter import BaseConverter
from hos_m2f.converters.md_to_docx import MDToDOCXConverter
from hos_m2f.converters.md_to_json import MDToJSONConverter
from hos_m2f.converters.md_to_xml import MDToXMLConverter
from hos_m2f.converters.md_to_html import MDToHTMLConverter
from hos_m2f.converters.docx_to_md import DOCXToMDConverter
from hos_m2f.converters.docx_to_xml import DOCXToXMLConverter
from hos_m2f.converters.docx_to_xml_lxml import DOCXToXMLLXMLConverter
from hos_m2f.converters.json_to_md import JSONToMDConverter
from hos_m2f.converters.xml_to_md import XMLToMDConverter
from hos_m2f.converters.xml_to_docx import XMLToDOCXConverter
from hos_m2f.converters.pdf_to_md import PDFToMDConverter

# 尝试导入可能失败的模块
MDToEPUBConverter = None
MDToLaTeXConverter = None
DOCXToHTMLConverter = None
EPUBToMDConverter = None
HTMLToDOCXConverter = None

try:
    from hos_m2f.converters.md_to_epub import MDToEPUBConverter
except ImportError:
    pass

try:
    from hos_m2f.converters.md_to_latex import MDToLaTeXConverter
except ImportError:
    pass

try:
    from hos_m2f.converters.docx_to_html import DOCXToHTMLConverter
except ImportError:
    pass

try:
    from hos_m2f.converters.epub_to_md import EPUBToMDConverter
except ImportError:
    pass

try:
    from hos_m2f.converters.html_to_docx import HTMLToDOCXConverter
except ImportError:
    pass

__all__ = [
    "BaseConverter",
    "MDToDOCXConverter",
    "MDToJSONConverter",
    "MDToXMLConverter",
    "MDToHTMLConverter",
    "DOCXToMDConverter",
    "DOCXToXMLConverter",
    "DOCXToXMLLXMLConverter",
    "JSONToMDConverter",
    "XMLToMDConverter",
    "XMLToDOCXConverter",
    "PDFToMDConverter",
    "get_converter"
]

# 转换映射
converter_mapping = {
    ("md", "docx"): MDToDOCXConverter,
    ("markdown", "docx"): MDToDOCXConverter,
    ("md", "json"): MDToJSONConverter,
    ("markdown", "json"): MDToJSONConverter,
    ("md", "xml"): MDToXMLConverter,
    ("markdown", "xml"): MDToXMLConverter,
    ("md", "html"): MDToHTMLConverter,
    ("markdown", "html"): MDToHTMLConverter,
    ("docx", "md"): DOCXToMDConverter,
    ("docx", "markdown"): DOCXToMDConverter,
    ("docx", "xml"): DOCXToXMLConverter,
    ("json", "md"): JSONToMDConverter,
    ("json", "markdown"): JSONToMDConverter,
    ("xml", "md"): XMLToMDConverter,
    ("xml", "markdown"): XMLToMDConverter,
    ("xml", "docx"): XMLToDOCXConverter,
    ("pdf", "md"): PDFToMDConverter,
    ("pdf", "markdown"): PDFToMDConverter
}

# 添加可能的转换器
if MDToEPUBConverter:
    converter_mapping[("md", "epub")] = MDToEPUBConverter
    converter_mapping[("markdown", "epub")] = MDToEPUBConverter
    __all__.append("MDToEPUBConverter")

if MDToLaTeXConverter:
    converter_mapping[("md", "latex")] = MDToLaTeXConverter
    converter_mapping[("markdown", "latex")] = MDToLaTeXConverter
    __all__.append("MDToLaTeXConverter")

if DOCXToHTMLConverter:
    converter_mapping[("docx", "html")] = DOCXToHTMLConverter
    __all__.append("DOCXToHTMLConverter")

if EPUBToMDConverter:
    converter_mapping[("epub", "md")] = EPUBToMDConverter
    converter_mapping[("epub", "markdown")] = EPUBToMDConverter
    __all__.append("EPUBToMDConverter")

if HTMLToDOCXConverter:
    converter_mapping[("html", "docx")] = HTMLToDOCXConverter
    __all__.append("HTMLToDOCXConverter")

def get_converter(from_format: str, to_format: str) -> BaseConverter:
    """获取转换器
    
    Args:
        from_format: 输入格式
        to_format: 输出格式
        
    Returns:
        对应的转换器实例
    """
    # 标准化格式名称
    from_format = from_format.lower()
    to_format = to_format.lower()
    
    # 获取转换器类
    converter_class = converter_mapping.get((from_format, to_format))
    
    if not converter_class:
        # 如果没有找到精确匹配，尝试使用默认转换器
        if from_format in ["md", "markdown"]:
            # Markdown到其他格式
            if to_format == "docx":
                converter_class = MDToDOCXConverter
            elif to_format == "json":
                converter_class = MDToJSONConverter
            elif to_format == "xml":
                converter_class = MDToXMLConverter
            elif to_format == "html":
                converter_class = MDToHTMLConverter
        elif to_format in ["md", "markdown"]:
            # 其他格式到Markdown
            if from_format == "docx":
                converter_class = DOCXToMDConverter
            elif from_format == "pdf":
                converter_class = PDFToMDConverter
        elif from_format == "docx" and to_format == "xml":
            # DOCX到XML
            converter_class = DOCXToXMLConverter
        elif from_format == "xml" and to_format == "docx":
            # XML到DOCX
            converter_class = XMLToDOCXConverter
    
    if not converter_class:
        raise ValueError(f"不支持的格式转换: {from_format} -> {to_format}")
    
    return converter_class()
