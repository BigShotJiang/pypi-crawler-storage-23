"""Markdown到HTML格式转换器"""

from typing import Any, Optional, Dict
import mistune
from hos_m2f.converters.base_converter import BaseConverter


class MDToHTMLConverter(BaseConverter):
    """Markdown到HTML格式转换器"""
    
    def convert(self, input_content: str, options: Optional[Dict[str, Any]] = None) -> bytes:
        """将Markdown转换为HTML
        
        Args:
            input_content: Markdown内容
            options: 转换选项
            
        Returns:
            bytes: HTML文件的二进制数据
        """
        if options is None:
            options = {}
        
        # 创建Markdown渲染器
        markdown = mistune.create_markdown(
            plugins=[
                'url',
                'task_lists',
                'table',
                'strikethrough',
                'footnotes'
            ]
        )
        
        # 转换为HTML
        html_content = markdown(input_content)
        
        # 包装为完整的HTML文档
        full_html = f'''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Markdown Document</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }}
        code {{
            font-family: 'Courier New', Courier, monospace;
            background-color: #f4f4f4;
            padding: 2px 4px;
            border-radius: 3px;
        }}
        pre {{
            background-color: #f4f4f4;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }}
        th {{
            background-color: #f2f2f2;
        }}
    </style>
</head>
<body>
{html_content}
</body>
</html>
'''
        
        return full_html.encode('utf-8')
    
    def get_supported_formats(self) -> tuple:
        """获取支持的格式"""
        return ('markdown', 'html')
