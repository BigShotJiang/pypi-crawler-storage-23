"""版本控制模块"""

from hos_m2f.version.version_control import VersionControl

__all__ = ["VersionControl"]
