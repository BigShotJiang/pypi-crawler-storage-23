"""批量处理模块"""

from hos_m2f.batch.batch_processor import BatchProcessor

__all__ = ['BatchProcessor']
