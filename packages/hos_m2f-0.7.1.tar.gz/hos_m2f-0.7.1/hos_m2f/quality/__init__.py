"""质量控制模块"""

from hos_m2f.quality.quality_control import QualityControl

__all__ = ['QualityControl']
