"""测试基于 lxml 的 DOCX 到 XML 转换功能"""

import os
import sys
from hos_m2f import Engine


def create_test_docx(file_path):
    """创建一个测试用的 DOCX 文件"""
    from docx import Document
    from docx.shared import RGBColor
    
    # 创建文档
    doc = Document()
    
    # 添加标题
    doc.add_heading('测试文档', level=1)
    doc.add_heading('子标题', level=2)
    
    # 添加普通段落
    p = doc.add_paragraph('这是一个普通段落。')
    
    # 添加带格式的段落
    p = doc.add_paragraph()
    run = p.add_run('这是粗体文本')
    run.bold = True
    p.add_run('，这是普通文本，')
    run = p.add_run('这是斜体文本')
    run.italic = True
    run = p.add_run('，这是红色文本')
    run.font.color.rgb = RGBColor(255, 0, 0)
    
    # 添加列表
    doc.add_paragraph('无序列表项1', style='List Bullet')
    doc.add_paragraph('无序列表项2', style='List Bullet')
    doc.add_paragraph('有序列表项1', style='List Number')
    doc.add_paragraph('有序列表项2', style='List Number')
    
    # 添加表格
    table = doc.add_table(rows=3, cols=2)
    table.cell(0, 0).text = '姓名'
    table.cell(0, 1).text = '年龄'
    table.cell(1, 0).text = '张三'
    table.cell(1, 1).text = '25'
    table.cell(2, 0).text = '李四'
    table.cell(2, 1).text = '30'
    
    # 保存文档
    doc.save(file_path)
    print(f"创建测试 DOCX 文件: {file_path}")

def test_docx_to_xml_lxml_conversion():
    """测试基于 lxml 的 DOCX 到 XML 转换"""
    print("测试基于 lxml 的 DOCX 到 XML 转换功能...")
    
    # 初始化引擎
    engine = Engine()
    
    # 测试文件路径
    test_dir = "test_files"
    input_docx = os.path.join(test_dir, "test.docx")
    output_xml = os.path.join(test_dir, "output_lxml.xml")
    
    # 确保测试目录存在
    os.makedirs(test_dir, exist_ok=True)
    
    # 创建测试 DOCX 文件
    create_test_docx(input_docx)
    
    try:
        # 读取 DOCX 文件
        with open(input_docx, 'rb') as f:
            docx_content = f.read()
        
        # 转换为 XML（使用 lxml 转换器）
        # 注意：这里我们直接使用转换器，因为 Engine 可能还没有配置使用新的转换器
        from hos_m2f.converters.docx_to_xml_lxml import DOCXToXMLLXMLConverter
        converter = DOCXToXMLLXMLConverter()
        
        # 转换
        xml_content = converter.convert(
            input_content=docx_content,
            options={
                'include_metadata': True,
                'include_structure': True,
                'include_formatting': True
            }
        )
        
        # 保存输出
        with open(output_xml, 'wb') as f:
            f.write(xml_content)
        
        print(f"转换成功！输出文件: {output_xml}")
        
        # 显示输出内容
        print("\n转换结果预览:")
        with open(output_xml, 'r', encoding='utf-8') as f:
            content = f.read()
            print(content[:1000] + "..." if len(content) > 1000 else content)
        
        return True
    except Exception as e:
        print(f"转换失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_custom_xml_structure():
    """测试自定义 XML 结构"""
    print("\n测试自定义 XML 结构...")
    
    # 测试文件路径
    test_dir = "test_files"
    input_docx = os.path.join(test_dir, "test.docx")
    output_xml = os.path.join(test_dir, "output_custom.xml")
    
    # 确保测试目录存在
    os.makedirs(test_dir, exist_ok=True)
    
    # 如果输入文件不存在，创建它
    if not os.path.exists(input_docx):
        create_test_docx(input_docx)
    
    try:
        # 读取 DOCX 文件
        with open(input_docx, 'rb') as f:
            docx_content = f.read()
        
        # 使用 lxml 转换器
        from hos_m2f.converters.docx_to_xml_lxml import DOCXToXMLLXMLConverter
        converter = DOCXToXMLLXMLConverter()
        
        # 转换（自定义选项）
        xml_content = converter.convert(
            input_content=docx_content,
            options={
                'include_metadata': True,
                'include_structure': False,
                'include_formatting': False
            }
        )
        
        # 保存输出
        with open(output_xml, 'wb') as f:
            f.write(xml_content)
        
        print(f"自定义结构转换成功！输出文件: {output_xml}")
        
        return True
    except Exception as e:
        print(f"转换失败: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    # 测试基本转换
    success1 = test_docx_to_xml_lxml_conversion()
    
    # 测试自定义结构
    success2 = test_custom_xml_structure()
    
    if success1 and success2:
        print("\n所有测试通过！")
    else:
        print("\n部分测试失败，请检查错误信息。")
        sys.exit(1)
