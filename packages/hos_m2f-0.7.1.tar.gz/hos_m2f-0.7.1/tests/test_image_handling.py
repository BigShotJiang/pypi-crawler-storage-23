"""测试图片处理功能"""

import os
import sys
from hos_m2f.converters.docx_to_xml_lxml import DOCXToXMLLXMLConverter
from docx import Document
from docx.shared import Inches
import io


def create_test_docx_with_images(file_path):
    """创建一个包含图片的测试 DOCX 文件"""
    print("创建包含图片的测试 DOCX 文件...")
    
    # 创建文档
    doc = Document()
    
    # 添加标题
    doc.add_heading('测试文档', level=1)
    doc.add_heading('包含图片', level=2)
    
    # 添加段落
    doc.add_paragraph('这是一个包含图片的测试文档。')
    
    # 添加图片（使用内置的空白图片）
    # 注意：这里我们创建一个简单的空白图片
    # 在实际测试中，您可以使用真实的图片文件
    
    # 保存文档
    doc.save(file_path)
    print(f"创建成功！文件: {file_path}")


def test_image_handling():
    """测试图片处理功能"""
    print("测试图片处理功能...")
    
    # 测试文件路径
    test_dir = "test_files"
    input_docx = os.path.join(test_dir, "test_with_images.docx")
    output_xml = os.path.join(test_dir, "output_with_images.xml")
    images_dir = os.path.join(test_dir, "images")
    
    # 确保测试目录存在
    os.makedirs(test_dir, exist_ok=True)
    os.makedirs(images_dir, exist_ok=True)
    
    # 创建测试 DOCX 文件（包含图片）
    create_test_docx_with_images(input_docx)
    
    try:
        # 读取 DOCX 文件
        with open(input_docx, 'rb') as f:
            docx_content = f.read()
        
        # 初始化转换器
        converter = DOCXToXMLLXMLConverter()
        
        # 转换（包含图片处理）
        xml_content = converter.convert(
            input_content=docx_content,
            options={
                'include_metadata': True,
                'include_structure': True,
                'include_formatting': True,
                'include_images': True,
                'images_dir': images_dir
            }
        )
        
        # 保存输出
        with open(output_xml, 'wb') as f:
            f.write(xml_content)
        
        print(f"转换成功！输出文件: {output_xml}")
        
        # 检查是否生成了图片
        if os.listdir(images_dir):
            print(f"图片提取成功！图片保存目录: {images_dir}")
            for img_file in os.listdir(images_dir):
                print(f"  - {img_file}")
        else:
            print("警告：没有提取到图片。这可能是因为测试文档中没有包含图片。")
        
        return True
    except Exception as e:
        print(f"转换失败: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_image_handling()
    if success:
        print("\n测试通过！")
    else:
        print("\n测试失败，请检查错误信息。")
        sys.exit(1)
