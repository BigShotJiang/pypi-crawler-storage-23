default_template = dict(
    templates=[
        dict(
            name='new_template',
            defaults=dict(
                font_size="4u",
                text_color="lightgray",
                color=[0, 0, 0, 150],
                text_spacing=10
            ),
            variables=dict(

            ),
            shapes=[]
        )
    ]
)