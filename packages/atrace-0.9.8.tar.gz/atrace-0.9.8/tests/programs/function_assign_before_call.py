import atrace  # noqa


def double(a):
    return a * 2


x = 3
x = double(5)
