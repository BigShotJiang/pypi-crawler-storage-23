# vd-dlt-notion-schema

Schema, defaults, and documentation for the Notion connector in vd-dlt pipelines.

## Installation

```bash
# Install via vd-dlt extras (recommended)
pip install vd-dlt[notion-schema]

# Or install directly
pip install vd-dlt-notion-schema
```

## Contents

- **defaults.yml** - Resource templates and default sync configuration (30+ Notion API endpoints)
- **schema.json** - JSON Schema for validating Notion credentials
- **manifest.yml** - Connector metadata (name, version, status)
- **docs/** - Connector documentation

## Usage

```python
from vd_dlt_notion_schema import get_defaults, get_schema, get_manifest

# Get connector defaults
defaults = get_defaults()
print(defaults["default_sync"])  # write_disposition, sync_mode, etc.
print(len(defaults["resources"]))  # 30+ resource templates

# Get credentials schema
schema = get_schema()
print(schema["definitions"]["credentials"]["required"])  # ["access_token"]

# Get connector metadata
manifest = get_manifest()
print(manifest["name"])  # "notion"
print(manifest["version"])  # "1.0.0"
```
