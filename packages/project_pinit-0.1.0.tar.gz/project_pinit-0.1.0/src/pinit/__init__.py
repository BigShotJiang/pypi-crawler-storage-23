"""pinit — Python project scaffolding CLI."""

from __future__ import annotations

__version__ = "0.1.0"
