"""Issue handlers module.

Provides abstraction for issue operations on GitHub, GitLab, and other issue trackers.
"""

from .github.handler import GitHubIssueHandler
from .gitlab.handler import GitLabIssueHandler
from .handler import IssueHandler
from .schema import Issue

__all__ = [
    "IssueHandler",
    "GitHubIssueHandler",
    "GitLabIssueHandler",
    "Issue",
]
