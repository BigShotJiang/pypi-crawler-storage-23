"""GitHub-specific issue schemas.

Currently empty - GitHub issues use the shared Issue schema.
Add GitHub-specific issue types here if needed in the future.
"""
