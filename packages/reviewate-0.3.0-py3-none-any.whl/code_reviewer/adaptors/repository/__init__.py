"""Repository handlers module.

Provides abstraction for repository operations on GitHub and GitLab.
"""

from .github.handler import GitHubRepositoryHandler
from .gitlab.handler import GitLabRepositoryHandler
from .handler import RepositoryHandler
from .schema import DiscussionItem, DiscussionItemType, DiscussionNote, MergeRequest

__all__ = [
    "RepositoryHandler",
    "GitHubRepositoryHandler",
    "GitLabRepositoryHandler",
    "MergeRequest",
    "DiscussionItem",
    "DiscussionItemType",
    "DiscussionNote",
]
