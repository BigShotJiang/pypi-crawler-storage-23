from ..logging_config import BaseLogger


class PlatformLogger(BaseLogger):
    """Platform adaptor logger (GitHub/GitLab)"""

    def __init__(self, platform_name: str):
        super().__init__("platform", platform_name)
