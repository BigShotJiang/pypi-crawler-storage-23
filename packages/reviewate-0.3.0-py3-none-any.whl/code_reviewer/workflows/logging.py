from ..logging_config import BaseLogger


class WorkflowLogger(BaseLogger):
    """Structured logger for workflow execution"""

    def __init__(self, workflow_name: str):
        super().__init__("workflow", workflow_name)

    def step(self, step_name: str, step_number: int, total_steps: int) -> None:
        """Log workflow step"""
        self.info(f"Starting step {step_number}/{total_steps}: {step_name}")
