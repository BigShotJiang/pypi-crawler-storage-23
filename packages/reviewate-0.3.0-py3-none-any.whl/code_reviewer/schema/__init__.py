"""Schema module - data models for the code reviewer.

Contains platform-agnostic base models and platform-specific implementations.
"""

# Re-export platform-specific schemas from their new locations
from code_reviewer.adaptors.repository.github.schema import (
    GitHubPullRequest,
    GitHubReviewComment,
)
from code_reviewer.adaptors.repository.gitlab.schema import (
    GitLabMergeRequest,
    GitLabReviewComment,
)

from .base import (
    BasicReviewOutput,
    DiscussionItem,
    DiscussionItemType,
    DiscussionNote,
    GuardrailResult,
    Issue,
    MergeRequest,
    ParsedSummaryOutput,
    PlatformReview,
    ReviewOutput,
    SummaryOutput,
)

__all__ = [
    # Base models
    "BasicReviewOutput",
    "DiscussionItem",
    "DiscussionItemType",
    "DiscussionNote",
    "GuardrailResult",
    "Issue",
    "MergeRequest",
    "ParsedSummaryOutput",
    "PlatformReview",
    "ReviewOutput",
    "SummaryOutput",
    # GitHub models
    "GitHubPullRequest",
    "GitHubReviewComment",
    # GitLab models
    "GitLabMergeRequest",
    "GitLabReviewComment",
]
