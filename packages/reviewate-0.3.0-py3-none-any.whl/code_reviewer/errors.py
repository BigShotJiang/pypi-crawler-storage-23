"""Error types for the code reviewer."""

from enum import StrEnum


class ErrorType(StrEnum):
    """Standardized error types emitted by the code reviewer."""

    NETWORK_ERROR = "network_error"
    AUTHENTICATION_FAILED = "authentication_failed"
    NOT_FOUND = "not_found"
    REQUEST_FAILED = "request_failed"
    INVALID_RESPONSE = "invalid_response"
    EXPLORER_ERROR = "explorer_error"
    VALIDATION_ERROR = "validation_error"
    INTERRUPTED = "interrupted"
    TIMEOUT = "timeout"
    POST_FAILED = "post_failed"
    CONTAINER_ERROR = "container_error"
    INTERNAL_ERROR = "internal_error"


class ReviewateError(Exception):
    """Base error class for all Reviewate errors."""

    pass


class PlatformError(ReviewateError):
    """Errors related to platform interactions."""

    pass


class NetworkError(PlatformError):
    """Network-related errors."""

    def __init__(self, message: str):
        super().__init__(f"Network error: {message}")
        self.message = message


class AuthenticationFailed(PlatformError):
    """Authentication failed error."""

    def __init__(self, message: str):
        super().__init__(f"Authentication failed: {message}")
        self.message = message


class NotFound(PlatformError):
    """Resource not found error."""

    def __init__(self, resource_type: str, identifier: str):
        super().__init__(f"{resource_type} not found: {identifier}")
        self.resource_type = resource_type
        self.identifier = identifier


class RequestFailed(PlatformError):
    """Generic request failure error."""

    def __init__(self, status: int, message: str):
        super().__init__(f"Request failed with status {status}: {message}")
        self.status = status
        self.message = message


class InvalidResponse(PlatformError):
    """Invalid response from platform API."""

    def __init__(self, message: str):
        super().__init__(f"Invalid response: {message}")
        self.message = message


class PostingError(ReviewateError):
    """Error when posting review comments fails."""

    def __init__(self, message: str):
        super().__init__(f"Posting error: {message}")
        self.message = message


class ReviewateValidationError(ReviewateError):
    """Errors related to validation failures."""

    def __init__(self, message: str, invalid_response: str):
        super().__init__(f"Validation error: {message}")
        self.message = message
        self.invalid_response = invalid_response


_EXCEPTION_MAP: dict[type, ErrorType] = {
    NetworkError: ErrorType.NETWORK_ERROR,
    AuthenticationFailed: ErrorType.AUTHENTICATION_FAILED,
    NotFound: ErrorType.NOT_FOUND,
    RequestFailed: ErrorType.REQUEST_FAILED,
    InvalidResponse: ErrorType.INVALID_RESPONSE,
    ReviewateValidationError: ErrorType.VALIDATION_ERROR,
    PostingError: ErrorType.POST_FAILED,
}


def error_type_for_exception(exc: Exception) -> ErrorType:
    """Map an exception to a standardized ErrorType."""
    for exc_class, error_type in _EXCEPTION_MAP.items():
        if isinstance(exc, exc_class):
            return error_type
    return ErrorType.INTERNAL_ERROR
