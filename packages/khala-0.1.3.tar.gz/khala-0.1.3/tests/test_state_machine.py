import pytest
from khala.state_machine import DeviceState, can_transition, transition


def test_can_transition():
    assert can_transition(DeviceState.Added, DeviceState.Booting)
    assert not can_transition(DeviceState.Added, DeviceState.Active)
    assert can_transition(DeviceState.Booting, DeviceState.Identified)
    assert can_transition(DeviceState.Identified, DeviceState.Active)


def test_transition():
    assert transition(DeviceState.Added, DeviceState.Booting) == DeviceState.Booting
    assert transition(DeviceState.Added, DeviceState.Active) == DeviceState.Added
    invalid_calls = []
    assert transition(
        DeviceState.Added, DeviceState.Active,
        on_invalid=lambda c, n: invalid_calls.append((c, n)),
    ) == DeviceState.Added
    assert len(invalid_calls) == 1 and invalid_calls[0] == (DeviceState.Added, DeviceState.Active)
