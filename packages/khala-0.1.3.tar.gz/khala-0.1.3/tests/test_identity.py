import pytest
from khala.identity import serial_to_mac, parse_serial_from_cpuinfo, provisioning_script


def test_serial_to_mac():
    mac = serial_to_mac("12345678")
    assert mac.startswith("02:50:4B:")
    assert len(mac.split(":")) == 6
    assert serial_to_mac("abc") != serial_to_mac("abd")


def test_serial_to_mac_empty():
    with pytest.raises(ValueError):
        serial_to_mac("")
    with pytest.raises(ValueError):
        serial_to_mac("   ")


def test_parse_serial_from_cpuinfo():
    assert parse_serial_from_cpuinfo(["Serial\t\t: abc123"]) == "abc123"
    assert parse_serial_from_cpuinfo("Serial : xyz\n") == "xyz"
    assert parse_serial_from_cpuinfo(["line1", "Serial : 999"]) == "999"
    assert parse_serial_from_cpuinfo(["no serial here"]) is None


def test_provisioning_script():
    script = provisioning_script("02:50:4B:aa:bb:cc")
    assert "ifconfig eth0 hw ether 02:50:4B:aa:bb:cc" in script
    assert "udhcpc" in script
    assert "telnetd" in script
