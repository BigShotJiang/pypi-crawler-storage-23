from khala.network import parse_ip_from_addr_output


def test_parse_ip_from_addr_output():
    text = "2: eth0: <BROADCAST>\n    inet 192.168.1.100/24 brd 192.168.1.255"
    assert parse_ip_from_addr_output(text) == "192.168.1.100"
    assert parse_ip_from_addr_output(text.splitlines()) == "192.168.1.100"
    assert parse_ip_from_addr_output("no inet here") is None
