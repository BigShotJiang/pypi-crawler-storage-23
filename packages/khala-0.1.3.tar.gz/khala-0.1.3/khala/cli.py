# CLI: khala add / add all / list / activate / deactivate

import glob
import os
import socket
import sys
import threading
import json
import http.server
import socketserver
from urllib import request as urlrequest, error as urlerror

import click
import sdev
from sdev.demoboard import check_alive as sdev_check_alive

from . import KhalaDevice, KhalaServer
from .identity import parse_serial_from_cpuinfo
from .network import parse_ip_from_addr_output
from .registry import (
    DEFAULT_REGISTRY_PATH,
    clear as registry_clear,
    get,
    set_entry,
    list_all,
    get_active_stack,
    push_activated,
    pop_activated,
    pop_all_activated_by_host,
    remove_from_activated,
    key,
)

VERBOSE_FILE = os.path.join(os.path.dirname(DEFAULT_REGISTRY_PATH), "verbose")
REMOTES_ENV = "KHALA_REMOTES"


def _is_verbose() -> bool:
    """是否开启串口日志：默认开启；存在 VERBOSE_FILE 时表示关闭。"""
    return not os.path.isfile(VERBOSE_FILE)


def _set_verbose(on: bool) -> None:
    """设置全局：是否显示串口日志。on=True 表示开启，on=False 表示关闭。"""
    if on:
        # 删除“关闭标记”文件，使后续 _is_verbose() 返回 True
        if os.path.isfile(VERBOSE_FILE):
            try:
                os.remove(VERBOSE_FILE)
            except OSError:
                pass
    else:
        # 创建“关闭标记”文件，使后续 _is_verbose() 返回 False
        os.makedirs(os.path.dirname(VERBOSE_FILE), exist_ok=True)
        open(VERBOSE_FILE, "a").close()


def _apply_serial_output(board, verbose: bool) -> None:
    """按全局设置应用 sdev 的 silence/display：默认打印串口日志。"""
    if verbose:
        board._silent = False
        board._display = True
    else:
        board.silence()
        board._display = False


def _list_serial_ports() -> list[str]:
    """跨平台枚举串口：Linux 用 /dev/ttyUSB* + ttyACM*，Windows 用 pyserial 枚举 COM*。"""
    if sys.platform == "win32":
        try:
            import serial.tools.list_ports
            return sorted(p.device for p in serial.tools.list_ports.comports())
        except ImportError:
            return [f"COM{i}" for i in range(1, 17)]
    ports = sorted(glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*"))
    return ports


def _hostname() -> str:
    try:
        return socket.gethostname() or "localhost"
    except Exception:
        return "localhost"


def _get_local_ip() -> str:
    """获取本机局域网 IP，用于 mDNS 注册。"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(0)
            s.connect(("10.255.255.255", 1))
            return s.getsockname()[0]
    except Exception:
        pass
    try:
        return socket.gethostbyname(socket.gethostname())
    except Exception:
        return "127.0.0.1"


_KHALA_SERVICE_TYPE = "_khala._tcp.local."


def _discover_khala_servers(timeout: float = 2.0) -> list[str]:
    """通过 mDNS 发现局域网内 khala serve，返回 endpoint 列表（host:port）。无 zeroconf 或超时返回 []。"""
    try:
        from zeroconf import Zeroconf, ServiceBrowser, ServiceStateChange
    except ImportError:
        return []
    found: list[str] = []

    def on_state_change(zeroconf, service_type, name, state_change, **kwargs):  # type: ignore[no-untyped-def]
        if state_change != ServiceStateChange.Added:
            return
        info = zeroconf.get_service_info(service_type, name, timeout=1000)
        if not info or not info.port:
            return
        fn = getattr(info, "parsed_scoped_addresses", None) or getattr(info, "parsed_addresses", None)
        addrs = list(fn()) if callable(fn) else []
        if not addrs and getattr(info, "addresses", None):
            import ipaddress
            addrs = [str(ipaddress.ip_address(bytes(a))) for a in info.addresses]
        for addr in (addrs or ["127.0.0.1"])[:1]:
            ep = f"{addr}:{info.port}"
            if ep not in found:
                found.append(ep)
            break

    zc = Zeroconf()
    try:
        browser = ServiceBrowser(zc, _KHALA_SERVICE_TYPE, handlers=[on_state_change])
        import time
        time.sleep(timeout)
    finally:
        zc.close()
    return found


@click.group()
@click.option("--registry", "-r", default=DEFAULT_REGISTRY_PATH, help="Registry JSON 路径")
@click.pass_context
def main(ctx, registry):
    ctx.ensure_object(dict)
    ctx.obj["registry"] = registry or DEFAULT_REGISTRY_PATH
    ctx.obj["verbose"] = _is_verbose()


@main.command("add")
@click.option("-D", "--device", "port", required=False, help="串口设备路径")
@click.option("-n", "--name", required=False, help="设备名称")
@click.option("-b", "--baudrate", default=115200, help="波特率")
@click.option("--no-check", is_flag=True, help="不进行 check_alive，仅登记到 registry（默认会握手验证）")
@click.option("--on", "on_host", default=None, help="在指定主机上执行 add（host 名或 host:port）；需该机运行 khala serve")
@click.option("--remote", "remotes", multiple=True, help="远程 serve 地址，用于解析 --on 的 host")
@click.argument("mode", required=False, default="manual")
@click.pass_context
def add_cmd(ctx, port, name, baudrate, no_check, on_host, remotes, mode):
    """手动添加: khala add -D /dev/ttyUSB0 -n xc01（Windows: -D COM3）；自动发现: khala add all；跨机: khala add --on <host> -D <port> -n x"""
    reg = ctx.obj["registry"]
    verbose = ctx.obj.get("verbose", False)
    if on_host:
        endpoints = _get_remote_endpoints(list(remotes))
        endpoint = on_host if ":" in on_host else _build_remote_host_to_endpoint(endpoints).get(on_host)
        if not endpoint:
            click.echo(f"未找到主机 {on_host} 的 serve 地址（请配置 KHALA_REMOTES 或 --remote）", err=True)
            raise SystemExit(1)
        mode_norm = (mode or "").strip().lower()
        if mode_norm in {"all", "auto"}:
            body = _remote_post(endpoint, "/add", {"mode": "all", "baudrate": baudrate, "verbose": verbose}, timeout=120.0)
        else:
            if not port or not name:
                click.echo("跨机添加请指定 -D 与 -n", err=True)
                raise SystemExit(1)
            body = _remote_post(endpoint, "/add", {"port": port, "name": name, "baudrate": baudrate, "no_check": no_check, "verbose": verbose}, timeout=60.0)
        if not body.get("ok"):
            click.echo(body.get("error", "未知错误"), err=True)
            raise SystemExit(1)
        if body.get("added") is not None:
            click.echo(f"Device(s) added on {on_host} (auto): {body.get('added')} added")
        else:
            click.echo(f"Device {body.get('name', name)} ({body.get('port', port)}) added successfully on {on_host}")
        return
    mode_norm = (mode or "").strip().lower()
    if mode_norm in {"all", "auto"}:
        result = _do_add_all(reg, baudrate, name, verbose)
        if not result.get("ok"):
            click.echo(result.get("error", "未知错误"), err=True)
            raise SystemExit(1)
        click.echo(f"{result.get('added', 0)} device(s) added (auto)")
        return
    if not port or not name:
        click.echo("手动添加请指定 -D <串口路径> -n <name>（Linux: /dev/ttyUSB0；Windows: COM3）", err=True)
        raise SystemExit(1)
    result = _do_add(reg, port, name, baudrate, no_check, verbose)
    if not result.get("ok"):
        click.echo(result.get("error", "未知错误"), err=True)
        raise SystemExit(1)
    click.echo(f"Device {result.get('name')} ({result.get('port')}) added successfully")


@main.command("list")
@click.option(
    "--remote",
    "remotes",
    multiple=True,
    help="额外聚合的远程 khala serve 地址（host:port），可多次指定；也可通过环境变量 KHALA_REMOTES 配置，逗号分隔",
)
@click.pass_context
def list_cmd(ctx, remotes):
    """显示本地及远程 Host 的所有设备。"""
    reg = ctx.obj["registry"]
    # 本地 registry
    devices = list_all(reg)
    active_keys = set(get_active_stack(reg))

    remote_endpoints = _get_remote_endpoints(list(remotes))
    if not remote_endpoints:
        remote_endpoints = _discover_khala_servers()
    for endpoint in remote_endpoints:
        try:
            r_devices, r_active, _ = _fetch_remote_registry(endpoint)
            devices.extend(r_devices)
            active_keys.update(r_active)
        except Exception as e:
            click.echo(f"跳过远程 {endpoint}: {e}", err=True)

    # 表头顺序：Host Device Name Active IP Owner
    click.echo(f"{'Host':<16} {'Device':<14} {'Name':<10} {'Active':<8} {'IP':<16} {'Owner':<16}")
    click.echo("-" * 86)
    for d in devices:
        host = d.get("host", "")
        name = d.get("name", "")
        port = d.get("port", "")
        ip = d.get("ip", "") or ""
        owner = d.get("owner", "") or "-"
        k = key(host, name)
        active = "*" if k in active_keys else ""
        click.echo(f"{host:<16} {port:<14} {name:<10} {active:<8} {ip:<16} {owner:<16}")
    if not devices:
        click.echo("（无设备）本机需先执行 khala add -D <串口> -n <名称> 或 khala add all；查看远端可在 A 机运行 khala serve 后 B 机直接 khala list（同局域网 mDNS 自动发现），或设置 KHALA_REMOTES=host:9412。")


def _get_remote_endpoints(remotes_from_opt: list[str] | None = None) -> list[str]:
    """从环境变量 KHALA_REMOTES（逗号分隔）与可选命令行 --remote 合并去重。"""
    endpoints: list[str] = []
    env_val = os.environ.get(REMOTES_ENV, "")
    if env_val:
        for part in env_val.split(","):
            part = part.strip()
            if part and part not in endpoints:
                endpoints.append(part)
    for r in remotes_from_opt or []:
        if r and r not in endpoints:
            endpoints.append(r)
    return endpoints


def _fetch_remote_registry(endpoint: str) -> tuple[list[dict], list[str], str]:
    """从远程 khala serve 拉取 registry。返回 (devices, active_stack, host)。"""
    url = f"http://{endpoint}/registry"
    try:
        with urlrequest.urlopen(url, timeout=5.0) as resp:
            data = resp.read().decode("utf-8")
    except urlerror.URLError as e:
        raise RuntimeError(f"无法连接: {e}") from e
    try:
        payload = json.loads(data)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"返回数据格式错误: {e}") from e
    devices = payload.get("devices") or []
    active = payload.get("active_stack") or []
    host = payload.get("host") or ""
    if host:
        for d in devices:
            d.setdefault("host", host)
    return devices, list(active), host


def _build_remote_host_to_endpoint(endpoints: list[str]) -> dict[str, str]:
    """拉取所有远端 /registry，得到 host -> endpoint 映射。"""
    out: dict[str, str] = {}
    for ep in endpoints:
        try:
            _, _, host = _fetch_remote_registry(ep)
            if host:
                out[host] = ep
        except Exception:
            pass
    return out


def _resolve_target_to_endpoint(
    target: str, reg: str, remote_host_to_endpoint: dict[str, str]
) -> tuple[str | None, str | None, str | None]:
    """解析 target 为 (host, name, endpoint)。endpoint 为 None 表示本机。未找到返回 (None,None,None)。"""
    me = _hostname()
    # 先查本机 registry
    resolved = _resolve_target(target, reg)
    if resolved:
        host, name = resolved
        if host == me:
            return (host, name, None)
        ep = remote_host_to_endpoint.get(host)
        if ep:
            return (host, name, ep)
        return (host, name, None)
    # 本机未找到：从远端聚合里找
    for host, ep in remote_host_to_endpoint.items():
        try:
            devices, _, _ = _fetch_remote_registry(ep)
            for d in devices:
                h = d.get("host", "")
                n = d.get("name", "")
                if ":" in target:
                    h2, n2 = target.split(":", 1)
                    if h2.strip() == h and n2.strip() == n:
                        return (h, n, ep)
                else:
                    if n == target and h == host:
                        return (h, n, ep)
        except Exception:
            continue
    return (None, None, None)


def _remote_post(endpoint: str, path: str, body: dict, timeout: float = 60.0) -> dict:
    """向远端 khala serve 发 POST，返回 JSON。"""
    url = f"http://{endpoint}{path}"
    req = urlrequest.Request(url, data=json.dumps(body).encode("utf-8"), method="POST")
    req.add_header("Content-Type", "application/json")
    try:
        with urlrequest.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urlerror.URLError as e:
        return {"ok": False, "error": str(e)}
    except json.JSONDecodeError as e:
        return {"ok": False, "error": f"响应非 JSON: {e}"}


def _resolve_target(target: str, reg: str) -> tuple[str, str] | None:
    """解析 target 为 (host, name)。target 可为 name 或 host:name。"""
    if ":" in target:
        parts = target.split(":", 1)
        return (parts[0].strip(), parts[1].strip())
    host = _hostname()
    e = get(host, target, path=reg)
    if e:
        return (host, target)
    for d in list_all(reg):
        if d.get("name") == target:
            return (d.get("host", ""), d.get("name", ""))
    return None


def _do_activate(reg_path: str, target: str, verbose: bool) -> dict:
    """在本机执行 activate，供 CLI 与 serve 复用。返回 {"ok": True, "ip": "..."} 或 {"ok": False, "error": "..."}。"""
    resolved = _resolve_target(target, reg_path)
    if not resolved:
        return {"ok": False, "error": f"未找到设备: {target}"}
    host, name = resolved
    e = get(host, name, path=reg_path)
    if not e:
        return {"ok": False, "error": f"未找到设备: {target}"}
    if key(host, name) in get_active_stack(reg_path):
        return {"ok": False, "error": "设备已处于激活状态"}
    port = e.get("port", "")
    if not port:
        return {"ok": False, "error": "设备无串口路径"}
    try:
        device = KhalaDevice(port, name, baudrate=e.get("baudrate", 115200))
        _apply_serial_output(device.board, verbose)
        for attempt in range(2):
            try:
                device.board.connect()
                device.board.check_alive(block=True, timeout=10.0)
                break
            except Exception as ex:
                if attempt == 0:
                    try:
                        device.board.disconnect()
                    except Exception:
                        pass
                    continue
                raise
        if not device.serial:
            out = device.board.shell("cat /proc/cpuinfo", timeout=10.0)
            if not isinstance(out, list):
                out = list(out)
            serial = parse_serial_from_cpuinfo(out)
            if serial:
                device.set_identified(serial)
        if not device.mac:
            return {"ok": False, "error": "无法获取 Serial/MAC"}
        device.board.shell("ifconfig eth0 down", timeout=8.0)
        device.board.shell(f"ifconfig eth0 hw ether {device.mac}", timeout=8.0)
        device.board.shell("ifconfig eth0 up", timeout=8.0)
        device.board.shell("udhcpc -i eth0 -n &", prompt_flag="Done", timeout=30.0)
        device.board.shell(None, timeout=5.0)
        device.board.shell("/usr/sbin/telnetd -p 23 -l /bin/sh", timeout=8.0)
        out = device.board.shell("ip addr show eth0", timeout=8.0)
        if not isinstance(out, list):
            out = list(out)
        ip = parse_ip_from_addr_output(out)
        if ip:
            device.set_active(ip)
            set_entry(host, name, mac=device.mac, ip=ip, state="Active", owner=_hostname(), path=reg_path)
            push_activated(host, name, path=reg_path)
            return {"ok": True, "ip": ip, "key": key(host, name)}
        set_entry(host, name, mac=device.mac, state="Identified", path=reg_path)
        return {"ok": True, "ip": None, "key": key(host, name)}
    except Exception as ex:
        msg = str(ex)
        if any(k in msg.lower() for k in ("deadline", "timeout", "exceeded", "no response")):
            msg = f"设备未响应（串口超时），请检查连接与板子启动状态。原始错误: {msg}"
        return {"ok": False, "error": msg}


def _do_deactivate_last(reg_path: str, verbose: bool) -> dict:
    """退栈最后一个并 reboot。"""
    k = pop_activated(reg_path)
    if not k:
        return {"ok": False, "error": "无已激活设备"}
    parts = k.split(":", 1)
    host = parts[0] if len(parts) == 2 else _hostname()
    name = parts[1] if len(parts) == 2 else parts[0]
    e = get(host, name, path=reg_path)
    if not e:
        return {"ok": True, "key": k}
    port = e.get("port", "")
    if port:
        try:
            dev = KhalaDevice(port, name)
            _apply_serial_output(dev.board, verbose)
            dev.board.connect()
            dev.board.send("reboot")
        except Exception:
            pass
    set_entry(host, name, ip="", state="Identified", owner="", path=reg_path)
    return {"ok": True, "key": k}


def _do_deactivate_all(reg_path: str, verbose: bool) -> dict:
    """本机激活的全部退栈。"""
    me = _hostname()
    removed = pop_all_activated_by_host(me, reg_path)
    if not removed:
        return {"ok": False, "error": "本机无已激活设备"}
    for k in removed:
        parts = k.split(":", 1)
        host = parts[0] if len(parts) == 2 else me
        name = parts[1] if len(parts) == 2 else parts[0]
        e = get(host, name, path=reg_path)
        if e and e.get("port"):
            try:
                dev = KhalaDevice(e["port"], name)
                _apply_serial_output(dev.board, verbose)
                dev.board.connect()
                dev.board.send("reboot")
            except Exception:
                pass
        set_entry(host, name, ip="", state="Identified", owner="", path=reg_path)
    return {"ok": True, "removed": removed}


def _do_deactivate_target(reg_path: str, host: str, name: str, verbose: bool) -> dict:
    """对指定 host:name 退栈并 reboot（需在本机 registry 且为本机 host）。"""
    me = _hostname()
    if host != me:
        return {"ok": False, "error": "只能对本机设备执行 deactivate"}
    e = get(host, name, path=reg_path)
    if not e:
        return {"ok": False, "error": "未找到设备"}
    k = key(host, name)
    if not remove_from_activated(host, name, reg_path):
        pass  # 本来就不在栈里也视为成功
    port = e.get("port", "")
    if port:
        try:
            dev = KhalaDevice(port, name)
            _apply_serial_output(dev.board, verbose)
            dev.board.connect()
            dev.board.send("reboot")
        except Exception:
            pass
    set_entry(host, name, ip="", state="Identified", owner="", path=reg_path)
    return {"ok": True, "key": k}


def _do_add(
    reg_path: str,
    port: str,
    name: str,
    baudrate: int = 115200,
    no_check: bool = False,
    verbose: bool = False,
) -> dict:
    """本机添加单设备。"""
    if not port or not name:
        return {"ok": False, "error": "请指定 -D 与 -n"}
    if not no_check:
        try:
            board = sdev.Demoboard(port, baudrate, check_alive=False)
            _apply_serial_output(board, verbose)
            board.connect()
            board.check_alive(block=True, timeout=10.0)
        except Exception as e:
            return {"ok": False, "error": f"check_alive 失败: {e}"}
    set_entry(_hostname(), name, port=port, state="Added", path=reg_path)
    return {"ok": True, "name": name, "port": port}


def _do_add_all(reg_path: str, baudrate: int = 115200, name_override: str | None = None, verbose: bool = False) -> dict:
    """本机自动发现并添加（跨平台：Linux /dev/ttyUSB*|ttyACM*，Windows COM*）。"""
    ports = _list_serial_ports()
    if not ports:
        return {"ok": False, "error": "未发现串口设备（Linux: /dev/ttyUSB*, ttyACM*；Windows: COM*）", "added": 0}
    added = 0
    for p in ports:
        short = p.split("/")[-1] if "/" in p else p
        try:
            board = sdev.Demoboard(p, baudrate, check_alive=False)
            _apply_serial_output(board, verbose)
            board.connect()
        except Exception:
            continue
        if sdev_check_alive(board, block=False, timeout=2.0) is not True:
            continue
        n = name_override or short
        set_entry(_hostname(), n, port=p, state="Added", path=reg_path)
        added += 1
    return {"ok": True, "added": added}


@main.command("activate")
@click.option("--remote", "remotes", multiple=True, help="远程 serve 地址 host:port，可多次指定；同 list")
@click.argument("target")
@click.pass_context
def activate_cmd(ctx, remotes, target):
    """激活设备：注入网络配置并获取 IP。target 为 name 或 host:name；可跨机操作。"""
    reg = ctx.obj["registry"]
    endpoints = _get_remote_endpoints(list(remotes))
    if not endpoints:
        endpoints = _discover_khala_servers()
    host_to_ep = _build_remote_host_to_endpoint(endpoints)
    host, name, endpoint = _resolve_target_to_endpoint(target, reg, host_to_ep)
    if host is None:
        click.echo(f"未找到设备: {target}", err=True)
        raise SystemExit(1)
    if endpoint:
        body = _remote_post(endpoint, "/activate", {"target": name}, timeout=120.0)
        if not body.get("ok"):
            click.echo(body.get("error", "未知错误"), err=True)
            raise SystemExit(1)
        ip = body.get("ip")
        if ip:
            click.echo("device {} activated at port: {}".format(key(host, name), ip))
        else:
            click.echo("device activated but IP not detected; check eth0 / udhcpc")
        return
    result = _do_activate(reg, target, ctx.obj.get("verbose", False))
    if not result.get("ok"):
        click.echo(result.get("error", "未知错误"), err=True)
        raise SystemExit(1)
    ip = result.get("ip")
    k = result.get("key", key(host, name))
    if ip:
        click.echo("device {} activated at port: {}".format(k, ip))
    else:
        click.echo("device activated but IP not detected; check eth0 / udhcpc")


@main.command("deactivate")
@click.option("--remote", "remotes", multiple=True, help="远程 serve 地址，同 list/activate")
@click.argument("scope", required=False, default="last")
@click.pass_context
def deactivate_scope_cmd(ctx, remotes, scope):
    """退栈：deactivate（默认）退本机最后一个；deactivate all 退本机+所有远端；deactivate host:name 退指定设备。"""
    reg = ctx.obj["registry"]
    verbose = ctx.obj.get("verbose", False)
    scope_norm = (scope or "last").strip().lower()
    if scope_norm == "all":
        result = _do_deactivate_all(reg, verbose)
        if not result.get("ok"):
            click.echo(result.get("error", "未知错误"), err=True)
            raise SystemExit(1)
        removed = result.get("removed", [])
        endpoints = _get_remote_endpoints(list(remotes))
        if not endpoints:
            endpoints = _discover_khala_servers()
        for ep in endpoints:
            body = _remote_post(ep, "/deactivate", {"scope": "all"}, timeout=30.0)
            if body.get("ok") and body.get("removed"):
                removed.extend(body.get("removed", []))
        click.echo("deactivated {} device(s): {}".format(len(removed), ", ".join(removed)))
        return
    if scope_norm != "last":
        # 视为 target：host:name 或 name
        endpoints = _get_remote_endpoints(list(remotes))
        if not endpoints:
            endpoints = _discover_khala_servers()
        host_to_ep = _build_remote_host_to_endpoint(endpoints)
        host, name, endpoint = _resolve_target_to_endpoint(scope, reg, host_to_ep)
        if host is None:
            click.echo(f"未找到设备: {scope}", err=True)
            raise SystemExit(1)
        if endpoint:
            body = _remote_post(endpoint, "/deactivate", {"target": name}, timeout=30.0)
            if not body.get("ok"):
                click.echo(body.get("error", "未知错误"), err=True)
                raise SystemExit(1)
            click.echo("device {} deactivated".format(key(host, name)))
            return
        result = _do_deactivate_target(reg, host, name, verbose)
        if not result.get("ok"):
            click.echo(result.get("error", "未知错误"), err=True)
            raise SystemExit(1)
        click.echo("device {} deactivated".format(key(host, name)))
        return
    result = _do_deactivate_last(reg, verbose)
    if not result.get("ok"):
        click.echo(result.get("error", "无已激活设备"), err=True)
        raise SystemExit(1)
    click.echo("device {} deactivated".format(result.get("key", "")))


@main.command("reset")
@click.pass_context
def reset_cmd(ctx):
    """重置设备缓存（清空 registry 中所有设备与激活栈）。"""
    reg = ctx.obj["registry"]
    registry_clear(path=reg)
    click.echo("设备缓存已重置")


@main.command("verbose")
@click.argument("mode", required=False, type=click.Choice(["off"], case_sensitive=False))
def verbose_cmd(mode):
    """设置全局串口日志：默认开启；使用 `khala verbose off` 关闭。"""
    if mode and mode.lower() == "off":
        _set_verbose(False)
        click.echo("串口日志已关闭（后续 add/activate/deactivate 不显示串口输出）")
    else:
        _set_verbose(True)
        click.echo("串口日志已开启（后续 add/activate/deactivate 将显示串口输出）")


@main.command("daemon")
@click.option("--registry", "-r", "reg_path", default=DEFAULT_REGISTRY_PATH, help="Registry 路径")
@click.option("--host", "-H", default=None, help="仅管理该 Host 的设备（默认本机）")
@click.pass_context
def daemon_cmd(ctx, reg_path, host):
    """后台守护进程：为已登记的本机设备启动串口 Watchdog，持续运行直到 Ctrl+C。"""
    import signal
    h = host or _hostname()
    devices = [d for d in list_all(reg_path) if d.get("host") == h and d.get("port")]
    if not devices:
        click.echo(f"本机 ({h}) 无已登记串口设备，退出")
        return
    stop_ev = threading.Event()
    server = KhalaServer()
    verbose = _is_verbose()
    for d in devices:
        port = d["port"]
        name = d.get("name", port)
        baud = d.get("baudrate", 115200)
        try:
            dev = server.add(port, name, baud)
            _apply_serial_output(dev.board, verbose)
            dev.start_watchdog_thread(stop_event=stop_ev)
            click.echo(f"Watchdog started: {name} ({port})")
        except Exception as e:
            click.echo(f"跳过 {name} ({port}): {e}", err=True)
    if not server.device_list:
        click.echo("无可用设备，退出")
        return

    def on_signal(*_):
        stop_ev.set()

    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGTERM, on_signal)
    click.echo("Daemon running (Ctrl+C to stop)...")
    stop_ev.wait()


@main.command("serve")
@click.option("--registry", "-r", "reg_path", default=DEFAULT_REGISTRY_PATH, help="Registry 路径")
@click.option("--host", default="0.0.0.0", help="监听地址（默认 0.0.0.0）")
@click.option("--port", default=9412, show_default=True, type=int, help="HTTP 端口")
def serve_cmd(reg_path, host, port):
    """启动 HTTP 服务：GET /registry 供 list 聚合；POST /activate、/deactivate、/add 供跨机操作。"""
    verbose = _is_verbose()

    class RegistryHandler(http.server.BaseHTTPRequestHandler):
        def _read_json(self):  # type: ignore[no-untyped-def]
            length = int(self.headers.get("Content-Length", 0))
            if not length:
                return None
            raw = self.rfile.read(length)
            try:
                return json.loads(raw.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                return None

        def _send_json(self, status: int, body: dict) -> None:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):  # type: ignore[override]
            if self.path.rstrip("/") == "/registry":
                devices = list_all(reg_path)
                stack = get_active_stack(reg_path)
                payload = {"host": _hostname(), "devices": devices, "active_stack": stack}
                self._send_json(200, payload)
            else:
                self.send_response(404)
                self.end_headers()

        def do_POST(self):  # type: ignore[override]
            path = self.path.rstrip("/").split("?")[0]
            body = self._read_json() or {}
            if path == "/activate":
                target = body.get("target") or ""
                result = _do_activate(reg_path, target, verbose)
                self._send_json(200, result)
            elif path == "/deactivate":
                scope = body.get("scope")
                target = body.get("target")
                if target is not None:
                    parts = target.split(":", 1)
                    h, n = (parts[0], parts[1]) if len(parts) == 2 else (_hostname(), target)
                    result = _do_deactivate_target(reg_path, h, n, verbose)
                elif scope == "all":
                    result = _do_deactivate_all(reg_path, verbose)
                else:
                    result = _do_deactivate_last(reg_path, verbose)
                self._send_json(200, result)
            elif path == "/add":
                if body.get("mode") in ("all", "auto"):
                    result = _do_add_all(
                        reg_path,
                        body.get("baudrate", 115200),
                        body.get("name"),
                        body.get("verbose", False),
                    )
                else:
                    result = _do_add(
                        reg_path,
                        body.get("port", ""),
                        body.get("name", ""),
                        body.get("baudrate", 115200),
                        body.get("no_check", False),
                        body.get("verbose", False),
                    )
                self._send_json(200, result)
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, format, *args):  # type: ignore[override]
            return

    class ThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
        daemon_threads = True

    addr = (host, port)
    httpd = ThreadingHTTPServer(addr, RegistryHandler)
    zc, svc_info = None, None
    try:
        from zeroconf import Zeroconf, ServiceInfo
        local_ip = _get_local_ip()
        name = f"Khala @ {_hostname()}._khala._tcp.local."
        svc_info = ServiceInfo(
            _KHALA_SERVICE_TYPE,
            name,
            addresses=[socket.inet_aton(local_ip)],
            port=port,
            server=f"{_hostname()}.local.",
        )
        zc = Zeroconf()
        zc.register_service(svc_info)
        click.echo(f"khala serve listening on http://{host}:{port} (mDNS 已注册，局域网可自动发现)")
    except Exception as e:
        click.echo(f"khala serve listening on http://{host}:{port} (mDNS 未注册: {e})")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if zc and svc_info:
            try:
                zc.unregister_service(svc_info)
            except Exception:
                pass
            try:
                zc.close()
            except Exception:
                pass
        httpd.server_close()


if __name__ == "__main__":
    main()
