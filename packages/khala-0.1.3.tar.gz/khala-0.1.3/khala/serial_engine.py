# Serial Engine: Watchdog 监听、模式匹配、匹配到 login: 后注入脚本

import threading
from typing import Callable, Optional

from .identity import parse_serial_from_cpuinfo, provisioning_script
from .state_machine import DeviceState

# 关键字匹配（子串即可）
PATTERN_LOGIN = "login:"
PATTERN_UBOOT = "U-Boot"
PATTERN_PANIC = "Kernel Panic"
PATTERN_KERNEL_START = "Starting kernel"


def _default_on_login(device) -> None:
    """匹配到 login: 后的默认行为：取 cpuinfo -> set_identified -> 逐行注入 provisioning。"""
    board = device.board
    try:
        device.try_transition(DeviceState.Booting)
        out = board.shell("cat /proc/cpuinfo", timeout=10.0)
        if not isinstance(out, list):
            out = list(out)
        serial = parse_serial_from_cpuinfo(out)
        if not serial:
            return
        device.set_identified(serial)
        script = provisioning_script(device.mac)
        for line in script.strip().splitlines():
            board.send(line)
    except Exception:
        pass


def run_watchdog(
    device,
    *,
    on_login: Optional[Callable[[], None]] = None,
    scan_timeout: float = 0.3,
    stop_event: Optional[threading.Event] = None,
) -> None:
    """
    在当前线程中持续监听串口，匹配 U-Boot / Kernel Panic / Starting kernel / login:。
    匹配到 login: 时执行 on_login(device) 或默认逻辑（取 Serial、注入 provisioning）。
    若提供 stop_event，当其 set() 时退出循环。
    """
    board = device.board
    try:
        board.connect()
    except Exception:
        return
    try:
        device.try_transition(DeviceState.Booting)
    except Exception:
        pass

    callback = on_login or (lambda: _default_on_login(device))
    while True:
        if stop_event is not None and stop_event.is_set():
            break
        try:
            for line in board.scan(end_flag=None, timeout=scan_timeout):
                if stop_event is not None and stop_event.is_set():
                    return
                s = (line or "").strip()
                if PATTERN_PANIC in s:
                    device.try_transition(DeviceState.Panic)
                elif PATTERN_LOGIN in s:
                    callback()
        except TimeoutError:
            continue
        except Exception:
            if stop_event is not None and stop_event.is_set():
                break
            continue
