# Identity Module: Serial -> MAC, provisioning script generation.
# MAC: 02:50:4B + md5(Serial).hex()[0:6] (3 bytes as 6 hex chars)

import hashlib
import re
from typing import Optional

MAC_PREFIX = "02:50:4B"
MAC_PREFIX_BYTES = bytes.fromhex("02504b")  # 3 bytes
SERIAL_RE = re.compile(r"Serial\s*:\s*(.+)", re.IGNORECASE)


def serial_to_mac(serial: str) -> str:
    """根据 Serial 字符串生成确定性 MAC 地址：02:50:4B + md5(Serial).hex()[0:6]。"""
    if not serial or not serial.strip():
        raise ValueError("serial must be non-empty")
    raw = serial.strip()
    h = hashlib.md5(raw.encode("utf-8")).hexdigest()
    suffix = h[0:6]  # 3 bytes as 6 hex chars
    return f"{MAC_PREFIX}:{suffix[0:2]}:{suffix[2:4]}:{suffix[4:6]}"


def parse_serial_from_cpuinfo(lines: str | list[str]) -> Optional[str]:
    """从 cat /proc/cpuinfo 输出中解析 Serial 字段。"""
    if isinstance(lines, str):
        lines = lines.splitlines()
    for line in lines:
        m = SERIAL_RE.search(line)
        if m:
            return m.group(1).strip()
    return None


def provisioning_script(mac: str) -> str:
    """生成 Provisioning 脚本（由 sdev 注入执行）：设 MAC、起 DHCP、起 telnetd。"""
    return "\n".join([
        "ifconfig eth0 down",
        f"ifconfig eth0 hw ether {mac}",
        "ifconfig eth0 up",
        "udhcpc -i eth0 -n &",
        "/usr/sbin/telnetd -p 23 -l /bin/sh",
        "",
    ])
