# KhalaDevice / KhalaServer

import threading
import sdev

from .identity import serial_to_mac, parse_serial_from_cpuinfo, provisioning_script
from .state_machine import DeviceState, transition, can_transition

try:
    from .serial_engine import run_watchdog
except ImportError:
    run_watchdog = None


class KhalaDevice:
    """单设备封装：持有 sdev.Demoboard、状态机与 Identity 相关字段。"""

    def __init__(self, port: str, name: str, baudrate: int = 115200):
        self.port = port
        self.name = name
        self.baudrate = baudrate
        self._board = sdev.Demoboard(port, baudrate, check_alive=False)
        self._state = DeviceState.Added
        self.serial: str | None = None
        self.mac: str | None = None
        self.ip: str | None = None

    @property
    def state(self) -> DeviceState:
        return self._state

    @property
    def board(self) -> sdev.Demoboard:
        return self._board

    def try_transition(self, next_state: DeviceState) -> bool:
        """尝试转移到 next_state，成功返回 True。"""
        new_state = transition(
            self._state,
            next_state,
            on_invalid=lambda c, n: None,
        )
        if new_state == next_state:
            self._state = new_state
            return True
        return False

    def set_identified(self, serial: str) -> None:
        """在识别到 Serial 后调用：更新 serial/mac 并进入 Identified。"""
        self.serial = serial.strip()
        self.mac = serial_to_mac(self.serial)
        self.try_transition(DeviceState.Identified)

    def set_active(self, ip: str) -> None:
        """激活完成、拿到 IP 后调用。"""
        self.ip = ip
        self.try_transition(DeviceState.Active)

    def get_provisioning_script(self) -> str:
        """返回当前 MAC 的 provisioning 脚本（需已 Identified）。"""
        if not self.mac:
            raise RuntimeError("device not identified, no MAC")
        return provisioning_script(self.mac)

    def start_watchdog_thread(
        self,
        *,
        on_login=None,
        stop_event: threading.Event | None = None,
    ) -> threading.Thread:
        """在后台线程启动 Serial Engine Watchdog；返回该线程。需 run_watchdog 可用。"""
        if run_watchdog is None:
            raise RuntimeError("serial_engine not available")
        ev = stop_event or threading.Event()
        t = threading.Thread(
            target=run_watchdog,
            args=(self,),
            kwargs={"on_login": on_login, "stop_event": ev},
            daemon=True,
        )
        t.start()
        return t


class KhalaServer:
    def __init__(self):
        self.device_list: list[KhalaDevice] = []

    def add(self, port: str, name: str, baudrate: int = 115200) -> KhalaDevice:
        device = KhalaDevice(port, name, baudrate)
        self.device_list.append(device)
        return device
