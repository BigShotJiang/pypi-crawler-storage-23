# type: ignore
"""This module is dead code - never imported."""


def unused_function():
    pass
