"""Main agent functionality -- tinyagent event-stream orchestrator."""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, cast

from tinyagent import Agent

from tunacode.constants import DEFAULT_CONTEXT_WINDOW
from tunacode.exceptions import (
    AgentError,
    ContextOverflowError,
    GlobalRequestTimeoutError,
    UserAbortError,
)
from tunacode.types import (
    ModelName,
    NoticeCallback,
    StreamingCallback,
    ToolCallback,
    ToolResultCallback,
    ToolStartCallback,
    UsageMetrics,
)
from tunacode.utils.messaging import estimate_messages_tokens

from tunacode.core.compaction.controller import (
    CompactionStatusCallback,
    apply_compaction_messages,
    build_compaction_notice,
    get_or_create_compaction_controller,
)
from tunacode.core.compaction.types import CompactionOutcome
from tunacode.core.debug import log_usage_update
from tunacode.core.logging import get_logger
from tunacode.core.types import RuntimeState, StateManagerProtocol

from . import agent_components as ac
from .helpers import (
    CONTEXT_OVERFLOW_FAILURE_NOTICE,
    CONTEXT_OVERFLOW_RETRY_NOTICE,
    coerce_error_text,
    coerce_tinyagent_history,
    extract_assistant_text,
    extract_tool_result_text,
    is_context_overflow_error,
    parse_canonical_usage,
)

__all__ = ["process_request", "get_agent_tool"]
DEFAULT_MAX_ITERATIONS: int = 15
REQUEST_ID_LENGTH: int = 8
MILLISECONDS_PER_SECOND: int = 1000
TOOL_EXECUTION_LIFECYCLE_PREFIX: str = "Tool execution"
PARALLEL_TOOL_CALLS_LIFECYCLE_PREFIX: str = "Parallel tool calls"
DURATION_NOT_AVAILABLE_LABEL: str = "n/a"


@dataclass
class AgentConfig:
    max_iterations: int = DEFAULT_MAX_ITERATIONS
    debug_metrics: bool = False


@dataclass(slots=True)
class RequestContext:
    request_id: str
    max_iterations: int
    debug_metrics: bool


@dataclass(slots=True)
class _TinyAgentStreamState:
    runtime: RuntimeState
    tool_start_times: dict[str, float]
    active_tool_call_ids: set[str]
    batch_tool_call_ids: set[str]
    last_assistant_message: dict[str, Any] | None = None


class EmptyResponseHandler:
    """Handles tracking and intervention for empty responses."""

    def __init__(
        self,
        state_manager: StateManagerProtocol,
        notice_callback: NoticeCallback | None,
    ) -> None:
        self.state_manager = state_manager
        self.notice_callback = notice_callback

    def track(self, is_empty: bool) -> None:
        runtime = self.state_manager.session.runtime
        if is_empty:
            runtime.consecutive_empty_responses += 1
            return
        runtime.consecutive_empty_responses = 0

    def should_intervene(self) -> bool:
        runtime = self.state_manager.session.runtime
        return runtime.consecutive_empty_responses >= 1

    async def prompt_action(self, message: str, reason: str, iteration: int) -> None:
        logger = get_logger()
        logger.warning(f"Empty response: {reason}", iteration=iteration)
        show_thoughts = bool(getattr(self.state_manager.session, "show_thoughts", False))

        @dataclass
        class StateView:
            sm: StateManagerProtocol
            show_thoughts: bool

        state_view = StateView(sm=self.state_manager, show_thoughts=show_thoughts)
        notice = await ac.handle_empty_response(message, reason, iteration, state_view)
        if self.notice_callback:
            self.notice_callback(notice)
        self.state_manager.session.runtime.consecutive_empty_responses = 0


class RequestOrchestrator:
    """Orchestrates the request processing loop using tinyagent events."""

    def __init__(
        self,
        message: str,
        model: ModelName,
        state_manager: StateManagerProtocol,
        tool_callback: ToolCallback | None,
        streaming_callback: StreamingCallback | None,
        thinking_callback: StreamingCallback | None = None,
        tool_result_callback: ToolResultCallback | None = None,
        tool_start_callback: ToolStartCallback | None = None,
        notice_callback: NoticeCallback | None = None,
        compaction_status_callback: CompactionStatusCallback | None = None,
    ) -> None:
        self.message = message
        self.model = model
        self.state_manager = state_manager
        self.tool_callback = tool_callback
        self.streaming_callback = streaming_callback
        self.thinking_callback = thinking_callback
        self.tool_result_callback = tool_result_callback
        self.tool_start_callback = tool_start_callback
        self.notice_callback = notice_callback
        self.compaction_status_callback = compaction_status_callback
        self.compaction_controller = get_or_create_compaction_controller(state_manager)
        user_config = getattr(state_manager.session, "user_config", {}) or {}
        settings = user_config.get("settings", {})
        self.config = AgentConfig(
            max_iterations=int(settings.get("max_iterations", DEFAULT_MAX_ITERATIONS)),
            debug_metrics=bool(settings.get("debug_metrics", False)),
        )
        self.empty_handler = EmptyResponseHandler(state_manager, notice_callback)

    async def run(self) -> Agent:
        from tunacode.core.agents.agent_components.agent_config import (
            _coerce_global_request_timeout,
        )

        timeout = _coerce_global_request_timeout(self.state_manager.session)
        if timeout is None:
            return await self._run_impl()
        try:
            return await asyncio.wait_for(self._run_impl(), timeout=timeout)
        except TimeoutError as e:
            logger = get_logger()
            invalidated = ac.invalidate_agent_cache(self.model, self.state_manager)
            if invalidated:
                logger.lifecycle("Agent cache invalidated after timeout")
            raise GlobalRequestTimeoutError(timeout) from e

    async def _run_impl(self) -> Agent:
        ctx = self._initialize_request()
        logger = get_logger()
        logger.info("Request started", request_id=ctx.request_id)
        agent = ac.get_or_create_agent(self.model, self.state_manager)
        session = self.state_manager.session
        conversation = session.conversation
        history = coerce_tinyagent_history(conversation.messages)
        self._configure_compaction_callbacks()
        compacted_history = await self._compact_history_for_request(history)
        baseline_message_count = len(conversation.messages)
        pre_request_history = list(conversation.messages)
        agent.replace_messages(compacted_history)
        session._debug_raw_stream_accum = ""
        try:
            await self._run_stream(
                agent=agent,
                request_context=ctx,
                baseline_message_count=baseline_message_count,
            )
            await self._retry_after_context_overflow_if_needed(
                agent=agent,
                request_context=ctx,
                pre_request_history=pre_request_history,
            )
            return agent
        except UserAbortError:
            self._handle_abort_cleanup(logger, invalidate_cache=False)
            raise
        except asyncio.CancelledError:
            # ESC cancellation should preserve agent cache
            self._handle_abort_cleanup(logger, invalidate_cache=False)
            raise

    def _initialize_request(self) -> RequestContext:
        ctx = self._create_request_context()
        self._reset_session_state()
        self._set_original_query_once()
        return ctx

    def _create_request_context(self) -> RequestContext:
        req_id = str(uuid.uuid4())[:REQUEST_ID_LENGTH]
        self.state_manager.session.runtime.request_id = req_id
        return RequestContext(
            request_id=req_id,
            max_iterations=self.config.max_iterations,
            debug_metrics=self.config.debug_metrics,
        )

    def _reset_session_state(self) -> None:
        session = self.state_manager.session
        runtime = session.runtime
        runtime.current_iteration = 0
        runtime.iteration_count = 0
        runtime.tool_registry.clear()
        runtime.batch_counter = 0
        runtime.consecutive_empty_responses = 0
        session.task.original_query = ""
        session.usage.last_call_usage = UsageMetrics()

    def _set_original_query_once(self) -> None:
        task_state = self.state_manager.session.task
        if task_state.original_query:
            return
        task_state.original_query = self.message

    def _configure_compaction_callbacks(self) -> None:
        self.compaction_controller.set_status_callback(self.compaction_status_callback)

    def _maybe_emit_compaction_notice(self, outcome: CompactionOutcome) -> None:
        if self.notice_callback is None:
            return
        notice = build_compaction_notice(outcome)
        if notice is None:
            return
        self.notice_callback(notice)

    async def _compact_history_for_request(
        self,
        history: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        self.compaction_controller.reset_request_state()
        max_tokens = self.state_manager.session.conversation.max_tokens
        compaction_outcome = await self.compaction_controller.check_and_compact(
            history,
            max_tokens=max_tokens,
            signal=None,
            allow_threshold=True,
        )
        self._maybe_emit_compaction_notice(compaction_outcome)
        applied_messages = apply_compaction_messages(
            self.state_manager,
            compaction_outcome.messages,
        )
        return [cast(dict[str, Any], message) for message in applied_messages]

    async def _force_compact_history(
        self,
        history: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        max_tokens = self.state_manager.session.conversation.max_tokens
        compaction_outcome = await self.compaction_controller.force_compact(
            history,
            max_tokens=max_tokens,
            signal=None,
        )
        self._maybe_emit_compaction_notice(compaction_outcome)
        applied_messages = apply_compaction_messages(
            self.state_manager,
            compaction_outcome.messages,
        )
        return [cast(dict[str, Any], message) for message in applied_messages]

    async def _retry_after_context_overflow_if_needed(
        self,
        *,
        agent: Agent,
        request_context: RequestContext,
        pre_request_history: list[dict[str, Any]],
    ) -> None:
        error_text = self._agent_error_text(agent)
        if not is_context_overflow_error(error_text):
            return
        if self.notice_callback is not None:
            self.notice_callback(CONTEXT_OVERFLOW_RETRY_NOTICE)
        logger = get_logger()
        logger.warning("Context overflow detected; forcing compaction and retrying")
        conversation = self.state_manager.session.conversation
        apply_compaction_messages(self.state_manager, pre_request_history)
        forced_history = await self._force_compact_history(pre_request_history)
        agent.replace_messages(forced_history)
        self.state_manager.session._debug_raw_stream_accum = ""
        retry_baseline = len(conversation.messages)
        await self._run_stream(
            agent=agent,
            request_context=request_context,
            baseline_message_count=retry_baseline,
        )
        retry_error_text = self._agent_error_text(agent)
        if not is_context_overflow_error(retry_error_text):
            return
        if self.notice_callback is not None:
            self.notice_callback(CONTEXT_OVERFLOW_FAILURE_NOTICE)
        estimated_tokens = estimate_messages_tokens(conversation.messages)
        max_tokens = conversation.max_tokens or DEFAULT_CONTEXT_WINDOW
        raise ContextOverflowError(
            estimated_tokens=estimated_tokens,
            max_tokens=max_tokens,
            model=self.model,
        )

    def _agent_error_text(self, agent: Agent) -> str:
        return coerce_error_text(agent.state.get("error"))

    def _normalize_tool_event_args(
        self,
        raw_args: object,
        *,
        event_name: str,
        tool_call_id: str,
    ) -> dict[str, Any]:
        if raw_args is None:
            return {}

        if isinstance(raw_args, dict):
            return cast(dict[str, Any], raw_args)

        if isinstance(raw_args, str):
            stripped_args = raw_args.strip()
            if not stripped_args:
                return {}
            try:
                parsed_args = json.loads(stripped_args)
            except json.JSONDecodeError as exc:
                raise TypeError(
                    f"{event_name} args must be a JSON object for tool_call_id='{tool_call_id}'"
                ) from exc
            if isinstance(parsed_args, dict):
                return cast(dict[str, Any], parsed_args)
            raise TypeError(
                f"{event_name} args must decode to an object for tool_call_id='{tool_call_id}', "
                f"got {type(parsed_args).__name__}"
            )

        raise TypeError(
            f"{event_name} args must be a dict or JSON string for tool_call_id='{tool_call_id}', "
            f"got {type(raw_args).__name__}"
        )

    def _mark_tool_start_batch_state(
        self,
        state: _TinyAgentStreamState,
        *,
        tool_call_id: str,
    ) -> None:
        active_tool_call_ids = state.active_tool_call_ids
        if active_tool_call_ids:
            state.batch_tool_call_ids.update(active_tool_call_ids)
            state.batch_tool_call_ids.add(tool_call_id)
        active_tool_call_ids.add(tool_call_id)

    def _clear_tool_batch_state_if_idle(self, state: _TinyAgentStreamState) -> None:
        if state.active_tool_call_ids:
            return
        state.batch_tool_call_ids.clear()

    def _format_duration_ms(self, duration_ms: float | None) -> str:
        if duration_ms is None:
            return DURATION_NOT_AVAILABLE_LABEL
        return f"{duration_ms:.1f}"

    def _log_tool_execution_start_lifecycle(
        self,
        *,
        state: _TinyAgentStreamState,
        tool_call_id: str,
        tool_name: str,
    ) -> None:
        logger = get_logger()
        in_flight = len(state.active_tool_call_ids)
        logger.lifecycle(
            f"{TOOL_EXECUTION_LIFECYCLE_PREFIX} start: "
            f"name={tool_name} tool_call_id={tool_call_id} in_flight={in_flight}"
        )
        if in_flight <= 1:
            return
        batch_size = len(state.batch_tool_call_ids)
        logger.lifecycle(
            f"{PARALLEL_TOOL_CALLS_LIFECYCLE_PREFIX} active: "
            f"in_flight={in_flight} batch_size={batch_size}"
        )

    def _log_tool_execution_end_lifecycle(
        self,
        *,
        state: _TinyAgentStreamState,
        tool_call_id: str,
        tool_name: str,
        status: str,
        duration_ms: float | None,
        was_parallel_batch_member: bool,
    ) -> None:
        logger = get_logger()
        in_flight = len(state.active_tool_call_ids)
        duration_text = self._format_duration_ms(duration_ms)
        logger.lifecycle(
            f"{TOOL_EXECUTION_LIFECYCLE_PREFIX} end: "
            f"name={tool_name} tool_call_id={tool_call_id} status={status} "
            f"in_flight={in_flight} duration_ms={duration_text}"
        )
        if not was_parallel_batch_member:
            return
        batch_size = len(state.batch_tool_call_ids)
        logger.lifecycle(
            f"{PARALLEL_TOOL_CALLS_LIFECYCLE_PREFIX} update: "
            f"in_flight={in_flight} batch_size={batch_size}"
        )
        if in_flight != 0:
            return
        logger.lifecycle(f"{PARALLEL_TOOL_CALLS_LIFECYCLE_PREFIX} complete")

    def _resolve_tool_duration_ms(
        self,
        state: _TinyAgentStreamState,
        *,
        tool_call_id: str,
    ) -> float | None:
        start_time = state.tool_start_times.pop(tool_call_id, None)
        if start_time is None:
            return None

        if tool_call_id in state.batch_tool_call_ids:
            # tinyagent emits end events only after all tools in the batch finish.
            # Start->end deltas in this mode represent batch latency, not per-tool latency.
            return None

        elapsed_seconds = time.perf_counter() - start_time
        return elapsed_seconds * MILLISECONDS_PER_SECOND

    def _persist_agent_messages(self, agent: Any, baseline_message_count: int) -> None:
        session = self.state_manager.session
        conversation = session.conversation
        # Preserve anything that might have been appended externally during the run.
        external_messages = list(conversation.messages[baseline_message_count:])
        agent_messages = agent.state.get("messages", [])
        if not isinstance(agent_messages, list):
            raise TypeError("tinyagent Agent.state['messages'] must be a list")
        conversation.messages = [*agent_messages, *external_messages]

    async def _handle_stream_turn_end(
        self,
        event_obj: object,
        *,
        agent: Any,
        state: _TinyAgentStreamState,
        request_context: RequestContext,
        baseline_message_count: int,
    ) -> bool:
        _ = baseline_message_count
        state.runtime.iteration_count += 1
        state.runtime.current_iteration = state.runtime.iteration_count
        if state.runtime.iteration_count <= request_context.max_iterations:
            return False
        agent.abort()
        raise RuntimeError(f"Max iterations exceeded ({request_context.max_iterations}); aborted")

    async def _handle_stream_message_update(
        self,
        event_obj: object,
        *,
        agent: Any,
        state: _TinyAgentStreamState,
        request_context: RequestContext,
        baseline_message_count: int,
    ) -> bool:
        _ = (agent, state, request_context, baseline_message_count)
        await self._handle_message_update(event_obj)
        return False

    async def _handle_stream_message_end(
        self,
        event_obj: object,
        *,
        agent: Any,
        state: _TinyAgentStreamState,
        request_context: RequestContext,
        baseline_message_count: int,
    ) -> bool:
        _ = (agent, request_context, baseline_message_count)
        msg = getattr(event_obj, "message", None)
        if not isinstance(msg, dict):
            return False
        if msg.get("role") != "assistant":
            return False
        state.last_assistant_message = cast(dict[str, Any], msg)
        usage = parse_canonical_usage(msg.get("usage"))
        session = self.state_manager.session
        session.usage.last_call_usage = usage
        session.usage.session_total_usage.add(usage)
        logger = get_logger()
        log_usage_update(
            logger=logger,
            request_id=request_context.request_id,
            event_name="message_end",
            last_call_usage=session.usage.last_call_usage,
            session_total_usage=session.usage.session_total_usage,
        )
        return False

    async def _handle_stream_tool_execution_start(
        self,
        event_obj: object,
        *,
        agent: Any,
        state: _TinyAgentStreamState,
        request_context: RequestContext,
        baseline_message_count: int,
    ) -> bool:
        _ = (agent, request_context, baseline_message_count)
        tool_call_id = cast(str, getattr(event_obj, "tool_call_id", ""))
        tool_name = cast(str, getattr(event_obj, "tool_name", ""))
        raw_args = getattr(event_obj, "args", None)
        args = self._normalize_tool_event_args(
            raw_args,
            event_name="tool_execution_start",
            tool_call_id=tool_call_id,
        )
        state.tool_start_times[tool_call_id] = time.perf_counter()
        self._mark_tool_start_batch_state(state, tool_call_id=tool_call_id)
        state.runtime.tool_registry.register(tool_call_id, tool_name, args)
        state.runtime.tool_registry.start(tool_call_id)
        self._log_tool_execution_start_lifecycle(
            state=state,
            tool_call_id=tool_call_id,
            tool_name=tool_name,
        )
        if self.tool_start_callback is not None:
            self.tool_start_callback(tool_name)
        return False

    async def _handle_stream_tool_execution_end(
        self,
        event_obj: object,
        *,
        agent: Any,
        state: _TinyAgentStreamState,
        request_context: RequestContext,
        baseline_message_count: int,
    ) -> bool:
        _ = (agent, request_context, baseline_message_count)
        tool_call_id = cast(str, getattr(event_obj, "tool_call_id", ""))
        tool_name = cast(str, getattr(event_obj, "tool_name", ""))
        is_error = bool(getattr(event_obj, "is_error", False))
        result = getattr(event_obj, "result", None)
        duration_ms = self._resolve_tool_duration_ms(state, tool_call_id=tool_call_id)
        result_text = extract_tool_result_text(result)
        status = "failed" if is_error else "completed"
        was_parallel_batch_member = tool_call_id in state.batch_tool_call_ids
        if is_error:
            state.runtime.tool_registry.fail(tool_call_id, error=result_text)
        else:
            state.runtime.tool_registry.complete(tool_call_id, result=result_text)
        state.active_tool_call_ids.discard(tool_call_id)
        self._clear_tool_batch_state_if_idle(state)
        self._log_tool_execution_end_lifecycle(
            state=state,
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            status=status,
            duration_ms=duration_ms,
            was_parallel_batch_member=was_parallel_batch_member,
        )
        if self.tool_result_callback is None:
            return False
        args = state.runtime.tool_registry.get_args(tool_call_id) or {}
        self.tool_result_callback(
            tool_name,
            status,
            cast(dict[str, Any], args),
            result_text,
            duration_ms,
        )
        return False

    async def _handle_stream_agent_end(
        self,
        event_obj: object,
        *,
        agent: Any,
        state: _TinyAgentStreamState,
        request_context: RequestContext,
        baseline_message_count: int,
    ) -> bool:
        _ = (event_obj, state, request_context)
        self._persist_agent_messages(agent, baseline_message_count)
        return True

    async def _run_stream(
        self,
        *,
        agent: Any,
        request_context: RequestContext,
        baseline_message_count: int,
    ) -> Agent:
        logger = get_logger()
        runtime = self.state_manager.session.runtime
        state = _TinyAgentStreamState(
            runtime=runtime,
            tool_start_times={},
            active_tool_call_ids=set(),
            batch_tool_call_ids=set(),
        )
        handlers: dict[str, Callable[..., Awaitable[bool]]] = {
            "turn_end": self._handle_stream_turn_end,
            "message_update": self._handle_stream_message_update,
            "message_end": self._handle_stream_message_end,
            "tool_execution_start": self._handle_stream_tool_execution_start,
            "tool_execution_end": self._handle_stream_tool_execution_end,
            "agent_end": self._handle_stream_agent_end,
        }
        started_at = time.perf_counter()
        async for event in agent.stream(self.message):
            ev_type = getattr(event, "type", None)
            if not isinstance(ev_type, str):
                continue
            handler = handlers.get(ev_type)
            if handler is None:
                continue
            should_stop = await handler(
                event,
                agent=agent,
                state=state,
                request_context=request_context,
                baseline_message_count=baseline_message_count,
            )
            if should_stop:
                break
        elapsed_ms = (time.perf_counter() - started_at) * MILLISECONDS_PER_SECOND
        logger.lifecycle(f"Request complete ({elapsed_ms:.0f}ms)")

        error_text = self._agent_error_text(agent)
        if error_text and not is_context_overflow_error(error_text):
            raise AgentError(error_text)

        assistant_text = extract_assistant_text(state.last_assistant_message)
        is_empty = not assistant_text.strip()
        self.empty_handler.track(is_empty)
        if is_empty and self.empty_handler.should_intervene():
            await self.empty_handler.prompt_action(
                self.message,
                "empty",
                runtime.iteration_count or 1,
            )
        return agent

    async def _handle_message_update(self, event: Any) -> None:
        assistant_event = getattr(event, "assistant_message_event", None)
        if not isinstance(assistant_event, dict):
            return

        event_type = assistant_event.get("type")
        delta = assistant_event.get("delta")
        if not isinstance(delta, str) or not delta:
            return

        if event_type == "text_delta":
            # Keep legacy debug accumulator for abort handling.
            session = self.state_manager.session
            session._debug_raw_stream_accum += delta
            if self.streaming_callback is None:
                return
            # Streaming callback is a UI hook; keep it best-effort.
            await self.streaming_callback(delta)
            return

        if event_type == "thinking_delta":
            if self.thinking_callback is None:
                return
            await self.thinking_callback(delta)
            return

    def _handle_abort_cleanup(self, logger: Any, *, invalidate_cache: bool = False) -> None:
        session = self.state_manager.session
        conversation = session.conversation
        partial_text = session._debug_raw_stream_accum
        if partial_text.strip():
            interrupted_text = f"[INTERRUPTED]\n\n{partial_text}"
            conversation.messages.append(
                {
                    "role": "assistant",
                    "stop_reason": "aborted",
                    "content": [{"type": "text", "text": interrupted_text}],
                    "timestamp": int(time.time() * 1000),
                }
            )
        if invalidate_cache:
            invalidated = ac.invalidate_agent_cache(self.model, self.state_manager)
            if invalidated:
                logger.lifecycle("Agent cache invalidated after abort")


def get_agent_tool() -> tuple[type[Any], type[Any]]:
    """Return the (Agent, AgentTool) classes."""
    from tinyagent import Agent as AgentCls
    from tinyagent.agent_types import AgentTool as ToolCls

    return AgentCls, ToolCls


async def process_request(
    message: str,
    model: ModelName,
    state_manager: StateManagerProtocol,
    tool_callback: ToolCallback | None = None,
    streaming_callback: StreamingCallback | None = None,
    thinking_callback: StreamingCallback | None = None,
    tool_result_callback: ToolResultCallback | None = None,
    tool_start_callback: ToolStartCallback | None = None,
    notice_callback: NoticeCallback | None = None,
    compaction_status_callback: CompactionStatusCallback | None = None,
) -> Agent:
    orchestrator = RequestOrchestrator(
        message,
        model,
        state_manager,
        tool_callback,
        streaming_callback,
        thinking_callback,
        tool_result_callback,
        tool_start_callback,
        notice_callback,
        compaction_status_callback,
    )
    return await orchestrator.run()
