import {
  File,
  FileText,
  FileSpreadsheet,
  Image as ImageIcon,
  Video,
  Music,
  Presentation,
  type LucideIcon,
} from "lucide-react";

export type FileCategory = "text" | "image" | "video" | "audio" | "pdf" | "office" | "binary";

const IMAGE_EXTS = new Set([".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".bmp", ".ico"]);
const VIDEO_EXTS = new Set([".mp4", ".mov", ".webm", ".avi", ".mkv", ".m4v"]);
const AUDIO_EXTS = new Set([".mp3", ".m4a", ".wav", ".ogg", ".flac", ".aac", ".wma"]);
const PDF_EXTS = new Set([".pdf"]);
const OFFICE_EXTS = new Set([".xlsx", ".xls", ".docx", ".doc", ".pptx", ".ppt"]);

function getExt(path: string): string {
  const dot = path.lastIndexOf(".");
  return dot >= 0 ? path.slice(dot).toLowerCase() : "";
}

export function getFileCategory(path: string): FileCategory {
  const ext = getExt(path);
  if (IMAGE_EXTS.has(ext)) return "image";
  if (VIDEO_EXTS.has(ext)) return "video";
  if (AUDIO_EXTS.has(ext)) return "audio";
  if (PDF_EXTS.has(ext)) return "pdf";
  if (OFFICE_EXTS.has(ext)) return "office";
  return "text";
}

const ICON_MAP: Record<FileCategory, LucideIcon> = {
  text: File,
  image: ImageIcon,
  video: Video,
  audio: Music,
  pdf: FileText,
  office: FileSpreadsheet,
  binary: File,
};

const OFFICE_ICON_MAP: Record<string, LucideIcon> = {
  ".pptx": Presentation,
  ".ppt": Presentation,
  ".docx": FileText,
  ".doc": FileText,
};

export function getFileCategoryIcon(path: string): LucideIcon {
  const ext = getExt(path);
  const category = getFileCategory(path);
  if (category === "office") {
    return OFFICE_ICON_MAP[ext] ?? FileSpreadsheet;
  }
  return ICON_MAP[category];
}
