from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Optional, Any, Tuple, List

import asyncio
import logging
import os
import random
import sqlite3
import time
import traceback

import yt_dlp

DEFAULT_RES_LABEL = {
    "1080x1920": "FHD (1080p)",
    "1440x2560": "2K",
    "2160x3840": "4K",
}


@dataclass
class AutoReupConfig:
    db_path: str
    output_dir: str
    owner_id: int
    default_hashtag: str
    min_valid_video_size: int = 200_000
    render_res: str = "1080x1920"
    render_fps: int = 60
    res_label: Dict[str, str] = field(default_factory=lambda: dict(DEFAULT_RES_LABEL))
    auto_monitor_interval: int = 30 * 60


@dataclass
class AutoReupDeps:
    load_user_data: Callable[[int], Dict[str, Any]]
    account_cookie_path: Callable[[int, str], str]
    download_video: Callable[[str, str, Any], Optional[str]]
    render_video: Callable[[str, str, Any, Any], Any]
    upload_video: Callable[[str, str, Any, int, str, Any], Any]
    generate_caption: Callable[[str, str, str, Optional[str]], str]
    animated_progress: Optional[Callable[[int], str]] = None


class AutoReupService:
    def __init__(self, config: AutoReupConfig, deps: AutoReupDeps, logger: Optional[logging.Logger] = None):
        self.config = config
        self.deps = deps
        self.log = logger or logging.getLogger("tiktok_autoreup_core")
        self._auto_monitor_task = None
        self._auto_monitor_running = False
        self._auto_monitor_interval = config.auto_monitor_interval
        self._auto_monitor_next_ts = None

    # ===== DB helpers =====
    def _connect(self):
        return sqlite3.connect(self.config.db_path)

    def init_db(self):
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS videos (
                video_id   TEXT PRIMARY KEY,
                url        TEXT,
                author     TEXT,
                title      TEXT,
                source     TEXT,
                created_at TEXT
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS channels (
                username       TEXT PRIMARY KEY,
                last_timestamp INTEGER DEFAULT 0
            )
        """)
        conn.commit()
        conn.close()

    def auto_video_already_processed(self, video_id: str) -> bool:
        if not video_id:
            return False
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM videos WHERE video_id = ?", (video_id,))
        row = cur.fetchone()
        conn.close()
        return row is not None

    def mark_auto_video_processed(self, video_id: str, url: str, author: str, title: str, source: str = "manual"):
        if not video_id:
            return
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("""
            INSERT OR IGNORE INTO videos (video_id, url, author, title, source, created_at)
            VALUES (?, ?, ?, ?, ?, datetime('now'))
        """, (video_id, url or "", author or "", title or "", source or "manual"))
        conn.commit()
        conn.close()

    def get_monitored_channels(self):
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("SELECT username, last_timestamp FROM channels ORDER BY username")
        rows = cur.fetchall()
        conn.close()
        return rows

    def add_monitored_channel(self, username: str):
        username = username.strip().lstrip("@")
        if not username:
            return False
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("""
            INSERT OR IGNORE INTO channels (username, last_timestamp)
            VALUES (?, 0)
        """, (username,))
        conn.commit()
        conn.close()
        return True

    def remove_monitored_channel(self, username: str):
        username = username.strip().lstrip("@")
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("DELETE FROM channels WHERE username = ?", (username,))
        deleted = cur.rowcount
        conn.commit()
        conn.close()
        return deleted > 0

    def get_channel_last_ts(self, username: str) -> int:
        username = username.strip().lstrip("@")
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("SELECT last_timestamp FROM channels WHERE username = ?", (username,))
        row = cur.fetchone()
        conn.close()
        return int(row[0]) if row and row[0] is not None else 0

    def set_channel_last_ts(self, username: str, ts: int):
        username = username.strip().lstrip("@")
        conn = self._connect()
        cur = conn.cursor()
        cur.execute("UPDATE channels SET last_timestamp = ? WHERE username = ?", (int(ts), username))
        conn.commit()
        conn.close()

    def get_auto_reup_stats(self) -> Tuple[int, int]:
        total = 0
        auto = 0
        try:
            conn = self._connect()
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM videos")
            row = cur.fetchone()
            if row and row[0] is not None:
                total = int(row[0])

            cur.execute("SELECT COUNT(*) FROM videos WHERE source = 'auto'")
            row = cur.fetchone()
            if row and row[0] is not None:
                auto = int(row[0])
            conn.close()
        except Exception as e:
            print("Lỗi get_auto_reup_stats:", e)
        return total, auto

    # ===== helpers =====
    @staticmethod
    def clean_filename(name: str, max_length: int = 80):
        import re
        name = re.sub(r'[\/\\\:\*\?"<>\|]', '', name)
        name = name.replace('\n', ' ').replace('\r', '')
        name = name.strip()
        if len(name) > max_length:
            name = name[:max_length].rstrip()
        return name

    def _animated_progress(self, percent: int) -> str:
        if self.deps.animated_progress:
            return self.deps.animated_progress(percent)
        block_full = "▓"
        block_empty = "░"
        block_count = 10
        filled = int(percent / 100 * block_count)
        bar = block_full * filled + block_empty * (block_count - filled)
        return f"<b>{bar} {percent:>3d}%</b>"

    # ===== fetch latest videos =====
    def fetch_user_latest_videos(self, username: str, max_videos: int = 5) -> List[Dict[str, Any]]:
        username = username.strip().lstrip("@")
        url = f"https://www.tiktok.com/@{username}"
        self.log.debug("fetch_user_latest_videos: start username=%s max=%s", username, max_videos)
        ydl_opts = {
            "quiet": True,
            "extract_flat": False,
            "playlistend": max_videos,
            "geo_bypass": True,
            "geo_bypass_country": "US",
            "http_headers": {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            },
            "skip_download": True,
            "socket_timeout": 30,
            "retries": 3,
        }
        videos: List[Dict[str, Any]] = []
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                if "entries" not in info:
                    self.log.warning("fetch_user_latest_videos: no entries username=%s", username)
                    return []
                for e in info["entries"]:
                    if not e:
                        continue

                    duration = e.get("duration") or 0
                    ext = (e.get("ext") or "").lower()
                    vcodec = (e.get("vcodec") or "").lower()
                    if vcodec == "none" or (duration == 0 and ext not in ("mp4", "mov", "mkv", "webm")):
                        continue

                    # ưu tiên description làm tiêu đề
                    desc = (
                        e.get("description")
                        or e.get("full_description")
                        or e.get("title")
                        or ""
                    )

                    videos.append({
                        "id": e.get("id", ""),
                        "url": e.get("webpage_url", ""),
                        "title": desc,
                        "caption": desc,
                        "timestamp": e.get("timestamp", 0),
                        "author": e.get("uploader", username),
                    })
        except Exception:
            self.log.exception("fetch_user_latest_videos: error username=%s", username)
            return []
        videos.sort(key=lambda x: x.get("timestamp") or 0, reverse=True)
        self.log.info("fetch_user_latest_videos: found=%s username=%s", len(videos), username)
        return videos

    # ===== auto reup =====
    async def auto_reup_from_tiktok(self, app, username: str, video_meta: Dict[str, Any]):
        bot = app.bot
        chat_id = self.config.owner_id
        user_id = self.config.owner_id

        user_settings = self.deps.load_user_data(user_id)
        acc = user_settings.get("current_acc")
        if not acc:
            await bot.send_message(chat_id, "❗ Auto-reup: chưa chọn acc TikTok (/accounts). Bỏ qua.")
            self.log.warning("auto_reup: no current acc, skip username=%s", username)
            return False

        cookie_path = self.deps.account_cookie_path(user_id, acc)
        if not os.path.exists(cookie_path):
            await bot.send_message(chat_id, f"❗ Auto-reup: acc {acc} chưa login hoặc mất cookies. Bỏ qua.")
            self.log.warning("auto_reup: missing cookies acc=%s", acc)
            return False

        default_hashtag = user_settings.get("hashtag", self.config.default_hashtag)

        url = video_meta.get("url")
        self.log.info("auto_reup: start username=%s video_id=%s", username, video_meta.get("id"))

        title_raw = (
            video_meta.get("caption")
            or video_meta.get("description")
            or video_meta.get("title")
            or "tiktok_video"
        )
        title = self.clean_filename(title_raw)

        await bot.send_message(
            chat_id,
            f"🤖 Auto-reup: thấy video mới từ @{username}\n"
            f"Tiêu đề: {title_raw[:100]}"
        )

        loop = asyncio.get_running_loop()
        input_path = None
        output_path = None
        uploaded_ok = False
        progress_msg_id = None

        try:
            for ext in ["mp4", "mkv", "webm", "mov"]:
                old = f"auto_dl_input.{ext}"
                if os.path.exists(old):
                    try:
                        os.remove(old)
                    except Exception:
                        pass

            input_path = await loop.run_in_executor(
                None, self.deps.download_video, url, "auto_dl_input.mp4", None
            )
            if (not input_path or not os.path.exists(input_path)
                    or os.path.getsize(input_path) < self.config.min_valid_video_size):
                await bot.send_message(chat_id, "❌ Auto-reup: tải video thất bại, bỏ qua.")
                self.log.error("auto_reup: download failed")
                return False
            self.log.info("auto_reup: downloaded input=%s size=%s", input_path, os.path.getsize(input_path))

            output_path = f"{self.config.output_dir}/{title}_blur_{self.config.render_res}.mp4"

            msg = await bot.send_message(
                chat_id,
                f"🎬 Auto render video @{username}\n"
                f"{self._animated_progress(0)}",
                parse_mode="HTML",
            )
            progress_msg_id = msg.message_id

            res_disp = self.config.res_label.get(self.config.render_res, self.config.render_res)

            def progress_callback(frame, total, percent):
                bar = self._animated_progress(percent)
                text = (
                    f"🤖 Auto reup @{username}\n"
                    f"<code>{res_disp} | {self.config.render_fps}fps</code>\n"
                    f"{bar}\n"
                    f"<i>Frame</i>: <code>{frame:,} / {total:,}</code>"
                )

                async def _edit():
                    try:
                        await bot.edit_message_text(
                            chat_id=chat_id,
                            message_id=progress_msg_id,
                            text=text,
                            parse_mode="HTML",
                        )
                    except Exception:
                        pass

                loop.call_soon_threadsafe(lambda: asyncio.create_task(_edit()))

            render_start = time.time()
            ok_render = await loop.run_in_executor(
                None,
                self.deps.render_video,
                input_path,
                output_path,
                None,
                progress_callback,
            )
            render_elapsed = time.time() - render_start
            self.log.info("auto_reup: render_done ok=%s output=%s elapsed=%.1fs", ok_render, output_path, render_elapsed)

            if not ok_render:
                if progress_msg_id:
                    try:
                        await bot.edit_message_text(
                            chat_id=chat_id,
                            message_id=progress_msg_id,
                            text="❌ Auto-reup: lỗi render video, bỏ qua.",
                            parse_mode="HTML",
                        )
                    except Exception:
                        pass
                else:
                    await bot.send_message(chat_id, "❌ Auto-reup: lỗi render video, bỏ qua.")
                self.log.error("auto_reup: render failed output=%s", output_path)
                return False

            if progress_msg_id:
                try:
                    await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=progress_msg_id,
                        text=(
                            f"🤖 Auto reup @{username}\n"
                            f"Đang đăng lên TikTok acc <b>{acc}</b> ..."
                        ),
                        parse_mode="HTML",
                    )
                except Exception:
                    pass
            else:
                await bot.send_message(chat_id, f"🤖 Auto reup @{username}: đang đăng lên acc {acc}...")

            caption_final = self.deps.generate_caption(
                output_path,
                default_hashtag,
                user_hashtag="",
                caption_custom=title_raw
            )
            self.log.debug("auto_reup: upload caption_len=%s", len(caption_final or ""))

            ok_upload = await loop.run_in_executor(
                None,
                self.deps.upload_video,
                output_path,
                caption_final,
                None,
                user_id,
                acc,
                None
            )
            self.log.info("auto_reup: upload_done ok=%s output=%s", ok_upload, output_path)

            if ok_upload:
                uploaded_ok = True
                if progress_msg_id:
                    try:
                        await bot.edit_message_text(
                            chat_id=chat_id,
                            message_id=progress_msg_id,
                            text=(f"✅ Auto-reup: đã đăng video @{username} thành công (acc {acc})."),
                            parse_mode="HTML",
                        )
                    except Exception:
                        await bot.send_message(
                            chat_id,
                            f"✅ Auto-reup: đã đăng video @{username} thành công (acc {acc})."
                        )
                else:
                    await bot.send_message(
                        chat_id,
                        f"✅ Auto-reup: đã đăng video @{username} thành công (acc {acc})."
                    )

                video_id = video_meta.get("id")
                self.mark_auto_video_processed(
                    video_id,
                    url,
                    video_meta.get("author") or username,
                    title_raw,
                    "auto",
                )
                ts = video_meta.get("timestamp") or 0
                if ts > 0:
                    self.set_channel_last_ts(username, ts)
                return True
            else:
                if progress_msg_id:
                    try:
                        await bot.edit_message_text(
                            chat_id=chat_id,
                            message_id=progress_msg_id,
                            text=f"❌ Auto-reup: lỗi đăng video @{username} (acc {acc}).",
                            parse_mode="HTML",
                        )
                    except Exception:
                        await bot.send_message(
                            chat_id,
                            f"❌ Auto-reup: lỗi đăng video @{username} (acc {acc})."
                        )
                else:
                    await bot.send_message(
                        chat_id,
                        f"❌ Auto-reup: lỗi đăng video @{username} (acc {acc})."
                    )
                self.log.error("auto_reup: upload failed acc=%s output=%s", acc, output_path)
                return False

        except Exception as e:
            await bot.send_message(chat_id, f"❌ Auto-reup lỗi: {e}")
            traceback.print_exc()
            self.log.exception("auto_reup: error")
            return False
        finally:
            if input_path and os.path.exists(input_path):
                try:
                    os.remove(input_path)
                except Exception:
                    pass
                self.log.info("auto_reup: removed input=%s", input_path)
            if uploaded_ok and output_path and os.path.exists(output_path):
                try:
                    os.remove(output_path)
                except Exception:
                    pass
                self.log.info("auto_reup: removed output=%s", output_path)

    # ===== auto monitor =====
    async def auto_monitor_loop(self, app, interval: Optional[int] = None):
        self._auto_monitor_running = True
        self._auto_monitor_interval = interval or self.config.auto_monitor_interval
        bot = app.bot
        chat_id = self.config.owner_id
        await bot.send_message(
            chat_id,
            f"🤖 Auto-monitor TikTok: đã bật (chu kỳ {self._auto_monitor_interval // 60} phút)."
        )
        self.log.info("auto_monitor: start interval=%s", self._auto_monitor_interval)

        try:
            while self._auto_monitor_running:
                self._auto_monitor_next_ts = None
                self.log.debug("auto_monitor: scan start")

                channels = self.get_monitored_channels()
                self.log.debug("auto_monitor: channels=%s", len(channels))
                if not channels:
                    await asyncio.sleep(60)
                    continue

                for username, last_ts in channels:
                    username_clean = (username or "").strip().lstrip("@")
                    if not username_clean:
                        continue
                    new_list = []
                    try:
                        videos = await asyncio.get_event_loop().run_in_executor(
                            None, self.fetch_user_latest_videos, username_clean, 5
                        )
                        if not videos:
                            continue

                        for v in videos:
                            vid = v.get("id")
                            ts = v.get("timestamp") or 0
                            if ts <= (last_ts or 0):
                                continue
                            if self.auto_video_already_processed(vid):
                                continue
                            new_list.append(v)

                        new_list.sort(key=lambda x: x.get("timestamp") or 0)
                        self.log.info(
                            "auto_monitor: channel=%s new=%s total=%s last_ts=%s",
                            username_clean, len(new_list), len(videos), last_ts
                        )

                        for v in new_list:
                            vid = v.get("id")
                            if self.auto_video_already_processed(vid):
                                continue
                            await self.auto_reup_from_tiktok(app, username_clean, v)
                            await asyncio.sleep(30 + random.randint(0, 45))

                    except Exception:
                        self.log.exception("auto_monitor: error username=%s", username_clean)

                    # update last timestamp
                    if new_list:
                        ts = new_list[-1].get("timestamp") or 0
                        if ts > 0:
                            self.set_channel_last_ts(username_clean, ts)

                self._auto_monitor_next_ts = time.time() + self._auto_monitor_interval
                self.log.debug("auto_monitor: next_scan_ts=%s", self._auto_monitor_next_ts)
                await asyncio.sleep(self._auto_monitor_interval)
        except asyncio.CancelledError:
            self.log.info("auto_monitor: cancelled")
        finally:
            self._auto_monitor_running = False
            self._auto_monitor_next_ts = None
            await bot.send_message(chat_id, "⏹️ Auto-monitor TikTok: đã dừng.")
            self.log.info("auto_monitor: stopped")

    def start_auto_monitor(self, app, interval: Optional[int] = None) -> bool:
        if self._auto_monitor_task and not self._auto_monitor_task.done():
            return False
        self._auto_monitor_running = True
        self._auto_monitor_interval = interval or self.config.auto_monitor_interval
        self._auto_monitor_next_ts = None
        self._auto_monitor_task = app.create_task(self.auto_monitor_loop(app, self._auto_monitor_interval))
        return True

    def stop_auto_monitor(self) -> bool:
        self._auto_monitor_running = False
        self._auto_monitor_next_ts = None
        if self._auto_monitor_task and not self._auto_monitor_task.done():
            self._auto_monitor_task.cancel()
            return True
        return False

    def get_monitor_state(self) -> Tuple[bool, int, Optional[float]]:
        return self._auto_monitor_running, self._auto_monitor_interval, self._auto_monitor_next_ts
