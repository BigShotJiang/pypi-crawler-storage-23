"""Provides RS485Client class."""

from .rs485_client import RS485Client

__all__ = ["RS485Client"]
