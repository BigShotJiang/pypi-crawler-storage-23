"""
Module containing the package version information.

Attributes:
    __version__ (str): The current version of the package.
"""

__version__ = "1.2.0"
