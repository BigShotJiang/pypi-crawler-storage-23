"""
Configuration management for the Enrichment Agent.
"""
import os
from typing import Dict, Any, Optional
try:
    from pydantic_settings import BaseSettings
except ImportError:
    from pydantic import BaseSettings
from pydantic import Field

class EnrichmentConfig(BaseSettings):
    """Configuration for the Enrichment Agent."""
    model: str = Field(default="gpt-4.1-mini", description="LLM model to use for enrichment decisions (auto = let system choose)")
    temperature: float = Field(default=0.1, description="Temperature for LLM responses")
    max_tokens: int = Field(default=2000, description="Maximum tokens for LLM responses")
    provider: str = Field(default="openai", description="AI provider to use (openai, anthropic, cortex)")
  