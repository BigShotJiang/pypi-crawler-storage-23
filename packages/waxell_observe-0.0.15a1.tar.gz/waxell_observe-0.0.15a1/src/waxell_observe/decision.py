"""@waxell.decision decorator for automatic decision recording.

Wraps any function that makes a routing/classification decision so that
the choice is automatically recorded on the current WaxellContext.

Usage::

    import waxell_observe as waxell

    @waxell.decision(name="route_task", options=["direct", "research", "multi_agent"])
    async def route_task(query: str) -> str:
        response = await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": f"Classify: {query}"}],
        )
        return response.choices[0].message.content  # e.g. "research"

    # Returns "research" AND auto-records:
    #   decision(name="route_task", options=[...], chosen="research")

For structured returns::

    @waxell.decision(name="route_task", options=["direct", "research"])
    async def route_task(query: str) -> dict:
        ...
        return {
            "chosen": "research",
            "reasoning": "Complex query needs multi-doc synthesis",
            "confidence": 0.92,
        }
    # SDK extracts chosen, reasoning, confidence from the dict.
"""

import functools
import inspect
import time
from typing import Optional

from .instrumentors._context_var import _current_context


def decision(
    name: Optional[str] = None,
    options: Optional[list[str]] = None,
):
    """Decorator to auto-record a function's return value as a decision.

    Args:
        name: Decision name for telemetry. Defaults to the function name.
        options: The available choices. If not provided, recorded as empty list.
    """

    def decorator(func):
        _decision_name = name or func.__name__
        _options = options or []
        _is_async = inspect.iscoroutinefunction(func)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            ctx = _current_context.get()
            t0 = time.perf_counter()

            result = await func(*args, **kwargs)

            duration_ms = int((time.perf_counter() - t0) * 1000)
            if ctx:
                _record(ctx, _decision_name, _options, result, duration_ms)
            return result

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            ctx = _current_context.get()
            t0 = time.perf_counter()

            result = func(*args, **kwargs)

            duration_ms = int((time.perf_counter() - t0) * 1000)
            if ctx:
                _record(ctx, _decision_name, _options, result, duration_ms)
            return result

        return async_wrapper if _is_async else sync_wrapper

    return decorator


def _record(ctx, name: str, options: list[str], result, duration_ms: int):
    """Extract decision fields from result and record on context."""
    if isinstance(result, dict):
        chosen = str(result.get("chosen", result.get("choice", "")))
        reasoning = str(result.get("reasoning", result.get("reason", "")))
        confidence = result.get("confidence")
    else:
        chosen = str(result)
        reasoning = ""
        confidence = None

    kwargs = dict(
        name=name,
        options=options,
        chosen=chosen,
        reasoning=reasoning,
    )
    if confidence is not None:
        kwargs["confidence"] = float(confidence)

    kwargs["instrumentation_type"] = "decorator"
    ctx.record_decision(**kwargs)
