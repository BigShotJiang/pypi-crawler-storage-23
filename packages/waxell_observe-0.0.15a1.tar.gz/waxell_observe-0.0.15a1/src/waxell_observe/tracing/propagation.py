"""W3C Trace Context propagation for HTTP requests.

Injects traceparent headers into outgoing HTTP requests so that
server-side spans (via DjangoInstrumentor) become children of
the SDK's client spans, creating unified traces.
"""

from ._compat import _HAS_OTEL


def inject_trace_context(headers: dict) -> dict:
    """Inject W3C Trace Context (traceparent) into HTTP headers.

    Modifies headers dict in-place and returns it.
    When OTel is not available or no active span exists, returns
    headers unchanged.
    """
    if not _HAS_OTEL:
        return headers

    try:
        from opentelemetry.trace.propagation.tracecontext import (
            TraceContextTextMapPropagator,
        )

        TraceContextTextMapPropagator().inject(carrier=headers)
    except Exception:
        pass  # Never break HTTP calls because of trace propagation failure

    return headers


def extract_trace_context(headers: dict):
    """Extract W3C Trace Context from HTTP headers.

    Returns an OTel Context if available, or None.
    This is for server-side use (already handled by DjangoInstrumentor),
    included for completeness and testing.
    """
    if not _HAS_OTEL:
        return None

    try:
        from opentelemetry.trace.propagation.tracecontext import (
            TraceContextTextMapPropagator,
        )

        return TraceContextTextMapPropagator().extract(carrier=headers)
    except Exception:
        return None
