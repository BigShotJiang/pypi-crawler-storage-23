"""Span creation helpers for agent, LLM, tool, and step spans.

All helpers use get_tracer() from _compat, so they return NoOpSpan
when OTel is not available. All span creation is wrapped in try/except
to never propagate errors to user code.
"""

import logging

from ._compat import _HAS_OTEL, NoOpSpan, get_tracer, _safe_attr
from .attributes import GenAIAttributes, WaxellAttributes

logger = logging.getLogger(__name__)


def _infer_provider(model: str) -> str:
    """Guess the LLM provider from the model name prefix."""
    model_lower = model.lower()
    if model_lower.startswith(("gpt-", "o1", "o3", "chatgpt")):
        return "openai"
    if model_lower.startswith("claude"):
        return "anthropic"
    if model_lower.startswith("gemini"):
        return "google"
    if model_lower.startswith("llama"):
        return "meta"
    if model_lower.startswith("mistral"):
        return "mistral"
    return ""


def start_agent_span(
    agent_name: str,
    workflow_name: str = "default",
    agent_id: str = "",
    run_id: str = "",
    extra_attrs: dict | None = None,
):
    """Create and start an agent execution span.

    Returns the span. Caller must call span.end() when done.
    """
    try:
        tracer = get_tracer()
        attrs = {
            GenAIAttributes.OPERATION_NAME: "invoke_agent",
            GenAIAttributes.AGENT_NAME: agent_name,
            WaxellAttributes.AGENT_NAME: agent_name,
            WaxellAttributes.WORKFLOW_NAME: workflow_name,
            WaxellAttributes.SPAN_TYPE: "agent_execution",
        }
        if agent_id:
            attrs[GenAIAttributes.AGENT_ID] = agent_id
            attrs[WaxellAttributes.AGENT_ID] = agent_id
        if run_id:
            attrs[WaxellAttributes.RUN_ID] = run_id
        if extra_attrs:
            for k, v in extra_attrs.items():
                attrs[k] = _safe_attr(v)

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind

            span = tracer.start_span(
                f"invoke_agent {agent_name}",
                kind=SpanKind.INTERNAL,
                attributes=attrs,
            )
        else:
            span = tracer.start_span(f"invoke_agent {agent_name}")

        return span
    except Exception as e:
        logger.debug("Failed to create agent span: %s", e)
        return NoOpSpan()


def start_llm_span(
    model: str,
    provider_name: str = "",
    tokens_in: int = 0,
    tokens_out: int = 0,
    cost: float = 0.0,
    task: str = "",
    capture_content: bool = False,
    input_messages: str = "",
    output_messages: str = "",
    parent_span=None,
):
    """Create and start an LLM call span.

    Returns the span. Caller must call span.end() when done.
    """
    try:
        tracer = get_tracer()
        if not provider_name:
            provider_name = _infer_provider(model)

        attrs = {
            GenAIAttributes.OPERATION_NAME: "chat",
            GenAIAttributes.REQUEST_MODEL: model,
            GenAIAttributes.USAGE_INPUT_TOKENS: tokens_in,
            GenAIAttributes.USAGE_OUTPUT_TOKENS: tokens_out,
            WaxellAttributes.SPAN_TYPE: "llm_call",
            WaxellAttributes.LLM_MODEL: model,
            WaxellAttributes.LLM_INPUT_TOKENS: tokens_in,
            WaxellAttributes.LLM_OUTPUT_TOKENS: tokens_out,
            WaxellAttributes.LLM_TOTAL_TOKENS: tokens_in + tokens_out,
            WaxellAttributes.LLM_COST: cost,
        }
        if provider_name:
            attrs[GenAIAttributes.PROVIDER_NAME] = provider_name
        if capture_content and input_messages:
            attrs[GenAIAttributes.INPUT_MESSAGES] = input_messages
        if capture_content and output_messages:
            attrs[GenAIAttributes.OUTPUT_MESSAGES] = output_messages

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            # Set parent context if provided
            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"chat {model}",
                kind=SpanKind.CLIENT,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"chat {model}")

        return span
    except Exception as e:
        logger.debug("Failed to create LLM span: %s", e)
        return NoOpSpan()


def start_tool_span(
    tool_name: str,
    tool_type: str = "function",
    parent_span=None,
):
    """Create and start a tool execution span.

    Returns the span. Caller must call span.end() when done.
    """
    try:
        tracer = get_tracer()
        attrs = {
            GenAIAttributes.TOOL_NAME: tool_name,
            GenAIAttributes.TOOL_TYPE: tool_type,
            WaxellAttributes.TOOL: tool_name,
            WaxellAttributes.SPAN_TYPE: "tool_call",
        }

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"execute_tool {tool_name}",
                kind=SpanKind.INTERNAL,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"execute_tool {tool_name}")

        return span
    except Exception as e:
        logger.debug("Failed to create tool span: %s", e)
        return NoOpSpan()


def start_step_span(
    step_name: str,
    position: int = 0,
    parent_span=None,
):
    """Create and start a step execution span.

    Returns the span. Caller must call span.end() when done.
    """
    try:
        tracer = get_tracer()
        attrs = {
            WaxellAttributes.STEP_NAME: step_name,
            WaxellAttributes.STEP_POSITION: position,
            WaxellAttributes.SPAN_TYPE: "workflow_step",
        }

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"step {step_name}",
                kind=SpanKind.INTERNAL,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"step {step_name}")

        return span
    except Exception as e:
        logger.debug("Failed to create step span: %s", e)
        return NoOpSpan()


def start_decision_span(
    decision_name: str,
    options: list[str] | None = None,
    chosen: str = "",
    parent_span=None,
):
    """Create and start a decision point span."""
    try:
        tracer = get_tracer()
        attrs = {
            WaxellAttributes.SPAN_TYPE: "decision",
            "waxell.decision.name": decision_name,
        }
        if options:
            attrs["waxell.decision.options"] = ",".join(options)
        if chosen:
            attrs["waxell.decision.chosen"] = chosen

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"decision {decision_name}",
                kind=SpanKind.INTERNAL,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"decision {decision_name}")

        return span
    except Exception as e:
        logger.debug("Failed to create decision span: %s", e)
        return NoOpSpan()


def start_reasoning_span(
    step_name: str,
    parent_span=None,
):
    """Create and start a reasoning chain span."""
    try:
        tracer = get_tracer()
        attrs = {
            WaxellAttributes.SPAN_TYPE: "reasoning",
            "waxell.reasoning.step": step_name,
        }

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"reasoning {step_name}",
                kind=SpanKind.INTERNAL,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"reasoning {step_name}")

        return span
    except Exception as e:
        logger.debug("Failed to create reasoning span: %s", e)
        return NoOpSpan()


def start_retrieval_span(
    query: str,
    source: str = "",
    parent_span=None,
):
    """Create and start a retrieval operation span."""
    try:
        tracer = get_tracer()
        attrs = {
            WaxellAttributes.SPAN_TYPE: "retrieval",
            "waxell.retrieval.query": query[:500],
        }
        if source:
            attrs["waxell.retrieval.source"] = source

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"retrieval {source or 'search'}",
                kind=SpanKind.INTERNAL,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"retrieval {source or 'search'}")

        return span
    except Exception as e:
        logger.debug("Failed to create retrieval span: %s", e)
        return NoOpSpan()


def start_embedding_span(
    model: str,
    provider_name: str = "",
    input_count: int = 0,
    dimensions: int = 0,
    tokens: int = 0,
    cost: float = 0.0,
    parent_span=None,
):
    """Create and start an embedding operation span.

    Returns the span. Caller must call span.end() when done.
    """
    try:
        tracer = get_tracer()
        attrs = {
            GenAIAttributes.OPERATION_NAME: "embed",
            GenAIAttributes.REQUEST_MODEL: model,
            WaxellAttributes.SPAN_TYPE: "embedding",
            WaxellAttributes.EMBEDDING_MODEL: model,
            WaxellAttributes.EMBEDDING_INPUT_COUNT: input_count,
            WaxellAttributes.EMBEDDING_INPUT_TOKENS: tokens,
            WaxellAttributes.EMBEDDING_COST: cost,
        }
        if dimensions:
            attrs[WaxellAttributes.EMBEDDING_DIMENSIONS] = dimensions
        if provider_name:
            attrs[GenAIAttributes.PROVIDER_NAME] = provider_name

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"embed {model}",
                kind=SpanKind.CLIENT,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"embed {model}")

        return span
    except Exception as e:
        logger.debug("Failed to create embedding span: %s", e)
        return NoOpSpan()


def start_guardrail_span(
    guardrail_name: str,
    framework: str = "",
    parent_span=None,
):
    """Create and start a guardrail evaluation span.

    Returns the span. Caller must call span.end() when done.
    """
    try:
        tracer = get_tracer()
        attrs = {
            WaxellAttributes.SPAN_TYPE: "guardrail",
            WaxellAttributes.GUARDRAIL_NAME: guardrail_name,
        }
        if framework:
            attrs["waxell.guardrail.framework"] = framework

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"guardrail {guardrail_name}",
                kind=SpanKind.INTERNAL,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"guardrail {guardrail_name}")

        return span
    except Exception as e:
        logger.debug("Failed to create guardrail span: %s", e)
        return NoOpSpan()


def start_governance_span(
    policy_name: str,
    action: str = "allow",
    category: str = "",
    parent_span=None,
):
    """Create and start a governance/policy evaluation span."""
    try:
        tracer = get_tracer()
        attrs = {
            WaxellAttributes.SPAN_TYPE: "governance",
            "waxell.policy.name": policy_name,
            "waxell.policy.action": action,
        }
        if category:
            attrs["waxell.policy.category"] = category

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"policy {policy_name}",
                kind=SpanKind.INTERNAL,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"policy {policy_name}")

        return span
    except Exception as e:
        logger.debug("Failed to create governance span: %s", e)
        return NoOpSpan()


def start_retry_span(
    attempt: int,
    strategy: str = "retry",
    parent_span=None,
):
    """Create and start a retry/fallback span."""
    try:
        tracer = get_tracer()
        attrs = {
            WaxellAttributes.SPAN_TYPE: "retry",
            "waxell.retry.attempt": attempt,
            "waxell.retry.strategy": strategy,
        }

        if _HAS_OTEL:
            from opentelemetry.trace import SpanKind
            from opentelemetry import trace as trace_api

            ctx = None
            if parent_span is not None and not isinstance(parent_span, NoOpSpan):
                ctx = trace_api.set_span_in_context(parent_span)

            span = tracer.start_span(
                f"{strategy} attempt {attempt}",
                kind=SpanKind.INTERNAL,
                attributes=attrs,
                context=ctx,
            )
        else:
            span = tracer.start_span(f"{strategy} attempt {attempt}")

        return span
    except Exception as e:
        logger.debug("Failed to create retry span: %s", e)
        return NoOpSpan()
