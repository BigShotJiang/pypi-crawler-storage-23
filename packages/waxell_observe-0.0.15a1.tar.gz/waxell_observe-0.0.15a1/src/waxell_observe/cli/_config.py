"""Configuration management for wax CLI."""
import os
from configparser import ConfigParser
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

DEFAULT_API_URL = "https://api.waxell.dev"


@dataclass
class WaxConfig:
    """Configuration for wax CLI."""

    api_url: str
    api_key: str
    profile: str
    domain_url: Optional[str] = None


def get_config_dir() -> Path:
    """Get the waxell config directory."""
    return Path.home() / ".waxell"


def get_config_path() -> Path:
    """Get the config file path."""
    return get_config_dir() / "config"


def load_config(profile: Optional[str] = None, api_url_override: Optional[str] = None) -> WaxConfig:
    """Load config from ~/.waxell/config, .env, or environment.

    Priority:
    1. api_url_override parameter (from --local flag)
    2. ~/.waxell/config file (CLI config takes priority)
    3. Environment variables (WAX_API_KEY, WAX_API_URL, WAXELL_API_KEY, WAXELL_API_URL)
    4. .env file in current directory
    """
    profile = profile or os.getenv("WAX_PROFILE", "default")
    api_key = None
    api_url = None
    domain_url = None

    # Priority 1: CLI config file (~/.waxell/config)
    config_path = get_config_path()
    if config_path.exists():
        parser = ConfigParser()
        parser.read(config_path)

        if profile in parser:
            api_key = parser[profile].get("api_key")
            api_url = parser[profile].get("api_url")
            domain_url = parser[profile].get("domain_url")

    # Priority 2: Environment variables
    if not api_key:
        api_key = os.getenv("WAXELL_API_KEY") or os.getenv("WAX_API_KEY")
    if not api_url:
        api_url = os.getenv("WAXELL_API_URL") or os.getenv("WAX_API_URL")
    if not domain_url:
        domain_url = os.getenv("WAX_DOMAIN_URL")

    # Priority 3: .env file
    if not api_key or not api_url:
        try:
            from dotenv import load_dotenv
            load_dotenv()
            if not api_key:
                api_key = os.getenv("WAXELL_API_KEY") or os.getenv("WAX_API_KEY")
            if not api_url:
                api_url = os.getenv("WAXELL_API_URL") or os.getenv("WAX_API_URL")
            if not domain_url:
                domain_url = os.getenv("WAX_DOMAIN_URL")
        except ImportError:
            pass

    if not api_key:
        raise ValueError(
            "No API key found. Run 'wax login' or set WAX_API_KEY environment variable."
        )

    if api_url_override:
        api_url = api_url_override

    return WaxConfig(
        api_url=api_url or DEFAULT_API_URL,
        api_key=api_key,
        profile=profile,
        domain_url=domain_url,
    )


def get_config_from_context(ctx, profile: Optional[str] = None) -> WaxConfig:
    """Get config using context's api_url_override if set.

    Profile resolution order:
    1. Command-level --profile parameter
    2. Global --profile flag (wax --profile <name> ...)
    3. --local flag (auto-selects "local" profile)
    4. WAX_PROFILE env var
    5. "default" profile
    """
    api_url_override = None
    is_local = False
    global_profile = None
    if ctx and ctx.obj:
        api_url_override = ctx.obj.get("api_url_override")
        is_local = ctx.obj.get("local", False)
        global_profile = ctx.obj.get("profile")

    if profile is None:
        if global_profile:
            profile = global_profile
        elif is_local:
            profile = "local"

    return load_config(profile=profile, api_url_override=api_url_override)


def save_config(profile: str, api_url: str, api_key: str, domain_url: Optional[str] = None) -> Path:
    """Save configuration to ~/.waxell/config."""
    config_dir = get_config_dir()
    config_dir.mkdir(exist_ok=True)
    config_path = get_config_path()

    parser = ConfigParser()
    if config_path.exists():
        parser.read(config_path)

    data = {"api_url": api_url, "api_key": api_key}
    if domain_url:
        data["domain_url"] = domain_url

    parser[profile] = data

    with open(config_path, "w") as f:
        parser.write(f)

    config_path.chmod(0o600)
    return config_path


def list_profiles() -> list[dict]:
    """List all configured profiles."""
    config_path = get_config_path()
    if not config_path.exists():
        return []

    parser = ConfigParser()
    parser.read(config_path)

    profiles = []
    for section in parser.sections():
        profiles.append({
            "name": section,
            "api_url": parser[section].get("api_url", ""),
            "api_key": parser[section].get("api_key", "")[:12] + "...",
        })
    return profiles
