"""Who-am-I command for wax CLI."""
import json

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_error,
)


@click.command()
@click.option("--profile", default=None, help="Config profile to use")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON response")
@click.pass_context
def whoami(ctx, profile: str, as_json: bool):
    """Show current authenticated user and tenant information."""
    try:
        data = api_get(ctx, "/v1/auth/me")
    except click.ClickException as e:
        print_error(str(e))
        raise SystemExit(1)

    if as_json:
        console.print_json(json.dumps(data, indent=2))
        return

    user = data.get("user", {})
    tenant = data.get("tenant", {})
    teams = data.get("teams", [])
    roles = data.get("roles", [])
    permissions = data.get("permissions", [])

    print_header("Current Identity")

    # User info
    info_lines = []
    info_lines.append(f"[bold]Email:[/bold]     {user.get('email', '-')}")
    info_lines.append(f"[bold]User ID:[/bold]   {user.get('id', '-')}")
    info_lines.append("")
    info_lines.append(f"[bold]Tenant:[/bold]    {tenant.get('name', '-')}")
    info_lines.append(f"[bold]Slug:[/bold]      {tenant.get('slug', '-')}")
    info_lines.append(f"[bold]Tenant ID:[/bold] {tenant.get('id', '-')}")

    console.print(Panel("\n".join(info_lines), title="Identity", border_style="cyan"))

    # Teams
    if teams:
        console.print()
        table = Table(
            show_header=True,
            header_style="bold cyan",
            border_style="dim",
            title="Teams",
        )
        table.add_column("Name", style="bold")
        table.add_column("Role")
        table.add_column("ID", style="dim")

        for team in teams:
            table.add_row(
                team.get("name", "-"),
                team.get("role", "-"),
                str(team.get("id", "-")),
            )
        console.print(table)

    # Roles
    if roles:
        console.print()
        table = Table(
            show_header=True,
            header_style="bold cyan",
            border_style="dim",
            title="Roles",
        )
        table.add_column("Role", style="bold")
        table.add_column("Scope")

        for role in roles:
            if isinstance(role, dict):
                table.add_row(
                    role.get("name", "-"),
                    role.get("scope", "tenant"),
                )
            else:
                table.add_row(str(role), "tenant")
        console.print(table)

    # Permissions
    if permissions:
        console.print()
        perm_text = ", ".join(
            str(p) for p in permissions[:20]
        )
        if len(permissions) > 20:
            perm_text += f" ... and {len(permissions) - 20} more"
        console.print(f"[bold]Permissions:[/bold] {perm_text}")

    console.print()
