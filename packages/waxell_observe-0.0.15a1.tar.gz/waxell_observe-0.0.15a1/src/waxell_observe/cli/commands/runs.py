"""Execution run commands."""
import json
import time

import click

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
    fmt_number,
    fmt_cost,
    fmt_tokens,
    fmt_duration,
    pct_color,
)
from rich.table import Table
from rich.panel import Panel


@click.group()
def runs():
    """Execution run browser and analytics."""
    pass


@runs.command("list")
@click.option("--agent", default=None, help="Filter by agent name.")
@click.option(
    "--status",
    type=click.Choice(["completed", "failed", "running", "pending"]),
    default=None,
    help="Filter by status.",
)
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option("--limit", type=int, default=50, help="Maximum runs to display.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def runs_list(
    ctx, agent: str, status: str, hours: int, limit: int, output_format: str
):
    """List recent execution runs."""
    params: dict = {"hours": hours}
    if agent:
        params["agent"] = agent
    if status:
        params["status"] = status

    data = api_get(ctx, "/v1/observe/query/runs/", params=params)

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    runs_data = data.get("runs", [])
    total = data.get("total_runs", len(runs_data))
    period = data.get("period_hours", hours)

    if not runs_data:
        print_warning("No runs found for the selected period.")
        return

    runs_data = runs_data[:limit]
    print_header("Execution Runs", f"Last {period}h | {total} total runs")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Run ID", style="bold", max_width=14)
    table.add_column("Agent")
    table.add_column("Workflow")
    table.add_column("Status")
    table.add_column("Duration", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Tokens", justify="right")
    table.add_column("User", style="dim")

    for run in runs_data:
        run_id = str(run.get("run_id", run.get("id", "")))[:12]
        run_status = run.get("status", "unknown")

        table.add_row(
            run_id,
            run.get("agent_name", run.get("agent", "-")),
            run.get("workflow_name", run.get("workflow", "-")),
            f"{status_dot(run_status)} {run_status}",
            fmt_duration(run.get("duration", run.get("duration_seconds", 0))),
            fmt_cost(run.get("cost", 0)),
            fmt_tokens(run.get("total_tokens", 0)),
            str(run.get("user_id", run.get("user", "-"))),
        )

    console.print(table)
    console.print()


@runs.command("show")
@click.argument("run_id")
@click.pass_context
def runs_show(ctx, run_id: str):
    """Show detailed information for a specific run."""
    data = api_get(ctx, "/v1/observe/query/runs/", params={"run_id": run_id})

    runs_data = data.get("runs", [])
    if not runs_data:
        print_warning(f"Run '{run_id}' not found.")
        return

    run = runs_data[0]
    run_status = run.get("status", "unknown")

    print_header(f"Run: {run_id}", f"Status: {run_status}")

    # Run detail panel
    detail_lines = [
        f"[bold]Agent:[/bold]    {run.get('agent_name', run.get('agent', '-'))}",
        f"[bold]Workflow:[/bold] {run.get('workflow_name', run.get('workflow', '-'))}",
        f"[bold]Status:[/bold]   {status_dot(run_status)} {run_status}",
        f"[bold]Duration:[/bold] {fmt_duration(run.get('duration', run.get('duration_seconds', 0)))}",
        f"[bold]Cost:[/bold]     {fmt_cost(run.get('cost', 0))}",
        f"[bold]Tokens:[/bold]   {fmt_tokens(run.get('total_tokens', 0))}",
        f"[bold]User:[/bold]     {run.get('user_id', run.get('user', '-'))}",
        f"[bold]Started:[/bold]  {run.get('started_at', run.get('created_at', '-'))}",
    ]

    if run.get("completed_at"):
        detail_lines.append(f"[bold]Completed:[/bold] {run['completed_at']}")
    if run.get("session_id"):
        detail_lines.append(f"[bold]Session:[/bold]  {run['session_id']}")

    console.print(Panel("\n".join(detail_lines), title="Run Details", border_style="cyan"))
    console.print()

    # Steps
    steps = run.get("steps", [])
    if steps:
        step_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        step_table.add_column("#", justify="right", width=4)
        step_table.add_column("Step")
        step_table.add_column("Status")
        step_table.add_column("Duration", justify="right")

        for i, step in enumerate(steps, 1):
            step_status = step.get("status", "unknown")
            step_table.add_row(
                str(i),
                step.get("name", step.get("step_name", "-")),
                f"{status_dot(step_status)} {step_status}",
                fmt_duration(step.get("duration", 0)),
            )

        console.print(step_table)
        console.print()

    # LLM calls
    llm_calls = run.get("llm_calls", [])
    if llm_calls:
        llm_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        llm_table.add_column("Model")
        llm_table.add_column("Tokens In", justify="right")
        llm_table.add_column("Tokens Out", justify="right")
        llm_table.add_column("Cost", justify="right")

        for call in llm_calls:
            llm_table.add_row(
                call.get("model", "-"),
                fmt_tokens(call.get("tokens_in", call.get("input_tokens", 0))),
                fmt_tokens(call.get("tokens_out", call.get("output_tokens", 0))),
                fmt_cost(call.get("cost", 0)),
            )

        console.print(llm_table)
        console.print()

    # Governance scores
    scores = run.get("scores", run.get("governance", {}))
    if scores:
        console.print(
            Panel(
                json.dumps(scores, indent=2),
                title="Governance Scores",
                border_style="yellow",
            )
        )
        console.print()

    # Context / metadata
    context = run.get("context", run.get("metadata", {}))
    if context:
        console.print(
            Panel(
                json.dumps(context, indent=2),
                title="Context",
                border_style="dim",
            )
        )
        console.print()


@runs.command("watch")
@click.option("--agent", default=None, help="Filter by agent name.")
@click.option("--interval", type=int, default=5, help="Poll interval in seconds.")
@click.pass_context
def runs_watch(ctx, agent: str, interval: int):
    """Watch live execution runs (polls every N seconds)."""
    console.print("[bold cyan]Watching runs...[/bold cyan] (Ctrl+C to stop)")
    console.print()

    seen_ids: set = set()
    try:
        while True:
            params: dict = {"hours": 0.08}  # ~5 minutes
            if agent:
                params["agent"] = agent

            data = api_get(ctx, "/v1/observe/query/runs/", params=params)
            runs_data = data.get("runs", [])

            new_runs = []
            for run in runs_data:
                rid = run.get("run_id", run.get("id", ""))
                if rid and rid not in seen_ids:
                    seen_ids.add(rid)
                    new_runs.append(run)

            if new_runs:
                table = Table(
                    show_header=True, header_style="bold cyan", border_style="dim"
                )
                table.add_column("Run ID", style="bold", max_width=14)
                table.add_column("Agent")
                table.add_column("Status")
                table.add_column("Duration", justify="right")
                table.add_column("Cost", justify="right")

                for run in new_runs:
                    run_status = run.get("status", "unknown")
                    table.add_row(
                        str(run.get("run_id", run.get("id", "")))[:12],
                        run.get("agent_name", run.get("agent", "-")),
                        f"{status_dot(run_status)} {run_status}",
                        fmt_duration(
                            run.get("duration", run.get("duration_seconds", 0))
                        ),
                        fmt_cost(run.get("cost", 0)),
                    )

                console.print(table)

            time.sleep(interval)

    except KeyboardInterrupt:
        console.print()
        console.print("[dim]Stopped watching.[/dim]")


@runs.command("stats")
@click.option("--hours", type=int, default=24, help="Time window in hours.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format.",
)
@click.pass_context
def runs_stats(ctx, hours: int, output_format: str):
    """Show summary statistics for runs."""
    data = api_get(ctx, "/v1/observe/query/dashboard/", params={"hours": hours})

    if output_format == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    print_header("Run Statistics", f"Last {hours}h")

    total = data.get("total_runs", data.get("total_executions", 0))
    error_rate = data.get("error_rate", 0)
    error_pct = error_rate * 100 if error_rate < 1 else error_rate
    avg_cost = data.get("avg_cost_per_run", data.get("avg_cost", 0))
    total_cost = data.get("total_cost", 0)

    stats_text = (
        f"[bold]Total Runs:[/bold]   {fmt_number(total)}\n"
        f"[bold]Error Rate:[/bold]   {error_pct:.1f}%\n"
        f"[bold]Total Cost:[/bold]   {fmt_cost(total_cost)}\n"
        f"[bold]Avg Cost/Run:[/bold] {fmt_cost(avg_cost)}"
    )
    console.print(Panel(stats_text, title="Summary", border_style="cyan"))
    console.print()

    # Top agents
    top_agents = data.get("top_agents", [])
    if top_agents:
        agent_table = Table(
            show_header=True, header_style="bold cyan", border_style="dim"
        )
        agent_table.add_column("Agent", style="bold")
        agent_table.add_column("Runs", justify="right")
        agent_table.add_column("Error Rate", justify="right")
        agent_table.add_column("Cost", justify="right")

        for agent in top_agents:
            a_err = agent.get("error_rate", 0)
            a_err_pct = a_err * 100 if a_err < 1 else a_err
            err_color = pct_color(a_err_pct)

            agent_table.add_row(
                agent.get("name", agent.get("agent_name", "unknown")),
                fmt_number(agent.get("runs", agent.get("executions", 0))),
                f"[{err_color}]{a_err_pct:.1f}%[/{err_color}]",
                fmt_cost(agent.get("cost", 0)),
            )

        console.print(agent_table)
        console.print()
