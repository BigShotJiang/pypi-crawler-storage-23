"""Governance events and compliance commands."""
import json
from datetime import datetime
from typing import Optional

import click
from rich.panel import Panel
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    fmt_number,
)


def _normalize_items(data):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get("results", data.get("items", data.get("events", data)))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


def _short_ts(ts: Optional[str]) -> str:
    """Format an ISO timestamp to a short display string."""
    if not ts:
        return "-"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, TypeError):
        return str(ts)[:19]


@click.group(name="governance")
def governance():
    """Governance events and compliance reporting."""


@governance.command("events")
@click.option("--minutes", default=60, type=int, help="Look back N minutes (default: 60)")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def governance_events(ctx, minutes: int, fmt: str):
    """Show recent governance events."""
    data = api_get(ctx, "/v1/observe/governance/events/", params={"minutes": minutes})
    items = _normalize_items(data)

    if fmt == "json":
        console.print_json(json.dumps(items, indent=2))
        return

    if not items:
        print_warning(f"No governance events in the last {minutes} minutes.")
        return

    print_header("Governance Events", f"Last {minutes} minutes -- {len(items)} events")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Timestamp")
    table.add_column("Event Type")
    table.add_column("Policy")
    table.add_column("Agent")
    table.add_column("Action")
    table.add_column("Detail")

    for ev in items:
        action = ev.get("action", ev.get("decision", "-"))
        action_str = str(action)
        if action_str.lower() == "block":
            action_str = f"[red]{action_str}[/red]"
        elif action_str.lower() == "warn":
            action_str = f"[yellow]{action_str}[/yellow]"
        elif action_str.lower() == "allow":
            action_str = f"[green]{action_str}[/green]"

        table.add_row(
            _short_ts(ev.get("timestamp", ev.get("created_at"))),
            ev.get("event_type", ev.get("type", "-")),
            ev.get("policy", ev.get("policy_name", "-")),
            ev.get("agent", ev.get("agent_name", "-")),
            action_str,
            str(ev.get("detail", ev.get("reason", "-")))[:60],
        )

    console.print(table)
    console.print()


@governance.command("compliance")
@click.option("--hours", default=24, type=int, help="Look back N hours (default: 24)")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def governance_compliance(ctx, hours: int, fmt: str):
    """Show compliance summary for policy checks."""
    data = api_get(ctx, "/v1/observe/query/policies/", params={"hours": hours})

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    # Extract stats -- handle both flat and nested response shapes
    if isinstance(data, dict):
        stats = data.get("summary", data.get("stats", data))
    else:
        stats = {}

    total = stats.get("total_checks", stats.get("total", 0))
    allow = stats.get("allow_count", stats.get("allow", 0))
    warn = stats.get("warn_count", stats.get("warn", 0))
    block = stats.get("block_count", stats.get("block", 0))

    if total == 0:
        # Try to compute from results list
        items = []
        if isinstance(data, dict):
            items = data.get("results", data.get("items", []))
        elif isinstance(data, list):
            items = data
        if items and isinstance(items, list):
            total = len(items)
            allow = sum(1 for i in items if str(i.get("action", i.get("decision", ""))).lower() == "allow")
            warn = sum(1 for i in items if str(i.get("action", i.get("decision", ""))).lower() == "warn")
            block = sum(1 for i in items if str(i.get("action", i.get("decision", ""))).lower() == "block")

    compliance_rate = (allow / total * 100) if total > 0 else 100.0

    print_header("Compliance Report", f"Last {hours} hours")

    if compliance_rate >= 95:
        rate_color = "green"
    elif compliance_rate >= 80:
        rate_color = "yellow"
    else:
        rate_color = "red"

    lines = [
        f"[bold]Total Policy Checks:[/bold]  {fmt_number(total)}",
        "",
        f"  [green]Allow:[/green]   {fmt_number(allow)}",
        f"  [yellow]Warn:[/yellow]    {fmt_number(warn)}",
        f"  [red]Block:[/red]   {fmt_number(block)}",
        "",
        f"[bold]Compliance Rate:[/bold]     [{rate_color}]{compliance_rate:.1f}%[/{rate_color}]",
    ]

    # Per-policy breakdown if available
    by_policy = stats.get("by_policy", data.get("by_policy", {}))
    if by_policy and isinstance(by_policy, dict):
        lines.append("")
        lines.append("[bold]By Policy:[/bold]")
        for policy_name, counts in by_policy.items():
            if isinstance(counts, dict):
                p_total = counts.get("total", 0)
                p_block = counts.get("block", 0)
                lines.append(f"  {policy_name}: {fmt_number(p_total)} checks, {fmt_number(p_block)} blocks")
            else:
                lines.append(f"  {policy_name}: {counts}")

    console.print(Panel("\n".join(lines), title="Compliance Summary", border_style="cyan"))
    console.print()
