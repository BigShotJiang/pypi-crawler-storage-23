"""LLM configuration commands."""
import json

import click
from rich.table import Table

from .._http import api_get
from .._display import (
    console,
    print_header,
    print_warning,
    status_dot,
)


def _normalize_items(data, key: str = "routes"):
    """Extract items from paginated or raw list responses."""
    if isinstance(data, dict):
        items = data.get(key, data.get("results", data.get("items", data)))
    else:
        items = data
    if not isinstance(items, list):
        items = [items] if items else []
    return items


@click.group(name="llm")
def llm_config():
    """View LLM configuration: routing and models."""


@llm_config.command("routing")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def llm_routing(ctx, fmt: str):
    """Show LLM routing configuration."""
    data = api_get(ctx, "/v1/observe/query/llm-config/")

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    items = _normalize_items(data, "routes")

    if not items:
        print_warning("No LLM routing configuration found.")
        return

    print_header("LLM Routing", f"{len(items)} routes configured")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Route Name", style="bold")
    table.add_column("Models")
    table.add_column("Priority", justify="right")
    table.add_column("Status", justify="center")

    for route in items:
        models = route.get("models", route.get("model_list", []))
        if isinstance(models, list):
            models_str = ", ".join(str(m) for m in models[:3])
            if len(models) > 3:
                models_str += f" +{len(models) - 3}"
        else:
            models_str = str(models) if models else "-"

        is_active = route.get("is_active", route.get("enabled", route.get("status", "") == "active"))
        status = "active" if is_active else "inactive"

        table.add_row(
            route.get("name", route.get("route_name", "-")),
            models_str,
            str(route.get("priority", "-")),
            status_dot(status),
        )

    console.print(table)
    console.print()


@llm_config.command("models")
@click.option("--format", "fmt", type=click.Choice(["table", "json"]), default="table", help="Output format")
@click.pass_context
def llm_models(ctx, fmt: str):
    """Show available LLM models and pricing."""
    data = api_get(ctx, "/v1/observe/query/llm-config/")

    if fmt == "json":
        console.print_json(json.dumps(data, indent=2))
        return

    items = _normalize_items(data, "models")

    if not items:
        print_warning("No LLM model configuration found.")
        return

    print_header("LLM Models", f"{len(items)} models available")

    table = Table(show_header=True, header_style="bold cyan", border_style="dim")
    table.add_column("Model", style="bold")
    table.add_column("Provider")
    table.add_column("Status", justify="center")
    table.add_column("Input $/1K", justify="right")
    table.add_column("Output $/1K", justify="right")

    for model in items:
        is_active = model.get("is_active", model.get("enabled", model.get("status", "") == "active"))
        status = "active" if is_active else "inactive"

        # Cost per 1K tokens
        input_cost = model.get("input_cost_per_1k", model.get("input_cost", 0)) or 0
        output_cost = model.get("output_cost_per_1k", model.get("output_cost", 0)) or 0

        # If costs are per-token, convert to per-1K
        if input_cost > 0 and input_cost < 0.001:
            input_cost *= 1000
        if output_cost > 0 and output_cost < 0.001:
            output_cost *= 1000

        table.add_row(
            model.get("model", model.get("model_name", model.get("name", "-"))),
            model.get("provider", "-"),
            status_dot(status),
            f"${input_cost:.4f}" if input_cost else "-",
            f"${output_cost:.4f}" if output_cost else "-",
        )

    console.print(table)
    console.print()
