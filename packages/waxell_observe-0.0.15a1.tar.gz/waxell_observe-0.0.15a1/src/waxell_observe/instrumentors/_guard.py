"""Client-side prompt guard for waxell-observe.

Intercepts LLM calls in all instrumentor wrappers (OpenAI, Anthropic,
LiteLLM, Groq) and checks prompts for PII, credentials, and prompt
injection BEFORE the call is made.

Two tiers of detection:
1. Local regex (always runs when enabled) — instant, zero network overhead
2. Server-side ML (opt-in via prompt_guard_server) — Presidio + HF model

Three configurable actions:
- block: raise PromptGuardError, LLM call never made
- warn: log violations, continue with original messages
- redact: replace sensitive data with ##TYPE##, continue with sanitized messages

Configuration is set at module level via configure() during init().
"""

from __future__ import annotations

import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level config (set by configure(), read by check_prompt())
# ---------------------------------------------------------------------------

_enabled: bool = False
_server_check: bool = False
_action: str = "block"  # "block", "warn", "redact"


def configure(enabled: bool = False, server: bool = False, action: str = "block") -> None:
    """Configure the prompt guard. Called from init()."""
    global _enabled, _server_check, _action
    _enabled = enabled
    _server_check = server
    _action = action if action in ("block", "warn", "redact") else "block"
    if _enabled:
        logger.debug(
            "Prompt guard configured: enabled=%s server=%s action=%s",
            _enabled, _server_check, _action,
        )


# ---------------------------------------------------------------------------
# Regex patterns (standalone copies from content_detection.py — observe SDK
# cannot import infra)
# ---------------------------------------------------------------------------

_PII_PATTERNS = {
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "email": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"),
    "phone": re.compile(
        r"\b(?:\+1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"
    ),
    "credit_card": re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"),
}

_CREDENTIAL_PATTERNS = {
    "password": re.compile(
        r"(?:password|passwd|pwd)\s*[:=]\s*\S+", re.IGNORECASE
    ),
    "api_key": re.compile(
        r"(?:api[_-]?key|apikey|api[_-]?secret)\s*[:=]\s*\S+", re.IGNORECASE
    ),
    "secret": re.compile(
        r"(?:secret[_-]?key|access[_-]?key|client[_-]?secret)\s*[:=]\s*\S+",
        re.IGNORECASE,
    ),
    "aws_key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "generic_token": re.compile(
        r"\b(?:sk-|pk_live_|sk_live_|rk_live_|sk_test_)[a-zA-Z0-9]{20,}\b"
    ),
    "github_pat": re.compile(r"\bghp_[a-zA-Z0-9]{36}\b"),
    "waxell_key": re.compile(r"\bwax_sk_[a-zA-Z0-9]+\b"),
}

_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(?:all\s+)?previous\s+instructions", re.IGNORECASE),
    re.compile(r"ignore\s+(?:all\s+)?above\s+instructions", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+(?:a|an)\s+", re.IGNORECASE),
    re.compile(r"forget\s+(?:all\s+)?(?:your|previous)\s+instructions", re.IGNORECASE),
    re.compile(r"disregard\s+(?:all\s+)?previous", re.IGNORECASE),
    re.compile(r"new\s+instructions?\s*:", re.IGNORECASE),
    re.compile(r"override\s+(?:your\s+)?(?:system|instructions)", re.IGNORECASE),
    re.compile(r"```system\b", re.IGNORECASE),
    re.compile(r"\[system\]\s*:", re.IGNORECASE),
    re.compile(r"<\|system\|>", re.IGNORECASE),
    re.compile(r"ADMIN\s+MODE\s+ENABLED", re.IGNORECASE),
    re.compile(r"developer\s+mode\s+(?:is\s+)?(?:enabled|activated|on)", re.IGNORECASE),
    re.compile(r"jailbreak", re.IGNORECASE),
    re.compile(r"DAN\s+mode", re.IGNORECASE),
]


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------

def _extract_text(messages: list, system: str = "") -> str:
    """Extract scannable text from a messages list.

    Handles:
    - OpenAI: [{role, content: str}]
    - Anthropic: [{role, content: str | list[{type, text}]}]
    - system kwarg (Anthropic passes system separately)
    """
    parts: list[str] = []

    if system:
        parts.append(str(system))

    for msg in messages:
        if not isinstance(msg, dict):
            continue
        content = msg.get("content", "")
        if isinstance(content, str):
            parts.append(content)
        elif isinstance(content, list):
            # Anthropic multimodal: [{type: "text", text: "..."}, ...]
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Local regex detection
# ---------------------------------------------------------------------------

def _detect_pii(text: str) -> list[str]:
    """Detect PII patterns. Returns violation descriptions."""
    violations = []
    for pii_type, pattern in _PII_PATTERNS.items():
        if pattern.search(text):
            violations.append(f"PII detected: {pii_type}")
    return violations


def _detect_credentials(text: str) -> list[str]:
    """Detect credential patterns. Returns violation descriptions."""
    violations = []
    for cred_type, pattern in _CREDENTIAL_PATTERNS.items():
        if pattern.search(text):
            violations.append(f"Credential detected: {cred_type}")
    return violations


def _detect_injection(text: str) -> list[str]:
    """Detect prompt injection patterns. Returns violation descriptions."""
    violations = []
    for pattern in _INJECTION_PATTERNS:
        match = pattern.search(text)
        if match:
            violations.append(f"Prompt injection pattern: '{match.group()}'")
    return violations


# ---------------------------------------------------------------------------
# Redaction
# ---------------------------------------------------------------------------

def _redact_text(text: str) -> str:
    """Replace detected patterns with ##TYPE## placeholders."""
    redacted = text

    # PII
    for pii_type, pattern in _PII_PATTERNS.items():
        tag = f"##{pii_type.upper()}##"
        redacted = pattern.sub(tag, redacted)

    # Credentials
    for cred_type, pattern in _CREDENTIAL_PATTERNS.items():
        tag = f"##{cred_type.upper()}##"
        redacted = pattern.sub(tag, redacted)

    return redacted


def _redact_messages(messages: list, system: str = "") -> tuple[list, str]:
    """Return copies of messages and system with sensitive data redacted.

    Does NOT mutate the originals.
    """
    redacted_msgs = []
    for msg in messages:
        if not isinstance(msg, dict):
            redacted_msgs.append(msg)
            continue

        msg_copy = dict(msg)
        content = msg_copy.get("content", "")

        if isinstance(content, str):
            msg_copy["content"] = _redact_text(content)
        elif isinstance(content, list):
            # Anthropic multimodal
            new_blocks = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    new_blocks.append({
                        **block,
                        "text": _redact_text(block.get("text", "")),
                    })
                else:
                    new_blocks.append(block)
            msg_copy["content"] = new_blocks

        redacted_msgs.append(msg_copy)

    redacted_system = _redact_text(system) if system else system
    return redacted_msgs, redacted_system


# ---------------------------------------------------------------------------
# Server-side check
# ---------------------------------------------------------------------------

def _server_check_prompt(text: str, model: str = "") -> Optional[dict]:
    """Call the controlplane prompt-guard endpoint for ML-powered scanning.

    Returns the server response dict or None on failure.
    """
    try:
        from ..client import WaxellObserveClient

        if not WaxellObserveClient.is_configured():
            return None

        client = WaxellObserveClient()
        return client.prompt_guard_sync(text=text, model=model)
    except Exception as e:
        logger.debug("Server-side prompt guard failed: %s", e)
        return None


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def check_prompt(
    messages: list,
    model: str = "",
    system: str = "",
) -> Optional["PromptGuardResult"]:
    """Check a prompt for violations before sending to the LLM.

    Returns None if guard is disabled (zero overhead path).
    Returns PromptGuardResult with passed=True if no violations.
    Returns PromptGuardResult with passed=False if violations found.
    """
    if not _enabled:
        return None

    from ..types import PromptGuardResult

    text = _extract_text(messages, system)
    if not text.strip():
        return None

    # --- Tier 1: Local regex ---
    violations: list[str] = []
    violations.extend(_detect_pii(text))
    violations.extend(_detect_credentials(text))
    violations.extend(_detect_injection(text))

    source = "local"

    # --- Tier 2: Server-side ML (opt-in) ---
    server_redacted_text = None
    if _server_check:
        server_result = _server_check_prompt(text, model)
        if server_result:
            server_violations = server_result.get("violations", [])
            if server_violations:
                for v in server_violations:
                    desc = v if isinstance(v, str) else v.get("detail", str(v))
                    if desc not in violations:
                        violations.append(f"[server] {desc}")
                source = "both" if violations else "server"
            server_redacted_text = server_result.get("redacted_text")

    # --- No violations → pass ---
    if not violations:
        return PromptGuardResult(passed=True, action="allow", source=source)

    # --- Violations found → apply configured action ---
    action = _action

    # Build result
    redacted_messages = None
    redacted_system = None

    if action == "redact":
        redacted_messages, redacted_system = _redact_messages(messages, system)

    if action == "warn":
        logger.warning(
            "Prompt guard violations (warn mode): %s",
            "; ".join(violations),
        )

    result = PromptGuardResult(
        passed=(action == "warn"),  # warn passes, block/redact don't
        action=action,
        violations=violations,
        source=source,
        redacted_messages=redacted_messages,
    )

    # Stash redacted system for Anthropic
    if redacted_system is not None:
        result._redacted_system = redacted_system  # type: ignore[attr-defined]

    return result


# ---------------------------------------------------------------------------
# Error class
# ---------------------------------------------------------------------------

class PromptGuardError(Exception):
    """Raised when prompt guard blocks an LLM call."""

    def __init__(self, result: "PromptGuardResult"):
        self.result = result
        violations_str = "; ".join(result.violations[:5])
        if len(result.violations) > 5:
            violations_str += f" (+{len(result.violations) - 5} more)"
        super().__init__(f"Prompt blocked by guard: {violations_str}")
