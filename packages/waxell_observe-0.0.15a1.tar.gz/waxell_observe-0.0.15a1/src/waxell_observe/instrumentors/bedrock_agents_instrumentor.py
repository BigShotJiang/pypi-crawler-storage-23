"""Amazon Bedrock Agents auto-instrumentor for waxell-observe.

Monkey-patches ``botocore.client.BaseClient._make_api_call`` to intercept
Bedrock Agent Runtime ``InvokeAgent`` and ``InvokeInlineAgent`` operations,
emitting OTel spans and recording to the Waxell HTTP API.

This is separate from the Bedrock Runtime instrumentor (which covers
Converse/InvokeModel for direct LLM calls). This instrumentor covers
the agent orchestration layer.

All wrapper code is wrapped in try/except -- never breaks the user's API calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# Operations we instrument on bedrock-agent-runtime
_AGENT_OPERATIONS = {"InvokeAgent", "InvokeInlineAgent"}


class BedrockAgentsInstrumentor(BaseInstrumentor):
    """Instrumentor for Amazon Bedrock Agents via boto3/botocore.

    Patches ``BaseClient._make_api_call`` and filters to bedrock-agent-runtime
    ``InvokeAgent`` and ``InvokeInlineAgent`` operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import botocore.client  # noqa: F401
        except ImportError:
            logger.debug("botocore not installed -- skipping Bedrock Agents instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Bedrock Agents instrumentation")
            return False

        try:
            wrapt.wrap_function_wrapper(
                "botocore.client",
                "BaseClient._make_api_call",
                _agent_api_call_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch botocore for Bedrock Agents: %s", exc)
            return False

        self._instrumented = True
        logger.debug("Bedrock Agents instrumented via botocore")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import botocore.client as mod

            if hasattr(mod.BaseClient._make_api_call, "__wrapped__"):
                mod.BaseClient._make_api_call = mod.BaseClient._make_api_call.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Bedrock Agents uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_bedrock_agent_runtime(instance) -> bool:
    """Check if the botocore client is a bedrock-agent-runtime client."""
    try:
        service_model = getattr(instance, "_service_model", None)
        if service_model:
            service_name = getattr(service_model, "service_name", "")
            return service_name == "bedrock-agent-runtime"
        # Fallback: check endpoint URL
        endpoint = getattr(instance, "_endpoint", None)
        if endpoint:
            host = str(getattr(endpoint, "host", ""))
            return "bedrock-agent-runtime" in host
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# Wrapper function
# ---------------------------------------------------------------------------


def _agent_api_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``BaseClient._make_api_call``.

    Only instruments bedrock-agent-runtime InvokeAgent/InvokeInlineAgent.
    All other API calls pass through untouched.
    """
    # args[0] = operation_name, args[1] = api_params
    operation_name = args[0] if args else kwargs.get("operation_name", "")
    api_params = args[1] if len(args) > 1 else kwargs.get("api_params", {})

    # Only instrument bedrock-agent-runtime operations we care about
    if operation_name not in _AGENT_OPERATIONS or not _is_bedrock_agent_runtime(instance):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract agent info from API params
    agent_id = api_params.get("agentId", "bedrock-agent")
    agent_alias_id = api_params.get("agentAliasId", "")
    session_id = api_params.get("sessionId", "")
    input_text = api_params.get("inputText", "")

    try:
        span = start_agent_span(
            agent_name=f"bedrock-agent:{agent_id}",
            workflow_name=f"bedrock_{operation_name.lower()}",
        )
        span.set_attribute("waxell.bedrock_agents.agent_id", agent_id)
        span.set_attribute("waxell.bedrock_agents.operation", operation_name)
        if agent_alias_id:
            span.set_attribute("waxell.bedrock_agents.agent_alias_id", agent_alias_id)
        if session_id:
            span.set_attribute("waxell.bedrock_agents.session_id", session_id)
        if input_text:
            span.set_attribute("waxell.bedrock_agents.input_preview", input_text[:200])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_response_attributes(span, response, agent_id, operation_name)
        except Exception:
            pass

        # Record to HTTP path
        try:
            _record_http_bedrock_agent(response, agent_id, session_id, operation_name, input_text)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Result processing
# ---------------------------------------------------------------------------


def _set_response_attributes(span, response: dict, agent_id: str, operation: str) -> None:
    """Extract and set response attributes on the span."""
    # InvokeAgent returns a streaming response with 'completion' EventStream
    completion = response.get("completion", None)
    if completion:
        span.set_attribute("waxell.bedrock_agents.has_completion", True)

    # Extract session ID from response
    session_id = response.get("sessionId", "")
    if session_id:
        span.set_attribute("waxell.bedrock_agents.response_session_id", session_id)

    # Content type
    content_type = response.get("contentType", "")
    if content_type:
        span.set_attribute("waxell.bedrock_agents.content_type", content_type)


def _record_http_bedrock_agent(
    response: dict,
    agent_id: str,
    session_id: str,
    operation: str,
    input_text: str,
) -> None:
    """Record a Bedrock Agent call to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"bedrock_agent:{agent_id}:{operation}",
            output={
                "agent_id": agent_id,
                "session_id": session_id,
                "operation": operation,
                "input_preview": input_text[:500],
                "has_completion": "completion" in response,
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
