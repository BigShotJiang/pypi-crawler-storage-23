"""Pipecat auto-instrumentor for waxell-observe.

Monkey-patches Pipecat pipeline processing, STT (speech-to-text), and
TTS (text-to-speech) service calls to emit OTel spans and record to
the Waxell HTTP API.

Pipecat is a voice agent framework for building real-time conversational
AI applications. It uses a pipeline architecture where audio flows through
a series of processors (STT, LLM, TTS) connected in a directed graph.

Patched methods:
  - ``pipecat.pipeline.pipeline.Pipeline.run``       — pipeline execution
  - ``pipecat.services.ai_services.STTService.run``   — speech-to-text
  - ``pipecat.services.ai_services.TTSService.run``   — text-to-speech
  - ``pipecat.processors.frame_processor.FrameProcessor.process_frame``
    — individual frame processor execution

All wrapper code is wrapped in try/except -- never breaks the user's pipeline.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class PipecatInstrumentor(BaseInstrumentor):
    """Instrumentor for the Pipecat voice agent framework (``pipecat`` package).

    Patches Pipeline.run for pipeline execution, STTService.run and
    TTSService.run for speech services, and FrameProcessor.process_frame
    for individual processor steps.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import pipecat  # noqa: F401
        except ImportError:
            logger.debug("pipecat not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Pipecat instrumentation")
            return False

        patched = False

        # Patch Pipeline.run (main pipeline execution)
        try:
            wrapt.wrap_function_wrapper(
                "pipecat.pipeline.pipeline",
                "Pipeline.run",
                _pipeline_run_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch Pipeline.run: %s", exc)

        # Also try PipelineRunner.run if available
        try:
            wrapt.wrap_function_wrapper(
                "pipecat.pipeline.runner",
                "PipelineRunner.run",
                _pipeline_runner_wrapper,
            )
            if not patched:
                patched = True
        except Exception as exc:
            logger.debug("Failed to patch PipelineRunner.run: %s", exc)

        # Patch STTService.run (speech-to-text processing)
        try:
            wrapt.wrap_function_wrapper(
                "pipecat.services.ai_services",
                "STTService.run",
                _stt_service_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch STTService.run: %s", exc)

        # Patch TTSService.run (text-to-speech processing)
        try:
            wrapt.wrap_function_wrapper(
                "pipecat.services.ai_services",
                "TTSService.run",
                _tts_service_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch TTSService.run: %s", exc)

        # Patch FrameProcessor.process_frame (individual processor step)
        try:
            wrapt.wrap_function_wrapper(
                "pipecat.processors.frame_processor",
                "FrameProcessor.process_frame",
                _process_frame_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch FrameProcessor.process_frame: %s", exc)

        if not patched:
            logger.debug("Could not find Pipecat methods to patch")
            return False

        self._instrumented = True
        logger.debug(
            "Pipecat instrumented (Pipeline.run + STTService.run + TTSService.run + "
            "FrameProcessor.process_frame)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Uninstrument Pipeline.run
        try:
            from pipecat.pipeline.pipeline import Pipeline

            method = getattr(Pipeline, "run", None)
            if method is not None and hasattr(method, "__wrapped__"):
                Pipeline.run = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument PipelineRunner.run
        try:
            from pipecat.pipeline.runner import PipelineRunner

            method = getattr(PipelineRunner, "run", None)
            if method is not None and hasattr(method, "__wrapped__"):
                PipelineRunner.run = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument STTService.run
        try:
            from pipecat.services.ai_services import STTService

            method = getattr(STTService, "run", None)
            if method is not None and hasattr(method, "__wrapped__"):
                STTService.run = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument TTSService.run
        try:
            from pipecat.services.ai_services import TTSService

            method = getattr(TTSService, "run", None)
            if method is not None and hasattr(method, "__wrapped__"):
                TTSService.run = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Uninstrument FrameProcessor.process_frame
        try:
            from pipecat.processors.frame_processor import FrameProcessor

            method = getattr(FrameProcessor, "process_frame", None)
            if method is not None and hasattr(method, "__wrapped__"):
                FrameProcessor.process_frame = method.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Pipecat uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Pipecat instances
# ---------------------------------------------------------------------------


def _extract_pipeline_name(instance) -> str:
    """Extract pipeline name from a Pipecat Pipeline instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        # Try to derive from processors list
        processors = getattr(instance, "processors", None) or getattr(
            instance, "_processors", None
        )
        if processors and isinstance(processors, (list, tuple)):
            proc_names = []
            for proc in processors[:5]:  # Limit to first 5
                pname = getattr(proc, "name", None) or type(proc).__name__
                proc_names.append(str(pname))
            if proc_names:
                return f"pipeline({' -> '.join(proc_names)})"
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "pipecat.pipeline"


def _extract_processor_name(instance) -> str:
    """Extract processor name from a Pipecat FrameProcessor instance."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "pipecat.processor"


def _extract_service_name(instance) -> str:
    """Extract service name from a Pipecat service instance (STT/TTS)."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        # Try to get model name for service identification
        model = getattr(instance, "model_name", None) or getattr(instance, "model", None)
        if model:
            return f"{type(instance).__name__}({model})"
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "pipecat.service"


def _extract_audio_metadata(instance, args, kwargs) -> dict:
    """Extract audio-related metadata from pipeline/service instances."""
    metadata = {}

    try:
        sample_rate = getattr(instance, "sample_rate", None)
        if sample_rate:
            metadata["sample_rate"] = int(sample_rate)
    except Exception:
        pass

    try:
        channels = getattr(instance, "channels", None) or getattr(
            instance, "num_channels", None
        )
        if channels:
            metadata["channels"] = int(channels)
    except Exception:
        pass

    try:
        language = getattr(instance, "language", None)
        if language:
            metadata["language"] = str(language)
    except Exception:
        pass

    try:
        model = getattr(instance, "model_name", None) or getattr(instance, "model", None)
        if model:
            metadata["model"] = str(model)
    except Exception:
        pass

    return metadata


def _extract_frame_type(args) -> str:
    """Extract the frame type from process_frame arguments."""
    if args:
        frame = args[0]
        try:
            return type(frame).__name__
        except Exception:
            pass
    return "unknown"


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


async def _pipeline_run_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Pipeline.run`` -- pipeline execution."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    pipeline_name = _extract_pipeline_name(instance)

    try:
        span = start_agent_span(
            agent_name=pipeline_name,
            workflow_name="pipecat_pipeline_run",
        )
        span.set_attribute("waxell.agent.framework", "pipecat")
        span.set_attribute("waxell.pipecat.pipeline_name", pipeline_name)

        # Extract processor names if available
        try:
            processors = getattr(instance, "processors", None) or getattr(
                instance, "_processors", None
            )
            if processors and isinstance(processors, (list, tuple)):
                proc_names = [
                    str(getattr(p, "name", None) or type(p).__name__)
                    for p in processors
                ]
                span.set_attribute(
                    "waxell.pipecat.processor_names", ", ".join(proc_names)
                )
                span.set_attribute(
                    "waxell.pipecat.processor_count", len(proc_names)
                )
        except Exception:
            pass
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_pipeline_result_attributes(span, result, pipeline_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _pipeline_runner_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``PipelineRunner.run`` -- pipeline runner execution."""
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    runner_name = _extract_processor_name(instance)

    try:
        span = start_agent_span(
            agent_name=runner_name,
            workflow_name="pipecat_pipeline_runner",
        )
        span.set_attribute("waxell.agent.framework", "pipecat")
        span.set_attribute("waxell.pipecat.runner_name", runner_name)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.pipecat.status", "completed")
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _stt_service_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``STTService.run`` -- speech-to-text processing."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    service_name = _extract_service_name(instance)
    audio_metadata = _extract_audio_metadata(instance, args, kwargs)

    try:
        span = start_step_span(step_name=f"stt:{service_name}")
        span.set_attribute("waxell.agent.framework", "pipecat")
        span.set_attribute("waxell.pipecat.service_type", "stt")
        span.set_attribute("waxell.pipecat.service_name", service_name)
        for key, value in audio_metadata.items():
            span.set_attribute(f"waxell.pipecat.audio.{key}", value)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_stt_result_attributes(span, result, service_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _tts_service_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``TTSService.run`` -- text-to-speech processing."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    service_name = _extract_service_name(instance)
    audio_metadata = _extract_audio_metadata(instance, args, kwargs)

    try:
        span = start_step_span(step_name=f"tts:{service_name}")
        span.set_attribute("waxell.agent.framework", "pipecat")
        span.set_attribute("waxell.pipecat.service_type", "tts")
        span.set_attribute("waxell.pipecat.service_name", service_name)
        for key, value in audio_metadata.items():
            span.set_attribute(f"waxell.pipecat.audio.{key}", value)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_tts_result_attributes(span, result, service_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _process_frame_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``FrameProcessor.process_frame`` -- individual frame processing."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    processor_name = _extract_processor_name(instance)
    frame_type = _extract_frame_type(args)

    try:
        span = start_step_span(step_name=f"processor:{processor_name}")
        span.set_attribute("waxell.agent.framework", "pipecat")
        span.set_attribute("waxell.pipecat.processor_name", processor_name)
        span.set_attribute("waxell.pipecat.frame_type", frame_type)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.pipecat.processor_status", "completed")
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _set_pipeline_result_attributes(span, result, pipeline_name: str) -> None:
    """Set result attributes on the span for pipeline execution."""
    try:
        span.set_attribute("waxell.pipecat.status", "completed")
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"pipecat:pipeline:{pipeline_name}",
                output={"pipeline_name": pipeline_name, "status": "completed"},
            )
    except Exception:
        pass


def _set_stt_result_attributes(span, result, service_name: str) -> None:
    """Set result attributes on the span for STT processing."""
    try:
        # Try to extract transcription text if available
        if result is not None:
            text = ""
            if isinstance(result, str):
                text = result
            elif hasattr(result, "text"):
                text = str(result.text)
            if text:
                span.set_attribute("waxell.pipecat.stt_result_preview", text[:200])
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"pipecat:stt:{service_name}",
                output={"service_name": service_name, "service_type": "stt"},
            )
    except Exception:
        pass


def _set_tts_result_attributes(span, result, service_name: str) -> None:
    """Set result attributes on the span for TTS processing."""
    try:
        span.set_attribute("waxell.pipecat.tts_status", "completed")
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"pipecat:tts:{service_name}",
                output={"service_name": service_name, "service_type": "tts"},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
