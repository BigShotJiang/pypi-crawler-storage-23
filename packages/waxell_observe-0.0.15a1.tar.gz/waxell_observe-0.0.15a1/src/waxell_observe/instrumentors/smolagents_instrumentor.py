"""smolagents auto-instrumentor for waxell-observe.

Monkey-patches ``smolagents.agents.MultiStepAgent.run``,
``smolagents.agents.ToolCallingAgent.run``, and
``smolagents.agents.CodeAgent.run`` to emit OTel spans and record to
the Waxell HTTP API.

HuggingFace smolagents is a lightweight agent framework where agents use
tools and execute code. MultiStepAgent is the base class for both
ToolCallingAgent and CodeAgent.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class SmolAgentsInstrumentor(BaseInstrumentor):
    """Instrumentor for HuggingFace smolagents (``smolagents`` package).

    Patches MultiStepAgent.run (base), ToolCallingAgent.run,
    and CodeAgent.run for agent execution.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import smolagents  # noqa: F401
        except ImportError:
            logger.debug("smolagents not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping smolagents instrumentation")
            return False

        patched = False

        # Patch MultiStepAgent.run (parent of ToolCallingAgent and CodeAgent)
        try:
            wrapt.wrap_function_wrapper(
                "smolagents.agents",
                "MultiStepAgent.run",
                _run_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch MultiStepAgent.run: %s", exc)

        # Patch ToolCallingAgent.run if it overrides the base
        try:
            wrapt.wrap_function_wrapper(
                "smolagents.agents",
                "ToolCallingAgent.run",
                _run_wrapper,
            )
        except Exception:
            pass

        # Patch CodeAgent.run if it overrides the base
        try:
            wrapt.wrap_function_wrapper(
                "smolagents.agents",
                "CodeAgent.run",
                _run_wrapper,
            )
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find smolagents agent methods to patch")
            return False

        self._instrumented = True
        logger.debug("smolagents instrumented (MultiStepAgent.run + subclasses)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from smolagents import agents as agents_mod

            for cls_name in ("MultiStepAgent", "ToolCallingAgent", "CodeAgent"):
                cls = getattr(agents_mod, cls_name, None)
                if cls:
                    run_method = getattr(cls, "run", None)
                    if run_method and hasattr(run_method, "__wrapped__"):
                        cls.run = run_method.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("smolagents uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for smolagents agent ``run`` method.

    Works for MultiStepAgent, ToolCallingAgent, and CodeAgent since
    they all share the same ``run(task)`` signature.
    """
    try:
        from ..tracing.spans import start_agent_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    agent_type = _extract_agent_type(instance)
    agent_name = _extract_agent_name(instance)
    model_name = _extract_model_name(instance)
    tool_names = _extract_tool_names(instance)

    # Extract task from positional args
    task = ""
    try:
        if args:
            task = str(args[0])[:200]
        elif "task" in kwargs:
            task = str(kwargs["task"])[:200]
    except Exception:
        pass

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="smolagents_run",
        )
        span.set_attribute("waxell.smolagents.agent_type", agent_type)
        span.set_attribute("waxell.smolagents.agent_name", agent_name)
        if model_name:
            span.set_attribute("waxell.smolagents.model", model_name)
        if tool_names:
            span.set_attribute("waxell.smolagents.tools", tool_names)
            span.set_attribute("waxell.smolagents.tool_count", len(tool_names))
        if task:
            span.set_attribute("waxell.smolagents.task_preview", task)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, instance, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_agent_type(instance) -> str:
    """Extract the agent type (class name) from a smolagents agent."""
    try:
        return type(instance).__name__
    except Exception:
        return "MultiStepAgent"


def _extract_agent_name(instance) -> str:
    """Extract a usable agent name from a smolagents agent."""
    try:
        name = getattr(instance, "name", None)
        if name:
            return str(name)
    except Exception:
        pass
    try:
        return type(instance).__name__
    except Exception:
        return "smolagents.agent"


def _extract_model_name(instance) -> str:
    """Extract model name from a smolagents agent."""
    try:
        model = getattr(instance, "model", None)
        if model is None:
            return ""
        # smolagents models may have .model_id
        model_id = getattr(model, "model_id", None)
        if model_id:
            return str(model_id)
        # Fallback to string representation
        return str(model)
    except Exception:
        return ""


def _extract_tool_names(instance) -> list:
    """Extract tool names from a smolagents agent."""
    try:
        tools = getattr(instance, "tools", None)
        if not tools:
            return []
        names = []
        if isinstance(tools, dict):
            names = list(tools.keys())[:20]
        elif isinstance(tools, (list, tuple)):
            for t in tools:
                try:
                    name = getattr(t, "name", None) or type(t).__name__
                    names.append(str(name))
                except Exception:
                    pass
            names = names[:20]
        return names
    except Exception:
        return []


def _set_result_attributes(span, result, instance, agent_name: str) -> None:
    """Set result attributes on the span."""
    try:
        # smolagents run() returns a string (the agent's final answer)
        if result is not None:
            result_str = str(result)[:200]
            span.set_attribute("waxell.smolagents.response_preview", result_str)
    except Exception:
        pass

    # Extract step count from instance.logs if available
    try:
        logs = getattr(instance, "logs", None)
        if logs:
            span.set_attribute("waxell.smolagents.step_count", len(logs))
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            result_preview = ""
            try:
                if result is not None:
                    result_preview = str(result)[:500]
            except Exception:
                pass
            ctx.record_step(
                "agent:smolagents.run",
                output={"agent_name": agent_name, "result_preview": result_preview},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
