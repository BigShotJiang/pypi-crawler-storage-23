"""AssemblyAI auto-instrumentor for waxell-observe.

Monkey-patches AssemblyAI SDK methods to emit OTel step spans for
transcription operations:
  - ``Transcriber.transcribe``         -- synchronous transcription
  - ``Transcriber.submit``             -- async submit (non-blocking)
  - ``Transcriber.wait_for_completion``-- poll until transcript is ready

The AssemblyAI Python SDK (``assemblyai``) returns ``Transcript`` objects:
  - ``transcript.text``              -- full transcript text
  - ``transcript.confidence``        -- overall confidence (0.0 - 1.0)
  - ``transcript.words``             -- list of word-level results
  - ``transcript.audio_duration``    -- audio duration in seconds
  - ``transcript.language_code``     -- detected language
  - ``transcript.speech_model``      -- model used (e.g. "best", "nano")
  - ``transcript.audio_url``         -- source audio URL
  - ``transcript.status``            -- "completed", "error", etc.

Cost is tracked externally by AssemblyAI billing, so cost is always 0.0 here.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AssemblyAIInstrumentor(BaseInstrumentor):
    """Instrumentor for the AssemblyAI Python SDK (``assemblyai`` package).

    Patches ``Transcriber.transcribe``, ``Transcriber.submit``, and
    ``Transcriber.wait_for_completion``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import assemblyai  # noqa: F401
        except ImportError:
            logger.debug("assemblyai package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping AssemblyAI instrumentation")
            return False

        patched = False

        # Patch Transcriber.transcribe
        try:
            wrapt.wrap_function_wrapper(
                "assemblyai",
                "Transcriber.transcribe",
                _sync_transcribe_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch AssemblyAI Transcriber.transcribe: %s", exc)

        # Patch Transcriber.submit
        try:
            wrapt.wrap_function_wrapper(
                "assemblyai",
                "Transcriber.submit",
                _sync_submit_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch AssemblyAI Transcriber.submit: %s", exc)

        # Patch Transcriber.wait_for_completion (polls until complete)
        try:
            wrapt.wrap_function_wrapper(
                "assemblyai",
                "Transcript.wait_for_completion",
                _sync_wait_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch AssemblyAI Transcript.wait_for_completion: %s", exc)

        if not patched:
            logger.debug("Could not find any AssemblyAI methods to patch")
            return False

        self._instrumented = True
        logger.debug("AssemblyAI instrumented (transcribe + submit + wait_for_completion)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import assemblyai

            # Uninstrument Transcriber methods
            for attr in ("transcribe", "submit"):
                method = getattr(assemblyai.Transcriber, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(assemblyai.Transcriber, attr, method.__wrapped__)

            # Uninstrument Transcript.wait_for_completion
            method = getattr(assemblyai.Transcript, "wait_for_completion", None)
            if method is not None and hasattr(method, "__wrapped__"):
                setattr(assemblyai.Transcript, "wait_for_completion", method.__wrapped__)
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("AssemblyAI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from AssemblyAI Transcript objects
# ---------------------------------------------------------------------------


def _extract_transcript_data(transcript) -> dict:
    """Extract relevant data from an AssemblyAI Transcript object."""
    data = {
        "text": "",
        "confidence": 0.0,
        "word_count": 0,
        "audio_duration": 0.0,
        "language": "",
        "speech_model": "",
        "audio_url": "",
        "status": "",
    }

    if transcript is None:
        return data

    try:
        data["text"] = getattr(transcript, "text", "") or ""
        data["confidence"] = getattr(transcript, "confidence", 0.0) or 0.0
        data["audio_duration"] = getattr(transcript, "audio_duration", 0.0) or 0.0
        data["language"] = getattr(transcript, "language_code", "") or ""
        data["speech_model"] = getattr(transcript, "speech_model", "") or ""
        data["audio_url"] = getattr(transcript, "audio_url", "") or ""
        data["status"] = getattr(transcript, "status", "") or ""

        # Word count from words list or text split
        words = getattr(transcript, "words", None)
        if words and isinstance(words, list):
            data["word_count"] = len(words)
        elif data["text"]:
            data["word_count"] = len(data["text"].split())
    except Exception:
        pass

    return data


def _extract_audio_source(args, kwargs) -> str:
    """Extract audio source identifier from transcribe/submit args."""
    # Transcriber.transcribe(data) where data can be str (URL/path) or file-like
    source = ""
    if args:
        arg0 = args[0]
        if isinstance(arg0, str):
            source = arg0[:200]
        else:
            source = f"[{type(arg0).__name__}]"

    if not source:
        data = kwargs.get("data", kwargs.get("audio", kwargs.get("audio_url", "")))
        if isinstance(data, str):
            source = data[:200]
        elif data is not None:
            source = f"[{type(data).__name__}]"

    return source


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_transcribe_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for AssemblyAI ``Transcriber.transcribe``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    audio_source = _extract_audio_source(args, kwargs)

    # Extract config for speech_model
    config = kwargs.get("config", None)
    speech_model = ""
    if config is not None:
        speech_model = getattr(config, "speech_model", "") or ""

    try:
        span = start_step_span(step_name="assemblyai.transcribe")
        if audio_source:
            span.set_attribute("waxell.assemblyai.audio_source", audio_source)
        if speech_model:
            span.set_attribute("waxell.assemblyai.speech_model", str(speech_model))
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_transcript_data(response)
            _set_transcript_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set AssemblyAI span attributes: %s", attr_exc)

        try:
            _record_transcribe_call("assemblyai.transcribe", data, latency, audio_source)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_submit_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for AssemblyAI ``Transcriber.submit``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    audio_source = _extract_audio_source(args, kwargs)

    config = kwargs.get("config", None)
    speech_model = ""
    if config is not None:
        speech_model = getattr(config, "speech_model", "") or ""

    try:
        span = start_step_span(step_name="assemblyai.transcribe")
        span.set_attribute("waxell.assemblyai.method", "submit")
        if audio_source:
            span.set_attribute("waxell.assemblyai.audio_source", audio_source)
        if speech_model:
            span.set_attribute("waxell.assemblyai.speech_model", str(speech_model))
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            # Submit returns a Transcript in "queued"/"processing" status
            data = _extract_transcript_data(response)
            span.set_attribute("waxell.assemblyai.status", data["status"])
            span.set_attribute("waxell.assemblyai.latency_ms", round(latency * 1000, 2))
        except Exception as attr_exc:
            logger.debug("Failed to set AssemblyAI submit span attributes: %s", attr_exc)

        try:
            _record_transcribe_call("assemblyai.submit", data, latency, audio_source)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_wait_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for AssemblyAI ``Transcript.wait_for_completion``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="assemblyai.transcribe")
        span.set_attribute("waxell.assemblyai.method", "wait_for_completion")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            # After wait, `instance` is the Transcript itself (it mutates in place)
            # `response` may be the same Transcript or None
            transcript = response if response is not None else instance
            data = _extract_transcript_data(transcript)
            _set_transcript_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set AssemblyAI wait span attributes: %s", attr_exc)

        try:
            transcript = response if response is not None else instance
            data = _extract_transcript_data(transcript)
            _record_transcribe_call("assemblyai.wait_for_completion", data, latency, "")
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_transcript_span_attributes(span, data: dict, latency: float) -> None:
    """Set OTel span attributes from extracted transcript data."""
    if data["speech_model"]:
        span.set_attribute("waxell.assemblyai.speech_model", str(data["speech_model"]))
    if data["language"]:
        span.set_attribute("waxell.assemblyai.language", data["language"])
    if data["audio_duration"]:
        span.set_attribute("waxell.assemblyai.audio_duration", data["audio_duration"])
    if data["text"]:
        span.set_attribute("waxell.assemblyai.transcript_preview", data["text"][:500])
    span.set_attribute("waxell.assemblyai.confidence", data["confidence"])
    span.set_attribute("waxell.assemblyai.word_count", data["word_count"])
    span.set_attribute("waxell.assemblyai.status", str(data["status"]))
    span.set_attribute("waxell.assemblyai.latency_ms", round(latency * 1000, 2))


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_transcribe_call(
    task: str, data: dict, latency: float, audio_source: str
) -> None:
    """Record an AssemblyAI transcription call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    model_name = data.get("speech_model", "") or "assemblyai"

    call_data = {
        "model": str(model_name),
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": audio_source[:500] if audio_source else f"[audio duration={data.get('audio_duration', 0):.1f}s]",
        "response_preview": str(data.get("text", ""))[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
