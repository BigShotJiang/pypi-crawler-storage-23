"""Marvin auto-instrumentor for waxell-observe.

Monkey-patches Marvin's high-level AI functions (``marvin.extract``,
``marvin.classify``, ``marvin.cast``, ``marvin.generate``) and the
``@marvin.fn`` / ``@marvin.ai_fn`` decorated function execution path
to emit OTel spans and record to the Waxell HTTP API.

Marvin provides simple, declarative AI functions that wrap OpenAI under
the hood.  Rather than patching the internal OpenAI call path (which our
OpenAI instrumentor already covers), we capture *Marvin-level* context:
which high-level operation was called, what the function name is, and
a preview of the output.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)

# The high-level Marvin functions to instrument.  Each entry is
# (module_path, attribute_name, operation_label).
_MARVIN_FUNCTIONS = [
    ("marvin", "extract", "marvin.extract"),
    ("marvin", "classify", "marvin.classify"),
    ("marvin", "cast", "marvin.cast"),
    ("marvin", "generate", "marvin.generate"),
]


class MarvinInstrumentor(BaseInstrumentor):
    """Instrumentor for the Marvin AI library (``marvin`` package).

    Patches marvin.extract, marvin.classify, marvin.cast, marvin.generate,
    and the @marvin.fn / @marvin.ai_fn decorator execution path.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import marvin  # noqa: F401
        except ImportError:
            logger.debug("marvin not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Marvin instrumentation")
            return False

        patched = False

        # Patch each high-level function
        for module_path, attr_name, operation_label in _MARVIN_FUNCTIONS:
            try:
                wrapt.wrap_function_wrapper(
                    module_path,
                    attr_name,
                    _make_function_wrapper(operation_label),
                )
                patched = True
            except Exception as exc:
                logger.debug("Failed to patch %s.%s: %s", module_path, attr_name, exc)

        # Patch @marvin.fn / @marvin.ai_fn decorated function call path.
        # In newer Marvin versions the decorator is `marvin.fn`; older
        # versions use `marvin.ai_fn`.  The decorated object is typically a
        # wrapper class whose __call__ invokes the LLM.  We try several
        # known internal locations.
        for module_path, class_attr in [
            ("marvin.components.ai_function", "AIFunction.__call__"),
            ("marvin.ai_functions", "AIFunction.__call__"),
            ("marvin.components.fn", "AIFunction.__call__"),
        ]:
            try:
                wrapt.wrap_function_wrapper(
                    module_path,
                    class_attr,
                    _ai_fn_call_wrapper,
                )
                patched = True
                break  # Only patch once
            except Exception:
                continue

        if not patched:
            logger.debug("Could not find Marvin methods to patch")
            return False

        self._instrumented = True
        logger.debug("Marvin instrumented (extract/classify/cast/generate + ai_fn)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore high-level functions
        try:
            import marvin

            for _module_path, attr_name, _label in _MARVIN_FUNCTIONS:
                fn = getattr(marvin, attr_name, None)
                if fn is not None and hasattr(fn, "__wrapped__"):
                    setattr(marvin, attr_name, fn.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore AIFunction.__call__
        for module_path in [
            "marvin.components.ai_function",
            "marvin.ai_functions",
            "marvin.components.fn",
        ]:
            try:
                import importlib

                mod = importlib.import_module(module_path)
                cls = getattr(mod, "AIFunction", None)
                if cls and hasattr(cls.__call__, "__wrapped__"):
                    cls.__call__ = cls.__call__.__wrapped__
                    break
            except (ImportError, AttributeError):
                continue

        self._instrumented = False
        logger.debug("Marvin uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper factories and functions
# ---------------------------------------------------------------------------


def _make_function_wrapper(operation_label: str):
    """Create a wrapper for a top-level Marvin function (extract/classify/cast/generate)."""

    def _wrapper(wrapped, instance, args, kwargs):
        try:
            from ..tracing.spans import start_step_span
        except Exception:
            return wrapped(*args, **kwargs)

        # Build a prompt preview from the first positional argument (the data/text)
        prompt_preview = ""
        try:
            if args:
                prompt_preview = str(args[0])[:500]
        except Exception:
            pass

        # Try to extract model from kwargs or Marvin settings
        model = _get_marvin_model(kwargs)

        try:
            span = start_step_span(step_name=operation_label)
            span.set_attribute("waxell.marvin.function_name", operation_label)
            span.set_attribute("waxell.marvin.model", model)
            if prompt_preview:
                span.set_attribute("waxell.marvin.prompt_preview", prompt_preview)
        except Exception:
            return wrapped(*args, **kwargs)

        t0 = time.monotonic()
        try:
            result = wrapped(*args, **kwargs)
        except Exception as exc:
            _record_error(span, exc)
            raise
        else:
            try:
                output_preview = str(result)[:500]
                span.set_attribute("waxell.marvin.output_preview", output_preview)
            except Exception:
                pass

            # Record to HTTP path
            try:
                _record_http_marvin(
                    result,
                    model=model,
                    function_name=operation_label,
                    prompt_preview=prompt_preview,
                )
            except Exception:
                pass
            return result
        finally:
            span.end()

    return _wrapper


def _ai_fn_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``AIFunction.__call__`` -- @marvin.fn / @marvin.ai_fn decorated functions."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract the decorated function's name
    function_name = "unknown"
    try:
        func = (
            getattr(instance, "fn", None)
            or getattr(instance, "func", None)
            or getattr(instance, "_func", None)
        )
        if func is not None:
            function_name = getattr(func, "__name__", "unknown")
    except Exception:
        pass

    # Try to get a prompt preview from the function's docstring (Marvin uses it as prompt)
    prompt_preview = ""
    try:
        func = (
            getattr(instance, "fn", None)
            or getattr(instance, "func", None)
            or getattr(instance, "_func", None)
        )
        if func is not None and func.__doc__:
            prompt_preview = func.__doc__[:500]
    except Exception:
        pass

    model = _get_marvin_model(kwargs)

    try:
        span = start_step_span(step_name=f"marvin.ai_fn:{function_name}")
        span.set_attribute("waxell.marvin.function_name", function_name)
        span.set_attribute("waxell.marvin.model", model)
        if prompt_preview:
            span.set_attribute("waxell.marvin.prompt_preview", prompt_preview)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            output_preview = str(result)[:500]
            span.set_attribute("waxell.marvin.output_preview", output_preview)
        except Exception:
            pass

        # Record to HTTP path
        try:
            _record_http_marvin(
                result,
                model=model,
                function_name=f"ai_fn:{function_name}",
                prompt_preview=prompt_preview,
            )
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_marvin_model(kwargs: dict) -> str:
    """Extract the model name from kwargs or Marvin's global settings."""
    # Check explicit kwarg first
    model = kwargs.get("model", None)
    if model:
        return str(model)

    # Fall back to Marvin's settings
    try:
        import marvin

        settings = getattr(marvin, "settings", None)
        if settings:
            # Marvin v2+ stores model in settings.openai.chat.completions.model
            # or settings.llm_model
            model_name = (
                getattr(settings, "llm_model", None)
                or getattr(settings, "default_model", None)
            )
            if model_name:
                return str(model_name)

            # Try nested openai settings
            openai_settings = getattr(settings, "openai", None)
            if openai_settings:
                chat = getattr(openai_settings, "chat", None)
                if chat:
                    completions = getattr(chat, "completions", None)
                    if completions:
                        m = getattr(completions, "model", None)
                        if m:
                            return str(m)
    except Exception:
        pass

    return "unknown"


def _record_http_marvin(
    result,
    model: str,
    function_name: str,
    prompt_preview: str,
) -> None:
    """Record a Marvin call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"marvin:{function_name}",
        "prompt_preview": prompt_preview[:500],
        "response_preview": str(result)[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
