"""Claude Agent SDK auto-instrumentor for waxell-observe.

Attempts to instrument the Anthropic Claude Agent SDK agent execution
entry points. Since this SDK is very new and the API is not fully
stabilized, this is a minimal stub that attempts to patch the primary
agent entry point and returns False if the module is unavailable.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ClaudeAgentsInstrumentor(BaseInstrumentor):
    """Instrumentor for the Claude Agent SDK / Anthropic agent patterns.

    Attempts to patch agent execution entry points. Since this SDK is
    very new, the instrumentor gracefully handles missing or changed APIs.
    """

    _instrumented: bool = False
    _patched_module: str | None = None

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        # Try multiple possible import paths for Claude agent SDK
        agent_module = None
        module_path = None

        for candidate in (
            "claude_agent",
            "anthropic.agent",
            "anthropic.agents",
            "anthropic_agents",
        ):
            try:
                __import__(candidate)
                agent_module = candidate
                module_path = candidate
                break
            except ImportError:
                continue

        if agent_module is None:
            logger.debug("Claude Agent SDK not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Claude Agents instrumentation")
            return False

        import importlib

        mod = importlib.import_module(module_path)
        patched = False

        # Try to find and patch the primary agent class
        # Look for common patterns: Agent.run, Agent.__call__, Runner.run
        for cls_name in ("Agent", "Runner", "AgentRunner"):
            cls = getattr(mod, cls_name, None)
            if cls is None:
                continue

            for method_name in ("run", "run_async", "__call__", "execute"):
                method = getattr(cls, method_name, None)
                if method is None:
                    continue

                try:
                    import asyncio

                    is_async = asyncio.iscoroutinefunction(method)
                    wrapper = _async_agent_wrapper if is_async else _sync_agent_wrapper

                    wrapt.wrap_function_wrapper(
                        module_path,
                        f"{cls_name}.{method_name}",
                        wrapper,
                    )
                    patched = True
                    self._patched_module = module_path
                    logger.debug(
                        "Claude Agents: patched %s.%s.%s",
                        module_path,
                        cls_name,
                        method_name,
                    )
                    break  # Only patch first found method per class
                except Exception as exc:
                    logger.debug(
                        "Failed to patch %s.%s.%s: %s",
                        module_path,
                        cls_name,
                        method_name,
                        exc,
                    )

        if not patched:
            logger.debug("Could not find Claude Agent SDK methods to patch")
            return False

        self._instrumented = True
        logger.debug("Claude Agent SDK instrumented via %s", module_path)
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        if self._patched_module:
            try:
                import importlib

                mod = importlib.import_module(self._patched_module)

                for cls_name in ("Agent", "Runner", "AgentRunner"):
                    cls = getattr(mod, cls_name, None)
                    if cls is None:
                        continue
                    for method_name in ("run", "run_async", "__call__", "execute"):
                        method = getattr(cls, method_name, None)
                        if method and hasattr(method, "__wrapped__"):
                            setattr(cls, method_name, method.__wrapped__)
            except (ImportError, AttributeError):
                pass

        self._instrumented = False
        self._patched_module = None
        logger.debug("Claude Agent SDK uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_agent_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Claude Agent SDK entry points."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = (
        getattr(instance, "name", None)
        or getattr(instance, "agent_name", None)
        or "claude.agent"
    )

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="claude_agent_run",
        )
        span.set_attribute("waxell.claude_agents.agent_name", agent_name)

        # Try to extract model info
        model = getattr(instance, "model", None) or getattr(instance, "model_name", None)
        if model:
            span.set_attribute("waxell.claude_agents.model", str(model))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_result(result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _async_agent_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Claude Agent SDK entry points."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    agent_name = (
        getattr(instance, "name", None)
        or getattr(instance, "agent_name", None)
        or "claude.agent"
    )

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="claude_agent_run",
        )
        span.set_attribute("waxell.claude_agents.agent_name", agent_name)

        model = getattr(instance, "model", None) or getattr(instance, "model_name", None)
        if model:
            span.set_attribute("waxell.claude_agents.model", str(model))
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_result(result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_result(result, agent_name: str) -> None:
    """Record execution result to context."""
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"claude_agent:{agent_name}",
                output={"result_preview": str(result)[:500]},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
