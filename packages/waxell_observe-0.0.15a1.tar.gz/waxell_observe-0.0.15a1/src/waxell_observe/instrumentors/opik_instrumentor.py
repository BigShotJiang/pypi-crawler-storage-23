"""Opik (Comet) auto-instrumentor for waxell-observe.

Monkey-patches ``opik.Opik.trace``, ``opik.Opik.log_traces``, and
evaluation methods to emit step and guardrail spans tracking trace
creation, logging, and evaluation operations.

Opik is an evaluation and tracing platform from Comet that provides
end-to-end LLM application observability. This instrumentor captures
Opik trace and eval operations as Waxell spans.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class OpikInstrumentor(BaseInstrumentor):
    """Instrumentor for Opik (Comet) (``opik`` package).

    Patches ``Opik.trace()``, ``Opik.log_traces()``, and evaluation methods.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import opik  # noqa: F401
        except ImportError:
            logger.debug("opik package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Opik instrumentation")
            return False

        patched = False

        # Patch Opik.trace()
        try:
            wrapt.wrap_function_wrapper(
                "opik",
                "Opik.trace",
                _trace_wrapper,
            )
            patched = True
            logger.debug("Opik.trace patched")
        except Exception as exc:
            logger.debug("Failed to patch Opik.trace: %s", exc)

        # Patch Opik.log_traces()
        try:
            wrapt.wrap_function_wrapper(
                "opik",
                "Opik.log_traces",
                _log_traces_wrapper,
            )
            patched = True
            logger.debug("Opik.log_traces patched")
        except Exception as exc:
            logger.debug("Failed to patch Opik.log_traces: %s", exc)

        # Patch opik.evaluation.evaluate if available
        try:
            wrapt.wrap_function_wrapper(
                "opik.evaluation",
                "evaluate",
                _evaluate_wrapper,
            )
            patched = True
            logger.debug("opik.evaluation.evaluate patched")
        except Exception as exc:
            logger.debug("Failed to patch opik.evaluation.evaluate: %s", exc)

        # Patch Opik.log_scores / feedback
        try:
            wrapt.wrap_function_wrapper(
                "opik",
                "Opik.log_spans_feedback_scores",
                _feedback_wrapper,
            )
            patched = True
            logger.debug("Opik.log_spans_feedback_scores patched")
        except Exception as exc:
            logger.debug("Failed to patch Opik.log_spans_feedback_scores: %s", exc)

        if not patched:
            logger.debug("Could not find any Opik methods to patch")
            return False

        self._instrumented = True
        logger.debug("Opik instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import opik

            for attr in ("trace", "log_traces", "log_spans_feedback_scores"):
                method = getattr(opik.Opik, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(opik.Opik, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        try:
            import opik.evaluation as eval_module

            if hasattr(getattr(eval_module, "evaluate", None), "__wrapped__"):
                eval_module.evaluate = eval_module.evaluate.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Opik uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _trace_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Opik.trace()`` -- trace creation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    trace_name = kwargs.get("name", "") or (args[0] if args else "")
    trace_input = kwargs.get("input", None)
    trace_output = kwargs.get("output", None)
    trace_metadata = kwargs.get("metadata", {})

    try:
        span = start_step_span(step_name=f"opik.trace:{trace_name}" if trace_name else "opik.trace")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "opik")
        span.set_attribute("waxell.opik.operation", "trace")
        if trace_name:
            span.set_attribute("waxell.opik.trace_name", str(trace_name)[:200])
        if trace_input is not None:
            span.set_attribute("waxell.opik.trace_input", str(trace_input)[:500])
        if trace_output is not None:
            span.set_attribute("waxell.opik.trace_output", str(trace_output)[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_opik_trace(trace_name, trace_input, trace_output, trace_metadata)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _log_traces_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Opik.log_traces()`` -- batch trace logging."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    traces = args[0] if args else kwargs.get("traces", [])
    traces_count = len(traces) if isinstance(traces, (list, tuple)) else 0

    try:
        span = start_step_span(step_name="opik.log_traces")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "opik")
        span.set_attribute("waxell.opik.operation", "log_traces")
        span.set_attribute("waxell.opik.traces_count", traces_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        return result
    finally:
        span.end()


def _evaluate_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``opik.evaluation.evaluate`` -- evaluation runs."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    dataset = kwargs.get("dataset", None) or (args[0] if args else None)
    task = kwargs.get("task", None)
    scoring_metrics = kwargs.get("scoring_metrics", [])

    dataset_size = 0
    try:
        if dataset is not None:
            dataset_size = len(dataset)
    except Exception:
        pass

    metrics_count = len(scoring_metrics) if isinstance(scoring_metrics, (list, tuple)) else 0

    try:
        span = start_step_span(step_name="opik.evaluate")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "opik")
        span.set_attribute("waxell.opik.operation", "evaluate")
        span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, dataset_size)
        span.set_attribute(WaxellAttributes.EVAL_METRICS_COUNT, metrics_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_eval_result(span, result, dataset_size, metrics_count)
        except Exception:
            pass

        try:
            _record_http_opik_eval(result, dataset_size, metrics_count)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _feedback_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Opik.log_spans_feedback_scores`` -- feedback/scoring."""
    try:
        from ..tracing.spans import start_guardrail_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    scores = args[0] if args else kwargs.get("scores", [])
    scores_count = len(scores) if isinstance(scores, (list, tuple)) else 0

    try:
        span = start_guardrail_span(
            guardrail_name="opik.feedback",
            framework="opik",
        )
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "opik")
        span.set_attribute("waxell.opik.operation", "feedback")
        span.set_attribute("waxell.opik.scores_count", scores_count)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_eval_result(span, result, dataset_size: int, metrics_count: int) -> None:
    """Extract evaluation results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    try:
        # Opik evaluation results may have scores/metrics
        test_results = getattr(result, "test_results", None)
        if test_results is not None and isinstance(test_results, (list, tuple)):
            passed = 0
            failed = 0
            for tr in test_results:
                score = getattr(tr, "score", None)
                if score is not None and score >= 0.5:
                    passed += 1
                else:
                    failed += 1
            total = passed + failed
            pass_rate = passed / total if total > 0 else 0.0
            span.set_attribute(WaxellAttributes.EVAL_PASSED, passed)
            span.set_attribute("waxell.eval.failed", failed)
            span.set_attribute(WaxellAttributes.EVAL_PASS_RATE, pass_rate)
    except Exception:
        pass


def _record_http_opik_trace(name, trace_input, trace_output, metadata) -> None:
    """Record an Opik trace to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"trace:opik:{name}" if name else "trace:opik",
            output={
                "framework": "opik",
                "trace_name": str(name)[:200] if name else "",
                "input_preview": str(trace_input)[:500] if trace_input else "",
                "output_preview": str(trace_output)[:500] if trace_output else "",
            },
        )


def _record_http_opik_eval(result, dataset_size: int, metrics_count: int) -> None:
    """Record an Opik evaluation to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:opik.evaluate",
            output={
                "framework": "opik",
                "dataset_size": dataset_size,
                "metrics_count": metrics_count,
                "result_preview": str(result)[:500],
            },
        )


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
