"""Ollama auto-instrumentor for waxell-observe.

Monkey-patches ``ollama.Client.chat`` and ``ollama.Client.generate``
(sync), and ``ollama.AsyncClient.chat`` and ``ollama.AsyncClient.generate``
(async) to emit OTel spans and record to the Waxell HTTP API.  Also patches
``ollama.Client.embeddings`` and ``ollama.AsyncClient.embeddings`` (sync +
async) to emit embedding spans.

The Ollama Python SDK returns plain dicts:
  - ``response["model"]``
  - ``response["message"]["role"]`` / ``response["message"]["content"]``
  - ``response["eval_count"]``       — output tokens
  - ``response["prompt_eval_count"]`` — input tokens
  - ``response["done_reason"]``       — finish reason (e.g. "stop")

Embedding responses:
  - ``response["embedding"]``   — single vector (list of floats)
  - ``response["embeddings"]``  — batch vectors (list of list of floats, newer SDK)

Cost is always 0.0 for local inference.

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class OllamaInstrumentor(BaseInstrumentor):
    """Instrumentor for the Ollama Python SDK (``ollama`` package).

    Patches ``Client.chat``, ``Client.generate``, ``Client.embeddings``,
    ``AsyncClient.chat``, ``AsyncClient.generate``, and
    ``AsyncClient.embeddings``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import ollama  # noqa: F401
        except ImportError:
            logger.debug("ollama package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug(
                "wrapt package not installed -- skipping Ollama instrumentation"
            )
            return False

        try:
            wrapt.wrap_function_wrapper(
                "ollama",
                "Client.chat",
                _sync_chat_wrapper,
            )
            wrapt.wrap_function_wrapper(
                "ollama",
                "Client.generate",
                _sync_generate_wrapper,
            )
            wrapt.wrap_function_wrapper(
                "ollama",
                "AsyncClient.chat",
                _async_chat_wrapper,
            )
            wrapt.wrap_function_wrapper(
                "ollama",
                "AsyncClient.generate",
                _async_generate_wrapper,
            )

            # Patch embeddings (sync + async)
            try:
                wrapt.wrap_function_wrapper(
                    "ollama",
                    "Client.embeddings",
                    _sync_embeddings_wrapper,
                )
                wrapt.wrap_function_wrapper(
                    "ollama",
                    "AsyncClient.embeddings",
                    _async_embeddings_wrapper,
                )
                logger.debug("Ollama embeddings instrumented (sync + async)")
            except Exception as emb_exc:
                logger.debug("Could not instrument Ollama embeddings: %s", emb_exc)

            self._instrumented = True
            logger.debug(
                "Ollama Client instrumented (chat + generate + embeddings, sync + async)"
            )
            return True
        except Exception as exc:
            logger.warning(
                "Failed to instrument Ollama SDK (possibly incompatible version): %s",
                exc,
            )
            return False

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import ollama

            for attr in ("chat", "generate", "embeddings"):
                method = getattr(ollama.Client, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(ollama.Client, attr, method.__wrapped__)  # type: ignore[attr-defined]

            for attr in ("chat", "generate", "embeddings"):
                method = getattr(ollama.AsyncClient, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(ollama.AsyncClient, attr, method.__wrapped__)  # type: ignore[attr-defined]
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("Ollama Client uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Ollama response dicts
# ---------------------------------------------------------------------------


def _extract_ollama_data(response, request_model: str) -> dict:
    """Extract model, tokens, cost, and finish reason from an Ollama response.

    Returns a dict with keys: model, tokens_in, tokens_out, cost,
    finish_reason, content.
    """
    # Accept both plain dicts and Pydantic models (e.g. ChatResponse)
    # that expose a dict-like .get() interface.
    if not isinstance(response, dict) and not hasattr(response, "get"):
        return {
            "model": request_model,
            "tokens_in": 0,
            "tokens_out": 0,
            "cost": 0.0,
            "finish_reason": "",
            "content": "",
        }

    model = response.get("model", request_model)
    tokens_in = response.get("prompt_eval_count", 0) or 0
    tokens_out = response.get("eval_count", 0) or 0
    finish_reason = response.get("done_reason", "")

    # Chat response: response["message"]["content"]
    # Generate response: response["response"]
    content = ""
    message = response.get("message")
    if isinstance(message, dict):
        content = message.get("content", "")
    elif not content:
        content = response.get("response", "")

    return {
        "model": model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,  # Local inference is always free
        "finish_reason": finish_reason,
        "content": content,
    }


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_chat_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Ollama ``Client.chat``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []),
            model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    stream = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="ollama")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    # Streaming: wrap the generator so we capture token counts from the final chunk
    if stream and _is_generator(response):
        return _wrap_sync_stream(response, span, model, kwargs, task="chat")

    # Non-streaming: extract data and end span immediately
    try:
        data = _extract_ollama_data(response, model)
        _set_span_attributes(span, data)
    except Exception as attr_exc:
        logger.debug("Failed to set span attributes: %s", attr_exc)

    try:
        _record_http_ollama(response, model, kwargs, task="chat")
    except Exception:
        pass

    span.end()
    return response


def _sync_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Ollama ``Client.generate``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        # generate() uses "prompt" (str), wrap it for the guard
        prompt_text = kwargs.get("prompt", "")
        if prompt_text:
            guard_messages = [{"role": "user", "content": prompt_text}]
        else:
            guard_messages = []
        guard_result = check_prompt(guard_messages, model=kwargs.get("model", ""))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["prompt"] = guard_result.redacted_messages[0]["content"]
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    stream = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="ollama")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    if stream and _is_generator(response):
        return _wrap_sync_stream(response, span, model, kwargs, task="generate")

    try:
        data = _extract_ollama_data(response, model)
        _set_span_attributes(span, data)
    except Exception as attr_exc:
        logger.debug("Failed to set span attributes: %s", attr_exc)

    try:
        _record_http_ollama(response, model, kwargs, task="generate")
    except Exception:
        pass

    span.end()
    return response


async def _async_chat_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Ollama ``AsyncClient.chat``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        guard_result = check_prompt(
            kwargs.get("messages", []),
            model=kwargs.get("model", ""),
        )
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["messages"] = guard_result.redacted_messages
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    stream = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="ollama")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    if stream and _is_async_generator(response):
        return _wrap_async_stream(response, span, model, kwargs, task="chat")

    try:
        data = _extract_ollama_data(response, model)
        _set_span_attributes(span, data)
    except Exception as attr_exc:
        logger.debug("Failed to set span attributes: %s", attr_exc)

    try:
        _record_http_ollama(response, model, kwargs, task="chat")
    except Exception:
        pass

    span.end()
    return response


async def _async_generate_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Ollama ``AsyncClient.generate``."""
    # --- Prompt guard (pre-LLM check) ---
    _guard_error = None
    try:
        from ._guard import check_prompt, PromptGuardError

        prompt_text = kwargs.get("prompt", "")
        if prompt_text:
            guard_messages = [{"role": "user", "content": prompt_text}]
        else:
            guard_messages = []
        guard_result = check_prompt(guard_messages, model=kwargs.get("model", ""))
        if guard_result:
            if not guard_result.passed and guard_result.action == "block":
                _guard_error = PromptGuardError(guard_result)
            elif guard_result.action == "redact" and guard_result.redacted_messages:
                kwargs = dict(kwargs)
                kwargs["prompt"] = guard_result.redacted_messages[0]["content"]
    except Exception:
        pass  # Guard failure never blocks LLM calls
    if _guard_error is not None:
        raise _guard_error

    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")
    stream = kwargs.get("stream", False)

    try:
        span = start_llm_span(model=model, provider_name="ollama")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    if stream and _is_async_generator(response):
        return _wrap_async_stream(response, span, model, kwargs, task="generate")

    try:
        data = _extract_ollama_data(response, model)
        _set_span_attributes(span, data)
    except Exception as attr_exc:
        logger.debug("Failed to set span attributes: %s", attr_exc)

    try:
        _record_http_ollama(response, model, kwargs, task="generate")
    except Exception:
        pass

    span.end()
    return response


# ---------------------------------------------------------------------------
# Embeddings wrappers
# ---------------------------------------------------------------------------


def _sync_embeddings_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Ollama ``Client.embeddings``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    # Count inputs: Ollama accepts "input" (str or list) or "prompt" (str)
    input_data = kwargs.get("input", kwargs.get("prompt", ""))
    if isinstance(input_data, list):
        input_count = len(input_data)
    else:
        input_count = 1

    try:
        span = start_embedding_span(
            model=model, provider_name="ollama", input_count=input_count
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Extract dimensions from response dict
            # Single: response["embedding"] = [0.1, 0.2, ...]
            # Batch:  response["embeddings"] = [[0.1, ...], [0.2, ...]]
            dimensions = 0
            if isinstance(response, dict):
                single = response.get("embedding", [])
                if single and isinstance(single, list):
                    dimensions = len(single)
                elif not single:
                    batch = response.get("embeddings", [])
                    if batch and isinstance(batch, list) and batch[0]:
                        dimensions = len(batch[0])

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, 0)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        try:
            _record_http_ollama_embed(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_embeddings_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for Ollama ``AsyncClient.embeddings``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return await wrapped(*args, **kwargs)

    model = kwargs.get("model", "unknown")

    input_data = kwargs.get("input", kwargs.get("prompt", ""))
    if isinstance(input_data, list):
        input_count = len(input_data)
    else:
        input_count = 1

    try:
        span = start_embedding_span(
            model=model, provider_name="ollama", input_count=input_count
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            dimensions = 0
            if isinstance(response, dict):
                single = response.get("embedding", [])
                if single and isinstance(single, list):
                    dimensions = len(single)
                elif not single:
                    batch = response.get("embeddings", [])
                    if batch and isinstance(batch, list) and batch[0]:
                        dimensions = len(batch[0])

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, 0)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, 0.0)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        try:
            _record_http_ollama_embed(response, model, kwargs)
        except Exception:
            pass

        return response
    finally:
        span.end()


def _record_http_ollama_embed(response, model: str, kwargs: dict) -> None:
    """Record an Ollama embedding call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "ollama.embeddings",
        "prompt_preview": f"[{model} embedding]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Streaming helpers
# ---------------------------------------------------------------------------


def _is_generator(obj) -> bool:
    """Check if obj is a sync generator/iterator (Ollama streaming response)."""
    import types

    return isinstance(obj, (types.GeneratorType,)) or (
        hasattr(obj, "__iter__")
        and hasattr(obj, "__next__")
        and not isinstance(obj, (dict, list, str, bytes))
    )


def _is_async_generator(obj) -> bool:
    """Check if obj is an async generator/iterator."""
    import types

    return isinstance(obj, types.AsyncGeneratorType) or (
        hasattr(obj, "__aiter__") and hasattr(obj, "__anext__")
    )


def _wrap_sync_stream(stream, span, model: str, kwargs: dict, task: str = "chat"):
    """Wrap a sync streaming response to capture token counts from the final chunk."""
    last_chunk = None
    try:
        for chunk in stream:
            last_chunk = chunk
            yield chunk
    except Exception as exc:
        _record_error(span, exc)
        raise
    finally:
        # The final chunk in Ollama streams contains eval_count and prompt_eval_count
        try:
            if last_chunk is not None and isinstance(last_chunk, dict):
                data = _extract_ollama_data(last_chunk, model)
                _set_span_attributes(span, data)
                _record_http_ollama(last_chunk, model, kwargs, task=task)
        except Exception:
            pass
        span.end()


async def _wrap_async_stream(
    stream, span, model: str, kwargs: dict, task: str = "chat"
):
    """Wrap an async streaming response to capture token counts from the final chunk."""
    last_chunk = None
    try:
        async for chunk in stream:
            last_chunk = chunk
            yield chunk
    except Exception as exc:
        _record_error(span, exc)
        raise
    finally:
        try:
            if last_chunk is not None and isinstance(last_chunk, dict):
                data = _extract_ollama_data(last_chunk, model)
                _set_span_attributes(span, data)
                _record_http_ollama(last_chunk, model, kwargs, task=task)
        except Exception:
            pass
        span.end()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _set_span_attributes(span, data: dict) -> None:
    """Set OTel span attributes from extracted Ollama data."""
    from ..tracing.attributes import GenAIAttributes, WaxellAttributes

    span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, data["tokens_in"])
    span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, data["tokens_out"])
    span.set_attribute(GenAIAttributes.RESPONSE_MODEL, data["model"])
    if data["finish_reason"]:
        span.set_attribute(
            GenAIAttributes.RESPONSE_FINISH_REASONS, [data["finish_reason"]]
        )
    span.set_attribute(WaxellAttributes.LLM_MODEL, data["model"])
    span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, data["tokens_in"])
    span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, data["tokens_out"])
    span.set_attribute(
        WaxellAttributes.LLM_TOTAL_TOKENS,
        data["tokens_in"] + data["tokens_out"],
    )
    span.set_attribute(WaxellAttributes.LLM_COST, 0.0)


def _record_http_ollama(
    response, request_model: str, kwargs: dict, task: str = "chat"
) -> None:
    """Record an Ollama LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    data = _extract_ollama_data(response, request_model)

    # Extract prompt preview
    prompt_preview = ""
    messages = kwargs.get("messages", [])
    if messages and isinstance(messages, list):
        first = messages[0]
        if isinstance(first, dict):
            prompt_preview = str(first.get("content", ""))[:500]
    elif not prompt_preview:
        prompt_text = kwargs.get("prompt", "")
        if prompt_text:
            prompt_preview = str(prompt_text)[:500]

    call_data = {
        "model": data["model"],
        "tokens_in": data["tokens_in"],
        "tokens_out": data["tokens_out"],
        "cost": 0.0,
        "task": f"ollama.{task}",
        "prompt_preview": prompt_preview,
        "response_preview": str(data["content"])[:500] if data["content"] else "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
