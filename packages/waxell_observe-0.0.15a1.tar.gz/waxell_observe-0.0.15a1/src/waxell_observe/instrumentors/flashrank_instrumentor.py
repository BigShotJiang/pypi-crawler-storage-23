"""FlashRank auto-instrumentor for waxell-observe.

Monkey-patches ``flashrank.Ranker.rerank`` to emit tool spans tracking
local reranking operations via FlashRank.

FlashRank is a lightweight, local reranker that does not require API calls.
Models include ms-marco-MultiBERT-L-12, ms-marco-MiniLM-L-12-v2, rank-T5-flan.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class FlashRankInstrumentor(BaseInstrumentor):
    """Instrumentor for the FlashRank reranker (``flashrank`` package).

    Patches ``Ranker.rerank`` to emit tool spans for reranking operations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import flashrank  # noqa: F401
        except ImportError:
            logger.debug("flashrank package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping FlashRank instrumentation")
            return False

        patched = False

        # Ranker.rerank (sync only -- FlashRank is local, no async)
        try:
            wrapt.wrap_function_wrapper(
                "flashrank",
                "Ranker.rerank",
                _sync_rerank_wrapper,
            )
            patched = True
            logger.debug("FlashRank Ranker.rerank patched")
        except Exception as exc:
            logger.debug("Could not patch flashrank Ranker.rerank: %s", exc)

        if not patched:
            logger.debug("Could not find FlashRank rerank methods to patch")
            return False

        self._instrumented = True
        logger.debug("FlashRank instrumented (Ranker.rerank)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import flashrank

            cls = getattr(flashrank, "Ranker", None)
            if cls is not None:
                method = getattr(cls, "rerank", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    cls.rerank = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("FlashRank uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_model_name(instance) -> str:
    """Extract the model name from a Ranker instance."""
    model = getattr(instance, "model_name", None)
    if model:
        return str(model)
    model = getattr(instance, "model", None)
    if model:
        return str(model)
    return "unknown"


def _extract_passages(request) -> list:
    """Extract the passages list from a RerankRequest."""
    passages = getattr(request, "passages", None)
    if passages is not None and isinstance(passages, list):
        return passages
    return []


def _extract_query(request) -> str:
    """Extract the query string from a RerankRequest."""
    query = getattr(request, "query", None)
    if query is not None:
        return str(query)
    return ""


def _extract_top_score(results) -> float | None:
    """Extract the top relevance score from FlashRank results."""
    if not results:
        return None
    first = results[0]
    score = getattr(first, "score", None)
    if score is not None:
        return float(score)
    if isinstance(first, dict):
        score = first.get("score")
        if score is not None:
            return float(score)
    return None


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_rerank_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``flashrank.Ranker.rerank``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract request from args/kwargs
    request = args[0] if args else kwargs.get("request", None)

    model_name = _extract_model_name(instance)
    query = _extract_query(request) if request else ""
    passages = _extract_passages(request) if request else []
    num_passages = len(passages)

    try:
        span = start_tool_span(tool_name="flashrank.rerank", tool_type="reranker")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results = result if isinstance(result, list) else []
            num_results = len(results)
            top_score = _extract_top_score(results)

            span.set_attribute("waxell.rerank.system", "flashrank")
            span.set_attribute("waxell.rerank.model", model_name)
            span.set_attribute("waxell.rerank.query", str(query)[:200])
            span.set_attribute("waxell.rerank.num_passages", num_passages)
            span.set_attribute("waxell.rerank.num_results", num_results)
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set FlashRank rerank span attributes: %s", attr_exc)

        try:
            _record_http_flashrank_rerank(
                model=model_name,
                query=query,
                num_passages=num_passages,
                num_results=num_results if 'num_results' in dir() else 0,
                top_score=top_score if 'top_score' in dir() else None,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_flashrank_rerank(
    model: str,
    query: str,
    num_passages: int = 0,
    num_results: int = 0,
    top_score: float | None = None,
) -> None:
    """Record a FlashRank rerank call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    score_str = f", top_score={top_score:.3f}" if top_score is not None else ""
    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "rerank:flashrank",
        "prompt_preview": f"rerank query: {query[:200]}",
        "response_preview": f"{num_results} result(s) from {num_passages} passage(s){score_str}",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
