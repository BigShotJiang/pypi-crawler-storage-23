"""RAGAS auto-instrumentor for waxell-observe.

Monkey-patches ``ragas.evaluate`` to emit evaluation spans tracking
metric scores, pass rates, and test case counts.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class RagasInstrumentor(BaseInstrumentor):
    """Instrumentor for the RAGAS evaluation framework (``ragas`` package).

    Patches ragas.evaluate() to track RAG evaluation metrics.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import ragas  # noqa: F401
        except ImportError:
            logger.debug("ragas not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping RAGAS instrumentation")
            return False

        patched = False

        # Patch ragas.evaluate (top-level evaluation entry point)
        try:
            wrapt.wrap_function_wrapper(
                "ragas",
                "evaluate",
                _evaluate_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch ragas.evaluate: %s", exc)

        # Try alternate import path for ragas.evaluation
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "ragas.evaluation",
                    "evaluate",
                    _evaluate_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Failed to patch ragas.evaluation.evaluate: %s", exc)

        if not patched:
            logger.debug("Could not find RAGAS methods to patch")
            return False

        self._instrumented = True
        logger.debug("RAGAS instrumented (evaluate)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import ragas

            if hasattr(ragas.evaluate, "__wrapped__"):
                ragas.evaluate = ragas.evaluate.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from ragas import evaluation

            if hasattr(evaluation.evaluate, "__wrapped__"):
                evaluation.evaluate = evaluation.evaluate.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("RAGAS uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _evaluate_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``ragas.evaluate`` -- top-level RAG evaluation."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract dataset and metrics from args/kwargs
    dataset = None
    metrics = []
    try:
        if args:
            dataset = args[0] if len(args) > 0 else None
            metrics = args[1] if len(args) > 1 else kwargs.get("metrics", [])
        else:
            dataset = kwargs.get("dataset", None)
            metrics = kwargs.get("metrics", [])
    except Exception:
        pass

    test_cases_count = 0
    metrics_count = 0
    metric_names: list[str] = []
    try:
        if dataset is not None:
            test_cases_count = len(dataset)
    except Exception:
        pass
    try:
        if metrics:
            metrics_count = len(metrics)
            for m in metrics:
                try:
                    name = getattr(m, "name", None) or type(m).__name__
                    metric_names.append(str(name))
                except Exception:
                    pass
    except Exception:
        pass

    try:
        span = start_step_span(step_name="ragas.evaluate")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "ragas")
        span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, test_cases_count)
        span.set_attribute(WaxellAttributes.EVAL_METRICS_COUNT, metrics_count)
        if metric_names:
            span.set_attribute("waxell.eval.metric_names", ",".join(metric_names))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_eval_result(span, result, test_cases_count, metric_names)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_eval_result(span, result, test_cases_count: int,
                        metric_names: list[str]) -> None:
    """Extract RAGAS evaluation results and set span attributes.

    RAGAS EvaluationResult supports:
    - result.scores: list of per-sample score dicts
    - result.to_pandas(): DataFrame with metric columns
    - result[metric_name]: aggregate score for a metric
    - dict-like access for aggregate scores
    """
    from ..tracing.attributes import WaxellAttributes

    scores: dict[str, float] = {}
    overall_score = None

    # Strategy 1: Try dict-like access for aggregate scores
    try:
        if hasattr(result, "__getitem__"):
            for name in metric_names:
                try:
                    val = result[name]
                    if val is not None:
                        scores[name] = float(val)
                except (KeyError, TypeError, ValueError):
                    pass
    except Exception:
        pass

    # Strategy 2: Try result.scores (list of per-row dicts)
    if not scores:
        try:
            result_scores = getattr(result, "scores", None)
            if result_scores and isinstance(result_scores, list):
                # Aggregate mean scores per metric
                from collections import defaultdict
                metric_sums: dict[str, float] = defaultdict(float)
                metric_counts: dict[str, int] = defaultdict(int)
                for row in result_scores:
                    if isinstance(row, dict):
                        for key, val in row.items():
                            try:
                                metric_sums[key] += float(val)
                                metric_counts[key] += 1
                            except (TypeError, ValueError):
                                pass
                for key in metric_sums:
                    if metric_counts[key] > 0:
                        scores[key] = metric_sums[key] / metric_counts[key]
        except Exception:
            pass

    # Strategy 3: Try to_pandas() as fallback
    if not scores:
        try:
            to_pandas = getattr(result, "to_pandas", None)
            if callable(to_pandas):
                df = to_pandas()
                for col in df.columns:
                    try:
                        mean_val = df[col].mean()
                        if mean_val is not None:
                            scores[str(col)] = float(mean_val)
                    except Exception:
                        pass
        except Exception:
            pass

    # Compute overall score (mean of all metric scores)
    try:
        if scores:
            overall_score = sum(scores.values()) / len(scores)
    except Exception:
        pass

    # Set span attributes
    try:
        if overall_score is not None:
            span.set_attribute(WaxellAttributes.EVAL_SCORE, overall_score)
        if scores:
            # Store individual metric scores as a comma-separated summary
            score_summary = ", ".join(
                f"{k}={v:.3f}" for k, v in scores.items()
            )
            span.set_attribute("waxell.eval.metric_scores", score_summary)

        # Determine pass rate based on a threshold (scores >= 0.5 are "passing")
        if scores:
            passing = sum(1 for v in scores.values() if v >= 0.5)
            total = len(scores)
            pass_rate = passing / total if total > 0 else 0.0
            span.set_attribute(WaxellAttributes.EVAL_PASS_RATE, pass_rate)
            span.set_attribute(WaxellAttributes.EVAL_PASSED, passing)
            span.set_attribute("waxell.eval.failed", total - passing)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_eval(result, scores, overall_score, test_cases_count,
                          metric_names)
    except Exception:
        pass


def _record_http_eval(result, scores: dict[str, float],
                      overall_score: float | None, test_cases_count: int,
                      metric_names: list[str]) -> None:
    """Record a RAGAS evaluation to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:ragas.evaluate",
            output={
                "framework": "ragas",
                "test_cases_count": test_cases_count,
                "metric_names": metric_names,
                "scores": scores,
                "overall_score": overall_score,
                "result_preview": str(result)[:500],
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
