"""Magentic auto-instrumentor for waxell-observe.

Monkey-patches ``magentic.prompt_function.PromptFunction.__call__`` and
``magentic.chat_model.base.ChatModel.complete`` to emit OTel spans and
record to the Waxell HTTP API.

Magentic uses decorators (@prompt, @chatprompt) that compile decorated
functions into PromptFunction objects.  When called, these objects build
a prompt and delegate to the configured ChatModel.  We instrument both
layers so that users get framework-level context (function name, prompt
preview) alongside the underlying completion call.

Because magentic wraps underlying providers (OpenAI, Anthropic, etc.),
our spans capture *framework* context only -- the underlying provider
instrumentor handles raw LLM telemetry.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MagenticInstrumentor(BaseInstrumentor):
    """Instrumentor for the Magentic framework (``magentic`` package).

    Patches PromptFunction.__call__ and ChatModel.complete.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import magentic  # noqa: F401
        except ImportError:
            logger.debug("magentic not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Magentic instrumentation")
            return False

        patched = False

        # Patch PromptFunction.__call__ (decorated function execution)
        try:
            wrapt.wrap_function_wrapper(
                "magentic.prompt_function",
                "PromptFunction.__call__",
                _prompt_function_call_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch PromptFunction.__call__: %s", exc)

        # Patch ChatModel.complete (underlying model completion)
        try:
            wrapt.wrap_function_wrapper(
                "magentic.chat_model.base",
                "ChatModel.complete",
                _chat_model_complete_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch ChatModel.complete: %s", exc)

        if not patched:
            logger.debug("Could not find Magentic methods to patch")
            return False

        self._instrumented = True
        logger.debug("Magentic instrumented (PromptFunction.__call__ + ChatModel.complete)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from magentic.prompt_function import PromptFunction

            if hasattr(PromptFunction.__call__, "__wrapped__"):
                PromptFunction.__call__ = PromptFunction.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            from magentic.chat_model.base import ChatModel

            if hasattr(ChatModel.complete, "__wrapped__"):
                ChatModel.complete = ChatModel.complete.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Magentic uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _prompt_function_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``PromptFunction.__call__`` -- magentic decorated function."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract function name from the PromptFunction instance
    function_name = "unknown"
    try:
        func = getattr(instance, "_func", None) or getattr(instance, "func", None)
        if func is not None:
            function_name = getattr(func, "__name__", "unknown")
    except Exception:
        pass

    # Try to extract model name from the instance
    model_name = "magentic"
    try:
        model = getattr(instance, "_model", None) or getattr(instance, "model", None)
        if model is not None:
            model_name = (
                getattr(model, "model", None)
                or getattr(model, "model_name", None)
                or str(type(model).__name__)
            )
    except Exception:
        pass

    # Try to build a prompt preview from the template and args
    prompt_preview = ""
    try:
        template = getattr(instance, "_template", None) or getattr(instance, "template", None)
        if template:
            prompt_preview = str(template)[:500]
    except Exception:
        pass

    try:
        span = start_llm_span(model=str(model_name), provider_name="magentic")
        span.set_attribute("waxell.magentic.function_name", function_name)
        span.set_attribute("waxell.magentic.model", str(model_name))
        if prompt_preview:
            span.set_attribute("waxell.magentic.prompt_preview", prompt_preview)
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            output_preview = str(result)[:500]
            span.set_attribute("waxell.magentic.output_preview", output_preview)
        except Exception:
            pass

        # Record to HTTP path
        try:
            _record_http_magentic(
                result,
                model=str(model_name),
                function_name=function_name,
                latency_ms=(time.monotonic() - t0) * 1000,
            )
        except Exception:
            pass
        return result
    finally:
        span.end()


def _chat_model_complete_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``ChatModel.complete`` -- underlying model call."""
    try:
        from ..tracing.spans import start_llm_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract model info from the ChatModel instance
    model_name = "magentic"
    try:
        model_name = (
            getattr(instance, "model", None)
            or getattr(instance, "model_name", None)
            or str(type(instance).__name__)
        )
    except Exception:
        pass

    try:
        span = start_llm_span(model=str(model_name), provider_name="magentic")
        span.set_attribute("waxell.magentic.model", str(model_name))
        span.set_attribute("waxell.magentic.chat_model_class", type(instance).__name__)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            output_preview = str(result)[:500]
            span.set_attribute("waxell.magentic.output_preview", output_preview)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_http_magentic(
    result,
    model: str,
    function_name: str,
    latency_ms: float,
) -> None:
    """Record a Magentic call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": f"magentic.prompt:{function_name}",
        "prompt_preview": "",
        "response_preview": str(result)[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
