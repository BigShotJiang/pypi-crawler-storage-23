"""LMQL auto-instrumentor for waxell-observe.

Monkey-patches ``lmql.run`` (the primary execution entry point) to emit
OTel spans and record to the Waxell HTTP API.

LMQL is a query language for LLMs that supports constrained decoding,
scripted prompting, and multi-model orchestration.  The main public API
is ``lmql.run(query_string, **kwargs)`` and the ``@lmql.query`` decorator
which produces callables that ultimately go through the same execution
engine.

Because LMQL's internals are specialised and can change between versions,
this instrumentor takes a minimal approach: we wrap ``lmql.run`` (the
common execution path) and, where possible, the ``__call__`` method of
the object returned by ``@lmql.query``.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class LMQLInstrumentor(BaseInstrumentor):
    """Instrumentor for the LMQL framework (``lmql`` package).

    Patches lmql.run and the LMQLQueryFunction.__call__ path.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import lmql  # noqa: F401
        except ImportError:
            logger.debug("lmql not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping LMQL instrumentation")
            return False

        patched = False

        # Patch lmql.run (main execution entry point)
        try:
            wrapt.wrap_function_wrapper(
                "lmql",
                "run",
                _lmql_run_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch lmql.run: %s", exc)

        # Patch @lmql.query decorated functions
        # The decorator returns an LMQLQueryFunction whose __call__ is the
        # execution path.  The class may live in different submodules across
        # versions, so we try several known locations.
        for module_path, class_attr in [
            ("lmql.runtime.query", "LMQLQueryFunction.__call__"),
            ("lmql.api.queries", "LMQLQueryFunction.__call__"),
            ("lmql", "LMQLQueryFunction.__call__"),
        ]:
            try:
                wrapt.wrap_function_wrapper(
                    module_path,
                    class_attr,
                    _lmql_query_call_wrapper,
                )
                patched = True
                break  # Only patch once
            except Exception:
                continue

        if not patched:
            logger.debug("Could not find LMQL methods to patch")
            return False

        self._instrumented = True
        logger.debug("LMQL instrumented (lmql.run)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import lmql

            if hasattr(lmql.run, "__wrapped__"):
                lmql.run = lmql.run.__wrapped__
        except (ImportError, AttributeError):
            pass

        # Try to restore LMQLQueryFunction.__call__
        for module_path in [
            "lmql.runtime.query",
            "lmql.api.queries",
            "lmql",
        ]:
            try:
                import importlib

                mod = importlib.import_module(module_path)
                cls = getattr(mod, "LMQLQueryFunction", None)
                if cls and hasattr(cls.__call__, "__wrapped__"):
                    cls.__call__ = cls.__call__.__wrapped__
                    break
            except (ImportError, AttributeError):
                continue

        self._instrumented = False
        logger.debug("LMQL uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _lmql_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``lmql.run`` -- primary LMQL execution entry point."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract query preview from first positional arg (the query string)
    query_preview = ""
    try:
        if args:
            query_preview = str(args[0])[:500]
    except Exception:
        pass

    # Extract model from kwargs
    model = kwargs.get("model", "unknown")
    if model is None:
        model = "unknown"

    try:
        span = start_step_span(step_name="lmql.run")
        if query_preview:
            span.set_attribute("waxell.lmql.query_preview", query_preview)
        span.set_attribute("waxell.lmql.model", str(model))
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency_ms = (time.monotonic() - t0) * 1000
        try:
            output_preview = str(result)[:500]
            span.set_attribute("waxell.lmql.output_preview", output_preview)
            span.set_attribute("waxell.lmql.latency_ms", latency_ms)
        except Exception:
            pass

        # Record to HTTP path
        try:
            _record_http_lmql(
                result,
                model=str(model),
                query_preview=query_preview,
                latency_ms=latency_ms,
            )
        except Exception:
            pass
        return result
    finally:
        span.end()


def _lmql_query_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``LMQLQueryFunction.__call__`` -- @lmql.query decorated functions."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract the query function name
    function_name = "unknown"
    try:
        func = getattr(instance, "fct", None) or getattr(instance, "query_fct", None)
        if func is not None:
            function_name = getattr(func, "__name__", "unknown")
    except Exception:
        pass

    # Try to get model from instance
    model = "unknown"
    try:
        model = (
            getattr(instance, "model", None)
            or getattr(instance, "default_model", None)
            or "unknown"
        )
    except Exception:
        pass

    try:
        span = start_step_span(step_name=f"lmql.query:{function_name}")
        span.set_attribute("waxell.lmql.query_preview", f"@lmql.query {function_name}")
        span.set_attribute("waxell.lmql.model", str(model))
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency_ms = (time.monotonic() - t0) * 1000
        try:
            output_preview = str(result)[:500]
            span.set_attribute("waxell.lmql.output_preview", output_preview)
            span.set_attribute("waxell.lmql.latency_ms", latency_ms)
        except Exception:
            pass

        # Record to HTTP path
        try:
            _record_http_lmql(
                result,
                model=str(model),
                query_preview=f"@lmql.query {function_name}",
                latency_ms=latency_ms,
            )
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_http_lmql(
    result,
    model: str,
    query_preview: str,
    latency_ms: float,
) -> None:
    """Record an LMQL call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "lmql.query",
        "prompt_preview": query_preview[:500],
        "response_preview": str(result)[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
