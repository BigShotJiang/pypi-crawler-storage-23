"""Shared ContextVar for the current WaxellContext.

This module exists to break circular imports: both ``context.py`` (which
defines WaxellContext) and the instrumentor wrappers need access to the
same ContextVar, but the instrumentors must not import ``context.py``
at module level (that would create a dependency cycle).

The typing import is guarded by TYPE_CHECKING so the ``WaxellContext``
type is only resolved by static analysis tools, never at runtime.
"""

from __future__ import annotations

from contextvars import ContextVar
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..context import WaxellContext

_current_context: ContextVar[Optional["WaxellContext"]] = ContextVar(
    "waxell_current_context", default=None
)
