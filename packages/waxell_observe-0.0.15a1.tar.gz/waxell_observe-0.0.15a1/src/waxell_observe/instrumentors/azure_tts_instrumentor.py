"""Azure Cognitive Services Speech (TTS) auto-instrumentor for waxell-observe.

Monkey-patches Azure Speech SDK methods to emit OTel step spans for
text-to-speech operations:
  - ``SpeechSynthesizer.speak_text``       -- sync
  - ``SpeechSynthesizer.speak_text_async``  -- returns Future
  - ``SpeechSynthesizer.speak_ssml``        -- sync
  - ``SpeechSynthesizer.speak_ssml_async``  -- returns Future

The Azure Speech SDK (``azure-cognitiveservices-speech``) returns a
``SpeechSynthesisResult`` with:
  - ``reason`` (ResultReason) -- e.g. SynthesizingAudioCompleted
  - ``audio_duration`` (timedelta) -- duration of synthesized audio

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AzureTTSInstrumentor(BaseInstrumentor):
    """Instrumentor for the Azure Cognitive Services Speech SDK.

    Patches ``SpeechSynthesizer.speak_text``, ``speak_text_async``,
    ``speak_ssml``, and ``speak_ssml_async``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import azure.cognitiveservices.speech  # noqa: F401
        except ImportError:
            logger.debug("azure-cognitiveservices-speech package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Azure TTS instrumentation")
            return False

        patched = False

        # Patch speak_text (sync)
        try:
            wrapt.wrap_function_wrapper(
                "azure.cognitiveservices.speech",
                "SpeechSynthesizer.speak_text",
                _sync_speak_text_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Azure TTS speak_text: %s", exc)

        # Patch speak_text_async (returns Future)
        try:
            wrapt.wrap_function_wrapper(
                "azure.cognitiveservices.speech",
                "SpeechSynthesizer.speak_text_async",
                _async_speak_text_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Azure TTS speak_text_async: %s", exc)

        # Patch speak_ssml (sync)
        try:
            wrapt.wrap_function_wrapper(
                "azure.cognitiveservices.speech",
                "SpeechSynthesizer.speak_ssml",
                _sync_speak_ssml_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Azure TTS speak_ssml: %s", exc)

        # Patch speak_ssml_async (returns Future)
        try:
            wrapt.wrap_function_wrapper(
                "azure.cognitiveservices.speech",
                "SpeechSynthesizer.speak_ssml_async",
                _async_speak_ssml_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Azure TTS speak_ssml_async: %s", exc)

        if not patched:
            logger.debug("Could not find any Azure TTS methods to patch")
            return False

        self._instrumented = True
        logger.debug(
            "Azure TTS instrumented (speak_text + speak_ssml, sync + async)"
        )
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import azure.cognitiveservices.speech as speech_module

            cls = getattr(speech_module, "SpeechSynthesizer", None)
            if cls is not None:
                for attr in ("speak_text", "speak_text_async", "speak_ssml", "speak_ssml_async"):
                    method = getattr(cls, attr, None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        setattr(cls, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Azure TTS uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_speak_text_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Azure ``SpeechSynthesizer.speak_text``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    text = _extract_text_arg(args, kwargs)
    text_length = len(text) if text else 0

    try:
        span = start_step_span(step_name="azure.tts.speak")
        _set_request_attrs(span, text_length, method="speak_text")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            _set_response_attrs(span, result, latency)
        except Exception:
            pass

        try:
            _record_tts_call("azure.tts.speak_text", text_length, result, latency)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _async_speak_text_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for Azure ``SpeechSynthesizer.speak_text_async`` (returns Future).

    The Azure SDK's ``speak_text_async`` returns a ``ResultFuture``, not a
    Python coroutine. We wrap the future's ``.get()`` to capture timing.
    """
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    text = _extract_text_arg(args, kwargs)
    text_length = len(text) if text else 0

    try:
        span = start_step_span(step_name="azure.tts.speak")
        _set_request_attrs(span, text_length, method="speak_text_async")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        future = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    # Wrap the future's .get() to capture result and end span
    try:
        _wrap_future(future, span, t0, text_length, "azure.tts.speak_text_async")
    except Exception:
        # If wrapping fails, end span immediately to avoid leaks
        try:
            span.end()
        except Exception:
            pass

    return future


def _sync_speak_ssml_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Azure ``SpeechSynthesizer.speak_ssml``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    ssml = _extract_text_arg(args, kwargs)
    text_length = len(ssml) if ssml else 0

    try:
        span = start_step_span(step_name="azure.tts.speak")
        _set_request_attrs(span, text_length, method="speak_ssml")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            _set_response_attrs(span, result, latency)
        except Exception:
            pass

        try:
            _record_tts_call("azure.tts.speak_ssml", text_length, result, latency)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _async_speak_ssml_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for Azure ``SpeechSynthesizer.speak_ssml_async`` (returns Future)."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    ssml = _extract_text_arg(args, kwargs)
    text_length = len(ssml) if ssml else 0

    try:
        span = start_step_span(step_name="azure.tts.speak")
        _set_request_attrs(span, text_length, method="speak_ssml_async")
    except Exception:
        return wrapped(*args, **kwargs)

    t0 = time.monotonic()
    try:
        future = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        span.end()
        raise

    # Wrap the future's .get() to capture result and end span
    try:
        _wrap_future(future, span, t0, text_length, "azure.tts.speak_ssml_async")
    except Exception:
        try:
            span.end()
        except Exception:
            pass

    return future


# ---------------------------------------------------------------------------
# Future wrapping for async methods
# ---------------------------------------------------------------------------


def _wrap_future(future, span, t0: float, text_length: int, task: str) -> None:
    """Wrap an Azure ResultFuture's .get() to capture timing and result.

    The Azure Speech SDK's async methods return a ``ResultFuture`` object
    (not a Python coroutine). The actual result is obtained by calling
    ``future.get()``. We monkey-patch ``.get()`` to capture the result.
    """
    original_get = future.get

    def patched_get(*a, **kw):
        try:
            result = original_get(*a, **kw)
        except Exception as exc:
            _record_error(span, exc)
            span.end()
            raise
        else:
            latency = time.monotonic() - t0
            try:
                _set_response_attrs(span, result, latency)
            except Exception:
                pass

            try:
                _record_tts_call(task, text_length, result, latency)
            except Exception:
                pass

            return result
        finally:
            try:
                span.end()
            except Exception:
                pass

    try:
        future.get = patched_get
    except Exception:
        # Some futures may not allow attribute assignment
        span.end()


# ---------------------------------------------------------------------------
# Parameter extraction helpers
# ---------------------------------------------------------------------------


def _extract_text_arg(args, kwargs) -> str:
    """Extract the text/ssml string from speak_text/speak_ssml args.

    Both ``speak_text`` and ``speak_ssml`` take a single positional string arg:
      speak_text(text: str)
      speak_ssml(ssml: str)
    """
    text = ""
    try:
        if args:
            text = str(args[0]) if args[0] else ""
        if not text:
            text = kwargs.get("text", "") or kwargs.get("ssml", "")
    except Exception:
        pass
    return str(text)


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_request_attrs(span, text_length: int, method: str = "") -> None:
    """Set request attributes for an Azure TTS span."""
    if text_length:
        span.set_attribute("waxell.azure_tts.text_length", text_length)
    if method:
        span.set_attribute("waxell.azure_tts.method", method)


def _set_response_attrs(span, result, latency: float) -> None:
    """Set response attributes from an Azure SpeechSynthesisResult."""
    span.set_attribute("waxell.azure_tts.latency_ms", round(latency * 1000, 2))

    if result is None:
        return

    # Extract reason (e.g. SynthesizingAudioCompleted)
    try:
        reason = getattr(result, "reason", None)
        if reason is not None:
            # reason is an enum -- get its name
            reason_str = str(getattr(reason, "name", reason))
            span.set_attribute("waxell.azure_tts.reason", reason_str)
    except Exception:
        pass

    # Extract audio duration
    try:
        audio_duration = getattr(result, "audio_duration", None)
        if audio_duration is not None:
            # audio_duration is a timedelta
            duration_ms = audio_duration.total_seconds() * 1000
            span.set_attribute("waxell.azure_tts.audio_duration_ms", round(duration_ms, 2))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_tts_call(task: str, text_length: int, result, latency: float) -> None:
    """Record an Azure TTS call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    reason_str = ""
    try:
        if result is not None:
            reason = getattr(result, "reason", None)
            if reason is not None:
                reason_str = str(getattr(reason, "name", reason))
    except Exception:
        pass

    call_data = {
        "model": "azure-tts",
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[tts text_length={text_length}]",
        "response_preview": f"[tts reason={reason_str} latency={latency * 1000:.0f}ms]",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
