"""Jina AI auto-instrumentor for waxell-observe.

Monkey-patches Jina's reranker client to emit retrieval/rerank spans.
For embeddings, Jina's OpenAI-compatible API (``base_url="https://api.jina.ai/v1"``)
is already auto-detected by the OpenAI instrumentor's provider detection.

This instrumentor targets the ``jina_reranker`` / ``jinareranker`` package
which provides ``Reranker.rerank()`` for reranking documents.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class JinaInstrumentor(BaseInstrumentor):
    """Instrumentor for the Jina AI reranker (``jina_reranker`` package).

    Patches ``Reranker.rerank`` to emit retrieval spans for reranking operations.
    Jina embeddings via OpenAI-compatible API are handled by the OpenAI instrumentor.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Jina instrumentation")
            return False

        patched = False

        # Try jina_reranker package (primary)
        try:
            import jina_reranker  # noqa: F401

            wrapt.wrap_function_wrapper(
                "jina_reranker",
                "Reranker.rerank",
                _sync_rerank_wrapper,
            )
            patched = True
            logger.debug("Jina reranker patched: jina_reranker.Reranker.rerank")
        except (ImportError, Exception):
            pass

        # Try jinareranker package (alternate naming)
        if not patched:
            try:
                import jinareranker  # noqa: F401

                wrapt.wrap_function_wrapper(
                    "jinareranker",
                    "Reranker.rerank",
                    _sync_rerank_wrapper,
                )
                patched = True
                logger.debug("Jina reranker patched: jinareranker.Reranker.rerank")
            except (ImportError, Exception):
                pass

        # Try jina package with JinaReranker class
        if not patched:
            try:
                import jina  # noqa: F401

                wrapt.wrap_function_wrapper(
                    "jina",
                    "JinaReranker.rerank",
                    _sync_rerank_wrapper,
                )
                patched = True
                logger.debug("Jina reranker patched: jina.JinaReranker.rerank")
            except (ImportError, Exception):
                pass

        if not patched:
            logger.debug(
                "Could not find Jina reranker methods to patch "
                "(jina_reranker, jinareranker, or jina package not installed)"
            )
            return False

        self._instrumented = True
        logger.debug("Jina reranker instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        for mod_path, cls_name in [
            ("jina_reranker", "Reranker"),
            ("jinareranker", "Reranker"),
            ("jina", "JinaReranker"),
        ]:
            try:
                import importlib

                mod = importlib.import_module(mod_path)
                cls = getattr(mod, cls_name, None)
                if cls is not None:
                    method = getattr(cls, "rerank", None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        cls.rerank = method.__wrapped__  # type: ignore[attr-defined]
            except (ImportError, AttributeError):
                pass

        self._instrumented = False
        logger.debug("Jina reranker uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_rerank_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Jina Reranker.rerank."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    model = kwargs.get("model", "jina-reranker-v2-base-multilingual")
    query = kwargs.get("query", args[0] if args else "")

    try:
        span = start_retrieval_span(
            query=query,
            source=f"jina-rerank:{model}",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # Extract results from response
            results = _extract_results(response)
            results_count = len(results)
            top_score = _extract_top_score(results)

            span.set_attribute("waxell.rerank.model", model)
            span.set_attribute("waxell.rerank.results_count", results_count)
            if top_score is not None:
                span.set_attribute("waxell.rerank.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set Jina rerank span attributes: %s", attr_exc)

        try:
            _record_http_jina_rerank(model, query, results_count, top_score)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_results(response):
    """Extract result list from a Jina rerank response."""
    # Try response.results (common pattern)
    results = getattr(response, "results", None)
    if results is not None:
        return results
    # Try response as dict
    if isinstance(response, dict):
        return response.get("results", [])
    # Try response as list directly
    if isinstance(response, list):
        return response
    return []


def _extract_top_score(results):
    """Extract the top relevance score from results."""
    if not results:
        return None
    first = results[0]
    # Try relevance_score attribute (object)
    score = getattr(first, "relevance_score", None)
    if score is not None:
        return float(score)
    # Try score attribute
    score = getattr(first, "score", None)
    if score is not None:
        return float(score)
    # Try dict access
    if isinstance(first, dict):
        score = first.get("relevance_score", first.get("score"))
        if score is not None:
            return float(score)
    return None


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_jina_rerank(
    model: str, query: str, results_count: int = 0, top_score: float | None = None
) -> None:
    """Record a Jina rerank call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    score_str = f", top_score={top_score:.3f}" if top_score is not None else ""
    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "rerank:jina",
        "prompt_preview": f"rerank query: {query[:200]}",
        "response_preview": f"{results_count} result(s){score_str}",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
