"""promptfoo auto-instrumentor for waxell-observe.

Monkey-patches promptfoo's Python evaluation interface and subprocess-based
CLI execution to emit step and guardrail spans tracking eval runs, assertion
checks, prompt templates, provider configs, and pass/fail metrics.

promptfoo is typically invoked via CLI (``promptfoo eval``), but also exposes
a Python interface via ``promptfoo.evaluate()`` and related methods. This
instrumentor patches both paths where possible.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class PromptfooInstrumentor(BaseInstrumentor):
    """Instrumentor for the promptfoo evaluation framework.

    Patches ``promptfoo.evaluate`` (if Python bindings available)
    and ``subprocess.run``/``subprocess.Popen`` to intercept promptfoo
    CLI invocations.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping promptfoo instrumentation")
            return False

        patched = False

        # Try to patch the Python promptfoo interface
        try:
            import promptfoo  # noqa: F401
            try:
                wrapt.wrap_function_wrapper(
                    "promptfoo",
                    "evaluate",
                    _evaluate_wrapper,
                )
                patched = True
                logger.debug("promptfoo.evaluate patched")
            except Exception as exc:
                logger.debug("Failed to patch promptfoo.evaluate: %s", exc)
        except ImportError:
            logger.debug("promptfoo Python package not installed")

        # Patch subprocess.run to intercept promptfoo CLI invocations
        try:
            wrapt.wrap_function_wrapper(
                "subprocess",
                "run",
                _subprocess_run_wrapper,
            )
            patched = True
            logger.debug("subprocess.run patched for promptfoo CLI detection")
        except Exception as exc:
            logger.debug("Failed to patch subprocess.run: %s", exc)

        if not patched:
            logger.debug("Could not find any promptfoo methods to patch")
            return False

        self._instrumented = True
        logger.debug("promptfoo instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import promptfoo

            if hasattr(getattr(promptfoo, "evaluate", None), "__wrapped__"):
                promptfoo.evaluate = promptfoo.evaluate.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import subprocess

            if hasattr(subprocess.run, "__wrapped__"):
                subprocess.run = subprocess.run.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("promptfoo uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_promptfoo_command(cmd) -> bool:
    """Check if a subprocess command is a promptfoo invocation."""
    if isinstance(cmd, str):
        return "promptfoo" in cmd
    if isinstance(cmd, (list, tuple)) and len(cmd) > 0:
        first = str(cmd[0])
        return "promptfoo" in first
    return False


def _extract_eval_config(args, kwargs) -> dict:
    """Extract evaluation config from promptfoo.evaluate() arguments."""
    config = {}
    try:
        if args:
            first_arg = args[0]
            if isinstance(first_arg, dict):
                config = first_arg
            elif hasattr(first_arg, "__dict__"):
                config = first_arg.__dict__
        if not config:
            config = kwargs
    except Exception:
        pass

    return {
        "prompts": config.get("prompts", []),
        "providers": config.get("providers", []),
        "tests": config.get("tests", []),
    }


def _extract_eval_results(result) -> dict:
    """Extract metrics from promptfoo evaluation results."""
    passed = 0
    failed = 0
    total_score = 0.0
    metrics_count = 0

    try:
        if isinstance(result, dict):
            results = result.get("results", [])
            stats = result.get("stats", {})
            if isinstance(stats, dict):
                passed = stats.get("successes", 0) or 0
                failed = stats.get("failures", 0) or 0
            else:
                for r in (results if isinstance(results, list) else []):
                    success = r.get("success", None) if isinstance(r, dict) else getattr(r, "success", None)
                    if success:
                        passed += 1
                    else:
                        failed += 1
        elif hasattr(result, "results"):
            results = getattr(result, "results", [])
            stats = getattr(result, "stats", None)
            if stats is not None:
                passed = getattr(stats, "successes", 0) or 0
                failed = getattr(stats, "failures", 0) or 0
            else:
                for r in (results if isinstance(results, (list, tuple)) else []):
                    if getattr(r, "success", False):
                        passed += 1
                    else:
                        failed += 1
    except Exception:
        pass

    total = passed + failed
    pass_rate = passed / total if total > 0 else 0.0

    return {
        "passed": passed,
        "failed": failed,
        "pass_rate": pass_rate,
        "total": total,
    }


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _evaluate_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``promptfoo.evaluate`` -- Python evaluation interface."""
    try:
        from ..tracing.spans import start_step_span, start_guardrail_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    config = _extract_eval_config(args, kwargs)
    prompts = config.get("prompts", [])
    providers = config.get("providers", [])
    tests = config.get("tests", [])

    prompts_count = len(prompts) if isinstance(prompts, list) else 0
    providers_count = len(providers) if isinstance(providers, list) else 0
    tests_count = len(tests) if isinstance(tests, list) else 0

    try:
        span = start_step_span(step_name="promptfoo.evaluate")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "promptfoo")
        span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, tests_count)
        span.set_attribute("waxell.eval.prompts_count", prompts_count)
        span.set_attribute("waxell.eval.providers_count", providers_count)

        # Record prompt template preview
        if prompts and isinstance(prompts, list):
            first_prompt = str(prompts[0])[:200] if prompts else ""
            span.set_attribute("waxell.eval.prompt_template", first_prompt)

        # Record provider info
        if providers and isinstance(providers, list):
            provider_str = str(providers[0])[:200] if providers else ""
            span.set_attribute("waxell.eval.provider", provider_str)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            metrics = _extract_eval_results(result)

            # Record assertion results as a guardrail span
            try:
                guard_span = start_guardrail_span(
                    guardrail_name="promptfoo.assertions",
                    framework="promptfoo",
                )
                guard_span.set_attribute(WaxellAttributes.EVAL_PASSED, metrics["passed"])
                guard_span.set_attribute("waxell.eval.failed", metrics["failed"])
                guard_span.set_attribute(WaxellAttributes.EVAL_PASS_RATE, metrics["pass_rate"])
                guard_span.set_attribute(WaxellAttributes.GUARDRAIL_PASSED, metrics["pass_rate"] >= 1.0)
                guard_span.end()
            except Exception:
                pass

            span.set_attribute(WaxellAttributes.EVAL_PASSED, metrics["passed"])
            span.set_attribute("waxell.eval.failed", metrics["failed"])
            span.set_attribute(WaxellAttributes.EVAL_PASS_RATE, metrics["pass_rate"])
        except Exception:
            pass

        try:
            _record_http_eval(result, config, metrics)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _subprocess_run_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``subprocess.run`` -- intercepts promptfoo CLI calls."""
    cmd = args[0] if args else kwargs.get("args", "")

    if not _is_promptfoo_command(cmd):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    cmd_str = cmd if isinstance(cmd, str) else " ".join(str(c) for c in cmd)

    try:
        span = start_step_span(step_name="promptfoo.cli")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "promptfoo")
        span.set_attribute("waxell.eval.cli_command", cmd_str[:500])
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            return_code = getattr(result, "returncode", None)
            span.set_attribute(WaxellAttributes.EVAL_PASSED, return_code == 0 if return_code is not None else False)
            if return_code is not None:
                span.set_attribute("waxell.eval.exit_code", return_code)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_eval(result, config: dict, metrics: dict) -> None:
    """Record a promptfoo evaluation to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:promptfoo.evaluate",
            output={
                "framework": "promptfoo",
                "passed": metrics.get("passed", 0),
                "failed": metrics.get("failed", 0),
                "pass_rate": metrics.get("pass_rate", 0.0),
                "total": metrics.get("total", 0),
                "result_preview": str(result)[:500],
            },
        )


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
