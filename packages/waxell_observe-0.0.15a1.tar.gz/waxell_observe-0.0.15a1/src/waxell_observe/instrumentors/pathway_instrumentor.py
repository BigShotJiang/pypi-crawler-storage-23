"""Pathway real-time RAG auto-instrumentor for waxell-observe.

Monkey-patches Pathway pipeline run methods, table operations, and vector
index queries to emit agent and retrieval spans.

Patched methods:
  - ``pathway.run``                             (agent span for pipeline execution)
  - ``pathway.run_all``                         (agent span for pipeline execution)
  - ``pathway.stdlib.indexing.VectorStoreServer.run``  (agent span for server)
  - ``pathway.stdlib.indexing.VectorStoreClient.query``  (retrieval span)

All wrapper code is wrapped in try/except -- never breaks the user's Pathway calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class PathwayInstrumentor(BaseInstrumentor):
    """Instrumentor for Pathway real-time RAG.

    Patches pipeline run methods to emit agent spans, and vector store
    query methods to emit retrieval spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import pathway  # noqa: F401
        except ImportError:
            logger.debug("pathway package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Pathway instrumentation")
            return False

        patched_any = False

        # --- pathway.run (main pipeline execution) ---
        try:
            wrapt.wrap_function_wrapper(
                "pathway",
                "run",
                _sync_pipeline_run_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch pathway.run: %s", exc)

        # --- pathway.run_all (alternative pipeline execution) ---
        try:
            wrapt.wrap_function_wrapper(
                "pathway",
                "run_all",
                _sync_pipeline_run_all_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch pathway.run_all: %s", exc)

        # --- VectorStoreServer.run (vector store server) ---
        try:
            wrapt.wrap_function_wrapper(
                "pathway.stdlib.indexing",
                "VectorStoreServer.run",
                _sync_vector_server_run_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch VectorStoreServer.run: %s", exc)

        # --- VectorStoreClient.query (vector query) ---
        try:
            wrapt.wrap_function_wrapper(
                "pathway.stdlib.indexing",
                "VectorStoreClient.query",
                _sync_vector_query_wrapper,
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch VectorStoreClient.query: %s", exc)

        # --- VectorStoreClient.__call__ (alternative query interface) ---
        try:
            wrapt.wrap_function_wrapper(
                "pathway.stdlib.indexing",
                "VectorStoreClient.__call__",
                _sync_vector_call_wrapper,
            )
        except Exception as exc:
            logger.debug("Could not patch VectorStoreClient.__call__: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any Pathway methods")
            return False

        self._instrumented = True
        logger.debug("Pathway instrumented (run, run_all, VectorStoreServer, VectorStoreClient)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore pathway.run / pathway.run_all
        try:
            import pathway

            for fn_name in ("run", "run_all"):
                fn = getattr(pathway, fn_name, None)
                if fn is not None and hasattr(fn, "__wrapped__"):
                    setattr(pathway, fn_name, fn.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore VectorStoreServer.run
        try:
            from pathway.stdlib.indexing import VectorStoreServer

            method = getattr(VectorStoreServer, "run", None)
            if method is not None and hasattr(method, "__wrapped__"):
                VectorStoreServer.run = method.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        # Restore VectorStoreClient methods
        try:
            from pathway.stdlib.indexing import VectorStoreClient

            for method_name in ("query", "__call__"):
                method = getattr(VectorStoreClient, method_name, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(VectorStoreClient, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Pathway uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _truncate(text: str, max_len: int = 500) -> str:
    """Truncate a string for span labelling."""
    if len(text) > max_len:
        return text[:max_len] + "..."
    return text


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


def _extract_query(args, kwargs) -> str:
    """Extract the query string from VectorStoreClient call args."""
    if args:
        return str(args[0]) if args[0] else ""
    return str(kwargs.get("query", kwargs.get("text", "")))


# ---------------------------------------------------------------------------
# Pipeline run wrappers (agent spans)
# ---------------------------------------------------------------------------


def _sync_pipeline_run_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for pathway.run -- emits agent span."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_agent_span(
            agent_name="pathway.pipeline",
            workflow_name="pathway_run",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.pathway.operation", "run")
        except Exception as attr_exc:
            logger.debug("Failed to set Pathway run span attributes: %s", attr_exc)

        try:
            _record_pathway_pipeline(operation="run")
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_pipeline_run_all_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for pathway.run_all -- emits agent span."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_agent_span(
            agent_name="pathway.pipeline",
            workflow_name="pathway_run_all",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.pathway.operation", "run_all")
        except Exception as attr_exc:
            logger.debug("Failed to set Pathway run_all span attributes: %s", attr_exc)

        try:
            _record_pathway_pipeline(operation="run_all")
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_vector_server_run_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for VectorStoreServer.run -- emits agent span."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    server_name = "pathway.VectorStoreServer"
    try:
        if hasattr(instance, "host") and hasattr(instance, "port"):
            server_name = f"pathway.VectorStoreServer({instance.host}:{instance.port})"
    except Exception:
        pass

    try:
        span = start_agent_span(
            agent_name=server_name,
            workflow_name="pathway_vector_server",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.pathway.operation", "vector_server_run")
        except Exception as attr_exc:
            logger.debug("Failed to set Pathway VectorStoreServer span attributes: %s", attr_exc)

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Vector query wrappers (retrieval spans)
# ---------------------------------------------------------------------------


def _sync_vector_query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for VectorStoreClient.query -- emits retrieval span."""
    query = _extract_query(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="pathway")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.retrieval.operation", "vector_query")
            results_count = 0
            if result is not None:
                if isinstance(result, (list, tuple)):
                    results_count = len(result)
                elif hasattr(result, "__len__"):
                    results_count = len(result)
            span.set_attribute("waxell.retrieval.results_count", results_count)
        except Exception as attr_exc:
            logger.debug("Failed to set Pathway query span attributes: %s", attr_exc)

        try:
            _record_pathway_retrieval(
                query=query_preview,
                results_count=results_count if "results_count" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_vector_call_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for VectorStoreClient.__call__ -- emits retrieval span."""
    query = _extract_query(args, kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    query_preview = _truncate(query)

    try:
        span = start_retrieval_span(query=query_preview, source="pathway")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.retrieval.operation", "vector_call")
            results_count = 0
            if result is not None and isinstance(result, (list, tuple)):
                results_count = len(result)
            span.set_attribute("waxell.retrieval.results_count", results_count)
        except Exception as attr_exc:
            logger.debug("Failed to set Pathway __call__ span attributes: %s", attr_exc)

        try:
            _record_pathway_retrieval(
                query=query_preview,
                results_count=results_count if "results_count" in dir() else 0,
            )
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_pathway_pipeline(
    operation: str = "run",
) -> None:
    """Record a Pathway pipeline execution to the context path.

    Pipeline executions are recorded as steps within an active WaxellContext.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"pathway_{operation}",
            output={"operation": operation},
        )


def _record_pathway_retrieval(
    query: str,
    results_count: int = 0,
) -> None:
    """Record a Pathway vector retrieval operation to the context path.

    Pathway retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="pathway",
            results_count=results_count,
        )
