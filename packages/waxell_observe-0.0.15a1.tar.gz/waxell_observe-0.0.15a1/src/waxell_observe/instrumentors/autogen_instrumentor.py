"""AutoGen auto-instrumentor for waxell-observe.

Monkey-patches ``autogen_agentchat.agents.AssistantAgent.on_messages``
to emit OTel spans and record to the Waxell HTTP API.

Microsoft AutoGen (v0.4+) uses ``autogen_agentchat`` as the primary
chat agent package with ``on_messages`` as the message-handling entry point.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class AutoGenInstrumentor(BaseInstrumentor):
    """Instrumentor for Microsoft AutoGen (``autogen-agentchat`` package).

    Patches AssistantAgent.on_messages for message handling.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import autogen_agentchat  # noqa: F401
        except ImportError:
            logger.debug("autogen_agentchat not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping AutoGen instrumentation")
            return False

        patched = False

        # Patch AssistantAgent.on_messages (async)
        try:
            wrapt.wrap_function_wrapper(
                "autogen_agentchat.agents",
                "AssistantAgent.on_messages",
                _on_messages_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch AssistantAgent.on_messages: %s", exc)

        # Also try to patch on_messages_stream if it exists
        try:
            wrapt.wrap_function_wrapper(
                "autogen_agentchat.agents",
                "AssistantAgent.on_messages_stream",
                _on_messages_stream_wrapper,
            )
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find AutoGen methods to patch")
            return False

        self._instrumented = True
        logger.debug("AutoGen instrumented (AssistantAgent.on_messages)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from autogen_agentchat.agents import AssistantAgent

            if hasattr(AssistantAgent.on_messages, "__wrapped__"):
                AssistantAgent.on_messages = AssistantAgent.on_messages.__wrapped__
            if hasattr(getattr(AssistantAgent, "on_messages_stream", None), "__wrapped__"):
                AssistantAgent.on_messages_stream = AssistantAgent.on_messages_stream.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("AutoGen uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


async def _on_messages_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AssistantAgent.on_messages``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    agent_name = getattr(instance, "name", None) or "autogen.agent"

    # Count incoming messages
    message_count = 0
    try:
        messages = args[0] if args else kwargs.get("messages", [])
        if messages:
            message_count = len(messages)
    except Exception:
        pass

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="autogen_on_messages",
        )
        span.set_attribute("waxell.autogen.agent_name", agent_name)
        span.set_attribute("waxell.autogen.message_count", message_count)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_result_attributes(span, result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _on_messages_stream_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``AssistantAgent.on_messages_stream``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    agent_name = getattr(instance, "name", None) or "autogen.agent"

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="autogen_on_messages_stream",
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _set_result_attributes(span, result, agent_name: str) -> None:
    """Set result attributes on the span."""
    try:
        # AutoGen Response has chat_message and inner_messages
        chat_message = getattr(result, "chat_message", None)
        inner_messages = getattr(result, "inner_messages", None) or []

        if chat_message:
            content = getattr(chat_message, "content", "")
            span.set_attribute("waxell.autogen.response_preview", str(content)[:200])

        span.set_attribute("waxell.autogen.inner_message_count", len(inner_messages))
    except Exception:
        pass

    # Record to context
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            response_preview = ""
            try:
                chat_message = getattr(result, "chat_message", None)
                if chat_message:
                    response_preview = str(getattr(chat_message, "content", ""))[:500]
            except Exception:
                pass
            ctx.record_step(
                f"autogen:{agent_name}",
                output={"result_preview": response_preview},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
