"""Fal AI auto-instrumentor for waxell-observe.

Monkey-patches ``fal_client.run``, ``fal_client.submit``, and
``fal_client.subscribe`` (sync and async) to emit OTel spans and record
to the Waxell HTTP API.

Fal AI is a serverless inference platform for running ML models including
image generation (Flux, Stable Diffusion, etc.), video, audio, and more.
The client sends requests specifying a model/function endpoint (e.g.
``"fal-ai/flux/dev"``) with input parameters and receives output URLs.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class FalInstrumentor(BaseInstrumentor):
    """Instrumentor for the Fal AI client (``fal-client`` package).

    Patches ``fal_client.run``, ``fal_client.submit``, and
    ``fal_client.subscribe`` for serverless inference observability.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import fal_client  # noqa: F401
        except ImportError:
            logger.debug("fal_client package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Fal AI instrumentation")
            return False

        patched = False

        # Patch fal_client.run (sync)
        try:
            wrapt.wrap_function_wrapper(
                "fal_client",
                "run",
                _fal_run_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch fal_client.run: %s", exc)

        # Patch fal_client.submit (sync)
        try:
            wrapt.wrap_function_wrapper(
                "fal_client",
                "submit",
                _fal_submit_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch fal_client.submit: %s", exc)

        # Patch fal_client.subscribe (sync)
        try:
            wrapt.wrap_function_wrapper(
                "fal_client",
                "subscribe",
                _fal_subscribe_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch fal_client.subscribe: %s", exc)

        # Patch async variants if available
        try:
            wrapt.wrap_function_wrapper(
                "fal_client",
                "run_async",
                _fal_run_async_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch fal_client.run_async: %s", exc)

        try:
            wrapt.wrap_function_wrapper(
                "fal_client",
                "submit_async",
                _fal_submit_async_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch fal_client.submit_async: %s", exc)

        try:
            wrapt.wrap_function_wrapper(
                "fal_client",
                "subscribe_async",
                _fal_subscribe_async_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch fal_client.subscribe_async: %s", exc)

        if not patched:
            logger.debug("Could not find fal_client methods to patch")
            return False

        self._instrumented = True
        logger.debug("Fal AI instrumented (run + submit + subscribe, sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import fal_client

            for attr in ("run", "submit", "subscribe", "run_async", "submit_async", "subscribe_async"):
                method = getattr(fal_client, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(fal_client, attr, method.__wrapped__)
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("Fal AI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Sync wrapper functions
# ---------------------------------------------------------------------------


def _fal_run_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``fal_client.run`` -- synchronous inference."""
    return _fal_sync_wrapper(wrapped, instance, args, kwargs, operation="run")


def _fal_submit_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``fal_client.submit`` -- submit async job."""
    return _fal_sync_wrapper(wrapped, instance, args, kwargs, operation="submit")


def _fal_subscribe_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``fal_client.subscribe`` -- submit and wait."""
    return _fal_sync_wrapper(wrapped, instance, args, kwargs, operation="subscribe")


def _fal_sync_wrapper(wrapped, instance, args, kwargs, operation: str):
    """Shared sync wrapper for all fal_client operations."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return wrapped(*args, **kwargs)

    # fal_client.run(endpoint, arguments={...}) or
    # fal_client.run("fal-ai/flux/dev", arguments={"prompt": "..."})
    endpoint = kwargs.get("endpoint", "") or (args[0] if args else "")
    arguments = kwargs.get("arguments", {}) or {}

    # Extract input parameters
    prompt = ""
    image_size = ""
    if isinstance(arguments, dict):
        prompt = arguments.get("prompt", "") or ""
        image_size = arguments.get("image_size", "") or ""

    function_name = _extract_function_name(endpoint)

    try:
        span = start_step_span(step_name=f"fal.{operation}")
        span.set_attribute("waxell.agent.framework", "fal")
        span.set_attribute("waxell.fal.operation", operation)

        if endpoint:
            span.set_attribute("waxell.fal.endpoint", str(endpoint))
        if function_name:
            span.set_attribute("waxell.fal.function_name", function_name)
        if prompt:
            span.set_attribute("waxell.fal.prompt_preview", str(prompt)[:200])
        if image_size:
            span.set_attribute("waxell.fal.image_size", str(image_size))

        # Extract additional common parameters
        if isinstance(arguments, dict):
            num_images = arguments.get("num_images", None)
            if num_images is not None:
                span.set_attribute("waxell.fal.num_images", int(num_images))

            num_inference_steps = arguments.get("num_inference_steps", None)
            if num_inference_steps is not None:
                span.set_attribute("waxell.fal.num_inference_steps", int(num_inference_steps))

            guidance_scale = arguments.get("guidance_scale", None)
            if guidance_scale is not None:
                span.set_attribute("waxell.fal.guidance_scale", float(guidance_scale))

            seed = arguments.get("seed", None)
            if seed is not None:
                span.set_attribute("waxell.fal.seed", int(seed))

            # Image/video input URL
            image_url = arguments.get("image_url", "") or ""
            if image_url:
                span.set_attribute("waxell.fal.has_input_image", True)
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.time() - start_time
            span.set_attribute("waxell.fal.latency_seconds", round(latency, 2))
            _set_fal_result_attributes(span, result, endpoint, operation)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrapper functions
# ---------------------------------------------------------------------------


async def _fal_run_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``fal_client.run_async``."""
    return await _fal_async_wrapper(wrapped, instance, args, kwargs, operation="run")


async def _fal_submit_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``fal_client.submit_async``."""
    return await _fal_async_wrapper(wrapped, instance, args, kwargs, operation="submit")


async def _fal_subscribe_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``fal_client.subscribe_async``."""
    return await _fal_async_wrapper(wrapped, instance, args, kwargs, operation="subscribe")


async def _fal_async_wrapper(wrapped, instance, args, kwargs, operation: str):
    """Shared async wrapper for all fal_client async operations."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes  # noqa: F401
    except Exception:
        return await wrapped(*args, **kwargs)

    endpoint = kwargs.get("endpoint", "") or (args[0] if args else "")
    arguments = kwargs.get("arguments", {}) or {}

    prompt = ""
    image_size = ""
    if isinstance(arguments, dict):
        prompt = arguments.get("prompt", "") or ""
        image_size = arguments.get("image_size", "") or ""

    function_name = _extract_function_name(endpoint)

    try:
        span = start_step_span(step_name=f"fal.{operation}")
        span.set_attribute("waxell.agent.framework", "fal")
        span.set_attribute("waxell.fal.operation", operation)

        if endpoint:
            span.set_attribute("waxell.fal.endpoint", str(endpoint))
        if function_name:
            span.set_attribute("waxell.fal.function_name", function_name)
        if prompt:
            span.set_attribute("waxell.fal.prompt_preview", str(prompt)[:200])
        if image_size:
            span.set_attribute("waxell.fal.image_size", str(image_size))

        if isinstance(arguments, dict):
            num_images = arguments.get("num_images", None)
            if num_images is not None:
                span.set_attribute("waxell.fal.num_images", int(num_images))

            num_inference_steps = arguments.get("num_inference_steps", None)
            if num_inference_steps is not None:
                span.set_attribute("waxell.fal.num_inference_steps", int(num_inference_steps))

            guidance_scale = arguments.get("guidance_scale", None)
            if guidance_scale is not None:
                span.set_attribute("waxell.fal.guidance_scale", float(guidance_scale))

            seed = arguments.get("seed", None)
            if seed is not None:
                span.set_attribute("waxell.fal.seed", int(seed))

            image_url = arguments.get("image_url", "") or ""
            if image_url:
                span.set_attribute("waxell.fal.has_input_image", True)
    except Exception:
        return await wrapped(*args, **kwargs)

    start_time = time.time()

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.time() - start_time
            span.set_attribute("waxell.fal.latency_seconds", round(latency, 2))
            _set_fal_result_attributes(span, result, endpoint, operation)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_function_name(endpoint: str) -> str:
    """Extract the function/model name from a fal endpoint string.

    E.g. ``"fal-ai/flux/dev"`` -> ``"flux/dev"``
         ``"fal-ai/stable-diffusion-v35"`` -> ``"stable-diffusion-v35"``
    """
    if not endpoint:
        return ""
    try:
        endpoint_str = str(endpoint)
        # Strip the "fal-ai/" prefix if present
        if endpoint_str.startswith("fal-ai/"):
            return endpoint_str[len("fal-ai/"):]
        return endpoint_str
    except Exception:
        return ""


def _set_fal_result_attributes(span, result, endpoint: str, operation: str) -> None:
    """Set result attributes for fal_client operations."""
    request_id = ""
    output_urls = []

    try:
        if isinstance(result, dict):
            # Direct result from run/subscribe
            request_id = result.get("request_id", "") or ""
            if request_id:
                span.set_attribute("waxell.fal.request_id", str(request_id))

            # Extract output image URLs
            images = result.get("images", [])
            if isinstance(images, list):
                for img in images:
                    if isinstance(img, dict):
                        url = img.get("url", "")
                        if url:
                            output_urls.append(str(url))
                    elif isinstance(img, str):
                        output_urls.append(img)

            # Single image output
            image = result.get("image", None)
            if isinstance(image, dict):
                url = image.get("url", "")
                if url:
                    output_urls.append(str(url))

            if output_urls:
                span.set_attribute("waxell.fal.output_count", len(output_urls))

            # Timing info from result
            timings = result.get("timings", {})
            if isinstance(timings, dict):
                inference_time = timings.get("inference", None)
                if inference_time is not None:
                    span.set_attribute("waxell.fal.inference_time_seconds", float(inference_time))

            # Seed used (may differ from input seed)
            seed = result.get("seed", None)
            if seed is not None:
                span.set_attribute("waxell.fal.output_seed", int(seed))

            # Check for has_nsfw_concepts
            nsfw = result.get("has_nsfw_concepts", None)
            if nsfw is not None and isinstance(nsfw, list):
                nsfw_count = sum(1 for x in nsfw if x)
                span.set_attribute("waxell.fal.nsfw_detected_count", nsfw_count)

        elif hasattr(result, "request_id"):
            # Submit result (handle object)
            request_id = getattr(result, "request_id", "") or ""
            if request_id:
                span.set_attribute("waxell.fal.request_id", str(request_id))

            status_url = getattr(result, "status_url", "") or ""
            if status_url:
                span.set_attribute("waxell.fal.has_status_url", True)
    except Exception:
        pass

    # Record to context (dual-path)
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"step:fal.{operation}",
                output={
                    "endpoint": str(endpoint),
                    "function_name": _extract_function_name(endpoint),
                    "request_id": str(request_id),
                    "output_count": len(output_urls),
                },
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
