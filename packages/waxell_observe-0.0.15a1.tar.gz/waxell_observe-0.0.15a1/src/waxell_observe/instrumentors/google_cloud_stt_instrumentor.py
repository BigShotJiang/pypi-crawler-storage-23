"""Google Cloud Speech-to-Text auto-instrumentor for waxell-observe.

Monkey-patches Google Cloud Speech SDK methods to emit OTel step spans
for speech-to-text (STT) operations:
  - ``google.cloud.speech.SpeechClient.recognize``       -- sync STT
  - ``google.cloud.speech.SpeechAsyncClient.recognize``   -- async STT

The Google Cloud Speech SDK returns typed response objects:
  - ``response.results[0].alternatives[0].transcript``
  - ``response.results[0].alternatives[0].confidence``

All wrapper code is wrapped in try/except -- never breaks the user's API calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class GoogleCloudSTTInstrumentor(BaseInstrumentor):
    """Instrumentor for the Google Cloud Speech-to-Text SDK.

    Patches ``SpeechClient.recognize`` (sync) and
    ``SpeechAsyncClient.recognize`` (async).
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import google.cloud.speech  # noqa: F401
        except ImportError:
            logger.debug("google.cloud.speech not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Google Cloud STT instrumentation")
            return False

        patched = False

        # Patch SpeechClient.recognize (sync)
        try:
            wrapt.wrap_function_wrapper(
                "google.cloud.speech",
                "SpeechClient.recognize",
                _sync_recognize_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Google Cloud SpeechClient.recognize: %s", exc)

        # Patch SpeechAsyncClient.recognize (async)
        try:
            wrapt.wrap_function_wrapper(
                "google.cloud.speech",
                "SpeechAsyncClient.recognize",
                _async_recognize_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch Google Cloud SpeechAsyncClient.recognize: %s", exc)

        if not patched:
            logger.debug("Could not find any Google Cloud Speech methods to patch")
            return False

        self._instrumented = True
        logger.debug("Google Cloud Speech-to-Text instrumented (recognize, sync + async)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import google.cloud.speech as mod

            for cls_name in ("SpeechClient", "SpeechAsyncClient"):
                cls = getattr(mod, cls_name, None)
                if cls is None:
                    continue
                method = getattr(cls, "recognize", None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(cls, "recognize", method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Google Cloud Speech-to-Text uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from Google Cloud Speech responses
# ---------------------------------------------------------------------------


def _extract_stt_data(response, config=None) -> dict:
    """Extract transcript, confidence, model, language, encoding from response."""
    data = {
        "transcript": "",
        "confidence": 0.0,
        "model": "",
        "language": "",
        "encoding": "",
    }

    if response is None:
        return data

    # Extract config-based attributes
    if config is not None:
        try:
            data["model"] = getattr(config, "model", "") or ""
        except Exception:
            pass
        try:
            data["language"] = getattr(config, "language_code", "") or ""
        except Exception:
            pass
        try:
            encoding = getattr(config, "encoding", None)
            if encoding is not None:
                data["encoding"] = str(encoding)
        except Exception:
            pass

    # Extract transcript and confidence from response
    try:
        results = getattr(response, "results", None)
        if results is None and isinstance(response, dict):
            results = response.get("results", [])

        if results and len(results) > 0:
            first_result = results[0]
            alternatives = getattr(first_result, "alternatives", None)
            if alternatives is None and isinstance(first_result, dict):
                alternatives = first_result.get("alternatives", [])

            if alternatives and len(alternatives) > 0:
                alt = alternatives[0]
                if isinstance(alt, dict):
                    data["transcript"] = alt.get("transcript", "")
                    data["confidence"] = alt.get("confidence", 0.0)
                else:
                    data["transcript"] = getattr(alt, "transcript", "")
                    data["confidence"] = getattr(alt, "confidence", 0.0)
    except Exception:
        pass

    return data


def _extract_config(args, kwargs):
    """Extract the RecognitionConfig from args/kwargs."""
    config = None
    try:
        # recognize(config=..., audio=...) or recognize(request={...})
        config = kwargs.get("config", None)
        if config is None:
            request = kwargs.get("request", None)
            if request is not None:
                if isinstance(request, dict):
                    config = request.get("config", None)
                else:
                    config = getattr(request, "config", None)
        if config is None and args:
            # First positional arg might be config or request
            first = args[0]
            if hasattr(first, "config"):
                config = getattr(first, "config", None)
            elif hasattr(first, "language_code"):
                config = first
    except Exception:
        pass
    return config


# ---------------------------------------------------------------------------
# Sync wrapper
# ---------------------------------------------------------------------------


def _sync_recognize_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``SpeechClient.recognize``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="google_cloud.stt.recognize")
    except Exception:
        return wrapped(*args, **kwargs)

    config = _extract_config(args, kwargs)

    t0 = time.monotonic()
    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_stt_data(response, config)
            _set_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set Google Cloud STT span attributes: %s", attr_exc)

        try:
            _record_stt_call("google_cloud.stt.recognize", data, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrapper
# ---------------------------------------------------------------------------


async def _async_recognize_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``SpeechAsyncClient.recognize``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        span = start_step_span(step_name="google_cloud.stt.recognize")
    except Exception:
        return await wrapped(*args, **kwargs)

    config = _extract_config(args, kwargs)

    t0 = time.monotonic()
    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        latency = time.monotonic() - t0
        try:
            data = _extract_stt_data(response, config)
            _set_span_attributes(span, data, latency)
        except Exception as attr_exc:
            logger.debug("Failed to set Google Cloud async STT span attributes: %s", attr_exc)

        try:
            _record_stt_call("google_cloud.stt.recognize", data, latency)
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Span attribute helpers
# ---------------------------------------------------------------------------


def _set_span_attributes(span, data: dict, latency: float) -> None:
    """Set OTel span attributes for a Google Cloud STT operation."""
    if data["model"]:
        span.set_attribute("waxell.google_cloud_stt.model", data["model"])
    if data["language"]:
        span.set_attribute("waxell.google_cloud_stt.language", data["language"])
    if data["encoding"]:
        span.set_attribute("waxell.google_cloud_stt.encoding", data["encoding"])
    if data["transcript"]:
        span.set_attribute("waxell.google_cloud_stt.transcript_preview", data["transcript"][:500])
    span.set_attribute("waxell.google_cloud_stt.confidence", data["confidence"])
    span.set_attribute("waxell.google_cloud_stt.latency_ms", round(latency * 1000, 2))


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_stt_call(task: str, data: dict, latency: float) -> None:
    """Record a Google Cloud STT call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": data.get("model", "google-cloud-stt"),
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": task,
        "prompt_preview": f"[google cloud stt, language={data.get('language', 'auto')}]",
        "response_preview": str(data.get("transcript", ""))[:500],
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
