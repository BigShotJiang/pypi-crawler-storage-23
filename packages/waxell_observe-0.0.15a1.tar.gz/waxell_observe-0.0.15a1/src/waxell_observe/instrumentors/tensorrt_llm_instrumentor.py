"""NVIDIA TensorRT-LLM auto-instrumentor for waxell-observe.

Monkey-patches tensorrt_llm.LLM.generate and tensorrt_llm.LLM.generate_async
to emit LLM call spans for TensorRT-optimized model inference.

TensorRT-LLM returns RequestOutput objects with:
  - ``outputs[0].token_ids``      -- list of output token ids per completion
  - ``outputs[0].text``           -- generated text

Cost is always 0.0 for local inference.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging
import time

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class TensorRTLLMInstrumentor(BaseInstrumentor):
    """Instrumentor for NVIDIA TensorRT-LLM (``tensorrt_llm`` package).

    Patches ``LLM.generate``, ``LLM.generate_async``, and model loading.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import tensorrt_llm  # noqa: F401
        except ImportError:
            logger.debug("tensorrt_llm package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping TensorRT-LLM instrumentation")
            return False

        patched = False

        # Patch LLM.generate (sync)
        try:
            wrapt.wrap_function_wrapper(
                "tensorrt_llm",
                "LLM.generate",
                _sync_generate_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch tensorrt_llm.LLM.generate: %s", exc)

        # Patch LLM.generate_async (async)
        try:
            wrapt.wrap_function_wrapper(
                "tensorrt_llm",
                "LLM.generate_async",
                _async_generate_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch tensorrt_llm.LLM.generate_async: %s", exc)

        # Patch LLM.__init__ to capture model loading
        try:
            wrapt.wrap_function_wrapper(
                "tensorrt_llm",
                "LLM.__init__",
                _model_load_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Could not patch tensorrt_llm.LLM.__init__: %s", exc)

        if not patched:
            logger.debug("Could not find any TensorRT-LLM methods to patch")
            return False

        self._instrumented = True
        logger.debug("TensorRT-LLM instrumented (generate + generate_async + __init__)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import tensorrt_llm

            for attr in ("generate", "generate_async", "__init__"):
                method = getattr(tensorrt_llm.LLM, attr, None)
                if method is not None and hasattr(method, "__wrapped__"):
                    setattr(tensorrt_llm.LLM, attr, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("TensorRT-LLM uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers for extracting data from TensorRT-LLM objects
# ---------------------------------------------------------------------------


def _get_model_name(instance) -> str:
    """Extract model name from a TensorRT-LLM LLM instance."""
    for attr in ("model", "model_dir", "config"):
        try:
            val = getattr(instance, attr, None)
            if val is None:
                continue
            if isinstance(val, str):
                return val
            model_name = getattr(val, "model", None) or getattr(val, "model_dir", None)
            if model_name and isinstance(model_name, str):
                return model_name
        except Exception:
            continue
    return "tensorrt-llm-local"


def _extract_generation_config(kwargs: dict) -> dict:
    """Extract generation configuration parameters."""
    config = {}
    # Check for SamplingParams or direct kwargs
    sampling_params = kwargs.get("sampling_params")
    if sampling_params is not None:
        for param in ("temperature", "top_k", "top_p", "max_tokens", "max_new_tokens"):
            val = getattr(sampling_params, param, None)
            if val is not None:
                config[param] = val
    else:
        for param in ("temperature", "top_k", "top_p", "max_tokens", "max_new_tokens"):
            if param in kwargs:
                config[param] = kwargs[param]
    return config


def _extract_token_counts(results) -> tuple[int, int]:
    """Extract input and output token counts from TensorRT-LLM results.

    Returns (tokens_in, tokens_out).
    """
    if not results:
        return 0, 0

    try:
        # Handle single result or list of results
        items = results if isinstance(results, (list, tuple)) else [results]
        first = items[0]

        tokens_in = len(getattr(first, "prompt_token_ids", []) or [])
        tokens_out = sum(
            len(getattr(o, "token_ids", []) or [])
            for o in getattr(first, "outputs", [])
        )
        return tokens_in, tokens_out
    except Exception:
        return 0, 0


def _extract_response_text(results) -> str:
    """Extract generated text from the first result for logging."""
    if not results:
        return ""

    try:
        items = results if isinstance(results, (list, tuple)) else [results]
        first = items[0]
        outputs = getattr(first, "outputs", [])
        if outputs:
            text = getattr(outputs[0], "text", "")
            return str(text)[:500] if text else ""
    except Exception:
        pass

    return ""


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``tensorrt_llm.LLM.generate``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="tensorrt_llm")
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.monotonic()

    try:
        results = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.monotonic() - start_time
            tokens_in, tokens_out = _extract_token_counts(results)
            gen_config = _extract_generation_config(kwargs)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)  # Local inference
            span.set_attribute("waxell.tensorrt_llm.latency_s", latency)

            if "temperature" in gen_config:
                span.set_attribute(GenAIAttributes.REQUEST_TEMPERATURE, gen_config["temperature"])
            if "top_k" in gen_config:
                span.set_attribute("waxell.tensorrt_llm.top_k", gen_config["top_k"])
            if "top_p" in gen_config:
                span.set_attribute("waxell.tensorrt_llm.top_p", gen_config["top_p"])
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_tensorrt(results, model, kwargs, task="generate")
        except Exception:
            pass

        return results
    finally:
        span.end()


async def _async_generate_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``tensorrt_llm.LLM.generate_async``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return await wrapped(*args, **kwargs)

    model = _get_model_name(instance)

    try:
        span = start_llm_span(model=model, provider_name="tensorrt_llm")
    except Exception:
        return await wrapped(*args, **kwargs)

    start_time = time.monotonic()

    try:
        results = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.monotonic() - start_time
            tokens_in, tokens_out = _extract_token_counts(results)
            gen_config = _extract_generation_config(kwargs)

            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
            span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
            span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
            span.set_attribute(WaxellAttributes.LLM_COST, 0.0)
            span.set_attribute("waxell.tensorrt_llm.latency_s", latency)

            if "temperature" in gen_config:
                span.set_attribute(GenAIAttributes.REQUEST_TEMPERATURE, gen_config["temperature"])
            if "top_k" in gen_config:
                span.set_attribute("waxell.tensorrt_llm.top_k", gen_config["top_k"])
            if "top_p" in gen_config:
                span.set_attribute("waxell.tensorrt_llm.top_p", gen_config["top_p"])
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        try:
            _record_http_tensorrt(results, model, kwargs, task="generate_async")
        except Exception:
            pass

        return results
    finally:
        span.end()


def _model_load_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``tensorrt_llm.LLM.__init__`` to trace model loading."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract model name from constructor args
    model_name = "unknown"
    if args:
        model_name = str(args[0]) if args[0] else "unknown"
    model_name = kwargs.get("model", kwargs.get("model_dir", model_name))

    try:
        span = start_step_span(step_name=f"tensorrt_llm.load:{model_name}")
    except Exception:
        return wrapped(*args, **kwargs)

    start_time = time.monotonic()

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            latency = time.monotonic() - start_time
            span.set_attribute("waxell.tensorrt_llm.model_name", str(model_name))
            span.set_attribute("waxell.tensorrt_llm.load_time_s", latency)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_tensorrt(
    results, request_model: str, kwargs: dict, task: str = "generate"
) -> None:
    """Record a TensorRT-LLM call to the HTTP path (context or collector)."""
    from ._context_var import _current_context
    from ._collector import _collector

    tokens_in, tokens_out = _extract_token_counts(results)

    # Extract prompt preview
    prompt_preview = ""
    prompts = kwargs.get("prompts") or kwargs.get("prompt")
    if isinstance(prompts, str):
        prompt_preview = prompts[:500]
    elif isinstance(prompts, list) and prompts:
        prompt_preview = str(prompts[0])[:500]

    response_preview = _extract_response_text(results)

    call_data = {
        "model": request_model,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": 0.0,  # Local inference is always free
        "task": f"tensorrt_llm.{task}",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
