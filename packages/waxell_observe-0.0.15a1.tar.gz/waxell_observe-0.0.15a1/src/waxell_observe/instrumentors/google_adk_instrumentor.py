"""Google Agent Development Kit (ADK) auto-instrumentor for waxell-observe.

Instruments the Google ADK agent execution entry points to emit OTel spans
and record to the Waxell HTTP API.

Google ADK (``google-adk`` package, import ``google.adk``) provides agent
primitives for building agents with Google's Gemini models.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class GoogleADKInstrumentor(BaseInstrumentor):
    """Instrumentor for Google Agent Development Kit (``google-adk`` package).

    Patches the primary agent execution entry points.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import google.adk  # noqa: F401
        except ImportError:
            logger.debug("google.adk not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Google ADK instrumentation")
            return False

        patched = False

        # Try patching the Runner.run method (primary entry point)
        try:
            wrapt.wrap_function_wrapper(
                "google.adk.runners",
                "Runner.run_async",
                _runner_run_async_wrapper,
            )
            patched = True
        except Exception:
            pass

        # Also try Runner.run (sync variant)
        try:
            wrapt.wrap_function_wrapper(
                "google.adk.runners",
                "Runner.run",
                _runner_run_wrapper,
            )
            patched = True
        except Exception:
            pass

        # Try patching Agent.run or Agent.__call__ if Runner not found
        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "google.adk.agents",
                    "Agent.run_async",
                    _agent_run_async_wrapper,
                )
                patched = True
            except Exception:
                pass

        if not patched:
            try:
                wrapt.wrap_function_wrapper(
                    "google.adk.agents",
                    "Agent.__call__",
                    _agent_call_wrapper,
                )
                patched = True
            except Exception as exc:
                logger.debug("Failed to patch Google ADK Agent: %s", exc)

        if not patched:
            logger.debug("Could not find Google ADK methods to patch")
            return False

        self._instrumented = True
        logger.debug("Google ADK instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Restore Runner methods
        try:
            from google.adk import runners

            for method_name in ("run_async", "run"):
                method = getattr(runners.Runner, method_name, None)
                if method and hasattr(method, "__wrapped__"):
                    setattr(runners.Runner, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        # Restore Agent methods
        try:
            from google.adk import agents

            for method_name in ("run_async", "__call__"):
                method = getattr(agents.Agent, method_name, None)
                if method and hasattr(method, "__wrapped__"):
                    setattr(agents.Agent, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Google ADK uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


async def _runner_run_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Runner.run_async``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    agent_name, session_id, tools = _extract_runner_info(instance, args, kwargs)

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="google_adk_runner_run",
        )
        _set_span_attributes(span, agent_name, session_id, tools)
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_result(result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _runner_run_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``Runner.run``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name, session_id, tools = _extract_runner_info(instance, args, kwargs)

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="google_adk_runner_run",
        )
        _set_span_attributes(span, agent_name, session_id, tools)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_result(result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


async def _agent_run_async_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for ``Agent.run_async``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return await wrapped(*args, **kwargs)

    agent_name = getattr(instance, "name", None) or "google.adk.agent"

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="google_adk_agent_run",
        )
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        result = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_result(result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _agent_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``Agent.__call__``."""
    try:
        from ..tracing.spans import start_agent_span
    except Exception:
        return wrapped(*args, **kwargs)

    agent_name = getattr(instance, "name", None) or "google.adk.agent"

    try:
        span = start_agent_span(
            agent_name=agent_name,
            workflow_name="google_adk_agent_call",
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_result(result, agent_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_runner_info(instance, args, kwargs):
    """Extract agent name, session ID, and tools from Runner."""
    agent_name = "google.adk.agent"
    session_id = ""
    tools = []

    try:
        agent = getattr(instance, "agent", None)
        if agent:
            agent_name = getattr(agent, "name", None) or "google.adk.agent"

            # Extract tools
            agent_tools = getattr(agent, "tools", None) or []
            for t in agent_tools:
                name = getattr(t, "name", None) or type(t).__name__
                tools.append(name)
    except Exception:
        pass

    try:
        session = kwargs.get("session", None)
        if session is None and len(args) > 0:
            # Check if first arg looks like a session
            candidate = args[0]
            if hasattr(candidate, "id"):
                session = candidate
        if session:
            session_id = str(getattr(session, "id", ""))
    except Exception:
        pass

    return agent_name, session_id, tools


def _set_span_attributes(span, agent_name: str, session_id: str, tools: list) -> None:
    """Set Google ADK span attributes."""
    span.set_attribute("waxell.google_adk.agent_name", agent_name)
    if session_id:
        span.set_attribute("waxell.google_adk.session_id", session_id)
    if tools:
        span.set_attribute("waxell.google_adk.tools", tools)
        span.set_attribute("waxell.google_adk.tool_count", len(tools))


def _record_result(result, agent_name: str) -> None:
    """Record execution result to context."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            f"google_adk:{agent_name}",
            output={"result_preview": str(result)[:500]},
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
