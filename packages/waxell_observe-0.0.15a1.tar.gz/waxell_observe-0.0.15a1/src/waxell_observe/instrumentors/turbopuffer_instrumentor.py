"""Turbopuffer auto-instrumentor for waxell-observe.

Monkey-patches the Turbopuffer Python client to emit OTel spans for
vector search (query), upsert, and delete operations.

Patched methods:
  - ``turbopuffer.Namespace.query``   (retrieval span)
  - ``turbopuffer.Namespace.upsert``  (tool span)
  - ``turbopuffer.Namespace.delete``  (tool span)

All wrapper code is wrapped in try/except -- never breaks the user's Turbopuffer calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class TurbopufferInstrumentor(BaseInstrumentor):
    """Instrumentor for the Turbopuffer Python client (``turbopuffer`` package).

    Patches ``Namespace.query``, ``Namespace.upsert``, and ``Namespace.delete``
    to emit OTel spans and record retrieval/tool events to the Waxell
    observability backend.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import turbopuffer  # noqa: F401
        except ImportError:
            logger.debug("turbopuffer package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Turbopuffer instrumentation")
            return False

        patched_any = False

        # Turbopuffer uses turbopuffer.Namespace for all operations
        try:
            wrapt.wrap_function_wrapper(
                "turbopuffer",
                "Namespace.query",
                _query_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch turbopuffer.Namespace.query")

        try:
            wrapt.wrap_function_wrapper(
                "turbopuffer",
                "Namespace.upsert",
                _upsert_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch turbopuffer.Namespace.upsert")

        try:
            wrapt.wrap_function_wrapper(
                "turbopuffer",
                "Namespace.delete",
                _delete_wrapper,
            )
            patched_any = True
        except Exception:
            logger.debug("Could not patch turbopuffer.Namespace.delete")

        if not patched_any:
            logger.debug("Could not patch any Turbopuffer methods")
            return False

        self._instrumented = True
        logger.debug("Turbopuffer Namespace instrumented (query, upsert, delete)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import turbopuffer

            ns_cls = getattr(turbopuffer, "Namespace", None)
            if ns_cls is not None:
                for method_name in ("query", "upsert", "delete"):
                    method = getattr(ns_cls, method_name, None)
                    if method and hasattr(method, "__wrapped__"):
                        setattr(ns_cls, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Turbopuffer Namespace uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_namespace_name(instance) -> str:
    """Extract the namespace name from the Turbopuffer Namespace instance."""
    try:
        # Namespace stores its name in .name or .namespace
        name = getattr(instance, "name", None)
        if name is not None:
            return str(name)
        name = getattr(instance, "namespace", None)
        if name is not None:
            return str(name)
    except Exception:
        pass
    return ""


def _get_top_k(args, kwargs) -> int:
    """Extract top_k from query arguments."""
    top_k = kwargs.get("top_k", None)
    if top_k is not None:
        try:
            return int(top_k)
        except (TypeError, ValueError):
            pass
    return 0


def _count_query_results(response) -> int:
    """Count the number of results from a Turbopuffer query response.

    Turbopuffer query returns a list-like of results or an object with
    an iterable of results.
    """
    try:
        if response is None:
            return 0
        # Direct list/tuple
        if isinstance(response, (list, tuple)):
            return len(response)
        # Object with .data or .results attribute
        data = getattr(response, "data", None)
        if data is not None and hasattr(data, "__len__"):
            return len(data)
        results = getattr(response, "results", None)
        if results is not None and hasattr(results, "__len__"):
            return len(results)
        # Try len() directly (Turbopuffer VectorResult is iterable)
        return len(response)
    except (TypeError, Exception):
        pass
    return 0


def _count_vectors(args, kwargs) -> int:
    """Count the number of vectors in an upsert operation.

    Turbopuffer upsert accepts various formats:
    - ids=..., vectors=... as keyword args
    - A list of dicts/tuples
    """
    try:
        # ids keyword
        ids = kwargs.get("ids", None)
        if ids is not None and hasattr(ids, "__len__"):
            return len(ids)
        # vectors keyword
        vectors = kwargs.get("vectors", None)
        if vectors is not None and hasattr(vectors, "__len__"):
            return len(vectors)
        # First positional arg could be a list of vectors/dicts
        if args:
            first = args[0]
            if isinstance(first, (list, tuple)):
                return len(first)
    except Exception:
        pass
    return 0


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _query_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Turbopuffer ``Namespace.query``."""
    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    namespace_name = _get_namespace_name(instance)
    top_k = _get_top_k(args, kwargs)

    query_preview = f"turbopuffer.query(namespace={namespace_name!r}, top_k={top_k})"

    try:
        span = start_retrieval_span(query=query_preview, source="turbopuffer")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            results_count = _count_query_results(response)

            span.set_attribute("waxell.retrieval.source", "turbopuffer")
            span.set_attribute("waxell.retrieval.operation", "query")
            span.set_attribute("waxell.retrieval.matches_count", results_count)
            if namespace_name:
                span.set_attribute("waxell.retrieval.namespace", namespace_name)
            if top_k:
                span.set_attribute("waxell.retrieval.top_k", top_k)
        except Exception as attr_exc:
            logger.debug("Failed to set Turbopuffer query span attributes: %s", attr_exc)

        try:
            _record_turbopuffer_retrieval(
                query=query_preview,
                namespace=namespace_name,
                results_count=results_count if "results_count" in dir() else 0,
                top_k=top_k,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _upsert_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Turbopuffer ``Namespace.upsert``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    namespace_name = _get_namespace_name(instance)
    vectors_count = _count_vectors(args, kwargs)

    try:
        span = start_tool_span(tool_name="turbopuffer.upsert", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "upsert")
            span.set_attribute("waxell.vectordb.vectors_count", vectors_count)
            if namespace_name:
                span.set_attribute("waxell.retrieval.namespace", namespace_name)
        except Exception as attr_exc:
            logger.debug("Failed to set Turbopuffer upsert span attributes: %s", attr_exc)

        try:
            _record_turbopuffer_write(
                operation="upsert",
                namespace=namespace_name,
                vectors_count=vectors_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _delete_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for Turbopuffer ``Namespace.delete``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    namespace_name = _get_namespace_name(instance)

    # delete accepts ids as first positional or keyword arg
    ids = kwargs.get("ids", args[0] if args else None)
    ids_count = len(ids) if ids and hasattr(ids, "__len__") else 0

    try:
        span = start_tool_span(tool_name="turbopuffer.delete", tool_type="vectordb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.vectordb.operation", "delete")
            span.set_attribute("waxell.vectordb.vectors_count", ids_count)
            if namespace_name:
                span.set_attribute("waxell.retrieval.namespace", namespace_name)
        except Exception as attr_exc:
            logger.debug("Failed to set Turbopuffer delete span attributes: %s", attr_exc)

        try:
            _record_turbopuffer_write(
                operation="delete",
                namespace=namespace_name,
                vectors_count=ids_count,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_turbopuffer_retrieval(
    query: str,
    namespace: str,
    results_count: int,
    top_k: int,
) -> None:
    """Record a Turbopuffer retrieval operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        documents = [{"id": f"result_{i}"} for i in range(results_count)]
        ctx.record_retrieval(
            query=query,
            source="turbopuffer",
            documents=documents,
            top_k=top_k,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_turbopuffer_write(
    operation: str,
    namespace: str,
    vectors_count: int,
) -> None:
    """Record a Turbopuffer write operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"turbopuffer.{operation}",
            input={"namespace": namespace, "vectors_count": vectors_count},
            tool_type="vectordb",
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass
