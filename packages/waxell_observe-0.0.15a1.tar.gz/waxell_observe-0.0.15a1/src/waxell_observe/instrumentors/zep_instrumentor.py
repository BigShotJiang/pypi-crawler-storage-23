"""Zep Memory auto-instrumentor for waxell-observe.

Monkey-patches Zep client memory and graph methods to emit tool spans
tracking memory operations via the Zep API.

Patched methods:
  - ``ZepClient.memory.add``       (tool span -- memory write)
  - ``ZepClient.memory.get``       (tool span -- memory read)
  - ``ZepClient.memory.search``    (tool span -- memory search)
  - ``ZepClient.memory.delete``    (tool span -- memory delete)
  - ``ZepClient.graph.search``     (tool span -- knowledge graph search, if available)
  - ``AsyncZepClient.memory.add``       (async tool span)
  - ``AsyncZepClient.memory.get``       (async tool span)
  - ``AsyncZepClient.memory.search``    (async tool span)
  - ``AsyncZepClient.memory.delete``    (async tool span)
  - ``AsyncZepClient.graph.search``     (async tool span, if available)

All wrapper code is wrapped in try/except -- never breaks the user's Zep calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ZepInstrumentor(BaseInstrumentor):
    """Instrumentor for the Zep Python SDK (``zep-python`` package).

    Patches memory and graph methods on both sync (ZepClient) and
    async (AsyncZepClient) clients to emit tool spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import zep_python  # noqa: F401
        except ImportError:
            logger.debug("zep-python package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping Zep instrumentation")
            return False

        patched_any = False

        # --- Sync ZepClient memory methods ---
        for method_name, wrapper_fn in (
            ("memory.add", _sync_memory_add_wrapper),
            ("memory.get", _sync_memory_get_wrapper),
            ("memory.search", _sync_memory_search_wrapper),
            ("memory.delete", _sync_memory_delete_wrapper),
        ):
            try:
                # Zep uses nested objects (client.memory.add), so we need to
                # patch the Memory class methods directly
                _patch_nested_method(
                    wrapt, "zep_python", "ZepClient", method_name, wrapper_fn
                )
                patched_any = True
            except Exception as exc:
                logger.debug("Could not patch zep_python ZepClient.%s: %s", method_name, exc)

        # --- Sync ZepClient graph methods (newer Zep) ---
        try:
            _patch_nested_method(
                wrapt, "zep_python", "ZepClient", "graph.search", _sync_graph_search_wrapper
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch zep_python ZepClient.graph.search: %s", exc)

        # --- Async AsyncZepClient memory methods ---
        for method_name, wrapper_fn in (
            ("memory.add", _async_memory_add_wrapper),
            ("memory.get", _async_memory_get_wrapper),
            ("memory.search", _async_memory_search_wrapper),
            ("memory.delete", _async_memory_delete_wrapper),
        ):
            try:
                _patch_nested_method(
                    wrapt, "zep_python", "AsyncZepClient", method_name, wrapper_fn
                )
                patched_any = True
            except Exception as exc:
                logger.debug("Could not patch zep_python AsyncZepClient.%s: %s", method_name, exc)

        # --- Async AsyncZepClient graph methods ---
        try:
            _patch_nested_method(
                wrapt, "zep_python", "AsyncZepClient", "graph.search", _async_graph_search_wrapper
            )
            patched_any = True
        except Exception as exc:
            logger.debug("Could not patch zep_python AsyncZepClient.graph.search: %s", exc)

        if not patched_any:
            logger.debug("Could not patch any Zep client methods")
            return False

        self._instrumented = True
        logger.debug("Zep instrumented (memory.add/get/search/delete, graph.search)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import zep_python

            for client_name in ("ZepClient", "AsyncZepClient"):
                client_cls = getattr(zep_python, client_name, None)
                if client_cls is None:
                    continue

                # Restore memory methods
                memory_cls = getattr(client_cls, "memory", None)
                if memory_cls is not None:
                    # memory could be a property returning an object; try the class
                    _try_restore_methods(
                        memory_cls, ("add", "get", "search", "delete")
                    )

                # Restore graph methods
                graph_cls = getattr(client_cls, "graph", None)
                if graph_cls is not None:
                    _try_restore_methods(graph_cls, ("search",))

        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Zep uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Patching helpers
# ---------------------------------------------------------------------------


def _patch_nested_method(wrapt, module_name, client_cls_name, dotted_method, wrapper_fn):
    """Patch a nested method like ZepClient.memory.add.

    Since Zep uses nested objects (client.memory is a MemoryClient instance),
    we need to find the actual class that owns the method and patch it there.
    """
    import importlib

    mod = importlib.import_module(module_name)
    client_cls = getattr(mod, client_cls_name)

    parts = dotted_method.split(".")
    if len(parts) == 2:
        sub_attr_name, method_name = parts
        # Get the sub-object type from the class
        sub_attr = getattr(client_cls, sub_attr_name, None)
        if sub_attr is None:
            raise AttributeError(
                f"{client_cls_name} has no attribute '{sub_attr_name}'"
            )
        # sub_attr might be a class (type) or an instance
        target_cls = sub_attr if isinstance(sub_attr, type) else type(sub_attr)
        method = getattr(target_cls, method_name, None)
        if method is None:
            raise AttributeError(
                f"{target_cls.__name__} has no method '{method_name}'"
            )
        # Apply wrapt directly to the class method
        original = method
        wrapt.wrap_function_wrapper(
            target_cls.__module__,
            f"{target_cls.__name__}.{method_name}",
            wrapper_fn,
        )
    else:
        # Simple method on the client class itself
        wrapt.wrap_function_wrapper(
            module_name,
            f"{client_cls_name}.{dotted_method}",
            wrapper_fn,
        )


def _try_restore_methods(cls_or_obj, method_names):
    """Try to restore wrapped methods on a class or object."""
    target = cls_or_obj if isinstance(cls_or_obj, type) else type(cls_or_obj)
    for method_name in method_names:
        try:
            method = getattr(target, method_name, None)
            if method is not None and hasattr(method, "__wrapped__"):
                setattr(target, method_name, method.__wrapped__)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_session_id(args, kwargs, position=0) -> str:
    """Extract session_id from args/kwargs."""
    session_id = kwargs.get("session_id", None)
    if session_id is None and len(args) > position:
        session_id = args[position]
    return str(session_id) if session_id else ""


def _extract_query(args, kwargs, position=1) -> str:
    """Extract query string from search args/kwargs."""
    query = kwargs.get("query", kwargs.get("text", None))
    if query is None and len(args) > position:
        query = args[position]
    return str(query)[:200] if query else ""


def _extract_messages(args, kwargs) -> list:
    """Extract messages list from memory.add args/kwargs."""
    messages = kwargs.get("messages", None)
    if messages is None and len(args) > 1:
        messages = args[1]
    if messages is not None and isinstance(messages, list):
        return messages
    return []


def _extract_search_results(response) -> tuple[int, float | None]:
    """Extract result count and top score from Zep search results."""
    if response is None:
        return 0, None
    if isinstance(response, list):
        count = len(response)
        if count > 0:
            first = response[0]
            score = getattr(first, "score", None)
            if score is None and isinstance(first, dict):
                score = first.get("score")
            if score is not None:
                return count, float(score)
        return count, None
    # Some versions return an object with results attribute
    results = getattr(response, "results", None)
    if results is not None and isinstance(results, list):
        count = len(results)
        if count > 0:
            first = results[0]
            score = getattr(first, "score", None)
            if score is not None:
                return count, float(score)
        return count, None
    return 0, None


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Sync wrappers
# ---------------------------------------------------------------------------


def _sync_memory_add_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for memory.add (store messages to memory)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    session_id = _extract_session_id(args, kwargs)
    messages = _extract_messages(args, kwargs)
    num_messages = len(messages)

    try:
        span = start_tool_span(tool_name="zep.memory.add", tool_type="memory")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "add")
            if session_id:
                span.set_attribute("waxell.memory.session_id", session_id)
            span.set_attribute("waxell.memory.num_messages", num_messages)
        except Exception as attr_exc:
            logger.debug("Failed to set Zep memory.add span attributes: %s", attr_exc)

        try:
            _record_zep_operation(
                operation="add",
                session_id=session_id,
                num_messages=num_messages,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_memory_get_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for memory.get (retrieve memory for session)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    session_id = _extract_session_id(args, kwargs)

    try:
        span = start_tool_span(tool_name="zep.memory.get", tool_type="memory")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "get")
            if session_id:
                span.set_attribute("waxell.memory.session_id", session_id)

            # Extract message count from response
            messages = getattr(response, "messages", None)
            if messages is not None:
                span.set_attribute("waxell.memory.message_count", len(messages))
        except Exception as attr_exc:
            logger.debug("Failed to set Zep memory.get span attributes: %s", attr_exc)

        try:
            _record_zep_operation(
                operation="get",
                session_id=session_id,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_memory_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for memory.search (search memory)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    session_id = _extract_session_id(args, kwargs)
    query = _extract_query(args, kwargs)

    try:
        span = start_tool_span(tool_name="zep.memory.search", tool_type="memory")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            num_results, top_score = _extract_search_results(response)

            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "search")
            if session_id:
                span.set_attribute("waxell.memory.session_id", session_id)
            if query:
                span.set_attribute("waxell.memory.query", query)
            span.set_attribute("waxell.memory.num_results", num_results)
            if top_score is not None:
                span.set_attribute("waxell.memory.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set Zep memory.search span attributes: %s", attr_exc)

        try:
            _record_zep_retrieval(
                query=query,
                session_id=session_id,
                num_results=num_results if 'num_results' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_memory_delete_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for memory.delete (delete session memory)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    session_id = _extract_session_id(args, kwargs)

    try:
        span = start_tool_span(tool_name="zep.memory.delete", tool_type="memory")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "delete")
            if session_id:
                span.set_attribute("waxell.memory.session_id", session_id)
        except Exception as attr_exc:
            logger.debug("Failed to set Zep memory.delete span attributes: %s", attr_exc)

        try:
            _record_zep_operation(
                operation="delete",
                session_id=session_id,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


def _sync_graph_search_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for graph.search (knowledge graph search)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    user_id = kwargs.get("user_id", args[0] if args else "")
    query = _extract_query(args, kwargs)

    try:
        span = start_tool_span(tool_name="zep.graph.search", tool_type="memory")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            num_results, top_score = _extract_search_results(response)

            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "graph_search")
            if user_id:
                span.set_attribute("waxell.memory.user_id", str(user_id))
            if query:
                span.set_attribute("waxell.memory.query", query)
            span.set_attribute("waxell.memory.num_results", num_results)
            if top_score is not None:
                span.set_attribute("waxell.memory.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set Zep graph.search span attributes: %s", attr_exc)

        try:
            _record_zep_retrieval(
                query=query,
                session_id=str(user_id) if user_id else "",
                num_results=num_results if 'num_results' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Async wrappers
# ---------------------------------------------------------------------------


async def _async_memory_add_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for memory.add (store messages to memory)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    session_id = _extract_session_id(args, kwargs)
    messages = _extract_messages(args, kwargs)
    num_messages = len(messages)

    try:
        span = start_tool_span(tool_name="zep.memory.add", tool_type="memory")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "add")
            if session_id:
                span.set_attribute("waxell.memory.session_id", session_id)
            span.set_attribute("waxell.memory.num_messages", num_messages)
        except Exception as attr_exc:
            logger.debug("Failed to set Zep async memory.add span attributes: %s", attr_exc)

        try:
            _record_zep_operation(
                operation="add",
                session_id=session_id,
                num_messages=num_messages,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_memory_get_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for memory.get (retrieve memory for session)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    session_id = _extract_session_id(args, kwargs)

    try:
        span = start_tool_span(tool_name="zep.memory.get", tool_type="memory")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "get")
            if session_id:
                span.set_attribute("waxell.memory.session_id", session_id)

            messages = getattr(response, "messages", None)
            if messages is not None:
                span.set_attribute("waxell.memory.message_count", len(messages))
        except Exception as attr_exc:
            logger.debug("Failed to set Zep async memory.get span attributes: %s", attr_exc)

        try:
            _record_zep_operation(
                operation="get",
                session_id=session_id,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_memory_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for memory.search (search memory)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    session_id = _extract_session_id(args, kwargs)
    query = _extract_query(args, kwargs)

    try:
        span = start_tool_span(tool_name="zep.memory.search", tool_type="memory")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            num_results, top_score = _extract_search_results(response)

            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "search")
            if session_id:
                span.set_attribute("waxell.memory.session_id", session_id)
            if query:
                span.set_attribute("waxell.memory.query", query)
            span.set_attribute("waxell.memory.num_results", num_results)
            if top_score is not None:
                span.set_attribute("waxell.memory.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set Zep async memory.search span attributes: %s", attr_exc)

        try:
            _record_zep_retrieval(
                query=query,
                session_id=session_id,
                num_results=num_results if 'num_results' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_memory_delete_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for memory.delete (delete session memory)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    session_id = _extract_session_id(args, kwargs)

    try:
        span = start_tool_span(tool_name="zep.memory.delete", tool_type="memory")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "delete")
            if session_id:
                span.set_attribute("waxell.memory.session_id", session_id)
        except Exception as attr_exc:
            logger.debug("Failed to set Zep async memory.delete span attributes: %s", attr_exc)

        try:
            _record_zep_operation(
                operation="delete",
                session_id=session_id,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


async def _async_graph_search_wrapper(wrapped, instance, args, kwargs):
    """Async wrapper for graph.search (knowledge graph search)."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return await wrapped(*args, **kwargs)

    user_id = kwargs.get("user_id", args[0] if args else "")
    query = _extract_query(args, kwargs)

    try:
        span = start_tool_span(tool_name="zep.graph.search", tool_type="memory")
    except Exception:
        return await wrapped(*args, **kwargs)

    try:
        response = await wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            num_results, top_score = _extract_search_results(response)

            span.set_attribute("waxell.memory.system", "zep")
            span.set_attribute("waxell.memory.operation", "graph_search")
            if user_id:
                span.set_attribute("waxell.memory.user_id", str(user_id))
            if query:
                span.set_attribute("waxell.memory.query", query)
            span.set_attribute("waxell.memory.num_results", num_results)
            if top_score is not None:
                span.set_attribute("waxell.memory.top_score", top_score)
        except Exception as attr_exc:
            logger.debug("Failed to set Zep async graph.search span attributes: %s", attr_exc)

        try:
            _record_zep_retrieval(
                query=query,
                session_id=str(user_id) if user_id else "",
                num_results=num_results if 'num_results' in dir() else 0,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_zep_retrieval(
    query: str,
    session_id: str,
    num_results: int = 0,
) -> None:
    """Record a Zep search operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="zep",
            results_count=num_results,
        )


def _record_zep_operation(
    operation: str,
    session_id: str,
    num_messages: int = 0,
) -> None:
    """Record a Zep write/read/delete operation to the context path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_tool_call(
            name=f"zep.memory.{operation}",
            input={"session_id": session_id, "num_messages": num_messages},
            tool_type="memory",
        )
