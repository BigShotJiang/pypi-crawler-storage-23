"""Braintrust auto-instrumentor for waxell-observe.

Monkey-patches ``braintrust.Eval()``, ``braintrust.init()``, and
``braintrust.log()`` to emit evaluation spans tracking experiment names,
scores, metric names, and dataset sizes.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class BraintrustInstrumentor(BaseInstrumentor):
    """Instrumentor for the Braintrust evaluation platform (``braintrust`` package).

    Patches Eval(), init(), and log().
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import braintrust  # noqa: F401
        except ImportError:
            logger.debug("braintrust not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Braintrust instrumentation")
            return False

        patched = False

        # Patch braintrust.Eval (main eval function)
        try:
            wrapt.wrap_function_wrapper(
                "braintrust",
                "Eval",
                _eval_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch braintrust.Eval: %s", exc)

        # Patch braintrust.init (experiment init)
        try:
            wrapt.wrap_function_wrapper(
                "braintrust",
                "init",
                _init_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch braintrust.init: %s", exc)

        # Patch braintrust.log (score logging)
        try:
            wrapt.wrap_function_wrapper(
                "braintrust",
                "log",
                _log_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch braintrust.log: %s", exc)

        if not patched:
            logger.debug("Could not find Braintrust methods to patch")
            return False

        self._instrumented = True
        logger.debug("Braintrust instrumented (Eval + init + log)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import braintrust

            if hasattr(braintrust.Eval, "__wrapped__"):
                braintrust.Eval = braintrust.Eval.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import braintrust

            if hasattr(braintrust.init, "__wrapped__"):
                braintrust.init = braintrust.init.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import braintrust

            if hasattr(braintrust.log, "__wrapped__"):
                braintrust.log = braintrust.log.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Braintrust uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _eval_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``braintrust.Eval`` -- main eval function."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract experiment name, data, scores from args/kwargs
    experiment_name = ""
    dataset_size = 0
    score_names: list[str] = []
    try:
        if args:
            experiment_name = str(args[0]) if len(args) > 0 else ""
        else:
            experiment_name = str(kwargs.get("name", ""))
    except Exception:
        pass

    try:
        data = kwargs.get("data", None)
        if data is not None:
            try:
                dataset_size = len(data)
            except (TypeError, AttributeError):
                pass
    except Exception:
        pass

    try:
        scores = kwargs.get("scores", None)
        if scores is not None:
            if isinstance(scores, (list, tuple)):
                for s in scores:
                    try:
                        name = getattr(s, "__name__", None) or getattr(s, "name", None) or type(s).__name__
                        score_names.append(str(name))
                    except Exception:
                        pass
    except Exception:
        pass

    try:
        span = start_step_span(step_name="braintrust.eval")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "braintrust")
        if experiment_name:
            span.set_attribute("waxell.eval.experiment", experiment_name)
        if dataset_size:
            span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, dataset_size)
        if score_names:
            span.set_attribute("waxell.eval.scores", ",".join(score_names))
            span.set_attribute(WaxellAttributes.EVAL_METRICS_COUNT, len(score_names))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_eval_result(span, result, experiment_name, dataset_size, score_names)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _init_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``braintrust.init`` -- experiment initialization."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    experiment_name = ""
    try:
        if args:
            experiment_name = str(args[0]) if len(args) > 0 else ""
        else:
            experiment_name = str(kwargs.get("project", "") or kwargs.get("name", ""))
    except Exception:
        pass

    try:
        span = start_step_span(step_name="braintrust.init")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "braintrust")
        if experiment_name:
            span.set_attribute("waxell.eval.experiment", experiment_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_init(experiment_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _log_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``braintrust.log`` -- score logging."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract scores from kwargs
    scores = {}
    try:
        scores = kwargs.get("scores", {}) or {}
        if not isinstance(scores, dict):
            scores = {}
    except Exception:
        pass

    try:
        span = start_step_span(step_name="braintrust.log")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "braintrust")
        if scores:
            span.set_attribute("waxell.eval.scores", ",".join(str(k) for k in scores.keys()))
            # Set first score as the primary score
            for key, val in scores.items():
                try:
                    span.set_attribute(WaxellAttributes.EVAL_METRIC_NAME, str(key))
                    span.set_attribute(WaxellAttributes.EVAL_SCORE, float(val))
                except (TypeError, ValueError):
                    pass
                break
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_log(scores)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_eval_result(span, result, experiment_name: str,
                        dataset_size: int, score_names: list[str]) -> None:
    """Extract Braintrust eval results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    overall_score = None
    scores: dict[str, float] = {}

    # Try to extract summary from result
    try:
        summary = getattr(result, "summary", None)
        if summary is not None:
            if callable(summary):
                summary = summary()
            scores_data = getattr(summary, "scores", None) or getattr(summary, "metrics", None)
            if isinstance(scores_data, dict):
                for k, v in scores_data.items():
                    try:
                        val = v if isinstance(v, (int, float)) else getattr(v, "score", None)
                        if val is not None:
                            scores[str(k)] = float(val)
                    except (TypeError, ValueError):
                        pass
    except Exception:
        pass

    # Try result as dict
    if not scores:
        try:
            if isinstance(result, dict):
                for k, v in result.items():
                    try:
                        scores[str(k)] = float(v)
                    except (TypeError, ValueError):
                        pass
        except Exception:
            pass

    try:
        if scores:
            overall_score = sum(scores.values()) / len(scores)
    except Exception:
        pass

    try:
        if overall_score is not None:
            span.set_attribute(WaxellAttributes.EVAL_SCORE, overall_score)
        if scores:
            score_summary = ", ".join(f"{k}={v:.3f}" for k, v in scores.items())
            span.set_attribute("waxell.eval.metric_scores", score_summary)
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_eval(result, experiment_name, dataset_size, score_names, scores)
    except Exception:
        pass


def _record_http_eval(result, experiment_name: str, dataset_size: int,
                      score_names: list[str], scores: dict[str, float]) -> None:
    """Record a Braintrust eval to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:braintrust.eval",
            output={
                "framework": "braintrust",
                "experiment": experiment_name,
                "dataset_size": dataset_size,
                "score_names": score_names,
                "scores": scores,
                "result_preview": str(result)[:500],
            },
        )


def _record_http_init(experiment_name: str) -> None:
    """Record a Braintrust init to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:braintrust.init",
            output={
                "framework": "braintrust",
                "experiment": experiment_name,
            },
        )


def _record_http_log(scores: dict) -> None:
    """Record a Braintrust log to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        safe_scores = {}
        for k, v in scores.items():
            try:
                safe_scores[str(k)] = float(v)
            except (TypeError, ValueError):
                safe_scores[str(k)] = str(v)

        ctx.record_step(
            "eval:braintrust.log",
            output={
                "framework": "braintrust",
                "scores": safe_scores,
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
