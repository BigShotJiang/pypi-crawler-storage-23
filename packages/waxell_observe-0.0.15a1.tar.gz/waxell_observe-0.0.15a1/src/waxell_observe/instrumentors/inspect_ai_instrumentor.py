"""Inspect AI auto-instrumentor for waxell-observe.

Monkey-patches ``inspect_ai.eval()`` and ``inspect_ai.Task.__call__()``
to emit evaluation spans tracking task names, models, scores, and
sample counts.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class InspectAIInstrumentor(BaseInstrumentor):
    """Instrumentor for the Inspect AI framework (``inspect_ai`` package).

    Patches inspect_ai.eval() and Task.__call__().
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import inspect_ai  # noqa: F401
        except ImportError:
            logger.debug("inspect_ai not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Inspect AI instrumentation")
            return False

        patched = False

        # Patch inspect_ai.eval (main eval entry point)
        try:
            wrapt.wrap_function_wrapper(
                "inspect_ai",
                "eval",
                _eval_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch inspect_ai.eval: %s", exc)

        # Patch inspect_ai.Task.__call__
        try:
            wrapt.wrap_function_wrapper(
                "inspect_ai",
                "Task.__call__",
                _task_call_wrapper,
            )
        except Exception as exc:
            logger.debug("Failed to patch inspect_ai.Task.__call__: %s", exc)

        if not patched:
            logger.debug("Could not find Inspect AI methods to patch")
            return False

        self._instrumented = True
        logger.debug("Inspect AI instrumented (eval + Task.__call__)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import inspect_ai

            if hasattr(inspect_ai.eval, "__wrapped__"):
                inspect_ai.eval = inspect_ai.eval.__wrapped__
        except (ImportError, AttributeError):
            pass

        try:
            import inspect_ai

            if hasattr(inspect_ai.Task.__call__, "__wrapped__"):
                inspect_ai.Task.__call__ = inspect_ai.Task.__call__.__wrapped__
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Inspect AI uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _eval_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``inspect_ai.eval`` -- main eval entry point."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract task, model, and other params
    task_name = ""
    model_name = ""
    try:
        task = args[0] if args else kwargs.get("tasks", kwargs.get("task", None))
        if task is not None:
            if isinstance(task, str):
                task_name = task
            elif isinstance(task, (list, tuple)):
                names = []
                for t in task:
                    try:
                        n = getattr(t, "name", None) or str(t)
                        names.append(str(n))
                    except Exception:
                        pass
                task_name = ",".join(names) if names else ""
            else:
                task_name = getattr(task, "name", None) or str(task)
    except Exception:
        pass

    try:
        model = kwargs.get("model", None)
        if model is not None:
            model_name = str(model)
        elif len(args) > 1:
            model_name = str(args[1])
    except Exception:
        pass

    try:
        span = start_step_span(step_name="inspect_ai.eval")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "inspect_ai")
        if task_name:
            span.set_attribute("waxell.eval.task", task_name)
        if model_name:
            span.set_attribute("waxell.eval.model", model_name)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_eval_result(span, result, task_name, model_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _task_call_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``inspect_ai.Task.__call__`` -- task execution."""
    try:
        from ..tracing.spans import start_step_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    task_name = ""
    try:
        task_name = getattr(instance, "name", None) or type(instance).__name__
    except Exception:
        task_name = "UnknownTask"

    try:
        span = start_step_span(step_name="inspect_ai.task")
        span.set_attribute(WaxellAttributes.EVAL_FRAMEWORK, "inspect_ai")
        span.set_attribute("waxell.eval.task", str(task_name))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _record_http_task(task_name, result)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _record_eval_result(span, result, task_name: str, model_name: str) -> None:
    """Extract Inspect AI eval results and set span attributes."""
    from ..tracing.attributes import WaxellAttributes

    samples_count = 0
    scores: dict[str, float] = {}

    # inspect_ai.eval returns a list of EvalLog or a single EvalLog
    results_list = []
    try:
        if isinstance(result, (list, tuple)):
            results_list = list(result)
        else:
            results_list = [result]
    except Exception:
        pass

    for eval_log in results_list:
        # Extract samples count
        try:
            samples = getattr(eval_log, "samples", None)
            if samples is not None:
                try:
                    samples_count += len(samples)
                except (TypeError, AttributeError):
                    pass
        except Exception:
            pass

        # Extract results/scores
        try:
            eval_results = getattr(eval_log, "results", None)
            if eval_results is not None:
                # Try scores attribute
                result_scores = getattr(eval_results, "scores", None)
                if result_scores is not None:
                    if isinstance(result_scores, dict):
                        for k, v in result_scores.items():
                            try:
                                val = v if isinstance(v, (int, float)) else getattr(v, "value", None)
                                if val is not None:
                                    scores[str(k)] = float(val)
                            except (TypeError, ValueError):
                                pass
                    elif isinstance(result_scores, (list, tuple)):
                        for s in result_scores:
                            try:
                                name = getattr(s, "name", None) or str(s)
                                val = getattr(s, "value", None) or getattr(s, "score", None)
                                if val is not None:
                                    scores[str(name)] = float(val)
                            except (TypeError, ValueError):
                                pass

                # Try metrics attribute
                metrics = getattr(eval_results, "metrics", None)
                if metrics is not None and not scores:
                    if isinstance(metrics, dict):
                        for k, v in metrics.items():
                            try:
                                val = v if isinstance(v, (int, float)) else getattr(v, "value", None)
                                if val is not None:
                                    scores[str(k)] = float(val)
                            except (TypeError, ValueError):
                                pass
        except Exception:
            pass

    overall_score = None
    try:
        if scores:
            overall_score = sum(scores.values()) / len(scores)
    except Exception:
        pass

    try:
        if samples_count:
            span.set_attribute(WaxellAttributes.EVAL_TEST_CASES_COUNT, samples_count)
        if overall_score is not None:
            span.set_attribute(WaxellAttributes.EVAL_SCORE, overall_score)
        if scores:
            score_summary = ", ".join(f"{k}={v:.3f}" for k, v in scores.items())
            span.set_attribute("waxell.eval.metric_scores", score_summary)
            span.set_attribute(WaxellAttributes.EVAL_METRICS_COUNT, len(scores))
    except Exception:
        pass

    # Record to HTTP path
    try:
        _record_http_eval(result, task_name, model_name, samples_count, scores)
    except Exception:
        pass


def _record_http_eval(result, task_name: str, model_name: str,
                      samples_count: int, scores: dict[str, float]) -> None:
    """Record an Inspect AI eval to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:inspect_ai.eval",
            output={
                "framework": "inspect_ai",
                "task": task_name,
                "model": model_name,
                "samples_count": samples_count,
                "scores": scores,
                "result_preview": str(result)[:500],
            },
        )


def _record_http_task(task_name: str, result) -> None:
    """Record an Inspect AI task call to the HTTP path."""
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_step(
            "eval:inspect_ai.task",
            output={
                "framework": "inspect_ai",
                "task": task_name,
                "result_preview": str(result)[:500],
            },
        )


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
