"""IBM WatsonX AI auto-instrumentor for waxell-observe.

Monkey-patches WatsonX AI SDK methods to emit OTel spans and record
to the Waxell HTTP API.

Patched methods:
  - ``ibm_watsonx_ai.foundation_models.ModelInference.generate()``
  - ``ibm_watsonx_ai.foundation_models.ModelInference.generate_text()``
  - ``ibm_watsonx_ai.foundation_models.Embeddings.embed_documents()``

WatsonX generate() returns a dict:
  - ``result["results"][0]["generated_text"]``
  - ``result["results"][0]["generated_token_count"]`` (output tokens)
  - ``result["results"][0]["input_token_count"]`` (input tokens)
  - ``result["results"][0]["stop_reason"]`` (finish reason)
  - ``result["model_id"]`` (model name)

Models: ibm/granite-13b-chat-v2, meta-llama/llama-3-70b-instruct,
        ibm/granite-3-8b-instruct, etc.

All wrapper code is wrapped in try/except -- never breaks the user's LLM calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Cost estimates for WatsonX models (USD per token)
# ---------------------------------------------------------------------------

_WATSONX_COSTS: dict[str, dict[str, float]] = {
    "ibm/granite-13b": {
        "input": 0.20 / 1_000_000,
        "output": 0.60 / 1_000_000,
    },
    "ibm/granite-3-8b": {
        "input": 0.15 / 1_000_000,
        "output": 0.45 / 1_000_000,
    },
    "ibm/granite-3-2b": {
        "input": 0.05 / 1_000_000,
        "output": 0.15 / 1_000_000,
    },
    "ibm/granite-34b": {
        "input": 0.60 / 1_000_000,
        "output": 1.80 / 1_000_000,
    },
    "meta-llama/llama-3-70b": {
        "input": 0.90 / 1_000_000,
        "output": 1.20 / 1_000_000,
    },
    "meta-llama/llama-3-8b": {
        "input": 0.15 / 1_000_000,
        "output": 0.20 / 1_000_000,
    },
    "meta-llama/llama-3-1-70b": {
        "input": 0.90 / 1_000_000,
        "output": 1.20 / 1_000_000,
    },
    "mistralai/mixtral-8x7b": {
        "input": 0.45 / 1_000_000,
        "output": 0.70 / 1_000_000,
    },
}

_DEFAULT_COST = {"input": 0.30 / 1_000_000, "output": 0.90 / 1_000_000}


def _estimate_watsonx_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    """Estimate cost for a WatsonX model call."""
    model_lower = model.lower()
    costs = _DEFAULT_COST
    for prefix, cost_info in _WATSONX_COSTS.items():
        if model_lower.startswith(prefix):
            costs = cost_info
            break
    return (tokens_in * costs["input"]) + (tokens_out * costs["output"])


class WatsonXInstrumentor(BaseInstrumentor):
    """Instrumentor for the IBM WatsonX AI SDK (``ibm_watsonx_ai`` package).

    Patches ``ModelInference.generate()``, ``ModelInference.generate_text()``,
    and ``Embeddings.embed_documents()``.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import ibm_watsonx_ai  # noqa: F401
        except ImportError:
            logger.debug("ibm_watsonx_ai package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping WatsonX instrumentation")
            return False

        patched = False

        # Patch ModelInference.generate()
        try:
            wrapt.wrap_function_wrapper(
                "ibm_watsonx_ai.foundation_models",
                "ModelInference.generate",
                _sync_generate_wrapper,
            )
            patched = True
            logger.debug("WatsonX ModelInference.generate instrumented")
        except Exception as exc:
            logger.debug("Could not patch ModelInference.generate: %s", exc)

        # Patch ModelInference.generate_text()
        try:
            wrapt.wrap_function_wrapper(
                "ibm_watsonx_ai.foundation_models",
                "ModelInference.generate_text",
                _sync_generate_text_wrapper,
            )
            logger.debug("WatsonX ModelInference.generate_text instrumented")
        except Exception as exc:
            logger.debug("Could not patch ModelInference.generate_text: %s", exc)

        # Patch Embeddings.embed_documents()
        try:
            wrapt.wrap_function_wrapper(
                "ibm_watsonx_ai.foundation_models",
                "Embeddings.embed_documents",
                _sync_embed_wrapper,
            )
            logger.debug("WatsonX Embeddings.embed_documents instrumented")
        except Exception as exc:
            logger.debug("Could not patch Embeddings.embed_documents: %s", exc)

        if not patched:
            logger.debug("Could not find WatsonX generation methods to patch")
            return False

        self._instrumented = True
        logger.debug("WatsonX ModelInference/Embeddings instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import importlib
            mod = importlib.import_module("ibm_watsonx_ai.foundation_models")

            if hasattr(mod, "ModelInference"):
                if hasattr(mod.ModelInference.generate, "__wrapped__"):
                    mod.ModelInference.generate = mod.ModelInference.generate.__wrapped__  # type: ignore[attr-defined]
                if hasattr(mod.ModelInference.generate_text, "__wrapped__"):
                    mod.ModelInference.generate_text = mod.ModelInference.generate_text.__wrapped__  # type: ignore[attr-defined]

            if hasattr(mod, "Embeddings"):
                if hasattr(mod.Embeddings.embed_documents, "__wrapped__"):
                    mod.Embeddings.embed_documents = mod.Embeddings.embed_documents.__wrapped__  # type: ignore[attr-defined]
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("WatsonX ModelInference/Embeddings uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _extract_generate_result(result: dict) -> tuple[str, int, int, str, str]:
    """Extract data from WatsonX generate() dict response.

    Returns (generated_text, input_tokens, output_tokens, stop_reason, model_id).
    """
    generated_text = ""
    tokens_in = 0
    tokens_out = 0
    stop_reason = ""
    model_id = ""

    try:
        model_id = result.get("model_id", "") or ""
        results = result.get("results", [])
        if results and len(results) > 0:
            first = results[0]
            generated_text = first.get("generated_text", "") or ""
            tokens_in = first.get("input_token_count", 0) or 0
            tokens_out = first.get("generated_token_count", 0) or 0
            stop_reason = first.get("stop_reason", "") or ""
    except Exception:
        pass

    return generated_text, tokens_in, tokens_out, stop_reason, model_id


def _get_model_from_instance(instance) -> str:
    """Try to extract the model ID from a ModelInference instance."""
    try:
        # ModelInference typically stores model_id
        model = getattr(instance, "model_id", None)
        if model:
            return str(model)
        model = getattr(instance, "model", None)
        if model:
            return str(model)
    except Exception:
        pass
    return "unknown"


# ---------------------------------------------------------------------------
# Wrapper functions (module-level for wrapt compatibility)
# ---------------------------------------------------------------------------


def _sync_generate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for WatsonX ``ModelInference.generate``."""
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import GenAIAttributes, WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="watsonx")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            if isinstance(result, dict):
                generated_text, tokens_in, tokens_out, stop_reason, model_id = (
                    _extract_generate_result(result)
                )
                response_model = model_id or model
                cost = _estimate_watsonx_cost(response_model, tokens_in, tokens_out)

                finish_reasons = [stop_reason] if stop_reason else []

                span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, tokens_in)
                span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, tokens_out)
                span.set_attribute(GenAIAttributes.RESPONSE_MODEL, response_model)
                span.set_attribute(GenAIAttributes.RESPONSE_FINISH_REASONS, finish_reasons)
                span.set_attribute(WaxellAttributes.LLM_MODEL, response_model)
                span.set_attribute(WaxellAttributes.LLM_INPUT_TOKENS, tokens_in)
                span.set_attribute(WaxellAttributes.LLM_OUTPUT_TOKENS, tokens_out)
                span.set_attribute(WaxellAttributes.LLM_TOTAL_TOKENS, tokens_in + tokens_out)
                span.set_attribute(WaxellAttributes.LLM_COST, cost)
            else:
                # Non-dict response (e.g. streaming) -- just set model
                span.set_attribute(WaxellAttributes.LLM_MODEL, model)
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API
        try:
            _record_http_generate(result, model, kwargs, instance)
        except Exception:
            pass

        return result
    finally:
        span.end()


def _sync_generate_text_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for WatsonX ``ModelInference.generate_text``.

    generate_text() is a convenience method that returns just the text string.
    We still create a span but with limited usage info.
    """
    try:
        from ..tracing.spans import start_llm_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    try:
        span = start_llm_span(model=model, provider_name="watsonx")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            span.set_attribute(WaxellAttributes.LLM_MODEL, model)
            if isinstance(result, str):
                # generate_text returns just the text, limited info available
                pass
        except Exception as attr_exc:
            logger.debug("Failed to set span attributes: %s", attr_exc)

        return result
    finally:
        span.end()


def _sync_embed_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for WatsonX ``Embeddings.embed_documents``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
    except Exception:
        return wrapped(*args, **kwargs)

    model = _get_model_from_instance(instance)

    # Count input documents
    docs = args[0] if args else kwargs.get("documents", [])
    if isinstance(docs, list):
        input_count = len(docs)
    elif isinstance(docs, str):
        input_count = 1
    else:
        input_count = 1

    try:
        span = start_embedding_span(
            model=model, provider_name="watsonx", input_count=input_count
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            dimensions = 0
            if isinstance(result, list) and len(result) > 0:
                first = result[0]
                if isinstance(first, list):
                    dimensions = len(first)

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
        except Exception as attr_exc:
            logger.debug("Failed to set embedding span attributes: %s", attr_exc)

        # Dual-path: record to HTTP API
        try:
            _record_http_embedding(result, model, kwargs, input_count)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_http_generate(
    result, request_model: str, kwargs: dict, instance=None
) -> None:
    """Record a WatsonX generate call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    generated_text = ""
    tokens_in = 0
    tokens_out = 0
    model_id = request_model

    if isinstance(result, dict):
        generated_text, tokens_in, tokens_out, _, model_id = _extract_generate_result(result)
        if not model_id:
            model_id = request_model

    cost = _estimate_watsonx_cost(model_id, tokens_in, tokens_out)

    # Extract prompt preview
    prompt_preview = ""
    prompt = kwargs.get("prompt", None)
    if prompt:
        prompt_preview = str(prompt)[:500]

    response_preview = str(generated_text)[:500] if generated_text else ""

    call_data = {
        "model": model_id,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "cost": cost,
        "task": "generate",
        "prompt_preview": prompt_preview,
        "response_preview": response_preview,
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_http_embedding(
    result, model: str, kwargs: dict, input_count: int = 0
) -> None:
    """Record a WatsonX embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": 0,
        "tokens_out": 0,
        "cost": 0.0,
        "task": "embedding",
        "prompt_preview": f"[{model} embedding, {input_count} docs]",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
