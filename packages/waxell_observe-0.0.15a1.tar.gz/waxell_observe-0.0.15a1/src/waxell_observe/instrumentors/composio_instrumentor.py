"""Composio auto-instrumentor for waxell-observe.

Monkey-patches ``composio.ComposioToolSet.execute_action``,
``ComposioToolSet.get_tools``, and ``ComposioToolSet.get_actions``
to emit OTel spans and record to the Waxell HTTP API.

Composio is a tool integration layer providing 250+ pre-built
integrations (GitHub, Slack, Gmail, etc.) that works with LangChain,
CrewAI, OpenAI, Anthropic, and more.

All wrapper code is wrapped in try/except -- never breaks the user's code.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class ComposioInstrumentor(BaseInstrumentor):
    """Instrumentor for the Composio tool integration layer (``composio-core`` package).

    Patches ComposioToolSet.execute_action, get_tools, and get_actions.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import composio  # noqa: F401
        except ImportError:
            logger.debug("composio not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt not installed -- skipping Composio instrumentation")
            return False

        patched = False

        # Patch ComposioToolSet.execute_action (main execution method)
        try:
            wrapt.wrap_function_wrapper(
                "composio",
                "ComposioToolSet.execute_action",
                _execute_action_wrapper,
            )
            patched = True
        except Exception as exc:
            logger.debug("Failed to patch ComposioToolSet.execute_action: %s", exc)

        # Patch ComposioToolSet.get_tools
        try:
            wrapt.wrap_function_wrapper(
                "composio",
                "ComposioToolSet.get_tools",
                _get_tools_wrapper,
            )
        except Exception:
            pass

        # Patch ComposioToolSet.get_actions
        try:
            wrapt.wrap_function_wrapper(
                "composio",
                "ComposioToolSet.get_actions",
                _get_actions_wrapper,
            )
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find Composio methods to patch")
            return False

        self._instrumented = True
        logger.debug("Composio instrumented (ComposioToolSet.execute_action + get_tools + get_actions)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            from composio import ComposioToolSet

            for method_name in ["execute_action", "get_tools", "get_actions"]:
                method = getattr(ComposioToolSet, method_name, None)
                if method and hasattr(method, "__wrapped__"):
                    setattr(ComposioToolSet, method_name, method.__wrapped__)
        except (ImportError, AttributeError):
            pass

        self._instrumented = False
        logger.debug("Composio uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _execute_action_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``ComposioToolSet.execute_action``."""
    try:
        from ..tracing.spans import start_tool_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract action name
    action_name = "unknown_action"
    try:
        action = kwargs.get("action") or (args[0] if args else None)
        if action is not None:
            # Action can be an enum (Action.GITHUB_CREATE_ISSUE) or string
            action_name = getattr(action, "name", None) or getattr(action, "value", None) or str(action)
    except Exception:
        pass

    # Extract app name from action (e.g., GITHUB_CREATE_ISSUE -> GITHUB)
    app_name = ""
    try:
        parts = action_name.split("_")
        if len(parts) > 1:
            app_name = parts[0].lower()
    except Exception:
        pass

    # Extract param keys (not values, for security)
    param_keys = []
    try:
        params = kwargs.get("params") or (args[1] if len(args) > 1 else None)
        if isinstance(params, dict):
            param_keys = list(params.keys())
    except Exception:
        pass

    try:
        span = start_tool_span(tool_name=f"composio:{action_name}")
        span.set_attribute("waxell.composio.system", "composio")
        span.set_attribute("waxell.composio.action", action_name)
        if app_name:
            span.set_attribute("waxell.composio.app", app_name)
        if param_keys:
            span.set_attribute("waxell.composio.param_keys", param_keys)
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            _set_execute_result_attributes(span, result, action_name)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _get_tools_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``ComposioToolSet.get_tools``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract action names for the span
    action_names = []
    try:
        actions = kwargs.get("actions") or (args[0] if args else [])
        if actions:
            for action in actions:
                name = getattr(action, "name", None) or getattr(action, "value", None) or str(action)
                action_names.append(name)
    except Exception:
        pass

    try:
        span = start_step_span(step_name="composio:get_tools")
        span.set_attribute("waxell.composio.system", "composio")
        span.set_attribute("waxell.composio.operation", "get_tools")
        if action_names:
            span.set_attribute("waxell.composio.requested_actions", action_names)
            span.set_attribute("waxell.composio.requested_action_count", len(action_names))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tool_count = len(result) if result else 0
            span.set_attribute("waxell.composio.tools_returned", tool_count)
        except Exception:
            pass
        return result
    finally:
        span.end()


def _get_actions_wrapper(wrapped, instance, args, kwargs):
    """Wrapper for ``ComposioToolSet.get_actions``."""
    try:
        from ..tracing.spans import start_step_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract app names
    app_names = []
    try:
        apps = kwargs.get("apps") or (args[0] if args else [])
        if apps:
            for app in apps:
                name = getattr(app, "name", None) or getattr(app, "value", None) or str(app)
                app_names.append(name)
    except Exception:
        pass

    try:
        span = start_step_span(step_name="composio:get_actions")
        span.set_attribute("waxell.composio.system", "composio")
        span.set_attribute("waxell.composio.operation", "get_actions")
        if app_names:
            span.set_attribute("waxell.composio.requested_apps", app_names)
            span.set_attribute("waxell.composio.requested_app_count", len(app_names))
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            action_count = len(result) if result else 0
            span.set_attribute("waxell.composio.actions_returned", action_count)
        except Exception:
            pass
        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _set_execute_result_attributes(span, result, action_name: str) -> None:
    """Set result attributes on the span for an execute_action response."""
    # execute_action returns dict with: response_data, status, error
    status = "unknown"
    try:
        if isinstance(result, dict):
            status = result.get("status", "unknown")
            error = result.get("error", None)
            span.set_attribute("waxell.composio.status", str(status))
            if error:
                span.set_attribute("waxell.composio.error", str(error)[:500])
        else:
            # Some versions may return an object
            status = getattr(result, "status", "unknown")
            span.set_attribute("waxell.composio.status", str(status))
            error = getattr(result, "error", None)
            if error:
                span.set_attribute("waxell.composio.error", str(error)[:500])
    except Exception:
        pass

    # Record to context
    try:
        from ._context_var import _current_context

        ctx = _current_context.get()
        if ctx and ctx.run_id:
            ctx.record_step(
                f"composio:{action_name}",
                output={"action": action_name, "status": str(status)},
            )
    except Exception:
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
