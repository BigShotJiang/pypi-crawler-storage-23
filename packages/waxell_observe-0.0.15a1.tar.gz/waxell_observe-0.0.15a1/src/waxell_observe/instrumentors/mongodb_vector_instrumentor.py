"""MongoDB Atlas Vector Search auto-instrumentor for waxell-observe.

Monkey-patches PyMongo's Collection methods to emit OTel spans when
Atlas Vector Search operations are detected.

Patched methods:
  - ``pymongo.collection.Collection.aggregate`` (retrieval span when $vectorSearch stage present)
  - ``pymongo.collection.Collection.find``      (pass-through with minimal overhead)

The key insight: only aggregate() calls whose pipeline starts with a
``$vectorSearch`` stage are instrumented as retrieval spans. Regular
aggregations pass through without creating spans.

All wrapper code is wrapped in try/except -- never breaks the user's MongoDB calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MongoDBVectorInstrumentor(BaseInstrumentor):
    """Instrumentor for MongoDB Atlas Vector Search via PyMongo.

    Patches ``Collection.aggregate`` to detect ``$vectorSearch`` stages
    and emit retrieval spans. Non-vector aggregations pass through
    without any span overhead.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        try:
            import pymongo.collection  # noqa: F401
        except ImportError:
            logger.debug("pymongo package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping MongoDB Vector instrumentation")
            return False

        wrapt.wrap_function_wrapper(
            "pymongo.collection",
            "Collection.aggregate",
            _aggregate_wrapper,
        )

        self._instrumented = True
        logger.debug("MongoDB Collection instrumented (aggregate for $vectorSearch)")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        try:
            import pymongo.collection as mod

            if hasattr(mod.Collection.aggregate, "__wrapped__"):
                mod.Collection.aggregate = mod.Collection.aggregate.__wrapped__  # type: ignore[attr-defined]
        except ImportError:
            pass

        self._instrumented = False
        logger.debug("MongoDB Collection uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _is_vector_search_pipeline(pipeline) -> bool:
    """Check if the pipeline starts with a $vectorSearch stage."""
    try:
        if not pipeline:
            return False
        if isinstance(pipeline, (list, tuple)) and len(pipeline) > 0:
            first_stage = pipeline[0]
            if isinstance(first_stage, dict) and "$vectorSearch" in first_stage:
                return True
    except Exception:
        pass
    return False


def _extract_vector_search_params(pipeline) -> dict:
    """Extract parameters from a $vectorSearch stage."""
    params: dict = {}
    try:
        if not pipeline or not isinstance(pipeline, (list, tuple)):
            return params
        first_stage = pipeline[0]
        if not isinstance(first_stage, dict):
            return params
        vs = first_stage.get("$vectorSearch", {})
        if isinstance(vs, dict):
            params["index"] = vs.get("index", "")
            params["path"] = vs.get("path", "")
            params["num_candidates"] = vs.get("numCandidates", 0)
            params["limit"] = vs.get("limit", 0)
    except Exception:
        pass
    return params


def _aggregate_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for MongoDB ``Collection.aggregate``.

    Only creates a retrieval span when the pipeline contains a $vectorSearch stage.
    Regular aggregations pass through without span creation.
    """
    # Extract pipeline from args/kwargs
    pipeline = kwargs.get("pipeline", args[0] if args else None)

    # If this is not a vector search pipeline, pass through immediately
    if not _is_vector_search_pipeline(pipeline):
        return wrapped(*args, **kwargs)

    try:
        from ..tracing.spans import start_retrieval_span
    except Exception:
        return wrapped(*args, **kwargs)

    # Extract vector search parameters
    vs_params = _extract_vector_search_params(pipeline)
    index_name = vs_params.get("index", "")
    num_candidates = vs_params.get("num_candidates", 0)
    limit = vs_params.get("limit", 0)

    # Get collection name from instance
    collection_name = ""
    try:
        collection_name = getattr(instance, "name", "") or ""
    except Exception:
        pass

    query_preview = (
        f"mongodb.vector_search(collection={collection_name!r}, "
        f"index={index_name!r}, limit={limit})"
    )

    try:
        span = start_retrieval_span(query=query_preview, source="mongodb")
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        response = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            # aggregate() returns a CommandCursor -- we record the call metadata
            # but don't iterate the cursor (that would consume it)
            span.set_attribute("waxell.retrieval.source", "mongodb")
            if collection_name:
                span.set_attribute("db.mongodb.collection_name", collection_name)
            if index_name:
                span.set_attribute("db.mongodb.vector_index", index_name)
            if num_candidates:
                span.set_attribute("db.mongodb.num_candidates", num_candidates)
            if limit:
                span.set_attribute("waxell.retrieval.top_k", limit)
        except Exception as attr_exc:
            logger.debug("Failed to set MongoDB vector search span attributes: %s", attr_exc)

        try:
            _record_mongodb_retrieval(
                query=query_preview,
                collection_name=collection_name,
                index_name=index_name,
                limit=limit,
            )
        except Exception:
            pass

        return response
    finally:
        span.end()


# ---------------------------------------------------------------------------
# HTTP dual-path recording
# ---------------------------------------------------------------------------


def _record_mongodb_retrieval(
    query: str,
    collection_name: str,
    index_name: str,
    limit: int,
) -> None:
    """Record a MongoDB vector search operation to the context path.

    Vector DB retrievals are only meaningful within an active WaxellContext run.
    When no context is active, we skip the collector.
    """
    from ._context_var import _current_context

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_retrieval(
            query=query,
            source="mongodb",
            documents=[],
            top_k=limit if limit else None,
        )
    else:
        # Skip collector for vector DB ops -- only relevant inside a context.
        pass


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode
        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
