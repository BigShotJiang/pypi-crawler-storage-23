"""MixedBread AI auto-instrumentor for waxell-observe.

Monkey-patches ``MixedbreadAI.embeddings`` to emit embedding spans
tracking remote embedding generation via the MixedBread API.

The ``mixedbread-ai`` package provides models like mxbai-embed-large-v1
and mxbai-embed-2d-large-v1. Token counts are extracted from
``result.usage.total_tokens`` and dimensions from the first embedding
vector.

All wrapper code is wrapped in try/except -- never breaks the user's calls.
"""

from __future__ import annotations

import logging

from ._base import BaseInstrumentor

logger = logging.getLogger(__name__)


class MixedbreadInstrumentor(BaseInstrumentor):
    """Instrumentor for the MixedBread AI Python SDK (``mixedbread-ai`` package).

    Patches ``MixedbreadAI.embeddings`` to emit embedding spans.
    """

    _instrumented: bool = False

    def instrument(self) -> bool:
        if self._instrumented:
            return True

        # Try primary import path
        _module = None
        try:
            import mixedbread_ai  # noqa: F401

            _module = "mixedbread_ai"
        except ImportError:
            pass

        if _module is None:
            try:
                import mixedbread  # noqa: F401

                _module = "mixedbread"
            except ImportError:
                pass

        if _module is None:
            logger.debug("mixedbread-ai package not installed -- skipping instrumentation")
            return False

        try:
            import wrapt
        except ImportError:
            logger.debug("wrapt package not installed -- skipping MixedBread instrumentation")
            return False

        patched = False

        # MixedbreadAI.embeddings
        try:
            wrapt.wrap_function_wrapper(
                _module,
                "MixedbreadAI.embeddings",
                _sync_embeddings_wrapper,
            )
            patched = True
            logger.debug("MixedBread MixedbreadAI.embeddings patched")
        except Exception:
            pass

        if not patched:
            logger.debug("Could not find MixedBread MixedbreadAI.embeddings to patch")
            return False

        self._instrumented = True
        logger.debug("MixedBread embeddings instrumented")
        return True

    def uninstrument(self) -> None:
        if not self._instrumented:
            return

        # Try both import paths
        for module_name in ("mixedbread_ai", "mixedbread"):
            try:
                import importlib

                mod = importlib.import_module(module_name)
                cls = getattr(mod, "MixedbreadAI", None)
                if cls is not None:
                    method = getattr(cls, "embeddings", None)
                    if method is not None and hasattr(method, "__wrapped__"):
                        cls.embeddings = method.__wrapped__  # type: ignore[attr-defined]
            except (ImportError, AttributeError):
                pass

        self._instrumented = False
        logger.debug("MixedBread embeddings uninstrumented")

    def is_instrumented(self) -> bool:
        return self._instrumented


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_input(args, kwargs):
    """Extract input texts from MixedbreadAI.embeddings call arguments.

    Signature: client.embeddings(model=..., input=[...])
    """
    inp = kwargs.get("input", None)
    if inp is not None:
        return inp
    # Positional: model is first, input is second
    if len(args) >= 2:
        return args[1]
    if len(args) >= 1:
        return args[0]
    return []


def _extract_model(args, kwargs):
    """Extract model name from MixedbreadAI.embeddings call arguments."""
    model = kwargs.get("model", None)
    if model is not None:
        return str(model)
    return "mixedbread-ai/mxbai-embed-large-v1"


def _extract_tokens(result):
    """Extract total token count from a MixedBread embeddings result.

    Result has ``usage`` attribute with ``prompt_tokens`` and ``total_tokens``.
    """
    usage = getattr(result, "usage", None)
    if usage is None:
        return 0
    total = getattr(usage, "total_tokens", 0)
    if total:
        return total
    prompt = getattr(usage, "prompt_tokens", 0)
    if prompt:
        return prompt
    return 0


def _extract_dimensions(result):
    """Extract embedding dimensions from a MixedBread embeddings result.

    Result has ``data`` attribute: list of objects with ``embedding`` (list of floats).
    """
    data = getattr(result, "data", None)
    if not data or not isinstance(data, list) or len(data) == 0:
        return 0
    first = data[0]
    embedding = getattr(first, "embedding", None)
    if embedding is None:
        return 0
    if isinstance(embedding, list):
        return len(embedding)
    if hasattr(embedding, "shape"):
        try:
            return int(embedding.shape[-1]) if len(embedding.shape) > 0 else 0
        except Exception:
            pass
    return 0


# ---------------------------------------------------------------------------
# Wrapper functions
# ---------------------------------------------------------------------------


def _sync_embeddings_wrapper(wrapped, instance, args, kwargs):
    """Sync wrapper for ``MixedbreadAI.embeddings``."""
    try:
        from ..tracing.spans import start_embedding_span
        from ..tracing.attributes import WaxellAttributes
        from ..cost import estimate_embedding_cost
    except Exception:
        return wrapped(*args, **kwargs)

    model = _extract_model(args, kwargs)
    inp = _extract_input(args, kwargs)
    if isinstance(inp, str):
        input_count = 1
    elif isinstance(inp, list):
        input_count = len(inp)
    else:
        input_count = 1

    try:
        span = start_embedding_span(
            model=model,
            provider_name="mixedbread",
            input_count=input_count,
        )
    except Exception:
        return wrapped(*args, **kwargs)

    try:
        result = wrapped(*args, **kwargs)
    except Exception as exc:
        _record_error(span, exc)
        raise
    else:
        try:
            tokens = _extract_tokens(result)
            dimensions = _extract_dimensions(result)
            cost = estimate_embedding_cost(model, tokens, "mixedbread")

            span.set_attribute(WaxellAttributes.EMBEDDING_MODEL, model)
            span.set_attribute(WaxellAttributes.EMBEDDING_DIMENSIONS, dimensions)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_COUNT, input_count)
            span.set_attribute(WaxellAttributes.EMBEDDING_INPUT_TOKENS, tokens)
            span.set_attribute(WaxellAttributes.EMBEDDING_COST, cost)
        except Exception as attr_exc:
            logger.debug("Failed to set MixedBread embed span attributes: %s", attr_exc)

        try:
            _record_http_mixedbread_embed(model, input_count, tokens, dimensions, cost)
        except Exception:
            pass

        return result
    finally:
        span.end()


# ---------------------------------------------------------------------------
# Dual-path context recording
# ---------------------------------------------------------------------------


def _record_http_mixedbread_embed(
    model: str, input_count: int, tokens: int = 0, dimensions: int = 0, cost: float = 0.0
) -> None:
    """Record a MixedBread embedding call to the HTTP path."""
    from ._context_var import _current_context
    from ._collector import _collector

    call_data = {
        "model": model,
        "tokens_in": tokens,
        "tokens_out": 0,
        "cost": cost,
        "task": "embedding:mixedbread",
        "prompt_preview": f"embed {input_count} text(s), dim={dimensions}",
        "response_preview": "",
    }

    ctx = _current_context.get()
    if ctx and ctx.run_id:
        ctx.record_llm_call(**call_data)
    else:
        _collector.record_call(call_data)


# ---------------------------------------------------------------------------
# Error helper
# ---------------------------------------------------------------------------


def _record_error(span, exc: Exception) -> None:
    """Record an exception on a span."""
    try:
        span.record_exception(exc)
        from opentelemetry.trace import StatusCode

        span.set_status(StatusCode.ERROR, str(exc))
    except Exception:
        pass
