"""@waxell.reasoning decorator for automatic reasoning/chain-of-thought recording.

Wraps any function that performs a reasoning step so that the thought
process, evidence, and conclusion are automatically recorded on the
current WaxellContext.

Usage::

    import waxell_observe as waxell

    @waxell.reasoning(step="quality_check")
    async def assess_quality(answer: str, sources: list) -> dict:
        return {
            "thought": "Answer covers all source material",
            "evidence": ["Source A cited", "Source B referenced"],
            "conclusion": "High quality, ready to present",
        }

    # Returns the dict AND auto-records:
    #   reasoning(step="quality_check", thought="...", evidence=[...], conclusion="...")

For simple returns::

    @waxell.reasoning(step="evaluate")
    def evaluate(data: str) -> str:
        return "The data looks consistent with previous results"
    # Uses the string as ``thought``.
"""

import functools
import inspect
import time
from typing import Optional

from .instrumentors._context_var import _current_context


def reasoning(
    step: Optional[str] = None,
):
    """Decorator to auto-record a function's return value as a reasoning step.

    Args:
        step: Reasoning step name (e.g. "evaluate_sources", "quality_check").
            Defaults to the function name.
    """

    def decorator(func):
        _step_name = step or func.__name__
        _is_async = inspect.iscoroutinefunction(func)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            ctx = _current_context.get()
            t0 = time.perf_counter()

            result = await func(*args, **kwargs)

            if ctx:
                _record(ctx, _step_name, result)
            return result

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            ctx = _current_context.get()
            t0 = time.perf_counter()

            result = func(*args, **kwargs)

            if ctx:
                _record(ctx, _step_name, result)
            return result

        return async_wrapper if _is_async else sync_wrapper

    return decorator


def _record(ctx, step_name: str, result):
    """Extract reasoning fields from result and record on context."""
    if isinstance(result, dict):
        thought = str(result.get("thought", ""))
        evidence = result.get("evidence")
        conclusion = str(result.get("conclusion", ""))
    else:
        thought = str(result)
        evidence = None
        conclusion = ""

    ctx.record_reasoning(
        step=step_name,
        thought=thought,
        evidence=evidence,
        conclusion=conclusion,
    )
