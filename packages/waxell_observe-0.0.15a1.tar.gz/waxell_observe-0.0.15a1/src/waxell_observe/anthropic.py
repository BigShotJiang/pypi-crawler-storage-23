"""Drop-in Anthropic wrapper with automatic Waxell instrumentation.

Usage::

    from waxell_observe.anthropic import anthropic

    # Every call is now automatically traced:
    client = anthropic.Anthropic()
    response = client.messages.create(
        model="claude-sonnet-4-5-20250929",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hello!"}],
    )

This is equivalent to calling ``waxell.init()`` and then using the
``anthropic`` module normally, but scoped to a single import.
"""

from __future__ import annotations

import anthropic as _anthropic  # type: ignore[import-untyped]

from waxell_observe.instrumentors import instrument_all

# Instrument Anthropic on import — idempotent if already instrumented.
instrument_all(libraries=["anthropic"])

# Re-export the real module so callers get the (now-patched) anthropic.
anthropic = _anthropic

__all__ = ["anthropic"]
