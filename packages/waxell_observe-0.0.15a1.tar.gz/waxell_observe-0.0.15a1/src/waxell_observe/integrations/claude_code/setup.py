"""Setup command for Claude Code integration.

Generates hook configuration in .claude/settings.json and
optionally registers the MCP server in .mcp.json.
"""

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def setup_hooks(
    project_dir: Optional[str] = None,
    global_config: bool = False,
    governance: bool = False,
    mcp: bool = False,
) -> dict:
    """Configure Claude Code hooks for Waxell observability.

    Args:
        project_dir: Project directory (defaults to cwd).
        global_config: Write to ~/.claude/settings.json instead of project.
        governance: Enable PreToolUse blocking hooks for policy enforcement.
        mcp: Register MCP server in .mcp.json.

    Returns:
        dict with 'hooks_path', 'mcp_path' (if applicable), and 'summary'.
    """
    result = {"summary": []}

    # Determine settings path
    if global_config:
        settings_path = Path.home() / ".claude" / "settings.json"
    else:
        base = Path(project_dir) if project_dir else Path.cwd()
        settings_path = base / ".claude" / "settings.json"

    # Build hook configuration
    hooks_config = _build_hooks_config(governance)

    # Merge with existing settings
    _merge_settings(settings_path, hooks_config)
    result["hooks_path"] = str(settings_path)
    result["summary"].append(f"Hooks written to {settings_path}")

    if governance:
        result["summary"].append("Governance enabled: PreToolUse hooks will enforce policies on Bash, Edit, Write")

    # MCP server registration
    if mcp:
        if global_config:
            mcp_path = Path.home() / ".claude" / ".mcp.json"
        else:
            base = Path(project_dir) if project_dir else Path.cwd()
            mcp_path = base / ".mcp.json"

        _merge_mcp_config(mcp_path)
        result["mcp_path"] = str(mcp_path)
        result["summary"].append(f"MCP server registered in {mcp_path}")

    return result


def _build_hooks_config(governance: bool) -> dict:
    """Build the hooks configuration dict."""
    hooks: dict = {
        "SessionStart": [
            {
                "matcher": "startup",
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 10,
                    }
                ],
            },
            {
                "matcher": "resume",
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 10,
                    }
                ],
            },
        ],
        "PostToolUse": [
            {
                "matcher": ".*",
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 10,
                        "async": True,
                    }
                ],
            },
        ],
        "PostToolUseFailure": [
            {
                "matcher": ".*",
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 10,
                        "async": True,
                    }
                ],
            },
        ],
        "SubagentStart": [
            {
                "matcher": ".*",
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 10,
                        "async": True,
                    }
                ],
            },
        ],
        "SubagentStop": [
            {
                "matcher": ".*",
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 10,
                    }
                ],
            },
        ],
        "TeammateIdle": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 10,
                        "async": True,
                    }
                ],
            },
        ],
        "Stop": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 30,
                    }
                ],
            },
        ],
        "SessionEnd": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 30,
                    }
                ],
            },
        ],
    }

    # Add governance hooks (sync, can block)
    if governance:
        hooks["PreToolUse"] = [
            {
                "matcher": "Bash|Edit|Write",
                "hooks": [
                    {
                        "type": "command",
                        "command": "wax observe claude-code hook",
                        "timeout": 5,
                    }
                ],
            },
        ]

    return hooks


def _merge_settings(path: Path, hooks_config: dict) -> None:
    """Merge hook config into existing settings.json, preserving other settings."""
    path.parent.mkdir(parents=True, exist_ok=True)

    existing = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text())
        except (json.JSONDecodeError, IOError):
            existing = {}

    # Merge hooks — our hooks get added alongside any existing hooks
    existing_hooks = existing.get("hooks", {})

    for event_name, event_hooks in hooks_config.items():
        if event_name not in existing_hooks:
            existing_hooks[event_name] = event_hooks
        else:
            # Check if waxell hook already exists for this event
            existing_list = existing_hooks[event_name]
            has_waxell = any(
                any(
                    "wax observe claude-code" in (h.get("command", ""))
                    for h in entry.get("hooks", [])
                )
                for entry in existing_list
            )
            if not has_waxell:
                existing_hooks[event_name].extend(event_hooks)
            else:
                # Update existing waxell hooks in place
                for i, entry in enumerate(existing_list):
                    if any(
                        "wax observe claude-code" in (h.get("command", ""))
                        for h in entry.get("hooks", [])
                    ):
                        existing_list[i] = event_hooks[0] if event_hooks else entry

    existing["hooks"] = existing_hooks
    path.write_text(json.dumps(existing, indent=2) + "\n")


def _merge_mcp_config(path: Path) -> None:
    """Register the Waxell MCP server in .mcp.json."""
    path.parent.mkdir(parents=True, exist_ok=True)

    existing = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text())
        except (json.JSONDecodeError, IOError):
            existing = {}

    servers = existing.get("mcpServers", {})
    servers["waxell-observe"] = {
        "type": "stdio",
        "command": "wax",
        "args": ["observe", "claude-code", "mcp-server"],
    }
    existing["mcpServers"] = servers
    path.write_text(json.dumps(existing, indent=2) + "\n")
