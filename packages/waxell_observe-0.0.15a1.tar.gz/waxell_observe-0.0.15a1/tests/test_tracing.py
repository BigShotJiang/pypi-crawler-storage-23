"""OTel span creation and attribute tests."""

import pytest

pytest.importorskip("opentelemetry.sdk.trace")

from waxell_observe.tracing.spans import (
    start_agent_span,
    start_llm_span,
    start_step_span,
    start_tool_span,
)
from waxell_observe.tracing.attributes import GenAIAttributes, WaxellAttributes
from waxell_observe.tracing._compat import NoOpSpan, _safe_attr
import waxell_observe.tracing._compat as compat_module


class TestAgentSpan:
    def test_agent_span_attributes(self, span_exporter):
        """Agent span has correct waxell and gen_ai attributes."""
        span = start_agent_span(
            agent_name="my-agent",
            workflow_name="default",
            run_id="run-1",
        )
        span.end()

        spans = span_exporter.get_finished_spans()
        assert len(spans) == 1

        s = spans[0]
        assert s.name == "invoke_agent my-agent"
        attrs = dict(s.attributes)
        assert attrs[WaxellAttributes.AGENT_NAME] == "my-agent"
        assert attrs[WaxellAttributes.WORKFLOW_NAME] == "default"
        assert attrs[WaxellAttributes.RUN_ID] == "run-1"
        assert attrs[WaxellAttributes.SPAN_TYPE] == "agent_execution"
        assert attrs[GenAIAttributes.OPERATION_NAME] == "invoke_agent"
        assert attrs[GenAIAttributes.AGENT_NAME] == "my-agent"

    def test_session_id_in_agent_span(self, span_exporter):
        """Extra attributes like session_id appear on agent span."""
        span = start_agent_span(
            agent_name="test-agent",
            workflow_name="default",
            run_id="run-2",
            extra_attrs={WaxellAttributes.SESSION_ID: "sess_abc123"},
        )
        span.end()

        spans = span_exporter.get_finished_spans()
        assert len(spans) == 1
        attrs = dict(spans[0].attributes)
        assert attrs[WaxellAttributes.SESSION_ID] == "sess_abc123"


class TestLlmSpan:
    def test_llm_span_attributes(self, span_exporter):
        """LLM span has correct model, token, and cost attributes."""
        span = start_llm_span(
            model="gpt-4o",
            tokens_in=100,
            tokens_out=50,
            cost=0.001,
        )
        span.end()

        spans = span_exporter.get_finished_spans()
        assert len(spans) == 1

        s = spans[0]
        assert s.name == "chat gpt-4o"
        attrs = dict(s.attributes)
        assert attrs[WaxellAttributes.LLM_MODEL] == "gpt-4o"
        assert attrs[WaxellAttributes.LLM_INPUT_TOKENS] == 100
        assert attrs[WaxellAttributes.LLM_OUTPUT_TOKENS] == 50
        assert attrs[WaxellAttributes.LLM_TOTAL_TOKENS] == 150
        assert attrs[WaxellAttributes.LLM_COST] == 0.001
        assert attrs[WaxellAttributes.SPAN_TYPE] == "llm_call"
        assert attrs[GenAIAttributes.REQUEST_MODEL] == "gpt-4o"

    def test_llm_span_infers_openai_provider(self, span_exporter):
        """gpt-4o model infers openai as provider."""
        span = start_llm_span(model="gpt-4o", tokens_in=10, tokens_out=5)
        span.end()

        spans = span_exporter.get_finished_spans()
        attrs = dict(spans[0].attributes)
        assert attrs[GenAIAttributes.PROVIDER_NAME] == "openai"

    def test_llm_span_infers_anthropic_provider(self, span_exporter):
        """claude-sonnet-4 model infers anthropic as provider."""
        span = start_llm_span(model="claude-sonnet-4", tokens_in=10, tokens_out=5)
        span.end()

        spans = span_exporter.get_finished_spans()
        attrs = dict(spans[0].attributes)
        assert attrs[GenAIAttributes.PROVIDER_NAME] == "anthropic"


class TestStepSpan:
    def test_step_span_attributes(self, span_exporter):
        """Step span has correct step name and position attributes."""
        span = start_step_span(step_name="retrieve", position=1)
        span.end()

        spans = span_exporter.get_finished_spans()
        assert len(spans) == 1

        s = spans[0]
        assert s.name == "step retrieve"
        attrs = dict(s.attributes)
        assert attrs[WaxellAttributes.STEP_NAME] == "retrieve"
        assert attrs[WaxellAttributes.STEP_POSITION] == 1
        assert attrs[WaxellAttributes.SPAN_TYPE] == "workflow_step"


class TestToolSpan:
    def test_tool_span_attributes(self, span_exporter):
        """Tool span has correct tool name and type attributes."""
        span = start_tool_span(tool_name="search")
        span.end()

        spans = span_exporter.get_finished_spans()
        assert len(spans) == 1

        s = spans[0]
        assert s.name == "execute_tool search"
        attrs = dict(s.attributes)
        assert attrs[GenAIAttributes.TOOL_NAME] == "search"
        assert attrs[GenAIAttributes.TOOL_TYPE] == "function"
        assert attrs[WaxellAttributes.TOOL] == "search"
        assert attrs[WaxellAttributes.SPAN_TYPE] == "tool_call"


class TestNoOpFallback:
    def test_noop_span_when_no_provider(self):
        """Returns NoOpSpan when no provider is set."""
        old_provider = compat_module._provider
        try:
            compat_module._provider = None
            span = start_agent_span(agent_name="test", run_id="run-x")
            assert isinstance(span, NoOpSpan)
        finally:
            compat_module._provider = old_provider


class TestSafeAttr:
    def test_safe_attr_string(self):
        """String values pass through unchanged."""
        assert _safe_attr("hello") == "hello"

    def test_safe_attr_int(self):
        """Int values pass through unchanged."""
        assert _safe_attr(42) == 42

    def test_safe_attr_float(self):
        """Float values pass through unchanged."""
        assert _safe_attr(3.14) == 3.14

    def test_safe_attr_bool(self):
        """Bool values pass through unchanged."""
        assert _safe_attr(True) is True

    def test_safe_attr_dict_serialized(self):
        """Dict values are JSON-serialized."""
        result = _safe_attr({"key": "value", "num": 42})
        import json

        parsed = json.loads(result)
        assert parsed == {"key": "value", "num": 42}

    def test_safe_attr_list_filtered(self):
        """List values keep only OTel-compatible types."""
        result = _safe_attr([1, "two", 3.0, True])
        assert result == [1, "two", 3.0, True]

    def test_safe_attr_complex_type(self):
        """Complex types are converted to string."""

        class MyObj:
            def __str__(self):
                return "my-object"

        result = _safe_attr(MyObj())
        assert result == "my-object"
