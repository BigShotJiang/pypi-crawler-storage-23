"""Tests for TypeQL utilities."""
