// 向量相似度模块 - 现在只导出到 vector_similarity_optimized 模块
// 冗余函数已删除，只保留最高效的 ultra_fast 版本
