"""
Backend implementations for paperscout.
"""

from paperscout.backends.base import BaseBackend

__all__ = ["BaseBackend"]
