"""
Example input guardrail that blocks obvious PII in user input.

This is a deliberately simple, heuristic guardrail intended as a reference
only. It looks for a small set of patterns (email addresses, US‑style SSNs)
and triggers a tripwire when they are detected.

Usage sketch:

  from agents.guardrail import input_guardrail
  from agenterm.core.guardrails_registry import register_input_guardrail

  # Import the definitions below so that registration runs at import time:
  #   import examples.guardrails.no_pii_input  # noqa: F401
  #
  # Then in config.yaml:
  #
  #   guardrails:
  #     input:
  #       - no_pii_input
  #
# Both `agenterm run` and `agenterm` (interactive REPL) will then attach this guardrail to
# RunConfig.input_guardrails.
"""

from __future__ import annotations

import re

from agents.agent import Agent
from agents.guardrail import GuardrailFunctionOutput, input_guardrail
from agents.run_context import RunContextWrapper
from openai.types.responses.response_input_param import ResponseInputItemParam

from agenterm.core.guardrails_registry import register_input_guardrail


_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")


def _contains_simple_pii(text: str) -> bool:
    if not text:
        return False
    if _EMAIL_RE.search(text):
        return True
    if _SSN_RE.search(text):
        return True
    return False


def _text_from_items(items: list[ResponseInputItemParam]) -> str:
    """Best-effort extraction of user text from ResponseInputItemParam list."""
    out: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        if item.get("type") != "message":
            continue
        content = item.get("content")
        if not isinstance(content, list):
            continue
        for part in content:
            if isinstance(part, dict) and part.get("type") == "input_text":
                txt = part.get("text")
                if isinstance(txt, str) and txt:
                    out.append(txt)
    return " ".join(out)


@input_guardrail(name="no_pii_input", run_in_parallel=False)
def no_pii_input_guardrail(
    context: RunContextWrapper[object],
    agent: Agent[object],
    input: str | list[ResponseInputItemParam],
) -> GuardrailFunctionOutput:
    """Tripwire when obvious PII is present in the input."""
    if isinstance(input, str):
        text = input
    else:
        text = _text_from_items(input)
    if _contains_simple_pii(text):
        return GuardrailFunctionOutput(
            output_info={
                "reason": "pii_detected",
                "detail": "Obvious PII pattern in input.",
            },
            tripwire_triggered=True,
        )
    return GuardrailFunctionOutput(
        output_info={"reason": "ok"},
        tripwire_triggered=False,
    )


# Register under the same name used in config.yaml.
register_input_guardrail("no_pii_input", no_pii_input_guardrail)
