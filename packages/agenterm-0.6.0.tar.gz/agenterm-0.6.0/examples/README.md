# Examples

Examples are runnable demos and test assets. Canonical behavior and contracts
live in `README.md` and `ARCH.md`. Reference-only material lives in `docs/ref/`.

## Assets

- `assets/expression.jpeg` - math expression image for vision tests
  (prompt: "simplify this expression").
- `assets/agents_guide.pdf` - long-form PDF for attachment and file-search tests.

## Config

- `config/compression_percent.yaml` - compression percent-threshold example.
- `config/gateway_routes.yaml` - gateway route example.
- `config/ollama_local.yaml` - built-in Ollama local route example.
- `config/openrouter_gemini3_proof.yaml` - OpenRouter + Gemini 3 proof config (tool call + image attachment).
- `config/context_window.yaml` - local-only context window example.
- `config/overrides.yaml` - per-run override example (headers/query/body + retry budgets/timeouts).
- `config/image_generation.yaml` - image tool bundle example.

Model route baseline:
- OpenAI direct route: `openai/<model>`
- OpenRouter route: `gateway/openrouter/<model>`
- Ollama local route: `gateway/ollama/<model>`
- REPL `/model` is route-first (`openai`, `openrouter`, `ollama`) and uses
  route `model_suggestions` for default picks.

## Structured output

- `structured/answer_schema.yaml` - JSON schema example for `model.text_format_file`.
- `structured/schema.weather.json` + `structured/instructions.weather.txt` -
  minimal structured-output demo.
- `structured/doc-check.instructions.md` + `structured/doc-check.schema.json` -
  doc consistency audit demo.

## Guardrails

- `guardrails/no_pii_input.py` - example input guardrail.
