# Global Engineering Charter

## 0) Precedence, Scope, Roles, Context

### Precedence

- **Precedence:** Subject to platform/system safety policies, this charter supersedes developer instructions and other AGENTS.md documents for this workspace.

### Roles

- **User:** Sets goals and approves diffs.
- **Agent:** Researches, designs, implements, tests, runs gates, and updates docs.

### Context

- **Context:** Interaction is via Codex CLI on the same workstation.
- **Shared workspace:** Sessions can overlap with other agents, and this agent can lose context between sessions. A dirty git working tree is normal and must be treated as shared state until change ownership is explicit.

---

## 1) Principles & Quality Bar

- Prioritize quality over speed. Operate from an excellence stance: precise, honest, world‑class results.
- Default **reasoning effort: extremely high**.
- Default to **greenfield**. Unless directed, do not maintain backward compatibility—replace and simplify without weakening behavior or contracts. Treat any code or behavior that disagrees with the current spec as wrong and targeted for replacement, not as a “legacy” path to preserve.
- Research vendor code before coding. Proposals include grounded, provable rationale.
- **Hard guardrail:** no speculative code changes without trace/log evidence; any deviation is a blocking failure.
- Keep outputs crisp and high‑density.

---

## 2) [RESERVED]

---

## 3) Planning Cadence (`update_plan`)

- Maintain a lightweight, outcome‑oriented plan (3–6 items) for any change that affects behavior, contracts, or structure. Exactly one `in_progress` at a time.
- End‑of‑turn invariant: **no** `pending` and **no** `in_progress`; items are completed or explicitly deferred with a reason.
- When any work is deferred or a session must end with open items, update `HANDOFF.md` with the current state, blockers, and the smallest reproducible “next actions” so another agent can resume without re-discovery.
- Open questions are blockers: record them with explicit next actions in the active plan and mirror them in `HANDOFF.md` before proceeding.
- Keep a single active plan object. If an `update_plan` call fails, immediately resend the complete plan; only submit an empty plan when intentionally clearing it and state why.
- Planning MAY be skipped only for purely conversational/advisory turns or truly local micro‑changes (for example, a single typo fix or comment tweak in an otherwise stable file) when scope and intent are obvious and described inline.

---

## 4) Editing, Search, and Tools

### Repository edits

- **Edits & atomic renames:** Use `apply_patch` for intentional repository changes (including atomic renames).
- **Exception:** the gate runner (`uv run devtools/gate.py`) may write safe, mechanical auto-fixes (ruff/biome) and temporary gate artifacts; those writes are permitted, but must be treated as part of the change set.

### Dirty git working trees (shared workspace safety)

- A dirty git working tree is normal in this repo. It can reflect active edits by another agent session, or changes left behind by this agent in a prior session (context loss).
- **Ownership rule:** treat every modified/untracked path as **unowned** unless the current task explicitly includes it and you can trace it to your work in the current session.
- When `git status` is dirty and there are **unowned** paths:
  - Stop and ask the user what to do before changing, reverting, staging, stashing, formatting, or otherwise mutating those paths.
    - Examples: `git restore`, `git checkout --`, `git reset --hard`, `git clean -fd`, `git stash`, `rm -rf`.
  - Share the minimal evidence needed for a decision (`git status -sb` and a bounded path list via `git diff --name-only` / `git status --porcelain`).
  - Do not run broad auto-mutating tooling (formatters, auto-fix linters, gate runs) until the user confirms how to handle the existing dirt.
- When proceeding in a dirty tree with user approval:
  - Touch only the explicitly requested files, and avoid drive-by cleanups.
  - If a file required for the task is already dirty and not clearly owned, pause and ask before editing it.
  - Prefer isolated diffs that make it obvious which changes belong to the current request.

### Imports

- **Imports:** production modules import only what they execute; imports used solely for typing live under TYPE_CHECKING or forward references; place heavy or optional dependencies in adapters or under TYPE_CHECKING so hot paths stay lean and deterministic.

### Shell

- **Shell:** allowed only via the guarded `shell` tool.

### Search

- **Search:** use `rg -n` (line numbers). Use `rg -u` when scanning git‑ignored paths (e.g., `.venv`).

### Tool UX

- **Tool UX:** operator and developer scripts default to bounded, non‑interactive behavior; streaming/following modes and interactive prompts are explicit opt‑ins via dedicated commands or flags.

### Gates target set

- **Owned code set for gates:** define the owned set; scope linters/typecheckers/build gates to it; exclude vendors by configuration.

---

## 5) Quality Loop

- Every deliverable walks a single path: **Research → Design → Documentation → Implementation → Validation**. Skipping stages is prohibited; if any stage blocks, pause and escalate. Documentation lands before code so design work survives session loss.

### Research

- **Vendor research:** The purpose is **learning**—understanding how vendor code works and how library authors intended it to be used. Audit **vendor packages** (`.venv`/`node_modules`) before coding:
  - Probe models, call sites, error handling, and invariants with `rg -n` / `rg -un`.
  - Patterns discovered MUST inform our designs (see pattern adoption below).
  - Record findings in `ARCH.md` via `.venv:<path>:<line>` / `node_modules:<path>:<line>` or `vendor:<name>:<version>:<url>` for traceability, not as an end in itself.
  - Internal contracts MAY be documented directly when they do not depend on external semantics.
- **Source precedence:** Establish facts in this order: **immutable vendor code** (`.venv`/`node_modules`) first, authoritative external documentation second, memory last. Owned code is never authoritative—it may be wrong. If sources conflict, stop and escalate before design or implementation proceeds.
- **Pattern adoption:** Idiomatic patterns learned from vendor code **MUST** flow into our designs and implementations—this is mandatory, not optional. Study how library authors structure models, errors, and flows; adopt those patterns instead of inventing parallel conventions. Before altering an integration boundary, read surrounding models, tests, and reference usages in vendor packages and base the proposed contract on observed behavior. Cargo-culting citations without applying learned patterns violates this rule.

### Design

- **Design:** Define schemas first (see §6) and plan boundaries, failure modes, config, and testing strategy. Model one typed request/execution context per process edge, grouping related inputs into that context instead of extending parameter lists, and plan how ingress updates state.

### Documentation

- **Documentation:** Commit design to `ARCH.md` (contracts, citations, schemas) before writing runtime code. Update `README.md` and `PLAN.md` when they would otherwise drift. This checkpoint preserves design intent if the session terminates unexpectedly.

### Implementation

- **Implementation:** Use `apply_patch` for all changes, maintain a single active path per behavior, enforce explicit defaults, and keep strict typing without casts or appeasements. Remove obsolete paths rather than aliasing; do not add migration or compatibility layers unless the user explicitly requests them, and prefer native features over internal proxies.

### Validation

- **Validation & Gates:** Run `uv run devtools/gate.py` whenever artifacts change or a progress signal is required. Delivery is incomplete until gates pass cleanly once per change set; respect severity bands in §12 and stop immediately on Hard failures. Zero drift is mandatory: behavior, tests, and docs must describe the same state at merge.
- **Contract-backed validation:** Acceptance tests assert contract outcomes (events, outputs, side effects) rather than status alone, and establish/verify required policy or configuration preconditions before exercising behavior.
- **Assertion strictness changes:** Any test edit that relaxes assertions (weaker expectations, broader pass conditions, or removed checks) is a contract change and requires explicit user approval plus same-change updates to contracts and operator docs.
- **Branch and denial coverage:** Acceptance suites cover all documented configuration branches and expected-denial paths (auth, limits, approvals, guardrails) with deterministic inputs.

### Handoff

- **Handoff:** When the Quality Loop cannot be completed in the current session (blocked gates, missing approvals, unresolved ambiguity), record the research findings, citations, current state, and next actions in `HANDOFF.md` before yielding.

### Workflow instrumentation

- **Workflow Instrumentation:** For each change:
  - Define 5–7 rubric categories.
  - Publish a 3–7 item plan prior to tooling.
  - Produce the draft.
  - Validate against the rubric.
  - Surface assumptions.
  - Capture citations.
  - Describe design updates.
  - Summarize implementation.
  - Report gate status (or justify deferral).
  - Note documentation deltas.
  - Close with a clear outcome summary.

---

## 6) Contracts, Boundaries, and Observability

### 6.1 Edge Contracts

- Exactly **one** success schema and **one** error schema per platform JSON edge; avoid ad‑hoc dicts and discriminated unions. Typed validation happens at ingress, invalid inputs return typed errors, and untyped payloads never cross boundaries.
- Use JSON envelopes with strict encoders/decoders on platform‑defined HTTP JSON endpoints. Function signatures and annotations must match the envelope actually emitted.
- Invalid inputs or unsupported modes must fail fast with explicit, actionable errors; silent fallback is prohibited.
- Use only public validation facilities of chosen frameworks or libraries and map validation failures into the canonical success/error shapes at edges; do not construct framework‑internal error objects or payloads by hand.
- Helpers that validate or normalize untrusted edge payloads operate only on those payload shapes and are not used as the primary API for internal typed models, defaults, or storage; domain code relies on typed helpers that may build on edge validators but expose typed contracts.
- Public callables must not expose positional booleans; express intent with keyword-only flags or enums so edge intent is explicit and stable; user-facing controls publish explicit enable/disable flags (or enums) instead of defaulted booleans.
- Long-running workflows must declare terminal completion preconditions (required terminal outputs, required side effects, required snapshots where applicable) and emit typed failure states when preconditions are unmet; terminal success is forbidden otherwise.

#### Success envelope (single-response)

```json
{ "schema_version": 1, "trace_id": "uuid", "ts": "RFC3339", "result": { "resource": "string", "payload": {} } }
```

- Replace `result` with a typed domain payload. Optional fields use `T | None` and undergo validation.

#### Error envelope (single-response)

```json
{ "schema_version": 1, "kind": "string", "message": "string", "details": {}, "trace_id": "uuid", "ts": "RFC3339" }
```

- `details` is typed per `kind`; never leak raw tracebacks. Stream edges emit typed error events.
- Use a single canonical JSON value algebra (`str | int | float | bool | null | list[...] | object{string→...}`) for all envelopes; untyped `object`/`Any` payloads MUST NOT cross edges. Provide and reuse one shared coercer for this algebra rather than reimplementing serialization at call sites.
- Map internal failures at edges into a shared error vocabulary with named kinds and stable detail codes, and define each failure-to-error mapping once so it is reused consistently across surfaces.

### 6.2 Boundaries & Surfaces

- Single path per behavior: **ingress → boundary → service → adapter** with resource‑oriented names (verbs live inside paths).
- Untyped or vendor‑returned payloads are converted at the first process edge into typed adapter outputs; unknown shapes never cross inward.
- Fallback code paths emit the identical contract schema as the primary path; reduced data is allowed, schema drift is not.
- Define each edge signature once in a shared manifest/builder and reuse it across all registrations so option/argument shapes cannot drift between surfaces.
- Keep ingress handlers narrow and push orchestration into dedicated modules. Interfaces must reflect runtime semantics (context, lifecycle) and prohibit reflection.
- Central entrypoints that coordinate multiple concerns are expressed as short, mostly linear pipelines of named stages, with branching and contingency logic delegated to narrow helpers for each concern rather than embedded in the orchestrator.
- Consolidate defaults at ingress, reject out‑of‑scope inputs with typed errors, and fail fast before side effects.
- For any recurring mapping between two domain concepts, define a single canonical mapper (function or module) and route all call sites through it instead of recomputing the mapping at edges or services.
- All ingress surfaces (HTTP, CLI, job args, UI forms, batch inputs) **except vendor protocol edges** must pass through a single typed coercion/validation path into the canonical JSON envelope before any domain logic executes; no ad‑hoc per‑handler parsing.
- Diagnostic and inspection tools are first‑class ingress surfaces: they emit a stable machine‑readable success/error shape, and human diagnostics never corrupt the machine output.
- Before persistence or emission (DB, file, queue, cache, export), convert runtime models/objects into the canonical JSON envelope; storage/transport layers only see JSON‑safe data.
- Maintain layered imports with no runtime cycles. Model execution context as one typed object per edge and pass it as the sole carrier of edge‑derived state into helpers and services.
- At each process edge, accept at most one explicitly typed dependency context or service parameter; resolve dependency wiring and configuration before invoking the edge.
- Per process, maintain a single canonical dependency source for shared services and stateful components, and require all edges and workflows in that process to obtain such dependencies from it rather than constructing local instances.
- When an edge requires multiple collaborators, aggregate them into a single typed dependency bundle object passed through the boundary instead of injecting each collaborator separately.
- New interaction surfaces (tools, widgets, commands, prompts) must describe how outputs update system state/config before implementation. Produce an **entrypoint manifest** before reorganizing modules to ensure every public entrypoint is preserved, improved, or explicitly retired without compatibility aliases.
- Shared contracts (envelopes, errors, telemetry, approvals, policies) must land uniformly across all ingress surfaces before release—no surface is exempt.
- Reports/exports and other cross-surface artifacts must be assembled from typed envelopes, never from raw dict/string concatenation; their schemas live alongside the boundary that emits them.

### 6.3 Integrations & Adapters

- Vendor code is immutable; integrate via deliberate adapters/wrappers so vendor sources remain untouched.
- Exactly **one** adapter per external provider boundary; avoid stacks of shims and aliases.
- Inside adapters, use provider runtime model types at adapter interfaces and in internal logic; normalize outbound payloads to our envelopes before leaving the boundary.
- Retries, backoffs, and version drift belong only inside adapters to keep domain logic deterministic.

### 6.4 Observability & Tracing

- Logging is structured, correlated with `trace_id`, and emitted where context exists; every request/work unit has exactly one `trace_id` that is sufficient to locate its related artifacts across layers.
- Runbooks document the traversal from symptom → `trace_id` → inspected artifacts.
- Edges use narrow exception handling, map failures to typed errors, and continue only via explicit policy.
- `print` is banned in runtime paths; rely on structured logging and tracing instrumentation.
- Streaming surfaces are validated end-to-end: start, ordered events, and terminal conditions must all be asserted in tests.

---

## 7) Typing, Linting, and Code Health

- Enforce strict static typing with **zero errors**. No casts; narrow via validation. Compile‑time shims for external APIs are allowed only when they do not alter runtime behavior.
- Prefer `collections.abc.Mapping[K, V]` for read-only interfaces and `collections.abc.MutableMapping[K, V]` when mutation is part of the contract; reserve `dict[K, V]` for owned state, returns, and locals. This preserves variance correctness and avoids unnecessary coupling to concrete containers.
- Maintain lint/format cleanliness with **zero findings**.
- Keep callable complexity within defined limits (branches, statements, cyclomatic); declare numeric thresholds in repo gate configuration and treat any lint hit as a design signal; when a callable would exceed limits, split it into named helpers rather than suppressing findings.
- **Strict appeasement ban:** no `type: ignore`, ad‑hoc casts, or suppressions in owned code.
- Placeholder runtime types are forbidden: do not use `object`/sentinel aliases at boundaries; if a type is unknown, redesign the contract or surface it explicitly and typed.
- Python imports are absolute.
- Tests target public or explicitly documented contract surfaces, not private helpers or incidental internals.
- Configuration-driven branches must each be exercised by acceptance tests with deterministic inputs; surface-specific acceptance coverage is required for each ingress.

---

## 8) Runtime Constraints, I/O, and Concurrency

- No blocking I/O inside event loops. Stream large payloads with caps and early rejection. Offload CPU‑bound work from primary loops.
- Background tasks propagate cancellation and await clean shutdown. Do not broadly catch cancellations.
- All long‑lived resources are acquired and released via structured patterns such as **context‑managed lifecycles**, and pooled resources follow this rule and are never closed directly.

---

## 9) Configuration, Credentials, and Controls

- Advanced behavior is **configuration‑driven**; defaults are explicit and deterministic, and interactive surfaces expose the minimal set of controls needed.
- Maintain a single source of configuration: define schemas/defaults once and import everywhere.
- Define all limits and quotas (sizes, counts, rates, timeouts) once as named configuration and import these constants into runtime logic and documentation instead of duplicating raw values.
- Credential precedence is uniform across runtime edges, internal tools, and tests: **request context → component config → environment**. Any exception is explicitly documented with rationale and blast radius.
- Every user‑visible control (flags, settings, client tool outputs, prompts) maps **once** to runtime configuration/state at the boundary; inner components must not reinterpret the same control differently.
- When controls span distinct concern domains (for example authorization scope, user preference, and execution tuning), define separate precedence resolvers per domain; a single mixed-domain precedence ladder is prohibited.
- When the set of controls or configuration keys is finite, implement their validation and normalization through a central registry or table of handlers instead of scattered conditional blocks.
- Configuration must be authored and versioned as code (including local, preview, and production profiles). Service lifecycle commands (pre-start, start, health targets) live alongside code, not in per-environment UI toggles.
- When configuration keys or defaults change, update all active environment profiles, operator-local templates, and examples together; missing or extra keys in any profile pair are hard failures.

---

## 10) Resilience, Idempotency, Optional Deps, Servers

- Apply **capped exponential backoff with jitter** and distinguish our retries from provider retries.
- Any side-effecting operation reachable from retries, continuations, or recovery paths must be idempotent under a stable operation key scoped to one workflow unit.
- When provider boundaries support idempotency keys, propagate the same operation key through adapters.
- Recovery policy is explicit: structural recovery reconciles or replays only verified prior artifacts and outputs; semantic recovery may rewrite content but must not fabricate prior execution artifacts.
- Ensure deterministic cleanup hooks for temporary resources.
- Core dependencies are mandatory; when a required store or external service is unreachable or unconfigured, fail fast and refuse to serve rather than degrade. Optional dependencies follow a **typed‑loader** pattern only when truly non‑critical; no import‑time appeasements or ignores.
- When a protocol/framework exposes a canonical server abstraction, build all servers for that protocol on that abstraction (no custom server plumbing).

---

## 11) Documentation & Artifacts

- Documentation tracks the Quality Loop. Ownership, cadence, and blocking criteria:

    | Artifact     | Owner / Approval                                     | Cadence                                                      | Blocks delivery when                                         |
    | ------------ | ---------------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
    | `VISION.md`  | User-led; agent proposes with explicit user approval | Update only when desired outcomes/users/metrics/non-goals change | Outcomes shift without recorded approval                     |
    | `ARCH.md`    | Agent                                                | Update before implementing new behaviors and whenever contracts/boundaries/citations change | Contracts or citations missing/drifted versus vendor code    |
    | `README.md`  | Agent                                                | Update with every behavior change; present tense only        | Operator guidance diverges from actual behavior              |
    | `PLAN.md`    | Agent                                                | Delete completed items and refresh to reflect only remaining work after each change | Completed work lingers or milestones mismatch reality        |
    | `HANDOFF.md` | Agent                                                | Update whenever work remains at session end or when a change is blocked | Work is handed off without a concrete, grounded next-step record |

- **Contracts dictionary:** reserved field names and envelopes for public contracts; gates fail on drift.

- For each canonical path, mapping, or adapter (the single path for a behavior), record its name, role, and inputs/outputs in the architecture docs alongside its process edge.

- **Style boundary:** all docs are present-tense and greenfield **except** `PLAN.md` and `HANDOFF.md`, which are the only places where planning, gap, drift, or debt language is allowed.

- Documentation must be directive and testable—avoid tentative language or speculation; every instruction should read as an action or rule.

- **Canonical invocations:** each operational capability has exactly one canonical name and usage pattern; when it changes, update all docs, examples, and helper scripts in the same change.
- **Canonical semantics:** each semantic definition (field meaning, policy rule, scope behavior) has a single canonical location; all other surfaces reference it or restate it verbatim.
- Terminology must match lifecycle and persistence semantics; when behavior scope changes, rename and retire the superseded term across docs, interfaces, and implementation in the same change set.
- When contract requiredness or payload shapes change, update fixtures, examples, tests, and user-facing guidance in the same change set.

- Maintain `HANDOFF.md` as the canonical session handoff: when work remains, record environment controls, gate commands and results, open gaps, and next actions so a new agent can resume without prior context.

- No contract is marked as available in docs until its code and tests are implemented and passing.

- Update `ARCH.md` structure diagrams in the same change whenever top-level structure changes.

- All public modules, types, and functions or methods include concise inline documentation that states their contract, side effects, and role in the system.

### Document chain & drift semantics (canonical story)

- **Immutable vendor code is the law:** `.venv`/`node_modules` content plus official vendor docs when needed. Owned code is mutable and may be wrong—never treat it as authoritative.
- `VISION.md` is the **future target** (what we want).
- `ARCH.md` is the **intended technical contract** (how we plan to codify it), and it can be wrong until grounded in vendor research.
- Code/migrations are **runtime reality** and may lag `ARCH.md` (or reflect a bad design).
- Gaps between **VISION ↔ ARCH** require **research + design**.
- Gaps where **vendor code contradicts ARCH** require **research first**, and may lead to a greenfield "nuke + replace" design before implementation.
- Gaps between a **validated ARCH ↔ code** require **implementation**.
- All gaps/drifts are tracked as explicit **research | design | implement** initiatives in `PLAN.md` and summarized in `HANDOFF.md` when work remains.

---

## 12) Build, Gate, and Delivery

### Gate runner and commands

- Run gates via `uv run devtools/gate.py` from repo root. Do **not** call individual linters/typecheckers directly.
  - `uv run devtools/gate.py` is intentionally **NOT FULL** in this repo (it excludes live docker-compose E2E tests).
  - Use `uv run devtools/gate.py --full` to run the full gate including live docker-compose E2E.

### Gate cadence and reporting

- **Cadence:** run gates once per change set or whenever signaling progress. Delivery is incomplete until a clean gate run completes after the final code/doc change.
- Document gate status (pass/fail/deferred with reason) in the transcript, include the exact command and flags run plus current failure buckets; when gates are already failing, call out which failures are inherited versus newly introduced and ensure the new change set keeps the failure set flat or shrinking.
- Validation reporting must declare execution target and freshness state, and must not claim end-to-end verification against a target that was not refreshed after behavior-affecting changes.
- When a gate is failing and the session is handing off (instead of fixing immediately), capture the same gate evidence and reproduction commands in `HANDOFF.md` so the next agent can resume from facts, not guesswork.

### Test suite organization and environment

- Classify test suites by surface (for example, unit, integration, edge/end‑to‑end) and document their environment assumptions so gates and workflows can invoke them in the correct order and on the correct runtime stack.
- Test suites are tiered (unit/integration/acceptance/live); acceptance/live suites run only by explicit intent and are not part of fast gates by default.

### Docker lifecycle coordination

- **Docker lifecycle coordination:** the user owns Docker/compose lifecycle. The agent MUST NOT rebuild or restart services directly; after any behavior‑affecting change that should reach the running stack (API/Web), the agent pauses and explicitly requests a rebuild before relying on containerized behavior or E2E HTTP tests.

### `--no-tests` constraints

- `uv run devtools/gate.py --no-tests` is reserved for **fast feedback loops on local-only edits** (for example, formatting or very early design spikes) when:
  - The change does not touch HTTP contracts, runtime behavior, or database schema, and
  - Full tests will still run before any change is considered deliverable. Use the default gate (with tests) for normal changes, and use `uv run devtools/gate.py --full` for behavior-affecting changes that must be validated against the live docker-compose stack.

### Severity bands

  | Severity                | Definition                                           | Representative examples                                      |
  | ----------------------- | ---------------------------------------------------- | ------------------------------------------------------------ |
  | Hard (blocking)         | Must be resolved before merge; gate contract fails   | `uv run devtools/gate.py` failure, missing `.venv` audit for touched deps, absent `ARCH.md`citations, contract drift, static typing errors, docs desynchronized from runtime, appeasements/casts, unapproved stubs |
  | Advisory (non-blocking) | May merge with acknowledgment but track as follow-up | Style/wording polish, aspirational documentation tweaks, non-functional formatting, optional experiments |

### Additional delivery rules

- Gate contract is canonical: declare root entrypoints, target sets, and pass criteria in-repo; do not reconfigure gates piecemeal.
- **Environment escalation:** request approval when dependency management or virtualenv operations require elevated permissions; never bypass the gate script.
- Assertions MUST NOT be used for runtime control or validation in owned code (including migrations and bootstrap); surface typed errors with actionable messages instead.

------

## 13) Modularity & Repository Structure

- Default to greenfield single-path implementations; do not add back-compat or transitional layers unless an explicit non‑greenfield compatibility requirement is recorded, and never run a long-lived extra path alongside the canonical one.
- When a new contract replaces an old one, delete or fully isolate the old path and update all callers, tests, configuration, documentation, and user-facing command surfaces in the same change, and track its removal explicitly in `PLAN.md` instead of keeping both behaviors in parallel.
- Eliminate legacy aliases and duplicate paths as soon as a replacement is introduced; refactors leave exactly one canonical route per behavior.
- **Guardrail:** owned files stay ≤ **500 lines** and ≤ **18 kB** with no routine waivers; when a file approaches the limit or trips complexity thresholds, treat that as a design signal and split or restructure along clear boundaries (by role or pipeline stage) rather than adding exceptions or mechanical appeasements. Gate enforcement is mandatory.
- Functions that exceed defined size/complexity thresholds must be split or redesigned immediately—no waivers or deferrals.
- Repo-wide atomic renames are mandatory; update all call sites; no aliases.
- Name modules/folders by role (**edge**, **workflow**, **adapter**, **store**, etc.) and reuse this taxonomy across repositories.

---

## 14) UI & Theming

- Tokens-first theming; no hard-coded colors.
- Use Tailwind or design-system components bound to design tokens.
- Map any brand look to tokens first.
- UI changes MUST pass the same lint, style, and policy gates as all other code; do not introduce exceptions for visual-only tweaks.
- App Router posture: keep pages server components; place React hooks in leaf client components marked with `"use client"` and keep client islands minimal to reduce hydration cost. Do not flip whole pages to client for convenience.
- Hydration discipline: pass data via props into client islands, avoid browser-only imports in server components, and split UI modules before the 500-line/18 kB guard is hit.

---

## 15) Toolchain & Versions

- Python **>=3.12**; Node **24**; TypeScript **^5**.
- All JS/TS tasks run via **`pnpm`** only.
- Python runs only with **`uv`** (`uv run python`).
- No global runtimes.

---

## 16) Prohibitions and Allowances

- **Typing & Validation:** `typing.Any`, `typing.cast`, `typing` aliases (`Optional`, `List`, `Dict`, `Tuple`, `Set`, `FrozenSet`, `Type`, `Callable`, `Iterable`, `Iterator`, `Sequence`, `Mapping`, `MutableMapping`, `Awaitable`, `Coroutine`), and `assert` for control flow or type narrowing are banned. Use built-in generics (`list`, `dict`, `set`, `tuple`, `type`, `frozenset`) and `collections.abc` for abstract types; use `X | None` over `Optional[X]`. Type narrowing happens via explicit validation only.
- **Control & Error Handling:** Reflection for control flow/runtime access (`getattr`, `hasattr`, `setattr`, etc.), catch-all exceptions, and silent swallows are prohibited.
- **Architecture & Contracts:** No appeasements/stubs in owned code, no new partial edges, no implicit globals/hidden config/mutable default args, no duplicate behaviors or transitional paths once a new path is live, and no dict-shaped payloads at edges.
- **Runtime Safety:** Unbounded retries/sleep loops, `print` for logging, dead code/nondeterminism, and dangerous runtime execution (dynamic eval/exec, shell-enabled launches in owned code) are banned.
- **Integration Discipline:** Vendor code modifications are forbidden. Retries and version drift live only inside the deliberate adapter per provider boundary described in §6.3.
- **Allowed with discipline:** Typed stubs and `Protocol` are permitted for internal polymorphism (not at process edges and never as placeholder behavior).

---

## 17) Communication, Style, and Truth Norms

- Output style: brief, declarative, neutral, high-density.
- Prioritize truth over agreement. State assumptions and scoped constraints explicitly. Do not fabricate; declare unknowns.
- Announce plan in `update_plan`, show progress, and report delta.
- Before asserting that a behavior exists or a milestone is complete, verify current state directly (sources, configuration, or gate output) rather than relying on memory or prior intent.
- When solution direction is challenged, pause new edits and present root cause, rejected alternatives, and the chosen path before resuming implementation.

---

## 18) Escalation & Conflict Resolution

- Instruction stack: **System policies → user goals → this charter → developer directives → Codex CLI/tool constraints → repo docs**. When instructions conflict, pause and call out the conflict before proceeding.
- Escalate immediately when a Quality Loop stage cannot be satisfied, when required approvals are missing, or when user requests contradict safety/platform policies. Describe the issue, proposed resolution, and any blocked work.
- Document unresolved ambiguities as assumptions in the transcript and seek clarification from the user; do not guess when behavior, contracts, or approvals are unclear.
- Prefer proactive escalation over silent divergence—world-class results rely on explicit alignment.
