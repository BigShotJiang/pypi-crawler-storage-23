# agenterm — Vision

## 1. Product Idea

### 1.1 Overview

agenterm is a **terminal-native agent runtime** for developers. It treats conversations as persistent, branchable objects backed by local SQLite—not stateless API calls. Run it inside any project directory to get:

- A **one‑shot `run` command** that can read, plan, and modify code in a single run, with access to deep tools (file search, web_search (`web.run`), local CLI tools, shell, apply‑patch, image generation, MCP).
- An **interactive REPL** as a full‑screen prompt‑toolkit TUI with a concise slash‑command language for changing models, toggling tools, editing instructions, attaching files, and re‑running runs.
- First‑class integration with OpenAI **Responses + Agents** and **MCP**, so the CLI behaves like a real agent runtime, not a thin HTTP wrapper.
- Two execution planes with one UX: OpenAI native Responses for `openai/...` models, and a gateway plane (`gateway/...`) for all other providers.

### 1.2 Product posture

The product posture is opinionated:

- One canonical engine path.
- Minimal surface knobs, strong defaults, and clear status.
- Conversations that can be resumed and inspected, locally and remotely.

## 2. Product Principles

### 2.1 Engine and tools

#### 2.1.1 Agents‑first

- The Agents SDK is the canonical engine:
  - Agents encapsulate instructions, model, tools, and MCP servers.
- A single runner drives runs (non‑streaming and streaming).
- All tools—hosted, local, and MCP—are exposed to the model as first‑class tools:
  - Hosted tools: `file_search`, `web_search` (`web.run`), `image_generation`.
  - Local tools: `inspect`, `shell`, `apply_patch`, `plan`, `steward`, `agent_run`, `agent_run_report`.
  - MCP: local/remote servers exposing tools via the MCP protocol.
- User-facing tool selection uses **tool keys** that encode capability family:
  - `fn:<name>` for built‑in FunctionTools (`fn:user:<name>` for user tools),
  - `hosted:openai:<tool>` for OpenAI hosted tools,
  - `hosted:mcp:<connector>` for OpenAI‑hosted MCP connectors,
  - `mcp:<server_key>` for client‑managed MCP servers.
- Built‑in FunctionTools include `fn:inspect`, `fn:shell`, `fn:apply_patch`,
  `fn:plan`, `fn:steward`, `fn:agent_run`, and `fn:agent_run_report`.
- MCP tool identities are always made **globally unique** and **OpenAI‑valid** before exposure:
  - Prefer readable names: `mcp__<server_key>__<tool_name>` when valid and within limits.
  - Fall back to a shortened hashed form when needed to satisfy platform constraints.

#### 2.1.2 Single path per behavior

- Every user‑visible behavior (for example, “run once”, “stream a run”, “start a REPL session”, “list sessions”) follows exactly one pipeline from CLI to engine to output.

### 2.2 UX and state

#### 2.2.1 Terminal‑native UX

- Typer powers commands, flags, and help.
- prompt‑toolkit Application powers a full‑screen TUI (scrollable transcript, keybindings, bottom status bar).
- Run execution uses the streaming engine under the hood, but the default presentation is calm:
  - Quiet by default: show the final answer plus a footer/summary (tools used + `response_id` when enabled).
  - Live streaming is opt‑in (`--live` and REPL stream/UX settings): tool calls, tool outputs, and other accessories are shown as they arrive.
  - Reasoning is treated as a UX artifact (summary‑only by default; no chain‑of‑thought dumps).
  Token usage is surfaced in the status bar.

#### 2.2.2 Slash‑command harness

- The REPL treats any line starting with `/` as a command, not a prompt.
- Commands are organized into logical groups:
  - `/config` — settings (key, verbosity, reasoning, trace).
  - `/session` — session management (new, list, use, runs).
  - `/tools`, `/mcp`, `/approvals` — tool and server control.
- `/help` and `/status` keep command discovery and state explicit.
- Commands update session state and configuration in a structured way, with no hidden global state.
- Commands are composable and reversible: you can always see and undo their effects via `/status` and follow‑up commands.

#### 2.2.3 Branchable conversations

- Each conversation is a first‑class object, identified by a stable `session_id`.
- Users can:
  - Start a new REPL session (`/session new`) without losing the old one.
  - Attach the REPL to an existing session (`/session use ID`) to inspect or continue it.
  - View recent runs (`/session runs [N]`) with concise previews.
  - Move between one‑shot `run` and the REPL using the same `session_id`.

#### 2.2.4 Transparent accessories

- Responses accessories (reasoning summaries, tool calls/results, web_search (`web.run`) context, images) are surfaced as labeled sections:
  - `[reasoning]`
  - `[tool call] web_search` / `[tool call] shell` / …
  - `[tool output] file_search` / `[tool output] apply_patch` / …
- The CLI always requests a fixed, high‑value include set internally and renders those accessories consistently in both `run` and REPL.

#### 2.2.5 Artifacts vault (durable outputs)

- Large binary outputs (especially generated images) are treated as **artifacts**, not as “just another field in session history (SDK turns)”.
- Artifacts are:
  - **Auto-saved** when produced (no manual “save” step).
  - **Durable** and **per-user**: stored under a single root directory in home (`~/.agenterm/`).
  - **Indexed** in the local SQLite store as stable filesystem references (not base64 blobs).
  - **Session-independent**: artifacts outlive sessions/threads; deleting a conversation does not delete the artifact files.
- The REPL treats artifacts as UI objects (image cards, paths, and navigation commands) instead of dumping base64.

#### 2.2.6 Dangerous tools and safe power

- A small set of tools is considered dangerous (by default, `fn:shell`, `fn:apply_patch`, `fn:user:*`, `mcp:*`, and `hosted:mcp:*`).
- Shell strings are not classified as safe (no “parse a command and hope”); the shell tool remains the explicit escape hatch.
- Shell and apply‑patch tools go through explicit, policy‑bound executors:
  - Shell commands run in a macOS Seatbelt sandbox (workspace-confined writes, configurable network access).
  - Apply‑patch operations are scoped to the workspace root and subject to explicit approvals.
- Tool approvals are visible and actionable:
  - The REPL presents a modal approval overlay for pending shell/patch operations (in `prompt` mode).
  - In one-shot runs, tool approvals are auto-resolved (non-interactive); dangerous tools are either exposed (via `--allow-dangerous`) or dropped from selection.
- Default behavior by surface:
  - One-shot runs drop dangerous tools unless `--allow-dangerous` is passed; when provided, dangerous tools are exposed and their approvals are auto-resolved.
  - The REPL allows dangerous tools but keeps approvals in `prompt` mode by default unless started in `auto` mode (via `--approvals auto`) or toggled via `/approvals auto`.

## 3. Product Surface

### 3.1 One‑shot `run`

`agenterm run "..."` executes a single agent run against the current project.

#### 3.1.1 Inputs

- **Prompt text**
  - One or more inline prompt arguments.
  - A file via `--file` (joined into a single prompt).
  - Stdin when no prompt or file is provided.
- **Attachments**
  - `--attach PATH|URL...` stages local files and URLs as additional input items for the run.

#### 3.1.2 Execution

- Foreground runs are executed via streaming:
  - Quiet by default (final answer + footer).
  - With `--live`, tool calls, tool outputs, and other accessories (including reasoning summaries) are shown as they arrive, then the run ends with a calm footer summarizing tools, `response_id`, and usage.
- Background runs (`--background`):
  - Submit a server‑side run that is not streamed to the client.
  - Print the `response_id` and then exit.
- Presentation modes:
  - Default **quiet** human output: one‑shot summary (plain output plus footer).
  - **Live** human output (`--live`): live accessory labels during the stream and a rich Markdown finale.
  - **JSON output** (`agenterm <command> --format json ...`): emits a single parseable envelope (text, attachments, artifacts, tools summary, `response_id`, `session_id`, usage) for CI/scripts and suppresses streaming accessories.

#### 3.1.3 Outputs

- **Text**
  - Quiet (default): final answer rendered as plain text with a calm footer.
  - Live: final answer rendered with rich Markdown.
- **Accessories**
  - Labeled reasoning summaries and tool sections when available.
- **Artifacts**
  - Durable filesystem-backed outputs (e.g. generated images), surfaced in the REPL transcript and included in JSON output.
- **Metadata**
  - `response_id` so you can chain calls or inspect background runs.
  - Usage summary (input/output/total tokens) when usage is enabled.

### 3.2 Interactive REPL

The REPL is a full‑screen prompt‑toolkit Application on top of the same engine.

#### 3.2.1 Prompt

- Line‑based input with history and completions in a dedicated composer region.
- Slash commands (`/status`, `/model`, `/tools`, `/config`, `/session`, …) are distinct from prompts.

#### 3.2.2 Transcript

- User prompts and agent outputs render inside a scrollable transcript window with internal scrollback.
- Tool calls/results and reasoning are labeled and summarized.
- Attachments used in a run are echoed so it is always clear what was actually sent.

#### 3.2.3 Status bar

- A compact toolbar shows:
  - Agent name and model.
  - Input token usage for the last provider request of the last completed run.
  - Approval posture when auto‑approval is enabled.

### 3.3 Sessions and continuity

Sessions are shared between `run` and REPL.

- Every run is attached to a local session backed by SQLite, identified by a UUID `session_id`.
- `--session ID` resumes an existing session or fails fast (no implicit create/fork).
- `/session list` and `/session use` in the REPL let users:
  - List existing sessions.
  - Attach the REPL to any of them for inspection or continuation.
- Continuity is always local; the CLI never uses provider-managed conversation state.
- Steward snapshots keep session history (SDK turns) within context budgets (compaction on OpenAI, summaries on the gateway); snapshots are local branches, not provider memory.
- `model.store` controls provider‑side persistence only (inspection/compaction/snapshot identifiers).
- `last_response_id` is stored per branch only when provider storage is enabled.
- This sessions model is the same in `run` and the REPL; only the UX is different.

## 4. Primary Workflows

### 4.1 Explore and edit a project in REPL

- Start the REPL with `agenterm repl` (TTY).
- Run `agenterm config save --scope global` to create the baseline global config in your home directory, then optionally `agenterm config save --scope local` to make a per-project override.
- Use:
  - `/model` to switch models; `/config reasoning|verbosity` to shape behavior.
  - `/tools` to toggle file search and shell on or off.
  - `/attach` to send specific files or URLs.
  - `/again` and `/edit` to rerun or fork prompts.
  - `/session list|use|runs` to navigate conversations.
- Goal: the REPL becomes the primary "thinking environment" for coding work.

### 4.2 Run scripted tasks and CI steps

- Use `agenterm run "..."` in scripts and CI jobs:
  - Run fix‑ups, code reviews, or documentation passes.
  - Use `--session <ID>` when you want to resume a local conversation explicitly.
  - Use `--store` when you want to enable server-side persistence explicitly.
  - Use `--format json` when you want a single machine-readable result.
  - Use `--background` for long operations and `agenterm inspect response <id>` to
    inspect them later; use `agenterm inspect run|run-events` for local run history.
- Goal: `run` is safe, repeatable, and easy to introspect.

### 4.3 Tools and MCP as first‑class citizens

- Configure and use:
  - Hosted tools (`file_search`, `web_search` (`web.run`), `image_generation`) via config.
  - `parallel`, `shell` (Seatbelt sandboxed, workspace-confined), and `apply_patch`.
  - MCP servers (stdio, SSE, Streamable HTTP) and inspect them with `agenterm mcp`.
- Let the agent discover and call tools; see those calls as labeled sections in the transcript.
- Goal: tools feel like part of the platform, not bolted‑on scripts.

## 5. Non‑Goals

- Agenterm CLI is focused on **developer workflows**, not on being a general chat client.
- The engine is **Responses + Agents + MCP** oriented; other model modes and protocols are out of scope.
- There is no GUI or web frontend; the CLI and REPL are the primary surfaces.
