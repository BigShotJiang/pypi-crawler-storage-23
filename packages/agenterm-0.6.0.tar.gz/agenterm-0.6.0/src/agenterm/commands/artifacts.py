"""Artifacts CLI commands."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Annotated

import typer

from agenterm.artifacts.agent_run import load_agent_run_report
from agenterm.artifacts.repo import get_artifact_by_id, list_artifacts_recent
from agenterm.cli.options import FormatOption, SessionIdOption, TraceIdOption
from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output import emit_result as emit_cli_result
from agenterm.cli.output_format import OutputFormat
from agenterm.core.cli_payloads import (
    ArtifactAgentRunPayload,
    ArtifactOpenPayload,
    ArtifactShowPayload,
    ArtifactsListPayload,
    ArtifactSummaryPayload,
)
from agenterm.core.error_report import (
    ErrorContext,
    build_error_report,
    build_message_report,
)
from agenterm.core.errors import DatabaseError, FilesystemError, ValidationError
from agenterm.core.platform import is_macos
from agenterm.store.session.service import session_store

artifacts_app = typer.Typer(
    name="artifacts",
    help="Browse durable artifacts produced by the agent.",
    no_args_is_help=True,
)


def _context(resource: str) -> ErrorContext:
    return ErrorContext(operation=resource, resource=resource, trace_id=None)


def _resolve_artifact_file(
    *,
    output_format: OutputFormat,
    artifact_id: str,
    resource: str,
) -> tuple[Path, str] | None:
    try:
        rec = asyncio.run(
            get_artifact_by_id(
                store=session_store(),
                artifact_id=artifact_id,
            )
        )
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=_context(resource))
        emit_cli_error(output_format=output_format, report=report)
        return None
    if rec is None:
        report = build_message_report(
            kind="not_found",
            message=f"No artifact with id {artifact_id!r}.",
            context=_context(resource),
        )
        emit_cli_error(output_format=output_format, report=report)
        return None

    path = Path(rec.path)
    if not path.is_file():
        report = build_message_report(
            kind="not_found",
            message=f"Artifact file missing: {path}",
            context=_context(resource),
        )
        emit_cli_error(output_format=output_format, report=report)
        return None

    return path, rec.artifact_id


@artifacts_app.command("list")
def list_cmd(
    *,
    output_format: FormatOption = OutputFormat.human,
    limit: Annotated[int, typer.Option("--limit", help="Max rows")] = 20,
    session_id: SessionIdOption = None,
    trace_id: TraceIdOption = None,
) -> None:
    """List recent artifacts."""
    try:
        rows = asyncio.run(
            list_artifacts_recent(
                store=session_store(),
                limit=limit,
                session_id=session_id,
                trace_id=trace_id,
            )
        )
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=_context("artifacts.list"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc

    payload = ArtifactsListPayload(
        artifacts=tuple(
            ArtifactSummaryPayload(
                artifact_id=r.artifact_id,
                kind=r.kind,
                mime=r.mime,
                path=r.path,
                size_bytes=r.size_bytes,
                created_at=r.created_at,
                source_type=r.source_type,
                source_id=r.source_id,
                session_id=r.session_id,
            )
            for r in rows
        ),
    )
    emit_cli_result(
        output_format=output_format,
        resource="artifacts.list",
        payload=payload,
        trace_id=None,
    )


@artifacts_app.command("show")
def show_cmd(
    artifact_id: Annotated[str, typer.Argument(help="Artifact ID")],
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Show one artifact record."""
    try:
        rec = asyncio.run(
            get_artifact_by_id(
                store=session_store(),
                artifact_id=artifact_id,
            )
        )
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=_context("artifacts.show"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    if rec is None:
        report = build_message_report(
            kind="not_found",
            message=f"No artifact with id {artifact_id!r}.",
            context=_context("artifacts.show"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1)

    payload = ArtifactShowPayload(
        artifact_id=rec.artifact_id,
        kind=rec.kind,
        mime=rec.mime,
        path=rec.path,
        size_bytes=rec.size_bytes,
        created_at=rec.created_at,
        source_type=rec.source_type,
        source_id=rec.source_id,
        session_id=rec.session_id,
    )
    emit_cli_result(
        output_format=output_format,
        resource="artifacts.show",
        payload=payload,
        trace_id=None,
    )


@artifacts_app.command("open")
def open_cmd(
    artifact_id: Annotated[str, typer.Argument(help="Artifact ID")],
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Open an artifact file (macOS only)."""
    if not is_macos():
        report = build_message_report(
            kind="usage_error",
            message="artifacts open is supported on macOS only.",
            context=_context("artifacts.open"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2)

    resolved = _resolve_artifact_file(
        output_format=output_format,
        artifact_id=artifact_id,
        resource="artifacts.open",
    )
    if resolved is None:
        raise typer.Exit(1)
    path, resolved_id = resolved
    typer.launch(str(path))
    payload = ArtifactOpenPayload(artifact_id=resolved_id, path=str(path))
    emit_cli_result(
        output_format=output_format,
        resource="artifacts.open",
        payload=payload,
        trace_id=None,
    )


@artifacts_app.command("agent-run")
def agent_run_cmd(
    artifact_id: Annotated[str, typer.Argument(help="Agent run report artifact ID")],
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Show an agent_run report."""
    try:
        report = asyncio.run(
            load_agent_run_report(
                store=session_store(),
                artifact_id=artifact_id,
            )
        )
    except (FilesystemError, DatabaseError, ValidationError) as exc:
        report_err = build_error_report(exc, context=_context("artifacts.agent_run"))
        emit_cli_error(output_format=output_format, report=report_err)
        raise typer.Exit(1) from exc
    if report is None:
        report_err = build_message_report(
            kind="not_found",
            message=f"No agent_run report with id {artifact_id!r}.",
            context=_context("artifacts.agent_run"),
        )
        emit_cli_error(output_format=output_format, report=report_err)
        raise typer.Exit(1)

    payload = ArtifactAgentRunPayload(artifact_id=artifact_id, report=report)
    emit_cli_result(
        output_format=output_format,
        resource="artifacts.agent_run",
        payload=payload,
        trace_id=None,
    )


__all__ = ("artifacts_app",)
