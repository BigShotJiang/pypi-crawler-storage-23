"""Typed command models for REPL prompt UI controls."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.choices.repl_ui import (
        ReplColorDepth,
        ReplCompletionMode,
        ReplEditingMode,
        ReplTheme,
    )


@dataclass(frozen=True)
class ReplShowCmd:
    """Show current prompt UI controls for the active REPL session."""


@dataclass(frozen=True)
class ReplThemeCmd:
    """Set the REPL prompt theme."""

    theme: ReplTheme


@dataclass(frozen=True)
class ReplColorDepthCmd:
    """Set the prompt-toolkit color depth for the REPL."""

    depth: ReplColorDepth


@dataclass(frozen=True)
class ReplMouseCmd:
    """Toggle prompt-toolkit mouse support."""

    on: bool


@dataclass(frozen=True)
class ReplCompletionCmd:
    """Set completion mode for the prompt UI."""

    mode: ReplCompletionMode


@dataclass(frozen=True)
class ReplEditingModeCmd:
    """Set editing mode for the prompt UI."""

    mode: ReplEditingMode


__all__ = (
    "ReplColorDepthCmd",
    "ReplCompletionCmd",
    "ReplEditingModeCmd",
    "ReplMouseCmd",
    "ReplShowCmd",
    "ReplThemeCmd",
)
