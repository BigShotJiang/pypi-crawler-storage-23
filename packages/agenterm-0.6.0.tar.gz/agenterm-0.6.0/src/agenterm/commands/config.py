"""Config commands for agenterm: show, path, save."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Annotated, Final

import typer

from agenterm.cli.options import ConfigOption, FormatOption, ModelOption
from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output import emit_result as emit_cli_result
from agenterm.cli.output_format import OutputFormat
from agenterm.config.bootstrap import save_config
from agenterm.config.paths import (
    find_default_config_path,
    global_config_dir,
    local_config_dir,
)
from agenterm.constants.defaults import DEFAULT_MODEL_ID
from agenterm.core.choices.config_scope import CONFIG_SCOPES, parse_config_scope
from agenterm.core.cli_payloads import (
    ConfigPathPayload,
    ConfigSavePayload,
    ConfigShowPayload,
)
from agenterm.core.error_report import (
    ErrorContext,
    build_error_report,
    build_message_report,
)
from agenterm.core.errors import ConfigError, FilesystemError
from agenterm.workflow.shared.config_files import load_base_config

if TYPE_CHECKING:
    from agenterm.config.model import McpServerConfig

_DEFAULT_BOOL = False
_DEFAULT_SCOPE = "global"

config_app: Final = typer.Typer(
    name="config",
    help="View and manage configuration",
    no_args_is_help=True,
)


def _context(resource: str, trace_id: str | None) -> ErrorContext:
    return ErrorContext(operation=resource, resource=resource, trace_id=trace_id)


def _mcp_endpoint(server: McpServerConfig) -> str | None:
    if server.kind == "stdio" and server.stdio is not None:
        return " ".join([server.stdio.command, *server.stdio.args])
    if server.kind == "sse" and server.sse is not None:
        return str(server.sse.url)
    if server.kind == "streamable_http" and server.streamable_http is not None:
        return str(server.streamable_http.url)
    return None


@config_app.command("show")
def show_cmd(
    *,
    config: ConfigOption = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Display effective configuration."""
    try:
        cfg = load_base_config(config)
    except ConfigError as exc:
        report = build_error_report(exc, context=_context("config.show", None))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc

    config_path_str: str | None
    if config is not None:
        config_path_str = str(config)
    else:
        found = find_default_config_path()
        config_path_str = str(found) if found is not None else None
    reasoning = cfg.model.reasoning
    payload = ConfigShowPayload(
        config_path=config_path_str,
        agent_model=cfg.agent.model,
        agent_max_turns=int(cfg.agent.max_turns),
        agent_name=cfg.agent.name,
        agent_path=str(cfg.agent.path) if cfg.agent.path else None,
        agent_source=cfg.agent.source,
        model_store=bool(cfg.model.store),
        model_context_window=cfg.model.context_window,
        model_verbosity=cfg.model.verbosity,
        model_temperature=cfg.model.temperature,
        model_reasoning_effort=(
            str(reasoning.effort)
            if reasoning is not None and reasoning.effort
            else None
        ),
        model_reasoning_summary=(
            str(reasoning.summary)
            if reasoning is not None and reasoning.summary
            else None
        ),
        run_background=bool(cfg.run.background),
        run_live=bool(cfg.run.live),
        run_json_output=bool(cfg.run.json_output),
        repl_approvals_mode=str(cfg.repl.approvals.mode),
        repl_theme=str(cfg.repl.ui.theme),
        repl_color_depth=str(cfg.repl.ui.color_depth),
        repl_editing_mode=str(cfg.repl.ui.editing_mode),
        repl_mouse=bool(cfg.repl.ui.mouse),
        repl_completion=str(cfg.repl.ui.completion),
        repl_stream_mode=str(cfg.repl.ux.stream),
        repl_verbosity=str(cfg.repl.ux.verbosity),
        mcp_servers=tuple(
            MappingProxyType(
                {
                    "key": server.key,
                    "kind": str(server.kind),
                    "name": server.name,
                    "endpoint": _mcp_endpoint(server),
                },
            )
            for server in (cfg.mcp.servers or [])
        ),
    )
    emit_cli_result(
        output_format=output_format,
        resource="config.show",
        payload=payload,
        trace_id=cfg.run.trace_id,
    )


@config_app.command("path")
def path_cmd(
    *,
    config: ConfigOption = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Print active config file path."""
    if config is not None:
        resolved = str(config.resolve())
        emit_cli_result(
            output_format=output_format,
            resource="config.path",
            payload=ConfigPathPayload(config_path=resolved, location="explicit"),
            trace_id=None,
        )
        return

    found = find_default_config_path()
    if found:
        loc = "global"
        try:
            if found.resolve() == (local_config_dir() / "config.yaml").resolve():
                loc = "local"
            elif found.resolve() == (global_config_dir() / "config.yaml").resolve():
                loc = "global"
        except OSError as exc:
            msg = f"Failed to resolve config path {found}: {exc}"
            report = build_message_report(
                kind="filesystem_error",
                message=msg,
                context=_context("config.path", None),
            )
            emit_cli_error(output_format=output_format, report=report)
            raise typer.Exit(2) from exc
        emit_cli_result(
            output_format=output_format,
            resource="config.path",
            payload=ConfigPathPayload(config_path=str(found), location=loc),
            trace_id=None,
        )
        return

    report = build_message_report(
        kind="not_found",
        message="No config file found.",
        context=_context("config.path", None),
    )
    emit_cli_error(output_format=output_format, report=report)
    raise typer.Exit(1)


@config_app.command("save")
def save_cmd(
    *,
    scope: Annotated[
        str,
        typer.Option("--scope", help="Config scope (global|local)"),
    ] = _DEFAULT_SCOPE,
    output_format: FormatOption = OutputFormat.human,
    model: ModelOption = None,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Overwrite existing config"),
    ] = _DEFAULT_BOOL,
) -> None:
    """Write a baseline config (global or project-local)."""
    scope_parsed = parse_config_scope(scope)
    if scope_parsed is None:
        msg = f"--scope must be one of: {', '.join(CONFIG_SCOPES)}"
        report = build_message_report(
            kind="usage_error",
            message=msg,
            context=_context("config.save", None),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2)

    model_id = model or DEFAULT_MODEL_ID
    try:
        result = save_config(
            scope=scope_parsed,
            model=model_id,
            force=bool(force),
        )
    except (ConfigError, FilesystemError) as exc:
        report = build_error_report(exc, context=_context("config.save", None))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc

    emit_cli_result(
        output_format=output_format,
        resource="config.save",
        payload=ConfigSavePayload(
            config_path=str(result.path),
            scope=str(result.scope),
            source=result.source,
            overwritten=bool(result.overwritten),
        ),
        trace_id=None,
    )


__all__ = ("config_app",)
