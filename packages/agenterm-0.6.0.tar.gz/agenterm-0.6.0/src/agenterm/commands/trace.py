"""Trace config CLI commands."""

from __future__ import annotations

from types import MappingProxyType
from typing import Final

import typer

from agenterm.cli.options import ConfigOption, FormatOption
from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output import emit_result as emit_cli_result
from agenterm.cli.output_format import OutputFormat
from agenterm.core.cli_payloads import TraceShowPayload
from agenterm.core.error_report import ErrorContext, build_error_report
from agenterm.core.errors import ConfigError, FilesystemError
from agenterm.workflow.shared.config_files import load_base_config

trace_app: Final = typer.Typer(
    name="trace",
    help="Inspect tracing configuration.",
    no_args_is_help=True,
)


def _context(resource: str, trace_id: str | None) -> ErrorContext:
    return ErrorContext(operation=resource, resource=resource, trace_id=trace_id)


@trace_app.command("show")
def show_cmd(
    *,
    config: ConfigOption = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Show effective trace configuration."""
    try:
        cfg = load_base_config(config)
    except (ConfigError, FilesystemError) as exc:
        report = build_error_report(exc, context=_context("trace.show", None))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc

    metadata = cfg.run.trace_metadata
    meta_view = MappingProxyType(dict(metadata)) if metadata is not None else None
    payload = TraceShowPayload(
        trace_enabled=bool(cfg.run.trace_enabled),
        trace_id=cfg.run.trace_id,
        group_id=cfg.run.group_id,
        trace_metadata=meta_view,
        trace_include_sensitive_data=bool(cfg.run.trace_include_sensitive_data),
    )
    emit_cli_result(
        output_format=output_format,
        resource="trace.show",
        payload=payload,
        trace_id=cfg.run.trace_id,
    )


__all__ = ("trace_app",)
