"""Run-history helpers for `agenterm session runs` (payload only)."""

from __future__ import annotations

from agenterm.core.cli_payloads import RunSummaryPayload, SessionRunsPayload
from agenterm.core.errors import DatabaseError
from agenterm.store.branch.repo import get_branch_meta
from agenterm.store.runs import list_runs
from agenterm.store.session.service import (
    get_session_metadata_row,
    session_store,
    usage_totals_by_run,
)


async def build_session_runs_payload(
    session_id: str,
    *,
    branch_id: str | None,
    limit: int | None = None,
) -> SessionRunsPayload | None:
    """Fetch runs and return a JSON payload, or None when session is missing."""
    store = session_store()
    meta = await get_session_metadata_row(store, session_id)
    if meta is None:
        return None
    head_branch_id = branch_id if branch_id is not None else meta.head_branch_id
    branch_meta = await get_branch_meta(store, session_id, head_branch_id)
    if branch_meta is None:
        msg = f"Unknown branch_id: {head_branch_id!r} for session {session_id!r}"
        raise DatabaseError(msg)

    runs = await list_runs(
        store=store,
        session_id=session_id,
        branch_id=head_branch_id,
        limit=limit,
    )
    usage_by_run = await usage_totals_by_run(
        store=store,
        session_id=session_id,
        branch_id=head_branch_id,
    )

    usage_json: dict[str, dict[str, int]] = {}
    for run_id, usage in usage_by_run.items():
        usage_json[str(run_id)] = dict(usage.to_mapping())

    run_payloads = tuple(
        RunSummaryPayload(
            run_number=rec.run_number,
            status=rec.status,
            response_id=rec.response_id,
            trace_id=rec.trace_id,
            started_at=rec.started_at,
            updated_at=rec.updated_at,
            branch_turn_start=rec.branch_turn_start,
            branch_turn_end=rec.branch_turn_end,
        )
        for rec in runs
    )

    return SessionRunsPayload(
        session_id=session_id,
        branch_id=head_branch_id,
        runs=run_payloads,
        usage_by_run=usage_json,
    )


__all__ = ("build_session_runs_payload",)
