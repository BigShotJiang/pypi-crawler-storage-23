"""Typed REPL actions emitted by command handlers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.commands.model import LastArtifactKind, LastArtifactMode


class ReplAction:
    """Marker base class for structural REPL actions."""


@dataclass(frozen=True)
class ReplActionExit(ReplAction):
    """Request REPL exit."""


@dataclass(frozen=True)
class ReplActionNewSession(ReplAction):
    """Start a fresh REPL session with a new backing store session."""

    notice: str | None = None


@dataclass(frozen=True)
class ReplActionAttachSession(ReplAction):
    """Attach REPL to an existing stored session."""

    session_id: str


@dataclass(frozen=True)
class ReplActionSessionRuns(ReplAction):
    """Render recent runs for the active session."""

    limit: int | None = None


@dataclass(frozen=True)
class ReplActionBranchList(ReplAction):
    """Render branches for the active session."""


@dataclass(frozen=True)
class ReplActionBranchUse(ReplAction):
    """Switch to a branch by id."""

    branch_id: str


@dataclass(frozen=True)
class ReplActionBranchNew(ReplAction):
    """Create a new branch from head and switch to it."""

    branch_id: str | None = None


@dataclass(frozen=True)
class ReplActionBranchFork(ReplAction):
    """Create a new branch from a run and switch to it."""

    run_number: int
    branch_id: str | None = None


@dataclass(frozen=True)
class ReplActionBranchDelete(ReplAction):
    """Delete a branch by id."""

    branch_id: str
    force: bool = False


@dataclass(frozen=True)
class ReplActionBranchRuns(ReplAction):
    """Render runs for a branch."""

    limit: int | None = None
    branch_id: str | None = None


@dataclass(frozen=True)
class ReplActionAgentSwitch(ReplAction):
    """Switch agent and branch from head."""

    notice: str | None = None


@dataclass(frozen=True)
class ReplActionSendAgain(ReplAction):
    """Re-run the previous prompt immediately."""


@dataclass(frozen=True)
class ReplActionSendPrompt(ReplAction):
    """Send a specific prompt without going through the input buffer."""

    prompt: str
    use_last: bool = False
    record_prompt: bool = True


@dataclass(frozen=True)
class ReplActionEditLast(ReplAction):
    """Prefill the input with the last prompt for editing."""


@dataclass(frozen=True)
class ReplActionContinue(ReplAction):
    """Continue after a cancelled/timeout run without adding a new user message.

    This action starts a new run with an empty input list. The workflow layer
    will replay any cancelled-attempt items (and other resume backfill) as the
    first coherent input for the run.
    """

    use_last: bool = True


@dataclass(frozen=True)
class ReplActionCompress(ReplAction):
    """Trigger a compression request for the current session."""

    notice: str | None = None


@dataclass(frozen=True)
class ReplActionCompressShow(ReplAction):
    """Render the most recent compression continuation for the current session."""


@dataclass(frozen=True)
class ReplActionLastArtifact(ReplAction):
    """Render the most recent captured artifact without re-parsing output."""

    kind: LastArtifactKind
    mode: LastArtifactMode = "preview"


@dataclass(frozen=True)
class ReplActionErrors(ReplAction):
    """Render the current stderr error buffer."""


@dataclass(frozen=True)
class ReplActionModelPicker(ReplAction):
    """Open the interactive route-first model picker modal."""

    route: str | None = None
