"""One-shot execution for `agenterm run`."""

from __future__ import annotations

import asyncio
from dataclasses import replace
from typing import TYPE_CHECKING, NoReturn

import typer
from agents.exceptions import MaxTurnsExceeded

from agenterm.app.services import RunRequest, prepare_run_context
from agenterm.cli.output_format import OutputFormat
from agenterm.commands.run_exec import execute_one_shot_run
from agenterm.commands.run_flags import (
    build_run_flags,
    require_api_key,
    resolve_run_modes,
)
from agenterm.commands.run_input import (
    RunUsageError,
    build_input_bundle,
    resolve_prompt_and_attachments,
)
from agenterm.commands.run_render import (
    emit_usage_error,
    postprocess_emit_line_from_modes,
    render_agent_source_note,
    render_config_source_note,
)
from agenterm.commands.run_support import (
    RunModes,
    build_payload,
    emit_error,
    render_success,
)
from agenterm.core.error_report import ErrorContext, build_error_report
from agenterm.core.errors import AgentermError, ConfigError, PipelineError
from agenterm.core.model_id import model_plane
from agenterm.store.async_db import close_store_registry
from agenterm.ui.cli_renderer import render_error_report

if TYPE_CHECKING:
    from agenterm.commands.cli_args import RunCliArgs
    from agenterm.core.json_types import JSONValue


def _exit(code: int) -> NoReturn:
    raise typer.Exit(code)


async def _run_command_with_args(opts_parsed: RunCliArgs) -> None:
    """Execute a one-shot prompt with pre-parsed arguments."""
    trace_id_effective: str | None = None
    provider_label: str | None = None
    modes = RunModes(
        live=False,
        output_format=(
            opts_parsed.format_override
            if opts_parsed.format_override is not None
            else OutputFormat.human
        ),
    )

    try:
        output_fmt_usage = (
            OutputFormat.json
            if opts_parsed.format_override is OutputFormat.json
            else OutputFormat.human
        )
        flags = build_run_flags(opts_parsed)
        try:
            prompt, attachments = resolve_prompt_and_attachments(opts_parsed)
        except RunUsageError as exc:
            emit_usage_error(
                message=str(exc),
                output_format=output_fmt_usage,
                emit_error=emit_error,
            )
            _exit(2)

        ctx = await prepare_run_context(
            RunRequest(
                flags=flags,
                session_id=opts_parsed.session_id,
                branch_id=opts_parsed.branch_id,
            ),
        )
        provider_label = model_plane(ctx.cfg.agent.model)
        trace_id_effective = ctx.cfg.run.trace_id
        modes = resolve_run_modes(opts_parsed, ctx.cfg.run)
        render_config_source_note(
            explicit=opts_parsed.config,
            resolved=ctx.cfg_bundle.config_path,
        )
        render_agent_source_note(cfg=ctx.cfg)
        require_api_key(ctx.cfg.agent.model)

        bundle = await build_input_bundle(
            cfg=ctx.cfg,
            model_id=ctx.cfg.agent.model,
            prompt=prompt,
            attachments=attachments,
        )

        run_context = ErrorContext(
            operation="run",
            resource="run",
            trace_id=trace_id_effective,
        )
        emit_line = postprocess_emit_line_from_modes(
            modes,
            context=run_context,
        )
        executed = await execute_one_shot_run(
            ctx,
            bundle=bundle,
            modes=modes,
            emit_line=emit_line,
        )

        payload = await build_payload(
            executed.result,
            attachments=attachments,
            session_id=executed.run_ctx.session_id,
            mode=("quiet" if ctx.background else ("live" if modes.live else "quiet")),
            background=bool(ctx.background),
        )
        if isinstance(executed.final_response_id, str) and executed.final_response_id:
            payload = replace(payload, response_id=executed.final_response_id)

        exit_code = render_success(
            payload=payload,
            modes=modes,
            trace_id=trace_id_effective,
        )
        _exit(exit_code)
    except (ConfigError, PipelineError, AgentermError, MaxTurnsExceeded) as exc:
        extra: dict[str, JSONValue] | None = None
        if provider_label is not None:
            extra = {"provider": provider_label}
        report = build_error_report(
            exc,
            context=ErrorContext(
                operation="run",
                resource="run",
                trace_id=trace_id_effective,
            ),
            extra_details=extra,
        )
        emit_error(output_format=modes.output_format, report=report)
        _exit(2)
    finally:
        try:
            await close_store_registry()
        except AgentermError as exc:
            report = build_error_report(
                exc,
                context=ErrorContext(
                    operation="run.store.cleanup",
                    resource="run.store.cleanup",
                    trace_id=trace_id_effective,
                ),
            )
            render_error_report(report)


def run_command_with_args(opts_parsed: RunCliArgs) -> None:
    """Execute a one-shot prompt with pre-parsed arguments."""
    asyncio.run(_run_command_with_args(opts_parsed))


__all__ = ("run_command_with_args",)
