"""Run execution helpers for `agenterm run`."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from agenterm.config.paths import meta_store_path
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.tool_selection import selected_mcp_server_configs
from agenterm.ui.renderer import status_spinner
from agenterm.ui.transcript.policy import transcript_policy_from_config
from agenterm.ui.transcript.render import render_run_item
from agenterm.workflow.run.execute_background import execute_background_run
from agenterm.workflow.run.execute_streamed import execute_streamed_run
from agenterm.workflow.run.model import (
    RunExecutionContext,
    StreamedRunRequest,
    StreamEventCallbacks,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from agents.items import RunItem
    from agents.result import RunResultBase

    from agenterm.app.services import RunContext
    from agenterm.commands.run_support import RunInputBundle, RunModes
    from agenterm.core.plan import PlanSnapshot
    from agenterm.ui.transcript.render import PlanSnapshotLoader


@dataclass(frozen=True)
class OneShotRunResult:
    """Outputs from executing a single one-shot agent run."""

    result: RunResultBase
    final_response_id: str | None
    run_ctx: RunExecutionContext


async def execute_one_shot_run(
    ctx: RunContext,
    *,
    bundle: RunInputBundle,
    modes: RunModes,
    emit_line: Callable[[str], None] | None,
) -> OneShotRunResult:
    """Execute one-shot run (background or streamed foreground)."""
    selected_caps = ctx.cfg_bundle.selected_tools if ctx.tools_enabled else None
    selected_servers = (
        selected_mcp_server_configs(selected_caps) if selected_caps else ()
    )
    cfg_for_run = (
        replace(ctx.cfg, mcp=replace(ctx.cfg.mcp, servers=list(selected_servers)))
        if selected_servers != tuple(ctx.cfg.mcp.servers or ())
        else ctx.cfg
    )
    db_path = meta_store_path()
    plan_cache: dict[str, PlanSnapshot] = {}
    tool_context = ToolRuntimeContext(
        db_path=db_path,
        session_id=ctx.session_id if isinstance(ctx.session_id, str) else None,
        branch_id=ctx.branch_id,
        run_number=None,
        trace_id=cfg_for_run.run.trace_id,
        plan_cache=plan_cache,
        cancel_token=None,
    )
    plan_snapshot_loader: PlanSnapshotLoader | None = None
    session_id = ctx.session_id
    if isinstance(session_id, str) and session_id:

        def _load_snapshot(call_id: str) -> PlanSnapshot | None:
            return plan_cache.get(call_id)

        plan_snapshot_loader = _load_snapshot

    run_ctx_base = RunExecutionContext(
        cfg=cfg_for_run,
        agent=ctx.agent,
        session=ctx.session,
        session_id=ctx.session_id if isinstance(ctx.session_id, str) else None,
        branch_id=ctx.branch_id,
        store_enabled=ctx.agenterm_store,
        interactive=False,
        workflow_name="agenterm run",
        approvals=ctx.approvals,
        mcp_pool=None,
        tool_context=tool_context,
    )

    if ctx.background:
        run_ctx = replace(run_ctx_base, workflow_name="agenterm run (background)")
        with status_spinner("Running in background..."):
            bg = await execute_background_run(
                run_ctx,
                input_items=bundle.input_items,
                emit_line=emit_line,
            )
        return OneShotRunResult(
            result=bg.result,
            final_response_id=bg.post.response_id,
            run_ctx=run_ctx,
        )

    run_ctx = run_ctx_base
    reasoning_summary_max = ctx.cfg.repl.ux.reasoning_summary_max_chars
    policy = transcript_policy_from_config(
        verbosity="normal",
        reasoning_mode="summary",
        diffs_mode="summary",
        reasoning_summary_max_chars=reasoning_summary_max,
        tool_output_max_chars=ctx.cfg.tools.max_chars,
        transcript_cfg=ctx.cfg.repl.transcript,
    )

    def _on_run_item(item: RunItem) -> None:
        render_run_item(
            item,
            policy=policy,
            plan_snapshot_loader=plan_snapshot_loader,
        )

    callbacks = (
        StreamEventCallbacks(on_run_item=_on_run_item)
        if modes.live and emit_line is not None
        else StreamEventCallbacks()
    )
    streamed = await execute_streamed_run(
        run_ctx,
        StreamedRunRequest(
            input_items=bundle.input_items,
            callbacks=callbacks,
            stream_mode="final",
            retry_policy=run_ctx.cfg.retries.provider,
            postprocess_emit_line=emit_line,
            retry_emit_line=emit_line,
        ),
    )
    return OneShotRunResult(
        result=streamed.streaming,
        final_response_id=streamed.post.response_id,
        run_ctx=run_ctx,
    )


__all__ = ("OneShotRunResult", "execute_one_shot_run")
