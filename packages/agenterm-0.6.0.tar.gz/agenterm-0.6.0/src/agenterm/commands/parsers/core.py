"""Core parsers for common REPL slash commands."""

from __future__ import annotations

from typing import TYPE_CHECKING, Final

from agenterm.commands.model import (
    AgentCmd,
    AgentListCmd,
    AgentShowCmd,
    AttachCmd,
    AttachmentsShowCmd,
    ClearCmd,
    Command,
    CompressCmd,
    CompressShowCmd,
    DetachAllCmd,
    DetachPathCmd,
    ModelCmd,
    ModelPickCmd,
)
from agenterm.commands.parsers.base import ordered
from agenterm.constants.defaults import (
    DEFAULT_OLLAMA_MODEL_SUGGESTIONS,
    DEFAULT_OPENAI_MODELS,
    DEFAULT_OPENROUTER_ALLOWLIST,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.config.model import GatewayRouteConfig
    from agenterm.core.types import SessionState

_ATTACH_REMOVE_ARG_COUNT: Final[int] = 2


def _parse_model_route(raw: str) -> str | None:
    token = raw.strip()
    if not token:
        return None
    head = token.lower()
    if head == "openai":
        return "openai"
    if head in {"openrouter", "ollama"}:
        return head
    if head.startswith("gateway/"):
        _, _, tail = head.partition("/")
        if tail and "/" not in tail:
            return tail
    return None


def parse_model(args: list[str]) -> Command | None:
    """Parse '/model' arguments into a Command.

    Args:
      args: Remaining tokens after the head.

    Returns:
      ModelPickCmd on no args or a route token; ModelCmd on a single model token;
      otherwise None.

    """
    if not args:
        return ModelPickCmd(route=None)
    if len(args) != 1:
        return None
    route = _parse_model_route(args[0])
    if route is not None:
        return ModelPickCmd(route=route)
    return ModelCmd(args[0])


def _route_map(state: SessionState | None) -> Mapping[str, GatewayRouteConfig]:
    if state is None:
        return {}
    return state.cfg.providers.gateway.routes


def _ordered_gateway_routes(
    route_map: Mapping[str, GatewayRouteConfig],
) -> list[str]:
    preferred = ("openrouter", "ollama")
    seen: set[str] = set()
    ordered_routes: list[str] = []
    for route in preferred:
        if route in route_map and route not in seen:
            seen.add(route)
            ordered_routes.append(route)
    for route in sorted(route_map.keys()):
        if route in seen:
            continue
        seen.add(route)
        ordered_routes.append(route)
    return ordered_routes


def _route_candidates(state: SessionState | None) -> list[str]:
    route_map = _route_map(state)
    routes = (
        _ordered_gateway_routes(route_map) if route_map else ["openrouter", "ollama"]
    )
    return ["openai ", *[f"{route} " for route in routes]]


def _suggested_model_ids(state: SessionState | None) -> list[str]:
    """Build recommended model candidates from provider suggestions."""
    ids: list[str] = []
    if state is None:
        ids.extend([f"openai/{model}" for model in DEFAULT_OPENAI_MODELS])
        ids.extend(
            [f"gateway/openrouter/{model}" for model in DEFAULT_OPENROUTER_ALLOWLIST],
        )
        ids.extend(
            [f"gateway/ollama/{model}" for model in DEFAULT_OLLAMA_MODEL_SUGGESTIONS],
        )
        return ids
    ids.extend(
        [f"openai/{model}" for model in state.cfg.providers.openai.model_suggestions],
    )
    for route_name, route_cfg in state.cfg.providers.gateway.routes.items():
        ids.extend(
            [f"gateway/{route_name}/{model}" for model in route_cfg.model_suggestions],
        )
    return ids


def _unique_preserve(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        out.append(item)
    return out


def _complete_model_root(*, model_name: str, state: SessionState | None) -> list[str]:
    candidates: list[str] = []
    candidates.extend(_route_candidates(state))
    if model_name:
        candidates.append(model_name)
    candidates.extend(_suggested_model_ids(state))
    return _unique_preserve(candidates)


def _complete_model_head_token(
    token: str,
    *,
    model_name: str,
    state: SessionState | None,
) -> list[str]:
    prefix = token.lower()
    candidates: list[str] = []
    candidates.extend(
        [
            route
            for route in _route_candidates(state)
            if route.lower().startswith(prefix)
        ],
    )
    if model_name and model_name.lower().startswith(prefix):
        candidates.append(model_name)
    candidates.extend(
        [mid for mid in _suggested_model_ids(state) if mid.lower().startswith(prefix)],
    )
    return _unique_preserve(candidates)


def complete_model(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /model."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    model_name = state.cfg.agent.model if state is not None else ""
    if not parts:
        return _complete_model_root(model_name=model_name, state=state)
    if len(parts) == 1 and not trailing_space:
        return _complete_model_head_token(
            parts[0],
            model_name=model_name,
            state=state,
        )
    return []


def parse_agent(args: list[str]) -> Command | None:
    """Parse '/agent' commands (show/list/switch).

    Args:
      args: Remaining tokens after the head.

    Returns:
      AgentShowCmd on no args or `show`, AgentListCmd on `list`, AgentCmd on a
      single name argument; else None.

    """
    if not args:
        return AgentShowCmd()
    head = args[0].lower()
    if head == "show":
        return AgentShowCmd() if len(args) == 1 else None
    if head == "list":
        return AgentListCmd() if len(args) == 1 else None
    return AgentCmd(name=args[0]) if len(args) == 1 else None


def complete_agent(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /agent."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    agent_name = state.cfg.agent.name if state is not None else ""
    candidates: list[str] = []
    if not parts:
        candidates.extend(["show ", "list "])
        if agent_name:
            candidates.append(agent_name)
        return ordered(candidates)
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        if "show".startswith(prefix):
            candidates.append("show ")
        if "list".startswith(prefix):
            candidates.append("list ")
        if agent_name and agent_name.lower().startswith(prefix):
            candidates.append(agent_name)
        return ordered(candidates)
    return []


def parse_attach(args: list[str]) -> Command | None:
    """Parse '/attach' commands.

    Args:
      args: Remaining tokens after the head.

    Returns:
      AttachmentsShowCmd on no args or `list`, ClearCmd on `clear`, DetachAllCmd
      / DetachPathCmd on `remove`, or AttachCmd on a single path/URL.

    """
    if not args:
        return AttachmentsShowCmd()
    head = args[0].lower()
    if head == "list":
        return AttachmentsShowCmd() if len(args) == 1 else None
    if head == "clear":
        return ClearCmd() if len(args) == 1 else None
    if head == "remove":
        if len(args) != _ATTACH_REMOVE_ARG_COUNT:
            return None
        tok = args[1]
        return DetachAllCmd() if tok.lower() == "all" else DetachPathCmd(path=tok)
    return AttachCmd(path=args[0]) if len(args) == 1 else None


def parse_compress(args: list[str]) -> Command | None:
    """Parse '/compress' into a CompressCmd or CompressShowCmd."""
    if len(args) == 0:
        return CompressCmd()
    if len(args) == 1 and args[0].lower() == "show":
        return CompressShowCmd()
    return None


__all__ = (
    "complete_agent",
    "complete_model",
    "parse_agent",
    "parse_attach",
    "parse_compress",
    "parse_model",
)
