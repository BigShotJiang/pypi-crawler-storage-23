"""Parser and completer for /artifacts commands."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import TYPE_CHECKING, Protocol

from agenterm.commands.model import (
    ArtifactsAgentRunCmd,
    ArtifactsListCmd,
    ArtifactsOpenCmd,
    ArtifactsShowCmd,
    Command,
)
from agenterm.commands.parsers.base import ordered

if TYPE_CHECKING:
    from agenterm.core.types import SessionState

_ARTIFACTS_SUBCOMMANDS: tuple[str, ...] = ("list", "show", "open", "agent-run")
_ARTIFACTS_HEAD_CANDIDATES: tuple[str, ...] = (
    "list ",
    "show ",
    "open ",
    "agent-run ",
)
_LIST_SUGGESTIONS: tuple[str, ...] = ("5", "10", "20", "50")
_ARTIFACT_ID_SUGGESTION_LIMIT = 15

ParserFn = Callable[[list[str]], Command | None]


class CompleterFn(Protocol):
    def __call__(
        self,
        args: list[str],
        *,
        trailing_space: bool = False,
    ) -> list[str]: ...


def _load_artifact_ids(state: SessionState | None) -> list[str]:
    if state is None:
        return []
    return list(state.caches.artifact_ids or ())


def parse_artifacts(args: list[str]) -> Command | None:
    """Parse '/artifacts' commands.

    Supported forms:
    - /artifacts list [N]
    - /artifacts show <ID>
    - /artifacts open <ID>
    - /artifacts agent-run <ID>
    """
    if not args:
        return ArtifactsListCmd(limit=20)
    sub = args[0].lower()
    rest = args[1:]

    parser = _PARSERS.get(sub)
    if parser is None:
        return None
    return parser(rest)


def _parse_list(args: list[str]) -> Command | None:
    if not args:
        return ArtifactsListCmd(limit=20)
    if len(args) != 1:
        return None
    try:
        n = int(args[0], 10)
    except ValueError:
        return None
    return ArtifactsListCmd(limit=n)


def _parse_id_only(
    cls: type[ArtifactsShowCmd | ArtifactsOpenCmd | ArtifactsAgentRunCmd],
    args: list[str],
) -> Command | None:
    if len(args) != 1:
        return None
    return cls(artifact_id=args[0])


_PARSERS: Mapping[str, ParserFn] = {
    "list": _parse_list,
    "show": lambda rest: _parse_id_only(ArtifactsShowCmd, rest),
    "open": lambda rest: _parse_id_only(ArtifactsOpenCmd, rest),
    "agent-run": lambda rest: _parse_id_only(ArtifactsAgentRunCmd, rest),
}


def _complete_head(parts: list[str], *, trailing_space: bool) -> list[str] | None:
    if not parts:
        return ordered(_ARTIFACTS_HEAD_CANDIDATES)
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([c for c in _ARTIFACTS_HEAD_CANDIDATES if c.startswith(prefix)])
    return None


def _complete_list(args: list[str], *, trailing_space: bool = False) -> list[str]:
    _ = trailing_space
    if not args:
        return ordered(_LIST_SUGGESTIONS)
    if len(args) == 1:
        if trailing_space:
            return []
        prefix = args[0]
        return ordered([v for v in _LIST_SUGGESTIONS if v.startswith(prefix)])
    return []


def _complete_id(
    args: list[str],
    *,
    trailing_space: bool = False,
    state: SessionState | None = None,
) -> list[str]:
    if not args:
        return (
            ordered(_load_artifact_ids(state)[:_ARTIFACT_ID_SUGGESTION_LIMIT])
            if trailing_space
            else []
        )
    if len(args) == 1:
        if trailing_space:
            return []
        prefix = args[0]
        ids = _load_artifact_ids(state)
        return ordered([i for i in ids if i.startswith(prefix)])
    return []


_COMPLETERS: Mapping[str, CompleterFn] = {
    "list": _complete_list,
    "show": _complete_id,
    "open": _complete_id,
    "agent-run": _complete_id,
}


def complete_artifacts(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /artifacts."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    head = _complete_head(parts, trailing_space=trailing_space)
    if head is not None:
        return head
    sub = parts[0].lower()
    completer = _COMPLETERS.get(sub)
    if completer is None:
        return []
    if sub in {"show", "open", "agent-run"}:
        return _complete_id(
            parts[1:],
            trailing_space=trailing_space,
            state=state,
        )
    return completer(parts[1:], trailing_space=trailing_space)


__all__ = ("complete_artifacts", "parse_artifacts")
