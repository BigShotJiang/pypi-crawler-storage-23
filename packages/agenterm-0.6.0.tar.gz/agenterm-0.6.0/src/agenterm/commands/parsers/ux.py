"""Parser and completer for /ux commands (REPL UX toggles)."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final

from agenterm.commands.model import (
    Command,
    UxDiffsCmd,
    UxMarkdownCmd,
    UxReasoningCmd,
    UxShowCmd,
    UxStreamCmd,
    UxVerbosityCmd,
)
from agenterm.commands.parsers.base import ordered
from agenterm.core.choices.repl import (
    REPL_DIFFS_MODES,
    REPL_REASONING_MODES,
    REPL_STREAM_MODES,
    REPL_VERBOSITIES,
)

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


_UX_HEADS: tuple[str, ...] = (
    "markdown",
    "reasoning",
    "diffs",
    "stream",
    "verbosity",
)

_UX_VALUES_BY_HEAD = MappingProxyType(
    {
        "markdown": ("on", "off"),
        "reasoning": REPL_REASONING_MODES,
        "diffs": REPL_DIFFS_MODES,
        "stream": REPL_STREAM_MODES,
        "verbosity": REPL_VERBOSITIES,
    },
)

_UX_PAIR_LEN: Final = 2
_UX_PAIR_COMMANDS = MappingProxyType(
    {
        ("markdown", "on"): UxMarkdownCmd(on=True),
        ("markdown", "off"): UxMarkdownCmd(on=False),
        **{
            ("reasoning", mode): UxReasoningCmd(mode=mode)
            for mode in REPL_REASONING_MODES
        },
        **{("diffs", mode): UxDiffsCmd(mode=mode) for mode in REPL_DIFFS_MODES},
        **{("stream", mode): UxStreamCmd(mode=mode) for mode in REPL_STREAM_MODES},
        **{("verbosity", mode): UxVerbosityCmd(mode=mode) for mode in REPL_VERBOSITIES},
    },
)


def parse_ux(args: list[str]) -> Command | None:
    """Parse '/ux' commands.

    Supported forms:
    - /ux                          -> UxShowCmd
    - /ux markdown on|off          -> UxMarkdownCmd
    - /ux reasoning off|summary    -> UxReasoningCmd
    - /ux diffs off|summary        -> UxDiffsCmd
    - /ux stream final|live        -> UxStreamCmd
    - /ux verbosity quiet|normal|debug -> UxVerbosityCmd
    """
    if not args:
        return UxShowCmd()
    if len(args) != _UX_PAIR_LEN:
        return None
    return _UX_PAIR_COMMANDS.get((args[0].lower(), args[1].lower()))


def complete_ux(rest: str, _state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /ux subcommands."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")

    if not parts:
        return ordered([f"{h} " for h in _UX_HEADS])

    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([f"{h} " for h in _UX_HEADS if h.startswith(prefix)])

    head = parts[0].lower()
    values = _UX_VALUES_BY_HEAD.get(head)
    if values is None:
        return []
    if len(parts) == 1 and trailing_space:
        return ordered(list(values))
    if len(parts) == _UX_PAIR_LEN and not trailing_space:
        val_prefix = parts[1].lower()
        return ordered([v for v in values if v.startswith(val_prefix)])
    return []


__all__ = ("complete_ux", "parse_ux")
