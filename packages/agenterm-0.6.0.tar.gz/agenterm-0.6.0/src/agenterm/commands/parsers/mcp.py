"""Parser and completer for `/mcp` REPL subcommands.

Implements minimal parse/complete over a small, explicit data table.
"""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING

from agenterm.commands.model import Command, McpRefreshCmd, McpStatusCmd
from agenterm.commands.parsers.base import ordered

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agenterm.core.types import SessionState

# Shared tables to keep parse/complete in sync
MCP_COMPLETION_HEADS: tuple[str, ...] = ("refresh", "status")
MCP_COMPLETION_SUGGESTIONS: Mapping[str, tuple[str, ...]] = MappingProxyType(
    {
        "refresh": (),
        "status": (),
    },
)


def parse_mcp(args: list[str]) -> Command | None:
    """Parse '/mcp' subcommands into Commands.

    Args:
      args: Argument tokens after '/mcp'.

    Returns:
      A concrete Command or None if parsing fails.

    """
    if not args:
        return None
    sub = args[0].lower()
    rest = args[1:]

    def _refresh(r: list[str]) -> Command | None:
        return McpRefreshCmd() if not r else None

    def _status(r: list[str]) -> Command | None:
        return McpStatusCmd() if not r else None

    table: Mapping[str, Callable[[list[str]], Command | None]] = MappingProxyType(
        {"refresh": _refresh, "status": _status},
    )
    fn = table.get(sub)
    return fn(rest) if fn else None


def complete_mcp(rest: str, _state: SessionState | None = None) -> list[str]:
    """Complete `/mcp` subcommands using a small data table.

    Rules:
    - Suggest subcommand heads when empty or partial.
    - After a space following a known head, no additional arguments are suggested.

    Args:
      rest: Raw remainder of the input after '/mcp'.

    Returns:
      A list of completion candidates ordered deterministically.

    """
    s = rest
    heads = MCP_COMPLETION_HEADS
    raw = s.strip()
    if not raw:
        return ordered(heads)
    parts = s.split()
    head = parts[0].lower()
    if len(parts) == 1 and not s.endswith(" "):
        return ordered([h for h in heads if h.startswith(head)])
    # After a known head and a space
    table: Mapping[str, tuple[str, ...]] = MCP_COMPLETION_SUGGESTIONS
    key = head.rstrip()
    return ordered(table.get(key, []))
