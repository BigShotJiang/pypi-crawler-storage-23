"""Parser and completer for `/last` REPL command."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.model import LastCmd
from agenterm.commands.parsers.base import ordered

_SUBCOMMANDS: tuple[str, ...] = ("diff", "tools", "approvals")
_MODES: tuple[str, ...] = ("preview", "full")
_KIND_ONLY_LEN = 1
_KIND_MODE_LEN = 2

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


def parse_last(args: list[str]) -> LastCmd | None:
    """Parse `/last` commands into typed commands.

    Supported forms:
    - /last diff
    - /last diff preview|full
    - /last tools
    - /last tools preview|full
    """
    if not args:
        return None
    head = args[0].lower()
    if head not in _SUBCOMMANDS:
        return None

    if head == "diff":
        kind = "diff"
    elif head == "tools":
        kind = "tools"
    else:
        kind = "approvals"

    if len(args) == _KIND_ONLY_LEN:
        mode = "preview"
    elif len(args) == _KIND_MODE_LEN:
        mode_str = args[1].lower()
        if mode_str not in _MODES:
            return None
        mode = "full" if mode_str == "full" else "preview"
    else:
        return None

    return LastCmd(kind=kind, mode=mode)


def complete_last(rest: str, _state: SessionState | None = None) -> list[str]:
    """Return completion suggestions for `/last`."""
    _ = _state
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")

    if not parts:
        return ordered([f"{sub} " for sub in _SUBCOMMANDS])

    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([f"{sub} " for sub in _SUBCOMMANDS if sub.startswith(prefix)])

    if len(parts) == 1 and trailing_space:
        return ordered(list(_MODES))

    if len(parts) == _KIND_MODE_LEN and not trailing_space:
        prefix = parts[1].lower()
        return ordered([m for m in _MODES if m.startswith(prefix)])

    return []


__all__ = ("complete_last", "parse_last")
