"""Parser and completer for /inspect commands."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

from agenterm.commands.model import Command, InspectAgentRunCmd
from agenterm.commands.parsers.base import ordered

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


_HEAD_CANDIDATES: tuple[str, ...] = ("agent-run ",)
_JSON_FLAGS: tuple[str, ...] = ("--json", "json")
_ARTIFACT_ID_SUGGESTION_LIMIT = 15
_MAX_ARGS = 2


class CompleterFn(Protocol):
    def __call__(
        self,
        args: list[str],
        *,
        trailing_space: bool = False,
        state: SessionState | None = None,
    ) -> list[str]: ...


def _load_artifact_ids(state: SessionState | None) -> list[str]:
    if state is None:
        return []
    return list(state.caches.artifact_ids or ())


def parse_inspect(args: list[str]) -> Command | None:
    """Parse '/inspect' commands.

    Supported forms:
    - /inspect agent-run <ID> [--json]
    """
    if not args:
        return None
    sub = args[0].lower()
    rest = args[1:]
    if sub != "agent-run":
        return None
    if not rest:
        return None
    report_id = rest[0]
    json_output = False
    if len(rest) == _MAX_ARGS:
        flag = rest[1].lower()
        if flag not in _JSON_FLAGS:
            return None
        json_output = True
    elif len(rest) > _MAX_ARGS:
        return None
    return InspectAgentRunCmd(report_id=report_id, json_output=json_output)


def _complete_head(parts: list[str], *, trailing_space: bool) -> list[str] | None:
    if not parts:
        return ordered(_HEAD_CANDIDATES)
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([c for c in _HEAD_CANDIDATES if c.startswith(prefix)])
    return None


def _complete_agent_run(
    args: list[str],
    *,
    trailing_space: bool = False,
    state: SessionState | None = None,
) -> list[str]:
    if not args:
        return ordered(_load_artifact_ids(state)[:_ARTIFACT_ID_SUGGESTION_LIMIT])
    if len(args) == 1:
        if trailing_space:
            return ordered([f"{flag} " for flag in _JSON_FLAGS])
        prefix = args[0]
        ids = _load_artifact_ids(state)
        return ordered([i for i in ids if i.startswith(prefix)])
    if len(args) == _MAX_ARGS:
        if trailing_space:
            return []
        prefix = args[1].lower()
        return ordered([f for f in _JSON_FLAGS if f.startswith(prefix)])
    return []


_COMPLETERS: dict[str, CompleterFn] = {
    "agent-run": _complete_agent_run,
}


def complete_inspect(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /inspect subcommands."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    head = _complete_head(parts, trailing_space=trailing_space)
    if head is not None:
        return head
    if not parts:
        return []
    sub = parts[0].lower()
    args = parts[1:]
    completer = _COMPLETERS.get(sub)
    if completer is None:
        return []
    return completer(args, trailing_space=trailing_space, state=state)


__all__ = ("complete_inspect", "parse_inspect")
