"""Parser and completer for `/resilience` REPL subcommands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.model import Command, ResilienceShowCmd
from agenterm.commands.parsers.base import ordered

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


def parse_resilience(args: list[str]) -> Command | None:
    """Parse `/resilience` into a typed command."""
    if not args:
        return ResilienceShowCmd()
    if len(args) == 1 and args[0].lower() == "show":
        return ResilienceShowCmd()
    return None


def complete_resilience(
    rest: str,
    _state: SessionState | None = None,
) -> list[str]:
    """Complete `/resilience` subcommands."""
    raw = rest.strip()
    if not raw:
        return ordered(["show"])
    if len(rest.split()) == 1 and not rest.endswith(" "):
        prefix = rest.strip().lower()
        return ordered([item for item in ("show",) if item.startswith(prefix)])
    return []


__all__ = ("complete_resilience", "parse_resilience")
