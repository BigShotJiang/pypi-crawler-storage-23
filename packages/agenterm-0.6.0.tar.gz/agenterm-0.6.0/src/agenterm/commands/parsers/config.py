"""Parser for consolidated /config command."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import TYPE_CHECKING, Protocol

from agenterm.commands.model import (
    Command,
    KeyCmd,
    ReasoningEffortCmd,
    ReasoningShowCmd,
    ReasoningSummaryCmd,
    ReasoningUnsetCmd,
    VerbosityCmd,
    VerbosityShowCmd,
)
from agenterm.commands.parsers.base import ordered
from agenterm.core.choices.common import UNSET_MARKER
from agenterm.core.choices.model import (
    MODEL_VERBOSITIES,
    REASONING_EFFORTS,
    REASONING_SUMMARIES,
)

if TYPE_CHECKING:
    from agenterm.core.types import SessionState

_SUBCOMMANDS: tuple[str, ...] = (
    "key",
    "verbosity",
    "reasoning",
)
_VERBOSITY_VALUES: tuple[str, ...] = (*MODEL_VERBOSITIES, UNSET_MARKER)
_REASONING_EFFORT_VALUES: tuple[str, ...] = (*REASONING_EFFORTS, UNSET_MARKER)
_REASONING_SUMMARY_VALUES: tuple[str, ...] = (*REASONING_SUMMARIES, UNSET_MARKER)
_REASONING_PAIR_LEN = 2
ParserFn = Callable[[list[str]], Command | None]


class CompleterFn(Protocol):
    def __call__(
        self,
        args: list[str],
        *,
        trailing_space: bool = False,
    ) -> list[str]: ...


def parse_config(args: list[str]) -> Command | None:
    """Parse '/config' commands with subcommand dispatch.

    Supported forms:
    - /config key <API_KEY>
    - /config verbosity [low|medium|high|unset]
    - /config reasoning [unset|effort <LEVEL>|summary <MODE>]
    """
    if not args:
        return None
    sub = args[0].lower()
    rest = args[1:]

    parser = _PARSERS.get(sub)
    if parser is None:
        return None
    return parser(rest)


def _parse_key(args: list[str]) -> Command | None:
    """Parse 'key <API_KEY>'."""
    return KeyCmd(value=args[0]) if len(args) == 1 else None


def _parse_verbosity(args: list[str]) -> Command | None:
    """Parse 'verbosity [low|medium|high|unset]'."""
    if not args:
        return VerbosityShowCmd()
    if len(args) != 1:
        return None
    level = args[0].lower()
    if level == UNSET_MARKER:
        return VerbosityCmd(level=None)
    if level in MODEL_VERBOSITIES:
        return VerbosityCmd(level=level)
    return None


def _parse_reasoning(args: list[str]) -> Command | None:
    """Parse 'reasoning [unset|effort <LEVEL>|summary <MODE>]'."""
    if not args:
        return ReasoningShowCmd()
    head = args[0].lower()
    result: Command | None = None
    if head == UNSET_MARKER:
        if len(args) == 1:
            result = ReasoningUnsetCmd()
    elif len(args) == _REASONING_PAIR_LEN:
        val = args[1].lower()
        if head == "effort" and val in _REASONING_EFFORT_VALUES:
            effort = None if val == UNSET_MARKER else val
            result = ReasoningEffortCmd(effort=effort)
        if head == "summary" and val in _REASONING_SUMMARY_VALUES:
            summary = None if val == UNSET_MARKER else val
            result = ReasoningSummaryCmd(summary=summary)
    return result


_PARSERS: Mapping[str, ParserFn] = {
    "key": _parse_key,
    "verbosity": _parse_verbosity,
    "reasoning": _parse_reasoning,
}


def _complete_config_head(
    parts: list[str],
    *,
    trailing_space: bool,
) -> list[str] | None:
    if not parts:
        return ordered([f"{sub} " for sub in _SUBCOMMANDS])
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        candidates = [f"{sub} " for sub in _SUBCOMMANDS]
        return ordered([c for c in candidates if c.startswith(prefix)])
    return None


def _complete_key(args: list[str], *, trailing_space: bool = False) -> list[str]:
    _ = args
    _ = trailing_space
    return []


def _complete_verbosity(args: list[str], *, trailing_space: bool = False) -> list[str]:
    if not args:
        return ordered(_VERBOSITY_VALUES)
    if len(args) == 1:
        if trailing_space:
            return []
        prefix = args[0].lower()
        return ordered([v for v in _VERBOSITY_VALUES if v.startswith(prefix)])
    if trailing_space:
        return []
    return []


def _complete_reasoning(args: list[str], *, trailing_space: bool = False) -> list[str]:
    head_options = [UNSET_MARKER, "effort ", "summary "]
    suggestions: list[str] = []
    if not args:
        suggestions = head_options
    elif len(args) == 1:
        head = args[0].lower()
        if head == "effort" and trailing_space:
            suggestions = list(_REASONING_EFFORT_VALUES)
        elif head == "summary" and trailing_space:
            suggestions = list(_REASONING_SUMMARY_VALUES)
        elif trailing_space:
            suggestions = []
        else:
            suggestions = [h for h in head_options if h.startswith(head)]
    elif len(args) == _REASONING_PAIR_LEN:
        if trailing_space:
            return []
        head = args[0].lower()
        val_prefix = args[1].lower()
        if head == "effort":
            suggestions = [
                v for v in _REASONING_EFFORT_VALUES if v.startswith(val_prefix)
            ]
        elif head == "summary":
            suggestions = [
                v for v in _REASONING_SUMMARY_VALUES if v.startswith(val_prefix)
            ]
    return ordered(suggestions)


_COMPLETERS: Mapping[str, CompleterFn] = {
    "key": _complete_key,
    "verbosity": _complete_verbosity,
    "reasoning": _complete_reasoning,
}


def complete_config(rest: str, _state: SessionState | None = None) -> list[str]:
    """Return completion suggestions for '/config'."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    head = _complete_config_head(parts, trailing_space=trailing_space)
    if head is not None:
        return head
    sub = parts[0].lower()
    completer = _COMPLETERS.get(sub)
    if completer is None:
        return []
    return completer(parts[1:], trailing_space=trailing_space)


__all__ = ("complete_config", "parse_config")
