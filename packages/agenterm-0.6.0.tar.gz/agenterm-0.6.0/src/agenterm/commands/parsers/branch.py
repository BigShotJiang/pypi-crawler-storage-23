"""Parser for consolidated /branch command."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import TYPE_CHECKING, Protocol

from agenterm.commands.model import (
    BranchDeleteCmd,
    BranchForkCmd,
    BranchListCmd,
    BranchNewCmd,
    BranchRunsCmd,
    BranchUseCmd,
    Command,
)
from agenterm.commands.parsers.base import ordered

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


_BRANCH_SUBCOMMANDS: tuple[str, ...] = (
    "list",
    "use",
    "new",
    "fork",
    "delete",
    "runs",
)
_BRANCH_HEAD_CANDIDATES: tuple[str, ...] = (
    "list",
    "use ",
    "new ",
    "fork ",
    "delete ",
    "runs ",
)
_RUN_SUGGESTIONS: tuple[str, ...] = ("10", "20", "50")
_BRANCH_ID_SUGGESTION_LIMIT = 10
_BASE_10 = 10
_MAX_OPTIONAL_ARGS = 2
ParserFn = Callable[[list[str]], Command | None]


class CompleterFn(Protocol):
    def __call__(
        self,
        args: list[str],
        *,
        trailing_space: bool = False,
        state: SessionState | None = None,
    ) -> list[str]: ...


def parse_branch(args: list[str]) -> Command | None:
    """Parse '/branch' commands with subcommand dispatch."""
    if not args:
        return None
    sub = args[0].lower()
    rest = args[1:]
    parser = _BRANCH_PARSERS.get(sub)
    if parser is None:
        return None
    return parser(rest)


def _parse_list(args: list[str]) -> Command | None:
    if args:
        return None
    return BranchListCmd()


def _parse_use(args: list[str]) -> Command | None:
    if len(args) != 1:
        return None
    return BranchUseCmd(branch_id=args[0])


def _parse_new(args: list[str]) -> Command | None:
    if not args:
        return BranchNewCmd()
    if len(args) == 1:
        return BranchNewCmd(branch_id=args[0])
    return None


def _parse_fork(args: list[str]) -> Command | None:
    if not args:
        return None
    if len(args) > _MAX_OPTIONAL_ARGS:
        return None
    try:
        run_number = int(args[0], _BASE_10)
    except ValueError:
        return None
    branch_id = args[1] if len(args) == _MAX_OPTIONAL_ARGS else None
    return BranchForkCmd(run_number=run_number, branch_id=branch_id)


def _parse_delete(args: list[str]) -> Command | None:
    if not args:
        return None
    if len(args) > _MAX_OPTIONAL_ARGS:
        return None
    branch_id = args[0]
    force = False
    if len(args) == _MAX_OPTIONAL_ARGS:
        flag = args[1].lower()
        if flag in ("force", "--force", "-f"):
            force = True
        else:
            return None
    return BranchDeleteCmd(branch_id=branch_id, force=force)


def _parse_runs(args: list[str]) -> Command | None:
    if not args:
        return BranchRunsCmd()
    if len(args) == 1:
        try:
            n = int(args[0], _BASE_10)
        except ValueError:
            return BranchRunsCmd(branch_id=args[0])
        return BranchRunsCmd(limit=n)
    if len(args) == _MAX_OPTIONAL_ARGS:
        try:
            n = int(args[0], _BASE_10)
        except ValueError:
            return None
        return BranchRunsCmd(limit=n, branch_id=args[1])
    return None


def _load_branch_ids(state: SessionState | None) -> list[str]:
    if state is None:
        return []
    return list(state.caches.branch_ids or ())


_BRANCH_PARSERS: Mapping[str, ParserFn] = {
    "list": _parse_list,
    "use": _parse_use,
    "new": _parse_new,
    "fork": _parse_fork,
    "delete": _parse_delete,
    "runs": _parse_runs,
}


def _complete_branch_head(
    parts: list[str],
    *,
    trailing_space: bool = False,
    state: SessionState | None = None,
) -> list[str] | None:
    _ = state
    if not parts:
        return ordered(_BRANCH_HEAD_CANDIDATES)
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([c for c in _BRANCH_HEAD_CANDIDATES if c.startswith(prefix)])
    return None


def _complete_use(
    args: list[str],
    *,
    trailing_space: bool = False,
    state: SessionState | None = None,
) -> list[str]:
    if not args:
        return (
            ordered(_load_branch_ids(state)[:_BRANCH_ID_SUGGESTION_LIMIT])
            if trailing_space
            else []
        )
    if len(args) == 1:
        if trailing_space:
            return []
        prefix = args[0]
        ids = _load_branch_ids(state)
        return ordered([i for i in ids if i.startswith(prefix)])
    return []


def _complete_delete(
    args: list[str],
    *,
    trailing_space: bool = False,
    state: SessionState | None = None,
) -> list[str]:
    if not args:
        return (
            ordered(_load_branch_ids(state)[:_BRANCH_ID_SUGGESTION_LIMIT])
            if trailing_space
            else []
        )
    if len(args) == 1:
        if trailing_space:
            opts = ("--force", "-f", "force")
            return ordered(list(opts))
        prefix = args[0]
        ids = _load_branch_ids(state)
        return ordered([i for i in ids if i.startswith(prefix)])
    if len(args) == _MAX_OPTIONAL_ARGS and not trailing_space:
        prefix = args[1].lower()
        opts = ("--force", "-f", "force")
        return ordered([o for o in opts if o.startswith(prefix)])
    return []


def _complete_runs(
    args: list[str],
    *,
    trailing_space: bool = False,
    state: SessionState | None = None,
) -> list[str]:
    candidates: list[str] = []
    if not args:
        candidates = list(_RUN_SUGGESTIONS)
    elif len(args) == 1:
        prefix = args[0]
        if trailing_space:
            if prefix.isdigit():
                candidates = _load_branch_ids(state)[:_BRANCH_ID_SUGGESTION_LIMIT]
        elif prefix.isdigit():
            candidates = [v for v in _RUN_SUGGESTIONS if v.startswith(prefix)]
        else:
            ids = _load_branch_ids(state)
            candidates = [i for i in ids if i.startswith(prefix)]
    elif len(args) == _MAX_OPTIONAL_ARGS and not trailing_space:
        prefix = args[1]
        ids = _load_branch_ids(state)
        candidates = [i for i in ids if i.startswith(prefix)]
    return ordered(candidates)


def _complete_noop(
    args: list[str],
    *,
    trailing_space: bool = False,
    state: SessionState | None = None,
) -> list[str]:
    _ = args
    _ = trailing_space
    _ = state
    return []


_BRANCH_COMPLETERS: Mapping[str, CompleterFn] = {
    "list": _complete_noop,
    "use": _complete_use,
    "new": _complete_noop,
    "fork": _complete_noop,
    "delete": _complete_delete,
    "runs": _complete_runs,
}


def complete_branch(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion suggestions for '/branch'."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    head = _complete_branch_head(parts, trailing_space=trailing_space)
    if head is not None:
        return head
    sub = parts[0].lower()
    completer = _BRANCH_COMPLETERS.get(sub)
    if completer is None:
        return []
    return completer(
        parts[1:],
        trailing_space=trailing_space,
        state=state,
    )


__all__ = ("complete_branch", "parse_branch")
