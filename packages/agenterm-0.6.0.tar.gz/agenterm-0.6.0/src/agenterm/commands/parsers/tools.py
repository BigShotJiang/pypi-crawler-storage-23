"""Parser and completer for '/tools' commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.model import (
    Command,
    ToolsAddBundleCmd,
    ToolsAddToolCmd,
    ToolsListCmd,
    ToolsRemoveBundleCmd,
    ToolsRemoveToolCmd,
    ToolsResetCmd,
    ToolsToggleCmd,
)
from agenterm.commands.parsers.base import ordered

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agenterm.core.types import SessionState


_MIN_TOKENS_FOR_KIND = 2  # kind + at least one item
_TOOLS_HEADS: tuple[str, ...] = ("on", "off", "add ", "remove ", "reset")
_TOOLS_NOARG_HEADS: frozenset[str] = frozenset({"on", "off", "reset"})
_TOOLS_MUTATING_HEADS: frozenset[str] = frozenset({"add", "remove"})
_TOOLS_KIND_SUGGESTIONS: tuple[str, ...] = ("bundle ", "tool ")
_TOOLS_KINDS: frozenset[str] = frozenset({"bundle", "tool"})


def _complete_heads(prefix: str) -> list[str]:
    return ordered([h for h in _TOOLS_HEADS if h.startswith(prefix)])


def _complete_kinds(prefix: str) -> list[str]:
    return ordered([k for k in _TOOLS_KIND_SUGGESTIONS if k.startswith(prefix)])


def _split_values(
    values: list[str],
    *,
    trailing_space: bool,
) -> tuple[list[str], str]:
    if not values:
        return [], ""
    if trailing_space:
        return values, ""
    return values[:-1], values[-1]


def _available_names(kind: str, state: SessionState) -> list[str]:
    bundles_map = state.tools.bundles_map or {}
    tools_map = state.tools.tools_map or {}
    return sorted(bundles_map.keys()) if kind == "bundle" else sorted(tools_map.keys())


def _complete_kind_values(
    kind: str,
    values: list[str],
    *,
    trailing_space: bool,
    state: SessionState | None,
) -> list[str]:
    if state is None:
        return []
    selected, prefix = _split_values(values, trailing_space=trailing_space)
    selected_lower = {s.lower() for s in selected}
    prefix_lower = prefix.lower()
    candidates = [
        f"{name} "
        for name in _available_names(kind, state)
        if name.lower() not in selected_lower
        and (not prefix_lower or name.lower().startswith(prefix_lower))
    ]
    return ordered(candidates)


def _complete_add_remove(
    args: list[str],
    *,
    trailing_space: bool,
    state: SessionState | None,
) -> list[str]:
    if not args:
        return ordered(_TOOLS_KIND_SUGGESTIONS)

    kind_prefix = args[0].lower()
    if len(args) == 1 and not trailing_space:
        return _complete_kinds(kind_prefix)

    kind = kind_prefix
    if kind not in _TOOLS_KINDS:
        return []
    return _complete_kind_values(
        kind,
        args[1:],
        trailing_space=trailing_space,
        state=state,
    )


def _complete_after_head(
    head: str,
    args: list[str],
    *,
    trailing_space: bool,
    state: SessionState | None,
) -> list[str]:
    if head in _TOOLS_NOARG_HEADS:
        return []
    if head not in _TOOLS_MUTATING_HEADS:
        return []
    return _complete_add_remove(args, trailing_space=trailing_space, state=state)


def parse_tools(args: list[str]) -> Command | None:
    """Parse '/tools' subcommands (on|off|reset|add|remove).

    Args:
      args: Remaining tokens after the head.

    Returns:
      ToolsListCmd on no args, otherwise the parsed Command or None.

    """
    if not args:
        return ToolsListCmd()
    sub = args[0].lower()
    rest = args[1:]

    def _noargs_factory(cmd: Command) -> Callable[[list[str]], Command | None]:
        return lambda r: cmd if not r else None

    def _add_or_remove(r: list[str], *, add: bool) -> Command | None:
        if len(r) < _MIN_TOKENS_FOR_KIND:
            return None
        kind = r[0].lower()
        items = r[1:]
        if kind == "bundle":
            return (
                ToolsAddBundleCmd(names=items)
                if add
                else ToolsRemoveBundleCmd(names=items)
            )
        if kind == "tool":
            return (
                ToolsAddToolCmd(keys=items) if add else ToolsRemoveToolCmd(keys=items)
            )
        return None

    table: Mapping[str, Callable[[list[str]], Command | None]] = {
        "on": _noargs_factory(ToolsToggleCmd(on=True)),
        "off": _noargs_factory(ToolsToggleCmd(on=False)),
        "reset": _noargs_factory(ToolsResetCmd()),
        "add": lambda r: _add_or_remove(r, add=True),
        "remove": lambda r: _add_or_remove(r, add=False),
    }
    fn = table.get(sub)
    return fn(rest) if fn else None


def complete_tools(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion suggestions for '/tools'.

    Args:
      rest: Unparsed remainder of the line after the head.
      state: Current SessionState (used to surface available bundles/tools).

    Returns:
      A list of completion strings, possibly empty.

    """
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    if not parts:
        return ordered(_TOOLS_HEADS)

    head_prefix = parts[0].lower()
    if len(parts) == 1 and not trailing_space:
        return _complete_heads(head_prefix)

    return _complete_after_head(
        head_prefix,
        parts[1:],
        trailing_space=trailing_space,
        state=state,
    )
