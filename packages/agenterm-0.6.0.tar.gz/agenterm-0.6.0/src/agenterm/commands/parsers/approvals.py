"""Parser and completer for /approvals commands."""

from __future__ import annotations

from typing import TYPE_CHECKING, Final

from agenterm.commands.model import (
    ApprovalsApproveCmd,
    ApprovalsDetailCmd,
    ApprovalsListCmd,
    ApprovalsModeCmd,
    ApprovalsRejectCmd,
    ApprovalsShowCmd,
    Command,
)
from agenterm.commands.parsers.base import ordered
from agenterm.core.choices.approvals import parse_approval_mode

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


_APPROVALS_ID_ARGS: Final = 2


def parse_approvals(args: list[str]) -> Command | None:
    """Parse '/approvals' commands.

    Supported forms:
    - /approvals              -> ApprovalsShowCmd (show current mode)
    - /approvals auto         -> ApprovalsModeCmd(mode="auto")
    - /approvals prompt       -> ApprovalsModeCmd(mode="prompt")
    - /approvals list         -> ApprovalsListCmd
    - /approvals show <id>    -> ApprovalsDetailCmd(id=...)
    - /approvals approve <id> -> ApprovalsApproveCmd(id=...)
    - /approvals reject <id> [reason...] -> ApprovalsRejectCmd(id=..., reason=...)
    """
    cmd: Command | None = None
    if not args:
        cmd = ApprovalsShowCmd()
    else:
        head = args[0].lower()
        if len(args) == 1:
            mode = parse_approval_mode(head)
            if mode:
                cmd = ApprovalsModeCmd(mode=mode)
            elif head == "list":
                cmd = ApprovalsListCmd()
        elif len(args) == _APPROVALS_ID_ARGS:
            ident = args[1]
            if head == "show":
                cmd = ApprovalsDetailCmd(id=ident)
            elif head == "approve":
                cmd = ApprovalsApproveCmd(id=ident)
            elif head == "reject":
                cmd = ApprovalsRejectCmd(id=ident, reason=None)
        elif head == "reject":
            ident = args[1]
            reason = " ".join(args[2:]).strip()
            cmd = ApprovalsRejectCmd(id=ident, reason=reason or None)
    return cmd


def complete_approvals(rest: str, _state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /approvals subcommands."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    opts = ["auto", "prompt", "list", "show ", "approve ", "reject "]

    def _pending_ids(prefix: str) -> list[str]:
        if _state is None:
            return []
        pending_ids = [
            *[i.id for i in _state.approvals.compress.pending()],
            *[i.id for i in _state.approvals.shell.pending()],
            *[i.id for i in _state.approvals.patch.pending()],
            *[i.id for i in _state.approvals.mcp.pending()],
        ]
        return ordered([i for i in pending_ids if i.startswith(prefix)])

    if not parts:
        return ordered(opts)

    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([o for o in opts if o.startswith(prefix)])

    sub = parts[0].lower()
    if sub not in {"show", "approve", "reject"}:
        return []

    if len(parts) == 1 and trailing_space:
        return _pending_ids("")

    if len(parts) == _APPROVALS_ID_ARGS and not trailing_space:
        return _pending_ids(parts[1])
    return []
