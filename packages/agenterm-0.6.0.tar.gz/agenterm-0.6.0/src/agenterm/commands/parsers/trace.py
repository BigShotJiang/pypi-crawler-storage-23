"""Parser for /trace commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.model import TraceClearCmd, TraceEnabledCmd, TraceShowCmd
from agenterm.commands.parsers.base import ordered

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


def parse_trace(
    args: list[str],
) -> TraceShowCmd | TraceClearCmd | TraceEnabledCmd | None:
    """Parse '/trace [show|clear|on|off]'."""
    if not args:
        return TraceShowCmd()
    if len(args) != 1:
        return None
    head = args[0].lower()
    mapping: dict[str, TraceShowCmd | TraceClearCmd | TraceEnabledCmd] = {
        "show": TraceShowCmd(),
        "clear": TraceClearCmd(),
        "on": TraceEnabledCmd(enabled=True),
        "off": TraceEnabledCmd(enabled=False),
    }
    return mapping.get(head)


def complete_trace(rest: str, _state: SessionState | None = None) -> list[str]:
    """Return completion candidates for `/trace`."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    choices = ["show", "clear", "on", "off"]
    if not parts:
        return ordered(choices)
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([v for v in choices if v.startswith(prefix)])
    return []


__all__ = ("complete_trace", "parse_trace")
