"""Parser and completer for /repl commands (prompt UI controls)."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final

from agenterm.commands.model import (
    Command,
    ReplColorDepthCmd,
    ReplCompletionCmd,
    ReplEditingModeCmd,
    ReplMouseCmd,
    ReplShowCmd,
    ReplThemeCmd,
)
from agenterm.commands.parsers.base import ordered
from agenterm.core.choices.repl_ui import (
    REPL_COLOR_DEPTHS,
    REPL_COMPLETION_MODES,
    REPL_EDITING_MODES,
    REPL_THEMES,
)

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


_REPL_HEADS: tuple[str, ...] = (
    "theme",
    "color-depth",
    "mouse",
    "completion",
    "edit-mode",
)

_REPL_VALUES_BY_HEAD = MappingProxyType(
    {
        "theme": REPL_THEMES,
        "color-depth": REPL_COLOR_DEPTHS,
        "mouse": ("on", "off"),
        "completion": REPL_COMPLETION_MODES,
        "edit-mode": REPL_EDITING_MODES,
    },
)

_REPL_PAIR_LEN: Final = 2
_REPL_PAIR_COMMANDS = MappingProxyType(
    {
        **{("theme", t): ReplThemeCmd(theme=t) for t in REPL_THEMES},
        **{("color-depth", d): ReplColorDepthCmd(depth=d) for d in REPL_COLOR_DEPTHS},
        ("mouse", "on"): ReplMouseCmd(on=True),
        ("mouse", "off"): ReplMouseCmd(on=False),
        **{("completion", m): ReplCompletionCmd(mode=m) for m in REPL_COMPLETION_MODES},
        **{
            ("edit-mode", mode): ReplEditingModeCmd(mode=mode)
            for mode in REPL_EDITING_MODES
        },
    },
)


def parse_repl(args: list[str]) -> Command | None:
    """Parse '/repl' commands.

    Supported forms:
    - /repl                                     -> ReplShowCmd
    - /repl theme dark|light                     -> ReplThemeCmd
    - /repl color-depth auto|mono|ansi|default|truecolor -> ReplColorDepthCmd
    - /repl mouse on|off                         -> ReplMouseCmd
    - /repl completion off|commands|full         -> ReplCompletionCmd
    - /repl edit-mode emacs|vi                   -> ReplEditingModeCmd
    """
    result: Command | None = None
    if not args:
        result = ReplShowCmd()
    elif len(args) == _REPL_PAIR_LEN:
        head = args[0].lower()
        tail = args[1]
        result = _REPL_PAIR_COMMANDS.get((head, tail.lower()))
    return result


def complete_repl(rest: str, _state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /repl subcommands."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")

    if not parts:
        return ordered([f"{h} " for h in _REPL_HEADS])

    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([f"{h} " for h in _REPL_HEADS if h.startswith(prefix)])

    head = parts[0].lower()
    values = _REPL_VALUES_BY_HEAD.get(head)
    if values is None:
        return []
    if len(parts) == 1 and trailing_space:
        return ordered(list(values))
    if len(parts) == _REPL_PAIR_LEN and not trailing_space:
        val_prefix = parts[1].lower()
        return ordered([v for v in values if v.startswith(val_prefix)])
    return []


__all__ = ("complete_repl", "parse_repl")
