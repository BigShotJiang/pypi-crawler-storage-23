"""Parser for consolidated /session command."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import TYPE_CHECKING, Protocol

from agenterm.commands.model import (
    Command,
    NewSessionCmd,
    SessionRunsCmd,
    SessionsListCmd,
    SessionsUseCmd,
)
from agenterm.commands.parsers.base import ordered

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


_SESSION_SUBCOMMANDS: tuple[str, ...] = ("new", "list", "use", "runs")
_SESSION_HEAD_CANDIDATES: tuple[str, ...] = ("new", "list", "use ", "runs ")
_RUNS_SUGGESTIONS: tuple[str, ...] = ("10", "20", "50")
_SESSION_ID_SUGGESTION_LIMIT = 10
ParserFn = Callable[[list[str]], Command | None]


class CompleterFn(Protocol):
    def __call__(
        self,
        args: list[str],
        *,
        trailing_space: bool = False,
    ) -> list[str]: ...


def parse_session(args: list[str]) -> Command | None:
    """Parse '/session' commands with subcommand dispatch.

    Supported forms:
    - /session new          Start fresh session
    - /session list         List stored sessions
    - /session use <ID>     Attach to existing session
    - /session runs [N]     Show recent runs
    """
    if not args:
        return None
    sub = args[0].lower()
    rest = args[1:]

    parser = _SESSION_PARSERS.get(sub)
    if parser is None:
        return None
    return parser(rest)


def _parse_use(args: list[str]) -> Command | None:
    """Parse 'use <SESSION_ID>'."""
    if len(args) != 1:
        return None
    return SessionsUseCmd(session_id=args[0])


def _parse_runs(args: list[str]) -> Command | None:
    """Parse 'runs [N]'."""
    if not args:
        return SessionRunsCmd(limit=10)
    if len(args) != 1:
        return None
    try:
        n = int(args[0], 10)
    except ValueError:
        return None
    return SessionRunsCmd(limit=n)


def _load_session_ids(state: SessionState | None) -> list[str]:
    """Return cached session ids (refresh via /session list)."""
    if state is None:
        return []
    return list(state.caches.session_ids or ())


_SESSION_PARSERS: Mapping[str, ParserFn] = {
    "new": lambda rest: NewSessionCmd() if not rest else None,
    "list": lambda rest: SessionsListCmd() if not rest else None,
    "use": _parse_use,
    "runs": _parse_runs,
}


def _complete_session_head(
    parts: list[str],
    *,
    trailing_space: bool,
) -> list[str] | None:
    if not parts:
        return ordered(_SESSION_HEAD_CANDIDATES)
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([c for c in _SESSION_HEAD_CANDIDATES if c.startswith(prefix)])
    return None


def _complete_use(
    args: list[str],
    *,
    trailing_space: bool = False,
    state: SessionState | None = None,
) -> list[str]:
    if not args:
        return (
            ordered(_load_session_ids(state)[:_SESSION_ID_SUGGESTION_LIMIT])
            if trailing_space
            else []
        )
    if len(args) == 1:
        if trailing_space:
            return []
        prefix = args[0]
        ids = _load_session_ids(state)
        return ordered([i for i in ids if i.startswith(prefix)])
    return []


def _complete_runs(
    args: list[str],
    *,
    trailing_space: bool = False,
) -> list[str]:
    _ = trailing_space
    if not args:
        return ordered(_RUNS_SUGGESTIONS)
    if len(args) == 1:
        if trailing_space:
            return []
        prefix = args[0]
        return ordered([v for v in _RUNS_SUGGESTIONS if v.startswith(prefix)])
    return []


def _complete_noop(
    args: list[str],
    *,
    trailing_space: bool = False,
) -> list[str]:
    _ = trailing_space
    _ = args
    return []


_SESSION_COMPLETERS: Mapping[str, CompleterFn] = {
    "new": _complete_noop,
    "list": _complete_noop,
    "use": _complete_use,
    "runs": _complete_runs,
}


def complete_session(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion suggestions for '/session'."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    head = _complete_session_head(parts, trailing_space=trailing_space)
    if head is not None:
        return head
    sub = parts[0].lower()
    completer = _SESSION_COMPLETERS.get(sub)
    if completer is None:
        return []
    if sub == "use":
        return _complete_use(
            parts[1:],
            trailing_space=trailing_space,
            state=state,
        )
    return completer(parts[1:], trailing_space=trailing_space)


__all__ = ("complete_session", "parse_session")
