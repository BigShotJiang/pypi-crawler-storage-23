"""Shared parser utilities and no-arg command helpers for the REPL."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from types import MappingProxyType
from typing import TYPE_CHECKING

from agenterm.commands.model import (
    AgainCmd,
    Command,
    ContinueCmd,
    EditCmd,
    ErrorsCmd,
    HelpCmd,
    QuitCmd,
    StatusCmd,
)

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


# Types for parsers and completions used across submodules
Parser = Callable[[list[str]], Command | None]
Completer = Callable[[str, "SessionState | None"], list[str]]


def parse_noargs_factory(ctor: Callable[[], Command]) -> Parser:
    """Return a parser that accepts no args and emits HelpCmd on extras."""

    def _p(args: list[str]) -> Command | None:
        return ctor() if not args else HelpCmd()

    return _p


def parse_help(args: list[str]) -> Command | None:
    """Parse '/help [topic]' into HelpCmd.

    Args:
      args: Remaining tokens after the head.

    Returns:
      HelpCmd with topic=None for overview, or topic set for specific help.

    """
    if not args:
        return HelpCmd(topic=None)
    if len(args) == 1:
        return HelpCmd(topic=args[0].lower().lstrip("/"))
    return HelpCmd(topic=None)  # Too many args, show overview


def ordered(cands: Iterable[str]) -> list[str]:
    """Return candidates ordered lexicographically, terms first, then non-terms.

    Args:
      cands: Completion candidates; those ending with space are considered non-terms.

    Returns:
      Sorted list with terms before non-terms.

    """
    # Completion UX contract: never emit duplicates into the completion panel.
    seen: set[str] = set()

    def _dedupe(items: Iterable[str]) -> list[str]:
        out: list[str] = []
        for item in items:
            if item in seen:
                continue
            seen.add(item)
            out.append(item)
        return out

    terms = _dedupe(c for c in cands if not c.endswith(" "))
    nonterms = _dedupe(c for c in cands if c.endswith(" "))

    def _key(s: str) -> str:
        return s.strip().lower()

    return [*sorted(terms, key=_key), *sorted(nonterms, key=_key)]


# Common no-arg command parsers used by registry wiring
NOARG_PARSERS: Mapping[str, Parser] = MappingProxyType(
    {
        "/quit": parse_noargs_factory(QuitCmd),
        "/again": parse_noargs_factory(AgainCmd),
        "/continue": parse_noargs_factory(ContinueCmd),
        "/edit": parse_noargs_factory(EditCmd),
        "/status": parse_noargs_factory(StatusCmd),
        "/errors": parse_noargs_factory(ErrorsCmd),
    },
)
