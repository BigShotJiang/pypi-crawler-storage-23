"""Shared helpers for branch CLI commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.paths import history_db_path
from agenterm.core.cli_payloads import BranchMetaPayload, BranchSummaryPayload
from agenterm.core.error_report import ErrorContext
from agenterm.core.errors import ConfigError, DatabaseError
from agenterm.store.branch.repo import get_branch_meta
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.service import get_session_metadata_row, session_store

if TYPE_CHECKING:
    from agenterm.store.branch.models import BranchMeta
    from agenterm.store.branch.summary import BranchSummary
    from agenterm.store.session.last_message import LastMessageSnippet


def branch_error_context(operation: str) -> ErrorContext:
    """Return a standard branch error context."""
    return ErrorContext(operation=operation, resource=operation, trace_id=None)


def build_branch_meta_payload(meta: BranchMeta) -> BranchMetaPayload:
    """Convert BranchMeta into a CLI payload."""
    return BranchMetaPayload(
        branch_id=meta.branch_id,
        kind=meta.kind,
        title=meta.title,
        pinned=meta.pinned,
        created_reason=meta.created_reason,
        parent_branch_id=meta.parent_branch_id,
        fork_run_number=meta.fork_run_number,
        agent_name=meta.agent_name,
        agent_path=meta.agent_path,
        agent_sha256=meta.agent_sha256,
        store_enabled=meta.store_enabled,
        last_response_id=meta.last_response_id,
    )


def build_branch_summary_payload(
    summary: BranchSummary,
    meta: BranchMeta | None,
    last_message: LastMessageSnippet | None = None,
) -> BranchSummaryPayload:
    """Build a summary payload for branch list entries."""
    meta_payload = build_branch_meta_payload(meta) if meta is not None else None
    return BranchSummaryPayload(
        branch_id=summary.branch_id,
        message_count=summary.message_count,
        user_turns=summary.user_turns,
        is_current=summary.is_current,
        created_at=summary.created_at,
        last_message_role=last_message.role if last_message is not None else None,
        last_message_snippet=last_message.snippet if last_message is not None else None,
        meta=meta_payload,
    )


async def load_session_head(
    session_id: str,
) -> tuple[str, BranchMetaPayload]:
    """Load the head branch metadata for a session."""
    store = session_store()
    meta = await get_session_metadata_row(store, session_id)
    if meta is None:
        msg = f"Session not found: {session_id}"
        raise ConfigError(msg)
    head = await get_branch_meta(store, session_id, meta.head_branch_id)
    if head is None:
        msg = f"Missing head branch metadata for session {session_id!r}"
        raise DatabaseError(msg)
    return meta.head_branch_id, build_branch_meta_payload(head)


async def open_session(
    session_id: str,
    *,
    head_branch_id: str,
) -> AgentermSQLiteSession:
    """Open an AdvancedSQLiteSession and switch to the requested branch."""
    session = AgentermSQLiteSession(
        session_id=session_id,
        db_path=str(history_db_path()),
        create_tables=True,
    )
    if head_branch_id != "main":
        await session.switch_to_branch(head_branch_id)
    return session


__all__ = (
    "branch_error_context",
    "build_branch_meta_payload",
    "build_branch_summary_payload",
    "load_session_head",
    "open_session",
)
