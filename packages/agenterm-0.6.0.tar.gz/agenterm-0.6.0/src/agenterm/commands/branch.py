"""Branch CLI commands."""

from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path
from typing import TYPE_CHECKING, Annotated

import typer

from agenterm.cli.options import BranchOption, FormatOption
from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output import emit_result as emit_cli_result
from agenterm.cli.output_format import OutputFormat
from agenterm.commands.branch_helpers import (
    branch_error_context,
    build_branch_meta_payload,
    build_branch_summary_payload,
    load_session_head,
    open_session,
)
from agenterm.commands.session_runs_view import build_session_runs_payload
from agenterm.core.cli_payloads import (
    BranchDeletePayload,
    BranchListPayload,
    BranchUsePayload,
)
from agenterm.core.error_report import build_error_report, build_message_report
from agenterm.core.errors import (
    ConfigError,
    DatabaseError,
    FilesystemError,
    ValidationError,
)
from agenterm.core.json_codec import require_json_object
from agenterm.store.branch.repo import list_branch_meta
from agenterm.store.branch.service import (
    create_branch_from_head,
    create_branch_from_run,
    delete_branch,
    switch_branch,
)
from agenterm.store.branch.summary import parse_branch_summary
from agenterm.store.history import history_store
from agenterm.store.session.service import (
    get_session_metadata_row,
    last_message_snippets_by_branch,
    session_store,
)

if TYPE_CHECKING:
    from agenterm.store.branch.summary import BranchSummary

_DEFAULT_BOOL = False

branch_app = typer.Typer(
    name="branch",
    help="View and manage session branches.",
    no_args_is_help=True,
    epilog=(
        "Commands:\n"
        "  list    List branches\n"
        "  use     Switch head branch\n"
        "  new     Create a branch from head\n"
        "  fork    Create a branch from a run\n"
        "  delete  Remove a branch\n"
        "  runs    View run history for a branch\n"
    ),
)


@branch_app.command("list")
def list_branches(
    session_id: str,
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """List branches for a session."""
    store = session_store()
    history = history_store()

    async def _load() -> BranchListPayload:
        meta = await get_session_metadata_row(store, session_id)
        if meta is None:
            msg = f"Session not found: {session_id}"
            raise ConfigError(msg)
        session = await open_session(
            session_id,
            head_branch_id=meta.head_branch_id,
        )
        branches = await session.list_branches()
        meta_rows = await list_branch_meta(store, session_id)
        meta_map = {row.branch_id: row for row in meta_rows}
        summaries: list[BranchSummary] = []
        for branch in branches:
            branch_json = require_json_object(
                value=branch,
                context="branch.list.entry",
            )
            summaries.append(parse_branch_summary(branch_json))
        snippets = await last_message_snippets_by_branch(
            store=history,
            session_id=session_id,
            branch_ids=[summary.branch_id for summary in summaries],
        )
        payloads = [
            build_branch_summary_payload(
                summary,
                meta_map.get(summary.branch_id),
                snippets.get(summary.branch_id),
            )
            for summary in summaries
        ]
        return BranchListPayload(
            session_id=session_id,
            head_branch_id=meta.head_branch_id,
            branches=tuple(payloads),
        )

    try:
        payload = asyncio.run(_load())
    except ConfigError as exc:
        report = build_message_report(
            kind="not_found",
            message=str(exc),
            context=branch_error_context("branch.list"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except (FilesystemError, DatabaseError, ValidationError) as exc:
        report = build_error_report(exc, context=branch_error_context("branch.list"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=branch_error_context("branch.list"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc

    emit_cli_result(
        output_format=output_format,
        resource="branch.list",
        payload=payload,
        trace_id=None,
    )


@branch_app.command("use")
def use_branch(
    session_id: str,
    branch_id: str,
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Switch the head branch for a session."""
    store = session_store()

    async def _switch() -> BranchUsePayload:
        head_branch_id, _ = await load_session_head(session_id)
        session = await open_session(
            session_id,
            head_branch_id=head_branch_id,
        )
        meta = await switch_branch(
            session=session,
            store=store,
            session_id=session_id,
            branch_id=branch_id,
        )
        branch_payload = build_branch_meta_payload(meta)
        return BranchUsePayload(
            session_id=session_id,
            branch_id=branch_payload.branch_id,
            head_branch_id=branch_payload.branch_id,
            branch=branch_payload,
        )

    try:
        payload = asyncio.run(_switch())
    except ConfigError as exc:
        report = build_message_report(
            kind="usage_error",
            message=str(exc),
            context=branch_error_context("branch.use"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=branch_error_context("branch.use"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=branch_error_context("branch.use"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc

    emit_cli_result(
        output_format=output_format,
        resource="branch.use",
        payload=payload,
        trace_id=None,
    )


@branch_app.command("new")
def new_branch(
    session_id: str,
    *,
    name: Annotated[
        str | None,
        typer.Option("--name", "-n", help="New branch id"),
    ] = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Create a new branch from the head."""
    store = session_store()

    async def _create() -> BranchUsePayload:
        head_branch_id, head_payload = await load_session_head(session_id)
        session = await open_session(
            session_id,
            head_branch_id=head_branch_id,
        )
        meta = await create_branch_from_head(
            session=session,
            store=store,
            session_id=session_id,
            branch_id=name,
            kind="fork",
            created_reason="user_branch",
            agent_name=head_payload.agent_name,
            agent_path=(
                Path(head_payload.agent_path)
                if head_payload.agent_path is not None
                else None
            ),
            agent_sha256=head_payload.agent_sha256,
        )
        branch_payload = build_branch_meta_payload(meta)
        return BranchUsePayload(
            session_id=session_id,
            branch_id=branch_payload.branch_id,
            head_branch_id=branch_payload.branch_id,
            branch=branch_payload,
        )

    try:
        payload = asyncio.run(_create())
    except ConfigError as exc:
        report = build_message_report(
            kind="usage_error",
            message=str(exc),
            context=branch_error_context("branch.new"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=branch_error_context("branch.new"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=branch_error_context("branch.new"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc

    emit_cli_result(
        output_format=output_format,
        resource="branch.new",
        payload=payload,
        trace_id=None,
    )


@branch_app.command("fork")
def fork_branch(
    session_id: str,
    run_number: int,
    *,
    name: Annotated[
        str | None,
        typer.Option("--name", "-n", help="New branch id"),
    ] = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Create a new branch from a run (exclusive)."""
    store = session_store()

    async def _fork() -> BranchUsePayload:
        head_branch_id, head_payload = await load_session_head(session_id)
        session = await open_session(
            session_id,
            head_branch_id=head_branch_id,
        )
        meta = await create_branch_from_run(
            session=session,
            store=store,
            session_id=session_id,
            run_number=run_number,
            branch_id=name,
            agent_name=head_payload.agent_name,
            agent_path=(
                Path(head_payload.agent_path)
                if head_payload.agent_path is not None
                else None
            ),
            agent_sha256=head_payload.agent_sha256,
        )
        branch_payload = build_branch_meta_payload(meta)
        return BranchUsePayload(
            session_id=session_id,
            branch_id=branch_payload.branch_id,
            head_branch_id=branch_payload.branch_id,
            branch=branch_payload,
        )

    try:
        payload = asyncio.run(_fork())
    except ConfigError as exc:
        report = build_message_report(
            kind="usage_error",
            message=str(exc),
            context=branch_error_context("branch.fork"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=branch_error_context("branch.fork"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=branch_error_context("branch.fork"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc

    emit_cli_result(
        output_format=output_format,
        resource="branch.fork",
        payload=payload,
        trace_id=None,
    )


@branch_app.command("delete")
def remove_branch(
    session_id: str,
    branch_id: str,
    *,
    output_format: FormatOption = OutputFormat.human,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Delete current branch"),
    ] = _DEFAULT_BOOL,
) -> None:
    """Delete a branch from the session."""
    store = session_store()

    async def _delete() -> BranchDeletePayload:
        meta = await get_session_metadata_row(store, session_id)
        if meta is None:
            msg = f"Session not found: {session_id}"
            raise ConfigError(msg)
        session = await open_session(
            session_id,
            head_branch_id=meta.head_branch_id,
        )
        deleted = await delete_branch(
            session=session,
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            force=force,
        )
        updated_meta = await get_session_metadata_row(store, session_id)
        head_branch_id = (
            updated_meta.head_branch_id
            if updated_meta is not None
            else meta.head_branch_id
        )
        return BranchDeletePayload(
            session_id=session_id,
            branch_id=branch_id,
            deleted=deleted,
            head_branch_id=head_branch_id,
        )

    try:
        payload = asyncio.run(_delete())
    except ConfigError as exc:
        report = build_message_report(
            kind="usage_error",
            message=str(exc),
            context=branch_error_context("branch.delete"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=branch_error_context("branch.delete"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=branch_error_context("branch.delete"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc

    emit_cli_result(
        output_format=output_format,
        resource="branch.delete",
        payload=payload,
        trace_id=None,
    )


@branch_app.command("runs")
def show_branch_runs(
    session_id: str,
    *,
    branch: BranchOption = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Show run history for a branch."""
    try:
        payload = asyncio.run(
            build_session_runs_payload(
                session_id,
                branch_id=branch,
            ),
        )
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(
            exc,
            context=branch_error_context("branch.runs"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=branch_error_context("branch.runs"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    if payload is None:
        report = build_message_report(
            kind="not_found",
            message=f"Session not found: {session_id}",
            context=branch_error_context("branch.runs"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1)
    emit_cli_result(
        output_format=output_format,
        resource="branch.runs",
        payload=payload,
        trace_id=None,
    )


__all__ = ("branch_app",)
