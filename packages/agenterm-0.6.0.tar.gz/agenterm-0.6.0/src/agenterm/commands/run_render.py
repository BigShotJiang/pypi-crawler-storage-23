"""Render helpers for `agenterm run`."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.cli.output_format import is_json
from agenterm.config.paths import resolve_config_source
from agenterm.core.error_report import ErrorContext, build_message_report
from agenterm.ui.cli_renderer import render_error_report, render_notice

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from agenterm.cli.output_format import OutputFormat
    from agenterm.commands.run_support import RunModes
    from agenterm.config.model import AppConfig


def emit_usage_error(
    *,
    message: str,
    output_format: OutputFormat,
    emit_error: Callable[..., None],
) -> None:
    """Emit usage error via the canonical run error output channel."""
    report = build_message_report(
        kind="usage_error",
        message=message,
        context=ErrorContext(operation="run", resource="run", trace_id=None),
    )
    emit_error(output_format=output_format, report=report)


def postprocess_emit_line_from_modes(
    modes: RunModes,
    *,
    context: ErrorContext,
) -> Callable[[str], None] | None:
    """Build postprocess emit callback for human-mode run output."""
    if is_json(modes.output_format):
        return None

    def _emit(msg: str) -> None:
        if msg.startswith("warn>"):
            text = msg[len("warn>") :].strip()
            render_notice(title="Warning", message=text, style="warn")
        elif msg.startswith("error>"):
            text = msg[len("error>") :].strip()
            report = build_message_report(
                kind="runtime_error",
                message=text,
                context=context,
            )
            render_error_report(report)

    return _emit


def render_config_source_note(
    *,
    explicit: Path | None,
    resolved: Path | None,
) -> None:
    """Render config-source notice for non-interactive run mode."""
    info = resolve_config_source(explicit=explicit, resolved=resolved)
    if info.location == "default":
        message = "Using defaults (no config.yaml found)."
    elif info.location == "local":
        message = f"Using local config: {info.path}"
    elif info.location == "global":
        message = f"Using global config: {info.path}"
    elif info.location == "explicit":
        message = f"Using explicit config: {info.path}"
    else:
        message = f"Using config: {info.path}"
    render_notice(title="Config", message=message, style="accent", stderr=True)


def render_agent_source_note(*, cfg: AppConfig) -> None:
    """Render agent-source notice for non-interactive run mode."""
    name = cfg.agent.name
    location = cfg.agent.source or "unknown"
    path = cfg.agent.path
    if cfg.agent.explicit:
        if path is not None:
            message = f"Using explicit agent {name}: {path}"
        else:
            message = f"Using explicit agent {name}."
    elif location == "local":
        message = f"Using local agent {name}: {path}"
    elif location == "global":
        message = f"Using global agent {name}: {path}"
    elif location == "bundled":
        message = f"Using bundled agent {name}."
    else:
        message = f"Using agent {name}."
    render_notice(title="Agent", message=message, style="accent", stderr=True)


__all__ = (
    "emit_usage_error",
    "postprocess_emit_line_from_modes",
    "render_agent_source_note",
    "render_config_source_note",
)
