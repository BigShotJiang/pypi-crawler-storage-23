"""Session and branch command models for REPL/CLI surfaces."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class NewSessionCmd:
    """Start a fresh REPL session backed by a new AgentermSQLiteSession."""


@dataclass(frozen=True)
class SessionsListCmd:
    """List known sessions from the local SQLite store in the REPL."""


@dataclass(frozen=True)
class SessionsUseCmd:
    """Attach the REPL to an existing stored session."""

    session_id: str


@dataclass(frozen=True)
class SessionRunsCmd:
    """Show recent runs for the active REPL session."""

    limit: int | None


@dataclass(frozen=True)
class BranchListCmd:
    """List branches for the active session."""


@dataclass(frozen=True)
class BranchUseCmd:
    """Switch to a branch by id."""

    branch_id: str


@dataclass(frozen=True)
class BranchNewCmd:
    """Create a new branch from head."""

    branch_id: str | None = None


@dataclass(frozen=True)
class BranchForkCmd:
    """Create a branch from a run and switch to it."""

    run_number: int
    branch_id: str | None = None


@dataclass(frozen=True)
class BranchDeleteCmd:
    """Delete a branch by id."""

    branch_id: str
    force: bool = False


@dataclass(frozen=True)
class BranchRunsCmd:
    """Show recent runs for a branch."""

    limit: int | None = None
    branch_id: str | None = None
