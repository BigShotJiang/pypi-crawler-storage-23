"""Typed CLI argument containers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.cli.output_format import OutputFormat


@dataclass(frozen=True)
class RunCliArgs:
    """Parsed CLI arguments for `agenterm run`."""

    config: Path | None
    agent_name: str | None
    model: str | None
    format_override: OutputFormat | None
    live: bool | None
    background: bool | None
    no_tools: bool
    tool_select: list[str] | None
    no_retry: bool
    max_retries: int | None
    deadline_seconds: float | None
    attempt_timeout_seconds: float | None
    file: Path | None
    prompts: list[str] | None
    allow_dangerous: bool
    attachments: list[str] | None
    trace_enabled: bool | None
    trace_id: str | None
    trace_group: str | None
    trace_metadata: list[str] | None
    session_id: str | None
    branch_id: str | None
    store_override: bool | None


__all__ = ("RunCliArgs",)
