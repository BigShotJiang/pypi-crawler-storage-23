"""Single source of truth for REPL slash command surface.

This manifest exists to prevent drift between:
- parsing (`/cmd ...` → typed Command),
- tab completion, and
- help/usage text rendered in the REPL.

Handlers live in `agenterm.commands.handlers.*` and are intentionally not referenced
here to avoid importing REPL UI/runtime concerns into parser wiring.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Final, Literal

from agenterm.commands.parsers.approvals import complete_approvals, parse_approvals
from agenterm.commands.parsers.artifacts import complete_artifacts, parse_artifacts
from agenterm.commands.parsers.base import (
    NOARG_PARSERS,
    Completer,
    Parser,
    ordered,
    parse_help,
)
from agenterm.commands.parsers.branch import complete_branch, parse_branch
from agenterm.commands.parsers.config import complete_config, parse_config
from agenterm.commands.parsers.core import (
    complete_agent,
    complete_model,
    parse_agent,
    parse_attach,
    parse_compress,
    parse_model,
)
from agenterm.commands.parsers.inspect import complete_inspect, parse_inspect
from agenterm.commands.parsers.last import complete_last, parse_last
from agenterm.commands.parsers.mcp import complete_mcp, parse_mcp
from agenterm.commands.parsers.repl import complete_repl, parse_repl
from agenterm.commands.parsers.resilience import (
    complete_resilience,
    parse_resilience,
)
from agenterm.commands.parsers.session import complete_session, parse_session
from agenterm.commands.parsers.tools import complete_tools, parse_tools
from agenterm.commands.parsers.trace import complete_trace, parse_trace
from agenterm.commands.parsers.ux import complete_ux, parse_ux

if TYPE_CHECKING:
    from agenterm.core.types import SessionState

type SlashCommandTier = Literal["essential", "advanced"]

_ATTACH_REMOVE_ARG_COUNT: Final[int] = 2


@dataclass(frozen=True)
class SlashCommandSpec:
    """One top-level slash command and its parsing/completion metadata."""

    name: str
    tier: SlashCommandTier
    summary: str
    parser: Parser
    takes_arguments: bool
    usage: str | None = None
    completer: Completer | None = None

    @property
    def topic(self) -> str:
        """Return the topic token used by `/help <topic>`."""
        return self.name.lstrip("/").lower()


def slash_topics(*, include_all: bool) -> list[str]:
    """Return `/help` topics in completion order."""
    topics = [s.topic for s in _SPECS]
    if include_all:
        topics.append("all")
    return topics


def complete_help(rest: str, _state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /help [topic]."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    topics = slash_topics(include_all=True)
    if not parts:
        return ordered(topics)
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lstrip("/").lower()
        return ordered([t for t in topics if t.startswith(prefix)])
    return []


def _complete_attach(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion suggestions for '/attach'."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    subcommands = ("list", "remove", "clear")
    if not parts:
        return ordered([f"{sub} " for sub in subcommands])
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        return ordered([f"{sub} " for sub in subcommands if sub.startswith(prefix)])
    if parts[0].lower() != "remove":
        return []
    opts = ["all"]
    if state is not None and state.attachments.pending:
        opts.extend(list(state.attachments.pending)[:25])
    if len(parts) == 1 and trailing_space:
        return ordered(opts)
    if len(parts) == _ATTACH_REMOVE_ARG_COUNT and not trailing_space:
        prefix = parts[1]
        return ordered([o for o in opts if o.startswith(prefix)])
    return []


_SPECS: tuple[SlashCommandSpec, ...] = (
    SlashCommandSpec(
        name="/help",
        tier="essential",
        summary="Help (try: /help tools; /help all)",
        parser=parse_help,
        takes_arguments=True,
        usage="Usage: /help [topic|all]",
        completer=complete_help,
    ),
    SlashCommandSpec(
        name="/status",
        tier="essential",
        summary="Show session snapshot",
        parser=NOARG_PARSERS["/status"],
        takes_arguments=False,
    ),
    SlashCommandSpec(
        name="/errors",
        tier="advanced",
        summary="Show captured stderr/logging lines",
        parser=NOARG_PARSERS["/errors"],
        takes_arguments=False,
    ),
    SlashCommandSpec(
        name="/model",
        tier="essential",
        summary="Route-first model picker / set model",
        parser=parse_model,
        takes_arguments=True,
        usage=(
            "Usage: /model | /model <openai|openrouter|ollama> | "
            "/model <openai/...|gateway/<route>/<model>|<openai-model>>"
        ),
        completer=complete_model,
    ),
    SlashCommandSpec(
        name="/agent",
        tier="essential",
        summary="Show or switch agent",
        parser=parse_agent,
        takes_arguments=True,
        usage="Usage: /agent [show|list|<NAME>]",
        completer=complete_agent,
    ),
    SlashCommandSpec(
        name="/tools",
        tier="essential",
        summary="Manage tools and bundles",
        parser=parse_tools,
        takes_arguments=True,
        usage=(
            "Usage: /tools | on|off | add bundle NAME... | add tool KEY... | "
            "remove bundle NAME... | remove tool KEY... | reset"
        ),
        completer=complete_tools,
    ),
    SlashCommandSpec(
        name="/approvals",
        tier="essential",
        summary="Approve or reject tool calls",
        parser=parse_approvals,
        takes_arguments=True,
        usage=(
            "Usage: /approvals (show mode) | prompt | auto | list | show <ID> | "
            "approve <ID> | reject <ID> [reason]"
        ),
        completer=complete_approvals,
    ),
    SlashCommandSpec(
        name="/config",
        tier="essential",
        summary="Configure key, verbosity, reasoning",
        parser=parse_config,
        takes_arguments=True,
        usage=("Usage: /config key <KEY> | verbosity [LEVEL] | reasoning [ARGS]"),
        completer=complete_config,
    ),
    SlashCommandSpec(
        name="/repl",
        tier="essential",
        summary="Prompt UI controls",
        parser=parse_repl,
        takes_arguments=True,
        usage=(
            "Usage: /repl (show) | theme dark|light | "
            "color-depth auto|mono|ansi|default|truecolor | "
            "mouse on|off | completion off|commands|full | edit-mode emacs|vi"
        ),
        completer=complete_repl,
    ),
    SlashCommandSpec(
        name="/ux",
        tier="essential",
        summary="REPL UX toggles",
        parser=parse_ux,
        takes_arguments=True,
        usage=(
            "Usage: /ux (show) | markdown on|off | reasoning off|summary | "
            "diffs off|summary | stream final|live | verbosity quiet|normal|debug"
        ),
        completer=complete_ux,
    ),
    SlashCommandSpec(
        name="/session",
        tier="essential",
        summary="Manage sessions",
        parser=parse_session,
        takes_arguments=True,
        usage="Usage: /session list | new | use <ID> | runs [N]",
        completer=complete_session,
    ),
    SlashCommandSpec(
        name="/branch",
        tier="essential",
        summary="Manage branches",
        parser=parse_branch,
        takes_arguments=True,
        usage=(
            "Usage: /branch list | use <ID> | new [ID] | "
            "fork <RUN> [ID] | delete <ID> [--force|-f|force] | runs [N] [ID]"
        ),
        completer=complete_branch,
    ),
    SlashCommandSpec(
        name="/again",
        tier="essential",
        summary="Re-run last prompt",
        parser=NOARG_PARSERS["/again"],
        takes_arguments=False,
    ),
    SlashCommandSpec(
        name="/continue",
        tier="essential",
        summary="Continue after cancellation/timeout",
        parser=NOARG_PARSERS["/continue"],
        takes_arguments=False,
    ),
    SlashCommandSpec(
        name="/edit",
        tier="essential",
        summary="Edit last prompt",
        parser=NOARG_PARSERS["/edit"],
        takes_arguments=False,
    ),
    SlashCommandSpec(
        name="/attach",
        tier="essential",
        summary="Manage attachments",
        parser=parse_attach,
        takes_arguments=True,
        usage=("Usage: /attach <PATH|URL> | list | remove <PATH|URL>|all | clear"),
        completer=_complete_attach,
    ),
    SlashCommandSpec(
        name="/last",
        tier="essential",
        summary="Show last artifacts",
        parser=parse_last,
        takes_arguments=True,
        usage=(
            "Usage: /last diff [preview|full] | /last tools [preview|full] | "
            "/last approvals [preview|full]"
        ),
        completer=complete_last,
    ),
    SlashCommandSpec(
        name="/artifacts",
        tier="advanced",
        summary="Browse artifacts",
        parser=parse_artifacts,
        takes_arguments=True,
        usage=(
            "Usage: /artifacts list [N] | /artifacts show <ID> | "
            "/artifacts open <ID> | /artifacts agent-run <ID>"
        ),
        completer=complete_artifacts,
    ),
    SlashCommandSpec(
        name="/inspect",
        tier="advanced",
        summary="Inspect agent_run reports",
        parser=parse_inspect,
        takes_arguments=True,
        usage="Usage: /inspect agent-run <REPORT_ID> [--json]",
        completer=complete_inspect,
    ),
    SlashCommandSpec(
        name="/compress",
        tier="advanced",
        summary="Snapshot local session history (SDK turns)",
        parser=parse_compress,
        takes_arguments=True,
        usage="Usage: /compress | /compress show",
    ),
    SlashCommandSpec(
        name="/mcp",
        tier="advanced",
        summary="MCP status and refresh",
        parser=parse_mcp,
        takes_arguments=True,
        usage="Usage: /mcp refresh | status",
        completer=complete_mcp,
    ),
    SlashCommandSpec(
        name="/trace",
        tier="advanced",
        summary="Tracing controls",
        parser=parse_trace,
        takes_arguments=True,
        usage="Usage: /trace [show|clear|on|off]",
        completer=complete_trace,
    ),
    SlashCommandSpec(
        name="/resilience",
        tier="advanced",
        summary="Show effective retry policy",
        parser=parse_resilience,
        takes_arguments=True,
        usage="Usage: /resilience [show]",
        completer=complete_resilience,
    ),
    SlashCommandSpec(
        name="/quit",
        tier="essential",
        summary="Exit the REPL",
        parser=NOARG_PARSERS["/quit"],
        takes_arguments=False,
    ),
)

_SPEC_BY_TOPIC: dict[str, SlashCommandSpec] = {s.topic: s for s in _SPECS}


def slash_commands() -> tuple[SlashCommandSpec, ...]:
    """Return all slash command specs in display order."""
    return _SPECS


def find_spec_by_topic(topic: str) -> SlashCommandSpec | None:
    """Return a SlashCommandSpec by `/help` topic token."""
    return _SPEC_BY_TOPIC.get(topic.lower().lstrip("/"))


__all__ = (
    "SlashCommandSpec",
    "SlashCommandTier",
    "complete_help",
    "find_spec_by_topic",
    "slash_commands",
    "slash_topics",
)
