"""MCP handlers: refresh and status commands."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.engine.mcp_diagnostics import McpServerStatus, build_mcp_status_snapshot

if TYPE_CHECKING:
    from agenterm.commands.model import McpRefreshCmd, McpStatusCmd
    from agenterm.core.types import SessionState

_ERROR_PREVIEW_LIMIT = 80
_ELLIPSIS_LEN = 3


def _status_label(row: McpServerStatus) -> str:
    if row.error is not None:
        return "error"
    if row.connected and row.tool_count > 0:
        return "connected"
    if row.connected:
        return "no tools"
    return "disconnected"


def _short_text(text: str | None, *, limit: int = _ERROR_PREVIEW_LIMIT) -> str:
    if not text:
        return "-"
    if len(text) <= limit:
        return text
    if limit <= _ELLIPSIS_LEN:
        return text[:limit]
    return f"{text[: limit - _ELLIPSIS_LEN]}..."


def _format_table(
    headers: list[str],
    rows: list[list[str]],
    *,
    right_align: set[int],
) -> list[str]:
    widths = [len(h) for h in headers]
    for row in rows:
        for idx, val in enumerate(row):
            widths[idx] = max(widths[idx], len(val))

    def _format_row(values: list[str]) -> str:
        parts: list[str] = []
        for idx, val in enumerate(values):
            if idx in right_align:
                parts.append(val.rjust(widths[idx]))
            else:
                parts.append(val.ljust(widths[idx]))
        return "  ".join(parts)

    header_line = _format_row(headers)
    sep_line = _format_row(["-" * w for w in widths])
    return [header_line, sep_line] + [_format_row(row) for row in rows]


def _format_status(snapshot: McpServerStatus) -> list[str]:
    return [
        snapshot.key,
        snapshot.kind,
        _status_label(snapshot),
        str(snapshot.tool_count),
        _short_text(snapshot.error),
    ]


def _format_snapshot_lines(
    snapshot: tuple[McpServerStatus, ...],
    total: int,
) -> list[str]:
    headers = ["Server", "Transport", "Status", "Tools", "Error"]
    rows = [_format_status(row) for row in snapshot]
    lines = ["MCP Status:"]
    lines.extend(_format_table(headers, rows, right_align={3}))
    lines.append(f"Total: {total} tools across {len(snapshot)} servers")
    return lines


def _no_servers_message() -> str:
    return (
        "MCP Status:\n"
        "No MCP servers configured.\n"
        "Add servers in config.yaml under mcp.servers\n"
        "(global: ~/.agenterm/config.yaml; optional override: .agenterm/config.yaml).\n"
        "See: agenterm mcp --help"
    )


def mcp_refresh(
    state: SessionState,
    _cmd: McpRefreshCmd,
) -> tuple[SessionState, str | None]:
    """Schedule MCP refresh at the next run boundary.

    Args:
      state: Current session state.
      cmd: Structured command requesting an MCP refresh.

    Returns:
      A tuple of updated state and a short UX message.

    """
    return (
        replace(state, mcp=replace(state.mcp, refresh_pending=True)),
        "MCP: refresh scheduled (will update discovered tools on next run)",
    )


async def mcp_status(
    state: SessionState,
    _cmd: McpStatusCmd,
) -> tuple[SessionState, str | None]:
    """Display MCP server connection status.

    Args:
      state: Current session state.
      cmd: Structured command requesting MCP status.

    Returns:
      A tuple of unchanged state and a rendered status summary.

    """
    servers = tuple(state.cfg.mcp.servers or ())
    if not servers:
        return state, _no_servers_message()
    snapshot = await build_mcp_status_snapshot(servers)
    lines = _format_snapshot_lines(snapshot.servers, snapshot.total_tools)
    return state, "\n".join(lines)
