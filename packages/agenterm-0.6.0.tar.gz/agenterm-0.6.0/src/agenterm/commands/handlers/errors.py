"""Handlers for `/errors` REPL command."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.actions import ReplActionErrors

if TYPE_CHECKING:
    from agenterm.commands.model import ErrorsCmd
    from agenterm.core.types import SessionState


def errors_cmd(
    state: SessionState,
    _cmd: ErrorsCmd,
) -> tuple[SessionState, ReplActionErrors]:
    """Return a structural action to render the error buffer."""
    return state, ReplActionErrors()


__all__ = ("errors_cmd",)
