"""Handlers for reasoning configuration commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from openai.types.shared import Reasoning as ReasoningModel

from agenterm.commands.model import (
    ReasoningEffortCmd,
    ReasoningSummaryCmd,
    ReasoningUnsetCmd,
)
from agenterm.config.editors import (
    set_reasoning_effort,
    set_reasoning_summary,
    unset_reasoning,
)
from agenterm.core.choices.common import UNSET_MARKER
from agenterm.core.errors import ValidationError

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


def _pair_from(obj: ReasoningModel | None) -> tuple[str | None, str | None]:
    """Extract (effort, summary) from a Reasoning value."""
    if isinstance(obj, ReasoningModel):
        eff = obj.effort
        sm = obj.summary
        return eff, sm
    return (None, None)


def reasoning_unset(
    state: SessionState,
    _cmd: ReasoningUnsetCmd,
) -> tuple[SessionState, str | None]:
    """Unset reasoning configuration for session or targeted agents.

    Args:
      state: Current session state.
      _cmd: Unset command (unused).

    Returns:
      A tuple of updated state and a confirmation message.

    """
    new_cfg = unset_reasoning(state.cfg)
    return state.with_cfg(new_cfg), f"Reasoning: {UNSET_MARKER}"


def _apply_reasoning_session(
    state: SessionState,
    *,
    is_effort: bool,
    cmd: ReasoningEffortCmd | ReasoningSummaryCmd,
) -> tuple[SessionState, str | None]:
    try:
        if is_effort and isinstance(cmd, ReasoningEffortCmd):
            new_cfg = set_reasoning_effort(state.cfg, effort=cmd.effort)
        elif (not is_effort) and isinstance(cmd, ReasoningSummaryCmd):
            new_cfg = set_reasoning_summary(state.cfg, summary=cmd.summary)
        else:
            return state, "Invalid reasoning command"
    except ValidationError as e:
        return state, f"Invalid reasoning: {e}"
    eff, summ = _pair_from(new_cfg.model.reasoning)
    eff_s = (eff or UNSET_MARKER) if new_cfg.model.reasoning else UNSET_MARKER
    summ_s = (summ or UNSET_MARKER) if new_cfg.model.reasoning else UNSET_MARKER
    return state.with_cfg(new_cfg), f"Reasoning set: effort={eff_s}, summary={summ_s}"


def reasoning_modify(
    state: SessionState,
    cmd: ReasoningEffortCmd | ReasoningSummaryCmd,
) -> tuple[SessionState, str | None]:
    """Unified handler for reasoning effort/summary updates (session-only)."""
    is_effort = isinstance(cmd, ReasoningEffortCmd)
    return _apply_reasoning_session(state, is_effort=is_effort, cmd=cmd)


"""
Dispatcher routes both ReasoningEffortCmd and ReasoningSummaryCmd to `reasoning_modify`.
"""
