"""Branch command handlers for REPL."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.actions import (
    ReplActionBranchDelete,
    ReplActionBranchFork,
    ReplActionBranchList,
    ReplActionBranchNew,
    ReplActionBranchRuns,
    ReplActionBranchUse,
)

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplAction
    from agenterm.commands.model import (
        BranchDeleteCmd,
        BranchForkCmd,
        BranchListCmd,
        BranchNewCmd,
        BranchRunsCmd,
        BranchUseCmd,
    )
    from agenterm.core.types import SessionState


def branch_list_cmd(
    state: SessionState,
    _cmd: BranchListCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """List branches for the active session."""
    if state.session_id is None:
        return state, "Branch list: no active session."
    return state, ReplActionBranchList()


def branch_use_cmd(
    state: SessionState,
    cmd: BranchUseCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Switch to a branch by id."""
    if state.session_id is None:
        return state, "Branch use: no active session."
    return state, ReplActionBranchUse(branch_id=cmd.branch_id)


def branch_new_cmd(
    state: SessionState,
    cmd: BranchNewCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Create a new branch from head."""
    if state.session_id is None:
        return state, "Branch new: no active session."
    return state, ReplActionBranchNew(branch_id=cmd.branch_id)


def branch_fork_cmd(
    state: SessionState,
    cmd: BranchForkCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Create a branch from a run and switch to it."""
    if state.session_id is None:
        return state, "Branch fork: no active session."
    return state, ReplActionBranchFork(
        run_number=cmd.run_number,
        branch_id=cmd.branch_id,
    )


def branch_delete_cmd(
    state: SessionState,
    cmd: BranchDeleteCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Delete a branch by id."""
    if state.session_id is None:
        return state, "Branch delete: no active session."
    return state, ReplActionBranchDelete(
        branch_id=cmd.branch_id,
        force=cmd.force,
    )


def branch_runs_cmd(
    state: SessionState,
    cmd: BranchRunsCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Show runs for a branch."""
    if state.session_id is None:
        return state, "Branch runs: no active session."
    return state, ReplActionBranchRuns(
        limit=cmd.limit,
        branch_id=cmd.branch_id,
    )


__all__ = (
    "branch_delete_cmd",
    "branch_fork_cmd",
    "branch_list_cmd",
    "branch_new_cmd",
    "branch_runs_cmd",
    "branch_use_cmd",
)
