"""Compression continuation command handler."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.actions import ReplActionCompress, ReplActionCompressShow

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplAction
    from agenterm.commands.model import CompressCmd, CompressShowCmd
    from agenterm.core.types import SessionState


def compress_cmd(
    state: SessionState,
    _cmd: CompressCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Request a compression run for the active session.

    The handler itself does not execute compaction; the REPL runner performs the
    provider call because it owns lifecycle, phase UX, and session persistence.
    """
    return state, ReplActionCompress(notice="Compressing session history...")


def compress_show_cmd(
    state: SessionState,
    _cmd: CompressShowCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Request rendering of the most recent compression continuation."""
    return state, ReplActionCompressShow()


__all__ = ("compress_cmd", "compress_show_cmd")
