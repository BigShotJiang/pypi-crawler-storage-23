"""Approvals handlers for REPL commands."""

from __future__ import annotations

from typing import TYPE_CHECKING, Final, Literal

from agenterm.constants.display import (
    APPROVALS_FULL_MAX_COMMANDS_DEFAULT,
    APPROVALS_FULL_MAX_DIFF_LINES_DEFAULT,
    APPROVALS_PREVIEW_MAX_CHARS_DEFAULT,
)
from agenterm.core.text import shorten_line
from agenterm.ui.transcript.diffs import format_unified_diff_lines

if TYPE_CHECKING:
    from agenterm.commands.model import (
        ApprovalsApproveCmd,
        ApprovalsDetailCmd,
        ApprovalsListCmd,
        ApprovalsModeCmd,
        ApprovalsRejectCmd,
        ApprovalsShowCmd,
    )
    from agenterm.core.approvals import (
        CompressionApprovalItem,
        McpApprovalItem,
        PatchApprovalItem,
        ShellApprovalItem,
    )
    from agenterm.core.types import SessionState


SHELL_DETAIL_MAX_COMMANDS: Final = APPROVALS_FULL_MAX_COMMANDS_DEFAULT
PATCH_DETAIL_MAX_DIFF_LINES: Final = APPROVALS_FULL_MAX_DIFF_LINES_DEFAULT


def approvals_show_cmd(
    state: SessionState,
    _cmd: ApprovalsShowCmd,
) -> tuple[SessionState, str | None]:
    """Show current approval mode."""
    mode = state.approvals.mode
    compress_n = len(state.approvals.compress.pending())
    shell_n = len(state.approvals.shell.pending())
    patch_n = len(state.approvals.patch.pending())
    mcp_n = len(state.approvals.mcp.pending())
    return state, (
        "Approval mode: "
        f"{mode} (pending: compress={compress_n} shell={shell_n} "
        f"patch={patch_n} mcp={mcp_n})"
    )


def _resolve_all_pending(state: SessionState) -> int:
    """Approve all pending shell and patch approvals."""
    count = 0
    compress_mgr = state.approvals.compress
    for item in compress_mgr.pending():
        compress_mgr.resolve(item.id, approved=True)
        count += 1
    shell_mgr = state.approvals.shell
    for item in shell_mgr.pending():
        shell_mgr.resolve(item.id, approved=True)
        count += 1
    patch_mgr = state.approvals.patch
    for item in patch_mgr.pending():
        patch_mgr.resolve(item.id, approved=True)
        count += 1
    mcp_mgr = state.approvals.mcp
    for item in mcp_mgr.pending():
        mcp_mgr.resolve(item.id, approved=True)
        count += 1
    return count


def approvals_mode_cmd(
    state: SessionState,
    cmd: ApprovalsModeCmd,
) -> tuple[SessionState, str | None]:
    """Set approval mode for tool approvals.

    When switching to 'auto' mode:
    - Enables global auto-resolve flag (affects future approvals)
    - Resolves any pending approvals immediately
    """
    enabled = cmd.mode == "auto"
    state.approvals.set_mode(mode=cmd.mode)
    new_state = state
    msg = f"Approval mode: {cmd.mode}"
    if enabled:
        resolved = _resolve_all_pending(state)
        if resolved > 0:
            msg = f"Approval mode: {cmd.mode} ({resolved} pending approved)"
    return new_state, msg


def approvals_list_cmd(
    state: SessionState,
    _cmd: ApprovalsListCmd,
) -> tuple[SessionState, str | None]:
    """List pending approvals across shell/apply_patch/hosted MCP."""
    compress = state.approvals.compress.pending()
    shell = state.approvals.shell.pending()
    patch = state.approvals.patch.pending()
    mcp = state.approvals.mcp.pending()
    total = len(compress) + len(shell) + len(patch) + len(mcp)
    if total == 0:
        return state, "No pending approvals."

    lines: list[str] = [f"Pending approvals: {total}"]
    lines.extend(
        f"- [compress] {item.id}: {shorten_line(item.message, limit=160)}"
        for item in compress
    )
    for item in shell:
        cmds = "; ".join(item.commands)
        summary = shorten_line(cmds, limit=160)
        if item.description:
            summary = shorten_line(
                f"{item.description} — {summary}",
                limit=160,
            )
        lines.append(f"- [shell] {item.id}: {summary}")
    lines.extend(
        (
            f"- [patch] {item.id}: "
            f"{item.description} — {item.operation_type} {item.path}"
            if item.description
            else f"- [patch] {item.id}: {item.operation_type} {item.path}"
        )
        for item in patch
    )
    lines.extend(
        f"- [mcp] {item.id}: {item.server_label} {item.tool_name}" for item in mcp
    )
    return state, "\n".join(lines)


def _find_pending_by_id(
    state: SessionState,
    ident: str,
) -> (
    tuple[Literal["compress"], CompressionApprovalItem]
    | tuple[Literal["shell"], ShellApprovalItem]
    | tuple[Literal["patch"], PatchApprovalItem]
    | tuple[Literal["mcp"], McpApprovalItem]
    | None
):
    for item in state.approvals.compress.pending():
        if item.id == ident:
            return "compress", item
    for item in state.approvals.shell.pending():
        if item.id == ident:
            return "shell", item
    for item in state.approvals.patch.pending():
        if item.id == ident:
            return "patch", item
    for item in state.approvals.mcp.pending():
        if item.id == ident:
            return "mcp", item
    return None


def _compress_detail_lines(
    ident: str,
    item: CompressionApprovalItem,
) -> list[str]:
    return [
        f"[compress] {ident}",
        f"- action: {item.action}",
        f"- message: {item.message}",
    ]


def _shell_detail_lines(
    ident: str,
    item: ShellApprovalItem,
) -> list[str]:
    lines = [f"[shell] {ident}"]
    if item.description:
        lines.append(f"- description: {item.description}")
    lines.append(f"- cwd: {item.cwd}")
    lines.append("- commands:")
    preview_limit = APPROVALS_PREVIEW_MAX_CHARS_DEFAULT
    lines.extend(
        f"  - {shorten_line(command, limit=preview_limit)}"
        for command in item.commands[:SHELL_DETAIL_MAX_COMMANDS]
    )
    if len(item.commands) > SHELL_DETAIL_MAX_COMMANDS:
        lines.append("  - …")
    return lines


def _patch_detail_lines(
    ident: str,
    item: PatchApprovalItem,
) -> list[str]:
    lines = [
        f"[patch] {ident}",
        f"- op: {item.operation_type}",
        f"- path: {item.path}",
    ]
    if item.description:
        lines.append(f"- description: {item.description}")
    diff = (item.diff or "").strip()
    if diff:
        lines.append("- diff:")
        diff_lines = format_unified_diff_lines(diff)
        lines.extend(f"  {line}" for line in diff_lines[:PATCH_DETAIL_MAX_DIFF_LINES])
        if len(diff_lines) > PATCH_DETAIL_MAX_DIFF_LINES:
            lines.append("  …")
    return lines


def _mcp_detail_lines(
    ident: str,
    item: McpApprovalItem,
) -> list[str]:
    args = shorten_line(item.arguments_json, limit=1200)
    return [
        f"[mcp] {ident}",
        f"- server: {item.server_label}",
        f"- tool: {item.tool_name}",
        "- args:",
        args,
    ]


def approvals_detail_cmd(
    state: SessionState,
    cmd: ApprovalsDetailCmd,
) -> tuple[SessionState, str | None]:
    """Show bounded details for a pending approval by id."""
    found = _find_pending_by_id(state, cmd.id)
    if found is None:
        return state, f"No pending approval with id: {cmd.id}"
    match found:
        case ("compress", compress_item):
            return state, "\n".join(_compress_detail_lines(cmd.id, compress_item))
        case ("shell", shell_item):
            return state, "\n".join(_shell_detail_lines(cmd.id, shell_item))
        case ("patch", patch_item):
            return state, "\n".join(_patch_detail_lines(cmd.id, patch_item))
        case ("mcp", mcp_item):
            return state, "\n".join(_mcp_detail_lines(cmd.id, mcp_item))


def approvals_approve_cmd(
    state: SessionState,
    cmd: ApprovalsApproveCmd,
) -> tuple[SessionState, str | None]:
    """Approve a pending approval by id."""
    found = _find_pending_by_id(state, cmd.id)
    if found is None:
        return state, f"No pending approval with id: {cmd.id}"
    kind, _item = found
    if kind == "compress":
        state.approvals.compress.resolve(cmd.id, approved=True, reason=None)
    elif kind == "shell":
        state.approvals.shell.resolve(cmd.id, approved=True)
    elif kind == "patch":
        state.approvals.patch.resolve(cmd.id, approved=True)
    else:
        state.approvals.mcp.resolve(cmd.id, approved=True, reason=None)
    return state, f"Approved: {cmd.id}"


def approvals_reject_cmd(
    state: SessionState,
    cmd: ApprovalsRejectCmd,
) -> tuple[SessionState, str | None]:
    """Reject a pending approval by id."""
    found = _find_pending_by_id(state, cmd.id)
    if found is None:
        return state, f"No pending approval with id: {cmd.id}"
    kind, _item = found
    reason = cmd.reason.strip() if cmd.reason else None
    if kind == "compress":
        state.approvals.compress.resolve(cmd.id, approved=False, reason=reason)
    elif kind == "shell":
        state.approvals.shell.resolve(cmd.id, approved=False, reason=reason)
    elif kind == "patch":
        state.approvals.patch.resolve(cmd.id, approved=False, reason=reason)
    else:
        state.approvals.mcp.resolve(cmd.id, approved=False, reason=reason)
    return state, f"Rejected: {cmd.id}"
