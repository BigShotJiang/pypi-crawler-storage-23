"""Handlers for `/last` REPL commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.actions import ReplActionLastArtifact

if TYPE_CHECKING:
    from agenterm.commands.model import LastCmd
    from agenterm.core.types import SessionState


def last_cmd(
    state: SessionState,
    cmd: LastCmd,
) -> tuple[SessionState, ReplActionLastArtifact]:
    """Return a structural action instructing the REPL to render the last artifact."""
    return state, ReplActionLastArtifact(kind=cmd.kind, mode=cmd.mode)


__all__ = ("last_cmd",)
