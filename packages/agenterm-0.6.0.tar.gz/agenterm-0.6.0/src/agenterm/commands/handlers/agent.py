"""Agent handler."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.commands.actions import ReplActionAgentSwitch
from agenterm.config.agent_files import (
    list_bundled_agents,
    list_global_agents,
    list_local_agents,
    resolve_agent,
)
from agenterm.config.editors import set_agent
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplAction
    from agenterm.commands.model import AgentCmd, AgentListCmd, AgentShowCmd
    from agenterm.core.types import SessionState


def agent_switch(
    state: SessionState,
    cmd: AgentCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Switch agent and branch from the current head."""
    try:
        resolved = resolve_agent(name=cmd.name, explicit=True)
    except ConfigError as exc:
        return state, str(exc)

    new_cfg = set_agent(
        state.cfg,
        name=resolved.name,
        instructions=resolved.text,
        path=resolved.source.path,
        source=resolved.source.location,
        explicit=True,
    )
    cleared = replace(
        state.with_cfg(new_cfg),
        prompt=replace(state.prompt, last_user_prompt=None),
        attachments=replace(
            state.attachments,
            pending=(),
            last_used=(),
            next_send_use_last=False,
        ),
    )
    notice = f"Agent set: {resolved.name} (branching from head)"
    return cleared, ReplActionAgentSwitch(notice=notice)


def agent_show(
    state: SessionState,
    _cmd: AgentShowCmd,
) -> tuple[SessionState, str | None]:
    """Show the current effective agent."""
    agent = state.cfg.agent
    source = agent.source or "unknown"
    path = str(agent.path) if agent.path is not None else "-"
    lines = [
        "Agent:",
        f"- name: {agent.name}",
        f"- source: {source}",
        f"- path: {path}",
    ]
    return state, "\n".join(lines)


def agent_list(
    state: SessionState,
    _cmd: AgentListCmd,
) -> tuple[SessionState, str | None]:
    """List available agent names grouped by source."""
    local = list_local_agents()
    global_agents = list_global_agents()
    bundled = list_bundled_agents()
    lines = ["Agents:"]
    lines.append(f"- local: {', '.join(local) if local else '(none)'}")
    lines.append(f"- global: {', '.join(global_agents) if global_agents else '(none)'}")
    lines.append(f"- bundled: {', '.join(bundled) if bundled else '(none)'}")
    return state, "\n".join(lines)


__all__ = ("agent_list", "agent_show", "agent_switch")
