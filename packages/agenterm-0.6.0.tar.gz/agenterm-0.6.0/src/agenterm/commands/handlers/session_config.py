"""Session configuration handlers: model, verbosity, reasoning, API key."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.app.services.model_registry import validate_model_id_with_registry
from agenterm.commands.actions import ReplActionModelPicker
from agenterm.config.editors import set_model as set_model_editor
from agenterm.config.editors import set_model_verbosity
from agenterm.core.choices.common import UNSET_MARKER
from agenterm.core.env import save_openai_api_key, set_openai_api_key
from agenterm.core.errors import (
    ConfigError,
    DatabaseError,
    FilesystemError,
    ValidationError,
)
from agenterm.store.session.service import session_store, update_session_model

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplAction
    from agenterm.commands.model import (
        KeyCmd,
        ModelCmd,
        ModelPickCmd,
        ReasoningShowCmd,
        VerbosityCmd,
        VerbosityShowCmd,
    )
    from agenterm.core.types import SessionState


async def set_model(
    state: SessionState,
    cmd: ModelCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Set the model for the current session."""
    raw = cmd.model.strip()
    candidate = f"openai/{raw}" if raw and "/" not in raw else cmd.model
    try:
        model_id = await validate_model_id_with_registry(
            candidate,
            store=session_store(),
            providers=state.cfg.providers,
        )
    except ValidationError as exc:
        return state, f"Invalid model id: {exc}"
    except ConfigError as exc:
        return state, f"Model registry error: {exc}"
    new_cfg = set_model_editor(state.cfg, model_id)
    new_state = state.with_cfg(new_cfg)
    if isinstance(state.session_id, str) and state.session_id:
        store, sid = session_store(), state.session_id
        try:
            await update_session_model(store=store, session_id=sid, model=model_id)
        except (FilesystemError, DatabaseError) as exc:
            return new_state, f"Model set: {model_id} (/status to confirm). warn: {exc}"
    return new_state, f"Model set: {model_id} (/status to confirm)"


def pick_model(
    state: SessionState,
    cmd: ModelPickCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Open the interactive route-first model picker modal."""
    return state, ReplActionModelPicker(route=cmd.route)


def set_verbosity(
    state: SessionState,
    cmd: VerbosityCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Set model verbosity for the session or targeted agents."""
    level = cmd.level or UNSET_MARKER
    try:
        new_cfg = set_model_verbosity(state.cfg, cmd.level)
    except ValidationError as exc:
        return state, f"Invalid verbosity: {exc}"
    return state.with_cfg(new_cfg), f"Model verbosity: {level}"


def show_verbosity(
    state: SessionState,
    _cmd: VerbosityShowCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Show the effective model verbosity."""
    v = state.cfg.model.verbosity or UNSET_MARKER
    return state, f"Verbosity: {v}"


def show_reasoning(
    state: SessionState,
    _cmd: ReasoningShowCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Show the effective reasoning configuration."""
    r = state.cfg.model.reasoning
    if r is None:
        return state, "Reasoning: unset"
    eff = r.effort or UNSET_MARKER
    summ = r.summary or UNSET_MARKER
    return state, f"Reasoning: effort={eff}, summary={summ}"


def set_api_key(
    state: SessionState,
    cmd: KeyCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Set or update the OpenAI API key and persist it to the user config dir."""
    value = cmd.value.strip()
    if not value:
        return state, "API key must be non-empty."
    try:
        env_path = save_openai_api_key(value)
    except FilesystemError as exc:
        set_openai_api_key(value)
        return (
            state,
            f"API key updated for this session.\n"
            f"warn> Failed to save key to ~/.agenterm/.env: {exc}",
        )
    set_openai_api_key(value)
    return state, f"API key saved: {env_path}"


__all__ = (
    "pick_model",
    "set_api_key",
    "set_model",
    "set_verbosity",
    "show_reasoning",
    "show_verbosity",
)
