"""Handlers for REPL prompt UI controls (/repl)."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.commands.model import (
        ReplColorDepthCmd,
        ReplCompletionCmd,
        ReplEditingModeCmd,
        ReplMouseCmd,
        ReplShowCmd,
        ReplThemeCmd,
    )
    from agenterm.core.types import SessionState


def repl_show_cmd(
    state: SessionState,
    _cmd: ReplShowCmd,
) -> tuple[SessionState, str | None]:
    """Show current prompt UI controls for the active REPL session."""
    lines = [
        "REPL UI:",
        f"- theme: {state.ui.theme}",
        f"- color_depth: {state.ui.color_depth}",
        f"- mouse: {'on' if state.ui.mouse else 'off'}",
        f"- completion: {state.ui.completion}",
        f"- edit_mode: {state.ui.editing_mode}",
    ]
    return state, "\n".join(lines)


def repl_theme_cmd(
    state: SessionState,
    cmd: ReplThemeCmd,
) -> tuple[SessionState, str | None]:
    """Set the prompt UI theme for the REPL."""
    new_state = replace(state, ui=replace(state.ui, theme=cmd.theme))
    return new_state, f"Theme: {cmd.theme}"


def repl_color_depth_cmd(
    state: SessionState,
    cmd: ReplColorDepthCmd,
) -> tuple[SessionState, str | None]:
    """Set prompt-toolkit color depth for the REPL."""
    new_state = replace(state, ui=replace(state.ui, color_depth=cmd.depth))
    return new_state, f"Color depth: {cmd.depth}"


def repl_mouse_cmd(
    state: SessionState,
    cmd: ReplMouseCmd,
) -> tuple[SessionState, str | None]:
    """Toggle prompt-toolkit mouse support."""
    on = bool(cmd.on)
    new_state = replace(state, ui=replace(state.ui, mouse=on))
    return new_state, f"Mouse: {'on' if on else 'off'}"


def repl_completion_cmd(
    state: SessionState,
    cmd: ReplCompletionCmd,
) -> tuple[SessionState, str | None]:
    """Set prompt completion mode."""
    new_state = replace(state, ui=replace(state.ui, completion=cmd.mode))
    return new_state, f"Completion: {cmd.mode}"


def repl_editing_mode_cmd(
    state: SessionState,
    cmd: ReplEditingModeCmd,
) -> tuple[SessionState, str | None]:
    """Set prompt editing mode."""
    new_state = replace(state, ui=replace(state.ui, editing_mode=cmd.mode))
    return new_state, f"Edit mode: {cmd.mode}"


__all__ = (
    "repl_color_depth_cmd",
    "repl_completion_cmd",
    "repl_editing_mode_cmd",
    "repl_mouse_cmd",
    "repl_show_cmd",
    "repl_theme_cmd",
)
