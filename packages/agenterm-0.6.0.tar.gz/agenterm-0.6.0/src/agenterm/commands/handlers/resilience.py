"""Resilience handlers for REPL slash commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.engine.model_provider import gateway_route_for_model
from agenterm.workflow.run.retry_policy import resolve_provider_resilience

if TYPE_CHECKING:
    from agenterm.commands.model import ResilienceShowCmd
    from agenterm.core.types import SessionState


def _format_optional_int(value: int | None) -> str:
    return "(inherit)" if value is None else str(value)


def _format_optional_float(value: float | None) -> str:
    return "(inherit)" if value is None else str(value)


def resilience_show_cmd(
    state: SessionState,
    _cmd: ResilienceShowCmd,
) -> tuple[SessionState, str | None]:
    """Render effective provider resilience for the active REPL model."""
    model_id = state.cfg.agent.model
    resolved = resolve_provider_resilience(
        state.cfg,
        model_id=model_id,
        workflow="streamed",
    )
    provider = state.cfg.retries.provider
    route = gateway_route_for_model(state.cfg.providers, model_id=model_id)
    lines: list[str] = ["Resilience:"]
    lines.append(f"- model: {model_id}")
    lines.append("- workflow: streamed")
    lines.append(
        "- provider_defaults: "
        f"max_retries={provider.max_retries}, "
        f"max_total_attempts={provider.max_total_attempts}, "
        f"deadline_seconds={provider.deadline_seconds}, "
        f"attempt_timeout_seconds={provider.attempt_timeout_seconds}"
    )
    if route is None:
        lines.append("- route_overrides: (none)")
    else:
        route_name, route_cfg = route
        lines.append(f"- route: {route_name}")
        lines.append(
            "- route_overrides: "
            f"retry_max_retries={_format_optional_int(route_cfg.retry_max_retries)}, "
            "retry_max_total_attempts="
            f"{_format_optional_int(route_cfg.retry_max_total_attempts)}, "
            "retry_deadline_seconds="
            f"{_format_optional_float(route_cfg.retry_deadline_seconds)}, "
            "retry_attempt_timeout_seconds="
            f"{_format_optional_float(route_cfg.retry_attempt_timeout_seconds)}"
        )
    lines.append(
        "- effective: "
        f"max_retries={resolved.retry_policy.max_retries}, "
        f"max_total_attempts={resolved.max_total_attempts}, "
        f"deadline_seconds={resolved.deadline_seconds}, "
        f"attempt_timeout_seconds={resolved.attempt_timeout_seconds}"
    )
    lines.append(
        "- streamed_restart_paths: "
        "tool_args_stall_retry_once="
        f"{'on' if resolved.allow_stall_retry else 'off'}, "
        "optional_param_fallback_once="
        f"{'on' if resolved.allow_optional_fallback_restart else 'off'}"
    )
    return state, "\n".join(lines)


__all__ = ("resilience_show_cmd",)
