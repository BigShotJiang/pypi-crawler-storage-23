"""Tool listing helpers for /tools output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.selection_utils import dedupe_str, expand_bundle_keys
from agenterm.core.tool_selection import (
    ToolCatalog,
    resolve_selection,
    selected_mcp_server_configs,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.toolspec import ToolSpec
    from agenterm.core.types import McpDiscoveryStatus, SessionState


def _fmt_list(
    keys: list[str],
    *,
    tools_map: Mapping[str, ToolSpec] | None,
) -> str:
    parts: list[str] = []
    for k in keys:
        ts = (tools_map or {}).get(k)
        if ts is None:
            parts.append(f"{k} (?)")
            continue
        # Show type plus namespace to indicate where the tool executes
        t = ts.type
        ns = ts.plane
        parts.append(f"{k} ({t}, {ns})")
    return ", ".join(parts) if parts else "(none)"


def _bundle_lines(
    map_: Mapping[str, list[str]] | None,
    bundles: list[str],
) -> list[str]:
    out: list[str] = []
    for b in bundles:
        keys = (map_ or {}).get(b, [])
        out.append(f"- {b}: {', '.join(keys) if keys else '(empty)'}")
    return out


def _mcp_lines_enabled(
    *,
    enabled: bool,
    names: list[str] | None,
    discovery_status: McpDiscoveryStatus,
    discovery_error: str | None,
) -> list[str]:
    def _pretty(n: str) -> str:
        s = n.strip()
        if s.startswith("mcp__"):
            rest = s[len("mcp__") :]
            if "__" in rest:
                server, tool = rest.split("__", 1)
                return f"{server}/{tool}"
            return rest
        return s

    if not enabled:
        return ["(off)"]

    if discovery_status == "error":
        summary = (
            f"(error: {discovery_error}; use '/mcp status' for details)"
            if discovery_error
            else "(error; use '/mcp status' for details)"
        )
        lines = [summary]
        if names:
            lines.extend([f"- {_pretty(n)}" for n in sorted(names)])
        return lines

    if discovery_status == "unknown":
        return ["(pending; use '/mcp refresh' to update)"]

    if names:
        return [f"- {_pretty(n)}" for n in sorted(names)]
    return ["(none)"]


def _initial_selected_keys(
    *,
    state: SessionState,
    bundles: list[str],
    tools: list[str],
) -> list[str]:
    keys: list[str] = []
    for b in bundles:
        keys.extend(expand_bundle_keys(b, bundles=state.tools.bundles_map or {}))
    keys.extend(tools)
    return dedupe_str([str(k) for k in keys])


def _unknown_selected_keys(state: SessionState, init_keys: list[str]) -> list[str]:
    tm = state.tools.tools_map or {}
    return [k for k in init_keys if k not in tm]


def _effective_tool_specs(
    state: SessionState,
) -> tuple[list[ToolSpec], str | None]:
    """Compute effective ToolSpecs for the current selection.

    Listing is an inspection surface: it never raises selection errors and
    instead returns them as strings for display.
    """
    tools_map = state.tools.tools_map or {}
    bundles_map = state.tools.bundles_map or {}
    catalog = ToolCatalog(
        tools_map=tools_map,
        bundles_map=bundles_map,
        default_bundles=list(state.tools.default_bundles or []),
    )
    resolved = resolve_selection(state.tools.selection, catalog=catalog)
    if resolved.error is not None:
        return [], resolved.error
    return list(resolved.specs), None


def _fmt_effective(specs: list[ToolSpec]) -> str:
    """Format effective ToolSpecs for /tools output.

    This view is selection-oriented: it reflects which tool families the
    current bundles + direct selection would attach. Viability (for example,
    file_search without vector_store_ids) is surfaced via built-in flags in
    /status so that /tools can stay focused on selection shape.
    """
    if not specs:
        return "(none)"
    # Use namespaced keys directly
    parts = [f"{s.key} ({s.type}, {s.plane})" for s in specs]
    return ", ".join(parts)


def _inactive_builtin_families(state: SessionState) -> list[str]:
    """Return built-in tool families that are selected but not viable.

    This mirrors the engine's construction rules and the /status
    builtin_effective flags so users can see misconfigurations directly
    from /tools (for example, file_search with no vector_store_ids).
    """
    if not state.tools.enabled:
        return []
    inactive: list[str] = []

    specs, _ = _effective_tool_specs(state)
    file_search_selected = any(spec.type == "file_search" for spec in specs)
    file_search_ready = bool(
        state.cfg.tools.file_search and state.cfg.tools.file_search.vector_store_ids,
    )
    if file_search_selected and not file_search_ready:
        inactive.append("file_search (missing vector_store_ids)")

    # Shell is effective when selected on supported sandbox platforms.
    # No additional viability conditions beyond platform support.

    # web_search, apply_patch, and image_generation do not currently have
    # additional viability conditions beyond selection.
    return inactive


def _tools_list_single(state: SessionState) -> str:
    bundles = list(state.tools.selection.selected_bundles)
    tools = list(state.tools.selection.selected_keys)
    bundle_lines = _bundle_lines(state.tools.bundles_map, bundles)
    eff_specs, sel_error = _effective_tool_specs(state)
    init_keys = _initial_selected_keys(state=state, bundles=bundles, tools=tools)
    unknown = _unknown_selected_keys(state, init_keys)
    mcp_selected_servers = selected_mcp_server_configs(eff_specs)
    mcp_enabled = bool(state.tools.enabled and mcp_selected_servers)
    mcp_lines = _mcp_lines_enabled(
        enabled=mcp_enabled,
        names=list(state.mcp.tool_names or ()),
        discovery_status=state.mcp.discovery_status,
        discovery_error=state.mcp.discovery_error,
    )
    inactive = _inactive_builtin_families(state)
    text = [
        "Bundles:",
        *(bundle_lines or ["(none)"]),
        "Direct tools:",
        _fmt_list(tools, tools_map=state.tools.tools_map),
        *([f"Unknown (ignored): {', '.join(unknown)}"] if unknown else []),
        *([f"Selection error: {sel_error}"] if sel_error else []),
        "Effective (selection):",
        _fmt_effective(eff_specs),
    ]
    if inactive:
        text.append("Inactive (misconfigured builtins):")
        text.extend(f"- {entry}" for entry in inactive)
    text.extend(
        [
            "MCP tools (discovered):",
            *(mcp_lines or ["(none — /mcp refresh to update)"]),
            "Tip: /tools add bundle NAME or /tools add tool KEY",
        ],
    )
    return "\n".join(text)


def tools_list(state: SessionState) -> tuple[SessionState, str | None]:
    """Render a summary of tool bundles, direct tools, and effective keys.

    Args:
      state: Current session state.

    Returns:
      The unchanged state and a multi-line summary (per agent when targeted).

    """
    header = f"Tools gate: {'on' if state.tools.enabled else 'off'}"
    if not state.tools.enabled:
        note = (
            "Note: tools gate is off; the model will not receive any tools until "
            "you run '/tools on'."
        )
        body = _tools_list_single(state)
        return state, f"{header}\n{note}\n{body}"
    body = _tools_list_single(state)
    return state, f"{header}\n{body}"
