"""Handler for toggling the tools gate in a session."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.commands.model import ToolsToggleCmd
    from agenterm.core.types import SessionState


def tools_toggle(
    state: SessionState,
    cmd: ToolsToggleCmd,
) -> tuple[SessionState, str | None]:
    """Toggle tools gate for the session.

    Args:
      state: Current session state.
      cmd: Toggle command specifying on/off.

    Returns:
      A tuple of updated state and an informational message.

    """
    msg = (
        "Tools: on (/tools; MCP connects when needed)"
        if cmd.on
        else "Tools: off (tool_choice: none; MCP disabled)"
    )
    return state.with_tools_enabled(on=cmd.on), msg
