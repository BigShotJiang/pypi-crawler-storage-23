"""Handlers for /tools selection edits (add/remove/reset)."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING, Literal

from agenterm.commands.model import (
    ToolsAddBundleCmd,
    ToolsAddToolCmd,
    ToolsRemoveBundleCmd,
    ToolsRemoveToolCmd,
    ToolsResetCmd,
)
from agenterm.core.tool_selection import (
    ToolCatalog,
    ToolSelection,
    resolve_selection,
    selected_mcp_server_configs,
)

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


def tools_modify(
    state: SessionState,
    cmd: ToolsAddBundleCmd
    | ToolsRemoveBundleCmd
    | ToolsAddToolCmd
    | ToolsRemoveToolCmd,
) -> tuple[SessionState, str | None]:
    """Unified handler for tools add/remove (bundles and tools).

    Reduces four near-identical handlers to a single typed function while
    preserving messages and behavior via `_apply_selection`.

    Args:
      state: Current session state.
      cmd: Typed command describing the operation and inputs.

    Returns:
      A tuple of the updated state and an informational message.

    """
    kind: Literal["bundle", "tool"]
    op: Literal["add", "remove"]
    items: list[str]
    if isinstance(cmd, ToolsAddBundleCmd):
        kind, op, items = "bundle", "add", [str(n) for n in cmd.names]
    elif isinstance(cmd, ToolsRemoveBundleCmd):
        kind, op, items = "bundle", "remove", [str(n) for n in cmd.names]
    elif isinstance(cmd, ToolsAddToolCmd):
        kind, op, items = "tool", "add", [str(k) for k in cmd.keys]
    else:
        # Remaining variant: ToolsRemoveToolCmd
        kind, op, items = "tool", "remove", [str(k) for k in cmd.keys]
    # All command variants are covered by the union above
    return _apply_selection(state, kind=kind, op=op, items=items)


def tools_reset(
    state: SessionState,
    _cmd: ToolsResetCmd,
) -> tuple[SessionState, str | None]:
    """Reset tools selection to the session start values.

    Args:
      state: Current session state.
      _cmd: Reset command (unused).

    Returns:
      A tuple of updated state and an informational message.

    """
    return _apply_simple_selection_op(state, _op="reset")


def _apply_selection(
    state: SessionState,
    *,
    kind: Literal["bundle", "tool"],
    op: Literal["add", "remove"],
    items: list[str],
) -> tuple[SessionState, str | None]:
    """Apply selection changes for the single session.

    Args:
      state: Current session state.
      kind: Whether to apply bundle or tool changes.
      op: The operation to perform (add/remove).
      items: Bundle names or tool keys to apply.

    Returns:
      A tuple of the updated state and an informational message.

    """
    add = op == "add"
    return _apply_single(state, kind=kind, add=add, items=items)


def _apply_single(
    state: SessionState,
    *,
    kind: Literal["bundle", "tool"],
    add: bool,
    items: list[str],
) -> tuple[SessionState, str | None]:
    sel = _apply_kind(state.tools.selection, kind=kind, add=add, items=items)
    kind_title = "Bundles" if kind == "bundle" else "Tools"
    tools_map = state.tools.tools_map or {}
    bundles_map = state.tools.bundles_map or {}
    catalog = ToolCatalog(
        tools_map=tools_map,
        bundles_map=bundles_map,
        default_bundles=list(state.tools.default_bundles or []),
    )
    resolved = resolve_selection(sel, catalog=catalog)
    if resolved.error is not None:
        msg = f"Selection error: {resolved.error} (/tools to inspect)"
        return state, msg

    before = resolve_selection(state.tools.selection, catalog=catalog)
    before_sig = (
        selected_mcp_server_configs(before.specs) if before.error is None else ()
    )
    after_sig = selected_mcp_server_configs(resolved.specs)

    msg = f"{kind_title} {('added' if add else 'removed')}: {', '.join(items)} (/tools)"
    state_upd = replace(state, tools=replace(state.tools, selection=sel))
    if after_sig != before_sig:
        state_upd = replace(
            state_upd,
            mcp=replace(
                state.mcp,
                refresh_pending=False,
                tool_names=(),
                discovery_status="unknown",
                discovery_error=None,
            ),
        )
    return state_upd, msg


def _apply_simple_selection_op(
    state: SessionState,
    *,
    _op: Literal["reset"],
) -> tuple[SessionState, str | None]:
    """Apply a simple selection op (reset) to the session.

    Args:
      state: Current session state.
      _op: The operation to apply (currently only 'reset').

    Returns:
      A tuple of the updated state and an informational message.

    """

    def _sel_for_single() -> tuple[ToolSelection, str]:
        sel = state.tools.startup_selection
        return (sel, "Tools selection: reset to session start (flags honored) (/tools)")

    sel, msg = _sel_for_single()
    tools_map = state.tools.tools_map or {}
    bundles_map = state.tools.bundles_map or {}
    catalog = ToolCatalog(
        tools_map=tools_map,
        bundles_map=bundles_map,
        default_bundles=list(state.tools.default_bundles or []),
    )
    resolved = resolve_selection(sel, catalog=catalog)
    if resolved.error is not None:
        return state, f"Selection error: {resolved.error} (/tools)"

    before = resolve_selection(state.tools.selection, catalog=catalog)
    before_sig = (
        selected_mcp_server_configs(before.specs) if before.error is None else ()
    )
    after_sig = selected_mcp_server_configs(resolved.specs)

    state_upd = replace(state, tools=replace(state.tools, selection=sel))
    if after_sig != before_sig:
        state_upd = replace(
            state_upd,
            mcp=replace(
                state.mcp,
                refresh_pending=False,
                tool_names=(),
                discovery_status="unknown",
                discovery_error=None,
            ),
        )
    return state_upd, msg


def _apply_kind(
    sel: ToolSelection,
    *,
    kind: Literal["bundle", "tool"],
    add: bool,
    items: list[str],
) -> ToolSelection:
    """Apply add/remove to a ToolSelection for given kind.

    Centralizes bundle/tool branching to reduce duplication and keep messages
    consistent.
    """
    if kind == "bundle":
        return sel.add_bundles(items) if add else sel.remove_bundles(items)
    return sel.add_keys(items) if add else sel.remove_keys(items)
