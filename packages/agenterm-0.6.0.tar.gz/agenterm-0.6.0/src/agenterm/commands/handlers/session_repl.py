"""Session control handlers: attachments, switching, runs, stop/edit/again."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING, Final
from urllib.parse import urlparse

from agenterm.commands.actions import (
    ReplActionAttachSession,
    ReplActionContinue,
    ReplActionEditLast,
    ReplActionNewSession,
    ReplActionSendAgain,
    ReplActionSessionRuns,
)
from agenterm.core.text import display_role, shorten_line
from agenterm.store.history import history_store
from agenterm.store.session.service import (
    get_session_metadata_row,
    last_message_snippets_by_branch,
    list_session_metadata,
    session_store,
)
from agenterm.store.turn_attempts import latest_cancelled_turn_attempt
from agenterm.ui.cli_renderer_base import relative_time

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplAction
    from agenterm.commands.model import (
        AgainCmd,
        AttachCmd,
        AttachmentsShowCmd,
        ClearCmd,
        ContinueCmd,
        DetachAllCmd,
        DetachPathCmd,
        EditCmd,
        NewSessionCmd,
        SessionRunsCmd,
        SessionsListCmd,
        SessionsUseCmd,
    )
    from agenterm.core.types import SessionState


ATTACHMENTS_SHOW_MAX_ITEMS: Final = 20
_SESSION_LIST_COLUMNS: Final = (
    ("Session", 9),
    ("Updated", 8),
    ("Last message", 96),
)
_SESSION_ID_HEAD: Final = 4
_SESSION_ID_TAIL: Final = 4
_SESSION_ID_MIN: Final = _SESSION_ID_HEAD + _SESSION_ID_TAIL


def _format_session_row(values: tuple[str, ...]) -> str:
    parts: list[str] = []
    last_index = len(_SESSION_LIST_COLUMNS) - 1
    for idx, (value, (_label, width)) in enumerate(
        zip(values, _SESSION_LIST_COLUMNS, strict=False)
    ):
        cell = shorten_line(value, limit=width)
        if idx < last_index:
            parts.append(cell.ljust(width))
        else:
            parts.append(cell)
    return "  ".join(parts).rstrip()


def _session_list_header() -> tuple[str, str]:
    header = _format_session_row(tuple(label for label, _ in _SESSION_LIST_COLUMNS))
    divider = "-" * len(header)
    return header, divider


def _session_id_preview(session_id: str) -> str:
    if len(session_id) <= _SESSION_ID_MIN:
        return session_id
    return f"{session_id[:_SESSION_ID_HEAD]}…{session_id[-_SESSION_ID_TAIL:]}"


def _two_line_preview(text: str, *, width: int) -> tuple[str, str]:
    compact = " ".join(text.split())
    if not compact:
        return "", ""
    if len(compact) <= width:
        return compact, ""
    split_at = compact.rfind(" ", 0, width + 1)
    if split_at <= 0:
        split_at = width
    first = compact[:split_at].rstrip()
    remainder = compact[split_at:].lstrip()
    second = shorten_line(remainder, limit=width)
    return first, second


def attach_cmd(
    state: SessionState,
    cmd: AttachCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Stage a local file or HTTP(S) URL for the NEXT message only."""
    raw = (cmd.path or "").strip()
    if not raw:
        return state, "Usage: /attach <PATH|URL>"
    pr = urlparse(raw)
    if pr.scheme in ("http", "https") and pr.netloc:
        pending = list(state.attachments.pending or ())
        if raw not in pending:
            pending.append(raw)
        return (
            state.with_attachments(tuple(pending)),
            f"Attached for next send: {raw}",
        )
    path_obj = Path(raw).expanduser()
    if not path_obj.is_file():
        return state, f"Attach: not a file or URL: {raw}"
    abs_path = str(path_obj)
    pending2 = list(state.attachments.pending or ())
    if abs_path not in pending2:
        pending2.append(abs_path)
    return state.with_attachments(tuple(pending2)), f"Attached for next send: {raw}"


def attachments_show_cmd(
    state: SessionState,
    _cmd: AttachmentsShowCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Show staged and last-used attachments for this REPL session."""
    pending = list(state.attachments.pending or ())
    last_used = list(state.attachments.last_used or ())
    reuse_last = bool(state.attachments.next_send_use_last)

    lines: list[str] = ["Attachments:"]
    lines.append(f"- staged: {len(pending)}")
    lines.extend(f"  - {item}" for item in pending[:ATTACHMENTS_SHOW_MAX_ITEMS])
    if len(pending) > ATTACHMENTS_SHOW_MAX_ITEMS:
        lines.append("  - …")

    lines.append(f"- last_used: {len(last_used)}")
    lines.extend(f"  - {item}" for item in last_used[:ATTACHMENTS_SHOW_MAX_ITEMS])
    if len(last_used) > ATTACHMENTS_SHOW_MAX_ITEMS:
        lines.append("  - …")

    lines.append(f"- next_send_use_last: {'yes' if reuse_last else 'no'}")
    return state, "\n".join(lines)


def detach_all_cmd(
    state: SessionState,
    _cmd: DetachAllCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Unstage all pending attachments for the next send."""
    if not state.attachments.pending:
        return state, "Attach remove: no staged attachments."
    new_state = replace(
        state,
        attachments=replace(state.attachments, pending=()),
    )
    msg = "Removed all staged attachments."
    if state.attachments.next_send_use_last:
        msg = (
            f"{msg} Note: next send is set to reuse last attachments; use /attach "
            "clear to disable."
        )
    return new_state, msg


def detach_path_cmd(
    state: SessionState,
    cmd: DetachPathCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Unstage a single pending attachment for the next send."""
    raw = (cmd.path or "").strip()
    if not raw:
        return state, "Usage: /attach remove <PATH|URL> | /attach remove all"
    if not state.attachments.pending:
        return state, "Attach remove: no staged attachments."

    candidates: set[str] = {raw}
    pr = urlparse(raw)
    if pr.scheme not in ("http", "https") or not pr.netloc:
        path_obj = Path(raw).expanduser()
        candidates.add(str(path_obj))

    pending = list(state.attachments.pending or ())
    kept = [p for p in pending if p not in candidates]
    if len(kept) == len(pending):
        return state, f"Attach remove: not staged: {raw}"

    new_state = replace(
        state,
        attachments=replace(state.attachments, pending=tuple(kept)),
    )
    msg = f"Removed: {raw}"
    if state.attachments.next_send_use_last:
        msg = (
            f"{msg} Note: next send is set to reuse last attachments; use /attach "
            "clear to disable."
        )
    return new_state, msg


def new_session_cmd(
    state: SessionState,
    _cmd: NewSessionCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Request a fresh REPL session (new conversation)."""
    cleared = replace(
        state,
        session_id=None,
        branch_id=None,
        prompt=replace(state.prompt, last_user_prompt=None),
        attachments=replace(
            state.attachments,
            pending=(),
            last_used=(),
            next_send_use_last=False,
        ),
    )
    return cleared, ReplActionNewSession()


async def sessions_list_cmd(
    state: SessionState,
    _cmd: SessionsListCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Render a concise list of known sessions from the local store."""
    store = session_store()
    history = history_store()
    rows = await list_session_metadata(store)
    if not rows:
        return state.with_session_id_cache(
            ()
        ), "Sessions: no sessions recorded in the local store."

    session_ids = tuple(meta.session_id for meta in rows)

    header, divider = _session_list_header()
    lines: list[str] = [
        f"Sessions ({len(rows)}):",
        "Use /session use <ID> to attach.",
        header,
        divider,
    ]
    for meta in rows:
        snippets = await last_message_snippets_by_branch(
            store=history,
            session_id=meta.session_id,
            branch_ids=[meta.head_branch_id],
        )
        last_message = snippets.get(meta.head_branch_id)
        if last_message is None:
            last_label = "-"
        else:
            role_label = display_role(last_message.role) or last_message.role
            last_label = f"{role_label}: {last_message.snippet}"
        updated = relative_time(meta.updated_at)
        session_id = _session_id_preview(meta.session_id)
        msg_first, msg_second = _two_line_preview(
            last_label,
            width=_SESSION_LIST_COLUMNS[2][1],
        )
        if last_label != "-" and not msg_second:
            msg_second = "…"
        lines.append(
            _format_session_row(
                (
                    session_id,
                    updated,
                    msg_first or "-",
                )
            ),
        )
        if msg_second:
            lines.append(
                _format_session_row(
                    (
                        "",
                        "",
                        msg_second,
                    )
                ),
            )
    return state.with_session_id_cache(session_ids), "\n".join(lines)


async def sessions_use_cmd(
    state: SessionState,
    cmd: SessionsUseCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Attach the REPL to an existing stored session by id."""
    meta_row = await get_session_metadata_row(session_store(), cmd.session_id)
    if meta_row is None:
        return state, f"Sessions: no session with id {cmd.session_id!r}."

    cache = tuple({*(state.caches.session_ids or ()), cmd.session_id})
    new_state = replace(
        state,
        caches=replace(state.caches, session_ids=cache),
    )
    return new_state, ReplActionAttachSession(cmd.session_id)


def session_runs_cmd(
    state: SessionState,
    cmd: SessionRunsCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Request recent runs for the active session."""
    return state, ReplActionSessionRuns(cmd.limit)


def again_cmd(
    state: SessionState,
    _cmd: AgainCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Re-run the previous prompt if available."""
    if not state.prompt.last_user_prompt:
        return state, "Nothing to send again."
    return state, ReplActionSendAgain()


async def continue_cmd(
    state: SessionState,
    _cmd: ContinueCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Continue after a cancelled/timeout run from the last coherent state."""
    if not state.session_id:
        return state, "No active session; nothing to continue."
    session_id = state.session_id
    branch_id = state.branch_id or "main"
    store = session_store()
    attempt = await latest_cancelled_turn_attempt(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
    )
    if attempt is None:
        return state, "Nothing to continue (no cancelled run attempt)."
    return state, ReplActionContinue(use_last=True)


def edit_cmd(
    state: SessionState,
    _cmd: EditCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Switch UI into edit mode and set the correct anchor."""
    if not state.prompt.last_user_prompt:
        return state, "Nothing to edit."
    return state, ReplActionEditLast()


def clear_cmd(
    state: SessionState,
    _cmd: ClearCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Clear staged attachments and pending send state."""
    cleared = replace(
        state,
        attachments=replace(
            state.attachments,
            pending=(),
            next_send_use_last=False,
        ),
    )
    return cleared, "Cleared staged attachments."


__all__ = (
    "again_cmd",
    "attach_cmd",
    "attachments_show_cmd",
    "clear_cmd",
    "continue_cmd",
    "detach_all_cmd",
    "detach_path_cmd",
    "edit_cmd",
    "new_session_cmd",
    "session_runs_cmd",
    "sessions_list_cmd",
    "sessions_use_cmd",
)
