"""Artifact vault handlers for REPL slash commands."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING

import typer

from agenterm.artifacts.agent_run import load_agent_run_report
from agenterm.artifacts.repo import get_artifact_by_id, list_artifacts_recent
from agenterm.core.errors import DatabaseError, FilesystemError, ValidationError
from agenterm.core.json_codec import as_bool, as_str
from agenterm.core.platform import is_macos
from agenterm.store.session.service import session_store
from agenterm.ui.tool_events import shorten_line

if TYPE_CHECKING:
    from agenterm.commands.model import (
        ArtifactsAgentRunCmd,
        ArtifactsListCmd,
        ArtifactsOpenCmd,
        ArtifactsShowCmd,
    )
    from agenterm.core.json_types import JSONValue
    from agenterm.core.types import SessionState


async def artifacts_list_cmd(
    state: SessionState,
    cmd: ArtifactsListCmd,
) -> tuple[SessionState, str | None]:
    """List recent artifacts in the local vault."""
    limit = cmd.limit if cmd.limit is not None else 10
    rows = await list_artifacts_recent(store=session_store(), limit=limit)
    if not rows:
        return state.with_artifact_id_cache(()), "Artifacts: none yet."
    cache = tuple(r.artifact_id for r in rows)
    lines: list[str] = [f"Artifacts (latest {len(rows)}):"]
    lines.extend(
        f"- {r.artifact_id}  {r.kind}  {r.mime}  {r.size_bytes} bytes  "
        f"{r.created_at or '-'}"
        for r in rows
    )
    lines.append(
        "Tip: /artifacts show <ID> | /artifacts open <ID> | /artifacts agent-run <ID>"
    )
    return state.with_artifact_id_cache(cache), "\n".join(lines)


async def artifacts_show_cmd(
    state: SessionState,
    cmd: ArtifactsShowCmd,
) -> tuple[SessionState, str | None]:
    """Show one artifact record."""
    rec = await get_artifact_by_id(
        store=session_store(),
        artifact_id=cmd.artifact_id,
    )
    if rec is None:
        return state, f"Artifacts: no artifact with id {cmd.artifact_id!r}."
    lines: list[str] = [
        f"id: {rec.artifact_id}",
        f"kind: {rec.kind}",
        f"mime: {rec.mime}",
        f"bytes: {rec.size_bytes}",
        f"created_at: {rec.created_at or '-'}",
        f"source: {rec.source_type}:{rec.source_id}",
        f"session_id: {rec.session_id or '-'}",
        f"path: {rec.path}",
    ]
    return state, "\n".join(lines)


async def artifacts_open_cmd(
    state: SessionState,
    cmd: ArtifactsOpenCmd,
) -> tuple[SessionState, str | None]:
    """Open an artifact file (macOS only)."""
    if not is_macos():
        return state, "Artifacts: open is supported on macOS only."
    rec = await get_artifact_by_id(
        store=session_store(),
        artifact_id=cmd.artifact_id,
    )
    if rec is None:
        return state, f"Artifacts: no artifact with id {cmd.artifact_id!r}."
    path = Path(rec.path)
    if not await asyncio.to_thread(path.is_file):
        return state, f"Artifacts: file missing: {path}"
    typer.launch(str(path))
    return state, f"Opened: {path}"


def _parse_int_mapping(raw: JSONValue | None) -> dict[str, int] | None:
    if not isinstance(raw, dict):
        return None
    out: dict[str, int] = {}
    for key, value in raw.items():
        if not isinstance(value, int) or isinstance(value, bool):
            return None
        out[key] = int(value)
    return out


def _summary_map(raw: JSONValue | None) -> str | None:
    parsed = _parse_int_mapping(raw)
    if not parsed:
        return None
    parts = [
        f"{name} x{count}" if count > 1 else name
        for name, count in sorted(parsed.items())
    ]
    return ", ".join(parts) if parts else None


def _summary_list(raw: JSONValue | None, *, limit: int) -> str | None:
    if not isinstance(raw, list):
        return None
    items = [item for item in raw if isinstance(item, str) and item]
    if not items:
        return None
    return shorten_line(", ".join(items), limit=limit)


async def artifacts_agent_run_cmd(
    state: SessionState,
    cmd: ArtifactsAgentRunCmd,
) -> tuple[SessionState, str | None]:
    """Show an agent_run report artifact."""
    try:
        report = await load_agent_run_report(
            store=session_store(),
            artifact_id=cmd.artifact_id,
        )
    except (DatabaseError, FilesystemError, ValidationError) as exc:
        return state, f"Artifacts: failed to load agent_run report ({exc})."
    if report is None:
        return state, f"Artifacts: no agent_run report with id {cmd.artifact_id!r}."
    model = as_str(report.get("model")) or "-"
    created_at = as_str(report.get("created_at")) or "-"
    trace_id = as_str(report.get("trace_id")) or "-"
    response_id = as_str(report.get("response_id")) or "-"
    truncated = as_bool(report.get("truncated"))
    tool_counts = _summary_map(report.get("tool_counts")) or "-"
    usage = _summary_map(report.get("usage")) or "-"
    tools_available = _summary_list(report.get("tools_available"), limit=200) or "-"
    tools_used = _summary_list(report.get("tools_used"), limit=200) or "-"
    warnings = _summary_list(report.get("warnings"), limit=200) or "-"
    input_text = shorten_line(as_str(report.get("input")) or "", limit=160)
    instructions = shorten_line(as_str(report.get("instructions")) or "", limit=160)
    output_text = shorten_line(as_str(report.get("output_text")) or "", limit=200)
    input_items = report.get("input_items")
    output_items = report.get("output_items")
    response_ids = report.get("response_ids")
    response_count = len(response_ids) if isinstance(response_ids, list) else None
    input_items_count = len(input_items) if isinstance(input_items, list) else None
    output_items_count = len(output_items) if isinstance(output_items, list) else None
    output_items_value = (
        str(output_items_count) if output_items_count is not None else "-"
    )
    output_items_label = f"- output_items: {output_items_value}"
    lines = [
        f"agent_run report: {cmd.artifact_id}",
        f"- model: {model}",
        f"- created_at: {created_at}",
        f"- trace_id: {trace_id}",
        f"- response_id: {response_id}",
        f"- responses: {response_count if response_count is not None else '-'}",
        f"- truncated: {'true' if truncated else 'false'}",
        f"- tools: {tool_counts}",
        f"- tools_available: {tools_available}",
        f"- tools_used: {tools_used}",
        f"- warnings: {warnings}",
        f"- usage: {usage}",
        f"- input: {input_text or '-'}",
        f"- instructions: {instructions or '-'}",
        f"- output: {output_text or '-'}",
        f"- input_items: {input_items_count if input_items_count is not None else '-'}",
        output_items_label,
        "Tip: use /artifacts show <ID> for metadata or",
        "     /inspect agent-run <ID> [--json] for the full report.",
    ]
    return state, "\n".join(lines)


__all__ = (
    "artifacts_agent_run_cmd",
    "artifacts_list_cmd",
    "artifacts_open_cmd",
    "artifacts_show_cmd",
)
