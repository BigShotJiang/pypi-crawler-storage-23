"""Handlers for REPL UX toggles (/ux)."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.commands.model import (
        UxDiffsCmd,
        UxMarkdownCmd,
        UxReasoningCmd,
        UxShowCmd,
        UxStreamCmd,
        UxVerbosityCmd,
    )
    from agenterm.core.types import SessionState


def ux_show_cmd(
    state: SessionState,
    _cmd: UxShowCmd,
) -> tuple[SessionState, str | None]:
    """Show current UX toggles for the active REPL session."""
    lines = [
        "UX:",
        f"- markdown: {'on' if state.ui.render_markdown else 'off'}",
        f"- reasoning: {state.ui.reasoning_mode}",
        f"- reasoning_summary_max_chars: {state.ui.reasoning_summary_max_chars}",
        f"- diffs: {state.ui.diffs_mode}",
        f"- stream: {state.ui.stream_mode}",
        f"- verbosity: {state.ui.verbosity}",
    ]
    return state, "\n".join(lines)


def ux_markdown_cmd(
    state: SessionState,
    cmd: UxMarkdownCmd,
) -> tuple[SessionState, str | None]:
    """Toggle Markdown rendering for agent output in the REPL."""
    on = bool(cmd.on)
    new_state = replace(state, ui=replace(state.ui, render_markdown=on))
    hint = " (agent output will be rendered as styled Markdown)" if on else ""
    return new_state, f"Markdown: {'on' if on else 'off'}{hint}"


def ux_reasoning_cmd(
    state: SessionState,
    cmd: UxReasoningCmd,
) -> tuple[SessionState, str | None]:
    """Toggle reasoning summary blocks in the transcript."""
    new_state = replace(state, ui=replace(state.ui, reasoning_mode=cmd.mode))
    return new_state, f"Reasoning: {cmd.mode}"


def ux_diffs_cmd(
    state: SessionState,
    cmd: UxDiffsCmd,
) -> tuple[SessionState, str | None]:
    """Toggle diff artifacts in the transcript."""
    new_state = replace(state, ui=replace(state.ui, diffs_mode=cmd.mode))
    return new_state, f"Diffs: {cmd.mode}"


def ux_stream_cmd(
    state: SessionState,
    cmd: UxStreamCmd,
) -> tuple[SessionState, str | None]:
    """Set live vs final streaming mode for the REPL."""
    new_state = replace(state, ui=replace(state.ui, stream_mode=cmd.mode))
    return new_state, f"Stream mode: {cmd.mode}"


def ux_verbosity_cmd(
    state: SessionState,
    cmd: UxVerbosityCmd,
) -> tuple[SessionState, str | None]:
    """Set transcript verbosity for the REPL."""
    new_state = replace(state, ui=replace(state.ui, verbosity=cmd.mode))
    return new_state, f"Verbosity: {cmd.mode}"


__all__ = (
    "ux_diffs_cmd",
    "ux_markdown_cmd",
    "ux_reasoning_cmd",
    "ux_show_cmd",
    "ux_stream_cmd",
    "ux_verbosity_cmd",
)
