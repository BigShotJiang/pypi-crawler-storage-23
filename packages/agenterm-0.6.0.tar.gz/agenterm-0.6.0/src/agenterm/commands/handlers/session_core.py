"""Core session handlers: help, status, and exit."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.actions import ReplActionExit
from agenterm.commands.slash_help import render_help
from agenterm.config.paths import history_db_path, meta_store_path
from agenterm.core.choices.common import UNSET_MARKER
from agenterm.core.env import has_openai_api_key
from agenterm.core.platform import supports_shell_sandbox_platform
from agenterm.core.tool_selection import (
    ToolCatalog,
    resolve_selection,
    selected_mcp_server_configs,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.commands.actions import ReplAction
    from agenterm.commands.model import HelpCmd, QuitCmd, StatusCmd
    from agenterm.config.model import ToolsConfig
    from agenterm.core.types import SessionState


def exit_cmd(
    state: SessionState,
    _cmd: QuitCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Request application exit."""
    return state, ReplActionExit()


def help_cmd(
    state: SessionState,
    cmd: HelpCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Return help text: overview or topic-specific."""
    return state, render_help(cmd.topic)


def status_cmd(
    state: SessionState,
    _cmd: StatusCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Return a snapshot of effective session configuration."""
    s = state
    parts: list[str] = []
    sections = [
        _format_session_section(s),
        _format_agent_section(s),
        _format_run_section(s),
        _format_repl_section(s),
        _format_tools_section(s),
        _format_guardrails_section(s),
        _format_env_section(),
    ]
    for sec in sections:
        if not sec:
            continue
        if parts:
            parts.append("")
        parts.extend(sec)
    return state, "\n".join(parts)


def _format_session_section(s: SessionState) -> list[str]:
    """Build the core session summary lines for /status output."""
    lines: list[str] = ["Session:"]
    lines.append(f"- model: {s.cfg.agent.model}")
    store_flag = s.cfg.model.store
    store_label = "off" if store_flag is False else "on"
    lines.append(f"- store: {store_label}")
    verb = s.cfg.model.verbosity or UNSET_MARKER
    lines.append(f"- verbosity: {verb}")
    rea = s.cfg.model.reasoning
    if rea is None:
        eff = UNSET_MARKER
        summ = UNSET_MARKER
    else:
        eff = rea.effort or UNSET_MARKER
        summ = rea.summary or UNSET_MARKER
    lines.append(f"- reasoning: effort={eff}, summary={summ}")
    lines.append(f"- tools_enabled: {'on' if s.tools.enabled else 'off'}")
    inc_list: list[str] = list(s.tools.include_base or ())
    lines.append(f"- include: {', '.join(inc_list) if inc_list else '(none)'}")
    lines.append(f"- history_db: {history_db_path()}")
    lines.append(f"- meta_store: {meta_store_path()}")
    sid = s.session_id or "(none)"
    lines.append(f"- session_id: {sid}")
    bid = s.branch_id or "(none)"
    lines.append(f"- branch_id: {bid}")
    return lines


def _format_agent_section(s: SessionState) -> list[str]:
    """Summarize agent-level configuration (name, max_turns, config path)."""
    a = s.cfg.agent
    lines: list[str] = ["Agent:"]
    lines.append(f"- name: {a.name}")
    lines.append(f"- max_turns: {a.max_turns}")
    cfg_path = s.config_path
    if cfg_path is None:
        lines.append("- config_path: (defaults from code)")
    else:
        lines.append(f"- config_path: {cfg_path}")
    lines.append(f"- source: {a.source or '(none)'}")
    lines.append(f"- path: {a.path or '(none)'}")
    lines.append(f"- explicit: {'on' if a.explicit else 'off'}")
    return lines


def _format_run_section(s: SessionState) -> list[str]:
    """Summarize run defaults and tracing configuration."""
    r = s.cfg.run
    lines: list[str] = ["Run:"]
    lines.append(f"- background: {'on' if r.background else 'off'}")
    timeout = "none" if r.timeout_seconds is None else str(r.timeout_seconds)
    lines.append(f"- timeout_seconds (idle/no events): {timeout}")
    lines.append(f"- live: {'on' if r.live else 'off'}")
    lines.append(f"- json_output: {'on' if r.json_output else 'off'}")
    lines.append(f"- trace_enabled: {'on' if r.trace_enabled else 'off'}")
    lines.append(f"- trace_id: {r.trace_id or '(none)'}")
    lines.append(f"- group_id: {r.group_id or '(none)'}")
    if r.trace_metadata:
        keys = ", ".join(sorted(str(k) for k in r.trace_metadata))
        lines.append(f"- trace_metadata_keys: {keys}")
    else:
        lines.append("- trace_metadata_keys: (none)")
    lines.append(
        f"- trace_include_sensitive_data: "
        f"{'on' if r.trace_include_sensitive_data else 'off'}",
    )
    return lines


def _format_repl_section(s: SessionState) -> list[str]:
    """Summarize REPL-only defaults and interactive session toggles."""
    cfg = s.cfg.repl
    ui = cfg.ui
    lines: list[str] = ["REPL:"]

    eff_approvals = s.approvals.mode
    lines.append(
        f"- approvals_mode: {eff_approvals} (session, default={cfg.approvals.mode})",
    )
    markdown = "on" if s.ui.render_markdown else "off"
    markdown_default = "on" if cfg.ux.markdown else "off"
    lines.append(
        f"- markdown: {markdown} (session, default={markdown_default})",
    )
    lines.append(f"- theme: {s.ui.theme} (session, default={ui.theme})")
    lines.append(
        f"- color_depth: {s.ui.color_depth} (session, default={ui.color_depth})",
    )
    lines.append(
        f"- mouse: {'on' if s.ui.mouse else 'off'} "
        f"(session, default={'on' if ui.mouse else 'off'})",
    )
    lines.append(
        f"- completion: {s.ui.completion} (session, default={ui.completion})",
    )
    lines.append(
        f"- edit_mode: {s.ui.editing_mode} (session, default={ui.editing_mode})",
    )
    lines.append(
        f"- stream: {s.ui.stream_mode} (session, default={cfg.ux.stream})",
    )
    lines.append(
        f"- verbosity: {s.ui.verbosity} (session, default={cfg.ux.verbosity})",
    )
    return lines


def _builtin_flags(*, on: bool) -> str:
    return "on" if on else "off"


_BUILTIN_TOOL_ORDER: tuple[str, ...] = (
    "file_search",
    "web_search",
    "image_generation",
    "shell",
    "apply_patch",
    "plan",
)


def _builtin_selection_flags(selected_types: set[str]) -> dict[str, bool]:
    return {name: name in selected_types for name in _BUILTIN_TOOL_ORDER}


def _builtin_effective_flags(
    selected: Mapping[str, bool],
    tools_cfg: ToolsConfig,
) -> dict[str, bool]:
    return {
        "file_search": selected.get("file_search", False)
        and bool(tools_cfg.file_search and tools_cfg.file_search.vector_store_ids),
        "web_search": selected.get("web_search", False)
        and bool(tools_cfg.web_search is not None),
        "image_generation": selected.get("image_generation", False)
        and bool(tools_cfg.image_generation is not None),
        "shell": selected.get("shell", False)
        and bool(tools_cfg.shell is not None)
        and supports_shell_sandbox_platform(),
        "apply_patch": selected.get("apply_patch", False)
        and bool(tools_cfg.apply_patch is not None),
        "plan": selected.get("plan", False) and bool(tools_cfg.plan is not None),
    }


def _format_builtin_flags(flags: Mapping[str, bool]) -> str:
    parts = [
        f"{name}={_builtin_flags(on=bool(flags.get(name, False)))}"
        for name in _BUILTIN_TOOL_ORDER
    ]
    return " ".join(parts)


def _format_builtin_lines(
    *,
    tools_enabled: bool,
    selected_types: set[str],
    tools_cfg: ToolsConfig,
) -> list[str]:
    if not tools_enabled:
        return ["- builtin: (disabled by tools gate)"]
    selected = _builtin_selection_flags(selected_types)
    effective = _builtin_effective_flags(selected, tools_cfg)
    return [
        f"- builtin_selected: {_format_builtin_flags(selected)}",
        f"- builtin_effective: {_format_builtin_flags(effective)}",
    ]


def _format_tools_section(s: SessionState) -> list[str]:
    """Summarize tools, bundles, and MCP configuration."""
    lines: list[str] = ["Tools:"]
    lines.append(f"- gate: {'on' if s.tools.enabled else 'off'}")
    tools_cfg = s.cfg.tools
    catalog = ToolCatalog(
        tools_map=s.tools.tools_map or {},
        bundles_map=s.tools.bundles_map or {},
        default_bundles=list(s.tools.default_bundles or []),
    )
    resolved = resolve_selection(s.tools.selection, catalog=catalog)
    specs = list(resolved.specs) if resolved.error is None else []
    selected_types = {spec.type for spec in specs}
    selected_mcp_servers = selected_mcp_server_configs(specs)

    connectors_total = len(s.cfg.mcp.connectors)
    connectors_selected = len([spec for spec in specs if spec.type == "hosted_mcp"])
    lines.extend(
        _format_builtin_lines(
            tools_enabled=s.tools.enabled,
            selected_types=selected_types,
            tools_cfg=tools_cfg,
        ),
    )
    if not connectors_total:
        lines.append("- mcp_connectors: (none configured)")
    elif not s.tools.enabled:
        lines.append(
            f"- mcp_connectors: {connectors_total} configured (disabled by tools gate)",
        )
    else:
        lines.append(
            f"- mcp_connectors: {connectors_selected}/{connectors_total} selected "
            "(always dangerous)",
        )
    bundles = s.tools.bundles_map or {}
    sel = s.tools.selection
    selected_bundles = (
        ", ".join(sel.selected_bundles) if sel.selected_bundles else "(none)"
    )
    default_bundles = (
        ", ".join(s.tools.default_bundles) if s.tools.default_bundles else "(none)"
    )
    lines.append(f"- bundles_selected: {selected_bundles}")
    lines.append(f"- default_bundles: {default_bundles}")
    lines.append(f"- bundles_defined: {', '.join(sorted(bundles.keys())) or '(none)'}")
    servers_cfg = s.cfg.mcp.servers
    lines.append(f"- mcp_servers_configured: {len(servers_cfg)}")
    if s.tools.enabled and selected_mcp_servers:
        pending = "on" if s.mcp.refresh_pending else "off"
        lines.append(
            f"- mcp_selected: {len(selected_mcp_servers)} server(s), "
            f"{len(s.mcp.tool_names)} tool name(s) discovered, "
            f"status={s.mcp.discovery_status}, refresh_pending={pending}",
        )
        if s.mcp.discovery_status == "error" and s.mcp.discovery_error:
            lines.append(f"- mcp_discovery_error: {s.mcp.discovery_error}")
    else:
        lines.append("- mcp_selected: (none)")
    return lines


def _format_guardrails_section(s: SessionState) -> list[str]:
    """Summarize configured guardrails by name."""
    g = s.cfg.guardrails
    lines: list[str] = ["Guardrails:"]
    inp = ", ".join(g.input) if g.input else "(none)"
    out = ", ".join(g.output) if g.output else "(none)"
    lines.append(f"- input: {inp}")
    lines.append(f"- output: {out}")
    return lines


def _format_env_section() -> list[str]:
    """Summarize environment-level status (API key)."""
    lines: list[str] = ["Environment:"]
    lines.append(f"- api_key: {'present' if has_openai_api_key() else 'missing'}")
    return lines


__all__ = ("exit_cmd", "help_cmd", "status_cmd")
