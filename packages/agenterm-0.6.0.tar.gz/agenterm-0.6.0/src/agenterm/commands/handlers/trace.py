"""Trace handlers for REPL slash commands."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.commands.model import TraceEnabledCmd
    from agenterm.core.types import SessionState


def trace_show(state: SessionState) -> tuple[SessionState, str | None]:
    """Show effective tracing configuration for the current session.

    This surfaces the values that ultimately flow into RunConfig:
      - trace_enabled
      - trace_id
      - group_id
      - trace_metadata keys
      - trace_include_sensitive_data flag
    """
    r = state.cfg.run
    lines: list[str] = ["Trace:"]
    lines.append(f"- enabled: {'on' if r.trace_enabled else 'off'}")
    lines.append(f"- trace_id: {r.trace_id or '(none)'}")
    lines.append(f"- group_id: {r.group_id or '(none)'}")
    if r.trace_metadata:
        keys = ", ".join(sorted(str(k) for k in r.trace_metadata))
        lines.append(f"- metadata_keys: {keys}")
    else:
        lines.append("- metadata_keys: (none)")
    lines.append(
        f"- include_sensitive_data: "
        f"{'on' if r.trace_include_sensitive_data else 'off'}",
    )
    return state, "\n".join(lines)


def trace_clear(state: SessionState) -> tuple[SessionState, str | None]:
    """Clear trace_id, group_id, and trace_metadata for this session.

    This does not affect config on disk; it only updates the in-memory
    AppConfig snapshot attached to the session.
    """
    r = state.cfg.run
    r2 = replace(r, trace_id=None, group_id=None, trace_metadata=None)
    cfg2 = replace(state.cfg, run=r2)
    new_state = state.with_cfg(cfg2)
    return new_state, "Trace: cleared trace_id, group_id, and metadata."


def trace_toggle(
    state: SessionState,
    cmd: TraceEnabledCmd,
) -> tuple[SessionState, str | None]:
    """Enable or disable tracing for the current session."""
    r = state.cfg.run
    r2 = replace(r, trace_enabled=bool(cmd.enabled))
    cfg2 = replace(state.cfg, run=r2)
    new_state = state.with_cfg(cfg2)
    label = "on" if cmd.enabled else "off"
    return new_state, f"Trace: {label}."


__all__ = ("trace_clear", "trace_show", "trace_toggle")
