"""Trace command models for REPL slash commands."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TraceShowCmd:
    """Show effective trace settings for the session."""


@dataclass(frozen=True)
class TraceClearCmd:
    """Clear trace identifiers and metadata."""


@dataclass(frozen=True)
class TraceEnabledCmd:
    """Enable or disable tracing for this session."""

    enabled: bool


__all__ = ("TraceClearCmd", "TraceEnabledCmd", "TraceShowCmd")
