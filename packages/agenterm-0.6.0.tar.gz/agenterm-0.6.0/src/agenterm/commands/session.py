"""Session CLI commands."""

from __future__ import annotations

import asyncio
import sqlite3
from types import MappingProxyType
from typing import Annotated

import typer

from agenterm.cli.options import BranchOption, FormatOption
from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output import emit_result as emit_cli_result
from agenterm.cli.output_format import OutputFormat
from agenterm.commands.session_runs_view import build_session_runs_payload
from agenterm.core.cli_payloads import (
    BranchMetaPayload,
    SessionDeletePayload,
    SessionListPayload,
    SessionMetadataPayload,
    SessionSummaryPayload,
)
from agenterm.core.error_report import (
    ErrorContext,
    build_error_report,
    build_message_report,
)
from agenterm.core.errors import DatabaseError, FilesystemError
from agenterm.store.branch.repo import get_branch_meta
from agenterm.store.history import history_store
from agenterm.store.session.service import (
    delete_session_metadata,
    get_session_metadata_row,
    last_message_snippets_by_branch,
    list_session_metadata,
    session_store,
    session_usage_totals,
)
from agenterm.ui.cli_renderer import render_notice

_DEFAULT_BOOL = False

session_app = typer.Typer(
    name="session",
    help="View and manage stored sessions.",
    no_args_is_help=True,
    epilog=(
        "Commands:\n"
        "  list    Show all sessions\n"
        "  show    View session metadata\n"
        "  runs    View run history\n"
        "  delete  Remove a session\n"
    ),
)


def _context(resource: str) -> ErrorContext:
    return ErrorContext(operation=resource, resource=resource, trace_id=None)


@session_app.command("list")
def list_sessions(
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Show all sessions in local store."""
    store = session_store()
    history = history_store()

    async def _load() -> tuple[SessionSummaryPayload, ...]:
        rows = await list_session_metadata(store)
        summaries: list[SessionSummaryPayload] = []
        for meta in rows:
            head_meta = await get_branch_meta(
                store,
                meta.session_id,
                meta.head_branch_id,
            )
            if head_meta is None:
                msg = f"Missing head branch metadata for session {meta.session_id!r}"
                raise DatabaseError(msg)
            snippets = await last_message_snippets_by_branch(
                store=history,
                session_id=meta.session_id,
                branch_ids=[meta.head_branch_id],
            )
            last_message = snippets.get(meta.head_branch_id)
            summaries.append(
                SessionSummaryPayload(
                    session_id=meta.session_id,
                    kind=meta.kind or "",
                    model=meta.model or "",
                    head_branch_id=meta.head_branch_id,
                    store_enabled=head_meta.store_enabled,
                    last_response_id=head_meta.last_response_id,
                    last_message_role=(
                        last_message.role if last_message is not None else None
                    ),
                    last_message_snippet=(
                        last_message.snippet if last_message is not None else None
                    ),
                    created_at=meta.created_at,
                    updated_at=meta.updated_at,
                ),
            )
        return tuple(summaries)

    try:
        summaries = asyncio.run(_load())
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=_context("session.list"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=_context("session.list"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    payload = SessionListPayload(sessions=summaries)
    emit_cli_result(
        output_format=output_format,
        resource="session.list",
        payload=payload,
        trace_id=None,
    )


@session_app.command("show")
def show_session(
    session_id: str,
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """View metadata for a session."""
    store = session_store()
    try:
        meta = asyncio.run(get_session_metadata_row(store, session_id))
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=_context("session.show"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=_context("session.show"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    if meta is None:
        report = build_message_report(
            kind="not_found",
            message=f"Session not found: {session_id}",
            context=_context("session.show"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1)

    head_meta = asyncio.run(
        get_branch_meta(store, session_id, meta.head_branch_id),
    )
    if head_meta is None:
        report = build_error_report(
            DatabaseError(
                f"Missing head branch metadata for session {session_id!r}",
            ),
            context=_context("session.show"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1)

    totals = asyncio.run(
        session_usage_totals(
            store=store,
            session_id=session_id,
            branch_id=meta.head_branch_id,
        ),
    )
    totals_map = totals.to_mapping() if totals is not None else None

    usage_total = MappingProxyType(dict(totals_map)) if totals_map is not None else None
    payload = SessionMetadataPayload(
        session_id=meta.session_id,
        kind=meta.kind,
        cwd=meta.cwd,
        config_path=meta.config_path,
        model=meta.model,
        tools_enabled=bool(meta.tools_enabled),
        trace_id=meta.trace_id,
        group_id=meta.group_id,
        head_branch_id=meta.head_branch_id,
        head_branch=BranchMetaPayload(
            branch_id=head_meta.branch_id,
            kind=head_meta.kind,
            title=head_meta.title,
            pinned=head_meta.pinned,
            created_reason=head_meta.created_reason,
            parent_branch_id=head_meta.parent_branch_id,
            fork_run_number=head_meta.fork_run_number,
            agent_name=head_meta.agent_name,
            agent_path=head_meta.agent_path,
            agent_sha256=head_meta.agent_sha256,
            store_enabled=head_meta.store_enabled,
            last_response_id=head_meta.last_response_id,
        ),
        created_at=meta.created_at,
        updated_at=meta.updated_at,
        usage_total=usage_total,
    )
    emit_cli_result(
        output_format=output_format,
        resource="session.show",
        payload=payload,
        trace_id=None,
    )


@session_app.command("runs")
def show_session_runs(
    session_id: str,
    *,
    output_format: FormatOption = OutputFormat.human,
    branch: BranchOption = None,
) -> None:
    """Show run history for a session."""
    try:
        payload = asyncio.run(
            build_session_runs_payload(
                session_id,
                branch_id=branch,
            ),
        )
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(
            exc,
            context=_context("session.runs"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=_context("session.runs"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    if payload is None:
        report = build_message_report(
            kind="not_found",
            message=f"Session not found: {session_id}",
            context=_context("session.runs"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1)
    emit_cli_result(
        output_format=output_format,
        resource="session.runs",
        payload=payload,
        trace_id=None,
    )


@session_app.command("delete")
def delete_session(
    session_id: str,
    *,
    output_format: FormatOption = OutputFormat.human,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation"),
    ] = _DEFAULT_BOOL,
) -> None:
    """Remove a session from local store."""
    store = session_store()

    try:
        meta = asyncio.run(get_session_metadata_row(store, session_id))
    except (FilesystemError, DatabaseError) as exc:
        report = build_error_report(exc, context=_context("session.delete"))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    except sqlite3.Error as exc:
        report = build_error_report(
            DatabaseError(str(exc)),
            context=_context("session.delete"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc
    if meta is None:
        report = build_message_report(
            kind="not_found",
            message=f"Session not found: {session_id}",
            context=_context("session.delete"),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1)

    if output_format is OutputFormat.json and not force:
        report = build_message_report(
            kind="usage_error",
            message="Session delete requires --force in --format json mode.",
            context=_context("session.delete"),
            extra_details={"session_id": session_id},
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2)

    if not force:
        render_notice(
            title="Confirm Delete",
            message=(
                f"Session: {meta.session_id}\n"
                f"Model: {meta.model}\n"
                f"Created: {meta.created_at}"
            ),
            style="warn",
        )
        if not typer.confirm("Delete?"):
            raise typer.Exit(0)

    deleted = asyncio.run(delete_session_metadata(store, session_id))
    emit_cli_result(
        output_format=output_format,
        resource="session.delete",
        payload=SessionDeletePayload(session_id=session_id, deleted=bool(deleted)),
        trace_id=None,
    )


__all__ = ("session_app",)
