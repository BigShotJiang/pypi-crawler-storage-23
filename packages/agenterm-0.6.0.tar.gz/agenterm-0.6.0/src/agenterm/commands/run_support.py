"""Helpers for rendering and envelopes used by the `run` command."""

from __future__ import annotations

import io
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output import emit_result as emit_cli_result
from agenterm.core.cli_payloads import ArtifactSummaryPayload
from agenterm.core.envelope import RunPayload
from agenterm.engine import (
    extract_final_text,
    summarize_tools_counts,
    summarize_usage_details,
)
from agenterm.engine.artifacts import resolve_image_artifacts
from agenterm.store.session.service import session_store

if TYPE_CHECKING:
    from agents.items import TResponseInputItem
    from agents.result import RunResultBase

    from agenterm.cli.output_format import OutputFormat
    from agenterm.core.error_report import ErrorReport


@dataclass(frozen=True)
class RunModes:
    """Resolved rendering and output modes for a run invocation."""

    live: bool
    output_format: OutputFormat


@dataclass(frozen=True)
class RunInputBundle:
    """Normalized prompt/input payload plus attachments."""

    prompt: str
    attachments: tuple[str, ...]
    input_items: list[TResponseInputItem]


def emit_error(*, output_format: OutputFormat, report: ErrorReport) -> None:
    """Emit an error envelope in text or JSON form."""
    emit_cli_error(output_format=output_format, report=report)


async def build_payload(
    result: RunResultBase,
    *,
    attachments: tuple[str, ...],
    session_id: str | None,
    mode: str,
    background: bool,
) -> RunPayload:
    """Construct a success payload from a run result."""
    usage_details = summarize_usage_details(result)
    resolution = await resolve_image_artifacts(
        store=session_store(),
        items=[item.to_input_item() for item in result.new_items],
    )
    artifacts = [
        ArtifactSummaryPayload(
            artifact_id=rec.artifact_id,
            kind=rec.kind,
            mime=rec.mime,
            path=rec.path,
            size_bytes=rec.size_bytes,
            created_at=rec.created_at,
            source_type=rec.source_type,
            source_id=rec.source_id,
            session_id=rec.session_id,
        )
        for rec in resolution.records
    ]
    return RunPayload(
        mode=mode,
        background=background,
        text=extract_final_text(result) or "",
        attachments=attachments,
        artifacts=tuple(artifacts),
        tools=summarize_tools_counts(result),
        response_id=result.last_response_id,
        session_id=session_id,
        usage=usage_details,
    )


def render_success(
    *,
    payload: RunPayload,
    modes: RunModes,
    trace_id: str | None,
) -> int:
    """Render a successful run result in JSON or human form."""
    emit_cli_result(
        output_format=modes.output_format,
        resource="run",
        payload=payload,
        trace_id=trace_id,
    )
    return 0


def stdin_is_tty() -> bool:
    """Return True when stdin is a TTY or unknown."""
    try:
        return sys.stdin.isatty()
    except (io.UnsupportedOperation, AttributeError, ValueError, OSError):
        return True


def resolve_source(
    *,
    prompts: list[str] | None,
    file: Path | None,
) -> tuple[str, str | list[str] | Path | None] | None:
    """Resolve input source preference among prompts/file/stdin."""
    has_prompts = bool(prompts and len(prompts) > 0)
    has_file = isinstance(file, Path)
    has_stdin = (not stdin_is_tty()) and (not has_prompts) and (not has_file)

    count = sum([has_prompts, has_file, has_stdin])
    if count == 0:
        return None
    if count > 1:
        return ("error", "multiple")
    if prompts and len(prompts) > 0:
        prom_list: list[str] = [str(x) for x in prompts]
        return ("prompts", prom_list)
    if has_file:
        return ("file", file)
    return ("stdin", None)


def detect_execution_mode(
    prompts: list[str] | None,
    file: Path | None,
) -> str | None:
    """Detect execution mode from input presence and TTY status.

    Returns:
        "repl" - Interactive mode (no input + TTY)
        "run" - One-shot mode (input present)
        None - Error (no input + non-TTY)

    """
    source = resolve_source(prompts=prompts, file=file)
    if source is not None:
        return "run"
    if stdin_is_tty():
        return "repl"
    return None
