"""MCP server commands."""

from __future__ import annotations

import asyncio
import pathlib
from dataclasses import dataclass
from types import MappingProxyType
from typing import TYPE_CHECKING, Annotated

import typer

from agenterm.app.services import load_base_app_config
from agenterm.cli.options import ConfigOption, FormatOption
from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output import emit_result as emit_cli_result
from agenterm.cli.output_format import OutputFormat
from agenterm.core.cli_payloads import (
    McpInspectPayload,
    McpServersPayload,
    McpToolsPayload,
    McpToolSummary,
)
from agenterm.core.error_report import (
    ErrorContext,
    build_error_report,
    build_message_report,
)
from agenterm.core.errors import ConfigError, FilesystemError
from agenterm.core.json_codec import dumps_pretty
from agenterm.engine.mcp_diagnostics import (
    build_mcp_status_snapshot,
    list_tools_for_servers,
)
from agenterm.engine.mcp_expose import serve_mcp_expose

if TYPE_CHECKING:
    from collections.abc import Mapping, MutableMapping, Sequence

    from mcp import types as mtypes

    from agenterm.config.model import AppConfig, McpServerConfig
    from agenterm.core.json_types import JSONMapping, JSONValue

mcp_app = typer.Typer(
    name="mcp",
    help="MCP server diagnostics and tool discovery",
    no_args_is_help=True,
    rich_markup_mode="rich",
    epilog=(
        "Commands:\n\n"
        "  status    Show connection status\n\n"
        "  servers   List configured servers\n\n"
        "  tools     List discovered tools\n\n"
        "  validate  Test server connections\n\n"
        "  inspect   Export tool definitions\n\n"
        "  serve     Run agenterm as an MCP server"
    ),
)


def _context(resource: str, trace_id: str | None) -> ErrorContext:
    return ErrorContext(operation=resource, resource=resource, trace_id=trace_id)


def _load_config_or_exit(
    *,
    config: pathlib.Path | None,
    output_format: OutputFormat,
) -> AppConfig:
    try:
        return load_base_app_config(config)
    except (ConfigError, FilesystemError) as exc:
        report = build_error_report(exc, context=_context("mcp.config", None))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc


@mcp_app.command("servers")
def servers_cmd(
    *,
    config: ConfigOption = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """List configured MCP servers from config.yaml."""
    cfg = _load_config_or_exit(config=config, output_format=output_format)
    servers = cfg.mcp.servers
    payload = McpServersPayload(
        servers=tuple(
            MappingProxyType(
                {"key": sc.key, "kind": str(sc.kind), "name": sc.name},
            )
            for sc in servers
        ),
    )
    emit_cli_result(
        output_format=output_format,
        resource="mcp.servers",
        payload=payload,
        trace_id=cfg.run.trace_id,
    )


@mcp_app.command("serve")
def serve_cmd(
    *,
    config: ConfigOption = None,
) -> None:
    """Expose local FunctionTools via a FastMCP server."""
    cfg = _load_config_or_exit(config=config, output_format=OutputFormat.human)

    async def _inner() -> None:
        await serve_mcp_expose(cfg, workspace_root=pathlib.Path.cwd())

    try:
        asyncio.run(_inner())
    except (ConfigError, FilesystemError) as exc:
        report = build_error_report(exc, context=_context("mcp.serve", None))
        emit_cli_error(output_format=OutputFormat.human, report=report)
        raise typer.Exit(2) from exc


def _extract_label(public_name: str) -> str | None:
    name = public_name.removeprefix("mcp__")
    if "__" not in name:
        return None
    head, _ = name.split("__", 1)
    return head or None


def _names_for_server(
    tools: Mapping[str, mtypes.Tool],
    server: str | None,
) -> list[str]:
    names = sorted(tools.keys())
    if server is None:
        return names
    return [n for n in names if _extract_label(n) == server]


def _payload_for_names(
    names: list[str],
    tools: Mapping[str, mtypes.Tool],
) -> list[dict[str, JSONValue]]:
    payload: list[dict[str, JSONValue]] = []
    for n in names:
        t = tools[n]
        ann = t.annotations
        title = ann.title if ann is not None and ann.title is not None else None
        desc = t.description or ""
        payload.append(
            {
                "name": n,
                "description": desc,
                "title": title,
                "has_output_schema": t.outputSchema is not None,
            },
        )
    return payload


def _payload_str(payload: Mapping[str, JSONValue], key: str) -> str | None:
    value = payload.get(key)
    return value if isinstance(value, str) else None


def _write_json(path: pathlib.Path, payload: Sequence[JSONMapping]) -> None:
    target = path
    try:
        _ = target.write_text(
            dumps_pretty(
                [dict(item) for item in payload],
                indent=2,
                ensure_ascii=False,
                context="mcp.inspect.write_json",
            ),
            encoding="utf-8",
        )
    except OSError as e:
        raise FilesystemError(str(e)) from e


@mcp_app.command("validate")
def validate_cmd(
    *,
    config: ConfigOption = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Test MCP server connections and report tool counts."""
    cfg = _load_config_or_exit(config=config, output_format=output_format)
    servers = tuple(cfg.mcp.servers)
    if not servers:
        report = build_message_report(
            kind="config_error",
            message="No MCP servers configured.",
            context=_context("mcp.validate", cfg.run.trace_id),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2)

    async def _inner() -> int:
        snapshot = await build_mcp_status_snapshot(servers)
        emit_cli_result(
            output_format=output_format,
            resource="mcp.validate",
            payload=snapshot,
            trace_id=cfg.run.trace_id,
        )
        return 2 if snapshot.has_errors() else 0

    raise typer.Exit(asyncio.run(_inner()))


def _summaries_for_tools(
    tools: Mapping[str, mtypes.Tool],
) -> tuple[McpToolSummary, ...]:
    summaries: list[McpToolSummary] = []
    for name, tool in sorted(tools.items()):
        ann = tool.annotations
        title = ann.title if ann is not None and ann.title is not None else None
        desc = tool.description or ""
        summaries.append(
            McpToolSummary(
                name=name,
                description=desc,
                title=title,
                has_output_schema=tool.outputSchema is not None,
            ),
        )
    return tuple(summaries)


@dataclass(frozen=True)
class _InspectResult:
    names: list[str]
    payload_dicts: list[dict[str, JSONValue]]
    tools_summary: tuple[McpToolSummary, ...]


async def _build_inspect_result(
    *,
    servers_cfg: tuple[McpServerConfig, ...],
    server_filter: str | None,
) -> _InspectResult | None:
    tools_by_server = await list_tools_for_servers(servers_cfg)
    if server_filter is not None and server_filter not in tools_by_server:
        return None
    merged: MutableMapping[str, mtypes.Tool] = {}
    for key, tools in tools_by_server.items():
        if server_filter is not None and key != server_filter:
            continue
        merged.update(tools)
    if not merged:
        return None

    names = _names_for_server(merged, server=None)
    payload_dicts = _payload_for_names(names, merged)
    tools_summary = tuple(
        McpToolSummary(
            name=str(p.get("name", "")),
            description=str(p.get("description", "")),
            title=_payload_str(p, "title"),
            has_output_schema=bool(p.get("has_output_schema", False)),
        )
        for p in payload_dicts
    )
    return _InspectResult(
        names=names,
        payload_dicts=payload_dicts,
        tools_summary=tools_summary,
    )


def _write_inspect_file_or_exit(
    *,
    out: pathlib.Path,
    payload_dicts: list[dict[str, JSONValue]],
    output_format: OutputFormat,
    trace_id: str | None,
) -> None:
    try:
        _write_json(out, payload_dicts)
    except FilesystemError as exc:
        report = build_error_report(
            exc,
            context=_context("mcp.inspect", trace_id),
            extra_details={"out_path": str(out)},
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc


@mcp_app.command("tools")
def tools_cmd(
    *,
    config: ConfigOption = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """List all discovered MCP tools grouped by server."""
    cfg = _load_config_or_exit(config=config, output_format=output_format)
    servers_cfg = tuple(cfg.mcp.servers)
    if not servers_cfg:
        emit_cli_result(
            output_format=output_format,
            resource="mcp.tools",
            payload=McpToolsPayload(
                tools_by_server=MappingProxyType({}),
                total_tools=0,
            ),
            trace_id=cfg.run.trace_id,
        )
        return

    async def _inner() -> None:
        tools_by_server = await list_tools_for_servers(servers_cfg)
        tools_payload = MappingProxyType(
            {
                server_key: _summaries_for_tools(tools)
                for server_key, tools in tools_by_server.items()
            },
        )
        total = sum(len(t) for t in tools_payload.values())
        emit_cli_result(
            output_format=output_format,
            resource="mcp.tools",
            payload=McpToolsPayload(tools_by_server=tools_payload, total_tools=total),
            trace_id=cfg.run.trace_id,
        )

    asyncio.run(_inner())


@mcp_app.command("status")
def status_cmd(
    *,
    config: ConfigOption = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Show MCP server connection status and tool counts."""
    cfg = _load_config_or_exit(config=config, output_format=output_format)
    servers = tuple(cfg.mcp.servers)

    async def _inner() -> int:
        snapshot = await build_mcp_status_snapshot(servers)
        emit_cli_result(
            output_format=output_format,
            resource="mcp.status",
            payload=snapshot,
            trace_id=cfg.run.trace_id,
        )
        return 2 if snapshot.has_errors() else 0

    code = asyncio.run(_inner())
    raise typer.Exit(code)


@mcp_app.command("inspect")
def inspect_cmd(
    *,
    config: ConfigOption = None,
    output_format: FormatOption = OutputFormat.human,
    server: Annotated[
        str | None,
        typer.Option("--server", help="Filter by server key"),
    ] = None,
    out: Annotated[
        pathlib.Path | None,
        typer.Option(
            "--out",
            help="Write tools to JSON file",
            file_okay=True,
            dir_okay=False,
            resolve_path=True,
        ),
    ] = None,
) -> None:
    """Export tool definitions as JSON."""
    cfg = _load_config_or_exit(config=config, output_format=output_format)
    servers_cfg = tuple(cfg.mcp.servers)
    if not servers_cfg:
        report = build_message_report(
            kind="config_error",
            message="No MCP servers configured.",
            context=_context("mcp.inspect", cfg.run.trace_id),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2)
    result = asyncio.run(
        _build_inspect_result(
            servers_cfg=servers_cfg,
            server_filter=server,
        ),
    )
    if result is None:
        emit_cli_result(
            output_format=output_format,
            resource="mcp.inspect",
            payload=McpInspectPayload(tools=(), out_path=None),
            trace_id=cfg.run.trace_id,
        )
        return

    out_path_str: str | None = str(out) if out is not None else None
    if out is not None:
        _write_inspect_file_or_exit(
            out=out,
            payload_dicts=result.payload_dicts,
            output_format=output_format,
            trace_id=cfg.run.trace_id,
        )

    emit_cli_result(
        output_format=output_format,
        resource="mcp.inspect",
        payload=McpInspectPayload(
            tools=result.tools_summary,
            out_path=out_path_str,
        ),
        trace_id=cfg.run.trace_id,
    )
