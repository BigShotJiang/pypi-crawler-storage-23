"""Typed command models for REPL slash commands and CLI dispatch."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from agenterm.commands.model_repl_ui import (
    ReplColorDepthCmd,
    ReplCompletionCmd,
    ReplEditingModeCmd,
    ReplMouseCmd,
    ReplShowCmd,
    ReplThemeCmd,
)
from agenterm.commands.model_session import (
    BranchDeleteCmd,
    BranchForkCmd,
    BranchListCmd,
    BranchNewCmd,
    BranchRunsCmd,
    BranchUseCmd,
    NewSessionCmd,
    SessionRunsCmd,
    SessionsListCmd,
    SessionsUseCmd,
)
from agenterm.commands.model_trace import TraceClearCmd, TraceEnabledCmd, TraceShowCmd

if TYPE_CHECKING:
    from agenterm.core.choices.approvals import ApprovalMode
    from agenterm.core.choices.repl import (
        ReplDiffsMode,
        ReplReasoningMode,
        ReplStreamMode,
        ReplVerbosity,
    )


@dataclass(frozen=True)
class ModelCmd:
    """Set the active model identifier."""

    model: str


@dataclass(frozen=True)
class ModelPickCmd:
    """Open the route-first model picker modal."""

    route: str | None = None


@dataclass(frozen=True)
class VerbosityCmd:
    """Set verbosity level; None clears to default."""

    level: str | None  # None means unset


@dataclass(frozen=True)
class ReasoningUnsetCmd:
    """Clear reasoning settings to defaults."""


@dataclass(frozen=True)
class ReasoningEffortCmd:
    """Adjust reasoning effort; None clears."""

    effort: str | None  # None means unset


@dataclass(frozen=True)
class ReasoningSummaryCmd:
    """Update reasoning summary; None clears."""

    summary: str | None  # None means unset


@dataclass(frozen=True)
class AgainCmd:
    """Re-run the last prompt verbatim."""


@dataclass(frozen=True)
class ContinueCmd:
    """Continue after a cancelled/timeout run without resending the full prompt."""


@dataclass(frozen=True)
class EditCmd:
    """Edit the last prompt before re-running."""


@dataclass(frozen=True)
class ClearCmd:
    """Clear staged attachments and cancel pending send state."""


@dataclass(frozen=True)
class StatusCmd:
    """Show current session status."""


@dataclass(frozen=True)
class ErrorsCmd:
    """Show captured stderr/logging lines from the REPL error buffer."""


type LastArtifactKind = Literal["diff", "tools", "approvals"]
type LastArtifactMode = Literal["preview", "full"]


@dataclass(frozen=True)
class LastCmd:
    """Show the most recent captured artifacts in the REPL."""

    kind: LastArtifactKind
    mode: LastArtifactMode = "preview"


@dataclass(frozen=True)
class HelpCmd:
    """Show available slash commands or help for a specific command."""

    topic: str | None = None


@dataclass(frozen=True)
class QuitCmd:
    """Exit the REPL."""


@dataclass(frozen=True)
class UsageCmd:
    """Emit a plain usage/help message."""

    msg: str


@dataclass(frozen=True)
class AgentCmd:
    """Switch the active agent by name."""

    name: str


@dataclass(frozen=True)
class AgentShowCmd:
    """Show the current effective agent."""


@dataclass(frozen=True)
class AgentListCmd:
    """List available agents."""


@dataclass(frozen=True)
class AttachCmd:
    """Attach a file or URL for the next run."""

    path: str


@dataclass(frozen=True)
class AttachmentsShowCmd:
    """Show staged and last-used attachments for the REPL session."""


@dataclass(frozen=True)
class DetachAllCmd:
    """Unstage all pending attachments for the next send."""


@dataclass(frozen=True)
class DetachPathCmd:
    """Unstage a single pending attachment for the next send."""

    path: str


@dataclass(frozen=True)
class CompressCmd:
    """Create a compression continuation for the active session."""


@dataclass(frozen=True)
class CompressShowCmd:
    """Show the most recent compression continuation for the active session."""


@dataclass(frozen=True)
class ArtifactsListCmd:
    """List recent artifacts from the local artifact vault."""

    limit: int | None = None


@dataclass(frozen=True)
class ArtifactsShowCmd:
    """Show one artifact record by id."""

    artifact_id: str


@dataclass(frozen=True)
class ArtifactsOpenCmd:
    """Open an artifact file by id (platform-dependent)."""

    artifact_id: str


@dataclass(frozen=True)
class ArtifactsAgentRunCmd:
    """Show an agent_run report artifact by id."""

    artifact_id: str


@dataclass(frozen=True)
class InspectAgentRunCmd:
    """Inspect an agent_run report by id."""

    report_id: str
    json_output: bool = False


@dataclass(frozen=True)
class ToolsAddBundleCmd:
    """Add one or more tool bundles to the selection."""

    names: list[str]


@dataclass(frozen=True)
class ToolsRemoveBundleCmd:
    """Remove tool bundles from the selection."""

    names: list[str]


@dataclass(frozen=True)
class ToolsAddToolCmd:
    """Add specific tool keys to the selection."""

    keys: list[str]


@dataclass(frozen=True)
class ToolsRemoveToolCmd:
    """Remove specific tool keys from the selection."""

    keys: list[str]


@dataclass(frozen=True)
class ToolsResetCmd:
    """Reset tools selection to startup defaults."""


@dataclass(frozen=True)
class UxShowCmd:
    """Show current REPL UX toggle values."""


@dataclass(frozen=True)
class UxMarkdownCmd:
    """Toggle Markdown rendering for agent output in the REPL."""

    on: bool


@dataclass(frozen=True)
class UxReasoningCmd:
    """Toggle reasoning summary display in the REPL transcript."""

    mode: ReplReasoningMode


@dataclass(frozen=True)
class UxDiffsCmd:
    """Toggle apply_patch diff artifact display in the REPL transcript."""

    mode: ReplDiffsMode


@dataclass(frozen=True)
class UxStreamCmd:
    """Set live vs final streaming mode for the REPL transcript."""

    mode: ReplStreamMode


@dataclass(frozen=True)
class UxVerbosityCmd:
    """Set transcript verbosity for REPL output."""

    mode: ReplVerbosity


@dataclass(frozen=True)
class KeyCmd:
    """Set or update the OpenAI API key for this process/session."""

    value: str


@dataclass(frozen=True)
class ToolsToggleCmd:
    """Toggle the session tools gate on or off."""

    on: bool


@dataclass(frozen=True)
class McpRefreshCmd:
    """Request MCP reconnection/refresh before the next run."""


@dataclass(frozen=True)
class McpStatusCmd:
    """Show MCP server connection status."""


@dataclass(frozen=True)
class ResilienceShowCmd:
    """Show effective provider resilience policy for the active model."""


@dataclass(frozen=True)
class ApprovalsShowCmd:
    """Show current approval mode (prompt or auto)."""


@dataclass(frozen=True)
class ApprovalsModeCmd:
    """Set approval mode for tool approvals in the REPL."""

    mode: ApprovalMode


@dataclass(frozen=True)
class ApprovalsListCmd:
    """List pending approvals with 1-line summaries."""


@dataclass(frozen=True)
class ApprovalsDetailCmd:
    """Show bounded details for a pending approval by id."""

    id: str


@dataclass(frozen=True)
class ApprovalsApproveCmd:
    """Approve a pending approval by id."""

    id: str


@dataclass(frozen=True)
class ApprovalsRejectCmd:
    """Reject a pending approval by id."""

    id: str
    reason: str | None = None


@dataclass(frozen=True)
class VerbosityShowCmd:
    """Show the current verbosity level."""


@dataclass(frozen=True)
class ReasoningShowCmd:
    """Show current reasoning settings."""


@dataclass(frozen=True)
class ToolsListCmd:
    """List the current tools selection and bundles."""


type Command = (
    ModelCmd
    | ModelPickCmd
    | VerbosityCmd
    | VerbosityShowCmd
    | ReasoningUnsetCmd
    | ReasoningEffortCmd
    | ReasoningSummaryCmd
    | ReasoningShowCmd
    | AgainCmd
    | ContinueCmd
    | EditCmd
    | ClearCmd
    | StatusCmd
    | ErrorsCmd
    | LastCmd
    | HelpCmd
    | QuitCmd
    | AgentCmd
    | AgentShowCmd
    | AgentListCmd
    | AttachCmd
    | AttachmentsShowCmd
    | DetachAllCmd
    | DetachPathCmd
    | CompressCmd
    | CompressShowCmd
    | ArtifactsListCmd
    | ArtifactsShowCmd
    | ArtifactsOpenCmd
    | ArtifactsAgentRunCmd
    | InspectAgentRunCmd
    | ToolsListCmd
    | ToolsAddBundleCmd
    | ToolsRemoveBundleCmd
    | ToolsAddToolCmd
    | ToolsRemoveToolCmd
    | ToolsResetCmd
    | ToolsToggleCmd
    | UxShowCmd
    | UxMarkdownCmd
    | UxReasoningCmd
    | UxDiffsCmd
    | UxStreamCmd
    | UxVerbosityCmd
    | ReplShowCmd
    | ReplThemeCmd
    | ReplColorDepthCmd
    | ReplMouseCmd
    | ReplCompletionCmd
    | ReplEditingModeCmd
    | KeyCmd
    | UsageCmd
    | McpRefreshCmd
    | McpStatusCmd
    | ResilienceShowCmd
    | ApprovalsShowCmd
    | ApprovalsModeCmd
    | ApprovalsListCmd
    | ApprovalsDetailCmd
    | ApprovalsApproveCmd
    | ApprovalsRejectCmd
    | TraceShowCmd
    | TraceClearCmd
    | TraceEnabledCmd
    | NewSessionCmd
    | SessionsListCmd
    | SessionsUseCmd
    | SessionRunsCmd
    | BranchListCmd
    | BranchUseCmd
    | BranchNewCmd
    | BranchForkCmd
    | BranchDeleteCmd
    | BranchRunsCmd
)
