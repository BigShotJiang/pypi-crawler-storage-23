"""Tiny flag decoders for CLI options (shared across commands)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TraceConfig:
    """Parsed trace configuration from --trace."""

    enabled: bool | None
    trace_id: str | None
    group_id: str | None
    metadata: list[str] | None


_TRACE_PARTS_WITH_META = 3


def parse_trace_flag(value: str | None) -> TraceConfig:
    """Parse consolidated --trace flag into components.

    Accepted formats:
    - ``on`` / ``off`` - Enable or disable tracing for this run
    - ``ID`` - Trace ID (also enables tracing)
    - ``ID:GROUP`` - ID and group
    - ``ID:GROUP:key=val,key2=val2`` - ID, group, and metadata

    Args:
      value: Raw CLI value for --trace.

    Returns:
      TraceConfig with parsed components.

    """
    if value is None or value.strip() == "":
        return TraceConfig(
            enabled=None,
            trace_id=None,
            group_id=None,
            metadata=None,
        )

    value = value.strip()
    lowered = value.lower()
    if lowered in {"on", "off"}:
        return TraceConfig(
            enabled=(lowered == "on"),
            trace_id=None,
            group_id=None,
            metadata=None,
        )

    # Split by colon (max 3 parts: ID, GROUP, METADATA)
    parts = value.split(":", _TRACE_PARTS_WITH_META - 1)
    trace_id = parts[0] or None
    group_id = parts[1] if len(parts) > 1 and parts[1] else None
    metadata: list[str] | None = None

    if len(parts) >= _TRACE_PARTS_WITH_META and parts[2]:
        # Parse key=val,key2=val2 into list
        raw_meta = parts[2]
        metadata = [kv.strip() for kv in raw_meta.split(",") if kv.strip()]
        if not metadata:
            metadata = None

    return TraceConfig(
        enabled=True,
        trace_id=trace_id,
        group_id=group_id,
        metadata=metadata,
    )


__all__ = ("TraceConfig", "parse_trace_flag")
