"""Command router mapping parsed commands to handlers."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from types import MappingProxyType

from agenterm.commands.actions import ReplAction
from agenterm.commands.handlers import agent as h_agent
from agenterm.commands.handlers import approvals as h_approvals
from agenterm.commands.handlers import artifacts as h_artifacts
from agenterm.commands.handlers import branch as h_branch
from agenterm.commands.handlers import compress as h_compress
from agenterm.commands.handlers import errors as h_errors
from agenterm.commands.handlers import inspect as h_inspect
from agenterm.commands.handlers import last as h_last
from agenterm.commands.handlers import mcp as h_mcp
from agenterm.commands.handlers import reasoning as h_reasoning
from agenterm.commands.handlers import repl as h_repl
from agenterm.commands.handlers import resilience as h_resilience
from agenterm.commands.handlers import session_config as h_session_config
from agenterm.commands.handlers import session_core as h_session_core
from agenterm.commands.handlers import session_repl as h_session_repl
from agenterm.commands.handlers import tools as h_tools
from agenterm.commands.handlers import trace as h_trace
from agenterm.commands.handlers import ux as h_ux
from agenterm.commands.model import (
    AgainCmd,
    AgentCmd,
    AgentListCmd,
    AgentShowCmd,
    ApprovalsApproveCmd,
    ApprovalsDetailCmd,
    ApprovalsListCmd,
    ApprovalsModeCmd,
    ApprovalsRejectCmd,
    ApprovalsShowCmd,
    ArtifactsAgentRunCmd,
    ArtifactsListCmd,
    ArtifactsOpenCmd,
    ArtifactsShowCmd,
    AttachCmd,
    AttachmentsShowCmd,
    BranchDeleteCmd,
    BranchForkCmd,
    BranchListCmd,
    BranchNewCmd,
    BranchRunsCmd,
    BranchUseCmd,
    ClearCmd,
    Command,
    CompressCmd,
    CompressShowCmd,
    ContinueCmd,
    DetachAllCmd,
    DetachPathCmd,
    EditCmd,
    ErrorsCmd,
    HelpCmd,
    InspectAgentRunCmd,
    KeyCmd,
    LastCmd,
    McpRefreshCmd,
    McpStatusCmd,
    ModelCmd,
    ModelPickCmd,
    NewSessionCmd,
    QuitCmd,
    ReasoningEffortCmd,
    ReasoningShowCmd,
    ReasoningSummaryCmd,
    ReasoningUnsetCmd,
    ReplColorDepthCmd,
    ReplCompletionCmd,
    ReplEditingModeCmd,
    ReplMouseCmd,
    ReplShowCmd,
    ReplThemeCmd,
    ResilienceShowCmd,
    SessionRunsCmd,
    SessionsListCmd,
    SessionsUseCmd,
    StatusCmd,
    ToolsAddBundleCmd,
    ToolsAddToolCmd,
    ToolsListCmd,
    ToolsRemoveBundleCmd,
    ToolsRemoveToolCmd,
    ToolsResetCmd,
    ToolsToggleCmd,
    TraceClearCmd,
    TraceEnabledCmd,
    TraceShowCmd,
    UsageCmd,
    UxDiffsCmd,
    UxMarkdownCmd,
    UxReasoningCmd,
    UxShowCmd,
    UxStreamCmd,
    UxVerbosityCmd,
    VerbosityCmd,
    VerbosityShowCmd,
)
from agenterm.core.types import SessionState


class CommandRouter:
    """Apply parsed commands to mutate session state using typed dispatch."""

    async def apply(
        self,
        state: SessionState,
        cmd: Command,
    ) -> tuple[SessionState, ReplAction | str | None]:
        """Dispatch a parsed command to its handler.

        Args:
          state: Current session state.
          cmd: Parsed command instance.

        Returns:
          Updated state and optional user-facing message.

        """
        return await handle_command(cmd, state)


HandlerResult = tuple[SessionState, ReplAction | str | None]
AsyncHandler = Callable[[SessionState, Command], Awaitable[HandlerResult]]


def _wrap_sync[C: Command](
    cls: type[C],
    fn: Callable[[SessionState, C], HandlerResult],
) -> AsyncHandler:
    """Wrap a sync handler to verify command type and return async callable."""

    async def _handler(state: SessionState, cmd: Command) -> HandlerResult:
        if not isinstance(cmd, cls):
            return state, "Unknown command. Use /help for usage."
        return fn(state, cmd)

    return _handler


def _wrap_async[C: Command](
    cls: type[C],
    fn: Callable[[SessionState, C], Awaitable[HandlerResult]],
) -> AsyncHandler:
    """Wrap an async handler to verify command type."""

    async def _handler(state: SessionState, cmd: Command) -> HandlerResult:
        if not isinstance(cmd, cls):
            return state, "Unknown command. Use /help for usage."
        return await fn(state, cmd)

    return _handler


def _usage(s: SessionState, c: UsageCmd) -> tuple[SessionState, str | None]:
    return s, c.msg


def _tools_list(
    state: SessionState,
    _cmd: ToolsListCmd,
) -> HandlerResult:
    return h_tools.tools_list(state)


def _trace_show(
    state: SessionState,
    _cmd: TraceShowCmd,
) -> HandlerResult:
    return h_trace.trace_show(state)


def _trace_clear(
    state: SessionState,
    _cmd: TraceClearCmd,
) -> HandlerResult:
    return h_trace.trace_clear(state)


HANDLERS: Mapping[type[Command], AsyncHandler] = MappingProxyType(
    {
        UsageCmd: _wrap_sync(UsageCmd, _usage),
        HelpCmd: _wrap_sync(HelpCmd, h_session_core.help_cmd),
        QuitCmd: _wrap_sync(QuitCmd, h_session_core.exit_cmd),
        StatusCmd: _wrap_sync(StatusCmd, h_session_core.status_cmd),
        ErrorsCmd: _wrap_sync(ErrorsCmd, h_errors.errors_cmd),
        LastCmd: _wrap_sync(LastCmd, h_last.last_cmd),
        ArtifactsListCmd: _wrap_async(
            ArtifactsListCmd,
            h_artifacts.artifacts_list_cmd,
        ),
        ArtifactsShowCmd: _wrap_async(
            ArtifactsShowCmd,
            h_artifacts.artifacts_show_cmd,
        ),
        ArtifactsOpenCmd: _wrap_async(
            ArtifactsOpenCmd,
            h_artifacts.artifacts_open_cmd,
        ),
        ArtifactsAgentRunCmd: _wrap_async(
            ArtifactsAgentRunCmd,
            h_artifacts.artifacts_agent_run_cmd,
        ),
        InspectAgentRunCmd: _wrap_async(
            InspectAgentRunCmd,
            h_inspect.inspect_agent_run_cmd,
        ),
        ModelCmd: _wrap_async(ModelCmd, h_session_config.set_model),
        ModelPickCmd: _wrap_sync(ModelPickCmd, h_session_config.pick_model),
        VerbosityCmd: _wrap_sync(VerbosityCmd, h_session_config.set_verbosity),
        VerbosityShowCmd: _wrap_sync(VerbosityShowCmd, h_session_config.show_verbosity),
        ReasoningUnsetCmd: _wrap_sync(ReasoningUnsetCmd, h_reasoning.reasoning_unset),
        ReasoningEffortCmd: _wrap_sync(
            ReasoningEffortCmd,
            h_reasoning.reasoning_modify,
        ),
        ReasoningSummaryCmd: _wrap_sync(
            ReasoningSummaryCmd,
            h_reasoning.reasoning_modify,
        ),
        ReasoningShowCmd: _wrap_sync(ReasoningShowCmd, h_session_config.show_reasoning),
        AgainCmd: _wrap_sync(AgainCmd, h_session_repl.again_cmd),
        ContinueCmd: _wrap_async(ContinueCmd, h_session_repl.continue_cmd),
        EditCmd: _wrap_sync(EditCmd, h_session_repl.edit_cmd),
        ClearCmd: _wrap_sync(ClearCmd, h_session_repl.clear_cmd),
        AttachmentsShowCmd: _wrap_sync(
            AttachmentsShowCmd,
            h_session_repl.attachments_show_cmd,
        ),
        AgentCmd: _wrap_sync(AgentCmd, h_agent.agent_switch),
        AgentShowCmd: _wrap_sync(AgentShowCmd, h_agent.agent_show),
        AgentListCmd: _wrap_sync(AgentListCmd, h_agent.agent_list),
        AttachCmd: _wrap_sync(AttachCmd, h_session_repl.attach_cmd),
        DetachAllCmd: _wrap_sync(DetachAllCmd, h_session_repl.detach_all_cmd),
        DetachPathCmd: _wrap_sync(DetachPathCmd, h_session_repl.detach_path_cmd),
        CompressCmd: _wrap_sync(CompressCmd, h_compress.compress_cmd),
        CompressShowCmd: _wrap_sync(CompressShowCmd, h_compress.compress_show_cmd),
        ToolsToggleCmd: _wrap_sync(ToolsToggleCmd, h_tools.tools_toggle),
        ToolsListCmd: _wrap_sync(ToolsListCmd, _tools_list),
        ToolsAddBundleCmd: _wrap_sync(ToolsAddBundleCmd, h_tools.tools_modify),
        ToolsRemoveBundleCmd: _wrap_sync(ToolsRemoveBundleCmd, h_tools.tools_modify),
        ToolsAddToolCmd: _wrap_sync(ToolsAddToolCmd, h_tools.tools_modify),
        ToolsRemoveToolCmd: _wrap_sync(ToolsRemoveToolCmd, h_tools.tools_modify),
        ToolsResetCmd: _wrap_sync(ToolsResetCmd, h_tools.tools_reset),
        McpRefreshCmd: _wrap_sync(McpRefreshCmd, h_mcp.mcp_refresh),
        McpStatusCmd: _wrap_async(McpStatusCmd, h_mcp.mcp_status),
        ResilienceShowCmd: _wrap_sync(
            ResilienceShowCmd,
            h_resilience.resilience_show_cmd,
        ),
        ApprovalsShowCmd: _wrap_sync(ApprovalsShowCmd, h_approvals.approvals_show_cmd),
        ApprovalsModeCmd: _wrap_sync(ApprovalsModeCmd, h_approvals.approvals_mode_cmd),
        ApprovalsListCmd: _wrap_sync(ApprovalsListCmd, h_approvals.approvals_list_cmd),
        ApprovalsDetailCmd: _wrap_sync(
            ApprovalsDetailCmd,
            h_approvals.approvals_detail_cmd,
        ),
        ApprovalsApproveCmd: _wrap_sync(
            ApprovalsApproveCmd,
            h_approvals.approvals_approve_cmd,
        ),
        ApprovalsRejectCmd: _wrap_sync(
            ApprovalsRejectCmd,
            h_approvals.approvals_reject_cmd,
        ),
        UxShowCmd: _wrap_sync(UxShowCmd, h_ux.ux_show_cmd),
        UxMarkdownCmd: _wrap_sync(UxMarkdownCmd, h_ux.ux_markdown_cmd),
        UxReasoningCmd: _wrap_sync(UxReasoningCmd, h_ux.ux_reasoning_cmd),
        UxDiffsCmd: _wrap_sync(UxDiffsCmd, h_ux.ux_diffs_cmd),
        UxStreamCmd: _wrap_sync(UxStreamCmd, h_ux.ux_stream_cmd),
        UxVerbosityCmd: _wrap_sync(UxVerbosityCmd, h_ux.ux_verbosity_cmd),
        ReplShowCmd: _wrap_sync(ReplShowCmd, h_repl.repl_show_cmd),
        ReplThemeCmd: _wrap_sync(ReplThemeCmd, h_repl.repl_theme_cmd),
        ReplColorDepthCmd: _wrap_sync(
            ReplColorDepthCmd,
            h_repl.repl_color_depth_cmd,
        ),
        ReplMouseCmd: _wrap_sync(ReplMouseCmd, h_repl.repl_mouse_cmd),
        ReplCompletionCmd: _wrap_sync(
            ReplCompletionCmd,
            h_repl.repl_completion_cmd,
        ),
        ReplEditingModeCmd: _wrap_sync(
            ReplEditingModeCmd,
            h_repl.repl_editing_mode_cmd,
        ),
        KeyCmd: _wrap_sync(KeyCmd, h_session_config.set_api_key),
        TraceShowCmd: _wrap_sync(TraceShowCmd, _trace_show),
        TraceClearCmd: _wrap_sync(TraceClearCmd, _trace_clear),
        TraceEnabledCmd: _wrap_sync(TraceEnabledCmd, h_trace.trace_toggle),
        NewSessionCmd: _wrap_sync(NewSessionCmd, h_session_repl.new_session_cmd),
        SessionsListCmd: _wrap_async(
            SessionsListCmd,
            h_session_repl.sessions_list_cmd,
        ),
        SessionsUseCmd: _wrap_async(
            SessionsUseCmd,
            h_session_repl.sessions_use_cmd,
        ),
        SessionRunsCmd: _wrap_sync(SessionRunsCmd, h_session_repl.session_runs_cmd),
        BranchListCmd: _wrap_sync(BranchListCmd, h_branch.branch_list_cmd),
        BranchUseCmd: _wrap_sync(BranchUseCmd, h_branch.branch_use_cmd),
        BranchNewCmd: _wrap_sync(BranchNewCmd, h_branch.branch_new_cmd),
        BranchForkCmd: _wrap_sync(BranchForkCmd, h_branch.branch_fork_cmd),
        BranchDeleteCmd: _wrap_sync(BranchDeleteCmd, h_branch.branch_delete_cmd),
        BranchRunsCmd: _wrap_sync(BranchRunsCmd, h_branch.branch_runs_cmd),
    },
)


async def handle_command(
    cmd: Command,
    state: SessionState,
) -> tuple[SessionState, ReplAction | str | None]:
    """Resolve and invoke the handler for a command.

    Args:
      cmd: Parsed command.
      state: Current session state.

    Returns:
      Updated state and optional user-facing message.

    """
    fn = HANDLERS.get(type(cmd))
    if fn is None:
        return state, "Unknown command. Use /help for usage."
    return await fn(state, cmd)
