"""Command parsing and completion router for top-level REPL commands.

Validate the registry shape, expose parse helpers, and provide completion
delegation to per-feature parsers.
"""

from __future__ import annotations

import shlex
from types import MappingProxyType
from typing import TYPE_CHECKING

from agenterm.commands.dispatcher import CommandRouter
from agenterm.commands.model import Command, HelpCmd, UsageCmd
from agenterm.commands.slash_manifest import SlashCommandSpec, slash_commands
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agenterm.commands.parsers.base import Completer
    from agenterm.core.types import SessionState


# Manifest-driven registry to prevent drift between parsing, completion, and help.
_SPECS: tuple[SlashCommandSpec, ...] = slash_commands()

# Registry maps command head -> (parser, takes_arguments)
_REGISTRY: Mapping[str, tuple[Callable[[list[str]], Command | None], bool]] = (
    MappingProxyType(
        {spec.name: (spec.parser, spec.takes_arguments) for spec in _SPECS},
    )
)


# Top-level commands in display order (used by completions and help)
_ORDER_TOP_LEVEL: tuple[str, ...] = tuple(spec.name for spec in _SPECS)


_COMPLETIONS: Mapping[str, Completer] = MappingProxyType(
    {spec.name: spec.completer for spec in _SPECS if spec.completer is not None},
)

_SUMMARY_MAP: Mapping[str, str] = MappingProxyType(
    {spec.name: spec.summary for spec in _SPECS},
)


def _validate_registry() -> None:
    """Validate command registry and completion tables.

    Raises:
      ConfigError: When registry contents are inconsistent or invalid.

    """
    allowed = set(_ORDER_TOP_LEVEL)
    for k, (parser, _) in _REGISTRY.items():
        if not k.startswith("/"):
            msg = f"registry key must start with '/': {k}"
            raise ConfigError(msg)
        if k not in allowed:
            msg = f"unknown command in registry: {k}"
            raise ConfigError(msg)
        if not callable(parser):
            msg = f"parser for {k} must be callable"
            raise ConfigError(msg)
    for ck, comp in _COMPLETIONS.items():
        if ck not in _REGISTRY:
            msg = f"completion without registry entry: {ck}"
            raise ConfigError(msg)
        if _REGISTRY[ck][1] is not True:
            msg = f"completion provided for non-arg command: {ck}"
            raise ConfigError(msg)
        if not callable(comp):
            msg = f"completion for {ck} must be callable"
            raise ConfigError(msg)


def parse_command(line: str) -> Command | None:
    """Parse a command line into a structured Command.

    Args:
      line: Raw input line.

    Returns:
      Parsed Command or None when the line is not a command.

    """
    raw = line.strip()
    if not raw.startswith("/"):
        return None
    try:
        ts = shlex.split(raw, posix=True)
    except ValueError as exc:
        return UsageCmd(f"Invalid quoting: {exc}")
    if not ts:
        return None
    head = ts[0].lower()
    args = ts[1:]
    parser = _REGISTRY.get(head, (None, False))[0] if head in _REGISTRY else None
    if parser is None:
        return HelpCmd()
    cmd = parser(args)
    return cmd if cmd is not None else UsageCmd(_usage_for(head))


def top_level_candidates() -> list[str]:
    """Return top-level command candidates with arg-trailing space.

    Returns:
      List of names with trailing space when they accept arguments.

    """
    out: list[str] = []
    for name in _ORDER_TOP_LEVEL:
        if name in _REGISTRY:
            has_arg = _REGISTRY[name][1]
            out.append(name + (" " if has_arg else ""))
    return out


def top_level_summaries() -> Mapping[str, str]:
    """Return top-level command summary strings keyed by command name."""
    return _SUMMARY_MAP


def subcommand_candidates(
    command: str,
    rest: str,
    state: SessionState | None = None,
) -> list[str]:
    """Return completion candidates for a subcommand.

    Args:
      command: Base command head (e.g., '/tools').
      rest: Unparsed remainder of the line after the head.
      state: Optional SessionState used for context-aware completions.

    Returns:
      A list of completion strings, possibly empty.

    """
    cmd = command.lower()
    fn = _COMPLETIONS.get(cmd)
    return fn(rest, state) if fn else []


_USAGE_MAP: Mapping[str, str] = MappingProxyType(
    {spec.name: spec.usage for spec in _SPECS if spec.usage is not None},
)


def _usage_for(head: str) -> str:
    return _USAGE_MAP.get(head, "Usage: /help")


_validate_registry()

__all__ = (
    "CommandRouter",
    "parse_command",
    "subcommand_candidates",
    "top_level_candidates",
    "top_level_summaries",
)
