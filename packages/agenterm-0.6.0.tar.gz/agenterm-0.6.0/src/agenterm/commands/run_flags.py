"""Flag + mode resolution helpers for `agenterm run`."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.app.services import RunConfigFlags
from agenterm.cli.output_format import OutputFormat
from agenterm.commands.run_support import RunModes
from agenterm.core.env import has_openai_api_key
from agenterm.core.errors import AuthError

if TYPE_CHECKING:
    from agenterm.commands.cli_args import RunCliArgs
    from agenterm.config.model import RunDefaults


def require_api_key(model_id: str) -> None:
    """Ensure OPENAI_API_KEY is present for openai/* models."""
    if not model_id.lower().startswith("openai/"):
        return
    if has_openai_api_key():
        return
    msg = "auth: OPENAI_API_KEY not set"
    raise AuthError(msg)


def build_run_flags(opts: RunCliArgs) -> RunConfigFlags:
    """Build run config flags from parsed CLI args."""
    return RunConfigFlags(
        config=opts.config,
        agent_name=opts.agent_name,
        model=opts.model,
        trace_enabled=opts.trace_enabled,
        trace_id=opts.trace_id,
        trace_group=opts.trace_group,
        trace_metadata=opts.trace_metadata,
        no_tools=opts.no_tools,
        tool_select=opts.tool_select,
        no_retry=opts.no_retry,
        max_retries=opts.max_retries,
        deadline_seconds=opts.deadline_seconds,
        attempt_timeout_seconds=opts.attempt_timeout_seconds,
        store_override=opts.store_override,
        allow_dangerous=bool(opts.allow_dangerous),
        hosted_mode=bool(opts.background) if opts.background is not None else False,
        background_flag=bool(opts.background) if opts.background is not None else None,
    )


def resolve_run_modes(opts: RunCliArgs, cfg_run: RunDefaults) -> RunModes:
    """Resolve live/output modes from flags + config defaults."""
    live = opts.live if opts.live is not None else cfg_run.live
    output_format = (
        opts.format_override
        if opts.format_override is not None
        else (OutputFormat.json if cfg_run.json_output else OutputFormat.human)
    )
    return RunModes(live=live, output_format=output_format)


__all__ = ("build_run_flags", "require_api_key", "resolve_run_modes")
