"""Agent commands for agenterm: list, show, path, save."""

from __future__ import annotations

from typing import Annotated, Final

import typer

from agenterm.cli.options import AgentOption, ConfigOption, FormatOption
from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output import emit_result as emit_cli_result
from agenterm.cli.output_format import OutputFormat
from agenterm.config.agent_files import (
    list_available_agents,
    list_bundled_agents,
    list_global_agents,
    list_local_agents,
)
from agenterm.config.bootstrap import save_agents
from agenterm.core.choices.config_scope import CONFIG_SCOPES, parse_config_scope
from agenterm.core.cli_payloads import (
    AgentPathPayload,
    AgentShowPayload,
    AgentsListPayload,
    AgentsSavePayload,
)
from agenterm.core.error_report import (
    ErrorContext,
    build_error_report,
    build_message_report,
)
from agenterm.core.errors import ConfigError, FilesystemError
from agenterm.core.hashing import sha256_text_or_none
from agenterm.workflow.shared.config_files import load_base_config

_DEFAULT_BOOL = False
_DEFAULT_SCOPE = "global"

agents_app: Final = typer.Typer(
    name="agents",
    help="View and manage agents",
    no_args_is_help=True,
)


def _context(resource: str, trace_id: str | None) -> ErrorContext:
    return ErrorContext(operation=resource, resource=resource, trace_id=trace_id)


@agents_app.command("list")
def list_cmd(
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """List available agents."""
    payload = AgentsListPayload(
        available=tuple(list_available_agents()),
        local=tuple(list_local_agents()),
        global_agents=tuple(list_global_agents()),
        bundled=tuple(list_bundled_agents()),
    )
    emit_cli_result(
        output_format=output_format,
        resource="agents.list",
        payload=payload,
        trace_id=None,
    )


@agents_app.command("show")
def show_cmd(
    *,
    config: ConfigOption = None,
    agent: AgentOption = None,
    output_format: FormatOption = OutputFormat.human,
    plain: Annotated[
        bool,
        typer.Option("--plain/--rich", help="Render plain text"),
    ] = _DEFAULT_BOOL,
) -> None:
    """Display the effective agent file."""
    try:
        cfg = load_base_config(config, agent_name=agent)
    except (ConfigError, FilesystemError) as exc:
        report = build_error_report(exc, context=_context("agents.show", None))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc

    text = cfg.agent.instructions or ""
    payload = AgentShowPayload(
        name=cfg.agent.name,
        source=cfg.agent.source,
        path=str(cfg.agent.path) if cfg.agent.path else None,
        text=text,
        sha256=sha256_text_or_none(cfg.agent.instructions),
        size_bytes=len(text.encode("utf-8")),
        render_mode="plain" if plain else "rich",
    )
    emit_cli_result(
        output_format=output_format,
        resource="agents.show",
        payload=payload,
        trace_id=cfg.run.trace_id,
    )


@agents_app.command("path")
def path_cmd(
    *,
    config: ConfigOption = None,
    agent: AgentOption = None,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Print active agent path."""
    try:
        cfg = load_base_config(config, agent_name=agent)
    except (ConfigError, FilesystemError) as exc:
        report = build_error_report(exc, context=_context("agents.path", None))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc

    emit_cli_result(
        output_format=output_format,
        resource="agents.path",
        payload=AgentPathPayload(
            name=cfg.agent.name,
            path=str(cfg.agent.path) if cfg.agent.path else None,
            source=cfg.agent.source,
        ),
        trace_id=None,
    )


@agents_app.command("save")
def save_cmd(
    *,
    scope: Annotated[
        str,
        typer.Option("--scope", help="Agent scope (global|local)"),
    ] = _DEFAULT_SCOPE,
    output_format: FormatOption = OutputFormat.human,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Overwrite existing agent files"),
    ] = _DEFAULT_BOOL,
) -> None:
    """Write baseline agent files (global or project-local)."""
    scope_parsed = parse_config_scope(scope)
    if scope_parsed is None:
        msg = f"--scope must be one of: {', '.join(CONFIG_SCOPES)}"
        report = build_message_report(
            kind="usage_error",
            message=msg,
            context=_context("agents.save", None),
        )
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2)

    try:
        result = save_agents(
            scope=scope_parsed,
            force=bool(force),
        )
    except (ConfigError, FilesystemError) as exc:
        report = build_error_report(exc, context=_context("agents.save", None))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(1) from exc

    emit_cli_result(
        output_format=output_format,
        resource="agents.save",
        payload=AgentsSavePayload(
            scope=str(result.scope),
            source=result.source,
            paths=tuple(str(p) for p in result.paths),
            overwritten=bool(result.overwritten),
        ),
        trace_id=None,
    )


__all__ = ("agents_app",)
