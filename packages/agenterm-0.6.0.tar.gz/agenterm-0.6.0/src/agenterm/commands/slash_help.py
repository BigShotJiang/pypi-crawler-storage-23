"""Help text rendering for REPL slash commands.

This module owns the human-facing help contract for `/help` and `/help <topic>`.
It consumes the canonical slash command manifest to ensure help does not drift
from the actual command surface.
"""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Literal

from agenterm.commands.slash_manifest import find_spec_by_topic, slash_commands
from agenterm.core.choices.common import UNSET_MARKER
from agenterm.core.choices.model import MODEL_VERBOSITIES
from agenterm.core.choices.repl import (
    REPL_DIFFS_MODES,
    REPL_REASONING_MODES,
    REPL_STREAM_MODES,
    REPL_VERBOSITIES,
)
from agenterm.core.choices.repl_ui import (
    REPL_COLOR_DEPTHS,
    REPL_COMPLETION_MODES,
    REPL_EDITING_MODES,
    REPL_THEMES,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.commands.slash_manifest import SlashCommandSpec


def _format_specs(specs: list[SlashCommandSpec]) -> list[str]:
    if not specs:
        return []
    width = max(len(s.name) for s in specs)
    pad = max(width, 10)
    return [f"  {s.name:<{pad}}  {s.summary}" for s in specs]


type HelpOverviewMode = Literal["essentials", "all"]


def _help_overview(*, mode: HelpOverviewMode) -> str:
    """Return `/help` overview text."""
    specs_all = list(slash_commands())
    essentials = [s for s in specs_all if s.tier == "essential"]
    advanced = [s for s in specs_all if s.tier == "advanced"]

    lines: list[str] = []
    if mode == "essentials":
        lines.append("Commands (essentials):")
        lines.extend(_format_specs(essentials))
        lines.append("")
        lines.append("More:")
        lines.append("  /help all      Show full command tree")
        lines.append("")
        lines.append("Cancel: ESC/Ctrl+C")
        lines.append("Tab: accept history suggestion for text.")
        lines.append("Slash input: open/cycle completion. Empty input: no-op.")
        lines.append("/help <topic> for details.")
        return "\n".join(lines)
    lines.append("Commands (essentials):")
    lines.extend(_format_specs(essentials))
    lines.append("")
    lines.append("Commands (advanced):")
    lines.extend(_format_specs(advanced))
    return "\n".join(lines)


_TOPIC_HELP: Mapping[str, str] = MappingProxyType(
    {
        "help": """/help — Show help

Usage:
  /help              Show essentials overview
  /help all          Show full command tree
  /help <topic>      Show detailed help for a command

Examples:
  /help tools
  /help config""",
        "status": """/status — Session snapshot

Shows current model, tools, verbosity, reasoning, session ID,
and other effective configuration values.""",
        "errors": """/errors — Show captured stderr/logging lines

Usage:
  /errors

Notes:
  - Displays the bounded REPL error buffer (stderr/logging captured during the session).
  - If the buffer clamps, the transcript emits: error> (truncated; see /errors).""",
        "last": """/last — Show last artifacts

Usage:
  /last diff [preview|full]        Show last apply_patch diff
  /last tools [preview|full]       Show last tool call/output
  /last approvals [preview|full]   Show last approvals (pending + resolved)

Notes:
  - preview is a bounded summary; /last diff full shows the full diff, other
    modes remain bounded by transcript policy.
  - Artifacts are captured from the streamed transcript as the agent runs.""",
        "artifacts": """/artifacts — Browse durable artifacts

Usage:
  /artifacts list [N]     List recent artifacts (default: 20)
  /artifacts show <ID>    Show one artifact record (metadata + bounded preview)
  /artifacts open <ID>    Open artifact file (macOS only)
  /artifacts agent-run <ID>  Show an agent_run report (summary)

Notes:
  - list shows ids + summaries; show expands one record.
  - Artifacts live on disk under ~/.agenterm/artifacts/; the DB stores references.""",
        "inspect": """/inspect — Inspect agent_run reports

Usage:
  /inspect agent-run <REPORT_ID> [--json]

Notes:
  - Human summary by default; add --json for the full report.
  - Report ids are printed by agent_run summaries and /artifacts list.""",
        "quit": """/quit — Exit REPL

Shortcut: Ctrl+D
Notes:
  - Prints a resume command with the current session id on exit.""",
        "model": """/model — Route-first model selection

Usage:
  /model                 Open route picker (openai/openrouter/ollama)
  /model <ROUTE>         Open route-scoped model picker
                         (ROUTE: openai | openrouter | ollama)
  /model <ID>            Set model directly
                         (openai/<model> or gateway/<route>/<model>)

Notes:
  - The picker always starts from route selection, then model selection.
  - Each route has opinionated defaults from providers.*.model_suggestions.
  - Convenience: `/model gpt-5.2` is treated as `openai/gpt-5.2` in the REPL.

Examples:
  /model
  /model openrouter
  /model openai/gpt-5.2
  /model gateway/openrouter/anthropic/claude-opus-4-6
  /model gateway/ollama/gpt-oss:20b""",
        "tools": """/tools — Manage tool bundles and selection

Usage:
  /tools              Show current selection
  /tools on|off       Enable/disable all tools
  /tools add bundle NAME...
  /tools add tool KEY...
  /tools remove bundle|tool NAME...
  /tools reset        Reset to config defaults

Examples:
  /tools add bundle code
  /tools remove tool fn:shell
  /tools off""",
        "config": f"""/config — Session settings

Usage:
  /config key <API_KEY>           Save OpenAI API key to ~/.agenterm/.env
                                 (and set for this session)
  /config verbosity [LEVEL]       Show/set output detail
                                 ({"|".join((*MODEL_VERBOSITIES, UNSET_MARKER))})
  /config reasoning [ARGS]        Show/set reasoning effort and summary

Examples:
  /config verbosity high
  /config reasoning effort high
  /config reasoning summary concise""",
        "trace": """/trace — Tracing controls

Usage:
  /trace                  Show current trace settings
  /trace show             Show current trace settings
  /trace clear            Clear trace id/group/metadata
  /trace on               Enable tracing for this session
  /trace off              Disable tracing for this session

Examples:
  /trace off
  /trace on""",
        "resilience": """/resilience — Effective retry policy

Usage:
  /resilience
  /resilience show

Shows:
  - provider retry defaults
  - route-level retry overrides (gateway models)
  - effective streamed retry policy and restart-path settings""",
        "repl": f"""/repl — Prompt UI controls

Usage:
  /repl                                  Show current prompt UI settings
  /repl theme {"|".join(REPL_THEMES)}                 Select REPL theme
  /repl color-depth {"|".join(REPL_COLOR_DEPTHS)}     Set prompt-toolkit color depth
  /repl mouse on|off                     Toggle mouse support
  /repl completion {"|".join(REPL_COMPLETION_MODES)}        Completion mode
  /repl edit-mode {"|".join(REPL_EDITING_MODES)}       Editing mode (vi/emacs)

Notes:
  - completion=commands suggests only slash commands.
  - completion=full includes slash commands + history suggestions.
  - These settings affect the REPL prompt UI only (not `agenterm run` output).""",
        "ux": f"""/ux — REPL UX toggles

Usage:
  /ux                          Show current UX settings
  /ux markdown on|off          Toggle Markdown rendering for agent output
  /ux reasoning {"|".join(REPL_REASONING_MODES)}    Toggle reasoning summary blocks
  /ux diffs {"|".join(REPL_DIFFS_MODES)}        Toggle apply_patch diff details
  /ux stream {"|".join(REPL_STREAM_MODES)}       Set streaming mode (final or live)
  /ux verbosity {"|".join(REPL_VERBOSITIES)}     Set transcript verbosity

Notes:
  - Markdown renders only in stream=final mode.
  - verbosity controls how much tool/detail text is emitted in transcript blocks.""",
        "session": """/session — Session management

Usage:
  /session list         List stored sessions
  /session new          Start fresh session
  /session use <ID>     Attach to existing session
  /session runs [N]     Show last N runs (default: 10)

Notes:
  - runs renders the last N runs for the active session/branch.

Examples:
  /session new
  /session use abc123
  /session runs 20""",
        "branch": """/branch — Branch management

Usage:
  /branch list                  List branches for the active session
  /branch use <ID>              Switch to a branch
  /branch new [ID]              Create a branch from head and switch
  /branch fork <RUN> [ID]       Fork from a run (exclusive) and switch
  /branch delete <ID> [--force|-f|force]   Delete a branch (force if current)
  /branch runs [N] [ID]         Show runs for a branch

Notes:
  - new keeps the full head session history (SDK turns).
  - fork discards runs >= RUN (useful for replaying/editing; if the last run has
    no turns, /again and /edit retry in place).

Examples:
  /branch list
  /branch use main
  /branch new experiment
  /branch fork 3 fixup
  /branch delete fixup --force
  /branch runs 20""",
        "approvals": """/approvals — Manage tool approvals

Usage:
  /approvals              Show current mode
  /approvals auto         Auto-resolve approvals for session
  /approvals prompt       Require inline approval (default)
  /approvals list         List pending approvals (ids + 1-line summaries)
  /approvals show <ID>    Show bounded detail for a pending approval
  /approvals approve <ID> Approve a pending approval by id
  /approvals reject <ID> [reason] Reject a pending approval by id

When prompt, tools prompt [y/N] inline.
When auto, approvals are auto-resolved.

Approval ids are kind-prefixed (e.g., shell-1, patch-2, mcp-3).""",
        "attach": """/attach — Manage staged attachments

Usage:
  /attach <PATH|URL>              Stage a file or URL for the next prompt
  /attach list                    Show staged + last-used attachments
  /attach remove <PATH|URL>|all   Unstage attachments for the next prompt
  /attach clear                   Clear staged attachments + reuse flag

Notes:
  - There is no standalone /clear command; use /attach clear.
  - Use /again or /edit to reuse last attachments.

Examples:
  /attach screenshot.png
  /attach list
  /attach remove all""",
        "agent": """/agent — Show/list/switch agent

Usage:
  /agent                 Show current agent
  /agent list            List available agents
  /agent <NAME>          Switch to an agent name

Switching agents replaces the current developer/system prompt with the
contents of the specified agent file.

Examples:
  /agent
  /agent list
  /agent agenterm""",
        "mcp": """/mcp — MCP server tools

Usage:
  /mcp refresh        Reconnect MCP servers at next run
  /mcp status         Show MCP server status and discovered tool counts

MCP servers are configured in config.yaml under mcp.servers.""",
        "again": """/again — Re-run last prompt

Re-sends your previous prompt on a new fork that drops the last run.
If the last run produced no turns, it retries in place.
Requires a stored session (local history) so the fork can be recorded.
Reuses the last attachments by default.""",
        "continue": """/continue — Continue after cancellation/timeout

Starts a new run with *no new user message* and relies on agenterm's resume
mechanism to prepend any captured in-flight items from the last cancelled/timeout
run.

Use this when the previous run was cancelled mid-tool-call or mid-stream and you
want to keep the coherent work that already completed. Use /again to re-run the
full previous prompt.""",
        "edit": """/edit — Edit last prompt

Forks from the last run and pre-fills the input.
If the last run produced no turns, it edits in place.
Marks the next send to reuse last attachments.""",
    },
)


def render_help(topic: str | None) -> str:
    """Render help text for `/help`, `/help all`, or `/help <topic>`."""
    if topic is None:
        return _help_overview(mode="essentials")
    tok = topic.lower().lstrip("/")
    if tok == "all":
        return _help_overview(mode="all")
    if tok in _TOPIC_HELP:
        return _TOPIC_HELP[tok]
    spec = find_spec_by_topic(tok)
    if spec is None:
        return f"Unknown topic: {topic}\n\n" + _help_overview(mode="essentials")
    title = f"{spec.name} — {spec.summary}"
    usage = spec.usage or "Usage: /help"
    return f"{title}\n\n{usage}\n"


__all__ = ("render_help",)
