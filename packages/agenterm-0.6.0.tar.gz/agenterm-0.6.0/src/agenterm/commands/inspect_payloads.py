"""Payload builders for inspect CLI commands."""

from __future__ import annotations

from types import MappingProxyType

from agenterm.artifacts.agent_run import load_agent_run_report
from agenterm.core.cli_payloads import (
    ArtifactSummaryPayload,
    InspectAgentRunPayload,
    InspectRunEventsPayload,
    InspectRunPayload,
    InspectTurnPayload,
)
from agenterm.core.response_items import (
    normalize_input_item_json,
    serialize_input_items,
)
from agenterm.engine.artifacts import resolve_image_artifacts
from agenterm.store.branch.repo import get_branch_meta
from agenterm.store.history import history_store
from agenterm.store.run_events import count_run_events, list_run_events
from agenterm.store.runs.repo import get_run_by_number
from agenterm.store.session.branch_turn_items import (
    list_branch_turn_items,
    list_branch_turn_items_range,
)
from agenterm.store.session.service import (
    get_session_metadata_row,
    session_store,
    usage_totals_by_run,
)


async def resolve_branch(
    *,
    session_id: str,
    branch_id: str | None,
) -> tuple[str, str] | None:
    """Resolve the effective branch id for a session."""
    store = session_store()
    meta = await get_session_metadata_row(store, session_id)
    if meta is None:
        return None
    resolved = branch_id if branch_id is not None else meta.head_branch_id
    branch_meta = await get_branch_meta(store, session_id, resolved)
    if branch_meta is None:
        return None
    return meta.session_id, resolved


async def inspect_run_payload(
    session_id: str,
    run_number: int,
    *,
    branch_id: str | None,
) -> InspectRunPayload | None:
    """Build payload for `agenterm inspect run`."""
    store = session_store()
    history = history_store()
    resolved = await resolve_branch(session_id=session_id, branch_id=branch_id)
    if resolved is None:
        return None
    _, resolved_branch = resolved
    run_record = await get_run_by_number(
        store=store,
        session_id=session_id,
        branch_id=resolved_branch,
        run_number=run_number,
    )
    if run_record is None:
        return None

    raw_items = ()
    if (
        run_record.branch_turn_start is not None
        and run_record.branch_turn_end is not None
    ):
        raw_items = await list_branch_turn_items_range(
            store=history,
            session_id=session_id,
            branch_id=resolved_branch,
            start_turn=run_record.branch_turn_start,
            end_turn=run_record.branch_turn_end,
        )
    parsed_items = [
        normalize_input_item_json(item.item, context="inspect.run.item")
        for item in raw_items
    ]
    items_payload = serialize_input_items(parsed_items, context="inspect.run.items")

    events_count = await count_run_events(
        store=store,
        session_id=session_id,
        branch_id=resolved_branch,
        run_number=run_number,
    )
    usage_by_run = await usage_totals_by_run(
        store=store,
        session_id=session_id,
        branch_id=resolved_branch,
    )
    usage = usage_by_run.get(run_number)
    usage_map = dict(usage.to_mapping()) if usage is not None else None

    artifacts_resolution = await resolve_image_artifacts(
        store=store,
        items=parsed_items,
    )
    artifacts = tuple(
        ArtifactSummaryPayload(
            artifact_id=rec.artifact_id,
            kind=rec.kind,
            mime=rec.mime,
            path=rec.path,
            size_bytes=rec.size_bytes,
            created_at=rec.created_at,
            source_type=rec.source_type,
            source_id=rec.source_id,
            session_id=rec.session_id,
        )
        for rec in artifacts_resolution.records
    )

    return InspectRunPayload(
        session_id=session_id,
        branch_id=resolved_branch,
        run_number=run_number,
        status=run_record.status,
        response_id=run_record.response_id,
        trace_id=run_record.trace_id,
        started_at=run_record.started_at,
        updated_at=run_record.updated_at,
        usage=usage_map,
        events_count=events_count,
        items=items_payload,
        artifacts=artifacts,
    )


async def inspect_run_events_payload(
    session_id: str,
    run_number: int,
    *,
    branch_id: str | None,
    limit: int | None,
) -> InspectRunEventsPayload | None:
    """Build payload for `agenterm inspect run-events`."""
    store = session_store()
    resolved = await resolve_branch(session_id=session_id, branch_id=branch_id)
    if resolved is None:
        return None
    _, resolved_branch = resolved
    run_record = await get_run_by_number(
        store=store,
        session_id=session_id,
        branch_id=resolved_branch,
        run_number=run_number,
    )
    if run_record is None:
        return None
    records = await list_run_events(
        store=store,
        session_id=session_id,
        branch_id=resolved_branch,
        run_number=run_number,
        limit=limit,
    )
    events = tuple(dict(rec.event) for rec in records)
    return InspectRunEventsPayload(
        session_id=session_id,
        branch_id=resolved_branch,
        run_number=run_number,
        events=events,
    )


async def inspect_turn_payload(
    session_id: str,
    turn_number: int,
    *,
    branch_id: str | None,
) -> InspectTurnPayload | None:
    """Build payload for `agenterm inspect turn`."""
    store = session_store()
    history = history_store()
    resolved = await resolve_branch(session_id=session_id, branch_id=branch_id)
    if resolved is None:
        return None
    _, resolved_branch = resolved
    raw_items = await list_branch_turn_items(
        store=history,
        session_id=session_id,
        branch_id=resolved_branch,
        branch_turn_number=turn_number,
    )
    if not raw_items:
        return None
    parsed_items = [
        normalize_input_item_json(item.item, context="inspect.turn.item")
        for item in raw_items
    ]
    items_payload = serialize_input_items(parsed_items, context="inspect.turn.items")
    artifacts_resolution = await resolve_image_artifacts(
        store=store,
        items=parsed_items,
    )
    artifacts = tuple(
        ArtifactSummaryPayload(
            artifact_id=rec.artifact_id,
            kind=rec.kind,
            mime=rec.mime,
            path=rec.path,
            size_bytes=rec.size_bytes,
            created_at=rec.created_at,
            source_type=rec.source_type,
            source_id=rec.source_id,
            session_id=rec.session_id,
        )
        for rec in artifacts_resolution.records
    )
    return InspectTurnPayload(
        session_id=session_id,
        branch_id=resolved_branch,
        turn_number=turn_number,
        items=items_payload,
        artifacts=artifacts,
    )


async def inspect_agent_run_payload(
    report_id: str,
) -> InspectAgentRunPayload | None:
    """Build payload for `agenterm inspect agent-run`."""
    report = await load_agent_run_report(
        store=session_store(),
        artifact_id=report_id,
    )
    if report is None:
        return None
    return InspectAgentRunPayload(
        report_id=report_id,
        report=MappingProxyType(dict(report)),
    )


__all__ = (
    "inspect_agent_run_payload",
    "inspect_run_events_payload",
    "inspect_run_payload",
    "inspect_turn_payload",
    "resolve_branch",
)
