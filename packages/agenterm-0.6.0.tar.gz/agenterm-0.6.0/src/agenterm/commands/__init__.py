"""Commands package.

Import submodules directly (e.g., `agenterm.commands.router`) to avoid import-time
cycles between command parsing and higher-level orchestration layers.
"""

from __future__ import annotations

__all__ = ()
