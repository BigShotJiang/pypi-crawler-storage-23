"""Input source resolution + payload assembly for `agenterm run`."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.commands.run_support import RunInputBundle, resolve_source
from agenterm.core.errors import ConfigError
from agenterm.engine.input_payload import build_from_prompt_and_attachments

if TYPE_CHECKING:
    from agenterm.commands.cli_args import RunCliArgs
    from agenterm.config.model import AppConfig

NO_INPUT_MESSAGE = "no input (pass PROMPT or pipe stdin)"
MULTI_INPUT_MESSAGE = "Choose a single input source: PROMPTs | --file FILE | stdin."


class RunUsageError(Exception):
    """User-facing usage error for run input resolution."""


def _read_prompt_lines(kind: str, value: str | list[str] | Path | None) -> list[str]:
    if kind == "prompts":
        if not isinstance(value, list):
            msg = "Internal error: invalid PROMPTS value."
            raise ConfigError(msg)
        return [str(item) for item in value]
    if kind == "file":
        if not isinstance(value, Path):
            msg = "Internal error: invalid --file value."
            raise ConfigError(msg)
        try:
            return value.read_text(encoding="utf-8").splitlines()
        except OSError as exc:
            msg = f"Failed to read --file: {exc}"
            raise ConfigError(msg) from exc
    return sys.stdin.read().splitlines()


def resolve_prompt_and_attachments(
    opts_parsed: RunCliArgs,
) -> tuple[str, tuple[str, ...]]:
    """Resolve prompt text + attachments from CLI inputs."""
    source = resolve_source(
        prompts=list(opts_parsed.prompts) if opts_parsed.prompts is not None else None,
        file=opts_parsed.file,
    )
    if source is None:
        raise RunUsageError(NO_INPUT_MESSAGE)
    source_kind, source_value = source
    if source_kind == "error":
        raise RunUsageError(MULTI_INPUT_MESSAGE)
    prompt = "\n".join(_read_prompt_lines(source_kind, source_value)).strip()
    attachments = tuple(opts_parsed.attachments or ())
    if not prompt and not attachments:
        raise RunUsageError(NO_INPUT_MESSAGE)
    return prompt, attachments


async def build_input_bundle(
    *,
    cfg: AppConfig,
    model_id: str,
    prompt: str,
    attachments: tuple[str, ...],
) -> RunInputBundle:
    """Build run input bundle from prompt + attachments."""
    input_items = await build_from_prompt_and_attachments(
        cfg=cfg,
        model_id=model_id,
        prompt=prompt,
        attachments=list(attachments),
        max_text_bytes=None,
    )
    return RunInputBundle(
        prompt=prompt,
        attachments=attachments,
        input_items=list(input_items),
    )


__all__ = (
    "RunUsageError",
    "build_input_bundle",
    "resolve_prompt_and_attachments",
)
