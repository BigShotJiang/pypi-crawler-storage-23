"""Steward task input models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


type StewardTaskKind = Literal["snapshot", "compaction"]


@dataclass(frozen=True)
class TurnRange:
    """Inclusive turn bounds for steward snapshot tasks."""

    start: int
    end: int


@dataclass(frozen=True)
class StewardSnapshotTaskInput:
    """Validated steward.snapshot task input."""

    session_id: str
    branch_id: str
    turn_range: TurnRange | None
    model: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe task payload."""
        return {
            "schema_version": 1,
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "turn_range": (
                {"start": self.turn_range.start, "end": self.turn_range.end}
                if self.turn_range is not None
                else None
            ),
            "model": self.model,
        }


@dataclass(frozen=True)
class StewardCompactionTaskInput:
    """Validated steward.compaction task input."""

    session_id: str
    branch_id: str
    model: str
    instructions: str | None
    input_items: tuple[dict[str, JSONValue], ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe task payload."""
        return {
            "schema_version": 1,
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "model": self.model,
            "instructions": self.instructions,
            "input_items": [dict(item) for item in self.input_items],
        }


__all__ = (
    "StewardCompactionTaskInput",
    "StewardSnapshotTaskInput",
    "StewardTaskKind",
    "TurnRange",
)
