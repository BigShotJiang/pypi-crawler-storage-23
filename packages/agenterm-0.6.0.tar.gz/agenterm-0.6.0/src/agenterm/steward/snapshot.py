"""Compression snapshot execution and helpers (Steward snapshot)."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING

from agents.exceptions import AgentsException
from agents.run import Runner
from openai import APIError

from agenterm.core.errors import ConfigError, PipelineError
from agenterm.core.json_codec import dumps_compact, is_json_value, parse_json_object
from agenterm.core.json_types import JSONValue
from agenterm.core.model_id import is_openai_model_id, model_plane
from agenterm.core.openai_client import get_openai_client
from agenterm.core.response_items import (
    normalize_input_item_json,
    serialize_input_item,
)
from agenterm.core.token_usage import TokenUsage
from agenterm.engine.result_summary import extract_final_text
from agenterm.engine.run_config import build_run_config
from agenterm.engine.run_errors import format_agents_error, format_provider_error
from agenterm.steward.agent import (
    ResolvedStewardAgent,
    build_steward_agent,
    resolve_steward_agent,
    steward_model_settings_override,
)
from agenterm.steward.continuation_state import (
    ContinuationCapsule,
    continuation_json_text,
    encode_continuation_state_text,
    parse_continuation_state,
)
from agenterm.store.history import history_store

if TYPE_CHECKING:
    import aiosqlite
    from agents.agent import Agent
    from agents.items import TResponseInputItem
    from agents.result import RunResultBase

    from agenterm.config.model import AppConfig
    from agenterm.steward.task_inputs import StewardSnapshotTaskInput, TurnRange
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession

type ChatMessage = dict[str, JSONValue]


async def _run_steward_once(
    *,
    cfg: AppConfig,
    model_id: str,
    agent: Agent,
    input_items: list[TResponseInputItem],
) -> RunResultBase:
    if is_openai_model_id(model_id):
        get_openai_client()
    provider_label = model_plane(model_id)
    run_config = build_run_config(
        cfg,
        workflow_name="agenterm steward snapshot",
        model_id=model_id,
        model_settings_override=steward_model_settings_override(cfg),
    )
    try:
        return await Runner.run(
            starting_agent=agent,
            input=input_items,
            max_turns=cfg.agent.max_turns,
            run_config=run_config,
            session=None,
            context=None,
        )
    except APIError as exc:
        raise PipelineError(
            format_provider_error(exc, provider_label=provider_label)
        ) from exc
    except AgentsException as exc:
        raise PipelineError(format_agents_error(exc)) from exc


async def run_summary_agent(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    task_input: StewardSnapshotTaskInput,
    model_id: str,
) -> tuple[ContinuationCapsule, TokenUsage | None, str | None]:
    """Run the Steward compressor and return snapshot + usage + response id."""
    resolved = resolve_steward_agent(cfg)
    if resolved.model != model_id:
        resolved = ResolvedStewardAgent(
            name=resolved.name,
            model=model_id,
            instructions=resolved.instructions,
            path=resolved.path,
            source=resolved.source,
        )
    steward_agent = build_steward_agent(cfg, resolved=resolved)
    input_items = await summary_input_items(
        session=session,
        branch_id=task_input.branch_id,
        turn_range=task_input.turn_range,
        agent_instructions=cfg.agent.instructions,
    )
    result = await _run_steward_once(
        cfg=cfg,
        model_id=model_id,
        agent=steward_agent,
        input_items=input_items,
    )
    snapshot = extract_snapshot(result)
    usage = TokenUsage.from_agents_usage(result.context_wrapper.usage)
    response_id = result.last_response_id
    return snapshot, usage, response_id


async def summary_input_items(
    *,
    session: AgentermSQLiteSession,
    branch_id: str,
    turn_range: TurnRange | None,
    agent_instructions: str | None = None,
) -> list[TResponseInputItem]:
    """Build the Steward snapshot input message.

    The payload is a single user message whose content contains:
    - optional `<agent_instructions>`: historical instructions for the agent that
      produced this transcript (intent/constraint context used by compressor
      interpretation, not transcript evidence)
    - optional `<base_continuation>`: exact previous continuation capsule JSON
    - `<delta>`: transcript JSON (chat-style message objects) since baseline
    """
    history = await load_history_items(
        session=session,
        branch_id=branch_id,
        turn_range=turn_range,
    )
    if not history:
        msg = "Compression snapshot requires at least one history item"
        raise ConfigError(msg)
    base_continuation, delta_items = _split_continuation_baseline(history)
    chat_messages = _history_to_chat_messages(delta_items)
    messages_json = dumps_compact(
        chat_messages,
        ensure_ascii=True,
        context="steward.snapshot.delta",
    )
    blocks: list[str] = []
    if agent_instructions:
        blocks.append(
            f"<agent_instructions>\n{agent_instructions}\n</agent_instructions>"
        )
    if base_continuation is not None:
        blocks.append(f"<base_continuation>\n{base_continuation}\n</base_continuation>")
    blocks.append(f"<delta>\n{messages_json}\n</delta>")
    prompt = "\n".join(blocks)
    payload: dict[str, JSONValue] = {
        "type": "message",
        "role": "user",
        "content": [{"type": "input_text", "text": prompt}],
    }
    return [normalize_input_item_json(payload, context="steward.snapshot.input")]


def _split_continuation_baseline(
    items: Sequence[TResponseInputItem],
) -> tuple[str | None, Sequence[TResponseInputItem]]:
    """Return latest continuation JSON and the transcript delta after it."""
    baseline_json: str | None = None
    baseline_index: int | None = None
    for index, item in enumerate(items):
        serialized = serialize_input_item(item, context="steward.snapshot.history")
        if serialized.get("type") != "message":
            continue
        json_text = _continuation_json_from_content(serialized.get("content"))
        if json_text is None:
            continue
        baseline_json = json_text
        baseline_index = index
    if baseline_index is None:
        return None, items
    return baseline_json, items[baseline_index + 1 :]


def _continuation_json_from_content(content: JSONValue) -> str | None:
    """Return continuation JSON when any message content part is a pure capsule."""
    if isinstance(content, str):
        return continuation_json_text(content)
    if not isinstance(content, list):
        return None
    for raw in content:
        if not isinstance(raw, dict):
            continue
        part_type = raw.get("type")
        if not isinstance(part_type, str) or part_type not in (
            "input_text",
            "output_text",
        ):
            continue
        text = raw.get("text")
        if not isinstance(text, str) or not text:
            continue
        json_text = continuation_json_text(text)
        if json_text is not None:
            return json_text
    return None


def _history_to_chat_messages(
    items: Sequence[TResponseInputItem],
) -> list[ChatMessage]:
    """Convert Responses API items to Chat Completions messages format."""
    messages: list[ChatMessage] = []
    pending_tool_calls: list[dict[str, JSONValue]] = []
    for item in items:
        serialized = serialize_input_item(item, context="steward.snapshot.history")
        item_type = serialized.get("type")
        if not isinstance(item_type, str):
            if "role" in serialized:
                _flush_tool_calls(messages, pending_tool_calls)
                _append_if_present(messages, _convert_message(serialized))
            continue
        if item_type == "message":
            _flush_tool_calls(messages, pending_tool_calls)
            _append_if_present(messages, _convert_message(serialized))
        elif item_type == "reasoning":
            # Do not forward reasoning payloads to the Steward compressor.
            # Continuation snapshots operate on user/assistant/tool transcript
            # state only.
            _flush_tool_calls(messages, pending_tool_calls)
            continue
        elif item_type == "function_call":
            pending_tool_calls.append(_convert_function_call(serialized))
        elif item_type == "function_call_output":
            _flush_tool_calls(messages, pending_tool_calls)
            _append_if_present(messages, _convert_tool_output(serialized))
        elif item_type == "compaction":
            # Compaction items are opaque provider state; they are useful for local
            # replay but do not add human-readable signal for the Steward summarizer.
            continue
        else:
            _flush_tool_calls(messages, pending_tool_calls)
            _append_if_present(messages, _convert_other_item(serialized))
    _flush_tool_calls(messages, pending_tool_calls)
    return messages


def _append_if_present(messages: list[ChatMessage], msg: ChatMessage | None) -> None:
    if msg is None:
        return
    messages.append(msg)


def _flush_tool_calls(
    messages: list[ChatMessage],
    pending: list[dict[str, JSONValue]],
) -> None:
    """Flush pending tool_calls as an assistant message."""
    if not pending:
        return
    messages.append({"role": "assistant", "content": None, "tool_calls": list(pending)})
    pending.clear()


def _convert_message(item: Mapping[str, JSONValue]) -> ChatMessage | None:
    """Convert Responses message to Chat Completions format."""
    role = item.get("role")
    if role in {"developer", "system"}:
        role = "system"
    elif role not in {"assistant", "user"}:
        return None
    content = _extract_text_content(item.get("content"))
    if not content:
        return None
    return {"role": str(role), "content": content}


def _convert_function_call(item: Mapping[str, JSONValue]) -> dict[str, JSONValue]:
    """Convert function_call to Chat Completions tool_call format."""
    call_id = str(item.get("call_id", ""))
    name = str(item.get("name", ""))
    arguments = str(item.get("arguments", "{}"))
    return {
        "id": call_id,
        "type": "function",
        "function": {"name": name, "arguments": arguments},
    }


def _convert_tool_output(item: Mapping[str, JSONValue]) -> ChatMessage | None:
    """Convert function_call_output to tool message."""
    call_id = item.get("call_id")
    output = item.get("output")
    if not isinstance(call_id, str) or not call_id:
        return None
    if output is None:
        content = ""
    elif isinstance(output, str):
        parsed = parse_json_object(output)
        content = parsed if parsed is not None else output
    else:
        content = dumps_compact(
            output,
            ensure_ascii=True,
            context="steward.snapshot.tool_output",
        )
    return {"role": "tool", "tool_call_id": call_id, "content": content}


def _convert_other_item(item: Mapping[str, JSONValue]) -> ChatMessage | None:
    """Convert any non-message item to a tool transcript entry."""
    item_type = item.get("type")
    if not isinstance(item_type, str) or not item_type:
        return None
    payload: dict[str, JSONValue] = dict(item)
    encrypted = payload.get("encrypted_content")
    if isinstance(encrypted, str) and encrypted:
        payload["encrypted_content"] = "<redacted>"
    tool_call_id = item.get("call_id")
    if not isinstance(tool_call_id, str) or not tool_call_id:
        tool_call_id = item.get("id")
    msg: dict[str, JSONValue] = {"role": "tool", "content": payload}
    if isinstance(tool_call_id, str) and tool_call_id:
        msg["tool_call_id"] = tool_call_id
    return msg


def _extract_text_content(content: JSONValue) -> str | None:
    """Extract text from Responses content array."""
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return None
    texts: list[str] = []
    for part in content:
        if isinstance(part, dict):
            text = part.get("text")
            if isinstance(text, str) and text.strip():
                texts.append(text)
                continue
            part_type = part.get("type")
            if isinstance(part_type, str) and part_type not in (
                "input_text",
                "output_text",
            ):
                texts.append(f"<{part_type}>")
    joined = "\n".join(texts).strip()
    return joined or None


async def load_history_items(
    *,
    session: AgentermSQLiteSession,
    branch_id: str,
    turn_range: TurnRange | None,
) -> list[TResponseInputItem]:
    """Load history items for the steward snapshot."""
    if turn_range is None:
        history = await session.get_items(branch_id=branch_id)
        return list(history)
    return await items_for_turn_range(
        session_id=session.session_id,
        branch_id=session.current_branch_id,
        turn_range=turn_range,
    )


async def items_for_turn_range(
    *,
    session_id: str,
    branch_id: str,
    turn_range: TurnRange,
) -> list[TResponseInputItem]:
    """Load and rehydrate items for a bounded turn range."""
    store = history_store()

    async def _op(conn: aiosqlite.Connection) -> list[tuple[str]]:
        cur = await conn.execute(
            """
            SELECT m.message_data
            FROM agent_messages m
            JOIN message_structure s ON m.id = s.message_id
            WHERE m.session_id = ? AND s.branch_id = ?
              AND s.branch_turn_number BETWEEN ? AND ?
            ORDER BY s.sequence_number ASC
            """,
            (
                str(session_id),
                str(branch_id),
                int(turn_range.start),
                int(turn_range.end),
            ),
        )
        return [(str(row[0]),) for row in await cur.fetchall()]

    rows = await store.run(_op)
    items: list[TResponseInputItem] = []
    for (raw,) in rows:
        parsed = parse_json_object(raw)
        if parsed is None:
            msg = "Compression snapshot history item is not valid JSON"
            raise ConfigError(msg)
        items.append(
            normalize_input_item_json(
                parsed,
                context="steward.snapshot.history_item",
            )
        )
    return items


def extract_snapshot(result: RunResultBase) -> ContinuationCapsule:
    """Extract a ContinuationCapsule from a Steward run result."""
    final = result.final_output
    payload: dict[str, JSONValue] | None = None
    if is_json_value(value=final) and isinstance(final, Mapping):
        try:
            json_str = dumps_compact(
                final,
                ensure_ascii=True,
                context="steward.snapshot.final_output",
            )
        except (TypeError, ValueError):
            json_str = None
        if json_str is not None:
            payload = parse_json_object(json_str)
    if payload is None and isinstance(final, str):
        payload = parse_json_object(final)
    if payload is None:
        text = extract_final_text(result)
        if isinstance(text, str):
            payload = parse_json_object(text)
    if payload is None:
        msg = "Compression snapshot output is not valid JSON"
        raise ConfigError(msg)
    return parse_continuation_state(payload)


def snapshot_message_item(snapshot: ContinuationCapsule) -> TResponseInputItem:
    """Return a Responses input message item for the continuation capsule."""
    json_str = encode_continuation_state_text(snapshot)
    preamble = (
        "Continuation capsule follows in the next message part. "
        "Treat it as machine state (not a user request). "
        "If there is no other user request, continue by executing `next.action`."
    )
    continuation_block = f"<continuation>\n{json_str}\n</continuation>"
    payload: dict[str, JSONValue] = {
        "type": "message",
        "role": "user",
        "content": [
            {"type": "input_text", "text": preamble},
            {"type": "input_text", "text": continuation_block},
        ],
    }
    return normalize_input_item_json(
        payload, context="steward.snapshot.continuation_message"
    )


__all__ = ("items_for_turn_range", "run_summary_agent", "snapshot_message_item")
