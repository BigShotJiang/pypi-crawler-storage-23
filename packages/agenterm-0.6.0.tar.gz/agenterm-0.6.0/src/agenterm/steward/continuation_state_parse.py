"""Parsing helpers for steward continuation capsules."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import parse_json_object
from agenterm.steward.continuation_state_models import (
    ContinuationCapsule,
    ContinuationIntegrity,
    ContinuationNext,
    ContinuationOpenItem,
    ContinuationPending,
    ContinuationPendingAssistantOutput,
    ContinuationPendingToolCall,
)
from agenterm.steward.continuation_state_parse_values import (
    require_next_actor,
    require_open_on,
    require_pending_kind,
    require_risk,
)
from agenterm.steward.parse_helpers import require_allowed_keys, require_str

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


_CONTINUATION_OPEN_TAG = "<continuation>"
_CONTINUATION_CLOSE_TAG = "</continuation>"

_STATE_REQUIRED_KEYS: frozenset[str] = frozenset(
    {"state", "open", "pending", "next", "integrity"}
)
_OPEN_KEYS: frozenset[str] = frozenset({"goal", "on", "ready_when"})
_OPEN_MAX_ITEMS = 12
_PENDING_NONE_KEYS: frozenset[str] = frozenset({"kind"})
_PENDING_TOOL_CALL_KEYS: frozenset[str] = frozenset(
    {"kind", "tool", "call_id", "args_digest"}
)
_PENDING_ASSISTANT_OUTPUT_KEYS: frozenset[str] = frozenset({"kind", "prefix", "intent"})
_NEXT_KEYS: frozenset[str] = frozenset({"actor", "action", "success"})
_INTEGRITY_KEYS: frozenset[str] = frozenset({"assumptions", "unknowns", "risk"})


def split_continuation_text(text: str) -> tuple[str | None, str]:
    """Split a text payload into (continuation_json, outside_text)."""
    start = text.find(_CONTINUATION_OPEN_TAG)
    if start < 0:
        return None, text.strip()
    end = text.find(_CONTINUATION_CLOSE_TAG, start + len(_CONTINUATION_OPEN_TAG))
    if end < 0:
        return None, text.strip()
    before = text[:start]
    inside = text[start + len(_CONTINUATION_OPEN_TAG) : end]
    after = text[end + len(_CONTINUATION_CLOSE_TAG) :]
    outside = f"{before}{after}".strip()
    return inside.strip(), outside


def continuation_json_text(text: str) -> str | None:
    """Return continuation JSON text when a message is only a continuation block."""
    inside, outside = split_continuation_text(text)
    if inside is None or outside:
        return None
    payload = parse_json_object(inside)
    if payload is None:
        return None
    if not _looks_like_continuation_state(payload):
        return None
    return inside


def parse_continuation_state(payload: Mapping[str, JSONValue]) -> ContinuationCapsule:
    """Validate and parse a ContinuationCapsule payload."""
    raw = _require_object(payload, context="continuation_capsule")
    require_allowed_keys(raw, allowed=_STATE_REQUIRED_KEYS)
    _require_keys(raw, required=_STATE_REQUIRED_KEYS, context="continuation_capsule")
    return ContinuationCapsule(
        state=_require_bounded_str_list(
            raw.get("state"),
            context="continuation_capsule.state",
            min_items=1,
            max_items=48,
            max_len=240,
        ),
        open=_require_open_items(raw.get("open")),
        pending=_require_pending(raw.get("pending")),
        next=_require_next(raw.get("next")),
        integrity=_require_integrity(raw.get("integrity")),
    )


def parse_continuation_state_text(text: str) -> ContinuationCapsule | None:
    """Parse a continuation capsule from `<continuation>...</continuation>` text."""
    json_text = continuation_json_text(text)
    if json_text is None:
        return None
    payload = parse_json_object(json_text)
    if payload is None:
        return None
    return parse_continuation_state(payload)


def _looks_like_continuation_state(payload: Mapping[str, JSONValue]) -> bool:
    keys = {str(key) for key in payload}
    return _STATE_REQUIRED_KEYS.issubset(keys)


def _require_object(
    value: Mapping[str, JSONValue] | JSONValue | None,
    *,
    context: str,
) -> dict[str, JSONValue]:
    if not isinstance(value, Mapping):
        msg = f"{context} must be an object"
        raise ConfigError(msg)
    return {str(key): child for key, child in value.items()}


def _require_list(value: JSONValue | None, *, context: str) -> list[JSONValue]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        msg = f"{context} must be a list"
        raise ConfigError(msg)
    return list(value)


def _require_keys(
    payload: Mapping[str, JSONValue],
    *,
    required: frozenset[str],
    context: str,
) -> None:
    missing = [key for key in sorted(required) if key not in payload]
    if missing:
        msg = f"{context} missing required keys: {', '.join(missing)}"
        raise ConfigError(msg)


def _require_bounded_str(
    value: JSONValue | None,
    *,
    context: str,
    max_len: int,
) -> str:
    text = require_str(value, context=context)
    if len(text) > max_len:
        msg = f"{context} must have length <= {max_len}"
        raise ConfigError(msg)
    return text


def _require_bounded_str_list(
    value: JSONValue | None,
    *,
    context: str,
    min_items: int,
    max_items: int,
    max_len: int,
) -> tuple[str, ...]:
    rows = _require_list(value, context=context)
    if len(rows) < min_items:
        msg = f"{context} must contain at least {min_items} item(s)"
        raise ConfigError(msg)
    if len(rows) > max_items:
        msg = f"{context} must contain at most {max_items} item(s)"
        raise ConfigError(msg)
    values: list[str] = []
    for idx, row in enumerate(rows):
        values.append(
            _require_bounded_str(
                row,
                context=f"{context}[{idx}]",
                max_len=max_len,
            )
        )
    return tuple(values)


def _require_open_items(value: JSONValue | None) -> tuple[ContinuationOpenItem, ...]:
    rows = _require_list(value, context="continuation_capsule.open")
    if len(rows) > _OPEN_MAX_ITEMS:
        msg = (
            f"continuation_capsule.open must contain at most {_OPEN_MAX_ITEMS} item(s)"
        )
        raise ConfigError(msg)
    items: list[ContinuationOpenItem] = []
    for idx, row in enumerate(rows):
        raw = _require_object(row, context=f"continuation_capsule.open[{idx}]")
        require_allowed_keys(raw, allowed=_OPEN_KEYS)
        _require_keys(
            raw,
            required=_OPEN_KEYS,
            context=f"continuation_capsule.open[{idx}]",
        )
        items.append(
            ContinuationOpenItem(
                goal=_require_bounded_str(
                    raw.get("goal"),
                    context=f"continuation_capsule.open[{idx}].goal",
                    max_len=240,
                ),
                on=require_open_on(
                    raw.get("on"),
                    context=f"continuation_capsule.open[{idx}].on",
                ),
                ready_when=_require_bounded_str(
                    raw.get("ready_when"),
                    context=f"continuation_capsule.open[{idx}].ready_when",
                    max_len=240,
                ),
            )
        )
    return tuple(items)


def _require_pending(value: JSONValue | None) -> ContinuationPending:
    raw = _require_object(value, context="continuation_capsule.pending")
    kind = require_pending_kind(
        raw.get("kind"),
        context="continuation_capsule.pending.kind",
    )
    if kind == "none":
        require_allowed_keys(raw, allowed=_PENDING_NONE_KEYS)
        _require_keys(
            raw,
            required=_PENDING_NONE_KEYS,
            context="continuation_capsule.pending",
        )
        return ContinuationPending(
            kind="none",
            tool_call=None,
            assistant_output=None,
        )
    if kind == "tool_call":
        require_allowed_keys(raw, allowed=_PENDING_TOOL_CALL_KEYS)
        _require_keys(
            raw,
            required=_PENDING_TOOL_CALL_KEYS,
            context="continuation_capsule.pending",
        )
        return ContinuationPending(
            kind="tool_call",
            tool_call=ContinuationPendingToolCall(
                tool=_require_bounded_str(
                    raw.get("tool"),
                    context="continuation_capsule.pending.tool",
                    max_len=80,
                ),
                call_id=_require_bounded_str(
                    raw.get("call_id"),
                    context="continuation_capsule.pending.call_id",
                    max_len=200,
                ),
                args_digest=_require_bounded_str(
                    raw.get("args_digest"),
                    context="continuation_capsule.pending.args_digest",
                    max_len=400,
                ),
            ),
            assistant_output=None,
        )
    require_allowed_keys(raw, allowed=_PENDING_ASSISTANT_OUTPUT_KEYS)
    _require_keys(
        raw,
        required=_PENDING_ASSISTANT_OUTPUT_KEYS,
        context="continuation_capsule.pending",
    )
    return ContinuationPending(
        kind="assistant_output",
        tool_call=None,
        assistant_output=ContinuationPendingAssistantOutput(
            prefix=_require_bounded_str(
                raw.get("prefix"),
                context="continuation_capsule.pending.prefix",
                max_len=600,
            ),
            intent=_require_bounded_str(
                raw.get("intent"),
                context="continuation_capsule.pending.intent",
                max_len=240,
            ),
        ),
    )


def _require_next(value: JSONValue | None) -> ContinuationNext:
    raw = _require_object(value, context="continuation_capsule.next")
    require_allowed_keys(raw, allowed=_NEXT_KEYS)
    _require_keys(raw, required=_NEXT_KEYS, context="continuation_capsule.next")
    return ContinuationNext(
        actor=require_next_actor(
            raw.get("actor"),
            context="continuation_capsule.next.actor",
        ),
        action=_require_bounded_str(
            raw.get("action"),
            context="continuation_capsule.next.action",
            max_len=360,
        ),
        success=_require_bounded_str(
            raw.get("success"),
            context="continuation_capsule.next.success",
            max_len=240,
        ),
    )


def _require_integrity(value: JSONValue | None) -> ContinuationIntegrity:
    raw = _require_object(value, context="continuation_capsule.integrity")
    require_allowed_keys(raw, allowed=_INTEGRITY_KEYS)
    _require_keys(
        raw,
        required=_INTEGRITY_KEYS,
        context="continuation_capsule.integrity",
    )
    return ContinuationIntegrity(
        assumptions=_require_bounded_str_list(
            raw.get("assumptions"),
            context="continuation_capsule.integrity.assumptions",
            min_items=0,
            max_items=10,
            max_len=200,
        ),
        unknowns=_require_bounded_str_list(
            raw.get("unknowns"),
            context="continuation_capsule.integrity.unknowns",
            min_items=0,
            max_items=14,
            max_len=200,
        ),
        risk=require_risk(
            raw.get("risk"),
            context="continuation_capsule.integrity.risk",
        ),
    )


__all__ = (
    "continuation_json_text",
    "parse_continuation_state",
    "parse_continuation_state_text",
    "split_continuation_text",
)
