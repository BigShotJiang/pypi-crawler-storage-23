"""Continuation capsule model and parsing (Steward snapshot continuation)."""

from __future__ import annotations

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import dumps_compact, is_json_value
from agenterm.steward.continuation_state_models import (
    ContinuationCapsule,
    ContinuationIntegrity,
    ContinuationNext,
    ContinuationNextActor,
    ContinuationOpenItem,
    ContinuationOpenOn,
    ContinuationPending,
    ContinuationPendingAssistantOutput,
    ContinuationPendingKind,
    ContinuationPendingToolCall,
    ContinuationRisk,
)
from agenterm.steward.continuation_state_parse import (
    continuation_json_text,
    parse_continuation_state,
    parse_continuation_state_text,
    split_continuation_text,
)


def encode_continuation_state_text(state: ContinuationCapsule) -> str:
    """Return canonical JSON text for a continuation capsule message."""
    payload = state.to_json()
    if not is_json_value(value=payload):
        msg = "ContinuationCapsule payload is not JSON-safe"
        raise ConfigError(msg)
    try:
        return dumps_compact(
            payload,
            sort_keys=True,
            ensure_ascii=True,
            context="steward.continuation_state.encode",
        )
    except (TypeError, ValueError) as exc:
        msg = f"Failed to encode ContinuationCapsule JSON: {exc}"
        raise ConfigError(msg) from exc


__all__ = (
    "ContinuationCapsule",
    "ContinuationIntegrity",
    "ContinuationNext",
    "ContinuationNextActor",
    "ContinuationOpenItem",
    "ContinuationOpenOn",
    "ContinuationPending",
    "ContinuationPendingAssistantOutput",
    "ContinuationPendingKind",
    "ContinuationPendingToolCall",
    "ContinuationRisk",
    "continuation_json_text",
    "encode_continuation_state_text",
    "parse_continuation_state",
    "parse_continuation_state_text",
    "split_continuation_text",
)
