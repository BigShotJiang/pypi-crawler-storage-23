"""Typed models for steward continuation capsules."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


type ContinuationOpenOn = Literal["user", "assistant", "tool", "none"]
type ContinuationPendingKind = Literal["none", "tool_call", "assistant_output"]
type ContinuationNextActor = Literal["assistant", "user", "tool"]
type ContinuationRisk = Literal["low", "medium", "high"]


@dataclass(frozen=True)
class ContinuationOpenItem:
    """Unresolved item that continuation should advance."""

    goal: str
    on: ContinuationOpenOn
    ready_when: str

    def to_json(self) -> dict[str, JSONValue]:
        """Return JSON-safe payload for one unresolved continuation item."""
        return {
            "goal": self.goal,
            "on": self.on,
            "ready_when": self.ready_when,
        }


@dataclass(frozen=True)
class ContinuationPendingToolCall:
    """Pending tool-call boundary details."""

    tool: str
    call_id: str
    args_digest: str

    def to_json(self) -> dict[str, JSONValue]:
        """Return JSON-safe payload for pending tool-call boundary."""
        return {
            "tool": self.tool,
            "call_id": self.call_id,
            "args_digest": self.args_digest,
        }


@dataclass(frozen=True)
class ContinuationPendingAssistantOutput:
    """Pending assistant-output boundary details."""

    prefix: str
    intent: str

    def to_json(self) -> dict[str, JSONValue]:
        """Return JSON-safe payload for pending assistant-output boundary."""
        return {
            "prefix": self.prefix,
            "intent": self.intent,
        }


@dataclass(frozen=True)
class ContinuationPending:
    """Exact inflight boundary at compression cut-point."""

    kind: ContinuationPendingKind
    tool_call: ContinuationPendingToolCall | None
    assistant_output: ContinuationPendingAssistantOutput | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return JSON-safe payload for the pending boundary."""
        payload: dict[str, JSONValue] = {"kind": self.kind}
        if self.kind == "tool_call" and self.tool_call is not None:
            payload.update(self.tool_call.to_json())
        if self.kind == "assistant_output" and self.assistant_output is not None:
            payload.update(self.assistant_output.to_json())
        return payload


@dataclass(frozen=True)
class ContinuationNext:
    """One atomic next continuation step."""

    actor: ContinuationNextActor
    action: str
    success: str

    def to_json(self) -> dict[str, JSONValue]:
        """Return JSON-safe payload for next continuation action."""
        return {
            "actor": self.actor,
            "action": self.action,
            "success": self.success,
        }


@dataclass(frozen=True)
class ContinuationIntegrity:
    """Integrity envelope for assumptions, unknowns, and risk."""

    assumptions: tuple[str, ...]
    unknowns: tuple[str, ...]
    risk: ContinuationRisk

    def to_json(self) -> dict[str, JSONValue]:
        """Return JSON-safe payload for integrity metadata."""
        return {
            "assumptions": list(self.assumptions),
            "unknowns": list(self.unknowns),
            "risk": self.risk,
        }


@dataclass(frozen=True)
class ContinuationCapsule:
    """Parsed continuation capsule payload."""

    state: tuple[str, ...]
    open: tuple[ContinuationOpenItem, ...]
    pending: ContinuationPending
    next: ContinuationNext
    integrity: ContinuationIntegrity

    def to_json(self) -> dict[str, JSONValue]:
        """Return JSON-safe payload for a full continuation capsule."""
        return {
            "state": list(self.state),
            "open": [item.to_json() for item in self.open],
            "pending": self.pending.to_json(),
            "next": self.next.to_json(),
            "integrity": self.integrity.to_json(),
        }


__all__ = (
    "ContinuationCapsule",
    "ContinuationIntegrity",
    "ContinuationNext",
    "ContinuationNextActor",
    "ContinuationOpenItem",
    "ContinuationOpenOn",
    "ContinuationPending",
    "ContinuationPendingAssistantOutput",
    "ContinuationPendingKind",
    "ContinuationPendingToolCall",
    "ContinuationRisk",
)
