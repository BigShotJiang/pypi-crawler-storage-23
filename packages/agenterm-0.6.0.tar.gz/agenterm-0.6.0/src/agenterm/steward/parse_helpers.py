"""Shared JSON parsing helpers for Steward schemas."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


def require_allowed_keys(
    payload: Mapping[str, JSONValue],
    *,
    allowed: frozenset[str],
) -> None:
    """Raise ConfigError when payload contains unknown keys."""
    unknown = {str(k) for k in payload if str(k) not in allowed}
    if unknown:
        msg = f"Unknown keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)


def require_str(value: JSONValue | None, *, context: str) -> str:
    """Require a non-empty string."""
    if not isinstance(value, str) or not value.strip():
        msg = f"{context} must be a non-empty string"
        raise ConfigError(msg)
    return value


def optional_str(value: JSONValue | None, *, context: str) -> str | None:
    """Return a non-empty string or None; raise when the value is invalid."""
    if value is None:
        return None
    if isinstance(value, str) and value.strip():
        return value
    msg = f"{context} must be a non-empty string or null"
    raise ConfigError(msg)


def require_int(value: JSONValue | None, *, context: str) -> int:
    """Require an integer (or an integer-valued float), rejecting bools."""
    if isinstance(value, bool):
        msg = f"{context} must be an integer"
        raise ConfigError(msg)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    msg = f"{context} must be an integer"
    raise ConfigError(msg)


def require_str_list(value: JSONValue | None, *, context: str) -> tuple[str, ...]:
    """Require a JSON list of strings."""
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        msg = f"{context} must be a list of strings"
        raise ConfigError(msg)
    items: list[str] = []
    for item in value:
        if not isinstance(item, str):
            msg = f"{context} entries must be strings"
            raise ConfigError(msg)
        items.append(item)
    return tuple(items)


__all__ = (
    "optional_str",
    "require_allowed_keys",
    "require_int",
    "require_str",
    "require_str_list",
)
