"""Runtime helpers for Steward task execution."""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.config.paths import history_db_path
from agenterm.core.error_report import ErrorContext, build_error_report
from agenterm.core.errors import AgentermError, ConfigError, OperationCancelledError
from agenterm.core.hashing import sha256_text_or_none
from agenterm.engine.compaction import CompactionResult, compact
from agenterm.steward.compaction import parse_compaction_items
from agenterm.steward.snapshot import run_summary_agent, snapshot_message_item
from agenterm.store.branch.service import (
    create_compaction_branch,
    create_snapshot_branch,
)
from agenterm.store.history import history_store
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.steward.repo import (
    StewardTaskRecord,
    StewardTaskTrigger,
    finalize_steward_task,
    mark_steward_task_running,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Sequence

    from agents.items import TResponseInputItem

    from agenterm.config.model import AppConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.token_usage import TokenUsage
    from agenterm.steward.emitters import CompressionEmitters
    from agenterm.steward.task_inputs import (
        StewardCompactionTaskInput,
        StewardSnapshotTaskInput,
    )
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.branch.models import BranchMeta


_TASK_LOCKS: dict[str, asyncio.Lock] = {}


@dataclass(frozen=True)
class StewardTaskResult:
    """Result of a completed Steward task."""

    task: StewardTaskRecord
    branch_meta: BranchMeta
    usage: TokenUsage | None


def _lock_key(session_id: str, branch_id: str) -> str:
    return f"{session_id}:{branch_id}"


def _task_lock(session_id: str, branch_id: str) -> asyncio.Lock:
    key = _lock_key(session_id, branch_id)
    lock = _TASK_LOCKS.get(key)
    if lock is None:
        lock = asyncio.Lock()
        _TASK_LOCKS[key] = lock
    return lock


def new_task_id() -> str:
    """Return a new UUID string for Steward task ids."""
    return str(uuid.uuid4())


async def await_with_cancel[T](
    awaitable: Awaitable[T],
    *,
    cancel_token: CancelToken | None,
) -> T:
    """Await work while honoring cooperative cancellation and draining children."""
    if cancel_token is None:
        return await awaitable
    cancel_token.raise_if_cancelled()

    async def _runner() -> T:
        return await awaitable

    task: asyncio.Task[T] = asyncio.create_task(_runner())
    cancel_task: asyncio.Task[None] = asyncio.create_task(cancel_token.wait())
    try:
        done, _ = await asyncio.wait(
            {task, cancel_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        if cancel_task in done:
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
            raise OperationCancelledError
        cancel_task.cancel()
        await asyncio.gather(cancel_task, return_exceptions=True)
        return await task
    except asyncio.CancelledError:
        # Parent cancellation must drain child tasks so no detached task
        # can later surface as an unhandled event-loop exception.
        task.cancel()
        cancel_task.cancel()
        await asyncio.gather(task, cancel_task, return_exceptions=True)
        raise


async def open_task_session(
    *,
    session_id: str,
    branch_id: str,
) -> AgentermSQLiteSession:
    """Open a dedicated SQLite session for background Steward tasks."""
    session = AgentermSQLiteSession(
        session_id=session_id,
        db_path=str(history_db_path()),
        create_tables=True,
    )
    await ensure_task_branch(session=session, branch_id=branch_id)
    return session


async def ensure_task_branch(
    *,
    session: AgentermSQLiteSession,
    branch_id: str,
) -> None:
    """Ensure the SQLite session is on the requested branch."""
    if session.current_branch_id == branch_id:
        return
    try:
        await session.switch_to_branch(branch_id)
    except ValueError as exc:
        msg = f"Unknown branch_id for steward task: {branch_id!r}"
        raise ConfigError(msg) from exc


def effective_steward_model(*, cfg: AppConfig, override: str | None) -> str:
    """Resolve the effective Steward model for a task."""
    return override or cfg.steward.agent.model or cfg.agent.model


async def execute_snapshot_task(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    task: StewardTaskRecord,
    task_input: StewardSnapshotTaskInput,
    trigger: StewardTaskTrigger,
    emitters: CompressionEmitters | None,
    run_number: int | None,
    origin_branch_id: str,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    """Run a steward.snapshot task and persist its outcome."""
    async with _task_lock(task.session_id, task.branch_id):
        await mark_steward_task_running(store=store, task_id=task.task_id)
        try:
            if emitters is not None and emitters.emit_line is not None:
                emitters.emit_line("info> Compression (snapshot) started.")
            await ensure_task_branch(session=session, branch_id=task.branch_id)
            snapshot, usage, response_id = await await_with_cancel(
                run_summary_agent(
                    cfg=cfg,
                    session=session,
                    task_input=task_input,
                    model_id=effective_steward_model(
                        cfg=cfg, override=task_input.model
                    ),
                ),
                cancel_token=cancel_token,
            )
            snapshot_items = [snapshot_message_item(snapshot)]
            branch_meta = await create_snapshot_branch(
                session=session,
                store=store,
                history_store=history_store(),
                session_id=task.session_id,
                snapshot_items=snapshot_items,
                response_id=response_id,
                usage=usage,
                model=effective_steward_model(cfg=cfg, override=task_input.model),
                agent_name=cfg.agent.name,
                agent_path=cfg.agent.path,
                agent_sha256=sha256_text_or_none(cfg.agent.instructions),
                created_reason=_snapshot_reason(trigger),
                branch_id=None,
                run_number=run_number,
                usage_branch_id=origin_branch_id,
            )
        except asyncio.CancelledError:
            await finalize_steward_task(
                store=store,
                task_id=task.task_id,
                status="cancelled",
                snapshot_branch_id=None,
                response_id=None,
                error_payload=None,
            )
            raise
        except AgentermError as exc:
            await _fail_task(
                store=store,
                task=task,
                exc=exc,
                cfg=cfg,
                operation="steward.snapshot",
            )
            raise

        completed = await finalize_steward_task(
            store=store,
            task_id=task.task_id,
            status="completed",
            snapshot_branch_id=branch_meta.branch_id,
            response_id=response_id,
            error_payload=None,
        )
        if emitters is not None and emitters.emit_snapshot is not None:
            emitters.emit_snapshot(snapshot)
        if emitters is not None and emitters.emit_line is not None:
            emitters.emit_line("info> Compression (snapshot) complete.")
        return StewardTaskResult(task=completed, branch_meta=branch_meta, usage=usage)


async def run_compaction(
    *,
    input_items: Sequence[TResponseInputItem],
    cfg: AppConfig,
    model_id: str,
    instructions: str | None,
) -> CompactionResult:
    """Run Responses compaction over input items."""
    if not input_items:
        msg = "Compaction requires input items"
        raise ConfigError(msg)

    return await compact(
        input_items=list(input_items),
        cfg=cfg,
        model_id=model_id,
        instructions=instructions,
    )


async def execute_compaction_task(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    task: StewardTaskRecord,
    task_input: StewardCompactionTaskInput,
    emitters: CompressionEmitters | None,
    run_number: int | None,
    origin_branch_id: str,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    """Run a steward.compaction task and persist its outcome."""
    async with _task_lock(task.session_id, task.branch_id):
        await mark_steward_task_running(store=store, task_id=task.task_id)
        try:
            if emitters is not None and emitters.emit_line is not None:
                emitters.emit_line("info> Compression (compaction) started.")
            await ensure_task_branch(session=session, branch_id=task.branch_id)
            input_items = parse_compaction_items(task_input.input_items)
            result = await await_with_cancel(
                run_compaction(
                    input_items=input_items,
                    cfg=cfg,
                    model_id=task_input.model,
                    instructions=task_input.instructions,
                ),
                cancel_token=cancel_token,
            )
            branch_meta = await create_compaction_branch(
                session=session,
                store=store,
                history_store=history_store(),
                session_id=task.session_id,
                snapshot_items=result.snapshot_items,
                compaction_response_id=result.compaction_response_id,
                compaction_usage=result.usage,
                model=task_input.model,
                agent_name=cfg.agent.name,
                agent_path=cfg.agent.path,
                agent_sha256=sha256_text_or_none(cfg.agent.instructions),
                created_reason=_compaction_reason(task.trigger),
                branch_id=None,
                run_number=run_number,
                usage_branch_id=origin_branch_id,
            )
        except asyncio.CancelledError:
            await finalize_steward_task(
                store=store,
                task_id=task.task_id,
                status="cancelled",
                snapshot_branch_id=None,
                response_id=None,
                error_payload=None,
            )
            raise
        except AgentermError as exc:
            await _fail_task(
                store=store,
                task=task,
                exc=exc,
                cfg=cfg,
                operation="steward.compaction",
            )
            raise

        completed = await finalize_steward_task(
            store=store,
            task_id=task.task_id,
            status="completed",
            snapshot_branch_id=branch_meta.branch_id,
            response_id=result.compaction_response_id,
            error_payload=None,
        )
        if emitters is not None and emitters.emit_compaction is not None:
            emitters.emit_compaction(result.snapshot_items)
        if emitters is not None and emitters.emit_line is not None:
            emitters.emit_line("info> Compression (compaction) complete.")
        return StewardTaskResult(
            task=completed,
            branch_meta=branch_meta,
            usage=result.usage,
        )


def _snapshot_reason(trigger: StewardTaskTrigger) -> str:
    if trigger == "auto":
        return "auto_snapshot"
    if trigger == "tool":
        return "tool_snapshot"
    return "manual_snapshot"


def _compaction_reason(trigger: StewardTaskTrigger) -> str:
    if trigger == "auto":
        return "auto_compaction"
    if trigger == "tool":
        return "tool_compaction"
    return "manual_compaction"


async def _fail_task(
    *,
    store: AsyncStore,
    task: StewardTaskRecord,
    exc: AgentermError,
    cfg: AppConfig,
    operation: str,
) -> None:
    report = build_error_report(
        exc,
        context=ErrorContext(
            operation=operation,
            resource=operation,
            trace_id=cfg.run.trace_id,
        ),
    )
    await finalize_steward_task(
        store=store,
        task_id=task.task_id,
        status="failed",
        snapshot_branch_id=None,
        response_id=None,
        error_payload=report.to_envelope().to_json(),
    )


__all__ = (
    "StewardTaskResult",
    "await_with_cancel",
    "effective_steward_model",
    "ensure_task_branch",
    "execute_compaction_task",
    "execute_snapshot_task",
    "new_task_id",
    "open_task_session",
    "run_compaction",
)
