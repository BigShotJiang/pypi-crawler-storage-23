"""Enum parsing helpers for ContinuationCapsule parsing."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue
    from agenterm.steward.continuation_state_models import (
        ContinuationNextActor,
        ContinuationOpenOn,
        ContinuationPendingKind,
        ContinuationRisk,
    )


def require_open_on(
    value: JSONValue | None,
    *,
    context: str,
) -> ContinuationOpenOn:
    """Return validated open-loop blocker owner."""
    if value == "user":
        return "user"
    if value == "assistant":
        return "assistant"
    if value == "tool":
        return "tool"
    if value == "none":
        return "none"
    msg = f"{context} must be one of: user|assistant|tool|none"
    raise ConfigError(msg)


def require_pending_kind(
    value: JSONValue | None,
    *,
    context: str,
) -> ContinuationPendingKind:
    """Return validated pending boundary kind."""
    if value == "none":
        return "none"
    if value == "tool_call":
        return "tool_call"
    if value == "assistant_output":
        return "assistant_output"
    msg = f"{context} must be one of: none|tool_call|assistant_output"
    raise ConfigError(msg)


def require_next_actor(
    value: JSONValue | None,
    *,
    context: str,
) -> ContinuationNextActor:
    """Return validated next-action actor."""
    if value == "assistant":
        return "assistant"
    if value == "user":
        return "user"
    if value == "tool":
        return "tool"
    msg = f"{context} must be one of: assistant|user|tool"
    raise ConfigError(msg)


def require_risk(value: JSONValue | None, *, context: str) -> ContinuationRisk:
    """Return validated integrity risk value."""
    if value == "low":
        return "low"
    if value == "medium":
        return "medium"
    if value == "high":
        return "high"
    msg = f"{context} must be one of: low|medium|high"
    raise ConfigError(msg)


__all__ = (
    "require_next_actor",
    "require_open_on",
    "require_pending_kind",
    "require_risk",
)
