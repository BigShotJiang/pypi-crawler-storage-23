"""Compression emitters for continuation display."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from agents.items import TResponseInputItem

    from agenterm.steward.continuation_state import ContinuationCapsule


@dataclass(frozen=True)
class CompressionEmitters:
    """Compression output hooks for UI surfaces."""

    emit_line: Callable[[str], None] | None = None
    emit_snapshot: Callable[[ContinuationCapsule], None] | None = None
    emit_compaction: Callable[[Sequence[TResponseInputItem]], None] | None = None


__all__ = ("CompressionEmitters",)
