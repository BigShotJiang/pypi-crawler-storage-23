"""Strict JSON schema for the Steward ContinuationCapsule output."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


CONTINUATION_CAPSULE_SCHEMA: dict[str, JSONValue] = {
    "name": "ContinuationCapsule",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "state": {
                "type": "array",
                "minItems": 1,
                "maxItems": 48,
                "items": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 240,
                },
            },
            "open": {
                "type": "array",
                "maxItems": 12,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "goal": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 240,
                        },
                        "on": {
                            "type": "string",
                            "enum": ["user", "assistant", "tool", "none"],
                        },
                        "ready_when": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 240,
                        },
                    },
                    "required": ["goal", "on", "ready_when"],
                },
            },
            "pending": {
                "anyOf": [
                    {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "kind": {
                                "type": "string",
                                "const": "none",
                            },
                        },
                        "required": ["kind"],
                    },
                    {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "kind": {
                                "type": "string",
                                "const": "tool_call",
                            },
                            "tool": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 80,
                            },
                            "call_id": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 200,
                            },
                            "args_digest": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 400,
                            },
                        },
                        "required": ["kind", "tool", "call_id", "args_digest"],
                    },
                    {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "kind": {
                                "type": "string",
                                "const": "assistant_output",
                            },
                            "prefix": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 600,
                            },
                            "intent": {
                                "type": "string",
                                "minLength": 1,
                                "maxLength": 240,
                            },
                        },
                        "required": ["kind", "prefix", "intent"],
                    },
                ]
            },
            "next": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "actor": {
                        "type": "string",
                        "enum": ["assistant", "user", "tool"],
                    },
                    "action": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 360,
                    },
                    "success": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 240,
                    },
                },
                "required": ["actor", "action", "success"],
            },
            "integrity": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "assumptions": {
                        "type": "array",
                        "maxItems": 10,
                        "items": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 200,
                        },
                    },
                    "unknowns": {
                        "type": "array",
                        "maxItems": 14,
                        "items": {
                            "type": "string",
                            "minLength": 1,
                            "maxLength": 200,
                        },
                    },
                    "risk": {
                        "type": "string",
                        "enum": ["low", "medium", "high"],
                    },
                },
                "required": ["assumptions", "unknowns", "risk"],
            },
        },
        "required": ["state", "open", "pending", "next", "integrity"],
    },
    "strict": True,
}


__all__ = ("CONTINUATION_CAPSULE_SCHEMA",)
