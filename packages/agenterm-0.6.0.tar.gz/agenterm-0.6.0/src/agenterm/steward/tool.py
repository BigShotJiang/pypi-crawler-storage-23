"""Steward tool construction (compression continuation integration)."""

from __future__ import annotations

import sqlite3
from collections.abc import Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.config.paths import history_db_path
from agenterm.core.errors import AgentermError, ConfigError, DatabaseError
from agenterm.core.json_codec import parse_json_object
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.tool_output_envelope import ToolOutputEnvelope, ToolOutputError
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_steward
from agenterm.steward.parse_helpers import (
    optional_str,
    require_allowed_keys,
    require_int,
)
from agenterm.steward.task_inputs import StewardTaskKind, TurnRange
from agenterm.steward.tasks import (
    StewardTaskResult,
    run_compaction_task,
    run_snapshot_task,
)
from agenterm.store.async_db import AsyncStore
from agenterm.store.session.agenterm_session import AgentermSQLiteSession

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.tool_context import ToolContext

    from agenterm.config.model import AppConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue


_INVALID_INPUT_KIND = "invalid_input"
_TOOL_ERROR_KIND = "tool_error"

_STEWARD_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Compression continuation request.",
    "properties": {
        "op": {"type": "string", "enum": ["snapshot", "compaction"]},
        "model": {"type": ["string", "null"], "minLength": 1},
        "turn_range": {
            "type": ["object", "null"],
            "description": "Inclusive turn bounds for snapshot compression.",
            "properties": {
                "start": {"type": "integer", "minimum": 1},
                "end": {"type": "integer", "minimum": 1},
            },
            "required": ["start", "end"],
            "additionalProperties": False,
        },
        "instructions": {"type": ["string", "null"], "minLength": 1},
    },
    "required": ["op", "model", "turn_range", "instructions"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class StewardArgs:
    """Parsed steward tool arguments."""

    task: StewardTaskKind
    turn_range: TurnRange | None
    model: str | None
    instructions: str | None


def _json_string_list(values: Sequence[str]) -> list[JSONValue]:
    items: list[JSONValue] = []
    items.extend(values)
    return items


def _error_output(
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    err = ToolOutputError(
        kind=kind,
        message=message,
        details=dict(details) if details is not None else {},
    )
    env = ToolOutputEnvelope(
        tool="steward",
        ok=False,
        result={},
        error=err,
    )
    return env.to_json_string()


def _parse_turn_range(value: JSONValue | None) -> TurnRange | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        msg = "steward.turn_range must be an object with start/end."
        raise ConfigError(msg)
    raw: dict[str, JSONValue] = {str(k): v for k, v in value.items()}
    require_allowed_keys(raw, allowed=frozenset({"start", "end"}))
    start = require_int(raw.get("start"), context="steward.turn_range.start")
    end = require_int(raw.get("end"), context="steward.turn_range.end")
    if start <= 0 or end <= 0:
        msg = "steward.turn_range.start/end must be positive integers."
        raise ConfigError(msg)
    if end < start:
        msg = "steward.turn_range.end must be >= steward.turn_range.start."
        raise ConfigError(msg)
    return TurnRange(start=start, end=end)


def _parse_payload(raw: str) -> tuple[StewardArgs | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, _error_output(
            kind=_INVALID_INPUT_KIND, message="Invalid steward payload."
        )
    unknown_keys = sorted(set(payload) - {"op", "model", "turn_range", "instructions"})
    if unknown_keys:
        return None, _error_output(
            kind=_INVALID_INPUT_KIND,
            message="Invalid steward payload.",
            details={
                "field": "/",
                "reason": "unknown_keys",
                "unknown_keys": _json_string_list(unknown_keys),
                "allowed_keys": _json_string_list(
                    ["instructions", "model", "op", "turn_range"]
                ),
            },
        )
    task_raw = payload.get("op")
    if task_raw not in ("snapshot", "compaction"):
        return None, _error_output(
            kind=_INVALID_INPUT_KIND,
            message="steward.op must be 'snapshot' or 'compaction'.",
            details={"field": "op", "reason": "invalid_enum"},
        )
    task: StewardTaskKind = task_raw
    try:
        model = optional_str(payload.get("model"), context="steward.model")
        instructions = optional_str(
            payload.get("instructions"),
            context="steward.instructions",
        )
        turn_range = _parse_turn_range(payload.get("turn_range"))
    except ConfigError as exc:
        return None, _error_output(kind=_INVALID_INPUT_KIND, message=str(exc))
    invalid_field: str | None = None
    invalid_message: str | None = None
    if task == "snapshot" and instructions is not None:
        invalid_field = "instructions"
        invalid_message = "steward.instructions is only valid for compaction."
    elif task == "compaction" and turn_range is not None:
        invalid_field = "turn_range"
        invalid_message = "steward.turn_range is only valid for snapshot."
    if invalid_field is not None and invalid_message is not None:
        must_be_null = ["instructions"] if task == "snapshot" else ["turn_range"]
        return None, _error_output(
            kind=_INVALID_INPUT_KIND,
            message=invalid_message,
            details={
                "field": invalid_field,
                "reason": "invalid_for_op",
                "op": task,
                "required_non_null": _json_string_list([]),
                "must_be_null": _json_string_list(must_be_null),
            },
        )
    return (
        StewardArgs(
            task=task,
            turn_range=turn_range,
            model=model,
            instructions=instructions,
        ),
        None,
    )


def _result_payload(result: StewardTaskResult) -> dict[str, JSONValue]:
    task = result.task
    return {
        "task_id": task.task_id,
        "op": task.kind,
        "session_id": task.session_id,
        "branch_id": task.branch_id,
        "snapshot_branch_id": result.branch_meta.branch_id,
        "response_id": task.response_id,
        "status": task.status,
        "next_action": None,
    }


def build_steward_tool(cfg: AppConfig) -> FunctionTool:
    """Return the Steward compressor as a strict FunctionTool."""
    validate_strict_schema("steward", _STEWARD_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext | None], raw: str) -> str:
        args, error = _parse_payload(raw)
        if error is not None:
            return error
        if args is None:
            return _error_output(
                kind=_INVALID_INPUT_KIND,
                message="Invalid steward payload.",
            )
        tool_ctx = ctx.context
        if not isinstance(tool_ctx, ToolRuntimeContext):
            return _error_output(
                kind=_TOOL_ERROR_KIND,
                message="steward requires ToolRuntimeContext.",
                details={"reason": "missing_tool_context"},
            )
        cancel_token = tool_ctx.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        session_id = tool_ctx.session_id
        branch_id = tool_ctx.branch_id or "main"
        if not isinstance(session_id, str) or not session_id:
            return _error_output(
                kind=_TOOL_ERROR_KIND,
                message="steward requires an active session.",
                details={"reason": "missing_session"},
            )
        store = AsyncStore(tool_ctx.db_path)
        try:
            session = await _open_session(
                session_id=session_id,
                branch_id=branch_id,
            )
            result = await _run_tool_task(
                cfg=cfg,
                session=session,
                store=store,
                session_id=session_id,
                branch_id=branch_id,
                args=args,
                run_number=tool_ctx.run_number,
                cancel_token=cancel_token,
            )
        except AgentermError as exc:
            return _error_output(kind=_TOOL_ERROR_KIND, message=str(exc))
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        env = ToolOutputEnvelope(
            tool="steward",
            ok=True,
            result=_result_payload(result),
        )
        return env.to_json_string()

    return FunctionTool(
        name="steward",
        description=describe_steward(),
        params_json_schema=_STEWARD_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


async def _open_session(
    *,
    session_id: str,
    branch_id: str,
) -> AgentermSQLiteSession:
    try:
        session = AgentermSQLiteSession(
            session_id=session_id,
            db_path=str(history_db_path()),
            create_tables=True,
        )
        if branch_id != "main":
            await session.switch_to_branch(branch_id)
    except (sqlite3.Error, OSError, ValueError) as exc:
        msg = f"Failed to open session store: {exc}"
        raise DatabaseError(msg) from exc
    else:
        return session


async def _run_tool_task(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    args: StewardArgs,
    run_number: int | None,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    if args.task == "snapshot":
        return await run_snapshot_task(
            cfg=cfg,
            session=session,
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            trigger="tool",
            turn_range=args.turn_range,
            model_override=args.model,
            emitters=None,
            run_number=run_number,
            origin_branch_id=branch_id,
            cancel_token=cancel_token,
        )
    return await run_compaction_task(
        cfg=cfg,
        session=session,
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        trigger="tool",
        model_override=args.model,
        instructions_override=args.instructions,
        emitters=None,
        run_number=run_number,
        origin_branch_id=branch_id,
        cancel_token=cancel_token,
    )


__all__ = ("build_steward_tool",)
