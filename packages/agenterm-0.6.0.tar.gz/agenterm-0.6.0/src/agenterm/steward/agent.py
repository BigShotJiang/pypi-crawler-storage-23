"""Steward agent resolution and construction."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agents.agent import Agent
from agents.exceptions import UserError
from agents.model_settings import ModelSettings
from agents.strict_schema import ensure_strict_json_schema

from agenterm.config.agent_files import resolve_agent
from agenterm.config.files import read_small_text_file
from agenterm.core.errors import ConfigError, ValidationError
from agenterm.core.json_codec import require_json_object
from agenterm.engine.output_schema import ConfigAgentOutputSchema
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.steward.continuation_state_schema import CONTINUATION_CAPSULE_SCHEMA

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.config.model import AppConfig
    from agenterm.config.steward import StewardAgentConfig
    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class ResolvedStewardAgent:
    """Resolved Steward agent configuration with instructions loaded."""

    name: str
    model: str
    instructions: str
    path: Path | None
    source: str | None


def resolve_steward_agent(cfg: AppConfig) -> ResolvedStewardAgent:
    """Resolve steward.agent instructions from inline/path/source/defaults."""
    agent_cfg = cfg.steward.agent
    model = agent_cfg.model or cfg.agent.model

    if agent_cfg.instructions is not None:
        instructions = agent_cfg.instructions
        return ResolvedStewardAgent(
            name=agent_cfg.name,
            model=model,
            instructions=instructions,
            path=None,
            source="inline",
        )

    if agent_cfg.path is not None:
        path = _resolve_path(agent_cfg)
        instructions = read_small_text_file(path)
        return ResolvedStewardAgent(
            name=agent_cfg.name,
            model=model,
            instructions=instructions,
            path=path,
            source="path",
        )

    source_name = agent_cfg.source or agent_cfg.name
    resolved = resolve_agent(name=source_name, explicit=agent_cfg.source is not None)
    return ResolvedStewardAgent(
        name=resolved.name,
        model=model,
        instructions=resolved.text,
        path=resolved.source.path,
        source=resolved.source.location,
    )


def build_steward_agent(
    cfg: AppConfig,
    *,
    resolved: ResolvedStewardAgent,
) -> Agent:
    """Construct the Steward agent with structured output schema."""
    output_schema = _continuation_capsule_schema()
    return Agent(
        name=resolved.name,
        instructions=resolved.instructions,
        model=resolved.model,
        model_settings=steward_model_settings(cfg),
        tools=[],
        output_type=output_schema,
    )


def _resolve_path(agent_cfg: StewardAgentConfig) -> Path:
    path = agent_cfg.path
    if path is None:
        msg = "steward.agent.path must be set to resolve path instructions"
        raise ConfigError(msg)
    return path


def _continuation_capsule_schema() -> ConfigAgentOutputSchema:
    name = CONTINUATION_CAPSULE_SCHEMA.get("name")
    schema_obj = CONTINUATION_CAPSULE_SCHEMA.get("schema")
    strict_obj = CONTINUATION_CAPSULE_SCHEMA.get("strict")
    if not isinstance(name, str) or not name:
        msg = "ContinuationCapsule schema name is invalid"
        raise ConfigError(msg)
    if not isinstance(schema_obj, Mapping):
        msg = "ContinuationCapsule schema payload is invalid"
        raise ConfigError(msg)
    strict = True
    if isinstance(strict_obj, bool) and not strict_obj:
        msg = "Steward ContinuationCapsule schema must be strict"
        raise ConfigError(msg)
    schema: dict[str, JSONValue] = {str(k): v for k, v in schema_obj.items()}
    if strict:
        validate_strict_schema("steward.continuation_capsule.schema", schema)
        try:
            strict_schema = ensure_strict_json_schema(dict(schema))
        except UserError as exc:
            msg = f"Steward ContinuationCapsule schema must be strict: {exc}"
            raise ConfigError(msg) from exc
        try:
            schema = require_json_object(
                value=strict_schema,
                context="steward.continuation_capsule.schema",
            )
        except ValidationError as exc:
            msg = (
                "Steward ContinuationCapsule schema must be JSON-safe after strict "
                "normalization"
            )
            raise ConfigError(msg) from exc
    return ConfigAgentOutputSchema(_name=name, _schema=schema, _strict=strict)


def steward_model_settings_override(cfg: AppConfig) -> ModelSettings | None:
    """Return a ModelSettings override for Steward runs when configured."""
    truncation = cfg.steward.agent.truncation
    max_output_tokens = cfg.steward.agent.max_output_tokens
    if max_output_tokens is None and truncation is None:
        return None
    return ModelSettings(
        max_tokens=max_output_tokens,
        truncation=truncation,
    )


def steward_model_settings(cfg: AppConfig) -> ModelSettings:
    """Return model settings with optional Steward overrides applied."""
    base = cfg.to_model_settings()
    override = steward_model_settings_override(cfg)
    if override is None:
        return base
    return base.resolve(override)


__all__ = (
    "ResolvedStewardAgent",
    "build_steward_agent",
    "resolve_steward_agent",
    "steward_model_settings",
    "steward_model_settings_override",
)
