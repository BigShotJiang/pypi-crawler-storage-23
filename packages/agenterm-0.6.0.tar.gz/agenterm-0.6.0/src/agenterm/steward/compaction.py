"""Steward compaction helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.response_items import (
    parse_input_item,
    serialize_input_item,
    serialize_input_items,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.items import TResponseInputItem

    from agenterm.core.json_types import JSONValue
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession


async def compaction_input_items(
    *,
    session: AgentermSQLiteSession,
    branch_id: str,
) -> list[TResponseInputItem]:
    """Load items for compaction."""
    history = await session.get_items(branch_id=branch_id)
    items = list(history)
    if not items:
        msg = "Compaction requires session history (SDK turns) items"
        raise ConfigError(msg)
    return items


def parse_compaction_items(
    items: Sequence[Mapping[str, JSONValue]],
) -> list[TResponseInputItem]:
    """Validate and convert persisted compaction items."""
    return [
        parse_input_item(item, context="steward.compaction.input_items")
        for item in items
    ]


def _filter_compaction_items(
    items: Sequence[Mapping[str, JSONValue]],
) -> list[TResponseInputItem]:
    filtered: list[TResponseInputItem] = []
    for item in items:
        try:
            parsed = parse_input_item(
                item,
                context="steward.compaction.input_items",
            )
        except ConfigError:
            continue
        filtered.append(parsed)
    if not filtered:
        msg = "Compaction requires at least one valid input item"
        raise ConfigError(msg)
    return filtered


def _filter_compaction_input_items(
    items: Sequence[TResponseInputItem],
) -> list[TResponseInputItem]:
    filtered: list[TResponseInputItem] = []
    for item in items:
        try:
            serialize_input_item(
                item,
                context="steward.compaction.input_items",
            )
        except ConfigError:
            continue
        filtered.append(item)
    if not filtered:
        msg = "Compaction requires at least one valid input item"
        raise ConfigError(msg)
    return filtered


def serialize_compaction_items(
    items: Sequence[Mapping[str, JSONValue]],
) -> tuple[dict[str, JSONValue], ...]:
    """Serialize compaction items for persistence."""
    filtered = _filter_compaction_items(items)
    return serialize_input_items(filtered, context="steward.compaction.input_items")


def serialize_compaction_input_items(
    items: Sequence[TResponseInputItem],
) -> tuple[dict[str, JSONValue], ...]:
    """Serialize typed compaction items for persistence."""
    filtered = _filter_compaction_input_items(items)
    return serialize_input_items(filtered, context="steward.compaction.input_items")


__all__ = (
    "compaction_input_items",
    "parse_compaction_items",
    "serialize_compaction_input_items",
    "serialize_compaction_items",
)
