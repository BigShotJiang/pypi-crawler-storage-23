"""Steward task execution and orchestration."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import AgentermError, ConfigError, OperationCancelledError
from agenterm.engine.provider_capabilities import resolve_provider_capabilities
from agenterm.steward.compaction import (
    compaction_input_items,
    serialize_compaction_input_items,
)
from agenterm.steward.task_inputs import (
    StewardCompactionTaskInput,
    StewardSnapshotTaskInput,
    TurnRange,
)
from agenterm.steward.task_runtime import (
    StewardTaskResult,
    effective_steward_model,
    ensure_task_branch,
    execute_compaction_task,
    execute_snapshot_task,
    new_task_id,
)
from agenterm.store.steward.repo import (
    StewardTaskTrigger,
    cancel_stale_running_steward_tasks,
    count_pending_steward_tasks,
    insert_steward_task,
)

if TYPE_CHECKING:
    from agenterm.config.compression import (
        CompressionPrimaryBranch,
        CompressionStrategy,
    )
    from agenterm.config.model import AppConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.steward.emitters import CompressionEmitters
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession


def _emit_line(
    emitters: CompressionEmitters | None,
    message: str,
) -> None:
    if emitters is not None and emitters.emit_line is not None:
        emitters.emit_line(message)


def _emit_warn(emitters: CompressionEmitters | None, message: str) -> None:
    _emit_line(emitters, message)


def _emit_info(emitters: CompressionEmitters | None, message: str) -> None:
    _emit_line(emitters, message)


def _compression_order(
    *,
    primary_branch: CompressionPrimaryBranch,
) -> tuple[str, str]:
    if primary_branch == "snapshot":
        return ("compaction", "snapshot")
    return ("snapshot", "compaction")


async def _count_pending_with_stale_eviction(
    *,
    cfg: AppConfig,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    emitters: CompressionEmitters | None,
) -> int:
    stale_after_seconds = cfg.steward.tasks.running_stale_seconds
    if stale_after_seconds is not None:
        evicted = await cancel_stale_running_steward_tasks(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            stale_after_seconds=stale_after_seconds,
        )
        if evicted > 0:
            unit = "task" if evicted == 1 else "tasks"
            _emit_warn(
                emitters,
                "warn> Cancelled "
                f"{evicted} stale running Steward {unit} "
                f"(older than {stale_after_seconds}s).",
            )
    return await count_pending_steward_tasks(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
    )


async def _run_both_if_supported(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    trigger: StewardTaskTrigger,
    turn_range: TurnRange | None,
    emitters: CompressionEmitters | None,
    model_override: str | None,
    instructions_override: str | None,
    primary_branch: CompressionPrimaryBranch,
    run_number: int | None,
    origin_branch_id: str,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    first, second = _compression_order(primary_branch=primary_branch)
    snapshot_result: StewardTaskResult | None = None
    compaction_result: StewardTaskResult | None = None
    errors: list[AgentermError] = []

    for kind in (first, second):
        try:
            if kind == "compaction":
                compaction_result = await run_compaction_task(
                    cfg=cfg,
                    session=session,
                    store=store,
                    session_id=session_id,
                    branch_id=branch_id,
                    trigger=trigger,
                    model_override=model_override,
                    instructions_override=instructions_override,
                    emitters=emitters,
                    run_number=run_number,
                    origin_branch_id=origin_branch_id,
                    cancel_token=cancel_token,
                )
            else:
                snapshot_result = await run_snapshot_task(
                    cfg=cfg,
                    session=session,
                    store=store,
                    session_id=session_id,
                    branch_id=branch_id,
                    trigger=trigger,
                    turn_range=turn_range,
                    model_override=model_override,
                    emitters=emitters,
                    run_number=run_number,
                    origin_branch_id=origin_branch_id,
                    cancel_token=cancel_token,
                )
        except AgentermError as exc:
            errors.append(exc)
            _emit_warn(emitters, f"warn> Compression {kind} failed: {exc}")

    if compaction_result is None and snapshot_result is None:
        msg = "Compression produced no continuation."
        raise AgentermError(msg)

    if primary_branch == "snapshot":
        if snapshot_result is not None:
            return snapshot_result
        if compaction_result is not None:
            return compaction_result
    else:
        if compaction_result is not None:
            return compaction_result
        if snapshot_result is not None:
            return snapshot_result
    msg = "Compression result resolution failed."
    raise AgentermError(msg)


async def run_compress_policy(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    trigger: StewardTaskTrigger,
    turn_range: TurnRange | None,
    emitters: CompressionEmitters | None,
    model_override: str | None = None,
    instructions_override: str | None = None,
    strategy_override: CompressionStrategy | None = None,
    primary_branch_override: CompressionPrimaryBranch | None = None,
    run_number: int | None = None,
    origin_branch_id: str | None = None,
    cancel_token: CancelToken | None = None,
) -> StewardTaskResult:
    """Run Steward compression based on the configured mode."""
    model_id = model_override or cfg.agent.model
    strategy = strategy_override or cfg.compression.strategy
    primary_branch = primary_branch_override or cfg.compression.primary_branch
    caps = resolve_provider_capabilities(cfg, model_id=model_id)
    origin_branch = origin_branch_id or branch_id
    run_label = f"run={run_number}" if run_number is not None else "run=manual"
    supports_compaction = caps.supports_compaction
    try:
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        _emit_info(
            emitters,
            "info> Compression started "
            f"(trigger={trigger}, strategy={strategy}, {run_label}).",
        )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        if strategy == "snapshot" or not supports_compaction:
            result = await run_snapshot_task(
                cfg=cfg,
                session=session,
                store=store,
                session_id=session_id,
                branch_id=branch_id,
                trigger=trigger,
                turn_range=turn_range,
                model_override=model_override,
                emitters=emitters,
                run_number=run_number,
                origin_branch_id=origin_branch,
                cancel_token=cancel_token,
            )
        elif strategy == "both_if_supported":
            result = await _run_both_if_supported(
                cfg=cfg,
                session=session,
                store=store,
                session_id=session_id,
                branch_id=branch_id,
                trigger=trigger,
                turn_range=turn_range,
                emitters=emitters,
                model_override=model_override,
                instructions_override=instructions_override,
                primary_branch=primary_branch,
                run_number=run_number,
                origin_branch_id=origin_branch,
                cancel_token=cancel_token,
            )
        else:
            try:
                result = await run_compaction_task(
                    cfg=cfg,
                    session=session,
                    store=store,
                    session_id=session_id,
                    branch_id=branch_id,
                    trigger=trigger,
                    model_override=model_override,
                    instructions_override=instructions_override,
                    emitters=emitters,
                    run_number=run_number,
                    origin_branch_id=origin_branch,
                    cancel_token=cancel_token,
                )
            except AgentermError as exc:
                warn_msg = (
                    "warn> Compression compaction failed; "
                    f"falling back to snapshot continuation: {exc}"
                )
                _emit_warn(emitters, warn_msg)
                result = await run_snapshot_task(
                    cfg=cfg,
                    session=session,
                    store=store,
                    session_id=session_id,
                    branch_id=branch_id,
                    trigger=trigger,
                    turn_range=turn_range,
                    model_override=model_override,
                    emitters=emitters,
                    run_number=run_number,
                    origin_branch_id=origin_branch,
                    cancel_token=cancel_token,
                )
    except OperationCancelledError:
        _emit_info(emitters, "info> Compression cancelled.")
        raise

    return result


async def run_snapshot_task(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    trigger: StewardTaskTrigger,
    turn_range: TurnRange | None,
    model_override: str | None,
    emitters: CompressionEmitters | None,
    run_number: int | None,
    origin_branch_id: str,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    """Execute a steward.snapshot task inline."""
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    await ensure_task_branch(session=session, branch_id=branch_id)
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    max_pending = cfg.steward.tasks.max_pending
    pending = await _count_pending_with_stale_eviction(
        cfg=cfg,
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        emitters=emitters,
    )
    if pending >= max_pending:
        msg = "Compression task limit reached; snapshot continuation refused."
        raise ConfigError(msg)

    task_input = StewardSnapshotTaskInput(
        session_id=session_id,
        branch_id=branch_id,
        turn_range=turn_range,
        model=model_override,
    )
    task_record = await insert_steward_task(
        store=store,
        task_id=new_task_id(),
        session_id=session_id,
        branch_id=branch_id,
        kind="snapshot",
        trigger=trigger,
        status="queued",
        model=effective_steward_model(cfg=cfg, override=model_override),
        input_payload=task_input.to_json(),
        trace_id=cfg.run.trace_id,
    )
    return await execute_snapshot_task(
        cfg=cfg,
        session=session,
        store=store,
        task=task_record,
        task_input=task_input,
        trigger=trigger,
        emitters=emitters,
        run_number=run_number,
        origin_branch_id=origin_branch_id,
        cancel_token=cancel_token,
    )


async def run_compaction_task(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    trigger: StewardTaskTrigger,
    model_override: str | None,
    instructions_override: str | None,
    emitters: CompressionEmitters | None,
    run_number: int | None,
    origin_branch_id: str,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    """Execute a steward.compaction task inline."""
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    await ensure_task_branch(session=session, branch_id=branch_id)
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    max_pending = cfg.steward.tasks.max_pending
    pending = await _count_pending_with_stale_eviction(
        cfg=cfg,
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        emitters=emitters,
    )
    if pending >= max_pending:
        msg = "Compression task limit reached; compaction continuation refused."
        raise ConfigError(msg)

    input_items = await compaction_input_items(
        session=session,
        branch_id=branch_id,
    )
    serialized_items = serialize_compaction_input_items(input_items)
    model_id = model_override or cfg.agent.model
    instructions = instructions_override or cfg.agent.instructions
    caps = resolve_provider_capabilities(cfg, model_id=model_id)
    if not caps.supports_compaction:
        msg = f"Compaction not supported for model {model_id!r}"
        raise ConfigError(msg)
    task_input = StewardCompactionTaskInput(
        session_id=session_id,
        branch_id=branch_id,
        model=model_id,
        instructions=instructions,
        input_items=serialized_items,
    )
    task_record = await insert_steward_task(
        store=store,
        task_id=new_task_id(),
        session_id=session_id,
        branch_id=branch_id,
        kind="compaction",
        trigger=trigger,
        status="queued",
        model=model_id,
        input_payload=task_input.to_json(),
        trace_id=cfg.run.trace_id,
    )
    return await execute_compaction_task(
        cfg=cfg,
        session=session,
        store=store,
        task=task_record,
        task_input=task_input,
        emitters=emitters,
        run_number=run_number,
        origin_branch_id=origin_branch_id,
        cancel_token=cancel_token,
    )


__all__ = (
    "StewardTaskResult",
    "run_compaction_task",
    "run_compress_policy",
    "run_snapshot_task",
)
