"""Image-generation artifact persistence and rehydration helpers."""

from __future__ import annotations

import asyncio
import base64
import binascii
import hashlib
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from agenterm.artifacts.repo import (
    ArtifactRecord,
    assign_artifact_session_id_by_source,
    get_artifact_by_hash,
    get_artifact_by_source,
    insert_artifact,
)
from agenterm.config.paths import ensure_artifacts_dir
from agenterm.core.errors import DatabaseError, FilesystemError, ValidationError

if TYPE_CHECKING:
    from agenterm.store.async_db import AsyncStore

_PNG_SIG = b"\x89PNG\r\n\x1a\n"
_JPEG_SIG = b"\xff\xd8\xff"
_RIFF_SIG = b"RIFF"
_WEBP_SIG = b"WEBP"
_WEBP_SIG_OFFSET = 8
_WEBP_MIN_BYTES = 12

ImageCallStatus = Literal["in_progress", "completed", "generating", "failed"]


def parse_image_call_status(value: str | None) -> ImageCallStatus:
    """Return a validated image_generation_call status or raise ValidationError."""
    if value == "in_progress":
        return "in_progress"
    if value == "completed":
        return "completed"
    if value == "generating":
        return "generating"
    if value == "failed":
        return "failed"
    msg = (
        "image_generation_call.status must be one of: "
        f"in_progress, completed, generating, failed (got {value!r})"
    )
    raise ValidationError(msg)


def _detect_image_format(data: bytes) -> tuple[str, str]:
    """Return (mime, ext) or raise ValidationError when format is unknown."""
    if data.startswith(_PNG_SIG):
        return "image/png", "png"
    if data.startswith(_JPEG_SIG):
        return "image/jpeg", "jpg"
    if (
        len(data) >= _WEBP_MIN_BYTES
        and data.startswith(_RIFF_SIG)
        and data[_WEBP_SIG_OFFSET:_WEBP_MIN_BYTES] == _WEBP_SIG
    ):
        return "image/webp", "webp"
    msg = "image_generation_call.result is not a supported image format"
    raise ValidationError(msg)


def _normalize_b64(raw: str) -> str:
    text = (raw or "").strip()
    if text.startswith("data:") and "base64," in text:
        _, text = text.split("base64,", 1)
    # Some encoders wrap base64 with newlines. Strip all whitespace so
    # downstream decoders can remain strict.
    return "".join(text.split())


def _decode_b64(b64: str) -> bytes:
    normalized = _normalize_b64(b64)
    if not normalized:
        msg = "image_generation_call.result is empty"
        raise ValidationError(msg)

    first_exc: Exception | None = None
    try:
        return base64.b64decode(normalized, validate=True)
    except (ValueError, binascii.Error) as exc:
        first_exc = exc

    padded = normalized + ("=" * (-len(normalized) % 4))
    try:
        return base64.b64decode(padded, validate=True)
    except (ValueError, binascii.Error):
        pass

    # Fall back to the URL-safe alphabet if present.
    try:
        return base64.urlsafe_b64decode(padded)
    except (ValueError, binascii.Error) as exc:  # pragma: no cover - defensive
        msg = "image_generation_call.result is not valid base64"
        raise ValidationError(msg) from (first_exc or exc)


def _encode_b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _write_bytes_atomic(path: Path, data: bytes) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_bytes(data)
        tmp.replace(path)
    except OSError as exc:
        msg = f"Failed to write image artifact {path}: {exc}"
        raise FilesystemError(msg) from exc


def _content_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _record_with_session(
    record: ArtifactRecord,
    session_id: str | None,
) -> ArtifactRecord:
    if not (session_id and (record.session_id is None or not record.session_id)):
        return record
    return ArtifactRecord(
        artifact_id=record.artifact_id,
        kind=record.kind,
        mime=record.mime,
        path=record.path,
        size_bytes=record.size_bytes,
        content_hash=record.content_hash,
        created_at=record.created_at,
        source_type=record.source_type,
        source_id=record.source_id,
        session_id=session_id,
    )


async def _persist_image_artifact(
    *,
    store: AsyncStore,
    session_id: str | None,
    source_type: str,
    source_id: str,
    result_b64: str,
) -> ArtifactRecord:
    existing = await get_artifact_by_source(
        store=store,
        source_type=source_type,
        source_id=source_id,
    )
    if existing is not None:
        if session_id and (existing.session_id is None or not existing.session_id):
            await assign_artifact_session_id_by_source(
                store=store,
                source_type=source_type,
                source_id=source_id,
                session_id=session_id,
            )
            return _record_with_session(existing, session_id)
        return existing

    data = _decode_b64(result_b64)
    mime, ext = _detect_image_format(data)
    content_hash = _content_hash(data)

    path: Path | None = None
    existing_hash = await get_artifact_by_hash(
        store=store,
        content_hash=content_hash,
    )
    if existing_hash is not None and existing_hash.kind == "image":
        path = Path(existing_hash.path)

    root = await asyncio.to_thread(ensure_artifacts_dir)
    images_dir = root / "images"
    if path is None:
        filename = f"{content_hash}.{ext}"
        path = images_dir / filename
        await asyncio.to_thread(_write_bytes_atomic, path, data)
    else:
        exists = await asyncio.to_thread(path.exists)
        if not exists:
            await asyncio.to_thread(_write_bytes_atomic, path, data)
    artifact_id = str(uuid.uuid4())

    record = ArtifactRecord(
        artifact_id=artifact_id,
        kind="image",
        mime=mime,
        path=str(path),
        size_bytes=len(data),
        content_hash=content_hash,
        created_at=None,
        source_type=source_type,
        source_id=source_id,
        session_id=session_id,
    )
    inserted = await insert_artifact(store=store, record=record)
    if inserted:
        return record

    # Another writer may have inserted the same (source_type, source_id).
    existing2 = await get_artifact_by_source(
        store=store,
        source_type=source_type,
        source_id=source_id,
    )
    if (
        existing2 is not None
        and session_id
        and (existing2.session_id is None or not existing2.session_id)
    ):
        await assign_artifact_session_id_by_source(
            store=store,
            source_type=source_type,
            source_id=source_id,
            session_id=session_id,
        )
    if existing2 is None:
        msg = "Failed to resolve artifact after integrity conflict"
        raise DatabaseError(msg)
    return _record_with_session(existing2, session_id)


async def persist_image_generation_call(
    *,
    store: AsyncStore,
    session_id: str | None,
    call_id: str,
    result_b64: str,
) -> ArtifactRecord:
    """Persist an image_generation_call result to the artifact vault."""
    return await _persist_image_artifact(
        store=store,
        session_id=session_id,
        source_type="image_generation_call",
        source_id=call_id,
        result_b64=result_b64,
    )


async def persist_image_generation_partial(
    *,
    store: AsyncStore,
    session_id: str | None,
    item_id: str,
    partial_index: int,
    result_b64: str,
) -> ArtifactRecord:
    """Persist a partial image stream payload to the artifact vault."""
    source_id = f"{item_id}:{int(partial_index)}"
    return await _persist_image_artifact(
        store=store,
        session_id=session_id,
        source_type="image_generation_partial",
        source_id=source_id,
        result_b64=result_b64,
    )


async def rehydrate_image_generation_call_result(
    *,
    artifact_path: Path,
) -> str | None:
    """Return base64 for an image artifact file."""
    try:
        data = await asyncio.to_thread(artifact_path.read_bytes)
    except OSError as exc:
        msg = f"Failed to read image artifact {artifact_path}: {exc}"
        raise FilesystemError(msg) from exc
    return _encode_b64(data)


__all__ = (
    "parse_image_call_status",
    "persist_image_generation_call",
    "persist_image_generation_partial",
    "rehydrate_image_generation_call_result",
)
