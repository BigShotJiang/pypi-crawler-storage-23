"""Run error summary artifact persistence helpers."""

from __future__ import annotations

import asyncio
import hashlib
import uuid
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.artifacts.repo import (
    ArtifactRecord,
    assign_artifact_session_id_by_source,
    get_artifact_by_hash,
    get_artifact_by_source,
    insert_artifact,
)
from agenterm.config.paths import ensure_artifacts_dir
from agenterm.core.errors import DatabaseError, FilesystemError, ValidationError
from agenterm.core.json_codec import dumps_compact, is_json_value
from agenterm.core.sanitize_paths import sanitize_json_paths

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore


def _write_text_atomic(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = path.with_suffix(path.suffix + ".tmp")
        temp_path.write_text(text, encoding="utf-8")
        temp_path.replace(path)
    except OSError as exc:
        msg = f"Failed to write run error artifact {path}: {exc}"
        raise FilesystemError(msg) from exc


async def _maybe_assign_session_id(
    *,
    store: AsyncStore,
    record: ArtifactRecord,
    session_id: str | None,
) -> ArtifactRecord:
    if not session_id or record.session_id:
        return record
    await assign_artifact_session_id_by_source(
        store=store,
        source_type=record.source_type,
        source_id=record.source_id,
        session_id=session_id,
    )
    return replace(record, session_id=session_id)


async def _existing_summary(
    *,
    store: AsyncStore,
    run_id: str,
    session_id: str | None,
) -> ArtifactRecord | None:
    existing = await get_artifact_by_source(
        store=store,
        source_type="run_error_summary",
        source_id=run_id,
    )
    if existing is None:
        return None
    return await _maybe_assign_session_id(
        store=store,
        record=existing,
        session_id=session_id,
    )


async def _resolve_artifact_path(
    *,
    store: AsyncStore,
    root: Path,
    content_hash: str,
    text: str,
) -> Path:
    existing_hash = await get_artifact_by_hash(
        store=store,
        content_hash=content_hash,
    )
    if existing_hash is not None and existing_hash.kind == "run_error_summary":
        path = Path(existing_hash.path)
    else:
        path = root / "run_errors" / f"{content_hash}.json"
    exists = await asyncio.to_thread(path.exists)
    if not exists:
        await asyncio.to_thread(_write_text_atomic, path, text)
    return path


async def persist_run_error_summary(
    *,
    store: AsyncStore,
    session_id: str | None,
    run_id: str,
    payload: Mapping[str, JSONValue],
) -> ArtifactRecord:
    """Persist a sanitized run-error summary artifact for a run id."""
    payload_json = dict(payload)
    if not is_json_value(value=payload_json):
        msg = "run_error summary payload is not JSON-safe"
        raise ValidationError(msg)
    existing = await _existing_summary(
        store=store,
        run_id=run_id,
        session_id=session_id,
    )
    if existing is not None:
        return existing

    sanitized = sanitize_json_paths(payload_json)
    text = dumps_compact(
        sanitized,
        sort_keys=True,
        ensure_ascii=True,
        context="artifacts.run_error.summary",
    )
    content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
    root = await asyncio.to_thread(ensure_artifacts_dir)
    path = await _resolve_artifact_path(
        store=store,
        root=root,
        content_hash=content_hash,
        text=text,
    )
    record = ArtifactRecord(
        artifact_id=str(uuid.uuid4()),
        kind="run_error_summary",
        mime="application/json",
        path=str(path),
        size_bytes=len(text.encode("utf-8")),
        content_hash=content_hash,
        created_at=None,
        source_type="run_error_summary",
        source_id=run_id,
        session_id=session_id,
    )
    inserted = await insert_artifact(store=store, record=record)
    if inserted:
        return record
    existing_after_conflict = await _existing_summary(
        store=store,
        run_id=run_id,
        session_id=session_id,
    )
    if existing_after_conflict is None:
        msg = "Failed to resolve run_error_summary artifact after conflict"
        raise DatabaseError(msg)
    return existing_after_conflict


__all__ = ("persist_run_error_summary",)
