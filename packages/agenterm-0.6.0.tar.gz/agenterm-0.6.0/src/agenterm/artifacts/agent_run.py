"""Agent-run report persistence and retrieval helpers."""

from __future__ import annotations

import asyncio
import hashlib
import uuid
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.artifacts.repo import (
    ArtifactRecord,
    assign_artifact_session_id_by_source,
    get_artifact_by_hash,
    get_artifact_by_id,
    get_artifact_by_source,
    insert_artifact,
)
from agenterm.config.paths import ensure_artifacts_dir
from agenterm.core.errors import DatabaseError, FilesystemError, ValidationError
from agenterm.core.json_codec import dumps_compact, is_json_value, parse_json_object

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore


def _write_text_atomic(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(text, encoding="utf-8")
        tmp.replace(path)
    except OSError as exc:
        msg = f"Failed to write agent_run report {path}: {exc}"
        raise FilesystemError(msg) from exc


async def _maybe_assign_session_id(
    *,
    store: AsyncStore,
    record: ArtifactRecord,
    session_id: str | None,
) -> ArtifactRecord:
    if not session_id or record.session_id:
        return record
    await assign_artifact_session_id_by_source(
        store=store,
        source_type=record.source_type,
        source_id=record.source_id,
        session_id=session_id,
    )
    return replace(record, session_id=session_id)


async def _get_existing_report(
    *,
    store: AsyncStore,
    source_id: str,
    session_id: str | None,
) -> ArtifactRecord | None:
    existing = await get_artifact_by_source(
        store=store,
        source_type="agent_run",
        source_id=source_id,
    )
    if existing is None:
        return None
    return await _maybe_assign_session_id(
        store=store,
        record=existing,
        session_id=session_id,
    )


async def _resolve_report_path(
    *,
    store: AsyncStore,
    root: Path,
    content_hash: str,
    text: str,
) -> Path:
    reports_dir = root / "agent_runs"
    existing_hash = await get_artifact_by_hash(
        store=store,
        content_hash=content_hash,
    )
    if existing_hash is not None and existing_hash.kind == "agent_run_report":
        path = Path(existing_hash.path)
    else:
        path = reports_dir / f"{content_hash}.json"
    exists = await asyncio.to_thread(path.exists)
    if not exists:
        await asyncio.to_thread(_write_text_atomic, path, text)
    return path


async def persist_agent_run_report(
    *,
    store: AsyncStore,
    session_id: str | None,
    source_id: str,
    payload: Mapping[str, JSONValue],
) -> ArtifactRecord:
    """Persist an agent_run report to the artifact vault."""
    if not is_json_value(value=payload):
        msg = "agent_run report payload is not JSON-safe"
        raise ValidationError(msg)
    existing = await _get_existing_report(
        store=store,
        source_id=source_id,
        session_id=session_id,
    )
    if existing is not None:
        return existing

    root = await asyncio.to_thread(ensure_artifacts_dir)
    text = dumps_compact(
        payload,
        sort_keys=True,
        ensure_ascii=True,
        context="artifacts.agent_run.report",
    )
    content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
    artifact_id = str(uuid.uuid4())
    path = await _resolve_report_path(
        store=store,
        root=root,
        content_hash=content_hash,
        text=text,
    )

    record = ArtifactRecord(
        artifact_id=artifact_id,
        kind="agent_run_report",
        mime="application/json",
        path=str(path),
        size_bytes=len(text.encode("utf-8")),
        content_hash=content_hash,
        created_at=None,
        source_type="agent_run",
        source_id=source_id,
        session_id=session_id,
    )
    inserted = await insert_artifact(store=store, record=record)
    if inserted:
        return record

    existing2 = await _get_existing_report(
        store=store,
        source_id=source_id,
        session_id=session_id,
    )
    if existing2 is None:
        msg = "Failed to resolve agent_run artifact after conflict"
        raise DatabaseError(msg)
    return existing2


async def load_agent_run_report(
    *,
    store: AsyncStore,
    artifact_id: str,
) -> dict[str, JSONValue] | None:
    """Load an agent_run report from the artifact vault."""
    record = await get_artifact_by_id(store=store, artifact_id=artifact_id)
    if record is None or record.kind != "agent_run_report":
        return None
    try:
        text = await asyncio.to_thread(Path(record.path).read_text, encoding="utf-8")
    except OSError as exc:
        msg = f"Failed to read agent_run report {record.path}: {exc}"
        raise FilesystemError(msg) from exc
    parsed = parse_json_object(text)
    if parsed is None:
        msg = "agent_run report payload is invalid JSON"
        raise ValidationError(msg)
    return parsed


__all__ = ("load_agent_run_report", "persist_agent_run_report")
