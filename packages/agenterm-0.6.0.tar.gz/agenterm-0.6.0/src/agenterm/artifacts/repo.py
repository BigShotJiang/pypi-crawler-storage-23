"""SQLite repository for agenterm-owned artifacts.

This table is separate from Agents session tables. It stores stable references
to durable artifact files on disk so the session DB is not used as a blob store.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.store.async_db import AsyncStore


@dataclass(frozen=True)
class ArtifactRecord:
    """Row model for `agenterm_artifacts`."""

    artifact_id: str
    kind: str
    mime: str
    path: str
    size_bytes: int
    content_hash: str
    created_at: str | None
    source_type: str
    source_id: str
    session_id: str | None


def _row_to_artifact(
    row: tuple[str | int | float | bytes | None, ...],
) -> ArtifactRecord:
    (
        artifact_id,
        kind,
        mime,
        path,
        size_bytes,
        content_hash,
        created_at,
        source_type,
        source_id,
        session_id,
    ) = row
    return ArtifactRecord(
        artifact_id=str(artifact_id),
        kind=str(kind),
        mime=str(mime),
        path=str(path),
        size_bytes=int(size_bytes) if isinstance(size_bytes, int) else 0,
        content_hash=str(content_hash) if content_hash is not None else "",
        created_at=str(created_at) if created_at is not None else None,
        source_type=str(source_type),
        source_id=str(source_id),
        session_id=str(session_id) if session_id is not None else None,
    )


async def get_artifact_by_source(
    *,
    store: AsyncStore,
    source_type: str,
    source_id: str,
) -> ArtifactRecord | None:
    """Return an artifact record by its source id."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str | int | float | bytes | None, ...] | None:
        cur = await conn.execute(
            """
            SELECT
                artifact_id,
                kind,
                mime,
                path,
                size_bytes,
                content_hash,
                created_at,
                source_type,
                source_id,
                session_id
            FROM agenterm_artifacts
            WHERE source_type = ? AND source_id = ?
            """,
            (str(source_type), str(source_id)),
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    return _row_to_artifact(row)


async def get_artifact_by_hash(
    *,
    store: AsyncStore,
    content_hash: str,
) -> ArtifactRecord | None:
    """Return an artifact record by its content hash."""
    if not content_hash:
        return None
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str | int | float | bytes | None, ...] | None:
        cur = await conn.execute(
            """
            SELECT
                artifact_id,
                kind,
                mime,
                path,
                size_bytes,
                content_hash,
                created_at,
                source_type,
                source_id,
                session_id
            FROM agenterm_artifacts
            WHERE content_hash = ?
            LIMIT 1
            """,
            (str(content_hash),),
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    return _row_to_artifact(row)


async def get_artifact_by_id(
    *,
    store: AsyncStore,
    artifact_id: str,
) -> ArtifactRecord | None:
    """Return an artifact record by artifact_id."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str | int | float | bytes | None, ...] | None:
        cur = await conn.execute(
            """
            SELECT
                artifact_id,
                kind,
                mime,
                path,
                size_bytes,
                content_hash,
                created_at,
                source_type,
                source_id,
                session_id
            FROM agenterm_artifacts
            WHERE artifact_id = ?
            """,
            (str(artifact_id),),
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    return _row_to_artifact(row)


async def insert_artifact(
    *,
    store: AsyncStore,
    record: ArtifactRecord,
) -> bool:
    """Insert an artifact record.

    Returns:
      True when inserted, False when a unique-constraint conflict occurs.

    """
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> bool:
        try:
            await conn.execute(
                """
                INSERT INTO agenterm_artifacts (
                    artifact_id, kind, mime, path, size_bytes, content_hash,
                    source_type, source_id, session_id
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record.artifact_id,
                    record.kind,
                    record.mime,
                    record.path,
                    int(record.size_bytes),
                    record.content_hash,
                    record.source_type,
                    record.source_id,
                    record.session_id,
                ),
            )
            await conn.commit()
        except sqlite3.IntegrityError:
            return False
        return True

    return await store.run(_op)


async def assign_artifact_session_id_by_source(
    *,
    store: AsyncStore,
    source_type: str,
    source_id: str,
    session_id: str,
) -> None:
    """Assign session_id for an existing artifact row when missing.

    Artifacts outlive sessions/threads; this is attribution only (no FK).
    """
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            UPDATE agenterm_artifacts
            SET session_id = ?
            WHERE source_type = ? AND source_id = ?
              AND (session_id IS NULL OR session_id = '')
            """,
            (str(session_id), str(source_type), str(source_id)),
        )
        await conn.commit()

    await store.run(_op)


async def list_artifacts_recent(
    *,
    store: AsyncStore,
    limit: int = 50,
    session_id: str | None = None,
    trace_id: str | None = None,
) -> tuple[ArtifactRecord, ...]:
    """Return the most recently created artifacts (best-effort ordering).

    Optional filters: session_id, trace_id.
    """
    lim = max(0, int(limit))
    session_filter = str(session_id) if session_id is not None else None
    trace_filter = str(trace_id) if trace_id is not None else None
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        query = [
            "SELECT",
            "    a.artifact_id,",
            "    a.kind,",
            "    a.mime,",
            "    a.path,",
            "    a.size_bytes,",
            "    a.content_hash,",
            "    a.created_at,",
            "    a.source_type,",
            "    a.source_id,",
            "    a.session_id",
            "FROM agenterm_artifacts AS a",
        ]
        params: list[str | int] = []
        if trace_filter is not None:
            query.append("JOIN agenterm_sessions AS s ON s.session_id = a.session_id")
        where: list[str] = []
        if session_filter is not None:
            where.append("a.session_id = ?")
            params.append(session_filter)
        if trace_filter is not None:
            where.append("s.trace_id = ?")
            params.append(trace_filter)
        if where:
            query.append("WHERE " + " AND ".join(where))
        query.append("ORDER BY a.created_at DESC")
        query.append("LIMIT ?")
        params.append(lim)
        cur = await conn.execute("\n".join(query), tuple(params))
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return tuple(_row_to_artifact(row) for row in rows)


__all__ = (
    "ArtifactRecord",
    "assign_artifact_session_id_by_source",
    "get_artifact_by_hash",
    "get_artifact_by_id",
    "get_artifact_by_source",
    "insert_artifact",
    "list_artifacts_recent",
)
