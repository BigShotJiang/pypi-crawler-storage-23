"""Artifacts (durable tool/model outputs) for agenterm.

Artifacts are persisted to disk under the per-user agenterm data directory and
indexed in the agenterm meta store. They intentionally outlive sessions/threads.
"""

from agenterm.artifacts.repo import (
    ArtifactRecord,
    get_artifact_by_hash,
    get_artifact_by_id,
    get_artifact_by_source,
    list_artifacts_recent,
)

__all__ = (
    "ArtifactRecord",
    "get_artifact_by_hash",
    "get_artifact_by_id",
    "get_artifact_by_source",
    "list_artifacts_recent",
)
