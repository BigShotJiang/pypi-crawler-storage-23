"""Session-history rehydration for artifact-backed items.

This module makes local (stateless) continuity work without bloating the local
SQLite session store. We persist only stable references to artifacts, then
rehydrate payloads into outgoing history when needed.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.artifacts.image_generation import (
    parse_image_call_status,
    rehydrate_image_generation_call_result,
)
from agenterm.core.errors import DatabaseError
from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    import aiosqlite
    from agents.items import TResponseInputItem
    from openai.types.responses.response_input_item_param import (
        ImageGenerationCall as ImageGenerationCallInputItem,
    )

    from agenterm.store.async_db import AsyncStore

_SOURCE_TYPE_IMAGE_CALL = "image_generation_call"


def _image_call_id_needing_rehydrate(item: TResponseInputItem) -> str | None:
    if item.get("type") != _SOURCE_TYPE_IMAGE_CALL:
        return None
    cid = item.get("id")
    if not isinstance(cid, str) or not cid:
        return None
    res_obj = item.get("result")
    if isinstance(res_obj, str) and res_obj:
        return None
    return cid


async def _paths_for_image_calls(
    store: AsyncStore,
    *,
    source_ids: list[str],
) -> dict[str, str]:
    if not source_ids:
        return {}
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> dict[str, str]:
        out: dict[str, str] = {}
        for source_id in source_ids:
            cur = await conn.execute(
                """
                SELECT path
                FROM agenterm_artifacts
                WHERE source_type = ? AND source_id = ?
                """,
                (str(_SOURCE_TYPE_IMAGE_CALL), str(source_id)),
            )
            row = await cur.fetchone()
            if row is None:
                continue
            (path,) = row
            if isinstance(path, str) and path:
                out[source_id] = path
        return out

    try:
        return dict(await store.run(_op))
    except DatabaseError:
        return {}


async def rehydrate_session_items(
    items: list[TResponseInputItem],
    *,
    store: AsyncStore,
) -> list[TResponseInputItem]:
    """Return a new list with artifact-backed items rehydrated for model input."""
    image_call_ids = [
        cid for item in items if (cid := _image_call_id_needing_rehydrate(item))
    ]

    paths = await _paths_for_image_calls(store, source_ids=image_call_ids)
    if not paths:
        return list(items)

    out: list[TResponseInputItem] = []
    for item in items:
        if item.get("type") != _SOURCE_TYPE_IMAGE_CALL:
            out.append(item)
            continue
        cid = _image_call_id_needing_rehydrate(item)
        if cid is None:
            out.append(item)
            continue
        path_str = paths.get(cid)
        if not path_str:
            out.append(item)
            continue
        b64 = await rehydrate_image_generation_call_result(
            artifact_path=Path(path_str),
        )
        if not isinstance(b64, str) or not b64:
            out.append(item)
            continue
        status_raw = item.get("status")
        status = parse_image_call_status(
            status_raw if isinstance(status_raw, str) else None,
        )
        patched: ImageGenerationCallInputItem = {
            "type": "image_generation_call",
            "id": cid,
            "status": status,
            "result": b64,
        }
        out.append(patched)
    return out


__all__ = ("rehydrate_session_items",)
