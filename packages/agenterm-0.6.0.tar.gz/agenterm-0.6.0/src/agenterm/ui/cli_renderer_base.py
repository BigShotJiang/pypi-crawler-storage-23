"""Shared helpers for CLI Rich rendering."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Final, Literal

from rich.console import Console, RenderableType
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

from agenterm.ui.cli_settings import get_cli_output_settings
from agenterm.ui.color_tokens import (
    COLOR_TOKENS_DARK,
    COLOR_TOKENS_LIGHT,
    SemanticColors,
)
from agenterm.ui.tool_events import shorten_line

if TYPE_CHECKING:
    from collections.abc import Iterator, Mapping, Sequence

    from agenterm.core.choices.repl_ui import ReplTheme
    from agenterm.core.error_report import ErrorReport


JustifyMethod = Literal["default", "left", "center", "right", "full"]
OverflowMethod = Literal["fold", "crop", "ellipsis", "ignore"]

_DEFAULT_WIDTH_LIMIT: Final[int] = 80
_SECONDS_IN_MINUTE: Final[int] = 60
_SECONDS_IN_HOUR: Final[int] = 3600
_SECONDS_IN_DAY: Final[int] = 86400


def _cli_theme_for(colors: SemanticColors) -> Theme:
    """Build a Rich Theme from semantic colors."""
    return Theme(
        {
            "label": f"dim {colors.secondary}",
            "muted": f"dim {colors.muted}",
            "dim": f"dim {colors.muted}",
            "accent": f"bold {colors.accent}",
            "good": f"bold {colors.good}",
            "warn": f"bold {colors.warn}",
            "error": f"bold {colors.error}",
        },
    )


_CLI_THEME_DARK: Final = _cli_theme_for(COLOR_TOKENS_DARK)
_CLI_THEME_LIGHT: Final = _cli_theme_for(COLOR_TOKENS_LIGHT)


@dataclass(frozen=True)
class ColumnSpec:
    """Column configuration for a Rich table."""

    header: str
    style: str | None = None
    justify: JustifyMethod | None = None
    no_wrap: bool = False
    overflow: OverflowMethod | None = None
    ratio: int | None = None


@dataclass(slots=True)
class _BlockSpacingState:
    last_line_blank: bool = True
    open_blocks: int = 0


_BLOCK_SPACING: Final = _BlockSpacingState()


def cli_console(*, stderr: bool = False, theme: ReplTheme | None = None) -> Console:
    """Return a themed Rich console for CLI output."""
    if theme is None:
        theme = get_cli_output_settings().theme
    rich_theme = _CLI_THEME_LIGHT if theme == "light" else _CLI_THEME_DARK
    return Console(stderr=stderr, theme=rich_theme)


def _format_rate_limit(report: ErrorReport, *, verbose: bool) -> str | None:
    rate_limit = report.rate_limit
    if rate_limit is None:
        return None
    parts: list[str] = []
    if rate_limit.retry_after_seconds is not None:
        parts.append(f"retry_after={rate_limit.retry_after_seconds:.1f}s")
    if (
        rate_limit.remaining_requests is not None
        and rate_limit.limit_requests is not None
    ):
        parts.append(
            f"requests={rate_limit.remaining_requests}/{rate_limit.limit_requests}",
        )
    if rate_limit.remaining_tokens is not None and rate_limit.limit_tokens is not None:
        parts.append(
            f"tokens={rate_limit.remaining_tokens}/{rate_limit.limit_tokens}",
        )
    if verbose:
        if rate_limit.request_id:
            parts.append(f"request_id={rate_limit.request_id}")
        if rate_limit.reset_requests_seconds is not None:
            parts.append(f"reset_requests={rate_limit.reset_requests_seconds:.1f}s")
        if rate_limit.reset_tokens_seconds is not None:
            parts.append(f"reset_tokens={rate_limit.reset_tokens_seconds:.1f}s")
    return ", ".join(parts) if parts else None


def format_error_report_lines(report: ErrorReport, *, verbose: bool) -> list[str]:
    """Format error report lines for human-facing output."""
    lines: list[str] = [f"{report.kind}: {report.message}"]
    if report.context.recovery_hint:
        lines.append(f"recovery: {report.context.recovery_hint}")
    rate_line = _format_rate_limit(report, verbose=verbose)
    if rate_line:
        lines.append(f"rate_limit: {rate_line}")
    if verbose:
        lines.append(f"operation: {report.context.operation}")
        lines.append(f"resource: {report.context.resource}")
    return lines


def render_error_report(report: ErrorReport) -> None:
    """Render a human error panel from a structured report."""
    settings = get_cli_output_settings()
    console = cli_console(stderr=True)
    lines = format_error_report_lines(report, verbose=settings.verbose)
    panel = Panel(
        Text("\n".join(lines)),
        border_style="error",
        title="Error",
        title_align="left",
    )
    with block(console):
        console.print(panel)


def render_notice(
    *,
    title: str,
    message: str,
    style: str = "accent",
    stderr: bool = False,
) -> None:
    """Render a short informational panel."""
    settings = get_cli_output_settings()
    if settings.quiet and not settings.verbose:
        return
    console = cli_console(stderr=stderr)
    panel = Panel(Text(message), border_style=style, title=title, title_align="left")
    with block(console):
        console.print(panel)


def render_panel(
    title: str,
    body: RenderableType,
    *,
    border: str = "accent",
    stderr: bool = False,
) -> None:
    """Render a panel with consistent block spacing."""
    console = cli_console(stderr=stderr)
    with block(console):
        console.print(panel(title, body, border=border))


def render_text_block(
    text: str,
    *,
    stderr: bool = False,
    style: str | None = None,
) -> None:
    """Render plain text as a spaced block."""
    if not text:
        return
    console = cli_console(stderr=stderr)
    with block(console):
        console.print(text, markup=False, highlight=False, style=style or "")


def kv_table(rows: Sequence[tuple[str, str]]) -> Table:
    """Render key-value rows without headers."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="label", no_wrap=True)
    table.add_column("Value")
    for key, value in rows:
        table.add_row(key, value)
    return table


def table(columns: Sequence[ColumnSpec]) -> Table:
    """Create a table with consistent styling from column specs."""
    table = Table(show_header=True, box=None, padding=(0, 2))
    for col in columns:
        justify = col.justify if col.justify is not None else "left"
        if col.overflow is None:
            table.add_column(
                col.header,
                style=col.style or "",
                justify=justify,
                no_wrap=col.no_wrap,
                ratio=col.ratio,
            )
        else:
            table.add_column(
                col.header,
                style=col.style or "",
                justify=justify,
                no_wrap=col.no_wrap,
                overflow=col.overflow,
                ratio=col.ratio,
            )
    return table


def panel(title: str, body: RenderableType, *, border: str = "accent") -> Panel:
    """Wrap content in a labeled panel."""
    return Panel(body, title=title, title_align="left", border_style=border)


def begin_block(console: Console) -> None:
    """Begin a new block with guaranteed leading spacing."""
    if _BLOCK_SPACING.open_blocks == 0:
        if not _BLOCK_SPACING.last_line_blank:
            console.print()
        _BLOCK_SPACING.last_line_blank = False
    _BLOCK_SPACING.open_blocks += 1


def end_block(console: Console) -> None:
    """End a block with guaranteed trailing spacing."""
    if _BLOCK_SPACING.open_blocks == 0:
        return
    _BLOCK_SPACING.open_blocks -= 1
    if _BLOCK_SPACING.open_blocks == 0:
        console.print()
        _BLOCK_SPACING.last_line_blank = True


@contextmanager
def block(console: Console) -> Iterator[None]:
    """Context manager that enforces block spacing."""
    begin_block(console)
    try:
        yield
    finally:
        end_block(console)


def short_text(text: str | None, *, limit: int = _DEFAULT_WIDTH_LIMIT) -> str:
    """Return a bounded preview string."""
    if text is None:
        return "-"
    return shorten_line(text, limit=limit)


def relative_time(iso_ts: str | None) -> str:
    """Return a compact relative time label."""
    if not iso_ts:
        return "-"
    try:
        ts = iso_ts[:-1] + "+00:00" if iso_ts.endswith("Z") else iso_ts
        dt = datetime.fromisoformat(ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        delta = datetime.now(UTC) - dt
        seconds = int(delta.total_seconds())
        if seconds < _SECONDS_IN_MINUTE:
            return f"{seconds}s ago"
        if seconds < _SECONDS_IN_HOUR:
            return f"{seconds // _SECONDS_IN_MINUTE}m ago"
        if seconds < _SECONDS_IN_DAY:
            return f"{seconds // _SECONDS_IN_HOUR}h ago"
        return f"{seconds // _SECONDS_IN_DAY}d ago"
    except (ValueError, TypeError):
        return iso_ts[:10] if iso_ts else "-"


def tools_summary(tools: Mapping[str, int]) -> str | None:
    """Summarize tool usage counts into a short string."""
    if not tools:
        return None
    parts = [
        f"{name} x{count}" if count > 1 else name
        for name, count in sorted(tools.items())
    ]
    return ", ".join(parts)


def usage_summary(usage: Mapping[str, int] | None) -> str | None:
    """Summarize usage counters into a short string."""
    if usage is None:
        return None
    req = usage.get("requests")
    inp = usage.get("input_tokens")
    cached = usage.get("input_cached_tokens")
    out = usage.get("output_tokens")
    reasoning = usage.get("output_reasoning_tokens")
    total = usage.get("total_tokens")
    parts: list[str] = []
    if req is not None:
        parts.append(f"req={req}")
    if inp is not None:
        if cached is not None:
            parts.append(f"in={inp} (c={cached})")
        else:
            parts.append(f"in={inp}")
    if out is not None:
        if reasoning is not None:
            parts.append(f"out={out} (r={reasoning})")
        else:
            parts.append(f"out={out}")
    if total is not None:
        parts.append(f"tot={total}")
    return " ".join(parts) if parts else None


__all__ = (
    "ColumnSpec",
    "JustifyMethod",
    "OverflowMethod",
    "begin_block",
    "block",
    "cli_console",
    "end_block",
    "kv_table",
    "panel",
    "relative_time",
    "render_error_report",
    "render_notice",
    "render_panel",
    "render_text_block",
    "short_text",
    "table",
    "tools_summary",
    "usage_summary",
)
