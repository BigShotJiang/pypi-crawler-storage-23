"""Branch payload renderers for CLI output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.text import display_role
from agenterm.ui.cli_renderer_base import (
    ColumnSpec,
    kv_table,
    relative_time,
    render_notice,
    render_panel,
    short_text,
    table,
)

if TYPE_CHECKING:
    from agenterm.core.cli_payloads import (
        BranchDeletePayload,
        BranchListPayload,
        BranchUsePayload,
    )

_BRANCH_ID_PREVIEW = 18
_BRANCH_ID_PREVIEW_TAIL = 15


def _format_branch_id(value: str) -> str:
    if len(value) > _BRANCH_ID_PREVIEW:
        return value[:_BRANCH_ID_PREVIEW_TAIL] + "..."
    return value


def render_branch_list(payload: BranchListPayload) -> None:
    """Render `agenterm branch list` output."""
    if not payload.branches:
        render_notice(title="Branches", message="No branches found.", style="warn")
        return
    table_view = table(
        [
            ColumnSpec("Branch", style="accent", no_wrap=True),
            ColumnSpec("Kind"),
            ColumnSpec("User turns", justify="right"),
            ColumnSpec("Messages", justify="right"),
            ColumnSpec("Last message", ratio=2),
            ColumnSpec("Store"),
            ColumnSpec("Current"),
            ColumnSpec("Created", justify="right", style="muted"),
        ],
    )
    for branch in payload.branches:
        meta = branch.meta
        store_label = "on" if (meta is not None and meta.store_enabled) else "off"
        current = "*" if branch.is_current else ""
        last_msg = branch.last_message_snippet or "-"
        role_label = display_role(branch.last_message_role)
        if role_label:
            last_msg = f"{role_label}: {last_msg}"
        table_view.add_row(
            _format_branch_id(branch.branch_id),
            meta.kind if meta is not None else "-",
            str(branch.user_turns),
            str(branch.message_count),
            short_text(last_msg, limit=120),
            store_label,
            current,
            relative_time(branch.created_at),
        )
    render_panel(f"Branches - {payload.session_id}", table_view)


def render_branch_use(payload: BranchUsePayload) -> None:
    """Render `agenterm branch use|new|fork` output."""
    branch = payload.branch
    rows = [
        ("Session ID", payload.session_id),
        ("Head branch", payload.head_branch_id),
        ("Branch ID", branch.branch_id),
        ("Kind", branch.kind),
        ("Store", "on" if branch.store_enabled else "off"),
        ("Last response", branch.last_response_id or "(none)"),
    ]
    render_panel("Branch", kv_table(rows))


def render_branch_delete(payload: BranchDeletePayload) -> None:
    """Render `agenterm branch delete` output."""
    status = "deleted" if payload.deleted else "not found"
    rows = [
        ("Session ID", payload.session_id),
        ("Branch ID", payload.branch_id),
        ("Head branch", payload.head_branch_id),
        ("Status", status),
    ]
    border = "good" if payload.deleted else "warn"
    render_panel("Branch Delete", kv_table(rows), border=border)


__all__ = ("render_branch_delete", "render_branch_list", "render_branch_use")
