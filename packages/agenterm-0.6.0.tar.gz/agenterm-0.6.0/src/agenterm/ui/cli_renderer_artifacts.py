"""Artifact payload renderers for CLI output."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING

from agenterm.core.json_codec import as_bool, as_str
from agenterm.ui.cli_renderer_base import (
    ColumnSpec,
    kv_table,
    render_notice,
    render_panel,
    short_text,
    table,
    tools_summary,
    usage_summary,
)

if TYPE_CHECKING:
    from agenterm.core.cli_payloads import (
        ArtifactAgentRunPayload,
        ArtifactOpenPayload,
        ArtifactShowPayload,
        ArtifactsListPayload,
    )
    from agenterm.core.json_types import JSONValue


def _parse_int_mapping(raw: JSONValue | None) -> dict[str, int] | None:
    if not isinstance(raw, Mapping):
        return None
    out: dict[str, int] = {}
    for key, value in raw.items():
        if not isinstance(value, int) or isinstance(value, bool):
            return None
        out[key] = int(value)
    return out


def _list_len(raw: JSONValue | None) -> int | None:
    return len(raw) if isinstance(raw, list) else None


def render_artifacts_list(payload: ArtifactsListPayload) -> None:
    """Render `agenterm artifacts list` output."""
    if not payload.artifacts:
        render_notice(title="Artifacts", message="No artifacts yet.", style="warn")
        return
    table_view = table(
        [
            ColumnSpec("ID", style="accent", no_wrap=True),
            ColumnSpec("Kind"),
            ColumnSpec("MIME"),
            ColumnSpec("Bytes", justify="right"),
            ColumnSpec("Created"),
            ColumnSpec("Path", overflow="ellipsis", ratio=2),
        ],
    )
    for art in payload.artifacts:
        table_view.add_row(
            art.artifact_id,
            art.kind,
            art.mime,
            str(art.size_bytes),
            art.created_at or "-",
            short_text(art.path, limit=120),
        )
    render_panel("Artifacts", table_view)


def render_artifact_show(payload: ArtifactShowPayload) -> None:
    """Render `agenterm artifacts show` output."""
    rows = [
        ("ID", payload.artifact_id),
        ("Kind", payload.kind),
        ("MIME", payload.mime),
        ("Bytes", str(payload.size_bytes)),
        ("Created", payload.created_at or "-"),
        ("Source", f"{payload.source_type}:{payload.source_id}"),
        ("Session", payload.session_id or "-"),
        ("Path", payload.path),
    ]
    render_panel("Artifact", kv_table(rows))


def render_artifact_open(payload: ArtifactOpenPayload) -> None:
    """Render `agenterm artifacts open` output."""
    rows = [
        ("ID", payload.artifact_id),
        ("Path", payload.path),
    ]
    render_panel("Artifact Opened", kv_table(rows), border="good")


def render_artifact_agent_run(payload: ArtifactAgentRunPayload) -> None:
    """Render `agenterm artifacts agent-run` output."""
    report = payload.report
    model = as_str(report.get("model"))
    created_at = as_str(report.get("created_at"))
    trace_id = as_str(report.get("trace_id"))
    response_id = as_str(report.get("response_id"))
    output_text = as_str(report.get("output_text"))
    input_text = as_str(report.get("input"))
    instructions = as_str(report.get("instructions"))
    truncated = as_bool(report.get("truncated"))
    tool_counts = _parse_int_mapping(report.get("tool_counts"))
    usage = _parse_int_mapping(report.get("usage"))
    response_ids = _list_len(report.get("response_ids"))
    input_items = _list_len(report.get("input_items"))
    output_items = _list_len(report.get("output_items"))

    rows = [
        ("ID", payload.artifact_id),
        ("Model", model or "-"),
        ("Created", created_at or "-"),
        ("Trace", trace_id or "-"),
        ("Response", response_id or "-"),
        ("Responses", str(response_ids) if response_ids is not None else "-"),
        ("Truncated", "true" if truncated else "false"),
        ("Tools", tools_summary(tool_counts or {}) or "-"),
        ("Usage", usage_summary(usage) or "-"),
        ("Input", short_text(input_text, limit=160)),
        ("Instructions", short_text(instructions, limit=160)),
        ("Output", short_text(output_text, limit=240)),
        ("Input items", str(input_items) if input_items is not None else "-"),
        ("Output items", str(output_items) if output_items is not None else "-"),
    ]
    render_panel("Agent Run Report", kv_table(rows))


__all__ = (
    "render_artifact_agent_run",
    "render_artifact_open",
    "render_artifact_show",
    "render_artifacts_list",
)
