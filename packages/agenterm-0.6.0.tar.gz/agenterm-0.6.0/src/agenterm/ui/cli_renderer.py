"""Rich-based renderer for human CLI output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.cli_payloads import (
    AgentPathPayload,
    AgentShowPayload,
    AgentsListPayload,
    AgentsSavePayload,
    ArtifactAgentRunPayload,
    ArtifactOpenPayload,
    ArtifactShowPayload,
    ArtifactsListPayload,
    BranchDeletePayload,
    BranchListPayload,
    BranchUsePayload,
    ConfigPathPayload,
    ConfigSavePayload,
    ConfigShowPayload,
    InspectAgentRunPayload,
    InspectResponsePayload,
    InspectRunEventsPayload,
    InspectRunPayload,
    InspectTurnPayload,
    McpInspectPayload,
    McpServersPayload,
    McpToolsPayload,
    SessionDeletePayload,
    SessionListPayload,
    SessionMetadataPayload,
    SessionRunsPayload,
    TraceShowPayload,
)
from agenterm.core.envelope import JsonPayload, RunPayload
from agenterm.core.errors import DispatchError
from agenterm.engine.mcp_diagnostics import McpStatusSnapshot
from agenterm.ui.cli_renderer_agents import (
    render_agents_list,
    render_agents_path,
    render_agents_save,
    render_agents_show,
)
from agenterm.ui.cli_renderer_artifacts import (
    render_artifact_agent_run,
    render_artifact_open,
    render_artifact_show,
    render_artifacts_list,
)
from agenterm.ui.cli_renderer_base import render_error_report, render_notice
from agenterm.ui.cli_renderer_branches import (
    render_branch_delete,
    render_branch_list,
    render_branch_use,
)
from agenterm.ui.cli_renderer_config import (
    render_config_path,
    render_config_save,
    render_config_show,
)
from agenterm.ui.cli_renderer_mcp import (
    render_mcp_inspect,
    render_mcp_servers,
    render_mcp_status,
    render_mcp_tools,
)
from agenterm.ui.cli_renderer_run import (
    render_inspect_agent_run,
    render_inspect_response,
    render_inspect_run,
    render_inspect_run_events,
    render_inspect_turn,
    render_run_payload,
)
from agenterm.ui.cli_renderer_sessions import (
    render_session_delete,
    render_session_list,
    render_session_runs,
    render_session_show,
)
from agenterm.ui.cli_renderer_trace import render_trace_show

if TYPE_CHECKING:
    from collections.abc import Callable


def _wrap_renderer[T_Payload: JsonPayload](
    payload_type: type[T_Payload],
    renderer: Callable[[T_Payload], None],
) -> Callable[[JsonPayload], None]:
    def _wrapped(payload: JsonPayload) -> None:
        if not isinstance(payload, payload_type):
            msg = f"Unhandled payload type: {payload.__class__.__name__}"
            raise DispatchError(msg)
        renderer(payload)

    return _wrapped


_PAYLOAD_RENDERERS: dict[type[JsonPayload], Callable[[JsonPayload], None]] = {
    ConfigShowPayload: _wrap_renderer(ConfigShowPayload, render_config_show),
    ConfigPathPayload: _wrap_renderer(ConfigPathPayload, render_config_path),
    ConfigSavePayload: _wrap_renderer(ConfigSavePayload, render_config_save),
    AgentsListPayload: _wrap_renderer(
        AgentsListPayload,
        render_agents_list,
    ),
    AgentShowPayload: _wrap_renderer(
        AgentShowPayload,
        render_agents_show,
    ),
    AgentPathPayload: _wrap_renderer(
        AgentPathPayload,
        render_agents_path,
    ),
    AgentsSavePayload: _wrap_renderer(
        AgentsSavePayload,
        render_agents_save,
    ),
    McpServersPayload: _wrap_renderer(McpServersPayload, render_mcp_servers),
    McpToolsPayload: _wrap_renderer(McpToolsPayload, render_mcp_tools),
    McpInspectPayload: _wrap_renderer(McpInspectPayload, render_mcp_inspect),
    McpStatusSnapshot: _wrap_renderer(McpStatusSnapshot, render_mcp_status),
    ArtifactsListPayload: _wrap_renderer(ArtifactsListPayload, render_artifacts_list),
    ArtifactShowPayload: _wrap_renderer(ArtifactShowPayload, render_artifact_show),
    ArtifactOpenPayload: _wrap_renderer(ArtifactOpenPayload, render_artifact_open),
    ArtifactAgentRunPayload: _wrap_renderer(
        ArtifactAgentRunPayload,
        render_artifact_agent_run,
    ),
    SessionListPayload: _wrap_renderer(SessionListPayload, render_session_list),
    SessionMetadataPayload: _wrap_renderer(
        SessionMetadataPayload,
        render_session_show,
    ),
    SessionDeletePayload: _wrap_renderer(SessionDeletePayload, render_session_delete),
    SessionRunsPayload: _wrap_renderer(SessionRunsPayload, render_session_runs),
    BranchListPayload: _wrap_renderer(BranchListPayload, render_branch_list),
    BranchUsePayload: _wrap_renderer(BranchUsePayload, render_branch_use),
    BranchDeletePayload: _wrap_renderer(BranchDeletePayload, render_branch_delete),
    InspectResponsePayload: _wrap_renderer(
        InspectResponsePayload,
        render_inspect_response,
    ),
    InspectRunPayload: _wrap_renderer(
        InspectRunPayload,
        render_inspect_run,
    ),
    InspectRunEventsPayload: _wrap_renderer(
        InspectRunEventsPayload,
        render_inspect_run_events,
    ),
    InspectTurnPayload: _wrap_renderer(
        InspectTurnPayload,
        render_inspect_turn,
    ),
    InspectAgentRunPayload: _wrap_renderer(
        InspectAgentRunPayload,
        render_inspect_agent_run,
    ),
    TraceShowPayload: _wrap_renderer(TraceShowPayload, render_trace_show),
    RunPayload: _wrap_renderer(RunPayload, render_run_payload),
}


def render_payload(*, resource: str, payload: JsonPayload) -> None:
    """Render a typed payload for human CLI output."""
    renderer = _PAYLOAD_RENDERERS.get(type(payload))
    if renderer is None:
        msg = f"Unhandled payload for {resource}: {payload.__class__.__name__}"
        raise DispatchError(msg)
    renderer(payload)


__all__ = ("render_error_report", "render_notice", "render_payload")
