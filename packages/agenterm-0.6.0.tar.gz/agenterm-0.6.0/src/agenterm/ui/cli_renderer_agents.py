"""Agent payload renderers for CLI output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.cli_renderer_base import kv_table, render_panel, render_text_block
from agenterm.ui.renderer import render_markdown

if TYPE_CHECKING:
    from agenterm.core.cli_payloads import (
        AgentPathPayload,
        AgentShowPayload,
        AgentsListPayload,
        AgentsSavePayload,
    )


def _format_list(items: tuple[str, ...]) -> str:
    return ", ".join(items) if items else "(none)"


def render_agents_list(payload: AgentsListPayload) -> None:
    """Render `agenterm agents list` output."""
    rows = [
        ("Available", _format_list(payload.available)),
        ("Local", _format_list(payload.local)),
        ("Global", _format_list(payload.global_agents)),
        ("Bundled", _format_list(payload.bundled)),
    ]
    render_panel("Agents", kv_table(rows))


def render_agents_show(payload: AgentShowPayload) -> None:
    """Render `agenterm agents show` output."""
    if payload.render_mode == "plain":
        lines = [
            "Agent:",
            f"- name: {payload.name}",
            f"- source: {payload.source or '(none)'}",
            f"- path: {payload.path or '(none)'}",
            f"- sha256: {payload.sha256 or '(none)'}",
            f"- size_bytes: {payload.size_bytes}",
            "",
            payload.text,
        ]
        render_text_block("\n".join(lines))
        return

    rows = [
        ("Agent", payload.name),
        ("Source", payload.source or "(none)"),
        ("Path", payload.path or "(none)"),
        ("SHA256", payload.sha256 or "(none)"),
        ("Size (bytes)", str(payload.size_bytes)),
    ]
    render_panel("Agent", kv_table(rows))
    render_markdown(payload.text)


def render_agents_path(payload: AgentPathPayload) -> None:
    """Render `agenterm agents path` output."""
    rows = [
        ("Agent", payload.name),
        ("Path", payload.path or "(none)"),
        ("Source", payload.source or "-"),
    ]
    render_panel("Agent Path", kv_table(rows))


def render_agents_save(payload: AgentsSavePayload) -> None:
    """Render `agenterm agents save` output."""
    rows = [
        ("Scope", payload.scope),
        ("Source", payload.source),
        ("Count", str(len(payload.paths))),
        ("Overwritten", "yes" if payload.overwritten else "no"),
    ]
    if payload.paths:
        rows.append(("Paths", "\n".join(payload.paths)))
    render_panel("Agents Saved", kv_table(rows), border="good")


__all__ = (
    "render_agents_list",
    "render_agents_path",
    "render_agents_save",
    "render_agents_show",
)
