"""Shared rendering primitives for REPL and streamed CLI output.

This module centralizes agent output rendering while allowing different
surfaces to choose how richly they render text:

- `run` renders agent output as Markdown via Rich for a polished one-shot
  experience.
- The REPL renders agent output as calm, wrapped plain text so the raw
  Markdown/content is visible and easy to copy.

Rendering stays separate from engine/session logic so storage and
conversation semantics remain untouched.
"""

from __future__ import annotations

import re
from contextlib import contextmanager
from typing import TYPE_CHECKING, Final

from rich.console import Group
from rich.markdown import Markdown
from rich.padding import Padding
from rich.text import Text

from agenterm.ui.cli_renderer_base import (
    begin_block,
    block,
    cli_console,
    end_block,
    panel,
)
from agenterm.ui.cli_settings import get_cli_output_settings
from agenterm.ui.transcript.diffs import parse_numbered_diff_line

if TYPE_CHECKING:
    from collections.abc import Iterator, Sequence

    from rich.console import Console, RenderableType
    from rich.status import Status

    from agenterm.core.plan import PlanStep


def _make_console(*, stderr: bool = False) -> Console:
    """Construct a Console bound to the current stdout/stderr.

    A new Console is created per call so that prompt_toolkit's `patch_stdout`
    integration (used by the REPL) continues to work as expected.
    """
    # Soft wrapping keeps long lines readable without horizontal scrolling.
    return cli_console(stderr=stderr)


_REPL_BLOCK_PADDING: Final[tuple[int, int, int, int]] = (0, 2, 0, 2)


def _wrap_repl_block(renderable: RenderableType) -> RenderableType:
    settings = get_cli_output_settings()
    if settings.surface != "repl":
        return renderable
    return Padding(renderable, pad=_REPL_BLOCK_PADDING)


def render_markdown(text: str) -> None:
    """Render agent output as Markdown using Rich.

    Intended for one-shot CLI surfaces (`agenterm run`) where a richer visual
    representation is desirable.
    """
    if not text:
        return
    console: Final = _make_console()
    with block(console):
        console.print(_wrap_repl_block(Markdown(text)))


def render_plain(text: str) -> None:
    """Render a single plain line without block spacing."""
    if not text:
        return
    console: Final = _make_console()
    console.print(text, markup=False, highlight=False)


def render_plain_block(text: str) -> None:
    """Render plain text as a spaced block."""
    if not text:
        return
    console: Final = _make_console()
    with block(console):
        console.print(_wrap_repl_block(Text(text)), markup=False, highlight=False)


def render_command_output(text: str, *, title: str = "Command") -> None:
    """Render command output inside a themed panel."""
    if not text:
        return
    console: Final = _make_console()
    with block(console):
        console.print(_wrap_repl_block(panel(title, Text(text))))


def render_plain_fragment(text: str) -> None:
    """Render text without forcing a trailing newline.

    Intended for live streaming in the REPL when verbosity is set to debug,
    where the transcript should reflect output deltas as they arrive.
    """
    if not text:
        return
    console: Final = _make_console()
    console.print(text, end="", markup=False, highlight=False)


def render_newline() -> None:
    """Render a single blank line."""
    console: Final = _make_console()
    console.print()


def render_block_start() -> None:
    """Open a spaced block for streamed output."""
    console: Final = _make_console()
    begin_block(console)


def render_block_end() -> None:
    """Close a spaced block for streamed output."""
    console: Final = _make_console()
    end_block(console)


# ---------------------------------------------------------------------------
# Status spinner for async operations
# ---------------------------------------------------------------------------


@contextmanager
def status_spinner(message: str = "Waiting for response...") -> Iterator[Status]:
    """Context manager that displays a spinner during async operations.

    Usage:
        with status_spinner("Processing..."):
            await long_running_operation()
    """
    console: Final = _make_console()
    with console.status(message, spinner="dots") as status:
        yield status


# ---------------------------------------------------------------------------
# Tool event rendering with visual hierarchy
# ---------------------------------------------------------------------------


def _tool_event_line(
    event_type: str,
    label: str,
    *,
    success: bool | None = None,
) -> str:
    if success is True:
        mark = " [good]✓[/good]"
    elif success is False:
        mark = " [error]✗[/error]"
    else:
        mark = ""
    return f"[dim]\\[{event_type}][/dim]{mark} {label}"


def render_tool_event(
    event_type: str,
    label: str,
    *,
    success: bool | None = None,
) -> None:
    """Render a tool call or output event header (no block spacing)."""
    console: Final = _make_console()
    console.print(_tool_event_line(event_type, label, success=success))


def render_tool_block(
    event_type: str,
    label: str,
    *,
    success: bool | None = None,
    detail_lines: Sequence[str] | None = None,
) -> None:
    """Render a tool event header and detail lines as one block."""
    header = Text.from_markup(_tool_event_line(event_type, label, success=success))
    lines: list[Text] = [header]
    for line in detail_lines or ():
        parsed = parse_numbered_diff_line(line)
        if parsed is None:
            lines.append(Text(line))
            continue
        prefix, content, kind = parsed
        style = _DIFF_STYLE_MAP.get(kind, "")
        text = Text(prefix, style="dim")
        if style:
            text.append(content, style=style)
        else:
            text.append(content)
        lines.append(text)
    body = Group(*lines)
    console: Final = _make_console()
    with block(console):
        console.print(_wrap_repl_block(body))


_HUNK_RE: Final = re.compile(r"^@@ -(\d+)(?:,(\d+))? \\+(\d+)(?:,(\d+))? @@")
_DIFF_FILE_HEADERS: Final[tuple[str, ...]] = ("+++", "---")
_PREFIX_RULES: Final[dict[str, tuple[int, int, str]]] = {
    "+": (0, 1, "good"),
    "-": (1, 0, "error"),
    " ": (1, 1, ""),
}
_DIFF_STYLE_MAP: Final[dict[str, str]] = {
    "add": "good",
    "remove": "error",
    "hunk": "warn",
    "header": "dim",
    "context": "",
}


def _parse_hunk_header(line: str) -> tuple[int, int] | None:
    if not line.startswith("@@"):
        return None
    match = _HUNK_RE.match(line)
    if match is None:
        return None
    return int(match.group(1)), int(match.group(3))


def _prefix_rule(line: str) -> tuple[int, int, str] | None:
    return _PREFIX_RULES.get(line[:1])


def _scan_diff_line_numbers(lines: list[str]) -> tuple[int, int]:
    max_old = 0
    max_new = 0
    old_line: int | None = None
    new_line: int | None = None
    for line in lines:
        hunk = _parse_hunk_header(line)
        if hunk is not None:
            old_line, new_line = hunk
            max_old = max(max_old, old_line)
            max_new = max(max_new, new_line)
            continue
        if line.startswith(_DIFF_FILE_HEADERS):
            continue
        rule = _prefix_rule(line)
        if rule is None:
            continue
        delta_old, delta_new, _style = rule
        if delta_old and old_line is not None:
            max_old = max(max_old, old_line)
            old_line += delta_old
        if delta_new and new_line is not None:
            max_new = max(max_new, new_line)
            new_line += delta_new
    return max_old, max_new


def _apply_prefix_line(
    line: str,
    *,
    old_line: int | None,
    new_line: int | None,
) -> tuple[int | None, int | None, str, str, str]:
    rule = _prefix_rule(line)
    if rule is None:
        return old_line, new_line, "", "", ""
    delta_old, delta_new, style = rule
    old_num = str(old_line) if delta_old and old_line is not None else ""
    new_num = str(new_line) if delta_new and new_line is not None else ""
    if delta_old and old_line is not None:
        old_line += delta_old
    if delta_new and new_line is not None:
        new_line += delta_new
    return old_line, new_line, old_num, new_num, style


def render_unified_diff(diff: str) -> None:
    """Render a unified diff with line numbers and color using Rich."""
    raw = diff.strip("\n")
    if not raw:
        return
    lines = raw.splitlines()
    max_old, max_new = _scan_diff_line_numbers(lines)
    width = max(len(str(max_old)), len(str(max_new)), 1)
    old_line: int | None = None
    new_line: int | None = None
    console: Final = _make_console()

    rendered: list[Text] = []
    for line in lines:
        old_num = ""
        new_num = ""
        style = ""
        hunk = _parse_hunk_header(line)
        if hunk is not None:
            old_line, new_line = hunk
            style = "warn"
        elif line.startswith(_DIFF_FILE_HEADERS):
            style = "dim"
        else:
            old_line, new_line, old_num, new_num, style = _apply_prefix_line(
                line,
                old_line=old_line,
                new_line=new_line,
            )
        prefix = f"{old_num:>{width}} {new_num:>{width}} | "
        text = Text(prefix, style="dim")
        text.append(line, style=style)
        rendered.append(text)
    with block(console):
        console.print(_wrap_repl_block(Group(*rendered)))


def _plan_status_marker(status: str) -> str:
    if status == "completed":
        return "✔"
    if status == "in_progress":
        return "▶"
    return "•"


def render_plan_update(
    *,
    explanation: str | None,
    steps: Sequence[PlanStep],
) -> None:
    """Render a structured plan update block."""
    lines: list[Text] = [Text("• Updated Plan")]
    if explanation:
        lines.append(Text(f"  └ {explanation}"))
        indent = "    "
    else:
        indent = "  "
    for step in steps:
        marker = _plan_status_marker(step.status)
        lines.append(Text(f"{indent}{marker} {step.step}"))
    console: Final = _make_console()
    with block(console):
        console.print(_wrap_repl_block(Group(*lines)))


def render_reasoning(text: str | None = None) -> None:
    """Render a reasoning block indicator and optional text.

    The caller should pass ReasoningBlock.display_text (content > summary).
    """
    lines: list[Text] = [Text("[reasoning]", style="dim")]
    if text:
        lines.extend(
            [Text(line, style="dim") for line in text.splitlines() if line.strip()],
        )
    console: Final = _make_console()
    with block(console):
        console.print(_wrap_repl_block(Group(*lines)))


def render_reasoning_header() -> None:
    """Render a reasoning header line without block spacing."""
    console: Final = _make_console()
    console.print("[dim]\\[reasoning][/dim]")


def render_reasoning_fragment(text: str) -> None:
    """Render reasoning summary text without forcing a trailing newline."""
    if not text:
        return
    console: Final = _make_console()
    console.print(text, end="", style="dim", markup=False, highlight=False)


# ---------------------------------------------------------------------------
# Run separator for REPL
# ---------------------------------------------------------------------------


def render_run_separator(run_number: int | None = None) -> None:
    """Render a visual separator between runs in the REPL.

    Args:
        run_number: Optional run number to display

    """
    console: Final = _make_console()
    with block(console):
        if run_number is not None:
            console.rule(f"[dim]run {run_number}[/dim]", style="dim", align="right")
        else:
            console.rule(style="dim")


__all__: Final[tuple[str, ...]] = (
    "render_block_end",
    "render_block_start",
    "render_command_output",
    "render_markdown",
    "render_plain",
    "render_plain_block",
    "render_plain_fragment",
    "render_plan_update",
    "render_reasoning",
    "render_reasoning_fragment",
    "render_reasoning_header",
    "render_run_separator",
    "render_tool_block",
    "render_tool_event",
    "render_unified_diff",
    "status_spinner",
)
