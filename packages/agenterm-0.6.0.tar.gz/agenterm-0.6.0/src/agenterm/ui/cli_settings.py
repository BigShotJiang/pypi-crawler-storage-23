"""CLI rendering settings stored in the Click context."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Literal

import click

from agenterm.config.decode import discover_config_path, load_raw_config
from agenterm.core.errors import ConfigError, FilesystemError

if TYPE_CHECKING:
    from agenterm.core.choices.repl_ui import ReplTheme


def _discover_theme_from_config() -> ReplTheme:
    """Read theme from config without full validation. Returns 'dark' on any error."""
    default: ReplTheme = "dark"
    try:
        config_path = discover_config_path(None)
        if config_path is None:
            return default
        raw = load_raw_config(config_path)
        if not isinstance(raw, dict):
            return default
        repl = raw.get("repl")
        if not isinstance(repl, dict):
            return default
        ui = repl.get("ui")
        if not isinstance(ui, dict):
            return default
        theme = ui.get("theme")
    except (ConfigError, FilesystemError, OSError, TypeError, ValueError):
        return default
    else:
        return theme if theme in ("dark", "light") else default


@dataclass(frozen=True)
class CliOutputSettings:
    """Global CLI output toggles derived from top-level flags."""

    quiet: bool = False
    verbose: bool = False
    theme: ReplTheme = "dark"
    surface: Literal["cli", "repl"] = "cli"


@dataclass(frozen=True)
class CliContext:
    """Click context payload for CLI output settings."""

    output: CliOutputSettings


def set_cli_output_settings(settings: CliOutputSettings) -> None:
    """Persist CLI output settings in the current Click context."""
    ctx = click.get_current_context()
    ctx.obj = CliContext(output=settings)


def set_cli_output_surface(surface: Literal["cli", "repl"]) -> None:
    """Update the output surface while preserving existing CLI settings."""
    ctx = click.get_current_context(silent=True)
    if ctx is None:
        return
    settings = get_cli_output_settings()
    if settings.surface == surface:
        return
    set_cli_output_settings(replace(settings, surface=surface))


def get_cli_output_settings() -> CliOutputSettings:
    """Return CLI output settings from the Click context, or defaults."""
    ctx = click.get_current_context(silent=True)
    if ctx is None:
        return CliOutputSettings()
    obj = ctx.obj
    if isinstance(obj, CliContext):
        return obj.output
    return CliOutputSettings()


def discover_cli_theme() -> ReplTheme:
    """Discover theme from config for CLI output. Returns 'dark' on any error."""
    return _discover_theme_from_config()


__all__ = (
    "CliContext",
    "CliOutputSettings",
    "discover_cli_theme",
    "get_cli_output_settings",
    "set_cli_output_settings",
    "set_cli_output_surface",
)
