"""Session payload renderers for CLI output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.text import display_role, shorten_line
from agenterm.ui.cli_renderer_base import (
    ColumnSpec,
    kv_table,
    relative_time,
    render_notice,
    render_panel,
    table,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.cli_payloads import (
        RunSummaryPayload,
        SessionDeletePayload,
        SessionListPayload,
        SessionMetadataPayload,
        SessionRunsPayload,
    )

_SESSION_LIST_COLUMNS = (
    ("Session", 9),
    ("Updated", 8),
    ("Last message", 96),
)
_SESSION_ID_HEAD = 4
_SESSION_ID_TAIL = 4
_SESSION_ID_MIN = _SESSION_ID_HEAD + _SESSION_ID_TAIL
_RESPONSE_ID_PREVIEW = 14
_RESPONSE_ID_PREVIEW_TAIL = 11


def _format_session_row(values: tuple[str, ...]) -> str:
    parts: list[str] = []
    last_index = len(_SESSION_LIST_COLUMNS) - 1
    for idx, (value, (_label, width)) in enumerate(
        zip(values, _SESSION_LIST_COLUMNS, strict=False)
    ):
        cell = shorten_line(value, limit=width)
        if idx < last_index:
            parts.append(cell.ljust(width))
        else:
            parts.append(cell)
    return "  ".join(parts).rstrip()


def _session_list_header() -> tuple[str, str]:
    header = _format_session_row(tuple(label for label, _ in _SESSION_LIST_COLUMNS))
    divider = "-" * len(header)
    return header, divider


def _session_id_preview(session_id: str) -> str:
    if len(session_id) <= _SESSION_ID_MIN:
        return session_id
    return f"{session_id[:_SESSION_ID_HEAD]}…{session_id[-_SESSION_ID_TAIL:]}"


def _two_line_preview(text: str, *, width: int) -> tuple[str, str]:
    compact = " ".join(text.split())
    if not compact:
        return "", ""
    if len(compact) <= width:
        return compact, ""
    split_at = compact.rfind(" ", 0, width + 1)
    if split_at <= 0:
        split_at = width
    first = compact[:split_at].rstrip()
    remainder = compact[split_at:].lstrip()
    second = shorten_line(remainder, limit=width)
    return first, second


def render_session_list(payload: SessionListPayload) -> None:
    """Render `agenterm session list` output."""
    if not payload.sessions:
        render_notice(title="Sessions", message="No sessions found.", style="warn")
        return
    header, divider = _session_list_header()
    lines: list[str] = [f"Sessions ({len(payload.sessions)}):", header, divider]
    for sess in payload.sessions:
        last_msg = sess.last_message_snippet or "-"
        role_label = display_role(sess.last_message_role)
        if role_label:
            last_msg = f"{role_label}: {last_msg}"
        updated = relative_time(sess.updated_at)
        session_id = _session_id_preview(sess.session_id)
        msg_first, msg_second = _two_line_preview(
            last_msg,
            width=_SESSION_LIST_COLUMNS[2][1],
        )
        if last_msg != "-" and not msg_second:
            msg_second = "…"
        lines.append(
            _format_session_row(
                (
                    session_id,
                    updated,
                    msg_first or "-",
                )
            ),
        )
        if msg_second:
            lines.append(
                _format_session_row(
                    (
                        "",
                        "",
                        msg_second,
                    )
                ),
            )
    render_panel("Sessions", "\n".join(lines))


def render_session_show(payload: SessionMetadataPayload) -> None:
    """Render `agenterm session show` output."""
    rows = [
        ("Session ID", payload.session_id),
        ("Kind", payload.kind),
        ("Model", payload.model),
        ("CWD", payload.cwd),
        ("Config path", payload.config_path or "(defaults)"),
        ("Tools enabled", "on" if payload.tools_enabled else "off"),
        ("Head branch", payload.head_branch_id),
        ("Trace ID", payload.trace_id or "(none)"),
        ("Group ID", payload.group_id or "(none)"),
        ("Created", payload.created_at or "-"),
        ("Updated", payload.updated_at or "-"),
    ]
    render_panel("Session", kv_table(rows))

    branch = payload.head_branch
    branch_rows = [
        ("Branch ID", branch.branch_id),
        ("Kind", branch.kind),
        ("Title", branch.title or "(none)"),
        ("Pinned", "yes" if branch.pinned else "no"),
        ("Reason", branch.created_reason or "(none)"),
        ("Parent branch", branch.parent_branch_id or "(none)"),
        (
            "Fork run",
            str(branch.fork_run_number) if branch.fork_run_number else "(none)",
        ),
        ("Agent", branch.agent_name),
        ("Agent path", branch.agent_path or "(none)"),
        ("Agent sha256", branch.agent_sha256 or "(none)"),
        ("Store", "on" if branch.store_enabled else "off"),
        ("Last response", branch.last_response_id or "(none)"),
    ]
    render_panel("Head Branch", kv_table(branch_rows))
    if payload.usage_total:
        usage_rows = [(k, str(v)) for k, v in payload.usage_total.items()]
        render_panel("Usage", kv_table(usage_rows))


def render_session_delete(payload: SessionDeletePayload) -> None:
    """Render `agenterm session delete` output."""
    status = "deleted" if payload.deleted else "not found"
    rows = [
        ("Session ID", payload.session_id),
        ("Status", status),
    ]
    border = "good" if payload.deleted else "warn"
    render_panel("Session Delete", kv_table(rows), border=border)


def _format_run_row(
    run: RunSummaryPayload,
    usage_by_run: Mapping[str, Mapping[str, int]],
) -> tuple[str, str, str, str, str]:
    run_key = str(run.run_number)
    usage = usage_by_run.get(run_key)
    if usage is not None:
        tokens_str = (
            f"{usage.get('input_tokens', 0)}({usage.get('input_cached_tokens', 0)})"
            f"->{usage.get('output_tokens', 0)}"
            f"({usage.get('output_reasoning_tokens', 0)})"
            f"={usage.get('total_tokens', 0)}"
        )
    else:
        tokens_str = "-"
    response_id = run.response_id or "-"
    if len(response_id) > _RESPONSE_ID_PREVIEW:
        response_id = response_id[:_RESPONSE_ID_PREVIEW_TAIL] + "..."
    time_str = relative_time(run.updated_at or run.started_at)
    return (
        str(run.run_number),
        run.status or "-",
        tokens_str,
        response_id,
        time_str,
    )


def render_session_runs(payload: SessionRunsPayload) -> None:
    """Render `agenterm session runs` output."""
    runs = payload.runs
    if not runs:
        render_notice(title="Session Runs", message="No runs recorded.", style="warn")
        return
    table_view = table(
        [
            ColumnSpec("#", style="muted", justify="right"),
            ColumnSpec("Status"),
            ColumnSpec("Tokens", justify="right"),
            ColumnSpec("Response"),
            ColumnSpec("Updated", justify="right", style="muted"),
        ],
    )
    for run in runs:
        row = _format_run_row(run, usage_by_run=payload.usage_by_run)
        table_view.add_row(*row)
    render_panel(
        f"Session Runs - {payload.session_id} ({payload.branch_id})",
        table_view,
    )


__all__ = (
    "render_session_delete",
    "render_session_list",
    "render_session_runs",
    "render_session_show",
)
