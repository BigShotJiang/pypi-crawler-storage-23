"""Approvals helpers for REPL and TUI surfaces."""

from __future__ import annotations

from agenterm.ui.approvals.pending import (
    ApprovalModalInputResult,
    handle_modal_approval_input,
    has_pending_approvals,
    resolve_next_pending,
    resolve_next_pending_with_reason,
)

__all__ = (
    "ApprovalModalInputResult",
    "handle_modal_approval_input",
    "has_pending_approvals",
    "resolve_next_pending",
    "resolve_next_pending_with_reason",
)
