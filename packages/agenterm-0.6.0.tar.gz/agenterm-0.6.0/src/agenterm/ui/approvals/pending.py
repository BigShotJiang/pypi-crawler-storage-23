"""REPL/TUI helpers for resolving pending approvals."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.approvals import ApprovalsContext
    from agenterm.ui.repl.phase_state import ReplHudLevel


def has_pending_approvals(approvals: ApprovalsContext) -> bool:
    """Return True when any approval manager has pending items."""
    return bool(
        approvals.compress.pending()
        or approvals.shell.pending()
        or approvals.patch.pending()
        or approvals.mcp.pending(),
    )


def resolve_next_pending(
    approvals: ApprovalsContext,
    *,
    approved: bool,
) -> str | None:
    """Resolve the next pending approval and return its id (or None)."""
    return resolve_next_pending_with_reason(
        approvals,
        approved=approved,
        reason=None,
    )


def resolve_next_pending_with_reason(
    approvals: ApprovalsContext,
    *,
    approved: bool,
    reason: str | None,
) -> str | None:
    """Resolve the next pending approval and return its id (or None)."""
    compress_mgr = approvals.compress
    pending_compress = compress_mgr.pending()
    if pending_compress:
        item = pending_compress[0]
        compress_mgr.resolve(item.id, approved=approved, reason=reason)
        return item.id

    shell_mgr = approvals.shell
    pending_shell = shell_mgr.pending()
    if pending_shell:
        item = pending_shell[0]
        shell_mgr.resolve(item.id, approved=approved, reason=reason)
        return item.id

    patch_mgr = approvals.patch
    pending_patch = patch_mgr.pending()
    if pending_patch:
        item = pending_patch[0]
        patch_mgr.resolve(item.id, approved=approved, reason=reason)
        return item.id

    mcp_mgr = approvals.mcp
    pending_mcp = mcp_mgr.pending()
    if pending_mcp:
        item = pending_mcp[0]
        mcp_mgr.resolve(item.id, approved=approved, reason=reason)
        return item.id

    return None


@dataclass(frozen=True)
class ApprovalModalInputResult:
    """Outcome of an approvals modal input submission."""

    notice: str
    level: ReplHudLevel
    handled: bool


def handle_modal_approval_input(
    *,
    text: str,
    approvals: ApprovalsContext,
) -> ApprovalModalInputResult:
    """Handle approvals input entered in the focused approvals modal."""
    tokens = (text or "").strip().split(maxsplit=1)
    head = tokens[0].lower() if tokens else ""
    tail = tokens[1].strip() if len(tokens) > 1 else ""

    if head in ("y", "yes"):
        ident = resolve_next_pending_with_reason(
            approvals,
            approved=True,
            reason=None,
        )
        if ident is None:
            return ApprovalModalInputResult(
                notice="No pending approvals.",
                level="info",
                handled=True,
            )
        return ApprovalModalInputResult(
            notice=f"Approved: {ident}",
            level="info",
            handled=True,
        )
    if head in ("n", "no"):
        ident = resolve_next_pending_with_reason(
            approvals,
            approved=False,
            reason=(tail or None),
        )
        if ident is None:
            return ApprovalModalInputResult(
                notice="No pending approvals.",
                level="info",
                handled=True,
            )
        return ApprovalModalInputResult(
            notice=f"Rejected: {ident}",
            level="warn",
            handled=True,
        )
    if has_pending_approvals(approvals):
        return ApprovalModalInputResult(
            notice="Approval pending - enter y/yes or n/no [reason].",
            level="warn",
            handled=False,
        )
    return ApprovalModalInputResult(
        notice="No pending approvals.",
        level="info",
        handled=False,
    )


__all__ = (
    "ApprovalModalInputResult",
    "handle_modal_approval_input",
    "has_pending_approvals",
    "resolve_next_pending",
    "resolve_next_pending_with_reason",
)
