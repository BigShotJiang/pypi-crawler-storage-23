"""Run and inspect payload renderers for CLI output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.text import Text

from agenterm.core.cli_payloads_artifacts import ArtifactAgentRunPayload
from agenterm.core.json_codec import dumps_pretty
from agenterm.ui.cli_renderer_artifacts import render_artifact_agent_run
from agenterm.ui.cli_renderer_base import (
    kv_table,
    render_notice,
    render_panel,
    tools_summary,
    usage_summary,
)
from agenterm.ui.render_artifacts import render_image_artifact
from agenterm.ui.renderer import render_markdown

if TYPE_CHECKING:
    from agenterm.core.cli_payloads import (
        InspectAgentRunPayload,
        InspectResponsePayload,
        InspectRunEventsPayload,
        InspectRunPayload,
        InspectTurnPayload,
    )
    from agenterm.core.envelope import RunPayload


def render_inspect_response(payload: InspectResponsePayload) -> None:
    """Render `agenterm inspect response` output."""
    usage_line = usage_summary(payload.usage)
    background_label = (
        "-"
        if payload.background is None
        else ("true" if payload.background else "false")
    )
    input_items_count = (
        len(payload.input_items) if payload.input_items is not None else None
    )
    rows = [
        ("Response ID", payload.response_id),
        ("Model", payload.model or "-"),
        ("Status", payload.status or "-"),
        ("Background", background_label),
        ("Usage", usage_line or "-"),
        (
            "Input items",
            str(input_items_count) if input_items_count is not None else "-",
        ),
    ]
    if payload.input_items is not None:
        rows.extend(
            [
                (
                    "Input page",
                    (
                        f"order={payload.input_items_order or '-'} "
                        f"limit={payload.input_items_limit or '-'}"
                    ),
                ),
                (
                    "Input has more",
                    (
                        "-"
                        if payload.input_items_has_more is None
                        else ("true" if payload.input_items_has_more else "false")
                    ),
                ),
                ("Input next_after", payload.input_items_next_after or "-"),
            ]
        )
    render_panel("Inspect Response", kv_table(rows), border="muted")
    if payload.text:
        render_panel("Output", Text(payload.text))
    else:
        render_notice(
            title="Inspect Response",
            message=f"No content for response {payload.response_id}",
            style="warn",
        )
    if payload.input_items is not None:
        items_json = dumps_pretty(
            [dict(item) for item in payload.input_items],
            ensure_ascii=False,
            indent=2,
            context="cli_renderer_run.inspect_response.input_items",
        )
        render_panel("Input Items", Text(items_json))


def render_inspect_run(payload: InspectRunPayload) -> None:
    """Render `agenterm inspect run` output."""
    usage_line = usage_summary(payload.usage)
    rows = [
        ("Session ID", payload.session_id),
        ("Branch ID", payload.branch_id),
        ("Run", str(payload.run_number)),
        ("Status", payload.status or "-"),
        ("Response ID", payload.response_id or "-"),
        ("Trace ID", payload.trace_id or "-"),
        ("Started", payload.started_at or "-"),
        ("Updated", payload.updated_at or "-"),
        ("Usage", usage_line or "-"),
        ("Events", str(payload.events_count)),
    ]
    render_panel("Inspect Run", kv_table(rows), border="muted")

    if payload.items:
        items_json = dumps_pretty(
            [dict(item) for item in payload.items],
            ensure_ascii=False,
            indent=2,
            context="cli_renderer_run.inspect_run.items",
        )
        render_panel("Items", Text(items_json))
    else:
        render_notice(
            title="Inspect Run",
            message="No items recorded for this run.",
            style="warn",
        )

    if payload.artifacts:
        lines = [
            f"- {art.artifact_id}  {art.mime}  {art.path}" for art in payload.artifacts
        ]
        render_panel("Artifacts", Text("\n".join(lines)))


def render_inspect_run_events(payload: InspectRunEventsPayload) -> None:
    """Render `agenterm inspect run-events` output."""
    rows = [
        ("Session ID", payload.session_id),
        ("Branch ID", payload.branch_id),
        ("Run", str(payload.run_number)),
        ("Events", str(len(payload.events))),
    ]
    render_panel("Inspect Run Events", kv_table(rows), border="muted")

    if payload.events:
        events_json = dumps_pretty(
            [dict(event) for event in payload.events],
            ensure_ascii=False,
            indent=2,
            context="cli_renderer_run.inspect_run_events.events",
        )
        render_panel("Events", Text(events_json))
    else:
        render_notice(
            title="Inspect Run Events",
            message="No events recorded for this run.",
            style="warn",
        )


def render_inspect_turn(payload: InspectTurnPayload) -> None:
    """Render `agenterm inspect turn` output."""
    rows = [
        ("Session ID", payload.session_id),
        ("Branch ID", payload.branch_id),
        ("Turn", str(payload.turn_number)),
        ("Items", str(len(payload.items))),
    ]
    render_panel("Inspect Turn", kv_table(rows), border="muted")

    if payload.items:
        items_json = dumps_pretty(
            [dict(item) for item in payload.items],
            ensure_ascii=False,
            indent=2,
            context="cli_renderer_run.inspect_turn.items",
        )
        render_panel("Items", Text(items_json))
    else:
        render_notice(
            title="Inspect Turn",
            message="No items recorded for this turn.",
            style="warn",
        )

    if payload.artifacts:
        lines = [
            f"- {art.artifact_id}  {art.mime}  {art.path}" for art in payload.artifacts
        ]
        render_panel("Artifacts", Text("\n".join(lines)))


def render_inspect_agent_run(payload: InspectAgentRunPayload) -> None:
    """Render `agenterm inspect agent-run` output."""
    render_artifact_agent_run(
        ArtifactAgentRunPayload(
            artifact_id=payload.report_id,
            report=payload.report,
        ),
    )


def render_run_payload(payload: RunPayload) -> None:
    """Render `agenterm run` output."""
    if payload.background:
        response = payload.response_id or "(none)"
        rows = [("Response ID", response), ("Mode", payload.mode)]
        render_panel("Background Run", kv_table(rows), border="good")
        return

    if payload.text:
        render_markdown(payload.text)

    if payload.artifacts:
        for art in payload.artifacts:
            if art.kind == "image":
                render_image_artifact(
                    artifact_id=art.artifact_id,
                    path=art.path,
                    mime=art.mime,
                    size_bytes=art.size_bytes,
                    inline_preview=True,
                )

    tools_line = tools_summary(payload.tools)
    usage_line = usage_summary(payload.usage)
    footer_rows = [
        ("Tools", tools_line or "-"),
        ("Usage", usage_line or "-"),
        ("Response ID", payload.response_id or "-"),
        ("Session ID", payload.session_id or "-"),
    ]
    if payload.attachments:
        footer_rows.insert(0, ("Attachments", str(len(payload.attachments))))
    render_panel("Run Summary", kv_table(footer_rows), border="muted")


__all__ = (
    "render_inspect_agent_run",
    "render_inspect_response",
    "render_inspect_run",
    "render_inspect_run_events",
    "render_inspect_turn",
    "render_run_payload",
)
