"""Artifact rendering helpers for CLI/REPL output."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Final

from agenterm.core.error_report import ErrorContext, build_error_report
from agenterm.core.errors import FilesystemError
from agenterm.ui.cli_renderer_base import block, cli_console, render_error_report
from agenterm.ui.iterm2 import (
    file_url,
    is_iterm2,
    iterm2_inline_image_sequence,
    iterm2_inline_image_sequence_from_path,
    osc8_link,
)

if TYPE_CHECKING:
    from rich.console import Console


def _make_console(*, stderr: bool = False) -> Console:
    """Construct a Console bound to the current stdout/stderr."""
    return cli_console(stderr=stderr)


def render_artifact_event(label: str) -> None:
    """Render an artifact creation event header."""
    console: Final = _make_console()
    console.print(f"[dim]\\[artifact][/dim] {label}")


def _render_image_artifact_header(
    console: Console,
    *,
    artifact_id: str,
    path: str,
    mime: str,
    size_bytes: int,
) -> Path:
    render_artifact_event(f"image {artifact_id}")

    p = Path(path)
    link = osc8_link(str(p), file_url(p))
    console.print(f"Saved: {link}", markup=False, highlight=False)
    console.print(
        f"Meta: {mime} • {size_bytes} bytes",
        style="dim",
        markup=False,
        highlight=False,
    )
    return p


def _emit_inline_image_sequence(console: Console, seq: str | None) -> None:
    if not seq:
        return
    console.file.write(seq)
    console.file.write("\n")
    console.file.flush()


def render_image_artifact(
    *,
    artifact_id: str,
    path: str,
    mime: str,
    size_bytes: int,
    inline_preview: bool = True,
) -> None:
    """Render an image artifact card (sync)."""
    console: Final = _make_console()
    with block(console):
        p = _render_image_artifact_header(
            console,
            artifact_id=artifact_id,
            path=path,
            mime=mime,
            size_bytes=size_bytes,
        )

        # Emit the inline image last. In prompt_toolkit-driven REPL mode, stdout is
        # proxied and each newline may trigger an erase+redraw cycle; printing more
        # lines after an OSC-1337 image can clear it from the UI region.
        if inline_preview and is_iterm2():
            try:
                seq = iterm2_inline_image_sequence_from_path(p)
            except FilesystemError as exc:
                report = build_error_report(
                    exc,
                    context=ErrorContext(
                        operation="artifact.render",
                        resource="ui.inline_image",
                        trace_id=None,
                    ),
                )
                render_error_report(report)
                return
            _emit_inline_image_sequence(console, seq)


async def render_image_artifact_async(
    *,
    artifact_id: str,
    path: str,
    mime: str,
    size_bytes: int,
    inline_preview: bool = True,
) -> None:
    """Render an image artifact card without blocking the event loop."""
    console: Final = _make_console()
    with block(console):
        p = _render_image_artifact_header(
            console,
            artifact_id=artifact_id,
            path=path,
            mime=mime,
            size_bytes=size_bytes,
        )

        if inline_preview and is_iterm2():
            try:
                data = await asyncio.to_thread(p.read_bytes)
            except OSError as exc:
                msg = f"Failed to read image artifact at {p}: {exc}"
                report = build_error_report(
                    FilesystemError(msg),
                    context=ErrorContext(
                        operation="artifact.render",
                        resource="ui.inline_image",
                        trace_id=None,
                    ),
                )
                render_error_report(report)
                return
            seq = iterm2_inline_image_sequence(data, name=p.name, width="auto")
            _emit_inline_image_sequence(console, seq)


__all__ = (
    "render_artifact_event",
    "render_image_artifact",
    "render_image_artifact_async",
)
