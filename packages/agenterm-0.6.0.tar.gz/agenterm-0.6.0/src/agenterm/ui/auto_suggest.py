"""Auto-suggest helpers for the REPL prompt."""

from __future__ import annotations

from typing import TYPE_CHECKING

from prompt_toolkit.auto_suggest import AutoSuggest, Suggestion

if TYPE_CHECKING:
    from prompt_toolkit.buffer import Buffer
    from prompt_toolkit.document import Document


class HistoryAutoSuggest(AutoSuggest):
    """Suggest full prior inputs from prompt history."""

    def __init__(self, *, allow_slash: bool = False) -> None:
        """Configure whether slash-prefixed history entries are eligible."""
        self._allow_slash = allow_slash

    def get_suggestion(self, buffer: Buffer, document: Document) -> Suggestion | None:
        """Return the remainder of the most recent history entry that matches."""
        text = document.text
        if not text.strip():
            return None
        if not self._allow_slash and text.lstrip().startswith("/"):
            return None

        for entry in reversed(list(buffer.history.get_strings())):
            if not entry:
                continue
            if not self._allow_slash and entry.lstrip().startswith("/"):
                continue
            if entry == text:
                continue
            if entry.startswith(text):
                return Suggestion(entry[len(text) :])
        return None


__all__ = ("HistoryAutoSuggest",)
