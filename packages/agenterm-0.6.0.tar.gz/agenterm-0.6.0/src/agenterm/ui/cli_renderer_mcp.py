"""MCP payload renderers for CLI output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.cli_renderer_base import (
    ColumnSpec,
    render_notice,
    render_panel,
    render_text_block,
    short_text,
    table,
)

if TYPE_CHECKING:
    from agenterm.core.cli_payloads import (
        McpInspectPayload,
        McpServersPayload,
        McpToolsPayload,
    )
    from agenterm.engine.mcp_diagnostics import McpStatusSnapshot


def render_mcp_servers(payload: McpServersPayload) -> None:
    """Render `agenterm mcp servers` output."""
    if not payload.servers:
        render_notice(title="MCP", message="No MCP servers configured.", style="warn")
        return
    table_view = table(
        [
            ColumnSpec("Key", style="accent", no_wrap=True),
            ColumnSpec("Kind"),
            ColumnSpec("Name"),
        ],
    )
    for server in payload.servers:
        key = server.get("key")
        kind = server.get("kind")
        name = server.get("name")
        table_view.add_row(str(key or "-"), str(kind or "-"), str(name or "-"))
    render_panel("MCP Servers", table_view)


def render_mcp_tools(payload: McpToolsPayload) -> None:
    """Render `agenterm mcp tools` output."""
    if not payload.tools_by_server:
        render_notice(title="MCP Tools", message="No tools discovered.", style="warn")
        return
    for server, tools in payload.tools_by_server.items():
        table_view = table(
            [
                ColumnSpec("Name", style="accent", no_wrap=True),
                ColumnSpec("Title"),
                ColumnSpec("Description", overflow="ellipsis", ratio=3),
                ColumnSpec("Output", justify="right"),
            ],
        )
        for tool in tools:
            title = tool.title or "-"
            desc = short_text(tool.description)
            out = "yes" if tool.has_output_schema else "no"
            table_view.add_row(tool.name, title, desc, out)
        render_panel(f"MCP Tools - {server}", table_view)
    render_text_block(
        (
            "Total: "
            f"{payload.total_tools} tools across "
            f"{len(payload.tools_by_server)} servers"
        ),
        style="muted",
    )


def render_mcp_inspect(payload: McpInspectPayload) -> None:
    """Render `agenterm mcp inspect` output."""
    if not payload.tools:
        render_notice(title="MCP Inspect", message="No tools discovered.", style="warn")
        return
    table_view = table(
        [
            ColumnSpec("Name", style="accent", no_wrap=True),
            ColumnSpec("Title"),
            ColumnSpec("Description", overflow="ellipsis", ratio=3),
            ColumnSpec("Output", justify="right"),
        ],
    )
    for tool in payload.tools:
        title = tool.title or "-"
        desc = short_text(tool.description)
        out = "yes" if tool.has_output_schema else "no"
        table_view.add_row(tool.name, title, desc, out)
    render_panel("MCP Inspect", table_view)
    if payload.out_path:
        render_text_block(f"Wrote: {payload.out_path}", style="muted")


def render_mcp_status(payload: McpStatusSnapshot) -> None:
    """Render `agenterm mcp status` output."""
    if not payload.servers:
        render_notice(
            title="MCP Status",
            message=(
                "No MCP servers configured.\n"
                "Add servers in config.yaml under mcp.servers "
                "(global: ~/.agenterm/config.yaml; optional override: "
                ".agenterm/config.yaml).\n"
                "See: agenterm mcp --help"
            ),
            style="warn",
        )
        return
    table_view = table(
        [
            ColumnSpec("Server", style="accent", no_wrap=True),
            ColumnSpec("Transport"),
            ColumnSpec("Status"),
            ColumnSpec("Tools", justify="right"),
            ColumnSpec("Error", overflow="ellipsis", ratio=2),
        ],
    )
    for row in payload.servers:
        if row.error is not None:
            status = "[error]error[/error]"
        elif row.connected and row.tool_count > 0:
            status = "[good]connected[/good]"
        elif row.connected:
            status = "[muted]no tools[/muted]"
        else:
            status = "[muted]disconnected[/muted]"
        table_view.add_row(
            row.key,
            row.kind,
            status,
            str(row.tool_count),
            short_text(row.error) if row.error else "-",
        )
    render_panel("MCP Status", table_view)
    render_text_block(
        f"Total: {payload.total_tools} tools across {len(payload.servers)} servers",
        style="muted",
    )


__all__ = (
    "render_mcp_inspect",
    "render_mcp_servers",
    "render_mcp_status",
    "render_mcp_tools",
)
