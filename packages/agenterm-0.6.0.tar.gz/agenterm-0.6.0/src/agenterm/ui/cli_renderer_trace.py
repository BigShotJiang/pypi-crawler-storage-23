"""Trace payload renderers for CLI output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.cli_renderer_base import kv_table, render_panel

if TYPE_CHECKING:
    from agenterm.core.cli_payloads import TraceShowPayload


def render_trace_show(payload: TraceShowPayload) -> None:
    """Render `agenterm trace show` output."""
    if payload.trace_metadata:
        keys = ", ".join(sorted(payload.trace_metadata))
    else:
        keys = "(none)"
    rows = [
        ("Enabled", "on" if payload.trace_enabled else "off"),
        ("Trace ID", payload.trace_id or "(none)"),
        ("Group ID", payload.group_id or "(none)"),
        ("Metadata keys", keys),
        (
            "Include sensitive data",
            "on" if payload.trace_include_sensitive_data else "off",
        ),
    ]
    render_panel("Trace", kv_table(rows))


__all__ = ("render_trace_show",)
