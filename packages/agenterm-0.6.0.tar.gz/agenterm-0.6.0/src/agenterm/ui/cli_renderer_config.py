"""Config payload renderers for CLI output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.cli_renderer_base import (
    ColumnSpec,
    kv_table,
    render_panel,
    short_text,
    table,
)

if TYPE_CHECKING:
    from agenterm.core.cli_payloads import (
        ConfigPathPayload,
        ConfigSavePayload,
        ConfigShowPayload,
    )


def render_config_show(payload: ConfigShowPayload) -> None:
    """Render `agenterm config show` output."""
    config_rows = [
        ("Config path", payload.config_path or "(defaults)"),
    ]
    render_panel("Config", kv_table(config_rows))

    agent_rows = [
        ("Model", payload.agent_model),
        ("Max SDK turns", str(payload.agent_max_turns)),
        ("Agent", payload.agent_name),
    ]
    if payload.agent_source:
        agent_rows.append(("Agent source", payload.agent_source))
    if payload.agent_path:
        agent_rows.append(("Agent path", payload.agent_path))
    render_panel("Agent", kv_table(agent_rows))

    model_rows = [
        ("Store", str(payload.model_store)),
    ]
    if payload.model_context_window is not None:
        model_rows.append(("Context window", str(payload.model_context_window)))
    if payload.model_verbosity:
        model_rows.append(("Verbosity", payload.model_verbosity))
    if payload.model_temperature is not None:
        model_rows.append(("Temperature", str(payload.model_temperature)))
    if payload.model_reasoning_effort:
        model_rows.append(("Reasoning effort", payload.model_reasoning_effort))
    if payload.model_reasoning_summary:
        model_rows.append(("Reasoning summary", payload.model_reasoning_summary))
    render_panel("Model", kv_table(model_rows))

    run_rows = [
        ("Background", "on" if payload.run_background else "off"),
        ("Live", "on" if payload.run_live else "off"),
        ("JSON output", "on" if payload.run_json_output else "off"),
    ]
    render_panel("Run", kv_table(run_rows))

    repl_rows = [
        ("Approvals mode", payload.repl_approvals_mode),
        ("Theme", payload.repl_theme),
        ("Color depth", payload.repl_color_depth),
        ("Editing mode", payload.repl_editing_mode),
        ("Mouse", "on" if payload.repl_mouse else "off"),
        ("Completion", payload.repl_completion),
        ("Stream", payload.repl_stream_mode),
        ("Verbosity", payload.repl_verbosity),
    ]
    render_panel("REPL", kv_table(repl_rows))

    if payload.mcp_servers:
        table_view = table(
            [
                ColumnSpec("Server", style="accent", no_wrap=True),
                ColumnSpec("Transport"),
                ColumnSpec("Name"),
                ColumnSpec("Endpoint", overflow="ellipsis"),
            ],
        )
        for server in payload.mcp_servers:
            key = server.get("key")
            kind = server.get("kind")
            name = server.get("name")
            endpoint = server.get("endpoint")
            table_view.add_row(
                str(key or "-"),
                str(kind or "-"),
                str(name or "-"),
                short_text(str(endpoint) if endpoint is not None else "-"),
            )
        render_panel("MCP Servers", table_view)


def render_config_path(payload: ConfigPathPayload) -> None:
    """Render `agenterm config path` output."""
    rows = [
        ("Config path", payload.config_path or "(none)"),
        ("Location", payload.location or "-"),
    ]
    render_panel("Config Path", kv_table(rows))


def render_config_save(payload: ConfigSavePayload) -> None:
    """Render `agenterm config save` output."""
    rows = [
        ("Path", payload.config_path),
        ("Scope", payload.scope),
        ("Source", payload.source),
        ("Overwritten", "yes" if payload.overwritten else "no"),
    ]
    render_panel("Config Saved", kv_table(rows), border="good")


__all__ = (
    "render_config_path",
    "render_config_save",
    "render_config_show",
)
