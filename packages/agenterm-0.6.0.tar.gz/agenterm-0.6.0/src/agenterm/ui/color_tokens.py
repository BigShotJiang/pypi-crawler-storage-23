"""Semantic color tokens shared by CLI and REPL themes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

if TYPE_CHECKING:
    from agenterm.core.choices.repl_ui import ReplTheme


@dataclass(frozen=True, slots=True)
class SemanticColors:
    """Semantic color tokens shared between REPL and CLI."""

    # Status colors
    good: str
    warn: str
    error: str

    # Text hierarchy
    primary: str
    secondary: str
    muted: str
    accent: str

    # Surfaces
    surface: str
    surface_alt: str


COLOR_TOKENS_DARK: Final[SemanticColors] = SemanticColors(
    good="#6cb878",  # Verdigris — slightly softer
    warn="#dca048",  # Amber glow — slightly softer
    error="#d45858",  # Soft coral — slightly softer
    primary="#f6ece0",  # Warm cream — slightly brighter for contrast
    secondary="#c4b8a8",  # Muted cream
    muted="#847870",  # Warm gray
    accent="#dca048",  # Amber signature — slightly softer
    surface="#080606",  # Deep warm black — slightly darker for contrast
    surface_alt="#1a1610",
)

COLOR_TOKENS_LIGHT: Final[SemanticColors] = SemanticColors(
    good="#247840",  # Forest — slightly more vivid
    warn="#a85808",  # Deep amber — slightly more vivid
    error="#b82828",  # Brick red — slightly more vivid
    primary="#14100a",  # Near black — slightly darker for contrast
    secondary="#3c3428",  # Dark warm gray
    muted="#585048",  # Medium-dark gray — readable on light
    accent="#a85808",  # Deep amber — slightly more vivid
    surface="#fcfaf6",  # Warm white — slightly brighter for contrast
    surface_alt="#e6ded0",
)


def colors_for_theme(theme: ReplTheme) -> SemanticColors:
    """Return semantic color tokens for the given theme."""
    return COLOR_TOKENS_LIGHT if theme == "light" else COLOR_TOKENS_DARK


__all__ = (
    "COLOR_TOKENS_DARK",
    "COLOR_TOKENS_LIGHT",
    "SemanticColors",
    "colors_for_theme",
)
