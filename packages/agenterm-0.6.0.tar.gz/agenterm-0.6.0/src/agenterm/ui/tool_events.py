"""Shared tool labeling and tool output summaries for CLI and REPL surfaces.

This module is the single canonical place that maps raw Responses item `type`
values into stable human labels and summarizes structured tool outputs we own.

It is intentionally pure: callers decide how to print/render the returned
strings.
"""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import TYPE_CHECKING, Final

from agents.tool import ShellResult

from agenterm.constants.display import (
    TRANSCRIPT_SHELL_PREVIEW_MAX_CHARS_DEFAULT,
    TRANSCRIPT_TOOL_OUTPUT_MAX_LINES_DEFAULT,
)
from agenterm.core.text import shorten_line

if TYPE_CHECKING:
    from agents.editor import ApplyPatchResult
    from agents.items import ToolCallItemTypes, ToolCallOutputTypes

    from agenterm.core.approvals_audit import ApprovalDecision, ApprovalFamily


_TOOL_TYPE_LABELS: Final = MappingProxyType(
    {
        "web_search_call_output": "web_search",
        "web_search_call": "web_search",
        "file_search_call_output": "file_search",
        "file_search_call": "file_search",
        "mcp_call": "mcp",
        "mcp_list_tools": "mcp",
        "mcp_approval_request": "mcp",
        "mcp_approval_response": "mcp",
        "image_generation_call": "image_generation",
    },
)


@dataclass(frozen=True)
class ToolOutputSummaryPolicy:
    """Boundedness policy for tool output summaries."""

    max_lines: int = TRANSCRIPT_TOOL_OUTPUT_MAX_LINES_DEFAULT
    shell_preview_max_chars: int = TRANSCRIPT_SHELL_PREVIEW_MAX_CHARS_DEFAULT


@dataclass
class BoundedLineWriter:
    """Append-only line buffer with a hard max-lines limit."""

    max_lines: int

    lines: list[str]
    truncated: bool = False

    def append(self, text: str) -> bool:
        """Append one line when within the line budget (returns False on truncation)."""
        if self.max_lines <= 0:
            self.truncated = True
            return False
        if len(self.lines) >= self.max_lines:
            self.truncated = True
            return False
        self.lines.append(text)
        return True

    def ensure_truncation_marker(self, marker: str = "…") -> None:
        """Append or overwrite a truncation marker when truncation occurred."""
        if not self.truncated:
            return
        if self.max_lines <= 0:
            return
        if len(self.lines) < self.max_lines:
            self.lines.append(marker)
        elif self.lines:
            self.lines[-1] = marker


def label_for_tool_type(raw_type: str | None, *, is_output: bool) -> str:
    """Map a raw Responses item type into a stable human label."""
    if raw_type is None:
        return "tool_output" if is_output else "tool_call"
    label = _TOOL_TYPE_LABELS.get(raw_type)
    if label is not None:
        return str(label)
    return raw_type


def raw_item_type(raw: ToolCallItemTypes | ToolCallOutputTypes | None) -> str | None:
    """Extract an item `type` field from Responses tool call/output shapes."""
    if raw is None:
        return None
    if isinstance(raw, dict):
        raw_type_val = raw.get("type")
        return raw_type_val if isinstance(raw_type_val, str) else None
    return raw.type


def shell_result_summary_lines(
    out: ShellResult,
    *,
    policy: ToolOutputSummaryPolicy,
) -> tuple[str, ...]:
    """Render concise, bounded summary lines for a ShellResult."""
    provider = dict(out.provider_data or {})
    max_lines = max(0, int(policy.max_lines))
    writer = BoundedLineWriter(max_lines=max_lines, lines=[])

    cwd_obj = provider.get("working_directory")
    if isinstance(cwd_obj, str) and cwd_obj and not writer.append(f"- cwd: {cwd_obj}"):
        return tuple(writer.lines)
    for cmd_out in out.output:
        cmd = cmd_out.command or ""
        status = cmd_out.status
        exit_code = cmd_out.exit_code
        line = f"- cmd: {cmd!r} | status={status}"
        if exit_code is not None:
            line += f" exit={exit_code}"
        if not writer.append(line):
            break
        preview_source = cmd_out.stdout.strip() or cmd_out.stderr.strip()
        if preview_source:
            first_line = preview_source.splitlines()[0]
            first_line = shorten_line(
                first_line,
                limit=policy.shell_preview_max_chars,
            )
            if not writer.append(f"  out: {first_line}"):
                break

    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def apply_patch_result_summary_lines(
    out: ApplyPatchResult,
    *,
    policy: ToolOutputSummaryPolicy,
    include_excerpt: bool,
) -> tuple[str, ...]:
    """Render concise, bounded summary lines for an ApplyPatchResult."""
    status = out.status or "completed"
    msg = out.output or ""
    hint = "view full diff: /last diff full"
    hint_needed = include_excerpt and "\n\n" in msg
    if not include_excerpt and msg:
        msg = msg.split("\n\n", 1)[0]
    lines: list[str] = [f"[apply_patch result] status={status}"]
    if msg:
        lines.extend(msg.splitlines())

    max_lines = max(0, int(policy.max_lines))
    if max_lines <= 0:
        return ()
    shown = lines[:max_lines]
    if hint_needed:
        if len(lines) < max_lines:
            shown.append(hint)
        else:
            if max_lines > 1 and len(lines) > max_lines:
                shown[-2] = "…"
            shown[-1] = hint
    elif len(lines) > len(shown):
        shown.append("…")
    return tuple(shown)


def tool_output_summary_lines(
    out: ShellResult | ApplyPatchResult,
    *,
    policy: ToolOutputSummaryPolicy,
    include_apply_patch_excerpt: bool,
) -> tuple[str, ...]:
    """Render concise, bounded summary lines for tool outputs we own."""
    if isinstance(out, ShellResult):
        return shell_result_summary_lines(out, policy=policy)
    return apply_patch_result_summary_lines(
        out,
        policy=policy,
        include_excerpt=include_apply_patch_excerpt,
    )


def approval_event_type(
    decision: ApprovalDecision | None,
) -> tuple[str, bool | None]:
    """Return the transcript event type and success flag for approvals."""
    if decision is None:
        return "approval requested", None
    if decision.approved:
        return "approved", True
    return "rejected", False


def approval_label(family: ApprovalFamily) -> str:
    """Return a stable label for approval transcript events."""
    if family == "patch":
        return "apply_patch approval"
    if family == "shell":
        return "shell approval"
    if family == "compress":
        return "compression approval"
    return "mcp approval"


__all__ = (
    "BoundedLineWriter",
    "ToolOutputSummaryPolicy",
    "apply_patch_result_summary_lines",
    "approval_event_type",
    "approval_label",
    "label_for_tool_type",
    "raw_item_type",
    "shell_result_summary_lines",
    "shorten_line",
    "tool_output_summary_lines",
)
