"""Interactive REPL loop."""

from __future__ import annotations

import asyncio
import contextlib
from typing import TYPE_CHECKING

from agents.exceptions import AgentsException

from agenterm.app.services import (
    attach_or_create_session,
    maybe_refresh_mcp,
    wire_repl_approvals,
)
from agenterm.commands.actions import ReplAction
from agenterm.commands.model import (
    ApprovalsApproveCmd,
    ApprovalsDetailCmd,
    ApprovalsListCmd,
    ApprovalsModeCmd,
    ApprovalsRejectCmd,
    ApprovalsShowCmd,
    AttachmentsShowCmd,
    ErrorsCmd,
    HelpCmd,
    LastCmd,
    StatusCmd,
)
from agenterm.commands.router import CommandRouter, parse_command
from agenterm.core.cancellation import CancellationScope
from agenterm.core.error_report import ErrorContext, ErrorReport, build_error_report
from agenterm.core.errors import AgentermError
from agenterm.store.async_db import close_store_registry
from agenterm.ui.approvals.pending import has_pending_approvals
from agenterm.ui.cli_renderer import render_error_report
from agenterm.ui.repl.actions import handle_action as handle_repl_action
from agenterm.ui.repl.artifacts import ReplArtifactIndex
from agenterm.ui.repl.controller import (
    attach_mcp_servers,
    build_agent_for_state,
    sync_agent_and_mcp,
)
from agenterm.ui.repl.error_capture import ReplErrorBuffer, ReplErrorSink
from agenterm.ui.repl.logging_filters import (
    clear_trace_noise_filter,
    sync_trace_noise_filter,
)
from agenterm.ui.repl.loop_emit import ReplLoopEmit
from agenterm.ui.repl.phase_state import ReplPhaseState
from agenterm.ui.repl.run_cancel import RunCancelController
from agenterm.ui.repl.run_runner import RunInputs, run_repl_run
from agenterm.ui.repl.transcript_reload import reload_repl_transcript
from agenterm.ui.repl.ui_signatures import prompt_ui_sig
from agenterm.ui.tui.app import ReplTui
from agenterm.ui.tui.state import UiStore
from agenterm.workflow.run.model import RunRef

if TYPE_CHECKING:
    from logging import Filter

    from agents.agent import Agent
    from agents.memory import Session
    from agents.result import RunResultStreaming

    from agenterm.commands.model import Command
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.types import SessionState

    RunTask = asyncio.Task[tuple[SessionState, Agent, RunResultStreaming | None]]


class ReplLoop(ReplLoopEmit):
    """Stateful REPL loop with single-run execution and cleanup."""

    integrate_lock: asyncio.Lock
    integrate_task: asyncio.Task[None] | None
    error_buffer: ReplErrorBuffer
    error_sink: ReplErrorSink

    def __init__(self, state: SessionState, *, mem_session: Session) -> None:
        """Initialize REPL state, session wiring, and prompt UI."""
        self.phase_state, self.state = ReplPhaseState(), state
        self.mem_session = mem_session
        self.agent = build_agent_for_state(self.state)
        self.mcp_pool, self.mcp_sig = None, ()
        self.router, self.artifacts = CommandRouter(), ReplArtifactIndex()
        self.ui_store = UiStore(
            max_transcript_entries=self.state.cfg.repl.ui.max_transcript_entries,
        )
        self.error_buffer = ReplErrorBuffer()
        self.error_sink = ReplErrorSink(
            buffer=self.error_buffer,
            emit_error_line=self.emit_error_line,
            phase_state=self.phase_state,
            ui_invalidate=self._invalidate_tui,
        )

        self.current_run: RunTask | None = None
        self.current_run_ref: RunRef | None = None
        self._action_cancel_scope: CancellationScope | None = None
        self._trace_log_filter: Filter | None = None
        self.integrate_lock = asyncio.Lock()
        self.integrate_task = None
        self._cancel_controller = RunCancelController(self)

        self.state, self.approvals_cleanup = wire_repl_approvals(
            self.state,
            notify=self.notify_approval,
            emit_event=self.emit_approval_event,
        )
        self._trace_log_filter = sync_trace_noise_filter(
            verbosity=self.state.ui.verbosity,
            active=self._trace_log_filter,
        )
        self.tui = ReplTui(
            state_provider=self._state_provider,
            phase_state=self.phase_state,
            store=self.ui_store,
            cancel_current_run=self._cancel_controller.request_cancel,
            cancel_available=self._cancel_available,
            stderr_handler=self.error_sink.handle_line,
        )
        self.tui.sync_approvals_modal()

    @classmethod
    async def create(
        cls,
        state: SessionState,
        *,
        attach_session_id: str | None,
        store_override: bool | None = None,
    ) -> ReplLoop:
        """Create a REPL loop with async session attachment/creation."""
        new_state, mem_session = await attach_or_create_session(
            state,
            attach_session_id,
            store_override=store_override,
        )
        loop = cls(new_state, mem_session=mem_session)
        await reload_repl_transcript(loop, branch_id=loop.state.branch_id)
        return loop

    def _state_provider(self) -> SessionState:
        return self.state

    def _invalidate_tui(self) -> None:
        self.tui.invalidate()

    def _run_running(self) -> bool:
        return self.current_run is not None and not self.current_run.done()

    def run_running(self) -> bool:
        """Return True while a model run is running (public wrapper)."""
        return self._run_running()

    def _cancel_available(self) -> bool:
        return self._run_running() or self._action_cancel_scope is not None

    async def _integrate_completed_run(self) -> None:
        async with self.integrate_lock:
            if self.current_run is None or not self.current_run.done():
                return
            run_ref = self.current_run_ref
            try:
                new_state, new_agent, _ = await self.current_run
            except (
                AgentermError,
                AgentsException,
            ) as exc:  # pragma: no cover
                report = build_error_report(
                    exc,
                    context=ErrorContext(
                        operation="repl.run",
                        resource="repl.run",
                        trace_id=self.state.cfg.run.trace_id,
                    ),
                )
                self.emit(report)
            except asyncio.CancelledError:
                await self._cancel_controller.handle_cancelled_run()
                return
            else:
                self.state = new_state
                self.agent = attach_mcp_servers(new_agent, pool=self.mcp_pool)
                if run_ref is not None and run_ref.cancel_reason is not None:
                    self.emit_command("Run cancelled.")
            finally:
                self.current_run = None
                self.current_run_ref = None
                self.phase_state.clear_notice()
                self.phase_state.clear_event_hint()
                self.tui.stop_animation()
                self._cancel_controller.clear_watchdog()

    def _clear_integrate_task(self, task: asyncio.Task[None]) -> None:
        if self.integrate_task is task:
            self.integrate_task = None

    def schedule_integrate_completed_run(self) -> None:
        """Schedule integration of a completed run without waiting for input."""
        if self.integrate_task is not None and not self.integrate_task.done():
            return
        task = asyncio.create_task(self._integrate_completed_run())
        self.integrate_task = task
        task.add_done_callback(self._clear_integrate_task)

    async def _refresh_mcp_if_needed(self) -> None:
        if not self.state.mcp.refresh_pending:
            return
        self.state, msg = await maybe_refresh_mcp(self.state)
        if msg:
            if isinstance(msg, ErrorReport):
                self.emit(msg)
            else:
                self.emit_command(msg)

    async def _sync_engine(self) -> None:
        try:
            self.agent, self.mcp_pool, self.mcp_sig = await sync_agent_and_mcp(
                self.state,
                workspace_root=None,
                existing_pool=self.mcp_pool,
                existing_sig=self.mcp_sig,
            )
        except AgentermError as exc:
            report = build_error_report(
                exc,
                context=ErrorContext(
                    operation="repl.mcp.sync",
                    resource="repl.mcp.sync",
                    trace_id=self.state.cfg.run.trace_id,
                ),
            )
            self.emit(report)
            raise

    def _start_run(
        self,
        text: str | None,
        *,
        use_last: bool,
        record_prompt: bool = True,
    ) -> None:
        if record_prompt and text is not None:
            self.state = self.state.with_prompt(text)
        self.phase_state.phase = "running"
        self.tui.invalidate()
        self.tui.start_animation()
        run_ref = RunRef(streaming=None)
        run_ctx = RunInputs(
            state=self.state,
            agent=self.agent,
            prompt_text=text,
            use_last_attachments=use_last,
            session=self.mem_session,
            phase_state=self.phase_state,
            run_ref=run_ref,
            mcp_pool=self.mcp_pool,
            artifact_index=self.artifacts,
            emit_event=self.ui_store.dispatch,
            ui_invalidate=self.tui.invalidate,
        )
        self.current_run = asyncio.create_task(run_repl_run(run_ctx))
        self.current_run.add_done_callback(
            lambda _task: self.schedule_integrate_completed_run()
        )
        self.current_run_ref = run_ref

    def start_run(
        self,
        text: str,
        *,
        use_last: bool,
        record_prompt: bool = True,
    ) -> None:
        """Start a new model run (public wrapper for action handlers)."""
        self._start_run(text, use_last=use_last, record_prompt=record_prompt)

    def start_resume_run(self, *, use_last: bool) -> None:
        """Start a run without adding a new user message.

        This is used by /continue to resume from cancelled/timeout state after
        the workflow layer replays any stored attempt items.
        """
        self._start_run(None, use_last=use_last, record_prompt=False)

    def begin_action_cancel_scope(self) -> CancelToken:
        """Create a cancellable scope for long-running actions."""
        scope = CancellationScope()
        self._action_cancel_scope = scope
        return scope.token

    def cancel_action_scope(self) -> bool:
        """Cancel the active action scope, if any."""
        if self._action_cancel_scope is None:
            return False
        self._action_cancel_scope.cancel()
        return True

    def clear_action_cancel_scope(self) -> None:
        """Clear the current action cancellation scope."""
        self._action_cancel_scope = None

    async def _handle_action(self, outcome: ReplAction) -> bool:
        return await handle_repl_action(self, outcome)

    def _command_allowed(self, cmd: Command) -> bool:
        if not self._run_running():
            return True
        return isinstance(
            cmd,
            (
                ApprovalsApproveCmd,
                ApprovalsModeCmd,
                ApprovalsDetailCmd,
                ApprovalsListCmd,
                ApprovalsRejectCmd,
                ApprovalsShowCmd,
                HelpCmd,
                LastCmd,
                StatusCmd,
                AttachmentsShowCmd,
                ErrorsCmd,
            ),
        )

    async def _handle_command(self, cmd: Command) -> bool:
        if not self._command_allowed(cmd):
            self.phase_state.set_notice(
                "Run running - /approvals, /last, /help, /status, /attach list only.",
                level="warn",
            )
            self.tui.invalidate()
            return True
        prev_cfg, prev_tools_enabled = self.state.cfg, self.state.tools.enabled
        prev_sel = self.state.tools.selection
        prev_verbosity = self.state.ui.verbosity
        prev_ui_sig = prompt_ui_sig(self.state)
        self.state, outcome = await self.router.apply(self.state, cmd)
        if isinstance(outcome, ReplAction):
            cont = await self._handle_action(outcome)
            if not cont:
                return False
        elif isinstance(outcome, str) and outcome:
            self.emit_command(outcome)
        if self.state.ui.verbosity != prev_verbosity:
            self._trace_log_filter = sync_trace_noise_filter(
                verbosity=self.state.ui.verbosity,
                active=self._trace_log_filter,
            )
        if (
            self.state.cfg != prev_cfg
            or self.state.tools.enabled != prev_tools_enabled
            or self.state.tools.selection != prev_sel
        ):
            await self._sync_engine()
        if self.state.cfg != prev_cfg:
            self.ui_store.set_max_transcript_entries(
                self.state.cfg.repl.ui.max_transcript_entries,
            )
        if prompt_ui_sig(self.state) != prev_ui_sig:
            self.tui.refresh_completion_mode()
            self.tui.refresh_editing_mode()
            self.tui.invalidate()
        self.tui.sync_approvals_modal()
        return True

    async def process_prompt(self, text: str) -> bool:
        """Process one user-provided input line for tests."""
        return await self._process_prompt(text)

    async def _process_prompt(self, text: str) -> bool:
        await self._integrate_completed_run()
        stripped = (text or "").strip()
        if not stripped:
            return True
        self.phase_state.clear_notice()
        self.tui.invalidate()
        if stripped.startswith("/"):
            cmd = parse_command(stripped)
            if cmd is None:
                self.emit_command("Invalid command. Use /help.")
                return True
            return await self._handle_command(cmd)
        if self._run_running():
            if has_pending_approvals(self.state.approvals):
                self.phase_state.set_notice(
                    "Approval pending - use modal input: y/yes or n/no [reason].",
                    level="warn",
                )
            else:
                self.phase_state.set_notice(
                    "Run running - ESC/Ctrl+C cancels.",
                    level="info",
                )
            self.tui.invalidate()
            return True
        self._emit_text(stripped, role="user")
        self._start_run(
            stripped,
            use_last=bool(self.state.attachments.next_send_use_last),
        )
        return True

    async def run(self) -> None:
        """Run the REPL until EOF/interrupt exits the loop."""
        ui_task: asyncio.Task[None] | None = None
        try:
            await self._sync_engine()
            ui_task = asyncio.create_task(self.tui.run())
            while True:
                await self._integrate_completed_run()
                await self._refresh_mcp_if_needed()
                text = await self.tui.next_input()
                if text is None:
                    break
                cont = await self.process_prompt(text)
                if not cont:
                    break
        finally:
            self.tui.request_exit()
            if ui_task is not None:
                with contextlib.suppress(asyncio.CancelledError):
                    await ui_task
            if self.mcp_pool is not None:
                try:
                    await self.mcp_pool.cleanup()
                except AgentermError as exc:
                    report = build_error_report(
                        exc,
                        context=ErrorContext(
                            operation="repl.mcp.cleanup",
                            resource="repl.mcp.cleanup",
                            trace_id=self.state.cfg.run.trace_id,
                        ),
                    )
                    render_error_report(report)
            try:
                await close_store_registry()
            except AgentermError as exc:
                report = build_error_report(
                    exc,
                    context=ErrorContext(
                        operation="repl.store.cleanup",
                        resource="repl.store.cleanup",
                        trace_id=self.state.cfg.run.trace_id,
                    ),
                )
                render_error_report(report)
            self.approvals_cleanup()
            clear_trace_noise_filter(self._trace_log_filter)
            self._trace_log_filter = None


__all__ = ("ReplLoop",)
