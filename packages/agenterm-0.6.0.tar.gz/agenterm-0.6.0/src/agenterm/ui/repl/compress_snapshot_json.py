"""JSON narrowing helpers for compaction snapshot formatting."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.json_codec import as_json_list, as_json_object, as_str

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


def json_dict(value: JSONValue | None) -> dict[str, JSONValue] | None:
    """Return a JSON object when value is object-shaped."""
    return as_json_object(value)


def json_list(value: JSONValue | None) -> list[JSONValue] | None:
    """Return a JSON list when value is list-shaped."""
    return as_json_list(value)


def json_str(value: JSONValue | None) -> str | None:
    """Return a string when value is string-shaped."""
    return as_str(value)


__all__ = ("json_dict", "json_list", "json_str")
