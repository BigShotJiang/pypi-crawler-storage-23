"""Transcript emission helpers for the REPL loop."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.error_report import ErrorReport
from agenterm.ui.cli_renderer_base import format_error_report_lines
from agenterm.ui.cli_settings import get_cli_output_settings
from agenterm.ui.repl.approvals_emit import (
    emit_approval_event as emit_approval_transcript,
)
from agenterm.ui.tui.state import (
    TranscriptEntryAddedEvent,
    TranscriptRole,
    TranscriptTextEntry,
)

if TYPE_CHECKING:
    from agenterm.app.services.approvals import ApprovalFamily
    from agenterm.core.approvals import (
        CompressionApprovalItem,
        McpApprovalItem,
        PatchApprovalItem,
        ShellApprovalItem,
    )
    from agenterm.core.approvals_audit import ApprovalDecision
    from agenterm.core.types import SessionState
    from agenterm.ui.repl.phase_state import ReplPhaseState
    from agenterm.ui.tui.app import ReplTui
    from agenterm.ui.tui.state import UiStore


class ReplLoopEmit:
    """Transcript emission and approval hooks for the REPL loop."""

    ui_store: UiStore
    phase_state: ReplPhaseState
    tui: ReplTui
    state: SessionState

    def _emit_text(self, text: str, *, role: TranscriptRole = "system") -> None:
        if not text:
            return
        self.ui_store.dispatch(
            TranscriptEntryAddedEvent(entry=TranscriptTextEntry(role=role, text=text)),
        )

    def emit(self, msg: str | ErrorReport) -> None:
        """Emit a single user-facing line or structured error."""
        if isinstance(msg, ErrorReport):
            lines = format_error_report_lines(
                msg,
                verbose=get_cli_output_settings().verbose,
            )
            text = "\n".join(lines)
            self._emit_text(f"[error]\n{text}")
            return
        self._emit_text(msg)

    def emit_command(self, msg: str) -> None:
        """Emit a command response using the standard panel style."""
        if not msg:
            return
        self._emit_text(f"[command]\n{msg}")

    def emit_command_lines(self, lines: list[str]) -> None:
        """Emit a multi-line command response as a single panel."""
        joined = "\n".join(lines)
        self.emit_command(joined)

    def emit_error_line(self, msg: str) -> None:
        """Emit a single stderr line as an error transcript entry."""
        text = msg.rstrip()
        if not text:
            return
        if not text.startswith("error>"):
            text = f"error> {text}"
        self._emit_text(text, role="error")

    def emit_error_lines(self, lines: list[str]) -> None:
        """Emit multiple stderr lines as error transcript entries."""
        for line in lines:
            self.emit_error_line(line)

    def emit_user(self, msg: str) -> None:
        """Emit a user message into the transcript."""
        self._emit_text(msg, role="user")

    def _notify_approval(self, msg: str) -> None:
        """Surface approval status as a HUD notice."""
        _ = msg
        self.phase_state.set_notice(
            "Approval pending - review modal or /approvals list.",
            level="warn",
        )
        self.tui.sync_approvals_modal()

    def notify_approval(self, msg: str) -> None:
        """Public wrapper for approval notices."""
        self._notify_approval(msg)

    def emit_approval_event(
        self,
        family: ApprovalFamily,
        item: (
            ShellApprovalItem
            | PatchApprovalItem
            | McpApprovalItem
            | CompressionApprovalItem
        ),
        decision: ApprovalDecision | None,
    ) -> None:
        """Public wrapper for approval transcript emission."""
        emit_approval_transcript(
            state=self.state,
            store=self.ui_store,
            phase_state=self.phase_state,
            tui=self.tui,
            family=family,
            item=item,
            decision=decision,
        )


__all__ = ("ReplLoopEmit",)
