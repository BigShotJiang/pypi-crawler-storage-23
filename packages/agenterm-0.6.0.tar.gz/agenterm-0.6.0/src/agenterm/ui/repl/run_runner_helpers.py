"""Shared helpers for REPL run execution."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.engine.artifacts import resolve_image_artifacts
from agenterm.engine.input_payload import build_from_prompt_and_attachments
from agenterm.store.runs.repo import next_run_number
from agenterm.store.session.service import session_store
from agenterm.ui.cli_renderer_base import format_error_report_lines
from agenterm.ui.cli_settings import get_cli_output_settings
from agenterm.ui.tool_events import BoundedLineWriter, shorten_line
from agenterm.ui.transcript.blocks import ImageArtifactBlock
from agenterm.ui.transcript.policy import transcript_policy_for_state
from agenterm.ui.tui.state import (
    TextFinalizedEvent,
    TranscriptEntryAddedEvent,
    TranscriptRole,
    TranscriptSeparatorEntry,
    TranscriptTextEntry,
    UiEvent,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from agents.items import TResponseInputItem
    from agents.memory import Session
    from openai.types.responses.response_input_item_param import ResponseInputItemParam

    from agenterm.core.error_report import ErrorReport
    from agenterm.core.types import SessionState
    from agenterm.ui.transcript.model import TranscriptPolicy


def resolve_session_id(state: SessionState, session: Session | None) -> str | None:
    """Return a session id from state or the Agents session."""
    sid = state.session_id
    if isinstance(sid, str) and sid:
        return sid
    if session is None:
        return None
    try:
        sid_obj = session.session_id
    except AttributeError:
        sid_obj = None
    return sid_obj if isinstance(sid_obj, str) and sid_obj else None


async def resolve_run_number(
    *,
    session_id: str | None,
    branch_id: str | None,
) -> int | None:
    """Return the next run number for a persisted session/branch."""
    if not (isinstance(session_id, str) and session_id):
        return None
    try:
        effective_branch = branch_id or "main"
        return await next_run_number(
            store=session_store(),
            session_id=session_id,
            branch_id=effective_branch,
        )
    except ConfigError:
        return None


def finalize_attachment_state(
    state: SessionState,
    *,
    used_last: bool,
    attachments: list[str],
) -> SessionState:
    """Update attachment tracking after a run."""
    if used_last:
        return replace(
            state,
            attachments=replace(state.attachments, next_send_use_last=False),
        )
    return replace(
        state,
        attachments=replace(
            state.attachments,
            last_used=tuple(attachments),
            pending=(() if attachments else state.attachments.pending),
            next_send_use_last=False,
        ),
    )


def build_attachments_text(
    state: SessionState,
    *,
    attachments: list[str],
    use_last: bool,
    policy: TranscriptPolicy,
) -> str | None:
    """Build a bounded attachment summary block."""
    pending_count = len(state.attachments.pending or ())
    last_count = len(state.attachments.last_used or ())
    if not pending_count and not last_count:
        return None
    using = "last" if use_last else "pending"
    lines = [
        f"attachments: pending={pending_count} last={last_count} using={using}",
    ]
    writer = BoundedLineWriter(
        max_lines=policy.attachments_max_lines,
        lines=[],
    )
    for raw in attachments:
        line = f"- {shorten_line(raw, limit=policy.attachments_path_max_chars)}"
        if not writer.append(line):
            break
    writer.ensure_truncation_marker("…")
    lines.extend(writer.lines)
    return "\n".join(lines)


async def prepare_run_display(
    *,
    state: SessionState,
    session_id: str | None,
    branch_id: str | None,
    use_last_attachments: bool,
    emit_entry: Callable[[TranscriptTextEntry | TranscriptSeparatorEntry], None],
) -> TranscriptPolicy:
    """Render the run header and return the effective transcript policy."""
    policy = transcript_policy_for_state(state)
    run_number = await resolve_run_number(
        session_id=session_id,
        branch_id=branch_id,
    )
    emit_entry(
        TranscriptSeparatorEntry(
            label=(f"run {run_number}" if run_number else None),
        ),
    )
    attachment_list = (
        list(state.attachments.last_used or ())
        if use_last_attachments
        else list(state.attachments.pending or ())
    )
    attachments_text = build_attachments_text(
        state,
        attachments=attachment_list,
        use_last=use_last_attachments,
        policy=policy,
    )
    if attachments_text:
        emit_entry(TranscriptTextEntry(role="system", text=attachments_text))
    return policy


async def prepare_input_items(
    state: SessionState,
    prompt_text: str | None,
    *,
    use_last_attachments: bool,
) -> tuple[list[str], list[TResponseInputItem]]:
    """Prepare prompt and attachment items for the agent run."""
    # /continue uses an empty input list so the model call is driven by
    # session history (and resume replay items) instead of a new user message.
    if prompt_text is None:
        return [], []
    if use_last_attachments:
        attachments = list(state.attachments.last_used or ())
    else:
        attachments = list(state.attachments.pending or ())
    items = await build_from_prompt_and_attachments(
        cfg=state.cfg,
        model_id=state.cfg.agent.model,
        prompt=prompt_text,
        attachments=attachments,
        max_text_bytes=None,
    )
    return attachments, list(items)


def dispatch_ui_event(
    emit_event: Callable[[UiEvent], None] | None,
    event: UiEvent,
) -> None:
    """Dispatch a UI event if an emitter is present."""
    if emit_event is None:
        return
    emit_event(event)


def emit_transcript_text(
    emit_event: Callable[[UiEvent], None] | None,
    text: str,
    *,
    role: TranscriptRole = "system",
) -> None:
    """Emit a text entry into the UI transcript."""
    if emit_event is None or not text:
        return
    dispatch_ui_event(
        emit_event,
        TranscriptEntryAddedEvent(
            entry=TranscriptTextEntry(role=role, text=text),
        ),
    )


def emit_error_report(
    emit_event: Callable[[UiEvent], None] | None,
    report: ErrorReport,
) -> None:
    """Emit a formatted error report into the transcript."""
    lines = format_error_report_lines(
        report,
        verbose=get_cli_output_settings().verbose,
    )
    emit_transcript_text(emit_event, "[error]\n" + "\n".join(lines))


async def emit_run_image_artifacts(
    *,
    items: Sequence[ResponseInputItemParam],
    rendered_artifact_ids: set[str],
    emit_event: Callable[[UiEvent], None] | None,
) -> None:
    """Emit image artifacts produced during a run."""
    resolution = await resolve_image_artifacts(
        store=session_store(),
        items=items,
    )
    for rec in resolution.records:
        if rec.artifact_id in rendered_artifact_ids:
            continue
        dispatch_ui_event(
            emit_event,
            TranscriptEntryAddedEvent(
                entry=ImageArtifactBlock(
                    kind="artifact_image",
                    artifact_id=rec.artifact_id,
                    path=rec.path,
                    mime=rec.mime,
                    size_bytes=rec.size_bytes,
                ),
            ),
        )
        rendered_artifact_ids.add(rec.artifact_id)


def emit_final_text(
    emit_event: Callable[[UiEvent], None] | None,
    *,
    stream_mode: str,
    saw_text_delta: bool,
    final_text: str,
    suppress_output: bool,
) -> None:
    """Emit the final assistant text for a run."""
    if emit_event is None:
        return
    if suppress_output:
        dispatch_ui_event(
            emit_event,
            TextFinalizedEvent(block_id="assistant", final_text=""),
        )
        return
    if stream_mode == "final" or not saw_text_delta:
        dispatch_ui_event(
            emit_event,
            TextFinalizedEvent(block_id="assistant", final_text=final_text),
        )
        return
    dispatch_ui_event(
        emit_event,
        TextFinalizedEvent(block_id="assistant", final_text=None),
    )


__all__ = (
    "build_attachments_text",
    "dispatch_ui_event",
    "emit_error_report",
    "emit_final_text",
    "emit_run_image_artifacts",
    "emit_transcript_text",
    "finalize_attachment_state",
    "prepare_input_items",
    "prepare_run_display",
    "resolve_run_number",
    "resolve_session_id",
)
