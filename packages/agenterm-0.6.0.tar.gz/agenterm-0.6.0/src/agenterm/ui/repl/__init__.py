"""REPL package surface.

The package init stays import-light so leaf imports under ``agenterm.ui.repl``
do not eagerly initialize the full REPL runner stack.
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


class _RunReplCallable(Protocol):
    async def __call__(
        self,
        state: SessionState,
        *,
        attach_session_id: str | None = None,
        store_override: bool | None = None,
    ) -> None: ...


def _load_run_repl() -> _RunReplCallable:
    module = importlib.import_module("agenterm.ui.repl.runner")
    return module.run_repl


async def run_repl(
    state: SessionState,
    *,
    attach_session_id: str | None = None,
    store_override: bool | None = None,
) -> None:
    """Run the interactive REPL via the canonical runner entrypoint."""
    await _load_run_repl()(
        state,
        attach_session_id=attach_session_id,
        store_override=store_override,
    )


__all__ = ("run_repl",)
