"""Logging filters for the REPL surface."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.choices.repl import ReplVerbosity


class _TraceNoiseFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        return not msg.startswith(
            (
                "[non-fatal] Tracing",
                "OPENAI_API_KEY is not set, skipping trace export",
            ),
        )


def sync_trace_noise_filter(
    *,
    verbosity: ReplVerbosity,
    active: logging.Filter | None,
) -> logging.Filter | None:
    """Add or remove the trace noise filter based on verbosity."""
    logger = logging.getLogger("openai.agents")
    root_logger = logging.getLogger()
    if verbosity == "debug":
        if active is not None:
            logger.removeFilter(active)
            for handler in root_logger.handlers:
                if active in handler.filters:
                    handler.removeFilter(active)
        return None
    if active is None:
        active = _TraceNoiseFilter()
        logger.addFilter(active)
        for handler in root_logger.handlers:
            if active not in handler.filters:
                handler.addFilter(active)
    return active


def clear_trace_noise_filter(active: logging.Filter | None) -> None:
    """Remove the trace noise filter if it is active."""
    if active is None:
        return
    logging.getLogger("openai.agents").removeFilter(active)
    root_logger = logging.getLogger()
    for handler in root_logger.handlers:
        if active in handler.filters:
            handler.removeFilter(active)
