"""Redaction and digest helpers for compaction snapshot rendering."""

from __future__ import annotations

from urllib.parse import urlparse

from agenterm.core.hashing import sha256_text

MAX_TEXT_CHARS = 0  # 0 = no limit
MAX_GROUP_ITEMS = 0  # 0 = no limit


def domain(url: str) -> str | None:
    """Extract URL domain when scheme+netloc are present."""
    parsed = urlparse(url)
    if parsed.scheme and parsed.netloc:
        return parsed.netloc
    return None


def redact_text(text: str) -> tuple[list[str], int]:
    """Return redacted display lines plus original text length."""
    total = len(text)
    if MAX_TEXT_CHARS <= 0 or total <= MAX_TEXT_CHARS:
        return text.splitlines() or [""], total
    head = text[:MAX_TEXT_CHARS]
    lines = head.splitlines() or [""]
    return [*lines, f"… (+{total - MAX_TEXT_CHARS} chars)"], total


def redact_blob(value: str) -> str:
    """Redact binary/blob payloads while preserving stable diagnostics."""
    if not value.startswith("data:"):
        digest = sha256_text(value)[:12]
        return f"<inline_data len={len(value)} sha256={digest}…>"
    head, sep, tail = value.partition(",")
    if not sep:
        digest = sha256_text(value)[:12]
        return f"<data_url len={len(value)} sha256={digest}…>"
    mime = head[5:]
    if ";" in mime:
        mime = mime.split(";", 1)[0]
    b64_chars = len(tail)
    approx_bytes = (b64_chars * 3) // 4
    digest = sha256_text(value)[:12]
    mime_label = mime or "unknown"
    return f"<data_url mime={mime_label} bytes≈{approx_bytes} sha256={digest}…>"


__all__ = ("MAX_GROUP_ITEMS", "domain", "redact_blob", "redact_text")
