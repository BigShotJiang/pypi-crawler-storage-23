"""REPL controller helpers (engine sync).

This module bridges `SessionState` to the engine by:

- computing the effective AppConfig (tools gate applied),
- managing MCP server lifecycle via `McpServerPool`, and
- producing an `Agent` that is safe to run (connected MCP servers attached).
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.core.model_id import model_plane
from agenterm.core.tool_selection import (
    ToolCatalog,
    filter_selection_specs,
    resolve_selection,
    selected_mcp_server_configs,
)
from agenterm.engine.agent_factory import build_agent_from_config
from agenterm.engine.config_effective import build_runtime_config
from agenterm.engine.mcp_pool import McpServerPool

if TYPE_CHECKING:
    from agents.agent import Agent

    from agenterm.config.model import AppConfig, McpServerConfig
    from agenterm.core.toolspec import ToolSpec
    from agenterm.core.types import SessionState


def _selected_tools_for_state(
    state: SessionState,
    *,
    hosted_mode: bool,
    allow_dangerous: bool,
) -> list[ToolSpec] | None:
    tools_map = state.tools.tools_map or {}
    bundles_map = state.tools.bundles_map or {}
    catalog = ToolCatalog(
        tools_map=tools_map,
        bundles_map=bundles_map,
        default_bundles=list(state.tools.default_bundles or []),
    )
    resolved = resolve_selection(state.tools.selection, catalog=catalog)
    if resolved.error is not None:
        return None
    filtered = filter_selection_specs(
        resolved.specs,
        allow_dangerous=allow_dangerous,
        hosted_mode=hosted_mode,
        model_plane=model_plane(state.cfg.agent.model),
    )
    return list(filtered) if filtered else None


def _cfg_with_selected_mcp_servers(
    cfg: AppConfig,
    *,
    mcp_servers: tuple[McpServerConfig, ...],
) -> AppConfig:
    """Return an AppConfig variant whose mcp.servers is exactly mcp_servers."""
    return replace(cfg, mcp=replace(cfg.mcp, servers=list(mcp_servers)))


def build_agent_for_state(
    state: SessionState,
    *,
    workspace_root: Path | None = None,
) -> Agent:
    """Construct an Agent for the current session state.

    - Starts from `state.cfg` (the effective AppConfig after any CLI or
      slash-command edits).
    - Applies the tools gate (`state.tools.enabled`) so the agent sees no
      tools when the gate is off.
    - Shell commands run in an OS sandbox backend for security.
    """
    cfg_effective = build_runtime_config(
        state.cfg,
        tools_enabled=state.tools.enabled,
    )
    root = workspace_root or Path.cwd()
    # Note: MCP server lifecycle is handled separately by `McpServerPool`.
    selected = (
        _selected_tools_for_state(
            state,
            hosted_mode=False,
            allow_dangerous=True,
        )
        if state.tools.enabled
        else None
    )
    return build_agent_from_config(
        cfg_effective,
        selected_tools=selected,
        approvals=state.approvals,
        workspace_root=root,
        mcp_servers=[],
    )


def attach_mcp_servers(agent: Agent, *, pool: McpServerPool | None) -> Agent:
    """Return an Agent with the pool's connected MCP servers attached."""
    servers = pool.servers if pool is not None else []
    return agent.clone(mcp_servers=servers)


async def sync_agent_and_mcp(
    state: SessionState,
    *,
    workspace_root: Path | None,
    existing_pool: McpServerPool | None,
    existing_sig: tuple[McpServerConfig, ...],
) -> tuple[Agent, McpServerPool | None, tuple[McpServerConfig, ...]]:
    """Ensure the MCP pool is connected and return an up-to-date Agent."""
    cfg_effective: AppConfig = build_runtime_config(
        state.cfg,
        tools_enabled=state.tools.enabled,
    )
    selected_specs = (
        _selected_tools_for_state(
            state,
            hosted_mode=False,
            allow_dangerous=True,
        )
        if state.tools.enabled
        else None
    )
    desired_sig: tuple[McpServerConfig, ...] = (
        selected_mcp_server_configs(selected_specs) if selected_specs else ()
    )

    pool = existing_pool
    sig = existing_sig
    if desired_sig != existing_sig:
        if pool is not None:
            await pool.cleanup()
        if desired_sig:
            cfg_mcp = _cfg_with_selected_mcp_servers(
                cfg_effective,
                mcp_servers=desired_sig,
            )
            pool = McpServerPool.from_config(cfg_mcp)
            await pool.connect()
            sig = desired_sig
        else:
            pool = None
            sig = ()

    root = workspace_root or Path.cwd()
    agent = build_agent_from_config(
        cfg_effective,
        selected_tools=selected_specs,
        approvals=state.approvals,
        workspace_root=root,
        mcp_servers=(pool.servers if pool is not None else []),
    )
    return agent, pool, sig


__all__ = ("attach_mcp_servers", "build_agent_for_state", "sync_agent_and_mcp")
