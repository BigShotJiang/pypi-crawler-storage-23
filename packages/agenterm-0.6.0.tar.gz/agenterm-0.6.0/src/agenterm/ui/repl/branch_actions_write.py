"""Branch mutation action handlers."""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.core.error_report import build_error_report
from agenterm.core.errors import ConfigError, DatabaseError
from agenterm.core.hashing import sha256_text_or_none
from agenterm.store.branch.repo import get_branch_meta
from agenterm.store.branch.service import (
    create_agent_branch,
    create_branch_from_head,
    create_branch_from_run,
    delete_branch,
    switch_branch,
)
from agenterm.store.session.service import session_store
from agenterm.ui.repl.branch_state import (
    apply_branch_meta,
    branch_error_context,
    refresh_branch_cache,
    refresh_usage_totals,
    require_session,
)
from agenterm.ui.repl.transcript_reload import reload_repl_transcript

if TYPE_CHECKING:
    from agenterm.commands.actions import (
        ReplActionAgentSwitch,
        ReplActionBranchDelete,
        ReplActionBranchFork,
        ReplActionBranchNew,
        ReplActionBranchUse,
    )
    from agenterm.ui.repl.loop import ReplLoop


def _emit_branch_error(loop: ReplLoop, exc: Exception, *, operation: str) -> None:
    report = build_error_report(
        DatabaseError(str(exc)) if isinstance(exc, sqlite3.Error) else exc,
        context=branch_error_context(loop.state, operation),
    )
    loop.emit(report)


async def handle_branch_use(
    loop: ReplLoop,
    outcome: ReplActionBranchUse,
) -> bool:
    """Switch to an existing branch and update REPL state."""
    session = require_session(loop)
    if session is None:
        return True
    session_id = loop.state.session_id
    if not isinstance(session_id, str):
        loop.emit_command("Branch use: no active session.")
        return True
    store = session_store()
    try:
        meta = await switch_branch(
            session=session,
            store=store,
            session_id=session_id,
            branch_id=outcome.branch_id,
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        _emit_branch_error(loop, exc, operation="branch.use")
        return True

    loop.phase_state.phase = "idle"
    loop.phase_state.reset_usage()
    loop.artifacts.clear()
    loop.state = apply_branch_meta(loop.state, meta)
    try:
        branch_cache = await refresh_branch_cache(
            session_id=session_id,
            store=store,
        )
        loop.state = replace(
            loop.state,
            caches=replace(loop.state.caches, branch_ids=branch_cache),
        )
    except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to refresh branches: {exc}")
    await refresh_usage_totals(
        loop=loop,
        store=store,
        session_id=session_id,
        branch_id=meta.branch_id,
    )
    await reload_repl_transcript(loop, branch_id=meta.branch_id)
    loop.emit_command(f"Switched to branch: {meta.branch_id}")
    return True


async def handle_branch_new(
    loop: ReplLoop,
    outcome: ReplActionBranchNew,
) -> bool:
    """Create a new branch from head and switch to it."""
    session = require_session(loop)
    if session is None:
        return True
    session_id = loop.state.session_id
    if not isinstance(session_id, str):
        loop.emit_command("Branch new: no active session.")
        return True
    store = session_store()
    try:
        meta = await create_branch_from_head(
            session=session,
            store=store,
            session_id=session_id,
            branch_id=outcome.branch_id,
            kind="fork",
            created_reason="user_branch",
            agent_name=loop.state.cfg.agent.name,
            agent_path=loop.state.cfg.agent.path,
            agent_sha256=sha256_text_or_none(loop.state.cfg.agent.instructions),
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        _emit_branch_error(loop, exc, operation="branch.new")
        return True

    loop.phase_state.phase = "idle"
    loop.phase_state.reset_usage()
    loop.artifacts.clear()
    loop.state = apply_branch_meta(loop.state, meta)
    try:
        branch_cache = await refresh_branch_cache(
            session_id=session_id,
            store=store,
        )
        loop.state = replace(
            loop.state,
            caches=replace(loop.state.caches, branch_ids=branch_cache),
        )
    except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to refresh branches: {exc}")
    await refresh_usage_totals(
        loop=loop,
        store=store,
        session_id=session_id,
        branch_id=meta.branch_id,
    )
    await reload_repl_transcript(loop, branch_id=meta.branch_id)
    loop.emit_command(f"Created branch: {meta.branch_id}")
    return True


async def handle_branch_fork(
    loop: ReplLoop,
    outcome: ReplActionBranchFork,
) -> bool:
    """Fork a branch from a specific run and switch to it."""
    session = require_session(loop)
    if session is None:
        return True
    session_id = loop.state.session_id
    if not isinstance(session_id, str):
        loop.emit_command("Branch fork: no active session.")
        return True
    store = session_store()
    try:
        meta = await create_branch_from_run(
            session=session,
            store=store,
            session_id=session_id,
            run_number=outcome.run_number,
            branch_id=outcome.branch_id,
            agent_name=loop.state.cfg.agent.name,
            agent_path=loop.state.cfg.agent.path,
            agent_sha256=sha256_text_or_none(loop.state.cfg.agent.instructions),
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        _emit_branch_error(loop, exc, operation="branch.fork")
        return True

    loop.phase_state.phase = "idle"
    loop.phase_state.reset_usage()
    loop.artifacts.clear()
    loop.state = apply_branch_meta(loop.state, meta)
    try:
        branch_cache = await refresh_branch_cache(
            session_id=session_id,
            store=store,
        )
        loop.state = replace(
            loop.state,
            caches=replace(loop.state.caches, branch_ids=branch_cache),
        )
    except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to refresh branches: {exc}")
    await refresh_usage_totals(
        loop=loop,
        store=store,
        session_id=session_id,
        branch_id=meta.branch_id,
    )
    await reload_repl_transcript(loop, branch_id=meta.branch_id)
    loop.emit_command(f"Forked branch: {meta.branch_id}")
    return True


async def handle_branch_delete(
    loop: ReplLoop,
    outcome: ReplActionBranchDelete,
) -> bool:
    """Delete a branch and refresh REPL state."""
    session = require_session(loop)
    if session is None:
        return True
    session_id = loop.state.session_id
    if not isinstance(session_id, str):
        loop.emit_command("Branch delete: no active session.")
    else:
        store = session_store()
        deleted: bool | None = None
        current_meta = None
        try:
            deleted = await delete_branch(
                session=session,
                store=store,
                session_id=session_id,
                branch_id=outcome.branch_id,
                force=outcome.force,
            )
            current_meta = await get_branch_meta(
                store=store,
                session_id=session_id,
                branch_id=session.current_branch_id,
            )
        except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
            _emit_branch_error(loop, exc, operation="branch.delete")
        if deleted is not None and current_meta is None:
            msg = "Branch metadata missing after delete; refresh required."
            _emit_branch_error(loop, DatabaseError(msg), operation="branch.delete")
        if deleted is not None and current_meta is not None:
            branch_changed = loop.state.branch_id != current_meta.branch_id
            if branch_changed:
                loop.phase_state.phase = "idle"
                loop.phase_state.reset_usage()
                loop.artifacts.clear()
                loop.state = apply_branch_meta(loop.state, current_meta)
            try:
                branch_cache = await refresh_branch_cache(
                    session_id=session_id,
                    store=store,
                )
                loop.state = replace(
                    loop.state,
                    caches=replace(loop.state.caches, branch_ids=branch_cache),
                )
            except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
                loop.emit_command(f"warn> Failed to refresh branches: {exc}")
            if branch_changed:
                await refresh_usage_totals(
                    loop=loop,
                    store=store,
                    session_id=session_id,
                    branch_id=current_meta.branch_id,
                )
                await reload_repl_transcript(loop, branch_id=current_meta.branch_id)
            msg = (
                f"Deleted branch: {outcome.branch_id}"
                if deleted
                else f"Branch not found: {outcome.branch_id}"
            )
            loop.emit_command(msg)
    return True


async def handle_agent_switch(
    loop: ReplLoop,
    outcome: ReplActionAgentSwitch,
) -> bool:
    """Create or reuse a branch for agent changes."""
    session = require_session(loop)
    if session is None:
        return True
    session_id = loop.state.session_id
    if not isinstance(session_id, str):
        loop.emit_command("Agent switch: no active session.")
        return True
    store = session_store()
    try:
        creation = await create_agent_branch(
            session=session,
            store=store,
            session_id=session_id,
            branch_id=None,
            agent_name=loop.state.cfg.agent.name,
            agent_path=loop.state.cfg.agent.path,
            agent_sha256=sha256_text_or_none(loop.state.cfg.agent.instructions),
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        _emit_branch_error(loop, exc, operation="agent.switch")
        return True

    loop.phase_state.phase = "idle"
    loop.phase_state.reset_usage()
    loop.artifacts.clear()
    loop.state = apply_branch_meta(loop.state, creation.branch_meta)
    try:
        branch_cache = await refresh_branch_cache(
            session_id=session_id,
            store=store,
        )
        loop.state = replace(
            loop.state,
            caches=replace(loop.state.caches, branch_ids=branch_cache),
        )
    except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to refresh branches: {exc}")
    await refresh_usage_totals(
        loop=loop,
        store=store,
        session_id=session_id,
        branch_id=creation.branch_id,
    )
    await reload_repl_transcript(loop, branch_id=creation.branch_id)
    notice = outcome.notice or f"Agent switched to branch: {creation.branch_id}"
    loop.emit_command(notice)
    return True


__all__ = (
    "handle_agent_switch",
    "handle_branch_delete",
    "handle_branch_fork",
    "handle_branch_new",
    "handle_branch_use",
)
