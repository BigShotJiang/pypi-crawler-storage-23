"""Build compression emitters for REPL output."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.steward.emitters import CompressionEmitters
from agenterm.ui.repl.compress_snapshot import format_compaction_snapshot_lines
from agenterm.ui.repl.snapshot_summary import format_snapshot_lines

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from agents.items import TResponseInputItem

    from agenterm.steward.continuation_state import ContinuationCapsule


def build_compression_emitters(
    emit_line: Callable[[str], None] | None,
) -> CompressionEmitters | None:
    """Return compression emitters that render continuation blocks."""
    if emit_line is None:
        return None

    def _emit_snapshot(snapshot: ContinuationCapsule) -> None:
        for line in format_snapshot_lines(snapshot):
            emit_line(line)

    def _emit_compaction(items: Sequence[TResponseInputItem]) -> None:
        lines = format_compaction_snapshot_lines(items)
        if lines is None:
            emit_line("warn> Compression continuation unavailable.")
            return
        for line in lines:
            emit_line(line)

    return CompressionEmitters(
        emit_line=emit_line,
        emit_snapshot=_emit_snapshot,
        emit_compaction=_emit_compaction,
    )


__all__ = ("build_compression_emitters",)
