"""Read-only branch action handlers."""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.core.error_report import build_error_report
from agenterm.core.errors import ConfigError, DatabaseError, ValidationError
from agenterm.core.json_codec import require_json_object
from agenterm.store.branch.repo import get_branch_meta, list_branch_meta
from agenterm.store.branch.summary import parse_branch_summary
from agenterm.store.history import history_store
from agenterm.store.runs import list_runs
from agenterm.store.session.service import (
    last_message_snippets_by_branch,
    session_store,
    usage_totals_by_run,
)
from agenterm.ui.repl.branch_state import (
    branch_error_context,
    build_branch_list_lines,
    require_session,
)

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplActionBranchList, ReplActionBranchRuns
    from agenterm.core.token_usage import TokenUsage
    from agenterm.store.branch.models import BranchMeta
    from agenterm.store.branch.summary import BranchSummary
    from agenterm.store.runs.models import RunStatusRecord
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession
    from agenterm.ui.repl.loop import ReplLoop


def _emit_branch_error(loop: ReplLoop, exc: Exception, *, operation: str) -> None:
    if isinstance(exc, sqlite3.Error):
        report = build_error_report(
            DatabaseError(str(exc)),
            context=branch_error_context(loop.state, operation),
        )
    else:
        report = build_error_report(
            exc,
            context=branch_error_context(loop.state, operation),
        )
    loop.emit(report)


def _emit_branch_list_error(loop: ReplLoop, exc: Exception) -> None:
    if isinstance(exc, sqlite3.Error):
        exc = DatabaseError(str(exc))
    report = build_error_report(
        exc,
        context=branch_error_context(loop.state, "branch.list"),
    )
    loop.emit(report)


async def _load_branch_list_data(
    loop: ReplLoop,
    *,
    session: AgentermSQLiteSession,
    session_id: str,
) -> tuple[list[BranchSummary], list[BranchMeta]] | None:
    store = session_store()
    try:
        branches = await session.list_branches()
        meta_rows = await list_branch_meta(store, session_id)
    except (ConfigError, OSError, sqlite3.Error, DatabaseError, ValidationError) as exc:
        _emit_branch_list_error(loop, exc)
        return None
    try:
        summaries: list[BranchSummary] = []
        for branch in branches:
            branch_json = require_json_object(
                value=branch,
                context="branch.list.entry",
            )
            summaries.append(parse_branch_summary(branch_json))
    except ValidationError as exc:
        _emit_branch_list_error(loop, exc)
        return None
    return summaries, list(meta_rows)


async def _load_branch_runs(
    loop: ReplLoop,
    *,
    session_id: str,
    branch_id: str,
) -> tuple[tuple[RunStatusRecord, ...], dict[int, TokenUsage]] | None:
    store = session_store()
    try:
        meta = await get_branch_meta(store, session_id, branch_id)
    except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
        _emit_branch_error(loop, exc, operation="branch.runs")
        return None
    if meta is None:
        _emit_branch_error(
            loop,
            ConfigError(f"Unknown branch_id: {branch_id!r}"),
            operation="branch.runs",
        )
        return None
    runs = await list_runs(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        limit=None,
    )
    usage_by_run = await usage_totals_by_run(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
    )
    return runs, usage_by_run


async def handle_branch_list(
    loop: ReplLoop,
    _outcome: ReplActionBranchList,
) -> bool:
    """Render the branch list for the active session."""
    session = require_session(loop)
    if session is None:
        return True
    session_id = loop.state.session_id
    if not isinstance(session_id, str):
        loop.emit_command("Branch list: no active session.")
        return True
    history = history_store()
    loaded = await _load_branch_list_data(
        loop,
        session=session,
        session_id=session_id,
    )
    if loaded is None:
        return True
    summaries, meta_rows = loaded
    snippets = await last_message_snippets_by_branch(
        store=history,
        session_id=session_id,
        branch_ids=[summary.branch_id for summary in summaries],
    )
    lines, branch_ids = build_branch_list_lines(
        session_id=session_id,
        branches=summaries,
        meta_rows=meta_rows,
        last_messages=snippets,
    )
    loop.state = replace(
        loop.state,
        caches=replace(loop.state.caches, branch_ids=branch_ids),
    )
    loop.emit_command_lines(lines)
    return True


async def handle_branch_runs(
    loop: ReplLoop,
    outcome: ReplActionBranchRuns,
) -> bool:
    """Render run history for the selected branch."""
    session = require_session(loop)
    if session is None:
        return True
    session_id = loop.state.session_id
    if not isinstance(session_id, str):
        loop.emit_command("Branch runs: no active session.")
    else:
        branch_id = outcome.branch_id or loop.state.branch_id or "main"
        loaded = await _load_branch_runs(
            loop,
            session_id=session_id,
            branch_id=branch_id,
        )
        if loaded is not None:
            runs, usage_by_run = loaded
            runs_list = list(runs)
            if outcome.limit is not None and outcome.limit > 0:
                runs_list = runs_list[: outcome.limit]
            lines: list[str] = [f"Branch runs ({session_id}, {branch_id}):"]
            if not runs_list:
                lines.append("No runs recorded.")
            else:
                for run in runs_list:
                    usage = usage_by_run.get(run.run_number)
                    if usage is None:
                        tokens = "-"
                    else:
                        tokens = (
                            f"{usage.input_tokens}({usage.input_cached_tokens})"
                            f"->{usage.output_tokens}"
                            f"({usage.output_reasoning_tokens})"
                            f"={usage.total_tokens}"
                        )
                    status = run.status or "-"
                    response_id = run.response_id or "-"
                    line = (
                        f"- {run.run_number}: {status}  tokens={tokens}  "
                        f"response={response_id}"
                    )
                    lines.append(line)
            loop.emit_command_lines(lines)
    return True


__all__ = ("handle_branch_list", "handle_branch_runs")
