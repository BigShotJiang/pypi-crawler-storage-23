"""History helpers for REPL prompt-toolkit history persistence."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.paths import ensure_history_dir

if TYPE_CHECKING:
    from pathlib import Path


def history_file_path() -> Path:
    """Return the REPL history file path.

    This file backs prompt-toolkit's `FileHistory` and is distinct from the
    SQLite session store used for full session history (SDK turns).

    Ensures the parent directory exists before returning.
    """
    return ensure_history_dir()
