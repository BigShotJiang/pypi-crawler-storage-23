"""REPL stderr capture buffer + sink."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.constants.display import REPL_ERROR_MAX_LINES_DEFAULT

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.ui.repl.phase_state import ReplPhaseState


@dataclass(frozen=True, slots=True)
class ErrorBufferSnapshot:
    """Snapshot of captured stderr lines."""

    lines: tuple[str, ...]
    total: int
    dropped: int


@dataclass(frozen=True, slots=True)
class ErrorAppendResult:
    """Outcome of appending one stderr line."""

    emit_line: bool
    truncated_now: bool


class ReplErrorBuffer:
    """Bounded ring buffer for stderr lines."""

    def __init__(self, *, max_lines: int = REPL_ERROR_MAX_LINES_DEFAULT) -> None:
        """Initialize the buffer with a max line cap."""
        self._max_lines = max(0, int(max_lines))
        self._lines: deque[str] = deque()
        self._total = 0
        self._dropped = 0
        self._emit_enabled = True
        self._truncated = False

    def append_line(self, line: str) -> ErrorAppendResult:
        """Append a stderr line and return clamp/emit decisions."""
        if not line:
            return ErrorAppendResult(emit_line=False, truncated_now=False)
        self._total += 1
        dropped = False
        if self._max_lines <= 0:
            dropped = True
            self._dropped += 1
        else:
            if len(self._lines) >= self._max_lines:
                self._lines.popleft()
                dropped = True
                self._dropped += 1
            self._lines.append(line)
        truncated_now = False
        if dropped and not self._truncated:
            self._truncated = True
            self._emit_enabled = False
            truncated_now = True
        emit_line = self._emit_enabled and not dropped
        return ErrorAppendResult(emit_line=emit_line, truncated_now=truncated_now)

    def snapshot(self) -> ErrorBufferSnapshot:
        """Return a stable snapshot of the buffer."""
        return ErrorBufferSnapshot(
            lines=tuple(self._lines),
            total=self._total,
            dropped=self._dropped,
        )

    @property
    def truncated(self) -> bool:
        """Return True when the buffer has dropped entries."""
        return self._truncated


class ReplErrorSink:
    """Event-loop sink for stderr lines."""

    def __init__(
        self,
        *,
        buffer: ReplErrorBuffer,
        emit_error_line: Callable[[str], None],
        phase_state: ReplPhaseState,
        ui_invalidate: Callable[[], None],
    ) -> None:
        """Initialize the sink with storage + UI hooks."""
        self._buffer = buffer
        self._emit_error_line = emit_error_line
        self._phase_state = phase_state
        self._ui_invalidate = ui_invalidate

    def handle_line(self, line: str) -> None:
        """Handle one stderr line (event-loop thread)."""
        text = line.rstrip()
        if not text.strip():
            return
        result = self._buffer.append_line(text)
        if result.emit_line:
            self._emit_error_line(text)
        if result.truncated_now:
            self._emit_error_line("(truncated; see /errors)")
        snapshot = self._buffer.snapshot()
        self._phase_state.set_error_state(
            count=snapshot.total,
            truncated=snapshot.dropped > 0,
        )
        self._ui_invalidate()

    def snapshot(self) -> ErrorBufferSnapshot:
        """Return the current error buffer snapshot."""
        return self._buffer.snapshot()


__all__ = (
    "ErrorAppendResult",
    "ErrorBufferSnapshot",
    "ReplErrorBuffer",
    "ReplErrorSink",
)
