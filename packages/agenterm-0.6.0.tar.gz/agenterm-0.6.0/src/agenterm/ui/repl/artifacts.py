"""In-memory REPL artifact index.

The REPL transcript is rendered from streamed run items. Some artifacts are
useful to re-render on-demand (e.g., "last apply_patch diff") without parsing
printed output. This module keeps a small, typed in-memory index for the active
REPL process.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from agenterm.ui.transcript.blocks import (
    ApplyPatchCallArtifact,
    ToolCallBlock,
    ToolOutputBlock,
    TranscriptBuild,
)
from agenterm.ui.transcript.diffs import DIFF_HINT_LINE, format_unified_diff_lines

type LastArtifactMode = Literal["preview", "full"]


@dataclass(slots=True)
class ReplArtifactIndex:
    """Capture the most recent artifacts for the current REPL process."""

    last_apply_patch_call: ApplyPatchCallArtifact | None = None
    last_tool_call: ToolCallBlock | None = None
    last_tool_output: ToolOutputBlock | None = None

    def clear(self) -> None:
        """Clear all captured artifacts."""
        self.last_apply_patch_call = None
        self.last_tool_call = None
        self.last_tool_output = None

    def on_transcript_build(self, build: TranscriptBuild) -> None:
        """Capture artifacts from a built transcript block."""
        if build.artifacts.apply_patch_call is not None:
            self.last_apply_patch_call = build.artifacts.apply_patch_call

        block = build.block
        if block is None:
            return
        if isinstance(block, ToolCallBlock):
            self.last_tool_call = block
        elif isinstance(block, ToolOutputBlock):
            self.last_tool_output = block


def last_apply_patch_diff_lines(
    artifact: ApplyPatchCallArtifact,
    *,
    mode: LastArtifactMode,
    preview_max_lines: int,
) -> tuple[str, ...]:
    """Return deterministic lines for the last apply_patch diff (preview bounded)."""
    header = f"last diff ({mode}): {artifact.op_type} {artifact.path}"
    diff = (artifact.diff or "").strip()
    if not diff:
        return (header, "(no diff available)")
    diff_lines = format_unified_diff_lines(diff)
    if not diff_lines:
        return (header, "(no diff available)")
    if mode == "preview":
        limit = max(0, int(preview_max_lines))
        if limit <= 0:
            return (header, DIFF_HINT_LINE)
        limited = diff_lines[:limit]
        lines: list[str] = [header, *limited]
        if len(diff_lines) > limit:
            lines.append("…")
            lines.append(DIFF_HINT_LINE)
        return tuple(lines)
    return (header, *diff_lines)


__all__ = (
    "LastArtifactMode",
    "ReplArtifactIndex",
    "last_apply_patch_diff_lines",
)
