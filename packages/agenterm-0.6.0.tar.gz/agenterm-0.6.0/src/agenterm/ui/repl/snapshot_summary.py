"""Rendering helpers for compression continuation capsules (Steward)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_json_list, as_json_object, as_str
from agenterm.core.response_items import serialize_input_item
from agenterm.steward.continuation_state import (
    ContinuationCapsule,
    ContinuationIntegrity,
    ContinuationOpenItem,
    ContinuationPending,
    parse_continuation_state_text,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.items import TResponseInputItem

    from agenterm.core.json_types import JSONValue


_SNAPSHOT_HEADER = "compress> continuation (snapshot)"
_SNAPSHOT_ROLES: tuple[str, ...] = ("user", "assistant", "developer")
_SNAPSHOT_PART_TYPES: tuple[str, ...] = ("input_text", "output_text")


def _message_parts(
    msg: Mapping[str, JSONValue],
) -> list[dict[str, JSONValue]]:
    parts_obj = as_json_list(msg.get("content"))
    if parts_obj is None:
        return []
    out: list[dict[str, JSONValue]] = []
    for raw in parts_obj:
        part = as_json_object(raw)
        if part is not None:
            out.append(part)
    return out


def _to_json_object(item: TResponseInputItem) -> dict[str, JSONValue] | None:
    try:
        return serialize_input_item(item, context="snapshot_summary.item")
    except ConfigError:
        return None


def _extract_snapshot(
    items: Sequence[TResponseInputItem],
) -> ContinuationCapsule | None:
    for item in items:
        obj = _to_json_object(item)
        if obj is None:
            continue
        if obj.get("type") != "message":
            continue
        role = obj.get("role")
        if not isinstance(role, str) or role not in _SNAPSHOT_ROLES:
            continue
        for part in _message_parts(obj):
            part_type = part.get("type")
            if not isinstance(part_type, str) or part_type not in _SNAPSHOT_PART_TYPES:
                continue
            text = as_str(part.get("text"))
            if not text:
                continue
            snapshot = parse_continuation_state_text(text)
            if snapshot is not None:
                return snapshot
    return None


def _render_list(label: str, items: Sequence[str]) -> list[str]:
    if not items:
        return [f"{label}: none"]
    lines = [label]
    lines.extend(f"- {item}" for item in items)
    return lines


def _render_open(items: Sequence[ContinuationOpenItem]) -> list[str]:
    if not items:
        return ["Open: none"]
    lines = ["Open:"]
    for item in items:
        lines.append(f"- goal: {item.goal}")
        lines.append(f"  on: {item.on}")
        lines.append(f"  ready_when: {item.ready_when}")
    return lines


def _render_pending(pending: ContinuationPending) -> list[str]:
    if pending.kind == "none":
        return ["Pending:", "- kind: none"]
    if pending.kind == "tool_call" and pending.tool_call is not None:
        return [
            "Pending:",
            "- kind: tool_call",
            f"- tool: {pending.tool_call.tool}",
            f"- call_id: {pending.tool_call.call_id}",
            f"- args_digest: {pending.tool_call.args_digest}",
        ]
    if pending.kind == "assistant_output" and pending.assistant_output is not None:
        return [
            "Pending:",
            "- kind: assistant_output",
            f"- prefix: {pending.assistant_output.prefix}",
            f"- intent: {pending.assistant_output.intent}",
        ]
    return ["Pending: invalid"]


def _render_integrity(integrity: ContinuationIntegrity) -> list[str]:
    lines = ["Integrity:", f"- risk: {integrity.risk}"]
    lines.extend(_render_list("Assumptions:", integrity.assumptions))
    lines.extend(_render_list("Unknowns:", integrity.unknowns))
    return lines


def format_snapshot_lines(snapshot: ContinuationCapsule) -> list[str]:
    """Return continuation lines for a ContinuationCapsule payload."""
    lines: list[str] = [_SNAPSHOT_HEADER]
    lines.extend(_render_list("State:", snapshot.state))
    lines.append("")
    lines.extend(_render_open(snapshot.open))
    lines.append("")
    lines.extend(_render_pending(snapshot.pending))
    lines.append("")
    lines.extend(
        [
            "Next:",
            f"- actor: {snapshot.next.actor}",
            f"- action: {snapshot.next.action}",
            f"- success: {snapshot.next.success}",
        ]
    )
    lines.append("")
    lines.extend(_render_integrity(snapshot.integrity))
    return lines


def format_continuation_capsule_lines(
    items: Sequence[TResponseInputItem],
) -> list[str] | None:
    """Return continuation lines for a ContinuationCapsule message payload."""
    snapshot = _extract_snapshot(items)
    if snapshot is None:
        return None
    return format_snapshot_lines(snapshot)


__all__ = ("format_continuation_capsule_lines", "format_snapshot_lines")
