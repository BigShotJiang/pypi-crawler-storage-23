"""Branch-focused REPL action dispatch."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.actions import (
    ReplAction,
    ReplActionAgentSwitch,
    ReplActionBranchDelete,
    ReplActionBranchFork,
    ReplActionBranchList,
    ReplActionBranchNew,
    ReplActionBranchRuns,
    ReplActionBranchUse,
)
from agenterm.ui.repl.branch_actions_read import (
    handle_branch_list,
    handle_branch_runs,
)
from agenterm.ui.repl.branch_actions_write import (
    handle_agent_switch,
    handle_branch_delete,
    handle_branch_fork,
    handle_branch_new,
    handle_branch_use,
)

if TYPE_CHECKING:
    from agenterm.ui.repl.loop import ReplLoop


async def handle_branch_action(loop: ReplLoop, outcome: ReplAction) -> bool | None:
    """Dispatch branch-related actions."""
    result: bool | None = None
    if isinstance(outcome, ReplActionBranchList):
        result = await handle_branch_list(loop, outcome)
    elif isinstance(outcome, ReplActionBranchUse):
        result = await handle_branch_use(loop, outcome)
    elif isinstance(outcome, ReplActionBranchNew):
        result = await handle_branch_new(loop, outcome)
    elif isinstance(outcome, ReplActionBranchFork):
        result = await handle_branch_fork(loop, outcome)
    elif isinstance(outcome, ReplActionBranchDelete):
        result = await handle_branch_delete(loop, outcome)
    elif isinstance(outcome, ReplActionBranchRuns):
        result = await handle_branch_runs(loop, outcome)
    elif isinstance(outcome, ReplActionAgentSwitch):
        result = await handle_agent_switch(loop, outcome)
    return result


__all__ = ("handle_branch_action",)
