"""Aggregation helpers for compaction snapshot summaries."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.hashing import sha256_text
from agenterm.ui.repl.compress_snapshot_json import json_dict, json_list, json_str
from agenterm.ui.repl.compress_snapshot_parts import message_parts
from agenterm.ui.repl.compress_snapshot_redact import domain
from agenterm.ui.repl.compress_snapshot_types import CitationGroups

if TYPE_CHECKING:
    from collections.abc import Mapping, MutableMapping, Sequence

    from agenterm.core.json_types import JSONMapping, JSONValue


def collect_role_counts(snapshot: Sequence[JSONMapping]) -> dict[str, int]:
    """Count message roles in the snapshot slice."""
    role_counts = dict[str, int]()
    for item in snapshot:
        if item.get("type") != "message":
            continue
        role = json_str(item.get("role")) or "unknown"
        role_counts[role] = role_counts.get(role, 0) + 1
    return role_counts


def collect_part_counts(snapshot: Sequence[JSONMapping]) -> dict[str, int]:
    """Count message part types in the snapshot slice."""
    part_counts = dict[str, int]()
    for item in snapshot:
        if item.get("type") != "message":
            continue
        for part in message_parts(item):
            part_type = json_str(part.get("type")) or "unknown"
            part_counts[part_type] = part_counts.get(part_type, 0) + 1
    return part_counts


def collect_file_groups(snapshot: Sequence[JSONMapping]) -> dict[str, int]:
    """Group input_file parts by stable identity key."""
    groups = dict[str, int]()
    for item in snapshot:
        if item.get("type") != "message":
            continue
        for part in message_parts(item):
            if part.get("type") != "input_file":
                continue
            file_id = json_str(part.get("file_id"))
            file_url = json_str(part.get("file_url"))
            filename = json_str(part.get("filename"))
            file_data = json_str(part.get("file_data"))
            if file_id is not None:
                key = f"file_id:{file_id}"
            elif file_url is not None:
                key = f"file_url:{file_url}"
            elif file_data is not None:
                digest = sha256_text(file_data)[:12]
                key = f"file_data:{digest}…"
            elif filename is not None:
                key = f"filename:{filename}"
            else:
                key = "file:<unknown>"
            groups[key] = groups.get(key, 0) + 1
    return groups


def collect_image_groups(snapshot: Sequence[JSONMapping]) -> dict[str, int]:
    """Group input_image parts by stable identity key."""
    groups = dict[str, int]()
    for item in snapshot:
        if item.get("type") != "message":
            continue
        for part in message_parts(item):
            if part.get("type") != "input_image":
                continue
            file_id = json_str(part.get("file_id"))
            image_url = json_str(part.get("image_url"))
            if file_id is not None:
                key = f"file_id:{file_id}"
            elif image_url is not None and image_url.startswith("data:"):
                digest = sha256_text(image_url)[:12]
                key = f"data_url:{digest}…"
            elif image_url is not None:
                key = f"url:{image_url}"
            else:
                key = "image:<unknown>"
            groups[key] = groups.get(key, 0) + 1
    return groups


def _track_container_file_citation(
    groups: MutableMapping[str, dict[str, int]],
    ann: Mapping[str, JSONValue],
) -> None:
    container_id = json_str(ann.get("container_id")) or "<unknown>"
    file_id = json_str(ann.get("file_id")) or "<unknown>"
    by_container = groups.get(container_id)
    if by_container is None:
        by_container = dict[str, int]()
        groups[container_id] = by_container
    by_container[file_id] = by_container.get(file_id, 0) + 1


def _track_simple_file_citation(
    groups: MutableMapping[str, int],
    ann: Mapping[str, JSONValue],
) -> None:
    file_id = json_str(ann.get("file_id")) or "<unknown>"
    groups[file_id] = groups.get(file_id, 0) + 1


def _track_url_citation(
    groups: MutableMapping[str, int],
    ann: Mapping[str, JSONValue],
) -> None:
    url = json_str(ann.get("url")) or ""
    key = domain(url) or url or "<unknown>"
    groups[key] = groups.get(key, 0) + 1


def _track_annotation(
    ann: Mapping[str, JSONValue],
    *,
    container_file: MutableMapping[str, dict[str, int]],
    file_citation: MutableMapping[str, int],
    file_path: MutableMapping[str, int],
    url_citation: MutableMapping[str, int],
) -> None:
    ann_type = json_str(ann.get("type")) or ""
    if ann_type == "container_file_citation":
        _track_container_file_citation(container_file, ann)
    elif ann_type == "file_citation":
        _track_simple_file_citation(file_citation, ann)
    elif ann_type == "file_path":
        _track_simple_file_citation(file_path, ann)
    elif ann_type == "url_citation":
        _track_url_citation(url_citation, ann)


def _collect_message_citations(
    item: JSONMapping,
    *,
    container_file: MutableMapping[str, dict[str, int]],
    file_citation: MutableMapping[str, int],
    file_path: MutableMapping[str, int],
    url_citation: MutableMapping[str, int],
) -> None:
    if item.get("type") != "message":
        return
    for part in message_parts(item):
        if part.get("type") != "output_text":
            continue
        annotations = json_list(part.get("annotations")) or []
        for ann_raw in annotations:
            ann = json_dict(ann_raw)
            if ann is None:
                continue
            _track_annotation(
                ann,
                container_file=container_file,
                file_citation=file_citation,
                file_path=file_path,
                url_citation=url_citation,
            )


def collect_citations(snapshot: Sequence[JSONMapping]) -> CitationGroups:
    """Aggregate output_text annotation citations across the snapshot."""
    container_file = dict[str, dict[str, int]]()
    file_citation = dict[str, int]()
    file_path = dict[str, int]()
    url_citation = dict[str, int]()

    for item in snapshot:
        _collect_message_citations(
            item,
            container_file=container_file,
            file_citation=file_citation,
            file_path=file_path,
            url_citation=url_citation,
        )
    return CitationGroups(
        container_file=container_file,
        file_citation=file_citation,
        file_path=file_path,
        url_citation=url_citation,
    )


__all__ = (
    "collect_citations",
    "collect_file_groups",
    "collect_image_groups",
    "collect_part_counts",
    "collect_role_counts",
)
