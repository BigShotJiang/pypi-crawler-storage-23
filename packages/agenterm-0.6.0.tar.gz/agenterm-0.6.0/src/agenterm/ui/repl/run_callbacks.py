"""Streamed REPL callback helpers (TUI event emission)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

from agents.items import ToolCallOutputItem

from agenterm.ui.transcript.blocks import TranscriptBuild, build_transcript_item
from agenterm.ui.transcript.plan_utils import (
    get_tool_call_output_call_id,
    get_tool_call_output_type,
)
from agenterm.ui.tui.state import (
    TextDeltaEvent,
    TranscriptEntryAddedEvent,
    TranscriptTextEntry,
    UiEvent,
)
from agenterm.workflow.run.model import StreamEventCallbacks

if TYPE_CHECKING:
    from collections.abc import Callable

    from agents.items import RunItem

    from agenterm.core.plan import PlanSnapshot
    from agenterm.core.types import SessionState
    from agenterm.ui.repl.phase_state import ReplPhaseState
    from agenterm.ui.transcript.model import TranscriptPolicy

type TranscriptBuildSink = Callable[[TranscriptBuild], None]
type PlanSnapshotLoader = Callable[[str], PlanSnapshot | None]
type UiEventEmitter = Callable[[UiEvent], None]

_RAW_DEBUG_EVENT_MAX_LINES: Final[int] = 40
_RAW_DEBUG_EVENT_TRUNCATION_LINE: Final[int] = _RAW_DEBUG_EVENT_MAX_LINES + 1


@dataclass(slots=True)
class StreamMarkers:
    """Mutable markers shared across stream callbacks."""

    debug_raw_count: int = 0
    saw_text_delta: bool = False


def _plan_status_marker(status: str) -> str:
    if status == "completed":
        return "x"
    if status == "in_progress":
        return ">"
    return "-"


def _plan_lines(snapshot: PlanSnapshot) -> list[str]:
    lines: list[str] = ["[plan] updated"]
    if snapshot.explanation:
        lines.append(f"  note: {snapshot.explanation}")
    for step in snapshot.steps:
        marker = _plan_status_marker(step.status)
        lines.append(f"  {marker} {step.step}")
    return lines


def _maybe_emit_plan_update(
    item: ToolCallOutputItem,
    *,
    plan_snapshot_loader: PlanSnapshotLoader | None,
    emit_event: UiEventEmitter,
) -> bool:
    if plan_snapshot_loader is None:
        return False
    raw = item.raw_item
    if get_tool_call_output_type(raw) != "function_call_output":
        return False
    call_id = get_tool_call_output_call_id(raw)
    if call_id is None:
        return False
    snapshot = plan_snapshot_loader(call_id)
    if snapshot is None:
        return False
    lines = _plan_lines(snapshot)
    emit_event(
        TranscriptEntryAddedEvent(
            entry=TranscriptTextEntry(role="system", text="\n".join(lines)),
        ),
    )
    return True


def _emit_raw_debug_event(
    type_str: str,
    *,
    markers: StreamMarkers,
    emit_event: UiEventEmitter,
) -> None:
    markers.debug_raw_count += 1
    if markers.debug_raw_count <= _RAW_DEBUG_EVENT_MAX_LINES:
        emit_event(
            TranscriptEntryAddedEvent(
                entry=TranscriptTextEntry(role="system", text=f"[event] {type_str}"),
            ),
        )
        return
    if markers.debug_raw_count == _RAW_DEBUG_EVENT_TRUNCATION_LINE:
        emit_event(
            TranscriptEntryAddedEvent(
                entry=TranscriptTextEntry(
                    role="system",
                    text="... (raw events truncated)",
                ),
            ),
        )


def _make_reasoning_delta_callback(
    phase_state: ReplPhaseState | None,
) -> Callable[[str], None] | None:
    """Return a reasoning delta callback, or None if phase_state is absent."""
    if phase_state is None:
        return None

    def _on_reasoning_delta(delta: str) -> None:
        if delta:
            phase_state.set_event_hint("sum.δ")

    return _on_reasoning_delta


def build_stream_callbacks(
    state: SessionState,
    *,
    policy: TranscriptPolicy,
    markers: StreamMarkers,
    sink: TranscriptBuildSink | None,
    plan_snapshot_loader: PlanSnapshotLoader | None,
    emit_event: UiEventEmitter,
    phase_state: ReplPhaseState | None = None,
) -> StreamEventCallbacks:
    """Construct StreamEventCallbacks for the TUI transcript."""

    def _on_text_delta(delta: str) -> None:
        if not delta:
            return
        markers.saw_text_delta = True
        emit_event(TextDeltaEvent(text=delta, block_id="assistant"))

    def _on_run_item(item: RunItem) -> None:
        if isinstance(item, ToolCallOutputItem) and _maybe_emit_plan_update(
            item,
            plan_snapshot_loader=plan_snapshot_loader,
            emit_event=emit_event,
        ):
            return
        build = build_transcript_item(item, policy=policy)
        if sink is not None:
            sink(build)
        if build.block is None:
            return
        emit_event(TranscriptEntryAddedEvent(entry=build.block))

    def _on_raw_event_type(type_str: str) -> None:
        # Update activity indicator (always, regardless of debug mode)
        if phase_state is not None:
            phase_state.set_event_hint(type_str)
        # Emit debug transcript entry only in debug mode
        if state.ui.verbosity == "debug":
            _emit_raw_debug_event(type_str, markers=markers, emit_event=emit_event)

    stream_live = state.ui.stream_mode == "live"
    reasoning_callback = (
        _make_reasoning_delta_callback(phase_state) if stream_live else None
    )
    return StreamEventCallbacks(
        on_text_delta=_on_text_delta if stream_live else None,
        on_reasoning_summary_delta=reasoning_callback,
        on_run_item=_on_run_item,
        on_raw_event_type=_on_raw_event_type,  # Always set for activity indicator
    )


__all__ = ("StreamMarkers", "build_stream_callbacks")
