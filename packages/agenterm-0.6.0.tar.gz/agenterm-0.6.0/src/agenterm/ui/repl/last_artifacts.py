"""Render helpers for bounded "last artifact" commands in the REPL."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.constants.display import (
    APPROVALS_FULL_MAX_COMMANDS_DEFAULT,
    APPROVALS_FULL_MAX_DIFF_LINES_DEFAULT,
    APPROVALS_FULL_MAX_LINES_DEFAULT,
    APPROVALS_FULL_MAX_MCP_ARGS_CHARS_DEFAULT,
    APPROVALS_FULL_MAX_RECORDS_DEFAULT,
    APPROVALS_PREVIEW_MAX_CHARS_DEFAULT,
    APPROVALS_PREVIEW_MAX_LINES_DEFAULT,
    APPROVALS_PREVIEW_MAX_RECORDS_DEFAULT,
)
from agenterm.ui.repl.artifacts import ReplArtifactIndex, last_apply_patch_diff_lines
from agenterm.ui.tool_events import BoundedLineWriter, shorten_line

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from agenterm.commands.actions import ReplActionLastArtifact
    from agenterm.core.approvals_audit import ApprovalAuditRecord
    from agenterm.core.types import SessionState


def _approvals_summary(record: ApprovalAuditRecord) -> str:
    d = record.detail
    if record.family == "shell":
        head = d.commands[0] if d.commands else ""
        extra = len(d.commands) - 1
        summary = shorten_line(head, limit=80) if head else "(no command)"
        if d.description:
            summary = shorten_line(f"{d.description} — {summary}", limit=92)
        if extra > 0:
            summary = shorten_line(f"{summary} (+{extra})", limit=92)
        if isinstance(d.cwd, str) and d.cwd:
            return f"{summary} (cwd={d.cwd})"
        return summary
    if record.family == "patch":
        op = d.operation_type or "(unknown op)"
        path = d.path or "(unknown path)"
        if d.description:
            return f"{d.description} — {op} {path}"
        return f"{op} {path}"
    if record.family == "compress":
        action = d.compress_action or "compress"
        message = d.compress_message or "(no message)"
        summary = shorten_line(message, limit=92)
        return f"{action}: {summary}"
    server = d.server_label or "(unknown server)"
    tool = d.tool_name or "(unknown tool)"
    return f"{server} {tool}"


def _approval_state(record: ApprovalAuditRecord) -> str:
    decision = record.decision
    if decision is None:
        return "pending"
    if decision.approved:
        return "approved"
    return "rejected"


def _approval_rejection_reason(record: ApprovalAuditRecord) -> str | None:
    decision = record.decision
    if decision is None or decision.approved:
        return None
    reason = decision.reason
    return reason if isinstance(reason, str) and reason else None


def _append_approval_preview_line(
    writer: BoundedLineWriter,
    record: ApprovalAuditRecord,
) -> bool:
    state = _approval_state(record)
    summary = _approvals_summary(record)
    reason = _approval_rejection_reason(record)
    line = f"- [{record.family}] {record.id}: {state} — {summary}"
    if reason:
        line = shorten_line(
            f"{line} (reason: {reason})",
            limit=APPROVALS_PREVIEW_MAX_CHARS_DEFAULT,
        )
    return writer.append(line)


def _append_shell_approval_details(
    writer: BoundedLineWriter,
    record: ApprovalAuditRecord,
) -> bool:
    d = record.detail
    if d.description and not writer.append(f"- description: {d.description}"):
        return False
    if isinstance(d.cwd, str) and d.cwd and not writer.append(f"- cwd: {d.cwd}"):
        return False
    if d.commands and not writer.append("- commands:"):
        return False
    for cmd in d.commands[:APPROVALS_FULL_MAX_COMMANDS_DEFAULT]:
        if not writer.append(f"  {cmd}"):
            return False
    return True


def _append_patch_approval_details(
    writer: BoundedLineWriter,
    record: ApprovalAuditRecord,
) -> bool:
    d = record.detail
    ok = True
    if isinstance(d.operation_type, str) and d.operation_type:
        ok = writer.append(f"- op: {d.operation_type}")
    if ok and isinstance(d.path, str) and d.path:
        ok = writer.append(f"- path: {d.path}")
    if ok and d.description:
        ok = writer.append(f"- description: {d.description}")
    summary = d.diff_summary or ""
    if ok and summary.strip():
        ok = writer.append("- diff:")
        if ok:
            diff_lines = summary.splitlines()
            for line in diff_lines[:APPROVALS_FULL_MAX_DIFF_LINES_DEFAULT]:
                if not writer.append(f"  {line}"):
                    ok = False
                    break
            if ok and len(diff_lines) > APPROVALS_FULL_MAX_DIFF_LINES_DEFAULT:
                ok = writer.append("  …")
    return ok


def _append_mcp_approval_details(
    writer: BoundedLineWriter,
    record: ApprovalAuditRecord,
) -> bool:
    d = record.detail
    if (
        isinstance(d.server_label, str)
        and d.server_label
        and not writer.append(f"- server: {d.server_label}")
    ):
        return False
    if (
        isinstance(d.tool_name, str)
        and d.tool_name
        and not writer.append(f"- tool: {d.tool_name}")
    ):
        return False
    args = d.arguments_json or ""
    if not args.strip():
        return True
    if not writer.append("- args:"):
        return False
    return writer.append(
        shorten_line(args, limit=APPROVALS_FULL_MAX_MCP_ARGS_CHARS_DEFAULT),
    )


def _append_compress_approval_details(
    writer: BoundedLineWriter,
    record: ApprovalAuditRecord,
) -> bool:
    d = record.detail
    action = d.compress_action or "compress"
    if not writer.append(f"- action: {action}"):
        return False
    message = d.compress_message or ""
    if message:
        return writer.append(f"- message: {message}")
    return True


def _append_approval_full_block(
    writer: BoundedLineWriter,
    record: ApprovalAuditRecord,
) -> bool:
    state = _approval_state(record)
    if not writer.append(f"[{record.family}] {record.id}"):
        return False
    if not writer.append(f"- state: {state}"):
        return False
    if record.family == "shell":
        ok = _append_shell_approval_details(writer, record)
    elif record.family == "patch":
        ok = _append_patch_approval_details(writer, record)
    elif record.family == "compress":
        ok = _append_compress_approval_details(writer, record)
    else:
        ok = _append_mcp_approval_details(writer, record)
    if not ok:
        return False
    reason = _approval_rejection_reason(record)
    if reason and not writer.append(f"- reason: {reason}"):
        return False
    return writer.append("")


def _handle_last_approvals(
    *,
    outcome: ReplActionLastArtifact,
    state: SessionState,
    emit_command: Callable[[str], None],
) -> None:
    audit = state.approvals.audit
    max_records = (
        APPROVALS_PREVIEW_MAX_RECORDS_DEFAULT
        if outcome.mode == "preview"
        else APPROVALS_FULL_MAX_RECORDS_DEFAULT
    )
    records = audit.snapshot(limit=max_records)
    if not records:
        emit_command("No approvals captured in this REPL session.")
        return

    writer = BoundedLineWriter(
        max_lines=(
            APPROVALS_PREVIEW_MAX_LINES_DEFAULT
            if outcome.mode == "preview"
            else APPROVALS_FULL_MAX_LINES_DEFAULT
        ),
        lines=[],
    )

    for rec in records:
        if outcome.mode == "preview":
            if not _append_approval_preview_line(writer, rec):
                break
            continue

        if not _append_approval_full_block(writer, rec):
            break

    writer.ensure_truncation_marker("…")
    text = _format_tool_block(
        "approvals",
        f"last: {len(records)}",
        detail_lines=writer.lines,
    )
    emit_command(text)


def _handle_last_diff(
    *,
    outcome: ReplActionLastArtifact,
    state: SessionState,
    artifacts: ReplArtifactIndex,
    emit_command: Callable[[str], None],
) -> None:
    art = artifacts.last_apply_patch_call
    if art is None:
        emit_command("No apply_patch diff captured in this REPL session.")
        return
    preview_max = state.cfg.repl.transcript.tool_detail_max_lines
    preview_lines = list(
        last_apply_patch_diff_lines(
            art,
            mode=outcome.mode,
            preview_max_lines=preview_max,
        ),
    )
    if not preview_lines:
        emit_command("(diff omitted by policy)")
        return
    emit_command(
        _format_tool_block(
            "diff",
            f"{art.op_type} {art.path}",
            detail_lines=preview_lines,
        ),
    )


def _handle_last_tool_events(
    *,
    outcome: ReplActionLastArtifact,
    artifacts: ReplArtifactIndex,
    emit_command: Callable[[str], None],
) -> None:
    last_call = artifacts.last_tool_call
    last_out = artifacts.last_tool_output
    if last_call is None and last_out is None:
        emit_command("No tool events captured in this REPL session.")
        return

    if last_call is not None:
        emit_command(
            _format_tool_block(
                "tool call",
                f"last: {last_call.label}",
                detail_lines=(last_call.detail_lines if outcome.mode == "full" else ()),
            ),
        )

    if last_out is not None:
        emit_command(
            _format_tool_block(
                "tool output",
                f"last: {last_out.label}",
                success=True,
                detail_lines=(last_out.detail_lines if outcome.mode == "full" else ()),
            ),
        )


def handle_last_artifact(
    *,
    outcome: ReplActionLastArtifact,
    state: SessionState,
    artifacts: ReplArtifactIndex,
    emit_command: Callable[[str], None],
) -> bool:
    """Render the last diff or tool artifacts into the REPL transcript."""
    if outcome.kind == "diff":
        _handle_last_diff(
            outcome=outcome,
            state=state,
            artifacts=artifacts,
            emit_command=emit_command,
        )
        return True
    if outcome.kind == "approvals":
        _handle_last_approvals(
            outcome=outcome,
            state=state,
            emit_command=emit_command,
        )
        return True

    _handle_last_tool_events(
        outcome=outcome,
        artifacts=artifacts,
        emit_command=emit_command,
    )
    return True


def _format_tool_block(
    event_type: str,
    label: str,
    *,
    detail_lines: Sequence[str] | None = None,
    success: bool | None = None,
) -> str:
    suffix = ""
    if success is True:
        suffix = " (ok)"
    elif success is False:
        suffix = " (fail)"
    header = f"[{event_type}] {label}{suffix}"
    lines = [header]
    if detail_lines:
        lines.extend(detail_lines)
    return "\n".join(lines)


__all__ = ("handle_last_artifact",)
