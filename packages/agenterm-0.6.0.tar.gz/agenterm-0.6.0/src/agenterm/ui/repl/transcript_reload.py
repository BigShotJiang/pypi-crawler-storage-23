"""REPL transcript reload helpers for session/branch switches."""

from __future__ import annotations

import sqlite3
from typing import TYPE_CHECKING

from agents.exceptions import AgentsException

from agenterm.core.errors import ConfigError, DatabaseError
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.service import session_store
from agenterm.ui.transcript.policy import transcript_policy_for_state
from agenterm.ui.transcript.rehydrate import rehydrate_transcript_items

if TYPE_CHECKING:
    from agenterm.ui.repl.loop import ReplLoop


async def reload_repl_transcript(
    loop: ReplLoop,
    *,
    branch_id: str | None = None,
) -> bool:
    """Replace the REPL transcript with stored history for the active branch."""
    session = loop.mem_session
    if not isinstance(session, AgentermSQLiteSession):
        return False
    session_sql: AgentermSQLiteSession = session
    target_branch = branch_id or loop.state.branch_id or session_sql.current_branch_id
    if not target_branch:
        return False
    try:
        items = await session_sql.get_items(branch_id=target_branch, limit=None)
    except (AgentsException, sqlite3.Error, OSError, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to reload transcript: {exc}")
        return False
    policy = transcript_policy_for_state(loop.state)
    try:
        result = await rehydrate_transcript_items(
            items,
            policy=policy,
            store=session_store(),
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to reload transcript: {exc}")
        return False
    loop.ui_store.replace_transcript(result.entries)
    loop.artifacts.clear()
    for build in result.builds:
        loop.artifacts.on_transcript_build(build)
    loop.tui.invalidate()
    return True


__all__ = ("reload_repl_transcript",)
