"""REPL action handler for the route-first `/model` picker modal."""

from __future__ import annotations

from typing import TYPE_CHECKING, Final

from agenterm.app.services.model_registry import (
    refresh_gateway_route_registry,
    refresh_model_registry,
    validate_model_id_with_registry,
)
from agenterm.config.editors import set_model as set_model_editor
from agenterm.core.errors import (
    ConfigError,
    DatabaseError,
    FilesystemError,
    ValidationError,
)
from agenterm.store.session.service import session_store, update_session_model
from agenterm.ui.repl.model_picker_builders import (
    ROUTE_ACTION_PREFIX,
    build_model_picker_items,
    build_route_picker_items,
)

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplActionModelPicker
    from agenterm.ui.repl.loop import ReplLoop


_MSG_ROUTE_INVALID: Final[str] = (
    "Invalid route. Use: openai | openrouter | ollama | gateway/<route>."
)


def _normalize_route_token(loop: ReplLoop, raw: str | None) -> str | None:
    route_key = (raw or "").strip().strip("/").lower()
    if not route_key:
        return None
    routes = loop.state.cfg.providers.gateway.routes
    if route_key == "openai":
        return "openai"
    if route_key.startswith("gateway/"):
        _, _, tail = route_key.partition("/")
        if tail and "/" not in tail and tail in routes:
            return tail
        return None
    return route_key if route_key in routes else None


def _route_action_value(selected_value: str | None) -> str | None:
    value = (selected_value or "").strip()
    if not value.startswith(ROUTE_ACTION_PREFIX):
        return None
    route = value.removeprefix(ROUTE_ACTION_PREFIX).strip().lower()
    return route or None


async def _apply_model(loop: ReplLoop, *, model_id: str) -> None:
    new_cfg = set_model_editor(loop.state.cfg, model_id)
    loop.state = loop.state.with_cfg(new_cfg)
    if isinstance(loop.state.session_id, str) and loop.state.session_id:
        try:
            await update_session_model(
                store=session_store(),
                session_id=loop.state.session_id,
                model=model_id,
            )
        except (FilesystemError, DatabaseError) as exc:
            loop.emit_command(
                f"Model set: {model_id} (/status to confirm). warn: {exc}",
            )
            return
    loop.emit_command(f"Model set: {model_id} (/status to confirm)")


async def _select_route(loop: ReplLoop) -> str | None:
    title, items = build_route_picker_items(loop.state)
    selected = await loop.tui.pick_model(title=title, items=items)
    if selected is None:
        return None
    if selected.kind != "action":
        loop.emit_command("Model route picker: select a route.")
        return None
    return _route_action_value(selected.value)


async def _select_model(loop: ReplLoop, *, route: str) -> str | None:
    try:
        title, items = await build_model_picker_items(loop.state, route=route)
    except ConfigError as exc:
        loop.emit_command(f"Model catalog error: {exc}")
        return None
    selected = await loop.tui.pick_model(title=title, items=items)
    if selected is None:
        return None
    if selected.kind != "model" or selected.value is None:
        loop.emit_command("Model picker: select a model.")
        return None
    return selected.value


async def _warm_route_catalog(loop: ReplLoop, *, route: str) -> None:
    store = session_store()
    if route == "openai":
        try:
            await refresh_model_registry(store=store)
        except ConfigError as exc:
            loop.emit_command(
                f"OpenAI catalog unavailable; showing suggestions only. {exc}",
            )
        return
    route_cfg = loop.state.cfg.providers.gateway.routes.get(route)
    if route_cfg is None:
        return
    try:
        await refresh_gateway_route_registry(
            store=store,
            route=route,
            route_cfg=route_cfg,
        )
    except (ConfigError, ValidationError) as exc:
        loop.emit_command(
            f"{route} catalog unavailable; showing suggestions only. {exc}",
        )


async def handle_model_picker_action(
    loop: ReplLoop,
    outcome: ReplActionModelPicker,
) -> bool:
    """Open the route-first model picker and apply a validated model selection."""
    route = _normalize_route_token(loop, outcome.route)
    if outcome.route is not None and route is None:
        loop.emit_command(_MSG_ROUTE_INVALID)
        return True
    if route is None:
        route = await _select_route(loop)
        if route is None:
            return True
        if _normalize_route_token(loop, route) is None:
            loop.emit_command(_MSG_ROUTE_INVALID)
            return True
    await _warm_route_catalog(loop, route=route)

    while True:
        selected_model = await _select_model(loop, route=route)
        if selected_model is None:
            return True
        if selected_model == loop.state.cfg.agent.model:
            loop.emit_command("Model unchanged.")
            return True
        try:
            model_id = await validate_model_id_with_registry(
                selected_model,
                store=session_store(),
                providers=loop.state.cfg.providers,
            )
        except (ConfigError, ValidationError) as exc:
            loop.emit_command(f"Invalid model id: {exc}")
            continue
        await _apply_model(loop, model_id=model_id)
        return True


__all__ = ("handle_model_picker_action",)
