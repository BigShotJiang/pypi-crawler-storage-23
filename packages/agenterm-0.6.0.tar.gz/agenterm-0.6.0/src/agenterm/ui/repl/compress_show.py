"""REPL rendering helpers for `/compress show`."""

from __future__ import annotations

import sqlite3
from typing import TYPE_CHECKING

from agents.exceptions import AgentsException

from agenterm.core.errors import ConfigError
from agenterm.store.branch.repo import list_branch_meta
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.service import session_store
from agenterm.ui.repl.compress_snapshot import format_compaction_snapshot_lines
from agenterm.ui.repl.snapshot_summary import format_continuation_capsule_lines

if TYPE_CHECKING:
    from collections.abc import Callable

    from agents.items import TResponseInputItem
    from agents.memory import Session

    from agenterm.store.branch.models import BranchMeta


def _require_snapshot_session(
    session: Session | None,
    *,
    emit: Callable[[str], None],
) -> tuple[AgentermSQLiteSession, str] | None:
    if session is None:
        emit("No session memory available; cannot show compression continuation.")
        return None
    if not isinstance(session, AgentermSQLiteSession):
        emit("Compression continuation inspection requires a stored session.")
        return None
    session_id = session.session_id
    if not session_id:
        emit("Compression continuation inspection requires a stored session.")
        return None
    return session, session_id


async def _load_latest_snapshot_meta(
    *,
    session_id: str,
    emit: Callable[[str], None],
) -> BranchMeta | None:
    try:
        branches = await list_branch_meta(session_store(), session_id)
    except (ConfigError, sqlite3.Error, OSError):
        emit("Failed to read branch metadata; cannot show compression continuation.")
        return None
    for row in branches:
        if row.kind in ("snapshot", "compaction"):
            return row
    emit("No compression continuation. Run /compress.")
    return None


async def _load_snapshot_items(
    *,
    session: AgentermSQLiteSession,
    branch_id: str,
    emit: Callable[[str], None],
) -> list[TResponseInputItem] | None:
    try:
        return await session.get_items(
            branch_id=branch_id,
            limit=None,
        )
    except (AgentsException, sqlite3.Error, OSError):
        emit("Failed to load continuation items; cannot show compression continuation.")
        return None


async def show_last_compression_snapshot(
    *,
    session: Session | None,
    emit: Callable[[str], None],
) -> None:
    """Emit the continuation block for the most recent compression."""
    resolved = _require_snapshot_session(session, emit=emit)
    if resolved is None:
        return
    session_sql, session_id = resolved
    snapshot_meta = await _load_latest_snapshot_meta(
        session_id=session_id,
        emit=emit,
    )
    if snapshot_meta is None:
        return
    raw_items = await _load_snapshot_items(
        session=session_sql,
        branch_id=snapshot_meta.branch_id,
        emit=emit,
    )
    if raw_items is None:
        return
    lines: list[str] | None
    if snapshot_meta.kind == "compaction":
        lines = format_compaction_snapshot_lines(raw_items)
    else:
        lines = format_continuation_capsule_lines(raw_items)
    if lines is None:
        emit("Compression continuation unavailable.")
        return
    for line in lines:
        emit(line)


__all__ = ("show_last_compression_snapshot",)
