"""Exit resume hint helpers for the REPL."""

from __future__ import annotations

from shlex import quote
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


def build_resume_command(state: SessionState) -> str | None:
    """Return a resume command for the current session, if available."""
    session_id = state.session_id
    if not isinstance(session_id, str) or not session_id:
        return None
    cmd = f"uv run agenterm repl --session {quote(session_id)}"
    cfg_path = state.config_path
    if cfg_path is not None:
        cmd = f"{cmd} --config {quote(str(cfg_path))}"
    return cmd


__all__ = ("build_resume_command",)
