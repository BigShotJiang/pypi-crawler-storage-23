"""REPL run execution helpers (bounded transcript, SessionState updates)."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

import httpx
from agents.exceptions import AgentsException, MaxTurnsExceeded
from openai import OpenAIError

from agenterm.config.paths import meta_store_path
from agenterm.core.env import has_openai_api_key
from agenterm.core.error_report import ErrorContext, build_error_report
from agenterm.core.errors import AgentermError, AuthError, ConfigError, DatabaseError
from agenterm.core.model_id import is_openai_model_id, model_plane
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.store_policy import store_is_enabled
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.service import get_session_metadata_row, session_store
from agenterm.ui.repl.compression_emitters import build_compression_emitters
from agenterm.ui.repl.run_callbacks import StreamMarkers, build_stream_callbacks
from agenterm.ui.repl.run_runner_helpers import (
    dispatch_ui_event,
    emit_error_report,
    emit_final_text,
    emit_run_image_artifacts,
    emit_transcript_text,
    finalize_attachment_state,
    prepare_input_items,
    prepare_run_display,
    resolve_session_id,
)
from agenterm.ui.transcript.blocks import ImageArtifactBlock
from agenterm.ui.tui.state import (
    TranscriptEntryAddedEvent,
    TranscriptSeparatorEntry,
    TranscriptTextEntry,
    UiEvent,
)
from agenterm.workflow.run.execute_streamed import execute_streamed_run
from agenterm.workflow.run.model import RunExecutionContext, RunRef, StreamedRunRequest

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from agents.agent import Agent
    from agents.result import RunResultStreaming

    from agenterm.core.plan import PlanSnapshot
    from agenterm.core.types import SessionState
    from agenterm.engine.mcp_pool import McpServerPool
    from agenterm.store.session.service import Session
    from agenterm.ui.repl.artifacts import ReplArtifactIndex
    from agenterm.ui.repl.phase_state import ReplPhaseState
    from agenterm.ui.transcript.blocks import TranscriptBuild
    from agenterm.ui.transcript.render import PlanSnapshotLoader
    from agenterm.workflow.run.model import RunPostprocessResult, StreamedRunResult


@dataclass(frozen=True)
class RunInputs:
    """Inputs required to execute a single REPL run."""

    state: SessionState
    agent: Agent
    prompt_text: str | None
    use_last_attachments: bool
    session: Session | None
    phase_state: ReplPhaseState | None
    run_ref: RunRef | None
    mcp_pool: McpServerPool | None
    artifact_index: ReplArtifactIndex | None
    emit_event: Callable[[UiEvent], None] | None
    ui_invalidate: Callable[[], None] | None


def _set_phase(
    phase_state: ReplPhaseState | None,
    value: str,
    ui_invalidate: Callable[[], None] | None = None,
) -> None:
    if phase_state is None:
        return
    if value in ("idle", "running", "compressing"):
        phase_state.phase = value
        if ui_invalidate is not None:
            ui_invalidate()


def _handle_missing_api_key(
    state: SessionState,
    *,
    used_last_attachments: bool,
    phase_state: ReplPhaseState | None,
    emit_event: Callable[[UiEvent], None] | None,
) -> SessionState:
    report = build_error_report(
        AuthError("OPENAI_API_KEY is not set."),
        context=ErrorContext(
            operation="repl.run",
            resource="repl.run",
            trace_id=state.cfg.run.trace_id,
            recovery_hint="Set it in your environment or use /config key.",
        ),
    )
    emit_error_report(emit_event, report)
    _set_phase(phase_state, "idle")
    return finalize_attachment_state(
        state,
        used_last=used_last_attachments,
        attachments=[],
    )


async def _execute_streamed_run_for_repl(
    run_ctx: RunExecutionContext,
    *,
    request: StreamedRunRequest,
    emit_event: Callable[[UiEvent], None] | None,
) -> StreamedRunResult | None:
    err_context = ErrorContext(
        operation="repl.run",
        resource="repl.run",
        trace_id=run_ctx.cfg.run.trace_id,
    )
    provider_label = model_plane(run_ctx.cfg.agent.model)
    try:
        return await execute_streamed_run(run_ctx, request)
    except AgentermError as exc:
        emit_error_report(
            emit_event,
            build_error_report(
                exc,
                context=err_context,
                extra_details={"provider": provider_label},
            ),
        )
        return None
    except MaxTurnsExceeded as exc:
        emit_error_report(
            emit_event,
            build_error_report(
                exc,
                context=err_context,
                extra_details={"provider": provider_label},
            ),
        )
        return None
    except AgentsException as exc:
        emit_error_report(
            emit_event,
            build_error_report(
                exc,
                context=err_context,
                extra_details={"provider": provider_label},
            ),
        )
        return None
    except (httpx.HTTPError, OpenAIError) as exc:
        emit_error_report(
            emit_event,
            build_error_report(
                exc,
                context=err_context,
                extra_details={"provider": provider_label},
            ),
        )
        return None


def _handle_missing_run_result(
    state: SessionState,
    *,
    agent: Agent,
    attachments: list[str],
    used_last_attachments: bool,
    emit_event: Callable[[UiEvent], None] | None,
) -> tuple[SessionState, Agent, None]:
    state = finalize_attachment_state(
        state,
        used_last=used_last_attachments,
        attachments=attachments,
    )
    if attachments:
        joined = ", ".join(str(a) for a in attachments)
        emit_transcript_text(emit_event, f"attachments: {joined}")
    return state, agent, None


def _update_usage_phase_state(
    phase_state: ReplPhaseState | None,
    *,
    post: RunPostprocessResult,
    ui_invalidate: Callable[[], None] | None,
) -> None:
    if phase_state is None:
        return
    totals = post.usage_total
    if totals is not None:
        phase_state.usage_total_tokens = totals.total_tokens
    phase_state.last_request_input_tokens = post.last_request_input_tokens
    phase_state.last_request_count = post.last_request_count
    if ui_invalidate is not None:
        ui_invalidate()


async def _read_head_branch(
    *,
    session_id: str,
    emit_event: Callable[[UiEvent], None] | None,
) -> str | None:
    try:
        meta = await get_session_metadata_row(session_store(), session_id)
    except (ConfigError, DatabaseError, sqlite3.Error, OSError) as exc:
        emit_transcript_text(
            emit_event,
            f"warn> Failed to read session head branch: {exc}",
        )
        return None
    if meta is None:
        return None
    head = meta.head_branch_id
    return head or None


async def _sync_head_branch(
    *,
    state: SessionState,
    session: Session | None,
    emit_event: Callable[[UiEvent], None] | None,
) -> tuple[SessionState, Session | None]:
    if session is None or not isinstance(session, AgentermSQLiteSession):
        return state, session
    session_id = resolve_session_id(state, session)
    if not session_id:
        return state, session
    head = await _read_head_branch(session_id=session_id, emit_event=emit_event)
    if head is None:
        return state, session
    if session.current_branch_id != head:
        try:
            await session.switch_to_branch(head)
        except ValueError as exc:
            emit_transcript_text(
                emit_event,
                f"warn> Failed to switch to head branch {head!r}: {exc}",
            )
            return state, session
    if head != state.branch_id:
        state = replace(
            state,
            branch_id=head,
            caches=replace(
                state.caches,
                branch_ids=tuple({*(state.caches.branch_ids or ()), head}),
            ),
        )
    return state, session


def _build_tool_context_and_plan_loader(
    *,
    db_path: Path,
    session_id: str | None,
    branch_id: str | None,
    trace_id: str | None,
    run_ref: RunRef | None,
) -> tuple[ToolRuntimeContext, PlanSnapshotLoader | None]:
    plan_cache: dict[str, PlanSnapshot] = {}
    tool_context = ToolRuntimeContext(
        db_path=db_path,
        session_id=session_id,
        branch_id=branch_id,
        run_number=None,
        trace_id=trace_id,
        plan_cache=plan_cache,
        cancel_token=run_ref.cancel_token if run_ref is not None else None,
    )
    if not isinstance(session_id, str) or not session_id:
        return tool_context, None

    def _load_snapshot(call_id: str) -> PlanSnapshot | None:
        return plan_cache.get(call_id)

    return tool_context, _load_snapshot


async def _finalize_streamed_run(
    *,
    state: SessionState,
    agent: Agent,
    run_result: StreamedRunResult | None,
    attachments: list[str],
    used_last_attachments: bool,
    markers: StreamMarkers,
    run_ref: RunRef | None,
    rendered_image_artifact_ids: set[str],
    phase_state: ReplPhaseState | None,
    emit_event: Callable[[UiEvent], None] | None,
    ui_invalidate: Callable[[], None] | None,
) -> tuple[SessionState, Agent, RunResultStreaming | None]:
    if run_result is None:
        state, agent, _ = _handle_missing_run_result(
            state,
            agent=agent,
            attachments=attachments,
            used_last_attachments=used_last_attachments,
            emit_event=emit_event,
        )
        return state, agent, None

    streaming = run_result.streaming
    agent = run_result.last_agent
    suppress_output = bool(run_ref is not None and run_ref.suppress_output)

    emit_final_text(
        emit_event,
        stream_mode=state.ui.stream_mode,
        saw_text_delta=markers.saw_text_delta,
        final_text=run_result.final_text,
        suppress_output=suppress_output,
    )

    if not suppress_output:
        await emit_run_image_artifacts(
            items=[item.to_input_item() for item in streaming.new_items],
            rendered_artifact_ids=rendered_image_artifact_ids,
            emit_event=emit_event,
        )

    new_branch_id = run_result.post.branch_id
    if (
        isinstance(new_branch_id, str)
        and new_branch_id
        and new_branch_id != state.branch_id
    ):
        state = replace(
            state,
            branch_id=new_branch_id,
            caches=replace(
                state.caches,
                branch_ids=tuple({*(state.caches.branch_ids or ()), new_branch_id}),
            ),
        )

    _update_usage_phase_state(
        phase_state,
        post=run_result.post,
        ui_invalidate=ui_invalidate,
    )

    state = finalize_attachment_state(
        state,
        used_last=used_last_attachments,
        attachments=attachments,
    )
    return state, agent, streaming


async def run_repl_run(
    ctx: RunInputs,
) -> tuple[SessionState, Agent, RunResultStreaming | None]:
    """Execute a single agent run and print outputs."""
    state = ctx.state
    agent = ctx.agent
    prompt_text = ctx.prompt_text
    use_last_attachments = ctx.use_last_attachments
    session = ctx.session
    phase_state = ctx.phase_state
    run_ref = ctx.run_ref
    mcp_pool = ctx.mcp_pool
    emit_event = ctx.emit_event
    state, session = await _sync_head_branch(
        state=state,
        session=session,
        emit_event=emit_event,
    )
    session_id = resolve_session_id(state, session)
    db_path = meta_store_path()

    def _emit_entry(entry: TranscriptTextEntry | TranscriptSeparatorEntry) -> None:
        dispatch_ui_event(
            emit_event,
            TranscriptEntryAddedEvent(entry=entry),
        )

    policy = await prepare_run_display(
        state=state,
        session_id=session_id,
        branch_id=state.branch_id,
        use_last_attachments=use_last_attachments,
        emit_entry=_emit_entry,
    )

    if is_openai_model_id(state.cfg.agent.model) and not has_openai_api_key():
        state_out = _handle_missing_api_key(
            state,
            used_last_attachments=use_last_attachments,
            phase_state=phase_state,
            emit_event=emit_event,
        )
        return state_out, agent, None

    atts, input_items = await prepare_input_items(
        state,
        prompt_text,
        use_last_attachments=use_last_attachments,
    )

    store_flag = state.cfg.model.store
    store_enabled = store_is_enabled(store=store_flag)
    markers = StreamMarkers()
    rendered_image_artifact_ids: set[str] = set()
    tool_context, plan_snapshot_loader = _build_tool_context_and_plan_loader(
        db_path=db_path,
        session_id=session_id,
        branch_id=state.branch_id,
        trace_id=state.cfg.run.trace_id,
        run_ref=run_ref,
    )

    def _sink(build: TranscriptBuild) -> None:
        if isinstance(build.block, ImageArtifactBlock):
            rendered_image_artifact_ids.add(build.block.artifact_id)
        if ctx.artifact_index is not None:
            ctx.artifact_index.on_transcript_build(build)

    callbacks = build_stream_callbacks(
        state,
        policy=policy,
        markers=markers,
        sink=_sink,
        plan_snapshot_loader=plan_snapshot_loader,
        emit_event=(emit_event or (lambda _evt: None)),
        phase_state=phase_state,
    )

    def _emit_line(msg: str) -> None:
        if run_ref is not None and run_ref.suppress_output:
            return
        emit_transcript_text(emit_event, msg)

    compression_emitters = build_compression_emitters(_emit_line)
    run_ctx = RunExecutionContext(
        cfg=state.cfg,
        agent=agent,
        session=session,
        session_id=session_id,
        branch_id=state.branch_id,
        store_enabled=store_enabled,
        interactive=True,
        workflow_name="agenterm repl",
        approvals=state.approvals,
        mcp_pool=mcp_pool,
        tool_context=tool_context,
        compression_emitters=compression_emitters,
    )

    try:
        run_result = await _execute_streamed_run_for_repl(
            run_ctx,
            request=StreamedRunRequest(
                input_items=input_items,
                callbacks=callbacks,
                stream_mode=state.ui.stream_mode,
                retry_policy=state.cfg.retries.provider,
                run_ref=run_ref,
                postprocess_emit_line=_emit_line,
                retry_emit_line=_emit_line,
            ),
            emit_event=emit_event,
        )
    finally:
        _set_phase(phase_state, "idle", ctx.ui_invalidate)

    return await _finalize_streamed_run(
        state=state,
        agent=agent,
        run_result=run_result,
        attachments=atts,
        used_last_attachments=use_last_attachments,
        markers=markers,
        run_ref=run_ref,
        rendered_image_artifact_ids=rendered_image_artifact_ids,
        phase_state=phase_state,
        emit_event=emit_event,
        ui_invalidate=ctx.ui_invalidate,
    )


__all__ = ("RunInputs", "run_repl_run")
