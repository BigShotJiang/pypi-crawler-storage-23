"""Rendering helpers for compaction snapshot continuation blocks."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.repl.compress_snapshot_collect import (
    collect_citations,
    collect_file_groups,
    collect_image_groups,
    collect_part_counts,
    collect_role_counts,
)
from agenterm.ui.repl.compress_snapshot_json import json_str
from agenterm.ui.repl.compress_snapshot_parts import summarize_message
from agenterm.ui.repl.compress_snapshot_redact import MAX_GROUP_ITEMS, redact_blob

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.ui.repl.compress_snapshot_types import CitationGroups, SnapshotSlice


def render_kv_counts(label: str, counts: Mapping[str, int]) -> str:
    if not counts:
        return f"- {label}: none"
    parts = " ".join(f"{key}={counts[key]}" for key in sorted(counts))
    return f"- {label}: {parts}"


def render_flat_groups(title: str, groups: Mapping[str, int]) -> list[str]:
    if not groups:
        return []
    keys = sorted(groups)[: (MAX_GROUP_ITEMS or None)]
    lines = [title, *[f"- {key} (n={groups[key]})" for key in keys]]
    extra = len(groups) - len(keys)
    if extra > 0:
        lines.append(f"- … ({extra} more)")
    return lines


def render_container_citations(groups: Mapping[str, Mapping[str, int]]) -> list[str]:
    if not groups:
        return []
    lines: list[str] = ["- container_file_citation:"]
    containers = sorted(groups)[: (MAX_GROUP_ITEMS or None)]
    for container_id in containers:
        lines.append(f"  - container_id={container_id}:")
        by_file = groups[container_id]
        file_ids = sorted(by_file)[: (MAX_GROUP_ITEMS or None)]
        lines.extend([f"    - file_id={fid} (n={by_file[fid]})" for fid in file_ids])
        extra_files = len(by_file) - len(file_ids)
        if extra_files > 0:
            lines.append(f"    - … ({extra_files} more files)")
    extra_containers = len(groups) - len(containers)
    if extra_containers > 0:
        lines.append(f"  - … ({extra_containers} more containers)")
    return lines


def render_citations(groups: CitationGroups) -> list[str]:
    if not groups.any():
        return []
    lines: list[str] = ["Citations:"]
    lines.extend(render_container_citations(groups.container_file))
    lines.extend(render_flat_groups("- file_citation:", groups.file_citation))
    lines.extend(render_flat_groups("- file_path:", groups.file_path))
    lines.extend(render_flat_groups("- url_citation:", groups.url_citation))
    return lines


def format_header(compaction_id: str | None) -> str:
    header = "compress> continuation (compaction"
    if compaction_id is not None:
        header += f" id={compaction_id}"
    header += ")"
    return header


def format_snapshot_lines(snapshot_slice: SnapshotSlice) -> list[str]:
    """Render a snapshot slice into the continuation text block."""
    compaction_id = json_str(snapshot_slice.compaction_item.get("id"))
    encrypted = json_str(snapshot_slice.compaction_item.get("encrypted_content")) or ""
    header = format_header(compaction_id)

    role_counts = collect_role_counts(snapshot_slice.snapshot)
    part_counts = collect_part_counts(snapshot_slice.snapshot)
    file_groups = collect_file_groups(snapshot_slice.snapshot)
    image_groups = collect_image_groups(snapshot_slice.snapshot)
    citations = collect_citations(snapshot_slice.snapshot)

    lines: list[str] = [
        header,
        f"- snapshot_items: {len(snapshot_slice.snapshot)}",
        f"- compaction.encrypted_content: {redact_blob(encrypted)}",
        render_kv_counts("roles", role_counts),
        render_kv_counts("parts", part_counts),
    ]
    grouped: list[str] = []
    grouped.extend(render_flat_groups("Files:", file_groups))
    grouped.extend(render_flat_groups("Images:", image_groups))
    grouped.extend(render_citations(citations))
    if grouped:
        lines.append("")
        lines.extend(grouped)

    lines.append("")
    lines.append("Messages:")
    msg_idx = 0
    for item in snapshot_slice.snapshot:
        if item.get("type") != "message":
            continue
        msg_idx += 1
        lines.extend(summarize_message(item, idx=msg_idx))
    if msg_idx == 0:
        lines.append("(no messages in snapshot)")
    return lines


__all__ = ("format_snapshot_lines",)
