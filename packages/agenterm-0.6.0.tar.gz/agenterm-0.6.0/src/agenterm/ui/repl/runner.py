"""REPL entrypoint.

This module exports `run_repl`, the interactive prompt_toolkit-driven REPL loop
used by the CLI entrypoint.

The bulk of the orchestration lives in `agenterm.ui.repl.loop` so this file stays
small and stable: it is the import surface for `agenterm.ui.repl`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.cli_renderer_base import render_text_block
from agenterm.ui.cli_settings import set_cli_output_surface
from agenterm.ui.repl.exit_hint import build_resume_command
from agenterm.ui.repl.loop import ReplLoop
from agenterm.ui.tui.splash import run_splash

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


async def run_repl(
    state: SessionState,
    *,
    attach_session_id: str | None = None,
    store_override: bool | None = None,
) -> None:
    """Run the interactive REPL.

    This is the CLI-facing entrypoint for the prompt_toolkit REPL. It blocks
    until the user exits (EOF / Ctrl+D).

    Side effects:

    - Reads user input from stdin.
    - Writes rendered output to stdout.
    - May create or attach to a persisted session (SQLite) depending on the
      supplied `SessionState` and `attach_session_id`.
    - Starts model runs as background tasks and integrates results into the
      in-memory `SessionState` before accepting the next prompt.
    """
    set_cli_output_surface("repl")

    # Splash screen before REPL initialization
    await run_splash(color_depth=state.ui.color_depth)

    loop = await ReplLoop.create(
        state,
        attach_session_id=attach_session_id,
        store_override=store_override,
    )
    await loop.run()
    cmd = build_resume_command(loop.state)
    if cmd is not None:
        render_text_block(f"agenterm exit. Resume with: {cmd}")


__all__ = ("run_repl",)
