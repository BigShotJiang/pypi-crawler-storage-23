"""Internal typed models for compaction snapshot rendering."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONMapping, JSONValue


@dataclass(frozen=True)
class SnapshotSlice:
    """Snapshot slice up to the most recent compaction item."""

    snapshot: list[JSONMapping]
    compaction_item: Mapping[str, JSONValue]


@dataclass(frozen=True)
class CitationGroups:
    """Grouped citation summary for output_text annotations."""

    container_file: Mapping[str, Mapping[str, int]]
    file_citation: Mapping[str, int]
    file_path: Mapping[str, int]
    url_citation: Mapping[str, int]

    def any(self) -> bool:
        """Return True when at least one citation group has entries."""
        if self.container_file:
            return True
        if self.file_citation:
            return True
        if self.file_path:
            return True
        return bool(self.url_citation)


__all__ = ("CitationGroups", "SnapshotSlice")
