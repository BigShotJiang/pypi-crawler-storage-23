"""Canonical REPL action dispatcher surface."""

from agenterm.ui.repl.actions.dispatch import handle_action
from agenterm.ui.repl.actions.replay import replay_decision_for_run

__all__ = ("handle_action", "replay_decision_for_run")
