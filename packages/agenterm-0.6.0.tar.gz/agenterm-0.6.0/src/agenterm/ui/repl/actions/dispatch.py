"""Top-level REPL action dispatcher."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.actions import (
    ReplAction,
    ReplActionAttachSession,
    ReplActionCompress,
    ReplActionCompressShow,
    ReplActionContinue,
    ReplActionEditLast,
    ReplActionErrors,
    ReplActionExit,
    ReplActionLastArtifact,
    ReplActionModelPicker,
    ReplActionNewSession,
    ReplActionSendAgain,
    ReplActionSendPrompt,
    ReplActionSessionRuns,
)
from agenterm.ui.repl.actions.diagnostics import (
    handle_errors_action,
    handle_last_artifact_action,
)
from agenterm.ui.repl.actions.replay import handle_edit_last, handle_send_again
from agenterm.ui.repl.actions.send import handle_continue, handle_send_prompt
from agenterm.ui.repl.actions.session import (
    handle_attach_session,
    handle_new_session,
    handle_session_runs,
)
from agenterm.ui.repl.branch_actions import handle_branch_action
from agenterm.ui.repl.compress_handlers import handle_compression_action
from agenterm.ui.repl.model_picker_action import handle_model_picker_action

if TYPE_CHECKING:
    from agenterm.ui.repl.loop import ReplLoop


async def _handle_primary_action(
    loop: ReplLoop,
    outcome: ReplAction,
) -> bool | None:
    result: bool | None = None
    if isinstance(outcome, ReplActionExit):
        result = False
    elif isinstance(outcome, ReplActionSendAgain):
        result = await handle_send_again(loop)
    elif isinstance(outcome, ReplActionSendPrompt):
        result = await handle_send_prompt(loop, outcome)
    elif isinstance(outcome, ReplActionContinue):
        result = await handle_continue(loop, outcome)
    elif isinstance(outcome, ReplActionEditLast):
        result = await handle_edit_last(loop)
    elif isinstance(outcome, ReplActionNewSession):
        result = await handle_new_session(loop, outcome)
    elif isinstance(outcome, ReplActionAttachSession):
        result = await handle_attach_session(loop, outcome)
    elif isinstance(outcome, ReplActionSessionRuns):
        result = await handle_session_runs(loop, outcome)
    return result


async def _handle_secondary_action(
    loop: ReplLoop,
    outcome: ReplAction,
) -> bool | None:
    if isinstance(outcome, (ReplActionCompress, ReplActionCompressShow)):
        return await handle_compression_action(loop, outcome)
    if isinstance(outcome, ReplActionLastArtifact):
        return handle_last_artifact_action(loop, outcome)
    if isinstance(outcome, ReplActionErrors):
        return handle_errors_action(loop)
    if isinstance(outcome, ReplActionModelPicker):
        return await handle_model_picker_action(loop, outcome)
    return None


async def handle_action(loop: ReplLoop, outcome: ReplAction) -> bool:
    """Apply an action outcome to the live REPL loop."""
    result = await _handle_primary_action(loop, outcome)
    if result is not None:
        return result
    result = await _handle_secondary_action(loop, outcome)
    if result is not None:
        return result
    branch_result = await handle_branch_action(loop, outcome)
    if branch_result is not None:
        return branch_result
    return True


__all__ = ("handle_action",)
