"""Prompt/run start handlers for REPL action dispatch."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplActionContinue, ReplActionSendPrompt
    from agenterm.ui.repl.loop import ReplLoop


async def handle_send_prompt(loop: ReplLoop, outcome: ReplActionSendPrompt) -> bool:
    """Handle explicit prompt send actions."""
    if loop.run_running():
        loop.emit_command("Run running; wait before /continue.")
        return True
    prompt = (outcome.prompt or "").strip()
    if not prompt:
        loop.emit_command("Nothing to send.")
        return True
    loop.emit_user(prompt)
    loop.start_run(
        prompt,
        use_last=bool(outcome.use_last),
        record_prompt=bool(outcome.record_prompt),
    )
    return True


async def handle_continue(loop: ReplLoop, outcome: ReplActionContinue) -> bool:
    """Handle `/continue` run start with no new user input."""
    if loop.run_running():
        loop.emit_command("Run running; wait before /continue.")
        return True
    loop.emit_command("Continuing from the last coherent state (no new user input).")
    loop.start_resume_run(use_last=bool(outcome.use_last))
    return True


__all__ = ("handle_continue", "handle_send_prompt")
