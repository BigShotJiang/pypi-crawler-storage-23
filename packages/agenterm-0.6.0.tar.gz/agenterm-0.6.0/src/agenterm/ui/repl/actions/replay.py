"""Replay/fork handlers for `/again` and `/edit`."""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from typing import TYPE_CHECKING, Literal

from agenterm.core.error_report import build_error_report
from agenterm.core.errors import ConfigError, DatabaseError
from agenterm.core.hashing import sha256_text_or_none
from agenterm.store.branch.service import create_branch_from_run
from agenterm.store.runs import list_runs
from agenterm.store.session.service import session_store
from agenterm.ui.repl.branch_state import (
    apply_branch_meta,
    branch_error_context,
    refresh_branch_cache,
    refresh_usage_totals,
    require_session,
)
from agenterm.ui.repl.transcript_reload import reload_repl_transcript

if TYPE_CHECKING:
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.branch.models import BranchMeta
    from agenterm.store.runs.models import RunStatusRecord
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession
    from agenterm.ui.repl.loop import ReplLoop


type ReplayDecision = Literal["none", "in_place", "fork"]


def replay_decision_for_run(run: RunStatusRecord | None) -> ReplayDecision:
    """Decide replay strategy for /again or /edit based on the last run."""
    if run is None:
        return "none"
    if run.branch_turn_start is None:
        return "in_place"
    return "fork"


async def create_replay_branch(
    loop: ReplLoop,
    *,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    last_run: RunStatusRecord,
    operation: str,
) -> BranchMeta | None:
    """Create a replay branch from the selected run number."""
    try:
        return await create_branch_from_run(
            session=session,
            store=store,
            session_id=session_id,
            run_number=last_run.run_number,
            branch_id=None,
            agent_name=loop.state.cfg.agent.name,
            agent_path=loop.state.cfg.agent.path,
            agent_sha256=sha256_text_or_none(loop.state.cfg.agent.instructions),
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        report = build_error_report(
            DatabaseError(str(exc)) if isinstance(exc, sqlite3.Error) else exc,
            context=branch_error_context(loop.state, operation),
        )
        loop.emit(report)
    return None


async def fork_from_last_run(loop: ReplLoop, *, operation: str) -> bool:
    """Fork from the last run when replay policy requires a branch."""
    session = require_session(loop)
    if session is None:
        return False
    session_id = (
        loop.state.session_id if isinstance(loop.state.session_id, str) else None
    )
    if session_id is None:
        loop.emit_command("Replay requires a stored session.")
        return False

    store = session_store()
    branch_id = loop.state.branch_id or "main"
    meta = None
    try:
        runs = await list_runs(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            limit=1,
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        report = build_error_report(
            DatabaseError(str(exc)) if isinstance(exc, sqlite3.Error) else exc,
            context=branch_error_context(loop.state, operation),
        )
        loop.emit(report)
    else:
        last_run = runs[0] if runs else None
        decision = replay_decision_for_run(last_run)
        if decision == "none":
            loop.emit_command("No previous run to replay.")
        elif decision == "in_place":
            loop.emit_command("Last run has no turn range; retrying in place.")
            return True
        elif decision == "fork" and last_run is not None:
            meta = await create_replay_branch(
                loop,
                session=session,
                store=store,
                session_id=session_id,
                last_run=last_run,
                operation=operation,
            )

    if meta is None:
        return False

    loop.phase_state.phase = "idle"
    loop.phase_state.reset_usage()
    loop.artifacts.clear()
    loop.state = apply_branch_meta(loop.state, meta)
    try:
        branch_cache = await refresh_branch_cache(
            session_id=session_id,
            store=store,
        )
        loop.state = replace(
            loop.state,
            caches=replace(loop.state.caches, branch_ids=branch_cache),
        )
    except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to refresh branches: {exc}")
    await refresh_usage_totals(
        loop=loop,
        store=store,
        session_id=session_id,
        branch_id=meta.branch_id,
    )
    await reload_repl_transcript(loop, branch_id=meta.branch_id)
    loop.tui.invalidate()
    return True


async def handle_send_again(loop: ReplLoop) -> bool:
    """Handle `/again` replay flow."""
    if loop.run_running():
        loop.emit_command("Run running; wait before /again.")
        return True
    prompt = loop.state.prompt.last_user_prompt or ""
    if not prompt:
        loop.emit_command("Nothing to send again.")
        return True
    if not await fork_from_last_run(loop, operation="repl.again"):
        return True
    loop.emit_user(prompt)
    loop.start_run(prompt, use_last=True)
    return True


async def handle_edit_last(loop: ReplLoop) -> bool:
    """Handle `/edit` replay flow."""
    if loop.run_running():
        loop.emit_command("Run running; wait before /edit.")
        return True
    prompt = loop.state.prompt.last_user_prompt or ""
    if not prompt:
        loop.emit_command("Nothing to edit.")
        return True
    if not await fork_from_last_run(loop, operation="repl.edit"):
        return True
    loop.state = loop.state.with_next_send_use_last(on=True)
    loop.tui.set_buffer_text(prompt)
    return True


__all__ = ("handle_edit_last", "handle_send_again", "replay_decision_for_run")
