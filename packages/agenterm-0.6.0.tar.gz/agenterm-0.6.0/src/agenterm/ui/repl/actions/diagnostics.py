"""Diagnostic REPL action handlers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.repl.last_artifacts import handle_last_artifact

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplActionLastArtifact
    from agenterm.ui.repl.loop import ReplLoop


def handle_last_artifact_action(
    loop: ReplLoop, outcome: ReplActionLastArtifact
) -> bool:
    """Handle `/last` artifact lookups."""
    return handle_last_artifact(
        outcome=outcome,
        state=loop.state,
        artifacts=loop.artifacts,
        emit_command=loop.emit_command,
    )


def handle_errors_action(loop: ReplLoop) -> bool:
    """Handle `/errors` stderr capture output."""
    snapshot = loop.error_sink.snapshot()
    if snapshot.total <= 0:
        loop.emit_command("No stderr errors captured.")
        return True
    shown = len(snapshot.lines)
    suffix = f"; dropped={snapshot.dropped}" if snapshot.dropped > 0 else ""
    loop.emit_command(f"Errors (showing {shown} of {snapshot.total}{suffix})")
    loop.emit_error_lines(list(snapshot.lines))
    return True


__all__ = ("handle_errors_action", "handle_last_artifact_action")
