"""Compression action handlers for the REPL loop."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.commands.actions import (
    ReplActionCompress,
    ReplActionCompressShow,
)
from agenterm.core.error_report import ErrorReport
from agenterm.ui.repl.compress_action import run_manual_compression
from agenterm.ui.repl.compress_show import show_last_compression_snapshot
from agenterm.ui.repl.transcript_reload import reload_repl_transcript

if TYPE_CHECKING:
    from agenterm.ui.repl.loop import ReplLoop


async def _handle_compress(loop: ReplLoop, outcome: ReplActionCompress) -> bool:
    if outcome.notice:
        loop.emit_command(outcome.notice)
    prev_branch = loop.state.branch_id
    cancel_token = loop.begin_action_cancel_scope()
    try:
        loop.state, msg = await run_manual_compression(
            state=loop.state,
            phase_state=loop.phase_state,
            session=loop.mem_session,
            ui_invalidate=loop.tui.invalidate,
            cancel_token=cancel_token,
            emit_line=loop.emit_command,
        )
    finally:
        loop.clear_action_cancel_scope()
    if loop.state.branch_id != prev_branch:
        await reload_repl_transcript(loop, branch_id=loop.state.branch_id)
    if isinstance(msg, ErrorReport):
        loop.emit(msg)
    else:
        loop.emit_command(msg)
    return True


async def _handle_compress_show(
    loop: ReplLoop, _outcome: ReplActionCompressShow
) -> bool:
    lines: list[str] = []

    def _collect(line: str) -> None:
        lines.append(line)

    await show_last_compression_snapshot(session=loop.mem_session, emit=_collect)
    if lines:
        loop.emit_command_lines(lines)
    return True


async def handle_compression_action(
    loop: ReplLoop,
    outcome: ReplActionCompress | ReplActionCompressShow,
) -> bool:
    """Handle compression actions for `/compress` and `/compress show`."""
    if isinstance(outcome, ReplActionCompressShow):
        return await _handle_compress_show(loop, outcome)
    return await _handle_compress(loop, outcome)


__all__ = ("handle_compression_action",)
