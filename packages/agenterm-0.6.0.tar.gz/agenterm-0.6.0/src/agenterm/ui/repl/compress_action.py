"""REPL action handler: `/compress`."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.core.error_report import ErrorContext, ErrorReport, build_error_report
from agenterm.core.errors import (
    AgentermError,
    ConfigError,
    DatabaseError,
    OperationCancelledError,
)
from agenterm.steward.tasks import run_compress_policy
from agenterm.store.runs import rebind_run_artifacts
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.service import session_store, session_usage_totals
from agenterm.ui.repl.compression_emitters import build_compression_emitters
from agenterm.workflow.run.status import (
    start_compression_status,
    update_run_status_record,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.types import SessionState
    from agenterm.steward.task_runtime import StewardTaskResult
    from agenterm.store.runs.models import RunStatus
    from agenterm.store.session.service import Session
    from agenterm.ui.repl.phase_state import ReplPhaseState
    from agenterm.workflow.run.status import RunStatusHandle


def _warn(warnings: list[str], msg: str, exc: Exception) -> None:
    warnings.append(f"warn> {msg}: {exc}")


async def _compression_preflight(
    state: SessionState,
    session: Session | None,
) -> tuple[AgentermSQLiteSession, str] | str:
    if session is None:
        return "No session memory available; cannot apply compression."
    if not isinstance(session, AgentermSQLiteSession):
        return "Compression requires an SQLite-backed session."
    session_id = state.session_id
    if not isinstance(session_id, str):
        return "Compression requires a stored session."
    history = await session.get_items()
    if not history:
        return "Nothing to compress (no session history items)."
    return session, session_id


def _format_message_with_warnings(message: str, warnings: list[str]) -> str:
    if not warnings:
        return message
    return "\n".join([message, *warnings])


def _compression_error_report(
    *,
    state: SessionState,
    exc: AgentermError,
) -> ErrorReport:
    return build_error_report(
        exc,
        context=ErrorContext(
            operation="repl.compress",
            resource="repl.compress",
            trace_id=state.cfg.run.trace_id,
        ),
    )


async def _update_status_or_warn(
    *,
    run_handle: RunStatusHandle | None,
    status: RunStatus,
    response_id: str | None,
    error_json: Mapping[str, JSONValue] | None,
    warnings: list[str],
    warning_message: str,
) -> None:
    if run_handle is None:
        return
    try:
        await update_run_status_record(
            run_handle,
            status=status,
            response_id=response_id,
            error_json=error_json,
            branch_turn_start=None,
            branch_turn_end=None,
        )
    except AgentermError as exc:
        _warn(warnings, warning_message, exc)


async def _run_compression_with_status(
    *,
    state: SessionState,
    session_sql: AgentermSQLiteSession,
    session_id: str,
    origin_branch_id: str,
    cancel_token: CancelToken | None,
    emit_line: Callable[[str], None] | None,
    warnings: list[str],
) -> tuple[RunStatusHandle | None, StewardTaskResult | None, ErrorReport | None, bool]:
    run_handle: RunStatusHandle | None = None
    try:
        run_handle = await start_compression_status(
            session_id=session_id,
            branch_id=origin_branch_id,
            trace_enabled=bool(state.cfg.run.trace_enabled),
            trace_id=state.cfg.run.trace_id,
            group_id=state.cfg.run.group_id,
            trace_metadata=state.cfg.run.trace_metadata,
        )
        emitters = build_compression_emitters(emit_line)
        result = await run_compress_policy(
            cfg=state.cfg,
            session=session_sql,
            store=session_store(),
            session_id=session_id,
            branch_id=origin_branch_id,
            trigger="manual",
            turn_range=None,
            emitters=emitters,
            run_number=run_handle.run_number,
            origin_branch_id=origin_branch_id,
            cancel_token=cancel_token,
        )
    except OperationCancelledError:
        await _update_status_or_warn(
            run_handle=run_handle,
            status="cancelled",
            response_id=None,
            error_json=None,
            warnings=warnings,
            warning_message="Failed to persist cancelled compression status",
        )
        return run_handle, None, None, True
    except AgentermError as exc:
        report = _compression_error_report(state=state, exc=exc)
        await _update_status_or_warn(
            run_handle=run_handle,
            status="failed",
            response_id=None,
            error_json=report.to_envelope().to_json(),
            warnings=warnings,
            warning_message="Failed to persist failed compression status",
        )
        return run_handle, None, report, False
    return run_handle, result, None, False


async def _finalize_success(
    *,
    state: SessionState,
    phase_state: ReplPhaseState,
    session_id: str,
    origin_branch_id: str,
    result: StewardTaskResult,
    run_handle: RunStatusHandle,
    warnings: list[str],
) -> tuple[SessionState, str]:
    await _update_status_or_warn(
        run_handle=run_handle,
        status="completed",
        response_id=result.task.response_id,
        error_json=None,
        warnings=warnings,
        warning_message="Failed to persist completed compression status",
    )
    store = session_store()
    branch_meta = result.branch_meta
    try:
        await rebind_run_artifacts(
            store=run_handle.store,
            session_id=session_id,
            from_branch_id=origin_branch_id,
            to_branch_id=branch_meta.branch_id,
            run_number=run_handle.run_number,
        )
    except (ConfigError, OSError, DatabaseError) as exc:
        _warn(warnings, "Failed to rebind compression run artifacts", exc)
    new_state = replace(
        state,
        branch_id=branch_meta.branch_id,
        prompt=replace(state.prompt, last_user_prompt=None),
        caches=replace(
            state.caches,
            branch_ids=tuple({*(state.caches.branch_ids or ()), branch_meta.branch_id}),
        ),
    )
    try:
        totals = await session_usage_totals(
            store=store,
            session_id=session_id,
            branch_id=branch_meta.branch_id,
        )
        phase_state.usage_total_tokens = (
            totals.total_tokens if totals is not None else None
        )
    except (ConfigError, OSError, DatabaseError) as exc:
        _warn(warnings, "Failed to read usage totals", exc)
    msg = (
        "Compression complete. Continuation active "
        f"(kind={branch_meta.kind}, branch={branch_meta.branch_id}, "
        f"response_id={result.task.response_id})."
    )
    return new_state, _format_message_with_warnings(msg, warnings)


async def run_manual_compression(
    *,
    state: SessionState,
    phase_state: ReplPhaseState,
    session: Session | None,
    ui_invalidate: Callable[[], None] | None = None,
    cancel_token: CancelToken | None = None,
    emit_line: Callable[[str], None] | None = None,
) -> tuple[SessionState, str | ErrorReport]:
    """Run a manual compression and return (updated_state, user_message)."""
    preflight = await _compression_preflight(state, session)
    if isinstance(preflight, str):
        return state, preflight
    session_sql, session_id = preflight
    warnings: list[str] = []
    phase_state.phase = "compressing"
    if ui_invalidate is not None:
        ui_invalidate()
    origin_branch_id = session_sql.current_branch_id
    try:
        run_handle, result, report, cancelled = await _run_compression_with_status(
            state=state,
            session_sql=session_sql,
            session_id=session_id,
            origin_branch_id=origin_branch_id,
            cancel_token=cancel_token,
            emit_line=emit_line,
            warnings=warnings,
        )
    finally:
        phase_state.phase = "idle"
        if ui_invalidate is not None:
            ui_invalidate()
    if cancelled:
        return state, _format_message_with_warnings("Compression cancelled.", warnings)
    if report is not None:
        return state, report
    if run_handle is None or result is None:
        internal_error = ConfigError("Compression did not return a status handle.")
        return state, _compression_error_report(state=state, exc=internal_error)
    return await _finalize_success(
        state=state,
        phase_state=phase_state,
        session_id=session_id,
        origin_branch_id=origin_branch_id,
        result=result,
        run_handle=run_handle,
        warnings=warnings,
    )


__all__ = ("run_manual_compression",)
