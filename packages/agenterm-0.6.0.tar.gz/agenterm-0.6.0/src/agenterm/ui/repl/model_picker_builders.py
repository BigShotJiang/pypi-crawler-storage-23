"""Builders for route-first `/model` picker modal flows."""

from __future__ import annotations

import os
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Final

from agenterm.app.services.model_registry import load_model_catalog
from agenterm.store.session.service import session_store
from agenterm.ui.tui.model_picker import ModelPickerItem

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.config.model import GatewayRouteConfig
    from agenterm.core.types import SessionState


ROUTE_ACTION_PREFIX: Final[str] = "route:"


def _header(label: str) -> ModelPickerItem:
    return ModelPickerItem(kind="header", label=label, enabled=False)


def _action_item(*, label: str, value: str) -> ModelPickerItem:
    return ModelPickerItem(kind="action", label=label, value=value, enabled=True)


def _model_item(
    model_id: str,
    *,
    current: str,
    enabled: bool,
    suffix: str | None = None,
) -> ModelPickerItem:
    label = model_id
    if model_id == current:
        label = f"{label} (current)"
    if suffix is not None:
        label = f"{label} {suffix}"
    return ModelPickerItem(kind="model", label=label, value=model_id, enabled=enabled)


def _gateway_routes_in_display_order(
    routes: Mapping[str, GatewayRouteConfig],
) -> list[str]:
    preferred = ("openrouter", "ollama")
    seen: set[str] = set()
    ordered: list[str] = []
    for route in preferred:
        if route in routes and route not in seen:
            seen.add(route)
            ordered.append(route)
    for route in sorted(routes.keys()):
        if route in seen:
            continue
        seen.add(route)
        ordered.append(route)
    return ordered


def _format_fetched(ts: int) -> str:
    return datetime.fromtimestamp(ts, UTC).isoformat()


def _current_route(state: SessionState) -> str | None:
    model_id = state.cfg.agent.model
    if model_id.startswith("openai/"):
        return "openai"
    if not model_id.startswith("gateway/"):
        return None
    _, _, rest = model_id.partition("/")
    route, _, _ = rest.partition("/")
    return route or None


def build_route_picker_items(
    state: SessionState,
) -> tuple[str, list[ModelPickerItem]]:
    """Build the first-step route selection picker items."""
    routes = state.cfg.providers.gateway.routes
    current_route = _current_route(state)
    items: list[ModelPickerItem] = []
    items.append(_header(f"Current: {state.cfg.agent.model}"))
    items.append(_header(""))
    items.append(_header("Select route"))

    openai_note = (
        "OPENAI_API_KEY set"
        if os.environ.get("OPENAI_API_KEY")
        else "OPENAI_API_KEY missing"
    )
    openai_label = f"openai (direct Responses API, {openai_note})"
    if current_route == "openai":
        openai_label = f"{openai_label} (current route)"
    items.append(
        _action_item(label=openai_label, value=f"{ROUTE_ACTION_PREFIX}openai"),
    )

    for route in _gateway_routes_in_display_order(routes):
        cfg = routes[route]
        if cfg.api_key_env is None:
            key_note = "no API key required"
        else:
            key_state = "set" if os.environ.get(cfg.api_key_env) else "missing"
            key_note = f"{cfg.api_key_env} {key_state}"
        label = f"{route} (gateway, {key_note})"
        if current_route == route:
            label = f"{label} (current route)"
        items.append(
            _action_item(label=label, value=f"{ROUTE_ACTION_PREFIX}{route}"),
        )
    return "Model route picker", items


def _is_allowed_gateway_model(
    model_id: str,
    *,
    route: str,
    route_cfg: GatewayRouteConfig,
) -> bool:
    if route_cfg.allow_any_model:
        return True
    prefix = f"gateway/{route}/"
    if not model_id.startswith(prefix):
        return False
    model = model_id[len(prefix) :]
    return model in route_cfg.model_allowlist


def _is_allowed_openai_model(
    model_id: str,
    *,
    allow_any_model: bool,
    model_allowlist: tuple[str, ...],
) -> bool:
    if allow_any_model:
        return True
    prefix = "openai/"
    if not model_id.startswith(prefix):
        return False
    model = model_id[len(prefix) :]
    return model in model_allowlist


def _openai_suggested_model_ids(state: SessionState) -> list[str]:
    return [f"openai/{model}" for model in state.cfg.providers.openai.model_suggestions]


def _gateway_suggested_model_ids(
    *,
    route: str,
    route_cfg: GatewayRouteConfig,
) -> list[str]:
    return [f"gateway/{route}/{model}" for model in route_cfg.model_suggestions]


def _unique_ids(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        out.append(item)
    return out


def _model_status(
    *,
    model_id: str,
    route: str,
    is_openai: bool,
    route_cfg: GatewayRouteConfig | None,
    openai_allow_any_model: bool,
    openai_model_allowlist: tuple[str, ...],
) -> tuple[bool, str | None]:
    if is_openai:
        enabled = _is_allowed_openai_model(
            model_id,
            allow_any_model=openai_allow_any_model,
            model_allowlist=openai_model_allowlist,
        )
        return enabled, None if enabled else "(not allowed)"
    if route_cfg is None:
        return False, "(route unavailable)"
    enabled = _is_allowed_gateway_model(
        model_id,
        route=route,
        route_cfg=route_cfg,
    )
    return enabled, None if enabled else "(not allowed)"


def _append_model_rows(
    items: list[ModelPickerItem],
    *,
    model_ids: list[str],
    skip: set[str],
    current: str,
    route: str,
    is_openai: bool,
    route_cfg: GatewayRouteConfig | None,
    openai_allow_any_model: bool,
    openai_model_allowlist: tuple[str, ...],
) -> None:
    for model_id in model_ids:
        if model_id in skip:
            continue
        enabled, suffix = _model_status(
            model_id=model_id,
            route=route,
            is_openai=is_openai,
            route_cfg=route_cfg,
            openai_allow_any_model=openai_allow_any_model,
            openai_model_allowlist=openai_model_allowlist,
        )
        items.append(
            _model_item(
                model_id,
                current=current,
                enabled=enabled,
                suffix=suffix,
            ),
        )


def _route_tip(
    *,
    route: str,
    is_openai: bool,
    route_cfg: GatewayRouteConfig | None,
    openai_allow_any_model: bool,
) -> str:
    if is_openai:
        if openai_allow_any_model:
            return "Tip: `/model gpt-5.2` sets `openai/gpt-5.2`."
        return "Tip: OpenAI allowlist policy is enforced for this route."
    if route_cfg is None:
        return f"Tip: set models directly with `gateway/{route}/<model>`."
    if route_cfg.allow_any_model:
        return f"Tip: any `gateway/{route}/<model>` id is allowed."
    return "Tip: route allowlist is enforced for this route."


async def build_model_picker_items(
    state: SessionState,
    *,
    route: str,
) -> tuple[str, list[ModelPickerItem]]:
    """Build the second-step model picker for one route."""
    current = state.cfg.agent.model
    is_openai = route == "openai"
    openai_cfg = state.cfg.providers.openai
    gateway_cfg = state.cfg.providers.gateway.routes.get(route)
    if not is_openai and gateway_cfg is None:
        return (
            f"Model picker: {route}",
            [_header(f"Unknown route: {route}")],
        )

    if is_openai:
        suggested_ids = _openai_suggested_model_ids(state)
    else:
        if gateway_cfg is None:
            return f"Model picker: {route}", [_header(f"Unknown route: {route}")]
        suggested_ids = _gateway_suggested_model_ids(route=route, route_cfg=gateway_cfg)
    suggested_ids = _unique_ids(suggested_ids)
    suggested_set = set(suggested_ids)

    store = session_store()
    catalog = await load_model_catalog(store=store)
    catalog_key = "openai" if is_openai else f"gateway/{route}"
    registry = catalog.registry(catalog_key) if catalog is not None else None
    discovered = registry.list_models() if registry is not None else []

    items: list[ModelPickerItem] = []
    items.append(_header(f"Current: {current}"))
    items.append(_header(""))
    items.append(_header(f"Recommended ({len(suggested_ids)})"))
    _append_model_rows(
        items,
        model_ids=suggested_ids,
        skip=set(),
        current=current,
        route=route,
        is_openai=is_openai,
        route_cfg=gateway_cfg,
        openai_allow_any_model=openai_cfg.allow_any_model,
        openai_model_allowlist=openai_cfg.model_allowlist,
    )

    items.append(_header(""))
    if registry is None:
        items.append(_header("Discovered models: (no cached catalog)"))
    else:
        fetched = _format_fetched(registry.fetched_at)
        items.append(
            _header(f"Discovered models ({len(discovered)}), cached {fetched}"),
        )
        _append_model_rows(
            items,
            model_ids=discovered,
            skip=suggested_set,
            current=current,
            route=route,
            is_openai=is_openai,
            route_cfg=gateway_cfg,
            openai_allow_any_model=openai_cfg.allow_any_model,
            openai_model_allowlist=openai_cfg.model_allowlist,
        )
        if not discovered:
            items.append(_header("(none cached)"))

    items.append(_header(""))
    items.append(
        _header(
            _route_tip(
                route=route,
                is_openai=is_openai,
                route_cfg=gateway_cfg,
                openai_allow_any_model=openai_cfg.allow_any_model,
            )
        ),
    )

    title = f"Model picker: {route}"
    return title, items


__all__ = (
    "ROUTE_ACTION_PREFIX",
    "build_model_picker_items",
    "build_route_picker_items",
)
