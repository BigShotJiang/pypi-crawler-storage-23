"""Compression continuation rendering for compaction (`/compress show`)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.response_items import serialize_input_item
from agenterm.ui.repl.compress_snapshot_render import format_snapshot_lines
from agenterm.ui.repl.compress_snapshot_types import SnapshotSlice

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.items import TResponseInputItem

    from agenterm.core.json_types import JSONValue


def _to_json_object(item: TResponseInputItem) -> dict[str, JSONValue] | None:
    try:
        return serialize_input_item(item, context="compress_snapshot.item")
    except ConfigError:
        return None


def _find_last_compaction_snapshot(
    items: list[dict[str, JSONValue]],
) -> SnapshotSlice | None:
    for idx in range(len(items) - 1, -1, -1):
        if items[idx].get("type") == "compaction":
            return SnapshotSlice(
                snapshot=list(items[: idx + 1]),
                compaction_item=items[idx],
            )
    return None


def format_compaction_snapshot_lines(
    raw_items: Sequence[TResponseInputItem],
) -> list[str] | None:
    """Return continuation lines for a compaction snapshot payload."""
    items: list[dict[str, JSONValue]] = []
    for raw in raw_items:
        obj = _to_json_object(raw)
        if obj is not None:
            items.append(obj)
    snapshot_slice = _find_last_compaction_snapshot(items)
    if snapshot_slice is None:
        return None
    return format_snapshot_lines(snapshot_slice)


def format_last_compaction_snapshot_lines(
    raw_items: Sequence[TResponseInputItem],
) -> list[str] | None:
    """Return continuation lines for the most recent compaction snapshot."""
    return format_compaction_snapshot_lines(raw_items)


__all__ = (
    "format_compaction_snapshot_lines",
    "format_last_compaction_snapshot_lines",
)
