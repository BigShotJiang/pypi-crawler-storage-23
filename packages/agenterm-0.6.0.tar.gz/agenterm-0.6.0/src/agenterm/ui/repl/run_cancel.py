"""Cancellation controller for REPL runs."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from agenterm.constants.limits import RUN_FORCE_CANCEL_PERSIST_TIMEOUT_SECONDS
from agenterm.core.store_policy import store_is_enabled
from agenterm.workflow.run.force_cancel import force_cancel_run
from agenterm.workflow.run.postprocess import postprocess_cancelled_run

if TYPE_CHECKING:
    from agents.agent import Agent
    from agents.result import RunResultStreaming

    from agenterm.core.types import SessionState
    from agenterm.ui.repl.loop import ReplLoop
    from agenterm.workflow.run.model import RunRef

    RunTask = asyncio.Task[tuple[SessionState, Agent, RunResultStreaming | None]]


class RunCancelController:
    """Coordinate cancellation requests for the active REPL run."""

    _CANCEL_FORCE_SECONDS = 3.0
    _CANCEL_FORCE_JOIN_SECONDS = 1.0

    def __init__(self, loop: ReplLoop) -> None:
        """Bind the controller to a live REPL loop."""
        self._loop = loop
        self._cancel_watchdog: asyncio.Task[None] | None = None

    def request_cancel(self) -> None:
        """Request cancellation for the active run or long-running action."""
        run_ref = self._loop.current_run_ref
        run_task = self._loop.current_run
        if run_task is not None and run_task.done():
            self._loop.schedule_integrate_completed_run()
            return
        if run_ref is None:
            if not self._loop.cancel_action_scope():
                return
            self._loop.phase_state.clear_notice()
            self._loop.tui.invalidate()
            self._loop.emit_command("Cancel requested.")
            return
        if run_ref.cancel_reason is not None:
            self._loop.phase_state.set_notice(
                "Cancellation in progress.",
                level="warn",
            )
            self._loop.tui.invalidate()
            return
        run_ref.request_cancel(mode="immediate", suppress_output=True, reason="user")
        self._loop.phase_state.clear_notice()
        self._loop.tui.invalidate()
        self._loop.emit_command("Cancel requested.")
        self._schedule_force_cancel()

    def clear_watchdog(self) -> None:
        """Cancel any force-cancel watchdog task."""
        if self._cancel_watchdog is None:
            return
        self._cancel_watchdog.cancel()
        self._cancel_watchdog = None

    async def handle_cancelled_run(self) -> None:
        """Persist cancellation artifacts and notify the user."""
        run_ref = self._loop.current_run_ref
        if run_ref is None or run_ref.cancel_reason is None:
            return
        store_flag = self._loop.state.cfg.model.store
        await postprocess_cancelled_run(
            session_id=self._loop.state.session_id,
            branch_id=self._loop.state.branch_id,
            store_enabled=store_is_enabled(store=store_flag),
            run_number=None,
            emit_line=self._loop.emit,
        )
        self._loop.emit_command("Run cancelled.")

    async def _await_force_cancelled_task(self, run_task: RunTask) -> bool:
        run_task.cancel()
        completed = False
        try:
            async with asyncio.timeout(self._CANCEL_FORCE_JOIN_SECONDS):
                await run_task
            completed = True
        except TimeoutError:
            completed = False
        except asyncio.CancelledError:
            completed = True
        return completed

    async def _persist_forced_cancel(self, run_ref: RunRef | None) -> None:
        persist_timeout = RUN_FORCE_CANCEL_PERSIST_TIMEOUT_SECONDS
        try:
            async with asyncio.timeout(persist_timeout):
                await force_cancel_run(
                    run_ref=run_ref,
                    emit_line=self._loop.emit_command,
                )
        except TimeoutError:
            self._loop.emit_command("warn> Forced cancellation persistence timed out.")

    async def _finalize_forced_cancel(self) -> None:
        persist_timeout = RUN_FORCE_CANCEL_PERSIST_TIMEOUT_SECONDS
        try:
            async with asyncio.timeout(persist_timeout):
                await self.handle_cancelled_run()
        except TimeoutError:
            self._loop.emit_command("warn> Cancellation postprocess timed out.")
        self._abandon_run_state()

    def _abandon_run_state(self) -> None:
        self._loop.current_run = None
        self._loop.current_run_ref = None
        self._loop.phase_state.phase = "idle"
        self._loop.phase_state.clear_notice()
        self._loop.phase_state.clear_event_hint()
        self._loop.tui.stop_animation()
        self._loop.tui.invalidate()

    def _schedule_force_cancel(self) -> None:
        if self._loop.current_run is None or self._loop.current_run.done():
            return
        if self._cancel_watchdog is not None and not self._cancel_watchdog.done():
            return

        async def _force() -> None:
            try:
                await asyncio.sleep(self._CANCEL_FORCE_SECONDS)
                run_task = self._loop.current_run
                if run_task is None or run_task.done():
                    return
                self._loop.emit_command("Force cancelling stalled run.")
                run_ref = self._loop.current_run_ref
                if run_ref is not None:
                    run_ref.request_cancel(
                        mode="immediate",
                        suppress_output=True,
                        reason="user",
                    )
                if await self._await_force_cancelled_task(run_task):
                    return
                await self._persist_forced_cancel(run_ref)
                await self._finalize_forced_cancel()
            finally:
                self._cancel_watchdog = None

        self._cancel_watchdog = asyncio.create_task(_force())


__all__ = ("RunCancelController",)
