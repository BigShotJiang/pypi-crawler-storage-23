"""Mutable REPL phase and usage state for TUI rendering.

The REPL loop owns a single instance of `ReplPhaseState` and mutates it as the
current run progresses (running → compressing → idle) and as usage summaries are
computed.

This keeps prompt-toolkit render callables side-effect free: they only read from
`SessionState`, approvals managers, and this small phase state object.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from agenterm.ui.tui.event_hints import event_type_to_hint

type ReplPhase = Literal["idle", "running", "compressing"]
type ReplHudLevel = Literal["info", "warn"]


@dataclass(slots=True)
class ReplPhaseState:
    """Live REPL phase + usage counters for the REPL HUD."""

    phase: ReplPhase = "idle"
    hud_notice: str = ""
    hud_notice_level: ReplHudLevel = "info"
    usage_total_tokens: int | None = None
    last_request_input_tokens: int | None = None
    last_request_count: int | None = None
    last_event_hint: str = ""
    error_count: int = 0
    error_truncated: bool = False

    def clear_notice(self) -> None:
        """Clear the current HUD notice (if any)."""
        self.hud_notice = ""
        self.hud_notice_level = "info"

    def set_notice(self, text: str, *, level: ReplHudLevel = "info") -> None:
        """Set a HUD notice shown in the placeholder area."""
        self.hud_notice = text.strip()
        self.hud_notice_level = level

    def reset_usage(self) -> None:
        """Clear usage totals (used when starting a fresh session)."""
        self.usage_total_tokens = None
        self.last_request_input_tokens = None
        self.last_request_count = None

    def set_event_hint(self, event_type: str) -> None:
        """Convert SSE event type to display hint and store.

        Args:
            event_type: Full event type, e.g., "response.output_text.delta"

        """
        self.last_event_hint = event_type_to_hint(event_type)

    def clear_event_hint(self) -> None:
        """Clear the event hint when run completes."""
        self.last_event_hint = ""

    def set_error_state(self, *, count: int, truncated: bool) -> None:
        """Update the stderr error count and truncated flag."""
        self.error_count = max(0, count)
        self.error_truncated = truncated


__all__ = ("ReplHudLevel", "ReplPhase", "ReplPhaseState")
