"""Branch-related state helpers for the REPL."""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.config.agent_files import resolve_agent
from agenterm.config.editors import set_agent, set_model_store
from agenterm.core.error_report import ErrorContext
from agenterm.core.errors import ConfigError, DatabaseError
from agenterm.core.text import display_role
from agenterm.store.branch.repo import list_branch_meta
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.service import session_usage_totals

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agenterm.core.types import SessionState
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.branch.models import BranchMeta
    from agenterm.store.branch.summary import BranchSummary
    from agenterm.store.session.last_message import LastMessageSnippet
    from agenterm.ui.repl.loop import ReplLoop


def _maybe_apply_agent_from_meta(
    state: SessionState,
    name: str | None,
) -> SessionState:
    if not name:
        return state
    try:
        resolved = resolve_agent(name=name, explicit=False)
    except ConfigError:
        return state
    cfg = set_agent(
        state.cfg,
        name=resolved.name,
        instructions=resolved.text,
        path=resolved.source.path,
        source=resolved.source.location,
        explicit=resolved.source.explicit,
    )
    return state.with_cfg(cfg)


def apply_branch_meta(
    state: SessionState,
    branch_meta: BranchMeta,
) -> SessionState:
    """Apply branch metadata to the REPL session state."""
    cfg = set_model_store(state.cfg, store=branch_meta.store_enabled)
    state = state.with_cfg(cfg)
    state = _maybe_apply_agent_from_meta(state, branch_meta.agent_name)
    return replace(
        state,
        branch_id=branch_meta.branch_id,
        prompt=replace(state.prompt, last_user_prompt=None),
    )


def require_session(loop: ReplLoop) -> AgentermSQLiteSession | None:
    """Return the active SQLite session or emit a warning."""
    session = loop.mem_session
    if not isinstance(session, AgentermSQLiteSession):
        loop.emit_command("Branch operations require a stored session.")
        return None
    return session


def branch_error_context(state: SessionState, operation: str) -> ErrorContext:
    """Build a branch-scoped error context for reports."""
    return ErrorContext(
        operation=operation,
        resource=operation,
        trace_id=state.cfg.run.trace_id,
    )


async def refresh_branch_cache(
    *,
    session_id: str,
    store: AsyncStore,
) -> tuple[str, ...]:
    """Refresh the cached branch id list from metadata."""
    rows = await list_branch_meta(store, session_id)
    seen: dict[str, None] = {}
    for row in rows:
        seen.setdefault(row.branch_id, None)
    return tuple(seen.keys())


async def refresh_usage_totals(
    *,
    loop: ReplLoop,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> None:
    """Refresh usage totals for the active branch."""
    try:
        totals = await session_usage_totals(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
        )
    except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to read usage totals: {exc}")
        return
    loop.phase_state.usage_total_tokens = (
        totals.total_tokens if totals is not None else None
    )


def _branch_store_label(meta: BranchMeta | None) -> str:
    if meta is None:
        return "-"
    return "on" if meta.store_enabled else "off"


def _branch_last_message(last_message: LastMessageSnippet | None) -> str:
    if last_message is None:
        return "-"
    role_label = display_role(last_message.role) or last_message.role
    return f"{role_label}: {last_message.snippet}"


def _branch_line(
    *,
    summary: BranchSummary,
    meta: BranchMeta | None,
    last_message: LastMessageSnippet | None,
) -> str:
    marker = "*" if summary.is_current else " "
    kind = meta.kind if meta is not None else "-"
    agent = meta.agent_name if meta is not None else "-"
    user_turns = summary.user_turns
    message_count = summary.message_count
    store_label = _branch_store_label(meta)
    last = _branch_last_message(last_message)
    return (
        f"{marker} {summary.branch_id}  kind={kind}  user_turns={user_turns}  "
        f"messages={message_count}  store={store_label}  last={last}  "
        f"agent={agent}"
    )


def build_branch_list_lines(
    *,
    session_id: str,
    branches: Sequence[BranchSummary],
    meta_rows: Sequence[BranchMeta],
    last_messages: Mapping[str, LastMessageSnippet] | None = None,
) -> tuple[list[str], tuple[str, ...]]:
    """Build lines and branch id cache from list_branches output."""
    meta_map = {row.branch_id: row for row in meta_rows}
    last_messages = last_messages or {}
    lines: list[str] = [f"Branches ({session_id}):"]
    branch_ids: dict[str, None] = {}
    for summary in branches:
        branch_ids.setdefault(summary.branch_id, None)
        lines.append(
            _branch_line(
                summary=summary,
                meta=meta_map.get(summary.branch_id),
                last_message=last_messages.get(summary.branch_id),
            )
        )
    if len(lines) == 1:
        lines.append("No branches found.")
    for row in meta_rows:
        branch_ids.setdefault(row.branch_id, None)
    return lines, tuple(branch_ids.keys())


__all__ = (
    "apply_branch_meta",
    "branch_error_context",
    "build_branch_list_lines",
    "refresh_branch_cache",
    "refresh_usage_totals",
    "require_session",
)
