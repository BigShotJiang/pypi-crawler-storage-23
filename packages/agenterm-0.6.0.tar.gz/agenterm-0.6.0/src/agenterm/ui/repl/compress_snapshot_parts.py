"""Message-part summarization for compaction snapshot rendering."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.repl.compress_snapshot_json import json_dict, json_list, json_str
from agenterm.ui.repl.compress_snapshot_redact import redact_blob, redact_text

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


def message_header(msg: Mapping[str, JSONValue], *, idx: int) -> str:
    role = json_str(msg.get("role")) or "unknown"
    status = json_str(msg.get("status"))
    header = f"- [{idx}] {role}/message"
    if role == "assistant" and status is not None:
        header += f" (status={status})"
    return header


def message_parts(msg: Mapping[str, JSONValue]) -> list[dict[str, JSONValue]]:
    """Extract message content parts as JSON objects."""
    parts_raw = json_list(msg.get("content"))
    if parts_raw is None:
        return []
    out: list[dict[str, JSONValue]] = []
    for raw in parts_raw:
        part = json_dict(raw)
        if part is not None:
            out.append(part)
    return out


def summarize_text_part(
    part: Mapping[str, JSONValue],
    *,
    kind: str,
) -> list[str]:
    text = json_str(part.get("text")) or ""
    snippet_lines, total_len = redact_text(text)
    ann_count = 0
    if kind == "output_text":
        anns = json_list(part.get("annotations"))
        ann_count = len(anns) if anns is not None else 0

    meta = f"  - {kind} (len={total_len}"
    if kind == "output_text":
        meta += f", annotations={ann_count}"
    meta += "):"
    return [meta, *[f"      {line}" if line else "      " for line in snippet_lines]]


def summarize_refusal_part(part: Mapping[str, JSONValue]) -> list[str]:
    refusal = json_str(part.get("refusal")) or ""
    snippet_lines, total_len = redact_text(refusal)
    return [
        f"  - refusal (len={total_len}):",
        *[f"      {line}" if line else "      " for line in snippet_lines],
    ]


def summarize_input_image_part(part: Mapping[str, JSONValue]) -> list[str]:
    detail = json_str(part.get("detail")) or "auto"
    file_id = json_str(part.get("file_id"))
    image_url = json_str(part.get("image_url"))
    label = f"  - input_image (detail={detail})"
    if file_id is not None:
        label += f" file_id={file_id}"
    if image_url is not None:
        label += (
            f" image_url={redact_blob(image_url)}"
            if image_url.startswith("data:")
            else f" image_url={image_url}"
        )
    return [label]


def summarize_input_file_part(part: Mapping[str, JSONValue]) -> list[str]:
    file_id = json_str(part.get("file_id"))
    file_url = json_str(part.get("file_url"))
    filename = json_str(part.get("filename"))
    file_data = json_str(part.get("file_data"))
    label = "  - input_file"
    if filename is not None:
        label += f" filename={filename}"
    if file_id is not None:
        label += f" file_id={file_id}"
    if file_url is not None:
        label += f" file_url={file_url}"
    if file_data is not None:
        label += f" file_data={redact_blob(file_data)}"
    return [label]


def summarize_unknown_part(part_type: str) -> list[str]:
    return [f"  - {part_type}"]


def summarize_message(msg: Mapping[str, JSONValue], *, idx: int) -> list[str]:
    """Render one message and its content parts into display lines."""
    lines: list[str] = [message_header(msg, idx=idx)]
    parts = message_parts(msg)
    if not parts:
        return [*lines, "  (no content)"]
    for part in parts:
        part_type = json_str(part.get("type")) or "unknown"
        if part_type == "input_text":
            lines.extend(summarize_text_part(part, kind="input_text"))
            continue
        if part_type == "output_text":
            lines.extend(summarize_text_part(part, kind="output_text"))
            continue
        if part_type == "refusal":
            lines.extend(summarize_refusal_part(part))
            continue
        if part_type == "input_image":
            lines.extend(summarize_input_image_part(part))
            continue
        if part_type == "input_file":
            lines.extend(summarize_input_file_part(part))
            continue
        lines.extend(summarize_unknown_part(part_type))
    return lines


__all__ = ("message_parts", "summarize_message")
