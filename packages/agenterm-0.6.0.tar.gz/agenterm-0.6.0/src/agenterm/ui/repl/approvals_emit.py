"""Approval transcript emission helpers for the REPL."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.approvals import (
    CompressionApprovalItem,
    McpApprovalItem,
    PatchApprovalItem,
    ShellApprovalItem,
)
from agenterm.ui.transcript.approvals import (
    build_compress_approval_block,
    build_mcp_approval_block,
    build_patch_approval_block,
    build_shell_approval_block,
)
from agenterm.ui.transcript.policy import transcript_policy_for_state
from agenterm.ui.tui.state import TranscriptEntryAddedEvent

if TYPE_CHECKING:
    from agenterm.app.services.approvals import ApprovalFamily
    from agenterm.core.approvals_audit import ApprovalDecision
    from agenterm.core.types import SessionState
    from agenterm.ui.repl.phase_state import ReplPhaseState
    from agenterm.ui.tui.app import ReplTui
    from agenterm.ui.tui.state import UiStore


def emit_approval_event(
    *,
    state: SessionState,
    store: UiStore,
    phase_state: ReplPhaseState,
    tui: ReplTui,
    family: ApprovalFamily,
    item: (
        ShellApprovalItem
        | PatchApprovalItem
        | McpApprovalItem
        | CompressionApprovalItem
    ),
    decision: ApprovalDecision | None,
) -> None:
    """Render an approval event and refresh the approvals UI state."""
    policy = transcript_policy_for_state(state)
    if family == "shell":
        if not isinstance(item, ShellApprovalItem):
            return
        block = build_shell_approval_block(
            item,
            decision=decision,
            policy=policy,
        )
    elif family == "patch":
        if not isinstance(item, PatchApprovalItem):
            return
        block = build_patch_approval_block(
            item,
            decision=decision,
            policy=policy,
        )
    elif family == "compress":
        if not isinstance(item, CompressionApprovalItem):
            return
        block = build_compress_approval_block(
            item,
            decision=decision,
            policy=policy,
        )
    else:
        if not isinstance(item, McpApprovalItem):
            return
        block = build_mcp_approval_block(
            item,
            decision=decision,
            policy=policy,
        )
    store.dispatch(TranscriptEntryAddedEvent(entry=block))
    tui.sync_approvals_modal()
    if not (
        state.approvals.compress.pending()
        or state.approvals.shell.pending()
        or state.approvals.patch.pending()
        or state.approvals.mcp.pending()
    ):
        phase_state.clear_notice()
        tui.invalidate()


__all__ = ("emit_approval_event",)
