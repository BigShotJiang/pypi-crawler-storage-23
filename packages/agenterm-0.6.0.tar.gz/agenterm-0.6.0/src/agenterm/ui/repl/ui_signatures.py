"""UI signature helpers for REPL state comparisons."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.types import SessionState


def prompt_ui_sig(state: SessionState) -> tuple[str, str, str, bool, str]:
    """Build the prompt UI signature used to detect display-affecting changes."""
    return (
        state.ui.theme,
        state.ui.color_depth,
        state.ui.editing_mode,
        bool(state.ui.mouse),
        state.ui.completion,
    )
