"""Prompt-toolkit completers for slash commands and free-form input."""

from __future__ import annotations

# Completers for slash-commands.
# Command completer is aware of top-level/subcommand structure and the current
# SessionState (for context-aware completions such as /tools).
from typing import TYPE_CHECKING, override

from prompt_toolkit.completion import Completer, Completion

from agenterm.commands.router import (
    subcommand_candidates,
    top_level_candidates,
    top_level_summaries,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable

    from prompt_toolkit.completion import CompleteEvent
    from prompt_toolkit.document import Document

    from agenterm.core.types import SessionState


class CommandCompleter(Completer):
    """Slash-command completer with simple prefix matching."""

    def __init__(self, state_supplier: Callable[[], SessionState | None]) -> None:
        """Initialize with a supplier for the current SessionState.

        The supplier is called on each completion to keep suggestions in sync
        with the live REPL session (e.g. tools bundles and keys).
        """
        self._state: Callable[[], SessionState | None] = state_supplier

    @override
    def get_completions(
        self,
        document: Document,
        complete_event: CompleteEvent,
    ) -> Iterable[Completion]:
        """Yield completions for slash-prefixed input."""
        text = document.current_line_before_cursor
        stripped = text.lstrip()
        if not stripped:
            return
        if not stripped.startswith("/"):
            return
        if " " not in stripped:
            yield from _top_level_completions(prefix=stripped)
            return
        first_space = stripped.find(" ")
        cmd = stripped[:first_space]
        last_space = stripped.rfind(" ")
        current_prefix = stripped[last_space + 1 :] if last_space >= 0 else ""
        replace_from = -len(current_prefix)
        rest = stripped[first_space + 1 :]
        state = self._state()
        prev_token: str | None = None
        if current_prefix == "" and stripped.endswith(" "):
            tokens = stripped.split()
            if tokens:
                prev_token = tokens[-1]
        for c in subcommand_candidates(cmd, rest, state):
            if prev_token is not None and c.strip() == prev_token:
                continue
            if c.startswith(current_prefix) and c != current_prefix:
                yield Completion(c, start_position=replace_from, display=c)


class NullCompleter(Completer):
    """Completer that always yields no suggestions."""

    @override
    def get_completions(
        self,
        document: Document,
        complete_event: CompleteEvent,
    ) -> Iterable[Completion]:
        """Yield no completions."""
        _ = (document, complete_event)
        return ()


def _top_level_completions(prefix: str) -> Iterable[Completion]:
    summaries = top_level_summaries()
    replace_from = -len(prefix)
    return [
        Completion(
            c,
            start_position=replace_from,
            display=c,
            display_meta=summaries.get(c.strip()),
        )
        for c in top_level_candidates()
        if c.startswith(prefix)
    ]


__all__ = (
    "CommandCompleter",
    "NullCompleter",
)
