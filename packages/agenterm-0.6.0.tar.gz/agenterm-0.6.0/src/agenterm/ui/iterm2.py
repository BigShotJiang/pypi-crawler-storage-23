"""Terminal feature helpers (iTerm2-focused).

This module powers "legendary" artifact UX in the REPL by using terminal-native
features when available (iTerm2 inline images, OSC-8 hyperlinks).
"""

from __future__ import annotations

import base64
import os
from typing import TYPE_CHECKING

from agenterm.core.errors import FilesystemError

if TYPE_CHECKING:
    from pathlib import Path

_ESC = "\033"
_BEL = "\a"
_OSC_MAX_CHARS = 1_048_576


def _split_b64_payload(payload: str, *, max_chars: int) -> list[str]:
    if max_chars <= 0:
        return [payload] if payload else []
    return [payload[i : i + max_chars] for i in range(0, len(payload), max_chars)]


def is_iterm2() -> bool:
    """Return True when running inside iTerm2."""
    return os.environ.get("TERM_PROGRAM") == "iTerm.app" or bool(
        os.environ.get("ITERM_SESSION_ID"),
    )


def osc8_link(text: str, url: str) -> str:
    """Return an OSC-8 hyperlink escape sequence."""
    if not text:
        return ""
    if not url:
        return text
    return f"{_ESC}]8;;{url}{_BEL}{text}{_ESC}]8;;{_BEL}"


def file_url(path: Path) -> str:
    """Return a file:// URL for a local path."""
    return path.resolve().as_uri()


def iterm2_inline_image_sequence(
    data: bytes,
    *,
    name: str,
    width: str | None = None,
    height: str | None = None,
    preserve_aspect: bool = True,
) -> str:
    """Return an iTerm2 inline image escape sequence.

    For large payloads, this returns a multipart sequence (MultipartFile +
    one or more FilePart chunks + FileEnd) to stay within iTerm2's per-OSC size
    limits.

    Reference: iTerm2 proprietary escape code ("OSC 1337;File=...").
    """
    b64_data = base64.b64encode(data).decode("ascii")
    name_b64 = base64.b64encode(name.encode("utf-8")).decode("ascii")
    params: list[str] = [
        "inline=1",
        f"size={len(data)}",
        f"name={name_b64}",
    ]
    if width:
        params.append(f"width={width}")
    if height:
        params.append(f"height={height}")
    if not preserve_aspect:
        params.append("preserveAspectRatio=0")

    single_prefix = f"{_ESC}]1337;File={';'.join(params)}:"
    single = f"{single_prefix}{b64_data}{_BEL}"
    if len(single) <= _OSC_MAX_CHARS:
        return single

    header = f"{_ESC}]1337;MultipartFile={';'.join(params)}{_BEL}"
    part_prefix = f"{_ESC}]1337;FilePart="
    part_suffix = _BEL
    max_part_chars = _OSC_MAX_CHARS - (len(part_prefix) + len(part_suffix))
    parts = _split_b64_payload(b64_data, max_chars=max_part_chars)
    part_seqs = [f"{part_prefix}{chunk}{_BEL}" for chunk in parts if chunk]
    end = f"{_ESC}]1337;FileEnd{_BEL}"
    return "".join([header, *part_seqs, end])


def iterm2_inline_image_sequence_from_path(
    path: Path,
    *,
    width: str | None = "auto",
    height: str | None = None,
    preserve_aspect: bool = True,
) -> str | None:
    """Return an iTerm2 inline image sequence for a file path."""
    try:
        data = path.read_bytes()
    except OSError as exc:
        msg = f"Failed to read image artifact at {path}: {exc}"
        raise FilesystemError(msg) from exc
    return iterm2_inline_image_sequence(
        data,
        name=path.name,
        width=width,
        height=height,
        preserve_aspect=preserve_aspect,
    )


__all__ = (
    "file_url",
    "is_iterm2",
    "iterm2_inline_image_sequence",
    "iterm2_inline_image_sequence_from_path",
    "osc8_link",
)
