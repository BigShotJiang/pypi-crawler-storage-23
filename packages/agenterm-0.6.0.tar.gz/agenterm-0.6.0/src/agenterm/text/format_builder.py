"""Helpers for building TextFormat descriptors from schema files.

These helpers convert a JSON/YAML schema file into a TextFormat JSON-schema
descriptor used by configuration-driven structured outputs (for example,
`model.text_format_file` in `config.yaml`).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Final, Protocol

from ruamel.yaml import YAML, YAMLError

from agenterm.config.text_format import TextFormat, build_json_schema_format
from agenterm.constants.limits import SMALL_FILE_MAX_BYTES
from agenterm.core.errors import ConfigError, FilesystemError, ValidationError
from agenterm.core.json_codec import (
    is_json_value,
    parse_json_value,
    require_json_object,
    require_json_value,
)

if TYPE_CHECKING:
    from pathlib import Path
    from typing import IO

    from agenterm.core.json_codec import JSONLike
    from agenterm.core.json_types import JSONValue

_MAX_SCHEMA_BYTES: Final[int] = SMALL_FILE_MAX_BYTES


class _YamlLoader(Protocol):
    def load(
        self,
        stream: str | bytes | bytearray | IO[str],
    ) -> JSONValue | list[JSONValue] | dict[str, JSONValue] | None: ...


def _make_yaml_loader() -> _YamlLoader:
    loader: YAML = YAML(typ="safe")
    return loader


def _load_yaml_value(text: str) -> JSONValue | None:
    """Load YAML content using ruamel safe loader."""
    yaml_loader = _make_yaml_loader()
    raw: JSONLike | None = yaml_loader.load(text)
    if raw is None:
        return None
    if is_json_value(value=raw):
        return raw
    try:
        return require_json_value(
            value=raw,
            context="text_format.schema.yaml",
        )
    except ValidationError as exc:
        msg = f"Schema file must contain JSON-compatible values: {exc}"
        raise ConfigError(msg) from exc


def _read_schema_text(path: Path) -> str:
    """Return the UTF-8 text contents of a schema file with a size cap.

    Raises FilesystemError when the file is missing/unreadable and ConfigError
    when the file violates size limits or decoding expectations.
    """
    if not path.exists() or not path.is_file():
        msg = f"Schema file not found or not a file: {path}"
        raise FilesystemError(msg)
    try:
        size = path.stat().st_size
    except OSError as e:
        msg = f"Failed to stat schema file {path}: {e}"
        raise FilesystemError(msg) from e
    if size > _MAX_SCHEMA_BYTES:
        msg = f"Schema file too large (> {SMALL_FILE_MAX_BYTES} bytes): {path}"
        raise ConfigError(msg)
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as e:
        msg = f"Schema file must be valid UTF-8 text: {path}"
        raise ConfigError(msg) from e


def _load_schema_mapping(path: Path) -> dict[str, JSONValue]:
    """Load a JSON/YAML schema file into a plain mapping.

    The loader prefers JSON; on failure it falls back to YAML. The root must
    be a mapping with string keys and JSON-compatible values.
    """
    text = _read_schema_text(path)

    # First attempt: JSON
    json_obj = parse_json_value(text)
    if json_obj is not None:
        if isinstance(json_obj, dict):
            try:
                return require_json_object(
                    value=json_obj,
                    context="text_format.schema.json",
                )
            except ValidationError as exc:
                msg = f"Schema file must contain JSON-compatible values: {exc}"
                raise ConfigError(msg) from exc
        msg = "Structured schema root must be a mapping (object)"
        raise ConfigError(msg)

    # Second attempt: YAML
    try:
        yaml_obj_raw = _load_yaml_value(text)
    except YAMLError as e:
        msg = "Schema file must be valid JSON or YAML mapping"
        raise ConfigError(msg) from e

    if not isinstance(yaml_obj_raw, dict):
        msg = "Structured schema root must be a mapping (object)"
        raise ConfigError(msg)
    try:
        return require_json_object(
            value=yaml_obj_raw,
            context="text_format.schema.yaml",
        )
    except ValidationError as exc:
        msg = f"Schema file must contain JSON-compatible values: {exc}"
        raise ConfigError(msg) from exc


def from_schema_file(path: Path, *, strict: bool) -> TextFormat:
    """Build a TextFormat descriptor from a JSON/YAML schema file.

    The name is inferred from the schema's ``title`` field when present and
    non-empty; otherwise the file stem is used. The schema is passed through
    unchanged (keys must already be strings) and an optional ``description``
    field is propagated when present.

    Raises ConfigError/FilesystemError when the file cannot be read or parsed,
    or when the root is not a mapping.
    """
    schema = _load_schema_mapping(path)
    title = schema.get("title")
    name = str(title).strip() if isinstance(title, str) else ""
    if not name:
        name = path.stem

    desc_obj = schema.get("description")
    description = (
        str(desc_obj).strip()
        if isinstance(desc_obj, str) and desc_obj.strip()
        else None
    )

    return build_json_schema_format(
        name=name,
        schema=schema,
        strict=bool(strict),
        description=description,
    )
