"""CLI package surface.

Keep package import side effects minimal so leaf modules (for example
``agenterm.cli.options``) do not eagerly import the full command graph.
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typer import Typer

app: Typer


def __getattr__(name: str) -> Typer:
    if name != "app":
        msg = f"module 'agenterm.cli' has no attribute {name!r}"
        raise AttributeError(msg)
    module = importlib.import_module("agenterm.cli.main")
    return module.app


__all__ = ("app",)
