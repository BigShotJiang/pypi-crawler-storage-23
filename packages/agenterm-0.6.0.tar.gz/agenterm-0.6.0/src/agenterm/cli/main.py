"""CLI entrypoint wiring for agenterm."""

from __future__ import annotations

import asyncio
import sys
from typing import TYPE_CHECKING, Annotated

import typer
from rich.prompt import Prompt

from agenterm import __version__
from agenterm.app.services import ReplConfigFlags
from agenterm.app.services.configuration import build_repl_state_from_flags
from agenterm.cli.options import (
    AgentOption,
    AllowDangerousOption,
    ApprovalsOption,
    AttachmentsOption,
    AttemptTimeoutSecondsOption,
    BackgroundOption,
    BranchOption,
    ConfigOption,
    DeadlineSecondsOption,
    FileOption,
    LiveOption,
    MaxRetriesOption,
    ModelOption,
    NoRetryOption,
    NoToolsOption,
    OptionalFormatOption,
    QuietOption,
    SessionOption,
    StoreOption,
    ToolSelectOption,
    TraceOption,
    VerboseOption,
    VersionOption,
)
from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output_format import OutputFormat
from agenterm.commands.agents import agents_app
from agenterm.commands.artifacts import artifacts_app
from agenterm.commands.branch import branch_app
from agenterm.commands.cli_args import RunCliArgs
from agenterm.commands.config import config_app
from agenterm.commands.flag_decoder import parse_trace_flag
from agenterm.commands.inspect import inspect_app
from agenterm.commands.mcp import mcp_app
from agenterm.commands.run import run_command_with_args
from agenterm.commands.session import session_app
from agenterm.commands.trace import trace_app
from agenterm.config.baseline import check_baseline_status, save_baseline
from agenterm.config.paths import (
    global_agents_dir,
    global_config_dir,
    local_agents_dir,
    local_config_dir,
)
from agenterm.constants.defaults import DEFAULT_MODEL_ID
from agenterm.core.choices.approvals import APPROVAL_MODES, parse_approval_mode
from agenterm.core.env import has_openai_api_key
from agenterm.core.error_report import (
    ErrorContext,
    build_error_report,
    build_message_report,
)
from agenterm.core.errors import AgentermError
from agenterm.store.async_db import close_store_registry
from agenterm.ui.cli_renderer import render_error_report, render_notice
from agenterm.ui.cli_renderer_base import cli_console
from agenterm.ui.cli_settings import (
    CliOutputSettings,
    discover_cli_theme,
    set_cli_output_settings,
)
from agenterm.ui.repl import run_repl

if TYPE_CHECKING:
    from agenterm.core.choices.approvals import ApprovalMode
    from agenterm.core.choices.config_scope import ConfigScope
    from agenterm.core.types import SessionState

app = typer.Typer(
    name="agenterm",
    help="Terminal-native agent runtime with persistent sessions, branching, and MCP",
    no_args_is_help=True,
    invoke_without_command=True,
    rich_markup_mode="rich",
    epilog=(
        "Quick start:\n\n"
        "  agenterm repl                     Interactive REPL with full-screen TUI\n\n"
        '  agenterm run "prompt"             One-shot execution (scripts, CI)\n\n'
        "  agenterm session list             Browse local sessions\n\n"
        "  agenterm mcp status               Check MCP server connections\n\n"
        "  agenterm config save --scope global  Write baseline config"
    ),
)

app.add_typer(config_app, name="config")
app.add_typer(agents_app, name="agents")
app.add_typer(artifacts_app, name="artifacts")
app.add_typer(trace_app, name="trace")
app.add_typer(mcp_app, name="mcp")
app.add_typer(session_app, name="session")
app.add_typer(branch_app, name="branch")
app.add_typer(inspect_app, name="inspect")


def _main(
    ctx: typer.Context,
    *,
    version: VersionOption = False,
    quiet: QuietOption = False,
    verbose: VerboseOption = False,
) -> None:
    def _cleanup_stores() -> None:
        # Many CLI surfaces touch AsyncStore (aiosqlite). Its worker threads are
        # non-daemon and will keep the process alive unless connections are
        # closed. Cleanup is best-effort and must not corrupt JSON output.
        try:
            asyncio.run(close_store_registry())
        except (AgentermError, RuntimeError):
            return

    ctx.call_on_close(_cleanup_stores)

    if verbose and quiet:
        quiet = False
    theme = discover_cli_theme()
    settings = CliOutputSettings(quiet=quiet, verbose=verbose, theme=theme)
    set_cli_output_settings(settings)
    if version:
        typer.echo(__version__)
        raise typer.Exit


app.callback()(_main)


def _cli_context(operation: str) -> ErrorContext:
    return ErrorContext(operation=operation, resource=f"cli.{operation}", trace_id=None)


def _exit_usage_error(
    *,
    output_format: OutputFormat,
    message: str,
    operation: str,
) -> None:
    report = build_message_report(
        kind="usage_error",
        message=message,
        context=_cli_context(operation),
    )
    emit_cli_error(output_format=output_format, report=report)
    raise typer.Exit(2)


def _parse_approvals_mode(
    approvals: str | None,
    *,
    output_format: OutputFormat,
    operation: str,
) -> ApprovalMode | None:
    if approvals is None:
        return None
    parsed = parse_approval_mode(approvals)
    if parsed is None:
        msg = f"--approvals must be one of: {', '.join(APPROVAL_MODES)}"
        _exit_usage_error(
            output_format=output_format,
            message=msg,
            operation=operation,
        )
        return None
    return parsed


_BASELINE_SCOPE_CHOICES = ("local", "global", "skip")


def _build_baseline_prompt_message(
    *,
    config_missing: bool,
    agent_bundled: bool,
) -> str:
    """Build the prompt message based on what's missing."""
    local_cfg = local_config_dir() / "config.yaml"
    global_cfg = global_config_dir() / "config.yaml"
    local_agents = local_agents_dir()
    global_agents = global_agents_dir()

    if config_missing and agent_bundled:
        header = "No baseline config or agent files found."
        paths = (
            f"local  - {local_cfg}, {local_agents}\n"
            f"global - {global_cfg}, {global_agents}"
        )
    elif config_missing:
        header = "No config.yaml found."
        paths = f"local  - {local_cfg}\nglobal - {global_cfg}"
    else:
        header = "Using bundled agent file."
        paths = f"local  - {local_agents}\nglobal - {global_agents}"

    return f"{header} Save baseline?\n{paths}\nskip   - continue with defaults"


def _prompt_baseline_scope(
    *,
    config_missing: bool,
    agent_bundled: bool,
) -> ConfigScope | None:
    """Prompt user to choose scope for saving baseline files."""
    message = _build_baseline_prompt_message(
        config_missing=config_missing,
        agent_bundled=agent_bundled,
    )
    render_notice(title="Baseline", message=message, style="accent")
    try:
        choice = Prompt.ask(
            "Save baseline",
            choices=list(_BASELINE_SCOPE_CHOICES),
            default="global",
            console=cli_console(),
            case_sensitive=False,
        )
    except (EOFError, KeyboardInterrupt):
        render_notice(title="Baseline", message="Cancelled.", style="warn")
        raise typer.Exit(130) from None

    choice_norm = choice.strip().lower()
    if choice_norm == "local":
        return "local"
    if choice_norm == "global":
        return "global"
    return None


def _maybe_prompt_baseline_save(
    state: SessionState,
    *,
    flags: ReplConfigFlags,
    model: str | None,
) -> SessionState:
    """Prompt to save baseline files if any are missing. Caller guarantees TTY."""
    status = check_baseline_status(
        config_path=state.config_path,
        agent_source=state.cfg.agent.source,
    )

    if not status.needs_prompt:
        return state

    scope = _prompt_baseline_scope(
        config_missing=status.config_missing,
        agent_bundled=status.agent_bundled,
    )
    if scope is None:
        render_notice(
            title="Baseline",
            message="Continuing with defaults.",
            style="accent",
        )
        return state

    try:
        result = save_baseline(
            scope=scope,
            status=status,
            model=model or DEFAULT_MODEL_ID,
        )
    except AgentermError as exc:
        report = build_error_report(exc, context=_cli_context("repl.baseline"))
        render_error_report(report)
        raise typer.Exit(1) from exc

    if result.config is not None:
        render_notice(
            title="Config",
            message=f"Saved {result.config.scope} config: {result.config.path}",
            style="good",
        )
    if result.agents is not None:
        agents = result.agents
        render_notice(
            title="Agents",
            message=(f"Saved {agents.scope} agent files: {len(agents.paths)} files"),
            style="good",
        )

    return build_repl_state_from_flags(flags)


def _prepare_repl_state(
    *,
    flags: ReplConfigFlags,
    model: str | None,
) -> SessionState:
    state = build_repl_state_from_flags(flags)
    return _maybe_prompt_baseline_save(state, flags=flags, model=model)


@app.command("repl", help="Start an interactive REPL session")
def repl_cmd(
    *,
    config: ConfigOption = None,
    agent: AgentOption = None,
    model: ModelOption = None,
    session: SessionOption = None,
    trace: TraceOption = None,
    no_tools: NoToolsOption = False,
    store: StoreOption = None,
    approvals: ApprovalsOption = None,
) -> None:
    """Start the interactive REPL (no implicit REPL on bare `agenterm`)."""
    if not sys.stdin.isatty():
        report = build_message_report(
            kind="usage_error",
            message="REPL requires an interactive terminal.",
            recovery_hint="Use 'agenterm run' for non-interactive execution.",
            context=_cli_context("repl"),
        )
        render_error_report(report)
        raise typer.Exit(1)

    approvals_mode = _parse_approvals_mode(
        approvals,
        output_format=OutputFormat.human,
        operation="repl",
    )
    trace_cfg = parse_trace_flag(trace)

    flags = ReplConfigFlags(
        config=config,
        agent_name=agent,
        model=model,
        no_tools=no_tools,
        trace_enabled=trace_cfg.enabled,
        store_override=store,
        trace_id=trace_cfg.trace_id,
        trace_group=trace_cfg.group_id,
        trace_metadata=trace_cfg.metadata,
        allow_dangerous=True,
        approvals_mode=approvals_mode,
    )
    try:
        state = _prepare_repl_state(flags=flags, model=model)
        if (
            state.cfg.agent.model.lower().startswith("openai/")
            and not has_openai_api_key()
        ):
            render_notice(
                title="Auth",
                message=(
                    "OPENAI_API_KEY not set "
                    "(set it in your environment or use `/config key`)"
                ),
                style="warn",
            )
        asyncio.run(
            run_repl(
                state,
                attach_session_id=session,
                store_override=flags.store_override,
            ),
        )
    except AgentermError as exc:
        report = build_error_report(exc, context=_cli_context("repl"))
        render_error_report(report)
        raise typer.Exit(2) from exc


@app.command("run", help="Execute a one-shot run (prompt args, --file, or stdin)")
def run_cmd(
    prompts: Annotated[list[str] | None, typer.Argument(help="Prompt text")] = None,
    *,
    config: ConfigOption = None,
    agent: AgentOption = None,
    model: ModelOption = None,
    output_format: OptionalFormatOption = None,
    session: SessionOption = None,
    branch: BranchOption = None,
    trace: TraceOption = None,
    no_tools: NoToolsOption = False,
    tool_select: ToolSelectOption = None,
    store: StoreOption = None,
    file: FileOption = None,
    attachments: AttachmentsOption = None,
    live: LiveOption = None,
    background: BackgroundOption = None,
    no_retry: NoRetryOption = False,
    max_retries: MaxRetriesOption = None,
    deadline_seconds: DeadlineSecondsOption = None,
    attempt_timeout_seconds: AttemptTimeoutSecondsOption = None,
    allow_dangerous: AllowDangerousOption = False,
) -> None:
    """Execute a one-shot run against the current project."""
    trace_cfg = parse_trace_flag(trace)

    args = RunCliArgs(
        config=config,
        agent_name=agent,
        model=model,
        format_override=output_format,
        live=live,
        background=background,
        no_tools=no_tools,
        tool_select=tool_select,
        no_retry=no_retry,
        max_retries=max_retries,
        deadline_seconds=deadline_seconds,
        attempt_timeout_seconds=attempt_timeout_seconds,
        file=file,
        prompts=prompts,
        allow_dangerous=allow_dangerous,
        attachments=attachments,
        trace_enabled=trace_cfg.enabled,
        trace_id=trace_cfg.trace_id,
        trace_group=trace_cfg.group_id,
        trace_metadata=list(trace_cfg.metadata) if trace_cfg.metadata else None,
        session_id=session,
        branch_id=branch,
        store_override=store,
    )
    run_command_with_args(args)
