"""Reusable Typer option definitions (single source of truth)."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from agenterm.cli.output_format import OutputFormat

_HELP_PANEL_CONFIG = "Config"
_HELP_PANEL_MODEL = "Model"
_HELP_PANEL_OUTPUT = "Output"
_HELP_PANEL_SESSION = "Session"
_HELP_PANEL_TRACE = "Tracing"
_HELP_PANEL_RUNTIME = "Runtime"
_HELP_PANEL_GLOBAL = "Global"
_HELP_PANEL_INPUT = "Input"
_HELP_PANEL_RUN = "Run"
_HELP_PANEL_TOOLS = "Tools"

ConfigOption = Annotated[
    Path | None,
    typer.Option(
        "--config",
        "-c",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Config file",
        rich_help_panel=_HELP_PANEL_CONFIG,
    ),
]

ModelOption = Annotated[
    str | None,
    typer.Option(
        "--model",
        "-m",
        help="Model ID (openai/<model> or gateway/<route>/<model>)",
        rich_help_panel=_HELP_PANEL_MODEL,
    ),
]

AgentOption = Annotated[
    str | None,
    typer.Option(
        "--agent",
        help="Agent name",
        rich_help_panel=_HELP_PANEL_CONFIG,
    ),
]

FormatOption = Annotated[
    OutputFormat,
    typer.Option(
        "--format",
        "-o",
        help="Output format (human|json)",
        rich_help_panel=_HELP_PANEL_OUTPUT,
    ),
]

OptionalFormatOption = Annotated[
    OutputFormat | None,
    typer.Option(
        "--format",
        "-o",
        help="Output format override (human|json)",
        rich_help_panel=_HELP_PANEL_OUTPUT,
    ),
]

TraceOption = Annotated[
    str | None,
    typer.Option(
        "--trace",
        help="Trace config (on|off|ID:GROUP:key=val)",
        rich_help_panel=_HELP_PANEL_TRACE,
    ),
]

TraceIdOption = Annotated[
    str | None,
    typer.Option(
        "--trace-id",
        help="Filter by trace id",
        rich_help_panel=_HELP_PANEL_TRACE,
    ),
]

SessionOption = Annotated[
    str | None,
    typer.Option(
        "--session",
        help="Session ID",
        rich_help_panel=_HELP_PANEL_SESSION,
    ),
]

SessionIdOption = Annotated[
    str | None,
    typer.Option(
        "--session-id",
        help="Filter by session id",
        rich_help_panel=_HELP_PANEL_SESSION,
    ),
]

BranchOption = Annotated[
    str | None,
    typer.Option(
        "--branch",
        help="Branch ID",
        rich_help_panel=_HELP_PANEL_SESSION,
    ),
]

StoreOption = Annotated[
    bool | None,
    typer.Option(
        "--store/--no-store",
        help="Enable or disable server-side store (default: off)",
        rich_help_panel=_HELP_PANEL_RUNTIME,
    ),
]

ApprovalsOption = Annotated[
    str | None,
    typer.Option(
        "--approvals",
        help="Tool approvals mode (prompt|auto)",
        rich_help_panel=_HELP_PANEL_RUNTIME,
    ),
]

FileOption = Annotated[
    Path | None,
    typer.Option(
        "--file",
        "-f",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Prompt file",
        rich_help_panel=_HELP_PANEL_INPUT,
    ),
]

AttachmentsOption = Annotated[
    list[str] | None,
    typer.Option(
        "--attach",
        help="Attachment",
        rich_help_panel=_HELP_PANEL_INPUT,
    ),
]

LiveOption = Annotated[
    bool | None,
    typer.Option(
        "--live/--no-live",
        help="Stream events",
        rich_help_panel=_HELP_PANEL_RUN,
    ),
]

BackgroundOption = Annotated[
    bool | None,
    typer.Option(
        "--background/--no-background",
        help="Server-side (OpenAI or background-enabled gateway route)",
        rich_help_panel=_HELP_PANEL_RUN,
    ),
]

NoRetryOption = Annotated[
    bool,
    typer.Option(
        "--no-retry/--retry",
        help="Disable or enable provider retries for this run",
        rich_help_panel=_HELP_PANEL_RUN,
    ),
]

MaxRetriesOption = Annotated[
    int | None,
    typer.Option(
        "--max-retries",
        help="Override provider max_retries for this run",
        rich_help_panel=_HELP_PANEL_RUN,
    ),
]

DeadlineSecondsOption = Annotated[
    float | None,
    typer.Option(
        "--deadline-seconds",
        help="Override provider retry deadline_seconds for this run",
        rich_help_panel=_HELP_PANEL_RUN,
    ),
]

AttemptTimeoutSecondsOption = Annotated[
    float | None,
    typer.Option(
        "--attempt-timeout-seconds",
        help="Override provider attempt_timeout_seconds for this run",
        rich_help_panel=_HELP_PANEL_RUN,
    ),
]

NoToolsOption = Annotated[
    bool,
    typer.Option(
        "--no-tools/--tools",
        help="Disable tools",
        rich_help_panel=_HELP_PANEL_TOOLS,
    ),
]

ToolSelectOption = Annotated[
    list[str] | None,
    typer.Option(
        "--tools-bundle",
        "--tool",
        help="Select tool bundles or tool keys",
        rich_help_panel=_HELP_PANEL_TOOLS,
    ),
]

AllowDangerousOption = Annotated[
    bool,
    typer.Option(
        "--allow-dangerous/--disallow-dangerous",
        help="Allow dangerous tools",
        rich_help_panel=_HELP_PANEL_TOOLS,
    ),
]

QuietOption = Annotated[
    bool,
    typer.Option(
        "--quiet/--no-quiet",
        "-q",
        help="Suppress informational notices",
        rich_help_panel=_HELP_PANEL_GLOBAL,
    ),
]

VerboseOption = Annotated[
    bool,
    typer.Option(
        "--verbose/--no-verbose",
        "-v",
        help="Show verbose error details",
        rich_help_panel=_HELP_PANEL_GLOBAL,
    ),
]

VersionOption = Annotated[
    bool,
    typer.Option(
        "-V",
        "--version/--no-version",
        is_eager=True,
        help="Show version and exit",
        rich_help_panel=_HELP_PANEL_GLOBAL,
    ),
]

__all__ = (
    "AgentOption",
    "AllowDangerousOption",
    "ApprovalsOption",
    "AttachmentsOption",
    "AttemptTimeoutSecondsOption",
    "BackgroundOption",
    "ConfigOption",
    "DeadlineSecondsOption",
    "FileOption",
    "FormatOption",
    "LiveOption",
    "MaxRetriesOption",
    "ModelOption",
    "NoRetryOption",
    "NoToolsOption",
    "OptionalFormatOption",
    "QuietOption",
    "SessionIdOption",
    "SessionOption",
    "StoreOption",
    "ToolSelectOption",
    "TraceIdOption",
    "TraceOption",
    "VerboseOption",
    "VersionOption",
)
