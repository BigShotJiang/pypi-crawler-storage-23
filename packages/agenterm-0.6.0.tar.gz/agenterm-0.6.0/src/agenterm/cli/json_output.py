"""Helpers for emitting canonical JSON envelopes from CLI commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

import typer

from agenterm.core.envelope import (
    JsonPayload,
    SuccessEnvelope,
    SuccessResult,
    iso_timestamp,
)
from agenterm.core.json_codec import dumps_compact

if TYPE_CHECKING:
    from agenterm.core.error_report import ErrorReport


def emit_success(
    *,
    resource: str,
    payload: JsonPayload,
    trace_id: str | None,
) -> None:
    """Emit a single success envelope JSON document to stdout."""
    env = SuccessEnvelope(
        trace_id=trace_id,
        ts=iso_timestamp(),
        result=SuccessResult(resource=resource, payload=payload),
    )
    typer.echo(
        dumps_compact(
            env.to_json(),
            ensure_ascii=False,
            context=f"cli.json_output.success.{resource}",
        )
    )


def emit_error(*, report: ErrorReport) -> None:
    """Emit a single error envelope JSON document to stdout."""
    env = report.to_envelope()
    typer.echo(
        dumps_compact(
            env.to_json(),
            ensure_ascii=False,
            context="cli.json_output.error",
        )
    )


__all__ = ("emit_error", "emit_success")
