"""Output format choices for CLI commands."""

from __future__ import annotations

from enum import StrEnum


class OutputFormat(StrEnum):
    """Supported CLI output formats."""

    human = "human"
    json = "json"


def is_json(output_format: OutputFormat) -> bool:
    """Return True when the command should emit a JSON envelope."""
    return output_format is OutputFormat.json


__all__ = ("OutputFormat", "is_json")
