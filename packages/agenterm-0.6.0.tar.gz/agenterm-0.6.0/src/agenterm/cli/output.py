"""Unified output dispatcher for CLI commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.cli.json_output import emit_error as emit_json_error
from agenterm.cli.json_output import emit_success as emit_json_success
from agenterm.cli.output_format import OutputFormat, is_json
from agenterm.ui.cli_renderer import render_error_report, render_payload

if TYPE_CHECKING:
    from agenterm.core.envelope import JsonPayload
    from agenterm.core.error_report import ErrorReport


def emit_result(
    *,
    output_format: OutputFormat,
    resource: str,
    payload: JsonPayload,
    trace_id: str | None,
) -> None:
    """Emit a command result in JSON or human form."""
    if is_json(output_format):
        emit_json_success(resource=resource, payload=payload, trace_id=trace_id)
        return
    render_payload(resource=resource, payload=payload)


def emit_error(*, output_format: OutputFormat, report: ErrorReport) -> None:
    """Emit a command error in JSON or human form."""
    if is_json(output_format):
        emit_json_error(report=report)
        return
    render_error_report(report)


__all__ = ("emit_error", "emit_result")
