"""Ephemeral agent_run tool (agent-as-tool delegation)."""

from __future__ import annotations

from dataclasses import dataclass, replace
from functools import partial
from typing import TYPE_CHECKING

from agents.exceptions import MaxTurnsExceeded
from agents.tool import FunctionTool

from agenterm.artifacts.agent_run import persist_agent_run_report
from agenterm.constants.limits import AGENT_RUN_SUMMARY_MAX_CHARS_DEFAULT
from agenterm.core.approvals import ApprovalsContext
from agenterm.core.errors import AgentermError, ConfigError, ValidationError
from agenterm.core.json_codec import as_str
from agenterm.core.model_contract import (
    delegate_model_catalog,
    map_agent_run_error,
    preflight_delegate_model_target,
)
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.retry import retry_async
from agenterm.core.tool_output_envelope import ToolOutputEnvelope, ToolOutputError
from agenterm.core.tool_output_limits import limit_tool_output_text
from agenterm.engine.agent_run_parse import (
    AGENT_RUN_OP_DISCOVER_MODELS,
    AGENT_RUN_OP_RUN,
    AGENT_RUN_SCHEMA,
    AgentRunArgs,
    AgentRunParseError,
    parse_agent_run_payload,
)
from agenterm.engine.agent_run_report_payload import build_agent_run_report_payload
from agenterm.engine.agent_run_schema import AGENT_RUN_REPORT_SCHEMA
from agenterm.engine.delegate_bundle import delegate_bundle_specs
from agenterm.engine.run import RunExecOptions, run_once
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_agent_run
from agenterm.store.async_db import AsyncStore
from agenterm.workflow.run.retry_policy import (
    build_retry_budget,
    provider_retry_decision,
    provider_retry_exceptions,
    resolve_provider_resilience,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence
    from pathlib import Path

    from agents.agent import Agent
    from agents.result import RunResultBase
    from agents.tool_context import ToolContext

    from agenterm.config.model import AppConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.toolspec import ToolSpec

_INVALID_INPUT_KIND = "invalid_input"
_TOOL_ERROR_KIND = "tool_error"


@dataclass(frozen=True)
class AgentRunInvocation:
    """Resolved agent_run invocation inputs."""

    args: AgentRunArgs
    ctx_runtime: ToolRuntimeContext
    cfg_run: AppConfig
    selected: list[ToolSpec]
    cancel_token: CancelToken | None


def _error_output(
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    details_map = dict(details) if details is not None else {}
    if "reason" not in details_map:
        if kind == _INVALID_INPUT_KIND:
            details_map["reason"] = "invalid_input"
        elif kind == _TOOL_ERROR_KIND:
            details_map["reason"] = "tool_error"
        else:
            details_map["reason"] = "error"
    err = ToolOutputError(
        kind=kind,
        message=message,
        details=details_map,
    )
    env = ToolOutputEnvelope(
        tool="agent_run",
        ok=False,
        result={},
        error=err,
    )
    return env.to_json_string()


def _invalid_payload_output() -> str:
    return _error_output(
        kind=_INVALID_INPUT_KIND,
        message="Invalid agent_run payload.",
        details={"field": "payload", "reason": "invalid_payload"},
    )


def _parse_error_output(error: AgentRunParseError) -> str:
    return _error_output(
        kind=_INVALID_INPUT_KIND,
        message=error.message,
        details=error.details,
    )


def _tools_available(specs: Sequence[ToolSpec]) -> list[str]:
    return sorted({spec.key for spec in specs})


def _agent_run_summary_max_chars(cfg: AppConfig) -> int:
    tool_max = int(cfg.tools.max_chars)
    return max(0, min(tool_max, AGENT_RUN_SUMMARY_MAX_CHARS_DEFAULT))


def _agent_run_discovery_output(cfg: AppConfig) -> str:
    payload = dict(delegate_model_catalog(cfg.providers))
    payload["ok"] = True
    payload["op"] = AGENT_RUN_OP_DISCOVER_MODELS
    env = ToolOutputEnvelope(tool="agent_run", ok=True, result=payload)
    return env.to_json_string()


def _map_delegate_model_settings_error(
    *,
    model_id: str,
    cfg: AppConfig,
    error_message: str,
) -> tuple[str, dict[str, JSONValue]]:
    catalog = delegate_model_catalog(cfg.providers)
    lowered = error_message.lower()
    details = dict(catalog)
    if "model.reasoning is only supported" in lowered:
        details["field"] = "model.reasoning"
        details["reason"] = "unsupported_reasoning"
        details["target_model"] = model_id
        details["next_step"] = (
            "Use an OpenAI GPT-5 delegated model id (openai/gpt-5*) or disable "
            "model.reasoning for delegated runs."
        )
        return (
            "Delegated model does not support the configured reasoning settings.",
            details,
        )
    details["field"] = "model"
    details["reason"] = "invalid_model_settings"
    details["target_model"] = model_id
    details["next_step"] = (
        "Choose a model from suggested_models or adjust model settings for the "
        "delegated target."
    )
    return error_message, details


def _resolve_agent_run_selection(
    cfg_run: AppConfig,
    *,
    model_id: str,
) -> tuple[list[ToolSpec], str | None]:
    try:
        return list(delegate_bundle_specs(cfg_run, model_id=model_id)), None
    except ValidationError as exc:
        return [], _error_output(
            kind=_INVALID_INPUT_KIND,
            message=str(exc),
            details={"field": "model", "reason": "invalid_model_target"},
        )
    except ConfigError as exc:
        return [], _error_output(
            kind=_TOOL_ERROR_KIND,
            message=str(exc),
            details={"reason": "delegate_bundle_config_error"},
        )


def _resolve_agent_run_invocation(
    ctx: ToolContext[ToolRuntimeContext | None],
    *,
    args: AgentRunArgs,
    cfg: AppConfig,
) -> tuple[AgentRunInvocation | None, str | None]:
    ctx_runtime = ctx.context
    if not isinstance(ctx_runtime, ToolRuntimeContext):
        return None, _error_output(
            kind=_TOOL_ERROR_KIND,
            message="agent_run requires ToolRuntimeContext.",
        )

    cancel_token = ctx_runtime.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    agent_cfg = replace(
        cfg.agent,
        name="agent_run",
        model=args.model,
        instructions=args.instructions,
        path=None,
        source=None,
        explicit=True,
    )
    cfg_run = replace(cfg, agent=agent_cfg)
    preflight_error = preflight_delegate_model_target(
        providers=cfg_run.providers,
        model_id=args.model,
    )
    if preflight_error is not None:
        return None, _error_output(
            kind=_INVALID_INPUT_KIND,
            message=preflight_error.message,
            details=preflight_error.details,
        )
    try:
        _ = cfg_run.to_model_settings()
    except ValidationError as exc:
        message, details = _map_delegate_model_settings_error(
            model_id=args.model,
            cfg=cfg_run,
            error_message=str(exc),
        )
        return None, _error_output(
            kind=_INVALID_INPUT_KIND,
            message=message,
            details=details,
        )

    selected, selection_error = _resolve_agent_run_selection(
        cfg_run, model_id=args.model
    )
    if selection_error is not None:
        return None, selection_error
    return (
        AgentRunInvocation(
            args=args,
            ctx_runtime=ctx_runtime,
            cfg_run=cfg_run,
            selected=selected,
            cancel_token=cancel_token,
        ),
        None,
    )


def _prepare_agent_run_invocation(
    ctx: ToolContext[ToolRuntimeContext | None],
    raw: str,
    *,
    cfg: AppConfig,
) -> tuple[AgentRunInvocation | None, str | None]:
    parsed, parse_error = parse_agent_run_payload(raw)
    if parse_error is not None:
        return None, _parse_error_output(parse_error)
    if parsed is None:
        return None, _invalid_payload_output()
    if parsed.discovery_requested:
        return None, _agent_run_discovery_output(cfg)
    args = parsed.args
    if args is None:
        return None, _invalid_payload_output()
    invocation, error = _resolve_agent_run_invocation(ctx, args=args, cfg=cfg)
    if error is not None:
        return None, error
    return invocation, None


async def _run_agent_once(
    agent: Agent,
    args: AgentRunArgs,
    cfg_run: AppConfig,
    *,
    warnings: list[str],
    max_turns: int,
) -> RunResultBase:
    return await run_once(
        agent,
        args.input_text,
        opts=RunExecOptions(
            cfg=cfg_run,
            workflow_name="agenterm agent_run",
            session=None,
            background=False,
            tool_context=None,
            model_id=args.model,
            max_turns=max_turns,
            on_optional_fallback=warnings.append,
        ),
    )


def _agent_run_success_payload(
    *,
    cfg: AppConfig,
    report: Mapping[str, JSONValue],
    report_id: str,
) -> dict[str, JSONValue]:
    summary_raw = as_str(report.get("output_text")) or ""
    summary_max_chars = _agent_run_summary_max_chars(cfg)
    summary = limit_tool_output_text(summary_raw, max_chars=summary_max_chars)
    return {
        "ok": True,
        "op": AGENT_RUN_OP_RUN,
        "summary": summary,
        "summary_truncated": summary != summary_raw,
        "report_id": report_id,
        "response_id": report.get("response_id"),
        "tool_counts": report.get("tool_counts", {}),
        "report_truncated": report.get("truncated", False),
        "warnings": report.get("warnings", []),
    }


async def _execute_agent_run_invocation(
    ctx: ToolContext[ToolRuntimeContext | None],
    invocation: AgentRunInvocation,
    *,
    cfg: AppConfig,
    workspace_root: Path,
    agent_builder: Callable[..., Agent],
) -> tuple[dict[str, JSONValue] | None, str | None]:
    args = invocation.args
    ctx_runtime = invocation.ctx_runtime
    cfg_run = invocation.cfg_run
    selected = invocation.selected
    cancel_token = invocation.cancel_token
    tools_available = _tools_available(selected)
    warnings: list[str] = []

    approvals = ApprovalsContext(mode="auto")
    try:
        agent = agent_builder(
            cfg_run,
            selected_tools=selected,
            approvals=approvals,
            workspace_root=workspace_root,
            mcp_servers=None,
        )
        resilience = resolve_provider_resilience(
            cfg_run,
            model_id=args.model,
            workflow="agent_run",
        )
        retry_budget = build_retry_budget(resilience)
        result = await retry_async(
            partial(
                _run_agent_once,
                agent=agent,
                args=args,
                cfg_run=cfg_run,
                warnings=warnings,
                max_turns=args.max_turns or cfg_run.agent.max_turns,
            ),
            policy=resilience.retry_policy,
            retry_on=provider_retry_exceptions(),
            classify=provider_retry_decision,
            budget=retry_budget,
            cancel_token=cancel_token,
        )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        report = build_agent_run_report_payload(
            tool_call_id=ctx.tool_call_id,
            trace_id=ctx_runtime.trace_id,
            model=args.model,
            instructions=args.instructions,
            input_text=args.input_text,
            result=result,
            tools_available=tools_available,
            warnings=warnings,
        )
        record = await persist_agent_run_report(
            store=AsyncStore(ctx_runtime.db_path),
            session_id=ctx_runtime.session_id,
            source_id=ctx.tool_call_id,
            payload=report,
        )
    except MaxTurnsExceeded as exc:
        return {
            "ok": False,
            "op": AGENT_RUN_OP_RUN,
            "error": {
                "kind": "provider_error",
                "message": str(exc),
                "details": {"reason": "max_turns_exceeded"},
            },
        }, None
    except AgentermError as exc:
        mapped_message, details_raw = map_agent_run_error(str(exc))
        details = details_raw or {}
        kind = "provider_error"
        reason = as_str(details.get("reason"))
        if reason == "policy_denied":
            kind = "policy_denied"
        return {
            "ok": False,
            "op": AGENT_RUN_OP_RUN,
            "error": {
                "kind": kind,
                "message": mapped_message,
                "details": details,
            },
        }, None
    return (
        _agent_run_success_payload(
            cfg=cfg,
            report=report,
            report_id=record.artifact_id,
        ),
        None,
    )


async def _invoke_agent_run(
    ctx: ToolContext[ToolRuntimeContext | None],
    raw: str,
    *,
    cfg: AppConfig,
    workspace_root: Path,
    agent_builder: Callable[..., Agent],
) -> str:
    invocation, immediate_output = _prepare_agent_run_invocation(ctx, raw, cfg=cfg)
    if immediate_output is not None:
        return immediate_output
    if invocation is None:
        return _invalid_payload_output()

    payload_out, error = await _execute_agent_run_invocation(
        ctx,
        invocation,
        cfg=cfg,
        workspace_root=workspace_root,
        agent_builder=agent_builder,
    )
    if error is not None:
        return error
    if payload_out is None:
        return _error_output(
            kind=_TOOL_ERROR_KIND,
            message="Failed to execute delegated run.",
            details={"reason": "execution_failed"},
        )
    env = ToolOutputEnvelope(tool="agent_run", ok=True, result=payload_out)
    return env.to_json_string()


def build_agent_run_tool(
    cfg: AppConfig,
    *,
    workspace_root: Path,
    agent_builder: Callable[..., Agent],
) -> FunctionTool | None:
    """Build the agent_run tool when configured."""
    if cfg.tools.agent_run is None:
        return None
    validate_strict_schema("agent_run", AGENT_RUN_SCHEMA)

    return FunctionTool(
        name="agent_run",
        description=describe_agent_run(),
        params_json_schema=AGENT_RUN_SCHEMA,
        on_invoke_tool=partial(
            _invoke_agent_run,
            cfg=cfg,
            workspace_root=workspace_root,
            agent_builder=agent_builder,
        ),
        strict_json_schema=True,
    )


__all__ = ("AGENT_RUN_REPORT_SCHEMA", "build_agent_run_tool")
