"""MCP bridge wrapper for structured output envelopes and approvals."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import httpx
from agents.mcp import MCPServer
from mcp import types as mtypes
from mcp.shared.exceptions import McpError

from agenterm.core.errors import AgentermError, ValidationError
from agenterm.core.json_codec import (
    dumps_compact,
    require_json_value,
)
from agenterm.core.tool_output_envelope import (
    ToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.mcp_bridge_payload import (
    content_blocks_and_truncation,
    content_text_and_truncation,
    structured_payload,
    text_from_content_blocks,
)
from agenterm.engine.mcp_namespacing import NamespacedMcpServer

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.agent import AgentBase
    from agents.run_context import RunContextWrapper

    from agenterm.config.model import McpBridgeConfig
    from agenterm.core.approvals import McpApprovalManager
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.engine.tool_output_clamp import ToolOutputClamp

_APPROVAL_REJECTED_KIND = "approval_rejected"
_INVALID_INPUT_KIND = "invalid_input"
_MCP_ERROR_KIND = "mcp_error"
_TOOL_ERROR_KIND = "tool_error"
_RESULT_ERROR_KIND = "mcp_call_error"


def _resolve_original_tool_name(server: MCPServer, tool_name: str) -> str:
    if isinstance(server, NamespacedMcpServer):
        return server.resolve_original_tool_name(tool_name)
    return tool_name


def _approval_denied_result(
    *,
    server_key: str,
    tool_name: str,
    original_tool_name: str,
    reason: str | None,
    output_clamp: ToolOutputClamp,
) -> mtypes.CallToolResult:
    details: dict[str, JSONValue] = {}
    if reason:
        details["reason"] = reason
    details["server_key"] = server_key
    details["tool_name"] = original_tool_name
    error = ToolOutputError(
        kind=_APPROVAL_REJECTED_KIND,
        message="MCP tool execution rejected by user.",
        details=details,
    )
    env = ToolOutputEnvelope(
        tool=tool_name,
        ok=False,
        truncated=False,
        limit_reason=None,
        result={},
        error=error,
    )
    env = output_clamp.clamp_function_envelope(env)
    return _call_result_from_envelope(env)


def _error_result(
    *,
    server_key: str,
    tool_name: str,
    original_tool_name: str,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
    output_clamp: ToolOutputClamp,
) -> mtypes.CallToolResult:
    details_map: dict[str, JSONValue] = dict(details) if details is not None else {}
    details_map["server_key"] = server_key
    details_map["tool_name"] = original_tool_name
    error = ToolOutputError(kind=kind, message=message, details=details_map)
    env = ToolOutputEnvelope(
        tool=tool_name,
        ok=False,
        truncated=False,
        limit_reason=None,
        result={},
        error=error,
    )
    env = output_clamp.clamp_function_envelope(env)
    return _call_result_from_envelope(env)


def _call_result_from_envelope(env: ToolOutputEnvelope) -> mtypes.CallToolResult:
    text = ""
    if env.ok:
        payload_kind = env.result.get("payload_kind")
        if payload_kind == "content_blocks":
            text = text_from_content_blocks(env.result.get("payload"))
    elif env.error is not None:
        text = env.error.message
    content: list[mtypes.ContentBlock] = [mtypes.TextContent(type="text", text=text)]
    return mtypes.CallToolResult(
        content=content,
        structuredContent=env.to_json(),
        isError=not env.ok,
    )


@dataclass
class BridgeMcpServer(MCPServer):
    """MCPServer wrapper that enforces approvals and output envelopes."""

    server_key: str
    inner: MCPServer
    approvals: McpApprovalManager
    output_clamp: ToolOutputClamp
    max_content_items: int
    cancel_token: CancelToken | None = None

    def __post_init__(self) -> None:
        """Initialize the MCP server with structured content enabled."""
        super().__init__(
            use_structured_content=True,
            tool_meta_resolver=self.inner.tool_meta_resolver,
        )

    @property
    def name(self) -> str:
        """Return the server's display name."""
        return self.inner.name

    async def connect(self) -> None:
        """Connect the inner MCP server."""
        await self.inner.connect()

    async def cleanup(self) -> None:
        """Cleanup resources for the inner MCP server."""
        await self.inner.cleanup()

    async def list_tools(
        self,
        run_context: RunContextWrapper | None = None,
        agent: AgentBase | None = None,
    ) -> list[mtypes.Tool]:
        """List tools from the inner MCP server."""
        return await self.inner.list_tools(run_context=run_context, agent=agent)

    def _arguments_json_or_error(
        self,
        *,
        tool_name: str,
        original_tool_name: str,
        args_dict: Mapping[str, JSONValue] | None,
    ) -> tuple[str | None, mtypes.CallToolResult | None]:
        try:
            args_json = dumps_compact(
                args_dict or {},
                ensure_ascii=True,
                context="mcp.bridge.arguments",
            )
        except ValidationError as exc:
            return None, _error_result(
                server_key=self.server_key,
                tool_name=tool_name,
                original_tool_name=original_tool_name,
                kind=_INVALID_INPUT_KIND,
                message=str(exc),
                details={"reason": "invalid_arguments"},
                output_clamp=self.output_clamp,
            )
        return args_json, None

    async def _call_inner_or_error(
        self,
        *,
        tool_name: str,
        original_tool_name: str,
        args_dict: Mapping[str, JSONValue] | None,
        meta: Mapping[str, JSONValue] | None,
    ) -> tuple[mtypes.CallToolResult | None, mtypes.CallToolResult | None]:
        try:
            inner_args = dict(args_dict) if args_dict is not None else None
            inner_meta = dict(meta) if meta is not None else None
            return await self.inner.call_tool(
                tool_name,
                inner_args,
                meta=inner_meta,
            ), None
        except McpError as exc:
            details: dict[str, JSONValue] = {"code": int(exc.error.code)}
            if exc.error.data is not None:
                try:
                    details["data"] = require_json_value(
                        value=exc.error.data,
                        context="mcp.bridge.error.data",
                    )
                except ValidationError as data_exc:
                    details["data_error"] = str(data_exc)
            return None, _error_result(
                server_key=self.server_key,
                tool_name=tool_name,
                original_tool_name=original_tool_name,
                kind=_MCP_ERROR_KIND,
                message=exc.error.message,
                details=details,
                output_clamp=self.output_clamp,
            )
        except (TimeoutError, OSError, httpx.HTTPError) as exc:
            return None, _error_result(
                server_key=self.server_key,
                tool_name=tool_name,
                original_tool_name=original_tool_name,
                kind=_TOOL_ERROR_KIND,
                message="MCP transport error.",
                details={
                    "reason": "transport_error",
                    "exception": type(exc).__name__,
                    "message": str(exc),
                },
                output_clamp=self.output_clamp,
            )
        except AgentermError as exc:
            return None, _error_result(
                server_key=self.server_key,
                tool_name=tool_name,
                original_tool_name=original_tool_name,
                kind=_TOOL_ERROR_KIND,
                message=str(exc),
                output_clamp=self.output_clamp,
            )

    def _normalize_result(
        self,
        *,
        tool_name: str,
        original_tool_name: str,
        result: mtypes.CallToolResult,
    ) -> mtypes.CallToolResult:
        try:
            if result.isError:
                text, _ = content_text_and_truncation(
                    result.content,
                    max_items=self.max_content_items,
                )
                message = text or "MCP tool returned an error."
                return _error_result(
                    server_key=self.server_key,
                    tool_name=tool_name,
                    original_tool_name=original_tool_name,
                    kind=_RESULT_ERROR_KIND,
                    message=message,
                    output_clamp=self.output_clamp,
                )

            structured = structured_payload(result.structuredContent)
            truncated = False
            limit_reason: str | None = None
            if structured is not None:
                result_payload: dict[str, JSONValue] = {
                    "server_key": self.server_key,
                    "tool_name": original_tool_name,
                    "payload_kind": "structured",
                    "payload": structured,
                }
            else:
                content_blocks, truncated = content_blocks_and_truncation(
                    result.content,
                    max_items=self.max_content_items,
                )
                result_payload = {
                    "server_key": self.server_key,
                    "tool_name": original_tool_name,
                    "payload_kind": "content_blocks",
                    "payload": content_blocks,
                }
                limit_reason = "content_cap" if truncated else None
            env = ToolOutputEnvelope(
                tool=tool_name,
                ok=True,
                truncated=truncated,
                limit_reason=limit_reason,
                result=result_payload,
            )
            env = self.output_clamp.clamp_function_envelope(env)
            return _call_result_from_envelope(env)
        except ValidationError as exc:
            return _error_result(
                server_key=self.server_key,
                tool_name=tool_name,
                original_tool_name=original_tool_name,
                kind=_TOOL_ERROR_KIND,
                message="Invalid MCP tool response.",
                details={"reason": "invalid_response", "message": str(exc)},
                output_clamp=self.output_clamp,
            )

    async def call_tool(
        self,
        tool_name: str,
        arguments: Mapping[str, JSONValue] | None,
        meta: Mapping[str, JSONValue] | None = None,
    ) -> mtypes.CallToolResult:
        """Call an MCP tool with approvals and envelope normalization."""
        original_name = _resolve_original_tool_name(self.inner, tool_name)
        args_dict = dict(arguments) if arguments is not None else None
        args_json, error = self._arguments_json_or_error(
            tool_name=tool_name,
            original_tool_name=original_name,
            args_dict=args_dict,
        )
        if error is not None:
            return error
        if args_json is None:
            return _error_result(
                server_key=self.server_key,
                tool_name=tool_name,
                original_tool_name=original_name,
                kind=_TOOL_ERROR_KIND,
                message="MCP bridge failed to serialize arguments.",
                details={"reason": "invalid_arguments"},
                output_clamp=self.output_clamp,
            )
        if self.cancel_token is not None:
            self.cancel_token.raise_if_cancelled()
        approval_item = self.approvals.register(
            server_label=self.server_key,
            tool_name=original_name,
            arguments_json=args_json,
        )
        decision = await self.approvals.wait(
            approval_item.id,
            cancel_token=self.cancel_token,
        )
        if not decision.approved:
            return _approval_denied_result(
                server_key=self.server_key,
                tool_name=tool_name,
                original_tool_name=original_name,
                reason=decision.reason,
                output_clamp=self.output_clamp,
            )
        if self.cancel_token is not None:
            self.cancel_token.raise_if_cancelled()
        result, call_error = await self._call_inner_or_error(
            tool_name=tool_name,
            original_tool_name=original_name,
            args_dict=args_dict,
            meta=meta,
        )
        if call_error is not None:
            return call_error
        if result is None:
            return _error_result(
                server_key=self.server_key,
                tool_name=tool_name,
                original_tool_name=original_name,
                kind=_TOOL_ERROR_KIND,
                message="MCP bridge failed to call tool.",
                details={"reason": "transport_error"},
                output_clamp=self.output_clamp,
            )
        return self._normalize_result(
            tool_name=tool_name,
            original_tool_name=original_name,
            result=result,
        )

    async def list_prompts(self) -> mtypes.ListPromptsResult:
        """List prompts from the inner MCP server."""
        return await self.inner.list_prompts()

    async def get_prompt(
        self,
        name: str,
        arguments: Mapping[str, JSONValue] | None = None,
    ) -> mtypes.GetPromptResult:
        """Fetch a prompt from the inner MCP server."""
        args_dict = dict(arguments) if arguments is not None else None
        return await self.inner.get_prompt(name, args_dict)


def wrap_mcp_servers(
    servers: Sequence[MCPServer],
    *,
    approvals: McpApprovalManager,
    bridge_cfg: McpBridgeConfig,
    output_clamp: ToolOutputClamp,
    cancel_token: CancelToken | None = None,
) -> list[MCPServer]:
    """Wrap MCP servers with the bridge when not already wrapped."""
    out: list[MCPServer] = []
    for server in servers:
        if isinstance(server, BridgeMcpServer):
            if server.cancel_token is cancel_token:
                out.append(server)
            else:
                out.append(
                    BridgeMcpServer(
                        server_key=server.server_key,
                        inner=server.inner,
                        approvals=approvals,
                        output_clamp=output_clamp,
                        max_content_items=bridge_cfg.max_content_items,
                        cancel_token=cancel_token,
                    )
                )
            continue
        server_key = server.name
        if isinstance(server, NamespacedMcpServer):
            server_key = server.server_key
            out.append(
                BridgeMcpServer(
                    server_key=server_key,
                    inner=server,
                    approvals=approvals,
                    output_clamp=output_clamp,
                    max_content_items=bridge_cfg.max_content_items,
                    cancel_token=cancel_token,
                )
            )
    return out


__all__ = ("BridgeMcpServer", "wrap_mcp_servers")
