"""Config-driven structured output schema for Agents.

This module bridges `AppConfig.model.text_format` (a TextFormat DTO) into an
Agents `AgentOutputSchemaBase` implementation. When a JSON-schema format is
configured, the engine passes this schema as `Agent.output_type` so the
Agents Responses model can enable Structured Outputs.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agents.agent_output import AgentOutputSchemaBase
from agents.exceptions import ModelBehaviorError, UserError
from agents.strict_schema import ensure_strict_json_schema

from agenterm.core.errors import ConfigError, ValidationError
from agenterm.core.json_codec import loads_json_value, require_json_object
from agenterm.engine.schema_validation import validate_strict_schema

if TYPE_CHECKING:
    from collections.abc import Mapping, MutableMapping

    from agenterm.config.text_format import TextFormat
    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class ConfigAgentOutputSchema(AgentOutputSchemaBase):
    """AgentOutputSchemaBase backed directly by a config-supplied JSON schema.

    This schema is treated as authoritative for Responses structured outputs.
    Validation is limited to checking that the model emits valid JSON; full
    JSON-schema validation is delegated to the server-side Structured Outputs
    machinery.
    """

    _name: str
    _schema: Mapping[str, JSONValue]
    _strict: bool

    def is_plain_text(self) -> bool:
        """Structured outputs are never plain text."""
        return False

    def name(self) -> str:
        """Return the configured schema name."""
        return self._name

    def json_schema(self) -> dict[str, JSONValue]:
        """Return the JSON schema payload."""
        return dict(self._schema)

    def is_strict_json_schema(self) -> bool:
        """Return whether the schema should be enforced strictly."""
        return self._strict

    def validate_json(self, json_str: str) -> JSONValue:
        """Validate JSON emitted by the model against basic well-formedness.

        On invalid JSON, raises ModelBehaviorError; otherwise returns the
        decoded Python value. Detailed schema validation is intentionally
        left to the server-side Structured Outputs engine.
        """
        try:
            return loads_json_value(json_str)
        except (TypeError, ValueError) as e:
            message = f"Invalid JSON for structured output: {e}"
            raise ModelBehaviorError(message) from e


def build_output_schema_from_text_format(
    text_format: TextFormat | None,
) -> AgentOutputSchemaBase | None:
    r"""Return an AgentOutputSchemaBase derived from a TextFormat descriptor.

    Only JSON-schema formats are mapped; plain `type: "text"` formats are
    treated as unstructured text and do not install a structured output schema.
    """
    if text_format is None:
        return None
    t = text_format.get("type")
    if t != "json_schema":
        # Plain text formats do not install a structured schema.
        return None

    if "schema" not in text_format or "name" not in text_format:
        return None
    schema_obj = text_format["schema"]
    name_obj = text_format["name"]
    strict_flag = text_format.get("strict")
    strict = bool(strict_flag) if isinstance(strict_flag, bool) else True

    try:
        schema_copy: MutableMapping[str, JSONValue] = require_json_object(
            value=schema_obj,
            context="model.text_format.schema",
        )
    except ValidationError as exc:
        msg = "model.text_format.schema must be JSON-safe"
        raise ConfigError(msg) from exc

    validate_strict_schema("model.text_format.schema", schema_copy)
    try:
        strict_schema = ensure_strict_json_schema(dict(schema_copy))
    except UserError as exc:
        msg = f"model.text_format.schema must be strict-compatible: {exc}"
        raise ConfigError(msg) from exc
    try:
        schema_copy = require_json_object(
            value=strict_schema,
            context="model.text_format.schema.strict",
        )
    except ValidationError as exc:
        msg = "model.text_format.schema must be JSON-safe after strict normalization"
        raise ConfigError(msg) from exc

    return ConfigAgentOutputSchema(_name=name_obj, _schema=schema_copy, _strict=strict)


__all__ = ("ConfigAgentOutputSchema", "build_output_schema_from_text_format")
