"""Provider capability resolution for compression and attachments."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.model_id import model_plane
from agenterm.engine.model_provider import gateway_route_for_model

if TYPE_CHECKING:
    from agenterm.config.model import AppConfig


@dataclass(frozen=True)
class ProviderCapabilities:
    """Resolved provider capabilities for a model plane."""

    supports_compaction: bool
    supports_snapshot: bool
    supports_file_id: bool
    supports_image_url: bool
    allow_inline_data_url: bool


def resolve_provider_capabilities(
    cfg: AppConfig,
    *,
    model_id: str,
) -> ProviderCapabilities:
    """Resolve provider capabilities for a model id."""
    plane = model_plane(model_id)
    if plane == "openai":
        return ProviderCapabilities(
            supports_compaction=True,
            supports_snapshot=True,
            supports_file_id=True,
            supports_image_url=True,
            allow_inline_data_url=True,
        )

    route_info = gateway_route_for_model(cfg.providers, model_id=model_id)
    if route_info is None:
        msg = f"Unknown gateway route for model id {model_id!r}"
        raise ConfigError(msg)
    _, route_cfg = route_info
    return ProviderCapabilities(
        supports_compaction=bool(route_cfg.supports_compaction),
        supports_snapshot=True,
        supports_file_id=bool(route_cfg.supports_file_id),
        supports_image_url=bool(route_cfg.supports_image_url),
        allow_inline_data_url=bool(route_cfg.allow_inline_data_url),
    )


__all__ = ("ProviderCapabilities", "resolve_provider_capabilities")
