"""Pre-flight validation for tool schemas.

This module validates that JSON schemas are compatible with OpenAI's strict
mode constraints before sending to the API. Catches errors at build time
with clear messages instead of cryptic API errors at runtime.
"""

from __future__ import annotations

from copy import deepcopy
from typing import TYPE_CHECKING

from agents.exceptions import UserError
from agents.strict_schema import ensure_strict_json_schema

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import require_json_object

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

_ROOT_FORBIDDEN_KEYS: frozenset[str] = frozenset(
    {"allOf", "anyOf", "enum", "not", "oneOf"}
)


def validate_strict_schema(
    tool_name: str,
    schema: Mapping[str, JSONValue],
) -> None:
    """Validate schema is compatible with OpenAI strict mode.

    Validation is intentionally vendor-aligned: it delegates strict-mode
    normalization rules to the Agents SDK (`ensure_strict_json_schema`) on a
    copy of the schema so agenterm does not drift from runtime behavior.

    agenterm policy constraints:
    - Tool parameter schemas must resolve to a root JSON object schema
      (`type:"object"`).
    - Root schemas must not declare root-level unions (`anyOf`/`oneOf`/`allOf`);
      encode unions under a required root property instead.

    Args:
        tool_name: Name of the tool (for error messages).
        schema: The JSON schema to validate.

    Raises:
        ConfigError: If schema is incompatible with strict mode.

    """
    schema_copy = deepcopy(dict(schema))
    try:
        normalized_raw = ensure_strict_json_schema(schema_copy)
    except (AssertionError, TypeError, UserError, ValueError) as exc:
        msg = (
            f"Tool '{tool_name}' has invalid schema for strict mode: "
            f"{exc.__class__.__name__}: {exc}"
        )
        raise ConfigError(msg) from exc

    normalized = require_json_object(
        value=normalized_raw,
        context=f"tool_schema.strict.{tool_name}",
    )
    if normalized.get("type") != "object":
        msg = (
            f"Tool '{tool_name}' has invalid schema for strict mode: "
            "tool parameters root schema must be an object."
        )
        raise ConfigError(msg)
    found = sorted(key for key in _ROOT_FORBIDDEN_KEYS if key in normalized)
    if found:
        joined = ", ".join(found)
        msg = (
            f"Tool '{tool_name}' has invalid schema for strict mode: "
            f"schema must not include {joined} at the root."
        )
        raise ConfigError(msg)


__all__ = ("validate_strict_schema",)
