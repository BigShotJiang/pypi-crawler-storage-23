"""Strict parsers for tool configuration JSON shapes."""

from __future__ import annotations

from collections.abc import Mapping
from types import MappingProxyType
from typing import TYPE_CHECKING, Literal

from openai.types.responses.web_search_tool import Filters as WebSearchModelFilters
from openai.types.shared_params.comparison_filter import ComparisonFilter
from openai.types.shared_params.compound_filter import CompoundFilter

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from openai.types.responses.file_search_tool_param import (
        Filters as FileSearchFilters,
    )
    from openai.types.responses.file_search_tool_param import (
        RankingOptions,
        RankingOptionsHybridSearch,
    )
    from openai.types.responses.tool_param import (
        ImageGeneration,
        ImageGenerationInputImageMask,
    )
    from openai.types.responses.web_search_tool_param import UserLocation

    from agenterm.config.tool_models import ImageGenerationToolConfig
    from agenterm.core.json_types import JSONValue

type FilterValue = str | float | bool | list[str | float]

_ALLOWED_COMPARISON_TYPES: set[str] = {"eq", "ne", "gt", "gte", "lt", "lte"}
_ALLOWED_RANKERS: set[str] = {"auto", "default-2024-11-15"}
_IMAGE_CHOICE_FIELDS: Mapping[str, set[str]] = MappingProxyType(
    {
        "background": {"transparent", "opaque", "auto"},
        "input_fidelity": {"high", "low"},
        "moderation": {"auto", "low"},
        "output_format": {"png", "webp", "jpeg"},
        "quality": {"low", "medium", "high", "auto"},
        "size": {"1024x1024", "1024x1536", "1536x1024", "auto"},
    },
)


def _ensure_allowed_keys(
    raw: Mapping[str, JSONValue],
    *,
    allowed: set[str],
    context: str,
) -> None:
    extra = {key for key in raw if key not in allowed}
    if extra:
        msg = f"{context} has unsupported keys: {sorted(extra)}"
        raise ConfigError(msg)


def _require_mapping(raw: JSONValue | None, *, context: str) -> Mapping[str, JSONValue]:
    if not isinstance(raw, Mapping):
        msg = f"{context} must be a JSON object"
        raise ConfigError(msg)
    return raw


def _require_non_empty_str(value: JSONValue | None, *, context: str) -> str:
    if not isinstance(value, str) or not value:
        msg = f"{context} must be a non-empty string"
        raise ConfigError(msg)
    return value


def _require_number(value: JSONValue | None, *, context: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        msg = f"{context} must be a number"
        raise ConfigError(msg)
    return float(value)


def _parse_ranker(
    value: JSONValue | None,
) -> Literal["auto", "default-2024-11-15"] | None:
    if value is None:
        return None
    if value == "auto":
        return "auto"
    if value == "default-2024-11-15":
        return "default-2024-11-15"
    msg = "file_search.ranking_options.ranker must be auto or default-2024-11-15"
    raise ConfigError(msg)


def _parse_score_threshold(value: JSONValue | None) -> float | None:
    if value is None:
        return None
    return _require_number(value, context="file_search.ranking_options.score_threshold")


def _parse_hybrid_search(raw: JSONValue | None) -> RankingOptionsHybridSearch:
    hs_raw = _require_mapping(raw, context="file_search.ranking_options.hybrid_search")
    _ensure_allowed_keys(
        hs_raw,
        allowed={"embedding_weight", "text_weight"},
        context="file_search.ranking_options.hybrid_search",
    )
    emb = _require_number(
        hs_raw.get("embedding_weight"),
        context="file_search.ranking_options.hybrid_search.embedding_weight",
    )
    txt = _require_number(
        hs_raw.get("text_weight"),
        context="file_search.ranking_options.hybrid_search.text_weight",
    )
    return {
        "embedding_weight": emb,
        "text_weight": txt,
    }


def parse_file_search_ranking_options(
    raw: Mapping[str, JSONValue] | None,
) -> RankingOptions | None:
    """Validate file_search.ranking_options JSON mapping."""
    if raw is None:
        return None
    _ensure_allowed_keys(
        raw,
        allowed={"hybrid_search", "ranker", "score_threshold"},
        context="file_search.ranking_options",
    )
    out: RankingOptions = {}
    if "hybrid_search" in raw:
        out["hybrid_search"] = _parse_hybrid_search(raw.get("hybrid_search"))
    ranker = _parse_ranker(raw.get("ranker"))
    if ranker is not None:
        out["ranker"] = ranker
    score = _parse_score_threshold(raw.get("score_threshold"))
    if score is not None:
        out["score_threshold"] = score
    if not out:
        msg = "file_search.ranking_options must include at least one valid field"
        raise ConfigError(msg)
    return out


def _parse_filter_value(value: JSONValue | None, *, context: str) -> FilterValue:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        if not value:
            msg = f"{context} must be a non-empty list"
            raise ConfigError(msg)
        seq: list[str | float] = []
        for idx, item in enumerate(value):
            if isinstance(item, bool):
                msg = f"{context}[{idx}] must be string or number"
                raise ConfigError(msg)
            if isinstance(item, (int, float)):
                seq.append(float(item))
                continue
            if isinstance(item, str):
                seq.append(item)
                continue
            msg = f"{context}[{idx}] must be string or number"
            raise ConfigError(msg)
        return seq
    msg = f"{context} must be string, number, boolean, or list"
    raise ConfigError(msg)


def _parse_comparison_filter(
    raw: Mapping[str, JSONValue],
    *,
    context: str,
) -> ComparisonFilter:
    _ensure_allowed_keys(raw, allowed={"key", "type", "value"}, context=context)
    key = _require_non_empty_str(raw.get("key"), context=f"{context}.key")
    kind = _require_non_empty_str(raw.get("type"), context=f"{context}.type")
    kind_literal: Literal["eq", "ne", "gt", "gte", "lt", "lte"]
    if kind == "eq":
        kind_literal = "eq"
    elif kind == "ne":
        kind_literal = "ne"
    elif kind == "gt":
        kind_literal = "gt"
    elif kind == "gte":
        kind_literal = "gte"
    elif kind == "lt":
        kind_literal = "lt"
    elif kind == "lte":
        kind_literal = "lte"
    else:
        msg = f"{context}.type must be one of: {sorted(_ALLOWED_COMPARISON_TYPES)}"
        raise ConfigError(msg)
    value = _parse_filter_value(raw.get("value"), context=f"{context}.value")
    try:
        return ComparisonFilter(key=key, type=kind_literal, value=value)
    except (TypeError, ValueError) as exc:
        msg = f"{context} is not valid: {exc}"
        raise ConfigError(msg) from exc


def _parse_compound_filter(
    raw: Mapping[str, JSONValue],
    *,
    context: str,
    kind: Literal["and", "or"],
) -> CompoundFilter:
    _ensure_allowed_keys(raw, allowed={"type", "filters"}, context=context)
    filters_raw = raw.get("filters")
    if not isinstance(filters_raw, list) or not filters_raw:
        msg = f"{context}.filters must be a non-empty list"
        raise ConfigError(msg)
    children: list[ComparisonFilter | CompoundFilter] = []
    for idx, item in enumerate(filters_raw):
        if not isinstance(item, Mapping):
            msg = f"{context}.filters[{idx}] must be an object"
            raise ConfigError(msg)
        children.append(_parse_filter_node(item, context=f"{context}.filters[{idx}]"))
    return CompoundFilter(type=kind, filters=children)


def _parse_filter_node(
    raw: Mapping[str, JSONValue],
    *,
    context: str,
) -> ComparisonFilter | CompoundFilter:
    kind = _require_non_empty_str(raw.get("type"), context=f"{context}.type")
    if kind in {"and", "or"}:
        kind_literal: Literal["and", "or"] = "and" if kind == "and" else "or"
        return _parse_compound_filter(raw, context=context, kind=kind_literal)
    return _parse_comparison_filter(raw, context=context)


def parse_file_search_filters(
    raw: Mapping[str, JSONValue] | None,
) -> FileSearchFilters | None:
    """Validate file_search.filters JSON mapping."""
    if raw is None:
        return None
    return _parse_filter_node(raw, context="file_search.filters")


def parse_web_search_filters(
    raw: Mapping[str, JSONValue] | None,
) -> WebSearchModelFilters | None:
    """Validate web_search.filters JSON mapping."""
    if raw is None:
        return None
    _ensure_allowed_keys(
        raw,
        allowed={"allowed_domains"},
        context="web_search.filters",
    )
    allowed = raw.get("allowed_domains")
    if not isinstance(allowed, list) or not allowed:
        msg = "web_search.filters.allowed_domains must be a non-empty list"
        raise ConfigError(msg)
    domains: list[str] = []
    for idx, item in enumerate(allowed):
        if not isinstance(item, str) or not item:
            msg = f"web_search.filters.allowed_domains[{idx}] must be a string"
            raise ConfigError(msg)
        domains.append(item)
    return WebSearchModelFilters(allowed_domains=domains)


def parse_web_search_user_location(
    raw: Mapping[str, JSONValue] | None,
) -> UserLocation | None:
    """Validate web_search.user_location JSON mapping."""
    if raw is None:
        return None
    _ensure_allowed_keys(
        raw,
        allowed={"type", "city", "country", "region", "timezone"},
        context="web_search.user_location",
    )
    typ = raw.get("type")
    if typ != "approximate":
        msg = "web_search.user_location.type must be 'approximate'"
        raise ConfigError(msg)
    out: UserLocation = {"type": "approximate"}
    city = raw.get("city")
    if city is not None:
        out["city"] = _require_non_empty_str(
            city,
            context="web_search.user_location.city",
        )
    country = raw.get("country")
    if country is not None:
        out["country"] = _require_non_empty_str(
            country,
            context="web_search.user_location.country",
        )
    region = raw.get("region")
    if region is not None:
        out["region"] = _require_non_empty_str(
            region,
            context="web_search.user_location.region",
        )
    timezone = raw.get("timezone")
    if timezone is not None:
        out["timezone"] = _require_non_empty_str(
            timezone,
            context="web_search.user_location.timezone",
        )
    return out


def parse_image_generation_config(
    cfg: ImageGenerationToolConfig,
) -> ImageGeneration:
    """Validate image_generation tool config and build request params."""
    params: ImageGeneration = {"type": "image_generation"}
    if cfg.model is not None:
        model = cfg.model.strip()
        if not model:
            msg = "image_generation.model must be a non-empty string or null"
            raise ConfigError(msg)
        params["model"] = model
    cfg_dict = vars(cfg)
    for field, allowed in _IMAGE_CHOICE_FIELDS.items():
        val = cfg_dict.get(field)
        if val is None:
            continue
        if val not in allowed:
            msg = f"image_generation.{field} must be one of: {sorted(allowed)}"
            raise ConfigError(msg)
        params[field] = val
    for field in ("output_compression", "partial_images"):
        val = cfg_dict.get(field)
        if val is None:
            continue
        if isinstance(val, bool) or not isinstance(val, int):
            msg = f"image_generation.{field} must be an integer"
            raise ConfigError(msg)
        params[field] = int(val)
    mask = _parse_image_mask(cfg.input_image_mask)
    if mask is not None:
        params["input_image_mask"] = mask
    return params


def _parse_image_mask(
    raw: Mapping[str, JSONValue] | None,
) -> ImageGenerationInputImageMask | None:
    if raw is None:
        return None
    _ensure_allowed_keys(
        raw,
        allowed={"file_id", "image_url"},
        context="image_generation.input_image_mask",
    )
    out: ImageGenerationInputImageMask = {}
    file_id = raw.get("file_id")
    image_url = raw.get("image_url")
    if file_id is not None:
        out["file_id"] = _require_non_empty_str(
            file_id,
            context="image_generation.input_image_mask.file_id",
        )
    if image_url is not None:
        out["image_url"] = _require_non_empty_str(
            image_url,
            context="image_generation.input_image_mask.image_url",
        )
    if not out:
        msg = "image_generation.input_image_mask must include file_id or image_url"
        raise ConfigError(msg)
    return out


__all__ = (
    "parse_file_search_filters",
    "parse_file_search_ranking_options",
    "parse_image_generation_config",
    "parse_web_search_filters",
    "parse_web_search_user_location",
)
