"""Schema and payload parsing for canonical shell FunctionTool calls."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.json_codec import as_str, parse_json_object

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

_ENV_ENTRY_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "properties": {
        "name": {"type": "string", "minLength": 1},
        "value": {"type": "string"},
    },
    "required": ["name", "value"],
    "additionalProperties": False,
}

SHELL_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Shell execution parameters.",
    "properties": {
        "commands": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 1,
            "description": "Commands to run in order.",
        },
        "approval_label": {
            "type": ["string", "null"],
            "description": "Approval label shown to the user.",
        },
        "cwd": {
            "type": ["string", "null"],
            "description": "Workspace-relative working directory (null uses root).",
        },
        "env": {
            "type": ["array", "null"],
            "items": _ENV_ENTRY_SCHEMA,
            "description": "Per-call environment variable entries.",
        },
        "timeout_ms": {
            "type": ["integer", "null"],
            "minimum": 1,
            "description": "Per-command timeout in ms (null uses config).",
        },
        "max_output_chars": {
            "type": "integer",
            "minimum": 0,
            "description": "Max stdout+stderr chars per command.",
        },
    },
    "required": [
        "commands",
        "approval_label",
        "cwd",
        "env",
        "timeout_ms",
        "max_output_chars",
    ],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class ParsedShellPayload:
    """Parsed shell payload."""

    commands: list[str]
    timeout_ms: int | None
    max_output_chars: int
    approval_label: str | None
    cwd: str | None
    env_override: dict[str, str] | None


def _parse_commands(payload: Mapping[str, JSONValue]) -> list[str] | None:
    commands_raw = payload.get("commands")
    if not isinstance(commands_raw, list) or not commands_raw:
        return None
    commands: list[str] = []
    for item in commands_raw:
        if not isinstance(item, str):
            return None
        cmd = item.strip()
        if not cmd:
            return None
        commands.append(cmd)
    return commands


def _parse_optional_int(
    value: JSONValue | None,
    *,
    min_value: int,
) -> int | None:
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool) or value < min_value:
        return None
    return int(value)


def _parse_env(value: JSONValue | None) -> dict[str, str] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        return None
    env_out: dict[str, str] = {}
    for entry in value:
        if not isinstance(entry, dict):
            return None
        name = as_str(entry.get("name"))
        env_value = as_str(entry.get("value"))
        if name is None or not name.strip() or env_value is None:
            return None
        env_out[name] = env_value
    return env_out


def _optional_clean_string(
    payload: Mapping[str, JSONValue],
    *,
    key: str,
) -> str | None:
    raw = as_str(payload.get(key))
    if raw is None:
        return None
    cleaned = raw.strip()
    return cleaned or None


def parse_shell_payload(raw: str) -> ParsedShellPayload | None:
    """Parse shell tool payload."""
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None
    required = {
        "commands",
        "approval_label",
        "cwd",
        "env",
        "timeout_ms",
        "max_output_chars",
    }
    if set(payload) != required:
        return None

    commands = _parse_commands(payload)

    timeout_raw = payload.get("timeout_ms")
    timeout_ms = _parse_optional_int(timeout_raw, min_value=1)

    max_output_chars = _parse_optional_int(
        payload.get("max_output_chars"),
        min_value=0,
    )

    env_raw = payload.get("env")
    env_override = _parse_env(env_raw)

    if commands is None or max_output_chars is None:
        return None
    if timeout_raw is not None and timeout_ms is None:
        return None
    if env_raw is not None and env_override is None:
        return None

    return ParsedShellPayload(
        commands=commands,
        timeout_ms=timeout_ms,
        max_output_chars=max_output_chars,
        approval_label=_optional_clean_string(payload, key="approval_label"),
        cwd=_optional_clean_string(payload, key="cwd"),
        env_override=env_override,
    )


__all__ = ("SHELL_SCHEMA", "ParsedShellPayload", "parse_shell_payload")
