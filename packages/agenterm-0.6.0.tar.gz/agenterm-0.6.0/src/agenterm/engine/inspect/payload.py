"""Payload parsing/validation for the native inspect tool."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ValidationError
from agenterm.core.json_codec import as_str, parse_json_object, require_json_object
from agenterm.core.tool_output_envelope import ToolOutputError
from agenterm.engine.cli_tools.shared import INVALID_INPUT_KIND, error_output
from agenterm.engine.inspect.constants import (
    ALLOWED_INSPECT_OPS,
    tool_name_for_operation,
)
from agenterm.engine.inspect.model import InspectOperation

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.tool import FunctionTool

    from agenterm.core.json_types import JSONValue


def _json_string_list(values: Sequence[str]) -> list[JSONValue]:
    items: list[JSONValue] = []
    items.extend(values)
    return items


_ALLOWED_OPS_JSON: list[JSONValue] = _json_string_list(sorted(ALLOWED_INSPECT_OPS))


def invalid_inspect_input(
    message: str,
    *,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    """Return a typed invalid-input envelope for `inspect`."""
    detail_payload: dict[str, JSONValue] = (
        dict(details)
        if details is not None
        else {"field": "/", "reason": "invalid_payload"}
    )
    if "allowed_ops" not in detail_payload:
        detail_payload["allowed_ops"] = list(_ALLOWED_OPS_JSON)
    if "required_non_null" not in detail_payload:
        detail_payload["required_non_null"] = []
    if "must_be_null" not in detail_payload:
        detail_payload["must_be_null"] = []
    if "example" not in detail_payload:
        detail_payload["example"] = {
            "requests": [_EXAMPLE_REQUEST_ENTRIES["runtime_info"]],
        }
    return error_output(
        "inspect",
        kind=INVALID_INPUT_KIND,
        message=message,
        details=detail_payload,
    )


_EXAMPLE_REQUEST_ENTRIES: dict[str, dict[str, JSONValue]] = {
    "search_text": {
        "op": "search_text",
        "request_id": None,
        "pattern": "todo",
        "pattern_mode": "auto",
        "case_mode": "smart",
        "paths": ["src"],
        "glob": [],
        "context": {"before": 0, "after": 0},
        "result_mode": "matches",
        "offset": 0,
        "limit": 200,
        "max_line_chars": 500,
    },
    "find_paths": {
        "op": "find_paths",
        "request_id": None,
        "pattern": "py",
        "pattern_mode": "auto",
        "paths": ["src"],
        "max_depth": None,
        "type": "any",
        "exclude": [],
        "offset": 0,
        "limit": 200,
    },
    "read_file": {
        "op": "read_file",
        "request_id": None,
        "path": "README.md",
        "start_line": 1,
        "limit_lines": 200,
        "max_chars": 20000,
    },
    "read_bytes": {
        "op": "read_bytes",
        "request_id": None,
        "path": "assets/logo.png",
        "offset": 0,
        "max_bytes": 32768,
    },
    "list_tree": {
        "op": "list_tree",
        "request_id": None,
        "path": ".",
        "depth": 3,
        "pattern_glob": None,
        "match_dirs": False,
        "include_hidden": False,
        "dirs_only": False,
        "gitignore": True,
        "offset": 0,
        "limit": 200,
    },
    "path_stats": {
        "op": "path_stats",
        "request_id": None,
        "paths": ["README.md"],
        "include_lines": True,
    },
    "runtime_info": {"op": "runtime_info", "request_id": None, "mode": "default"},
}


def _example_request_entry(op_name: str) -> dict[str, JSONValue] | None:
    return _EXAMPLE_REQUEST_ENTRIES.get(op_name)


def _parse_request_id(
    entry: Mapping[str, JSONValue],
    *,
    idx: int,
    op_name: str,
) -> tuple[str | None, dict[str, JSONValue] | None]:
    if "request_id" not in entry:
        return None, operation_invalid_entry(
            idx,
            op_name=op_name,
            request_id=None,
            message="inspect.requests request_id is required (string or null).",
            details={
                "field": f"/requests/{idx}/request_id",
                "reason": "required",
                "required_non_null": [],
                "must_be_null": [],
            },
        )
    raw = entry.get("request_id")
    if raw is None:
        return None, None
    if not isinstance(raw, str):
        return None, operation_invalid_entry(
            idx,
            op_name=op_name,
            request_id=None,
            message="inspect.requests request_id must be a string or null.",
            details={
                "field": f"/requests/{idx}/request_id",
                "reason": "invalid_type",
                "must_be_null": [],
                "required_non_null": [],
            },
        )
    cleaned = raw.strip()
    if not cleaned:
        return None, operation_invalid_entry(
            idx,
            op_name=op_name,
            request_id=None,
            message="inspect.requests request_id must be a non-empty string when set.",
            details={
                "field": f"/requests/{idx}/request_id",
                "reason": "invalid_value",
                "must_be_null": [],
                "required_non_null": [],
            },
        )
    return cleaned, None


def _parse_request_arguments(
    entry: Mapping[str, JSONValue],
    *,
    idx: int,
    op_name: str,
    request_id: str | None,
) -> tuple[dict[str, JSONValue] | None, dict[str, JSONValue] | None]:
    args_raw: dict[str, JSONValue] = {}
    for key, value in entry.items():
        if key in {"op", "request_id"}:
            continue
        args_raw[key] = value
    try:
        parsed = require_json_object(
            value=args_raw,
            context=f"inspect.requests[{idx}]",
        )
    except ValidationError as exc:
        return None, operation_invalid_entry(
            idx,
            op_name=op_name,
            request_id=request_id,
            message=str(exc),
            details={"field": f"/requests/{idx}", "reason": "invalid_args"},
        )
    return parsed, None


def operation_invalid_entry(
    idx: int,
    *,
    op_name: str | None,
    request_id: str | None,
    message: str,
    details: Mapping[str, JSONValue],
) -> dict[str, JSONValue]:
    """Build one failed request entry in the ordered inspect response list."""
    detail_payload = dict(details)
    if "allowed_ops" not in detail_payload:
        detail_payload["allowed_ops"] = list(_ALLOWED_OPS_JSON)
    if "required_non_null" not in detail_payload:
        detail_payload["required_non_null"] = []
    if "must_be_null" not in detail_payload:
        detail_payload["must_be_null"] = []
    if "example" not in detail_payload:
        if isinstance(op_name, str):
            example = _example_request_entry(op_name)
            if example is not None:
                detail_payload["example"] = example
        else:
            detail_payload["example"] = _EXAMPLE_REQUEST_ENTRIES["runtime_info"]
    err = ToolOutputError(
        kind=INVALID_INPUT_KIND,
        message=message,
        details=detail_payload,
    )
    return {
        "index": int(idx),
        "op": op_name or "unknown",
        "request_id": request_id,
        "status": "error",
        "result": {},
        "error": err.to_json(),
        "truncated": False,
        "limit_reason": None,
    }


def parse_request_entry(
    entry: JSONValue,
    *,
    idx: int,
    tools: Mapping[str, FunctionTool],
) -> tuple[InspectOperation | None, dict[str, JSONValue] | None]:
    """Validate one request object from `inspect.requests`."""
    mapped_entry, entry_error = _entry_mapping_or_error(entry, idx=idx)
    if entry_error is not None or mapped_entry is None:
        return None, entry_error
    op_name, op_error = _op_name_or_error(mapped_entry, idx=idx)
    if op_error is not None or op_name is None:
        return None, op_error
    request_id, request_id_error = _parse_request_id(
        mapped_entry,
        idx=idx,
        op_name=op_name,
    )
    if request_id_error is not None:
        return None, request_id_error
    tool_name, tool, binding_error = _tool_binding_or_error(
        op_name=op_name,
        idx=idx,
        request_id=request_id,
        tools=tools,
    )
    if binding_error is not None or tool_name is None or tool is None:
        return None, binding_error
    arguments, args_error = _parse_request_arguments(
        mapped_entry,
        idx=idx,
        op_name=op_name,
        request_id=request_id,
    )
    if args_error is not None or arguments is None:
        return None, args_error
    return (
        InspectOperation(
            index=idx,
            op_name=op_name,
            request_id=request_id,
            tool_name=tool_name,
            arguments=arguments,
            tool=tool,
        ),
        None,
    )


def _entry_mapping_or_error(
    entry: JSONValue,
    *,
    idx: int,
) -> tuple[Mapping[str, JSONValue] | None, dict[str, JSONValue] | None]:
    if isinstance(entry, dict):
        return entry, None
    return (
        None,
        operation_invalid_entry(
            idx,
            op_name=None,
            request_id=None,
            message="inspect.requests entries must be objects.",
            details={"field": f"/requests/{idx}", "reason": "invalid_type"},
        ),
    )


def _op_name_or_error(
    entry: Mapping[str, JSONValue],
    *,
    idx: int,
) -> tuple[str | None, dict[str, JSONValue] | None]:
    op_name = as_str(entry.get("op"))
    if not op_name:
        return (
            None,
            operation_invalid_entry(
                idx,
                op_name=None,
                request_id=None,
                message="inspect.requests op must be a non-empty string.",
                details={"field": f"/requests/{idx}/op", "reason": "missing_op"},
            ),
        )
    if op_name in ALLOWED_INSPECT_OPS:
        return op_name, None
    return (
        None,
        operation_invalid_entry(
            idx,
            op_name=op_name,
            request_id=None,
            message="inspect.requests op is not allowed.",
            details={
                "field": f"/requests/{idx}/op",
                "reason": "invalid_op",
                "op": op_name,
            },
        ),
    )


def _tool_binding_or_error(
    *,
    op_name: str,
    idx: int,
    request_id: str | None,
    tools: Mapping[str, FunctionTool],
) -> tuple[str | None, FunctionTool | None, dict[str, JSONValue] | None]:
    tool_name = tool_name_for_operation(op_name)
    if tool_name is None:
        return (
            None,
            None,
            operation_invalid_entry(
                idx,
                op_name=op_name,
                request_id=request_id,
                message="inspect.requests op is not mapped.",
                details={
                    "field": f"/requests/{idx}/op",
                    "reason": "op_not_mapped",
                    "op": op_name,
                },
            ),
        )
    tool = tools.get(tool_name)
    if tool is not None:
        return tool_name, tool, None
    return (
        None,
        None,
        operation_invalid_entry(
            idx,
            op_name=op_name,
            request_id=request_id,
            message="inspect.requests op is not available.",
            details={
                "field": f"/requests/{idx}/op",
                "reason": "op_not_available",
                "op": op_name,
            },
        ),
    )


def parse_inspect_payload(
    raw: str,
    *,
    max_operations: int,
    tools: Mapping[str, FunctionTool],
) -> tuple[
    list[InspectOperation | None] | None,
    list[dict[str, JSONValue] | None] | None,
    str | None,
]:
    """Parse/validate `inspect` payload and return requests plus response slots."""
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, None, invalid_inspect_input("Invalid inspect payload.")
    unknown_keys = sorted(set(payload) - {"requests"})
    if unknown_keys:
        return (
            None,
            None,
            invalid_inspect_input(
                "inspect payload contains unknown keys.",
                details={
                    "field": "/",
                    "reason": "unknown_keys",
                    "unknown_keys": _json_string_list(unknown_keys),
                    "allowed_keys": _json_string_list(["requests"]),
                },
            ),
        )
    requests_raw = payload.get("requests")
    if not isinstance(requests_raw, list) or not requests_raw:
        return (
            None,
            None,
            invalid_inspect_input(
                "inspect.requests must be a non-empty list.",
                details={
                    "field": "/requests",
                    "reason": "required_non_null",
                    "required_non_null": _json_string_list(["requests"]),
                },
            ),
        )
    if len(requests_raw) > max_operations:
        return (
            None,
            None,
            invalid_inspect_input(
                "inspect.requests exceeds max_operations.",
                details={"max_operations": max_operations},
            ),
        )
    operations: list[InspectOperation | None] = [None for _ in range(len(requests_raw))]
    entries: list[dict[str, JSONValue] | None] = [
        None for _ in range(len(requests_raw))
    ]
    for idx, entry in enumerate(requests_raw):
        operation, operation_error = parse_request_entry(entry, idx=idx, tools=tools)
        if operation is not None:
            operations[idx] = operation
            continue
        op_name = as_str(entry.get("op")) if isinstance(entry, dict) else None
        request_id = (
            as_str(entry.get("request_id")) if isinstance(entry, dict) else None
        )
        details: dict[str, JSONValue] = {
            "field": f"/requests/{idx}",
            "reason": "invalid",
        }
        example = _example_request_entry(op_name) if isinstance(op_name, str) else None
        if example is not None:
            details["example"] = example
        entries[idx] = operation_error or operation_invalid_entry(
            idx,
            op_name=op_name,
            request_id=request_id,
            message="Invalid inspect.requests entry.",
            details=details,
        )
    return operations, entries, None


__all__ = (
    "invalid_inspect_input",
    "operation_invalid_entry",
    "parse_inspect_payload",
)
