"""Concurrent execution for validated inspect operations."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from agents.tool_context import ToolContext

from agenterm.core.errors import AgentermError, OperationCancelledError
from agenterm.core.json_codec import dumps_compact, require_json_object
from agenterm.core.tool_output_envelope import ToolOutputEnvelope, ToolOutputError
from agenterm.engine.cli_tools.shared import TOOL_ERROR_KIND
from agenterm.engine.inspect.budget import limit_inspect_envelope
from agenterm.engine.inspect.output import (
    normalize_subtool_output,
    operation_entry_from_output,
)
from agenterm.engine.inspect.payload import (
    invalid_inspect_input,
    operation_invalid_entry,
    parse_inspect_payload,
)
from agenterm.engine.tool_contracts import summarize_batch

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.tool import FunctionTool

    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext
    from agenterm.engine.inspect.model import InspectOperation


async def run_inspect_operation(
    ctx: ToolContext[ToolRuntimeContext],
    *,
    operation: InspectOperation,
    operation_call_id: str,
    semaphore: asyncio.Semaphore,
) -> ToolOutputEnvelope:
    """Execute one parsed inspect operation under the inspect semaphore."""
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    async with semaphore:
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        args_json = dumps_compact(
            require_json_object(
                value=operation.arguments,
                context=f"inspect.args.{operation.op_name}",
            ),
            ensure_ascii=True,
            context=f"inspect.args.{operation.op_name}",
        )
        tool = operation.tool
        if tool is None or operation.tool_name is None:
            return ToolOutputEnvelope(
                tool=operation.op_name,
                ok=False,
                result={},
                error=ToolOutputError(
                    kind=TOOL_ERROR_KIND,
                    message="Missing inspect operation tool binding.",
                    details={"op": operation.op_name},
                ),
            )
        tool_ctx = ToolContext(
            context=ctx.context,
            usage=ctx.usage,
            tool_name=operation.tool_name,
            tool_call_id=operation_call_id,
            tool_arguments=args_json,
            tool_call=None,
        )
        try:
            output = await tool.on_invoke_tool(tool_ctx, args_json)
        except OperationCancelledError:
            raise
        except AgentermError as exc:
            return ToolOutputEnvelope(
                tool=operation.op_name,
                ok=False,
                result={},
                error=ToolOutputError(
                    kind=TOOL_ERROR_KIND,
                    message=str(exc),
                    details={},
                ),
            )
        return normalize_subtool_output(tool_name=operation.op_name, output=output)


async def invoke_inspect(
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
    *,
    max_operations: int,
    max_concurrency: int,
    tools: Mapping[str, FunctionTool],
    max_chars: int,
) -> str:
    """Parse payload, run inspect operations, and clamp output envelope."""
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    operations, entries, error = parse_inspect_payload(
        raw,
        max_operations=max_operations,
        tools=tools,
    )
    if error is not None or operations is None or entries is None:
        return error or invalid_inspect_input("Invalid inspect payload.")
    requested = len(entries)

    concurrency = max(1, int(max_concurrency))
    semaphore = asyncio.Semaphore(concurrency)

    await _run_all(
        ctx=ctx,
        operations=operations,
        entries=entries,
        semaphore=semaphore,
    )

    output_results = _finalize_entries(
        operations=operations,
        entries=entries,
        requested=requested,
    )

    summary = summarize_batch(output_results)
    limited = limit_inspect_envelope(
        responses=output_results,
        summary=summary,
        max_chars=max(0, int(max_chars)),
    )
    return limited.to_json_string()


def _collect_operation_tasks(
    *,
    ctx: ToolContext[ToolRuntimeContext],
    operations: list[InspectOperation | None],
    entries: list[dict[str, JSONValue] | None],
    semaphore: asyncio.Semaphore,
) -> list[tuple[int, InspectOperation, asyncio.Task[ToolOutputEnvelope]]]:
    indexed_tasks: list[
        tuple[int, InspectOperation, asyncio.Task[ToolOutputEnvelope]]
    ] = []
    for idx, operation in enumerate(operations):
        if operation is None or entries[idx] is not None:
            continue
        operation_call_id = f"{ctx.tool_call_id}:{operation.index}"
        indexed_tasks.append(
            (
                idx,
                operation,
                asyncio.create_task(
                    run_inspect_operation(
                        ctx,
                        operation=operation,
                        operation_call_id=operation_call_id,
                        semaphore=semaphore,
                    )
                ),
            )
        )
    return indexed_tasks


async def _run_all(
    *,
    ctx: ToolContext[ToolRuntimeContext],
    operations: list[InspectOperation | None],
    entries: list[dict[str, JSONValue] | None],
    semaphore: asyncio.Semaphore,
) -> None:
    indexed_tasks = _collect_operation_tasks(
        ctx=ctx,
        operations=operations,
        entries=entries,
        semaphore=semaphore,
    )
    try:
        task_values = (
            await asyncio.gather(*(task for _idx, _operation, task in indexed_tasks))
            if indexed_tasks
            else []
        )
    except OperationCancelledError:
        for _idx, _operation, task in indexed_tasks:
            task.cancel()
        raise
    for (idx, operation, _task), result in zip(indexed_tasks, task_values, strict=True):
        entries[idx] = operation_entry_from_output(
            index=operation.index,
            op_name=operation.op_name,
            request_id=operation.request_id,
            output=result,
        )


def _missing_output_entry(
    *,
    idx: int,
    operation: InspectOperation | None,
) -> dict[str, JSONValue]:
    op_name = operation.op_name if operation is not None else None
    request_id = operation.request_id if operation is not None else None
    return operation_invalid_entry(
        idx,
        op_name=op_name,
        request_id=request_id,
        message="Missing inspect request output.",
        details={"field": f"/requests/{idx}", "reason": "missing_output"},
    )


def _finalize_entries(
    *,
    operations: list[InspectOperation | None],
    entries: list[dict[str, JSONValue] | None],
    requested: int,
) -> list[dict[str, JSONValue]]:
    output_results: list[dict[str, JSONValue]] = []
    for idx in range(requested):
        entry = entries[idx]
        if entry is None:
            entry = _missing_output_entry(idx=idx, operation=operations[idx])
        output_results.append(entry)
    return output_results


__all__ = ("invoke_inspect",)
