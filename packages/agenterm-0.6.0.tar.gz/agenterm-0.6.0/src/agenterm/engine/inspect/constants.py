"""Constants for the native inspect tool."""

from __future__ import annotations

from typing import Final

INSPECT_OPERATION_BINDINGS: Final[tuple[tuple[str, str], ...]] = (
    ("search_text", "rg"),
    ("find_paths", "fd"),
    ("read_file", "bat"),
    ("read_bytes", "read_bytes"),
    ("list_tree", "tree"),
    ("path_stats", "stat"),
    ("runtime_info", "info"),
)

ALLOWED_INSPECT_OPS: Final[tuple[str, ...]] = tuple(
    operation for operation, _tool_name in INSPECT_OPERATION_BINDINGS
)


def tool_name_for_operation(operation: str) -> str | None:
    """Return the private subtool name bound to an inspect operation."""
    for op_name, tool_name in INSPECT_OPERATION_BINDINGS:
        if op_name == operation:
            return tool_name
    return None


__all__ = (
    "ALLOWED_INSPECT_OPS",
    "INSPECT_OPERATION_BINDINGS",
    "tool_name_for_operation",
)
