"""Strict JSON schema builder for the inspect tool payload."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.json_codec import require_json_object
from agenterm.engine.inspect.constants import INSPECT_OPERATION_BINDINGS

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.tool import FunctionTool

    from agenterm.core.json_types import JSONValue


def inspect_schema_for_tools(
    *,
    tools: Mapping[str, FunctionTool],
) -> dict[str, JSONValue]:
    """Return the strict schema for configured inspect operations."""
    variants: list[dict[str, JSONValue]] = []
    for op_name, tool_name in INSPECT_OPERATION_BINDINGS:
        tool = tools.get(tool_name)
        if tool is None:
            continue
        args_schema = require_json_object(
            value=tool.params_json_schema,
            context=f"inspect.schema.{op_name}.params_json_schema",
        )
        properties_raw = args_schema.get("properties")
        if not isinstance(properties_raw, dict):
            continue
        required_raw = args_schema.get("required")
        required_args = (
            [item for item in required_raw if isinstance(item, str)]
            if isinstance(required_raw, list)
            else []
        )
        op_enum: list[JSONValue] = [op_name]
        base_props: dict[str, JSONValue] = {
            "op": {"type": "string", "enum": op_enum},
            "request_id": {
                "type": ["string", "null"],
                "minLength": 1,
                "description": "Caller-supplied request id echoed in response.",
            },
            **dict(properties_raw),
        }
        base_required = ["op", "request_id", *required_args]
        required_fields: list[JSONValue] = []
        required_fields.extend(base_required)
        variants.append(
            {
                "type": "object",
                "description": f"Inspect request for op={op_name}.",
                "properties": base_props,
                "required": required_fields,
                "additionalProperties": False,
            }
        )
    requests_schema: dict[str, JSONValue] = {
        "type": "array",
        "minItems": 1,
        "description": "Ordered list of inspect requests.",
        "items": {"anyOf": list(variants)},
    }
    return {
        "type": "object",
        "description": "Inspect batch request.",
        "properties": {"requests": requests_schema},
        "required": ["requests"],
        "additionalProperties": False,
    }


__all__ = ("inspect_schema_for_tools",)
