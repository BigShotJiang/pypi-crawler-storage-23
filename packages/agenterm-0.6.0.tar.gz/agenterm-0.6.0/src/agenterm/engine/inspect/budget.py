"""Size budgeting for `inspect` tool outputs.

`inspect` aggregates multiple operation outputs into a single ToolOutputEnvelope
bounded by `tools.max_chars`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.json_codec import json_size
from agenterm.core.tool_output_envelope import ToolOutputEnvelope
from agenterm.core.tool_output_limits import (
    budget_infeasible_envelope,
    limit_tool_output_text,
)
from agenterm.core.tool_output_payload_clamp import limit_payload_to_fit

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agenterm.core.json_types import JSONValue

_LIMIT_REASON_CHAR_BUDGET = "char_budget"


def _entry_size(entry: Mapping[str, JSONValue]) -> int:
    return json_size(dict(entry))


def _limit_text(text: str, max_len: int) -> str:
    return limit_tool_output_text(text, max_chars=max_len)


def _with_result(
    entry: Mapping[str, JSONValue], result: Mapping[str, JSONValue]
) -> dict[str, JSONValue]:
    out = dict(entry)
    out["result"] = dict(result)
    return out


def _with_error_message(
    entry: Mapping[str, JSONValue], message: str
) -> dict[str, JSONValue]:
    out = dict(entry)
    error = out.get("error")
    if not isinstance(error, dict):
        return out
    updated = dict(error)
    updated["message"] = message
    out["error"] = updated
    return out


def _skeleton_response_entry(entry: Mapping[str, JSONValue]) -> dict[str, JSONValue]:
    op = entry.get("op")
    status = entry.get("status")
    limit_reason = entry.get("limit_reason")
    request_id_raw = entry.get("request_id")
    request_id = request_id_raw.strip() if isinstance(request_id_raw, str) else None
    if isinstance(request_id, str) and not request_id:
        request_id = None
    out: dict[str, JSONValue] = {
        "index": entry.get("index"),
        "op": op if isinstance(op, str) else "unknown",
        "request_id": request_id,
        "status": status if isinstance(status, str) else "error",
        "truncated": True,
        "result": {},
        "limit_reason": limit_reason if isinstance(limit_reason, str) else None,
    }
    if out["status"] == "error":
        error = entry.get("error")
        kind = None
        if isinstance(error, dict):
            kind_raw = error.get("kind")
            if isinstance(kind_raw, str) and kind_raw:
                kind = kind_raw
        if kind is None:
            kind = "tool_error"
        out["error"] = {"kind": kind, "message": "", "details": {}}
    return out


def _truncate_text_to_fit(
    entry: Mapping[str, JSONValue],
    *,
    max_chars: int,
    text: str,
) -> str:
    if max_chars <= 0:
        return ""
    low = 0
    high = min(len(text), max_chars)
    best = ""
    while low <= high:
        mid = (low + high) // 2
        candidate = limit_tool_output_text(text, max_chars=mid)
        if _entry_size(_with_error_message(entry, candidate)) <= max_chars:
            best = candidate
            low = mid + 1
        else:
            high = mid - 1
    return best


def _clamp_error_result_entry(
    entry: Mapping[str, JSONValue],
    *,
    skeleton: Mapping[str, JSONValue],
    max_chars: int,
) -> dict[str, JSONValue]:
    base = dict(skeleton)
    base_error = base.get("error")
    message = ""
    if isinstance(base_error, dict):
        raw = entry.get("error")
        if isinstance(raw, dict):
            raw_message = raw.get("message")
            if isinstance(raw_message, str):
                message = raw_message
    if message:
        fitted = _truncate_text_to_fit(base, max_chars=max_chars, text=message)
        base = _with_error_message(base, fitted)
    if _entry_size(base) <= max_chars:
        return base
    return _with_error_message(base, "")


def _clamp_ok_result_entry(
    entry: Mapping[str, JSONValue],
    *,
    skeleton: Mapping[str, JSONValue],
    max_chars: int,
) -> dict[str, JSONValue]:
    result_raw = entry.get("result")
    result = dict(result_raw) if isinstance(result_raw, dict) else {}
    base = dict(skeleton)

    def _size(candidate_result: Mapping[str, JSONValue]) -> int:
        return _entry_size(_with_result(base, candidate_result))

    limited = limit_payload_to_fit(
        payload=result,
        max_chars=max_chars,
        size=_size,
        limit_text=_limit_text,
    )
    out = _with_result(base, limited)
    if _entry_size(out) <= max_chars:
        return out
    return _with_result(base, {})


def _clamp_result_entry(
    entry: Mapping[str, JSONValue],
    *,
    skeleton: Mapping[str, JSONValue],
    max_chars: int,
) -> dict[str, JSONValue]:
    if _entry_size(entry) <= max_chars:
        return dict(entry)
    if _entry_size(skeleton) > max_chars:
        return dict(skeleton)

    status = entry.get("status")
    if status == "error":
        return _clamp_error_result_entry(entry, skeleton=skeleton, max_chars=max_chars)
    return _clamp_ok_result_entry(entry, skeleton=skeleton, max_chars=max_chars)


def limit_inspect_envelope(
    *,
    responses: Sequence[Mapping[str, JSONValue]],
    summary: Mapping[str, JSONValue],
    max_chars: int,
) -> ToolOutputEnvelope:
    """Return an inspect ToolOutputEnvelope bounded by max_chars."""
    responses_full = [dict(response) for response in responses]
    responses_json: list[JSONValue] = [dict(response) for response in responses_full]
    payload_full: dict[str, JSONValue] = {
        "responses": responses_json,
        "summary": dict(summary),
    }
    full_env = ToolOutputEnvelope(
        tool="inspect",
        ok=True,
        result=payload_full,
    )
    if json_size(full_env.to_json()) <= max_chars:
        return full_env

    skeleton_responses = [
        _skeleton_response_entry(response) for response in responses_full
    ]
    skeleton_responses_json: list[JSONValue] = [
        dict(response) for response in skeleton_responses
    ]
    payload_skel: dict[str, JSONValue] = {
        "responses": skeleton_responses_json,
        "summary": dict(summary),
    }
    skeleton_env = ToolOutputEnvelope(
        tool="inspect",
        ok=True,
        truncated=True,
        limit_reason=_LIMIT_REASON_CHAR_BUDGET,
        result=payload_skel,
    )
    if json_size(skeleton_env.to_json()) > max_chars:
        return budget_infeasible_envelope(tool="inspect", max_chars=max_chars)

    skel_sizes = [_entry_size(response) for response in skeleton_responses]
    full_sizes = [_entry_size(response) for response in responses_full]
    capacities = [
        max(0, full_size - skel_size)
        for full_size, skel_size in zip(full_sizes, skel_sizes, strict=True)
    ]
    hi = max(capacities, default=0)

    def _build(delta: int) -> ToolOutputEnvelope:
        limited_results: list[JSONValue] = []
        for response_full, response_skel, skel_size, capacity in zip(
            responses_full, skeleton_responses, skel_sizes, capacities, strict=True
        ):
            budget = int(skel_size + min(capacity, max(0, int(delta))))
            limited_results.append(
                _clamp_result_entry(
                    response_full,
                    skeleton=response_skel,
                    max_chars=budget,
                )
            )
        payload: dict[str, JSONValue] = {
            "responses": limited_results,
            "summary": dict(summary),
        }
        return ToolOutputEnvelope(
            tool="inspect",
            ok=True,
            truncated=True,
            limit_reason=_LIMIT_REASON_CHAR_BUDGET,
            result=payload,
        )

    best = skeleton_env
    low = 0
    high = int(hi)
    while low <= high:
        mid = (low + high) // 2
        candidate = _build(mid)
        if json_size(candidate.to_json()) <= max_chars:
            best = candidate
            low = mid + 1
        else:
            high = mid - 1

    if json_size(best.to_json()) > max_chars:
        return budget_infeasible_envelope(tool="inspect", max_chars=max_chars)
    return best


__all__ = ("limit_inspect_envelope",)
