"""Typed runtime model for parsed inspect operations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agents.tool import FunctionTool

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class InspectOperation:
    """One validated operation entry in the inspect payload."""

    index: int
    op_name: str
    request_id: str | None
    tool_name: str | None
    arguments: dict[str, JSONValue]
    tool: FunctionTool | None


__all__ = ("InspectOperation",)
