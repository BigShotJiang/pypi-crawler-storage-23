"""Public builder for the native inspect FunctionTool."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.engine.inspect.constants import INSPECT_OPERATION_BINDINGS
from agenterm.engine.inspect.run import invoke_inspect
from agenterm.engine.inspect.schema import inspect_schema_for_tools
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_inspect

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.tool_context import ToolContext

    from agenterm.config.tools_policy import InspectToolConfig
    from agenterm.core.plan import ToolRuntimeContext


def build_inspect_tool(
    cfg: InspectToolConfig | None,
    *,
    tools: Mapping[str, FunctionTool],
    max_chars: int,
) -> FunctionTool | None:
    """Build the inspect FunctionTool when configured."""
    if cfg is None:
        return None

    required_tools: dict[str, FunctionTool] = {}
    for _op_name, tool_name in INSPECT_OPERATION_BINDINGS:
        tool = tools.get(tool_name)
        if tool is None:
            return None
        required_tools[tool_name] = tool

    schema = inspect_schema_for_tools(tools=required_tools)
    validate_strict_schema("inspect", schema)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        return await invoke_inspect(
            ctx,
            raw,
            max_operations=cfg.max_operations,
            max_concurrency=cfg.max_concurrency,
            tools=required_tools,
            max_chars=max_chars,
        )

    return FunctionTool(
        name="inspect",
        description=describe_inspect(),
        params_json_schema=schema,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_inspect_tool",)
