"""Subtool output normalization for the native inspect tool."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ValidationError
from agenterm.core.json_codec import require_json_value
from agenterm.core.tool_output_envelope import (
    ToolOutputEnvelope,
    ToolOutputError,
    parse_tool_output_envelope,
)
from agenterm.engine.cli_tools.shared import TOOL_ERROR_KIND
from agenterm.engine.tool_contracts import batch_response

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


def normalize_subtool_output(
    *,
    tool_name: str,
    output: JSONValue,
) -> ToolOutputEnvelope:
    """Normalize arbitrary subtool output into the canonical envelope."""
    if isinstance(output, str):
        parsed = parse_tool_output_envelope(output)
        if parsed is not None:
            return parsed
        return ToolOutputEnvelope(
            tool=tool_name,
            ok=True,
            result={"text": output},
        )
    try:
        value = require_json_value(
            value=output,
            context=f"inspect.output.{tool_name}",
        )
    except ValidationError as exc:
        return ToolOutputEnvelope(
            tool=tool_name,
            ok=False,
            result={},
            error=ToolOutputError(
                kind=TOOL_ERROR_KIND,
                message=str(exc),
                details={},
            ),
        )
    return ToolOutputEnvelope(
        tool=tool_name,
        ok=True,
        result={"result": value},
    )


def operation_entry_from_output(
    *,
    index: int,
    op_name: str,
    request_id: str | None,
    output: ToolOutputEnvelope,
) -> dict[str, JSONValue]:
    """Map a subtool envelope to one ordered inspect result entry."""
    return batch_response(
        index=index,
        op=op_name,
        request_id=request_id,
        include_request_id=True,
        status="ok" if output.ok else "error",
        result=output.result if output.ok else {},
        error=output.error if not output.ok else None,
        truncated=bool(output.truncated),
        limit_reason=output.limit_reason,
    )


__all__ = ("normalize_subtool_output", "operation_entry_from_output")
