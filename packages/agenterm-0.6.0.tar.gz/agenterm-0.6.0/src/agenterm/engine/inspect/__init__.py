"""Native inspect FunctionTool package for batched read-only inspection."""

from agenterm.engine.inspect.tool import build_inspect_tool

__all__ = ("build_inspect_tool",)
