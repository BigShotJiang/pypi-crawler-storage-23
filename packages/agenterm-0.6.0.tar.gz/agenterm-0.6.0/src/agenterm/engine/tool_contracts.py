"""Shared model-facing tool contract helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agenterm.core.json_types import JSONValue
    from agenterm.core.tool_output_envelope import ToolOutputError

BatchStatus = Literal["ok", "error", "skipped"]


def batch_response(
    *,
    index: int,
    op: str,
    status: BatchStatus,
    result: Mapping[str, JSONValue] | None = None,
    error: ToolOutputError | None = None,
    request_id: str | None = None,
    include_request_id: bool = False,
    truncated: bool = False,
    limit_reason: str | None = None,
) -> dict[str, JSONValue]:
    """Build one canonical batch response item."""
    payload: dict[str, JSONValue] = {
        "index": int(index),
        "op": op,
        "status": status,
        "result": dict(result) if result is not None else {},
        "truncated": bool(truncated),
        "limit_reason": limit_reason,
    }
    if include_request_id:
        payload["request_id"] = request_id
    if error is not None:
        payload["error"] = error.to_json()
    return payload


def summarize_batch(
    responses: Sequence[Mapping[str, JSONValue]],
) -> dict[str, JSONValue]:
    """Build canonical per-call batch summary counters."""
    ok_count = 0
    error_count = 0
    skipped_count = 0
    for entry in responses:
        status = entry.get("status")
        if status == "ok":
            ok_count += 1
            continue
        if status == "error":
            error_count += 1
            continue
        if status == "skipped":
            skipped_count += 1
    return {
        "requested": len(responses),
        "ok": ok_count,
        "error": error_count,
        "skipped": skipped_count,
    }


__all__ = (
    "BatchStatus",
    "batch_response",
    "summarize_batch",
)
