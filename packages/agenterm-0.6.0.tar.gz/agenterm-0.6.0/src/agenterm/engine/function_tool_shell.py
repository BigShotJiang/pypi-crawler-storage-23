"""Portable FunctionTool wrapper implementation for local shell execution."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool import (
    FunctionTool,
    ShellActionRequest,
    ShellCallData,
    ShellCommandOutput,
    ShellCommandRequest,
    ShellResult,
)

from agenterm.core.errors import (
    AgentermError,
    SandboxBackendUnavailableError,
    ValidationError,
)
from agenterm.core.json_codec import as_str
from agenterm.core.tool_output_envelope import ToolOutputEnvelope, ToolOutputError
from agenterm.engine.function_tool_shell_contract import (
    SHELL_SCHEMA,
    ParsedShellPayload,
    parse_shell_payload,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_contracts import batch_response, summarize_batch
from agenterm.engine.tool_descriptions import describe_shell

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable, Mapping
    from pathlib import Path

    from agents.tool_context import ToolContext

    from agenterm.config.tool_models import ShellToolConfig
    from agenterm.core.approvals import ShellApprovalManager
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_INVALID_INPUT_KIND = "invalid_input"
_TOOL_ERROR_KIND = "tool_error"
_POLICY_DENIED_KIND = "policy_denied"
_COMMAND_FAILED_KIND = "command_failed"
_TIMEOUT_KIND = "timeout"


def _error_output(
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
    result: Mapping[str, JSONValue] | None = None,
) -> str:
    err = ToolOutputError(
        kind=kind,
        message=message,
        details=dict(details) if details is not None else {},
    )
    envelope = ToolOutputEnvelope(
        tool="shell",
        ok=False,
        result=dict(result) if result is not None else {},
        error=err,
    )
    return envelope.to_json_string()


def _shell_error_from_output(
    *,
    index: int,
    item: ShellCommandOutput,
    elapsed_ms: int | None,
    success: bool,
    provider_data: Mapping[str, JSONValue],
) -> ToolOutputError | None:
    if provider_data.get("approval_rejected") is True:
        details: dict[str, JSONValue] = {"reason": "rejected", "index": index}
        approval_reason = as_str(provider_data.get("approval_reason"))
        if approval_reason:
            details["approval_reason"] = approval_reason
        return ToolOutputError(
            kind=_POLICY_DENIED_KIND,
            message="Shell command execution rejected by user.",
            details=details,
        )
    if item.outcome.type == "timeout":
        return ToolOutputError(
            kind=_TIMEOUT_KIND,
            message="Shell command timed out before completion.",
            details={
                "reason": "command_timeout",
                "index": index,
                "command": item.command,
                "elapsed_ms": elapsed_ms,
            },
        )
    if success:
        return None
    exit_code = item.outcome.exit_code
    parsed_exit_code = (
        int(exit_code)
        if isinstance(exit_code, int) and not isinstance(exit_code, bool)
        else None
    )
    return ToolOutputError(
        kind=_COMMAND_FAILED_KIND,
        message="Shell command exited with non-zero status.",
        details={
            "reason": "command_failed",
            "index": index,
            "command": item.command,
            "exit_code": parsed_exit_code,
        },
    )


def _shell_response_entry(index: int, item: ShellCommandOutput) -> dict[str, JSONValue]:
    provider_data = dict(item.provider_data or {})
    stdout_truncated = provider_data.get("stdout_truncated") is True
    stderr_truncated = provider_data.get("stderr_truncated") is True
    elapsed_raw = provider_data.get("elapsed_ms")
    elapsed_ms = (
        int(elapsed_raw)
        if isinstance(elapsed_raw, int) and not isinstance(elapsed_raw, bool)
        else None
    )
    exit_code = item.outcome.exit_code
    parsed_exit_code = (
        int(exit_code)
        if isinstance(exit_code, int) and not isinstance(exit_code, bool)
        else None
    )
    success = item.outcome.type == "exit" and parsed_exit_code in (None, 0)
    error = _shell_error_from_output(
        index=index,
        item=item,
        elapsed_ms=elapsed_ms,
        success=success,
        provider_data=provider_data,
    )
    truncated = stdout_truncated or stderr_truncated
    return batch_response(
        index=index,
        op="command",
        status="ok" if error is None else "error",
        result={
            "command": item.command,
            "status": item.outcome.type,
            "ok": success,
            "exit_code": parsed_exit_code,
            "signal": None,
            "elapsed_ms": elapsed_ms,
            "stdout": item.stdout,
            "stderr": item.stderr,
            "stdout_truncated": stdout_truncated,
            "stderr_truncated": stderr_truncated,
        },
        error=error,
        truncated=truncated,
        limit_reason="max_output_chars" if truncated else None,
    )


def _shell_skipped_entry(
    *,
    index: int,
    command: str,
) -> dict[str, JSONValue]:
    return batch_response(
        index=index,
        op="command",
        status="skipped",
        result={"command": command, "reason": "not_run"},
    )


def _collect_shell_responses(
    *,
    result: ShellResult,
    commands_requested: list[str],
) -> list[dict[str, JSONValue]]:
    responses = [
        _shell_response_entry(index=idx, item=item)
        for idx, item in enumerate(result.output)
    ]
    executed = len(responses)
    if executed < len(commands_requested):
        responses.extend(
            _shell_skipped_entry(index=idx, command=cmd)
            for idx, cmd in enumerate(commands_requested[executed:], start=executed)
        )
    return responses


def _count_timed_out(responses: list[dict[str, JSONValue]]) -> int:
    timed_out = 0
    for entry in responses:
        result_payload = entry.get("result")
        if (
            isinstance(result_payload, dict)
            and result_payload.get("status") == "timeout"
        ):
            timed_out += 1
    return timed_out


def _shell_payload_from_result(
    *,
    result: ShellResult,
    commands_requested: list[str],
) -> dict[str, JSONValue]:
    responses = _collect_shell_responses(
        result=result,
        commands_requested=commands_requested,
    )
    summary = summarize_batch(responses)
    provider = dict(result.provider_data or {})
    cwd_resolved = as_str(provider.get("working_directory")) or "."
    cwd_abs = as_str(provider.get("working_directory_abs"))
    commands_total = len(commands_requested)
    commands_executed = len(result.output)
    responses_json: list[JSONValue] = []
    responses_json.extend(responses)
    return {
        "cwd_resolved": cwd_resolved,
        "cwd_abs": cwd_abs,
        "summary": {
            "commands": commands_total,
            "ok": summary["ok"],
            "failed": summary["error"],
            "timed_out": _count_timed_out(responses),
            "skipped": summary["skipped"],
        },
        "stopped_early": commands_executed < commands_total,
        "responses": responses_json,
    }


def _shell_validation_details(message: str) -> dict[str, JSONValue]:
    if "workspace-relative" in message:
        return {"field": "cwd", "reason": "workspace_relative_required"}
    if "resolve inside the workspace" in message:
        return {"field": "cwd", "reason": "outside_workspace"}
    if "does not exist" in message:
        return {"field": "cwd", "reason": "not_found"}
    if "not a directory" in message:
        return {"field": "cwd", "reason": "not_a_directory"}
    return {"reason": "invalid_shell_request"}


def _shell_backend_details(exc: SandboxBackendUnavailableError) -> dict[str, JSONValue]:
    details: dict[str, JSONValue] = {
        "reason": "backend_unavailable",
        "platform": exc.platform,
    }
    if exc.backend is not None:
        details["backend"] = exc.backend
    return details


def _shell_error_from_exception(exc: AgentermError) -> str:
    if isinstance(exc, SandboxBackendUnavailableError):
        return _error_output(
            kind=_TOOL_ERROR_KIND,
            message=str(exc),
            details=_shell_backend_details(exc),
        )
    if isinstance(exc, ValidationError):
        return _error_output(
            kind=_INVALID_INPUT_KIND,
            message=str(exc),
            details=_shell_validation_details(str(exc)),
        )
    return _error_output(
        kind=_TOOL_ERROR_KIND,
        message=str(exc),
        details={"reason": "executor_failure"},
    )


def _shell_request(
    *,
    ctx: ToolContext[ToolRuntimeContext],
    parsed: ParsedShellPayload,
) -> ShellCommandRequest:
    data = ShellCallData(
        call_id=ctx.tool_call_id,
        action=ShellActionRequest(
            commands=parsed.commands,
            timeout_ms=parsed.timeout_ms,
            max_output_length=parsed.max_output_chars,
        ),
        raw={
            "description": parsed.approval_label,
            "cwd": parsed.cwd,
        },
    )
    return ShellCommandRequest(ctx_wrapper=ctx, data=data)


async def _invoke_shell_tool(
    *,
    cfg: ShellToolConfig,
    workspace_root: Path,
    approvals: ShellApprovalManager,
    run_shell: Callable[..., Awaitable[ShellResult]],
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
) -> str:
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    parsed = parse_shell_payload(raw)
    if parsed is None:
        return _error_output(kind=_INVALID_INPUT_KIND, message="Invalid shell payload.")
    request = _shell_request(ctx=ctx, parsed=parsed)
    try:
        result = await run_shell(
            request,
            tool_cfg=cfg,
            workspace_root=workspace_root,
            approvals=approvals,
            env_override=parsed.env_override,
            cancel_token=cancel_token,
        )
    except AgentermError as exc:
        return _shell_error_from_exception(exc)
    payload = _shell_payload_from_result(
        result=result,
        commands_requested=parsed.commands,
    )
    return ToolOutputEnvelope(tool="shell", ok=True, result=payload).to_json_string()


def build_shell_function_tool(
    cfg: ShellToolConfig | None,
    *,
    workspace_root: Path,
    approvals: ShellApprovalManager,
    supports_shell_platform: Callable[[], bool],
    run_shell: Callable[..., Awaitable[ShellResult]],
) -> FunctionTool | None:
    """Build a portable FunctionTool wrapper for local shell execution."""
    if not supports_shell_platform() or cfg is None:
        return None
    validate_strict_schema("shell", SHELL_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        return await _invoke_shell_tool(
            cfg=cfg,
            workspace_root=workspace_root,
            approvals=approvals,
            run_shell=run_shell,
            ctx=ctx,
            raw=raw,
        )

    return FunctionTool(
        name="shell",
        description=describe_shell(),
        params_json_schema=SHELL_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_shell_function_tool",)
