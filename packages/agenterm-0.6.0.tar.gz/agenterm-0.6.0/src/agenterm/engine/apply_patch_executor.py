"""Execution helpers for canonical apply_patch operations."""

from __future__ import annotations

import asyncio
import re
import shutil
from contextlib import suppress
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agents.apply_diff import apply_diff

from agenterm.core.tool_output_envelope import ToolOutputError
from agenterm.engine.cli_tools.shared import resolve_path_checked

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

    from agenterm.core.approvals import PatchApprovalManager
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.engine.apply_patch_contract import (
        CreateFileOp,
        DeletePathOp,
        ResponseStatus,
        UpdateFileOp,
    )

INVALID_INPUT_KIND = "invalid_input"
INTERNAL_ERROR_KIND = "internal_error"
POLICY_DENIED_KIND = "policy_denied"
CONFLICT_KIND = "conflict"

_HUNK_LINE_RE = re.compile(r"line\s+(\d+)", re.IGNORECASE)
_HEADER_PREFIXES = ("diff --git ", "index ", "--- ", "+++ ")


@dataclass(frozen=True)
class OperationExecution:
    """One executed operation outcome."""

    status: ResponseStatus
    result: dict[str, JSONValue]
    error: ToolOutputError | None = None


def _op_ok(result: Mapping[str, JSONValue]) -> OperationExecution:
    return OperationExecution(status="ok", result=dict(result))


def _op_skipped(result: Mapping[str, JSONValue]) -> OperationExecution:
    return OperationExecution(status="skipped", result=dict(result))


def _op_error(
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue],
) -> OperationExecution:
    return OperationExecution(
        status="error",
        result={},
        error=ToolOutputError(kind=kind, message=message, details=dict(details)),
    )


def _missing_path_error(raw_path: str, reason: str | None) -> OperationExecution:
    error_kind = INVALID_INPUT_KIND if reason != "not_found" else CONFLICT_KIND
    message = (
        "Operation path is invalid."
        if reason != "not_found"
        else "Operation path does not exist."
    )
    detail_reason = (
        "missing_target" if reason == "not_found" else reason or "invalid_path"
    )
    return _op_error(
        kind=error_kind,
        message=message,
        details={
            "field": "/path",
            "reason": detail_reason,
            "path": raw_path,
        },
    )


def _with_path_error(
    execution: OperationExecution,
    *,
    rel_path: str,
) -> OperationExecution:
    if execution.error is None:
        return execution
    details = dict(execution.error.details)
    details.setdefault("path", rel_path)
    error = ToolOutputError(
        kind=execution.error.kind,
        message=execution.error.message,
        details=details,
    )
    return OperationExecution(
        status=execution.status,
        result=execution.result,
        error=error,
    )


def _path_mismatch_error(
    rel_path: str,
    *,
    expected: str,
    actual: str,
) -> OperationExecution:
    return _op_error(
        kind=CONFLICT_KIND,
        message=f"delete_path target_type={expected} but path is a {actual}.",
        details={"reason": "target_type_mismatch", "path": rel_path},
    )


def _extract_hunks(diff_text: str) -> str | None:
    lines = diff_text.splitlines()
    for idx, line in enumerate(lines):
        if line.startswith("@@"):
            return "\n".join(
                item for item in lines[idx:] if not item.startswith(_HEADER_PREFIXES)
            )
    return None


def _apply_update_diff(
    original: str,
    op: UpdateFileOp,
) -> tuple[str | None, OperationExecution | None]:
    diff_text = op.diff
    if op.diff_format == "unified_with_headers":
        hunks = _extract_hunks(diff_text)
        if hunks is None:
            return None, _op_error(
                kind=INVALID_INPUT_KIND,
                message="update_file diff does not include hunks.",
                details={"reason": "missing_hunks", "diff_format": op.diff_format},
            )
        diff_text = hunks
    try:
        return apply_diff(original, diff_text), None
    except ValueError as exc:
        details: dict[str, JSONValue] = {
            "reason": "patch_apply_failed",
            "diagnostic": str(exc),
        }
        line_match = _HUNK_LINE_RE.search(str(exc))
        if line_match is not None:
            with suppress(ValueError):
                details["diagnostic_line"] = int(line_match.group(1))
        return (
            None,
            _op_error(
                kind=CONFLICT_KIND,
                message="Patch did not apply cleanly.",
                details=details,
            ),
        )


async def _write_text(path: Path, content: str) -> OperationExecution | None:
    try:
        await asyncio.to_thread(path.parent.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(path.write_text, content, "utf-8")
    except OSError:
        return _op_error(
            kind=INTERNAL_ERROR_KIND,
            message="Failed to write file.",
            details={"reason": "write_failed", "path": path.as_posix()},
        )
    return None


def _resolve_path(
    workspace_root: Path,
    raw_path: str,
) -> tuple[Path | None, str | None, OperationExecution | None]:
    resolved, reason = resolve_path_checked(workspace_root, raw_path, expect=None)
    if resolved is None:
        return None, None, _missing_path_error(raw_path, reason)
    abs_path, rel_path = resolved
    return abs_path, rel_path, None


async def _await_approval(
    approvals: PatchApprovalManager,
    *,
    op_type: str,
    path: str,
    diff: str | None,
    approval_label: str | None,
    cancel_token: CancelToken | None,
) -> OperationExecution | None:
    item = approvals.register(op_type, path, diff, description=approval_label)
    decision = await approvals.wait(item.id, cancel_token=cancel_token)
    if decision.approved:
        return None
    details: dict[str, JSONValue] = {"reason": "rejected", "path": path}
    if decision.reason:
        details["approval_reason"] = decision.reason
    return _op_error(
        kind=POLICY_DENIED_KIND,
        message="apply_patch operation rejected by user.",
        details=details,
    )


async def _execute_create_existing(
    op: CreateFileOp,
    *,
    abs_path: Path,
    rel_path: str,
) -> OperationExecution:
    if await asyncio.to_thread(abs_path.is_dir):
        return _op_error(
            kind=CONFLICT_KIND,
            message="create_file target exists as a directory.",
            details={"reason": "target_is_directory", "path": rel_path},
        )
    if op.if_exists == "skip":
        return _op_skipped(
            {"path": rel_path, "changed": False, "reason": "already_exists"}
        )
    if op.if_exists == "error":
        return _op_error(
            kind=CONFLICT_KIND,
            message="create_file target already exists.",
            details={"reason": "already_exists", "path": rel_path},
        )
    previous = await asyncio.to_thread(abs_path.read_text, "utf-8")
    changed = previous != op.content
    write_error = await _write_text(abs_path, op.content)
    if write_error is not None:
        return write_error
    return _op_ok({"path": rel_path, "changed": changed})


async def execute_create_file(
    op: CreateFileOp,
    *,
    workspace_root: Path,
    approvals: PatchApprovalManager,
    approval_label: str | None,
    cancel_token: CancelToken | None,
) -> OperationExecution:
    """Execute create_file operation."""
    abs_path, rel_path, resolve_error = _resolve_path(workspace_root, op.path)
    if resolve_error is not None or abs_path is None or rel_path is None:
        return resolve_error or _missing_path_error(op.path, "invalid_path")
    approval_error = await _await_approval(
        approvals,
        op_type="create_file",
        path=rel_path,
        diff=op.content,
        approval_label=approval_label,
        cancel_token=cancel_token,
    )
    if approval_error is not None:
        return approval_error
    if await asyncio.to_thread(abs_path.exists):
        return await _execute_create_existing(op, abs_path=abs_path, rel_path=rel_path)
    write_error = await _write_text(abs_path, op.content)
    if write_error is not None:
        return write_error
    return _op_ok({"path": rel_path, "changed": True})


def _update_missing_result(op: UpdateFileOp, *, rel_path: str) -> OperationExecution:
    if op.if_missing == "skip":
        return _op_skipped(
            {"path": rel_path, "changed": False, "reason": "missing_target"}
        )
    return _op_error(
        kind=CONFLICT_KIND,
        message="update_file target does not exist.",
        details={"reason": "missing_target", "path": rel_path},
    )


async def _read_text(
    path: Path, *, rel_path: str
) -> tuple[str | None, OperationExecution | None]:
    try:
        return await asyncio.to_thread(path.read_text, "utf-8"), None
    except OSError:
        return (
            None,
            _op_error(
                kind=INTERNAL_ERROR_KIND,
                message="Failed to read update_file target.",
                details={"reason": "read_failed", "path": rel_path},
            ),
        )


async def _prepare_update_target(
    op: UpdateFileOp,
    *,
    workspace_root: Path,
    approvals: PatchApprovalManager,
    approval_label: str | None,
    cancel_token: CancelToken | None,
) -> tuple[Path | None, str | None, str | None, OperationExecution | None]:
    abs_path, rel_path, resolve_error = _resolve_path(workspace_root, op.path)
    if resolve_error is not None or abs_path is None or rel_path is None:
        return None, None, None, resolve_error
    approval_error = await _await_approval(
        approvals,
        op_type="update_file",
        path=rel_path,
        diff=op.diff,
        approval_label=approval_label,
        cancel_token=cancel_token,
    )
    if approval_error is not None:
        return None, None, None, approval_error
    if not await asyncio.to_thread(abs_path.exists):
        return None, rel_path, None, _update_missing_result(op, rel_path=rel_path)
    if await asyncio.to_thread(abs_path.is_dir):
        return (
            None,
            rel_path,
            None,
            _op_error(
                kind=CONFLICT_KIND,
                message="update_file target is a directory.",
                details={"reason": "target_is_directory", "path": rel_path},
            ),
        )
    original, read_error = await _read_text(abs_path, rel_path=rel_path)
    if read_error is not None or original is None:
        return None, rel_path, None, read_error
    return abs_path, rel_path, original, None


async def execute_update_file(
    op: UpdateFileOp,
    *,
    workspace_root: Path,
    approvals: PatchApprovalManager,
    approval_label: str | None,
    cancel_token: CancelToken | None,
) -> OperationExecution:
    """Execute update_file operation."""
    abs_path, rel_path, original, prep_error = await _prepare_update_target(
        op,
        workspace_root=workspace_root,
        approvals=approvals,
        approval_label=approval_label,
        cancel_token=cancel_token,
    )
    if (
        prep_error is not None
        or abs_path is None
        or rel_path is None
        or original is None
    ):
        return prep_error or _missing_path_error(op.path, "invalid_path")
    patched, patch_error = _apply_update_diff(original, op)
    if patch_error is not None or patched is None:
        patch_result = patch_error or _op_error(
            kind=CONFLICT_KIND,
            message="Patch did not apply cleanly.",
            details={"reason": "patch_apply_failed"},
        )
        return _with_path_error(patch_result, rel_path=rel_path)
    changed = patched != original
    if changed:
        write_error = await _write_text(abs_path, patched)
        if write_error is not None:
            return write_error
    return _op_ok({"path": rel_path, "changed": changed})


def _delete_missing_result(*, rel_path: str, missing_ok: bool) -> OperationExecution:
    if missing_ok:
        return _op_ok({"path": rel_path, "changed": False, "reason": "missing_target"})
    return _op_error(
        kind=CONFLICT_KIND,
        message="delete_path target does not exist.",
        details={"reason": "missing_target", "path": rel_path},
    )


def _delete_type_mismatch(
    *,
    rel_path: str,
    target_type: str,
    is_dir: bool,
) -> OperationExecution | None:
    if target_type == "file" and is_dir:
        return _path_mismatch_error(rel_path, expected="file", actual="directory")
    if target_type == "dir" and not is_dir:
        return _path_mismatch_error(rel_path, expected="dir", actual="file")
    return None


async def _delete_path(
    *,
    abs_path: Path,
    is_dir: bool,
    recursive: bool,
) -> bool:
    if is_dir and recursive:
        await asyncio.to_thread(shutil.rmtree, abs_path)
        return True
    if is_dir:
        await asyncio.to_thread(abs_path.rmdir)
        return False
    await asyncio.to_thread(abs_path.unlink)
    return False


async def execute_delete_path(
    op: DeletePathOp,
    *,
    workspace_root: Path,
    approvals: PatchApprovalManager,
    approval_label: str | None,
    cancel_token: CancelToken | None,
) -> OperationExecution:
    """Execute delete_path operation."""
    abs_path, rel_path, resolve_error = _resolve_path(workspace_root, op.path)
    if resolve_error is not None or abs_path is None or rel_path is None:
        return resolve_error or _missing_path_error(op.path, "invalid_path")
    approval_error = await _await_approval(
        approvals,
        op_type="delete_path",
        path=rel_path,
        diff=None,
        approval_label=approval_label,
        cancel_token=cancel_token,
    )
    if approval_error is not None:
        return approval_error
    if not await asyncio.to_thread(abs_path.exists):
        return _delete_missing_result(rel_path=rel_path, missing_ok=op.missing_ok)
    is_dir = await asyncio.to_thread(abs_path.is_dir)
    mismatch = _delete_type_mismatch(
        rel_path=rel_path,
        target_type=op.target_type,
        is_dir=is_dir,
    )
    if mismatch is not None:
        return mismatch
    try:
        rmdir_failed = await _delete_path(
            abs_path=abs_path,
            is_dir=is_dir,
            recursive=op.recursive,
        )
    except OSError:
        kind = CONFLICT_KIND if is_dir and not op.recursive else INTERNAL_ERROR_KIND
        return _op_error(
            kind=kind,
            message="Failed to delete path.",
            details={"reason": "delete_failed", "path": rel_path},
        )
    _ = rmdir_failed
    return _op_ok({"path": rel_path, "changed": True})


__all__ = (
    "CONFLICT_KIND",
    "INTERNAL_ERROR_KIND",
    "INVALID_INPUT_KIND",
    "POLICY_DENIED_KIND",
    "OperationExecution",
    "execute_create_file",
    "execute_delete_path",
    "execute_update_file",
)
