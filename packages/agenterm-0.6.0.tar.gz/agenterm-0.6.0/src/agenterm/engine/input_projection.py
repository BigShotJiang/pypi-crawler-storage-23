"""Per-call history projection for multi-provider session replay.

agenterm stores the full provider-native Responses item shapes in the local
session store, but it must *project* that history into the maximal valid input
shape for the specific target model/protocol on each call.

This module is the single place where cross-provider incompatibilities are
handled. It is intentionally small and table-driven: add new projections here
instead of scattering provider conditionals across packing and workflows.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agents.models.fake_id import FAKE_RESPONSES_ID

from agenterm.core.errors import ConfigError, ValidationError
from agenterm.core.model_contract import ReasoningReplayMode, resolve_model_contract
from agenterm.core.reasoning import (
    filter_reasoning_for_model,
    filter_reasoning_for_openai,
)
from agenterm.core.response_items import serialize_input_item_param

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.items import TResponseInputItem

    from agenterm.config.model import AppConfig


@dataclass(frozen=True)
class ProjectionTarget:
    """Resolved replay target for projecting stored history into call input."""

    reasoning_replay_mode: ReasoningReplayMode


def _resolve_target(cfg: AppConfig, *, model_id: str) -> ProjectionTarget:
    try:
        contract = resolve_model_contract(cfg.providers, model_id=model_id)
    except ValidationError as exc:
        msg = f"Unknown replay target for model id {model_id!r}: {exc}"
        raise ConfigError(msg) from exc
    return ProjectionTarget(
        reasoning_replay_mode=contract.reasoning_replay_mode,
    )


def project_items_for_model_call(
    *,
    cfg: AppConfig,
    model_id: str,
    items: Sequence[TResponseInputItem],
) -> list[TResponseInputItem]:
    """Project stored history items into the maximal valid input for this call.

    Storage is lossless; this projection is allowed to be lossy so long as it is:
    - deterministic,
    - protocol-correct for the target, and
    - never mutates the stored session items in-place.
    """
    target = _resolve_target(cfg, model_id=model_id)
    if target.reasoning_replay_mode == "openai_encrypted_only":
        return project_items_for_openai_responses_protocol(items)
    return _project_for_provider_native_reasoning(items)


def project_items_for_openai_responses_protocol(
    items: Sequence[TResponseInputItem],
) -> list[TResponseInputItem]:
    """Project items into an OpenAI-compatible Responses `input=[...]` payload."""
    cleaned: list[TResponseInputItem] = []
    for item in items:
        # Vendor guidance: provider-specific reasoning items are incompatible with
        # OpenAI Responses input cleaning. Drop them before sanitization.
        if item.get("type") == "reasoning" and item.get("provider_data"):
            continue

        copied = serialize_input_item_param(
            item,
            context="input_projection.openai_responses.item",
        )

        # Remove fake IDs produced by chat-completions conversion.
        if copied.get("id") == FAKE_RESPONSES_ID:
            copied.pop("id", None)

        # Strip provider-native metadata: the OpenAI Responses API does not accept it.
        if "provider_data" in copied:
            copied.pop("provider_data", None)

        cleaned.append(copied)

    # OpenAI plane constraint: reasoning can be replayed only via encrypted tokens.
    # (OpenAI rejects replaying `reasoning.content`.)
    return filter_reasoning_for_openai(cleaned)


def _project_for_provider_native_reasoning(
    items: Sequence[TResponseInputItem],
) -> list[TResponseInputItem]:
    """Project items for provider-native reasoning replay paths.

    Keep provider-native metadata (`provider_data`) so downstream converters can
    restore provider-specific fields, but strip UI-only reasoning summaries.
    """
    cleaned: list[TResponseInputItem] = []
    for item in items:
        copied = serialize_input_item_param(
            item,
            context="input_projection.litellm_chat_completions.item",
        )
        # Drop fake IDs early to reduce prompt noise; they are not meaningful
        # across providers and only exist as conversion placeholders.
        if copied.get("id") == FAKE_RESPONSES_ID:
            copied.pop("id", None)
        cleaned.append(copied)
    return filter_reasoning_for_model(cleaned)


__all__ = (
    "project_items_for_model_call",
    "project_items_for_openai_responses_protocol",
)
