"""Decode compaction responses into snapshot items."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from agenterm.core.errors import AgentermError
from agenterm.core.json_codec import parse_json_object
from agenterm.core.token_usage import TokenUsage

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.items import TResponseInputItem
    from openai.types.responses.compacted_response import CompactedResponse
    from openai.types.responses.response_compaction_item_param_param import (
        ResponseCompactionItemParamParam,
    )
    from openai.types.responses.response_input_file_param import ResponseInputFileParam
    from openai.types.responses.response_input_image_param import (
        ResponseInputImageParam,
    )
    from openai.types.responses.response_input_message_content_list_param import (
        ResponseInputMessageContentListParam,
    )
    from openai.types.responses.response_input_text_param import ResponseInputTextParam
    from openai.types.responses.response_output_message_param import (
        Content as OutputMessageContentParam,
    )
    from openai.types.responses.response_output_refusal_param import (
        ResponseOutputRefusalParam,
    )
    from openai.types.responses.response_output_text_param import (
        Annotation as OutputTextAnnotationParam,
    )
    from openai.types.responses.response_output_text_param import (
        ResponseOutputTextParam,
    )

    from agenterm.core.json_types import JSONValue


def _require_str(value: JSONValue | None, *, context: str) -> str:
    if not isinstance(value, str) or not value:
        msg = f"Invalid {context}: expected non-empty string."
        raise AgentermError(msg)
    return value


def _require_int(value: JSONValue | None, *, context: str) -> int:
    if not isinstance(value, int):
        msg = f"Invalid {context}: expected int."
        raise AgentermError(msg)
    return value


def _require_image_detail(value: JSONValue | None) -> Literal["low", "high", "auto"]:
    if value == "low":
        return "low"
    if value == "high":
        return "high"
    if value == "auto" or value is None:
        return "auto"
    msg = f"Invalid input_image.detail: {value!r}"
    raise AgentermError(msg)


def _require_message_status(
    value: JSONValue | None,
) -> Literal["in_progress", "completed", "incomplete"]:
    if value == "in_progress":
        return "in_progress"
    if value == "incomplete":
        return "incomplete"
    if value == "completed" or value is None:
        return "completed"
    msg = f"Invalid agent message.status: {value!r}"
    raise AgentermError(msg)


def _as_mapping(value: JSONValue | None, *, context: str) -> dict[str, JSONValue]:
    if not isinstance(value, dict):
        msg = f"Invalid {context}: expected object."
        raise AgentermError(msg)
    return value


def _as_list(value: JSONValue | None, *, context: str) -> list[JSONValue]:
    if not isinstance(value, list):
        msg = f"Invalid {context}: expected list."
        raise AgentermError(msg)
    return value


def _annotation_mapping_to_output_param(
    ann: JSONValue,
) -> OutputTextAnnotationParam:
    data = _as_mapping(ann, context="output_text.annotations[]")
    ann_type = _require_str(data.get("type"), context="annotation.type")
    if ann_type == "file_citation":
        return {
            "type": "file_citation",
            "file_id": _require_str(
                data.get("file_id"),
                context="file_citation.file_id",
            ),
            "filename": _require_str(
                data.get("filename"),
                context="file_citation.filename",
            ),
            "index": _require_int(data.get("index"), context="file_citation.index"),
        }
    if ann_type == "url_citation":
        return {
            "type": "url_citation",
            "start_index": _require_int(
                data.get("start_index"),
                context="url_citation.start_index",
            ),
            "end_index": _require_int(
                data.get("end_index"),
                context="url_citation.end_index",
            ),
            "title": _require_str(data.get("title"), context="url_citation.title"),
            "url": _require_str(data.get("url"), context="url_citation.url"),
        }
    if ann_type == "container_file_citation":
        return {
            "type": "container_file_citation",
            "container_id": _require_str(
                data.get("container_id"),
                context="container_file_citation.container_id",
            ),
            "file_id": _require_str(
                data.get("file_id"),
                context="container_file_citation.file_id",
            ),
            "filename": _require_str(
                data.get("filename"),
                context="container_file_citation.filename",
            ),
            "start_index": _require_int(
                data.get("start_index"),
                context="container_file_citation.start_index",
            ),
            "end_index": _require_int(
                data.get("end_index"),
                context="container_file_citation.end_index",
            ),
        }
    if ann_type == "file_path":
        return {
            "type": "file_path",
            "file_id": _require_str(data.get("file_id"), context="file_path.file_id"),
            "index": _require_int(data.get("index"), context="file_path.index"),
        }
    msg = f"Unsupported annotation type: {ann_type}"
    raise AgentermError(msg)


def _output_text_mapping_to_param(
    part: Mapping[str, JSONValue],
) -> ResponseOutputTextParam:
    text = _require_str(part.get("text"), context="output_text.text")
    raw_annotations = part.get("annotations")
    if raw_annotations is None:
        annotations: list[OutputTextAnnotationParam] = []
    else:
        annotations = [
            _annotation_mapping_to_output_param(ann)
            for ann in _as_list(raw_annotations, context="output_text.annotations")
        ]
    return {
        "type": "output_text",
        "text": text,
        "annotations": annotations,
    }


def _output_refusal_mapping_to_param(
    part: Mapping[str, JSONValue],
) -> ResponseOutputRefusalParam:
    return {
        "type": "refusal",
        "refusal": _require_str(part.get("refusal"), context="refusal.refusal"),
    }


def _message_content_to_output_parts(
    content: JSONValue | None,
) -> list[OutputMessageContentParam]:
    if content is None:
        return []
    parts_raw = _as_list(content, context="message.content")
    out: list[OutputMessageContentParam] = []
    for raw in parts_raw:
        part = _as_mapping(raw, context="message.content[]")
        part_type = _require_str(part.get("type"), context="message.content[].type")
        if part_type == "output_text":
            out.append(_output_text_mapping_to_param(part))
            continue
        if part_type == "refusal":
            out.append(_output_refusal_mapping_to_param(part))
            continue
        if part_type == "input_text":
            # The SDK may construct input_text parts as ResponseOutputText inside
            # message.content (see ARCH 1.9.4). Convert to output_text for replay.
            out.append(
                {
                    "type": "output_text",
                    "text": _require_str(part.get("text"), context="input_text.text"),
                    "annotations": [],
                },
            )
            continue
        msg = f"Unsupported agent message content type: {part_type}"
        raise AgentermError(msg)
    return out


def _input_text_mapping_to_param(
    part: Mapping[str, JSONValue],
) -> ResponseInputTextParam:
    type_val: Literal["input_text"] = "input_text"
    return {
        "type": type_val,
        "text": _require_str(part.get("text"), context="input_text.text"),
    }


def _input_image_mapping_to_param(
    part: Mapping[str, JSONValue],
) -> ResponseInputImageParam:
    detail = _require_image_detail(part.get("detail"))
    type_val: Literal["input_image"] = "input_image"
    out: ResponseInputImageParam = {"type": type_val, "detail": detail}
    file_id = part.get("file_id")
    if isinstance(file_id, str) and file_id:
        out["file_id"] = file_id
    image_url = part.get("image_url")
    if isinstance(image_url, str) and image_url:
        out["image_url"] = image_url
    if "file_id" not in out and "image_url" not in out:
        msg = "Invalid input_image: missing both file_id and image_url."
        raise AgentermError(msg)
    return out


def _input_file_mapping_to_param(
    part: Mapping[str, JSONValue],
) -> ResponseInputFileParam:
    type_val: Literal["input_file"] = "input_file"
    out: ResponseInputFileParam = {"type": type_val}
    file_data = part.get("file_data")
    if isinstance(file_data, str) and file_data:
        out["file_data"] = file_data
    file_id = part.get("file_id")
    if isinstance(file_id, str) and file_id:
        out["file_id"] = file_id
    file_url = part.get("file_url")
    if isinstance(file_url, str) and file_url:
        out["file_url"] = file_url
    filename = part.get("filename")
    if isinstance(filename, str) and filename:
        out["filename"] = filename
    if "file_data" not in out and "file_id" not in out and "file_url" not in out:
        msg = "Invalid input_file: missing file_data, file_id, and file_url."
        raise AgentermError(msg)
    return out


def _message_content_to_input_parts(
    content: JSONValue | None,
) -> ResponseInputMessageContentListParam:
    if content is None:
        return []
    parts_raw = _as_list(content, context="message.content")
    out: ResponseInputMessageContentListParam = []
    for raw in parts_raw:
        part = _as_mapping(raw, context="message.content[]")
        part_type = _require_str(part.get("type"), context="message.content[].type")
        if part_type == "input_text":
            out.append(_input_text_mapping_to_param(part))
            continue
        if part_type == "input_image":
            out.append(_input_image_mapping_to_param(part))
            continue
        if part_type == "input_file":
            out.append(_input_file_mapping_to_param(part))
            continue
        msg = f"Unsupported input message content type: {part_type}"
        raise AgentermError(msg)
    return out


def _message_mapping_to_snapshot_item(
    message: Mapping[str, JSONValue],
    *,
    seq: int,
) -> TResponseInputItem:
    msg_type: Literal["message"] = "message"
    role = _require_str(message.get("role"), context="message.role")
    if role == "assistant":
        message_id = message.get("id")
        mid = (
            message_id
            if isinstance(message_id, str) and message_id
            else f"compaction_msg_{seq}"
        )
        status = _require_message_status(message.get("status"))
        return {
            "id": mid,
            "type": msg_type,
            "role": "assistant",
            "status": status,
            "content": _message_content_to_output_parts(message.get("content")),
        }
    if role in {"user", "system", "developer"}:
        role_val: Literal["user", "system", "developer"]
        if role == "system":
            role_val = "system"
        elif role == "developer":
            role_val = "developer"
        else:
            role_val = "user"
        return {
            "type": msg_type,
            "role": role_val,
            "content": _message_content_to_input_parts(message.get("content")),
        }
    msg = f"Unsupported message.role in compaction output: {role!r}"
    raise AgentermError(msg)


def _compaction_mapping_to_snapshot_item(
    item: Mapping[str, JSONValue],
) -> ResponseCompactionItemParamParam:
    type_val: Literal["compaction"] = "compaction"
    out: ResponseCompactionItemParamParam = {
        "type": type_val,
        "encrypted_content": _require_str(
            item.get("encrypted_content"),
            context="compaction.encrypted_content",
        ),
    }
    cid = item.get("id")
    if isinstance(cid, str) and cid:
        out["id"] = cid
    return out


def usage_from_compacted_response(resp: CompactedResponse) -> TokenUsage | None:
    """Extract usage totals from a CompactedResponse when available."""
    raw = resp.to_json(
        indent=None,
        use_api_names=True,
        exclude_unset=True,
        warnings=False,
    )
    data = parse_json_object(raw)
    if data is None:
        return None
    usage_obj = data.get("usage")
    if usage_obj is None:
        return None
    usage = _as_mapping(usage_obj, context="usage")
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    total_tokens = usage.get("total_tokens")
    if (
        not isinstance(input_tokens, int)
        or not isinstance(output_tokens, int)
        or not isinstance(total_tokens, int)
    ):
        return None

    cached_tokens = 0
    input_details_obj = usage.get("input_tokens_details")
    if input_details_obj is not None:
        input_details = _as_mapping(
            input_details_obj,
            context="usage.input_tokens_details",
        )
        cached_obj = input_details.get("cached_tokens")
        if isinstance(cached_obj, int):
            cached_tokens = cached_obj

    reasoning_tokens = 0
    output_details_obj = usage.get("output_tokens_details")
    if output_details_obj is not None:
        output_details = _as_mapping(
            output_details_obj,
            context="usage.output_tokens_details",
        )
        reasoning_obj = output_details.get("reasoning_tokens")
        if isinstance(reasoning_obj, int):
            reasoning_tokens = reasoning_obj

    return TokenUsage(
        requests=1,
        input_tokens=input_tokens,
        input_cached_tokens=cached_tokens,
        output_tokens=output_tokens,
        output_reasoning_tokens=reasoning_tokens,
        total_tokens=total_tokens,
    )


def snapshot_items_from_compacted_response(
    resp: CompactedResponse,
) -> list[TResponseInputItem]:
    """Convert a CompactedResponse into next-run replay items.

    The returned list is intended to be written directly into an Agents session
    (e.g. `AdvancedSQLiteSession.add_items(...)`) and then replayed into the next
    Responses request via stateless session history (SDK turns).
    """
    messages: list[TResponseInputItem] = []
    compaction_item: ResponseCompactionItemParamParam | None = None
    seq: int = 0
    for item in resp.output:
        seq += 1
        raw_json = item.to_json(
            indent=None,
            use_api_names=True,
            exclude_unset=True,
            warnings=False,
        )
        raw = parse_json_object(raw_json)
        if raw is None:
            msg = "Failed to decode compaction output item JSON."
            raise AgentermError(msg)
        item_type = _require_str(raw.get("type"), context="compaction.output[].type")
        if item_type == "compaction":
            compaction_item = _compaction_mapping_to_snapshot_item(raw)
            continue
        if item_type == "message":
            messages.append(_message_mapping_to_snapshot_item(raw, seq=seq))
            continue
        msg = f"Unexpected compaction output item type: {item_type!r}"
        raise AgentermError(msg)

    if compaction_item is None:
        msg = "Compaction response did not include a compaction item."
        raise AgentermError(msg)
    return [*messages, compaction_item]


__all__ = ("snapshot_items_from_compacted_response", "usage_from_compacted_response")
