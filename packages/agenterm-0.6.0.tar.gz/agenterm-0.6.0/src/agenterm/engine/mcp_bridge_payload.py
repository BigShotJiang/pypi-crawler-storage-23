"""Payload/channel helpers for MCP bridge envelopes."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp import types as mtypes

from agenterm.core.json_codec import JSONLike, dumps_compact, require_json_value

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agenterm.core.json_types import JSONValue


def content_text_and_truncation(
    items: Sequence[mtypes.ContentBlock],
    *,
    max_items: int,
) -> tuple[str, bool]:
    """Return newline-joined content text plus truncation marker."""
    truncated = False
    blocks = list(items)
    if max_items > 0 and len(blocks) > max_items:
        blocks = blocks[:max_items]
        truncated = True
    parts: list[str] = []
    for item in blocks:
        if isinstance(item, mtypes.TextContent):
            parts.append(item.text)
            continue
        dumped = item.model_dump(by_alias=True, exclude_none=True)
        parts.append(
            dumps_compact(
                require_json_value(
                    value=dumped,
                    context="mcp.bridge.content_block",
                ),
                ensure_ascii=True,
                context="mcp.bridge.content_block",
            )
        )
    return "\n".join(parts), truncated


def content_blocks_and_truncation(
    items: Sequence[mtypes.ContentBlock],
    *,
    max_items: int,
) -> tuple[list[JSONValue], bool]:
    """Return normalized content blocks plus truncation marker."""
    truncated = False
    blocks = list(items)
    if max_items > 0 and len(blocks) > max_items:
        blocks = blocks[:max_items]
        truncated = True
    normalized: list[JSONValue] = []
    for item in blocks:
        dumped = item.model_dump(by_alias=True, exclude_none=True)
        normalized.append(
            require_json_value(
                value=dumped,
                context="mcp.bridge.content_block",
            )
        )
    return normalized, truncated


def structured_payload(structured: JSONLike | None) -> JSONValue | None:
    """Normalize structured MCP payload into canonical JSON value algebra."""
    if structured is None:
        return None
    return require_json_value(
        value=structured,
        context="mcp.bridge.structured_content",
    )


def text_from_content_blocks(value: JSONValue | None) -> str:
    """Extract plain text lines from normalized text content blocks."""
    if not isinstance(value, list):
        return ""
    texts: list[str] = []
    for entry in value:
        if not isinstance(entry, dict):
            continue
        text = entry.get("text")
        if entry.get("type") == "text" and isinstance(text, str):
            texts.append(text)
    return "\n".join(texts)


__all__ = (
    "content_blocks_and_truncation",
    "content_text_and_truncation",
    "structured_payload",
    "text_from_content_blocks",
)
