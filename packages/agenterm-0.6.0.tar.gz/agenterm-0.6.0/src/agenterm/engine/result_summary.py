"""Helpers to derive CLI summaries from Agents RunResult/RunResultStreaming.

These helpers are grounded in the actual Agents + Responses runtime types
from the installed `.venv`:

- RunResultBase / RunResultStreaming:
  `.venv:lib/python3.12/site-packages/agents/result.py`
- MessageOutputItem / ToolCallItem / ToolCallOutputItem:
  `.venv:lib/python3.12/site-packages/agents/items.py`
- ResponseOutputMessageParam / ResponseOutputTextParam:
  `.venv:lib/python3.12/site-packages/openai/types/responses/response_output_message_param.py`
  `.venv:lib/python3.12/site-packages/openai/types/responses/response_output_text_param.py`
"""

from __future__ import annotations

from collections import Counter
from typing import TYPE_CHECKING

from agents.items import MessageOutputItem, ToolCallItem, ToolCallOutputItem
from openai.types.responses.response_output_text import ResponseOutputText

from agenterm.core.token_usage import TokenUsage

if TYPE_CHECKING:
    from agents.result import RunResultBase
    from openai.types.responses.response_output_message import ResponseOutputMessage


def _content_as_text_segments(message: ResponseOutputMessage) -> list[str]:
    """Extract all output_text segments from a Responses message."""
    return [
        content.text
        for content in message.content
        if isinstance(content, ResponseOutputText)
    ]


def extract_final_text(result: RunResultBase) -> str | None:
    """Return the best-effort final agent output text from a run result.

    Priority:
    - If RunResultBase.final_output is a non-empty string, use it; the
      Agents SDK often populates this for simple runs.
    - Otherwise, walk MessageOutputItem.raw_item.content (a
      ResponseOutputMessageParam) and concatenate all `output_text` segments
      from the last assistant-role message.
    """
    final_output = result.final_output
    if isinstance(final_output, str) and final_output:
        return final_output

    for item in reversed(result.new_items):
        if not isinstance(item, MessageOutputItem):
            continue
        raw: ResponseOutputMessage = item.raw_item
        texts = _content_as_text_segments(raw)
        if texts:
            return "".join(texts)
    return None


def _tool_label_from_tool_item(item: ToolCallItem) -> str | None:
    raw_data = item.to_input_item()
    raw_type = raw_data.get("type")
    raw_name = raw_data.get("name")
    if raw_type == "function_call" and isinstance(raw_name, str):
        return f"function:{raw_name}"
    if raw_type == "mcp_call" and isinstance(raw_name, str):
        return f"mcp:{raw_name}"
    if isinstance(raw_type, str):
        return raw_type
    return None


def summarize_tools_counts(result: RunResultBase) -> dict[str, int]:
    """Return tool usage counts keyed by stable labels."""
    counts: Counter[str] = Counter()
    for item in result.new_items:
        if isinstance(item, ToolCallItem):
            label = _tool_label_from_tool_item(item)
            if label:
                counts[label] += 1
        elif isinstance(item, ToolCallOutputItem):
            # Outputs are useful for richer summaries later, but we avoid
            # double-counting by treating ToolCallItem as the canonical
            # source of tool invocations.
            continue
    return dict(counts)


def summarize_tools(result: RunResultBase) -> str | None:
    """Return a compact tool usage summary string, or None if no tools.

    Labels are derived from ``summarize_tools_counts`` to keep string and
    structured summaries consistent.
    """
    counts = summarize_tools_counts(result)
    if not counts:
        return None
    parts = [
        f"{name} x{count}" if count > 1 else name for name, count in counts.items()
    ]
    return ", ".join(parts)


def summarize_usage(result: RunResultBase) -> str | None:
    """Return a human-friendly usage summary from the run context, if any."""
    details = summarize_usage_details(result)
    if details is None:
        return None
    return (
        f"req={details['requests']} "
        f"in={details['input_tokens']} (c={details['input_cached_tokens']}) "
        f"out={details['output_tokens']} (r={details['output_reasoning_tokens']}) "
        f"tot={details['total_tokens']}"
    )


def summarize_usage_glance(result: RunResultBase) -> str | None:
    """Return a short token signal intended for the REPL HUD.

    Goal: provide a context-window proxy, not an “integral cost” summary.

    - We use per-request usage from the last provider request in this run:
      `result.raw_responses[-1].usage.input_tokens`.
    - When a run includes multiple provider requests, we surface the request
      count as a multiplier.
    """
    if not result.raw_responses:
        return None
    last = result.raw_responses[-1]
    last_in = last.usage.input_tokens
    req = len(result.raw_responses)
    base = f"in:{int(last_in)}"
    return f"{base}x{req}" if req > 1 else base


def summarize_usage_details(result: RunResultBase) -> dict[str, int] | None:
    """Return structured usage details if available."""
    usage_obj = result.context_wrapper.usage
    usage = TokenUsage.from_agents_usage(usage_obj)
    return usage.to_mapping()
