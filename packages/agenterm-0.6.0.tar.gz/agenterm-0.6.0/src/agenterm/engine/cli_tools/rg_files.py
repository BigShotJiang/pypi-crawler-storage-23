"""rg file-mode helpers (files-with-matches)."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from agenterm.core.errors import ToolExecutionError
from agenterm.engine.cli_tools.shared import build_safe_env, resolve_path
from agenterm.engine.subprocess_runner import (
    read_line_or_cancel,
    spawn_subprocess,
    terminate_process,
)

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from agenterm.core.cancellation import CancelToken
    from agenterm.engine.cli_tools.rg_parse import RgArgs


def rg_files_command(
    args: RgArgs,
    *,
    glob_filters: Sequence[str],
    resolved_paths: Sequence[str],
) -> list[str]:
    """Build rg arguments for files-with-matches mode."""
    cmd: list[str] = ["rg", "-l", "--sort=path"]
    if args.include_hidden:
        cmd.append("--hidden")
    if not args.gitignore:
        cmd.append("--no-ignore")
    if args.effective_pattern_mode == "literal":
        cmd.append("-F")
    if args.case_mode == "sensitive":
        cmd.append("--case-sensitive")
    elif args.case_mode == "smart":
        cmd.append("--smart-case")
    else:
        cmd.append("--ignore-case")
    for glob_filter in glob_filters:
        cmd.extend(["-g", glob_filter])
    cmd.append(args.pattern)
    cmd.extend(resolved_paths)
    return cmd


async def _read_rg_files_stream(
    proc: asyncio.subprocess.Process,
    *,
    max_files: int,
    cancel_token: CancelToken | None,
) -> tuple[list[str], bool, bool]:
    files: list[str] = []
    truncated = False
    terminated = False
    stdout = proc.stdout
    if stdout is None:
        return files, truncated, terminated
    while True:
        raw_line = await read_line_or_cancel(
            stdout,
            process=proc,
            cancel_token=cancel_token,
        )
        if not raw_line:
            break
        if len(files) >= max_files:
            truncated = True
            terminated = True
            terminate_process(proc)
            break
        line_text = raw_line.decode("utf-8", "replace").strip()
        if not line_text:
            continue
        files.append(line_text)
    return files, truncated, terminated


async def run_rg_files_command(
    *,
    cmd: Sequence[str],
    workspace_root: Path,
    max_files: int,
    cancel_token: CancelToken | None,
) -> tuple[list[str], bool, bool, int, str]:
    """Run rg in file mode and return raw paths plus exit metadata."""
    try:
        proc = await spawn_subprocess(
            cmd,
            cwd=str(workspace_root),
            env=build_safe_env(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cancel_token=cancel_token,
        )
    except ToolExecutionError as exc:
        return [], False, False, 127, str(exc)
    files, truncated, terminated = await _read_rg_files_stream(
        proc,
        max_files=max_files,
        cancel_token=cancel_token,
    )
    _stdout_tail, stderr_tail = await proc.communicate()
    stderr_text = stderr_tail.decode("utf-8", "replace") if stderr_tail else ""
    exit_code = int(proc.returncode or 0)
    return files, truncated, terminated, exit_code, stderr_text


def normalize_rg_files(
    files: Sequence[str],
    *,
    workspace_root: Path,
) -> list[str]:
    """Resolve rg file paths against the workspace root."""
    normalized: list[str] = []
    for path_text in files:
        resolved = resolve_path(workspace_root, path_text)
        if resolved is None:
            continue
        _abs_path, rel = resolved
        normalized.append(rel)
    return normalized


__all__ = ("normalize_rg_files", "rg_files_command", "run_rg_files_command")
