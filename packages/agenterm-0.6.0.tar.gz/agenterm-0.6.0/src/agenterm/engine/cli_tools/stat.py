"""stat local CLI tool implementation."""

from __future__ import annotations

import asyncio
import os
import stat as stat_mod
from dataclasses import dataclass
from datetime import UTC, datetime
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.constants.limits import (
    SAFE_OFFSET_MAX,
    SAFE_OFFSET_MIN,
    STAT_MAX_PATHS_MAX,
    STAT_MAX_PATHS_MIN,
)
from agenterm.core.json_codec import as_bool, as_str_list, parse_json_object
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    count_text_lines_checked,
    error_output,
    path_error_kind,
    reason_details,
    resolve_path_checked,
    success_output,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_stat

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.tool_context import ToolContext

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONMapping, JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_STAT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "stat metadata parameters.",
    "properties": {
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": STAT_MAX_PATHS_MIN,
            "maxItems": STAT_MAX_PATHS_MAX,
            "description": "Workspace-relative paths to stat.",
        },
        "include_lines": {
            "type": "boolean",
            "description": "Include line counts (files + directory totals).",
            "default": True,
        },
    },
    "required": ["paths", "include_lines"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class StatArgs:
    """Parsed stat arguments."""

    paths: list[str]
    include_lines: bool


def _stat_error(message: str) -> str:
    return error_output("stat", kind=INVALID_INPUT_KIND, message=message)


def _parse_stat_args(raw: str) -> tuple[StatArgs | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None or set(payload) - {"paths", "include_lines"}:
        return None, _stat_error("Invalid stat payload.")
    paths = as_str_list(payload.get("paths"), drop_empty=True)
    if paths is None or not paths:
        return None, _stat_error("stat requires paths.")
    if len(paths) < STAT_MAX_PATHS_MIN or len(paths) > STAT_MAX_PATHS_MAX:
        return None, _stat_error("Invalid stat paths length.")
    include_lines_raw = payload.get("include_lines")
    include_lines = (
        as_bool(include_lines_raw) if include_lines_raw is not None else True
    )
    if include_lines is None:
        return None, _stat_error("Invalid stat include_lines flag.")

    return StatArgs(paths=paths, include_lines=include_lines), None


def _raise_if_cancelled(cancel_token: CancelToken | None) -> None:
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()


def _prune_symlink_dirs(root: Path, dirnames: list[str]) -> None:
    """Mutate dirnames in-place to prevent os.walk from following symlink dirs."""
    dirnames[:] = [name for name in dirnames if not (root / name).is_symlink()]


def _non_symlink_file_paths(root: Path, filenames: list[str]) -> list[Path]:
    """Return non-symlink file paths for a single os.walk root."""
    return [root / name for name in filenames if not (root / name).is_symlink()]


def _format_mode(mode_int: int) -> str:
    """Return zero-padded permission bits (e.g., 0644)."""
    return format(mode_int & 0o7777, "04o")


def _iso_timestamp(epoch_seconds: float | None) -> str | None:
    if epoch_seconds is None:
        return None
    try:
        return datetime.fromtimestamp(epoch_seconds, tz=UTC).isoformat()
    except (OverflowError, OSError, ValueError):
        return None


def _type_from_mode(mode_int: int) -> str:
    if stat_mod.S_ISDIR(mode_int):
        return "dir"
    if stat_mod.S_ISREG(mode_int):
        return "file"
    return "other"


def _stat_row_error(
    raw_path: str,
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None,
) -> dict[str, JSONValue]:
    error_details = dict(details) if details is not None else {}
    return {
        "path": raw_path,
        "ok": False,
        "error": {"kind": kind, "message": message, "details": error_details},
    }


def _stat_row_ok(
    rel_path: str,
    *,
    path_type: str,
    bytes_value: int | None,
    lines_value: int | None,
    binary: bool,
    modified: str | None,
    mode: str | None,
) -> dict[str, JSONValue]:
    row: dict[str, JSONValue] = {"path": rel_path, "ok": True, "type": path_type}
    if bytes_value is not None:
        row["bytes"] = int(bytes_value)
    if binary:
        row["binary"] = True
    if lines_value is not None:
        row["lines"] = int(lines_value)
    if modified is not None:
        row["modified"] = modified
    if mode is not None:
        row["mode"] = mode
    return row


def _lstat_sync(path: Path) -> os.stat_result:
    return path.stat(follow_symlinks=False)


def _directory_totals_sync(
    abs_path: Path,
    *,
    include_lines: bool,
    cancel_token: CancelToken | None,
) -> tuple[int, int]:
    total_bytes = 0
    total_lines = 0
    for root, dirnames, filenames in os.walk(abs_path, followlinks=False):
        _raise_if_cancelled(cancel_token)
        root_path = Path(root)
        _prune_symlink_dirs(root_path, dirnames)
        file_paths = _non_symlink_file_paths(root_path, filenames)
        for file_path in file_paths:
            _raise_if_cancelled(cancel_token)
            try:
                st = file_path.stat(follow_symlinks=False)
            except OSError:
                continue
            total_bytes += int(st.st_size)
            if include_lines:
                lines_count, kind = count_text_lines_checked(file_path)
                if kind == "text" and lines_count is not None:
                    total_lines += int(lines_count)
    return int(total_bytes), int(total_lines)


async def _stat_file_row(
    *,
    abs_path: Path,
    rel_path: str,
    st: os.stat_result,
    include_lines: bool,
    cancel_token: CancelToken | None,
) -> dict[str, JSONValue]:
    binary = False
    lines_val: int | None = None
    if include_lines:
        _raise_if_cancelled(cancel_token)
        lines_count, kind = await asyncio.to_thread(count_text_lines_checked, abs_path)
        if kind == "binary":
            binary = True
        elif kind == "text" and lines_count is not None:
            lines_val = int(lines_count)

    return _stat_row_ok(
        rel_path,
        path_type="file",
        bytes_value=int(st.st_size),
        lines_value=lines_val,
        binary=binary,
        modified=_iso_timestamp(st.st_mtime),
        mode=_format_mode(int(st.st_mode)),
    )


async def _stat_dir_row(
    *,
    abs_path: Path,
    rel_path: str,
    st: os.stat_result,
    include_lines: bool,
    cancel_token: CancelToken | None,
) -> dict[str, JSONValue]:
    total_bytes, total_lines = await asyncio.to_thread(
        _directory_totals_sync,
        abs_path,
        include_lines=include_lines,
        cancel_token=cancel_token,
    )
    return _stat_row_ok(
        rel_path,
        path_type="dir",
        bytes_value=total_bytes,
        lines_value=total_lines if include_lines else None,
        binary=False,
        modified=_iso_timestamp(st.st_mtime),
        mode=_format_mode(int(st.st_mode)),
    )


def _resolve_path(
    workspace_root: Path,
    raw: str,
) -> tuple[tuple[Path, str] | None, str | None]:
    return resolve_path_checked(workspace_root, raw, expect="any")


def _clamp_paths(paths: list[str]) -> list[str]:
    """Protect against runaway lists even after schema validation."""
    if len(paths) > SAFE_OFFSET_MAX:
        return paths[:SAFE_OFFSET_MAX]
    if len(paths) < SAFE_OFFSET_MIN:
        return []
    return paths


def _stat_payload(results: Sequence[JSONMapping]) -> dict[str, JSONValue]:
    return {"results": [dict(item) for item in results]}


async def _stat_payload_from_args(
    *,
    args: StatArgs,
    workspace_root: Path,
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    clamped_paths = _clamp_paths(args.paths)
    if not clamped_paths:
        return None, _stat_error("stat requires paths.")

    results: list[dict[str, JSONValue]] = []
    for raw_path in clamped_paths:
        resolved, reason = await asyncio.to_thread(
            _resolve_path,
            workspace_root,
            raw_path,
        )
        _raise_if_cancelled(cancel_token)
        if resolved is None:
            kind = path_error_kind(reason)
            results.append(
                _stat_row_error(
                    raw_path,
                    kind=kind,
                    message="Invalid stat path.",
                    details=reason_details(reason, field="path"),
                )
            )
            continue

        abs_path, rel_path = resolved
        try:
            st = await asyncio.to_thread(_lstat_sync, abs_path)
        except FileNotFoundError:
            results.append(
                _stat_row_error(
                    raw_path,
                    kind=path_error_kind("not_found"),
                    message="Path does not exist.",
                    details=reason_details("not_found", field="path"),
                )
            )
            continue
        except OSError:
            results.append(
                _stat_row_error(
                    raw_path,
                    kind=TOOL_ERROR_KIND,
                    message="Failed to stat path.",
                    details=reason_details("stat_failed", field="path"),
                )
            )
            continue

        path_type = _type_from_mode(int(st.st_mode))
        if path_type == "dir":
            row = await _stat_dir_row(
                abs_path=abs_path,
                rel_path=rel_path,
                st=st,
                include_lines=args.include_lines,
                cancel_token=cancel_token,
            )
        elif path_type == "file":
            row = await _stat_file_row(
                abs_path=abs_path,
                rel_path=rel_path,
                st=st,
                include_lines=args.include_lines,
                cancel_token=cancel_token,
            )
        else:
            row = _stat_row_ok(
                rel_path,
                path_type="other",
                bytes_value=int(st.st_size),
                lines_value=None,
                binary=False,
                modified=_iso_timestamp(st.st_mtime),
                mode=_format_mode(int(st.st_mode)),
            )
        results.append(row)

    return _stat_payload(results), None


async def _invoke_stat(
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
    *,
    workspace_root: Path,
) -> str:
    cancel_token = ctx.context.cancel_token
    _raise_if_cancelled(cancel_token)
    args, error = _parse_stat_args(raw)
    if error is not None:
        return error
    if args is None:
        return _stat_error("Invalid stat payload.")
    payload, error = await _stat_payload_from_args(
        args=args,
        workspace_root=workspace_root,
        cancel_token=cancel_token,
    )
    if error is not None:
        return error
    if payload is None:
        return _stat_error("Invalid stat payload.")
    return success_output("stat", payload)


def build_stat_tool(
    workspace_root: Path,
) -> FunctionTool:
    """Build the stat inspection operation engine."""
    validate_strict_schema("stat", _STAT_SCHEMA)

    return FunctionTool(
        name="stat",
        description=describe_stat(),
        params_json_schema=_STAT_SCHEMA,
        on_invoke_tool=partial(_invoke_stat, workspace_root=workspace_root),
        strict_json_schema=True,
    )


__all__ = ("build_stat_tool",)
