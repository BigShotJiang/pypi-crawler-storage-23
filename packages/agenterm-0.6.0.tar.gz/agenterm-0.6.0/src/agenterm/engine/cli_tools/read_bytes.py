"""read_bytes local tool implementation."""

from __future__ import annotations

import asyncio
import base64
from dataclasses import dataclass
from functools import partial
from typing import TYPE_CHECKING, Final

from agents.tool import FunctionTool

from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    build_page,
    error_output,
    parse_bounded_int,
    path_error_kind,
    reason_details,
    resolve_path_checked,
    success_output,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_read_bytes

if TYPE_CHECKING:
    from pathlib import Path

    from agents.tool_context import ToolContext

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_MAX_BYTES_DEFAULT: Final[int] = 32_768
_MAX_BYTES_MIN: Final[int] = 1
_MAX_BYTES_MAX: Final[int] = 262_144

_READ_BYTES_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Read binary bytes with base64 output.",
    "properties": {
        "path": {
            "type": "string",
            "description": "Workspace-relative file path.",
        },
        "offset": {
            "type": "integer",
            "minimum": 0,
            "description": "0-based byte offset.",
            "default": 0,
        },
        "max_bytes": {
            "type": "integer",
            "minimum": _MAX_BYTES_MIN,
            "maximum": _MAX_BYTES_MAX,
            "description": "Maximum bytes to read.",
            "default": _MAX_BYTES_DEFAULT,
        },
    },
    "required": ["path", "offset", "max_bytes"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class ReadBytesArgs:
    """Parsed read_bytes arguments."""

    path: str
    offset: int
    max_bytes: int


def _read_bytes_error(message: str) -> str:
    return error_output("read_bytes", kind=INVALID_INPUT_KIND, message=message)


def _raise_if_cancelled(cancel_token: CancelToken | None) -> None:
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()


def _parse_read_bytes_args(raw: str) -> tuple[ReadBytesArgs | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None or set(payload) - {"path", "offset", "max_bytes"}:
        return None, _read_bytes_error("Invalid read_bytes payload.")
    path = as_str(payload.get("path"))
    if path is None or not path.strip():
        return None, _read_bytes_error("read_bytes requires path.")
    offset = parse_bounded_int(
        payload.get("offset"),
        default=0,
        min_value=0,
        max_value=2_147_483_647,
    )
    max_bytes = parse_bounded_int(
        payload.get("max_bytes"),
        default=_MAX_BYTES_DEFAULT,
        min_value=_MAX_BYTES_MIN,
        max_value=_MAX_BYTES_MAX,
    )
    if offset is None or max_bytes is None:
        return None, _read_bytes_error("Invalid read_bytes bounds.")
    return ReadBytesArgs(path=path, offset=offset, max_bytes=max_bytes), None


def _read_slice_sync(path: Path, *, offset: int, max_bytes: int) -> tuple[bytes, int]:
    with path.open("rb") as handle:
        handle.seek(0, 2)
        total = int(handle.tell())
        handle.seek(max(0, int(offset)))
        content = handle.read(max_bytes)
    return content, total


async def _payload_from_args(
    *,
    args: ReadBytesArgs,
    workspace_root: Path,
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    resolved, reason = await asyncio.to_thread(
        resolve_path_checked,
        workspace_root,
        args.path,
        expect="file",
    )
    _raise_if_cancelled(cancel_token)
    if resolved is None:
        return None, error_output(
            "read_bytes",
            kind=path_error_kind(reason),
            message="Invalid read_bytes path.",
            details=reason_details(reason, field="path", requested_path=args.path),
        )
    abs_path, rel_path = resolved
    try:
        content, total_bytes = await asyncio.to_thread(
            _read_slice_sync,
            abs_path,
            offset=args.offset,
            max_bytes=args.max_bytes,
        )
    except OSError:
        return None, error_output(
            "read_bytes",
            kind=TOOL_ERROR_KIND,
            message="Failed to read file bytes.",
            details=reason_details("read_failed", field="path"),
        )
    _raise_if_cancelled(cancel_token)
    bytes_read = len(content)
    next_cursor: int | None = None
    if args.offset + bytes_read < total_bytes:
        next_cursor = args.offset + bytes_read
    page = build_page(
        kind="offset",
        cursor=args.offset,
        limit=args.max_bytes,
        returned=bytes_read,
        next_cursor=next_cursor,
        limit_reason="page_limit" if next_cursor is not None else None,
    )
    payload: dict[str, JSONValue] = {
        "path": rel_path,
        "offset": int(args.offset),
        "bytes_read": bytes_read,
        "total_bytes": int(total_bytes),
        "encoding": "base64",
        "data_base64": base64.b64encode(content).decode("ascii"),
        "page": page,
    }
    return payload, None


async def _invoke_read_bytes(
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
    *,
    workspace_root: Path,
) -> str:
    cancel_token = ctx.context.cancel_token
    _raise_if_cancelled(cancel_token)
    args, error = _parse_read_bytes_args(raw)
    if error is not None:
        return error
    if args is None:
        return _read_bytes_error("Invalid read_bytes payload.")
    payload, error = await _payload_from_args(
        args=args,
        workspace_root=workspace_root,
        cancel_token=cancel_token,
    )
    if error is not None:
        return error
    if payload is None:
        return _read_bytes_error("Invalid read_bytes payload.")
    return success_output("read_bytes", payload)


def build_read_bytes_tool(
    workspace_root: Path,
) -> FunctionTool:
    """Build the read_bytes inspection operation engine."""
    validate_strict_schema("read_bytes", _READ_BYTES_SCHEMA)
    return FunctionTool(
        name="read_bytes",
        description=describe_read_bytes(),
        params_json_schema=_READ_BYTES_SCHEMA,
        on_invoke_tool=partial(_invoke_read_bytes, workspace_root=workspace_root),
        strict_json_schema=True,
    )


__all__ = ("build_read_bytes_tool",)
