"""rg schema + argument parsing helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.constants.limits import (
    RG_CONTEXT_MAX,
    RG_CONTEXT_MIN,
    RG_LINE_MAX_CHARS_DEFAULT,
    RG_LINE_MAX_CHARS_MAX,
    RG_LINE_MAX_CHARS_MIN,
    RG_OUTPUT_MAX_ITEMS_DEFAULT,
    RG_OUTPUT_MAX_ITEMS_MAX,
    RG_OUTPUT_MAX_ITEMS_MIN,
    SAFE_OFFSET_MAX,
    SAFE_OFFSET_MIN,
)
from agenterm.core.json_codec import as_json_object, as_str, parse_json_object
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    error_output,
    parse_bounded_int,
    parse_optional_bool,
    parse_optional_str_list,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

_PATTERN_MODES = {"regex", "literal", "auto"}
_CASE_MODES = {"smart", "sensitive", "insensitive"}
_RESULT_MODES = {"matches", "files", "count", "summary"}

RG_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "rg search parameters (pattern, scope, paging).",
    "properties": {
        "pattern": {
            "type": "string",
            "description": (
                "Search pattern (regex or literal depending on pattern_mode)."
            ),
        },
        "pattern_mode": {
            "type": "string",
            "enum": ["regex", "literal", "auto"],
            "description": "How to interpret pattern.",
            "default": "auto",
        },
        "case_mode": {
            "type": "string",
            "enum": ["smart", "sensitive", "insensitive"],
            "description": "Case sensitivity mode.",
            "default": "smart",
        },
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Workspace-relative search roots.",
            "default": ["."],
        },
        "glob": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Glob filter(s) passed to rg -g.",
            "default": [],
        },
        "include_hidden": {
            "type": "boolean",
            "description": "Include hidden files and directories.",
            "default": False,
        },
        "gitignore": {
            "type": "boolean",
            "description": "Respect ignore files (.gitignore, .ignore, .rgignore).",
            "default": True,
        },
        "context": {
            "type": "object",
            "description": "Context lines to include before/after matches.",
            "properties": {
                "before": {
                    "type": "integer",
                    "minimum": RG_CONTEXT_MIN,
                    "maximum": RG_CONTEXT_MAX,
                    "description": "Context lines before each match.",
                    "default": RG_CONTEXT_MIN,
                },
                "after": {
                    "type": "integer",
                    "minimum": RG_CONTEXT_MIN,
                    "maximum": RG_CONTEXT_MAX,
                    "description": "Context lines after each match.",
                    "default": RG_CONTEXT_MIN,
                },
            },
            "additionalProperties": False,
            "default": {"before": RG_CONTEXT_MIN, "after": RG_CONTEXT_MIN},
        },
        "result_mode": {
            "type": "string",
            "enum": ["matches", "files", "count", "summary"],
            "description": "Output shape: matches | files | count | summary.",
            "default": "matches",
        },
        "offset": {
            "type": "integer",
            "minimum": 0,
            "description": "0-based result offset.",
            "default": SAFE_OFFSET_MIN,
        },
        "limit": {
            "type": "integer",
            "minimum": 1,
            "description": "Max results per page (after offset).",
            "default": RG_OUTPUT_MAX_ITEMS_DEFAULT,
        },
        "max_line_chars": {
            "type": "integer",
            "minimum": 1,
            "description": "Max characters per output line.",
            "default": RG_LINE_MAX_CHARS_DEFAULT,
        },
    },
    "additionalProperties": False,
}


@dataclass(frozen=True)
class RgArgs:
    """Parsed rg arguments."""

    pattern: str
    paths: list[str]
    pattern_mode: str
    effective_pattern_mode: str
    case_mode: str
    include_hidden: bool
    gitignore: bool
    before: int
    after: int
    result_mode: str
    offset: int
    limit: int
    max_line_chars: int


def _rg_error(message: str) -> str:
    return error_output("rg", kind=INVALID_INPUT_KIND, message=message)


def _parse_rg_payload(raw: str) -> tuple[dict[str, JSONValue] | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, _rg_error("Invalid rg payload.")
    if set(payload) - {
        "pattern",
        "pattern_mode",
        "case_mode",
        "paths",
        "glob",
        "include_hidden",
        "gitignore",
        "context",
        "result_mode",
        "offset",
        "limit",
        "max_line_chars",
    }:
        return None, _rg_error("Invalid rg payload.")
    return payload, None


def _parse_rg_paths(
    payload: Mapping[str, JSONValue],
) -> tuple[list[str], str | None]:
    paths = parse_optional_str_list(payload, key="paths", default=["."])
    if paths is None:
        return [], _rg_error("Invalid rg paths.")
    return paths, None


def _parse_rg_pattern(
    payload: Mapping[str, JSONValue],
) -> tuple[str, str | None]:
    pattern = as_str(payload.get("pattern"))
    if pattern is None or pattern == "":
        return "", _rg_error("rg requires a pattern.")
    return pattern, None


def _parse_rg_pattern_mode(
    payload: Mapping[str, JSONValue],
) -> tuple[str, str | None]:
    mode = as_str(payload.get("pattern_mode")) or "auto"
    if mode not in _PATTERN_MODES:
        return "", _rg_error("Invalid rg pattern_mode.")
    return mode, None


def _parse_rg_case_mode(
    payload: Mapping[str, JSONValue],
) -> tuple[str, str | None]:
    mode = as_str(payload.get("case_mode")) or "smart"
    if mode not in _CASE_MODES:
        return "", _rg_error("Invalid rg case_mode.")
    return mode, None


def _auto_pattern_mode(pattern: str) -> str:
    if "\\" in pattern:
        return "regex"
    if pattern.startswith("^") or pattern.endswith("$"):
        return "regex"
    if ".*" in pattern:
        return "regex"
    return "literal"


def _parse_rg_context(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[int, int], str | None]:
    raw = payload.get("context")
    if raw is None:
        return (RG_CONTEXT_MIN, RG_CONTEXT_MIN), None
    ctx = as_json_object(raw)
    if ctx is None:
        return (RG_CONTEXT_MIN, RG_CONTEXT_MIN), _rg_error("Invalid rg context.")
    if set(ctx) - {"before", "after"}:
        return (RG_CONTEXT_MIN, RG_CONTEXT_MIN), _rg_error("Invalid rg context.")
    before = parse_bounded_int(
        ctx.get("before"),
        default=RG_CONTEXT_MIN,
        min_value=RG_CONTEXT_MIN,
        max_value=RG_CONTEXT_MAX,
    )
    after = parse_bounded_int(
        ctx.get("after"),
        default=RG_CONTEXT_MIN,
        min_value=RG_CONTEXT_MIN,
        max_value=RG_CONTEXT_MAX,
    )
    if before is None or after is None:
        return (RG_CONTEXT_MIN, RG_CONTEXT_MIN), _rg_error("Invalid rg context bounds.")
    return (before, after), None


def _parse_rg_traversal_flags(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[bool, bool], str | None]:
    include_hidden = parse_optional_bool(
        payload,
        key="include_hidden",
        default=False,
    )
    gitignore = parse_optional_bool(
        payload,
        key="gitignore",
        default=True,
    )
    if include_hidden is None or gitignore is None:
        return (False, True), _rg_error("Invalid rg traversal flags.")
    return (include_hidden, gitignore), None


def _parse_rg_mode(
    payload: Mapping[str, JSONValue],
) -> tuple[str, str | None]:
    mode = as_str(payload.get("result_mode")) or "matches"
    if mode not in _RESULT_MODES:
        return "", _rg_error("Invalid rg result_mode.")
    return mode, None


def _parse_rg_pagination(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[int, int], str | None]:
    offset_val = parse_bounded_int(
        payload.get("offset"),
        default=SAFE_OFFSET_MIN,
        min_value=SAFE_OFFSET_MIN,
        max_value=SAFE_OFFSET_MAX,
    )
    limit_val = parse_bounded_int(
        payload.get("limit"),
        default=RG_OUTPUT_MAX_ITEMS_DEFAULT,
        min_value=RG_OUTPUT_MAX_ITEMS_MIN,
        max_value=RG_OUTPUT_MAX_ITEMS_MAX,
    )
    if offset_val is None or limit_val is None:
        return (SAFE_OFFSET_MIN, RG_OUTPUT_MAX_ITEMS_DEFAULT), _rg_error(
            "Invalid rg pagination bounds."
        )
    return (offset_val, limit_val), None


def _parse_rg_glob_filters(
    payload: Mapping[str, JSONValue],
) -> tuple[list[str], str | None]:
    glob_filters = parse_optional_str_list(
        payload,
        key="glob",
        default=[],
        allow_empty=True,
    )
    if glob_filters is None:
        return [], _rg_error("Invalid rg glob filter.")
    return glob_filters, None


def _parse_rg_max_line_chars(
    payload: Mapping[str, JSONValue],
) -> tuple[int, str | None]:
    max_chars = parse_bounded_int(
        payload.get("max_line_chars"),
        default=RG_LINE_MAX_CHARS_DEFAULT,
        min_value=RG_LINE_MAX_CHARS_MIN,
        max_value=RG_LINE_MAX_CHARS_MAX,
    )
    if max_chars is None:
        return RG_LINE_MAX_CHARS_DEFAULT, _rg_error("Invalid rg max_line_chars.")
    return max_chars, None


def _parse_rg_args_payload(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[RgArgs, list[str]] | None, str | None]:
    pattern, error = _parse_rg_pattern(payload)
    pattern_mode, error = (
        _parse_rg_pattern_mode(payload) if error is None else ("auto", error)
    )
    case_mode, error = (
        _parse_rg_case_mode(payload) if error is None else ("smart", error)
    )
    paths, error = _parse_rg_paths(payload) if error is None else (["."], error)
    traversal_flags, error = (
        _parse_rg_traversal_flags(payload) if error is None else ((False, True), error)
    )
    before_after, error = (
        _parse_rg_context(payload)
        if error is None
        else ((RG_CONTEXT_MIN, RG_CONTEXT_MIN), error)
    )
    result_mode, error = (
        _parse_rg_mode(payload) if error is None else ("matches", error)
    )
    pagination, error = (
        _parse_rg_pagination(payload)
        if error is None
        else ((SAFE_OFFSET_MIN, RG_OUTPUT_MAX_ITEMS_DEFAULT), error)
    )
    glob_filters, error = (
        _parse_rg_glob_filters(payload) if error is None else ([], error)
    )
    max_chars, error = (
        _parse_rg_max_line_chars(payload)
        if error is None
        else (RG_LINE_MAX_CHARS_DEFAULT, error)
    )
    if error is not None:
        return None, error

    effective_pattern_mode = (
        _auto_pattern_mode(pattern) if pattern_mode == "auto" else pattern_mode
    )
    if effective_pattern_mode not in {"regex", "literal"}:
        return None, _rg_error("Invalid rg pattern_mode.")
    include_hidden, gitignore = traversal_flags
    before, after = before_after
    offset, limit = pagination
    return (
        (
            RgArgs(
                pattern=pattern,
                paths=paths,
                pattern_mode=pattern_mode,
                effective_pattern_mode=effective_pattern_mode,
                case_mode=case_mode,
                include_hidden=include_hidden,
                gitignore=gitignore,
                before=before,
                after=after,
                result_mode=result_mode,
                offset=offset,
                limit=limit,
                max_line_chars=max_chars,
            ),
            glob_filters,
        ),
        None,
    )


def parse_rg_args(raw: str) -> tuple[tuple[RgArgs, list[str]] | None, str | None]:
    """Parse rg arguments + glob filters from a raw JSON payload string."""
    payload, error = _parse_rg_payload(raw)
    if error is not None or payload is None:
        return None, error or _rg_error("Invalid rg payload.")
    return _parse_rg_args_payload(payload)


__all__ = ("RG_SCHEMA", "RgArgs", "parse_rg_args")
