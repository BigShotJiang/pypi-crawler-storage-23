"""rg context helpers for before/after lines."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.text import shorten_line

if TYPE_CHECKING:
    from collections.abc import Mapping, MutableMapping, Sequence
    from pathlib import Path

    from agenterm.core.json_types import JSONValue


@dataclass
class PendingAfter:
    """Track pending context-after lines for rg."""

    entry: MutableMapping[str, JSONValue]
    remaining: int
    lines: list[str]


def _context_before(prev_lines: Sequence[str], *, max_line_chars: int) -> str:
    return "\n".join(shorten_line(text, limit=max_line_chars) for text in prev_lines)


def _advance_pending(
    pending: Sequence[PendingAfter],
    *,
    text: str,
    max_line_chars: int,
) -> list[PendingAfter]:
    if not pending:
        return []
    next_pending: list[PendingAfter] = []
    for item in pending:
        item.lines.append(shorten_line(text, limit=max_line_chars))
        remaining = item.remaining - 1
        item.remaining = remaining
        if remaining <= 0:
            item.entry["context_after"] = "\n".join(item.lines)
        else:
            next_pending.append(item)
    return next_pending


def _flush_pending(pending: Sequence[PendingAfter]) -> None:
    for item in pending:
        if item.lines:
            item.entry["context_after"] = "\n".join(item.lines)


def _build_line_map(
    entries: Sequence[MutableMapping[str, JSONValue]],
) -> dict[int, list[MutableMapping[str, JSONValue]]]:
    line_map: dict[int, list[MutableMapping[str, JSONValue]]] = {}
    for entry in entries:
        line_val = entry.get("line")
        if isinstance(line_val, int):
            line_map.setdefault(line_val, []).append(entry)
    return line_map


def _apply_before_context(
    line_map: Mapping[int, Sequence[MutableMapping[str, JSONValue]]],
    *,
    lineno: int,
    prev_lines: Sequence[str],
    before: int,
    max_line_chars: int,
) -> None:
    if before <= 0 or not prev_lines:
        return
    entries = line_map.get(lineno)
    if not entries:
        return
    ctx = _context_before(prev_lines, max_line_chars=max_line_chars)
    for entry in entries:
        entry["context_before"] = ctx


def _enqueue_after_context(
    line_map: Mapping[int, Sequence[MutableMapping[str, JSONValue]]],
    *,
    lineno: int,
    pending: list[PendingAfter],
    after: int,
) -> None:
    if after <= 0:
        return
    entries = line_map.get(lineno)
    if not entries:
        return
    pending.extend(
        [PendingAfter(entry=entry, remaining=after, lines=[]) for entry in entries]
    )


def _update_prev_lines(prev_lines: list[str], *, text: str, before: int) -> None:
    if before <= 0:
        return
    prev_lines.append(text)
    if len(prev_lines) > before:
        prev_lines.pop(0)


def _add_context_for_file(
    abs_path: Path,
    entries: Sequence[MutableMapping[str, JSONValue]],
    *,
    before: int,
    after: int,
    max_line_chars: int,
) -> None:
    line_map = _build_line_map(entries)
    if not line_map:
        return
    prev_lines: list[str] = []
    pending: list[PendingAfter] = []
    try:
        with abs_path.open("r", encoding="utf-8", errors="strict") as handle:
            for lineno, line in enumerate(handle, start=1):
                text = line.rstrip("\n")
                pending = _advance_pending(
                    pending,
                    text=text,
                    max_line_chars=max_line_chars,
                )
                _apply_before_context(
                    line_map,
                    lineno=lineno,
                    prev_lines=prev_lines,
                    before=before,
                    max_line_chars=max_line_chars,
                )
                _enqueue_after_context(
                    line_map,
                    lineno=lineno,
                    pending=pending,
                    after=after,
                )
                _update_prev_lines(prev_lines, text=text, before=before)
        _flush_pending(pending)
    except (OSError, UnicodeDecodeError):
        return


def add_context(
    entries: Sequence[tuple[Path, MutableMapping[str, JSONValue]]],
    *,
    before: int,
    after: int,
    max_line_chars: int,
) -> None:
    """Mutate entries to add before/after context text where requested."""
    if before <= 0 and after <= 0:
        return
    by_path: dict[Path, list[MutableMapping[str, JSONValue]]] = {}
    for abs_path, entry in entries:
        by_path.setdefault(abs_path, []).append(entry)
    for abs_path, items in by_path.items():
        _add_context_for_file(
            abs_path,
            items,
            before=before,
            after=after,
            max_line_chars=max_line_chars,
        )


__all__ = ("add_context",)
