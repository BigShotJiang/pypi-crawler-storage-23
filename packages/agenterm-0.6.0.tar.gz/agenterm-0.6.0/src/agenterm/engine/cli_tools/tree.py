"""tree local CLI tool implementation."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.constants.limits import (
    SAFE_OFFSET_MAX,
    SAFE_OFFSET_MIN,
    TREE_DEPTH_DEFAULT,
    TREE_DEPTH_MAX,
    TREE_DEPTH_MIN,
    TREE_OUTPUT_MAX_ITEMS_DEFAULT,
    TREE_OUTPUT_MAX_ITEMS_MAX,
    TREE_OUTPUT_MAX_ITEMS_MIN,
)
from agenterm.core.json_codec import as_str, parse_json_object, parse_json_value
from agenterm.engine.cli_tools.shared import (
    COMMAND_NOT_FOUND_EXIT_CODE,
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    build_page,
    build_safe_env,
    error_output,
    parse_bounded_int,
    parse_optional_bool,
    path_error_kind,
    reason_details,
    resolve_path_checked,
    run_command,
    success_output,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_tree

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.tool_context import ToolContext

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_TREE_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "tree listing parameters.",
    "properties": {
        "path": {
            "type": "string",
            "description": "Workspace-relative directory path.",
            "default": ".",
        },
        "depth": {
            "type": "integer",
            "minimum": TREE_DEPTH_MIN,
            "maximum": TREE_DEPTH_MAX,
            "description": "Max depth to traverse.",
            "default": TREE_DEPTH_DEFAULT,
        },
        "pattern_glob": {
            "type": ["string", "null"],
            "description": "Optional glob filter (tree -P).",
        },
        "match_dirs": {
            "type": "boolean",
            "description": "Apply pattern_glob to directories too.",
            "default": False,
        },
        "include_hidden": {
            "type": "boolean",
            "description": "Include hidden entries.",
            "default": False,
        },
        "dirs_only": {
            "type": "boolean",
            "description": "Return directories only.",
            "default": False,
        },
        "gitignore": {
            "type": "boolean",
            "description": "Respect .gitignore rules.",
            "default": True,
        },
        "offset": {
            "type": "integer",
            "minimum": SAFE_OFFSET_MIN,
            "maximum": SAFE_OFFSET_MAX,
            "description": "0-based node offset.",
            "default": SAFE_OFFSET_MIN,
        },
        "limit": {
            "type": "integer",
            "minimum": TREE_OUTPUT_MAX_ITEMS_MIN,
            "maximum": TREE_OUTPUT_MAX_ITEMS_MAX,
            "description": "Max nodes per page.",
            "default": TREE_OUTPUT_MAX_ITEMS_DEFAULT,
        },
    },
    "required": [
        "path",
        "depth",
        "pattern_glob",
        "match_dirs",
        "include_hidden",
        "dirs_only",
        "gitignore",
        "offset",
        "limit",
    ],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class TreeArgs:
    """Parsed tree arguments."""

    path: str
    depth: int
    pattern_glob: str | None
    match_dirs: bool
    include_hidden: bool
    dirs_only: bool
    gitignore: bool
    offset: int
    limit: int


def _tree_error(message: str) -> str:
    return error_output("tree", kind=INVALID_INPUT_KIND, message=message)


def _parse_tree_args(raw: str) -> tuple[TreeArgs | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None or set(payload) - {
        "path",
        "depth",
        "pattern_glob",
        "match_dirs",
        "include_hidden",
        "dirs_only",
        "gitignore",
        "offset",
        "limit",
    }:
        return None, _tree_error("Invalid tree payload.")

    error_msg: str | None = None
    path = as_str(payload.get("path")) or "."
    if not path.strip():
        error_msg = "tree requires a path."

    depth = parse_bounded_int(
        payload.get("depth"),
        default=TREE_DEPTH_DEFAULT,
        min_value=TREE_DEPTH_MIN,
        max_value=TREE_DEPTH_MAX,
    )
    if depth is None:
        return None, _tree_error("Invalid tree depth.")

    pattern_raw = payload.get("pattern_glob")
    pattern_val: str | None = None
    if pattern_raw is not None and not isinstance(pattern_raw, str):
        error_msg = error_msg or "Invalid tree pattern_glob."
    elif isinstance(pattern_raw, str) and pattern_raw.strip():
        pattern_val = pattern_raw

    match_dirs = parse_optional_bool(payload, key="match_dirs", default=False)
    include_hidden = parse_optional_bool(payload, key="include_hidden", default=False)
    dirs_only = parse_optional_bool(payload, key="dirs_only", default=False)
    gitignore = parse_optional_bool(payload, key="gitignore", default=True)
    if (
        match_dirs is None
        or include_hidden is None
        or dirs_only is None
        or gitignore is None
    ):
        return None, _tree_error("Invalid tree flags.")

    offset = parse_bounded_int(
        payload.get("offset"),
        default=SAFE_OFFSET_MIN,
        min_value=SAFE_OFFSET_MIN,
        max_value=SAFE_OFFSET_MAX,
    )
    limit = parse_bounded_int(
        payload.get("limit"),
        default=TREE_OUTPUT_MAX_ITEMS_DEFAULT,
        min_value=TREE_OUTPUT_MAX_ITEMS_MIN,
        max_value=TREE_OUTPUT_MAX_ITEMS_MAX,
    )
    if offset is None or limit is None:
        return None, _tree_error("Invalid tree paging.")

    if error_msg is not None:
        return None, _tree_error(error_msg)

    return (
        TreeArgs(
            path=path,
            depth=depth,
            pattern_glob=pattern_val,
            match_dirs=bool(match_dirs),
            include_hidden=include_hidden,
            dirs_only=dirs_only,
            gitignore=gitignore,
            offset=offset,
            limit=limit,
        ),
        None,
    )


def _tree_command(args: TreeArgs, *, rel_path: str, json_output: bool) -> list[str]:
    cmd: list[str] = ["tree"]
    if json_output:
        cmd.append("-J")
    else:
        cmd.extend(["-n", "--charset=ASCII"])
    cmd.extend(["-L", str(args.depth), "--noreport"])
    if args.include_hidden:
        cmd.append("-a")
    if args.dirs_only:
        cmd.append("-d")
    if args.pattern_glob is not None:
        cmd.extend(["-P", args.pattern_glob])
        if args.match_dirs:
            cmd.append("--matchdirs")
        else:
            cmd.append("--prune")
    if args.gitignore:
        cmd.append("--gitignore")
    cmd.append(rel_path or ".")
    return cmd


def _tree_node_type(value: str | None) -> str | None:
    if value == "directory":
        return "dir"
    if value == "file":
        return "file"
    return None


def _collect_tree_nodes(
    node: Mapping[str, JSONValue],
    *,
    current_path: Path,
    depth: int,
    nodes: list[dict[str, JSONValue]],
) -> None:
    node_type = _tree_node_type(as_str(node.get("type")))
    if node_type is None:
        return
    nodes.append(
        {
            "path": current_path.as_posix(),
            "type": node_type,
            "depth": int(depth),
        }
    )
    contents = node.get("contents")
    if not isinstance(contents, list):
        return
    for child in contents:
        if not isinstance(child, dict):
            continue
        name = as_str(child.get("name"))
        if name is None:
            continue
        _collect_tree_nodes(
            child,
            current_path=current_path / name,
            depth=depth + 1,
            nodes=nodes,
        )


def _parse_tree_nodes(stdout_text: str) -> list[dict[str, JSONValue]] | None:
    parsed = parse_json_value(stdout_text)
    if not isinstance(parsed, list):
        return None
    nodes: list[dict[str, JSONValue]] = []
    for entry in parsed:
        if not isinstance(entry, dict):
            continue
        name = as_str(entry.get("name"))
        if name is None:
            continue
        _collect_tree_nodes(
            entry,
            current_path=Path(name),
            depth=0,
            nodes=nodes,
        )
    filtered = [node for node in nodes if node.get("depth") != 0]
    filtered.sort(key=lambda node: str(node.get("path") or ""))
    return filtered


def _stats_from_nodes(nodes: Sequence[Mapping[str, JSONValue]]) -> tuple[int, int]:
    dirs = 0
    files = 0
    for node in nodes:
        node_type = node.get("type")
        if node_type == "dir":
            dirs += 1
        elif node_type == "file":
            files += 1
    return int(dirs), int(files)


async def _tree_payload_from_args(
    *,
    args: TreeArgs,
    workspace_root: Path,
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    resolved, reason = await asyncio.to_thread(
        resolve_path_checked,
        workspace_root,
        args.path,
        expect="dir",
    )
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    if resolved is None:
        return None, error_output(
            "tree",
            kind=path_error_kind(reason),
            message="Invalid tree path.",
            details=reason_details(reason, field="path", requested_path=args.path),
        )
    _abs_path, rel_path = resolved
    cmd_json = _tree_command(args, rel_path=rel_path, json_output=True)
    exit_code, stdout_json, _stderr_text = await run_command(
        cmd_json,
        cwd=str(workspace_root),
        env=build_safe_env(),
        cancel_token=cancel_token,
    )
    if exit_code != 0:
        if exit_code == COMMAND_NOT_FOUND_EXIT_CODE:
            return None, error_output(
                "tree",
                kind=TOOL_ERROR_KIND,
                message="tree binary is not available.",
                details=reason_details("missing_binary"),
            )
        return None, error_output(
            "tree",
            kind=TOOL_ERROR_KIND,
            message="Failed to list path.",
            details=reason_details("command_failed", field="path"),
        )
    nodes = _parse_tree_nodes(stdout_json)
    if nodes is None:
        return None, error_output(
            "tree",
            kind=TOOL_ERROR_KIND,
            message="Failed to parse tree output.",
            details=reason_details("parse_failed"),
        )
    total = len(nodes)
    page_nodes = (
        nodes[args.offset : args.offset + args.limit] if args.offset < total else []
    )
    returned = len(page_nodes)
    page_has_more = args.offset + returned < total
    next_cursor = args.offset + returned if page_has_more else None
    page = build_page(
        kind="offset",
        cursor=args.offset,
        limit=args.limit,
        returned=returned,
        next_cursor=next_cursor,
        limit_reason="page_limit" if page_has_more else None,
    )
    total_dirs, total_files = _stats_from_nodes(nodes)
    returned_dirs, returned_files = _stats_from_nodes(page_nodes)
    nodes_json: list[JSONValue] = [dict(node) for node in page_nodes]
    payload: dict[str, JSONValue] = {
        "root": rel_path,
        "nodes": nodes_json,
        "stats": {
            "total_directories": total_dirs,
            "total_files": total_files,
            "returned_directories": returned_dirs,
            "returned_files": returned_files,
        },
        "page": page,
    }
    return payload, None


async def _invoke_tree(
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
    *,
    workspace_root: Path,
) -> str:
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    args, error = _parse_tree_args(raw)
    if error is not None:
        return error
    if args is None:
        return _tree_error("Invalid tree payload.")
    payload, error = await _tree_payload_from_args(
        args=args,
        workspace_root=workspace_root,
        cancel_token=cancel_token,
    )
    if error is not None:
        return error
    if payload is None:
        return _tree_error("Invalid tree payload.")
    return success_output("tree", payload)


def build_tree_tool(
    workspace_root: Path,
) -> FunctionTool:
    """Build the tree inspection operation engine."""
    validate_strict_schema("tree", _TREE_SCHEMA)

    return FunctionTool(
        name="tree",
        description=describe_tree(),
        params_json_schema=_TREE_SCHEMA,
        on_invoke_tool=partial(_invoke_tree, workspace_root=workspace_root),
        strict_json_schema=True,
    )


__all__ = ("build_tree_tool",)
