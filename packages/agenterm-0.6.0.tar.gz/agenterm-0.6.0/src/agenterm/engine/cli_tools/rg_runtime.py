"""rg execution and payload assembly."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from agenterm.constants.limits import RG_OUTPUT_MAX_ITEMS_MAX
from agenterm.engine.cli_tools.rg_context import add_context
from agenterm.engine.cli_tools.rg_exec import (
    build_rg_command,
    build_rg_count_command,
    rg_error_from_exit,
    run_rg_command,
    run_rg_count_command,
)
from agenterm.engine.cli_tools.rg_files import (
    normalize_rg_files,
    rg_files_command,
    run_rg_files_command,
)
from agenterm.engine.cli_tools.rg_payload import (
    coverage_payload,
    entries_from_normalized,
    files_searched,
    matched_paths,
    normalize_rg_counts,
    normalize_rg_matches,
    slice_page,
    sorted_entries,
)
from agenterm.engine.cli_tools.shared import (
    error_output,
    path_error_kind,
    reason_details,
    resolve_path_checked,
)

if TYPE_CHECKING:
    from collections.abc import Iterable, Mapping, Sequence
    from pathlib import Path

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.engine.cli_tools.rg_parse import RgArgs


def _json_entry(entry: Mapping[str, JSONValue]) -> JSONValue:
    return dict(entry)


def _raise_if_cancelled(cancel_token: CancelToken | None) -> None:
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()


async def _build_rg_count_payload(
    *,
    workspace_root: Path,
    args: RgArgs,
    glob_filters: Sequence[str],
    resolved_paths: Sequence[str],
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    cmd = build_rg_count_command(
        args,
        glob_filters=glob_filters,
        resolved_paths=resolved_paths,
    )
    # Count mode needs a correct count_total across the returned set, so we read up to
    # the tool's max-items cap rather than just offset+limit.
    max_files = RG_OUTPUT_MAX_ITEMS_MAX
    (
        counts,
        _truncated,
        terminated,
        exit_code,
        stderr_text,
    ) = await run_rg_count_command(
        cmd=cmd,
        workspace_root=str(workspace_root),
        max_files=max_files,
        cancel_token=cancel_token,
    )
    error = rg_error_from_exit(
        exit_code=exit_code,
        terminated=terminated,
        stderr_text=stderr_text,
    )
    if error is not None:
        return None, error
    _raise_if_cancelled(cancel_token)
    normalized = await asyncio.to_thread(
        normalize_rg_counts,
        counts,
        workspace_root=workspace_root,
    )
    _raise_if_cancelled(cancel_token)
    count_entries: list[dict[str, JSONValue]] = [
        {"path": path, "count": int(count)} for path, count in normalized
    ]
    count_total = sum(int(count) for _path, count in normalized)
    can_continue = False
    sliced, page = slice_page(
        count_entries,
        offset=args.offset,
        limit=args.limit,
        kind="offset",
        can_continue=can_continue,
    )
    counts_json = [_json_entry(entry) for entry in sliced]
    complete = not terminated
    reason = "result_cap" if terminated else None
    payload_count: dict[str, JSONValue] = {
        "counts": counts_json,
        "count_total": int(count_total),
        "page": page,
        "coverage": coverage_payload(
            mode="count",
            files_searched=None,
            files_matched=len(normalized),
            complete=complete,
            limit_reason=reason,
        ),
    }
    return payload_count, None


async def _build_rg_files_payload(
    *,
    workspace_root: Path,
    args: RgArgs,
    glob_filters: Sequence[str],
    resolved_paths: Sequence[str],
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    cmd = rg_files_command(
        args,
        glob_filters=glob_filters,
        resolved_paths=resolved_paths,
    )
    max_files = RG_OUTPUT_MAX_ITEMS_MAX
    (
        files,
        _truncated,
        terminated,
        exit_code,
        stderr_text,
    ) = await run_rg_files_command(
        cmd=cmd,
        workspace_root=workspace_root,
        max_files=max_files,
        cancel_token=cancel_token,
    )
    error = rg_error_from_exit(
        exit_code=exit_code,
        terminated=terminated,
        stderr_text=stderr_text,
    )
    if error is not None:
        return None, error
    _raise_if_cancelled(cancel_token)
    normalized = await asyncio.to_thread(
        normalize_rg_files,
        files,
        workspace_root=workspace_root,
    )
    _raise_if_cancelled(cancel_token)
    files_matched = sorted(set(normalized))
    file_entries: list[dict[str, JSONValue]] = [
        {"path": path} for path in files_matched
    ]
    can_continue = False
    sliced, page = slice_page(
        file_entries,
        offset=args.offset,
        limit=args.limit,
        kind="offset",
        can_continue=can_continue,
    )
    files_json: list[JSONValue] = []
    for entry in sliced:
        path_val = entry.get("path")
        if isinstance(path_val, str):
            files_json.append(path_val)
    complete = not terminated
    reason = "result_cap" if terminated else None
    payload_files: dict[str, JSONValue] = {
        "files": files_json,
        "page": page,
        "coverage": coverage_payload(
            mode="files",
            files_searched=None,
            files_matched=len(files_matched),
            complete=complete,
            limit_reason=reason,
        ),
    }
    return payload_files, None


async def _build_rg_matches_payload(
    *,
    workspace_root: Path,
    args: RgArgs,
    glob_filters: Sequence[str],
    resolved_paths: Sequence[str],
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    cmd = build_rg_command(
        args,
        glob_filters=glob_filters,
        resolved_paths=resolved_paths,
    )
    max_matches = min(RG_OUTPUT_MAX_ITEMS_MAX, args.offset + args.limit)
    (
        matches,
        stats,
        _truncated,
        terminated,
        exit_code,
        stderr_text,
    ) = await run_rg_command(
        cmd=cmd,
        workspace_root=str(workspace_root),
        max_matches=max_matches,
        max_line_chars=args.max_line_chars,
        cancel_token=cancel_token,
    )
    error = rg_error_from_exit(
        exit_code=exit_code,
        terminated=terminated,
        stderr_text=stderr_text,
    )
    if error is not None:
        return None, error
    _raise_if_cancelled(cancel_token)
    normalized = await asyncio.to_thread(
        normalize_rg_matches,
        matches,
        workspace_root=workspace_root,
    )
    _raise_if_cancelled(cancel_token)
    await asyncio.to_thread(
        add_context,
        normalized,
        before=args.before,
        after=args.after,
        max_line_chars=args.max_line_chars,
    )
    _raise_if_cancelled(cancel_token)
    entries = sorted_entries(entries_from_normalized(normalized))
    files_matched_list = matched_paths(entries)
    complete = stats is not None and not terminated
    stats_map = stats if complete else None
    files_searched_val = files_searched(stats_map)
    files_matched = len(files_matched_list)
    if stats_map is not None:
        matched_val = stats_map.get("searches_with_match")
        if isinstance(matched_val, int):
            files_matched = int(matched_val)
    stats_reason: str | None = None
    if not complete:
        if terminated and max_matches >= RG_OUTPUT_MAX_ITEMS_MAX:
            stats_reason = "result_cap"
        elif terminated:
            stats_reason = "page_limit"
        else:
            stats_reason = "stats_unavailable"
    can_continue = (
        terminated
        and max_matches == args.offset + args.limit
        and max_matches < RG_OUTPUT_MAX_ITEMS_MAX
    )
    sliced, page = slice_page(
        entries,
        offset=args.offset,
        limit=args.limit,
        kind="offset",
        can_continue=can_continue,
    )
    matches_json = [_json_entry(entry) for entry in sliced]
    payload: dict[str, JSONValue] = {
        "matches": matches_json,
        "page": page,
        "coverage": coverage_payload(
            mode="matches",
            files_searched=files_searched_val,
            files_matched=files_matched,
            complete=complete,
            limit_reason=stats_reason,
        ),
    }
    return payload, None


async def _build_rg_summary_payload(
    *,
    workspace_root: Path,
    args: RgArgs,
    glob_filters: Sequence[str],
    resolved_paths: Sequence[str],
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    """Return a bounded total match count without per-path rows.

    We implement summary by reusing count-mode collection, which scales by
    files-with-matches rather than by individual matches.
    """
    cmd = build_rg_count_command(
        args,
        glob_filters=glob_filters,
        resolved_paths=resolved_paths,
    )
    max_files = RG_OUTPUT_MAX_ITEMS_MAX
    (
        counts,
        _truncated,
        terminated,
        exit_code,
        stderr_text,
    ) = await run_rg_count_command(
        cmd=cmd,
        workspace_root=str(workspace_root),
        max_files=max_files,
        cancel_token=cancel_token,
    )
    error = rg_error_from_exit(
        exit_code=exit_code,
        terminated=terminated,
        stderr_text=stderr_text,
    )
    if error is not None:
        return None, error
    _raise_if_cancelled(cancel_token)
    normalized = await asyncio.to_thread(
        normalize_rg_counts,
        counts,
        workspace_root=workspace_root,
    )
    _raise_if_cancelled(cancel_token)
    count_total = sum(int(count) for _path, count in normalized)
    complete = not terminated
    reason = "result_cap" if terminated else None
    payload: dict[str, JSONValue] = {
        "count_total": int(count_total),
        "page": {
            "kind": "offset",
            "cursor": int(args.offset),
            "limit": int(args.limit),
            "returned": 0,
            "has_more": False,
            "next_cursor": None,
        },
        "coverage": coverage_payload(
            mode="summary",
            files_searched=None,
            files_matched=len(normalized),
            complete=complete,
            limit_reason=reason,
        ),
    }
    return payload, None


async def build_rg_payload(
    *,
    workspace_root: Path,
    args: RgArgs,
    glob_filters: Sequence[str],
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    """Run rg and assemble the bounded payload."""
    resolved_paths, reason = await asyncio.to_thread(
        _resolve_paths, workspace_root, args.paths
    )
    _raise_if_cancelled(cancel_token)
    if reason is not None or resolved_paths is None:
        return None, error_output(
            "rg",
            kind=path_error_kind(reason),
            message="Invalid rg path.",
            details=reason_details(reason, field="paths"),
        )
    result: dict[str, JSONValue] | None = None
    error: str | None = None
    if args.result_mode == "summary":
        result, error = await _build_rg_summary_payload(
            workspace_root=workspace_root,
            args=args,
            glob_filters=glob_filters,
            resolved_paths=resolved_paths,
            cancel_token=cancel_token,
        )
    elif args.result_mode == "count":
        result, error = await _build_rg_count_payload(
            workspace_root=workspace_root,
            args=args,
            glob_filters=glob_filters,
            resolved_paths=resolved_paths,
            cancel_token=cancel_token,
        )
    elif args.result_mode == "files":
        result, error = await _build_rg_files_payload(
            workspace_root=workspace_root,
            args=args,
            glob_filters=glob_filters,
            resolved_paths=resolved_paths,
            cancel_token=cancel_token,
        )
    else:
        result, error = await _build_rg_matches_payload(
            workspace_root=workspace_root,
            args=args,
            glob_filters=glob_filters,
            resolved_paths=resolved_paths,
            cancel_token=cancel_token,
        )
    if error is not None:
        return None, error
    if result is None:
        return None, None
    if args.pattern_mode == "auto":
        result["effective_pattern_mode"] = args.effective_pattern_mode
    return result, None


def _resolve_paths(
    workspace_root: Path,
    paths: Iterable[str],
) -> tuple[list[str] | None, str | None]:
    resolved: list[str] = []
    for raw in paths:
        resolved_pair, reason = resolve_path_checked(workspace_root, raw, expect="any")
        if resolved_pair is None:
            return None, reason or "invalid_path"
        _abs_path, rel = resolved_pair
        resolved.append(rel)
    return resolved, None


__all__ = ("build_rg_payload",)
