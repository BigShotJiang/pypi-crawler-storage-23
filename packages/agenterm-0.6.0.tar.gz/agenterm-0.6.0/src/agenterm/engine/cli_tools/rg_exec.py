"""rg execution helpers."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from agenterm.core.errors import ToolExecutionError
from agenterm.engine.cli_tools.rg_events import parse_rg_line
from agenterm.engine.cli_tools.shared import (
    COMMAND_NOT_FOUND_EXIT_CODE,
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    build_safe_env,
    error_output,
    reason_details,
)
from agenterm.engine.subprocess_runner import (
    read_line_or_cancel,
    spawn_subprocess,
    terminate_process,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agenterm.core.cancellation import CancelToken
    from agenterm.engine.cli_tools.rg_events import RgRawMatch
    from agenterm.engine.cli_tools.rg_parse import RgArgs

_RG_DIAGNOSTIC_MAX_CHARS = 280


def build_rg_command(
    args: RgArgs,
    *,
    glob_filters: Sequence[str],
    resolved_paths: Sequence[str],
) -> list[str]:
    """Build the rg JSON output command."""
    cmd: list[str] = ["rg", "--json", "--sort=path"]
    if args.include_hidden:
        cmd.append("--hidden")
    if not args.gitignore:
        cmd.append("--no-ignore")
    if args.effective_pattern_mode == "literal":
        cmd.append("-F")
    if args.case_mode == "sensitive":
        cmd.append("--case-sensitive")
    elif args.case_mode == "smart":
        cmd.append("--smart-case")
    else:
        cmd.append("--ignore-case")
    for glob_filter in glob_filters:
        cmd.extend(["-g", glob_filter])
    cmd.append(args.pattern)
    cmd.extend(resolved_paths)
    return cmd


def build_rg_count_command(
    args: RgArgs,
    *,
    glob_filters: Sequence[str],
    resolved_paths: Sequence[str],
) -> list[str]:
    """Build the rg count output command."""
    cmd: list[str] = ["rg", "--count-matches", "-H", "--sort=path"]
    if args.include_hidden:
        cmd.append("--hidden")
    if not args.gitignore:
        cmd.append("--no-ignore")
    if args.effective_pattern_mode == "literal":
        cmd.append("-F")
    if args.case_mode == "sensitive":
        cmd.append("--case-sensitive")
    elif args.case_mode == "smart":
        cmd.append("--smart-case")
    else:
        cmd.append("--ignore-case")
    for glob_filter in glob_filters:
        cmd.extend(["-g", glob_filter])
    cmd.append(args.pattern)
    cmd.extend(resolved_paths)
    return cmd


def _parse_rg_count_line(line_text: str) -> tuple[str, int] | None:
    path_text, sep, count_text = line_text.rpartition(":")
    if sep == "" or not path_text:
        return None
    count_text = count_text.strip()
    if not count_text.isdigit():
        return None
    return path_text, int(count_text)


def _append_matches(
    matches: list[RgRawMatch],
    new_matches: Sequence[RgRawMatch],
    *,
    max_matches: int,
) -> tuple[bool, bool]:
    truncated = False
    reached = False
    for match in new_matches:
        matches.append(match)
        if len(matches) >= max_matches:
            truncated = True
            reached = True
            break
    return truncated, reached


async def _read_rg_stream(
    proc: asyncio.subprocess.Process,
    *,
    max_matches: int,
    max_line_chars: int,
    cancel_token: CancelToken | None,
) -> tuple[list[RgRawMatch], dict[str, int] | None, bool, bool]:
    matches: list[RgRawMatch] = []
    stats: dict[str, int] | None = None
    truncated = False
    terminated = False
    stdout = proc.stdout
    if stdout is None:
        return matches, stats, truncated, terminated
    while True:
        raw_line = await read_line_or_cancel(
            stdout,
            process=proc,
            cancel_token=cancel_token,
        )
        if not raw_line:
            break
        if len(matches) >= max_matches:
            truncated = True
            terminated = True
            terminate_process(proc)
            break
        new_matches, stats_update = parse_rg_line(
            raw_line,
            max_line_chars=max_line_chars,
        )
        if stats_update is not None:
            stats = stats_update
        if new_matches:
            hit_trunc, reached = _append_matches(
                matches,
                new_matches,
                max_matches=max_matches,
            )
            truncated = truncated or hit_trunc
            if reached:
                terminated = True
                terminate_process(proc)
                break
    return matches, stats, truncated, terminated


async def _read_rg_count_stream(
    proc: asyncio.subprocess.Process,
    *,
    max_files: int,
    cancel_token: CancelToken | None,
) -> tuple[list[tuple[str, int]], bool, bool]:
    counts: list[tuple[str, int]] = []
    truncated = False
    terminated = False
    stdout = proc.stdout
    if stdout is None:
        return counts, truncated, terminated
    while True:
        raw_line = await read_line_or_cancel(
            stdout,
            process=proc,
            cancel_token=cancel_token,
        )
        if not raw_line:
            break
        if len(counts) >= max_files:
            truncated = True
            terminated = True
            terminate_process(proc)
            break
        line_text = raw_line.decode("utf-8", "replace").strip()
        if not line_text:
            continue
        parsed = _parse_rg_count_line(line_text)
        if parsed is None:
            continue
        counts.append(parsed)
    return counts, truncated, terminated


async def run_rg_command(
    *,
    cmd: Sequence[str],
    workspace_root: str,
    max_matches: int,
    max_line_chars: int,
    cancel_token: CancelToken | None,
) -> tuple[list[RgRawMatch], dict[str, int] | None, bool, bool, int, str]:
    """Run rg JSON command and collect matches."""
    try:
        proc = await spawn_subprocess(
            cmd,
            cwd=workspace_root,
            env=build_safe_env(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cancel_token=cancel_token,
        )
    except ToolExecutionError as exc:
        # Missing binaries (e.g., rg not installed) are expected runtime failures and
        # must be reported as a tool_error envelope by the caller, not raised.
        return [], None, False, False, COMMAND_NOT_FOUND_EXIT_CODE, str(exc)
    matches, stats, truncated, terminated = await _read_rg_stream(
        proc,
        max_matches=max_matches,
        max_line_chars=max_line_chars,
        cancel_token=cancel_token,
    )
    _stdout_tail, stderr_tail = await proc.communicate()
    stderr_text = stderr_tail.decode("utf-8", "replace") if stderr_tail else ""
    exit_code = int(proc.returncode or 0)
    return matches, stats, truncated, terminated, exit_code, stderr_text


async def run_rg_count_command(
    *,
    cmd: Sequence[str],
    workspace_root: str,
    max_files: int,
    cancel_token: CancelToken | None,
) -> tuple[list[tuple[str, int]], bool, bool, int, str]:
    """Run rg count command and collect counts."""
    try:
        proc = await spawn_subprocess(
            cmd,
            cwd=workspace_root,
            env=build_safe_env(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cancel_token=cancel_token,
        )
    except ToolExecutionError as exc:
        return [], False, False, COMMAND_NOT_FOUND_EXIT_CODE, str(exc)
    counts, truncated, terminated = await _read_rg_count_stream(
        proc,
        max_files=max_files,
        cancel_token=cancel_token,
    )
    _stdout_tail, stderr_tail = await proc.communicate()
    stderr_text = stderr_tail.decode("utf-8", "replace") if stderr_tail else ""
    exit_code = int(proc.returncode or 0)
    return counts, truncated, terminated, exit_code, stderr_text


def rg_error_from_exit(
    *,
    exit_code: int,
    terminated: bool,
    stderr_text: str,
) -> str | None:
    """Map rg exit codes to tool errors."""
    if exit_code in {0, 1} or terminated:
        return None
    if exit_code == COMMAND_NOT_FOUND_EXIT_CODE:
        return error_output(
            "rg",
            kind=TOOL_ERROR_KIND,
            message="rg binary is not available.",
            details=reason_details("missing_binary"),
        )
    if _is_invalid_pattern_error(stderr_text):
        details = reason_details("invalid_pattern", field="pattern") or {}
        diagnostic = _invalid_pattern_diagnostic(stderr_text)
        if diagnostic is not None:
            details["diagnostic"] = diagnostic
        return error_output(
            "rg",
            kind=INVALID_INPUT_KIND,
            message="Invalid rg pattern.",
            details=details,
        )
    return error_output(
        "rg",
        kind=TOOL_ERROR_KIND,
        message="Failed to search.",
        details=reason_details("command_failed"),
    )


def _is_invalid_pattern_error(stderr_text: str) -> bool:
    lowered = stderr_text.lower()
    return (
        "regex parse error" in lowered
        or "error parsing regex" in lowered
        or "invalid regex" in lowered
        or "glob parse error" in lowered
        or "invalid glob" in lowered
    )


def _invalid_pattern_diagnostic(stderr_text: str) -> str | None:
    text = stderr_text.strip()
    if not text:
        return None
    lines = [line.rstrip() for line in text.splitlines() if line.strip()]
    if not lines:
        return None
    diagnostic = "\n".join(lines[:4])
    if len(diagnostic) <= _RG_DIAGNOSTIC_MAX_CHARS:
        return diagnostic
    return diagnostic[: _RG_DIAGNOSTIC_MAX_CHARS - 3] + "..."


__all__ = (
    "build_rg_command",
    "build_rg_count_command",
    "rg_error_from_exit",
    "run_rg_command",
    "run_rg_count_command",
)
