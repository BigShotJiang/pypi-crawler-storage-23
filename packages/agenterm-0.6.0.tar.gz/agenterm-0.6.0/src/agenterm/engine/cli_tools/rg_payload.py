"""rg payload normalization helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.engine.cli_tools.shared import build_page, resolve_path

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence
    from pathlib import Path

    from agenterm.core.json_types import JSONValue
    from agenterm.engine.cli_tools.rg_events import RgRawMatch


def normalize_rg_matches(
    matches: Sequence[RgRawMatch],
    *,
    workspace_root: Path,
) -> list[tuple[Path, dict[str, JSONValue]]]:
    """Normalize rg match records into workspace-relative entries."""
    normalized: list[tuple[Path, dict[str, JSONValue]]] = []
    for match in matches:
        resolved = resolve_path(workspace_root, match.path_text)
        if resolved is None:
            continue
        abs_path, rel = resolved
        entry: dict[str, JSONValue] = {
            "path": rel,
            "line": match.line,
            "column": match.column,
            "text": match.text,
            "text_truncated": bool(match.text_truncated),
        }
        normalized.append((abs_path, entry))
    return normalized


def normalize_rg_counts(
    counts: Sequence[tuple[str, int]],
    *,
    workspace_root: Path,
) -> list[tuple[str, int]]:
    """Normalize rg count tuples into workspace-relative paths."""
    normalized: list[tuple[str, int]] = []
    for path_text, count in counts:
        resolved = resolve_path(workspace_root, path_text)
        if resolved is None:
            continue
        _abs_path, rel = resolved
        normalized.append((rel, int(count)))
    return sorted(normalized, key=lambda item: item[0])


def entries_from_normalized(
    normalized: Sequence[tuple[Path, Mapping[str, JSONValue]]],
) -> list[dict[str, JSONValue]]:
    """Extract JSON-ready match entries from normalized tuples."""
    return [dict(entry) for _abs, entry in normalized]


def matched_paths(entries: Sequence[Mapping[str, JSONValue]]) -> list[str]:
    """Return a sorted list of unique paths from match entries."""
    paths: list[str] = []
    for entry in entries:
        path_val = entry.get("path")
        if isinstance(path_val, str):
            paths.append(path_val)
    return sorted(set(paths))


def sorted_entries(
    entries: Sequence[Mapping[str, JSONValue]],
) -> list[dict[str, JSONValue]]:
    """Sort entries by path, line, and column for stable paging."""

    def _entry_key(entry: Mapping[str, JSONValue]) -> tuple[str, int, int]:
        path = entry.get("path")
        line = entry.get("line")
        column = entry.get("column")
        return (
            path if isinstance(path, str) else "",
            int(line) if isinstance(line, int) else 0,
            int(column) if isinstance(column, int) else 0,
        )

    return sorted((dict(entry) for entry in entries), key=_entry_key)


def files_searched(stats: Mapping[str, int] | None) -> int | None:
    """Return files_searched from rg stats when available."""
    if not stats:
        return None
    val = stats.get("searches")
    return int(val) if isinstance(val, int) else None


def coverage_payload(
    *,
    mode: str,
    files_searched: int | None,
    files_matched: int,
    complete: bool,
    limit_reason: str | None,
) -> dict[str, JSONValue]:
    """Build a coverage payload for rg results."""
    searched_available = files_searched is not None
    return {
        "mode": mode,
        "files_searched": files_searched,
        "files_searched_available": searched_available,
        "files_matched": int(files_matched),
        "scan_complete": bool(complete),
        "limit_reason": limit_reason,
    }


def slice_page(
    entries: Sequence[Mapping[str, JSONValue]],
    *,
    offset: int,
    limit: int,
    kind: str,
    can_continue: bool,
) -> tuple[list[dict[str, JSONValue]], dict[str, JSONValue]]:
    """Slice entries and build a page cursor payload."""
    total = len(entries)
    sliced = (
        [dict(item) for item in entries[offset : offset + limit]]
        if offset < total
        else []
    )
    returned = len(sliced)
    page_has_more = offset + returned < total
    continuation_has_more = can_continue and returned > 0
    next_cursor: int | None = None
    if page_has_more or continuation_has_more:
        next_cursor = offset + returned
    page = build_page(
        kind=kind,
        cursor=offset,
        limit=limit,
        returned=returned,
        next_cursor=next_cursor,
        limit_reason="page_limit" if next_cursor is not None else None,
    )
    return sliced, page


__all__ = (
    "coverage_payload",
    "entries_from_normalized",
    "files_searched",
    "matched_paths",
    "normalize_rg_counts",
    "normalize_rg_matches",
    "slice_page",
    "sorted_entries",
)
