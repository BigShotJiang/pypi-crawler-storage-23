"""rg local CLI tool implementation."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.engine.cli_tools.rg_parse import RG_SCHEMA, parse_rg_args
from agenterm.engine.cli_tools.rg_runtime import build_rg_payload
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    error_output,
    success_output,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_rg

if TYPE_CHECKING:
    from pathlib import Path

    from agents.tool_context import ToolContext

    from agenterm.core.plan import ToolRuntimeContext


def build_rg_tool(
    workspace_root: Path,
) -> FunctionTool:
    """Build the rg inspection operation engine."""
    validate_strict_schema("rg", RG_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        args_pair, error = parse_rg_args(raw)
        if error is not None:
            return error
        if args_pair is None:
            return error_output(
                "rg",
                kind=INVALID_INPUT_KIND,
                message="Invalid rg payload.",
            )
        args, glob_filters = args_pair
        result, error_out = await build_rg_payload(
            workspace_root=workspace_root,
            args=args,
            glob_filters=glob_filters,
            cancel_token=cancel_token,
        )
        if error_out is not None:
            return error_out
        if result is None:
            return error_output(
                "rg",
                kind=TOOL_ERROR_KIND,
                message="Failed to search.",
            )
        return success_output("rg", result)

    return FunctionTool(
        name="rg",
        description=describe_rg(),
        params_json_schema=RG_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_rg_tool",)
