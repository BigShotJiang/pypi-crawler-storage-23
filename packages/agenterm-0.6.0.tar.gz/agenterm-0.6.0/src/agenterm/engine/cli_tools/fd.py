"""fd local CLI tool implementation."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.constants.limits import FD_OUTPUT_MAX_ITEMS_MAX
from agenterm.engine.cli_tools.fd_parse import FD_SCHEMA, FdArgs, parse_fd_args
from agenterm.engine.cli_tools.shared import (
    COMMAND_NOT_FOUND_EXIT_CODE,
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    build_page,
    build_safe_env,
    error_output,
    path_error_kind,
    reason_details,
    resolve_path,
    resolve_path_checked,
    run_command,
    success_output,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_fd

if TYPE_CHECKING:
    from collections.abc import Iterable
    from pathlib import Path

    from agents.tool_context import ToolContext

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext


def _resolve_paths(
    workspace_root: Path, paths: Iterable[str]
) -> tuple[list[str] | None, str | None]:
    resolved: list[str] = []
    for raw in paths:
        resolved_pair, reason = resolve_path_checked(workspace_root, raw, expect="any")
        if resolved_pair is None:
            return None, reason or "invalid_path"
        _abs_path, rel = resolved_pair
        resolved.append(rel)
    return resolved, None


def _append_traversal_flags(cmd: list[str], args: FdArgs) -> None:
    if args.include_hidden:
        cmd.append("--hidden")
    if not args.gitignore:
        cmd.append("--no-ignore")


def _append_pattern_flags(cmd: list[str], args: FdArgs) -> None:
    if args.max_depth is not None:
        cmd.extend(["--max-depth", str(args.max_depth)])
    if args.pattern is None:
        return
    if args.effective_pattern_mode == "glob":
        cmd.append("--glob")
    elif args.effective_pattern_mode == "fixed":
        cmd.append("--fixed-strings")


def _append_filter_flags(cmd: list[str], args: FdArgs) -> None:
    if args.type_filter != "any":
        cmd.extend(["--type", args.type_filter])
    for exclude in args.exclude:
        cmd.extend(["--exclude", exclude])


def _append_search_paths(cmd: list[str], resolved_paths: list[str]) -> None:
    for path in resolved_paths:
        cmd.extend(["--search-path", path])


def _fd_command(
    args: FdArgs,
    *,
    resolved_paths: list[str],
    max_results: int,
) -> list[str]:
    cmd: list[str] = ["fd", "--color=never", "--max-results", str(max_results)]
    _append_traversal_flags(cmd, args)
    _append_pattern_flags(cmd, args)
    _append_filter_flags(cmd, args)
    _append_search_paths(cmd, resolved_paths)
    if args.pattern is not None:
        cmd.append(args.pattern)
    return cmd


def _parse_fd_output(
    stdout_text: str,
    *,
    workspace_root: Path,
) -> list[str]:
    matches: list[str] = []
    for line in stdout_text.splitlines():
        candidate = line.strip()
        if not candidate:
            continue
        resolved = resolve_path(workspace_root, candidate)
        if resolved is None:
            continue
        _abs_path, rel = resolved
        matches.append(rel)
    return matches


def _stable_matches(matches: list[str]) -> list[str]:
    return sorted(set(matches))


def _raise_if_cancelled(cancel_token: CancelToken | None) -> None:
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()


def _is_invalid_pattern_error(
    *,
    args: FdArgs,
    stderr_text: str,
) -> bool:
    if args.pattern is None:
        return False
    lowered = stderr_text.lower()
    return (
        "regex parse error" in lowered
        or "error parsing regex" in lowered
        or "invalid regex" in lowered
        or "invalid pattern" in lowered
        or ("glob" in lowered and "syntax error" in lowered)
    )


def _error_from_exit_code(
    *, args: FdArgs, exit_code: int, stderr_text: str
) -> str | None:
    if exit_code == 0:
        return None
    if exit_code == COMMAND_NOT_FOUND_EXIT_CODE:
        return error_output(
            "fd",
            kind=TOOL_ERROR_KIND,
            message="fd binary is not available.",
            details=reason_details("missing_binary"),
        )
    if _is_invalid_pattern_error(args=args, stderr_text=stderr_text):
        return error_output(
            "fd",
            kind=INVALID_INPUT_KIND,
            message="Invalid fd pattern.",
            details=reason_details("invalid_pattern", field="pattern"),
        )
    return error_output(
        "fd",
        kind=TOOL_ERROR_KIND,
        message="Failed to list files.",
        details=reason_details("command_failed"),
    )


def _fd_payload(
    args: FdArgs, stable: list[str], *, scan_truncated: bool
) -> dict[str, JSONValue]:
    total = len(stable)
    sliced = (
        list(stable[args.offset : args.offset + args.limit])
        if args.offset < total
        else []
    )
    returned = len(sliced)
    page_has_more = args.offset + returned < total
    next_cursor = args.offset + returned if page_has_more else None
    page = build_page(
        kind="offset",
        cursor=args.offset,
        limit=args.limit,
        returned=returned,
        next_cursor=next_cursor,
        limit_reason=(
            "tool_cap" if scan_truncated else ("page_limit" if page_has_more else None)
        ),
    )
    payload: dict[str, JSONValue] = {
        "matches": list(sliced),
        "page": page,
        "coverage": {
            "scan_complete": not scan_truncated,
            "page_complete": not page_has_more,
            "limit_reason": "result_cap" if scan_truncated else None,
        },
    }
    if args.pattern_mode == "auto":
        payload["effective_pattern_mode"] = args.effective_pattern_mode
    return payload


def build_fd_tool(
    workspace_root: Path,
) -> FunctionTool:
    """Build the fd inspection operation engine."""
    validate_strict_schema("fd", FD_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        _raise_if_cancelled(cancel_token)
        args, error = parse_fd_args(raw)
        if error is not None or args is None:
            return error or error_output(
                "fd",
                kind=INVALID_INPUT_KIND,
                message="Invalid fd payload.",
            )

        resolved_paths, reason = await asyncio.to_thread(
            _resolve_paths, workspace_root, args.paths
        )
        _raise_if_cancelled(cancel_token)
        if reason is not None or resolved_paths is None:
            return error_output(
                "fd",
                kind=path_error_kind(reason),
                message="Invalid fd path.",
                details=reason_details(reason, field="paths"),
            )

        # fd output ordering can vary by filesystem traversal order.
        # Build pages from a fixed-size scan so pagination is deterministic.
        scan_limit = FD_OUTPUT_MAX_ITEMS_MAX
        scan_max_results = scan_limit + 1
        cmd = _fd_command(
            args,
            resolved_paths=resolved_paths,
            max_results=scan_max_results,
        )
        exit_code, stdout_text, stderr_text = await run_command(
            cmd,
            cwd=str(workspace_root),
            env=build_safe_env(),
            cancel_token=cancel_token,
        )
        error_output_from_exit = _error_from_exit_code(
            args=args,
            exit_code=exit_code,
            stderr_text=stderr_text,
        )
        if error_output_from_exit is not None:
            return error_output_from_exit

        matches = await asyncio.to_thread(
            _parse_fd_output, stdout_text, workspace_root=workspace_root
        )
        _raise_if_cancelled(cancel_token)
        scan_truncated = len(matches) >= scan_max_results
        if scan_truncated and len(matches) > scan_limit:
            matches = matches[:scan_limit]
        stable = _stable_matches(matches)
        return success_output(
            "fd", _fd_payload(args, stable, scan_truncated=scan_truncated)
        )

    return FunctionTool(
        name="fd",
        description=describe_fd(),
        params_json_schema=FD_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_fd_tool",)
