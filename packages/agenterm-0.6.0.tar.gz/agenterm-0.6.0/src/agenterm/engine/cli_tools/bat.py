"""bat local CLI tool implementation."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from functools import partial
from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.constants.limits import (
    BAT_MAX_LINES_DEFAULT,
    BAT_MAX_LINES_MAX,
    BAT_MAX_LINES_MIN,
    BAT_OUTPUT_MAX_CHARS_DEFAULT,
    BAT_OUTPUT_MAX_CHARS_MAX,
    BAT_OUTPUT_MAX_CHARS_MIN,
    BAT_START_LINE_MAX,
    BAT_START_LINE_MIN,
)
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    build_page,
    build_safe_env,
    count_text_lines_checked,
    error_output,
    parse_bounded_int,
    path_error_kind,
    reason_details,
    resolve_path_checked,
    run_command,
    success_output,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_bat

if TYPE_CHECKING:
    from pathlib import Path

    from agents.tool_context import ToolContext

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_BAT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "bat file preview parameters.",
    "properties": {
        "path": {
            "type": "string",
            "description": "Workspace-relative file path (text).",
        },
        "start_line": {
            "anyOf": [
                {
                    "type": "integer",
                    "minimum": BAT_START_LINE_MIN,
                    "maximum": BAT_START_LINE_MAX,
                },
                {"type": "string", "enum": ["end"]},
            ],
            "description": '1-based start line, or "end" for tail.',
            "default": BAT_START_LINE_MIN,
        },
        "limit_lines": {
            "type": "integer",
            "minimum": 1,
            "description": "Max lines to return.",
            "default": BAT_MAX_LINES_DEFAULT,
        },
        "max_chars": {
            "type": "integer",
            "minimum": 1,
            "description": "Max characters across lines.",
            "default": BAT_OUTPUT_MAX_CHARS_DEFAULT,
        },
    },
    "required": ["path", "start_line", "limit_lines", "max_chars"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class BatArgs:
    """Parsed bat arguments."""

    path: str
    start_line: int | None
    limit_lines: int
    max_chars: int


def _bat_error(message: str) -> str:
    return error_output("bat", kind=INVALID_INPUT_KIND, message=message)


def _raise_if_cancelled(cancel_token: CancelToken | None) -> None:
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()


def _resolve_bat_start_line(
    args: BatArgs,
    *,
    total_lines: int,
) -> tuple[int, str | None]:
    if total_lines == 0:
        if args.start_line not in {None, BAT_START_LINE_MIN}:
            return BAT_START_LINE_MIN, "out_of_range"
        return BAT_START_LINE_MIN, None
    if args.start_line is None:
        return max(BAT_START_LINE_MIN, total_lines - args.limit_lines + 1), None
    if args.start_line > total_lines:
        return args.start_line, "out_of_range"
    return args.start_line, None


def _bat_empty_payload(
    rel_path: str,
    *,
    args: BatArgs,
    total_lines: int,
) -> dict[str, JSONValue]:
    lines_json: list[JSONValue] = []
    page = build_page(
        kind="line",
        cursor=BAT_START_LINE_MIN,
        limit=args.limit_lines,
        returned=0,
        next_cursor=None,
    )
    payload: dict[str, JSONValue] = {
        "path": rel_path,
        "lines": lines_json,
        "total_lines": int(total_lines),
        "page": page,
    }
    return payload


def _parse_bat_args(raw: str) -> tuple[BatArgs | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None or set(payload) - {
        "path",
        "start_line",
        "limit_lines",
        "max_chars",
    }:
        return None, _bat_error("Invalid bat payload.")
    path = as_str(payload.get("path"))
    if path is None or path == "":
        return None, _bat_error("bat requires a path.")
    start_line_raw = payload.get("start_line")
    start_line: int | None
    start_line_str = as_str(start_line_raw) if start_line_raw is not None else None
    if start_line_str is not None:
        if start_line_str != "end":
            return None, _bat_error("Invalid bat start_line.")
        start_line = None
    else:
        start_line_int = parse_bounded_int(
            start_line_raw,
            default=BAT_START_LINE_MIN,
            min_value=BAT_START_LINE_MIN,
            max_value=BAT_START_LINE_MAX,
        )
        if start_line_int is None:
            return None, _bat_error("Invalid bat start_line.")
        start_line = start_line_int
    limit_lines = parse_bounded_int(
        payload.get("limit_lines"),
        default=BAT_MAX_LINES_DEFAULT,
        min_value=BAT_MAX_LINES_MIN,
        max_value=BAT_MAX_LINES_MAX,
    )
    max_chars = parse_bounded_int(
        payload.get("max_chars"),
        default=BAT_OUTPUT_MAX_CHARS_DEFAULT,
        min_value=BAT_OUTPUT_MAX_CHARS_MIN,
        max_value=BAT_OUTPUT_MAX_CHARS_MAX,
    )
    if limit_lines is None or max_chars is None:
        return None, _bat_error("Invalid bat bounds.")
    return (
        BatArgs(
            path=path,
            start_line=start_line,
            limit_lines=limit_lines,
            max_chars=max_chars,
        ),
        None,
    )


def _bat_command(
    args: BatArgs,
    *,
    rel_path: str,
    start_line: int,
) -> list[str]:
    end_line = start_line + args.limit_lines
    return [
        "bat",
        "--color=never",
        "--decorations=always",
        "--paging=never",
        "--wrap=never",
        "--style=numbers",
        "--line-range",
        f"{start_line}:{end_line}",
        rel_path,
    ]


def _parse_bat_output(
    stdout_text: str,
    *,
    args: BatArgs,
    rel_path: str,
    start_line: int,
) -> dict[str, JSONValue]:
    lines_out: list[dict[str, JSONValue]] = []
    chars_used = 0
    has_more = False
    next_line: int | None = None
    truncated_by_chars = False
    for raw_line in stdout_text.splitlines():
        stripped = raw_line.lstrip()
        if not stripped:
            continue
        num_str, sep, rest = stripped.partition(" ")
        if sep == "" or not num_str.isdigit():
            continue
        line_no = int(num_str)
        if len(lines_out) >= args.limit_lines:
            has_more = True
            next_line = line_no
            break

        sep_chars = 1 if lines_out else 0
        remaining_chars = args.max_chars - chars_used - sep_chars
        if remaining_chars <= 0:
            has_more = True
            next_line = line_no
            truncated_by_chars = True
            break

        text_out = rest
        text_truncated = False
        if len(text_out) > remaining_chars:
            text_out = text_out[:remaining_chars]
            text_truncated = True

        chars_used += sep_chars + len(text_out)
        lines_out.append(
            {"line": line_no, "text": text_out, "text_truncated": text_truncated}
        )
        if text_truncated:
            has_more = True
            next_line = line_no
            truncated_by_chars = True
            break
    lines_json: list[JSONValue] = list(lines_out)
    page = build_page(
        kind="line",
        cursor=start_line,
        limit=args.limit_lines,
        returned=len(lines_out),
        next_cursor=next_line if has_more else None,
        limit_reason=(
            "max_chars" if truncated_by_chars else ("page_limit" if has_more else None)
        ),
    )
    payload: dict[str, JSONValue] = {
        "path": rel_path,
        "lines": lines_json,
        "page": page,
    }
    return payload


async def _bat_payload_from_args(
    *,
    args: BatArgs,
    workspace_root: Path,
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    resolved, reason = await asyncio.to_thread(
        resolve_path_checked,
        workspace_root,
        args.path,
        expect="file",
    )
    _raise_if_cancelled(cancel_token)

    payload_out: dict[str, JSONValue] | None = None
    error: str | None = None

    if resolved is None:
        error = error_output(
            "bat",
            kind=path_error_kind(reason),
            message="Invalid bat path.",
            details=reason_details(reason, field="path", requested_path=args.path),
        )
    else:
        abs_path, rel_path = resolved
        total_lines, kind = await asyncio.to_thread(count_text_lines_checked, abs_path)
        _raise_if_cancelled(cancel_token)

        if kind == "binary":
            error = error_output(
                "bat",
                kind=INVALID_INPUT_KIND,
                message="bat does not support binary files.",
                details=reason_details("binary_file", field="path"),
            )
        elif total_lines is None:
            error = error_output(
                "bat",
                kind=TOOL_ERROR_KIND,
                message="Failed to read file.",
                details=reason_details("count_failed"),
            )
        else:
            start_line, start_line_error = _resolve_bat_start_line(
                args,
                total_lines=total_lines,
            )
            if start_line_error is not None:
                details = reason_details(start_line_error, field="start_line") or {}
                details["total_lines"] = int(total_lines)
                error = error_output(
                    "bat",
                    kind=INVALID_INPUT_KIND,
                    message="Invalid bat start_line.",
                    details=details,
                )
            elif total_lines == 0:
                payload_out = _bat_empty_payload(
                    rel_path,
                    args=args,
                    total_lines=total_lines,
                )
            else:
                cmd = _bat_command(args, rel_path=rel_path, start_line=start_line)
                exit_code, stdout_text, _stderr_text = await run_command(
                    cmd,
                    cwd=str(workspace_root),
                    env=build_safe_env(),
                    cancel_token=cancel_token,
                )
                if exit_code != 0:
                    error = error_output(
                        "bat",
                        kind=TOOL_ERROR_KIND,
                        message="Failed to read file.",
                        details=reason_details("command_failed"),
                    )
                else:
                    payload_out = _parse_bat_output(
                        stdout_text,
                        args=args,
                        rel_path=rel_path,
                        start_line=start_line,
                    )
                    payload_out["total_lines"] = int(total_lines)

    if error is not None:
        return None, error
    if payload_out is None:
        return None, _bat_error("Invalid bat payload.")
    return payload_out, None


async def _invoke_bat(
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
    *,
    workspace_root: Path,
) -> str:
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    args, error = _parse_bat_args(raw)
    if error is not None:
        return error
    if args is None:
        return error_output(
            "bat",
            kind=INVALID_INPUT_KIND,
            message="Invalid bat payload.",
        )
    payload, error = await _bat_payload_from_args(
        args=args,
        workspace_root=workspace_root,
        cancel_token=cancel_token,
    )
    if error is not None:
        return error
    if payload is None:
        return _bat_error("Invalid bat payload.")
    return success_output("bat", payload)


def build_bat_tool(
    workspace_root: Path,
) -> FunctionTool:
    """Build the bat inspection operation engine."""
    validate_strict_schema("bat", _BAT_SCHEMA)

    return FunctionTool(
        name="bat",
        description=describe_bat(),
        params_json_schema=_BAT_SCHEMA,
        on_invoke_tool=partial(_invoke_bat, workspace_root=workspace_root),
        strict_json_schema=True,
    )


__all__ = ("build_bat_tool",)
