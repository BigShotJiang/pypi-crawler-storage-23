"""fd schema and argument parsing helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.constants.limits import (
    FD_MAX_DEPTH_MAX,
    FD_MAX_DEPTH_MIN,
    FD_OUTPUT_MAX_ITEMS_DEFAULT,
    FD_OUTPUT_MAX_ITEMS_MAX,
    FD_OUTPUT_MAX_ITEMS_MIN,
    SAFE_OFFSET_MAX,
    SAFE_OFFSET_MIN,
)
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    error_output,
    parse_bounded_int,
    parse_optional_bool,
    parse_optional_str_list,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

FD_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "fd search parameters.",
    "properties": {
        "pattern": {
            "type": ["string", "null"],
            "description": "Pattern to match (null = match all).",
        },
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Workspace-relative search roots.",
            "default": ["."],
        },
        "max_depth": {
            "type": ["integer", "null"],
            "minimum": FD_MAX_DEPTH_MIN,
            "maximum": FD_MAX_DEPTH_MAX,
            "description": "Maximum depth (null = no limit).",
        },
        "pattern_mode": {
            "type": "string",
            "enum": ["regex", "glob", "fixed", "auto"],
            "description": "Pattern mode: regex, glob, fixed, or auto.",
            "default": "auto",
        },
        "type": {
            "type": "string",
            "enum": ["file", "dir", "symlink", "any"],
            "description": "Entry type filter.",
            "default": "any",
        },
        "exclude": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Exclude glob patterns.",
            "default": [],
        },
        "include_hidden": {
            "type": "boolean",
            "description": "Include hidden files and directories.",
            "default": False,
        },
        "gitignore": {
            "type": "boolean",
            "description": "Respect ignore files (.gitignore, .ignore, .fdignore).",
            "default": True,
        },
        "offset": {
            "type": "integer",
            "minimum": 0,
            "description": "0-based result offset.",
            "default": SAFE_OFFSET_MIN,
        },
        "limit": {
            "type": "integer",
            "minimum": 1,
            "description": "Max results per page.",
            "default": FD_OUTPUT_MAX_ITEMS_DEFAULT,
        },
    },
    "additionalProperties": False,
}


@dataclass(frozen=True)
class FdArgs:
    """Parsed fd arguments."""

    pattern: str | None
    pattern_mode: str
    effective_pattern_mode: str
    paths: list[str]
    max_depth: int | None
    type_filter: str
    exclude: list[str]
    include_hidden: bool
    gitignore: bool
    offset: int
    limit: int


def _fd_error(message: str) -> str:
    return error_output("fd", kind=INVALID_INPUT_KIND, message=message)


def _parse_fd_payload(raw: str) -> tuple[dict[str, JSONValue] | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, _fd_error("Invalid fd payload.")
    if set(payload) - {
        "pattern",
        "pattern_mode",
        "paths",
        "max_depth",
        "type",
        "exclude",
        "include_hidden",
        "gitignore",
        "offset",
        "limit",
    }:
        return None, _fd_error("Invalid fd payload.")
    return payload, None


def _parse_fd_pattern(
    payload: Mapping[str, JSONValue],
) -> tuple[str | None, str | None]:
    pattern_obj = payload.get("pattern")
    if pattern_obj is None:
        return None, None
    pattern = as_str(pattern_obj)
    if pattern is None or pattern == "":
        return None, _fd_error("Invalid fd pattern.")
    return pattern, None


def _parse_fd_paths(
    payload: Mapping[str, JSONValue],
) -> tuple[list[str] | None, str | None]:
    paths = parse_optional_str_list(payload, key="paths", default=["."])
    if paths is None:
        return None, _fd_error("Invalid fd paths.")
    return paths, None


def _parse_fd_max_depth(
    payload: Mapping[str, JSONValue],
) -> tuple[int | None, str | None]:
    if "max_depth" not in payload:
        return None, None
    max_depth_raw = payload.get("max_depth")
    if max_depth_raw is None:
        return None, None
    max_depth = parse_bounded_int(
        max_depth_raw,
        default=FD_MAX_DEPTH_MIN,
        min_value=FD_MAX_DEPTH_MIN,
        max_value=FD_MAX_DEPTH_MAX,
    )
    if max_depth is None:
        return None, _fd_error("Invalid fd max_depth.")
    return max_depth, None


_FD_PATTERN_MODES = {"regex", "glob", "fixed", "auto"}


def _parse_fd_pattern_mode(
    payload: Mapping[str, JSONValue],
) -> tuple[str | None, str | None]:
    mode = as_str(payload.get("pattern_mode")) or "auto"
    if mode not in _FD_PATTERN_MODES:
        return None, _fd_error("Invalid fd pattern_mode.")
    return mode, None


def _auto_fd_pattern_mode(pattern: str | None) -> str:
    if not pattern:
        return "fixed"
    if "\\" in pattern:
        return "regex"
    if pattern.startswith("^") or pattern.endswith("$"):
        return "regex"
    if ".*" in pattern:
        return "regex"
    if "*" in pattern or "?" in pattern or "[" in pattern:
        return "glob"
    return "fixed"


def _parse_fd_type(payload: Mapping[str, JSONValue]) -> tuple[str | None, str | None]:
    type_filter = as_str(payload.get("type")) or "any"
    if type_filter not in {"file", "dir", "symlink", "any"}:
        return None, _fd_error("Invalid fd type.")
    return type_filter, None


def _parse_fd_exclude(
    payload: Mapping[str, JSONValue],
) -> tuple[list[str] | None, str | None]:
    exclude = parse_optional_str_list(
        payload,
        key="exclude",
        default=[],
        allow_empty=True,
    )
    if exclude is None:
        return None, _fd_error("Invalid fd exclude list.")
    return exclude, None


def _parse_fd_traversal_flags(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[bool, bool] | None, str | None]:
    include_hidden = parse_optional_bool(
        payload,
        key="include_hidden",
        default=False,
    )
    gitignore = parse_optional_bool(
        payload,
        key="gitignore",
        default=True,
    )
    if include_hidden is None or gitignore is None:
        return None, _fd_error("Invalid fd traversal flags.")
    return (include_hidden, gitignore), None


def _parse_fd_pagination(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[int, int] | None, str | None]:
    offset = parse_bounded_int(
        payload.get("offset"),
        default=SAFE_OFFSET_MIN,
        min_value=SAFE_OFFSET_MIN,
        max_value=SAFE_OFFSET_MAX,
    )
    limit = parse_bounded_int(
        payload.get("limit"),
        default=FD_OUTPUT_MAX_ITEMS_DEFAULT,
        min_value=FD_OUTPUT_MAX_ITEMS_MIN,
        max_value=FD_OUTPUT_MAX_ITEMS_MAX,
    )
    if offset is None or limit is None:
        return None, _fd_error("Invalid fd pagination.")
    return (offset, limit), None


def parse_fd_args(raw: str) -> tuple[FdArgs | None, str | None]:
    """Parse an fd payload into validated arguments."""
    payload, error = _parse_fd_payload(raw)
    if error is not None or payload is None:
        return None, error or _fd_error("Invalid fd payload.")

    pattern, error = _parse_fd_pattern(payload)
    pattern_mode, error = (
        _parse_fd_pattern_mode(payload) if error is None else (None, error)
    )
    paths, error = _parse_fd_paths(payload) if error is None else (None, error)
    max_depth, error = _parse_fd_max_depth(payload) if error is None else (None, error)
    type_filter, error = _parse_fd_type(payload) if error is None else (None, error)
    exclude, error = _parse_fd_exclude(payload) if error is None else (None, error)
    traversal_flags, error = (
        _parse_fd_traversal_flags(payload) if error is None else (None, error)
    )
    pagination, error = (
        _parse_fd_pagination(payload) if error is None else (None, error)
    )
    if error is not None:
        return None, error
    if (
        pattern_mode is None
        or paths is None
        or type_filter is None
        or exclude is None
        or traversal_flags is None
        or pagination is None
    ):
        return None, _fd_error("Invalid fd payload.")

    effective_pattern_mode = (
        _auto_fd_pattern_mode(pattern) if pattern_mode == "auto" else pattern_mode
    )
    if effective_pattern_mode not in {"regex", "glob", "fixed"}:
        return None, _fd_error("Invalid fd pattern_mode.")

    include_hidden, gitignore = traversal_flags
    offset, limit = pagination
    return (
        FdArgs(
            pattern=pattern,
            pattern_mode=pattern_mode,
            effective_pattern_mode=effective_pattern_mode,
            paths=paths,
            max_depth=max_depth,
            type_filter=type_filter,
            exclude=exclude,
            include_hidden=include_hidden,
            gitignore=gitignore,
            offset=offset,
            limit=limit,
        ),
        None,
    )


__all__ = ("FD_SCHEMA", "FdArgs", "parse_fd_args")
