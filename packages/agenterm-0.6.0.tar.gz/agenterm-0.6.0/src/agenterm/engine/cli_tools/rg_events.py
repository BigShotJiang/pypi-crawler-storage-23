"""rg JSON event parsing helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.json_codec import as_int, as_json_object, as_str, parse_json_value
from agenterm.core.text import shorten_line

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class RgRawMatch:
    """Raw rg match before path normalization."""

    path_text: str
    line: int
    column: int
    text: str
    text_truncated: bool


def _parse_rg_summary(event: Mapping[str, JSONValue]) -> dict[str, int] | None:
    data = as_json_object(event.get("data"))
    if data is None:
        return None
    stats = as_json_object(data.get("stats"))
    if stats is None:
        return None
    out: dict[str, int] = {}
    for key, val in stats.items():
        val_int = as_int(val)
        if val_int is None:
            continue
        out[str(key)] = int(val_int)
    return out


def _extract_rg_data(event: Mapping[str, JSONValue]) -> dict[str, JSONValue] | None:
    return as_json_object(event.get("data"))


def _extract_path_text(data: Mapping[str, JSONValue]) -> str | None:
    path_obj = as_json_object(data.get("path"))
    if path_obj is None:
        return None
    return as_str(path_obj.get("text"))


def _extract_line_text(data: Mapping[str, JSONValue]) -> str | None:
    lines_obj = as_json_object(data.get("lines"))
    if lines_obj is None:
        return None
    return as_str(lines_obj.get("text"))


def _extract_line_number(data: Mapping[str, JSONValue]) -> int | None:
    return as_int(data.get("line_number"))


def _extract_submatch_starts(data: Mapping[str, JSONValue]) -> list[int]:
    submatches = data.get("submatches")
    if not isinstance(submatches, list):
        return []
    starts: list[int] = []
    for submatch in submatches:
        sub_obj = as_json_object(submatch)
        if sub_obj is None:
            continue
        start = as_int(sub_obj.get("start"))
        if start is None:
            continue
        starts.append(start)
    return starts


def _parse_rg_match_event(
    event: Mapping[str, JSONValue],
    *,
    max_line_chars: int,
) -> list[RgRawMatch]:
    data = _extract_rg_data(event)
    if data is None:
        return []
    path_text = _extract_path_text(data)
    line_text = _extract_line_text(data)
    line_number = _extract_line_number(data)
    if path_text is None or line_text is None or line_number is None:
        return []
    starts = _extract_submatch_starts(data)
    if not starts:
        return []
    raw_text = line_text.rstrip("\n")
    text_truncated = len(raw_text) > max_line_chars
    text = shorten_line(raw_text, limit=max_line_chars)
    return [
        RgRawMatch(
            path_text=path_text,
            line=int(line_number),
            column=int(start) + 1,
            text=text,
            text_truncated=text_truncated,
        )
        for start in starts
    ]


def _parse_rg_event(
    event: Mapping[str, JSONValue],
    *,
    max_line_chars: int,
) -> tuple[list[RgRawMatch], dict[str, int] | None]:
    event_type = as_str(event.get("type"))
    if event_type == "summary":
        return [], _parse_rg_summary(event)
    if event_type == "match":
        return _parse_rg_match_event(event, max_line_chars=max_line_chars), None
    return [], None


def parse_rg_line(
    raw_line: bytes,
    *,
    max_line_chars: int,
) -> tuple[list[RgRawMatch], dict[str, int] | None]:
    """Parse a single rg JSON line into matches and summary stats."""
    if not raw_line:
        return [], None
    line_text = raw_line.decode("utf-8", "replace").strip()
    if not line_text:
        return [], None
    parsed = parse_json_value(line_text)
    if parsed is None:
        return [], None
    event = as_json_object(parsed)
    if event is None:
        return [], None
    return _parse_rg_event(event, max_line_chars=max_line_chars)


__all__ = ("RgRawMatch", "parse_rg_line")
