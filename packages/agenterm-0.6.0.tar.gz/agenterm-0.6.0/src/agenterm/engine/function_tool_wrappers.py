"""Public builder entrypoints for owned FunctionTool wrappers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.platform import supports_shell_sandbox_platform
from agenterm.engine.function_tool_shell import (
    build_shell_function_tool as _build_shell_function_tool,
)
from agenterm.engine.function_tool_wrappers_apply_patch import (
    build_apply_patch_function_tool,
)
from agenterm.engine.shell_executor import run_shell_sandboxed

if TYPE_CHECKING:
    from pathlib import Path

    from agents.tool import FunctionTool

    from agenterm.config.tool_models import ShellToolConfig
    from agenterm.core.approvals import ShellApprovalManager


def build_shell_function_tool(
    cfg: ShellToolConfig | None,
    *,
    workspace_root: Path,
    approvals: ShellApprovalManager,
) -> FunctionTool | None:
    """Build the shell FunctionTool using the canonical shell wrapper."""
    return _build_shell_function_tool(
        cfg,
        workspace_root=workspace_root,
        approvals=approvals,
        supports_shell_platform=supports_shell_sandbox_platform,
        run_shell=run_shell_sandboxed,
    )


__all__ = (
    "build_apply_patch_function_tool",
    "build_shell_function_tool",
    "run_shell_sandboxed",
    "supports_shell_sandbox_platform",
)
