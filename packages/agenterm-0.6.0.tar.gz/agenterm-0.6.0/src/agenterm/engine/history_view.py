"""History view construction based on vendor message structure."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import (
    as_json_list,
    as_json_object,
    as_str,
    parse_json_object,
)
from agenterm.core.json_types import JSONValue
from agenterm.core.response_items import (
    normalize_input_item_json,
    serialize_input_item,
)
from agenterm.engine.input_projection import project_items_for_model_call
from agenterm.steward.continuation_state import continuation_json_text
from agenterm.store.history import ensure_history_tables

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.config.model import AppConfig
    from agenterm.store.async_db import AsyncStore

type PackedItem = dict[str, JSONValue]


@dataclass(frozen=True)
class HistoryView:
    """History split into a prefix and per-turn buckets."""

    prefix: list[PackedItem]
    turns: list[list[PackedItem]]


def _packed_item_id(item: PackedItem) -> str | None:
    value = item.get("id")
    return value if isinstance(value, str) else None


def _track_item_id(item: PackedItem, seen_item_ids: set[str]) -> bool:
    item_id = _packed_item_id(item)
    if not isinstance(item_id, str):
        return True
    if item_id in seen_item_ids:
        return False
    seen_item_ids.add(item_id)
    return True


def _append_item_by_turn(
    *,
    item: PackedItem,
    turn_number: int,
    prefix: list[PackedItem],
    turns: list[list[PackedItem]],
    current_turn: list[PackedItem],
    current_turn_number: int | None,
) -> tuple[list[PackedItem], int | None]:
    if turn_number <= 0:
        if current_turn:
            turns.append(current_turn)
        prefix.append(item)
        return [], None
    if current_turn_number is None or turn_number != current_turn_number:
        if current_turn:
            turns.append(current_turn)
        return [item], turn_number
    current_turn.append(item)
    return current_turn, current_turn_number


def _is_continuation_item(item: PackedItem) -> bool:
    if item.get("type") != "message":
        return False
    content = as_json_list(item.get("content"))
    if content is None:
        return False
    for raw in content:
        part = as_json_object(raw)
        if part is None:
            continue
        part_type = as_str(part.get("type"))
        if part_type not in {"input_text", "output_text"}:
            continue
        text = as_str(part.get("text"))
        if not text:
            continue
        if continuation_json_text(text) is not None:
            return True
    return False


def _parse_and_project_history_item(
    *,
    raw_json: str | None,
    cfg: AppConfig,
    model_id: str,
) -> PackedItem | None:
    if not isinstance(raw_json, str) or not raw_json:
        msg = "History item payload is missing from message store."
        raise ConfigError(msg)
    parsed = parse_json_object(raw_json)
    if parsed is None:
        msg = "History item payload is not valid JSON."
        raise ConfigError(msg)
    normalized = normalize_input_item_json(parsed, context="history_view.item")
    projected = project_items_for_model_call(
        cfg=cfg,
        model_id=model_id,
        items=[normalized],
    )
    if not projected:
        return None
    if len(projected) != 1:
        msg = "History projection returned multiple items for a single stored item."
        raise ConfigError(msg)
    return serialize_input_item(projected[0], context="history_view.item")


async def load_history_view(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    cfg: AppConfig,
    model_id: str,
) -> HistoryView:
    """Load history items for a branch and split into prefix + turns."""

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[int | None, str | None]]:
        await ensure_history_tables(
            conn,
            tables=("message_structure", "agent_messages"),
        )
        cur = await conn.execute(
            """
            SELECT ms.branch_turn_number, am.message_data
            FROM message_structure ms
            JOIN agent_messages am ON ms.message_id = am.id
            WHERE ms.session_id = ? AND ms.branch_id = ?
            ORDER BY ms.sequence_number ASC
            """,
            (str(session_id), str(branch_id)),
        )
        rows = await cur.fetchall()
        return [(row[0], row[1]) for row in rows]

    rows = await store.run(_op)
    prefix: list[PackedItem] = []
    turns: list[list[PackedItem]] = []
    seen_item_ids: set[str] = set()
    current_turn: list[PackedItem] = []
    current_turn_number: int | None = None
    for raw_turn, raw_json in rows:
        item = _parse_and_project_history_item(
            raw_json=raw_json,
            cfg=cfg,
            model_id=model_id,
        )
        if item is None:
            continue
        if not _track_item_id(item, seen_item_ids):
            continue
        if _is_continuation_item(item):
            if current_turn:
                turns.append(current_turn)
                current_turn = []
                current_turn_number = None
            prefix.append(item)
            continue
        turn_number = int(raw_turn) if isinstance(raw_turn, int) else 0
        current_turn, current_turn_number = _append_item_by_turn(
            item=item,
            turn_number=turn_number,
            prefix=prefix,
            turns=turns,
            current_turn=current_turn,
            current_turn_number=current_turn_number,
        )
    if current_turn:
        turns.append(current_turn)
    return HistoryView(prefix=prefix, turns=turns)


__all__ = ("HistoryView", "load_history_view")
