"""Sandboxed shell executor for agenterm's local shell tool.

Security model (supported platforms):
- Commands run through an OS sandbox backend.
- Filesystem writes are confined to the workspace root.
- Temp directory writes are allowed.
- Network access is configurable (allow/deny).
- Full shell features work (pipes, redirection, chaining) within sandbox.
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING

from agents.tool import (
    ShellActionRequest,
    ShellCallOutcome,
    ShellCommandOutput,
    ShellCommandRequest,
    ShellResult,
)

from agenterm.core.errors import ValidationError
from agenterm.core.json_codec import JSONLike, as_json_object, as_str
from agenterm.engine.sandbox_backends import (
    ShellSandboxBackend,
    resolve_shell_sandbox_backend,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.config.tool_models import ShellToolConfig
    from agenterm.core.approvals import ShellApprovalManager
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.choices.tools import SandboxNetwork

# Safe environment variables to inherit (mirrors MCP SDK pattern).
# Reference: .venv/lib/python3.12/site-packages/mcp/client/stdio/__init__.py:28-45
_SAFE_INHERITED_ENV_VARS: tuple[str, ...] = (
    ("HOME", "LOGNAME", "PATH", "SHELL", "TERM", "USER")
    if sys.platform != "win32"
    else (
        "APPDATA",
        "HOMEDRIVE",
        "HOMEPATH",
        "LOCALAPPDATA",
        "PATH",
        "PATHEXT",
        "PROCESSOR_ARCHITECTURE",
        "SYSTEMDRIVE",
        "SYSTEMROOT",
        "TEMP",
        "USERNAME",
        "USERPROFILE",
    )
)


def _get_default_environment() -> dict[str, str]:
    """Return environment with only safe inherited variables.

    Mirrors the MCP SDK pattern for secure subprocess environments.
    Shell functions (values starting with '()') are filtered as a security measure.
    """
    env = dict[str, str]()
    for key in _SAFE_INHERITED_ENV_VARS:
        value = os.environ.get(key)
        if value is None:
            continue
        # Skip shell functions (security risk)
        if value.startswith("()"):
            continue
        env[key] = value
    return env


def _build_shell_env(custom: Mapping[str, str] | None) -> dict[str, str]:
    """Build shell environment from safe defaults plus optional custom vars."""
    base = _get_default_environment()
    if custom is not None:
        return {**base, **custom}
    return base


def _truncate_text(value: str, *, limit: int) -> tuple[str, bool]:
    """Return (possibly truncated text, was_truncated).

    The returned string is always <= limit characters.
    """
    if limit <= 0:
        return "", bool(value)
    if len(value) <= limit:
        return value, False
    return value[:limit], True


def _truncate_shell_output(
    out: ShellCommandOutput,
    *,
    max_output_length: int,
) -> ShellCommandOutput:
    """Apply a strict stdout+stderr character budget to a single command."""
    stdout = out.stdout or ""
    stderr = out.stderr or ""
    if max_output_length <= 0:
        if not stdout and not stderr:
            return out
        provider_data = dict(out.provider_data or {})
        provider_data["truncated"] = True
        provider_data["stdout_truncated"] = bool(stdout)
        provider_data["stderr_truncated"] = bool(stderr)
        return ShellCommandOutput(
            command=out.command,
            stdout="",
            stderr="",
            outcome=out.outcome,
            provider_data=provider_data,
        )
    if len(stdout) + len(stderr) <= max_output_length:
        return out
    if not stdout:
        stderr_trunc, truncated = _truncate_text(stderr, limit=max_output_length)
        provider_data = dict(out.provider_data or {})
        provider_data["truncated"] = truncated
        provider_data["stdout_truncated"] = False
        provider_data["stderr_truncated"] = truncated
        return ShellCommandOutput(
            command=out.command,
            stdout="",
            stderr=stderr_trunc,
            outcome=out.outcome,
            provider_data=provider_data,
        )
    if not stderr:
        stdout_trunc, truncated = _truncate_text(stdout, limit=max_output_length)
        provider_data = dict(out.provider_data or {})
        provider_data["truncated"] = truncated
        provider_data["stdout_truncated"] = truncated
        provider_data["stderr_truncated"] = False
        return ShellCommandOutput(
            command=out.command,
            stdout=stdout_trunc,
            stderr="",
            outcome=out.outcome,
            provider_data=provider_data,
        )

    failed = out.outcome.type != "exit" or (out.outcome.exit_code not in (None, 0))
    stderr_budget = max_output_length // 2 if failed else max_output_length // 4
    stdout_budget = max_output_length - stderr_budget

    # Transfer unused budget to the other stream.
    if len(stderr) < stderr_budget:
        stdout_budget += stderr_budget - len(stderr)
        stderr_budget = len(stderr)
    elif len(stdout) < stdout_budget:
        stderr_budget += stdout_budget - len(stdout)
        stdout_budget = len(stdout)

    stdout_trunc, stdout_truncated = _truncate_text(stdout, limit=stdout_budget)
    stderr_trunc, stderr_truncated = _truncate_text(stderr, limit=stderr_budget)
    truncated = stdout_truncated or stderr_truncated
    provider_data = dict(out.provider_data or {})
    provider_data["truncated"] = truncated
    provider_data["stdout_truncated"] = stdout_truncated
    provider_data["stderr_truncated"] = stderr_truncated
    return ShellCommandOutput(
        command=out.command,
        stdout=stdout_trunc,
        stderr=stderr_trunc,
        outcome=out.outcome,
        provider_data=provider_data,
    )


def _rejection_result(
    commands: list[str],
    working_dir: str,
    *,
    reason: str | None,
    max_output_length: int | None,
) -> ShellResult:
    """Build rejection result when user declines approval."""
    base = "Shell command execution rejected by user."
    stderr = f"{base}\nReason: {reason}" if reason else base
    return ShellResult(
        output=[
            ShellCommandOutput(
                command=commands[0] if commands else "",
                stdout="",
                stderr=stderr,
                outcome=ShellCallOutcome(type="exit", exit_code=1),
            ),
        ],
        max_output_length=max_output_length,
        provider_data={
            "working_directory": working_dir,
            "approval_rejected": True,
            "approval_reason": reason,
        },
    )


def _clean_optional_str(value: str | None) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return cleaned or None


def _parse_shell_call_metadata(
    raw: JSONLike | None,
) -> tuple[str | None, str | None]:
    raw_map = as_json_object(raw) if raw is not None else None
    if raw_map is None:
        return None, None
    description = _clean_optional_str(as_str(raw_map.get("description")))
    call_cwd = _clean_optional_str(as_str(raw_map.get("cwd")))
    return description, call_cwd


def _resolve_shell_working_dir(
    *,
    workspace_root: Path,
    tool_cfg: ShellToolConfig,
    call_cwd: str | None,
) -> Path:
    if call_cwd is not None:
        candidate = Path(call_cwd)
        if candidate.is_absolute() or call_cwd.startswith("~"):
            message = "Shell cwd must be workspace-relative."
            raise ValidationError(message)
        resolved = (workspace_root / candidate).resolve()
        try:
            resolved.relative_to(workspace_root)
        except ValueError as exc:
            message = "Shell cwd must resolve inside the workspace."
            raise ValidationError(message) from exc
        return resolved
    if tool_cfg.working_dir is not None:
        candidate = (
            tool_cfg.working_dir
            if tool_cfg.working_dir.is_absolute()
            else (workspace_root / tool_cfg.working_dir)
        ).resolve()
        try:
            candidate.relative_to(workspace_root)
        except ValueError as exc:
            message = "Shell working_dir must resolve inside the workspace."
            raise ValidationError(message) from exc
        return candidate
    return workspace_root


def _workspace_relative_path(workspace_root: Path, value: Path) -> str:
    relative = value.relative_to(workspace_root)
    rendered = relative.as_posix()
    return rendered or "."


async def _run_shell_commands(
    *,
    backend: ShellSandboxBackend,
    commands: list[str],
    workspace_root: Path,
    working_dir: Path,
    network: SandboxNetwork,
    timeout_ms: int,
    shell_env: Mapping[str, str],
    max_output_length: int | None,
    cancel_token: CancelToken | None,
) -> list[ShellCommandOutput]:
    outputs: list[ShellCommandOutput] = []
    for cmd in commands:
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        started = time.monotonic()
        output = await backend.execute_command(
            cmd=cmd,
            workspace_root=workspace_root,
            working_dir=working_dir,
            network=network,
            timeout_ms=timeout_ms,
            env=shell_env,
            cancel_token=cancel_token,
        )
        elapsed_ms = max(0, int((time.monotonic() - started) * 1000))
        provider_data = dict(output.provider_data or {})
        provider_data["elapsed_ms"] = elapsed_ms
        output = ShellCommandOutput(
            command=output.command,
            stdout=output.stdout,
            stderr=output.stderr,
            outcome=output.outcome,
            provider_data=provider_data,
        )
        if isinstance(max_output_length, int):
            output = _truncate_shell_output(
                output,
                max_output_length=max_output_length,
            )
        outputs.append(output)
    return outputs


async def run_shell_sandboxed(
    request: ShellCommandRequest,
    *,
    tool_cfg: ShellToolConfig,
    workspace_root: Path,
    approvals: ShellApprovalManager,
    env_override: Mapping[str, str] | None = None,
    cancel_token: CancelToken | None = None,
) -> ShellResult:
    """Execute shell command using the runtime sandbox backend.

    Security is enforced by the selected backend at OS level:
    - Filesystem writes only under workspace_root
    - Network access controlled by tool_cfg.sandbox.network
    - Full shell features (pipes, redirection, chaining) work within sandbox

    Approval is for user control flow only (not security):
    - Every invocation registers an approval request.
    - The host resolves approvals via the approvals manager (prompted in REPL,
      auto-resolved in one-shot runs).

    Cancellation:
    - If cancel_token is set, aborts in-flight commands and raises CancelledError.
    """
    action: ShellActionRequest = request.data.action
    commands = list(action.commands or [])
    effective_max_output_length = (
        action.max_output_length
        if action.max_output_length is not None
        else tool_cfg.max_chars
    )
    backend = resolve_shell_sandbox_backend()
    description, call_cwd = _parse_shell_call_metadata(request.data.raw)
    working_dir = _resolve_shell_working_dir(
        workspace_root=workspace_root,
        tool_cfg=tool_cfg,
        call_cwd=call_cwd,
    )
    working_dir_rel = _workspace_relative_path(workspace_root, working_dir)

    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    if not working_dir.exists():
        msg = f"Shell cwd does not exist: {working_dir_rel}"
        raise ValidationError(msg)
    if not working_dir.is_dir():
        msg = f"Shell cwd is not a directory: {working_dir_rel}"
        raise ValidationError(msg)
    approval_item = approvals.register(
        commands,
        working_dir_rel,
        description=description,
    )
    decision = await approvals.wait(approval_item.id, cancel_token=cancel_token)
    if not decision.approved:
        return _rejection_result(
            commands,
            working_dir_rel,
            reason=decision.reason,
            max_output_length=effective_max_output_length,
        )

    merged_env = dict(tool_cfg.env) if tool_cfg.env is not None else {}
    if env_override:
        merged_env.update(env_override)
    shell_env = _build_shell_env(merged_env or None)
    timeout_ms = action.timeout_ms or tool_cfg.timeout_ms or 60000
    outputs = await _run_shell_commands(
        backend=backend,
        commands=commands,
        workspace_root=workspace_root,
        working_dir=working_dir,
        network=tool_cfg.sandbox.network,
        timeout_ms=timeout_ms,
        shell_env=shell_env,
        max_output_length=effective_max_output_length,
        cancel_token=cancel_token,
    )
    return ShellResult(
        output=outputs,
        max_output_length=effective_max_output_length,
        provider_data={
            "working_directory": working_dir_rel,
            "working_directory_abs": str(working_dir),
        },
    )
