"""Artifact helpers derived from run results.

The Agents SDK yields run results containing typed `RunItem` objects. We convert
those run items into Responses "input items" (`ResponseInputItemParam`) via
`RunItem.to_input_item()` and then reason about durable artifacts.

This module centralizes the logic for:
- extracting image generation call IDs from input items
- resolving those call IDs into agenterm artifact records in the local store

Keeping this in one place prevents drift between `agenterm run` and the REPL.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.artifacts.repo import ArtifactRecord, get_artifact_by_source

if TYPE_CHECKING:
    from collections.abc import Sequence

    from openai.types.responses.response_input_item_param import ResponseInputItemParam

    from agenterm.store.async_db import AsyncStore


@dataclass(frozen=True)
class ImageArtifactResolution:
    """Resolved image artifacts for a completed run."""

    call_ids: tuple[str, ...]
    records: tuple[ArtifactRecord, ...]


def _unique_preserve_order(values: list[str]) -> tuple[str, ...]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        out.append(value)
    return tuple(out)


def image_generation_call_ids_from_input_items(
    items: Sequence[ResponseInputItemParam],
) -> tuple[str, ...]:
    """Return ordered unique image_generation_call IDs referenced by input items."""
    call_ids: list[str] = []
    for item in items:
        if item.get("type") != "image_generation_call":
            continue
        call_id = item.get("id")
        if isinstance(call_id, str) and call_id:
            call_ids.append(call_id)
    return _unique_preserve_order(call_ids)


async def image_artifacts_for_image_generation_calls(
    *,
    store: AsyncStore,
    call_ids: tuple[str, ...],
) -> tuple[ArtifactRecord, ...]:
    """Resolve image artifacts by image_generation_call IDs (best-effort)."""
    if not call_ids:
        return ()
    records: list[ArtifactRecord] = []
    seen: set[str] = set()
    for call_id in call_ids:
        if call_id in seen:
            continue
        seen.add(call_id)
        rec = await get_artifact_by_source(
            store=store,
            source_type="image_generation_call",
            source_id=call_id,
        )
        if rec is not None:
            records.append(rec)
    return tuple(records)


async def resolve_image_artifacts(
    *,
    store: AsyncStore,
    items: Sequence[ResponseInputItemParam],
) -> ImageArtifactResolution:
    """Return image generation call IDs plus resolved artifact records."""
    call_ids = image_generation_call_ids_from_input_items(items)
    records = await image_artifacts_for_image_generation_calls(
        store=store,
        call_ids=call_ids,
    )
    return ImageArtifactResolution(call_ids=call_ids, records=records)


__all__ = (
    "ImageArtifactResolution",
    "image_artifacts_for_image_generation_calls",
    "image_generation_call_ids_from_input_items",
    "resolve_image_artifacts",
)
