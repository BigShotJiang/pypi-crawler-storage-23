"""Build agent_run report payloads for delegated runs."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.items import ItemHelpers, ToolCallOutputItem

from agenterm.core.envelope import iso_timestamp
from agenterm.core.json_codec import require_json_value
from agenterm.core.response_items import serialize_input_items
from agenterm.core.token_usage import TokenUsage
from agenterm.core.tool_output_envelope import parse_tool_output_envelope
from agenterm.engine.result_summary import extract_final_text, summarize_tools_counts

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.items import TResponseInputItem
    from agents.result import RunResultBase

    from agenterm.core.json_types import JSONValue


def _response_ids(result: RunResultBase) -> list[str]:
    out: list[str] = []
    for resp in result.raw_responses:
        rid = resp.response_id
        if isinstance(rid, str) and rid:
            out.append(rid)
    return out


def _output_items(result: RunResultBase) -> Sequence[TResponseInputItem]:
    return [item.to_input_item() for item in result.new_items]


def _result_has_more(result: Mapping[str, JSONValue]) -> bool:
    page_obj = result.get("page")
    if not isinstance(page_obj, dict):
        return False
    return page_obj.get("has_more") is True


def _has_truncated_tool_output(result: RunResultBase) -> bool:
    for item in result.new_items:
        if not isinstance(item, ToolCallOutputItem):
            continue
        output = item.output
        if not isinstance(output, str):
            continue
        parsed = parse_tool_output_envelope(output)
        if parsed is None or not parsed.ok:
            continue
        if parsed.truncated or _result_has_more(parsed.result):
            return True
    return False


def build_agent_run_report_payload(
    *,
    tool_call_id: str,
    trace_id: str | None,
    model: str,
    instructions: str,
    input_text: str,
    result: RunResultBase,
    tools_available: Sequence[str],
    warnings: Sequence[str],
) -> dict[str, JSONValue]:
    """Assemble the stored agent_run report payload."""
    input_items = ItemHelpers.input_to_new_input_list(result.input)
    output_items = _output_items(result)
    usage = TokenUsage.from_agents_usage(result.context_wrapper.usage)
    usage_map: dict[str, JSONValue] = {
        key: int(val) for key, val in usage.to_mapping().items()
    }
    response_ids = _response_ids(result)
    response_id: str | None = response_ids[-1] if response_ids else None
    tool_counts_raw = summarize_tools_counts(result)
    tool_counts: dict[str, JSONValue] = {
        name: int(count) for name, count in sorted(tool_counts_raw.items())
    }
    tools_used = sorted(tool_counts_raw.keys())
    input_items_json: list[JSONValue] = list(
        serialize_input_items(input_items, context="agent_run.input_items")
    )
    output_items_json: list[JSONValue] = list(
        serialize_input_items(output_items, context="agent_run.output_items")
    )
    require_json_value(
        value=response_ids,
        context="agent_run.response_ids",
    )
    response_ids_json: list[JSONValue] = list(response_ids)
    truncated = _has_truncated_tool_output(result)
    return {
        "tool_call_id": tool_call_id,
        "trace_id": trace_id,
        "created_at": iso_timestamp(),
        "model": model,
        "instructions": instructions,
        "input": input_text,
        "input_items": input_items_json,
        "output_text": extract_final_text(result),
        "output_items": output_items_json,
        "tools_available": list(tools_available),
        "tools_used": list(tools_used),
        "tool_counts": tool_counts,
        "truncated": truncated,
        "warnings": list(warnings),
        "usage": usage_map,
        "response_id": response_id,
        "response_ids": response_ids_json,
    }


__all__ = ("build_agent_run_report_payload",)
