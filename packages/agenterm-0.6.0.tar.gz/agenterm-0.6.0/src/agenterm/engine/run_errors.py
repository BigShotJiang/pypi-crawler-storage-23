"""Shared error formatting for Agents runner failures."""

from __future__ import annotations

from agents.exceptions import (
    AgentsException,
    InputGuardrailTripwireTriggered,
    MaxTurnsExceeded,
    OutputGuardrailTripwireTriggered,
)
from openai import APIConnectionError, APIError, APIStatusError, APITimeoutError

from agenterm.core.error_conversion import resolve_provider_error_data
from agenterm.core.error_openai import openai_status_message


def format_provider_error(exc: APIError, *, provider_label: str | None) -> str:
    """Return a concise, user-facing message for provider API errors."""
    provider_error = resolve_provider_error_data(
        exc,
        provider_label=provider_label,
    )
    provider_name = provider_error.provider_name
    if isinstance(exc, APITimeoutError):
        return f"{provider_name} API timeout: {exc}"
    if isinstance(exc, APIConnectionError):
        return f"{provider_name} API connection error: {exc}"
    if isinstance(exc, APIStatusError):
        return openai_status_message(
            exc,
            provider_name=provider_name,
            detail_message=provider_error.detail_message,
        )
    details = provider_error.details
    suffix_bits: list[str] = []
    code = details.get("code")
    if isinstance(code, str) and code:
        suffix_bits.append(f"code={code}")
    param = details.get("param")
    if isinstance(param, str) and param:
        suffix_bits.append(f"param={param}")
    suffix = f" ({', '.join(suffix_bits)})" if suffix_bits else ""
    detail = provider_error.detail_message or str(exc)
    return f"{provider_name} API error{suffix}: {detail}"


def format_agents_error(exc: AgentsException) -> str:
    """Return a concise message for Agents engine errors."""
    if isinstance(exc, InputGuardrailTripwireTriggered):
        gr = exc.guardrail_result.guardrail
        return f"Guardrail blocked input: {gr.get_name()}"

    if isinstance(exc, OutputGuardrailTripwireTriggered):
        gr = exc.guardrail_result.guardrail
        return f"Guardrail blocked output: {gr.get_name()}"

    if isinstance(exc, MaxTurnsExceeded):
        return str(exc)

    return f"Agents engine error: {exc}"


__all__ = ("format_agents_error", "format_provider_error")
