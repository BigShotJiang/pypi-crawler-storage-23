"""Execution wrappers around Agents Runner.

These helpers provide a single path for run execution and are responsible
for mapping low-level SDK exceptions into the CLI's AgentermError hierarchy.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from agents.exceptions import AgentsException, MaxTurnsExceeded
from agents.run import RunConfig, Runner
from openai import APIError

from agenterm.core.errors import PipelineError
from agenterm.core.model_contract import (
    apply_optional_model_settings_fallback,
    provider_error_param_from_exception,
)
from agenterm.core.model_id import is_openai_model_id, model_plane
from agenterm.core.openai_client import get_openai_client
from agenterm.engine.history_packing import (
    HistoryPackingOptions,
    build_session_input_callback,
)
from agenterm.engine.model_input_packing import build_call_model_input_filter
from agenterm.engine.run_config import build_run_config
from agenterm.engine.run_errors import format_agents_error, format_provider_error
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.service import DEFAULT_SESSION_INPUT_CALLBACK

if TYPE_CHECKING:
    from collections.abc import Callable

    from agents.agent import Agent
    from agents.items import TResponseInputItem
    from agents.lifecycle import RunHooks
    from agents.memory import Session
    from agents.model_settings import ModelSettings
    from agents.result import RunResult, RunResultStreaming

    from agenterm.config.model import AppConfig
    from agenterm.core.plan import ToolRuntimeContext


def _needs_openai_client(model_id: str) -> bool:
    return is_openai_model_id(model_id)


def _apply_session_input_callback(
    run_cfg: RunConfig,
    *,
    opts: RunExecOptions,
    model_id: str,
) -> RunConfig:
    if opts.session is None:
        return run_cfg
    if not isinstance(opts.session, AgentermSQLiteSession):
        return run_cfg
    history_packing = opts.history_packing or HistoryPackingOptions(
        interactive=False,
        approvals=None,
        emitters=None,
    )
    callback = build_session_input_callback(
        cfg=opts.cfg,
        session=opts.session,
        model_id=model_id,
        options=history_packing,
    )
    return replace(run_cfg, session_input_callback=callback)


def _apply_call_model_input_filter(
    run_cfg: RunConfig,
    *,
    opts: RunExecOptions,
    model_id: str,
) -> RunConfig:
    if opts.session is None:
        return run_cfg
    if not isinstance(opts.session, AgentermSQLiteSession):
        return run_cfg
    history_packing = opts.history_packing or HistoryPackingOptions(
        interactive=False,
        approvals=None,
        emitters=None,
    )
    callback = build_call_model_input_filter(
        cfg=opts.cfg,
        session=opts.session,
        model_id=model_id,
        options=history_packing,
    )
    return replace(run_cfg, call_model_input_filter=callback)


def _base_run_config_for_options(
    opts: RunExecOptions,
    *,
    model_id: str,
) -> RunConfig:
    return build_run_config(
        opts.cfg,
        workflow_name=opts.workflow_name,
        model_id=model_id,
        model_settings_override=opts.model_settings_override,
        response_include_override=opts.response_include,
    )


def apply_optional_fallback_to_run_options(
    *,
    opts: RunExecOptions,
    exc: APIError,
    on_warning: Callable[[str], None] | None = None,
) -> RunExecOptions | None:
    """Return updated run options after optional-model compatibility adaptation."""
    effective_model = opts.model_id or opts.cfg.agent.model
    provider_label = model_plane(effective_model)
    run_cfg = _base_run_config_for_options(opts, model_id=effective_model)
    model_settings = run_cfg.model_settings
    if model_settings is None:
        return None
    message = format_provider_error(exc, provider_label=provider_label)
    param = provider_error_param_from_exception(exc)
    fallback = apply_optional_model_settings_fallback(
        model_id=effective_model,
        model_settings=model_settings,
        param=param,
        message=message,
    )
    if fallback is None:
        return None
    if on_warning is not None:
        for warning in fallback.warnings:
            on_warning(warning)
    return replace(opts, model_settings_override=fallback.model_settings)


def _apply_optional_model_fallback(
    *,
    run_cfg: RunConfig,
    model_id: str,
    exc: APIError,
    provider_label: str,
    on_warning: Callable[[str], None] | None,
) -> RunConfig | None:
    model_settings = run_cfg.model_settings
    if model_settings is None:
        return None
    message = format_provider_error(exc, provider_label=provider_label)
    param = provider_error_param_from_exception(exc)
    fallback = apply_optional_model_settings_fallback(
        model_id=model_id,
        model_settings=model_settings,
        param=param,
        message=message,
    )
    if fallback is None:
        return None
    if on_warning is not None:
        for warning in fallback.warnings:
            on_warning(warning)
    return replace(run_cfg, model_settings=fallback.model_settings)


def _runner_call_inputs(
    *,
    agent: Agent,
    run_cfg: RunConfig,
) -> tuple[Agent, RunConfig]:
    """Return SDK call inputs with a single effective model-settings source.

    The Agents SDK resolves settings as:
    `starting_agent.model_settings.resolve(run_config.model_settings)`.
    Because `resolve()` overlays only non-None override values, optional
    settings cannot be *cleared* by setting `run_config.model_settings.<field>`
    to `None` when the same field remains non-None on the agent.

    To make optional-setting fallback deterministic, we collapse the effective
    settings into the starting agent and clear the run-config model settings for
    this SDK invocation.
    """
    model_settings = run_cfg.model_settings
    if model_settings is None:
        return agent, run_cfg
    return (
        agent.clone(model_settings=model_settings),
        replace(run_cfg, model_settings=None),
    )


@dataclass(frozen=True)
class RunExecOptions:
    """Immutable execution options shared by run_once and run_streamed."""

    cfg: AppConfig
    workflow_name: str = "agenterm run"
    session: Session | None = None
    background: bool = False
    tool_context: ToolRuntimeContext | None = None
    model_id: str | None = None
    max_turns: int | None = None
    history_packing: HistoryPackingOptions | None = None
    response_include: tuple[str, ...] | None = None
    on_optional_fallback: Callable[[str], None] | None = None
    model_settings_override: ModelSettings | None = None


async def run_once(
    agent: Agent,
    input_items: str | list[TResponseInputItem],
    *,
    opts: RunExecOptions,
) -> RunResult:
    """Execute a single non-streaming agent run.

    SDK-specific exceptions are wrapped in AgentermError so edges can handle
    failures uniformly.
    """
    effective_model = opts.model_id or opts.cfg.agent.model
    provider_label = model_plane(effective_model)
    if _needs_openai_client(effective_model):
        get_openai_client()
    cfg = opts.cfg
    run_cfg = _base_run_config_for_options(opts, model_id=effective_model)
    max_turns = opts.max_turns if opts.max_turns is not None else cfg.agent.max_turns
    if opts.background:
        # When running in background mode, we rely on the Responses API
        # `background` flag. This is plumbed via ModelSettings.extra_args
        # so the engine path remains single and based on Agents.
        ms = run_cfg.model_settings or cfg.to_model_settings()
        extra_args = dict(ms.extra_args or {})
        extra_args["background"] = True
        # Background responses must be stored server-side so they can be
        # inspected later.
        ms = replace(ms, extra_args=extra_args, store=True)
        # Background runs require provider-side persistence, but can still be
        # invoked in stateless input mode (e.g., a compaction reseed run).
        run_cfg = replace(
            run_cfg,
            model_settings=ms,
            session_input_callback=DEFAULT_SESSION_INPUT_CALLBACK,
        )
    run_cfg = _apply_session_input_callback(
        run_cfg,
        opts=opts,
        model_id=effective_model,
    )
    run_cfg = _apply_call_model_input_filter(
        run_cfg,
        opts=opts,
        model_id=effective_model,
    )
    run_cfg_current = run_cfg
    for _ in range(2):
        try:
            call_agent, call_cfg = _runner_call_inputs(
                agent=agent,
                run_cfg=run_cfg_current,
            )
            return await Runner.run(
                starting_agent=call_agent,
                input=input_items,
                max_turns=max_turns,
                run_config=call_cfg,
                session=opts.session,
                context=opts.tool_context,
            )
        except APIError as exc:
            fallback_cfg = _apply_optional_model_fallback(
                run_cfg=run_cfg_current,
                model_id=effective_model,
                exc=exc,
                provider_label=provider_label,
                on_warning=opts.on_optional_fallback,
            )
            if fallback_cfg is not None:
                run_cfg_current = fallback_cfg
                continue
            # Normalize OpenAI client errors into a single PipelineError with a
            # user-facing message derived from the concrete error subclass.
            raise PipelineError(
                format_provider_error(exc, provider_label=provider_label)
            ) from exc
        except MaxTurnsExceeded:
            raise
        except AgentsException as exc:
            raise PipelineError(format_agents_error(exc)) from exc
    msg = "run_once exhausted optional fallback attempts."
    raise PipelineError(msg)


def run_streamed(
    agent: Agent,
    input_items: str | list[TResponseInputItem],
    *,
    opts: RunExecOptions,
    hooks: RunHooks[ToolRuntimeContext] | None = None,
) -> RunResultStreaming:
    """Execute a streaming agent run and return the streaming handle."""
    effective_model = opts.model_id or opts.cfg.agent.model
    provider_label = model_plane(effective_model)
    if _needs_openai_client(effective_model):
        get_openai_client()
    cfg = opts.cfg
    run_cfg = _base_run_config_for_options(opts, model_id=effective_model)
    run_cfg = _apply_session_input_callback(
        run_cfg,
        opts=opts,
        model_id=effective_model,
    )
    run_cfg = _apply_call_model_input_filter(
        run_cfg,
        opts=opts,
        model_id=effective_model,
    )
    run_cfg_current = run_cfg
    for _ in range(2):
        try:
            call_agent, call_cfg = _runner_call_inputs(
                agent=agent,
                run_cfg=run_cfg_current,
            )
            return Runner.run_streamed(
                starting_agent=call_agent,
                input=input_items,
                max_turns=(
                    opts.max_turns
                    if opts.max_turns is not None
                    else cfg.agent.max_turns
                ),
                hooks=hooks,
                run_config=call_cfg,
                session=opts.session,
                context=opts.tool_context,
            )
        except APIError as exc:
            fallback_cfg = _apply_optional_model_fallback(
                run_cfg=run_cfg_current,
                model_id=effective_model,
                exc=exc,
                provider_label=provider_label,
                on_warning=opts.on_optional_fallback,
            )
            if fallback_cfg is not None:
                run_cfg_current = fallback_cfg
                continue
            raise PipelineError(
                format_provider_error(exc, provider_label=provider_label)
            ) from exc
        except MaxTurnsExceeded:
            raise
        except AgentsException as exc:
            raise PipelineError(format_agents_error(exc)) from exc
    msg = "run_streamed exhausted optional fallback attempts."
    raise PipelineError(msg)
