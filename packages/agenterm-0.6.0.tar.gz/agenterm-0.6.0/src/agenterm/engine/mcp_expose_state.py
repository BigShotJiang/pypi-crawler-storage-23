"""State/build helpers for local FunctionTool MCP exposure."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from types import MappingProxyType
from typing import TYPE_CHECKING

from agents.tool import FunctionTool
from agents.tool_context import ToolContext
from mcp import types as mtypes

from agenterm.artifacts.agent_run import load_agent_run_report
from agenterm.config.paths import meta_store_path
from agenterm.config.tools_catalog import build_tool_catalog_from_config
from agenterm.constants.tools import TOOL_TYPE_FUNCTION
from agenterm.core.approvals import ApprovalsContext
from agenterm.core.errors import ConfigError
from agenterm.core.function_tools import resolve_function_tools
from agenterm.core.json_codec import (
    as_str,
    dumps_compact,
    require_json_object,
    require_json_value,
)
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.tool_output_envelope import (
    ToolOutputEnvelope,
    ToolOutputError,
    parse_tool_output_envelope,
)
from agenterm.core.tool_selection import ToolCatalog, ToolSelection, resolve_selection
from agenterm.core.toolspec import is_fn_key, is_user_fn_key, make_fn_key
from agenterm.engine.agent_factory import build_agent_from_config
from agenterm.engine.agent_run_report_sanitize import sanitize_agent_run_report
from agenterm.engine.agent_run_report_tool import build_agent_run_report_tool
from agenterm.engine.agent_run_tool import AGENT_RUN_REPORT_SCHEMA, build_agent_run_tool
from agenterm.engine.cli_tools import (
    build_bat_tool,
    build_fd_tool,
    build_read_bytes_tool,
    build_rg_tool,
    build_stat_tool,
    build_tree_tool,
)
from agenterm.engine.function_tool_wrappers import (
    build_apply_patch_function_tool,
    build_shell_function_tool,
)
from agenterm.engine.info_tool import build_info_tool
from agenterm.engine.inspect import build_inspect_tool
from agenterm.engine.plan_tool import build_plan_tool
from agenterm.engine.tool_output_clamp import ToolOutputClamp
from agenterm.store.async_db import AsyncStore

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence
    from pathlib import Path

    from agenterm.config.model import AppConfig
    from agenterm.core.json_types import JSONValue
    from agenterm.core.toolspec import ToolSpec

ERROR_KIND_TOOL = "tool_error"
_EXPOSE_EXCLUDE_KEYS = {make_fn_key("steward")}

FUNCTION_TOOL_OUTPUT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "properties": {
        "tool": {"type": "string"},
        "ok": {"type": "boolean"},
        "truncated": {"type": "boolean"},
        "limit_reason": {"type": ["string", "null"]},
        "result": {"type": "object"},
        "error": {
            "type": "object",
            "properties": {
                "kind": {"type": "string"},
                "message": {"type": "string"},
                "details": {"type": "object"},
            },
            "required": ["kind", "message", "details"],
            "additionalProperties": False,
        },
    },
    "required": ["tool", "ok", "truncated", "limit_reason", "result"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class McpExposeState:
    """Immutable state shared by the MCP exposure server."""

    tools: Mapping[str, FunctionTool]
    tool_defs: tuple[mtypes.Tool, ...]
    tool_context: ToolRuntimeContext


def _resolve_expose_specs(cfg: AppConfig) -> tuple[ToolSpec, ...]:
    tools_map, bundles_map, default_bundles = build_tool_catalog_from_config(cfg)
    catalog = ToolCatalog(
        tools_map=tools_map,
        bundles_map=bundles_map,
        default_bundles=list(default_bundles),
    )
    expose = cfg.mcp.expose
    explicit = expose.bundles is not None or expose.tools is not None
    bundles = (
        tuple(expose.bundles) if expose.bundles is not None else tuple(default_bundles)
    )
    keys = tuple(expose.tools or ())
    selection = ToolSelection(
        selected_bundles=bundles,
        selected_keys=keys,
        explicit_override=explicit,
    )
    resolved = resolve_selection(selection, catalog=catalog)
    if resolved.error is not None:
        raise ConfigError(resolved.error)
    specs = resolved.specs
    filtered = tuple(
        spec for spec in specs if is_fn_key(spec.key) or is_user_fn_key(spec.key)
    )
    if _EXPOSE_EXCLUDE_KEYS:
        filtered = tuple(
            spec for spec in filtered if spec.key not in _EXPOSE_EXCLUDE_KEYS
        )
    if not expose.allow_dangerous:
        filtered = tuple(spec for spec in filtered if not spec.dangerous)
    return filtered


def _user_tool_map(specs: Sequence[ToolSpec]) -> Mapping[str, FunctionTool]:
    names = [
        spec.name for spec in specs if spec.name and spec.type == TOOL_TYPE_FUNCTION
    ]
    tools = resolve_function_tools(names)
    return MappingProxyType({tool.name: tool for tool in tools})


def _append_tool(tools: list[FunctionTool], tool: FunctionTool | None) -> None:
    if tool is not None:
        tools.append(tool)


def _inspect_operation_tools_for_expose(
    cfg: AppConfig,
    *,
    workspace_root: Path,
    specs: Sequence[ToolSpec],
) -> dict[str, FunctionTool]:
    tools = [
        build_rg_tool(workspace_root=workspace_root),
        build_fd_tool(workspace_root=workspace_root),
        build_bat_tool(workspace_root=workspace_root),
        build_read_bytes_tool(workspace_root=workspace_root),
        build_tree_tool(workspace_root=workspace_root),
        build_stat_tool(workspace_root=workspace_root),
        build_info_tool(
            cfg,
            workspace_root=workspace_root,
            selected_specs=specs,
        ),
    ]
    return {tool.name: tool for tool in tools}


def _mcp_builtin_builders(
    cfg: AppConfig,
    *,
    workspace_root: Path,
    specs: Sequence[ToolSpec],
) -> Mapping[str, Callable[[], FunctionTool | None]]:
    approvals = ApprovalsContext(mode="auto")
    return {
        make_fn_key("shell"): lambda: build_shell_function_tool(
            cfg.tools.shell,
            workspace_root=workspace_root,
            approvals=approvals.shell,
        ),
        make_fn_key("apply_patch"): lambda: build_apply_patch_function_tool(
            cfg.tools.apply_patch,
            workspace_root=workspace_root,
            approvals=approvals.patch,
        ),
        make_fn_key("inspect"): lambda: build_inspect_tool(
            cfg.tools.inspect,
            tools=_inspect_operation_tools_for_expose(
                cfg,
                workspace_root=workspace_root,
                specs=specs,
            ),
            max_chars=cfg.tools.max_chars,
        ),
        make_fn_key("plan"): lambda: build_plan_tool(cfg.tools.plan),
        make_fn_key("agent_run"): lambda: build_agent_run_tool(
            cfg,
            workspace_root=workspace_root,
            agent_builder=build_agent_from_config,
        ),
        make_fn_key("agent_run_report"): lambda: build_agent_run_report_tool(
            cfg.tools.agent_run_report
        ),
    }


def _build_function_tools(
    cfg: AppConfig,
    specs: Sequence[ToolSpec],
    *,
    workspace_root: Path,
) -> list[FunctionTool]:
    user_tools = _user_tool_map(specs)
    builders = _mcp_builtin_builders(cfg, workspace_root=workspace_root, specs=specs)
    clamp = ToolOutputClamp(cfg.tools.max_chars)
    tools: list[FunctionTool] = []
    for spec in specs:
        builder = builders.get(spec.key)
        if builder is not None:
            _append_tool(tools, builder())
            continue
        if spec.type == TOOL_TYPE_FUNCTION and spec.name:
            tool = user_tools.get(spec.name)
            if tool is not None:
                tools.append(tool)
            continue
    wrapped = clamp.wrap_tools(tools)
    return [tool for tool in wrapped if isinstance(tool, FunctionTool)]


def _tool_output_schema(tool: FunctionTool) -> dict[str, JSONValue]:
    if tool.name == "agent_run":
        return dict(AGENT_RUN_REPORT_SCHEMA)
    return dict(FUNCTION_TOOL_OUTPUT_SCHEMA)


def _tool_defs(tools: Sequence[FunctionTool]) -> tuple[mtypes.Tool, ...]:
    defs: list[mtypes.Tool] = []
    for tool in tools:
        schema = dict(tool.params_json_schema)
        if "properties" not in schema:
            schema["properties"] = {}
        defs.append(
            mtypes.Tool(
                name=tool.name,
                description=tool.description or "",
                inputSchema=schema,
                outputSchema=_tool_output_schema(tool),
            ),
        )
    return tuple(defs)


def _tool_context(cfg: AppConfig) -> ToolRuntimeContext:
    return ToolRuntimeContext(
        db_path=meta_store_path(),
        session_id=None,
        branch_id=None,
        run_number=None,
        trace_id=cfg.run.trace_id,
        plan_cache={},
        cancel_token=None,
    )


def build_mcp_expose_state(
    cfg: AppConfig,
    *,
    workspace_root: Path,
) -> McpExposeState:
    """Build MCP exposure state (tool registry + runtime context)."""
    specs = _resolve_expose_specs(cfg)
    tools = _build_function_tools(cfg, specs, workspace_root=workspace_root)
    tool_map_raw: dict[str, FunctionTool] = {}
    for tool in tools:
        if tool.name in tool_map_raw:
            msg = f"Duplicate FunctionTool name for MCP exposure: {tool.name}"
            raise ConfigError(msg)
        tool_map_raw[tool.name] = tool
    tool_map = MappingProxyType(tool_map_raw)
    return McpExposeState(
        tools=tool_map,
        tool_defs=_tool_defs(tools),
        tool_context=_tool_context(cfg),
    )


def _result_has_more(result: Mapping[str, JSONValue]) -> bool:
    page_obj = result.get("page")
    if not isinstance(page_obj, dict):
        return False
    return page_obj.get("has_more") is True


def tool_summary_text(env: ToolOutputEnvelope) -> str:
    """Build a stable text summary for MCP content blocks."""
    summary = as_str(env.result.get("summary"))
    if summary:
        return summary
    if env.ok:
        if env.truncated:
            return f"{env.tool} ok (output truncated)"
        if _result_has_more(env.result):
            return f"{env.tool} ok (has_more)"
        return f"{env.tool} ok"
    return f"{env.tool} error"


def error_call_tool_result(
    *,
    tool_name: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
    kind: str = ERROR_KIND_TOOL,
) -> mtypes.CallToolResult:
    """Build a typed MCP error result from an owned-tool failure."""
    err = ToolOutputError(
        kind=kind,
        message=message,
        details=dict(details) if details is not None else {},
    )
    env = ToolOutputEnvelope(
        tool=tool_name,
        ok=False,
        result={},
        error=err,
    )
    summary = f"{tool_name} error: {err.kind}"
    return mtypes.CallToolResult(
        content=[mtypes.TextContent(type="text", text=summary)],
        structuredContent=env.to_json(),
        isError=True,
    )


async def agent_run_structured_output(
    env: ToolOutputEnvelope,
    *,
    tool_context: ToolRuntimeContext,
) -> tuple[Sequence[mtypes.ContentBlock], dict[str, JSONValue]] | mtypes.CallToolResult:
    """Load and return stored report payload for agent_run MCP calls."""
    report_id = as_str(env.result.get("report_id"))
    if report_id is None:
        return error_call_tool_result(
            tool_name="agent_run",
            message="agent_run report_id missing",
            details={"reason": "missing_report_id", "field": "report_id"},
            kind="invalid_input",
        )
    report = await load_agent_run_report(
        store=AsyncStore(tool_context.db_path),
        artifact_id=report_id,
    )
    if report is None:
        return error_call_tool_result(
            tool_name="agent_run",
            message="agent_run report not found",
            details={
                "reason": "not_found",
                "field": "report_id",
                "report_id": report_id,
            },
            kind="not_found",
        )
    summary = as_str(env.result.get("summary")) or ""
    blocks: Sequence[mtypes.ContentBlock] = [
        mtypes.TextContent(type="text", text=summary),
    ]
    sanitized_report, _stats = sanitize_agent_run_report(report)
    return blocks, sanitized_report


def build_tool_context(
    *,
    state: McpExposeState,
    name: str,
    arguments: Mapping[str, JSONValue],
) -> tuple[ToolContext[ToolRuntimeContext], str]:
    """Create ToolContext + canonical JSON arguments for exposed tool invocation."""
    args_json = dumps_compact(
        require_json_object(
            value=arguments,
            context="mcp.expose.arguments",
        ),
        ensure_ascii=True,
        context="mcp.expose.arguments",
    )
    tool_call_id = uuid.uuid4().hex
    return (
        ToolContext(
            context=state.tool_context,
            tool_name=name,
            tool_call_id=tool_call_id,
            tool_arguments=args_json,
            tool_call=None,
        ),
        args_json,
    )


def wrap_raw_output(*, tool_name: str, output: JSONValue) -> ToolOutputEnvelope:
    """Wrap raw non-enveloped tool output in the canonical envelope."""
    return ToolOutputEnvelope(
        tool=tool_name,
        ok=True,
        result={
            "result": require_json_value(
                value=output,
                context=f"mcp.expose.output.{tool_name}",
            )
        },
    )


def parse_output_envelope(*, tool_name: str, output: str) -> ToolOutputEnvelope:
    """Parse a tool output string into a canonical envelope."""
    parsed = parse_tool_output_envelope(output)
    if parsed is not None:
        return parsed
    return ToolOutputEnvelope(
        tool=tool_name,
        ok=True,
        result={"text": output},
    )


__all__ = (
    "McpExposeState",
    "agent_run_structured_output",
    "build_mcp_expose_state",
    "build_tool_context",
    "error_call_tool_result",
    "parse_output_envelope",
    "tool_summary_text",
    "wrap_raw_output",
)
