"""Canonical MCP tool-call metadata resolver.

This module owns the single `_meta` generation path for MCP tool calls.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool_context import ToolContext

from agenterm.core.plan import ToolRuntimeContext

if TYPE_CHECKING:
    from agents.mcp.util import MCPToolMetaContext

    from agenterm.core.json_types import JSONValue


def _tool_call_id(ctx: MCPToolMetaContext) -> str | None:
    run_context = ctx.run_context
    if not isinstance(run_context, ToolContext):
        return None
    call_id = run_context.tool_call_id
    if not call_id:
        return None
    return call_id


def resolve_mcp_tool_meta(ctx: MCPToolMetaContext) -> dict[str, JSONValue] | None:
    """Build MCP `_meta` from the current run/tool runtime context."""
    runtime = ctx.run_context.context
    if not isinstance(runtime, ToolRuntimeContext):
        return None

    metadata: dict[str, JSONValue] = {}
    if runtime.trace_id:
        metadata["trace_id"] = runtime.trace_id
    if runtime.session_id:
        metadata["session_id"] = runtime.session_id
    if runtime.branch_id:
        metadata["branch_id"] = runtime.branch_id
    if runtime.run_number is not None:
        metadata["run_number"] = runtime.run_number

    call_id = _tool_call_id(ctx)
    if call_id:
        metadata["tool_call_id"] = call_id

    if not metadata:
        return None
    return {"agenterm": metadata}


__all__ = ("resolve_mcp_tool_meta",)
