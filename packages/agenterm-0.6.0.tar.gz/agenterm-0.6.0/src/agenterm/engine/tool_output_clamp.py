"""Unified tool output clamp helpers."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from agents.tool import FunctionTool, Tool

from agenterm.core.tool_output_envelope import (
    ToolOutputEnvelope,
    ToolOutputError,
    parse_tool_output_envelope,
)
from agenterm.core.tool_output_limits import (
    limit_tool_output,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.tool_context import ToolContext

    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext


@dataclass(frozen=True)
class ToolOutputClamp:
    """Clamp tool outputs to a single global max length."""

    max_chars: int

    def _invalid_tool_output_envelope(
        self,
        *,
        tool_name: str,
        kind: str,
        message: str,
        details: Mapping[str, JSONValue],
    ) -> str:
        env = ToolOutputEnvelope(
            tool=tool_name,
            ok=False,
            truncated=False,
            limit_reason=None,
            result={},
            error=ToolOutputError(kind=kind, message=message, details=dict(details)),
        )
        limited = limit_tool_output(env, max_chars=self.max_chars)
        return limited.to_json_string()

    def clamp_value(self, value: JSONValue, *, tool_name: str) -> JSONValue:
        """Clamp a raw owned-tool output value.

        Owned tools must return a single `ToolOutputEnvelope` JSON string.
        Non-envelope outputs are treated as tool errors (strict envelope parsing only).
        """
        if self.max_chars <= 0:
            return value
        tool = tool_name or "unknown"
        if not isinstance(value, str):
            details: dict[str, JSONValue] = {"reason": "non_string_output"}
            details["output_type"] = type(value).__name__
            return self._invalid_tool_output_envelope(
                tool_name=tool,
                kind="tool_error",
                message="Tool returned a non-string output value.",
                details=details,
            )
        parsed = parse_tool_output_envelope(value)
        if parsed is None:
            return self._invalid_tool_output_envelope(
                tool_name=tool,
                kind="tool_error",
                message="Tool returned an invalid output envelope.",
                details={"reason": "invalid_envelope"},
            )
        limited = limit_tool_output(parsed, max_chars=self.max_chars)
        return limited.to_json_string()

    def clamp_function_envelope(
        self,
        env: ToolOutputEnvelope,
    ) -> ToolOutputEnvelope:
        """Clamp a FunctionTool envelope in structured form."""
        if self.max_chars <= 0:
            return env
        return limit_tool_output(env, max_chars=self.max_chars)

    def wrap_function_tool(self, tool: FunctionTool) -> FunctionTool:
        """Return a FunctionTool wrapper that clamps output length."""
        if self.max_chars <= 0:
            return tool
        inner = tool.on_invoke_tool
        tool_name = tool.name or "unknown"

        async def _invoke(
            ctx: ToolContext[ToolRuntimeContext],
            raw: str,
        ) -> JSONValue:
            output = await inner(ctx, raw)
            return self.clamp_value(output, tool_name=tool_name)

        return replace(tool, on_invoke_tool=_invoke)

    def wrap_tools(self, tools: Sequence[Tool]) -> list[Tool]:
        """Clamp outputs for all FunctionTools in a tool list."""
        if self.max_chars <= 0:
            return list(tools)
        out: list[Tool] = []
        for tool in tools:
            if isinstance(tool, FunctionTool):
                out.append(self.wrap_function_tool(tool))
            else:
                out.append(tool)
        return out


__all__ = ("ToolOutputClamp",)
