"""Unified, model-facing tool descriptions for built-in tools."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ToolDescriptionParts:
    """Template parts for a model-facing tool description."""

    purpose: str
    inputs: str
    defaults: str
    behavior: str
    outputs: str
    errors: str


def render_tool_description(parts: ToolDescriptionParts) -> str:
    """Render a consistent multi-line tool description."""
    lines = [
        f"Purpose: {parts.purpose}",
        f"Inputs: {parts.inputs}",
        f"Defaults: {parts.defaults}",
        f"Behavior: {parts.behavior}",
        f"Outputs: {parts.outputs}",
        f"Errors: {parts.errors}",
    ]
    return "\n".join(lines)


def describe_rg() -> str:
    """Return the model-facing rg description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Search workspace text with ripgrep.",
            inputs=(
                "pattern; pattern_mode; case_mode; paths; glob; include_hidden; "
                "gitignore; context{before,after}; result_mode; offset; limit; "
                "max_line_chars."
            ),
            defaults=(
                "pattern_mode=auto; case_mode=smart; paths=['.']; "
                "include_hidden=false; gitignore=true; "
                "context={before:0,after:0}; paging uses schema defaults."
            ),
            behavior=(
                "Workspace-relative paths only; include_hidden enables --hidden; "
                "gitignore=false maps to --no-ignore; auto mode chooses regex for "
                "\\\\ escapes, anchors, or .*; output order is deterministic."
            ),
            outputs=(
                "matches/files/count/summary plus page + coverage metadata; "
                "matches include text_truncated and optional context fields; "
                "pattern_mode=auto includes effective_pattern_mode."
            ),
            errors=(
                "invalid_input for bad payload/paths/patterns; tool_error for "
                "missing binary or command failure."
            ),
        )
    )


def describe_fd() -> str:
    """Return the model-facing fd description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Find files and directories under the workspace.",
            inputs=(
                "pattern; pattern_mode; paths; max_depth; type; exclude; "
                "include_hidden; gitignore; offset; limit."
            ),
            defaults=(
                "pattern null matches all; pattern_mode=auto; paths=['.']; "
                "max_depth null means no limit; include_hidden=false; gitignore=true."
            ),
            behavior=(
                "Workspace-relative paths only; type filter applied; "
                "include_hidden enables --hidden; gitignore=false maps to --no-ignore; "
                "auto chooses regex/glob/fixed based on pattern syntax."
            ),
            outputs=(
                "matches plus page + coverage; auto includes effective_pattern_mode."
            ),
            errors=(
                "invalid_input for bad payload/paths/patterns; tool_error for "
                "missing binary or command failure."
            ),
        )
    )


def describe_bat() -> str:
    """Return the model-facing bat description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Preview file contents with line numbers.",
            inputs='path; start_line (int or "end"); limit_lines; max_chars.',
            defaults="start_line defaults to 1; limits use schema defaults.",
            behavior=(
                "Workspace-relative path only; UTF-8 text only; "
                "bounded output; start_line is 1-based."
            ),
            outputs=(
                "path, lines[{line,text,text_truncated}], total_lines, page cursor."
            ),
            errors=(
                "invalid_input for bad payload/path/binary; "
                "tool_error for read failures."
            ),
        )
    )


def describe_tree() -> str:
    """Return the model-facing tree description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Render a directory tree with nodes.",
            inputs=(
                "path; depth; pattern_glob; match_dirs; include_hidden; "
                "dirs_only; gitignore; offset; limit."
            ),
            defaults=(
                "path defaults to '.'; depth and flags use schema defaults; "
                "paging uses schema defaults."
            ),
            behavior=(
                "Workspace-relative path only; bounded traversal depth; "
                "pattern_glob filters names; nodes are the output."
            ),
            outputs="root, nodes list, stats counts, and page cursor.",
            errors=(
                "invalid_input for bad payload/paths; "
                "tool_error for execution failures."
            ),
        )
    )


def describe_stat() -> str:
    """Return the model-facing stat description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Return file and directory metadata (size, mtime, lines).",
            inputs="paths; include_lines.",
            defaults="include_lines defaults to true.",
            behavior=(
                "Workspace-relative paths only; directories include totals; "
                "invalid or unreadable paths become per-path ok=false rows."
            ),
            outputs=(
                "results[{path, ok, type, bytes?, lines?, modified?, mode?, "
                "binary?, error?}]."
            ),
            errors=(
                "invalid_input for malformed payload; path failures are per-path "
                "error rows in results."
            ),
        )
    )


def describe_shell() -> str:
    """Return the model-facing shell description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Run shell commands locally (approval required).",
            inputs=(
                "commands (required), approval_label, cwd, env, "
                "timeout_ms, max_output_chars."
            ),
            defaults=(
                "cwd defaults to workspace root; env defaults to null; "
                "timeout_ms null uses config."
            ),
            behavior=(
                "cwd must be workspace-relative and resolve inside the workspace; "
                "commands run sequentially and always report per-command outcomes; "
                "avoid file edits (use apply_patch)."
            ),
            outputs=(
                "cwd_resolved, cwd_abs, summary{commands,ok,failed,timed_out,skipped}, "
                "stopped_early, responses[{index,op,status,result,error?,truncated,"
                "limit_reason}]."
            ),
            errors=(
                "invalid_input/tool_error for malformed payload or executor failures; "
                "command failures are per-item status=error entries in responses."
            ),
        )
    )


def describe_apply_patch() -> str:
    """Return the model-facing apply_patch description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Edit workspace files with structured patches (approval required).",
            inputs=(
                "approval_label, operations[]. "
                "operations items are one of: "
                "create_file{path,if_exists,content}, "
                "update_file{path,diff,diff_format,if_missing}, "
                "delete_path{path,target_type,recursive,missing_ok}."
            ),
            defaults="operations execute in-order with per-operation outcomes.",
            behavior=(
                "Absolute and ~ paths are rejected; operations execute in order; "
                "operations always continue and report per-operation outcomes."
            ),
            outputs=(
                "summary{requested,ok,error,skipped,changed} and "
                "responses[{index,op,status,result,error?,truncated,limit_reason}]."
            ),
            errors=(
                "tool-level malformed payloads return invalid_input; per-operation "
                "errors in responses use conflict|invalid_input|policy_denied|"
                "internal_error with reason details."
            ),
        )
    )


def describe_inspect() -> str:
    """Return the model-facing inspect description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Run batched read-only inspection operations.",
            inputs=(
                "requests[] only. "
                "Each requests[] item is op-keyed and contains operation fields at "
                "top level (no nested args). request_id is required as string|null "
                "and echoed back "
                "per response item."
            ),
            defaults=(
                "max batch size/concurrency are bounded by tools.inspect config."
            ),
            behavior=(
                "Output order matches input order; each operation yields one result "
                "entry; invalid request entries become per-item status=error; output "
                "is clamped with stable truncation markers."
            ),
            outputs=(
                "responses[{index,op,request_id,status,result,error?,truncated,"
                "limit_reason}] plus summary{requested,ok,error,skipped}."
            ),
            errors="invalid_input for bad payload or too many operations.",
        )
    )


def describe_plan() -> str:
    """Return the model-facing plan description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Manage a structured task plan with incremental ops.",
            inputs=(
                "Flat payload with op and nullable per-op fields: "
                "get; set{steps,explanation}; "
                "add{step_id,step,status,placement}; "
                "update{step_id,patch}; "
                "delete{step_id}; "
                "advance{completed_step_id,next_step_id}; "
                "reset{mode}. "
                "placement object: {mode,anchor_step_id|null}. "
                "patch object: {kind,step|null,status|null}."
            ),
            defaults=(
                "Non-applicable fields must be null; "
                "step_id may be null to auto-assign; explanation may be null; "
                "append/prepend require placement.anchor_step_id=null; "
                "before/after require non-null placement.anchor_step_id; "
                "patch.kind controls which patch fields are non-null; "
                "reset.mode supports delete or empty."
            ),
            behavior=(
                "Requires active session/branch; set replaces the full plan; "
                "op selects get/set/add/update/delete/advance/reset; "
                "advance atomically completes one step and starts another; "
                "enforces <=1 in_progress step."
            ),
            outputs=(
                "plan_state, steps[{step_id, step, status}], explanation, revision, "
                "plan_created_at, plan_updated_at."
            ),
            errors=(
                "invalid_input for validation issues (field/reason with optional "
                "hints/conflict details); tool_error on storage failure."
            ),
        )
    )


def describe_agent_run() -> str:
    """Return the model-facing agent_run description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose=(
                "Delegate a focused subtask to a bounded sub-agent and persist "
                "its report."
            ),
            inputs=(
                "Flat payload: op + nullable mode fields. "
                "op=run requires model/instructions/input. "
                "op=discover_models takes no extra fields."
            ),
            defaults=(
                "Delegate bundle comes from config; run uses configured max_turns; "
                "discover_models performs no provider run."
            ),
            behavior=(
                "Input-only delegation (no session continuity). Returns a compact "
                "summary + report_id and stores the full report artifact. "
                "Preflight validates model id shape, policy allowlists, and route "
                "compatibility before provider calls. discover_models returns the "
                "live delegated-model catalog."
            ),
            outputs=(
                "run mode: ok, op, summary, summary_truncated, report_id, "
                "response_id, tool_counts, report_truncated, warnings; "
                "discover_models mode: ok, op, supported_prefixes, known_routes, "
                "suggested_models, openai policy, gateway_routes."
            ),
            errors=(
                "invalid_input for payload/model preflight failures "
                "(typed reason/field plus model catalog hints); "
                "tool_error for delegated run failures."
            ),
        )
    )


def describe_agent_run_report() -> str:
    """Return the model-facing agent_run_report description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Fetch a stored agent_run report by report_id.",
            inputs=(
                "Flat payload: report_id (required), mode (summary|full|forensic|null)."
            ),
            defaults="mode=null defaults to summary.",
            behavior=(
                "Loads report from the local store; report_id comes from agent_run. "
                "summary/full return sanitized payloads (no encrypted reasoning tokens "
                "or provider_data). forensic returns raw payload. "
                "output is bounded by tools.max_chars."
            ),
            outputs=(
                "report_id, mode, and report payload (summary by default, "
                "sanitized full on mode=full, raw on mode=forensic)."
            ),
            errors=(
                "invalid_input for bad payload; not_found when missing; "
                "tool_error on load."
            ),
        )
    )


def describe_steward() -> str:
    """Return the model-facing steward description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Create a compression continuation (snapshot or compaction).",
            inputs=(
                "Flat payload: op plus nullable model/turn_range/instructions. "
                "snapshot accepts model/turn_range and requires instructions=null. "
                "compaction accepts model/instructions and requires turn_range=null."
            ),
            defaults="optional fields use configured defaults.",
            behavior=(
                "Requires active session; op explicitly selects snapshot or compaction."
            ),
            outputs=(
                "task_id, op, session_id, branch_id, snapshot_branch_id, "
                "response_id, status, next_action."
            ),
            errors="invalid_input for bad payload; tool_error for execution failures.",
        )
    )


def describe_info() -> str:
    """Return the model-facing info description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Summarize runtime context without shell access.",
            inputs=(
                "Flat payload: mode selector + sections nullable. "
                "mode: discover | default | all | custom. "
                "custom mode requires sections: [clock, workspace, session, "
                "runtime, tools, binaries, config, trace, branch, compression]."
            ),
            defaults="mode defaults are explicit: choose default or all directly.",
            behavior=(
                "Returns only requested sections; missing sections are listed in "
                "unavailable (for example, branch when the local store is absent)."
            ),
            outputs=(
                "mode, sections map, unavailable list; discovery also returns "
                "allowed_sections and inspect tool limits."
            ),
            errors="invalid_input for bad payload or invalid section selection.",
        )
    )


def describe_read_bytes() -> str:
    """Return the model-facing read_bytes description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Read binary file bytes with base64 encoding.",
            inputs="path, offset, max_bytes.",
            defaults="offset defaults to 0; max_bytes defaults to 32768.",
            behavior=(
                "Workspace-relative file paths only; bounded byte reads with "
                "cursor-style paging."
            ),
            outputs=(
                "path, offset, bytes_read, total_bytes, encoding, data_base64, "
                "page{kind,cursor,limit,returned,has_more,next_cursor,complete,"
                "limit_reason}."
            ),
            errors="invalid_input for bad payload/path; tool_error for read failures.",
        )
    )


__all__ = (
    "ToolDescriptionParts",
    "describe_agent_run",
    "describe_agent_run_report",
    "describe_apply_patch",
    "describe_bat",
    "describe_fd",
    "describe_info",
    "describe_inspect",
    "describe_plan",
    "describe_read_bytes",
    "describe_rg",
    "describe_shell",
    "describe_stat",
    "describe_steward",
    "describe_tree",
    "render_tool_description",
)
