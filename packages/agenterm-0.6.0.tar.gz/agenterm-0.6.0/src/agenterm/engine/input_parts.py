"""Attachment resolver for prompt + file/URL inputs."""

from __future__ import annotations

import base64
import binascii
import mimetypes
from pathlib import Path
from typing import TYPE_CHECKING, Literal
from urllib.parse import urlparse

from agenterm.core.errors import ConfigError, FilesystemError, ValidationError
from agenterm.core.gateway_client import get_gateway_client
from agenterm.core.model_id import model_plane
from agenterm.core.openai_client import get_openai_client
from agenterm.engine.model_provider import gateway_route_for_model
from agenterm.engine.provider_capabilities import resolve_provider_capabilities

if TYPE_CHECKING:
    from collections.abc import Sequence

    from openai.types.responses.response_input_file_param import ResponseInputFileParam
    from openai.types.responses.response_input_image_param import (
        ResponseInputImageParam,
    )
    from openai.types.responses.response_input_text_param import ResponseInputTextParam

    from agenterm.config.model import AppConfig

type AttachmentKind = Literal["image", "pdf", "text", "file"]
type AttachmentPart = (
    ResponseInputTextParam | ResponseInputImageParam | ResponseInputFileParam
)

_TEXT_EXTS = {
    ".txt",
    ".md",
    ".markdown",
    ".json",
    ".yaml",
    ".yml",
    ".ini",
    ".cfg",
    ".toml",
    ".csv",
    ".tsv",
    ".py",
}

_IMAGE_EXTS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".webp",
    ".gif",
    ".bmp",
}


def _guess_mime(path: Path) -> str:
    mt, _ = mimetypes.guess_type(str(path))
    return mt or "application/octet-stream"


def _read_bytes(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except OSError as exc:
        msg = f"Failed to read attachment {path}: {exc}"
        raise FilesystemError(msg) from exc


def _read_text(path: Path, *, max_bytes: int | None) -> str:
    raw = _read_bytes(path)
    if max_bytes is not None and len(raw) > max_bytes:
        msg = (
            f"Text attachment too large ({len(raw)} bytes > {max_bytes}); "
            "convert to PDF or reduce size."
        )
        raise ValidationError(msg)
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        msg = f"Attachment is not valid UTF-8 text: {path.name}"
        raise ValidationError(msg) from exc


def _is_http_url(raw: str) -> bool:
    pr = urlparse(str(raw))
    return pr.scheme in ("http", "https") and bool(pr.netloc)


def _is_data_url(raw: str) -> bool:
    text = str(raw).strip()
    return text.startswith("data:") and "base64," in text


def _split_data_url(raw: str) -> tuple[str, str]:
    text = str(raw).strip()
    if not text.startswith("data:") or "base64," not in text:
        msg = "Attachment data URL must be base64-encoded."
        raise ValidationError(msg)
    header, b64 = text.split("base64,", 1)
    mime = header[5:].split(";", 1)[0]
    if not mime:
        mime = "application/octet-stream"
    return mime, b64


def _decode_b64(raw: str) -> bytes:
    normalized = "".join(str(raw).split())
    if not normalized:
        msg = "Inline data URL payload is empty."
        raise ValidationError(msg)
    try:
        return base64.b64decode(normalized, validate=True)
    except (ValueError, binascii.Error):
        pass
    padded = normalized + ("=" * (-len(normalized) % 4))
    try:
        return base64.b64decode(padded, validate=True)
    except (ValueError, binascii.Error):
        pass
    try:
        return base64.urlsafe_b64decode(padded)
    except (ValueError, binascii.Error) as exc:
        msg = "Inline data URL payload is not valid base64."
        raise ValidationError(msg) from exc


def _data_url(mime: str, data: bytes) -> str:
    b64 = base64.b64encode(data).decode("ascii")
    return f"data:{mime};base64,{b64}"


def _resolve_local_attachment_path(raw: str) -> Path:
    return Path(raw).expanduser().resolve()


def _attachment_kind_for_path(path: Path, mime: str) -> AttachmentKind | None:
    suffix = path.suffix.lower()
    if mime.startswith("image/") or suffix in _IMAGE_EXTS:
        return "image"
    if mime == "application/pdf" or suffix == ".pdf":
        return "pdf"
    if mime.startswith("text/") or suffix in _TEXT_EXTS:
        return "text"
    return None


def _attachment_kind_for_url(raw: str) -> AttachmentKind:
    suffix = Path(urlparse(str(raw)).path).suffix.lower()
    if suffix in _IMAGE_EXTS:
        return "image"
    if suffix == ".pdf":
        return "pdf"
    return "file"


def _inline_policy(
    cfg: AppConfig,
    *,
    allow_inline_data_url: bool,
) -> int:
    if not allow_inline_data_url:
        msg = (
            "Inline data URLs are disabled. Provide a URL, enable file_id upload, "
            "or set attachments.allow_inline_data_url=true."
        )
        raise ValidationError(msg)
    if cfg.attachments.image_input_mode != "allow_inline_data_url":
        msg = (
            "attachments.image_input_mode must be allow_inline_data_url "
            "to use inline data."
        )
        raise ValidationError(msg)
    max_bytes = cfg.attachments.max_inline_bytes
    if max_bytes <= 0:
        msg = (
            "attachments.max_inline_bytes must be > 0 when inline data URLs are allowed"
        )
        raise ConfigError(msg)
    return max_bytes


def _inline_data_url_for_path(
    *,
    path: Path,
    mime: str,
    max_bytes: int,
) -> str:
    size = path.stat().st_size
    if size > max_bytes:
        msg = (
            f"Inline attachment too large ({size} bytes > {max_bytes}); "
            "use a URL instead."
        )
        raise ValidationError(msg)
    data = _read_bytes(path)
    return _data_url(mime, data)


async def _upload_file(
    *,
    cfg: AppConfig,
    model_id: str,
    path: Path,
) -> str:
    plane = model_plane(model_id)
    if plane == "openai":
        client = get_openai_client()
    else:
        route_info = gateway_route_for_model(cfg.providers, model_id=model_id)
        if route_info is None:
            msg = f"Unknown gateway route for model id {model_id!r}"
            raise ConfigError(msg)
        route, route_cfg = route_info
        client = get_gateway_client(route=route, route_cfg=route_cfg)
    response = await client.files.create(file=path, purpose="user_data")
    file_id = response.id
    if not file_id:
        msg = "File upload did not return a file id."
        raise ConfigError(msg)
    return file_id


async def _part_from_data_url(
    *,
    cfg: AppConfig,
    raw: str,
    allow_inline_data_url: bool,
) -> AttachmentPart:
    mime, b64 = _split_data_url(raw)
    max_bytes = _inline_policy(cfg, allow_inline_data_url=allow_inline_data_url)
    data = _decode_b64(b64)
    if len(data) > max_bytes:
        msg = (
            f"Inline attachment too large ({len(data)} bytes > {max_bytes}); "
            "use a URL or file_id upload instead."
        )
        raise ValidationError(msg)
    if mime.startswith("image/"):
        return {"type": "input_image", "detail": "auto", "image_url": raw}
    if mime == "application/pdf":
        return {"type": "input_file", "file_data": raw, "filename": "attachment.pdf"}
    msg = f"Unsupported data URL mime type: {mime}"
    raise ValidationError(msg)


async def _part_from_url(
    *,
    model_id: str,
    raw: str,
    supports_image_url: bool,
) -> AttachmentPart:
    kind = _attachment_kind_for_url(raw)
    if kind == "image":
        if not supports_image_url:
            msg = "image_url inputs are not supported by the active provider route."
            raise ValidationError(msg)
        return {"type": "input_image", "detail": "auto", "image_url": str(raw)}
    if model_plane(model_id) == "gateway":
        msg = "Gateway routes require inline file_data for non-image URLs."
        raise ValidationError(msg)
    filename = Path(urlparse(str(raw)).path).name or None
    payload: ResponseInputFileParam = {"type": "input_file", "file_url": str(raw)}
    if filename:
        payload["filename"] = filename
    return payload


async def _local_image_part(
    *,
    cfg: AppConfig,
    model_id: str,
    path: Path,
    mime: str,
    supports_file_id: bool,
    supports_image_url: bool,
    allow_inline_data_url: bool,
) -> AttachmentPart:
    if model_plane(model_id) == "gateway":
        max_bytes = _inline_policy(cfg, allow_inline_data_url=allow_inline_data_url)
        return {
            "type": "input_image",
            "detail": "auto",
            "image_url": _inline_data_url_for_path(
                path=path,
                mime=mime,
                max_bytes=max_bytes,
            ),
        }
    if supports_file_id:
        file_id = await _upload_file(cfg=cfg, model_id=model_id, path=path)
        return {"type": "input_image", "detail": "auto", "file_id": file_id}
    if not supports_image_url:
        msg = "image_url inputs are not supported by the active provider route."
        raise ValidationError(msg)
    max_bytes = _inline_policy(cfg, allow_inline_data_url=allow_inline_data_url)
    return {
        "type": "input_image",
        "detail": "auto",
        "image_url": _inline_data_url_for_path(
            path=path,
            mime=mime,
            max_bytes=max_bytes,
        ),
    }


async def _local_pdf_part(
    *,
    cfg: AppConfig,
    model_id: str,
    path: Path,
    supports_file_id: bool,
    allow_inline_data_url: bool,
) -> AttachmentPart:
    filename = path.name
    if model_plane(model_id) == "gateway":
        max_bytes = _inline_policy(cfg, allow_inline_data_url=allow_inline_data_url)
        return {
            "type": "input_file",
            "file_data": _inline_data_url_for_path(
                path=path,
                mime="application/pdf",
                max_bytes=max_bytes,
            ),
            "filename": filename,
        }
    if supports_file_id:
        file_id = await _upload_file(cfg=cfg, model_id=model_id, path=path)
        return {
            "type": "input_file",
            "file_id": file_id,
            "filename": filename,
        }
    max_bytes = _inline_policy(cfg, allow_inline_data_url=allow_inline_data_url)
    return {
        "type": "input_file",
        "file_data": _inline_data_url_for_path(
            path=path,
            mime="application/pdf",
            max_bytes=max_bytes,
        ),
        "filename": filename,
    }


async def _part_from_local_path(
    *,
    cfg: AppConfig,
    model_id: str,
    raw: str,
    max_text_bytes: int | None,
    supports_file_id: bool,
    supports_image_url: bool,
    allow_inline_data_url: bool,
) -> AttachmentPart:
    path = _resolve_local_attachment_path(raw)
    if not path.is_file():
        msg = f"Attachment not a file: {raw}"
        raise FilesystemError(msg)
    mime = _guess_mime(path)
    kind = _attachment_kind_for_path(path, mime)
    if kind == "text":
        return {
            "type": "input_text",
            "text": _read_text(path, max_bytes=max_text_bytes),
        }
    if kind == "image":
        return await _local_image_part(
            cfg=cfg,
            model_id=model_id,
            path=path,
            mime=mime,
            supports_file_id=supports_file_id,
            supports_image_url=supports_image_url,
            allow_inline_data_url=allow_inline_data_url,
        )
    if kind == "pdf":
        return await _local_pdf_part(
            cfg=cfg,
            model_id=model_id,
            path=path,
            supports_file_id=supports_file_id,
            allow_inline_data_url=allow_inline_data_url,
        )
    allowed = "pdf, text, or image"
    msg = (
        f"Unsupported attachment type: {path.name} ({mime or 'unknown'}). "
        f"Convert to {allowed} before sending."
    )
    raise ValidationError(msg)


async def build_attachment_parts(
    cfg: AppConfig,
    *,
    model_id: str,
    attachments: Sequence[str],
    max_text_bytes: int | None = None,
) -> list[AttachmentPart]:
    """Resolve attachment strings into Responses input content parts."""
    caps = resolve_provider_capabilities(cfg, model_id=model_id)
    supports_file_id = (
        bool(caps.supports_file_id) and model_plane(model_id) != "gateway"
    )
    supports_image_url = bool(caps.supports_image_url)
    allow_inline_data_url = bool(caps.allow_inline_data_url) and bool(
        cfg.attachments.allow_inline_data_url
    )

    out: list[AttachmentPart] = []
    for raw in attachments:
        if _is_data_url(raw):
            out.append(
                await _part_from_data_url(
                    cfg=cfg,
                    raw=str(raw),
                    allow_inline_data_url=allow_inline_data_url,
                )
            )
            continue
        if _is_http_url(raw):
            out.append(
                await _part_from_url(
                    model_id=model_id,
                    raw=str(raw),
                    supports_image_url=supports_image_url,
                )
            )
            continue
        out.append(
            await _part_from_local_path(
                cfg=cfg,
                model_id=model_id,
                raw=str(raw),
                max_text_bytes=max_text_bytes,
                supports_file_id=supports_file_id,
                supports_image_url=supports_image_url,
                allow_inline_data_url=allow_inline_data_url,
            )
        )
    return out


__all__ = ("build_attachment_parts",)
