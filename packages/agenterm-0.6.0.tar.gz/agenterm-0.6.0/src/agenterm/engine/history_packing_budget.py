"""Budget and trimming helpers for history packing.

This module exists to keep the main history packing pipeline small and focused.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from agenterm.core.errors import AgentermError, ConfigError
from agenterm.core.model_id import model_plane
from agenterm.engine.history_packing_helpers import (
    PackedItem,
    flatten_turns,
    instructions_size,
    items_size,
    trim_by_chars,
)
from agenterm.engine.history_packing_io import count_openai_tokens, parse_packed_items

if TYPE_CHECKING:
    from agenterm.engine.history_packing_helpers import PackingBudget


async def _trim_by_openai_tokens(
    *,
    model_id: str,
    combined: list[PackedItem],
    prefix: list[PackedItem],
    remaining_turns: list[list[PackedItem]],
    new_items: list[PackedItem],
    instructions: str | None,
    budget_tokens: int,
) -> tuple[Literal["ok", "failed", "over"], list[PackedItem]]:
    token_count = await count_openai_tokens(
        model_id=model_id,
        input_items=parse_packed_items(
            combined,
            context="history_packing.openai_input",
        ),
        instructions=instructions,
    )
    if token_count is None:
        return "failed", combined
    while token_count > budget_tokens:
        if not remaining_turns:
            return "over", combined
        remaining_turns = remaining_turns[1:]
        combined = [*prefix, *flatten_turns(remaining_turns), *new_items]
        token_count = await count_openai_tokens(
            model_id=model_id,
            input_items=parse_packed_items(
                combined,
                context="history_packing.openai_input",
            ),
            instructions=instructions,
        )
        if token_count is None:
            return "failed", combined
    return "ok", combined


def budget_error_message(
    *,
    model_id: str,
    budget: PackingBudget,
    size_chars: int,
    size_tokens: int | None,
    compress_error: AgentermError | None,
) -> str:
    """Format a stable, actionable error message for budget overflows.

    The message is intended for user-facing surfaced errors (no tracebacks) and
    may include a secondary compression failure if packing itself errored.
    """
    token_clause = f", size_tokens={size_tokens}" if size_tokens is not None else ""
    msg = (
        "Packed history exceeds input budget "
        f"(model={model_id!r}, budget_tokens={budget.input_tokens}, "
        f"budget_chars={budget.input_chars}, size_chars={size_chars}{token_clause})."
    )
    if compress_error is not None:
        msg = f"{msg} Compression failed: {compress_error}"
    return msg


async def drop_to_fit(
    *,
    model_id: str,
    prefix: list[PackedItem],
    turns: list[list[PackedItem]],
    new_items: list[PackedItem],
    instructions: str | None,
    budget: PackingBudget,
) -> list[PackedItem]:
    """Drop oldest turns until the packed history fits the configured budget."""
    combined, remaining_turns = trim_by_chars(
        prefix=prefix,
        turns=turns,
        new_items=new_items,
        budget_chars=budget.input_chars,
        instructions=instructions,
    )
    plane = model_plane(model_id)
    if plane == "openai":
        status, combined = await _trim_by_openai_tokens(
            model_id=model_id,
            combined=combined,
            prefix=prefix,
            remaining_turns=remaining_turns,
            new_items=new_items,
            instructions=instructions,
            budget_tokens=budget.input_tokens,
        )
        if status == "ok":
            return combined
        if status == "over":
            current_chars = items_size(combined) + instructions_size(instructions)
            msg = budget_error_message(
                model_id=model_id,
                budget=budget,
                size_chars=current_chars,
                size_tokens=None,
                compress_error=None,
            )
            raise ConfigError(msg)
        return combined
    return combined


__all__ = ("budget_error_message", "drop_to_fit")
