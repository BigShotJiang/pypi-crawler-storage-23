"""Sanitize agent_run report payloads for model-facing output."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class AgentRunReportSanitizationStats:
    """Metrics describing how a report payload was sanitized."""

    provider_data_stripped: int = 0
    encrypted_reasoning_stripped: int = 0
    reasoning_items: int = 0
    reasoning_with_summary: int = 0
    reasoning_with_content: int = 0

    def to_mapping(self) -> dict[str, int]:
        """Return a JSON-safe mapping."""
        return {
            "provider_data_stripped": self.provider_data_stripped,
            "encrypted_reasoning_stripped": self.encrypted_reasoning_stripped,
            "reasoning_items": self.reasoning_items,
            "reasoning_with_summary": self.reasoning_with_summary,
            "reasoning_with_content": self.reasoning_with_content,
        }


@dataclass(frozen=True)
class _SanitizeCounter:
    provider_data_stripped: int = 0
    encrypted_reasoning_stripped: int = 0
    reasoning_items: int = 0
    reasoning_with_summary: int = 0
    reasoning_with_content: int = 0

    def with_provider_data(self) -> _SanitizeCounter:
        return replace(
            self,
            provider_data_stripped=self.provider_data_stripped + 1,
        )

    def with_encrypted_reasoning(self) -> _SanitizeCounter:
        return replace(
            self,
            encrypted_reasoning_stripped=self.encrypted_reasoning_stripped + 1,
        )

    def with_reasoning_item(
        self,
        *,
        has_summary: bool,
        has_content: bool,
    ) -> _SanitizeCounter:
        return replace(
            self,
            reasoning_items=self.reasoning_items + 1,
            reasoning_with_summary=(
                self.reasoning_with_summary + 1
                if has_summary
                else self.reasoning_with_summary
            ),
            reasoning_with_content=(
                self.reasoning_with_content + 1
                if has_content
                else self.reasoning_with_content
            ),
        )

    def as_stats(self) -> AgentRunReportSanitizationStats:
        return AgentRunReportSanitizationStats(
            provider_data_stripped=self.provider_data_stripped,
            encrypted_reasoning_stripped=self.encrypted_reasoning_stripped,
            reasoning_items=self.reasoning_items,
            reasoning_with_summary=self.reasoning_with_summary,
            reasoning_with_content=self.reasoning_with_content,
        )


def _sanitize_json_value(
    value: JSONValue,
    *,
    strip_encrypted_reasoning: bool,
    counter: _SanitizeCounter,
) -> tuple[JSONValue, _SanitizeCounter]:
    if isinstance(value, dict):
        return _sanitize_json_object(
            value,
            strip_encrypted_reasoning=strip_encrypted_reasoning,
            counter=counter,
        )
    if isinstance(value, list):
        return _sanitize_json_list(
            value,
            strip_encrypted_reasoning=strip_encrypted_reasoning,
            counter=counter,
        )
    return value, counter


def _sanitize_json_list(
    values: list[JSONValue],
    *,
    strip_encrypted_reasoning: bool,
    counter: _SanitizeCounter,
) -> tuple[list[JSONValue], _SanitizeCounter]:
    sanitized: list[JSONValue] = []
    counter_current = counter
    for value in values:
        next_value, counter_current = _sanitize_json_value(
            value,
            strip_encrypted_reasoning=strip_encrypted_reasoning,
            counter=counter_current,
        )
        sanitized.append(next_value)
    return sanitized, counter_current


def _sanitize_json_object(
    value: Mapping[str, JSONValue],
    *,
    strip_encrypted_reasoning: bool,
    counter: _SanitizeCounter,
) -> tuple[dict[str, JSONValue], _SanitizeCounter]:
    sanitized: dict[str, JSONValue] = {}
    counter_current = counter
    for key, raw in value.items():
        if key == "provider_data":
            counter_current = counter_current.with_provider_data()
            continue
        if key == "encrypted_content" and strip_encrypted_reasoning:
            counter_current = counter_current.with_encrypted_reasoning()
            continue
        next_value, counter_current = _sanitize_json_value(
            raw,
            strip_encrypted_reasoning=strip_encrypted_reasoning,
            counter=counter_current,
        )
        sanitized[key] = next_value
    return sanitized, counter_current


def _sanitize_item(
    item: Mapping[str, JSONValue],
    *,
    counter: _SanitizeCounter,
) -> tuple[dict[str, JSONValue], _SanitizeCounter]:
    item_type = item.get("type")
    is_reasoning = isinstance(item_type, str) and item_type == "reasoning"
    summary = item.get("summary")
    content = item.get("content")
    summary_items = summary if isinstance(summary, list) else None
    content_items = content if isinstance(content, list) else None
    has_summary = summary_items is not None and len(summary_items) > 0
    has_content = content_items is not None and len(content_items) > 0
    counter_current = counter
    if is_reasoning:
        counter_current = counter_current.with_reasoning_item(
            has_summary=has_summary,
            has_content=has_content,
        )
    return _sanitize_json_object(
        item,
        strip_encrypted_reasoning=is_reasoning,
        counter=counter_current,
    )


def _sanitize_items(
    raw_items: JSONValue,
    *,
    counter: _SanitizeCounter,
) -> tuple[JSONValue, _SanitizeCounter]:
    if not isinstance(raw_items, list):
        return raw_items, counter
    items: list[JSONValue] = []
    counter_current = counter
    for raw in raw_items:
        if isinstance(raw, dict):
            item, counter_current = _sanitize_item(raw, counter=counter_current)
            items.append(item)
            continue
        next_value, counter_current = _sanitize_json_value(
            raw,
            strip_encrypted_reasoning=False,
            counter=counter_current,
        )
        items.append(next_value)
    return items, counter_current


def sanitize_agent_run_report(
    report: Mapping[str, JSONValue],
) -> tuple[dict[str, JSONValue], AgentRunReportSanitizationStats]:
    """Strip model-useless encrypted/provider-specific fields from report payload."""
    sanitized = dict(report)
    counter = _SanitizeCounter()
    for key in ("input_items", "output_items"):
        cleaned, counter = _sanitize_items(sanitized.get(key), counter=counter)
        sanitized[key] = cleaned
    return sanitized, counter.as_stats()


__all__ = ("AgentRunReportSanitizationStats", "sanitize_agent_run_report")
