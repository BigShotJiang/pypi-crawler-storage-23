"""Portable FunctionTool wrapper for canonical apply_patch operations."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.core.errors import AgentermError
from agenterm.core.tool_output_envelope import ToolOutputEnvelope, ToolOutputError
from agenterm.engine.apply_patch_contract import (
    APPLY_PATCH_SCHEMA,
    CreateFileOp,
    DeletePathOp,
    PatchOp,
    parse_apply_patch_payload,
    patch_op_name,
)
from agenterm.engine.apply_patch_executor import (
    INTERNAL_ERROR_KIND,
    INVALID_INPUT_KIND,
    OperationExecution,
    execute_create_file,
    execute_delete_path,
    execute_update_file,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_contracts import batch_response, summarize_batch
from agenterm.engine.tool_descriptions import describe_apply_patch

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

    from agents.tool_context import ToolContext

    from agenterm.config.tool_models import ApplyPatchToolConfig
    from agenterm.core.approvals import PatchApprovalManager
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext


def _error_output(
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    envelope = ToolOutputEnvelope(
        tool="apply_patch",
        ok=False,
        result={},
        error=ToolOutputError(
            kind=kind,
            message=message,
            details=dict(details) if details is not None else {},
        ),
    )
    return envelope.to_json_string()


async def _execute_operation(
    *,
    op: PatchOp,
    workspace_root: Path,
    approvals: PatchApprovalManager,
    approval_label: str | None,
    cancel_token: CancelToken | None,
) -> OperationExecution:
    if isinstance(op, CreateFileOp):
        return await execute_create_file(
            op,
            workspace_root=workspace_root,
            approvals=approvals,
            approval_label=approval_label,
            cancel_token=cancel_token,
        )
    if isinstance(op, DeletePathOp):
        return await execute_delete_path(
            op,
            workspace_root=workspace_root,
            approvals=approvals,
            approval_label=approval_label,
            cancel_token=cancel_token,
        )
    return await execute_update_file(
        op,
        workspace_root=workspace_root,
        approvals=approvals,
        approval_label=approval_label,
        cancel_token=cancel_token,
    )


async def _invoke_apply_patch(
    *,
    workspace_root: Path,
    approvals: PatchApprovalManager,
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
) -> str:
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    parsed = parse_apply_patch_payload(raw)
    if parsed is None:
        return _error_output(
            kind=INVALID_INPUT_KIND,
            message="Invalid apply_patch payload.",
            details={"field": "/payload", "reason": "invalid_payload"},
        )

    responses: list[dict[str, JSONValue]] = []
    for index, op in enumerate(parsed.operations):
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        op_name = patch_op_name(op)
        execution = await _execute_operation(
            op=op,
            workspace_root=workspace_root,
            approvals=approvals,
            approval_label=parsed.approval_label,
            cancel_token=cancel_token,
        )
        responses.append(
            batch_response(
                index=index,
                op=op_name,
                status=execution.status,
                result=execution.result,
                error=execution.error,
            )
        )

    summary = summarize_batch(responses)
    changed = 0
    for entry in responses:
        result_value = entry.get("result")
        if isinstance(result_value, dict) and result_value.get("changed") is True:
            changed += 1
    responses_json: list[JSONValue] = []
    responses_json.extend(responses)
    payload: dict[str, JSONValue] = {
        "summary": {
            "requested": summary["requested"],
            "ok": summary["ok"],
            "error": summary["error"],
            "skipped": summary["skipped"],
            "changed": changed,
        },
        "responses": responses_json,
    }
    return ToolOutputEnvelope(
        tool="apply_patch",
        ok=True,
        result=payload,
    ).to_json_string()


def build_apply_patch_function_tool(
    cfg: ApplyPatchToolConfig | None,
    *,
    workspace_root: Path,
    approvals: PatchApprovalManager,
) -> FunctionTool | None:
    """Build a portable FunctionTool wrapper for apply_patch."""
    if cfg is None:
        return None
    validate_strict_schema("apply_patch", APPLY_PATCH_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        try:
            return await _invoke_apply_patch(
                workspace_root=workspace_root,
                approvals=approvals,
                ctx=ctx,
                raw=raw,
            )
        except AgentermError as exc:
            return _error_output(
                kind=INTERNAL_ERROR_KIND,
                message=str(exc),
                details={"reason": "apply_patch_error"},
            )

    return FunctionTool(
        name="apply_patch",
        description=describe_apply_patch(),
        params_json_schema=APPLY_PATCH_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_apply_patch_function_tool",)
