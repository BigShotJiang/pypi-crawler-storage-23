"""Expose local FunctionTools as an MCP server via FastMCP."""

from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path
from typing import TYPE_CHECKING

from mcp import types as mtypes
from mcp.server.fastmcp import FastMCP

from agenterm.core.errors import AgentermError, ConfigError
from agenterm.core.json_codec import require_json_value
from agenterm.engine.mcp_expose_state import (
    McpExposeState,
    agent_run_structured_output,
    build_mcp_expose_state,
    build_tool_context,
    error_call_tool_result,
    parse_output_envelope,
    tool_summary_text,
    wrap_raw_output,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Mapping, Sequence
    from contextlib import AbstractAsyncContextManager

    from agenterm.config.model import AppConfig
    from agenterm.core.json_types import JSONValue


def _error_response_from_envelope(
    env_json: Mapping[str, JSONValue],
) -> mtypes.CallToolResult:
    tool_name = env_json.get("tool")
    tool_label = tool_name if isinstance(tool_name, str) else "tool"
    return mtypes.CallToolResult(
        content=[
            mtypes.TextContent(
                type="text",
                text=f"{tool_label} error",
            )
        ],
        structuredContent=dict(env_json),
        isError=True,
    )


def _success_response_from_envelope(
    env_json: Mapping[str, JSONValue],
    *,
    summary: str,
) -> tuple[Sequence[mtypes.ContentBlock], dict[str, JSONValue]]:
    return [mtypes.TextContent(type="text", text=summary)], dict(env_json)


class McpExposeServer(FastMCP[McpExposeState]):
    """FastMCP server exposing local FunctionTools."""

    def __init__(self, cfg: AppConfig, *, workspace_root: Path) -> None:
        """Initialize the MCP exposure server."""
        self._cfg = cfg
        self._workspace_root = workspace_root
        self._state: McpExposeState | None = None
        super().__init__(
            name="agenterm",
            host=cfg.mcp.expose.host,
            port=cfg.mcp.expose.port,
            lifespan=self._lifespan,
        )

    def _setup_handlers(self) -> None:
        super()._setup_handlers()
        self._mcp_server.call_tool(validate_input=True)(self._call_tool_handler)

    def _lifespan(
        self,
        _app: FastMCP[McpExposeState],
    ) -> AbstractAsyncContextManager[McpExposeState]:
        """Build FastMCP lifespan context with tool selection state."""

        @asynccontextmanager
        async def _ctx() -> AsyncIterator[McpExposeState]:
            state = build_mcp_expose_state(
                self._cfg,
                workspace_root=self._workspace_root,
            )
            self._state = state
            try:
                yield state
            finally:
                self._state = None

        return _ctx()

    def _require_state(self) -> McpExposeState:
        if self._state is None:
            msg = "MCP expose server is not initialized"
            raise ConfigError(msg)
        return self._state

    async def list_tools(self) -> list[mtypes.Tool]:
        """List available MCP tools (FunctionTools only)."""
        state = self._require_state()
        return list(state.tool_defs)

    async def _invoke_tool(
        self,
        *,
        state: McpExposeState,
        name: str,
        arguments: Mapping[str, JSONValue],
    ) -> str | JSONValue | mtypes.CallToolResult:
        tool = state.tools.get(name)
        if tool is None:
            return error_call_tool_result(
                tool_name=name,
                message="Unknown tool",
                details={"reason": "unknown_tool", "field": "name"},
                kind="not_found",
            )
        tool_ctx, args_json = build_tool_context(
            state=state,
            name=name,
            arguments=arguments,
        )
        try:
            return await tool.on_invoke_tool(tool_ctx, args_json)
        except AgentermError as exc:
            return error_call_tool_result(
                tool_name=tool.name,
                message=str(exc),
                details={"reason": "tool_error"},
            )

    async def _handle_string_output(
        self,
        *,
        state: McpExposeState,
        tool_name: str,
        output: str,
    ) -> (
        Sequence[mtypes.ContentBlock]
        | dict[str, JSONValue]
        | tuple[Sequence[mtypes.ContentBlock], dict[str, JSONValue]]
        | mtypes.CallToolResult
    ):
        env = parse_output_envelope(tool_name=tool_name, output=output)
        env_json = env.to_json()
        if not env.ok:
            return _error_response_from_envelope(env_json)
        if env.tool == "agent_run":
            structured = await agent_run_structured_output(
                env,
                tool_context=state.tool_context,
            )
            if isinstance(structured, mtypes.CallToolResult):
                return structured
            return structured
        return _success_response_from_envelope(
            env_json,
            summary=tool_summary_text(env),
        )

    async def _call_tool_handler(
        self,
        name: str,
        arguments: Mapping[str, JSONValue],
        *,
        state: McpExposeState | None = None,
    ) -> (
        Sequence[mtypes.ContentBlock]
        | dict[str, JSONValue]
        | tuple[Sequence[mtypes.ContentBlock], dict[str, JSONValue]]
        | mtypes.CallToolResult
    ):
        """Invoke a FunctionTool and return MCP content blocks or structured output."""
        active_state = self._require_state() if state is None else state
        output = await self._invoke_tool(
            state=active_state,
            name=name,
            arguments=arguments,
        )
        if isinstance(output, mtypes.CallToolResult):
            return output
        if isinstance(output, str):
            return await self._handle_string_output(
                state=active_state,
                tool_name=name,
                output=output,
            )
        env = wrap_raw_output(
            tool_name=name,
            output=require_json_value(
                value=output,
                context=f"mcp.expose.output.{name}",
            ),
        )
        env_json = env.to_json()
        return _success_response_from_envelope(
            env_json,
            summary=tool_summary_text(env),
        )

    async def call_tool_with_state(
        self,
        name: str,
        arguments: Mapping[str, JSONValue],
        *,
        state: McpExposeState,
    ) -> (
        Sequence[mtypes.ContentBlock]
        | dict[str, JSONValue]
        | tuple[Sequence[mtypes.ContentBlock], dict[str, JSONValue]]
        | mtypes.CallToolResult
    ):
        """Invoke a FunctionTool with an explicit state (testing helper)."""
        return await self._call_tool_handler(name, arguments, state=state)


async def serve_mcp_expose(
    cfg: AppConfig,
    *,
    workspace_root: Path | None = None,
) -> None:
    """Run FastMCP server to expose local FunctionTools."""
    if not cfg.mcp.expose.enabled:
        message = "mcp.expose.enabled must be true to start the MCP server"
        raise ConfigError(message)
    root = workspace_root or Path.cwd()
    server = McpExposeServer(cfg, workspace_root=root)
    transport = cfg.mcp.expose.transport
    if transport == "stdio":
        await server.run_stdio_async()
    elif transport == "sse":
        await server.run_sse_async()
    else:
        await server.run_streamable_http_async()


__all__ = ("McpExposeServer", "build_mcp_expose_state", "serve_mcp_expose")
