"""Run-scoped branch switching tracker.

This module tracks when a run switches session head to a new branch (typically via
compression continuations) so run-scoped artifacts can be rebound onto the final
head branch at the end of the run.
"""

from __future__ import annotations

from dataclasses import dataclass

from agenterm.store.history import history_store
from agenterm.store.session.request_usage import current_branch_turn_number


@dataclass
class RunBranchTracker:
    """Track the active head branch and per-branch turn-base for a single run."""

    session_id: str
    origin_branch_id: str
    current_branch_id: str
    _branch_turn_base: dict[str, int | None]

    @classmethod
    def from_origin(
        cls,
        *,
        session_id: str,
        origin_branch_id: str,
        origin_branch_turn_base: int | None,
    ) -> RunBranchTracker:
        """Create a tracker for a run starting on origin_branch_id."""
        origin = origin_branch_id or "main"
        return cls(
            session_id=session_id,
            origin_branch_id=origin,
            current_branch_id=origin,
            _branch_turn_base={origin: origin_branch_turn_base},
        )

    def branch_turn_base(self, branch_id: str) -> int | None:
        """Return the recorded turn-base for a branch when available."""
        return self._branch_turn_base.get(branch_id)

    def switched(self) -> bool:
        """Return True when the run switched away from its origin branch."""
        return self.current_branch_id != self.origin_branch_id

    async def note_head_switch(self, *, branch_id: str) -> None:
        """Record a head-branch switch and capture the branch turn-base.

        The base is the current max(branch_turn_number) for the new head branch at
        the moment we observe the switch.
        """
        cleaned = branch_id or "main"
        if cleaned == self.current_branch_id:
            return
        base = await current_branch_turn_number(
            history_store(),
            self.session_id,
            branch_id=cleaned,
        )
        if cleaned not in self._branch_turn_base:
            self._branch_turn_base[cleaned] = base
        self.current_branch_id = cleaned


__all__ = ("RunBranchTracker",)
