"""History packing helpers for splitting and threshold calculations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.constants.limits import (
    CONTEXT_WINDOW_CHARS_PER_TOKEN,
    CONTEXT_WINDOW_DEFAULT_TOKENS,
)
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import json_size as json_size_json
from agenterm.core.json_types import JSONValue

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agenterm.config.model import AppConfig
    from agenterm.core.approvals import ApprovalsContext, CompressionApprovalAction
    from agenterm.core.cancellation import CancelToken
    from agenterm.engine.run_branch_tracker import RunBranchTracker
    from agenterm.steward.emitters import CompressionEmitters

type PackedItem = dict[str, JSONValue]


@dataclass(frozen=True)
class PackingBudget:
    """Resolved input budgets for history packing."""

    input_tokens: int
    input_chars: int


@dataclass(frozen=True)
class HistoryPackingOptions:
    """Interactive options for history packing decisions."""

    interactive: bool
    approvals: ApprovalsContext | None = None
    cancel_token: CancelToken | None = None
    emitters: CompressionEmitters | None = None
    run_number: int | None = None
    origin_branch_id: str | None = None
    branch_tracker: RunBranchTracker | None = None


@dataclass(frozen=True)
class CompressionThreshold:
    """Resolved compression threshold for a run."""

    percent: float
    reference_tokens: int
    threshold_tokens: int
    threshold_chars: int


def resolve_budget(cfg: AppConfig) -> PackingBudget:
    """Return the input budget (tokens/chars) for the configured model."""
    context_window = cfg.model.context_window or CONTEXT_WINDOW_DEFAULT_TOKENS
    if context_window <= 0:
        msg = "model.context_window must be a positive integer"
        raise ConfigError(msg)
    max_output = cfg.model.max_output_tokens
    if max_output is not None and max_output >= context_window:
        msg = "model.max_output_tokens must be less than model.context_window"
        raise ConfigError(msg)
    input_tokens = (
        context_window - max_output if max_output is not None else context_window
    )
    if input_tokens <= 0:
        msg = "Input token budget must be positive"
        raise ConfigError(msg)
    input_chars = int(input_tokens * CONTEXT_WINDOW_CHARS_PER_TOKEN)
    return PackingBudget(input_tokens=input_tokens, input_chars=input_chars)


def resolve_compression_threshold(
    cfg: AppConfig,
    *,
    budget: PackingBudget,
) -> CompressionThreshold:
    """Return the resolved compression threshold for a run."""
    reference_tokens = cfg.model.context_window or CONTEXT_WINDOW_DEFAULT_TOKENS
    percent = cfg.compression.threshold_percent
    threshold_tokens = int(reference_tokens * percent)
    if threshold_tokens <= 0:
        threshold_tokens = 1
    threshold_tokens = min(threshold_tokens, budget.input_tokens)
    threshold_chars = int(threshold_tokens * CONTEXT_WINDOW_CHARS_PER_TOKEN)
    return CompressionThreshold(
        percent=percent,
        reference_tokens=reference_tokens,
        threshold_tokens=threshold_tokens,
        threshold_chars=threshold_chars,
    )


def json_size(item: PackedItem) -> int:
    """Return serialized size for a single item."""
    try:
        return json_size_json(item, sort_keys=True)
    except (TypeError, ValueError) as exc:
        msg = f"History item could not be serialized for packing: {exc}"
        raise ConfigError(msg) from exc


def items_size(items: Sequence[PackedItem]) -> int:
    """Return total JSON size for input items."""
    return sum(json_size(item) for item in items)


def instructions_size(instructions: str | None) -> int:
    """Return size of instructions string."""
    return len(instructions) if isinstance(instructions, str) else 0


def packed_item_id(item: PackedItem) -> str | None:
    """Return the item id when available."""
    value = item.get("id")
    return value if isinstance(value, str) else None


def dedupe_packed_items(
    items: Sequence[PackedItem],
) -> list[PackedItem]:
    """Drop repeated item ids while preserving order of first occurrence."""
    out: list[PackedItem] = []
    seen_ids: set[str] = set()
    for item in items:
        item_id = packed_item_id(item)
        if isinstance(item_id, str):
            if item_id in seen_ids:
                continue
            seen_ids.add(item_id)
        out.append(item)
    return out


def dedupe_new_packed_items(
    history_items: Sequence[PackedItem],
    new_items: Sequence[PackedItem],
) -> list[PackedItem]:
    """Drop new items whose ids already exist in history."""
    seen_ids: set[str] = set()
    for item in history_items:
        item_id = packed_item_id(item)
        if isinstance(item_id, str):
            seen_ids.add(item_id)
    if not seen_ids:
        return list(new_items)
    deduped: list[PackedItem] = []
    for item in new_items:
        item_id = packed_item_id(item)
        if isinstance(item_id, str):
            if item_id in seen_ids:
                continue
            seen_ids.add(item_id)
        deduped.append(item)
    return deduped


def compress_prompt(
    *,
    mode: str,
    threshold: CompressionThreshold,
    token_count: int | None,
    char_count: int,
) -> str:
    """Build the prompt for compression approval."""
    percent = int(threshold.percent * 100)
    if token_count is not None:
        return (
            "Compress history? "
            f"input_tokens={token_count} "
            f"threshold={threshold.threshold_tokens} "
            f"({percent}% of {threshold.reference_tokens}) "
            f"mode={mode}"
        )
    return (
        "Compress history? "
        f"input_chars≈{char_count} "
        f"threshold≈{threshold.threshold_chars} "
        f"(~{percent}% of {threshold.reference_tokens} tokens) "
        f"mode={mode}"
    )


def drop_prompt(
    *,
    budget: PackingBudget,
    token_count: int | None,
    char_count: int,
) -> str:
    """Build the prompt for drop approval."""
    if token_count is not None:
        return (
            "Drop oldest turns to fit budget? "
            f"input_tokens={token_count} budget={budget.input_tokens}"
        )
    return (
        "Drop oldest turns to fit budget? "
        f"input_chars≈{char_count} budget≈{budget.input_chars}"
    )


async def await_compression_approval(
    *,
    options: HistoryPackingOptions,
    action: CompressionApprovalAction,
    message: str,
) -> bool:
    """Await an approval decision for compression or drop."""
    if options.cancel_token is not None:
        options.cancel_token.raise_if_cancelled()
    if not options.interactive:
        return False
    approvals = options.approvals
    if approvals is None:
        return False
    item = approvals.compress.register(action=action, message=message)
    decision = await approvals.compress.wait(
        item.id,
        cancel_token=options.cancel_token,
    )
    return decision.approved


def flatten_turns(
    turns: Sequence[Sequence[PackedItem]],
) -> list[PackedItem]:
    """Flatten turn buckets into a single list."""
    out: list[PackedItem] = []
    for turn in turns:
        out.extend(turn)
    return out


def trim_by_chars(
    *,
    prefix: list[PackedItem],
    turns: list[list[PackedItem]],
    new_items: list[PackedItem],
    budget_chars: int,
    instructions: str | None,
) -> tuple[list[PackedItem], list[list[PackedItem]]]:
    """Drop turns until combined size fits the char budget."""
    prefix_size = items_size(prefix)
    new_size = items_size(new_items)
    turn_sizes = [items_size(turn) for turn in turns]
    total = prefix_size + new_size + instructions_size(instructions) + sum(turn_sizes)
    drop_idx = 0
    while drop_idx < len(turn_sizes) and total > budget_chars:
        total -= turn_sizes[drop_idx]
        drop_idx += 1
    remaining_turns = turns[drop_idx:]
    combined = [*prefix, *flatten_turns(remaining_turns), *new_items]
    return combined, remaining_turns


__all__ = (
    "CompressionThreshold",
    "HistoryPackingOptions",
    "PackingBudget",
    "await_compression_approval",
    "compress_prompt",
    "dedupe_packed_items",
    "drop_prompt",
    "flatten_turns",
    "instructions_size",
    "items_size",
    "json_size",
    "resolve_budget",
    "resolve_compression_threshold",
    "trim_by_chars",
)
