"""Delegate tool bundle resolution helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.tools_catalog import build_tool_catalog_from_config
from agenterm.core.errors import ConfigError
from agenterm.core.model_id import model_plane

if TYPE_CHECKING:
    from agenterm.config.model import AppConfig
    from agenterm.core.toolspec import ToolSpec


def delegate_bundle_specs(cfg: AppConfig, *, model_id: str) -> tuple[ToolSpec, ...]:
    """Return delegate bundle specs for agent_run (hosted tools only)."""
    if cfg.tools.agent_run is None:
        msg = "tools.agent_run must be enabled to resolve delegate bundles"
        raise ConfigError(msg)
    bundle_name = cfg.tools.agent_run.bundle
    tools_map, bundles_map, _defaults = build_tool_catalog_from_config(
        cfg,
        scope="delegate",
    )
    bundle_keys = bundles_map.get(bundle_name)
    if bundle_keys is None:
        msg = f"tools.agent_run.bundle '{bundle_name}' is not a delegate bundle"
        raise ConfigError(msg)
    plane = model_plane(model_id)
    specs: list[ToolSpec] = []
    invalid: list[str] = []
    for key in bundle_keys:
        spec = tools_map.get(key)
        if spec is None:
            invalid.append(str(key))
            continue
        if spec.plane != "hosted":
            invalid.append(str(key))
            continue
        if spec.dangerous:
            continue
        if plane == "gateway":
            continue
        specs.append(spec)
    if invalid:
        msg = (
            f"tools.bundles.{bundle_name} contains non-hosted tool keys: "
            f"{', '.join(invalid)}"
        )
        raise ConfigError(msg)
    return tuple(specs)


__all__ = ("delegate_bundle_specs",)
