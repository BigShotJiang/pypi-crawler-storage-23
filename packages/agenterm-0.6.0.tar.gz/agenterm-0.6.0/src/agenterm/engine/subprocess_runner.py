"""Cancel-aware subprocess execution helpers."""

from __future__ import annotations

import asyncio
import os
import signal
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.errors import OperationCancelledError, ToolExecutionError

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agenterm.core.cancellation import CancelToken


@dataclass(frozen=True)
class SubprocessResult:
    """Captured subprocess result with timeout metadata."""

    exit_code: int
    stdout: bytes
    stderr: bytes
    timed_out: bool


_CANCEL_JOIN_TIMEOUT_SECONDS = 2.0


def _use_process_group() -> bool:
    return os.name != "nt"


def _terminate_process_group(proc: asyncio.subprocess.Process) -> None:
    if proc.returncode is not None:
        return
    try:
        if _use_process_group():
            os.killpg(proc.pid, signal.SIGTERM)
        else:
            proc.terminate()
    except OSError:
        # Process signaling is best-effort; constrained runtimes may deny
        # killpg/terminate with EPERM. Tool callers must not fail on cleanup.
        return


def _kill_process_group(proc: asyncio.subprocess.Process) -> None:
    if proc.returncode is not None:
        return
    try:
        if _use_process_group():
            os.killpg(proc.pid, signal.SIGKILL)
        else:
            proc.kill()
    except OSError:
        # Process signaling is best-effort; constrained runtimes may deny
        # killpg/kill with EPERM. Tool callers must not fail on cleanup.
        return


async def _await_exit(proc: asyncio.subprocess.Process) -> None:
    if proc.returncode is not None:
        return
    try:
        async with asyncio.timeout(_CANCEL_JOIN_TIMEOUT_SECONDS):
            await proc.wait()
    except TimeoutError:
        return


async def spawn_subprocess(
    cmd: Sequence[str],
    *,
    cwd: str,
    env: Mapping[str, str] | None,
    stdout: int | None = asyncio.subprocess.PIPE,
    stderr: int | None = asyncio.subprocess.PIPE,
    cancel_token: CancelToken | None = None,
) -> asyncio.subprocess.Process:
    """Spawn a subprocess with optional cancellation checks."""
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=cwd,
            env=dict(env) if env is not None else None,
            stdout=stdout,
            stderr=stderr,
            start_new_session=_use_process_group(),
        )
    except OSError as exc:
        cmd0 = str(cmd[0]) if cmd else "<empty>"
        msg = f"Failed to spawn subprocess {cmd0}: {exc}"
        raise ToolExecutionError(msg) from exc
    if cancel_token is not None and cancel_token.is_cancelled():
        _kill_process_group(proc)
        await _await_exit(proc)
        raise OperationCancelledError
    return proc


async def run_subprocess(
    cmd: Sequence[str],
    *,
    cwd: str,
    env: Mapping[str, str] | None,
    timeout_ms: int | None,
    cancel_token: CancelToken | None = None,
) -> SubprocessResult:
    """Run a subprocess to completion and capture stdout/stderr."""
    try:
        proc = await spawn_subprocess(
            cmd,
            cwd=cwd,
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cancel_token=cancel_token,
        )
    except ToolExecutionError as exc:
        return SubprocessResult(
            exit_code=127,
            stdout=b"",
            stderr=str(exc).encode("utf-8", errors="replace"),
            timed_out=False,
        )
    comm_task: asyncio.Task[tuple[bytes, bytes]] = asyncio.create_task(
        proc.communicate()
    )
    cancel_task: asyncio.Task[None] | None = None
    tasks: set[asyncio.Task[object]] = {comm_task}
    if cancel_token is not None:
        cancel_task = asyncio.create_task(cancel_token.wait())
        tasks.add(cancel_task)
    timeout_seconds = None
    if isinstance(timeout_ms, int) and timeout_ms > 0:
        timeout_seconds = timeout_ms / 1000.0
    done, pending = await asyncio.wait(
        tasks,
        timeout=timeout_seconds,
        return_when=asyncio.FIRST_COMPLETED,
    )
    timed_out = False
    cancelled = False
    if not done:
        timed_out = True
    elif cancel_task is not None and cancel_task in done:
        cancelled = True
    if (timed_out or cancelled) and proc.returncode is None:
        _kill_process_group(proc)
    stdout_bytes, stderr_bytes = await comm_task
    pending_tasks = set(pending)
    pending_tasks.discard(comm_task)
    for task in pending_tasks:
        task.cancel()
    if pending_tasks:
        await asyncio.gather(*pending_tasks, return_exceptions=True)
    if cancelled:
        raise OperationCancelledError
    return SubprocessResult(
        exit_code=int(proc.returncode or 0),
        stdout=stdout_bytes,
        stderr=stderr_bytes,
        timed_out=timed_out,
    )


async def read_line_or_cancel(
    stream: asyncio.StreamReader,
    *,
    process: asyncio.subprocess.Process,
    cancel_token: CancelToken | None = None,
) -> bytes:
    """Read a line from a subprocess stream or cancel the process."""
    if cancel_token is None:
        return await stream.readline()
    cancel_task = asyncio.create_task(cancel_token.wait())
    read_task = asyncio.create_task(stream.readline())
    done, pending = await asyncio.wait(
        {read_task, cancel_task},
        return_when=asyncio.FIRST_COMPLETED,
    )
    if cancel_task in done:
        read_task.cancel()
        await asyncio.gather(read_task, return_exceptions=True)
        _kill_process_group(process)
        await _await_exit(process)
        raise OperationCancelledError
    cancel_task.cancel()
    if cancel_task in pending:
        await asyncio.gather(cancel_task, return_exceptions=True)
    return await read_task


def terminate_process(proc: asyncio.subprocess.Process) -> None:
    """Terminate a subprocess group without marking cancellation."""
    _terminate_process_group(proc)


__all__ = (
    "SubprocessResult",
    "read_line_or_cancel",
    "run_subprocess",
    "spawn_subprocess",
    "terminate_process",
)
