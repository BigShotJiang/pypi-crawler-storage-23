"""Reusable section builders for the info tool."""

from __future__ import annotations

import platform as system_platform
import shutil
import sys
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from agenterm import __version__
from agenterm.core.model_id import model_plane

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, MutableMapping, Sequence
    from pathlib import Path

    from agenterm.config.model import AppConfig
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext
    from agenterm.core.toolspec import ToolSpec

BINARY_NAMES: tuple[str, ...] = ("rg", "fd", "bat", "tree")


def json_list(values: Sequence[str]) -> list[JSONValue]:
    """Encode a string sequence as a JSONValue list."""
    out: list[JSONValue] = []
    out.extend(values)
    return out


def clock_section() -> dict[str, JSONValue]:
    """Build the clock section."""
    local_now = datetime.now().astimezone()
    utc_now = datetime.now(UTC)
    tz_name = local_now.tzname() or "unknown"
    offset = local_now.utcoffset()
    offset_minutes = 0
    if offset is not None:
        offset_minutes = int(offset.total_seconds() // 60)
    return {
        "now_local": local_now.isoformat(),
        "now_utc": utc_now.isoformat(),
        "tz_name": tz_name,
        "tz_offset_minutes": offset_minutes,
    }


def workspace_section(workspace_root: Path) -> dict[str, JSONValue]:
    """Build the workspace section."""
    return {
        "name": workspace_root.name,
        "root": workspace_root.as_posix(),
    }


def session_section(ctx: ToolRuntimeContext) -> dict[str, JSONValue] | None:
    """Build the session section when available."""
    if not ctx.session_id or not ctx.branch_id:
        return None
    return {
        "session_id": ctx.session_id,
        "branch_id": ctx.branch_id,
        "run_number": ctx.run_number,
    }


def runtime_section(cfg: AppConfig) -> dict[str, JSONValue]:
    """Build the runtime section."""
    inspect_cfg = cfg.tools.inspect
    return {
        "agenterm_version": __version__,
        "platform": "cli",
        "os": sys.platform,
        "arch": system_platform.machine(),
        "inspect_max_operations": (
            int(inspect_cfg.max_operations) if inspect_cfg is not None else None
        ),
        "inspect_max_concurrency": (
            int(inspect_cfg.max_concurrency) if inspect_cfg is not None else None
        ),
    }


def tools_section(selected: Sequence[ToolSpec]) -> dict[str, JSONValue]:
    """Build the selected-tools section."""
    unique: dict[str, ToolSpec] = {}
    for spec in selected:
        if spec.key not in unique:
            unique[spec.key] = spec
    keys = sorted(unique.keys())
    hosted = sum(1 for spec in unique.values() if spec.plane == "hosted")
    client = sum(1 for spec in unique.values() if spec.plane == "client")
    return {
        "selected_keys": json_list(keys),
        "selected_count": len(keys),
        "hosted_count": hosted,
        "client_count": client,
    }


def binaries_section() -> dict[str, JSONValue]:
    """Build the binaries section."""
    binaries: list[JSONValue] = [
        {"name": name, "available": shutil.which(name) is not None}
        for name in BINARY_NAMES
    ]
    return {"binaries": binaries}


def config_section(cfg: AppConfig) -> dict[str, JSONValue]:
    """Build the config section."""
    model_id = cfg.agent.model
    return {
        "model": {"id": model_id, "plane": model_plane(model_id)},
        "agent": {"name": cfg.agent.name, "source": cfg.agent.source},
    }


def trace_section(ctx: ToolRuntimeContext) -> dict[str, JSONValue] | None:
    """Build the trace section when identifiers are available."""
    if not ctx.trace_id and not ctx.session_id and not ctx.branch_id:
        return None
    return {
        "trace_id": ctx.trace_id,
        "session_id": ctx.session_id,
        "branch_id": ctx.branch_id,
        "run_number": ctx.run_number,
    }


def compression_section(cfg: AppConfig) -> dict[str, JSONValue]:
    """Build the compression section."""
    comp = cfg.compression
    return {
        "strategy": comp.strategy,
        "trigger": comp.trigger,
        "threshold_percent": comp.threshold_percent,
        "primary_branch": comp.primary_branch,
        "drop_policy": comp.drop_policy,
    }


def sync_section_builders(
    *,
    cfg: AppConfig,
    ctx: ToolRuntimeContext,
    workspace_root: Path,
    selected_specs: Sequence[ToolSpec],
) -> dict[str, Callable[[], dict[str, JSONValue] | None]]:
    """Build synchronous section-builder map."""
    return {
        "clock": clock_section,
        "workspace": lambda: workspace_section(workspace_root),
        "session": lambda: session_section(ctx),
        "runtime": lambda: runtime_section(cfg),
        "tools": lambda: tools_section(selected_specs),
        "binaries": binaries_section,
        "config": lambda: config_section(cfg),
        "trace": lambda: trace_section(ctx),
        "compression": lambda: compression_section(cfg),
    }


def apply_sync_section(
    name: str,
    *,
    builders: Mapping[str, Callable[[], dict[str, JSONValue] | None]],
    sections_out: MutableMapping[str, JSONValue],
    unavailable: list[str],
) -> None:
    """Execute one synchronous section builder."""
    builder = builders.get(name)
    if builder is None:
        unavailable.append(name)
        return
    result = builder()
    if result is None:
        unavailable.append(name)
        return
    sections_out[name] = result


__all__ = (
    "apply_sync_section",
    "json_list",
    "sync_section_builders",
)
