"""OS sandbox backends for shell tool execution."""

from __future__ import annotations

import asyncio
import os
import shutil
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Protocol

from agents.tool import ShellCallOutcome, ShellCommandOutput

from agenterm.core.errors import SandboxBackendUnavailableError
from agenterm.core.platform import is_linux, is_macos
from agenterm.engine.subprocess_runner import run_subprocess

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.choices.tools import SandboxNetwork


class ShellSandboxBackend(Protocol):
    """Backend contract for executing one shell command under OS sandboxing."""

    name: str

    async def execute_command(
        self,
        *,
        cmd: str,
        workspace_root: Path,
        working_dir: Path,
        network: SandboxNetwork,
        timeout_ms: int,
        env: Mapping[str, str],
        cancel_token: CancelToken | None,
    ) -> ShellCommandOutput:
        """Execute one command in a backend sandbox and return structured output."""
        ...


def _shell_output_from_subprocess(
    *,
    cmd: str,
    exit_code: int,
    stdout: bytes,
    stderr: bytes,
    timed_out: bool,
) -> ShellCommandOutput:
    return ShellCommandOutput(
        command=cmd,
        stdout=stdout.decode("utf-8", errors="ignore"),
        stderr=stderr.decode("utf-8", errors="ignore"),
        outcome=ShellCallOutcome(
            type="timeout" if timed_out else "exit",
            exit_code=exit_code,
        ),
    )


class SeatbeltBackend:
    """macOS Seatbelt backend using sandbox-exec."""

    name = "seatbelt"

    @staticmethod
    def _generate_policy(
        *,
        workspace_root: Path,
        network: SandboxNetwork,
    ) -> str:
        network_rule = "(allow network*)" if network == "allow" else "(deny network*)"
        workspace_path = str(workspace_root.resolve())
        return f"""(version 1)

; Start permissive, then restrict
(allow default)

; Network access (configurable)
{network_rule}

; Deny all writes by default
(deny file-write*)

; Allow writes ONLY under workspace root
(allow file-write* (subpath "{workspace_path}"))

; Allow writes to temp directories (needed for many tools)
(allow file-write* (subpath "/private/var/folders/"))
(allow file-write* (subpath "/private/tmp/"))
(allow file-write* (subpath "/tmp/"))

; Allow /dev/null (needed by git, many Unix tools for output suppression)
(allow file-write* (literal "/dev/null"))

; Allow process execution (needed to run commands)
(allow process*)

; Allow reading everywhere (model needs to read system files, binaries, etc.)
(allow file-read*)
"""

    @staticmethod
    def _write_policy_sync(policy: str) -> Path:
        policy_fd, policy_path_str = tempfile.mkstemp(suffix=".sb", text=True)
        try:
            os.write(policy_fd, policy.encode("utf-8"))
        finally:
            os.close(policy_fd)
        return Path(policy_path_str)

    async def execute_command(
        self,
        *,
        cmd: str,
        workspace_root: Path,
        working_dir: Path,
        network: SandboxNetwork,
        timeout_ms: int,
        env: Mapping[str, str],
        cancel_token: CancelToken | None,
    ) -> ShellCommandOutput:
        """Execute one command under macOS Seatbelt policy enforcement."""
        policy = self._generate_policy(
            workspace_root=workspace_root,
            network=network,
        )
        policy_path = await asyncio.to_thread(self._write_policy_sync, policy)
        try:
            result = await run_subprocess(
                [
                    "sandbox-exec",
                    "-f",
                    str(policy_path),
                    "sh",
                    "-c",
                    cmd,
                ],
                cwd=str(working_dir),
                env=env,
                timeout_ms=timeout_ms,
                cancel_token=cancel_token,
            )
            return _shell_output_from_subprocess(
                cmd=cmd,
                exit_code=result.exit_code,
                stdout=result.stdout,
                stderr=result.stderr,
                timed_out=result.timed_out,
            )
        finally:
            policy_path.unlink(missing_ok=True)


class LinuxBackend:
    """Linux backend using bubblewrap (bwrap)."""

    name = "linux_bwrap"
    binary_name = "bwrap"
    root_mount = str(Path(os.path.sep))
    tmp_mount = str(Path(os.path.sep) / "tmp")
    var_tmp_mount = str(Path(os.path.sep) / "var" / "tmp")
    proc_mount = str(Path(os.path.sep) / "proc")
    dev_mount = str(Path(os.path.sep) / "dev")

    @staticmethod
    def _build_bwrap_cmd(
        *,
        cmd: str,
        workspace_root: Path,
        working_dir: Path,
        network: SandboxNetwork,
    ) -> list[str]:
        workspace_path = str(workspace_root.resolve())
        cwd_path = str(working_dir.resolve())
        args = [
            LinuxBackend.binary_name,
            "--die-with-parent",
            "--ro-bind",
            LinuxBackend.root_mount,
            LinuxBackend.root_mount,
            "--bind",
            workspace_path,
            workspace_path,
            "--tmpfs",
            LinuxBackend.tmp_mount,
            "--tmpfs",
            LinuxBackend.var_tmp_mount,
            "--proc",
            LinuxBackend.proc_mount,
            "--dev",
            LinuxBackend.dev_mount,
            "--chdir",
            cwd_path,
        ]
        if network == "deny":
            args.append("--unshare-net")
        args.extend(["sh", "-c", cmd])
        return args

    async def execute_command(
        self,
        *,
        cmd: str,
        workspace_root: Path,
        working_dir: Path,
        network: SandboxNetwork,
        timeout_ms: int,
        env: Mapping[str, str],
        cancel_token: CancelToken | None,
    ) -> ShellCommandOutput:
        """Execute one command under the Linux bubblewrap sandbox."""
        args = self._build_bwrap_cmd(
            cmd=cmd,
            workspace_root=workspace_root,
            working_dir=working_dir,
            network=network,
        )
        result = await run_subprocess(
            args,
            cwd=str(working_dir),
            env=env,
            timeout_ms=timeout_ms,
            cancel_token=cancel_token,
        )
        return _shell_output_from_subprocess(
            cmd=cmd,
            exit_code=result.exit_code,
            stdout=result.stdout,
            stderr=result.stderr,
            timed_out=result.timed_out,
        )


def resolve_shell_sandbox_backend() -> ShellSandboxBackend:
    """Return the concrete shell sandbox backend for this runtime."""
    if is_macos():
        return SeatbeltBackend()
    if is_linux():
        if shutil.which(LinuxBackend.binary_name) is None:
            msg = (
                "Linux shell sandbox backend unavailable: install bubblewrap (`bwrap`)."
            )
            raise SandboxBackendUnavailableError(
                msg,
                platform="linux",
                backend=LinuxBackend.binary_name,
            )
        return LinuxBackend()
    msg = f"No supported shell sandbox backend available for platform: {sys.platform}"
    raise SandboxBackendUnavailableError(
        msg,
        platform=sys.platform,
        backend=None,
    )


__all__ = (
    "LinuxBackend",
    "SeatbeltBackend",
    "ShellSandboxBackend",
    "resolve_shell_sandbox_backend",
)
