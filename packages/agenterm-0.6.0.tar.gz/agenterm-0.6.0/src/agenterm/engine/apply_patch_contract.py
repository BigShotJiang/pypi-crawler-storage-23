"""Canonical contract definitions and payload parsing for apply_patch."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from agenterm.core.json_codec import as_bool, as_str, parse_json_object

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

CreateIfExists = Literal["error", "overwrite", "skip"]
UpdateDiffFormat = Literal["unified_with_headers", "hunks_only"]
UpdateIfMissing = Literal["error", "skip"]
DeleteTargetType = Literal["file", "dir", "any"]
ResponseStatus = Literal["ok", "error", "skipped"]


@dataclass(frozen=True)
class CreateFileOp:
    """Create/overwrite file operation."""

    path: str
    if_exists: CreateIfExists
    content: str


@dataclass(frozen=True)
class UpdateFileOp:
    """Patch existing file operation."""

    path: str
    diff: str
    diff_format: UpdateDiffFormat
    if_missing: UpdateIfMissing


@dataclass(frozen=True)
class DeletePathOp:
    """Delete path operation."""

    path: str
    target_type: DeleteTargetType
    recursive: bool
    missing_ok: bool


PatchOp = CreateFileOp | UpdateFileOp | DeletePathOp

_CREATE_FILE_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "properties": {
        "op": {"type": "string", "enum": ["create_file"]},
        "path": {"type": "string"},
        "if_exists": {"type": "string", "enum": ["error", "overwrite", "skip"]},
        "content": {"type": "string"},
    },
    "required": ["op", "path", "if_exists", "content"],
    "additionalProperties": False,
}

_UPDATE_FILE_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "properties": {
        "op": {"type": "string", "enum": ["update_file"]},
        "path": {"type": "string"},
        "diff": {"type": "string"},
        "diff_format": {
            "type": "string",
            "enum": ["unified_with_headers", "hunks_only"],
        },
        "if_missing": {"type": "string", "enum": ["error", "skip"]},
    },
    "required": ["op", "path", "diff", "diff_format", "if_missing"],
    "additionalProperties": False,
}

_DELETE_PATH_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "properties": {
        "op": {"type": "string", "enum": ["delete_path"]},
        "path": {"type": "string"},
        "target_type": {"type": "string", "enum": ["file", "dir", "any"]},
        "recursive": {"type": "boolean"},
        "missing_ok": {"type": "boolean"},
    },
    "required": ["op", "path", "target_type", "recursive", "missing_ok"],
    "additionalProperties": False,
}

APPLY_PATCH_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Apply ordered workspace edit operations.",
    "properties": {
        "approval_label": {
            "type": ["string", "null"],
            "description": "Approval label shown to the user.",
        },
        "operations": {
            "type": "array",
            "minItems": 1,
            "items": {
                "anyOf": [_CREATE_FILE_SCHEMA, _UPDATE_FILE_SCHEMA, _DELETE_PATH_SCHEMA]
            },
        },
    },
    "required": ["approval_label", "operations"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class ParsedApplyPatchPayload:
    """Parsed apply_patch payload."""

    approval_label: str | None
    operations: list[PatchOp]


def _parse_create_if_exists(value: str | None) -> CreateIfExists | None:
    if value == "error":
        return "error"
    if value == "overwrite":
        return "overwrite"
    if value == "skip":
        return "skip"
    return None


def _parse_update_diff_format(value: str | None) -> UpdateDiffFormat | None:
    if value == "unified_with_headers":
        return "unified_with_headers"
    if value == "hunks_only":
        return "hunks_only"
    return None


def _parse_update_if_missing(value: str | None) -> UpdateIfMissing | None:
    if value == "error":
        return "error"
    if value == "skip":
        return "skip"
    return None


def _parse_delete_target_type(value: str | None) -> DeleteTargetType | None:
    if value == "file":
        return "file"
    if value == "dir":
        return "dir"
    if value == "any":
        return "any"
    return None


def _parse_create_file(entry: Mapping[str, JSONValue]) -> CreateFileOp | None:
    path = as_str(entry.get("path"))
    content = as_str(entry.get("content"))
    if_exists = _parse_create_if_exists(as_str(entry.get("if_exists")))
    if path is None or not path.strip() or content is None or if_exists is None:
        return None
    return CreateFileOp(path=path, if_exists=if_exists, content=content)


def _parse_update_file(entry: Mapping[str, JSONValue]) -> UpdateFileOp | None:
    path = as_str(entry.get("path"))
    diff = as_str(entry.get("diff"))
    diff_format = _parse_update_diff_format(as_str(entry.get("diff_format")))
    if_missing = _parse_update_if_missing(as_str(entry.get("if_missing")))
    if (
        path is None
        or not path.strip()
        or diff is None
        or diff_format is None
        or if_missing is None
    ):
        return None
    return UpdateFileOp(
        path=path,
        diff=diff,
        diff_format=diff_format,
        if_missing=if_missing,
    )


def _parse_delete_path(entry: Mapping[str, JSONValue]) -> DeletePathOp | None:
    path = as_str(entry.get("path"))
    target_type = _parse_delete_target_type(as_str(entry.get("target_type")))
    recursive = as_bool(entry.get("recursive"))
    missing_ok = as_bool(entry.get("missing_ok"))
    if (
        path is None
        or not path.strip()
        or target_type is None
        or recursive is None
        or missing_ok is None
    ):
        return None
    return DeletePathOp(
        path=path,
        target_type=target_type,
        recursive=recursive,
        missing_ok=missing_ok,
    )


def _parse_operation(entry: Mapping[str, JSONValue]) -> PatchOp | None:
    op = as_str(entry.get("op"))
    if op == "create_file":
        return _parse_create_file(entry)
    if op == "update_file":
        return _parse_update_file(entry)
    if op == "delete_path":
        return _parse_delete_path(entry)
    return None


def _parse_operations(value: JSONValue | None) -> list[PatchOp] | None:
    if not isinstance(value, list) or not value:
        return None
    operations: list[PatchOp] = []
    for entry in value:
        if not isinstance(entry, dict):
            return None
        parsed = _parse_operation(entry)
        if parsed is None:
            return None
        operations.append(parsed)
    return operations


def parse_apply_patch_payload(raw: str) -> ParsedApplyPatchPayload | None:
    """Parse/validate apply_patch tool input."""
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None
    required = {"approval_label", "operations"}
    if set(payload) != required:
        return None
    label_raw = payload.get("approval_label")
    if label_raw is not None and not isinstance(label_raw, str):
        return None
    operations = _parse_operations(payload.get("operations"))
    if operations is None:
        return None
    cleaned_label = label_raw.strip() if isinstance(label_raw, str) else None
    return ParsedApplyPatchPayload(
        approval_label=cleaned_label or None,
        operations=operations,
    )


def patch_op_name(op: PatchOp) -> str:
    """Return canonical op name for a parsed patch operation."""
    if isinstance(op, CreateFileOp):
        return "create_file"
    if isinstance(op, UpdateFileOp):
        return "update_file"
    return "delete_path"


__all__ = (
    "APPLY_PATCH_SCHEMA",
    "CreateFileOp",
    "DeletePathOp",
    "ParsedApplyPatchPayload",
    "PatchOp",
    "ResponseStatus",
    "UpdateFileOp",
    "parse_apply_patch_payload",
    "patch_op_name",
)
