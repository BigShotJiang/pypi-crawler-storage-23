"""Model-input packing hooks.

This module wires agenterm's history packing into the Agents SDK per-call hook
(`RunConfig.call_model_input_filter`) so compression can run between turns.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

from agents.run import CallModelData, ModelInputData

from agenterm.core.function_call_recovery import recover_orphan_function_call_outputs
from agenterm.engine.history_packing import pack_history_items
from agenterm.store.session.factory import session_store

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from agenterm.config.model import AppConfig
    from agenterm.engine.history_packing_helpers import HistoryPackingOptions
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession

TContext = TypeVar("TContext")


def build_call_model_input_filter(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    model_id: str,
    options: HistoryPackingOptions,
) -> Callable[[CallModelData[TContext]], Awaitable[ModelInputData]]:
    """Return a per-run per-call model input filter.

    The Agents runner applies `session_input_callback` only once at run start.
    This hook runs before every model call, enabling mid-run compression when
    tool output or multi-turn loops grow the prompt.

    The first model call is left unchanged: it already reflects the packed
    `session_input_callback` result.
    """
    store = session_store()
    first_call = True

    async def _filter(payload: CallModelData[TContext]) -> ModelInputData:
        nonlocal first_call
        if first_call:
            first_call = False
            return payload.model_data

        history_items = await session.get_items()
        packed = await pack_history_items(
            cfg=cfg,
            history_items=history_items,
            new_items=[],
            model_id=model_id,
            session=session,
            store=store,
            options=options,
        )
        repaired = recover_orphan_function_call_outputs(
            packed,
            source="call_model_input_filter",
        )
        return ModelInputData(
            input=repaired,
            instructions=payload.model_data.instructions,
        )

    return _filter


__all__ = ("build_call_model_input_filter",)
