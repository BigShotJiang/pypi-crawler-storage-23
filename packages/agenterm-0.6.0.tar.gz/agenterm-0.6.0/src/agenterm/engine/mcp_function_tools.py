"""Build FunctionTools from MCP servers for gateway execution."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.mcp.util import MCPUtil
from agents.run_context import RunContextWrapper
from agents.tool import FunctionTool, Tool

from agenterm.core.errors import ValidationError
from agenterm.engine.mcp_bridge import wrap_mcp_servers
from agenterm.engine.schema_validation import validate_strict_schema

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.agent import AgentBase
    from agents.mcp import MCPServer

    from agenterm.config.mcp_models import McpBridgeConfig
    from agenterm.core.approvals import McpApprovalManager
    from agenterm.core.plan import ToolRuntimeContext
    from agenterm.engine.tool_output_clamp import ToolOutputClamp


def _function_tool_names(tools: Sequence[Tool]) -> set[str]:
    return {tool.name for tool in tools if isinstance(tool, FunctionTool)}


def _require_strict_mcp_function_tools(tools: Sequence[Tool]) -> None:
    function_tools = [tool for tool in tools if isinstance(tool, FunctionTool)]
    non_strict = sorted(
        tool.name for tool in function_tools if not tool.strict_json_schema
    )
    if non_strict:
        message = (
            "MCP tools must expose strict JSON schemas. Non-strict tools: "
            f"{', '.join(non_strict)}"
        )
        raise ValidationError(message)
    for tool in function_tools:
        validate_strict_schema(f"mcp.{tool.name}", tool.params_json_schema)


def merge_mcp_function_tools(
    *,
    existing_tools: Sequence[Tool],
    mcp_tools: Sequence[Tool],
) -> list[Tool]:
    """Merge MCP-derived tools into the existing tool list, rejecting collisions."""
    existing_names = _function_tool_names(existing_tools)
    mcp_names = _function_tool_names(mcp_tools)
    duplicates = sorted(existing_names & mcp_names)
    if duplicates:
        message = f"MCP tool names collide with existing tools: {', '.join(duplicates)}"
        raise ValidationError(message)
    return [*existing_tools, *mcp_tools]


async def build_mcp_function_tools(
    *,
    servers: Sequence[MCPServer],
    approvals: McpApprovalManager,
    bridge_cfg: McpBridgeConfig,
    output_clamp: ToolOutputClamp,
    convert_schemas_to_strict: bool,
    run_context: ToolRuntimeContext | None,
    agent: AgentBase,
) -> list[Tool]:
    """Return MCP servers converted into FunctionTools via Agents MCP utilities."""
    if not servers:
        return []
    if not convert_schemas_to_strict:
        message = (
            "MCP schema strict conversion must be enabled; "
            "set mcp.convert_schemas_to_strict=true."
        )
        raise ValidationError(message)
    cancel_token = run_context.cancel_token if run_context is not None else None
    wrapped = wrap_mcp_servers(
        servers,
        approvals=approvals,
        bridge_cfg=bridge_cfg,
        output_clamp=output_clamp,
        cancel_token=cancel_token,
    )
    context = RunContextWrapper(run_context)
    tools = await MCPUtil.get_all_function_tools(
        list(wrapped),
        convert_schemas_to_strict,
        context,
        agent,
    )
    _require_strict_mcp_function_tools(tools)
    return output_clamp.wrap_tools(tools)


__all__ = ("build_mcp_function_tools", "merge_mcp_function_tools")
