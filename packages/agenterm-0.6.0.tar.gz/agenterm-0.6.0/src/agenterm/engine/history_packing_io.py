"""Serialization helpers for history packing."""

from __future__ import annotations

from typing import TYPE_CHECKING

from openai import OpenAIError

from agenterm.core.model_id import openai_model_name
from agenterm.core.openai_client import get_openai_client
from agenterm.core.response_items import normalize_input_item_json, serialize_input_item

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.items import TResponseInputItem

    from agenterm.engine.history_packing_helpers import PackedItem


def serialize_packed_items(
    items: Sequence[TResponseInputItem],
    *,
    context: str,
) -> list[PackedItem]:
    """Serialize typed input items into JSON-safe packed items."""
    return [serialize_input_item(item, context=context) for item in items]


def parse_packed_items(
    items: Sequence[PackedItem],
    *,
    context: str,
) -> list[TResponseInputItem]:
    """Normalize packed items into JSON-safe input items."""
    return [normalize_input_item_json(item, context=context) for item in items]


async def count_openai_tokens(
    *,
    model_id: str,
    input_items: Sequence[TResponseInputItem],
    instructions: str | None,
) -> int | None:
    """Count input tokens for OpenAI models.

    Returns None for provider/API failures (OpenAIError).

    Raises:
      ConfigError: When OPENAI_API_KEY is not configured for this process.

    """
    normalized_model = openai_model_name(model_id)
    client = get_openai_client()
    try:
        response = await client.responses.input_tokens.count(
            model=normalized_model,
            input=list(input_items),
            instructions=instructions,
            truncation="disabled",
        )
    except OpenAIError:
        return None
    return int(response.input_tokens)


__all__ = (
    "count_openai_tokens",
    "parse_packed_items",
    "serialize_packed_items",
)
