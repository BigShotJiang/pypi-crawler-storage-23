"""MCP diagnostics helpers shared by CLI and REPL edges.

This module provides a single, typed path to:
- connect to configured MCP servers,
- list tools (for status/inspection),
- return bounded, stable snapshots suitable for human rendering and JSON envelopes.

It intentionally lives in the engine layer so both `agenterm mcp ...` and REPL
`/mcp ...` commands share one canonical behavior.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.config.model import AppConfig, McpConfig, McpServerConfig
from agenterm.engine.mcp_errors import MCP_CONNECT_ERRORS
from agenterm.engine.mcp_factory import build_mcp_servers

if TYPE_CHECKING:
    from collections.abc import MutableMapping

    from mcp import types as mtypes

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class McpServerStatus:
    """Per-server status row for a diagnostic status snapshot."""

    key: str
    kind: str
    connected: bool
    tool_count: int
    error: str | None = None

    def to_json(self) -> dict[str, JSONValue]:
        """Convert the status row to a JSON-ready mapping."""
        return {
            "key": self.key,
            "kind": self.kind,
            "connected": self.connected,
            "tool_count": self.tool_count,
            "error": self.error,
        }


@dataclass(frozen=True)
class McpStatusSnapshot:
    """Aggregated MCP status snapshot suitable for UI rendering and JSON output."""

    servers: tuple[McpServerStatus, ...]
    total_tools: int

    def has_errors(self) -> bool:
        """Return True when any configured server failed to connect or list tools."""
        return any(s.error is not None for s in self.servers)

    def to_json(self) -> dict[str, JSONValue]:
        """Convert the snapshot to a JSON-ready mapping."""
        return {
            "servers": [s.to_json() for s in self.servers],
            "total_tools": self.total_tools,
        }


async def _probe_servers(
    servers_cfg: tuple[McpServerConfig, ...],
) -> tuple[McpStatusSnapshot, MutableMapping[str, MutableMapping[str, mtypes.Tool]]]:
    """Connect to each server and return (status snapshot, tools by server)."""
    if not servers_cfg:
        return McpStatusSnapshot(servers=(), total_tools=0), {}

    app_cfg = AppConfig(mcp=McpConfig(servers=list(servers_cfg)))
    servers = build_mcp_servers(app_cfg)

    rows: list[McpServerStatus] = []
    tools_by_server: MutableMapping[str, MutableMapping[str, mtypes.Tool]] = {}
    total_tools = 0

    for scfg, server in zip(servers_cfg, servers, strict=False):
        tools: MutableMapping[str, mtypes.Tool] = {}
        err: str | None = None
        connected = False
        try:
            await server.connect()
            connected = True
            tools_raw = await server.list_tools()
            tools = {t.name: t for t in tools_raw if t.name}
        except MCP_CONNECT_ERRORS as exc:
            err = str(exc)
            connected = False
            tools = {}
        finally:
            try:
                await server.cleanup()
            except MCP_CONNECT_ERRORS:
                # Status snapshots are best-effort; cleanup failure should not crash
                # the edge.
                if err is None:
                    err = "cleanup_failed"

        tools_by_server[scfg.key] = tools
        tool_count = len(tools)
        total_tools += tool_count
        rows.append(
            McpServerStatus(
                key=scfg.key,
                kind=scfg.kind,
                connected=connected,
                tool_count=tool_count,
                error=err,
            ),
        )

    return McpStatusSnapshot(
        servers=tuple(rows),
        total_tools=total_tools,
    ), tools_by_server


async def build_mcp_status_snapshot(
    servers_cfg: tuple[McpServerConfig, ...],
) -> McpStatusSnapshot:
    """Build a best-effort status snapshot for all configured servers."""
    snapshot, _ = await _probe_servers(servers_cfg)
    return snapshot


async def diagnose_mcp_servers(
    servers_cfg: tuple[McpServerConfig, ...],
) -> tuple[McpStatusSnapshot, MutableMapping[str, MutableMapping[str, mtypes.Tool]]]:
    """Connect to each server and return a snapshot plus tool definitions."""
    return await _probe_servers(servers_cfg)


async def list_tools_for_servers(
    servers_cfg: tuple[McpServerConfig, ...],
) -> MutableMapping[str, MutableMapping[str, mtypes.Tool]]:
    """Connect to each configured server and list tools.

    Returns a mapping from server key to a tools mapping (name -> Tool).
    Servers that fail to connect or list tools return an empty mapping for that key.
    """
    _, tools_by_server = await _probe_servers(servers_cfg)
    return tools_by_server


__all__ = (
    "McpServerStatus",
    "McpStatusSnapshot",
    "build_mcp_status_snapshot",
    "diagnose_mcp_servers",
    "list_tools_for_servers",
)
