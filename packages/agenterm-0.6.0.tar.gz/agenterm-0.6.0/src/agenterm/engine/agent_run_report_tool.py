"""Local agent_run_report tool for retrieving stored agent_run reports."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.artifacts.agent_run import load_agent_run_report
from agenterm.core.errors import AgentermError
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.core.tool_output_envelope import (
    ToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.agent_run_report_sanitize import (
    AgentRunReportSanitizationStats,
    sanitize_agent_run_report,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_agent_run_report
from agenterm.store.async_db import AsyncStore

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.tool_context import ToolContext

    from agenterm.config.tools_policy import AgentRunReportToolConfig
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_INVALID_INPUT_KIND = "invalid_input"
_NOT_FOUND_KIND = "not_found"
_TOOL_ERROR_KIND = "tool_error"

_AGENT_RUN_REPORT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "agent_run_report lookup parameters.",
    "properties": {
        "report_id": {
            "type": "string",
            "description": "Report id returned by agent_run.",
        },
        "mode": {
            "type": ["string", "null"],
            "enum": ["summary", "full", "forensic", None],
            "description": "summary (default), full, or forensic.",
        },
    },
    "required": ["report_id", "mode"],
    "additionalProperties": False,
}

_SUMMARY_REPORT_KEYS: tuple[str, ...] = (
    "tool_call_id",
    "trace_id",
    "created_at",
    "model",
    "input",
    "output_text",
    "tool_counts",
    "truncated",
    "warnings",
    "usage",
    "response_id",
    "response_ids",
    "tools_used",
)


def _json_string_list(values: Sequence[str]) -> list[JSONValue]:
    items: list[JSONValue] = []
    items.extend(values)
    return items


def _error_output(
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    err = ToolOutputError(
        kind=kind,
        message=message,
        details=dict(details) if details is not None else {},
    )
    env = ToolOutputEnvelope(
        tool="agent_run_report",
        ok=False,
        result={},
        error=err,
    )
    return env.to_json_string()


def _parse_report_request(
    raw: str,
) -> tuple[str | None, str | None, dict[str, JSONValue] | None]:
    payload = parse_json_object(raw) if raw else None
    report_id: str | None = None
    mode: str | None = None
    if payload is None:
        return None, None, {"field": "/", "reason": "invalid_payload"}
    unknown_keys = sorted(set(payload) - {"report_id", "mode"})
    if unknown_keys:
        allowed_keys = _json_string_list(["mode", "report_id"])
        return (
            None,
            None,
            {
                "field": "/",
                "reason": "unknown_keys",
                "unknown_keys": _json_string_list(unknown_keys),
                "allowed_keys": allowed_keys,
            },
        )
    report_id_raw = as_str(payload.get("report_id"))
    if report_id_raw is None or not report_id_raw.strip():
        return (
            None,
            None,
            {
                "field": "report_id",
                "reason": "required_non_null",
                "required_non_null": _json_string_list(["report_id"]),
            },
        )
    report_id = report_id_raw
    mode_raw = payload.get("mode")
    if mode_raw is None:
        mode = "summary"
    elif isinstance(mode_raw, str):
        cleaned_mode = mode_raw.strip()
        if cleaned_mode:
            mode = cleaned_mode
    if mode not in {"summary", "full", "forensic"}:
        return (
            report_id,
            None,
            {
                "field": "mode",
                "reason": "invalid_value",
                "allowed": _json_string_list(["summary", "full", "forensic"]),
            },
        )
    return report_id, mode, None


def _summary_report(
    report: Mapping[str, JSONValue],
    *,
    stats: AgentRunReportSanitizationStats,
) -> dict[str, JSONValue]:
    summary: dict[str, JSONValue] = {}
    for key in _SUMMARY_REPORT_KEYS:
        if key in report:
            summary[key] = report[key]
    input_items = report.get("input_items")
    output_items = report.get("output_items")
    tools_available = report.get("tools_available")
    summary["input_items_count"] = (
        len(input_items) if isinstance(input_items, list) else 0
    )
    summary["output_items_count"] = (
        len(output_items) if isinstance(output_items, list) else 0
    )
    summary["tools_available_count"] = (
        len(tools_available) if isinstance(tools_available, list) else 0
    )
    summary["report_sanitized"] = True
    summary["sanitization"] = {
        key: int(value) for key, value in stats.to_mapping().items()
    }
    summary["contains_full_payload"] = False
    summary["full_payload_available"] = True
    return summary


def build_agent_run_report_tool(
    cfg: AgentRunReportToolConfig | None,
) -> FunctionTool | None:
    """Build the agent_run_report tool when configured."""
    if cfg is None:
        return None
    validate_strict_schema("agent_run_report", _AGENT_RUN_REPORT_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        report_id, mode, details = _parse_report_request(raw)
        if details is not None or report_id is None or mode is None:
            if details is not None and details.get("field") == "report_id":
                return _error_output(
                    kind=_INVALID_INPUT_KIND,
                    message="agent_run_report requires report_id.",
                    details=details,
                )
            if details is not None and details.get("field") == "mode":
                return _error_output(
                    kind=_INVALID_INPUT_KIND,
                    message="agent_run_report mode must be summary, full, or forensic.",
                    details=details,
                )
            return _error_output(
                kind=_INVALID_INPUT_KIND,
                message="Invalid agent_run_report payload.",
                details=details or {"reason": "invalid_payload"},
            )
        try:
            report = await load_agent_run_report(
                store=AsyncStore(ctx.context.db_path),
                artifact_id=report_id,
            )
        except AgentermError as exc:
            return _error_output(
                kind=_TOOL_ERROR_KIND,
                message=str(exc),
                details={"reason": "report_load_failed"},
            )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        if report is None:
            return _error_output(
                kind=_NOT_FOUND_KIND,
                message="agent_run_report not found.",
                details={
                    "field": "report_id",
                    "reason": "not_found",
                    "report_id": report_id,
                },
            )
        sanitized_report, stats = sanitize_agent_run_report(report)
        payload: dict[str, JSONValue] = {
            "report_id": report_id,
            "mode": mode,
            "report": (
                _summary_report(sanitized_report, stats=stats)
                if mode == "summary"
                else (report if mode == "forensic" else sanitized_report)
            ),
            "truncated": False,
            "truncation": None,
        }
        env = ToolOutputEnvelope(
            tool="agent_run_report",
            ok=True,
            result=payload,
        )
        return env.to_json_string()

    return FunctionTool(
        name="agent_run_report",
        description=describe_agent_run_report(),
        params_json_schema=_AGENT_RUN_REPORT_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_agent_run_report_tool",)
