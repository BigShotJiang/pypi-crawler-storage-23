"""Shared exception sets for MCP connectivity and listing.

Centralizes the "things that can go wrong" when connecting to MCP servers so
engine components can handle failures consistently (diagnostics, pools, etc.).
"""

from __future__ import annotations

import asyncio

import httpx
from agents.exceptions import AgentsException
from mcp.shared.exceptions import McpError

MCP_CONNECT_ERRORS = (
    AgentsException,
    McpError,
    OSError,
    RuntimeError,
    asyncio.TimeoutError,
    httpx.HTTPError,
    ValueError,
)

__all__ = ("MCP_CONNECT_ERRORS",)
