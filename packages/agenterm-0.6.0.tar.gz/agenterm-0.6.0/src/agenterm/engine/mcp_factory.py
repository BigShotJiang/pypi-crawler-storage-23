"""MCP server construction for agenterm.

Translates AppConfig.mcp into Agents MCP server instances.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.mcp import (
    MCPServer,
    MCPServerSse,
    MCPServerStdio,
    MCPServerStreamableHttp,
    create_static_tool_filter,
)

from agenterm.core.errors import ConfigError
from agenterm.core.mcp_registry import (
    resolve_httpx_client_factory,
    resolve_message_handler,
    resolve_tool_filter,
)
from agenterm.core.retry import RetryPolicy
from agenterm.engine.mcp_meta import resolve_mcp_tool_meta
from agenterm.engine.mcp_namespacing import NamespacedMcpServer

if TYPE_CHECKING:
    from agents.mcp import (
        MCPServerSseParams,
        MCPServerStdioParams,
        MCPServerStreamableHttpParams,
        ToolFilter,
    )
    from mcp.client.session import MessageHandlerFnT

    from agenterm.config.model import AppConfig, McpServerConfig


def _tool_filter_arg(conf: McpServerConfig) -> ToolFilter:
    tf = conf.tool_filter
    if tf is None:
        return None
    if tf.callable_key is not None:
        return resolve_tool_filter(tf.callable_key)
    allowed_tool_names = (
        list(tf.allowed_tool_names) if tf.allowed_tool_names is not None else None
    )
    blocked_tool_names = (
        list(tf.blocked_tool_names) if tf.blocked_tool_names is not None else None
    )
    return create_static_tool_filter(
        allowed_tool_names=allowed_tool_names,
        blocked_tool_names=blocked_tool_names,
    )


def _message_handler_arg(conf: McpServerConfig) -> MessageHandlerFnT | None:
    key = conf.message_handler_key
    if key is None:
        return None
    return resolve_message_handler(key)


def _build_stdio_server(conf: McpServerConfig) -> MCPServer:
    if conf.stdio is None:
        message = f"MCP server {conf.key!r} declared kind=stdio but has no stdio config"
        raise ConfigError(message)
    s = conf.stdio
    params: MCPServerStdioParams = {
        "command": s.command,
        "encoding": s.encoding,
        "encoding_error_handler": s.encoding_error_handler,
    }
    if s.args:
        params["args"] = list(s.args)
    if s.env is not None:
        params["env"] = dict(s.env)
    if s.cwd is not None:
        params["cwd"] = s.cwd
    rt = conf.runtime
    tool_filter = _tool_filter_arg(conf)
    message_handler = _message_handler_arg(conf)
    return MCPServerStdio(
        params=params,
        cache_tools_list=rt.cache_tools,
        name=conf.name,
        client_session_timeout_seconds=rt.session_timeout,
        tool_filter=tool_filter,
        use_structured_content=conf.use_structured_content,
        max_retry_attempts=0,
        retry_backoff_seconds_base=1.0,
        message_handler=message_handler,
        tool_meta_resolver=resolve_mcp_tool_meta,
    )


def _build_sse_server(conf: McpServerConfig) -> MCPServer:
    if conf.sse is None:
        message = f"MCP server {conf.key!r} declared kind=sse but has no sse config"
        raise ConfigError(message)
    s = conf.sse
    params: MCPServerSseParams = {"url": s.url}
    if s.headers is not None:
        params["headers"] = dict(s.headers)
    if s.timeout is not None:
        params["timeout"] = s.timeout
    if s.sse_read_timeout is not None:
        params["sse_read_timeout"] = s.sse_read_timeout
    rt = conf.runtime
    tool_filter = _tool_filter_arg(conf)
    message_handler = _message_handler_arg(conf)
    return MCPServerSse(
        params=params,
        cache_tools_list=rt.cache_tools,
        name=conf.name,
        client_session_timeout_seconds=rt.session_timeout,
        tool_filter=tool_filter,
        use_structured_content=conf.use_structured_content,
        max_retry_attempts=0,
        retry_backoff_seconds_base=1.0,
        message_handler=message_handler,
        tool_meta_resolver=resolve_mcp_tool_meta,
    )


def _build_streamable_http_server(conf: McpServerConfig) -> MCPServer:
    if conf.streamable_http is None:
        message = (
            f"MCP server {conf.key!r} declared kind=streamable_http but has no "
            "streamable_http config"
        )
        raise ConfigError(message)
    s = conf.streamable_http
    params: MCPServerStreamableHttpParams = {"url": s.url}
    if s.headers is not None:
        params["headers"] = dict(s.headers)
    if s.timeout is not None:
        params["timeout"] = s.timeout
    if s.sse_read_timeout is not None:
        params["sse_read_timeout"] = s.sse_read_timeout
    if s.terminate_on_close is not None:
        params["terminate_on_close"] = s.terminate_on_close
    if s.httpx_client_factory_key is not None:
        params["httpx_client_factory"] = resolve_httpx_client_factory(
            s.httpx_client_factory_key,
        )
    rt = conf.runtime
    tool_filter = _tool_filter_arg(conf)
    message_handler = _message_handler_arg(conf)
    return MCPServerStreamableHttp(
        params=params,
        cache_tools_list=rt.cache_tools,
        name=conf.name,
        client_session_timeout_seconds=rt.session_timeout,
        tool_filter=tool_filter,
        use_structured_content=conf.use_structured_content,
        max_retry_attempts=0,
        retry_backoff_seconds_base=1.0,
        message_handler=message_handler,
        tool_meta_resolver=resolve_mcp_tool_meta,
    )


def _mcp_retry_policy(cfg: AppConfig) -> RetryPolicy:
    policy = cfg.retries.mcp
    return RetryPolicy(
        max_retries=policy.max_retries,
        base_backoff_seconds=policy.base_backoff_seconds,
        max_backoff_seconds=policy.max_backoff_seconds,
        jitter_ratio=policy.jitter_ratio,
        retry_after_max_seconds=policy.retry_after_max_seconds,
    )


def build_mcp_servers(cfg: AppConfig) -> list[MCPServer]:
    """Construct MCPServer instances from AppConfig.mcp."""
    servers: list[MCPServer] = []
    retry_policy = _mcp_retry_policy(cfg)
    for sc in cfg.mcp.servers:
        if sc.kind == "stdio" and sc.stdio is not None:
            inner = _build_stdio_server(sc)
            servers.append(
                NamespacedMcpServer(
                    server_key=sc.key,
                    inner=inner,
                    retry_policy=retry_policy,
                )
            )
        elif sc.kind == "sse" and sc.sse is not None:
            inner = _build_sse_server(sc)
            servers.append(
                NamespacedMcpServer(
                    server_key=sc.key,
                    inner=inner,
                    retry_policy=retry_policy,
                )
            )
        elif sc.kind == "streamable_http" and sc.streamable_http is not None:
            inner = _build_streamable_http_server(sc)
            servers.append(
                NamespacedMcpServer(
                    server_key=sc.key,
                    inner=inner,
                    retry_policy=retry_policy,
                )
            )
    return servers
