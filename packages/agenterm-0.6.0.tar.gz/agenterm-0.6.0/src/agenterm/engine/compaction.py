"""Responses compaction helpers for provider compaction endpoints."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from openai import OpenAIError

from agenterm.core.errors import AgentermError
from agenterm.core.gateway_client import get_gateway_client
from agenterm.core.model_id import (
    model_plane,
    openai_model_name,
    split_gateway_model_id,
)
from agenterm.core.openai_client import get_openai_client
from agenterm.engine.compaction_decode import (
    snapshot_items_from_compacted_response,
    usage_from_compacted_response,
)
from agenterm.engine.input_projection import project_items_for_openai_responses_protocol
from agenterm.engine.model_provider import gateway_route_for_model

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.items import TResponseInputItem
    from openai.types.responses.compacted_response import CompactedResponse

    from agenterm.config.model import AppConfig
    from agenterm.core.token_usage import TokenUsage


@dataclass(frozen=True)
class CompactionResult:
    """Result of a compaction request."""

    compaction_response_id: str
    snapshot_items: list[TResponseInputItem]
    usage: TokenUsage | None


async def compact(
    *,
    input_items: Sequence[TResponseInputItem],
    cfg: AppConfig,
    model_id: str,
    instructions: str | None,
) -> CompactionResult:
    """Run Responses compaction and return a compacted history snapshot."""
    if not input_items:
        msg = "Compaction requires at least one input item."
        raise AgentermError(msg)
    plane = model_plane(model_id)
    sanitized_items = project_items_for_openai_responses_protocol(list(input_items))
    if not sanitized_items:
        msg = "Compaction input became empty after OpenAI reasoning sanitization."
        raise AgentermError(msg)
    if plane == "openai":
        normalized_model = openai_model_name(model_id)
        client = get_openai_client()
    else:
        route_info = gateway_route_for_model(cfg.providers, model_id=model_id)
        if route_info is None:
            msg = f"Unknown gateway route for model id {model_id!r}."
            raise AgentermError(msg)
        route, route_cfg = route_info
        _, model = split_gateway_model_id(model_id)
        normalized_model = (
            model
            if route_cfg.protocol == "openai_responses"
            else f"{route_cfg.provider}/{model}"
        )
        client = get_gateway_client(route=route, route_cfg=route_cfg)
    try:
        resp: CompactedResponse = await client.responses.compact(
            model=normalized_model,
            input=sanitized_items,
            instructions=instructions,
        )
    except OpenAIError as exc:
        msg = f"Failed to compact history for model {model_id!r}: {exc}"
        raise AgentermError(msg) from exc

    snapshot_items = snapshot_items_from_compacted_response(resp)
    usage = usage_from_compacted_response(resp)

    return CompactionResult(
        compaction_response_id=resp.id,
        snapshot_items=snapshot_items,
        usage=usage,
    )


__all__ = ("CompactionResult", "compact", "snapshot_items_from_compacted_response")
