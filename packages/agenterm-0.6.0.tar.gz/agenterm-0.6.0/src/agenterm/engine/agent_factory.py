"""Build Agents `Agent` instances from AppConfig for the CLI."""

from __future__ import annotations

from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Final

from agents.agent import Agent, MCPConfig

from agenterm.constants.tools import (
    TOOL_TYPE_FILE_SEARCH,
    TOOL_TYPE_FUNCTION,
    TOOL_TYPE_HOSTED_MCP,
    TOOL_TYPE_IMAGE_GENERATION,
    TOOL_TYPE_WEB_SEARCH,
)
from agenterm.core.errors import ValidationError
from agenterm.core.function_tools import resolve_function_tools
from agenterm.core.model_id import model_plane
from agenterm.engine.agent_run_report_tool import build_agent_run_report_tool
from agenterm.engine.agent_run_tool import build_agent_run_tool
from agenterm.engine.cli_tools import (
    build_bat_tool,
    build_fd_tool,
    build_read_bytes_tool,
    build_rg_tool,
    build_stat_tool,
    build_tree_tool,
)
from agenterm.engine.function_tool_wrappers import (
    build_apply_patch_function_tool,
    build_shell_function_tool,
)
from agenterm.engine.info_tool import build_info_tool
from agenterm.engine.inspect import build_inspect_tool
from agenterm.engine.mcp_bridge import wrap_mcp_servers
from agenterm.engine.output_schema import build_output_schema_from_text_format
from agenterm.engine.plan_tool import build_plan_tool
from agenterm.engine.tool_builders import (
    build_file_search_tool,
    build_hosted_mcp_tools,
    build_image_generation_tool,
    build_web_search_tool,
)
from agenterm.engine.tool_output_clamp import ToolOutputClamp
from agenterm.steward.tool import build_steward_tool

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from agents.mcp import MCPServer
    from agents.model_settings import ModelSettings
    from agents.tool import FunctionTool, Tool

    from agenterm.config.model import AppConfig, ToolsConfig
    from agenterm.core.approvals import ApprovalsContext
    from agenterm.core.toolspec import ToolSpec

_HOSTED_MCP_KEY_PREFIX: Final[str] = "hosted:mcp:"


def _maybe_add_tool(tools: list[Tool], tool: Tool | None) -> None:
    if tool is None:
        return
    tools.append(tool)


def _inspect_operation_tools(
    *,
    cfg: AppConfig,
    root: Path,
    selected_specs: Sequence[ToolSpec],
) -> dict[str, FunctionTool]:
    tools = [
        build_rg_tool(workspace_root=root),
        build_fd_tool(workspace_root=root),
        build_bat_tool(workspace_root=root),
        build_read_bytes_tool(workspace_root=root),
        build_tree_tool(workspace_root=root),
        build_stat_tool(workspace_root=root),
        build_info_tool(
            cfg,
            workspace_root=root,
            selected_specs=selected_specs,
        ),
    ]
    return {tool.name: tool for tool in tools}


def _build_inspect_function_tool(
    *,
    cfg: AppConfig,
    tools_cfg: ToolsConfig,
    root: Path,
    selected_specs: Sequence[ToolSpec],
) -> Tool | None:
    operation_tools = _inspect_operation_tools(
        cfg=cfg,
        root=root,
        selected_specs=selected_specs,
    )
    return build_inspect_tool(
        tools_cfg.inspect,
        tools=operation_tools,
        max_chars=tools_cfg.max_chars,
    )


def _builtin_tool_builders(
    *,
    cfg: AppConfig,
    tools_cfg: ToolsConfig,
    root: Path,
    approvals: ApprovalsContext,
    selected_specs: Sequence[ToolSpec],
) -> dict[str, Callable[[], Tool | None]]:
    return {
        TOOL_TYPE_FILE_SEARCH: partial(build_file_search_tool, tools_cfg.file_search),
        TOOL_TYPE_WEB_SEARCH: partial(build_web_search_tool, tools_cfg.web_search),
        "shell": partial(
            build_shell_function_tool,
            tools_cfg.shell,
            workspace_root=root,
            approvals=approvals.shell,
        ),
        "apply_patch": partial(
            build_apply_patch_function_tool,
            tools_cfg.apply_patch,
            workspace_root=root,
            approvals=approvals.patch,
        ),
        "inspect": partial(
            _build_inspect_function_tool,
            cfg=cfg,
            tools_cfg=tools_cfg,
            root=root,
            selected_specs=selected_specs,
        ),
        "plan": partial(build_plan_tool, tools_cfg.plan),
        "agent_run": partial(
            build_agent_run_tool,
            cfg,
            workspace_root=root,
            agent_builder=build_agent_from_config,
        ),
        "agent_run_report": partial(
            build_agent_run_report_tool,
            tools_cfg.agent_run_report,
        ),
        "steward": partial(build_steward_tool, cfg),
        TOOL_TYPE_IMAGE_GENERATION: partial(
            build_image_generation_tool,
            tools_cfg.image_generation,
        ),
    }


def _build_selected_builtin_tools(
    selected: list[ToolSpec],
    *,
    cfg: AppConfig,
    tools_cfg: ToolsConfig,
    root: Path,
    approvals: ApprovalsContext,
) -> list[Tool]:
    builders = _builtin_tool_builders(
        cfg=cfg,
        tools_cfg=tools_cfg,
        root=root,
        approvals=approvals,
        selected_specs=selected,
    )
    tools: list[Tool] = []
    for spec in selected:
        builder = builders.get(spec.type)
        if builder is None:
            continue
        _maybe_add_tool(tools, builder())
    return tools


def _hosted_mcp_connector_name_from_key(key: str) -> str | None:
    if not key.startswith(_HOSTED_MCP_KEY_PREFIX):
        return None
    name = key[len(_HOSTED_MCP_KEY_PREFIX) :].strip()
    return name or None


def _selected_hosted_mcp_connector_names(
    selected: list[ToolSpec],
) -> tuple[str, ...]:
    out: list[str] = []
    for spec in selected:
        if spec.type != TOOL_TYPE_HOSTED_MCP:
            continue
        name = _hosted_mcp_connector_name_from_key(str(spec.key))
        if name is not None:
            out.append(name)
    return tuple(out)


def _selected_function_names(
    selected: list[ToolSpec],
) -> tuple[str, ...]:
    out: list[str] = []
    for spec in selected:
        if spec.type != TOOL_TYPE_FUNCTION:
            continue
        name = (spec.name or "").strip()
        if name:
            out.append(name)
    return tuple(out)


def build_agent_from_config(
    cfg: AppConfig,
    *,
    selected_tools: list[ToolSpec] | None,
    approvals: ApprovalsContext,
    workspace_root: Path | None = None,
    mcp_servers: list[MCPServer] | None = None,
) -> Agent:
    """Construct an Agents Agent from AppConfig."""
    model_name = cfg.agent.model
    plane = model_plane(model_name)
    model_settings: ModelSettings = cfg.to_model_settings()
    output_schema = build_output_schema_from_text_format(cfg.model.text_format)

    tools_cfg = cfg.tools

    root = workspace_root or Path.cwd()

    selected = list(selected_tools) if selected_tools is not None else []
    if plane == "gateway":
        hosted = [spec.key for spec in selected if spec.plane == "hosted"]
        if hosted:
            msg = (
                "Gateway models do not support hosted tools. "
                f"Remove: {', '.join(hosted)}"
            )
            raise ValidationError(msg)
    tools = _build_selected_builtin_tools(
        selected,
        cfg=cfg,
        tools_cfg=tools_cfg,
        root=root,
        approvals=approvals,
    )

    selected_hosted_mcp_names = _selected_hosted_mcp_connector_names(selected)
    if selected_hosted_mcp_names:
        selected_set = set(selected_hosted_mcp_names)
        connectors = [tc for tc in cfg.mcp.connectors if tc.name in selected_set]
        tools.extend(build_hosted_mcp_tools(connectors, approvals=approvals.mcp))

    selected_func_names = _selected_function_names(selected)
    if selected_func_names:
        tools.extend(resolve_function_tools(list(selected_func_names)))

    clamp = ToolOutputClamp(cfg.tools.max_chars)
    tools = clamp.wrap_tools(tools)

    mcp_servers_effective = list(mcp_servers) if mcp_servers is not None else []
    if mcp_servers_effective:
        mcp_servers_effective = wrap_mcp_servers(
            mcp_servers_effective,
            approvals=approvals.mcp,
            bridge_cfg=cfg.mcp.bridge,
            output_clamp=clamp,
        )
    mcp_cfg: MCPConfig = {
        "convert_schemas_to_strict": cfg.mcp.convert_schemas_to_strict,
    }

    return Agent(
        name=cfg.agent.name,
        instructions=cfg.agent.instructions,
        model=model_name,
        model_settings=model_settings,
        tools=tools,
        mcp_servers=mcp_servers_effective,
        mcp_config=mcp_cfg,
        output_type=output_schema,
    )
