"""Payload builders for Responses input items."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from agenterm.engine.input_parts import build_attachment_parts

if TYPE_CHECKING:
    from collections.abc import Sequence

    from openai.types.responses.response_input_message_content_list_param import (
        ResponseInputMessageContentListParam,
    )
    from openai.types.responses.response_input_param import (
        Message,
        ResponseInputParam,
    )
    from openai.types.responses.response_input_text_param import (
        ResponseInputTextParam,
    )

    from agenterm.config.model import AppConfig


def _text_item(text: str) -> ResponseInputTextParam:
    type_val: Literal["input_text"] = "input_text"
    return {"type": type_val, "text": text}


async def build_from_prompt_and_attachments(
    *,
    cfg: AppConfig,
    model_id: str,
    prompt: str,
    attachments: Sequence[str],
    max_text_bytes: int | None = None,
) -> ResponseInputParam:
    """Construct one explicit user message from prompt text and attachments."""
    items: ResponseInputMessageContentListParam = []
    if prompt:
        items.append(_text_item(prompt))
    if attachments:
        parts = await build_attachment_parts(
            cfg,
            model_id=model_id,
            attachments=attachments,
            max_text_bytes=max_text_bytes,
        )
        items.extend(parts)
    msg: Message = {"type": "message", "role": "user", "content": items}
    payload: ResponseInputParam = [msg]
    return payload


__all__ = ("build_from_prompt_and_attachments",)
