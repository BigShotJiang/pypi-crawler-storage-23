"""Helpers for inspecting background Responses by id.

This module provides a thin, explicit surface for retrieving a single
Responses `Response` object by `response_id` using the same OpenAI client
machinery that the Agents engine relies on.

It intentionally avoids introducing a second engine path for normal runs:
background inspection is read-only and does not mutate Agents sessions.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING

from openai import OpenAIError
from openai.types.responses import (
    ResponseCompletedEvent,
    ResponseCreatedEvent,
    ResponseFailedEvent,
    ResponseTextDeltaEvent,
)

from agenterm.constants.include import DEFAULT_RESPONSE_INCLUDE
from agenterm.core.errors import AgentermError
from agenterm.core.json_codec import is_json_object
from agenterm.core.openai_client import get_openai_client

if TYPE_CHECKING:
    from collections.abc import AsyncIterator
    from typing import Literal

    from openai.types.responses import Response
    from openai.types.responses.response_item import ResponseItem
    from openai.types.responses.response_stream_event import ResponseStreamEvent

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class ResponseInputItemsPage:
    """One page of server-side input items for a response."""

    items: tuple[Mapping[str, JSONValue], ...]
    has_more: bool
    next_after: str | None
    order: Literal["asc", "desc"]
    limit: int


def _serialize_response_item(item: ResponseItem) -> dict[str, JSONValue]:
    payload = item.model_dump(
        mode="json",
        by_alias=True,
        exclude_none=False,
    )
    if not is_json_object(value=payload):
        msg = "Response input item is not JSON-safe."
        raise AgentermError(msg)
    return dict(payload)


async def retrieve_response(response_id: str) -> Response:
    """Retrieve a single Responses `Response` by id.

    Raises:
      AgentermError: When the underlying client raises an OpenAIError.

    """
    client = get_openai_client()
    try:
        return await client.responses.retrieve(response_id=response_id)
    except OpenAIError as exc:  # pragma: no cover - defensive mapping
        message = f"Failed to retrieve response {response_id!r}: {exc}"
        raise AgentermError(message) from exc


async def retrieve_response_input_items(
    response_id: str,
    *,
    after: str | None = None,
    limit: int = 20,
    order: Literal["asc", "desc"] = "desc",
) -> ResponseInputItemsPage:
    """Retrieve one page of input items for a Responses object."""
    client = get_openai_client()
    include = list(DEFAULT_RESPONSE_INCLUDE)
    try:
        if after is None:
            page = await client.responses.input_items.list(
                response_id=response_id,
                include=include,
                limit=limit,
                order=order,
            )
        else:
            page = await client.responses.input_items.list(
                response_id=response_id,
                after=after,
                include=include,
                limit=limit,
                order=order,
            )
    except OpenAIError as exc:  # pragma: no cover - defensive mapping
        message = f"Failed to retrieve response input items {response_id!r}: {exc}"
        raise AgentermError(message) from exc

    page_info = page.next_page_info()
    next_after: str | None = None
    if page_info is not None and isinstance(page_info.params, Mapping):
        candidate = page_info.params.get("after")
        if isinstance(candidate, str) and candidate:
            next_after = candidate
    return ResponseInputItemsPage(
        items=tuple(_serialize_response_item(item) for item in page.data),
        has_more=page.has_next_page(),
        next_after=next_after,
        order=order,
        limit=limit,
    )


def render_response_summary(resp: Response) -> str:
    """Render a concise, human-readable summary for a Responses object.

    The goal is to provide enough information to understand the outcome of
    a background run without duplicating the richer formatting logic used
    by the main `run` command.
    """
    lines: list[str] = []
    lines.append(f"response_id: {resp.id}")
    lines.append(f"model: {resp.model}")
    if resp.background is True:
        lines.append("background: true")
    status = resp.status
    if isinstance(status, str):
        lines.append(f"status: {status}")
    usage = resp.usage
    if usage is not None:
        lines.append(
            f"usage: in={usage.input_tokens} out={usage.output_tokens} "
            f"total={usage.total_tokens}",
        )
    text = resp.output_text or ""
    if text:
        lines.append("")
        lines.append("output:")
        lines.append("")
        lines.append(text)
    return "\n".join(lines)


async def retrieve_response_stream(
    response_id: str,
    starting_after: int | None = None,
) -> AsyncIterator[ResponseStreamEvent]:
    """Stream events for a Responses response.

    Args:
        response_id: The response ID to retrieve.
        starting_after: Sequence number to resume from (optional).

    Yields:
        ResponseStreamEvent objects as they arrive.

    Raises:
        AgentermError: When the underlying client raises an error.

    """
    client = get_openai_client()
    try:
        # Use explicit branching to satisfy pyright's overload resolution
        if starting_after is not None:
            stream = await client.responses.retrieve(
                response_id=response_id,
                stream=True,
                starting_after=starting_after,
            )
        else:
            stream = await client.responses.retrieve(
                response_id=response_id,
                stream=True,
            )
        async for event in stream:
            yield event
    except OpenAIError as exc:  # pragma: no cover - defensive mapping
        message = f"Failed to stream response {response_id!r}: {exc}"
        raise AgentermError(message) from exc


def render_stream_event(event: ResponseStreamEvent) -> str | None:
    """Render a single stream event for terminal output.

    Returns None for events that should not produce output.
    Uses isinstance checks for type-safe attribute access.
    """
    if isinstance(event, ResponseCreatedEvent):
        return f"[streaming response {event.response.id}]\n"
    if isinstance(event, ResponseTextDeltaEvent):
        return event.delta
    if isinstance(event, ResponseCompletedEvent):
        return f"\n[completed: {event.response.status}]"
    if isinstance(event, ResponseFailedEvent):
        error = event.response.error
        error_msg = str(error) if error else "unknown"
        return f"\n[failed: {error_msg}]"
    # Silent for other event types (response.in_progress, etc.)
    return None


__all__ = (
    "ResponseInputItemsPage",
    "render_response_summary",
    "render_stream_event",
    "retrieve_response",
    "retrieve_response_input_items",
    "retrieve_response_stream",
)
