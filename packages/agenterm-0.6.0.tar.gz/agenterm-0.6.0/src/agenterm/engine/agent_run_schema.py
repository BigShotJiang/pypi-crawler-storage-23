"""Schema constants for agent_run reporting."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue

AGENT_RUN_REPORT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "agent_run report payload.",
    "properties": {
        "tool_call_id": {
            "type": "string",
            "description": "Tool call id for this agent_run.",
        },
        "trace_id": {
            "type": ["string", "null"],
            "description": "Trace id, if available.",
        },
        "created_at": {
            "type": "string",
            "description": "RFC3339 timestamp.",
        },
        "model": {
            "type": "string",
            "description": "Delegated model id.",
        },
        "instructions": {
            "type": "string",
            "description": "Delegated instructions.",
        },
        "input": {
            "type": "string",
            "description": "Input text.",
        },
        "input_items": {
            "type": "array",
            "items": {},
            "description": "Serialized input items.",
        },
        "output_text": {
            "type": ["string", "null"],
            "description": "Final output text, if any.",
        },
        "output_items": {
            "type": "array",
            "items": {},
            "description": "Serialized output items.",
        },
        "tools_available": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Tools available to the delegate.",
        },
        "tools_used": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Tools used by the delegate.",
        },
        "tool_counts": {
            "type": "object",
            "description": "Tool call counts by name.",
        },
        "truncated": {
            "type": "boolean",
            "description": "True if output was truncated.",
        },
        "warnings": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Run warnings.",
        },
        "usage": {
            "type": "object",
            "description": "Token usage.",
        },
        "response_id": {
            "type": ["string", "null"],
            "description": "Primary response id, if available.",
        },
        "response_ids": {
            "type": "array",
            "items": {"type": "string"},
            "description": "All response ids captured.",
        },
    },
    "required": [
        "tool_call_id",
        "trace_id",
        "created_at",
        "model",
        "instructions",
        "input",
        "input_items",
        "output_text",
        "output_items",
        "tools_available",
        "tools_used",
        "tool_counts",
        "truncated",
        "warnings",
        "usage",
        "response_id",
        "response_ids",
    ],
    "additionalProperties": False,
}


__all__ = ("AGENT_RUN_REPORT_SCHEMA",)
