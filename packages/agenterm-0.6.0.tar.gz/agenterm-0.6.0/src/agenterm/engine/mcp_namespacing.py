"""MCP tool name rewriting for OpenAI + Agents compatibility.

Local MCP tools are discovered from MCP servers and exposed to the model as
OpenAI function tools. That implies two hard constraints:

1) OpenAI function names must match the platform's function-name contract
   (character set + max length).
2) The Agents SDK requires tool names to be globally unique across selected
   MCP servers (it raises on duplicates).

This module provides a small, deterministic adapter:
- Rewrite MCP tool names returned by `list_tools()` so they are always valid and
  globally unique (`mcp__...`).
- Map rewritten names back to the original server-provided name for `call_tool()`.
"""

from __future__ import annotations

import asyncio
import hashlib
import re
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING, TypeVar

import httpx
from agents.mcp import MCPServer

from agenterm.core.errors import McpConnectError
from agenterm.core.retry import RetryDecision, RetryPolicy, retry_async

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable, Mapping

    from agents.agent import AgentBase
    from agents.run_context import RunContextWrapper
    from mcp import types as mtypes

    from agenterm.core.json_types import JSONValue

T = TypeVar("T")


_OPENAI_FUNCTION_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_OPENAI_FUNCTION_NAME_MAX_LEN = 64
_FALLBACK_HASH_LEN = 10
_EMPTY_MAPPING: Mapping[str, str] = MappingProxyType({})
_MCP_RETRY_ON: tuple[type[Exception], ...] = (
    OSError,
    asyncio.TimeoutError,
    httpx.HTTPError,
)


def _is_openai_function_name(name: str) -> bool:
    """Return True when `name` satisfies the OpenAI function-name contract."""
    return _OPENAI_FUNCTION_NAME_RE.match(name) is not None


def _short_hash(text: str) -> str:
    """Return a stable short hex hash for `text` (ASCII-safe, deterministic)."""
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return digest[:_FALLBACK_HASH_LEN]


def _slugify(text: str) -> str:
    """Normalize text into the OpenAI function-name character set.

    - Replace disallowed characters with "_".
    - Collapse runs of "_" and trim leading/trailing "_" for readability.
    - Guarantee non-empty output.
    """
    cleaned = re.sub(r"[^A-Za-z0-9_-]", "_", text.strip())
    collapsed = re.sub(r"_+", "_", cleaned).strip("_")
    return collapsed or "x"


def _fallback_tool_name(*, server_key: str, tool_name: str) -> str:
    """Return a valid OpenAI function name for an MCP tool via slug+hash fallback."""
    server_slug = _slugify(server_key)
    tool_slug = _slugify(tool_name)
    server_hash = _short_hash(server_key)
    tool_hash = _short_hash(tool_name)

    prefix = "mcp__"
    sep = "__"
    join = "_"

    def build(s_slug: str, t_slug: str) -> str:
        return f"{prefix}{s_slug}{join}{server_hash}{sep}{t_slug}{join}{tool_hash}"

    # Bounded initial slugs so we don't waste cycles on huge inputs.
    server_slug = server_slug[:32]
    tool_slug = tool_slug[:48]

    candidate = build(server_slug, tool_slug)
    if len(candidate) <= _OPENAI_FUNCTION_NAME_MAX_LEN:
        return candidate

    # Prefer retaining some of the server label, but make room for the tool.
    server_slug = server_slug[:16]
    fixed_len = (
        len(prefix)
        + len(server_slug)
        + len(join)
        + len(server_hash)
        + len(sep)
        + len(join)
        + len(tool_hash)
    )
    tool_budget = _OPENAI_FUNCTION_NAME_MAX_LEN - fixed_len
    if tool_budget >= 1:
        return build(server_slug, tool_slug[:tool_budget])

    # Pathological case: keep the hashes and drop most of the slugs.
    hash_only = f"{prefix}{server_hash}{sep}{tool_hash}"
    if _is_openai_function_name(hash_only):
        return hash_only

    # This should be unreachable: hash_only is ASCII and well under 64 chars.
    msg = (
        "Failed to build a valid MCP tool name "
        f"(server_key={server_key!r}, tool={tool_name!r})"
    )
    raise McpConnectError(msg)


def namespace_mcp_tool_name(*, server_key: str, tool_name: str) -> str:
    """Return the model-visible name for an MCP tool.

    Contract:
    - Always returns a valid OpenAI function name (allowed charset, max length 64).
    - Always starts with `mcp__` so UIs can group MCP tools by prefix.
    - Deterministic for a given `(server_key, tool_name)` pair.
    """
    raw = f"mcp__{server_key}__{tool_name}"
    if _is_openai_function_name(raw):
        return raw
    return _fallback_tool_name(server_key=server_key, tool_name=tool_name)


@dataclass
class NamespacedMcpServer(MCPServer):
    """MCPServer wrapper that rewrites tool names to be model-safe and unique."""

    server_key: str
    inner: MCPServer
    retry_policy: RetryPolicy | None = None
    _namespaced_to_original: Mapping[str, str] = field(
        default_factory=lambda: _EMPTY_MAPPING,
    )

    def __post_init__(self) -> None:
        """Initialize the MCPServer base class using the inner server config."""
        super().__init__(
            use_structured_content=self.inner.use_structured_content,
            tool_meta_resolver=self.inner.tool_meta_resolver,
        )

    @property
    def name(self) -> str:
        """A readable name for the server (delegated)."""
        return self.inner.name

    async def connect(self) -> None:
        """Connect the inner server."""
        await self.inner.connect()

    async def cleanup(self) -> None:
        """Cleanup the inner server."""
        await self.inner.cleanup()

    async def _call_with_retries(self, func: Callable[[], Awaitable[T]]) -> T:
        policy = self.retry_policy
        if policy is None:
            return await func()

        def _classify(exc: Exception) -> RetryDecision:
            if isinstance(exc, asyncio.CancelledError):
                return RetryDecision(retry=False, label="mcp_cancelled")
            return RetryDecision(retry=True, label="mcp_error")

        return await retry_async(
            func,
            policy=policy,
            retry_on=_MCP_RETRY_ON,
            classify=_classify,
        )

    async def list_tools(
        self,
        run_context: RunContextWrapper | None = None,
        agent: AgentBase | None = None,
    ) -> list[mtypes.Tool]:
        """List tools from the inner server and rewrite their names."""

        async def _call() -> list[mtypes.Tool]:
            return await self.inner.list_tools(run_context=run_context, agent=agent)

        tools_raw = await self._call_with_retries(_call)
        tools: list[mtypes.Tool] = list(tools_raw)

        mapping: dict[str, str] = {}
        out: list[mtypes.Tool] = []
        for tool in tools:
            original_name = tool.name
            namespaced = namespace_mcp_tool_name(
                server_key=self.server_key,
                tool_name=original_name,
            )
            mapping[namespaced] = original_name
            out.append(tool.model_copy(update={"name": namespaced}))

        self._namespaced_to_original = MappingProxyType(dict(mapping))
        return out

    async def call_tool(
        self,
        tool_name: str,
        arguments: Mapping[str, JSONValue] | None,
        meta: Mapping[str, JSONValue] | None = None,
    ) -> mtypes.CallToolResult:
        """Call an MCP tool, mapping the model-visible name back to the original."""
        original = self.resolve_original_tool_name(tool_name)
        args_dict = dict(arguments) if arguments is not None else None
        meta_dict = dict(meta) if meta is not None else None

        async def _call() -> mtypes.CallToolResult:
            return await self.inner.call_tool(original, args_dict, meta=meta_dict)

        return await self._call_with_retries(_call)

    def resolve_original_tool_name(self, tool_name: str) -> str:
        """Return the original MCP tool name for a model-visible name."""
        original = self._namespaced_to_original.get(tool_name)
        if original is not None:
            return original
        raw_prefix = f"mcp__{self.server_key}__"
        if tool_name.startswith(raw_prefix):
            return tool_name[len(raw_prefix) :]
        return tool_name

    async def list_prompts(self) -> mtypes.ListPromptsResult:
        """Delegate prompt listing to the inner server."""
        return await self.inner.list_prompts()

    async def get_prompt(
        self,
        name: str,
        arguments: Mapping[str, JSONValue] | None = None,
    ) -> mtypes.GetPromptResult:
        """Delegate prompt retrieval to the inner server."""
        args_dict = dict(arguments) if arguments is not None else None
        return await self.inner.get_prompt(name, args_dict)


__all__ = ("NamespacedMcpServer", "namespace_mcp_tool_name")
