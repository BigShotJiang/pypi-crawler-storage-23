"""agent_run schema and payload parsing helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.json_codec import as_str, parse_json_object

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agenterm.core.json_types import JSONValue

AGENT_RUN_OP_RUN = "run"
AGENT_RUN_OP_DISCOVER_MODELS = "discover_models"

AGENT_RUN_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": (
        "Delegated sub-agent invocation for focused tasks or model-catalog discovery."
    ),
    "properties": {
        "op": {
            "type": "string",
            "enum": [AGENT_RUN_OP_RUN, AGENT_RUN_OP_DISCOVER_MODELS],
        },
        "model": {"type": ["string", "null"], "minLength": 1},
        "instructions": {"type": ["string", "null"], "minLength": 1},
        "input": {"type": ["string", "null"], "minLength": 1},
        "max_turns": {"type": ["integer", "null"], "minimum": 1},
    },
    "required": ["op", "model", "instructions", "input", "max_turns"],
    "additionalProperties": False,
}

_RUN_FIELDS = {"op", "model", "instructions", "input", "max_turns"}
_RUN_REQUIRED_NON_NULL = ("model", "instructions", "input")
_ALLOWED_OPS = (AGENT_RUN_OP_RUN, AGENT_RUN_OP_DISCOVER_MODELS)


def _json_string_list(values: Sequence[str]) -> list[JSONValue]:
    items: list[JSONValue] = []
    items.extend(values)
    return items


@dataclass(frozen=True)
class AgentRunArgs:
    """Parsed agent_run run-mode arguments."""

    model: str
    instructions: str
    input_text: str
    max_turns: int | None


@dataclass(frozen=True)
class AgentRunPayload:
    """Parsed agent_run payload with mode discriminator."""

    args: AgentRunArgs | None
    discovery_requested: bool


@dataclass(frozen=True)
class AgentRunParseError:
    """Typed parse failure for agent_run input payloads."""

    message: str
    details: dict[str, JSONValue]


def _required_nonempty_str(
    payload: Mapping[str, JSONValue],
    *,
    key: str,
) -> str | None:
    raw = as_str(payload.get(key))
    if raw is None:
        return None
    value = raw.strip()
    if not value:
        return None
    return value


def _invalid_payload_error() -> AgentRunParseError:
    return AgentRunParseError(
        message="Invalid agent_run payload.",
        details={
            "field": "payload",
            "reason": "invalid_payload",
            "allowed_ops": _json_string_list(list(_ALLOWED_OPS)),
            "example": {
                "op": AGENT_RUN_OP_DISCOVER_MODELS,
                "model": None,
                "instructions": None,
                "input": None,
                "max_turns": None,
            },
        },
    )


def _parse_discovery_payload(
    payload: Mapping[str, JSONValue],
) -> tuple[AgentRunPayload | None, AgentRunParseError | None]:
    unknown_keys = sorted(set(payload) - _RUN_FIELDS)
    if unknown_keys:
        allowed_keys = _json_string_list(sorted(_RUN_FIELDS))
        return None, AgentRunParseError(
            message="Invalid agent_run payload.",
            details={
                "field": "payload",
                "reason": "unknown_keys",
                "unknown_keys": _json_string_list(unknown_keys),
                "allowed_keys": allowed_keys,
            },
        )
    must_be_null: list[JSONValue] = [
        key
        for key in ("model", "instructions", "input", "max_turns")
        if payload.get(key) is not None
    ]
    if must_be_null:
        return None, AgentRunParseError(
            message="agent_run discover_models requires all non-op fields to be null.",
            details={
                "field": "payload",
                "reason": "must_be_null",
                "op": AGENT_RUN_OP_DISCOVER_MODELS,
                "must_be_null": must_be_null,
                "required_non_null": _json_string_list(()),
                "example": {
                    "op": AGENT_RUN_OP_DISCOVER_MODELS,
                    "model": None,
                    "instructions": None,
                    "input": None,
                    "max_turns": None,
                },
            },
        )
    return AgentRunPayload(args=None, discovery_requested=True), None


def _parse_run_payload(
    payload: Mapping[str, JSONValue],
) -> tuple[AgentRunPayload | None, AgentRunParseError | None]:
    unknown_keys = sorted(set(payload) - _RUN_FIELDS)
    if unknown_keys:
        allowed_keys = _json_string_list(sorted(_RUN_FIELDS))
        return None, AgentRunParseError(
            message="Invalid agent_run payload.",
            details={
                "field": "payload",
                "reason": "unknown_keys",
                "unknown_keys": _json_string_list(unknown_keys),
                "allowed_keys": allowed_keys,
            },
        )
    model = _required_nonempty_str(payload, key="model")
    instructions = _required_nonempty_str(payload, key="instructions")
    input_text = _required_nonempty_str(payload, key="input")
    if model is None or instructions is None or input_text is None:
        missing_fields: list[JSONValue] = []
        if model is None:
            missing_fields.append("model")
        if instructions is None:
            missing_fields.append("instructions")
        if input_text is None:
            missing_fields.append("input")
        required_non_null = _json_string_list(_RUN_REQUIRED_NON_NULL)
        return None, AgentRunParseError(
            message="agent_run requires model, instructions, and input strings.",
            details={
                "field": "payload",
                "reason": "required_non_null",
                "op": AGENT_RUN_OP_RUN,
                "required_non_null": required_non_null,
                "missing": missing_fields,
                "must_be_null": _json_string_list(()),
            },
        )
    max_turns_raw = payload.get("max_turns")
    max_turns: int | None = None
    if max_turns_raw is not None:
        if (
            not isinstance(max_turns_raw, int)
            or isinstance(max_turns_raw, bool)
            or max_turns_raw < 1
        ):
            return None, AgentRunParseError(
                message="agent_run max_turns must be an integer >= 1.",
                details={"field": "/max_turns", "reason": "invalid_value"},
            )
        max_turns = int(max_turns_raw)
    return (
        AgentRunPayload(
            args=AgentRunArgs(
                model=model,
                instructions=instructions,
                input_text=input_text,
                max_turns=max_turns,
            ),
            discovery_requested=False,
        ),
        None,
    )


def parse_agent_run_payload(
    raw: str,
) -> tuple[AgentRunPayload | None, AgentRunParseError | None]:
    """Parse and validate an agent_run payload."""
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, _invalid_payload_error()

    op = _required_nonempty_str(payload, key="op")
    if op is None:
        return None, AgentRunParseError(
            message="agent_run requires op.",
            details={
                "field": "op",
                "reason": "required_non_null",
                "required_non_null": _json_string_list(["op"]),
                "allowed_ops": _json_string_list(list(_ALLOWED_OPS)),
            },
        )
    if op == AGENT_RUN_OP_DISCOVER_MODELS:
        return _parse_discovery_payload(payload)
    if op == AGENT_RUN_OP_RUN:
        return _parse_run_payload(payload)
    return None, AgentRunParseError(
        message="Invalid agent_run op.",
        details={
            "field": "op",
            "reason": "invalid_value",
            "allowed_ops": _json_string_list(list(_ALLOWED_OPS)),
            "example": {
                "op": AGENT_RUN_OP_RUN,
                "model": "openai/gpt-5",
                "instructions": "goal + constraints + output format",
                "input": "task context",
                "max_turns": None,
            },
        },
    )


__all__ = (
    "AGENT_RUN_OP_DISCOVER_MODELS",
    "AGENT_RUN_OP_RUN",
    "AGENT_RUN_SCHEMA",
    "AgentRunArgs",
    "AgentRunParseError",
    "AgentRunPayload",
    "parse_agent_run_payload",
)
