"""Built-in plan tool for plan operations."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.core.errors import AgentermError
from agenterm.core.json_codec import parse_json_object
from agenterm.core.plan import (
    PlanOpGet,
    PlanOpReset,
    ToolRuntimeContext,
    apply_plan_op,
    parse_plan_request,
    plan_error_details,
)
from agenterm.core.tool_output_envelope import (
    ToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_plan
from agenterm.store.async_db import AsyncStore
from agenterm.store.plan.repo import (
    delete_plan_snapshots,
    get_latest_plan_snapshot,
    get_plan_series,
    insert_plan_snapshot,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.tool_context import ToolContext

    from agenterm.config.model import PlanToolConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import PlanMutation, PlanOp, PlanSeries, PlanSnapshot

_NON_WHITESPACE_PATTERN = r"\S"

_PLAN_STEP_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Plan step entry.",
    "properties": {
        "step_id": {
            "type": ["string", "null"],
            "pattern": _NON_WHITESPACE_PATTERN,
            "description": "Optional stable step id.",
        },
        "step": {
            "type": "string",
            "minLength": 1,
            "pattern": _NON_WHITESPACE_PATTERN,
            "description": "Step text shown to the user.",
        },
        "status": {
            "type": "string",
            "enum": ["pending", "in_progress", "completed"],
            "description": "Step status (only one in_progress).",
        },
    },
    "additionalProperties": False,
}

_PLAN_STATUS_SCHEMA: dict[str, JSONValue] = {
    "type": "string",
    "enum": ["pending", "in_progress", "completed"],
    "description": "Plan step status (only one in_progress).",
}

_PLAN_PLACEMENT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Where to place a new step in the plan.",
    "properties": {
        "mode": {"type": "string", "enum": ["append", "prepend", "before", "after"]},
        "anchor_step_id": {
            "type": ["string", "null"],
            "minLength": 1,
            "pattern": _NON_WHITESPACE_PATTERN,
        },
    },
    "required": ["mode", "anchor_step_id"],
    "additionalProperties": False,
}

_PLAN_UPDATE_PATCH_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Mutation patch for update operations.",
    "properties": {
        "kind": {"type": "string", "enum": ["step", "status", "both"]},
        "step": {
            "type": ["string", "null"],
            "minLength": 1,
            "pattern": _NON_WHITESPACE_PATTERN,
        },
        "status": {
            "type": ["string", "null"],
            "enum": ["pending", "in_progress", "completed", None],
        },
    },
    "required": ["kind", "step", "status"],
    "additionalProperties": False,
}

_PLAN_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Structured plan request payload.",
    "properties": {
        "op": {
            "type": "string",
            "enum": ["get", "set", "add", "update", "delete", "advance", "reset"],
        },
        "steps": {
            "type": ["array", "null"],
            "items": _PLAN_STEP_SCHEMA,
            "minItems": 1,
        },
        "explanation": {"type": ["string", "null"]},
        "step_id": {
            "type": ["string", "null"],
            "pattern": _NON_WHITESPACE_PATTERN,
        },
        "step": {
            "type": ["string", "null"],
            "minLength": 1,
            "pattern": _NON_WHITESPACE_PATTERN,
        },
        "status": {
            "type": ["string", "null"],
            "enum": ["pending", "in_progress", "completed", None],
        },
        "placement": {
            **_PLAN_PLACEMENT_SCHEMA,
            "type": ["object", "null"],
        },
        "patch": {
            **_PLAN_UPDATE_PATCH_SCHEMA,
            "type": ["object", "null"],
        },
        "completed_step_id": {
            "type": ["string", "null"],
            "pattern": _NON_WHITESPACE_PATTERN,
        },
        "next_step_id": {
            "type": ["string", "null"],
            "pattern": _NON_WHITESPACE_PATTERN,
        },
        "mode": {
            "type": ["string", "null"],
            "enum": ["delete", "empty", None],
        },
    },
    "required": [
        "op",
        "steps",
        "explanation",
        "step_id",
        "step",
        "status",
        "placement",
        "patch",
        "completed_step_id",
        "next_step_id",
        "mode",
    ],
    "additionalProperties": False,
}

_PLAN_FLAT_KEYS: frozenset[str] = frozenset(
    {
        "op",
        "steps",
        "explanation",
        "step_id",
        "step",
        "status",
        "placement",
        "patch",
        "completed_step_id",
        "next_step_id",
        "mode",
    }
)
_PLAN_KEYS_BY_OP: dict[str, frozenset[str]] = {
    "get": frozenset({"op"}),
    "set": frozenset({"op", "steps", "explanation"}),
    "add": frozenset({"op", "step_id", "step", "status", "placement"}),
    "update": frozenset({"op", "step_id", "patch"}),
    "delete": frozenset({"op", "step_id"}),
    "advance": frozenset({"op", "completed_step_id", "next_step_id"}),
    "reset": frozenset({"op", "mode"}),
}
_PLAN_REQUIRED_NON_NULL_BY_OP: dict[str, tuple[str, ...]] = {
    "get": (),
    "set": ("steps",),
    "add": ("step", "status", "placement"),
    "update": ("step_id", "patch"),
    "delete": ("step_id",),
    "advance": ("next_step_id",),
    "reset": ("mode",),
}
_PLAN_EXAMPLE_BY_OP: dict[str, dict[str, JSONValue]] = {
    "get": {"op": "get"},
    "set": {
        "op": "set",
        "steps": [{"step_id": None, "step": "Draft", "status": "in_progress"}],
        "explanation": None,
    },
    "add": {
        "op": "add",
        "step_id": None,
        "step": "Draft",
        "status": "pending",
        "placement": {"mode": "append", "anchor_step_id": None},
    },
    "update": {
        "op": "update",
        "step_id": "step-1",
        "patch": {"kind": "status", "step": None, "status": "completed"},
    },
    "delete": {"op": "delete", "step_id": "step-1"},
    "advance": {"op": "advance", "completed_step_id": None, "next_step_id": "step-2"},
    "reset": {"op": "reset", "mode": "empty"},
}

_INVALID_MESSAGE = "Invalid plan payload."
_INVALID_INPUT_KIND = "invalid_input"
_TOOL_ERROR_KIND = "tool_error"


def _json_string_list(values: Sequence[str]) -> list[JSONValue]:
    items: list[JSONValue] = []
    items.extend(values)
    return items


def _error_output(message: str, *, details: Mapping[str, JSONValue]) -> str:
    err = ToolOutputError(
        kind=_INVALID_INPUT_KIND,
        message=message,
        details=dict(details),
    )
    env = ToolOutputEnvelope(
        tool="plan",
        ok=False,
        result={},
        error=err,
    )
    return env.to_json_string()


def _tool_error_output(message: str, *, details: Mapping[str, JSONValue]) -> str:
    err = ToolOutputError(
        kind=_TOOL_ERROR_KIND,
        message=message,
        details=dict(details),
    )
    env = ToolOutputEnvelope(
        tool="plan",
        ok=False,
        result={},
        error=err,
    )
    return env.to_json_string()


def _normalize_flat_plan_payload(
    payload: Mapping[str, JSONValue],
) -> tuple[dict[str, JSONValue] | None, str | None]:
    unknown_keys = sorted(set(payload) - _PLAN_FLAT_KEYS)
    if unknown_keys:
        allowed_keys = _json_string_list(sorted(_PLAN_FLAT_KEYS))
        allowed_ops = _json_string_list(sorted(_PLAN_KEYS_BY_OP))
        return None, _error_output(
            _INVALID_MESSAGE,
            details={
                "field": "/",
                "reason": "unknown_keys",
                "unknown_keys": _json_string_list(unknown_keys),
                "allowed_keys": allowed_keys,
                "allowed_ops": allowed_ops,
            },
        )
    op_raw = payload.get("op")
    request: dict[str, JSONValue] = {"op": op_raw}
    if not isinstance(op_raw, str):
        return request, None
    allowed = _PLAN_KEYS_BY_OP.get(op_raw)
    if allowed is None:
        return request, None
    must_be_null_names = sorted((_PLAN_FLAT_KEYS - allowed) - {"op"})
    required_non_null_names = list(_PLAN_REQUIRED_NON_NULL_BY_OP.get(op_raw, ()))
    must_be_null = _json_string_list(must_be_null_names)
    required_non_null = _json_string_list(required_non_null_names)
    for key in must_be_null_names:
        if payload.get(key) is not None:
            return None, _error_output(
                _INVALID_MESSAGE,
                details={
                    "field": key,
                    "reason": "must_be_null",
                    "op": op_raw,
                    "must_be_null": must_be_null,
                    "required_non_null": required_non_null,
                    "example": _PLAN_EXAMPLE_BY_OP.get(op_raw),
                },
            )
    for key in sorted(allowed):
        if key == "op":
            continue
        request[key] = payload.get(key)
    return request, None


def _parse_plan_op(raw: str) -> tuple[PlanOp, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return PlanOpGet(), _error_output(
            _INVALID_MESSAGE,
            details={"field": "/", "reason": "invalid_payload"},
        )
    request, normalize_error = _normalize_flat_plan_payload(payload)
    if normalize_error is not None:
        return PlanOpGet(), normalize_error
    if request is None:
        return PlanOpGet(), _error_output(
            _INVALID_MESSAGE,
            details={"field": "/", "reason": "invalid_payload"},
        )
    op, error = parse_plan_request(request)
    if error is None and op is not None:
        return op, None
    details: dict[str, JSONValue] = (
        dict(plan_error_details(error))
        if error is not None
        else {"field": "/", "reason": "invalid_payload"}
    )
    op_name = request.get("op")
    if "allowed_ops" not in details:
        details["allowed_ops"] = _json_string_list(sorted(_PLAN_KEYS_BY_OP))
    if isinstance(op_name, str):
        if "required_non_null" not in details:
            details["required_non_null"] = _json_string_list(
                list(_PLAN_REQUIRED_NON_NULL_BY_OP.get(op_name, ()))
            )
        if "must_be_null" not in details and op_name in _PLAN_KEYS_BY_OP:
            details["must_be_null"] = _json_string_list(
                sorted((_PLAN_FLAT_KEYS - _PLAN_KEYS_BY_OP[op_name]) - {"op"})
            )
        if "example" not in details:
            details["example"] = _PLAN_EXAMPLE_BY_OP.get(op_name)
    return PlanOpGet(), _error_output(_INVALID_MESSAGE, details=details)


async def _persist_plan_mutation(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    latest: PlanSnapshot | None,
    mutation: PlanMutation | None,
    trace_id: str | None,
    tool_call_id: str | None,
) -> PlanSnapshot | None:
    if mutation is None:
        return latest
    if (
        latest is not None
        and latest.steps == mutation.steps
        and latest.explanation == mutation.explanation
    ):
        return latest
    return await insert_plan_snapshot(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        steps=mutation.steps,
        explanation=mutation.explanation,
        trace_id=trace_id,
        tool_call_id=tool_call_id,
    )


async def _plan_series_after_op(
    *,
    ctx: ToolContext[ToolRuntimeContext],
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    op: PlanOp,
    cancel_token: CancelToken | None,
) -> tuple[PlanSeries | None, str | None]:
    if isinstance(op, PlanOpReset) and op.mode == "delete":
        await delete_plan_snapshots(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
        )
        series = await get_plan_series(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
        )
        return series, None
    latest = await get_latest_plan_snapshot(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
    )
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    mutation, error = apply_plan_op(latest, op)
    if error is not None:
        return None, _error_output(_INVALID_MESSAGE, details=plan_error_details(error))
    snapshot = await _persist_plan_mutation(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        latest=latest,
        mutation=mutation,
        trace_id=ctx.context.trace_id,
        tool_call_id=ctx.tool_call_id,
    )
    if ctx.tool_call_id and snapshot is not None:
        ctx.context.plan_cache[ctx.tool_call_id] = snapshot
    series = await get_plan_series(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
    )
    return series, None


async def _invoke_plan_tool(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    op, error = _parse_plan_op(raw)
    if error is not None:
        return error
    session_id = ctx.context.session_id
    branch_id = ctx.context.branch_id
    if not session_id or not branch_id:
        return _tool_error_output(
            "plan requires a session id and branch id.",
            details={"reason": "missing_session_context"},
        )
    store = AsyncStore(ctx.context.db_path)
    try:
        series, plan_error = await _plan_series_after_op(
            ctx=ctx,
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            op=op,
            cancel_token=cancel_token,
        )
    except AgentermError as exc:
        return _tool_error_output(
            "plan store error.",
            details={"reason": "store_error", "message": str(exc)},
        )
    if plan_error is not None:
        return plan_error
    if series is None:
        return _tool_error_output(
            "plan store error.",
            details={"reason": "store_error", "message": "missing_plan_series"},
        )
    env = ToolOutputEnvelope(
        tool="plan",
        ok=True,
        result=series.to_json(),
    )
    return env.to_json_string()


def build_plan_tool(cfg: PlanToolConfig | None) -> FunctionTool | None:
    """Build the plan tool when configured."""
    if cfg is None:
        return None

    validate_strict_schema("plan", _PLAN_SCHEMA)

    return FunctionTool(
        name="plan",
        description=describe_plan(),
        params_json_schema=_PLAN_SCHEMA,
        on_invoke_tool=_invoke_plan_tool,
        strict_json_schema=True,
    )


__all__ = ("build_plan_tool",)
