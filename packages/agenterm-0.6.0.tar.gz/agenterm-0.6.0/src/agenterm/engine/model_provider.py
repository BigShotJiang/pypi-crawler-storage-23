"""Model provider wiring for OpenAI + gateway routes."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from agents.exceptions import UserError
from agents.models.interface import Model, ModelProvider
from agents.models.multi_provider import MultiProvider, MultiProviderMap
from agents.models.openai_responses import OpenAIResponsesModel

from agenterm.core.gateway_client import get_gateway_client

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.extensions.models.litellm_model import LitellmModel
    from openai import AsyncOpenAI

    from agenterm.config.model import GatewayRouteConfig, ProvidersConfig

_GATEWAY_ID_ERROR = "Gateway model ids must be gateway/<route>/<model>."
_GATEWAY_PARTS: int = 3

_litellm_model_cls: type[LitellmModel] | None
try:  # pragma: no cover - optional dependency
    from agents.extensions.models.litellm_model import LitellmModel as _LitellmModel
except ImportError:
    _litellm_model_cls = None
else:
    _litellm_model_cls = _LitellmModel


def _split_gateway_model(model_name: str) -> tuple[str, str]:
    if "/" not in model_name:
        msg = _GATEWAY_ID_ERROR
        raise UserError(msg)
    route, model = model_name.split("/", 1)
    if not route or not model:
        msg = _GATEWAY_ID_ERROR
        raise UserError(msg)
    return route, model


def _require_route_api_key(route: str, route_cfg: GatewayRouteConfig) -> str | None:
    if route_cfg.api_key_env is None:
        return None
    value = os.environ.get(route_cfg.api_key_env)
    if not value:
        msg = (
            f"Missing environment variable {route_cfg.api_key_env} for "
            f"gateway route {route}."
        )
        raise UserError(msg)
    return value


def _build_litellm_model(
    *,
    model: str,
    base_url: str | None,
    api_key: str | None,
) -> Model:
    if _litellm_model_cls is None:
        msg = (
            "LiteLLM support is not installed. Install openai-agents[litellm] "
            "to use gateway routes."
        )
        raise UserError(msg)
    return _litellm_model_cls(model=model, base_url=base_url, api_key=api_key)


def _build_openai_responses_model(
    *,
    model: str,
    client: AsyncOpenAI,
) -> Model:
    return OpenAIResponsesModel(
        model=model, openai_client=client, model_is_explicit=True
    )


class GatewayProvider(ModelProvider):
    """ModelProvider for gateway/<route>/<model> ids (LiteLLM or OpenAI-compatible)."""

    def __init__(self, routes: Mapping[str, GatewayRouteConfig]) -> None:
        """Store configured gateway routes."""
        self._routes = routes

    def get_model(self, model_name: str | None) -> Model:
        """Resolve gateway/<route>/<model> to a configured model provider."""
        if model_name is None:
            msg = _GATEWAY_ID_ERROR
            raise UserError(msg)
        route, model = _split_gateway_model(model_name)
        route_cfg = self._routes.get(route)
        if route_cfg is None:
            msg = f"Unknown gateway route: {route}"
            raise UserError(msg)
        api_key = _require_route_api_key(route, route_cfg)
        if route_cfg.protocol == "openai_responses":
            client = get_gateway_client(route=route, route_cfg=route_cfg)
            return _build_openai_responses_model(model=model, client=client)
        return _build_litellm_model(
            model=f"{route_cfg.provider}/{model}",
            base_url=route_cfg.base_url,
            api_key=api_key,
        )


def build_model_provider(cfg: ProvidersConfig) -> ModelProvider:
    """Construct the MultiProvider with gateway routes mapped to LiteLLM."""
    provider_map = MultiProviderMap()
    provider_map.add_provider("gateway", GatewayProvider(cfg.gateway.routes))
    return MultiProvider(
        provider_map=provider_map,
        openai_base_url=cfg.openai.base_url,
    )


def gateway_route_for_model(
    providers: ProvidersConfig,
    *,
    model_id: str,
) -> tuple[str, GatewayRouteConfig] | None:
    """Return the gateway route config for a gateway/<route>/<model> id."""
    if not model_id.lower().startswith("gateway/"):
        return None
    parts = model_id.split("/", 2)
    if len(parts) != _GATEWAY_PARTS:
        return None
    route = parts[1]
    route_cfg = providers.gateway.routes.get(route)
    if route_cfg is None:
        return None
    return route, route_cfg


__all__ = (
    "GatewayProvider",
    "build_model_provider",
    "gateway_route_for_model",
)
