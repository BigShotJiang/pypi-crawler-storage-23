"""Utility helpers for engine configuration shaping.

Keep small, pure helpers that adjust configuration based on runtime toggles.
"""

from __future__ import annotations

from dataclasses import replace

from agenterm.config.model import AppConfig, McpConfig, ToolsConfig


def build_runtime_config(cfg: AppConfig, *, tools_enabled: bool) -> AppConfig:
    """Return cfg or a tools-disabled variant deterministically.

    When tools are disabled, strip tool configurations so the engine does not
    expose hosted tools or local tools to the model. This preserves all other
    configuration (model, guardrails, MCP config, run defaults).

    Args:
      cfg: Base application configuration.
      tools_enabled: Whether tools are enabled.

    Returns:
      The effective configuration with tools omitted when disabled.

    """
    if tools_enabled:
        return cfg

    tools_src = cfg.tools
    model_src = cfg.model
    # Preserve bundles so UX surfaces (e.g. /tools) remain coherent, but remove
    # all concrete tool configs so the agent sees no tools when the gate is off.
    tools_disabled = ToolsConfig(
        file_search=None,
        web_search=None,
        image_generation=None,
        shell=None,
        apply_patch=None,
        inspect=None,
        plan=None,
        agent_run=None,
        agent_run_report=None,
        function_tools=[],
        bundles=dict(tools_src.bundles),
        default_bundles=list(tools_src.default_bundles),
    )
    mcp_disabled = McpConfig(servers=[], connectors=[], convert_schemas_to_strict=True)
    model_disabled = replace(model_src, tool_choice="none")
    return replace(cfg, tools=tools_disabled, mcp=mcp_disabled, model=model_disabled)


__all__ = ("build_runtime_config",)
