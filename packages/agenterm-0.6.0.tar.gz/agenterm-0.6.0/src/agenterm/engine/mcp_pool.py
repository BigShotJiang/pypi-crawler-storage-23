"""Lifecycle management for Agents MCP servers.

The Agents SDK requires callers to connect MCP servers before passing them to an
Agent, and to cleanup servers when they are no longer needed.

This module centralizes that lifecycle for agenterm so both one-shot runs and the
REPL can share one canonical behavior.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Self

from agenterm.core.errors import McpConnectError
from agenterm.engine.mcp_errors import MCP_CONNECT_ERRORS
from agenterm.engine.mcp_factory import build_mcp_servers

if TYPE_CHECKING:
    from collections.abc import Sequence
    from types import TracebackType

    from agents.mcp import MCPServer

    from agenterm.config.model import AppConfig


class McpServerPool:
    """Own the lifecycle of a set of Agents MCP servers."""

    def __init__(self, servers: Sequence[MCPServer]) -> None:
        """Initialize a pool from a pre-built server list."""
        self._servers: list[MCPServer] = list(servers)
        self._connected: bool = False

    @classmethod
    def from_config(cls, cfg: AppConfig) -> McpServerPool:
        """Build the MCP server list from config (unconnected)."""
        return cls(build_mcp_servers(cfg))

    @property
    def servers(self) -> list[MCPServer]:
        """Return the server list (connected after `connect()`)."""
        return list(self._servers)

    async def connect(self) -> None:
        """Connect all servers in order, cleaning up on partial failure."""
        if self._connected:
            return
        connected: list[MCPServer] = []
        connect_error: Exception | None = None
        cleanup_error: Exception | None = None
        try:
            for server in self._servers:
                await server.connect()
                connected.append(server)
            self._connected = True
        except MCP_CONNECT_ERRORS as exc:
            connect_error = exc
        finally:
            if not self._connected:
                for server in reversed(connected):
                    try:
                        await server.cleanup()
                    except MCP_CONNECT_ERRORS as cleanup_exc:
                        cleanup_error = cleanup_exc
                        break
        if cleanup_error is not None:
            detail = (
                f"; initial connect error: {connect_error}" if connect_error else ""
            )
            msg = f"MCP cleanup failed after connect failure: {cleanup_error}{detail}"
            raise McpConnectError(msg) from cleanup_error
        if connect_error is not None:
            msg = f"MCP connect failed: {connect_error}"
            raise McpConnectError(msg) from connect_error

    async def cleanup(self) -> None:
        """Cleanup all servers in reverse order."""
        if not self._connected:
            return
        cleanup_errors: list[Exception] = []
        for server in reversed(self._servers):
            try:
                await server.cleanup()
            except MCP_CONNECT_ERRORS as exc:
                cleanup_errors.append(exc)
        self._connected = False
        if cleanup_errors:
            first = cleanup_errors[0]
            msg = f"MCP cleanup failed: {first}"
            raise McpConnectError(msg) from first

    async def __aenter__(self) -> Self:
        """Connect servers when entering an async context."""
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        """Cleanup servers when exiting an async context."""
        await self.cleanup()


__all__ = ("McpServerPool",)
