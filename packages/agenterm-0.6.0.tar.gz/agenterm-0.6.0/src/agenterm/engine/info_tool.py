"""Local info tool for runtime context snapshots."""

from __future__ import annotations

from functools import partial
from typing import TYPE_CHECKING, Final

from agents.tool import FunctionTool

from agenterm.core.errors import AgentermError
from agenterm.core.json_codec import as_str, as_str_list, parse_json_object
from agenterm.core.tool_output_envelope import (
    ToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.info_sections import (
    apply_sync_section,
    json_list,
    sync_section_builders,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_info
from agenterm.store.async_db import AsyncStore
from agenterm.store.branch.repo import get_branch_meta

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence
    from pathlib import Path

    from agents.tool_context import ToolContext

    from agenterm.config.model import AppConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext
    from agenterm.core.toolspec import ToolSpec

_INVALID_INPUT_KIND: Final[str] = "invalid_input"
_TOOL_ERROR_KIND: Final[str] = "tool_error"

_ALLOWED_SECTIONS: Final[tuple[str, ...]] = (
    "clock",
    "workspace",
    "session",
    "runtime",
    "tools",
    "binaries",
    "config",
    "trace",
    "branch",
    "compression",
)
_DEFAULT_SECTIONS: Final[tuple[str, ...]] = ("clock", "workspace", "session")

_INFO_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Select runtime-info mode and optional sections.",
    "properties": {
        "mode": {
            "type": "string",
            "enum": ["discover", "default", "all", "custom"],
        },
        "sections": {
            "type": ["array", "null"],
            "items": {"type": "string", "enum": list(_ALLOWED_SECTIONS)},
            "minItems": 1,
        },
    },
    "required": ["mode", "sections"],
    "additionalProperties": False,
}


def _error_output(
    message: str,
    *,
    details: Mapping[str, JSONValue],
) -> str:
    err = ToolOutputError(
        kind=_INVALID_INPUT_KIND,
        message=message,
        details=dict(details),
    )
    env = ToolOutputEnvelope(
        tool="info",
        ok=False,
        result={},
        error=err,
    )
    return env.to_json_string()


def _tool_error_output(message: str) -> str:
    err = ToolOutputError(
        kind=_TOOL_ERROR_KIND,
        message=message,
        details={"reason": "tool_error"},
    )
    env = ToolOutputEnvelope(
        tool="info",
        ok=False,
        result={},
        error=err,
    )
    return env.to_json_string()


def _parse_simple_mode(
    payload: Mapping[str, JSONValue],
    *,
    mode: str,
    sections: tuple[str, ...],
) -> tuple[str | None, tuple[str, ...] | None, dict[str, JSONValue] | None]:
    unknown_keys = sorted(set(payload) - {"mode", "sections"})
    if unknown_keys:
        return (
            None,
            None,
            {
                "field": "payload",
                "reason": "unknown_keys",
                "unknown_keys": json_list(unknown_keys),
                "allowed_keys": json_list(("mode", "sections")),
            },
        )
    if payload.get("sections") is not None:
        return (
            None,
            None,
            {
                "field": "sections",
                "reason": "must_be_null",
                "must_be_null": json_list(("sections",)),
                "mode": mode,
            },
        )
    return mode, sections, None


def _parse_custom_mode(
    payload: Mapping[str, JSONValue],
) -> tuple[str | None, tuple[str, ...] | None, dict[str, JSONValue] | None]:
    unknown_keys = sorted(set(payload) - {"mode", "sections"})
    if unknown_keys:
        return (
            None,
            None,
            {
                "field": "payload",
                "reason": "unknown_keys",
                "unknown_keys": json_list(unknown_keys),
                "allowed_keys": json_list(("mode", "sections")),
            },
        )
    parsed = as_str_list(payload.get("sections"), strip=True, drop_empty=True)
    if parsed is None or not parsed:
        return (
            None,
            None,
            {
                "field": "sections",
                "reason": "required_non_null",
                "required_non_null": json_list(("sections",)),
            },
        )
    unknown = [item for item in parsed if item not in _ALLOWED_SECTIONS]
    if unknown:
        return (
            None,
            None,
            {
                "field": "sections",
                "reason": "unknown",
                "unknown": json_list(unknown),
                "allowed_sections": json_list(_ALLOWED_SECTIONS),
            },
        )
    seen: set[str] = set()
    ordered: list[str] = []
    for item in parsed:
        if item in seen:
            continue
        seen.add(item)
        ordered.append(item)
    return "custom", tuple(ordered), None


def _parse_sections(
    payload: Mapping[str, JSONValue],
) -> tuple[str | None, tuple[str, ...] | None, dict[str, JSONValue] | None]:
    mode = as_str(payload.get("mode"))
    if mode is None:
        return None, None, {"field": "mode", "reason": "missing"}
    if mode == "discover":
        return _parse_simple_mode(payload, mode="discover", sections=())
    if mode == "default":
        return _parse_simple_mode(payload, mode="default", sections=_DEFAULT_SECTIONS)
    if mode == "all":
        return _parse_simple_mode(payload, mode="all", sections=_ALLOWED_SECTIONS)
    if mode == "custom":
        return _parse_custom_mode(payload)
    return (
        None,
        None,
        {
            "field": "mode",
            "reason": "invalid",
            "allowed_modes": json_list(("discover", "default", "all", "custom")),
        },
    )


async def _branch_section(
    ctx: ToolRuntimeContext,
) -> dict[str, JSONValue] | None:
    if not ctx.session_id or not ctx.branch_id:
        return None
    if not ctx.db_path.is_file():
        return None
    store = AsyncStore(ctx.db_path)
    meta = await get_branch_meta(
        store=store,
        session_id=ctx.session_id,
        branch_id=ctx.branch_id,
    )
    if meta is None:
        return None
    return {
        "branch_id": meta.branch_id,
        "kind": meta.kind,
        "parent_branch_id": meta.parent_branch_id,
        "fork_run_number": meta.fork_run_number,
        "pinned": meta.pinned,
        "store_enabled": meta.store_enabled,
        "created_at": meta.created_at,
        "updated_at": meta.updated_at,
    }


async def _branch_result(
    ctx: ToolRuntimeContext,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    try:
        return await _branch_section(ctx), None
    except AgentermError as exc:
        return None, _tool_error_output(str(exc))


async def _collect_sections(
    sections: Sequence[str],
    *,
    cfg: AppConfig,
    ctx: ToolRuntimeContext,
    workspace_root: Path,
    selected_specs: Sequence[ToolSpec],
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue], list[JSONValue], str | None]:
    builders = sync_section_builders(
        cfg=cfg,
        ctx=ctx,
        workspace_root=workspace_root,
        selected_specs=selected_specs,
    )
    sections_out: dict[str, JSONValue] = {}
    unavailable: list[str] = []
    for name in sections:
        if name == "branch":
            branch, error = await _branch_result(ctx)
            if error is not None:
                return {}, [], error
            if cancel_token is not None:
                cancel_token.raise_if_cancelled()
            if branch is None:
                unavailable.append(name)
            else:
                sections_out[name] = branch
            continue
        apply_sync_section(
            name,
            builders=builders,
            sections_out=sections_out,
            unavailable=unavailable,
        )
    return sections_out, json_list(unavailable), None


async def _invoke_info_tool(
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
    *,
    cfg: AppConfig,
    workspace_root: Path,
    selected_specs: Sequence[ToolSpec],
) -> str:
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return _error_output(
            "Invalid info payload.",
            details={"field": "payload", "reason": "invalid_payload"},
        )
    mode, sections, details = _parse_sections(payload)
    if mode is None or sections is None:
        return _error_output(
            "Invalid info payload.",
            details=details or {"field": "sections", "reason": "invalid"},
        )
    if mode == "discover":
        discovery_payload: dict[str, JSONValue] = {
            "mode": "discover",
            "sections": {},
            "unavailable": [],
            "allowed_sections": json_list(_ALLOWED_SECTIONS),
            "tool_limits": {
                "inspect_max_operations": (
                    int(cfg.tools.inspect.max_operations)
                    if cfg.tools.inspect is not None
                    else None
                ),
                "inspect_max_concurrency": (
                    int(cfg.tools.inspect.max_concurrency)
                    if cfg.tools.inspect is not None
                    else None
                ),
            },
        }
        env = ToolOutputEnvelope(
            tool="info",
            ok=True,
            result=discovery_payload,
        )
        return env.to_json_string()
    sections_out, unavailable, error_env = await _collect_sections(
        sections,
        cfg=cfg,
        ctx=ctx.context,
        workspace_root=workspace_root,
        selected_specs=selected_specs,
        cancel_token=cancel_token,
    )
    if error_env is not None:
        return error_env
    payload_out: dict[str, JSONValue] = {
        "mode": mode,
        "sections": sections_out,
        "unavailable": unavailable,
    }
    env = ToolOutputEnvelope(
        tool="info",
        ok=True,
        result=payload_out,
    )
    return env.to_json_string()


def build_info_tool(
    cfg: AppConfig,
    *,
    workspace_root: Path,
    selected_specs: Sequence[ToolSpec],
) -> FunctionTool:
    """Build the runtime_info inspection operation engine."""
    validate_strict_schema("info", _INFO_SCHEMA)

    on_invoke = partial(
        _invoke_info_tool,
        cfg=cfg,
        workspace_root=workspace_root,
        selected_specs=selected_specs,
    )
    return FunctionTool(
        name="info",
        description=describe_info(),
        params_json_schema=_INFO_SCHEMA,
        on_invoke_tool=on_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_info_tool",)
