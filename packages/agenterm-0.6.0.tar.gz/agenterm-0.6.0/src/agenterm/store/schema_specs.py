"""Table specifications for agenterm-owned SQLite schema."""

from __future__ import annotations

from typing import Final

from agenterm.store.schema_spec_types import TableSpec
from agenterm.store.schema_specs_core import CORE_TABLE_SPECS
from agenterm.store.schema_specs_support import SUPPORT_TABLE_SPECS

TABLE_SPECS: Final[tuple[TableSpec, ...]] = (
    *CORE_TABLE_SPECS,
    *SUPPORT_TABLE_SPECS,
)


__all__ = ("TABLE_SPECS", "TableSpec")
