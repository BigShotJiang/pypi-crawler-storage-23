"""Cancelled turn attempt queries.

This module is split out to keep repository files below the 500 line limit.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.store.schema import ensure_store_schema
from agenterm.store.turn_attempts.rows import row_to_attempt, row_to_item

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.store.async_db import AsyncStore
    from agenterm.store.turn_attempts.models import (
        TurnAttemptItemRecord,
        TurnAttemptRecord,
    )


async def latest_cancelled_turn_attempt(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> TurnAttemptRecord | None:
    """Return the most recent cancelled attempt, if any."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str | int | float | bytes | None, ...] | None:
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                run_number,
                status,
                cancel_reason,
                created_at,
                updated_at
            FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND status = 'cancelled'
            ORDER BY run_number DESC
            LIMIT 1
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    return row_to_attempt(row)


async def list_cancelled_turn_attempts(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> tuple[TurnAttemptRecord, ...]:
    """Return cancelled attempts ordered by run number (oldest first)."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                run_number,
                status,
                cancel_reason,
                created_at,
                updated_at
            FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND status = 'cancelled'
            ORDER BY run_number ASC
            """,
            (str(session_id), str(branch_id)),
        )
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return tuple(row_to_attempt(row) for row in rows)


async def list_cancelled_turn_attempt_items(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> tuple[TurnAttemptItemRecord, ...]:
    """Return unseen items for all cancelled attempts ordered by attempt+sequence."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        cur = await conn.execute(
            """
            SELECT
                i.session_id,
                i.branch_id,
                i.run_number,
                i.item_seq,
                i.item_type,
                i.item_json,
                i.seen_by_model,
                i.created_at
            FROM agenterm_turn_attempt_items i
            JOIN agenterm_turn_attempts a
              ON a.session_id = i.session_id
             AND a.branch_id = i.branch_id
             AND a.run_number = i.run_number
            WHERE i.session_id = ?
              AND i.branch_id = ?
              AND a.status = 'cancelled'
              AND i.seen_by_model = 0
            ORDER BY i.run_number ASC, i.item_seq ASC
            """,
            (str(session_id), str(branch_id)),
        )
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return tuple(row_to_item(row) for row in rows)


async def clear_cancelled_turn_attempts(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> None:
    """Delete all cancelled attempts and their items for a session branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            DELETE FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND status = 'cancelled'
            """,
            (str(session_id), str(branch_id)),
        )
        await conn.commit()

    await store.run(_op)


async def consume_latest_cancelled_attempt(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> tuple[TurnAttemptRecord, tuple[TurnAttemptItemRecord, ...]] | None:
    """Return and delete the most recent cancelled attempt and its unseen items."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[
        tuple[str | int | float | bytes | None, ...] | None,
        list[tuple[str | int | float | bytes | None, ...]],
    ]:
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                run_number,
                status,
                cancel_reason,
                created_at,
                updated_at
            FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND status = 'cancelled'
            ORDER BY run_number DESC
            LIMIT 1
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        if row is None:
            return None, []
        attempt_row = tuple(row)
        run_number = row[2]
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                run_number,
                item_seq,
                item_type,
                item_json,
                seen_by_model,
                created_at
            FROM agenterm_turn_attempt_items
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
              AND seen_by_model = 0
            ORDER BY item_seq ASC
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        rows = await cur.fetchall()
        await conn.execute(
            """
            DELETE FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.commit()
        return attempt_row, [tuple(row) for row in rows]

    attempt_row, item_rows = await store.run(_op)
    if attempt_row is None:
        return None
    attempt = row_to_attempt(attempt_row)
    items = tuple(row_to_item(row) for row in item_rows)
    return attempt, items


__all__ = (
    "clear_cancelled_turn_attempts",
    "consume_latest_cancelled_attempt",
    "latest_cancelled_turn_attempt",
    "list_cancelled_turn_attempt_items",
    "list_cancelled_turn_attempts",
)
