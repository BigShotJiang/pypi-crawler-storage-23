"""Turn attempt ledger models for agenterm-owned persistence."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue

type TurnAttemptStatus = Literal["active", "cancelled"]


@dataclass(frozen=True)
class TurnAttemptRecord:
    """Persisted turn attempt record (decoded)."""

    session_id: str
    branch_id: str
    run_number: int
    status: TurnAttemptStatus
    cancel_reason: str | None
    created_at: str | None
    updated_at: str | None


@dataclass(frozen=True)
class TurnAttemptItemRecord:
    """Persisted turn attempt item (decoded)."""

    session_id: str
    branch_id: str
    run_number: int
    item_seq: int
    item_type: str
    item: dict[str, JSONValue]
    seen_by_model: bool
    created_at: str | None


__all__ = (
    "TurnAttemptItemRecord",
    "TurnAttemptRecord",
    "TurnAttemptStatus",
)
