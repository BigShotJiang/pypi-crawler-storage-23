"""SQLite repository for turn attempt ledger entries."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.store.codec import encode_json_object
from agenterm.store.schema import ensure_store_schema
from agenterm.store.turn_attempts.rows import row_to_item

if TYPE_CHECKING:
    from collections.abc import Mapping

    import aiosqlite

    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.turn_attempts.models import TurnAttemptItemRecord


async def start_turn_attempt(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
) -> None:
    """Insert or reset a turn attempt to active status."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            INSERT INTO agenterm_turn_attempts (
                session_id,
                branch_id,
                run_number,
                status,
                cancel_reason
            )
            VALUES (?, ?, ?, 'active', NULL)
            ON CONFLICT(session_id, branch_id, run_number)
            DO UPDATE SET
                status='active',
                cancel_reason=NULL,
                updated_at=CURRENT_TIMESTAMP
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.execute(
            """
            DELETE FROM agenterm_turn_attempt_items
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.commit()

    await store.run(_op)


async def insert_turn_attempt_item(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    item_seq: int,
    item_type: str,
    item: Mapping[str, JSONValue],
    seen_by_model: bool,
) -> None:
    """Insert a new turn attempt item."""
    await ensure_store_schema(store.db_path)
    item_json = encode_json_object(
        dict(item),
        context="agenterm_turn_attempt_items.item_json",
        sort_keys=True,
        ensure_ascii=True,
    )

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            INSERT INTO agenterm_turn_attempt_items (
                session_id,
                branch_id,
                run_number,
                item_seq,
                item_type,
                item_json,
                seen_by_model
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(session_id),
                str(branch_id),
                int(run_number),
                int(item_seq),
                str(item_type),
                item_json,
                1 if seen_by_model else 0,
            ),
        )
        await conn.commit()

    await store.run(_op)


async def mark_turn_attempt_items_seen(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
) -> None:
    """Mark all items for this attempt as seen by the model."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            UPDATE agenterm_turn_attempt_items
            SET seen_by_model = 1
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.execute(
            """
            UPDATE agenterm_turn_attempts
            SET updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.commit()

    await store.run(_op)


async def mark_turn_attempt_cancelled(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    cancel_reason: str | None,
) -> None:
    """Mark a turn attempt as cancelled."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            UPDATE agenterm_turn_attempts
            SET status = 'cancelled',
                cancel_reason = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (
                str(cancel_reason) if cancel_reason else None,
                str(session_id),
                str(branch_id),
                int(run_number),
            ),
        )
        await conn.commit()

    await store.run(_op)


async def clear_turn_attempt(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
) -> None:
    """Delete a turn attempt and its items."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            DELETE FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.commit()

    await store.run(_op)


async def list_turn_attempt_items(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    seen_by_model: bool | None = None,
) -> tuple[TurnAttemptItemRecord, ...]:
    """Return ordered attempt items (optionally filtered by seen flag)."""
    await ensure_store_schema(store.db_path)
    seen_val = None if seen_by_model is None else (1 if seen_by_model else 0)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        query = """
            SELECT
                session_id,
                branch_id,
                run_number,
                item_seq,
                item_type,
                item_json,
                seen_by_model,
                created_at
            FROM agenterm_turn_attempt_items
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
        """
        params: list[str | int] = [
            str(session_id),
            str(branch_id),
            int(run_number),
        ]
        if seen_val is not None:
            query = query + " AND seen_by_model = ?"
            params.append(seen_val)
        query = query + " ORDER BY item_seq ASC"
        cur = await conn.execute(query, tuple(params))
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return tuple(row_to_item(row) for row in rows)


__all__ = (
    "clear_turn_attempt",
    "insert_turn_attempt_item",
    "list_turn_attempt_items",
    "mark_turn_attempt_cancelled",
    "mark_turn_attempt_items_seen",
    "start_turn_attempt",
)
