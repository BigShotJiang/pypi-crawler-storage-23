"""SQLite row decoding helpers for the turn attempt ledger."""

from __future__ import annotations

from agenterm.core.errors import DatabaseError
from agenterm.store.codec import (
    decode_json_object,
    optional_text,
    require_int,
    require_text,
)
from agenterm.store.turn_attempts.models import (
    TurnAttemptItemRecord,
    TurnAttemptRecord,
    TurnAttemptStatus,
)

type Row = tuple[str | int | float | bytes | None, ...]


def row_to_attempt(row: Row) -> TurnAttemptRecord:
    """Decode a row from agenterm_turn_attempts into a typed record."""
    (
        session_id,
        branch_id,
        run_number,
        status,
        cancel_reason,
        created_at,
        updated_at,
    ) = row
    session_id = require_text(session_id, field="agenterm_turn_attempts.session_id")
    branch_id = require_text(branch_id, field="agenterm_turn_attempts.branch_id")
    run_number_int = require_int(
        run_number,
        field="agenterm_turn_attempts.run_number",
    )
    status_val = require_text(status, field="agenterm_turn_attempts.status")
    if status_val not in {"active", "cancelled"}:
        msg = "agenterm_turn_attempts.status expected active|cancelled"
        raise DatabaseError(msg)
    status_norm: TurnAttemptStatus = "active" if status_val == "active" else "cancelled"
    return TurnAttemptRecord(
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number_int,
        status=status_norm,
        cancel_reason=optional_text(
            cancel_reason,
            field="agenterm_turn_attempts.cancel_reason",
        ),
        created_at=optional_text(
            created_at,
            field="agenterm_turn_attempts.created_at",
        ),
        updated_at=optional_text(
            updated_at,
            field="agenterm_turn_attempts.updated_at",
        ),
    )


def row_to_item(row: Row) -> TurnAttemptItemRecord:
    """Decode a row from agenterm_turn_attempt_items into a typed record."""
    (
        session_id,
        branch_id,
        run_number,
        item_seq,
        item_type,
        item_json,
        seen_by_model,
        created_at,
    ) = row
    session_id = require_text(
        session_id,
        field="agenterm_turn_attempt_items.session_id",
    )
    branch_id = require_text(
        branch_id,
        field="agenterm_turn_attempt_items.branch_id",
    )
    run_number_int = require_int(
        run_number,
        field="agenterm_turn_attempt_items.run_number",
    )
    item_seq_int = require_int(
        item_seq,
        field="agenterm_turn_attempt_items.item_seq",
    )
    item_type = require_text(
        item_type,
        field="agenterm_turn_attempt_items.item_type",
    )
    item_json_text = require_text(
        item_json,
        field="agenterm_turn_attempt_items.item_json",
    )
    seen = require_int(
        seen_by_model,
        field="agenterm_turn_attempt_items.seen_by_model",
    )
    return TurnAttemptItemRecord(
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number_int,
        item_seq=item_seq_int,
        item_type=item_type,
        item=decode_json_object(
            item_json_text,
            context="agenterm_turn_attempt_items.item_json",
        ),
        seen_by_model=bool(seen),
        created_at=optional_text(
            created_at,
            field="agenterm_turn_attempt_items.created_at",
        ),
    )


__all__ = ("Row", "row_to_attempt", "row_to_item")
