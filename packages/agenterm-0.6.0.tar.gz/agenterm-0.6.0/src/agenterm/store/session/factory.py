"""Factories for creating or attaching sessions backed by SQLite."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from agenterm.config.paths import history_db_path, meta_store_path
from agenterm.core.errors import ConfigError
from agenterm.store.async_db import AsyncStore
from agenterm.store.branch.repo import (
    BranchMetaUpsert,
    get_branch_meta,
    update_branch_store,
    upsert_branch_meta,
)
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.repo import (
    SessionMetadataUpsert,
    get_session_metadata_row,
    upsert_session_metadata,
)

if TYPE_CHECKING:
    from pathlib import Path

    from agents.memory import Session

    from agenterm.store.branch.models import BranchMeta

type SessionFactoryMode = Literal["run", "repl", "background"]


@dataclass(frozen=True)
class SessionFactoryConfig:
    """Configuration for creating or attaching a stored session."""

    mode: SessionFactoryMode
    cwd: Path
    config_path: Path | None
    model: str
    tools_enabled: bool
    trace_id: str | None
    group_id: str | None
    session_id: str | None
    branch_id: str | None
    store_enabled: bool
    store_override: bool | None
    agent_name: str
    agent_path: Path | None
    agent_sha256: str | None


@dataclass(frozen=True)
class SessionFactoryResult:
    """Result returned by make_session."""

    session: Session
    session_id: str | None
    branch_id: str | None
    branch_meta: BranchMeta | None


def session_db_path() -> Path:
    """Return the SQLite database path used for agenterm metadata."""
    return meta_store_path()


def session_store() -> AsyncStore:
    """Return the AsyncStore wrapper for the session database."""
    return AsyncStore(session_db_path())


def _normalize_branch_id(value: str | None, *, fallback: str) -> str:
    if value is None:
        return fallback
    cleaned = value.strip()
    if not cleaned:
        msg = "branch_id cannot be empty"
        raise ConfigError(msg)
    return cleaned


async def _create_new_session(
    cfg: SessionFactoryConfig,
    *,
    store: AsyncStore,
) -> tuple[str, str, BranchMeta]:
    session_id = str(uuid.uuid4())
    if cfg.branch_id not in (None, "", "main"):
        msg = "--branch requires an existing session"
        raise ConfigError(msg)
    branch_id = "main"
    session_payload = SessionMetadataUpsert(
        session_id=session_id,
        kind=cfg.mode,
        cwd=cfg.cwd,
        config_path=cfg.config_path,
        model=cfg.model,
        tools_enabled=cfg.tools_enabled,
        trace_id=cfg.trace_id,
        group_id=cfg.group_id,
        head_branch_id=branch_id,
    )
    await upsert_session_metadata(store=store, payload=session_payload)

    branch_payload = BranchMetaUpsert(
        session_id=session_id,
        branch_id=branch_id,
        kind="main",
        title=None,
        pinned=True,
        created_reason=None,
        parent_branch_id=None,
        fork_run_number=None,
        agent_name=cfg.agent_name,
        agent_path=cfg.agent_path,
        agent_sha256=cfg.agent_sha256,
        store_enabled=cfg.store_enabled,
        last_response_id=None,
    )
    await upsert_branch_meta(store=store, payload=branch_payload)
    branch_meta = await get_branch_meta(store, session_id, branch_id)
    if branch_meta is None:
        msg = f"Failed to read back branch metadata for {branch_id}"
        raise ConfigError(msg)
    return session_id, branch_id, branch_meta


async def _attach_existing_session(
    cfg: SessionFactoryConfig,
    *,
    store: AsyncStore,
) -> tuple[str, str, BranchMeta]:
    if cfg.session_id is None:
        msg = "session_id is required for session attachment"
        raise ConfigError(msg)
    session_id = cfg.session_id
    meta = await get_session_metadata_row(store, session_id)
    if meta is None:
        msg = (
            f"Unknown session_id: {session_id!r}. "
            "Use `agenterm session list` (CLI) or `/session list` (REPL) to discover "
            "valid ids."
        )
        raise ConfigError(msg)

    branch_id = _normalize_branch_id(cfg.branch_id, fallback=meta.head_branch_id)
    branch_meta = await get_branch_meta(store, session_id, branch_id)
    if branch_meta is None:
        msg = f"Unknown branch_id: {branch_id!r} for session {session_id!r}"
        raise ConfigError(msg)

    store_enabled = (
        cfg.store_override
        if cfg.store_override is not None
        else branch_meta.store_enabled
    )

    last_response_id = branch_meta.last_response_id if store_enabled else None
    if branch_meta.store_enabled != store_enabled or (
        store_enabled is False and branch_meta.last_response_id is not None
    ):
        await update_branch_store(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            store_enabled=store_enabled,
            last_response_id=last_response_id,
        )
        branch_meta = await get_branch_meta(store, session_id, branch_id)
        if branch_meta is None:
            msg = f"Failed to read back branch metadata for {branch_id}"
            raise ConfigError(msg)

    session_payload = SessionMetadataUpsert(
        session_id=session_id,
        kind=cfg.mode,
        cwd=cfg.cwd,
        config_path=cfg.config_path,
        model=cfg.model,
        tools_enabled=cfg.tools_enabled,
        trace_id=cfg.trace_id,
        group_id=cfg.group_id,
        head_branch_id=branch_id,
    )
    await upsert_session_metadata(store=store, payload=session_payload)
    return session_id, branch_id, branch_meta


async def make_session(cfg: SessionFactoryConfig) -> SessionFactoryResult:
    """Create or attach a stored SQLite-backed session."""
    store = session_store()
    if cfg.session_id is None:
        session_id, branch_id, branch_meta = await _create_new_session(
            cfg,
            store=store,
        )
    else:
        session_id, branch_id, branch_meta = await _attach_existing_session(
            cfg,
            store=store,
        )

    sess = AgentermSQLiteSession(
        session_id=session_id,
        db_path=str(history_db_path()),
        create_tables=True,
    )
    if branch_id != "main":
        await sess.switch_to_branch(branch_id)
    try:
        sess_id = sess.session_id
    except AttributeError:
        sess_id = None
    return SessionFactoryResult(
        session=sess,
        session_id=sess_id if isinstance(sess_id, str) else None,
        branch_id=branch_id,
        branch_meta=branch_meta,
    )


__all__ = (
    "SessionFactoryConfig",
    "SessionFactoryMode",
    "SessionFactoryResult",
    "make_session",
    "session_db_path",
    "session_store",
)
