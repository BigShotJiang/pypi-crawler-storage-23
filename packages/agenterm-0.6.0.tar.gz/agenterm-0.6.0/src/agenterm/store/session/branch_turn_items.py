"""Read-only helpers for per-branch-turn items from the Agents session tables."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.store.codec import (
    decode_json_object,
    optional_text,
    require_int,
    require_text,
)
from agenterm.store.history import ensure_history_tables

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore


@dataclass(frozen=True)
class BranchTurnItemRecord:
    """Decoded item row for a branch turn."""

    sequence_number: int
    message_type: str
    tool_name: str | None
    item: dict[str, JSONValue]


def _row_to_item(
    row: tuple[str | int | float | bytes | None, ...],
) -> BranchTurnItemRecord:
    sequence_number, message_type, tool_name, message_data = row
    sequence_number = require_int(
        sequence_number,
        field="message_structure.sequence_number",
    )
    message_type = require_text(
        message_type,
        field="message_structure.message_type",
    )
    message_text = require_text(
        message_data,
        field="agent_messages.message_data",
    )
    return BranchTurnItemRecord(
        sequence_number=sequence_number,
        message_type=message_type,
        tool_name=optional_text(tool_name, field="message_structure.tool_name"),
        item=decode_json_object(
            message_text,
            context="agent_messages.message_data",
        ),
    )


async def list_branch_turn_items(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    branch_turn_number: int,
) -> tuple[BranchTurnItemRecord, ...]:
    """Return ordered items for a specific branch turn."""

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        await ensure_history_tables(
            conn,
            tables=("message_structure", "agent_messages"),
        )
        cur = await conn.execute(
            """
            SELECT
                ms.sequence_number,
                ms.message_type,
                ms.tool_name,
                am.message_data
            FROM message_structure ms
            JOIN agent_messages am ON ms.message_id = am.id
            WHERE ms.session_id = ? AND ms.branch_id = ? AND ms.branch_turn_number = ?
            ORDER BY ms.sequence_number ASC
            """,
            (str(session_id), str(branch_id), int(branch_turn_number)),
        )
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return tuple(_row_to_item(row) for row in rows)


async def list_branch_turn_items_range(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    start_turn: int,
    end_turn: int,
) -> tuple[BranchTurnItemRecord, ...]:
    """Return ordered items for a range of branch turns (inclusive)."""

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        await ensure_history_tables(
            conn,
            tables=("message_structure", "agent_messages"),
        )
        cur = await conn.execute(
            """
            SELECT
                ms.sequence_number,
                ms.message_type,
                ms.tool_name,
                am.message_data
            FROM message_structure ms
            JOIN agent_messages am ON ms.message_id = am.id
            WHERE ms.session_id = ?
              AND ms.branch_id = ?
              AND ms.branch_turn_number BETWEEN ? AND ?
            ORDER BY ms.sequence_number ASC
            """,
            (str(session_id), str(branch_id), int(start_turn), int(end_turn)),
        )
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return tuple(_row_to_item(row) for row in rows)


__all__ = (
    "BranchTurnItemRecord",
    "list_branch_turn_items",
    "list_branch_turn_items_range",
)
