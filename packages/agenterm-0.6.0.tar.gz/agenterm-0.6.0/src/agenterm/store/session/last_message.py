"""Last-message snippet helpers for session and branch listings."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.text import shorten_line
from agenterm.store.codec import decode_json_object, require_text
from agenterm.store.history import ensure_history_tables

if TYPE_CHECKING:
    from collections.abc import Sequence

    import aiosqlite

    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore


_SNIPPET_MAX_CHARS = 160
_SNIPPET_SCAN_MULTIPLIER = 4
_ALLOWED_MESSAGE_TYPES: tuple[str, ...] = ("user", "assistant")


@dataclass(frozen=True)
class LastMessageSnippet:
    """Latest message snippet for a branch."""

    role: str
    snippet: str


def _text_from_part(part: Mapping[str, JSONValue]) -> str | None:
    part_type = part.get("type")
    if part_type in ("input_text", "output_text", "reasoning_text"):
        text = part.get("text")
        return text if isinstance(text, str) and text else None
    if part_type == "refusal":
        text = part.get("refusal")
        return text if isinstance(text, str) and text else None
    return None


def _normalize_snippet(text: str, *, limit_chars: int) -> str | None:
    if limit_chars <= 0:
        return None
    scan_limit = max(limit_chars, limit_chars * _SNIPPET_SCAN_MULTIPLIER)
    compact = " ".join(text[:scan_limit].split())
    if not compact:
        return None
    return shorten_line(compact, limit=limit_chars)


def extract_message_snippet(
    item: Mapping[str, JSONValue],
    *,
    limit_chars: int = _SNIPPET_MAX_CHARS,
) -> str | None:
    """Return a bounded snippet from a Responses message item."""
    content = item.get("content")
    parts: list[str] = []
    if isinstance(content, str) and content:
        parts.append(content)
    elif isinstance(content, list):
        for part in content:
            if not isinstance(part, Mapping):
                continue
            text = _text_from_part(part)
            if text:
                parts.append(text)
    if not parts:
        return None
    combined = " ".join(parts)
    return _normalize_snippet(combined, limit_chars=limit_chars)


def _normalize_branch_ids(branch_ids: Sequence[str]) -> tuple[str, ...]:
    seen: dict[str, None] = {}
    for branch_id in branch_ids:
        if branch_id:
            seen.setdefault(str(branch_id), None)
    return tuple(seen.keys())


async def _fetch_last_message_rows(
    conn: aiosqlite.Connection,
    *,
    session_id: str,
    branches: Sequence[str],
) -> list[tuple[str | int | float | bytes | None, ...]]:
    await ensure_history_tables(conn, tables=("message_structure", "agent_messages"))
    rows: list[tuple[str | int | float | bytes | None, ...]] = []
    for branch_id in branches:
        cur = await conn.execute(
            """
            SELECT ms.branch_id, ms.message_type, am.message_data
            FROM message_structure ms
            JOIN agent_messages am ON ms.message_id = am.id
            WHERE ms.session_id = ? AND ms.branch_id = ?
              AND ms.message_type IN ('user', 'assistant')
            ORDER BY ms.sequence_number DESC
            LIMIT 1
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        if row is not None:
            rows.append(tuple(row))
    return rows


def _snippets_from_rows(
    rows: Sequence[tuple[str | int | float | bytes | None, ...]],
    *,
    limit_chars: int,
) -> dict[str, LastMessageSnippet]:
    snippets: dict[str, LastMessageSnippet] = {}
    for row in rows:
        branch_id_raw, message_type_raw, message_data_raw = row
        branch_id = str(branch_id_raw)
        role = str(message_type_raw)
        if role not in _ALLOWED_MESSAGE_TYPES:
            continue
        raw = require_text(message_data_raw, field="agent_messages.message_data")
        item = decode_json_object(raw, context="agent_messages.message_data")
        snippet = extract_message_snippet(item, limit_chars=limit_chars)
        if snippet:
            snippets[branch_id] = LastMessageSnippet(role=role, snippet=snippet)
    return snippets


async def last_message_snippets_by_branch(
    *,
    store: AsyncStore,
    session_id: str,
    branch_ids: Sequence[str],
    limit_chars: int = _SNIPPET_MAX_CHARS,
) -> dict[str, LastMessageSnippet]:
    """Return last message snippets for the requested branches."""
    branches = _normalize_branch_ids(branch_ids)
    if not branches:
        return {}

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        return await _fetch_last_message_rows(
            conn,
            session_id=session_id,
            branches=branches,
        )

    rows = await store.run(_op)
    return _snippets_from_rows(rows, limit_chars=limit_chars)


__all__ = (
    "LastMessageSnippet",
    "extract_message_snippet",
    "last_message_snippets_by_branch",
)
