"""Row mapping helpers for session metadata records."""

from __future__ import annotations

from agenterm.core.errors import DatabaseError
from agenterm.store.session.models import SessionMetadata


def row_to_metadata(
    row: tuple[str | int | float | bytes | None, ...],
) -> SessionMetadata:
    """Convert a SQLite row into SessionMetadata."""
    (
        session_id,
        kind,
        cwd,
        config_path,
        model,
        tools_enabled,
        trace_id,
        group_id,
        head_branch_id,
        created_at,
        updated_at,
    ) = row
    if not isinstance(head_branch_id, str):
        msg = (
            f"agenterm_sessions.head_branch_id expected str, got {type(head_branch_id)}"
        )
        raise DatabaseError(msg)
    return SessionMetadata(
        session_id=str(session_id),
        kind=str(kind),
        cwd=str(cwd),
        config_path=str(config_path) if config_path is not None else None,
        model=str(model),
        tools_enabled=bool(tools_enabled),
        trace_id=str(trace_id) if trace_id is not None else None,
        group_id=str(group_id) if group_id is not None else None,
        head_branch_id=head_branch_id,
        created_at=str(created_at) if created_at is not None else None,
        updated_at=str(updated_at) if updated_at is not None else None,
    )


__all__ = ("row_to_metadata",)
