"""Usage persistence helpers for sessions."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.exceptions import AgentsException
from agents.extensions.memory import AdvancedSQLiteSession
from agents.result import RunResult, RunResultBase, RunResultStreaming

from agenterm.core.errors import AgentermError

if TYPE_CHECKING:
    from agenterm.store.session.models import Session


def _to_run_result(streaming: RunResultStreaming) -> RunResult:
    return RunResult(
        input=streaming.input,
        new_items=streaming.new_items,
        raw_responses=streaming.raw_responses,
        final_output=streaming.final_output,
        input_guardrail_results=streaming.input_guardrail_results,
        output_guardrail_results=streaming.output_guardrail_results,
        tool_input_guardrail_results=streaming.tool_input_guardrail_results,
        tool_output_guardrail_results=streaming.tool_output_guardrail_results,
        context_wrapper=streaming.context_wrapper,
        _last_agent=streaming.last_agent,
    )


async def store_run_usage(
    session: Session | None,
    result: RunResultBase | None,
) -> None:
    """Persist Agents usage information for a completed run.

    Greenfield posture: failures are not silently ignored. Callers decide
    whether to surface a warning or fail the edge.
    """
    if session is None:
        return
    if not isinstance(session, AdvancedSQLiteSession):
        msg = f"store_run_usage requires AdvancedSQLiteSession, got {type(session)}"
        raise AgentermError(msg)
    if isinstance(result, RunResultStreaming):
        result = _to_run_result(result)
    if not isinstance(result, RunResult):
        msg = f"store_run_usage requires RunResult, got {type(result)}"
        raise AgentermError(msg)
    try:
        await session.store_run_usage(result)
    except (AgentsException, OSError, RuntimeError) as exc:
        msg = f"Failed to persist Agents run usage: {exc}"
        raise AgentermError(msg) from exc


__all__ = ("store_run_usage",)
