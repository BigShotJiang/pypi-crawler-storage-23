"""agenterm-owned session wrapper for Agents SQLite persistence.

The Agents runner persists every turn's input and output items into the session
store via `Session.add_items(...)` (see ARCH.md for vendor citations).

agenterm extends the session to:
- persist large binary tool results (images) as durable filesystem artifacts, and
- keep the SQLite conversation tables small by stripping base64 blobs at write time.
"""

from __future__ import annotations

import asyncio
import threading
from contextlib import closing
from typing import TYPE_CHECKING

from agents.extensions.memory import AdvancedSQLiteSession

from agenterm.artifacts.image_generation import (
    parse_image_call_status,
    persist_image_generation_call,
)
from agenterm.config.paths import meta_store_path
from agenterm.core.response_items import serialize_input_item_param
from agenterm.store.async_db import AsyncStore
from agenterm.store.codec import (
    optional_int,
    optional_text,
    require_int,
    require_text,
)

if TYPE_CHECKING:
    import sqlite3

    from agents.items import TResponseInputItem
    from agents.memory.session_settings import SessionSettings
    from openai.types.responses.response_input_item_param import (
        ImageGenerationCall as ImageGenerationCallInputItem,
    )


def _ensure_branch_absent(
    cursor: sqlite3.Cursor,
    *,
    session_id: str,
    branch_id: str,
) -> None:
    cursor.execute(
        """
        SELECT COUNT(*)
        FROM message_structure
        WHERE session_id = ? AND branch_id = ?
        """,
        (session_id, branch_id),
    )
    row = cursor.fetchone()
    count = row[0] if row else 0
    if int(count or 0) != 0:
        msg = f"Branch '{branch_id}' already exists"
        raise ValueError(msg)


def _fetch_branch_messages(
    cursor: sqlite3.Cursor,
    *,
    session_id: str,
    branch_id: str,
) -> list[tuple[int, str, int, int | None, int | None, str | None]]:
    cursor.execute(
        """
        SELECT
            ms.message_id,
            ms.message_type,
            ms.sequence_number,
            ms.user_turn_number,
            ms.branch_turn_number,
            ms.tool_name
        FROM message_structure ms
        WHERE ms.session_id = ? AND ms.branch_id = ?
        ORDER BY ms.sequence_number
        """,
        (session_id, branch_id),
    )
    raw_rows = cursor.fetchall()
    if not raw_rows:
        msg = "Cannot branch from an empty conversation"
        raise ValueError(msg)
    messages: list[tuple[int, str, int, int | None, int | None, str | None]] = []
    for row in raw_rows:
        msg_id = require_int(row[0], field="message_structure.message_id")
        msg_type = require_text(row[1], field="message_structure.message_type")
        seq_number = require_int(row[2], field="message_structure.sequence_number")
        user_turn = optional_int(row[3], field="message_structure.user_turn_number")
        branch_turn = optional_int(
            row[4],
            field="message_structure.branch_turn_number",
        )
        tool_name = optional_text(row[5], field="message_structure.tool_name")
        messages.append(
            (
                msg_id,
                msg_type,
                seq_number,
                user_turn,
                branch_turn,
                tool_name,
            )
        )
    return messages


def _next_sequence_start(cursor: sqlite3.Cursor, *, session_id: str) -> int:
    cursor.execute(
        """
        SELECT COALESCE(MAX(sequence_number), 0)
        FROM message_structure
        WHERE session_id = ?
        """,
        (session_id,),
    )
    row = cursor.fetchone()
    return int(row[0] if row else 0)


def _build_structure_rows(
    *,
    session_id: str,
    new_branch_id: str,
    seq_start: int,
    messages: list[tuple[int, str, int, int | None, int | None, str | None]],
) -> list[tuple[str, int, str, str, int, int | None, int | None, str | None]]:
    rows: list[tuple[str, int, str, str, int, int | None, int | None, str | None]] = []
    for i, (msg_id, msg_type, _seq, user_turn, branch_turn, tool_name) in enumerate(
        messages
    ):
        rows.append(
            (
                session_id,
                msg_id,
                new_branch_id,
                msg_type,
                seq_start + i + 1,
                user_turn,
                branch_turn,
                tool_name,
            )
        )
    return rows


class AgentermSQLiteSession(AdvancedSQLiteSession):
    """AdvancedSQLiteSession with agenterm artifact hygiene."""

    # Keep this aligned with the upstream Session protocol field type.
    session_settings: SessionSettings | None

    @property
    def current_branch_id(self) -> str:
        """Return the current branch id."""
        return self._current_branch_id

    async def add_items(self, items: list[TResponseInputItem]) -> None:
        """Persist items, extracting large artifacts and stripping base64 blobs."""
        if not items:
            return

        store = AsyncStore(meta_store_path())
        sanitized: list[TResponseInputItem] = []
        for item in items:
            if item.get("type") != "image_generation_call":
                sanitized.append(item)
                continue

            call_id = item.get("id")
            result_b64 = item.get("result")
            if not (isinstance(call_id, str) and call_id):
                sanitized.append(item)
                continue
            if not (isinstance(result_b64, str) and result_b64):
                # No payload to extract; keep as-is.
                sanitized.append(item)
                continue

            await persist_image_generation_call(
                store=store,
                session_id=self.session_id,
                call_id=call_id,
                result_b64=result_b64,
            )
            status_raw = item.get("status")
            status = parse_image_call_status(
                status_raw if isinstance(status_raw, str) else None,
            )
            scrubbed: ImageGenerationCallInputItem = {
                "type": "image_generation_call",
                "id": call_id,
                "status": status,
                "result": None,
            }
            sanitized.append(scrubbed)

        json_safe = [
            serialize_input_item_param(item, context="session.add_items")
            for item in sanitized
        ]
        await super().add_items(json_safe)

    async def create_branch_from_head(self, branch_id: str) -> str:
        """Create a new branch by copying all messages from the current branch."""
        if not branch_id or not branch_id.strip():
            msg = "Branch ID cannot be empty"
            raise ValueError(msg)
        new_branch_id = branch_id.strip()

        def _copy_sync() -> int:
            conn = self._get_connection()
            lock = self._lock if self._is_memory_db else threading.Lock()
            with lock, closing(conn.cursor()) as cursor:
                _ensure_branch_absent(
                    cursor,
                    session_id=self.session_id,
                    branch_id=new_branch_id,
                )
                messages_to_copy = _fetch_branch_messages(
                    cursor,
                    session_id=self.session_id,
                    branch_id=self._current_branch_id,
                )
                seq_start = _next_sequence_start(cursor, session_id=self.session_id)
                new_structure_data = _build_structure_rows(
                    session_id=self.session_id,
                    new_branch_id=new_branch_id,
                    seq_start=seq_start,
                    messages=messages_to_copy,
                )

                cursor.executemany(
                    """
                    INSERT INTO message_structure
                    (session_id, message_id, branch_id, message_type, sequence_number,
                     user_turn_number, branch_turn_number, tool_name)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    new_structure_data,
                )

                conn.commit()
                return len(messages_to_copy)

        copied = await asyncio.to_thread(_copy_sync)
        old_branch = self._current_branch_id
        self._current_branch_id = new_branch_id
        self._logger.debug(
            "Created branch '%s' from head '%s' (%s messages)",
            new_branch_id,
            old_branch,
            copied,
        )
        return new_branch_id


__all__ = ("AgentermSQLiteSession",)
