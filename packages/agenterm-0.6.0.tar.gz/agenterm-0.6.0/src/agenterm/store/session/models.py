"""Session store models and input callback helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agents.memory import Session, SessionInputCallback

if TYPE_CHECKING:
    from agents.items import TResponseInputItem


@dataclass(frozen=True)
class SessionMetadata:
    """Metadata row for a session managed by agenterm."""

    session_id: str
    kind: str
    cwd: str
    config_path: str | None
    model: str
    tools_enabled: bool
    trace_id: str | None
    group_id: str | None
    head_branch_id: str
    created_at: str | None
    updated_at: str | None


async def default_session_input_callback(
    history_items: list[TResponseInputItem],
    new_items: list[TResponseInputItem],
) -> list[TResponseInputItem]:
    """Stateless strategy: append history then new items."""
    return [*history_items, *new_items]


DEFAULT_SESSION_INPUT_CALLBACK: SessionInputCallback = default_session_input_callback


__all__ = (
    "DEFAULT_SESSION_INPUT_CALLBACK",
    "Session",
    "SessionInputCallback",
    "SessionMetadata",
    "default_session_input_callback",
)
