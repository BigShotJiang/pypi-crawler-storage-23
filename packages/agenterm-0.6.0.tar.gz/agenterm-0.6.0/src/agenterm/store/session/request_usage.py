"""Request-usage ledger repository (async)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Final, Literal

from agenterm.core.errors import DatabaseError
from agenterm.core.token_usage import TokenUsage
from agenterm.store.history import ensure_history_tables
from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    from collections.abc import Iterable

    import aiosqlite

    from agenterm.store.async_db import AsyncStore

type RequestKind = Literal["response", "compaction", "steward"]
type _Row = tuple[str | int | float | bytes | None, ...]

_EXPECTED_USAGE_COLS: Final[int] = 6
_EXPECTED_RUN_USAGE_COLS: Final[int] = 7


@dataclass(frozen=True)
class RequestUsageRecord:
    """Stored per-request usage record."""

    session_id: str
    branch_id: str
    kind: RequestKind
    run_number: int
    request_index: int
    model: str
    response_id: str | None
    usage: TokenUsage


def _usage_from_row(
    row: _Row,
    *,
    context: str,
) -> TokenUsage:
    if len(row) < _EXPECTED_USAGE_COLS:
        msg = f"{context} returned unexpected column count"
        raise DatabaseError(msg)
    (
        requests_val,
        input_tokens,
        input_cached_tokens,
        output_tokens,
        output_reasoning_tokens,
        total_tokens,
    ) = row[:6]
    try:
        requests = int(requests_val) if requests_val is not None else 0
        in_tokens = int(input_tokens) if input_tokens is not None else 0
        cached_tokens = (
            int(input_cached_tokens) if input_cached_tokens is not None else 0
        )
        out_tokens = int(output_tokens) if output_tokens is not None else 0
        reasoning_tokens = (
            int(output_reasoning_tokens) if output_reasoning_tokens is not None else 0
        )
        total = int(total_tokens) if total_tokens is not None else 0
    except (TypeError, ValueError) as exc:
        msg = f"{context} returned non-numeric usage values"
        raise DatabaseError(msg) from exc
    return TokenUsage(
        requests=requests,
        input_tokens=in_tokens,
        input_cached_tokens=cached_tokens,
        output_tokens=out_tokens,
        output_reasoning_tokens=reasoning_tokens,
        total_tokens=total,
    )


async def current_branch_turn_number(
    store: AsyncStore,
    session_id: str,
    *,
    branch_id: str = "main",
) -> int:
    """Return the current branch turn number from Agents message_structure."""

    async def _op(conn: aiosqlite.Connection) -> int:
        await ensure_history_tables(conn, tables=("message_structure",))
        cur = await conn.execute(
            """
            SELECT COALESCE(MAX(branch_turn_number), 0)
            FROM message_structure
            WHERE session_id = ? AND branch_id = ?
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        if row is None:
            return 0
        val = row[0]
        if val is None:
            return 0
        try:
            return int(val)
        except (TypeError, ValueError) as exc:
            msg = "message_structure.branch_turn_number is not numeric"
            raise DatabaseError(msg) from exc

    return await store.run(_op)


async def next_request_index(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    kind: RequestKind,
    run_number: int,
) -> int:
    """Return the next request index for a session/kind/run."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> int:
        cur = await conn.execute(
            """
            SELECT COALESCE(MAX(request_index), -1)
            FROM agenterm_request_usage
            WHERE session_id = ? AND branch_id = ? AND kind = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), str(kind), int(run_number)),
        )
        row = await cur.fetchone()
        if row is None:
            return 0
        try:
            return int(row[0]) + 1
        except (TypeError, ValueError) as exc:
            msg = "agenterm_request_usage.request_index is not numeric"
            raise DatabaseError(msg) from exc

    return await store.run(_op)


async def insert_request_usage(
    *,
    store: AsyncStore,
    records: Iterable[RequestUsageRecord],
) -> None:
    """Insert request-usage ledger records."""
    await ensure_store_schema(store.db_path)
    rows: list[tuple[str | int | None, ...]] = []
    for rec in records:
        usage = rec.usage
        rows.append(
            (
                rec.session_id,
                rec.branch_id,
                rec.kind,
                int(rec.run_number),
                int(rec.request_index),
                rec.model,
                rec.response_id,
                int(usage.requests),
                int(usage.input_tokens),
                int(usage.input_cached_tokens),
                int(usage.output_tokens),
                int(usage.output_reasoning_tokens),
                int(usage.total_tokens),
            ),
        )
    if not rows:
        return

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.executemany(
            """
            INSERT INTO agenterm_request_usage (
                session_id,
                branch_id,
                kind,
                run_number,
                request_index,
                model,
                response_id,
                requests,
                input_tokens,
                input_cached_tokens,
                output_tokens,
                output_reasoning_tokens,
                total_tokens
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(session_id, branch_id, kind, run_number, request_index)
            DO UPDATE SET
                model = excluded.model,
                response_id = excluded.response_id,
                requests = excluded.requests,
                input_tokens = excluded.input_tokens,
                input_cached_tokens = excluded.input_cached_tokens,
                output_tokens = excluded.output_tokens,
                output_reasoning_tokens = excluded.output_reasoning_tokens,
                total_tokens = excluded.total_tokens
            """,
            rows,
        )
        await conn.commit()

    await store.run(_op)


async def session_usage_totals(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str | None = None,
) -> TokenUsage | None:
    """Return aggregated usage totals for a session or branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> _Row | None:
        if branch_id is None:
            query = """
                SELECT
                    COUNT(*) as requests,
                    SUM(input_tokens),
                    SUM(input_cached_tokens),
                    SUM(output_tokens),
                    SUM(output_reasoning_tokens),
                    SUM(total_tokens)
                FROM agenterm_request_usage
                WHERE session_id = ?
                """
            params = (str(session_id),)
        else:
            query = """
                SELECT
                    COUNT(*) as requests,
                    SUM(input_tokens),
                    SUM(input_cached_tokens),
                    SUM(output_tokens),
                    SUM(output_reasoning_tokens),
                    SUM(total_tokens)
                FROM agenterm_request_usage
                WHERE session_id = ? AND branch_id = ?
                """
            params = (str(session_id), str(branch_id))
        cur = await conn.execute(query, params)
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    count_val = row[0]
    if count_val is None:
        return None
    try:
        if int(count_val) <= 0:
            return None
    except (TypeError, ValueError) as exc:
        msg = "agenterm_request_usage COUNT(*) is not numeric"
        raise DatabaseError(msg) from exc
    return _usage_from_row(row, context="session_usage_totals")


async def usage_totals_by_run(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str | None = None,
) -> dict[int, TokenUsage]:
    """Return per-run usage totals for a session or branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> list[_Row]:
        if branch_id is None:
            query = """
                SELECT
                    run_number,
                    COUNT(*) as requests,
                    SUM(input_tokens),
                    SUM(input_cached_tokens),
                    SUM(output_tokens),
                    SUM(output_reasoning_tokens),
                    SUM(total_tokens)
                FROM agenterm_request_usage
                WHERE session_id = ?
                GROUP BY run_number
                ORDER BY run_number ASC
            """
            params = (str(session_id),)
        else:
            query = """
                SELECT
                    run_number,
                    COUNT(*) as requests,
                    SUM(input_tokens),
                    SUM(input_cached_tokens),
                    SUM(output_tokens),
                    SUM(output_reasoning_tokens),
                    SUM(total_tokens)
                FROM agenterm_request_usage
                WHERE session_id = ? AND branch_id = ?
                GROUP BY run_number
                ORDER BY run_number ASC
            """
            params = (str(session_id), str(branch_id))
        cur = await conn.execute(query, params)
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    out: dict[int, TokenUsage] = {}
    for row in rows:
        if len(row) < _EXPECTED_RUN_USAGE_COLS:
            msg = "usage_totals_by_run returned unexpected column count"
            raise DatabaseError(msg)
        run_val = row[0]
        if run_val is None:
            msg = "agenterm_request_usage.run_number is not numeric"
            raise DatabaseError(msg)
        try:
            run_number = int(run_val)
        except (TypeError, ValueError) as exc:
            msg = "agenterm_request_usage.run_number is not numeric"
            raise DatabaseError(msg) from exc
        usage = _usage_from_row(row[1:], context="usage_totals_by_run")
        out[run_number] = usage
    return out


__all__ = (
    "RequestKind",
    "RequestUsageRecord",
    "current_branch_turn_number",
    "insert_request_usage",
    "next_request_index",
    "session_usage_totals",
    "usage_totals_by_run",
)
