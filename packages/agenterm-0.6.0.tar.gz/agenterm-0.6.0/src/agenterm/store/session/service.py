"""Session store service facade."""

from __future__ import annotations

from agenterm.store.session.factory import (
    SessionFactoryConfig,
    SessionFactoryMode,
    SessionFactoryResult,
    make_session,
    session_db_path,
    session_store,
)
from agenterm.store.session.last_message import (
    LastMessageSnippet,
    last_message_snippets_by_branch,
)
from agenterm.store.session.models import (
    DEFAULT_SESSION_INPUT_CALLBACK,
    Session,
    SessionInputCallback,
    SessionMetadata,
)
from agenterm.store.session.repo import (
    delete_session_metadata,
    get_session_metadata_row,
    list_session_metadata,
    update_session_head,
    update_session_model,
)
from agenterm.store.session.request_usage import (
    RequestKind,
    RequestUsageRecord,
    current_branch_turn_number,
    insert_request_usage,
    next_request_index,
    session_usage_totals,
    usage_totals_by_run,
)
from agenterm.store.session.usage import store_run_usage

__all__ = (
    "DEFAULT_SESSION_INPUT_CALLBACK",
    "LastMessageSnippet",
    "RequestKind",
    "RequestUsageRecord",
    "Session",
    "SessionFactoryConfig",
    "SessionFactoryMode",
    "SessionFactoryResult",
    "SessionInputCallback",
    "SessionMetadata",
    "current_branch_turn_number",
    "delete_session_metadata",
    "get_session_metadata_row",
    "insert_request_usage",
    "last_message_snippets_by_branch",
    "list_session_metadata",
    "make_session",
    "next_request_index",
    "session_db_path",
    "session_store",
    "session_usage_totals",
    "store_run_usage",
    "update_session_head",
    "update_session_model",
    "usage_totals_by_run",
)
