"""Metadata repository for sessions (async)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.errors import DatabaseError
from agenterm.store.schema import ensure_store_schema
from agenterm.store.session.schema import row_to_metadata

if TYPE_CHECKING:
    from pathlib import Path

    import aiosqlite

    from agenterm.store.async_db import AsyncStore
    from agenterm.store.session.models import SessionMetadata


@dataclass(frozen=True)
class SessionMetadataUpsert:
    """Input payload for inserting/updating a session metadata row."""

    session_id: str
    kind: str
    cwd: Path
    config_path: Path | None
    model: str
    tools_enabled: bool
    trace_id: str | None
    group_id: str | None
    head_branch_id: str


async def list_session_metadata(store: AsyncStore) -> list[SessionMetadata]:
    """Return all session metadata rows, most recently updated first."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        cur = await conn.execute(
            """
            SELECT session_id,
                   kind,
                   cwd,
                   config_path,
                   model,
                   tools_enabled,
                   trace_id,
                   group_id,
                   head_branch_id,
                   created_at,
                   updated_at
            FROM agenterm_sessions
            ORDER BY updated_at DESC
            """,
        )
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return [row_to_metadata(tuple(r)) for r in rows]


async def get_session_metadata_row(
    store: AsyncStore,
    session_id: str,
) -> SessionMetadata | None:
    """Return a single session metadata row when it exists."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str | int | float | bytes | None, ...] | None:
        cur = await conn.execute(
            """
            SELECT session_id,
                   kind,
                   cwd,
                   config_path,
                   model,
                   tools_enabled,
                   trace_id,
                   group_id,
                   head_branch_id,
                   created_at,
                   updated_at
            FROM agenterm_sessions
            WHERE session_id = ?
            """,
            (session_id,),
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    return row_to_metadata(tuple(row))


async def _upsert_session_metadata(
    *,
    store: AsyncStore,
    payload: SessionMetadataUpsert,
) -> None:
    """Insert or update metadata for a session."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            INSERT INTO agenterm_sessions (
                session_id, kind, cwd, config_path, model, tools_enabled,
                trace_id, group_id, head_branch_id
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(session_id) DO UPDATE SET
                kind=excluded.kind,
                cwd=excluded.cwd,
                config_path=excluded.config_path,
                model=excluded.model,
                tools_enabled=excluded.tools_enabled,
                trace_id=excluded.trace_id,
                group_id=excluded.group_id,
                head_branch_id=excluded.head_branch_id,
                updated_at=CURRENT_TIMESTAMP
            """,
            (
                payload.session_id,
                payload.kind,
                str(payload.cwd),
                str(payload.config_path) if payload.config_path is not None else None,
                payload.model,
                1 if payload.tools_enabled else 0,
                payload.trace_id,
                payload.group_id,
                payload.head_branch_id,
            ),
        )
        await conn.commit()

    await store.run(_op)


async def upsert_session_metadata(
    *,
    store: AsyncStore,
    payload: SessionMetadataUpsert,
) -> None:
    """Public wrapper around metadata upsert to avoid importing private helpers."""
    await _upsert_session_metadata(store=store, payload=payload)


async def update_session_head(
    *,
    store: AsyncStore,
    session_id: str,
    head_branch_id: str,
) -> None:
    """Persist the head branch id for a session."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            UPDATE agenterm_sessions
            SET head_branch_id = ?, updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ?
            """,
            (head_branch_id, session_id),
        )
        await conn.commit()

    await store.run(_op)


async def update_session_model(
    *,
    store: AsyncStore,
    session_id: str,
    model: str,
) -> None:
    """Persist the model id for a session and bump updated_at."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            UPDATE agenterm_sessions
            SET model = ?, updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ?
            """,
            (str(model), str(session_id)),
        )
        await conn.commit()
        cur = await conn.execute(
            "SELECT 1 FROM agenterm_sessions WHERE session_id = ?",
            (str(session_id),),
        )
        row = await cur.fetchone()
        if row is None:
            msg = f"Session not found: {session_id!r}"
            raise DatabaseError(msg)

    await store.run(_op)


async def delete_session_metadata(
    store: AsyncStore,
    session_id: str,
) -> bool:
    """Delete a session from the metadata table."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> bool:
        cur = await conn.execute(
            """
            DELETE FROM agenterm_sessions
            WHERE session_id = ?
            """,
            (session_id,),
        )
        await conn.commit()
        return cur.rowcount > 0

    return await store.run(_op)


__all__ = (
    "SessionMetadataUpsert",
    "delete_session_metadata",
    "get_session_metadata_row",
    "list_session_metadata",
    "update_session_head",
    "update_session_model",
    "upsert_session_metadata",
)
