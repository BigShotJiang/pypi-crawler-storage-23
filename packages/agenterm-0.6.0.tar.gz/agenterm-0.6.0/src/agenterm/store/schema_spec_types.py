"""Shared schema spec types."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TableSpec:
    """SQLite table specification used for schema validation."""

    name: str
    create_sql: str
    expected_cols: tuple[str, ...]
    notnull_cols: tuple[str, ...]


__all__ = ("TableSpec",)
