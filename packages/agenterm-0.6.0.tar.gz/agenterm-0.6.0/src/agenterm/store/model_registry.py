"""SQLite persistence for the cached OpenAI model registry."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.store.async_db import AsyncStore


@dataclass(frozen=True)
class ModelRegistryRow:
    """Row payload for the cached model registry table."""

    source: str
    fetched_at: int
    models_json: str


async def get_model_registry_row(store: AsyncStore) -> ModelRegistryRow | None:
    """Return the cached model registry row when present."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str, int, str] | None:
        cur = await conn.execute(
            """
            SELECT source,
                   fetched_at,
                   models_json
            FROM agenterm_model_registry
            WHERE id = 1
            """,
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    source, fetched_at, models_json = row
    return ModelRegistryRow(
        source=str(source),
        fetched_at=int(fetched_at),
        models_json=str(models_json),
    )


async def upsert_model_registry_row(
    *,
    store: AsyncStore,
    row: ModelRegistryRow,
) -> None:
    """Insert or update the cached model registry row."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            INSERT INTO agenterm_model_registry (
                id,
                source,
                fetched_at,
                models_json
            )
            VALUES (1, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                source = excluded.source,
                fetched_at = excluded.fetched_at,
                models_json = excluded.models_json
            """,
            (row.source, int(row.fetched_at), row.models_json),
        )
        await conn.commit()

    await store.run(_op)


__all__ = ("ModelRegistryRow", "get_model_registry_row", "upsert_model_registry_row")
