"""Core table specifications for agenterm meta store."""

from __future__ import annotations

from typing import Final

from agenterm.store.schema_spec_types import TableSpec

CORE_TABLE_SPECS: Final[tuple[TableSpec, ...]] = (
    TableSpec(
        name="agenterm_sessions",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_sessions (
            session_id TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            cwd TEXT NOT NULL,
            config_path TEXT,
            model TEXT NOT NULL,
            tools_enabled INTEGER NOT NULL,
            trace_id TEXT,
            group_id TEXT,
            head_branch_id TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """,
        expected_cols=(
            "session_id",
            "kind",
            "cwd",
            "config_path",
            "model",
            "tools_enabled",
            "trace_id",
            "group_id",
            "head_branch_id",
            "created_at",
            "updated_at",
        ),
        notnull_cols=(
            "kind",
            "cwd",
            "model",
            "tools_enabled",
            "head_branch_id",
        ),
    ),
    TableSpec(
        name="agenterm_branch_meta",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_branch_meta (
            session_id TEXT NOT NULL, branch_id TEXT NOT NULL,
            kind TEXT NOT NULL
                CHECK (kind IN ('main', 'fork', 'agent', 'compaction', 'snapshot')),
            title TEXT,
            pinned INTEGER NOT NULL CHECK (pinned IN (0, 1)),
            created_reason TEXT,
            parent_branch_id TEXT,
            fork_run_number INTEGER,
            agent_name TEXT NOT NULL,
            agent_path TEXT,
            agent_sha256 TEXT,
            store_enabled INTEGER NOT NULL CHECK (store_enabled IN (0, 1)),
            last_response_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (session_id, branch_id),
            FOREIGN KEY (session_id) REFERENCES agenterm_sessions(session_id)
                ON DELETE CASCADE
        )
        """,
        expected_cols=(
            "session_id",
            "branch_id",
            "kind",
            "title",
            "pinned",
            "created_reason",
            "parent_branch_id",
            "fork_run_number",
            "agent_name",
            "agent_path",
            "agent_sha256",
            "store_enabled",
            "last_response_id",
            "created_at",
            "updated_at",
        ),
        notnull_cols=(
            "session_id",
            "branch_id",
            "kind",
            "pinned",
            "agent_name",
            "store_enabled",
        ),
    ),
    TableSpec(
        name="agenterm_runs",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_runs (
            run_id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL, branch_id TEXT NOT NULL,
            run_number INTEGER NOT NULL,
            status TEXT NOT NULL
                CHECK (
                    status IN (
                        'running',
                        'completed',
                        'failed',
                        'cancelled',
                        'timeout'
                    )
                ),
            trace_id TEXT,
            group_id TEXT,
            trace_metadata_json TEXT,
            trace_link_type TEXT NOT NULL
                CHECK (trace_link_type IN ('shared', 'new', 'disabled')),
            response_id TEXT,
            error_json TEXT,
            error_artifact_id TEXT,
            run_error_summary_ref TEXT,
            branch_turn_start INTEGER, branch_turn_end INTEGER,
            recovery_state TEXT
                CHECK (recovery_state IN ('needs_replay', 'replayed')),
            recovery_spool_path TEXT,
            started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(session_id, branch_id, run_number),
            FOREIGN KEY (session_id, branch_id)
                REFERENCES agenterm_branch_meta(session_id, branch_id)
                ON DELETE CASCADE
        )
        """,
        expected_cols=(
            "run_id",
            "session_id",
            "branch_id",
            "run_number",
            "status",
            "trace_id",
            "group_id",
            "trace_metadata_json",
            "trace_link_type",
            "response_id",
            "error_json",
            "error_artifact_id",
            "run_error_summary_ref",
            "branch_turn_start",
            "branch_turn_end",
            "recovery_state",
            "recovery_spool_path",
            "started_at",
            "updated_at",
        ),
        notnull_cols=(
            "session_id",
            "branch_id",
            "run_number",
            "status",
            "trace_link_type",
        ),
    ),
    TableSpec(
        name="agenterm_run_events",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_run_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            branch_id TEXT NOT NULL,
            run_number INTEGER NOT NULL,
            request_index INTEGER NOT NULL, event_seq INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            response_id TEXT,
            model TEXT NOT NULL,
            event_json TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(session_id, branch_id, run_number, request_index, event_seq),
            FOREIGN KEY (session_id, branch_id)
                REFERENCES agenterm_branch_meta(session_id, branch_id)
                ON DELETE CASCADE
        )
        """,
        expected_cols=(
            "id",
            "session_id",
            "branch_id",
            "run_number",
            "request_index",
            "event_seq",
            "event_type",
            "response_id",
            "model",
            "event_json",
            "created_at",
        ),
        notnull_cols=(
            "session_id",
            "branch_id",
            "run_number",
            "request_index",
            "event_seq",
            "event_type",
            "model",
            "event_json",
        ),
    ),
    TableSpec(
        name="agenterm_turn_attempts",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_turn_attempts (
            session_id TEXT NOT NULL,
            branch_id TEXT NOT NULL,
            run_number INTEGER NOT NULL,
            status TEXT NOT NULL CHECK (status IN ('active', 'cancelled')),
            cancel_reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (session_id, branch_id, run_number),
            FOREIGN KEY (session_id, branch_id)
                REFERENCES agenterm_branch_meta(session_id, branch_id)
                ON DELETE CASCADE
        )
        """,
        expected_cols=(
            "session_id",
            "branch_id",
            "run_number",
            "status",
            "cancel_reason",
            "created_at",
            "updated_at",
        ),
        notnull_cols=(
            "session_id",
            "branch_id",
            "run_number",
            "status",
        ),
    ),
    TableSpec(
        name="agenterm_turn_attempt_items",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_turn_attempt_items (
            session_id TEXT NOT NULL,
            branch_id TEXT NOT NULL,
            run_number INTEGER NOT NULL,
            item_seq INTEGER NOT NULL,
            item_type TEXT NOT NULL,
            item_json TEXT NOT NULL,
            seen_by_model INTEGER NOT NULL CHECK (seen_by_model IN (0, 1)),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (session_id, branch_id, run_number, item_seq),
            FOREIGN KEY (session_id, branch_id, run_number)
                REFERENCES agenterm_turn_attempts(session_id, branch_id, run_number)
                ON DELETE CASCADE
        )
        """,
        expected_cols=(
            "session_id",
            "branch_id",
            "run_number",
            "item_seq",
            "item_type",
            "item_json",
            "seen_by_model",
            "created_at",
        ),
        notnull_cols=(
            "session_id",
            "branch_id",
            "run_number",
            "item_seq",
            "item_type",
            "item_json",
            "seen_by_model",
        ),
    ),
)


__all__ = ("CORE_TABLE_SPECS",)
