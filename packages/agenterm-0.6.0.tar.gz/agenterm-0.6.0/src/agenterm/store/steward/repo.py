"""SQLite repository for Steward tasks."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from agenterm.core.errors import DatabaseError
from agenterm.store.codec import (
    decode_json_value,
    encode_json_value,
    optional_text,
    require_text,
)
from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore

type StewardTaskKind = Literal["snapshot", "compaction"]
type StewardTaskTrigger = Literal["auto", "manual", "tool"]
type StewardTaskStatus = Literal[
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
]


@dataclass(frozen=True)
class StewardTaskRecord:
    """Persisted Steward task row."""

    task_id: str
    session_id: str
    branch_id: str
    snapshot_branch_id: str | None
    kind: StewardTaskKind
    trigger: StewardTaskTrigger
    status: StewardTaskStatus
    model: str
    input: JSONValue
    trace_id: str | None
    response_id: str | None
    error: JSONValue | None
    created_at: str | None
    started_at: str | None
    completed_at: str | None


def _row_to_task(
    row: tuple[str | int | float | bytes | None, ...],
) -> StewardTaskRecord:
    (
        task_id,
        session_id,
        branch_id,
        snapshot_branch_id,
        kind,
        trigger,
        status,
        model,
        input_json,
        trace_id,
        response_id,
        error_json,
        created_at,
        started_at,
        completed_at,
    ) = row
    task_id = require_text(task_id, field="agenterm_steward_tasks.task_id")
    session_id = require_text(session_id, field="agenterm_steward_tasks.session_id")
    branch_id = require_text(branch_id, field="agenterm_steward_tasks.branch_id")
    kind = require_text(kind, field="agenterm_steward_tasks.kind")
    trigger = require_text(trigger, field="agenterm_steward_tasks.trigger")
    status = require_text(status, field="agenterm_steward_tasks.status")
    model = require_text(model, field="agenterm_steward_tasks.model")
    input_text = require_text(input_json, field="agenterm_steward_tasks.input_json")
    input_payload = decode_json_value(
        input_text,
        context="agenterm_steward_tasks.input_json",
    )
    error_text = optional_text(
        error_json,
        field="agenterm_steward_tasks.error_json",
    )
    error_payload = (
        decode_json_value(error_text, context="agenterm_steward_tasks.error_json")
        if error_text is not None
        else None
    )

    kind_val = _require_kind(kind)
    trigger_val = _require_trigger(trigger)
    status_val = _require_status(status)

    return StewardTaskRecord(
        task_id=task_id,
        session_id=session_id,
        branch_id=branch_id,
        snapshot_branch_id=optional_text(
            snapshot_branch_id,
            field="agenterm_steward_tasks.snapshot_branch_id",
        ),
        kind=kind_val,
        trigger=trigger_val,
        status=status_val,
        model=model,
        input=input_payload,
        trace_id=optional_text(trace_id, field="agenterm_steward_tasks.trace_id"),
        response_id=optional_text(
            response_id,
            field="agenterm_steward_tasks.response_id",
        ),
        error=error_payload,
        created_at=optional_text(
            created_at,
            field="agenterm_steward_tasks.created_at",
        ),
        started_at=optional_text(
            started_at,
            field="agenterm_steward_tasks.started_at",
        ),
        completed_at=optional_text(
            completed_at,
            field="agenterm_steward_tasks.completed_at",
        ),
    )


def _require_kind(value: str) -> StewardTaskKind:
    if value == "snapshot":
        return "snapshot"
    if value == "compaction":
        return "compaction"
    msg = f"agenterm_steward_tasks.kind must be snapshot|compaction, got {value!r}"
    raise DatabaseError(msg)


def _require_trigger(value: str) -> StewardTaskTrigger:
    if value == "auto":
        return "auto"
    if value == "manual":
        return "manual"
    if value == "tool":
        return "tool"
    msg = f"agenterm_steward_tasks.trigger must be auto|manual|tool, got {value!r}"
    raise DatabaseError(msg)


def _require_status(value: str) -> StewardTaskStatus:
    if value == "queued":
        return "queued"
    if value == "running":
        return "running"
    if value == "completed":
        return "completed"
    if value == "failed":
        return "failed"
    if value == "cancelled":
        return "cancelled"
    msg = f"agenterm_steward_tasks.status must be a valid status, got {value!r}"
    raise DatabaseError(msg)


async def _get_task_by_id(
    conn: aiosqlite.Connection,
    task_id: str,
) -> tuple[str | int | float | bytes | None, ...] | None:
    cur = await conn.execute(
        """
        SELECT
            task_id,
            session_id,
            branch_id,
            snapshot_branch_id,
            kind,
            trigger,
            status,
            model,
            input_json,
            trace_id,
            response_id,
            error_json,
            created_at,
            started_at,
            completed_at
        FROM agenterm_steward_tasks
        WHERE task_id = ?
        """,
        (str(task_id),),
    )
    row = await cur.fetchone()
    return tuple(row) if row is not None else None


async def insert_steward_task(
    *,
    store: AsyncStore,
    task_id: str,
    session_id: str,
    branch_id: str,
    kind: StewardTaskKind,
    trigger: StewardTaskTrigger,
    status: StewardTaskStatus,
    model: str,
    input_payload: JSONValue,
    trace_id: str | None,
) -> StewardTaskRecord:
    """Insert a Steward task row and return the persisted task."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> StewardTaskRecord:
        input_json = encode_json_value(
            input_payload,
            context="agenterm_steward_tasks.input_json",
            sort_keys=True,
            ensure_ascii=True,
        )
        await conn.execute(
            """
            INSERT INTO agenterm_steward_tasks (
                task_id,
                session_id,
                branch_id,
                snapshot_branch_id,
                kind,
                trigger,
                status,
                model,
                input_json,
                trace_id
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(task_id),
                str(session_id),
                str(branch_id),
                None,
                str(kind),
                str(trigger),
                str(status),
                str(model),
                input_json,
                trace_id,
            ),
        )
        await conn.commit()
        row = await _get_task_by_id(conn, task_id)
        if row is None:
            msg = "Failed to read back inserted Steward task"
            raise DatabaseError(msg)
        return _row_to_task(row)

    return await store.run(_op)


async def mark_steward_task_running(
    *,
    store: AsyncStore,
    task_id: str,
) -> StewardTaskRecord:
    """Mark a Steward task as running and set started_at."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> StewardTaskRecord:
        await conn.execute(
            """
            UPDATE agenterm_steward_tasks
            SET status = ?, started_at = CURRENT_TIMESTAMP
            WHERE task_id = ?
            """,
            ("running", str(task_id)),
        )
        await conn.commit()
        row = await _get_task_by_id(conn, task_id)
        if row is None:
            msg = "Failed to read back Steward task after running update"
            raise DatabaseError(msg)
        return _row_to_task(row)

    return await store.run(_op)


async def count_pending_steward_tasks(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> int:
    """Return the number of queued/running Steward tasks for a session branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> int:
        cur = await conn.execute(
            """
            SELECT COUNT(*) FROM agenterm_steward_tasks
            WHERE session_id = ? AND branch_id = ?
              AND status IN ('queued', 'running')
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        count = row[0] if row is not None else 0
        if isinstance(count, int):
            return count
        if isinstance(count, float):
            return int(count)
        return 0

    return await store.run(_op)


async def cancel_stale_running_steward_tasks(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    stale_after_seconds: int,
) -> int:
    """Cancel stale running tasks for a session branch and return update count."""
    if stale_after_seconds < 1:
        msg = "stale_after_seconds must be a positive integer"
        raise DatabaseError(msg)
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> int:
        error_json = encode_json_value(
            {
                "kind": "stale_task_evicted",
                "message": "Cancelled stale running steward task",
                "details": {
                    "status": "running",
                    "stale_after_seconds": stale_after_seconds,
                },
            },
            context="agenterm_steward_tasks.error_json",
            sort_keys=True,
            ensure_ascii=True,
        )
        age_modifier = f"-{stale_after_seconds} seconds"
        cur = await conn.execute(
            """
            UPDATE agenterm_steward_tasks
            SET status = 'cancelled',
                error_json = COALESCE(error_json, ?),
                completed_at = CURRENT_TIMESTAMP
            WHERE session_id = ? AND branch_id = ?
              AND status = 'running'
              AND started_at IS NOT NULL
              AND started_at <= datetime('now', ?)
            """,
            (
                error_json,
                str(session_id),
                str(branch_id),
                age_modifier,
            ),
        )
        await conn.commit()
        row_count = cur.rowcount
        if row_count >= 0:
            return row_count
        cur = await conn.execute("SELECT changes()")
        row = await cur.fetchone()
        changes = row[0] if row is not None else 0
        return int(changes)

    return await store.run(_op)


async def finalize_steward_task(
    *,
    store: AsyncStore,
    task_id: str,
    status: StewardTaskStatus,
    snapshot_branch_id: str | None,
    response_id: str | None,
    error_payload: JSONValue | None,
) -> StewardTaskRecord:
    """Finalize a Steward task with terminal status and optional outputs."""
    if status not in ("completed", "failed", "cancelled"):
        msg = "Steward task final status must be completed|failed|cancelled"
        raise DatabaseError(msg)
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> StewardTaskRecord:
        error_json = (
            encode_json_value(
                error_payload,
                context="agenterm_steward_tasks.error_json",
                sort_keys=True,
                ensure_ascii=True,
            )
            if error_payload is not None
            else None
        )
        await conn.execute(
            """
            UPDATE agenterm_steward_tasks
            SET status = ?,
                snapshot_branch_id = ?,
                response_id = ?,
                error_json = ?,
                completed_at = CURRENT_TIMESTAMP
            WHERE task_id = ?
            """,
            (
                str(status),
                str(snapshot_branch_id) if snapshot_branch_id is not None else None,
                str(response_id) if response_id is not None else None,
                error_json,
                str(task_id),
            ),
        )
        await conn.commit()
        row = await _get_task_by_id(conn, task_id)
        if row is None:
            msg = "Failed to read back Steward task after finalize update"
            raise DatabaseError(msg)
        return _row_to_task(row)

    return await store.run(_op)


__all__ = (
    "StewardTaskKind",
    "StewardTaskRecord",
    "StewardTaskStatus",
    "StewardTaskTrigger",
    "cancel_stale_running_steward_tasks",
    "count_pending_steward_tasks",
    "finalize_steward_task",
    "insert_steward_task",
    "mark_steward_task_running",
)
