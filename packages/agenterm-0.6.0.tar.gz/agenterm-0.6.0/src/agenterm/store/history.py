"""History store helpers for vendor session tables."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.paths import history_db_path
from agenterm.core.errors import ConfigError
from agenterm.store.async_db import AsyncStore

if TYPE_CHECKING:
    from collections.abc import Iterable

    import aiosqlite

HISTORY_TABLES: tuple[str, ...] = (
    "agent_sessions",
    "agent_messages",
    "message_structure",
    "turn_usage",
)


def history_store() -> AsyncStore:
    """Return AsyncStore bound to the history SQLite database."""
    return AsyncStore(history_db_path())


async def _table_exists(conn: aiosqlite.Connection, *, table: str) -> bool:
    cur = await conn.execute(
        """
        SELECT name
        FROM sqlite_master
        WHERE type = 'table' AND name = ?
        """,
        (str(table),),
    )
    row = await cur.fetchone()
    return row is not None


async def ensure_history_tables(
    conn: aiosqlite.Connection,
    *,
    tables: Iterable[str] | None = None,
) -> None:
    """Ensure vendor history tables exist."""
    targets = tuple(tables) if tables is not None else HISTORY_TABLES
    missing = [name for name in targets if not await _table_exists(conn, table=name)]
    if not missing:
        return
    msg = (
        "History tables missing; initialize a session to create vendor tables "
        f"(missing: {', '.join(missing)})."
    )
    raise ConfigError(msg)


async def ensure_message_structure(conn: aiosqlite.Connection) -> None:
    """Ensure the vendor message_structure table exists."""
    await ensure_history_tables(conn, tables=("message_structure",))


__all__ = (
    "HISTORY_TABLES",
    "ensure_history_tables",
    "ensure_message_structure",
    "history_store",
)
