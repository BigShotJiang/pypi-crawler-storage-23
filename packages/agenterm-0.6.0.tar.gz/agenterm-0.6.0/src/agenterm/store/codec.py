"""Canonical SQLite JSON and row codecs."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import DatabaseError
from agenterm.core.json_codec import (
    dumps_compact,
    is_json_object,
    is_json_value,
    loads_json_value,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

type RowValue = str | int | float | bytes | None


def require_text(value: RowValue, *, field: str) -> str:
    """Return a required text field or raise DatabaseError."""
    if not isinstance(value, str) or not value:
        msg = f"{field} expected str"
        raise DatabaseError(msg)
    return value


def optional_text(value: RowValue, *, field: str) -> str | None:
    """Return an optional text field or raise DatabaseError."""
    if value is None:
        return None
    if not isinstance(value, str):
        msg = f"{field} expected str"
        raise DatabaseError(msg)
    return value


def require_int(value: RowValue, *, field: str) -> int:
    """Return a required int field or raise DatabaseError."""
    if isinstance(value, bool) or not isinstance(value, int):
        msg = f"{field} expected int"
        raise DatabaseError(msg)
    return int(value)


def optional_int(value: RowValue, *, field: str) -> int | None:
    """Return an optional int field or raise DatabaseError."""
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        msg = f"{field} expected int"
        raise DatabaseError(msg)
    return int(value)


def encode_json_value(
    value: JSONValue,
    *,
    context: str,
    sort_keys: bool = True,
    ensure_ascii: bool = True,
) -> str:
    """Encode JSONValue into a compact JSON string."""
    if not is_json_value(value=value):
        msg = f"{context} must be a JSONValue"
        raise DatabaseError(msg)
    try:
        return dumps_compact(
            value,
            sort_keys=sort_keys,
            ensure_ascii=ensure_ascii,
            context=context,
        )
    except (TypeError, ValueError) as exc:
        msg = f"{context} is not JSON-serializable"
        raise DatabaseError(msg) from exc


def encode_json_object(
    value: Mapping[str, JSONValue],
    *,
    context: str,
    sort_keys: bool = True,
    ensure_ascii: bool = True,
) -> str:
    """Encode a JSON object into a compact JSON string."""
    if not is_json_object(value=value):
        msg = f"{context} must be a JSON object"
        raise DatabaseError(msg)
    return encode_json_value(
        dict(value),
        context=context,
        sort_keys=sort_keys,
        ensure_ascii=ensure_ascii,
    )


def encode_json_object_optional(
    value: Mapping[str, JSONValue] | None,
    *,
    context: str,
    sort_keys: bool = True,
    ensure_ascii: bool = True,
) -> str | None:
    """Encode an optional JSON object into a compact JSON string."""
    if value is None:
        return None
    return encode_json_object(
        value,
        context=context,
        sort_keys=sort_keys,
        ensure_ascii=ensure_ascii,
    )


def decode_json_value(
    raw: str,
    *,
    context: str,
) -> JSONValue:
    """Decode a JSON string into JSONValue or raise DatabaseError."""
    try:
        parsed = loads_json_value(raw)
    except (TypeError, ValueError) as exc:
        msg = f"{context} is not valid JSON"
        raise DatabaseError(msg) from exc
    if not is_json_value(value=parsed):
        msg = f"{context} is not a JSONValue"
        raise DatabaseError(msg)
    return parsed


def decode_json_object(
    raw: str,
    *,
    context: str,
) -> dict[str, JSONValue]:
    """Decode a JSON string into a JSON object or raise DatabaseError."""
    parsed = decode_json_value(raw, context=context)
    if not is_json_object(value=parsed):
        msg = f"{context} is not a JSON object"
        raise DatabaseError(msg)
    return dict(parsed)


def decode_json_object_optional(
    raw: str | None,
    *,
    context: str,
) -> dict[str, JSONValue] | None:
    """Decode an optional JSON string into a JSON object."""
    if raw is None:
        return None
    return decode_json_object(raw, context=context)


__all__ = (
    "RowValue",
    "decode_json_object",
    "decode_json_object_optional",
    "decode_json_value",
    "encode_json_object",
    "encode_json_object_optional",
    "encode_json_value",
    "optional_int",
    "optional_text",
    "require_int",
    "require_text",
)
