"""Async SQLite store runtime and registry for agenterm metadata."""

from __future__ import annotations

import asyncio
import sqlite3
import threading
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import aiosqlite

from agenterm.config.paths import ensure_data_dir
from agenterm.constants.limits import STORE_BUSY_TIMEOUT_MS
from agenterm.core.errors import DatabaseError, FilesystemError
from agenterm.core.retry import RetryDecision, RetryPolicy, retry_async

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable
    from pathlib import Path


def _is_locked_error(exc: sqlite3.Error) -> bool:
    return "database is locked" in str(exc).lower()


_DEFAULT_RETRY_POLICY = RetryPolicy(
    max_retries=5,
    base_backoff_seconds=0.05,
    max_backoff_seconds=1.0,
    jitter_ratio=0.25,
    retry_after_max_seconds=None,
)


@dataclass
class _StoreRetryState:
    policy: RetryPolicy


_STORE_RETRY_STATE = _StoreRetryState(policy=_DEFAULT_RETRY_POLICY)


def set_store_retry_policy(policy: RetryPolicy) -> None:
    """Set the global store retry policy."""
    _STORE_RETRY_STATE.policy = policy


def get_store_retry_policy() -> RetryPolicy:
    """Return the global store retry policy."""
    return _STORE_RETRY_STATE.policy


async def _ensure_data_dir_async() -> Path:
    try:
        return await asyncio.to_thread(ensure_data_dir)
    except FilesystemError:
        raise
    except OSError as exc:
        msg = f"Failed to create store directory: {exc}"
        raise FilesystemError(msg) from exc


async def _configure_connection(conn: aiosqlite.Connection) -> None:
    try:
        await conn.execute("PRAGMA journal_mode=WAL")
        await conn.execute(f"PRAGMA busy_timeout={STORE_BUSY_TIMEOUT_MS}")
        await conn.execute("PRAGMA foreign_keys=ON")
    except sqlite3.Error as exc:
        msg = f"Failed to configure store connection: {exc}"
        raise DatabaseError(msg) from exc


async def _run_with_retry[T](
    conn: aiosqlite.Connection,
    op: Callable[[aiosqlite.Connection], Awaitable[T]],
    *,
    retry_policy: RetryPolicy | None,
) -> T:
    policy = retry_policy or get_store_retry_policy()

    async def _call() -> T:
        return await op(conn)

    def _classify(exc: Exception) -> RetryDecision:
        if isinstance(exc, sqlite3.OperationalError) and _is_locked_error(exc):
            return RetryDecision(retry=True, label="sqlite_busy")
        return RetryDecision(retry=False)

    try:
        return await retry_async(
            _call,
            policy=policy,
            retry_on=(sqlite3.Error,),
            classify=_classify,
        )
    except sqlite3.OperationalError as exc:
        msg = f"Store operation failed: {exc}"
        raise DatabaseError(msg) from exc
    except sqlite3.Error as exc:
        msg = f"Store operation failed: {exc}"
        raise DatabaseError(msg) from exc


@dataclass
class _StoreRuntime:
    """Single-connection store runtime bound to one event loop + db path."""

    db_path: Path
    _conn: aiosqlite.Connection | None = None
    _init_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    _op_lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def _ensure_connection(self) -> aiosqlite.Connection:
        if self._conn is not None:
            return self._conn
        async with self._init_lock:
            if self._conn is not None:
                return self._conn
            await _ensure_data_dir_async()
            try:
                conn = await aiosqlite.connect(str(self.db_path))
            except sqlite3.Error as exc:
                msg = f"Failed to open store: {self.db_path} ({exc})"
                raise DatabaseError(msg) from exc
            await _configure_connection(conn)
            self._conn = conn
        return conn

    async def run[T](
        self,
        op: Callable[[aiosqlite.Connection], Awaitable[T]],
        *,
        retry_policy: RetryPolicy | None,
    ) -> T:
        conn = await self._ensure_connection()
        async with self._op_lock:
            return await _run_with_retry(
                conn,
                op,
                retry_policy=retry_policy,
            )

    async def close(self) -> None:
        async with self._init_lock:
            conn = self._conn
            if conn is None:
                return
            async with self._op_lock:
                try:
                    await conn.close()
                except sqlite3.Error as exc:
                    msg = f"Failed to close store: {exc}"
                    raise DatabaseError(msg) from exc
                self._conn = None


@dataclass
class _StoreRegistry:
    _stores: dict[tuple[int, Path], _StoreRuntime] = field(default_factory=dict)
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def runtime_for(self, db_path: Path) -> _StoreRuntime:
        loop_id = id(asyncio.get_running_loop())
        key = (loop_id, db_path)
        with self._lock:
            runtime = self._stores.get(key)
            if runtime is None:
                runtime = _StoreRuntime(
                    db_path=db_path,
                )
                self._stores[key] = runtime
        return runtime

    async def close_all(self) -> None:
        with self._lock:
            runtimes = list(self._stores.values())
            self._stores.clear()
        for runtime in runtimes:
            await runtime.close()


_STORE_REGISTRY = _StoreRegistry()


@dataclass(frozen=True)
class AsyncStore:
    """Async SQLite store facade with WAL + busy-timeout + retry handling."""

    db_path: Path
    retry_policy: RetryPolicy | None = None

    async def run[T](self, op: Callable[[aiosqlite.Connection], Awaitable[T]]) -> T:
        """Execute an operation with retry/backoff for SQLITE_BUSY."""
        runtime = _STORE_REGISTRY.runtime_for(self.db_path)
        return await runtime.run(op, retry_policy=self.retry_policy)


async def close_store_registry() -> None:
    """Close all shared store connections."""
    await _STORE_REGISTRY.close_all()


__all__ = (
    "AsyncStore",
    "close_store_registry",
    "get_store_retry_policy",
    "set_store_retry_policy",
)
