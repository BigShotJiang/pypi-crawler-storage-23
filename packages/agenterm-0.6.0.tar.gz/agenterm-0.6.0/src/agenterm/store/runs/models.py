"""Run status models for the agenterm run ledger."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from agenterm.core.errors import DatabaseError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue
    from agenterm.core.trace_context import TraceLinkType

type RunStatus = Literal["running", "completed", "failed", "cancelled", "timeout"]
type RunRecoveryState = Literal["needs_replay", "replayed"]


@dataclass(frozen=True)
class RunStatusRecord:
    """Persisted status record for a single run attempt."""

    run_id: str
    session_id: str
    branch_id: str
    run_number: int
    status: RunStatus
    trace_id: str | None
    group_id: str | None
    trace_metadata_json: dict[str, JSONValue] | None
    trace_link_type: TraceLinkType
    response_id: str | None
    error_json: dict[str, JSONValue] | None
    error_artifact_id: str | None
    run_error_summary_ref: dict[str, JSONValue] | None
    branch_turn_start: int | None
    branch_turn_end: int | None
    recovery_state: RunRecoveryState | None
    recovery_spool_path: str | None
    started_at: str | None
    updated_at: str | None


@dataclass(frozen=True)
class RunStatusUpdate:
    """Update payload for run status persistence."""

    status: RunStatus
    response_id: str | None
    error_json: Mapping[str, JSONValue] | None
    trace_id: str | None
    group_id: str | None
    trace_metadata_json: Mapping[str, JSONValue] | None
    trace_link_type: TraceLinkType
    error_artifact_id: str | None
    run_error_summary_ref: Mapping[str, JSONValue] | None
    branch_turn_start: int | None
    branch_turn_end: int | None


def parse_run_status(value: str) -> RunStatus:
    """Parse persisted run status text into RunStatus."""
    if value == "running":
        return "running"
    if value == "completed":
        return "completed"
    if value == "failed":
        return "failed"
    if value == "cancelled":
        return "cancelled"
    if value == "timeout":
        return "timeout"
    msg = f"agenterm_runs.status invalid value: {value!r}"
    raise DatabaseError(msg)


def parse_run_recovery_state(value: str | None) -> RunRecoveryState | None:
    """Parse persisted recovery-state text into RunRecoveryState."""
    if value is None:
        return None
    if value == "needs_replay":
        return "needs_replay"
    if value == "replayed":
        return "replayed"
    msg = f"agenterm_runs.recovery_state invalid value: {value!r}"
    raise DatabaseError(msg)


def parse_run_trace_link_type(value: str) -> TraceLinkType:
    """Parse persisted trace-link text into TraceLinkType."""
    if value == "shared":
        return "shared"
    if value == "new":
        return "new"
    if value == "disabled":
        return "disabled"
    msg = f"agenterm_runs.trace_link_type invalid value: {value!r}"
    raise DatabaseError(msg)


__all__ = (
    "RunRecoveryState",
    "RunStatus",
    "RunStatusRecord",
    "RunStatusUpdate",
    "parse_run_recovery_state",
    "parse_run_status",
    "parse_run_trace_link_type",
)
