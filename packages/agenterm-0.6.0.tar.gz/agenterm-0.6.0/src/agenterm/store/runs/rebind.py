"""Run-scoped artifact rebinding.

When a run switches the session head to a new branch (for example via compression
continuations), run-scoped artifacts must be rebound onto the final head branch
so inspection surfaces remain coherent.

This rebinding is purely a meta-store operation (store.sqlite3). It does not
modify vendor history tables (history.sqlite3).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import DatabaseError
from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.store.async_db import AsyncStore


async def rebind_run_artifacts(
    *,
    store: AsyncStore,
    session_id: str,
    from_branch_id: str,
    to_branch_id: str,
    run_number: int,
) -> None:
    """Move run-scoped artifacts from one branch to another.

    This updates:
    - agenterm_runs
    - agenterm_run_events
    - agenterm_request_usage
    - agenterm_turn_attempts + agenterm_turn_attempt_items

    The destination branch must exist in agenterm_branch_meta (FK constraint).

    Idempotency:
    - If no run row exists in from_branch_id but does exist in to_branch_id,
      this is treated as already-rebound (no-op).
    """
    if not session_id:
        return
    if not from_branch_id or not to_branch_id:
        return
    if from_branch_id == to_branch_id:
        return
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute("PRAGMA foreign_keys = ON")
        cur = await conn.execute(
            """
            SELECT run_id
            FROM agenterm_runs
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(from_branch_id), int(run_number)),
        )
        from_row = await cur.fetchone()
        if from_row is None:
            cur = await conn.execute(
                """
                SELECT run_id
                FROM agenterm_runs
                WHERE session_id = ? AND branch_id = ? AND run_number = ?
                """,
                (str(session_id), str(to_branch_id), int(run_number)),
            )
            to_row = await cur.fetchone()
            if to_row is not None:
                return
            return

        cur = await conn.execute(
            """
            SELECT 1
            FROM agenterm_runs
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(to_branch_id), int(run_number)),
        )
        if await cur.fetchone() is not None:
            msg = (
                "Run artifact rebind refused: destination already has a run "
                f"(session_id={session_id!r}, "
                f"branch_id={to_branch_id!r}, "
                f"run={run_number})."
            )
            raise DatabaseError(msg)

        await conn.execute(
            """
            UPDATE agenterm_runs
            SET branch_id = ?, updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(to_branch_id), str(session_id), str(from_branch_id), int(run_number)),
        )
        await conn.execute(
            """
            UPDATE agenterm_run_events
            SET branch_id = ?
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(to_branch_id), str(session_id), str(from_branch_id), int(run_number)),
        )
        await conn.execute(
            """
            UPDATE agenterm_request_usage
            SET branch_id = ?
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(to_branch_id), str(session_id), str(from_branch_id), int(run_number)),
        )

        cur = await conn.execute(
            """
            SELECT status, cancel_reason, created_at, updated_at
            FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(from_branch_id), int(run_number)),
        )
        attempt_row = await cur.fetchone()
        if attempt_row is not None:
            cur = await conn.execute(
                """
                SELECT 1
                FROM agenterm_turn_attempts
                WHERE session_id = ? AND branch_id = ? AND run_number = ?
                """,
                (str(session_id), str(to_branch_id), int(run_number)),
            )
            if await cur.fetchone() is not None:
                msg = (
                    "Turn attempt rebind refused: destination already has an attempt "
                    "row"
                    f" (session_id={session_id!r}, branch_id={to_branch_id!r},"
                    f" run={run_number})."
                )
                raise DatabaseError(msg)

            (status, cancel_reason, created_at, updated_at) = attempt_row
            await conn.execute(
                """
                INSERT INTO agenterm_turn_attempts (
                    session_id,
                    branch_id,
                    run_number,
                    status,
                    cancel_reason,
                    created_at,
                    updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(session_id),
                    str(to_branch_id),
                    int(run_number),
                    status,
                    cancel_reason,
                    created_at,
                    updated_at,
                ),
            )
            await conn.execute(
                """
                UPDATE agenterm_turn_attempt_items
                SET branch_id = ?
                WHERE session_id = ? AND branch_id = ? AND run_number = ?
                """,
                (
                    str(to_branch_id),
                    str(session_id),
                    str(from_branch_id),
                    int(run_number),
                ),
            )
            await conn.execute(
                """
                DELETE FROM agenterm_turn_attempts
                WHERE session_id = ? AND branch_id = ? AND run_number = ?
                """,
                (str(session_id), str(from_branch_id), int(run_number)),
            )

        await conn.commit()

    await store.run(_op)


__all__ = ("rebind_run_artifacts",)
