"""SQLite repository for per-run status tracking."""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

from agenterm.core.errors import DatabaseError
from agenterm.store.codec import (
    decode_json_object_optional,
    encode_json_object_optional,
    optional_text,
    require_int,
    require_text,
)
from agenterm.store.runs.models import (
    RunStatusRecord,
    RunStatusUpdate,
    parse_run_recovery_state,
    parse_run_status,
    parse_run_trace_link_type,
)
from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    from collections.abc import Mapping

    import aiosqlite

    from agenterm.core.json_types import JSONValue
    from agenterm.core.trace_context import TraceLinkType
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.runs.models import RunRecoveryState


def _row_to_record(
    row: tuple[str | int | float | bytes | None, ...],
) -> RunStatusRecord:
    (
        run_id,
        session_id,
        branch_id,
        run_number,
        status,
        trace_id,
        group_id,
        trace_metadata_json,
        trace_link_type,
        response_id,
        error_json,
        error_artifact_id,
        run_error_summary_ref,
        branch_turn_start,
        branch_turn_end,
        recovery_state,
        recovery_spool_path,
        started_at,
        updated_at,
    ) = row
    run_id = require_text(run_id, field="agenterm_runs.run_id")
    session_id = require_text(session_id, field="agenterm_runs.session_id")
    branch_id = require_text(branch_id, field="agenterm_runs.branch_id")
    run_number_int = require_int(run_number, field="agenterm_runs.run_number")
    status = require_text(status, field="agenterm_runs.status")
    status_value = parse_run_status(status)
    trace_val = optional_text(trace_id, field="agenterm_runs.trace_id")
    group_val = optional_text(group_id, field="agenterm_runs.group_id")
    trace_link_type_text = require_text(
        trace_link_type,
        field="agenterm_runs.trace_link_type",
    )
    trace_link_type_value = parse_run_trace_link_type(trace_link_type_text)
    response_val = optional_text(response_id, field="agenterm_runs.response_id")
    error_text = optional_text(error_json, field="agenterm_runs.error_json")
    trace_metadata_text = optional_text(
        trace_metadata_json,
        field="agenterm_runs.trace_metadata_json",
    )
    run_error_ref_text = optional_text(
        run_error_summary_ref,
        field="agenterm_runs.run_error_summary_ref",
    )
    recovery_state_text = optional_text(
        recovery_state,
        field="agenterm_runs.recovery_state",
    )
    recovery_state_val = parse_run_recovery_state(recovery_state_text)
    return RunStatusRecord(
        run_id=run_id,
        session_id=session_id,
        branch_id=branch_id,
        run_number=int(run_number_int),
        status=status_value,
        trace_id=trace_val,
        group_id=group_val,
        trace_metadata_json=decode_json_object_optional(
            trace_metadata_text,
            context="agenterm_runs.trace_metadata_json",
        ),
        trace_link_type=trace_link_type_value,
        response_id=response_val,
        error_json=decode_json_object_optional(
            error_text,
            context="agenterm_runs.error_json",
        ),
        error_artifact_id=optional_text(
            error_artifact_id,
            field="agenterm_runs.error_artifact_id",
        ),
        run_error_summary_ref=decode_json_object_optional(
            run_error_ref_text,
            context="agenterm_runs.run_error_summary_ref",
        ),
        branch_turn_start=require_int(
            branch_turn_start,
            field="agenterm_runs.branch_turn_start",
        )
        if branch_turn_start is not None
        else None,
        branch_turn_end=require_int(
            branch_turn_end,
            field="agenterm_runs.branch_turn_end",
        )
        if branch_turn_end is not None
        else None,
        recovery_state=recovery_state_val,
        recovery_spool_path=optional_text(
            recovery_spool_path,
            field="agenterm_runs.recovery_spool_path",
        ),
        started_at=optional_text(
            started_at,
            field="agenterm_runs.started_at",
        ),
        updated_at=optional_text(
            updated_at,
            field="agenterm_runs.updated_at",
        ),
    )


async def _get_run_by_id(
    conn: aiosqlite.Connection,
    run_id: str,
) -> RunStatusRecord | None:
    cur = await conn.execute(
        """
        SELECT
            run_id,
            session_id,
            branch_id,
            run_number,
            status,
            trace_id,
            group_id,
            trace_metadata_json,
            trace_link_type,
            response_id,
            error_json,
            error_artifact_id,
            run_error_summary_ref,
                branch_turn_start,
                branch_turn_end,
                recovery_state,
                recovery_spool_path,
                started_at,
                updated_at
        FROM agenterm_runs
        WHERE run_id = ?
        """,
        (str(run_id),),
    )
    row = await cur.fetchone()
    if row is None:
        return None
    return _row_to_record(tuple(row))


async def get_run_by_number(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
) -> RunStatusRecord | None:
    """Return the most recent status row for a session/branch run."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> RunStatusRecord | None:
        cur = await conn.execute(
            """
            SELECT
                run_id,
                session_id,
                branch_id,
                run_number,
                status,
                trace_id,
                group_id,
                trace_metadata_json,
                trace_link_type,
                response_id,
                error_json,
                error_artifact_id,
                run_error_summary_ref,
                branch_turn_start,
                branch_turn_end,
                recovery_state,
                recovery_spool_path,
                started_at,
                updated_at
            FROM agenterm_runs
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            ORDER BY updated_at DESC, started_at DESC, run_id DESC
            LIMIT 1
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        row = await cur.fetchone()
        if row is None:
            return None
        return _row_to_record(tuple(row))

    return await store.run(_op)


async def list_runs(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    limit: int | None = None,
) -> tuple[RunStatusRecord, ...]:
    """Return ordered run status records for a session/branch."""
    await ensure_store_schema(store.db_path)
    limit_val = int(limit) if limit is not None else None

    async def _op(conn: aiosqlite.Connection) -> list[RunStatusRecord]:
        query = """
            SELECT
                run_id,
                session_id,
                branch_id,
                run_number,
                status,
                trace_id,
                group_id,
                trace_metadata_json,
                trace_link_type,
                response_id,
                error_json,
                error_artifact_id,
                run_error_summary_ref,
                branch_turn_start,
                branch_turn_end,
                recovery_state,
                recovery_spool_path,
                started_at,
                updated_at
            FROM agenterm_runs
            WHERE session_id = ? AND branch_id = ?
            ORDER BY run_number DESC, updated_at DESC, started_at DESC, run_id DESC
        """
        params: list[str | int] = [str(session_id), str(branch_id)]
        if limit_val is not None:
            query = query + " LIMIT ?"
            params.append(limit_val)
        cur = await conn.execute(query, tuple(params))
        rows = await cur.fetchall()
        return [_row_to_record(tuple(row)) for row in rows]

    rows = await store.run(_op)
    return tuple(rows)


async def next_run_number(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> int:
    """Return the next run number for a session/branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> int:
        cur = await conn.execute(
            """
            SELECT COALESCE(MAX(run_number), 0)
            FROM agenterm_runs
            WHERE session_id = ? AND branch_id = ?
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        if row is None:
            return 1
        try:
            return int(row[0]) + 1
        except (TypeError, ValueError) as exc:
            msg = "agenterm_runs.run_number is not numeric"
            raise DatabaseError(msg) from exc

    return await store.run(_op)


async def insert_run_start(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    trace_id: str | None,
    group_id: str | None,
    trace_metadata_json: Mapping[str, JSONValue] | None,
    trace_link_type: TraceLinkType,
) -> RunStatusRecord:
    """Insert a running run record and return it."""
    await ensure_store_schema(store.db_path)
    run_id = str(uuid.uuid4())
    encoded_trace_metadata = encode_json_object_optional(
        trace_metadata_json,
        context="agenterm_runs.trace_metadata_json",
        sort_keys=True,
        ensure_ascii=True,
    )

    async def _op(conn: aiosqlite.Connection) -> RunStatusRecord:
        await conn.execute(
            """
            INSERT INTO agenterm_runs (
                run_id,
                session_id,
                branch_id,
                run_number,
                status,
                trace_id,
                group_id,
                trace_metadata_json,
                trace_link_type,
                recovery_state,
                recovery_spool_path
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL)
            """,
            (
                run_id,
                str(session_id),
                str(branch_id),
                int(run_number),
                "running",
                trace_id,
                group_id,
                encoded_trace_metadata,
                str(trace_link_type),
            ),
        )
        await conn.commit()
        record = await _get_run_by_id(conn, run_id)
        if record is None:
            msg = "Failed to read back inserted run record"
            raise DatabaseError(msg)
        return record

    return await store.run(_op)


async def update_run_status(
    *,
    store: AsyncStore,
    run_id: str,
    update: RunStatusUpdate,
) -> RunStatusRecord:
    """Update a run status row and return the updated record."""
    await ensure_store_schema(store.db_path)
    encoded_error = encode_json_object_optional(
        update.error_json,
        context="agenterm_runs.error_json",
        sort_keys=True,
        ensure_ascii=True,
    )
    encoded_trace_metadata = encode_json_object_optional(
        update.trace_metadata_json,
        context="agenterm_runs.trace_metadata_json",
        sort_keys=True,
        ensure_ascii=True,
    )
    encoded_run_error_ref = encode_json_object_optional(
        update.run_error_summary_ref,
        context="agenterm_runs.run_error_summary_ref",
        sort_keys=True,
        ensure_ascii=True,
    )

    async def _op(conn: aiosqlite.Connection) -> RunStatusRecord:
        existing = await _get_run_by_id(conn, run_id)
        if existing is None:
            msg = "Failed to read current run record"
            raise DatabaseError(msg)
        if existing.status == "cancelled" and update.status != "cancelled":
            return existing
        await conn.execute(
            """
            UPDATE agenterm_runs
            SET status = ?,
                trace_id = ?,
                group_id = ?,
                trace_metadata_json = ?,
                trace_link_type = ?,
                response_id = ?,
                error_json = ?,
                error_artifact_id = ?,
                run_error_summary_ref = ?,
                branch_turn_start = ?,
                branch_turn_end = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE run_id = ?
            """,
            (
                str(update.status),
                update.trace_id,
                update.group_id,
                encoded_trace_metadata,
                str(update.trace_link_type),
                update.response_id,
                encoded_error,
                update.error_artifact_id,
                encoded_run_error_ref,
                update.branch_turn_start,
                update.branch_turn_end,
                str(run_id),
            ),
        )
        await conn.commit()
        record = await _get_run_by_id(conn, run_id)
        if record is None:
            msg = "Failed to read back updated run record"
            raise DatabaseError(msg)
        return record

    return await store.run(_op)


async def update_run_recovery(
    *,
    store: AsyncStore,
    run_id: str,
    recovery_state: RunRecoveryState,
    recovery_spool_path: str | None,
) -> RunStatusRecord:
    """Update run recovery metadata and return the updated record."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> RunStatusRecord:
        await conn.execute(
            """
            UPDATE agenterm_runs
            SET recovery_state = ?,
                recovery_spool_path = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE run_id = ?
            """,
            (
                str(recovery_state),
                recovery_spool_path,
                str(run_id),
            ),
        )
        await conn.commit()
        record = await _get_run_by_id(conn, run_id)
        if record is None:
            msg = "Failed to read back updated run record"
            raise DatabaseError(msg)
        return record

    return await store.run(_op)


__all__ = (
    "get_run_by_number",
    "insert_run_start",
    "list_runs",
    "next_run_number",
    "update_run_recovery",
    "update_run_status",
)
