"""Row mapping helpers for branch metadata records."""

from __future__ import annotations

from agenterm.core.errors import DatabaseError
from agenterm.store.branch.models import BranchKind, BranchMeta

_BRANCH_KINDS: tuple[BranchKind, ...] = (
    "main",
    "fork",
    "agent",
    "compaction",
    "snapshot",
)


def _parse_branch_kind(value: str | None, source: str) -> BranchKind:
    if value in _BRANCH_KINDS:
        return value
    msg = f"{source} expected one of {_BRANCH_KINDS}, got {value!r}"
    raise DatabaseError(msg)


def row_to_branch_meta(
    row: tuple[str | int | float | bytes | None, ...],
) -> BranchMeta:
    """Convert a SQLite row into BranchMeta."""
    (
        session_id,
        branch_id,
        kind,
        title,
        pinned,
        created_reason,
        parent_branch_id,
        fork_run_number,
        agent_name,
        agent_path,
        agent_sha256,
        store_enabled,
        last_response_id,
        created_at,
        updated_at,
    ) = row
    if not isinstance(pinned, int):
        msg = "agenterm_branch_meta.pinned expected int 0/1"
        raise DatabaseError(msg)
    if not isinstance(store_enabled, int):
        msg = "agenterm_branch_meta.store_enabled expected int 0/1"
        raise DatabaseError(msg)
    kind_value = _parse_branch_kind(
        str(kind) if kind is not None else None,
        "agenterm_branch_meta.kind",
    )
    fork_run_value: int | None
    if fork_run_number is None:
        fork_run_value = None
    else:
        try:
            fork_run_value = int(fork_run_number)
        except (TypeError, ValueError) as exc:
            msg = "agenterm_branch_meta.fork_run_number is not numeric"
            raise DatabaseError(msg) from exc
    return BranchMeta(
        session_id=str(session_id),
        branch_id=str(branch_id),
        kind=kind_value,
        title=str(title) if title is not None else None,
        pinned=bool(pinned),
        created_reason=str(created_reason) if created_reason is not None else None,
        parent_branch_id=(
            str(parent_branch_id) if parent_branch_id is not None else None
        ),
        fork_run_number=fork_run_value,
        agent_name=str(agent_name),
        agent_path=str(agent_path) if agent_path is not None else None,
        agent_sha256=str(agent_sha256) if agent_sha256 is not None else None,
        store_enabled=bool(store_enabled),
        last_response_id=str(last_response_id) if last_response_id else None,
        created_at=str(created_at) if created_at is not None else None,
        updated_at=str(updated_at) if updated_at is not None else None,
    )


__all__ = ("row_to_branch_meta",)
