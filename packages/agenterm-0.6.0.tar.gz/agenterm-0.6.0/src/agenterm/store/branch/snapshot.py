"""Branch creation helpers for compression continuation branches."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.response_items import serialize_input_item
from agenterm.store.branch.helpers import (
    default_branch_id,
    normalize_branch_id,
    require_branch_meta,
)
from agenterm.store.branch.repo import (
    BranchMetaUpsert,
    get_branch_meta,
    upsert_branch_meta,
)
from agenterm.store.branch.structure import clear_branch_structure
from agenterm.store.session.repo import update_session_head
from agenterm.store.session.request_usage import (
    RequestUsageRecord,
    insert_request_usage,
    next_request_index,
)

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from agents.items import TResponseInputItem

    from agenterm.core.json_types import JSONValue
    from agenterm.core.token_usage import TokenUsage
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.branch.models import BranchMeta
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession


def _pending_protocol_tail(
    items: Sequence[TResponseInputItem],
) -> list[TResponseInputItem]:
    """Return tail starting from earliest unresolved function_call, if any."""
    pending_call_starts: dict[str, int] = {}
    for index, item in enumerate(items):
        serialized = serialize_input_item(item, context="branch.snapshot.pending_tail")
        item_type = serialized.get("type")
        if item_type == "function_call":
            call_id = serialized.get("call_id")
            if isinstance(call_id, str) and call_id:
                pending_call_starts.setdefault(call_id, index)
            continue
        if item_type == "function_call_output":
            call_id = serialized.get("call_id")
            if isinstance(call_id, str) and call_id:
                pending_call_starts.pop(call_id, None)
    if not pending_call_starts:
        return []
    tail_start = min(pending_call_starts.values())
    return list(items[tail_start:])


def _serialize_items(
    items: Sequence[TResponseInputItem],
    *,
    context: str,
) -> list[dict[str, JSONValue]]:
    return [serialize_input_item(item, context=context) for item in items]


def _contains_sequence(
    *,
    haystack: Sequence[dict[str, JSONValue]],
    needle: Sequence[dict[str, JSONValue]],
) -> bool:
    if not needle:
        return True
    if len(needle) > len(haystack):
        return False
    window = len(needle)
    for start in range(len(haystack) - window + 1):
        if list(haystack[start : start + window]) == list(needle):
            return True
    return False


def _seed_with_pending_tail(
    *,
    seed_items: Sequence[TResponseInputItem],
    source_items: Sequence[TResponseInputItem],
) -> list[TResponseInputItem]:
    """Append pending protocol tail unless the seed already contains it."""
    tail = _pending_protocol_tail(source_items)
    if not tail:
        return list(seed_items)
    seed_serialized = _serialize_items(seed_items, context="branch.snapshot.seed")
    tail_serialized = _serialize_items(tail, context="branch.snapshot.tail")
    if _contains_sequence(haystack=seed_serialized, needle=tail_serialized):
        return list(seed_items)
    return [*seed_items, *tail]


async def create_compaction_branch(
    *,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    history_store: AsyncStore,
    session_id: str,
    snapshot_items: Sequence[TResponseInputItem],
    compaction_response_id: str,
    compaction_usage: TokenUsage | None,
    model: str,
    agent_name: str,
    agent_path: Path | None,
    agent_sha256: str | None,
    created_reason: str,
    branch_id: str | None,
    run_number: int | None,
    usage_branch_id: str | None,
) -> BranchMeta:
    """Create a compaction branch seeded from compaction continuation items.

    Request-usage rows are attributed to usage_branch_id when provided.
    """
    parent_branch_id = session.current_branch_id
    parent_meta = await require_branch_meta(
        store=store,
        session_id=session_id,
        branch_id=parent_branch_id,
    )
    parent_items = await session.get_items(branch_id=parent_branch_id)
    seeded_items = _seed_with_pending_tail(
        seed_items=snapshot_items,
        source_items=parent_items,
    )
    cleaned = normalize_branch_id(branch_id)
    new_branch_id = cleaned or default_branch_id("compaction")
    try:
        await session.create_branch_from_head(new_branch_id)
    except ValueError as exc:
        msg = str(exc)
        raise ConfigError(msg) from exc

    await clear_branch_structure(
        store=history_store,
        session_id=session_id,
        branch_id=new_branch_id,
    )
    await session.add_items(seeded_items)

    payload = BranchMetaUpsert(
        session_id=session_id,
        branch_id=new_branch_id,
        kind="compaction",
        title=None,
        pinned=False,
        created_reason=created_reason,
        parent_branch_id=parent_branch_id,
        fork_run_number=None,
        agent_name=agent_name,
        agent_path=agent_path,
        agent_sha256=agent_sha256,
        store_enabled=parent_meta.store_enabled,
        last_response_id=(
            compaction_response_id if parent_meta.store_enabled else None
        ),
    )
    await upsert_branch_meta(store=store, payload=payload)

    if compaction_usage is not None and run_number is not None:
        usage_branch = usage_branch_id or new_branch_id
        request_index = await next_request_index(
            store=store,
            session_id=session_id,
            branch_id=usage_branch,
            kind="compaction",
            run_number=run_number,
        )
        await insert_request_usage(
            store=store,
            records=[
                RequestUsageRecord(
                    session_id=session_id,
                    branch_id=usage_branch,
                    kind="compaction",
                    run_number=run_number,
                    request_index=request_index,
                    model=model,
                    response_id=compaction_response_id,
                    usage=compaction_usage,
                ),
            ],
        )

    await update_session_head(
        store=store,
        session_id=session_id,
        head_branch_id=new_branch_id,
    )
    meta = await get_branch_meta(store, session_id, new_branch_id)
    if meta is None:
        msg = f"Failed to read back branch metadata for {new_branch_id}"
        raise ConfigError(msg)
    return meta


async def create_snapshot_branch(
    *,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    history_store: AsyncStore,
    session_id: str,
    snapshot_items: Sequence[TResponseInputItem],
    response_id: str | None,
    usage: TokenUsage | None,
    model: str,
    agent_name: str,
    agent_path: Path | None,
    agent_sha256: str | None,
    created_reason: str,
    branch_id: str | None,
    run_number: int | None,
    usage_branch_id: str | None,
) -> BranchMeta:
    """Create a snapshot branch seeded from compression continuation items.

    Request-usage rows are attributed to usage_branch_id when provided.
    """
    parent_branch_id = session.current_branch_id
    parent_meta = await require_branch_meta(
        store=store,
        session_id=session_id,
        branch_id=parent_branch_id,
    )
    parent_items = await session.get_items(branch_id=parent_branch_id)
    seeded_items = _seed_with_pending_tail(
        seed_items=snapshot_items,
        source_items=parent_items,
    )
    cleaned = normalize_branch_id(branch_id)
    new_branch_id = cleaned or default_branch_id("snapshot")
    try:
        await session.create_branch_from_head(new_branch_id)
    except ValueError as exc:
        msg = str(exc)
        raise ConfigError(msg) from exc

    await clear_branch_structure(
        store=history_store,
        session_id=session_id,
        branch_id=new_branch_id,
    )
    await session.add_items(seeded_items)

    payload = BranchMetaUpsert(
        session_id=session_id,
        branch_id=new_branch_id,
        kind="snapshot",
        title=None,
        pinned=False,
        created_reason=created_reason,
        parent_branch_id=parent_branch_id,
        fork_run_number=None,
        agent_name=agent_name,
        agent_path=agent_path,
        agent_sha256=agent_sha256,
        store_enabled=parent_meta.store_enabled,
        last_response_id=response_id if parent_meta.store_enabled else None,
    )
    await upsert_branch_meta(store=store, payload=payload)

    if usage is not None and run_number is not None:
        usage_branch = usage_branch_id or new_branch_id
        request_index = await next_request_index(
            store=store,
            session_id=session_id,
            branch_id=usage_branch,
            kind="steward",
            run_number=run_number,
        )
        await insert_request_usage(
            store=store,
            records=[
                RequestUsageRecord(
                    session_id=session_id,
                    branch_id=usage_branch,
                    kind="steward",
                    run_number=run_number,
                    request_index=request_index,
                    model=model,
                    response_id=response_id,
                    usage=usage,
                ),
            ],
        )

    await update_session_head(
        store=store,
        session_id=session_id,
        head_branch_id=new_branch_id,
    )
    meta = await get_branch_meta(store, session_id, new_branch_id)
    if meta is None:
        msg = f"Failed to read back branch metadata for {new_branch_id}"
        raise ConfigError(msg)
    return meta


__all__ = ("create_compaction_branch", "create_snapshot_branch")
