"""Metadata repository for branches (async)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.store.branch.schema import row_to_branch_meta
from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    from pathlib import Path

    import aiosqlite

    from agenterm.store.async_db import AsyncStore
    from agenterm.store.branch.models import BranchKind, BranchMeta


@dataclass(frozen=True)
class BranchMetaUpsert:
    """Input payload for inserting/updating a branch metadata row."""

    session_id: str
    branch_id: str
    kind: BranchKind
    title: str | None
    pinned: bool
    created_reason: str | None
    parent_branch_id: str | None
    fork_run_number: int | None
    agent_name: str
    agent_path: Path | None
    agent_sha256: str | None
    store_enabled: bool
    last_response_id: str | None


async def list_branch_meta(
    store: AsyncStore,
    session_id: str,
) -> list[BranchMeta]:
    """Return all branch metadata rows for a session, newest first."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        cur = await conn.execute(
            """
            SELECT session_id,
                   branch_id,
                   kind,
                   title,
                   pinned,
                   created_reason,
                   parent_branch_id,
                   fork_run_number,
                   agent_name,
                   agent_path,
                   agent_sha256,
                   store_enabled,
                   last_response_id,
                   created_at,
                   updated_at
            FROM agenterm_branch_meta
            WHERE session_id = ?
            ORDER BY updated_at DESC
            """,
            (session_id,),
        )
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return [row_to_branch_meta(tuple(r)) for r in rows]


async def get_branch_meta(
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> BranchMeta | None:
    """Return a single branch metadata row when it exists."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str | int | float | bytes | None, ...] | None:
        cur = await conn.execute(
            """
            SELECT session_id,
                   branch_id,
                   kind,
                   title,
                   pinned,
                   created_reason,
                   parent_branch_id,
                   fork_run_number,
                   agent_name,
                   agent_path,
                   agent_sha256,
                   store_enabled,
                   last_response_id,
                   created_at,
                   updated_at
            FROM agenterm_branch_meta
            WHERE session_id = ? AND branch_id = ?
            """,
            (session_id, branch_id),
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    return row_to_branch_meta(tuple(row))


async def _upsert_branch_meta(
    *,
    store: AsyncStore,
    payload: BranchMetaUpsert,
) -> None:
    """Insert or update metadata for a branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            INSERT INTO agenterm_branch_meta (
                session_id,
                branch_id,
                kind,
                title,
                pinned,
                created_reason,
                parent_branch_id,
                fork_run_number,
                agent_name,
                agent_path,
                agent_sha256,
                store_enabled,
                last_response_id
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(session_id, branch_id) DO UPDATE SET
                kind=excluded.kind,
                title=excluded.title,
                pinned=excluded.pinned,
                created_reason=excluded.created_reason,
                parent_branch_id=excluded.parent_branch_id,
                fork_run_number=excluded.fork_run_number,
                agent_name=excluded.agent_name,
                agent_path=excluded.agent_path,
                agent_sha256=excluded.agent_sha256,
                store_enabled=excluded.store_enabled,
                last_response_id=excluded.last_response_id,
                updated_at=CURRENT_TIMESTAMP
            """,
            (
                payload.session_id,
                payload.branch_id,
                payload.kind,
                payload.title,
                1 if payload.pinned else 0,
                payload.created_reason,
                payload.parent_branch_id,
                payload.fork_run_number,
                payload.agent_name,
                str(payload.agent_path) if payload.agent_path is not None else None,
                payload.agent_sha256,
                1 if payload.store_enabled else 0,
                payload.last_response_id,
            ),
        )
        await conn.commit()

    await store.run(_op)


async def upsert_branch_meta(
    *,
    store: AsyncStore,
    payload: BranchMetaUpsert,
) -> None:
    """Public wrapper around branch metadata upsert."""
    await _upsert_branch_meta(store=store, payload=payload)


async def update_branch_store(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    store_enabled: bool,
    last_response_id: str | None,
) -> None:
    """Persist provider storage settings for a branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            UPDATE agenterm_branch_meta
            SET store_enabled = ?,
                last_response_id = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ? AND branch_id = ?
            """,
            (
                1 if store_enabled else 0,
                last_response_id,
                session_id,
                branch_id,
            ),
        )
        await conn.commit()

    await store.run(_op)


async def update_branch_agent(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    agent_name: str,
    agent_path: Path | None,
    agent_sha256: str | None,
) -> None:
    """Persist agent identity for a branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            UPDATE agenterm_branch_meta
            SET agent_name = ?,
                agent_path = ?,
                agent_sha256 = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ? AND branch_id = ?
            """,
            (
                agent_name,
                str(agent_path) if agent_path is not None else None,
                agent_sha256,
                session_id,
                branch_id,
            ),
        )
        await conn.commit()

    await store.run(_op)


async def delete_branch_meta(
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> bool:
    """Delete a branch metadata row."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> bool:
        cur = await conn.execute(
            """
            DELETE FROM agenterm_branch_meta
            WHERE session_id = ? AND branch_id = ?
            """,
            (session_id, branch_id),
        )
        await conn.commit()
        return cur.rowcount > 0

    return await store.run(_op)


__all__ = (
    "BranchMetaUpsert",
    "delete_branch_meta",
    "get_branch_meta",
    "list_branch_meta",
    "update_branch_agent",
    "update_branch_store",
    "upsert_branch_meta",
)
