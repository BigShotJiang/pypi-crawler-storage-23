"""Helpers for branch-scoped request usage ledgers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.store.async_db import AsyncStore


async def copy_request_usage(
    *,
    store: AsyncStore,
    session_id: str,
    source_branch_id: str,
    dest_branch_id: str,
    before_run: int | None,
) -> None:
    """Copy request usage rows into a new branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        if before_run is None:
            query = """
                INSERT INTO agenterm_request_usage (
                    session_id,
                    branch_id,
                    kind,
                    run_number,
                    request_index,
                    model,
                    response_id,
                    requests,
                    input_tokens,
                    input_cached_tokens,
                    output_tokens,
                    output_reasoning_tokens,
                    total_tokens,
                    created_at
                )
                SELECT
                    session_id,
                    ?,
                    kind,
                    run_number,
                    request_index,
                    model,
                    response_id,
                    requests,
                    input_tokens,
                    input_cached_tokens,
                    output_tokens,
                    output_reasoning_tokens,
                    total_tokens,
                    created_at
                FROM agenterm_request_usage
                WHERE session_id = ? AND branch_id = ?
            """
            params = (
                str(dest_branch_id),
                str(session_id),
                str(source_branch_id),
            )
        else:
            query = """
                INSERT INTO agenterm_request_usage (
                    session_id,
                    branch_id,
                    kind,
                    run_number,
                    request_index,
                    model,
                    response_id,
                    requests,
                    input_tokens,
                    input_cached_tokens,
                    output_tokens,
                    output_reasoning_tokens,
                    total_tokens,
                    created_at
                )
                SELECT
                    session_id,
                    ?,
                    kind,
                    run_number,
                    request_index,
                    model,
                    response_id,
                    requests,
                    input_tokens,
                    input_cached_tokens,
                    output_tokens,
                    output_reasoning_tokens,
                    total_tokens,
                    created_at
                FROM agenterm_request_usage
                WHERE session_id = ? AND branch_id = ? AND run_number < ?
            """
            params = (
                str(dest_branch_id),
                str(session_id),
                str(source_branch_id),
                int(before_run),
            )
        await conn.execute(query, params)
        await conn.commit()

    await store.run(_op)


async def last_response_id_for_run(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
) -> str | None:
    """Return the last response id for a given run."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> str | None:
        cur = await conn.execute(
            """
            SELECT response_id
            FROM agenterm_request_usage
            WHERE session_id = ? AND branch_id = ?
            AND kind = 'response' AND run_number = ?
            ORDER BY request_index DESC
            LIMIT 1
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        row = await cur.fetchone()
        if row is None:
            return None
        value = row[0]
        return str(value) if isinstance(value, str) and value else None

    return await store.run(_op)


__all__ = ("copy_request_usage", "last_response_id_for_run")
