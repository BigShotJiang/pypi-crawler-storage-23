"""Helpers for AdvancedSQLiteSession branch structure tables."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import DatabaseError
from agenterm.store.history import ensure_history_tables

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.store.async_db import AsyncStore


async def branch_row_count(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> int:
    """Return the message_structure row count for a branch."""

    async def _op(conn: aiosqlite.Connection) -> int:
        await ensure_history_tables(conn, tables=("message_structure",))
        cur = await conn.execute(
            """
            SELECT COUNT(*)
            FROM message_structure
            WHERE session_id = ? AND branch_id = ?
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        if row is None:
            return 0
        try:
            return int(row[0] or 0)
        except (TypeError, ValueError) as exc:
            msg = "message_structure row count is not numeric"
            raise DatabaseError(msg) from exc

    return await store.run(_op)


async def clear_branch_structure(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> None:
    """Delete branch structure rows from Agents tables."""

    async def _op(conn: aiosqlite.Connection) -> None:
        await ensure_history_tables(conn, tables=("message_structure", "turn_usage"))
        await conn.execute(
            """
            DELETE FROM turn_usage
            WHERE session_id = ? AND branch_id = ?
            """,
            (str(session_id), str(branch_id)),
        )
        await conn.execute(
            """
            DELETE FROM message_structure
            WHERE session_id = ? AND branch_id = ?
            """,
            (str(session_id), str(branch_id)),
        )
        await conn.commit()

    await store.run(_op)


__all__ = ("branch_row_count", "clear_branch_structure")
