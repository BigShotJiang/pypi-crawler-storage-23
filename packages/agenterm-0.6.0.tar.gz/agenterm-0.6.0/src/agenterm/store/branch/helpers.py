"""Shared helpers for branch lifecycle operations."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.store.branch.repo import get_branch_meta

if TYPE_CHECKING:
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.branch.models import BranchMeta


def default_branch_id(prefix: str) -> str:
    """Return a timestamped branch id for the given prefix."""
    ts = int(time.time())
    return f"{prefix}_{ts}"


def normalize_branch_id(value: str | None) -> str | None:
    """Normalize a branch id or raise when blank."""
    if value is None:
        return None
    cleaned = value.strip()
    if not cleaned:
        msg = "branch_id cannot be empty"
        raise ConfigError(msg)
    return cleaned


async def require_branch_meta(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> BranchMeta:
    """Return branch metadata or raise if it does not exist."""
    meta = await get_branch_meta(store, session_id, branch_id)
    if meta is None:
        msg = f"Unknown branch_id: {branch_id!r} for session {session_id!r}"
        raise ConfigError(msg)
    return meta


__all__ = ("default_branch_id", "normalize_branch_id", "require_branch_meta")
