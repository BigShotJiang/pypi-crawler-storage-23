"""Branch metadata models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

type BranchKind = Literal["main", "fork", "agent", "compaction", "snapshot"]


@dataclass(frozen=True)
class BranchMeta:
    """Metadata row for a branch managed by agenterm."""

    session_id: str
    branch_id: str
    kind: BranchKind
    title: str | None
    pinned: bool
    created_reason: str | None
    parent_branch_id: str | None
    fork_run_number: int | None
    agent_name: str
    agent_path: str | None
    agent_sha256: str | None
    store_enabled: bool
    last_response_id: str | None
    created_at: str | None
    updated_at: str | None


__all__ = ("BranchKind", "BranchMeta")
