"""Branch lifecycle helpers for agenterm-owned metadata."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.store.branch.helpers import (
    default_branch_id,
    normalize_branch_id,
    require_branch_meta,
)
from agenterm.store.branch.ledger import copy_request_usage, last_response_id_for_run
from agenterm.store.branch.repo import (
    BranchMetaUpsert,
    delete_branch_meta,
    get_branch_meta,
    update_branch_agent,
    upsert_branch_meta,
)
from agenterm.store.branch.snapshot import (
    create_compaction_branch,
    create_snapshot_branch,
)
from agenterm.store.branch.structure import branch_row_count
from agenterm.store.history import history_store
from agenterm.store.runs.repo import get_run_by_number
from agenterm.store.session.repo import update_session_head

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.store.async_db import AsyncStore
    from agenterm.store.branch.models import BranchKind, BranchMeta
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession


@dataclass(frozen=True)
class BranchCreation:
    """Result of creating or reusing a branch."""

    branch_id: str
    branch_meta: BranchMeta
    created: bool


async def create_branch_from_head(
    *,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str | None,
    kind: BranchKind,
    created_reason: str | None,
    agent_name: str,
    agent_path: Path | None,
    agent_sha256: str | None,
) -> BranchMeta:
    """Create a new branch by copying the current branch head."""
    parent_branch_id = session.current_branch_id
    parent_meta = await require_branch_meta(
        store=store,
        session_id=session_id,
        branch_id=parent_branch_id,
    )
    cleaned = normalize_branch_id(branch_id)
    new_branch_id = cleaned or default_branch_id("branch_from_head")

    try:
        await session.create_branch_from_head(new_branch_id)
    except ValueError as exc:
        msg = str(exc)
        raise ConfigError(msg) from exc

    payload = BranchMetaUpsert(
        session_id=session_id,
        branch_id=new_branch_id,
        kind=kind,
        title=None,
        pinned=False,
        created_reason=created_reason,
        parent_branch_id=parent_branch_id,
        fork_run_number=None,
        agent_name=agent_name,
        agent_path=agent_path,
        agent_sha256=agent_sha256,
        store_enabled=parent_meta.store_enabled,
        last_response_id=(
            parent_meta.last_response_id if parent_meta.store_enabled else None
        ),
    )
    await upsert_branch_meta(store=store, payload=payload)
    await copy_request_usage(
        store=store,
        session_id=session_id,
        source_branch_id=parent_branch_id,
        dest_branch_id=new_branch_id,
        before_run=None,
    )
    await update_session_head(
        store=store,
        session_id=session_id,
        head_branch_id=new_branch_id,
    )
    meta = await get_branch_meta(store, session_id, new_branch_id)
    if meta is None:
        msg = f"Failed to read back branch metadata for {new_branch_id}"
        raise ConfigError(msg)
    return meta


async def create_agent_branch(
    *,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str | None,
    agent_name: str,
    agent_path: Path | None,
    agent_sha256: str | None,
) -> BranchCreation:
    """Create a branch for agent changes, or update in place when no history."""
    parent_branch_id = session.current_branch_id
    if (
        await branch_row_count(
            store=history_store(),
            session_id=session_id,
            branch_id=parent_branch_id,
        )
        == 0
    ):
        await update_branch_agent(
            store=store,
            session_id=session_id,
            branch_id=parent_branch_id,
            agent_name=agent_name,
            agent_path=agent_path,
            agent_sha256=agent_sha256,
        )
        meta = await require_branch_meta(
            store=store,
            session_id=session_id,
            branch_id=parent_branch_id,
        )
        return BranchCreation(
            branch_id=parent_branch_id,
            branch_meta=meta,
            created=False,
        )
    new_branch = await create_branch_from_head(
        session=session,
        store=store,
        session_id=session_id,
        branch_id=branch_id or default_branch_id("agent"),
        kind="agent",
        created_reason="agent_switch",
        agent_name=agent_name,
        agent_path=agent_path,
        agent_sha256=agent_sha256,
    )
    return BranchCreation(
        branch_id=new_branch.branch_id,
        branch_meta=new_branch,
        created=True,
    )


async def create_branch_from_run(
    *,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    run_number: int,
    branch_id: str | None,
    agent_name: str,
    agent_path: Path | None,
    agent_sha256: str | None,
) -> BranchMeta:
    """Create a branch from a specific run (exclusive)."""
    parent_branch_id = session.current_branch_id
    parent_meta = await require_branch_meta(
        store=store,
        session_id=session_id,
        branch_id=parent_branch_id,
    )
    cleaned = normalize_branch_id(branch_id)
    if run_number <= 0:
        msg = "run_number must be >= 1"
        raise ConfigError(msg)
    run_record = await get_run_by_number(
        store=store,
        session_id=session_id,
        branch_id=parent_branch_id,
        run_number=run_number,
    )
    if run_record is None:
        msg = f"Run {run_number} not found for branch {parent_branch_id}"
        raise ConfigError(msg)
    if run_record.branch_turn_start is None:
        msg = f"Run {run_number} has no branch turn range; cannot fork"
        raise ConfigError(msg)
    try:
        new_branch_id = await session.create_branch_from_turn(
            int(run_record.branch_turn_start),
            cleaned,
        )
    except ValueError as exc:
        msg = str(exc)
        raise ConfigError(msg) from exc

    last_response_id: str | None = None
    if parent_meta.store_enabled:
        last_response_id = await last_response_id_for_run(
            store=store,
            session_id=session_id,
            branch_id=parent_branch_id,
            run_number=max(0, int(run_number) - 1),
        )
    payload = BranchMetaUpsert(
        session_id=session_id,
        branch_id=new_branch_id,
        kind="fork",
        title=None,
        pinned=False,
        created_reason="user_fork",
        parent_branch_id=parent_branch_id,
        fork_run_number=int(run_number),
        agent_name=agent_name,
        agent_path=agent_path,
        agent_sha256=agent_sha256,
        store_enabled=parent_meta.store_enabled,
        last_response_id=last_response_id if parent_meta.store_enabled else None,
    )
    await upsert_branch_meta(store=store, payload=payload)
    await copy_request_usage(
        store=store,
        session_id=session_id,
        source_branch_id=parent_branch_id,
        dest_branch_id=new_branch_id,
        before_run=int(run_number),
    )
    await update_session_head(
        store=store,
        session_id=session_id,
        head_branch_id=new_branch_id,
    )
    meta = await get_branch_meta(store, session_id, new_branch_id)
    if meta is None:
        msg = f"Failed to read back branch metadata for {new_branch_id}"
        raise ConfigError(msg)
    return meta


async def switch_branch(
    *,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> BranchMeta:
    """Switch to a branch and update head metadata."""
    cleaned = normalize_branch_id(branch_id)
    if cleaned is None:
        msg = "branch_id cannot be empty"
        raise ConfigError(msg)
    try:
        await session.switch_to_branch(cleaned)
    except ValueError as exc:
        msg = str(exc)
        raise ConfigError(msg) from exc
    await update_session_head(
        store=store,
        session_id=session_id,
        head_branch_id=cleaned,
    )
    return await require_branch_meta(
        store=store,
        session_id=session_id,
        branch_id=cleaned,
    )


async def delete_branch(
    *,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    force: bool,
) -> bool:
    """Delete a branch and its metadata."""
    cleaned = normalize_branch_id(branch_id)
    if cleaned is None:
        msg = "branch_id cannot be empty"
        raise ConfigError(msg)
    try:
        await session.delete_branch(cleaned, force=force)
    except ValueError as exc:
        msg = str(exc)
        raise ConfigError(msg) from exc
    deleted = await delete_branch_meta(store, session_id, cleaned)
    await update_session_head(
        store=store,
        session_id=session_id,
        head_branch_id=session.current_branch_id,
    )
    return deleted


__all__ = (
    "BranchCreation",
    "create_agent_branch",
    "create_branch_from_head",
    "create_branch_from_run",
    "create_compaction_branch",
    "create_snapshot_branch",
    "delete_branch",
    "switch_branch",
)
