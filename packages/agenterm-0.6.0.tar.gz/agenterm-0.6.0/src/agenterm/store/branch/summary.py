"""Typed helpers for branch listings returned by the Agents SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.json_codec import (
    require_bool,
    require_int,
    require_optional_str,
    require_str,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class BranchSummary:
    """Typed view of a branch listing entry."""

    branch_id: str
    message_count: int
    user_turns: int
    is_current: bool
    created_at: str | None


def parse_branch_summary(raw: Mapping[str, JSONValue]) -> BranchSummary:
    """Validate a JSON mapping into a BranchSummary."""
    branch_id = require_str(raw.get("branch_id"), context="branch_summary.branch_id")
    message_count = require_int(
        raw.get("message_count"),
        context="branch_summary.message_count",
    )
    user_turns = require_int(raw.get("user_turns"), context="branch_summary.user_turns")
    is_current = require_bool(
        raw.get("is_current"),
        context="branch_summary.is_current",
    )
    created_at = require_optional_str(
        raw.get("created_at"),
        context="branch_summary.created_at",
    )
    return BranchSummary(
        branch_id=branch_id,
        message_count=message_count,
        user_turns=user_turns,
        is_current=is_current,
        created_at=created_at,
    )


__all__ = ("BranchSummary", "parse_branch_summary")
