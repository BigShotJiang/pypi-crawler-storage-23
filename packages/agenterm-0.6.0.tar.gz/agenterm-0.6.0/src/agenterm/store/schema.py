"""Store schema versioning and validation for agenterm-owned SQLite tables."""

from __future__ import annotations

import sqlite3
from typing import TYPE_CHECKING, Final

from agenterm.core.errors import ConfigError
from agenterm.store.async_db import AsyncStore
from agenterm.store.schema_specs import TABLE_SPECS

if TYPE_CHECKING:
    from pathlib import Path

    import aiosqlite

    from agenterm.store.schema_spec_types import TableSpec

_STORE_SCHEMA_VERSION: Final[int] = 15

_SCHEMA_TABLE_SQL: Final[str] = """
CREATE TABLE IF NOT EXISTS agenterm_schema (
    schema_version INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
"""


async def _read_schema_version(conn: aiosqlite.Connection) -> int | None:
    try:
        async with conn.execute(
            "SELECT schema_version FROM agenterm_schema LIMIT 1",
        ) as cur:
            row = await cur.fetchone()
    except sqlite3.Error:
        return None
    if row is None:
        return None
    version = row[0]
    return int(version) if isinstance(version, int) else None


async def _write_schema_version(conn: aiosqlite.Connection, version: int) -> None:
    await conn.execute(_SCHEMA_TABLE_SQL)
    await conn.execute("DELETE FROM agenterm_schema")
    await conn.execute(
        "INSERT INTO agenterm_schema (schema_version) VALUES (?)",
        (int(version),),
    )


async def _table_columns(
    conn: aiosqlite.Connection,
    *,
    table: str,
) -> tuple[set[str], set[str]]:
    async with conn.execute(
        'SELECT name, "notnull" FROM pragma_table_info(?)',
        (str(table),),
    ) as cur:
        rows = await cur.fetchall()
    cols = {str(row[0]) for row in rows}
    notnull = {str(row[0]) for row in rows if bool(row[1])}
    return cols, notnull


async def _validate_table_schema(
    conn: aiosqlite.Connection,
    spec: TableSpec,
) -> bool:
    cols, notnull = await _table_columns(conn, table=spec.name)
    expected = set(spec.expected_cols)
    if cols != expected:
        return False
    required_notnull = set(spec.notnull_cols)
    return required_notnull.issubset(notnull)


async def _init_store(conn: aiosqlite.Connection) -> None:
    await _write_schema_version(conn, _STORE_SCHEMA_VERSION)
    for spec in TABLE_SPECS:
        await conn.execute(spec.create_sql)
    for spec in TABLE_SPECS:
        if not await _validate_table_schema(conn, spec):
            msg = f"Failed to initialize store schema: {spec.name}"
            raise ConfigError(msg)
    await conn.commit()


async def _validate_store(conn: aiosqlite.Connection) -> bool:
    version = await _read_schema_version(conn)
    if version != _STORE_SCHEMA_VERSION:
        return False
    for spec in TABLE_SPECS:
        if not await _validate_table_schema(conn, spec):
            return False
    return True


async def ensure_store_schema(
    db_path: Path,
) -> None:
    """Ensure the agenterm-owned store schema exists and matches expectations.

    Raises ConfigError when the on-disk schema does not match the expected
    version so operators can delete the store explicitly.
    """
    store = AsyncStore(db_path)

    async def _ensure(conn: aiosqlite.Connection) -> None:
        version = await _read_schema_version(conn)
        if version == _STORE_SCHEMA_VERSION and await _validate_store(conn):
            return
        if version is None:
            await _init_store(conn)
            return
        msg = (
            "Store schema mismatch. Move aside the versioned store file and "
            f"retry: {db_path}"
        )
        raise ConfigError(msg)

    await store.run(_ensure)


__all__ = ("ensure_store_schema",)
