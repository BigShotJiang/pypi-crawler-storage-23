"""Supporting table specifications for agenterm meta store."""

from __future__ import annotations

from typing import Final

from agenterm.store.schema_spec_types import TableSpec

SUPPORT_TABLE_SPECS: Final[tuple[TableSpec, ...]] = (
    TableSpec(
        name="agenterm_artifacts",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_artifacts (
            artifact_id TEXT NOT NULL PRIMARY KEY,
            kind TEXT NOT NULL,
            mime TEXT NOT NULL,
            path TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            content_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            source_type TEXT NOT NULL,
            source_id TEXT NOT NULL,
            session_id TEXT,
            UNIQUE(source_type, source_id)
        )
        """,
        expected_cols=(
            "artifact_id",
            "kind",
            "mime",
            "path",
            "size_bytes",
            "content_hash",
            "created_at",
            "source_type",
            "source_id",
            "session_id",
        ),
        notnull_cols=(
            "artifact_id",
            "kind",
            "mime",
            "path",
            "size_bytes",
            "content_hash",
            "source_type",
            "source_id",
        ),
    ),
    TableSpec(
        name="agenterm_approvals",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_approvals (
            approval_id TEXT NOT NULL PRIMARY KEY,
            session_id TEXT NOT NULL,
            branch_id TEXT NOT NULL,
            request_json TEXT NOT NULL,
            decision_json TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id, branch_id)
                REFERENCES agenterm_branch_meta(session_id, branch_id)
                ON DELETE CASCADE
        )
        """,
        expected_cols=(
            "approval_id",
            "session_id",
            "branch_id",
            "request_json",
            "decision_json",
            "created_at",
            "updated_at",
        ),
        notnull_cols=("approval_id", "session_id", "branch_id", "request_json"),
    ),
    TableSpec(
        name="agenterm_request_usage",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_request_usage (
            session_id TEXT NOT NULL,
            branch_id TEXT NOT NULL,
            kind TEXT NOT NULL CHECK (kind IN ('response', 'compaction', 'steward')),
            run_number INTEGER NOT NULL,
            request_index INTEGER NOT NULL,
            model TEXT NOT NULL,
            response_id TEXT,
            requests INTEGER NOT NULL,
            input_tokens INTEGER NOT NULL,
            input_cached_tokens INTEGER NOT NULL,
            output_tokens INTEGER NOT NULL,
            output_reasoning_tokens INTEGER NOT NULL,
            total_tokens INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (session_id, branch_id, kind, run_number, request_index),
            FOREIGN KEY (session_id, branch_id)
                REFERENCES agenterm_branch_meta(session_id, branch_id)
                ON DELETE CASCADE
        )
        """,
        expected_cols=(
            "session_id",
            "branch_id",
            "kind",
            "run_number",
            "request_index",
            "model",
            "response_id",
            "requests",
            "input_tokens",
            "input_cached_tokens",
            "output_tokens",
            "output_reasoning_tokens",
            "total_tokens",
            "created_at",
        ),
        notnull_cols=(
            "session_id",
            "branch_id",
            "kind",
            "run_number",
            "request_index",
            "model",
            "requests",
            "input_tokens",
            "input_cached_tokens",
            "output_tokens",
            "output_reasoning_tokens",
            "total_tokens",
        ),
    ),
    TableSpec(
        name="agenterm_steward_tasks",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_steward_tasks (
            task_id TEXT PRIMARY KEY NOT NULL,
            session_id TEXT NOT NULL,
            branch_id TEXT NOT NULL,
            snapshot_branch_id TEXT,
            kind TEXT NOT NULL CHECK (kind IN ('snapshot', 'compaction')),
            trigger TEXT NOT NULL CHECK (trigger IN ('auto', 'manual', 'tool')),
            status TEXT NOT NULL
                CHECK (
                    status IN ('queued', 'running', 'completed', 'failed', 'cancelled')
                ),
            model TEXT NOT NULL,
            input_json TEXT NOT NULL,
            trace_id TEXT,
            response_id TEXT,
            error_json TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            FOREIGN KEY (session_id, branch_id)
                REFERENCES agenterm_branch_meta(session_id, branch_id)
                ON DELETE CASCADE,
            FOREIGN KEY (session_id, snapshot_branch_id)
                REFERENCES agenterm_branch_meta(session_id, branch_id)
                ON DELETE CASCADE
        )
        """,
        expected_cols=(
            "task_id",
            "session_id",
            "branch_id",
            "snapshot_branch_id",
            "kind",
            "trigger",
            "status",
            "model",
            "input_json",
            "trace_id",
            "response_id",
            "error_json",
            "created_at",
            "started_at",
            "completed_at",
        ),
        notnull_cols=(
            "task_id",
            "session_id",
            "branch_id",
            "kind",
            "trigger",
            "status",
            "model",
            "input_json",
        ),
    ),
    TableSpec(
        name="agenterm_plan_snapshots",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_plan_snapshots (
            session_id TEXT NOT NULL,
            branch_id TEXT NOT NULL,
            revision INTEGER NOT NULL,
            steps_json TEXT NOT NULL,
            explanation TEXT,
            trace_id TEXT,
            tool_call_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (session_id, branch_id, revision),
            FOREIGN KEY (session_id, branch_id)
                REFERENCES agenterm_branch_meta(session_id, branch_id)
                ON DELETE CASCADE
        )
        """,
        expected_cols=(
            "session_id",
            "branch_id",
            "revision",
            "steps_json",
            "explanation",
            "trace_id",
            "tool_call_id",
            "created_at",
        ),
        notnull_cols=("session_id", "branch_id", "revision", "steps_json"),
    ),
    TableSpec(
        name="agenterm_model_registry",
        create_sql="""
        CREATE TABLE IF NOT EXISTS agenterm_model_registry (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            source TEXT NOT NULL,
            fetched_at INTEGER NOT NULL,
            models_json TEXT NOT NULL
        )
        """,
        expected_cols=(
            "id",
            "source",
            "fetched_at",
            "models_json",
        ),
        notnull_cols=("source", "fetched_at", "models_json"),
    ),
)


__all__ = ("SUPPORT_TABLE_SPECS",)
