"""SQLite repository for plan snapshots."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import DatabaseError
from agenterm.core.plan import (
    PlanSeries,
    PlanSnapshot,
    PlanStep,
    derive_plan_series,
    normalize_plan_timestamp,
    parse_plan_steps,
    plan_steps_payload,
)
from agenterm.store.codec import (
    decode_json_value,
    encode_json_value,
    optional_text,
    require_int,
    require_text,
)
from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    from collections.abc import Sequence

    import aiosqlite

    from agenterm.store.async_db import AsyncStore


def _encode_steps(steps: Sequence[PlanStep]) -> str:
    return encode_json_value(
        plan_steps_payload(steps),
        context="agenterm_plan_snapshots.steps_json",
        sort_keys=True,
        ensure_ascii=True,
    )


def _decode_steps(raw: str) -> tuple[PlanStep, ...]:
    parsed = decode_json_value(
        raw,
        context="agenterm_plan_snapshots.steps_json",
    )
    steps = parse_plan_steps(parsed)
    if steps is None:
        msg = "agenterm_plan_snapshots.steps_json does not match plan step schema"
        raise DatabaseError(msg)
    return steps


def _row_to_snapshot(
    row: tuple[str | int | float | bytes | None, ...],
) -> PlanSnapshot:
    (
        session_id,
        branch_id,
        revision,
        steps_json,
        explanation,
        trace_id,
        tool_call_id,
        created_at,
    ) = row
    session_id = require_text(
        session_id,
        field="agenterm_plan_snapshots.session_id",
    )
    branch_id = require_text(
        branch_id,
        field="agenterm_plan_snapshots.branch_id",
    )
    revision = require_int(revision, field="agenterm_plan_snapshots.revision")
    steps_json = require_text(
        steps_json,
        field="agenterm_plan_snapshots.steps_json",
    )
    steps = _decode_steps(steps_json)
    created_at_raw = optional_text(
        created_at,
        field="agenterm_plan_snapshots.created_at",
    )
    return PlanSnapshot(
        session_id=session_id,
        branch_id=branch_id,
        revision=int(revision),
        steps=steps,
        explanation=optional_text(
            explanation,
            field="agenterm_plan_snapshots.explanation",
        ),
        trace_id=optional_text(trace_id, field="agenterm_plan_snapshots.trace_id"),
        tool_call_id=optional_text(
            tool_call_id,
            field="agenterm_plan_snapshots.tool_call_id",
        ),
        created_at=normalize_plan_timestamp(created_at_raw),
    )


async def _next_revision(
    conn: aiosqlite.Connection,
    session_id: str,
    branch_id: str,
) -> int:
    cur = await conn.execute(
        """
        SELECT COALESCE(MAX(revision), 0) + 1
        FROM agenterm_plan_snapshots
        WHERE session_id = ? AND branch_id = ?
        """,
        (str(session_id), str(branch_id)),
    )
    row = await cur.fetchone()
    if row is None or not isinstance(row[0], int):
        msg = "Failed to compute next plan snapshot revision"
        raise DatabaseError(msg)
    return int(row[0])


async def insert_plan_snapshot(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    steps: Sequence[PlanStep],
    explanation: str | None,
    trace_id: str | None,
    tool_call_id: str | None,
) -> PlanSnapshot:
    """Insert a plan snapshot and return the persisted row."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> PlanSnapshot:
        revision = await _next_revision(conn, session_id, branch_id)
        steps_json = _encode_steps(steps)
        await conn.execute(
            """
            INSERT INTO agenterm_plan_snapshots (
                session_id,
                branch_id,
                revision,
                steps_json,
                explanation,
                trace_id,
                tool_call_id
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(session_id),
                str(branch_id),
                int(revision),
                steps_json,
                explanation,
                trace_id,
                tool_call_id,
            ),
        )
        await conn.commit()
        snapshot = await _get_plan_snapshot_by_revision(
            conn,
            session_id,
            branch_id,
            revision,
        )
        if snapshot is None:
            msg = "Failed to read back inserted plan snapshot"
            raise DatabaseError(msg)
        return snapshot

    return await store.run(_op)


async def _get_plan_snapshot_by_revision(
    conn: aiosqlite.Connection,
    session_id: str,
    branch_id: str,
    revision: int,
) -> PlanSnapshot | None:
    cur = await conn.execute(
        """
        SELECT
            session_id,
            branch_id,
            revision,
            steps_json,
            explanation,
            trace_id,
            tool_call_id,
            created_at
        FROM agenterm_plan_snapshots
        WHERE session_id = ? AND branch_id = ? AND revision = ?
        """,
        (str(session_id), str(branch_id), int(revision)),
    )
    row = await cur.fetchone()
    if row is None:
        return None
    return _row_to_snapshot(tuple(row))


async def get_latest_plan_snapshot(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> PlanSnapshot | None:
    """Return the latest plan snapshot for a session."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str | int | float | bytes | None, ...] | None:
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                revision,
                steps_json,
                explanation,
                trace_id,
                tool_call_id,
                created_at
            FROM agenterm_plan_snapshots
            WHERE session_id = ? AND branch_id = ?
            ORDER BY revision DESC
            LIMIT 1
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    return _row_to_snapshot(row)


async def get_plan_series(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> PlanSeries:
    """Return the resolved plan series for a session."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                revision,
                steps_json,
                explanation,
                trace_id,
                tool_call_id,
                created_at
            FROM agenterm_plan_snapshots
            WHERE session_id = ? AND branch_id = ?
            ORDER BY revision DESC
            """,
            (str(session_id), str(branch_id)),
        )
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    snapshots = [_row_to_snapshot(row) for row in rows]
    return derive_plan_series(snapshots)


async def get_plan_snapshot_by_call_id(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    tool_call_id: str,
) -> PlanSnapshot | None:
    """Return a plan snapshot associated with a tool call id."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str | int | float | bytes | None, ...] | None:
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                revision,
                steps_json,
                explanation,
                trace_id,
                tool_call_id,
                created_at
            FROM agenterm_plan_snapshots
            WHERE session_id = ? AND branch_id = ? AND tool_call_id = ?
            ORDER BY revision DESC
            LIMIT 1
            """,
            (str(session_id), str(branch_id), str(tool_call_id)),
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    return _row_to_snapshot(row)


async def delete_plan_snapshots(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> None:
    """Delete all plan snapshots for one session/branch."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            DELETE FROM agenterm_plan_snapshots
            WHERE session_id = ? AND branch_id = ?
            """,
            (str(session_id), str(branch_id)),
        )
        await conn.commit()

    await store.run(_op)


__all__ = (
    "delete_plan_snapshots",
    "get_latest_plan_snapshot",
    "get_plan_series",
    "get_plan_snapshot_by_call_id",
    "insert_plan_snapshot",
)
