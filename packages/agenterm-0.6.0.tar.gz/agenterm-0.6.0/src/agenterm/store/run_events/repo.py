"""SQLite repository for run event ledger entries."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.store.codec import (
    decode_json_object,
    encode_json_object,
    optional_text,
    require_int,
    require_text,
)
from agenterm.store.run_events.models import (
    RunEventEnvelope,
    RunEventInsert,
    RunEventRecord,
)
from agenterm.store.schema import ensure_store_schema

if TYPE_CHECKING:
    from collections.abc import Sequence

    import aiosqlite

    from agenterm.store.async_db import AsyncStore


def _row_to_record(
    row: tuple[str | int | float | bytes | None, ...],
) -> RunEventRecord:
    (
        session_id,
        branch_id,
        run_number,
        request_index,
        event_seq,
        event_type,
        response_id,
        model,
        event_json,
        created_at,
    ) = row
    session_id = require_text(session_id, field="agenterm_run_events.session_id")
    branch_id = require_text(branch_id, field="agenterm_run_events.branch_id")
    run_number_int = require_int(
        run_number,
        field="agenterm_run_events.run_number",
    )
    request_index_int = require_int(
        request_index,
        field="agenterm_run_events.request_index",
    )
    event_seq_int = require_int(event_seq, field="agenterm_run_events.event_seq")
    event_type = require_text(event_type, field="agenterm_run_events.event_type")
    model = require_text(model, field="agenterm_run_events.model")
    event_json_text = require_text(event_json, field="agenterm_run_events.event_json")
    return RunEventRecord(
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number_int,
        request_index=request_index_int,
        event_seq=event_seq_int,
        event_type=event_type,
        response_id=optional_text(
            response_id,
            field="agenterm_run_events.response_id",
        ),
        model=model,
        event=decode_json_object(
            event_json_text,
            context="agenterm_run_events.event_json",
        ),
        created_at=optional_text(
            created_at,
            field="agenterm_run_events.created_at",
        ),
    )


async def insert_run_event(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    request_index: int,
    event_seq: int,
    event_type: str,
    response_id: str | None,
    model: str,
    envelope: RunEventEnvelope,
) -> None:
    """Insert a run event entry."""
    await ensure_store_schema(store.db_path)
    event_json = encode_json_object(
        envelope.to_json(),
        context="agenterm_run_events.event_json",
        sort_keys=True,
        ensure_ascii=True,
    )

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            INSERT INTO agenterm_run_events (
                session_id,
                branch_id,
                run_number,
                request_index,
                event_seq,
                event_type,
                response_id,
                model,
                event_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(session_id),
                str(branch_id),
                int(run_number),
                int(request_index),
                int(event_seq),
                str(event_type),
                str(response_id) if response_id is not None else None,
                str(model),
                event_json,
            ),
        )
        await conn.commit()

    await store.run(_op)


async def insert_run_events_batch(
    *,
    store: AsyncStore,
    records: Sequence[RunEventInsert],
) -> None:
    """Insert a batch of run event entries in a single transaction."""
    if not records:
        return
    await ensure_store_schema(store.db_path)
    rows: list[tuple[str | int | None, ...]] = []
    for record in records:
        event_json = encode_json_object(
            record.envelope.to_json(),
            context="agenterm_run_events.event_json",
            sort_keys=True,
            ensure_ascii=True,
        )
        rows.append(
            (
                str(record.session_id),
                str(record.branch_id),
                int(record.run_number),
                int(record.request_index),
                int(record.event_seq),
                str(record.event_type),
                str(record.response_id) if record.response_id is not None else None,
                str(record.model),
                event_json,
            )
        )

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.executemany(
            """
            INSERT INTO agenterm_run_events (
                session_id,
                branch_id,
                run_number,
                request_index,
                event_seq,
                event_type,
                response_id,
                model,
                event_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )
        await conn.commit()

    await store.run(_op)


async def insert_run_events_batch_ignore_conflicts(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    events: Sequence[tuple[int, int, str, str | None, str, str]],
) -> None:
    """Insert run events with conflict ignore (used for spool replay)."""
    if not events:
        return
    await ensure_store_schema(store.db_path)
    rows: list[tuple[str | int | None, ...]] = []
    for request_index, event_seq, event_type, response_id, model, event_json in events:
        rows.append(
            (
                str(session_id),
                str(branch_id),
                int(run_number),
                int(request_index),
                int(event_seq),
                str(event_type),
                str(response_id) if response_id is not None else None,
                str(model),
                str(event_json),
            )
        )

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.executemany(
            """
            INSERT OR IGNORE INTO agenterm_run_events (
                session_id,
                branch_id,
                run_number,
                request_index,
                event_seq,
                event_type,
                response_id,
                model,
                event_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )
        await conn.commit()

    await store.run(_op)


async def list_run_events(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    limit: int | None = None,
) -> tuple[RunEventRecord, ...]:
    """Return ordered run events for a run."""
    await ensure_store_schema(store.db_path)
    limit_val = int(limit) if limit is not None else None

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        query = """
            SELECT
                session_id,
                branch_id,
                run_number,
                request_index,
                event_seq,
                event_type,
                response_id,
                model,
                event_json,
                created_at
            FROM agenterm_run_events
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            ORDER BY request_index ASC, event_seq ASC, id ASC
        """
        params: list[str | int] = [
            str(session_id),
            str(branch_id),
            int(run_number),
        ]
        if limit_val is not None:
            query = query + " LIMIT ?"
            params.append(limit_val)
        cur = await conn.execute(query, tuple(params))
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return tuple(_row_to_record(row) for row in rows)


async def count_run_events(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
) -> int:
    """Return the count of events for a run."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> int:
        cur = await conn.execute(
            """
            SELECT COUNT(*)
            FROM agenterm_run_events
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        row = await cur.fetchone()
        count = row[0] if row else 0
        return int(count or 0)

    return await store.run(_op)


__all__ = (
    "count_run_events",
    "insert_run_event",
    "insert_run_events_batch",
    "insert_run_events_batch_ignore_conflicts",
    "list_run_events",
)
