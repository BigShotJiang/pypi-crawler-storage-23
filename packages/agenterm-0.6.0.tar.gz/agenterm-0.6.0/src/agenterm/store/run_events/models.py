"""Run event ledger models for agenterm-owned persistence."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue
    from agenterm.core.trace_context import TraceLinkType

type RunEventPlane = Literal["openai", "gateway"]


@dataclass(frozen=True)
class RunEventPayload:
    """Event payload stored inside a run event envelope."""

    type: str
    plane: RunEventPlane
    model: str
    response_id: str | None
    request_index: int
    payload: dict[str, JSONValue]
    raw_provider_payload: JSONValue | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for the payload."""
        return {
            "type": self.type,
            "plane": self.plane,
            "model": self.model,
            "response_id": self.response_id,
            "request_index": self.request_index,
            "payload": dict(self.payload),
            "raw_provider_payload": self.raw_provider_payload,
        }


@dataclass(frozen=True)
class RunEventEnvelope:
    """Canonical envelope persisted for run event ledger entries."""

    schema_version: int
    trace_id: str | None
    group_id: str | None
    trace_metadata: dict[str, JSONValue] | None
    trace_link_type: TraceLinkType
    ts: str
    event: RunEventPayload

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for the envelope."""
        return {
            "schema_version": self.schema_version,
            "trace_id": self.trace_id,
            "group_id": self.group_id,
            "trace_metadata": (
                dict(self.trace_metadata) if self.trace_metadata is not None else None
            ),
            "trace_link_type": self.trace_link_type,
            "ts": self.ts,
            "event": self.event.to_json(),
        }


@dataclass(frozen=True)
class RunEventRecord:
    """Persisted run event record (decoded)."""

    session_id: str
    branch_id: str
    run_number: int
    request_index: int
    event_seq: int
    event_type: str
    response_id: str | None
    model: str
    event: dict[str, JSONValue]
    created_at: str | None


@dataclass(frozen=True)
class RunEventInsert:
    """Insert payload for a run event ledger row."""

    session_id: str
    branch_id: str
    run_number: int
    request_index: int
    event_seq: int
    event_type: str
    response_id: str | None
    model: str
    envelope: RunEventEnvelope


__all__ = (
    "RunEventEnvelope",
    "RunEventInsert",
    "RunEventPayload",
    "RunEventPlane",
    "RunEventRecord",
)
