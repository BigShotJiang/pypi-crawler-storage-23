"""Model catalog encode/decode + typed registry snapshots.

This module owns the canonical on-disk JSON shape for the cached model catalogs
stored in the single-row SQLite table `agenterm_model_registry`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import dumps_compact, loads_json_value

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


_CATALOG_SCHEMA_VERSION: Final[int] = 1
_CATALOG_KEY_REGISTRIES: Final[str] = "registries"
_CATALOG_KEY_SCHEMA_VERSION: Final[str] = "schema_version"

_REGISTRY_KEY_SOURCE: Final[str] = "source"
_REGISTRY_KEY_FETCHED_AT: Final[str] = "fetched_at"
_REGISTRY_KEY_MODELS: Final[str] = "models"

_MSG_CORRUPT_ENTRY: Final[str] = "Model registry cache is corrupted (invalid entry)."
_MSG_CORRUPT_MODEL_STRINGS: Final[str] = (
    "Model registry cache is corrupted (expected model strings)."
)


@dataclass(frozen=True)
class ModelRegistry:
    """Cached model registry snapshot (OpenAI or OpenAI-compatible route)."""

    models: frozenset[str]
    fetched_at: int
    source: str

    def is_stale(self, *, now: int, ttl_seconds: int) -> bool:
        """Return True when the registry age exceeds ttl_seconds."""
        return (now - self.fetched_at) > ttl_seconds

    def list_models(self, *, filter_text: str | None = None) -> list[str]:
        """Return sorted model ids, optionally filtered by substring."""
        models = sorted(self.models)
        if filter_text is None:
            return models
        needle = filter_text.strip().lower()
        if not needle:
            return models
        return [m for m in models if needle in m.lower()]


@dataclass(frozen=True)
class ModelCatalog:
    """Multi-registry model catalog stored as one SQLite payload."""

    registries: Mapping[str, ModelRegistry]

    def registry(self, key: str) -> ModelRegistry | None:
        """Return a registry by key (e.g. 'openai' or 'gateway/<route>')."""
        return self.registries.get(key)


def prefix_openai_model_id(model_id: str) -> str:
    """Normalize raw model ids into canonical `openai/<model>` ids."""
    trimmed = model_id.strip()
    if not trimmed:
        return trimmed
    if trimmed.startswith("openai/"):
        return trimmed
    if "/" in trimmed:
        return trimmed
    return f"openai/{trimmed}"


def prefix_gateway_model_id(*, route: str, model_id: str) -> str:
    """Normalize raw model ids into canonical `gateway/<route>/<model>` ids."""
    trimmed = model_id.strip()
    if not trimmed:
        return trimmed
    prefix = f"gateway/{route}/"
    if trimmed.startswith(prefix):
        return trimmed
    return f"{prefix}{trimmed}"


def _load_payload(payload: str) -> JSONValue:
    try:
        return loads_json_value(payload)
    except (TypeError, ValueError) as exc:
        msg = "Model registry cache is corrupted (invalid JSON)."
        raise ConfigError(msg) from exc


def _require_object(value: JSONValue, *, msg: str) -> dict[str, JSONValue]:
    if not isinstance(value, dict):
        raise ConfigError(msg)
    return value


def _require_string(value: JSONValue, *, msg: str) -> str:
    if not isinstance(value, str) or not value:
        raise ConfigError(msg)
    return value


def _require_int(value: JSONValue, *, msg: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ConfigError(msg)
    return int(value)


def _require_list(value: JSONValue, *, msg: str) -> list[JSONValue]:
    if not isinstance(value, list):
        raise ConfigError(msg)
    return value


def _require_string_list(raw: list[JSONValue]) -> list[str]:
    out: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            raise ConfigError(_MSG_CORRUPT_MODEL_STRINGS)
        if item:
            out.append(item)
    return out


def _decode_openai_models(raw: list[JSONValue]) -> list[str]:
    return [prefix_openai_model_id(m) for m in _require_string_list(raw)]


def _decode_gateway_models(*, route: str, raw: list[JSONValue]) -> list[str]:
    route_norm = route.strip()
    if not route_norm:
        msg = "Model registry cache is corrupted (missing gateway route)."
        raise ConfigError(msg)
    return [
        prefix_gateway_model_id(route=route_norm, model_id=m)
        for m in _require_string_list(raw)
    ]


def _decode_plain_models(raw: list[JSONValue]) -> list[str]:
    return [m.strip() for m in _require_string_list(raw)]


def _decode_models_for_key(key: str, raw: list[JSONValue]) -> list[str]:
    if key == "openai":
        return _decode_openai_models(raw)
    if key.startswith("gateway/"):
        _, _, route = key.partition("/")
        return _decode_gateway_models(route=route, raw=raw)
    return _decode_plain_models(raw)


def _decode_registry_entry(key: str, entry: JSONValue) -> ModelRegistry | None:
    if not key:
        msg = "Model registry cache is corrupted (invalid registry key)."
        raise ConfigError(msg)
    obj = _require_object(entry, msg=_MSG_CORRUPT_ENTRY)
    source = _require_string(
        obj.get(_REGISTRY_KEY_SOURCE),
        msg="Model registry cache is corrupted (missing registry source).",
    )
    fetched_at = _require_int(
        obj.get(_REGISTRY_KEY_FETCHED_AT),
        msg="Model registry cache is corrupted (missing registry fetched_at).",
    )
    models_raw = _require_list(
        obj.get(_REGISTRY_KEY_MODELS),
        msg="Model registry cache is corrupted (missing registry models).",
    )
    models = _decode_models_for_key(key, models_raw)
    if not models:
        return None
    return ModelRegistry(models=frozenset(models), fetched_at=fetched_at, source=source)


def decode_model_catalog(payload: str) -> ModelCatalog:
    """Decode a stored catalog payload or raise ConfigError on corruption."""
    parsed = _load_payload(payload)
    obj = _require_object(
        parsed,
        msg="Model registry cache is corrupted (expected object).",
    )
    schema_version = obj.get(_CATALOG_KEY_SCHEMA_VERSION)
    if not isinstance(schema_version, int) or schema_version != _CATALOG_SCHEMA_VERSION:
        msg = "Model registry cache is corrupted (unknown schema version)."
        raise ConfigError(msg)
    registries_raw = _require_object(
        obj.get(_CATALOG_KEY_REGISTRIES),
        msg="Model registry cache is corrupted (missing registries).",
    )
    if not registries_raw:
        msg = "Model registry cache is corrupted (missing registries)."
        raise ConfigError(msg)
    registries: dict[str, ModelRegistry] = {}
    for key, entry in registries_raw.items():
        registry = _decode_registry_entry(key, entry)
        if registry is not None:
            registries[key] = registry
    if not registries:
        msg = "Model registry cache is empty."
        raise ConfigError(msg)
    return ModelCatalog(registries=registries)


def encode_model_catalog(catalog: ModelCatalog) -> str:
    """Encode a catalog into the persisted JSON payload."""
    registries_obj: dict[str, JSONValue] = {}
    for key in sorted(catalog.registries.keys()):
        reg = catalog.registries[key]
        models: list[JSONValue] = []
        models.extend(sorted(reg.models))
        entry: dict[str, JSONValue] = {
            _REGISTRY_KEY_SOURCE: reg.source,
            _REGISTRY_KEY_FETCHED_AT: int(reg.fetched_at),
            _REGISTRY_KEY_MODELS: models,
        }
        registries_obj[key] = entry
    payload: dict[str, JSONValue] = {
        _CATALOG_KEY_SCHEMA_VERSION: _CATALOG_SCHEMA_VERSION,
        _CATALOG_KEY_REGISTRIES: registries_obj,
    }
    return dumps_compact(
        payload,
        ensure_ascii=True,
        context="model_registry.models_json",
    )


__all__ = (
    "ModelCatalog",
    "ModelRegistry",
    "decode_model_catalog",
    "encode_model_catalog",
    "prefix_gateway_model_id",
    "prefix_openai_model_id",
)
