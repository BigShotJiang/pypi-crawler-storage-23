"""Run context assembly for CLI `run` surfaces."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.app.services.configuration import (
    ConfigAndTools,
    RunConfigFlags,
    build_run_config_bundle,
)
from agenterm.app.services.model_registry import validate_model_id_with_registry
from agenterm.config.agent_files import resolve_agent
from agenterm.config.editors import set_agent, set_model_store
from agenterm.core.approvals import ApprovalsContext
from agenterm.core.errors import ConfigError
from agenterm.core.hashing import sha256_text_or_none
from agenterm.core.store_policy import store_is_enabled
from agenterm.engine.agent_factory import build_agent_from_config
from agenterm.store.session.service import (
    SessionFactoryConfig,
    make_session,
    session_store,
)

if TYPE_CHECKING:
    from agents.agent import Agent
    from agents.memory import Session

    from agenterm.config.model import AppConfig


@dataclass(frozen=True)
class RunContext:
    """Fully-prepared context for a one-shot run invocation."""

    cfg_bundle: ConfigAndTools
    cfg: AppConfig
    tools_enabled: bool
    agenterm_store: bool
    session: Session
    agent: Agent
    session_id: str | None
    branch_id: str | None
    background: bool
    approvals: ApprovalsContext


@dataclass(frozen=True)
class RunRequest:
    """Inputs required to build a RunContext."""

    flags: RunConfigFlags
    session_id: str | None
    branch_id: str | None


def _maybe_apply_agent_from_branch(
    cfg: AppConfig,
    *,
    branch_meta_agent: str | None,
) -> AppConfig:
    if not branch_meta_agent:
        return cfg
    try:
        resolved = resolve_agent(name=branch_meta_agent, explicit=False)
    except ConfigError:
        return cfg
    return set_agent(
        cfg,
        name=resolved.name,
        instructions=resolved.text,
        path=resolved.source.path,
        source=resolved.source.location,
        explicit=resolved.source.explicit,
    )


async def prepare_run_context(req: RunRequest) -> RunContext:
    """Build configuration, session, and agent for a run edge."""
    cfg_bundle, cfg_runtime, tools_enabled, effective_background = (
        build_run_config_bundle(
            flags=req.flags,
        )
    )

    await validate_model_id_with_registry(
        cfg_runtime.agent.model,
        store=session_store(),
        providers=cfg_runtime.providers,
    )

    model_store = cfg_runtime.model.store
    agenterm_store = store_is_enabled(store=model_store)

    agent_path = cfg_runtime.agent.path
    agent_sha256 = sha256_text_or_none(cfg_runtime.agent.instructions)

    session_cfg = SessionFactoryConfig(
        mode="background" if effective_background else "run",
        cwd=Path.cwd(),
        config_path=cfg_bundle.config_path,
        model=cfg_runtime.agent.model,
        tools_enabled=tools_enabled,
        trace_id=cfg_runtime.run.trace_id,
        group_id=cfg_runtime.run.group_id,
        session_id=req.session_id,
        branch_id=req.branch_id,
        store_enabled=agenterm_store,
        store_override=req.flags.store_override,
        agent_name=cfg_runtime.agent.name,
        agent_path=agent_path,
        agent_sha256=agent_sha256,
    )
    session_result = await make_session(session_cfg)
    session = session_result.session
    if session_result.branch_meta is not None:
        cfg_runtime = set_model_store(
            cfg_runtime,
            store=session_result.branch_meta.store_enabled,
        )
    cfg_runtime = _maybe_apply_agent_from_branch(
        cfg_runtime,
        branch_meta_agent=(
            session_result.branch_meta.agent_name
            if session_result.branch_meta is not None
            else None
        ),
    )
    approvals = ApprovalsContext(mode="auto")
    agent = build_agent_from_config(
        cfg_runtime,
        selected_tools=(cfg_bundle.selected_tools if tools_enabled else None),
        approvals=approvals,
    )
    if session_result.branch_meta is not None:
        agenterm_store = session_result.branch_meta.store_enabled

    return RunContext(
        cfg_bundle=cfg_bundle,
        cfg=cfg_runtime,
        tools_enabled=tools_enabled,
        agenterm_store=agenterm_store,
        session=session,
        agent=agent,
        session_id=session_result.session_id,
        branch_id=session_result.branch_id,
        background=effective_background,
        approvals=approvals,
    )
