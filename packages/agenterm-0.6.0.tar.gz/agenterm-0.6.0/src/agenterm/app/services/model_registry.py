"""Provider-scoped model registry refresh/validation.

This module owns the local model catalog cache used by:
- `openai/...` model id validation (cached `/models` snapshot), and
- interactive browsing (cached snapshots for OpenAI-compatible gateway routes).
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from openai import AsyncOpenAI, OpenAIError

from agenterm.app.services.model_catalog import (
    ModelCatalog,
    ModelRegistry,
    decode_model_catalog,
    encode_model_catalog,
    prefix_gateway_model_id,
    prefix_openai_model_id,
)
from agenterm.config.editors import validate_model_id
from agenterm.constants.limits import MODEL_REGISTRY_TTL_SECONDS
from agenterm.core.dotenv_loader import ensure_global_dotenv_loaded
from agenterm.core.errors import ConfigError, ValidationError
from agenterm.core.gateway_client import get_gateway_client
from agenterm.core.openai_client import get_openai_client
from agenterm.store.model_registry import (
    ModelRegistryRow,
    get_model_registry_row,
    upsert_model_registry_row,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from openai.types import Model

    from agenterm.config.model import GatewayRouteConfig, ProvidersConfig
    from agenterm.store.async_db import AsyncStore

_MODEL_REGISTRY_SOURCE = "openai/models"


@dataclass(frozen=True)
class ParsedModelId:
    """Parsed model identifier parts."""

    prefix: str
    route: str | None
    model: str


class ModelRegistryClient(Protocol):
    """Protocol for model registry sources."""

    async def list_model_ids(self) -> list[str]:
        """Return known model identifiers."""
        ...


@dataclass(frozen=True)
class OpenAIModelRegistryClient:
    """Adapter for fetching model ids from the OpenAI SDK client."""

    client: AsyncOpenAI

    async def list_model_ids(self) -> list[str]:
        """Fetch model ids using the OpenAI `/models` endpoint."""
        page = await self.client.models.list()
        items: Sequence[Model] = page.data
        return _collect_model_ids_openai(items)


def _collect_model_ids_openai(raw: Sequence[Model]) -> list[str]:
    out: list[str] = []
    for item in raw:
        model_id = item.id
        if model_id:
            out.append(prefix_openai_model_id(model_id))
    return out


def _collect_model_ids_raw(raw: Sequence[Model]) -> list[str]:
    out: list[str] = []
    for item in raw:
        model_id = item.id
        if model_id:
            out.append(str(model_id).strip())
    return out


def _parse_model_id(model_id: str) -> ParsedModelId:
    prefix, rest = model_id.split("/", 1)
    prefix_norm = prefix.lower()
    if prefix_norm == "openai":
        return ParsedModelId(prefix=prefix_norm, route=None, model=rest)
    if prefix_norm == "gateway":
        route, model = rest.split("/", 1)
        return ParsedModelId(prefix=prefix_norm, route=route, model=model)
    msg = "Model id prefix must be openai/ or gateway/."
    raise ValidationError(msg)


async def load_model_catalog(*, store: AsyncStore) -> ModelCatalog | None:
    """Load the cached model catalog from SQLite, if present."""
    row = await get_model_registry_row(store)
    if row is None:
        return None
    return decode_model_catalog(row.models_json)


async def load_model_registry(*, store: AsyncStore) -> ModelRegistry | None:
    """Load the cached OpenAI model registry from SQLite, if present."""
    catalog = await load_model_catalog(store=store)
    if catalog is None:
        return None
    return catalog.registry("openai")


async def load_gateway_model_registry(
    *,
    store: AsyncStore,
    route: str,
) -> ModelRegistry | None:
    """Load a cached gateway/<route> remote model registry, if present."""
    route_norm = (route or "").strip()
    if not route_norm:
        return None
    catalog = await load_model_catalog(store=store)
    if catalog is None:
        return None
    return catalog.registry(f"gateway/{route_norm}")


async def refresh_model_registry(
    *,
    store: AsyncStore,
    client: ModelRegistryClient | AsyncOpenAI | None = None,
    now: int | None = None,
) -> ModelRegistry:
    """Refresh the cached model registry from OpenAI."""
    catalog = await load_model_catalog(store=store)
    registries = dict(catalog.registries) if catalog is not None else {}
    registry_client = client or OpenAIModelRegistryClient(get_openai_client())
    if isinstance(registry_client, AsyncOpenAI):
        registry_client = OpenAIModelRegistryClient(registry_client)
    try:
        models = await registry_client.list_model_ids()
    except OpenAIError as exc:
        msg = f"Failed to fetch OpenAI model list: {exc}"
        raise ConfigError(msg) from exc
    if not models:
        msg = "OpenAI model list returned no model ids."
        raise ConfigError(msg)
    models_sorted = sorted({prefix_openai_model_id(m) for m in models if m})
    fetched_at = int(time.time() if now is None else now)
    registries["openai"] = ModelRegistry(
        models=frozenset(models_sorted),
        fetched_at=fetched_at,
        source=_MODEL_REGISTRY_SOURCE,
    )
    updated = ModelCatalog(registries=registries)
    row = ModelRegistryRow(
        source="model_catalog",
        fetched_at=max((r.fetched_at for r in updated.registries.values()), default=0),
        models_json=encode_model_catalog(updated),
    )
    await upsert_model_registry_row(store=store, row=row)
    return registries["openai"]


async def refresh_gateway_route_registry(
    *,
    store: AsyncStore,
    route: str,
    route_cfg: GatewayRouteConfig,
    client: ModelRegistryClient | AsyncOpenAI | None = None,
    now: int | None = None,
) -> ModelRegistry:
    """Refresh a cached gateway/<route> model registry.

    This hits an OpenAI-compatible `/models` endpoint and stores the results in
    the local multi-registry catalog cache.
    """
    route_norm = (route or "").strip()
    if not route_norm:
        msg = "Gateway route name must be non-empty."
        raise ValidationError(msg)
    catalog = await load_model_catalog(store=store)
    registries = dict(catalog.registries) if catalog is not None else {}
    effective_now = int(time.time() if now is None else now)
    try:
        if client is None:
            gateway_client = get_gateway_client(route=route_norm, route_cfg=route_cfg)
            page = await gateway_client.models.list()
            items: Sequence[Model] = page.data
            model_ids = _collect_model_ids_raw(items)
        elif isinstance(client, AsyncOpenAI):
            page = await client.models.list()
            items = page.data
            model_ids = _collect_model_ids_raw(items)
        else:
            model_ids = await client.list_model_ids()
    except OpenAIError as exc:
        msg = f"Failed to fetch gateway/{route_norm} model list: {exc}"
        raise ConfigError(msg) from exc
    if not model_ids:
        msg = f"Gateway route {route_norm} model list returned no model ids."
        raise ConfigError(msg)
    models_sorted = sorted(
        {prefix_gateway_model_id(route=route_norm, model_id=m) for m in model_ids if m}
    )
    key = f"gateway/{route_norm}"
    source = f"gateway/{route_norm}/models"
    registries[key] = ModelRegistry(
        models=frozenset(models_sorted),
        fetched_at=effective_now,
        source=source,
    )
    updated = ModelCatalog(registries=registries)
    row = ModelRegistryRow(
        source="model_catalog",
        fetched_at=max((r.fetched_at for r in updated.registries.values()), default=0),
        models_json=encode_model_catalog(updated),
    )
    await upsert_model_registry_row(store=store, row=row)
    return registries[key]


async def require_model_registry(
    *,
    store: AsyncStore,
    ttl_seconds: int = MODEL_REGISTRY_TTL_SECONDS,
    client: ModelRegistryClient | AsyncOpenAI | None = None,
    now: int | None = None,
) -> ModelRegistry:
    """Return a fresh registry snapshot or raise on refresh failure."""
    effective_now = int(time.time() if now is None else now)
    registry = await load_model_registry(store=store)
    if registry is None or registry.is_stale(
        now=effective_now,
        ttl_seconds=ttl_seconds,
    ):
        return await refresh_model_registry(
            store=store,
            client=client,
            now=effective_now,
        )
    return registry


async def validate_model_id_with_registry(
    model_id: str,
    *,
    store: AsyncStore,
    providers: ProvidersConfig,
    ttl_seconds: int = MODEL_REGISTRY_TTL_SECONDS,
    client: ModelRegistryClient | AsyncOpenAI | None = None,
) -> str:
    """Validate a model id against provider registries."""
    cleaned = validate_model_id(model_id)
    parsed = _parse_model_id(cleaned)
    if parsed.prefix == "openai":
        registry = await require_model_registry(
            store=store,
            ttl_seconds=ttl_seconds,
            client=client,
        )
        cleaned = prefix_openai_model_id(cleaned)
        if cleaned not in registry.models:
            msg = (
                "Model id is not in the cached OpenAI /models list. "
                "Use `/model` (or `/model openai`) to choose a suggested model, "
                "or set a valid `openai/<model>` id from the OpenAI catalog."
            )
            raise ValidationError(msg)
        openai_cfg = providers.openai
        if (
            not openai_cfg.allow_any_model
            and parsed.model not in openai_cfg.model_allowlist
        ):
            msg = (
                "Model id is not allowed for OpenAI policy. "
                "Set providers.openai.model_allowlist or "
                "providers.openai.allow_any_model=true."
            )
            raise ValidationError(msg)
        return cleaned

    route = parsed.route
    if route is None:
        msg = "Gateway model ids must be gateway/<route>/<model>."
        raise ValidationError(msg)
    route_cfg = providers.gateway.routes.get(route)
    if route_cfg is None:
        msg = f"Unknown gateway route: {route}"
        raise ValidationError(msg)
    ensure_global_dotenv_loaded()
    if route_cfg.api_key_env and not os.environ.get(route_cfg.api_key_env):
        msg = (
            f"Missing environment variable {route_cfg.api_key_env} for "
            f"gateway route {route}."
        )
        raise ConfigError(msg)
    if not route_cfg.allow_any_model and parsed.model not in route_cfg.model_allowlist:
        msg = (
            f"Model id is not allowed for gateway route {route}. "
            "Set providers.gateway.routes.<route>.model_allowlist or "
            "allow_any_model=true."
        )
        raise ValidationError(msg)
    return cleaned


__all__ = (
    "ModelCatalog",
    "ModelRegistry",
    "ModelRegistryClient",
    "OpenAIModelRegistryClient",
    "load_gateway_model_registry",
    "load_model_catalog",
    "load_model_registry",
    "refresh_gateway_route_registry",
    "refresh_model_registry",
    "require_model_registry",
    "validate_model_id_with_registry",
)
