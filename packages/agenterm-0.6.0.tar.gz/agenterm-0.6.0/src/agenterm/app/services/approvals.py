"""Helpers for wiring shell/apply_patch/hosted MCP approvals in the REPL."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.approvals import (
    ApprovalEvent,
    ApprovalsContext,
    CompressionApprovalItem,
    McpApprovalItem,
    PatchApprovalItem,
    ShellApprovalItem,
)
from agenterm.core.approvals_audit import ApprovalDecision, ApprovalFamily
from agenterm.core.text import shorten_line

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.core.types import SessionState

type ApprovalEventCallback = Callable[
    [
        ApprovalFamily,
        ShellApprovalItem
        | PatchApprovalItem
        | McpApprovalItem
        | CompressionApprovalItem,
        ApprovalDecision | None,
    ],
    None,
]


def _notify_noop(_message: str) -> None:
    return


def _approval_notice(ident: str, summary: str) -> str:
    s = summary.strip()
    if s:
        return f"Approval requested: {ident} — {s} (y/n or /approvals show {ident})"
    return f"Approval requested: {ident} — y/n or /approvals show {ident}"


def _shell_summary(item: ShellApprovalItem) -> str:
    head = item.commands[0] if item.commands else ""
    extra = len(item.commands) - 1
    summary = shorten_line(head, limit=80)
    if extra > 0:
        summary = shorten_line(f"{summary} (+{extra})", limit=92)
    return summary


def _patch_summary(item: PatchApprovalItem) -> str:
    return shorten_line(f"{item.operation_type} {item.path}", limit=92)


def _mcp_summary(item: McpApprovalItem) -> str:
    return shorten_line(f"{item.server_label} {item.tool_name}", limit=92)


def _compress_summary(item: CompressionApprovalItem) -> str:
    return shorten_line(item.message, limit=120)


def _build_shell_on_register(
    approvals: ApprovalsContext,
    *,
    notify: Callable[[str], None],
    emit_event: ApprovalEventCallback | None,
) -> Callable[[ShellApprovalItem], None]:
    def _on_shell(item: ShellApprovalItem) -> None:
        if emit_event is not None:
            emit_event("shell", item, None)
        if approvals.mode == "auto":
            return
        notify(_approval_notice(item.id, _shell_summary(item)))

    return _on_shell


def _build_patch_on_register(
    approvals: ApprovalsContext,
    *,
    notify: Callable[[str], None],
    emit_event: ApprovalEventCallback | None,
) -> Callable[[PatchApprovalItem], None]:
    def _on_patch(item: PatchApprovalItem) -> None:
        if emit_event is not None:
            emit_event("patch", item, None)
        if approvals.mode == "auto":
            return
        notify(_approval_notice(item.id, _patch_summary(item)))

    return _on_patch


def _build_mcp_on_register(
    approvals: ApprovalsContext,
    *,
    notify: Callable[[str], None],
) -> Callable[[McpApprovalItem], None]:
    def _on_mcp(item: McpApprovalItem) -> None:
        if approvals.mode == "auto":
            return
        notify(_approval_notice(item.id, _mcp_summary(item)))

    return _on_mcp


def _build_compress_on_register(
    approvals: ApprovalsContext,
    *,
    notify: Callable[[str], None],
    emit_event: ApprovalEventCallback | None,
) -> Callable[[CompressionApprovalItem], None]:
    def _on_compress(item: CompressionApprovalItem) -> None:
        if emit_event is not None:
            emit_event("compress", item, None)
        if approvals.mode == "auto":
            return
        notify(_approval_notice(item.id, _compress_summary(item)))

    return _on_compress


def _build_shell_on_resolve(
    *,
    emit_event: ApprovalEventCallback | None,
) -> Callable[[ShellApprovalItem, ApprovalDecision], None]:
    def _on_resolve(item: ShellApprovalItem, decision: ApprovalDecision) -> None:
        if emit_event is not None:
            emit_event("shell", item, decision)

    return _on_resolve


def _build_patch_on_resolve(
    *,
    emit_event: ApprovalEventCallback | None,
) -> Callable[[PatchApprovalItem, ApprovalDecision], None]:
    def _on_resolve(item: PatchApprovalItem, decision: ApprovalDecision) -> None:
        if emit_event is not None:
            emit_event("patch", item, decision)

    return _on_resolve


def _build_compress_on_resolve(
    *,
    emit_event: ApprovalEventCallback | None,
) -> Callable[[CompressionApprovalItem, ApprovalDecision], None]:
    def _on_resolve(item: CompressionApprovalItem, decision: ApprovalDecision) -> None:
        if emit_event is not None:
            emit_event("compress", item, decision)

    return _on_resolve


def _dispatch_register_event(
    event: ApprovalEvent,
    *,
    shell_on_register: Callable[[ShellApprovalItem], None],
    patch_on_register: Callable[[PatchApprovalItem], None],
    mcp_on_register: Callable[[McpApprovalItem], None],
    compress_on_register: Callable[[CompressionApprovalItem], None],
) -> None:
    if event.family == "shell" and isinstance(event.item, ShellApprovalItem):
        shell_on_register(event.item)
        return
    if event.family == "patch" and isinstance(event.item, PatchApprovalItem):
        patch_on_register(event.item)
        return
    if event.family == "mcp" and isinstance(event.item, McpApprovalItem):
        mcp_on_register(event.item)
        return
    if event.family == "compress" and isinstance(event.item, CompressionApprovalItem):
        compress_on_register(event.item)


def _dispatch_resolve_event(
    event: ApprovalEvent,
    *,
    shell_on_resolve: Callable[[ShellApprovalItem, ApprovalDecision], None],
    patch_on_resolve: Callable[[PatchApprovalItem, ApprovalDecision], None],
    compress_on_resolve: Callable[[CompressionApprovalItem, ApprovalDecision], None],
) -> None:
    if event.decision is None:
        return
    if event.family == "shell" and isinstance(event.item, ShellApprovalItem):
        shell_on_resolve(event.item, event.decision)
        return
    if event.family == "patch" and isinstance(event.item, PatchApprovalItem):
        patch_on_resolve(event.item, event.decision)
        return
    if event.family == "compress" and isinstance(event.item, CompressionApprovalItem):
        compress_on_resolve(event.item, event.decision)


def wire_repl_approvals(
    state: SessionState,
    *,
    notify: Callable[[str], None] | None = None,
    emit_event: ApprovalEventCallback | None = None,
) -> tuple[SessionState, Callable[[], None]]:
    """Attach approval callbacks and return (updated state, cleanup).

    - Auto-approves when approvals mode is `auto`.
    - Returns a cleanup callback that unsubscribes from the approvals context.
    - `emit_event` may render transcript blocks for shell/apply_patch approvals.
    """
    notify_fn: Callable[[str], None] = notify or _notify_noop
    approvals = state.approvals
    shell_on_register = _build_shell_on_register(
        approvals,
        notify=notify_fn,
        emit_event=emit_event,
    )
    patch_on_register = _build_patch_on_register(
        approvals,
        notify=notify_fn,
        emit_event=emit_event,
    )
    mcp_on_register = _build_mcp_on_register(approvals, notify=notify_fn)
    compress_on_register = _build_compress_on_register(
        approvals,
        notify=notify_fn,
        emit_event=emit_event,
    )
    shell_on_resolve = _build_shell_on_resolve(emit_event=emit_event)
    patch_on_resolve = _build_patch_on_resolve(emit_event=emit_event)
    compress_on_resolve = _build_compress_on_resolve(emit_event=emit_event)

    def _on_register(event: ApprovalEvent) -> None:
        _dispatch_register_event(
            event,
            shell_on_register=shell_on_register,
            patch_on_register=patch_on_register,
            mcp_on_register=mcp_on_register,
            compress_on_register=compress_on_register,
        )

    def _on_resolve(event: ApprovalEvent) -> None:
        _dispatch_resolve_event(
            event,
            shell_on_resolve=shell_on_resolve,
            patch_on_resolve=patch_on_resolve,
            compress_on_resolve=compress_on_resolve,
        )

    token = approvals.subscribe(
        on_register=_on_register,
        on_resolve=_on_resolve,
    )

    def _cleanup() -> None:
        approvals.unsubscribe(token)

    return state, _cleanup


__all__ = ("ApprovalFamily", "wire_repl_approvals")
