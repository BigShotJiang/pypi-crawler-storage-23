"""Service layer entrypoints for CLI/REPL orchestration."""

from __future__ import annotations

from agenterm.app.services.approvals import wire_repl_approvals
from agenterm.app.services.configuration import (
    ConfigAndTools,
    ReplConfigFlags,
    RunConfigFlags,
    build_repl_state_from_flags,
    build_run_config_bundle,
    load_base_app_config,
)
from agenterm.app.services.mcp_refresh import maybe_refresh_mcp
from agenterm.app.services.repl_session import attach_or_create_session
from agenterm.app.services.run_context import (
    RunContext,
    RunRequest,
    prepare_run_context,
)

__all__ = (
    "ConfigAndTools",
    "ReplConfigFlags",
    "RunConfigFlags",
    "RunContext",
    "RunRequest",
    "attach_or_create_session",
    "build_repl_state_from_flags",
    "build_run_config_bundle",
    "load_base_app_config",
    "maybe_refresh_mcp",
    "prepare_run_context",
    "wire_repl_approvals",
)
