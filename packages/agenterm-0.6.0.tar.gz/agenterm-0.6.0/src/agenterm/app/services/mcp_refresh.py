"""Helper to refresh MCP tools when requested."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.constants.display import MCP_ERROR_SUMMARY_MAX_CHARS_DEFAULT
from agenterm.core.error_report import (
    ErrorContext,
    ErrorReport,
    build_error_report,
    build_message_report,
)
from agenterm.core.errors import AgentermError
from agenterm.core.text import shorten_line
from agenterm.core.tool_selection import (
    ToolCatalog,
    resolve_selection,
    selected_mcp_server_configs,
)
from agenterm.engine.mcp_diagnostics import diagnose_mcp_servers

if TYPE_CHECKING:
    from agenterm.core.types import SessionState
    from agenterm.engine.mcp_diagnostics import McpStatusSnapshot


_MCP_REFRESH_MESSAGE_MAX_TOOLS = 8


def _summarize_errors(snapshot: McpStatusSnapshot) -> str | None:
    errs = [s for s in snapshot.servers if s.error is not None]
    if not errs:
        return None
    first = errs[0]
    head = f"{first.key}: {first.error}"
    extra = len(errs) - 1
    if extra > 0:
        head = f"{head} (+{extra} more)"
    return shorten_line(head, limit=MCP_ERROR_SUMMARY_MAX_CHARS_DEFAULT)


async def maybe_refresh_mcp(
    state: SessionState,
) -> tuple[SessionState, ErrorReport | str | None]:
    """Refresh MCP tools when `mcp_refresh_pending` is set.

    Returns (new_state, message | None). Message is printed by caller when set.
    """
    if not state.mcp.refresh_pending:
        return state, None
    cleared = replace(state, mcp=replace(state.mcp, refresh_pending=False))
    if not state.tools.enabled:
        return cleared, None

    catalog = ToolCatalog(
        tools_map=state.tools.tools_map or {},
        bundles_map=state.tools.bundles_map or {},
        default_bundles=list(state.tools.default_bundles or []),
    )
    resolved = resolve_selection(state.tools.selection, catalog=catalog)
    servers_cfg = (
        selected_mcp_server_configs(resolved.specs) if resolved.error is None else ()
    )
    if not servers_cfg:
        return replace(
            cleared,
            mcp=replace(
                cleared.mcp,
                tool_names=(),
                discovery_status="unknown",
                discovery_error=None,
            ),
        ), None

    try:
        snapshot, tools_by_server = await diagnose_mcp_servers(servers_cfg)
    except AgentermError as exc:
        new_state = replace(
            cleared,
            mcp=replace(
                cleared.mcp,
                discovery_status="error",
                discovery_error=shorten_line(
                    str(exc),
                    limit=MCP_ERROR_SUMMARY_MAX_CHARS_DEFAULT,
                ),
            ),
        )
        report = build_error_report(
            exc,
            context=ErrorContext(
                operation="repl.mcp.refresh",
                resource="repl.mcp.refresh",
                trace_id=state.cfg.run.trace_id,
            ),
        )
        return new_state, report

    names_set: set[str] = set()
    for tools in tools_by_server.values():
        names_set.update(tools.keys())
    names = tuple(sorted(names_set))

    errs = _summarize_errors(snapshot)
    status = "error" if snapshot.has_errors() else "ok"
    new_state = replace(
        cleared,
        mcp=replace(
            cleared.mcp,
            tool_names=names,
            discovery_status=status,
            discovery_error=errs,
        ),
    )

    preview = ", ".join(names[:_MCP_REFRESH_MESSAGE_MAX_TOOLS])
    msg: str | None
    if status == "error":
        hint = errs or "unknown error"
        msg = f"MCP discovery error: {hint} (use /mcp status for details)" + (
            f"; discovered {len(names)} tool(s): {preview}" if names else ""
        )
        report = build_message_report(
            kind="mcp_error",
            message=msg,
            context=ErrorContext(
                operation="repl.mcp.refresh",
                resource="repl.mcp.refresh",
                trace_id=state.cfg.run.trace_id,
            ),
        )
        return new_state, report
    if not names:
        msg = "[mcp] discovered 0 tools"
    else:
        extra = len(names) - min(len(names), _MCP_REFRESH_MESSAGE_MAX_TOOLS)
        suffix = f" (+{extra} more)" if extra > 0 else ""
        msg = f"[mcp] discovered {len(names)} tool(s): {preview}{suffix}"
    return new_state, msg


__all__ = ("maybe_refresh_mcp",)
