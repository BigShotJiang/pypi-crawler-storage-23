"""Session lifecycle helpers for the REPL."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.app.services.model_registry import validate_model_id_with_registry
from agenterm.config.agent_files import resolve_agent
from agenterm.config.editors import set_agent, set_model_store
from agenterm.core.approvals import ApprovalsContext
from agenterm.core.errors import ConfigError
from agenterm.core.hashing import sha256_text_or_none
from agenterm.core.store_policy import store_is_enabled
from agenterm.store.session.service import (
    SessionFactoryConfig,
    make_session,
    session_store,
)

if TYPE_CHECKING:
    from agents.memory import Session

    from agenterm.core.types import SessionState


def _maybe_apply_agent_from_meta(
    state: SessionState,
    name: str | None,
) -> SessionState:
    if not name:
        return state
    try:
        resolved = resolve_agent(name=name, explicit=False)
    except ConfigError:
        return state
    cfg = set_agent(
        state.cfg,
        name=resolved.name,
        instructions=resolved.text,
        path=resolved.source.path,
        source=resolved.source.location,
        explicit=resolved.source.explicit,
    )
    return state.with_cfg(cfg)


async def _attach_existing_session(
    state: SessionState,
    *,
    attach_session_id: str,
    store_override: bool | None,
) -> tuple[SessionState, Session]:
    session_cfg = SessionFactoryConfig(
        mode="repl",
        cwd=Path.cwd(),
        config_path=state.config_path,
        model=state.cfg.agent.model,
        tools_enabled=state.tools.enabled,
        trace_id=state.cfg.run.trace_id,
        group_id=state.cfg.run.group_id,
        session_id=attach_session_id,
        branch_id=None,
        store_enabled=store_is_enabled(store=state.cfg.model.store),
        store_override=store_override,
        agent_name=state.cfg.agent.name,
        agent_path=state.cfg.agent.path,
        agent_sha256=sha256_text_or_none(state.cfg.agent.instructions),
    )
    session_result = await make_session(session_cfg)
    branch_meta = session_result.branch_meta
    if branch_meta is None:
        msg = f"Failed to load branch metadata for session {attach_session_id!r}"
        raise ConfigError(msg)
    state = _maybe_apply_agent_from_meta(state, branch_meta.agent_name)
    cfg = set_model_store(state.cfg, store=branch_meta.store_enabled)
    state = state.with_cfg(cfg)
    state = replace(
        state,
        session_id=attach_session_id,
        branch_id=session_result.branch_id,
        prompt=replace(state.prompt, last_user_prompt=None),
        attachments=replace(
            state.attachments,
            pending=(),
            last_used=(),
            next_send_use_last=False,
        ),
        approvals=ApprovalsContext(mode=state.approvals.mode),
    )
    return state, session_result.session


async def _create_new_session(
    state: SessionState,
    *,
    store_override: bool | None,
) -> tuple[SessionState, Session]:
    store_flag = state.cfg.model.store
    if store_override is not None:
        agenterm_store = store_override
    else:
        agenterm_store = store_is_enabled(store=store_flag)
    session_cfg = SessionFactoryConfig(
        mode="repl",
        cwd=Path.cwd(),
        config_path=state.config_path,
        model=state.cfg.agent.model,
        tools_enabled=state.tools.enabled,
        trace_id=state.cfg.run.trace_id,
        group_id=state.cfg.run.group_id,
        session_id=None,
        branch_id=None,
        store_enabled=agenterm_store,
        store_override=store_override,
        agent_name=state.cfg.agent.name,
        agent_path=state.cfg.agent.path,
        agent_sha256=sha256_text_or_none(state.cfg.agent.instructions),
    )
    session_result = await make_session(session_cfg)
    if isinstance(session_result.session_id, str):
        state = replace(
            state,
            session_id=session_result.session_id,
            branch_id=session_result.branch_id,
            prompt=replace(state.prompt, last_user_prompt=None),
            approvals=ApprovalsContext(mode=state.approvals.mode),
        )
    return state, session_result.session


async def attach_or_create_session(
    state: SessionState,
    attach_session_id: str | None,
    *,
    store_override: bool | None = None,
) -> tuple[SessionState, Session]:
    """Return (updated_state, backing Session) for the REPL.

    - When attach_session_id is provided and exists in metadata, rehydrates
      model.store from metadata and binds an AgentermSQLiteSession to that id.
    - Otherwise creates a fresh AgentermSQLiteSession via the session factory
      and seeds SessionState.session_id.
    """
    await validate_model_id_with_registry(
        state.cfg.agent.model,
        store=session_store(),
        providers=state.cfg.providers,
    )
    if attach_session_id is not None:
        return await _attach_existing_session(
            state,
            attach_session_id=attach_session_id,
            store_override=store_override,
        )
    return await _create_new_session(
        state,
        store_override=store_override,
    )


__all__ = ("attach_or_create_session",)
