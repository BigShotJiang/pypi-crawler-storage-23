"""Workflows/services layer for CLI/REPL configuration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.workflow.repl.build_state import (
    ReplConfigInputs,
)
from agenterm.workflow.repl.build_state import (
    build_repl_state_from_flags as _build_repl_state,
)
from agenterm.workflow.run.build_state import (
    ConfigAndTools,
    RunConfigInputs,
)
from agenterm.workflow.run.build_state import (
    build_run_config_bundle as _build_run,
)
from agenterm.workflow.shared.config_files import load_base_config as _load_base_config

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.config.model import AppConfig
    from agenterm.core.choices.approvals import ApprovalMode
    from agenterm.core.types import SessionState


@dataclass(frozen=True)
class RunConfigFlags:
    """Flag bundle for constructing run configuration."""

    config: Path | None
    agent_name: str | None
    model: str | None
    trace_enabled: bool | None
    trace_id: str | None
    trace_group: str | None
    trace_metadata: list[str] | None
    no_tools: bool
    tool_select: list[str] | None
    no_retry: bool
    max_retries: int | None
    deadline_seconds: float | None
    attempt_timeout_seconds: float | None
    store_override: bool | None
    allow_dangerous: bool
    hosted_mode: bool
    background_flag: bool | None


@dataclass(frozen=True)
class ReplConfigFlags:
    """Flag bundle for constructing initial REPL SessionState."""

    config: Path | None
    agent_name: str | None
    model: str | None
    no_tools: bool
    trace_enabled: bool | None
    trace_id: str | None
    trace_group: str | None
    trace_metadata: list[str] | None
    store_override: bool | None
    approvals_mode: ApprovalMode | None
    allow_dangerous: bool


def build_run_config_bundle(
    flags: RunConfigFlags,
) -> tuple[ConfigAndTools, AppConfig, bool, bool]:
    """Return (bundle, runtime cfg, tools_enabled, background) for run surfaces."""
    return _build_run(
        RunConfigInputs(
            config=flags.config,
            agent_name=flags.agent_name,
            model=flags.model,
            trace_enabled=flags.trace_enabled,
            trace_id=flags.trace_id,
            trace_group=flags.trace_group,
            trace_metadata=flags.trace_metadata,
            store_override=flags.store_override,
            allow_dangerous=flags.allow_dangerous,
            hosted_mode=flags.hosted_mode,
            background_flag=flags.background_flag,
            no_tools=flags.no_tools,
            tool_select=flags.tool_select,
            no_retry=flags.no_retry,
            max_retries=flags.max_retries,
            deadline_seconds=flags.deadline_seconds,
            attempt_timeout_seconds=flags.attempt_timeout_seconds,
        ),
    )


def build_repl_state_from_flags(flags: ReplConfigFlags) -> SessionState:
    """Return an initialized SessionState for the REPL."""
    return _build_repl_state(
        ReplConfigInputs(
            config=flags.config,
            agent_name=flags.agent_name,
            model=flags.model,
            no_tools=flags.no_tools,
            trace_enabled=flags.trace_enabled,
            trace_id=flags.trace_id,
            trace_group=flags.trace_group,
            trace_metadata=flags.trace_metadata,
            store_override=flags.store_override,
            approvals_mode=flags.approvals_mode,
            allow_dangerous=flags.allow_dangerous,
        ),
    )


def load_base_app_config(path: Path | None) -> AppConfig:
    """Load and validate the base AppConfig from YAML/JSON."""
    return _load_base_config(path)


__all__ = (
    "ConfigAndTools",
    "ReplConfigFlags",
    "RunConfigFlags",
    "build_repl_state_from_flags",
    "build_run_config_bundle",
    "load_base_app_config",
)
