"""Application-level services for agenterm.

This package hosts small orchestration helpers that sit above the engine and
config layers but below the CLI/REPL edges. Services are thin: they accept
typed state/config objects and return updated instances without side effects
outside the process.
"""

from __future__ import annotations

__all__: tuple[str, ...] = ()
