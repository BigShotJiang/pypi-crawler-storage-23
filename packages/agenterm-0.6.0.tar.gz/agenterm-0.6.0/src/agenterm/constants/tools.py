"""Typed tool constants for OpenAI Responses tool_choice values.

Docs Evidence Block
- Claim: Web search tool variants are available as typed ToolParam options.
- Evidence: .venv:lib/python3.12/site-packages/openai/types/responses/
  web_search_tool_param.py
- Confidence: 1.0

- Claim: File search and image generation are concrete ToolParam variants
  with typed fields.
- Evidence: .venv:lib/python3.12/site-packages/openai/types/responses/
  tool_param.py
- Confidence: 1.0
"""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

    from openai.types.responses.tool_choice_types_param import ToolChoiceTypesParam

TOOL_TYPE_FUNCTION: Final[str] = "function"
TOOL_TYPE_FILE_SEARCH: Final[str] = "file_search"
TOOL_TYPE_WEB_SEARCH: Final[str] = "web_search"
TOOL_TYPE_IMAGE_GENERATION: Final[str] = "image_generation"
TOOL_TYPE_HOSTED_MCP: Final[str] = "hosted_mcp"

ToolChoiceTypeLiteral = Literal[
    "file_search",
    "web_search_preview",
    "image_generation",
]


def _tool_choice_param(type_value: ToolChoiceTypeLiteral) -> ToolChoiceTypesParam:
    return {"type": type_value}


_TOOL_CHOICE_TYPES_MAP: Final[Mapping[str, ToolChoiceTypesParam]] = MappingProxyType(
    {
        TOOL_TYPE_FILE_SEARCH: _tool_choice_param(TOOL_TYPE_FILE_SEARCH),
        TOOL_TYPE_WEB_SEARCH: _tool_choice_param("web_search_preview"),
        TOOL_TYPE_IMAGE_GENERATION: _tool_choice_param(TOOL_TYPE_IMAGE_GENERATION),
    },
)


def types_param_from_string(s: str) -> ToolChoiceTypesParam | None:
    """Return a typed ToolChoiceTypesParam for supported non-function tools."""
    return _TOOL_CHOICE_TYPES_MAP.get(s)


__all__ = (
    "TOOL_TYPE_FILE_SEARCH",
    "TOOL_TYPE_FUNCTION",
    "TOOL_TYPE_HOSTED_MCP",
    "TOOL_TYPE_IMAGE_GENERATION",
    "TOOL_TYPE_WEB_SEARCH",
    "types_param_from_string",
)
