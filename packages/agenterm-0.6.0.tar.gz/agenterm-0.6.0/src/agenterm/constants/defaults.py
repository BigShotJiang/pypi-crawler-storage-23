"""Default identifiers and values shared across config surfaces."""

from __future__ import annotations

from typing import Final

DEFAULT_MODEL_ID: Final[str] = "openai/gpt-5.2"

DEFAULT_OPENAI_MODELS: Final[tuple[str, ...]] = (
    "gpt-5.2",
    "gpt-5.2-codex",
    "gpt-5-mini",
)

DEFAULT_OPENROUTER_ALLOWLIST: Final[tuple[str, ...]] = (
    "anthropic/claude-opus-4-6",
    "google/gemini-3-pro-preview",
    "google/gemini-3-flash-preview",
    "moonshotai/kimi-k2.5",
)

DEFAULT_OLLAMA_BASE_URL: Final[str] = "http://localhost:11434/v1"
DEFAULT_OLLAMA_MODEL_SUGGESTIONS: Final[tuple[str, ...]] = (
    "gpt-oss:20b",
    "gpt-oss:120b",
)

__all__ = (
    "DEFAULT_MODEL_ID",
    "DEFAULT_OLLAMA_BASE_URL",
    "DEFAULT_OLLAMA_MODEL_SUGGESTIONS",
    "DEFAULT_OPENAI_MODELS",
    "DEFAULT_OPENROUTER_ALLOWLIST",
)
