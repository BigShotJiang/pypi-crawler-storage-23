"""Default include keys for Responses API calls."""

from __future__ import annotations

from typing import TYPE_CHECKING, Final

if TYPE_CHECKING:
    from openai.types.responses.response_includable import ResponseIncludable

# Fixed include set used by agenterm.
# We restrict the surface to a small, high-value subset of the SDK's
# ResponseIncludable literals and do not expose a user-facing knob for
# configuring it. This keeps the runtime predictable while still capturing
# the key accessories we care about (file/web search results, images,
# encrypted reasoning).
#
# Evidence (SDK):
#   .venv/lib/python3.14/site-packages/openai/types/responses/response_includable.py
LOGPROBS_RESPONSE_INCLUDE: Final[ResponseIncludable] = "message.output_text.logprobs"

DEFAULT_RESPONSE_INCLUDE: Final[list[ResponseIncludable]] = [
    "file_search_call.results",
    "web_search_call.results",
    "web_search_call.action.sources",
    "reasoning.encrypted_content",
]


__all__ = ("DEFAULT_RESPONSE_INCLUDE", "LOGPROBS_RESPONSE_INCLUDE")
