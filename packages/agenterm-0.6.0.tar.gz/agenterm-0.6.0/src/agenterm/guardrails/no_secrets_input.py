"""Built-in input guardrail that blocks obvious secrets in user input.

This is intentionally conservative: it targets a small set of high-signal
credential shapes and never returns the matched value in its output.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

from agents.guardrail import GuardrailFunctionOutput, input_guardrail

from agenterm.core.guardrails_registry import register_input_guardrail

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.agent import Agent
    from agents.run_context import RunContextWrapper
    from openai.types.responses.response_input_content_param import (
        ResponseInputContentParam,
    )
    from openai.types.responses.response_input_param import ResponseInputItemParam
    from openai.types.responses.response_output_message_param import (
        Content as OutputMessageContent,
    )
    from openai.types.responses.response_reasoning_item_param import (
        Content as ReasoningContent,
    )


@dataclass(frozen=True, slots=True)
class _SecretHit:
    kind: str


_MAX_SCAN_CHARS: Final[int] = 20_000


_SECRET_PATTERNS: Final[tuple[tuple[str, re.Pattern[str]], ...]] = (
    ("private_key_block", re.compile(r"-----BEGIN [A-Z ]+ PRIVATE KEY-----")),
    # OpenAI-style API keys (common form). Keep threshold high to reduce
    # false positives.
    ("openai_api_key", re.compile(r"\bsk-[A-Za-z0-9]{20,}\b")),
    # GitHub personal access token.
    ("github_pat", re.compile(r"\bghp_[A-Za-z0-9]{20,}\b")),
    # AWS access key id (does not include the secret access key, but is still
    # sensitive).
    ("aws_access_key_id", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
)


def _detect_secret(text: str) -> _SecretHit | None:
    if not text:
        return None
    scan = text[:_MAX_SCAN_CHARS]
    for kind, pat in _SECRET_PATTERNS:
        if pat.search(scan):
            return _SecretHit(kind=kind)
    return None


def _text_from_part(
    part: ResponseInputContentParam | OutputMessageContent | ReasoningContent,
) -> str | None:
    if part["type"] == "input_text":
        txt = part["text"]
        return txt or None
    if part["type"] == "output_text":
        txt = part["text"]
        return txt or None
    if part["type"] == "reasoning_text":
        txt = part["text"]
        return txt or None
    return None


def _texts_from_message_content(
    content: Sequence[ResponseInputContentParam]
    | Sequence[OutputMessageContent]
    | Sequence[ReasoningContent],
) -> list[str]:
    out: list[str] = []
    for part in content:
        txt = _text_from_part(part)
        if txt is not None:
            out.append(txt)
    return out


def _texts_from_item(item: ResponseInputItemParam) -> list[str]:
    if "type" not in item:
        return []
    if item["type"] != "message":
        return []
    if "content" not in item:
        return []
    content = item["content"]
    if isinstance(content, str):
        return [content] if content else []
    if isinstance(content, list):
        return _texts_from_message_content(content)
    return []


def _text_from_items(items: list[ResponseInputItemParam]) -> str:
    """Best-effort extraction of user text from ResponseInputItemParam list."""
    out: list[str] = []
    for item in items:
        out.extend(_texts_from_item(item))
    return " ".join(out)


@input_guardrail(name="no_secrets_input", run_in_parallel=False)
def no_secrets_input_guardrail(
    context: RunContextWrapper[object],
    agent: Agent[object],
    input_value: str | list[ResponseInputItemParam],
) -> GuardrailFunctionOutput:
    """Tripwire when obvious secrets are present in the input."""
    _ = (context, agent)
    text = (
        input_value if isinstance(input_value, str) else _text_from_items(input_value)
    )

    hit = _detect_secret(text)
    if hit is None:
        return GuardrailFunctionOutput(
            output_info={"reason": "ok"},
            tripwire_triggered=False,
        )

    return GuardrailFunctionOutput(
        output_info={
            "reason": "secret_detected",
            "kind": hit.kind,
            "guardrail": "no_secrets_input",
        },
        tripwire_triggered=True,
    )


register_input_guardrail("no_secrets_input", no_secrets_input_guardrail)
