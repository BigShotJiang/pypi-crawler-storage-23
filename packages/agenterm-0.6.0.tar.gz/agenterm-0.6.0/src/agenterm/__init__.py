"""agenterm package."""

from importlib.metadata import version

__all__ = ("__version__",)

# Single source of truth: reads from pyproject.toml via installed package metadata
__version__ = version("agenterm")
