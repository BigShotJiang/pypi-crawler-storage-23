"""Run section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc

SECTION_DOC = SectionDoc(
    lines=(
        "==============================================================================",
        "RUN - Default behavior for CLI runs",
        "==============================================================================",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "run.background": FieldDoc(
        inline=(
            "Server-side execution (non-streaming; openai/* or gateway routes "
            "with supports_background=true)"
        ),
    ),
    "run.timeout_seconds": FieldDoc(
        inline=(
            "Stream idle timeout seconds (no events/model bytes; resets on any event;"
            " null = no limit)"
        ),
    ),
    "run.progress_timeout_seconds": FieldDoc(
        inline=(
            "Stream progress timeout seconds (whitespace-only tool-arg deltas do not"
            " count; null = no limit)"
        ),
    ),
    "run.tool_args_max_chars": FieldDoc(
        inline=(
            "Max streamed tool-argument chars per tool call (sum of deltas; null = no"
            " limit)"
        ),
    ),
    "run.live": FieldDoc(inline="false = quiet summary, true = stream live events"),
    "run.json_output": FieldDoc(
        inline="true = emit JSON envelope instead of text output",
    ),
    "run.trace_enabled": FieldDoc(
        before=("Tracing (for observability platforms)",),
        inline="Enable/disable tracing for runs and REPL runs",
    ),
    "run.trace_id": FieldDoc(inline="Optional trace id"),
    "run.group_id": FieldDoc(inline="Optional trace grouping id"),
    "run.trace_metadata": FieldDoc(inline="Mapping[str, str]"),
    "run.trace_include_sensitive_data": FieldDoc(
        inline="Include sensitive data in traces",
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
