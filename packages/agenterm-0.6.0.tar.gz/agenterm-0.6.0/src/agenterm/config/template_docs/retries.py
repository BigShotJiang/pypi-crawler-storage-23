"""Retries section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc

SECTION_DOC = SectionDoc(
    lines=(
        "==============================================================================",
        "RETRIES - Unified retry policy (provider/MCP/store)",
        "==============================================================================",
        "SDK retries are disabled; agenterm owns the retry loop.",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "retries.provider": FieldDoc(
        before=("Provider retries (model calls: streamed/background/agent_run).",),
    ),
    "retries.provider.max_retries": FieldDoc(
        inline="Non-negative; 0 disables retries",
    ),
    "retries.provider.base_backoff_seconds": FieldDoc(
        inline="Base seconds for exponential backoff",
    ),
    "retries.provider.max_backoff_seconds": FieldDoc(
        inline="Max seconds for exponential backoff",
    ),
    "retries.provider.jitter_ratio": FieldDoc(
        inline="0.0-1.0; jitter applied as 1 - ratio * rand()",
    ),
    "retries.provider.retry_after_max_seconds": FieldDoc(
        inline="Cap for Retry-After (null disables)",
    ),
    "retries.provider.max_total_attempts": FieldDoc(
        inline="Hard cap for total provider attempts across one run",
    ),
    "retries.provider.deadline_seconds": FieldDoc(
        inline="Run-level retry deadline in seconds (null disables)",
    ),
    "retries.provider.attempt_timeout_seconds": FieldDoc(
        inline="Per-attempt provider timeout in seconds (null disables)",
    ),
    "retries.mcp": FieldDoc(
        before=("MCP retries (list_tools/call_tool).",),
    ),
    "retries.mcp.max_retries": FieldDoc(
        inline="Non-negative; 0 disables retries",
    ),
    "retries.mcp.base_backoff_seconds": FieldDoc(
        inline="Base seconds for exponential backoff",
    ),
    "retries.mcp.max_backoff_seconds": FieldDoc(
        inline="Max seconds for exponential backoff",
    ),
    "retries.mcp.jitter_ratio": FieldDoc(
        inline="0.0-1.0; jitter applied as 1 - ratio * rand()",
    ),
    "retries.mcp.retry_after_max_seconds": FieldDoc(
        inline="Ignored for MCP (no Retry-After headers)",
    ),
    "retries.mcp.max_total_attempts": FieldDoc(
        inline="Hard cap for total MCP attempts per operation",
    ),
    "retries.mcp.deadline_seconds": FieldDoc(
        inline="Operation-level retry deadline in seconds (null disables)",
    ),
    "retries.mcp.attempt_timeout_seconds": FieldDoc(
        inline="Per-attempt MCP timeout in seconds (null disables)",
    ),
    "retries.store": FieldDoc(
        before=("SQLite store retries (SQLITE_BUSY).",),
    ),
    "retries.store.max_retries": FieldDoc(
        inline="Non-negative; 0 disables retries",
    ),
    "retries.store.base_backoff_seconds": FieldDoc(
        inline="Base seconds for exponential backoff",
    ),
    "retries.store.max_backoff_seconds": FieldDoc(
        inline="Max seconds for exponential backoff",
    ),
    "retries.store.jitter_ratio": FieldDoc(
        inline="0.0-1.0; jitter applied as 1 - ratio * rand()",
    ),
    "retries.store.retry_after_max_seconds": FieldDoc(
        inline="Ignored for SQLite",
    ),
    "retries.store.max_total_attempts": FieldDoc(
        inline="Hard cap for total store attempts per operation",
    ),
    "retries.store.deadline_seconds": FieldDoc(
        inline="Operation-level retry deadline in seconds (null disables)",
    ),
    "retries.store.attempt_timeout_seconds": FieldDoc(
        inline="Per-attempt store timeout in seconds (null disables)",
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
