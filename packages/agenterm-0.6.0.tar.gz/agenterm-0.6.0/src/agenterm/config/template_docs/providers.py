"""Providers section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc

SECTION_DOC = SectionDoc(
    lines=(
        "============================================================",
        "PROVIDERS - OpenAI + gateway (OpenAI-compatible) settings",
        "============================================================",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "providers.openai": FieldDoc(
        inline="OpenAI settings (API key is always sourced from env)",
    ),
    "providers.openai.base_url": FieldDoc(
        inline=(
            "Optional OpenAI-compatible endpoint override (overrides OPENAI_BASE_URL)"
        ),
    ),
    "providers.openai.model_suggestions": FieldDoc(
        inline="Opinionated OpenAI model list shown in `/model` picker",
    ),
    "providers.openai.model_allowlist": FieldDoc(
        inline="Optional allowed OpenAI model IDs (used when allow_any_model=false)",
    ),
    "providers.openai.allow_any_model": FieldDoc(
        inline=(
            "When true (default), allow any OpenAI model in the cached /models registry"
        ),
    ),
    "providers.gateway": FieldDoc(
        inline="Gateway routes (in-process; OpenAI-compatible; optional LiteLLM)",
    ),
    "providers.gateway.routes": FieldDoc(
        before=(
            "Gateway route map (route name -> route config).",
            "Each route is referenced as gateway/<route>/<model>.",
            "Route names must be non-empty and must not contain '/'.",
            "When allow_any_model is false, model_allowlist must be non-empty.",
            "api_key_env names the env var with the key (no secrets in config).",
            "model_suggestions defines route-default models shown in `/model`.",
            "protocol selects the route protocol:",
            "- litellm_chat_completions: Responses input -> Chat Completions",
            "  via LiteLLM conversion.",
            "  Conversion constraints apply:",
            "  - input_image requires image_url (file_id rejected).",
            "  - input_file requires file_data (file_url/file_id rejected).",
            "- openai_responses: OpenAI-compatible Responses API",
            "  (no LiteLLM required).",
            "response_include optionally overrides the default Responses include set",
            "for this route.",
            "retry_* fields optionally override retries.provider for this route.",
            "Capability flags (supports_compaction / supports_background / "
            "supports_file_id / "
            "supports_image_url / allow_inline_data_url) gate compression and "
            "attachment handling.",
        ),
    ),
    # --- Default OpenRouter route fields ---
    "providers.gateway.routes.openrouter": FieldDoc(
        before=(
            "Built-in OpenRouter route (Responses API).",
            "Set OPENROUTER_API_KEY in env to activate.",
        ),
    ),
    "providers.gateway.routes.openrouter.provider": FieldDoc(
        inline="LiteLLM provider id (used only for litellm_chat_completions)",
    ),
    "providers.gateway.routes.openrouter.protocol": FieldDoc(
        inline="Route protocol (openai_responses | litellm_chat_completions)",
    ),
    "providers.gateway.routes.openrouter.base_url": FieldDoc(
        inline="OpenAI-compatible endpoint URL",
    ),
    "providers.gateway.routes.openrouter.api_key_env": FieldDoc(
        inline="Env var name for the API key (no secrets in config)",
    ),
    "providers.gateway.routes.openrouter.headers": FieldDoc(
        inline="Optional non-secret static headers (e.g., metadata)",
    ),
    "providers.gateway.routes.openrouter.model_suggestions": FieldDoc(
        inline="Opinionated model list shown in `/model openrouter`",
    ),
    "providers.gateway.routes.openrouter.model_allowlist": FieldDoc(
        inline="Allowed model IDs for this route (enforced unless allow_any_model)",
    ),
    "providers.gateway.routes.openrouter.allow_any_model": FieldDoc(
        inline="When true, bypasses model_allowlist validation",
    ),
    "providers.gateway.routes.openrouter.supports_compaction": FieldDoc(
        inline="Whether this route supports conversation compaction",
    ),
    "providers.gateway.routes.openrouter.supports_background": FieldDoc(
        inline=(
            "Whether this route supports provider-hosted background runs "
            "(requires response retrieval support)"
        ),
    ),
    "providers.gateway.routes.openrouter.supports_file_id": FieldDoc(
        inline="Whether this route supports file_id references",
    ),
    "providers.gateway.routes.openrouter.supports_image_url": FieldDoc(
        inline="Whether this route supports image_url input parts",
    ),
    "providers.gateway.routes.openrouter.allow_inline_data_url": FieldDoc(
        inline="Whether to inline local images as data: URIs",
    ),
    "providers.gateway.routes.openrouter.response_include": FieldDoc(
        inline="Route-scoped include override for Responses API requests",
    ),
    "providers.gateway.routes.openrouter.retry_max_retries": FieldDoc(
        inline="Optional route override for retries.provider.max_retries",
    ),
    "providers.gateway.routes.openrouter.retry_max_total_attempts": FieldDoc(
        inline="Optional route override for retries.provider.max_total_attempts",
    ),
    "providers.gateway.routes.openrouter.retry_deadline_seconds": FieldDoc(
        inline="Optional route override for retries.provider.deadline_seconds",
    ),
    "providers.gateway.routes.openrouter.retry_attempt_timeout_seconds": FieldDoc(
        inline="Optional route override for retries.provider.attempt_timeout_seconds",
    ),
    # --- Default Ollama route fields ---
    "providers.gateway.routes.ollama": FieldDoc(
        before=(
            "Built-in Ollama route (local OpenAI-compatible Responses API).",
            "No API key required for the default localhost setup.",
        ),
    ),
    "providers.gateway.routes.ollama.provider": FieldDoc(
        inline="Provider label for diagnostics and route metadata",
    ),
    "providers.gateway.routes.ollama.protocol": FieldDoc(
        inline="Route protocol (openai_responses | litellm_chat_completions)",
    ),
    "providers.gateway.routes.ollama.base_url": FieldDoc(
        inline="Local Ollama OpenAI-compatible endpoint URL",
    ),
    "providers.gateway.routes.ollama.api_key_env": FieldDoc(
        inline="Optional env var name for API key (null for default local Ollama)",
    ),
    "providers.gateway.routes.ollama.headers": FieldDoc(
        inline="Optional non-secret static headers (for proxied deployments)",
    ),
    "providers.gateway.routes.ollama.model_suggestions": FieldDoc(
        inline="Opinionated local models shown in `/model ollama`",
    ),
    "providers.gateway.routes.ollama.model_allowlist": FieldDoc(
        inline="Optional pinned model IDs (allow_any_model=true permits any model)",
    ),
    "providers.gateway.routes.ollama.allow_any_model": FieldDoc(
        inline="When true, allows any locally available model id",
    ),
    "providers.gateway.routes.ollama.supports_compaction": FieldDoc(
        inline="Whether this route supports conversation compaction",
    ),
    "providers.gateway.routes.ollama.supports_background": FieldDoc(
        inline=(
            "Whether this route supports provider-hosted background runs "
            "(default: false for Ollama)"
        ),
    ),
    "providers.gateway.routes.ollama.supports_file_id": FieldDoc(
        inline="Whether this route supports file_id references",
    ),
    "providers.gateway.routes.ollama.supports_image_url": FieldDoc(
        inline="Whether this route supports image_url input parts",
    ),
    "providers.gateway.routes.ollama.allow_inline_data_url": FieldDoc(
        inline="Whether to inline local images as data: URIs",
    ),
    "providers.gateway.routes.ollama.response_include": FieldDoc(
        inline="Route-scoped include override for Responses API requests",
    ),
    "providers.gateway.routes.ollama.retry_max_retries": FieldDoc(
        inline="Optional route override for retries.provider.max_retries",
    ),
    "providers.gateway.routes.ollama.retry_max_total_attempts": FieldDoc(
        inline="Optional route override for retries.provider.max_total_attempts",
    ),
    "providers.gateway.routes.ollama.retry_deadline_seconds": FieldDoc(
        inline="Optional route override for retries.provider.deadline_seconds",
    ),
    "providers.gateway.routes.ollama.retry_attempt_timeout_seconds": FieldDoc(
        inline="Optional route override for retries.provider.attempt_timeout_seconds",
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
