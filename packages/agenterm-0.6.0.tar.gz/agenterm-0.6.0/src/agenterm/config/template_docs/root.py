"""Root comment block for the generated config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import RootDoc

ROOT_DOC = RootDoc(
    lines=(
        "agenterm Configuration (config.yaml)",
        "",
        "This is a complete, commented reference configuration for the agenterm CLI.",
        "All sections are optional; omitted keys fall back to built-in defaults.",
        "",
        "Capabilities at a glance:",
        "- OpenAI Responses plane + in-process gateway routes",
        "  (OpenAI-compatible Responses and LiteLLM adapters).",
        "- Route-first model UX (`/model`): openai, openrouter, ollama.",
        "- Local tools (inspect/shell/apply_patch/plan/agent_run/steward)",
        "  plus hosted tools (file_search/web_search/image_generation).",
        "- MCP connectors (provider-hosted) and MCP servers",
        "  (local stdio/SSE/streamable HTTP).",
        "- Local session store with history packing, inspection, and tracing controls.",
        "",
        "Config discovery order:",
        "  1) --config PATH (explicit)",
        "  2) ./.agenterm/config.yaml (project-local override; when present)",
        "  3) ~/.agenterm/config.yaml (global baseline)",
        "",
        "Quick start:",
        "  agenterm repl                   Start interactive REPL",
        "                             (prompts to save config if missing)",
        "  agenterm config save --scope global  Write global baseline config",
        "  agenterm config save --scope local   Create a project override in",
        "                                  .agenterm/config.yaml",
        "  agenterm agents save --scope global  Write global agent files",
        "  agenterm agents save --scope local   Create .agenterm/agents/ overrides",
        "  agenterm config show             View effective values",
        '  agenterm run "..."              Execute a one-shot prompt',
        "",
        "Notes:",
        '- YAML `null` means "unset" (use the built-in default).',
        "- Tool exposure is controlled by selection (bundles + tool keys).",
        "- To remove a tool family from the tool catalog entirely, set the",
        "  family block to `null` (it cannot be selected).",
    ),
)


__all__ = ("ROOT_DOC",)
