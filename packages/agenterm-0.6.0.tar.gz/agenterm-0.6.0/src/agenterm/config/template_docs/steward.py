"""Steward section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc

SECTION_DOC = SectionDoc(
    lines=(
        "==============================================================================",
        "STEWARD - Snapshot agent and task policy",
        "==============================================================================",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "steward.agent": FieldDoc(
        before=(
            "Steward agent configuration (used for snapshot tasks).",
            "Defaults to the bundled/local/global steward agent when fields are null.",
        ),
    ),
    "steward.agent.name": FieldDoc(
        inline='e.g. "steward"',
    ),
    "steward.agent.model": FieldDoc(
        before=(
            "Optional model override for Steward tasks.",
            "Null uses agent.model.",
        ),
        inline='e.g. "openai/gpt-5.2-pro"',
    ),
    "steward.agent.truncation": FieldDoc(
        before=(
            "Truncation mode for Steward snapshot tasks.",
            "Must be disabled (auto can silently truncate snapshot input).",
        ),
        inline="disabled",
    ),
    "steward.agent.max_output_tokens": FieldDoc(
        before=(
            "Output-token cap for Steward tasks.",
            "Default: 8192 (set null to mirror model.max_output_tokens).",
        ),
        inline="e.g. 4096",
    ),
    "steward.agent.instructions": FieldDoc(
        before=("Inline Steward instructions (mutually exclusive with path/source).",),
    ),
    "steward.agent.path": FieldDoc(
        before=(
            "Path to a Steward agent file (mutually exclusive with",
            "instructions/source).",
        ),
    ),
    "steward.agent.source": FieldDoc(
        before=(
            "Agent file name to resolve (mutually exclusive with instructions/path).",
        ),
    ),
    "steward.tasks": FieldDoc(
        before=("Steward task scheduling policy.",),
    ),
    "steward.tasks.max_pending": FieldDoc(
        before=("Maximum queued Steward tasks per session/branch.",),
        inline="e.g. 1",
    ),
    "steward.tasks.running_stale_seconds": FieldDoc(
        before=(
            "Auto-cancel stale running Steward tasks before queue-limit checks.",
            "Set null to disable stale-running eviction.",
        ),
        inline="e.g. 900",
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
