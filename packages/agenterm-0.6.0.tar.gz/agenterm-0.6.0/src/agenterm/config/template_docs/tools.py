"""Tools section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc, format_choices
from agenterm.core.choices.image_generation import (
    IMAGE_BACKGROUNDS,
    IMAGE_INPUT_FIDELITIES,
    IMAGE_MODERATIONS,
    IMAGE_OUTPUT_FORMATS,
    IMAGE_QUALITIES,
    IMAGE_SIZES,
)
from agenterm.core.choices.tools import SANDBOX_NETWORKS, SEARCH_CONTEXT_SIZES

SECTION_DOC = SectionDoc(
    lines=(
        "======================================================================",
        "TOOLS - Built-in and hosted tools configuration",
        "======================================================================",
    ),
)

FIELD_DOCS: dict[str, FieldDoc] = {
    "tools.max_chars": FieldDoc(
        before=("Tool output budget (shared)",),
        inline="Max serialized tool output length (chars; unified clamp)",
    ),
    "tools.file_search": FieldDoc(before=("File Search (vector store retrieval)",)),
    "tools.file_search.vector_store_ids": FieldDoc(
        inline="Required to actually use file_search",
    ),
    "tools.file_search.max_num_results": FieldDoc(inline="Results per query"),
    "tools.file_search.include_search_results": FieldDoc(
        inline="Include matched chunks in response",
    ),
    "tools.file_search.filters": FieldDoc(
        inline="Advanced: metadata filters (JSONValue mapping)",
    ),
    "tools.file_search.ranking_options": FieldDoc(
        inline="Advanced: ranking customization (JSONValue mapping)",
    ),
    "tools.web_search": FieldDoc(before=("Web Search",)),
    "tools.web_search.search_context_size": FieldDoc(
        inline=format_choices(SEARCH_CONTEXT_SIZES),
    ),
    "tools.web_search.user_location": FieldDoc(
        before=(
            "Optional approximate user location; forwarded to the tool as-is.",
            "Common keys: type=approximate, country, city, region, timezone.",
        ),
    ),
    "tools.web_search.user_location.type": FieldDoc(inline="approximate"),
    "tools.web_search.user_location.country": FieldDoc(
        inline="ISO country code for localized results",
    ),
    "tools.web_search.filters": FieldDoc(
        inline="Advanced: domain/date filters (JSONValue mapping)",
    ),
    "tools.shell": FieldDoc(
        before=(
            "Shell (local command execution in OS sandbox backend; macOS + Linux)",
        ),
    ),
    "tools.shell.timeout_ms": FieldDoc(inline="Per-command timeout"),
    "tools.shell.max_chars": FieldDoc(inline="Truncate output beyond this (chars)"),
    "tools.shell.working_dir": FieldDoc(inline="Override cwd for shell commands"),
    "tools.shell.env": FieldDoc(
        before=(
            "Environment variables for shell commands. Defaults include",
            "UV_CACHE_DIR=.uv-cache to keep uv cache inside the workspace.",
            "Set to null to use only safe defaults (PATH, HOME, SHELL, etc.).",
            "Custom vars are merged with defaults.",
            "env:",
            "  UV_CACHE_DIR: .uv-cache",
            "  CUSTOM_VAR: value",
        ),
    ),
    "tools.shell.env.UV_CACHE_DIR": FieldDoc(
        inline="uv cache directory (workspace-relative by default)",
    ),
    "tools.shell.sandbox": FieldDoc(
        before=(
            "Sandbox configuration for shell backends (Seatbelt on macOS,",
            "bubblewrap on Linux). Unsupported platforms omit the shell tool.",
        ),
    ),
    "tools.shell.sandbox.network": FieldDoc(
        inline=f"{format_choices(SANDBOX_NETWORKS)} (network access for commands)",
    ),
    "tools.apply_patch": FieldDoc(
        before=(
            "Apply Patch (file editing)",
            "",
            "The apply_patch tool is implemented by a workspace-scoped executor; it",
            "refuses to operate on paths outside the workspace root (cwd where",
            "`agenterm` launched), including symlink escapes. This works on both",
            "Linux and macOS. Per-operation errors use conflict/invalid_input/",
            "policy_denied/internal_error with reason details.",
        ),
    ),
    "tools.inspect": FieldDoc(
        before=(
            "Inspect (read-only inspection ingress).",
            "",
            "Runs semantic inspection operations (search_text/find_paths/read_file/",
            "list_tree/path_stats/runtime_info) in one request.",
            "Each request uses request_id as string|null and echoes it in responses.",
            "Execution may run concurrently,",
            "but concurrency is an implementation detail.",
        ),
    ),
    "tools.inspect.max_operations": FieldDoc(
        inline="Max operations per inspect invocation",
    ),
    "tools.inspect.max_concurrency": FieldDoc(
        inline="Max concurrent inspect operations",
    ),
    "tools.agent_run": FieldDoc(
        before=(
            "Agent Run (safe, ephemeral delegation).",
            "",
            "Tool input is a flat payload with nullable mode-specific fields.",
            "Supports two ops:",
            "  - `run` for one-shot delegated execution with explicit model +",
            "    instructions + input.",
            "  - `discover_models` for delegated-model catalog discovery.",
        ),
    ),
    "tools.agent_run.bundle": FieldDoc(
        inline="Delegate bundle name (delegate-scope only; default: openai)",
    ),
    "tools.agent_run_report": FieldDoc(
        before=(
            "Agent Run Report (safe, read-only).",
            "",
            "Tool input is a flat payload: report_id + nullable mode.",
            "Retrieves a stored agent_run report by report_id.",
        ),
    ),
    "tools.image_generation": FieldDoc(before=("Image Generation (hosted)",)),
    "tools.image_generation.model": FieldDoc(
        inline="Set null to let the platform pick a default model",
    ),
    "tools.image_generation.background": FieldDoc(
        inline=format_choices(IMAGE_BACKGROUNDS),
    ),
    "tools.image_generation.input_fidelity": FieldDoc(
        inline=format_choices(IMAGE_INPUT_FIDELITIES),
    ),
    "tools.image_generation.moderation": FieldDoc(
        inline=format_choices(IMAGE_MODERATIONS),
    ),
    "tools.image_generation.output_compression": FieldDoc(
        inline="int (0-100 for jpeg/webp)",
    ),
    "tools.image_generation.output_format": FieldDoc(
        inline=format_choices(IMAGE_OUTPUT_FORMATS),
    ),
    "tools.image_generation.partial_images": FieldDoc(inline="int"),
    "tools.image_generation.quality": FieldDoc(inline=format_choices(IMAGE_QUALITIES)),
    "tools.image_generation.size": FieldDoc(inline=format_choices(IMAGE_SIZES)),
    "tools.image_generation.input_image_mask": FieldDoc(
        inline="Advanced: forwarded JSONValue mapping",
    ),
    "tools.plan": FieldDoc(
        before=(
            "Plan (local, safe by default)",
            "",
            "Tool input is a flat payload with op + nullable per-op fields.",
            "Nested placement/patch inputs are also flat strict objects",
            "with discriminators plus nullable fields.",
            "Single plan tool with incremental ops (`get`, `set`, `add`, `update`,",
            "`delete`, `advance`, `reset`). Mutating ops persist plan snapshots and",
            "the CLI",
            "renders the plan block from the persisted snapshot. Steps carry stable",
            "`step_id` values; missing ids are assigned deterministically. String",
            "ids/step text must contain at least one non-whitespace character.",
        ),
    ),
    "tools.function_tools": FieldDoc(
        before=(
            "Function Tools (client; user-defined FunctionTools)",
            "",
            "The actual Python callables are registered in code",
            "(see core.function_tools).",
            "Example:",
            "  - name: my_custom_tool",
        ),
    ),
    "tools.bundles": FieldDoc(
        before=(
            "Tool Bundles (named tool groups for config selection and /tools).",
            "Bundle fields:",
            "  bundles: list of bundle names to include",
            "  tools: list of explicit tool keys",
            "  selectors: prefix patterns (mcp:*, hosted:mcp:*, fn:user:*)",
            "  scope: main | delegate",
        ),
    ),
    "tools.bundles.agenterm": FieldDoc(
        inline="All main-scope bundles (default)",
    ),
    "tools.bundles.inspect": FieldDoc(
        inline="Local inspection tool (inspect)",
    ),
    "tools.bundles.plan": FieldDoc(inline="Plan tool (plan)"),
    "tools.bundles.subagents": FieldDoc(
        inline="Sub-agent tools (agent_run + agent_run_report + steward)",
    ),
    "tools.bundles.edit": FieldDoc(inline="Workspace edits (apply_patch)"),
    "tools.bundles.shell": FieldDoc(inline="Shell tool (sandboxed; macOS + Linux)"),
    "tools.bundles.integrations": FieldDoc(
        inline="MCP selectors (mcp:* + hosted:mcp:*)",
    ),
    "tools.bundles.extensions": FieldDoc(
        inline="User FunctionTools selector (fn:user:*)",
    ),
    "tools.bundles.openai": FieldDoc(
        inline="OpenAI hosted tools (web_search / file_search / image_generation)",
    ),
    "tools.default_bundles": FieldDoc(inline="Main-scope bundles active by default"),
    "tools.dangerous": FieldDoc(
        before=(
            "Dangerous tool overrides (tool refs).",
            "Defaults follow policy; overrides apply after defaults.",
        ),
    ),
    "tools.dangerous.add": FieldDoc(
        inline="Force-mark tool refs as dangerous",
    ),
    "tools.dangerous.remove": FieldDoc(
        inline="Force-mark tool refs as safe",
    ),
}

for name in (
    "agenterm",
    "inspect",
    "plan",
    "subagents",
    "edit",
    "shell",
    "integrations",
    "extensions",
    "openai",
):
    FIELD_DOCS[f"tools.bundles.{name}.bundles"] = FieldDoc(
        inline="Bundle names to include in this bundle",
    )
    FIELD_DOCS[f"tools.bundles.{name}.tools"] = FieldDoc(
        inline="Explicit tool keys for this bundle",
    )
    FIELD_DOCS[f"tools.bundles.{name}.selectors"] = FieldDoc(
        inline="Selector prefixes (mcp:*, hosted:mcp:*, fn:user:*)",
    )
    FIELD_DOCS[f"tools.bundles.{name}.scope"] = FieldDoc(
        inline="Bundle scope (main or delegate)",
    )

__all__ = ("FIELD_DOCS", "SECTION_DOC")
