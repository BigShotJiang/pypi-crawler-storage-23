"""Compression section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc

SECTION_DOC = SectionDoc(
    lines=(
        "==============================================================================",
        "COMPRESSION - Pre-run history compression policy",
        "==============================================================================",
    ),
)

FIELD_DOCS: dict[str, FieldDoc] = {
    "compression.strategy": FieldDoc(
        inline=(
            "snapshot | compaction_if_supported | both_if_supported "
            "(compaction requires provider capability)"
        ),
    ),
    "compression.trigger": FieldDoc(
        inline="ask | auto (ask prompts only when interactive; otherwise deny)",
    ),
    "compression.threshold_percent": FieldDoc(
        inline="Percent of context_window to trigger compression (0 < x <= 1).",
    ),
    "compression.primary_branch": FieldDoc(
        inline="snapshot | compaction (only when strategy=both_if_supported)",
    ),
    "compression.drop_policy": FieldDoc(
        inline="ask | deny | allow (controls last-resort turn dropping)",
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
