"""REPL section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc, format_choices
from agenterm.core.choices.approvals import APPROVAL_MODES
from agenterm.core.choices.repl import (
    REPL_DIFFS_MODES,
    REPL_REASONING_MODES,
    REPL_STREAM_MODES,
    REPL_VERBOSITIES,
)
from agenterm.core.choices.repl_ui import (
    REPL_COLOR_DEPTHS,
    REPL_COMPLETION_MODES,
    REPL_EDITING_MODES,
    REPL_THEMES,
)

SECTION_DOC = SectionDoc(
    lines=(
        "=============================================================================",
        "REPL - Interactive UX defaults (does not affect `agenterm run`)",
        "=============================================================================",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "repl.approvals": FieldDoc(before=("Approvals policy",)),
    "repl.approvals.mode": FieldDoc(inline=format_choices(APPROVAL_MODES)),
    "repl.ui": FieldDoc(before=("Prompt UI controls",)),
    "repl.ui.theme": FieldDoc(inline=format_choices(REPL_THEMES)),
    "repl.ui.color_depth": FieldDoc(
        inline=(
            f"{format_choices(REPL_COLOR_DEPTHS)}; "
            "auto selects the highest supported depth "
            "(truecolor on Apple Terminal/iTerm2)"
        ),
    ),
    "repl.ui.editing_mode": FieldDoc(inline=format_choices(REPL_EDITING_MODES)),
    "repl.ui.mouse": FieldDoc(inline="prompt UI mouse support (default on)"),
    "repl.ui.completion": FieldDoc(
        inline=(
            f"{format_choices(REPL_COMPLETION_MODES)} "
            "(commands on Tab only, or commands + history suggestions)"
        ),
    ),
    "repl.ui.max_transcript_entries": FieldDoc(
        inline=(
            "Max transcript entries retained in the TUI "
            "(0 keeps only the truncation marker)"
        ),
    ),
    "repl.ux": FieldDoc(before=("REPL UX controls",)),
    "repl.ux.markdown": FieldDoc(
        inline="Render agent output as Rich Markdown (default on)",
    ),
    "repl.ux.reasoning": FieldDoc(inline=format_choices(REPL_REASONING_MODES)),
    "repl.ux.reasoning_summary_max_chars": FieldDoc(
        inline="0 = no limit; >0 truncates reasoning summary text",
    ),
    "repl.ux.diffs": FieldDoc(inline=format_choices(REPL_DIFFS_MODES)),
    "repl.ux.stream": FieldDoc(inline=format_choices(REPL_STREAM_MODES)),
    "repl.ux.verbosity": FieldDoc(inline=format_choices(REPL_VERBOSITIES)),
    "repl.transcript": FieldDoc(before=("Transcript boundedness",)),
    "repl.transcript.tool_output_max_lines": FieldDoc(
        inline="Max lines for tool output summaries",
    ),
    "repl.transcript.shell_preview_max_chars": FieldDoc(
        inline="Max chars for shell stdout/stderr previews",
    ),
    "repl.transcript.tool_detail_max_lines": FieldDoc(
        inline="Max lines for tool detail blocks",
    ),
    "repl.transcript.tool_detail_max_chars": FieldDoc(
        inline="Max chars per tool detail line",
    ),
    "repl.transcript.mcp_args_preview_max_chars": FieldDoc(
        inline="Max chars for MCP args previews",
    ),
    "repl.transcript.attachments_max_lines": FieldDoc(
        inline="Max lines for attachments-used blocks",
    ),
    "repl.transcript.attachments_path_max_chars": FieldDoc(
        inline="Max chars per attachment path preview",
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
