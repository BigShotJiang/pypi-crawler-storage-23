"""Guardrails section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc

SECTION_DOC = SectionDoc(
    lines=(
        "==============================================================================",
        "GUARDRAILS - Input/output validation",
        "==============================================================================",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "guardrails.load_modules": FieldDoc(
        inline="Optional modules to import for registration",
    ),
    "guardrails.input": FieldDoc(
        inline="Guardrail names from core.guardrails_registry",
    ),
    "guardrails.output": FieldDoc(inline="Output guardrail names"),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
