"""Attachments section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc

SECTION_DOC = SectionDoc(
    lines=(
        "==============================================================================",
        "ATTACHMENTS - Local file/URL ingestion policy",
        "==============================================================================",
    ),
)

FIELD_DOCS: dict[str, FieldDoc] = {
    "attachments.image_input_mode": FieldDoc(
        inline="file_id_or_url_only | allow_inline_data_url",
    ),
    "attachments.allow_inline_data_url": FieldDoc(
        inline="Allow inline data URLs for explicit attachments (default false).",
    ),
    "attachments.max_inline_bytes": FieldDoc(
        inline="Max inline bytes when inline data URLs are allowed (0 disables).",
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
