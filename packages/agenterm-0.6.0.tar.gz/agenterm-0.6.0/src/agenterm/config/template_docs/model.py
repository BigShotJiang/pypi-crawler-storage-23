"""Model section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc, format_choices
from agenterm.core.choices.model import (
    MODEL_TRUNCATIONS,
    MODEL_VERBOSITIES,
    PROMPT_CACHE_RETENTIONS,
    REASONING_EFFORTS,
    REASONING_SUMMARIES,
)

SECTION_DOC = SectionDoc(
    lines=(
        "=============================================================================",
        "MODEL - Sampling, reasoning, output format, and API behavior",
        "=============================================================================",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "model.temperature": FieldDoc(
        before=("Sampling parameters",),
        inline="0.0 = deterministic, 2.0 = max randomness",
    ),
    "model.top_p": FieldDoc(inline="Nucleus sampling (alternative to temperature)"),
    "model.frequency_penalty": FieldDoc(
        inline="-2.0 to 2.0, penalize frequent tokens",
    ),
    "model.presence_penalty": FieldDoc(
        inline="-2.0 to 2.0, penalize tokens that appear",
    ),
    "model.max_output_tokens": FieldDoc(
        before=("Output limits",),
        inline="Max output tokens (visible + reasoning)",
    ),
    "model.truncation": FieldDoc(inline=format_choices(MODEL_TRUNCATIONS)),
    "model.reasoning": FieldDoc(
        before=(
            "Reasoning (extended thinking).",
            "Defaults to xhigh effort for GPT-5 models;",
            "defaults to auto summaries for GPT-5 models;",
            "OpenAI non-GPT-5 models require reasoning to be null.",
            "Gateway routes map reasoning by protocol (Responses vs LiteLLM).",
        ),
    ),
    "model.reasoning.effort": FieldDoc(inline=format_choices(REASONING_EFFORTS)),
    "model.reasoning.summary": FieldDoc(inline=format_choices(REASONING_SUMMARIES)),
    "model.verbosity": FieldDoc(
        before=("Verbosity (output detail level)",),
        inline=format_choices(MODEL_VERBOSITIES),
    ),
    "model.store": FieldDoc(
        before=("Provider storage (responses)",),
        inline=(
            "Default: false. Store responses for retrieval/inspection "
            "(no effect on local replay)"
        ),
    ),
    "model.context_window": FieldDoc(
        before=("Context window (local-only; for packing + UI)",),
        inline=(
            "Default: 200000 tokens; fallback: 128k tokens (~450k chars) when null; "
            "set from model docs; not exposed by /models API; "
            "also used as the default compression threshold reference"
        ),
    ),
    "model.prompt_cache_retention": FieldDoc(
        inline=format_choices(PROMPT_CACHE_RETENTIONS),
    ),
    "model.include_usage": FieldDoc(
        before=("Usage and debugging",),
        inline="Include token counts in response",
    ),
    "model.top_logprobs": FieldDoc(
        inline="Return top N logprobs per token (debugging)",
    ),
    "model.tool_choice": FieldDoc(
        before=("Tool selection",),
        inline="auto | none | required | function:<NAME>",
    ),
    "model.text_format": FieldDoc(
        before=(
            "Structured output (Responses text.format)",
            "Exactly one of `text_format` or `text_format_file` may be set.",
            "Schemas are normalized to strict mode (additionalProperties: false).",
            "Example (inline JSON schema):",
            "text_format:",
            "  type: json_schema",
            "  name: answer_schema",
            "  schema:",
            '    type: "object"',
            "    properties:",
            "      summary: { type: string }",
            "      confidence: { type: number }",
            '    required: ["summary", "confidence"]',
            "    additionalProperties: false",
            "  strict: true",
            "",
            "Example (load from file):",
            "text_format_file: examples/structured/answer_schema.yaml",
        ),
    ),
    "model.text_format_file": FieldDoc(
        inline="Path to JSON/YAML schema file",
    ),
    "model.metadata": FieldDoc(
        before=("Request customization (advanced)",),
        inline="Mapping[str, str]",
    ),
    "model.extra_headers": FieldDoc(inline="Mapping[str, str]"),
    "model.extra_query": FieldDoc(inline="Mapping[str, JSONValue]"),
    "model.extra_body": FieldDoc(inline="Mapping[str, JSONValue]"),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
