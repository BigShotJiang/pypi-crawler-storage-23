"""Documentation primitives for the config template generator."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence


@dataclass(frozen=True)
class FieldDoc:
    """Comment metadata for a single config field."""

    before: tuple[str, ...] | None = None
    inline: str | None = None


@dataclass(frozen=True)
class SectionDoc:
    """Comment block for a top-level config section."""

    lines: tuple[str, ...]


@dataclass(frozen=True)
class RootDoc:
    """Comment block emitted before the first key."""

    lines: tuple[str, ...]


def format_choices(values: Sequence[str]) -> str:
    """Return a stable, readable choice list string."""
    return " | ".join(values)


def merge_field_docs(*doc_sets: Mapping[str, FieldDoc]) -> dict[str, FieldDoc]:
    """Merge FieldDoc mappings while rejecting duplicate keys."""
    merged: dict[str, FieldDoc] = {}
    for doc_set in doc_sets:
        for key, doc in doc_set.items():
            if key in merged:
                msg = f"Duplicate FieldDoc for {key}"
                raise ConfigError(msg)
            merged[key] = doc
    return merged


def merge_section_docs(*doc_sets: Mapping[str, SectionDoc]) -> dict[str, SectionDoc]:
    """Merge SectionDoc mappings while rejecting duplicate keys."""
    merged: dict[str, SectionDoc] = {}
    for doc_set in doc_sets:
        for key, doc in doc_set.items():
            if key in merged:
                msg = f"Duplicate SectionDoc for {key}"
                raise ConfigError(msg)
            merged[key] = doc
    return merged


def merge_root_docs(*docs: RootDoc) -> RootDoc:
    """Merge RootDoc blocks into a single doc."""
    lines: list[str] = []
    for doc in docs:
        if lines:
            lines.append("")
        lines.extend(doc.lines)
    return RootDoc(lines=tuple(lines))


__all__ = (
    "FieldDoc",
    "RootDoc",
    "SectionDoc",
    "format_choices",
    "merge_field_docs",
    "merge_root_docs",
    "merge_section_docs",
)
