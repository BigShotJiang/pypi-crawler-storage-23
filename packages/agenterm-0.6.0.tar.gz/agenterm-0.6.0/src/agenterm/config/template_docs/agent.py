"""Agent section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc
from agenterm.constants.limits import AGENT_MAX_TURNS_MAX, AGENT_MAX_TURNS_MIN

SECTION_DOC = SectionDoc(
    lines=(
        "==============================================================================",
        "AGENT - Core agent identity and limits",
        "==============================================================================",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "agent.name": FieldDoc(
        before=(
            "Agent name (instruction file name). Agents resolve in order:",
            "  1) ./.agenterm/agents/<name>.md (project-local override)",
            "  2) ~/.agenterm/agents/<name>.md (global override)",
            "  3) bundled src/agenterm/data/agents/<name>.md",
        ),
    ),
    "agent.model": FieldDoc(
        inline="Model ID (openai/<model> or gateway/<route>/<model>)",
    ),
    "agent.max_turns": FieldDoc(
        inline=(
            "SDK turn limit per run (safety cap; "
            f"{AGENT_MAX_TURNS_MIN}-{AGENT_MAX_TURNS_MAX})"
        ),
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
