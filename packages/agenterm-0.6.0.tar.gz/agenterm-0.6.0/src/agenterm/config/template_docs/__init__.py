"""Documentation registry for config template generation."""

from __future__ import annotations

from agenterm.config.template_docs.agent import FIELD_DOCS as AGENT_FIELDS
from agenterm.config.template_docs.agent import SECTION_DOC as AGENT_SECTION
from agenterm.config.template_docs.attachments import FIELD_DOCS as ATTACHMENTS_FIELDS
from agenterm.config.template_docs.attachments import SECTION_DOC as ATTACHMENTS_SECTION
from agenterm.config.template_docs.base import (
    FieldDoc,
    RootDoc,
    SectionDoc,
    merge_field_docs,
    merge_root_docs,
    merge_section_docs,
)
from agenterm.config.template_docs.compression import FIELD_DOCS as COMPRESSION_FIELDS
from agenterm.config.template_docs.compression import SECTION_DOC as COMPRESSION_SECTION
from agenterm.config.template_docs.guardrails import FIELD_DOCS as GUARDRAILS_FIELDS
from agenterm.config.template_docs.guardrails import SECTION_DOC as GUARDRAILS_SECTION
from agenterm.config.template_docs.mcp import FIELD_DOCS as MCP_FIELDS
from agenterm.config.template_docs.mcp import SECTION_DOC as MCP_SECTION
from agenterm.config.template_docs.model import FIELD_DOCS as MODEL_FIELDS
from agenterm.config.template_docs.model import SECTION_DOC as MODEL_SECTION
from agenterm.config.template_docs.providers import FIELD_DOCS as PROVIDERS_FIELDS
from agenterm.config.template_docs.providers import SECTION_DOC as PROVIDERS_SECTION
from agenterm.config.template_docs.repl import FIELD_DOCS as REPL_FIELDS
from agenterm.config.template_docs.repl import SECTION_DOC as REPL_SECTION
from agenterm.config.template_docs.retries import FIELD_DOCS as RETRIES_FIELDS
from agenterm.config.template_docs.retries import SECTION_DOC as RETRIES_SECTION
from agenterm.config.template_docs.root import ROOT_DOC as ROOT
from agenterm.config.template_docs.run import FIELD_DOCS as RUN_FIELDS
from agenterm.config.template_docs.run import SECTION_DOC as RUN_SECTION
from agenterm.config.template_docs.steward import FIELD_DOCS as STEWARD_FIELDS
from agenterm.config.template_docs.steward import SECTION_DOC as STEWARD_SECTION
from agenterm.config.template_docs.tools import FIELD_DOCS as TOOLS_FIELDS
from agenterm.config.template_docs.tools import SECTION_DOC as TOOLS_SECTION

SECTION_ORDER: tuple[str, ...] = (
    "agent",
    "model",
    "providers",
    "retries",
    "compression",
    "attachments",
    "tools",
    "mcp",
    "steward",
    "run",
    "repl",
    "guardrails",
)

SECTION_DOCS: dict[str, SectionDoc] = merge_section_docs(
    {"agent": AGENT_SECTION},
    {"model": MODEL_SECTION},
    {"providers": PROVIDERS_SECTION},
    {"retries": RETRIES_SECTION},
    {"compression": COMPRESSION_SECTION},
    {"attachments": ATTACHMENTS_SECTION},
    {"steward": STEWARD_SECTION},
    {"run": RUN_SECTION},
    {"repl": REPL_SECTION},
    {"tools": TOOLS_SECTION},
    {"mcp": MCP_SECTION},
    {"guardrails": GUARDRAILS_SECTION},
)

FIELD_DOCS: dict[str, FieldDoc] = merge_field_docs(
    AGENT_FIELDS,
    MODEL_FIELDS,
    PROVIDERS_FIELDS,
    RETRIES_FIELDS,
    COMPRESSION_FIELDS,
    ATTACHMENTS_FIELDS,
    STEWARD_FIELDS,
    RUN_FIELDS,
    REPL_FIELDS,
    TOOLS_FIELDS,
    MCP_FIELDS,
    GUARDRAILS_FIELDS,
)

ROOT_DOC: RootDoc = merge_root_docs(ROOT)


__all__ = ("FIELD_DOCS", "ROOT_DOC", "SECTION_DOCS", "SECTION_ORDER")
