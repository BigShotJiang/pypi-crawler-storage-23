"""Schema-first validation for raw config payloads."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue

_JSON_PRIMITIVES = (str, int, float, bool, type(None))

type RawConfigValue = (
    str
    | int
    | float
    | bool
    | None
    | Sequence["RawConfigValue"]
    | Mapping[str | int | float | bool | None, "RawConfigValue"]
)


def _path_join(base: str, key: str) -> str:
    return f"{base}.{key}" if base else key


def _path_index(base: str, index: int) -> str:
    return f"{base}[{index}]"


def _validate_value(value: RawConfigValue, *, path: str) -> JSONValue:
    if isinstance(value, _JSON_PRIMITIVES):
        return value
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        out: list[JSONValue] = []
        for idx, item in enumerate(value):
            out.append(_validate_value(item, path=_path_index(path, idx)))
        return out
    if isinstance(value, Mapping):
        return _validate_object(value, path=path)
    msg = f"{path} must be JSON-compatible (got {type(value).__name__})"
    raise ConfigError(msg)


def _validate_object(
    raw: Mapping[str | int | float | bool | None, RawConfigValue],
    *,
    path: str,
) -> dict[str, JSONValue]:
    out: dict[str, JSONValue] = {}
    for key, value in raw.items():
        if not isinstance(key, str):
            msg = f"{path} keys must be strings (got {type(key).__name__})"
            raise ConfigError(msg)
        next_path = _path_join(path, key)
        out[key] = _validate_value(value, path=next_path)
    return out


def validate_raw_config(raw: RawConfigValue | None) -> dict[str, JSONValue]:
    """Validate the raw config payload is JSON-compatible and return a mapping.

    Raises ConfigError when the root is not an object or when any value is not
    JSON-compatible.
    """
    if raw is None:
        return {}
    if not isinstance(raw, Mapping):
        msg = "config root must be a mapping/object"
        raise ConfigError(msg)
    return _validate_object(raw, path="config")


__all__ = ("RawConfigValue", "validate_raw_config")
