"""Tool family configuration models."""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

    from agenterm.core.choices.image_generation import (
        ImageBackground,
        ImageInputFidelity,
        ImageModeration,
        ImageOutputFormat,
        ImageQuality,
        ImageSize,
    )
    from agenterm.core.choices.tools import SandboxNetwork, SearchContextSize
    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class FileSearchToolConfig:
    """Hosted file search tool configuration."""

    vector_store_ids: list[str] = field(default_factory=list)
    max_num_results: int | None = 5
    include_search_results: bool = True
    # Advanced options forwarded to the hosted file search tool.
    filters: Mapping[str, JSONValue] | None = None
    ranking_options: Mapping[str, JSONValue] | None = None


@dataclass(frozen=True)
class WebSearchToolConfig:
    """Hosted web search tool configuration."""

    search_context_size: SearchContextSize = "high"
    # Optional approximate user location; forwarded to the hosted web search
    # tool as-is. Shape should match the SDK's UserLocation TypedDict
    # (type="approximate", city|country|region|timezone), but we keep the
    # config surface JSON-typed.
    user_location: Mapping[str, JSONValue] | None = field(
        default_factory=lambda: MappingProxyType(
            {"type": "approximate", "country": "US"},
        ),
    )
    # Optional filters forwarded to the hosted web search tool. Shape should
    # match the SDK's WebSearchToolFilters / Filters types; we keep the config
    # surface JSON-typed to avoid mirroring the full schema.
    filters: Mapping[str, JSONValue] | None = None


@dataclass(frozen=True)
class ShellSandboxConfig:
    """Sandbox configuration for shell tool backends."""

    network: SandboxNetwork = "allow"


@dataclass(frozen=True)
class ShellToolConfig:
    """Local shell tool configuration (sandboxed execution)."""

    timeout_ms: int | None = 60000
    max_chars: int | None = 85000
    working_dir: Path | None = None
    env: Mapping[str, str] | None = field(
        default_factory=lambda: MappingProxyType({"UV_CACHE_DIR": ".uv-cache"})
    )
    sandbox: ShellSandboxConfig = field(default_factory=ShellSandboxConfig)


@dataclass(frozen=True)
class ApplyPatchToolConfig:
    """Local apply_patch tool configuration."""


@dataclass(frozen=True)
class ImageGenerationToolConfig:
    """Hosted image generation tool configuration."""

    # Image model for `image_generation`.
    #
    # Default is "gpt-image-1.5" (agenterm policy). Set to null to omit the `model`
    # field and let the platform pick its own default.
    model: str | None = "gpt-image-1.5"
    # Background treatment for generated images.
    background: ImageBackground | None = None
    # Fidelity of input conditioning when editing/transforming images.
    input_fidelity: ImageInputFidelity | None = "high"
    # Moderation posture for prompts/content.
    moderation: ImageModeration | None = "low"
    # Output compression level.
    output_compression: int | None = None
    # Output image format.
    output_format: ImageOutputFormat | None = "png"
    # Number of partial images to emit (streaming).
    partial_images: int | None = None
    # Overall quality tradeoff.
    quality: ImageQuality | None = "high"
    # Output size; see SDK docs for allowed combinations.
    size: ImageSize | None = None
    # Advanced input mask configuration; forwarded as-is to the SDK.
    input_image_mask: Mapping[str, JSONValue] | None = None


@dataclass(frozen=True)
class FunctionToolConfig:
    """Declarative function tool config (callable registered in code)."""

    name: str


__all__ = (
    "ApplyPatchToolConfig",
    "FileSearchToolConfig",
    "FunctionToolConfig",
    "ImageGenerationToolConfig",
    "ShellSandboxConfig",
    "ShellToolConfig",
    "WebSearchToolConfig",
)
