"""Steward configuration models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.core.choices.model import ModelTruncation


@dataclass(frozen=True)
class StewardAgentConfig:
    """Steward agent configuration for snapshot tasks."""

    name: str = "steward"
    model: str | None = None
    truncation: ModelTruncation | None = "disabled"
    max_output_tokens: int | None = 8192
    instructions: str | None = None
    path: Path | None = None
    source: str | None = None


@dataclass(frozen=True)
class StewardTasksConfig:
    """Steward task scheduling policy."""

    max_pending: int = 1
    running_stale_seconds: int | None = 900


@dataclass(frozen=True)
class StewardConfig:
    """Steward configuration (agent + task policy)."""

    agent: StewardAgentConfig = field(default_factory=StewardAgentConfig)
    tasks: StewardTasksConfig = field(default_factory=StewardTasksConfig)


__all__ = (
    "StewardAgentConfig",
    "StewardConfig",
    "StewardTasksConfig",
)
