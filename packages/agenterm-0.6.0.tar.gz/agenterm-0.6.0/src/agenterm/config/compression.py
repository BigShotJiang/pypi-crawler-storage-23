"""Compression configuration models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

type CompressionStrategy = Literal[
    "snapshot",
    "compaction_if_supported",
    "both_if_supported",
]
type CompressionTrigger = Literal["ask", "auto"]
type CompressionPrimaryBranch = Literal["snapshot", "compaction"]
type CompressionDropPolicy = Literal["ask", "deny", "allow"]


@dataclass(frozen=True)
class CompressionConfig:
    """Compression policy for long-running sessions."""

    strategy: CompressionStrategy = "snapshot"
    trigger: CompressionTrigger = "auto"
    threshold_percent: float = 0.5
    primary_branch: CompressionPrimaryBranch = "snapshot"
    drop_policy: CompressionDropPolicy = "deny"


__all__ = (
    "CompressionConfig",
    "CompressionDropPolicy",
    "CompressionPrimaryBranch",
    "CompressionStrategy",
    "CompressionTrigger",
)
