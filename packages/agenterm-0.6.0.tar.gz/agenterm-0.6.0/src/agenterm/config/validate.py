"""Cross-field validation for normalized config."""

from __future__ import annotations

import shutil
from typing import TYPE_CHECKING

from agenterm.config.tools_catalog import build_tool_catalog_from_config
from agenterm.constants.limits import (
    AGENT_MAX_TURNS_MAX,
    AGENT_MAX_TURNS_MIN,
    FILE_SEARCH_MAX_RESULTS_MAX,
    FILE_SEARCH_MAX_RESULTS_MIN,
    IMAGE_OUTPUT_COMPRESSION_MAX,
    IMAGE_OUTPUT_COMPRESSION_MIN,
    IMAGE_PARTIAL_IMAGES_MAX,
    IMAGE_PARTIAL_IMAGES_MIN,
    MCP_BRIDGE_MAX_CONTENT_ITEMS_MAX,
    MCP_BRIDGE_MAX_CONTENT_ITEMS_MIN,
    MCP_EXPOSE_PORT_MAX,
    MCP_EXPOSE_PORT_MIN,
    MODEL_MAX_OUTPUT_TOKENS_MIN,
    MODEL_PENALTY_MAX,
    MODEL_PENALTY_MIN,
    MODEL_TEMPERATURE_MAX,
    MODEL_TEMPERATURE_MIN,
    MODEL_TOP_LOGPROBS_MAX,
    MODEL_TOP_LOGPROBS_MIN,
    MODEL_TOP_P_MAX,
    MODEL_TOP_P_MIN,
    SHELL_OUTPUT_MAX_CHARS_MAX,
    SHELL_OUTPUT_MAX_CHARS_MIN,
    SHELL_TIMEOUT_MS_MAX,
    SHELL_TIMEOUT_MS_MIN,
    TOOL_OUTPUT_MAX_CHARS_MAX,
    TOOL_OUTPUT_MAX_CHARS_MIN,
)
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.config.model import McpServerConfig
from agenterm.config.normalize import NormalizedConfig, to_app_config
from agenterm.config.validate_retries import validate_retries_config


def validate_config(cfg: NormalizedConfig) -> None:
    """Raise ConfigError when cross-field constraints are violated."""
    _validate_agent(cfg)
    _validate_model(cfg)
    _validate_providers(cfg)
    validate_retries_config(cfg)
    _validate_compression(cfg)
    _validate_attachments(cfg)
    _validate_steward(cfg)
    _validate_tools(cfg)
    _validate_mcp(cfg)


def _validate_agent(cfg: NormalizedConfig) -> None:
    max_turns = int(cfg.agent.max_turns)
    if max_turns < AGENT_MAX_TURNS_MIN or max_turns > AGENT_MAX_TURNS_MAX:
        msg = (
            f"agent.max_turns must be between {AGENT_MAX_TURNS_MIN} and "
            f"{AGENT_MAX_TURNS_MAX}"
        )
        raise ConfigError(msg)


def _validate_optional_range(
    *,
    name: str,
    value: float | None,
    min_value: float,
    max_value: float,
) -> None:
    if value is None:
        return
    if value < min_value or value > max_value:
        msg = f"{name} must be between {min_value} and {max_value}"
        raise ConfigError(msg)


def _validate_model(cfg: NormalizedConfig) -> None:
    model = cfg.model
    _validate_optional_range(
        name="model.temperature",
        value=model.temperature,
        min_value=MODEL_TEMPERATURE_MIN,
        max_value=MODEL_TEMPERATURE_MAX,
    )
    _validate_optional_range(
        name="model.top_p",
        value=model.top_p,
        min_value=MODEL_TOP_P_MIN,
        max_value=MODEL_TOP_P_MAX,
    )
    _validate_optional_range(
        name="model.frequency_penalty",
        value=model.frequency_penalty,
        min_value=MODEL_PENALTY_MIN,
        max_value=MODEL_PENALTY_MAX,
    )
    _validate_optional_range(
        name="model.presence_penalty",
        value=model.presence_penalty,
        min_value=MODEL_PENALTY_MIN,
        max_value=MODEL_PENALTY_MAX,
    )
    if (
        model.max_output_tokens is not None
        and model.max_output_tokens < MODEL_MAX_OUTPUT_TOKENS_MIN
    ):
        msg = f"model.max_output_tokens must be >= {MODEL_MAX_OUTPUT_TOKENS_MIN}"
        raise ConfigError(msg)
    _validate_optional_range(
        name="model.top_logprobs",
        value=model.top_logprobs,
        min_value=MODEL_TOP_LOGPROBS_MIN,
        max_value=MODEL_TOP_LOGPROBS_MAX,
    )
    if model.extra_body is not None and "parallel_tool_calls" in model.extra_body:
        msg = (
            "model.extra_body.parallel_tool_calls is not supported; "
            "agenterm enforces provider parallel_tool_calls=false."
        )
        raise ConfigError(msg)
    if model.extra_query is not None and "parallel_tool_calls" in model.extra_query:
        msg = (
            "model.extra_query.parallel_tool_calls is not supported; "
            "agenterm enforces provider parallel_tool_calls=false."
        )
        raise ConfigError(msg)


def _validate_providers(cfg: NormalizedConfig) -> None:
    openai = cfg.providers.openai
    if not openai.allow_any_model and not openai.model_allowlist:
        msg = "providers.openai must set model_allowlist or allow_any_model=true"
        raise ConfigError(msg)
    for route_name, route in cfg.providers.gateway.routes.items():
        if not route.allow_any_model and not route.model_allowlist:
            msg = (
                f"providers.gateway.routes.{route_name} must set model_allowlist "
                "or allow_any_model=true"
            )
            raise ConfigError(msg)
        if route.supports_background and route.protocol != "openai_responses":
            msg = (
                f"providers.gateway.routes.{route_name}.supports_background=true "
                "requires protocol=openai_responses"
            )
            raise ConfigError(msg)
        if route.retry_max_retries is not None and route.retry_max_retries < 0:
            msg = (
                f"providers.gateway.routes.{route_name}.retry_max_retries must be "
                ">= 0 or null"
            )
            raise ConfigError(msg)
        if (
            route.retry_max_total_attempts is not None
            and route.retry_max_total_attempts < 1
        ):
            msg = (
                "providers.gateway.routes."
                f"{route_name}.retry_max_total_attempts must be >= 1 or null"
            )
            raise ConfigError(msg)
        if (
            route.retry_deadline_seconds is not None
            and route.retry_deadline_seconds <= 0
        ):
            msg = (
                f"providers.gateway.routes.{route_name}.retry_deadline_seconds "
                "must be > 0 or null"
            )
            raise ConfigError(msg)
        if (
            route.retry_attempt_timeout_seconds is not None
            and route.retry_attempt_timeout_seconds <= 0
        ):
            msg = (
                "providers.gateway.routes."
                f"{route_name}.retry_attempt_timeout_seconds must be > 0 or null"
            )
            raise ConfigError(msg)


def _validate_compression(cfg: NormalizedConfig) -> None:
    threshold_percent = cfg.compression.threshold_percent
    if threshold_percent <= 0 or threshold_percent > 1:
        msg = "compression.threshold_percent must be in (0, 1]"
        raise ConfigError(msg)


def _validate_attachments(cfg: NormalizedConfig) -> None:
    if cfg.attachments.allow_inline_data_url and cfg.attachments.max_inline_bytes <= 0:
        msg = (
            "attachments.max_inline_bytes must be > 0 when inline data URLs are allowed"
        )
        raise ConfigError(msg)


def _validate_steward(cfg: NormalizedConfig) -> None:
    if cfg.steward.tasks.max_pending < 1:
        msg = "steward.tasks.max_pending must be a positive integer"
        raise ConfigError(msg)
    stale_seconds = cfg.steward.tasks.running_stale_seconds
    if stale_seconds is not None and stale_seconds < 1:
        msg = "steward.tasks.running_stale_seconds must be a positive integer or null"
        raise ConfigError(msg)
    if cfg.steward.agent.truncation == "auto":
        msg = (
            "steward.agent.truncation=auto is not supported for snapshot tasks. "
            "It can silently truncate the Steward snapshot input and produce an "
            "incorrect continuation state. Set steward.agent.truncation=disabled."
        )
        raise ConfigError(msg)
    max_output_tokens = cfg.steward.agent.max_output_tokens
    if (
        max_output_tokens is not None
        and max_output_tokens < MODEL_MAX_OUTPUT_TOKENS_MIN
    ):
        msg = (
            f"steward.agent.max_output_tokens must be >= {MODEL_MAX_OUTPUT_TOKENS_MIN}"
        )
        raise ConfigError(msg)


def _validate_tool_bundles(cfg: NormalizedConfig) -> None:
    bundles_cfg = cfg.tools.bundles
    for name, bundle in bundles_cfg.items():
        if bundle.bundles or bundle.tools or bundle.selectors:
            continue
        msg = f"tools.bundles.{name} must include bundles, tools, or selectors"
        raise ConfigError(msg)


def _validate_default_bundles(cfg: NormalizedConfig) -> None:
    if not cfg.tools.default_bundles:
        return
    bundles_cfg = cfg.tools.bundles
    bundle_keys = set(bundles_cfg.keys())
    for name in cfg.tools.default_bundles:
        if name not in bundle_keys:
            message = f"tools.default_bundles references unknown bundle '{name}'"
            raise ConfigError(message)
        if bundles_cfg[name].scope != "main":
            msg = f"tools.default_bundles may only reference main-scope bundles: {name}"
            raise ConfigError(msg)


def _validate_agent_run_bundle(cfg: NormalizedConfig) -> None:
    agent_run = cfg.tools.agent_run
    if agent_run is None:
        return
    bundles_cfg = cfg.tools.bundles
    bundle_name = agent_run.bundle
    if bundle_name not in bundles_cfg:
        msg = f"tools.agent_run.bundle references unknown bundle '{bundle_name}'"
        raise ConfigError(msg)
    if bundles_cfg[bundle_name].scope != "delegate":
        msg = (
            "tools.agent_run.bundle must reference a delegate-scope bundle: "
            f"{bundle_name}"
        )
        raise ConfigError(msg)


def _validate_tool_output_limits(cfg: NormalizedConfig) -> None:
    max_chars = cfg.tools.max_chars
    if max_chars < TOOL_OUTPUT_MAX_CHARS_MIN or max_chars > TOOL_OUTPUT_MAX_CHARS_MAX:
        msg = (
            "tools.max_chars must be between "
            f"{TOOL_OUTPUT_MAX_CHARS_MIN} and {TOOL_OUTPUT_MAX_CHARS_MAX}"
        )
        raise ConfigError(msg)


def _validate_file_search_limits(cfg: NormalizedConfig) -> None:
    file_search = cfg.tools.file_search
    if file_search is None:
        return
    _validate_optional_range(
        name="tools.file_search.max_num_results",
        value=file_search.max_num_results,
        min_value=FILE_SEARCH_MAX_RESULTS_MIN,
        max_value=FILE_SEARCH_MAX_RESULTS_MAX,
    )


def _validate_image_generation_limits(cfg: NormalizedConfig) -> None:
    image = cfg.tools.image_generation
    if image is None:
        return
    _validate_optional_range(
        name="tools.image_generation.output_compression",
        value=image.output_compression,
        min_value=IMAGE_OUTPUT_COMPRESSION_MIN,
        max_value=IMAGE_OUTPUT_COMPRESSION_MAX,
    )
    _validate_optional_range(
        name="tools.image_generation.partial_images",
        value=image.partial_images,
        min_value=IMAGE_PARTIAL_IMAGES_MIN,
        max_value=IMAGE_PARTIAL_IMAGES_MAX,
    )


def _validate_shell_limits(cfg: NormalizedConfig) -> None:
    shell = cfg.tools.shell
    if shell is None:
        return
    _validate_optional_range(
        name="tools.shell.timeout_ms",
        value=shell.timeout_ms,
        min_value=SHELL_TIMEOUT_MS_MIN,
        max_value=SHELL_TIMEOUT_MS_MAX,
    )
    _validate_optional_range(
        name="tools.shell.max_chars",
        value=shell.max_chars,
        min_value=SHELL_OUTPUT_MAX_CHARS_MIN,
        max_value=SHELL_OUTPUT_MAX_CHARS_MAX,
    )


def _validate_tools(cfg: NormalizedConfig) -> None:
    _validate_tool_bundles(cfg)
    _validate_default_bundles(cfg)
    _validate_agent_run_bundle(cfg)
    _validate_tool_output_limits(cfg)
    _validate_file_search_limits(cfg)
    _validate_image_generation_limits(cfg)
    _validate_shell_limits(cfg)

    _validate_local_tool_binaries(cfg)


def _validate_local_tool_binaries(cfg: NormalizedConfig) -> None:
    if cfg.tools.inspect is None:
        return
    missing: list[str] = []
    if shutil.which("rg") is None:
        missing.append("rg")
    if shutil.which("fd") is None:
        missing.append("fd")
    if shutil.which("bat") is None:
        missing.append("bat")
    if shutil.which("tree") is None:
        missing.append("tree")
    if shutil.which("stat") is None:
        missing.append("stat")
    if not missing:
        return
    bins = ", ".join(missing)
    msg = (
        f"Missing required CLI tools: {bins}. Install with "
        "`brew install ripgrep fd bat tree` (plus coreutils if stat is missing) "
        "or your system package manager."
    )
    raise ConfigError(msg)


def _validate_mcp_servers(cfg: NormalizedConfig) -> None:
    seen_keys: set[str] = set()
    for server in cfg.mcp.servers:
        if server.key in seen_keys:
            message = f"duplicate mcp server key: {server.key}"
            raise ConfigError(message)
        seen_keys.add(server.key)
        _validate_mcp_server(server)


def _validate_mcp_bridge(cfg: NormalizedConfig) -> None:
    bridge = cfg.mcp.bridge
    if (
        bridge.max_content_items < MCP_BRIDGE_MAX_CONTENT_ITEMS_MIN
        or bridge.max_content_items > MCP_BRIDGE_MAX_CONTENT_ITEMS_MAX
    ):
        msg = (
            "mcp.bridge.max_content_items must be between "
            f"{MCP_BRIDGE_MAX_CONTENT_ITEMS_MIN} and {MCP_BRIDGE_MAX_CONTENT_ITEMS_MAX}"
        )
        raise ConfigError(msg)


def _validate_mcp_expose(cfg: NormalizedConfig) -> None:
    expose = cfg.mcp.expose
    if not (expose.enabled or expose.bundles is not None or expose.tools is not None):
        return
    if not expose.host.strip():
        msg = "mcp.expose.host must be a non-empty string"
        raise ConfigError(msg)
    if expose.port < MCP_EXPOSE_PORT_MIN or expose.port > MCP_EXPOSE_PORT_MAX:
        msg = (
            "mcp.expose.port must be between "
            f"{MCP_EXPOSE_PORT_MIN} and {MCP_EXPOSE_PORT_MAX}"
        )
        raise ConfigError(msg)
    if expose.bundles:
        bundles = set(cfg.tools.bundles.keys())
        for name in expose.bundles:
            if name not in bundles:
                msg = f"mcp.expose.bundles references unknown bundle '{name}'"
                raise ConfigError(msg)
            if cfg.tools.bundles[name].scope != "main":
                msg = (
                    f"mcp.expose.bundles may only reference main-scope bundles: {name}"
                )
                raise ConfigError(msg)
    if expose.tools:
        app_cfg = to_app_config(cfg)
        tools_map, _bundles_map, _defaults = build_tool_catalog_from_config(
            app_cfg,
            scope="main",
        )
        unknown = sorted({k for k in expose.tools if k not in tools_map})
        if unknown:
            msg = f"mcp.expose.tools references unknown tool keys: {', '.join(unknown)}"
            raise ConfigError(msg)


def _validate_mcp(cfg: NormalizedConfig) -> None:
    _validate_mcp_servers(cfg)
    _validate_mcp_bridge(cfg)
    _validate_mcp_expose(cfg)


def _validate_mcp_server(server: McpServerConfig) -> None:
    tool_filter = server.tool_filter
    if tool_filter is not None:
        has_static = bool(
            (tool_filter.allowed_tool_names or ())
            or (tool_filter.blocked_tool_names or ()),
        )
        has_callable = tool_filter.callable_key is not None
        if has_static and has_callable:
            message = (
                f"mcp server {server.key}: tool_filter.callable_key is "
                "mutually exclusive with allowed_tool_names/blocked_tool_names"
            )
            raise ConfigError(message)

    rt = server.runtime
    if rt.session_timeout is not None and rt.session_timeout <= 0:
        message = (
            f"mcp server {server.key}: runtime.session_timeout must be positive or null"
        )
        raise ConfigError(message)


__all__ = ("validate_config",)
