"""File helpers for config path handling."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.constants.limits import SMALL_FILE_MAX_BYTES
from agenterm.core.errors import FilesystemError, ValidationError

if TYPE_CHECKING:
    from pathlib import Path


def read_small_text_file(path: Path, max_bytes: int = SMALL_FILE_MAX_BYTES) -> str:
    """Read a small UTF-8 text file enforcing a size cap.

    Raises FilesystemError when the file is missing/unreadable and
    ValidationError when the file violates size or encoding constraints.
    """
    try:
        if not path.exists() or not path.is_file():
            msg = f"file not found or not a file: {path}"
            raise FilesystemError(msg)
        size = path.stat().st_size
        if size > max_bytes:
            msg = "file too large (>256KB)"
            raise ValidationError(msg)
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as e:
        raise FilesystemError(str(e)) from e


__all__ = ("read_small_text_file",)
