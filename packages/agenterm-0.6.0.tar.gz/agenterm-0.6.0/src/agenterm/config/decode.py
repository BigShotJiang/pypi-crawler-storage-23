"""Decode layer for config files (YAML/JSON) into raw YAML/JSON objects.

Responsibilities:
- Resolve the effective config path (explicit or discovered).
- Load YAML/JSON safely using ruamel in safe mode.
- Return raw objects or None when the file is absent.
- Raise ConfigError on parse/IO issues so callers can surface typed errors.
"""

from __future__ import annotations

from typing import IO, TYPE_CHECKING, Protocol

from ruamel.yaml import YAML, YAMLError

from agenterm.config.paths import find_default_config_path
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.config.schema_validation import RawConfigValue


class _YamlLoader(Protocol):
    def load(
        self,
        stream: str | bytes | bytearray | IO[str],
    ) -> RawConfigValue | None: ...


def _make_yaml_loader() -> _YamlLoader:
    """Return a YAML loader typed to the minimal surface we rely on."""
    return YAML(typ="safe")


def discover_config_path(explicit: Path | None) -> Path | None:
    """Resolve the effective config path.

    Order:
    1) explicit path when provided
    2) default discovery (`find_default_config_path`)
    """
    if explicit is not None:
        return explicit
    return find_default_config_path()


def load_raw_config(path: Path) -> RawConfigValue | None:
    """Load a YAML/JSON file into a raw object.

    Returns None when the file is missing. Raises ConfigError on parse/IO errors.
    """
    yaml_loader = _make_yaml_loader()
    raw: RawConfigValue | None = None
    try:
        with path.open("r", encoding="utf-8") as f:
            raw = yaml_loader.load(f)
    except FileNotFoundError:
        return None
    except (YAMLError, UnicodeDecodeError, OSError) as exc:
        msg = f"failed to parse config at {path}: {exc}"
        raise ConfigError(msg) from exc

    if raw is None:
        return {}
    return raw


__all__ = ("discover_config_path", "load_raw_config")
