"""Bootstrap helpers for first-run config and bundled agent files.

This module owns the single canonical paths for writing starter
`config.yaml` and agent files from bundled templates.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.config.agent_files import (
    list_bundled_agents,
    list_global_agents,
    read_bundled_agent_text,
)
from agenterm.config.files import read_small_text_file
from agenterm.config.paths import (
    global_agent_path,
    global_agents_dir,
    global_config_dir,
    local_agent_path,
    local_agents_dir,
    local_config_dir,
)
from agenterm.config.template import render_config_template
from agenterm.constants.limits import SMALL_FILE_MAX_BYTES
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.core.choices.config_scope import ConfigScope


def _render_config_template(*, model: str) -> str:
    """Render the config.yaml template from the live schema."""
    return render_config_template(model=model)


def write_starter_config(
    path: Path,
    *,
    model: str,
    force: bool,
) -> None:
    """Write a starter config.yaml at the given path.

    Ensures:
    - the parent directory exists,
    - the file is not overwritten unless force=True.
    """
    if path.exists() and not force:
        message = f"Config exists: {path}"
        raise ConfigError(message)

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        message = f"Cannot create directory {path.parent}: {exc}"
        raise ConfigError(message) from exc

    contents = _render_config_template(model=model)
    try:
        path.write_text(contents, encoding="utf-8")
    except OSError as exc:
        message = f"Cannot write config to {path}: {exc}"
        raise ConfigError(message) from exc


@dataclass(frozen=True)
class ConfigSaveResult:
    """Outcome details for config save operations."""

    path: Path
    scope: ConfigScope
    source: str
    overwritten: bool


def _write_config_text(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        message = f"Cannot create directory {path.parent}: {exc}"
        raise ConfigError(message) from exc
    try:
        path.write_text(text, encoding="utf-8")
    except OSError as exc:
        message = f"Cannot write config to {path}: {exc}"
        raise ConfigError(message) from exc


@dataclass(frozen=True)
class AgentsSaveResult:
    """Outcome details for agent file save operations."""

    paths: tuple[Path, ...]
    scope: ConfigScope
    source: str
    overwritten: bool


def save_config(
    *,
    scope: ConfigScope,
    model: str,
    force: bool,
) -> ConfigSaveResult:
    """Write a baseline config and return save metadata."""
    if scope == "global":
        dest = global_config_dir() / "config.yaml"
        existed = dest.exists()
        write_starter_config(dest, model=model, force=force)
        return ConfigSaveResult(
            path=dest,
            scope=scope,
            source="bundled template",
            overwritten=bool(existed),
        )

    dest = local_config_dir() / "config.yaml"
    existed = dest.exists()
    if existed and not force:
        message = f"Config exists: {dest}"
        raise ConfigError(message)

    src_path = global_config_dir() / "config.yaml"
    if src_path.exists():
        try:
            text = src_path.read_text(encoding="utf-8")
        except OSError as exc:
            message = f"Cannot read source config {src_path}: {exc}"
            raise ConfigError(message) from exc
        _write_config_text(dest, text)
        source = str(src_path)
    else:
        write_starter_config(dest, model=model, force=force)
        source = "bundled template"

    return ConfigSaveResult(
        path=dest,
        scope=scope,
        source=source,
        overwritten=bool(existed),
    )


def _write_agent_text(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        message = f"Cannot create directory {path.parent}: {exc}"
        raise ConfigError(message) from exc
    try:
        path.write_text(text, encoding="utf-8")
    except OSError as exc:
        message = f"Cannot write agent file to {path}: {exc}"
        raise ConfigError(message) from exc


def _read_global_agent_text(name: str) -> str:
    path = global_agent_path(name)
    try:
        return read_small_text_file(path, max_bytes=SMALL_FILE_MAX_BYTES)
    except OSError as exc:
        message = f"Cannot read agent file {path}: {exc}"
        raise ConfigError(message) from exc


def save_agents(
    *,
    scope: ConfigScope,
    force: bool,
) -> AgentsSaveResult:
    """Write baseline agent files and return save metadata."""
    if scope == "global":
        names = list_bundled_agents()
        if not names:
            msg = "No bundled agent files found."
            raise ConfigError(msg)
        reader = read_bundled_agent_text
        dest_dir = global_agents_dir()
        source = "bundled templates"
        dest_for_name = global_agent_path
    else:
        names = list_global_agents()
        if names:
            reader = _read_global_agent_text
            dest_dir = local_agents_dir()
            source = str(global_agents_dir())
            dest_for_name = local_agent_path
        else:
            names = list_bundled_agents()
            if not names:
                msg = "No bundled agent files found."
                raise ConfigError(msg)
            reader = read_bundled_agent_text
            dest_dir = local_agents_dir()
            source = "bundled templates"
            dest_for_name = local_agent_path

    dest_paths = [dest_for_name(name) for name in names]
    existing = [path for path in dest_paths if path.exists()]
    if existing and not force:
        msg = f"Agent files already exist in {dest_dir}"
        raise ConfigError(msg)

    for name, path in zip(names, dest_paths, strict=False):
        text = reader(name)
        _write_agent_text(path, text)

    return AgentsSaveResult(
        paths=tuple(dest_paths),
        scope=scope,
        source=source,
        overwritten=bool(existing),
    )


__all__ = (
    "AgentsSaveResult",
    "ConfigSaveResult",
    "save_agents",
    "save_config",
    "write_starter_config",
)
