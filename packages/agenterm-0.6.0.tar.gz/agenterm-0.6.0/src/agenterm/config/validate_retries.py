"""Retry-policy validation for normalized configuration."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.config.normalize import NormalizedConfig


def _validate_retry_policy(
    *,
    name: str,
    max_retries: int,
    base_backoff_seconds: float,
    max_backoff_seconds: float,
    jitter_ratio: float,
    retry_after_max_seconds: float | None,
    max_total_attempts: int,
    deadline_seconds: float | None,
    attempt_timeout_seconds: float | None,
) -> None:
    if max_retries < 0:
        msg = f"{name}.max_retries must be >= 0"
        raise ConfigError(msg)
    if base_backoff_seconds <= 0:
        msg = f"{name}.base_backoff_seconds must be > 0"
        raise ConfigError(msg)
    if max_backoff_seconds <= 0:
        msg = f"{name}.max_backoff_seconds must be > 0"
        raise ConfigError(msg)
    if max_backoff_seconds < base_backoff_seconds:
        msg = f"{name}.max_backoff_seconds must be >= base_backoff_seconds"
        raise ConfigError(msg)
    if jitter_ratio < 0 or jitter_ratio > 1:
        msg = f"{name}.jitter_ratio must be between 0 and 1"
        raise ConfigError(msg)
    if retry_after_max_seconds is not None and retry_after_max_seconds <= 0:
        msg = f"{name}.retry_after_max_seconds must be > 0 or null"
        raise ConfigError(msg)
    if max_total_attempts < 1:
        msg = f"{name}.max_total_attempts must be >= 1"
        raise ConfigError(msg)
    if deadline_seconds is not None and deadline_seconds <= 0:
        msg = f"{name}.deadline_seconds must be > 0 or null"
        raise ConfigError(msg)
    if attempt_timeout_seconds is not None and attempt_timeout_seconds <= 0:
        msg = f"{name}.attempt_timeout_seconds must be > 0 or null"
        raise ConfigError(msg)


def validate_retries_config(cfg: NormalizedConfig) -> None:
    """Validate retries.* policy constraints."""
    retries = cfg.retries
    _validate_retry_policy(
        name="retries.provider",
        max_retries=retries.provider.max_retries,
        base_backoff_seconds=retries.provider.base_backoff_seconds,
        max_backoff_seconds=retries.provider.max_backoff_seconds,
        jitter_ratio=retries.provider.jitter_ratio,
        retry_after_max_seconds=retries.provider.retry_after_max_seconds,
        max_total_attempts=retries.provider.max_total_attempts,
        deadline_seconds=retries.provider.deadline_seconds,
        attempt_timeout_seconds=retries.provider.attempt_timeout_seconds,
    )
    _validate_retry_policy(
        name="retries.mcp",
        max_retries=retries.mcp.max_retries,
        base_backoff_seconds=retries.mcp.base_backoff_seconds,
        max_backoff_seconds=retries.mcp.max_backoff_seconds,
        jitter_ratio=retries.mcp.jitter_ratio,
        retry_after_max_seconds=retries.mcp.retry_after_max_seconds,
        max_total_attempts=retries.mcp.max_total_attempts,
        deadline_seconds=retries.mcp.deadline_seconds,
        attempt_timeout_seconds=retries.mcp.attempt_timeout_seconds,
    )
    _validate_retry_policy(
        name="retries.store",
        max_retries=retries.store.max_retries,
        base_backoff_seconds=retries.store.base_backoff_seconds,
        max_backoff_seconds=retries.store.max_backoff_seconds,
        jitter_ratio=retries.store.jitter_ratio,
        retry_after_max_seconds=retries.store.retry_after_max_seconds,
        max_total_attempts=retries.store.max_total_attempts,
        deadline_seconds=retries.store.deadline_seconds,
        attempt_timeout_seconds=retries.store.attempt_timeout_seconds,
    )


__all__ = ("validate_retries_config",)
