"""Normalize MCP connector configuration.

MCP connectors are provider-hosted MCP endpoints exposed to the model as a
single hosted tool (`hosted_mcp`) via Agents `HostedMCPTool`.

Exactly one of `server_url` (custom MCP server) or `connector_id` (service
connector) must be provided.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING

from agenterm.config.model import McpConnectorConfig
from agenterm.config.normalize.tools_helpers import (
    as_json_object,
    as_str_dict,
    validate_allowed_keys,
)
from agenterm.core.choices.mcp import MCP_CONNECTOR_IDS, parse_mcp_connector_id
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_str, as_str_list

if TYPE_CHECKING:
    from agenterm.config.mcp_filters import (
        McpAllowedTools,
        McpRequireApproval,
        McpRequireApprovalFilter,
        McpToolFilter,
    )
    from agenterm.core.choices.mcp import McpConnectorId
    from agenterm.core.json_types import JSONValue

_MCP_CONNECTOR_ALLOWED_KEYS: set[str] = {
    "name",
    "server_url",
    "authorization_env",
    "server_description",
    "connector_id",
    "headers",
    "allowed_tools",
    "require_approval",
}


def _connector_opt_str(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
) -> str | None:
    raw = node.get(key)
    if raw is None:
        return None
    value = as_str(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be a string or null"
    raise ConfigError(msg)


def _connector_opt_non_empty_str(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
) -> str | None:
    raw = _connector_opt_str(node, key=key, prefix=prefix)
    if raw is None:
        return None
    stripped = raw.strip()
    if not stripped:
        msg = f"{prefix} must be a non-empty string or null"
        raise ConfigError(msg)
    return stripped


def _parse_connector_id(
    raw: str | None,
    *,
    prefix: str,
) -> McpConnectorId | None:
    if raw is None:
        return None
    parsed = parse_mcp_connector_id(raw)
    if parsed is None:
        supported = ", ".join(MCP_CONNECTOR_IDS)
        msg = (
            f"{prefix} must be one of: {supported}. "
            "Set connector_id to null to use server_url instead."
        )
        raise ConfigError(msg)
    return parsed


def _require_exactly_one_target(
    server_url: str | None,
    connector_id: McpConnectorId | None,
    *,
    prefix: str,
) -> None:
    if server_url is None and connector_id is None:
        msg = f"{prefix} must set exactly one of server_url or connector_id"
        raise ConfigError(msg)
    if server_url is not None and connector_id is not None:
        msg = f"{prefix} must not set both server_url and connector_id"
        raise ConfigError(msg)


def _connector_headers(
    node: Mapping[str, JSONValue],
    *,
    prefix: str,
) -> Mapping[str, str] | None:
    if "headers" not in node:
        return None
    raw = node.get("headers")
    if raw is None:
        return None
    mapped = as_str_dict(raw)
    if mapped is None:
        msg = f"{prefix} must be a mapping of strings"
        raise ConfigError(msg)
    return mapped


def _connector_allowed_tools(
    raw: JSONValue | None,
    *,
    prefix: str,
) -> McpAllowedTools | None:
    if raw is None:
        return None
    if isinstance(raw, list):
        names = as_str_list(raw)
        if names is None:
            msg = f"{prefix} must be a list of strings"
            raise ConfigError(msg)
        return names
    if isinstance(raw, Mapping):
        return _parse_tool_filter(raw, prefix=prefix)
    msg = f"{prefix} must be a list, mapping, or null"
    raise ConfigError(msg)


def _connector_require_approval(
    raw: JSONValue | None,
    *,
    prefix: str,
) -> McpRequireApproval | None:
    if raw is None:
        return None
    if raw == "always":
        return "always"
    if raw == "never":
        return "never"
    if isinstance(raw, Mapping):
        raw_map = as_json_object(raw)
        if raw_map is None:
            msg = f"{prefix} must contain only JSON values"
            raise ConfigError(msg)
        validate_allowed_keys(
            raw_map,
            allowed={"always", "never"},
            prefix=prefix,
        )
        out: McpRequireApprovalFilter = {}
        for key in ("always", "never"):
            if key not in raw_map:
                continue
            sub = raw_map.get(key)
            if not isinstance(sub, Mapping):
                msg = f"{prefix}.{key} must be a mapping"
                raise ConfigError(msg)
            out[key] = _parse_tool_filter(sub, prefix=f"{prefix}.{key}")
        return out
    msg = f"{prefix} must be always|never, a mapping, or null"
    raise ConfigError(msg)


def _parse_tool_filter(
    raw: Mapping[str, JSONValue],
    *,
    prefix: str,
) -> McpToolFilter:
    raw_map = as_json_object(raw)
    if raw_map is None:
        msg = f"{prefix} must contain only JSON values"
        raise ConfigError(msg)
    validate_allowed_keys(
        raw_map,
        allowed={"read_only", "tool_names"},
        prefix=prefix,
    )
    out: McpToolFilter = {}
    if "read_only" in raw_map:
        raw_ro = raw_map.get("read_only")
        if not isinstance(raw_ro, bool):
            msg = f"{prefix}.read_only must be a boolean"
            raise ConfigError(msg)
        out["read_only"] = raw_ro
    if "tool_names" in raw_map:
        raw_names = raw_map.get("tool_names")
        if not isinstance(raw_names, list):
            msg = f"{prefix}.tool_names must be a list of strings"
            raise ConfigError(msg)
        names = as_str_list(raw_names)
        if names is None:
            msg = f"{prefix}.tool_names must be a list of strings"
            raise ConfigError(msg)
        out["tool_names"] = names
    return out


def _parse_connector(raw: JSONValue, *, index: int) -> McpConnectorConfig:
    raw_typed = as_json_object(raw)
    if raw_typed is None:
        msg = f"mcp.connectors[{index}] must be a mapping"
        raise ConfigError(msg)
    validate_allowed_keys(
        raw_typed,
        allowed=_MCP_CONNECTOR_ALLOWED_KEYS,
        prefix=f"mcp.connectors[{index}]",
    )

    name_raw = raw_typed.get("name")
    if not isinstance(name_raw, str) or not name_raw.strip():
        msg = f"mcp.connectors[{index}].name must be a non-empty string"
        raise ConfigError(msg)
    name = name_raw.strip()

    server_url = _connector_opt_non_empty_str(
        raw_typed,
        key="server_url",
        prefix=f"mcp.connectors[{index}].server_url",
    )
    connector_id_raw = _connector_opt_non_empty_str(
        raw_typed,
        key="connector_id",
        prefix=f"mcp.connectors[{index}].connector_id",
    )
    connector_id = _parse_connector_id(
        connector_id_raw,
        prefix=f"mcp.connectors[{index}].connector_id",
    )
    _require_exactly_one_target(
        server_url,
        connector_id,
        prefix=f"mcp.connectors[{index}]",
    )

    return McpConnectorConfig(
        name=name,
        server_url=server_url,
        authorization_env=_connector_opt_str(
            raw_typed,
            key="authorization_env",
            prefix=f"mcp.connectors[{index}].authorization_env",
        ),
        server_description=_connector_opt_str(
            raw_typed,
            key="server_description",
            prefix=f"mcp.connectors[{index}].server_description",
        ),
        connector_id=connector_id,
        headers=_connector_headers(
            raw_typed,
            prefix=f"mcp.connectors[{index}].headers",
        ),
        allowed_tools=_connector_allowed_tools(
            raw_typed.get("allowed_tools"),
            prefix=f"mcp.connectors[{index}].allowed_tools",
        ),
        require_approval=_connector_require_approval(
            raw_typed.get("require_approval"),
            prefix=f"mcp.connectors[{index}].require_approval",
        ),
    )


def normalize_mcp_connectors(seq: JSONValue | None) -> list[McpConnectorConfig]:
    """Normalize mcp.connectors list from YAML."""
    if not isinstance(seq, list):
        return []
    return [_parse_connector(raw, index=i) for i, raw in enumerate(seq)]


__all__ = ("normalize_mcp_connectors",)
