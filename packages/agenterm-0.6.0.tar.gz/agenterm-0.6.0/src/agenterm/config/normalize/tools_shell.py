"""Normalize shell tool configuration."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.config.normalize.tools_helpers import (
    as_json_object,
    as_str_dict,
    validate_allowed_keys,
)
from agenterm.config.tool_models import ShellSandboxConfig, ShellToolConfig
from agenterm.core.choices.tools import (
    parse_sandbox_network,
)
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


def _normalize_shell_sandbox(node: Mapping[str, JSONValue]) -> ShellSandboxConfig:
    """Normalize tools.shell.sandbox config from YAML mapping."""
    base = ShellSandboxConfig()
    validate_allowed_keys(node, allowed={"network"}, prefix="tools.shell.sandbox")

    net_raw = node.get("network", base.network)
    if not isinstance(net_raw, str):
        msg = "tools.shell.sandbox.network must be allow|deny"
        raise ConfigError(msg)
    network = parse_sandbox_network(net_raw)
    if network is None:
        msg = "tools.shell.sandbox.network must be allow|deny"
        raise ConfigError(msg)
    return ShellSandboxConfig(network=network)


def _normalize_shell_timeout_ms(
    node: Mapping[str, JSONValue],
    base: ShellToolConfig,
) -> int | None:
    raw = node.get("timeout_ms", base.timeout_ms)
    if raw is None:
        return None
    if isinstance(raw, int):
        return int(raw)
    msg = "tools.shell.timeout_ms must be an integer or null"
    raise ConfigError(msg)


def _normalize_shell_max_chars(
    node: Mapping[str, JSONValue],
    base: ShellToolConfig,
) -> int | None:
    raw = node.get("max_chars", base.max_chars)
    if raw is None:
        return None
    if isinstance(raw, int):
        return int(raw)
    msg = "tools.shell.max_chars must be an integer or null"
    raise ConfigError(msg)


def _normalize_shell_working_dir(
    node: Mapping[str, JSONValue],
    base: ShellToolConfig,
) -> Path | None:
    raw = node.get("working_dir", base.working_dir)
    if raw is None:
        return None
    if isinstance(raw, str):
        return Path(raw).expanduser().resolve()
    if isinstance(raw, Path):
        return raw
    msg = "tools.shell.working_dir must be a string path or null"
    raise ConfigError(msg)


def _normalize_shell_env(
    node: Mapping[str, JSONValue],
    base: ShellToolConfig,
) -> Mapping[str, str] | None:
    if "env" not in node:
        return base.env
    raw = node.get("env")
    if raw is None:
        return None
    result = as_str_dict(raw)
    if result is None:
        msg = "tools.shell.env must be a string-keyed object with string values or null"
        raise ConfigError(msg)
    return result


def _normalize_shell_sandbox_field(
    node: Mapping[str, JSONValue],
    base: ShellToolConfig,
) -> ShellSandboxConfig:
    raw = node.get("sandbox", None)
    if raw is None:
        return base.sandbox
    if not isinstance(raw, Mapping):
        msg = "tools.shell.sandbox must be a mapping when provided"
        raise ConfigError(msg)
    raw_map = as_json_object(raw)
    if raw_map is None:
        msg = "tools.shell.sandbox must contain only JSON values"
        raise ConfigError(msg)
    return _normalize_shell_sandbox(raw_map)


def normalize_shell(
    node: Mapping[str, JSONValue],
    base: ShellToolConfig,
) -> ShellToolConfig:
    """Normalize tools.shell mapping."""
    validate_allowed_keys(
        node,
        allowed={
            "timeout_ms",
            "max_chars",
            "working_dir",
            "env",
            "sandbox",
        },
        prefix="tools.shell",
    )

    timeout_ms = _normalize_shell_timeout_ms(node, base)
    max_chars = _normalize_shell_max_chars(node, base)
    working_dir = _normalize_shell_working_dir(node, base)
    env = _normalize_shell_env(node, base)
    sandbox = _normalize_shell_sandbox_field(node, base)

    return replace(
        base,
        timeout_ms=timeout_ms,
        max_chars=max_chars,
        working_dir=working_dir,
        env=env,
        sandbox=sandbox,
    )


__all__ = ("normalize_shell",)
