"""Normalize attachment policy configuration."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.attachments import AttachmentImageInputMode, AttachmentsConfig
from agenterm.config.normalize.validators import validate_allowed_keys
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_bool, as_int, as_str

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


_ALLOWED_KEYS: set[str] = {
    "image_input_mode",
    "allow_inline_data_url",
    "max_inline_bytes",
}


def _normalize_image_input_mode(
    raw: JSONValue | None,
    *,
    default: AttachmentImageInputMode,
    prefix: str,
) -> AttachmentImageInputMode:
    parsed = as_str(raw)
    if parsed is None:
        return default
    if parsed == "file_id_or_url_only":
        return "file_id_or_url_only"
    if parsed == "allow_inline_data_url":
        return "allow_inline_data_url"
    msg = f"{prefix} must be file_id_or_url_only|allow_inline_data_url"
    raise ConfigError(msg)


def _normalize_allow_inline(
    raw: JSONValue | None,
    *,
    default: bool,
) -> bool:
    parsed = as_bool(raw)
    if parsed is None:
        return default
    return bool(parsed)


def _normalize_max_inline_bytes(
    raw: JSONValue | None,
    *,
    default: int,
    prefix: str,
) -> int:
    parsed = as_int(raw)
    if parsed is None:
        return default
    if parsed < 0:
        msg = f"{prefix} must be >= 0"
        raise ConfigError(msg)
    return int(parsed)


def normalize_attachments(
    node: Mapping[str, JSONValue] | None,
    base: AttachmentsConfig,
) -> AttachmentsConfig:
    """Normalize the attachments section."""
    if node is None:
        return base
    validate_allowed_keys(node, allowed=_ALLOWED_KEYS, prefix="attachments")
    image_input_mode = _normalize_image_input_mode(
        node.get("image_input_mode", base.image_input_mode),
        default=base.image_input_mode,
        prefix="attachments.image_input_mode",
    )
    allow_inline = _normalize_allow_inline(
        node.get("allow_inline_data_url", base.allow_inline_data_url),
        default=base.allow_inline_data_url,
    )
    max_inline_bytes = _normalize_max_inline_bytes(
        node.get("max_inline_bytes", base.max_inline_bytes),
        default=base.max_inline_bytes,
        prefix="attachments.max_inline_bytes",
    )
    if image_input_mode == "file_id_or_url_only" and allow_inline:
        msg = "attachments.image_input_mode conflicts with allow_inline_data_url"
        raise ConfigError(msg)
    if image_input_mode == "allow_inline_data_url" and not allow_inline:
        msg = "attachments.image_input_mode requires allow_inline_data_url=true"
        raise ConfigError(msg)
    if allow_inline and max_inline_bytes <= 0:
        msg = (
            "attachments.max_inline_bytes must be > 0 when inline data URLs are allowed"
        )
        raise ConfigError(msg)
    return AttachmentsConfig(
        image_input_mode=image_input_mode,
        allow_inline_data_url=allow_inline,
        max_inline_bytes=max_inline_bytes,
    )


__all__ = ("normalize_attachments",)
