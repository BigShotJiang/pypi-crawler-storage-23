"""Normalize MCP bridge configuration."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.config.mcp_models import McpBridgeConfig
from agenterm.config.normalize.validators import validate_allowed_keys
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_int, as_json_object

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


def _int_or_default(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int,
    prefix: str,
) -> int:
    raw = node.get(key, default)
    value = as_int(raw)
    if value is not None:
        return value
    if raw is None:
        return default
    msg = f"{prefix} must be an integer"
    raise ConfigError(msg)


def _build_bridge(node: Mapping[str, JSONValue]) -> McpBridgeConfig:
    validate_allowed_keys(
        node,
        allowed={"max_content_items"},
        prefix="mcp.bridge",
    )
    base = McpBridgeConfig()
    max_items = _int_or_default(
        node,
        key="max_content_items",
        default=base.max_content_items,
        prefix="mcp.bridge.max_content_items",
    )
    return replace(
        base,
        max_content_items=max_items,
    )


def normalize_mcp_bridge(node: Mapping[str, JSONValue]) -> McpBridgeConfig:
    """Normalize the mcp.bridge section."""
    if "bridge" not in node:
        return McpBridgeConfig()
    raw_bridge = node.get("bridge")
    if raw_bridge is None:
        return McpBridgeConfig()
    typed = as_json_object(raw_bridge)
    if typed is None:
        msg = "mcp.bridge must be a mapping or null"
        raise ConfigError(msg)
    return _build_bridge(typed)


__all__ = ("normalize_mcp_bridge",)
