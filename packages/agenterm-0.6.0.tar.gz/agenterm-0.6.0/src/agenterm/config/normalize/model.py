"""Normalize model section."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from openai.types.shared import Reasoning

from agenterm.config.normalize.validators import (
    bool_field,
    float_field,
    int_field,
    str_map_or_none,
    text_format_field,
)
from agenterm.core.choices.model import (
    ModelTruncation,
    ModelVerbosity,
    PromptCacheRetention,
    ReasoningEffort,
    ReasoningSummary,
    parse_model_truncation,
    parse_model_verbosity,
    parse_prompt_cache_retention,
    parse_reasoning_effort,
    parse_reasoning_summary,
)
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_bool, as_json_object, as_str

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.model_settings import ToolChoice

    from agenterm.config.model import ModelConfig
    from agenterm.config.text_format import TextFormat
    from agenterm.core.json_types import JSONValue


def _bool_or_none(
    node: Mapping[str, JSONValue],
    key: str,
    *,
    base: bool | None,
) -> bool | None:
    if key not in node:
        return base
    val = node.get(key)
    if val is None:
        return None
    parsed = as_bool(val)
    if parsed is not None:
        return parsed
    msg = f"model.{key} must be a boolean when provided"
    raise ConfigError(msg)


def _tool_choice(node: Mapping[str, JSONValue], base: ModelConfig) -> ToolChoice | None:
    if "tool_choice" not in node:
        return base.tool_choice
    val = node.get("tool_choice")
    if val is None:
        return None
    parsed = as_str(val)
    if parsed is not None:
        return parsed
    msg = "model.tool_choice must be a string when provided"
    raise ConfigError(msg)


def _literal_effort(val: JSONValue | None) -> ReasoningEffort | None:
    parsed = as_str(val)
    if parsed is None:
        return None
    return parse_reasoning_effort(parsed)


def _literal_summary(val: JSONValue | None) -> ReasoningSummary | None:
    parsed = as_str(val)
    if parsed is None:
        return None
    return parse_reasoning_summary(parsed)


_REASONING_ALLOWED_KEYS: set[str] = {"effort", "summary"}


def _reasoning_effort(
    raw: Mapping[str, JSONValue],
    *,
    base: Reasoning,
) -> ReasoningEffort | None:
    if "effort" not in raw:
        return base.effort
    effort_raw = raw.get("effort")
    if effort_raw is None:
        return None
    effort = _literal_effort(effort_raw)
    if effort is None:
        msg = "model.reasoning.effort must be one of none|minimal|low|medium|high|xhigh"
        raise ConfigError(msg)
    return effort


def _reasoning_summary(
    raw: Mapping[str, JSONValue],
    *,
    base: Reasoning,
) -> ReasoningSummary | None:
    if "summary" not in raw:
        return base.summary
    summary_raw = raw.get("summary")
    if summary_raw is None:
        return None
    summary = _literal_summary(summary_raw)
    if summary is None:
        msg = "model.reasoning.summary must be auto|concise|detailed when provided"
        raise ConfigError(msg)
    return summary


def _reasoning(node: Mapping[str, JSONValue], base: ModelConfig) -> Reasoning | None:
    if "reasoning" not in node:
        return base.reasoning
    raw = node.get("reasoning")
    if raw is None:
        return None
    if not isinstance(raw, dict):
        msg = "model.reasoning must be a mapping when provided"
        raise ConfigError(msg)

    unknown = {str(k) for k in raw if str(k) not in _REASONING_ALLOWED_KEYS}
    if unknown:
        msg = f"model.reasoning contains unknown keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)

    base_reasoning = base.reasoning or Reasoning()
    return Reasoning(
        effort=_reasoning_effort(raw, base=base_reasoning),
        summary=_reasoning_summary(raw, base=base_reasoning),
    )


def _text_format(node: Mapping[str, JSONValue], base: ModelConfig) -> TextFormat | None:
    return text_format_field(
        node,
        key="text_format",
        default=base.text_format,
        prefix="model.text_format",
    )


def _text_format_file(node: Mapping[str, JSONValue], base: ModelConfig) -> Path | None:
    if "text_format_file" not in node:
        return base.text_format_file
    raw_tf_file = node.get("text_format_file")
    if isinstance(raw_tf_file, str):
        return Path(raw_tf_file)
    if raw_tf_file is None:
        return None
    msg = "model.text_format_file must be a string path when provided"
    raise ConfigError(msg)


_ALLOWED_MODEL_KEYS: set[str] = {
    "temperature",
    "top_p",
    "frequency_penalty",
    "presence_penalty",
    "tool_choice",
    "truncation",
    "max_output_tokens",
    "reasoning",
    "verbosity",
    "metadata",
    "text_format",
    "text_format_file",
    "store",
    "context_window",
    "prompt_cache_retention",
    "include_usage",
    "top_logprobs",
    "extra_query",
    "extra_body",
    "extra_headers",
}


def _validate_model_keys(node: Mapping[str, JSONValue]) -> None:
    unknown = {str(k) for k in node if str(k) not in _ALLOWED_MODEL_KEYS}
    if unknown:
        msg = f"Unknown model keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)


def _validate_text_format_exclusive(node: Mapping[str, JSONValue]) -> None:
    has_tf = "text_format" in node and node.get("text_format") is not None
    has_tf_file = (
        "text_format_file" in node and node.get("text_format_file") is not None
    )
    if has_tf and has_tf_file:
        msg = "model.text_format and model.text_format_file cannot both be set"
        raise ConfigError(msg)


def _str_map_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: Mapping[str, str] | None,
) -> dict[str, str] | None:
    if key not in node:
        return dict(default) if default is not None else None
    value = str_map_or_none(
        node,
        key=key,
        default=None,
        prefix=f"model.{key}",
    )
    return dict(value) if value is not None else None


def _json_map_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: Mapping[str, JSONValue] | None,
) -> dict[str, JSONValue] | None:
    if key not in node:
        return dict(default) if default is not None else None
    raw = node.get(key)
    if raw is None:
        return None
    raw_map = as_json_object(raw)
    if raw_map is None:
        msg = f"model.{key} must be a JSON object or null when provided"
        raise ConfigError(msg)
    return raw_map


def _truncation(
    node: Mapping[str, JSONValue],
    base: ModelConfig,
) -> ModelTruncation | None:
    if "truncation" not in node:
        return base.truncation
    raw = node.get("truncation")
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_model_truncation(raw)
        if parsed is not None:
            return parsed
    msg = "model.truncation must be auto|disabled|null when provided"
    raise ConfigError(msg)


def _verbosity(
    node: Mapping[str, JSONValue],
    base: ModelConfig,
) -> ModelVerbosity | None:
    if "verbosity" not in node:
        return base.verbosity
    raw = node.get("verbosity")
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_model_verbosity(raw)
        if parsed is not None:
            return parsed
    msg = "model.verbosity must be low|medium|high|null when provided"
    raise ConfigError(msg)


def _prompt_cache_retention(
    node: Mapping[str, JSONValue],
    base: ModelConfig,
) -> PromptCacheRetention | None:
    if "prompt_cache_retention" not in node:
        return base.prompt_cache_retention
    raw = node.get("prompt_cache_retention")
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_prompt_cache_retention(raw)
        if parsed is not None:
            return parsed
    msg = "model.prompt_cache_retention must be 24h|in_memory|null when provided"
    raise ConfigError(msg)


def _context_window(
    node: Mapping[str, JSONValue],
    base: ModelConfig,
) -> int | None:
    if "context_window" not in node:
        return base.context_window
    raw = node.get("context_window")
    if raw is None:
        return None
    if isinstance(raw, int) and not isinstance(raw, bool) and raw > 0:
        return raw
    msg = "model.context_window must be a positive integer or null when provided"
    raise ConfigError(msg)


def normalize_model(
    node: Mapping[str, JSONValue] | None,
    base: ModelConfig,
) -> ModelConfig:
    """Normalize the model block."""
    if node is None:
        return base

    _validate_model_keys(node)
    _validate_text_format_exclusive(node)

    include_usage = _bool_or_none(node, "include_usage", base=base.include_usage)

    return replace(
        base,
        temperature=float_field(
            node,
            key="temperature",
            default=base.temperature,
            prefix="model.temperature",
        ),
        top_p=float_field(
            node,
            key="top_p",
            default=base.top_p,
            prefix="model.top_p",
        ),
        frequency_penalty=float_field(
            node,
            key="frequency_penalty",
            default=base.frequency_penalty,
            prefix="model.frequency_penalty",
        ),
        presence_penalty=float_field(
            node,
            key="presence_penalty",
            default=base.presence_penalty,
            prefix="model.presence_penalty",
        ),
        tool_choice=_tool_choice(node, base),
        truncation=_truncation(node, base),
        max_output_tokens=int_field(
            node,
            key="max_output_tokens",
            default=base.max_output_tokens,
            prefix="model.max_output_tokens",
        ),
        reasoning=_reasoning(node, base),
        verbosity=_verbosity(node, base),
        metadata=_str_map_field(node, key="metadata", default=base.metadata),
        text_format=_text_format(node, base),
        text_format_file=_text_format_file(node, base),
        store=bool_field(
            node,
            key="store",
            default=base.store,
            prefix="model.store",
        ),
        context_window=_context_window(node, base),
        prompt_cache_retention=_prompt_cache_retention(node, base),
        include_usage=include_usage,
        top_logprobs=int_field(
            node,
            key="top_logprobs",
            default=base.top_logprobs,
            prefix="model.top_logprobs",
        ),
        extra_query=_json_map_field(node, key="extra_query", default=base.extra_query),
        extra_body=_json_map_field(node, key="extra_body", default=base.extra_body),
        extra_headers=_str_map_field(
            node,
            key="extra_headers",
            default=base.extra_headers,
        ),
    )


__all__ = ("normalize_model",)
