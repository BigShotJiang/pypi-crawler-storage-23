"""Normalize MCP exposure configuration."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.config.mcp_models import McpExposeConfig
from agenterm.config.normalize.validators import bool_field
from agenterm.core.choices.mcp import MCP_SERVER_KINDS, parse_mcp_server_kind
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_int, as_json_object, as_str, as_str_list

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


def _optional_str_list(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
) -> list[str] | None:
    if key not in node:
        return None
    raw = node.get(key)
    if raw is None:
        return None
    parsed = as_str_list(raw)
    if parsed is None:
        msg = f"{prefix} must be a list of strings"
        raise ConfigError(msg)
    return parsed


def _optional_str(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: str,
    prefix: str,
) -> str:
    if key not in node:
        return default
    raw = node.get(key)
    if raw is None:
        return default
    value = as_str(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be a string"
    raise ConfigError(msg)


def _optional_int(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int,
    prefix: str,
) -> int:
    if key not in node:
        return default
    raw = node.get(key)
    if raw is None:
        return default
    value = as_int(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be an integer"
    raise ConfigError(msg)


def _optional_transport(
    node: Mapping[str, JSONValue],
    *,
    default: str,
) -> str:
    if "transport" not in node:
        return default
    raw = node.get("transport")
    if raw is None:
        return default
    value = as_str(raw)
    if value is None:
        msg = "mcp.expose.transport must be a string"
        raise ConfigError(msg)
    transport = parse_mcp_server_kind(value)
    if transport is None:
        msg = f"mcp.expose.transport must be one of: {', '.join(MCP_SERVER_KINDS)}"
        raise ConfigError(msg)
    return transport


def _build_expose(node: Mapping[str, JSONValue]) -> McpExposeConfig:
    unknown = {
        str(k)
        for k in node
        if str(k)
        not in {
            "enabled",
            "transport",
            "host",
            "port",
            "allow_dangerous",
            "bundles",
            "tools",
        }
    }
    if unknown:
        msg = f"mcp.expose contains unknown keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)

    base = McpExposeConfig()
    enabled = bool_field(
        node,
        key="enabled",
        default=base.enabled,
        prefix="mcp.expose.enabled",
    )
    allow_dangerous = bool_field(
        node,
        key="allow_dangerous",
        default=base.allow_dangerous,
        prefix="mcp.expose.allow_dangerous",
    )
    transport = _optional_transport(node, default=base.transport)
    host = _optional_str(node, key="host", default=base.host, prefix="mcp.expose.host")
    port = _optional_int(node, key="port", default=base.port, prefix="mcp.expose.port")
    bundles = _optional_str_list(node, key="bundles", prefix="mcp.expose.bundles")
    tools = _optional_str_list(node, key="tools", prefix="mcp.expose.tools")
    return replace(
        base,
        enabled=enabled,
        transport=transport,
        host=host,
        port=port,
        allow_dangerous=allow_dangerous,
        bundles=bundles,
        tools=tools,
    )


def normalize_mcp_expose(node: Mapping[str, JSONValue]) -> McpExposeConfig:
    """Normalize the mcp.expose section."""
    if "expose" not in node:
        return McpExposeConfig()
    raw_expose = node.get("expose")
    if raw_expose is None:
        return McpExposeConfig()
    typed = as_json_object(raw_expose)
    if typed is None:
        msg = "mcp.expose must be a mapping or null"
        raise ConfigError(msg)
    return _build_expose(typed)


__all__ = ("normalize_mcp_expose",)
