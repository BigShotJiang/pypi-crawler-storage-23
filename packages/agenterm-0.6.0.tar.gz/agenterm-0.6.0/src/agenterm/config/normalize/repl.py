"""Normalize repl configuration."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING

from agenterm.config.model import (
    ReplApprovalsConfig,
    ReplConfig,
    ReplTranscriptConfig,
    ReplUiConfig,
    ReplUxConfig,
)
from agenterm.config.normalize.validators import bool_field, nonneg_int_field
from agenterm.core.choices.approvals import (
    APPROVAL_MODES,
    ApprovalMode,
    parse_approval_mode,
)
from agenterm.core.choices.repl import (
    REPL_DIFFS_MODES,
    REPL_REASONING_MODES,
    REPL_STREAM_MODES,
    REPL_VERBOSITIES,
    ReplDiffsMode,
    ReplReasoningMode,
    ReplStreamMode,
    ReplVerbosity,
    parse_repl_diffs_mode,
    parse_repl_reasoning_mode,
    parse_repl_stream_mode,
    parse_repl_verbosity,
)
from agenterm.core.choices.repl_ui import (
    REPL_COLOR_DEPTHS,
    REPL_COMPLETION_MODES,
    REPL_EDITING_MODES,
    REPL_THEMES,
    ReplColorDepth,
    ReplCompletionMode,
    ReplEditingMode,
    ReplTheme,
    parse_repl_color_depth,
    parse_repl_completion_mode,
    parse_repl_editing_mode,
    parse_repl_theme,
)
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


_ALLOWED_REPL_KEYS: set[str] = {"approvals", "transcript", "ui", "ux"}
_ALLOWED_UX_KEYS: set[str] = {
    "markdown",
    "reasoning",
    "reasoning_summary_max_chars",
    "diffs",
    "stream",
    "verbosity",
}
_ALLOWED_TRANSCRIPT_KEYS: set[str] = {
    "tool_output_max_lines",
    "shell_preview_max_chars",
    "tool_detail_max_lines",
    "tool_detail_max_chars",
    "mcp_args_preview_max_chars",
    "attachments_max_lines",
    "attachments_path_max_chars",
}
_ALLOWED_UI_KEYS: set[str] = {
    "theme",
    "color_depth",
    "editing_mode",
    "mouse",
    "completion",
    "max_transcript_entries",
}
_ALLOWED_APPROVALS_KEYS: set[str] = {"mode"}


def _approval_mode_field(
    node: Mapping[str, JSONValue],
    *,
    default: ApprovalMode,
) -> ApprovalMode:
    raw = node.get("mode", default)
    if not isinstance(raw, str):
        msg = "repl.approvals.mode must be a string"
        raise ConfigError(msg)
    val = parse_approval_mode(raw)
    if val is None:
        msg = f"repl.approvals.mode must be one of: {', '.join(APPROVAL_MODES)}"
        raise ConfigError(msg)
    return val


def _reasoning_mode_field(
    node: Mapping[str, JSONValue],
    *,
    default: ReplReasoningMode,
) -> ReplReasoningMode:
    raw = node.get("reasoning", default)
    if not isinstance(raw, str):
        msg = "repl.ux.reasoning must be a string"
        raise ConfigError(msg)
    val = parse_repl_reasoning_mode(raw)
    if val is None:
        msg = f"repl.ux.reasoning must be one of: {', '.join(REPL_REASONING_MODES)}"
        raise ConfigError(msg)
    return val


def _diffs_mode_field(
    node: Mapping[str, JSONValue],
    *,
    default: ReplDiffsMode,
) -> ReplDiffsMode:
    raw = node.get("diffs", default)
    if not isinstance(raw, str):
        msg = "repl.ux.diffs must be a string"
        raise ConfigError(msg)
    val = parse_repl_diffs_mode(raw)
    if val is None:
        msg = f"repl.ux.diffs must be one of: {', '.join(REPL_DIFFS_MODES)}"
        raise ConfigError(msg)
    return val


def _stream_mode_field(
    node: Mapping[str, JSONValue],
    *,
    default: ReplStreamMode,
) -> ReplStreamMode:
    raw = node.get("stream", default)
    if not isinstance(raw, str):
        msg = "repl.ux.stream must be a string"
        raise ConfigError(msg)
    val = parse_repl_stream_mode(raw)
    if val is None:
        msg = f"repl.ux.stream must be one of: {', '.join(REPL_STREAM_MODES)}"
        raise ConfigError(msg)
    return val


def _verbosity_field(
    node: Mapping[str, JSONValue],
    *,
    default: ReplVerbosity,
) -> ReplVerbosity:
    raw = node.get("verbosity", default)
    if not isinstance(raw, str):
        msg = "repl.ux.verbosity must be a string"
        raise ConfigError(msg)
    val = parse_repl_verbosity(raw)
    if val is None:
        msg = f"repl.ux.verbosity must be one of: {', '.join(REPL_VERBOSITIES)}"
        raise ConfigError(msg)
    return val


def _editing_mode_field(
    node: Mapping[str, JSONValue],
    *,
    default: ReplEditingMode,
) -> ReplEditingMode:
    raw = node.get("editing_mode", default)
    if not isinstance(raw, str):
        msg = "repl.ui.editing_mode must be a string"
        raise ConfigError(msg)
    val = parse_repl_editing_mode(raw)
    if val is None:
        msg = f"repl.ui.editing_mode must be one of: {', '.join(REPL_EDITING_MODES)}"
        raise ConfigError(msg)
    return val


def _theme_field(
    node: Mapping[str, JSONValue],
    *,
    default: ReplTheme,
) -> ReplTheme:
    raw = node.get("theme", default)
    if not isinstance(raw, str):
        msg = "repl.ui.theme must be a string"
        raise ConfigError(msg)
    val = parse_repl_theme(raw)
    if val is None:
        msg = f"repl.ui.theme must be one of: {', '.join(REPL_THEMES)}"
        raise ConfigError(msg)
    return val


def _color_depth_field(
    node: Mapping[str, JSONValue],
    *,
    default: ReplColorDepth,
) -> ReplColorDepth:
    raw = node.get("color_depth", default)
    if not isinstance(raw, str):
        msg = "repl.ui.color_depth must be a string"
        raise ConfigError(msg)
    val = parse_repl_color_depth(raw)
    if val is None:
        msg = f"repl.ui.color_depth must be one of: {', '.join(REPL_COLOR_DEPTHS)}"
        raise ConfigError(msg)
    return val


def _completion_mode_field(
    node: Mapping[str, JSONValue],
    *,
    default: ReplCompletionMode,
) -> ReplCompletionMode:
    raw = node.get("completion", default)
    if not isinstance(raw, str):
        msg = "repl.ui.completion must be a string"
        raise ConfigError(msg)
    val = parse_repl_completion_mode(raw)
    if val is None:
        msg = f"repl.ui.completion must be one of: {', '.join(REPL_COMPLETION_MODES)}"
        raise ConfigError(msg)
    return val


def _normalize_approvals(
    node: JSONValue | None,
    base: ReplApprovalsConfig,
) -> ReplApprovalsConfig:
    if node is None:
        return base
    if not isinstance(node, Mapping):
        msg = "repl.approvals must be a mapping when provided"
        raise ConfigError(msg)
    unknown = {str(k) for k in node if str(k) not in _ALLOWED_APPROVALS_KEYS}
    if unknown:
        msg = f"Unknown repl.approvals keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)
    mode = _approval_mode_field(node, default=base.mode)
    return ReplApprovalsConfig(mode=mode)


def _normalize_ux(node: JSONValue | None, base: ReplUxConfig) -> ReplUxConfig:
    if node is None:
        return base
    if not isinstance(node, Mapping):
        msg = "repl.ux must be a mapping when provided"
        raise ConfigError(msg)
    unknown = {str(k) for k in node if str(k) not in _ALLOWED_UX_KEYS}
    if unknown:
        msg = f"Unknown repl.ux keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)
    markdown = bool_field(
        node,
        key="markdown",
        default=base.markdown,
        prefix="repl.ux.markdown",
    )
    reasoning = _reasoning_mode_field(node, default=base.reasoning)
    reasoning_summary_max_chars = nonneg_int_field(
        node,
        key="reasoning_summary_max_chars",
        default=base.reasoning_summary_max_chars,
        prefix="repl.ux.reasoning_summary_max_chars",
    )
    diffs = _diffs_mode_field(node, default=base.diffs)
    stream = _stream_mode_field(node, default=base.stream)
    verbosity = _verbosity_field(node, default=base.verbosity)
    return ReplUxConfig(
        markdown=markdown,
        reasoning=reasoning,
        reasoning_summary_max_chars=reasoning_summary_max_chars,
        diffs=diffs,
        stream=stream,
        verbosity=verbosity,
    )


def _normalize_transcript(
    node: JSONValue | None,
    base: ReplTranscriptConfig,
) -> ReplTranscriptConfig:
    if node is None:
        return base
    if not isinstance(node, Mapping):
        msg = "repl.transcript must be a mapping when provided"
        raise ConfigError(msg)
    unknown = {str(k) for k in node if str(k) not in _ALLOWED_TRANSCRIPT_KEYS}
    if unknown:
        msg = f"Unknown repl.transcript keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)
    tool_output_max_lines = nonneg_int_field(
        node,
        key="tool_output_max_lines",
        default=base.tool_output_max_lines,
        prefix="repl.transcript.tool_output_max_lines",
    )
    shell_preview_max_chars = nonneg_int_field(
        node,
        key="shell_preview_max_chars",
        default=base.shell_preview_max_chars,
        prefix="repl.transcript.shell_preview_max_chars",
    )
    tool_detail_max_lines = nonneg_int_field(
        node,
        key="tool_detail_max_lines",
        default=base.tool_detail_max_lines,
        prefix="repl.transcript.tool_detail_max_lines",
    )
    tool_detail_max_chars = nonneg_int_field(
        node,
        key="tool_detail_max_chars",
        default=base.tool_detail_max_chars,
        prefix="repl.transcript.tool_detail_max_chars",
    )
    mcp_args_preview_max_chars = nonneg_int_field(
        node,
        key="mcp_args_preview_max_chars",
        default=base.mcp_args_preview_max_chars,
        prefix="repl.transcript.mcp_args_preview_max_chars",
    )
    attachments_max_lines = nonneg_int_field(
        node,
        key="attachments_max_lines",
        default=base.attachments_max_lines,
        prefix="repl.transcript.attachments_max_lines",
    )
    attachments_path_max_chars = nonneg_int_field(
        node,
        key="attachments_path_max_chars",
        default=base.attachments_path_max_chars,
        prefix="repl.transcript.attachments_path_max_chars",
    )
    return ReplTranscriptConfig(
        tool_output_max_lines=tool_output_max_lines,
        shell_preview_max_chars=shell_preview_max_chars,
        tool_detail_max_lines=tool_detail_max_lines,
        tool_detail_max_chars=tool_detail_max_chars,
        mcp_args_preview_max_chars=mcp_args_preview_max_chars,
        attachments_max_lines=attachments_max_lines,
        attachments_path_max_chars=attachments_path_max_chars,
    )


def _normalize_ui(node: JSONValue | None, base: ReplUiConfig) -> ReplUiConfig:
    if node is None:
        return base
    if not isinstance(node, Mapping):
        msg = "repl.ui must be a mapping when provided"
        raise ConfigError(msg)
    unknown = {str(k) for k in node if str(k) not in _ALLOWED_UI_KEYS}
    if unknown:
        msg = f"Unknown repl.ui keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)

    theme = _theme_field(node, default=base.theme)
    color_depth = _color_depth_field(node, default=base.color_depth)
    editing_mode = _editing_mode_field(node, default=base.editing_mode)
    mouse = bool_field(node, key="mouse", default=base.mouse, prefix="repl.ui.mouse")
    completion = _completion_mode_field(node, default=base.completion)
    max_transcript_entries = nonneg_int_field(
        node,
        key="max_transcript_entries",
        default=base.max_transcript_entries,
        prefix="repl.ui.max_transcript_entries",
    )
    return ReplUiConfig(
        theme=theme,
        color_depth=color_depth,
        editing_mode=editing_mode,
        mouse=mouse,
        completion=completion,
        max_transcript_entries=max_transcript_entries,
    )


def normalize_repl(
    node: Mapping[str, JSONValue] | None,
    base: ReplConfig,
) -> ReplConfig:
    """Normalize repl config node into a ReplConfig instance."""
    if node is None:
        return base

    unknown = {str(k) for k in node if str(k) not in _ALLOWED_REPL_KEYS}
    if unknown:
        msg = f"Unknown repl keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)

    approvals = _normalize_approvals(node.get("approvals"), base.approvals)
    transcript = _normalize_transcript(node.get("transcript"), base.transcript)
    ui = _normalize_ui(node.get("ui"), base.ui)
    ux = _normalize_ux(node.get("ux"), base.ux)
    if (
        approvals == base.approvals
        and transcript == base.transcript
        and ui == base.ui
        and ux == base.ux
    ):
        return base
    return ReplConfig(
        approvals=approvals,
        ux=ux,
        transcript=transcript,
        ui=ui,
    )


__all__ = ("normalize_repl",)
