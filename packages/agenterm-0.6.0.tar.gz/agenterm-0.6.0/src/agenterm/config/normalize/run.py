"""Normalize run defaults."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.model import RunDefaults
from agenterm.config.normalize.validators import (
    bool_field,
    str_map_or_none,
    str_or_none,
)
from agenterm.constants.limits import (
    RUN_TOOL_ARGS_MAX_CHARS_MAX,
    RUN_TOOL_ARGS_MAX_CHARS_MIN,
)
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


_ALLOWED_RUN_KEYS: set[str] = {
    "background",
    "timeout_seconds",
    "progress_timeout_seconds",
    "tool_args_max_chars",
    "live",
    "json_output",
    "trace_enabled",
    "trace_id",
    "group_id",
    "trace_metadata",
    "trace_include_sensitive_data",
}


def _pos_float_or_none(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: float | None,
    prefix: str,
) -> float | None:
    raw = node.get(key, default)
    if raw is None:
        return None
    if isinstance(raw, (int, float)) and float(raw) > 0:
        return float(raw)
    msg = f"{prefix} must be a positive number or null"
    raise ConfigError(msg)


def _bounded_int_or_none(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int | None,
    prefix: str,
    minimum: int,
    maximum: int,
) -> int | None:
    raw = node.get(key, default)
    if raw is None:
        return None
    if isinstance(raw, int) and minimum <= raw <= maximum:
        return raw
    msg = f"{prefix} must be an integer between {minimum} and {maximum} or null"
    raise ConfigError(msg)


def normalize_run(
    node: Mapping[str, JSONValue] | None,
    base: RunDefaults,
) -> RunDefaults:
    """Normalize run defaults node into a RunDefaults instance."""
    if node is None:
        return base

    unknown = {str(k) for k in node if str(k) not in _ALLOWED_RUN_KEYS}
    if unknown:
        msg = f"Unknown run keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)

    timeout = _pos_float_or_none(
        node,
        key="timeout_seconds",
        default=base.timeout_seconds,
        prefix="run.timeout_seconds",
    )
    progress_timeout = _pos_float_or_none(
        node,
        key="progress_timeout_seconds",
        default=base.progress_timeout_seconds,
        prefix="run.progress_timeout_seconds",
    )
    tool_args_max_chars = _bounded_int_or_none(
        node,
        key="tool_args_max_chars",
        default=base.tool_args_max_chars,
        prefix="run.tool_args_max_chars",
        minimum=RUN_TOOL_ARGS_MAX_CHARS_MIN,
        maximum=RUN_TOOL_ARGS_MAX_CHARS_MAX,
    )
    live = bool_field(node, key="live", default=base.live, prefix="run.live")
    json_output = bool_field(
        node,
        key="json_output",
        default=base.json_output,
        prefix="run.json_output",
    )
    trace_enabled = bool_field(
        node,
        key="trace_enabled",
        default=base.trace_enabled,
        prefix="run.trace_enabled",
    )
    trace_id = str_or_none(
        node,
        key="trace_id",
        default=base.trace_id,
        prefix="run.trace_id",
    )
    group_id = str_or_none(
        node,
        key="group_id",
        default=base.group_id,
        prefix="run.group_id",
    )
    background = bool_field(
        node,
        key="background",
        default=base.background,
        prefix="run.background",
    )
    trace_metadata = str_map_or_none(
        node,
        key="trace_metadata",
        default=base.trace_metadata,
        prefix="run.trace_metadata",
    )
    trace_include_sensitive_data = bool_field(
        node,
        key="trace_include_sensitive_data",
        default=base.trace_include_sensitive_data,
        prefix="run.trace_include_sensitive_data",
    )

    return RunDefaults(
        background=background,
        timeout_seconds=timeout,
        progress_timeout_seconds=progress_timeout,
        tool_args_max_chars=tool_args_max_chars,
        live=live,
        json_output=json_output,
        trace_enabled=trace_enabled,
        trace_id=trace_id,
        group_id=group_id,
        trace_metadata=trace_metadata,
        trace_include_sensitive_data=trace_include_sensitive_data,
    )


__all__ = ("normalize_run",)
