"""Normalize MCP configuration."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.config.model import (
    McpConfig,
    McpServerConfig,
    McpServerRuntimeConfig,
    McpServerSseConfig,
    McpServerStdioConfig,
    McpServerStreamableHttpConfig,
    McpToolFilterConfig,
)
from agenterm.config.normalize.mcp_bridge import normalize_mcp_bridge
from agenterm.config.normalize.mcp_connectors import normalize_mcp_connectors
from agenterm.config.normalize.mcp_expose import normalize_mcp_expose
from agenterm.config.normalize.validators import validate_allowed_keys
from agenterm.core.choices.mcp import (
    MCP_SERVER_KINDS,
    McpServerKind,
    parse_encoding_error_handler,
    parse_mcp_server_kind,
)
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_json_object, as_str_dict, as_str_list

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

_ALLOWED_MCP_ROOT_KEYS: set[str] = {
    "servers",
    "connectors",
    "bridge",
    "convert_schemas_to_strict",
    "expose",
}
_ALLOWED_MCP_SERVER_KEYS: set[str] = {
    "key",
    "kind",
    "name",
    "tool_filter",
    "use_structured_content",
    "message_handler_key",
    "stdio",
    "sse",
    "streamable_http",
    "runtime",
}


def _build_runtime(node: JSONValue | None) -> McpServerRuntimeConfig | None:
    typed = as_json_object(node)
    if typed is None:
        return None
    allowed = {"cache_tools", "session_timeout"}
    unknown = {str(k) for k in typed if str(k) not in allowed}
    if unknown:
        msg = f"mcp server runtime contains unknown keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)
    base = McpServerRuntimeConfig()
    out = base

    cache_tools = typed.get("cache_tools")
    if isinstance(cache_tools, bool):
        out = replace(out, cache_tools=cache_tools)

    session_timeout = typed.get("session_timeout")
    if isinstance(session_timeout, (int, float)):
        out = replace(out, session_timeout=float(session_timeout))
    elif session_timeout is None and "session_timeout" in typed:
        out = replace(out, session_timeout=None)

    return out


def _build_tool_filter(node: JSONValue | None) -> McpToolFilterConfig | None:
    typed = as_json_object(node)
    if typed is None:
        return None
    allowed = {"allowed_tool_names", "blocked_tool_names", "callable_key"}
    unknown = {str(k) for k in typed if str(k) not in allowed}
    if unknown:
        msg = (
            "mcp server tool_filter contains unknown keys: "
            f"{', '.join(sorted(unknown))}"
        )
        raise ConfigError(msg)
    allowed = as_str_list(typed.get("allowed_tool_names"))
    blocked = as_str_list(typed.get("blocked_tool_names"))
    callable_key_raw = typed.get("callable_key")
    callable_key = (
        callable_key_raw.strip()
        if isinstance(callable_key_raw, str) and callable_key_raw.strip()
        else None
    )
    if not allowed and not blocked and callable_key is None:
        return None
    return McpToolFilterConfig(
        allowed_tool_names=allowed or None,
        blocked_tool_names=blocked or None,
        callable_key=callable_key,
    )


def _build_stdio(node: JSONValue | None) -> McpServerStdioConfig | None:
    typed = as_json_object(node)
    if typed is None:
        return None
    validate_allowed_keys(
        typed,
        allowed={
            "command",
            "args",
            "env",
            "cwd",
            "encoding",
            "encoding_error_handler",
        },
        prefix="mcp.servers[].stdio",
    )
    command_raw = typed.get("command")
    if not isinstance(command_raw, str) or not command_raw:
        return None
    args_raw = typed.get("args")
    args = [str(a) for a in args_raw] if isinstance(args_raw, list) else []
    env = as_str_dict(typed.get("env"))
    cwd_raw = typed.get("cwd")
    cwd = Path(cwd_raw).expanduser().resolve() if isinstance(cwd_raw, str) else None
    encoding_raw = typed.get("encoding", "utf-8")
    encoding = encoding_raw if isinstance(encoding_raw, str) else "utf-8"
    handler_raw = typed.get("encoding_error_handler", "strict")
    if not isinstance(handler_raw, str):
        msg = "mcp.servers[].stdio.encoding_error_handler must be strict|ignore|replace"
        raise ConfigError(msg)
    handler = parse_encoding_error_handler(handler_raw)
    if handler is None:
        msg = "mcp.servers[].stdio.encoding_error_handler must be strict|ignore|replace"
        raise ConfigError(msg)
    return McpServerStdioConfig(
        command=command_raw,
        args=args,
        env=env,
        cwd=cwd,
        encoding=encoding,
        encoding_error_handler=handler,
    )


def _build_sse(node: JSONValue | None) -> McpServerSseConfig | None:
    typed = as_json_object(node)
    if typed is None:
        return None
    validate_allowed_keys(
        typed,
        allowed={"url", "headers", "timeout", "sse_read_timeout"},
        prefix="mcp.servers[].sse",
    )
    url_raw = typed.get("url")
    if not isinstance(url_raw, str) or not url_raw:
        return None
    timeout = typed.get("timeout")
    read_timeout = typed.get("sse_read_timeout")
    return McpServerSseConfig(
        url=url_raw,
        headers=as_str_dict(typed.get("headers")),
        timeout=float(timeout) if isinstance(timeout, (int, float)) else None,
        sse_read_timeout=float(read_timeout)
        if isinstance(read_timeout, (int, float))
        else None,
    )


def _build_streamable_http(
    node: JSONValue | None,
) -> McpServerStreamableHttpConfig | None:
    typed = as_json_object(node)
    if typed is None:
        return None
    validate_allowed_keys(
        typed,
        allowed={
            "url",
            "headers",
            "timeout",
            "sse_read_timeout",
            "terminate_on_close",
            "httpx_client_factory_key",
        },
        prefix="mcp.servers[].streamable_http",
    )
    url_raw = typed.get("url")
    if not isinstance(url_raw, str) or not url_raw:
        return None
    timeout = typed.get("timeout")
    read_timeout = typed.get("sse_read_timeout")
    terminate = typed.get("terminate_on_close")
    httpx_factory_key_raw = typed.get("httpx_client_factory_key")
    httpx_factory_key = (
        httpx_factory_key_raw.strip()
        if isinstance(httpx_factory_key_raw, str) and httpx_factory_key_raw.strip()
        else None
    )
    return McpServerStreamableHttpConfig(
        url=url_raw,
        headers=as_str_dict(typed.get("headers")),
        timeout=float(timeout) if isinstance(timeout, (int, float)) else None,
        sse_read_timeout=float(read_timeout)
        if isinstance(read_timeout, (int, float))
        else None,
        terminate_on_close=bool(terminate) if isinstance(terminate, bool) else None,
        httpx_client_factory_key=httpx_factory_key,
    )


def _parse_server_mapping(raw: JSONValue, *, index: int) -> dict[str, JSONValue]:
    raw_typed = as_json_object(raw)
    if raw_typed is None:
        msg = f"mcp.servers[{index}] must be a mapping"
        raise ConfigError(msg)
    validate_allowed_keys(
        raw_typed,
        allowed=_ALLOWED_MCP_SERVER_KEYS,
        prefix=f"mcp.servers[{index}]",
    )
    return raw_typed


def _parse_required_str(
    raw_typed: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
) -> str:
    raw = raw_typed.get(key)
    if not isinstance(raw, str) or not raw.strip():
        msg = f"{prefix} must be a non-empty string"
        raise ConfigError(msg)
    return raw.strip()


def _parse_server_kind(
    raw_typed: Mapping[str, JSONValue],
    *,
    index: int,
) -> McpServerKind:
    kind_raw = raw_typed.get("kind")
    if isinstance(kind_raw, str):
        parsed = parse_mcp_server_kind(kind_raw)
        if parsed is not None:
            return parsed
    msg = f"mcp.servers[{index}].kind must be one of: {', '.join(MCP_SERVER_KINDS)}"
    raise ConfigError(msg)


def _parse_optional_trimmed_str(
    raw_typed: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
) -> str | None:
    raw = raw_typed.get(key)
    if raw is None:
        return None
    if isinstance(raw, str):
        return raw.strip() or None
    msg = f"{prefix} must be a string or null"
    raise ConfigError(msg)


def _parse_bool_default(
    raw_typed: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
    default: bool,
) -> bool:
    if key not in raw_typed:
        return default
    raw = raw_typed.get(key)
    if isinstance(raw, bool):
        return raw
    msg = f"{prefix} must be a boolean"
    raise ConfigError(msg)


def _parse_tool_filter(
    raw_typed: Mapping[str, JSONValue],
    *,
    index: int,
) -> McpToolFilterConfig | None:
    tool_filter_raw = raw_typed.get("tool_filter")
    if tool_filter_raw is None:
        return None
    if not isinstance(tool_filter_raw, dict):
        msg = f"mcp.servers[{index}].tool_filter must be a mapping or null"
        raise ConfigError(msg)
    return _build_tool_filter(tool_filter_raw)


def _parse_runtime(
    raw_typed: Mapping[str, JSONValue],
    *,
    index: int,
) -> McpServerRuntimeConfig:
    runtime_raw = raw_typed.get("runtime")
    if runtime_raw is None:
        return McpServerRuntimeConfig()
    if not isinstance(runtime_raw, dict):
        msg = f"mcp.servers[{index}].runtime must be a mapping or null"
        raise ConfigError(msg)
    runtime = _build_runtime(runtime_raw)
    if runtime is None:
        msg = f"mcp.servers[{index}].runtime must be a mapping"
        raise ConfigError(msg)
    return runtime


def _build_transport_configs(
    kind: McpServerKind,
    raw_typed: Mapping[str, JSONValue],
    *,
    server_key: str,
) -> tuple[
    McpServerStdioConfig | None,
    McpServerSseConfig | None,
    McpServerStreamableHttpConfig | None,
]:
    if kind == "stdio":
        stdio = _build_stdio(raw_typed.get("stdio"))
        if stdio is None:
            msg = f"mcp server {server_key}: stdio config is required for kind=stdio"
            raise ConfigError(msg)
        return stdio, None, None
    if kind == "sse":
        sse = _build_sse(raw_typed.get("sse"))
        if sse is None:
            msg = f"mcp server {server_key}: sse config is required for kind=sse"
            raise ConfigError(msg)
        return None, sse, None
    sh = _build_streamable_http(raw_typed.get("streamable_http"))
    if sh is None:
        msg = (
            f"mcp server {server_key}: streamable_http config is required for "
            "kind=streamable_http"
        )
        raise ConfigError(msg)
    return None, None, sh


def _parse_server(raw: JSONValue, *, index: int) -> McpServerConfig:
    raw_typed = _parse_server_mapping(raw, index=index)
    server_key = _parse_required_str(
        raw_typed,
        key="key",
        prefix=f"mcp.servers[{index}].key",
    )
    kind_literal = _parse_server_kind(raw_typed, index=index)
    name = _parse_optional_trimmed_str(
        raw_typed,
        key="name",
        prefix=f"mcp.servers[{index}].name",
    )
    use_structured_content = _parse_bool_default(
        raw_typed,
        key="use_structured_content",
        prefix=f"mcp.servers[{index}].use_structured_content",
        default=False,
    )
    message_handler_key = _parse_optional_trimmed_str(
        raw_typed,
        key="message_handler_key",
        prefix=f"mcp.servers[{index}].message_handler_key",
    )
    tool_filter = _parse_tool_filter(raw_typed, index=index)
    runtime = _parse_runtime(raw_typed, index=index)
    stdio_conf, sse_conf, sh_conf = _build_transport_configs(
        kind_literal,
        raw_typed,
        server_key=server_key,
    )
    return McpServerConfig(
        key=server_key,
        kind=kind_literal,
        name=name,
        tool_filter=tool_filter,
        use_structured_content=use_structured_content,
        message_handler_key=message_handler_key,
        stdio=stdio_conf,
        sse=sse_conf,
        streamable_http=sh_conf,
        runtime=runtime,
    )


def _ensure_unique_server_keys(servers: list[McpServerConfig]) -> None:
    seen_keys: set[str] = set()
    for server in servers:
        if server.key in seen_keys:
            msg = f"Duplicate MCP server key: {server.key}"
            raise ConfigError(msg)
        seen_keys.add(server.key)


def _normalize_servers(node: Mapping[str, JSONValue]) -> list[McpServerConfig]:
    servers_node = node.get("servers")
    if servers_node is None:
        return []
    if not isinstance(servers_node, list):
        msg = "mcp.servers must be a list when provided"
        raise ConfigError(msg)
    servers = [_parse_server(raw, index=i) for i, raw in enumerate(servers_node)]
    _ensure_unique_server_keys(servers)
    return servers


def normalize_mcp(node: Mapping[str, JSONValue] | None) -> McpConfig:
    """Normalize MCP server and connector configuration."""
    if node is None:
        return McpConfig()
    validate_allowed_keys(node, allowed=_ALLOWED_MCP_ROOT_KEYS, prefix="mcp")
    bridge = normalize_mcp_bridge(node)
    expose = normalize_mcp_expose(node)
    servers = _normalize_servers(node)
    connectors = (
        normalize_mcp_connectors(node.get("connectors")) if "connectors" in node else []
    )

    convert_schemas_to_strict = True
    if "convert_schemas_to_strict" in node:
        raw = node.get("convert_schemas_to_strict")
        if not isinstance(raw, bool):
            msg = "mcp.convert_schemas_to_strict must be a boolean"
            raise ConfigError(msg)
        if not raw:
            msg = (
                "mcp.convert_schemas_to_strict must be true; "
                "agenterm enforces strict MCP schemas."
            )
            raise ConfigError(msg)
        convert_schemas_to_strict = raw

    return McpConfig(
        servers=servers,
        connectors=connectors,
        convert_schemas_to_strict=convert_schemas_to_strict,
        bridge=bridge,
        expose=expose,
    )


__all__ = ("normalize_mcp",)
