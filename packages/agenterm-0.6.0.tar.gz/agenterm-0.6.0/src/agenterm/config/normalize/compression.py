"""Normalize compression configuration."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.compression import (
    CompressionConfig,
    CompressionDropPolicy,
    CompressionPrimaryBranch,
    CompressionStrategy,
    CompressionTrigger,
)
from agenterm.config.normalize.validators import validate_allowed_keys
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_float, as_str

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


_ALLOWED_KEYS: set[str] = {
    "strategy",
    "trigger",
    "threshold_percent",
    "primary_branch",
    "drop_policy",
}


def _ratio_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: float,
    prefix: str,
) -> float:
    raw = node.get(key)
    if raw is None:
        return default
    if raw == "":
        return default
    ratio = as_float(raw)
    if ratio is not None and 0 < ratio <= 1:
        return ratio
    msg = f"{prefix} must be a number in (0, 1]"
    raise ConfigError(msg)


def _normalize_strategy(
    raw: JSONValue | None,
    *,
    default: CompressionStrategy,
    prefix: str,
) -> CompressionStrategy:
    parsed = as_str(raw)
    if parsed is None:
        return default
    if parsed == "snapshot":
        return "snapshot"
    if parsed == "compaction_if_supported":
        return "compaction_if_supported"
    if parsed == "both_if_supported":
        return "both_if_supported"
    msg = f"{prefix} must be snapshot|compaction_if_supported|both_if_supported"
    raise ConfigError(msg)


def _normalize_trigger(
    raw: JSONValue | None,
    *,
    default: CompressionTrigger,
    prefix: str,
) -> CompressionTrigger:
    parsed = as_str(raw)
    if parsed is None:
        return default
    if parsed == "ask":
        return "ask"
    if parsed == "auto":
        return "auto"
    msg = f"{prefix} must be ask|auto"
    raise ConfigError(msg)


def _normalize_primary_branch(
    raw: JSONValue | None,
    *,
    default: CompressionPrimaryBranch,
    prefix: str,
) -> CompressionPrimaryBranch:
    parsed = as_str(raw)
    if parsed is None:
        return default
    if parsed == "snapshot":
        return "snapshot"
    if parsed == "compaction":
        return "compaction"
    msg = f"{prefix} must be snapshot|compaction"
    raise ConfigError(msg)


def _normalize_drop_policy(
    raw: JSONValue | None,
    *,
    default: CompressionDropPolicy,
    prefix: str,
) -> CompressionDropPolicy:
    parsed = as_str(raw)
    if parsed is None:
        return default
    if parsed == "ask":
        return "ask"
    if parsed == "deny":
        return "deny"
    if parsed == "allow":
        return "allow"
    msg = f"{prefix} must be ask|deny|allow"
    raise ConfigError(msg)


def normalize_compression(
    node: Mapping[str, JSONValue] | None,
    base: CompressionConfig,
) -> CompressionConfig:
    """Normalize the compression section."""
    if node is None:
        return base
    validate_allowed_keys(node, allowed=_ALLOWED_KEYS, prefix="compression")
    strategy = _normalize_strategy(
        node.get("strategy", base.strategy),
        default=base.strategy,
        prefix="compression.strategy",
    )
    trigger = _normalize_trigger(
        node.get("trigger", base.trigger),
        default=base.trigger,
        prefix="compression.trigger",
    )
    threshold_percent = _ratio_field(
        node,
        key="threshold_percent",
        default=base.threshold_percent,
        prefix="compression.threshold_percent",
    )
    primary_branch = _normalize_primary_branch(
        node.get("primary_branch", base.primary_branch),
        default=base.primary_branch,
        prefix="compression.primary_branch",
    )
    drop_policy = _normalize_drop_policy(
        node.get("drop_policy", base.drop_policy),
        default=base.drop_policy,
        prefix="compression.drop_policy",
    )
    return CompressionConfig(
        strategy=strategy,
        trigger=trigger,
        threshold_percent=threshold_percent,
        primary_branch=primary_branch,
        drop_policy=drop_policy,
    )


__all__ = ("normalize_compression",)
