"""Normalize agent section."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.agent_files import normalize_agent_name
from agenterm.config.model import AgentConfig
from agenterm.core.errors import ConfigError, ValidationError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


def _normalize_positive_int(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int,
    prefix: str,
) -> int:
    raw = node.get(key, default)
    if not isinstance(raw, int) or raw <= 0:
        msg = f"{prefix} must be a positive integer"
        raise ConfigError(msg)
    return int(raw)


def normalize_agent(
    node: Mapping[str, JSONValue] | None,
    base: AgentConfig,
) -> AgentConfig:
    """Normalize the agent block onto the provided base config."""
    if node is None:
        return base

    allowed = {"name", "model", "max_turns"}
    unknown = {str(k) for k in node if str(k) not in allowed}
    if unknown:
        msg = f"Unknown agent keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)

    name_obj = node.get("name", base.name)
    if not isinstance(name_obj, str):
        msg = "agent.name must be a string"
        raise ConfigError(msg)
    try:
        name = normalize_agent_name(name_obj)
    except ValidationError as exc:
        msg = f"agent.name {exc}"
        raise ConfigError(msg) from exc

    model_obj = node.get("model", base.model)
    if not isinstance(model_obj, str) or not model_obj.strip():
        msg = "agent.model must be a non-empty string"
        raise ConfigError(msg)

    max_turns_int = _normalize_positive_int(
        node,
        key="max_turns",
        default=base.max_turns,
        prefix="agent.max_turns",
    )

    return AgentConfig(
        name=name,
        model=model_obj.strip(),
        max_turns=max_turns_int,
        instructions=base.instructions,
        path=base.path,
        source=base.source,
        explicit=base.explicit,
    )


__all__ = ("normalize_agent",)
