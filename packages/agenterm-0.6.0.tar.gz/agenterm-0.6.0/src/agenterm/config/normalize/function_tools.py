"""Normalize function tool configuration.

Function tools are user-defined Python tools registered in code and enabled via
`tools.function_tools` in config.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.model import FunctionToolConfig
from agenterm.config.normalize.tools_helpers import (
    as_json_object,
    validate_allowed_keys,
)
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


def normalize_function_tools(seq: JSONValue | None) -> list[FunctionToolConfig]:
    """Normalize tools.function_tools list from YAML."""
    out: list[FunctionToolConfig] = []
    if not isinstance(seq, list):
        return out
    for raw in seq:
        raw_map = as_json_object(raw)
        if raw_map is None:
            msg = "tools.function_tools[] must be a mapping"
            raise ConfigError(msg)
        validate_allowed_keys(
            raw_map,
            allowed={"name"},
            prefix="tools.function_tools[]",
        )
        name = raw_map.get("name")
        if not isinstance(name, str) or not name.strip():
            msg = "tools.function_tools[].name must be a non-empty string"
            raise ConfigError(msg)
        out.append(FunctionToolConfig(name=name.strip()))
    return out


__all__ = ("normalize_function_tools",)
