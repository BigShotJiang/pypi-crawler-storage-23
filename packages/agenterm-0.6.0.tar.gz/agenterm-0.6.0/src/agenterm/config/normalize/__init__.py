"""Normalization pipeline for config sections."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.config.model import (
    AgentConfig,
    AppConfig,
    AttachmentsConfig,
    CompressionConfig,
    GuardrailsConfig,
    McpConfig,
    ModelConfig,
    ProvidersConfig,
    ReplConfig,
    RunDefaults,
    StewardConfig,
    ToolsConfig,
)
from agenterm.config.normalize.agent import normalize_agent
from agenterm.config.normalize.attachments import normalize_attachments
from agenterm.config.normalize.compression import normalize_compression
from agenterm.config.normalize.guardrails import normalize_guardrails
from agenterm.config.normalize.mcp import normalize_mcp
from agenterm.config.normalize.model import normalize_model
from agenterm.config.normalize.providers import normalize_providers
from agenterm.config.normalize.repl import normalize_repl
from agenterm.config.normalize.retries import normalize_retries
from agenterm.config.normalize.run import normalize_run
from agenterm.config.normalize.steward import normalize_steward
from agenterm.config.normalize.tools import normalize_tools
from agenterm.config.retries import RetriesConfig

if TYPE_CHECKING:
    from agenterm.config.schema import RawConfig


@dataclass(frozen=True)
class NormalizedConfig:
    """Fully normalized configuration ready for validation/runtime."""

    agent: AgentConfig
    model: ModelConfig
    providers: ProvidersConfig
    retries: RetriesConfig
    compression: CompressionConfig
    attachments: AttachmentsConfig
    steward: StewardConfig
    tools: ToolsConfig
    mcp: McpConfig
    run: RunDefaults
    repl: ReplConfig
    guardrails: GuardrailsConfig


def normalize_config(raw: RawConfig) -> NormalizedConfig:
    """Normalize a raw config object into concrete runtime models."""
    agent_cfg = normalize_agent(raw.agent, AgentConfig())
    model_cfg = normalize_model(raw.model, ModelConfig())
    providers_cfg = normalize_providers(raw.providers, ProvidersConfig())
    retries_cfg = normalize_retries(raw.retries, RetriesConfig())
    compression_cfg = normalize_compression(raw.compression, CompressionConfig())
    attachments_cfg = normalize_attachments(raw.attachments, AttachmentsConfig())
    steward_cfg = normalize_steward(raw.steward, StewardConfig())
    tools_cfg = normalize_tools(raw.tools)
    mcp_cfg = normalize_mcp(raw.mcp)
    run_cfg = normalize_run(raw.run, RunDefaults())
    repl_cfg = normalize_repl(raw.repl, ReplConfig())
    guardrails_cfg = normalize_guardrails(raw.guardrails)

    return NormalizedConfig(
        agent=agent_cfg,
        model=model_cfg,
        providers=providers_cfg,
        retries=retries_cfg,
        compression=compression_cfg,
        attachments=attachments_cfg,
        steward=steward_cfg,
        tools=tools_cfg,
        mcp=mcp_cfg,
        run=run_cfg,
        repl=repl_cfg,
        guardrails=guardrails_cfg,
    )


def to_app_config(normalized: NormalizedConfig) -> AppConfig:
    """Convert a normalized config into the AppConfig runtime model."""
    return AppConfig(
        agent=normalized.agent,
        model=normalized.model,
        providers=normalized.providers,
        retries=normalized.retries,
        compression=normalized.compression,
        attachments=normalized.attachments,
        steward=normalized.steward,
        tools=normalized.tools,
        mcp=normalized.mcp,
        run=normalized.run,
        repl=normalized.repl,
        guardrails=normalized.guardrails,
    )


__all__ = ("NormalizedConfig", "normalize_config", "to_app_config")
