"""Shared validation helpers for config normalization."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Literal, overload

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import (
    as_bool,
    as_float,
    as_int,
    as_json_object,
    as_str,
    as_str_dict,
    as_str_list,
)

if TYPE_CHECKING:
    from agenterm.config.text_format import TextFormat, TextFormatJSONSchema
    from agenterm.core.json_types import JSONValue


def validate_allowed_keys(
    node: Mapping[str, JSONValue],
    *,
    allowed: set[str],
    prefix: str,
) -> None:
    """Raise ConfigError when node contains keys outside allowed."""
    unknown = {str(key) for key in node if str(key) not in allowed}
    if unknown:
        message = f"{prefix} contains unknown keys: {', '.join(sorted(unknown))}"
        raise ConfigError(message)


@overload
def bool_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: bool,
    prefix: str,
    allow_none: Literal[False] = False,
) -> bool: ...


@overload
def bool_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: bool | None,
    prefix: str,
    allow_none: Literal[True],
) -> bool | None: ...


def bool_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: bool | None,
    prefix: str,
    allow_none: bool = False,
) -> bool | None:
    """Return a boolean field (optionally nullable)."""
    if key not in node:
        return default
    raw = node.get(key)
    if raw is None:
        if allow_none:
            return None
        msg = f"{prefix} must be a boolean"
        raise ConfigError(msg)
    value = as_bool(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be a boolean"
    if allow_none:
        msg = f"{prefix} must be a boolean when provided"
    raise ConfigError(msg)


def float_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: float | None,
    prefix: str,
) -> float | None:
    """Return a float field or None."""
    if key not in node:
        return default
    raw = node.get(key)
    if raw is None:
        return None
    value = as_float(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be a number or null when provided"
    raise ConfigError(msg)


def int_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int | None,
    prefix: str,
) -> int | None:
    """Return an int field or None."""
    if key not in node:
        return default
    raw = node.get(key)
    if raw is None:
        return None
    value = as_int(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be an integer or null when provided"
    raise ConfigError(msg)


def nonneg_int_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int,
    prefix: str,
) -> int:
    """Return a non-negative int field."""
    raw = node.get(key, default)
    value = as_int(raw)
    if value is None:
        msg = f"{prefix} must be an integer"
        raise ConfigError(msg)
    if value < 0:
        msg = f"{prefix} must be non-negative"
        raise ConfigError(msg)
    return value


def str_or_none(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: str | None,
    prefix: str,
) -> str | None:
    """Return a string field or None."""
    raw = node.get(key, default)
    if raw is None:
        return None
    value = as_str(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be a string or null"
    raise ConfigError(msg)


def str_map_or_none(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: Mapping[str, str] | None,
    prefix: str,
) -> Mapping[str, str] | None:
    """Return a mapping of string keys/values or None."""
    raw = node.get(key, default)
    if raw is None:
        return None
    if isinstance(raw, Mapping):
        typed: dict[str, JSONValue] = {str(k): v for k, v in raw.items()}
        value = as_str_dict(typed)
    else:
        value = as_str_dict(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be a mapping or null"
    raise ConfigError(msg)


def _require_json_mapping(
    raw: JSONValue | Mapping[str, JSONValue],
    *,
    prefix: str,
) -> dict[str, JSONValue]:
    if not isinstance(raw, Mapping):
        msg = f"{prefix} must be a mapping with type 'text' or 'json_schema'"
        raise ConfigError(msg)
    raw_map = as_json_object(raw)
    if raw_map is None:
        msg = f"{prefix} must contain only JSON values"
        raise ConfigError(msg)
    return raw_map


def _require_non_empty_str(raw: JSONValue | None, *, prefix: str) -> str:
    value = as_str(raw)
    if value is None or not value:
        msg = f"{prefix} must be a non-empty string"
        raise ConfigError(msg)
    return value


def _optional_bool(raw: JSONValue | None, *, prefix: str) -> bool | None:
    if raw is None:
        return None
    value = as_bool(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be a boolean when provided"
    raise ConfigError(msg)


def _optional_str(raw: JSONValue | None, *, prefix: str) -> str | None:
    if raw is None:
        return None
    value = as_str(raw)
    if value is not None:
        return value
    msg = f"{prefix} must be a string when provided"
    raise ConfigError(msg)


def _require_schema_map(
    raw: JSONValue | None,
    *,
    prefix: str,
) -> dict[str, JSONValue]:
    if not isinstance(raw, Mapping):
        msg = f"{prefix} must be a mapping"
        raise ConfigError(msg)
    schema_map = as_json_object(raw)
    if schema_map is None:
        msg = f"{prefix} must be a JSON object"
        raise ConfigError(msg)
    return schema_map


def _parse_text_format_json_schema(
    raw_map: Mapping[str, JSONValue],
    *,
    prefix: str,
) -> TextFormatJSONSchema:
    validate_allowed_keys(
        raw_map,
        allowed={"type", "name", "schema", "strict", "description"},
        prefix=prefix,
    )
    name = _require_non_empty_str(raw_map.get("name"), prefix=f"{prefix}.name")
    schema = _require_schema_map(raw_map.get("schema"), prefix=f"{prefix}.schema")
    strict = _optional_bool(raw_map.get("strict"), prefix=f"{prefix}.strict")
    description = _optional_str(
        raw_map.get("description"),
        prefix=f"{prefix}.description",
    )
    out: TextFormatJSONSchema = {
        "type": "json_schema",
        "name": name,
        "schema": schema,
    }
    if strict is not None:
        out["strict"] = strict
    if description is not None:
        out["description"] = description
    return out


def text_format_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: TextFormat | None,
    prefix: str,
) -> TextFormat | None:
    """Return a strict text_format mapping or None."""
    if key not in node:
        return default
    raw = node.get(key)
    if raw is None:
        return None
    raw_map = _require_json_mapping(raw, prefix=prefix)
    type_raw = raw_map.get("type")
    if type_raw == "text":
        validate_allowed_keys(
            raw_map,
            allowed={"type"},
            prefix=prefix,
        )
        return {"type": "text"}
    if type_raw != "json_schema":
        msg = f"{prefix} must be a mapping with type 'text' or 'json_schema'"
        raise ConfigError(msg)
    return _parse_text_format_json_schema(raw_map, prefix=prefix)


def optional_positive_int_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int | None,
    prefix: str,
) -> int | None:
    """Return a positive integer or None."""
    raw = node.get(key, default)
    if raw is None:
        return None
    value = as_int(raw)
    if value is not None and value > 0:
        return value
    msg = f"{prefix} must be a positive integer or null"
    raise ConfigError(msg)


def normalize_str_list_section(
    root: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
    base_value: list[str],
) -> list[str]:
    """Normalize a list-of-strings section, allowing null to mean empty."""
    if key not in root:
        return base_value
    raw = root.get(key)
    if raw is None:
        return []
    out = as_str_list(raw, strip=False, drop_empty=False)
    if out is None:
        msg = f"{prefix} must be a list of strings"
        raise ConfigError(msg)
    return out


def normalize_str_list_value(
    value: JSONValue | None,
    *,
    prefix: str,
) -> list[str]:
    """Normalize a list-of-strings value, allowing null to mean empty."""
    if value is None:
        return []
    out = as_str_list(value, strip=False, drop_empty=False)
    if out is None:
        msg = f"{prefix} must be a list of strings"
        raise ConfigError(msg)
    return out


__all__ = (
    "bool_field",
    "float_field",
    "int_field",
    "nonneg_int_field",
    "normalize_str_list_section",
    "normalize_str_list_value",
    "optional_positive_int_field",
    "str_map_or_none",
    "str_or_none",
    "text_format_field",
    "validate_allowed_keys",
)
