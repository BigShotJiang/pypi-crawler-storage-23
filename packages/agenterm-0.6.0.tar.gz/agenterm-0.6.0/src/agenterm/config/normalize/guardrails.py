"""Normalize guardrails selection."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.model import GuardrailsConfig
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


def normalize_guardrails(node: Mapping[str, JSONValue] | None) -> GuardrailsConfig:
    """Normalize guardrails input/output lists."""
    base = GuardrailsConfig()
    if node is None:
        return base

    allowed = {"load_modules", "input", "output"}
    unknown = {str(k) for k in node if str(k) not in allowed}
    if unknown:
        msg = f"Unknown guardrails keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)

    raw_modules = node.get("load_modules", base.load_modules)
    if raw_modules is None:
        load_modules: list[str] = []
    elif isinstance(raw_modules, list):
        load_modules = [str(x) for x in raw_modules]
    else:
        msg = "guardrails.load_modules must be a list or null"
        raise ConfigError(msg)

    gi = node.get("input", base.input)
    if gi is None:
        guard_in: list[str] = []
    elif isinstance(gi, list):
        guard_in = [str(x) for x in gi]
    else:
        msg = "guardrails.input must be a list or null"
        raise ConfigError(msg)

    go = node.get("output", base.output)
    if go is None:
        guard_out: list[str] = []
    elif isinstance(go, list):
        guard_out = [str(x) for x in go]
    else:
        msg = "guardrails.output must be a list or null"
        raise ConfigError(msg)

    return GuardrailsConfig(load_modules=load_modules, input=guard_in, output=guard_out)


__all__ = ("normalize_guardrails",)
