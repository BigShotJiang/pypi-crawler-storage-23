"""Normalize tools configuration into typed ToolConfig objects."""

from __future__ import annotations

from collections.abc import Callable, Mapping, MutableMapping
from typing import TYPE_CHECKING

from agenterm.config.model import (
    AgentRunReportToolConfig,
    AgentRunToolConfig,
    DangerousToolsConfig,
    InspectToolConfig,
    PlanToolConfig,
    ShellToolConfig,
    ToolsConfig,
)
from agenterm.config.normalize.function_tools import normalize_function_tools
from agenterm.config.normalize.tools_families import (
    normalize_agent_run,
    normalize_agent_run_report,
    normalize_apply_patch,
    normalize_file_search,
    normalize_inspect,
    normalize_plan,
    normalize_web_search,
)
from agenterm.config.normalize.tools_helpers import (
    as_json_object,
    validate_allowed_keys,
)
from agenterm.config.normalize.tools_image_generation import normalize_image_generation
from agenterm.config.normalize.tools_shell import normalize_shell
from agenterm.config.normalize.validators import (
    nonneg_int_field,
    normalize_str_list_section,
    normalize_str_list_value,
)
from agenterm.config.tool_bundles import ToolBundleConfig, ToolBundleScope
from agenterm.config.tool_models import (
    ApplyPatchToolConfig,
    FileSearchToolConfig,
    ImageGenerationToolConfig,
    WebSearchToolConfig,
)
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


def _normalize_optional_mapping_section[T](
    root: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
    base_value: T | None,
    factory: Callable[[], T],
    normalizer: Callable[[Mapping[str, JSONValue], T], T],
) -> T | None:
    if key not in root:
        return base_value
    raw = root.get(key)
    if raw is None:
        return None
    if not isinstance(raw, Mapping):
        msg = f"{prefix} must be a mapping or null"
        raise ConfigError(msg)
    raw_map = as_json_object(raw)
    if raw_map is None:
        msg = f"{prefix} must contain only JSON values"
        raise ConfigError(msg)
    return normalizer(raw_map, base_value or factory())


def _normalize_list_section[T](
    root: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
    base_value: list[T],
    normalizer: Callable[[JSONValue | None], list[T]],
) -> list[T]:
    if key not in root:
        return base_value
    raw = root.get(key)
    if raw is None:
        return []
    if not isinstance(raw, list):
        msg = f"{prefix} must be a list when provided"
        raise ConfigError(msg)
    return normalizer(raw)


def _normalize_dangerous_overrides(
    root: Mapping[str, JSONValue],
    base: DangerousToolsConfig,
) -> DangerousToolsConfig:
    if "dangerous" not in root:
        return base
    raw = root.get("dangerous")
    if raw is None:
        return DangerousToolsConfig()
    if not isinstance(raw, Mapping):
        msg = "tools.dangerous must be a mapping or null"
        raise ConfigError(msg)
    raw_map = as_json_object(raw)
    if raw_map is None:
        msg = "tools.dangerous must contain only JSON values"
        raise ConfigError(msg)
    validate_allowed_keys(
        raw_map,
        allowed={"add", "remove"},
        prefix="tools.dangerous",
    )
    add = normalize_str_list_value(
        raw_map.get("add"),
        prefix="tools.dangerous.add",
    )
    remove = normalize_str_list_value(
        raw_map.get("remove"),
        prefix="tools.dangerous.remove",
    )
    return DangerousToolsConfig(add=add, remove=remove)


def _normalize_bundle_scope(
    value: JSONValue | None,
    *,
    prefix: str,
    default: ToolBundleScope,
) -> ToolBundleScope:
    raw = value if value is not None else default
    if not isinstance(raw, str):
        msg = f"{prefix} must be 'main' or 'delegate'"
        raise ConfigError(msg)
    scope = raw.strip()
    if scope == "main":
        return "main"
    if scope == "delegate":
        return "delegate"
    msg = f"{prefix} must be 'main' or 'delegate'"
    raise ConfigError(msg)


def _normalize_bundle_entry(
    name: str,
    node: Mapping[str, JSONValue],
    base: ToolBundleConfig,
) -> ToolBundleConfig:
    prefix = f"tools.bundles.{name}"
    validate_allowed_keys(
        node,
        allowed={"bundles", "tools", "selectors", "scope"},
        prefix=prefix,
    )
    if "bundles" in node:
        bundles = normalize_str_list_value(
            node.get("bundles"),
            prefix=f"{prefix}.bundles",
        )
    else:
        bundles = list(base.bundles)
    if "tools" in node:
        tools = normalize_str_list_value(node.get("tools"), prefix=f"{prefix}.tools")
    else:
        tools = list(base.tools)
    if "selectors" in node:
        selectors = normalize_str_list_value(
            node.get("selectors"),
            prefix=f"{prefix}.selectors",
        )
    else:
        selectors = list(base.selectors)
    if "scope" in node:
        scope = _normalize_bundle_scope(
            node.get("scope"),
            prefix=f"{prefix}.scope",
            default=base.scope,
        )
    else:
        scope = base.scope
    return ToolBundleConfig(
        bundles=bundles,
        tools=tools,
        selectors=selectors,
        scope=scope,
    )


def _normalize_bundles(
    root: Mapping[str, JSONValue],
    base_value: Mapping[str, ToolBundleConfig],
) -> Mapping[str, ToolBundleConfig]:
    bundles: MutableMapping[str, ToolBundleConfig] = dict(base_value)
    if "bundles" not in root:
        return bundles
    bundles_raw = root.get("bundles")
    if not isinstance(bundles_raw, Mapping):
        msg = "tools.bundles must be a mapping when provided"
        raise ConfigError(msg)
    for key_obj, val_obj in bundles_raw.items():
        key = str(key_obj)
        if not isinstance(val_obj, Mapping):
            msg = f"tools.bundles.{key} must be a mapping"
            raise ConfigError(msg)
        raw_map = as_json_object(val_obj)
        if raw_map is None:
            msg = f"tools.bundles.{key} must contain only JSON values"
            raise ConfigError(msg)
        base_bundle = bundles.get(key, ToolBundleConfig())
        bundles[key] = _normalize_bundle_entry(key, raw_map, base_bundle)
    return bundles


def normalize_tools(node: Mapping[str, JSONValue] | None) -> ToolsConfig:
    """Normalize the tools section of the config into ToolsConfig.

    Semantics:
    - Missing keys keep defaults.
    - Explicit `null` disables optional tool families
      (file_search/web_search/shell/apply_patch/inspect/plan/agent_run/agent_run_report/image_generation).
    """
    base = ToolsConfig()
    if node is None:
        return base

    root = as_json_object(node)
    if root is None:
        msg = "tools section must contain only JSON values"
        raise ConfigError(msg)

    allowed_keys = {
        "max_chars",
        "file_search",
        "web_search",
        "shell",
        "apply_patch",
        "inspect",
        "plan",
        "agent_run",
        "agent_run_report",
        "image_generation",
        "function_tools",
        "dangerous",
        "bundles",
        "default_bundles",
    }
    unknown = {str(key) for key in root if str(key) not in allowed_keys}
    if unknown:
        msg = f"Unknown tools keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)

    file_search = _normalize_optional_mapping_section(
        root,
        key="file_search",
        prefix="tools.file_search",
        base_value=base.file_search,
        factory=FileSearchToolConfig,
        normalizer=normalize_file_search,
    )
    web_search = _normalize_optional_mapping_section(
        root,
        key="web_search",
        prefix="tools.web_search",
        base_value=base.web_search,
        factory=WebSearchToolConfig,
        normalizer=normalize_web_search,
    )
    shell = _normalize_optional_mapping_section(
        root,
        key="shell",
        prefix="tools.shell",
        base_value=base.shell,
        factory=ShellToolConfig,
        normalizer=normalize_shell,
    )
    apply_patch = _normalize_optional_mapping_section(
        root,
        key="apply_patch",
        prefix="tools.apply_patch",
        base_value=base.apply_patch,
        factory=ApplyPatchToolConfig,
        normalizer=normalize_apply_patch,
    )
    inspect = _normalize_optional_mapping_section(
        root,
        key="inspect",
        prefix="tools.inspect",
        base_value=base.inspect,
        factory=InspectToolConfig,
        normalizer=normalize_inspect,
    )
    plan = _normalize_optional_mapping_section(
        root,
        key="plan",
        prefix="tools.plan",
        base_value=base.plan,
        factory=PlanToolConfig,
        normalizer=normalize_plan,
    )
    agent_run = _normalize_optional_mapping_section(
        root,
        key="agent_run",
        prefix="tools.agent_run",
        base_value=base.agent_run,
        factory=AgentRunToolConfig,
        normalizer=normalize_agent_run,
    )
    agent_run_report = _normalize_optional_mapping_section(
        root,
        key="agent_run_report",
        prefix="tools.agent_run_report",
        base_value=base.agent_run_report,
        factory=AgentRunReportToolConfig,
        normalizer=normalize_agent_run_report,
    )
    image_generation = _normalize_optional_mapping_section(
        root,
        key="image_generation",
        prefix="tools.image_generation",
        base_value=base.image_generation,
        factory=ImageGenerationToolConfig,
        normalizer=normalize_image_generation,
    )
    max_chars = nonneg_int_field(
        root,
        key="max_chars",
        default=base.max_chars,
        prefix="tools.max_chars",
    )

    function_tools = _normalize_list_section(
        root,
        key="function_tools",
        prefix="tools.function_tools",
        base_value=list(base.function_tools),
        normalizer=normalize_function_tools,
    )
    dangerous = _normalize_dangerous_overrides(root, base.dangerous)
    bundles = _normalize_bundles(root, base.bundles)
    default_bundles = normalize_str_list_section(
        root,
        key="default_bundles",
        prefix="tools.default_bundles",
        base_value=list(base.default_bundles),
    )
    return ToolsConfig(
        max_chars=max_chars,
        file_search=file_search,
        web_search=web_search,
        shell=shell,
        apply_patch=apply_patch,
        inspect=inspect,
        plan=plan,
        agent_run=agent_run,
        agent_run_report=agent_run_report,
        image_generation=image_generation,
        function_tools=function_tools,
        dangerous=dangerous,
        bundles=bundles,
        default_bundles=default_bundles,
    )


__all__ = ("normalize_tools",)
