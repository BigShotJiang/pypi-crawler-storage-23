"""Normalize hosted image generation tool configuration."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING

from agenterm.config.model import ImageGenerationToolConfig
from agenterm.config.normalize.tools_helpers import (
    as_json_object,
    validate_allowed_keys,
)
from agenterm.core.choices.image_generation import (
    ImageBackground,
    ImageInputFidelity,
    ImageModeration,
    ImageOutputFormat,
    ImageQuality,
    ImageSize,
    parse_image_background,
    parse_image_input_fidelity,
    parse_image_moderation,
    parse_image_output_format,
    parse_image_quality,
    parse_image_size,
)
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


def _normalize_image_model(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> str | None:
    raw = node.get("model", base.model)
    if raw is None:
        return None
    if isinstance(raw, str):
        return raw
    msg = "tools.image_generation.model must be a string or null"
    raise ConfigError(msg)


def _normalize_image_background(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> ImageBackground | None:
    raw = node.get("background", base.background)
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_image_background(raw)
        if parsed is not None:
            return parsed
    msg = "tools.image_generation.background must be transparent|opaque|auto|null"
    raise ConfigError(msg)


def _normalize_image_input_fidelity(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> ImageInputFidelity | None:
    raw = node.get("input_fidelity", base.input_fidelity)
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_image_input_fidelity(raw)
        if parsed is not None:
            return parsed
    msg = "tools.image_generation.input_fidelity must be high|low|null"
    raise ConfigError(msg)


def _normalize_image_moderation(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> ImageModeration | None:
    raw = node.get("moderation", base.moderation)
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_image_moderation(raw)
        if parsed is not None:
            return parsed
    msg = "tools.image_generation.moderation must be auto|low|null"
    raise ConfigError(msg)


def _normalize_image_output_format(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> ImageOutputFormat | None:
    raw = node.get("output_format", base.output_format)
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_image_output_format(raw)
        if parsed is not None:
            return parsed
    msg = "tools.image_generation.output_format must be png|webp|jpeg|null"
    raise ConfigError(msg)


def _normalize_image_quality(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> ImageQuality | None:
    raw = node.get("quality", base.quality)
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_image_quality(raw)
        if parsed is not None:
            return parsed
    msg = "tools.image_generation.quality must be low|medium|high|auto|null"
    raise ConfigError(msg)


def _normalize_image_size(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> ImageSize | None:
    raw = node.get("size", base.size)
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_image_size(raw)
        if parsed is not None:
            return parsed
    msg = "tools.image_generation.size must be 1024x1024|1024x1536|1536x1024|auto|null"
    raise ConfigError(msg)


def _normalize_image_output_compression(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> int | None:
    raw = node.get("output_compression", base.output_compression)
    if raw is None:
        return None
    if isinstance(raw, int):
        return int(raw)
    msg = "tools.image_generation.output_compression must be an integer or null"
    raise ConfigError(msg)


def _normalize_image_partial_images(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> int | None:
    raw = node.get("partial_images", base.partial_images)
    if raw is None:
        return None
    if isinstance(raw, int):
        return int(raw)
    msg = "tools.image_generation.partial_images must be an integer or null"
    raise ConfigError(msg)


def _normalize_image_input_mask(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> dict[str, JSONValue] | None:
    raw = node.get("input_image_mask", base.input_image_mask)
    if raw is None:
        return None
    if not isinstance(raw, Mapping):
        msg = "tools.image_generation.input_image_mask must be a mapping or null"
        raise ConfigError(msg)
    typed = as_json_object(raw)
    if typed is None:
        msg = "tools.image_generation.input_image_mask must contain only JSON values"
        raise ConfigError(msg)
    return typed


def normalize_image_generation(
    node: Mapping[str, JSONValue],
    base: ImageGenerationToolConfig,
) -> ImageGenerationToolConfig:
    """Normalize tools.image_generation config from YAML mapping."""
    validate_allowed_keys(
        node,
        allowed={
            "model",
            "background",
            "input_fidelity",
            "moderation",
            "output_compression",
            "output_format",
            "partial_images",
            "quality",
            "size",
            "input_image_mask",
        },
        prefix="tools.image_generation",
    )

    model = _normalize_image_model(node, base)
    background = _normalize_image_background(node, base)
    input_fidelity = _normalize_image_input_fidelity(node, base)
    moderation = _normalize_image_moderation(node, base)
    output_compression = _normalize_image_output_compression(node, base)
    output_format = _normalize_image_output_format(node, base)
    partial_images = _normalize_image_partial_images(node, base)
    quality = _normalize_image_quality(node, base)
    size = _normalize_image_size(node, base)
    input_image_mask = _normalize_image_input_mask(node, base)

    return ImageGenerationToolConfig(
        model=model,
        background=background,
        input_fidelity=input_fidelity,
        moderation=moderation,
        output_compression=output_compression,
        output_format=output_format,
        partial_images=partial_images,
        quality=quality,
        size=size,
        input_image_mask=input_image_mask,
    )


__all__ = ("normalize_image_generation",)
