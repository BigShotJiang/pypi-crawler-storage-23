"""Normalize retries configuration."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.config.normalize.validators import validate_allowed_keys
from agenterm.config.retries import RetriesConfig, RetryPolicyConfig
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_float, as_int, as_json_object

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

_ALLOWED_RETRIES_KEYS: set[str] = {"provider", "mcp", "store"}
_ALLOWED_POLICY_KEYS: set[str] = {
    "max_retries",
    "base_backoff_seconds",
    "max_backoff_seconds",
    "jitter_ratio",
    "retry_after_max_seconds",
    "max_total_attempts",
    "deadline_seconds",
    "attempt_timeout_seconds",
}


def _int_with_default(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int,
    prefix: str,
) -> int:
    raw = node.get(key, default)
    if raw is None:
        return default
    value = as_int(raw)
    if value is None:
        msg = f"{prefix} must be an integer or null"
        raise ConfigError(msg)
    return value


def _float_with_default(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: float,
    prefix: str,
) -> float:
    raw = node.get(key, default)
    if raw is None:
        return default
    value = as_float(raw)
    if value is None:
        msg = f"{prefix} must be a number or null"
        raise ConfigError(msg)
    return value


def _float_or_none(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: float | None,
    prefix: str,
) -> float | None:
    raw = node.get(key, default)
    if raw is None:
        return None
    value = as_float(raw)
    if value is None:
        msg = f"{prefix} must be a number or null"
        raise ConfigError(msg)
    return value


def _normalize_policy(
    node: JSONValue | None,
    base: RetryPolicyConfig,
    *,
    prefix: str,
) -> RetryPolicyConfig:
    if node is None:
        return base
    typed = as_json_object(node)
    if typed is None:
        msg = f"{prefix} must be a mapping"
        raise ConfigError(msg)
    validate_allowed_keys(typed, allowed=_ALLOWED_POLICY_KEYS, prefix=prefix)
    max_retries = _int_with_default(
        typed,
        key="max_retries",
        default=base.max_retries,
        prefix=f"{prefix}.max_retries",
    )
    base_backoff = _float_with_default(
        typed,
        key="base_backoff_seconds",
        default=base.base_backoff_seconds,
        prefix=f"{prefix}.base_backoff_seconds",
    )
    max_backoff = _float_with_default(
        typed,
        key="max_backoff_seconds",
        default=base.max_backoff_seconds,
        prefix=f"{prefix}.max_backoff_seconds",
    )
    jitter_ratio = _float_with_default(
        typed,
        key="jitter_ratio",
        default=base.jitter_ratio,
        prefix=f"{prefix}.jitter_ratio",
    )
    retry_after_max = _float_or_none(
        typed,
        key="retry_after_max_seconds",
        default=base.retry_after_max_seconds,
        prefix=f"{prefix}.retry_after_max_seconds",
    )
    max_total_attempts = _int_with_default(
        typed,
        key="max_total_attempts",
        default=base.max_total_attempts,
        prefix=f"{prefix}.max_total_attempts",
    )
    deadline_seconds = _float_or_none(
        typed,
        key="deadline_seconds",
        default=base.deadline_seconds,
        prefix=f"{prefix}.deadline_seconds",
    )
    attempt_timeout_seconds = _float_or_none(
        typed,
        key="attempt_timeout_seconds",
        default=base.attempt_timeout_seconds,
        prefix=f"{prefix}.attempt_timeout_seconds",
    )
    return replace(
        base,
        max_retries=max_retries,
        base_backoff_seconds=base_backoff,
        max_backoff_seconds=max_backoff,
        jitter_ratio=jitter_ratio,
        retry_after_max_seconds=retry_after_max,
        max_total_attempts=max_total_attempts,
        deadline_seconds=deadline_seconds,
        attempt_timeout_seconds=attempt_timeout_seconds,
    )


def normalize_retries(
    node: Mapping[str, JSONValue] | None,
    base: RetriesConfig,
) -> RetriesConfig:
    """Normalize retries node into a RetriesConfig instance."""
    if node is None:
        return base
    unknown = {str(k) for k in node if str(k) not in _ALLOWED_RETRIES_KEYS}
    if unknown:
        msg = f"Unknown retries keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)
    provider = _normalize_policy(
        node.get("provider"),
        base.provider,
        prefix="retries.provider",
    )
    mcp = _normalize_policy(
        node.get("mcp"),
        base.mcp,
        prefix="retries.mcp",
    )
    store = _normalize_policy(
        node.get("store"),
        base.store,
        prefix="retries.store",
    )
    return RetriesConfig(provider=provider, mcp=mcp, store=store)


__all__ = ("normalize_retries",)
