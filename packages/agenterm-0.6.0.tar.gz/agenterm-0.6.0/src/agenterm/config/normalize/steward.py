"""Normalize steward section (agent + tasks)."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.config.agent_files import normalize_agent_name
from agenterm.config.normalize.validators import (
    validate_allowed_keys,
)
from agenterm.config.steward import (
    StewardAgentConfig,
    StewardConfig,
    StewardTasksConfig,
)
from agenterm.core.choices.model import ModelTruncation, parse_model_truncation
from agenterm.core.errors import ConfigError, ValidationError
from agenterm.core.json_codec import as_int, as_str

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


_ALLOWED_STEWARD_KEYS: set[str] = {"agent", "tasks"}
_ALLOWED_AGENT_KEYS: set[str] = {
    "name",
    "model",
    "truncation",
    "max_output_tokens",
    "instructions",
    "path",
    "source",
}
_ALLOWED_TASK_KEYS: set[str] = {"max_pending", "running_stale_seconds"}


def _positive_int_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int,
    prefix: str,
) -> int:
    raw = node.get(key, default)
    value = as_int(raw)
    if value is not None and value > 0:
        return value
    msg = f"{prefix} must be a positive integer"
    raise ConfigError(msg)


def _optional_positive_int_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int | None,
    prefix: str,
) -> int | None:
    raw = node.get(key, default)
    if raw is None:
        return None
    value = as_int(raw)
    if value is not None and value > 0:
        return value
    msg = f"{prefix} must be a positive integer or null"
    raise ConfigError(msg)


def _truncation_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: ModelTruncation | None,
    prefix: str,
) -> ModelTruncation | None:
    if key not in node:
        return default
    raw = node.get(key)
    if raw is None:
        return None
    if isinstance(raw, str):
        parsed = parse_model_truncation(raw)
        if parsed is not None:
            return parsed
    msg = f"{prefix} must be auto|disabled|null when provided"
    raise ConfigError(msg)


def _normalize_agent(
    node: Mapping[str, JSONValue] | None,
    base: StewardAgentConfig,
) -> StewardAgentConfig:
    if node is None:
        return base

    validate_allowed_keys(node, allowed=_ALLOWED_AGENT_KEYS, prefix="steward.agent")

    name = _normalize_agent_name(node.get("name", base.name))
    model = _non_empty_str_or_none(
        node,
        key="model",
        default=base.model,
        prefix="steward.agent.model",
    )
    truncation = _truncation_field(
        node,
        key="truncation",
        default=base.truncation,
        prefix="steward.agent.truncation",
    )
    max_output_tokens = _optional_positive_int_field(
        node,
        key="max_output_tokens",
        default=base.max_output_tokens,
        prefix="steward.agent.max_output_tokens",
    )
    instructions = _non_empty_str_or_none(
        node,
        key="instructions",
        default=base.instructions,
        prefix="steward.agent.instructions",
    )
    path = _path_or_none(
        node,
        key="path",
        default=base.path,
        prefix="steward.agent.path",
    )
    source = _non_empty_str_or_none(
        node,
        key="source",
        default=base.source,
        prefix="steward.agent.source",
    )

    provided = [val for val in (instructions, path, source) if val is not None]
    if len(provided) > 1:
        msg = "steward.agent.instructions/path/source are mutually exclusive"
        raise ConfigError(msg)

    return StewardAgentConfig(
        name=name,
        model=model,
        truncation=truncation,
        max_output_tokens=max_output_tokens,
        instructions=instructions,
        path=path,
        source=source,
    )


def _normalize_tasks(
    node: Mapping[str, JSONValue] | None,
    base: StewardTasksConfig,
) -> StewardTasksConfig:
    if node is None:
        return base

    validate_allowed_keys(node, allowed=_ALLOWED_TASK_KEYS, prefix="steward.tasks")

    max_pending = _positive_int_field(
        node,
        key="max_pending",
        default=base.max_pending,
        prefix="steward.tasks.max_pending",
    )
    running_stale_seconds = _optional_positive_int_field(
        node,
        key="running_stale_seconds",
        default=base.running_stale_seconds,
        prefix="steward.tasks.running_stale_seconds",
    )
    return StewardTasksConfig(
        max_pending=max_pending,
        running_stale_seconds=running_stale_seconds,
    )


def _normalize_agent_name(raw: JSONValue | None) -> str:
    parsed = as_str(raw)
    if parsed is None:
        msg = "steward.agent.name must be a string"
        raise ConfigError(msg)
    try:
        return normalize_agent_name(parsed)
    except ValidationError as exc:
        msg = f"steward.agent.name {exc}"
        raise ConfigError(msg) from exc


def _non_empty_str_or_none(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: str | None,
    prefix: str,
) -> str | None:
    raw = node.get(key, default)
    if raw is None:
        return None
    parsed = as_str(raw)
    if parsed is not None and parsed.strip():
        return parsed
    msg = f"{prefix} must be a non-empty string or null"
    raise ConfigError(msg)


def _path_or_none(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: Path | None,
    prefix: str,
) -> Path | None:
    raw = node.get(key, default)
    if raw is None:
        return None
    if isinstance(raw, Path):
        return raw
    if isinstance(raw, str):
        return Path(raw).expanduser().resolve()
    msg = f"{prefix} must be a string path or null"
    raise ConfigError(msg)


def normalize_steward(
    node: Mapping[str, JSONValue] | None,
    base: StewardConfig,
) -> StewardConfig:
    """Normalize steward node into a StewardConfig instance."""
    if node is None:
        return base

    unknown = {str(k) for k in node if str(k) not in _ALLOWED_STEWARD_KEYS}
    if unknown:
        msg = f"Unknown steward keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)

    agent_node = node.get("agent")
    if agent_node is not None and not isinstance(agent_node, dict):
        msg = "steward.agent must be a mapping when provided"
        raise ConfigError(msg)
    agent = _normalize_agent(
        agent_node if isinstance(agent_node, dict) else None,
        base.agent,
    )

    tasks_node = node.get("tasks")
    if tasks_node is not None and not isinstance(tasks_node, dict):
        msg = "steward.tasks must be a mapping when provided"
        raise ConfigError(msg)
    tasks = _normalize_tasks(
        tasks_node if isinstance(tasks_node, dict) else None,
        base.tasks,
    )

    return StewardConfig(
        agent=agent,
        tasks=tasks,
    )


__all__ = ("normalize_steward",)
