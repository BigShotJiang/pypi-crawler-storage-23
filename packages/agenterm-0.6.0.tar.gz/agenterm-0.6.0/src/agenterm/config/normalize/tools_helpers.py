"""Shared helpers for tools normalization."""

from __future__ import annotations

from agenterm.config.normalize.validators import validate_allowed_keys
from agenterm.core.json_codec import as_json_object, as_str_dict

__all__ = ("as_json_object", "as_str_dict", "validate_allowed_keys")
