"""Normalize built-in tool family configuration."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.config.normalize.tools_helpers import (
    as_json_object,
    validate_allowed_keys,
)
from agenterm.constants.limits import (
    INSPECT_MAX_CONCURRENCY_MAX,
    INSPECT_MAX_CONCURRENCY_MIN,
    INSPECT_MAX_OPERATIONS_MAX,
    INSPECT_MAX_OPERATIONS_MIN,
)
from agenterm.core.choices.tools import (
    SEARCH_CONTEXT_SIZES,
    SearchContextSize,
    parse_search_context_size,
)
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agenterm.config.model import (
        AgentRunReportToolConfig,
        AgentRunToolConfig,
        InspectToolConfig,
        PlanToolConfig,
    )
    from agenterm.config.tool_models import (
        ApplyPatchToolConfig,
        FileSearchToolConfig,
        WebSearchToolConfig,
    )
    from agenterm.core.json_types import JSONValue


def normalize_file_search(
    node: Mapping[str, JSONValue],
    base: FileSearchToolConfig,
) -> FileSearchToolConfig:
    """Normalize tools.file_search mapping."""
    validate_allowed_keys(
        node,
        allowed={
            "vector_store_ids",
            "max_num_results",
            "include_search_results",
            "filters",
            "ranking_options",
        },
        prefix="tools.file_search",
    )

    vs_ids_raw = node.get("vector_store_ids", base.vector_store_ids)
    if vs_ids_raw is None:
        vector_store_ids: list[str] = []
    elif isinstance(vs_ids_raw, list):
        vector_store_ids = [str(x) for x in vs_ids_raw]
    else:
        msg = "tools.file_search.vector_store_ids must be a list of strings"
        raise ConfigError(msg)

    max_results_obj = node.get("max_num_results", base.max_num_results)
    if max_results_obj is None:
        max_num_results = None
    elif isinstance(max_results_obj, int):
        max_num_results = int(max_results_obj)
    else:
        msg = "tools.file_search.max_num_results must be an integer or null"
        raise ConfigError(msg)

    include_obj = node.get("include_search_results", base.include_search_results)
    if not isinstance(include_obj, bool):
        msg = "tools.file_search.include_search_results must be a boolean"
        raise ConfigError(msg)

    filters_obj = node.get("filters") if "filters" in node else base.filters
    if (
        "filters" in node
        and filters_obj is not None
        and not isinstance(filters_obj, Mapping)
    ):
        msg = "tools.file_search.filters must be a mapping or null"
        raise ConfigError(msg)
    filters = as_json_object(filters_obj) if isinstance(filters_obj, Mapping) else None

    ranking_obj = (
        node.get("ranking_options")
        if "ranking_options" in node
        else base.ranking_options
    )
    if (
        "ranking_options" in node
        and ranking_obj is not None
        and not isinstance(ranking_obj, Mapping)
    ):
        msg = "tools.file_search.ranking_options must be a mapping or null"
        raise ConfigError(msg)
    ranking = as_json_object(ranking_obj) if isinstance(ranking_obj, Mapping) else None

    return replace(
        base,
        vector_store_ids=vector_store_ids,
        max_num_results=max_num_results,
        include_search_results=include_obj,
        filters=filters,
        ranking_options=ranking,
    )


def _normalize_web_search_context_size(
    raw: JSONValue,
) -> SearchContextSize:
    if isinstance(raw, str):
        parsed = parse_search_context_size(raw)
        if parsed is not None:
            return parsed
    msg = (
        f"tools.web_search.search_context_size must be {'|'.join(SEARCH_CONTEXT_SIZES)}"
    )
    raise ConfigError(msg)


def _normalize_web_search_user_location(
    raw: JSONValue | Mapping[str, JSONValue] | None,
) -> dict[str, JSONValue] | None:
    if raw is None:
        return None
    if not isinstance(raw, Mapping):
        msg = "tools.web_search.user_location must be a mapping or null"
        raise ConfigError(msg)
    typed = as_json_object(raw)
    if typed is None:
        msg = "tools.web_search.user_location must contain only JSON values"
        raise ConfigError(msg)
    validate_allowed_keys(
        typed,
        allowed={"type", "city", "country", "region", "timezone"},
        prefix="tools.web_search.user_location",
    )
    return typed


def normalize_web_search(
    node: Mapping[str, JSONValue],
    base: WebSearchToolConfig,
) -> WebSearchToolConfig:
    """Normalize tools.web_search mapping."""
    validate_allowed_keys(
        node,
        allowed={"search_context_size", "user_location", "filters"},
        prefix="tools.web_search",
    )

    size_obj = node.get("search_context_size", base.search_context_size)
    size_lit = _normalize_web_search_context_size(size_obj)

    user_loc_obj = (
        node.get("user_location") if "user_location" in node else base.user_location
    )
    user_location = _normalize_web_search_user_location(user_loc_obj)

    filters_obj = node.get("filters") if "filters" in node else base.filters
    if filters_obj is None:
        filters = None
    elif isinstance(filters_obj, Mapping):
        filters = as_json_object(filters_obj)
        if filters is None:
            msg = "tools.web_search.filters must contain only JSON values"
            raise ConfigError(msg)
    else:
        msg = "tools.web_search.filters must be a mapping or null"
        raise ConfigError(msg)

    return replace(
        base,
        search_context_size=size_lit,
        user_location=user_location,
        filters=filters,
    )


def normalize_apply_patch(
    node: Mapping[str, JSONValue],
    base: ApplyPatchToolConfig,
) -> ApplyPatchToolConfig:
    """Normalize tools.apply_patch mapping."""
    validate_allowed_keys(node, allowed=set(), prefix="tools.apply_patch")
    return base


def _bounded_int_field(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: int,
    min_value: int,
    max_value: int,
    prefix: str,
) -> int:
    raw = node.get(key, default)
    if not isinstance(raw, int) or isinstance(raw, bool):
        msg = f"{prefix} must be an integer"
        raise ConfigError(msg)
    if raw < min_value or raw > max_value:
        msg = f"{prefix} must be between {min_value} and {max_value}"
        raise ConfigError(msg)
    return int(raw)


def normalize_inspect(
    node: Mapping[str, JSONValue],
    base: InspectToolConfig,
) -> InspectToolConfig:
    """Normalize tools.inspect mapping."""
    validate_allowed_keys(
        node,
        allowed={"max_operations", "max_concurrency"},
        prefix="tools.inspect",
    )
    max_operations = _bounded_int_field(
        node,
        key="max_operations",
        default=base.max_operations,
        min_value=INSPECT_MAX_OPERATIONS_MIN,
        max_value=INSPECT_MAX_OPERATIONS_MAX,
        prefix="tools.inspect.max_operations",
    )
    max_concurrency = _bounded_int_field(
        node,
        key="max_concurrency",
        default=base.max_concurrency,
        min_value=INSPECT_MAX_CONCURRENCY_MIN,
        max_value=INSPECT_MAX_CONCURRENCY_MAX,
        prefix="tools.inspect.max_concurrency",
    )
    return replace(
        base,
        max_operations=max_operations,
        max_concurrency=max_concurrency,
    )


def normalize_plan(
    node: Mapping[str, JSONValue],
    base: PlanToolConfig,
) -> PlanToolConfig:
    """Normalize tools.plan mapping."""
    validate_allowed_keys(node, allowed=set(), prefix="tools.plan")
    return base


def normalize_agent_run(
    node: Mapping[str, JSONValue],
    base: AgentRunToolConfig,
) -> AgentRunToolConfig:
    """Normalize tools.agent_run mapping."""
    validate_allowed_keys(node, allowed={"bundle"}, prefix="tools.agent_run")
    raw_bundle = node.get("bundle", base.bundle)
    if not isinstance(raw_bundle, str) or not raw_bundle.strip():
        msg = "tools.agent_run.bundle must be a non-empty string"
        raise ConfigError(msg)
    return replace(base, bundle=raw_bundle.strip())


def normalize_agent_run_report(
    node: Mapping[str, JSONValue],
    base: AgentRunReportToolConfig,
) -> AgentRunReportToolConfig:
    """Normalize tools.agent_run_report mapping."""
    validate_allowed_keys(node, allowed=set(), prefix="tools.agent_run_report")
    return base


__all__ = (
    "normalize_agent_run",
    "normalize_agent_run_report",
    "normalize_apply_patch",
    "normalize_file_search",
    "normalize_inspect",
    "normalize_plan",
    "normalize_web_search",
)
