"""Config-derived tool metadata for selection and MCP.

This module turns `AppConfig.tools` into the tools/bundles data structures
used by the selection layer and CLI. All configuration lives in `config.yaml`.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Final

from agenterm.constants.tools import (
    TOOL_TYPE_FILE_SEARCH,
    TOOL_TYPE_FUNCTION,
    TOOL_TYPE_HOSTED_MCP,
    TOOL_TYPE_IMAGE_GENERATION,
    TOOL_TYPE_WEB_SEARCH,
)
from agenterm.core.errors import ConfigError
from agenterm.core.platform import supports_shell_sandbox_platform
from agenterm.core.selection_utils import dedupe_str
from agenterm.core.tool_safety import apply_tool_safety
from agenterm.core.toolspec import (
    ToolSpec,
    make_fn_key,
    make_hosted_mcp_key,
    make_hosted_openai_key,
    make_mcp_server_key,
    make_user_fn_key,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, MutableMapping

    from agenterm.config.model import AppConfig, ToolsConfig
    from agenterm.config.tool_bundles import ToolBundleConfig, ToolBundleScope

_VALID_FUNC_NAME_RE: Final[re.Pattern[str]] = re.compile(r"^[a-z0-9_-]+$")


def _validate_direct_function_names(tools_map: Mapping[str, ToolSpec]) -> None:
    """Validate user-defined function names (no internal prefixes; unique, lowercase).

    Rules (user-facing):
    - name must be lowercase and match ^[a-z0-9_-]+$
    - name must NOT start with reserved prefixes (currently: 'mcp__' / 'mcp_')
    - names must be unique case-insensitively across all direct function tools
    """
    seen_lc: set[str] = set()
    for key, spec in tools_map.items():
        if spec.type != TOOL_TYPE_FUNCTION:
            continue
        name = (spec.name or "").strip()
        if not name:
            msg = (
                f"tools.function_tools entry {key!r}: "
                "function tool requires a non-empty name"
            )
            raise ConfigError(msg)
        if name != name.lower():
            msg = (
                f"tools.function_tools entry {key!r}: "
                f"function name must be lowercase [a-z0-9_-]: {name}"
            )
            raise ConfigError(msg)
        if not _VALID_FUNC_NAME_RE.match(name):
            msg = (
                f"tools.function_tools entry {key!r}: "
                f"invalid function name (allowed [a-z0-9_-]): {name}"
            )
            raise ConfigError(msg)
        if name.startswith("mcp_"):
            msg = (
                "tools.function_tools entry "
                f"{key!r}: name must not start with reserved prefixes "
                f"('mcp__' / 'mcp_'): {name}"
            )
            raise ConfigError(msg)
        lc = name.lower()
        if lc in seen_lc:
            msg = f"Duplicate function tool name (case-insensitive): {name}"
            raise ConfigError(msg)
        seen_lc.add(lc)


def _add_file_search_tool(
    *,
    tools_map: MutableMapping[str, ToolSpec],
    tools_cfg: ToolsConfig,
) -> None:
    fs = tools_cfg.file_search
    if fs is None:
        return
    vs_ids = tuple(fs.vector_store_ids) if fs.vector_store_ids else ()
    fs_key = make_hosted_openai_key("file_search")
    tools_map[fs_key] = ToolSpec(
        type=TOOL_TYPE_FILE_SEARCH,
        key=fs_key,
        plane="hosted",
        dangerous=False,
        hosted_only=True,
        vector_store_ids=vs_ids,
    )


def _add_web_search_tool(
    *,
    tools_map: MutableMapping[str, ToolSpec],
    tools_cfg: ToolsConfig,
) -> None:
    ws = tools_cfg.web_search
    if ws is None:
        return
    ul = (
        None
        if ws.user_location is None
        else {str(k): v for k, v in ws.user_location.items()}
    )
    ws_key = make_hosted_openai_key("web_search")
    tools_map[ws_key] = ToolSpec(
        type=TOOL_TYPE_WEB_SEARCH,
        key=ws_key,
        plane="hosted",
        dangerous=False,
        hosted_only=True,
        search_context_size=ws.search_context_size,
        user_location=ul,
    )


def _add_image_generation_tool(
    *,
    tools_map: MutableMapping[str, ToolSpec],
    tools_cfg: ToolsConfig,
) -> None:
    ig = tools_cfg.image_generation
    if ig is None:
        return
    ig_key = make_hosted_openai_key("image_generation")
    tools_map[ig_key] = ToolSpec(
        type=TOOL_TYPE_IMAGE_GENERATION,
        key=ig_key,
        plane="hosted",
        dangerous=False,
        hosted_only=True,
        model=ig.model,
    )


def _add_hosted_mcp_tools(
    *,
    tools_map: MutableMapping[str, ToolSpec],
    cfg: AppConfig,
) -> None:
    """Add provider-hosted MCP tools as selectable tool entries.

    Each `mcp.connectors[*]` entry becomes a selectable tool key:
      hosted:mcp:<name>
    """
    if not cfg.mcp.connectors:
        return
    seen_lc: set[str] = set()
    for index, tc in enumerate(cfg.mcp.connectors):
        name = (tc.name or "").strip()
        if not name:
            continue
        if name != name.lower():
            msg = f"mcp.connectors[{index}].name must be lowercase [a-z0-9_-]: {name}"
            raise ConfigError(msg)
        if not _VALID_FUNC_NAME_RE.match(name):
            msg = f"mcp.connectors[{index}].name must match ^[a-z0-9_-]+$: {name}"
            raise ConfigError(msg)
        lc = name.lower()
        if lc in seen_lc:
            msg = f"Duplicate hosted MCP name (case-insensitive): {name}"
            raise ConfigError(msg)
        seen_lc.add(lc)

        mcp_key = make_hosted_mcp_key(name)
        if mcp_key in tools_map:
            msg = f"Duplicate tool key: {mcp_key}"
            raise ConfigError(msg)
        tools_map[mcp_key] = ToolSpec(
            type=TOOL_TYPE_HOSTED_MCP,
            key=mcp_key,
            plane="hosted",
            dangerous=False,
            hosted_only=True,
        )


def _add_mcp_server_tools(
    *,
    tools_map: MutableMapping[str, ToolSpec],
    cfg: AppConfig,
) -> None:
    """Add client-managed MCP servers as selectable tool entries.

    Each `mcp.servers[*]` entry becomes a selectable tool key:
      mcp:<server_key>
    """
    if not cfg.mcp.servers:
        return
    seen: set[str] = set()
    for index, server in enumerate(cfg.mcp.servers):
        server_key = str(server.key).strip()
        if not server_key:
            msg = f"mcp.servers[{index}].key must be a non-empty string"
            raise ConfigError(msg)
        if server_key in seen:
            msg = f"Duplicate MCP server key: {server_key}"
            raise ConfigError(msg)
        seen.add(server_key)

        tool_key = make_mcp_server_key(server_key)
        if tool_key in tools_map:
            msg = f"Duplicate tool key: {tool_key}"
            raise ConfigError(msg)
        tools_map[tool_key] = ToolSpec(
            type="mcp_server",
            key=tool_key,
            plane="client",
            dangerous=False,
            hosted_only=False,
            mcp_server=server,
        )


def _add_local_tools(
    *,
    tools_map: MutableMapping[str, ToolSpec],
    tools_cfg: ToolsConfig,
) -> None:
    def _register_local_tool(tool_name: str, *, tool_type: str) -> None:
        tool_key = make_fn_key(tool_name)
        tools_map[tool_key] = ToolSpec(
            type=tool_type,
            key=tool_key,
            plane="client",
            dangerous=False,
            hosted_only=False,
            name=tool_name,
        )

    if tools_cfg.shell is not None and supports_shell_sandbox_platform():
        _register_local_tool("shell", tool_type="shell")

    local_flags = [
        (tools_cfg.apply_patch is not None, "apply_patch", "apply_patch"),
        (tools_cfg.inspect is not None, "inspect", "inspect"),
        (tools_cfg.plan is not None, "plan", "plan"),
        (tools_cfg.agent_run is not None, "agent_run", "agent_run"),
        (
            tools_cfg.agent_run_report is not None,
            "agent_run_report",
            "agent_run_report",
        ),
    ]
    for enabled, name, tool_type in local_flags:
        if enabled:
            _register_local_tool(name, tool_type=tool_type)

    _register_local_tool("steward", tool_type="steward")


def _add_function_tools(
    *,
    tools_map: MutableMapping[str, ToolSpec],
    tools_cfg: ToolsConfig,
) -> None:
    if not tools_cfg.function_tools:
        return
    for ft in tools_cfg.function_tools:
        name = (ft.name or "").strip()
        if not name:
            continue
        ft_key = make_user_fn_key(name)
        tools_map[ft_key] = ToolSpec(
            type=TOOL_TYPE_FUNCTION,
            key=ft_key,
            plane="client",
            name=name,
            dangerous=False,
            hosted_only=False,
        )


def _selector_prefix(selector: str, *, prefix: str) -> str:
    if "*" not in selector:
        msg = f"{prefix} must end with '*' for prefix matching"
        raise ConfigError(msg)
    if selector.count("*") != 1 or not selector.endswith("*"):
        msg = f"{prefix} must use a single trailing '*' wildcard"
        raise ConfigError(msg)
    base = selector[:-1]
    if not base:
        msg = f"{prefix} must include a non-empty prefix before '*'"
        raise ConfigError(msg)
    return base


def _resolve_selector_keys(
    selectors: list[str],
    *,
    tools_map: MutableMapping[str, ToolSpec],
    prefix: str,
) -> list[str]:
    if not selectors:
        return []
    ordered_keys = sorted(tools_map.keys())
    out: list[str] = []
    for selector in selectors:
        if not selector.strip():
            msg = f"{prefix} must be a list of non-empty strings"
            raise ConfigError(msg)
        sel = selector.strip()
        base = _selector_prefix(sel, prefix=prefix)
        out.extend([key for key in ordered_keys if key.startswith(base)])
    return out


def _resolve_bundle_tools(
    name: str,
    *,
    bundle: ToolBundleConfig,
    bundle_defs: Mapping[str, ToolBundleConfig],
    tools_map: MutableMapping[str, ToolSpec],
    scope: ToolBundleScope,
    stack: list[str],
    cache: MutableMapping[str, list[str]],
) -> list[str]:
    if name in cache:
        return list(cache[name])
    if name in stack:
        cycle = " -> ".join([*stack, name])
        msg = f"tools.bundles.{name} contains a cycle: {cycle}"
        raise ConfigError(msg)
    if bundle.scope != scope:
        msg = f"tools.bundles.{name} has scope '{bundle.scope}', expected '{scope}'"
        raise ConfigError(msg)
    stack.append(name)
    keys: list[str] = []
    for ref in bundle.bundles:
        ref_name = str(ref)
        ref_bundle = bundle_defs.get(ref_name)
        if ref_bundle is None:
            msg = f"tools.bundles.{name} references unknown bundle '{ref_name}'"
            raise ConfigError(msg)
        keys.extend(
            _resolve_bundle_tools(
                ref_name,
                bundle=ref_bundle,
                bundle_defs=bundle_defs,
                tools_map=tools_map,
                scope=scope,
                stack=stack,
                cache=cache,
            )
        )
    for key in bundle.tools:
        tool_key = str(key)
        if tool_key in tools_map:
            keys.append(tool_key)
            continue
        if tool_key == make_fn_key("shell") and not supports_shell_sandbox_platform():
            continue
        msg = f"tools.bundles.{name} references unknown tool key: {tool_key}"
        raise ConfigError(msg)
    keys.extend(
        _resolve_selector_keys(
            bundle.selectors,
            tools_map=tools_map,
            prefix=f"tools.bundles.{name}.selectors",
        )
    )
    resolved = dedupe_str(keys)
    cache[name] = resolved
    stack.pop()
    return list(resolved)


def _resolve_bundles_map(
    bundle_defs: Mapping[str, ToolBundleConfig],
    *,
    tools_map: MutableMapping[str, ToolSpec],
    scope: ToolBundleScope,
) -> MutableMapping[str, list[str]]:
    bundles_map: MutableMapping[str, list[str]] = {}
    cache: MutableMapping[str, list[str]] = {}
    for name, bundle in bundle_defs.items():
        if bundle.scope != scope:
            continue
        bundles_map[str(name)] = _resolve_bundle_tools(
            str(name),
            bundle=bundle,
            bundle_defs=bundle_defs,
            tools_map=tools_map,
            scope=scope,
            stack=[],
            cache=cache,
        )
    return bundles_map


def build_tool_catalog_from_config(
    cfg: AppConfig,
    *,
    scope: ToolBundleScope = "main",
) -> tuple[
    MutableMapping[str, ToolSpec],
    MutableMapping[str, list[str]],
    list[str],
]:
    """Return tools/bundles/defaults derived from AppConfig.tools.

    - tools_map: mapping tool keys to ToolSpec instances.
    - bundles_map: mapping bundle name to list of tool keys.
    - default_bundles: bundles active when no CLI selection is provided (main scope).
    """
    tools_cfg = cfg.tools

    tools_map: MutableMapping[str, ToolSpec] = {}
    _add_file_search_tool(
        tools_map=tools_map,
        tools_cfg=tools_cfg,
    )
    _add_web_search_tool(
        tools_map=tools_map,
        tools_cfg=tools_cfg,
    )
    _add_image_generation_tool(
        tools_map=tools_map,
        tools_cfg=tools_cfg,
    )
    _add_hosted_mcp_tools(
        tools_map=tools_map,
        cfg=cfg,
    )
    _add_mcp_server_tools(
        tools_map=tools_map,
        cfg=cfg,
    )
    _add_local_tools(
        tools_map=tools_map,
        tools_cfg=tools_cfg,
    )
    _add_function_tools(
        tools_map=tools_map,
        tools_cfg=tools_cfg,
    )
    apply_tool_safety(tools_map=tools_map, overrides=tools_cfg.dangerous)

    _validate_direct_function_names(tools_map)

    bundles_map = _resolve_bundles_map(
        tools_cfg.bundles,
        tools_map=tools_map,
        scope=scope,
    )

    return (
        tools_map,
        bundles_map,
        list(tools_cfg.default_bundles or []) if scope == "main" else [],
    )


__all__ = ("build_tool_catalog_from_config",)
