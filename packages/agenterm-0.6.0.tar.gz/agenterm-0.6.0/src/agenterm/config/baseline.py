"""Unified baseline status detection and save operations.

This module provides a single abstraction for checking and saving the
baseline config and agent files, replacing the previous asymmetric
two-prompt system.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.config.bootstrap import (
    AgentsSaveResult,
    ConfigSaveResult,
    save_agents,
    save_config,
)
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.core.choices.config_scope import ConfigScope


@dataclass(frozen=True)
class BaselineStatus:
    """Tracks which baseline files are missing and need prompting."""

    config_missing: bool
    agent_bundled: bool

    @property
    def needs_prompt(self) -> bool:
        """Return True if any baseline file is missing."""
        return self.config_missing or self.agent_bundled


def check_baseline_status(
    *,
    config_path: Path | None,
    agent_source: str | None,
) -> BaselineStatus:
    """Determine which baseline files are missing.

    Args:
        config_path: Resolved config path, or None if no config found.
        agent_source: Resolved agent source location.

    Returns:
        BaselineStatus indicating which files need saving.

    """
    return BaselineStatus(
        config_missing=config_path is None,
        agent_bundled=agent_source == "bundled",
    )


@dataclass(frozen=True)
class BaselineSaveResult:
    """Outcome of a baseline save operation."""

    config: ConfigSaveResult | None
    agents: AgentsSaveResult | None

    @property
    def saved_any(self) -> bool:
        """Return True if any file was saved."""
        return self.config is not None or self.agents is not None


def save_baseline(
    *,
    scope: ConfigScope,
    status: BaselineStatus,
    model: str,
) -> BaselineSaveResult:
    """Save missing baseline files at the specified scope.

    Saves whichever files are missing according to status. If both are
    missing, saves both. Operations are independent; a failure in one
    does not prevent the other.

    Args:
        scope: Target scope ("local" or "global").
        status: Which files are missing.
        model: Model name to embed in config template.

    Returns:
        BaselineSaveResult with outcomes for each file.

    Raises:
        ConfigError: If any save operation fails.

    """
    config_result: ConfigSaveResult | None = None
    agents_result: AgentsSaveResult | None = None
    errors: list[str] = []

    if status.config_missing:
        try:
            config_result = save_config(scope=scope, model=model, force=False)
        except ConfigError as exc:
            errors.append(f"config: {exc}")

    if status.agent_bundled:
        try:
            agents_result = save_agents(scope=scope, force=False)
        except ConfigError as exc:
            errors.append(f"agent files: {exc}")

    if errors:
        msg = "; ".join(errors)
        raise ConfigError(msg)

    return BaselineSaveResult(config=config_result, agents=agents_result)


__all__ = (
    "BaselineSaveResult",
    "BaselineStatus",
    "check_baseline_status",
    "save_baseline",
)
