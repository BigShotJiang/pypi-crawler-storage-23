"""Attachment ingestion policy configuration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

type AttachmentImageInputMode = Literal["file_id_or_url_only", "allow_inline_data_url"]


@dataclass(frozen=True)
class AttachmentsConfig:
    """Attachment policy for images and files."""

    image_input_mode: AttachmentImageInputMode = "file_id_or_url_only"
    allow_inline_data_url: bool = False
    max_inline_bytes: int = 0


__all__ = ("AttachmentImageInputMode", "AttachmentsConfig")
