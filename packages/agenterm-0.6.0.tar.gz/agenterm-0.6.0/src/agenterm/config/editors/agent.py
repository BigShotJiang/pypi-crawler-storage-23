"""Editors for agent-level configuration."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.constants.limits import AGENT_MAX_TURNS_MAX, AGENT_MAX_TURNS_MIN
from agenterm.core.errors import ValidationError

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.config.model import AppConfig


def set_agent(
    cfg: AppConfig,
    *,
    name: str,
    instructions: str | None,
    path: Path | None,
    source: str | None,
    explicit: bool,
) -> AppConfig:
    """Return a new AppConfig with resolved agent details applied."""
    agent_cfg = replace(
        cfg.agent,
        name=name,
        instructions=instructions,
        path=path,
        source=source,
        explicit=explicit,
    )
    return replace(cfg, agent=agent_cfg)


def set_max_turns(cfg: AppConfig, max_turns: int) -> AppConfig:
    """Return a new AppConfig with AgentConfig.max_turns updated."""
    if max_turns < AGENT_MAX_TURNS_MIN or max_turns > AGENT_MAX_TURNS_MAX:
        msg = (
            f"max_turns must be between {AGENT_MAX_TURNS_MIN} and {AGENT_MAX_TURNS_MAX}"
        )
        raise ValidationError(msg)
    agent_cfg = replace(cfg.agent, max_turns=int(max_turns))
    return replace(cfg, agent=agent_cfg)


__all__ = ("set_agent", "set_max_turns")
