"""Editors for model-level configuration fields."""

from __future__ import annotations

import re
from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.core.choices.model import parse_model_verbosity
from agenterm.core.errors import ValidationError

if TYPE_CHECKING:
    from agenterm.config.model import AppConfig, ModelConfig
    from agenterm.config.text_format import TextFormat

_MODEL_ID_RE = re.compile(r"^[^\s'\"]+$")
_OPENAI_MODEL_SEGMENTS: int = 2
_GATEWAY_MODEL_MIN_SEGMENTS: int = 3


def validate_model_id(model: str) -> str:
    """Return a sanitized model id or raise ValidationError on obvious typos."""
    trimmed = (model or "").strip()
    if not trimmed:
        msg = "Model id must be non-empty."
        raise ValidationError(msg)
    if not _MODEL_ID_RE.match(trimmed):
        msg = "Model id must not contain whitespace or quotes."
        raise ValidationError(msg)
    if "/" not in trimmed:
        msg = (
            "Model id must include a provider prefix "
            "(openai/<model> or gateway/<route>/<model>)."
        )
        raise ValidationError(msg)
    parts = trimmed.split("/")
    if any(part == "" for part in parts):
        msg = "Model id must not contain empty path segments."
        raise ValidationError(msg)
    prefix = parts[0].lower()
    if prefix not in {"openai", "gateway"}:
        msg = "Model id prefix must be openai/ or gateway/."
        raise ValidationError(msg)
    if prefix == "openai" and len(parts) != _OPENAI_MODEL_SEGMENTS:
        msg = "OpenAI model ids must be openai/<model> (no extra path segments)."
        raise ValidationError(msg)
    if prefix == "gateway" and len(parts) < _GATEWAY_MODEL_MIN_SEGMENTS:
        msg = (
            "Gateway model ids must be gateway/<route>/<model> "
            "(missing route or model)."
        )
        raise ValidationError(msg)
    return trimmed


def _with_model(cfg: AppConfig, model: ModelConfig) -> AppConfig:
    return replace(cfg, model=model)


def set_model(cfg: AppConfig, model: str) -> AppConfig:
    """Return a new AppConfig with AgentConfig.model updated."""
    agent_cfg = replace(cfg.agent, model=model)
    return replace(cfg, agent=agent_cfg)


def set_model_store(cfg: AppConfig, *, store: bool | None) -> AppConfig:
    """Return a new AppConfig with ModelConfig.store updated."""
    model_cfg = replace(cfg.model, store=store)
    return _with_model(cfg, model_cfg)


def set_model_verbosity(cfg: AppConfig, level: str | None) -> AppConfig:
    """Return a new AppConfig with ModelConfig.verbosity updated.

    Args:
      cfg: Current AppConfig instance to update immutably.
      level: Verbosity token ('low'|'medium'|'high') or None to unset.

    """
    if level is not None:
        level_norm = parse_model_verbosity(level)
        if level_norm is None:
            msg = f"Invalid model verbosity: {level}"
            raise ValidationError(msg)
    else:
        level_norm = None
    model_cfg = replace(cfg.model, verbosity=level_norm)
    return _with_model(cfg, model_cfg)


def set_text_format(cfg: AppConfig, text_format: TextFormat | None) -> AppConfig:
    """Return a new AppConfig with ModelConfig.text_format updated."""
    model_cfg = replace(cfg.model, text_format=text_format)
    return _with_model(cfg, model_cfg)


__all__ = (
    "set_model",
    "set_model_store",
    "set_model_verbosity",
    "set_text_format",
)
