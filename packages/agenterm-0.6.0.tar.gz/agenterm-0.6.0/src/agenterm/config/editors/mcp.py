"""Editors for MCP configuration."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.config.model import AppConfig, McpServerConfig


def set_mcp_servers(
    cfg: AppConfig,
    servers: tuple[McpServerConfig, ...] | list[McpServerConfig],
) -> AppConfig:
    """Return a new AppConfig with mcp.servers replaced by the given sequence."""
    return replace(cfg, mcp=replace(cfg.mcp, servers=list(servers)))


__all__ = ("set_mcp_servers",)
