"""Editors for reasoning settings on ModelConfig."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from openai.types.shared import Reasoning

from agenterm.core.choices.model import (
    ReasoningEffort,
    ReasoningSummary,
    parse_reasoning_effort,
    parse_reasoning_summary,
)
from agenterm.core.errors import ValidationError

if TYPE_CHECKING:
    from agenterm.config.model import AppConfig


def _normalize_effort(effort: str | None) -> ReasoningEffort | None:
    if effort is None:
        return None
    normalized = parse_reasoning_effort(effort)
    if normalized is None:
        msg = f"Invalid reasoning effort: {effort}"
        raise ValidationError(msg)
    return normalized


def _normalize_summary(summary: str | None) -> ReasoningSummary | None:
    if summary is None:
        return None
    normalized = parse_reasoning_summary(summary)
    if normalized is None:
        msg = f"Invalid reasoning summary: {summary}"
        raise ValidationError(msg)
    return normalized


def unset_reasoning(cfg: AppConfig) -> AppConfig:
    """Return a new AppConfig with ModelConfig.reasoning cleared."""
    if cfg.model.reasoning is None:
        return cfg
    model_cfg = replace(cfg.model, reasoning=None)
    return replace(cfg, model=model_cfg)


def set_reasoning_effort(cfg: AppConfig, effort: str | None) -> AppConfig:
    """Return a new AppConfig with ModelConfig.reasoning.effort updated."""
    eff_norm = _normalize_effort(effort) if effort is not None else None
    current = cfg.model.reasoning
    if current is None and eff_norm is None:
        return cfg
    if current is None:
        new_reasoning = Reasoning(effort=eff_norm)
    else:
        new_reasoning = Reasoning(
            effort=eff_norm,
            summary=current.summary,
        )
    if new_reasoning.effort is None and new_reasoning.summary is None:
        model_cfg = replace(cfg.model, reasoning=None)
    else:
        model_cfg = replace(cfg.model, reasoning=new_reasoning)
    return replace(cfg, model=model_cfg)


def set_reasoning_summary(cfg: AppConfig, summary: str | None) -> AppConfig:
    """Return a new AppConfig with ModelConfig.reasoning.summary updated."""
    summ_norm = _normalize_summary(summary) if summary is not None else None
    current = cfg.model.reasoning
    effort = current.effort if isinstance(current, Reasoning) else None
    if effort is None and summ_norm is None:
        model_cfg = replace(cfg.model, reasoning=None)
        return replace(cfg, model=model_cfg)
    new_reasoning = Reasoning(
        effort=effort,
        summary=summ_norm,
    )
    model_cfg = replace(cfg.model, reasoning=new_reasoning)
    return replace(cfg, model=model_cfg)


__all__ = (
    "set_reasoning_effort",
    "set_reasoning_summary",
    "unset_reasoning",
)
