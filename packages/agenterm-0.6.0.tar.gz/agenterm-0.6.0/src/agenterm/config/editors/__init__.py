"""Public editors for AppConfig sections.

These helpers are the only supported way to mutate configuration at runtime.
Each function returns a new AppConfig instance and leaves inputs unchanged.
"""

from __future__ import annotations

from agenterm.config.editors.agent import set_agent, set_max_turns
from agenterm.config.editors.mcp import set_mcp_servers
from agenterm.config.editors.model import (
    set_model,
    set_model_store,
    set_model_verbosity,
    set_text_format,
    validate_model_id,
)
from agenterm.config.editors.reasoning import (
    set_reasoning_effort,
    set_reasoning_summary,
    unset_reasoning,
)

__all__ = (
    "set_agent",
    "set_max_turns",
    "set_mcp_servers",
    "set_model",
    "set_model_store",
    "set_model_verbosity",
    "set_reasoning_effort",
    "set_reasoning_summary",
    "set_text_format",
    "unset_reasoning",
    "validate_model_id",
)
