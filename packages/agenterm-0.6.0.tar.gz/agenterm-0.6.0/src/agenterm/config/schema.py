"""Typed raw schema for config files.

This layer converts the decoded YAML/JSON mapping into predictable
dataclasses so later stages can normalize and validate without re-checking
top-level shapes.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import Mapping, MutableMapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class RawConfig:
    """Top-level raw config sections as mappings or None."""

    agent: MutableMapping[str, JSONValue] | None
    model: MutableMapping[str, JSONValue] | None
    providers: MutableMapping[str, JSONValue] | None
    retries: MutableMapping[str, JSONValue] | None
    steward: MutableMapping[str, JSONValue] | None
    compression: MutableMapping[str, JSONValue] | None
    attachments: MutableMapping[str, JSONValue] | None
    tools: MutableMapping[str, JSONValue] | None
    mcp: MutableMapping[str, JSONValue] | None
    run: MutableMapping[str, JSONValue] | None
    repl: MutableMapping[str, JSONValue] | None
    guardrails: MutableMapping[str, JSONValue] | None


def to_raw_config(raw: Mapping[str, JSONValue]) -> RawConfig:
    """Convert a decoded mapping into the raw schema structure.

    Raises ConfigError when the root is not a mapping or when a known
    section is provided but not a mapping.
    """
    allowed_sections = {
        "agent",
        "model",
        "providers",
        "retries",
        "steward",
        "compression",
        "attachments",
        "tools",
        "mcp",
        "run",
        "repl",
        "guardrails",
    }
    unknown = {str(k) for k in raw if str(k) not in allowed_sections}
    if unknown:
        message = f"Unknown top-level config sections: {', '.join(sorted(unknown))}"
        raise ConfigError(message)

    def section(name: str) -> MutableMapping[str, JSONValue] | None:
        value = raw.get(name)
        if value is None:
            return None
        if not isinstance(value, dict):
            message = f"{name} section must be a mapping when provided"
            raise ConfigError(message)
        # Make a shallow copy so downstream stages can rely on mutability being local.
        return dict(value)

    return RawConfig(
        agent=section("agent"),
        model=section("model"),
        providers=section("providers"),
        retries=section("retries"),
        steward=section("steward"),
        compression=section("compression"),
        attachments=section("attachments"),
        tools=section("tools"),
        mcp=section("mcp"),
        run=section("run"),
        repl=section("repl"),
        guardrails=section("guardrails"),
    )


__all__ = ("RawConfig", "to_raw_config")
