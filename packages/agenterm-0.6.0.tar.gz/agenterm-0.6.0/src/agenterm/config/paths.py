"""Config and data paths for agenterm.

Target platforms: Linux and macOS only.
Config locations:
  - Project-local override: .agenterm/config.yaml
  - Global baseline: ~/.agenterm/config.yaml
Agents (instruction files):
  - Project-local overrides: .agenterm/agents/<name>.md
  - Global overrides: ~/.agenterm/agents/<name>.md
Data location:
  - ~/.agenterm/<version>/ (history.sqlite3, store.sqlite3)
  - ~/.agenterm/ (repl_history, artifacts/)
"""

from __future__ import annotations

from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm import __version__
from agenterm.core.errors import FilesystemError

if TYPE_CHECKING:
    from importlib.resources.abc import Traversable

# Local config directory (project-local)
_LOCAL_DIR_NAME = ".agenterm"


def _global_dir() -> Path:
    """Return the per-user config/data directory root (~/.agenterm).

    This is computed dynamically (not at import time) so tests and callers can
    control `HOME` without relying on module reloads.
    """
    return Path.home() / ".agenterm"


def global_config_dir() -> Path:
    """Return the global config directory: ~/.agenterm."""
    return _global_dir()


def local_config_dir() -> Path:
    """Return the project-local config directory: .agenterm/."""
    return Path.cwd() / _LOCAL_DIR_NAME


def local_agents_dir() -> Path:
    """Return the project-local agents directory: .agenterm/agents."""
    return local_config_dir() / "agents"


def global_agents_dir() -> Path:
    """Return the global agents directory: ~/.agenterm/agents."""
    return _global_dir() / "agents"


def local_agent_path(name: str) -> Path:
    """Return the local agent file path for an agent name."""
    return local_agents_dir() / f"{name}.md"


def global_agent_path(name: str) -> Path:
    """Return the global agent file path for an agent name."""
    return global_agents_dir() / f"{name}.md"


def find_default_config_path() -> Path | None:
    """Discover default config.yaml when --config is not provided.

    Order:
      1) Project-local: .agenterm/config.yaml
      2) Global: ~/.agenterm/config.yaml

    Returns:
      The resolved path if found; otherwise None.

    """
    # 1) Project-local
    local_config = local_config_dir() / "config.yaml"
    if local_config.is_file():
        return local_config.resolve()

    # 2) Global
    global_config = _global_dir() / "config.yaml"
    if global_config.is_file():
        return global_config.resolve()

    return None


@dataclass(frozen=True)
class ConfigSourceInfo:
    """Resolved config source information for CLI reporting."""

    location: str
    path: Path | None


def resolve_config_source(
    *,
    explicit: Path | None,
    resolved: Path | None,
) -> ConfigSourceInfo:
    """Return the config source location and path for reporting."""
    if explicit is not None:
        return ConfigSourceInfo(location="explicit", path=explicit)
    if resolved is None:
        return ConfigSourceInfo(location="default", path=None)

    local_path = local_config_dir() / "config.yaml"
    global_path = global_config_dir() / "config.yaml"
    try:
        resolved_path = resolved.resolve()
        if resolved_path == local_path.resolve():
            return ConfigSourceInfo(location="local", path=resolved_path)
        if resolved_path == global_path.resolve():
            return ConfigSourceInfo(location="global", path=resolved_path)
    except OSError as exc:
        msg = f"Failed to resolve config path {resolved}: {exc}"
        raise FilesystemError(msg) from exc
    return ConfigSourceInfo(location="custom", path=resolved)


def data_dir() -> Path:
    """Return the per-user data directory root (~/.agenterm/<version>)."""
    return _global_dir() / __version__


def history_db_path() -> Path:
    """Return the SQLite database path for vendor session history."""
    return data_dir() / "history.sqlite3"


def meta_store_path() -> Path:
    """Return the SQLite database path for agenterm metadata."""
    return data_dir() / "store.sqlite3"


def ensure_data_dir() -> Path:
    """Ensure the data directory exists and return it."""
    target = data_dir()
    try:
        target.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        msg = f"Failed to create data dir {target}: {e}"
        raise FilesystemError(msg) from e
    return target


def repl_history_path() -> Path:
    """Return the text history file path used by the REPL (does NOT create directory).

    This remains a simple line-based history file consumed by prompt-toolkit's
    FileHistory. It is intentionally separate from the SQLite session store.

    Use `ensure_history_dir()` when you need to create the parent directory.
    """
    return _global_dir() / "repl_history"


def ensure_history_dir() -> Path:
    """Ensure REPL history directory exists and return the history file path.

    Use this before writing to the history file for the first time.
    """
    target = repl_history_path()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        msg = f"Failed to create REPL history dir {target.parent}: {e}"
        raise FilesystemError(msg) from e
    return target


def artifacts_dir() -> Path:
    """Return the per-user artifacts directory (does NOT create directory).

    Location: ~/.agenterm/artifacts

    This directory stores durable model/tool outputs such as generated images.
    """
    return _global_dir() / "artifacts"


def ensure_artifacts_dir() -> Path:
    """Ensure the artifacts directory exists and return it."""
    target = artifacts_dir()
    try:
        target.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        msg = f"Failed to create artifacts dir {target}: {e}"
        raise FilesystemError(msg) from e
    return target


def run_spool_dir() -> Path:
    """Return the run spool directory (does NOT create directory)."""
    return artifacts_dir() / "run_spool"


def ensure_run_spool_dir() -> Path:
    """Ensure the run spool directory exists and return it."""
    target = run_spool_dir()
    try:
        target.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        msg = f"Failed to create run spool dir {target}: {e}"
        raise FilesystemError(msg) from e
    return target


def bundled_agents_dir() -> Traversable:
    """Return the bundled agents directory (package data)."""
    return files("agenterm").joinpath("data").joinpath("agents")


def global_env_path() -> Path:
    """Return the per-user environment file path: ~/.agenterm/.env.

    agenterm intentionally does NOT auto-load `.env` files from the current working
    directory (to avoid accidental secret leakage via git or unexpected project
    environment capture). Instead, it supports a single global `.env` file
    alongside the global config and store.
    """
    return _global_dir() / ".env"


__all__ = (
    "ConfigSourceInfo",
    "artifacts_dir",
    "bundled_agents_dir",
    "data_dir",
    "ensure_artifacts_dir",
    "ensure_data_dir",
    "ensure_history_dir",
    "find_default_config_path",
    "global_agent_path",
    "global_agents_dir",
    "global_config_dir",
    "global_env_path",
    "history_db_path",
    "local_agent_path",
    "local_agents_dir",
    "local_config_dir",
    "meta_store_path",
    "repl_history_path",
    "resolve_config_source",
)
