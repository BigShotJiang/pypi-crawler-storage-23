"""Runtime entrypoints for config loading."""

from __future__ import annotations

import logging
from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.config.agent_files import resolve_agent
from agenterm.config.decode import discover_config_path, load_raw_config
from agenterm.config.editors import set_text_format
from agenterm.config.model import AppConfig
from agenterm.config.normalize import normalize_config, to_app_config
from agenterm.config.schema import RawConfig, to_raw_config
from agenterm.config.schema_validation import validate_raw_config
from agenterm.config.validate import validate_config
from agenterm.core.errors import ConfigError, FilesystemError
from agenterm.core.guardrails_loader import prime_guardrails
from agenterm.core.openai_client import set_openai_base_url
from agenterm.core.retry import RetryPolicy
from agenterm.store.async_db import set_store_retry_policy
from agenterm.text.format_builder import from_schema_file as build_text_format_from_file

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)


def _resolve_agent(
    cfg: AppConfig,
    *,
    explicit_name: str | None,
) -> AppConfig:
    """Resolve agent instructions into cfg.agent.instructions."""
    resolved = resolve_agent(
        name=explicit_name or cfg.agent.name,
        explicit=explicit_name is not None,
    )
    agent_cfg = replace(
        cfg.agent,
        name=resolved.name,
        instructions=resolved.text,
        path=resolved.source.path,
        source=resolved.source.location,
        explicit=resolved.source.explicit,
    )
    return replace(cfg, agent=agent_cfg)


def _resolve_text_format(cfg: AppConfig, *, conf_path: Path | None) -> AppConfig:
    if cfg.model.text_format is not None:
        return cfg
    if cfg.model.text_format_file is None:
        return cfg
    if conf_path is None:
        msg = "model.text_format_file requires a config file path for resolution"
        raise ConfigError(msg)
    cfg_dir = conf_path.parent
    tf_path = (
        cfg.model.text_format_file
        if cfg.model.text_format_file.is_absolute()
        else (cfg_dir / cfg.model.text_format_file)
    )
    try:
        tf = build_text_format_from_file(tf_path, strict=True)
    except FilesystemError as exc:
        detail = f"Failed to read model.text_format_file {tf_path}: {exc}"
        raise FilesystemError(detail) from exc
    except ConfigError as exc:
        detail = f"Invalid model.text_format_file {tf_path}: {exc}"
        raise ConfigError(detail) from exc
    return set_text_format(cfg, tf)


def _apply_store_retry_policy(cfg: AppConfig) -> None:
    retries = cfg.retries.store
    set_store_retry_policy(
        RetryPolicy(
            max_retries=retries.max_retries,
            base_backoff_seconds=retries.base_backoff_seconds,
            max_backoff_seconds=retries.max_backoff_seconds,
            jitter_ratio=retries.jitter_ratio,
            retry_after_max_seconds=retries.retry_after_max_seconds,
        ),
    )


def load_app_config(
    path: Path | None,
    *,
    agent_name: str | None = None,
) -> AppConfig:
    """Load configuration from YAML/JSON into AppConfig.

    Returns defaults when no config file exists. Propagates ConfigError on
    structural or validation failures.
    """
    conf_path = discover_config_path(path)
    if conf_path is None:
        cfg = AppConfig()
        set_openai_base_url(cfg.providers.openai.base_url)
        _apply_store_retry_policy(cfg)
        cfg = _resolve_text_format(cfg, conf_path=None)
        cfg = _resolve_agent(cfg, explicit_name=agent_name)
        prime_guardrails(cfg.guardrails)
        return cfg

    raw_mapping = load_raw_config(conf_path)
    if raw_mapping is None:
        cfg = AppConfig()
        set_openai_base_url(cfg.providers.openai.base_url)
        _apply_store_retry_policy(cfg)
        cfg = _resolve_text_format(cfg, conf_path=conf_path)
        cfg = _resolve_agent(cfg, explicit_name=agent_name)
        prime_guardrails(cfg.guardrails)
        return cfg

    validated_mapping = validate_raw_config(raw_mapping)
    raw_config: RawConfig = to_raw_config(validated_mapping)
    normalized = normalize_config(raw_config)
    validate_config(normalized)
    cfg = to_app_config(normalized)
    set_openai_base_url(cfg.providers.openai.base_url)
    _apply_store_retry_policy(cfg)
    cfg = _resolve_text_format(cfg, conf_path=conf_path)
    cfg = _resolve_agent(cfg, explicit_name=agent_name)
    prime_guardrails(cfg.guardrails)
    return cfg


__all__ = ("discover_config_path", "load_app_config")
