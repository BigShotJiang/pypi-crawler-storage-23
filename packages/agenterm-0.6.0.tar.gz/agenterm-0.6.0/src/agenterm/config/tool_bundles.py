"""Built-in tool bundle definitions for config defaults."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

ToolBundleScope = Literal["main", "delegate"]


@dataclass(frozen=True)
class ToolBundleConfig:
    """Tool bundle definition (composition + scope + selectors)."""

    bundles: list[str] = field(default_factory=list)
    tools: list[str] = field(default_factory=list)
    selectors: list[str] = field(default_factory=list)
    scope: ToolBundleScope = "main"


def default_bundles_map() -> dict[str, ToolBundleConfig]:
    """Return built-in tool bundle definitions."""
    return {
        # Composite bundle: all main-scope bundles (default for new sessions).
        "agenterm": ToolBundleConfig(
            bundles=[
                "inspect",
                "plan",
                "subagents",
                "edit",
                "shell",
                "integrations",
                "extensions",
            ],
        ),
        # Individual bundles (composable).
        "inspect": ToolBundleConfig(
            tools=[
                "fn:inspect",
            ],
        ),
        "plan": ToolBundleConfig(
            tools=[
                "fn:plan",
            ],
        ),
        "subagents": ToolBundleConfig(
            tools=[
                "fn:agent_run",
                "fn:agent_run_report",
                "fn:steward",
            ],
        ),
        "edit": ToolBundleConfig(tools=["fn:apply_patch"]),
        "shell": ToolBundleConfig(tools=["fn:shell"]),
        "integrations": ToolBundleConfig(
            selectors=[
                "mcp:*",
                "hosted:mcp:*",
            ],
        ),
        "extensions": ToolBundleConfig(selectors=["fn:user:*"]),
        # OpenAI hosted tools (delegate-scope; used by agent_run sub-agents).
        "openai": ToolBundleConfig(
            tools=[
                "hosted:openai:web_search",
                "hosted:openai:file_search",
                "hosted:openai:image_generation",
            ],
            scope="delegate",
        ),
    }


def default_bundle_selection() -> list[str]:
    """Return bundle names enabled by default for new sessions."""
    return ["agenterm"]


__all__ = (
    "ToolBundleConfig",
    "ToolBundleScope",
    "default_bundle_selection",
    "default_bundles_map",
)
