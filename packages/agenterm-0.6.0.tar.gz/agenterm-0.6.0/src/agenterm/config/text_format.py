"""Typed configuration surfaces for text and JSON-schema formats.

These structures are simple DTOs intentionally designed for configuration
boundaries. They avoid runtime behavior and remain fully serializable.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal, NotRequired, TypedDict

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONMapping


class TextFormatText(TypedDict):
    """Plain text response format."""

    type: Literal["text"]


class TextFormatJSONSchema(TypedDict, total=False):
    """JSON Schema-guided text format."""

    type: Literal["json_schema"]
    name: str
    schema: JSONMapping
    strict: NotRequired[bool]
    description: NotRequired[str]


TextFormat = TextFormatText | TextFormatJSONSchema


def build_json_schema_format(
    name: str,
    schema: JSONMapping,
    *,
    strict: bool | None = None,
    description: str | None = None,
) -> TextFormatJSONSchema:
    """Construct a JSON-schema text format payload.

    Args:
      name: Human-readable name for the schema.
      schema: Parsed JSON schema as a Python mapping.
      strict: When set, propagate a strictness hint to consumers.
      description: Optional human description of the schema.

    Returns:
      A `TextFormatJSONSchema` mapping suitable for serialization.

    """
    out: TextFormatJSONSchema = {"type": "json_schema", "name": name, "schema": schema}
    if strict is not None:
        out["strict"] = bool(strict)
    if isinstance(description, str) and description:
        out["description"] = description
    return out
