"""MCP configuration models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from agenterm.constants.limits import MCP_BRIDGE_MAX_CONTENT_ITEMS_DEFAULT


@dataclass(frozen=True)
class McpBridgeConfig:
    """Output and serialization limits for MCP-as-FunctionTools bridging."""

    max_content_items: int = MCP_BRIDGE_MAX_CONTENT_ITEMS_DEFAULT
    """Max MCP content items per tool call before serialization."""


@dataclass(frozen=True)
class McpExposeConfig:
    """Expose agenterm as an MCP server (FastMCP)."""

    enabled: bool = False
    transport: Literal["stdio", "sse", "streamable_http"] = "stdio"
    host: str = "127.0.0.1"
    port: int = 8000
    allow_dangerous: bool = False
    bundles: list[str] | None = None
    tools: list[str] | None = None


__all__ = ("McpBridgeConfig", "McpExposeConfig")
