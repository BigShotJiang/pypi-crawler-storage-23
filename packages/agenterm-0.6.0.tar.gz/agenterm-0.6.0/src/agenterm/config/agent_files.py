"""Agent file resolution helpers."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Final

from agenterm.config.files import read_small_text_file
from agenterm.config.paths import (
    bundled_agents_dir,
    global_agent_path,
    global_agents_dir,
    local_agent_path,
    local_agents_dir,
)
from agenterm.constants.limits import SMALL_FILE_MAX_BYTES
from agenterm.core.errors import ConfigError, ValidationError

if TYPE_CHECKING:
    from importlib.resources.abc import Traversable

_AGENT_NAME_RE: Final[re.Pattern[str]] = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]*$")


@dataclass(frozen=True)
class AgentSourceInfo:
    """Resolved agent source information."""

    location: str
    path: Path | None
    explicit: bool


@dataclass(frozen=True)
class ResolvedAgent:
    """Resolved agent contents."""

    name: str
    text: str
    source: AgentSourceInfo


def normalize_agent_name(raw: str) -> str:
    """Normalize and validate an agent name."""
    name = raw.strip()
    name = name.removesuffix(".md")
    if not name:
        msg = "agent.name must be a non-empty string"
        raise ValidationError(msg)
    if not _AGENT_NAME_RE.match(name):
        msg = "agent.name must match [A-Za-z0-9][A-Za-z0-9_-]* (no path separators)."
        raise ValidationError(msg)
    return name


def _read_bundled_text(path: Traversable) -> str:
    try:
        raw = path.read_bytes()
    except OSError as exc:
        msg = f"Failed to read bundled agent file: {exc}"
        raise ConfigError(msg) from exc
    if len(raw) > SMALL_FILE_MAX_BYTES:
        msg = "Bundled agent file too large (>256KB)"
        raise ConfigError(msg)
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        msg = f"Bundled agent file is not valid UTF-8: {exc}"
        raise ConfigError(msg) from exc


def _bundled_agent_path(name: str) -> Traversable | None:
    candidate = bundled_agents_dir().joinpath(f"{name}.md")
    try:
        return candidate if candidate.is_file() else None
    except OSError:
        return None


def _read_agent_from_path(path: Path) -> str:
    try:
        return read_small_text_file(path, max_bytes=SMALL_FILE_MAX_BYTES)
    except (ValidationError, OSError) as exc:
        msg = f"Failed to read agent file {path}: {exc}"
        raise ConfigError(msg) from exc


def resolve_agent(
    *,
    name: str,
    explicit: bool,
) -> ResolvedAgent:
    """Resolve an agent from local/global/bundled sources."""
    name = normalize_agent_name(name)

    local_path = local_agent_path(name)
    if local_path.is_file():
        text = _read_agent_from_path(local_path)
        return ResolvedAgent(
            name=name,
            text=text,
            source=AgentSourceInfo(
                location="local",
                path=local_path,
                explicit=explicit,
            ),
        )

    global_path = global_agent_path(name)
    if global_path.is_file():
        text = _read_agent_from_path(global_path)
        return ResolvedAgent(
            name=name,
            text=text,
            source=AgentSourceInfo(
                location="global",
                path=global_path,
                explicit=explicit,
            ),
        )

    bundled_path = _bundled_agent_path(name)
    if bundled_path is not None:
        text = _read_bundled_text(bundled_path)
        return ResolvedAgent(
            name=name,
            text=text,
            source=AgentSourceInfo(
                location="bundled",
                path=None,
                explicit=explicit,
            ),
        )

    available = list_available_agents()
    msg = (
        f"Unknown agent {name!r}. "
        f"Available agents: {', '.join(available) if available else '(none)'}."
    )
    raise ConfigError(msg)


def _names_from_paths(paths: list[Path]) -> list[str]:
    names: list[str] = []
    for path in paths:
        if path.suffix != ".md":
            continue
        stem = path.stem.strip()
        if stem:
            names.append(stem)
    return names


def list_bundled_agents() -> list[str]:
    """Return bundled agent names (without extension)."""
    names: list[str] = []
    try:
        for entry in bundled_agents_dir().iterdir():
            try:
                if entry.is_file() and str(entry.name).endswith(".md"):
                    stem = Path(str(entry.name)).stem.strip()
                    if stem:
                        names.append(stem)
            except OSError:
                continue
    except OSError:
        return []
    return sorted(set(names))


def read_bundled_agent_text(name: str) -> str:
    """Return bundled agent text for an agent name."""
    path = _bundled_agent_path(name)
    if path is None:
        msg = f"Bundled agent not found: {name}"
        raise ConfigError(msg)
    return _read_bundled_text(path)


def list_local_agents() -> list[str]:
    """Return local agent names (without extension)."""
    try:
        return sorted(set(_names_from_paths(list(local_agents_dir().glob("*.md")))))
    except OSError:
        return []


def list_global_agents() -> list[str]:
    """Return global agent names (without extension)."""
    try:
        return sorted(set(_names_from_paths(list(global_agents_dir().glob("*.md")))))
    except OSError:
        return []


def list_available_agents() -> list[str]:
    """Return deduplicated agent names across local/global/bundled sources."""
    names = [
        *list_local_agents(),
        *list_global_agents(),
        *list_bundled_agents(),
    ]
    out: list[str] = []
    seen: set[str] = set()
    for name in names:
        if name in seen:
            continue
        seen.add(name)
        out.append(name)
    return out


__all__ = (
    "AgentSourceInfo",
    "ResolvedAgent",
    "list_available_agents",
    "list_bundled_agents",
    "list_global_agents",
    "list_local_agents",
    "normalize_agent_name",
    "read_bundled_agent_text",
    "resolve_agent",
)
