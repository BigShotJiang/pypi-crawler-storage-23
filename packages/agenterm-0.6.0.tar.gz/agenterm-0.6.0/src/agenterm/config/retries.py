"""Retry policy configuration models."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class RetryPolicyConfig:
    """Unified retry policy for a single surface."""

    max_retries: int
    base_backoff_seconds: float
    max_backoff_seconds: float
    jitter_ratio: float
    retry_after_max_seconds: float | None = None
    max_total_attempts: int = 25
    deadline_seconds: float | None = None
    attempt_timeout_seconds: float | None = None


@dataclass(frozen=True)
class RetriesConfig:
    """Retry policies for provider, MCP, and store surfaces."""

    provider: RetryPolicyConfig = field(
        default_factory=lambda: RetryPolicyConfig(
            max_retries=20,
            base_backoff_seconds=0.5,
            max_backoff_seconds=8.0,
            jitter_ratio=0.25,
            retry_after_max_seconds=60.0,
            max_total_attempts=25,
            deadline_seconds=None,
            attempt_timeout_seconds=None,
        ),
    )
    mcp: RetryPolicyConfig = field(
        default_factory=lambda: RetryPolicyConfig(
            max_retries=5,
            base_backoff_seconds=1.0,
            max_backoff_seconds=8.0,
            jitter_ratio=0.25,
            retry_after_max_seconds=None,
        ),
    )
    store: RetryPolicyConfig = field(
        default_factory=lambda: RetryPolicyConfig(
            max_retries=5,
            base_backoff_seconds=0.05,
            max_backoff_seconds=1.0,
            jitter_ratio=0.25,
            retry_after_max_seconds=None,
        ),
    )


__all__ = ("RetriesConfig", "RetryPolicyConfig")
