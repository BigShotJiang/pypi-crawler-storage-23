"""Typed filter shapes for MCP tool configuration."""

from __future__ import annotations

from typing import Literal, TypedDict


class McpToolFilter(TypedDict, total=False):
    """Typed filter for allowed MCP tool names."""

    read_only: bool
    tool_names: list[str]


class McpToolApprovalFilter(TypedDict, total=False):
    """Typed filter for MCP tool approvals."""

    read_only: bool
    tool_names: list[str]


class McpRequireApprovalFilter(TypedDict, total=False):
    """Typed approval filters for MCP tool approvals."""

    always: McpToolApprovalFilter
    never: McpToolApprovalFilter


McpAllowedTools = list[str] | McpToolFilter
McpRequireApproval = Literal["always", "never"] | McpRequireApprovalFilter


__all__ = (
    "McpAllowedTools",
    "McpRequireApproval",
    "McpRequireApprovalFilter",
    "McpToolApprovalFilter",
    "McpToolFilter",
)
