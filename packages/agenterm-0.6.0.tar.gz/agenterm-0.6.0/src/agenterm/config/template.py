"""Generate the commented config.yaml template from the live schema."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import fields, is_dataclass
from io import StringIO
from pathlib import Path
from typing import Protocol, TypeGuard

from openai.types.shared import Reasoning
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap

from agenterm.config.editors.model import set_model
from agenterm.config.model import (
    AgentConfig,
    AgentRunToolConfig,
    AppConfig,
    AttachmentsConfig,
    CompressionConfig,
    DangerousToolsConfig,
    GatewayProviderConfig,
    GatewayRouteConfig,
    GuardrailsConfig,
    InspectToolConfig,
    McpBridgeConfig,
    McpConfig,
    McpConnectorConfig,
    McpExposeConfig,
    McpServerConfig,
    McpServerRuntimeConfig,
    McpServerSseConfig,
    McpServerStdioConfig,
    McpServerStreamableHttpConfig,
    McpToolFilterConfig,
    ModelConfig,
    OpenAIProviderConfig,
    PlanToolConfig,
    ProvidersConfig,
    ReplApprovalsConfig,
    ReplConfig,
    ReplUiConfig,
    ReplUxConfig,
    RunDefaults,
    ToolsConfig,
)
from agenterm.config.steward import (
    StewardAgentConfig,
    StewardConfig,
    StewardTasksConfig,
)
from agenterm.config.template_docs import (
    FIELD_DOCS,
    ROOT_DOC,
    SECTION_DOCS,
    SECTION_ORDER,
)
from agenterm.config.text_format import TextFormat
from agenterm.config.tool_bundles import ToolBundleConfig
from agenterm.config.tool_models import (
    ApplyPatchToolConfig,
    FileSearchToolConfig,
    FunctionToolConfig,
    ImageGenerationToolConfig,
    ShellSandboxConfig,
    ShellToolConfig,
    WebSearchToolConfig,
)
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import JSONLike, parse_json_object
from agenterm.core.json_types import JSONValue

type ConfigDataclass = (
    AgentConfig
    | ModelConfig
    | FileSearchToolConfig
    | WebSearchToolConfig
    | ShellSandboxConfig
    | ShellToolConfig
    | ApplyPatchToolConfig
    | PlanToolConfig
    | InspectToolConfig
    | AgentRunToolConfig
    | DangerousToolsConfig
    | ImageGenerationToolConfig
    | FunctionToolConfig
    | ToolBundleConfig
    | ToolsConfig
    | OpenAIProviderConfig
    | GatewayRouteConfig
    | GatewayProviderConfig
    | ProvidersConfig
    | McpConnectorConfig
    | McpBridgeConfig
    | McpExposeConfig
    | McpServerStdioConfig
    | McpServerSseConfig
    | McpServerStreamableHttpConfig
    | McpToolFilterConfig
    | McpServerRuntimeConfig
    | McpServerConfig
    | McpConfig
    | RunDefaults
    | CompressionConfig
    | AttachmentsConfig
    | ReplApprovalsConfig
    | ReplUxConfig
    | ReplUiConfig
    | ReplConfig
    | GuardrailsConfig
    | StewardAgentConfig
    | StewardTasksConfig
    | StewardConfig
    | AppConfig
)

type ConfigNode = (
    ConfigDataclass
    | Reasoning
    | TextFormat
    | list["ConfigNode"]
    | Mapping[str, "ConfigNode"]
    | JSONLike
    | Path
)

type TemplateNode = CommentedMap | list["TemplateNode"] | JSONValue | None


class CommentedMapWithComments(Protocol):
    """Minimal comment API required by the template renderer."""

    def yaml_set_start_comment(self, comment: str, indent: int = 0) -> None: ...

    def yaml_set_comment_before_after_key(
        self,
        key: str,
        before: str | None = None,
        indent: int = 0,
        after: str | None = None,
        after_indent: int | None = None,
    ) -> None: ...

    def yaml_add_eol_comment(
        self,
        comment: str,
        key: str,
        column: int | None = None,
    ) -> None: ...


class YamlEmitter(Protocol):
    """Typed subset of ruamel.yaml.YAML used by the template renderer."""

    map_indent: int | None
    sequence_indent: int | None
    sequence_dash_offset: int
    width: int | None
    default_flow_style: bool | None

    def dump(self, data: CommentedMap, stream: StringIO) -> None: ...


def render_config_template(*, model: str) -> str:
    """Render a complete, commented config.yaml template."""
    validate_template_docs()
    cfg = set_model(AppConfig(), model=model)
    root = _build_root_map(cfg)
    if ROOT_DOC.lines:
        _set_start_comment(root, ROOT_DOC.lines)
    yaml = _new_yaml()
    stream = StringIO()
    yaml.dump(root, stream)
    return stream.getvalue()


def validate_template_docs() -> None:
    """Ensure doc coverage for every schema field path."""
    cfg = AppConfig()
    expected = _collect_paths(cfg, ())
    missing: list[str] = []
    for path in expected:
        if len(path) == 1:
            if path[0] not in SECTION_DOCS and _path_key(path) not in FIELD_DOCS:
                missing.append(_path_key(path))
            continue
        if _path_key(path) not in FIELD_DOCS:
            missing.append(_path_key(path))

    extra = [key for key in FIELD_DOCS if key not in {_path_key(p) for p in expected}]
    if missing or extra:
        parts: list[str] = []
        if missing:
            parts.append(f"Missing docs: {', '.join(sorted(missing))}")
        if extra:
            parts.append(f"Unknown docs: {', '.join(sorted(extra))}")
        raise ConfigError("; ".join(parts))

    top_level = [path for path in expected if len(path) == 1]
    ordered = tuple(path[0] for path in top_level)
    if ordered != SECTION_ORDER:
        msg = "SECTION_ORDER does not match AppConfig field order"
        raise ConfigError(msg)


def _collect_paths(value: ConfigNode, path: tuple[str, ...]) -> list[tuple[str, ...]]:
    paths: list[tuple[str, ...]] = []
    if _is_config_dataclass(value):
        data = vars(value)
        for field in fields(value):
            if field.metadata.get("template") is False:
                continue
            key = field.name
            child = data[key]
            child_path = (*path, key)
            paths.append(child_path)
            paths.extend(_collect_paths(child, child_path))
        return paths
    if value is None and path and path[-1] == "reasoning":
        return _collect_paths(_reasoning_mapping(Reasoning()), path)
    if isinstance(value, Reasoning):
        mapping = _reasoning_mapping(value)
        return _collect_paths(mapping, path)
    if _is_mapping_node(value):
        for raw_key, raw_val in value.items():
            key = str(raw_key)
            child_path = (*path, key)
            paths.append(child_path)
            paths.extend(_collect_paths(raw_val, child_path))
        return paths
    if _is_sequence(value):
        return paths
    return paths


def _build_root_map(cfg: AppConfig) -> CommentedMap:
    data = vars(cfg)
    root = CommentedMap()
    for idx, key in enumerate(SECTION_ORDER):
        if key not in data:
            msg = f"Missing AppConfig section: {key}"
            raise ConfigError(msg)
        root[key] = _build_node(data[key], (key,))
        _apply_comments(root, key, (key,), section_index=idx)
    return root


def _build_node(value: ConfigNode, path: tuple[str, ...]) -> TemplateNode:
    if _is_config_dataclass(value):
        node = _build_dataclass_map(value, path)
    elif value is None and path and path[-1] == "reasoning":
        node = _build_mapping_node(_reasoning_mapping(Reasoning()), path)
    elif isinstance(value, Reasoning):
        node = _build_mapping_node(_reasoning_mapping(value), path)
    elif _is_mapping_node(value):
        node = _build_mapping_node(value, path)
    elif isinstance(value, Path):
        node = str(value)
    elif _is_sequence(value):
        node = [_build_node(item, (*path, str(idx))) for idx, item in enumerate(value)]
    elif value is None or isinstance(value, (str, int, float, bool)):
        node = value
    else:
        msg = f"Unsupported config node: {type(value)}"
        raise ConfigError(msg)
    return node


def _build_dataclass_map(value: ConfigDataclass, path: tuple[str, ...]) -> CommentedMap:
    mapping = CommentedMap()
    data = vars(value)
    for field in fields(value):
        if field.metadata.get("template") is False:
            continue
        key = field.name
        mapping[key] = _build_node(data[key], (*path, key))
        _apply_comments(mapping, key, (*path, key))
    return mapping


def _build_mapping_node(
    value: Mapping[str, ConfigNode],
    path: tuple[str, ...],
) -> CommentedMap:
    mapping = CommentedMap()
    for raw_key, raw_val in value.items():
        key = str(raw_key)
        mapping[key] = _build_node(raw_val, (*path, key))
        _apply_comments(mapping, key, (*path, key))
    return mapping


def _apply_comments(
    mapping: CommentedMapWithComments,
    key: str,
    path: tuple[str, ...],
    *,
    section_index: int | None = None,
) -> None:
    before_lines: list[str] = []
    if len(path) == 1:
        section = SECTION_DOCS.get(path[0])
        if section is not None:
            if section_index is not None and section_index > 0:
                before_lines.append("")
            before_lines.extend(section.lines)
    field_doc = FIELD_DOCS.get(_path_key(path))
    if field_doc is not None and field_doc.before:
        if before_lines:
            before_lines.append("")
        before_lines.extend(field_doc.before)
    if before_lines:
        mapping.yaml_set_comment_before_after_key(key, before="\n".join(before_lines))
    if field_doc is not None and field_doc.inline:
        mapping.yaml_add_eol_comment(field_doc.inline, key=key)


def _set_start_comment(
    mapping: CommentedMapWithComments,
    lines: tuple[str, ...],
) -> None:
    mapping.yaml_set_start_comment("\n".join(lines))


def _path_key(path: tuple[str, ...]) -> str:
    return ".".join(path)


def _new_yaml() -> YamlEmitter:
    yaml = YAML()
    yaml.map_indent = 2
    yaml.sequence_indent = 4
    yaml.sequence_dash_offset = 2
    yaml.width = 120
    yaml.default_flow_style = False
    return yaml


def _reasoning_mapping(value: Reasoning) -> Mapping[str, JSONValue]:
    payload = value.to_json(
        indent=None,
        use_api_names=True,
        exclude_unset=False,
        exclude_none=False,
    )
    parsed = parse_json_object(payload)
    if parsed is None:
        msg = "Reasoning serialization must produce a JSON object"
        raise ConfigError(msg)
    return {
        "effort": parsed.get("effort"),
        "summary": parsed.get("summary"),
    }


def _is_sequence(value: ConfigNode) -> TypeGuard[Sequence[ConfigNode]]:
    return isinstance(value, Sequence) and not isinstance(
        value,
        (str, bytes, bytearray),
    )


def _is_config_dataclass(value: ConfigNode) -> TypeGuard[ConfigDataclass]:
    return is_dataclass(value) and not isinstance(value, Reasoning)


def _is_mapping_node(value: ConfigNode) -> TypeGuard[Mapping[str, ConfigNode]]:
    return isinstance(value, Mapping)


__all__ = ("render_config_template", "validate_template_docs")
