"""Public config surface for agenterm."""

from __future__ import annotations

from agenterm.config.model import AppConfig

__all__ = ("AppConfig",)
