"""Tool policy and auxiliary tool config types."""

from __future__ import annotations

from dataclasses import dataclass, field

from agenterm.constants.limits import (
    INSPECT_MAX_CONCURRENCY_DEFAULT,
    INSPECT_MAX_OPERATIONS_DEFAULT,
)


@dataclass(frozen=True)
class PlanToolConfig:
    """Local plan tool configuration."""


@dataclass(frozen=True)
class InspectToolConfig:
    """Local inspect tool configuration (read-only inspection ingress)."""

    max_operations: int = INSPECT_MAX_OPERATIONS_DEFAULT
    max_concurrency: int = INSPECT_MAX_CONCURRENCY_DEFAULT


@dataclass(frozen=True)
class AgentRunToolConfig:
    """Local agent_run tool configuration (ephemeral delegation)."""

    bundle: str = "openai"


@dataclass(frozen=True)
class AgentRunReportToolConfig:
    """Local agent_run_report tool configuration (report retrieval)."""


@dataclass(frozen=True)
class DangerousToolsConfig:
    """Overrides for dangerous tool labels."""

    add: list[str] = field(default_factory=list)
    remove: list[str] = field(default_factory=list)


__all__ = (
    "AgentRunReportToolConfig",
    "AgentRunToolConfig",
    "DangerousToolsConfig",
    "InspectToolConfig",
    "PlanToolConfig",
)
