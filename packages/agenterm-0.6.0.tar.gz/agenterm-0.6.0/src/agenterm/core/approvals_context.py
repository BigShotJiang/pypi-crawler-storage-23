"""Approvals context and event wiring."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.approvals_audit import (
    AUDIT_MAX_RECORDS,
    ApprovalDecision,
    ApprovalFamily,
    ApprovalsAuditLog,
)
from agenterm.core.approvals_managers import (
    CompressionApprovalManager,
    McpApprovalManager,
    PatchApprovalManager,
    ShellApprovalManager,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.core.approvals_models import (
        CompressionApprovalItem,
        McpApprovalItem,
        PatchApprovalItem,
        ShellApprovalItem,
    )
    from agenterm.core.choices.approvals import ApprovalMode


@dataclass(frozen=True)
class ApprovalEvent:
    """Approval event emitted by an approvals context."""

    family: ApprovalFamily
    item: (
        ShellApprovalItem
        | PatchApprovalItem
        | McpApprovalItem
        | CompressionApprovalItem
    )
    decision: ApprovalDecision | None


@dataclass(frozen=True)
class _Subscriber:
    on_register: Callable[[ApprovalEvent], None] | None
    on_resolve: Callable[[ApprovalEvent], None] | None


class ApprovalsContext:
    """Session-scoped approvals context with subscription fan-out."""

    def __init__(self, *, mode: ApprovalMode = "prompt") -> None:
        """Initialize approvals managers and subscription registry."""
        self._mode: ApprovalMode = mode
        self._audit = ApprovalsAuditLog(max_records=AUDIT_MAX_RECORDS)
        self._subscribers: dict[str, _Subscriber] = {}
        self.shell = ShellApprovalManager(
            audit=self._audit,
            on_register=self._on_shell_register,
            on_resolve=self._on_shell_resolve,
        )
        self.patch = PatchApprovalManager(
            audit=self._audit,
            on_register=self._on_patch_register,
            on_resolve=self._on_patch_resolve,
        )
        self.mcp = McpApprovalManager(
            audit=self._audit,
            on_register=self._on_mcp_register,
            on_resolve=self._on_mcp_resolve,
        )
        self.compress = CompressionApprovalManager(
            audit=self._audit,
            on_register=self._on_compress_register,
            on_resolve=self._on_compress_resolve,
        )

    @property
    def mode(self) -> ApprovalMode:
        """Return the current approvals mode."""
        return self._mode

    def set_mode(self, *, mode: ApprovalMode) -> None:
        """Update the approvals mode."""
        self._mode = mode

    @property
    def audit(self) -> ApprovalsAuditLog:
        """Return the approvals audit log."""
        return self._audit

    def clear_audit(self) -> None:
        """Clear the approvals audit log."""
        self._audit.clear()

    def subscribe(
        self,
        *,
        on_register: Callable[[ApprovalEvent], None] | None = None,
        on_resolve: Callable[[ApprovalEvent], None] | None = None,
    ) -> str:
        """Register callbacks and return an opaque subscription token."""
        token = uuid.uuid4().hex
        self._subscribers[token] = _Subscriber(
            on_register=on_register,
            on_resolve=on_resolve,
        )
        return token

    def unsubscribe(self, token: str) -> None:
        """Remove a subscription by token."""
        self._subscribers.pop(token, None)

    def _dispatch_register(self, event: ApprovalEvent) -> None:
        for sub in tuple(self._subscribers.values()):
            if sub.on_register is not None:
                sub.on_register(event)

    def _dispatch_resolve(self, event: ApprovalEvent) -> None:
        for sub in tuple(self._subscribers.values()):
            if sub.on_resolve is not None:
                sub.on_resolve(event)

    def _on_shell_register(self, item: ShellApprovalItem) -> None:
        event = ApprovalEvent(family="shell", item=item, decision=None)
        self._dispatch_register(event)
        if self._mode == "auto":
            self.shell.resolve(item.id, approved=True, reason=None)

    def _on_patch_register(self, item: PatchApprovalItem) -> None:
        event = ApprovalEvent(family="patch", item=item, decision=None)
        self._dispatch_register(event)
        if self._mode == "auto":
            self.patch.resolve(item.id, approved=True, reason=None)

    def _on_mcp_register(self, item: McpApprovalItem) -> None:
        event = ApprovalEvent(family="mcp", item=item, decision=None)
        self._dispatch_register(event)
        if self._mode == "auto":
            self.mcp.resolve(item.id, approved=True, reason=None)

    def _on_compress_register(self, item: CompressionApprovalItem) -> None:
        event = ApprovalEvent(family="compress", item=item, decision=None)
        self._dispatch_register(event)
        if self._mode == "auto":
            self.compress.resolve(item.id, approved=True, reason=None)

    def _on_shell_resolve(
        self, item: ShellApprovalItem, decision: ApprovalDecision
    ) -> None:
        self._dispatch_resolve(
            ApprovalEvent(family="shell", item=item, decision=decision),
        )

    def _on_patch_resolve(
        self, item: PatchApprovalItem, decision: ApprovalDecision
    ) -> None:
        self._dispatch_resolve(
            ApprovalEvent(family="patch", item=item, decision=decision),
        )

    def _on_mcp_resolve(
        self, item: McpApprovalItem, decision: ApprovalDecision
    ) -> None:
        self._dispatch_resolve(
            ApprovalEvent(family="mcp", item=item, decision=decision),
        )

    def _on_compress_resolve(
        self, item: CompressionApprovalItem, decision: ApprovalDecision
    ) -> None:
        self._dispatch_resolve(
            ApprovalEvent(family="compress", item=item, decision=decision),
        )


__all__ = ("ApprovalEvent", "ApprovalsContext")
