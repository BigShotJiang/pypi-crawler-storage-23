"""Canonical provider error conversion shared by engine and edge reports."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import httpx
from openai import APIError

from agenterm.core.error_litellm import litellm_error_payload
from agenterm.core.error_openai import openai_error_payload

if TYPE_CHECKING:
    from collections.abc import Mapping, MutableMapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class ProviderErrorData:
    """Normalized provider error payload for one exception."""

    provider_label: str | None
    provider_name: str
    detail_message: str | None
    llm_provider: str | None
    details: dict[str, JSONValue]


def provider_display_name(
    label: str | None,
    *,
    llm_provider: str | None = None,
) -> str:
    """Render one canonical provider display name."""
    if label == "openai":
        return "OpenAI"
    if label == "gateway":
        if llm_provider:
            return f"{llm_provider} (via gateway)"
        return "Gateway"
    if isinstance(label, str) and label:
        return label
    return "Provider"


def _provider_label_from_details(
    details: Mapping[str, JSONValue],
    exc: Exception,
) -> str | None:
    raw = details.get("provider")
    if isinstance(raw, str) and raw:
        return raw
    if isinstance(exc, APIError):
        return "openai"
    return None


def _llm_provider_from_details(details: Mapping[str, JSONValue]) -> str | None:
    raw = details.get("llm_provider")
    if isinstance(raw, str) and raw:
        return raw
    return None


def _merge_openai_details(
    *,
    exc: Exception,
    details: MutableMapping[str, JSONValue],
    detail_message: str | None,
) -> tuple[MutableMapping[str, JSONValue], str | None]:
    if not isinstance(exc, APIError):
        return details, detail_message
    openai_message, openai_details = openai_error_payload(exc)
    if openai_details:
        details = {**openai_details, **details}
    if openai_message:
        detail_message = openai_message
    return details, detail_message


def _merge_litellm_details(
    *,
    exc: Exception,
    details: MutableMapping[str, JSONValue],
    detail_message: str | None,
) -> tuple[MutableMapping[str, JSONValue], str | None]:
    litellm_message, litellm_details = litellm_error_payload(exc)
    if detail_message is None and litellm_message:
        detail_message = litellm_message
    for key, value in litellm_details.items():
        if key not in details:
            details[key] = value
    return details, detail_message


def _merge_http_status_details(
    *,
    exc: Exception,
    details: MutableMapping[str, JSONValue],
) -> MutableMapping[str, JSONValue]:
    if not isinstance(exc, httpx.HTTPStatusError):
        return details
    if "status_code" not in details:
        details["status_code"] = int(exc.response.status_code)
    request_id = exc.response.headers.get("x-request-id")
    if request_id and "request_id" not in details:
        details["request_id"] = request_id
    return details


def resolve_provider_error_data(
    exc: Exception,
    *,
    provider_label: str | None = None,
    extra_details: Mapping[str, JSONValue] | None = None,
) -> ProviderErrorData:
    """Build one normalized provider error payload from an exception."""
    details = dict(extra_details) if extra_details is not None else {}
    detail_message: str | None = None
    details, detail_message = _merge_openai_details(
        exc=exc,
        details=details,
        detail_message=detail_message,
    )
    details, detail_message = _merge_litellm_details(
        exc=exc,
        details=details,
        detail_message=detail_message,
    )
    details = _merge_http_status_details(
        exc=exc,
        details=details,
    )

    resolved_provider = provider_label or _provider_label_from_details(details, exc)
    if resolved_provider and "provider" not in details:
        details["provider"] = resolved_provider
    llm_provider = _llm_provider_from_details(details)
    provider_name = provider_display_name(
        resolved_provider,
        llm_provider=llm_provider,
    )
    return ProviderErrorData(
        provider_label=resolved_provider,
        provider_name=provider_name,
        detail_message=detail_message,
        llm_provider=llm_provider,
        details=dict(details),
    )


def provider_error_param_from_exception(
    exc: Exception,
    *,
    provider_label: str | None = None,
    extra_details: Mapping[str, JSONValue] | None = None,
) -> str | None:
    """Extract provider-reported `param` using canonical error conversion."""
    provider_error = resolve_provider_error_data(
        exc,
        provider_label=provider_label,
        extra_details=extra_details,
    )
    raw = provider_error.details.get("param")
    if not isinstance(raw, str):
        return None
    value = raw.strip()
    return value or None


__all__ = (
    "ProviderErrorData",
    "provider_display_name",
    "provider_error_param_from_exception",
    "resolve_provider_error_data",
)
