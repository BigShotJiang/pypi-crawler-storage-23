"""JSON helpers with precise TypeGuards and strict validators.

This module owns the canonical JSON value algebra helpers used across config,
UI rendering, and tool adapters.
"""

from __future__ import annotations

import json as _json
from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, TypeGuard

from agenterm.core.errors import ValidationError
from agenterm.core.json_types import JSONMapping, JSONScalar, JSONValue

if TYPE_CHECKING:
    from collections.abc import Callable

type JSONLike = (
    JSONValue
    | Mapping[str, JSONValue]
    | Sequence[JSONValue]
    | Mapping[JSONScalar, "JSONLike"]
)

type JSONInput = JSONLike | JSONMapping


# Rebind json.loads with a precise return type to avoid Any propagation.
_JSON_LOADS: Callable[[str | bytes | bytearray], JSONValue] = _json.loads


def loads_json_value(payload: str | bytes | bytearray) -> JSONValue:
    """Parse JSON into a JSONValue without propagating Any."""
    return _JSON_LOADS(payload)


def dumps_compact(
    value: JSONInput,
    *,
    sort_keys: bool = False,
    ensure_ascii: bool = True,
    context: str,
) -> str:
    """Dump a JSON value into a compact JSON string (validated)."""
    checked = require_json_value(value=value, context=context)
    return _json.dumps(
        checked,
        separators=(",", ":"),
        sort_keys=sort_keys,
        ensure_ascii=ensure_ascii,
    )


def dumps_pretty(
    value: JSONInput,
    *,
    sort_keys: bool = False,
    ensure_ascii: bool = False,
    indent: int = 2,
    context: str,
) -> str:
    """Dump a JSON value into a human-readable JSON string (validated)."""
    checked = require_json_value(value=value, context=context)
    return _json.dumps(
        checked,
        sort_keys=sort_keys,
        ensure_ascii=ensure_ascii,
        indent=indent,
    )


def json_size(
    value: JSONLike,
    *,
    sort_keys: bool = False,
) -> int:
    """Return the byte length of compact JSON for a JSON value."""
    return len(
        dumps_compact(
            value,
            sort_keys=sort_keys,
            ensure_ascii=True,
            context="json_size",
        )
    )


def parse_json_value(s: str) -> JSONValue | None:
    """Parse a JSON string into a JSONValue or return None on failure."""
    try:
        parsed = _JSON_LOADS(s)
    except (ValueError, TypeError):
        return None
    if not is_json_value(value=parsed):
        return None
    return parsed


def is_json_value(*, value: JSONInput) -> TypeGuard[JSONValue]:
    """Return True if obj is a JSONValue (scalar, list, or dict[str, JSONValue])."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return True
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return all(is_json_value(value=item) for item in value)
    if isinstance(value, Mapping):
        for key, val_obj in value.items():
            if not isinstance(key, str):
                return False
            if not is_json_value(value=val_obj):
                return False
        return True
    return False


def is_json_object(*, value: JSONInput) -> TypeGuard[dict[str, JSONValue]]:
    """Return True if obj is a JSON object mapping str→JSONValue."""
    if not isinstance(value, Mapping):
        return False
    for key, val_obj in value.items():
        if not isinstance(key, str):
            return False
        if not is_json_value(value=val_obj):
            return False
    return True


def parse_json_object(s: str) -> dict[str, JSONValue] | None:
    """Parse a JSON string and return a dict[str, JSONValue] if valid.

    Args:
      s: JSON string expected to represent an object.

    Returns:
      Parsed mapping or None if decoding/validation fails.

    """
    try:
        parsed = _JSON_LOADS(s)
    except (ValueError, TypeError):
        return None
    if not is_json_object(value=parsed):
        return None
    return dict(parsed)


def as_json_object(value: JSONInput) -> dict[str, JSONValue] | None:
    """Return a JSON object mapping or None when input is not JSON-typed."""
    if not isinstance(value, Mapping):
        return None
    out: dict[str, JSONValue] = {}
    for key, val_obj in value.items():
        if not isinstance(key, str):
            return None
        if not is_json_value(value=val_obj):
            return None
        out[key] = val_obj
    return out


def as_json_list(value: JSONInput) -> list[JSONValue] | None:
    """Return a JSON list or None when input is not a JSON list."""
    if not isinstance(value, list):
        return None
    out: list[JSONValue] = []
    for item in value:
        if not is_json_value(value=item):
            return None
        out.append(item)
    return out


def require_json_value(
    *,
    value: JSONInput,
    context: str,
) -> JSONValue:
    """Return a JSONValue or raise ValidationError with context."""
    if not is_json_value(value=value):
        msg = f"{context} must be JSON-serializable"
        raise ValidationError(msg)
    return value


def require_json_object(
    *,
    value: JSONInput,
    context: str,
) -> dict[str, JSONValue]:
    """Return a JSON object or raise ValidationError with context."""
    if not is_json_object(value=value):
        msg = f"{context} must be a JSON object"
        raise ValidationError(msg)
    return dict(value)


def require_str(
    value: JSONValue | None,
    *,
    context: str,
) -> str:
    """Return a non-empty string or raise ValidationError with context."""
    if not isinstance(value, str):
        msg = f"{context} must be a string"
        raise ValidationError(msg)
    if not value:
        msg = f"{context} must be a non-empty string"
        raise ValidationError(msg)
    return value


def require_optional_str(
    value: JSONValue | None,
    *,
    context: str,
) -> str | None:
    """Return a string or None, raising on invalid types."""
    if value is None:
        return None
    if not isinstance(value, str):
        msg = f"{context} must be a string"
        raise ValidationError(msg)
    return value


def require_int(
    value: JSONValue | None,
    *,
    context: str,
) -> int:
    """Return an integer (bool excluded) or raise ValidationError with context."""
    if isinstance(value, bool) or not isinstance(value, int):
        msg = f"{context} must be an integer"
        raise ValidationError(msg)
    return value


def require_optional_int(
    value: JSONValue | None,
    *,
    context: str,
) -> int | None:
    """Return an int or None, raising on invalid types."""
    if value is None:
        return None
    return require_int(value, context=context)


def require_float(
    value: JSONValue | None,
    *,
    context: str,
) -> float:
    """Return a number (bool excluded) as float or raise ValidationError."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        msg = f"{context} must be a number"
        raise ValidationError(msg)
    return float(value)


def require_optional_float(
    value: JSONValue | None,
    *,
    context: str,
) -> float | None:
    """Return a float or None, raising on invalid types."""
    if value is None:
        return None
    return require_float(value, context=context)


def require_bool(
    value: JSONValue | None,
    *,
    context: str,
) -> bool:
    """Return a bool or raise ValidationError with context."""
    if not isinstance(value, bool):
        msg = f"{context} must be a boolean"
        raise ValidationError(msg)
    return value


def require_optional_bool(
    value: JSONValue | None,
    *,
    context: str,
) -> bool | None:
    """Return a bool or None, raising on invalid types."""
    if value is None:
        return None
    return require_bool(value, context=context)


def as_str(value: JSONValue | None) -> str | None:
    """Return a string if already a string."""
    return value if isinstance(value, str) else None


def as_int(value: JSONValue | None) -> int | None:
    """Return an int if already an int (bool excluded)."""
    if isinstance(value, bool):
        return None
    return value if isinstance(value, int) else None


def as_float(value: JSONValue | None) -> float | None:
    """Return a float if already an int/float (bool excluded)."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None


def as_bool(value: JSONValue | None) -> bool | None:
    """Return a bool if already a bool."""
    return value if isinstance(value, bool) else None


def as_str_list(
    value: JSONValue | None,
    *,
    strip: bool = True,
    drop_empty: bool = True,
) -> list[str] | None:
    """Return a list of strings or None when input is not a list of strings."""
    if not isinstance(value, list):
        return None
    out: list[str] = []
    for raw in value:
        if not isinstance(raw, str):
            return None
        s = raw.strip() if strip else raw
        if drop_empty and not s:
            continue
        out.append(s)
    return out


def as_str_dict(value: JSONValue | None) -> dict[str, str] | None:
    """Return a string->string mapping or None when input is not a string map."""
    if not isinstance(value, dict):
        return None
    out: dict[str, str] = {}
    for key, raw in value.items():
        if not isinstance(raw, str):
            return None
        out[key] = raw
    return out


__all__ = (
    "JSONInput",
    "JSONLike",
    "as_bool",
    "as_float",
    "as_int",
    "as_json_list",
    "as_json_object",
    "as_str",
    "as_str_dict",
    "as_str_list",
    "dumps_compact",
    "dumps_pretty",
    "is_json_object",
    "is_json_value",
    "json_size",
    "loads_json_value",
    "parse_json_object",
    "parse_json_value",
    "require_bool",
    "require_float",
    "require_int",
    "require_json_object",
    "require_json_value",
    "require_optional_bool",
    "require_optional_float",
    "require_optional_int",
    "require_optional_str",
    "require_str",
)
