"""Approval manager primitives for tool approvals."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from agenterm.core.approvals_audit import (
    AUDIT_MAX_MCP_ARGS_CHARS,
    AUDIT_MAX_PATCH_DIFF_LINES,
    AUDIT_MAX_SHELL_COMMANDS,
    ApprovalDecision,
    ApprovalFamily,
    ApprovalRequestDetail,
    ApprovalsAuditLog,
    normalize_approval_reason,
    shorten_line,
)
from agenterm.core.approvals_models import (
    CompressionApprovalAction,
    CompressionApprovalDetail,
    CompressionApprovalItem,
    McpApprovalDetail,
    McpApprovalItem,
    PatchApprovalDetail,
    PatchApprovalItem,
    ShellApprovalDetail,
    ShellApprovalItem,
)
from agenterm.core.errors import OperationCancelledError

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.core.cancellation import CancelToken


class ApprovalManager[TDetail, TItem]:
    """Generic in-memory approval manager for a single approval family."""

    def __init__(
        self,
        *,
        family: ApprovalFamily,
        id_prefix: str,
        item_builder: Callable[[str, TDetail], TItem],
        detail_builder: Callable[[TDetail], ApprovalRequestDetail],
        audit: ApprovalsAuditLog | None = None,
        on_register: Callable[[TItem], None] | None = None,
        on_resolve: Callable[[TItem, ApprovalDecision], None] | None = None,
    ) -> None:
        """Initialize tracking maps and id generator."""
        self._family: ApprovalFamily = family
        self._id_prefix = id_prefix
        self._item_builder = item_builder
        self._detail_builder = detail_builder
        self._audit: ApprovalsAuditLog | None = audit
        self._on_register = on_register
        self._on_resolve = on_resolve
        self._next_id: int = 1
        self._futures: dict[str, asyncio.Future[ApprovalDecision]] = {}
        self._items: dict[str, TItem] = {}

    def register_detail(self, detail: TDetail) -> TItem:
        """Register a pending approval detail and return the created item."""
        ident = f"{self._id_prefix}-{self._next_id}"
        self._next_id += 1
        item = self._item_builder(ident, detail)
        self._items[ident] = item
        self._futures[ident] = asyncio.Future()
        if self._audit is not None:
            self._audit.record_request(
                family=self._family,
                ident=ident,
                detail=self._detail_builder(detail),
            )
        if self._on_register is not None:
            self._on_register(item)
        return item

    def pending(self) -> tuple[TItem, ...]:
        """Return all currently pending approvals."""
        return tuple(self._items.values())

    def resolve(self, ident: str, *, approved: bool, reason: str | None = None) -> None:
        """Resolve a pending approval by completing its future."""
        fut = self._futures.get(ident)
        if fut is None or fut.done():
            return
        decision = (
            ApprovalDecision(approved=True, reason=None)
            if approved
            else ApprovalDecision(
                approved=False,
                reason=normalize_approval_reason(reason),
            )
        )
        if self._audit is not None:
            self._audit.record_resolution(ident=ident, decision=decision)
        fut.set_result(decision)
        item = self._items.get(ident)
        if self._on_resolve is not None and item is not None:
            self._on_resolve(item, decision)
        # Remove from pending; the future is kept until wait() returns.
        self._items.pop(ident, None)

    async def wait(
        self,
        ident: str,
        *,
        cancel_token: CancelToken | None = None,
    ) -> ApprovalDecision:
        """Wait for an approval decision and consume the future."""
        fut = self._futures.get(ident)
        if fut is None:
            return ApprovalDecision(approved=False, reason=None)
        if cancel_token is None:
            try:
                return await fut
            finally:
                self._futures.pop(ident, None)
        cancel_task = asyncio.create_task(cancel_token.wait())
        done, pending = await asyncio.wait(
            {fut, cancel_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        if cancel_task in done:
            if not fut.done():
                fut.cancel()
            self._futures.pop(ident, None)
            self._items.pop(ident, None)
            raise OperationCancelledError
        cancel_task.cancel()
        if cancel_task in pending:
            await asyncio.gather(cancel_task, return_exceptions=True)
        try:
            return await fut
        finally:
            self._futures.pop(ident, None)


def _shell_detail(
    commands: list[str],
    cwd: str,
    description: str | None,
) -> ShellApprovalDetail:
    trimmed = tuple(commands[:AUDIT_MAX_SHELL_COMMANDS])
    return ShellApprovalDetail(commands=trimmed, cwd=cwd, description=description)


def _shell_item(ident: str, detail: ShellApprovalDetail) -> ShellApprovalItem:
    return ShellApprovalItem(
        id=ident,
        commands=detail.commands,
        cwd=detail.cwd,
        description=detail.description,
    )


def _shell_audit(detail: ShellApprovalDetail) -> ApprovalRequestDetail:
    return ApprovalRequestDetail(
        cwd=detail.cwd,
        commands=detail.commands,
        description=detail.description,
    )


class ShellApprovalManager:
    """In-memory approval manager for shell tool calls."""

    def __init__(
        self,
        *,
        audit: ApprovalsAuditLog | None = None,
        on_register: Callable[[ShellApprovalItem], None] | None = None,
        on_resolve: Callable[[ShellApprovalItem, ApprovalDecision], None] | None = None,
    ) -> None:
        """Initialize the shell approvals manager."""
        self._mgr = ApprovalManager[
            ShellApprovalDetail,
            ShellApprovalItem,
        ](
            family="shell",
            id_prefix="shell",
            item_builder=_shell_item,
            detail_builder=_shell_audit,
            audit=audit,
            on_register=on_register,
            on_resolve=on_resolve,
        )

    def register(
        self,
        commands: list[str],
        cwd: str,
        *,
        description: str | None = None,
    ) -> ShellApprovalItem:
        """Register a pending shell approval and return the created item."""
        return self._mgr.register_detail(_shell_detail(commands, cwd, description))

    def pending(self) -> tuple[ShellApprovalItem, ...]:
        """Return all currently pending shell approvals."""
        return self._mgr.pending()

    def resolve(self, ident: str, *, approved: bool, reason: str | None = None) -> None:
        """Resolve a pending shell approval by completing its future."""
        self._mgr.resolve(ident, approved=approved, reason=reason)

    async def wait(
        self,
        ident: str,
        *,
        cancel_token: CancelToken | None = None,
    ) -> ApprovalDecision:
        """Wait for an approval decision and consume the future."""
        return await self._mgr.wait(ident, cancel_token=cancel_token)


def _patch_item(ident: str, detail: PatchApprovalDetail) -> PatchApprovalItem:
    return PatchApprovalItem(
        id=ident,
        operation_type=detail.operation_type,
        path=detail.path,
        diff=detail.diff,
        description=detail.description,
    )


def _summarize_diff(diff: str | None) -> str | None:
    if diff is None:
        return None
    raw = diff.strip()
    if not raw:
        return None
    lines = raw.splitlines()
    limited = lines[:AUDIT_MAX_PATCH_DIFF_LINES]
    summary = "\n".join(limited)
    if len(lines) > AUDIT_MAX_PATCH_DIFF_LINES:
        summary = f"{summary}\n…"
    return summary


def _patch_audit(detail: PatchApprovalDetail) -> ApprovalRequestDetail:
    return ApprovalRequestDetail(
        operation_type=detail.operation_type,
        path=detail.path,
        diff_summary=_summarize_diff(detail.diff),
        description=detail.description,
    )


class PatchApprovalManager:
    """In-memory approval manager for apply_patch editor operations."""

    def __init__(
        self,
        *,
        audit: ApprovalsAuditLog | None = None,
        on_register: Callable[[PatchApprovalItem], None] | None = None,
        on_resolve: Callable[[PatchApprovalItem, ApprovalDecision], None] | None = None,
    ) -> None:
        """Initialize the patch approvals manager."""
        self._mgr = ApprovalManager[
            PatchApprovalDetail,
            PatchApprovalItem,
        ](
            family="patch",
            id_prefix="patch",
            item_builder=_patch_item,
            detail_builder=_patch_audit,
            audit=audit,
            on_register=on_register,
            on_resolve=on_resolve,
        )

    def register(
        self,
        op_type: str,
        path: str,
        diff: str | None,
        *,
        description: str | None = None,
    ) -> PatchApprovalItem:
        """Register a pending patch approval and return the created item."""
        detail = PatchApprovalDetail(
            operation_type=op_type,
            path=path,
            diff=diff,
            description=description,
        )
        return self._mgr.register_detail(detail)

    def pending(self) -> tuple[PatchApprovalItem, ...]:
        """Return all currently pending patch approvals."""
        return self._mgr.pending()

    def resolve(self, ident: str, *, approved: bool, reason: str | None = None) -> None:
        """Resolve a pending patch approval by completing its future."""
        self._mgr.resolve(ident, approved=approved, reason=reason)

    async def wait(
        self,
        ident: str,
        *,
        cancel_token: CancelToken | None = None,
    ) -> ApprovalDecision:
        """Wait for an approval decision and consume the future."""
        return await self._mgr.wait(ident, cancel_token=cancel_token)


def _mcp_item(ident: str, detail: McpApprovalDetail) -> McpApprovalItem:
    return McpApprovalItem(
        id=ident,
        server_label=detail.server_label,
        tool_name=detail.tool_name,
        arguments_json=detail.arguments_json,
    )


def _mcp_audit(detail: McpApprovalDetail) -> ApprovalRequestDetail:
    return ApprovalRequestDetail(
        server_label=detail.server_label,
        tool_name=detail.tool_name,
        arguments_json=shorten_line(
            detail.arguments_json,
            limit=AUDIT_MAX_MCP_ARGS_CHARS,
        ),
    )


class McpApprovalManager:
    """In-memory approval manager for hosted MCP tool calls."""

    def __init__(
        self,
        *,
        audit: ApprovalsAuditLog | None = None,
        on_register: Callable[[McpApprovalItem], None] | None = None,
        on_resolve: Callable[[McpApprovalItem, ApprovalDecision], None] | None = None,
    ) -> None:
        """Initialize an empty hosted MCP approvals queue."""
        self._mgr = ApprovalManager[
            McpApprovalDetail,
            McpApprovalItem,
        ](
            family="mcp",
            id_prefix="mcp",
            item_builder=_mcp_item,
            detail_builder=_mcp_audit,
            audit=audit,
            on_register=on_register,
            on_resolve=on_resolve,
        )

    def register(
        self,
        *,
        server_label: str,
        tool_name: str,
        arguments_json: str,
    ) -> McpApprovalItem:
        """Register a pending hosted MCP approval and return the created item."""
        detail = McpApprovalDetail(
            server_label=server_label,
            tool_name=tool_name,
            arguments_json=arguments_json,
        )
        return self._mgr.register_detail(detail)

    def pending(self) -> tuple[McpApprovalItem, ...]:
        """Return all currently pending hosted MCP approvals."""
        return self._mgr.pending()

    def resolve(self, ident: str, *, approved: bool, reason: str | None = None) -> None:
        """Resolve a pending hosted MCP approval by completing its future."""
        self._mgr.resolve(ident, approved=approved, reason=reason)

    async def wait(
        self,
        ident: str,
        *,
        cancel_token: CancelToken | None = None,
    ) -> ApprovalDecision:
        """Wait for an approval decision and consume the future."""
        return await self._mgr.wait(ident, cancel_token=cancel_token)


def _compress_item(
    ident: str,
    detail: CompressionApprovalDetail,
) -> CompressionApprovalItem:
    return CompressionApprovalItem(
        id=ident,
        action=detail.action,
        message=detail.message,
    )


def _compress_audit(detail: CompressionApprovalDetail) -> ApprovalRequestDetail:
    return ApprovalRequestDetail(
        compress_action=detail.action,
        compress_message=detail.message,
    )


class CompressionApprovalManager:
    """In-memory approval manager for compression decisions."""

    def __init__(
        self,
        *,
        audit: ApprovalsAuditLog | None = None,
        on_register: Callable[[CompressionApprovalItem], None] | None = None,
        on_resolve: Callable[[CompressionApprovalItem, ApprovalDecision], None]
        | None = None,
    ) -> None:
        """Initialize the compression approvals manager."""
        self._mgr = ApprovalManager[
            CompressionApprovalDetail,
            CompressionApprovalItem,
        ](
            family="compress",
            id_prefix="compress",
            item_builder=_compress_item,
            detail_builder=_compress_audit,
            audit=audit,
            on_register=on_register,
            on_resolve=on_resolve,
        )

    def register(
        self,
        *,
        action: CompressionApprovalAction,
        message: str,
    ) -> CompressionApprovalItem:
        """Register a pending compression approval and return the created item."""
        detail = CompressionApprovalDetail(action=action, message=message)
        return self._mgr.register_detail(detail)

    def pending(self) -> tuple[CompressionApprovalItem, ...]:
        """Return all currently pending compression approvals."""
        return self._mgr.pending()

    def resolve(self, ident: str, *, approved: bool, reason: str | None = None) -> None:
        """Resolve a pending compression approval by completing its future."""
        self._mgr.resolve(ident, approved=approved, reason=reason)

    async def wait(
        self,
        ident: str,
        *,
        cancel_token: CancelToken | None = None,
    ) -> ApprovalDecision:
        """Wait for an approval decision and consume the future."""
        return await self._mgr.wait(ident, cancel_token=cancel_token)


__all__ = (
    "ApprovalManager",
    "CompressionApprovalManager",
    "McpApprovalManager",
    "PatchApprovalManager",
    "ShellApprovalManager",
)
