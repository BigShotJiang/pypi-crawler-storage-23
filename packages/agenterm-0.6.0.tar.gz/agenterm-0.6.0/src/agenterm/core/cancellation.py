"""Cancellation scope and token primitives shared across the runtime."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

from agenterm.core.errors import OperationCancelledError


@dataclass(frozen=True)
class CancelToken:
    """Shared cancellation token for cooperative aborts."""

    _event: asyncio.Event

    def is_cancelled(self) -> bool:
        """Return True when cancellation has been requested."""
        return self._event.is_set()

    def raise_if_cancelled(self) -> None:
        """Raise when cancellation has been requested."""
        if self._event.is_set():
            raise OperationCancelledError

    async def wait(self) -> None:
        """Block until cancellation is requested."""
        await self._event.wait()


@dataclass(frozen=True)
class CancellationScope:
    """Owned cancellation scope that produces a shared token."""

    _event: asyncio.Event = field(default_factory=asyncio.Event)
    _token: CancelToken = field(init=False)

    def __post_init__(self) -> None:
        """Initialize the shared token from the backing event."""
        object.__setattr__(self, "_token", CancelToken(self._event))

    @property
    def token(self) -> CancelToken:
        """Return the shared cancellation token."""
        return self._token

    def cancel(self) -> None:
        """Request cancellation for the scope."""
        self._event.set()

    def is_cancelled(self) -> bool:
        """Return True when the scope has been cancelled."""
        return self._event.is_set()


__all__ = ("CancelToken", "CancellationScope")
