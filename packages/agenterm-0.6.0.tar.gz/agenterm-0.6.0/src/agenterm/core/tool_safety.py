"""Tool safety labeling and dangerous override resolution."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING, Final

from agenterm.core.toolspec import (
    FN_PREFIX,
    FN_USER_PREFIX,
    HOSTED_MCP_PREFIX,
    HOSTED_OPENAI_PREFIX,
    MCP_SERVER_PREFIX,
    make_hosted_mcp_key,
    make_hosted_openai_key,
    make_mcp_server_key,
    make_user_fn_key,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Mapping, MutableMapping, Sequence

    from agenterm.config.tools_policy import DangerousToolsConfig
    from agenterm.core.toolspec import ToolSpec


DEFAULT_DANGEROUS_REFS: Final[tuple[str, ...]] = (
    "fn:shell",
    "fn:apply_patch",
    "fn:user:*",
    "mcp:*",
    "hosted:mcp:*",
)


def _resolve_prefix(
    *,
    tools_map: Mapping[str, ToolSpec],
    prefix: str,
) -> set[str]:
    return {key for key in tools_map if key.startswith(prefix)}


def _resolve_fn_ref(
    parts: list[str],
    *,
    tools_map: Mapping[str, ToolSpec],
) -> set[str]:
    match parts:
        case [] | ["*"]:
            return _resolve_prefix(tools_map=tools_map, prefix=FN_PREFIX)
        case ["user"] | ["user", "*"]:
            return _resolve_prefix(tools_map=tools_map, prefix=FN_USER_PREFIX)
        case ["user", name]:
            key = make_user_fn_key(name)
            return {key} if key in tools_map else set()
        case _:
            return set()


def _resolve_wildcard_or_key(
    parts: list[str],
    *,
    tools_map: Mapping[str, ToolSpec],
    prefix: str,
    make_key: Callable[[str], str],
) -> set[str]:
    match parts:
        case [] | ["*"]:
            return _resolve_prefix(tools_map=tools_map, prefix=prefix)
        case [name]:
            key = make_key(name)
            return {key} if key in tools_map else set()
        case _:
            return set()


def _resolve_hosted_ref(
    parts: list[str],
    *,
    tools_map: Mapping[str, ToolSpec],
) -> set[str]:
    if not parts:
        return set()
    kind, *rest = parts
    if kind == "openai":
        return _resolve_wildcard_or_key(
            rest,
            tools_map=tools_map,
            prefix=HOSTED_OPENAI_PREFIX,
            make_key=make_hosted_openai_key,
        )
    if kind == "mcp":
        return _resolve_wildcard_or_key(
            rest,
            tools_map=tools_map,
            prefix=HOSTED_MCP_PREFIX,
            make_key=make_hosted_mcp_key,
        )
    return set()


def _resolve_mcp_ref(
    parts: list[str],
    *,
    tools_map: Mapping[str, ToolSpec],
) -> set[str]:
    return _resolve_wildcard_or_key(
        parts,
        tools_map=tools_map,
        prefix=MCP_SERVER_PREFIX,
        make_key=make_mcp_server_key,
    )


def _resolve_type_ref(ref: str, *, tools_map: Mapping[str, ToolSpec]) -> set[str]:
    return {key for key, spec in tools_map.items() if spec.type == ref}


def _resolve_ref(ref: str, *, tools_map: Mapping[str, ToolSpec]) -> set[str]:
    if ref in tools_map:
        return {ref}
    parts = [part for part in ref.split(":") if part]
    if not parts:
        return set()
    head, *rest = parts
    if head == "fn":
        return _resolve_fn_ref(rest, tools_map=tools_map)
    if head == "hosted":
        return _resolve_hosted_ref(rest, tools_map=tools_map)
    if head == "mcp":
        return _resolve_mcp_ref(rest, tools_map=tools_map)
    return _resolve_type_ref(ref, tools_map=tools_map)


def resolve_tool_refs(
    refs: Iterable[str],
    *,
    tools_map: Mapping[str, ToolSpec],
) -> set[str]:
    """Resolve tool references into concrete tool keys.

    Supported refs:
    - explicit tool keys (`fn:*`, `fn:user:*`, `hosted:*`, `mcp:*`)
    - built-in names (file_search, web_search, image_generation, inspect,
      shell, apply_patch, plan, agent_run, agent_run_report, steward)
    - fn:user:<name> or fn:user:* (user FunctionTools)
    - hosted:mcp:<name> or hosted:mcp:* (OpenAI hosted connectors)
    - hosted:openai:<tool> or hosted:openai:* (OpenAI hosted tools)
    - mcp:<server_key> or mcp:* (client MCP servers)
    """
    resolved: set[str] = set()
    for raw in refs:
        ref = str(raw).strip()
        if not ref:
            continue
        resolved |= _resolve_ref(ref, tools_map=tools_map)
    return resolved


def apply_tool_safety(
    *,
    tools_map: MutableMapping[str, ToolSpec],
    overrides: DangerousToolsConfig,
    defaults: Sequence[str] = DEFAULT_DANGEROUS_REFS,
) -> None:
    """Apply dangerous label defaults and overrides to tool specs."""
    default_keys = resolve_tool_refs(defaults, tools_map=tools_map)
    add_keys = resolve_tool_refs(overrides.add, tools_map=tools_map)
    remove_keys = resolve_tool_refs(overrides.remove, tools_map=tools_map)

    for key in default_keys | add_keys:
        spec = tools_map.get(key)
        if spec is None or spec.dangerous:
            continue
        tools_map[key] = replace(spec, dangerous=True)

    for key in remove_keys:
        spec = tools_map.get(key)
        if spec is None or not spec.dangerous:
            continue
        tools_map[key] = replace(spec, dangerous=False)


__all__ = ("DEFAULT_DANGEROUS_REFS", "apply_tool_safety", "resolve_tool_refs")
