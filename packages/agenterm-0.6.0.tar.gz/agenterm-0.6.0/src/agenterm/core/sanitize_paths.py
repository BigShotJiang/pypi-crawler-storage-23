"""Path redaction for model-facing text and JSON payloads.

Absolute filesystem paths are replaced with ``[redacted_path]`` so
model-facing error envelopes never leak workspace locations.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Final

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue

REDACTED_PATH: Final[str] = "[redacted_path]"

# Unix: /segment/segment... — stop at whitespace, quotes, backticks.
# Lookbehind excludes word chars, dot, slash, hyphen to avoid matching
# URL paths (://path), relative paths (./path), and mid-word slashes.
_UNIX_ABSOLUTE_PATH_RE: Final[re.Pattern[str]] = re.compile(
    r"(?<![\w./-])/(?:[^/\s\"'`]+(?:/[^/\s\"'`]+)*)"
)
# Windows: C:\segment\segment... (runtime form) and escaped renderings where
# separators appear doubled (for example: C:\\segment\\segment in logs).
_WINDOWS_ABSOLUTE_PATH_RE: Final[re.Pattern[str]] = re.compile(
    r"(?<![\w./-])[A-Za-z]:(?:\\+[^\\\s\"'`]+)+"
)


def sanitize_path_text(text: str) -> str:
    """Replace absolute filesystem paths with a redaction placeholder."""
    redacted = _WINDOWS_ABSOLUTE_PATH_RE.sub(REDACTED_PATH, text)
    return _UNIX_ABSOLUTE_PATH_RE.sub(REDACTED_PATH, redacted)


def sanitize_json_paths(value: JSONValue) -> JSONValue:
    """Recursively redact absolute paths in a JSON-safe value tree."""
    if value is None:
        return None
    if isinstance(value, str):
        return sanitize_path_text(value)
    if isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, list):
        return [sanitize_json_paths(item) for item in value]
    return {str(key): sanitize_json_paths(item) for key, item in value.items()}


__all__ = (
    "REDACTED_PATH",
    "sanitize_json_paths",
    "sanitize_path_text",
)
