"""Registry and lookup for optional MCP customization hooks.

This module exists to expose Agents SDK MCP server customization hooks that are
callable-based (tool_filter callable, message_handler, httpx_client_factory)
without putting callables directly into config.yaml.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, MutableMapping
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from agents.mcp.util import HttpClientFactory, ToolFilterContext
    from mcp import types as mtypes
    from mcp.client.session import MessageHandlerFnT

ToolFilterFn = Callable[["ToolFilterContext", "mtypes.Tool"], bool | Awaitable[bool]]

_TOOL_FILTERS: MutableMapping[str, ToolFilterFn] = {}
_MESSAGE_HANDLERS: MutableMapping[str, MessageHandlerFnT] = {}
_HTTPX_CLIENT_FACTORIES: MutableMapping[str, HttpClientFactory] = {}


def register_tool_filter(name: str, func: ToolFilterFn) -> None:
    """Register a dynamic MCP tool filter under a stable key."""
    key = name.strip()
    if not key:
        message = "MCP tool_filter name must be non-empty"
        raise ConfigError(message)
    _TOOL_FILTERS[key] = func


def register_message_handler(name: str, func: MessageHandlerFnT) -> None:
    """Register an MCP client session message handler under a stable key."""
    key = name.strip()
    if not key:
        message = "MCP message_handler name must be non-empty"
        raise ConfigError(message)
    _MESSAGE_HANDLERS[key] = func


def register_httpx_client_factory(name: str, func: HttpClientFactory) -> None:
    """Register a Streamable HTTP httpx client factory under a stable key."""
    key = name.strip()
    if not key:
        message = "MCP httpx_client_factory name must be non-empty"
        raise ConfigError(message)
    _HTTPX_CLIENT_FACTORIES[key] = func


def resolve_tool_filter(key: str) -> ToolFilterFn:
    """Resolve a tool filter callable by key."""
    name = key.strip()
    if not name:
        message = "MCP tool_filter key must be non-empty"
        raise ConfigError(message)
    fn = _TOOL_FILTERS.get(name)
    if fn is None:
        message = f"Unknown MCP tool_filter callable_key: {name}"
        raise ConfigError(message)
    return fn


def resolve_message_handler(key: str) -> MessageHandlerFnT:
    """Resolve an MCP message_handler callable by key."""
    name = key.strip()
    if not name:
        message = "MCP message_handler_key must be non-empty"
        raise ConfigError(message)
    fn = _MESSAGE_HANDLERS.get(name)
    if fn is None:
        message = f"Unknown MCP message_handler_key: {name}"
        raise ConfigError(message)
    return fn


def resolve_httpx_client_factory(key: str) -> HttpClientFactory:
    """Resolve a Streamable HTTP httpx client factory callable by key."""
    name = key.strip()
    if not name:
        message = "MCP httpx_client_factory_key must be non-empty"
        raise ConfigError(message)
    fn = _HTTPX_CLIENT_FACTORIES.get(name)
    if fn is None:
        message = f"Unknown MCP httpx_client_factory_key: {name}"
        raise ConfigError(message)
    return fn


__all__ = (
    "ToolFilterFn",
    "register_httpx_client_factory",
    "register_message_handler",
    "register_tool_filter",
    "resolve_httpx_client_factory",
    "resolve_message_handler",
    "resolve_tool_filter",
)
