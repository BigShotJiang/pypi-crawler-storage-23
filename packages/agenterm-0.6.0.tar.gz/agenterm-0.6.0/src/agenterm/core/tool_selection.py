"""Tool selection helpers for agenterm.

Selection is structural and uses **tool keys**:

- `hosted:*` for provider-hosted tools (background-compatible)
- `fn:*` / `fn:user:*` for local FunctionTools (requires the agenterm process)
- `mcp:*` for client MCP servers (requires the agenterm process)

MCP servers are selectable tools (`mcp:<server_key>`), not a
separate selection channel.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.errors import ValidationError
from agenterm.core.selection_utils import dedupe_str, expand_bundle_keys

if TYPE_CHECKING:
    from collections.abc import Iterable, Mapping, Sequence

    from agenterm.config.model import McpServerConfig
    from agenterm.core.model_id import ModelPlane
    from agenterm.core.toolspec import ToolSpec


@dataclass(frozen=True)
class ToolCatalog:
    """Canonical catalog for tool selection resolution."""

    tools_map: Mapping[str, ToolSpec]
    bundles_map: Mapping[str, list[str]]
    default_bundles: list[str]


@dataclass(frozen=True)
class ToolSelection:
    """Immutable selection of bundles and tool keys."""

    selected_bundles: tuple[str, ...] = ()
    selected_keys: tuple[str, ...] = ()
    explicit_override: bool = False

    def add_bundles(self, bundles: Iterable[str]) -> ToolSelection:
        """Return a new selection with bundles added if not present."""
        seen = set(self.selected_bundles)
        out = list(self.selected_bundles)
        for b in bundles:
            sb = str(b)
            if sb not in seen:
                seen.add(sb)
                out.append(sb)
        return ToolSelection(tuple(out), self.selected_keys, self.explicit_override)

    def remove_bundles(self, bundles: Iterable[str]) -> ToolSelection:
        """Return a new selection without the specified bundle names."""
        rem = {str(b) for b in bundles}
        out = tuple(x for x in self.selected_bundles if x not in rem)
        return ToolSelection(out, self.selected_keys, self.explicit_override)

    def add_keys(self, keys: Iterable[str]) -> ToolSelection:
        """Return a new selection with tool keys added if not present."""
        seen = set(self.selected_keys)
        out = list(self.selected_keys)
        for k in keys:
            sk = str(k)
            if sk not in seen:
                seen.add(sk)
                out.append(sk)
        return ToolSelection(self.selected_bundles, tuple(out), self.explicit_override)

    def remove_keys(self, keys: Iterable[str]) -> ToolSelection:
        """Return a new selection without the specified tool keys."""
        rem = {str(k) for k in keys}
        out = tuple(x for x in self.selected_keys if x not in rem)
        return ToolSelection(self.selected_bundles, out, self.explicit_override)

    def clear(self) -> ToolSelection:
        """Return an empty selection for bundles and tool keys."""
        return ToolSelection((), (), self.explicit_override)

    def with_override(self, *, explicit_override: bool) -> ToolSelection:
        """Return a new selection with explicit_override set."""
        return ToolSelection(
            self.selected_bundles,
            self.selected_keys,
            explicit_override,
        )

    def effective_keys(
        self,
        *,
        tools_map: Mapping[str, ToolSpec],
        bundles_map: Mapping[str, list[str]],
    ) -> list[str]:
        """Compute effective tool keys from the selection and bundle map."""
        return _effective_tool_keys(
            tools_map=tools_map,
            bundles_map=bundles_map,
            selected_bundles=self.selected_bundles,
            selected_keys=self.selected_keys,
        )


@dataclass(frozen=True)
class ResolvedSelection:
    """Resolved selection keys/specs (plus optional error string)."""

    keys: tuple[str, ...]
    specs: tuple[ToolSpec, ...]
    error: str | None = None


def selection_from_flags(
    *,
    default_bundles: list[str],
    cli_bundles: Iterable[str] | None,
    cli_keys: Iterable[str] | None,
) -> ToolSelection:
    """Return a ToolSelection derived from CLI flags or defaults."""
    explicit = cli_bundles is not None or cli_keys is not None
    if explicit:
        bundles = tuple(str(b) for b in (cli_bundles or ()))
        keys = tuple(str(k) for k in (cli_keys or ()))
        return ToolSelection(bundles, keys, explicit_override=True)
    if default_bundles:
        return ToolSelection(
            tuple(str(b) for b in default_bundles),
            (),
            explicit_override=False,
        )
    return ToolSelection((), (), explicit_override=False)


def split_cli_selection_tokens(
    tokens: Iterable[str],
    *,
    catalog: ToolCatalog,
) -> tuple[list[str], list[str]]:
    """Split CLI selection tokens into bundle names and tool keys."""
    bundles: list[str] = []
    keys: list[str] = []
    for token in tokens:
        value = str(token)
        in_bundles = value in catalog.bundles_map
        in_tools = value in catalog.tools_map
        if in_bundles and in_tools:
            message = (
                "Selection token matches both bundle and tool key: "
                f"{value}. Rename one or remove the collision."
            )
            raise ValidationError(message)
        if in_bundles:
            bundles.append(value)
        else:
            keys.append(value)
    return bundles, keys


def resolve_selection(
    selection: ToolSelection,
    *,
    catalog: ToolCatalog,
) -> ResolvedSelection:
    """Resolve selection bundles/keys into concrete ToolSpec entries."""
    try:
        keys = selection.effective_keys(
            tools_map=catalog.tools_map,
            bundles_map=catalog.bundles_map,
        )
    except ValidationError as exc:
        return ResolvedSelection(keys=(), specs=(), error=str(exc))
    specs = tuple(catalog.tools_map[k] for k in keys)
    return ResolvedSelection(keys=tuple(keys), specs=specs, error=None)


def filter_selection_specs(
    specs: Sequence[ToolSpec],
    *,
    allow_dangerous: bool,
    hosted_mode: bool,
    model_plane: ModelPlane,
) -> tuple[ToolSpec, ...]:
    """Apply runtime filters to a resolved selection spec list."""
    if model_plane == "gateway":
        hosted = [spec.key for spec in specs if spec.plane == "hosted"]
        if hosted:
            message = (
                "Gateway models do not support hosted tools. "
                f"Remove: {', '.join(hosted)}"
            )
            raise ValidationError(message)
    filtered: list[ToolSpec] = list(specs)
    if hosted_mode:
        filtered = [spec for spec in filtered if spec.plane == "hosted"]
    if not allow_dangerous:
        filtered = [spec for spec in filtered if not spec.dangerous]
    return tuple(filtered)


def selected_mcp_server_configs(
    specs: Sequence[ToolSpec],
) -> tuple[McpServerConfig, ...]:
    """Return selected McpServerConfig entries (ordered, deduped)."""
    out: list[McpServerConfig] = []
    seen: set[str] = set()
    for spec in specs:
        if spec.type != "mcp_server":
            continue
        server = spec.mcp_server
        if server is None:
            continue
        key = str(server.key)
        if key in seen:
            continue
        seen.add(key)
        out.append(server)
    return tuple(out)


def _effective_tool_keys(
    *,
    tools_map: Mapping[str, ToolSpec],
    bundles_map: Mapping[str, list[str]],
    selected_bundles: Iterable[str],
    selected_keys: Iterable[str],
) -> list[str]:
    """Compute validated, deduplicated tool keys from selection."""
    keys: list[str] = []
    for b in selected_bundles:
        sb = str(b)
        if sb not in bundles_map:
            message = f"Unknown bundle: {sb}"
            raise ValidationError(message)
        keys.extend(
            expand_bundle_keys(
                sb,
                bundles=bundles_map,
            ),
        )
    keys.extend([str(k) for k in selected_keys])
    deduped = dedupe_str(keys)
    for k in deduped:
        if k not in tools_map:
            message = f"Unknown tool key: {k}"
            raise ValidationError(message)
    return deduped


__all__ = (
    "ResolvedSelection",
    "ToolCatalog",
    "ToolSelection",
    "filter_selection_specs",
    "resolve_selection",
    "selected_mcp_server_configs",
    "selection_from_flags",
    "split_cli_selection_tokens",
)
