"""Rate-limit metadata parsing for error reports."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.rate_limits import parse_retry_after_seconds

if TYPE_CHECKING:
    from collections.abc import Mapping

    import httpx

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class RateLimitInfo:
    """Normalized provider rate-limit metadata."""

    request_id: str | None
    retry_after_seconds: float | None
    limit_requests: int | None
    remaining_requests: int | None
    reset_requests_seconds: float | None
    limit_tokens: int | None
    remaining_tokens: int | None
    reset_tokens_seconds: float | None
    headers: Mapping[str, str] | None = None

    def to_json(self) -> dict[str, JSONValue]:
        """Convert to a JSONValue mapping."""
        return {
            "request_id": self.request_id,
            "retry_after_seconds": self.retry_after_seconds,
            "limit_requests": self.limit_requests,
            "remaining_requests": self.remaining_requests,
            "reset_requests_seconds": self.reset_requests_seconds,
            "limit_tokens": self.limit_tokens,
            "remaining_tokens": self.remaining_tokens,
            "reset_tokens_seconds": self.reset_tokens_seconds,
            "headers": dict(self.headers) if self.headers is not None else None,
        }


def _collect_rate_limit_headers(headers: httpx.Headers | None) -> dict[str, str] | None:
    if headers is None:
        return None
    collected: dict[str, str] = {}
    for key, value in headers.items():
        lower = key.lower()
        if lower.startswith("x-ratelimit-") or lower in (
            "retry-after",
            "retry-after-ms",
        ):
            collected[lower] = value
    return collected or None


def _parse_int_header(headers: httpx.Headers | None, name: str) -> int | None:
    if headers is None:
        return None
    raw = headers.get(name)
    if raw is None:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def _parse_float_header(headers: httpx.Headers | None, name: str) -> float | None:
    if headers is None:
        return None
    raw = headers.get(name)
    if raw is None:
        return None
    try:
        return float(raw)
    except (TypeError, ValueError):
        return None


def rate_limit_info_from_headers(
    headers: httpx.Headers | None,
    *,
    request_id: str | None,
) -> RateLimitInfo | None:
    """Return a normalized rate-limit payload from HTTP headers."""
    if headers is None:
        return None
    retry_after = parse_retry_after_seconds(headers)
    limit_requests = _parse_int_header(headers, "x-ratelimit-limit-requests")
    remaining_requests = _parse_int_header(headers, "x-ratelimit-remaining-requests")
    reset_requests_seconds = _parse_float_header(headers, "x-ratelimit-reset-requests")
    limit_tokens = _parse_int_header(headers, "x-ratelimit-limit-tokens")
    remaining_tokens = _parse_int_header(headers, "x-ratelimit-remaining-tokens")
    reset_tokens_seconds = _parse_float_header(headers, "x-ratelimit-reset-tokens")
    headers_out = _collect_rate_limit_headers(headers)
    if (
        retry_after is None
        and limit_requests is None
        and remaining_requests is None
        and reset_requests_seconds is None
        and limit_tokens is None
        and remaining_tokens is None
        and reset_tokens_seconds is None
        and headers_out is None
        and request_id is None
    ):
        return None
    return RateLimitInfo(
        request_id=request_id,
        retry_after_seconds=retry_after,
        limit_requests=limit_requests,
        remaining_requests=remaining_requests,
        reset_requests_seconds=reset_requests_seconds,
        limit_tokens=limit_tokens,
        remaining_tokens=remaining_tokens,
        reset_tokens_seconds=reset_tokens_seconds,
        headers=headers_out,
    )


__all__ = ("RateLimitInfo", "rate_limit_info_from_headers")
