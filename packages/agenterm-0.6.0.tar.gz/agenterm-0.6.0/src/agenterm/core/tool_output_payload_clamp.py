"""Structured payload clamp helpers for tool output envelopes.

Preserves top-level keys + pagination cursors and fits within a size budget.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agenterm.core.json_types import JSONValue

    type _IntPredicate = Callable[[int], bool]

_PREFERRED_PAGED_LIST_KEYS = (
    "matches",
    "lines",
    "files",
    "counts",
    "responses",
    "results",
    "nodes",
)
_IDENTIFIER_STRING_KEYS = frozenset(
    [
        "path",
        "root",
        "type",
        "kind",
        "command",
        "cwd",
        "working_directory",
        "report_id",
        "response_id",
        "trace_id",
        "session_id",
        "branch_id",
    ]
)
_IDENTIFIER_STRING_LIST_KEYS = frozenset(["matches", "files", "paths", "commands"])


def _binary_search_max_candidate[T](
    *,
    low: int,
    high: int,
    make_candidate: Callable[[int], T],
    fits: Callable[[T], bool],
) -> T | None:
    best: T | None = None
    while low <= high:
        mid = (low + high) // 2
        candidate = make_candidate(mid)
        if fits(candidate):
            best = candidate
            low = mid + 1
        else:
            high = mid - 1
    return best


def _binary_search_max_int(*, low: int, high: int, fits: _IntPredicate) -> int | None:
    best: int | None = None
    while low <= high:
        mid = (low + high) // 2
        if fits(mid):
            best = mid
            low = mid + 1
        else:
            high = mid - 1
    return best


def _as_int(value: JSONValue | None) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return int(value)


def _as_json_object(value: JSONValue | None) -> dict[str, JSONValue] | None:
    if not isinstance(value, dict):
        return None
    return value


def _as_json_list(value: JSONValue | None) -> list[JSONValue] | None:
    if not isinstance(value, list):
        return None
    return value


def _paged_list_key(payload: Mapping[str, JSONValue]) -> str | None:
    page = _as_json_object(payload.get("page"))
    if page is None:
        return None
    returned = _as_int(page.get("returned"))
    if returned is None:
        return None
    candidates: list[str] = []
    for key, value in payload.items():
        if key == "page":
            continue
        items = _as_json_list(value)
        if items is None:
            continue
        if len(items) == returned:
            candidates.append(key)
    if not candidates:
        return None
    for key in _PREFERRED_PAGED_LIST_KEYS:
        if key in candidates:
            return key
    return sorted(candidates)[0]


def _sync_page_for_list_prefix(
    original: Mapping[str, JSONValue],
    payload: Mapping[str, JSONValue],
    *,
    list_key: str,
) -> dict[str, JSONValue]:
    """Return payload with page fields updated to match the list prefix length."""
    original_page = _as_json_object(original.get("page"))
    page = _as_json_object(payload.get("page"))
    items = _as_json_list(payload.get(list_key))
    original_items = _as_json_list(original.get(list_key))
    if original_page is None or page is None or items is None or original_items is None:
        return dict(payload)
    original_returned = _as_int(original_page.get("returned"))
    cursor = _as_int(original_page.get("cursor"))
    if original_returned is None:
        return dict(payload)
    returned = len(items)
    if returned == original_returned:
        return dict(payload)
    updated = dict(page)
    updated["returned"] = int(returned)
    if returned < original_returned and cursor is not None:
        next_cursor = int(cursor + returned)
        updated["next_cursor"] = next_cursor
        updated["has_more"] = True
    payload_out = dict(payload)
    payload_out["page"] = updated
    return payload_out


def _clamp_json_value(
    value: JSONValue,
    *,
    key: str | None,
    max_str_chars: int,
    max_list_items: int,
    max_obj_keys: int,
    depth: int,
    limit_text: Callable[[str, int], str],
) -> JSONValue:
    if isinstance(value, str):
        if key is not None and (
            key in _IDENTIFIER_STRING_KEYS or key in _IDENTIFIER_STRING_LIST_KEYS
        ):
            return value
        return limit_text(value, max_str_chars)
    if isinstance(value, list):
        items = value[: max(0, int(max_list_items))]
        return [
            _clamp_json_value(
                item,
                key=key,
                max_str_chars=max_str_chars,
                max_list_items=max_list_items,
                max_obj_keys=max_obj_keys,
                depth=depth + 1,
                limit_text=limit_text,
            )
            for item in items
        ]
    if isinstance(value, dict):
        obj_keys: list[str] = list(value.keys())
        if depth > 0 and len(obj_keys) > max_obj_keys:
            obj_keys = obj_keys[: max(0, int(max_obj_keys))]
        out: dict[str, JSONValue] = {}
        for k in obj_keys:
            out[k] = _clamp_json_value(
                value[k],
                key=k,
                max_str_chars=max_str_chars,
                max_list_items=max_list_items,
                max_obj_keys=max_obj_keys,
                depth=depth + 1,
                limit_text=limit_text,
            )
        return out
    return value


def _clamp_payload_mapping(
    payload: Mapping[str, JSONValue],
    *,
    max_str_chars: int,
    max_list_items: int,
    max_obj_keys: int,
    limit_text: Callable[[str, int], str],
) -> dict[str, JSONValue]:
    out: dict[str, JSONValue] = {}
    for key, value in payload.items():
        out[key] = _clamp_json_value(
            value,
            key=key,
            max_str_chars=max_str_chars,
            max_list_items=max_list_items,
            max_obj_keys=max_obj_keys,
            depth=0,
            limit_text=limit_text,
        )
    return out


def _apply_clamp(
    *,
    payload: Mapping[str, JSONValue],
    list_key: str | None,
    limit_text: Callable[[str, int], str],
    max_str_chars: int,
    max_list_items: int,
    max_obj_keys: int,
) -> dict[str, JSONValue]:
    clamped = _clamp_payload_mapping(
        payload,
        max_str_chars=max_str_chars,
        max_list_items=max_list_items,
        max_obj_keys=max_obj_keys,
        limit_text=limit_text,
    )
    if list_key is None:
        return clamped
    return _sync_page_for_list_prefix(payload, clamped, list_key=list_key)


def _max_string_length(value: JSONValue) -> int:
    if isinstance(value, str):
        return len(value)
    if isinstance(value, list):
        return max((_max_string_length(item) for item in value), default=0)
    if isinstance(value, dict):
        return max((_max_string_length(item) for item in value.values()), default=0)
    return 0


def _max_list_length(value: JSONValue) -> int:
    if isinstance(value, list):
        inner = max((_max_list_length(item) for item in value), default=0)
        return max(len(value), inner)
    if isinstance(value, dict):
        return max((_max_list_length(item) for item in value.values()), default=0)
    return 0


def _max_object_keys(value: JSONValue, *, depth: int) -> int:
    if isinstance(value, dict):
        here = len(value) if depth > 0 else 0
        inner = max(
            (_max_object_keys(item, depth=depth + 1) for item in value.values()),
            default=0,
        )
        return max(here, inner)
    if isinstance(value, list):
        return max(
            (_max_object_keys(item, depth=depth + 1) for item in value),
            default=0,
        )
    return 0


def _fit_paged_list_prefix(
    *,
    payload: Mapping[str, JSONValue],
    list_key: str,
    max_chars: int,
    size: Callable[[Mapping[str, JSONValue]], int],
) -> dict[str, JSONValue] | None:
    items = _as_json_list(payload.get(list_key)) or []
    if not items:
        return None

    def _make(mid: int) -> dict[str, JSONValue]:
        candidate = dict(payload)
        candidate[list_key] = list(items[:mid])
        return _sync_page_for_list_prefix(payload, candidate, list_key=list_key)

    return _binary_search_max_candidate(
        low=0,
        high=len(items),
        make_candidate=_make,
        fits=lambda candidate: size(candidate) <= max_chars,
    )


def _best_payload_for_string_limit(
    *,
    payload: Mapping[str, JSONValue],
    list_key: str | None,
    limit_text: Callable[[str, int], str],
    max_chars: int,
    size: Callable[[Mapping[str, JSONValue]], int],
    str_hi: int,
    max_list_items: int,
    max_obj_keys: int,
) -> dict[str, JSONValue] | None:
    def _make(mid: int) -> dict[str, JSONValue]:
        return _apply_clamp(
            payload=payload,
            list_key=list_key,
            limit_text=limit_text,
            max_str_chars=mid,
            max_list_items=max_list_items,
            max_obj_keys=max_obj_keys,
        )

    return _binary_search_max_candidate(
        low=0,
        high=str_hi,
        make_candidate=_make,
        fits=lambda candidate: size(candidate) <= max_chars,
    )


def _best_list_limit(
    *,
    payload: Mapping[str, JSONValue],
    list_key: str | None,
    limit_text: Callable[[str, int], str],
    max_chars: int,
    size: Callable[[Mapping[str, JSONValue]], int],
    list_hi: int,
    max_str_chars: int,
    max_obj_keys: int,
) -> int | None:
    def _fits(mid: int) -> bool:
        candidate = _apply_clamp(
            payload=payload,
            list_key=list_key,
            limit_text=limit_text,
            max_str_chars=max_str_chars,
            max_list_items=mid,
            max_obj_keys=max_obj_keys,
        )
        return size(candidate) <= max_chars

    return _binary_search_max_int(low=0, high=list_hi, fits=_fits)


def _fit_generic_payload(
    *,
    payload: Mapping[str, JSONValue],
    max_chars: int,
    size: Callable[[Mapping[str, JSONValue]], int],
    limit_text: Callable[[str, int], str],
) -> dict[str, JSONValue]:
    list_key = _paged_list_key(payload)
    str_hi = min(max_chars, _max_string_length(dict(payload)))
    list_hi = _max_list_length(dict(payload))
    obj_hi = max(0, _max_object_keys(dict(payload), depth=0))

    best = _best_payload_for_string_limit(
        payload=payload,
        list_key=list_key,
        limit_text=limit_text,
        max_chars=max_chars,
        size=size,
        str_hi=str_hi,
        max_list_items=list_hi,
        max_obj_keys=obj_hi,
    )
    if best is not None:
        return best

    list_limit = _best_list_limit(
        payload=payload,
        list_key=list_key,
        limit_text=limit_text,
        max_chars=max_chars,
        size=size,
        list_hi=list_hi,
        max_str_chars=0,
        max_obj_keys=obj_hi,
    )
    if list_limit is not None:
        best = _best_payload_for_string_limit(
            payload=payload,
            list_key=list_key,
            limit_text=limit_text,
            max_chars=max_chars,
            size=size,
            str_hi=str_hi,
            max_list_items=list_limit,
            max_obj_keys=obj_hi,
        )
        if best is not None:
            return best
        return _apply_clamp(
            payload=payload,
            list_key=list_key,
            limit_text=limit_text,
            max_str_chars=0,
            max_list_items=list_limit,
            max_obj_keys=obj_hi,
        )

    def _fits_obj_keys(mid: int) -> bool:
        candidate = _apply_clamp(
            payload=payload,
            list_key=list_key,
            limit_text=limit_text,
            max_str_chars=0,
            max_list_items=0,
            max_obj_keys=mid,
        )
        return size(candidate) <= max_chars

    obj_limit = _binary_search_max_int(low=0, high=obj_hi, fits=_fits_obj_keys)
    if obj_limit is None:
        return {}

    list_limit = _best_list_limit(
        payload=payload,
        list_key=list_key,
        limit_text=limit_text,
        max_chars=max_chars,
        size=size,
        list_hi=list_hi,
        max_str_chars=0,
        max_obj_keys=obj_limit,
    )
    if list_limit is None:
        list_limit = 0

    best = _best_payload_for_string_limit(
        payload=payload,
        list_key=list_key,
        limit_text=limit_text,
        max_chars=max_chars,
        size=size,
        str_hi=str_hi,
        max_list_items=list_limit,
        max_obj_keys=obj_limit,
    )
    if best is not None:
        return best
    return _apply_clamp(
        payload=payload,
        list_key=list_key,
        limit_text=limit_text,
        max_str_chars=0,
        max_list_items=list_limit,
        max_obj_keys=obj_limit,
    )


def limit_payload_to_fit(
    *,
    payload: Mapping[str, JSONValue],
    max_chars: int,
    size: Callable[[Mapping[str, JSONValue]], int],
    limit_text: Callable[[str, int], str],
) -> dict[str, JSONValue]:
    """Return a structurally clamped payload that fits within the size budget."""
    if max_chars <= 0:
        return dict(payload)
    if size({}) > max_chars:
        return {}

    list_key = _paged_list_key(payload)
    if list_key is not None:
        fitted = _fit_paged_list_prefix(
            payload=payload,
            list_key=list_key,
            max_chars=max_chars,
            size=size,
        )
        if fitted is not None:
            return fitted

    return _fit_generic_payload(
        payload=payload,
        max_chars=max_chars,
        size=size,
        limit_text=limit_text,
    )


__all__ = ("limit_payload_to_fit",)
