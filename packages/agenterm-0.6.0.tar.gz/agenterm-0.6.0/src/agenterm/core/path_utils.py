"""Path normalization helpers shared across storage and workflow layers."""

from __future__ import annotations

from pathlib import Path


def parse_db_path(raw: str | Path | None) -> Path | None:
    """Return a filesystem Path for a SQLite db path or None when invalid."""
    if isinstance(raw, Path):
        path = raw
    elif isinstance(raw, str):
        if not raw or raw == ":memory:":
            return None
        path = Path(raw)
    else:
        return None
    if str(path) == ":memory:":
        return None
    return path


__all__ = ("parse_db_path",)
