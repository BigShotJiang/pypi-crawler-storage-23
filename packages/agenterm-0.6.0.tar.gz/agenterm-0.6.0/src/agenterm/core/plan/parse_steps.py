"""Step-shape parsers shared by plan payload parsing."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING

from agenterm.core.json_codec import is_json_value
from agenterm.core.plan.types import PlanStep, PlanStepSpec
from agenterm.core.plan.utils import (
    has_only_allowed_keys,
    is_plan_status,
    normalize_step_id,
)

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


def parse_plan_steps(value: JSONValue | None) -> tuple[PlanStep, ...] | None:
    """Parse a JSON value into a tuple of persisted PlanStep entries."""
    if not isinstance(value, list):
        return None
    steps: list[PlanStep] = []
    for item in value:
        step = _parse_persisted_step(item)
        if step is None:
            return None
        steps.append(step)
    return tuple(steps)


def parse_plan_step_specs(value: JSONValue | None) -> tuple[PlanStepSpec, ...] | None:
    """Parse a JSON value into a tuple of PlanStepSpec entries."""
    if not isinstance(value, list):
        return None
    steps: list[PlanStepSpec] = []
    for item in value:
        step = _parse_step_spec(item)
        if step is None:
            return None
        steps.append(step)
    return tuple(steps)


def coerce_plan_json_mapping(item: JSONValue) -> dict[str, JSONValue] | None:
    """Return a JSON object mapping with string keys, or None."""
    if not isinstance(item, Mapping):
        return None
    typed_item: dict[str, JSONValue] = {}
    for key, val in item.items():
        if not is_json_value(value=val):
            return None
        typed_item[str(key)] = val
    return typed_item


def _parse_step_spec(item: JSONValue) -> PlanStepSpec | None:
    typed_item = coerce_plan_json_mapping(item)
    if typed_item is None or not has_only_allowed_keys(
        typed_item,
        allowed={"step_id", "step", "status"},
    ):
        return None
    step_val = typed_item.get("step")
    status_val = typed_item.get("status")
    step_id_val = typed_item.get("step_id")
    if not isinstance(step_val, str) or not isinstance(status_val, str):
        return None
    if not step_val.strip():
        return None
    if not is_plan_status(status_val):
        return None
    step_id = normalize_step_id(step_id_val)
    if step_id is None and step_id_val is not None:
        return None
    return PlanStepSpec(step_id=step_id, step=step_val, status=status_val)


def _parse_persisted_step(item: JSONValue) -> PlanStep | None:
    typed_item = coerce_plan_json_mapping(item)
    if typed_item is None or not has_only_allowed_keys(
        typed_item,
        allowed={"step_id", "step", "status"},
    ):
        return None
    step_val = typed_item.get("step")
    status_val = typed_item.get("status")
    step_id_val = typed_item.get("step_id")
    if (
        not isinstance(step_val, str)
        or not isinstance(status_val, str)
        or not isinstance(step_id_val, str)
    ):
        return None
    if not step_val.strip():
        return None
    if not is_plan_status(status_val):
        return None
    if not step_id_val.strip():
        return None
    return PlanStep(step_id=step_id_val, step=step_val, status=status_val)


__all__ = (
    "coerce_plan_json_mapping",
    "parse_plan_step_specs",
    "parse_plan_steps",
)
