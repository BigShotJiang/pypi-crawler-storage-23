"""Plan series derivation and timestamp normalization."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING

from agenterm.core.plan.types import PlanSeries, PlanSnapshot

if TYPE_CHECKING:
    from collections.abc import Sequence


def normalize_plan_timestamp(value: str | None) -> str | None:
    """Normalize timestamps to RFC3339 (UTC)."""
    if value is None:
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        try:
            parsed = datetime.strptime(f"{value} +0000", "%Y-%m-%d %H:%M:%S %z")
        except ValueError:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    else:
        parsed = parsed.astimezone(UTC)
    return parsed.isoformat()


def derive_plan_series(snapshots: Sequence[PlanSnapshot]) -> PlanSeries:
    """Compute the current plan series from snapshots."""
    if not snapshots:
        return PlanSeries(
            plan_state="missing",
            steps=(),
            explanation=None,
            revision=None,
            plan_created_at=None,
            plan_updated_at=None,
        )
    ordered = sorted(snapshots, key=lambda item: item.revision, reverse=True)
    latest = ordered[0]
    updated_at = normalize_plan_timestamp(latest.created_at)
    if not latest.steps:
        return PlanSeries(
            plan_state="active",
            steps=(),
            explanation=latest.explanation,
            revision=latest.revision,
            plan_created_at=updated_at,
            plan_updated_at=updated_at,
        )
    created_at = updated_at
    for snapshot in ordered[1:]:
        if not snapshot.steps:
            break
        candidate = normalize_plan_timestamp(snapshot.created_at)
        if candidate is not None:
            created_at = candidate
    return PlanSeries(
        plan_state="active",
        steps=latest.steps,
        explanation=latest.explanation,
        revision=latest.revision,
        plan_created_at=created_at,
        plan_updated_at=updated_at,
    )


__all__ = ("derive_plan_series", "normalize_plan_timestamp")
