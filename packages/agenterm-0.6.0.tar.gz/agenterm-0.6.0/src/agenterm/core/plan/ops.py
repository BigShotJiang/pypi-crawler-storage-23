"""Mutation operations for plan snapshots."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.plan.types import (
    PlanInputError,
    PlanMutation,
    PlanOp,
    PlanOpAdd,
    PlanOpAdvance,
    PlanOpDelete,
    PlanOpGet,
    PlanOpReset,
    PlanOpSet,
    PlanOpUpdate,
    PlanPatchStatus,
    PlanPatchStep,
    PlanPlacement,
    PlanPlacementAppend,
    PlanPlacementBefore,
    PlanPlacementPrepend,
    PlanSnapshot,
    PlanStep,
    PlanStepSpec,
)
from agenterm.core.plan.utils import (
    count_in_progress,
    next_step_index,
    reserve_next_step_id,
    step_id_suffix,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agenterm.core.json_types import JSONValue


def apply_plan_op(
    current: PlanSnapshot | None,
    op: PlanOp,
) -> tuple[PlanMutation | None, PlanInputError | None]:
    """Apply a plan operation to the current snapshot."""
    steps = current.steps if current is not None else ()
    explanation = current.explanation if current is not None else None
    if isinstance(op, PlanOpGet):
        return None, None

    mutation: PlanMutation | None
    error: PlanInputError | None

    if isinstance(op, PlanOpReset):
        if op.mode == "empty":
            mutation = PlanMutation(steps=(), explanation=None)
        else:
            mutation = None
        error = None
    elif isinstance(op, PlanOpSet):
        mutation, error = _apply_set(op)
    elif isinstance(op, PlanOpAdd):
        mutation, error = _apply_add_op(steps, explanation, op)
    elif isinstance(op, PlanOpUpdate):
        mutation, error = _apply_update_op(current, steps, explanation, op)
    elif isinstance(op, PlanOpAdvance):
        mutation, error = _apply_advance_op(current, steps, explanation, op)
    else:
        mutation, error = _apply_delete_op(current, steps, explanation, op)
    return mutation, error


def _apply_set(op: PlanOpSet) -> tuple[PlanMutation | None, PlanInputError | None]:
    steps_with_ids, error = _assign_step_ids(op.steps)
    if error is not None:
        return None, error
    if count_in_progress(steps_with_ids) > 1:
        return None, _multiple_in_progress_error(steps_with_ids)
    return (
        PlanMutation(steps=steps_with_ids, explanation=op.explanation),
        None,
    )


def _apply_add_op(
    steps: Sequence[PlanStep],
    explanation: str | None,
    op: PlanOpAdd,
) -> tuple[PlanMutation | None, PlanInputError | None]:
    new_steps, error = _apply_add(steps, op)
    if error is not None:
        return None, error
    return PlanMutation(steps=new_steps, explanation=explanation), None


def _apply_update_op(
    current: PlanSnapshot | None,
    steps: Sequence[PlanStep],
    explanation: str | None,
    op: PlanOpUpdate,
) -> tuple[PlanMutation | None, PlanInputError | None]:
    if current is None:
        return None, PlanInputError(field="step_id", reason="missing_plan")
    new_steps, error = _apply_update(steps, op)
    if error is not None:
        return None, error
    return PlanMutation(steps=new_steps, explanation=explanation), None


def _apply_delete_op(
    current: PlanSnapshot | None,
    steps: Sequence[PlanStep],
    explanation: str | None,
    op: PlanOpDelete,
) -> tuple[PlanMutation | None, PlanInputError | None]:
    if current is None:
        return None, PlanInputError(field="step_id", reason="missing_plan")
    new_steps, error = _apply_delete(steps, op)
    if error is not None:
        return None, error
    return PlanMutation(steps=new_steps, explanation=explanation), None


def _apply_advance_op(
    current: PlanSnapshot | None,
    steps: Sequence[PlanStep],
    explanation: str | None,
    op: PlanOpAdvance,
) -> tuple[PlanMutation | None, PlanInputError | None]:
    if current is None:
        return None, PlanInputError(field="next_step_id", reason="missing_plan")
    indexes, error = _resolve_advance_indexes(steps, op)
    if error is not None or indexes is None:
        return None, error
    completed_index, next_index = indexes
    updated = list(steps)
    completed_step = updated[completed_index]
    next_step = updated[next_index]
    updated[completed_index] = PlanStep(
        step_id=completed_step.step_id,
        step=completed_step.step,
        status="completed",
    )
    updated[next_index] = PlanStep(
        step_id=next_step.step_id,
        step=next_step.step,
        status="in_progress",
    )
    if count_in_progress(updated) > 1:
        return None, PlanInputError(field="steps", reason="multiple_in_progress")
    return PlanMutation(steps=tuple(updated), explanation=explanation), None


def _resolve_advance_indexes(
    steps: Sequence[PlanStep],
    op: PlanOpAdvance,
) -> tuple[tuple[int, int] | None, PlanInputError | None]:
    completed_id = op.completed_step_id
    if completed_id is None:
        active = [step for step in steps if step.status == "in_progress"]
        if len(active) != 1:
            active_ids: list[JSONValue] = []
            active_ids.extend(step.step_id for step in active)
            return None, PlanInputError(
                field="completed_step_id",
                reason="requires_single_in_progress",
                details={
                    "in_progress_step_ids": active_ids,
                    "in_progress_count": len(active),
                },
            )
        completed_id = active[0].step_id
    completed_index = _find_step_index(steps, completed_id)
    if completed_index is None:
        return None, _unknown_step_id_error(
            field="completed_step_id",
            steps=steps,
        )
    next_index = _find_step_index(steps, op.next_step_id)
    if next_index is None:
        return None, _unknown_step_id_error(field="next_step_id", steps=steps)
    if completed_index == next_index:
        return None, PlanInputError(
            field="next_step_id",
            reason="must_differ_from_completed",
        )
    next_status = steps[next_index].status
    if next_status != "pending":
        return None, PlanInputError(field="next_step_id", reason="must_be_pending")
    return (completed_index, next_index), None


def _apply_add(
    steps: Sequence[PlanStep],
    op: PlanOpAdd,
) -> tuple[tuple[PlanStep, ...], PlanInputError | None]:
    existing = {step.step_id for step in steps}
    step_id = op.step_id
    if step_id is not None:
        if step_id in existing:
            existing_ids: list[JSONValue] = []
            existing_ids.extend(sorted(existing))
            return (
                tuple(steps),
                PlanInputError(
                    field="step_id",
                    reason="duplicate_step_id",
                    details={"existing_step_ids": existing_ids},
                ),
            )
        if not step_id.strip():
            return (
                tuple(steps),
                PlanInputError(field="step_id", reason="invalid_value"),
            )
    else:
        step_id = reserve_next_step_id(existing, start=next_step_index(existing))
    index, error = _resolve_insert_index(steps, placement=op.placement)
    if error is not None:
        return tuple(steps), error
    new_step = PlanStep(step_id=step_id, step=op.step, status=op.status)
    updated = list(steps)
    updated.insert(index, new_step)
    if count_in_progress(updated) > 1:
        return (
            tuple(steps),
            _multiple_in_progress_error(updated),
        )
    return tuple(updated), None


def _apply_update(
    steps: Sequence[PlanStep],
    op: PlanOpUpdate,
) -> tuple[tuple[PlanStep, ...], PlanInputError | None]:
    index = _find_step_index(steps, op.step_id)
    if index is None:
        return (
            tuple(steps),
            _unknown_step_id_error(field="step_id", steps=steps),
        )
    current = steps[index]
    step_text = current.step
    step_status = current.status
    if isinstance(op.patch, PlanPatchStep):
        step_text = op.patch.step
    elif isinstance(op.patch, PlanPatchStatus):
        step_status = op.patch.status
    else:
        step_text = op.patch.step
        step_status = op.patch.status
    updated_step = PlanStep(
        step_id=current.step_id,
        step=step_text,
        status=step_status,
    )
    updated = list(steps)
    updated[index] = updated_step
    if count_in_progress(updated) > 1:
        return (
            tuple(steps),
            _multiple_in_progress_error(updated),
        )
    return tuple(updated), None


def _apply_delete(
    steps: Sequence[PlanStep],
    op: PlanOpDelete,
) -> tuple[tuple[PlanStep, ...], PlanInputError | None]:
    index = _find_step_index(steps, op.step_id)
    if index is None:
        return (
            tuple(steps),
            _unknown_step_id_error(field="step_id", steps=steps),
        )
    updated = list(steps)
    updated.pop(index)
    return tuple(updated), None


def _assign_step_ids(
    steps: Sequence[PlanStepSpec],
) -> tuple[tuple[PlanStep, ...], PlanInputError | None]:
    existing: set[str] = set()
    max_index = 0
    for step in steps:
        if step.step_id is None:
            continue
        if step.step_id in existing:
            return (), PlanInputError(field="step_id", reason="duplicate_step_id")
        if not step.step_id.strip():
            return (), PlanInputError(field="step_id", reason="invalid_value")
        existing.add(step.step_id)
        max_index = max(max_index, step_id_suffix(step.step_id))
    next_index = max_index + 1
    resolved: list[PlanStep] = []
    for step in steps:
        step_id = step.step_id
        if step_id is None:
            step_id = reserve_next_step_id(existing, start=next_index)
            next_index = step_id_suffix(step_id) + 1
        else:
            existing.add(step_id)
        resolved.append(PlanStep(step_id=step_id, step=step.step, status=step.status))
    return tuple(resolved), None


def _resolve_insert_index(
    steps: Sequence[PlanStep],
    *,
    placement: PlanPlacement,
) -> tuple[int, PlanInputError | None]:
    index = 0
    error: PlanInputError | None = None
    if isinstance(placement, PlanPlacementAppend):
        index = len(steps)
    elif isinstance(placement, PlanPlacementPrepend):
        index = 0
    elif isinstance(placement, PlanPlacementBefore):
        resolved = _find_step_index(steps, placement.anchor_step_id)
        if resolved is None:
            error = _unknown_step_id_error(
                field="placement.anchor_step_id",
                steps=steps,
            )
        else:
            index = resolved
    else:
        resolved = _find_step_index(steps, placement.anchor_step_id)
        if resolved is None:
            error = _unknown_step_id_error(
                field="placement.anchor_step_id",
                steps=steps,
            )
        else:
            index = resolved + 1
    return index, error


def _multiple_in_progress_error(steps: Sequence[PlanStep]) -> PlanInputError:
    ids: list[JSONValue] = []
    indexes: list[JSONValue] = []
    for index, step in enumerate(steps):
        if step.status != "in_progress":
            continue
        ids.append(step.step_id)
        indexes.append(index)
    details: dict[str, JSONValue] = {
        "in_progress_step_ids": ids,
        "in_progress_step_indexes": indexes,
        "index_base": 0,
    }
    return PlanInputError(
        field="steps",
        reason="multiple_in_progress",
        details=details,
    )


def _unknown_step_id_error(
    *,
    field: str,
    steps: Sequence[PlanStep],
) -> PlanInputError:
    known_ids: list[JSONValue] = []
    known_ids.extend(step.step_id for step in steps)
    details: dict[str, JSONValue] = {"known_step_ids": known_ids}
    return PlanInputError(field=field, reason="unknown_step_id", details=details)


def _find_step_index(steps: Sequence[PlanStep], step_id: str) -> int | None:
    for idx, step in enumerate(steps):
        if step.step_id == step_id:
            return idx
    return None


__all__ = ("apply_plan_op",)
