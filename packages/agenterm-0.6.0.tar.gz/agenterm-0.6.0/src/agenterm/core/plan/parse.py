"""Parsing helpers for plan tool payloads."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.plan.parse_steps import (
    coerce_plan_json_mapping,
    parse_plan_step_specs,
    parse_plan_steps,
)
from agenterm.core.plan.types import (
    PlanInputError,
    PlanOp,
    PlanOpAdd,
    PlanOpAdvance,
    PlanOpDelete,
    PlanOpGet,
    PlanOpReset,
    PlanOpSet,
    PlanOpUpdate,
    PlanPatch,
    PlanPatchBoth,
    PlanPatchStatus,
    PlanPatchStep,
    PlanPlacement,
    PlanPlacementAfter,
    PlanPlacementAppend,
    PlanPlacementBefore,
    PlanPlacementPrepend,
    PlanResetMode,
    PlanStepSpec,
    PlanStepStatus,
)
from agenterm.core.plan.utils import (
    count_in_progress,
    has_only_allowed_keys,
    is_plan_status,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agenterm.core.json_types import JSONValue

_VALID_OPS: set[str] = {"get", "set", "add", "update", "delete", "advance", "reset"}
_PLACEMENT_MODES: set[str] = {"append", "prepend", "before", "after"}
_PATCH_KINDS: set[str] = {"step", "status", "both"}


def parse_plan_request(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanOp | None, PlanInputError | None]:
    """Parse a strict plan payload into a concrete PlanOp."""
    op_name, error = _parse_op_name(payload.get("op"))
    if error is not None or op_name is None:
        return None, error
    handler = _OP_PARSERS.get(op_name)
    if handler is None:
        return None, PlanInputError(field="op", reason="invalid_op")
    return handler(payload)


def _parse_op_name(
    value: JSONValue | None,
) -> tuple[str | None, PlanInputError | None]:
    if value is None:
        return None, PlanInputError(field="op", reason="missing")
    if not isinstance(value, str):
        return None, PlanInputError(field="op", reason="invalid_type")
    if value not in _VALID_OPS:
        return None, PlanInputError(field="op", reason="invalid_op")
    return value, None


def _parse_get(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanOp | None, PlanInputError | None]:
    if not has_only_allowed_keys(payload, allowed={"op"}):
        return None, PlanInputError(field="payload", reason="unknown_keys")
    return PlanOpGet(), None


def _parse_set(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanOp | None, PlanInputError | None]:
    if not has_only_allowed_keys(payload, allowed={"op", "steps", "explanation"}):
        return None, PlanInputError(field="payload", reason="unknown_keys")
    steps, err = _parse_steps_for_set(payload)
    if err is not None or steps is None:
        return None, err
    explanation, err = _parse_required_nullable_text(payload, key="explanation")
    if err is not None:
        return None, err
    if count_in_progress(steps) > 1:
        return None, PlanInputError(
            field="steps",
            reason="multiple_in_progress",
            details=_in_progress_conflict_details(steps),
        )
    return PlanOpSet(steps=steps, explanation=explanation), None


def _in_progress_conflict_details(
    steps: Sequence[PlanStepSpec],
) -> dict[str, JSONValue]:
    step_ids: list[JSONValue] = []
    indexes: list[JSONValue] = []
    for index, step in enumerate(steps):
        if step.status != "in_progress":
            continue
        step_ids.append(step.step_id)
        indexes.append(index)
    return {
        "in_progress_step_ids": step_ids,
        "in_progress_step_indexes": indexes,
        "index_base": 0,
    }


def _parse_add(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanOp | None, PlanInputError | None]:
    if not has_only_allowed_keys(
        payload,
        allowed={"op", "step_id", "step", "status", "placement"},
    ):
        return None, PlanInputError(field="payload", reason="unknown_keys")
    step_id, error = _parse_required_nullable_step_id(payload)
    if error is not None:
        return None, error
    step, error = _parse_required_str(payload, key="step")
    if error is not None or step is None:
        return None, error
    status, error = _parse_required_status(payload)
    if error is not None or status is None:
        return None, error
    placement, error = _parse_required_placement(payload)
    if error is not None or placement is None:
        return None, error
    return PlanOpAdd(
        step_id=step_id, step=step, status=status, placement=placement
    ), None


def _parse_update(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanOp | None, PlanInputError | None]:
    if not has_only_allowed_keys(payload, allowed={"op", "step_id", "patch"}):
        return None, PlanInputError(field="payload", reason="unknown_keys")
    step_id, error = _parse_required_str(payload, key="step_id")
    if error is not None or step_id is None:
        return None, error
    patch, error = _parse_required_patch(payload)
    if error is not None or patch is None:
        return None, error
    return PlanOpUpdate(step_id=step_id, patch=patch), None


def _parse_delete(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanOp | None, PlanInputError | None]:
    if not has_only_allowed_keys(payload, allowed={"op", "step_id"}):
        return None, PlanInputError(field="payload", reason="unknown_keys")
    step_id, err = _parse_required_str(payload, key="step_id")
    if err is not None:
        return None, err
    if step_id is None:
        return None, PlanInputError(field="step_id", reason="missing")
    return PlanOpDelete(step_id=step_id), None


def _parse_advance(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanOp | None, PlanInputError | None]:
    if not has_only_allowed_keys(
        payload,
        allowed={"op", "completed_step_id", "next_step_id"},
    ):
        return None, PlanInputError(field="payload", reason="unknown_keys")
    completed_step_id, error = _parse_nullable_str(payload, key="completed_step_id")
    if error is not None:
        return None, PlanInputError(
            field="completed_step_id",
            reason=error.reason,
        )
    next_step_id, error = _parse_required_str(payload, key="next_step_id")
    if error is not None or next_step_id is None:
        return None, error
    if completed_step_id is not None and completed_step_id == next_step_id:
        return None, PlanInputError(
            field="next_step_id",
            reason="must_differ_from_completed",
        )
    return PlanOpAdvance(
        completed_step_id=completed_step_id,
        next_step_id=next_step_id,
    ), None


def _parse_reset(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanOp | None, PlanInputError | None]:
    if not has_only_allowed_keys(payload, allowed={"op", "mode"}):
        return None, PlanInputError(field="payload", reason="unknown_keys")
    mode, error = _parse_required_str(payload, key="mode")
    if error is not None or mode is None:
        return None, error
    reset_mode: PlanResetMode
    if mode == "delete":
        reset_mode = "delete"
    elif mode == "empty":
        reset_mode = "empty"
    else:
        return None, PlanInputError(field="mode", reason="invalid_value")
    return PlanOpReset(mode=reset_mode), None


def _parse_steps_for_set(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[PlanStepSpec, ...] | None, PlanInputError | None]:
    if "steps" not in payload:
        return None, PlanInputError(field="steps", reason="missing")
    raw = payload.get("steps")
    if raw is None:
        return None, PlanInputError(field="steps", reason="missing")
    steps = parse_plan_step_specs(raw)
    if steps is None:
        return None, PlanInputError(field="steps", reason="invalid_steps")
    if not steps:
        return None, PlanInputError(field="steps", reason="empty_steps")
    return steps, None


def _parse_required_nullable_text(
    payload: Mapping[str, JSONValue],
    *,
    key: str,
) -> tuple[str | None, PlanInputError | None]:
    if key not in payload:
        return None, PlanInputError(field=key, reason="missing")
    value = payload.get(key)
    if value is None:
        return None, None
    if not isinstance(value, str):
        return None, PlanInputError(field=key, reason="invalid_type")
    return value, None


def _parse_nullable_str(
    payload: Mapping[str, JSONValue],
    *,
    key: str,
) -> tuple[str | None, PlanInputError | None]:
    if key not in payload:
        return None, None
    value = payload.get(key)
    if value is None:
        return None, None
    if not isinstance(value, str):
        return None, PlanInputError(field=key, reason="invalid_type")
    if not value.strip():
        return None, PlanInputError(field=key, reason="invalid_value")
    return value, None


def _parse_required_str(
    payload: Mapping[str, JSONValue],
    *,
    key: str,
) -> tuple[str | None, PlanInputError | None]:
    value, error = _parse_nullable_str(payload, key=key)
    if error is not None:
        return None, error
    if value is None:
        return None, PlanInputError(field=key, reason="missing")
    return value, None


def _parse_status(
    value: JSONValue | None,
) -> tuple[PlanStepStatus | None, PlanInputError | None]:
    if value is None:
        return None, None
    if not isinstance(value, str):
        return None, PlanInputError(field="status", reason="invalid_type")
    if not is_plan_status(value):
        return None, PlanInputError(field="status", reason="invalid_status")
    return value, None


def _parse_required_status(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanStepStatus | None, PlanInputError | None]:
    if "status" not in payload:
        return None, PlanInputError(field="status", reason="missing")
    status, error = _parse_status(payload.get("status"))
    if error is not None:
        return None, error
    if status is None:
        return None, PlanInputError(field="status", reason="missing")
    return status, None


def _parse_required_nullable_step_id(
    payload: Mapping[str, JSONValue],
) -> tuple[str | None, PlanInputError | None]:
    if "step_id" not in payload:
        return None, PlanInputError(field="step_id", reason="missing")
    value = payload.get("step_id")
    if value is None:
        return None, None
    if not isinstance(value, str):
        return None, PlanInputError(field="step_id", reason="invalid_type")
    if not value.strip():
        return None, PlanInputError(field="step_id", reason="invalid_value")
    return value, None


def _parse_required_json_mapping(
    payload: Mapping[str, JSONValue],
    *,
    key: str,
) -> tuple[dict[str, JSONValue] | None, PlanInputError | None]:
    if key not in payload:
        return None, PlanInputError(field=key, reason="missing")
    typed = coerce_plan_json_mapping(payload.get(key))
    if typed is None:
        return None, PlanInputError(field=key, reason="invalid_type")
    return typed, None


def _parse_required_placement(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanPlacement | None, PlanInputError | None]:
    typed, error = _parse_required_json_mapping(payload, key="placement")
    if error is not None or typed is None:
        return None, error
    if not has_only_allowed_keys(typed, allowed={"mode", "anchor_step_id"}):
        return None, PlanInputError(field="placement", reason="unknown_keys")
    mode, error = _parse_placement_mode(typed)
    if error is not None or mode is None:
        return None, error
    anchor, error = _parse_nullable_str(typed, key="anchor_step_id")
    if error is not None:
        return None, PlanInputError(
            field=f"placement.{error.field}", reason=error.reason
        )
    return _build_placement(mode=mode, anchor=anchor)


def _build_placement(
    *,
    mode: str,
    anchor: str | None,
) -> tuple[PlanPlacement | None, PlanInputError | None]:
    if mode in {"append", "prepend"}:
        if anchor is not None:
            return None, PlanInputError(
                field="placement.anchor_step_id",
                reason="must_be_null",
                details={"mode": mode, "must_be_null": ["anchor_step_id"]},
            )
        return (
            PlanPlacementAppend() if mode == "append" else PlanPlacementPrepend()
        ), None
    if anchor is None:
        return None, PlanInputError(
            field="placement.anchor_step_id",
            reason="required_non_null",
            details={"mode": mode, "required_non_null": ["anchor_step_id"]},
        )
    if mode == "before":
        return PlanPlacementBefore(anchor_step_id=anchor), None
    return PlanPlacementAfter(anchor_step_id=anchor), None


def _parse_required_patch(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanPatch | None, PlanInputError | None]:
    typed, error = _parse_required_json_mapping(payload, key="patch")
    if error is not None or typed is None:
        return None, error
    if not has_only_allowed_keys(typed, allowed={"kind", "step", "status"}):
        return None, PlanInputError(field="patch", reason="unknown_keys")
    kind = typed.get("kind")
    if kind is None:
        return None, PlanInputError(field="patch.kind", reason="missing")
    if not isinstance(kind, str):
        return None, PlanInputError(field="patch.kind", reason="invalid_type")
    if kind not in _PATCH_KINDS:
        return None, PlanInputError(field="patch.kind", reason="invalid_value")
    parser = {"step": _parse_patch_step, "status": _parse_patch_status}.get(
        kind, _parse_patch_both
    )
    return parser(typed)


def _parse_placement_mode(
    payload: Mapping[str, JSONValue],
) -> tuple[str | None, PlanInputError | None]:
    value = payload.get("mode")
    if value is None:
        return None, PlanInputError(field="placement.mode", reason="missing")
    if not isinstance(value, str):
        return None, PlanInputError(field="placement.mode", reason="invalid_type")
    if value not in _PLACEMENT_MODES:
        return None, PlanInputError(field="placement.mode", reason="invalid_value")
    return value, None


def _parse_patch_step(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanPatchStep | None, PlanInputError | None]:
    if not has_only_allowed_keys(payload, allowed={"kind", "step", "status"}):
        return None, PlanInputError(field="patch", reason="unknown_keys")
    step, error = _parse_required_str(payload, key="step")
    if error is not None or step is None:
        if error is not None:
            return None, PlanInputError(
                field=f"patch.{error.field}",
                reason=error.reason,
            )
        return None, PlanInputError(field="patch.step", reason="missing")
    status, error = _parse_status(payload.get("status"))
    if error is not None:
        return None, PlanInputError(field="patch.status", reason=error.reason)
    if status is not None:
        return None, PlanInputError(
            field="patch.status",
            reason="must_be_null",
            details={"must_be_null": ["status"]},
        )
    return PlanPatchStep(step=step), None


def _parse_patch_status(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanPatchStatus | None, PlanInputError | None]:
    if not has_only_allowed_keys(payload, allowed={"kind", "step", "status"}):
        return None, PlanInputError(field="patch", reason="unknown_keys")
    step, error = _parse_nullable_str(payload, key="step")
    if error is not None:
        return None, PlanInputError(field="patch.step", reason=error.reason)
    if step is not None:
        return None, PlanInputError(
            field="patch.step",
            reason="must_be_null",
            details={"must_be_null": ["step"]},
        )
    status, error = _parse_required_patch_status(payload)
    if error is not None or status is None:
        return None, error
    return PlanPatchStatus(status=status), None


def _parse_patch_both(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanPatchBoth | None, PlanInputError | None]:
    if not has_only_allowed_keys(payload, allowed={"kind", "step", "status"}):
        return None, PlanInputError(field="patch", reason="unknown_keys")
    step, error = _parse_required_str(payload, key="step")
    if error is not None or step is None:
        if error is not None:
            return None, PlanInputError(
                field=f"patch.{error.field}",
                reason=error.reason,
            )
        return None, PlanInputError(field="patch.step", reason="missing")
    status, error = _parse_required_patch_status(payload)
    if error is not None or status is None:
        return None, error
    return PlanPatchBoth(step=step, status=status), None


def _parse_required_patch_status(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanStepStatus | None, PlanInputError | None]:
    if "status" not in payload:
        return None, PlanInputError(field="patch.status", reason="missing")
    status, error = _parse_status(payload.get("status"))
    if error is not None:
        return None, PlanInputError(field="patch.status", reason=error.reason)
    if status is None:
        return None, PlanInputError(field="patch.status", reason="missing")
    return status, None


_OP_PARSERS = {
    "get": _parse_get,
    "set": _parse_set,
    "add": _parse_add,
    "update": _parse_update,
    "delete": _parse_delete,
    "advance": _parse_advance,
    "reset": _parse_reset,
}


__all__ = ("parse_plan_request", "parse_plan_steps")
