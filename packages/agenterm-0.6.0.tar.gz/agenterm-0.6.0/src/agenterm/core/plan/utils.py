"""Shared helpers for plan parsing and mutation."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeGuard

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan.types import PlanStep, PlanStepSpec, PlanStepStatus

_STEP_ID_PREFIX = "step-"


def has_only_allowed_keys(
    payload: Mapping[str, JSONValue],
    *,
    allowed: set[str],
) -> bool:
    """Return True if payload keys are within the allowed set."""
    return not any(str(key) not in allowed for key in payload)


def is_plan_status(value: str) -> TypeGuard[PlanStepStatus]:
    """Return True when value is a valid plan status."""
    return value in {"pending", "in_progress", "completed"}


def count_in_progress(steps: Sequence[PlanStep | PlanStepSpec]) -> int:
    """Count in-progress entries in a plan step list."""
    return sum(1 for step in steps if step.status == "in_progress")


def normalize_step_id(value: JSONValue | None) -> str | None:
    """Normalize a nullable step_id value."""
    if value is None:
        return None
    if not isinstance(value, str):
        return None
    if not value.strip():
        return None
    return value


def step_id_suffix(step_id: str) -> int:
    """Parse the numeric suffix from step-<n> IDs."""
    if not step_id.startswith(_STEP_ID_PREFIX):
        return 0
    suffix = step_id[len(_STEP_ID_PREFIX) :]
    return int(suffix) if suffix.isdigit() else 0


def next_step_index(existing: set[str]) -> int:
    """Return the next numeric step index from existing step ids."""
    max_index = 0
    for step_id in existing:
        max_index = max(max_index, step_id_suffix(step_id))
    return max_index + 1


def reserve_next_step_id(existing: set[str], *, start: int) -> str:
    """Return a new step id not present in the existing set."""
    index = start
    while True:
        candidate = f"{_STEP_ID_PREFIX}{index}"
        if candidate not in existing:
            existing.add(candidate)
            return candidate
        index += 1


__all__ = (
    "count_in_progress",
    "has_only_allowed_keys",
    "is_plan_status",
    "next_step_index",
    "normalize_step_id",
    "reserve_next_step_id",
    "step_id_suffix",
)
