"""Typed plan models used by plan tooling."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue

PlanStepStatus = Literal["pending", "in_progress", "completed"]
PlanState = Literal["missing", "active"]
PlanResetMode = Literal["delete", "empty"]
PlanOpName = Literal["get", "set", "add", "update", "delete", "advance", "reset"]
PlanPlacementMode = Literal["append", "prepend", "before", "after"]
PlanPatchKind = Literal["step", "status", "both"]


@dataclass(frozen=True)
class PlanStep:
    """One plan step rendered in the transcript and tool payloads."""

    step_id: str
    step: str
    status: PlanStepStatus


@dataclass(frozen=True)
class PlanStepSpec:
    """Plan step spec from a plan set payload (step_id may be null)."""

    step_id: str | None
    step: str
    status: PlanStepStatus


@dataclass(frozen=True)
class PlanOpGet:
    """Read the current plan state."""

    op: Literal["get"] = "get"


@dataclass(frozen=True)
class PlanOpSet:
    """Replace the plan with a full steps list."""

    steps: tuple[PlanStepSpec, ...]
    explanation: str | None
    op: Literal["set"] = "set"


@dataclass(frozen=True)
class PlanPlacementAppend:
    """Append a new step to the end of the plan."""

    mode: Literal["append"] = "append"


@dataclass(frozen=True)
class PlanPlacementPrepend:
    """Prepend a new step to the start of the plan."""

    mode: Literal["prepend"] = "prepend"


@dataclass(frozen=True)
class PlanPlacementBefore:
    """Insert a new step before an anchor step."""

    anchor_step_id: str
    mode: Literal["before"] = "before"


@dataclass(frozen=True)
class PlanPlacementAfter:
    """Insert a new step after an anchor step."""

    anchor_step_id: str
    mode: Literal["after"] = "after"


PlanPlacement = (
    PlanPlacementAppend
    | PlanPlacementPrepend
    | PlanPlacementBefore
    | PlanPlacementAfter
)


@dataclass(frozen=True)
class PlanOpAdd:
    """Add a new step, optionally positioned before/after another step."""

    step_id: str | None
    step: str
    status: PlanStepStatus
    placement: PlanPlacement
    op: Literal["add"] = "add"


@dataclass(frozen=True)
class PlanPatchStep:
    """Update the step text only."""

    step: str
    kind: Literal["step"] = "step"


@dataclass(frozen=True)
class PlanPatchStatus:
    """Update the step status only."""

    status: PlanStepStatus
    kind: Literal["status"] = "status"


@dataclass(frozen=True)
class PlanPatchBoth:
    """Update both step text and status."""

    step: str
    status: PlanStepStatus
    kind: Literal["both"] = "both"


PlanPatch = PlanPatchStep | PlanPatchStatus | PlanPatchBoth


@dataclass(frozen=True)
class PlanOpUpdate:
    """Update an existing step."""

    step_id: str
    patch: PlanPatch
    op: Literal["update"] = "update"


@dataclass(frozen=True)
class PlanOpDelete:
    """Delete a step by step_id."""

    step_id: str
    op: Literal["delete"] = "delete"


@dataclass(frozen=True)
class PlanOpAdvance:
    """Atomically complete one step and start another step."""

    completed_step_id: str | None
    next_step_id: str
    op: Literal["advance"] = "advance"


@dataclass(frozen=True)
class PlanOpReset:
    """Reset plan state to missing (delete) or active-empty."""

    mode: PlanResetMode
    op: Literal["reset"] = "reset"


PlanOp = (
    PlanOpGet
    | PlanOpSet
    | PlanOpAdd
    | PlanOpUpdate
    | PlanOpDelete
    | PlanOpAdvance
    | PlanOpReset
)


@dataclass(frozen=True)
class PlanSnapshot:
    """Persisted plan snapshot stored in SQLite."""

    session_id: str
    branch_id: str
    revision: int
    steps: tuple[PlanStep, ...]
    explanation: str | None
    trace_id: str | None
    tool_call_id: str | None
    created_at: str | None


@dataclass(frozen=True)
class PlanSeries:
    """Resolved plan state for tool payloads."""

    plan_state: PlanState
    steps: tuple[PlanStep, ...]
    explanation: str | None
    revision: int | None
    plan_created_at: str | None
    plan_updated_at: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "plan_state": self.plan_state,
            "steps": plan_steps_payload(self.steps),
            "explanation": self.explanation,
            "revision": self.revision,
            "plan_created_at": self.plan_created_at,
            "plan_updated_at": self.plan_updated_at,
        }


@dataclass(frozen=True)
class PlanInputError:
    """Structured parse or validation error for plan tool input."""

    field: str
    reason: str
    details: dict[str, JSONValue] | None = None


@dataclass(frozen=True)
class PlanMutation:
    """Mutation result for plan operations."""

    steps: tuple[PlanStep, ...]
    explanation: str | None


@dataclass(frozen=True)
class ToolRuntimeContext:
    """Tool execution context shared across built-in tools."""

    db_path: Path
    session_id: str | None
    branch_id: str | None
    run_number: int | None
    trace_id: str | None
    plan_cache: dict[str, PlanSnapshot]
    cancel_token: CancelToken | None


def plan_error_details(error: PlanInputError) -> dict[str, JSONValue]:
    """Return JSON-ready error details for a plan error."""
    details: dict[str, JSONValue] = {
        "field": error.field,
        "reason": error.reason,
    }
    if error.details is not None:
        details.update(error.details)
    if "hint" not in details:
        hint = _error_hint(reason=error.reason)
        if hint is not None:
            details["hint"] = hint
    return details


def _error_hint(*, reason: str) -> str | None:
    if reason == "unknown_step_id":
        return "Call op=get first to list valid step_id values."
    if reason == "multiple_in_progress":
        return "Keep at most one in_progress step at a time."
    if reason == "requires_single_in_progress":
        return (
            "Set completed_step_id explicitly or ensure exactly one step is "
            "in_progress."
        )
    if reason == "missing_plan":
        return "Initialize a plan first with op=set or op=add."
    if reason == "must_be_pending":
        return "next_step_id must refer to a pending step."
    return None


def plan_steps_payload(steps: Sequence[PlanStep]) -> list[JSONValue]:
    """Return a JSON-safe list of plan step objects."""
    return [
        {"step_id": step.step_id, "step": step.step, "status": step.status}
        for step in steps
    ]


__all__ = (
    "PlanInputError",
    "PlanMutation",
    "PlanOp",
    "PlanOpAdd",
    "PlanOpAdvance",
    "PlanOpDelete",
    "PlanOpGet",
    "PlanOpReset",
    "PlanOpSet",
    "PlanOpUpdate",
    "PlanPatch",
    "PlanPatchBoth",
    "PlanPatchStatus",
    "PlanPatchStep",
    "PlanPlacement",
    "PlanPlacementAfter",
    "PlanPlacementAppend",
    "PlanPlacementBefore",
    "PlanPlacementPrepend",
    "PlanResetMode",
    "PlanSeries",
    "PlanSnapshot",
    "PlanState",
    "PlanStep",
    "PlanStepSpec",
    "PlanStepStatus",
    "ToolRuntimeContext",
    "plan_error_details",
    "plan_steps_payload",
)
