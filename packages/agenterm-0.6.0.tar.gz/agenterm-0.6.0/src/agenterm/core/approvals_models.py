"""Approval detail/item models shared across approvals modules."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class ShellApprovalDetail:
    """Normalized detail for a pending shell approval request."""

    commands: tuple[str, ...]
    cwd: str
    description: str | None = None


@dataclass(frozen=True)
class ShellApprovalItem:
    """Description of a pending shell approval request."""

    id: str
    commands: tuple[str, ...]
    cwd: str
    description: str | None = None


@dataclass(frozen=True)
class PatchApprovalDetail:
    """Normalized detail for a pending apply_patch approval request."""

    operation_type: str
    path: str
    diff: str | None
    description: str | None = None


@dataclass(frozen=True)
class PatchApprovalItem:
    """Description of a pending apply_patch operation."""

    id: str
    operation_type: str
    path: str
    diff: str | None
    description: str | None = None


@dataclass(frozen=True)
class McpApprovalDetail:
    """Normalized detail for a pending hosted MCP approval request."""

    server_label: str
    tool_name: str
    arguments_json: str


@dataclass(frozen=True)
class McpApprovalItem:
    """Description of a pending hosted MCP approval request."""

    id: str
    server_label: str
    tool_name: str
    arguments_json: str


type CompressionApprovalAction = Literal["compress", "drop"]


@dataclass(frozen=True)
class CompressionApprovalDetail:
    """Normalized detail for a pending compression approval request."""

    action: CompressionApprovalAction
    message: str


@dataclass(frozen=True)
class CompressionApprovalItem:
    """Description of a pending compression approval request."""

    id: str
    action: CompressionApprovalAction
    message: str


__all__ = (
    "CompressionApprovalAction",
    "CompressionApprovalDetail",
    "CompressionApprovalItem",
    "McpApprovalDetail",
    "McpApprovalItem",
    "PatchApprovalDetail",
    "PatchApprovalItem",
    "ShellApprovalDetail",
    "ShellApprovalItem",
)
