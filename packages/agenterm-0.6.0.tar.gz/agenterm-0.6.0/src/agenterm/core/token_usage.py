"""Token usage helpers for Responses/Agents runs.

This module intentionally limits itself to provider-returned usage categories.
It does not attempt local tokenization or per-item heuristics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agents.usage import Usage


@dataclass(frozen=True)
class TokenUsage:
    """Flattened token usage summary for a single request or an aggregated run."""

    requests: int
    input_tokens: int
    input_cached_tokens: int
    output_tokens: int
    output_reasoning_tokens: int
    total_tokens: int

    @staticmethod
    def from_agents_usage(usage: Usage) -> TokenUsage:
        """Convert Agents Usage into a stable TokenUsage."""
        cached = usage.input_tokens_details.cached_tokens
        reasoning = usage.output_tokens_details.reasoning_tokens
        return TokenUsage(
            requests=int(usage.requests),
            input_tokens=int(usage.input_tokens),
            input_cached_tokens=int(cached),
            output_tokens=int(usage.output_tokens),
            output_reasoning_tokens=int(reasoning),
            total_tokens=int(usage.total_tokens),
        )

    def to_mapping(self) -> dict[str, int]:
        """Return a JSON-friendly mapping of usage fields."""
        return {
            "requests": self.requests,
            "input_tokens": self.input_tokens,
            "input_cached_tokens": self.input_cached_tokens,
            "output_tokens": self.output_tokens,
            "output_reasoning_tokens": self.output_reasoning_tokens,
            "total_tokens": self.total_tokens,
        }

    def format_compact(self) -> str:
        """Return a compact, single-line usage summary."""
        cached = self.input_cached_tokens
        reasoning = self.output_reasoning_tokens
        return (
            f"req={self.requests} "
            f"in={self.input_tokens} (c={cached}) "
            f"out={self.output_tokens} (r={reasoning}) "
            f"tot={self.total_tokens}"
        )


__all__ = ("TokenUsage",)
