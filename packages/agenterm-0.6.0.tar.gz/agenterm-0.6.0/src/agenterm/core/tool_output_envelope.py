"""Canonical owned-tool output envelope.

All agenterm-owned tools emit a single compact JSON envelope string.

This module intentionally defines one envelope type for:
- local FunctionTools
- agenterm-wrapped MCP tools (normalized into the same envelope)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from agenterm.core.json_codec import (
    as_json_object,
    dumps_compact,
    parse_json_object,
    require_json_object,
)
from agenterm.core.sanitize_paths import sanitize_json_paths, sanitize_path_text

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


def _default_reason_for_kind(kind: str) -> str:
    return {
        "approval_rejected": "rejected",
        "already_exists": "already_exists",
        "command_failed": "command_failed",
        "command_timeout": "command_timeout",
        "not_found": "not_found",
        "invalid_input": "invalid_input",
        "invalid_patch": "invalid_patch",
        "budget_infeasible": "budget_infeasible",
        "tool_error": "tool_error",
    }.get(kind, "unknown_error")


def _normalize_error_details(
    *,
    kind: str,
    details: Mapping[str, JSONValue],
) -> dict[str, JSONValue]:
    normalized = {
        str(key): sanitize_json_paths(value) for key, value in details.items()
    }
    reason_raw = normalized.get("reason")
    reason = reason_raw if isinstance(reason_raw, str) and reason_raw.strip() else None
    if reason is None:
        normalized["reason"] = _default_reason_for_kind(kind)
    return normalized


@dataclass(frozen=True)
class ToolOutputError:
    """Typed error payload for tool output envelopes."""

    kind: str
    message: str
    details: dict[str, JSONValue] = field(default_factory=dict)

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this error."""
        details_json = require_json_object(
            value=self.details,
            context="tool_output.error.details",
        )
        normalized_details = _normalize_error_details(
            kind=self.kind,
            details=details_json,
        )
        return {
            "kind": self.kind,
            "message": sanitize_path_text(self.message),
            "details": normalized_details,
        }


@dataclass(frozen=True)
class ToolOutputEnvelope:
    """Owned-tool output envelope.

    Semantics:
    - ok=true  -> result is present and error is None
    - ok=false -> error is present; result may include partial output context
    """

    tool: str
    ok: bool
    truncated: bool = False
    limit_reason: str | None = None
    result: dict[str, JSONValue] = field(default_factory=dict)
    error: ToolOutputError | None = None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this envelope."""
        result_json = require_json_object(
            value=self.result,
            context=f"tool_output.result.{self.tool}",
        )
        out: dict[str, JSONValue] = {
            "tool": self.tool,
            "ok": self.ok,
            "truncated": self.truncated,
            "limit_reason": self.limit_reason,
            "result": result_json,
        }
        if not self.ok and self.error is not None:
            out["error"] = self.error.to_json()
        return out

    def to_json_string(self) -> str:
        """Return the compact JSON string for this envelope."""
        return dumps_compact(
            self.to_json(),
            ensure_ascii=True,
            context=f"tool_output.envelope.{self.tool}",
        )


def _parse_error(raw: JSONValue | None) -> ToolOutputError | None:
    if not isinstance(raw, dict):
        return None
    kind = raw.get("kind")
    message = raw.get("message")
    details_raw = raw.get("details")
    if not isinstance(kind, str) or not isinstance(message, str):
        return None
    details = as_json_object(details_raw)
    if details is None:
        if details_raw is not None:
            return None
        details = {}
    return ToolOutputError(kind=kind, message=message, details=details)


def _parse_result_map(result_raw: JSONValue | None) -> dict[str, JSONValue] | None:
    result = as_json_object(result_raw)
    if result is None:
        return None
    return result


def _parse_limit_reason(value: JSONValue | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return None


def parse_tool_output_envelope(payload: str) -> ToolOutputEnvelope | None:
    """Parse an owned-tool output envelope from a JSON string."""
    parsed = parse_json_object(payload)
    if parsed is None:
        return None

    required_keys = {"tool", "ok", "truncated", "limit_reason", "result"}
    allowed_keys = required_keys | {"error"}
    parsed_keys = {str(key) for key in parsed}
    if (not required_keys.issubset(parsed_keys)) or (parsed_keys - allowed_keys):
        return None

    tool = parsed.get("tool")
    ok = parsed.get("ok")
    truncated_raw = parsed.get("truncated")
    if (
        not isinstance(tool, str)
        or not tool
        or not isinstance(ok, bool)
        or not isinstance(truncated_raw, bool)
    ):
        return None

    limit_reason = _parse_limit_reason(parsed.get("limit_reason"))
    if (truncated_raw and not limit_reason) or (
        (not truncated_raw) and limit_reason is not None
    ):
        return None

    result_map: dict[str, JSONValue] | None = None
    if "result" in parsed:
        result_map = _parse_result_map(parsed.get("result"))
    if result_map is None:
        return None

    error = _parse_error(parsed.get("error"))
    env: ToolOutputEnvelope | None = None
    if ok and error is None:
        env = ToolOutputEnvelope(
            tool=tool,
            ok=True,
            truncated=truncated_raw,
            limit_reason=limit_reason,
            result=result_map,
            error=None,
        )
    elif (not ok) and error is not None:
        env = ToolOutputEnvelope(
            tool=tool,
            ok=False,
            truncated=truncated_raw,
            limit_reason=limit_reason,
            result=result_map,
            error=error,
        )
    return env


__all__ = (
    "ToolOutputEnvelope",
    "ToolOutputError",
    "parse_tool_output_envelope",
)
