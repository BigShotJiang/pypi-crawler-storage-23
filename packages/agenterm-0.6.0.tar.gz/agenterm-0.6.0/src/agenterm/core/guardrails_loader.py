"""Config-driven guardrails loading (built-ins + user modules).

This module is the single place where agenterm performs side-effectful guardrail
imports. Guardrail registration itself lives in `core.guardrails_registry`.

Design goals:
- Fail fast: surface import/registration problems as `ConfigError` at config load.
- Deterministic: one import per module string per process.
- Safe-by-default messaging: never echo suspected secret material.
"""

from __future__ import annotations

import importlib
import sys
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.guardrails_registry import (
    resolve_input_guardrails,
    resolve_output_guardrails,
)

if TYPE_CHECKING:
    from agenterm.config.model import GuardrailsConfig

_BUILTIN_MODULE = "agenterm.guardrails.no_secrets_input"
_LOADED_MODULES: set[str] = set()


def load_builtin_guardrails() -> None:
    """Import agenterm-shipped guardrails exactly once per process."""
    if _BUILTIN_MODULE in sys.modules:
        return
    importlib.import_module(_BUILTIN_MODULE)


def _normalize_module_key(raw: str) -> str | None:
    key = (raw or "").strip()
    if not key:
        return None
    if any(ch.isspace() for ch in key):
        msg = f"guardrails.load_modules entry must not contain whitespace: {raw!r}"
        raise ConfigError(msg)
    return key


def load_guardrail_modules(modules: list[str]) -> None:
    """Import user guardrail modules, once each, in list order."""
    for raw in modules:
        key = _normalize_module_key(raw)
        if key is None:
            continue
        if key in _LOADED_MODULES:
            continue
        try:
            importlib.import_module(key)
        except ImportError as exc:
            msg = f"Failed to import guardrails module {key!r}: {exc}"
            raise ConfigError(msg) from exc
        except SyntaxError as exc:
            msg = f"Guardrails module {key!r} has a syntax error: {exc}"
            raise ConfigError(msg) from exc
        _LOADED_MODULES.add(key)


def prime_guardrails(cfg: GuardrailsConfig) -> None:
    """Load and validate guardrails referenced by GuardrailsConfig.

    This function is idempotent and safe to call from multiple edges.
    """
    if not (cfg.load_modules or cfg.input or cfg.output):
        return

    load_builtin_guardrails()
    if cfg.load_modules:
        load_guardrail_modules(cfg.load_modules)

    # Validate configured names after all registrations have had a chance to run.
    if cfg.input:
        resolve_input_guardrails(cfg.input)
    if cfg.output:
        resolve_output_guardrails(cfg.output)


__all__ = ("load_builtin_guardrails", "load_guardrail_modules", "prime_guardrails")
