"""Optional model-parameter shaping and fallback adaptation."""

from __future__ import annotations

import re
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from agenterm.constants.include import LOGPROBS_RESPONSE_INCLUDE
from agenterm.core.error_conversion import (
    provider_error_param_from_exception as _provider_error_param_from_exception,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from agents.model_settings import ModelSettings

    from agenterm.core.json_types import JSONValue

_INCLUDE_PARAM = "include"
_PROMPT_CACHE_RETENTION_PARAM = "prompt_cache_retention"
_TOP_LOGPROBS_PARAM = "top_logprobs"
_VERBOSITY_PARAM = "verbosity"
_REASONING_PARAM = "reasoning"
_STORE_PARAM = "store"
_METADATA_PARAM = "metadata"
_UNSUPPORTED_INCLUDE_FRAGMENT = "encrypted content is not supported"
_PROMPT_CACHE_FRAGMENT = "prompt_cache_retention"
_PROMPT_CACHE_TEXT_FRAGMENT = "prompt cache"
_TOP_LOGPROBS_FRAGMENT = "top_logprobs"
_VERBOSITY_FRAGMENT = "verbosity"
_REASONING_FRAGMENT = "reasoning"
_STORE_FRAGMENT = "store"
_METADATA_FRAGMENT = "metadata"
_PARAM_RE = re.compile(r"param=([^\s,)]+)")

_OPTIONAL_PARAM_KEYS: tuple[str, ...] = (
    _PROMPT_CACHE_RETENTION_PARAM,
    _TOP_LOGPROBS_PARAM,
    _VERBOSITY_PARAM,
    _REASONING_PARAM,
    _STORE_PARAM,
    _METADATA_PARAM,
    _INCLUDE_PARAM,
)
_UNSUPPORTED_OPTIONAL_CACHE: set[tuple[str, str]] = set()


@dataclass(frozen=True)
class OptionalSupportMatrix:
    """Protocol-level support matrix for optional settings."""

    supports_prompt_cache_retention: bool
    supports_top_logprobs: bool
    supports_verbosity: bool
    supports_reasoning: bool
    supports_store: bool
    supports_metadata: bool
    supports_response_include: bool
    default_response_include: tuple[str, ...] | None


@dataclass(frozen=True)
class OptionalSettingsResolution:
    """Result of optional-settings shaping before provider calls."""

    model_settings: ModelSettings
    warnings: tuple[str, ...]


@dataclass(frozen=True)
class OptionalModelSettingsFallback:
    """Result of adapting optional model settings after a provider error."""

    model_settings: ModelSettings
    warnings: tuple[str, ...]


def _drop_include_surface(
    model_settings: ModelSettings,
) -> OptionalModelSettingsFallback | None:
    warnings: list[str] = []
    updated = model_settings
    changed = False
    include = updated.response_include
    if include is not None and len(include) > 0:
        updated = replace(updated, response_include=[])
        warnings.append("Dropped model.response_include (unsupported by model).")
        changed = True
    if updated.top_logprobs is not None:
        updated = replace(updated, top_logprobs=None)
        warnings.append("Dropped model.top_logprobs (unsupported by model).")
        changed = True
    if not changed:
        return None
    return OptionalModelSettingsFallback(
        model_settings=updated,
        warnings=tuple(warnings),
    )


def _drop_prompt_cache_retention(
    model_settings: ModelSettings,
) -> OptionalModelSettingsFallback | None:
    if model_settings.prompt_cache_retention is None:
        return None
    updated = replace(model_settings, prompt_cache_retention=None)
    return OptionalModelSettingsFallback(
        model_settings=updated,
        warnings=("Dropped model.prompt_cache_retention (unsupported by model).",),
    )


def _drop_top_logprobs(
    model_settings: ModelSettings,
) -> OptionalModelSettingsFallback | None:
    if model_settings.top_logprobs is None:
        return None
    updated = replace(model_settings, top_logprobs=None)
    return OptionalModelSettingsFallback(
        model_settings=updated,
        warnings=("Dropped model.top_logprobs (unsupported by model).",),
    )


def _drop_verbosity(
    model_settings: ModelSettings,
) -> OptionalModelSettingsFallback | None:
    if model_settings.verbosity is None:
        return None
    updated = replace(model_settings, verbosity=None)
    return OptionalModelSettingsFallback(
        model_settings=updated,
        warnings=("Dropped model.verbosity (unsupported by model).",),
    )


def _drop_reasoning(
    model_settings: ModelSettings,
) -> OptionalModelSettingsFallback | None:
    if model_settings.reasoning is None:
        return None
    updated = replace(model_settings, reasoning=None)
    return OptionalModelSettingsFallback(
        model_settings=updated,
        warnings=("Dropped model.reasoning (unsupported by model).",),
    )


def _drop_store(
    model_settings: ModelSettings,
) -> OptionalModelSettingsFallback | None:
    if model_settings.store is None:
        return None
    updated = replace(model_settings, store=None)
    return OptionalModelSettingsFallback(
        model_settings=updated,
        warnings=("Dropped model.store (unsupported by model).",),
    )


def _drop_metadata(
    model_settings: ModelSettings,
) -> OptionalModelSettingsFallback | None:
    if model_settings.metadata is None:
        return None
    updated = replace(model_settings, metadata=None)
    return OptionalModelSettingsFallback(
        model_settings=updated,
        warnings=("Dropped model.metadata (unsupported by model).",),
    )


def provider_error_param(message: str) -> str | None:
    """Extract provider-reported field names from formatted error messages."""
    match = _PARAM_RE.search(message)
    if match is None:
        return None
    value = match.group(1).strip()
    return value or None


def provider_error_param_from_exception(exc: Exception) -> str | None:
    """Extract provider-reported param from canonical provider error conversion."""
    return _provider_error_param_from_exception(exc)


def _param_matches(param: str | None, expected: str) -> bool:
    if not isinstance(param, str):
        return False
    normalized = param.strip().strip("`'\"")
    if not normalized:
        return False
    if normalized == expected:
        return True
    if normalized.startswith((f"{expected}.", f"{expected}[")):
        return True
    parts = [
        part.strip().strip("`'\"")
        for part in re.split(r"[.\[\]]+", normalized)
        if part.strip().strip("`'\"")
    ]
    return expected in parts


def _mark_optional_param_unsupported(*, model_id: str, param: str) -> None:
    if not model_id or not param:
        return
    _UNSUPPORTED_OPTIONAL_CACHE.add((model_id, param))


def _is_optional_param_marked_unsupported(*, model_id: str, param: str) -> bool:
    if not model_id or not param:
        return False
    return (model_id, param) in _UNSUPPORTED_OPTIONAL_CACHE


def reset_optional_model_settings_cache() -> None:
    """Clear in-process unsupported-parameter cache."""
    _UNSUPPORTED_OPTIONAL_CACHE.clear()


def _apply_drop_by_param(
    *,
    model_settings: ModelSettings,
    param: str,
) -> OptionalModelSettingsFallback | None:
    handler = _DROP_HANDLERS.get(param)
    if handler is None:
        return None
    return handler(model_settings)


def _is_param_supported(matrix: OptionalSupportMatrix, *, param: str) -> bool:
    getter = _SUPPORT_GETTERS.get(param)
    if getter is None:
        return True
    return getter(matrix)


def resolve_optional_model_settings(
    *,
    model_id: str,
    matrix: OptionalSupportMatrix,
    model_settings: ModelSettings,
    include_override: tuple[str, ...] | None = None,
) -> OptionalSettingsResolution:
    """Apply protocol support matrix + cache to optional settings."""
    warnings: list[str] = []
    updated = model_settings
    if matrix.supports_response_include:
        include_raw = (
            list(include_override)
            if include_override is not None
            else list(matrix.default_response_include or ())
        )
        if (
            updated.top_logprobs is not None
            and LOGPROBS_RESPONSE_INCLUDE not in include_raw
        ):
            include_raw.append(LOGPROBS_RESPONSE_INCLUDE)
        updated = replace(updated, response_include=include_raw)
    else:
        include_drop = _drop_include_surface(updated)
        if include_drop is not None:
            warnings.extend(include_drop.warnings)
            updated = include_drop.model_settings
    for param in _OPTIONAL_PARAM_KEYS:
        is_supported = _is_param_supported(matrix, param=param)
        is_marked_unsupported = _is_optional_param_marked_unsupported(
            model_id=model_id, param=param
        )
        if is_supported and not is_marked_unsupported:
            continue
        fallback = _apply_drop_by_param(model_settings=updated, param=param)
        if fallback is None:
            continue
        updated = fallback.model_settings
        warnings.extend(fallback.warnings)
    return OptionalSettingsResolution(
        model_settings=updated,
        warnings=tuple(warnings),
    )


def apply_optional_model_settings_fallback(
    *,
    model_id: str,
    model_settings: ModelSettings,
    param: str | None,
    message: str,
) -> OptionalModelSettingsFallback | None:
    """Return an adapted ModelSettings surface when optional params are rejected."""
    lowered = message.lower()
    param_norm = (param or provider_error_param(message) or "").strip().lower()
    mark_param = _match_optional_param_from_error(
        param_norm=param_norm,
        lowered=lowered,
    )
    if mark_param is None:
        return None
    fallback = _apply_drop_by_param(model_settings=model_settings, param=mark_param)
    if fallback is None:
        return None
    _mark_optional_param_unsupported(model_id=model_id, param=mark_param)
    if mark_param == _INCLUDE_PARAM:
        _mark_optional_param_unsupported(model_id=model_id, param=_TOP_LOGPROBS_PARAM)
    return fallback


def _match_optional_param_from_error(
    *,
    param_norm: str,
    lowered: str,
) -> str | None:
    for key, fragments in _PARAM_MATCH_RULES:
        if _param_matches(param_norm, key):
            return key
        for fragment in fragments:
            if fragment in lowered:
                return key
    return None


def map_agent_run_error(message: str) -> tuple[str, dict[str, JSONValue] | None]:
    """Map provider-facing agent_run errors into stable machine-readable guidance."""
    lowered = message.lower()
    param = provider_error_param(message)
    mapped = message
    details: dict[str, JSONValue] | None = None
    if _param_matches(param, _PROMPT_CACHE_RETENTION_PARAM):
        mapped = (
            "Model does not support prompt_cache_retention. Choose a compatible model "
            "or remove model.prompt_cache_retention for delegated runs."
        )
        details = {
            "reason": "unsupported_optional_parameter",
            "field": _PROMPT_CACHE_RETENTION_PARAM,
        }
    elif _param_matches(param, _TOP_LOGPROBS_PARAM):
        mapped = (
            "Model does not support top_logprobs for delegated runs. Disable "
            "model.top_logprobs or choose a compatible model."
        )
        details = {
            "reason": "unsupported_optional_parameter",
            "field": _TOP_LOGPROBS_PARAM,
        }
    elif _param_matches(param, _VERBOSITY_PARAM):
        mapped = (
            "Model does not support verbosity for delegated runs. Disable "
            "model.verbosity or choose a compatible model."
        )
        details = {
            "reason": "unsupported_optional_parameter",
            "field": _VERBOSITY_PARAM,
        }
    elif _param_matches(param, _REASONING_PARAM):
        mapped = (
            "Model does not support the configured reasoning settings for delegated "
            "runs. Disable model.reasoning or choose a compatible model."
        )
        details = {
            "reason": "unsupported_optional_parameter",
            "field": _REASONING_PARAM,
        }
    elif _param_matches(param, _STORE_PARAM):
        mapped = (
            "Model does not support store for delegated runs. Disable model.store "
            "or choose a compatible model."
        )
        details = {"reason": "unsupported_optional_parameter", "field": _STORE_PARAM}
    elif _param_matches(param, _METADATA_PARAM):
        mapped = (
            "Model does not support metadata for delegated runs. Disable "
            "model.metadata or choose a compatible model."
        )
        details = {"reason": "unsupported_optional_parameter", "field": _METADATA_PARAM}
    elif _param_matches(param, _INCLUDE_PARAM):
        mapped = (
            "Model does not support one or more response include values. Choose a "
            "model that supports the current include set or adjust route/model "
            "settings."
        )
        details = {"reason": "unsupported_include", "field": _INCLUDE_PARAM}
    elif _UNSUPPORTED_INCLUDE_FRAGMENT in lowered:
        mapped = (
            "Model does not support reasoning.encrypted_content. Choose a model that "
            "supports encrypted reasoning or adjust the Responses include set."
        )
        details = {"reason": "unsupported_include", "field": _INCLUDE_PARAM}
    return mapped, details


_DROP_HANDLERS: dict[
    str,
    Callable[[ModelSettings], OptionalModelSettingsFallback | None],
] = {
    _PROMPT_CACHE_RETENTION_PARAM: _drop_prompt_cache_retention,
    _TOP_LOGPROBS_PARAM: _drop_top_logprobs,
    _VERBOSITY_PARAM: _drop_verbosity,
    _REASONING_PARAM: _drop_reasoning,
    _STORE_PARAM: _drop_store,
    _METADATA_PARAM: _drop_metadata,
    _INCLUDE_PARAM: _drop_include_surface,
}

_SUPPORT_GETTERS: dict[str, Callable[[OptionalSupportMatrix], bool]] = {
    _PROMPT_CACHE_RETENTION_PARAM: (
        lambda matrix: matrix.supports_prompt_cache_retention
    ),
    _TOP_LOGPROBS_PARAM: (lambda matrix: matrix.supports_top_logprobs),
    _VERBOSITY_PARAM: (lambda matrix: matrix.supports_verbosity),
    _REASONING_PARAM: (lambda matrix: matrix.supports_reasoning),
    _STORE_PARAM: (lambda matrix: matrix.supports_store),
    _METADATA_PARAM: (lambda matrix: matrix.supports_metadata),
    _INCLUDE_PARAM: (lambda matrix: matrix.supports_response_include),
}

_PARAM_MATCH_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    (
        _PROMPT_CACHE_RETENTION_PARAM,
        (_PROMPT_CACHE_FRAGMENT, _PROMPT_CACHE_TEXT_FRAGMENT),
    ),
    (_TOP_LOGPROBS_PARAM, (_TOP_LOGPROBS_FRAGMENT,)),
    (_VERBOSITY_PARAM, (_VERBOSITY_FRAGMENT,)),
    (_REASONING_PARAM, (_REASONING_FRAGMENT,)),
    (_STORE_PARAM, (_STORE_FRAGMENT,)),
    (_METADATA_PARAM, (_METADATA_FRAGMENT,)),
    (_INCLUDE_PARAM, (_UNSUPPORTED_INCLUDE_FRAGMENT,)),
)


__all__ = (
    "OptionalModelSettingsFallback",
    "OptionalSettingsResolution",
    "OptionalSupportMatrix",
    "apply_optional_model_settings_fallback",
    "map_agent_run_error",
    "provider_error_param",
    "provider_error_param_from_exception",
    "reset_optional_model_settings_cache",
    "resolve_optional_model_settings",
)
