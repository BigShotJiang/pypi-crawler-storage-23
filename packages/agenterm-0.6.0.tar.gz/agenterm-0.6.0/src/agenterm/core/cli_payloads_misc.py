"""Misc payloads for CLI JSON envelopes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.cli_payloads_artifacts import ArtifactSummaryPayload
    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class InspectResponsePayload:
    """Payload for `agenterm inspect response` in JSON mode."""

    response_id: str
    model: str | None
    status: str | None
    background: bool | None
    usage: Mapping[str, int] | None
    text: str
    input_items: tuple[Mapping[str, JSONValue], ...] | None = None
    input_items_has_more: bool | None = None
    input_items_next_after: str | None = None
    input_items_order: str | None = None
    input_items_limit: int | None = None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "response_id": self.response_id,
            "model": self.model,
            "status": self.status,
            "background": self.background,
            "usage": dict(self.usage) if self.usage is not None else None,
            "text": self.text,
            "input_items": (
                [dict(item) for item in self.input_items]
                if self.input_items is not None
                else None
            ),
            "input_items_has_more": self.input_items_has_more,
            "input_items_next_after": self.input_items_next_after,
            "input_items_order": self.input_items_order,
            "input_items_limit": self.input_items_limit,
        }


@dataclass(frozen=True)
class InspectRunPayload:
    """Payload for `agenterm inspect run` in JSON mode."""

    session_id: str
    branch_id: str
    run_number: int
    status: str | None
    response_id: str | None
    trace_id: str | None
    started_at: str | None
    updated_at: str | None
    usage: Mapping[str, int] | None
    events_count: int
    items: tuple[Mapping[str, JSONValue], ...]
    artifacts: tuple[ArtifactSummaryPayload, ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "run_number": self.run_number,
            "status": self.status,
            "response_id": self.response_id,
            "trace_id": self.trace_id,
            "started_at": self.started_at,
            "updated_at": self.updated_at,
            "usage": dict(self.usage) if self.usage is not None else None,
            "events_count": self.events_count,
            "items": [dict(item) for item in self.items],
            "artifacts": [artifact.to_json() for artifact in self.artifacts],
        }


@dataclass(frozen=True)
class InspectRunEventsPayload:
    """Payload for `agenterm inspect run-events` in JSON mode."""

    session_id: str
    branch_id: str
    run_number: int
    events: tuple[Mapping[str, JSONValue], ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "run_number": self.run_number,
            "events": [dict(event) for event in self.events],
        }


@dataclass(frozen=True)
class InspectRunSpoolPayload:
    """Payload for `agenterm inspect run-spool` in JSON mode."""

    kind: str
    session_id: str
    branch_id: str
    run_number: int
    run_id: str | None
    events: int
    items: int
    spool_path: str

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "kind": self.kind,
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "run_number": self.run_number,
            "run_id": self.run_id,
            "events": self.events,
            "items": self.items,
            "spool_path": self.spool_path,
        }


@dataclass(frozen=True)
class InspectTurnPayload:
    """Payload for `agenterm inspect turn` in JSON mode."""

    session_id: str
    branch_id: str
    turn_number: int
    items: tuple[Mapping[str, JSONValue], ...]
    artifacts: tuple[ArtifactSummaryPayload, ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "turn_number": self.turn_number,
            "items": [dict(item) for item in self.items],
            "artifacts": [artifact.to_json() for artifact in self.artifacts],
        }


@dataclass(frozen=True)
class InspectAgentRunPayload:
    """Payload for `agenterm inspect agent-run` in JSON mode."""

    report_id: str
    report: Mapping[str, JSONValue]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "report_id": self.report_id,
            "report": dict(self.report),
        }


@dataclass(frozen=True)
class TraceShowPayload:
    """Payload for `agenterm trace show` in JSON mode."""

    trace_enabled: bool
    trace_id: str | None
    group_id: str | None
    trace_metadata: Mapping[str, str] | None
    trace_include_sensitive_data: bool

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "trace_enabled": self.trace_enabled,
            "trace_id": self.trace_id,
            "group_id": self.group_id,
            "trace_metadata": (
                dict(self.trace_metadata) if self.trace_metadata is not None else None
            ),
            "trace_include_sensitive_data": self.trace_include_sensitive_data,
        }


__all__ = (
    "InspectAgentRunPayload",
    "InspectResponsePayload",
    "InspectRunEventsPayload",
    "InspectRunPayload",
    "InspectRunSpoolPayload",
    "InspectTurnPayload",
    "TraceShowPayload",
)
