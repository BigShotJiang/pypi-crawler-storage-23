"""Shared output-length clamps for owned-tool output envelopes.

The clamp is a global safety net enforcing `tools.max_chars`.

Policies:
- Prefer structural clamping of `result` for ok envelopes.
- Drop error details first, then trim error messages.
- Fail fast with a typed budget error when the output budget cannot fit even a
  minimally meaningful result.
"""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.core.json_codec import json_size
from agenterm.core.tool_output_envelope import ToolOutputEnvelope, ToolOutputError
from agenterm.core.tool_output_payload_clamp import limit_payload_to_fit

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agenterm.core.json_types import JSONValue

_ELLIPSIS = "..."
_ELLIPSIS_LEN = len(_ELLIPSIS)

_LIMIT_REASON_CHAR_BUDGET = "char_budget"
_LIMIT_REASON_BUDGET_COMPACT = "budget"
_BUDGET_INFEASIBLE_KIND = "budget_infeasible"


def _truncate_text_to_fit[TEnv](
    env: TEnv,
    *,
    max_chars: int,
    text: str,
    apply_text: Callable[[TEnv, str], TEnv],
    length: Callable[[TEnv], int],
) -> str:
    if max_chars <= 0:
        return ""
    low = 0
    high = min(len(text), max_chars)
    best = ""
    while low <= high:
        mid = (low + high) // 2
        candidate = limit_tool_output_text(text, max_chars=mid)
        if length(apply_text(env, candidate)) <= max_chars:
            best = candidate
            low = mid + 1
        else:
            high = mid - 1
    return best


def limit_tool_output_text(text: str, *, max_chars: int) -> str:
    """Return a truncated text tool output within max_chars."""
    if max_chars <= 0:
        return ""
    if len(text) <= max_chars:
        return text
    if max_chars <= _ELLIPSIS_LEN:
        return "." * max_chars
    remaining = max_chars - _ELLIPSIS_LEN
    head = remaining // 2
    tail = remaining - head
    if head <= 0:
        return f"{_ELLIPSIS}{text[-tail:]}" if tail > 0 else _ELLIPSIS
    if tail <= 0:
        return f"{text[:head]}{_ELLIPSIS}"
    return f"{text[:head]}{_ELLIPSIS}{text[-tail:]}"


def _env_size(env: ToolOutputEnvelope) -> int:
    return json_size(env.to_json())


def _with_result(
    env: ToolOutputEnvelope, result: Mapping[str, JSONValue]
) -> ToolOutputEnvelope:
    return replace(env, result=dict(result))


def _with_error_message(env: ToolOutputEnvelope, message: str) -> ToolOutputEnvelope:
    if env.error is None:
        return env
    return replace(env, error=replace(env.error, message=message))


def _minimal_error_details(error: ToolOutputError) -> dict[str, JSONValue]:
    details = dict(error.details)
    reason_raw = details.get("reason")
    reason = reason_raw if isinstance(reason_raw, str) and reason_raw.strip() else None
    if reason is None:
        reason = _LIMIT_REASON_BUDGET_COMPACT
    minimal: dict[str, JSONValue] = {"reason": reason}
    field_raw = details.get("field")
    if isinstance(field_raw, str) and field_raw.strip():
        minimal["field"] = field_raw
    return minimal


def _fit_budget_message(
    env: ToolOutputEnvelope,
    *,
    max_chars: int,
) -> ToolOutputEnvelope:
    if env.error is None or not env.error.message:
        return env
    fitted = _truncate_text_to_fit(
        env,
        max_chars=max_chars,
        text=env.error.message,
        apply_text=_with_error_message,
        length=_env_size,
    )
    trimmed = _with_error_message(env, fitted)
    if _env_size(trimmed) <= max_chars:
        return trimmed
    return _with_error_message(env, "")


def _budget_infeasible_for_tool(*, tool: str, max_chars: int) -> ToolOutputEnvelope:
    message = "Output budget too small to fit a minimally meaningful tool result."
    templates: tuple[tuple[str, str, dict[str, JSONValue], str], ...] = (
        (
            _BUDGET_INFEASIBLE_KIND,
            _LIMIT_REASON_BUDGET_COMPACT,
            {"reason": _LIMIT_REASON_BUDGET_COMPACT, "max_chars": int(max_chars)},
            message,
        ),
        (
            _BUDGET_INFEASIBLE_KIND,
            _LIMIT_REASON_BUDGET_COMPACT,
            {"reason": _LIMIT_REASON_BUDGET_COMPACT},
            message,
        ),
        (
            _BUDGET_INFEASIBLE_KIND,
            _LIMIT_REASON_BUDGET_COMPACT,
            {"reason": _LIMIT_REASON_BUDGET_COMPACT},
            "",
        ),
        (
            "tool_error",
            _LIMIT_REASON_BUDGET_COMPACT,
            {"reason": _LIMIT_REASON_BUDGET_COMPACT},
            "",
        ),
    )
    candidates: list[ToolOutputEnvelope] = []
    for kind, limit_reason, details, err_message in templates:
        env = ToolOutputEnvelope(
            tool=tool,
            ok=False,
            truncated=True,
            limit_reason=limit_reason,
            result={},
            error=ToolOutputError(
                kind=kind,
                message=err_message,
                details=details,
            ),
        )
        candidates.append(env)
        candidates.append(_fit_budget_message(env, max_chars=max_chars))
    for candidate in candidates:
        if _env_size(candidate) <= max_chars:
            return candidate
    return candidates[-1]


def _truncate_ok(env: ToolOutputEnvelope, *, max_chars: int) -> ToolOutputEnvelope:
    baseline = _with_result(env, {})
    if _env_size(baseline) > max_chars:
        return _budget_infeasible_for_tool(tool=env.tool, max_chars=max_chars)

    def _size(candidate_result: Mapping[str, JSONValue]) -> int:
        return _env_size(_with_result(env, candidate_result))

    def _limit_text(text: str, max_len: int) -> str:
        return limit_tool_output_text(text, max_chars=max_len)

    result = limit_payload_to_fit(
        payload=env.result,
        max_chars=max_chars,
        size=_size,
        limit_text=_limit_text,
    )
    if not result and env.result:
        return _budget_infeasible_for_tool(tool=env.tool, max_chars=max_chars)
    limited = _with_result(env, result)
    if _env_size(limited) <= max_chars:
        return limited
    if not baseline.result and env.result:
        return _budget_infeasible_for_tool(tool=env.tool, max_chars=max_chars)
    return baseline


def _truncate_error_result_payload(
    env: ToolOutputEnvelope,
    *,
    max_chars: int,
) -> ToolOutputEnvelope:
    if not env.result:
        return env

    def _size(candidate_result: Mapping[str, JSONValue]) -> int:
        return _env_size(_with_result(env, candidate_result))

    def _limit_text(text: str, max_len: int) -> str:
        return limit_tool_output_text(text, max_chars=max_len)

    limited_result = limit_payload_to_fit(
        payload=env.result,
        max_chars=max_chars,
        size=_size,
        limit_text=_limit_text,
    )
    return _with_result(env, limited_result)


def _truncate_error_details(
    env: ToolOutputEnvelope,
    *,
    max_chars: int,
) -> ToolOutputEnvelope:
    error = env.error
    if error is None or not error.details:
        return env
    minimal = _minimal_error_details(error)
    candidates = (
        replace(env, error=replace(error, details=minimal)),
        replace(env, error=replace(error, details={"reason": minimal["reason"]})),
    )
    for candidate in candidates:
        if _env_size(candidate) <= max_chars:
            return candidate
    return candidates[-1]


def _truncate_error_message(
    env: ToolOutputEnvelope,
    *,
    max_chars: int,
) -> ToolOutputEnvelope:
    error = env.error
    if error is None or not error.message:
        return env
    fitted = _truncate_text_to_fit(
        env,
        max_chars=max_chars,
        text=error.message,
        apply_text=_with_error_message,
        length=_env_size,
    )
    trimmed = _with_error_message(env, fitted)
    if _env_size(trimmed) <= max_chars:
        return trimmed
    return _budget_infeasible_for_tool(tool=env.tool, max_chars=max_chars)


def _truncate_error(env: ToolOutputEnvelope, *, max_chars: int) -> ToolOutputEnvelope:
    error = env.error
    if error is None:
        return env
    current = _truncate_error_result_payload(env, max_chars=max_chars)
    if _env_size(current) > max_chars:
        current = _truncate_error_details(current, max_chars=max_chars)
    if _env_size(current) > max_chars:
        current = _truncate_error_message(current, max_chars=max_chars)
    if _env_size(current) > max_chars:
        return _budget_infeasible_for_tool(tool=current.tool, max_chars=max_chars)
    return current


def limit_tool_output(env: ToolOutputEnvelope, *, max_chars: int) -> ToolOutputEnvelope:
    """Clamp an owned-tool output envelope to max_chars."""
    if max_chars <= 0:
        return env
    if _env_size(env) <= max_chars:
        return env
    truncated_env = replace(env, truncated=True, limit_reason=_LIMIT_REASON_CHAR_BUDGET)
    limited = (
        _truncate_ok(truncated_env, max_chars=max_chars)
        if truncated_env.ok
        else _truncate_error(truncated_env, max_chars=max_chars)
    )
    if _env_size(limited) <= max_chars:
        return limited
    return _budget_infeasible_for_tool(tool=env.tool, max_chars=max_chars)


def budget_infeasible_envelope(*, tool: str, max_chars: int) -> ToolOutputEnvelope:
    """Return a budget_infeasible envelope that fits within max_chars."""
    return _budget_infeasible_for_tool(tool=tool, max_chars=max_chars)


__all__ = (
    "budget_infeasible_envelope",
    "limit_tool_output",
    "limit_tool_output_text",
)
