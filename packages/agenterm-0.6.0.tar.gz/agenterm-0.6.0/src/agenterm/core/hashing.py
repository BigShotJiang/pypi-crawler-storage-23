"""Small hashing helpers for stable fingerprints."""

from __future__ import annotations

import hashlib


def sha256_text(text: str) -> str:
    """Return a hex sha256 digest for a UTF-8 string."""
    h = hashlib.sha256()
    h.update(text.encode("utf-8"))
    return h.hexdigest()


def sha256_text_or_none(text: str | None) -> str | None:
    """Return sha256 hex digest for text, or None when text is None."""
    if text is None:
        return None
    return sha256_text(text)


__all__ = ("sha256_text", "sha256_text_or_none")
