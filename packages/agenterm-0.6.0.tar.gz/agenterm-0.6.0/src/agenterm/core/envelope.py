"""Typed JSON envelopes for CLI and diagnostic edges.

This module defines the single success and error schemas used by JSON-output
surfaces (e.g., `agenterm run --format json ...`, `agenterm mcp status --format json`).

The success envelope is intentionally generic:
- `result.resource` identifies the command/resource.
- `result.payload` is a typed payload dataclass that can be rendered as JSON
  without ad-hoc dict construction.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Final, Protocol

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.cli_payloads import ArtifactSummaryPayload
    from agenterm.core.json_types import JSONValue

from agenterm.core.json_codec import require_json_object


def iso_timestamp() -> str:
    """Return an RFC3339/ISO-8601 timestamp in UTC."""
    return datetime.now(UTC).isoformat()


SCHEMA_VERSION: Final[int] = 1


class JsonPayload(Protocol):
    """Protocol for payloads that can be emitted as JSONValue mappings."""

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSONValue-only mapping for this payload."""
        ...


@dataclass(frozen=True)
class SuccessResult:
    """Typed success result wrapper for a resource payload."""

    resource: str
    payload: JsonPayload

    def to_json(self) -> dict[str, JSONValue]:
        """Convert the result wrapper to a JSON-ready mapping."""
        return {"resource": self.resource, "payload": self.payload.to_json()}


@dataclass(frozen=True)
class SuccessEnvelope:
    """Canonical success envelope for JSON-output edges."""

    trace_id: str | None
    ts: str
    result: SuccessResult
    schema_version: int = SCHEMA_VERSION

    def to_json(self) -> dict[str, JSONValue]:
        """Convert the envelope to a JSON-ready mapping."""
        return {
            "schema_version": self.schema_version,
            "trace_id": self.trace_id,
            "ts": self.ts,
            "result": self.result.to_json(),
        }


@dataclass(frozen=True)
class ErrorEnvelope:
    """Canonical error envelope for JSON-output edges."""

    kind: str
    message: str
    trace_id: str | None
    ts: str
    details: Mapping[str, JSONValue]
    schema_version: int = SCHEMA_VERSION

    def to_json(self) -> dict[str, JSONValue]:
        """Convert the envelope to a JSON-ready mapping."""
        details_json = require_json_object(
            value=self.details,
            context="error_envelope.details",
        )
        return {
            "schema_version": self.schema_version,
            "kind": self.kind,
            "message": self.message,
            "trace_id": self.trace_id,
            "ts": self.ts,
            "details": details_json,
        }


@dataclass(frozen=True)
class RunPayload:
    """Payload for successful `run` invocations in JSON mode."""

    mode: str
    background: bool
    text: str
    attachments: tuple[str, ...]
    artifacts: tuple[ArtifactSummaryPayload, ...]
    tools: Mapping[str, int]
    response_id: str | None
    session_id: str | None
    usage: Mapping[str, int] | None

    def to_json(self) -> dict[str, JSONValue]:
        """Convert the payload to a JSON-ready mapping."""
        return {
            "mode": self.mode,
            "background": self.background,
            "text": self.text,
            "attachments": list(self.attachments),
            "artifacts": [a.to_json() for a in self.artifacts],
            "tools": dict(self.tools),
            "response_id": self.response_id,
            "session_id": self.session_id,
            "usage": dict(self.usage) if self.usage is not None else None,
        }


__all__ = (
    "SCHEMA_VERSION",
    "ErrorEnvelope",
    "JsonPayload",
    "RunPayload",
    "SuccessEnvelope",
    "SuccessResult",
    "iso_timestamp",
)
