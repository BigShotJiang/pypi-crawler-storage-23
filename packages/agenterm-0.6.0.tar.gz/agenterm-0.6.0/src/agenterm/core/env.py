"""Centralized environment and .env handling for agenterm.

This module is the single place that:
- Loads the global `.env` via python-dotenv.
- Checks for the presence of OPENAI_API_KEY.
- Updates the in-process API key used by Agents/OpenAI.
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Final

import agents

from agenterm.config.paths import global_env_path
from agenterm.core.dotenv_loader import ensure_global_dotenv_loaded
from agenterm.core.errors import FilesystemError, ValidationError
from agenterm.core.openai_client import reset_openai_client

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)


def ensure_env_loaded() -> None:
    """Load the global agenterm environment file once per process, if present."""
    ensure_global_dotenv_loaded()


def has_openai_api_key() -> bool:
    """Return True if an OpenAI API key is available from env."""
    ensure_env_loaded()
    return bool(os.environ.get("OPENAI_API_KEY"))


def _normalize_key(value: str) -> str:
    key = value.strip()
    if not key:
        msg = "OPENAI_API_KEY must be non-empty."
        raise ValidationError(msg)
    return key


def _ensure_env_dir(path: Path) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        msg = f"Failed to create env directory {path.parent}: {exc}"
        raise FilesystemError(msg) from exc


def _read_env_text(path: Path) -> str:
    if not path.exists():
        return ""
    try:
        return path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.debug("Failed to read %s: %s", path, exc)
        return ""


def _render_env_with_key(existing: str, key: str) -> str:
    lines_out: list[str] = []
    replaced = False
    for raw in existing.splitlines():
        line = raw.rstrip("\n")
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            lines_out.append(line)
            continue
        if stripped.startswith(("OPENAI_API_KEY=", "export OPENAI_API_KEY=")):
            lines_out.append(f"OPENAI_API_KEY={key}")
            replaced = True
            continue
        lines_out.append(line)

    if not replaced:
        if lines_out and lines_out[-1].strip():
            lines_out.append("")
        lines_out.append(f"OPENAI_API_KEY={key}")

    return "\n".join(lines_out).rstrip("\n") + "\n"


def _write_env_text(path: Path, rendered: str) -> None:
    try:
        path.write_text(rendered, encoding="utf-8")
    except OSError as exc:
        msg = f"Failed to write env file {path}: {exc}"
        raise FilesystemError(msg) from exc


def _chmod_env_file(path: Path) -> None:
    try:
        path.chmod(0o600)
    except OSError as exc:
        logger.debug("Failed to chmod %s to 0600: %s", path, exc)


def save_openai_api_key(value: str) -> Path:
    """Persist OPENAI_API_KEY to ~/.agenterm/.env and return the path.

    The file is chmodded to 0600 (best-effort) to reduce accidental disclosure.
    """
    key = _normalize_key(value)
    path = global_env_path()
    _ensure_env_dir(path)
    existing = _read_env_text(path)
    rendered = _render_env_with_key(existing, key)
    _write_env_text(path, rendered)
    _chmod_env_file(path)
    return path


def set_openai_api_key(value: str) -> None:
    """Set the OpenAI API key for this process/session.

    This updates both Agents' default key and the OPENAI_API_KEY environment
    variable so that downstream SDK calls see a consistent value.
    """
    agents.set_default_openai_key(value)
    os.environ["OPENAI_API_KEY"] = value
    reset_openai_client()


__all__: Final[tuple[str, ...]] = (
    "ensure_env_loaded",
    "has_openai_api_key",
    "save_openai_api_key",
    "set_openai_api_key",
)
