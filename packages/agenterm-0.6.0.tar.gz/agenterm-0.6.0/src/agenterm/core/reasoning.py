"""Reasoning token extraction, filtering, and display utilities.

agenterm stores provider-native reasoning items losslessly, but model APIs are not
shape-compatible across providers. This module owns:

- Extraction for UI/compression (content > summary; never display encrypted tokens)
- Replay filtering to produce maximal *valid* continuation input per protocol

Important policy:

- `summary` is UI-only in agenterm. It is rendered in the REPL transcript but is
  never sent back to any model.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.response_items import normalize_input_item_json, serialize_input_item

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.items import ReasoningItem, TResponseInputItem
    from openai.types.responses.response_reasoning_item import ResponseReasoningItem

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class ReasoningData:
    """Extracted reasoning data from a ResponseReasoningItem.

    Fields:
        summary_text: Concatenated summary parts (always present, may be empty).
        content_text: Full thinking text (when provider supplies it).
        encrypted_content: Opaque replay token (when available).
        has_real_thinking: True if content or encrypted_content exists.
    """

    summary_text: str | None
    content_text: str | None
    encrypted_content: str | None
    has_real_thinking: bool


def extract_reasoning_data(item: ReasoningItem) -> ReasoningData:
    """Extract all reasoning fields from a ReasoningItem."""
    raw = item.raw_item
    summary_text = _extract_summary_text(raw)
    content_text = _extract_content_text(raw)
    encrypted = raw.encrypted_content
    has_real = bool(content_text or encrypted)
    return ReasoningData(
        summary_text=summary_text,
        content_text=content_text,
        encrypted_content=encrypted,
        has_real_thinking=has_real,
    )


def extract_reasoning_for_display(item: ReasoningItem) -> str | None:
    """Extract text suitable for transcript display.

    Priority: content > summary (use full thinking when available).
    Never returns encrypted_content.
    """
    data = extract_reasoning_data(item)
    if data.content_text:
        return data.content_text
    return data.summary_text


def extract_reasoning_for_compressor(item: ReasoningItem) -> str | None:
    """Extract text suitable for steward/compressor input.

    Same as display: content > summary, no encrypted_content.
    """
    return extract_reasoning_for_display(item)


def has_real_thinking(item: ReasoningItem) -> bool:
    """Check if item has content or encrypted_content (not just summary)."""
    raw = item.raw_item
    return bool(_extract_content_text(raw) or raw.encrypted_content)


def filter_reasoning_for_model(
    items: Sequence[TResponseInputItem],
) -> list[TResponseInputItem]:
    """Filter reasoning items for model continuation.

    Policy:
    - `reasoning.summary` is display-only; always strip it (token hygiene).
    - Keep reasoning items only when they include replayable payload:
      `content` (cleartext thinking blocks) and/or `encrypted_content` (opaque
      token/signature).
    - Drop summary-only reasoning items (no replayable payload).
    """
    result: list[TResponseInputItem] = []
    for item in items:
        serialized = serialize_input_item(item, context="reasoning.filter_for_model")
        filtered = _filter_reasoning_dict_for_model(serialized)
        if filtered is None:
            continue
        parsed = normalize_input_item_json(
            filtered,
            context="reasoning.filter_for_model",
        )
        result.append(parsed)
    return result


def filter_reasoning_for_openai(
    items: Sequence[TResponseInputItem],
) -> list[TResponseInputItem]:
    """Filter reasoning items for OpenAI Responses continuation.

    OpenAI rejects reasoning items whose `content` includes `reasoning_text` parts
    when those items are re-sent in `input`. For OpenAI-plane calls, reasoning is
    continued only via `encrypted_content` (requested via
    `reasoning.encrypted_content`).

    Policy:
    - Keep only reasoning items that include a non-empty `encrypted_content`.
    - Strip `summary` (redundant token cost once `encrypted_content` exists).
    - Omit `content` entirely.
    - Drop reasoning items missing `encrypted_content` (non-portable across providers).
    """
    result: list[TResponseInputItem] = []
    for item in items:
        serialized = serialize_input_item(item, context="reasoning.filter_for_openai")
        filtered = _filter_reasoning_dict_for_openai(serialized)
        if filtered is None:
            continue
        parsed = normalize_input_item_json(
            filtered,
            context="reasoning.filter_for_openai",
        )
        result.append(parsed)
    return result


def filter_reasoning_for_steward(
    items: Sequence[TResponseInputItem],
) -> list[TResponseInputItem]:
    """Convert reasoning items to text messages for steward/compressor input.

    The API interprets reasoning item IDs as server references → 404.
    Convert reasoning to assistant messages so steward sees the thinking
    as readable context, not as API item references.
    """
    result: list[TResponseInputItem] = []
    for item in items:
        serialized = serialize_input_item(item, context="reasoning.filter_for_steward")
        converted = _convert_reasoning_to_message(serialized)
        if converted is not None:
            parsed = normalize_input_item_json(
                converted,
                context="reasoning.filter_for_steward",
            )
            result.append(parsed)
    return result


def _convert_reasoning_to_message(
    item: Mapping[str, JSONValue],
) -> dict[str, JSONValue] | None:
    """Convert reasoning item to assistant message, or pass through other items."""
    if item.get("type") != "reasoning":
        return dict(item)
    # Extract text: prefer content over summary
    content_text = _extract_text_from_parts(item.get("content"))
    summary_text = _extract_text_from_parts(item.get("summary"))
    text = content_text or summary_text
    if not text:
        return None  # Empty reasoning, skip
    # Convert to user message (input context for steward to read)
    return {
        "type": "message",
        "role": "user",
        "content": [{"type": "input_text", "text": f"[assistant thinking]\n{text}"}],
    }


def _extract_text_from_parts(parts: JSONValue) -> str | None:
    """Extract concatenated text from a list of {text: ...} parts."""
    if not isinstance(parts, list):
        return None
    texts: list[str] = []
    for part in parts:
        if isinstance(part, dict):
            text = part.get("text")
            if isinstance(text, str) and text:
                texts.append(text)
    joined = "\n".join(texts).strip()
    return joined or None


def _filter_reasoning_dict_for_model(
    item: Mapping[str, JSONValue],
) -> dict[str, JSONValue] | None:
    """Return a model-safe reasoning item dict, or None to drop the item."""
    if item.get("type") != "reasoning":
        return dict(item)
    content_list = item.get("content")
    encrypted = item.get("encrypted_content")
    if not content_list and not encrypted:
        # Summary-only reasoning is display-only and cannot be replayed.
        return None
    # Preserve all provider-native fields (e.g., provider_data) but strip
    # replay-disallowed summary text.
    filtered = dict(item)
    filtered["summary"] = []  # Empty, never replay reasoning summaries.
    return filtered


def _filter_reasoning_dict_for_openai(
    item: Mapping[str, JSONValue],
) -> dict[str, JSONValue] | None:
    """Return an OpenAI-safe reasoning item dict, or None to drop the item."""
    if item.get("type") != "reasoning":
        return dict(item)
    rid = item.get("id")
    if not isinstance(rid, str) or not rid:
        return None
    encrypted = item.get("encrypted_content")
    if not isinstance(encrypted, str) or not encrypted:
        return None
    filtered: dict[str, JSONValue] = {
        "type": "reasoning",
        "id": rid,
        "summary": [],
        "encrypted_content": encrypted,
    }
    status = item.get("status")
    if status is not None:
        filtered["status"] = status
    return filtered


def _extract_summary_text(raw: ResponseReasoningItem) -> str | None:
    """Extract concatenated summary text from raw item."""
    parts = raw.summary
    if not parts:
        return None
    texts = [part.text for part in parts if part.text]
    text = "\n".join(texts).strip()
    return text or None


def _extract_content_text(raw: ResponseReasoningItem) -> str | None:
    """Extract concatenated content text from raw item."""
    content_list = raw.content
    if not content_list:
        return None
    texts = [part.text for part in content_list if part.text]
    text = "\n".join(texts).strip()
    return text or None


__all__ = (
    "ReasoningData",
    "extract_reasoning_data",
    "extract_reasoning_for_compressor",
    "extract_reasoning_for_display",
    "filter_reasoning_for_model",
    "filter_reasoning_for_openai",
    "filter_reasoning_for_steward",
    "has_real_thinking",
)
