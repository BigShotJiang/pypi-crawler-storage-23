"""Core primitives for the greenfield engine.

This package provides typed domain models and explicit error types.
These are the sanctioned public interfaces for engine orchestration.
"""

from agenterm.core.errors import (
    AgentermError,
    AuthError,
    ConfigError,
    DatabaseError,
    DispatchError,
    FilesystemError,
    McpConnectError,
    OperationCancelledError,
    OperationTimeoutError,
    PipelineError,
    RateLimitError,
    ToolExecutionError,
    ValidationError,
)
from agenterm.core.tool_selection import ToolSelection
from agenterm.core.toolspec import ToolSpec
from agenterm.core.types import SessionState

__all__ = (
    "AgentermError",
    "AuthError",
    "ConfigError",
    "DatabaseError",
    "DispatchError",
    "FilesystemError",
    "McpConnectError",
    "OperationCancelledError",
    "OperationTimeoutError",
    "PipelineError",
    "RateLimitError",
    "SessionState",
    "ToolExecutionError",
    "ToolSelection",
    "ToolSpec",
    "ValidationError",
)
