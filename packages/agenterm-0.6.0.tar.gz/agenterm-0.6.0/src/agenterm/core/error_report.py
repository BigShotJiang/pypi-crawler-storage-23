"""Structured error reporting helpers shared by CLI and REPL edges."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import httpx
from agents.exceptions import AgentsException, MaxTurnsExceeded
from openai import (
    APIConnectionError,
    APIError,
    APIStatusError,
    APITimeoutError,
)
from openai import (
    AuthenticationError as OpenAIAuthError,
)
from openai import (
    RateLimitError as OpenAIRateLimitError,
)

from agenterm.core.envelope import ErrorEnvelope, iso_timestamp
from agenterm.core.error_conversion import (
    ProviderErrorData,
    resolve_provider_error_data,
)
from agenterm.core.error_openai import openai_status_message
from agenterm.core.error_text import bounded_exception_message
from agenterm.core.errors import (
    AgentermError,
    AuthError,
    ConfigError,
    DatabaseError,
    FilesystemError,
    McpConnectError,
    OperationTimeoutError,
    PipelineError,
    RateLimitError,
    ToolArgumentsLimitError,
    ToolExecutionError,
    UsageError,
    ValidationError,
)
from agenterm.core.rate_limit_info import RateLimitInfo, rate_limit_info_from_headers

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class ErrorContext:
    """Execution context for an error report."""

    operation: str
    resource: str
    trace_id: str | None
    recovery_hint: str | None = None


@dataclass(frozen=True)
class ErrorReport:
    """Structured error report suitable for JSON envelopes and human rendering."""

    kind: str
    message: str
    context: ErrorContext
    details: dict[str, JSONValue] = field(default_factory=dict)
    rate_limit: RateLimitInfo | None = None

    def to_envelope(self) -> ErrorEnvelope:
        """Convert the report into a canonical error envelope."""
        detail_map: dict[str, JSONValue] = {
            "operation": self.context.operation,
            "resource": self.context.resource,
            "recovery_hint": self.context.recovery_hint,
            "rate_limit": self.rate_limit.to_json() if self.rate_limit else None,
            **self.details,
        }
        return ErrorEnvelope(
            kind=self.kind,
            message=self.message,
            trace_id=self.context.trace_id,
            ts=iso_timestamp(),
            details=detail_map,
        )


def _unwrap_pipeline_cause(exc: Exception) -> Exception:
    if isinstance(exc, PipelineError) and isinstance(exc.__cause__, Exception):
        return exc.__cause__
    return exc


_ERROR_KIND_RULES: tuple[tuple[type[Exception], str], ...] = (
    (ValidationError, "validation_error"),
    (UsageError, "usage_error"),
    (ConfigError, "config_error"),
    (FilesystemError, "filesystem_error"),
    (DatabaseError, "database_error"),
    (AuthError, "auth_error"),
    (RateLimitError, "rate_limit_error"),
    (OperationTimeoutError, "timeout_error"),
    (McpConnectError, "mcp_error"),
    (ToolExecutionError, "tool_error"),
    (AgentsException, "agents_error"),
    (OpenAIRateLimitError, "rate_limit_error"),
    (OpenAIAuthError, "auth_error"),
    (APITimeoutError, "timeout_error"),
    (APIConnectionError, "provider_error"),
    (APIStatusError, "provider_error"),
    (APIError, "provider_error"),
    (httpx.TimeoutException, "timeout_error"),
    (httpx.HTTPError, "provider_error"),
    (AgentermError, "runtime_error"),
)


def _error_kind(exc: Exception) -> str:
    for exc_type, kind in _ERROR_KIND_RULES:
        if isinstance(exc, exc_type):
            return kind
    return "runtime_error"


_ERROR_MESSAGE_PASSTHROUGH: tuple[type[Exception], ...] = (
    ValidationError,
    ConfigError,
    FilesystemError,
    DatabaseError,
    AuthError,
    RateLimitError,
    OperationTimeoutError,
    McpConnectError,
    ToolExecutionError,
    AgentermError,
)

_ERROR_MESSAGE_RULES: tuple[tuple[type[Exception], str], ...] = (
    (OpenAIAuthError, "OpenAI authentication failed."),
    (OpenAIRateLimitError, "OpenAI rate limit exceeded."),
    (httpx.TimeoutException, "Network request timed out."),
)


def _provider_error_message(
    exc: Exception,
    *,
    provider_error: ProviderErrorData,
) -> str | None:
    provider_name = provider_error.provider_name
    detail_message = provider_error.detail_message
    details = provider_error.details
    message: str | None = None
    if isinstance(exc, APIStatusError):
        message = openai_status_message(
            exc,
            provider_name=provider_name,
            detail_message=detail_message,
        )
    elif isinstance(exc, APITimeoutError):
        message = f"{provider_name} request timed out."
    elif isinstance(exc, APIConnectionError):
        message = f"{provider_name} connection error."
    elif isinstance(exc, APIError):
        suffix_bits: list[str] = []
        code = details.get("code")
        if isinstance(code, str):
            suffix_bits.append(f"code={code}")
        param = details.get("param")
        if isinstance(param, str):
            suffix_bits.append(f"param={param}")
        base = f"{provider_name} request failed"
        if suffix_bits:
            base = f"{base} ({', '.join(suffix_bits)})"
        message = f"{base}: {detail_message}" if detail_message else base
    elif isinstance(exc, httpx.HTTPError):
        message = f"Network error communicating with {provider_name}."
    return message


def _unexpected_error_message(exc: Exception) -> str:
    exc_type = type(exc).__name__
    exc_message = bounded_exception_message(exc)
    if exc_message:
        return f"Unexpected error ({exc_type}): {exc_message}"
    return f"Unexpected error ({exc_type})."


def _error_message(
    exc: Exception,
    *,
    provider_error: ProviderErrorData,
) -> str:
    message: str | None = None
    if isinstance(exc, _ERROR_MESSAGE_PASSTHROUGH):
        message = str(exc)
    else:
        message = _provider_error_message(
            exc,
            provider_error=provider_error,
        )
    if message is not None:
        return message
    if isinstance(exc, AgentsException):
        bounded = bounded_exception_message(exc)
        message = (
            f"Agents runtime error: {bounded}" if bounded else "Agents runtime error."
        )
    else:
        for exc_type, fallback in _ERROR_MESSAGE_RULES:
            if isinstance(exc, exc_type):
                message = fallback
                break
    if message is None:
        message = _unexpected_error_message(exc)
    return message


_RECOVERY_HINT_RULES: tuple[tuple[type[Exception], str], ...] = (
    (AuthError, "Check OPENAI_API_KEY or set it via `/config key` in the REPL."),
    (OpenAIAuthError, "Check OPENAI_API_KEY or set it via `/config key` in the REPL."),
    (
        ConfigError,
        "Review config values or re-save config (agenterm config show/save) and retry.",
    ),
    (
        DatabaseError,
        "If the database is locked, close other agenterm processes and retry. "
        "If a run spool exists, replay it with `agenterm inspect run-spool <PATH>`.",
    ),
    (
        ToolArgumentsLimitError,
        "Reduce tool arguments or increase run.tool_args_max_chars "
        "(or set it to null).",
    ),
    (
        ValidationError,
        "Review the referenced field and update config or command arguments.",
    ),
    (
        RateLimitError,
        "Retry after the rate-limit window or reduce request volume.",
    ),
    (
        OpenAIRateLimitError,
        "Retry after the rate-limit window or reduce request volume.",
    ),
    (
        OperationTimeoutError,
        "Retry with smaller inputs or increase run.timeout_seconds (idle) or "
        "run.progress_timeout_seconds (progress), or set them to null.",
    ),
    (
        MaxTurnsExceeded,
        "Increase agent.max_turns or reduce loops/tool churn, then retry.",
    ),
)


def _recovery_hint(exc: Exception) -> str | None:
    for exc_type, hint in _RECOVERY_HINT_RULES:
        if isinstance(exc, exc_type):
            return hint
    return None


def _rate_limit_for_exception(exc: Exception) -> RateLimitInfo | None:
    if isinstance(exc, APIStatusError):
        return rate_limit_info_from_headers(
            exc.response.headers,
            request_id=exc.request_id,
        )
    if isinstance(exc, httpx.HTTPStatusError):
        return rate_limit_info_from_headers(
            exc.response.headers,
            request_id=exc.response.headers.get("x-request-id"),
        )
    return None


def build_error_report(
    exc: Exception,
    *,
    context: ErrorContext,
    extra_details: Mapping[str, JSONValue] | None = None,
) -> ErrorReport:
    """Construct a structured error report from an exception."""
    root = _unwrap_pipeline_cause(exc)
    hint = context.recovery_hint or _recovery_hint(root)
    ctx = ErrorContext(
        operation=context.operation,
        resource=context.resource,
        trace_id=context.trace_id,
        recovery_hint=hint,
    )
    provider_error = resolve_provider_error_data(
        root,
        extra_details=extra_details,
    )
    details = provider_error.details
    rate_limit = _rate_limit_for_exception(root)
    return ErrorReport(
        kind=_error_kind(root),
        message=_error_message(
            root,
            provider_error=provider_error,
        ),
        context=ctx,
        details=details,
        rate_limit=rate_limit,
    )


def build_message_report(
    *,
    kind: str,
    message: str,
    context: ErrorContext,
    recovery_hint: str | None = None,
    extra_details: Mapping[str, JSONValue] | None = None,
) -> ErrorReport:
    """Construct a report from explicit fields (usage/validation errors)."""
    ctx = ErrorContext(
        operation=context.operation,
        resource=context.resource,
        trace_id=context.trace_id,
        recovery_hint=recovery_hint or context.recovery_hint,
    )
    details = dict(extra_details) if extra_details is not None else {}
    return ErrorReport(
        kind=kind,
        message=message,
        context=ctx,
        details=details,
        rate_limit=None,
    )


__all__ = (
    "ErrorContext",
    "ErrorReport",
    "RateLimitInfo",
    "build_error_report",
    "build_message_report",
)
