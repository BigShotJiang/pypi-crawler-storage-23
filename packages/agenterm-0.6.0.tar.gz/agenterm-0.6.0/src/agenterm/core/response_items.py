"""Helpers for validating and serializing Responses input items."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeGuard

from openai.types.responses.response_input_item_param import ResponseInputItemParam
from pydantic import TypeAdapter, ValidationError
from pydantic_core import PydanticSerializationError

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import is_json_object, json_size, parse_json_object

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.items import TResponseInputItem

    from agenterm.core.json_codec import JSONInput
    from agenterm.core.json_types import JSONValue


_INPUT_ITEM_ADAPTER: TypeAdapter[ResponseInputItemParam] = TypeAdapter(
    ResponseInputItemParam
)


def _is_response_input_item_json(
    *,
    value: JSONInput,
) -> TypeGuard[TResponseInputItem]:
    return is_json_object(value=value)


def parse_input_item(
    payload: Mapping[str, JSONValue],
    *,
    context: str,
) -> TResponseInputItem:
    """Validate and return a typed Responses input item."""
    try:
        return _INPUT_ITEM_ADAPTER.validate_python(payload)
    except ValidationError as exc:
        msg = f"{context} is not a valid Responses input item"
        raise ConfigError(msg) from exc


def parse_input_item_json(
    raw: str,
    *,
    context: str,
) -> TResponseInputItem | None:
    """Parse a JSON string into a typed Responses input item."""
    parsed = parse_json_object(raw)
    if parsed is None:
        return None
    return parse_input_item(parsed, context=context)


def normalize_input_item_json(
    payload: Mapping[str, JSONValue],
    *,
    context: str,
) -> TResponseInputItem:
    """Normalize a JSON input item without Pydantic validation."""
    if not _is_response_input_item_json(value=payload):
        msg = f"{context} is not JSON-safe"
        raise ConfigError(msg)
    try:
        jsonable = _INPUT_ITEM_ADAPTER.dump_python(
            payload,
            mode="json",
            warnings="none",
        )
    except (TypeError, ValueError, PydanticSerializationError) as exc:
        msg = f"{context} could not be serialized to JSON"
        raise ConfigError(msg) from exc
    if not _is_response_input_item_json(value=jsonable):
        msg = f"{context} is not JSON-safe"
        raise ConfigError(msg)
    return jsonable


def validate_input_item_json(
    payload: Mapping[str, JSONValue],
    *,
    context: str,
) -> TResponseInputItem:
    """Validate and normalize a JSON input item without parse_input_item."""
    if not _is_response_input_item_json(value=payload):
        msg = f"{context} is not JSON-safe"
        raise ConfigError(msg)
    try:
        jsonable = _INPUT_ITEM_ADAPTER.dump_python(
            payload,
            mode="json",
            warnings="error",
        )
    except (TypeError, ValueError, PydanticSerializationError) as exc:
        msg = f"{context} is not a valid Responses input item"
        raise ConfigError(msg) from exc
    if not _is_response_input_item_json(value=jsonable):
        msg = f"{context} is not JSON-safe"
        raise ConfigError(msg)
    return jsonable


def _dump_input_item_jsonable(
    item: TResponseInputItem,
    *,
    context: str,
) -> dict[str, JSONValue]:
    try:
        jsonable = _INPUT_ITEM_ADAPTER.dump_python(item, mode="json", warnings="none")
    except (TypeError, ValueError, PydanticSerializationError) as exc:
        msg = f"{context} could not be serialized to JSON"
        raise ConfigError(msg) from exc
    if not is_json_object(value=jsonable):
        msg = f"{context} is not JSON-safe"
        raise ConfigError(msg)
    return dict(jsonable)


def serialize_input_item(
    item: TResponseInputItem,
    *,
    context: str,
) -> dict[str, JSONValue]:
    """Serialize a Responses input item into a JSON-safe dict."""
    return _dump_input_item_jsonable(item, context=context)


def serialize_input_item_param(
    item: TResponseInputItem,
    *,
    context: str,
) -> TResponseInputItem:
    """Serialize a Responses input item into a JSON-safe input item payload."""
    jsonable = serialize_input_item(item, context=context)
    return normalize_input_item_json(jsonable, context=context)


def serialize_input_items(
    items: Sequence[TResponseInputItem],
    *,
    context: str,
) -> tuple[dict[str, JSONValue], ...]:
    """Serialize Responses input items into JSON-safe dicts."""
    return tuple(serialize_input_item(item, context=context) for item in items)


def input_item_json_size(
    item: TResponseInputItem,
    *,
    context: str,
) -> int:
    """Return the serialized JSON size for a Responses input item."""
    jsonable = _dump_input_item_jsonable(item, context=context)
    return json_size(jsonable, sort_keys=True)


__all__ = (
    "input_item_json_size",
    "normalize_input_item_json",
    "parse_input_item",
    "parse_input_item_json",
    "serialize_input_item",
    "serialize_input_item_param",
    "serialize_input_items",
    "validate_input_item_json",
)
