"""Registry and helpers for Agents FunctionTool integration.

agenterm supports local, user-defined function tools implemented in Python and
enabled via `tools.function_tools` in `config.yaml`.

This module intentionally does **not** ship any built-in function tools. The
registry is empty by default; projects can add function tools by registering
them in code and enabling them in config.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from types import MappingProxyType
from typing import TYPE_CHECKING

from agents.strict_schema import ensure_strict_json_schema

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.tool import FunctionTool


@dataclass(frozen=True)
class RegisteredFunctionTool:
    """One registered function tool."""

    name: str
    tool: FunctionTool


_FUNCTION_TOOLS_REGISTRY: Mapping[str, RegisteredFunctionTool] = MappingProxyType({})


def get_function_tools_registry() -> Mapping[str, RegisteredFunctionTool]:
    """Return the current mapping of tool-name → RegisteredFunctionTool."""
    return _FUNCTION_TOOLS_REGISTRY


def _require_strict_registered_tool(entry: RegisteredFunctionTool) -> FunctionTool:
    tool = entry.tool
    if not tool.strict_json_schema:
        msg = (
            f"Function tool '{entry.name}' must set strict_json_schema=True. "
            "Non-strict function tools are not supported."
        )
        raise ConfigError(msg)
    normalized = ensure_strict_json_schema(deepcopy(dict(tool.params_json_schema)))
    if normalized != tool.params_json_schema:
        msg = (
            f"Function tool '{entry.name}' params_json_schema "
            "is not strict-normalized. "
            "Provide a strict JSON schema for all function tools."
        )
        raise ConfigError(msg)
    return tool


def resolve_function_tools(names: list[str]) -> list[FunctionTool]:
    """Resolve enabled function tool names to Agents FunctionTool instances.

    Unknown names are ignored so configuration can remain stable even when a
    tool implementation is not present in the current runtime.
    """
    reg = get_function_tools_registry()
    tools: list[FunctionTool] = []
    for nm in names:
        entry = reg.get(nm)
        if entry is not None:
            tools.append(_require_strict_registered_tool(entry))
    return tools


__all__ = (
    "RegisteredFunctionTool",
    "get_function_tools_registry",
    "resolve_function_tools",
)
