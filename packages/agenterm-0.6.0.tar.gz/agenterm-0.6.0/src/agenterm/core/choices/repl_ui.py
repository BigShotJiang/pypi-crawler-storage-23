"""REPL prompt UI choice sets.

These string tokens are shared across:
- config (`repl.ui.*`)
- SessionState (`core.types.SessionState`)
- `/repl` parsing + completion
- prompt-toolkit wiring (`ui.tui.app`)

They live in `agenterm.core.choices.*` to prevent drift between surfaces.
"""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

ReplTheme = Literal["dark", "light"]
REPL_THEMES: Final[tuple[ReplTheme, ...]] = ("dark", "light")
_REPL_THEME_MAP: Final[Mapping[str, ReplTheme]] = MappingProxyType(
    {
        "dark": "dark",
        "light": "light",
    },
)

ReplColorDepth = Literal["auto", "mono", "ansi", "default", "truecolor"]
REPL_COLOR_DEPTHS: Final[tuple[ReplColorDepth, ...]] = (
    "auto",
    "mono",
    "ansi",
    "default",
    "truecolor",
)
_REPL_COLOR_DEPTH_MAP: Final[Mapping[str, ReplColorDepth]] = MappingProxyType(
    {
        "auto": "auto",
        "mono": "mono",
        "ansi": "ansi",
        "default": "default",
        "truecolor": "truecolor",
    },
)

ReplCompletionMode = Literal["off", "commands", "full"]
REPL_COMPLETION_MODES: Final[tuple[ReplCompletionMode, ...]] = (
    "off",
    "commands",
    "full",
)
_REPL_COMPLETION_MODE_MAP: Final[Mapping[str, ReplCompletionMode]] = MappingProxyType(
    {
        "off": "off",
        "commands": "commands",
        "full": "full",
    },
)

ReplEditingMode = Literal["emacs", "vi"]
REPL_EDITING_MODES: Final[tuple[ReplEditingMode, ...]] = ("emacs", "vi")
_REPL_EDITING_MODE_MAP: Final[Mapping[str, ReplEditingMode]] = MappingProxyType(
    {
        "emacs": "emacs",
        "vi": "vi",
    },
)


def parse_repl_theme(raw: str) -> ReplTheme | None:
    """Return the normalized theme token or None when invalid."""
    return _REPL_THEME_MAP.get(raw.lower())


def parse_repl_color_depth(raw: str) -> ReplColorDepth | None:
    """Return the normalized color depth token or None when invalid."""
    return _REPL_COLOR_DEPTH_MAP.get(raw.lower())


def parse_repl_completion_mode(raw: str) -> ReplCompletionMode | None:
    """Return the normalized completion mode token or None when invalid."""
    return _REPL_COMPLETION_MODE_MAP.get(raw.lower())


def parse_repl_editing_mode(raw: str) -> ReplEditingMode | None:
    """Return the normalized editing mode token or None when invalid."""
    return _REPL_EDITING_MODE_MAP.get(raw.lower())


__all__ = (
    "REPL_COLOR_DEPTHS",
    "REPL_COMPLETION_MODES",
    "REPL_EDITING_MODES",
    "REPL_THEMES",
    "ReplColorDepth",
    "ReplCompletionMode",
    "ReplEditingMode",
    "ReplTheme",
    "parse_repl_color_depth",
    "parse_repl_completion_mode",
    "parse_repl_editing_mode",
    "parse_repl_theme",
)
