"""REPL-specific UX choice sets.

These tokens show up in:
- config.yaml (`repl.ux.*`)
- SessionState (`core.types.SessionState`)
- `/ux` command parsing and completion
- transcript rendering policy (`ui.transcript.model.TranscriptPolicy`)
"""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

ReplVerbosity = Literal["quiet", "normal", "debug"]
REPL_VERBOSITIES: Final[tuple[ReplVerbosity, ...]] = ("quiet", "normal", "debug")
_REPL_VERBOSITY_MAP: Final[Mapping[str, ReplVerbosity]] = MappingProxyType(
    {
        "quiet": "quiet",
        "normal": "normal",
        "debug": "debug",
    },
)

ReplStreamMode = Literal["final", "live"]
REPL_STREAM_MODES: Final[tuple[ReplStreamMode, ...]] = ("final", "live")
_REPL_STREAM_MODE_MAP: Final[Mapping[str, ReplStreamMode]] = MappingProxyType(
    {
        "final": "final",
        "live": "live",
    },
)

ReplReasoningMode = Literal["off", "summary"]
REPL_REASONING_MODES: Final[tuple[ReplReasoningMode, ...]] = ("off", "summary")
_REPL_REASONING_MODE_MAP: Final[Mapping[str, ReplReasoningMode]] = MappingProxyType(
    {
        "off": "off",
        "summary": "summary",
    },
)

ReplDiffsMode = Literal["off", "summary"]
REPL_DIFFS_MODES: Final[tuple[ReplDiffsMode, ...]] = ("off", "summary")
_REPL_DIFFS_MODE_MAP: Final[Mapping[str, ReplDiffsMode]] = MappingProxyType(
    {
        "off": "off",
        "summary": "summary",
    },
)


def parse_repl_verbosity(raw: str) -> ReplVerbosity | None:
    """Return the normalized verbosity token or None when invalid."""
    return _REPL_VERBOSITY_MAP.get(raw.lower())


def parse_repl_stream_mode(raw: str) -> ReplStreamMode | None:
    """Return the normalized stream mode token or None when invalid."""
    return _REPL_STREAM_MODE_MAP.get(raw.lower())


def parse_repl_reasoning_mode(raw: str) -> ReplReasoningMode | None:
    """Return the normalized reasoning mode token or None when invalid."""
    return _REPL_REASONING_MODE_MAP.get(raw.lower())


def parse_repl_diffs_mode(raw: str) -> ReplDiffsMode | None:
    """Return the normalized diffs mode token or None when invalid."""
    return _REPL_DIFFS_MODE_MAP.get(raw.lower())


__all__ = (
    "REPL_DIFFS_MODES",
    "REPL_REASONING_MODES",
    "REPL_STREAM_MODES",
    "REPL_VERBOSITIES",
    "ReplDiffsMode",
    "ReplReasoningMode",
    "ReplStreamMode",
    "ReplVerbosity",
    "parse_repl_diffs_mode",
    "parse_repl_reasoning_mode",
    "parse_repl_stream_mode",
    "parse_repl_verbosity",
)
