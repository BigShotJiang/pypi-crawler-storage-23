"""Image generation tool option choice sets (hosted tool)."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

ImageBackground = Literal["transparent", "opaque", "auto"]
IMAGE_BACKGROUNDS: Final[tuple[ImageBackground, ...]] = (
    "transparent",
    "opaque",
    "auto",
)
_IMAGE_BACKGROUND_MAP: Final[Mapping[str, ImageBackground]] = MappingProxyType(
    {
        "transparent": "transparent",
        "opaque": "opaque",
        "auto": "auto",
    },
)

ImageInputFidelity = Literal["high", "low"]
IMAGE_INPUT_FIDELITIES: Final[tuple[ImageInputFidelity, ...]] = ("high", "low")
_IMAGE_INPUT_FIDELITY_MAP: Final[Mapping[str, ImageInputFidelity]] = MappingProxyType(
    {
        "high": "high",
        "low": "low",
    },
)

ImageModeration = Literal["auto", "low"]
IMAGE_MODERATIONS: Final[tuple[ImageModeration, ...]] = ("auto", "low")
_IMAGE_MODERATION_MAP: Final[Mapping[str, ImageModeration]] = MappingProxyType(
    {
        "auto": "auto",
        "low": "low",
    },
)

ImageOutputFormat = Literal["png", "webp", "jpeg"]
IMAGE_OUTPUT_FORMATS: Final[tuple[ImageOutputFormat, ...]] = ("png", "webp", "jpeg")
_IMAGE_OUTPUT_FORMAT_MAP: Final[Mapping[str, ImageOutputFormat]] = MappingProxyType(
    {
        "png": "png",
        "webp": "webp",
        "jpeg": "jpeg",
    },
)

ImageQuality = Literal["low", "medium", "high", "auto"]
IMAGE_QUALITIES: Final[tuple[ImageQuality, ...]] = ("low", "medium", "high", "auto")
_IMAGE_QUALITY_MAP: Final[Mapping[str, ImageQuality]] = MappingProxyType(
    {
        "low": "low",
        "medium": "medium",
        "high": "high",
        "auto": "auto",
    },
)

ImageSize = Literal["1024x1024", "1024x1536", "1536x1024", "auto"]
IMAGE_SIZES: Final[tuple[ImageSize, ...]] = (
    "1024x1024",
    "1024x1536",
    "1536x1024",
    "auto",
)
_IMAGE_SIZE_MAP: Final[Mapping[str, ImageSize]] = MappingProxyType(
    {
        "1024x1024": "1024x1024",
        "1024x1536": "1024x1536",
        "1536x1024": "1536x1024",
        "auto": "auto",
    },
)


def parse_image_background(raw: str) -> ImageBackground | None:
    """Return the normalized background token or None when invalid."""
    return _IMAGE_BACKGROUND_MAP.get(raw.lower())


def parse_image_input_fidelity(raw: str) -> ImageInputFidelity | None:
    """Return the normalized input_fidelity token or None when invalid."""
    return _IMAGE_INPUT_FIDELITY_MAP.get(raw.lower())


def parse_image_moderation(raw: str) -> ImageModeration | None:
    """Return the normalized moderation token or None when invalid."""
    return _IMAGE_MODERATION_MAP.get(raw.lower())


def parse_image_output_format(raw: str) -> ImageOutputFormat | None:
    """Return the normalized output_format token or None when invalid."""
    return _IMAGE_OUTPUT_FORMAT_MAP.get(raw.lower())


def parse_image_quality(raw: str) -> ImageQuality | None:
    """Return the normalized quality token or None when invalid."""
    return _IMAGE_QUALITY_MAP.get(raw.lower())


def parse_image_size(raw: str) -> ImageSize | None:
    """Return the normalized size token or None when invalid."""
    return _IMAGE_SIZE_MAP.get(raw.lower())


__all__ = (
    "IMAGE_BACKGROUNDS",
    "IMAGE_INPUT_FIDELITIES",
    "IMAGE_MODERATIONS",
    "IMAGE_OUTPUT_FORMATS",
    "IMAGE_QUALITIES",
    "IMAGE_SIZES",
    "ImageBackground",
    "ImageInputFidelity",
    "ImageModeration",
    "ImageOutputFormat",
    "ImageQuality",
    "ImageSize",
    "parse_image_background",
    "parse_image_input_fidelity",
    "parse_image_moderation",
    "parse_image_output_format",
    "parse_image_quality",
    "parse_image_size",
)
