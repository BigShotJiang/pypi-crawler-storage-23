"""MCP-related choice sets shared across config and normalization."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

McpConnectorId = Literal[
    "connector_dropbox",
    "connector_gmail",
    "connector_googlecalendar",
    "connector_googledrive",
    "connector_microsoftteams",
    "connector_outlookcalendar",
    "connector_outlookemail",
    "connector_sharepoint",
]
MCP_CONNECTOR_IDS: Final[tuple[McpConnectorId, ...]] = (
    "connector_dropbox",
    "connector_gmail",
    "connector_googlecalendar",
    "connector_googledrive",
    "connector_microsoftteams",
    "connector_outlookcalendar",
    "connector_outlookemail",
    "connector_sharepoint",
)
_MCP_CONNECTOR_ID_MAP: Final[Mapping[str, McpConnectorId]] = MappingProxyType(
    {cid: cid for cid in MCP_CONNECTOR_IDS},
)

McpServerKind = Literal["stdio", "sse", "streamable_http"]
MCP_SERVER_KINDS: Final[tuple[McpServerKind, ...]] = ("stdio", "sse", "streamable_http")
_MCP_SERVER_KIND_MAP: Final[Mapping[str, McpServerKind]] = MappingProxyType(
    {
        "stdio": "stdio",
        "sse": "sse",
        "streamable_http": "streamable_http",
    },
)

EncodingErrorHandler = Literal["strict", "ignore", "replace"]
ENCODING_ERROR_HANDLERS: Final[tuple[EncodingErrorHandler, ...]] = (
    "strict",
    "ignore",
    "replace",
)
_ENCODING_ERROR_HANDLER_MAP: Final[Mapping[str, EncodingErrorHandler]] = (
    MappingProxyType(
        {
            "strict": "strict",
            "ignore": "ignore",
            "replace": "replace",
        },
    )
)


def parse_mcp_server_kind(raw: str) -> McpServerKind | None:
    """Return the normalized server kind token or None when invalid."""
    return _MCP_SERVER_KIND_MAP.get(raw.lower())


def parse_mcp_connector_id(raw: str) -> McpConnectorId | None:
    """Return the normalized connector_id token or None when invalid."""
    return _MCP_CONNECTOR_ID_MAP.get(raw.strip())


def parse_encoding_error_handler(raw: str) -> EncodingErrorHandler | None:
    """Return the normalized encoding handler token or None when invalid."""
    return _ENCODING_ERROR_HANDLER_MAP.get(raw.lower())


__all__ = (
    "ENCODING_ERROR_HANDLERS",
    "MCP_CONNECTOR_IDS",
    "MCP_SERVER_KINDS",
    "EncodingErrorHandler",
    "McpConnectorId",
    "McpServerKind",
    "parse_encoding_error_handler",
    "parse_mcp_connector_id",
    "parse_mcp_server_kind",
)
