"""Tool configuration choice sets shared across config, parsing, and tool specs."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

from agenterm.core.choices.common import LOW_MEDIUM_HIGH, LowMediumHigh

if TYPE_CHECKING:
    from collections.abc import Mapping

SearchContextSize = LowMediumHigh
SEARCH_CONTEXT_SIZES: Final[tuple[SearchContextSize, ...]] = LOW_MEDIUM_HIGH
_SEARCH_CONTEXT_SIZE_MAP: Final[Mapping[str, SearchContextSize]] = MappingProxyType(
    {
        "low": "low",
        "medium": "medium",
        "high": "high",
    },
)

SandboxNetwork = Literal["allow", "deny"]
SANDBOX_NETWORKS: Final[tuple[SandboxNetwork, ...]] = ("allow", "deny")
_SANDBOX_NETWORK_MAP: Final[Mapping[str, SandboxNetwork]] = MappingProxyType(
    {
        "allow": "allow",
        "deny": "deny",
    },
)


def parse_search_context_size(raw: str) -> SearchContextSize | None:
    """Return the normalized search_context_size token or None when invalid."""
    return _SEARCH_CONTEXT_SIZE_MAP.get(raw.lower())


def parse_sandbox_network(raw: str) -> SandboxNetwork | None:
    """Return the normalized sandbox network token or None when invalid."""
    return _SANDBOX_NETWORK_MAP.get(raw.lower())


__all__ = (
    "SANDBOX_NETWORKS",
    "SEARCH_CONTEXT_SIZES",
    "SandboxNetwork",
    "SearchContextSize",
    "parse_sandbox_network",
    "parse_search_context_size",
)
