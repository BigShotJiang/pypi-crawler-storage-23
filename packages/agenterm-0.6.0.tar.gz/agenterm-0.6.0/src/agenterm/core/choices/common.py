"""Common tokens and helpers shared by multiple choice sets."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

UNSET_MARKER: Final[str] = "unset"

LowMediumHigh = Literal["low", "medium", "high"]
LOW_MEDIUM_HIGH: Final[tuple[LowMediumHigh, ...]] = ("low", "medium", "high")

_LOW_MEDIUM_HIGH_MAP: Final[Mapping[str, LowMediumHigh]] = MappingProxyType(
    {
        "low": "low",
        "medium": "medium",
        "high": "high",
    },
)


def parse_low_medium_high(raw: str) -> LowMediumHigh | None:
    """Return the normalized low|medium|high token or None when invalid."""
    return _LOW_MEDIUM_HIGH_MAP.get(raw.lower())


__all__ = ("LOW_MEDIUM_HIGH", "UNSET_MARKER", "LowMediumHigh", "parse_low_medium_high")
