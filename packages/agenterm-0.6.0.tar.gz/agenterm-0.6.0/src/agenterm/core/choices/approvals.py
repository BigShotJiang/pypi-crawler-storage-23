"""Approval policy choice sets shared across config, parsing, and UI."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

ApprovalMode = Literal["prompt", "auto"]
APPROVAL_MODES: Final[tuple[ApprovalMode, ...]] = ("prompt", "auto")
_APPROVAL_MODE_MAP: Final[Mapping[str, ApprovalMode]] = MappingProxyType(
    {
        "prompt": "prompt",
        "auto": "auto",
    },
)


def parse_approval_mode(raw: str) -> ApprovalMode | None:
    """Return the normalized approval mode token or None when invalid."""
    return _APPROVAL_MODE_MAP.get(raw.lower())


__all__ = ("APPROVAL_MODES", "ApprovalMode", "parse_approval_mode")
