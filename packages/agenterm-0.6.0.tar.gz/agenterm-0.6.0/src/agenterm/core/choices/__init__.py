"""Canonical enumerated choice sets used across agenterm.

This package is the single source of truth for string-token enums that appear in
multiple layers (config, normalization, CLI parsing, UI policy/state).

Rules:
- Shared choice sets are defined here exactly once.
- Other layers import these types/value tuples instead of re-declaring Literals.
- CLI may accept the sentinel string from `common.UNSET_MARKER` to map to None, but
  that token is not part of the underlying value types.
"""

from __future__ import annotations

__all__ = ()
