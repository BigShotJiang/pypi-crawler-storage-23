"""Config scope choice set (global vs local)."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

ConfigScope = Literal["global", "local"]
CONFIG_SCOPES: Final[tuple[ConfigScope, ...]] = ("global", "local")
_CONFIG_SCOPE_MAP: Final[Mapping[str, ConfigScope]] = MappingProxyType(
    {
        "global": "global",
        "local": "local",
    },
)


def parse_config_scope(raw: str) -> ConfigScope | None:
    """Return the normalized config scope token or None when invalid."""
    return _CONFIG_SCOPE_MAP.get(raw.lower())


__all__ = ("CONFIG_SCOPES", "ConfigScope", "parse_config_scope")
