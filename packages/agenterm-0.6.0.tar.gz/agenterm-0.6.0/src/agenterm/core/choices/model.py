"""Model-level configuration choice sets (ModelSettings surface)."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal

from agenterm.core.choices.common import LOW_MEDIUM_HIGH, LowMediumHigh

if TYPE_CHECKING:
    from collections.abc import Mapping

ModelTruncation = Literal["auto", "disabled"]
MODEL_TRUNCATIONS: Final[tuple[ModelTruncation, ...]] = ("auto", "disabled")
_MODEL_TRUNCATION_MAP: Final[Mapping[str, ModelTruncation]] = MappingProxyType(
    {
        "auto": "auto",
        "disabled": "disabled",
    },
)

ModelVerbosity = LowMediumHigh
MODEL_VERBOSITIES: Final[tuple[ModelVerbosity, ...]] = LOW_MEDIUM_HIGH
_MODEL_VERBOSITY_MAP: Final[Mapping[str, ModelVerbosity]] = MappingProxyType(
    {
        "low": "low",
        "medium": "medium",
        "high": "high",
    },
)

PromptCacheRetention = Literal["in_memory", "24h"]
PROMPT_CACHE_RETENTIONS: Final[tuple[PromptCacheRetention, ...]] = ("in_memory", "24h")
_PROMPT_CACHE_RETENTION_MAP: Final[Mapping[str, PromptCacheRetention]] = (
    MappingProxyType(
        {
            "in_memory": "in_memory",
            "24h": "24h",
        },
    )
)

ReasoningEffort = Literal["none", "minimal", "low", "medium", "high", "xhigh"]
REASONING_EFFORTS: Final[tuple[ReasoningEffort, ...]] = (
    "none",
    "minimal",
    "low",
    "medium",
    "high",
    "xhigh",
)
_REASONING_EFFORT_MAP: Final[Mapping[str, ReasoningEffort]] = MappingProxyType(
    {
        "none": "none",
        "minimal": "minimal",
        "low": "low",
        "medium": "medium",
        "high": "high",
        "xhigh": "xhigh",
    },
)

ReasoningSummary = Literal["auto", "concise", "detailed"]
REASONING_SUMMARIES: Final[tuple[ReasoningSummary, ...]] = (
    "auto",
    "concise",
    "detailed",
)
_REASONING_SUMMARY_MAP: Final[Mapping[str, ReasoningSummary]] = MappingProxyType(
    {
        "auto": "auto",
        "concise": "concise",
        "detailed": "detailed",
    },
)


def parse_model_truncation(raw: str) -> ModelTruncation | None:
    """Return the normalized truncation token or None when invalid."""
    return _MODEL_TRUNCATION_MAP.get(raw.lower())


def parse_model_verbosity(raw: str) -> ModelVerbosity | None:
    """Return the normalized verbosity token or None when invalid."""
    return _MODEL_VERBOSITY_MAP.get(raw.lower())


def is_model_verbosity(raw: str | None) -> bool:
    """Return True when the token is a valid model verbosity value."""
    return isinstance(raw, str) and parse_model_verbosity(raw) is not None


def parse_prompt_cache_retention(raw: str) -> PromptCacheRetention | None:
    """Return the normalized prompt cache retention token or None when invalid."""
    return _PROMPT_CACHE_RETENTION_MAP.get(raw.lower())


def parse_reasoning_effort(raw: str) -> ReasoningEffort | None:
    """Return the normalized reasoning effort token or None when invalid."""
    return _REASONING_EFFORT_MAP.get(raw.lower())


def parse_reasoning_summary(raw: str) -> ReasoningSummary | None:
    """Return the normalized reasoning summary token or None when invalid."""
    return _REASONING_SUMMARY_MAP.get(raw.lower())


__all__ = (
    "MODEL_TRUNCATIONS",
    "MODEL_VERBOSITIES",
    "PROMPT_CACHE_RETENTIONS",
    "REASONING_EFFORTS",
    "REASONING_SUMMARIES",
    "ModelTruncation",
    "ModelVerbosity",
    "PromptCacheRetention",
    "ReasoningEffort",
    "ReasoningSummary",
    "is_model_verbosity",
    "parse_model_truncation",
    "parse_model_verbosity",
    "parse_prompt_cache_retention",
    "parse_reasoning_effort",
    "parse_reasoning_summary",
)
