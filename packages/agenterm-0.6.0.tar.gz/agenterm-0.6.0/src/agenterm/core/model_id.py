"""Model id helpers for execution-plane resolution."""

from __future__ import annotations

from typing import Literal

from agenterm.core.errors import ValidationError

ModelPlane = Literal["openai", "gateway"]

_GATEWAY_MODEL_PARTS = 3
_GPT5_PREFIX = "gpt-5"
_GPT5_CHAT_PREFIX = "gpt-5-chat"


def is_openai_model_id(model_id: str) -> bool:
    """Return True if model_id is in the openai/<model> namespace."""
    return model_id.lower().startswith("openai/")


def is_gateway_model_id(model_id: str) -> bool:
    """Return True if model_id is in the gateway/<route>/<model> namespace."""
    return model_id.lower().startswith("gateway/")


def model_plane(model_id: str) -> ModelPlane:
    """Resolve the execution plane for a model id."""
    if is_openai_model_id(model_id):
        return "openai"
    if is_gateway_model_id(model_id):
        return "gateway"
    msg = "Model id prefix must be openai/ or gateway/."
    raise ValidationError(msg)


def openai_model_name(model_id: str) -> str:
    """Return the native OpenAI model name for openai/<model> ids."""
    plane = model_plane(model_id)
    if plane != "openai":
        msg = f"OpenAI model id required (got {model_id!r})."
        raise ValidationError(msg)
    name = model_id.split("/", 1)[1]
    if not name or "/" in name:
        msg = "OpenAI model ids must be openai/<model>."
        raise ValidationError(msg)
    return name


def openai_model_supports_reasoning(model_id: str) -> bool:
    """Return True when the OpenAI model supports reasoning settings."""
    name = openai_model_name(model_id).lower()
    return name.startswith(_GPT5_PREFIX)


def openai_model_requires_reasoning(model_id: str) -> bool:
    """Return True when GPT-5 models require reasoning settings."""
    name = openai_model_name(model_id).lower()
    if name.startswith(_GPT5_CHAT_PREFIX):
        return False
    return name.startswith(_GPT5_PREFIX)


def split_gateway_model_id(model_id: str) -> tuple[str, str]:
    """Return (route, model) for gateway/<route>/<model> ids."""
    plane = model_plane(model_id)
    if plane != "gateway":
        msg = f"Gateway model id required (got {model_id!r})."
        raise ValidationError(msg)
    parts = model_id.split("/", 2)
    if len(parts) != _GATEWAY_MODEL_PARTS:
        msg = "Gateway model ids must be gateway/<route>/<model>."
        raise ValidationError(msg)
    route, model = parts[1], parts[2]
    if not route or not model:
        msg = "Gateway model ids must be gateway/<route>/<model>."
        raise ValidationError(msg)
    return route, model


__all__ = (
    "ModelPlane",
    "is_gateway_model_id",
    "is_openai_model_id",
    "model_plane",
    "openai_model_name",
    "openai_model_requires_reasoning",
    "openai_model_supports_reasoning",
    "split_gateway_model_id",
)
