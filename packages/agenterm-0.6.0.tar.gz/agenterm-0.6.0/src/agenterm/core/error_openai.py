"""OpenAI error parsing helpers for structured reports."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from openai import APIError, APIStatusError

from agenterm.core.error_text import bounded_text
from agenterm.core.json_codec import as_str, loads_json_value

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


type OpenAIErrorFields = tuple[str | None, str | None, str | None, str | None]


def _first_nonempty_str(*values: str | None) -> str | None:
    for value in values:
        if value:
            return value
    return None


def _openai_body_fields(body_json: JSONValue | None) -> OpenAIErrorFields:
    if isinstance(body_json, dict):
        err = body_json.get("error")
        if isinstance(err, dict):
            return (
                as_str(err.get("message")),
                as_str(err.get("code")),
                as_str(err.get("param")),
                as_str(err.get("type")),
            )
        return (
            as_str(body_json.get("message")),
            as_str(body_json.get("code")),
            as_str(body_json.get("param")),
            as_str(body_json.get("type")),
        )
    if isinstance(body_json, str):
        return body_json, None, None, None
    return None, None, None, None


def _parse_body_fields(exc: APIError) -> OpenAIErrorFields:
    body = exc.body
    body_json: JSONValue | None
    if body is None:
        body_json = None
    elif isinstance(body, str):
        body_json = body
    else:
        try:
            serialized = json.dumps(body)
        except (TypeError, ValueError):
            body_json = None
        else:
            body_json = loads_json_value(serialized)
    message, code, param, err_type = _openai_body_fields(body_json)
    return (
        _first_nonempty_str(message),
        _first_nonempty_str(code, exc.code),
        _first_nonempty_str(param, exc.param),
        _first_nonempty_str(err_type, exc.type),
    )


def _openai_details_from_fields(
    *,
    message: str | None,
    code: str | None,
    param: str | None,
    err_type: str | None,
    exc: APIError,
) -> tuple[str | None, dict[str, JSONValue]]:
    details: dict[str, JSONValue] = {}
    bounded_message = bounded_text(message) if message else None
    if bounded_message:
        details["error_message"] = bounded_message
    if code:
        details["code"] = code
    if param:
        details["param"] = param
    if err_type:
        details["type"] = err_type
    if isinstance(exc, APIStatusError):
        details["status_code"] = int(exc.status_code)
        if exc.request_id:
            details["request_id"] = exc.request_id
    return bounded_message, details


def openai_error_payload(
    exc: APIError,
) -> tuple[str | None, dict[str, JSONValue]]:
    """Return the bounded message and detail map for an OpenAI error."""
    message, code, param, err_type = _parse_body_fields(exc)
    return _openai_details_from_fields(
        message=message,
        code=code,
        param=param,
        err_type=err_type,
        exc=exc,
    )


def openai_status_message(
    exc: APIStatusError,
    *,
    provider_name: str = "OpenAI",
    detail_message: str | None = None,
) -> str:
    """Return a user-facing status message for provider errors."""
    message, details = openai_error_payload(exc)
    if message is None and detail_message:
        message = detail_message
    suffix_bits: list[str] = []
    code = details.get("code")
    if code:
        suffix_bits.append(f"code={code}")
    param = details.get("param")
    if param:
        suffix_bits.append(f"param={param}")
    base = f"{provider_name} request failed (status {exc.status_code}"
    base = f"{base}, {', '.join(suffix_bits)})" if suffix_bits else f"{base})"
    if message:
        return f"{base}: {message}"
    return base


__all__ = ("openai_error_payload", "openai_status_message")
