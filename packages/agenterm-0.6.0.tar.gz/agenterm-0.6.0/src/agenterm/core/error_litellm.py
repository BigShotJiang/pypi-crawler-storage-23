"""LiteLLM error parsing helpers for structured reports."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, TypeGuard

from agenterm.core.error_text import bounded_text

_litellm_detail_types: tuple[type[Exception], ...]
_litellm_retryable_types: tuple[type[Exception], ...]


try:  # pragma: no cover - optional dependency
    from litellm.exceptions import (
        APIConnectionError as LiteLLMApiConnectionError,
    )
    from litellm.exceptions import (
        APIError as LiteLLMApiError,
    )
    from litellm.exceptions import (
        APIResponseValidationError as LiteLLMApiResponseValidationError,
    )
    from litellm.exceptions import (
        AuthenticationError as LiteLLMAuthenticationError,
    )
    from litellm.exceptions import (
        BadGatewayError as LiteLLMBadGatewayError,
    )
    from litellm.exceptions import (
        BadRequestError as LiteLLMBadRequestError,
    )
    from litellm.exceptions import (
        ContentPolicyViolationError as LiteLLMContentPolicyViolationError,
    )
    from litellm.exceptions import (
        ContextWindowExceededError as LiteLLMContextWindowExceededError,
    )
    from litellm.exceptions import (
        ImageFetchError as LiteLLMImageFetchError,
    )
    from litellm.exceptions import (
        InternalServerError as LiteLLMInternalServerError,
    )
    from litellm.exceptions import (
        JSONSchemaValidationError as LiteLLMJsonSchemaValidationError,
    )
    from litellm.exceptions import (
        LiteLLMUnknownProvider as LiteLLMUnknownProviderError,
    )
    from litellm.exceptions import (
        MidStreamFallbackError as LiteLLMMidStreamFallbackError,
    )
    from litellm.exceptions import (
        MockException as LiteLLMMockException,
    )
    from litellm.exceptions import (
        NotFoundError as LiteLLMNotFoundError,
    )
    from litellm.exceptions import (
        PermissionDeniedError as LiteLLMPermissionDeniedError,
    )
    from litellm.exceptions import (
        RateLimitError as LiteLLMRateLimitError,
    )
    from litellm.exceptions import (
        RejectedRequestError as LiteLLMRejectedRequestError,
    )
    from litellm.exceptions import (
        ServiceUnavailableError as LiteLLMServiceUnavailableError,
    )
    from litellm.exceptions import (
        Timeout as LiteLLMTimeout,
    )
    from litellm.exceptions import (
        UnprocessableEntityError as LiteLLMUnprocessableEntityError,
    )
    from litellm.exceptions import (
        UnsupportedParamsError as LiteLLMUnsupportedParamsError,
    )
except ImportError:  # pragma: no cover - optional dependency
    _litellm_detail_types = ()
    _litellm_retryable_types = ()
else:
    _litellm_detail_types = (
        LiteLLMAuthenticationError,
        LiteLLMNotFoundError,
        LiteLLMBadRequestError,
        LiteLLMImageFetchError,
        LiteLLMUnprocessableEntityError,
        LiteLLMTimeout,
        LiteLLMPermissionDeniedError,
        LiteLLMRateLimitError,
        LiteLLMContextWindowExceededError,
        LiteLLMRejectedRequestError,
        LiteLLMContentPolicyViolationError,
        LiteLLMInternalServerError,
        LiteLLMServiceUnavailableError,
        LiteLLMBadGatewayError,
        LiteLLMApiError,
        LiteLLMApiConnectionError,
        LiteLLMApiResponseValidationError,
        LiteLLMJsonSchemaValidationError,
        LiteLLMMockException,
        LiteLLMUnsupportedParamsError,
        LiteLLMUnknownProviderError,
        LiteLLMMidStreamFallbackError,
    )
    _litellm_retryable_types = (
        LiteLLMTimeout,
        LiteLLMApiConnectionError,
        LiteLLMRateLimitError,
        LiteLLMServiceUnavailableError,
        LiteLLMBadGatewayError,
        LiteLLMInternalServerError,
    )

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


_RETRYABLE_STATUS_MIN = 500


class _LiteLLMDetailError(Protocol):
    message: str | None
    llm_provider: str | None
    model: str | None
    status_code: int | None
    max_retries: int | None
    num_retries: int | None


def _is_litellm_detail_error(exc: Exception) -> TypeGuard[_LiteLLMDetailError]:
    return isinstance(exc, _litellm_detail_types)


def litellm_error_payload(
    exc: Exception,
) -> tuple[str | None, dict[str, JSONValue]]:
    """Return the bounded message + details for LiteLLM-raised errors."""
    if not _is_litellm_detail_error(exc):
        return None, {}
    details: dict[str, JSONValue] = {}
    message = exc.message if isinstance(exc.message, str) else None
    bounded_message: str | None = None
    if message:
        bounded_message = bounded_text(message)
        details["error_message"] = bounded_message
    if exc.llm_provider:
        details["llm_provider"] = exc.llm_provider
    if exc.model:
        details["model"] = exc.model
    if exc.status_code is not None:
        details["status_code"] = int(exc.status_code)
    if exc.num_retries is not None:
        details["num_retries"] = int(exc.num_retries)
    if exc.max_retries is not None:
        details["max_retries"] = int(exc.max_retries)
    return bounded_message, details


def litellm_status_code(exc: Exception) -> int | None:
    """Return the LiteLLM status code when available."""
    if not _is_litellm_detail_error(exc):
        return None
    if exc.status_code is None:
        return None
    return int(exc.status_code)


def is_litellm_retryable(exc: Exception) -> bool:
    """Return True when a LiteLLM exception is retryable."""
    if isinstance(exc, _litellm_retryable_types):
        return True
    status = litellm_status_code(exc)
    if status is None:
        return False
    if status in (408, 409, 429):
        return True
    return status >= _RETRYABLE_STATUS_MIN


def litellm_exception_types() -> tuple[type[Exception], ...]:
    """Return the known LiteLLM exception types (empty when LiteLLM is unavailable)."""
    return _litellm_detail_types


__all__ = (
    "is_litellm_retryable",
    "litellm_error_payload",
    "litellm_exception_types",
    "litellm_status_code",
)
