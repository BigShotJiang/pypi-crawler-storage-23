"""Shared OpenAI-compatible client for gateway routes."""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import TYPE_CHECKING

from openai import AsyncOpenAI, DefaultAsyncHttpxClient

from agenterm.core.dotenv_loader import ensure_global_dotenv_loaded
from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.config.model import GatewayRouteConfig


@dataclass(slots=True)
class _GatewayClientState:
    http_client: DefaultAsyncHttpxClient | None = None
    clients: (
        dict[
            tuple[
                str,
                str,
                tuple[tuple[str, str], ...],
                int | None,
                int | None,
                float | None,
                float | None,
            ],
            AsyncOpenAI,
        ]
        | None
    ) = None


_STATE = _GatewayClientState()


def _shared_http_client() -> DefaultAsyncHttpxClient:
    if _STATE.http_client is None:
        _STATE.http_client = DefaultAsyncHttpxClient()
    return _STATE.http_client


def _normalized_headers(
    headers: Mapping[str, str] | None,
) -> tuple[tuple[str, str], ...]:
    if not headers:
        return ()
    return tuple(sorted((str(k), str(v)) for k, v in headers.items()))


def _route_api_key(route: str, route_cfg: GatewayRouteConfig) -> str:
    ensure_global_dotenv_loaded()
    if route_cfg.api_key_env is None:
        return ""
    value = os.environ.get(route_cfg.api_key_env)
    if not value:
        msg = (
            f"Missing environment variable {route_cfg.api_key_env} for "
            f"gateway route {route}."
        )
        raise ConfigError(msg)
    return value


def _route_resilience_cache_tuple(
    route_cfg: GatewayRouteConfig,
) -> tuple[int | None, int | None, float | None, float | None]:
    return (
        route_cfg.retry_max_retries,
        route_cfg.retry_max_total_attempts,
        route_cfg.retry_deadline_seconds,
        route_cfg.retry_attempt_timeout_seconds,
    )


def get_gateway_client(
    *,
    route: str,
    route_cfg: GatewayRouteConfig,
) -> AsyncOpenAI:
    """Return a cached OpenAI-compatible client for a gateway route."""
    api_key = _route_api_key(route, route_cfg)
    base_url = route_cfg.base_url or "https://api.openai.com/v1"
    headers_key = _normalized_headers(route_cfg.headers)
    resilience_key = _route_resilience_cache_tuple(route_cfg)
    cache_key = (base_url, api_key, headers_key, *resilience_key)
    if _STATE.clients is None:
        _STATE.clients = {}
    cached = _STATE.clients.get(cache_key)
    if cached is not None:
        return cached
    default_headers = dict(route_cfg.headers or {})
    client = AsyncOpenAI(
        api_key=api_key,
        base_url=base_url,
        default_headers=default_headers or None,
        http_client=_shared_http_client(),
        timeout=route_cfg.retry_attempt_timeout_seconds,
        max_retries=0,
    )
    _STATE.clients[cache_key] = client
    return client


def reset_gateway_client_cache() -> None:
    """Reset cached gateway clients and shared HTTP client."""
    _STATE.clients = None
    _STATE.http_client = None


__all__ = ("get_gateway_client", "reset_gateway_client_cache")
