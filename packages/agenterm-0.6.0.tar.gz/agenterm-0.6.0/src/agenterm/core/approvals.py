"""Per-session approvals context and managers for tool approvals."""

from __future__ import annotations

from agenterm.core.approvals_context import ApprovalEvent, ApprovalsContext
from agenterm.core.approvals_managers import (
    ApprovalManager,
    CompressionApprovalManager,
    McpApprovalManager,
    PatchApprovalManager,
    ShellApprovalManager,
)
from agenterm.core.approvals_models import (
    CompressionApprovalAction,
    CompressionApprovalDetail,
    CompressionApprovalItem,
    McpApprovalDetail,
    McpApprovalItem,
    PatchApprovalDetail,
    PatchApprovalItem,
    ShellApprovalDetail,
    ShellApprovalItem,
)

__all__ = (
    "ApprovalEvent",
    "ApprovalManager",
    "ApprovalsContext",
    "CompressionApprovalAction",
    "CompressionApprovalDetail",
    "CompressionApprovalItem",
    "CompressionApprovalManager",
    "McpApprovalDetail",
    "McpApprovalItem",
    "McpApprovalManager",
    "PatchApprovalDetail",
    "PatchApprovalItem",
    "PatchApprovalManager",
    "ShellApprovalDetail",
    "ShellApprovalItem",
    "ShellApprovalManager",
)
