"""Agent payloads for CLI JSON envelopes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class AgentsListPayload:
    """Payload for `agenterm agents list` in JSON mode."""

    available: tuple[str, ...]
    local: tuple[str, ...]
    global_agents: tuple[str, ...]
    bundled: tuple[str, ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "available": list(self.available),
            "local": list(self.local),
            "global": list(self.global_agents),
            "bundled": list(self.bundled),
        }


@dataclass(frozen=True)
class AgentShowPayload:
    """Payload for `agenterm agents show` in JSON mode."""

    name: str
    source: str | None
    path: str | None
    text: str
    sha256: str | None
    size_bytes: int
    render_mode: str

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "name": self.name,
            "source": self.source,
            "path": self.path,
            "text": self.text,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
        }


@dataclass(frozen=True)
class AgentPathPayload:
    """Payload for `agenterm agents path` in JSON mode."""

    name: str
    path: str | None
    source: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "name": self.name,
            "path": self.path,
            "source": self.source,
        }


@dataclass(frozen=True)
class AgentsSavePayload:
    """Payload for `agenterm agents save` in JSON mode."""

    scope: str
    source: str
    paths: tuple[str, ...]
    overwritten: bool

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "scope": self.scope,
            "source": self.source,
            "paths": list(self.paths),
            "overwritten": self.overwritten,
        }


__all__ = (
    "AgentPathPayload",
    "AgentShowPayload",
    "AgentsListPayload",
    "AgentsSavePayload",
)
