"""Global `.env` loader for agenterm (global-only, no project scanning).

This module provides the single canonical place that:
- loads `~/.agenterm/.env` (if present) via python-dotenv, and
- guarantees we do **not** search the current working directory for `.env`.

Rationale:
- Avoid accidental secret leakage via git by never encouraging per-project `.env`
  files for agenterm credentials.
- Keep CI behavior conventional: CI should set env vars via secrets managers.
"""

from __future__ import annotations

import functools

from dotenv import load_dotenv

from agenterm.config.paths import global_env_path


@functools.lru_cache(maxsize=1)
def ensure_global_dotenv_loaded() -> None:
    """Load ~/.agenterm/.env exactly once per process (cached)."""
    load_dotenv(dotenv_path=str(global_env_path()), override=False)


__all__ = ("ensure_global_dotenv_loaded",)
