"""MCP payloads for CLI JSON envelopes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class McpServersPayload:
    """Payload for `agenterm mcp servers` in JSON mode."""

    servers: tuple[Mapping[str, JSONValue], ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        servers: list[JSONValue] = [dict(server) for server in self.servers]
        return {"servers": servers}


@dataclass(frozen=True)
class McpToolSummary:
    """Summary of one MCP tool."""

    name: str
    description: str
    title: str | None
    has_output_schema: bool

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "name": self.name,
            "description": self.description,
            "title": self.title,
            "has_output_schema": self.has_output_schema,
        }


@dataclass(frozen=True)
class McpToolsPayload:
    """Payload for `agenterm mcp tools` in JSON mode."""

    tools_by_server: Mapping[str, tuple[McpToolSummary, ...]]
    total_tools: int

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        tools_by_server: dict[str, JSONValue] = {}
        for server_label, tools in self.tools_by_server.items():
            tool_items: list[JSONValue] = [tool.to_json() for tool in tools]
            tools_by_server[server_label] = tool_items
        return {
            "tools_by_server": dict(tools_by_server),
            "total_tools": self.total_tools,
        }


@dataclass(frozen=True)
class McpInspectPayload:
    """Payload for `agenterm mcp inspect` in JSON mode."""

    tools: tuple[McpToolSummary, ...]
    out_path: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        tools: list[JSONValue] = [tool.to_json() for tool in self.tools]
        return {
            "tools": tools,
            "out_path": self.out_path,
        }


__all__ = (
    "McpInspectPayload",
    "McpServersPayload",
    "McpToolSummary",
    "McpToolsPayload",
)
