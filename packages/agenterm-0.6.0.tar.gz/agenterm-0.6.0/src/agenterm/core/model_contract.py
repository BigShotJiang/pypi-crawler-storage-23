"""Canonical model-contract resolution for validation, shaping, and replay."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Literal

from openai.types.shared import Reasoning

from agenterm.constants.include import DEFAULT_RESPONSE_INCLUDE
from agenterm.core.errors import ValidationError
from agenterm.core.model_id import (
    ModelPlane,
    model_plane,
    openai_model_name,
    openai_model_requires_reasoning,
    openai_model_supports_reasoning,
    split_gateway_model_id,
)
from agenterm.core.model_optional_params import (
    OptionalModelSettingsFallback,
    OptionalSupportMatrix,
    apply_optional_model_settings_fallback,
    map_agent_run_error,
    provider_error_param,
    provider_error_param_from_exception,
    resolve_optional_model_settings,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.model_settings import ModelSettings

    from agenterm.config.model import GatewayRouteConfig, ProvidersConfig
    from agenterm.core.json_types import JSONValue

type ModelProtocol = Literal["openai_responses", "litellm_chat_completions"]
type ModelValidationSource = Literal[
    "openai_registry",
    "openai_policy_allowlist",
    "gateway_route_policy",
]
type ReasoningReplayMode = Literal[
    "openai_encrypted_only",
    "provider_native",
]
type ReportRedactionMode = Literal["sanitized_default", "forensic_raw"]

_SUPPORTED_PREFIXES: tuple[str, ...] = ("openai", "gateway")
_DEFAULT_GATEWAY_RESPONSE_INCLUDE: tuple[str, ...] = ("reasoning.encrypted_content",)


@dataclass(frozen=True)
class ResolvedModelContract:
    """Canonical contract resolved for one run target."""

    model_id: str
    plane: ModelPlane
    protocol: ModelProtocol
    route: str | None
    validation_source: ModelValidationSource
    supports_reasoning: bool
    requires_reasoning: bool
    supports_verbosity: bool
    supports_prompt_cache_retention: bool
    supports_top_logprobs: bool
    supports_store: bool
    supports_metadata: bool
    supports_response_include: bool
    supports_background: bool
    reasoning_replay_mode: ReasoningReplayMode
    report_redaction_mode: ReportRedactionMode
    default_response_include: tuple[str, ...] | None


@dataclass(frozen=True)
class ResolvedModelSettings:
    """ModelSettings plus resolved contract and shaping warnings."""

    contract: ResolvedModelContract
    model_settings: ModelSettings
    warnings: tuple[str, ...]


@dataclass(frozen=True)
class DelegateModelPreflightError:
    """Typed delegated-model preflight failure payload."""

    message: str
    details: dict[str, JSONValue]


def _json_string_list(values: tuple[str, ...] | list[str]) -> list[JSONValue]:
    return [str(item) for item in values]


def _prefix_suggestions() -> list[JSONValue]:
    return _json_string_list(list(_SUPPORTED_PREFIXES))


def _prefixed_openai_ids(values: tuple[str, ...]) -> list[str]:
    return [f"openai/{item}" for item in values]


def _route_model_ids(route: str, values: tuple[str, ...]) -> list[JSONValue]:
    return _json_string_list([f"gateway/{route}/{item}" for item in values])


def _gateway_route_or_error(
    providers: ProvidersConfig,
    *,
    model_id: str,
) -> tuple[str, GatewayRouteConfig]:
    route, _route_model = split_gateway_model_id(model_id)
    route_cfg = providers.gateway.routes.get(route)
    if route_cfg is None:
        msg = f"Unknown gateway route {route!r} for model id {model_id!r}."
        raise ValidationError(msg)
    return route, route_cfg


def resolve_model_contract(
    providers: ProvidersConfig,
    *,
    model_id: str,
) -> ResolvedModelContract:
    """Return the canonical contract for a model target."""
    plane = model_plane(model_id)
    if plane == "openai":
        supports_reasoning = openai_model_supports_reasoning(model_id)
        allow_any_model = bool(providers.openai.allow_any_model)
        validation_source: ModelValidationSource = (
            "openai_registry" if allow_any_model else "openai_policy_allowlist"
        )
        return ResolvedModelContract(
            model_id=model_id,
            plane=plane,
            protocol="openai_responses",
            route=None,
            validation_source=validation_source,
            supports_reasoning=supports_reasoning,
            requires_reasoning=openai_model_requires_reasoning(model_id),
            supports_verbosity=True,
            supports_prompt_cache_retention=True,
            supports_top_logprobs=True,
            supports_store=True,
            supports_metadata=True,
            supports_response_include=True,
            supports_background=True,
            reasoning_replay_mode="openai_encrypted_only",
            report_redaction_mode="sanitized_default",
            default_response_include=tuple(DEFAULT_RESPONSE_INCLUDE),
        )
    route, route_cfg = _gateway_route_or_error(providers, model_id=model_id)
    protocol: ModelProtocol = route_cfg.protocol
    if protocol == "openai_responses":
        include = (
            tuple(str(item) for item in route_cfg.response_include)
            if route_cfg.response_include is not None
            else _DEFAULT_GATEWAY_RESPONSE_INCLUDE
        )
        return ResolvedModelContract(
            model_id=model_id,
            plane=plane,
            protocol=protocol,
            route=route,
            validation_source="gateway_route_policy",
            supports_reasoning=True,
            requires_reasoning=False,
            supports_verbosity=True,
            supports_prompt_cache_retention=True,
            supports_top_logprobs=True,
            supports_store=True,
            supports_metadata=True,
            supports_response_include=True,
            supports_background=bool(route_cfg.supports_background),
            reasoning_replay_mode="openai_encrypted_only",
            report_redaction_mode="sanitized_default",
            default_response_include=include,
        )
    return ResolvedModelContract(
        model_id=model_id,
        plane=plane,
        protocol=protocol,
        route=route,
        validation_source="gateway_route_policy",
        supports_reasoning=True,
        requires_reasoning=False,
        supports_verbosity=False,
        supports_prompt_cache_retention=False,
        supports_top_logprobs=True,
        supports_store=False,
        supports_metadata=True,
        supports_response_include=False,
        supports_background=False,
        reasoning_replay_mode="provider_native",
        report_redaction_mode="sanitized_default",
        default_response_include=None,
    )


def delegate_model_catalog(
    providers: ProvidersConfig,
) -> dict[str, JSONValue]:
    """Return a dynamic delegated-model discovery payload."""
    openai_allowlist_prefixed = _prefixed_openai_ids(providers.openai.model_allowlist)
    route_entries: list[JSONValue] = []
    suggested_models: list[JSONValue] = [
        f"openai/{model_id}" for model_id in providers.openai.model_suggestions
    ]
    for openai_model in openai_allowlist_prefixed:
        if openai_model not in suggested_models:
            suggested_models.append(openai_model)
    for route in sorted(providers.gateway.routes):
        route_cfg = providers.gateway.routes[route]
        allowlist = _route_model_ids(route, route_cfg.model_allowlist)
        suggestions = _route_model_ids(route, route_cfg.model_suggestions)
        route_entries.append(
            {
                "route": route,
                "protocol": route_cfg.protocol,
                "allow_any_model": route_cfg.allow_any_model,
                "model_allowlist": allowlist,
                "model_suggestions": suggestions,
                "model_pattern": f"gateway/{route}/<model>",
            }
        )
        for model_id in allowlist:
            if model_id not in suggested_models:
                suggested_models.append(model_id)
        for model_id in suggestions:
            if model_id not in suggested_models:
                suggested_models.append(model_id)
    return {
        "supported_prefixes": _prefix_suggestions(),
        "known_routes": _json_string_list(sorted(providers.gateway.routes.keys())),
        "suggested_models": suggested_models,
        "openai": {
            "allow_any_model": providers.openai.allow_any_model,
            "model_allowlist": _json_string_list(openai_allowlist_prefixed),
            "model_suggestions": _json_string_list(
                [f"openai/{item}" for item in providers.openai.model_suggestions]
            ),
            "model_pattern": "openai/<model>",
        },
        "gateway_routes": route_entries,
    }


def _preflight_error_from_catalog(
    *,
    catalog: Mapping[str, JSONValue],
    message: str,
    reason: str,
    extra_details: Mapping[str, JSONValue] | None = None,
) -> DelegateModelPreflightError:
    details = dict(catalog)
    details["field"] = "model"
    details["reason"] = reason
    if extra_details is not None:
        details.update(extra_details)
    return DelegateModelPreflightError(message=message, details=details)


def _preflight_openai_model_target(
    *,
    providers: ProvidersConfig,
    model_id: str,
    catalog: Mapping[str, JSONValue],
) -> DelegateModelPreflightError | None:
    try:
        model_name = openai_model_name(model_id)
        _ = openai_model_supports_reasoning(model_id)
    except ValidationError:
        return _preflight_error_from_catalog(
            catalog=catalog,
            message="OpenAI model ids must be openai/<model>.",
            reason="invalid_openai_model_id",
        )
    if (
        providers.openai.allow_any_model
        or model_name in providers.openai.model_allowlist
    ):
        return None
    return _preflight_error_from_catalog(
        catalog=catalog,
        message="Model id is not allowed for openai policy.",
        reason="model_not_allowed",
        extra_details={
            "route": "openai",
            "allow_any_model": False,
            "model_allowlist": _json_string_list(
                _prefixed_openai_ids(providers.openai.model_allowlist)
            ),
            "model_suggestions": _json_string_list(
                [f"openai/{item}" for item in providers.openai.model_suggestions]
            ),
        },
    )


def _preflight_gateway_model_target(
    *,
    providers: ProvidersConfig,
    model_id: str,
    catalog: Mapping[str, JSONValue],
) -> DelegateModelPreflightError | None:
    try:
        route, route_model = split_gateway_model_id(model_id)
    except ValidationError:
        return _preflight_error_from_catalog(
            catalog=catalog,
            message="Gateway model ids must be gateway/<route>/<model>.",
            reason="invalid_gateway_model_id",
        )
    route_cfg = providers.gateway.routes.get(route)
    if route_cfg is None:
        return _preflight_error_from_catalog(
            catalog=catalog,
            message=f"Unknown gateway route: {route}",
            reason="unknown_gateway_route",
            extra_details={"route": route},
        )
    if route_cfg.allow_any_model or route_model in route_cfg.model_allowlist:
        return None
    suggestions = [f"gateway/{route}/{item}" for item in route_cfg.model_suggestions]
    return _preflight_error_from_catalog(
        catalog=catalog,
        message=f"Model id is not allowed for gateway route {route}.",
        reason="model_not_allowed",
        extra_details={
            "route": route,
            "allow_any_model": False,
            "model_allowlist": _json_string_list(list(route_cfg.model_allowlist)),
            "model_suggestions": _json_string_list(suggestions),
        },
    )


def preflight_delegate_model_target(
    *,
    providers: ProvidersConfig,
    model_id: str,
) -> DelegateModelPreflightError | None:
    """Return typed preflight error details for delegated model targets."""
    catalog = delegate_model_catalog(providers)
    try:
        plane = model_plane(model_id)
    except ValidationError:
        return _preflight_error_from_catalog(
            catalog=catalog,
            message="Model id prefix must be openai/ or gateway/.",
            reason="invalid_model_prefix",
        )
    if plane == "openai":
        return _preflight_openai_model_target(
            providers=providers,
            model_id=model_id,
            catalog=catalog,
        )
    return _preflight_gateway_model_target(
        providers=providers,
        model_id=model_id,
        catalog=catalog,
    )


def _drop_reasoning_summary_for_litellm(reasoning: Reasoning) -> Reasoning:
    if reasoning.summary is None:
        return reasoning
    return Reasoning(effort=reasoning.effort, summary=None)


def effective_reasoning_settings(
    *,
    providers: ProvidersConfig,
    model_id: str,
    reasoning: Reasoning | None,
) -> Reasoning | None:
    """Return validated reasoning settings for the active model id."""
    contract = resolve_model_contract(providers, model_id=model_id)
    if reasoning is None:
        if contract.requires_reasoning:
            return Reasoning(effort="low")
        return None
    if not contract.supports_reasoning:
        msg = (
            "model.reasoning is only supported for OpenAI GPT-5 models "
            "or gateway models that expose reasoning effort."
        )
        raise ValidationError(msg)
    if contract.protocol == "litellm_chat_completions":
        return _drop_reasoning_summary_for_litellm(reasoning)
    return reasoning


def validate_background_mode_for_model(
    *,
    model_id: str,
    providers: ProvidersConfig,
) -> None:
    """Raise ValidationError when model_id cannot run in background mode."""
    contract = resolve_model_contract(providers, model_id=model_id)
    if contract.plane == "openai":
        return
    if contract.protocol != "openai_responses":
        msg = (
            "Background mode is only supported for openai/<model> or "
            "gateway routes with protocol=openai_responses."
        )
        raise ValidationError(msg)
    if not contract.supports_background:
        route = contract.route or "gateway"
        msg = (
            f"Background mode is disabled for gateway route {route!r}. "
            "Set providers.gateway.routes.<route>.supports_background=true "
            "for providers that support response retrieval."
        )
        raise ValidationError(msg)


def resolve_model_settings_for_target(
    *,
    providers: ProvidersConfig,
    model_id: str,
    model_settings: ModelSettings,
    include_override: tuple[str, ...] | None = None,
) -> ResolvedModelSettings:
    """Return contract-shaped ModelSettings for a specific model target."""
    contract = resolve_model_contract(providers, model_id=model_id)
    reasoning = effective_reasoning_settings(
        providers=providers,
        model_id=model_id,
        reasoning=model_settings.reasoning,
    )
    updated = replace(model_settings, reasoning=reasoning)
    if contract.route is not None:
        route_cfg = providers.gateway.routes.get(contract.route)
        if route_cfg is not None and route_cfg.headers:
            merged = dict(route_cfg.headers)
            if updated.extra_headers:
                merged.update(
                    {
                        key: value
                        for key, value in updated.extra_headers.items()
                        if isinstance(value, str)
                    }
                )
            updated = replace(updated, extra_headers=merged)
    matrix = OptionalSupportMatrix(
        supports_prompt_cache_retention=contract.supports_prompt_cache_retention,
        supports_top_logprobs=contract.supports_top_logprobs,
        supports_verbosity=contract.supports_verbosity,
        supports_reasoning=contract.supports_reasoning,
        supports_store=contract.supports_store,
        supports_metadata=contract.supports_metadata,
        supports_response_include=contract.supports_response_include,
        default_response_include=contract.default_response_include,
    )
    optional_resolution = resolve_optional_model_settings(
        model_id=model_id,
        matrix=matrix,
        model_settings=updated,
        include_override=include_override,
    )
    return ResolvedModelSettings(
        contract=contract,
        model_settings=optional_resolution.model_settings,
        warnings=optional_resolution.warnings,
    )


__all__ = (
    "DelegateModelPreflightError",
    "ModelProtocol",
    "OptionalModelSettingsFallback",
    "ReasoningReplayMode",
    "ReportRedactionMode",
    "ResolvedModelContract",
    "ResolvedModelSettings",
    "apply_optional_model_settings_fallback",
    "delegate_model_catalog",
    "effective_reasoning_settings",
    "map_agent_run_error",
    "preflight_delegate_model_target",
    "provider_error_param",
    "provider_error_param_from_exception",
    "resolve_model_contract",
    "resolve_model_settings_for_target",
    "validate_background_mode_for_model",
)
