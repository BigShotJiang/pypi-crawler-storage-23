"""Store policy helpers shared across surfaces."""

from __future__ import annotations


def store_is_enabled(*, store: bool | None) -> bool:
    """Return True when provider-side storage is enabled."""
    return store is not False


__all__ = ("store_is_enabled",)
