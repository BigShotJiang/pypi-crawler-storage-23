"""Typed error hierarchy for agenterm."""

from __future__ import annotations

import asyncio


class AgentermError(Exception):
    """Base error for the CLI engine."""


class ConfigError(AgentermError):
    """Raised when configuration is invalid or inconsistent."""


class ValidationError(AgentermError):
    """Raised when user-provided or schema-validated values are invalid."""


class ToolArgumentsLimitError(ValidationError):
    """Raised when streamed tool-call arguments exceed configured limits."""


class UsageError(AgentermError):
    """Raised when a CLI invocation is invalid or unsupported."""


class DispatchError(AgentermError):
    """Raised when command dispatch or routing fails."""


class PipelineError(AgentermError):
    """Raised for errors occurring during pipeline execution."""


class McpConnectError(AgentermError):
    """Raised when MCP discovery or connectivity fails."""


class ToolExecutionError(AgentermError):
    """Raised when a local tool executor fails in a way that aborts the workflow."""


class SandboxBackendUnavailableError(ToolExecutionError):
    """Raised when fn:shell cannot resolve a supported sandbox backend."""

    def __init__(
        self,
        message: str,
        *,
        platform: str,
        backend: str | None,
    ) -> None:
        """Store backend-resolution context for typed tool error mapping."""
        super().__init__(message)
        self.platform = platform
        self.backend = backend


class FilesystemError(AgentermError):
    """Raised when filesystem operations fail or paths cannot be resolved."""


class DatabaseError(AgentermError):
    """Raised when local SQLite store access or schema expectations fail."""


class AuthError(AgentermError):
    """Raised when authentication is missing or invalid."""


class RateLimitError(AgentermError):
    """Raised when provider rate limits prevent a request."""


class OperationTimeoutError(AgentermError):
    """Raised when an operation exceeds a configured timeout."""


class RetriesExhaustedError(OperationTimeoutError):
    """Raised when a shared retry budget has no attempts remaining."""


class DeadlineExceededError(OperationTimeoutError):
    """Raised when a shared retry deadline is exceeded."""


class AttemptTimeoutError(OperationTimeoutError):
    """Raised when a single retry attempt exceeds its timeout."""

    def __init__(
        self,
        message: str,
        *,
        timeout_seconds: float | None,
    ) -> None:
        """Store the configured timeout for typed edge mapping."""
        super().__init__(message)
        self.timeout_seconds = timeout_seconds


class ToolArgumentsStalledError(OperationTimeoutError):
    """Raised when streamed tool-call arguments stall without making progress.

    This is distinct from an "idle" timeout: events may still be arriving, but the
    model is not producing any non-whitespace tool arguments for long enough that
    agenterm must cancel the stream to preserve boundedness.
    """

    def __init__(
        self,
        message: str,
        *,
        item_id: str,
        call_id: str | None,
        tool_name: str | None,
        timeout_seconds: float | None,
        observed_chars: int | None,
    ) -> None:
        """Initialize a stall timeout with tool-call context for recovery/backfill."""
        super().__init__(message)
        self.item_id = item_id
        self.call_id = call_id
        self.tool_name = tool_name
        self.timeout_seconds = timeout_seconds
        self.observed_chars = observed_chars


class OperationCancelledError(asyncio.CancelledError):
    """Raised when a cooperative cancellation token is triggered."""

    def __init__(self, message: str | None = None) -> None:
        """Initialize the cancellation message for cooperative aborts."""
        super().__init__(message or "Operation cancelled.")


__all__ = (
    "AgentermError",
    "AttemptTimeoutError",
    "AuthError",
    "ConfigError",
    "DatabaseError",
    "DeadlineExceededError",
    "DispatchError",
    "FilesystemError",
    "McpConnectError",
    "OperationCancelledError",
    "OperationTimeoutError",
    "PipelineError",
    "RateLimitError",
    "RetriesExhaustedError",
    "SandboxBackendUnavailableError",
    "ToolArgumentsLimitError",
    "ToolArgumentsStalledError",
    "ToolExecutionError",
    "UsageError",
    "ValidationError",
)
