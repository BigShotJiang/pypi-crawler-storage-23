"""Parsing helpers for Responses tool_choice flags."""

from __future__ import annotations

from types import MappingProxyType
from typing import TYPE_CHECKING

from agenterm.constants.tools import types_param_from_string

if TYPE_CHECKING:
    from collections.abc import Mapping

    from openai.types.responses.response_create_params import ToolChoice
    from openai.types.responses.tool_choice_function_param import (
        ToolChoiceFunctionParam,
    )

    from agenterm.core.json_types import JSONValue


def _parse_tool_choice_str(v: str) -> ToolChoice | None:
    s = v.strip()
    if not s:
        return None
    lo = s.lower()
    direct: Mapping[str, ToolChoice] = MappingProxyType(
        {
            "none": "none",
            "auto": "auto",
            "required": "required",
        },
    )
    if lo in direct:
        return direct[lo]
    if lo.startswith("type:"):
        t = s.split(":", 1)[1].strip()
        return types_param_from_string(t) if t else None
    if lo.startswith("function:"):
        name = s.split(":", 1)[1].strip()
        if name:
            out2: ToolChoiceFunctionParam = {"type": "function", "name": name}
            return out2
    return None


def _parse_tool_choice_dict(d: Mapping[str, JSONValue]) -> ToolChoice | None:
    tval = d.get("type")
    if not isinstance(tval, str):
        return None
    if tval == "function" and isinstance(d.get("name"), str):
        return {"type": "function", "name": str(d["name"])}
    return types_param_from_string(tval)


def parse_tool_choice(value: str | Mapping[str, JSONValue] | None) -> ToolChoice | None:
    """Parse a concise tool-choice into a typed ToolChoice.

    Accepted forms:
    - none | auto | required
    - type:<built_in_tool> (reserved for future built-in tools)
    - function:<NAME>
    - dict forms matching ToolChoiceTypesParam or function param are also accepted

    Args:
      value: String or mapping describing tool choice.

    Returns:
      A typed ToolChoice or None when parsing fails.

    """
    if value is None:
        return None
    if isinstance(value, str):
        return _parse_tool_choice_str(value)
    return _parse_tool_choice_dict(value)


__all__ = ("parse_tool_choice",)
