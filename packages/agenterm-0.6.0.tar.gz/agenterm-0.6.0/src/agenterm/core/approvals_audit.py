"""Approvals decision and audit log helpers.

This module centralizes approval decision semantics and the bounded audit trail
used by REPL inspection surfaces (e.g. `/last approvals`).

It intentionally mirrors the hosted MCP approval idiom:
- approvals always resolve to `approved: bool`
- `reason` is meaningful only when rejected
"""

from __future__ import annotations

import contextlib
from dataclasses import dataclass
from typing import Literal

from agenterm.core.text import shorten_line

APPROVAL_REASON_MAX_CHARS = 400

AUDIT_MAX_RECORDS = 100
AUDIT_MAX_SHELL_COMMANDS = 32
AUDIT_MAX_MCP_ARGS_CHARS = 2000
AUDIT_MAX_PATCH_DIFF_LINES = 40

type ApprovalFamily = Literal["shell", "patch", "mcp", "compress"]


def normalize_approval_reason(reason: str | None) -> str | None:
    """Normalize an operator-provided rejection reason (bounded, single string)."""
    if not isinstance(reason, str):
        return None
    cleaned = reason.strip()
    if not cleaned:
        return None
    limit = APPROVAL_REASON_MAX_CHARS
    if len(cleaned) <= limit:
        return cleaned
    if limit <= 1:
        return "…"
    return f"{cleaned[: limit - 1]}…"


@dataclass(frozen=True)
class ApprovalDecision:
    """Resolved decision for a pending approval request."""

    approved: bool
    reason: str | None = None


@dataclass(frozen=True)
class ApprovalRequestDetail:
    """Captured request details for approvals audit and rendering."""

    # shell
    cwd: str | None = None
    commands: tuple[str, ...] = ()
    description: str | None = None
    # apply_patch
    operation_type: str | None = None
    path: str | None = None
    diff_summary: str | None = None
    # hosted mcp
    server_label: str | None = None
    tool_name: str | None = None
    arguments_json: str | None = None
    # compression
    compress_action: str | None = None
    compress_message: str | None = None


@dataclass(frozen=True)
class ApprovalAuditRecord:
    """One approval request plus its latest decision (if resolved)."""

    id: str
    family: ApprovalFamily
    requested_seq: int
    detail: ApprovalRequestDetail
    decision: ApprovalDecision | None = None
    resolved_seq: int | None = None

    def last_seq(self) -> int:
        """Return the sequence number for the most recent activity on this record."""
        return (
            self.resolved_seq
            if isinstance(self.resolved_seq, int)
            else self.requested_seq
        )


class ApprovalsAuditLog:
    """Bounded in-process approvals audit trail (requested + resolved)."""

    def __init__(self, *, max_records: int) -> None:
        """Initialize an empty audit log with a bounded max size."""
        self._max_records = max(0, int(max_records))
        self._next_seq = 1
        self._by_id: dict[str, ApprovalAuditRecord] = {}
        # Oldest → newest by last activity.
        self._lru: list[str] = []

    def clear(self) -> None:
        """Drop all recorded approval audit records."""
        self._next_seq = 1
        self._by_id.clear()
        self._lru.clear()

    def snapshot(self, *, limit: int) -> tuple[ApprovalAuditRecord, ...]:
        """Return newest-first records, bounded by `limit`."""
        if self._max_records <= 0:
            return ()
        n = max(0, int(limit))
        if n <= 0 or not self._lru:
            return ()
        out: list[ApprovalAuditRecord] = []
        for ident in reversed(self._lru[-n:]):
            rec = self._by_id.get(ident)
            if rec is not None:
                out.append(rec)
        return tuple(out)

    def record_request(
        self,
        *,
        family: ApprovalFamily,
        detail: ApprovalRequestDetail,
        ident: str,
    ) -> None:
        """Record a new approval request."""
        if self._max_records <= 0:
            return
        seq = self._next_seq
        self._next_seq += 1
        record = ApprovalAuditRecord(
            id=ident,
            family=family,
            requested_seq=seq,
            detail=detail,
            decision=None,
            resolved_seq=None,
        )
        self._by_id[ident] = record
        self._touch(ident)
        self._evict_if_needed()

    def record_resolution(self, *, ident: str, decision: ApprovalDecision) -> None:
        """Record an approval decision for a previously requested approval."""
        if self._max_records <= 0:
            return
        seq = self._next_seq
        self._next_seq += 1
        existing = self._by_id.get(ident)
        if existing is None:
            if ident.startswith("patch-"):
                family: ApprovalFamily = "patch"
            elif ident.startswith("mcp-"):
                family = "mcp"
            elif ident.startswith("compress-"):
                family = "compress"
            else:
                family = "shell"
            record = ApprovalAuditRecord(
                id=ident,
                family=family,
                requested_seq=seq,
                detail=ApprovalRequestDetail(),
                decision=decision,
                resolved_seq=seq,
            )
        else:
            record = ApprovalAuditRecord(
                id=existing.id,
                family=existing.family,
                requested_seq=existing.requested_seq,
                detail=existing.detail,
                decision=decision,
                resolved_seq=seq,
            )
        self._by_id[ident] = record
        self._touch(ident)
        self._evict_if_needed()

    def _touch(self, ident: str) -> None:
        if self._max_records <= 0:
            return
        with contextlib.suppress(ValueError):
            self._lru.remove(ident)
        self._lru.append(ident)

    def _evict_if_needed(self) -> None:
        if self._max_records <= 0:
            self._by_id.clear()
            self._lru.clear()
            return
        while len(self._lru) > self._max_records:
            ident = self._lru.pop(0)
            self._by_id.pop(ident, None)


__all__ = (
    "APPROVAL_REASON_MAX_CHARS",
    "AUDIT_MAX_MCP_ARGS_CHARS",
    "AUDIT_MAX_PATCH_DIFF_LINES",
    "AUDIT_MAX_RECORDS",
    "AUDIT_MAX_SHELL_COMMANDS",
    "ApprovalAuditRecord",
    "ApprovalDecision",
    "ApprovalFamily",
    "ApprovalRequestDetail",
    "ApprovalsAuditLog",
    "normalize_approval_reason",
    "shorten_line",
)
