"""Config payloads for CLI JSON envelopes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class ConfigPathPayload:
    """Payload for `agenterm config path` in JSON mode."""

    config_path: str | None
    location: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "config_path": self.config_path,
            "location": self.location,
        }


@dataclass(frozen=True)
class ConfigShowPayload:
    """Payload for `agenterm config show` in JSON mode (summary fields only)."""

    config_path: str | None
    agent_model: str
    agent_max_turns: int
    agent_name: str
    agent_path: str | None
    agent_source: str | None
    model_store: bool
    model_context_window: int | None
    model_verbosity: str | None
    model_temperature: float | None
    model_reasoning_effort: str | None
    model_reasoning_summary: str | None
    run_background: bool
    run_live: bool
    run_json_output: bool
    repl_approvals_mode: str
    repl_theme: str
    repl_color_depth: str
    repl_editing_mode: str
    repl_mouse: bool
    repl_completion: str
    repl_stream_mode: str
    repl_verbosity: str
    mcp_servers: tuple[Mapping[str, JSONValue], ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        mcp_servers: list[JSONValue] = [dict(server) for server in self.mcp_servers]
        return {
            "config_path": self.config_path,
            "agent": {
                "model": self.agent_model,
                "max_turns": self.agent_max_turns,
                "name": self.agent_name,
                "path": self.agent_path,
                "source": self.agent_source,
            },
            "model": {
                "store": self.model_store,
                "context_window": self.model_context_window,
                "verbosity": self.model_verbosity,
                "temperature": self.model_temperature,
                "reasoning_effort": self.model_reasoning_effort,
                "reasoning_summary": self.model_reasoning_summary,
            },
            "run": {
                "background": self.run_background,
                "live": self.run_live,
                "json_output": self.run_json_output,
            },
            "repl": {
                "approvals_mode": self.repl_approvals_mode,
                "theme": self.repl_theme,
                "color_depth": self.repl_color_depth,
                "editing_mode": self.repl_editing_mode,
                "mouse": self.repl_mouse,
                "completion": self.repl_completion,
                "stream": self.repl_stream_mode,
                "verbosity": self.repl_verbosity,
            },
            "mcp_servers": mcp_servers,
        }


@dataclass(frozen=True)
class ConfigSavePayload:
    """Payload for `agenterm config save` in JSON mode."""

    config_path: str
    scope: str
    source: str
    overwritten: bool

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "config_path": self.config_path,
            "scope": self.scope,
            "source": self.source,
            "overwritten": self.overwritten,
        }


__all__ = ("ConfigPathPayload", "ConfigSavePayload", "ConfigShowPayload")
