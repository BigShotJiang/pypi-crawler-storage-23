"""Unified retry helpers (bounded exponential backoff + jitter)."""

from __future__ import annotations

import asyncio
import secrets
import time
from contextlib import suppress
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from agenterm.core.errors import (
    AttemptTimeoutError,
    DeadlineExceededError,
    OperationCancelledError,
    RetriesExhaustedError,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from agenterm.core.cancellation import CancelToken

_RANDOM = secrets.SystemRandom()


@dataclass(frozen=True)
class RetryPolicy:
    """Retry policy parameters shared across surfaces."""

    max_retries: int
    base_backoff_seconds: float
    max_backoff_seconds: float
    jitter_ratio: float
    retry_after_max_seconds: float | None = None


@dataclass(frozen=True)
class RetryDecision:
    """Classification result for a retryable error."""

    retry: bool
    label: str | None = None
    retry_after_seconds: float | None = None


@dataclass(frozen=True)
class RetryNotice:
    """Retry metadata surfaced to callers."""

    label: str
    attempt: int
    max_retries: int
    delay_seconds: float
    retry_after_seconds: float | None


@dataclass(frozen=True)
class RetryBudgetSummary:
    """Run-level summary emitted from a retry budget."""

    attempts_used: int
    total_backoff_seconds: float


@dataclass
class RetryBudget:
    """Mutable retry budget shared across retry-like loops in one run."""

    max_total_attempts: int
    deadline_seconds: float | None
    attempt_timeout_seconds: float | None
    _started_at_monotonic: float = field(default_factory=time.monotonic, init=False)
    _attempts_used: int = field(default=0, init=False)
    _total_backoff_seconds: float = field(default=0.0, init=False)

    def _deadline_remaining_seconds(self) -> float | None:
        deadline = self.deadline_seconds
        if deadline is None:
            return None
        elapsed = time.monotonic() - self._started_at_monotonic
        return deadline - elapsed

    def start_attempt(self) -> float | None:
        """Consume one attempt and return the effective attempt timeout."""
        if self._attempts_used >= self.max_total_attempts:
            msg = "Retry budget exhausted."
            raise RetriesExhaustedError(msg)
        remaining = self._deadline_remaining_seconds()
        if remaining is not None and remaining <= 0:
            msg = "Retry deadline exceeded."
            raise DeadlineExceededError(msg)
        self._attempts_used += 1
        attempt_timeout = self.attempt_timeout_seconds
        if remaining is not None:
            attempt_timeout = (
                remaining
                if attempt_timeout is None
                else min(attempt_timeout, remaining)
            )
        if attempt_timeout is not None and attempt_timeout <= 0:
            msg = "Retry deadline exceeded before attempt execution."
            raise DeadlineExceededError(msg)
        return attempt_timeout

    def assert_can_delay(self, delay_seconds: float) -> None:
        """Raise if sleeping `delay_seconds` would exceed the retry deadline."""
        remaining = self._deadline_remaining_seconds()
        if remaining is None:
            return
        if delay_seconds <= remaining:
            return
        msg = "Retry deadline exceeded before next attempt."
        raise DeadlineExceededError(msg)

    def record_backoff(self, delay_seconds: float) -> None:
        """Record applied retry backoff delay for run-level summaries."""
        self._total_backoff_seconds += max(0.0, float(delay_seconds))

    def snapshot(self) -> RetryBudgetSummary:
        """Return a frozen summary for postprocess output."""
        return RetryBudgetSummary(
            attempts_used=self._attempts_used,
            total_backoff_seconds=self._total_backoff_seconds,
        )


def retry_delay_seconds(
    policy: RetryPolicy,
    *,
    attempt: int,
    retry_after_seconds: float | None,
    rand: Callable[[], float] | None = None,
) -> float:
    """Return the delay for the next retry attempt."""
    if (
        retry_after_seconds is not None
        and policy.retry_after_max_seconds is not None
        and 0 < retry_after_seconds <= policy.retry_after_max_seconds
    ):
        return max(0.0, retry_after_seconds)
    base = min(
        policy.base_backoff_seconds * (2**attempt),
        policy.max_backoff_seconds,
    )
    jitter = policy.jitter_ratio
    jitter_factor = 1.0 - (jitter * (rand() if rand is not None else _RANDOM.random()))
    return max(0.0, base * jitter_factor)


async def cancel_aware_sleep(
    delay_seconds: float,
    *,
    cancel_token: CancelToken | None,
    sleep: Callable[[float], Awaitable[None]] | None = None,
) -> None:
    """Sleep while honoring cooperative cancellation when a token is present."""
    sleeper = sleep or asyncio.sleep
    delay = max(0.0, float(delay_seconds))
    if cancel_token is None:
        await sleeper(delay)
        return
    cancel_token.raise_if_cancelled()
    if delay == 0:
        return
    sleep_task: asyncio.Task[None]
    if sleep is None:
        sleep_task = asyncio.create_task(asyncio.sleep(delay))
    else:

        async def _sleep_once() -> None:
            await sleep(delay)

        sleep_task = asyncio.create_task(_sleep_once())
    cancel_task: asyncio.Task[None] = asyncio.create_task(cancel_token.wait())
    done, _pending = await asyncio.wait(
        {sleep_task, cancel_task},
        return_when=asyncio.FIRST_COMPLETED,
    )
    if cancel_task in done:
        sleep_task.cancel()
        with suppress(asyncio.CancelledError):
            await sleep_task
        with suppress(asyncio.CancelledError):
            await cancel_task
        msg = "Retry sleep cancelled."
        raise OperationCancelledError(msg)
    cancel_task.cancel()
    with suppress(asyncio.CancelledError):
        await cancel_task
    await sleep_task


def _retry_permitted(
    *,
    attempt: int,
    max_attempts: int,
    decision: RetryDecision,
) -> bool:
    return decision.retry and attempt < max_attempts - 1


def _retry_notice(
    *,
    exc: Exception,
    decision: RetryDecision,
    attempt: int,
    max_retries: int,
    delay_seconds: float,
) -> RetryNotice:
    label = decision.label or exc.__class__.__name__
    return RetryNotice(
        label=label,
        attempt=attempt,
        max_retries=max_retries,
        delay_seconds=delay_seconds,
        retry_after_seconds=decision.retry_after_seconds,
    )


async def _apply_retry_backoff(
    *,
    exc: Exception,
    decision: RetryDecision,
    attempt: int,
    policy: RetryPolicy,
    max_retries: int,
    on_retry: Callable[[RetryNotice], None] | None,
    budget: RetryBudget | None,
    cancel_token: CancelToken | None,
    sleep: Callable[[float], Awaitable[None]],
) -> None:
    delay = retry_delay_seconds(
        policy,
        attempt=attempt,
        retry_after_seconds=decision.retry_after_seconds,
    )
    if budget is not None:
        budget.assert_can_delay(delay)
        budget.record_backoff(delay)
    if on_retry is not None:
        on_retry(
            _retry_notice(
                exc=exc,
                decision=decision,
                attempt=attempt,
                max_retries=max_retries,
                delay_seconds=delay,
            )
        )
    await cancel_aware_sleep(
        delay,
        cancel_token=cancel_token,
        sleep=sleep,
    )


async def _run_with_attempt_timeout[T](
    func: Callable[[], Awaitable[T]],
    *,
    attempt_timeout: float | None,
) -> T:
    if attempt_timeout is None:
        return await func()
    async with asyncio.timeout(attempt_timeout):
        return await func()


def _timeout_label(timeout_seconds: float | None) -> str:
    if isinstance(timeout_seconds, float):
        return f"{timeout_seconds:.2f}s"
    return "configured timeout"


async def retry_async[T](
    func: Callable[[], Awaitable[T]],
    *,
    policy: RetryPolicy,
    retry_on: tuple[type[Exception], ...],
    classify: Callable[[Exception], RetryDecision],
    on_retry: Callable[[RetryNotice], None] | None = None,
    sleep: Callable[[float], Awaitable[None]] | None = None,
    budget: RetryBudget | None = None,
    cancel_token: CancelToken | None = None,
) -> T:
    """Execute func with retries based on classification."""
    sleeper = sleep or asyncio.sleep
    if not retry_on:
        msg = "retry_on must include at least one exception type"
        raise ValueError(msg)
    attempts = max(0, int(policy.max_retries)) + 1
    max_retries = attempts - 1
    last_exc: Exception | None = None
    for attempt in range(attempts):
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        attempt_timeout = budget.start_attempt() if budget is not None else None
        try:
            return await _run_with_attempt_timeout(
                func,
                attempt_timeout=attempt_timeout,
            )
        except TimeoutError as exc:
            retriable_exc: Exception = AttemptTimeoutError(
                f"Retry attempt timed out after {_timeout_label(attempt_timeout)}.",
                timeout_seconds=attempt_timeout,
            )
            last_exc = retriable_exc
            decision = classify(retriable_exc)
            if not _retry_permitted(
                attempt=attempt,
                max_attempts=attempts,
                decision=decision,
            ):
                raise retriable_exc from exc
            await _apply_retry_backoff(
                exc=retriable_exc,
                decision=decision,
                attempt=attempt,
                policy=policy,
                max_retries=max_retries,
                on_retry=on_retry,
                budget=budget,
                cancel_token=cancel_token,
                sleep=sleeper,
            )
        except retry_on as exc:
            last_exc = exc
            decision = classify(exc)
            if not _retry_permitted(
                attempt=attempt,
                max_attempts=attempts,
                decision=decision,
            ):
                raise
            await _apply_retry_backoff(
                exc=exc,
                decision=decision,
                attempt=attempt,
                policy=policy,
                max_retries=max_retries,
                on_retry=on_retry,
                budget=budget,
                cancel_token=cancel_token,
                sleep=sleeper,
            )
    msg = "retry loop exited without returning"
    raise RuntimeError(msg) from last_exc


__all__ = (
    "RetryBudget",
    "RetryBudgetSummary",
    "RetryDecision",
    "RetryNotice",
    "RetryPolicy",
    "cancel_aware_sleep",
    "retry_async",
    "retry_delay_seconds",
)
