"""Rate-limit header helpers shared by retry and error reporting."""

from __future__ import annotations

import email.utils
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping


def parse_retry_after_seconds(headers: Mapping[str, str] | None) -> float | None:
    """Return retry-after seconds parsed from headers."""
    if headers is None:
        return None
    try:
        retry_ms = headers.get("retry-after-ms")
        if retry_ms is not None:
            return float(retry_ms) / 1000.0
    except (TypeError, ValueError):
        pass
    retry_after = headers.get("retry-after")
    try:
        return float(retry_after) if retry_after is not None else None
    except (TypeError, ValueError):
        pass
    retry_date = email.utils.parsedate_tz(retry_after)
    if retry_date is None:
        return None
    return float(email.utils.mktime_tz(retry_date) - time.time())


__all__ = ("parse_retry_after_seconds",)
