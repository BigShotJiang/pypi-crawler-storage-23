"""Shared state structures for CLI sessions and workflows."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Literal

from agenterm.core.approvals import ApprovalsContext
from agenterm.core.tool_selection import ToolSelection

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

    from agenterm.config.model import AppConfig
    from agenterm.core.choices.repl import (
        ReplDiffsMode,
        ReplReasoningMode,
        ReplStreamMode,
        ReplVerbosity,
    )
    from agenterm.core.choices.repl_ui import (
        ReplColorDepth,
        ReplCompletionMode,
        ReplEditingMode,
        ReplTheme,
    )
    from agenterm.core.toolspec import ToolSpec

# Canonical session types for the engine (moved from engine/state.py)

type McpDiscoveryStatus = Literal["unknown", "ok", "error"]


@dataclass(frozen=True)
class SessionUiState:
    """UI-only toggles and REPL rendering preferences."""

    render_markdown: bool = False
    verbosity: ReplVerbosity = "normal"
    stream_mode: ReplStreamMode = "final"
    reasoning_mode: ReplReasoningMode = "summary"
    reasoning_summary_max_chars: int = 0
    diffs_mode: ReplDiffsMode = "summary"
    theme: ReplTheme = "dark"
    color_depth: ReplColorDepth = "auto"
    editing_mode: ReplEditingMode = "vi"
    mouse: bool = True
    completion: ReplCompletionMode = "full"


@dataclass(frozen=True)
class SessionMcpState:
    """MCP discovery state and refresh posture."""

    refresh_pending: bool = False
    discovery_status: McpDiscoveryStatus = "unknown"
    discovery_error: str | None = None
    tool_names: tuple[str, ...] = ()


@dataclass(frozen=True)
class SessionToolsState:
    """Tool selection state and resolved catalog metadata."""

    enabled: bool = True
    tools_map: Mapping[str, ToolSpec] | None = None
    bundles_map: Mapping[str, list[str]] | None = None
    default_bundles: list[str] | None = None
    selection: ToolSelection = field(default_factory=ToolSelection)
    include_base: tuple[str, ...] = ()
    startup_selection: ToolSelection = field(default_factory=ToolSelection)


@dataclass(frozen=True)
class SessionPromptState:
    """Prompt anchors shared across runs."""

    last_user_prompt: str | None = None


@dataclass(frozen=True)
class SessionAttachmentsState:
    """Staged/last-used attachments for upcoming runs."""

    pending: tuple[str, ...] = ()
    last_used: tuple[str, ...] = ()
    next_send_use_last: bool = False


@dataclass(frozen=True)
class SessionCachesState:
    """Caches for completion lists and quick lookups."""

    session_ids: tuple[str, ...] = ()
    branch_ids: tuple[str, ...] = ()
    artifact_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class SessionState:
    """Immutable interactive/one-shot session state.

    Keeps configuration and ephemeral state small and explicit to help other
    LLMs extend behaviors safely.
    """

    cfg: AppConfig
    session_id: str | None = None
    branch_id: str | None = None
    config_path: Path | None = None
    ui: SessionUiState = field(default_factory=SessionUiState)
    mcp: SessionMcpState = field(default_factory=SessionMcpState)
    tools: SessionToolsState = field(default_factory=SessionToolsState)
    prompt: SessionPromptState = field(default_factory=SessionPromptState)
    attachments: SessionAttachmentsState = field(
        default_factory=SessionAttachmentsState,
    )
    caches: SessionCachesState = field(default_factory=SessionCachesState)
    approvals: ApprovalsContext = field(default_factory=ApprovalsContext)

    def with_cfg(self, cfg: AppConfig) -> SessionState:
        """Return a new state with an updated AppConfig."""
        before = tuple(self.cfg.mcp.servers or ())
        after = tuple(cfg.mcp.servers or ())
        if before != after:
            # MCP discovery is tied to the selected servers. When the set
            # changes, drop cached discovery output and require a refresh.
            return replace(
                self,
                cfg=cfg,
                mcp=replace(
                    self.mcp,
                    refresh_pending=False,
                    tool_names=(),
                    discovery_status="unknown",
                    discovery_error=None,
                ),
            )
        return replace(self, cfg=cfg)

    def with_prompt(self, prompt: str | None) -> SessionState:
        """Return a state with the last user prompt updated."""
        return replace(
            self,
            prompt=replace(self.prompt, last_user_prompt=prompt),
        )

    def with_tools_enabled(self, *, on: bool) -> SessionState:
        """Toggle tools-enabled flag immutably."""
        return replace(self, tools=replace(self.tools, enabled=on))

    def with_attachments(self, items: tuple[str, ...]) -> SessionState:
        """Return a new state with pending attachments staged for next send."""
        return replace(self, attachments=replace(self.attachments, pending=items))

    def with_session_id_cache(self, items: tuple[str, ...]) -> SessionState:
        """Return a state with updated cached session ids for completions."""
        return replace(self, caches=replace(self.caches, session_ids=items))

    def with_branch_id_cache(self, items: tuple[str, ...]) -> SessionState:
        """Return a state with updated cached branch ids for completions."""
        return replace(self, caches=replace(self.caches, branch_ids=items))

    def with_artifact_id_cache(self, items: tuple[str, ...]) -> SessionState:
        """Return a state with updated cached artifact ids for completions."""
        return replace(self, caches=replace(self.caches, artifact_ids=items))

    def with_next_send_use_last(self, *, on: bool) -> SessionState:
        """Toggle reuse of last attachments for the next send."""
        return replace(
            self,
            attachments=replace(self.attachments, next_send_use_last=on),
        )


__all__ = (
    "McpDiscoveryStatus",
    "SessionAttachmentsState",
    "SessionCachesState",
    "SessionMcpState",
    "SessionPromptState",
    "SessionState",
    "SessionToolsState",
    "SessionUiState",
)
