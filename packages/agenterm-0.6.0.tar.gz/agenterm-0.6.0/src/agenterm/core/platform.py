"""Platform feature helpers for agenterm.

This module centralizes platform checks so tool availability can be made
consistent across:
- tool spec construction (selection/UI), and
- tool building (agent runtime).
"""

from __future__ import annotations

import sys


def is_macos() -> bool:
    """Return True when running on macOS (darwin)."""
    return sys.platform == "darwin"


def is_linux() -> bool:
    """Return True when running on Linux."""
    return sys.platform.startswith("linux")


def supports_shell_sandbox_platform() -> bool:
    """Return True when a built-in shell sandbox backend exists for this platform."""
    return is_macos() or is_linux()


__all__ = ("is_linux", "is_macos", "supports_shell_sandbox_platform")
