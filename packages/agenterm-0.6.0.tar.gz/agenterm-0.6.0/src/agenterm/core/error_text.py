"""Shared helpers for bounding error text."""

from __future__ import annotations

_FALLBACK_ERROR_MESSAGE_MAX_CHARS = 200


def bounded_exception_message(exc: Exception) -> str:
    """Return a trimmed exception message suitable for user display."""
    msg = str(exc).strip()
    if not msg:
        return ""
    if len(msg) <= _FALLBACK_ERROR_MESSAGE_MAX_CHARS:
        return msg
    trimmed = msg[: _FALLBACK_ERROR_MESSAGE_MAX_CHARS - 3].rstrip()
    return f"{trimmed}..."


def bounded_text(text: str) -> str:
    """Return trimmed text suitable for user display."""
    if len(text) <= _FALLBACK_ERROR_MESSAGE_MAX_CHARS:
        return text
    trimmed = text[: _FALLBACK_ERROR_MESSAGE_MAX_CHARS - 3].rstrip()
    return f"{trimmed}..."


__all__ = ("bounded_exception_message", "bounded_text")
