"""Session and branch payloads for CLI JSON envelopes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class BranchMetaPayload:
    """Branch metadata payload for JSON output."""

    branch_id: str
    kind: str
    title: str | None
    pinned: bool
    created_reason: str | None
    parent_branch_id: str | None
    fork_run_number: int | None
    agent_name: str
    agent_path: str | None
    agent_sha256: str | None
    store_enabled: bool
    last_response_id: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "branch_id": self.branch_id,
            "kind": self.kind,
            "title": self.title,
            "pinned": self.pinned,
            "created_reason": self.created_reason,
            "parent_branch_id": self.parent_branch_id,
            "fork_run_number": self.fork_run_number,
            "agent_name": self.agent_name,
            "agent_path": self.agent_path,
            "agent_sha256": self.agent_sha256,
            "store_enabled": self.store_enabled,
            "last_response_id": self.last_response_id,
        }


@dataclass(frozen=True)
class BranchSummaryPayload:
    """Summary row for `agenterm branch list` in JSON mode."""

    branch_id: str
    message_count: int
    user_turns: int
    is_current: bool
    created_at: str | None
    last_message_role: str | None
    last_message_snippet: str | None
    meta: BranchMetaPayload | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        meta_json: JSONValue = self.meta.to_json() if self.meta is not None else None
        return {
            "branch_id": self.branch_id,
            "message_count": self.message_count,
            "user_turns": self.user_turns,
            "is_current": self.is_current,
            "created_at": self.created_at,
            "last_message_role": self.last_message_role,
            "last_message_snippet": self.last_message_snippet,
            "meta": meta_json,
        }


@dataclass(frozen=True)
class BranchListPayload:
    """Payload for `agenterm branch list` in JSON mode."""

    session_id: str
    head_branch_id: str
    branches: tuple[BranchSummaryPayload, ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "session_id": self.session_id,
            "head_branch_id": self.head_branch_id,
            "branches": [branch.to_json() for branch in self.branches],
        }


@dataclass(frozen=True)
class BranchUsePayload:
    """Payload for branch switching/creation commands."""

    session_id: str
    branch_id: str
    head_branch_id: str
    branch: BranchMetaPayload

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "head_branch_id": self.head_branch_id,
            "branch": self.branch.to_json(),
        }


@dataclass(frozen=True)
class BranchDeletePayload:
    """Payload for branch deletion."""

    session_id: str
    branch_id: str
    deleted: bool
    head_branch_id: str

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "deleted": self.deleted,
            "head_branch_id": self.head_branch_id,
        }


@dataclass(frozen=True)
class SessionSummaryPayload:
    """Summary row for `agenterm session list` in JSON mode."""

    session_id: str
    kind: str
    model: str
    head_branch_id: str
    store_enabled: bool
    last_response_id: str | None
    last_message_role: str | None
    last_message_snippet: str | None
    created_at: str | None
    updated_at: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "session_id": self.session_id,
            "kind": self.kind,
            "model": self.model,
            "head_branch_id": self.head_branch_id,
            "store_enabled": self.store_enabled,
            "last_response_id": self.last_response_id,
            "last_message_role": self.last_message_role,
            "last_message_snippet": self.last_message_snippet,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


@dataclass(frozen=True)
class SessionListPayload:
    """Payload for `agenterm session list` in JSON mode."""

    sessions: tuple[SessionSummaryPayload, ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        sessions: list[JSONValue] = [session.to_json() for session in self.sessions]
        return {"sessions": sessions}


@dataclass(frozen=True)
class SessionMetadataPayload:
    """Payload for `agenterm session show` in JSON mode."""

    session_id: str
    kind: str
    cwd: str
    config_path: str | None
    model: str
    tools_enabled: bool
    trace_id: str | None
    group_id: str | None
    head_branch_id: str
    head_branch: BranchMetaPayload
    created_at: str | None
    updated_at: str | None
    usage_total: Mapping[str, int] | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        if self.usage_total is None:
            usage_total_json: JSONValue = None
        else:
            usage_total_json = dict(self.usage_total)
        return {
            "session_id": self.session_id,
            "kind": self.kind,
            "cwd": self.cwd,
            "config_path": self.config_path,
            "model": self.model,
            "tools_enabled": self.tools_enabled,
            "trace_id": self.trace_id,
            "group_id": self.group_id,
            "head_branch_id": self.head_branch_id,
            "head_branch": self.head_branch.to_json(),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "usage_total": usage_total_json,
        }


@dataclass(frozen=True)
class SessionDeletePayload:
    """Payload for `agenterm session delete` in JSON mode."""

    session_id: str
    deleted: bool

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "session_id": self.session_id,
            "deleted": self.deleted,
        }


@dataclass(frozen=True)
class RunSummaryPayload:
    """Summary row for `agenterm session runs` in JSON mode."""

    run_number: int
    status: str | None
    response_id: str | None
    trace_id: str | None
    started_at: str | None
    updated_at: str | None
    branch_turn_start: int | None
    branch_turn_end: int | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "run_number": self.run_number,
            "status": self.status,
            "response_id": self.response_id,
            "trace_id": self.trace_id,
            "started_at": self.started_at,
            "updated_at": self.updated_at,
            "branch_turn_start": self.branch_turn_start,
            "branch_turn_end": self.branch_turn_end,
        }


@dataclass(frozen=True)
class SessionRunsPayload:
    """Payload for `agenterm session runs` in JSON mode."""

    session_id: str
    branch_id: str
    runs: tuple[RunSummaryPayload, ...]
    usage_by_run: Mapping[str, Mapping[str, int]]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        usage_by_run: dict[str, JSONValue] = {}
        for run_id, usage in self.usage_by_run.items():
            usage_json: dict[str, JSONValue] = {}
            usage_json.update(usage)
            usage_by_run[run_id] = dict(usage_json)
        return {
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "runs": [run.to_json() for run in self.runs],
            "usage_by_run": dict(usage_by_run),
        }


__all__ = (
    "BranchDeletePayload",
    "BranchListPayload",
    "BranchMetaPayload",
    "BranchSummaryPayload",
    "BranchUsePayload",
    "RunSummaryPayload",
    "SessionDeletePayload",
    "SessionListPayload",
    "SessionMetadataPayload",
    "SessionRunsPayload",
    "SessionSummaryPayload",
)
