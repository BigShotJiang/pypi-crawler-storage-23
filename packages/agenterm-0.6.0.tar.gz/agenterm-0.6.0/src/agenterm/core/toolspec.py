"""Typed tool specification used across selection and adapters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Final, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.config.model import McpServerConfig
    from agenterm.core.choices.tools import SearchContextSize
    from agenterm.core.json_types import JSONValue


# Execution plane for a tool (where it runs).
#
# - hosted: provider-hosted execution (compatible with --background mode)
# - client: local harness execution (requires the agenterm process)
ExecutionPlane = Literal["hosted", "client"]

ToolKey = str

FN_PREFIX: Final[str] = "fn:"
FN_USER_PREFIX: Final[str] = "fn:user:"
HOSTED_OPENAI_PREFIX: Final[str] = "hosted:openai:"
HOSTED_MCP_PREFIX: Final[str] = "hosted:mcp:"
MCP_SERVER_PREFIX: Final[str] = "mcp:"


def make_fn_key(name: str) -> ToolKey:
    """Return a built-in FunctionTool key (fn:<name>)."""
    return f"{FN_PREFIX}{name}"


def make_user_fn_key(name: str) -> ToolKey:
    """Return a user FunctionTool key (fn:user:<name>)."""
    return f"{FN_USER_PREFIX}{name}"


def make_hosted_openai_key(name: str) -> ToolKey:
    """Return an OpenAI hosted tool key (hosted:openai:<tool>)."""
    return f"{HOSTED_OPENAI_PREFIX}{name}"


def make_hosted_mcp_key(name: str) -> ToolKey:
    """Return an OpenAI hosted MCP connector key (hosted:mcp:<connector>)."""
    return f"{HOSTED_MCP_PREFIX}{name}"


def make_mcp_server_key(server_key: str) -> ToolKey:
    """Return a client MCP server key (mcp:<server_key>)."""
    return f"{MCP_SERVER_PREFIX}{server_key}"


def is_fn_key(key: str) -> bool:
    """Return True when key is a built-in FunctionTool key."""
    return key.startswith(FN_PREFIX) and not key.startswith(FN_USER_PREFIX)


def is_user_fn_key(key: str) -> bool:
    """Return True when key is a user FunctionTool key."""
    return key.startswith(FN_USER_PREFIX)


def is_hosted_openai_key(key: str) -> bool:
    """Return True when key is an OpenAI hosted tool key."""
    return key.startswith(HOSTED_OPENAI_PREFIX)


def is_hosted_mcp_key(key: str) -> bool:
    """Return True when key is a hosted MCP connector key."""
    return key.startswith(HOSTED_MCP_PREFIX)


def is_mcp_server_key(key: str) -> bool:
    """Return True when key is a client MCP server key."""
    return key.startswith(MCP_SERVER_PREFIX)


@dataclass(frozen=True)
class ToolSpec:
    """Normalized representation of a selectable tool.

    Tools are classified by execution plane:
    - hosted: Runs on provider infrastructure
      (file_search, web_search, image_generation, mcp_connector)
    - client: Runs in the local harness
      (shell, apply_patch, function tools, MCP servers)
    """

    type: str
    # Tool key (e.g., "fn:shell", "hosted:openai:file_search", "mcp:files")
    key: ToolKey
    # Execution plane
    plane: ExecutionPlane
    # Whether this tool is considered dangerous and requires explicit opt-in
    # when running in non-interactive contexts. Defaults are policy-driven,
    # then overridden by config (tools.dangerous.add/remove).
    dangerous: bool = False
    # Whether this tool is safe to execute when the client is in background
    # mode (server-side execution only).
    hosted_only: bool = False
    # function
    name: str | None = None
    parameters: Mapping[str, JSONValue] | None = None
    description: str | None = None
    # file_search
    vector_store_ids: tuple[str, ...] | None = None
    # image_generation
    model: str | None = None
    # web_search
    search_context_size: SearchContextSize | None = None
    user_location: Mapping[str, JSONValue] | None = None
    # mcp_server
    mcp_server: McpServerConfig | None = None


__all__ = (
    "FN_PREFIX",
    "FN_USER_PREFIX",
    "HOSTED_MCP_PREFIX",
    "HOSTED_OPENAI_PREFIX",
    "MCP_SERVER_PREFIX",
    "ExecutionPlane",
    "ToolKey",
    "ToolSpec",
    "is_fn_key",
    "is_hosted_mcp_key",
    "is_hosted_openai_key",
    "is_mcp_server_key",
    "is_user_fn_key",
    "make_fn_key",
    "make_hosted_mcp_key",
    "make_hosted_openai_key",
    "make_mcp_server_key",
    "make_user_fn_key",
)
