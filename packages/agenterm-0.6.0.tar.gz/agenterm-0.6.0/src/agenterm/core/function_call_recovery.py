"""Recover missing function-call outputs in replayed input histories.

agenterm treats local session/store history as the continuity source of truth.
When replayed items include an orphan `function_call` (no matching
`function_call_output`), provider requests fail validation. This module repairs
those histories by appending deterministic synthetic tool outputs.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.response_items import normalize_input_item_json
from agenterm.core.tool_output_envelope import ToolOutputEnvelope, ToolOutputError

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.items import TResponseInputItem

    from agenterm.core.json_types import JSONValue


_MISSING_OUTPUT_KIND = "recovered_missing_tool_output"


def _function_call_output_ids(
    items: Sequence[TResponseInputItem],
) -> set[str]:
    call_ids: set[str] = set()
    for item in items:
        item_type = item.get("type")
        if item_type != "function_call_output":
            continue
        call_id = item.get("call_id")
        if isinstance(call_id, str) and call_id:
            call_ids.add(call_id)
    return call_ids


def _tool_name_for_call(item: TResponseInputItem) -> str:
    value = item.get("name")
    if isinstance(value, str) and value:
        return value
    return "unknown_function"


def _synthetic_function_output(
    *,
    call_id: str,
    tool_name: str,
    source: str,
) -> dict[str, JSONValue]:
    error = ToolOutputError(
        kind=_MISSING_OUTPUT_KIND,
        message=(
            "Recovered missing function_call_output from local history; "
            "tool was not executed."
        ),
        details={
            "call_id": call_id,
            "tool": tool_name,
            "source": source,
        },
    )
    envelope = ToolOutputEnvelope(
        tool=tool_name,
        ok=False,
        error=error,
    )
    return {
        "type": "function_call_output",
        "call_id": call_id,
        "output": envelope.to_json_string(),
    }


def recover_orphan_function_call_outputs(
    items: Sequence[TResponseInputItem],
    *,
    source: str,
) -> list[TResponseInputItem]:
    """Return input items with synthetic outputs for orphan function calls.

    A function call is considered orphaned when:
    - `type == "function_call"`,
    - it has a non-empty `call_id`, and
    - no `function_call_output` item in the payload has the same `call_id`.
    """
    completed = _function_call_output_ids(items)
    recovered: set[str] = set()
    repaired: list[TResponseInputItem] = []
    for item in items:
        repaired.append(item)
        item_type = item.get("type")
        if item_type != "function_call":
            continue
        call_id = item.get("call_id")
        if not isinstance(call_id, str) or not call_id:
            continue
        if call_id in completed or call_id in recovered:
            continue
        tool_name = _tool_name_for_call(item)
        repaired.append(
            normalize_input_item_json(
                _synthetic_function_output(
                    call_id=call_id,
                    tool_name=tool_name,
                    source=source,
                ),
                context="function_call_recovery.synthetic_output",
            )
        )
        recovered.add(call_id)
        completed.add(call_id)
    return repaired


__all__ = ("recover_orphan_function_call_outputs",)
