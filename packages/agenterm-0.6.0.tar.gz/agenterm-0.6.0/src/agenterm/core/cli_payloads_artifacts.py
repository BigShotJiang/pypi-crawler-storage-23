"""Artifact payloads for CLI JSON envelopes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class ArtifactSummaryPayload:
    """Summary row for `agenterm artifacts list` in JSON mode."""

    artifact_id: str
    kind: str
    mime: str
    path: str
    size_bytes: int
    created_at: str | None
    source_type: str
    source_id: str
    session_id: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "artifact_id": self.artifact_id,
            "kind": self.kind,
            "mime": self.mime,
            "path": self.path,
            "size_bytes": self.size_bytes,
            "created_at": self.created_at,
            "source_type": self.source_type,
            "source_id": self.source_id,
            "session_id": self.session_id,
        }


@dataclass(frozen=True)
class ArtifactsListPayload:
    """Payload for `agenterm artifacts list` in JSON mode."""

    artifacts: tuple[ArtifactSummaryPayload, ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        artifacts: list[JSONValue] = [a.to_json() for a in self.artifacts]
        return {"artifacts": artifacts}


@dataclass(frozen=True)
class ArtifactShowPayload:
    """Payload for `agenterm artifacts show` in JSON mode."""

    artifact_id: str
    kind: str
    mime: str
    path: str
    size_bytes: int
    created_at: str | None
    source_type: str
    source_id: str
    session_id: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "artifact_id": self.artifact_id,
            "kind": self.kind,
            "mime": self.mime,
            "path": self.path,
            "size_bytes": self.size_bytes,
            "created_at": self.created_at,
            "source_type": self.source_type,
            "source_id": self.source_id,
            "session_id": self.session_id,
        }


@dataclass(frozen=True)
class ArtifactOpenPayload:
    """Payload for `agenterm artifacts open` in JSON mode."""

    artifact_id: str
    path: str

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {"artifact_id": self.artifact_id, "path": self.path}


@dataclass(frozen=True)
class ArtifactAgentRunPayload:
    """Payload for `agenterm artifacts agent-run` in JSON mode."""

    artifact_id: str
    report: Mapping[str, JSONValue]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {"artifact_id": self.artifact_id, "report": dict(self.report)}


__all__ = (
    "ArtifactAgentRunPayload",
    "ArtifactOpenPayload",
    "ArtifactShowPayload",
    "ArtifactSummaryPayload",
    "ArtifactsListPayload",
)
