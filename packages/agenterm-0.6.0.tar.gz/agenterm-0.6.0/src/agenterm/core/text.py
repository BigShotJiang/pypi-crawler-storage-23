"""Shared text formatting helpers."""

from __future__ import annotations


def shorten_line(text: str, *, limit: int) -> str:
    """Return a display-bounded single-line preview."""
    if limit <= 0:
        return ""
    if len(text) <= limit:
        return text
    if limit == 1:
        return "…"
    return f"{text[: limit - 1]}…"


def display_role(role: str | None) -> str | None:
    """Return the user-facing label for a role string."""
    if role == "assistant":
        return "agent"
    return role


__all__ = ("display_role", "shorten_line")
