"""Shared selection helpers used by CLI tooling and the engine.

These functions stay small and deterministic so tool_selection and
REPL/UI helpers can rely on identical bundle expansion without
duplicating logic.

Tool keys use namespaced format: {plane}__{id}
  - hosted:openai:file_search, hosted:openai:web_search, hosted:openai:image_generation
  - fn:inspect, fn:shell, fn:apply_patch, fn:user:my_tool
  - mcp:files
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable, Mapping


def expand_bundle_keys(name: str, *, bundles: Mapping[str, list[str]]) -> list[str]:
    """Return the tool keys for a bundle name, or [] when missing."""
    if name not in bundles:
        return []
    return [str(k) for k in (bundles.get(name) or [])]


def dedupe_str(seq: Iterable[str]) -> list[str]:
    """Preserve order while deduping a sequence of strings."""
    seen: set[str] = set()
    out: list[str] = []
    for item in seq:
        if item not in seen:
            seen.add(item)
            out.append(item)
    return out


__all__ = ("dedupe_str", "expand_bundle_keys")
