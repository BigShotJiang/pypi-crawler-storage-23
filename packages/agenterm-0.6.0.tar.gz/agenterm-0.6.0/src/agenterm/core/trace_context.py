"""Canonical trace-context payloads used by lifecycle persistence."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Literal

from agenterm.core.json_codec import is_json_value

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

type TraceLinkType = Literal["shared", "new", "disabled"]


@dataclass(frozen=True)
class TraceContextSnapshot:
    """Persisted trace context for a run attempt and lifecycle envelopes."""

    trace_id: str | None
    group_id: str | None
    trace_metadata: dict[str, JSONValue] | None
    trace_link_type: TraceLinkType

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for persistence and envelopes."""
        return {
            "trace_id": self.trace_id,
            "group_id": self.group_id,
            "trace_metadata": (
                dict(self.trace_metadata) if self.trace_metadata is not None else None
            ),
            "trace_link_type": self.trace_link_type,
        }


def _clean_optional_text(value: str | None) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return cleaned or None


def _normalize_trace_metadata(
    metadata: Mapping[str, JSONValue] | None,
) -> dict[str, JSONValue] | None:
    if metadata is None:
        return None
    normalized: dict[str, JSONValue] = {}
    for key, value in metadata.items():
        key_clean = str(key).strip()
        if not key_clean:
            continue
        if is_json_value(value=value):
            normalized[key_clean] = value
            continue
        normalized[key_clean] = str(value)
    return normalized or None


def trace_context_from_run_settings(
    *,
    trace_enabled: bool,
    trace_id: str | None,
    group_id: str | None,
    trace_metadata: Mapping[str, JSONValue] | None,
) -> TraceContextSnapshot:
    """Build a persisted trace context from run settings."""
    if not trace_enabled:
        return TraceContextSnapshot(
            trace_id=None,
            group_id=None,
            trace_metadata=None,
            trace_link_type="disabled",
        )
    normalized_trace_id = _clean_optional_text(trace_id)
    link_type: TraceLinkType = "shared" if normalized_trace_id is not None else "new"
    return TraceContextSnapshot(
        trace_id=normalized_trace_id,
        group_id=_clean_optional_text(group_id),
        trace_metadata=_normalize_trace_metadata(trace_metadata),
        trace_link_type=link_type,
    )


def resolve_trace_context(
    base: TraceContextSnapshot,
    *,
    trace_id: str | None,
    group_id: str | None,
    trace_metadata: Mapping[str, JSONValue] | None,
) -> TraceContextSnapshot:
    """Return trace context updated with runtime lifecycle values when present."""
    if base.trace_link_type == "disabled":
        return base
    resolved_trace_id = _clean_optional_text(trace_id) or base.trace_id
    resolved_group_id = _clean_optional_text(group_id) or base.group_id
    resolved_metadata = _normalize_trace_metadata(trace_metadata) or base.trace_metadata
    return replace(
        base,
        trace_id=resolved_trace_id,
        group_id=resolved_group_id,
        trace_metadata=resolved_metadata,
    )


__all__ = (
    "TraceContextSnapshot",
    "TraceLinkType",
    "resolve_trace_context",
    "trace_context_from_run_settings",
)
