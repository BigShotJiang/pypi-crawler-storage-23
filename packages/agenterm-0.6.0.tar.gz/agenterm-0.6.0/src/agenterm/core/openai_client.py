"""Single shared OpenAI client configuration for agenterm.

agenterm is built on the Agents SDK, which itself uses the OpenAI client internally.
Some operations (e.g. Responses compaction and background inspection) require
calling the OpenAI client directly.

Greenfield posture: there is exactly one OpenAI client instance per process.
All code paths must obtain the client from this module so we do not accidentally
split connection pools or drift auth/tracing configuration.

Runtime citations:
- `.venv/lib/python3.12/site-packages/agents/__init__.py:187-197`
  (`set_default_openai_client`)
- `.venv/lib/python3.12/site-packages/agents/models/openai_provider.py:19-25`
  (shared HTTP client rationale)
- `.venv/lib/python3.12/site-packages/agents/models/openai_provider.py:71-81`
  (default client resolution)
"""

from __future__ import annotations

import os
from dataclasses import dataclass

import agents
from openai import AsyncOpenAI, DefaultAsyncHttpxClient

from agenterm.core.dotenv_loader import ensure_global_dotenv_loaded
from agenterm.core.errors import ConfigError


@dataclass(slots=True)
class _OpenAIClientState:
    http_client: DefaultAsyncHttpxClient | None = None
    openai_client: AsyncOpenAI | None = None
    openai_client_api_key: str | None = None
    openai_base_url: str | None = None


_STATE = _OpenAIClientState()


def _shared_http_client() -> DefaultAsyncHttpxClient:
    """Return a shared async HTTP client for OpenAI (connection pooling).

    This mirrors the Agents OpenAIProvider pattern: a single httpx client is
    shared across requests so connection pools are reused.
    """
    if _STATE.http_client is None:
        _STATE.http_client = DefaultAsyncHttpxClient()
    return _STATE.http_client


def _env_openai_api_key() -> str | None:
    ensure_global_dotenv_loaded()
    key = os.environ.get("OPENAI_API_KEY")
    if not isinstance(key, str) or not key:
        return None
    return key


def reset_openai_client() -> None:
    """Drop the cached OpenAI client so it will be rebuilt on next use.

    This is used when `/config key` updates OPENAI_API_KEY; it prevents stale
    credentials from persisting in a long-lived client instance.
    """
    _STATE.openai_client = None
    _STATE.openai_client_api_key = None


def set_openai_base_url(base_url: str | None) -> None:
    """Set the OpenAI base URL override for this process."""
    normalized = (
        base_url.strip() if isinstance(base_url, str) and base_url.strip() else None
    )
    if _STATE.openai_base_url == normalized:
        return
    _STATE.openai_base_url = normalized
    reset_openai_client()


def get_openai_client() -> AsyncOpenAI:
    """Return the process-wide OpenAI client and register it into Agents.

    Raises:
      ConfigError: If OPENAI_API_KEY is not set.

    """
    api_key = _env_openai_api_key()
    if api_key is None:
        msg = (
            "OPENAI_API_KEY is not set. Set it in your shell environment or "
            "save it to ~/.agenterm/.env (via `/config key <KEY>` in the REPL)."
        )
        raise ConfigError(msg)

    client = _STATE.openai_client
    if client is None or _STATE.openai_client_api_key != api_key:
        client = AsyncOpenAI(
            api_key=api_key,
            base_url=_STATE.openai_base_url,
            http_client=_shared_http_client(),
            max_retries=0,
        )
        _STATE.openai_client_api_key = api_key
        _STATE.openai_client = client
        agents.set_default_openai_client(client, use_for_tracing=True)

    return client


__all__ = ("get_openai_client", "reset_openai_client", "set_openai_base_url")
