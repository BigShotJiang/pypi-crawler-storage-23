"""Registration and lookup for configured guardrails."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import MutableMapping

    from agents.guardrail import InputGuardrail, OutputGuardrail

_INPUT_GUARDRAILS: MutableMapping[str, InputGuardrail[object]] = {}
_OUTPUT_GUARDRAILS: MutableMapping[str, OutputGuardrail[object]] = {}


def register_input_guardrail(name: str, guardrail: InputGuardrail[object]) -> None:
    """Register an input guardrail under a stable name."""
    key = name.strip()
    if not key:
        message = "Guardrail name must be non-empty"
        raise ConfigError(message)
    _INPUT_GUARDRAILS[key] = guardrail


def register_output_guardrail(name: str, guardrail: OutputGuardrail[object]) -> None:
    """Register an output guardrail under a stable name."""
    key = name.strip()
    if not key:
        message = "Guardrail name must be non-empty"
        raise ConfigError(message)
    _OUTPUT_GUARDRAILS[key] = guardrail


def resolve_input_guardrails(names: list[str]) -> list[InputGuardrail[object]]:
    """Resolve configured input guardrail names into concrete guardrails.

    Raises:
      ConfigError: When a requested guardrail name has not been registered.

    """
    out: list[InputGuardrail[object]] = []
    for raw in names:
        key = raw.strip()
        if not key:
            continue
        gr = _INPUT_GUARDRAILS.get(key)
        if gr is None:
            message = f"Unknown input guardrail: {key}"
            raise ConfigError(message)
        out.append(gr)
    return out


def resolve_output_guardrails(names: list[str]) -> list[OutputGuardrail[object]]:
    """Resolve configured output guardrail names into concrete guardrails.

    Raises:
      ConfigError: When a requested guardrail name has not been registered.

    """
    out: list[OutputGuardrail[object]] = []
    for raw in names:
        key = raw.strip()
        if not key:
            continue
        gr = _OUTPUT_GUARDRAILS.get(key)
        if gr is None:
            message = f"Unknown output guardrail: {key}"
            raise ConfigError(message)
        out.append(gr)
    return out


__all__ = (
    "register_input_guardrail",
    "register_output_guardrail",
    "resolve_input_guardrails",
    "resolve_output_guardrails",
)
