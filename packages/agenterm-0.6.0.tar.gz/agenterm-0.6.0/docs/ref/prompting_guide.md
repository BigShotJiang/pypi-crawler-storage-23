## GPT‑5 family prompting guide (detailed, crisp, copy/paste-ready)

This guide covers **GPT‑5**, **GPT‑5.2**, and **GPT‑5.1 variants (including Codex‑Max)** with patterns pulled from the GPT‑5 family prompting docs. GPT‑5.2 in particular is **still prompt-sensitive and highly steerable** (tone, verbosity, output shape), so explicit prompting pays off (src_3).

---

## 1) The mental model: prompt = policy + contract + budget

For GPT‑5 family models, the most reliable prompts do three things:

1) **Policy**: what the assistant is allowed/required to do (scope, safety, ambiguity handling).  
2) **Contract**: exactly what the output should look like (sections, format, length).  
3) **Budget**: how much “work” to do (reasoning effort + tool call limits + stop conditions).

Why it matters:
- GPT‑5 is built for **tool calling, instruction following, and long-context**, and is intended as a foundation for agentic apps (src_2).
- GPT‑5.2 tends to be **more deliberate and concise**, but benefits from **explicit scope + verbosity constraints** (src_3).

---

## 2) Start from a canonical “prompt skeleton” (use tags to make it steerable)

Structured XML-like blocks improve instruction adherence and make prompts easier to maintain and reference (src_2). Here’s a strong default skeleton you can adapt:

```text
<task>
Goal: {one sentence definition of “done”}.
</task>

<context>
- Inputs you must use: {bullets}
- What to assume: {bullets}
- What not to assume: {bullets}
</context>

<output_contract>
Return {plain text | Markdown | JSON}.

Structure:
1) {Section A}
2) {Section B}
3) {Section C}

Length + shape:
- Default: {N} bullets max OR {N} sentences max.
- No long narrative paragraphs.
- Do not rephrase the user’s request unless it changes semantics.
</output_contract>

<constraints>
- Implement EXACTLY and ONLY what’s requested.
- No extra features.
- If ambiguous, choose the simplest valid interpretation.
</constraints>

<ambiguity_policy>
- For low-risk uncertainty: proceed with reasonable assumptions; list them briefly.
- For high-risk actions: stop and ask 1–2 questions.
</ambiguity_policy>

<tools_and_context_gathering>
- Batch reads/searches; avoid repeated tool calls.
- Search again only if validation fails or new unknowns appear.
- Prefer acting over more searching.
</tools_and_context_gathering>

<stop_conditions>
Stop when: {objective is fully satisfied + checks pass}.
</stop_conditions>
```

You’ll see these exact “themes” repeated across the GPT‑5 docs: **output shape clamps, scope constraints, explicit stop conditions, and tool-use discipline** (src_1) (src_3).

---

## 3) Control verbosity & output shape (biggest reliability lever)

### 3.1 Use a “verbosity clamp” (especially important on GPT‑5.2)
GPT‑5.2 explicitly recommends **clear, concrete length constraints** for enterprise/coding agents (src_3). You can drop in their pattern:

```text
<output_verbosity_spec>
- Default: 3–6 sentences OR ≤5 bullets.
- For yes/no + short explanation: ≤2 sentences.
- For complex tasks:
  - 1 short overview paragraph
  - then ≤5 bullets tagged: What changed, Where, Risks, Next steps, Open questions.
- Avoid long narrative paragraphs; prefer compact bullets/short sections.
- Do not rephrase the user’s request unless it changes semantics.
</output_verbosity_spec>
```
(src_3)

### 3.2 When you need consistent structure, “dictate the shape”
GPT‑5.2’s guidance is blunt: **dictate output shape and tone** (headers/tables/voice) to get consistency (src_3). If you’re seeing drift, tighten the contract:

```text
Return Markdown with EXACTLY these sections:
## Answer
## Key assumptions (if any)
## Risks / edge cases
## Next steps

Rules:
- Max 6 bullets per section.
- Use inline code for identifiers/paths.
- No extra sections.
```

---

## 4) Prevent scope drift (frontend/product prompts especially)

GPT‑5.2 is strong at structured code, but may “helpfully” add more than you asked for. The docs recommend explicitly forbidding extras and uncontrolled styling (src_3):

```text
<design_and_scope_constraints>
- Explore any existing design systems and understand it deeply.
- Implement EXACTLY and ONLY what the user requests.
- No extra features, no added components, no UX embellishments.
- Do NOT invent colors, shadows, tokens, animations, or new UI elements unless requested.
- If any instruction is ambiguous, choose the simplest valid interpretation.
</design_and_scope_constraints>
```
(src_3)

This same pattern works beyond UI: it’s just “scope discipline” expressed as hard constraints.

---

## 5) Reasoning effort: use the knob, then reinforce with prompting

### 5.1 `reasoning_effort` is a real control surface
GPT‑5 provides a `reasoning_effort` parameter that controls **how hard it thinks** and **how willingly it calls tools**. Default is `medium`; scale it with task difficulty; for complex multi-step tasks, higher is recommended (src_1).

Also notable: **peak performance** is often when you break distinct tasks across multiple agent turns (src_1).

### 5.2 Minimal reasoning (fastest) needs more explicit scaffolding
GPT‑5 introduces **minimal reasoning effort** as a fast option; at minimal reasoning, prompt sensitivity is higher and planning/tool instructions matter more (src_1). The doc calls out patterns that improve performance at minimal reasoning (src_1):

- Ask for a **brief explanation summary** at the start of the final answer (e.g., bullets).  
- Ask for **thorough tool-calling preambles** in agentic workflows (if your UX supports it).  
- **Disambiguate tool instructions** + include persistence reminders.  
- Use **prompted planning**, because there are fewer reasoning tokens for internal planning. (src_1)

---

## 6) Tool use: budget it, batch it, and define “stop”

### 6.1 Prefer batching + acting over endless searching
The GPT‑5 guide suggests patterns like: **Batch search → minimal plan → complete task**, and search again only if validation fails or new unknowns appear—“prefer acting over more searching” (src_1). You can even impose explicit tool budgets (src_1):

```text
<context_gathering>
- Search depth: very low
- Absolute maximum of 2 tool calls.
- If more investigation is needed, summarize findings + open questions, then ask.
</context_gathering>
```
(src_1)

Tip from the same section: include an “escape hatch” that allows proceeding under uncertainty (e.g., “even if it might not be fully correct”) so the model doesn’t stall (src_1).

### 6.2 Avoid “over-tooling” with GPT‑5
Cursor’s prompt tuning found that overly aggressive “be thorough / use tools” instructions can become counterproductive with GPT‑5, causing repetitive searches when internal knowledge was sufficient. Softening those instructions improved tool decisions and efficiency (src_2).

Practical implication: don’t write *“always use tools / be THOROUGH”*; write *“use tools only when needed; batch; stop when enough.”*

---

## 7) Agentic persistence: tell it when to keep going, and when to stop

If you want autonomy (fewer clarifying questions, more persistence), GPT‑5 recommends increasing `reasoning_effort` and using a persistence block like this (src_1):

```text
<persistence>
- You are an agent — keep going until the user’s query is completely resolved.
- Only terminate when you are sure the problem is solved.
- Never stop or hand back when you encounter uncertainty — research/deduce and continue.
- Do not ask the human to confirm assumptions — decide, proceed, document assumptions.
</persistence>
```
(src_1)

### 7.1 Define stop conditions + safe vs unsafe actions
The docs recommend clearly stating:
- the **stop conditions**,
- what actions are safe vs unsafe,
- and when it’s acceptable to hand back to the user.  
Example given: payment/checkout tools should require clarification at lower uncertainty thresholds, while search tools can proceed more aggressively; similarly, deleting files should require higher confidence than grep/search (src_1).

This is an important “agent safety” design pattern: **different actions get different ambiguity policies** (src_1).

---

## 8) Tool preambles: great for UX—but not always

GPT‑5 is trained to provide upfront plans and consistent progress updates via “tool preamble” messages, and you can steer their frequency/style via prompting (src_2). Example prompt snippet:

```text
<tool_preambles>
- Always begin by rephrasing the user's goal briefly before calling tools.
- Outline a structured plan.
- Narrate each step succinctly as you execute tool calls.
- Finish by summarizing completed work distinctly from your plan.
</tool_preambles>
```
(src_2)

**But:** the Codex‑Max guide warns that prompting for upfront plans/preambles/status updates during long rollouts can cause the model to stop abruptly before the rollout is complete—so they recommend removing that kind of prompting in that harness (src_4).

**Rule of thumb**
- If your app shows intermediate steps and benefits from transparency → use tool preambles (src_2).  
- If your harness is sensitive to “talking during rollout” (e.g., certain coding agents) → keep it quiet and focus on completion (src_4).

---

## 9) Instruction hierarchy & contradictions: eliminate “prompt fights”

GPT‑5 explicitly notes that resolving instruction hierarchy conflicts improves reasoning efficiency and performance, and gives a real example where conflicting rules (emergency handling vs lookup vs consent) had to be made consistent. They fixed it by removing contradictions and clarifying exception cases (src_1).

**Practical workflow**
1) Audit your prompt library for contradictions (must/ must-not conflicts, ordering conflicts, hidden exceptions).  
2) Rewrite into a clean hierarchy:
   - Base rules
   - Exceptions (emergency, high-risk)
   - Tool-specific thresholds
3) Add one-liners that explicitly permit exception behavior (e.g., “Do not do lookup in emergency; proceed immediately to 911 guidance”) (src_1).

---

## 10) Formatting: Markdown is not default—so request it (and refresh it)

GPT‑5 in the API does **not** format final answers in Markdown by default (compatibility reason). You can induce Markdown with explicit instructions (src_1). Also: adherence can degrade over long conversations; appending a Markdown instruction every 3–5 user messages improves consistency (src_1).

Drop-in snippet:

```text
- Use Markdown only where semantically correct (inline code, code fences, lists, tables).
- Use backticks for file/dir/function/class names.
```
(src_1)

---

## 11) GPT‑5.2 specific tuning: what to change first

GPT‑5.2 differences called out in the docs (use these to guide prompt tweaks) (src_3):
- More deliberate scaffolding; benefits from explicit scope/verbosity constraints.  
- Generally lower verbosity, but still prompt-sensitive.  
- Stronger instruction adherence and formatting/rationale presentation.  
- Tool-efficiency tradeoffs (may take more tool actions than GPT‑5.1).  
- Conservative grounding bias; ambiguity handling improves with clarification prompts.  

Migration guidance also explicitly says to **pin `reasoning_effort`** to match your prior latency/depth profile (avoid “provider-default thinking traps” that skew cost/verbosity/structure) and then run evals + tune prompt constraints if needed (src_3).

---

## 12) Codex‑Max (GPT‑5.1‑Codex‑Max) prompting notes (if you’re building coding agents)

Codex‑Max is positioned as the best agentic coding model; recommended `medium` reasoning effort as a strong interactive default, with `high`/`xhigh` for hardest tasks (src_4). It also supports compaction for multi-hour reasoning without hitting context limits (src_4).

Two especially actionable Codex‑Max harness tips:

### 12.1 Don’t over-narrate during long rollouts
They recommend removing prompting for upfront plans/preambles/status updates during rollout to avoid premature stopping (src_4).

### 12.2 Maximize parallelism + truncate tool output deliberately
Codex‑Max guidance for file/tool reading:
- “Think first” → decide all files/resources needed.
- “Batch everything” → read multiple files together.
- Use `fn:inspect` to batch read-only inspection operations in one tool call.
- Only do sequential calls if unavoidable (src_4).

For long tool outputs:
- Limit tool responses to ~10k tokens (approx bytes/4).
- If truncating, keep half from the beginning and half from the end; truncate the middle with a marker (src_4).

(If you’re building agents, these two patterns alone can materially improve speed and stability.)

---

## 13) Copy/paste templates (practical starting points)

### Template A — General “crisp but detailed” answer
```text
<task>
Give me a detailed, crisp guide to {topic}.
</task>

<output_contract>
Return Markdown with sections:
## Checklist
## Core principles
## Templates (copy/paste)
## Common failure modes + fixes

Length:
- Max 6 bullets per section (except Templates).
- No long paragraphs.
</output_contract>

<constraints>
- Be concrete and implementation-ready.
- No filler.
</constraints>
```

### Template B — GPT‑5.2 “enterprise clamp + scope discipline”
```text
<output_verbosity_spec>
- Default: 3–6 sentences OR ≤5 bullets.
- Avoid long narrative paragraphs; prefer compact bullets.
</output_verbosity_spec>

<design_and_scope_constraints>
- Implement EXACTLY and ONLY what I request.
- No extra features or styling invention.
- If ambiguous, choose simplest valid interpretation.
</design_and_scope_constraints>
```
(src_3)

### Template C — Agentic tool runner with explicit stop conditions
```text
<persistence>
Keep going until the task is completely resolved; only stop when solved.
Document assumptions; don’t ask to confirm low-risk assumptions.
</persistence>

<tools_and_context_gathering>
- Batch search → minimal plan → complete task.
- Search again only if validation fails or new unknowns appear.
- Tool budget: max 2 calls unless genuinely necessary.
</tools_and_context_gathering>

<stop_conditions>
Stop when: {tests pass / files updated / answer delivered in required format}.
</stop_conditions>
```
(src_1)

### Template D — “Prompt linter” metaprompt (use GPT‑5 to fix your prompt)
Early testers have had success using GPT‑5 as a meta-prompter to suggest what to add/remove to get desired behavior (src_2). A practical way to do that:

```text
Here is my current prompt:
```PROMPT
...
```

It isn’t producing {desired behavior}. From your perspective:
1) What specific phrases should I add to get {behavior}?
2) What phrases should I delete because they cause {undesired behavior}?
3) Where are there contradictions or ambiguous instructions?
4) Give me a revised prompt (minimal edits) and explain the changes briefly.
```

---

## Sources
- **(src_1)** GPT‑5 prompting guidance excerpts covering: context/tool-call budgeting and “prefer acting over more searching”; persistence + stop conditions + safe/unsafe action thresholds; `reasoning_effort` behavior and defaults; minimal reasoning prompt patterns; instruction hierarchy conflict resolution example; Markdown formatting default and “refresh every 3–5 messages.”  
- **(src_2)** GPT‑5 prompting guidance excerpts covering: recommendation to use the Responses API for agentic/tool-calling with reasoning persisted between tool calls; tool preambles concept and steering; Cursor prompt-tuning note about over-tooling and using structured XML specs for instruction adherence; metaprompting.  
- **(src_3)** GPT‑5.2 prompting guidance excerpts covering: behavioral differences vs prior models; controlling verbosity/output shape; preventing scope drift with explicit constraints; migration guidance including pinning reasoning effort and running evals; web research prompting best practices.  
- **(src_4)** GPT‑5.1‑Codex‑Max prompting guidance excerpts covering: recommended reasoning effort levels; warning against prompting for plans/preambles during rollout; parallel tool calling discipline; tool-response truncation recommendations; compaction support.  
- **(src_5)** Codex CLI-oriented style/formatting guidance excerpts emphasizing concise, scannable plain-text responses, not dumping large files, and providing brief next steps.

If you tell me **your use case** (chat Q&A vs agentic tools vs coding agent) and **your constraints** (latency target, max tokens, whether you want Markdown/JSON), I can tailor these templates into a single “house prompt” you can drop into your system/developer message.
