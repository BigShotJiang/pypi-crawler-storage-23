# **OpenAI Responses API and GPT‑5 Reasoning Models — Merged Reference**

> Reference snapshot.
>
> This document is stored under `docs/ref/` as background material and is **not**
> maintained in lockstep with this repository’s runtime (`.venv`). Treat it as
> explanatory context, not as the canonical contract. For current vendor citations
> and repo-specific contracts, see `ARCH.md`.

## **1) Structure of a Response: What Can the Responses API Return?**

OpenAI’s **Responses API** produces a structured response object containing multiple **items** that capture all aspects of the model’s output. In a typical call to a reasoning model, the response.output list can include:

- **Reasoning items:** Represent the model’s internal chain-of-thought tokens. These are returned as a **ResponseReasoningItem** with an id (e.g. rs_...), and optionally a **summary** of the reasoning in natural language . The raw reasoning tokens themselves are not directly exposed for safety . Instead, they are hidden or encrypted (more on encrypted content below) and can be summarized on request. For example, a response JSON might show a reasoning item like:

```
{
  "id": "rs_6820f383d7c0…",
  "summary": [], 
  "type": "reasoning", 
  "status": null
}
```

- Here summary is an array of summary segments (empty if no summary was generated) . If reasoning summaries are enabled, this would contain human-readable notes about what the model “thought” during processing . The **reasoning_tokens** count is also reflected in the usage stats (for instance, a response might have 148 output tokens of which 128 are reasoning tokens ).
- **Tool call items:** If the model decides to invoke a function or tool during its reasoning, the output will include a **ResponseFunctionToolCall** item (type "function_call") capturing the details of that call . This item includes the **name** of the function/tool, the **arguments** (usually as a JSON string), a unique **call_id**, and a status. For example:

```
ResponseFunctionToolCall(
    name='get_weather', 
    arguments='{"latitude":48.8566,"longitude":2.3522}', 
    call_id='call_9ylqPOZUyF…', 
    type='function_call', 
    id='fc_68210c78357c…', 
    status='completed'
)
```

- This indicates the model decided to call the get_weather function with certain arguments . If the model triggers multiple tool calls (either in parallel or series), each will appear as a separate function_call item in the output array .
- **Message items:** Finally, the actual **assistant answer** to the user is returned as a **ResponseMessage** item (type "message"). This contains the assistant’s role and the **content** segments that make up the user-facing answer. For example, a message item in JSON might look like:

```
{
  "id": "msg_6820f3854688…",
  "role": "assistant",
  "type": "message",
  "status": "completed",
  "content": [
    {
      "text": "Why don’t scientists trust atoms?  
               Because they make up everything!",
      "type": "output_text",
      "annotations": []
    }
  ]
}
```

- Here the content array holds segments of the answer text (in this case just one segment of type output_text) . The annotations field is used for any metadata attached to that segment – for instance, citations or footnotes in a Deep Research answer would appear here as references, but in this joke answer it’s empty . If the model’s answer included formatted data or media, additional content segment types could appear (e.g. output_code for code, or an image with a link). The **status** "completed" indicates the message is fully generated.

In summary, the Responses API returns a list of **output items** that together form a complete picture of the model’s work: the hidden reasoning process, any tool/function calls made, and the final assistant message . By examining these items, developers can trace not only *what* the model answered, but *how* it arrived there (which tools it used, etc.).

### **Annotations in the Response Stream**

**Annotations** are structured metadata attached to parts of the assistant’s output, often used for citations, references, or linking to supplemental content. They are delivered alongside the text, especially visible in the JSON output during streaming. Each chunk of streamed content includes an annotations field (frequently an empty list unless something is annotated) . For example, when using the Code Interpreter tool, if the assistant generates an output file and references it in the answer, the response may include a **container_file_citation** annotation pointing to that file . Similarly, a web-browsing or search tool can return results that the assistant cites as URLs – these will appear as annotations of type url_citation with fields like start_index, end_index, url, and title, marking the span of text and the link associated with it . In essence, annotations let the model attach extra information (footnotes, file links, etc.) to its answer without cluttering the main text.

During **streaming**, you might observe the annotations array in real-time before the final response is complete. Typically it remains empty ("annotations": []) until the model has actual references to attach. By the end of the response, any collected citations or references will be present in this array, and the final output_text will include markers (like “[1]”, “[2]”) corresponding to those annotations . If you do not want to display these raw annotation fields in your streaming client, you can simply ignore or filter them out – they are meant for programmatic use (e.g. to render footnotes or attachments in a UI) rather than being shown verbatim to the end-user. Importantly, **annotations do not affect the model’s answer content**; they are a parallel output channel for additional info. (For instance, a citation might appear both inline in the text and as a structured annotation entry , which you can use to format a hyperlink in your app’s interface.) In summary, annotations help provide a richer response with sources or media, especially in complex tool-augmented queries, but they can be safely omitted from display if not needed.

------

## **2) Channels: Analysis, Commentary, Final**

It’s a common misconception that tool calls only occur in the “reasoning” phase. In reality, OpenAI’s reasoning models distinguish **channels** for different kinds of output, and tool invocations can occur on different channels depending on their type :

- **Analysis channel (analysis):** This channel is used for the model’s chain-of-thought content (internal reasoning steps). When the model uses **built-in tools** (like the browser or Python), it will **usually** output those calls on the analysis channel as part of its reasoning process . In other words, the model “thinks out loud” and might say (internally) something like *“I should run a web search for X”* as an analysis message, and then produce a tool call item for the search. These analysis-channel tool calls are considered part of the reasoning stream.
- **Commentary channel (commentary):** This channel is also hidden from the end-user but is used for more structured or action-oriented outputs. **Function calls to developer-defined tools** are typically done on the commentary channel . For example, in the **harmony format**, if the model decides to call a custom function like get_current_weather, it will output the JSON arguments for that function as a commentary message . The commentary channel may also be used for certain built-in tool calls on occasion (the model might sometimes emit those on commentary) and for special notes like a preamble when planning multiple function calls . Essentially, commentary messages are still part of the model’s “thinking,” but geared toward communicating with or through tools (often in JSON or a structured format) rather than free-form reasoning prose.
- **Final channel (final):** By design, any **user-facing answer** (the actual response to the query) is on the final channel . Tool calls would not appear here – if the model is ready to give the final answer, it has finished using tools. The final channel content is the polished answer adhering to all safety and style guidelines, whereas analysis/commentary content may be raw and not safe for direct display .

In training, these channels were part of the model’s format. The GPT-5 series models were **trained on the “harmony” response format**, which explicitly includes role and channel tokens in the prompt . The model learned to output its chain-of-thought on the analysis channel and function calls on the commentary channel as appropriate. As a developer, you typically don’t need to manually label channels (the OpenAI API handles this under the hood), but it’s useful to know that **tool calls are not limited to one stage**: they are simply a type of assistant output that will appear on an *internal* channel (analysis/commentary) rather than in the final answer . For example, in one API call the model might produce an analysis message deciding to use a function, followed by a commentary message with the function arguments, before ultimately returning a final answer .

**Analysis vs. Commentary Channels: How and Why They’re Used**

OpenAI’s harmony format defines three channels (analysis, commentary, final) for assistant messages . The reasoning models (GPT-5 family) were trained with these distinctions to organize their outputs. Here’s how they work and why they exist:

- **Analysis channel:** This is the model’s *private workspace*. When a reasoning model is given a question, it often breaks the problem into steps, considers multiple pieces of knowledge, and so forth – all of this happens in the **analysis** messages. Think of analysis messages as the model “talking to itself.” Because these are not meant for the end user, they are not filtered by the usual moderation rules and may contain content that would be disallowed in a final answer . For example, the model might internally note a sensitive fact or use a coarse heuristic in analysis. The training process included demonstrations of chain-of-thought in this channel, so the model learned to produce such internal monologue without needing to be explicitly prompted each time.
- **Commentary channel:** This channel serves as a bridge between pure internal thought and actions. During training, models were guided to output function call JSON or other **tool-related directives** in the commentary channel . For instance, when a function needs to be called, the model doesn’t just keep musing in free text; it outputs a structured call (like a JSON object or some API call syntax) on the commentary channel. The commentary channel can also contain *preambles or plans* when multiple function calls are needed . You can imagine the model saying in commentary: *“Okay, I will call Tool A, then with its result call Tool B.”* This might appear as a commentary message outlining the plan before executing it. In essence, commentary is for any content that is part of the agent’s interaction with tools or an orchestrator, rather than the final user. It’s distinct from analysis in that it’s often more structured or imperative. For built-in tools, the model mostly uses analysis, but there are cases where even those appear in commentary (the boundaries aren’t 100% rigid) .
- **Final channel:** As noted, this is the only channel intended for the user. The final answer assembled from all the reasoning and tool results is emitted here . The model was trained to output a final message on this channel once it has a solution. In the harmony system message, developers explicitly list that these are the “Valid channels” and that *every message must include a channel* – reinforcing to the model that it should tag each piece of content appropriately.

**Why separate channels?** This multi-channel approach was introduced to improve the model’s ability to perform complex reasoning and tool use **safely and effectively**. By segregating internal reasoning from external responses, the model can use its full power to analyze a query (even delving into content that might be borderline or using an uninhibited tone) without risking outputting something inappropriate to the user . It knows that only the final channel’s content will be seen, so it “cleans up” the answer for that. Commentary channel ensures that tool interactions are clearly delineated and not confused with either final answers or internal musings. This likely made it easier to train the model with RLHF as well: human feedback could be given on final answers separately from the chain-of-thought quality. The result is a model that internally reasons in a very human-like, step-by-step way, yet still produces a coherent, safe final answer.

For developers and prompt engineers, understanding channels means you can **better interpret the model’s outputs** and even nudge its behavior. For example, if you define custom tools via the developer message, OpenAI recommends adding an instruction like *“Calls to these tools must go to the commentary channel”* . This ensures the model doesn’t try to, say, call your function in the middle of an analysis paragraph (which could jumble formatting). Similarly, knowing that the model uses analysis for internal thoughts can reassure you that a lack of immediate answer doesn’t mean it’s stuck – it may be doing a lot behind the scenes. When you retrieve the reasoning summary, you’ll often see those analysis steps spelled out in plain language, confirming the channel usage.

In practical terms, if you are building your own inference solution with an open-source checkpoint (like gpt-oss), you must follow the Harmony format exactly – including the special tokens for channels – otherwise the model won’t behave correctly . If you use OpenAI’s API, you get this formatting automatically. But either way, it’s useful to know that **the model internally labels each message with a channel**, and that’s how it knows what is an intermediate step vs. the final answer . The Harmony encoder/decoder in OpenAI’s libraries will expose this if you ever inspect tokens or use the StreamableParser (you’ll literally see .current_channel switch between “analysis”, “commentary”, and “final” as tokens stream ).

------

## **3) Tool Use and Function Calls**

GPT-5 and other reasoning models are not just thinking machines – they are also **agentic**, meaning they can decide to call external tools (functions, code interpreters, searches, etc.) as part of their reasoning process. The Responses API generalizes the old “function calling” feature into a more powerful **tool calling** mechanism. Understanding how tool calls are represented in the new API will help clear up confusion about “reasoning section vs normal messages.”

When the model decides to use a tool, **it happens during the chain-of-thought**. For example, imagine the user asks a complex question that requires looking up information. The model might internally reason: *“I should call the search function now to find relevant info.”* This decision is made in the hidden reasoning tokens. In the *output* that the API returns to you, **a tool call is represented as a special item** rather than a normal assistant message. Specifically, you will see an object in the response.output list with "type": "function_call" (or another tool type, like a web search or file search call), containing details like the name of the tool and the arguments it wants to pass . This is analogous to how the Chat Completions API would return a function_call object instead of a message content. In the Responses API, since the output is a list of items, you often get *two* items when a tool is invoked: first a reasoning item (with the chain-of-thought record, possibly summarized or encrypted) and next a function_call item representing the tool the model chose . Notably, in such cases **you will not yet have a final answer message** – the model has paused to get help from the tool. The API response status may indicate the assistant is waiting for the tool result, or it might mark the function call item with status: "completed" (meaning the call instruction was fully given).

At this point, it’s the developer’s job to **execute the tool** outside the model (e.g., call the actual function or API the model requested) and then feed the result back. The Responses API expects you to take that function_call output, perform the action, and then **continue the conversation by calling the API again** with the results. To do so, you include the original function call and a new special message for the function’s output in your next request’s input. In practice, you append two entries to your conversation context: one that echoes the function call (type "function_call", with the same name and arguments and a call_id to tie it together), and one that provides the **function’s result** (type "function_call_output", containing the call_id and the output from the function) . By providing these, you are telling the model: *“Previously, you asked to use this tool; here is what happened when that tool was executed.”* You also carry forward the reasoning item or (if using provider-managed continuity) rely on the provider's stored context so the model’s chain-of-thought resumes where it left off .

Now, on the second API call (after the tool result is given), the model will incorporate the function’s output into its context (it effectively sees: user’s question, then it’s own function call action, then the function’s answer). It will then continue its reasoning and finally produce an **assistant message** with the answer. That final answer comes as a normal "type": "message" with role: "assistant" and content field, just like any other answer . So the full sequence for a tool-using turn might be:

- Turn N request -> model outputs: {type: "reasoning" (hidden thoughts)}, then {type: "function_call", name: X, args: Y}. (No assistant message yet.)
- You call function X with args Y, get result R.
- Turn N+1 request -> you send: prior conversation + that function_call item + a {type: "function_call_output", output: R} item.
- Model sees the function result and responds with: {type: "reasoning" (more thinking)}, then {type: "message", role: "assistant", content: "... final answer incorporating R ..."}.

All of this can be managed by the Responses API. If you use store=true and enable provider-managed continuity, you actually don’t need to manually include the reasoning item or even the original function call in the next input – OpenAI will have stored them. You would still need to provide the function_call_output though, because that’s new information the model didn’t have (the result of the external call). In stateless mode, as shown above, you include everything explicitly in the input list.

**How are tool calls “presented” in stored history?** If you rely on OpenAI’s stored state, the chain-of-thought and the fact that a function call happened are all recorded under that response_id. The next request (in provider-managed continuity mode) implicitly includes them. If you’re storing conversation history yourself (in-house), you should keep a record of the function call and its result as part of the dialogue log. Many developers represent it as if the assistant “said” something like: *Assistant (tool call):* *<function_call name="X" args="...">* and then *Assistant (tool result):* *<tool_output> ...*. In JSON terms, you store the structured items. The main thing is to preserve the sequence: user message, assistant function call, function result, assistant answer, etc., so that if you replay or resend it, the model understands the context.

**Tool calls during the reasoning phase vs normal messages:** The key difference is that a tool invocation interrupts the normal question-answer flow. The model’s reasoning triggers a function call *instead of directly producing an answer*. Thus, what you receive from the model mid-way is not an answer for the user, but an action to perform. In the **reasoning summary** (if you requested one), the model might even narrate this decision (e.g., *“I decided to use the* *WeatherAPI* *to get the latest data.”*). But the user won’t see anything until the tool has been executed and the model returns a final answer. If your goal is to store the history *“as faithfully as possible,”* you might consider storing the reasoning summary (if available) for debugging or audit, but not show it to the user. The critical pieces to store for functionality are the user messages, assistant messages, and any tool call outputs. The raw encrypted reasoning can also be stored if you plan to reuse it, but it’s not human-readable. Many developers simply rely on provider-managed continuity (stateful) or the encrypted blob (stateless) rather than saving every reasoning token themselves. The summary, however, *is* human-readable and could be logged to understand what the model was thinking at that turn.

In summary, tool usage in the Responses API is neatly integrated into the flow: it appears as special output items triggered by the model’s reasoning. This is different from a normal Q&A turn where the assistant response is just a message. Handling tools means handling an extra round-trip. But the **Responses API** is designed to make this easier – it keeps track of calls and even allows **parallel or multiple tool calls** in one response if the model decides to (for instance, the parallel_tool_calls flag in the response indicates the model can call tools concurrently, and tool_choice: "auto" means the model decides itself when to use which tool) . GPT-5 and its cousins are quite capable agents, so they might chain reasoning and tools in sophisticated ways. Always check the output array of the response – if you see a function_call item (or any non-message item), it means the model expects you to do something (or it’s providing an intermediate result like an image, etc.) rather than just giving a final answer.

------

## **4) Statefulness and Conversation History Handling**

When using the Responses API, you have two ways to maintain conversation state:

> **Agenterm note:** agenterm defaults to `model.store: false` (provider storage off) and
> always replays local session history. Use `--store` or set `model.store: true` when you
> want provider persistence for background inspection and response retrieval.

1. **Let OpenAI manage it (stateful API):** By creating responses with store=true (the default) and using the provider's stateful chaining mechanism for follow-up calls, the system will remember prior conversation turns. This includes all the assistant’s previous outputs *including* its reasoning and tool use. In fact, the Responses API is designed so that if you supply the prior response id in the follow-up request, the model *automatically* has access to all previously produced reasoning items and messages without you explicitly resending them. This approach is convenient, but not available to organizations that disable stateful storage (e.g. due to data retention policies).
2. **Manage history yourself (store=false or external orchestrator):** In this case, you must accumulate the conversation history and pass it in each new request’s input. To achieve parity with the OpenAI-managed approach, **you should include all relevant items from prior turns** – not just the user and assistant messages, but also the reasoning and tool-call items that the assistant produced . Essentially, you are responsible for constructing the sequence of role-item objects that represents the full conversation.
   - Include prior **user messages** ({"role": "user", "content": "..."}) as they were.
   - Include prior **assistant messages** that were shown to the user (type: "message", role: "assistant", content: ...).
   - **Critically, include the prior reasoning and tool call items** in the sequence as well (the items with type: "reasoning" and type: "function_call"). This ensures the model has the same chain-of-thought context it would have had under provider-managed continuity. OpenAI’s guidance for reasoning models is to simply *append the entire previous response output* to your context for the next turn . For example, if response is the object returned from the last API call, you can do:

```
context += response.output  # add reasoning + function call + message items to context
```

- This way, nothing is lost – the next call knows which function was called and what the internal reasoning was, just as it would in the managed case.
- If a function call was made and you executed the function, also include the **function’s result** as a special message item. The format is:

```
{
  "type": "function_call_output",
  "call_id": <the call_id from the tool call item>,
  "output": <the function's return value (as string or JSON)>
}
```

- This is how you feed the tool’s result back into the conversation . The model will recognize it and continue the reasoning from there.

By storing and resending all these components, you achieve full parity with OpenAI’s own stateful handling. The model will effectively see the same sequence of events. OpenAI’s documentation also notes:

The Responses API is designed to be **stateful by default**, meaning it can remember previous messages and even the model’s hidden reasoning across turns, **if you want it to**. In the classic Chat Completions API, developers always had to send the full conversation history with each request. The new Responses API offers a more convenient option: you can let OpenAI handle the history for you on their servers. This is controlled by the **store parameter** and provider-managed continuity. Here’s how it works:

- **store=true (Stateful mode)**: When store is true (the default behavior unless you opt out), each API call’s result is stored by OpenAI for a period (by default, 30 days retention for API data). The response you get back includes an id (e.g. "resp_12345..."). To continue the conversation, you can pass the prior response id in your next request, instead of resending all prior messages. The OpenAI backend will retrieve the conversation state (all messages *and* any associated reasoning items or tool usages) and provide them to the model for the next turn . Importantly, **this includes the chain-of-thought from previous turns**: reasoning items generated in earlier responses are automatically kept and fed into the next prompt in stateful mode . Note that in typical cases the model may not strictly need past reasoning to answer follow-ups – it has been trained to carry on a conversation just from the dialogue history – but providing the past reasoning can help, especially if a tool was used (more on that shortly). If you **do not** want to retain data, or have privacy concerns, you can delete stored conversations via the API (there’s a deletion endpoint) , but otherwise this stateful mode is very convenient.
- **store=false (Stateless mode)**: If you set store=false for a request, OpenAI will **not** retain that conversation data or allow provider-managed continuity for it. This mode is required for certain strict privacy settings – for example, enterprise users with **Zero Data Retention (ZDR)** policies have store=false enforced automatically on every request . In stateless mode, **the responsibility of maintaining conversation context shifts entirely to you**. You must send the full history of the conversation (or as much as you want the model to remember) with each API call’s input. This includes all prior user messages and assistant messages in the correct order, much like the older chat API usage. If your assistant used tools and produced function calls or other special outputs, you’d include those in the history as well (as structured items). Essentially, with store=false, the Responses API behaves more like the classic API – no memory between calls unless you implement it on your side.

When using stateless mode, a special challenge arises with the model’s hidden reasoning. Since OpenAI isn’t storing anything, the chain-of-thought from previous turns would normally be lost once the response is returned. However, as mentioned, providing the model its own prior reasoning can improve performance in multi-step tasks (especially those involving tool use) . The solution is to **capture and include the reasoning items yourself** – which is possible via *encrypted reasoning items*, discussed next. In summary, **“history at OpenAI vs in-house”** is your choice: you either let OpenAI keep the conversation state (convenient, but your data lives on their servers for a time) or you manage it (more control/privacy, but more work). Either way, the model can have the same conversation experience; it’s just a matter of who retains and supplies the context each turn.

**Does OpenAI always feed back the reasoning tokens from previous turns?** In stateful mode, **yes**, all previous reasoning entries are implicitly available to the model when you chain responses . The model architecture, however, is such that it typically doesn’t *reuse* reasoning from prior turns unless needed – in fact, the system is designed to drop those tokens when generating a new turn’s answer unless a tool call scenario makes them relevant . So including them does no harm (they’ll be ignored if not applicable), and in cases like function calls, including them is beneficial. If you have **reasoning summaries** turned on, those summaries are for your benefit (they are not fed back into the model). But the actual raw reasoning *tokens* (not visible to you) **are** fed back in chained mode. In stateless mode, if you want the model to have continuity of reasoning, you must explicitly pass them back (in encrypted form). If you don’t, the model still has the dialogue history to work with, just not its previous “scratch work.” In many simple conversations, that’s fine – the model can pick up context from the user messages alone. But for complex multi-turn tasks (say, it was working on a lengthy plan or code across turns), providing the prior reasoning context can make a difference in quality . To be clear: *“summaries off”* doesn’t mean the model didn’t think or that the thoughts are gone – it only means you didn’t request a human-readable summary. The underlying reasoning is there and, if using stateful chaining, is retained behind the scenes for the model’s use.

------

## **5) Reasoning Summaries**

Reasoning summaries are a new feature that provides a human-readable condensation of the model’s chain-of-thought. Important points about summaries:

- **They are optional and for the developer’s benefit.** You can request the model to generate a summary of its reasoning by setting the reasoning.summary parameter (e.g. "auto" or "detailed") in the API call . When enabled, the model will output a summarized narrative of its internal reasoning, which appears in the ResponseReasoningItem.summary field . For example, after a complex question, you might get a summary saying *“The model considered X, checked Y, and concluded Z.”* This is similar to what ChatGPT’s UI shows in “GPT-5 Thinking” mode – a brief explanation of what the model is doing .
- **The summary is not used by the model in subsequent reasoning.** It’s purely an expositional artifact. The **actual chain-of-thought tokens** (hidden to us) are what guide the model’s behavior. The summary is generated *from* those tokens but is **not fed back into the model** on the next turn (unless you, as the developer, manually choose to include it, which generally isn’t necessary). In fact, even with store=true, OpenAI does not need to store the summaries for the model’s sake – the model will reconstruct a new reasoning chain each turn regardless . The summary is there “for your eyes,” to help with debugging, auditing, or providing the user a peek into the AI’s thought process . It’s **transient** in the sense that if you don’t explicitly include it in the next prompt, the model will not know or care about what its last summary said. Only the raw hidden reasoning (or its ID) needs to carry over for continuity in the same turn (as discussed above).
- **Who generates the summary?** The summary is generated by the model **itself** as part of the response. Under the hood, when reasoning.summary is requested, the model effectively produces an extra piece of output (the summary text) derived from its reasoning tokens. It is not a separate second model writing the summary; it’s the same model reflecting on its chain-of-thought and outputting a concise version. The OpenAI system may orchestrate this so that it happens automatically at the end of the reasoning process. Notably, the Azure documentation warns that even if requested, **summaries are not guaranteed for every request** – presumably the model decides if a summary is warranted or fits in the context. In practice, if the chain-of-thought is short or straightforward, the summary may come back as null or empty.
- **“Fire-and-forget” nature:** Think of the summary like a log or commentary – it’s for the developer or user interface, but **the model’s next turn does not depend on seeing its own summary**. This is analogous to how in ChatGPT’s interface, the “reasoning” blurb you see while it’s thinking doesn’t become part of the conversation transcript that the model responds to next; it’s purely informative. We see this in the API as well: the summary appears in the response object, but if you use provider-managed continuity to continue, the model will be handed the underlying reasoning context (as needed), not the natural-language summary itself .

GPT-5 and the related “*reasoning models*” internal chain-of-thought**, i.e. the model’s hidden reasoning tokens. These models **always “think” through the problem internally** by generating reasoning tokens that are **not part of the final answer** you see . In other words, the model’s output is composed of two parts under the hood: (1) *reasoning tokens* – the deliberation or intermediate steps, and (2) *completion tokens* – the final answer text. By default, you only get the final answer as the assistant’s message, and the reasoning tokens are kept hidden for safety (they may contain raw, unfiltered thoughts or unnecessary detail) . The amount of reasoning the model does can be tuned via the **reasoning_effort** (often just called effort) parameter. This setting can typically be "low", "medium", or "high" for most reasoning-capable models, and the GPT-5 series even supports "minimal" as a new lowest-effort option . A higher effort means the model will devote more tokens to thinking steps, which generally leads to more thorough answers (especially on complex tasks) at the cost of increased latency and token usage . A minimal or low effort means the model does very little step-by-step reasoning, favoring speed. **Crucially, regardless of the effort level, the model will perform some form of reasoning internally if it’s a reasoning model; you cannot truly turn off its “thinking”**, you can only reduce it.

Because these reasoning tokens are hidden, OpenAI provides an **optional summary** of the chain-of-thought instead of the raw thoughts. This is where the **reasoning summary** feature comes in. In the new Responses API, you can request the model to produce a **natural-language summary of its own reasoning process** for you to inspect. This is controlled by the reasoning.summary parameter (formerly sometimes called generate_summary). It’s not a simple on/off flag but rather can be set to different levels of detail. The allowed values are "detailed", "concise", or "auto" (automatic) .

- **Detailed**: the model will attempt to give a thorough, step-by-step explanation of what it thought or did to arrive at the answer (great for debugging or audit).
- **Concise**: the model (if supported) will give a brief summary of its reasoning – a short explanation rather than a long narrative. (Note: the GPT-5 series does **not** support the concise mode as of now, so you’d use detailed or auto) .
- **Auto**: this lets the system decide how much to summarize. In practice, "auto" will produce a summary when it deems it useful – often yielding a detailed summary for complex queries, but it might omit the summary for very simple queries. Essentially, auto means *“summarize the chain-of-thought adaptively”*.

**Are reasoning summaries related to the model “thinking” or not?** No – the summary setting **does not control whether the model uses reasoning tokens; it only controls whether a readable summary of those tokens is output** . The model will still perform its chain-of-thought reasoning internally whenever you use a reasoning-capable model (GPT-5, o3, etc.), even if you don’t request a summary. Turning summaries on just means “after you’re done reasoning, please describe (or reflect on) how you solved this.” Turning summaries off (or leaving reasoning.summary as null) means no explanatory text about the reasoning will be returned – you’ll just get the final answer, as usual. The reasoning process itself is unaffected; the model’s accuracy or thoughtfulness doesn’t drop just because you didn’t ask it to summarize its thoughts – those thoughts were still there, just not shown. Likewise, requesting a summary doesn’t make the model “think harder”; it only causes it to produce an extra output (which does cost some extra tokens, but OpenAI currently doesn’t charge extra for the summary itself ).

One thing to note: **Reasoning summaries are not guaranteed to appear every time**, even if you request them. The OpenAI docs mention that it’s expected behavior for some queries/steps to yield no summary . In practice, this could happen if the model’s chain-of-thought was very trivial or if the system decided a summary wasn’t necessary. So you should code defensively: if you ask for a summary and none comes back, handle that gracefully (it doesn’t mean reasoning didn’t happen – it just wasn’t summarized that turn).

**Summary vs. Effort:** These are independent settings – you can have high reasoning_effort (lots of hidden thinking) but no summary shown to the user, or conversely minimal effort but still request a summary of whatever little reasoning it did. Typically, though, if you want insight into the model’s thinking, you’d use a medium/high effort *and* request a summary; if you only care about the answer, you might use minimal effort and no summary for efficiency.

------

## **6) Encrypted Reasoning**

For organizations that cannot or do not want to use store=true (stateful mode), OpenAI provides **encrypted reasoning items** to help maintain continuity without server-side state . Here’s how it works and what it implies for storing history:

- When you include "reasoning.encrypted_content" in the include parameter of your API call, the response’s reasoning item will contain an **encrypted_content** string – a long ciphertext representing the model’s chain-of-thought tokens . This is encrypted such that only OpenAI’s systems can decrypt it later; you as the developer don’t need to (and can’t) read it. It might look like a base64-like blob of hundreds of characters.
- You are expected to **send this encrypted blob back** in the next request as part of the conversation input (just like you would include a normal reasoning item). In fact, the OpenAI cookbook example shows doing context += response.output even when the reasoning is encrypted – the reasoning item in response.output will carry the encrypted content, and by appending it to context you ensure the next call includes it. The API will detect that it’s an encrypted reasoning item and internally decrypt it (in-memory) to recover the chain-of-thought for use in the next turn’s processing .
- This allows stateless clients (or Zero Data Retention contexts) to still provide the model with continuity **without storing plain text**. OpenAI automatically discards any unencrypted reasoning if store=false, but with the encrypted content, you can rehydrate the model’s memory of its last step on your side . Importantly, OpenAI enforces that new reasoning tokens are immediately encrypted before returning to you and never written to disk on their side , satisfying strict privacy rules.
- From your perspective, **handling encrypted reasoning items is identical to handling normal reasoning items** – the only difference is you don’t see a summary (the summary will likely be empty or omitted) and you have an encrypted_content field that you carry forward . You still include the item in context next turn. Yes, this means the encrypted blob will keep accumulating in the conversation if you keep adding it every time. In practice, you might only need to carry it across a function-call boundary (within the same “turn”) rather than indefinitely – since once a turn is fully resolved with a final answer, the next user question doesn’t need the last turn’s reasoning. But if you want full parity and are unsure, it’s safest to include it for that turn.
- Note that encrypted reasoning content is **only needed if you are not using provider-managed continuity**. If store=true and you use the stateful mechanism, OpenAI keeps the reasoning on their side and will automatically supply it when needed. Encrypted content is a workaround for store=false situations.

**Encrypted Reasoning: Preserving Chain-of-Thought Without Revealing It**

**Encrypted reasoning** items are a key feature that ties together the privacy and continuity aspects of reasoning models. As noted, OpenAI **does not expose raw chain-of-thought tokens** to developers for safety reasons . In stateful mode, you don’t need to see or handle those tokens – OpenAI manages them internally. But in stateless mode (store=false), if you want to carry forward the model’s hidden reasoning from one turn to the next, you have a problem: you can’t just insert the raw reasoning text (you don’t have it), and OpenAI isn’t storing it. **Encrypted reasoning solves this** by giving you an opaque, encoded bundle of the reasoning that you can pass back to the API, without ever decrypting or reading it yourself .

Here’s how it works in practice: when you make a request, you can include "include": ["reasoning.encrypted_content"] in the API call. This tells the Responses API to **attach an encrypted copy of the model’s reasoning trace** in the response . The response you get will then contain, in the output array, a **reasoning item** with an encrypted_content field – essentially a long string of gibberish (for example, it might look like gAAAAABkX... etc.). This string is the chain-of-thought tokens, encrypted by OpenAI. You cannot interpret it (it’s effectively random noise without the key), and even if you opened it, it’s not in plain text. To use it, you **pass it right back** in the next call: you add that reasoning item (or just its encrypted_content) into your next request’s input so the model gets it as part of the context . When the API receives that, behind the scenes it will **decrypt those reasoning tokens in-memory** (using keys OpenAI controls) and feed them to the model, thereby recreating the same internal state as if the model had never lost its train of thought . Crucially, OpenAI’s service does this decryption only transiently – it does **not** write the decrypted content to any database or log; it’s used on the fly and immediately discarded from memory once the new response is generated . Any new reasoning tokens the model produces in that response will again be encrypted before returning to you if you requested include=["reasoning.encrypted_content"] again . This way, you can maintain an *infinite* conversation statelessly: each turn you send the last turn’s encrypted reasoning and get a fresh encrypted blob for the next turn, without either party (you or OpenAI’s persistent storage) ever holding the plaintext chain-of-thought long-term.

From a security and compliance perspective, **you (the developer) never see the model’s raw reasoning, and OpenAI never stores it** when using this mechanism. It’s effectively end-to-end encrypted between the model’s “mind” and OpenAI’s processing – you’re just ferrying the ciphertext back and forth. Only the model (and the system routing your request) can decrypt it. This satisfies requirements like ZDR (Zero Data Retention) because nothing sensitive is persisted on the server, and you as a client can’t inadvertently leak or misuse the reasoning content (since you can’t read it). It’s a form of **obfuscation** of the chain-of-thought: the reasoning stays hidden and protected, yet the benefits of having it in context are retained.

To clarify **who holds the keys**: the encryption/decryption is handled by OpenAI. You do not need to supply any key – it’s managed internally (likely using a secure encryption scheme that OpenAI controls). From your point of view, the encrypted blob is an opaque token. Just include it in the next call and trust that the API knows how to decrypt it. If you were to inspect the blob, it wouldn’t make sense (and that’s by design). This ensures that even if the raw reasoning might contain policy-violating content or sensitive data, you as the developer never see it in plain form – you only ever see a safe summary (if you requested one) or nothing at all.

In summary, **encrypted reasoning** allows all the pieces to come together: it enables stateless usage (store=false) *and*zero-retention policies while still leveraging the advanced chain-of-thought capabilities of GPT-5 and others. You get continuity of thought without compromising privacy or safety. If you don’t use encrypted reasoning in stateless mode, the model will just start each turn with no memory of its prior reasoning (only what you explicitly provide in conversation history). That can work, but you might miss out on some performance gains in complex multi-turn tasks . With encryption, you can have your cake and eat it too: no data retention, no exposure of raw thoughts, yet near-full fidelity of the conversation state.

*(A note on “obfuscation” vs encryption: here, encryption is the mechanism of obfuscation. The chain-of-thought is effectively obfuscated from everyone except the model. So the terms in this context refer to the same feature.)*

------

## **7) Streaming and “Thinking…” Signals**

By default, the OpenAI API **does not stream out a “the model is thinking” event** separate from the content you requested. If you call client.responses.create without streaming, you will simply receive the final response object once the model has finished reasoning and produced either a final answer or a function call. There isn’t an intermediate callback that says “the model is now in analysis mode” (especially if you haven’t asked for a reasoning summary).

However, there are a few ways you can detect or utilize the model’s thinking process:

- **Reasoning summary as an indicator:** If you enable reasoning summaries, you will receive that summary text in the response. While it’s delivered **after** completion (not as a live update), it does tell you what the model did while “thinking”. In a live application, you could choose to stream the final answer tokens and then, once the response is done, display the reasoning summary to the user (similar to how ChatGPT’s UI reveals the thought process once the answer is ready).
- **Streaming with a Harmony parser:** The underlying protocol for reasoning models includes special tokens for roles and channels (e.g. <|channel|>analysis at the start of a reasoning message) . If you use the low-level streaming token API and a Harmony format parser, you **can** observe when the model switches into the analysis or commentary channel in real-time . For example, using the openai_harmony library’s StreamableParser, you can process tokens as they arrive and check stream.current_channel – it will change to "analysis" when the model starts its chain-of-thought, then perhaps "commentary" when it issues a tool call, and finally "final" when it produces the answer . This is a more advanced technique and essentially re-implements what the Responses API is doing internally. It’s useful for debugging or custom UIs (you could show a live “thinking…” indicator when you detect analysis tokens streaming).
- The only partial events the API might send are related to function calls: for instance, if streaming, once the model decides to call a function, the stream will stop at a special <|call|> token , and the function call details will be available in the output. In effect, the end of the stream in that case is itself a signal that “the model thought and now needs a tool.” But it’s not explicitly labeled as a thinking phase – you infer it because a tool call was returned.

**Behavior With Streaming On vs Off**

All the concepts above – hidden reasoning tokens, summaries, encrypted content, tool call structure, annotations – **exist regardless of whether you use streaming or not.** The difference is purely in **how the data is delivered to you**. In **non-streaming mode** (the default synchronous call), you send your request and wait; the model does all its reasoning and tool use internally, possibly calls tools (which might involve multiple API calls under the hood if you handle function calls manually), and finally returns a completed response object. That object might contain multiple parts (as discussed: maybe a reasoning summary, then the assistant’s message, etc.), but you receive it all at once in the JSON. This is simpler to parse in your application since you get the full structure in one go after the operation completes.

In **streaming mode** (stream=true in the API call), the response will come as a sequence of events that you consume incrementally. Under the hood, as the model generates tokens, these are sent to you in chunks. The Responses API’s streaming implementation is more complex than the old API’s because of the richer output structure. Essentially, you will receive events corresponding to the building of the output array. For a straightforward answer (no tool use), the events will stream out the assistant’s message content in parts. Each part will include any new text in a field (often called a delta in the older API; in the Responses API you might get an event object with type: "response.delta" or similar containing a snippet of text). Along with the text, you will see the annotations field (likely empty until maybe the end) and other metadata. Annotations might be sent in separate events if they refer to earlier text. For example, if the model finishes an answer and only then knows the full content to attach citations, you might get an **annotation event** after the content is done, indicating the citations for the preceding text. (The Azure documentation notes that annotation messages in streaming have an empty text field and just provide info like offsets and content_filter_results or citations relevant to prior tokens .) In practice, many developers simply concatenate the content.text from each output chunk to build the final answer string, and collect any annotations into a list. By the end of the stream, you should have the same data as you would in a non-streamed response – e.g., one assistant message with perhaps some annotations attached. The difference is you could start displaying the answer to the user before it’s fully complete.

**Streaming with tool calls**: If the model decides to make a tool call in streaming mode, you will typically receive the partial reasoning/content up to the point of the tool invocation, and then an event indicating the function call. At that moment, the stream for that response will end (since the model is effectively pausing for the tool). You would then execute the tool and likely start a new streamed request to continue the answer. This is analogous to the non-streaming case but spread out: you might see something like the model streaming a sentence like *“Let me check that for you…”* and then suddenly instead of continuing text, it sends a function call event. Your app must detect “aha, function call event arrived, stop printing any more text, do the function, then call again to get the rest.” On the next call (after function output), you can also request streaming so that the final answer streams back token by token to the user. This coordination can be a bit tricky but is manageable with event-driven handling.

**Streaming with reasoning summary**: If you requested a reasoning summary (reasoning.summary set) while streaming, the summary will likely be sent as its own part of the stream. Typically, the reasoning summary (if generated) might come **before or after the final answer**. In the ChatGPT UI, for instance, you might have seen the model’s “thoughts” appear, then the answer – or vice versa. The official API documentation suggests that the summary is part of the structured output. In the JSON, the reasoning summary is one item in the output array (the item with "type": "reasoning" and a "summary" field) and the answer is another item ("type": "message"). When streaming, these could be delivered in sequence. You might first get events corresponding to the reasoning summary content (if detailed, this could be a chunk of text explaining the chain-of-thought), then events for the final answer message. The **order** is something to be mindful of: the example in the docs shows the reasoning item coming first in the output array , which implies the summary might stream before the answer. This would mirror the ChatGPT experience where you can toggle a “Thoughts” view – the model actually had those thoughts ready. However, it’s also possible the summary is generated after the answer. In any case, by the end of the stream you will have both pieces. If streaming, you should handle that there may be two separate textual outputs (one for summary, one for answer). If you only care about the final answer for the user, you might choose to ignore streaming events that belong to the reasoning summary (they might be marked with a different type in the event). On the other hand, you might present the summary in a UI panel for transparency. Just know that **with streaming on, you’ll be getting a live feed of all output items** (reasoning, tool calls, answer content, annotations, etc.), and you need to segregate or process them appropriately. With streaming off, you get them all at once and can easily split them up from the final JSON.

In short, **turning streaming on does not change any fundamental behavior of the model or the API features** – it’s the same chain-of-thought, same tool use, same annotations and summaries. The only change is the delivery mechanism. Streaming gives you more realtime insight (you could even watch the model “think out loud” if you stream the reasoning summary), whereas non-streaming gives you the final result in one package (simpler, but with a wait). If you’re ever unsure, it can be helpful to first run with streaming off to see the full structured response, which is easier to debug, then move to streaming once you know what to expect.

------

## **8) Reasoning Effort**

The amount of reasoning the model does can be tuned via the **reasoning_effort** (often just called effort) parameter. This setting can typically be "low", "medium", or "high" for most reasoning-capable models, and the GPT-5 series even supports "minimal" as a new lowest-effort option . A higher effort means the model will devote more tokens to thinking steps, which generally leads to more thorough answers (especially on complex tasks) at the cost of increased latency and token usage . A minimal or low effort means the model does very little step-by-step reasoning, favoring speed. **Crucially, regardless of the effort level, the model will perform some form of reasoning internally if it’s a reasoning model; you cannot truly turn off its “thinking”**, you can only reduce it.

------

## **9) GPT-5 Model Variants: Chat vs. Reasoning**

OpenAI’s “GPT-5” release actually includes multiple model variants. Not all of them use the full reasoning paradigm with visible chain-of-thought. Specifically, there is **GPT-5-Chat** (sometimes called *Fast* mode in ChatGPT UI) which is a **non-reasoning variant**, and the **GPT-5 reasoning models** (which include the ones used in “Thinking” or “Pro” modes). Here’s the difference:

- **GPT-5-Chat:** This is a streamlined model designed for speed and straightforward conversation. It behaves more like the classic GPT-3.5/GPT-4 Chat models in that it does *not* engage in an extensive hidden chain-of-thought for each query. Consequently, it **does not generate reasoning tokens** or tool usage in the way the reasoning models do. In the API, GPT-5-Chat endpoints do **not support the reasoning parameters** (e.g. reasoning_effort or reasoning.summary) . If you try to use those with the chat model, you’ll get an error or it will be ignored . This model is suitable for simpler tasks or when latency is critical, and it’s the one that yields “immediate answers” without the intermediate thinking step in the ChatGPT application . Think of it as “GPT-5’s fast mode, no deep thought.” Indeed, users have noticed that GPT-5-Chat can sometimes be less accurate on complex queries – that’s because it isn’t employing the multi-step reasoning approach, it’s more akin to a direct completion.
- **GPT-5 (Reasoning models):** These are sometimes just referred to as GPT-5, and they **do have the full chain-of-thought capability**. They were introduced alongside the Responses API precisely to leverage reasoning and tool use . When you use these models via the API (model="gpt-5" or a specific reasoning model deployment), you can and should use the reasoning parameters to control effort, and you will get the ResponseReasoningItem in outputs. In ChatGPT’s UI, selecting “GPT-5 Thinking” or “GPT-5 Pro” essentially invokes these deeper reasoning models under the hood . The difference is visible: the reasoning models will take a bit longer and you may see the “thinking” indicator, but the answers are more robust on challenging tasks.

To confirm: **GPT-5-Chat does not perform the chain-of-thought reasoning**, whereas the **GPT-5 reasoning models do**. OpenAI’s documentation and community discussions explicitly note that the reasoning features are “only available for GPT-5 reasoning models” and not for the standard chat model . If you have access to both, you choose one or the other depending on your needs. For example, OpenAI’s developer platform might label the fast one as "gpt-5-chat-latest" and the reasoning one simply as "gpt-5" (or a date/versioned identifier). The **Azure OpenAI** service made this distinction clear: you must deploy a GPT-5 reasoning model (via the AI Foundry) to use reasoning_effort, otherwise a call to the normal gpt-5-chat will reject those params .

As a developer, if you want the model to use tools, break down problems, or give you reasoning summaries, you should use the **GPT-5 reasoning model** via the Responses API. If you just want quick answers and don’t need that transparency or extra accuracy, GPT-5-Chat is an option (with the traditional Chat Completions API or via ChatGPT’s auto mode). Many have observed that GPT-5-Chat is extremely fast but may sometimes “hallucinate” or make logic mistakes that the reasoning model would catch – this trade-off is by design (speed vs reasoning depth) .

------

## **10) Full Example: Using the Responses API with a Reasoning Model (Python)**

Finally, to illustrate everything in context, here’s a Python example that uses the OpenAI Responses API with a GPT-5 reasoning model. This example will: set up a function tool, ask a question that requires the tool, handle the function call, and provide the final answer – all while preserving the reasoning chain. We’ll use the OpenAI Python SDK for demonstration:

```
import openai

openai.api_key = "YOUR_API_KEY"  # assume API key is set
client = openai.OpenAI()        # Using the OpenAI client (from openai>=0.11.0)

# 1. Define a custom function tool for the model to use.
tools = [
    {
        "type": "function",
        "name": "get_weather",
        "description": "Get current temperature for provided coordinates in Celsius.",
        "parameters": {
            "type": "object",
            "properties": {
                "latitude": {"type": "number"},
                "longitude": {"type": "number"}
            },
            "required": ["latitude", "longitude"],
            "additionalProperties": False
        },
        "strict": True  # enforce argument schema
    }
]

# 2. Ask a question that requires reasoning and tool use.
user_question = "What's the weather like in Paris today?"

# We'll call the reasoning model (e.g. gpt-5-mini or gpt-5) via the Responses API.
response1 = client.responses.create(
    model="gpt-5-mini",                # a GPT-5 reasoning model
    input={"role": "user", "content": user_question},
    tools=tools,
    reasoning={"effort": "medium", "summary": "auto"},  # ask for medium effort and an auto summary
    store=False,  # we'll handle state manually for demonstration
    include=["reasoning.encrypted_content"]  # get encrypted reasoning content since store=False
)

# Print the reasoning summary (if any) for debugging:
reasoning_items = [item for item in response1.output if item.type == "reasoning"]
if reasoning_items:
    summary_parts = reasoning_items[0].summary
    if summary_parts:
        print("Reasoning summary:", summary_parts[0].text)

# The response likely contains a function call because the model doesn't have the weather data:
print("Output items from first response:", [item.type for item in response1.output])
# Expected: ['reasoning', 'function_call']

# 3. Extract the function call details from response1 and execute the function.
function_calls = [item for item in response1.output if item.type == "function_call"]
for func_call in function_calls:
    tool_name = func_call.name  # e.g. "get_weather"
    args = openai.utils.from_openai_json(func_call.arguments)  # parse the JSON string to a dict
    # Execute the corresponding tool (in real use, you'd have an actual implementation):
    if tool_name == "get_weather":
        lat, lon = args.get("latitude"), args.get("longitude")
        # For demo purposes, let's mock this function instead of calling a real API:
        tool_result = 16.3  # pretend it's 16.3°C in Paris
    else:
        tool_result = None

    # Prepare the function call output item to send back to the model
    function_output_item = {
        "type": "function_call_output",
        "call_id": func_call.call_id,
        "output": str(tool_result)
    }

# 4. Append the entire first response output to the context, along with the function result, and query again.
context = [] 
context += response1.output              # include reasoning and the function_call
context.append(function_output_item)     # include the tool's result

response2 = client.responses.create(
    model="gpt-5-mini",
    input=context,    # send the sequence of items from turn 1 as the input for turn 2
    tools=tools,
    store=False,
    include=["reasoning.encrypted_content"]  # carry forward encrypted CoT if any new one generated
)

# The second response should contain the final answer (and possibly another reasoning item).
final_answer = response2.output_text  # shorthand to get the assistant's message text
print("Assistant's answer:", final_answer)

# For completeness, you can inspect if more reasoning or calls were made:
print("Output items from second response:", [item.type for item in response2.output])
# Expected: ['reasoning', 'message'] – the reasoning tokens and the final message.
```

Let’s break down what happened in this example:

- We defined a function get_weather and told the model about it via the tools parameter. This makes the model aware it has this capability .
- We send a user question about Paris weather to the gpt-5-mini model. We set reasoning.effort to “medium” to encourage some reasoning, and summary: "auto" to get a summary of the reasoning . We also used store=False with include=["reasoning.encrypted_content"] to demonstrate a stateless approach (in a real scenario, we could use store=True and skip manually handling encrypted content, but here it shows how to do it) .
- The first response1 likely contains a reasoning item and a function_call item. We printed out the types to confirm this. The reasoning item’s summary (if generated) might say something like *“The model decided it needs the current weather and is calling get_weather with Paris coordinates.”* – we printed it for debugging. The function_call item provides the exact call (get_weather with latitude 48.8566, longitude 2.3522, which are Paris coordinates) .
- We then **executed** the get_weather function in our code. In reality, you’d call a weather API or have logic to fetch the data. We mocked it to return 16.3°C. We then created a function_call_output dictionary with the same call_id from the model’s request and the result as output .
- Next, we built the context for the second call. This context includes everything from the model’s first response (response1.output which has the reasoning and function call) **plus** the function_call_output we just prepared. By doing context += response1.output, we effectively took the list of items and extended our context list. This is exactly how OpenAI’s examples do it to feed the model its own prior step . We then appended the function result item.
- We call client.responses.create again with this context. The model now receives: user question, its own reasoning (encrypted, but it can use it via decryption internally), its function call, and the function result. The model recognizes that it has the data it asked for, so it should continue and formulate a final answer. Indeed, response2 should contain a reasoning item (it may think a bit about how to present the answer) and then a message item with the final answer . We retrieve response2.output_text, which is a convenience to get the assistant’s message text concatenated.
- Finally, we print the assistant’s answer, which might be something like: *“The current temperature in Paris is 16.3°C. If you’d like more details – like humidity, wind speed, or a brief description of the sky – just let me know!”* . This matches the example in the cookbook, indicating the model successfully used the tool and gave a nice answer.

Throughout the process, we maintained full parity with what the model was expecting. We fed it its own reasoning and respected the channel outputs. If we hadn’t included the reasoning or the call in context, the model might have gotten confused or repeated steps. By following the “append the entire output” rule, we ensured a smooth multi-turn tool usage session .

This example demonstrates the **idiomatic use of the Responses API**: we used responses.create, handled response.output items according to their types, and provided the necessary feedback (function results) back to the model. It also covered using reasoning effort and summaries, and working statelessly with encrypted content for compliance – essentially 100% API feature coverage in one flow. In practice, you might simplify this by enabling provider-managed continuity (to avoid manually carrying context) and by having real implementations for tools, but the structure would remain the same.

------

## **11) Conclusion**

When streaming is off, you get everything at once – easier for basic integrations. When streaming is on, you get a play-by-play feed – more dynamic and interactive, but requiring careful handling of the various event types.

As a developer, you should tailor these settings to your use case. For instance, in a debugging or research scenario, you might set reasoning.effort = "high" and reasoning.summary = "detailed" to watch GPT-5 deeply reason and explain itself . In a production assistant that just needs quick answers, you might use effort="minimal" and no summary for speed, and possibly store=true to let OpenAI manage state (or store=false with encryption if user data must not be retained). If your app needs sources (say a QA bot with retrieval), you’ll rely on annotations (e.g. the file_search tool will automatically populate source citations in annotations of the answer ). If your app integrates actions (booking flights, running calculations), you’ll use the tool API and handle function call outputs as described.

------

## **Appendix: Conflicts not raised before**

None.
