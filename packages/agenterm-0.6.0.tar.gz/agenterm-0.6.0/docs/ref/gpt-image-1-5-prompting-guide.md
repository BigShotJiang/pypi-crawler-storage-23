# gpt-image-1.5 Prompting Guide

## 1. Introduction

gpt-image-1.5 is OpenAI's production image model, released December 2025. It is optimized for precision, speed, and instruction following.

**Why 1.5 changes the approach:**

| Behavior | What it means for you |
|----------|----------------------|
| **4× faster** | Defaults are fast enough. No need to start with `quality="low"`. |
| **Automatic high fidelity** | First 5 input images preserved at high fidelity automatically. Explicit `input_fidelity="high"` often unnecessary. |
| **Better instruction following** | Simpler prompts work. The model infers intent. |
| **Dense text rendering** | Handles smaller, denser text reliably. Less need for letter-by-letter spelling. |
| **Consistent edits** | Preserves lighting, composition, identity across chained edits without explicit constraints. |

**Capabilities:**

- Photorealism with natural lighting and accurate materials
- Reliable in-image text rendering
- Structured visuals: infographics, diagrams, UI mockups, multi-panel layouts
- Style transfer with minimal prompting
- World knowledge (infers context—"Bethel, NY, August 1969" → Woodstock)

## 2. The 1.5 Prompting Posture

**Trust the defaults.** The model is fast and follows instructions well. Don't over-engineer.

### When to use parameters

| Parameter | Default | When to override |
|-----------|---------|------------------|
| `quality` | `"auto"` | `"high"` for dense text, infographics, photorealism |
| `size` | `"auto"` | Only when aspect ratio matters (`"1536x1024"` landscape, `"1024x1536"` portrait) |
| `input_fidelity` | `"low"` | `"high"` for complex edits requiring identity/face preservation beyond the automatic first-5-images fidelity |
| `background` | `"auto"` | `"transparent"` for product shots, icons |

### Prompt structure

**Scene/background → Subject → Key details → Constraints**

Include intended use when it helps: "marketing banner", "UI mockup", "children's book illustration".

### The 1.5 difference

- **Less is more.** The model follows instructions. Don't repeat obvious constraints.
- **Skip defensive prompts.** No need for "no watermark" unless the model is adding them.
- **Iterate small.** Start simple, refine with single-change follow-ups.
- **Text in images.** Quotes or ALL CAPS. Typography details only if critical. Letter-by-letter spelling rarely needed now.
- **Multi-image inputs.** Reference by index: "Image 1", "Image 2". Describe interaction.

## 3. Setup (Python SDK)

```python
import os
import base64
from openai import OpenAI

client = OpenAI()

os.makedirs("../../images/input_images", exist_ok=True)
os.makedirs("../../images/output_images", exist_ok=True)

def save_image(result, filename: str) -> None:
    """
    Saves the first returned image to the given filename inside the output_images folder.
    """
    image_base64 = result.data[0].b64_json
    out_path = os.path.join("../../images/output_images", filename)
    with open(out_path, "wb") as f:
        f.write(base64.b64decode(image_base64))
```

Put reference images used for edits into `input_images/` (or update paths in examples).

### 3.1 API Quick Reference

**Generation** — most calls need only `model` + `prompt`:

```python
result = client.images.generate(
    model="gpt-image-1.5",
    prompt="...",
    # Optional (use defaults unless needed):
    # quality="auto",        # "auto" | "low" | "medium" | "high"
    # size="auto",           # "auto" | "1024x1024" | "1536x1024" | "1024x1536"
    # n=1,                   # 1-10
    # output_format="png",   # "png" | "jpeg" | "webp"
    # background="auto",     # "auto" | "transparent" | "opaque"
)
```

**Editing** — simple edits need only `model` + `image` + `prompt`:

```python
result = client.images.edit(
    model="gpt-image-1.5",
    image=[open("input.png", "rb")],  # Up to 16 images, max 50MB each
    prompt="...",
    # Optional:
    # input_fidelity="low",  # "low" | "high" — use "high" for identity preservation
    # quality="auto",
    # mask=open("mask.png", "rb"),  # PNG with alpha channel
)
```

**When to use `input_fidelity="high"` + `quality="high"`:**

Use this combo only for complex edits that must preserve identity/composition through major scene changes:
- Inserting a person into a new scene
- Lighting/weather transformations on faces
- Multi-image compositing with identity preservation
- Object removal while keeping face/identity intact

For simple edits (style transfer, translation, product extraction): defaults are sufficient.

## 4. Use Cases — Generate (text → image)

### 4.1 Infographics

Use for structured information. For dense layouts or heavy in-image text, set quality="high".

```python
prompt = """
Create a detailed Infographic of the functioning and flow of an automatic coffee machine like a Jura.
From bean basket, to grinding, to scale, water tank, boiler, etc.
I'd like to understand technically and visually the flow.
"""

result = client.images.generate(
    model="gpt-image-1.5",
    prompt=prompt,
    quality="high"  # Dense text benefits from high quality
)

save_image(result, "infographic_coffee_machine.png")
```

### 4.2 Photorealistic images that feel natural

Prompt as if a real photo is being captured. Use photography language and ask for real texture (pores, wrinkles, fabric wear, imperfections). Avoid studio polish terms.

```python
prompt = """
Create a photorealistic candid photograph of an elderly sailor standing on a small fishing boat.
He has weathered skin with visible wrinkles, pores, and sun texture, and a few faded traditional sailor tattoos on his arms.
He is calmly adjusting a net while his dog sits nearby on the deck. Shot like a 35mm film photograph, medium close-up at eye level, using a 50mm lens.
Soft coastal daylight, shallow depth of field, subtle film grain, natural color balance.
The image should feel honest and unposed, with real skin texture, worn materials, and everyday detail. No glamorization, no heavy retouching.
"""

result = client.images.generate(
    model="gpt-image-1.5",
    prompt=prompt,
    quality="high"
)

save_image(result, "photorealism.png")
```

### 4.3 World knowledge

Example: Bethel, New York, August 1969 (Woodstock context implied).

```python
prompt = """
Create a realistic outdoor crowd scene in Bethel, New York on August 16, 1969.
Photorealistic, period-accurate clothing, staging, and environment.
"""

result = client.images.generate(
    model="gpt-image-1.5",
    prompt=prompt
)

save_image(result, "world_knowledge.png")
```

### 4.4 Logo generation

Provide clear brand constraints and simplicity. Use `n` for variations.

```python
prompt = """
Create an original, non-infringing logo for a company called Field & Flour, a local bakery.
The logo should feel warm, simple, and timeless. Use clean, vector-like shapes, a strong silhouette, and balanced negative space.
Favor simplicity over detail so it reads clearly at small and large sizes. Flat design, minimal strokes, no gradients unless essential.
Plain background. Deliver a single centered logo with generous padding. No watermark.
"""

result = client.images.generate(
    model="gpt-image-1.5",
    prompt=prompt,
    n=4
)

for i, item in enumerate(result.data, start=1):
    image_bytes = base64.b64decode(item.b64_json)
    with open(f"../../images/output_images/logo_generation_{i}.png", "wb") as f:
        f.write(image_bytes)
```

### 4.5 Story to comic strip

Define the narrative as clear visual beats, one per panel.

```python
prompt = """
Create a short vertical comic-style reel with 4 equal-sized panels.
Panel 1: The owner leaves through the front door. The pet is framed in the window behind them, small against the glass, eyes wide, paws pressed high, the house suddenly quiet.
Panel 2: The door clicks shut. Silence breaks. The pet slowly turns toward the empty house, posture shifting, eyes sharp with possibility.
Panel 3: The house transformed. The pet sprawls across the couch like it owns the place, crumbs nearby, sunlight cutting across the room like a spotlight.
Panel 4: The door opens. The pet is seated perfectly by the entrance, alert and composed, as if nothing happened.
"""

result = client.images.generate(
    model="gpt-image-1.5",
    prompt=prompt
)

save_image(result, "comic_reel.png")
```

### 4.6 UI mockups

Describe the product as if it exists; specify layout and hierarchy.

```python
prompt = """
Create a realistic mobile app UI mockup for a local farmers market.
Show today's market with a simple header, a short list of vendors with small photos and categories, a small "Today's specials" section, and basic information for location and hours.
Design it to be practical, and easy to use. White background, subtle natural accent colors, clear typography, and minimal decoration.
It should look like a real, well-designed, beautiful app for a small local market.
Place the UI mockup in an iPhone frame.
"""

result = client.images.generate(
    model="gpt-image-1.5",
    prompt=prompt
)

save_image(result, "ui_farmers_market.png")
```

## 5. Use Cases — Edit (image + text → image)

**The 1.5 edit pattern:**

| Edit type | Parameters needed |
|-----------|-------------------|
| Simple (style, translation, product) | `model` + `image` + `prompt` only |
| Preservation-critical (identity, composition) | Add `input_fidelity="high"` + `quality="high"` |

The first 5 input images get automatic high fidelity. Explicit `input_fidelity="high"` is for complex edits where you need maximum preservation through major scene changes.

### 5.1 Translation in images

Preserve everything except the text. Keep typography style, placement, spacing, and hierarchy consistent.

```python
prompt = """
Translate the text in the infographic to Spanish. Do not change any other aspect of the image.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    image=[
        open("../../images/output_images/infographic_coffee_machine.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "infographic_coffee_machine_sp.png")
```

### 5.2 Style transfer

Describe what must stay consistent (style cues) and what must change.

```python
prompt = """
Use the same style from the input image and generate a man riding a motorcycle on a white background.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    image=[
        open("../../images/input_images/pixels.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "motorcycle.png")
```

### 5.3 Virtual clothing try-on

Lock identity and change only garments. Preserve lighting and shadows.

```python
prompt = """
Edit the image to dress the woman using the provided clothing images. Do not change her face, facial features, skin tone, body shape, pose, or identity in any way.
Preserve her exact likeness, expression, hairstyle, and proportions. Replace only the clothing, fitting the garments naturally to her existing pose and body geometry with realistic fabric behavior.
Match lighting, shadows, and color temperature to the original photo so the outfit integrates photorealistically, without looking pasted on.
Do not change the background, camera angle, framing, or image quality, and do not add accessories, text, logos, or watermarks.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    image=[
        open("../../images/input_images/woman_in_museum.png", "rb"),
        open("../../images/input_images/tank_top.png", "rb"),
        open("../../images/input_images/jacket.png", "rb"),
        open("../../images/input_images/tank_top.png", "rb"),
        open("../../images/input_images/boots.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "outfit.png")
```

### 5.4 Drawing to image (rendering)

Preserve layout and perspective, add realistic materials and lighting.

```python
prompt = """
Turn this drawing into a photorealistic image.
Preserve the exact layout, proportions, and perspective.
Choose realistic materials and lighting consistent with the sketch intent.
Do not add new elements or text.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    image=[
        open("../../images/input_images/drawings.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "realistic_valley.png")
```

### 5.5 Product mockups (transparent background + label integrity)

Clean silhouette, no halos, preserve label text.

```python
prompt = """
Extract the product from the input image.
Output: transparent background (RGBA PNG), crisp silhouette, no halos/fringing.
Preserve product geometry and label legibility exactly.
Optional: subtle, realistic contact shadow in the alpha (no hard cut line).
Do not restyle the product; only remove background and lightly polish.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    image=[
        open("../../images/input_images/shampoo.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "extract_product.png")
```

### 5.6 Marketing creatives with real text in-image

Put exact copy in quotes, specify typography and placement.

```python
prompt = """
Create a realistic billboard mockup of the shampoo on a highway scene during sunset.
Billboard text (EXACT, verbatim, no extra characters):
"Fresh and clean"
Typography: bold sans-serif, high contrast, centered, clean kerning.
Ensure text appears once and is perfectly legible.
No watermarks, no logos.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    image=[
        open("../../images/input_images/shampoo.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "billboard.png")
```

### 5.7 Lighting and weather transformation

Change only environmental conditions; preserve identity and layout.

```python
prompt = """
Make it look like a winter evening with snowfall.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    input_fidelity="high",
    quality="high",
    image=[
        open("../../images/output_images/billboard.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "billboard_winter.png")
```

### 5.8 Object removal / small edits

Use explicit change-only language.

```python
prompt = """
Remove the red stripes from the white t-shirt of the man. Do not change anything else.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    input_fidelity="high",
    quality="high",
    image=[
        open("../../images/output_images/man_with_blue_hat.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "man_no_stripes.png")
```

### 5.9 Insert a person into a scene

Anchor realism, lock identity, avoid cinematic grading.

```python
prompt = """
Generate a highly realistic action scene where this person is running away from a large, realistic brown bear attacking a campsite. The image should look like a real photograph someone could have taken, not an overly enhanced or cinematic movie-poster image.
She is centered in the image but looking away from the camera, wearing outdoorsy camping attire, with dirt on her face and tears in her clothing. She is clearly afraid but focused on escaping, running away from the bear as it destroys the campsite behind her.
The campsite is in Yosemite National Park, with believable natural details. The time of day is dusk, with natural lighting and realistic colors. Everything should feel grounded, authentic, and unstyled, as if captured in a real moment. Avoid cinematic lighting, dramatic color grading, or stylized composition.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    input_fidelity="high",
    quality="high",
    image=[
        open("../../images/input_images/woman_in_museum.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "scene.png")
```

### 5.10 Multi-image referencing and compositing

Specify which elements move where and preserve lighting/perspective.

```python
prompt = """
Place the dog from the second image into the setting of image 1, right next to the woman, use the same style of lighting, composition and background. Do not change anything else.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    input_fidelity="high",
    quality="high",
    image=[
        open("../../images/output_images/test_woman.png", "rb"),
        open("../../images/output_images/test_woman_2.png", "rb"),
    ],
    prompt=prompt
)

save_image(result, "test_woman_with_dog.png")
```

## 6. Additional High-Value Use Cases

### 6.1 Interior design swap (precision edits)

```python
prompt = """
In this room photo, replace ONLY the white chairs with wooden chairs.
Preserve camera angle, room lighting, floor shadows, and surrounding objects.
Keep all other aspects of the image unchanged.
Photorealistic contact shadows and fabric texture.
"""

result = client.images.edit(
    model="gpt-image-1.5",
    image=[
        open("../../images/input_images/kitchen.jpeg", "rb"),
    ],
    prompt=prompt
)

save_image(result, "kitchen-chairs.png")
```

### 6.2 3D pop-up holiday card (product-style mock)

```python
scene_description = (
    "a cozy Christmas scene with an old teddy bear sitting inside a keepsake box, "
    "slightly worn fur, soft stitching repairs, placed near a window with falling snow outside. "
    "The scene suggests the child has grown up, but the memories remain."
)

short_copy = "Merry Christmas -- some memories never fade."

prompt = f"""
Create a Christmas holiday card illustration.

Scene:
{scene_description}

Mood:
Warm, nostalgic, gentle, emotional.

Style:
Premium holiday card photography, soft cinematic lighting,
realistic textures, shallow depth of field,
tasteful bokeh lights, high print-quality composition.

Constraints:
- Original artwork only
- No trademarks
- No watermarks
- No logos

Include ONLY this card text (verbatim):
"{short_copy}"
"""

result = client.images.generate(
    model="gpt-image-1.5",
    prompt=prompt,
)

save_image(result, "christmas_holiday_card_teddy.png")
```

### 6.3 Collectible action figure / plush keychain (merch concept)

```python
character_description = (
    "a vintage-style toy propeller airplane with rounded wings, "
    "a front-mounted spinning propeller, slightly worn paint edges, "
    "classic childhood proportions, designed as a nostalgic holiday collectible"
)

short_copy = "Christmas Memories Edition"

prompt = f"""
Create a collectible action figure of {character_description}, in blister packaging.

Concept:
A nostalgic holiday collectible inspired by the simple toy airplanes
children used to play with during winter holidays.
Evokes warmth, imagination, and childhood wonder.

Style:
Premium toy photography, realistic plastic and painted metal textures,
studio lighting, shallow depth of field,
sharp label printing, high-end retail presentation.

Constraints:
- Original design only
- No trademarks
- No watermarks
- No logos

Include ONLY this packaging text (verbatim):
"{short_copy}"
"""

result = client.images.generate(
    model="gpt-image-1.5",
    prompt=prompt,
)

save_image(result, "christmas_collectible_toy_airplane.png")
```

### 6.4 Childrens book art with character consistency

Use a character anchor, then reuse it via edit for subsequent pages.

```python
# Character anchor
prompt = """
Create a childrens book illustration introducing a main character.

Character:
A young, storybook-style hero inspired by a little forest outlaw,
wearing a simple green hooded tunic, soft brown boots, and a small belt pouch.
The character has a kind expression, gentle eyes, and a brave but warm demeanor.
Carries a small wooden bow used only for helping, never harming.

Theme:
The character protects and rescues small forest animals like squirrels, birds, and rabbits.

Style:
Childrens book illustration, hand-painted watercolor look,
soft outlines, warm earthy colors, whimsical and friendly.
Proportions suitable for picture books (slightly oversized head, expressive face).

Constraints:
- Original character (no copyrighted characters)
- No text
- No watermarks
- Plain forest background to clearly showcase the character
"""

result = client.images.generate(
    model="gpt-image-1.5",
    prompt=prompt,
)

save_image(result, "childrens_book_illustration_1.png")
```

```python
# Story continuation
prompt = """
Continue the childrens book story using the same character.

Scene:
The same young forest hero is gently helping a frightened squirrel
out of a fallen tree after a winter storm.
The character kneels beside the squirrel, offering reassurance.

Character Consistency:
- Same green hooded tunic
- Same facial features, proportions, and color palette
- Same gentle, heroic personality

Style:
Childrens book watercolor illustration,
soft lighting, snowy forest environment,
warm and comforting mood.

Constraints:
- Do not redesign the character
- No text
- No watermarks
"""

result = client.images.edit(
    model="gpt-image-1.5",
    image=[
        open("../../images/output_images/childrens_book_illustration_1.png", "rb"),
    ],
    prompt=prompt,
)

save_image(result, "childrens_book_illustration_2.png")
```

## 7. Summary

**The 1.5 posture:**

1. **Trust defaults.** `quality="auto"` and `input_fidelity="low"` work for most cases.
2. **Simpler prompts.** Better instruction following means less over-specification.
3. **Automatic fidelity.** First 5 input images preserved at high fidelity automatically.
4. **Explicit preservation only when needed.** Use `input_fidelity="high"` + `quality="high"` only for complex identity-critical edits.
5. **Iterate small.** Start clean, refine with single changes.

The model is smarter. Prompt directly.
