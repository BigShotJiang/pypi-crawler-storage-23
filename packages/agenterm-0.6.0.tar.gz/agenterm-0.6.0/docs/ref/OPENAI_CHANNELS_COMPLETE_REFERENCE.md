# OpenAI Channels Architecture: Complete Reference
> Reference snapshot (2025-09-08).
>
> This document is **not maintained in lockstep** with this repo’s current runtime
> dependencies (for authoritative, current vendor citations see `ARCH.md`).
> Treat any `.venv/...` paths and SDK version numbers below as **historical**
> environment citations from the snapshot date, not as guarantees about the
> present checkout.

*Last Updated: 2025-09-08*
*Sources: responses_ref.md, OpenAI Python SDK source code (snapshot), Harmony format specifications*

## Table of Contents
1. [Executive Summary](#executive-summary)
2. [The Three-Channel Model Architecture](#the-three-channel-model-architecture)
3. [Channel Definitions and Purposes](#channel-definitions-and-purposes)
4. [What Actually Happens at the API Level](#what-actually-happens-at-the-api-level)
5. [The Transformation Layer](#the-transformation-layer)
6. [Tool Calling Patterns Across Channels](#tool-calling-patterns-across-channels)
7. [Developer Accessibility Matrix](#developer-accessibility-matrix)
8. [Source Code Citations](#source-code-citations)
9. [Common Misconceptions](#common-misconceptions)
10. [Practical Implications](#practical-implications)

---

## Executive Summary

The OpenAI three-channel architecture (analysis, commentary, final) is a **training and inference concept** that exists internally within GPT-5 series and reasoning models (o3, o4-mini). However, **these channels are NOT exposed through the Responses API**. Instead, the API provides a sanitized, structured view where channel information is completely abstracted into typed output items.

### Key Facts:
- **Channels exist**: In model training and internal processing
- **Channels DON'T exist**: In the API responses you receive
- **You CAN access**: Final messages, function calls (as items), reasoning summaries
- **You CANNOT access**: Raw analysis text, commentary preambles, channel markers

---

## The Three-Channel Model Architecture

### Historical Context
The GPT-5 series models were trained using the **"Harmony" response format**, which explicitly teaches models to segregate their outputs into three distinct channels. This architecture was designed to solve fundamental problems:
1. Allow unconstrained internal reasoning while ensuring safe outputs
2. Separate thinking from tool interaction from user communication
3. Enable better RLHF training by evaluating different aspects separately

### Channel Token Markers
During training, models learned to output special tokens:
```
<|start|>assistant<|channel|>analysis<|message|>
[Internal reasoning content]
<|end|>

<|start|>assistant<|channel|>commentary<|message|>
[Tool interaction content]
<|end|>

<|start|>assistant<|channel|>final<|message|>
[User-facing content]
<|end|>
```

---

## Channel Definitions and Purposes

### 1. Analysis Channel
**Purpose**: The model's private thinking workspace

**Characteristics**:
- Contains chain-of-thought reasoning
- Unfiltered and unmoderated content
- May include sensitive reasoning or coarse heuristics
- Not bound by safety guidelines
- Never directly visible to end users

**Content Examples**:
```
"The user is asking about Paris weather. I need to:
1. Get the coordinates for Paris
2. Call the weather function
3. Format the response nicely
Paris coordinates are approximately 48.8566°N, 2.3522°E..."
```

**When Used**:
- Problem decomposition
- Multi-step reasoning
- Hypothesis exploration
- Built-in tool invocation (usually)

**Source Reference**: docs/ref/responses_ref.md:67-68, 78-79

### 2. Commentary Channel
**Purpose**: Bridge between pure thought and structured actions

**Characteristics**:
- Contains structured outputs (often JSON)
- Tool directives and function calls
- Multi-step planning preambles
- Hidden from end users
- More structured than analysis, less polished than final

**Content Examples**:
```
"I will now call the weather function for Paris, then format the results."
{"function": "get_weather", "args": {"latitude": 48.8566, "longitude": 2.3522}}
```

**When Used**:
- Developer-defined function calls (ALWAYS)
- Built-in tool calls (SOMETIMES)
- Multi-tool orchestration planning
- Structured output generation

**Source Reference**: docs/ref/responses_ref.md:69, 79-80

### 3. Final Channel
**Purpose**: The only user-facing output

**Characteristics**:
- Fully moderated and safe
- Polished, coherent responses
- Adheres to all safety guidelines
- The ONLY channel visible to end users
- Contains the actual assistant response

**Content Examples**:
```
"The current temperature in Paris is 16.3°C with partly cloudy skies. 
The humidity is at 65% with light winds from the west."
```

**When Used**:
- All user-facing responses
- After reasoning and tool use complete
- Final answers and explanations

**Source Reference**: docs/ref/responses_ref.md:70, 81

---

## What Actually Happens at the API Level

### The Reality: No Channels in API

**Source Code Citations** (example local `.venv/.../site-packages/openai/` tree):
```python
# From response.py:86-94
output: List[ResponseOutputItem]
"""An array of content items generated by the model."""

# Search for "channel" in entire OpenAI library: 0 matches
```

### What You Actually Receive

The Responses API returns a `Response` object with an `output` array containing typed items:

```python
ResponseOutputItem = Union[
    ResponseOutputMessage,        # Final channel → assistant message
    ResponseReasoningItem,        # Analysis channel → summary only
    ResponseFunctionToolCall,     # Commentary channel → function call
    ResponseFileSearchToolCall,   # Various tool calls
    ResponseCodeInterpreterToolCall,
    ResponseWebSearchCall,
    # ... other tool types
]
```

### Data Structure Mapping

| Internal Channel | API Output Type | What You Get | What's Hidden |
|-----------------|-----------------|--------------|---------------|
| Analysis | ResponseReasoningItem | Optional summary text | Raw reasoning tokens |
| Commentary | ResponseFunctionToolCall | Function name & args | Preambles, planning text |
| Final | ResponseOutputMessage | Complete message | Nothing (fully visible) |

---

## The Transformation Layer

### How Internal Channels Become API Items

```
INTERNAL PROCESSING                    API TRANSFORMATION                    YOUR RESPONSE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

<|channel|>analysis                                                        
"User wants weather. Need to          ──────────►  ResponseReasoningItem {
check Paris coordinates first.                        summary: ["Analyzed weather
Paris is at 48.85°N, 2.35°E"                         request for Paris"],
                                                      encrypted_content: "gAAA..."
                                                    }

<|channel|>commentary                               
"Calling weather function now"         ──────────►  [Preamble text discarded]
{"function": "get_weather",            ──────────►  ResponseFunctionToolCall {
 "args": {"lat": 48.85,                               name: "get_weather",
          "lon": 2.35}}                               arguments: "{\"lat\":48.85...}"
                                                    }

<|channel|>final                                   
"The temperature in Paris              ──────────►  ResponseOutputMessage {
is 16°C with cloudy skies."                          role: "assistant",
                                                      content: [{
                                                        text: "The temperature..."
                                                      }]
                                                    }
```

### Key Transformations

1. **Analysis → ResponseReasoningItem**
   - Raw tokens: NEVER exposed (safety)
   - Summary: Optional, generated on request
   - Encrypted content: For stateless continuity

2. **Commentary → ResponseFunctionToolCall**
   - Preambles: DISCARDED
   - JSON calls: Preserved as structured items
   - Planning text: LOST

3. **Final → ResponseOutputMessage**
   - Content: Fully preserved
   - Annotations: Attached as metadata
   - Status: Tracked (in_progress, completed)

---

## Tool Calling Patterns Across Channels

### Built-in Tools (browser, python, file_search)

**Internal Behavior**:
```
<|channel|>analysis
"I need to search for information about quantum computing"
<|browser_call|>search("quantum computing recent advances")
"Found several results, analyzing..."
```

**API Output**:
```json
{
  "type": "web_search_call",
  "query": "quantum computing recent advances",
  "results": [...]
}
```

**Key Point**: Built-in tools USUALLY originate from analysis channel

### Developer-Defined Functions

**Internal Behavior**:
```
<|channel|>commentary
"I need to call the custom weather function"
{"function": "get_weather", "args": {"city": "Paris"}}
```

**API Output**:
```json
{
  "type": "function_call",
  "name": "get_weather",
  "arguments": "{\"city\": \"Paris\"}",
  "call_id": "call_abc123"
}
```

**Key Point**: Custom functions ALWAYS go through commentary channel

### Multi-Tool Orchestration

**Internal Behavior**:
```
<|channel|>commentary
"I'll first get weather for Paris, then London, then compare"
{"function": "get_weather", "args": {"city": "Paris"}}
{"function": "get_weather", "args": {"city": "London"}}
```

**API Output**:
```json
[
  {"type": "function_call", "name": "get_weather", "arguments": "{\"city\":\"Paris\"}"},
  {"type": "function_call", "name": "get_weather", "arguments": "{\"city\":\"London\"}"}
]
```

**Key Point**: Planning text is lost, only function calls remain

---

## Developer Accessibility Matrix

### What You CAN Access

| Component | How to Access | Format | Completeness |
|-----------|--------------|--------|--------------|
| Final answers | `response.output` → `ResponseOutputMessage` | Full text | 100% |
| Function calls | `response.output` → `ResponseFunctionToolCall` | JSON | Args only, no context |
| Reasoning summary | `response.output` → `ResponseReasoningItem.summary` | Text | Condensed |
| Tool results | Function call outputs | Structured | 100% |
| Encrypted reasoning | `ResponseReasoningItem.encrypted_content` | Base64 blob | Encrypted |

### What You CANNOT Access

| Component | Why Hidden | Workaround |
|-----------|------------|------------|
| Raw analysis text | Safety, unfiltered content | Request reasoning summary |
| Commentary preambles | Not useful for execution | None |
| Channel markers | Internal tokens | None |
| Planning narratives | Redundant with function calls | None |
| Internal tool thoughts | Part of analysis | Reasoning summary might include |

### Special Cases

**Streaming Mode**:
- Still no channel access
- Events arrive sequentially
- Can detect function calls as they happen
- Cannot see channel switches

**Low-Level Parsing** (theoretical):
- Would require direct token access
- OpenAI API doesn't provide this
- Harmony parser exists but needs raw tokens

---

## Source Code Citations

### From OpenAI Python SDK v1.102.0

**No Channel Exposure**:
```bash
# Search results from example `.venv/.../site-packages/openai/` tree
grep -r "channel" . → 0 matches
grep -r "commentary" . → 0 matches
grep -r "analysis" . → 0 matches (in this context)
```

**Response Structure** (response.py):
```python
class Response(BaseModel):
    output: List[ResponseOutputItem]  # No channel information
    # ... other fields
```

**Output Items** (response_output_item.py):
```python
ResponseOutputItem = Union[
    ResponseOutputMessage,       # Just role and content
    ResponseReasoningItem,       # Just summary and encrypted
    ResponseFunctionToolCall,    # Just name and arguments
    # ... no channel field anywhere
]
```

**Reasoning Item** (response_reasoning_item.py):
```python
class ResponseReasoningItem(BaseModel):
    summary: List[Summary]              # Generated summary
    encrypted_content: Optional[str]    # Encrypted blob
    # No "channel" field
```

---

## Common Misconceptions

### Misconception 1: "I can access commentary channel for debugging"
**Reality**: Commentary content is transformed into function call items. Preambles are discarded.

### Misconception 2: "Reasoning summaries come from a specific channel"
**Reality**: Summaries are metadata ABOUT the analysis channel, not FROM any channel.

### Misconception 3: "Built-in tools always use analysis channel"
**Reality**: Documentation says "usually" - there can be exceptions.

### Misconception 4: "I can see channels in streaming mode"
**Reality**: Streaming provides the same items, just incrementally. No channel info.

### Misconception 5: "The API hides channels for my protection"
**Reality**: Channels are abstracted for safety AND simplicity. Raw analysis could contain harmful content.

---

## Practical Implications

### For Developers

1. **You work with items, not channels**
   - Think in terms of output types
   - Don't expect channel information
   - Use type discrimination for handling

2. **Function context is lost**
   - You get function calls but not the "why"
   - Planning text doesn't survive transformation
   - Design your functions to be self-contained

3. **Reasoning is optional metadata**
   - Request summaries if needed
   - Don't rely on reasoning for logic
   - Summaries cost tokens but aren't charged extra

### For System Design

1. **Stateless continuity requires encryption**
   - Use `encrypted_content` for zero-retention
   - Pass encrypted blobs between calls
   - Never attempt to decrypt (you can't)

2. **Tool orchestration is implicit**
   - Model plans internally
   - You see only the execution sequence
   - Trust the model's orchestration

3. **Safety is built into the architecture**
   - Analysis can explore dangerous ideas
   - Final channel is always safe
   - This is by design, not limitation

### For Understanding Model Behavior

1. **Three-channel thinking is real**
   - Models genuinely process in channels
   - This affects response quality
   - Higher reasoning_effort = more analysis

2. **Commentary is the "API layer"**
   - Where structured interaction happens
   - JSON formatting occurs here
   - Bridge between thought and action

3. **Final channel is the "presentation layer"**
   - Polished, user-ready content
   - All safety filters applied
   - The only guaranteed visible output

---

## Appendix: Example API Response

Here's what you actually receive from the Responses API:

```json
{
  "id": "resp_abc123",
  "model": "o4-mini",
  "output": [
    {
      "type": "reasoning",
      "id": "rs_def456",
      "summary": [{
        "text": "I analyzed the request for weather information...",
        "type": "summary_text"
      }],
      "encrypted_content": "gAAAABkX..."
    },
    {
      "type": "function_call",
      "name": "get_weather",
      "arguments": "{\"latitude\": 48.8566, \"longitude\": 2.3522}",
      "call_id": "call_ghi789",
      "status": "completed"
    },
    {
      "type": "message",
      "role": "assistant",
      "content": [{
        "text": "The current temperature in Paris is 16°C...",
        "type": "output_text"
      }],
      "status": "completed"
    }
  ],
  "usage": {
    "prompt_tokens": 50,
    "completion_tokens": 200,
    "reasoning_tokens": 150
  }
}
```

**Note**: No "channel" field anywhere. The three-channel architecture lives only in the model's training and internal processing, not in the API.

---

## References

1. **Primary Sources**:
   - `/docs/ref/responses_ref.md` (Local documentation)
   - OpenAI Python SDK v1.102.0 (Source code analysis)
   - GitHub: openai/harmony (Harmony format specification)
   - GitHub: openai/openai-cookbook (Harmony article)

2. **Key Files Examined**:
   - `.venv/.../openai/types/responses/response.py`
   - `.venv/.../openai/types/responses/response_output_item.py`
   - `.venv/.../openai/types/responses/response_reasoning_item.py`
   - `.venv/.../openai/types/responses/response_function_tool_call.py`

3. **Documentation Sections**:
   - responses_ref.md:66-82 (Channels overview)
   - responses_ref.md:159-163 (Reasoning summaries)
   - responses_ref.md:183-201 (Encrypted reasoning)

---

*End of Reference Document*
