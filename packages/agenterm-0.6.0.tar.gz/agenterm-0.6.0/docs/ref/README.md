# Reference docs

This directory contains background material and upstream references. These files
are not canonical; they may lag the runtime or vendor SDKs. Canonical contracts
live in `ARCH.md` and `README.md`.

Contents:

- `responses_ref.md` - Responses API reference snapshot.
- `openai-harmony-cookbook.md` - Harmony format background.
- `OPENAI_CHANNELS_COMPLETE_REFERENCE.md` - channel semantics reference.
- `gpt-image-1-5-prompting-guide.md` - image prompting reference.
- `gpt-5-prompting-guide.pdf` - GPT-5 prompting reference (snapshot).
- `agent-instruction-templates.md` - starter instruction templates.
- `response-input-example.yaml` - raw Responses input example.
- `shell_apply_patch/` - tool-specific reference docs.
