#!/usr/bin/env python3
"""Generate docs/repl.html from actual color tokens.

Run: uv run docs/generate_repl_reference.py
"""

from __future__ import annotations

import sys
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from agenterm.ui.color_tokens import COLOR_TOKENS_DARK, COLOR_TOKENS_LIGHT
from agenterm.ui.tui.theme import _TOKENS_DARK, _TOKENS_LIGHT


def generate_html() -> str:
    """Generate the complete HTML reference from actual token values."""

    # Extract all token values
    dark = {
        # Semantic colors
        "good": COLOR_TOKENS_DARK.good,
        "warn": COLOR_TOKENS_DARK.warn,
        "error": COLOR_TOKENS_DARK.error,
        "primary": COLOR_TOKENS_DARK.primary,
        "secondary": COLOR_TOKENS_DARK.secondary,
        "muted": COLOR_TOKENS_DARK.muted,
        "accent": COLOR_TOKENS_DARK.accent,
        "surface": COLOR_TOKENS_DARK.surface,
        "surface_alt": COLOR_TOKENS_DARK.surface_alt,
        # TUI tokens
        "toolbar_bg": _TOKENS_DARK.toolbar_bg,
        "toolbar_fg": _TOKENS_DARK.toolbar_fg,
        "dim": _TOKENS_DARK.dim,
        "brand": _TOKENS_DARK.brand,
        "phase": _TOKENS_DARK.phase,
        "model": _TOKENS_DARK.model,
        "key": _TOKENS_DARK.key,
        "value": _TOKENS_DARK.value,
        "sep": _TOKENS_DARK.sep,
        "surface_bg": _TOKENS_DARK.surface_bg,
        "surface_fg": _TOKENS_DARK.surface_fg,
        "surface_alt_bg": _TOKENS_DARK.surface_alt_bg,
        "surface_alt_fg": _TOKENS_DARK.surface_alt_fg,
        "surface_meta_bg": _TOKENS_DARK.surface_meta_bg,
        "surface_meta_fg": _TOKENS_DARK.surface_meta_fg,
        "input_bg": _TOKENS_DARK.input_bg,
        "input_fg": _TOKENS_DARK.input_fg,
        "menu_bg": _TOKENS_DARK.menu_bg,
        "menu_fg": _TOKENS_DARK.menu_fg,
        "menu_alt_bg": _TOKENS_DARK.menu_alt_bg,
        "menu_alt_fg": _TOKENS_DARK.menu_alt_fg,
        "menu_meta_fg": _TOKENS_DARK.menu_meta_fg,
        "scrollbar_bg": _TOKENS_DARK.scrollbar_bg,
        "scrollbar_button": _TOKENS_DARK.scrollbar_button,
        "search_bg": _TOKENS_DARK.search_bg,
        "search_fg": _TOKENS_DARK.search_fg,
        "selection_bg": _TOKENS_DARK.selection_bg,
        "selection_fg": _TOKENS_DARK.selection_fg,
        "cursor_line_bg": _TOKENS_DARK.cursor_line_bg,
        "bracket_bg": _TOKENS_DARK.bracket_bg,
        "bracket_fg": _TOKENS_DARK.bracket_fg,
    }

    light = {
        # Semantic colors
        "good": COLOR_TOKENS_LIGHT.good,
        "warn": COLOR_TOKENS_LIGHT.warn,
        "error": COLOR_TOKENS_LIGHT.error,
        "primary": COLOR_TOKENS_LIGHT.primary,
        "secondary": COLOR_TOKENS_LIGHT.secondary,
        "muted": COLOR_TOKENS_LIGHT.muted,
        "accent": COLOR_TOKENS_LIGHT.accent,
        "surface": COLOR_TOKENS_LIGHT.surface,
        "surface_alt": COLOR_TOKENS_LIGHT.surface_alt,
        # TUI tokens
        "toolbar_bg": _TOKENS_LIGHT.toolbar_bg,
        "toolbar_fg": _TOKENS_LIGHT.toolbar_fg,
        "dim": _TOKENS_LIGHT.dim,
        "brand": _TOKENS_LIGHT.brand,
        "phase": _TOKENS_LIGHT.phase,
        "model": _TOKENS_LIGHT.model,
        "key": _TOKENS_LIGHT.key,
        "value": _TOKENS_LIGHT.value,
        "sep": _TOKENS_LIGHT.sep,
        "surface_bg": _TOKENS_LIGHT.surface_bg,
        "surface_fg": _TOKENS_LIGHT.surface_fg,
        "surface_alt_bg": _TOKENS_LIGHT.surface_alt_bg,
        "surface_alt_fg": _TOKENS_LIGHT.surface_alt_fg,
        "surface_meta_bg": _TOKENS_LIGHT.surface_meta_bg,
        "surface_meta_fg": _TOKENS_LIGHT.surface_meta_fg,
        "input_bg": _TOKENS_LIGHT.input_bg,
        "input_fg": _TOKENS_LIGHT.input_fg,
        "menu_bg": _TOKENS_LIGHT.menu_bg,
        "menu_fg": _TOKENS_LIGHT.menu_fg,
        "menu_alt_bg": _TOKENS_LIGHT.menu_alt_bg,
        "menu_alt_fg": _TOKENS_LIGHT.menu_alt_fg,
        "menu_meta_fg": _TOKENS_LIGHT.menu_meta_fg,
        "scrollbar_bg": _TOKENS_LIGHT.scrollbar_bg,
        "scrollbar_button": _TOKENS_LIGHT.scrollbar_button,
        "search_bg": _TOKENS_LIGHT.search_bg,
        "search_fg": _TOKENS_LIGHT.search_fg,
        "selection_bg": _TOKENS_LIGHT.selection_bg,
        "selection_fg": _TOKENS_LIGHT.selection_fg,
        "cursor_line_bg": _TOKENS_LIGHT.cursor_line_bg,
        "bracket_bg": _TOKENS_LIGHT.bracket_bg,
        "bracket_fg": _TOKENS_LIGHT.bracket_fg,
    }

    # Generate CSS custom properties
    def css_vars(prefix: str, tokens: dict[str, str]) -> str:
        return "\n".join(f"      --{prefix}-{k.replace('_', '-')}: {v};" for k, v in tokens.items())

    dark_vars = css_vars("dark", dark)
    light_vars = css_vars("light", light)

    # Generate color swatches
    def swatch(name: str, color: str, style_ref: str) -> str:
        return f'''      <div class="color-swatch">
        <div class="swatch-box" style="background: {color};"></div>
        <div class="swatch-info">
          <div class="swatch-name">{name}</div>
          <div class="swatch-hex">{color}</div>
          <div class="style-ref">{style_ref}</div>
        </div>
      </div>'''

    # Token to style mapping
    style_refs = {
        "surface_bg": "transcript bg, indicator bg",
        "surface_fg": "transcript.assistant",
        "key": "transcript.user, transcript.label, toolbar.key",
        "dim": "transcript.meta, .separator, .system, placeholder",
        "brand": "prompt.chevron, modal.title",
        "phase": "indicator.active, toolbar.phase",
        "toolbar_bg": "bottom-toolbar bg",
        "toolbar_fg": "bottom-toolbar fg",
        "input_bg": "input-area bg",
        "input_fg": "input-area fg",
        "value": "toolbar.value, toolbar.agent",
        "model": "toolbar.model",
        "sep": "toolbar.sep",
        "good": "status ok, toolbar.good",
        "warn": "placeholder.warn, toolbar.warn",
        "error": "status fail, toolbar.auto",
        "menu_bg": "completion-menu bg",
        "menu_fg": "completion-menu fg",
        "menu_alt_bg": "completion-menu.current bg",
        "menu_alt_fg": "completion-menu.current fg",
        "menu_meta_fg": "completion-menu.meta",
        "surface_alt_bg": "selected/hover bg",
        "surface_alt_fg": "selected/hover fg",
        "surface_meta_bg": "modal bg",
        "surface_meta_fg": "modal fg",
        "scrollbar_bg": "scrollbar.background",
        "scrollbar_button": "scrollbar.button",
        "search_bg": "search highlight bg",
        "search_fg": "search highlight fg",
        "selection_bg": "text selection bg",
        "selection_fg": "text selection fg",
        "cursor_line_bg": "cursor-line bg",
        "bracket_bg": "matching-bracket bg",
        "bracket_fg": "matching-bracket fg",
        "primary": "semantic: primary text",
        "secondary": "semantic: secondary text",
        "muted": "semantic: muted text",
        "accent": "semantic: accent",
        "surface": "semantic: surface",
        "surface_alt": "semantic: surface alt",
    }

    dark_swatches = "\n".join(swatch(k, v, style_refs.get(k, "")) for k, v in dark.items())
    light_swatches = "\n".join(swatch(k, v, style_refs.get(k, "")) for k, v in light.items())

    return f'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agenterm REPL Color Reference</title>
  <meta name="generator" content="docs/generate_repl_reference.py">
  <style>
    /* === FONT === */
    @import url('https://fonts.googleapis.com/css2?family=Victor+Mono:ital,wght@0,400;0,700;1,400;1,700&display=swap');

    :root {{
      /* Dark Theme - Generated from color_tokens.py + tui/theme.py */
{dark_vars}

      /* Light Theme - Generated from color_tokens.py + tui/theme.py */
{light_vars}
    }}

    * {{ box-sizing: border-box; margin: 0; padding: 0; }}

    body {{
      font-family: 'Victor Mono', 'SF Mono', 'Monaco', monospace;
      font-size: 13px;
      line-height: 1.5;
      background: #1a1a1a;
      padding: 20px;
    }}

    h1 {{ color: #fff; margin-bottom: 10px; font-weight: 400; font-size: 18px; }}
    h2 {{ color: #888; font-size: 12px; font-weight: 400; margin: 20px 0 10px 0; text-transform: uppercase; letter-spacing: 1px; }}
    h3 {{ color: #666; font-size: 11px; font-weight: 400; margin: 15px 0 8px 0; }}
    .generator-note {{ color: #555; font-size: 11px; margin-bottom: 20px; }}

    .theme-toggle {{
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
    }}
    .theme-toggle button {{
      font-family: inherit;
      font-size: 12px;
      padding: 8px 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }}
    .theme-toggle button.dark {{
      background: var(--dark-surface-bg);
      color: var(--dark-brand);
      border: 1px solid var(--dark-sep);
    }}
    .theme-toggle button.light {{
      background: var(--light-surface-bg);
      color: var(--light-brand);
      border: 1px solid var(--light-sep);
    }}
    .theme-toggle button.active {{
      outline: 2px solid currentColor;
      outline-offset: 2px;
    }}

    .repl-container {{
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      max-width: 900px;
      margin-bottom: 20px;
    }}

    /* ============================================================
       DARK THEME STYLES
       Source: tui/theme.py _style_for_tokens()
       ============================================================ */
    .repl-container.dark {{
      background: var(--dark-surface-bg);
      color: var(--dark-surface-fg);
    }}
    .dark .transcript {{ background: var(--dark-surface-bg); padding: 16px; }}

    /* transcript.user: bold {{tokens.key}} */
    .dark .transcript-user {{ color: var(--dark-key); font-weight: 700; }}

    /* transcript.assistant: {{tokens.surface_fg}} */
    .dark .transcript-assistant {{ color: var(--dark-surface-fg); }}

    /* transcript.label: bold {{tokens.key}} */
    .dark .transcript-label {{ color: var(--dark-key); font-weight: 700; }}

    /* transcript.meta: {{tokens.dim}} */
    .dark .transcript-meta {{ color: var(--dark-dim); }}

    /* transcript.separator: {{tokens.dim}} */
    .dark .transcript-separator {{ color: var(--dark-dim); margin: 12px 0; }}

    /* transcript.system: {{tokens.dim}} */
    .dark .transcript-system {{ color: var(--dark-dim); }}

    /* Status markers */
    .dark .status-ok {{ color: var(--dark-good); }}
    .dark .status-fail {{ color: var(--dark-error); }}

    /* indicator.idle, indicator.active */
    .dark .indicator-line {{ background: var(--dark-surface-bg); padding: 4px 16px; }}
    .dark .indicator-idle {{ color: var(--dark-dim); }}
    .dark .indicator-active {{ color: var(--dark-phase); font-weight: 700; }}

    /* input-area: bg:{{tokens.input_bg}} {{tokens.input_fg}} */
    .dark .prompt-area {{
      background: var(--dark-input-bg);
      padding: 12px 16px;
      border-top: 1px solid var(--dark-sep);
    }}

    /* prompt.chevron: bold {{tokens.brand}} */
    .dark .prompt-chevron {{ color: var(--dark-brand); font-weight: 700; }}

    /* placeholder: italic {{tokens.dim}} */
    .dark .placeholder {{ color: var(--dark-dim); font-style: italic; }}

    /* placeholder.warn: italic bold {{tokens.warn}} */
    .dark .placeholder-warn {{ color: var(--dark-warn); font-style: italic; font-weight: 700; }}

    /* bottom-toolbar: bg:{{tokens.toolbar_bg}} {{tokens.toolbar_fg}} */
    .dark .toolbar {{
      background: var(--dark-toolbar-bg);
      color: var(--dark-toolbar-fg);
      padding: 8px 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }}
    .dark .toolbar-key {{ color: var(--dark-key); font-weight: 700; }}
    .dark .toolbar-agent {{ color: var(--dark-value); font-weight: 700; }}
    .dark .toolbar-model {{ color: var(--dark-model); font-weight: 700; }}
    .dark .toolbar-sep {{ color: var(--dark-sep); }}
    .dark .toolbar-value {{ color: var(--dark-value); }}
    .dark .toolbar-phase {{ color: var(--dark-phase); font-weight: 700; }}
    .dark .toolbar-good {{ color: var(--dark-good); font-weight: 700; }}
    .dark .toolbar-warn {{ color: var(--dark-warn); font-weight: 700; }}
    .dark .toolbar-auto {{ color: var(--dark-error); font-weight: 700; }}

    /* completion-menu styles */
    .dark .menu-popup {{
      background: var(--dark-menu-bg);
      color: var(--dark-menu-fg);
      border: 1px solid var(--dark-sep);
      border-radius: 4px;
      padding: 4px 0;
      margin: 8px 16px;
      display: inline-block;
    }}
    .dark .menu-item {{ padding: 4px 12px; }}
    .dark .menu-item.selected {{
      background: var(--dark-menu-alt-bg);
      color: var(--dark-menu-alt-fg);
      font-weight: 700;
    }}
    .dark .menu-meta {{ color: var(--dark-menu-meta-fg); }}

    /* modal styles */
    .dark .modal {{
      background: var(--dark-surface-meta-bg);
      color: var(--dark-surface-meta-fg);
      border: 1px solid var(--dark-sep);
      border-radius: 4px;
      padding: 12px 16px;
      margin: 8px 16px;
    }}
    .dark .modal-title {{ color: var(--dark-brand); font-weight: 700; }}
    .dark .modal-border {{ border-color: var(--dark-sep); }}
    .dark .modal-key {{ color: var(--dark-key); font-weight: 700; }}
    .dark .modal-dim {{ color: var(--dark-dim); }}
    .dark .modal-warn {{ color: var(--dark-warn); font-weight: 700; }}

    /* search/selection styles */
    .dark .search-highlight {{ background: var(--dark-search-bg); color: var(--dark-search-fg); }}
    .dark .text-selection {{ background: var(--dark-selection-bg); color: var(--dark-selection-fg); }}
    .dark .cursor-line {{ background: var(--dark-cursor-line-bg); }}
    .dark .matching-bracket {{ background: var(--dark-bracket-bg); color: var(--dark-bracket-fg); }}

    /* scrollbar */
    .dark .scrollbar-demo {{
      display: flex;
      gap: 4px;
      padding: 8px 16px;
    }}
    .dark .scrollbar-track {{ background: var(--dark-scrollbar-bg); width: 12px; height: 60px; border-radius: 2px; }}
    .dark .scrollbar-thumb {{ background: var(--dark-scrollbar-button); width: 12px; height: 20px; border-radius: 2px; }}

    /* ============================================================
       LIGHT THEME STYLES
       ============================================================ */
    .repl-container.light {{
      background: var(--light-surface-bg);
      color: var(--light-surface-fg);
    }}
    .light .transcript {{ background: var(--light-surface-bg); padding: 16px; }}
    .light .transcript-user {{ color: var(--light-key); font-weight: 700; }}
    .light .transcript-assistant {{ color: var(--light-surface-fg); }}
    .light .transcript-label {{ color: var(--light-key); font-weight: 700; }}
    .light .transcript-meta {{ color: var(--light-dim); }}
    .light .transcript-separator {{ color: var(--light-dim); margin: 12px 0; }}
    .light .transcript-system {{ color: var(--light-dim); }}
    .light .status-ok {{ color: var(--light-good); }}
    .light .status-fail {{ color: var(--light-error); }}
    .light .indicator-line {{ background: var(--light-surface-bg); padding: 4px 16px; }}
    .light .indicator-idle {{ color: var(--light-dim); }}
    .light .indicator-active {{ color: var(--light-phase); font-weight: 700; }}
    .light .prompt-area {{
      background: var(--light-input-bg);
      padding: 12px 16px;
      border-top: 1px solid var(--light-sep);
    }}
    .light .prompt-chevron {{ color: var(--light-brand); font-weight: 700; }}
    .light .placeholder {{ color: var(--light-dim); font-style: italic; }}
    .light .placeholder-warn {{ color: var(--light-warn); font-style: italic; font-weight: 700; }}
    .light .toolbar {{
      background: var(--light-toolbar-bg);
      color: var(--light-toolbar-fg);
      padding: 8px 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }}
    .light .toolbar-key {{ color: var(--light-key); font-weight: 700; }}
    .light .toolbar-agent {{ color: var(--light-value); font-weight: 700; }}
    .light .toolbar-model {{ color: var(--light-model); font-weight: 700; }}
    .light .toolbar-sep {{ color: var(--light-sep); }}
    .light .toolbar-value {{ color: var(--light-value); }}
    .light .toolbar-phase {{ color: var(--light-phase); font-weight: 700; }}
    .light .toolbar-good {{ color: var(--light-good); font-weight: 700; }}
    .light .toolbar-warn {{ color: var(--light-warn); font-weight: 700; }}
    .light .toolbar-auto {{ color: var(--light-error); font-weight: 700; }}
    .light .menu-popup {{
      background: var(--light-menu-bg);
      color: var(--light-menu-fg);
      border: 1px solid var(--light-sep);
      border-radius: 4px;
      padding: 4px 0;
      margin: 8px 16px;
      display: inline-block;
    }}
    .light .menu-item {{ padding: 4px 12px; }}
    .light .menu-item.selected {{
      background: var(--light-menu-alt-bg);
      color: var(--light-menu-alt-fg);
      font-weight: 700;
    }}
    .light .menu-meta {{ color: var(--light-menu-meta-fg); }}
    .light .modal {{
      background: var(--light-surface-meta-bg);
      color: var(--light-surface-meta-fg);
      border: 1px solid var(--light-sep);
      border-radius: 4px;
      padding: 12px 16px;
      margin: 8px 16px;
    }}
    .light .modal-title {{ color: var(--light-brand); font-weight: 700; }}
    .light .modal-key {{ color: var(--light-key); font-weight: 700; }}
    .light .modal-dim {{ color: var(--light-dim); }}
    .light .modal-warn {{ color: var(--light-warn); font-weight: 700; }}
    .light .search-highlight {{ background: var(--light-search-bg); color: var(--light-search-fg); }}
    .light .text-selection {{ background: var(--light-selection-bg); color: var(--light-selection-fg); }}
    .light .cursor-line {{ background: var(--light-cursor-line-bg); }}
    .light .matching-bracket {{ background: var(--light-bracket-bg); color: var(--light-bracket-fg); }}
    .light .scrollbar-demo {{ display: flex; gap: 4px; padding: 8px 16px; }}
    .light .scrollbar-track {{ background: var(--light-scrollbar-bg); width: 12px; height: 60px; border-radius: 2px; }}
    .light .scrollbar-thumb {{ background: var(--light-scrollbar-button); width: 12px; height: 20px; border-radius: 2px; }}

    /* === SHARED LAYOUT === */
    .content-block {{ margin-bottom: 12px; }}
    .section {{ margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #333; }}
    .section:last-child {{ border-bottom: none; }}
    .stripe-container {{ height: 20px; overflow: hidden; display: flex; align-items: center; padding: 0 16px; }}

    /* === COLOR SWATCH SECTION === */
    .color-section {{
      margin-top: 30px;
      padding: 20px;
      background: #222;
      border-radius: 8px;
    }}
    .color-section h2 {{ color: #fff; margin-bottom: 16px; }}
    .color-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 8px;
    }}
    .color-swatch {{
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 6px 8px;
      background: #333;
      border-radius: 4px;
    }}
    .swatch-box {{
      width: 28px;
      height: 28px;
      border-radius: 3px;
      border: 1px solid rgba(255,255,255,0.1);
      flex-shrink: 0;
    }}
    .swatch-info {{ flex: 1; min-width: 0; }}
    .swatch-name {{ color: #ccc; font-size: 11px; }}
    .swatch-hex {{ color: #888; font-size: 10px; }}
    .style-ref {{ color: #555; font-size: 9px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }}
  </style>
</head>
<body>
  <h1>Agenterm REPL Color Reference</h1>
  <p class="generator-note">Generated from color_tokens.py + tui/theme.py &mdash; run <code>uv run docs/generate_repl_reference.py</code> to regenerate</p>

  <div class="theme-toggle">
    <button class="dark active" onclick="showTheme('dark')">Dark Theme</button>
    <button class="light" onclick="showTheme('light')">Light Theme</button>
  </div>

  <!-- ============================================================
       DARK THEME CONTAINER
       ============================================================ -->
  <div id="dark-container" class="repl-container dark">

    <!-- SECTION: Transcript Text Roles -->
    <div class="transcript">
      <div class="section">
        <h3>Transcript Text Roles</h3>

        <div class="content-block">
          <span class="transcript-user">transcript.user: User input text (bold key)</span>
        </div>

        <div class="content-block">
          <span class="transcript-assistant">transcript.assistant: Agent response text (surface_fg)</span>
        </div>

        <div class="content-block">
          <span class="transcript-system">transcript.system: System messages (dim)</span>
        </div>

        <div class="transcript-separator">-- transcript.separator: run 1 ------------------------------------------------------------</div>
      </div>

      <!-- SECTION: Reasoning Blocks -->
      <div class="section">
        <h3>Reasoning Blocks</h3>

        <div class="content-block">
          <div class="transcript-label">[reasoning]</div>
          <div class="transcript-meta">**Summary text with literal markdown** (transcript.meta = dim)</div>
          <div class="transcript-meta">Multi-line reasoning content appears here.</div>
          <div class="transcript-meta">The **bold markers** are NOT rendered, shown as literal text.</div>
        </div>
      </div>

      <!-- SECTION: Tool Call Blocks -->
      <div class="section">
        <h3>Tool Call Blocks</h3>

        <div class="content-block">
          <div class="transcript-label">[tool call] tool_name</div>
          <div class="transcript-meta">  arg1: value1</div>
          <div class="transcript-meta">  arg2: value2</div>
        </div>
      </div>

      <!-- SECTION: Tool Output Blocks -->
      <div class="section">
        <h3>Tool Output Blocks</h3>

        <div class="content-block">
          <div class="transcript-label">[tool output] bat <span class="status-ok">(ok)</span></div>
          <div class="transcript-meta">  path: src/app.py</div>
          <div class="transcript-meta">  lines: 200</div>
        </div>

        <div class="content-block">
          <div class="transcript-label">[tool output] shell <span class="status-fail">(fail)</span></div>
          <div class="transcript-meta">  error: Command failed with exit code 1</div>
          <div class="transcript-meta">  stderr: Permission denied</div>
        </div>
      </div>

      <!-- SECTION: Artifact Blocks -->
      <div class="section">
        <h3>Artifact Blocks</h3>

        <div class="content-block">
          <div class="transcript-label">[artifact] image abc123</div>
          <div class="transcript-meta">  saved: /tmp/artifacts/abc123.png</div>
          <div class="transcript-meta">  meta: image/png (45678 bytes)</div>
          <div class="transcript-meta">  open: /artifacts open abc123</div>
        </div>
      </div>

      <!-- SECTION: Approval Blocks -->
      <div class="section">
        <h3>Approval Blocks</h3>

        <div class="content-block">
          <div class="transcript-label">[approval] shell: rm -rf /tmp/test</div>
          <div class="transcript-meta">  command: rm -rf /tmp/test</div>
          <div class="transcript-meta">  reason: Dangerous command requires approval</div>
        </div>

        <div class="content-block">
          <div class="transcript-label">[approval] shell: rm -rf /tmp/test <span class="status-ok">(ok)</span></div>
        </div>

        <div class="content-block">
          <div class="transcript-label">[approval] shell: rm -rf /tmp/test <span class="status-fail">(fail)</span></div>
        </div>
      </div>
    </div>

    <!-- SECTION: Activity Indicators -->
    <h3 style="color: #666; padding: 8px 16px;">Activity Indicators</h3>

    <div class="indicator-line">
      <span class="indicator-idle">indicator.idle: ⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶</span>
    </div>

    <div class="indicator-line">
      <span class="indicator-active">indicator.active: ████████████████████████████████████████████████████████████████████████</span>
    </div>

    <div class="stripe-container" id="dark-stripe"></div>

    <!-- SECTION: Prompt Area States -->
    <h3 style="color: #666; padding: 8px 16px;">Prompt Area States</h3>

    <div class="prompt-area">
      <span class="prompt-chevron">&gt; </span><span class="placeholder">placeholder: Enter sends. Ctrl+J inserts newline. Ctrl+C clears input.</span>
    </div>

    <div class="prompt-area">
      <span class="prompt-chevron">&gt; </span><span class="placeholder">placeholder (running): Run running - ESC/Ctrl+C cancels.</span>
    </div>

    <div class="prompt-area">
      <span class="prompt-chevron">&gt; </span><span class="placeholder-warn">placeholder.warn: Approval pending - review modal or /approvals list.</span>
    </div>

    <!-- SECTION: Toolbar Variations -->
    <h3 style="color: #666; padding: 8px 16px;">Toolbar Variations</h3>

    <div class="toolbar">
      <div>
        <span class="toolbar-key">agent: </span><span class="toolbar-agent">default</span><span class="toolbar-model">[openai/gpt-5.2]</span>
        <span class="toolbar-sep"> | </span>
        <span class="toolbar-key">effort: </span><span class="toolbar-value">xhigh</span>
        <span class="toolbar-sep"> | </span>
        <span class="toolbar-key">tools: </span><span class="toolbar-value">safe</span>
        <span class="toolbar-sep"> | </span>
        <span class="toolbar-key">context: </span><span class="toolbar-value">42%</span>
      </div>
    </div>

    <div class="toolbar">
      <div>
        <span class="toolbar-key">agent: </span><span class="toolbar-agent">coding</span><span class="toolbar-model">[anthropic/claude-sonnet]</span>
        <span class="toolbar-sep"> | </span>
        <span class="toolbar-phase">running</span>
        <span class="toolbar-sep"> | </span>
        <span class="toolbar-good">ready</span>
        <span class="toolbar-sep"> | </span>
        <span class="toolbar-warn">warning</span>
      </div>
      <span class="toolbar-auto">AUTO</span>
    </div>

    <!-- SECTION: Completion Menu -->
    <h3 style="color: #666; padding: 8px 16px;">Completion Menu</h3>

    <div class="menu-popup">
      <div class="menu-item selected">/help <span class="menu-meta">— Show help</span></div>
      <div class="menu-item">/attach <span class="menu-meta">— Attach context</span></div>
      <div class="menu-item">/clear <span class="menu-meta">— Clear history</span></div>
      <div class="menu-item">/agent <span class="menu-meta">— Switch agent</span></div>
    </div>

    <!-- SECTION: Modal Overlay -->
    <h3 style="color: #666; padding: 8px 16px;">Modal Overlay</h3>

    <div class="modal">
      <div class="modal-title">modal.title: Approval Required</div>
      <div style="margin-top: 8px;">
        <span class="modal-key">modal.key:</span> <span>Command to execute</span>
      </div>
      <div class="modal-dim">modal.dim: Press Y to approve, N to deny</div>
      <div class="modal-warn">modal.warn: This action cannot be undone</div>
    </div>

    <!-- SECTION: Search & Selection -->
    <h3 style="color: #666; padding: 8px 16px;">Search & Selection</h3>

    <div style="padding: 8px 16px;">
      <span>Normal text with </span><span class="search-highlight">search highlight</span><span> in context</span>
    </div>
    <div style="padding: 8px 16px;">
      <span>Normal text with </span><span class="text-selection">text selection</span><span> highlighted</span>
    </div>
    <div class="cursor-line" style="padding: 8px 16px;">
      cursor-line: Current line highlighting
    </div>
    <div style="padding: 8px 16px;">
      <span>Code with </span><span class="matching-bracket">(</span><span>matching</span><span class="matching-bracket">)</span><span> brackets</span>
    </div>

    <!-- SECTION: Scrollbar -->
    <h3 style="color: #666; padding: 8px 16px;">Scrollbar</h3>

    <div class="scrollbar-demo">
      <div class="scrollbar-track">
        <div class="scrollbar-thumb"></div>
      </div>
      <span style="color: var(--dark-dim); font-size: 11px;">scrollbar.background + scrollbar.button</span>
    </div>
  </div>

  <!-- ============================================================
       LIGHT THEME CONTAINER (identical structure)
       ============================================================ -->
  <div id="light-container" class="repl-container light" style="display: none;">
    <div class="transcript">
      <div class="section">
        <h3>Transcript Text Roles</h3>
        <div class="content-block">
          <span class="transcript-user">transcript.user: User input text (bold key)</span>
        </div>
        <div class="content-block">
          <span class="transcript-assistant">transcript.assistant: Agent response text (surface_fg)</span>
        </div>
        <div class="content-block">
          <span class="transcript-system">transcript.system: System messages (dim)</span>
        </div>
        <div class="transcript-separator">-- transcript.separator: run 1 ------------------------------------------------------------</div>
      </div>
      <div class="section">
        <h3>Reasoning Blocks</h3>
        <div class="content-block">
          <div class="transcript-label">[reasoning]</div>
          <div class="transcript-meta">**Summary text with literal markdown** (transcript.meta = dim)</div>
          <div class="transcript-meta">Multi-line reasoning content appears here.</div>
        </div>
      </div>
      <div class="section">
        <h3>Tool Call/Output Blocks</h3>
        <div class="content-block">
          <div class="transcript-label">[tool call] tool_name</div>
          <div class="transcript-meta">  arg1: value1</div>
        </div>
        <div class="content-block">
          <div class="transcript-label">[tool output] bat <span class="status-ok">(ok)</span></div>
          <div class="transcript-meta">  path: src/app.py</div>
          <div class="transcript-meta">  lines: 200</div>
        </div>
        <div class="content-block">
          <div class="transcript-label">[tool output] shell <span class="status-fail">(fail)</span></div>
          <div class="transcript-meta">  error: Command failed</div>
        </div>
      </div>
      <div class="section">
        <h3>Artifact & Approval Blocks</h3>
        <div class="content-block">
          <div class="transcript-label">[artifact] image abc123</div>
          <div class="transcript-meta">  saved: /tmp/artifacts/abc123.png</div>
        </div>
        <div class="content-block">
          <div class="transcript-label">[approval] shell: rm -rf /tmp <span class="status-ok">(ok)</span></div>
        </div>
      </div>
    </div>
    <h3 style="color: #888; padding: 8px 16px;">Activity Indicators</h3>
    <div class="indicator-line">
      <span class="indicator-idle">indicator.idle: ⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶⠶</span>
    </div>
    <div class="indicator-line">
      <span class="indicator-active">indicator.active: ████████████████████████████████████████████████████████████████████████</span>
    </div>
    <div class="stripe-container" id="light-stripe"></div>
    <h3 style="color: #888; padding: 8px 16px;">Prompt Area States</h3>
    <div class="prompt-area">
      <span class="prompt-chevron">&gt; </span><span class="placeholder">placeholder: Enter sends. Ctrl+J inserts newline.</span>
    </div>
    <div class="prompt-area">
      <span class="prompt-chevron">&gt; </span><span class="placeholder-warn">placeholder.warn: Approval pending</span>
    </div>
    <h3 style="color: #888; padding: 8px 16px;">Toolbar</h3>
    <div class="toolbar">
      <div>
        <span class="toolbar-key">agent: </span><span class="toolbar-agent">default</span><span class="toolbar-model">[openai/gpt-5.2]</span>
        <span class="toolbar-sep"> | </span>
        <span class="toolbar-key">effort: </span><span class="toolbar-value">xhigh</span>
        <span class="toolbar-sep"> | </span>
        <span class="toolbar-key">tools: </span><span class="toolbar-value">safe</span>
      </div>
      <span class="toolbar-auto">AUTO</span>
    </div>
    <h3 style="color: #888; padding: 8px 16px;">Completion Menu & Modal</h3>
    <div class="menu-popup">
      <div class="menu-item selected">/help <span class="menu-meta">— Show help</span></div>
      <div class="menu-item">/attach <span class="menu-meta">— Attach context</span></div>
    </div>
    <div class="modal">
      <div class="modal-title">modal.title: Approval Required</div>
      <div><span class="modal-key">modal.key:</span> Command</div>
      <div class="modal-dim">modal.dim: Instructions</div>
      <div class="modal-warn">modal.warn: Warning</div>
    </div>
    <h3 style="color: #888; padding: 8px 16px;">Search & Selection</h3>
    <div style="padding: 8px 16px;">
      <span>Text with </span><span class="search-highlight">search</span><span> and </span><span class="text-selection">selection</span>
    </div>
    <div class="cursor-line" style="padding: 8px 16px;">cursor-line highlighting</div>
    <div style="padding: 8px 16px;">
      <span class="matching-bracket">(</span><span>brackets</span><span class="matching-bracket">)</span>
    </div>
    <div class="scrollbar-demo">
      <div class="scrollbar-track"><div class="scrollbar-thumb"></div></div>
    </div>
  </div>

  <!-- COLOR SWATCHES -->
  <div class="color-section">
    <h2>Dark Theme Tokens</h2>
    <div class="color-grid">
{dark_swatches}
    </div>
  </div>

  <div class="color-section">
    <h2>Light Theme Tokens</h2>
    <div class="color-grid">
{light_swatches}
    </div>
  </div>

  <script>
    function showTheme(theme) {{
      document.getElementById('dark-container').style.display = theme === 'dark' ? 'block' : 'none';
      document.getElementById('light-container').style.display = theme === 'light' ? 'block' : 'none';
      document.querySelectorAll('.theme-toggle button').forEach(btn => {{
        btn.classList.toggle('active', btn.classList.contains(theme));
      }});
    }}

    // Waveform animation (from tui/format.py)
    const WAVEFORM_CHARS = ['\\u28e4', '\\u28c0', '\\u2836', '\\u2809', '\\u281b'];
    const THRESHOLDS = [-0.4, -0.1, 0.1, 0.4];

    function noise(seed) {{
      const x = ((seed * 1103515245 + 12345) >>> 16) & 0x7FFF;
      return (x / 32767.0) - 0.5;
    }}

    function hslToHex(h, s, l) {{
      h = ((h % 360) + 360) % 360;
      const c = (1 - Math.abs(2 * l - 1)) * s;
      const x = c * (1 - Math.abs((h / 60) % 2 - 1));
      const m = l - c / 2;
      let r, g, b;
      if (h < 60) {{ r = c; g = x; b = 0; }}
      else if (h < 120) {{ r = x; g = c; b = 0; }}
      else if (h < 180) {{ r = 0; g = c; b = x; }}
      else if (h < 240) {{ r = 0; g = x; b = c; }}
      else if (h < 300) {{ r = x; g = 0; b = c; }}
      else {{ r = c; g = 0; b = x; }}
      const toHex = (v) => Math.round((v + m) * 255).toString(16).padStart(2, '0');
      return `#${{toHex(r)}}${{toHex(g)}}${{toHex(b)}}`;
    }}

    function generateWaveformChar(t, i, n) {{
      const frame = Math.floor(t * 90);
      const seed = frame * 31 + i * 17;
      const pos = i / Math.max(n - 1, 1);
      const wave1 = Math.sin(t * 7.0 + pos * 4.0 * Math.PI * 2) * 0.25;
      const wave2 = Math.sin(t * 16.0 + pos * 4.0 * Math.PI * 3) * 0.2;
      let amp = Math.max(-1, Math.min(1, wave1 + wave2 + noise(seed) * 0.7));
      let idx = THRESHOLDS.length;
      for (let j = 0; j < THRESHOLDS.length; j++) if (amp < THRESHOLDS[j]) {{ idx = j; break; }}
      const hue = (pos * 360) + (t * 440) + noise(seed * 7) * 40;
      const color = hslToHex(hue, 0.9 + noise(seed * 19) * 0.1, 0.55 + noise(seed * 13) * 0.2);
      return {{ char: WAVEFORM_CHARS[idx], color }};
    }}

    function renderWaveform(id, n = 70) {{
      const el = document.getElementById(id);
      if (!el) return;
      const t = performance.now() / 1000;
      let html = '';
      for (let i = 0; i < n; i++) {{
        const {{ char, color }} = generateWaveformChar(t, i, n);
        html += `<span style="color: ${{color}}">${{char}}</span>`;
      }}
      el.innerHTML = html;
    }}

    function animate() {{
      renderWaveform('dark-stripe');
      renderWaveform('light-stripe');
      requestAnimationFrame(animate);
    }}
    animate();
  </script>
</body>
</html>
'''


def main() -> None:
    """Generate and write the HTML file."""
    output_path = Path(__file__).parent / "repl.html"
    html = generate_html()
    output_path.write_text(html)
    print(f"Generated {output_path}")


if __name__ == "__main__":
    main()
