# SKILLS Proposal

## 0. Skill ledger (cumulative registry; never delete rows)
| name | status | suggested_scope | first_seen | last_seen | merged_into | notes |
| --- | --- | --- | --- | --- | --- | --- |
| contract-doc-sync-auditor | ACTIVE | USER | — | 2026-02-26 | — | imported pre-ledger from main; definition refined for parity gates. |
| schema-invariant-regression-harness | ACTIVE | USER | — | 2026-02-26 | — | imported pre-ledger from main; evidence refreshed this run. |
| bounded-output-consistency-auditor | ACTIVE | USER | — | 2026-02-26 | — | imported pre-ledger from main; evidence refreshed this run. |
| cancellation-resume-resilience-check | ACTIVE | USER | — | 2026-02-26 | — | imported pre-ledger from main; evidence refreshed this run. |
| retry-budget-verifier | ACTIVE | USER | — | 2026-02-26 | — | imported pre-ledger from main; expanded deterministic retry/cancel verification guidance. |
| state-machine-property-test-starter | ACTIVE | USER | — | 2026-02-26 | — | imported pre-ledger from main; expanded sequence-fuzzing workflow. |
| surface-contract-matrix-acceptance | ACTIVE | USER | 2026-02-22 | 2026-02-26 | — | updated to emphasize generated contract matrices and parity checks. |
| aggregate-failure-semantics-validator | ACTIVE | USER | 2026-02-22 | 2026-02-26 | — | evidence refreshed this run. |
| config-template-harmonizer | ACTIVE | USER | 2026-02-23 | 2026-02-26 | — | evidence refreshed this run. |
| rename-move-propagation-guard | ACTIVE | USER | 2026-02-23 | 2026-02-26 | — | evidence refreshed this run. |
| error-envelope-auditor | ACTIVE | USER | 2026-02-23 | 2026-02-26 | — | evidence refreshed this run. |
| module-decomposition-playbook | ACTIVE | USER | 2026-02-23 | 2026-02-26 | — | refined to include seam-first and blast-radius staging checks. |
| sanitization-redaction-guardrail | ACTIVE | USER | 2026-02-24 | 2026-02-26 | — | evidence refreshed this run. |
| trace-lifecycle-consistency-check | ACTIVE | USER | 2026-02-24 | 2026-02-26 | — | evidence refreshed this run. |
| release-notes-synthesizer | ACTIVE | USER | 2026-02-26 | 2026-02-26 | — | new transferable skill for user-impact release communication. |

## 1. Analysis window
- Date range analyzed: 2026-02-12 to 2026-02-26 (last 14 days)
- Commit count analyzed (non-merge): 97

## 2. Observed patterns (repo-agnostic)
- Strict ingress and egress contracts were repeatedly tightened across multiple surfaces.
- Contract changes required coordinated updates across runtime behavior, tests, docs, and examples.
- Retry, timeout, and cancellation logic was formalized with explicit lifecycle/state semantics.
- Property-based and matrix-style tests were used to harden sequence-sensitive behavior.
- Canonicalization refactors replaced duplicated mapping, error conversion, and sanitization logic.
- Renames and module moves had broad blast radius across code, docs, and configuration surfaces.
- Structured error kinds and machine-readable details were expanded to reduce ambiguity.
- Tracing and lifecycle observability moved toward consistent end-to-end correlation.
- Output bounds, truncation metadata, and pagination semantics were hardened for determinism.
- Security-sensitive output handling (sanitization/redaction) required multiple iterative fixes.

## 3. Featured changes this run (3–7)

### 3.1 contract-doc-sync-auditor
- name: contract-doc-sync-auditor
- change_type: UPDATED
- summary: Refined this skill from a generic doc checklist into a parity-oriented workflow that treats docs, examples, and operator guidance as contract surfaces, with explicit checks to prevent schema or behavior drift after interface updates.
- evidence_signals (this window only):
- Contract/schema updates repeatedly shipped with architecture and README updates.
- Drift corrections and sync tests were added after contract wording mismatches.
- Tool description and schema edits required synchronized documentation changes.

### 3.2 surface-contract-matrix-acceptance
- name: surface-contract-matrix-acceptance
- change_type: UPDATED
- summary: Expanded the skill to emphasize matrix generation across API/CLI/tool surfaces with one canonical assertion set for success, error, and bounded-output behaviors, reducing cross-surface drift and rework loops.
- evidence_signals (this window only):
- Dedicated contract matrix tests were added for owned tool behavior.
- Multiple contract-focused tests were updated together with boundary refactors.
- Aggregate ok/error semantics were corrected after earlier surface divergence.

### 3.3 retry-budget-verifier
- name: retry-budget-verifier
- change_type: UPDATED
- summary: Updated the skill to include deterministic test harness patterns for retry, timeout, and cancellation interactions so teams can verify retry budgets and stop conditions without time-based flakiness.
- evidence_signals (this window only):
- Retry budgets and runtime enforcement were wired across execution paths.
- Fixes addressed stalled retry loops and progress-timeout edge cases.
- Cancellation cleanup behavior was explicitly hardened in async flows.

### 3.4 state-machine-property-test-starter
- name: state-machine-property-test-starter
- change_type: UPDATED
- summary: Strengthened this skill to cover sequence fuzzing and lifecycle invariants for stateful workflows, extending beyond simple extracted state diagrams into repeatable property-driven regression strategy.
- evidence_signals (this window only):
- Stream lifecycle logic was extracted into explicit state machine modules.
- Property-based testing dependencies and transition-invariant tests were introduced.
- Retry and lifecycle behavior validation moved from examples to invariant assertions.

### 3.5 module-decomposition-playbook
- name: module-decomposition-playbook
- change_type: UPDATED
- summary: Refined the decomposition workflow with seam-first staging and blast-radius controls so broad refactors stay auditable, acyclic, and contract-safe across runtime, tests, and docs.
- evidence_signals (this window only):
- Large refactors decomposed orchestration paths into focused modules.
- Canonicalization and dedup changes followed decomposition to remove parallel logic.
- Cycle-breaking and package-surface adjustments were performed during structural work.

### 3.6 release-notes-synthesizer
- name: release-notes-synthesizer
- change_type: NEW
- summary: Adds a universal skill for turning merged technical changes into concise user-impact release notes with explicit behavior, migration, and risk framing; intended for teams where commit history exists but release communication is inconsistent.
- evidence_signals (this window only):
- A version bump occurred in-window while release communication stayed fragmented across commits.
- Many behavior and contract changes shipped in parallel, increasing summary complexity.
- Documentation updates captured technical details but not consistently user-facing deltas.

## 4. Skill catalog (cumulative; canonical definitions)

### contract-doc-sync-auditor
- name: contract-doc-sync-auditor
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Public contracts, schemas, CLI flags, or tool interfaces change and docs/examples must remain precise.
  - Do not use when: A change is purely internal with no operator or integrator-facing impact.
- why_evergreen: Contract drift between runtime behavior and human guidance is universal across ecosystems. This skill remains valuable in any repo because it enforces a deterministic mapping from interface changes to documentation updates and parity checks.
- artifacts_produced:
  - Contract-to-doc mapping checklist
  - Required doc/example update plan
  - Release-note input bullets tied to user-facing impact
- verification:
  - Every contract-affecting change maps to at least one documentation surface.
  - Examples and docs reflect the same required fields/defaults enforced by runtime.
  - No-op result is explicit for internal-only changes.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: contract-doc-sync-auditor
    description: Keep docs, examples, and operator guidance synchronized with contract and schema changes.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Discover contract-bearing deltas (schemas, envelopes, flags, tool signatures).
    2. Enumerate affected doc surfaces (architecture, README, examples, runbooks).
    3. Generate exact update actions per surface and draft release-note bullets.
    4. Produce a parity checklist for reviewer sign-off.
  - Verification steps that adapt to the repo:
    1. Discover repo docs and examples from root and docs directories.
    2. Run the repo’s standard gate/test command(s) after doc updates.
    3. Confirm contract snapshots/examples still parse where applicable.
- optional_assets_or_scripts: None
- validation_plan: Trigger on a schema or CLI change in an arbitrary repo and verify it outputs concrete doc targets plus parity checks, while returning a no-op when no public contract changed.
- evidence_signals:
  - Contract/schema updates repeatedly shipped with architecture and README updates.
  - Drift corrections and sync tests were added after contract wording mismatches.
  - Tool description and schema edits required synchronized documentation changes.

### schema-invariant-regression-harness
- name: schema-invariant-regression-harness
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Public input schemas or validation constraints are edited.
  - Do not use when: The system has no formal schema or validation boundary.
- why_evergreen: Validation regressions are a common, high-cost integration failure mode in any stack. A schema invariant harness keeps rejection behavior and error semantics stable as contracts evolve.
- artifacts_produced:
  - Invariant checklist (allowed and forbidden constructs)
  - Negative/boundary test matrix
  - Error-shape expectations for invalid inputs
- verification:
  - Forbidden constructs fail deterministically.
  - Valid baseline inputs remain accepted.
  - Error kinds/details stay machine-consumable.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: schema-invariant-regression-harness
    description: Build regression checks for schema invariants and stable validation errors.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Inventory public schema sources and validators.
    2. Define invariant rules and prohibited shapes.
    3. Draft deterministic negative and boundary test cases.
    4. Produce expected error taxonomy by violation type.
  - Verification steps that adapt to the repo:
    1. Discover schema and validation entrypoints.
    2. Run repository tests that cover ingress validation.
    3. Confirm failures match documented error kinds.
- optional_assets_or_scripts: None
- validation_plan: Run in a repo with JSON schema, typed request models, or equivalent; verify it detects missing negative tests and emits reusable invariant checks.
- evidence_signals:
  - Strict schema enforcement and validation guards were expanded.
  - Schema compatibility fixes were required after boundary changes.
  - Schema-oriented contract tests were added and maintained.

### bounded-output-consistency-auditor
- name: bounded-output-consistency-auditor
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Outputs are truncated, paginated, or char-limited across any surface.
  - Do not use when: Outputs are intentionally unbounded and unmanaged.
- why_evergreen: Bounded output behavior is a recurring source of inconsistency across APIs, CLIs, and reports. This skill ensures deterministic limit semantics and user-visible signals regardless of language or framework.
- artifacts_produced:
  - Limit map by surface
  - Truncation and pagination parity checklist
  - Missing metadata report for bounded outputs
- verification:
  - Every bounded output exposes truncation/limit metadata consistently.
  - Defaults and hard caps are centralized and non-conflicting.
  - Pagination invariants hold under boundary inputs.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: bounded-output-consistency-auditor
    description: Audit truncation, limit, and pagination behavior for cross-surface consistency.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Discover configured limits and defaults.
    2. Trace where each limit is applied at runtime.
    3. Compare emitted metadata across surfaces.
    4. Produce remediation checklist for drift.
  - Verification steps that adapt to the repo:
    1. Discover output surfaces and limit settings.
    2. Execute existing tests or sample commands at boundary sizes.
    3. Confirm metadata presence and consistent semantics.
- optional_assets_or_scripts: None
- validation_plan: Apply to a repo with paginated or truncated outputs; verify the skill highlights metadata gaps and conflicting defaults.
- evidence_signals:
  - Pagination and output-bound semantics were refined in tooling.
  - Contract tests asserted bounded-output behavior and metadata.
  - Aggregate output envelopes were corrected for consistency.

### cancellation-resume-resilience-check
- name: cancellation-resume-resilience-check
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Workflows can be cancelled, resumed, or interrupted mid-execution.
  - Do not use when: Workloads are strictly synchronous and non-interruptible.
- why_evergreen: Cancellation correctness and resume safety are difficult in any long-running system. This skill provides a portable lifecycle checklist that prevents resource leaks, zombie work, and ambiguous terminal states.
- artifacts_produced:
  - Lifecycle state checklist (cancel, resume, terminal)
  - Cleanup and ownership requirement map
  - Edge-case scenario matrix for interruption paths
- verification:
  - Cancellation paths release resources and preserve deterministic state.
  - Resume paths enforce preconditions before continuing.
  - Terminal outcomes remain typed and explicit on failures.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: cancellation-resume-resilience-check
    description: Validate cancellation and resume lifecycle semantics for long-running workflows.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Enumerate cancellable and resumable workflows.
    2. Define lifecycle transitions and cleanup invariants.
    3. Build interruption and recovery scenario matrix.
    4. Report missing transitions or ambiguous terminal states.
  - Verification steps that adapt to the repo:
    1. Discover workflow runners and lifecycle state holders.
    2. Run deterministic cancellation tests or scripts.
    3. Verify cleanup and terminal-state assertions.
- optional_assets_or_scripts: None
- validation_plan: Run in any repo with background jobs/streams; verify output includes testable lifecycle invariants and explicit cleanup checks.
- evidence_signals:
  - Child-task drain semantics were added for cancellation paths.
  - Stale run cleanup/cancellation handling was hardened.
  - Retry and timeout behavior was adjusted for interruption correctness.

### retry-budget-verifier
- name: retry-budget-verifier
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Systems rely on retries, backoff, deadlines, or transient-error handling.
  - Do not use when: There are no retrying operations or backoff controls.
- why_evergreen: Retry policy defects create availability, latency, and cost incidents in almost every distributed system. This skill remains portable because it frames retries as explicit budgets with deterministic stop conditions and cancel-aware behavior.
- artifacts_produced:
  - Retry policy inventory (counts, deadlines, backoff, jitter, retryable classes)
  - Deterministic verification matrix for retry/cancel interactions
  - Unbounded-or-inconsistent retry risk report
- verification:
  - Every retry surface is bounded and policy-driven.
  - Retry classifier behavior is explicit for each failure class.
  - Cancellation stops retry loops and preserves terminal error semantics.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: retry-budget-verifier
    description: Audit retry budgets and deterministically verify retry/cancellation semantics.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Inventory retry surfaces and policy configuration.
    2. Extract budgets/deadlines/backoff and error-class mappings.
    3. Produce deterministic test plan (injected clock/sleep/classifier where possible).
    4. Report policy gaps and conflicting semantics.
  - Verification steps that adapt to the repo:
    1. Discover retry config and runtime call sites.
    2. Run repo test command(s) for resilience paths.
    3. Confirm bounded attempts and cancel-aware termination.
- optional_assets_or_scripts: None
- validation_plan: Apply to any repo with retry middleware or adapter retries and verify it surfaces unbounded retries and nondeterministic tests.
- evidence_signals:
  - Retry budget configuration and enforcement were expanded.
  - Timeout/progress edge-case fixes targeted retry correctness.
  - Deterministic resilience testing patterns were used for async paths.

### state-machine-property-test-starter
- name: state-machine-property-test-starter
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Event sequencing and lifecycle transitions drive system behavior.
  - Do not use when: Workflows are linear and have no meaningful state graph.
- why_evergreen: Sequence bugs are universal in stateful systems and are rarely caught by example tests alone. Property-based state-machine testing provides a transferable method to validate invariants across broad transition space.
- artifacts_produced:
  - State graph draft with explicit transitions
  - Invariant inventory for safety and liveness properties
  - Property-test scaffold for generated transition sequences
- verification:
  - Invariants are expressed as properties, not only fixtures.
  - Generated sequences cover key transition families and terminal states.
  - Failures include reproducible minimized cases.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: state-machine-property-test-starter
    description: Extract workflow state machines and bootstrap property-based invariant testing.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Identify stateful workflows and events.
    2. Define explicit states/transitions and terminal conditions.
    3. Author invariants and operation generators.
    4. Produce minimal property-test harness and adoption checklist.
  - Verification steps that adapt to the repo:
    1. Discover existing state or lifecycle tests.
    2. Run repository tests with property tooling available in-project.
    3. Confirm invariant failures are reproducible.
- optional_assets_or_scripts: None
- validation_plan: Run in any repo with queues, streams, or orchestration logic and verify it outputs a usable property-test starting point.
- evidence_signals:
  - State-machine extraction and lifecycle decomposition occurred in runtime code.
  - Property-based tests were introduced for transition invariants.
  - Async behavior validation shifted toward invariant-driven checks.

### surface-contract-matrix-acceptance
- name: surface-contract-matrix-acceptance
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Multiple interfaces should honor one contract (API, CLI, tools, jobs, UI actions).
  - Do not use when: There is only one externally visible interface.
- why_evergreen: Cross-surface contract drift is common wherever a system exposes the same behavior through several interfaces. This skill scales across languages by enforcing one assertion matrix for shared success and error semantics.
- artifacts_produced:
  - Surface inventory and contract matrix
  - Shared assertion set (success, error, boundary, truncation cases)
  - Drift report for mismatched behavior per surface
- verification:
  - Each public surface is mapped in the matrix.
  - The same contract assertions run for each surface.
  - Mismatches are reported by case and surface.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: surface-contract-matrix-acceptance
    description: Create a cross-surface contract matrix with shared acceptance assertions.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Enumerate contract-sharing surfaces.
    2. Define canonical assertion cases and fixtures.
    3. Build a surface-by-case matrix and expected outcomes.
    4. Emit drift report and remediation checklist.
  - Verification steps that adapt to the repo:
    1. Discover surface entrypoints automatically where possible.
    2. Run existing unit/integration command(s) mapped to each surface.
    3. Confirm shared assertions pass or produce explicit diffs.
- optional_assets_or_scripts: None
- validation_plan: Apply to a repo with at least two interfaces for one feature and verify matrix outputs detectable parity failures.
- evidence_signals:
  - Contract matrix tests were added for tool behavior.
  - Contract and boundary tests were repeatedly updated with refactors.
  - Aggregate success/error semantics needed convergence after drift.

### aggregate-failure-semantics-validator
- name: aggregate-failure-semantics-validator
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Batch or fan-out operations return both per-item and aggregate outcomes.
  - Do not use when: Operations are strictly single-item without aggregate semantics.
- why_evergreen: Batch result semantics are commonly under-specified and prone to hidden partial failures. This skill codifies deterministic aggregate rules and per-item outcome checks that transfer to any batching pattern.
- artifacts_produced:
  - Aggregate semantics checklist
  - Mixed-success/mixed-failure case matrix
  - Missing-signal report for batch outputs
- verification:
  - Each item includes explicit status and error data when relevant.
  - Aggregate status follows documented rule set for mixed outcomes.
  - Batch contracts are stable across interfaces.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: aggregate-failure-semantics-validator
    description: Validate per-item and aggregate result semantics for batch operations.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Identify batch surfaces and response structures.
    2. Define aggregate and per-item invariants.
    3. Build mixed-outcome test cases.
    4. Emit drift and ambiguity findings.
  - Verification steps that adapt to the repo:
    1. Discover batch contracts and execution surfaces.
    2. Run tests or scripts for mixed outcomes.
    3. Confirm aggregate and per-item status coherence.
- optional_assets_or_scripts: None
- validation_plan: Apply to a repo with bulk APIs/jobs and verify it catches absent aggregate status or inconsistent per-item signaling.
- evidence_signals:
  - Aggregate success semantics were revised to remove ambiguity.
  - Batch coverage was expanded for mixed outcome cases.
  - Output contract adjustments were required after regressions.

### config-template-harmonizer
- name: config-template-harmonizer
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Configuration keys/defaults/constraints change and templates/examples must stay valid.
  - Do not use when: The project has no user-facing configuration artifacts.
- why_evergreen: Configuration drift between runtime schema and examples is a universal onboarding and reliability problem. This skill keeps config definitions, docs, and templates in lockstep across ecosystems.
- artifacts_produced:
  - Config key and default delta map
  - Template/example update checklist
  - Validation coverage checklist for changed keys
- verification:
  - Example and template configs parse/validate against current schema.
  - Runtime defaults match documented defaults.
  - Config controls are consistently named across surfaces.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: config-template-harmonizer
    description: Synchronize configuration schema changes with templates, examples, and docs.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Detect config model/default changes.
    2. Locate templates, env examples, and config docs.
    3. Map each key change to required updates.
    4. Produce validation checklist for updated examples.
  - Verification steps that adapt to the repo:
    1. Discover config schema and template sources.
    2. Run repo validation/tests that load config.
    3. Confirm examples remain valid and current.
- optional_assets_or_scripts: None
- validation_plan: Run in a repo with config templates and schema validation; ensure it flags stale examples and missing key migrations.
- evidence_signals:
  - Config defaults and retry controls changed across runtime paths.
  - Template docs and examples were updated to reflect new controls.
  - Config validation and docs required repeated synchronization edits.

### rename-move-propagation-guard
- name: rename-move-propagation-guard
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Names, module paths, commands, or config keys are renamed or moved.
  - Do not use when: There are no public or cross-module identifier changes.
- why_evergreen: Renames are deceptively expensive and often leave stale references that become latent defects. This skill is portable because every codebase faces rename propagation risk across docs, tests, scripts, and interfaces.
- artifacts_produced:
  - Rename/move inventory with old-to-new mapping
  - Surface propagation checklist
  - Residual-reference scan report
- verification:
  - No stale references remain in source, tests, docs, or config.
  - User-facing surfaces consistently use new terminology.
  - Entrypoint and import paths still resolve after moves.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: rename-move-propagation-guard
    description: Prevent stale references after renames and module moves.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Build canonical old-to-new mapping.
    2. Enumerate all surfaces referencing renamed artifacts.
    3. Execute replacement and residual scans.
    4. Emit unresolved-reference checklist.
  - Verification steps that adapt to the repo:
    1. Discover search tooling and source roots.
    2. Run tests/lint/typecheck commands for renamed surfaces.
    3. Confirm zero stale identifiers remain.
- optional_assets_or_scripts: None
- validation_plan: Use in any repo with file/key renames and verify it produces complete propagation tasks and residual scan outputs.
- evidence_signals:
  - Multiple module and naming refactors required wide-scope updates.
  - Large blast-radius renames touched code, docs, and tests together.
  - Consolidation passes removed stale references across surfaces.

### error-envelope-auditor
- name: error-envelope-auditor
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Structured error contracts, failure mappings, or envelope fields are modified.
  - Do not use when: Failures are intentionally opaque and undocumented.
- why_evergreen: Typed and stable error envelopes are foundational for automation and supportability in any integration-heavy system. This skill keeps error semantics explicit, consistent, and safe for machine consumers.
- artifacts_produced:
  - Error taxonomy map by failure class
  - Envelope field compliance checklist
  - Redaction and sensitive-data failure-surface review
- verification:
  - Error envelopes contain required canonical fields.
  - Failure classes map to typed error kinds consistently.
  - Sensitive internals are redacted and not leaked.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: error-envelope-auditor
    description: Audit error contract consistency, typed kinds, and redaction across surfaces.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Inventory error-producing boundaries.
    2. Map exceptions/failure classes to canonical error kinds.
    3. Compare emitted envelopes against schema.
    4. Report field, kind, and redaction mismatches.
  - Verification steps that adapt to the repo:
    1. Discover failure paths and error schemas.
    2. Run tests for representative failure classes.
    3. Confirm consistent structured output.
- optional_assets_or_scripts: None
- validation_plan: Apply in any repo exposing structured errors and verify it detects missing fields, inconsistent kinds, and redaction regressions.
- evidence_signals:
  - Canonical provider error conversion was centralized.
  - Typed failure kinds and structured details were expanded.
  - Envelope parsing and strictness were tightened after drift.

### module-decomposition-playbook
- name: module-decomposition-playbook
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Modules exceed complexity limits or multiple concerns are entangled.
  - Do not use when: A tiny local change does not affect module boundaries.
- why_evergreen: Decomposition is a recurring necessity in growing codebases, independent of language. A seam-first playbook with blast-radius staging reduces refactor risk while preserving behavior and contracts.
- artifacts_produced:
  - Seam-first decomposition plan
  - Dependency direction and ownership sketch
  - Blast-radius staging checklist (move, verify, retire)
- verification:
  - New modules have clear single-purpose boundaries.
  - Import graph remains acyclic after moves.
  - Public entrypoints and contract tests remain valid.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: module-decomposition-playbook
    description: Execute seam-first module decomposition with explicit blast-radius controls.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Identify decomposition seams by concern and dependency direction.
    2. Stage moves into small verifiable slices.
    3. Consolidate duplicate logic into canonical paths.
    4. Retire superseded paths and update docs/tests.
  - Verification steps that adapt to the repo:
    1. Discover module size/complexity signals and import relationships.
    2. Run repo lint/type/test gates after each stage.
    3. Confirm no new cycles and stable entrypoints.
- optional_assets_or_scripts: None
- validation_plan: Apply in a repo with large modules and verify it produces staged refactor plan plus objective pass/fail checks per stage.
- evidence_signals:
  - Large orchestration modules were decomposed into focused components.
  - Canonicalization refactors followed decomposition to remove duplication.
  - Cycle-breaking changes were required during modularization work.

### sanitization-redaction-guardrail
- name: sanitization-redaction-guardrail
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Outputs may contain sensitive tokens, filesystem paths, IDs, or credentials.
  - Do not use when: Data is fully synthetic and contains no sensitive material.
- why_evergreen: Data leakage prevention is universally relevant and often regresses during refactors. This skill provides repeatable checks for redaction consistency while preserving debuggability.
- artifacts_produced:
  - Sensitive-field and output-surface inventory
  - Redaction policy conformance checklist
  - Leakage-risk report with remediation priorities
- verification:
  - Sensitive fields are redacted consistently across surfaces.
  - Path and token normalization rules are deterministic.
  - Tests or samples confirm no raw sensitive values leak.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: sanitization-redaction-guardrail
    description: Enforce consistent redaction and sanitization of sensitive output fields.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Identify sensitive data classes and emitting surfaces.
    2. Define canonical redaction and normalization rules.
    3. Compare outputs against policy under representative failures.
    4. Produce leakage findings and fix checklist.
  - Verification steps that adapt to the repo:
    1. Discover logs/reports/errors where sensitive data may appear.
    2. Run existing tests or sampled commands for those surfaces.
    3. Confirm policy-compliant output formatting.
- optional_assets_or_scripts: None
- validation_plan: Use in any repo producing logs/reports and verify it catches path/token leakage and inconsistent masking.
- evidence_signals:
  - Path sanitization logic was corrected across edge cases.
  - Cross-platform redaction behavior required dedicated fixes.
  - Report sanitization modes were expanded for safer diagnostics.

### trace-lifecycle-consistency-check
- name: trace-lifecycle-consistency-check
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Multi-stage workflows require trace correlation and lifecycle observability.
  - Do not use when: The system has no tracing requirements or no workflow staging.
- why_evergreen: Tracing gaps at component boundaries are a recurring observability failure in distributed and asynchronous systems. This skill remains useful across stacks because it verifies correlation continuity and lifecycle event completeness.
- artifacts_produced:
  - Trace propagation map by stage/surface
  - Lifecycle event completeness checklist
  - Missing-correlation report
- verification:
  - Trace IDs and correlation fields propagate across boundaries.
  - Lifecycle phases emit structured, ordered records.
  - Failure artifacts preserve trace linkage.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: trace-lifecycle-consistency-check
    description: Verify trace correlation and lifecycle event continuity across workflow boundaries.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Inventory required trace fields and lifecycle stages.
    2. Map expected trace flow through each boundary.
    3. Compare observed events/logs against expected flow.
    4. Emit missing-link and missing-stage findings.
  - Verification steps that adapt to the repo:
    1. Discover tracing configuration and observability outputs.
    2. Run representative workflows in test/dev mode.
    3. Confirm correlated identifiers and stage coverage.
- optional_assets_or_scripts: None
- validation_plan: Apply to any repo with tracing/logging and verify it detects broken correlation paths and missing lifecycle events.
- evidence_signals:
  - Trace context propagation was added across tool/workflow paths.
  - Lifecycle tracing instrumentation was introduced for stream flows.
  - Tests asserted trace metadata presence and continuity.

### release-notes-synthesizer
- name: release-notes-synthesizer
- suggested_scope: USER
- status: ACTIVE
- description (written for implicit invocation):
  - Use when: Many commits have landed and the team needs a user-focused release narrative.
  - Do not use when: The task is purely internal analysis with no release communication need.
- why_evergreen: Release communication quality degrades quickly as change volume grows in any project. This skill is portable because it transforms technical deltas into concise operator/user impact summaries, migration notes, and risk callouts without requiring repo-specific process.
- artifacts_produced:
  - User-impact release summary draft
  - Breaking-change and migration checklist
  - Risk/rollback notes for operators
- verification:
  - Every highlighted change ties to user-facing behavior, not internal refactor detail alone.
  - Breaking changes include required action and affected surfaces.
  - Claims are traceable to merged commits or documented contracts.
- proposed_SKILL_md_skeleton:
  - YAML frontmatter:
    ```yaml
    ---
    name: release-notes-synthesizer
    description: Generate concise user-impact release notes from merged technical changes.
    ---
    ```
  - Step-by-step workflow with explicit inputs/outputs:
    1. Collect commits/PRs for the target release window.
    2. Cluster changes by user-facing impact (features, fixes, breaking changes).
    3. Draft release notes with migration and operator implications.
    4. Output unresolved claim checklist for reviewer confirmation.
  - Verification steps that adapt to the repo:
    1. Discover canonical release/version markers and changelog practices.
    2. Validate notes against tests/docs updated in the same window.
    3. Confirm each bullet has evidence in commit or contract history.
- optional_assets_or_scripts: None
- validation_plan: Run in a repo with a version bump and dense commit history; verify it produces a concise release draft with actionable migration and risk notes.
- evidence_signals:
  - A version bump occurred alongside broad contract and behavior changes.
  - Technical updates were distributed across many commits and surfaces.
  - User-facing summary artifacts were less centralized than implementation detail.

## 5. Lifecycle log (this run)
- ACTIVE → CONSOLIDATED transitions: None.
- CONSOLIDATED → ACTIVE reactivations: None.
- merges performed (old → new): None.
- deprecations: None.
- new skills added: release-notes-synthesizer.
