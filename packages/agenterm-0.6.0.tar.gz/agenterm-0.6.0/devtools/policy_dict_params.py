"""Enforce Mapping/MutableMapping usage for parameters.

The engineering charter reserves `dict[K, V]` for owned state, locals, and
returns. Function parameters should use `Mapping[K, V]` or `MutableMapping[K, V]`
to preserve variance and avoid over-constraining call sites.

This policy is enforced at gate time using AST inspection so multi-line
signatures and `Annotated[...]` wrappers are handled correctly.
"""

from __future__ import annotations

import ast
import sys
from dataclasses import dataclass
from pathlib import Path

SEARCH_DIRS = ("src", "devtools")


@dataclass(frozen=True, slots=True)
class Violation:
    """One dict-typed parameter violation."""

    path: Path
    line: int
    col: int
    function: str
    param: str

    def render(self) -> str:
        """Render a single-line violation message."""
        return (
            f"{self.path.as_posix()}:{self.line}:{self.col}: "
            f"parameter {self.param!r} in {self.function!r} uses dict[...]"
        )


def _unwrap_annotated(expr: ast.AST) -> ast.AST:
    """Return the inner type for Annotated[T, ...] annotations."""
    if not isinstance(expr, ast.Subscript):
        return expr

    value = expr.value
    if isinstance(value, ast.Name):
        is_annotated = value.id == "Annotated"
    elif isinstance(value, ast.Attribute):
        is_annotated = value.attr == "Annotated"
    else:
        return expr
    if not is_annotated:
        return expr
    slice_expr = expr.slice

    if isinstance(slice_expr, ast.Tuple) and slice_expr.elts:
        return slice_expr.elts[0]
    return slice_expr


def _is_dict_annotation(expr: ast.AST | None) -> bool:
    """Return True when the annotation denotes `dict[...]` (including unions)."""
    if expr is None:
        return False

    expr = _unwrap_annotated(expr)

    if isinstance(expr, ast.Name) and expr.id == "dict":
        return True
    if (
        isinstance(expr, ast.Subscript)
        and isinstance(expr.value, ast.Name)
        and expr.value.id == "dict"
    ):
        return True
    if isinstance(expr, ast.BinOp) and isinstance(expr.op, ast.BitOr):
        return _is_dict_annotation(expr.left) or _is_dict_annotation(expr.right)
    return False


def _iter_args(node: ast.FunctionDef | ast.AsyncFunctionDef) -> list[ast.arg]:
    args = node.args
    out: list[ast.arg] = []
    out.extend(args.posonlyargs)
    out.extend(args.args)
    out.extend(args.kwonlyargs)
    if args.vararg is not None:
        out.append(args.vararg)
    if args.kwarg is not None:
        out.append(args.kwarg)
    return out


def _check_path(path: Path) -> list[Violation]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except SyntaxError as exc:
        line = exc.lineno if isinstance(exc.lineno, int) else 1
        col = exc.offset if isinstance(exc.offset, int) else 0
        return [
            Violation(
                path=path,
                line=line,
                col=col,
                function="<parse>",
                param=f"syntax_error: {exc.msg}",
            ),
        ]

    violations: list[Violation] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        fn_name = node.name
        violations.extend(
            [
                Violation(
                    path=path,
                    line=arg.lineno,
                    col=arg.col_offset,
                    function=fn_name,
                    param=arg.arg,
                )
                for arg in _iter_args(node)
                if _is_dict_annotation(arg.annotation)
            ],
        )
    return violations


def _iter_python_files() -> list[Path]:
    out: list[Path] = []
    for base in SEARCH_DIRS:
        root = Path(base)
        if not root.is_dir():
            continue
        out.extend(p for p in root.rglob("*.py") if p.is_file())
    return out


def main() -> int:
    """Entry point."""
    violations: list[Violation] = []
    for path in _iter_python_files():
        violations.extend(_check_path(path))

    if not violations:
        return 0

    for v in violations:
        sys.stdout.write(f"{v.render()}\n")
    return 1


if __name__ == "__main__":
    sys.exit(main())
