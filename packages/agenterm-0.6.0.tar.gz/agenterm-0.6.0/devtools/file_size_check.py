"""Check source files against size thresholds (LOC and chars).

Exits 0 if all files pass, 1 if any exceed thresholds.
Only outputs on failure for minimal token footprint.
"""

from __future__ import annotations

import sys
from pathlib import Path

MAX_LINES = 500
MAX_CHARS = 18000
SOURCE_EXTENSIONS = (".py", ".ts", ".tsx", ".js", ".jsx", ".yaml", ".yml")
SOURCE_DIRS = ("src", "devtools")
EXCLUDE_DIR_NAMES = {
    ".venv",
    "node_modules",
    "dist",
    "docs",
    "__pycache__",
    ".git",
}

EXCLUDE_FILE_PATHS: set[Path] = set()


def is_excluded(path: Path) -> bool:
    """Return True when any path component is in the exclude set."""
    if path in EXCLUDE_FILE_PATHS:
        return True
    return any(part in EXCLUDE_DIR_NAMES for part in path.parts)


def check_files() -> list[tuple[Path, int, int]]:
    """Find files exceeding thresholds. Returns list of (path, lines, chars)."""
    violations: list[tuple[Path, int, int]] = []

    for base in SOURCE_DIRS:
        base_path = Path(base)
        if not base_path.is_dir():
            continue
        for path in base_path.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix not in SOURCE_EXTENSIONS:
                continue
            if is_excluded(path):
                continue
            try:
                content = path.read_bytes()
            except OSError:
                continue
            lines = content.count(b"\n") or (1 if content else 0)
            chars = len(content)
            if lines > MAX_LINES or chars > MAX_CHARS:
                violations.append((path, lines, chars))

    return violations


def main() -> int:
    """Entry point."""
    violations = check_files()
    if violations:
        for path, lines, chars in violations:
            sys.stdout.write(f"{path.as_posix()} | lines={lines} chars={chars}\n")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
