"""Gate runner for linting, type-checking, smoke tests, and policy checks.

Prints all output (including warnings) from every step.
Exit 0 = all gates passed, non-zero = at least one failed.
"""

from __future__ import annotations

import argparse
import asyncio
import shlex
import sys
from dataclasses import dataclass, field
from pathlib import Path

EXCLUDE_GLOBS: tuple[str, ...] = (
    "-g",
    "!**/.venv/**",
    "-g",
    "!**/node_modules/**",
    "-g",
    "!dist/**",
    "-g",
    "!docs/**",
    "-g",
    "!examples/**",
    "-g",
    "!devtools/gate.py",
    "-g",
    "!**/.git/**",
    "-g",
    "!**/__pycache__/**",
    "-g",
    "!**/data/agents/**",
)


@dataclass(frozen=True)
class Step:
    """A single gate step."""

    name: str
    cmd: tuple[str, ...]
    cwd: Path | None = None
    info_only: bool = False  # If True, failures are advisory (exit 0)


@dataclass
class StepResult:
    """Result of running a step."""

    step: Step
    returncode: int
    output: str
    raw_returncode: int = 0  # Actual return code before info_only adjustment


@dataclass
class GateRunner:
    """Runs gate steps and collects results."""

    repo_root: Path
    run_tests: bool = True
    run_full: bool = False
    web_dir: Path = field(init=False)
    has_web: bool = field(init=False)
    results: list[StepResult] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Resolve paths and detect optional web toolchain presence."""
        self.repo_root = self.repo_root.resolve()
        self.web_dir = self.repo_root / "web"
        self.has_web = (
            self.web_dir.is_dir() and (self.web_dir / "package.json").is_file()
        )

    async def _run_cmd(self, *, cmd: tuple[str, ...], cwd: Path) -> tuple[int, str]:
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=str(cwd),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
        except FileNotFoundError:
            return 127, f"command not found: {cmd[0]}"

        stdout_bytes, _ = await proc.communicate()
        returncode = proc.returncode
        if returncode is None:
            returncode = await proc.wait()
        stdout = stdout_bytes.decode("utf-8", errors="replace").rstrip()
        return returncode, stdout

    def run_step(self, step: Step) -> StepResult:
        """Run a single step, capturing output."""
        cwd = (step.cwd or self.repo_root).resolve()
        raw_returncode, output = asyncio.run(self._run_cmd(cmd=step.cmd, cwd=cwd))
        return StepResult(
            step=step,
            returncode=0 if step.info_only else raw_returncode,
            output=output,
            raw_returncode=raw_returncode,
        )

    def _policy_paths(self) -> tuple[str, ...]:
        paths: list[str] = ["src", "devtools"]
        if self.has_web:
            paths.append(str(self.web_dir / "src"))
        return tuple(paths)

    def rg_policy(
        self,
        name: str,
        pattern: str,
        *,
        paths: tuple[str, ...] | None = None,
        extra_globs: tuple[str, ...] = (),
        pcre2: bool = True,
        invert: bool = True,
        info_only: bool = False,
    ) -> Step:
        """Create a ripgrep-based policy check step."""
        search_paths = paths or self._policy_paths()
        cmd_parts: list[str] = ["rg", "-n"]
        if pcre2:
            cmd_parts.append("-P")
        cmd_parts.append(pattern)
        cmd_parts.extend(search_paths)
        cmd_parts.extend(EXCLUDE_GLOBS)
        cmd_parts.extend(extra_globs)

        if invert:
            bash_cmd = "! " + " ".join(shlex.quote(p) for p in cmd_parts)
            return Step(
                name=name,
                cmd=("bash", "-lc", bash_cmd),
                cwd=self.repo_root,
                info_only=info_only,
            )
        return Step(
            name=name,
            cmd=tuple(cmd_parts),
            cwd=self.repo_root,
            info_only=info_only,
        )

    def python_steps(self) -> list[Step]:
        """Python toolchain steps."""
        steps = [
            Step(
                "ruff:check",
                (
                    "uv",
                    "run",
                    "ruff",
                    "check",
                    "--fix",
                    "src",
                    "devtools",
                ),
                cwd=self.repo_root,
            ),
            Step(
                "ruff:format",
                (
                    "uv",
                    "run",
                    "ruff",
                    "format",
                    "src",
                    "devtools",
                ),
                cwd=self.repo_root,
            ),
            Step(
                "basedpyright",
                (
                    "uv",
                    "run",
                    "basedpyright",
                    ".",
                ),
                cwd=self.repo_root,
            ),
            Step(
                "compileall",
                (
                    "uv",
                    "run",
                    "python",
                    "-m",
                    "compileall",
                    "src",
                    "devtools",
                ),
                cwd=self.repo_root,
            ),
        ]

        if self.run_tests:
            steps.append(
                Step(
                    "pytest",
                    (
                        "bash",
                        "-lc",
                        "uv run pytest -q || [ $? -eq 5 ]",
                    ),
                    cwd=self.repo_root,
                ),
            )

        if self.run_full:
            steps.append(
                Step(
                    "pytest:integration_provider",
                    (
                        "bash",
                        "-lc",
                        "uv run pytest -q -m integration_provider || [ $? -eq 5 ]",
                    ),
                    cwd=self.repo_root,
                ),
            )

        steps.append(
            Step(
                "cli-help",
                (
                    "uv",
                    "run",
                    "agenterm",
                    "--help",
                ),
                cwd=self.repo_root,
            ),
        )

        return steps

    def web_steps(self) -> list[Step]:
        """Web toolchain steps (if web/ exists)."""
        if not self.has_web:
            return []
        return [
            Step(
                "tsc",
                ("pnpm", "exec", "tsc", "--noEmit", "-p", "tsconfig.json"),
                cwd=self.web_dir,
            ),
            Step(
                "no-inline-style",
                (
                    "bash",
                    "-lc",
                    "! rg -n -F 'style={' src -g '!src/vendor/**' -g '!**/*.svg'",
                ),
                cwd=self.web_dir,
            ),
            Step(
                "biome",
                ("pnpm", "exec", "biome", "check", "--write"),
                cwd=self.web_dir,
            ),
            Step(
                "build",
                ("pnpm", "build"),
                cwd=self.web_dir,
            ),
        ]

    def policy_steps(self) -> list[Step]:
        """Policy enforcement steps."""
        return [
            self.rg_policy("no-type-ignore", r"#\s*(type|pyright):\s*ignore"),
            self.rg_policy("no-noqa", r"#\s*noqa\b"),
            self.rg_policy("no-bare-except", r"^\s*except\s*:"),
            self.rg_policy(
                "no-reflection",
                r"(?<![A-Za-z_])(getattr|hasattr|setattr)\s*\(",
            ),
            self.rg_policy("no-silent-swallow", r"except(?:\s+[^:]+)?\s*:\s*pass\b"),
            self.rg_policy("no-eval-exec", r"\b(eval|exec)\s*\("),
            self.rg_policy(
                "no-shell-true",
                r"(os\.system\s*\(|subprocess\.(?:Popen|run)\(.*shell\s*=\s*True)",
            ),
            self.rg_policy(
                "no-pass-only-def",
                r"^(?s)\s*(def|class)\s+[A-Za-z_]\w*\s*\([^)]*\)?\s*:\s*\n\s*pass\b",
            ),
            self.rg_policy(
                "no-any-cast",
                r"(from\s+typing\s+import[^\n]*\bAny\b|\btyping\.Any\b|\btyping\.cast\b|\bcast\s*\()",
            ),
            self.rg_policy(
                "no-broad-object",
                r"(?<!json)(?:[:\-]>?\s*|\b(?:list|dict|mapping)\[)\s*object\b|\b(dict|Mapping|list)\s*\[\s*str\s*,\s*object\s*\]",
            ),
            Step(
                "no-dict-params",
                ("uv", "run", "python", "-m", "devtools.policy_dict_params"),
                cwd=self.repo_root,
            ),
            Step(
                "file-size",
                ("uv", "run", "python", "-m", "devtools.file_size_check"),
                cwd=self.repo_root,
            ),
            Step(
                "uv:lock-check",
                ("uv", "lock", "--check"),
                cwd=self.repo_root,
            ),
            # Advisory checks (info_only=True)
            self.rg_policy(
                "tech-debt (advisory)",
                r"\b(TODO|FIXME|HACK|XXX)\b|#.*\bappease\b",
                invert=False,
                info_only=True,
            ),
        ]

    def all_steps(self) -> list[Step]:
        """All gate steps in order."""
        return self.python_steps() + self.web_steps() + self.policy_steps()

    def run(self) -> int:
        """Run all steps, return overall exit code."""
        steps = self.all_steps()
        failures: list[StepResult] = []
        advisories: list[StepResult] = []

        for step in steps:
            result = self.run_step(step)
            self.results.append(result)

            if result.returncode != 0:
                failures.append(result)
                sys.stdout.write(f"FAIL {step.name}\n")
                if result.output:
                    sys.stdout.write(f"{result.output}\n")
            elif step.info_only and result.output:
                advisories.append(result)
            elif result.output:
                # Print output for successful steps (don't swallow warnings)
                sys.stdout.write(f"{step.name}:\n{result.output}\n")

        if advisories:
            sys.stdout.write("\n--- advisory ---\n")
            for r in advisories:
                sys.stdout.write(f"{r.step.name}:\n")
                sys.stdout.write(f"{r.output}\n")

        if failures:
            sys.stdout.write(
                f"\n{len(failures)} failed, {len(steps) - len(failures)} passed\n",
            )
            return 1

        sys.stdout.write(f"OK ({len(steps)} steps)\n")
        return 0


def main() -> int:
    """Entry point."""
    parser = argparse.ArgumentParser(description="Run gate checks")
    parser.add_argument(
        "--full",
        action="store_true",
        help=(
            "Include opt-in external integration tests "
            "(pytest -m integration_provider). "
            "This may require credentials and hit real provider/network APIs."
        ),
    )
    parser.add_argument(
        "--no-tests",
        action="store_true",
        help="Skip pytest (runs by default)",
    )
    args = parser.parse_args()

    if args.full and args.no_tests:
        parser.error("--full and --no-tests are mutually exclusive")

    repo_root = Path(__file__).resolve().parent.parent
    runner = GateRunner(
        repo_root=repo_root,
        run_tests=not args.no_tests,
        run_full=args.full,
    )
    return runner.run()


if __name__ == "__main__":
    sys.exit(main())
