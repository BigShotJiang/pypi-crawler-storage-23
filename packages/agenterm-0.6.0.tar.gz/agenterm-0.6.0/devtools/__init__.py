"""Developer tooling for this repository.

This package is intentionally importable so gates can be run via:

  uv run python -m devtools.<module>
"""
