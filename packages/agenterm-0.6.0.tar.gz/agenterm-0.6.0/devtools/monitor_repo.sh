#!/bin/bash


usage() {
    cat <<'EOH'
Usage: devtools/monitor_repo.sh [OPTIONS]

DESCRIPTION:
  Monitor Python files in the repository, displaying file statistics and metrics.
  By default, excludes .venv and devtools directories, showing top 15 files.

OPTIONS:
  --limit N           Number of top files to display (default: 15)

                      Examples:
                        --limit 10        # Show top 10 files
                        --limit 50        # Show top 50 files

  --sort-by METRIC    Metric used for ranking output rows (default: chars)

                      Available metrics:
                        chars → Total bytes per file
                        dens  → Byte density (bytes per line)

                      Example: --sort-by dens

  --sort ORDER        Ordering direction (default: h)

                      Available orders:
                        h → Highest first (descending)
                        l → Lowest first (ascending)

                      Example: --sort l

  --exclude DIRS      Comma-separated list of directory names to exclude.
                      These directories will be excluded ANYWHERE in the tree,
                      not just at the root level.

                      IMPORTANT: Specify directory names only, NOT paths.
                      The script will match these names at any depth.

                      Default: .venv, devtools (always excluded unless removed via --include)

                      Examples:
                        --exclude tests           # Excludes any dir named "tests"
                        --exclude tests,__pycache__,build
                        --exclude "tests,dist"    # Quotes optional

                      Note: Your excludes are ADDED to the defaults (.venv, devtools).

  --include DIRS      Comma-separated list of directory names to REMOVE from
                      the default exclude list.

                      This allows you to force-include directories that are
                      excluded by default.

                      Default: (none - by default, .venv and devtools remain excluded)

                      Examples:
                        --include devtools        # Include devtools in scan
                        --include .venv,devtools  # Include both default excludes
                        --include .venv           # Include only .venv (devtools still excluded)

                      IMPORTANT: --include only affects DEFAULT excludes (.venv, devtools).
                      It does NOT affect directories you add via --exclude.

  -h, --help          Show this help message and exit

EXAMPLES:
  # Basic usage - show top 15 files by character count
  devtools/monitor_repo.sh

  # Show top 30 files
  devtools/monitor_repo.sh --limit 30

  # Show files with highest density first
  devtools/monitor_repo.sh --sort-by dens

  # Show smallest files first
  devtools/monitor_repo.sh --sort l

  # Exclude all "tests" directories anywhere in the tree
  devtools/monitor_repo.sh --exclude tests

  # Exclude multiple directory names
  devtools/monitor_repo.sh --exclude "tests,docs,examples"

  # Include devtools in the scan (remove from default excludes)
  devtools/monitor_repo.sh --include devtools

  # Complex: show top 25, exclude tests, include devtools, sort by density
  devtools/monitor_repo.sh --limit 25 --exclude tests --include devtools --sort-by dens

OUTPUT:
  First line shows aggregate statistics across ALL scanned files:
    FILES   - Total number of Python files found
    LINES   - Total lines across all files
    CHARS   - Total characters across all files
    DENSITY - min/max/avg/median density values

  Following lines show the top 20 files sorted by your chosen metric.

TROUBLESHOOTING:
  Q: Why are test files still appearing?
  A: Use --exclude tests (without any path separators)

  Q: How do I exclude nested directories like packages/foo/tests?
  A: Just use --exclude tests - it matches ANY directory named "tests"

  Q: Can I use wildcards or glob patterns?
  A: No, specify exact directory names only. The script handles matching
     at any depth automatically.

  Q: How do I see devtools files?
  A: Use --include devtools to remove it from default excludes
EOH
}

sort_by="chars"
sort_order="h"
limit=15
exclude_dirs=(".venv" "devtools")
include_dirs=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --limit)
            if [[ $# -lt 2 || $2 == -* ]]; then
                echo "Error: --limit requires a number" >&2
                usage >&2
                exit 1
            fi
            shift
            limit="$1"
            # Validate it's a positive integer
            if ! [[ "$limit" =~ ^[0-9]+$ ]] || [[ $limit -lt 1 ]]; then
                echo "Error: --limit must be a positive integer" >&2
                exit 1
            fi
            ;;
        --sort-by)
            if [[ $# -lt 2 || $2 == -* ]]; then
                echo "Error: --sort-by requires a value (chars or dens)" >&2
                usage >&2
                exit 1
            fi
            shift
            sort_by="$1"
            ;;
        --sort)
            if [[ $# -lt 2 || $2 == -* ]]; then
                echo "Error: --sort requires a value (h or l)" >&2
                usage >&2
                exit 1
            fi
            shift
            sort_order="$1"
            ;;
        --exclude)
            if [[ $# -lt 2 || $2 == -* ]]; then
                echo "Error: --exclude requires a comma-separated list of directories" >&2
                usage >&2
                exit 1
            fi
            shift
            IFS=',' read -r -a extra_excludes <<< "$1"
            for dir in "${extra_excludes[@]}"; do
                # Strip any leading/trailing slashes and whitespace
                dir="${dir#"${dir%%[![:space:]]*}"}"  # trim leading whitespace
                dir="${dir%"${dir##*[![:space:]]}"}"  # trim trailing whitespace
                dir="${dir#/}"  # strip leading slash
                dir="${dir%/}"  # strip trailing slash
                [[ -n $dir ]] && exclude_dirs+=("$dir")
            done
            ;;
        --include)
            if [[ $# -lt 2 || $2 == -* ]]; then
                echo "Error: --include requires a comma-separated list of directories" >&2
                usage >&2
                exit 1
            fi
            shift
            IFS=',' read -r -a extra_includes <<< "$1"
            # Store included dirs to prevent later exclusion
            for dir in "${extra_includes[@]}"; do
                # Strip any leading/trailing slashes and whitespace
                dir="${dir#"${dir%%[![:space:]]*}"}"  # trim leading whitespace
                dir="${dir%"${dir##*[![:space:]]}"}"  # trim trailing whitespace
                dir="${dir#/}"  # strip leading slash
                dir="${dir%/}"  # strip trailing slash
                [[ -z $dir ]] && continue
                # Remove any matching directory from the exclude list (normalize trailing slashes)
                tmp=()
                for ex in "${exclude_dirs[@]}"; do
                    [[ "$ex" != "$dir" ]] && tmp+=("$ex")
                done
                exclude_dirs=("${tmp[@]}")
            done
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage >&2
            exit 1
            ;;
    esac
    shift
done

case "$sort_by" in
    chars)
        sort_column=3
        ;;
    dens)
        sort_column=4
        ;;
    *)
        echo "Invalid --sort-by value: $sort_by" >&2
        usage >&2
        exit 1
        ;;
esac

case "$sort_order" in
    h)
        sort_flags="-rn"
        ;;
    l)
        sort_flags="-n"
        ;;
    *)
        echo "Invalid --sort value: $sort_order" >&2
        usage >&2
        exit 1
        ;;
esac

tmpfile=$(mktemp)

# Show what's being excluded (helpful UX feedback)
if [[ ${#exclude_dirs[@]} -gt 0 ]]; then
    echo "Excluding directories: ${exclude_dirs[*]}" >&2
fi

# Find Python files and calculate metrics
# Build find filters to exclude directories at any depth in the tree
find_filters=()
for ex in "${exclude_dirs[@]}"; do
    # Match the directory name anywhere in the path (not just at root)
    find_filters+=( ! -path "*/${ex}/*" )
done

find . -name "*.py" -type f "${find_filters[@]}" | while read file; do
    lines=$(wc -l < "$file")
    chars=$(wc -c < "$file")
    if [[ "$lines" -gt 0 ]]; then
        density=$(( chars / lines ))
    else
        density=0
    fi
    printf "%s|%d|%d|%d\n" "$file" "$lines" "$chars" "$density" >> "$tmpfile"
done

# Calculate statistics on ALL files
total_files=$(wc -l < "$tmpfile")

# Check if any files were found
if [[ $total_files -eq 0 ]]; then
    echo "" >&2
    echo "⚠️  No Python files found with current filters!" >&2
    echo "" >&2
    echo "Current exclusions: ${exclude_dirs[*]}" >&2
    echo "" >&2
    echo "Try:" >&2
    echo "  - Reducing exclusions with different --exclude values" >&2
    echo "  - Using --include to re-add default excludes (.venv, devtools)" >&2
    echo "  - Running without any flags to see all files except defaults" >&2
    rm -f "$tmpfile"
    exit 0
fi

total_lines=$(awk -F'|' '{sum+=$2} END {print sum}' "$tmpfile")
total_chars=$(awk -F'|' '{sum+=$3} END {print sum}' "$tmpfile")
min_density=$(awk -F'|' 'BEGIN{min=999999} {if($4<min) min=$4} END{print min}' "$tmpfile")
max_density=$(awk -F'|' 'BEGIN{max=0} {if($4>max) max=$4} END{print max}' "$tmpfile")
avg_density=$(awk -F'|' '{sum+=$4; n++} END {if(n>0) print int(sum/n); else print 0}' "$tmpfile")

# Fix median calculation
median_density=$(sort -t'|' -k4 -n "$tmpfile" | awk -F'|' -v total="$total_files" 'BEGIN{mid=(total+1)/2} NR==int(mid) {print $4}')

# Print summary at top
sort_desc=""
case "$sort_by" in
    chars) sort_desc="size" ;;
    dens) sort_desc="density" ;;
esac
order_desc=""
case "$sort_order" in
    h) order_desc="↓" ;;
    l) order_desc="↑" ;;
esac

printf "FILES: %d | LINES: %d | CHARS: %d | DENSITY: min=%d max=%d avg=%d med=%d | Sort: %s %s | Showing: top %d\n" \
    "$total_files" "$total_lines" "$total_chars" "$min_density" "$max_density" "$avg_density" "$median_density" "$sort_desc" "$order_desc" "$limit"
printf "%s\n" "$(printf '=%.0s' {1..100})"

# Header
printf "%-3s %-47s %8s %8s %8s\n" "#" "FILE" "LINES" "CHARS" "DENSITY"
printf "%s\n" "$(printf '=%.0s' {1..80})"

# Sort and display top N using selected metric
rank=1
sort -t'|' -k${sort_column} ${sort_flags} "$tmpfile" | head -${limit} | while IFS='|' read file lines chars density; do
    display_file="$file"
    if [[ ${#display_file} -gt 47 ]]; then
        display_file="…${display_file: -46}"
    fi
    # Highlight the sorted column value
    case "$sort_by" in
        chars)
            printf "%-3d %-47s %8d %8d %8d\n" "$rank" "$display_file" "$lines" "$chars" "$density"
            ;;
        dens)
            printf "%-3d %-47s %8d %8d %8d\n" "$rank" "$display_file" "$lines" "$chars" "$density"
            ;;
    esac
    ((rank++))
done

echo "" >&2
echo "💡 Tip: Use --exclude tests to skip test files, or --help for more options" >&2

rm -f "$tmpfile"
