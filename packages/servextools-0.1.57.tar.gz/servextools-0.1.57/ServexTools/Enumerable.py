class TipoMensaje:
    ALT = "ALT"
    MSJ = "MSJ"

class Metodo:
    GET = "GET"
    POST = "POST"

class async_mode:
    GEVENT = "gevent"
    THREADING = "threading"
    ASGI = "asgi"