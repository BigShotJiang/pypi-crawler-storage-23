import uuid
import time
import traceback
import subprocess
from pyspark.sql import functions as F
from datetime import date, datetime
from gss_spark_flow import io as sf_io


class PipelineContext:

    def __init__(self, spark, pipeline_name, task_name=None,
                 sla_minutes=60,
                 trigger_type="manual",
                 dataset=None,
                 run_id=None,
                 auto_start=True):

        self.spark = spark
        self.pipeline_name = pipeline_name
        self.task_name = task_name
        self.sla_minutes = sla_minutes
        self.trigger_type = trigger_type
        self.dataset = dataset

        self.run_id = run_id or str(uuid.uuid4())
        self.task_run_id = None
        self._owns_run = run_id is None
        self._run_started = False
        self._task_started = False

        self.start_time = None
        self.task_start_time = None
        self._task_run_columns = None

        self.git_sha = self._get_git_sha()
        self.triggered_by = self._get_user()
        self.spark_app_id = spark.sparkContext.applicationId

        if auto_start:
            if self.task_name:
                self.start()
            else:
                self.start_run()

    # -------------------------------------

    def _get_git_sha(self):
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                check=True,
                capture_output=True,
                text=True,
            )
            return result.stdout.strip()
        except Exception:
            return None

    def _sql_str_or_null(self, value):
        if value is None:
            return "NULL"
        clean_value = str(value).replace("'", "")
        return f"'{clean_value}'"

    def _get_user(self):
        return self.spark.sparkContext.sparkUser()

    def _normalize_watermark_type(self, wm_type):
        if not wm_type:
            return "string"

        value = str(wm_type).lower().strip()
        if value.startswith("decimal"):
            return "decimal"
        if value in {"byte", "short", "int", "integer", "long", "bigint"}:
            return "long"
        if value in {"float", "double"}:
            return "double"
        if value in {"bool", "boolean"}:
            return "boolean"
        if value in {"timestamp", "date", "string"}:
            return value
        return "string"

    def _infer_watermark_type_from_value(self, value):
        if isinstance(value, bool):
            return "boolean"
        if isinstance(value, int):
            return "long"
        if isinstance(value, float):
            return "double"
        if isinstance(value, datetime):
            return "timestamp"
        if isinstance(value, date):
            return "date"
        return "string"

    def _infer_watermark_type_from_df(self, df, watermark_column):
        return self._normalize_watermark_type(df.schema[watermark_column].dataType.simpleString())

    def _serialize_watermark(self, value, watermark_type=None):
        if value is None:
            return None

        normalized = self._normalize_watermark_type(
            watermark_type or self._infer_watermark_type_from_value(value)
        )

        if normalized == "boolean":
            return "true" if bool(value) else "false"
        if normalized == "long":
            return str(int(value))
        if normalized in {"double", "decimal"}:
            return str(float(value))
        if normalized == "timestamp":
            if isinstance(value, datetime):
                return value.isoformat()
            if isinstance(value, date):
                return datetime(value.year, value.month, value.day).isoformat()
            if isinstance(value, (int, float)):
                return datetime.fromtimestamp(float(value)).isoformat()
            return str(value)
        if normalized == "date":
            if isinstance(value, datetime):
                return value.date().isoformat()
            if isinstance(value, date):
                return value.isoformat()
            if isinstance(value, (int, float)):
                return datetime.fromtimestamp(float(value)).date().isoformat()
            return str(value)

        return str(value)

    def _deserialize_watermark(self, value, wm_type):
        if value is None:
            return None

        normalized = self._normalize_watermark_type(wm_type)
        try:
            if normalized == "long":
                return int(value)
            if normalized == "double":
                return float(value)
            if normalized == "boolean":
                return str(value).lower() == "true"
            if normalized == "timestamp":
                return datetime.fromisoformat(str(value))
            if normalized == "date":
                return date.fromisoformat(str(value))
        except Exception:
            return value
        return value

    def _minimum_watermark_value(self, watermark_type):
        normalized = self._normalize_watermark_type(watermark_type)
        if normalized == "long":
            return 0
        if normalized in {"double", "decimal"}:
            return 0.0
        if normalized == "boolean":
            return False
        if normalized == "date":
            return date(1900, 1, 1)
        if normalized == "timestamp":
            return datetime(1900, 1, 1, 0, 0, 0)
        if normalized == "string":
            return ""
        return None

    def _parse_merge_keys(self, merge_keys):
        if merge_keys is None:
            return None
        if isinstance(merge_keys, list):
            return [str(x).strip() for x in merge_keys if str(x).strip()]
        return [k.strip() for k in str(merge_keys).split(",") if k.strip()]

    def _get_dataset_config(self):
        if not self.dataset:
            return {}
        try:
            result = self.spark.sql(f"""
            SELECT source_table, target_table, watermark_column, watermark_type, merge_keys
            FROM metadata.dataset_config
            WHERE pipeline_name = '{self.pipeline_name}'
            AND dataset = '{self.dataset}'
            ORDER BY updated_ts DESC
            LIMIT 1
            """).collect()
        except Exception:
            return {}

        if not result:
            return {}

        row = result[0]
        return {
            "source_table": row[0],
            "target_table": row[1],
            "watermark_column": row[2],
            "watermark_type": self._normalize_watermark_type(row[3]) if row[3] else None,
            "merge_keys": self._parse_merge_keys(row[4]),
        }

    def _resolve_target_table(self, target_table):
        config = self._get_dataset_config()
        resolved = target_table or config.get("target_table") or self.dataset
        if not resolved:
            raise ValueError("target_table is required when dataset is not set in PipelineContext")
        return resolved

    def _resolve_merge_keys(self, merge_keys=None):
        parsed = self._parse_merge_keys(merge_keys)
        if parsed:
            return parsed

        config = self._get_dataset_config()
        resolved = config.get("merge_keys")
        if resolved:
            return resolved

        raise ValueError(
            "merge_keys is not configured. Set metadata.dataset_config.merge_keys "
            "for this pipeline_name + dataset."
        )

    def _resolve_watermark_config(self, df=None, watermark_column=None, watermark_type=None):
        config = self._get_dataset_config()
        metadata_wm = self.get_watermark(include_metadata=True) if self.dataset else {}
        resolved_column = (
            watermark_column
            or config.get("watermark_column")
            or metadata_wm.get("watermark_column")
        )
        resolved_type = (
            watermark_type
            or config.get("watermark_type")
            or metadata_wm.get("watermark_type")
        )

        if resolved_column and not resolved_type and df is not None and resolved_column in df.columns:
            resolved_type = self._infer_watermark_type_from_df(df, resolved_column)

        if resolved_type:
            resolved_type = self._normalize_watermark_type(resolved_type)

        return resolved_column, resolved_type

    def _get_task_run_columns(self):
        if self._task_run_columns is not None:
            return self._task_run_columns
        try:
            self._task_run_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.task_run").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._task_run_columns = set()
        return self._task_run_columns

    def _ensure_task_run_row(self):
        self.spark.sql(f"""
        INSERT INTO metadata.task_run (task_run_id, run_id, task_name, start_ts, status)
        SELECT
            '{self.task_run_id}',
            '{self.run_id}',
            '{self.task_name}',
            current_timestamp(),
            'RUNNING'
        WHERE NOT EXISTS (
            SELECT 1
            FROM metadata.task_run
            WHERE task_run_id = '{self.task_run_id}'
        )
        """)

    def _ensure_run_row(self):
        self.spark.sql(f"""
        INSERT INTO metadata.run (
            run_id,
            pipeline_name,
            git_sha,
            triggered_by,
            trigger_type,
            start_ts,
            end_ts,
            status,
            sla_minutes,
            duration_ms,
            spark_app_id
        )
        SELECT
            '{self.run_id}',
            '{self.pipeline_name}',
            {self._sql_str_or_null(self.git_sha)},
            '{self.triggered_by}',
            '{self.trigger_type}',
            current_timestamp(),
            NULL,
            'RUNNING',
            {self.sla_minutes},
            NULL,
            '{self.spark_app_id}'
        WHERE NOT EXISTS (
            SELECT 1
            FROM metadata.run
            WHERE run_id = '{self.run_id}'
        )
        """)

    def _update_task_run_metrics(self, metrics):
        if not self._task_started or not self.task_run_id:
            return
        task_run_columns = self._get_task_run_columns()
        numeric_fields = [
            "rows_in",
            "rows_out",
            "rows_inserted",
            "rows_updated",
            "rows_deleted",
            "target_rows_total",
            "duration_ms",
        ]
        text_fields = ["watermark_in", "watermark_out"]

        assignments = []
        for field in numeric_fields:
            if field in task_run_columns and field in metrics:
                value = metrics.get(field)
                if value is None:
                    assignments.append(f"{field} = NULL")
                else:
                    assignments.append(f"{field} = {int(value)}")

        for field in text_fields:
            if field in task_run_columns and field in metrics:
                assignments.append(f"{field} = {self._sql_str_or_null(metrics.get(field))}")

        if not assignments:
            return

        self._ensure_task_run_row()
        self.spark.sql(f"""
        UPDATE metadata.task_run
        SET {', '.join(assignments)}
        WHERE task_run_id = '{self.task_run_id}'
        """)

    def _get_target_rows_total(self, target_table):
        try:
            return self.spark.table(target_table).count()
        except Exception:
            return None

    # -------------------------------------

    def start_run(self):
        if self._run_started:
            return

        self.start_time = time.time()
        self._ensure_run_row()
        self._run_started = True

    def start_task(self, task_name=None, dataset=None):
        if self._task_started:
            raise RuntimeError(
                "There is an active task in RUNNING state. "
                "Call success_task() or fail_task(e) before start_task()."
            )

        if task_name is not None:
            self.task_name = task_name
        if dataset is not None:
            self.dataset = dataset

        if not self.task_name:
            raise ValueError("task_name is required to start a task")

        self.start_run()
        self.task_run_id = str(uuid.uuid4())
        self.task_start_time = time.time()
        self._ensure_task_run_row()
        self._task_started = True

    def _ensure_task_started(self):
        if not self._task_started:
            self.start_task()

    def start(self):
        self.start_run()
        if not self._task_started:
            self.start_task()

    # -------------------------------------

    def get_watermark(self, include_metadata=False):

        if not self.dataset:
            if include_metadata:
                return {"value": None, "watermark_column": None, "watermark_type": None}
            return None

        try:
            result = self.spark.sql(f"""
            SELECT last_watermark, watermark_column, watermark_type
            FROM metadata.watermark_state
            WHERE pipeline_name = '{self.pipeline_name}'
            AND dataset = '{self.dataset}'
            ORDER BY updated_ts DESC
            LIMIT 1
            """).collect()
        except Exception:
            result = self.spark.sql(f"""
            SELECT last_watermark, NULL as watermark_column, NULL as watermark_type
            FROM metadata.watermark_state
            WHERE pipeline_name = '{self.pipeline_name}'
            AND dataset = '{self.dataset}'
            ORDER BY updated_ts DESC
            LIMIT 1
            """).collect()

        if not result:
            if include_metadata:
                return {"value": None, "watermark_column": None, "watermark_type": None}
            return None

        row = result[0]
        parsed_value = self._deserialize_watermark(row[0], row[2])
        if include_metadata:
            return {
                "value": parsed_value,
                "watermark_column": row[1],
                "watermark_type": self._normalize_watermark_type(row[2]),
            }
        return parsed_value

    # -------------------------------------

    def update_watermark(self, new_wm, watermark_column=None, watermark_type=None):

        if not self.dataset:
            return

        resolved_column, resolved_config_type = self._resolve_watermark_config(
            watermark_column=watermark_column,
            watermark_type=watermark_type,
        )
        resolved_type = self._normalize_watermark_type(
            resolved_config_type or self._infer_watermark_type_from_value(new_wm)
        )
        serialized_wm = self._serialize_watermark(new_wm, resolved_type)

        self.spark.sql(f"""
        MERGE INTO metadata.watermark_state t
        USING (SELECT
            '{self.pipeline_name}' as pipeline_name,
            '{self.dataset}' as dataset,
            {self._sql_str_or_null(serialized_wm)} as last_watermark,
            {self._sql_str_or_null(resolved_column)} as watermark_column,
            {self._sql_str_or_null(resolved_type)} as watermark_type,
            '{self.run_id}' as last_run_id,
            current_timestamp() as updated_ts
        ) s
        ON t.pipeline_name = s.pipeline_name
        AND t.dataset = s.dataset
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
        """)

    # -------------------------------------

    def reset_watermark(self, mode="null", watermark_column=None, watermark_type=None):

        normalized_mode = str(mode).lower().strip()
        if normalized_mode not in {"null", "min"}:
            raise ValueError("mode must be 'null' or 'min'")

        resolved_column, resolved_type = self._resolve_watermark_config(
            watermark_column=watermark_column,
            watermark_type=watermark_type,
        )
        normalized_type = self._normalize_watermark_type(
            resolved_type or "string"
        )
        value = None if normalized_mode == "null" else self._minimum_watermark_value(normalized_type)

        self.update_watermark(
            value,
            watermark_column=resolved_column,
            watermark_type=normalized_type,
        )
        return value

    # -------------------------------------

    def set_dataset_config(
        self,
        source_table=None,
        target_table=None,
        merge_keys=None,
        watermark_column=None,
        watermark_type=None,
    ):
        if not self.dataset:
            raise ValueError("dataset is required in PipelineContext to set dataset_config")

        merge_keys_value = None
        parsed_merge_keys = self._parse_merge_keys(merge_keys)
        if parsed_merge_keys:
            merge_keys_value = ",".join(parsed_merge_keys)

        normalized_wm_type = (
            self._normalize_watermark_type(watermark_type) if watermark_type else None
        )

        self.spark.sql(f"""
        MERGE INTO metadata.dataset_config t
        USING (SELECT
            '{self.pipeline_name}' as pipeline_name,
            '{self.dataset}' as dataset,
            {self._sql_str_or_null(source_table)} as source_table,
            {self._sql_str_or_null(target_table)} as target_table,
            {self._sql_str_or_null(watermark_column)} as watermark_column,
            {self._sql_str_or_null(normalized_wm_type)} as watermark_type,
            {self._sql_str_or_null(merge_keys_value)} as merge_keys,
            current_timestamp() as updated_ts
        ) s
        ON t.pipeline_name = s.pipeline_name
        AND t.dataset = s.dataset
        WHEN MATCHED THEN UPDATE SET
            source_table = COALESCE(s.source_table, t.source_table),
            target_table = COALESCE(s.target_table, t.target_table),
            watermark_column = COALESCE(s.watermark_column, t.watermark_column),
            watermark_type = COALESCE(s.watermark_type, t.watermark_type),
            merge_keys = COALESCE(s.merge_keys, t.merge_keys),
            updated_ts = s.updated_ts
        WHEN NOT MATCHED THEN INSERT *
        """)

    def get_dataset_config(self):
        return self._get_dataset_config()

    # -------------------------------------

    def write_output(self, df, output_table=None):
        self._ensure_task_started()

        target_table = self._resolve_target_table(output_table)
        watermark_before = self.get_watermark(include_metadata=True)
        serialized_watermark_in = self._serialize_watermark(
            watermark_before.get("value"),
            watermark_before.get("watermark_type"),
        )
        write_metrics = sf_io.write_append(df, target_table)

        resolved_column, resolved_type = self._resolve_watermark_config(df=df)
        serialized_watermark_out = None
        if resolved_column:
            max_wm = df.agg(F.max(resolved_column)).collect()[0][0]
            if not resolved_type:
                resolved_type = self._infer_watermark_type_from_df(df, resolved_column)
            self.update_watermark(
                max_wm,
                watermark_column=resolved_column,
                watermark_type=resolved_type,
            )
            serialized_watermark_out = self._serialize_watermark(max_wm, resolved_type)

        duration = int((time.time() - self.task_start_time) * 1000)
        target_rows_total = self._get_target_rows_total(target_table)

        self._update_task_run_metrics({
            "rows_in": write_metrics.get("rows_in"),
            "rows_out": write_metrics.get("rows_out"),
            "rows_inserted": write_metrics.get("rows_inserted"),
            "rows_updated": write_metrics.get("rows_updated"),
            "rows_deleted": write_metrics.get("rows_deleted"),
            "target_rows_total": target_rows_total,
            "duration_ms": duration,
            "watermark_in": serialized_watermark_in,
            "watermark_out": serialized_watermark_out,
        })

        self.spark.sql(f"""
        INSERT INTO metadata.lineage VALUES (
            '{self.run_id}',
            '{self.task_name}',
            'unknown',
            '{target_table}',
            current_timestamp()
        )
        """)

    # -------------------------------------

    def write_overwrite(self, df, output_table=None):
        self._ensure_task_started()

        target_table = self._resolve_target_table(output_table)
        watermark_before = self.get_watermark(include_metadata=True)
        serialized_watermark_in = self._serialize_watermark(
            watermark_before.get("value"),
            watermark_before.get("watermark_type"),
        )
        write_metrics = sf_io.write_overwrite(df, target_table)

        resolved_column, resolved_type = self._resolve_watermark_config(df=df)
        serialized_watermark_out = None
        if resolved_column:
            max_wm = df.agg(F.max(resolved_column)).collect()[0][0]
            if not resolved_type:
                resolved_type = self._infer_watermark_type_from_df(df, resolved_column)
            self.update_watermark(
                max_wm,
                watermark_column=resolved_column,
                watermark_type=resolved_type,
            )
            serialized_watermark_out = self._serialize_watermark(max_wm, resolved_type)

        duration = int((time.time() - self.task_start_time) * 1000)
        target_rows_total = self._get_target_rows_total(target_table)

        self._update_task_run_metrics({
            "rows_in": write_metrics.get("rows_in"),
            "rows_out": write_metrics.get("rows_out"),
            "rows_inserted": write_metrics.get("rows_inserted"),
            "rows_updated": write_metrics.get("rows_updated"),
            "rows_deleted": write_metrics.get("rows_deleted"),
            "target_rows_total": target_rows_total,
            "duration_ms": duration,
            "watermark_in": serialized_watermark_in,
            "watermark_out": serialized_watermark_out,
        })

        self.spark.sql(f"""
        INSERT INTO metadata.lineage VALUES (
            '{self.run_id}',
            '{self.task_name}',
            'unknown',
            '{target_table}',
            current_timestamp()
        )
        """)

    # -------------------------------------

    def write_merge(
        self,
        df,
        target_table=None,
        update_columns=None,
        insert_only=False,
        key_type_mismatch_action="error",
        create_target_if_missing=True,
    ):
        self._ensure_task_started()

        target = self._resolve_target_table(target_table)
        resolved_merge_keys = self._resolve_merge_keys()
        watermark_before = self.get_watermark(include_metadata=True)
        serialized_watermark_in = self._serialize_watermark(
            watermark_before.get("value"),
            watermark_before.get("watermark_type"),
        )
        merge_metrics = sf_io.write_merge(
            spark=self.spark,
            df=df,
            target_table=target,
            merge_keys=resolved_merge_keys,
            update_columns=update_columns,
            insert_only=insert_only,
            mismatch_action=key_type_mismatch_action,
            create_target_if_missing=create_target_if_missing,
        )

        resolved_column, resolved_type = self._resolve_watermark_config(df=df)
        serialized_watermark_out = None
        if resolved_column:
            max_wm = df.agg(F.max(resolved_column)).collect()[0][0]
            if not resolved_type:
                resolved_type = self._infer_watermark_type_from_df(df, resolved_column)
            self.update_watermark(
                max_wm,
                watermark_column=resolved_column,
                watermark_type=resolved_type,
            )
            serialized_watermark_out = self._serialize_watermark(max_wm, resolved_type)

        duration = int((time.time() - self.task_start_time) * 1000)
        target_rows_total = self._get_target_rows_total(target)

        self._update_task_run_metrics({
            "rows_in": merge_metrics.get("rows_in"),
            "rows_out": merge_metrics.get("rows_out"),
            "rows_inserted": merge_metrics.get("rows_inserted"),
            "rows_updated": merge_metrics.get("rows_updated"),
            "rows_deleted": merge_metrics.get("rows_deleted"),
            "target_rows_total": target_rows_total,
            "duration_ms": duration,
            "watermark_in": serialized_watermark_in,
            "watermark_out": serialized_watermark_out,
        })

        self.spark.sql(f"""
        INSERT INTO metadata.lineage VALUES (
            '{self.run_id}',
            '{self.task_name}',
            'unknown',
            '{target}',
            current_timestamp()
        )
        """)

    # -------------------------------------

    def success_task(self):
        if not self._task_started or not self.task_run_id:
            return

        self.spark.sql(f"""
        UPDATE metadata.task_run
        SET status = 'SUCCESS',
            end_ts = current_timestamp()
        WHERE task_run_id = '{self.task_run_id}'
        """)
        self._task_started = False

    def fail_task(self, e):
        if not self._task_started or not self.task_run_id:
            return

        stack = traceback.format_exc()
        error_id = str(uuid.uuid4())

        self.spark.sql(f"""
        INSERT INTO metadata.error_log VALUES (
            '{error_id}',
            '{self.run_id}',
            '{self.task_name}',
            '{type(e).__name__}',
            '{str(e).replace("'", "")}',
            '{stack.replace("'", "")}',
            current_timestamp()
        )
        """)

        self.spark.sql(f"""
        UPDATE metadata.task_run
        SET status = 'FAILED',
            end_ts = current_timestamp()
        WHERE task_run_id = '{self.task_run_id}'
        """)
        self._task_started = False

    def success_run(self):
        self.start_run()
        end_time = time.time()
        duration = int((end_time - self.start_time) * 1000) if self.start_time else None
        duration_expr = "NULL" if duration is None else str(duration)
        self.spark.sql(f"""
        UPDATE metadata.run
        SET status = 'SUCCESS',
            end_ts = current_timestamp(),
            duration_ms = {duration_expr}
        WHERE run_id = '{self.run_id}'
        """)
        self._run_started = False

    def fail_run(self):
        self.start_run()
        self.spark.sql(f"""
        UPDATE metadata.run
        SET status = 'FAILED',
            end_ts = current_timestamp()
        WHERE run_id = '{self.run_id}'
        """)
        self._run_started = False

    # -------------------------------------

    def success(self, close_run=None):

        if close_run is None:
            close_run = self._owns_run

        self.success_task()
        if close_run:
            self.success_run()

    # -------------------------------------

    def fail(self, e, close_run=None):

        if close_run is None:
            close_run = self._owns_run

        self.fail_task(e)
        if close_run:
            self.fail_run()
