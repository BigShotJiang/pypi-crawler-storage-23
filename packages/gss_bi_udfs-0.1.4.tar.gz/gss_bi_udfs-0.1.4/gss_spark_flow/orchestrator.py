from datetime import datetime, timedelta


class PipelineOrchestrator:

    def __init__(self, spark):
        self.spark = spark
        self._dependency_columns = None

    # -------------------------------------
    # Internal helpers
    # -------------------------------------

    def _clean(self, value):
        if value is None:
            return None
        cleaned = str(value).replace("'", "").strip()
        return cleaned if cleaned else None

    def _sql_str_or_null(self, value):
        cleaned = self._clean(value)
        if cleaned is None:
            return "NULL"
        return f"'{cleaned}'"

    def _normalize_dependency_mode(self, mode):
        normalized = str(mode or "hard").lower().strip()
        if normalized not in {"hard", "soft"}:
            raise ValueError("dependency_mode must be 'hard' or 'soft'")
        return normalized

    def _normalize_freshness_hours(self, freshness_hours):
        if freshness_hours is None:
            return None
        hours = int(freshness_hours)
        if hours <= 0:
            raise ValueError("freshness_hours must be > 0")
        return hours

    def _get_dependency_columns(self):
        if self._dependency_columns is not None:
            return self._dependency_columns
        try:
            self._dependency_columns = {
                row[0]
                for row in self.spark.sql("DESCRIBE metadata.pipeline_dependency").collect()
                if row[0] and not row[0].startswith("#")
            }
        except Exception:
            self._dependency_columns = set()
        return self._dependency_columns

    def _require_dependency_columns(self, required_columns):
        existing = self._get_dependency_columns()
        missing = [col for col in required_columns if col not in existing]
        if missing:
            raise ValueError(
                "metadata.pipeline_dependency is missing columns: "
                f"{missing}. Re-run init_metadata_layer to apply migrations."
            )

    def _dependency_node(self, pipeline_name, dataset=None):
        dataset_part = dataset if dataset is not None else "*"
        return f"{pipeline_name}::{dataset_part}"

    def _fetch_dependencies(self, child_pipeline, child_dataset=None):
        child = self._clean(child_pipeline)
        if child is None:
            raise ValueError("pipeline_name is required")
        child_ds = self._clean(child_dataset)

        cols = self._get_dependency_columns()
        parent_dataset_expr = "parent_dataset" if "parent_dataset" in cols else "NULL as parent_dataset"
        child_dataset_expr = "child_dataset" if "child_dataset" in cols else "NULL as child_dataset"
        mode_expr = "dependency_mode" if "dependency_mode" in cols else "'hard' as dependency_mode"
        freshness_expr = "freshness_hours" if "freshness_hours" in cols else "NULL as freshness_hours"

        if child_ds is None:
            dataset_filter = ""
        elif "child_dataset" in cols:
            dataset_filter = f"AND (child_dataset IS NULL OR child_dataset = '{child_ds}')"
        else:
            dataset_filter = ""

        rows = self.spark.sql(f"""
        SELECT
            parent_pipeline,
            {parent_dataset_expr},
            child_pipeline,
            {child_dataset_expr},
            {mode_expr},
            {freshness_expr}
        FROM metadata.pipeline_dependency
        WHERE child_pipeline = '{child}'
        {dataset_filter}
        ORDER BY parent_pipeline
        """).collect()

        return [
            {
                "parent_pipeline": row[0],
                "parent_dataset": row[1],
                "child_pipeline": row[2],
                "child_dataset": row[3],
                "dependency_mode": self._normalize_dependency_mode(row[4]),
                "freshness_hours": int(row[5]) if row[5] is not None else None,
            }
            for row in rows
        ]

    def _get_last_run(self, pipeline_name, dataset=None, success_only=False):
        pipeline = self._clean(pipeline_name)
        dataset_clean = self._clean(dataset)
        status_filter = "AND r.status = 'SUCCESS'" if success_only else ""

        if dataset_clean is None:
            rows = self.spark.sql(f"""
            SELECT r.run_id, r.status, r.start_ts, r.end_ts
            FROM metadata.run r
            WHERE r.pipeline_name = '{pipeline}'
            {status_filter}
            ORDER BY r.start_ts DESC
            LIMIT 1
            """).collect()
        else:
            rows = self.spark.sql(f"""
            SELECT r.run_id, r.status, r.start_ts, r.end_ts
            FROM metadata.run r
            WHERE r.pipeline_name = '{pipeline}'
            {status_filter}
              AND r.run_id IN (
                  SELECT DISTINCT t.run_id
                  FROM metadata.task_run t
                  LEFT JOIN metadata.lineage l
                    ON l.run_id = t.run_id
                   AND l.task_name = t.task_name
                  LEFT JOIN metadata.dataset_config dc
                    ON dc.pipeline_name = '{pipeline}'
                   AND dc.target_table = l.output_table
                  WHERE dc.dataset = '{dataset_clean}'
                     OR dc.target_table = '{dataset_clean}'
              )
            ORDER BY r.start_ts DESC
            LIMIT 1
            """).collect()

        if not rows:
            return None
        row = rows[0]
        return {
            "run_id": row[0],
            "status": row[1],
            "start_ts": row[2],
            "end_ts": row[3],
        }

    def _get_run_change_stats(self, run_id, pipeline_name, dataset=None):
        run = self._clean(run_id)
        pipeline = self._clean(pipeline_name)
        dataset_clean = self._clean(dataset)

        if dataset_clean is None:
            rows = self.spark.sql(f"""
            SELECT
                SUM(COALESCE(rows_inserted, 0)) AS rows_inserted,
                SUM(COALESCE(rows_updated, 0)) AS rows_updated,
                SUM(COALESCE(rows_deleted, 0)) AS rows_deleted,
                SUM(COALESCE(rows_out, 0))      AS rows_out
            FROM metadata.task_run
            WHERE run_id = '{run}'
            """).collect()
        else:
            rows = self.spark.sql(f"""
            WITH scoped_tasks AS (
                SELECT DISTINCT
                    t.task_run_id,
                    t.rows_inserted,
                    t.rows_updated,
                    t.rows_deleted,
                    t.rows_out
                FROM metadata.task_run t
                LEFT JOIN metadata.lineage l
                  ON l.run_id = t.run_id
                 AND l.task_name = t.task_name
                LEFT JOIN metadata.dataset_config dc
                  ON dc.pipeline_name = '{pipeline}'
                 AND dc.target_table = l.output_table
                WHERE t.run_id = '{run}'
                  AND (
                    dc.dataset = '{dataset_clean}'
                    OR dc.target_table = '{dataset_clean}'
                  )
            )
            SELECT
                SUM(COALESCE(rows_inserted, 0)) AS rows_inserted,
                SUM(COALESCE(rows_updated, 0)) AS rows_updated,
                SUM(COALESCE(rows_deleted, 0)) AS rows_deleted,
                SUM(COALESCE(rows_out, 0))      AS rows_out
            FROM scoped_tasks
            """).collect()

        row = rows[0]
        return {
            "rows_inserted": int(row[0] or 0),
            "rows_updated": int(row[1] or 0),
            "rows_deleted": int(row[2] or 0),
            "rows_out": int(row[3] or 0),
        }

    # -------------------------------------
    # Dependency CRUD
    # -------------------------------------

    def add_dependency(
        self,
        parent_pipeline,
        child_pipeline,
        parent_dataset=None,
        child_dataset=None,
        dependency_mode="hard",
        freshness_hours=None,
        validate_cycles=True,
    ):
        parent = self._clean(parent_pipeline)
        child = self._clean(child_pipeline)
        parent_ds = self._clean(parent_dataset)
        child_ds = self._clean(child_dataset)
        mode = self._normalize_dependency_mode(dependency_mode)
        freshness = self._normalize_freshness_hours(freshness_hours)

        if not parent or not child:
            raise ValueError("parent_pipeline and child_pipeline are required")
        if parent == child and parent_ds == child_ds:
            raise ValueError("A pipeline/dataset node cannot depend on itself")

        advanced_requested = (
            parent_ds is not None
            or child_ds is not None
            or mode != "hard"
            or freshness is not None
        )
        if advanced_requested:
            self._require_dependency_columns(
                {"parent_dataset", "child_dataset", "dependency_mode", "freshness_hours"}
            )

        cols = self._get_dependency_columns()
        insert_columns = ["parent_pipeline", "child_pipeline"]
        insert_values = [f"'{parent}'", f"'{child}'"]
        match_conditions = [f"parent_pipeline = '{parent}'", f"child_pipeline = '{child}'"]

        if "parent_dataset" in cols:
            insert_columns.append("parent_dataset")
            insert_values.append(self._sql_str_or_null(parent_ds))
            if parent_ds is None:
                match_conditions.append("parent_dataset IS NULL")
            else:
                match_conditions.append(f"parent_dataset = '{parent_ds}'")

        if "child_dataset" in cols:
            insert_columns.append("child_dataset")
            insert_values.append(self._sql_str_or_null(child_ds))
            if child_ds is None:
                match_conditions.append("child_dataset IS NULL")
            else:
                match_conditions.append(f"child_dataset = '{child_ds}'")

        if "dependency_mode" in cols:
            insert_columns.append("dependency_mode")
            insert_values.append(f"'{mode}'")
            match_conditions.append(f"dependency_mode = '{mode}'")

        if "freshness_hours" in cols:
            insert_columns.append("freshness_hours")
            insert_values.append("NULL" if freshness is None else str(freshness))
            if freshness is None:
                match_conditions.append("freshness_hours IS NULL")
            else:
                match_conditions.append(f"freshness_hours = {freshness}")

        self.spark.sql(f"""
        INSERT INTO metadata.pipeline_dependency ({', '.join(insert_columns)})
        SELECT {', '.join(insert_values)}
        WHERE NOT EXISTS (
            SELECT 1
            FROM metadata.pipeline_dependency
            WHERE {' AND '.join(match_conditions)}
        )
        """)

        if validate_cycles:
            cycles = self.detect_cycles()
            if cycles:
                self.remove_dependency(
                    parent_pipeline=parent,
                    child_pipeline=child,
                    parent_dataset=parent_ds,
                    child_dataset=child_ds,
                    dependency_mode=mode if "dependency_mode" in cols else None,
                    freshness_hours=freshness if "freshness_hours" in cols else None,
                )
                sample_cycle = " -> ".join(cycles[0])
                raise ValueError(
                    "Dependency would create a cycle. "
                    f"Example cycle: {sample_cycle}"
                )

    def remove_dependency(
        self,
        parent_pipeline,
        child_pipeline,
        parent_dataset=None,
        child_dataset=None,
        dependency_mode=None,
        freshness_hours=None,
    ):
        parent = self._clean(parent_pipeline)
        child = self._clean(child_pipeline)
        parent_ds = self._clean(parent_dataset)
        child_ds = self._clean(child_dataset)
        mode = self._clean(dependency_mode)
        freshness = None if freshness_hours is None else int(freshness_hours)

        where = [f"parent_pipeline = '{parent}'", f"child_pipeline = '{child}'"]
        cols = self._get_dependency_columns()

        if "parent_dataset" in cols and parent_dataset is not None:
            where.append(f"parent_dataset = '{parent_ds}'")
        if "child_dataset" in cols and child_dataset is not None:
            where.append(f"child_dataset = '{child_ds}'")
        if "dependency_mode" in cols and dependency_mode is not None:
            where.append(f"dependency_mode = '{mode}'")
        if "freshness_hours" in cols and freshness_hours is not None:
            where.append(f"freshness_hours = {freshness}")

        self.spark.sql(f"""
        DELETE FROM metadata.pipeline_dependency
        WHERE {' AND '.join(where)}
        """)

    def list_dependencies(self, pipeline_name=None, direction="child", dataset=None):
        normalized_direction = str(direction).lower().strip()
        if normalized_direction not in {"child", "parent"}:
            raise ValueError("direction must be 'child' or 'parent'")

        cols = self._get_dependency_columns()
        parent_dataset_expr = "parent_dataset" if "parent_dataset" in cols else "NULL as parent_dataset"
        child_dataset_expr = "child_dataset" if "child_dataset" in cols else "NULL as child_dataset"
        mode_expr = "dependency_mode" if "dependency_mode" in cols else "'hard' as dependency_mode"
        freshness_expr = "freshness_hours" if "freshness_hours" in cols else "NULL as freshness_hours"

        where_clauses = []
        if pipeline_name is not None:
            pipeline = self._clean(pipeline_name)
            field = "child_pipeline" if normalized_direction == "child" else "parent_pipeline"
            where_clauses.append(f"{field} = '{pipeline}'")

            dataset_clean = self._clean(dataset)
            if dataset_clean is not None:
                if normalized_direction == "child" and "child_dataset" in cols:
                    where_clauses.append(f"(child_dataset IS NULL OR child_dataset = '{dataset_clean}')")
                if normalized_direction == "parent" and "parent_dataset" in cols:
                    where_clauses.append(f"(parent_dataset IS NULL OR parent_dataset = '{dataset_clean}')")

        where_sql = ""
        if where_clauses:
            where_sql = "WHERE " + " AND ".join(where_clauses)

        order_sql = "ORDER BY child_pipeline, parent_pipeline"
        if normalized_direction == "child":
            order_sql = "ORDER BY child_pipeline, child_dataset, parent_pipeline, parent_dataset"
        elif normalized_direction == "parent":
            order_sql = "ORDER BY parent_pipeline, parent_dataset, child_pipeline, child_dataset"

        rows = self.spark.sql(f"""
        SELECT
            parent_pipeline,
            {parent_dataset_expr},
            child_pipeline,
            {child_dataset_expr},
            {mode_expr},
            {freshness_expr}
        FROM metadata.pipeline_dependency
        {where_sql}
        {order_sql}
        """).collect()

        return [
            {
                "parent_pipeline": row[0],
                "parent_dataset": row[1],
                "child_pipeline": row[2],
                "child_dataset": row[3],
                "dependency_mode": self._normalize_dependency_mode(row[4]),
                "freshness_hours": int(row[5]) if row[5] is not None else None,
            }
            for row in rows
        ]

    # -------------------------------------
    # Cycle detection
    # -------------------------------------

    def _build_dependency_graph(self):
        deps = self.list_dependencies()
        graph = {}
        for dep in deps:
            parent_node = self._dependency_node(dep["parent_pipeline"], dep.get("parent_dataset"))
            child_node = self._dependency_node(dep["child_pipeline"], dep.get("child_dataset"))

            if parent_node not in graph:
                graph[parent_node] = []
            if child_node not in graph:
                graph[child_node] = []
            graph[parent_node].append(child_node)
        return graph

    def detect_cycles(self):
        graph = self._build_dependency_graph()
        visited = set()
        in_stack = set()
        path = []
        cycles = []
        seen_cycle_keys = set()

        def dfs(node):
            visited.add(node)
            in_stack.add(node)
            path.append(node)

            for nxt in graph.get(node, []):
                if nxt not in visited:
                    dfs(nxt)
                elif nxt in in_stack:
                    idx = path.index(nxt)
                    cycle = path[idx:] + [nxt]
                    key = tuple(cycle)
                    if key not in seen_cycle_keys:
                        seen_cycle_keys.add(key)
                        cycles.append(cycle)

            path.pop()
            in_stack.remove(node)

        for node in list(graph.keys()):
            if node not in visited:
                dfs(node)

        return cycles

    def assert_acyclic(self):
        cycles = self.detect_cycles()
        if cycles:
            sample_cycle = " -> ".join(cycles[0])
            raise ValueError(f"Dependency graph has cycles. Example: {sample_cycle}")
        return True

    # -------------------------------------
    # Execution guards
    # -------------------------------------

    def get_dependency_diagnostics(
        self,
        pipeline_name,
        dataset=None,
        require_parent_latest_success=True,
        require_parent_changes=False,
        require_parent_newer_than_child=False,
        novelty_mode="abm",
        validate_cycles=True,
    ):
        pipeline = self._clean(pipeline_name)
        dataset_clean = self._clean(dataset)
        blocking_reasons = []
        warnings = []

        if validate_cycles:
            cycles = self.detect_cycles()
            if cycles:
                sample_cycle = " -> ".join(cycles[0])
                blocking_reasons.append({
                    "code": "dependency_cycle",
                    "severity": "hard",
                    "message": f"Dependency graph has cycles. Example: {sample_cycle}",
                })
                return {
                    "can_execute": False,
                    "blocking_reasons": blocking_reasons,
                    "warnings": warnings,
                }

        deps = self._fetch_dependencies(pipeline, child_dataset=dataset_clean)
        if not deps:
            return {
                "can_execute": True,
                "blocking_reasons": [],
                "warnings": [],
            }

        child_last_success = None
        if require_parent_newer_than_child:
            child_last_success = self._get_last_run(
                pipeline_name=pipeline,
                dataset=dataset_clean,
                success_only=True,
            )

        now = datetime.utcnow()

        for dep in deps:
            severity = self._normalize_dependency_mode(dep.get("dependency_mode"))
            collector = warnings if severity == "soft" else blocking_reasons

            parent = dep["parent_pipeline"]
            parent_dataset = dep.get("parent_dataset")

            parent_last = self._get_last_run(
                pipeline_name=parent,
                dataset=parent_dataset,
                success_only=False,
            )
            parent_success = self._get_last_run(
                pipeline_name=parent,
                dataset=parent_dataset,
                success_only=True,
            )

            if parent_last is None:
                collector.append({
                    "code": "parent_never_ran",
                    "severity": severity,
                    "parent_pipeline": parent,
                    "parent_dataset": parent_dataset,
                    "message": (
                        f"Parent '{parent}'"
                        f"{' dataset=' + parent_dataset if parent_dataset else ''} has no runs."
                    ),
                })
                continue

            if require_parent_latest_success and parent_last["status"] != "SUCCESS":
                collector.append({
                    "code": "parent_latest_not_success",
                    "severity": severity,
                    "parent_pipeline": parent,
                    "parent_dataset": parent_dataset,
                    "run_id": parent_last["run_id"],
                    "status": parent_last["status"],
                    "message": (
                        f"Latest run of parent '{parent}'"
                        f"{' dataset=' + parent_dataset if parent_dataset else ''} "
                        f"is '{parent_last['status']}', expected SUCCESS."
                    ),
                })
                continue

            if parent_success is None:
                collector.append({
                    "code": "parent_without_success",
                    "severity": severity,
                    "parent_pipeline": parent,
                    "parent_dataset": parent_dataset,
                    "message": (
                        f"Parent '{parent}'"
                        f"{' dataset=' + parent_dataset if parent_dataset else ''} has no SUCCESS run."
                    ),
                })
                continue

            if require_parent_newer_than_child and child_last_success is not None:
                if parent_success["start_ts"] <= child_last_success["start_ts"]:
                    collector.append({
                        "code": "parent_not_newer_than_child",
                        "severity": severity,
                        "parent_pipeline": parent,
                        "parent_dataset": parent_dataset,
                        "parent_run_id": parent_success["run_id"],
                        "child_run_id": child_last_success["run_id"],
                        "message": (
                            f"Parent '{parent}'"
                            f"{' dataset=' + parent_dataset if parent_dataset else ''} "
                            f"has no newer SUCCESS run than child '{pipeline}'"
                            f"{' dataset=' + dataset_clean if dataset_clean else ''}."
                        ),
                    })
                    continue

            freshness_hours = dep.get("freshness_hours")
            if freshness_hours is not None:
                max_age = timedelta(hours=int(freshness_hours))
                age = now - parent_success["start_ts"].replace(tzinfo=None)
                if age > max_age:
                    collector.append({
                        "code": "parent_freshness_expired",
                        "severity": severity,
                        "parent_pipeline": parent,
                        "parent_dataset": parent_dataset,
                        "run_id": parent_success["run_id"],
                        "freshness_hours": freshness_hours,
                        "parent_start_ts": parent_success["start_ts"],
                        "message": (
                            f"Parent '{parent}'"
                            f"{' dataset=' + parent_dataset if parent_dataset else ''} "
                            f"exceeded freshness window ({freshness_hours}h)."
                        ),
                    })
                    continue

            if require_parent_changes:
                stats = self._get_run_change_stats(
                    run_id=parent_success["run_id"],
                    pipeline_name=parent,
                    dataset=parent_dataset,
                )
                mode = str(novelty_mode).lower().strip()
                if mode == "rows_out":
                    changed = stats["rows_out"] > 0
                else:
                    changed = (
                        stats["rows_inserted"] > 0
                        or stats["rows_updated"] > 0
                        or stats["rows_deleted"] > 0
                    )
                if not changed:
                    collector.append({
                        "code": "parent_without_changes",
                        "severity": severity,
                        "parent_pipeline": parent,
                        "parent_dataset": parent_dataset,
                        "run_id": parent_success["run_id"],
                        "rows_inserted": stats["rows_inserted"],
                        "rows_updated": stats["rows_updated"],
                        "rows_deleted": stats["rows_deleted"],
                        "rows_out": stats["rows_out"],
                        "message": (
                            f"Parent '{parent}'"
                            f"{' dataset=' + parent_dataset if parent_dataset else ''} "
                            f"last SUCCESS run has no changes (mode={novelty_mode})."
                        ),
                    })

        return {
            "can_execute": len(blocking_reasons) == 0,
            "blocking_reasons": blocking_reasons,
            "warnings": warnings,
        }

    def get_blocking_reasons(
        self,
        pipeline_name,
        dataset=None,
        require_parent_latest_success=True,
        require_parent_changes=False,
        require_parent_newer_than_child=False,
        novelty_mode="abm",
        validate_cycles=True,
    ):
        diagnostics = self.get_dependency_diagnostics(
            pipeline_name=pipeline_name,
            dataset=dataset,
            require_parent_latest_success=require_parent_latest_success,
            require_parent_changes=require_parent_changes,
            require_parent_newer_than_child=require_parent_newer_than_child,
            novelty_mode=novelty_mode,
            validate_cycles=validate_cycles,
        )
        return diagnostics["blocking_reasons"]

    def can_execute(
        self,
        pipeline_name,
        dataset=None,
        require_parent_latest_success=True,
        require_parent_changes=False,
        require_parent_newer_than_child=False,
        novelty_mode="abm",
        validate_cycles=True,
    ):
        diagnostics = self.get_dependency_diagnostics(
            pipeline_name=pipeline_name,
            dataset=dataset,
            require_parent_latest_success=require_parent_latest_success,
            require_parent_changes=require_parent_changes,
            require_parent_newer_than_child=require_parent_newer_than_child,
            novelty_mode=novelty_mode,
            validate_cycles=validate_cycles,
        )
        return diagnostics["can_execute"]

    def assert_can_execute(
        self,
        pipeline_name,
        dataset=None,
        require_parent_latest_success=True,
        require_parent_changes=False,
        require_parent_newer_than_child=False,
        novelty_mode="abm",
        validate_cycles=True,
    ):
        diagnostics = self.get_dependency_diagnostics(
            pipeline_name=pipeline_name,
            dataset=dataset,
            require_parent_latest_success=require_parent_latest_success,
            require_parent_changes=require_parent_changes,
            require_parent_newer_than_child=require_parent_newer_than_child,
            novelty_mode=novelty_mode,
            validate_cycles=validate_cycles,
        )
        if diagnostics["blocking_reasons"]:
            formatted = "; ".join(
                [r.get("message", r.get("code", "blocked")) for r in diagnostics["blocking_reasons"]]
            )
            raise RuntimeError(f"Pipeline '{pipeline_name}' blocked: {formatted}")
        return True
