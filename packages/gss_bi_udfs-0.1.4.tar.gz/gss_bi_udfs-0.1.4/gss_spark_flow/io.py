import uuid
import warnings


def _q(identifier):
    return f"`{str(identifier).replace('`', '')}`"


def _table_exists(spark, table_name):
    try:
        spark.table(table_name).limit(1).collect()
        return True
    except Exception:
        return False


def _ensure_target_table_for_merge(spark, df, target_table):
    if _table_exists(spark, target_table):
        return
    # Bootstrap empty Delta table from source schema so first MERGE can run.
    df.limit(0).write.format("delta").mode("overwrite").saveAsTable(target_table)

def _to_int(value, default=0):
    try:
        if value is None:
            return default
        return int(value)
    except Exception:
        return default


def _normalize_type_name(type_name):
    value = str(type_name).lower().strip()
    aliases = {
        "byte": "tinyint",
        "short": "smallint",
        "int": "int",
        "integer": "int",
        "long": "bigint",
        "float": "float",
        "double": "double",
        "bool": "boolean",
        "str": "string",
    }
    if value.startswith("decimal"):
        return "decimal"
    return aliases.get(value, value)


def _validate_merge_key_types(spark, df, target_table, merge_keys, mismatch_action="error"):
    action = str(mismatch_action or "error").lower().strip()
    if action not in {"error", "warn", "ignore"}:
        raise ValueError("mismatch_action must be one of: error, warn, ignore")
    if action == "ignore":
        return

    source_types = {field.name: field.dataType.simpleString() for field in df.schema.fields}
    target_types = {field.name: field.dataType.simpleString() for field in spark.table(target_table).schema.fields}

    missing_in_source = [key for key in merge_keys if key not in source_types]
    missing_in_target = [key for key in merge_keys if key not in target_types]
    if missing_in_source or missing_in_target:
        details = []
        if missing_in_source:
            details.append(f"missing in source: {missing_in_source}")
        if missing_in_target:
            details.append(f"missing in target: {missing_in_target}")
        message = "Invalid merge_keys; " + ", ".join(details)
        if action == "warn":
            warnings.warn(message)
            return
        raise ValueError(message)

    mismatches = []
    for key in merge_keys:
        source_type = _normalize_type_name(source_types[key])
        target_type = _normalize_type_name(target_types[key])
        if source_type != target_type:
            mismatches.append(
                f"{key}: source={source_types[key]} target={target_types[key]}"
            )

    if mismatches:
        message = (
            "Merge key type mismatch detected. "
            "This can cause INSERT instead of UPDATE. "
            + "; ".join(mismatches)
        )
        if action == "warn":
            warnings.warn(message)
            return
        raise ValueError(message)


def write_append(df, target_table):
    rows_out = df.count()
    df.write.mode("append").option("mergeSchema", "true").saveAsTable(target_table)
    return {
        "rows_in": rows_out,
        "rows_out": rows_out,
        "rows_inserted": rows_out,
        "rows_updated": 0,
        "rows_deleted": 0,
    }


def write_overwrite(df, target_table):
    rows_out = df.count()
    df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(target_table)
    return {
        "rows_in": rows_out,
        "rows_out": rows_out,
        "rows_inserted": rows_out,
        "rows_updated": 0,
        "rows_deleted": 0,
    }


def write_merge(
    spark,
    df,
    target_table,
    merge_keys,
    update_columns=None,
    insert_only=False,
    mismatch_action="error",
    create_target_if_missing=True,
):
    if isinstance(merge_keys, str):
        merge_keys = [merge_keys]

    if not merge_keys:
        raise ValueError("merge_keys is required")

    if create_target_if_missing:
        _ensure_target_table_for_merge(
            spark=spark,
            df=df,
            target_table=target_table,
        )

    _validate_merge_key_types(
        spark=spark,
        df=df,
        target_table=target_table,
        merge_keys=merge_keys,
        mismatch_action=mismatch_action,
    )

    source_view = f"tmp_merge_{uuid.uuid4().hex}"
    df.createOrReplaceTempView(source_view)

    target_alias = "t"
    source_alias = "s"
    all_columns = df.columns
    quoted_columns = [_q(col) for col in all_columns]
    merge_condition = " AND ".join(
        [f"{target_alias}.{_q(key)} = {source_alias}.{_q(key)}" for key in merge_keys]
    )

    if update_columns is None:
        update_columns = [col for col in all_columns if col not in set(merge_keys)]

    update_set_sql = ", ".join(
        [f"{target_alias}.{_q(col)} = {source_alias}.{_q(col)}" for col in update_columns]
    )
    insert_cols_sql = ", ".join(quoted_columns)
    insert_vals_sql = ", ".join([f"{source_alias}.{col}" for col in quoted_columns])

    merge_sql = f"""
    MERGE INTO {target_table} {target_alias}
    USING {source_view} {source_alias}
    ON {merge_condition}
    """
    if not insert_only and update_columns:
        merge_sql += f"\nWHEN MATCHED THEN UPDATE SET {update_set_sql}"
    merge_sql += (
        f"\nWHEN NOT MATCHED THEN INSERT ({insert_cols_sql}) "
        f"VALUES ({insert_vals_sql})"
    )

    rows_out = df.count()
    previous_auto_merge = spark.conf.get("spark.databricks.delta.schema.autoMerge.enabled", None)
    previous_user_metadata = spark.conf.get("spark.databricks.delta.commitInfo.userMetadata", None)
    commit_tag = f"gss-task-{uuid.uuid4().hex}"
    spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
    spark.conf.set("spark.databricks.delta.commitInfo.userMetadata", commit_tag)
    operation_metrics = {}
    try:
        spark.sql(merge_sql)
        history_rows = spark.sql(f"DESCRIBE HISTORY {target_table}").limit(20).collect()
        for row in history_rows:
            if getattr(row, "userMetadata", None) == commit_tag and getattr(row, "operation", None) == "MERGE":
                metrics = getattr(row, "operationMetrics", None)
                if isinstance(metrics, dict):
                    operation_metrics = metrics
                break
    finally:
        if previous_auto_merge is None:
            spark.conf.unset("spark.databricks.delta.schema.autoMerge.enabled")
        else:
            spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", previous_auto_merge)
        if previous_user_metadata is None:
            spark.conf.unset("spark.databricks.delta.commitInfo.userMetadata")
        else:
            spark.conf.set("spark.databricks.delta.commitInfo.userMetadata", previous_user_metadata)
        spark.catalog.dropTempView(source_view)

    rows_inserted = _to_int(operation_metrics.get("numTargetRowsInserted"))
    rows_updated = _to_int(operation_metrics.get("numTargetRowsUpdated"))
    rows_deleted = _to_int(operation_metrics.get("numTargetRowsDeleted"))
    affected_rows = rows_inserted + rows_updated + rows_deleted
    rows_output = affected_rows if affected_rows > 0 else rows_out

    return {
        "rows_in": rows_out,
        "rows_out": rows_output,
        "rows_inserted": rows_inserted,
        "rows_updated": rows_updated,
        "rows_deleted": rows_deleted,
    }
