import os

os.environ.setdefault("AZURE_OPENAI_API_DEPLOYMENT", "")
os.environ.setdefault("AZURE_OPENAI_API_KEY", "")
os.environ.setdefault("AZURE_OPENAI_API_VERSION", "")
os.environ.setdefault("AZURE_OPENAI_ENDPOINT", "")
os.environ.setdefault("OPENAI_API_KEY", "")
os.environ.setdefault("HAYSTACK_AUTO_TRACE_ENABLED", "False")
os.environ.setdefault("GEMINI_API_KEY", "")
os.environ.setdefault("GOOGLE_API_KEY", "")
