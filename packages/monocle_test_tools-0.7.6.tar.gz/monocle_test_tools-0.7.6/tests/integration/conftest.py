# load the plugin for local test runs without installing the package
pytest_plugins = ["monocle_test_tools.pytest_plugin"] 