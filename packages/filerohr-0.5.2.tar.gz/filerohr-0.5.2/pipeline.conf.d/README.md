Place your pipeline configurations here and they will be loaded automatically.
