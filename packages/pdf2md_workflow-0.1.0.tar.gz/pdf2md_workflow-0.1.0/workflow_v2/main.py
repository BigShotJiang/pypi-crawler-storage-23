
#!/usr/bin/env python3

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import Config
from processor import PDFProcessor


def main():
    print("=" * 60)
    print("PDF 转 Markdown 工作流 v2.0")
    print("=" * 60)
    
    workflow_dir = Path(__file__).parent
    config_path = workflow_dir / "config.yaml"
    
    if not config_path.exists():
        print("配置文件不存在: %s" % config_path)
        print("使用默认配置...")
    
    config = Config.from_yaml(str(config_path))
    
    processor = PDFProcessor(config)
    success, fail, results = processor.run()
    
    if fail &gt; 0:
        print("\n警告: 有 %d 个文件处理失败" % fail)
        return 1
    
    print("\n所有文件处理成功!")
    return 0


if __name__ == "__main__":
    sys.exit(main())

