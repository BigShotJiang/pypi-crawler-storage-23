
import re


class TextCleaner:
    @staticmethod
    def clean_text(text):
        text = text.replace('\r', '\n')
        text = re.sub(r'[ \t]+', ' ', text)
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
        text = re.sub(r'[^\S\n]+', ' ', text)
        return text
    
    @staticmethod
    def remove_headers_footers(text):
        lines = text.split('\n')
        cleaned = []
        
        for line in lines:
            line = line.strip()
            
            if not line:
                cleaned.append('')
                continue
            
            if re.match(r'^—\s*\d+\s*—$', line):
                continue
            
            if re.match(r'^.*第\s*\d+\s*卷.*$', line) or re.match(r'^.*Vol\.\s*\d+.*$', line, re.I):
                continue
            
            if re.match(r'^.*收稿日期.*$', line) or re.match(r'^.*基金项目.*$', line) or re.match(r'^.*作者简介.*$', line):
                continue
            
            if re.match(r'^.*南京师大学报.*$', line, re.I):
                continue
            
            if re.match(r'^.*责任编辑.*$', line):
                continue
            
            cleaned.append(line)
        
        return '\n'.join(cleaned)


class ParagraphFormatter:
    @staticmethod
    def format_paragraphs(text):
        lines = text.split('\n')
        result = []
        current_paragraph = []
        
        for line in lines:
            line = line.strip()
            
            if not line:
                if current_paragraph:
                    result.append(' '.join(current_paragraph))
                    current_paragraph = []
                result.append('')
                continue
            
            if re.match(r'^\d+[．.∙]\s*[\u4e00-\u9fa5]', line) or re.match(r'^[一二三四五六七八九十]+[、．.∙]\s*', line):
                if current_paragraph:
                    result.append(' '.join(current_paragraph))
                    current_paragraph = []
                result.append('## %s' % line)
                continue
            
            if re.match(r'^表\s*\d+', line) or re.match(r'^图\s*\d+', line):
                if current_paragraph:
                    result.append(' '.join(current_paragraph))
                    current_paragraph = []
                result.append('\n**%s**\n' % line)
                continue
            
            if len(line) &lt; 80 or line.endswith(('。', '！', '？', '；', '：', '.', '!', '?', ';', ':')):
                current_paragraph.append(line)
                if len(current_paragraph) &gt; 3:
                    result.append(' '.join(current_paragraph))
                    current_paragraph = []
            else:
                current_paragraph.append(line)
        
        if current_paragraph:
            result.append(' '.join(current_paragraph))
        
        text = '\n\n'.join(result)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()


class TableFormatter:
    @staticmethod
    def to_markdown(table_data):
        if not table_data or len(table_data) == 0:
            return ""
        
        md = []
        for i, row in enumerate(table_data):
            if i == 0:
                md.append('| ' + ' | '.join([str(cell) if cell else '' for cell in row]) + ' |')
                md.append('| ' + ' | '.join(['---'] * len(row)) + ' |')
            else:
                md.append('| ' + ' | '.join([str(cell) if cell else '' for cell in row]) + ' |')
        
        return '\n'.join(md)


class MarkdownFormatter:
    def __init__(self, config):
        self.config = config
        self.cleaner = TextCleaner()
        self.paragraph_formatter = ParagraphFormatter()
        self.table_formatter = TableFormatter()
    
    def format(self, text, metadata, tables):
        md_content = []
        
        if self.config.format_include_basic_info:
            md_content.append("# %s\n" % metadata.get('stem', 'Untitled'))
            md_content.append("**页数**: %d\n\n" % metadata.get('total_pages', 0))
        
        formatted_text = self.cleaner.clean_text(text)
        
        if self.config.format_clean_headers or self.config.format_clean_footers:
            formatted_text = self.cleaner.remove_headers_footers(formatted_text)
        
        formatted_text = self.paragraph_formatter.format_paragraphs(formatted_text)
        
        md_content.append(formatted_text)
        
        if tables and len(tables) &gt; 0:
            md_content.append("\n\n---\n\n")
            md_content.append("## 提取的表格\n\n")
            
            for i, table in enumerate(tables, 1):
                md_content.append("### 表格 %d (第 %d 页)\n\n" % (i, table['page_num']))
                md_content.append(self.table_formatter.to_markdown(table['data']))
                md_content.append("\n\n")
        
        return '\n'.join(md_content)

