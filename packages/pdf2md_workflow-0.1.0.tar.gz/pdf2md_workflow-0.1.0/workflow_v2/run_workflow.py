
#!/usr/bin/env python3

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import Config
from processor import PDFProcessor


def main():
    print("=" * 60)
    print("PDF 转 Markdown 工作流 v2.0")
    print("=" * 60)
    
    workflow_dir = Path(__file__).parent
    config_path = workflow_dir / "config.yaml"
    
    config = Config.from_yaml(str(config_path))
    
    processor = PDFProcessor(config)
    success, fail, results = processor.run()
    
    print("\n" + "=" * 60)
    print("完成!")
    print("成功:", success)
    print("失败:", fail)
    print("=" * 60)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

