
from pathlib import Path
import logging
from datetime import datetime

from config import Config
from extractors import create_extractor
from formatter import MarkdownFormatter


class PDFProcessor:
    def __init__(self, config):
        self.config = config
        self.formatter = MarkdownFormatter(config)
        self._setup_logging()
    
    def _setup_logging(self):
        log_level = getattr(logging, self.config.logging_level.upper(), logging.INFO)
        logging.basicConfig(
            level=log_level,
            format=self.config.logging_format
        )
        
        if self.config.logging_save_to_file:
            log_file = self.config.get_logs_dir() / ("workflow_%s.log" % datetime.now().strftime('%Y%m%d_%H%M%S'))
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setFormatter(logging.Formatter(self.config.logging_format))
            logging.getLogger().addHandler(file_handler)
    
    def process_single_pdf(self, pdf_path, output_dir):
        try:
            logging.info("处理: %s" % pdf_path.name)
            
            output_file = output_dir / (pdf_path.stem + ".md")
            
            if self.config.process_skip_existing and output_file.exists():
                logging.info("  跳过已存在: %s" % output_file.name)
                return True, "已跳过"
            
            extractor = create_extractor(self.config.process_extractor, pdf_path)
            
            text, page_count = extractor.extract_text()
            metadata = extractor.get_metadata()
            
            tables = []
            if self.config.process_extract_tables:
                tables = extractor.extract_tables()
                logging.info("  提取到 %d 个表格" % len(tables))
            
            markdown = self.formatter.format(text, metadata, tables)
            
            output_dir.mkdir(parents=True, exist_ok=True)
            
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(markdown)
            
            logging.info("  保存到: %s" % output_file)
            return True, "成功 (%d 页)" % page_count
            
        except Exception as e:
            logging.error("处理失败 %s: %s" % (pdf_path.name, e))
            return False, str(e)
    
    def process_directory(self, input_dir, output_dir):
        logging.info("\n=== 处理目录: %s ===" % input_dir.name)
        
        pdf_files = list(input_dir.glob(self.config.input_file_pattern))
        if not self.config.input_recursive:
            pdf_files = [f for f in pdf_files if f.parent == input_dir]
        
        logging.info("找到 %d 个 PDF 文件" % len(pdf_files))
        
        success_count = 0
        fail_count = 0
        results = []
        
        for pdf_path in pdf_files:
            category_output_dir = output_dir / input_dir.name
            success, message = self.process_single_pdf(pdf_path, category_output_dir)
            
            if success:
                success_count += 1
            else:
                fail_count += 1
            
            results.append("%s: %s" % (pdf_path.name, message))
        
        return success_count, fail_count, results
    
    def run(self):
        logging.info("=" * 60)
        logging.info("PDF 转 Markdown 工作流")
        logging.info("提取器: %s" % self.config.process_extractor)
        logging.info("=" * 60)
        
        self.config.init_dirs()
        
        total_success = 0
        total_fail = 0
        all_results = []
        
        output_dir = self.config.get_output_dir()
        
        for input_dir in self.config.get_input_dirs():
            if not input_dir.exists():
                logging.warning("目录不存在: %s" % input_dir)
                continue
            
            success, fail, results = self.process_directory(input_dir, output_dir)
            total_success += success
            total_fail += fail
            all_results.extend(results)
        
        logging.info("\n" + "=" * 60)
        logging.info("处理完成!")
        logging.info("成功: %d" % total_success)
        logging.info("失败: %d" % total_fail)
        logging.info("输出目录: %s" % output_dir)
        logging.info("=" * 60)
        
        return total_success, total_fail, all_results

