
"""
PDF 转 Markdown 工作流 v2.0

组件化架构：
- config.py: 配置管理
- extractors.py: 提取器 (PyMuPDF, pdfplumber)
- formatter.py: 格式化器
- processor.py: 批处理器
- main.py: 主入口
"""

__version__ = "2.0.0"

