# pdf2md-workflow

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

一个组件化的 PDF 转 Markdown 工作流工具，支持批量处理和 AI 智能格式化。

## ✨ 特性

- 📄 **PDF 文本提取** - 基于 PyMuPDF 的高效文本提取
- 📊 **表格提取** - 使用 pdfplumber 提取 PDF 表格
- 🔄 **批量处理** - 支持批量转换多个 PDF 文件
- 🤖 **AI 格式化** - 配合 markdown-formatter skill 智能格式化
- 📦 **Python 包** - 可通过 pip 安装使用
- 🛠️ **CLI 工具** - 提供命令行接口

## 📦 安装

```bash
pip install pdf2md-workflow
```

或从源码安装：

```bash
git clone https://github.com/Drehabwen/Openrehab-vibepaper-read.git
cd Openrehab-vibepaper-read
pip install -e .
```

## 🚀 快速开始

### 命令行使用

```bash
# 转换单个 PDF
pdf2md convert paper.pdf

# 批量转换
pdf2md batch ./pdfs -o ./output

# 使用配置文件
pdf2md batch ./pdfs -c config.yaml
```

### Python API 使用

```python
from pdf2md_workflow import convert_pdf, Config

# 简单转换
convert_pdf("paper.pdf", "output.md")

# 使用配置
config = Config.from_yaml("config.yaml")
convert_pdf("paper.pdf", "output.md", config=config)
```

## 📁 项目结构

```
pdf2md_workflow/
├── __init__.py      # 包入口
├── cli.py           # 命令行接口
├── config.py        # 配置管理
├── extractors.py    # PDF 提取器
├── formatter.py     # Markdown 格式化
└── processor.py     # 批量处理器
```

## ⚙️ 配置

创建 `config.yaml` 文件：

```yaml
input_directories:
  - "./pdfs"
output_directory: "./output"
extractor: "pymupdf"  # pymupdf 或 pdfplumber
preserve_images: true
```

## 🔧 依赖

- Python >= 3.8
- PyMuPDF >= 1.23.0
- pdfplumber >= 0.10.0
- PyYAML >= 6.0

## 📝 使用示例

### 转换学术论文

```python
from pdf2md_workflow import convert_pdf

# 转换 PDF 论文
convert_pdf(
    "research_paper.pdf",
    "research_paper.md",
    extractor="pymupdf"
)
```

### 批量处理

```python
from pdf2md_workflow import PDFProcessor, Config

config = Config(
    input_directories=["./papers"],
    output_directory="./markdown"
)

processor = PDFProcessor(config)
processor.process_all()
```

## 🤝 配合 AI 格式化

本项目提供 `markdown-formatter` skill，可以配合 AI 工具进行智能格式化：

```
用户: 整理这个 Markdown 文件
AI: [调用 markdown-formatter skill 进行格式化]
```

## 📄 License

MIT License - 详见 [LICENSE](LICENSE) 文件

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📮 联系方式

- GitHub: https://github.com/Drehabwen/Openrehab-vibepaper-read

---

**Made with ❤️ by Drehabwen**
