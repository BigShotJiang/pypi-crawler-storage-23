
from pathlib import Path
import logging
from datetime import datetime

from pdf2md_workflow.config import Config
from pdf2md_workflow.extractors import create_extractor
from pdf2md_workflow.formatter import MarkdownFormatter


class PDFProcessor:
    def __init__(self, config=None):
        if config is None:
            config = Config()
        self.config = config
        self.formatter = MarkdownFormatter(config)
        self._setup_logging()
    
    def _setup_logging(self):
        log_level = getattr(logging, self.config.logging_level.upper(), logging.INFO)
        logging.basicConfig(
            level=log_level,
            format=self.config.logging_format
        )
        
        if self.config.logging_save_to_file:
            logs_dir = Path(self.config.output_logs_dir)
            logs_dir.mkdir(parents=True, exist_ok=True)
            log_file = logs_dir / ("workflow_%s.log" % datetime.now().strftime('%Y%m%d_%H%M%S'))
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setFormatter(logging.Formatter(self.config.logging_format))
            logging.getLogger().addHandler(file_handler)
    
    def process_single_pdf(self, pdf_path, output_dir):
        try:
            pdf_path = Path(pdf_path)
            output_dir = Path(output_dir)
            
            logging.info("Processing: %s" % pdf_path.name)
            
            output_file = output_dir / (pdf_path.stem + ".md")
            
            if self.config.process_skip_existing and output_file.exists():
                logging.info("  Skipped existing: %s" % output_file.name)
                return True, "Skipped"
            
            extractor = create_extractor(self.config.process_extractor, pdf_path)
            
            text, page_count = extractor.extract_text()
            metadata = extractor.get_metadata()
            
            tables = []
            if self.config.process_extract_tables:
                tables = extractor.extract_tables()
                logging.info("  Extracted %d tables" % len(tables))
            
            markdown = self.formatter.format(text, metadata, tables)
            
            output_dir.mkdir(parents=True, exist_ok=True)
            
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(markdown)
            
            logging.info("  Saved to: %s" % output_file)
            return True, "Success (%d pages)" % page_count
            
        except Exception as e:
            logging.error("Failed to process %s: %s" % (pdf_path.name, e))
            return False, str(e)
    
    def process_directory(self, input_dir, output_dir):
        input_dir = Path(input_dir)
        output_dir = Path(output_dir)
        
        logging.info("\n=== Processing directory: %s ===" % input_dir.name)
        
        pdf_files = list(input_dir.glob(self.config.input_file_pattern))
        if not self.config.input_recursive:
            pdf_files = [f for f in pdf_files if f.parent == input_dir]
        
        logging.info("Found %d PDF files" % len(pdf_files))
        
        success_count = 0
        fail_count = 0
        results = []
        
        for pdf_path in pdf_files:
            category_output_dir = output_dir / input_dir.name
            success, message = self.process_single_pdf(pdf_path, category_output_dir)
            
            if success:
                success_count += 1
            else:
                fail_count += 1
            
            results.append("%s: %s" % (pdf_path.name, message))
        
        return success_count, fail_count, results

