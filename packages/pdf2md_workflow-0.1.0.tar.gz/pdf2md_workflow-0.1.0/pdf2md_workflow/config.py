
from pathlib import Path
import yaml


class Config:
    def __init__(self):
        self.input_directories = []
        self.input_recursive = False
        self.input_file_pattern = "*.pdf"
        
        self.output_base_dir = "./output"
        self.output_preserve_structure = True
        self.output_images_dir = "./output/images"
        self.output_logs_dir = "./logs"
        
        self.process_extract_text = True
        self.process_extract_tables = True
        self.process_extract_images = False
        self.process_skip_existing = True
        self.process_max_file_size_mb = 50
        self.process_extractor = "pymupdf"
        
        self.format_include_basic_info = True
        self.format_table_format = "markdown"
        self.format_image_path_format = "relative"
        self.format_clean_headers = True
        self.format_clean_footers = True
        
        self.logging_level = "INFO"
        self.logging_format = "%(asctime)s - %(levelname)s - %(message)s"
        self.logging_save_to_file = False
    
    @classmethod
    def from_yaml(cls, yaml_path):
        config = cls()
        yaml_file = Path(yaml_path)
        
        if not yaml_file.exists():
            return config
        
        with open(yaml_file, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        if data and 'input' in data:
            inp = data['input']
            if 'directories' in inp:
                config.input_directories = inp['directories']
            if 'recursive' in inp:
                config.input_recursive = inp['recursive']
            if 'file_pattern' in inp:
                config.input_file_pattern = inp['file_pattern']
        
        if data and 'output' in data:
            out = data['output']
            if 'base_dir' in out:
                config.output_base_dir = out['base_dir']
            if 'preserve_structure' in out:
                config.output_preserve_structure = out['preserve_structure']
            if 'images_dir' in out:
                config.output_images_dir = out['images_dir']
            if 'logs_dir' in out:
                config.output_logs_dir = out['logs_dir']
        
        if data and 'processing' in data:
            proc = data['processing']
            if 'extract_text' in proc:
                config.process_extract_text = proc['extract_text']
            if 'extract_tables' in proc:
                config.process_extract_tables = proc['extract_tables']
            if 'extract_images' in proc:
                config.process_extract_images = proc['extract_images']
            if 'skip_existing' in proc:
                config.process_skip_existing = proc['skip_existing']
            if 'max_file_size_mb' in proc:
                config.process_max_file_size_mb = proc['max_file_size_mb']
            if 'extractor' in proc:
                config.process_extractor = proc['extractor']
        
        return config

