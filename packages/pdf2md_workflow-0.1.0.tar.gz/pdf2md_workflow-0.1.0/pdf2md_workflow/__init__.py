
"""
PDF to Markdown Workflow
=======================

A componentized PDF to Markdown conversion toolkit.

Features:
- Multiple extractor support (PyMuPDF, pdfplumber)
- Configurable via YAML or code
- Plugin architecture for custom extractors and formatters
- Command-line interface
- Python API for integration

Example:
    &gt;&gt;&gt; from pdf2md_workflow import convert_pdf
    &gt;&gt;&gt; convert_pdf("paper.pdf", "output.md")
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__license__ = "MIT"

from pathlib import Path
from pdf2md_workflow.config import Config
from pdf2md_workflow.extractors import create_extractor, PyMuPDFExtractor, PDFPlumberExtractor
from pdf2md_workflow.formatter import MarkdownFormatter
from pdf2md_workflow.processor import PDFProcessor

__all__ = [
    "Config",
    "create_extractor",
    "PyMuPDFExtractor",
    "PDFPlumberExtractor",
    "MarkdownFormatter",
    "PDFProcessor",
    "convert_pdf",
]


def convert_pdf(pdf_path, output_path, config=None):
    """
    Convert a single PDF file to Markdown.

    Args:
        pdf_path: Path to the PDF file
        output_path: Path to save the Markdown file
        config: Optional Config object

    Returns:
        bool: Success status
    """
    if config is None:
        config = Config()
    
    processor = PDFProcessor(config)
    success, _ = processor.process_single_pdf(
        pdf_path, 
        Path(output_path).parent
    )
    return success

