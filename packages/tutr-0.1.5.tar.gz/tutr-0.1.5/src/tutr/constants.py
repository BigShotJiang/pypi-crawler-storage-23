"""Shared constants used across tutr modules."""

BOLD = "\033[1m"
CYAN = "\033[36m"
RED = "\033[31m"
RESET = "\033[0m"
