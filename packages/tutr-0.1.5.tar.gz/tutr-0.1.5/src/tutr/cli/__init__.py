"""tutr one-shot CLI package."""

from tutr.cli.app import entrypoint, main

__all__ = ["entrypoint", "main"]
