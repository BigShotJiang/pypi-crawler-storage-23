"""Allow running as `python -m tutr`."""

from tutr.cli import main

raise SystemExit(main())
