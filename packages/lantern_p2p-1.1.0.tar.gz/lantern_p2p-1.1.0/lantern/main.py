"""
Lantern - P2P File Sharing System
Main entry point for pip-installed package.
"""

from .peer import main

if __name__ == "__main__":
    main()
