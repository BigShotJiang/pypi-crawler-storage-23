"""
RequestInput is the base class for all request input types.
"""

from __future__ import annotations

from abc import abstractmethod
from datetime import datetime
from functools import cached_property
from typing import Any, Dict, List, Literal, Optional, Tuple, Union, cast

from dateutil import tz
from pydantic import Field, StrictStr, field_validator, model_validator
from sqlglot import expressions
from sqlglot.expressions import Select
from typing_extensions import ClassVar

from featurebyte.common.doc_util import FBAutoDoc
from featurebyte.enum import DBVarType, InternalName, SpecialColumnName, StrEnum
from featurebyte.exception import ColumnNotFoundError
from featurebyte.models import FeatureStoreModel
from featurebyte.models.base import FeatureByteBaseModel, PydanticObjectId
from featurebyte.query_graph.model.column_info import ColumnInfo
from featurebyte.query_graph.model.common_table import TabularSource
from featurebyte.query_graph.model.graph import QueryGraphModel
from featurebyte.query_graph.node.schema import TableDetails
from featurebyte.query_graph.sql.adapter import BaseAdapter, get_sql_adapter
from featurebyte.query_graph.sql.ast.literal import make_literal_value
from featurebyte.query_graph.sql.common import (
    get_non_missing_and_missing_condition_pair,
    quoted_identifier,
)
from featurebyte.query_graph.sql.materialisation import (
    ExtendedSourceMetadata,
    get_row_count_sql,
    get_source_expr,
    get_view_expr,
    select_and_rename_columns,
)
from featurebyte.query_graph.transform.operation_structure import OperationStructureExtractor
from featurebyte.session.base import BaseSession


class RequestInputType(StrEnum):
    """
    Input type refers to how an ObservationTableModel is created
    """

    VIEW = "view"
    SOURCE_TABLE = "source_table"
    OBSERVATION_TABLE = "observation_table"
    DATAFRAME = "dataframe"
    UPLOADED_FILE = "uploaded_file"
    SOURCE_OBSERVATION_TABLE = "source_observation_table"
    MANAGED_VIEW = "managed_view"


class TargetValueSamplingRate(FeatureByteBaseModel):
    """Sampling rate for a specific target_value"""

    # class variables
    __fbautodoc__: ClassVar[FBAutoDoc] = FBAutoDoc(
        proxy_class="featurebyte.TargetValueSamplingRate"
    )

    target_value: Union[str, int, bool]
    rate: float = Field(gt=0, le=1)


class DownSamplingInfo(FeatureByteBaseModel):
    """Information on downsampling"""

    # class variables
    __fbautodoc__: ClassVar[FBAutoDoc] = FBAutoDoc(proxy_class="featurebyte.DownSamplingInfo")

    sampling_rate_per_target_value: List[TargetValueSamplingRate] = Field(min_length=1)
    default_sampling_rate: float = Field(gt=0, le=1, default=1)

    @field_validator("sampling_rate_per_target_value")
    @classmethod
    def _validate_sampling_rates(
        cls, values: Optional[List[TargetValueSamplingRate]]
    ) -> Optional[List[TargetValueSamplingRate]]:
        # ensure target values are unique
        target_values = set()
        if values is not None:
            for sampling in values:
                if sampling.target_value in target_values:
                    raise ValueError(f"Duplicate target value found: {sampling.target_value}")
                target_values.add(sampling.target_value)
        return values

    @model_validator(mode="after")
    def validate_parameters(self) -> "DownSamplingInfo":  # ensure target values are unique
        downsampling_needed = self.default_sampling_rate < 1.0
        for sampling_rate in self.sampling_rate_per_target_value:
            if sampling_rate.rate < 1.0:
                downsampling_needed = True

        if not downsampling_needed:
            raise ValueError(
                "At least one sampling rate must be less than 1.0 to enable downsampling"
            )
        return self


class DownSamplingInfoWithTargetColumn(DownSamplingInfo):
    """Information on downsampling with target column"""

    target_column: str


class SplitInfo(FeatureByteBaseModel):
    """
    Information for splitting a table into multiple parts based on percentages.

    This is used internally when creating split observation tables.
    """

    # class variables
    __fbautodoc__: ClassVar[FBAutoDoc] = FBAutoDoc(proxy_class="featurebyte.SplitInfo")

    split_index: int = Field(ge=0, description="The index of this split (0-based)")
    split_ratios: List[float] = Field(
        min_length=2,
        max_length=3,
        description="List of ratios for each split. Must sum to 1.0.",
    )
    seed: int = Field(default=1234, description="Random seed for reproducible splits")

    @field_validator("split_ratios")
    @classmethod
    def _validate_split_ratios(cls, values: List[float]) -> List[float]:
        # ensure ratios are valid (0 < ratio < 1)
        for ratio in values:
            if ratio <= 0 or ratio > 1:
                raise ValueError(
                    f"Each split ratio must be between 0 and 1 (exclusive), got {ratio}"
                )
        # ensure ratios sum to 1
        total = sum(values)
        if abs(total - 1.0) > 1e-9:
            raise ValueError(f"Split ratios must sum to 1.0, got {total}")
        return values

    @model_validator(mode="after")
    def validate_split_index(self) -> "SplitInfo":
        """
        Validate that split_index is within the valid range.

        Raises
        ------
        ValueError
            If split_index is greater than or equal to the number of split ratios.

        Returns
        -------
        SplitInfo
            The validated SplitInfo instance.
        """
        if self.split_index >= len(self.split_ratios):
            raise ValueError(
                f"split_index ({self.split_index}) must be less than number of splits ({len(self.split_ratios)})"
            )
        return self


class BaseRequestInput(FeatureByteBaseModel):
    """
    BaseRequestInput is the base class for all RequestInput types
    """

    columns: Optional[List[str]] = Field(default=None)
    columns_rename_mapping: Optional[Dict[str, str]] = Field(default=None)

    @abstractmethod
    async def get_query_expr(
        self, session: BaseSession, feature_store: FeatureStoreModel
    ) -> Select:
        """
        Get the SQL expression for the underlying data (can be either a table or a view)

        Parameters
        ----------
        session: BaseSession
            The session to use to get the query expression
        feature_store: FeatureStoreModel
            The feature store model

        Returns
        -------
        Select
        """

    @staticmethod
    async def get_row_count(session: BaseSession, query_expr: Select) -> int:
        """
        Get the number of rows in the observation table

        Parameters
        ----------
        session: BaseSession
            The session to use to get the row count
        query_expr: Select
            The query expression to get the row count for

        Returns
        -------
        int
        """
        query = get_row_count_sql(table_expr=query_expr, source_type=session.source_type)
        result = await session.execute_query_long_running(query)
        return int(result.iloc[0]["row_count"])  # type: ignore[union-attr]

    @abstractmethod
    async def get_column_names_and_dtypes(self, session: BaseSession) -> Dict[str, DBVarType]:
        """
        Get the column names and dtypes of the table query

        Parameters
        ----------
        session: BaseSession
            The session to use to get the column names

        Returns
        -------
        Dict[str, DBVarType]
        """

    @staticmethod
    def get_sample_percentage_from_row_count(total_row_count: int, desired_row_count: int) -> float:
        """
        Get the sample percentage required to get the desired number of rows

        Parameters
        ----------
        total_row_count: int
            The total number of rows
        desired_row_count: int
            The desired number of rows

        Returns
        -------
        float
        """
        # Sample a bit above the theoretical sample percentage since bernoulli sampling doesn't
        # guarantee an exact number of rows.
        return min(100.0, 100.0 * desired_row_count / total_row_count * 1.4)

    async def get_output_columns_and_dtypes(
        self, session: BaseSession, additional_columns: Optional[List[str]] = None
    ) -> Tuple[List[str], Dict[str, DBVarType]]:
        """
        Get the output columns and dtypes based on the input columns and rename mapping

        Parameters
        ----------
        session: BaseSession
            The session to use to get the column names
        additional_columns: Optional[List[str]]
            Additional columns to include in the output

        Returns
        -------
        Tuple[List[str], Dict[str, DBVarType]]
        """
        column_names_and_dtypes = await self.get_column_names_and_dtypes(session=session)
        available_columns = list(column_names_and_dtypes.keys())
        self._validate_columns_and_rename_mapping(available_columns)
        input_columns = self.columns or available_columns

        # If the input has a sampling column, ensure it is included
        if InternalName.TABLE_ROW_WEIGHT in available_columns:
            if InternalName.TABLE_ROW_WEIGHT not in input_columns:
                input_columns.append(InternalName.TABLE_ROW_WEIGHT)

        # Add any additional columns if provided
        if additional_columns:
            for col in additional_columns:
                if col not in input_columns:
                    input_columns.append(col)

        if self.columns_rename_mapping is not None:
            output_column_names_and_dtypes = {
                self.columns_rename_mapping.get(col, col): column_names_and_dtypes[col]
                for col in input_columns
            }
        else:
            output_column_names_and_dtypes = {
                col: column_names_and_dtypes[col] for col in input_columns
            }
        return input_columns, output_column_names_and_dtypes

    @staticmethod
    def get_downsample_sql(
        adapter: BaseAdapter,
        select_expr: Select,
        downsampling_info: DownSamplingInfoWithTargetColumn,
        seed: int,
    ) -> Select:
        """
        Construct query to downsample a table based on the downsampling information

        Parameters
        ----------
        adapter: BaseAdapter
            SQL adapter
        select_expr: Select
            Table to sample from
        downsampling_info: DownSamplingInfoWithTargetColumn
            Downsampling information
        seed: int
            Random seed

        Returns
        -------
        Select
        """

        original_cols = [
            quoted_identifier(col_expr.alias or col_expr.name)
            for col_expr in select_expr.expressions
        ]
        prob_expr = expressions.alias_(
            adapter.get_uniform_distribution_expr(seed),
            alias="prob",
            quoted=True,
        )
        sampled_expr_with_prob = expressions.select(prob_expr, *original_cols).from_(
            select_expr.subquery()
        )

        # column to indicate the sampling rate applied to each row
        sampling_column_exists = False
        for col_expr in select_expr.expressions:
            if col_expr.name == InternalName.TABLE_ROW_WEIGHT:
                sampling_column_exists = True

        sample_rate_expr = expressions.Case(
            ifs=[
                expressions.If(
                    this=expressions.EQ(
                        this=quoted_identifier(downsampling_info.target_column),
                        expression=make_literal_value(sampling.target_value),
                    ),
                    true=expressions.Cast(
                        this=(
                            expressions.Mul(
                                this=quoted_identifier(InternalName.TABLE_ROW_WEIGHT),
                                expression=make_literal_value(1 / sampling.rate),
                            )
                            if sampling_column_exists
                            else make_literal_value(1 / sampling.rate)
                        ),
                        to=expressions.DataType.build("FLOAT"),
                    ),
                )
                for sampling in downsampling_info.sampling_rate_per_target_value
            ],
            default=(
                quoted_identifier(InternalName.TABLE_ROW_WEIGHT)
                if sampling_column_exists
                else make_literal_value(1 / downsampling_info.default_sampling_rate)
            ),
        )

        if sampling_column_exists:
            final_output_cols = [
                col for col in original_cols if col.name != InternalName.TABLE_ROW_WEIGHT
            ]
        else:
            final_output_cols = original_cols
        output_col_expr = final_output_cols + [
            expressions.alias_(sample_rate_expr, alias=InternalName.TABLE_ROW_WEIGHT, quoted=True)
        ]

        output = (
            expressions.select(*output_col_expr)
            .from_(sampled_expr_with_prob.subquery())
            .where(
                expressions.or_(
                    *(
                        # conditions for specified target values and rates
                        [
                            expressions.and_(
                                expressions.EQ(
                                    this=quoted_identifier(downsampling_info.target_column),
                                    expression=make_literal_value(sampling.target_value),
                                ),
                                expressions.LTE(
                                    this=quoted_identifier("prob"),
                                    expression=make_literal_value(sampling.rate),
                                ),
                            )
                            for sampling in downsampling_info.sampling_rate_per_target_value
                        ]
                        +
                        # condition for unspecified target values (apply default sampling rate)
                        [
                            expressions.and_(
                                expressions.not_(
                                    expressions.In(
                                        this=quoted_identifier(downsampling_info.target_column),
                                        expressions=[
                                            make_literal_value(sampling.target_value)
                                            for sampling in downsampling_info.sampling_rate_per_target_value
                                        ],
                                    )
                                ),
                                expressions.LTE(
                                    this=quoted_identifier("prob"),
                                    expression=make_literal_value(
                                        downsampling_info.default_sampling_rate
                                    ),
                                ),
                            )
                        ]
                    )
                )
            )
        )
        return output

    async def materialize(
        self,
        session: BaseSession,
        destination: TableDetails,
        feature_store: FeatureStoreModel,
        sample_rows: Optional[int],
        sample_from_timestamp: Optional[datetime] = None,
        sample_to_timestamp: Optional[datetime] = None,
        downsampling_info: Optional[DownSamplingInfoWithTargetColumn] = None,
        columns_to_exclude_missing_values: Optional[List[str]] = None,
        missing_data_table_details: Optional[TableDetails] = None,
    ) -> None:
        """
        Materialize the request input table

        Parameters
        ----------
        session: BaseSession
            The session to use to materialize the table
        destination: TableDetails
            The destination table details
        feature_store: FeatureStoreModel
            The feature store model
        sample_rows: Optional[int]
            The number of rows to sample. If None, no sampling is performed
        sample_from_timestamp: Optional[datetime]
            The timestamp to sample from
        sample_to_timestamp: Optional[datetime]
            The timestamp to sample to
        downsampling_info: Optional[DownSamplingInfoWithTargetColumn]
            The downsampling information
        columns_to_exclude_missing_values: Optional[List[str]
            The columns to exclude missing values from
        missing_data_table_details: Optional[TableDetails]
            Missing data table details
        """
        # Get the base query and column info
        query_expr = await self.get_query_expr(session=session, feature_store=feature_store)

        # Derive output column names and dtypes
        input_columns, output_column_names_and_dtypes = await self.get_output_columns_and_dtypes(
            session=session,
            additional_columns=[downsampling_info.target_column] if downsampling_info else None,
        )
        output_columns = list(output_column_names_and_dtypes.keys())

        # Always perform explicit column selection and renaming
        adapter = get_sql_adapter(session.get_source_info())
        query_expr = select_and_rename_columns(
            query_expr,
            input_columns,
            self.columns_rename_mapping,
            output_column_names_and_dtypes,
            adapter,
        )

        # Build base filter conditions (e.g. time filters)
        base_filter_conditions: list[expressions.Expression] = []

        if SpecialColumnName.POINT_IN_TIME in output_columns and output_column_names_and_dtypes.get(
            SpecialColumnName.POINT_IN_TIME
        ) in {DBVarType.TIMESTAMP, DBVarType.TIMESTAMP_TZ}:
            # Filter to exclude rows that are too old
            if sample_from_timestamp is not None:
                if sample_from_timestamp.tzinfo is not None:
                    sample_from_timestamp = sample_from_timestamp.astimezone(tz.UTC).replace(
                        tzinfo=None
                    )
                base_filter_conditions.append(
                    expressions.GTE(
                        this=adapter.normalize_timestamp_before_comparison(
                            quoted_identifier(SpecialColumnName.POINT_IN_TIME)
                        ),
                        expression=make_literal_value(
                            sample_from_timestamp.isoformat(), cast_as_timestamp=True
                        ),
                    )
                )

            # Filter to exclude rows that are too recent
            if sample_to_timestamp is not None:
                if sample_to_timestamp.tzinfo is not None:
                    sample_to_timestamp = sample_to_timestamp.astimezone(tz.UTC).replace(
                        tzinfo=None
                    )
                base_filter_conditions.append(
                    expressions.LT(
                        this=adapter.normalize_timestamp_before_comparison(
                            quoted_identifier(SpecialColumnName.POINT_IN_TIME)
                        ),
                        expression=make_literal_value(
                            sample_to_timestamp.isoformat(), cast_as_timestamp=True
                        ),
                    )
                )

        # Build missing/non-missing conditions if columns are provided.
        # If a missing_data_table_details is provided, we will split into two queries.
        non_missing_condition = None
        missing_condition = None

        if columns_to_exclude_missing_values:
            valid_columns = [
                col for col in columns_to_exclude_missing_values if col in output_columns
            ]
            if valid_columns:
                non_missing_condition, missing_condition = (
                    get_non_missing_and_missing_condition_pair(columns=valid_columns)
                )

        # Create a helper function to apply conditions to the base query
        def apply_conditions(
            base_query: expressions.Select,
            additional_condition: Optional[expressions.Expression],
        ) -> expressions.Select:
            all_conditions = base_filter_conditions.copy()
            if additional_condition is not None:
                all_conditions.append(additional_condition)
            if all_conditions:
                return (
                    expressions.Select(
                        expressions=[
                            quoted_identifier(col_expr.alias or col_expr.name)
                            for (column_idx, col_expr) in enumerate(base_query.expressions)
                        ]
                    )
                    .from_(base_query.subquery())
                    .where(expressions.And(expressions=all_conditions))
                )
            return base_query

        # Create the main query (for destination) using non-missing condition if applicable
        main_query_expr = apply_conditions(query_expr, non_missing_condition)

        # If sampling is requested, apply it only to the main query
        if sample_rows is not None:
            num_rows = await self.get_row_count(session=session, query_expr=main_query_expr)
            if num_rows > sample_rows:
                if adapter.TABLESAMPLE_SUPPORTS_VIEW:
                    num_percent = self.get_sample_percentage_from_row_count(num_rows, sample_rows)
                    main_query_expr = (
                        adapter.tablesample(main_query_expr, num_percent)
                        .order_by(expressions.Anonymous(this="RANDOM"))
                        .limit(sample_rows)
                    )
                else:
                    main_query_expr = adapter.random_sample(
                        main_query_expr,
                        desired_row_count=sample_rows,
                        total_row_count=num_rows,
                        seed=0,
                    )

        # apply downsampling if applicable, only to the main query
        if downsampling_info:
            main_query_expr = self.get_downsample_sql(
                adapter,
                main_query_expr,
                downsampling_info=downsampling_info,
                seed=0,
            )

        # Materialize the destination table
        await session.create_table_as(table_details=destination, select_expr=main_query_expr)

        # If missing_data_table_details is provided, materialize the missing data table
        if missing_data_table_details and missing_condition is not None:
            missing_query_expr = apply_conditions(query_expr, missing_condition)
            await session.create_table_as(
                table_details=missing_data_table_details, select_expr=missing_query_expr
            )

    def _validate_columns_and_rename_mapping(self, available_columns: list[str]) -> None:
        referenced_columns = list(self.columns or [])
        referenced_columns += (
            list(self.columns_rename_mapping.keys()) if self.columns_rename_mapping else []
        )
        missing_columns = set(referenced_columns) - set(available_columns)
        if missing_columns:
            raise ColumnNotFoundError(
                f"Columns {sorted(missing_columns)} not found (available: {available_columns})"
            )


class ViewRequestInput(BaseRequestInput):
    """
    ViewRequestInput is the input for creating a materialized request table from a view

    graph: QueryGraphModel
        The query graph that defines the view
    node_name: str
        The name of the node in the query graph that defines the view
    type: Literal[RequestInputType.VIEW]
        The type of the input. Must be VIEW for this class
    """

    node_name: StrictStr
    type: Literal[RequestInputType.VIEW] = RequestInputType.VIEW

    # special handling for those attributes that are expensive to deserialize
    # internal_* is used to store the raw data from persistence, _* is used as a cache
    internal_graph: Any = Field(alias="graph", default=None)

    @cached_property
    def graph(self) -> QueryGraphModel:
        """
        Get the graph. If the graph is not loaded, load it first.

        Returns
        -------
        QueryGraphModel
        """
        if isinstance(self.internal_graph, dict):
            return QueryGraphModel(**self.internal_graph)
        else:
            assert isinstance(self.internal_graph, QueryGraphModel)
            return self.internal_graph

    async def get_query_expr(
        self, session: BaseSession, feature_store: FeatureStoreModel
    ) -> Select:
        _ = feature_store
        return get_view_expr(
            graph=self.graph, node_name=self.node_name, source_info=session.get_source_info()
        )

    async def get_column_names_and_dtypes(self, session: BaseSession) -> Dict[str, DBVarType]:
        node = self.graph.get_node_by_name(self.node_name)
        op_struct_info = OperationStructureExtractor(graph=self.graph).extract(node=node)
        op_struct = op_struct_info.operation_structure_map[node.name]
        return cast(
            Dict[str, DBVarType], {column.name: column.dtype for column in op_struct.columns}
        )


class SourceTableRequestInput(BaseRequestInput):
    """
    SourceTableRequestInput is the input for creating a materialized request table from a source table

    source: TabularSource
        The source table
    type: Literal[RequestInputType.SOURCE_TABLE]
        The type of the input. Must be SOURCE_TABLE for this class
    """

    source: TabularSource
    type: Literal[RequestInputType.SOURCE_TABLE] = RequestInputType.SOURCE_TABLE

    async def get_query_expr(
        self, session: BaseSession, feature_store: FeatureStoreModel
    ) -> Select:
        table_schema = await session.list_table_schema(
            table_name=self.source.table_details.table_name,
            schema_name=self.source.table_details.schema_name,
            database_name=self.source.table_details.database_name,
        )
        columns_info = [
            ColumnInfo(**schema.model_dump(by_alias=True)) for schema in table_schema.values()
        ]
        metadata = ExtendedSourceMetadata(
            columns_info=columns_info,
            feature_store_id=feature_store.id,
            feature_store_details=feature_store.get_feature_store_details(),
            source_info=session.get_source_info(),
        )
        return get_source_expr(source=self.source.table_details, metadata=metadata)

    async def get_column_names_and_dtypes(self, session: BaseSession) -> Dict[str, DBVarType]:
        table_schema = await session.list_table_schema(
            table_name=self.source.table_details.table_name,
            database_name=self.source.table_details.database_name,
            schema_name=self.source.table_details.schema_name,
        )
        return {key: value.dtype for key, value in table_schema.items()}


class ManagedViewRequestInput(BaseRequestInput):
    """
    ManagedViewRequestInput is the input for creating a materialized request table from a managed view

    type: Literal[RequestInputType.MANAGED_VIEW]
        The type of the input. Must be MANAGED_VIEW for this class
    """

    managed_view_id: PydanticObjectId
    type: Literal[RequestInputType.MANAGED_VIEW] = RequestInputType.MANAGED_VIEW

    async def get_query_expr(
        self, session: BaseSession, feature_store: FeatureStoreModel
    ) -> Select:
        raise NotImplementedError

    async def get_column_names_and_dtypes(self, session: BaseSession) -> Dict[str, DBVarType]:
        raise NotImplementedError
