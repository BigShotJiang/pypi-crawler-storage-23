"""
Deployment SQL routes module
"""
