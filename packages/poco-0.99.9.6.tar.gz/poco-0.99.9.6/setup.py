#!/usr/bin/env python
import poco
import sys
import platform
from setuptools import setup, find_packages
from setuptools.command.test import test as TestCommand

requires = ['PyYAML>=6.0.2', 'pyaml==21.10.1', 'gitpython==3.1.41', 'svn==1.0.1', 'docopt==0.6.2',
            'pygithub==1.55', 'python-gitlab==3.9.0', 'packaging>=24.0']
test_requires = ['pytest>=7.4.0', 'pytest-cov>=4.1.0']

# MacOS
if platform.system() == "Darwin" and sys.version_info[0] == 3:
    requires.append("certifi>=2022.9.14")
    requires.append("Scrapy>=2.6.2")


class PyTestCommand(TestCommand):
    """ Command to run unit py.test unit tests
    """
    def finalize_options(self):
        TestCommand.finalize_options(self)
        self.test_args = ['--verbose', '--cov', 'poco']
        self.test_suite = True

    def run(self):
        import pytest
        rcode = pytest.main(self.test_args)
        sys.exit(rcode)

setup_options = dict(
    name='poco',
    version=poco.__version__,
    description='One CLI for Docker, Kubernetes and Helm: compose projects (up/down/ps), kubectx/kubens, helm-repos/helm-list.',
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    author='Shiwaforce.com',
    url='https://www.shiwaforce.com',
    packages=find_packages(exclude=['tests*']),
    package_data={'': ['poco.yml',
                       'docker-compose.yml',
                       'command-hierarchy.yml',
                       'config']},
    include_package_data=True,
    python_requires='>=3.12.3',
    install_requires=requires,
    tests_require=test_requires,
    cmdclass={'test': PyTestCommand},
    entry_points={
      'console_scripts': ['poco=poco.poco:main']
    },
    license="Apache License 2.0",
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: System Administrators',
        'Natural Language :: English',
        'License :: OSI Approved :: Apache Software License',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: Python :: 3.14'
    ]
)

setup(**setup_options)
