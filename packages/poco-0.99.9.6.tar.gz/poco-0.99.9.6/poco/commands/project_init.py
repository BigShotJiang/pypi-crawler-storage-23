from .init import Init


class ProjectInit(Init):

    sub_command = "project"
    command = "init"
