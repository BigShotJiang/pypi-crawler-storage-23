# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1] - 2026-02-20

### Added

- Email/password authentication support with automatic token caching
- Token cache with expiration management in `~/.vanda/token_cache.json`
- Entitlement validation on authentication
- Support for `VANDA_LOGIN_EMAIL` and `VANDA_PASSWORD` environment variables
- Async authentication methods in `AsyncAuth` class

### Fixed

- Fixed `asset_class` parameter format in bulk operations (now sent as list)
- Fixed async authentication to include entitlement check

## [0.1.0] - 2024-02-06

### Added

- Initial release
- Synchronous VandaClient
- Asynchronous AsyncVandaClient
- All 12 API endpoints implemented
- Retry logic with exponential backoff
- Comprehensive error handling
- Job polling utilities
- CSV/JSONL export support
- Optional pandas support
- Type hints throughout
- Full test coverage
- CI/CD with GitHub Actions
