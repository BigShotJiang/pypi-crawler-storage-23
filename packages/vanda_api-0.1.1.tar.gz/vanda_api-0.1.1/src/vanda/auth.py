import json
import os
import time
from pathlib import Path
from typing import Optional

import httpx

from vanda.errors import AuthError


class TokenCache:
    """Manages token caching with expiration."""

    def __init__(self, cache_file: Optional[str] = None) -> None:
        """
        Initialize token cache.

        Args:
            cache_file: Path to cache file. If None, uses default location.
        """
        if cache_file:
            self.cache_path = Path(cache_file)
        else:
            cache_dir = Path.home() / ".vanda"
            cache_dir.mkdir(exist_ok=True)
            self.cache_path = cache_dir / "token_cache.json"

    def save(self, access_token: str, expires_in: int) -> None:
        """
        Save token to cache.

        Args:
            access_token: Access token.
            expires_in: Token validity duration in seconds.
        """
        expires_at = time.time() + expires_in
        cache_data = {
            "access_token": access_token,
            "expires_at": expires_at,
        }
        try:
            self.cache_path.write_text(json.dumps(cache_data))
        except Exception:
            pass

    def load(self) -> Optional[str]:
        """
        Load valid token from cache.

        Returns:
            Token if valid and not expired, None otherwise.
        """
        if not self.cache_path.exists():
            return None

        try:
            cache_data = json.loads(self.cache_path.read_text())
            expires_at = cache_data.get("expires_at", 0)

            if time.time() < expires_at - 300:
                return cache_data.get("access_token")
        except Exception:
            pass

        return None

    def clear(self) -> None:
        """Clear token cache."""
        try:
            if self.cache_path.exists():
                self.cache_path.unlink()
        except Exception:
            pass


class Auth:
    """Manages authentication tokens."""

    def __init__(
        self,
        token: Optional[str] = None,
        email: Optional[str] = None,
        password: Optional[str] = None,
        base_url: str = "https://api.vanda-analytics.com",
        env_var: str = "VANDA_API_TOKEN",
        email_env_var: str = "VANDA_LOGIN_EMAIL",
        password_env_var: str = "VANDA_PASSWORD",
        cache_file: Optional[str] = None,
    ) -> None:
        """
        Initialize authentication.

        Args:
            token: API token. If None, reads from environment variable.
            email: Email for basic auth. If None, reads from environment variable.
            password: Password for basic auth. If None, reads from environment variable.
            base_url: API base URL for token endpoint.
            env_var: Environment variable name to read token from.
            email_env_var: Environment variable name to read email from.
            password_env_var: Environment variable name to read password from.
            cache_file: Path to token cache file.

        Raises:
            AuthError: If neither token nor credentials are provided.
        """
        self.base_url = base_url.rstrip("/")
        self._token = token or os.getenv(env_var)
        self._email = email or os.getenv(email_env_var)
        self._password = password or os.getenv(password_env_var)
        self._token_cache = TokenCache(cache_file)

        if self._token:
            self._auth_mode = "token"
        elif self._email and self._password:
            self._auth_mode = "basic"
            cached_token = self._token_cache.load()
            if cached_token:
                self._token = cached_token
            else:
                self._token = self._fetch_token()
        else:
            raise AuthError(
                f"Authentication required. Provide token= or set {env_var}, "
                f"or provide email/password or set {email_env_var}/{password_env_var}."
            )

    def _check_entitlement(self, token: str) -> None:
        """
        Check token entitlement.

        Args:
            token: Access token to check.

        Raises:
            AuthError: If entitlement check fails.
        """
        url = f"{self.base_url}/auth/get-entitlement"
        headers = {"Authorization": f"Bearer {token}"}

        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.get(url, headers=headers)
                response.raise_for_status()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthError("Invalid credentials") from e
            raise AuthError(f"Entitlement check failed: {e}") from e
        except Exception as e:
            raise AuthError(f"Entitlement check failed: {e}") from e

    def _fetch_token(self) -> str:
        """
        Fetch token using basic authentication.

        Returns:
            Access token.

        Raises:
            AuthError: If token fetch fails.
        """
        url = f"{self.base_url}/auth/basic"
        payload = {"email": self._email, "password": self._password}

        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.post(url, json=payload)
                response.raise_for_status()
                data = response.json()

                access_token = data.get("access_token")
                expires_in = data.get("expires_in", 86400)

                if not access_token:
                    raise AuthError("No access token in response")

                # Check entitlement before caching
                self._check_entitlement(access_token)

                self._token_cache.save(access_token, expires_in)
                return access_token

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthError("Invalid credentials") from e
            raise AuthError(f"Token fetch failed: {e}") from e
        except Exception as e:
            raise AuthError(f"Token fetch failed: {e}") from e

    def get_token(self) -> str:
        """
        Get valid token, refreshing if needed.

        Returns:
            Valid access token.
        """
        if self._auth_mode == "basic":
            cached_token = self._token_cache.load()
            if cached_token:
                self._token = cached_token
            else:
                self._token = self._fetch_token()

        return self._token

    def get_headers(self) -> dict[str, str]:
        """Return authentication headers."""
        return {"Authorization": f"Bearer {self.get_token()}"}

    def get_headers_safe(self) -> dict[str, str]:
        """Return headers with token redacted (for logging)."""
        return {"Authorization": "Bearer ***"}

    def refresh_token(self) -> None:
        """Force token refresh for basic auth mode."""
        if self._auth_mode == "basic":
            self._token_cache.clear()
            self._token = self._fetch_token()
