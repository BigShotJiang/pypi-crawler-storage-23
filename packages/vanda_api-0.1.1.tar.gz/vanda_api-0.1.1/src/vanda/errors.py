from typing import Any, Optional


class VandaError(Exception):
    """Base exception for all Vanda SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        request_id: Optional[str] = None,
        response_body: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.request_id = request_id
        self.response_body = response_body

    def __str__(self) -> str:
        parts = [self.message]
        if self.status_code is not None:
            parts.append(f"status_code={self.status_code}")
        if self.request_id:
            parts.append(f"request_id={self.request_id}")
        return " | ".join(parts)


class AuthError(VandaError):
    """Authentication failed."""


class RateLimitError(VandaError):
    """Rate limit exceeded."""

    def __init__(
        self,
        message: str,
        retry_after: Optional[int] = None,
        status_code: Optional[int] = None,
        request_id: Optional[str] = None,
        response_body: Optional[Any] = None,
    ) -> None:
        super().__init__(message, status_code, request_id, response_body)
        self.retry_after = retry_after


class NotFoundError(VandaError):
    """Resource not found."""


class ValidationError(VandaError):
    """Request validation failed."""


class ServerError(VandaError):
    """Server error occurred."""


class TransportError(VandaError):
    """Network or transport error."""
