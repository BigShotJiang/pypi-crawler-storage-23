from typing import Any, Literal, Optional, TypedDict


class JobStatus(TypedDict, total=False):
    """Job status response."""

    job_id: str
    status: str
    created_at: str
    updated_at: str
    error: Optional[str]
    result: Optional[Any]


class TimeseriesParams(TypedDict, total=False):
    """Parameters for timeseries requests."""

    symbol: str
    interval: str
    start_date: str
    end_date: str
    fields: list[str]
    asset_class: str
    records_per_page: int
    page_number: int
    order: str
    calculate_metrics: bool
    type: str
    notional: str
    moneyness: str
    size: str


class BulkSecuritiesParams(TypedDict, total=False):
    """Parameters for bulk securities requests."""

    interval: str
    asset_class: str
    start_date: Optional[str]
    end_date: Optional[str]
    fields: Optional[list[str]]
    identifiers: Optional[list[str]]
    all: Optional[bool]
    type: str
    notional: str
    moneyness: str
    size: str


ExportFormat = Literal["csv", "json"]
CompressionType = Literal["none", "gzip", "zip"]
StreamFormat = Literal["ndjson", "csv"]
