import asyncio
import logging
import random
import time
from collections.abc import Awaitable
from typing import Callable, Optional, TypeVar

import httpx

from vanda.errors import TransportError

logger = logging.getLogger(__name__)

T = TypeVar("T")

RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def calculate_backoff(attempt: int, base_delay: float = 1.0, max_delay: float = 32.0) -> float:
    """
    Calculate exponential backoff with jitter.

    Args:
        attempt: Retry attempt number (0-indexed).
        base_delay: Base delay in seconds.
        max_delay: Maximum delay in seconds.

    Returns:
        Delay in seconds.
    """
    delay = min(base_delay * (2**attempt), max_delay)
    jitter = delay * random.uniform(0, 0.3)
    return delay + jitter


def should_retry(exception: Optional[Exception] = None, status_code: Optional[int] = None) -> bool:
    """
    Determine if request should be retried.

    Args:
        exception: Exception raised during request.
        status_code: HTTP status code.

    Returns:
        True if request should be retried.
    """
    if status_code in RETRYABLE_STATUS_CODES:
        return True
    if isinstance(
        exception, (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError)
    ):
        return True
    return False


def retry_request(
    func: Callable[..., T],
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 32.0,
    retry_after: Optional[int] = None,
) -> T:
    """
    Execute function with retry logic.

    Args:
        func: Function to execute.
        max_retries: Maximum number of retry attempts.
        base_delay: Base delay for exponential backoff.
        max_delay: Maximum delay between retries.
        retry_after: Explicit retry-after delay from server.

    Returns:
        Result from func.

    Raises:
        Exception: Last exception if all retries exhausted.
    """
    last_exception: Optional[Exception] = None

    for attempt in range(max_retries + 1):
        try:
            return func()
        except httpx.HTTPStatusError as e:
            status_code = e.response.status_code
            if not should_retry(status_code=status_code) or attempt == max_retries:
                raise
            last_exception = e

            if status_code == 429 and retry_after:
                delay = float(retry_after)
                logger.warning(
                    "rate_limit_exceeded retry=%d delay=%.2f status=%d",
                    attempt + 1,
                    delay,
                    status_code,
                )
            else:
                delay = calculate_backoff(attempt, base_delay, max_delay)
                logger.warning(
                    "http_error_retry retry=%d delay=%.2f status=%d",
                    attempt + 1,
                    delay,
                    status_code,
                )

            time.sleep(delay)

        except (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError) as e:
            if attempt == max_retries:
                raise TransportError(f"Network error: {e}") from e
            last_exception = e

            delay = calculate_backoff(attempt, base_delay, max_delay)
            logger.warning(
                "network_error_retry retry=%d delay=%.2f error=%s",
                attempt + 1,
                delay,
                type(e).__name__,
            )
            time.sleep(delay)

    if last_exception:
        raise last_exception
    raise RuntimeError("Retry logic failed unexpectedly")


async def async_retry_request(
    func: Callable[..., Awaitable[T]],
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 32.0,
    retry_after: Optional[int] = None,
) -> T:
    """
    Execute async function with retry logic.

    Args:
        func: Async function to execute.
        max_retries: Maximum number of retry attempts.
        base_delay: Base delay for exponential backoff.
        max_delay: Maximum delay between retries.
        retry_after: Explicit retry-after delay from server.

    Returns:
        Result from func.

    Raises:
        Exception: Last exception if all retries exhausted.
    """
    last_exception: Optional[Exception] = None

    for attempt in range(max_retries + 1):
        try:
            return await func()
        except httpx.HTTPStatusError as e:
            status_code = e.response.status_code
            if not should_retry(status_code=status_code) or attempt == max_retries:
                raise
            last_exception = e

            if status_code == 429 and retry_after:
                delay = float(retry_after)
                logger.warning(
                    "rate_limit_exceeded retry=%d delay=%.2f status=%d",
                    attempt + 1,
                    delay,
                    status_code,
                )
            else:
                delay = calculate_backoff(attempt, base_delay, max_delay)
                logger.warning(
                    "http_error_retry retry=%d delay=%.2f status=%d",
                    attempt + 1,
                    delay,
                    status_code,
                )

            await asyncio.sleep(delay)

        except (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError) as e:
            if attempt == max_retries:
                raise TransportError(f"Network error: {e}") from e
            last_exception = e

            delay = calculate_backoff(attempt, base_delay, max_delay)
            logger.warning(
                "network_error_retry retry=%d delay=%.2f error=%s",
                attempt + 1,
                delay,
                type(e).__name__,
            )
            await asyncio.sleep(delay)

    if last_exception:
        raise last_exception
    raise RuntimeError("Retry logic failed unexpectedly")
