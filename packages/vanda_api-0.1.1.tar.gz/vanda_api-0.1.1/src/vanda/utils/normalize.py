from typing import Any


def normalize_result(data: Any) -> list[dict[str, Any]]:
    """
    Normalize API response to list of records.

    Handles various response shapes:
    - {"data": [...]}
    - {"results": [...]}
    - {"data": {symbol: [...]}}
    - [...]
    - {...}

    Args:
        data: Raw API response data.

    Returns:
        List of records (dicts).
    """
    if not data:
        return []

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        if "data" in data:
            data_value = data["data"]
            if isinstance(data_value, list):
                return data_value
            elif isinstance(data_value, dict) and data_value:
                first_value = next(iter(data_value.values()), None)
                if isinstance(first_value, list):
                    records = []
                    for values in data_value.values():
                        if isinstance(values, list):
                            records.extend(values)
                    return records
                else:
                    return [data_value]
            else:
                return [data_value] if data_value else []

        if "results" in data:
            results = data["results"]
            if isinstance(results, list):
                return results
            return [results] if results else []

        return [data]

    return [data]
