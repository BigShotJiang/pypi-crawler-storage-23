import re
from datetime import date, datetime
from typing import Union

from vanda.errors import ValidationError

DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def validate_date_string(date_str: str) -> str:
    """
    Validate date string format (YYYY-MM-DD).

    Args:
        date_str: Date string to validate.

    Returns:
        The validated date string.

    Raises:
        ValidationError: If date string is invalid.
    """
    if not DATE_PATTERN.match(date_str):
        raise ValidationError(f"Invalid date format: {date_str}. Expected YYYY-MM-DD.")
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError as e:
        raise ValidationError(f"Invalid date: {date_str}. {e}") from e
    return date_str


def format_date(date_value: Union[str, date, datetime]) -> str:
    """
    Format date to YYYY-MM-DD string.

    Args:
        date_value: Date as string, date object, or datetime object.

    Returns:
        Formatted date string.

    Raises:
        ValidationError: If date is invalid.
    """
    if isinstance(date_value, str):
        return validate_date_string(date_value)
    elif isinstance(date_value, datetime):
        return date_value.strftime("%Y-%m-%d")
    elif isinstance(date_value, date):
        return date_value.strftime("%Y-%m-%d")
    else:
        raise ValidationError(f"Invalid date type: {type(date_value)}")


def validate_date_range(start_date: str, end_date: str) -> None:
    """
    Validate that start_date is before or equal to end_date.

    Args:
        start_date: Start date string (YYYY-MM-DD).
        end_date: End date string (YYYY-MM-DD).

    Raises:
        ValidationError: If date range is invalid.
    """
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end = datetime.strptime(end_date, "%Y-%m-%d")
    if start > end:
        raise ValidationError(f"start_date ({start_date}) must be <= end_date ({end_date})")
