import csv
import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def save_to_csv(records: list[dict[str, Any]], output_path: str) -> None:
    """
    Save records to CSV file.

    Args:
        records: List of record dictionaries.
        output_path: Output file path.
    """
    if not records:
        logger.warning("No records to save")
        Path(output_path).write_text("")
        return

    fieldnames = list(records[0].keys())
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)
    logger.info("saved_csv path=%s records=%d", output_path, len(records))


def save_to_jsonl(records: list[dict[str, Any]], output_path: str) -> None:
    """
    Save records to JSONL file (newline-delimited JSON).

    Args:
        records: List of record dictionaries.
        output_path: Output file path.
    """
    with open(output_path, "w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record) + "\n")
    logger.info("saved_jsonl path=%s records=%d", output_path, len(records))


def to_dataframe(records: list[dict[str, Any]]) -> Any:
    """
    Convert records to pandas DataFrame.

    Args:
        records: List of record dictionaries.

    Returns:
        pandas.DataFrame if pandas is installed.

    Raises:
        ImportError: If pandas is not installed.
    """
    try:
        import pandas as pd
    except ImportError as e:
        raise ImportError(
            "pandas is not installed. Install with: pip install vanda-analytics[pandas]"
        ) from e
    return pd.DataFrame(records)


def save_dataframe_to_csv(df: Any, output_path: str) -> None:
    """
    Save pandas DataFrame to CSV.

    Args:
        df: pandas.DataFrame.
        output_path: Output file path.
    """
    df.to_csv(output_path, index=False)
    logger.info("saved_dataframe_csv path=%s rows=%d", output_path, len(df))


def write_stream_to_file(content: bytes, output_path: str) -> None:
    """
    Write raw bytes to file.

    Args:
        content: Raw bytes content.
        output_path: Output file path.
    """
    Path(output_path).write_bytes(content)
    size_kb = len(content) / 1024
    logger.info("saved_stream path=%s size_kb=%.2f", output_path, size_kb)
