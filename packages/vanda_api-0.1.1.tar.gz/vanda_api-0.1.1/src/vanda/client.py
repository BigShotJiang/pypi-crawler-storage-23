import logging
import time
from datetime import date, datetime
from typing import Any, Optional, Union

import httpx

from vanda.auth import Auth
from vanda.errors import (
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
    VandaError,
)
from vanda.models import CompressionType, ExportFormat, StreamFormat
from vanda.retry import retry_request
from vanda.utils.dates import format_date, validate_date_range
from vanda.utils.io import write_stream_to_file
from vanda.utils.normalize import normalize_result

logger = logging.getLogger(__name__)


class VandaClient:
    """
    Synchronous client for Vanda Analytics API.

    Example:
        with VandaClient(token="YOUR_TOKEN_HERE") as client:
            data = client.get_timeseries("TSLA", "2025-12-01", "2025-12-31", ["retail_net_turnover"])
    """

    def __init__(
        self,
        token: Optional[str] = None,
        email: Optional[str] = None,
        password: Optional[str] = None,
        base_url: str = "https://api.vanda-analytics.com",
        timeout: float = 600.0,
        max_retries: int = 3,
        cache_file: Optional[str] = None,
    ) -> None:
        """
        Initialize Vanda client.

        Args:
            token: API token. If None, reads from VANDA_API_TOKEN environment variable.
            email: Email for basic auth. If None, reads from VANDA_LOGIN_EMAIL environment variable.
            password: Password for basic auth. If None, reads from VANDA_PASSWORD environment variable.
            base_url: API base URL.
            timeout: Request timeout in seconds.
            max_retries: Maximum retry attempts.
            cache_file: Path to token cache file.

        Raises:
            AuthError: If token is not provided.
        """
        self.auth = Auth(
            token=token, email=email, password=password, base_url=base_url, cache_file=cache_file
        )
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: Optional[httpx.Client] = None

    def __enter__(self) -> "VandaClient":
        """Context manager entry."""
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self.auth.get_headers(),
            timeout=self.timeout,
        )
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit."""
        if self._client:
            self._client.close()
            self._client = None

    @property
    def client(self) -> httpx.Client:
        """Get HTTP client, creating if necessary."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.base_url,
                headers=self.auth.get_headers(),
                timeout=self.timeout,
            )
        return self._client

    def close(self) -> None:
        """Close HTTP client."""
        if self._client:
            self._client.close()
            self._client = None

    def _refresh_client_headers(self) -> None:
        """Refresh client headers with updated token."""
        if self._client:
            self._client.headers.update(self.auth.get_headers())

    def _handle_error(self, response: httpx.Response) -> None:
        """
        Handle HTTP error responses.

        Args:
            response: HTTP response.

        Raises:
            VandaError: Appropriate exception based on status code.
        """
        status_code = response.status_code
        request_id = response.headers.get("x-request-id")

        try:
            body = response.json()
            detail = body.get("detail", response.text)
        except Exception:
            detail = response.text
            body = None

        if status_code == 401 or status_code == 403:
            raise AuthError(
                f"Authentication failed: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )
        elif status_code == 404:
            raise NotFoundError(
                f"Resource not found: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )
        elif status_code == 422:
            raise ValidationError(
                f"Validation error: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )
        elif status_code == 429:
            retry_after = response.headers.get("retry-after")
            retry_after_int = int(retry_after) if retry_after else None
            raise RateLimitError(
                f"Rate limit exceeded: {detail}",
                retry_after=retry_after_int,
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )
        elif status_code >= 500:
            raise ServerError(
                f"Server error: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )
        else:
            raise VandaError(
                f"HTTP {status_code}: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
    ) -> Any:
        """
        Make HTTP request with retry logic.

        Args:
            method: HTTP method.
            path: Request path.
            params: Query parameters.
            json: JSON body.

        Returns:
            Response JSON data.

        Raises:
            VandaError: On error.
        """
        start_time = time.time()
        self._refresh_client_headers()

        def _do_request() -> Any:
            logger.debug(
                "http_request method=%s path=%s headers=%s",
                method,
                path,
                self.auth.get_headers_safe(),
            )
            response = self.client.request(method, path, params=params, json=json)
            if response.status_code >= 400:
                response.raise_for_status()
            return response

        try:
            response = retry_request(_do_request, max_retries=self.max_retries)
            latency = time.time() - start_time
            logger.info(
                "http_success method=%s path=%s status=%d latency=%.3f",
                method,
                path,
                response.status_code,
                latency,
            )
            return response.json()
        except httpx.HTTPStatusError as e:
            latency = time.time() - start_time
            logger.error(
                "http_error method=%s path=%s status=%d latency=%.3f",
                method,
                path,
                e.response.status_code,
                latency,
            )
            self._handle_error(e.response)

    def _request_stream(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
    ) -> bytes:
        """
        Make streaming HTTP request.

        Args:
            method: HTTP method.
            path: Request path.
            params: Query parameters.

        Returns:
            Response content as bytes.

        Raises:
            VandaError: On error.
        """
        start_time = time.time()
        self._refresh_client_headers()

        def _do_request() -> httpx.Response:
            response = self.client.request(method, path, params=params)
            if response.status_code >= 400:
                response.raise_for_status()
            return response

        try:
            response = retry_request(_do_request, max_retries=self.max_retries)
            latency = time.time() - start_time
            logger.info(
                "http_stream_success method=%s path=%s status=%d latency=%.3f size_kb=%.2f",
                method,
                path,
                response.status_code,
                latency,
                len(response.content) / 1024,
            )
            return response.content
        except httpx.HTTPStatusError as e:
            latency = time.time() - start_time
            logger.error(
                "http_error method=%s path=%s status=%d latency=%.3f",
                method,
                path,
                e.response.status_code,
                latency,
            )
            self._handle_error(e.response)
            raise

    def get_timeseries(
        self,
        symbol: str,
        start_date: Union[str, date, datetime],
        end_date: Union[str, date, datetime],
        fields: list[str],
        interval: str = "1d",
        asset_class: str = "cash",
        records_per_page: int = 2000,
        page_number: int = 1,
        order: str = "asc",
        calculate_metrics: bool = False,
        options_type: str = "ALL",
        options_notional: str = "ALL",
        options_moneyness: str = "TOTAL",
        options_size: str = "TOTAL",
    ) -> list[dict[str, Any]]:
        """
        Get timeseries data for a symbol.

        Args:
            symbol: Ticker symbol.
            start_date: Start date (YYYY-MM-DD or date object).
            end_date: End date (YYYY-MM-DD or date object).
            fields: List of fields to retrieve.
            interval: Time interval (1d, 1w, 1m, etc).
            asset_class: "cash" or "options".
            records_per_page: Records per page (max 2000).
            page_number: Page number.
            order: "asc" or "desc".
            calculate_metrics: Calculate additional metrics.
            options_type: Options filter (ALL, CALL, PUT).
            options_notional: Options notional filter.
            options_moneyness: Options moneyness filter.
            options_size: Options size filter.

        Returns:
            List of records.

        Raises:
            ValidationError: If parameters are invalid.
        """
        start_str = format_date(start_date)
        end_str = format_date(end_date)
        validate_date_range(start_str, end_str)

        params: dict[str, Any] = {
            "symbol": symbol,
            "interval": interval,
            "start_date": start_str,
            "end_date": end_str,
            "fields": fields,
            "asset_class": asset_class,
            "records_per_page": records_per_page,
            "page_number": page_number,
            "order": order,
            "calculate_metrics": str(calculate_metrics).lower(),
        }

        if asset_class == "options":
            params.update(
                {
                    "type": options_type,
                    "notional": options_notional,
                    "moneyness": options_moneyness,
                    "size": options_size,
                }
            )

        data = self._request("GET", "/series/timeseries", params=params)

        if "job_id" in data:
            result = self.poll_job(data["job_id"])
            return normalize_result(result)

        return normalize_result(data)

    def get_timeseries_many(
        self,
        symbols: list[str],
        start_date: Union[str, date, datetime],
        end_date: Union[str, date, datetime],
        fields: list[str],
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """
        Get timeseries data for multiple symbols.

        Args:
            symbols: List of ticker symbols.
            start_date: Start date.
            end_date: End date.
            fields: List of fields.
            **kwargs: Additional parameters passed to get_timeseries.

        Returns:
            Aggregated list of records from all symbols.
        """
        all_records = []
        for symbol in symbols:
            records = self.get_timeseries(symbol, start_date, end_date, fields, **kwargs)
            all_records.extend(records)
        return all_records

    def get_leaderboard(
        self,
        interval: str = "1d",
        metric: str = "retail_net_turnover",
        records_per_page: int = 2000,
        page_number: int = 1,
        asset_class: str = "cash",
        start_date: Optional[Union[str, date, datetime]] = None,
        end_date: Optional[Union[str, date, datetime]] = None,
        date_filter: Optional[Union[str, date, datetime]] = None,
        sector: Optional[str] = None,
        options_type: str = "ALL",
        options_notional: str = "ALL",
        options_moneyness: str = "TOTAL",
        options_size: str = "TOTAL",
    ) -> list[dict[str, Any]]:
        """
        Get leaderboard data (ranked by metric).

        Args:
            interval: Time interval.
            metric: Metric to rank by.
            records_per_page: Records per page.
            page_number: Page number.
            asset_class: "cash" or "options".
            start_date: Start date (optional).
            end_date: End date (optional).
            date_filter: Specific date filter (optional).
            sector: Sector filter (optional).
            options_type: Options filter.
            options_notional: Options notional filter.
            options_moneyness: Options moneyness filter.
            options_size: Options size filter.

        Returns:
            List of records.
        """
        params: dict[str, Any] = {
            "interval": interval,
            "metric": metric,
            "records_per_page": records_per_page,
            "page_number": page_number,
            "asset_class": asset_class,
        }

        if start_date:
            params["start_date"] = format_date(start_date)
        if end_date:
            params["end_date"] = format_date(end_date)
        if date_filter:
            params["date"] = format_date(date_filter)
        if sector:
            params["sector"] = sector

        if asset_class == "options":
            params.update(
                {
                    "type": options_type,
                    "notional": options_notional,
                    "moneyness": options_moneyness,
                    "size": options_size,
                }
            )

        data = self._request("GET", "/series/timeseries/leaderboard", params=params)
        return normalize_result(data)

    def create_bulk_securities_job(
        self,
        interval: str = "1d",
        asset_class: str = "cash",
        start_date: Optional[Union[str, date, datetime]] = None,
        end_date: Optional[Union[str, date, datetime]] = None,
        fields: Optional[list[str]] = None,
        identifiers: Optional[list[str]] = None,
        all: bool = False,
        options_type: str = "ALL",
        options_notional: str = "ALL",
        options_moneyness: str = "TOTAL",
        options_size: str = "TOTAL",
    ) -> str:
        """
        Create bulk securities job.

        Args:
            interval: Time interval.
            asset_class: "cash" or "options".
            start_date: Start date (optional).
            end_date: End date (optional).
            fields: Fields to retrieve (optional).
            identifiers: List of identifiers (ignored if all=True).
            all: Fetch all securities.
            options_type: Options filter.
            options_notional: Options notional filter.
            options_moneyness: Options moneyness filter.
            options_size: Options size filter.

        Returns:
            Job ID.

        Raises:
            ValidationError: If neither identifiers nor all is provided.
        """
        if not all and not identifiers:
            raise ValidationError("Must provide identifiers or set all=True")

        payload: dict[str, Any] = {
            "interval": interval,
            "asset_class": [asset_class],
        }

        if all:
            payload["all"] = True
        elif identifiers:
            payload["identifiers"] = identifiers

        if start_date:
            payload["start_date"] = format_date(start_date)
        if end_date:
            payload["end_date"] = format_date(end_date)
        if fields:
            payload["fields"] = fields

        if asset_class == "options":
            payload.update(
                {
                    "type": options_type,
                    "notional": options_notional,
                    "moneyness": options_moneyness,
                    "size": options_size,
                }
            )

        data = self._request("POST", "/series/bulk/securities", json=payload)
        return data["job_id"]

    def bulk_securities(
        self,
        wait: bool = True,
        poll_interval: int = 5,
        max_wait: int = 600,
        **kwargs: Any,
    ) -> Union[str, list[dict[str, Any]]]:
        """
        Fetch bulk securities data.

        Args:
            wait: Wait for job completion and return result.
            poll_interval: Polling interval in seconds.
            max_wait: Maximum wait time in seconds.
            **kwargs: Parameters passed to create_bulk_securities_job.

        Returns:
            Job ID if wait=False, otherwise list of records.
        """
        job_id = self.create_bulk_securities_job(**kwargs)
        if not wait:
            return job_id
        result = self.poll_job(job_id, poll_interval=poll_interval, max_wait=max_wait)
        return normalize_result(result)

    def get_daily_snapshot(
        self,
        interval: str = "1d",
        asset_class: str = "cash",
        limit: int = 2000,
        date_filter: Optional[Union[str, date, datetime]] = None,
        fields: Optional[list[str]] = None,
        is_active: Optional[bool] = None,
        sector: Optional[str] = None,
        wait: bool = True,
        poll_interval: int = 5,
        max_wait: int = 600,
        options_type: str = "ALL",
        options_notional: str = "ALL",
        options_moneyness: str = "TOTAL",
        options_size: str = "TOTAL",
    ) -> Union[str, list[dict[str, Any]]]:
        """
        Get daily snapshot for many securities.

        Args:
            interval: Time interval.
            asset_class: "cash" or "options".
            limit: Maximum securities.
            date_filter: Specific date (optional).
            fields: Fields to retrieve (optional).
            is_active: Filter by active status (optional).
            sector: Sector filter (optional).
            wait: Wait for job completion.
            poll_interval: Polling interval in seconds.
            max_wait: Maximum wait time in seconds.
            options_type: Options filter.
            options_notional: Options notional filter.
            options_moneyness: Options moneyness filter.
            options_size: Options size filter.

        Returns:
            Job ID if wait=False, otherwise list of records.
        """
        payload: dict[str, Any] = {
            "interval": interval,
            "asset_class": [asset_class],
            "limit": limit,
        }

        if date_filter:
            payload["date"] = format_date(date_filter)
        if fields:
            payload["fields"] = fields
        if is_active is not None:
            payload["is_active"] = is_active
        if sector:
            payload["sector"] = sector

        if asset_class == "options":
            payload.update(
                {
                    "type": options_type,
                    "notional": options_notional,
                    "moneyness": options_moneyness,
                    "size": options_size,
                }
            )

        data = self._request("POST", "/series/bulk/daily/snapshot", json=payload)

        if "job_id" in data:
            job_id = data["job_id"]
            if not wait:
                return job_id
            result = self.poll_job(job_id, poll_interval=poll_interval, max_wait=max_wait)
            return normalize_result(result)

        return normalize_result(data)

    def get_job(self, job_id: str) -> dict[str, Any]:
        """
        Get job status and result.

        Args:
            job_id: Job ID.

        Returns:
            Job status dict with result if completed.
        """
        return self._request("GET", f"/series/jobs/{job_id}")

    def get_job_status(self, job_id: str) -> dict[str, Any]:
        """
        Get job status only (lightweight).

        Args:
            job_id: Job ID.

        Returns:
            Job status dict.
        """
        return self._request("GET", f"/series/jobs/{job_id}/status")

    def poll_job(self, job_id: str, poll_interval: int = 5, max_wait: int = 600) -> dict[str, Any]:
        """
        Poll job until completion.

        Args:
            job_id: Job ID.
            poll_interval: Polling interval in seconds.
            max_wait: Maximum wait time in seconds.

        Returns:
            Job result.

        Raises:
            VandaError: If job fails or times out.
        """
        start_time = time.time()
        while time.time() - start_time < max_wait:
            status_data = self.get_job(job_id)
            status = status_data.get("status", "").upper()

            logger.debug("job_poll job_id=%s status=%s", job_id, status)

            if status == "COMPLETED":
                logger.info("job_completed job_id=%s", job_id)
                return status_data.get("result", {})
            elif status == "FAILED":
                error = status_data.get("error", "Unknown error")
                logger.error("job_failed job_id=%s error=%s", job_id, error)
                raise VandaError(f"Job failed: {error}")

            time.sleep(poll_interval)

        raise VandaError(f"Job polling timeout after {max_wait}s")

    def wait_for_job(self, job_id: str, **kwargs: Any) -> dict[str, Any]:
        """Alias for poll_job."""
        return self.poll_job(job_id, **kwargs)

    def export_job_result(
        self,
        job_id: str,
        export_format: ExportFormat = "csv",
        compression: CompressionType = "none",
        output_path: str = "",
    ) -> None:
        """
        Export job result to file.

        Args:
            job_id: Job ID.
            export_format: "csv" or "json".
            compression: "none", "gzip", or "zip".
            output_path: Output file path.
        """
        params = {"export_format": export_format, "compression": compression}
        content = self._request_stream("GET", f"/series/jobs/{job_id}/export", params=params)
        write_stream_to_file(content, output_path)

    def stream_job_result(
        self, job_id: str, format: StreamFormat = "ndjson", output_path: str = ""
    ) -> None:
        """
        Stream job result to file.

        Args:
            job_id: Job ID.
            format: "ndjson" or "csv".
            output_path: Output file path.
        """
        params = {"format": format}
        content = self._request_stream("GET", f"/series/jobs/{job_id}/stream", params=params)
        write_stream_to_file(content, output_path)

    def export_timeseries(
        self,
        symbol: Optional[str] = None,
        vanda_id: Optional[str] = None,
        interval: str = "1d",
        start_date: Optional[Union[str, date, datetime]] = None,
        end_date: Optional[Union[str, date, datetime]] = None,
        export_format: ExportFormat = "csv",
        compression: CompressionType = "none",
        asset_class: str = "cash",
        output_path: str = "",
    ) -> None:
        """
        Export timeseries data to file.

        Args:
            symbol: Ticker symbol (mutually exclusive with vanda_id).
            vanda_id: Vanda ID (mutually exclusive with symbol).
            interval: Time interval.
            start_date: Start date (optional).
            end_date: End date (optional).
            export_format: "csv" or "json".
            compression: "none", "gzip", or "zip".
            asset_class: "cash" or "options".
            output_path: Output file path.

        Raises:
            ValidationError: If neither or both symbol and vanda_id provided.
        """
        if not symbol and not vanda_id:
            raise ValidationError("Must provide either symbol or vanda_id")
        if symbol and vanda_id:
            raise ValidationError("Cannot provide both symbol and vanda_id")

        params: dict[str, Any] = {
            "interval": interval,
            "export_format": export_format,
            "compression": compression,
            "asset_class": asset_class,
        }

        if symbol:
            params["symbol"] = symbol
        if vanda_id:
            params["vanda_id"] = vanda_id
        if start_date:
            params["start_date"] = format_date(start_date)
        if end_date:
            params["end_date"] = format_date(end_date)

        content = self._request_stream("GET", "/series/timeseries/export", params=params)
        write_stream_to_file(content, output_path)

    def list_fields(self, asset_class: str = "cash") -> dict[str, Any]:
        """
        List available fields for asset class.

        Args:
            asset_class: "cash" or "options".

        Returns:
            Fields metadata.
        """
        params = {"asset_class": asset_class}
        return self._request("GET", "/series/timeseries/fields", params=params)

    def list_intervals(self) -> dict[str, Any]:
        """
        List available time intervals.

        Returns:
            Intervals metadata.
        """
        return self._request("GET", "/series/timeseries/intervals")

    def list_securities(
        self, asset_class: str = "cash", limit: int = 2000, is_active: bool = True
    ) -> list[dict[str, Any]]:
        """
        List available securities.

        Args:
            asset_class: "cash" or "options".
            limit: Maximum securities.
            is_active: Filter by active status.

        Returns:
            List of securities.
        """
        params = {
            "asset_class": asset_class,
            "limit": limit,
            "is_active": str(is_active).lower(),
        }
        data = self._request("GET", "/series/timeseries/list", params=params)
        return normalize_result(data)
