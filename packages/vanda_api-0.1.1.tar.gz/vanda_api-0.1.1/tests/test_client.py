from pathlib import Path

import httpx
import pytest
import respx

from vanda import AuthError, ValidationError, VandaClient


@pytest.fixture
def client() -> VandaClient:
    """Create test client."""
    return VandaClient(token="test_token", base_url="https://api.test.com")


@respx.mock
def test_get_timeseries_success(client: VandaClient) -> None:
    """Test successful timeseries request."""
    mock_data = {"data": [{"ts": "2025-12-01", "retail_net_turnover": 1000000}]}
    respx.get("https://api.test.com/series/timeseries").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    result = client.get_timeseries("TSLA", "2025-12-01", "2025-12-31", ["retail_net_turnover"])
    assert len(result) == 1
    assert result[0]["ts"] == "2025-12-01"


@respx.mock
def test_get_timeseries_validation_error(client: VandaClient) -> None:
    """Test validation error."""
    with pytest.raises(ValidationError):
        client.get_timeseries("TSLA", "2025-12-31", "2025-12-01", ["retail_net_turnover"])


@respx.mock
def test_get_timeseries_auth_error(client: VandaClient) -> None:
    """Test auth error."""
    respx.get("https://api.test.com/series/timeseries").mock(
        return_value=httpx.Response(401, json={"detail": "Unauthorized"})
    )

    with pytest.raises(AuthError):
        client.get_timeseries("TSLA", "2025-12-01", "2025-12-31", ["retail_net_turnover"])


@respx.mock
def test_list_securities(client: VandaClient) -> None:
    """Test list securities."""
    mock_data = {"data": [{"symbol": "TSLA"}, {"symbol": "NVDA"}]}
    respx.get("https://api.test.com/series/timeseries/list").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    result = client.list_securities()
    assert len(result) == 2
    assert result[0]["symbol"] == "TSLA"


@respx.mock
def test_export_timeseries_validation(client: VandaClient) -> None:
    """Test export validation."""
    with pytest.raises(ValidationError, match="Must provide either symbol or vanda_id"):
        client.export_timeseries(output_path="test.csv")

    with pytest.raises(ValidationError, match="Cannot provide both"):
        client.export_timeseries(symbol="TSLA", vanda_id="vanda_123", output_path="test.csv")


@respx.mock
def test_basic_auth_success(tmp_path: Path) -> None:
    """Test basic authentication with email and password."""
    token_response = {
        "access_token": "test_access_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    respx.post("https://api.test.com/auth/basic").mock(
        return_value=httpx.Response(200, json=token_response)
    )

    respx.get("https://api.test.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    cache_file = str(tmp_path / "test_cache.json")
    client = VandaClient(
        email="test@example.com",
        password="test_password",
        base_url="https://api.test.com",
        cache_file=cache_file,
    )

    assert client.auth._token == "test_access_token"
    assert client.auth._auth_mode == "basic"


@respx.mock
def test_basic_auth_invalid_credentials(tmp_path: Path) -> None:
    """Test basic authentication with invalid credentials."""
    respx.post("https://api.test.com/auth/basic").mock(
        return_value=httpx.Response(401, json={"detail": "Invalid credentials"})
    )

    cache_file = str(tmp_path / "test_cache.json")
    with pytest.raises(AuthError, match="Invalid credentials"):
        VandaClient(
            email="test@example.com",
            password="wrong_password",
            base_url="https://api.test.com",
            cache_file=cache_file,
        )


def test_auth_no_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    """Test authentication with no credentials provided."""
    monkeypatch.delenv("VANDA_API_TOKEN", raising=False)
    monkeypatch.delenv("VANDA_LOGIN_EMAIL", raising=False)
    monkeypatch.delenv("VANDA_PASSWORD", raising=False)

    with pytest.raises(AuthError, match="Authentication required"):
        VandaClient(base_url="https://api.test.com")


@respx.mock
def test_basic_auth_request_includes_token(tmp_path: Path) -> None:
    """Test that requests with basic auth include bearer token."""
    token_response = {
        "access_token": "test_access_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    respx.post("https://api.test.com/auth/basic").mock(
        return_value=httpx.Response(200, json=token_response)
    )

    respx.get("https://api.test.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    mock_data = {"data": [{"symbol": "TSLA"}]}
    route = respx.get("https://api.test.com/series/timeseries/list").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    cache_file = str(tmp_path / "test_cache.json")
    with VandaClient(
        email="test@example.com",
        password="test_password",
        base_url="https://api.test.com",
        cache_file=cache_file,
    ) as client:
        client.list_securities()

    assert route.called
    assert route.calls.last.request.headers["Authorization"] == "Bearer test_access_token"
