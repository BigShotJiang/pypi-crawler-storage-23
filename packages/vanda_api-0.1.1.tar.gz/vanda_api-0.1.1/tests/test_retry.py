from vanda.retry import calculate_backoff, should_retry


def test_calculate_backoff() -> None:
    """Test exponential backoff calculation."""
    delay0 = calculate_backoff(0, base_delay=1.0)
    delay1 = calculate_backoff(1, base_delay=1.0)
    delay2 = calculate_backoff(2, base_delay=1.0)

    assert 1.0 <= delay0 <= 1.3
    assert 2.0 <= delay1 <= 2.6
    assert 4.0 <= delay2 <= 5.2


def test_should_retry() -> None:
    """Test retry decision logic."""
    assert should_retry(status_code=429)
    assert should_retry(status_code=500)
    assert should_retry(status_code=502)
    assert should_retry(status_code=503)
    assert should_retry(status_code=504)
    assert not should_retry(status_code=200)
    assert not should_retry(status_code=400)
    assert not should_retry(status_code=404)
