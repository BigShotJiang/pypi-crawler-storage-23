import time
from pathlib import Path

import httpx
import pytest
import respx

from vanda.auth import Auth, TokenCache
from vanda.errors import AuthError


@pytest.fixture
def temp_cache_file(tmp_path: Path) -> str:
    """Create temporary cache file."""
    return str(tmp_path / "test_token_cache.json")


def test_token_cache_save_and_load(temp_cache_file: str) -> None:
    """Test token cache save and load."""
    cache = TokenCache(temp_cache_file)
    cache.save("test_token", 86400)

    loaded_token = cache.load()
    assert loaded_token == "test_token"


def test_token_cache_expired(temp_cache_file: str) -> None:
    """Test expired token is not loaded."""
    cache = TokenCache(temp_cache_file)
    cache.save("test_token", 1)
    time.sleep(2)

    loaded_token = cache.load()
    assert loaded_token is None


def test_token_cache_clear(temp_cache_file: str) -> None:
    """Test token cache clear."""
    cache = TokenCache(temp_cache_file)
    cache.save("test_token", 86400)
    cache.clear()

    loaded_token = cache.load()
    assert loaded_token is None


def test_auth_with_token() -> None:
    """Test authentication with direct token."""
    auth = Auth(token="test_token")
    assert auth._token == "test_token"
    assert auth._auth_mode == "token"
    assert auth.get_headers() == {"Authorization": "Bearer test_token"}


def test_auth_with_token_env_var(monkeypatch: pytest.MonkeyPatch) -> None:
    """Test authentication with token from environment variable."""
    monkeypatch.setenv("VANDA_API_TOKEN", "env_token")
    auth = Auth()
    assert auth._token == "env_token"
    assert auth._auth_mode == "token"


@respx.mock
def test_auth_with_email_password(temp_cache_file: str) -> None:
    """Test authentication with email and password."""
    token_response = {
        "access_token": "fetched_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    respx.post("https://api.vanda-analytics.com/auth/basic").mock(
        return_value=httpx.Response(200, json=token_response)
    )

    respx.get("https://api.vanda-analytics.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    auth = Auth(email="test@example.com", password="test_password", cache_file=temp_cache_file)
    assert auth._token == "fetched_token"
    assert auth._auth_mode == "basic"


@respx.mock
def test_auth_with_email_password_env_vars(
    monkeypatch: pytest.MonkeyPatch, temp_cache_file: str
) -> None:
    """Test authentication with email and password from environment variables."""
    monkeypatch.setenv("VANDA_LOGIN_EMAIL", "test@example.com")
    monkeypatch.setenv("VANDA_PASSWORD", "test_password")

    token_response = {
        "access_token": "fetched_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    respx.post("https://api.vanda-analytics.com/auth/basic").mock(
        return_value=httpx.Response(200, json=token_response)
    )

    respx.get("https://api.vanda-analytics.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    auth = Auth(cache_file=temp_cache_file)
    assert auth._token == "fetched_token"
    assert auth._auth_mode == "basic"


@respx.mock
def test_auth_uses_cached_token(temp_cache_file: str) -> None:
    """Test that cached token is used before fetching new one."""
    cache = TokenCache(temp_cache_file)
    cache.save("cached_token", 86400)

    auth = Auth(email="test@example.com", password="test_password", cache_file=temp_cache_file)
    assert auth._token == "cached_token"


@respx.mock
def test_auth_fetch_token_on_cache_miss(temp_cache_file: str) -> None:
    """Test token fetch when cache is empty."""
    token_response = {
        "access_token": "new_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    route = respx.post("https://api.vanda-analytics.com/auth/basic").mock(
        return_value=httpx.Response(200, json=token_response)
    )

    respx.get("https://api.vanda-analytics.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    auth = Auth(email="test@example.com", password="test_password", cache_file=temp_cache_file)
    assert auth._token == "new_token"
    assert route.called


@respx.mock
def test_auth_invalid_credentials(tmp_path: Path) -> None:
    """Test authentication with invalid credentials."""
    respx.post("https://api.vanda-analytics.com/auth/basic").mock(
        return_value=httpx.Response(401, json={"detail": "Invalid credentials"})
    )

    cache_file = str(tmp_path / "test_cache.json")
    with pytest.raises(AuthError, match="Invalid credentials"):
        Auth(email="test@example.com", password="wrong_password", cache_file=cache_file)


def test_auth_no_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    """Test authentication without any credentials."""
    monkeypatch.delenv("VANDA_API_TOKEN", raising=False)
    monkeypatch.delenv("VANDA_LOGIN_EMAIL", raising=False)
    monkeypatch.delenv("VANDA_PASSWORD", raising=False)

    with pytest.raises(AuthError, match="Authentication required"):
        Auth()


def test_auth_get_headers_safe() -> None:
    """Test that get_headers_safe redacts token."""
    auth = Auth(token="test_token")
    safe_headers = auth.get_headers_safe()
    assert safe_headers == {"Authorization": "Bearer ***"}


@respx.mock
def test_auth_refresh_token(temp_cache_file: str) -> None:
    """Test token refresh for basic auth."""
    token_response = {
        "access_token": "initial_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    respx.post("https://api.vanda-analytics.com/auth/basic").mock(
        return_value=httpx.Response(200, json=token_response)
    )

    respx.get("https://api.vanda-analytics.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    auth = Auth(email="test@example.com", password="test_password", cache_file=temp_cache_file)
    initial_token = auth._token

    refresh_response = {
        "access_token": "refreshed_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    respx.post("https://api.vanda-analytics.com/auth/basic").mock(
        return_value=httpx.Response(200, json=refresh_response)
    )

    respx.get("https://api.vanda-analytics.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    auth.refresh_token()
    assert auth._token != initial_token
    assert auth._token == "refreshed_token"


@respx.mock
def test_auth_get_token_refreshes_on_expiry(temp_cache_file: str) -> None:
    """Test get_token refreshes expired token."""
    cache = TokenCache(temp_cache_file)
    cache.save("expired_token", 1)
    time.sleep(2)

    token_response = {
        "access_token": "new_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    respx.post("https://api.vanda-analytics.com/auth/basic").mock(
        return_value=httpx.Response(200, json=token_response)
    )

    respx.get("https://api.vanda-analytics.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    auth = Auth(email="test@example.com", password="test_password", cache_file=temp_cache_file)

    token = auth.get_token()
    assert token == "new_token"
