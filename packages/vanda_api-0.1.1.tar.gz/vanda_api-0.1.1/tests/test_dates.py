from datetime import date, datetime

import pytest

from vanda.errors import ValidationError
from vanda.utils.dates import format_date, validate_date_range, validate_date_string


def test_validate_date_string_valid() -> None:
    """Test valid date string."""
    assert validate_date_string("2025-12-01") == "2025-12-01"


def test_validate_date_string_invalid_format() -> None:
    """Test invalid date format."""
    with pytest.raises(ValidationError):
        validate_date_string("2025/12/01")


def test_validate_date_string_invalid_date() -> None:
    """Test invalid date value."""
    with pytest.raises(ValidationError):
        validate_date_string("2025-13-01")


def test_format_date_from_string() -> None:
    """Test format date from string."""
    assert format_date("2025-12-01") == "2025-12-01"


def test_format_date_from_date() -> None:
    """Test format date from date object."""
    assert format_date(date(2025, 12, 1)) == "2025-12-01"


def test_format_date_from_datetime() -> None:
    """Test format date from datetime object."""
    assert format_date(datetime(2025, 12, 1, 10, 30)) == "2025-12-01"


def test_validate_date_range_valid() -> None:
    """Test valid date range."""
    validate_date_range("2025-12-01", "2025-12-31")


def test_validate_date_range_invalid() -> None:
    """Test invalid date range."""
    with pytest.raises(ValidationError):
        validate_date_range("2025-12-31", "2025-12-01")
