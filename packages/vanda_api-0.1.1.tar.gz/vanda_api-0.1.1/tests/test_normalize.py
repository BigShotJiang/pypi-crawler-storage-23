from vanda.utils.normalize import normalize_result


def test_normalize_list() -> None:
    """Test normalize list response."""
    data = [{"a": 1}, {"b": 2}]
    result = normalize_result(data)
    assert result == data


def test_normalize_dict_with_data() -> None:
    """Test normalize dict with data key."""
    data = {"data": [{"a": 1}]}
    result = normalize_result(data)
    assert result == [{"a": 1}]


def test_normalize_dict_with_results() -> None:
    """Test normalize dict with results key."""
    data = {"results": [{"a": 1}]}
    result = normalize_result(data)
    assert result == [{"a": 1}]


def test_normalize_nested_dict() -> None:
    """Test normalize nested dict (symbol: records)."""
    data = {"data": {"TSLA": [{"x": 1}], "NVDA": [{"y": 2}]}}
    result = normalize_result(data)
    assert len(result) == 2
    assert {"x": 1} in result
    assert {"y": 2} in result


def test_normalize_empty() -> None:
    """Test normalize empty data."""
    assert normalize_result(None) == []
    assert normalize_result({}) == []
    assert normalize_result([]) == []
