from pathlib import Path

import httpx
import pytest
import respx

from vanda import AsyncVandaClient, AuthError


@pytest.fixture
async def client() -> AsyncVandaClient:
    """Create test async client."""
    return AsyncVandaClient(token="test_token", base_url="https://api.test.com")


@pytest.mark.asyncio
@respx.mock
async def test_get_timeseries_success(client: AsyncVandaClient) -> None:
    """Test successful async timeseries request."""
    mock_data = {"data": [{"ts": "2025-12-01", "retail_net_turnover": 1000000}]}
    respx.get("https://api.test.com/series/timeseries").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    result = await client.get_timeseries(
        "TSLA", "2025-12-01", "2025-12-31", ["retail_net_turnover"]
    )
    assert len(result) == 1
    assert result[0]["ts"] == "2025-12-01"


@pytest.mark.asyncio
@respx.mock
async def test_get_timeseries_auth_error(client: AsyncVandaClient) -> None:
    """Test auth error in async client."""
    respx.get("https://api.test.com/series/timeseries").mock(
        return_value=httpx.Response(401, json={"detail": "Unauthorized"})
    )

    with pytest.raises(AuthError):
        await client.get_timeseries("TSLA", "2025-12-01", "2025-12-31", ["retail_net_turnover"])


@pytest.mark.asyncio
@respx.mock
async def test_list_securities(client: AsyncVandaClient) -> None:
    """Test async list securities."""
    mock_data = {"data": [{"symbol": "TSLA"}, {"symbol": "NVDA"}]}
    respx.get("https://api.test.com/series/timeseries/list").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    result = await client.list_securities()
    assert len(result) == 2


@pytest.mark.asyncio
@respx.mock
async def test_context_manager(client: AsyncVandaClient) -> None:
    """Test async context manager."""
    mock_data = {"data": [{"symbol": "TSLA"}]}
    respx.get("https://api.test.com/series/timeseries/list").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    async with AsyncVandaClient(token="test_token", base_url="https://api.test.com") as c:
        result = await c.list_securities()
        assert len(result) == 1


@pytest.mark.asyncio
@respx.mock
async def test_basic_auth_success(tmp_path: Path) -> None:
    """Test async basic authentication with email and password."""
    token_response = {
        "access_token": "test_access_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    respx.post("https://api.test.com/auth/basic").mock(
        return_value=httpx.Response(200, json=token_response)
    )

    respx.get("https://api.test.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    cache_file = str(tmp_path / "test_cache.json")
    client = AsyncVandaClient(
        email="test@example.com",
        password="test_password",
        base_url="https://api.test.com",
        cache_file=cache_file,
    )

    assert client.auth._token == "test_access_token"
    assert client.auth._auth_mode == "basic"
    await client.close()


@pytest.mark.asyncio
@respx.mock
async def test_basic_auth_invalid_credentials(tmp_path: Path) -> None:
    """Test async basic authentication with invalid credentials."""
    respx.post("https://api.test.com/auth/basic").mock(
        return_value=httpx.Response(401, json={"detail": "Invalid credentials"})
    )

    cache_file = str(tmp_path / "test_cache.json")
    with pytest.raises(AuthError, match="Invalid credentials"):
        AsyncVandaClient(
            email="test@example.com",
            password="wrong_password",
            base_url="https://api.test.com",
            cache_file=cache_file,
        )


@pytest.mark.asyncio
async def test_auth_no_credentials(monkeypatch: pytest.MonkeyPatch) -> None:
    """Test async authentication with no credentials provided."""
    monkeypatch.delenv("VANDA_API_TOKEN", raising=False)
    monkeypatch.delenv("VANDA_LOGIN_EMAIL", raising=False)
    monkeypatch.delenv("VANDA_PASSWORD", raising=False)

    with pytest.raises(AuthError, match="Authentication required"):
        AsyncVandaClient(base_url="https://api.test.com")


@pytest.mark.asyncio
@respx.mock
async def test_basic_auth_request_includes_token(tmp_path: Path) -> None:
    """Test that async requests with basic auth include bearer token."""
    token_response = {
        "access_token": "test_access_token",
        "token_type": "Bearer",
        "expires_in": 86400,
        "scope": "openid profile email",
    }
    respx.post("https://api.test.com/auth/basic").mock(
        return_value=httpx.Response(200, json=token_response)
    )

    respx.get("https://api.test.com/auth/get-entitlement").mock(
        return_value=httpx.Response(200, json={})
    )

    mock_data = {"data": [{"symbol": "TSLA"}]}
    route = respx.get("https://api.test.com/series/timeseries/list").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    cache_file = str(tmp_path / "test_cache.json")
    async with AsyncVandaClient(
        email="test@example.com",
        password="test_password",
        base_url="https://api.test.com",
        cache_file=cache_file,
    ) as client:
        await client.list_securities()

    assert route.called
    assert route.calls.last.request.headers["Authorization"] == "Bearer test_access_token"
