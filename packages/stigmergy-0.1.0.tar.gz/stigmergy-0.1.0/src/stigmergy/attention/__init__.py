"""Probabilistic attention model — per-person P(knows) and surfacing decisions."""
