from DAJIN2.core.classification.classifier import classify_alleles
