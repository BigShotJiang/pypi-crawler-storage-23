from setuptools import setup, find_packages

setup(
    name='ventas_tecnotic',
    version='0.1.0',
    author='Cesar Araujo Dominguez',
    author_email='cesar103.caad@gmail.com',
    description='Paquete para gestionar ventas, precios, impuestos y descuentos',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/GRLL/PROGRAMACION/APLICACION_VENTAS',
    packages=find_packages(),
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.10',
)

# https://pypi.org/account/register/

