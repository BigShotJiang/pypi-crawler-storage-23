# Aplicación de ventas

Este paquete proporciona funcionalidades para gestionar ventas, incluyendo cálculos de precios,
impuestos y descuentos.

## instalación

Puedes instalar el paquete usando:
```bash
pip install .
"