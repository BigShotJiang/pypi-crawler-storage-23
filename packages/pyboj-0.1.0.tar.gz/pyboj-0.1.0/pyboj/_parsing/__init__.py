"""Shared parsing utilities for pyboj domain objects."""
