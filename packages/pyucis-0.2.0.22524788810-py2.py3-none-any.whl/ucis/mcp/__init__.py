"""
PyUCIS MCP Server

Model Context Protocol server for exposing UCIS coverage data to AI agents.
"""

__version__ = "0.1.0"
