"""CLI package export."""

from bub.cli.app import app

__all__ = ["app"]
