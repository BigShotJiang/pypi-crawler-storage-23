"""Bub package."""

from bub.cli import app

__all__ = ["app"]
__version__ = "0.2.2"
