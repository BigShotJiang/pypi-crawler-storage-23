"""
ripd — GPU frame ripper. Kill ffmpeg.

Hardware-accelerated video frame extraction using NVIDIA NVDEC.
Zero subprocess overhead. Native resolution. 6× faster than ffmpeg.

    from ripd import extract_frames, extract_triplets
"""

__version__ = "0.1.0"
__all__ = ["extract_frames", "extract_triplets", "download_url"]

from ripd.core import extract_frames, extract_triplets, download_url
