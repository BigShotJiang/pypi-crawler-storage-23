"""
ripd.core — NVDEC extraction engine
=====================================
Hardware-accelerated video frame extraction using PyNvVideoCodec.

Zero ffmpeg. Zero subprocess overhead. Native resolution output.
NVDEC runs on the dedicated video decode hardware — zero impact on
concurrent CUDA training jobs on the same GPU.
"""

from __future__ import annotations

import ctypes
import gc
import json
import shutil
import subprocess
import tarfile
import tempfile
from pathlib import Path
from typing import Iterator, List, Optional, Tuple

import cv2
import numpy as np

try:
    import PyNvVideoCodec as nvc
    from PyNvVideoCodec.decoders.SimpleDecoder import SimpleDecoder as _NvcSD
    _HAS_NVC = True
except ImportError:
    _HAS_NVC = False
    _NvcSD = None

# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────
DEFAULT_FPS    = 10
MAX_TRIPLETS   = 5
MIN_FRAME_GAP  = 2
MAX_FRAME_GAP  = 8
MIN_FRAMES     = 10
VIDEO_EXTS     = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".flv", ".ts"}

_GPU_ID: int = 0


def set_gpu(gpu_id: int) -> None:
    """Set which GPU to use for NVDEC decoding."""
    global _GPU_ID
    _GPU_ID = gpu_id


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _require_nvc() -> None:
    if not _HAS_NVC:
        raise ImportError(
            "PyNvVideoCodec is not installed.\n"
            "Install: pip install PyNvVideoCodec\n"
            "Requires: NVIDIA GPU, CUDA driver >= 525"
        )


def _open_dec(path: str):
    _require_nvc()
    try:
        return _NvcSD(
            enc_file_path=path,
            gpu_id=_GPU_ID,
            use_device_memory=False,
            output_color_type=nvc.OutputColorType.RGB,
        )
    except Exception as e:
        raise RuntimeError(f"NVDEC could not open {Path(path).name}: {e}") from e


def _close_dec(dec) -> None:
    try:
        dec.stop()
    except Exception:
        pass


def _frame_to_numpy(frame) -> np.ndarray:
    """DecodedFrame (host memory, RGB) → (H, W, 3) uint8 ndarray."""
    ptr = frame.GetPtrToPlane(0)
    H, W, C = frame.shape
    buf = (ctypes.c_uint8 * (H * W * C)).from_address(ptr)
    return np.frombuffer(buf, dtype=np.uint8).reshape((H, W, C)).copy()


def _resize_frame(
    frame: np.ndarray,
    max_size: Optional[int],
    exact_wh: Optional[Tuple[int, int]],
    fit: str,
) -> np.ndarray:
    if max_size is None and exact_wh is None:
        return frame
    H, W = frame.shape[:2]
    if max_size is not None:
        scale = max_size / max(H, W)
        if scale < 1.0:
            nw = max(1, int(round(W * scale)))
            nh = max(1, int(round(H * scale)))
            return cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_AREA)
        return frame
    tw, th = exact_wh
    if fit == "stretch":
        return cv2.resize(frame, (tw, th), interpolation=cv2.INTER_AREA)
    if fit == "letterbox":
        scale = min(tw / W, th / H)
        nw, nh = int(round(W * scale)), int(round(H * scale))
        res = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_AREA)
        canvas = np.zeros((th, tw, 3), dtype=np.uint8)
        y0, x0 = (th - nh) // 2, (tw - nw) // 2
        canvas[y0:y0+nh, x0:x0+nw] = res
        return canvas
    # crop
    scale = max(tw / W, th / H)
    nw, nh = int(round(W * scale)), int(round(H * scale))
    res = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_AREA)
    y0, x0 = (nh - th) // 2, (nw - tw) // 2
    return res[y0:y0+th, x0:x0+tw]


def _encode(frame_rgb: np.ndarray, fmt: str, quality: int) -> bytes:
    bgr = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)
    params = {
        "jpeg": [cv2.IMWRITE_JPEG_QUALITY, quality],
        "png":  [cv2.IMWRITE_PNG_COMPRESSION, 6],
        "webp": [cv2.IMWRITE_WEBP_QUALITY, quality],
    }
    ok, buf = cv2.imencode(
        {"jpeg": ".jpg", "png": ".png", "webp": ".webp"}[fmt],
        bgr, params[fmt],
    )
    if not ok:
        raise RuntimeError(f"imencode failed ({fmt})")
    return bytes(buf)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def extract_frames(
    video_path: str | Path,
    output_dir: str | Path,
    *,
    fps: float = DEFAULT_FPS,
    fmt: str = "jpeg",
    quality: int = 90,
    max_size: Optional[int] = None,
    exact_wh: Optional[Tuple[int, int]] = None,
    fit: str = "crop",
    dry_run: bool = False,
) -> int:
    """
    Extract individual frames from a video at a target FPS.

    Args:
        video_path: Path to the input video file.
        output_dir: Directory to write frame images into.
        fps:        Target extraction FPS (default: 10).
        fmt:        Output format: "jpeg", "png", or "webp".
        quality:    JPEG/WebP quality 1-100 (default: 90).
        max_size:   Cap longest edge to N pixels (aspect-preserving).
        exact_wh:   Exact (width, height) output size.
        fit:        Resize strategy: "crop", "letterbox", or "stretch".
        dry_run:    Count frames without writing files.

    Returns:
        Number of frames written (or counted in dry_run mode).

    Example:
        >>> import ripd
        >>> n = ripd.extract_frames("clip.mp4", "./frames", fps=5)
        >>> print(f"Extracted {n} frames")
    """
    video_path = Path(video_path)
    output_dir = Path(output_dir)

    dec = _open_dec(str(video_path))
    try:
        try:
            meta = dec.get_stream_metadata()
            native_fps = float(meta.frame_rate) if hasattr(meta, "frame_rate") else 25.0
        except Exception:
            native_fps = 25.0

        n_frames = len(dec)
        step     = max(1, round(native_fps / fps))
        indices  = list(range(0, n_frames, step))

        if dry_run:
            return len(indices)

        frame_dir = output_dir / video_path.stem
        frame_dir.mkdir(parents=True, exist_ok=True)
        ext = {"jpeg": "jpg", "png": "png", "webp": "webp"}[fmt]

        written = 0
        chunk = 64
        for start_i in range(0, len(indices), chunk):
            batch_idx  = indices[start_i : start_i + chunk]
            raw_frames = dec[batch_idx]
            for j, raw_f in enumerate(raw_frames):
                arr = _frame_to_numpy(raw_f)
                arr = _resize_frame(arr, max_size, exact_wh, fit)
                (frame_dir / f"f{start_i + j:05d}.{ext}").write_bytes(
                    _encode(arr, fmt, quality)
                )
                written += 1
        return written
    finally:
        _close_dec(dec)
        gc.collect()


def extract_triplets(
    video_path: str | Path,
    output_dir: str | Path,
    *,
    max_triplets: int = MAX_TRIPLETS,
    min_gap: int = MIN_FRAME_GAP,
    max_gap: int = MAX_FRAME_GAP,
    min_frames: int = MIN_FRAMES,
    fmt: str = "jpeg",
    quality: int = 90,
    max_size: Optional[int] = None,
    exact_wh: Optional[Tuple[int, int]] = None,
    fit: str = "crop",
    dry_run: bool = False,
    seed: Optional[int] = None,
) -> int:
    """
    Extract (im1, im2, im3) frame triplets for VSR/interpolation training.

    Each triplet is written to a subdirectory:
        output_dir/
          {video_stem}_00/
            im1.jpg   ← frame at t0
            im2.jpg   ← frame at t1 (training target)
            im3.jpg   ← frame at t2

    Args:
        video_path:   Path to the input video file.
        output_dir:   Directory to write triplet subdirectories into.
        max_triplets: Maximum number of triplets to extract per video.
        min_gap:      Minimum frame gap between triplet members.
        max_gap:      Maximum frame gap between triplet members.
        min_frames:   Skip videos shorter than this many frames.
        fmt:          Output format: "jpeg", "png", or "webp".
        quality:      JPEG/WebP quality 1-100 (default: 90).
        max_size:     Cap longest edge to N pixels (aspect-preserving).
        exact_wh:     Exact (width, height) output size.
        fit:          Resize strategy: "crop", "letterbox", or "stretch".
        dry_run:      Count triplets without writing files.
        seed:         RNG seed for reproducible triplet selection.

    Returns:
        Number of triplets written (or counted in dry_run mode).

    Example:
        >>> import ripd
        >>> n = ripd.extract_triplets("clip.mp4", "./triplets", max_triplets=10)
        >>> print(f"Extracted {n} triplets")
    """
    video_path = Path(video_path)
    output_dir = Path(output_dir)

    dec = _open_dec(str(video_path))
    try:
        n_frames = len(dec)
        if n_frames < min_frames:
            return 0

        rng_seed = seed if seed is not None else abs(hash(str(video_path))) % 2**31
        rng  = np.random.RandomState(rng_seed)
        used: set = set()
        count = 0
        ext = {"jpeg": "jpg", "png": "png", "webp": "webp"}[fmt]
        video_id = video_path.stem[:40]

        for _ in range(max_triplets * 10):
            if count >= max_triplets:
                break
            gap   = int(rng.randint(min_gap, max_gap + 1))
            start = int(rng.randint(0, max(1, n_frames - 2 * gap)))
            pos   = (start, start + gap, start + 2 * gap)
            if pos[2] >= n_frames or pos in used:
                continue
            used.add(pos)

            if dry_run:
                count += 1
                continue

            raw_frames = dec.get_batch_frames_by_index(list(pos))

            triplet_dir = output_dir / f"{video_id}_{count:02d}"
            triplet_dir.mkdir(parents=True, exist_ok=True)

            for raw_f, name in zip(raw_frames, ("im1", "im2", "im3")):
                arr = _frame_to_numpy(raw_f)
                arr = _resize_frame(arr, max_size, exact_wh, fit)
                (triplet_dir / f"{name}.{ext}").write_bytes(
                    _encode(arr, fmt, quality)
                )
            count += 1

        return count
    finally:
        _close_dec(dec)
        gc.collect()


def download_url(url: str, output_dir: str | Path) -> Path:
    """
    Download a video from a URL using yt-dlp.

    Requires yt-dlp in PATH: pip install yt-dlp

    Args:
        url:        Video URL (YouTube, direct MP4, etc.).
        output_dir: Directory to save the downloaded video.

    Returns:
        Path to the downloaded video file.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    out_tmpl = str(output_dir / "%(id)s.%(ext)s")
    cmd = ["yt-dlp", "-f", "bestvideo[ext=mp4]/bestvideo/best",
           "-o", out_tmpl, "--no-playlist", url]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    except FileNotFoundError:
        raise RuntimeError("yt-dlp not found. Install: pip install yt-dlp")
    except subprocess.TimeoutExpired:
        raise RuntimeError("yt-dlp timed out after 300s")
    if r.returncode != 0:
        raise RuntimeError(f"yt-dlp failed: {r.stderr[-500:]}")
    videos = [p for p in output_dir.glob("*") if p.suffix.lower() in VIDEO_EXTS]
    if not videos:
        raise RuntimeError("yt-dlp succeeded but produced no video file")
    return videos[0]


def process_kinetics_tar(
    tar_path: str | Path,
    output_dir: str | Path,
    *,
    mode: str = "triplet",
    fmt: str = "jpeg",
    quality: int = 90,
    max_triplets: int = MAX_TRIPLETS,
    fps: float = DEFAULT_FPS,
    max_size: Optional[int] = None,
    delete_tar: bool = False,
    progress_file: Optional[str | Path] = None,
    verbose: bool = False,
) -> int:
    """
    Extract frames from a Kinetics-style .tar.gz archive.

    Streams videos out one at a time — never unpacks the full archive to disk.
    Peak extra disk usage: size of one clip (~10–50 MB), not the full tar (~1.7 GB).

    Args:
        tar_path:      Path to the .tar.gz archive.
        output_dir:    Output directory for extracted frames/triplets.
        mode:          "triplet" or "frames".
        fmt:           Output format: "jpeg", "png", or "webp".
        quality:       JPEG/WebP quality.
        max_triplets:  Max triplets per video (triplet mode).
        fps:           Target FPS (frames mode).
        max_size:      Cap longest edge (px).
        delete_tar:    Delete the tar after successful extraction.
        progress_file: Path to progress JSON (for resumable extraction).
        verbose:       Per-video logging.

    Returns:
        Total number of items extracted.
    """
    tar_path   = Path(tar_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if progress_file is None:
        progress_file = output_dir / "extraction_progress.json"
    progress_file = Path(progress_file)

    # Load existing progress
    progress: dict = {"completed_tars": [], "total_items": 0}
    if progress_file.exists():
        try:
            progress = json.loads(progress_file.read_text())
        except Exception:
            pass

    tmp   = Path(tempfile.mkdtemp(prefix="ripd_"))
    total = 0

    try:
        with tarfile.open(tar_path, "r:gz") as tf:
            members = [
                m for m in tf.getmembers()
                if m.isfile() and Path(m.name).suffix.lower() in VIDEO_EXTS
            ]

        if verbose:
            print(f"[ripd] {tar_path.name}: {len(members)} videos")

        with tarfile.open(tar_path, "r:gz") as tf:
            for i, member in enumerate(members, 1):
                vid_tmp = tmp / Path(member.name).name
                try:
                    fobj = tf.extractfile(member)
                    if fobj is None:
                        continue
                    vid_tmp.write_bytes(fobj.read())
                except Exception as e:
                    if verbose:
                        print(f"  [skip] {member.name}: {e}")
                    continue

                try:
                    if mode == "triplet":
                        n = extract_triplets(vid_tmp, output_dir,
                                             max_triplets=max_triplets,
                                             fmt=fmt, quality=quality,
                                             max_size=max_size)
                    else:
                        n = extract_frames(vid_tmp, output_dir,
                                           fps=fps, fmt=fmt, quality=quality,
                                           max_size=max_size)
                    total += n
                except Exception as e:
                    if verbose:
                        print(f"  [skip] {member.name}: {e}")

                try:
                    vid_tmp.unlink()
                except Exception:
                    pass

                if verbose or i % 50 == 0 or i == len(members):
                    print(f"  {i}/{len(members)} | total: {total}")

    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    # Save progress
    progress["completed_tars"].append(tar_path.name)
    progress["total_items"] = progress.get("total_items", 0) + total
    progress_file.write_text(json.dumps(progress, indent=2))

    if delete_tar and tar_path.exists():
        tar_path.unlink()

    return total
