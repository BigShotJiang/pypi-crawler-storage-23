"""
ripd CLI — GPU frame ripper
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ripd",
        description="GPU frame ripper. Kill ffmpeg.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  ripd video.mp4 --output ./frames
  ripd video.mp4 --output ./frames --fps 5 --format png
  ripd video.mp4 --output ./triplets --mode triplet --max_triplets 10
  ripd --url "https://example.com/clip.mp4" --output ./frames
  ripd --videos_dir ./raw --output ./frames --fps 10
  ripd --tars_dir ./kinetics_tars --output ./triplets --mode triplet
""",
    )

    # Input
    src = p.add_mutually_exclusive_group()
    src.add_argument("video", nargs="?", help="Single video file")
    src.add_argument("--url", help="Video URL (requires yt-dlp)")
    src.add_argument("--videos_dir", help="Directory of video files")
    src.add_argument("--tars_dir",   help="Directory of Kinetics .tar.gz files")

    p.add_argument("--output", "-o", required=True, help="Output directory")

    # Mode
    p.add_argument("--mode", choices=["frames", "triplet"], default="frames",
                   help="frames: individual frames at target FPS | triplet: im1/im2/im3 sets (default: frames)")

    # Format
    p.add_argument("--format", "-f", choices=["jpeg", "png", "webp"], default="jpeg")
    p.add_argument("--quality", "-q", type=int, default=90,
                   help="JPEG/WebP quality 1-100 (default: 90)")

    # Resolution
    p.add_argument("--max_size", type=int, default=None,
                   help="Cap longest edge to N pixels (aspect-preserving)")

    # Frames mode
    p.add_argument("--fps", type=float, default=10.0,
                   help="Target extraction FPS for frames mode (default: 10)")

    # Triplet mode
    p.add_argument("--max_triplets", type=int, default=5)
    p.add_argument("--min_gap",      type=int, default=2)
    p.add_argument("--max_gap",      type=int, default=8)

    # Runtime
    p.add_argument("--gpu", type=int, default=0, help="GPU device index (default: 0)")
    p.add_argument("--dry_run", action="store_true", help="Count items without writing")
    p.add_argument("--verbose", "-v", action="store_true")

    return p


def main() -> None:
    args = build_parser().parse_args()

    # Lazy import so CLI help works without CUDA installed
    import ripd
    from ripd.core import set_gpu, download_url, process_kinetics_tar

    set_gpu(args.gpu)
    output = Path(args.output)

    # ── URL ──────────────────────────────────────────────────────────────────
    if args.url:
        import tempfile, shutil
        tmp = Path(tempfile.mkdtemp(prefix="ripd_"))
        try:
            print(f"[ripd] Downloading {args.url}")
            video_path = download_url(args.url, tmp)
            _process_single(video_path, output, args)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        return

    # ── Single file ───────────────────────────────────────────────────────────
    if args.video:
        vp = Path(args.video)
        if not vp.exists():
            print(f"[ripd] Not found: {args.video}", file=sys.stderr)
            sys.exit(1)
        _process_single(vp, output, args)
        return

    # ── Video directory ───────────────────────────────────────────────────────
    if args.videos_dir:
        from ripd.core import VIDEO_EXTS
        vdir   = Path(args.videos_dir)
        videos = sorted(v for v in vdir.rglob("*") if v.suffix.lower() in VIDEO_EXTS)
        print(f"[ripd] {len(videos)} videos found in {vdir}")
        total = 0
        for i, vp in enumerate(videos, 1):
            n = _process_single(vp, output, args, silent=not args.verbose)
            total += n
            if args.verbose or i % 50 == 0 or i == len(videos):
                print(f"  {i}/{len(videos)} | {vp.name} → {n}  (total: {total})")
        print(f"\n[ripd] Done. {total} items → {output}")
        return

    # ── Kinetics tars ─────────────────────────────────────────────────────────
    if args.tars_dir:
        from ripd.core import VIDEO_EXTS
        tars_dir = Path(args.tars_dir)
        tars     = sorted(tars_dir.glob("*.tar.gz"))
        if not tars:
            print(f"[ripd] No .tar.gz files found in {tars_dir}", file=sys.stderr)
            sys.exit(1)
        print(f"[ripd] {len(tars)} tars found")
        total = 0
        for tar in tars:
            n = process_kinetics_tar(
                tar, output,
                mode=args.mode,
                fmt=args.format,
                quality=args.quality,
                max_triplets=args.max_triplets,
                fps=args.fps,
                max_size=args.max_size,
                verbose=args.verbose,
            )
            total += n
            print(f"  {tar.name} → {n}  (total: {total})")
        print(f"\n[ripd] Done. {total} items → {output}")
        return

    build_parser().print_help()
    sys.exit(1)


def _process_single(video_path: Path, output: Path, args, silent: bool = False) -> int:
    import ripd
    if args.mode == "triplet":
        n = ripd.extract_triplets(
            video_path, output,
            max_triplets=args.max_triplets,
            min_gap=args.min_gap,
            max_gap=args.max_gap,
            fmt=args.format,
            quality=args.quality,
            max_size=args.max_size,
            dry_run=args.dry_run,
        )
    else:
        n = ripd.extract_frames(
            video_path, output,
            fps=args.fps,
            fmt=args.format,
            quality=args.quality,
            max_size=args.max_size,
            dry_run=args.dry_run,
        )
    if not silent:
        tag = "[dry run] " if args.dry_run else ""
        print(f"[ripd] {tag}{video_path.name} → {n} items → {output}")
    return n


if __name__ == "__main__":
    main()
