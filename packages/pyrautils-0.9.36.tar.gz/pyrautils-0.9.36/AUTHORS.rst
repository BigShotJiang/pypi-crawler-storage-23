=======
Authors
=======

PyraUtils 是由以下贡献者共同开发和维护的。

项目负责人
----------

* PyraUtils <ops@920430.com>

贡献者
------

感谢所有为项目做出贡献的开发者！

贡献列表
--------

.. list-table::
   :header-rows: 1

   * - 贡献者
     - 邮箱
     - 主要贡献
   * - PyraUtils
     - ops@920430.com
     - 项目创建与维护

如何成为贡献者
--------------

我们欢迎任何形式的贡献！您可以通过以下方式参与：

1. **提交 Bug 报告** - 在 GitHub Issues 中报告问题
2. **提交功能建议** - 提出新功能或改进建议
3. **提交代码** - 通过 Pull Request 贡献代码
4. **完善文档** - 帮助改进项目文档
5. **翻译** - 帮助翻译文档到其他语言

请查看 `CONTRIBUTING.rst`_ 了解详细的贡献指南。

.. _CONTRIBUTING.rst: CONTRIBUTING.rst

致谢
----

感谢以下开源项目，PyraUtils 的开发离不开它们：

* `loguru`_ - 简单易用的日志库
* `httpx`_ - 现代化的 HTTP 客户端
* `authlib`_ - OAuth 和 JWT 认证库
* `cryptography`_ - 密码学工具包
* `sqlalchemy`_ - Python SQL 工具包

.. _loguru: https://github.com/Delgan/loguru
.. _httpx: https://www.python-httpx.org/
.. _authlib: https://authlib.org/
.. _cryptography: https://cryptography.io/
.. _sqlalchemy: https://www.sqlalchemy.org/
