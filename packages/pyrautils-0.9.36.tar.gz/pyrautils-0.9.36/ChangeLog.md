# 更新日志

所有重要的更改都将记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [0.9.36] - 2026-02-28

### 新增
- 统一日志模块，所有模块使用 `LoguruHandler` 进行日志输出
- 完善测试用例，测试覆盖率大幅提升
- 添加 `setup.cfg` 完整配置，支持多种开发工具
- 完善 `README.rst`、`AUTHORS.rst`、`CONTRIBUTING.rst` 文档

### 修复
- 修复 JWT 过期验证失败的问题
- 修复文件压缩解压模块中 gz 和 7z 格式的处理问题
- 修复 `tarfile.extractall` 的 filter 参数兼容性问题
- 修复证书测试中的 mock 问题
- 修复企业微信 `WXBizMsgCrypt` 的编码问题

### 变更
- 日志实例从函数级/实例级提升为模块级/类级
- 优化异常处理，使用 `raise ... from ...` 保留原始异常堆栈
- 依赖版本使用 `>=` 替代 `==`，允许版本升级

## [0.9.34] - 2024-XX-XX

### 变更
- 优化 DB 类: `_sqlalchemy.py` 和 `_sqlite3.py`
- 企业微信接口支持白名单返回

## [0.9.33] - 2024-XX-XX

### 新增
- 企业微信调用类支持 `jsapi_ticket` 的返回

## [0.9.32] - 2024-XX-XX

### 变更
- Python PyPI 打包脚本更新
- Python 版本支持 3.12

## [0.9.31] - 2024-XX-XX

### 变更
- 使用 authlib 代替 pyjwt

### 新增
- OAuth2.0 支持

## [0.9.30] - 2024-XX-XX

### 变更
- 优化 DB 类: `_sqlalchemy.py` 和 `_sqlite3.py`

## [0.9.24] - 2024-XX-XX

### 新增
- 企业微信调用类支持

## [0.9.7] - 2024-XX-XX

### 新增
- 新增对压缩文件例如：zip/gz/7z 等的支持

## [0.9.6] - 2024-XX-XX

### 变更
- 兼容 Python 版本，3.8.2 -> 3.10.6
- 对旧有的函数进行拆分和重构，增加注释
- 弃用 pipenv 作为虚拟环境管理工具，改成原生的 venv

## [0.9.2] - 2024-XX-XX

### 变更
- 升级 Python 版本，3.9.2 -> 3.10.6
- 大版本更新，主要的几个函数类都进行了优化

### 新增
- 新增测试用例（未完善）

## [0.8.0] - 2024-XX-XX

### 变更
- 升级 Python 版本，3.8.9 -> 3.9
- 完善 sqlite3 的封装，限制 sqlite3 在 fetchmany 的时候默认一次性取 10 条数据

### 新增
- 新增密码相关的封装 `password.py`，具备随机密码和检查弱密码的功能

### 修复
- Bugs 修复

## [0.7.0] - 2024-XX-XX

### 修复
- Bugs 修复

## [0.6.0] - 2024-XX-XX

### 修复
- Bugs 修复

## [0.5.0] - 2024-XX-XX

### 变更
- 代码优化
- 文件重命名，避免模块冲突

## [0.1.0] - 2024-XX-XX

### 新增
- 初始化项目

---

[0.9.36]: https://github.com/yourusername/PyraUtils/compare/v0.9.34...v0.9.36
[0.9.34]: https://github.com/yourusername/PyraUtils/compare/v0.9.33...v0.9.34
[0.9.33]: https://github.com/yourusername/PyraUtils/compare/v0.9.32...v0.9.33
[0.9.32]: https://github.com/yourusername/PyraUtils/compare/v0.9.31...v0.9.32
[0.9.31]: https://github.com/yourusername/PyraUtils/compare/v0.9.30...v0.9.31
[0.9.30]: https://github.com/yourusername/PyraUtils/compare/v0.9.24...v0.9.30
[0.9.24]: https://github.com/yourusername/PyraUtils/compare/v0.9.7...v0.9.24
[0.9.7]: https://github.com/yourusername/PyraUtils/compare/v0.9.6...v0.9.7
[0.9.6]: https://github.com/yourusername/PyraUtils/compare/v0.9.2...v0.9.6
[0.9.2]: https://github.com/yourusername/PyraUtils/compare/v0.8.0...v0.9.2
[0.8.0]: https://github.com/yourusername/PyraUtils/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/yourusername/PyraUtils/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/yourusername/PyraUtils/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/yourusername/PyraUtils/compare/v0.1.0...v0.5.0
[0.1.0]: https://github.com/yourusername/PyraUtils/releases/tag/v0.1.0
