.. highlight:: shell

============
贡献指南
============

欢迎贡献！每一个贡献都非常有价值，我们会永远铭记贡献者的名字。

您可以通过多种方式为 PyraUtils 做出贡献：

贡献类型
--------

报告 Bug
~~~~~~~~

在 https://github.com/yourusername/PyraUtils/issues 报告 Bug。

报告 Bug 时，请包含以下信息：

* 操作系统名称和版本
* Python 版本
* 本地环境配置（如有帮助）
* 详细的复现步骤
* 预期行为和实际行为
* 相关的错误日志或截图

修复 Bug
~~~~~~~~

在 GitHub Issues 中查找标记为 "bug" 和 "help wanted" 的问题，尝试修复它们。

实现新功能
~~~~~~~~~~

在 GitHub Issues 中查找标记为 "enhancement" 和 "help wanted" 的问题，实现新功能。

完善文档
~~~~~~~~

文档改进包括：

* 修复拼写错误或语法错误
* 添加缺失的文档
* 改进代码示例
* 翻译文档

提交反馈
~~~~~~~~

在 https://github.com/yourusername/PyraUtils/issues 提交反馈。

如果您提议新功能：

* 详细说明功能如何工作
* 尽量缩小范围，便于实现
* 记住这是一个志愿者驱动的项目

快速开始
--------

1. Fork 仓库
~~~~~~~~~~~~~

在 GitHub 上 Fork `PyraUtils` 仓库。

2. 克隆到本地
~~~~~~~~~~~~~

::

    $ git clone git@github.com:your_username/PyraUtils.git
    $ cd PyraUtils

3. 创建虚拟环境
~~~~~~~~~~~~~~~

使用 venv::

    $ python -m venv .venv
    $ source .venv/bin/activate  # Linux/macOS
    $ .venv\Scripts\activate     # Windows

或使用 pipenv::

    $ pipenv shell

4. 安装开发依赖
~~~~~~~~~~~~~~~

::

    $ pip install -e ".[dev]"

5. 创建分支
~~~~~~~~~~~

::

    $ git checkout -b feature/your-feature-name
    # 或
    $ git checkout -b fix/your-bug-fix

6. 进行修改
~~~~~~~~~~~

编写代码并确保：

* 遵循项目的代码风格
* 添加必要的测试
* 更新相关文档
* 添加类型注解

7. 运行测试
~~~~~~~~~~~

::

    $ pytest

    # 带覆盖率报告
    $ pytest --cov=PyraUtils --cov-report=html

8. 代码检查
~~~~~~~~~~~

::

    $ flake8 PyraUtils tests
    $ black --check PyraUtils tests
    $ isort --check-only PyraUtils tests
    $ mypy PyraUtils

9. 提交更改
~~~~~~~~~~~

::

    $ git add .
    $ git commit -m "feat: 添加新功能描述"
    $ git push origin feature/your-feature-name

提交信息格式
~~~~~~~~~~~~

使用约定式提交格式：

* ``feat:`` 新功能
* ``fix:`` Bug 修复
* ``docs:`` 文档更新
* ``style:`` 代码格式调整
* ``refactor:`` 代码重构
* ``test:`` 测试相关
* ``chore:`` 构建/工具相关

示例::

    feat: 添加异步 HTTP 请求支持
    fix: 修复 JWT 过期验证问题
    docs: 更新安装指南

10. 提交 Pull Request
~~~~~~~~~~~~~~~~~~~~~

通过 GitHub 网站提交 Pull Request。

Pull Request 指南
-----------------

提交 PR 前，请确保：

1. **测试通过** - 所有测试必须通过

   ::

       $ pytest

2. **代码风格** - 通过 flake8 和 black 检查

   ::

       $ flake8 PyraUtils tests
       $ black --check PyraUtils tests

3. **测试覆盖** - 新代码需要有对应的测试

4. **文档更新** - 新功能需要更新文档

5. **兼容性** - 支持 Python 3.8+

代码风格
--------

* 遵循 PEP 8 规范
* 使用 4 空格缩进
* 最大行长度 120 字符
* 使用类型注解
* 编写文档字符串

示例::

    def get_user(user_id: int) -> dict:
        """
        获取用户信息。

        :param user_id: 用户ID
        :type user_id: int
        :return: 用户信息字典
        :rtype: dict
        """
        return {"id": user_id, "name": "test"}

项目结构
--------

::

    PyraUtils/
    ├── PyraUtils/           # 源代码
    │   ├── common/          # 通用工具
    │   ├── db/              # 数据库
    │   ├── http/            # HTTP 相关
    │   ├── log/             # 日志
    │   ├── network/         # 网络工具
    │   ├── password/        # 密码处理
    │   ├── service/         # 第三方服务
    │   └── signature/       # 签名
    ├── tests/               # 测试用例
    ├── docs/                # 文档
    └── setup.py             # 安装配置

发布流程
--------

维护者发布指南：

1. 更新版本号和 CHANGELOG

2. 构建发布包

   ::

       $ python -m build

3. 上传到 PyPI

   ::

       $ twine upload dist/*

4. 创建 Git 标签

   ::

       $ git tag -a v0.9.36 -m "Release v0.9.36"
       $ git push --tags

获取帮助
--------

* 查看 `README.rst`_
* 在 GitHub Issues 提问
* 发送邮件至 ops@920430.com

.. _README.rst: README.rst

感谢您的贡献！
