import httpx
import json
from typing import Dict, Any, Tuple, Optional
from PyraUtils.log import LoguruHandler

class AbstractApi(object) :
    def __init__(self, max_retries: int = 3, retry_interval: float = 1.0, timeout: float = 30.0):
        """
        初始化抽象API
        
        :param max_retries: 最大重试次数
        :param retry_interval: 重试间隔时间（秒）
        :param timeout: 请求超时时间（秒）
        """
        self.max_retries = max_retries
        self.retry_interval = retry_interval
        self.timeout = timeout
        self.logger = LoguruHandler()

    def getAccessToken(self):
        """获取访问令牌"""
        raise NotImplementedError

    def refreshAccessToken(self):
        """刷新访问令牌"""
        raise NotImplementedError

    def getSuiteAccessToken(self):
        """获取套件访问令牌"""
        raise NotImplementedError

    def refreshSuiteAccessToken(self):
        """刷新套件访问令牌"""
        raise NotImplementedError

    def getProviderAccessToken(self):
        """获取提供者访问令牌"""
        raise NotImplementedError

    def refreshProviderAccessToken(self):
        """刷新提供者访问令牌"""
        raise NotImplementedError

    @staticmethod
    def __tokenExpired(errCode):
        """检查令牌是否过期

        40014: 通常表示“access_token 无效”。
        42001: 通常表示“access_token 已过期”。
        42007: 通常表示“jsapi_ticket 已过期”。
        42009: 通常表示“api_ticket 已过期”。
        """
        return errCode in [40014, 42001, 42007, 42009]

    def __refreshToken(self, url):
        """刷新令牌"""
        if 'SUITE_ACCESS_TOKEN' in url:
            self.logger.info("刷新套件访问令牌")
            self.refreshSuiteAccessToken()
        elif 'PROVIDER_ACCESS_TOKEN' in url:
            self.logger.info("刷新提供者访问令牌")
            self.refreshProviderAccessToken()
        elif 'ACCESS_TOKEN' in url:
            self.logger.info("刷新普通访问令牌")
            self.refreshAccessToken()

    @staticmethod
    def __checkResponse(response):
        """
        检查响应结果
        :param response: 请求返回结果
        :return: 响应结果
        """
        err_code = response.get('errcode')
        err_msg = response.get('errmsg')

        if err_code == 0:
            return response
        else:
            raise RuntimeError(f"API error: {err_code} - {err_msg}")

    def httpCall(self, urlType: Tuple, params: dict, req_body: Any = None, **kwargs) -> json:
        """
        调用HTTP接口
        :param urlType: 请求地址类型; [请求地址, 请求方法]
        :param params: 请求参数;
        :param req_body: 请求体
        :param kwargs: 其他参数
        :return: json
        """
        url, method = urlType
        response = {}
        retry_cnt = 0

        while retry_cnt < self.max_retries:
            try:
                self.logger.info(f"[{method}] 请求: {url}, params: {params}")
                if req_body:
                    self.logger.debug(f"请求体: {req_body}")
                
                if method == 'POST' and req_body is not None:
                    response = self.__httpPost(url, params, req_body, **kwargs)
                elif method == 'GET':
                    response = self.__httpGet(url, params, **kwargs)
                
                self.logger.debug(f"响应: {response}")
                
                err_code = response.get('errcode')
                if self.__tokenExpired(err_code):
                    self.logger.warning(f"令牌过期，错误码: {err_code}，开始刷新令牌")
                    self.__refreshToken(url)
                    retry_cnt += 1
                    self.logger.info(f"第 {retry_cnt} 次重试")
                    continue
                break
            except Exception as e:
                self.logger.error(f"请求异常: {e}")
                retry_cnt += 1
                if retry_cnt < self.max_retries:
                    import time
                    time.sleep(self.retry_interval)
                    self.logger.info(f"第 {retry_cnt} 次重试")
                else:
                    raise

        return self.__checkResponse(response)

    def __httpPost(self, url: str, params: dict, req_body: Any, **kwargs) -> json:
        """
        发送POST请求
        :param url: 请求地址
        :param params: 请求参数
        :param req_body: 请求体
        :param kwargs: 其他参数
        :return: json
        """
        try:
            response_data = httpx.post(
                url, 
                params=params, 
                json=req_body, 
                timeout=self.timeout, 
                **kwargs
            )
            response_data.raise_for_status()
            return response_data.json()
        except httpx.RequestError as err:
            self.logger.error(f"POST请求错误: {err}")
            raise RuntimeError(f"Request error: {err}") from err

    def __httpGet(self, url: str, params: dict, **kwargs) -> json:
        """
        发送GET请求
        :param url: 请求地址
        :param params: 请求参数
        :param kwargs: 其他参数
        :return: json
        """
        try:
            response_data = httpx.get(
                url, 
                params=params, 
                timeout=self.timeout, 
                **kwargs
            )
            response_data.raise_for_status()
            return response_data.json()
        except httpx.RequestError as err:
            self.logger.error(f"GET请求错误: {err}")
            raise RuntimeError(f"Request error: {err}") from err

    def __httpPostFile(self, url: str, media_file) -> Dict[str, Any]:
        """
        发送的附件
        :param url: 请求地址
        :param media_file: 附件文件
        :return: json
        """
        try:
            response_data = httpx.post(
                url, 
                files={'file': media_file}, 
                timeout=self.timeout
            )
            response_data.raise_for_status()
            return response_data.json()
        except httpx.RequestError as err:
            self.logger.error(f"文件上传错误: {err}")
            raise RuntimeError(f"Request error: {err}") from err
