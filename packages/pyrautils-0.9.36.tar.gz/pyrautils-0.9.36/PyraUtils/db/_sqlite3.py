"""
created by：2018-2-23 14:15:57
modify by: 2023-05-13 15:05:05

功能：sqlite3的方法函数的封装。
"""

import sqlite3
from typing import Dict, List, Optional, Any, Tuple
from ..log.logger._loguru import LoguruHandler

logger = LoguruHandler()


def handle_db_operations(func):
    """
    数据库操作装饰器，统一处理数据库异常。
    
    :param func: 被装饰的数据库操作函数
    :type func: callable
    :return: 装饰后的函数
    :rtype: callable
    :raises sqlite3.DatabaseError: 如果数据库操作失败
    """
    def wrapper(*args, **kwargs):
        try:
            result = func(*args, **kwargs)
            return result
        except sqlite3.DatabaseError as e:
            logger.error(f"Database error during {func.__name__}: {e}")
            raise
    return wrapper



class SQLite3Util:
    """
    SQLite3 数据库操作工具类，提供便捷的数据库操作方法。
    
    示例用法：
    >>> with SQLite3Util('my.db') as db:
    >>>     result = db.query('SELECT * FROM users WHERE age > ?', (18,))
    >>>     for row in result:
    >>>         print(row['username'], row['age'])
    
    支持上下文管理器，自动管理连接和事务。
    """

    def __init__(self, dbfile: Optional[str] = None):
        """
        初始化 SQLite3 数据库连接。
        
        :param dbfile: 数据库文件路径，如果为 None 或空字符串，使用内存数据库
        :type dbfile: Optional[str]
        """
        db_path = dbfile or ':memory:'
        logger.info(f"Connecting to SQLite3 database: {db_path}")
        self.db = sqlite3.connect(db_path)
        self.db.row_factory = sqlite3.Row
        self.c = self.db.cursor()
        logger.info("SQLite3 connection established")

    @handle_db_operations
    def query(self, sql: str, params: Optional[Tuple[Any, ...]] = None) -> List[sqlite3.Row]:
        """
        执行查询操作，返回所有结果。
        
        :param sql: SQL 查询语句
        :type sql: str
        :param params: SQL 参数，用于防止 SQL 注入
        :type params: Optional[Tuple[Any, ...]]
        :return: 查询结果列表，每个元素是 sqlite3.Row 对象
        :rtype: List[sqlite3.Row]
        :raises sqlite3.DatabaseError: 如果查询失败
        """
        logger.info(f"Executing query: {sql}")
        if params:
            logger.debug(f"Query parameters: {params}")
        
        with self.db:
            self.c.execute(sql, params or ())
            result = self.c.fetchall()
            logger.info(f"Query executed successfully, {len(result)} rows returned")
            return result

    @handle_db_operations
    def insert(self, table: str, data: Dict[str, Any]) -> int:
        """
        执行插入操作，返回自动生成的 ID 号。
        
        :param table: 表名
        :type table: str
        :param data: 要插入的数据，键为字段名，值为字段值
        :type data: Dict[str, Any]
        :return: 自动生成的 ID 号（如果表有 AUTOINCREMENT 字段）
        :rtype: int
        :raises sqlite3.DatabaseError: 如果插入失败
        """
        logger.info(f"Inserting data into table: {table}")
        logger.debug(f"Insert data: {data}")
        
        fields = ','.join(data.keys())
        values = tuple(data.values())
        placeholders = ','.join(['?'] * len(data))
        sql = f'INSERT INTO {table} ({fields}) VALUES ({placeholders})'

        with self.db:
            self.c.execute(sql, values)
            lastrowid = self.c.lastrowid
            logger.info(f"Insert successful, last row ID: {lastrowid}")
            return lastrowid

    @handle_db_operations
    def select(self, table: str, fields: str = '*', condition: str = '', 
               params: Optional[Tuple[Any, ...]] = None) -> List[sqlite3.Row]:
        """
        执行查询操作，并使用 Row 创建可迭代的行对象。
        
        :param table: 表名
        :type table: str
        :param fields: 要查询的字段，默认为 '*'（所有字段）
        :type fields: str
        :param condition: 查询条件，不需要包含 'WHERE' 关键字
        :type condition: str
        :param params: SQL 参数，用于防止 SQL 注入
        :type params: Optional[Tuple[Any, ...]]
        :return: 查询结果列表，每个元素是 sqlite3.Row 对象
        :rtype: List[sqlite3.Row]
        :raises sqlite3.DatabaseError: 如果查询失败
        """
        sql = f'SELECT {fields} FROM {table}'
        if condition:
            sql += f' WHERE {condition}'
        
        logger.info(f"Executing select: {sql}")
        if params:
            logger.debug(f"Select parameters: {params}")

        with self.db:
            self.c.execute(sql, params or ())
            result = self.c.fetchall()
            logger.info(f"Select executed successfully, {len(result)} rows returned")
            return result

    @handle_db_operations
    def execute(self, sql: str, params: Optional[Any] = None, many: bool = False) -> bool:
        """
        执行任意 SQL 语句，返回是否修改了数据。
        
        :param sql: SQL 语句
        :type sql: str
        :param params: SQL 参数，用于防止 SQL 注入
                      如果 many 为 True，params 应该是参数列表
        :type params: Optional[Any]
        :param many: 是否执行多条 SQL 语句
        :type many: bool
        :return: 是否修改了数据
        :rtype: bool
        :raises sqlite3.DatabaseError: 如果执行失败
        """
        logger.info(f"Executing SQL: {sql}")
        if params:
            logger.debug(f"SQL parameters: {params}")

        with self.db:
            if many:
                self.c.executemany(sql, params or [])
            else:
                self.c.execute(sql, params or ())
            changes = self.db.total_changes
            logger.info(f"SQL executed successfully, {changes} changes made")
            return changes > 0

    def __enter__(self):
        """
        上下文管理器进入方法。
        
        :return: SQLite3Util 对象
        :rtype: SQLite3Util
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        上下文管理器退出方法，自动管理事务和连接关闭。
        
        :param exc_type: 异常类型
        :param exc_val: 异常值
        :param exc_tb: 异常追踪信息
        """
        if exc_type:
            self.db.rollback()
            logger.error(f"Exception has been handled and the transaction is rollbacked: {exc_val}")
        else:
            self.db.commit()
        self.c.close()
        self.db.close()
