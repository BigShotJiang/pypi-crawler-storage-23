"""
created by: 2023-05-13 15:05:05

功能：SQLAlchemy 数据库操作工具类，提供原生 SQL 执行和 ORM 操作。
"""

from contextlib import contextmanager
from typing import Any, Dict, List, Optional, Tuple, Type, Union
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.exc import SQLAlchemyError, DatabaseError
from sqlalchemy.engine.result import Result

from ..log.logger._loguru import LoguruHandler

logger = LoguruHandler()


class DBManager:
    """
    SQLAlchemy 原生 SQL 执行工具类，提供便捷的 SQL 语句执行方法。
    
    示例用法：
    >>> db_manager = DBManager('mysql+pymysql://root:123456@localhost:3306/test?charset=utf8')
    >>> # 执行建表语句
    >>> db_manager.execute('create table if not EXISTS user (id int PRIMARY KEY auto_increment, name char(32), age int);')
    >>> # 执行插入语句
    >>> db_manager.execute("INSERT INTO users (name, age) VALUES (:name, :age)", {'name': 'Alice', 'age': 30})
    >>> # 执行查询语句
    >>> result = db_manager.execute('select * from user;')
    >>> print(result.fetchall())
    """
    
    def __init__(self, db_url: str):
        """
        初始化数据库连接。
        
        :param db_url: 数据库连接 URL
        :type db_url: str
        
        连接 URL 格式示例：
        - MySQL: mysql+pymysql://root:password@localhost:3306/database_name?charset=utf8
        - SQLite: sqlite:///database.db
        - PostgreSQL: postgresql://user:password@localhost/database_name
        """
        # 创建连接引擎
        logger.info(f"Connecting to database: {db_url}")
        self.engine = create_engine(db_url)
        # 创建会话类
        self.Session = sessionmaker(bind=self.engine)
        logger.info("Database connection established")
    
    def execute(self, sql: Union[str, Tuple[str, Dict[str, Any]]], params: Optional[Dict[str, Any]] = None) -> Optional[Result]:
        """
        执行 SQL 语句。
        
        :param sql: SQL 语句字符串，或 (SQL 语句, 参数) 元组
        :type sql: Union[str, Tuple[str, Dict[str, Any]]]
        :param params: SQL 参数，用于防止 SQL 注入
        :type params: Optional[Dict[str, Any]]
        :return: 查询结果对象，如果执行失败返回 None
        :rtype: Optional[Result]
        :raises SQLAlchemyError: 如果 SQL 执行过程中发生错误
        """
        # 处理元组形式的 SQL 和参数
        if isinstance(sql, tuple) and len(sql) == 2:
            sql, params = sql
        
        logger.info(f"Executing SQL: {sql}")
        if params:
            logger.debug(f"SQL parameters: {params}")
        
        try:
            # 创建会话对象
            with self.Session() as session:
                if params:
                    result = session.execute(sql, params)
                else:
                    result = session.execute(sql)
                session.commit()  # 提交事务
                logger.info("SQL execution successful")
                return result
        except SQLAlchemyError as e:
            logger.warning(f"SQL execution error: {e}")
            return None


# 创建基类，所有的模型类都继承自此类
Base = declarative_base()


class ORMManager:
    """
    SQLAlchemy ORM 操作工具类，提供对象关系映射的便捷操作方法。
    
    示例用法：
    >>> from sqlalchemy import Column, Integer, String
    >>> 
    >>> # 定义映射类
    >>> class User(Base):
    >>>     __tablename__ = 'user'  # 表名
    >>>     id = Column(Integer, primary_key=True)  # 主键
    >>>     name = Column(String(20))  # 姓名
    >>>     age = Column(Integer)  # 年龄
    >>> 
    >>> # 创建 ORM 管理器实例
    >>> orm_manager = ORMManager('mysql+pymysql://root:123456@localhost:3306/test?charset=utf8')
    >>> # 创建所有表
    >>> orm_manager.create_tables()
    >>> # 添加用户
    >>> user1 = User(name='Alice', age=18)
    >>> orm_manager.add(user1)
    >>> # 查询用户
    >>> result = orm_manager.query(User, name='Alice')
    >>> for user in result:
    >>>     print(user.name, user.age)
    >>> # 更新用户
    >>> orm_manager.update(User, condition={'name': 'Alice'}, age=19)
    >>> # 删除用户
    >>> orm_manager.delete(User, name='Alice')
    """
    
    def __init__(self, db_url: str):
        """
        初始化 ORM 管理器。
        
        :param db_url: 数据库连接 URL
        :type db_url: str
        
        连接 URL 格式示例：
        - MySQL: mysql+pymysql://root:password@localhost:3306/database_name?charset=utf8
        - SQLite: sqlite:///database.db
        - PostgreSQL: postgresql://user:password@localhost/database_name
        """
        # 创建连接引擎
        logger.info(f"Connecting to database for ORM: {db_url}")
        self.engine = create_engine(db_url)
        # 创建会话类
        self.Session = sessionmaker(bind=self.engine)
        logger.info("ORM manager initialized")
    
    def create_tables(self) -> None:
        """
        创建所有继承自 Base 的表。
        
        注意：此方法应该在应用启动时手动调用一次。
        """
        logger.info("Creating database tables")
        Base.metadata.create_all(self.engine)
        logger.info("Database tables created successfully")

    @contextmanager
    def session_scope(self) -> Session:
        """
        提供事务范围的上下文管理器。
        
        在上下文中执行的所有操作将在退出时自动提交，如果发生异常则回滚。
        
        :return: SQLAlchemy Session 对象
        :rtype: Session
        :raises RuntimeError: 如果操作失败并需要回滚
        """
        session = self.Session()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Session rollback due to exception: {e}")
            raise RuntimeError(f"Session rollback because of exception: {e}")
        finally:
            session.close()

    def add(self, obj: Any) -> None:
        """
        添加对象到数据库。
        
        :param obj: 要添加的 ORM 对象
        :type obj: Any
        """
        with self.session_scope() as session:
            session.add(obj)
            logger.info(f"Added object: {obj}")
    
    def query(self, cls: Type[Base], **kwargs) -> List[Any]:
        """
        查询数据库中的对象。
        
        :param cls: ORM 模型类
        :type cls: Type[Base]
        :param kwargs: 查询条件，键为字段名，值为字段值
        :return: 查询结果列表
        :rtype: List[Any]
        """
        with self.session_scope() as session:
            result = session.query(cls).filter_by(**kwargs).all()
            logger.info(f"Queried {len(result)} objects of type {cls.__name__}")
            return result
    
    def update(self, cls: Type[Base], condition: Dict[str, Any], **kwargs) -> None:
        """
        更新数据库中的对象。
        
        :param cls: ORM 模型类
        :type cls: Type[Base]
        :param condition: 更新条件，键为字段名，值为字段值
        :type condition: Dict[str, Any]
        :param kwargs: 要更新的字段和值
        """
        with self.session_scope() as session:
            obj = session.query(cls).filter_by(**condition).first()
            if obj:
                for key, value in kwargs.items():
                    setattr(obj, key, value)
                logger.info(f"Updated object: {obj}")
            else:
                logger.warning(f"No {cls.__name__} object found with condition: {condition}")

    def delete(self, cls: Type[Base], **kwargs) -> None:
        """
        删除数据库中的对象。
        
        :param cls: ORM 模型类
        :type cls: Type[Base]
        :param kwargs: 删除条件，键为字段名，值为字段值
        """
        with self.session_scope() as session:
            obj = session.query(cls).filter_by(**kwargs).first()
            if obj:
                session.delete(obj)
                logger.info(f"Deleted object: {obj}")
            else:
                logger.warning(f"No {cls.__name__} object found with condition: {kwargs}")