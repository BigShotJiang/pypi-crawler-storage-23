#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by: 2024-03-18
modify by: 2024-03-18

功能：提供 HMAC 签名和验证功能的工具类。
"""

import hmac
from typing import Optional, Union, bytes, bytearray, memoryview
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class HmacUtil:
    """
    HMAC 工具类，提供 HMAC 签名生成和安全验证功能。
    
    示例用法：
    >>> from PyraUtils.signature._hmac import HmacUtil
    >>> 
    >>> # 生成 HMAC 签名
    >>> secret_key = b'secret_key_123'
    >>> message = b'Hello, World!'
    >>> signature = HmacUtil.sign(secret_key, message, digestmod='sha256')
    >>> print(f"HMAC 签名: {signature.decode('utf-8')}")
    >>> 
    >>> # 验证 HMAC 签名
    >>> is_valid = HmacUtil.verify(signature, signature)
    >>> print(f"签名验证结果: {is_valid}")
    """
    
    @staticmethod
    def sign(key: Union[bytes, bytearray], msg: Optional[Union[bytes, bytearray, memoryview]] = None, 
            digestmod: str = 'sha256') -> bytes:
        """
        使用指定的哈希算法创建一个 HMAC 签名。

        :param key: 密钥，用于 HMAC 算法的密钥。必须是 bytes 或 bytearray 类型。
        :param msg: 要签名的消息，如果提供了该参数，则必须是 bytes、bytearray 或者 memoryview 类型。默认为 None。
        :param digestmod: 指定用于 HMAC 的哈希算法名称的字符串，默认为 'sha256'。
                        支持 hashlib 支持的所有算法，以及 OpenSSL 库可能提供的其他算法。
                        常见的哈希算法包括但不限于：
                        'md5', 'sha1', 'sha224', 'sha256', 'sha384', 'sha512',
                        'blake2b', 'blake2s',
                        'sha3_224', 'sha3_256', 'sha3_384', 'sha3_512',
                        'shake_128', 'shake_256'。
        :type key: Union[bytes, bytearray]
        :type msg: Optional[Union[bytes, bytearray, memoryview]]
        :type digestmod: str
        :return: 签名结果的十六进制字符串形式，经过 utf-8 编码转换为 bytes 对象。
        :rtype: bytes
        :raises ValueError: 如果密钥或消息类型不正确，或者哈希算法无效。

        HMAC 签名用于数据认证，确保数据在传输或存储过程中未被篡改。选择合适的哈希算法可以根据安全需求和性能要求进行权衡。

        注意：hashlib 的构造器（例如 hashlib.sha256()）通常比对应的 new() 方法（例如 hashlib.new('sha256')）
            更快，因此当可用时应优先使用。
        """
        logger.info(f"开始生成 HMAC 签名，算法: {digestmod}")
        if not isinstance(key, (bytes, bytearray)):
            logger.error("密钥必须是 bytes 或 bytearray 类型")
            raise ValueError("Key must be bytes or bytearray.")
        
        if msg is not None and not isinstance(msg, (bytes, bytearray, memoryview)):
            logger.error("消息必须是 bytes、bytearray 或 memoryview 类型")
            raise ValueError("Message must be bytes, bytearray, or memoryview if provided.")
        
        try:
            # 使用 hmac 模块和指定的哈希方法来创建新的 HMAC 对象
            h = hmac.new(key, msg=msg, digestmod=digestmod)
            
            # 返回十六进制表示的 HMAC 签名，并转换成 bytes 类型
            result = h.hexdigest().encode('utf-8')
            logger.info("HMAC 签名生成成功")
            return result
        except ValueError as e:
            logger.error(f"无效的哈希算法: {digestmod}")
            raise ValueError(f"Invalid digest mode: {digestmod}. Please check the supported algorithms.")

    @staticmethod
    def verify(a: Union[bytes, str], b: Union[bytes, str]) -> bool:
        """
        安全地比较两个 HMAC 摘要值是否相等。

        :param a: 第一个比较值，可为 bytes 或 ASCII 字符串（如 hashlib 的 hexdigest() 结果）
        :param b: 第二个比较值，类型必须与 a 相同
        :type a: Union[bytes, str]
        :type b: Union[bytes, str]
        :return: 布尔值，如果两个值相等返回 True，否则返回 False
        :rtype: bool
        :raises ValueError: 如果输入参数类型不正确。
        :raises TypeError: 如果比较过程中发生类型错误。

        使用 hmac 模块的 compare_digest 函数来进行比较防止定时攻击。这是因为 compare_digest 设计上
        会以恒定时间运行，不管输入值的大小或内容。这种方法能有效降低通过时间分析差异来猜测信息的可能性，
        从而提高安全性。
        
        对于比较敏感数据（如密码、密钥等）时，应该使用本函数而非简单的 == 运算符，
        因为 == 运算符可能引入基于内容的短路行为，增加信息泄露风险。
        """
        logger.info("开始验证 HMAC 签名")
        if not (isinstance(a, (bytes, str)) and isinstance(b, (bytes, str))):
            logger.error("a 和 b 都必须是 bytes 或 ASCII 字符串类型")
            raise ValueError("Both a and b must be bytes or ASCII strings.")

        try:
            # 使用 hmac 模块中的 compare_digest 函数进行安全比较
            result = hmac.compare_digest(a, b)
            logger.info(f"HMAC 签名验证结果: {result}")
            return result
        except TypeError as e:
            logger.error(f"HMAC 比较过程中发生类型错误: {e}")
            raise TypeError(f"Error in HMAC comparison: {e}")
            