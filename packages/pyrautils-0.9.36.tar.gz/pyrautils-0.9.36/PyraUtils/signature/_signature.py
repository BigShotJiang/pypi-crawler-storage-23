#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by: 2018-4-16 20:59:0
modify by: 2023-05-25 11:24:33

功能：生成随机数和加密签名的工具类。
"""

import uuid
import random
import hmac
import hashlib
import base64
import secrets
from typing import str, int, bytes
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class GenerateNonceUtil:
    """
    随机数生成工具类，提供多种生成随机数的方法。
    
    示例用法：
    >>> from PyraUtils.signature._signature import GenerateNonceUtil
    >>> 
    >>> # 生成8位随机数字
    >>> nonce1 = GenerateNonceUtil.gen_nonce_use_random(8)
    >>> print(f"随机数字: {nonce1}")
    >>> 
    >>> # 生成16位加密安全的随机字符串
    >>> nonce2 = GenerateNonceUtil.gen_nonce_use_secrets(16)
    >>> print(f"安全随机字符串: {nonce2}")
    >>> 
    >>> # 生成UUID
    >>> nonce3 = GenerateNonceUtil.gen_nonce_use_uuid1()
    >>> print(f"UUID: {nonce3}")
    """

    @staticmethod
    def gen_nonce_use_random(length: int = 8) -> str:
        """
        使用 random 模块生成一个伪随机数作为随机值。
        
        :param length: 生成的随机数长度，默认为8位
        :type length: int
        :return: 返回由随机数字组成的字符串
        :rtype: str
        :raises ValueError: 如果长度小于1
        """
        logger.info(f"开始生成随机数字，长度: {length}")
        if length < 1:
            logger.error("随机数长度必须大于0")
            raise ValueError("随机数长度必须大于0")
            
        # 使用列表解析式生成指定长度的随机数，并转换为字符串返回
        result = ''.join([str(random.randint(0, 9)) for i in range(length)])
        logger.info("随机数字生成成功")
        return result

    @staticmethod
    def gen_nonce_use_secrets(length: int = 8) -> str:
        """
        使用 secrets 模块生成加密安全强度的随机字符串。
        
        :param length: 生成的随机字符串长度，默认为8位
        :type length: int
        :return: 返回由随机字符组成的字符串，字符集包括数字和字母
        :rtype: str
        :raises ValueError: 如果长度小于1
        """
        logger.info(f"开始生成安全随机字符串，长度: {length}")
        if length < 1:
            logger.error("随机字符串长度必须大于0")
            raise ValueError("随机字符串长度必须大于0")
            
        # 定义符合要求的字符集合
        alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        # 利用 secrets.choice() 随机选择字符构造随机字符串并返回
        result = ''.join(secrets.choice(alphabet) for _ in range(length))
        logger.info("安全随机字符串生成成功")
        return result

    @staticmethod
    def gen_nonce_use_uuid1() -> str:
        """
        使用 uuid 模块的 uuid1 函数生成基于主机ID和当前时间的唯一键。
        
        :return: 基于UUID1算法生成的独特标识符的字符串形式
        :rtype: str
        """
        logger.info("开始生成UUID")
        # 直接调用 uuid.uuid1() 并转化为字符串返回
        result = str(uuid.uuid1())
        logger.info(f"UUID生成成功: {result}")
        return result


class GenerateEncryptionUtil:
    """
    加密工具类，提供 HMAC 加密功能。
    
    示例用法：
    >>> from PyraUtils.signature._signature import GenerateEncryptionUtil
    >>> 
    >>> # 使用 HMAC-SHA256 加密
    >>> secret_key = "my_secret_key"
    >>> message = "Hello, World!"
    >>> signature = GenerateEncryptionUtil.gen_hmac_shax(secret_key, message, digestmod="HmacSHA256")
    >>> print(f"HMAC-SHA256 签名: {signature.decode('utf-8')}")
    """

    @staticmethod
    def gen_hmac_shax(secretKey: str, msg: str, digestmod: str = "HmacSHA1") -> bytes:
        """
        使用 HMAC 加密消息，模拟 PHP 中的 hash_hmac 函数。

        :param secretKey: 密钥，必须是字符串类型
        :type secretKey: str
        :param msg: 待加密的信息，必须是字符串类型
        :type msg: str
        :param digestmod: 指定哈希算法的类型，可以是 'HmacSHA256' 或 'HmacSHA1'
        :type digestmod: str
        :return: 使用 base64 编码的 HMAC 签名
        :rtype: bytes
        :raises ValueError: 如果提供了不支持的哈希算法

        注意：
        - PHP 和 Python 在输出时可能有细微差别，所以需要考虑输出格式的一致性。
        - 当使用 hmac.digest() 方法时，PHP 中应该使用原始二进制数据输出。
        - 当使用 hmac.hexdigest() 方法时，可以不传递 raw_output 参数给 PHP 的 hash_hmac 函数。
        """
        logger.info(f"开始生成 HMAC 签名，算法: {digestmod}")
        # 根据 digestmod 选择对应的哈希函数
        if digestmod == "HmacSHA256":
            hasher = hashlib.sha256
        elif digestmod == "HmacSHA1":
            hasher = hashlib.sha1
        else:
            logger.error(f"不支持的哈希算法: {digestmod}")
            raise ValueError(f"不支持的哈希算法: {digestmod}，仅支持 HmacSHA256 和 HmacSHA1")

        # 转换密钥和消息为字节类型
        secret_key_bytes = secretKey.encode('utf-8')
        msg_bytes = msg.encode('utf-8')

        # 加密后得到原始二进制数据
        data_bytes = hmac.new(secret_key_bytes, msg=msg_bytes, digestmod=hasher).digest()
        # 使用 base64 编码 HMAC 签名
        signature = base64.b64encode(data_bytes)

        # 避免时序攻击（如果有 compare_digest 方法则使用它）
        if hasattr(hmac, 'compare_digest'):
            expected = hmac.new(secret_key_bytes, msg=msg_bytes, digestmod=hasher).digest()
            # 使用 constant-time 比较签名是否匹配
            if not hmac.compare_digest(data_bytes, expected):
                logger.error("HMAC 签名不匹配")
                raise ValueError("HMAC signature does not match")

        logger.info("HMAC 签名生成成功")
        return signature
