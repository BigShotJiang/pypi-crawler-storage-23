# -*- coding: utf-8 -*-
"""
Created on 2022-07-05 18:03:02
Modified on 2024-07-29 11:05:32
Purpose: 提供JSON Web Token认证功能
"""

import datetime
from typing import Any, Dict, List, Optional, Tuple, Union, Type
from collections.abc import Callable
from authlib.jose import jwt, JoseError
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()

# 设置JWT选项配置
jwt_options = {
    'verify_signature': True,  # 验证签名
    'verify_exp': True,        # 验证令牌是否过期
    'verify_nbf': False,       # 验证令牌是否在某个时间点之后
    'verify_iat': True,        # 验证令牌发布时间
    'verify_aud': True,        # 验证受众字段
    'verify_iss': False        # 验证发行者字段
}


class JWTDecorator:
    """
    JSON Web Token装饰器类，支持 Flask 和 Tornado 框架。
    
    参考链接: https://github.com/paulorodriguesxv/tornado-json-web-token-jwt/blob/master/auth.py
    
    示例用法：
    >>> from PyraUtils.http._jwt import JWTDecorator
    >>> 
    >>> # Flask 用法
    >>> jwt_decorator = JWTDecorator(secret_key='your_secret_key')
    >>> 
    >>> @jwt_decorator.jwtauth(framework='flask')
    >>> def protected_route():
    >>>     return {'message': 'Authorized access'}
    >>> 
    >>> # Tornado 用法
    >>> class ProtectedHandler(tornado.web.RequestHandler):
    >>>     @jwt_decorator.jwtauth(framework='tornado')
    >>>     def get(self):
    >>>         self.write({'message': 'Authorized access'})
    """

    def __init__(self, auth_method: str = 'bearer', secret_key: str = 'DEFAULT_SECRET_KEY',
                 audience: Optional[str] = None, algorithms: List[str] = ['HS256']):
        """
        初始化JWTDecorator类。

        :param auth_method: 验证方法，默认为 bearer
        :type auth_method: str
        :param secret_key: 密钥，如果没有指定，则使用默认密钥 "my_secret_key"
        :type secret_key: str
        :param audience: 颁发令牌的受众
        :type audience: Optional[str]
        :param algorithms: 使用的算法，默认为 HS256
        :type algorithms: List[str]
        """
        self.secret_key = secret_key
        self.audience = audience
        self.auth_method = auth_method
        self.algorithms = algorithms
        logger.info(f"JWTDecorator 初始化成功: 认证方法={auth_method}, 算法={algorithms}")

    def is_valid_header(self, parts: List[str]) -> bool:
        """
        检查头部是否有效。

        :param parts: 授权头部信息分割后的列表
        :type parts: List[str]
        :return: 布尔值，头部信息有效返回True，否则返回False
        :rtype: bool
        """
        return parts and len(parts) == 2 and parts[0].lower() == self.auth_method

    def return_auth_error(self, handler: Any, err_msg: Dict[str, str]) -> None:
        """
        返回授权错误。

        :param handler: Tornado的RequestHandler对象
        :type handler: Any
        :param err_msg: 错误消息字典
        :type err_msg: Dict[str, str]
        """
        logger.warning(f"JWT 认证错误: {err_msg}")
        handler.set_status(401)
        handler.set_header('WWW-Authenticate', f'{self.auth_method.capitalize()} realm="Restricted"')
        handler.finish(err_msg)

    def require_auth(self, auth_header: Any) -> bool:
        """
        在执行handler前验证请求是否经过授权。

        :param auth_header: RequestHandler对象或Flask request对象
        :type auth_header: Any
        :return: 授权成功返回True，失败返回False
        :rtype: bool
        """
        auth = auth_header.request.headers.get('Authorization', None)
        if not auth:
            logger.warning("缺少 Authorization 头")
            self.return_auth_error(auth_header, {'message': '参数错误!', 'reason': '缺少Authorization'})
            return False

        parts = auth.split()
        if not self.is_valid_header(parts):
            logger.warning("无效的 Authorization 头格式")
            self.return_auth_error(auth_header, {'message': '验证错误', 'reason': '无效的Authorization头'})
            return False

        token = parts[1]
        try:
            # 定义验证选项
            claims_options = {
                'exp': {'essential': True},  # 确保验证过期时间
                'iat': {'essential': True},  # 确保验证发布时间
                'aud': {'essential': self.audience is not None}
            }
            
            # 设置受众参数
            claims_params = {'aud': self.audience} if self.audience else None
            
            payload = jwt.decode(
                token,
                self.secret_key,
                claims_options=claims_options,
                claims_params=claims_params
            )
            # 将解码后的payload添加到请求的属性中
            setattr(auth_header, '_jwt_payload', payload)
            logger.info("JWT 验证成功")
            return True
        except JoseError as err:
            logger.error(f"JWT 解码错误: {err}")
            self.return_auth_error(auth_header, {'message': 'Token无效', 'reason': str(err)})
            return False

    def jwtauth(self, func: Optional[Callable] = None, framework: str = 'flask') -> Callable:
        """
        JWT 认证装饰器工厂方法。
        
        :param func: 被装饰的函数，适用于 Flask 或 Tornado 框架
        :type func: Optional[Callable]
        :param framework: 框架类型，目前支持flask和tornado
        :type framework: str
        :return: 装饰后的函数或类
        :rtype: Callable
        :raises ValueError: 如果框架不被支持
        """
        if framework == 'flask':
            return self._flask_jwtauth(func)
        elif framework == 'tornado':
            # 对于Tornado，func是handler类
            return self._tornado_jwtauth(func)
        else:
            logger.error(f"不支持的框架: {framework}")
            raise ValueError(f"Unsupported framework: {framework}. Only 'flask' and 'tornado' are supported.")

    def _flask_jwtauth(self, func: Callable) -> Callable:
        """
        Flask JWT 认证装饰器。

        :param func: Flask的路由处理函数
        :type func: Callable
        :return: 装饰后的函数
        :rtype: Callable
        """
        def wrapper(*args, **kwargs):
            try:
                from flask import request  # 延迟导入 Flask 的 request 对象
            except ImportError:
                logger.error("Flask 未安装")
                raise ImportError("Flask is not installed. Please install it to use this feature.")
            if not self.require_auth(request):
                return {'message': 'Unauthorized'}, 401
            return func(*args, **kwargs)
        return wrapper

    def _tornado_jwtauth(self, handler_class: Optional[Type[Any]] = None) -> Callable:
        """
        Tornado JWT 认证装饰器。

        :param handler_class: Tornado的RequestHandler类
        :type handler_class: Optional[Type[Any]]
        :return: 装饰后的类或装饰器函数
        :rtype: Callable
        """
        def decorator(cls: Type[Any]) -> Type[Any]:
            """内部装饰器函数"""
            execute_orig = cls._execute

            def _execute(self, transforms, *args, **kwargs):
                self.require_auth(self)  # require_auth 已经处理了错误响应
                return execute_orig(self, transforms, *args, **kwargs)

            cls._execute = _execute
            return cls
        
        # 如果直接传递了handler_class，则直接应用装饰器
        if handler_class is not None:
            return decorator(handler_class)
        # 否则返回装饰器函数
        return decorator


class JWT:
    """
    JWT 类，提供编码和解码功能。
    
    示例用法：
    >>> from PyraUtils.http._jwt import JWT
    >>> 
    >>> jwt_instance = JWT(secret_key='your_secret_key')
    >>> # 生成 token
    >>> payload = {'user_id': 123, 'username': 'test_user'}
    >>> token_dict = jwt_instance.jwt_encode(payload, exp_seconds=3600)
    >>> token = token_dict['token']
    >>> 
    >>> # 验证 token
    >>> is_valid, result = jwt_instance.jwt_decode(token)
    >>> if is_valid:
    >>>     print('Token is valid:', result['data'])
    >>> else:
    >>>     print('Token is invalid:', result['reason'])
    """
    
    def __init__(self, secret_key: str = 'my_secret_key'):
        """
        初始化JWT类。

        :param secret_key: 密钥，如果没有指定，则使用默认密钥 "my_secret_key"
        :type secret_key: str
        """
        self.secret_key = secret_key
        logger.info("JWT 实例初始化成功")

    def jwt_encode(self, payload: Dict[str, Any], algorithm: str = 'HS256', 
                  exp_seconds: int = 3600, audience: Optional[str] = None) -> Dict[str, str]:
        """
        生成JWT token字符串。

        :param payload: 要编码的数据
        :type payload: Dict[str, Any]
        :param algorithm: 编码算法，默认为 HS256
        :type algorithm: str
        :param exp_seconds: token的过期时间（秒），默认为1小时
        :type exp_seconds: int
        :param audience: 颁发令牌的受众
        :type audience: Optional[str]
        :return: 包含 JWT token 的字典对象
        :rtype: Dict[str, str]
        :raises RuntimeError: 如果编码失败
        """
        logger.info(f"开始生成 JWT token，过期时间: {exp_seconds}秒")
        # jwt库会将这些datetime对象转化成相应的Unix时间戳。
        now = datetime.datetime.now(datetime.timezone.utc)
        payload.update({
            'exp': now + datetime.timedelta(seconds=exp_seconds),
            'iat': now,
        })

        # 如果提供了audience，则添加到payload中
        if audience:
            payload['aud'] = audience

        header = {'alg': algorithm}
        try:
            encoded = jwt.encode(header, payload, self.secret_key)
            token = encoded.decode() if isinstance(encoded, bytes) else encoded
            logger.info("JWT token 生成成功")
            return {'token': token}
        except (JoseError, TypeError) as e:
            logger.error(f"JWT 编码错误: {e}")
            raise RuntimeError(f"JWT encoding error: {e}")

    def jwt_decode(self, jwt_token: str, audience: Optional[str] = None) -> Tuple[bool, Dict[str, Any]]:
        """
        解码 JWT token。

        :param jwt_token: 要解码的 token
        :type jwt_token: str
        :param audience: 颁发令牌的受众
        :type audience: Optional[str]
        :return: tuple，第一个元素指示 token 是否有效，第二个元素是包含结果的字典对象
        :rtype: Tuple[bool, Dict[str, Any]]
        """
        logger.info("开始验证 JWT token")
        try:
            # 定义验证选项
            claims_options = {
                'exp': {'essential': True},  # 确保验证过期时间
                'iat': {'essential': True},  # 确保验证发布时间
                'aud': {'essential': audience is not None}
            }
            
            # 设置受众参数
            claims_params = {'aud': audience} if audience else None
            
            decoded = jwt.decode(
                jwt_token,
                self.secret_key,
                claims_options=claims_options,
                claims_params=claims_params
            )
            
            # 手动检查过期时间
            if 'exp' in decoded:
                exp_time = datetime.datetime.fromtimestamp(decoded['exp'], datetime.timezone.utc)
                now = datetime.datetime.now(datetime.timezone.utc)
                if exp_time < now:
                    logger.warning("JWT token 已过期")
                    return False, {'message': 'Token is expired!', 'reason': 'Token has expired'}
            
            logger.info("JWT token 验证成功")
            return True, {'message': 'Token is valid!', 'data': decoded}
        except JoseError as err:
            logger.error(f"JWT 解码错误: {err}")
            return False, {'message': 'Token is invalid!', 'reason': str(err)}
        except Exception as e:
            logger.error(f"JWT 验证时发生未知错误: {e}")
            return False, {'message': 'Unexpected error!', 'reason': str(e)}
