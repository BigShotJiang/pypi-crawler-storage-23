# -*- coding: utf-8 -*-

"""
created by：2017-05-10 20:11:31
modify by: 2024-03-07 23:21:32

功能：requests二次封装，常用的get,post,head,delete方法封装。
     这个是第三方库，使用提前需要pip install requests

参考文档:
    http://docs.python-requests.org/zh_CN/latest/user/quickstart.html
    http://docs.python-requests.org/zh_CN/latest/user/advanced.html
    http://docs.python-requests.org/zh_CN/latest/api.html
    http://docs.python-requests.org/zh_CN/latest/_modules/requests/api.html
"""

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from typing import Optional, Union, Dict, Any, Tuple, IO
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class RequestsBasicUtil:
    """
    requests 二次封装工具类，提供常用的 HTTP 请求方法封装。
    
    封装了 requests 库的核心功能，提供统一的错误处理和类型标注。
    """

    @staticmethod
    def req_method(method: str, url: str, **kwargs) -> requests.Response:
        """
        发送 HTTP 请求。

        :param method: HTTP 请求方法，如 ``GET``, ``OPTIONS``, ``HEAD``, ``POST``, ``PUT``, ``PATCH``, 或 ``DELETE``
        :type method: str
        :param url: 请求的 URL 地址
        :type url: str
        :param params: (可选) 请求的查询字符串参数，字典或字节内容
        :type params: Optional[Union[Dict[str, Any], bytes]]
        :param data: (可选) 请求体中的数据，字典、字节或类文件对象
        :type data: Optional[Union[Dict[str, Any], bytes, IO]]
        :param json: (可选) 请求体中的 JSON 数据
        :type json: Optional[Dict[str, Any]]
        :param headers: (可选) 请求头信息，字典格式
        :type headers: Optional[Dict[str, str]]
        :param cookies: (可选) 请求的 Cookie 信息，字典或 CookieJar 对象
        :type cookies: Optional[Union[Dict[str, str], requests.cookies.CookieJar]]
        :param files: (可选) 要上传的文件，字典格式，如 {'name': file-like-object}
        :type files: Optional[Dict[str, Any]]
        :param auth: (可选) HTTP 认证信息，用于 Basic/Digest/Custom 认证
        :type auth: Optional[Tuple[str, str]]
        :param timeout: (可选) 超时时间，浮点数或 (connect timeout, read timeout) 元组
        :type timeout: Optional[Union[float, Tuple[float, float]]]
        :param allow_redirects: (可选) 是否允许重定向，默认为 True
        :type allow_redirects: Optional[bool]
        :param proxies: (可选) 代理配置，字典格式，将协议映射为代理 URL
        :type proxies: Optional[Dict[str, str]]
        :param verify: (可选) 是否验证 SSL 证书，或 CA_BUNDLE 路径
        :type verify: Optional[Union[bool, str]]
        :param stream: (可选) 是否流式下载响应内容，默认为 False
        :type stream: Optional[bool]
        :param cert: (可选) SSL 客户端证书文件路径，或 (cert, key) 二元组
        :type cert: Optional[Union[str, Tuple[str, str]]]

        :return: HTTP 响应对象
        :rtype: requests.Response
        
        :raises RuntimeError: 如果请求过程中发生错误
        """
        logger.info(f"发送 {method} 请求到: {url}")
        if kwargs.get('params'):
            logger.debug(f"请求参数: {kwargs.get('params')}")
        if kwargs.get('json'):
            logger.debug(f"请求体: {kwargs.get('json')}")
        
        try:
            resp = requests.request(method, url, **kwargs)
            resp.raise_for_status()
            logger.info(f"请求成功，状态码: {resp.status_code}")
        except requests.RequestException as err:
            # 捕获所有请求相关的异常
            logger.error(f"请求出错: {err}")
            raise RuntimeError(f"请求出错: {err}")
        except Exception as e:
            # 捕获其他异常
            logger.error(f"未知错误: {e}")
            raise RuntimeError(f"未知错误: {e}")
        return resp

class RequestsSessionUtil:
    """
    封装 requests.Session 类，提供连接池、持久化会话和重试机制功能。
    
    该类配置了智能重试策略，适用于需要稳定连接的场景。
    """

    def __init__(self, retries: int = 5, backoff_factor: float = 0.3,
                 status_forcelist: list = [500, 502, 503, 504],
                 session: Optional[requests.Session] = None,
                 allowed_methods: list = ["HEAD", "GET", "OPTIONS", "POST"]):
        """
        初始化 Session，并配置重试策略。

        :param retries: 最大重试次数，默认为 5
        :type retries: int
        :param backoff_factor: 退避因子，决定重试间隔时间，默认为 0.3
        :type backoff_factor: float
        :param status_forcelist: 需要触发重试的 HTTP 状态码列表，默认为 [500, 502, 503, 504]
        :type status_forcelist: list
        :param session: 如果提供，则使用该 Session 对象，否则创建新的 Session
        :type session: Optional[requests.Session]
        :param allowed_methods: 允许重试的 HTTP 方法列表，默认为 ["HEAD", "GET", "OPTIONS", "POST"]
        :type allowed_methods: list
        """
        self.session = session or requests.Session()
        retry_strategy = Retry(
            total=retries,
            read=retries,
            connect=retries,
            backoff_factor=backoff_factor,
            status_forcelist=status_forcelist,
            allowed_methods=allowed_methods
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)
        logger.info(f"RequestsSessionUtil 初始化成功: 重试次数={retries}, 退避因子={backoff_factor}")

    def session_method(self, method: str, url: str, **kwargs) -> requests.Response:
        """
        使用预配置的 Session 来发送 HTTP 请求。

        :param method: HTTP 请求方法，如 'GET', 'POST', 'PUT', 'DELETE' 等
        :type method: str
        :param url: 请求的 URL 地址
        :type url: str
        :param **kwargs: requests.Session.request 方法所接受的其他参数，
                        与 RequestsBasicUtil.req_method 的参数相同

        :return: HTTP 响应对象
        :rtype: requests.Response
        
        :raises RuntimeError: 如果请求过程中发生错误
        """
        logger.info(f"使用会话发送 {method} 请求到: {url}")
        if kwargs.get('params'):
            logger.debug(f"请求参数: {kwargs.get('params')}")
        if kwargs.get('json'):
            logger.debug(f"请求体: {kwargs.get('json')}")
        
        try:
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status()
            logger.info(f"会话请求成功，状态码: {response.status_code}")
            return response
        except requests.RequestException as err:
            logger.error(f"Session 请求出错: {err}")
            raise RuntimeError(f"Session 请求出错: {err}")
        except Exception as e:
            logger.error(f"未知错误: {e}")
            raise RuntimeError(f"未知错误: {e}")
