"""
Created on 2022-07-05
Modified on 2024-07-29
Purpose: 提供 OAuth2 客户端功能
"""

from typing import Dict, Tuple, Any, Optional
from authlib.integrations.requests_client import OAuth2Session
from authlib.oauth2.rfc6749.errors import OAuth2Error
import requests
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class OAuth2ClientError(Exception):
    """Custom exception class for OAuth2Client errors"""
    pass


class OAuth2Client:
    """
    OAuth2 客户端类，用于处理 OAuth2 认证流程和资源访问。
    
    封装了 authlib 的 OAuth2Session，提供了简洁的接口来完成 OAuth2 认证流程：
    1. 获取授权 URL
    2. 使用授权响应获取访问令牌
    3. 使用刷新令牌获取新的访问令牌
    4. 使用访问令牌访问受保护的资源
    
    示例用法：
    >>> from PyraUtils.http._oauth2 import OAuth2Client, OAuth2ClientError
    >>> import os
    >>> 
    >>> client_id = os.getenv("CLIENT_ID")
    >>> client_secret = os.getenv("CLIENT_SECRET")
    >>> authorize_url = "https://example.com/oauth/authorize"
    >>> token_url = "https://example.com/oauth/token"
    >>> redirect_uri = "https://yourapp.com/callback"
    >>> scope = "read write"
    >>> 
    >>> oauth_client = OAuth2Client(client_id, client_secret, authorize_url, token_url, redirect_uri, scope)
    >>> 
    >>> try:
    >>>     # 获取授权URL
    >>>     auth_url, state = oauth_client.get_authorization_url()
    >>>     print(f"请访问以下URL进行授权: {auth_url}")
    >>> 
    >>>     # 在用户授权后，你会收到一个回调请求，其中包含授权响应
    >>>     authorization_response = input("请输入授权响应URL: ")
    >>> 
    >>>     # 获取访问令牌
    >>>     token = oauth_client.fetch_token(authorization_response)
    >>>     print(f"访问令牌: {token}")
    >>> 
    >>>     # 使用访问令牌获取资源
    >>>     resource_url = "https://example.com/api/resource"
    >>>     response = oauth_client.get(resource_url, token)
    >>>     print(f"资源响应: {response}")
    >>> except OAuth2ClientError as e:
    >>>     print(f"OAuth2ClientError: {e}")
    """
    
    def __init__(self, client_id: str, client_secret: str, authorize_url: str, 
                 token_url: str, redirect_uri: str, scope: str):
        """
        初始化OAuth2Client实例。

        :param client_id: OAuth2 客户端ID
        :type client_id: str
        :param client_secret: OAuth2 客户端密钥
        :type client_secret: str
        :param authorize_url: 授权URL
        :type authorize_url: str
        :param token_url: 令牌URL
        :type token_url: str
        :param redirect_uri: 重定向URI
        :type redirect_uri: str
        :param scope: 授权范围，多个范围用空格分隔
        :type scope: str
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.authorize_url = authorize_url
        self.token_url = token_url
        self.redirect_uri = redirect_uri
        self.scope = scope
        self.session = OAuth2Session(client_id, client_secret, redirect_uri=redirect_uri, scope=scope)
        logger.info(f"OAuth2Client 初始化成功: 客户端ID={client_id}, 授权范围={scope}")

    def get_authorization_url(self) -> Tuple[str, str]:
        """
        获取授权URL。

        :return: 授权URL和状态参数
        :rtype: Tuple[str, str]
        :raises OAuth2ClientError: 如果获取授权URL失败
        """
        logger.info(f"开始获取授权URL: {self.authorize_url}")
        try:
            uri, state = self.session.create_authorization_url(self.authorize_url)
            logger.info(f"授权URL获取成功: {uri}")
            return uri, state
        except OAuth2Error as e:
            logger.error(f"获取授权URL失败: {e}")
            raise OAuth2ClientError(f"Error obtaining authorization URL: {e}")

    def fetch_token(self, authorization_response: str) -> Dict[str, Any]:
        """
        使用授权响应获取访问令牌。

        :param authorization_response: 授权响应URL，包含授权码
        :type authorization_response: str
        :return: 访问令牌信息字典
        :rtype: Dict[str, Any]
        :raises OAuth2ClientError: 如果获取访问令牌失败
        """
        logger.info(f"开始获取访问令牌: {self.token_url}")
        try:
            token = self.session.fetch_token(self.token_url, authorization_response=authorization_response)
            logger.info("访问令牌获取成功")
            # 敏感信息不记录到日志
            token_info = {k: v for k, v in token.items() if k not in ['access_token', 'refresh_token']}
            logger.debug(f"令牌信息: {token_info}")
            return token
        except OAuth2Error as e:
            logger.error(f"获取访问令牌失败: {e}")
            raise OAuth2ClientError(f"Error fetching token: {e}")

    def refresh_token(self, refresh_token: str) -> Dict[str, Any]:
        """
        使用刷新令牌获取新的访问令牌。

        :param refresh_token: 刷新令牌
        :type refresh_token: str
        :return: 新的访问令牌信息字典
        :rtype: Dict[str, Any]
        :raises OAuth2ClientError: 如果刷新访问令牌失败
        """
        logger.info(f"开始刷新访问令牌: {self.token_url}")
        try:
            new_token = self.session.refresh_token(self.token_url, refresh_token=refresh_token)
            logger.info("访问令牌刷新成功")
            # 敏感信息不记录到日志
            token_info = {k: v for k, v in new_token.items() if k not in ['access_token', 'refresh_token']}
            logger.debug(f"新令牌信息: {token_info}")
            return new_token
        except OAuth2Error as e:
            logger.error(f"刷新访问令牌失败: {e}")
            raise OAuth2ClientError(f"Error refreshing token: {e}")

    def get(self, url: str, token: Dict[str, Any]) -> Dict[str, Any]:
        """
        使用访问令牌获取资源。

        :param url: 资源URL
        :type url: str
        :param token: 访问令牌信息字典
        :type token: Dict[str, Any]
        :return: 资源响应的JSON数据
        :rtype: Dict[str, Any]
        :raises OAuth2ClientError: 如果获取资源失败
        """
        logger.info(f"开始获取资源: {url}")
        try:
            self.session.token = token
            response = self.session.get(url)
            response.raise_for_status()  # 对于错误响应抛出 HTTPError
            logger.info(f"资源获取成功，状态码: {response.status_code}")
            return response.json()
        except OAuth2Error as e:
            logger.error(f"OAuth2 错误: {e}")
            raise OAuth2ClientError(f"OAuth2 error making GET request: {e}")
        except requests.exceptions.HTTPError as e:
            logger.error(f"HTTP 错误: {e}")
            raise OAuth2ClientError(f"HTTP error: {e}")
        except Exception as e:
            logger.error(f"未知错误: {e}")
            raise OAuth2ClientError(f"Unexpected error: {e}")
