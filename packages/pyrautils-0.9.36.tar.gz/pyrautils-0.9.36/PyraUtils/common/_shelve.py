#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Shelve 持久化存储工具类，用于数据的持久化存储和读取。
"""

import os
import shelve
from typing import Any, Optional

class ShelveUtils:
    """
    Shelve 持久化存储工具类，提供数据的持久化存储和读取功能。
    
    Shelf 是一种持久化的类似字典的对象，可以像字典一样使用。
    
    示例用法：
    >>> # 写入数据
    >>> ShelveUtils.set_shelve_value('data.db', 'name', 'John')
    >>> # 读取数据
    >>> name = ShelveUtils.get_shelve_value('data.db', 'name')
    >>> print(name)  # 输出: John
    """
    
    @staticmethod
    def set_shelve_value(file_path: str, key: str, value: Any, flag: str = 'c', writeback: bool = False) -> None:
        """
        向 Shelve 文件中写入键值对。

        :param file_path: Shelve 文件路径
        :type file_path: str
        :param key: 要写入的键
        :type key: str
        :param value: 要写入的值
        :type value: Any
        :param flag: 打开模式，默认为 'c'
        :type flag: str
        :param writeback: 是否开启回写模式，默认为 False
        :type writeback: bool
        
        :raises OSError: 如果 flag 为 'w' 但文件不存在
        :raises ValueError: 如果 flag 不是有效的打开模式
        
        打开模式说明：
        - 'r': 只读访问
        - 'w': 读写访问（文件必须存在）
        - 'c': 读写访问（如果文件不存在则创建，默认）
        - 'n': 读写访问（总是创建新的空文件）
        """
        valid_flags = {'r', 'w', 'c', 'n'}
        if flag not in valid_flags:
            raise ValueError(f"无效的 flag: {flag}，有效值包括: {', '.join(valid_flags)}")

        if flag == "w" and not os.path.isfile(file_path):
            raise OSError(f"文件路径 {file_path} 不存在！")

        with shelve.open(file_path, flag=flag, writeback=writeback) as shelf:
            shelf[key] = value

    @staticmethod
    def get_shelve_value(file_path: str, key: str, flag: str = 'r', writeback: bool = False) -> Any:
        """
        从 Shelve 文件中读取指定键的值。
        
        :param file_path: Shelve 文件路径
        :type file_path: str
        :param key: 要读取的键
        :type key: str
        :param flag: 打开模式，默认为 'r'
        :type flag: str
        :param writeback: 是否开启回写模式，默认为 False
        :type writeback: bool
        
        :return: 指定键对应的值
        :rtype: Any
        
        :raises KeyError: 如果指定的键不存在
        :raises OSError: 如果文件不存在且 flag 为 'r'
        :raises ValueError: 如果 flag 不是有效的打开模式
        
        打开模式说明：
        - 'r': 只读访问
        - 'w': 读写访问（文件必须存在）
        - 'c': 读写访问（如果文件不存在则创建，默认）
        - 'n': 读写访问（总是创建新的空文件）
        """
        valid_flags = {'r', 'w', 'c', 'n'}
        if flag not in valid_flags:
            raise ValueError(f"无效的 flag: {flag}，有效值包括: {', '.join(valid_flags)}")

        with shelve.open(file_path, flag=flag, writeback=writeback) as shelf:
            try:
                return shelf[key]
            except KeyError as err:
                raise KeyError(f'键不存在: {err}')
