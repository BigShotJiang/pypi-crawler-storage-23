#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cerberus 验证工具类，用于数据验证。
"""

from cerberus import Validator
from typing import Dict, Any, Optional
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()

class CerberusUtil:
    """
    Cerberus 验证工具类，提供数据验证功能。
    
    示例用法：
    >>> validator = CerberusUtil()
    >>> schema = {"name": {"type": "string"}, "age": {"type": "integer", "min": 0}}
    >>> document = {"name": "John", "age": 30}
    >>> if validator.validate(document, schema):
    >>>     print("文档验证通过")
    >>> else:
    >>>     print(f"验证失败: {validator.errors()}")
    """
    
    def __init__(self):
        """
        初始化 Cerberus 验证器。
        """
        self.validator = Validator()
        logger.info("Cerberus 验证器初始化完成")

    def validate(self, document: Dict[str, Any], schema: Dict[str, Any]) -> bool:
        """
        使用 Cerberus 验证器来验证给定的文档是否符合给定的模式。

        :param document: 要验证的文档，通常是字典格式
        :type document: Dict[str, Any]
        :param schema: 包含验证规则的模式，遵循 Cerberus 模式格式
        :type schema: Dict[str, Any]
        :return: 如果文档有效，则返回 True；否则返回 False
        :rtype: bool
        """
        logger.debug(f"开始验证文档: {document}")
        logger.debug(f"验证模式: {schema}")
        result = self.validator.validate(document, schema)
        if result:
            logger.info("文档验证通过")
        else:
            logger.warning(f"文档验证失败: {self.validator.errors}")
        return result

    def errors(self) -> Dict[str, Any]:
        """
        获取最近一次验证操作的错误字典。

        :return: 包含验证错误信息的字典，键为字段名，值为错误信息
        :rtype: Dict[str, Any]
        """
        logger.debug(f"获取验证错误: {self.validator.errors}")
        return self.validator.errors
