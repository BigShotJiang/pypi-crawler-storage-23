#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by：2017-05-10 20:11:31
modify by: 2017-6-30 15:56:58

功能：实现rsync命令的二次封装

"""

import sysrsync
import subprocess
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()

class RsyncUtil:
    """
    Rsync 工具类，封装了 sysrsync 模块，提供文件同步功能。

    提供两种同步方式：
    - rsync_use_ssh(): 使用 SSH 方式进行 Rsync
    - rsync_daemon(): 使用 Rsync daemon 方式进行 Rsync

    使用要求：
    - 本地和远程系统中都必须安装 rsync 命令
    - 使用 rsync_daemon() 方法时，需要准备存储密码的文本文件，并且需要设置该文件的权限为 600
    """

    @staticmethod
    def rsync_use_ssh(workspace: str, source_dir: str, rsync_user: str,
                      rsync_ip: str, target: str, rsync_port: int = 22) -> int:
        """
        使用 SSH 方式进行 Rsync 文件同步。

        :param workspace: Rsync 工作路径，可以是任意有效路径
        :type workspace: str
        :param source_dir: Rsync 源路径，本地文件或目录路径
        :type source_dir: str
        :param rsync_user: SSH 用户名
        :type rsync_user: str
        :param rsync_ip: 目标服务器 IP 地址
        :type rsync_ip: str
        :param target: 目标服务器上的路径
        :type target: str
        :param rsync_port: SSH 端口，默认为 22
        :type rsync_port: int

        :return: 执行状态码，0 为正常，其他为异常
        :rtype: int
        
        示例用法：
        >>> RsyncUtil.rsync_use_ssh(
        >>>     workspace='/tmp',
        >>>     source_dir='/local/path',
        >>>     rsync_user='user',
        >>>     rsync_ip='192.168.1.100',
        >>>     target='/remote/path',
        >>>     rsync_port=2222
        >>> )
        """
        logger.info(f"开始使用 SSH 方式进行 Rsync 同步: 源={source_dir} -> 目标={rsync_user}@{rsync_ip}:{target}")
        destination = f"{rsync_user}@{rsync_ip}:{target}"
        ssh_opts = f"-e 'ssh -p {rsync_port}'"
        result = RsyncUtil.do_rsync(workspace, source_dir, destination, ssh_opts)
        if result == 0:
            logger.info("SSH 方式 Rsync 同步成功")
        else:
            logger.warning("SSH 方式 Rsync 同步失败")
        return result

    @staticmethod
    def rsync_daemon(workspace: str, source_dir: str, rsync_user: str, rsync_ip: str,
                     rsync_remote_module: str, rsync_passwd_file: str, rsync_port: int = 873) -> int:
        """
        使用 Rsync daemon 方式进行 Rsync 文件同步。

        :param workspace: Rsync 工作路径，可以是任意有效路径
        :type workspace: str
        :param source_dir: Rsync 源路径，本地文件或目录路径
        :type source_dir: str
        :param rsync_user: Rsync 用户名
        :type rsync_user: str
        :param rsync_ip: Rsync daemon 服务器 IP 地址
        :type rsync_ip: str
        :param rsync_remote_module: Rsync daemon 配置的模块名
        :type rsync_remote_module: str
        :param rsync_passwd_file: 存储 Rsync 密码的文本文件路径
                                 注意：该文件权限必须设置为 600
        :type rsync_passwd_file: str
        :param rsync_port: Rsync daemon 端口，默认为 873
        :type rsync_port: int

        :return: 执行状态码，0 为正常，其他为异常
        :rtype: int
        
        示例用法：
        >>> RsyncUtil.rsync_daemon(
        >>>     workspace='/tmp',
        >>>     source_dir='/local/path',
        >>>     rsync_user='rsync_user',
        >>>     rsync_ip='192.168.1.100',
        >>>     rsync_remote_module='module_name',
        >>>     rsync_passwd_file='/path/to/rsync.passwd'
        >>> )
        """
        logger.info(f"开始使用 Rsync daemon 方式进行同步: 源={source_dir} -> 目标={rsync_user}@{rsync_ip}::{rsync_remote_module}")
        destination = f"{rsync_user}@{rsync_ip}::{rsync_remote_module}"
        extra_opts = f"--port={rsync_port} --password-file={rsync_passwd_file}"
        result = RsyncUtil.do_rsync(workspace, source_dir, destination, extra_opts)
        if result == 0:
            logger.info("Rsync daemon 方式同步成功")
        else:
            logger.warning("Rsync daemon 方式同步失败")
        return result

    @staticmethod
    def do_rsync(workspace: str, source: str, destination: str, options: str = "") -> int:
        """
        执行 rsync 命令的底层方法。

        :param workspace: Rsync 工作路径，可以是任意有效路径
        :type workspace: str
        :param source: Rsync 源路径
        :type source: str
        :param destination: Rsync 目标路径
        :type destination: str
        :param options: 其他 rsync 命令参数，如 SSH 选项、daemon 选项等
        :type options: str

        :return: 执行状态码，0 为正常，其他为异常
        :rtype: int
        """
        # 添加常用的 rsync 选项，如递归、压缩、保留权限等
        default_opts = "-avz"
        
        # 构建完整的 rsync 命令
        command = f"rsync {default_opts} {options} '{source}' '{destination}'"
        
        try:
            logger.info(f"执行 rsync 命令: {command}")
            return subprocess.check_call(command, shell=True, cwd=workspace)
        except Exception as e:
            logger.error(f"执行 rsync 命令时发生错误: {e}")
            return 1
           