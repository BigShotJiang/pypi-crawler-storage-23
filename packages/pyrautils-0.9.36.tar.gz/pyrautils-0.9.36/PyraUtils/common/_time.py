# -*- coding: utf-8 -*-
"""
created by：2022-07-29 16:17:18
modify by: 2022-08-01 18:51:42
功能：时间相关的函数封装
"""

import pytz
import datetime
import calendar
from typing import Optional

class TimeUtils:
    """
    时间处理工具类，提供各种常用的时间操作方法。
    """

    @staticmethod
    def datetime_strftime_now(tz_info: Optional[str] = "Asia/Shanghai",
                              strftime: str = "%Y-%m-%d %H:%M:%S") -> str:
        """
        获取当前时间的格式化字符串。

        :param tz_info: 时区信息，如 "Asia/Shanghai"，None 表示使用本地时区
        :type tz_info: Optional[str]
        :param strftime: 时间格式化字符串，默认 "%Y-%m-%d %H:%M:%S"
        :type strftime: str
        :return: 格式化后的时间字符串
        :rtype: str
        :raises pytz.exceptions.UnknownTimeZoneError: 如果提供了无效的时区信息
        
        示例用法：
        >>> TimeUtils.datetime_strftime_now()
        '2023-12-25 10:30:45'
        >>> TimeUtils.datetime_strftime_now(tz_info="UTC", strftime="%Y-%m-%dT%H:%M:%SZ")
        '2023-12-25T02:30:45Z'
        """
        if tz_info:
            tz_info_obj = pytz.timezone(tz_info)
            return datetime.datetime.now(tz=tz_info_obj).strftime(strftime) 
        else:
            return datetime.datetime.now().strftime(strftime)

    @staticmethod
    def timegm_timestamp(value: datetime.datetime) -> float:
        """
        将 datetime 对象转换为 Unix 时间戳（秒）。

        :param value: 要转换的 datetime 对象
        :type value: datetime.datetime
        :return: Unix 时间戳（自 1970-01-01 00:00:00 UTC 以来的秒数）
        :rtype: float
        
        示例用法：
        >>> dt = datetime.datetime(2023, 12, 25, 10, 30, 45)
        >>> TimeUtils.timegm_timestamp(dt)
        1703490645.0
        """
        if value.tzinfo is None:
            # 假设无时区的datetime对象是UTC时间
            return float(calendar.timegm(value.timetuple()))
        else:
            # 对于带时区的datetime对象，先转换为UTC再获取时间戳
            return float(calendar.timegm(value.astimezone(datetime.timezone.utc).timetuple()))

    @staticmethod
    def datetime_utc_now(date_type: str = "seconds", tz: Optional[datetime.tzinfo] = None, 
                        timedelta: int = 0) -> datetime.datetime:
        """
        获取当前 UTC 时间，并可选择添加时间偏移。

        :param date_type: 时间偏移的单位，支持 seconds、minutes、hours、days、weeks
        :type date_type: str
        :param tz: 时区信息，默认使用 UTC 时区
        :type tz: Optional[datetime.tzinfo]
        :param timedelta: 时间偏移量，正数表示未来时间，负数表示过去时间
        :type timedelta: int
        :return: 带时区信息的 datetime 对象
        :rtype: datetime.datetime
        
        示例用法：
        >>> TimeUtils.datetime_utc_now()
        datetime.datetime(2023, 12, 25, 2, 30, 45, 123456, tzinfo=datetime.timezone.utc)
        >>> TimeUtils.datetime_utc_now(date_type="minutes", timedelta=30)
        datetime.datetime(2023, 12, 25, 3, 0, 45, 123456, tzinfo=datetime.timezone.utc)
        """
        if tz is None:
            tz = datetime.timezone.utc

        # 验证 date_type 参数
        valid_date_types = {'seconds', 'minutes', 'hours', 'days', 'weeks'}
        if date_type.lower() not in valid_date_types:
            raise ValueError(f"无效的 date_type: {date_type}，支持的类型包括: {', '.join(valid_date_types)}")

        datetime_timedelta = datetime.timedelta(**{date_type.lower(): timedelta}) 
        return datetime.datetime.now(tz=tz) + datetime_timedelta
