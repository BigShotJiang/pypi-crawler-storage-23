#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
邮件发送工具类，支持 HTML 格式邮件发送。
"""

import smtplib
from email.mime.text import MIMEText
from email.header import Header
from email.mime.multipart import MIMEMultipart
from typing import Union, List, Optional
from PyraUtils.log import LoguruHandler

class EmailSender:
    """
    邮件发送工具类，支持 HTML 格式邮件发送。
    
    示例用法：
    >>> sender = EmailSender(
    >>>     smtp_server="smtp.example.com",
    >>>     smtp_port=465,
    >>>     sender_email="sender@example.com",
    >>>     password="your_password"
    >>> )
    >>> sender.send_email(
    >>>     subject="测试邮件",
    >>>     body="这是一封测试邮件内容",
    >>>     receiver_email="receiver@example.com"
    >>> )
    """
    
    # 创建类级别的 logger 实例
    logger = LoguruHandler()
    
    def __init__(self, smtp_server: str, smtp_port: int, sender_email: str, password: str, timeout: int = 30):
        """
        初始化邮件发送器。

        :param smtp_server: SMTP 服务器地址
        :type smtp_server: str
        :param smtp_port: SMTP 服务器端口（1-65535）
        :type smtp_port: int
        :param sender_email: 发件人邮箱
        :type sender_email: str
        :param password: 发件人邮箱密码或授权码
        :type password: str
        :param timeout: SMTP连接超时时间（秒），默认为30秒
        :type timeout: int
        :raises ValueError: 如果端口号无效
        """
        # 验证SMTP端口
        if not isinstance(smtp_port, int) or smtp_port <= 0 or smtp_port > 65535:
            self.logger.error(f"无效的SMTP端口号: {smtp_port}，端口号必须是1-65535之间的整数")
            raise ValueError(f"无效的SMTP端口号: {smtp_port}，端口号必须是1-65535之间的整数")
            
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.sender_email = sender_email
        self.password = password
        self.timeout = timeout
        
        self.logger.info(f"邮件发送器初始化成功: SMTP服务器={smtp_server}:{smtp_port}, 发件人={sender_email}")

    def send_email(self, subject: str, body: str, receiver_email: Union[str, List[str]], 
                  is_html: bool = True) -> bool:
        """
        发送邮件。

        :param subject: 邮件主题
        :type subject: str
        :param body: 邮件内容
        :type body: str
        :param receiver_email: 收件人邮箱，可以是单个邮箱字符串或邮箱列表
        :type receiver_email: Union[str, List[str]]
        :param is_html: 邮件内容是否为 HTML 格式，默认为 True
        :type is_html: bool
        :return: 发送成功返回 True，失败返回 False
        :rtype: bool
        """
        try:
            # 处理收件人
            if isinstance(receiver_email, str):
                receivers = [receiver_email]
            else:
                receivers = receiver_email
            
            # 创建邮件内容
            if is_html:
                # 简化HTML模板，保留基本结构
                html_body = f"<html><body><p>{body}</p></body></html>"
                msg = MIMEText(html_body, "html", 'utf-8')
            else:
                msg = MIMEText(body, "plain", 'utf-8')
            
            # 设置邮件头
            msg["Subject"] = Header(subject, 'utf-8')
            msg['From'] = self.sender_email
            msg['To'] = ", ".join(receivers)

            self.logger.info(f"正在连接到 SMTP 服务器 {self.smtp_server}:{self.smtp_port}...")
            
            # 发送邮件，使用超时设置
            with smtplib.SMTP_SSL(self.smtp_server, self.smtp_port, timeout=self.timeout) as server:
                self.logger.info("正在登录到 SMTP 服务器...")
                server.login(self.sender_email, self.password)
                
                self.logger.info(f"正在发送邮件到 {', '.join(receivers)}...")
                server.sendmail(self.sender_email, receivers, msg.as_string())
                
                self.logger.info("邮件发送成功！")
                return True
                
        except smtplib.SMTPException as e:
            self.logger.error(f"发送邮件失败: {e}")
            return False
        except Exception as e:
            self.logger.error(f"发送邮件时发生未知错误: {e}")
            return False


