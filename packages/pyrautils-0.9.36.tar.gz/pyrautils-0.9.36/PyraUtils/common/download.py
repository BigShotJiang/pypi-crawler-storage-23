#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by：2018-2-23 14:15:57
modify by: 2023-05-13 15:05:05

功能：各种常用的方法函数的封装。
"""

import os
import urllib3
from contextlib import closing
import requests
import httpx
import rich.progress
from tqdm import tqdm

from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()

class DownloadUtil:
    """
    下载工具类，提供多种下载文件的方法。
    
    包含以下下载方法：
    - dl_01: 使用 requests 实现基本下载
    - dl_02: 使用 urllib3 实现下载
    - dl_03: 使用 requests 实现下载并增加状态判断
    - dl_04: 使用 requests 实现大文件下载，支持断点续传
    """

    def __init__(self):
        pass

    @staticmethod
    def dl_01(url: str, dl_path: str, timeout: int = 10, **kwargs) -> bool:
        """
        使用 requests 实现基本下载。

        :param url: 下载文件的 URL 地址
        :type url: str
        :param dl_path: 下载文件保存的路径
        :type dl_path: str
        :param timeout: 超时时间，默认为 10 秒
        :type timeout: int
        :param kwargs: 其他可选参数传递给 requests.get()
        :return: 下载成功返回 True，失败返回 False
        :rtype: bool
        """
        try:
            # 检查保存文件的目录是否存在，如果不存在则创建
            os.makedirs(os.path.dirname(dl_path), exist_ok=True)
            resp = requests.get(url, timeout=timeout, **kwargs)
            # 在有异常的情况下抛出异常
            resp.raise_for_status()
            with open(dl_path, "wb") as f:
                f.write(resp.content)
            return True  # 返回下载成功标识
        except (requests.RequestException, IOError) as err:
            logger.error(f"下载 {url} 时发生错误: {err}")
            return False  # 返回下载失败标识

    @staticmethod
    def dl_02(url: str, dl_path: str, timeout: float = 10, **kwargs) -> None:
        """
        使用 urllib3 实现下载。

        :param url: 下载文件的 URL 地址
        :type url: str
        :param dl_path: 下载文件保存的路径
        :type dl_path: str
        :param timeout: 超时时间（秒），默认为 10 秒
        :type timeout: float
        :param kwargs: 其他可选参数传递给 http.request()
        :return: None

        示例用法：
        >>> DownloadUtil.dl_02('https://example.com/file.zip', 'path/to/save/file.zip')
        """
        # 创建连接池管理器
        http = urllib3.PoolManager(timeout=timeout)
        # 发送请求并获取响应
        response = http.request('GET', url, **kwargs)
        # 检查保存文件的目录是否存在，如果不存在则创建
        os.makedirs(os.path.dirname(dl_path), exist_ok=True)
        # 读取响应内容并保存到文件中
        with open(dl_path, 'wb') as f:
            f.write(response.data)

    @staticmethod
    def dl_03(url: str, dl_path: str, **kwargs) -> str:
        """
        使用 requests 实现下载，并增加对特定情况的判断。

        :param url: 下载文件的 URL 地址
        :type url: str
        :param dl_path: 下载文件保存的路径
        :type dl_path: str
        :param kwargs: 其他可选参数传递给 requests.get()
        :return: 下载结果状态字符串
                 - 'success': 下载成功
                 - 'size0 {url}': 文件大小为 0
                 - 'RequestError {error}': 请求过程中发生错误
                 - 'SaveError {error}': 保存文件时发生错误
        :rtype: str
        """
        with closing(requests.get(url, stream=True, **kwargs)) as resp:
            # 判断下载链接是否异常
            resp.raise_for_status()

            # 判断下载链接是否异常（双重检查）
            resp_code = resp.status_code
            # 确保 resp_code 是整数类型
            try:
                if isinstance(resp_code, int) and (resp_code < 200 or resp_code > 299):
                    logger.warning('返回状态码异常 %s %s' % (resp_code, url))
            except (TypeError, ValueError):
                # 忽略类型错误，在测试环境中可能会出现 MagicMock 对象
                pass

            # 判断下载文件是否为 0 字节
            content_length = int(resp.headers.get('content-length', '0'))
            if content_length == 0:
                return f'size0 {url}'

            try:
                # 确保目录存在
                os.makedirs(os.path.dirname(dl_path), exist_ok=True)
                with open(dl_path, 'wb') as f:
                    for data in resp.iter_content(1024):
                        f.write(data)
            except requests.exceptions.RequestException as e:
                return f'RequestError {str(e)}'
            except IOError as e:
                return f'SaveError {str(e)}'
            except Exception as e:
                # 捕获其他所有异常
                return f'RequestError {str(e)}'

            return 'success'

    @staticmethod
    def dl_04(url: str, dl_path: str, chunk_size: int = 1024, **kwargs) -> None:
        """
        使用 requests 实现大文件下载，支持断点续传。

        :param url: 下载文件的 URL 地址
        :type url: str
        :param dl_path: 下载文件保存的路径
        :type dl_path: str
        :param chunk_size: 每次下载的块大小，默认为 1024 字节
        :type chunk_size: int
        :param kwargs: 其他可选参数传递给 requests.get()
        :return: None
        
        注意：如果文件已经存在，会从上次下载的位置继续下载（断点续传）。
        """
        # 确保目录存在
        os.makedirs(os.path.dirname(dl_path), exist_ok=True)

        # 判断文件是否已经存在
        file_exists = os.path.exists(dl_path)
        headers = kwargs.get('headers', {})
        
        if file_exists:
            # 获取本地文件大小
            local_size = os.path.getsize(dl_path)
            
            # 发送HEAD请求获取文件总大小
            head_resp = requests.head(url, headers=headers, **kwargs)
            head_resp.raise_for_status()
            
            # 获取文件总大小
            total_size = int(head_resp.headers.get('content-length', '0'))
            
            if local_size >= total_size and total_size > 0:
                # 文件已经完整存在，直接返回
                logger.info(f"文件 {dl_path} 已经完整存在，跳过下载")
                return
            else:
                # 文件不完整，继续下载
                headers['Range'] = f'bytes={local_size}-'
                kwargs['headers'] = headers

        with requests.get(url, stream=True, **kwargs) as resp:
            resp.raise_for_status()

            with open(dl_path, 'ab') as f:
                for chunk in resp.iter_content(chunk_size=chunk_size):
                    if chunk:  # 过滤掉空的块
                        f.write(chunk)

class DownloadProgressUtil:
    """
    带进度条的下载工具类，提供可视化的文件下载功能。
    
    包含以下下载方法：
    - dl_01: 使用 tqdm 库显示下载进度条
    - dl_02: 使用 rich 库显示更丰富的下载进度条
    """
    
    def __init__(self, chunk_size: int = 1024) -> None:
        """
        初始化 DownloadProgressUtil 实例。

        :param chunk_size: 每次下载的块大小，默认为 1024 字节
        :type chunk_size: int
        """
        self.chunk_size = chunk_size

    def dl_01(self, url: str, dl_path: str, **kwargs) -> None:
        """
        使用 tqdm 库显示下载进度条，实现文件下载。

        :param url: 下载文件的 URL 地址
        :type url: str
        :param dl_path: 下载文件保存的路径
        :type dl_path: str
        :param kwargs: 其他可选参数传递给 httpx.stream()
        :return: None
        """
        # 创建文件夹（如果不存在）
        os.makedirs(os.path.dirname(dl_path), exist_ok=True)

        # 发送GET请求并获得响应对象
        with open(dl_path, 'wb') as out_file:
            # 使用 httpx.stream() 方法获取流式响应
            with httpx.stream("GET", url, **kwargs) as resp:
                # 确定文件的总大小（字节数）
                total_length = int(resp.headers.get("Content-Length", 0))

                with tqdm(total=total_length, unit_scale=True, unit_divisor=1024, unit="B") as progress:
                    num_bytes_downloaded = resp.num_bytes_downloaded
                    for chunk in resp.iter_bytes(chunk_size=self.chunk_size):
                        out_file.write(chunk)
                        progress.update(resp.num_bytes_downloaded - num_bytes_downloaded)
                        num_bytes_downloaded = resp.num_bytes_downloaded

    def dl_02(self, url: str, dl_path: str, **kwargs) -> None:
        """
        使用 rich 库显示更丰富的下载进度条，实现文件下载。

        :param url: 下载文件的 URL 地址
        :type url: str
        :param dl_path: 下载文件保存的路径
        :type dl_path: str
        :param kwargs: 其他可选参数传递给 httpx.stream()
        :return: None
        """
        # 创建文件夹（如果不存在）
        os.makedirs(os.path.dirname(dl_path), exist_ok=True)
        
        with open(dl_path, 'wb') as out_file:
            # 使用 httpx.stream() 方法获取流式响应
            with httpx.stream("GET", url, **kwargs) as resp:
                total_length = int(resp.headers.get("Content-Length", 0))

                with rich.progress.Progress(
                    "[progress.percentage]{task.percentage:>3.0f}%",
                    rich.progress.BarColumn(bar_width=None),
                    rich.progress.DownloadColumn(),
                    rich.progress.TransferSpeedColumn(),
                ) as progress:
                    download_task = progress.add_task("Download", total=total_length)
                    for chunk in resp.iter_bytes(chunk_size=self.chunk_size):
                        out_file.write(chunk)
                        progress.update(download_task, completed=resp.num_bytes_downloaded)

