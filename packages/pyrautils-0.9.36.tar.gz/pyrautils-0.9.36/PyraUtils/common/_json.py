#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by：2021-12-02 18:02:15
modify by: 2023-05-12 10:02:18

功能：json函数的封装。
"""

import json
import os
from typing import Any, Optional, Dict, List
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()

class JsonUtils:
    """
    支持加载、保存、更新JSON文件以及判断字符串是否为JSON格式等操作。

    Attributes:

        dumps是将dict转化成str格式，loads是将str转化成dict格式。

        dump和load也是类似的功能，只是与文件操作结合起来了。
    """
    def __init__(self):
        pass
    
    @staticmethod
    def load_json(json_path: str) -> Optional[Dict[str, Any]]:
        """
        加载JSON文件并返回一个JSON对象。

        :param json_path: JSON文件路径
        :type json_path: str
        :return: 解析后的JSON对象，如果解析失败则返回None
        :rtype: Optional[Dict[str, Any]]
        
        :raises OSError: 如果文件打开失败
        """
        logger.info(f"开始加载JSON文件: {json_path}")
        try:
            with open(json_path, "r", encoding="utf8") as frs:
                data = json.load(frs)
                logger.info(f"JSON文件加载成功: {json_path}")
                return data
        except OSError as e:
            logger.error(f"无法打开文件 {json_path}: {e}")
            raise OSError(f"无法打开文件 {json_path}: {e}")
        except json.JSONDecodeError as e:
            logger.warning(f"JSON解析错误 {json_path}: {e}")
            # 捕获JSON解析错误并返回None
            return None

    @staticmethod
    def set_json_to_file(value: Any, file_path: str, ensure_ascii: bool = False) -> Optional[bool]:
        """
        将JSON对象或JSON字符串写入文件。

        :param value: 要写入的JSON对象或JSON格式字符串
        :type value: Any
        :param file_path: 要写入的文件路径
        :type file_path: str
        :param ensure_ascii: 是否保证ASCII字符在输出时不会转义，默认为False（支持中文等非ASCII字符）
        :type ensure_ascii: bool
        :return: 成功时返回True；失败时返回None
        :rtype: Optional[bool]
        """
        logger.info(f"开始写入JSON文件: {file_path}")
        try:
            # 如果输入是字符串，尝试解析为JSON对象
            if isinstance(value, str):
                json_data = json.loads(value)
            else:
                json_data = value
                
            # 确保目录存在
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            with open(file_path, "w", encoding="utf8") as fws:
                json.dump(json_data, fws, indent=4, sort_keys=True, ensure_ascii=ensure_ascii)
            logger.info(f"JSON文件写入成功: {file_path}")
            return True
        except (OSError, json.JSONDecodeError, TypeError) as e:
            logger.error(f"写入JSON文件失败 {file_path}: {e}")
            # 捕获文件操作异常、JSON解析异常或类型错误
            return None
    
    @staticmethod
    def get_json_value(file_path: str, key: str) -> Optional[Any]:
        """
        从JSON文件中获取指定键对应的值。

        :param file_path: JSON文件路径
        :type file_path: str
        :param key: 需要获取的键名
        :type key: str
        :return: 键对应的值，如果键不存在或操作失败则返回None
        :rtype: Optional[Any]
        """
        logger.info(f"从JSON文件获取值: {file_path}, 键: {key}")
        try:
            data = JsonUtils.load_json(file_path)  # 加载JSON文件内容
            if data is None:
                logger.warning(f"JSON文件解析失败: {file_path}")
                return None
            value = data.get(key)
            logger.info(f"获取键值成功: {key} = {value}")
            return value
        except (OSError, json.JSONDecodeError) as e:
            logger.error(f"获取JSON值失败 {file_path}: {e}")
            return None

    @staticmethod
    def set_value(file_path: str, key: str, value: Any) -> Optional[bool]:
        """
        在JSON文件中设置或更新指定键的值。

        :param file_path: JSON文件路径
        :type file_path: str
        :param key: 需要设置或更新的键名
        :type key: str
        :param value: 新的值
        :type value: Any
        :return: 成功时返回True；失败时返回None
        :rtype: Optional[bool]
        
        注意：
        - 如果文件不存在或内容不是有效的JSON，会创建一个新的JSON对象
        - 如果键已经存在，会更新其值
        - 如果键不存在，会添加新的键值对
        """
        logger.info(f"设置JSON文件值: {file_path}, 键: {key}, 值: {value}")
        try:
            try:
                data = JsonUtils.load_json(file_path)  # 加载JSON文件内容
                if data is None:
                    logger.warning(f"JSON文件解析失败，创建新对象: {file_path}")
                    data = {}
            except OSError:
                # 文件不存在，创建新的JSON对象
                logger.info(f"文件不存在，创建新对象: {file_path}")
                data = {}

            data[key] = value  # 更新或添加键值对
            
            # 确保目录存在
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as file:
                json.dump(data, file, ensure_ascii=False, indent=4)
            logger.info(f"JSON文件更新成功: {file_path}")
            return True
        except (OSError, TypeError) as e:
            logger.error(f"更新JSON文件失败 {file_path}: {e}")
            # 捕获文件操作异常和类型错误（如value不可序列化）
            return None

    @staticmethod
    def loads_json_value(value: str) -> Optional[Any]:
        """
        将字符串转换为 JSON 对象。

        :param value: 需要转换的字符串
        :type value: str
        :return: 解析后的 JSON 对象，如果解析失败则返回 None
        :rtype: Optional[Any]
        """
        logger.info(f"开始解析JSON字符串")
        try:
            data = json.loads(value)
            logger.info("JSON字符串解析成功")
            return data
        except (ValueError, TypeError, json.JSONDecodeError) as e:
            logger.warning(f"JSON字符串解析失败: {e}")
            # 捕获各种解析错误并返回 None
            return None

    @staticmethod
    def is_json(value: Any) -> bool:
        """
        判断数据是否是有效的 JSON 格式。

        :param value: 需要判断的数据，可以是字符串或其他类型
        :type value: Any
        :return: 如果是有效的 JSON 格式返回 True，否则返回 False
        :rtype: bool
        
        注意：
        - 如果输入是字符串，会尝试解析为 JSON 对象
        - 如果输入是字典或列表，会尝试序列化为 JSON 字符串
        """
        logger.info(f"判断数据是否为有效的JSON格式")
        try:
            if isinstance(value, str):
                # 如果是字符串，尝试解析为 JSON
                json.loads(value)
                logger.info("字符串是有效的JSON格式")
                return True
            else:
                # 如果是其他类型，尝试序列化为 JSON
                json.dumps(value)
                logger.info("数据是有效的JSON格式")
                return True
        except (ValueError, TypeError, json.JSONDecodeError) as e:
            logger.warning(f"数据不是有效的JSON格式: {e}")
            # 捕获各种 JSON 相关错误
            return False
        
    @staticmethod
    def json_to_markdown(data: Any, level: int = 1) -> str:
        """
        将 JSON 数据或 JSON 字符串转换为 Markdown 文本。

        :param data: JSON 数据（字典或列表）或 JSON 字符串
        :type data: Any
        :param level: 当前标题级别，默认为 1
        :type level: int
        :return: Markdown 文本字符串
        :rtype: str
        
        :raises ValueError: 如果输入不是有效的 JSON 格式
        
        示例用法：
        >>> data = {"name": "测试", "value": 123, "details": {"a": 1, "b": 2}}
        >>> JsonUtils.json_to_markdown(data)
        '# name\n\n- **value**: 123\n\n# details\n\n- **a**: 1\n\n- **b**: 2\n'
        """
        logger.info("开始将JSON转换为Markdown")
        # 如果传入的是字符串，尝试将其解析为 Python 对象
        if isinstance(data, str):
            try:
                data = json.loads(data)
                logger.info("JSON字符串解析成功")
            except json.JSONDecodeError:
                logger.error("无效的 JSON 字符串")
                raise ValueError("无效的 JSON 字符串")

        markdown_lines = []

        def add_heading(text: str, level: int) -> str:
            return f"{'#' * level} {text}"

        def process_dict(d: Dict[str, Any], level: int) -> None:
            for key, value in d.items():
                if isinstance(value, dict):
                    markdown_lines.append(add_heading(key, level))
                    markdown_lines.append("")
                    process_dict(value, level + 1)
                elif isinstance(value, list):
                    markdown_lines.append(add_heading(key, level))
                    markdown_lines.append("")
                    process_list(value, level + 1)
                else:
                    markdown_lines.append(f"- **{key}**: {value}")
                    markdown_lines.append("")

        def process_list(lst: List[Any], level: int) -> None:
            for index, item in enumerate(lst):
                if isinstance(item, dict):
                    markdown_lines.append(add_heading(f"Item {index + 1}", level))
                    markdown_lines.append("")
                    process_dict(item, level + 1)
                elif isinstance(item, list):
                    markdown_lines.append(add_heading(f"List {index + 1}", level))
                    markdown_lines.append("")
                    process_list(item, level + 1)
                else:
                    markdown_lines.append(f"- {item}")
                    markdown_lines.append("")

        if isinstance(data, dict):
            # 处理根级别的字典
            for key, value in data.items():
                markdown_lines.append(add_heading(key, level))
                markdown_lines.append("")
                if isinstance(value, dict):
                    process_dict(value, level + 1)
                elif isinstance(value, list):
                    process_list(value, level + 1)
                else:
                    markdown_lines.append(f"- **{key}**: {value}")
                    markdown_lines.append("")
        elif isinstance(data, list):
            process_list(data, level)
        else:
            logger.error("输入数据必须是字典、列表或有效的 JSON 字符串")
            raise ValueError("输入数据必须是字典、列表或有效的 JSON 字符串")

        markdown = "\n".join(markdown_lines)
        logger.info("JSON转换为Markdown成功")
        return markdown


if __name__ == "__main__":
    # 示例用法
    # 假设有一个名为config.json的JSON文件，我们需要更新键"example_key"的值为"new_value"
    success = JsonUtils.set_value("config.json", "example_key", "new_value")
    logger.info("更新成功" if success else "更新失败")
