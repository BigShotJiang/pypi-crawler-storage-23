#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by：2018-2-23 14:15:57
modify by: 2023-05-17 17:46:40

功能：封装常见文件操作的工具类，包括打开大文件、创建目录、复制目录树、获取目录下的文件列表、更改文件所有权、
      批量重命名文件、单个文件重命名以及压缩与解压文件。
"""
import os
from pathlib import Path
from typing import List
import gzip
import lzma
import shutil
import tarfile
import zipfile
import py7zr
import platform
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()

class FileUtils:
    """
    封装常见文件操作的工具类，包括打开大文件、创建目录、复制目录树、获取目录下的文件列表、更改文件所有权
    """
    @staticmethod
    def open_large_file(filename: str):
        """
        逐行读取大文件，使用生成器避免一次性加载整个文件到内存中。

        :param filename: 要逐行读取的文件路径
        :type filename: str
        :yield: 文件的每一行内容（已去除首尾空白字符）
        :raises OSError: 如果文件无法打开或读取
        """
        logger.info(f"开始逐行读取大文件: {filename}")
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                for line in f:
                    yield line.strip()
            logger.info(f"大文件读取完成: {filename}")
        except OSError as e:
            logger.error(f"读取文件失败: {filename}, 错误: {e}")
            raise

    @staticmethod
    def create_folder(path: str) -> None:
        """
        创建目录，如果目录的上级目录不存在，也会被递归创建。

        :param path: 要创建的目录路径
        :type path: str
        :raises OSError: 如果无法创建目录（如权限不足）
        """
        logger.info(f"开始创建目录: {path}")
        try:
            Path(path).mkdir(parents=True, exist_ok=True)
            logger.info(f"目录创建成功: {path}")
        except OSError as e:
            logger.error(f"创建目录失败: {path}, 错误: {e}")
            raise

    @staticmethod
    def copy(src: str, dst: str, ignore=None, dirs_exist_ok=True) -> None:
        """
        递归地复制一个目录树到指定目录。

        :param src: 源目录的路径。
        :param dst: 目标目录的路径。
        :param ignore: 可选参数, 默认为None。可以是shutil.ignore_patterns()返回的函数，
                      或包含忽略模式的列表/元组，或None表示不忽略任何文件。
        :param dirs_exist_ok: 可选参数，默认为True。当目标目录存在时是否抛出异常。
        
        :raises FileNotFoundError: 如果源目录不存在
        :raises OSError: 如果无法复制目录
        """
        logger.info(f"开始复制目录: 从 {src} 到 {dst}")
        src_path = Path(src)
        dst_path = Path(dst)
        
        if not src_path.exists():
            logger.error(f"源目录不存在: {src}")
            raise FileNotFoundError(f"源目录不存在: {src}")
            
        if ignore and isinstance(ignore, (list, tuple)):
            # 如果ignore是列表或元组，将其转换为shutil.ignore_patterns函数
            ignore = shutil.ignore_patterns(*ignore)

        try:
            # 使用shutil.copytree进行目录复制
            shutil.copytree(src, dst, ignore=ignore, dirs_exist_ok=dirs_exist_ok)
            logger.info(f"目录复制成功: 从 {src} 到 {dst}")
        except OSError as e:
            logger.error(f"复制目录失败: 从 {src} 到 {dst}, 错误: {e}")
            raise

    @staticmethod
    def get_listfile_01(path: str) -> List[str]:
        """
        使用 os.walk() 遍历指定目录，返回目录下所有文件的路径（不包含文件夹）。

        :param path: 指定的目录路径
        :type path: str
        :return: 包含指定目录下所有文件的路径列表
        :rtype: List[str]
        :raises FileNotFoundError: 如果指定的目录不存在
        """
        logger.info(f"开始获取目录文件列表（方法1）: {path}")
        path_obj = Path(path)
        if not path_obj.exists():
            logger.error(f"目录不存在: {path}")
            raise FileNotFoundError(f"目录不存在: {path}")
            
        file_path_list = []
        for root, _, files in os.walk(path):
            file_path_list.extend(os.path.join(root, f) for f in files)

        logger.info(f"获取目录文件列表完成，共 {len(file_path_list)} 个文件")
        return file_path_list

    @staticmethod
    def get_listfile_02(path: str) -> List[str]:
        """
        使用 os.scandir() 递归遍历指定目录，返回目录下所有文件的路径（不包含文件夹）。
        
        os.scandir() 可能相较 os.walk() 性能更高，尤其在列出大量目录内容时。

        :param path: 指定的目录路径
        :type path: str
        :return: 包含指定目录下所有文件的路径列表
        :rtype: List[str]
        :raises FileNotFoundError: 如果指定的目录不存在
        """
        logger.info(f"开始获取目录文件列表（方法2）: {path}")
        path_obj = Path(path)
        if not path_obj.exists():
            logger.error(f"目录不存在: {path}")
            raise FileNotFoundError(f"目录不存在: {path}")
            
        file_path_list = []
        
        def scan_dir(dir_path):
            for entry in os.scandir(dir_path):
                if entry.is_file():
                    file_path_list.append(entry.path)
                # 如果entry是文件夹，则递归调用scan_dir()来扫描其内部
                elif entry.is_dir():
                    scan_dir(entry.path)

        scan_dir(path)
        logger.info(f"获取目录文件列表完成，共 {len(file_path_list)} 个文件")
        return file_path_list

    @staticmethod
    def get_listfile_03(path: str, include_files: bool = True, include_dirs: bool = False) -> List[str]:
        """获取指定目录下的所有文件和/或文件夹列表。

        :param path: 目标文件夹路径
        :type path: str
        :param include_files: 是否包含文件，默认值为 True
        :type include_files: bool
        :param include_dirs: 是否包含子文件夹，默认值为 False
        :type include_dirs: bool
        :return: 包含指定目录下的文件或文件夹路径的列表
        :rtype: List[str]
        :raises FileNotFoundError: 如果指定的目录不存在
        :raises ValueError: 如果 include_files 和 include_dirs 都为 False
        """
        logger.info(f"开始获取目录文件列表（方法3）: {path}, 包含文件: {include_files}, 包含目录: {include_dirs}")
        path_obj = Path(path)
        if not path_obj.exists():
            logger.error(f"目录不存在: {path}")
            raise FileNotFoundError(f"目录不存在: {path}")

        file_list = []
        dir_list = []

        for root, dirs, files in os.walk(path, topdown=False):
            if include_files:
                file_list.extend([os.path.join(root, f) for f in files])
            if include_dirs:
                dir_list.extend([os.path.join(root, d) for d in dirs])

        if include_files and include_dirs:
            result = [*file_list, *dir_list]
            logger.info(f"获取目录文件和目录列表完成，共 {len(result)} 个项目")
            return result
        elif include_files:
            logger.info(f"获取目录文件列表完成，共 {len(file_list)} 个文件")
            return file_list
        elif include_dirs:
            logger.info(f"获取目录列表完成，共 {len(dir_list)} 个目录")
            return dir_list
        else:
            logger.error("至少需要包含文件或文件夹中的一种")
            raise ValueError("至少需要包含文件或文件夹中的一种")

    @staticmethod
    def change_owner(src: str, uid: int, gid: int, loop: bool = False) -> None:
        """
        更改指定文件或目录的所有者（UID）和所属组（GID）。

        :param src: 要更改所有权的文件或目录路径
        :type src: str
        :param uid: 新的所有者用户 ID
        :type uid: int
        :param gid: 新的所属组 ID
        :type gid: int
        :param loop: 是否递归处理子文件和子目录，默认值为 False
        :type loop: bool
        
        :raises OSError: 如果在 Windows 系统上调用此方法
        :raises FileNotFoundError: 如果指定的文件或目录不存在
        :raises PermissionError: 如果没有足够的权限更改所有权
        
        注意事项：
        - 此方法仅在 Linux/macOS 系统上有效，Windows 系统不支持
        - 递归处理时会忽略符号链接，避免不可预期的后果
        - 需要 root 权限或相应的文件系统权限
        
        示例用法：
        >>> FileUtils.change_owner('/path/to/file.txt', 1000, 1000)
        >>> FileUtils.change_owner('/path/to/dir', 1000, 1000, loop=True)
        """
        logger.info(f"开始更改文件/目录所有权: {src}, UID: {uid}, GID: {gid}, 递归: {loop}")
        if platform.system().lower() == 'windows':
            logger.error('Windows 系统无法设置文件或目录的所有者')
            raise OSError('Windows 系统无法设置文件或目录的所有者')
        
        src_path = Path(src)
        if not src_path.exists():
            logger.error(f"文件或目录不存在: {src}")
            raise FileNotFoundError(f"文件或目录不存在: {src}")
            
        try:
            if src_path.is_file():
                os.chown(src, uid, gid)
                logger.info(f"文件所有权更改成功: {src}")
            elif src_path.is_dir() and loop:
                for dirpath, dirnames, filenames in os.walk(src):
                    # 处理子目录
                    for dirname in dirnames:
                        filepath = os.path.join(dirpath, dirname)
                        if os.path.islink(filepath):  # 如果是符号链接，则跳过
                            continue
                        os.chown(filepath, uid, gid)
                    
                    # 处理文件
                    for filename in filenames:
                        filepath = os.path.join(dirpath, filename)
                        if os.path.islink(filepath):  # 如果是符号链接，则跳过
                            continue
                        os.chown(filepath, uid, gid)
                logger.info(f"目录及其子内容所有权更改成功: {src}")
        except PermissionError as e:
            logger.error(f"更改所有权失败: {src}, 错误: {e}")
            raise
        except OSError as e:
            logger.error(f"更改所有权失败: {src}, 错误: {e}")
            raise

    @staticmethod
    def rename_files(file_lists: List[str], file_prefix: str = "", file_suffix: int = 1) -> None:
        """
        批量重命名文件。

        :param file_lists: 要重命名的文件列表，即包含多个文件路径的字符串列表
        :type file_lists: List[str]
        :param file_prefix: 新文件名的前缀，默认为空字符串
        :type file_prefix: str
        :param file_suffix: 新文件名的起始序号，必须为正整数，默认为1
        :type file_suffix: int
        :return: None
        
        :raises ValueError: 如果 file_suffix 不是正整数
        :raises FileNotFoundError: 如果列表中的文件不存在
        :raises OSError: 如果重命名操作失败
        
        示例用法：
        >>> file_list = ["file1.txt", "file2.txt", "file3.txt"]
        >>> FileUtils.rename_files(file_list, "new_", 10)
        # 结果：new_010.txt, new_011.txt, new_012.txt
        """
        logger.info(f"开始批量重命名文件，共 {len(file_lists)} 个文件")
        if not isinstance(file_suffix, int) or file_suffix <= 0:
            logger.error(f"file_suffix 必须是正整数，当前值: {file_suffix}")
            raise ValueError("file_suffix must be a positive integer")

        original_files = []  # 保存原始文件路径和新文件名的映射

        try:
            for i, file_path in enumerate(file_lists):
                # 检查文件是否存在
                if not os.path.exists(file_path):
                    logger.error(f"文件不存在: {file_path}")
                    raise FileNotFoundError(f"文件不存在: {file_path}")
                    
                # 获取文件扩展名
                _, file_ext = os.path.splitext(file_path)
                # 构造新文件名
                new_name = f"{file_prefix}{file_suffix + i:03d}{file_ext}"
                # 获取文件所在目录
                dir_path = os.path.dirname(file_path)
                # 构造完整的新文件路径
                new_path = os.path.join(dir_path, new_name) if dir_path else new_name
                
                original_files.append((file_path, new_path))

            # 执行重命名操作
            for old_path, new_path in original_files:
                os.rename(old_path, new_path)
                logger.info(f"文件重命名成功: {old_path} -> {new_path}")
                
        except Exception as e:
            # 回滚所有已完成的重命名操作
            for old_path, new_path in original_files:
                if os.path.exists(new_path):
                    try:
                        os.rename(new_path, old_path)
                        logger.info(f"文件重命名回滚: {new_path} -> {old_path}")
                    except Exception:
                        pass  # 忽略回滚时的错误
            logger.error(f"批量重命名失败: {e}")
            raise OSError(f"批量重命名失败: {e}") from e


    @staticmethod
    def rename_file(old_path: str, new_path: str) -> None:
        """
        重命名单个文件。

        :param old_path: 原文件路径
        :type old_path: str
        :param new_path: 新文件路径
        :type new_path: str
        
        :raises FileNotFoundError: 如果原文件不存在
        :raises FileExistsError: 如果新路径的文件已存在
        :raises OSError: 如果重命名操作失败
        """
        logger.info(f"开始重命名文件: {old_path} -> {new_path}")
        old_path_obj = Path(old_path)
        new_path_obj = Path(new_path)
        
        if not old_path_obj.exists():
            logger.error(f"原文件不存在: {old_path}")
            raise FileNotFoundError(f"原文件不存在: {old_path}")
            
        if new_path_obj.exists():
            logger.error(f"新文件已存在: {new_path}")
            raise FileExistsError(f"新文件已存在: {new_path}")
            
        try:
            old_path_obj.rename(new_path_obj)
            logger.info(f"文件重命名成功: {old_path} -> {new_path}")
        except OSError as e:
            logger.error(f"重命名失败: {e}")
            raise OSError(f"重命名失败: {e}") from e

#############
####  压缩包方法       
#############

def get_compress_types():
    """
    返回支持的压缩类型与相应打开文件的函数和模式。

    :return: 压缩类型与函数、模式的映射字典。
    """
    # 需要导入 bz2 模块
    import bz2
    
    return {
        "gz": (gzip.open, 'wb'),    # .gz 文件使用 gzip.open 打开，并以写入二进制模式
        "bz2": (bz2.open, 'wb'),    # .bz2 文件使用 bz2.open 打开，并以写入二进制模式
        "xz": (lzma.open, 'wb'),    # .xz 文件使用 lzma.open 打开，并以写入二进制模式
        "zip": (zipfile.ZipFile, 'w'),  # .zip 文件使用 ZipFile 打开，并以写入模式
        "7z": (py7zr.SevenZipFile, 'w')  # .7z 文件使用 SevenZipFile 打开，并以写入模式
    }

def get_compression_formats():
    """
    返回支持的压缩格式对应的 tarfile 模式。

    :return: 压缩类型与 tarfile 模式的映射字典。
    """
    return {
        "gz": "r:gz",   # .gz 文件采用 "r:gz" 解压格式
        "tgz": "r:gz",  # .tgz 文件也采用 "r:gz" 解压格式
        "bz2": "r:bz2", # .bz2 文件采用 "r:bz2" 解压格式
        "xz": "r:xz",   # .xz 文件采用 "r:xz" 解压格式
        "zip": None,     # .zip 文件不需要指定 tarfile 格式（使用 zipfile 模块）
        "7z": None       # .7z 文件不需要指定 tarfile 格式（使用 py7zr 模块）
    }

class ZipFilesUtils:
    """
    压缩与解压缩工具类
    """
    @staticmethod
    def compress_file(source_path: str, target_path: str, compress_type: str = "gz") -> None:
        """
        将指定文件进行压缩。

        :param source_path: 要压缩的文件路径
        :type source_path: str
        :param target_path: 压缩文件保存路径
        :type target_path: str
        :param compress_type: 压缩类型，支持 gz, bz2, xz, zip, 7z
        :type compress_type: str
        
        :raises FileNotFoundError: 如果源文件不存在
        :raises ValueError: 如果压缩类型不受支持
        :raises OSError: 如果压缩操作失败
        """
        logger.info(f"开始压缩文件: {source_path} -> {target_path}, 压缩类型: {compress_type}")
        source_path_obj = Path(source_path)
        if not source_path_obj.exists():
            logger.error(f"源文件不存在: {source_path}")
            raise FileNotFoundError(f"源文件不存在: {source_path}")
            
        compress_types = get_compress_types()
        compress_func, mode = compress_types.get(compress_type.lower(), (None, None))
        
        if compress_func is None:
            supported_types = ', '.join(compress_types.keys())
            logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
            raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
            
        try:
            if compress_type.lower() == "zip":
                # ZipFile 需要使用 writestr 方法
                with zipfile.ZipFile(target_path, 'w') as f_out:
                    with open(source_path, 'rb') as f_in:
                        f_out.writestr(source_path_obj.name, f_in.read())
            elif compress_type.lower() == "7z":
                # py7zr 需要使用 write 方法
                with py7zr.SevenZipFile(target_path, 'w') as f_out:
                    f_out.write(source_path, source_path_obj.name)
            elif compress_type.lower() in ["gz", "bz2", "xz"]:
                # 对于 gz, bz2, xz 格式，需要先创建 tar 文件
                import tarfile
                with tarfile.open(target_path, f'w:{compress_type}') as tar:
                    tar.add(source_path, arcname=source_path_obj.name)
            else:
                # 其他压缩格式
                with open(source_path, 'rb') as f_in, compress_func(target_path, mode) as f_out:
                    shutil.copyfileobj(f_in, f_out)
            logger.info(f"文件压缩成功: {target_path}")
        except OSError as e:
            logger.error(f"压缩文件失败: {source_path} -> {target_path}, 错误: {e}")
            raise

    @staticmethod
    def extract_file(file_path: str, extract_path: str, compress_type: str = None) -> None:
        """
        将压缩文件解压到指定目录。

        :param file_path: 压缩文件路径
        :type file_path: str
        :param extract_path: 解压缩目标目录
        :type extract_path: str
        :param compress_type: 压缩文件类型，如果为 None 则自动检测
        :type compress_type: str
        
        :raises FileNotFoundError: 如果压缩文件不存在
        :raises ValueError: 如果压缩类型不受支持
        :raises OSError: 如果解压操作失败
        """
        logger.info(f"开始解压文件: {file_path} -> {extract_path}")
        file_path_obj = Path(file_path)
        extract_path_obj = Path(extract_path)
        
        # 检查压缩文件是否存在
        if not file_path_obj.exists():
            logger.error(f"压缩文件不存在: {file_path}")
            raise FileNotFoundError(f"压缩文件不存在: {file_path}")
            
        # 创建目标目录
        extract_path_obj.mkdir(parents=True, exist_ok=True)
        logger.info(f"创建解压目标目录: {extract_path}")
        
        # 如果未指定压缩类型，尝试从文件名中推断
        if not compress_type:
            suffix = file_path_obj.suffix.lower()
            if suffix == '.gz' or suffix == '.tgz':
                compress_type = 'gz'
            elif suffix == '.bz2':
                compress_type = 'bz2'
            elif suffix == '.xz':
                compress_type = 'xz'
            elif suffix == '.zip':
                compress_type = 'zip'
            elif suffix == '.7z':
                compress_type = '7z'
            else:
                logger.error(f"无法从文件名推断压缩类型: {file_path}")
                raise ValueError(f"无法从文件名推断压缩类型: {file_path}")
        
        compress_type = compress_type.lower()
        compression_formats = get_compression_formats()
        compression_format = compression_formats.get(compress_type)
        
        try:
            if compression_format is None:
                if compress_type == "zip":
                    with zipfile.ZipFile(file_path) as zfile:
                        zfile.extractall(extract_path)  # 对于 zip 文件，使用 extractall() 方法进行解压
                        logger.info(f"ZIP文件解压成功: {file_path} -> {extract_path}")
                elif compress_type == "7z":
                    with py7zr.SevenZipFile(file_path, mode='r') as sfile:
                        sfile.extractall(path=extract_path)  # 对于 7z 文件，使用 extractall() 方法进行解压
                        logger.info(f"7z文件解压成功: {file_path} -> {extract_path}")
                else:
                    supported_types = ', '.join(compression_formats.keys())
                    logger.error(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
                    raise ValueError(f"不支持的压缩类型: {compress_type}，支持的类型包括: {supported_types}")
            else:
                try:
                    with tarfile.open(file_path, compression_format) as tar:
                        def safe_member_filter(member, path):
                            # 使用 `isreg` 来检查是否是常规文件，如果不是常规文件则返回 None
                            return member if member.isreg() else None
                        
                        # 使用 `filter` 参数来确保安全提取
                        tar.extractall(path=extract_path, filter=safe_member_filter)
                        logger.info(f"压缩文件解压成功: {file_path} -> {extract_path}")
                except (tarfile.ReadError, OSError) as e:
                    logger.error(f"解压文件失败: {file_path} -> {extract_path}, 错误: {e}")
                    raise ValueError(f"解压失败: {str(e)}")
        except OSError as e:
            logger.error(f"解压文件失败: {file_path} -> {extract_path}, 错误: {e}")
            raise
