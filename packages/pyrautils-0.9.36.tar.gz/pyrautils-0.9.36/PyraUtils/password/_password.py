#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by: 2024-03-18
modify by: 2024-03-18

功能：密码生成和强度检查工具类。
"""

import secrets
import string
from typing import Optional, Set
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class PasswordMaker:
    """
    密码生成器类，用于生成安全的随机密码。
    
    示例用法：
    >>> from PyraUtils.password._password import PasswordMaker
    >>> 
    >>> # 生成默认长度（10位）的随机密码
    >>> password = PasswordMaker.make_random_password()
    >>> print(password)
    >>> 
    >>> # 生成指定长度（16位）的随机密码
    >>> password = PasswordMaker.make_random_password(length=16)
    >>> print(password)
    >>> 
    >>> # 生成仅包含字母和数字的随机密码
    >>> password = PasswordMaker.make_random_password(allowed_chars=string.ascii_letters + string.digits)
    >>> print(password)
    """
    
    @staticmethod
    def make_random_password(length: int = 10, allowed_chars: Optional[str] = None) -> str:
        """
        生成一个随机密码。

        :param length: 指定生成密码的长度，默认为10
        :type length: int
        :param allowed_chars: 指定可用于构造密码的字符集合。如果未指定，则使用默认的安全字符集
        :type allowed_chars: Optional[str]
        :return: 一个随机生成的密码字符串
        :rtype: str
        :raises ValueError: 如果长度小于1
        """
        logger.info(f"开始生成随机密码，长度: {length}")
        if length < 1:
            logger.error("密码长度必须大于0")
            raise ValueError("密码长度必须大于0")
            
        # 如果没有指定允许的字符集合，则使用默认的安全字符集
        if not allowed_chars:
            allowed_chars = string.ascii_letters + string.digits + string.punctuation
            logger.debug("使用默认安全字符集")
        else:
            logger.debug("使用自定义字符集")
            
        # 生成随机密码直到达到需要的长度
        password = ''.join(secrets.choice(allowed_chars) for _ in range(length))
        logger.info("随机密码生成成功")
        # 注意：不要记录密码本身，避免安全风险
        return password


class PasswordStrength:
    """
    密码强度检查器类，用于评估密码强度和检测弱密码。
    
    弱口令字典推荐地址: 
    - https://github.com/wwl012345/PasswordDic
    - https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt
    
    示例用法：
    >>> from PyraUtils.password._password import PasswordStrength
    >>> 
    >>> # 初始化密码强度检查器（使用弱密码字典）
    >>> strength_checker = PasswordStrength(words_path='path/to/weak_passwords.txt')
    >>> 
    >>> # 检查密码是否为弱密码
    >>> is_weak = strength_checker.is_weak_password('password123')
    >>> print(f"密码是否为弱密码: {is_weak}")
    >>> 
    >>> # 检查密码强度
    >>> strength = strength_checker.password_strength('My$trongP@ssw0rd123')
    >>> print(f"密码强度: {strength}")
    """
    
    def __init__(self, words_path: Optional[str] = None):
        """
        初始化 PasswordStrength 对象。

        :param words_path: 弱口令字典文件路径。如果不提供，则需要后续手动设置 word_set 属性
        :type words_path: Optional[str]
        :raises FileNotFoundError: 如果指定的文件不存在
        """
        self.word_set: Set[str] = set()
        if words_path:
            logger.info(f"开始加载弱密码字典: {words_path}")
            try:
                with open(words_path, 'r', encoding='utf-8') as f:
                    # 从给定文件中读取并存储弱密码库
                    self.word_set.update(line.strip().lower() for line in f)
                logger.info(f"弱密码字典加载成功，共 {len(self.word_set)} 条记录")
            except FileNotFoundError:
                logger.error(f"弱口令字典不存在: {words_path}")
                raise FileNotFoundError(
                    "弱口令字典不存在，请下载以下字典：\n"
                    "- https://github.com/wwl012345/PasswordDic\n"
                    "- https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt"
                )

    def is_weak_password(self, pw_str: str) -> bool:
        """
        根据预定义的弱口令字典检测密码是否弱。

        :param pw_str: 要检测的密码字符串
        :type pw_str: str
        :return: 如果密码被认为是弱密码返回 True，否则返回 False
        :rtype: bool
        :raises ValueError: 如果弱密码字典未加载
        """
        logger.info("开始检查密码是否为弱密码")
        if not self.word_set:
            logger.error("弱密码字典未加载")
            raise ValueError("弱密码字典未加载，请初始化时提供字典路径或手动设置 word_set 属性")
        
        is_weak = pw_str.lower() in self.word_set
        if is_weak:
            logger.warning("检测到弱密码")
        else:
            logger.info("密码不在弱密码字典中")
        return is_weak

    def password_strength(self, pw_str: str) -> str:
        """
        评估密码的复杂度，并根据结果分类。

        :param pw_str: 要评估的密码字符串
        :type pw_str: str
        :return: 密码的强度等级（'WEAK', 'MEDIUM', 'STRONG'）
        :rtype: str
        """
        logger.info("开始评估密码强度")
        # 检查密码长度和是否为弱密码
        if len(pw_str) < 8:
            logger.info("密码强度: WEAK (长度不足8位)")
            return 'WEAK'
            
        try:
            if self.is_weak_password(pw_str):
                logger.info("密码强度: WEAK (在弱密码字典中)")
                return 'WEAK'
        except ValueError:
            # 如果弱密码字典未加载，跳过弱密码检查
            logger.debug("弱密码字典未加载，跳过弱密码检查")
            pass
        
        # 计算密码中包含的不同字符类别数量
        char_classes = [
            string.ascii_lowercase,  # 小写字母
            string.ascii_uppercase,  # 大写字母
            string.digits,           # 数字
            string.punctuation       # 标点符号
        ]
        
        strength_score = sum(1 for char_class in char_classes if any(c in pw_str for c in char_class))
        
        # 根据长度和字符类别数量判断密码强度
        if len(pw_str) >= 12 and strength_score >= 3:
            logger.info("密码强度: STRONG")
            return 'STRONG'
        elif len(pw_str) >= 8 and strength_score >= 2:
            logger.info("密码强度: MEDIUM")
            return 'MEDIUM'
        else:
            logger.info("密码强度: WEAK")
            return 'WEAK'