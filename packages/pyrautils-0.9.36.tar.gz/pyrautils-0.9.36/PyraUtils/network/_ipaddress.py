#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by：2022-07-28 16:17:47
modify by: 2024-03-18 19:34:04

功能描述：封装 ipaddress 库的函数，进行 IP 地址相关操作。
"""
import socket
import ipaddress
from typing import List, Optional, Union
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class IpaddressUtils:
    """IP 地址实用工具类，提供验证 IP 地址和网络地址有效性的方法。
    
    封装了 Python 标准库中的 ipaddress 模块，提供更便捷的 IP 地址验证、
    网络地址验证和本地 IP 地址获取功能。
    """
    
    def __init__(self) -> None:
        """初始化 IP 地址工具类。"""
        logger.info("IpaddressUtils 初始化成功")
        pass

    def _ip_network(self, network: str) -> ipaddress.IPv4Network | ipaddress.IPv6Network:
        """
        验证网络地址是否合法。
        
        :param network: 网络地址字符串（如 '192.168.1.0/24'）
        :type network: str
        :return: 合法的网络地址对象
        :rtype: Union[ipaddress.IPv4Network, ipaddress.IPv6Network]
        :raises ValueError: 如果网络地址无效
        """
        logger.info(f"开始验证网络地址: {network}")
        try:
            network_obj = ipaddress.ip_network(network)
            logger.info(f"网络地址验证成功: {network}")
            return network_obj
        except ValueError as e:
            logger.error(f"网络地址验证失败: {network}, 错误: {e}")
            raise ValueError(f"Invalid network address '{network}': {e}")

    def _ip_address(self, address: str) -> ipaddress.IPv4Address | ipaddress.IPv6Address:
        """
        验证 IP 地址是否合法。
        
        :param address: IP 地址字符串（如 '192.168.1.1'）
        :type address: str
        :return: 合法的 IP 地址对象
        :rtype: Union[ipaddress.IPv4Address, ipaddress.IPv6Address]
        :raises ValueError: 如果 IP 地址无效
        """
        logger.info(f"开始验证 IP 地址: {address}")
        try:
            address_obj = ipaddress.ip_address(address)
            logger.info(f"IP 地址验证成功: {address}")
            return address_obj
        except ValueError as e:
            logger.error(f"IP 地址验证失败: {address}, 错误: {e}")
            raise ValueError(f"Invalid IP address '{address}': {e}")

    def check_ipaddress(self, address: str, network_list: Optional[List[str]] = None) -> bool:
        """
        验证给定的 IP 地址是否属于指定的网络地址列表中的任意一个。

        :param address: 要验证的 IP 地址字符串
        :type address: str
        :param network_list: 网络地址字符串列表，默认值为 None
        :type network_list: Optional[List[str]]
        :return: 如果 IP 地址属于网络列表中的任意网络，返回 True，否则返回 False
        :rtype: bool
        :raises ValueError: 如果 IP 地址或网络地址无效
        """
        logger.info(f"开始检查 IP 地址: {address} 是否在网络列表中")
        if not network_list:
            logger.info("网络列表为空，返回 False")
            return False
            
        valid_address = self._ip_address(address)
        
        for network_str in network_list:
            network = self._ip_network(network_str)
            if valid_address in network:
                logger.info(f"IP 地址 {address} 在网络 {network_str} 中")
                return True
        logger.info(f"IP 地址 {address} 不在任何指定网络中")
        return False

    def get_internal_ip(self) -> str:
        """
        获取本地内网 IP 地址。

        :return: 本地内网 IP 地址字符串
        :rtype: str
        :raises RuntimeError: 如果无法获取内网 IP 地址
        """
        logger.info("开始获取本地内网 IP 地址")
        # 使用 UDP 协议获取内网 IP，不会实际发送数据
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                # 连接到一个公共 IP 地址（不会实际建立连接）
                s.connect(('10.255.255.255', 1))
                internal_ip = s.getsockname()[0]
            logger.info(f"获取本地内网 IP 地址成功: {internal_ip}")
            return internal_ip
        except Exception as e:
            logger.error(f"获取本地内网 IP 地址失败: {e}")
            raise RuntimeError(f"无法获取内网IP地址: {e}")
