#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by：2024-03-06
modify by: 2024-03-06

功能：MAC地址相关的基础方法
"""

import re
from typing import Optional
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class MacHandler:
    """
    MAC 地址处理工具类，提供 MAC 地址验证和标准化功能。
    
    支持常见的 MAC 地址格式：
    - 00:11:22:33:44:55（冒号分隔）
    - 00-11-22-33-44-55（连字符分隔）
    - 001122334455（无分隔符）
    """
    
    def standardize_mac_address(self, mac: str) -> str:
        """
        将 MAC 地址标准化为冒号分隔的大写格式。
        
        :param mac: MAC 地址字符串
        :type mac: str
        :return: 标准化后的 MAC 地址（如：00:11:22:33:44:55）
        :rtype: str
        :raises ValueError: 如果 MAC 地址无效
        """
        logger.info(f"开始标准化 MAC 地址: {mac}")
        try:
            # 移除所有非十六进制字符进行清洗
            sanitized_mac = re.sub(r'[^0-9A-Fa-f]', '', mac)
            
            if len(sanitized_mac) != 12:
                logger.error(f"MAC 地址长度无效: {mac}")
                raise ValueError(f"Invalid MAC address length: {mac}")
            
            # 将 MAC 地址格式化为冒号分隔的格式
            colon_separated_mac = ':'.join(sanitized_mac[i:i+2] for i in range(0, 12, 2))
            
            # 转换为大写
            standardized_mac = colon_separated_mac.upper()
            logger.info(f"MAC 地址标准化成功: {standardized_mac}")
            return standardized_mac
        except Exception as e:
            logger.error(f"处理 MAC 地址失败: {mac}, 错误: {e}")
            raise ValueError(f"Error processing MAC address '{mac}': {e}")

    def is_valid_mac_address(self, mac: str) -> bool:
        """
        验证 MAC 地址是否有效。
        
        支持的格式：
        - 00:11:22:33:44:55（冒号分隔）
        - 00-11-22-33-44-55（连字符分隔）
        - 001122334455（无分隔符）
        
        :param mac: MAC 地址字符串
        :type mac: str
        :return: 如果 MAC 地址有效返回 True，否则返回 False
        :rtype: bool
        """
        logger.info(f"开始验证 MAC 地址: {mac}")
        # 删除 MAC 地址字符串前后的空格
        mac = mac.strip()
        
        # 支持无分隔符、冒号分隔和连字符分隔的 MAC 地址格式
        patterns = [
            r'^[0-9A-Fa-f]{12}$',  # 无分隔符：001122334455
            r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$',  # 冒号分隔：00:11:22:33:44:55
            r'^([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}$'   # 连字符分隔：00-11-22-33-44-55
        ]
        
        for pattern in patterns:
            if re.match(pattern, mac):
                logger.info(f"MAC 地址验证成功: {mac}")
                return True
        logger.info(f"MAC 地址验证失败: {mac}")
        return False