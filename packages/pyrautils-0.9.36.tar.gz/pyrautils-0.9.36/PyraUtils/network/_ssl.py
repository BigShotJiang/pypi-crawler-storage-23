#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
created by: 2024-03-18
modify by: 2024-03-18

功能：SSL 证书检查工具类，提供证书格式验证和过期时间检查功能。
"""

import os
import datetime
from typing import Tuple, Optional
from OpenSSL import crypto
from PyraUtils.log import LoguruHandler

# 创建模块级别的 logger 实例
logger = LoguruHandler()


class CheckSSLCert:
    """
    SSL 证书检查工具类，提供证书格式验证和过期时间检查功能。
    
    示例用法：
    >>> from PyraUtils.network._ssl import CheckSSLCert
    >>> 
    >>> # 检查证书是否为 PEM 格式
    >>> is_pem = CheckSSLCert.is_pem_format('path/to/cert.pem')
    >>> print(f"证书是否为 PEM 格式: {is_pem}")
    >>> 
    >>> # 检查证书是否将在 30 天内过期
    >>> is_expiring, start_date, error = CheckSSLCert.check_ssl_cert_expiry('path/to/cert.pem', days=30)
    >>> if error:
    >>>     print(f"检查失败: {error}")
    >>> else:
    >>>     print(f"证书是否即将过期: {is_expiring}")
    >>>     print(f"证书开始日期: {start_date}")
    """
    
    @staticmethod
    def is_pem_format(cert_path: str) -> bool:
        """
        检查给定路径的证书文件是否为有效的 PEM 格式。

        :param cert_path: 证书文件的路径
        :type cert_path: str
        :return: 布尔值，表示是否为有效的 PEM 格式
        :rtype: bool
        :raises FileNotFoundError: 如果证书文件不存在
        """
        logger.info(f"开始检查证书是否为 PEM 格式: {cert_path}")
        if not os.path.exists(cert_path):
            logger.error(f"证书文件不存在: {cert_path}")
            raise FileNotFoundError(f"证书文件不存在: {cert_path}")

        try:
            with open(cert_path, 'rb') as cert_file:
                cert_content = cert_file.read()
            # 尝试加载证书内容
            crypto.load_certificate(crypto.FILETYPE_PEM, cert_content)
            logger.info(f"证书 {cert_path} 是有效的 PEM 格式")
            return True
        except crypto.Error:
            # 如果加载失败，则不是有效的 PEM 格式
            logger.info(f"证书 {cert_path} 不是有效的 PEM 格式")
            return False

    @staticmethod
    def check_ssl_cert_expiry(cert_path: str, days: int = 30) -> Tuple[bool, Optional[datetime.datetime], Optional[str]]:
        """
        检查给定路径的 SSL 证书是否将在指定天数内过期。

        :param cert_path: 包含 SSL 证书的路径
        :type cert_path: str
        :param days: 相对于当前日期，考虑为即将过期的天数阈值
        :type days: int
        :return: 元组 (即将过期的布尔值, 证书开始日期, 错误信息)
        :rtype: Tuple[bool, Optional[datetime.datetime], Optional[str]]
        """
        logger.info(f"开始检查证书过期时间: {cert_path}, 阈值: {days}天")
        if not os.path.exists(cert_path):
            error_msg = f"证书文件不存在于路径 {cert_path}"
            logger.error(error_msg)
            return False, None, error_msg

        try:
            # 读取证书内容
            with open(cert_path, 'rb') as cert_file:
                cert_content = cert_file.read()

            # 加载证书
            cert = crypto.load_certificate(crypto.FILETYPE_PEM, cert_content)

            # 获取证书创建时间
            before_date = datetime.datetime.strptime(cert.get_notBefore().decode('ascii'), '%Y%m%d%H%M%SZ')
            
            # 获取证书过期时间
            expiration_date = datetime.datetime.strptime(cert.get_notAfter().decode('ascii'), '%Y%m%d%H%M%SZ')
            # 计算当前时间与过期时间的差值
            remaining = expiration_date - datetime.datetime.utcnow()

            # 判断是否快到期
            is_expiring = remaining < datetime.timedelta(days=days)
            if is_expiring:
                logger.warning(f"证书 {cert_path} 将在 {remaining.days} 天内过期")
            else:
                logger.info(f"证书 {cert_path} 有效期还有 {remaining.days} 天")
            return is_expiring, before_date, None
        except Exception as e:
            error_msg = str(e)
            logger.error(f"检查证书过期时间失败: {cert_path}, 错误: {error_msg}")
            return False, None, error_msg