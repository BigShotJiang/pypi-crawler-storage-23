PyraUtils
=========

|PyPI version| |Python versions| |License| |Build Status|

.. |PyPI version| image:: https://img.shields.io/pypi/v/PyraUtils.svg
   :target: https://pypi.org/project/PyraUtils/
.. |Python versions| image:: https://img.shields.io/pypi/pyversions/PyraUtils.svg
   :target: https://pypi.org/project/PyraUtils/
.. |License| image:: https://img.shields.io/pypi/l/PyraUtils.svg
   :target: https://github.com/yourusername/PyraUtils/blob/main/LICENSE
.. |Build Status| image:: https://img.shields.io/github/actions/workflow/status/yourusername/PyraUtils/ci.yml?branch=main
   :target: https://github.com/yourusername/PyraUtils/actions

PyraUtils 是一个功能丰富的 Python 工具类库，提供了日志、HTTP请求、文件操作、数据库、JWT认证、企业微信API等常用功能的封装。

特性
----

- 📝 **日志模块** - 基于 loguru 和 logging 的统一日志处理
- 🌐 **HTTP请求** - 封装 httpx 和 requests，支持重试、超时、代理
- 🔐 **JWT认证** - JWT 令牌生成、验证、装饰器认证
- 📁 **文件操作** - 文件压缩解压、下载、同步
- 🗄️ **数据库** - SQLAlchemy 和 SQLite3 封装
- 📧 **邮件发送** - SMTP 邮件发送封装
- 🔒 **密码处理** - 密码哈希、验证、强度测试
- 📱 **企业微信** - 企业微信 API 封装
- 🔑 **签名生成** - HMAC、Hash 签名生成
- 🌍 **网络工具** - IP地址、MAC地址、SSL证书处理

安装
----

使用 pip 安装::

    pip install PyraUtils

或使用 pipenv::

    pipenv install PyraUtils

快速开始
--------

日志模块
~~~~~~~~

.. code-block:: python

    from PyraUtils.log import LoguruHandler

    # 创建日志处理器
    logger = LoguruHandler()
    log = logger.get_logger("myapp", "app.log")

    log.info("这是一条信息日志")
    log.warning("这是一条警告日志")
    log.error("这是一条错误日志")

HTTP 请求
~~~~~~~~~

.. code-block:: python

    from PyraUtils.http import RequestUtils

    # GET 请求
    response = RequestUtils.get("https://api.example.com/data")
    print(response.json())

    # POST 请求
    response = RequestUtils.post(
        "https://api.example.com/submit",
        json={"key": "value"}
    )

JWT 认证
~~~~~~~~

.. code-block:: python

    from PyraUtils.http import JWT

    # 创建 JWT 实例
    jwt = JWT(secret_key="your-secret-key")

    # 生成令牌
    token = jwt.jwt_encode({"user_id": 123, "username": "test"})

    # 验证令牌
    is_valid, result = jwt.jwt_decode(token)

文件操作
~~~~~~~~

.. code-block:: python

    from PyraUtils.common import FileUtils, ZipFilesUtils

    # 获取文件列表
    files = FileUtils.get_listfile_01("./directory")

    # 压缩文件
    ZipFilesUtils.compress_file("source.txt", "archive.gz", "gz")

    # 解压文件
    ZipFilesUtils.extract_file("archive.gz", "./extract_dir")

数据库操作
~~~~~~~~~~

.. code-block:: python

    from PyraUtils.db import SQLiteUtils

    # 创建数据库连接
    db = SQLiteUtils("database.db")

    # 执行查询
    results = db.execute_query("SELECT * FROM users WHERE id = ?", (1,))

企业微信
~~~~~~~~

.. code-block:: python

    from PyraUtils.service.work_wechat import CorpApi

    # 初始化 API
    api = CorpApi(corpid="your_corp_id", corpsecret="your_secret")

    # 获取用户信息
    user_info = api.get_user("user_id")

模块列表
--------

* ``PyraUtils.log`` - 日志处理 (Loguru/Logging)
* ``PyraUtils.http`` - HTTP请求、JWT认证、OAuth2
* ``PyraUtils.common`` - 文件操作、下载、压缩、时间处理、字符串
* ``PyraUtils.db`` - 数据库操作 (SQLAlchemy/SQLite)
* ``PyraUtils.network`` - 网络工具 (IP/MAC/SSL)
* ``PyraUtils.password`` - 密码处理、哈希验证
* ``PyraUtils.service`` - 第三方服务集成 (企业微信)
* ``PyraUtils.signature`` - 签名生成 (HMAC/Hash)

开发环境
--------

克隆仓库并安装开发依赖::

    git clone https://github.com/yourusername/PyraUtils.git
    cd PyraUtils
    pip install -e ".[dev]"

运行测试::

    pytest

代码检查::

    flake8 PyraUtils tests
    black --check PyraUtils tests
    isort --check-only PyraUtils tests

文档构建
--------

安装文档依赖::

    pip install -e ".[doc]"

构建文档::

    cd docs
    make html

贡献指南
--------

欢迎贡献代码！请查看 `CONTRIBUTING.rst`_ 了解详情。

.. _CONTRIBUTING.rst: CONTRIBUTING.rst

许可证
-------

本项目采用 MIT 许可证，详见 `LICENSE`_ 文件。

.. _LICENSE: LICENSE

更新日志
--------

详见 `ChangeLog.md`_。

.. _ChangeLog.md: ChangeLog.md

联系方式
--------

- 邮箱: ops@920430.com
- 问题反馈: https://github.com/yourusername/PyraUtils/issues
