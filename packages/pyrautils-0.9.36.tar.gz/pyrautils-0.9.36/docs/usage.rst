=====
Usage
=====

To use retailcloud in a project::

    import retailcloud
