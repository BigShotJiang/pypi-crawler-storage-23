#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
PyraUtils - Python 常用工具类库

一个功能丰富的 Python 工具类库，提供了日志、HTTP请求、文件操作、数据库、
JWT认证、企业微信API等常用功能的封装。
"""

import os
import site
import sys
from setuptools import setup, find_packages
from setuptools.command.install import install

# Allow editable install into user site directory.
# See https://github.com/pypa/pip/issues/7953.
site.ENABLE_USER_SITE = '--user' in sys.argv[1:]

# 读取版本号
here = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(here, 'VERSION'), encoding='utf-8') as f:
    version = f.read().strip()

# 读取 README
with open(os.path.join(here, 'README.rst'), encoding='utf-8') as f:
    readme = f.read()

# 读取 CHANGELOG
with open(os.path.join(here, 'ChangeLog.md'), encoding='utf-8') as f:
    changelog = f.read()


def read_requirements(filename):
    """读取 requirements 文件，支持多种编码格式"""
    requirements = []
    filepath = os.path.join(here, filename)
    
    # 首先尝试以二进制方式读取，然后解码
    with open(filepath, 'rb') as f:
        raw_data = f.read()
    
    # 检测并移除 BOM
    if raw_data.startswith(b'\xef\xbb\xbf'):  # UTF-8 BOM
        raw_data = raw_data[3:]
        encoding = 'utf-8'
    elif raw_data.startswith(b'\xff\xfe'):  # UTF-16 LE BOM
        raw_data = raw_data[2:]
        encoding = 'utf-16-le'
    elif raw_data.startswith(b'\xfe\xff'):  # UTF-16 BE BOM
        raw_data = raw_data[2:]
        encoding = 'utf-16-be'
    else:
        encoding = 'utf-8'
    
    try:
        content = raw_data.decode(encoding)
    except UnicodeDecodeError:
        # 如果解码失败，尝试其他编码
        for enc in ['utf-8', 'gbk', 'latin-1']:
            try:
                content = raw_data.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        else:
            raise ValueError(f"无法解码 {filename} 文件")
    
    for line in content.splitlines():
        line = line.strip()
        # 跳过注释、空行和 -i/-e 开头的行
        if line and not line.startswith('#') and not line.startswith('-'):
            # 处理带有环境标记的依赖
            if ';' in line:
                # 保留环境标记
                requirements.append(line)
            else:
                requirements.append(line)
    
    return requirements


class CustomInstallCommand(install):
    """自定义安装命令，用于检测覆盖安装"""
    
    def run(self):
        install.run(self)
        self._warn_overlay_install()

    def _warn_overlay_install(self):
        """警告用户可能存在的覆盖安装问题"""
        overlay_warning = False
        lib_paths = [self.install_lib]
        if lib_paths[0].startswith("/usr/lib/"):
            # We have to try also with an explicit prefix of /usr/local in order to
            # catch Debian's custom user site-packages directory.
            lib_paths.append(self.install_lib.replace("/usr/lib/", "/usr/local/lib/"))
        for lib_path in lib_paths:
            existing_path = os.path.abspath(os.path.join(lib_path, "PyraUtils"))
            if os.path.exists(existing_path):
                overlay_warning = True
                break
        
        if overlay_warning:
            sys.stderr.write(f"""
========
WARNING!
========
You have just installed PyraUtils over top of an existing
installation, without removing it first. Because of this,
your install may now include extraneous files from a
previous version that have since been removed from
PyraUtils. This is known to cause a variety of problems. You
should manually remove the
{existing_path}
directory and re-install PyraUtils.
""")


# 读取依赖
install_requires = read_requirements('requirements.txt')


setup(
    name='PyraUtils',
    version=version,
    description='Python 常用工具类库 - 提供日志、HTTP请求、文件操作、数据库、JWT认证等功能',
    long_description=readme + '\n\n' + changelog,
    long_description_content_type='text/x-rst',
    author='PyraUtils',
    author_email='ops@920430.com',
    url='https://github.com/yourusername/PyraUtils',
    packages=find_packages(exclude=['tests', 'tests.*', 'demos', 'demos.*', 'docs', 'docs.*']),
    package_dir={'PyraUtils': 'PyraUtils'},
    include_package_data=True,
    install_requires=install_requires,
    python_requires='>=3.8',
    license='MIT',
    zip_safe=False,
    keywords='python, utils, tools, logging, http, jwt, database, file, wechat',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: Chinese (Simplified)',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Utilities',
    ],
    entry_points={
        'console_scripts': [
            'pyrautils=PyraUtils.cli:main',
        ],
    },
    cmdclass={
        'install': CustomInstallCommand,
    },
    project_urls={
        'Bug Reports': 'https://github.com/yourusername/PyraUtils/issues',
        'Source': 'https://github.com/yourusername/PyraUtils',
        'Documentation': 'https://pyrautils.readthedocs.io/',
    },
)
