import pytest
import os
import sys
from pypinyin import Style

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from PyraUtils.common._strings import StringsUtils

class TestStringsUtils:
    """测试StringsUtils类的功能"""
    
    def test_chars_to_escape(self):
        """测试字符转义功能"""
        text = "这是一个带有*特殊字符&的字符串"
        result = StringsUtils.chars_to_escape(text, special_chars="*&")
        assert "\*" in result
        assert "\&" in result
    
    def test_remove_duplicate(self):
        """测试列表去重功能"""
        # 测试基本列表去重
        test_list = [1, 2, 3, 2, 1]
        result = StringsUtils.remove_duplicate(test_list)
        assert result == [1, 2, 3]
        
        # 测试字符串列表去重
        test_list = ["a", "b", "a", "c"]
        result = StringsUtils.remove_duplicate(test_list)
        assert result == ["a", "b", "c"]
    
    def test_create_multi_dict(self):
        """测试创建多值字典功能"""
        key_values = [('even', 2), ('odd', 1), ('even', 8), ('odd', 3), ('float', 2.4), ('odd', 7)]
        result = StringsUtils.create_multi_dict(key_values)
        assert result['even'] == [2, 8]
        assert result['odd'] == [1, 3, 7]
        assert result['float'] == [2.4]
    
    def test_str_to_pinyin(self):
        """测试中文转拼音功能"""
        # 测试基本中文转拼音
        result = StringsUtils.str_to_pinyin("中文", style=Style.NORMAL)
        assert "zhong" in result.lower()
        assert "wen" in result.lower()
        
        # 测试首字母
        result = StringsUtils.str_to_pinyin("中文", style=Style.FIRST_LETTER)
        assert result.lower() == "zw"
    
    def test_is_empty(self):
        """测试判空功能"""
        assert StringsUtils.is_empty("") is True
        assert StringsUtils.is_empty(" ") is False
        assert StringsUtils.is_empty(None) is True
        assert StringsUtils.is_empty("test") is False
    
    def test_valid_str_is_digit(self):
        """测试字符串是否只包含数字"""
        assert StringsUtils.valid_str_is_digit("123") is True
        assert StringsUtils.valid_str_is_digit("") is True
        assert StringsUtils.valid_str_is_digit("123abc") is False
        assert StringsUtils.valid_str_is_digit("abc") is False
    
    def test_valid_str_01(self):
        """测试生成有效文件名功能（方法01）"""
        result = StringsUtils.valid_str_01("john's portrait in 2004.jpg")
        assert result == "johns_portrait_in_2004.jpg"
        
        with pytest.raises(ValueError):
            StringsUtils.valid_str_01("")
    
    def test_valid_str_02(self):
        """测试生成有效文件名功能（方法02）"""
        result = StringsUtils.valid_str_02("陈aaa ll%.jpg")
        assert result == "aaall.jpg"
        
        result = StringsUtils.valid_str_02("aaa ll%.jpg")
        assert result == "aaall.jpg"
    
    def test_slugify(self):
        """测试slugify功能"""
        result = StringsUtils.slugify("陈 ll%.jpg")
        assert result == "lljpg"
        
        result = StringsUtils.slugify("陈aaa ll%.jpg", allow_unicode=True)
        assert result == "陈aaa-lljpg"
    
    def test_natural_sort_01(self):
        """测试自然排序功能（方法01）"""
        # natural_sort_01 使用了 lru_cache，但列表不可哈希，需要转换为元组
        # 注意：此方法在源代码中存在设计问题，因为它接收列表参数却使用了缓存
        test_tuple = ("file2.txt", "file10.txt", "file1.txt")
        sorted_list = StringsUtils.natural_sort_01(list(test_tuple))
        assert sorted_list == ["file1.txt", "file2.txt", "file10.txt"]
    
    def test_natural_sort_02(self):
        """测试自然排序功能（方法02）"""
        # natural_sort_02 使用了 lru_cache，但列表不可哈希，需要转换为元组
        # 注意：此方法在源代码中存在设计问题，因为它接收列表参数却使用了缓存
        test_tuple = ("file2.txt", "file10.txt", "file1.txt")
        sorted_list = StringsUtils.natural_sort_02(list(test_tuple))
        assert sorted_list == ["file1.txt", "file2.txt", "file10.txt"]
    
    def test_natural_sort_03(self):
        """测试自然排序功能（方法03，带缓存）"""
        test_tuple = ("file2.txt", "file10.txt", "file1.txt")
        sorted_list = StringsUtils.natural_sort_03(test_tuple)
        assert sorted_list == ["file1.txt", "file2.txt", "file10.txt"]

if __name__ == "__main__":
    pytest.main([__file__])