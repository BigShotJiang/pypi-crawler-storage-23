import pytest
import os
import sys
import tempfile
import dbm

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from PyraUtils.common._shelve import ShelveUtils

class TestShelveUtils:
    """测试ShelveUtils类的功能"""
    
    def setup_method(self):
        """在每个测试方法前创建临时文件"""
        # 创建临时目录
        self.temp_dir = tempfile.mkdtemp()
        # 创建临时文件路径
        self.test_file = os.path.join(self.temp_dir, "test_shelve.db")
        self.test_file2 = os.path.join(self.temp_dir, "test_shelve2.db")
    
    def teardown_method(self):
        """在每个测试方法后清理临时文件"""
        # 清理临时文件
        for file in os.listdir(self.temp_dir):
            os.remove(os.path.join(self.temp_dir, file))
        # 清理临时目录
        os.rmdir(self.temp_dir)
    
    def test_set_and_get_shelve_value(self):
        """测试基本的写入和读取功能"""
        # 写入数据
        ShelveUtils.set_shelve_value(self.test_file, "name", "John")
        ShelveUtils.set_shelve_value(self.test_file, "age", 30)
        ShelveUtils.set_shelve_value(self.test_file, "is_student", False)
        
        # 读取数据
        assert ShelveUtils.get_shelve_value(self.test_file, "name") == "John"
        assert ShelveUtils.get_shelve_value(self.test_file, "age") == 30
        assert ShelveUtils.get_shelve_value(self.test_file, "is_student") is False
    
    def test_set_shelve_value_with_different_types(self):
        """测试写入不同类型的数据"""
        # 写入各种类型数据
        test_data = {
            "string": "test",
            "int": 123,
            "float": 123.456,
            "bool": True,
            "list": [1, 2, 3],
            "dict": {"key": "value"}
        }
        
        for key, value in test_data.items():
            ShelveUtils.set_shelve_value(self.test_file, key, value)
            assert ShelveUtils.get_shelve_value(self.test_file, key) == value
    
    def test_set_shelve_value_with_flag_c(self):
        """测试使用'c'模式创建新文件"""
        # 确保文件不存在
        assert not any(os.path.exists(f"{self.test_file2}{ext}") for ext in ['', '.db', '.dat', '.dir', '.bak'])
        
        # 使用'c'模式写入数据（应该创建新文件）
        ShelveUtils.set_shelve_value(self.test_file2, "name", "Jane", flag="c")
        
        # 检查是否有任何相关文件被创建
        assert any(os.path.exists(f"{self.test_file2}{ext}") for ext in ['', '.db', '.dat', '.dir', '.bak'])
        assert ShelveUtils.get_shelve_value(self.test_file2, "name") == "Jane"
    
    def test_set_shelve_value_with_flag_n(self):
        """测试使用'n'模式创建新文件"""
        # 先写入一些数据
        ShelveUtils.set_shelve_value(self.test_file, "name", "John")
        assert ShelveUtils.get_shelve_value(self.test_file, "name") == "John"
        
        # 使用'n'模式写入数据（应该创建新的空文件）
        ShelveUtils.set_shelve_value(self.test_file, "age", 30, flag="n")
        assert ShelveUtils.get_shelve_value(self.test_file, "age") == 30
        
        # 原来的键应该不存在了
        with pytest.raises(KeyError):
            ShelveUtils.get_shelve_value(self.test_file, "name")
    
    def test_set_shelve_value_with_flag_w_error(self):
        """测试使用'w'模式打开不存在的文件时抛出错误"""
        with pytest.raises(OSError):
            ShelveUtils.set_shelve_value(self.test_file2, "name", "John", flag="w")
    
    def test_set_shelve_value_with_invalid_flag(self):
        """测试使用无效的flag时抛出错误"""
        with pytest.raises(ValueError):
            ShelveUtils.set_shelve_value(self.test_file, "name", "John", flag="invalid")
    
    def test_get_shelve_value_nonexistent_key(self):
        """测试读取不存在的键时抛出错误"""
        # 写入一个键
        ShelveUtils.set_shelve_value(self.test_file, "name", "John")
        
        # 尝试读取不存在的键
        with pytest.raises(KeyError):
            ShelveUtils.get_shelve_value(self.test_file, "nonexistent_key")
    
    def test_get_shelve_value_nonexistent_file(self):
        """测试读取不存在的文件时抛出错误"""
        with pytest.raises(Exception):
            ShelveUtils.get_shelve_value(self.test_file2, "name", flag="r")
    
    def test_get_shelve_value_with_invalid_flag(self):
        """测试使用无效的flag时抛出错误"""
        with pytest.raises(ValueError):
            ShelveUtils.get_shelve_value(self.test_file, "name", flag="invalid")
    
    def test_set_shelve_value_with_writeback(self):
        """测试使用writeback模式"""
        import shelve
        # 使用writeback模式写入列表
        ShelveUtils.set_shelve_value(self.test_file, "numbers", [1, 2, 3], writeback=True)
        
        # 读取并修改列表
        with shelve.open(self.test_file, writeback=True) as shelf:
            shelf["numbers"].append(4)
        
        # 验证修改是否生效
        assert ShelveUtils.get_shelve_value(self.test_file, "numbers") == [1, 2, 3, 4]

if __name__ == "__main__":
    pytest.main([__file__])