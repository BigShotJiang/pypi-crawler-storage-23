import pytest
import os
import sys
import tempfile
import shutil
from pathlib import Path
import platform

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from PyraUtils.common._file import FileUtils, ZipFilesUtils

class TestFileUtils:
    """测试FileUtils类的功能"""
    
    def setup_method(self):
        """在每个测试方法前创建临时目录和文件"""
        # 创建临时目录
        self.temp_dir = tempfile.mkdtemp()
        self.src_dir = os.path.join(self.temp_dir, "source")
        self.dst_dir = os.path.join(self.temp_dir, "destination")
        
        # 创建源目录结构
        os.makedirs(os.path.join(self.src_dir, "subdir1"))
        os.makedirs(os.path.join(self.src_dir, "subdir2"))
        
        # 创建测试文件
        self.test_file1 = os.path.join(self.src_dir, "file1.txt")
        self.test_file2 = os.path.join(self.src_dir, "file2.txt")
        self.test_file3 = os.path.join(self.src_dir, "subdir1", "file3.txt")
        self.test_file4 = os.path.join(self.src_dir, "subdir2", "file4.txt")
        
        with open(self.test_file1, "w") as f:
            f.write("Line 1\nLine 2\nLine 3")
        with open(self.test_file2, "w") as f:
            f.write("Content of file 2")
        with open(self.test_file3, "w") as f:
            f.write("Content of file 3")
        with open(self.test_file4, "w") as f:
            f.write("Content of file 4")
    
    def teardown_method(self):
        """在每个测试方法后清理临时目录"""
        # 清理临时目录
        shutil.rmtree(self.temp_dir)
    
    def test_open_large_file(self):
        """测试打开大文件的功能"""
        lines = list(FileUtils.open_large_file(self.test_file1))
        assert lines == ["Line 1", "Line 2", "Line 3"]
    
    def test_create_folder(self):
        """测试创建目录的功能"""
        new_dir = os.path.join(self.temp_dir, "new", "nested", "dir")
        FileUtils.create_folder(new_dir)
        assert os.path.exists(new_dir)
    
    def test_copy(self):
        """测试复制目录的功能"""
        FileUtils.copy(self.src_dir, self.dst_dir)
        
        # 验证文件是否复制成功
        assert os.path.exists(os.path.join(self.dst_dir, "file1.txt"))
        assert os.path.exists(os.path.join(self.dst_dir, "file2.txt"))
        assert os.path.exists(os.path.join(self.dst_dir, "subdir1", "file3.txt"))
        assert os.path.exists(os.path.join(self.dst_dir, "subdir2", "file4.txt"))
    
    def test_copy_with_ignore(self):
        """测试复制目录时忽略特定文件"""
        FileUtils.copy(self.src_dir, self.dst_dir, ignore=["*.txt"])
        
        # 验证文件是否被忽略
        assert not os.path.exists(os.path.join(self.dst_dir, "file1.txt"))
        assert not os.path.exists(os.path.join(self.dst_dir, "file2.txt"))
        assert not os.path.exists(os.path.join(self.dst_dir, "subdir1", "file3.txt"))
        assert not os.path.exists(os.path.join(self.dst_dir, "subdir2", "file4.txt"))
    
    def test_get_listfile_01(self):
        """测试get_listfile_01方法"""
        files = FileUtils.get_listfile_01(self.src_dir)
        files.sort()
        expected = [self.test_file1, self.test_file2, self.test_file3, self.test_file4]
        expected.sort()
        assert files == expected
    
    def test_get_listfile_02(self):
        """测试get_listfile_02方法"""
        files = FileUtils.get_listfile_02(self.src_dir)
        files.sort()
        expected = [self.test_file1, self.test_file2, self.test_file3, self.test_file4]
        expected.sort()
        assert files == expected
    
    def test_get_listfile_03_files_only(self):
        """测试get_listfile_03方法只获取文件"""
        files = FileUtils.get_listfile_03(self.src_dir, include_files=True, include_dirs=False)
        files.sort()
        expected = [self.test_file1, self.test_file2, self.test_file3, self.test_file4]
        expected.sort()
        assert files == expected
    
    def test_get_listfile_03_dirs_only(self):
        """测试get_listfile_03方法只获取目录"""
        dirs = FileUtils.get_listfile_03(self.src_dir, include_files=False, include_dirs=True)
        dirs.sort()
        expected = [
            os.path.join(self.src_dir, "subdir1"),
            os.path.join(self.src_dir, "subdir2")
        ]
        expected.sort()
        assert dirs == expected
    
    def test_get_listfile_03_both(self):
        """测试get_listfile_03方法同时获取文件和目录"""
        items = FileUtils.get_listfile_03(self.src_dir, include_files=True, include_dirs=True)
        items.sort()
        expected = [
            self.test_file1, self.test_file2, self.test_file3, self.test_file4,
            os.path.join(self.src_dir, "subdir1"),
            os.path.join(self.src_dir, "subdir2")
        ]
        expected.sort()
        assert items == expected
    
    @pytest.mark.skipif(platform.system().lower() == 'windows', reason="Windows不支持chown操作")
    def test_change_owner(self):
        """测试更改文件所有权（仅在Linux/macOS上运行）"""
        # 获取当前文件的所有者和组
        import pwd
        import grp
        current_uid = os.stat(self.test_file1).st_uid
        current_gid = os.stat(self.test_file1).st_gid
        
        try:
            # 尝试更改所有者（可能需要root权限，这里仅测试API调用）
            FileUtils.change_owner(self.test_file1, current_uid, current_gid)
        except PermissionError:
            # 如果没有权限，至少确认方法被正确调用
            pass
    
    def test_rename_files(self):
        """测试批量重命名文件"""
        # 创建临时文件列表
        temp_files = []
        for i in range(3):
            temp_file = os.path.join(self.temp_dir, f"temp{i}.txt")
            with open(temp_file, "w") as f:
                f.write(f"Content {i}")
            temp_files.append(temp_file)
        
        # 执行批量重命名
        FileUtils.rename_files(temp_files, "new_", 1)
        
        # 验证重命名结果
        for i in range(3):
            new_file = os.path.join(self.temp_dir, f"new_{i+1:03d}.txt")
            assert os.path.exists(new_file)
    
    def test_rename_file(self):
        """测试重命名单个文件"""
        old_file = os.path.join(self.temp_dir, "old.txt")
        new_file = os.path.join(self.temp_dir, "new.txt")
        
        with open(old_file, "w") as f:
            f.write("Test content")
        
        FileUtils.rename_file(old_file, new_file)
        
        assert not os.path.exists(old_file)
        assert os.path.exists(new_file)
        with open(new_file, "r") as f:
            assert f.read() == "Test content"
    
    def test_rename_file_nonexistent(self):
        """测试重命名不存在的文件"""
        old_file = os.path.join(self.temp_dir, "nonexistent.txt")
        new_file = os.path.join(self.temp_dir, "new.txt")
        
        with pytest.raises(FileNotFoundError):
            FileUtils.rename_file(old_file, new_file)
    
    def test_rename_file_existing_new(self):
        """测试重命名到已存在的文件"""
        old_file = os.path.join(self.temp_dir, "old.txt")
        new_file = os.path.join(self.temp_dir, "new.txt")
        
        with open(old_file, "w") as f:
            f.write("Old content")
        with open(new_file, "w") as f:
            f.write("New content")
        
        with pytest.raises(FileExistsError):
            FileUtils.rename_file(old_file, new_file)

class TestZipFilesUtils:
    """测试ZipFilesUtils类的功能"""
    
    def setup_method(self):
        """在每个测试方法前创建临时目录和文件"""
        # 创建临时目录
        self.temp_dir = tempfile.mkdtemp()
        self.extract_dir = os.path.join(self.temp_dir, "extract")
        
        # 创建测试文件
        self.test_file = os.path.join(self.temp_dir, "test.txt")
        with open(self.test_file, "w") as f:
            f.write("Test content for compression")
    
    def teardown_method(self):
        """在每个测试方法后清理临时目录"""
        # 清理临时目录
        shutil.rmtree(self.temp_dir)
    
    @pytest.mark.parametrize("compress_type", ["gz", "zip", "7z"])
    def test_compress_and_extract_file(self, compress_type):
        """测试压缩和解压文件功能"""
        # 创建压缩文件路径
        compressed_file = os.path.join(self.temp_dir, f"test.{compress_type}")
        
        # 压缩文件
        ZipFilesUtils.compress_file(self.test_file, compressed_file, compress_type)
        assert os.path.exists(compressed_file)
        
        # 解压文件
        ZipFilesUtils.extract_file(compressed_file, self.extract_dir)
        
        # 验证解压结果
        extracted_file = os.path.join(self.extract_dir, "test.txt")
        assert os.path.exists(extracted_file)
        with open(extracted_file, "r") as f:
            assert f.read() == "Test content for compression"
    
    def test_compress_nonexistent_file(self):
        """测试压缩不存在的文件"""
        nonexistent_file = os.path.join(self.temp_dir, "nonexistent.txt")
        compressed_file = os.path.join(self.temp_dir, "test.gz")
        
        with pytest.raises(FileNotFoundError):
            ZipFilesUtils.compress_file(nonexistent_file, compressed_file)
    
    def test_compress_invalid_type(self):
        """测试使用无效的压缩类型"""
        compressed_file = os.path.join(self.temp_dir, "test.invalid")
        
        with pytest.raises(ValueError):
            ZipFilesUtils.compress_file(self.test_file, compressed_file, "invalid")
    
    def test_extract_nonexistent_file(self):
        """测试解压不存在的文件"""
        nonexistent_file = os.path.join(self.temp_dir, "nonexistent.gz")
        
        with pytest.raises(FileNotFoundError):
            ZipFilesUtils.extract_file(nonexistent_file, self.extract_dir)
    
    def test_extract_invalid_type(self):
        """测试解压无效的压缩类型"""
        # 创建一个普通文件，不是压缩文件
        invalid_file = os.path.join(self.temp_dir, "invalid.txt")
        with open(invalid_file, "w") as f:
            f.write("Not a compressed file")
        
        with pytest.raises(ValueError):
            ZipFilesUtils.extract_file(invalid_file, self.extract_dir, "gz")
    
    def test_extract_auto_detect_type(self):
        """测试自动检测压缩类型"""
        # 创建压缩文件
        compressed_file = os.path.join(self.temp_dir, "test.zip")
        ZipFilesUtils.compress_file(self.test_file, compressed_file, "zip")
        
        # 解压时不指定类型，让它自动检测
        ZipFilesUtils.extract_file(compressed_file, self.extract_dir)
        
        # 验证解压结果
        extracted_file = os.path.join(self.extract_dir, "test.txt")
        assert os.path.exists(extracted_file)
        with open(extracted_file, "r") as f:
            assert f.read() == "Test content for compression"

if __name__ == "__main__":
    pytest.main([__file__])