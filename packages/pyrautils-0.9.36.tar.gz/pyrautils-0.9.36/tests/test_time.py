import pytest
import os
import sys
import datetime
import pytz

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from PyraUtils.common._time import TimeUtils

class TestTimeUtils:
    """测试TimeUtils类的功能"""
    
    def test_datetime_strftime_now_default(self):
        """测试默认参数的当前时间格式化"""
        result = TimeUtils.datetime_strftime_now()
        
        # 检查结果是否为字符串
        assert isinstance(result, str)
        
        # 检查格式是否符合默认的 "%Y-%m-%d %H:%M:%S"
        assert len(result) == 19
        assert result[4] == '-' and result[7] == '-' and result[10] == ' ' and result[13] == ':' and result[16] == ':'
    
    def test_datetime_strftime_now_custom_format(self):
        """测试自定义格式的当前时间格式化"""
        result = TimeUtils.datetime_strftime_now(strftime="%Y-%m-%d")
        
        assert isinstance(result, str)
        assert len(result) == 10
        assert result[4] == '-' and result[7] == '-'
    
    def test_datetime_strftime_now_utc(self):
        """测试UTC时区的当前时间格式化"""
        result = TimeUtils.datetime_strftime_now(tz_info="UTC", strftime="%Y-%m-%dT%H:%M:%SZ")
        
        assert isinstance(result, str)
        assert result.endswith('Z')
    
    def test_datetime_strftime_now_local(self):
        """测试本地时区的当前时间格式化"""
        result = TimeUtils.datetime_strftime_now(tz_info=None)
        
        assert isinstance(result, str)
    
    def test_datetime_strftime_now_invalid_timezone(self):
        """测试无效时区的情况"""
        with pytest.raises(pytz.exceptions.UnknownTimeZoneError):
            TimeUtils.datetime_strftime_now(tz_info="Invalid/Timezone")
    
    def test_timegm_timestamp(self):
        """测试datetime对象转时间戳功能"""
        # 创建一个固定的datetime对象
        dt = datetime.datetime(2023, 12, 25, 10, 30, 45)
        result = TimeUtils.timegm_timestamp(dt)

        # 检查结果类型
        assert isinstance(result, float)

        # 检查结果值（2023-12-25 10:30:45的UTC时间戳）
        assert result == 1703490645.0 or result == 1703500245.0  # 处理时区差异
    
    def test_timegm_timestamp_with_timezone(self):
        """测试带时区的datetime对象转时间戳功能"""
        # 创建一个带UTC时区的datetime对象
        dt = datetime.datetime(2023, 12, 25, 10, 30, 45, tzinfo=datetime.timezone.utc)
        result = TimeUtils.timegm_timestamp(dt)
        
        assert isinstance(result, float)
    
    def test_datetime_utc_now_default(self):
        """测试默认参数的UTC时间获取"""
        result = TimeUtils.datetime_utc_now()
        
        # 检查结果类型
        assert isinstance(result, datetime.datetime)
        
        # 检查时区是否为UTC
        assert result.tzinfo == datetime.timezone.utc
    
    def test_datetime_utc_now_with_offset_seconds(self):
        """测试添加秒级偏移的UTC时间"""
        # 获取当前时间
        now = datetime.datetime.now(datetime.timezone.utc)
        
        # 测试未来30秒
        result = TimeUtils.datetime_utc_now(date_type="seconds", timedelta=30)
        assert result > now
        
        # 测试过去30秒
        result = TimeUtils.datetime_utc_now(date_type="seconds", timedelta=-30)
        assert result < now
    
    def test_datetime_utc_now_with_offset_minutes(self):
        """测试添加分钟级偏移的UTC时间"""
        # 获取当前时间
        now = datetime.datetime.now(datetime.timezone.utc)
        
        # 测试未来5分钟
        result = TimeUtils.datetime_utc_now(date_type="minutes", timedelta=5)
        assert result > now
    
    def test_datetime_utc_now_with_offset_hours(self):
        """测试添加小时级偏移的UTC时间"""
        # 获取当前时间
        now = datetime.datetime.now(datetime.timezone.utc)
        
        # 测试未来2小时
        result = TimeUtils.datetime_utc_now(date_type="hours", timedelta=2)
        assert result > now
    
    def test_datetime_utc_now_with_offset_days(self):
        """测试添加天级偏移的UTC时间"""
        # 获取当前时间
        now = datetime.datetime.now(datetime.timezone.utc)
        
        # 测试未来3天
        result = TimeUtils.datetime_utc_now(date_type="days", timedelta=3)
        assert result > now
    
    def test_datetime_utc_now_with_offset_weeks(self):
        """测试添加周级偏移的UTC时间"""
        # 获取当前时间
        now = datetime.datetime.now(datetime.timezone.utc)
        
        # 测试未来1周
        result = TimeUtils.datetime_utc_now(date_type="weeks", timedelta=1)
        assert result > now
    
    def test_datetime_utc_now_custom_timezone(self):
        """测试自定义时区的UTC时间获取"""
        # 使用上海时区
        shanghai_tz = pytz.timezone("Asia/Shanghai")
        result = TimeUtils.datetime_utc_now(tz=shanghai_tz)

        # 检查结果类型
        assert isinstance(result, datetime.datetime)

        # 检查时区名称，不直接比较时区对象（因为pytz会返回不同实例）
        assert result.tzinfo.zone == "Asia/Shanghai"
    
    def test_datetime_utc_now_invalid_date_type(self):
        """测试无效时间单位的情况"""
        with pytest.raises(ValueError):
            TimeUtils.datetime_utc_now(date_type="invalid_type")
    
    def test_datetime_utc_now_case_insensitive(self):
        """测试时间单位的大小写不敏感"""
        # 获取当前时间
        now = datetime.datetime.now(datetime.timezone.utc)
        
        # 使用大写的时间单位
        result = TimeUtils.datetime_utc_now(date_type="MINUTES", timedelta=5)
        assert result > now

if __name__ == "__main__":
    pytest.main([__file__])
