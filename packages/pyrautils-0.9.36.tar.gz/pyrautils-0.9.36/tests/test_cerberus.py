#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CerberusUtil 测试用例
"""

import unittest
from PyraUtils.common._cerberus import CerberusUtil
from typing import Dict, Any


class TestCerberusUtil(unittest.TestCase):
    """
    CerberusUtil 类的测试用例
    """
    
    def setUp(self):
        """
        每个测试方法执行前的设置
        """
        self.validator = CerberusUtil()
    
    def test_validate_success(self):
        """
        测试验证成功的情况
        """
        schema = {
            "name": {"type": "string"},
            "age": {"type": "integer", "min": 0}
        }
        document = {
            "name": "John",
            "age": 30
        }
        result = self.validator.validate(document, schema)
        self.assertTrue(result)
    
    def test_validate_failure(self):
        """
        测试验证失败的情况
        """
        schema = {
            "name": {"type": "string"},
            "age": {"type": "integer", "min": 0}
        }
        document = {
            "name": "John",
            "age": -5  # 年龄不符合最小要求
        }
        result = self.validator.validate(document, schema)
        self.assertFalse(result)
    
    def test_validate_missing_required_field(self):
        """
        测试缺少必填字段的情况
        """
        schema = {
            "name": {"type": "string", "required": True},
            "age": {"type": "integer"}
        }
        document = {
            "age": 30  # 缺少必填的name字段
        }
        result = self.validator.validate(document, schema)
        self.assertFalse(result)
    
    def test_validate_wrong_type(self):
        """
        测试字段类型错误的情况
        """
        schema = {
            "name": {"type": "string"},
            "age": {"type": "integer"}
        }
        document = {
            "name": "John",
            "age": "thirty"  # age应该是整数
        }
        result = self.validator.validate(document, schema)
        self.assertFalse(result)
    
    def test_errors_after_failure(self):
        """
        测试验证失败后获取错误信息
        """
        schema = {
            "name": {"type": "string"},
            "age": {"type": "integer", "min": 0}
        }
        document = {
            "name": "John",
            "age": -5  # 年龄不符合最小要求
        }
        self.validator.validate(document, schema)
        errors = self.validator.errors()
        self.assertIn("age", errors)
        self.assertIsInstance(errors, dict)
    
    def test_errors_after_success(self):
        """
        测试验证成功后获取错误信息（应该为空）
        """
        schema = {
            "name": {"type": "string"},
            "age": {"type": "integer", "min": 0}
        }
        document = {
            "name": "John",
            "age": 30
        }
        self.validator.validate(document, schema)
        errors = self.validator.errors()
        self.assertEqual(len(errors), 0)
    
    def test_validate_complex_schema(self):
        """
        测试复杂模式的验证
        """
        schema = {
            "user": {
                "type": "dict",
                "schema": {
                    "name": {"type": "string"},
                    "address": {
                        "type": "dict",
                        "schema": {
                            "city": {"type": "string"},
                            "zipcode": {"type": "string", "regex": "^\\d{5}$"}
                        }
                    }
                }
            }
        }
        document = {
            "user": {
                "name": "John",
                "address": {
                    "city": "New York",
                    "zipcode": "12345"
                }
            }
        }
        result = self.validator.validate(document, schema)
        self.assertTrue(result)
    
    def test_validate_complex_schema_failure(self):
        """
        测试复杂模式验证失败的情况
        """
        schema = {
            "user": {
                "type": "dict",
                "schema": {
                    "name": {"type": "string"},
                    "address": {
                        "type": "dict",
                        "schema": {
                            "city": {"type": "string"},
                            "zipcode": {"type": "string", "regex": "^\\d{5}$"}
                        }
                    }
                }
            }
        }
        document = {
            "user": {
                "name": "John",
                "address": {
                    "city": "New York",
                    "zipcode": "1234"  # 邮编格式不正确
                }
            }
        }
        result = self.validator.validate(document, schema)
        self.assertFalse(result)
        errors = self.validator.errors()
        self.assertIn("user", errors)


if __name__ == "__main__":
    unittest.main()