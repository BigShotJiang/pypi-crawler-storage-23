#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RsyncUtil 测试用例
"""

import unittest
from unittest.mock import patch, MagicMock
from PyraUtils.common.rsync import RsyncUtil


class TestRsyncUtil(unittest.TestCase):
    """
    RsyncUtil 类的测试用例
    """
    
    def setUp(self):
        """
        每个测试方法执行前的设置
        """
        self.workspace = "/tmp"
        self.source_dir = "/local/path"
        self.rsync_user = "user"
        self.rsync_ip = "192.168.1.100"
        self.target = "/remote/path"
        self.rsync_port = 22
    
    @patch('PyraUtils.common.rsync.subprocess.check_call')
    def test_rsync_use_ssh_success(self, mock_check_call):
        """
        测试使用SSH方式成功执行Rsync
        """
        mock_check_call.return_value = 0
        result = RsyncUtil.rsync_use_ssh(
            workspace=self.workspace,
            source_dir=self.source_dir,
            rsync_user=self.rsync_user,
            rsync_ip=self.rsync_ip,
            target=self.target,
            rsync_port=self.rsync_port
        )
        self.assertEqual(result, 0)
        mock_check_call.assert_called_once()
        # 验证调用的命令包含预期的参数
        call_args = mock_check_call.call_args[0][0]
        self.assertIn("-avz", call_args)
        self.assertIn(f"-e 'ssh -p {self.rsync_port}'", call_args)
        self.assertIn(self.source_dir, call_args)
        self.assertIn(f"{self.rsync_user}@{self.rsync_ip}:{self.target}", call_args)
    
    @patch('PyraUtils.common.rsync.subprocess.check_call')
    def test_rsync_use_ssh_failure(self, mock_check_call):
        """
        测试使用SSH方式执行Rsync失败
        """
        mock_check_call.side_effect = Exception("Rsync failed")
        result = RsyncUtil.rsync_use_ssh(
            workspace=self.workspace,
            source_dir=self.source_dir,
            rsync_user=self.rsync_user,
            rsync_ip=self.rsync_ip,
            target=self.target,
            rsync_port=self.rsync_port
        )
        self.assertEqual(result, 1)
        mock_check_call.assert_called_once()
    
    @patch('PyraUtils.common.rsync.subprocess.check_call')
    def test_rsync_daemon_success(self, mock_check_call):
        """
        测试使用Rsync daemon方式成功执行Rsync
        """
        mock_check_call.return_value = 0
        rsync_remote_module = "module_name"
        rsync_passwd_file = "/path/to/rsync.passwd"
        result = RsyncUtil.rsync_daemon(
            workspace=self.workspace,
            source_dir=self.source_dir,
            rsync_user=self.rsync_user,
            rsync_ip=self.rsync_ip,
            rsync_remote_module=rsync_remote_module,
            rsync_passwd_file=rsync_passwd_file
        )
        self.assertEqual(result, 0)
        mock_check_call.assert_called_once()
        # 验证调用的命令包含预期的参数
        call_args = mock_check_call.call_args[0][0]
        self.assertIn("-avz", call_args)
        self.assertIn("--port=873", call_args)
        self.assertIn(f"--password-file={rsync_passwd_file}", call_args)
        self.assertIn(self.source_dir, call_args)
        self.assertIn(f"{self.rsync_user}@{self.rsync_ip}::{rsync_remote_module}", call_args)
    
    @patch('PyraUtils.common.rsync.subprocess.check_call')
    def test_rsync_daemon_failure(self, mock_check_call):
        """
        测试使用Rsync daemon方式执行Rsync失败
        """
        mock_check_call.side_effect = Exception("Rsync daemon failed")
        rsync_remote_module = "module_name"
        rsync_passwd_file = "/path/to/rsync.passwd"
        result = RsyncUtil.rsync_daemon(
            workspace=self.workspace,
            source_dir=self.source_dir,
            rsync_user=self.rsync_user,
            rsync_ip=self.rsync_ip,
            rsync_remote_module=rsync_remote_module,
            rsync_passwd_file=rsync_passwd_file
        )
        self.assertEqual(result, 1)
        mock_check_call.assert_called_once()
    
    @patch('PyraUtils.common.rsync.subprocess.check_call')
    def test_do_rsync_with_options(self, mock_check_call):
        """
        测试do_rsync方法带有额外选项
        """
        mock_check_call.return_value = 0
        source = "/local/source"
        destination = "/remote/dest"
        options = "--exclude=*.tmp"
        result = RsyncUtil.do_rsync(
            workspace=self.workspace,
            source=source,
            destination=destination,
            options=options
        )
        self.assertEqual(result, 0)
        mock_check_call.assert_called_once()
        call_args = mock_check_call.call_args[0][0]
        self.assertIn("-avz", call_args)
        self.assertIn(options, call_args)
        self.assertIn(source, call_args)
        self.assertIn(destination, call_args)
    
    @patch('PyraUtils.common.rsync.subprocess.check_call')
    def test_do_rsync_default_options(self, mock_check_call):
        """
        测试do_rsync方法使用默认选项
        """
        mock_check_call.return_value = 0
        source = "/local/source"
        destination = "/remote/dest"
        result = RsyncUtil.do_rsync(
            workspace=self.workspace,
            source=source,
            destination=destination
        )
        self.assertEqual(result, 0)
        mock_check_call.assert_called_once()
        call_args = mock_check_call.call_args[0][0]
        self.assertIn("-avz", call_args)
        self.assertIn(source, call_args)
        self.assertIn(destination, call_args)
    
    @patch('PyraUtils.common.rsync.subprocess.check_call')
    def test_do_rsync_cwd(self, mock_check_call):
        """
        测试do_rsync方法设置正确的工作目录
        """
        mock_check_call.return_value = 0
        source = "/local/source"
        destination = "/remote/dest"
        RsyncUtil.do_rsync(
            workspace=self.workspace,
            source=source,
            destination=destination
        )
        mock_check_call.assert_called_once()
        # 验证cwd参数
        self.assertEqual(mock_check_call.call_args[1]['cwd'], self.workspace)


if __name__ == "__main__":
    unittest.main()