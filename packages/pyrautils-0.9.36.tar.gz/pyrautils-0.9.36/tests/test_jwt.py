import pytest
import os
import sys
from unittest.mock import MagicMock, patch
import datetime
from PyraUtils.http._jwt import JWT, JWTDecorator, jwt_options

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

class TestJWT:
    """测试JWT类的功能"""
    
    def setup_method(self):
        """在每个测试方法前初始化JWT实例"""
        self.jwt = JWT(secret_key='test_secret_key')
        self.test_payload = {'user_id': 123, 'username': 'test_user'}
    
    def test_jwt_encode_basic(self):
        """测试基本的JWT编码功能"""
        result = self.jwt.jwt_encode(self.test_payload)
        assert 'token' in result
        assert isinstance(result['token'], str)
    
    def test_jwt_encode_with_custom_expiry(self):
        """测试带有自定义过期时间的JWT编码"""
        result = self.jwt.jwt_encode(self.test_payload, exp_seconds=7200)  # 2小时过期
        assert 'token' in result
    
    def test_jwt_encode_invalid_payload(self):
        """测试无效负载的JWT编码"""
        # 使用不可序列化的对象作为payload
        invalid_payload = {'user_id': 123, 'data': datetime.datetime.now()}
        with pytest.raises(RuntimeError):
            self.jwt.jwt_encode(invalid_payload)
    
    def test_jwt_decode_valid(self):
        """测试有效的JWT解码"""
        # 先编码一个token
        token_result = self.jwt.jwt_encode(self.test_payload)
        token = token_result['token']
        print(f"Generated token: {token}")
        
        # 然后解码
        is_valid, result = self.jwt.jwt_decode(token)
        print(f"Decode result: is_valid={is_valid}, result={result}")
        
        assert is_valid is True
        assert 'message' in result
        assert 'data' in result
        assert result['data']['user_id'] == self.test_payload['user_id']
        assert result['data']['username'] == self.test_payload['username']
    
    def test_jwt_decode_invalid(self):
        """测试无效的JWT解码"""
        invalid_token = 'invalid.token.string'
        is_valid, result = self.jwt.jwt_decode(invalid_token)
        
        assert is_valid is False
        assert 'message' in result
        assert 'reason' in result
    
    def test_jwt_decode_expired(self):
        """测试过期的JWT解码"""
        # 创建一个立即过期的token
        token_result = self.jwt.jwt_encode(self.test_payload, exp_seconds=-1)
        token = token_result['token']
        print(f"Generated expired token: {token}")
        
        # 解码过期的token
        is_valid, result = self.jwt.jwt_decode(token)
        print(f"Decode expired token result: is_valid={is_valid}, result={result}")
        
        assert is_valid is False
        assert 'message' in result
        assert 'reason' in result

class TestJWTDecorator:
    """测试JWTDecorator类的功能"""
    
    def setup_method(self):
        """在每个测试方法前初始化JWTDecorator实例"""
        self.jwt_decorator = JWTDecorator(secret_key='test_secret_key', audience='test_audience')
        self.test_payload = {'user_id': 123, 'username': 'test_user'}
        
        # 创建一个有效的token用于测试
        jwt_instance = JWT(secret_key='test_secret_key')
        self.valid_token = jwt_instance.jwt_encode(self.test_payload)['token']
    
    def test_is_valid_header(self):
        """测试头部验证功能"""
        # 有效的Bearer头
        valid_header = ['bearer', 'token123']
        assert self.jwt_decorator.is_valid_header(valid_header) is True
        
        # 无效的头部格式
        invalid_header = ['bearer']
        assert self.jwt_decorator.is_valid_header(invalid_header) is False
        
        # 错误的认证方法
        wrong_method_header = ['basic', 'token123']
        assert self.jwt_decorator.is_valid_header(wrong_method_header) is False
    
    def test_return_auth_error(self):
        """测试返回认证错误功能"""
        # 创建一个模拟的handler对象
        mock_handler = MagicMock()
        
        error_msg = {'message': 'Test error', 'reason': 'Test reason'}
        self.jwt_decorator.return_auth_error(mock_handler, error_msg)
        
        # 验证handler方法是否被正确调用
        mock_handler.set_status.assert_called_once_with(401)
        mock_handler.set_header.assert_called_once_with('WWW-Authenticate', 'Bearer realm="Restricted"')
        mock_handler.finish.assert_called_once_with(error_msg)
    
    @patch('PyraUtils.http._jwt.jwt.decode')
    def test_require_auth_success(self, mock_decode):
        """测试成功的认证请求"""
        # 设置mock返回值
        mock_decode.return_value = self.test_payload
        
        # 创建一个模拟的auth_header对象
        mock_header = MagicMock()
        mock_header.request.headers.get.return_value = f'Bearer {self.valid_token}'
        
        # 调用require_auth方法
        result = self.jwt_decorator.require_auth(mock_header)
        
        assert result is True
        mock_decode.assert_called_once()
        # 验证payload是否被设置到auth_header对象
        assert hasattr(mock_header, '_jwt_payload')
        assert mock_header._jwt_payload == self.test_payload
    
    def test_require_auth_missing_header(self):
        """测试缺少Authorization头的请求"""
        # 创建一个模拟的auth_header对象
        mock_header = MagicMock()
        mock_header.request.headers.get.return_value = None
        
        # 调用require_auth方法
        result = self.jwt_decorator.require_auth(mock_header)
        
        assert result is False
        mock_header.set_status.assert_called_once_with(401)
    
    def test_require_auth_invalid_header(self):
        """测试无效Authorization头的请求"""
        # 创建一个模拟的auth_header对象
        mock_header = MagicMock()
        mock_header.request.headers.get.return_value = 'InvalidHeader'
        
        # 调用require_auth方法
        result = self.jwt_decorator.require_auth(mock_header)
        
        assert result is False
        mock_header.set_status.assert_called_once_with(401)
    
    @patch('PyraUtils.http._jwt.jwt.decode')
    def test_require_auth_invalid_token(self, mock_decode):
        """测试无效token的请求"""
        from authlib.jose import JoseError
        
        # 设置mock抛出错误
        mock_decode.side_effect = JoseError('Invalid token')
        
        # 创建一个模拟的auth_header对象
        mock_header = MagicMock()
        mock_header.request.headers.get.return_value = f'Bearer {self.valid_token}'
        
        # 调用require_auth方法
        result = self.jwt_decorator.require_auth(mock_header)
        
        assert result is False
        mock_header.set_status.assert_called_once_with(401)
    
    def test_jwtauth_flask(self):
        """测试Flask的jwtauth装饰器"""
        # 尝试获取Flask装饰器
        flask_decorator = self.jwt_decorator.jwtauth(framework='flask')
        assert callable(flask_decorator)
    
    def test_jwtauth_tornado(self):
        """测试Tornado的jwtauth装饰器"""
        # 尝试获取Tornado装饰器
        tornado_decorator = self.jwt_decorator.jwtauth(framework='tornado')
        assert callable(tornado_decorator)
    
    def test_jwtauth_unsupported_framework(self):
        """测试不支持的框架"""
        with pytest.raises(ValueError):
            self.jwt_decorator.jwtauth(framework='django')
    
    @patch('PyraUtils.http._jwt.JWTDecorator._flask_jwtauth')
    def test_jwtauth_with_func(self, mock_flask_decorator):
        """测试传递函数给jwtauth方法"""
        # 设置mock返回值
        mock_wrapper = MagicMock()
        mock_flask_decorator.return_value = mock_wrapper
        
        # 创建一个测试函数
        def test_func():
            return "test"
        
        # 调用jwtauth方法
        result = self.jwt_decorator.jwtauth(test_func, framework='flask')
        
        # 验证结果
        assert result == mock_wrapper
        mock_flask_decorator.assert_called_once_with(test_func)

if __name__ == "__main__":
    pytest.main([__file__])