import pytest
import os
import sys
import logging
from unittest.mock import patch, MagicMock

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from PyraUtils.common._email import EmailSender

class TestEmailSender:
    """测试EmailSender类的功能"""
    
    # 测试初始化方法
    def test_init_valid_params(self):
        """测试使用有效参数初始化EmailSender"""
        sender = EmailSender(
            smtp_server="smtp.example.com",
            smtp_port=465,
            sender_email="sender@example.com",
            password="test_password"
        )
        
        assert sender.smtp_server == "smtp.example.com"
        assert sender.smtp_port == 465
        assert sender.sender_email == "sender@example.com"
        assert sender.password == "test_password"
        assert sender.timeout == 30
    
    def test_init_invalid_port(self):
        """测试使用无效端口初始化EmailSender"""
        with pytest.raises(ValueError):
            EmailSender(
                smtp_server="smtp.example.com",
                smtp_port=70000,  # 无效端口
                sender_email="sender@example.com",
                password="test_password"
            )
    
    def test_init_custom_timeout(self):
        """测试使用自定义超时初始化EmailSender"""
        sender = EmailSender(
            smtp_server="smtp.example.com",
            smtp_port=465,
            sender_email="sender@example.com",
            password="test_password",
            timeout=60
        )
        
        assert sender.timeout == 60
    
    # 测试send_email方法
    @patch('smtplib.SMTP_SSL')
    def test_send_email_single_recipient(self, mock_smtp):
        """测试发送邮件给单个收件人"""
        # 配置mock
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        sender = EmailSender(
            smtp_server="smtp.example.com",
            smtp_port=465,
            sender_email="sender@example.com",
            password="test_password"
        )
        
        # 发送邮件
        result = sender.send_email(
            subject="测试邮件",
            body="这是一封测试邮件内容",
            receiver_email="receiver@example.com",
            is_html=True
        )
        
        # 验证结果
        assert result is True
        mock_smtp.assert_called_once_with("smtp.example.com", 465, timeout=30)
        mock_server.login.assert_called_once_with("sender@example.com", "test_password")
        mock_server.sendmail.assert_called_once()
    
    @patch('smtplib.SMTP_SSL')
    def test_send_email_multiple_recipients(self, mock_smtp):
        """测试发送邮件给多个收件人"""
        # 配置mock
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        sender = EmailSender(
            smtp_server="smtp.example.com",
            smtp_port=465,
            sender_email="sender@example.com",
            password="test_password"
        )
        
        # 发送邮件
        result = sender.send_email(
            subject="测试邮件",
            body="这是一封测试邮件内容",
            receiver_email=["receiver1@example.com", "receiver2@example.com"],
            is_html=True
        )
        
        # 验证结果
        assert result is True
        mock_server.sendmail.assert_called_once()
        args, kwargs = mock_server.sendmail.call_args
        assert args[0] == "sender@example.com"
        assert args[1] == ["receiver1@example.com", "receiver2@example.com"]
    
    @patch('smtplib.SMTP_SSL')
    def test_send_email_plain_text(self, mock_smtp):
        """测试发送纯文本邮件"""
        # 配置mock
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        sender = EmailSender(
            smtp_server="smtp.example.com",
            smtp_port=465,
            sender_email="sender@example.com",
            password="test_password"
        )
        
        # 发送邮件
        result = sender.send_email(
            subject="测试邮件",
            body="这是一封纯文本测试邮件",
            receiver_email="receiver@example.com",
            is_html=False
        )
        
        # 验证结果
        assert result is True
    
    @patch('smtplib.SMTP_SSL')
    def test_send_email_smtp_error(self, mock_smtp):
        """测试发送邮件时SMTP服务器错误"""
        # 配置mock抛出SMTPException
        mock_server = MagicMock()
        mock_server.login.side_effect = smtplib.SMTPException("Authentication failed")
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        sender = EmailSender(
            smtp_server="smtp.example.com",
            smtp_port=465,
            sender_email="sender@example.com",
            password="test_password"
        )
        
        # 发送邮件
        result = sender.send_email(
            subject="测试邮件",
            body="这是一封测试邮件内容",
            receiver_email="receiver@example.com",
            is_html=True
        )
        
        # 验证结果
        assert result is False
    
    @patch('smtplib.SMTP_SSL')
    def test_send_email_timeout(self, mock_smtp):
        """测试发送邮件时超时"""
        # 配置mock抛出超时异常
        mock_smtp.side_effect = smtplib.socket.timeout("Connection timed out")
        
        sender = EmailSender(
            smtp_server="smtp.example.com",
            smtp_port=465,
            sender_email="sender@example.com",
            password="test_password"
        )
        
        # 发送邮件
        result = sender.send_email(
            subject="测试邮件",
            body="这是一封测试邮件内容",
            receiver_email="receiver@example.com",
            is_html=True
        )
        
        # 验证结果
        assert result is False

# 导入smtplib用于测试异常
import smtplib

if __name__ == "__main__":
    pytest.main([__file__])
