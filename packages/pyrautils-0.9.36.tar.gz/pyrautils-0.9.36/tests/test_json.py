import pytest
import os
import sys
import tempfile
import json as json_module

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from PyraUtils.common._json import JsonUtils

class TestJsonUtils:
    """测试JsonUtils类的功能"""
    
    def setup_method(self):
        """在每个测试方法前创建临时文件"""
        # 创建临时文件用于测试
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.json', mode='w')
        self.temp_file.close()
    
    def teardown_method(self):
        """在每个测试方法后清理临时文件"""
        # 删除临时文件
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)
    
    def test_load_json_valid(self):
        """测试加载有效的JSON文件"""
        # 写入测试数据
        test_data = {"name": "John", "age": 30, "city": "New York"}
        with open(self.temp_file.name, 'w', encoding='utf8') as f:
            json_module.dump(test_data, f)
        
        # 加载JSON文件
        result = JsonUtils.load_json(self.temp_file.name)
        
        assert result == test_data
    
    def test_load_json_invalid(self):
        """测试加载无效的JSON文件"""
        # 写入无效的JSON数据
        with open(self.temp_file.name, 'w', encoding='utf8') as f:
            f.write("{name: 'John', age: 30}")  # 无效的JSON格式
        
        # 加载JSON文件
        result = JsonUtils.load_json(self.temp_file.name)
        
        assert result is None
    
    def test_load_json_nonexistent(self):
        """测试加载不存在的JSON文件"""
        # 尝试加载不存在的文件
        with pytest.raises(OSError):
            JsonUtils.load_json("nonexistent_file.json")
    
    def test_set_json_to_file_from_dict(self):
        """测试从字典写入JSON文件"""
        test_data = {"name": "John", "age": 30, "city": "New York"}
        
        # 写入JSON文件
        result = JsonUtils.set_json_to_file(test_data, self.temp_file.name)
        
        assert result is True
        
        # 验证文件内容
        with open(self.temp_file.name, 'r', encoding='utf8') as f:
            content = json_module.load(f)
        
        assert content == test_data
    
    def test_set_json_to_file_from_string(self):
        """测试从JSON字符串写入JSON文件"""
        test_json_str = '{"name": "John", "age": 30, "city": "New York"}'
        test_data = {"name": "John", "age": 30, "city": "New York"}
        
        # 写入JSON文件
        result = JsonUtils.set_json_to_file(test_json_str, self.temp_file.name)
        
        assert result is True
        
        # 验证文件内容
        with open(self.temp_file.name, 'r', encoding='utf8') as f:
            content = json_module.load(f)
        
        assert content == test_data
    
    def test_set_json_to_file_invalid_string(self):
        """测试从无效JSON字符串写入JSON文件"""
        invalid_json_str = '{name: "John", age: 30}'
        
        # 尝试写入无效JSON
        result = JsonUtils.set_json_to_file(invalid_json_str, self.temp_file.name)
        
        assert result is None
    
    def test_get_json_value_existing(self):
        """测试获取存在的JSON值"""
        # 写入测试数据
        test_data = {"name": "John", "age": 30, "city": "New York"}
        with open(self.temp_file.name, 'w', encoding='utf8') as f:
            json_module.dump(test_data, f)
        
        # 获取JSON值
        result = JsonUtils.get_json_value(self.temp_file.name, "name")
        
        assert result == "John"
    
    def test_get_json_value_nonexistent(self):
        """测试获取不存在的JSON值"""
        # 写入测试数据
        test_data = {"name": "John", "age": 30, "city": "New York"}
        with open(self.temp_file.name, 'w', encoding='utf8') as f:
            json_module.dump(test_data, f)
        
        # 获取不存在的键
        result = JsonUtils.get_json_value(self.temp_file.name, "nonexistent_key")
        
        assert result is None
    
    def test_set_value_new_key(self):
        """测试在JSON文件中设置新键"""
        # 写入初始数据
        initial_data = {"name": "John", "age": 30}
        with open(self.temp_file.name, 'w', encoding='utf8') as f:
            json_module.dump(initial_data, f)
        
        # 设置新键值对
        result = JsonUtils.set_value(self.temp_file.name, "city", "New York")
        
        assert result is True
        
        # 验证结果
        with open(self.temp_file.name, 'r', encoding='utf8') as f:
            content = json_module.load(f)
        
        assert content == {"name": "John", "age": 30, "city": "New York"}
    
    def test_set_value_update_existing(self):
        """测试在JSON文件中更新现有键"""
        # 写入初始数据
        initial_data = {"name": "John", "age": 30}
        with open(self.temp_file.name, 'w', encoding='utf8') as f:
            json_module.dump(initial_data, f)
        
        # 更新现有键
        result = JsonUtils.set_value(self.temp_file.name, "age", 31)
        
        assert result is True
        
        # 验证结果
        with open(self.temp_file.name, 'r', encoding='utf8') as f:
            content = json_module.load(f)
        
        assert content == {"name": "John", "age": 31}
    
    def test_set_value_nonexistent_file(self):
        """测试在不存在的JSON文件中设置值"""
        # 删除临时文件
        os.unlink(self.temp_file.name)
        
        # 设置键值对到不存在的文件
        result = JsonUtils.set_value(self.temp_file.name, "name", "John")
        
        assert result is True
        
        # 验证文件被创建且内容正确
        with open(self.temp_file.name, 'r', encoding='utf8') as f:
            content = json_module.load(f)
        
        assert content == {"name": "John"}
    
    def test_loads_json_value_valid(self):
        """测试解析有效的JSON字符串"""
        test_json_str = '{"name": "John", "age": 30}'
        
        result = JsonUtils.loads_json_value(test_json_str)
        
        assert result == {"name": "John", "age": 30}
    
    def test_loads_json_value_invalid(self):
        """测试解析无效的JSON字符串"""
        invalid_json_str = '{name: "John", age: 30}'
        
        result = JsonUtils.loads_json_value(invalid_json_str)
        
        assert result is None
    
    def test_is_json_valid_dict(self):
        """测试判断有效的JSON字典"""
        test_data = {"name": "John", "age": 30}
        
        result = JsonUtils.is_json(test_data)
        
        assert result is True
    
    def test_is_json_valid_string(self):
        """测试判断有效的JSON字符串"""
        test_json_str = '{"name": "John", "age": 30}'
        
        result = JsonUtils.is_json(test_json_str)
        
        assert result is True
    
    def test_is_json_invalid(self):
        """测试判断无效的JSON"""
        invalid_json_str = '{name: "John", age: 30}'
        
        result = JsonUtils.is_json(invalid_json_str)
        
        assert result is False
    
    def test_json_to_markdown_basic(self):
        """测试将基本JSON转换为Markdown"""
        test_data = {"name": "John", "age": 30, "city": "New York"}
        
        result = JsonUtils.json_to_markdown(test_data)
        
        assert "# name" in result
        assert "- **name**: John" in result
        assert "- **age**: 30" in result
        assert "- **city**: New York" in result
    
    def test_json_to_markdown_nested(self):
        """测试将嵌套JSON转换为Markdown"""
        test_data = {
            "person": {
                "name": "John",
                "age": 30,
                "address": {
                    "city": "New York",
                    "zipcode": "12345"
                }
            }
        }
        
        result = JsonUtils.json_to_markdown(test_data)
        
        assert "# person" in result
        assert "# address" in result
        assert "- **name**: John" in result
        assert "- **city**: New York" in result
        assert "- **zipcode**: 12345" in result
    
    def test_json_to_markdown_list(self):
        """测试将包含列表的JSON转换为Markdown"""
        test_data = {
            "fruits": ["apple", "banana", "orange"]
        }
        
        result = JsonUtils.json_to_markdown(test_data)
        
        assert "# fruits" in result
        assert "- apple" in result
        assert "- banana" in result
        assert "- orange" in result
    
    def test_json_to_markdown_from_string(self):
        """测试将JSON字符串转换为Markdown"""
        test_json_str = '{"name": "John", "age": 30}'
        
        result = JsonUtils.json_to_markdown(test_json_str)
        
        assert "# name" in result
        assert "- **name**: John" in result
        assert "- **age**: 30" in result

if __name__ == "__main__":
    pytest.main([__file__])
