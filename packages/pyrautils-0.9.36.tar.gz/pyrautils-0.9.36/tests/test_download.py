import pytest
import os
import sys
import tempfile
from unittest import mock

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from PyraUtils.common.download import DownloadUtil, DownloadProgressUtil

class TestDownloadUtil:
    """测试DownloadUtil类的功能"""
    
    def setup_method(self):
        """在每个测试方法前创建临时文件"""
        # 创建临时目录
        self.temp_dir = tempfile.mkdtemp()
        # 创建临时文件路径
        self.test_file = os.path.join(self.temp_dir, "test_file.txt")
        self.test_url = "https://example.com/test.txt"
    
    def teardown_method(self):
        """在每个测试方法后清理临时文件"""
        # 清理临时文件
        if os.path.exists(self.test_file):
            os.remove(self.test_file)
        # 清理临时目录
        os.rmdir(self.temp_dir)
    
    @mock.patch('PyraUtils.common.download.requests.get')
    def test_dl_01_success(self, mock_get):
        """测试dl_01方法下载成功的情况"""
        # 模拟响应
        mock_resp = mock.Mock()
        mock_resp.content = b"Hello, World!"
        mock_resp.raise_for_status = mock.Mock()
        mock_get.return_value = mock_resp
        
        # 执行下载
        result = DownloadUtil.dl_01(self.test_url, self.test_file)
        
        # 验证结果
        assert result is True
        assert os.path.exists(self.test_file)
        with open(self.test_file, "rb") as f:
            assert f.read() == b"Hello, World!"
        mock_get.assert_called_once()
    
    @mock.patch('PyraUtils.common.download.requests.get')
    def test_dl_01_failure(self, mock_get):
        """测试dl_01方法下载失败的情况"""
        # 模拟请求异常
        from requests.exceptions import RequestException
        mock_get.side_effect = RequestException("Network error")
        
        # 执行下载
        result = DownloadUtil.dl_01(self.test_url, self.test_file)
        
        # 验证结果
        assert result is False
        assert not os.path.exists(self.test_file)
        mock_get.assert_called_once()
    
    @mock.patch('PyraUtils.common.download.urllib3.PoolManager')
    def test_dl_02_success(self, mock_pool_manager):
        """测试dl_02方法下载成功的情况"""
        # 模拟连接池和响应
        mock_http = mock.Mock()
        mock_resp = mock.Mock()
        mock_resp.data = b"Hello, World!"
        mock_http.request.return_value = mock_resp
        mock_pool_manager.return_value = mock_http
        
        # 执行下载
        DownloadUtil.dl_02(self.test_url, self.test_file)
        
        # 验证结果
        assert os.path.exists(self.test_file)
        with open(self.test_file, "rb") as f:
            assert f.read() == b"Hello, World!"
        mock_pool_manager.assert_called_once()
        mock_http.request.assert_called_once_with('GET', self.test_url)
    
    @mock.patch('PyraUtils.common.download.requests.get')
    def test_dl_03_success(self, mock_get):
        """测试dl_03方法下载成功的情况"""
        # 模拟响应
        mock_resp = mock.Mock()
        mock_resp.status_code = 200
        mock_resp.headers = {'content-length': '13'}
        # 模拟 iter_content 方法，使其返回一个生成器
        def mock_iter_content(chunk_size):
            yield b"Hello"
            yield b", "
            yield b"World!"
        mock_resp.iter_content = mock_iter_content
        mock_resp.raise_for_status = mock.Mock()
        # 确保status_code可以进行整数比较
        type(mock_resp).status_code = mock.PropertyMock(return_value=200)
        # 模拟 requests.get 的返回值（不需要上下文管理器，因为 closing 会处理）
        mock_get.return_value = mock_resp
        
        # 执行下载
        result = DownloadUtil.dl_03(self.test_url, self.test_file)
        
        # 验证结果
        assert result == 'success'
        assert os.path.exists(self.test_file)
        with open(self.test_file, "rb") as f:
            content = f.read()
            print(f"File content: {content}")
            assert content == b"Hello, World!"
        mock_get.assert_called_once()
    
    @mock.patch('PyraUtils.common.download.requests.get')
    def test_dl_03_zero_size(self, mock_get):
        """测试dl_03方法下载文件大小为0的情况"""
        # 模拟响应
        mock_resp = mock.Mock()
        mock_resp.status_code = 200
        mock_resp.headers = {'content-length': '0'}
        mock_resp.raise_for_status = mock.Mock()
        # 确保status_code可以进行整数比较
        type(mock_resp).status_code = mock.PropertyMock(return_value=200)
        # 模拟 requests.get 的返回值
        mock_get.return_value = mock_resp
        
        # 执行下载
        result = DownloadUtil.dl_03(self.test_url, self.test_file)
        
        # 验证结果
        print(f"Result: {result}")
        print(f"Expected: size0 {self.test_url}")
        assert result == f'size0 {self.test_url}'
        assert not os.path.exists(self.test_file)
        mock_get.assert_called_once()
    
    @mock.patch('PyraUtils.common.download.requests.get')
    def test_dl_03_request_error(self, mock_get):
        """测试dl_03方法请求错误的情况"""
        # 模拟请求异常
        mock_resp = mock.Mock()
        mock_resp.status_code = 200
        mock_resp.headers = {'content-length': '13'}
        # 模拟 iter_content 方法，使其抛出异常
        def mock_iter_content(chunk_size):
            raise Exception("Request error")
        mock_resp.iter_content = mock_iter_content
        mock_resp.raise_for_status = mock.Mock()
        # 确保status_code可以进行整数比较
        type(mock_resp).status_code = mock.PropertyMock(return_value=200)
        # 模拟 requests.get 的返回值
        mock_get.return_value = mock_resp
        
        # 执行下载
        result = DownloadUtil.dl_03(self.test_url, self.test_file)
        
        # 验证结果
        print(f"Result: {result}")
        assert result.startswith('RequestError')
        mock_get.assert_called_once()
    
    @mock.patch('PyraUtils.common.download.requests.get')
    def test_dl_04_success(self, mock_get):
        """测试dl_04方法下载成功的情况"""
        # 模拟响应
        mock_resp = mock.Mock()
        mock_resp.status_code = 200
        mock_resp.headers = {'content-length': '13'}
        mock_resp.iter_content.return_value = [b"Hello", b", ", b"World!"]
        mock_resp.raise_for_status = mock.Mock()
        mock_get.return_value.__enter__.return_value = mock_resp
        
        # 执行下载
        DownloadUtil.dl_04(self.test_url, self.test_file)
        
        # 验证结果
        assert os.path.exists(self.test_file)
        with open(self.test_file, "rb") as f:
            assert f.read() == b"Hello, World!"
        mock_get.assert_called_once()
    
    @mock.patch('PyraUtils.common.download.requests.head')
    @mock.patch('PyraUtils.common.download.requests.get')
    def test_dl_04_resume_download(self, mock_get, mock_head):
        """测试dl_04方法断点续传的情况"""
        # 先创建一个部分下载的文件
        with open(self.test_file, "wb") as f:
            f.write(b"Hello")
        
        # 模拟HEAD响应
        mock_head_resp = mock.Mock()
        mock_head_resp.status_code = 200
        mock_head_resp.headers = {'content-length': '13'}
        mock_head_resp.raise_for_status = mock.Mock()
        mock_head.return_value = mock_head_resp
        
        # 模拟GET响应
        mock_resp = mock.Mock()
        mock_resp.status_code = 206  # Partial Content
        mock_resp.iter_content.return_value = [b", ", b"World!"]
        mock_resp.raise_for_status = mock.Mock()
        mock_get.return_value.__enter__.return_value = mock_resp
        
        # 执行下载
        DownloadUtil.dl_04(self.test_url, self.test_file)
        
        # 验证结果
        assert os.path.exists(self.test_file)
        with open(self.test_file, "rb") as f:
            assert f.read() == b"Hello, World!"
        mock_head.assert_called_once()
        mock_get.assert_called_once()
    
    @mock.patch('PyraUtils.common.download.requests.head')
    def test_dl_04_file_already_complete(self, mock_head):
        """测试dl_04方法文件已经完整的情况"""
        # 创建完整文件
        with open(self.test_file, "wb") as f:
            f.write(b"Hello, World!")
        
        # 模拟HEAD响应
        mock_head_resp = mock.Mock()
        mock_head_resp.status_code = 200
        mock_head_resp.headers = {'content-length': '13'}
        mock_head_resp.raise_for_status = mock.Mock()
        mock_head.return_value = mock_head_resp
        
        # 执行下载
        DownloadUtil.dl_04(self.test_url, self.test_file)
        
        # 验证结果
        assert os.path.exists(self.test_file)
        with open(self.test_file, "rb") as f:
            assert f.read() == b"Hello, World!"
        mock_head.assert_called_once()

class TestDownloadProgressUtil:
    """测试DownloadProgressUtil类的功能"""
    
    def setup_method(self):
        """在每个测试方法前创建临时文件"""
        # 创建临时目录
        self.temp_dir = tempfile.mkdtemp()
        # 创建临时文件路径
        self.test_file = os.path.join(self.temp_dir, "test_file.txt")
        self.test_url = "https://example.com/test.txt"
    
    def teardown_method(self):
        """在每个测试方法后清理临时文件"""
        # 清理临时文件
        if os.path.exists(self.test_file):
            os.remove(self.test_file)
        # 清理临时目录
        os.rmdir(self.temp_dir)
    
    @mock.patch('PyraUtils.common.download.httpx.stream')
    @mock.patch('PyraUtils.common.download.tqdm')
    def test_dl_01_success(self, mock_tqdm, mock_stream):
        """测试dl_01方法下载成功的情况"""
        # 模拟响应
        mock_resp = mock.Mock()
        mock_resp.headers = {'Content-Length': '13'}
        mock_resp.num_bytes_downloaded = 0
        mock_resp.iter_bytes.return_value = [b"Hello", b", ", b"World!"]
        
        # 模拟num_bytes_downloaded递增
        def side_effect(chunk_size):
            chunks = [b"Hello", b", ", b"World!"]
            for i, chunk in enumerate(chunks):
                mock_resp.num_bytes_downloaded = sum(len(c) for c in chunks[:i+1])
                yield chunk
        
        mock_resp.iter_bytes.side_effect = side_effect
        mock_stream.return_value.__enter__.return_value = mock_resp
        
        # 创建进度条实例
        progress_instance = mock.Mock()
        mock_tqdm.return_value.__enter__.return_value = progress_instance
        
        # 执行下载
        downloader = DownloadProgressUtil()
        downloader.dl_01(self.test_url, self.test_file)
        
        # 验证结果
        assert os.path.exists(self.test_file)
        with open(self.test_file, "rb") as f:
            assert f.read() == b"Hello, World!"
        mock_stream.assert_called_once()
        mock_tqdm.assert_called_once()
    
    @mock.patch('PyraUtils.common.download.httpx.stream')
    @mock.patch('PyraUtils.common.download.rich.progress.Progress')
    def test_dl_02_success(self, mock_progress, mock_stream):
        """测试dl_02方法下载成功的情况"""
        # 模拟响应
        mock_resp = mock.Mock()
        mock_resp.headers = {'Content-Length': '13'}
        mock_resp.num_bytes_downloaded = 0
        mock_resp.iter_bytes.return_value = [b"Hello", b", ", b"World!"]
        
        # 模拟num_bytes_downloaded递增
        def side_effect(chunk_size):
            chunks = [b"Hello", b", ", b"World!"]
            for i, chunk in enumerate(chunks):
                mock_resp.num_bytes_downloaded = sum(len(c) for c in chunks[:i+1])
                yield chunk
        
        mock_resp.iter_bytes.side_effect = side_effect
        mock_stream.return_value.__enter__.return_value = mock_resp
        
        # 创建进度条实例
        progress_instance = mock.Mock()
        task_id = 1
        progress_instance.add_task.return_value = task_id
        mock_progress.return_value.__enter__.return_value = progress_instance
        
        # 执行下载
        downloader = DownloadProgressUtil()
        downloader.dl_02(self.test_url, self.test_file)
        
        # 验证结果
        assert os.path.exists(self.test_file)
        with open(self.test_file, "rb") as f:
            assert f.read() == b"Hello, World!"
        mock_stream.assert_called_once()
        mock_progress.assert_called_once()
        progress_instance.add_task.assert_called_once()

if __name__ == "__main__":
    pytest.main([__file__])