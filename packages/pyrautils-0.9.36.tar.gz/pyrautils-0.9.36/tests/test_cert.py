#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CertUtils 测试用例
"""

import unittest
import ssl
import socket
from unittest.mock import patch, MagicMock
from PyraUtils.common.cert import CertUtils


class TestCertUtils(unittest.TestCase):
    """
    CertUtils 类的测试用例
    """
    
    def setUp(self):
        """
        每个测试方法执行前的设置
        """
        self.cert_utils = CertUtils()
    
    @patch('ssl._ssl._test_decode_cert')
    def test_get_ssl_file_info_success(self, mock_test_decode_cert):
        """
        测试成功获取SSL文件信息
        """
        mock_cert_info = {
            'subject': ((('commonName', 'example.com'),),),
            'issuer': ((('commonName', 'Example CA'),),),
            'version': 3
        }
        mock_test_decode_cert.return_value = mock_cert_info
        
        cert_file = '/path/to/cert.pem'
        result = self.cert_utils.get_ssl_file_info(cert_file)
        
        self.assertEqual(result, mock_cert_info)
        mock_test_decode_cert.assert_called_once_with(cert_file)
    
    @patch('ssl._ssl._test_decode_cert')
    def test_get_ssl_file_info_failure(self, mock_test_decode_cert):
        """
        测试获取SSL文件信息失败
        """
        mock_test_decode_cert.side_effect = ssl.SSLError("Failed to read cert")
        
        cert_file = '/path/to/nonexistent_cert.pem'
        with self.assertRaises(RuntimeError):
            self.cert_utils.get_ssl_file_info(cert_file)
        
        mock_test_decode_cert.assert_called_once_with(cert_file)
    
    @patch('OpenSSL.crypto.load_certificate')
    @patch('OpenSSL.crypto.dump_certificate')
    def test_load_x509_cert_use_openssl_pem(self, mock_dump_cert, mock_load_cert):
        """
        测试使用OpenSSL加载PEM格式证书
        """
        mock_cert_data = b"cert data"
        mock_cert_x509 = MagicMock()
        mock_load_cert.return_value = mock_cert_x509
        mock_dump_cert.return_value = b"dumped cert"
        
        result = self.cert_utils.load_x509_cert_use_openssl(mock_cert_data, "pem")
        
        self.assertEqual(result, b"dumped cert")
        mock_load_cert.assert_called_once()
        mock_dump_cert.assert_called_once()
    
    @patch('OpenSSL.crypto.load_certificate')
    @patch('OpenSSL.crypto.dump_certificate')
    def test_load_x509_cert_use_openssl_der(self, mock_dump_cert, mock_load_cert):
        """
        测试使用OpenSSL加载DER格式证书
        """
        mock_cert_data = b"cert data"
        mock_cert_x509 = MagicMock()
        mock_load_cert.return_value = mock_cert_x509
        mock_dump_cert.return_value = b"dumped cert"
        
        result = self.cert_utils.load_x509_cert_use_openssl(mock_cert_data, "der")
        
        self.assertEqual(result, b"dumped cert")
        mock_load_cert.assert_called_once()
        mock_dump_cert.assert_called_once()
    
    def test_load_x509_cert_use_openssl_invalid_format(self):
        """
        测试使用OpenSSL加载无效格式证书
        """
        mock_cert_data = b"cert data"
        
        with self.assertRaises(ValueError):
            self.cert_utils.load_x509_cert_use_openssl(mock_cert_data, "invalid_format")
    
    def test_load_x509_cert_use_openssl_non_bytes(self):
        """
        测试使用OpenSSL加载非字节类型的证书数据
        """
        mock_cert_data = "cert data"  # 字符串而不是字节
        
        with self.assertRaises(AssertionError):
            self.cert_utils.load_x509_cert_use_openssl(mock_cert_data, "pem")
    
    @patch('cryptography.x509.load_pem_x509_certificate')
    def test_load_x509_cert_use_cryptography_pem(self, mock_load_pem):
        """
        测试使用cryptography加载PEM格式证书
        """
        mock_cert_data = b"cert data"
        mock_cert = MagicMock()
        mock_load_pem.return_value = mock_cert
        
        result = self.cert_utils.load_x509_cert_use_cryptography(mock_cert_data, "pem")
        
        self.assertEqual(result, mock_cert)
        mock_load_pem.assert_called_once()
    
    @patch('cryptography.x509.load_der_x509_certificate')
    def test_load_x509_cert_use_cryptography_der(self, mock_load_der):
        """
        测试使用cryptography加载DER格式证书
        """
        mock_cert_data = b"cert data"
        mock_cert = MagicMock()
        mock_load_der.return_value = mock_cert
        
        result = self.cert_utils.load_x509_cert_use_cryptography(mock_cert_data, "der")
        
        self.assertEqual(result, mock_cert)
        mock_load_der.assert_called_once()
    
    def test_load_x509_cert_use_cryptography_invalid_format(self):
        """
        测试使用cryptography加载无效格式证书
        """
        mock_cert_data = b"cert data"
        
        with self.assertRaises(ValueError):
            self.cert_utils.load_x509_cert_use_cryptography(mock_cert_data, "invalid_format")
    
    def test_load_x509_cert_use_cryptography_non_bytes(self):
        """
        测试使用cryptography加载非字节类型的证书数据
        """
        mock_cert_data = "cert data"  # 字符串而不是字节
        
        with self.assertRaises(AssertionError):
            self.cert_utils.load_x509_cert_use_cryptography(mock_cert_data, "pem")
    
    @patch('ssl.SSLContext.wrap_socket')
    def test_get_ssl_url_info_success(self, mock_wrap_socket):
        """
        测试成功获取SSL URL信息
        """
        mock_conn = MagicMock()
        mock_wrap_socket.return_value = mock_conn
        mock_cert_info = {
            'subject': ((('commonName', 'example.com'),),),
            'issuer': ((('commonName', 'Example CA'),),),
            'version': 3
        }
        mock_conn.getpeercert.return_value = mock_cert_info
        
        hostname = "example.com"
        port = 443
        result = self.cert_utils.get_ssl_url_info(hostname, port)
        
        self.assertEqual(result, mock_cert_info)
        mock_wrap_socket.assert_called_once()
        mock_conn.connect.assert_called_once_with((hostname, port))
        mock_conn.getpeercert.assert_called_once()
        mock_conn.close.assert_called_once()
    
    @patch('ssl.SSLContext.wrap_socket')
    def test_get_ssl_url_info_failure(self, mock_wrap_socket):
        """
        测试获取SSL URL信息失败
        """
        mock_conn = MagicMock()
        mock_wrap_socket.return_value = mock_conn
        mock_conn.connect.side_effect = socket.timeout
        
        hostname = "example.com"
        port = 443
        
        with self.assertRaises(RuntimeError):
            self.cert_utils.get_ssl_url_info(hostname, port)
        
        mock_wrap_socket.assert_called_once()
        mock_conn.connect.assert_called_once_with((hostname, port))
        mock_conn.close.assert_called_once()
    
    def test_get_ssl_url_info_invalid_port(self):
        """
        测试使用无效端口获取SSL URL信息
        """
        hostname = "example.com"
        
        # 测试端口为负数
        with self.assertRaises(ValueError):
            self.cert_utils.get_ssl_url_info(hostname, -1)
        
        # 测试端口为0
        with self.assertRaises(ValueError):
            self.cert_utils.get_ssl_url_info(hostname, 0)
        
        # 测试端口超出范围
        with self.assertRaises(ValueError):
            self.cert_utils.get_ssl_url_info(hostname, 65536)


if __name__ == "__main__":
    unittest.main()