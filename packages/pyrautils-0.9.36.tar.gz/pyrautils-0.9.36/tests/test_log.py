import pytest
import os
import sys
import tempfile

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from PyraUtils.log import LoguruHandler, LoggingHandler, LoggingFileHandler

class TestLoguruHandler:
    """测试LoguruHandler类的功能"""
    
    def setup_method(self):
        """在每个测试方法前创建LoguruHandler实例"""
        self.logger = LoguruHandler()
    
    def test_info(self):
        """测试info方法"""
        # 测试info方法是否能正常调用
        try:
            self.logger.info("Test info message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"info方法调用失败: {e}"
    
    def test_error(self):
        """测试error方法"""
        # 测试error方法是否能正常调用
        try:
            self.logger.error("Test error message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"error方法调用失败: {e}"
    
    def test_warning(self):
        """测试warning方法"""
        # 测试warning方法是否能正常调用
        try:
            self.logger.warning("Test warning message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"warning方法调用失败: {e}"
    
    def test_debug(self):
        """测试debug方法"""
        # 测试debug方法是否能正常调用
        try:
            self.logger.debug("Test debug message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"debug方法调用失败: {e}"

class TestLoggingHandler:
    """测试LoggingHandler类的功能"""
    
    def setup_method(self):
        """在每个测试方法前创建LoggingHandler实例（启用文件输出用于测试）"""
        self.logger = LoggingHandler(file=True)  # 显式启用文件输出
    
    def teardown_method(self):
        """在每个测试方法后清理生成的日志文件"""
        # 清理 default.log 文件
        default_log = "default.log"
        if os.path.exists(default_log):
            try:
                os.unlink(default_log)
            except:
                pass
    
    def test_info(self):
        """测试info方法"""
        # 测试info方法是否能正常调用
        try:
            self.logger.info("Test info message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"info方法调用失败: {e}"
    
    def test_error(self):
        """测试error方法"""
        # 测试error方法是否能正常调用
        try:
            self.logger.error("Test error message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"error方法调用失败: {e}"
    
    def test_warning(self):
        """测试warning方法"""
        # 测试warning方法是否能正常调用
        try:
            self.logger.warning("Test warning message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"warning方法调用失败: {e}"
    
    def test_debug(self):
        """测试debug方法"""
        # 测试debug方法是否能正常调用
        try:
            self.logger.debug("Test debug message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"debug方法调用失败: {e}"

class TestLoggingFileHandler:
    """测试LoggingFileHandler类的功能"""
    
    def setup_method(self):
        """在每个测试方法前创建LoggingFileHandler实例"""
        self.logger = LoggingFileHandler()
    
    def teardown_method(self):
        """在每个测试方法后清理临时文件"""
        # 清理临时文件
        if hasattr(self, 'temp_file') and self.temp_file and os.path.exists(self.temp_file):
            try:
                os.unlink(self.temp_file)
            except:
                pass
    
    def test_info(self):
        """测试info方法"""
        # 创建临时文件用于测试
        with tempfile.NamedTemporaryFile(delete=False, suffix='.log') as f:
            self.temp_file = f.name
        # 获取logger实例
        test_logger = self.logger.get_logger("test", self.temp_file)
        # 测试info方法是否能正常调用
        try:
            test_logger.info("Test info message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"info方法调用失败: {e}"
    
    def test_error(self):
        """测试error方法"""
        # 创建临时文件用于测试
        with tempfile.NamedTemporaryFile(delete=False, suffix='.log') as f:
            self.temp_file = f.name
        # 获取logger实例
        test_logger = self.logger.get_logger("test", self.temp_file)
        # 测试error方法是否能正常调用
        try:
            test_logger.error("Test error message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"error方法调用失败: {e}"
    
    def test_warning(self):
        """测试warning方法"""
        # 创建临时文件用于测试
        with tempfile.NamedTemporaryFile(delete=False, suffix='.log') as f:
            self.temp_file = f.name
        # 获取logger实例
        test_logger = self.logger.get_logger("test", self.temp_file)
        # 测试warning方法是否能正常调用
        try:
            test_logger.warning("Test warning message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"warning方法调用失败: {e}"
    
    def test_debug(self):
        """测试debug方法"""
        # 创建临时文件用于测试
        with tempfile.NamedTemporaryFile(delete=False, suffix='.log') as f:
            self.temp_file = f.name
        # 获取logger实例
        test_logger = self.logger.get_logger("test", self.temp_file)
        # 测试debug方法是否能正常调用
        try:
            test_logger.debug("Test debug message")
            # 如果没有抛出异常，则测试通过
            assert True
        except Exception as e:
            assert False, f"debug方法调用失败: {e}"

if __name__ == "__main__":
    pytest.main([__file__])