"""
Supreme 2 Light Core Module
Core scanning engine, parallel execution, and reporting
"""

from supreme_max.core.parallel import Supreme2lParallelScanner
from supreme_max.core.reporter import Supreme2lReportGenerator

__all__ = ["Supreme2lParallelScanner", "Supreme2lReportGenerator"]
