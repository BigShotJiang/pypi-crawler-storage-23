# saar

**Extract the essence of your codebase.**

Saar auto-generates AI coding config files (CLAUDE.md, .cursorrules, copilot-instructions.md) from deep static analysis of your codebase using tree-sitter AST parsing.

## Coming Soon

```bash
pip install saar
saar ./my-repo --format all
```

## What it does

Saar reads your codebase and detects architectural patterns, coding conventions, and team rules -- then generates the config files that make AI coding tools actually understand how your team writes code.

No cloud. No API keys. Runs locally. Open source.
