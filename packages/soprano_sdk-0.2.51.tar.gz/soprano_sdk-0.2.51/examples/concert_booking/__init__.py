"""
Concert Ticket Booking Example

This example demonstrates MFA (Multi-Factor Authentication) functionality
in a concert ticket booking workflow.
"""
