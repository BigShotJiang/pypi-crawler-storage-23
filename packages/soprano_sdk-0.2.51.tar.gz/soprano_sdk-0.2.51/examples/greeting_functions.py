def create_personalized_greeting(state: dict) -> str:
    name = state.get('username') or state.get('name')
    age = state.get('age')
    weight = state.get('weight')
    height = state.get('height')
    phone_number = state.get('phone_number')
    parts = [f"Name: {name}"]
    if age:
        parts.append(f"Age: {age}")
    if weight:
        parts.append(f"Weight: {weight}")
    if height:
        parts.append(f"Height: {height}")
    if phone_number:
        parts.append(f"Phone Number: {phone_number}")
    return "\n    ".join(parts)
