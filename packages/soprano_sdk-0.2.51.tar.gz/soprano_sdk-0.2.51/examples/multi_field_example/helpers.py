import re


def validate_email(email: str, **kwargs):
    """Validate that the email has a basic valid format."""
    if not email or not re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', email):
        return False, "Please provide a valid email address (e.g. user@example.com)."
    return True, None


def validate_phone(phone: str, **kwargs):
    """Validate that the phone number is 10 digits."""
    digits = re.sub(r'\D', '', phone or '')
    if len(digits) != 10:
        return False, "Phone number must be exactly 10 digits."
    return True, None


def generate_onboarding_summary(state: dict) -> str:
    """Generate a summary of the collected customer information."""
    return (
        f"Onboarding complete!\n"
        f"  Name:  {state.get('customer_name')}\n"
        f"  Email: {state.get('email')}\n"
        f"  Phone: {state.get('phone')}\n"
        f"  City:  {state.get('city')}\n"
        f"  Zip:   {state.get('zip_code')}"
    )
