#!/usr/bin/env python3
"""
Runner for the multi-field collection example workflow.

Tests both single-field (name) and multi-field (email+phone, city+zip) collection.

Usage:
    # Interactive mode (default) - talk to the agent
    python run.py

    # With pre-populated context (skips name collection)
    python run.py --context '{"customer_name": "Alice"}'

    # With all contact fields pre-populated (skips to address collection)
    python run.py --context '{"customer_name": "Alice", "email": "alice@test.com", "phone": "1234567890"}'

    # Use Ollama instead of OpenAI
    python run.py --provider ollama --model llama3.2

    # Use a custom OpenAI-compatible endpoint
    OPENAI_BASE_URL=http://localhost:1234/v1 python run.py
"""

import os
import sys

# Add parent dirs to path so imports work when running directly
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from concert_booking.example_runner import main as runner_main


def main():
    """Run the multi-field example using the generic WorkflowRunner."""
    yaml_path = os.path.join(os.path.dirname(__file__), 'multi_field_workflow.yaml')

    # Patch sys.argv so the generic runner picks up our YAML
    # if no YAML path was explicitly provided
    if len(sys.argv) == 1:
        sys.argv = [sys.argv[0], yaml_path]
    elif not os.path.exists(sys.argv[1]):
        # If the first arg doesn't look like a file, insert our yaml
        sys.argv.insert(1, yaml_path)

    runner_main()


if __name__ == "__main__":
    main()
