"""
Tests for WorkflowResult and its integration with WorkflowTool.execute() / resume().

Covers:
- WorkflowResult(str) subclass behavior: equality, string ops, field_details attribute
- execute() returns WorkflowResult across all code paths (interrupt, completion, async, out-of-scope)
- resume() returns WorkflowResult across all code paths
- Validation failure scenario: field_details carries errors and failed values
- Backward compatibility: existing string patterns still work
"""

from unittest.mock import MagicMock, patch

from soprano_sdk.core.models import WorkflowResult, MessagePayload
from soprano_sdk.core.constants import InterruptType
from soprano_sdk.tools import WorkflowTool


# ===========================================================================
# A. WorkflowResult class unit tests
# ===========================================================================

class TestWorkflowResultClass:
    def test_isinstance_str(self):
        """WorkflowResult is a str."""
        r = WorkflowResult("hello")
        assert isinstance(r, str)

    def test_equality_with_plain_str(self):
        """WorkflowResult("x") == "x" is True in both directions."""
        r = WorkflowResult("hello")
        assert r == "hello"
        assert "hello" == r

    # --- text, options, is_selectable defaults ---

    def test_text_defaults_to_value(self):
        """text defaults to the raw string value when not explicitly set."""
        r = WorkflowResult("hello world")
        assert r.text == "hello world"

    def test_text_explicit(self):
        """text can be set explicitly, independent of value."""
        r = WorkflowResult("__WORKFLOW_INTERRUPT__|t|n|prompt", text="prompt")
        assert r.text == "prompt"
        assert r.value == "__WORKFLOW_INTERRUPT__|t|n|prompt"

    def test_options_default_empty(self):
        """Default options is []."""
        r = WorkflowResult("msg")
        assert r.options == []

    def test_options_populated(self):
        """options carries the provided list."""
        r = WorkflowResult("msg", options=["VIP", "Premium", "General"])
        assert r.options == ["VIP", "Premium", "General"]

    def test_options_none_gives_empty_list(self):
        """Passing None explicitly results in []."""
        r = WorkflowResult("msg", options=None)
        assert r.options == []

    def test_options_dict_format_text_subtext(self):
        """options accepts list of dicts with text/subtext keys."""
        opts = [
            {"text": "Yes", "subtext": ""},
            {"text": "No", "subtext": ""},
        ]
        r = WorkflowResult("msg", options=opts, is_selectable=True)
        assert r.options == opts
        assert r.options[0]["text"] == "Yes"
        assert r.options[1]["subtext"] == ""

    def test_options_dict_format_with_subtext_values(self):
        """options preserves non-empty subtext fields (e.g. pricing, URLs)."""
        opts = [
            {"text": "Basic", "subtext": "Free"},
            {"text": "Pro", "subtext": "$9/month"},
            {"text": "Help Center", "subtext": "https://example.com/help"},
        ]
        r = WorkflowResult("Choose a plan:", options=opts, is_selectable=True)
        assert len(r.options) == 3
        assert r.options[1]["subtext"] == "$9/month"
        assert r.options[2]["subtext"] == "https://example.com/help"

    def test_is_selectable_default_false(self):
        """Default is_selectable is False."""
        r = WorkflowResult("msg")
        assert r.is_selectable is False

    def test_is_selectable_true(self):
        """is_selectable can be set to True."""
        r = WorkflowResult("msg", is_selectable=True)
        assert r.is_selectable is True

    def test_all_new_attributes_together(self):
        """All new attributes work together."""
        r = WorkflowResult(
            "__WORKFLOW_INTERRUPT__|t|n|Choose seat",
            text="Choose seat",
            options=["VIP", "General"],
            is_selectable=True,
            field_details=[{"name": "seat"}],
        )
        assert r.text == "Choose seat"
        assert r.options == ["VIP", "General"]
        assert r.is_selectable is True
        assert r.field_details == [{"name": "seat"}]
        assert r.value == "__WORKFLOW_INTERRUPT__|t|n|Choose seat"

    def test_string_startswith(self):
        r = WorkflowResult("__WORKFLOW_INTERRUPT__|tid|name|prompt")
        assert r.startswith("__WORKFLOW_INTERRUPT__")

    def test_string_contains(self):
        r = WorkflowResult("__WORKFLOW_INTERRUPT__|tid|name|prompt")
        assert "__WORKFLOW_INTERRUPT__" in r

    def test_string_split(self):
        r = WorkflowResult("a|b|c|d")
        parts = r.split("|")
        assert parts == ["a", "b", "c", "d"]

    def test_string_slicing(self):
        r = WorkflowResult("abcdefgh")
        assert r[:3] == "abc"
        assert r[2:5] == "cde"

    def test_str_conversion(self):
        """str(result) returns the plain string."""
        r = WorkflowResult("done", field_details=[{"name": "email"}])
        assert str(r) == "done"

    def test_field_details_default_empty(self):
        """Default field_details is []."""
        r = WorkflowResult("msg")
        assert r.field_details == []

    def test_field_details_populated(self):
        """field_details carries the provided data."""
        details = [{"name": "email", "value": "bad@", "error": "Invalid"}]
        r = WorkflowResult("prompt", field_details=details)
        assert r.field_details == details
        assert r.field_details[0]["error"] == "Invalid"

    def test_field_details_none_gives_empty_list(self):
        """Passing None explicitly results in []."""
        r = WorkflowResult("msg", field_details=None)
        assert r.field_details == []

    def test_repr_without_details(self):
        r = WorkflowResult("hello")
        assert "WorkflowResult" in repr(r)

    def test_repr_with_details(self):
        r = WorkflowResult("hello", field_details=[{"name": "x"}])
        assert "field_details" in repr(r)

    def test_hash_matches_str(self):
        """WorkflowResult is usable as a dict key like str."""
        r = WorkflowResult("key")
        d = {r: 1}
        assert d["key"] == 1

    def test_len(self):
        r = WorkflowResult("abc")
        assert len(r) == 3

    def test_format_string(self):
        """f-string formatting works."""
        r = WorkflowResult("world")
        assert f"hello {r}" == "hello world"

    def test_value_attribute_returns_string(self):
        """result.value returns the raw string content."""
        r = WorkflowResult("hello world")
        assert r.value == "hello world"
        assert isinstance(r.value, str)

    def test_value_equals_str_content(self):
        """result.value matches str(result) and direct comparison."""
        r = WorkflowResult("__WORKFLOW_INTERRUPT__|t|n|prompt", field_details=[{"name": "x"}])
        assert r.value == str(r)
        assert r.value == r

    def test_value_is_plain_str_not_workflow_result(self):
        """result.value is a plain str, not a WorkflowResult."""
        r = WorkflowResult("test")
        assert type(r.value) is str
        assert not isinstance(r.value, WorkflowResult)

    def test_importable_from_package(self):
        """WorkflowResult is importable from the top-level package."""
        from soprano_sdk import WorkflowResult as WR
        assert WR is WorkflowResult


# ===========================================================================
# B. execute() returns WorkflowResult – integration tests
# ===========================================================================

class TestExecuteReturnsWorkflowResult:

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_user_input_interrupt(self, mock_cb, mock_trace, mock_load):
        """execute() returning a user input interrupt is a WorkflowResult."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_interrupt = MagicMock()
        mock_interrupt.value = "Please enter your email"
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}

        expected_details = [{"name": "email", "value": None}]
        mock_engine.build_field_details.return_value = expected_details

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert isinstance(result, WorkflowResult)
        assert isinstance(result, str)
        assert result.startswith(InterruptType.USER_INPUT)
        assert "Please enter your email" in result
        assert result.field_details == expected_details
        # Structured access via .value
        assert "Please enter your email" in result.value
        assert isinstance(result.value, str)
        # New attributes — plain string interrupt has no options
        assert result.text == "Please enter your email"
        assert result.options == []
        assert result.is_selectable is False

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_user_input_interrupt_with_options(self, mock_cb, mock_trace, mock_load):
        """execute() with structured dict interrupt carries options."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "text": "Select your seat preference:",
            "options": ["VIP", "Premium", "General"],
            "is_selectable": True,
        }
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert isinstance(result, WorkflowResult)
        assert result.startswith(InterruptType.USER_INPUT)
        assert result.text == "Select your seat preference:"
        assert result.options == ["VIP", "Premium", "General"]
        assert result.is_selectable is True
        # Backward compat: value string still contains the interrupt format
        assert "|Select your seat preference:" in result.value

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_completion(self, mock_cb, mock_trace, mock_load):
        """execute() completing the workflow returns WorkflowResult."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_graph.invoke.return_value = {"outcome": "done"}
        mock_engine.get_outcome_message.return_value = MessagePayload("Success", None, False)
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert isinstance(result, WorkflowResult)
        assert result == "Success"
        assert result.value == "Success"
        assert result.text == "Success"
        assert result.options == []
        assert result.is_selectable is False
        assert result.field_details == []

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_async_interrupt(self, mock_cb, mock_trace, mock_load):
        """execute() returning an async interrupt is a WorkflowResult."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "async",
            "step_id": "payment",
            "pending": {"txn": "123"}
        }
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert isinstance(result, WorkflowResult)
        assert result.startswith(InterruptType.ASYNC)
        assert result.field_details == []

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_out_of_scope_interrupt(self, mock_cb, mock_trace, mock_load):
        """execute() returning an out-of-scope interrupt is a WorkflowResult."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "out_of_scope",
            "step_id": "collect_email",
            "reason": "Asked about weather",
            "user_message": "What's the weather?"
        }
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert isinstance(result, WorkflowResult)
        assert result.startswith(InterruptType.OUT_OF_SCOPE)
        assert result.field_details == []


# ===========================================================================
# C. resume() returns WorkflowResult – integration tests
# ===========================================================================

class TestResumeReturnsWorkflowResult:

    @patch('soprano_sdk.tools.load_workflow')
    def test_resume_user_input_interrupt(self, mock_load):
        """resume() returning an interrupt is a WorkflowResult."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)

        mock_interrupt = MagicMock()
        mock_interrupt.value = "Now enter your phone"
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}

        expected_details = [{"name": "phone", "value": None}]
        mock_engine.build_field_details.return_value = expected_details

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.resume(thread_id="t1", resume_value="test@email.com")

        assert isinstance(result, WorkflowResult)
        assert isinstance(result, str)
        assert result.startswith(InterruptType.USER_INPUT)
        assert result.field_details == expected_details

    @patch('soprano_sdk.tools.load_workflow')
    def test_resume_user_input_interrupt_with_options(self, mock_load):
        """resume() with structured dict interrupt carries options."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)

        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "text": "Pick a reason:",
            "options": ["Damaged", "Wrong size", "Changed mind"],
            "is_selectable": True,
        }
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.resume(thread_id="t1", resume_value="test@email.com")

        assert isinstance(result, WorkflowResult)
        assert result.text == "Pick a reason:"
        assert result.options == ["Damaged", "Wrong size", "Changed mind"]
        assert result.is_selectable is True

    @patch('soprano_sdk.tools.load_workflow')
    def test_resume_completion(self, mock_load):
        """resume() completing the workflow returns WorkflowResult."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)

        mock_graph.invoke.return_value = {"outcome": "done"}
        mock_engine.get_outcome_message.return_value = MessagePayload("All done", None, False)
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.resume(thread_id="t1", resume_value="final input")

        assert isinstance(result, WorkflowResult)
        assert result == "All done"
        assert result.field_details == []

    @patch('soprano_sdk.tools.load_workflow')
    def test_resume_async_interrupt(self, mock_load):
        """resume() returning an async interrupt is a WorkflowResult."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)

        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "async",
            "step_id": "check",
            "pending": {"id": "abc"}
        }
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.resume(thread_id="t1", resume_value="input")

        assert isinstance(result, WorkflowResult)
        assert result.startswith(InterruptType.ASYNC)

    @patch('soprano_sdk.tools.load_workflow')
    def test_resume_out_of_scope_interrupt(self, mock_load):
        """resume() returning out-of-scope is a WorkflowResult."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)

        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "out_of_scope",
            "step_id": "s1",
            "reason": "off topic",
            "user_message": "tell me a joke"
        }
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.resume(thread_id="t1", resume_value="tell me a joke")

        assert isinstance(result, WorkflowResult)
        assert result.startswith(InterruptType.OUT_OF_SCOPE)


# ===========================================================================
# D. Validation failure scenario – field_details carries errors
# ===========================================================================

class TestFieldDetailsOnValidationFailure:

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_field_details_has_validation_errors_on_interrupt(
        self, mock_cb, mock_trace, mock_load
    ):
        """After a validation failure, the interrupt result carries field_details with errors."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_interrupt = MagicMock()
        mock_interrupt.value = "Email is invalid. Please re-enter."
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}

        # Simulate what build_field_details returns after a validation failure
        mock_engine.build_field_details.return_value = [
            {"name": "email", "value": "bad@", "error": "Invalid email format"},
            {"name": "phone", "value": "1234567890"},
        ]

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert isinstance(result, WorkflowResult)
        assert len(result.field_details) == 2
        assert result.field_details[0]["name"] == "email"
        assert result.field_details[0]["error"] == "Invalid email format"
        assert result.field_details[0]["value"] == "bad@"
        assert result.field_details[1]["name"] == "phone"
        assert "error" not in result.field_details[1]

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_field_details_empty_when_no_active_collector(
        self, mock_cb, mock_trace, mock_load
    ):
        """When no collector node is active (e.g. completed), field_details is []."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_graph.invoke.return_value = {"outcome": "done"}
        mock_engine.get_outcome_message.return_value = MessagePayload("Complete", None, False)
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert result.field_details == []

    @patch('soprano_sdk.tools.load_workflow')
    def test_resume_field_details_has_validation_errors(self, mock_load):
        """resume() also carries field_details with validation errors."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)

        mock_interrupt = MagicMock()
        mock_interrupt.value = "Phone is invalid."
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}

        mock_engine.build_field_details.return_value = [
            {"name": "phone", "value": "123", "error": "Must be 10 digits"},
        ]

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.resume(thread_id="t1", resume_value="123")

        assert isinstance(result, WorkflowResult)
        assert result.field_details[0]["error"] == "Must be 10 digits"
        assert result.field_details[0]["value"] == "123"


# ===========================================================================
# E. Backward compatibility
# ===========================================================================

class TestBackwardCompatibility:

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_existing_string_comparison_patterns(self, mock_cb, mock_trace, mock_load):
        """All existing string-based consumption patterns still work."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_interrupt = MagicMock()
        mock_interrupt.value = "Enter your order ID"
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="TestWF", description="T")
        result = wf.execute(thread_id="test-thread", initial_context={})

        # Pattern: InterruptType.USER_INPUT in result
        assert InterruptType.USER_INPUT in result

        # Pattern: result.startswith(...)
        assert result.startswith("__WORKFLOW_INTERRUPT__")

        # Pattern: result.split("|")
        parts = result.split("|")
        assert parts[0] == InterruptType.USER_INPUT
        assert parts[1] == "test-thread"
        assert parts[2] == "TestWF"
        assert len(parts) >= 4

        # Pattern: slicing
        _ = result[:100]

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_existing_equality_comparison(self, mock_cb, mock_trace, mock_load):
        """result == "Success" still works for completion path."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_graph.invoke.return_value = {"outcome": "done"}
        mock_engine.get_outcome_message.return_value = MessagePayload("Success", None, False)
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert result == "Success"
        assert "Success" == result

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_existing_interrupt_string_format(self, mock_cb, mock_trace, mock_load):
        """The exact interrupt string format matches the old behavior."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = ["waiting"]
        mock_state.values = {}
        mock_graph.get_state.return_value = mock_state

        mock_interrupt = MagicMock()
        mock_interrupt.value = "Please provide your order ID"
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="TestWorkflow", description="T")
        result = wf.execute(
            thread_id="test-thread",
            user_message="12345",
            initial_context={"key": "value"}
        )

        expected = "__WORKFLOW_INTERRUPT__|test-thread|TestWorkflow|Please provide your order ID"
        assert result == expected
