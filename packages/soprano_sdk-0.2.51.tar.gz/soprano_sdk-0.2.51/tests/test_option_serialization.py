"""
Tests for Option model migration from Pydantic BaseModel to TypedDict.

Covers:
- OptionDict is a plain dict at runtime (JSON-serializable)
- MessagePayload accepts OptionDict lists
- HumanizedResponse._OptionSchema converts to plain dicts via model_dump()
- WorkflowResult options are always JSON-serializable
- End-to-end: _humanize_message returns dicts, not Pydantic objects
- _build_result passes options through without needing conversion
"""

import json
from unittest.mock import MagicMock, patch

from soprano_sdk.core.models import OptionDict, MessagePayload, WorkflowResult
from soprano_sdk.core.engine import HumanizedResponse
from soprano_sdk.tools import WorkflowTool


# ===========================================================================
# A. OptionDict (TypedDict) unit tests
# ===========================================================================

class TestOptionDict:
    def test_is_plain_dict(self):
        """OptionDict instances are plain dicts at runtime."""
        opt: OptionDict = {"text": "Yes", "subtext": ""}
        assert isinstance(opt, dict)

    def test_json_serializable(self):
        """OptionDict is natively JSON-serializable."""
        opt: OptionDict = {"text": "Basic", "subtext": "Free"}
        serialized = json.dumps(opt)
        assert '"text": "Basic"' in serialized

    def test_list_of_options_json_serializable(self):
        """A list of OptionDicts is JSON-serializable."""
        opts = [
            {"text": "VIP", "subtext": "Full access"},
            {"text": "General", "subtext": ""},
        ]
        serialized = json.dumps(opts)
        parsed = json.loads(serialized)
        assert len(parsed) == 2
        assert parsed[0]["text"] == "VIP"

    def test_subtext_optional(self):
        """OptionDict works without subtext (total=False)."""
        opt: OptionDict = {"text": "Only text"}
        assert json.dumps(opt)  # Should not raise


# ===========================================================================
# B. MessagePayload with OptionDict
# ===========================================================================

class TestMessagePayloadWithOptionDict:
    def test_accepts_option_dicts(self):
        """MessagePayload stores OptionDict lists correctly."""
        opts = [{"text": "A", "subtext": "desc A"}, {"text": "B", "subtext": ""}]
        payload = MessagePayload("Choose:", opts, True)
        assert payload.options == opts
        assert payload.is_selectable is True

    def test_options_default_none(self):
        """MessagePayload options defaults to None."""
        payload = MessagePayload("Hello")
        assert payload.options is None

    def test_options_json_serializable(self):
        """MessagePayload options are always JSON-serializable."""
        opts = [{"text": "X", "subtext": "Y"}]
        payload = MessagePayload("msg", opts)
        serialized = json.dumps(payload.options)
        assert '"text": "X"' in serialized


# ===========================================================================
# C. HumanizedResponse._OptionSchema → dict conversion
# ===========================================================================

class TestHumanizedResponseOptionConversion:
    def test_option_schema_model_dump(self):
        """_OptionSchema.model_dump() produces a plain dict."""
        schema = HumanizedResponse._OptionSchema(text="Premium", subtext="$9/mo")
        dumped = schema.model_dump()
        assert isinstance(dumped, dict)
        assert dumped == {"text": "Premium", "subtext": "$9/mo"}

    def test_option_schema_default_subtext(self):
        """_OptionSchema defaults subtext to empty string."""
        schema = HumanizedResponse._OptionSchema(text="Basic")
        dumped = schema.model_dump()
        assert dumped == {"text": "Basic", "subtext": ""}

    def test_humanized_response_options_to_dicts(self):
        """HumanizedResponse.options converts to list of dicts via model_dump()."""
        response = HumanizedResponse(
            message="Pick one:",
            options=[
                HumanizedResponse._OptionSchema(text="A", subtext="first"),
                HumanizedResponse._OptionSchema(text="B", subtext="second"),
            ],
            is_selectable=True,
        )
        converted = [opt.model_dump() for opt in response.options]
        assert converted == [
            {"text": "A", "subtext": "first"},
            {"text": "B", "subtext": "second"},
        ]
        assert all(isinstance(opt, dict) for opt in converted)
        assert json.dumps(converted)  # JSON-serializable

    def test_humanized_response_none_options(self):
        """HumanizedResponse with None options stays None."""
        response = HumanizedResponse(message="No options here")
        assert response.options is None

    def test_humanized_response_empty_options(self):
        """HumanizedResponse with empty list stays empty."""
        response = HumanizedResponse(message="No options", options=[])
        converted = [opt.model_dump() for opt in response.options]
        assert converted == []


# ===========================================================================
# D. WorkflowResult JSON serialization
# ===========================================================================

class TestWorkflowResultJsonSerialization:
    def test_options_json_serializable(self):
        """WorkflowResult with dict options is JSON-serializable."""
        opts = [{"text": "Yes", "subtext": ""}, {"text": "No", "subtext": ""}]
        result = WorkflowResult("msg", options=opts, is_selectable=True)
        serialized = json.dumps(result.options)
        parsed = json.loads(serialized)
        assert parsed == opts

    def test_empty_options_json_serializable(self):
        """WorkflowResult with empty options is JSON-serializable."""
        result = WorkflowResult("msg")
        assert json.dumps(result.options) == "[]"

    def test_full_result_attributes_json_serializable(self):
        """All list/dict attributes on WorkflowResult are JSON-serializable."""
        result = WorkflowResult(
            "prompt",
            text="prompt",
            options=[{"text": "A", "subtext": "a"}],
            is_selectable=True,
            field_details=[{"name": "field1", "value": "val"}],
        )
        # Each attribute should serialize independently
        json.dumps(result.options)
        json.dumps(result.field_details)
        json.dumps({
            "text": result.text,
            "options": result.options,
            "is_selectable": result.is_selectable,
            "field_details": result.field_details,
        })


# ===========================================================================
# E. _humanize_message integration — returns dicts, not Pydantic objects
# ===========================================================================

class TestHumanizeMessageReturnsDicts:

    def _make_engine(self):
        """Create a minimal WorkflowEngine mock with real _humanize_message."""
        from soprano_sdk.core.engine import WorkflowEngine
        engine = MagicMock(spec=WorkflowEngine)
        engine._humanize_message = WorkflowEngine._humanize_message.__get__(engine)
        engine._get_humanization_model_config = MagicMock(return_value={
            "model_name": "test-model",
            "api_key": "test-key",
        })
        engine._get_humanization_config = MagicMock(return_value={})
        engine.get_config_value = MagicMock(return_value=None)
        engine._get_conversation_history = MagicMock(return_value=[])
        engine.get_localization_instructions = MagicMock(return_value="")
        return engine

    @patch("soprano_sdk.core.engine.get_model")
    def test_humanize_returns_dict_options(self, mock_get_model):
        """_humanize_message converts _OptionSchema to plain dicts."""
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = HumanizedResponse(
            message="Friendly message!",
            options=[
                HumanizedResponse._OptionSchema(text="VIP", subtext="All access"),
                HumanizedResponse._OptionSchema(text="Basic", subtext=""),
            ],
            is_selectable=True,
        )
        mock_get_model.return_value = mock_llm

        engine = self._make_engine()
        result = engine._humanize_message("Choose plan:", {})

        assert isinstance(result, MessagePayload)
        assert result.options == [
            {"text": "VIP", "subtext": "All access"},
            {"text": "Basic", "subtext": ""},
        ]
        assert all(isinstance(opt, dict) for opt in result.options)
        assert json.dumps(result.options)  # JSON-serializable

    @patch("soprano_sdk.core.engine.get_model")
    def test_humanize_none_options_falls_back_to_input(self, mock_get_model):
        """When LLM returns None options, falls back to input options."""
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = HumanizedResponse(
            message="Friendly!",
            options=None,
            is_selectable=None,
        )
        mock_get_model.return_value = mock_llm

        engine = self._make_engine()
        input_options = [{"text": "A", "subtext": ""}]
        result = engine._humanize_message("msg", {}, options=input_options, is_selectable=True)

        assert result.options == input_options
        assert result.is_selectable is True

    @patch("soprano_sdk.core.engine.get_model")
    def test_humanize_empty_options(self, mock_get_model):
        """When LLM returns empty options list, result has empty list."""
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = HumanizedResponse(
            message="No options here",
            options=[],
            is_selectable=False,
        )
        mock_get_model.return_value = mock_llm

        engine = self._make_engine()
        result = engine._humanize_message("msg", {})

        assert result.options == []
        assert json.dumps(result.options) == "[]"

    @patch("soprano_sdk.core.engine.get_model")
    def test_humanize_failure_returns_input_options(self, mock_get_model):
        """When humanization fails, input options (already dicts) are returned."""
        mock_get_model.side_effect = Exception("LLM error")

        engine = self._make_engine()
        input_options = [{"text": "Fallback", "subtext": ""}]
        result = engine._humanize_message("msg", {}, options=input_options, is_selectable=True)

        assert result.options == input_options
        assert result.is_selectable is True


# ===========================================================================
# F. _build_result — no conversion needed (options are already dicts)
# ===========================================================================

class TestBuildResultPassthrough:

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_dict_options_pass_through(self, mock_cb, mock_trace, mock_load):
        """_build_result passes dict options to WorkflowResult without conversion."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "text": "Pick:",
            "options": [
                {"text": "VIP", "subtext": "Full"},
                {"text": "Basic", "subtext": ""},
            ],
            "is_selectable": True,
        }
        mock_graph.invoke.return_value = {"__interrupt__": [mock_interrupt]}
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert isinstance(result, WorkflowResult)
        assert result.options == [
            {"text": "VIP", "subtext": "Full"},
            {"text": "Basic", "subtext": ""},
        ]
        assert json.dumps(result.options)  # JSON-serializable

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_outcome_options_json_serializable(self, mock_cb, mock_trace, mock_load):
        """Outcome with dict options produces JSON-serializable WorkflowResult."""
        mock_graph, mock_engine = MagicMock(), MagicMock()
        mock_load.return_value = (mock_graph, mock_engine)
        mock_trace.return_value.__enter__.return_value = MagicMock()

        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        mock_graph.invoke.return_value = {"outcome": "done"}
        opts = [{"text": "Rate us", "subtext": "1-5 stars"}]
        mock_engine.get_outcome_message.return_value = MessagePayload("Done!", opts, True)
        mock_engine.build_field_details.return_value = []

        wf = WorkflowTool(yaml_path="t.yaml", name="T", description="T")
        result = wf.execute(thread_id="t1", initial_context={})

        assert result.options == opts
        assert result.is_selectable is True
        serialized = json.dumps(result.options)
        assert json.loads(serialized) == opts
