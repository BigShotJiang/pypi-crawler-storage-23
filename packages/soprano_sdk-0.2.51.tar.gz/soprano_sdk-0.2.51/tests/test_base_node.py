"""
Tests for ActionStrategy base class - specifically error handling with custom failure messages.
"""

import pytest
from unittest.mock import MagicMock

from langgraph.errors import GraphInterrupt
from langgraph.types import Interrupt

from soprano_sdk.nodes.base import ActionStrategy
from soprano_sdk.core.constants import WorkflowKeys


class ConcreteActionStrategy(ActionStrategy):
    """Concrete implementation of ActionStrategy for testing."""

    def execute(self, state):
        """Execute implementation that can be controlled in tests."""
        if hasattr(self, 'should_raise') and self.should_raise:
            raise self.should_raise
        return state

    def pre_execute(self, state):
        """Pre-execute implementation."""
        return state


class TestActionStrategyErrorHandling:
    """Test suite for ActionStrategy error handling with custom failure messages."""

    @pytest.fixture
    def engine_context(self):
        """Create a mock engine context."""
        context = MagicMock()
        # Remove failure_message attribute by default so getattr returns None
        del context.failure_message
        return context

    @pytest.fixture
    def step_config(self):
        """Basic step config."""
        return {
            "id": "test_step",
            "action": "test_action",
        }

    @pytest.fixture
    def initial_state(self):
        """Initial workflow state."""
        return {
            WorkflowKeys.STATUS: "initial",
            "test_data": "test_value"
        }

    def test_exception_uses_custom_failure_message_when_available(
        self, step_config, engine_context, initial_state
    ):
        """Test that custom failure_message from engine context is used when exception occurs."""
        # Set custom failure message on engine context
        engine_context.failure_message = "Custom error: Please try again later"

        # Create strategy that will raise an exception
        strategy = ConcreteActionStrategy(step_config, engine_context)
        strategy.should_raise = ValueError("Original exception message")

        # Get the node function and execute it
        node_fn = strategy.get_node_function()
        result = node_fn(initial_state)

        # Verify custom error message is used
        assert result[WorkflowKeys.ERROR] == "Custom error: Please try again later"
        assert result[WorkflowKeys.OUTCOME_ID] == WorkflowKeys.ERROR
        assert result[WorkflowKeys.STATUS] == "test_step_error"

    def test_exception_uses_default_message_when_no_custom_message(
        self, step_config, engine_context, initial_state
    ):
        """Test that default error message is used when no custom failure_message is set."""
        # Don't set failure_message on engine context

        # Create strategy that will raise an exception
        strategy = ConcreteActionStrategy(step_config, engine_context)
        exception_msg = "Something went wrong"
        strategy.should_raise = RuntimeError(exception_msg)

        # Get the node function and execute it
        node_fn = strategy.get_node_function()
        result = node_fn(initial_state)

        # Verify default error message is used with exception details
        expected_message = f"Unable to complete the request: {exception_msg}"
        assert result[WorkflowKeys.ERROR] == expected_message
        assert result[WorkflowKeys.OUTCOME_ID] == WorkflowKeys.ERROR
        assert result[WorkflowKeys.STATUS] == "test_step_error"

    def test_exception_uses_default_when_empty_string(
        self, step_config, engine_context, initial_state
    ):
        """Test that empty string failure_message falls back to default message."""
        # Set custom failure message as empty string
        engine_context.failure_message = ""

        # Create strategy that will raise an exception
        strategy = ConcreteActionStrategy(step_config, engine_context)
        exception_msg = "Original exception"
        strategy.should_raise = ValueError(exception_msg)

        # Get the node function and execute it
        node_fn = strategy.get_node_function()
        result = node_fn(initial_state)

        # Verify empty string is NOT used (falls back to default due to truthy check)
        expected_message = f"Unable to complete the request: {exception_msg}"
        assert result[WorkflowKeys.ERROR] == expected_message

    def test_exception_with_none_custom_message_uses_default(
        self, step_config, engine_context, initial_state
    ):
        """Test that None custom failure_message falls back to default."""
        # Explicitly set to None
        engine_context.failure_message = None

        # Create strategy that will raise an exception
        strategy = ConcreteActionStrategy(step_config, engine_context)
        exception_msg = "Test exception"
        strategy.should_raise = ValueError(exception_msg)

        # Get the node function and execute it
        node_fn = strategy.get_node_function()
        result = node_fn(initial_state)

        # Verify default error message is used
        expected_message = f"Unable to complete the request: {exception_msg}"
        assert result[WorkflowKeys.ERROR] == expected_message

    def test_graph_interrupt_is_not_caught(
        self, step_config, engine_context, initial_state
    ):
        """Test that GraphInterrupt exceptions are re-raised, not handled."""
        # Create strategy that will raise GraphInterrupt
        strategy = ConcreteActionStrategy(step_config, engine_context)
        interrupt = Interrupt(value="User input required")
        strategy.should_raise = GraphInterrupt([interrupt])

        # Get the node function
        node_fn = strategy.get_node_function()

        # Verify GraphInterrupt is re-raised
        with pytest.raises(GraphInterrupt):
            node_fn(initial_state)

    def test_successful_execution_does_not_set_error(
        self, step_config, engine_context, initial_state
    ):
        """Test that successful execution does not set error fields."""
        # Create strategy that won't raise
        strategy = ConcreteActionStrategy(step_config, engine_context)

        # Get the node function and execute it
        node_fn = strategy.get_node_function()
        result = node_fn(initial_state)

        # Verify no error is set
        assert WorkflowKeys.ERROR not in result or result.get(WorkflowKeys.ERROR) is None

    def test_exception_preserves_existing_state_data(
        self, step_config, engine_context, initial_state
    ):
        """Test that exception handling preserves existing state data."""
        engine_context.failure_message = "Custom error message"

        # Create strategy that will raise an exception
        strategy = ConcreteActionStrategy(step_config, engine_context)
        strategy.should_raise = ValueError("Error")

        # Get the node function and execute it
        node_fn = strategy.get_node_function()
        result = node_fn(initial_state)

        # Verify existing state data is preserved
        assert result["test_data"] == "test_value"
        assert result[WorkflowKeys.STATUS] == "test_step_error"
        assert result[WorkflowKeys.ERROR] == "Custom error message"

    def test_state_already_has_error_sets_error_outcome(
        self, step_config, engine_context, initial_state
    ):
        """Test that if state already has an error, outcome is set to ERROR."""
        # Create strategy that returns state with error already set
        strategy = ConcreteActionStrategy(step_config, engine_context)

        # Override execute to set error in state
        def execute_with_error(state):
            state[WorkflowKeys.ERROR] = "Previous error"
            return state

        strategy.execute = execute_with_error

        # Get the node function and execute it
        node_fn = strategy.get_node_function()
        result = node_fn(initial_state)

        # Verify outcome is set to ERROR
        assert result[WorkflowKeys.OUTCOME_ID] == WorkflowKeys.ERROR
        assert result[WorkflowKeys.STATUS] == "test_step_error"

    def test_different_exception_types_use_custom_message(
        self, step_config, engine_context, initial_state
    ):
        """Test that custom message is used for different exception types."""
        engine_context.failure_message = "System temporarily unavailable"

        exception_types = [
            ValueError("value error"),
            RuntimeError("runtime error"),
            KeyError("key error"),
            AttributeError("attribute error"),
        ]

        for exception in exception_types:
            # Create fresh strategy for each exception type
            strategy = ConcreteActionStrategy(step_config, engine_context)
            strategy.should_raise = exception

            # Get the node function and execute it
            node_fn = strategy.get_node_function()
            result = node_fn(initial_state.copy())

            # Verify custom message is used for all exception types
            assert result[WorkflowKeys.ERROR] == "System temporarily unavailable"
            assert result[WorkflowKeys.OUTCOME_ID] == WorkflowKeys.ERROR