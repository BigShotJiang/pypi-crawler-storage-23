"""
Tests for multi-field collection capability.

Covers:
- CollectInputStrategy initialization with 'fields' (multi-field) vs 'field' (single)
- Field pre-population checks for multi-field
- Missing fields detection
- Multi-field value storage
- Per-field validation
- Workflow validator: field/fields mutual exclusivity, unknown field detection, validators config
- Engine: _get_collect_input_fields with multi-field steps
- Rollback: _clear_future_executions and DependencyBasedRollback with multi-field
"""

import pytest
from unittest.mock import MagicMock
from jinja2 import Environment
from soprano_sdk.nodes.collect_input import CollectInputStrategy
from soprano_sdk.validation.validator import WorkflowValidator
from soprano_sdk.core.constants import WorkflowKeys
from soprano_sdk.core.rollback_strategies import _clear_future_executions, DependencyBasedRollback


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_engine_context(**overrides):
    ctx = MagicMock()
    ctx.get_config_value.return_value = "history_based"
    ctx.data_fields = overrides.get("data_fields", [])
    ctx.workflow_description = "Test workflow"
    ctx.function_repository = MagicMock()
    ctx.function_repository.load.return_value = lambda **kw: (True, None)
    for k, v in overrides.items():
        if k != "data_fields":
            setattr(ctx, k, v)
    return ctx


def _make_strategy(step_config, engine_context=None):
    if engine_context is None:
        engine_context = _make_engine_context()
    return CollectInputStrategy(step_config, engine_context)


# ===========================================================================
# CollectInputStrategy – init and properties
# ===========================================================================

class TestMultiFieldInit:
    def test_single_field_legacy(self):
        """Single 'field' config still works and sets is_multi_field=False."""
        strategy = _make_strategy({"field": "name", "agent": {"name": "a"}})
        assert strategy.is_multi_field is False
        assert strategy.fields == ["name"]
        assert strategy.primary_field == "name"

    def test_multi_field(self):
        """'fields' config sets is_multi_field=True with correct primary."""
        strategy = _make_strategy({"fields": ["first_name", "last_name"], "agent": {"name": "a"}})
        assert strategy.is_multi_field is True
        assert strategy.fields == ["first_name", "last_name"]
        assert strategy.primary_field == "first_name"

    def test_missing_field_and_fields_raises(self):
        """Neither 'field' nor 'fields' raises RuntimeError."""
        with pytest.raises(RuntimeError, match="missing 'field' or 'fields'"):
            _make_strategy({"id": "s1", "agent": {"name": "a"}})

    def test_conversation_key_uses_primary_field(self):
        strategy = _make_strategy({"fields": ["city", "zip"], "agent": {"name": "a"}})
        assert strategy._conversation_key == "city_conversation"

    def test_formatted_field_name_multi(self):
        strategy = _make_strategy({"fields": ["first_name", "last_name"], "agent": {"name": "a"}})
        assert "First Name" in strategy._formatted_field_name
        assert "Last Name" in strategy._formatted_field_name

    def test_formatted_field_name_single(self):
        strategy = _make_strategy({"field": "order_id", "agent": {"name": "a"}})
        assert strategy._formatted_field_name == "Order Id"

    def test_scope_description_fallback_multi_field(self):
        """Fallback scope_description should list all fields, not just primary."""
        strategy = _make_strategy({"fields": ["email", "phone"], "agent": {"name": "a"}})
        assert strategy.scope_description == "Test workflow. Currently: collecting email, phone"

    def test_scope_description_fallback_single_field(self):
        """Fallback scope_description for single field still works."""
        strategy = _make_strategy({"field": "order_id", "agent": {"name": "a"}})
        assert strategy.scope_description == "Test workflow. Currently: collecting order_id"

    def test_scope_description_explicit_description_overrides(self):
        """Explicit agent description takes precedence over auto-generated."""
        strategy = _make_strategy({
            "fields": ["email", "phone"],
            "agent": {"name": "a", "description": "Collect contact info"},
        })
        assert strategy.scope_description == "Test workflow. Currently: Collect contact info"


# ===========================================================================
# Field population and missing fields
# ===========================================================================

class TestFieldPopulationChecks:
    def test_is_pre_populated_all_present(self):
        strategy = _make_strategy({"fields": ["a", "b"], "agent": {"name": "a"}})
        state = {"a": 1, "b": 2}
        assert strategy._is_field_pre_populated(state) is True

    def test_is_pre_populated_partial(self):
        strategy = _make_strategy({"fields": ["a", "b"], "agent": {"name": "a"}})
        state = {"a": 1, "b": None}
        assert strategy._is_field_pre_populated(state) is False

    def test_is_pre_populated_none(self):
        strategy = _make_strategy({"fields": ["a", "b"], "agent": {"name": "a"}})
        state = {}
        assert strategy._is_field_pre_populated(state) is False

    def test_get_missing_fields(self):
        strategy = _make_strategy({"fields": ["x", "y", "z"], "agent": {"name": "a"}})
        state = {"x": 10, "y": None}
        assert strategy._get_missing_fields(state) == ["y", "z"]

    def test_get_missing_fields_all_present(self):
        strategy = _make_strategy({"fields": ["x", "y"], "agent": {"name": "a"}})
        state = {"x": 1, "y": 2}
        assert strategy._get_missing_fields(state) == []


# ===========================================================================
# Value storage
# ===========================================================================

class TestStoreFieldValues:
    def test_store_single_field(self):
        ctx = _make_engine_context(data_fields=[{"name": "age", "type": "number"}])
        strategy = _make_strategy({"field": "age", "agent": {"name": "a"}}, ctx)
        state = {}
        strategy._store_field_value(state, "25")
        assert state["age"] == 25

    def test_store_single_field_text(self):
        ctx = _make_engine_context(data_fields=[{"name": "name", "type": "text"}])
        strategy = _make_strategy({"field": "name", "agent": {"name": "a"}}, ctx)
        state = {}
        strategy._store_field_value(state, "Alice")
        assert state["name"] == "Alice"

    def test_store_multi_field_values(self):
        ctx = _make_engine_context(data_fields=[
            {"name": "first", "type": "text"},
            {"name": "last", "type": "text"},
        ])
        strategy = _make_strategy({"fields": ["first", "last"], "agent": {"name": "a"}}, ctx)
        state = {}
        strategy._store_field_values(state, {"first": "Alice", "last": "Smith"})
        assert state["first"] == "Alice"
        assert state["last"] == "Smith"

    def test_store_multi_field_partial(self):
        """Only provided values are stored; missing ones left untouched."""
        ctx = _make_engine_context(data_fields=[
            {"name": "first", "type": "text"},
            {"name": "last", "type": "text"},
        ])
        strategy = _make_strategy({"fields": ["first", "last"], "agent": {"name": "a"}}, ctx)
        state = {"first": None, "last": None}
        strategy._store_field_values(state, {"first": "Bob"})
        assert state["first"] == "Bob"
        assert state["last"] is None

    def test_store_multi_field_number_coercion(self):
        ctx = _make_engine_context(data_fields=[
            {"name": "quantity", "type": "number"},
            {"name": "label", "type": "text"},
        ])
        strategy = _make_strategy({"fields": ["quantity", "label"], "agent": {"name": "a"}}, ctx)
        state = {}
        strategy._store_field_values(state, {"quantity": "5", "label": "box"})
        assert state["quantity"] == 5
        assert state["label"] == "box"


# ===========================================================================
# Per-field validation
# ===========================================================================

class TestPerFieldValidation:
    def test_per_field_validator_pass(self):
        ctx = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        ctx.function_repository.load.return_value = lambda **kw: (True, None)
        strategy = _make_strategy({
            "fields": ["email", "phone"],
            "agent": {"name": "a"},
            "validators": {"email": "mod.validate_email"},
        }, ctx)
        state = {"email": "a@b.com", "phone": "123"}
        is_valid, msg = strategy._validate_collected_input(state)
        assert is_valid is True

    def test_per_field_validator_fail(self):
        def bad_validator(**kw):
            return False, "Invalid email format"

        ctx = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        ctx.function_repository.load.return_value = bad_validator
        strategy = _make_strategy({
            "fields": ["email", "phone"],
            "agent": {"name": "a"},
            "validators": {"email": "mod.validate_email"},
        }, ctx)
        state = {"email": "bad", "phone": "123"}
        is_valid, msg = strategy._validate_collected_input(state)
        assert is_valid is False
        assert "email" in msg
        # Field should be cleared on validation failure
        assert state["email"] is None

    def test_legacy_single_validator_still_works(self):
        def legacy_validator(**kw):
            return kw.get("age", 0) > 0, "Age must be positive"

        ctx = _make_engine_context(data_fields=[{"name": "age", "type": "number"}])
        ctx.function_repository.load.return_value = legacy_validator
        strategy = _make_strategy({
            "field": "age",
            "agent": {"name": "a"},
            "validator": "mod.validate_age",
        }, ctx)
        state = {"age": -1}
        is_valid, msg = strategy._validate_collected_input(state)
        assert is_valid is False

    def test_legacy_validator_stored_in_field_validators(self):
        """Legacy 'validator' config is stored in field_validators keyed by primary_field."""
        def validator_fn(**kw):
            return True, None

        ctx = _make_engine_context(data_fields=[{"name": "name", "type": "text"}])
        ctx.function_repository.load.return_value = validator_fn
        strategy = _make_strategy({
            "field": "name",
            "agent": {"name": "a"},
            "validator": "mod.validate_name",
        }, ctx)
        assert "name" in strategy.field_validators
        assert strategy.field_validators["name"] is validator_fn
        assert not hasattr(strategy, "validator")

    def test_legacy_validator_pass(self):
        """Legacy single 'validator' passes through the unified per-field path."""
        ctx = _make_engine_context(data_fields=[{"name": "age", "type": "number"}])
        ctx.function_repository.load.return_value = lambda **kw: (True, None)
        strategy = _make_strategy({
            "field": "age",
            "agent": {"name": "a"},
            "validator": "mod.validate_age",
        }, ctx)
        state = {"age": 25}
        is_valid, msg = strategy._validate_collected_input(state)
        assert is_valid is True
        assert msg is None
        assert state["age"] == 25

    def test_legacy_validator_fail_clears_field(self):
        """Legacy single 'validator' failure clears the field and returns error as-is."""
        ctx = _make_engine_context(data_fields=[{"name": "age", "type": "number"}])
        ctx.function_repository.load.return_value = lambda **kw: (False, "Must be positive")
        strategy = _make_strategy({
            "field": "age",
            "agent": {"name": "a"},
            "validator": "mod.validate_age",
        }, ctx)
        state = {"age": -1}
        is_valid, msg = strategy._validate_collected_input(state)
        assert is_valid is False
        assert state["age"] is None
        assert msg == "Must be positive"

    def test_no_validators_configured(self):
        """No validator or validators config means validation always passes."""
        ctx = _make_engine_context(data_fields=[{"name": "city", "type": "text"}])
        strategy = _make_strategy({
            "field": "city",
            "agent": {"name": "a"},
        }, ctx)
        assert strategy.field_validators == {}
        state = {"city": "anything"}
        is_valid, msg = strategy._validate_collected_input(state)
        assert is_valid is True
        assert msg is None

    def test_legacy_and_per_field_validators_share_field_validators(self):
        """Both 'validator' and 'validators' are stored in field_validators."""
        def validator_fn(**kw):
            return True, None

        # Legacy single validator
        ctx1 = _make_engine_context(data_fields=[{"name": "email", "type": "text"}])
        ctx1.function_repository.load.return_value = validator_fn
        s1 = _make_strategy({"field": "email", "agent": {"name": "a"}, "validator": "mod.v"}, ctx1)

        # Per-field validators
        ctx2 = _make_engine_context(data_fields=[{"name": "email", "type": "text"}])
        ctx2.function_repository.load.return_value = validator_fn
        s2 = _make_strategy({"field": "email", "agent": {"name": "a"}, "validators": {"email": "mod.v"}}, ctx2)

        # Both stored in field_validators keyed by field name
        assert "email" in s1.field_validators
        assert "email" in s2.field_validators

    def test_multi_field_error_prefixed_single_field_not(self):
        """Multi-field validator errors are prefixed with field name; single-field are not."""
        def reject(**kw):
            return False, "bad value"

        # Single-field: error returned as-is
        ctx1 = _make_engine_context(data_fields=[{"name": "email", "type": "text"}])
        ctx1.function_repository.load.return_value = reject
        s1 = _make_strategy({"field": "email", "agent": {"name": "a"}, "validator": "mod.v"}, ctx1)
        state1 = {"email": "x"}
        _, msg1 = s1._validate_collected_input(state1)
        assert msg1 == "bad value"

        # Multi-field: error prefixed with field name
        ctx2 = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        ctx2.function_repository.load.return_value = reject
        s2 = _make_strategy({"fields": ["email", "phone"], "agent": {"name": "a"}, "validators": {"email": "mod.v"}}, ctx2)
        state2 = {"email": "x", "phone": "123"}
        _, msg2 = s2._validate_collected_input(state2)
        assert msg2 == "email: bad value"

    def test_multi_field_validates_all_fields_not_fail_fast(self):
        """When multiple fields fail validation, all errors are returned together."""
        def reject_email(**kw):
            return False, "Invalid email format"

        def reject_phone(**kw):
            return False, "Phone must be 10 digits"

        ctx = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        validators = {"email": reject_email, "phone": reject_phone}
        ctx.function_repository.load.side_effect = lambda path: validators[path.split(".")[-1]]
        strategy = _make_strategy({
            "fields": ["email", "phone"],
            "agent": {"name": "a"},
            "validators": {"email": "mod.email", "phone": "mod.phone"},
        }, ctx)
        state = {"email": "bad", "phone": "123"}
        is_valid, msg = strategy._validate_collected_input(state)
        assert is_valid is False
        # Both fields should be cleared
        assert state["email"] is None
        assert state["phone"] is None
        # Both errors should be present
        assert "email: Invalid email format" in msg
        assert "phone: Phone must be 10 digits" in msg

    def test_multi_field_partial_failure_only_reports_failing_fields(self):
        """When one field passes and another fails, only the failing field error is returned."""
        def accept_email(**kw):
            return True, None

        def reject_phone(**kw):
            return False, "Phone must be 10 digits"

        ctx = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        validators = {"email": accept_email, "phone": reject_phone}
        ctx.function_repository.load.side_effect = lambda path: validators[path.split(".")[-1]]
        strategy = _make_strategy({
            "fields": ["email", "phone"],
            "agent": {"name": "a"},
            "validators": {"email": "mod.email", "phone": "mod.phone"},
        }, ctx)
        state = {"email": "good@test.com", "phone": "123"}
        is_valid, msg = strategy._validate_collected_input(state)
        assert is_valid is False
        # Valid field preserved, invalid field cleared
        assert state["email"] == "good@test.com"
        assert state["phone"] is None
        assert msg == "phone: Phone must be 10 digits"


# ===========================================================================
# Validation errors stored in state
# ===========================================================================

class TestValidationErrorsInState:
    def test_all_fail_stores_errors_with_failed_values(self):
        """When all fields fail, _validation_errors stores each failed value and error."""
        def reject_email(**kw):
            return False, "Invalid email"

        def reject_phone(**kw):
            return False, "Bad phone"

        ctx = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        validators = {"email": reject_email, "phone": reject_phone}
        ctx.function_repository.load.side_effect = lambda path: validators[path.split(".")[-1]]
        strategy = _make_strategy({
            "fields": ["email", "phone"],
            "agent": {"name": "a"},
            "validators": {"email": "mod.email", "phone": "mod.phone"},
        }, ctx)
        state = {"email": "bad@", "phone": "123"}
        strategy._validate_collected_input(state)

        errors = state[WorkflowKeys.VALIDATION_ERRORS]
        assert errors["email"] == {"value": "bad@", "error": "Invalid email"}
        assert errors["phone"] == {"value": "123", "error": "Bad phone"}

    def test_partial_fail_stores_only_failing_fields(self):
        """When one field passes, only the failing field appears in _validation_errors."""
        def accept(**kw):
            return True, None

        def reject(**kw):
            return False, "Bad phone"

        ctx = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        validators = {"email": accept, "phone": reject}
        ctx.function_repository.load.side_effect = lambda path: validators[path.split(".")[-1]]
        strategy = _make_strategy({
            "fields": ["email", "phone"],
            "agent": {"name": "a"},
            "validators": {"email": "mod.email", "phone": "mod.phone"},
        }, ctx)
        state = {"email": "good@test.com", "phone": "12"}
        strategy._validate_collected_input(state)

        errors = state[WorkflowKeys.VALIDATION_ERRORS]
        assert "email" not in errors
        assert errors["phone"] == {"value": "12", "error": "Bad phone"}

    def test_all_pass_clears_validation_errors(self):
        """When all fields pass, _validation_errors is empty."""
        ctx = _make_engine_context(data_fields=[
            {"name": "email", "type": "text"},
            {"name": "phone", "type": "text"},
        ])
        ctx.function_repository.load.return_value = lambda **kw: (True, None)
        strategy = _make_strategy({
            "fields": ["email", "phone"],
            "agent": {"name": "a"},
            "validators": {"email": "mod.v", "phone": "mod.v"},
        }, ctx)
        state = {"email": "ok@test.com", "phone": "1234567890"}
        strategy._validate_collected_input(state)

        assert state[WorkflowKeys.VALIDATION_ERRORS] == {}

    def test_single_field_stores_validation_error_with_value(self):
        """Single-field validation failure stores the failed value in _validation_errors."""
        ctx = _make_engine_context(data_fields=[{"name": "age", "type": "number"}])
        ctx.function_repository.load.return_value = lambda **kw: (False, "Must be positive")
        strategy = _make_strategy({
            "field": "age",
            "agent": {"name": "a"},
            "validator": "mod.v",
        }, ctx)
        state = {"age": -5}
        strategy._validate_collected_input(state)

        errors = state[WorkflowKeys.VALIDATION_ERRORS]
        assert errors["age"] == {"value": -5, "error": "Must be positive"}


# ===========================================================================
# Apply context value
# ===========================================================================

class TestApplyContextValue:
    def test_single_field_context_applied(self):
        ctx = _make_engine_context()
        ctx.get_context_value.side_effect = lambda f: "Alice" if f == "name" else None
        strategy = _make_strategy({"id": "s1", "field": "name", "agent": {"name": "a"}}, ctx)
        state = {}
        span = MagicMock()
        strategy._apply_context_value(state, span)
        assert state["name"] == "Alice"
        span.add_event.assert_called_once()

    def test_multi_field_all_context_applied(self):
        ctx = _make_engine_context()
        ctx.get_context_value.side_effect = lambda f: {"city": "NYC", "zip": "10001"}.get(f)
        strategy = _make_strategy({"id": "s1", "fields": ["city", "zip"], "agent": {"name": "a"}}, ctx)
        state = {}
        span = MagicMock()
        strategy._apply_context_value(state, span)
        assert state["city"] == "NYC"
        assert state["zip"] == "10001"
        assert span.add_event.call_count == 2

    def test_multi_field_partial_context_applied(self):
        ctx = _make_engine_context()
        ctx.get_context_value.side_effect = lambda f: "NYC" if f == "city" else None
        strategy = _make_strategy({"id": "s1", "fields": ["city", "zip"], "agent": {"name": "a"}}, ctx)
        state = {}
        span = MagicMock()
        strategy._apply_context_value(state, span)
        assert state["city"] == "NYC"
        assert "zip" not in state
        span.add_event.assert_called_once()

    def test_multi_field_no_context_available(self):
        ctx = _make_engine_context()
        ctx.get_context_value.return_value = None
        strategy = _make_strategy({"id": "s1", "fields": ["city", "zip"], "agent": {"name": "a"}}, ctx)
        state = {}
        span = MagicMock()
        strategy._apply_context_value(state, span)
        assert "city" not in state
        assert "zip" not in state
        span.add_event.assert_not_called()


# ===========================================================================
# Validation failure handling
# ===========================================================================

class TestHandleValidationFailure:
    @staticmethod
    def _make_ctx_with_template(**overrides):
        ctx = _make_engine_context(**overrides)
        ctx.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment(),
        }.get(key, default)
        ctx._get_humanization_config.return_value = {"enabled": False}
        ctx.update_context = MagicMock()
        return ctx

    def test_multi_field_preserves_valid_fields(self):
        """Validation failure on multi-field only updates context for already-cleared fields."""
        ctx = self._make_ctx_with_template()
        strategy = _make_strategy({"id": "s1", "fields": ["email", "phone"], "agent": {"name": "a"}}, ctx)
        # Simulate: _validate_collected_input already cleared the invalid field
        state = {"email": None, "phone": "123-456-7890"}
        conversation = []
        strategy._handle_validation_failure(state, conversation, message="email: Invalid format")
        # Valid field is preserved
        assert state["phone"] == "123-456-7890"
        assert state["email"] is None
        # Only the invalid field's context is updated
        ctx.update_context.assert_called_once_with({"email": None})

    def test_multi_field_clears_context_for_all_none_fields(self):
        """When all fields are None, all get their context updated."""
        ctx = self._make_ctx_with_template()
        strategy = _make_strategy({"id": "s1", "fields": ["city", "zip"], "agent": {"name": "a"}}, ctx)
        state = {"city": None, "zip": None}
        conversation = []
        strategy._handle_validation_failure(state, conversation, message="Invalid address")
        assert ctx.update_context.call_count == 2

    def test_single_field_clears_field(self):
        """Validation failure on single-field step clears the field and updates context."""
        ctx = self._make_ctx_with_template(data_fields=[{"name": "age", "type": "number"}])
        strategy = _make_strategy({"id": "s1", "field": "age", "agent": {"name": "a"}}, ctx)
        state = {"age": -5}
        conversation = []
        strategy._handle_validation_failure(state, conversation, message="Age must be positive")
        assert state["age"] is None
        ctx.update_context.assert_called_once_with({"age": None})

    def test_validation_failure_appends_message_to_conversation(self):
        ctx = self._make_ctx_with_template()
        strategy = _make_strategy({"id": "s1", "fields": ["x", "y"], "agent": {"name": "a"}}, ctx)
        state = {"x": "bad", "y": "bad"}
        conversation = []
        strategy._handle_validation_failure(state, conversation, message="Try again")
        assert len(conversation) == 1
        assert conversation[0]["content"]== '{"text": "Try again", "options": [], "is_selectable": false}'
        assert conversation[0]["role"] == "assistant"


# ===========================================================================
# Register collector node
# ===========================================================================

class TestRegisterCollectorNode:
    def test_register_single_field(self):
        strategy = _make_strategy({"id": "s1", "field": "name", "agent": {"name": "a"}})
        state = {}
        strategy._register_collector_node(state)
        assert state[WorkflowKeys.NODE_FIELD_MAP]["s1"] == "name"

    def test_register_multi_field(self):
        strategy = _make_strategy({"id": "s2", "fields": ["city", "zip"], "agent": {"name": "a"}})
        state = {}
        strategy._register_collector_node(state)
        assert state[WorkflowKeys.NODE_FIELD_MAP]["s2"] == ["city", "zip"]


# ===========================================================================
# Complete collection message
# ===========================================================================

class TestCompleteCollection:
    def test_complete_single_field_message(self):
        ctx = _make_engine_context()
        ctx.outcome_map = {}
        strategy = _make_strategy({"id": "s1", "field": "name", "agent": {"name": "a"}}, ctx)
        state = {"name": "Alice"}
        result = strategy._complete_collection(state, "next_node", "Alice")
        assert "Name" in result[WorkflowKeys.MESSAGES][0]

    def test_complete_multi_field_message(self):
        ctx = _make_engine_context()
        ctx.outcome_map = {}
        strategy = _make_strategy({"id": "s2", "fields": ["city", "zip"], "agent": {"name": "a"}}, ctx)
        state = {"city": "NYC", "zip": "10001"}
        result = strategy._complete_collection(state, "next_node", {"city": "NYC", "zip": "10001"})
        msg = result[WorkflowKeys.MESSAGES][0]
        assert "Collected" in msg
        assert "NYC" in msg
        assert "10001" in msg


# ===========================================================================
# WorkflowValidator – multi-field validation rules
# ===========================================================================

class TestValidatorMultiField:
    def _base_config(self, steps):
        return {
            "name": "Test",
            "description": "Test",
            "version": "1.0.0",
            "data": [
                {"name": "first_name", "type": "text", "description": "First"},
                {"name": "last_name", "type": "text", "description": "Last"},
                {"name": "email", "type": "text", "description": "Email"},
            ],
            "steps": steps,
            "outcomes": [{"id": "success", "type": "success", "message": "Done"}],
        }

    def _transition(self):
        return [{"pattern": "done", "next": "success"}]

    def test_valid_multi_field_step(self):
        config = self._base_config([{
            "id": "collect_names",
            "action": "collect_input_with_agent",
            "fields": ["first_name", "last_name"],
            "agent": {"name": "a", "instructions": "Collect names"},
            "transitions": self._transition(),
        }])
        result = WorkflowValidator(config).validate()
        field_errors = [e for e in result.errors if "field" in e.lower()]
        assert field_errors == []

    def test_both_field_and_fields_error(self):
        config = self._base_config([{
            "id": "bad_step",
            "action": "collect_input_with_agent",
            "field": "first_name",
            "fields": ["last_name"],
            "agent": {"name": "a", "instructions": "x"},
            "transitions": self._transition(),
        }])
        result = WorkflowValidator(config).validate()
        assert any("both 'field' and 'fields'" in e for e in result.errors)

    def test_neither_field_nor_fields_error(self):
        config = self._base_config([{
            "id": "bad_step",
            "action": "collect_input_with_agent",
            "agent": {"name": "a", "instructions": "x"},
            "transitions": self._transition(),
        }])
        result = WorkflowValidator(config).validate()
        assert any("missing 'field' or 'fields'" in e for e in result.errors)

    def test_unknown_field_in_fields_list(self):
        config = self._base_config([{
            "id": "bad_step",
            "action": "collect_input_with_agent",
            "fields": ["first_name", "nonexistent"],
            "agent": {"name": "a", "instructions": "x"},
            "transitions": self._transition(),
        }])
        result = WorkflowValidator(config).validate()
        assert any("nonexistent" in e for e in result.errors)

    def test_validator_references_unknown_field(self):
        config = self._base_config([{
            "id": "bad_step",
            "action": "collect_input_with_agent",
            "fields": ["first_name", "last_name"],
            "validators": {"email": "mod.validate_email"},
            "agent": {"name": "a", "instructions": "x"},
            "transitions": self._transition(),
        }])
        result = WorkflowValidator(config).validate()
        assert any("validator references unknown field" in e for e in result.errors)

    def test_validator_references_valid_field(self):
        config = self._base_config([{
            "id": "ok_step",
            "action": "collect_input_with_agent",
            "fields": ["first_name", "last_name"],
            "validators": {"first_name": "mod.validate_name"},
            "agent": {"name": "a", "instructions": "x"},
            "transitions": self._transition(),
        }])
        result = WorkflowValidator(config).validate()
        validator_errors = [e for e in result.errors if "validator references" in e]
        assert validator_errors == []


# ===========================================================================
# Engine._get_collect_input_fields
# ===========================================================================

class TestEngineGetCollectInputFields:
    def test_single_and_multi_field_steps(self):
        """Engine should collect fields from both 'field' and 'fields' configs."""
        from soprano_sdk.core.engine import WorkflowEngine
        engine = MagicMock(spec=WorkflowEngine)
        engine.steps = [
            {"action": "collect_input_with_agent", "field": "order_id"},
            {"action": "collect_input_with_agent", "fields": ["city", "zip"]},
            {"action": "call_function", "function": "f"},
        ]
        result = WorkflowEngine._get_collect_input_fields(engine)
        assert result == {"order_id", "city", "zip"}


# ===========================================================================
# Rollback – _clear_future_executions with multi-field
# ===========================================================================

class TestClearFutureExecutionsMultiField:
    def test_clears_multi_field_step(self):
        state = {
            "city": "NYC",
            "zip": "10001",
            WorkflowKeys.CONVERSATIONS: {
                "city_conversation": [{"role": "user", "content": "NYC"}],
                "zip_conversation": [{"role": "user", "content": "10001"}],
            },
        }
        steps = [
            {
                "id": "collect_address",
                "action": "collect_input_with_agent",
                "fields": ["city", "zip"],
            }
        ]
        result = _clear_future_executions(state, "collect_address", steps)
        assert result["city"] is None
        assert result["zip"] is None
        assert "city_conversation" not in result[WorkflowKeys.CONVERSATIONS]
        assert "zip_conversation" not in result[WorkflowKeys.CONVERSATIONS]

    def test_clears_single_field_step(self):
        state = {
            "name": "Alice",
            WorkflowKeys.CONVERSATIONS: {
                "name_conversation": [{"role": "user", "content": "Alice"}],
            },
        }
        steps = [
            {
                "id": "collect_name",
                "action": "collect_input_with_agent",
                "field": "name",
            }
        ]
        result = _clear_future_executions(state, "collect_name", steps)
        assert result["name"] is None
        assert "name_conversation" not in result[WorkflowKeys.CONVERSATIONS]


# ===========================================================================
# DependencyBasedRollback with multi-field
# ===========================================================================

class TestDependencyBasedRollbackMultiField:
    def test_rollback_clears_all_fields_in_multi_field_node(self):
        strategy = DependencyBasedRollback()
        state = {
            "city": "NYC",
            "zip": "10001",
            "order_total": 100,
            WorkflowKeys.CONVERSATIONS: {
                "city_conversation": [{"role": "user", "content": "NYC"}],
                "zip_conversation": [{"role": "user", "content": "10001"}],
            },
        }
        node_field_map = {
            "collect_address": ["city", "zip"],
        }
        workflow_steps = [
            {"id": "collect_address", "action": "collect_input_with_agent", "fields": ["city", "zip"]},
        ]
        result = strategy.rollback_to_node(
            state=state,
            target_node="collect_address",
            node_execution_order=["collect_address"],
            node_field_map=node_field_map,
            workflow_steps=workflow_steps,
        )
        assert result["city"] is None
        assert result["zip"] is None

    def test_rollback_single_field_still_works(self):
        strategy = DependencyBasedRollback()
        state = {
            "name": "Alice",
            WorkflowKeys.CONVERSATIONS: {
                "name_conversation": [{"role": "user", "content": "Alice"}],
            },
        }
        node_field_map = {"collect_name": "name"}
        workflow_steps = [
            {"id": "collect_name", "action": "collect_input_with_agent", "field": "name"},
        ]
        result = strategy.rollback_to_node(
            state=state,
            target_node="collect_name",
            node_execution_order=["collect_name"],
            node_field_map=node_field_map,
            workflow_steps=workflow_steps,
        )
        assert result["name"] is None
