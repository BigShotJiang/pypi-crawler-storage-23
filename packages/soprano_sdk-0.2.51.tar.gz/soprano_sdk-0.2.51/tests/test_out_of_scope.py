"""
Tests for out-of-scope detection functionality.
"""
import json
from unittest.mock import MagicMock, patch
from jinja2 import Environment

from soprano_sdk.core.constants import InterruptType
from soprano_sdk.agents.structured_output import create_structured_output_model
from soprano_sdk.nodes.collect_input import (
    CollectInputStrategy,
    _wrap_instructions_with_out_of_scope_detection,
    OUT_OF_SCOPE_PATTERN
)
from soprano_sdk.tools import WorkflowTool


class TestInterruptTypeOutOfScope:
    """Test InterruptType.OUT_OF_SCOPE constant."""

    def test_out_of_scope_interrupt_type_exists(self):
        """Verify OUT_OF_SCOPE interrupt type is defined."""
        assert hasattr(InterruptType, 'OUT_OF_SCOPE')
        assert InterruptType.OUT_OF_SCOPE == '__OUT_OF_SCOPE_INTERRUPT__'

    def test_all_interrupt_types_are_unique(self):
        """Verify all interrupt types have unique values."""
        types = [
            InterruptType.USER_INPUT,
            InterruptType.ASYNC,
            InterruptType.OUT_OF_SCOPE
        ]
        assert len(types) == len(set(types))


class TestStructuredOutputOutOfScope:
    """Test out-of-scope field in structured output model."""

    def test_out_of_scope_field_not_added_when_disabled(self):
        """Verify out_of_scope field is not added when enable_out_of_scope=False."""
        fields = [
            {"name": "value", "type": "text", "description": "Test value", "required": True}
        ]
        model = create_structured_output_model(
            fields, "TestModel",
            needs_intent_change=False,
            enable_out_of_scope=False
        )

        # Check model fields
        model_fields = model.model_fields
        assert "out_of_scope" not in model_fields
        assert "bot_response" in model_fields
        assert "value" in model_fields

    def test_out_of_scope_field_added_when_enabled(self):
        """Verify out_of_scope field is added when enable_out_of_scope=True."""
        fields = [
            {"name": "value", "type": "text", "description": "Test value", "required": True}
        ]
        model = create_structured_output_model(
            fields, "TestModel",
            needs_intent_change=False,
            enable_out_of_scope=True
        )

        # Check model fields
        model_fields = model.model_fields
        assert "out_of_scope" in model_fields
        assert "bot_response" in model_fields
        assert "value" in model_fields

    def test_out_of_scope_field_is_optional(self):
        """Verify out_of_scope field is optional (can be None)."""
        fields = [
            {"name": "value", "type": "text", "description": "Test value", "required": True}
        ]
        model = create_structured_output_model(
            fields, "TestModel",
            needs_intent_change=False,
            enable_out_of_scope=True
        )

        # Create instance without out_of_scope
        instance = model(value="test")
        assert instance.out_of_scope is None

        # Create instance with out_of_scope
        instance_with_oos = model(value="test", out_of_scope="User asking about weather")
        assert instance_with_oos.out_of_scope == "User asking about weather"

    def test_out_of_scope_and_intent_change_can_coexist(self):
        """Verify both out_of_scope and intent_change fields can be present."""
        fields = [
            {"name": "value", "type": "text", "description": "Test value", "required": True}
        ]
        model = create_structured_output_model(
            fields, "TestModel",
            needs_intent_change=True,
            enable_out_of_scope=True
        )

        model_fields = model.model_fields
        assert "out_of_scope" in model_fields
        assert "intent_change" in model_fields
        assert "bot_response" in model_fields


class TestOutOfScopeInstructions:
    """Test out-of-scope detection instruction wrapping."""

    def test_wrap_instructions_non_structured_output(self):
        """Test instruction wrapping for non-structured output mode."""
        original = "Collect the customer's order ID."
        scope_desc = "collecting order information for returns"

        result = _wrap_instructions_with_out_of_scope_detection(
            original, scope_desc, with_structured_output=False
        )

        assert original in result
        assert "OUT-OF-SCOPE DETECTION" in result
        assert scope_desc in result
        assert "OUT_OF_SCOPE:" in result
        assert "Set out_of_scope" not in result

    def test_wrap_instructions_structured_output(self):
        """Test instruction wrapping for structured output mode."""
        original = "Collect the customer's order ID."
        scope_desc = "collecting order information for returns"

        result = _wrap_instructions_with_out_of_scope_detection(
            original, scope_desc, with_structured_output=True
        )

        assert original in result
        assert "OUT-OF-SCOPE DETECTION" in result
        assert scope_desc in result
        assert "Set out_of_scope" in result
        assert "OUT_OF_SCOPE:" not in result

    def test_wrap_instructions_contains_examples(self):
        """Verify instruction wrapping includes helpful guidance."""
        result = _wrap_instructions_with_out_of_scope_detection(
            "Test instructions", "test scope", with_structured_output=False
        )

        assert "A query is OUT OF SCOPE only if" in result
        assert "completely different products" in result.lower()
        assert "A query is IN SCOPE if it:" in result


class TestCollectInputStrategyOutOfScopeConfig:
    """Test CollectInputStrategy out-of-scope configuration."""

    def _create_strategy(self, agent_config=None, step_config_extras=None):
        """Helper to create a CollectInputStrategy with mocked context."""
        step_config = {
            "id": "test_step",
            "field": "test_field",
            "agent": agent_config or {"name": "test_agent"}
        }
        if step_config_extras:
            step_config.update(step_config_extras)

        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "out_of_scope_description_override": None
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.workflow_description = "Test workflow for processing orders"

        return CollectInputStrategy(step_config, engine_context)

    def test_out_of_scope_disabled_by_default(self):
        """Verify out-of-scope detection is disabled by default."""
        strategy = self._create_strategy()
        assert strategy.enable_out_of_scope is False

    def test_out_of_scope_can_be_enabled(self):
        """Verify out-of-scope detection can be enabled via config."""
        strategy = self._create_strategy(
            agent_config={"name": "test_agent", "detect_out_of_scope": True}
        )
        assert strategy.enable_out_of_scope is True

    def test_scope_description_from_agent_description(self):
        """Verify scope_description combines workflow and agent descriptions."""
        strategy = self._create_strategy(
            agent_config={
                "name": "test_agent",
                "description": "Collect customer order ID for processing returns"
            }
        )
        assert strategy.scope_description == "Test workflow for processing orders. Currently: Collect customer order ID for processing returns"

    def test_scope_description_custom_override(self):
        """Verify scope_description can be customized."""
        strategy = self._create_strategy(
            agent_config={
                "name": "test_agent",
                "description": "Default description",
                "scope_description": "Custom scope for out-of-scope detection"
            }
        )
        assert strategy.scope_description == "Custom scope for out-of-scope detection"

    def test_scope_description_fallback_to_field(self):
        """Verify scope_description falls back to field name when no description, combined with workflow description."""
        strategy = self._create_strategy(
            agent_config={"name": "test_agent"}
        )
        assert strategy.scope_description == "Test workflow for processing orders. Currently: collecting test_field"


class TestCollectInputStrategyHandleOutOfScope:
    """Test _handle_out_of_scope method."""

    def _create_strategy(self):
        """Helper to create a CollectInputStrategy with mocked context."""
        step_config = {
            "id": "collect_order_id",
            "field": "order_id",
            "agent": {"name": "test_agent"}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.workflow_description = "Test workflow for processing orders"
        return CollectInputStrategy(step_config, engine_context)

    @patch('soprano_sdk.nodes.collect_input.interrupt')
    def test_handle_out_of_scope_parses_pattern(self, mock_interrupt):
        """Test that OUT_OF_SCOPE: pattern is parsed correctly."""
        strategy = self._create_strategy()
        state = {}
        user_message = "What is my account balance?"

        strategy._handle_out_of_scope(
            "OUT_OF_SCOPE: User wants to check account balance",
            state,
            user_message
        )

        assert state['_out_of_scope_reason'] == "User wants to check account balance"
        mock_interrupt.assert_called_once()
        call_args = mock_interrupt.call_args[0][0]
        assert call_args['type'] == 'out_of_scope'
        assert call_args['reason'] == "User wants to check account balance"
        assert call_args['user_message'] == user_message

    @patch('soprano_sdk.nodes.collect_input.interrupt')
    def test_handle_out_of_scope_direct_reason(self, mock_interrupt):
        """Test handling when reason is passed directly (structured output)."""
        strategy = self._create_strategy()
        state = {}
        user_message = "How's the weather?"

        strategy._handle_out_of_scope(
            "User asking about weather",
            state,
            user_message
        )

        assert state['_out_of_scope_reason'] == "User asking about weather"
        mock_interrupt.assert_called_once()
        call_args = mock_interrupt.call_args[0][0]
        assert call_args['type'] == 'out_of_scope'
        assert call_args['reason'] == "User asking about weather"

    @patch('soprano_sdk.nodes.collect_input.interrupt')
    def test_handle_out_of_scope_includes_step_id(self, mock_interrupt):
        """Test that step_id is included in interrupt payload."""
        strategy = self._create_strategy()
        state = {}

        strategy._handle_out_of_scope("Test reason", state, "Test message")

        call_args = mock_interrupt.call_args[0][0]
        assert call_args['step_id'] == 'collect_order_id'


class TestCollectInputStrategyGetInstructions:
    """Test that _get_instructions includes out-of-scope detection."""

    def _create_strategy(self, enable_out_of_scope=True):
        """Helper to create a CollectInputStrategy."""
        step_config = {
            "id": "collect_order_id",
            "field": "order_id",
            "agent": {
                "name": "test_agent",
                "instructions": "Collect the order ID from the customer.",
                "description": "Order ID collection",
                "detect_out_of_scope": enable_out_of_scope
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.workflow_description = "Test workflow for processing orders"

        return CollectInputStrategy(step_config, engine_context)

    def test_instructions_include_out_of_scope_when_enabled(self):
        """Verify out-of-scope instructions are added when enabled."""
        strategy = self._create_strategy(enable_out_of_scope=True)
        state = {}
        collector_nodes = {}

        instructions = strategy._get_instructions(state, collector_nodes)

        assert "OUT-OF-SCOPE DETECTION" in instructions
        assert "Order ID collection" in instructions

    def test_instructions_exclude_out_of_scope_when_disabled(self):
        """Verify out-of-scope instructions are not added when disabled."""
        strategy = self._create_strategy(enable_out_of_scope=False)
        state = {}
        collector_nodes = {}

        instructions = strategy._get_instructions(state, collector_nodes)

        assert "OUT-OF-SCOPE DETECTION" not in instructions


class TestOutOfScopePattern:
    """Test OUT_OF_SCOPE_PATTERN constant."""

    def test_pattern_value(self):
        """Verify the pattern constant value."""
        assert OUT_OF_SCOPE_PATTERN == "OUT_OF_SCOPE:"

    def test_pattern_in_response_detection(self):
        """Test pattern detection in agent responses."""
        response = "OUT_OF_SCOPE: User is asking about product returns instead of order lookup"
        assert response.startswith(OUT_OF_SCOPE_PATTERN)

        normal_response = "ORDER_ID_CAPTURED: 12345"
        assert not normal_response.startswith(OUT_OF_SCOPE_PATTERN)


class TestWorkflowToolOutOfScopeInterrupt:
    """Test WorkflowTool handling of out-of-scope interrupts."""

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_execute_returns_out_of_scope_interrupt(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that execute() returns properly formatted out-of-scope interrupt."""

        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state
        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        # Mock result with out-of-scope interrupt
        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "out_of_scope",
            "step_id": "collect_order_id",
            "reason": "User wants to check account balance",
            "user_message": "What is my balance?"
        }
        mock_result = {"__interrupt__": [mock_interrupt]}
        mock_graph.invoke.return_value = mock_result

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute
        result = workflow.execute(thread_id="test-thread", initial_context={})

        # Verify out-of-scope interrupt format
        assert result.startswith("__OUT_OF_SCOPE_INTERRUPT__|test-thread|TestWorkflow|")

        # Parse the JSON payload
        payload_str = result.split("|", 3)[3]
        payload = json.loads(payload_str)
        assert payload["reason"] == "User wants to check account balance"
        assert payload["user_message"] == "What is my balance?"

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_execute_sets_span_attributes_for_out_of_scope(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that span attributes are set correctly for out-of-scope interrupt."""

        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state
        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        # Mock result with out-of-scope interrupt
        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "out_of_scope",
            "step_id": "collect_order_id",
            "reason": "Test reason",
            "user_message": "Test message"
        }
        mock_result = {"__interrupt__": [mock_interrupt]}
        mock_graph.invoke.return_value = mock_result

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute
        workflow.execute(thread_id="test-thread", initial_context={})

        # Verify span attributes were set
        mock_span.set_attribute.assert_any_call("workflow.status", "out_of_scope")
        mock_span.set_attribute.assert_any_call("out_of_scope.step_id", "collect_order_id")

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_resume_returns_out_of_scope_interrupt(
        self, mock_callback_handler, mock_load_workflow
    ):
        """Test that resume() returns properly formatted out-of-scope interrupt."""

        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock result with out-of-scope interrupt
        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "out_of_scope",
            "step_id": "collect_reason",
            "reason": "User asking about shipping status",
            "user_message": "Where is my package?"
        }
        mock_result = {"__interrupt__": [mock_interrupt]}
        mock_graph.invoke.return_value = mock_result

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Resume
        result = workflow.resume(thread_id="test-thread", resume_value="test input")

        # Verify out-of-scope interrupt format
        assert result.startswith("__OUT_OF_SCOPE_INTERRUPT__|test-thread|TestWorkflow|")

        # Parse the JSON payload
        payload_str = result.split("|", 3)[3]
        payload = json.loads(payload_str)
        assert payload["reason"] == "User asking about shipping status"
        assert payload["user_message"] == "Where is my package?"

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_out_of_scope_has_default_reason_if_missing(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that a default reason is used if not provided in interrupt."""

        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state
        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        # Mock result with out-of-scope interrupt (missing reason)
        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "out_of_scope",
            "step_id": "collect_order_id"
            # reason and user_message missing
        }
        mock_result = {"__interrupt__": [mock_interrupt]}
        mock_graph.invoke.return_value = mock_result

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute
        result = workflow.execute(thread_id="test-thread", initial_context={})

        # Parse the JSON payload
        payload_str = result.split("|", 3)[3]
        payload = json.loads(payload_str)
        assert payload["reason"] == "User query is out of scope"
        assert payload["user_message"] == ""
