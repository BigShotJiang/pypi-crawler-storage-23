"""Prospect Intelligence -- tone analysis + pain point extraction.

Analyzes a prospect's profile data (title, company, headline, industry)
combined with ICP campaign data to produce:
1. Tone profile: How the prospect likely communicates
2. Pain points: Prospect-specific pain points inferred from role + ICP
3. Summary: 1-sentence profile summary for prompt injection

Results are cached in contacts.analysis_json for reuse across
invitation, follow-up, and comment generation.

Backend routing: if in backend mode with no local LLM key,
proxies through the backend API (same pattern as voice_analyzer.py).
"""

from __future__ import annotations

import logging
from typing import Any

from .json_repair import parse_json
from .llm import LLMClient
from .persona_cards import find_matching_persona
from .prompt_loader import get_prompt_temperature, has_prompt, render_prompt

logger = logging.getLogger(__name__)

PROSPECT_ANALYSIS_SYSTEM = """You are an expert B2B sales intelligence analyst. You analyze prospect profiles to extract communication preferences and likely pain points, enabling personalized outreach.

You are precise, analytical, and output structured JSON only."""

PROSPECT_ANALYSIS_PROMPT = """Analyze this prospect for outreach preparation.

## PROSPECT
Name: {prospect_name}
Title: {prospect_title}
Company: {prospect_company}
Headline: {prospect_headline}
Location: {prospect_location}
Industry: {prospect_industry}

## CAMPAIGN ICP CONTEXT
Target: {campaign_target}
Campaign pain points: {icp_pain_points}
Campaign fears: {icp_fears}
Campaign barriers: {icp_barriers}
{persona_card_section}
## TASK
Produce a prospect intelligence brief with:

### 1. TONE PROFILE
Infer the prospect's likely communication style from their title, industry, and seniority:
- formality_level: 1-10 (1=very casual startup founder, 10=very formal C-suite at enterprise)
- industry_jargon: Industry-specific terms they likely use (list, max 5)
- emotional_tone: Their likely emotional register (e.g., "analytical", "passionate", "pragmatic")
- recommended_approach: 1-sentence recommendation on how to match their tone in outreach

### 2. PAIN POINTS
Cross-reference the prospect's role/company/industry with the ICP pain points.
Produce 2-4 prospect-SPECIFIC pain points they likely face (not generic business platitudes).

### 3. SUMMARY
One sentence capturing who this person is and what they care about.

## OUTPUT
Return ONLY valid JSON (no markdown, no code fences):
{{
    "tone": {{
        "formality_level": 7,
        "industry_jargon": ["term1", "term2"],
        "emotional_tone": "analytical and data-driven",
        "recommended_approach": "Use concise, metrics-oriented language..."
    }},
    "pain_points": [
        "Specific pain point 1 for this prospect's role",
        "Specific pain point 2"
    ],
    "summary": "One-sentence prospect profile summary"
}}"""


def _fmt_list(items: Any) -> str:
    """Format a list or string for prompt injection."""
    if isinstance(items, list):
        return "; ".join(str(i) for i in items[:5]) if items else "Not specified"
    return str(items) if items else "Not specified"


def _default_analysis(prospect: dict[str, Any]) -> dict[str, Any]:
    """Return neutral defaults when analysis fails."""
    title = prospect.get("title", "Professional")
    company = prospect.get("company", "their company")
    return {
        "tone": {
            "formality_level": 5,
            "industry_jargon": [],
            "emotional_tone": "professional",
            "recommended_approach": "Use a neutral, professional tone",
        },
        "pain_points": [],
        "summary": f"{title} at {company}" if title and company else "Professional",
    }


async def analyze_prospect(
    prospect: dict[str, Any],
    campaign_context: dict[str, Any],
    icp_data: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Analyze a prospect's likely tone and pain points for outreach.

    Args:
        prospect: Prospect profile data (name, title, company, headline, etc.)
        campaign_context: Campaign target description and relevance hook
        icp_data: Parsed ICP JSON with pain_points, fears, barriers

    Returns:
        Dict with "tone" (dict), "pain_points" (list[str]), "summary" (str).
    """
    # Route through backend if in backend mode and no local LLM key
    from ..config import has_local_llm_key, is_backend_mode
    if is_backend_mode() and not has_local_llm_key():
        from ..linkedin import get_linkedin_client
        client = get_linkedin_client()
        try:
            return await client.analyze_prospect(
                prospect=prospect,
                campaign_context=campaign_context,
                icp_data=icp_data,
            )
        finally:
            await client.close()

    icp = icp_data or {}

    # Get prospect's first name for prompt
    prospect_name = prospect.get("name", "").split()[0] if prospect.get("name") else "Unknown"

    # Look up matching persona card from KB
    persona = find_matching_persona(prospect.get("title", ""))
    persona_section = ""
    if persona:
        pains = "\n".join(f"  - {p}" for p in persona["pain_points"][:5])
        kpis = ", ".join(persona["kpis"][:5])
        triggers = ", ".join(persona["triggers"][:4])
        angles = "\n".join(f"  - {a}" for a in persona["messaging_angles"][:4])
        persona_section = (
            f"\n## BUYER PERSONA CARD ({persona['role']})\n"
            f"Known pain points:\n{pains}\n"
            f"KPIs they care about: {kpis}\n"
            f"Buying triggers: {triggers}\n"
            f"Messaging angles:\n{angles}\n"
        )
        logger.info("Matched persona card: %s for title: %s", persona["role"], prospect.get("title", ""))

    # Build template variables
    tpl_vars = {
        "prospect_name": prospect_name,
        "prospect_title": prospect.get("title", ""),
        "prospect_company": prospect.get("company", ""),
        "prospect_headline": prospect.get("headline", ""),
        "prospect_location": prospect.get("location", ""),
        "prospect_industry": prospect.get("industry", ""),
        "campaign_target": campaign_context.get("target_description", ""),
        "icp_pain_points": _fmt_list(icp.get("pain_points", [])),
        "icp_fears": _fmt_list(icp.get("fears", [])),
        "icp_barriers": _fmt_list(icp.get("barriers", [])),
        "persona_card_section": persona_section,
    }

    # v63 path: use JSON prompt template
    if has_prompt("prospect_analysis"):
        logger.debug("Using v63 prospect_analysis prompt")
        prompt = render_prompt("prospect_analysis", tpl_vars)
        temperature = get_prompt_temperature("prospect_analysis")
    else:
        logger.debug("Using legacy prospect_analysis prompt")
        prompt = PROSPECT_ANALYSIS_PROMPT.format(**tpl_vars)
        temperature = 0.5

    llm_client = LLMClient()
    raw = await llm_client.generate(
        prompt, system=PROSPECT_ANALYSIS_SYSTEM, temperature=temperature,
    )

    # Parse JSON with 2-tier repair
    fallback = _default_analysis(prospect)
    result = parse_json(raw, fallback=fallback)

    # Ensure all expected keys are present
    if "tone" not in result:
        result["tone"] = fallback["tone"]
    if "pain_points" not in result:
        result["pain_points"] = fallback["pain_points"]
    if "summary" not in result:
        result["summary"] = fallback["summary"]

    # Enrich with persona card data if LLM output is thin
    if persona:
        result["persona_match"] = persona["role"]
        result["messaging_angles"] = persona["messaging_angles"][:4]
        result["buying_triggers"] = persona["triggers"][:4]
        result["value_drivers"] = persona.get("value_drivers", [])
        # Supplement pain points if LLM returned fewer than 2
        llm_pains = result.get("pain_points", [])
        if len(llm_pains) < 2:
            result["pain_points"] = persona["pain_points"][:4]

    return result
