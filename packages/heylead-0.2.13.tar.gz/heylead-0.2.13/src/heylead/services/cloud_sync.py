"""Cloud sync service — push/pull state between MCP client and backend scheduler.

MCP client pushes campaign/outreach state to the backend for 24/7 scheduling.
Backend executes outreach jobs (invites, follow-ups, engagements, reply checks)
via Cloud Scheduler every 5 minutes, even when the user's laptop is closed.

MCP client pulls back changes (outreach status updates, new messages) periodically.
"""

from __future__ import annotations

import json
import logging
from typing import Any

import httpx

from .. import config
from ..db import queries

logger = logging.getLogger(__name__)

_TIMEOUT = httpx.Timeout(30.0, connect=15.0, read=30.0, write=30.0)


def _headers() -> dict[str, str]:
    """Build auth headers for backend API calls."""
    _, jwt = config.get_backend_config()
    return {
        "Authorization": f"Bearer {jwt}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _base_url() -> str:
    """Get backend base URL."""
    url, _ = config.get_backend_config()
    return url.rstrip("/")


# ── Push: Sync local state to backend ──


async def sync_to_cloud() -> dict[str, Any]:
    """Push all active autopilot campaign state to the backend for cloud scheduling.

    Gathers campaigns, contacts, outreaches, messages, engagements, and settings
    from the local DB and POSTs them to /api/v1/scheduler/sync.

    Returns the backend's response dict.
    """
    if not config.is_backend_mode():
        return {"error": "Backend mode not configured"}

    # ── Gather settings ──
    voice_signature = queries.get_setting("voice_signature", {})
    profile = queries.get_setting("profile", {})
    tier = config.get_tier()
    cfg = config.load_config()
    working_hours = cfg.get("working_hours", {})

    # ── Gather active autopilot campaigns ──
    all_campaigns = queries.list_campaigns("active")
    autopilot_campaigns = [c for c in all_campaigns if c.get("mode") == "autopilot"]

    sync_campaigns = []
    sync_contacts = []
    sync_outreaches = []
    sync_messages = []
    sync_engagements = []

    for camp in autopilot_campaigns:
        camp_id = camp["id"]

        sync_campaigns.append({
            "id": camp_id,
            "name": camp.get("name", ""),
            "mode": camp.get("mode", "autopilot"),
            "status": camp.get("status", "active"),
            "icp_json": camp.get("icp_json", ""),
            "config_json": camp.get("config_json", ""),
            "context_json": camp.get("context_json", ""),
        })

        # Contacts
        contacts = queries.get_contacts_for_campaign(camp_id)
        for contact in contacts:
            sync_contacts.append({
                "id": contact["id"],
                "campaign_id": camp_id,
                "name": contact.get("name", ""),
                "title": contact.get("title", ""),
                "company": contact.get("company", ""),
                "linkedin_id": contact.get("linkedin_id", ""),
                "linkedin_url": contact.get("linkedin_url", ""),
                "profile_json": contact.get("profile_json", ""),
                "analysis_json": contact.get("analysis_json", ""),
                "fit_score": contact.get("fit_score", 0.0),
            })

        # Outreaches
        db = queries.get_db()
        outreach_rows = db.execute(
            "SELECT * FROM outreaches WHERE campaign_id = ?", (camp_id,)
        ).fetchall()
        db.close()
        for o in outreach_rows:
            out = dict(o)
            sync_outreaches.append({
                "id": out["id"],
                "campaign_id": camp_id,
                "contact_id": out["contact_id"],
                "status": out.get("status", "pending"),
                "next_action": out.get("next_action", ""),
                "followup_count": out.get("followup_count", 0),
                "memory_json": out.get("memory_json", ""),
                "outcome_json": out.get("outcome_json", ""),
            })

            # Messages for each outreach
            messages = queries.get_messages_for_outreach(out["id"])
            for msg in messages:
                sync_messages.append({
                    "id": msg["id"],
                    "outreach_id": out["id"],
                    "role": msg.get("role", ""),
                    "text": msg.get("text", ""),
                    "sentiment": msg.get("sentiment", ""),
                    "timestamp": msg.get("timestamp", 0),
                })

        # Engagements
        eng_rows = db if False else None  # Need to query engagements
        db2 = queries.get_db()
        eng_rows = db2.execute(
            "SELECT e.* FROM engagements e "
            "JOIN outreaches o ON e.outreach_id = o.id "
            "WHERE o.campaign_id = ?",
            (camp_id,),
        ).fetchall()
        db2.close()
        for eng in eng_rows:
            e = dict(eng)
            sync_engagements.append({
                "id": e["id"],
                "outreach_id": e["outreach_id"],
                "action_type": e.get("action_type", ""),
                "post_id": e.get("post_id", ""),
                "post_text": e.get("post_text", ""),
                "text": e.get("text", ""),
                "reaction_type": e.get("reaction_type", ""),
                "status": e.get("status", "sent"),
            })

    # ── POST to backend ──
    payload = {
        "settings": {
            "voice_signature": voice_signature,
            "profile": profile,
            "tier": tier,
            "working_hours": working_hours,
        },
        "campaigns": sync_campaigns,
        "contacts": sync_contacts,
        "outreaches": sync_outreaches,
        "messages": sync_messages,
        "engagements": sync_engagements,
    }

    base = _base_url()
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        try:
            resp = await client.post(
                f"{base}/api/v1/scheduler/sync",
                json=payload,
                headers=_headers(),
            )
            resp.raise_for_status()
            result = resp.json()
            logger.info(
                "Cloud sync complete: %d campaigns, %d contacts, %d outreaches",
                result.get("campaigns", 0),
                result.get("contacts", 0),
                result.get("outreaches", 0),
            )
            return result
        except httpx.HTTPStatusError as e:
            logger.error("Cloud sync HTTP error: %s %s", e.response.status_code, e.response.text)
            return {"error": f"Sync failed: HTTP {e.response.status_code}"}
        except httpx.HTTPError as e:
            logger.error("Cloud sync failed: %s", e)
            return {"error": f"Sync failed: {e}"}


# ── Pull: Fetch changes from backend ──


async def pull_changes(since: int) -> dict[str, Any]:
    """Pull state changes made by the backend scheduler since a timestamp.

    Applies outreach status updates and saves new messages to the local DB.
    Returns the changes dict from the backend.
    """
    if not config.is_backend_mode():
        return {"error": "Backend mode not configured"}

    base = _base_url()
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        try:
            resp = await client.get(
                f"{base}/api/v1/scheduler/changes",
                params={"since": since},
                headers=_headers(),
            )
            resp.raise_for_status()
            changes = resp.json()
        except httpx.HTTPStatusError as e:
            logger.error("Pull changes HTTP error: %s", e.response.status_code)
            return {"error": f"Pull failed: HTTP {e.response.status_code}"}
        except httpx.HTTPError as e:
            logger.error("Pull changes failed: %s", e)
            return {"error": f"Pull failed: {e}"}

    # Apply outreach updates to local DB
    outreach_updates = changes.get("outreach_updates", [])
    for update in outreach_updates:
        oid = update.get("id")
        if not oid:
            continue
        local = queries.get_outreach(oid)
        if not local:
            continue
        kwargs: dict[str, Any] = {}
        if "status" in update:
            kwargs["status"] = update["status"]
        if "followup_count" in update:
            kwargs["followup_count"] = update["followup_count"]
        if kwargs:
            queries.update_outreach(oid, **kwargs)
            logger.debug("Applied cloud update to outreach %s: %s", oid, kwargs)

    # Save new messages
    new_messages = changes.get("new_messages", [])
    for msg in new_messages:
        outreach_id = msg.get("outreach_id")
        if not outreach_id:
            continue
        # Check if message already exists locally
        local_msgs = queries.get_messages_for_outreach(outreach_id)
        existing_ids = {m["id"] for m in local_msgs}
        if msg.get("id") in existing_ids:
            continue
        queries.save_message(
            outreach_id=outreach_id,
            role=msg.get("role", "sdr"),
            text=msg.get("text", ""),
            sentiment=msg.get("sentiment", ""),
        )
        logger.debug("Saved cloud message for outreach %s", outreach_id)

    applied = len(outreach_updates) + len(new_messages)
    if applied:
        logger.info(
            "Pulled %d outreach updates + %d new messages from cloud",
            len(outreach_updates),
            len(new_messages),
        )

    return changes


# ── Toggle: Enable/disable cloud scheduler ──


async def toggle_cloud_scheduler(enabled: bool) -> str:
    """Enable or disable the cloud scheduler on the backend.

    If enabling: syncs local state first, then toggles.
    If disabling: just toggles (no sync needed).

    Returns a user-facing status message.
    """
    if not config.is_backend_mode():
        return "Cloud scheduling requires backend mode. Set up your profile first."

    base = _base_url()

    if enabled:
        # Sync first, then enable
        sync_result = await sync_to_cloud()
        if "error" in sync_result:
            return f"Cloud sync failed: {sync_result['error']}\nCannot enable cloud scheduler."

    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        try:
            resp = await client.post(
                f"{base}/api/v1/scheduler/toggle",
                json={"enabled": enabled},
                headers=_headers(),
            )
            resp.raise_for_status()
            result = resp.json()
        except httpx.HTTPStatusError as e:
            detail = ""
            try:
                detail = e.response.json().get("detail", "")
            except Exception:
                detail = e.response.text
            return f"Toggle failed: {detail}"
        except httpx.HTTPError as e:
            return f"Toggle failed: {e}"

    status = result.get("status", "unknown")
    if status == "enabled":
        return (
            "Cloud scheduler **enabled**.\n\n"
            "The backend will now process outreach every 5 minutes, 24/7 "
            "even when your laptop is off:\n"
            "- Send invitations to pending prospects (autopilot campaigns)\n"
            "- Send follow-ups on schedule (day 1, 7, 14, 21, 28)\n"
            "- Check for replies and classify sentiment\n"
            "- Engage with prospect posts (comments & reactions)\n\n"
            "All actions respect rate limits, working hours, and daily caps.\n"
            "Use `scheduler_status()` to monitor cloud activity."
        )
    else:
        return (
            "Cloud scheduler **disabled**.\n\n"
            "The backend will stop processing new outreach.\n"
            "Already-running jobs will complete.\n\n"
            "Use `toggle_scheduler(enabled=True, cloud=True)` to re-enable."
        )


# ── Status: Get cloud scheduler status ──


async def get_cloud_scheduler_status() -> dict[str, Any]:
    """Fetch scheduler status from the backend.

    Returns dict with enabled, pending_jobs, recent_activity, campaigns, etc.
    """
    if not config.is_backend_mode():
        return {"error": "Backend mode not configured"}

    base = _base_url()
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        try:
            resp = await client.get(
                f"{base}/api/v1/scheduler/status",
                headers=_headers(),
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as e:
            return {"error": f"Status check failed: HTTP {e.response.status_code}"}
        except httpx.HTTPError as e:
            return {"error": f"Status check failed: {e}"}
