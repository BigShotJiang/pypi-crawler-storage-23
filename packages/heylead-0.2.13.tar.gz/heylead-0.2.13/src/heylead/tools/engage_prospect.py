"""Tool: engage_prospect — Comment on or react to a prospect's LinkedIn post.

Core engagement loop:
1. Find next outreach candidate for engagement
2. Fetch prospect's recent LinkedIn posts via get_user_posts()
3. Pick the best post (most recent with substantial text)
4. Generate voice-matched comment or react with LIKE
5. In Copilot mode: show post + proposed comment for review
6. In Autopilot: send immediately
7. Log engagement to DB
"""

from __future__ import annotations

import json
import logging
from typing import Any

from ..ai.comment_generator import generate_comment, COMMENT_MAX_CHARS
from ..ai.message_fixer import fix_message
from ..ai.message_improver import improve_message
from ..ai.message_validator import validate_comment
from ..ai.prospect_analyzer import analyze_prospect
from ..config import get_tier
from ..constants import (
    COMMENT_MAX_CHARS as COMMENT_LIMIT,
    DAILY_ENGAGEMENT_LIMIT,
    FREE_MAX_ENGAGEMENTS,
    TIER_PRO,
)
from ..db.queries import (
    find_active_campaign,
    get_campaign,
    get_contact_analysis,
    get_daily_engagement_count,
    get_engaged_post_ids,
    get_engagement_candidates,
    get_monthly_usage,
    get_outreach,
    get_outreach_with_contact,
    get_setting,
    increment_usage,
    log_action,
    save_contact_analysis,
    save_engagement,
    update_outreach,
)
from ..formatter import stars
from ..linkedin import (
    UnipileAuthError,
    UnipileError,
    get_account_id,
    get_linkedin_client,
)

logger = logging.getLogger(__name__)

MAX_ENGAGEMENTS_PER_OUTREACH = 3  # Don't over-engage with a single prospect


async def run_engage_prospect(
    campaign_id: str = "",
    outreach_id: str = "",
    action: str = "auto",
    mode: str = "copilot",
) -> str:
    """Engage with a prospect's LinkedIn post (comment or react).

    Flow:
    1. Pre-checks: setup_complete, account_id, client
    2. Normalize action, find campaign + candidate
    3. Fetch prospect's recent posts
    4. Pick best post, generate comment or react
    5. Copilot: show for review. Autopilot: send immediately.
    6. Log engagement to DB
    """

    # ── Step 0: Pre-checks ──
    setup_done = get_setting("setup_complete", False)
    if not setup_done:
        return (
            "Setup required before engaging.\n\n"
            "Please run setup_profile first."
        )

    account_id = get_account_id()
    if not account_id:
        return "No LinkedIn account connected. Run setup_profile first."

    try:
        client = get_linkedin_client()
    except UnipileError as e:
        return f"{e}"

    # Normalize action
    action = action.lower().strip()
    if action == "like":
        action = "react"
    if action not in ("auto", "comment", "react"):
        await client.close()
        return f"Invalid action: '{action}'. Use 'auto', 'comment', 'react', or 'like'."

    # ── Step 1: Find campaign + engagement candidate ──
    if outreach_id:
        outreach = get_outreach(outreach_id)
        if not outreach:
            await client.close()
            return f"Outreach not found: {outreach_id}"
        campaign = get_campaign(outreach["campaign_id"])
        if not campaign:
            await client.close()
            return "Campaign not found for this outreach."
        campaign_id = campaign["id"]
        candidate = get_outreach_with_contact(outreach_id)
        if not candidate:
            await client.close()
            return "Could not load contact data for this outreach."
    else:
        campaign, err = find_active_campaign(campaign_id)
        if not campaign:
            await client.close()
            return err
        campaign_id = campaign["id"]

        # Block engagement when campaign is paused
        if campaign.get("status") == "paused":
            await client.close()
            return (
                f"Campaign '{campaign['name']}' is paused.\n\n"
                "No engagement will be sent while the campaign is paused.\n"
                "Use resume_campaign() to resume."
            )

        candidates = get_engagement_candidates(campaign_id, MAX_ENGAGEMENTS_PER_OUTREACH)
        if not candidates:
            await client.close()
            return (
                f"No prospects available for engagement in '{campaign['name']}'.\n\n"
                "Prospects need to be in the campaign first.\n"
                "Use generate_and_send() to reach new prospects."
            )
        # Will iterate through candidates below to find one with posts
        candidate = None
        outreach_id = ""

    # ── Step 2: Check daily + monthly limits ──
    daily_count = get_daily_engagement_count()
    if daily_count >= DAILY_ENGAGEMENT_LIMIT:
        await client.close()
        return (
            f"Daily engagement limit reached ({DAILY_ENGAGEMENT_LIMIT}/day).\n\n"
            "LinkedIn safety: too many engagements in a day can flag your account.\n"
            "Try again tomorrow."
        )

    tier = get_tier()
    if tier != TIER_PRO:
        usage = get_monthly_usage()
        monthly_engagements = usage.get("engagements_sent", 0)
        if monthly_engagements >= FREE_MAX_ENGAGEMENTS:
            await client.close()
            return (
                f"Free tier limit reached: {FREE_MAX_ENGAGEMENTS} engagements/month.\n\n"
                "Upgrade to Pro ($29/mo) for more engagements."
            )

    # ── Step 3: Fetch prospect's recent posts ──
    # If candidate was set by outreach_id, use single-candidate list
    if candidate is not None:
        candidates_to_try = [candidate]
    # else candidates list was populated above

    skipped_names: list[str] = []
    posts: list[dict[str, Any]] = []

    for cand in (candidates_to_try if candidate is not None else candidates):
        # Use provider_id from profile_json — Unipile requires the internal
        # provider ID (starts with ACo...), NOT the public LinkedIn slug.
        profile_data = {}
        if cand.get("profile_json"):
            try:
                profile_data = json.loads(cand["profile_json"])
            except (json.JSONDecodeError, TypeError):
                pass

        prospect_identifier = profile_data.get("provider_id", "")
        if not prospect_identifier:
            # Fallback: try linkedin_id or extract from URL
            prospect_identifier = cand.get("linkedin_id", "")
        if not prospect_identifier:
            url = cand.get("linkedin_url", "")
            if "/in/" in url:
                prospect_identifier = url.split("/in/")[-1].strip("/")

        if not prospect_identifier:
            skipped_names.append(cand.get("name", "Unknown"))
            continue

        try:
            posts = await client.get_user_posts(account_id, prospect_identifier, limit=5)
        except Exception as e:
            logger.error(f"Failed to fetch posts for {cand.get('name')}: {e}")
            posts = []

        if posts:
            candidate = cand
            outreach_id = cand.get("outreach_id", outreach_id)
            break
        else:
            skipped_names.append(cand.get("name", "Unknown"))

    prospect_name = candidate.get("name", "Unknown") if candidate else "Unknown"
    prospect_title = candidate.get("title", "") if candidate else ""
    prospect_company = candidate.get("company", "") if candidate else ""
    role_str = prospect_title
    if prospect_company:
        role_str += f" at {prospect_company}" if role_str else prospect_company

    # ── Step 4: Handle no posts ──
    if not posts or candidate is None:
        await client.close()
        if skipped_names:
            names_str = ", ".join(skipped_names)
            return (
                f"No recent posts found for any candidate ({names_str}).\n\n"
                "None of the available prospects have posted recently.\n"
                "Try send_followup() for a DM instead, or wait for new content."
            )
        return (
            f"No recent posts found for {prospect_name} ({role_str}).\n\n"
            "This prospect hasn't posted recently, so engagement isn't possible right now.\n"
            "Try send_followup() for a DM instead, or engage_prospect() with a different prospect."
        )

    # ── Step 4b: Filter already-engaged posts ──
    engaged_ids = get_engaged_post_ids(outreach_id)
    if engaged_ids:
        posts = [p for p in posts if p.get("id", "") not in engaged_ids]
        if not posts:
            await client.close()
            return (
                f"All recent posts by {prospect_name} have already been engaged.\n\n"
                "Wait for new content, or try a different prospect.\n"
                "Use engage_prospect() again to auto-pick the next candidate."
            )

    # ── Step 5: Pick best post + decide action ──
    # Simple heuristic: pick most recent post with substantial text (>50 chars)
    target_post = posts[0]  # Default to most recent
    for post in posts:
        text = post.get("text", "")
        if len(text) > 50:
            target_post = post
            break

    if action == "react":
        return await _handle_reaction(
            client, account_id, outreach_id, candidate, target_post, mode
        )

    # For "auto" or "comment": check if post has enough content for a comment
    post_text = target_post.get("text", "")
    if action == "auto" and len(post_text) < 50:
        # Very short post — just react
        return await _handle_reaction(
            client, account_id, outreach_id, candidate, target_post, mode
        )

    # ── Step 6: Generate comment ──
    sender_profile = get_setting("profile", {})
    voice_signature = get_setting("voice_signature", {})

    prospect_data = json.loads(candidate.get("profile_json", "{}")) if candidate.get("profile_json") else {
        "name": prospect_name,
        "title": prospect_title,
        "company": prospect_company,
        "headline": f"{prospect_title} at {prospect_company}" if prospect_company else prospect_title,
    }

    # ── Prospect Intelligence: load cached or generate ──
    prospect_analysis = None
    contact_db_id = candidate.get("contact_id") or candidate.get("contact_db_id", "")
    if contact_db_id:
        prospect_analysis = get_contact_analysis(contact_db_id)
    if not prospect_analysis:
        campaign_config = json.loads(campaign.get("config_json", "{}"))
        icp_data = json.loads(campaign.get("icp_json", "{}"))
        campaign_context = {
            "target_description": campaign_config.get("target_description", ""),
            "relevance_hook": icp_data.get("relevance_hook", ""),
        }
        try:
            prospect_analysis = await analyze_prospect(
                prospect=prospect_data,
                campaign_context=campaign_context,
                icp_data=icp_data,
            )
            if contact_db_id:
                save_contact_analysis(contact_db_id, prospect_analysis)
        except Exception as e:
            logger.warning(f"Prospect analysis failed, proceeding without: {e}")

    # ── Generate → Improve → Validate → Fix pipeline ──
    comment_text = ""
    style = ""
    reasoning = {}
    validation = None

    # Attempt 1: Generate + Improve + Validate (+ Fix if needed)
    try:
        result = await generate_comment(
            prospect=prospect_data,
            sender_profile=sender_profile,
            voice_signature=voice_signature,
            post_data=target_post,
            max_chars=COMMENT_MAX_CHARS,
            prospect_analysis=prospect_analysis,
        )
        comment_text = result.get("comment", "")
        style = result.get("style", "")
        reasoning = result.get("reasoning", {})
    except Exception as e:
        logger.error(f"Comment generation failed: {e}")
        await client.close()
        return f"Failed to generate comment: {e}"

    # Improve stage — polish for naturalness
    try:
        comment_text = await improve_message(
            draft=comment_text,
            voice_signature=voice_signature,
            message_type="comment",
            max_chars=COMMENT_MAX_CHARS,
        )
    except Exception as e:
        logger.warning(f"Improve stage failed, using raw comment: {e}")

    # Validate
    validation = validate_comment(comment_text, voice_signature, max_chars=COMMENT_MAX_CHARS)

    # Fix stage — if validation failed, surgically fix issues
    if not validation.is_valid:
        logger.info(f"Comment validation failed, attempting fix: {validation.issues}")
        try:
            comment_text = await fix_message(
                message=comment_text,
                issues=validation.issues,
                voice_signature=voice_signature,
                message_type="comment",
                max_chars=COMMENT_MAX_CHARS,
            )
            validation = validate_comment(comment_text, voice_signature, max_chars=COMMENT_MAX_CHARS)
        except Exception as e:
            logger.warning(f"Fix stage failed: {e}")

    # Last resort: regenerate from scratch if still invalid
    if not validation.is_valid:
        logger.info(f"Fix failed, regenerating comment from scratch: {validation.issues}")
        try:
            result = await generate_comment(
                prospect=prospect_data,
                sender_profile=sender_profile,
                voice_signature=voice_signature,
                post_data=target_post,
                max_chars=COMMENT_MAX_CHARS,
                prospect_analysis=prospect_analysis,
            )
            comment_text = result.get("comment", "")
            style = result.get("style", "")
            reasoning = result.get("reasoning", {})
            comment_text = await improve_message(
                draft=comment_text,
                voice_signature=voice_signature,
                message_type="comment",
                max_chars=COMMENT_MAX_CHARS,
            )
            validation = validate_comment(comment_text, voice_signature, max_chars=COMMENT_MAX_CHARS)
        except Exception as e:
            logger.error(f"Regeneration failed: {e}")

    if not validation or not validation.is_valid:
        issues_text = "\n".join(f"  ⚠️ {issue}" for issue in (validation.issues if validation else []))
        if mode == "autopilot":
            logger.warning(f"Autopilot blocked invalid comment: {issues_text}")
            log_action("validation_blocked", outreach_id=outreach_id, result="blocked",
                       details={"issues": validation.issues if validation else [], "type": "comment"})
            await client.close()
            return (
                f"⚠️ Comment for {prospect_name} failed validation "
                f"after Generate → Improve → Fix pipeline.\n\n"
                f"Issues:\n{issues_text}\n\n"
                "The comment was NOT posted to protect your account.\n"
                "Try: engage_prospect(mode='copilot') to review and edit manually."
            )
        else:
            logger.warning(f"Copilot comment has validation warnings: {issues_text}")

    # ── Step 7: Copilot vs Autopilot ──
    post_preview = post_text[:150]
    if len(post_text) > 150:
        post_preview += "..."

    fit_score = candidate.get("fit_score", 0)

    if mode == "copilot":
        # Store proposed action for later approval
        update_outreach(outreach_id, next_action=json.dumps({
            "type": "comment",
            "post_id": target_post.get("id", ""),
            "comment": comment_text,
        }))

        output = [
            f"Comment for **{prospect_name}** ({role_str}):",
            f"   Fit: {stars(fit_score)}",
            "",
            f"   Post: \"{post_preview}\"",
            "",
            f'   Comment: "{comment_text}"',
            f"   ({len(comment_text)}/{COMMENT_MAX_CHARS} chars)",
            "",
        ]

        if style:
            output.append(f"   Style: {style}")
        if reasoning:
            hook = reasoning.get("post_hook", "")
            angle = reasoning.get("angle", "")
            if hook:
                output.append(f"   Hook: {hook}")
            if angle:
                output.append(f"   Angle: {angle}")
            output.append("")

        if validation and validation.warnings:
            for w in validation.warnings:
                output.append(f"   {w}")
            output.append("")

        output.extend([
            "Post this? Reply with:",
            "  'yes' / 'send' to post this comment",
            "  'react' to just like the post instead",
            "  'skip' to skip this prospect",
            "  'edit: [your text]' to post a custom comment instead",
            "  'stop' to pause the campaign",
        ])

        await client.close()
        return "\n".join(line for line in output if line is not None)

    else:
        # Autopilot — send immediately
        return await _send_comment(
            client, account_id, outreach_id, candidate, target_post,
            comment_text, style, reasoning,
        )


async def _handle_reaction(
    client: Any,
    account_id: str,
    outreach_id: str,
    candidate: dict,
    target_post: dict,
    mode: str,
) -> str:
    """Handle a reaction (LIKE) on a post."""
    prospect_name = candidate.get("name", "Unknown")
    post_preview = target_post.get("text", "")[:100]
    if len(target_post.get("text", "")) > 100:
        post_preview += "..."
    post_id = target_post.get("id", "")

    if mode == "copilot":
        update_outreach(outreach_id, next_action=json.dumps({
            "type": "react",
            "post_id": post_id,
        }))

        output = [
            f"React to **{prospect_name}**'s post:",
            f"   Post: \"{post_preview}\"",
            "",
            "   Action: Like this post",
            "",
            "Send this? Reply with:",
            "  'yes' / 'send' to like the post",
            "  'comment' to write a comment instead",
            "  'skip' to skip this prospect",
        ]
        await client.close()
        return "\n".join(output)

    # Autopilot — react immediately
    try:
        result = await client.send_post_reaction(account_id, post_id, "LIKE")
    except UnipileAuthError:
        await client.close()
        return "LinkedIn account disconnected. Run setup_profile() again."
    except Exception as e:
        await client.close()
        return f"Failed to react: {e}"
    finally:
        await client.close()

    if result.get("success"):
        save_engagement(
            outreach_id=outreach_id,
            action_type="react",
            post_id=post_id,
            post_text=target_post.get("text", "")[:500],
            reaction_type="LIKE",
            status="sent",
        )
        increment_usage("engagements_sent")
        log_action(
            "engagement_react",
            outreach_id=outreach_id,
            result="success",
            details={"prospect": prospect_name, "post_id": post_id},
        )
        return f"Liked {prospect_name}'s post: \"{post_preview}\""
    else:
        error = result.get("error", "Unknown error")
        log_action(
            "engagement_react_failed",
            outreach_id=outreach_id,
            result="error",
            details={"error": error},
        )
        return f"Reaction failed for {prospect_name}: {error}"


async def _send_comment(
    client: Any,
    account_id: str,
    outreach_id: str,
    candidate: dict,
    target_post: dict,
    comment_text: str,
    style: str,
    reasoning: dict,
) -> str:
    """Send a comment on a post and record it."""
    prospect_name = candidate.get("name", "Unknown")
    post_id = target_post.get("id", "")

    try:
        result = await client.send_post_comment(account_id, post_id, comment_text)
    except UnipileAuthError:
        await client.close()
        return "LinkedIn account disconnected. Run setup_profile() again."
    except Exception as e:
        await client.close()
        return f"Failed to send comment: {e}"
    finally:
        await client.close()

    if result.get("success"):
        save_engagement(
            outreach_id=outreach_id,
            action_type="comment",
            post_id=post_id,
            post_text=target_post.get("text", "")[:500],
            text=comment_text,
            status="sent",
            reasoning=json.dumps({"style": style, **reasoning}),
        )
        increment_usage("engagements_sent")
        log_action(
            "engagement_comment",
            outreach_id=outreach_id,
            result="success",
            details={
                "prospect": prospect_name,
                "post_id": post_id,
                "comment_length": len(comment_text),
                "style": style,
                "reasoning": reasoning,
            },
        )

        output = f"Commented on {prospect_name}'s post:\n"
        output += f'   "{comment_text}"'
        if style:
            output += f"\n\n   Style: {style}"
        return output
    else:
        error = result.get("error", "Unknown error")
        log_action(
            "engagement_comment_failed",
            outreach_id=outreach_id,
            result="error",
            details={"error": error},
        )
        return f"Comment failed for {prospect_name}: {error}"


