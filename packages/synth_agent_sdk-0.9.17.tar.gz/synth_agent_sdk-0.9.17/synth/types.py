"""Core data models for the Synth SDK.

Defines RunResult, stream event types, guard types, orchestration types,
and all supporting dataclasses used across the SDK.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, TypedDict, Union


# ---------------------------------------------------------------------------
# Message type (lightweight representation used in traces and team results)
# ---------------------------------------------------------------------------


class _MessageRequired(TypedDict):
    """Required fields for a conversation message."""

    role: str
    content: str


class Message(_MessageRequired, total=False):
    """A single conversation message with role and content.

    The ``tool_name`` field is only present on ``role: "tool"``
    messages and carries the name of the tool that produced the
    result.  Providers use it to build correctly attributed tool
    result blocks (e.g. Bedrock ``toolUse`` / ``toolResult`` pairs).
    """

    tool_name: str


# ---------------------------------------------------------------------------
# Token / tool usage
# ---------------------------------------------------------------------------


@dataclass
class TokenUsage:
    """Input/output/total token counts for a single run."""

    input_tokens: int
    output_tokens: int
    total_tokens: int


@dataclass
class ToolCallRecord:
    """Record of a single tool invocation during a run."""

    name: str
    args: dict[str, Any]
    result: Any
    latency_ms: float


# ---------------------------------------------------------------------------
# RunResult
# ---------------------------------------------------------------------------


@dataclass
class RunResult:
    """Response object returned by ``agent.run()``.

    Contains the model's reply, token usage, latency, cost, and trace.
    """

    text: str
    output: Any | None  # Parsed structured output (BaseModel) if schema set
    tokens: TokenUsage
    cost: float
    latency_ms: float
    trace: Any  # Trace object from synth.tracing (Trace | None)
    tool_calls: list[ToolCallRecord] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Stream event types
# ---------------------------------------------------------------------------


@dataclass
class TokenEvent:
    """Emitted when the model produces a text token."""

    text: str


@dataclass
class ToolCallEvent:
    """Emitted when the agent decides to invoke a tool."""

    name: str
    args: dict[str, Any]


@dataclass
class ToolResultEvent:
    """Emitted after a tool invocation completes."""

    name: str
    result: Any


@dataclass
class ThinkingEvent:
    """Emitted when the model produces a reasoning/thinking token."""

    text: str


@dataclass
class DoneEvent:
    """Emitted as the final event of a successful streaming run."""

    result: RunResult


@dataclass
class ErrorEvent:
    """Emitted when a streaming run is interrupted by an exception."""

    error: Exception


StreamEvent = Union[
    TokenEvent,
    ToolCallEvent,
    ToolResultEvent,
    ThinkingEvent,
    DoneEvent,
    ErrorEvent,
]


@dataclass
class StageEvent:
    """Wraps a StreamEvent with the pipeline stage name that produced it."""

    stage_name: str
    event: StreamEvent


# ---------------------------------------------------------------------------
# Guard types
# ---------------------------------------------------------------------------


@dataclass
class GuardContext:
    """Context passed to guards during evaluation."""

    cumulative_cost: float
    tool_calls: list[str]
    run_id: str | None


@dataclass
class GuardResult:
    """Result of a guard check."""

    passed: bool
    violation_message: str | None = None


# ---------------------------------------------------------------------------
# Checkpointing types
# ---------------------------------------------------------------------------


@dataclass
class Checkpoint:
    """Persisted snapshot of execution state after a node/step completes."""

    run_id: str
    state: Any
    step: int
    node_name: str
    timestamp: datetime


@dataclass
class PausedRun:
    """Returned when graph execution is paused for human-in-the-loop approval."""

    run_id: str
    paused_at_node: str
    state: Any
    checkpoint: Checkpoint


# ---------------------------------------------------------------------------
# Multi-agent team types
# ---------------------------------------------------------------------------


@dataclass
class AgentContribution:
    """A single agent's contribution within a team run."""

    agent_name: str
    result: RunResult


@dataclass
class TeamResult:
    """Result of an ``AgentTeam.run()`` call."""

    answer: str
    contributions: list[AgentContribution]
    message_trace: list[Message]
    total_cost: float
    total_latency_ms: float
