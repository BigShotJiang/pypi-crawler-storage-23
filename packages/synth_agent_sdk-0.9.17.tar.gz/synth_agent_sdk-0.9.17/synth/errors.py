"""Error hierarchy for the Synth SDK.

All SDK errors inherit from ``SynthError``, which enforces a consistent
structure: *what* went wrong (message), *which component* raised it
(``component``), and *how to fix it* (``suggestion``).
"""

from __future__ import annotations

from typing import Any


class SynthError(Exception):
    """Base error for all Synth SDK errors.

    Parameters
    ----------
    message:
        Human-readable description of what went wrong.
    component:
        The SDK component that raised the error (e.g. "ProviderRouter").
    suggestion:
        Actionable fix instruction for the developer.
    """

    def __init__(self, message: str, *, component: str, suggestion: str) -> None:
        self.component = component
        self.suggestion = suggestion
        super().__init__(message)


class SynthConfigError(SynthError):
    """Invalid configuration, missing API keys, or missing provider packages."""


class ToolDefinitionError(SynthError):
    """Raised at decoration time when a ``@tool`` function is invalid."""


class ToolExecutionError(SynthError):
    """Raised when a tool function throws during execution."""

    def __init__(
        self,
        message: str,
        *,
        component: str,
        suggestion: str,
        tool_name: str,
        tool_args: dict[str, Any],
        original_error: Exception,
    ) -> None:
        self.tool_name = tool_name
        self.tool_args = tool_args
        self.original_error = original_error
        super().__init__(message, component=component, suggestion=suggestion)


class GuardViolationError(SynthError):
    """Raised when a guard constraint is violated."""

    def __init__(
        self,
        message: str,
        *,
        component: str,
        suggestion: str,
        guard_name: str,
        violating_content: str,
        remediation: str,
    ) -> None:
        self.guard_name = guard_name
        self.violating_content = violating_content
        self.remediation = remediation
        super().__init__(message, component=component, suggestion=suggestion)


class CostLimitError(GuardViolationError):
    """Raised when a cost guard limit is exceeded."""


class SynthParseError(SynthError):
    """Raised when structured output cannot be parsed after retries."""


class GraphRoutingError(SynthError):
    """Raised when no outbound edge condition matches at a node."""

    def __init__(
        self,
        message: str,
        *,
        component: str,
        suggestion: str,
        node_name: str,
        current_state: Any,
    ) -> None:
        self.node_name = node_name
        self.current_state = current_state
        super().__init__(message, component=component, suggestion=suggestion)


class GraphLoopError(SynthError):
    """Raised when a graph exceeds its maximum iteration count."""

    def __init__(
        self,
        message: str,
        *,
        component: str,
        suggestion: str,
        node_history: list[str],
        max_iterations: int,
    ) -> None:
        self.node_history = node_history
        self.max_iterations = max_iterations
        super().__init__(message, component=component, suggestion=suggestion)


class RunNotFoundError(SynthError):
    """Raised when no checkpoint exists for a given ``run_id``."""

    def __init__(
        self,
        message: str,
        *,
        component: str,
        suggestion: str,
        run_id: str,
    ) -> None:
        self.run_id = run_id
        super().__init__(message, component=component, suggestion=suggestion)


class PipelineError(SynthError):
    """Raised when a pipeline step fails, carrying partial results."""

    def __init__(
        self,
        message: str,
        *,
        component: str,
        suggestion: str,
        failed_step: int,
        agent_name: str,
        partial_results: list[Any],
    ) -> None:
        self.failed_step = failed_step
        self.agent_name = agent_name
        self.partial_results = partial_results
        super().__init__(message, component=component, suggestion=suggestion)
