"""Extended tests for BedrockProvider — coverage for _strip_tool_blocks,
_build_messages edge cases, _build_tool_config, _merge_consecutive_roles,
and complete()/stream() fallback paths.

Supplements test_bedrock_provider.py with tests for branches and helpers
introduced in the full provider rewrite.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from synth.providers.base import (
    ProviderDoneEvent,
    TextChunkEvent,
    ToolCallChunkEvent,
)
from synth.types import Message


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USER_MSG: list[Message] = [{"role": "user", "content": "hello"}]


def _make_provider(**kwargs: Any):
    """Create a BedrockProvider with a mocked boto3 client."""
    with patch("synth.providers.bedrock.boto3") as mock_boto3:
        mock_client = MagicMock()
        mock_boto3.client.return_value = mock_client
        from synth.providers.bedrock import BedrockProvider

        provider = BedrockProvider(model="bedrock/test-model", **kwargs)
    return provider, mock_client


async def _collect_stream(provider, messages=None, **kwargs):
    """Collect all events from a stream() call into a list."""
    events = []
    async for event in provider.stream(messages or _USER_MSG, **kwargs):
        events.append(event)
    return events


# ---------------------------------------------------------------------------
# _strip_tool_blocks
# ---------------------------------------------------------------------------


class TestStripToolBlocks:
    """BedrockProvider._strip_tool_blocks removes toolUse/toolResult blocks."""

    def _strip(self, api_messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        provider, _ = _make_provider()
        return provider._strip_tool_blocks(api_messages)

    def test_removes_tool_use_blocks(self) -> None:
        msgs = [
            {
                "role": "assistant",
                "content": [
                    {"text": "Let me check."},
                    {"toolUse": {"toolUseId": "tc_1", "name": "search", "input": {}}},
                ],
            },
        ]
        result = self._strip(msgs)
        assert len(result) == 1
        assert result[0]["content"] == [{"text": "Let me check."}]

    def test_removes_tool_result_blocks(self) -> None:
        msgs = [
            {
                "role": "user",
                "content": [
                    {"toolResult": {"toolUseId": "tc_1", "content": [{"text": "ok"}]}},
                ],
            },
        ]
        result = self._strip(msgs)
        # Message becomes empty after stripping → dropped entirely
        assert len(result) == 0

    def test_drops_empty_messages_after_stripping(self) -> None:
        msgs = [
            {"role": "user", "content": [{"text": "hi"}]},
            {
                "role": "assistant",
                "content": [
                    {"toolUse": {"toolUseId": "tc_1", "name": "fn", "input": {}}},
                ],
            },
            {
                "role": "user",
                "content": [
                    {"toolResult": {"toolUseId": "tc_1", "content": [{"text": "r"}]}},
                ],
            },
        ]
        result = self._strip(msgs)
        # Only the first user message survives
        assert len(result) == 1
        assert result[0]["content"] == [{"text": "hi"}]

    def test_preserves_text_only_messages(self) -> None:
        msgs = [
            {"role": "user", "content": [{"text": "hello"}]},
            {"role": "assistant", "content": [{"text": "hi there"}]},
        ]
        result = self._strip(msgs)
        assert len(result) == 2
        assert result[0]["content"] == [{"text": "hello"}]
        assert result[1]["content"] == [{"text": "hi there"}]

    def test_non_list_content_preserved(self) -> None:
        """Messages with non-list content are passed through unchanged."""
        msgs = [{"role": "user", "content": "plain string"}]
        result = self._strip(msgs)
        assert len(result) == 1
        assert result[0]["content"] == "plain string"

    def test_non_dict_content_items_preserved(self) -> None:
        """Non-dict items in content lists are kept (not toolUse/toolResult)."""
        msgs = [{"role": "user", "content": ["plain", 42, {"text": "ok"}]}]
        result = self._strip(msgs)
        assert len(result) == 1
        assert result[0]["content"] == ["plain", 42, {"text": "ok"}]

    def test_empty_messages_list(self) -> None:
        assert self._strip([]) == []

    def test_mixed_tool_and_text_in_same_message(self) -> None:
        """Only tool blocks are removed; text blocks in the same message survive."""
        msgs = [
            {
                "role": "assistant",
                "content": [
                    {"text": "Here are results."},
                    {"toolUse": {"toolUseId": "tc_1", "name": "s", "input": {}}},
                    {"text": "More text."},
                ],
            },
        ]
        result = self._strip(msgs)
        assert len(result) == 1
        assert result[0]["content"] == [
            {"text": "Here are results."},
            {"text": "More text."},
        ]


# ---------------------------------------------------------------------------
# _merge_consecutive_roles
# ---------------------------------------------------------------------------


class TestMergeConsecutiveRoles:
    """BedrockProvider._merge_consecutive_roles merges same-role messages."""

    def _merge(self, msgs: list[dict[str, Any]]) -> list[dict[str, Any]]:
        provider, _ = _make_provider()
        return provider._merge_consecutive_roles(msgs)

    def test_empty_list(self) -> None:
        assert self._merge([]) == []

    def test_single_message(self) -> None:
        msgs = [{"role": "user", "content": [{"text": "hi"}]}]
        result = self._merge(msgs)
        assert len(result) == 1

    def test_alternating_roles_unchanged(self) -> None:
        msgs = [
            {"role": "user", "content": [{"text": "hi"}]},
            {"role": "assistant", "content": [{"text": "hello"}]},
            {"role": "user", "content": [{"text": "bye"}]},
        ]
        result = self._merge(msgs)
        assert len(result) == 3

    def test_consecutive_user_messages_merged(self) -> None:
        msgs = [
            {"role": "user", "content": [{"text": "a"}]},
            {"role": "user", "content": [{"text": "b"}]},
        ]
        result = self._merge(msgs)
        assert len(result) == 1
        assert result[0]["role"] == "user"
        assert result[0]["content"] == [{"text": "a"}, {"text": "b"}]

    def test_consecutive_assistant_messages_merged(self) -> None:
        msgs = [
            {"role": "user", "content": [{"text": "hi"}]},
            {"role": "assistant", "content": [{"text": "a"}]},
            {"role": "assistant", "content": [{"text": "b"}]},
        ]
        result = self._merge(msgs)
        assert len(result) == 2
        assert result[1]["content"] == [{"text": "a"}, {"text": "b"}]

    def test_three_consecutive_same_role_merged(self) -> None:
        msgs = [
            {"role": "user", "content": [{"text": "1"}]},
            {"role": "user", "content": [{"text": "2"}]},
            {"role": "user", "content": [{"text": "3"}]},
        ]
        result = self._merge(msgs)
        assert len(result) == 1
        assert result[0]["content"] == [
            {"text": "1"}, {"text": "2"}, {"text": "3"},
        ]


# ---------------------------------------------------------------------------
# _build_tool_config
# ---------------------------------------------------------------------------


class TestBuildToolConfig:
    """BedrockProvider._build_tool_config converts Synth schemas to Bedrock format."""

    def _build(self, tools: list[dict[str, Any]] | None) -> dict[str, Any] | None:
        provider, _ = _make_provider()
        return provider._build_tool_config(tools)

    def test_none_returns_none(self) -> None:
        assert self._build(None) is None

    def test_empty_list_returns_none(self) -> None:
        assert self._build([]) is None

    def test_single_tool_converted(self) -> None:
        tools = [
            {
                "name": "get_weather",
                "description": "Get weather for a city",
                "parameters": {"type": "object", "properties": {"city": {"type": "string"}}},
            },
        ]
        result = self._build(tools)
        assert result is not None
        assert len(result["tools"]) == 1
        spec = result["tools"][0]["toolSpec"]
        assert spec["name"] == "get_weather"
        assert spec["description"] == "Get weather for a city"
        assert spec["inputSchema"]["json"] == tools[0]["parameters"]

    def test_multiple_tools_converted(self) -> None:
        tools = [
            {"name": "add", "description": "Add numbers", "parameters": {}},
            {"name": "mul", "description": "Multiply", "parameters": {}},
        ]
        result = self._build(tools)
        assert len(result["tools"]) == 2
        assert result["tools"][0]["toolSpec"]["name"] == "add"
        assert result["tools"][1]["toolSpec"]["name"] == "mul"

    def test_missing_description_defaults_to_empty(self) -> None:
        tools = [{"name": "noop", "parameters": {}}]
        result = self._build(tools)
        assert result["tools"][0]["toolSpec"]["description"] == ""

    def test_missing_parameters_defaults_to_empty(self) -> None:
        tools = [{"name": "noop", "description": "No-op"}]
        result = self._build(tools)
        assert result["tools"][0]["toolSpec"]["inputSchema"]["json"] == {}


# ---------------------------------------------------------------------------
# _build_messages — tool_name attribution
# ---------------------------------------------------------------------------


class TestBuildMessagesToolNameAttribution:
    """Verify _build_messages reads tool_name from tool messages."""

    def _build(
        self, messages: list[Message],
    ) -> tuple[list[dict[str, Any]] | None, list[dict[str, Any]]]:
        provider, _ = _make_provider()
        return provider._build_messages(messages)

    def test_tool_name_used_in_tool_use_block(self) -> None:
        """When tool_name is present, it appears in the synthetic toolUse block."""
        _, msgs = self._build([
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "checking"},
            {"role": "tool", "content": "result", "tool_name": "get_weather"},
        ])
        # Find the assistant message with toolUse blocks
        assistant_msgs = [m for m in msgs if m["role"] == "assistant"]
        tool_use_blocks = []
        for m in assistant_msgs:
            for block in m["content"]:
                if isinstance(block, dict) and "toolUse" in block:
                    tool_use_blocks.append(block["toolUse"])
        assert len(tool_use_blocks) == 1
        assert tool_use_blocks[0]["name"] == "get_weather"

    def test_missing_tool_name_defaults_to_tool_call(self) -> None:
        """When tool_name is absent, falls back to 'tool_call'."""
        _, msgs = self._build([
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "checking"},
            {"role": "tool", "content": "result"},
        ])
        assistant_msgs = [m for m in msgs if m["role"] == "assistant"]
        tool_use_blocks = []
        for m in assistant_msgs:
            for block in m["content"]:
                if isinstance(block, dict) and "toolUse" in block:
                    tool_use_blocks.append(block["toolUse"])
        assert len(tool_use_blocks) == 1
        assert tool_use_blocks[0]["name"] == "tool_call"

    def test_consecutive_tool_results_merged(self) -> None:
        """Multiple consecutive tool messages produce paired toolUse/toolResult blocks."""
        _, msgs = self._build([
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "checking both"},
            {"role": "tool", "content": "result1", "tool_name": "search"},
            {"role": "tool", "content": "result2", "tool_name": "fetch"},
        ])
        # The assistant message should have text + 2 toolUse blocks
        assistant_msgs = [m for m in msgs if m["role"] == "assistant"]
        tool_use_blocks = []
        for m in assistant_msgs:
            for block in m["content"]:
                if isinstance(block, dict) and "toolUse" in block:
                    tool_use_blocks.append(block["toolUse"])
        assert len(tool_use_blocks) == 2
        assert tool_use_blocks[0]["name"] == "search"
        assert tool_use_blocks[1]["name"] == "fetch"

        # The user message should have 2 toolResult blocks
        user_tool_msgs = [
            m for m in msgs if m["role"] == "user"
            and any(
                isinstance(b, dict) and "toolResult" in b
                for b in m.get("content", [])
            )
        ]
        assert len(user_tool_msgs) == 1
        tool_results = [
            b["toolResult"] for b in user_tool_msgs[0]["content"]
            if isinstance(b, dict) and "toolResult" in b
        ]
        assert len(tool_results) == 2

    def test_tool_result_without_preceding_assistant_injects_one(self) -> None:
        """Tool messages without a preceding assistant message get a synthetic one."""
        _, msgs = self._build([
            {"role": "user", "content": "hi"},
            {"role": "tool", "content": "result", "tool_name": "fn"},
        ])
        # Should have: user, assistant (injected with toolUse), user (toolResult)
        roles = [m["role"] for m in msgs]
        assert roles == ["user", "assistant", "user"]
        # The injected assistant has only toolUse blocks (no text)
        assistant_content = msgs[1]["content"]
        assert all("toolUse" in b for b in assistant_content)


# ---------------------------------------------------------------------------
# _build_messages — tool_use ID correlation
# ---------------------------------------------------------------------------


class TestBuildMessagesToolIdCorrelation:
    """Verify toolUse and toolResult blocks share the same toolUseId."""

    def test_tool_use_and_result_ids_match(self) -> None:
        provider, _ = _make_provider()
        _, msgs = provider._build_messages([
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "let me check"},
            {"role": "tool", "content": "sunny", "tool_name": "weather"},
        ])
        # Extract toolUse ID from assistant message
        tool_use_id = None
        for m in msgs:
            if m["role"] == "assistant":
                for block in m["content"]:
                    if isinstance(block, dict) and "toolUse" in block:
                        tool_use_id = block["toolUse"]["toolUseId"]
        # Extract toolResult ID from user message
        tool_result_id = None
        for m in msgs:
            if m["role"] == "user":
                for block in m.get("content", []):
                    if isinstance(block, dict) and "toolResult" in block:
                        tool_result_id = block["toolResult"]["toolUseId"]
        assert tool_use_id is not None
        assert tool_result_id is not None
        assert tool_use_id == tool_result_id


# ---------------------------------------------------------------------------
# complete() — edge cases
# ---------------------------------------------------------------------------


class TestBedrockCompleteEdgeCases:
    """Edge cases for the complete() method."""

    @pytest.mark.asyncio
    async def test_complete_missing_usage_keys_default_to_zero(self) -> None:
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {"message": {"content": [{"text": "ok"}]}},
            "usage": {},
        }
        result = await provider.complete(_USER_MSG)
        assert result.usage.input_tokens == 0
        assert result.usage.output_tokens == 0
        assert result.usage.total_tokens == 0

    @pytest.mark.asyncio
    async def test_complete_empty_content_list(self) -> None:
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {"message": {"content": []}},
            "usage": {"inputTokens": 1, "outputTokens": 0, "totalTokens": 1},
        }
        result = await provider.complete(_USER_MSG)
        assert result.text == ""
        assert result.tool_calls == []

    @pytest.mark.asyncio
    async def test_complete_missing_output_key(self) -> None:
        provider, client = _make_provider()
        client.converse.return_value = {
            "usage": {"inputTokens": 1, "outputTokens": 0, "totalTokens": 1},
        }
        result = await provider.complete(_USER_MSG)
        assert result.text == ""
        assert result.tool_calls == []

    @pytest.mark.asyncio
    async def test_complete_with_system_message(self) -> None:
        """System messages are extracted and passed as the system parameter."""
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {"message": {"content": [{"text": "ok"}]}},
            "usage": {"inputTokens": 5, "outputTokens": 1, "totalTokens": 6},
        }
        messages: list[Message] = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "hi"},
        ]
        await provider.complete(messages)
        call_kwargs = client.converse.call_args[1]
        assert "system" in call_kwargs
        assert call_kwargs["system"][0]["text"] == "You are helpful."

    @pytest.mark.asyncio
    async def test_complete_strips_tool_blocks_when_no_tools(self) -> None:
        """complete() strips tool blocks instead of sending empty toolConfig."""
        provider, client = _make_provider()
        client.converse.return_value = {
            "output": {"message": {"content": [{"text": "Done."}]}},
            "usage": {"inputTokens": 5, "outputTokens": 3, "totalTokens": 8},
        }
        messages: list[Message] = [
            {"role": "user", "content": "Search"},
            {"role": "assistant", "content": "Searching..."},
            {"role": "tool", "content": "Found results", "tool_name": "search"},
            {"role": "assistant", "content": "Here you go."},
            {"role": "user", "content": "Thanks"},
        ]
        await provider.complete(messages, tools=None)
        call_kwargs = client.converse.call_args[1]
        # complete() uses _strip_tool_blocks, so no toolConfig should be present
        assert "toolConfig" not in call_kwargs
        # Verify tool blocks were actually stripped from messages
        for msg in call_kwargs["messages"]:
            for block in msg.get("content", []):
                if isinstance(block, dict):
                    assert "toolUse" not in block
                    assert "toolResult" not in block


# ---------------------------------------------------------------------------
# stream() — kwargs forwarding
# ---------------------------------------------------------------------------


class TestBedrockStreamKwargs:
    """Verify stream() forwards inference config kwargs."""

    @pytest.mark.asyncio
    async def test_stream_forwards_temperature_and_max_tokens(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "ok"}}},
                {"metadata": {"usage": {"inputTokens": 1, "outputTokens": 1}}},
            ],
        }
        await _collect_stream(provider, temperature=0.7, max_tokens=200)
        call_kwargs = client.converse_stream.call_args[1]
        assert call_kwargs["inferenceConfig"]["temperature"] == 0.7
        assert call_kwargs["inferenceConfig"]["maxTokens"] == 200

    @pytest.mark.asyncio
    async def test_stream_no_kwargs_omits_inference_config(self) -> None:
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"metadata": {"usage": {"inputTokens": 1, "outputTokens": 1}}},
            ],
        }
        await _collect_stream(provider)
        call_kwargs = client.converse_stream.call_args[1]
        assert "inferenceConfig" not in call_kwargs

    @pytest.mark.asyncio
    async def test_stream_with_system_message(self) -> None:
        """System messages are extracted and passed as the system parameter."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "ok"}}},
                {"metadata": {"usage": {"inputTokens": 5, "outputTokens": 1}}},
            ],
        }
        messages: list[Message] = [
            {"role": "system", "content": "Be concise."},
            {"role": "user", "content": "hi"},
        ]
        await _collect_stream(provider, messages)
        call_kwargs = client.converse_stream.call_args[1]
        assert "system" in call_kwargs
        assert call_kwargs["system"][0]["text"] == "Be concise."


# ---------------------------------------------------------------------------
# stream() — tool blocks fallback strips blocks (same as complete())
# ---------------------------------------------------------------------------


class TestStreamToolBlocksFallback:
    """stream() strips tool blocks when no tools are passed."""

    @pytest.mark.asyncio
    async def test_stream_strips_tool_blocks_when_no_tools(self) -> None:
        """stream() strips tool blocks from messages when tools=None."""
        provider, client = _make_provider()
        client.converse_stream.return_value = {
            "stream": [
                {"contentBlockDelta": {"delta": {"text": "ok"}}},
                {"metadata": {"usage": {"inputTokens": 5, "outputTokens": 2}}},
            ],
        }
        messages: list[Message] = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "checking"},
            {"role": "tool", "content": "result", "tool_name": "fn"},
            {"role": "assistant", "content": "done"},
            {"role": "user", "content": "thanks"},
        ]
        await _collect_stream(provider, messages, tools=None)
        call_kwargs = client.converse_stream.call_args[1]
        # Tool blocks are stripped, no toolConfig sent
        assert "toolConfig" not in call_kwargs
        for msg in call_kwargs["messages"]:
            for block in msg.get("content", []):
                if isinstance(block, dict):
                    assert "toolUse" not in block
                    assert "toolResult" not in block
