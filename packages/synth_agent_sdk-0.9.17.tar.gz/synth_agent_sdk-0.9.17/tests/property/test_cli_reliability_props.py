# Feature: synth-cli-reliability-fixes, Properties 1-9
"""Property-based tests for CLI reliability fixes.

**Property 1: sys.path injection ensures parent directory is present**
**Validates: Requirements 1.1, 1.3**

**Property 2: sys.path injection is idempotent**
**Validates: Requirements 1.2**

**Property 3: Venv detection correctness**
**Validates: Requirements 3.1**

**Property 4: Thread ID consistency across conversation turns**
**Validates: Requirements 4.1, 4.2**

**Property 5: Tool result serialization completeness**
**Validates: Requirements 4.6**

**Property 6: Content block sanitization**
**Validates: Requirements 5.1, 5.2, 5.3**

**Property 7: Agent name validation accepts only valid names**
**Validates: Requirements 6.1**

**Property 8: Dockerfile folder mismatch error includes all available folders**
**Validates: Requirements 6.3**

**Property 9: Agent name sanitization produces valid names**
**Validates: Requirements 6.4**
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

from hypothesis import given, settings
from hypothesis import strategies as st


# ---------------------------------------------------------------------------
# Helper — extracted sys.path injection logic (mirrors run_cmd.py / _tui.py)
# ---------------------------------------------------------------------------

def _inject_agent_dir(file: str) -> str:
    """Prepend the agent file's parent directory to ``sys.path``.

    Returns the resolved parent directory string.
    This is the exact pattern used in ``run_cmd._load_agent`` and
    ``_tui._load_agent_module``.
    """
    agent_dir = str(Path(file).resolve().parent)
    if agent_dir not in sys.path:
        sys.path.insert(0, agent_dir)
    return agent_dir


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

# File-path segments: printable, non-empty, no null bytes or path separators
_path_segment = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "N"),
        whitelist_characters="_-.",
    ),
    min_size=1,
    max_size=30,
).filter(lambda s: s.strip(".") != "")

# Build a plausible file path from 1-4 segments ending with ".py"
_file_path = st.builds(
    lambda parts, name: str(Path(*parts, f"{name}.py")),
    parts=st.lists(_path_segment, min_size=1, max_size=4),
    name=_path_segment,
)


# ---------------------------------------------------------------------------
# Property 1: sys.path injection ensures parent directory is present
# ---------------------------------------------------------------------------


class TestSysPathInjection:
    """Property tests for the sys.path injection logic."""

    @settings(max_examples=100)
    @given(file_path=_file_path)
    def test_parent_directory_present_after_injection(self, file_path: str) -> None:
        """Property 1: For any agent file path, after injection the parent
        directory is present in ``sys.path``.

        **Validates: Requirements 1.1, 1.3**
        """
        # Snapshot and restore sys.path to avoid cross-test pollution
        original_path = sys.path.copy()
        try:
            agent_dir = _inject_agent_dir(file_path)
            assert agent_dir in sys.path, (
                f"Expected '{agent_dir}' in sys.path after injection"
            )
        finally:
            sys.path[:] = original_path

    # -------------------------------------------------------------------
    # Property 2: sys.path injection is idempotent
    # -------------------------------------------------------------------

    @settings(max_examples=100)
    @given(
        file_path=_file_path,
        repeat_count=st.integers(min_value=1, max_value=10),
    )
    def test_injection_is_idempotent(
        self, file_path: str, repeat_count: int
    ) -> None:
        """Property 2: Calling the injection N times never produces duplicate
        entries of the parent directory in ``sys.path``.

        **Validates: Requirements 1.2**
        """
        original_path = sys.path.copy()
        try:
            agent_dir = str(Path(file_path).resolve().parent)
            count_before = sys.path.count(agent_dir)

            for _ in range(repeat_count):
                _inject_agent_dir(file_path)

            count_after = sys.path.count(agent_dir)
            expected = max(1, count_before)
            assert count_after == expected, (
                f"Expected count {expected} for '{agent_dir}' but got "
                f"{count_after} after {repeat_count} injection(s)"
            )
        finally:
            sys.path[:] = original_path



# ---------------------------------------------------------------------------
# Feature: synth-cli-reliability-fixes, Property 3: Venv detection correctness
# ---------------------------------------------------------------------------


class TestVenvDetection:
    """Property tests for the ``_is_in_venv()`` helper.

    **Property 3: Venv detection correctness**
    **Validates: Requirements 3.1**

    For any combination of ``sys.prefix``, ``sys.base_prefix``, and
    ``VIRTUAL_ENV`` / ``CONDA_DEFAULT_ENV`` environment variables,
    ``_is_in_venv()`` shall return ``True`` if and only if
    ``sys.prefix != sys.base_prefix`` or ``VIRTUAL_ENV`` is set or
    ``CONDA_DEFAULT_ENV`` is set.
    """

    @settings(max_examples=100)
    @given(
        prefix_differs=st.booleans(),
        virtual_env_set=st.booleans(),
        conda_env_set=st.booleans(),
    )
    def test_venv_detection_correctness(
        self,
        prefix_differs: bool,
        virtual_env_set: bool,
        conda_env_set: bool,
    ) -> None:
        """Property 3: ``_is_in_venv()`` returns True iff at least one
        venv indicator is active.

        **Validates: Requirements 3.1**
        """
        from synth.cli.init_cmd import _is_in_venv

        # Build mock values based on the generated booleans
        fake_prefix = "/fake/venv" if prefix_differs else "/fake/base"
        fake_base_prefix = "/fake/base"

        # Build a clean environment dict without venv-related vars
        clean_env = {k: v for k, v in os.environ.items()
                     if k not in ("VIRTUAL_ENV", "CONDA_DEFAULT_ENV")}
        if virtual_env_set:
            clean_env["VIRTUAL_ENV"] = "/some/venv"
        if conda_env_set:
            clean_env["CONDA_DEFAULT_ENV"] = "myenv"

        expected = prefix_differs or virtual_env_set or conda_env_set

        with patch.object(sys, "prefix", fake_prefix), \
             patch.object(sys, "base_prefix", fake_base_prefix), \
             patch.dict(os.environ, clean_env, clear=True):
            result = _is_in_venv()

        assert result == expected, (
            f"_is_in_venv() returned {result}, expected {expected} "
            f"(prefix_differs={prefix_differs}, "
            f"virtual_env_set={virtual_env_set}, "
            f"conda_env_set={conda_env_set})"
        )


# ---------------------------------------------------------------------------
# Feature: synth-cli-reliability-fixes, Property 4: Thread ID consistency
# ---------------------------------------------------------------------------


class TestThreadIdConsistency:
    """Property tests for thread_id passthrough in the UI server.

    **Property 4: Thread ID consistency across conversation turns**
    **Validates: Requirements 4.1, 4.2**

    For any conversation ID passed to the UI server's chat endpoints,
    the ``thread_id`` passed to the agent's ``run`` or ``stream`` method
    shall equal the conversation ID, ensuring the same memory context is
    used across all turns of a conversation.
    """

    @settings(max_examples=100)
    @given(conv_id=st.text(min_size=1))
    def test_run_agent_passes_thread_id(self, conv_id: str) -> None:
        """Property 4 (run path): ``_run_agent`` forwards the conversation
        ID as ``thread_id`` to ``agent.run()``.

        **Validates: Requirements 4.1, 4.2**
        """
        from synth.types import RunResult, TokenUsage

        captured: dict[str, Any] = {}

        def fake_run(prompt: str, **kwargs: Any) -> RunResult:
            captured.update(kwargs)
            return RunResult(
                text="ok",
                output=None,
                tokens=TokenUsage(
                    input_tokens=0, output_tokens=0, total_tokens=0,
                ),
                cost=0.0,
                latency_ms=0.0,
                trace=None,
                tool_calls=[],
            )

        mock_agent = MagicMock()
        mock_agent.run = fake_run

        # Replicate the logic from server._run_agent
        start = time.perf_counter()
        result = mock_agent.run("hello", thread_id=conv_id)
        elapsed = (time.perf_counter() - start) * 1000

        assert captured.get("thread_id") == conv_id, (
            f"Expected thread_id={conv_id!r}, got {captured.get('thread_id')!r}"
        )

    @settings(max_examples=100)
    @given(conv_id=st.text(min_size=1))
    def test_stream_passes_thread_id(self, conv_id: str) -> None:
        """Property 4 (stream path): the streaming code forwards the
        conversation ID as ``thread_id`` to ``agent.stream()``.

        **Validates: Requirements 4.1, 4.2**
        """
        from synth.types import DoneEvent, RunResult, TokenUsage

        captured: dict[str, Any] = {}

        def fake_stream(prompt: str, **kwargs: Any):
            captured.update(kwargs)
            yield DoneEvent(
                result=RunResult(
                    text="ok",
                    output=None,
                    tokens=TokenUsage(
                        input_tokens=0, output_tokens=0, total_tokens=0,
                    ),
                    cost=0.0,
                    latency_ms=0.0,
                    trace=None,
                    tool_calls=[],
                )
            )

        mock_agent = MagicMock()
        mock_agent.stream = fake_stream

        # Consume the generator the same way the server does
        for _event in mock_agent.stream("hello", thread_id=conv_id):
            pass

        assert captured.get("thread_id") == conv_id, (
            f"Expected thread_id={conv_id!r}, got {captured.get('thread_id')!r}"
        )


# ---------------------------------------------------------------------------
# Feature: synth-cli-reliability-fixes, Property 5: Tool result serialization
# ---------------------------------------------------------------------------


class TestToolResultSerialization:
    """Property tests for tool result serialization completeness.

    **Property 5: Tool result serialization completeness**
    **Validates: Requirements 4.6**

    For any ``ToolCallRecord`` with a name, args dict, result string, and
    latency value, the serialized output dict shall contain keys ``name``,
    ``args``, ``result``, and ``latency_ms`` with values matching the input
    record.
    """

    @settings(max_examples=100)
    @given(
        name=st.text(min_size=1),
        args=st.dictionaries(
            keys=st.text(min_size=1, max_size=20),
            values=st.one_of(st.text(), st.integers(), st.floats(allow_nan=False), st.booleans()),
            max_size=5,
        ),
        result_text=st.text(),
        latency=st.floats(min_value=0.0, max_value=1e6, allow_nan=False, allow_infinity=False),
    )
    def test_tool_call_serialization_contains_all_keys(
        self,
        name: str,
        args: dict[str, Any],
        result_text: str,
        latency: float,
    ) -> None:
        """Property 5: Serialized tool call dict contains ``name``, ``args``,
        ``result``, and ``latency_ms`` matching the input record.

        **Validates: Requirements 4.6**
        """
        from synth.types import ToolCallRecord  # noqa: F811

        record = ToolCallRecord(
            name=name,
            args=args,
            result=result_text,
            latency_ms=latency,
        )

        # Replicate the serialization logic from server._build_msg
        serialized = {
            "name": record.name,
            "args": record.args,
            "result": str(record.result),
            "latency_ms": round(record.latency_ms, 1),
        }

        assert serialized["name"] == name
        assert serialized["args"] == args
        assert serialized["result"] == str(result_text)
        assert serialized["latency_ms"] == round(latency, 1)
        assert set(serialized.keys()) == {"name", "args", "result", "latency_ms"}


# ---------------------------------------------------------------------------
# Feature: synth-cli-reliability-fixes, Property 6: Content block sanitization
# ---------------------------------------------------------------------------


class TestContentBlockSanitization:
    """Property tests for the ``_sanitize_content()`` helper.

    **Property 6: Content block sanitization**
    **Validates: Requirements 5.1, 5.2, 5.3**

    For any string that is empty, ``None``, or composed entirely of
    whitespace characters, ``_sanitize_content`` shall return a non-empty
    string that contains at least one non-whitespace character.
    """

    @settings(max_examples=100)
    @given(text=st.from_regex(r"^\s*$", fullmatch=True))
    def test_blank_inputs_produce_non_empty_output(self, text: str) -> None:
        """Property 6 (blank path): empty strings and whitespace-only strings
        are replaced with a non-empty, non-whitespace result.

        **Validates: Requirements 5.1, 5.3**
        """
        from synth.agent import _sanitize_content

        result = _sanitize_content(text)
        assert len(result) > 0, "Result must be non-empty"
        assert result.strip(), "Result must contain at least one non-whitespace character"

    @settings(max_examples=100)
    @given(text=st.text(min_size=1).filter(lambda s: s.strip()))
    def test_non_blank_inputs_pass_through(self, text: str) -> None:
        """Property 6 (passthrough path): non-blank strings are returned
        unchanged.

        **Validates: Requirements 5.1, 5.2, 5.3**
        """
        from synth.agent import _sanitize_content

        result = _sanitize_content(text)
        assert result == text, (
            f"Non-blank input should pass through unchanged: "
            f"got {result!r} for input {text!r}"
        )

    @settings(max_examples=100)
    @given(text=st.text())
    def test_output_is_never_empty_or_whitespace_only(self, text: str) -> None:
        """Property 6 (universal): for any input, the result is never empty
        and never whitespace-only.

        **Validates: Requirements 5.1, 5.2, 5.3**
        """
        from synth.agent import _sanitize_content

        result = _sanitize_content(text)
        assert len(result) > 0, "Result must be non-empty for any input"
        assert result.strip(), "Result must contain at least one non-whitespace character"


# ---------------------------------------------------------------------------
# Feature: synth-cli-reliability-fixes, Property 7: Agent name validation
# ---------------------------------------------------------------------------


# AgentCore naming pattern — same regex used in deploy_cmd._stage_manifest
_AGENTCORE_NAME_PATTERN = r"^[a-zA-Z][a-zA-Z0-9_]{0,47}$"

# Strategy for valid AgentCore names
_valid_agentcore_name = st.from_regex(
    r"[a-zA-Z][a-zA-Z0-9_]{0,47}", fullmatch=True,
)


def _is_valid_agentcore_name(name: str) -> bool:
    """Check if a name matches the AgentCore naming pattern.

    This mirrors the regex check in ``deploy_cmd._stage_manifest``.
    """
    import re

    return bool(re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_]{0,47}", name))


class TestAgentNameValidation:
    """Property tests for AgentCore name validation.

    **Property 7: Agent name validation accepts only valid names**
    **Validates: Requirements 6.1**

    For any string, the AgentCore name validation regex shall accept the
    string if and only if it starts with a letter, contains only
    letters/numbers/underscores, and is 1–48 characters long.
    """

    @settings(max_examples=100)
    @given(name=_valid_agentcore_name)
    def test_valid_names_are_accepted(self, name: str) -> None:
        """Property 7 (positive): names generated from the valid pattern
        are always accepted by the validator.

        **Validates: Requirements 6.1**
        """
        assert _is_valid_agentcore_name(name), (
            f"Expected valid name {name!r} to be accepted"
        )
        # Also verify structural properties hold
        assert name[0].isalpha(), "Must start with a letter"
        assert all(c.isalnum() or c == "_" for c in name), (
            "Must contain only letters, numbers, underscores"
        )
        assert 1 <= len(name) <= 48, "Must be 1–48 characters"

    @settings(max_examples=100)
    @given(name=st.text())
    def test_validation_matches_structural_check(self, name: str) -> None:
        """Property 7 (equivalence): the regex accepts a string iff it
        satisfies all three structural conditions — starts with an ASCII
        letter, ASCII alphanumeric/underscore only, and 1–48 chars.

        **Validates: Requirements 6.1**
        """
        _ASCII_LETTERS = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
        _ASCII_ALNUM_UNDER = _ASCII_LETTERS | set("0123456789_")

        structurally_valid = (
            len(name) >= 1
            and len(name) <= 48
            and name[0] in _ASCII_LETTERS
            and all(c in _ASCII_ALNUM_UNDER for c in name)
        ) if name else False

        assert _is_valid_agentcore_name(name) == structurally_valid, (
            f"Regex and structural check disagree for {name!r}: "
            f"regex={_is_valid_agentcore_name(name)}, "
            f"structural={structurally_valid}"
        )

    @settings(max_examples=100)
    @given(name=st.text().filter(lambda s: len(s) > 48))
    def test_names_over_48_chars_are_rejected(self, name: str) -> None:
        """Property 7 (length boundary): names longer than 48 characters
        are always rejected.

        **Validates: Requirements 6.1**
        """
        assert not _is_valid_agentcore_name(name), (
            f"Expected name of length {len(name)} to be rejected"
        )


# ---------------------------------------------------------------------------
# Feature: synth-cli-reliability-fixes, Property 8: Dockerfile folder mismatch
# ---------------------------------------------------------------------------


# Strategy for folder names: non-empty, no path separators or null bytes,
# no trailing dots/spaces (Windows normalizes those away),
# no Windows reserved device names (CON, PRN, AUX, NUL, COM1-9, LPT1-9)
_WINDOWS_RESERVED = frozenset({
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
})
_folder_name = st.text(
    alphabet=st.characters(
        whitelist_categories=("L", "N"),
        whitelist_characters="_-",
    ),
    min_size=1,
    max_size=30,
).filter(lambda s: s.strip() != "" and s.upper() not in _WINDOWS_RESERVED)


class TestDockerfileFolderMismatch:
    """Property tests for Dockerfile folder mismatch error reporting.

    **Property 8: Dockerfile folder mismatch error includes all available
    folders**
    **Validates: Requirements 6.3**

    For any set of folder names in ``.bedrock_agentcore/`` and any agent
    name that does not match any folder, the error message shall contain
    every folder name from the set.
    """

    @settings(max_examples=100)
    @given(
        folder_names=st.lists(_folder_name, min_size=1, max_size=8, unique=True),
    )
    def test_error_contains_all_folder_names(
        self, folder_names: list[str],
    ) -> None:
        """Property 8: when the agent name doesn't match any folder, the
        error message/suggestion contains every available folder name.

        **Validates: Requirements 6.3**
        """
        import tempfile

        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)

            # Create a fake agent file and .bedrock_agentcore/ directory
            agent_file = tmp_path / "agent.py"
            agent_file.write_text("agent = None")

            agentcore_dir = tmp_path / ".bedrock_agentcore"
            agentcore_dir.mkdir()
            for name in folder_names:
                (agentcore_dir / name).mkdir(exist_ok=True)

            # Use an agent name guaranteed not to match any folder
            agent_name = "zzz_nonexistent_agent_name_zzz"
            while agent_name in folder_names:
                agent_name += "_x"

            result = _stage_dockerfile_validation(
                agent_name=agent_name,
                file=str(agent_file),
            )

        assert not result.success, "Expected failure for mismatched name"

        # The suggestion field should contain all folder names
        combined = f"{result.message} {result.suggestion or ''}"
        for folder in folder_names:
            assert folder in combined, (
                f"Folder {folder!r} not found in error output: "
                f"{combined!r}"
            )

    @settings(max_examples=100)
    @given(folder_name=_folder_name)
    def test_matching_folder_returns_success(
        self, folder_name: str,
    ) -> None:
        """Property 8 (positive): when the agent name matches a folder,
        validation succeeds.

        **Validates: Requirements 6.3**
        """
        import tempfile

        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)

            agent_file = tmp_path / "agent.py"
            agent_file.write_text("agent = None")

            agentcore_dir = tmp_path / ".bedrock_agentcore"
            agentcore_dir.mkdir()
            (agentcore_dir / folder_name).mkdir(exist_ok=True)

            result = _stage_dockerfile_validation(
                agent_name=folder_name,
                file=str(agent_file),
            )

        assert result.success, (
            f"Expected success when folder matches agent name "
            f"{folder_name!r}, got: {result.message}"
        )


# ---------------------------------------------------------------------------
# Feature: synth-cli-reliability-fixes, Property 9: Agent name sanitization
# ---------------------------------------------------------------------------


class TestAgentNameSanitization:
    """Property tests for the ``_sanitize_for_path()`` function.

    **Property 9: Agent name sanitization produces valid names**
    **Validates: Requirements 6.4**

    For any non-empty input string, ``_sanitize_for_path`` shall return a
    string that matches the AgentCore naming pattern
    ``^[a-zA-Z][a-zA-Z0-9_]{0,47}$``.
    """

    @settings(max_examples=100)
    @given(value=st.text(min_size=1))
    def test_sanitized_name_is_always_valid(self, value: str) -> None:
        """Property 9: the sanitized output always matches the AgentCore
        naming pattern.

        **Validates: Requirements 6.4**
        """
        from synth.deploy.agentcore.manifest import _sanitize_for_path

        result = _sanitize_for_path(value)

        assert _is_valid_agentcore_name(result), (
            f"Sanitized name {result!r} (from input {value!r}) does not "
            f"match AgentCore pattern"
        )

    @settings(max_examples=100)
    @given(value=st.text(min_size=1))
    def test_sanitized_name_starts_with_letter(self, value: str) -> None:
        """Property 9 (structural): the sanitized name always starts with
        a letter.

        **Validates: Requirements 6.4**
        """
        from synth.deploy.agentcore.manifest import _sanitize_for_path

        result = _sanitize_for_path(value)

        assert result[0].isalpha(), (
            f"Sanitized name {result!r} does not start with a letter "
            f"(input: {value!r})"
        )

    @settings(max_examples=100)
    @given(value=st.text(min_size=1))
    def test_sanitized_name_within_length_limit(self, value: str) -> None:
        """Property 9 (length): the sanitized name is 1–48 characters.

        **Validates: Requirements 6.4**
        """
        from synth.deploy.agentcore.manifest import _sanitize_for_path

        result = _sanitize_for_path(value)

        assert 1 <= len(result) <= 48, (
            f"Sanitized name {result!r} has length {len(result)}, "
            f"expected 1–48 (input: {value!r})"
        )
