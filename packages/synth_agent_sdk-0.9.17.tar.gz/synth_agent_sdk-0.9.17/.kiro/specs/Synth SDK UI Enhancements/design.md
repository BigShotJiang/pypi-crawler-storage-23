# Design Document: Testing UI Enhancements

## Overview

This design extends the Synth SDK's browser-based testing dashboard with four capabilities: a live agent configuration panel, guard evaluation visibility, streaming performance metrics, and enhanced export. All changes follow the existing vanilla JS + FastAPI architecture. The backend (`server.py`) gains new endpoints for configuration introspection and mutation, while the frontend (`app.js`, `index.html`, `style.css`) gains a new Config tab, telemetry panel extensions, and export functions.

The design preserves the single-file-per-concern structure: `server.py` for all backend logic, `app.js` for all frontend logic, `index.html` for layout, and `style.css` for styling. No new frameworks or build tools are introduced.

## Architecture

```mermaid
graph TB
    subgraph Browser["Browser (Vanilla JS)"]
        ConfigPanel["Config Panel Tab"]
        TelemetryPanel["Telemetry Panel"]
        ExportFns["Export Functions"]
        ChatTab["Chat Tab (existing)"]
        EvalsTab["Evals Tab (existing)"]
    end

    subgraph Server["FastAPI Server (server.py)"]
        ConfigAPI["Config API Endpoints"]
        StreamAPI["Streaming Chat (SSE)"]
        ExistingAPI["Existing Endpoints"]
        AgentState["Agent Runtime State"]
        FilePatcher["File Patcher"]
    end

    subgraph SDK["Synth SDK"]
        Agent["Agent Instance"]
        ProviderRouter["ProviderRouter"]
        Guards["Guard Instances"]
    end

    ConfigPanel -->|"GET /api/config"| ConfigAPI
    ConfigPanel -->|"PATCH /api/config"| ConfigAPI
    ConfigPanel -->|"POST /api/config/save"| FilePatcher
    ConfigPanel -->|"POST /api/reload"| ExistingAPI
    TelemetryPanel -->|"SSE guard_result events"| StreamAPI
    TelemetryPanel -->|"Client-side timing"| ChatTab
    ExportFns -->|"GET /api/conversations/{id}"| ExistingAPI
    ExportFns -->|"Client-side JSON/MD generation"| Browser

    ConfigAPI --> AgentState
    AgentState --> Agent
    AgentState --> ProviderRouter
    StreamAPI --> Guards
    FilePatcher -->|"Atomic write"| AgentFile["agent.py on disk"]
```

## Components and Interfaces

### Backend Components (server.py additions)

#### 1. Agent Runtime State Manager

Manages the mutable runtime state of the agent, tracking the original on-disk values for drift detection.

```python
# New module-level state
_original_config: dict[str, Any] = {}  # Snapshot at load time
_disabled_tools: set[str] = set()      # Tools toggled off at runtime
_all_tools: dict[str, Any] = {}        # Full tool registry (never mutated)
```

#### 2. Configuration API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/api/config` | GET | Return current runtime config (model, instructions, tools with enabled status, guards, drift status, agentcore metadata) |
| `/api/config` | PATCH | Update model, instructions, or tool enabled states at runtime |
| `/api/config/save` | POST | Persist runtime config to agent file using atomic write |
| `/api/models` | GET | Return available models grouped by provider |

#### 3. Guard Evaluation Hook

The streaming endpoint (`/api/chat/stream`) is extended to:
1. Capture guard evaluation results (name, passed, duration_ms, violation_message) during the agent run
2. Emit a `guard_result` SSE event before the final `done` event

#### 4. File Patcher

Reuses the regex patterns from `synth/cli/edit_cmd.py` (`_patch_model`, `_patch_instructions`, `_patch_tools_list`) and the `_atomic_write` function. The server imports these directly rather than duplicating them.

### Frontend Components (app.js additions)

#### 1. Config Tab (`switchTab("config")`)

A new tab added to the tab bar. Layout follows the existing `feature-layout` pattern (main area + sidebar). Contains:
- Model selector dropdown (grouped `<optgroup>` by provider)
- Instructions textarea (auto-resizing)
- Tool list with toggle switches
- "Save to file" and "Reset" buttons
- Drift indicator badge on the tab button
- AgentCore deployment info section (conditional)

#### 2. Streaming Metrics Tracker

Client-side timing logic in `sendPrompt()`:
- Records `requestStartTime` when the fetch begins
- Records `firstTokenTime` on the first `token` SSE event
- Computes TTFT = `firstTokenTime - requestStartTime`
- Counts tokens during streaming
- Computes tokens/sec and duration on `done` event
- Passes metrics to `updateTelemetry()`

#### 3. Export Functions

Pure client-side functions that build file content from conversation/eval data and trigger browser downloads via `URL.createObjectURL()` + temporary `<a>` element click.

### Interface Contracts

#### GET /api/config Response

```json
{
  "model": "claude-sonnet-4-5",
  "instructions": "You are a helpful assistant...",
  "tools": [
    {"name": "search", "description": "Search the web", "enabled": true},
    {"name": "calculator", "description": "Do math", "enabled": false}
  ],
  "guards": [
    {"name": "no_pii_output", "type": "PIIGuard"},
    {"name": "cost_limit", "type": "CostGuard"}
  ],
  "has_drift": true,
  "agentcore": {
    "detected": true,
    "agent_name": "my-agent",
    "aws_region": "us-east-1",
    "model_id": "bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0"
  }
}
```

#### PATCH /api/config Request

```json
{
  "model": "gpt-4o",
  "instructions": "Updated instructions...",
  "tools": {"search": true, "calculator": false}
}
```

All fields are optional — only provided fields are updated.

#### PATCH /api/config Response

```json
{
  "status": "updated",
  "warnings": [],
  "has_drift": true
}
```

#### POST /api/config/save Response

```json
{
  "status": "saved",
  "warnings": ["Could not patch 'model' — value appears to come from an environment variable."]
}
```

#### GET /api/models Response

```json
{
  "providers": {
    "Anthropic": ["claude-sonnet-4-5", "claude-haiku-3-5"],
    "OpenAI": ["gpt-4o", "gpt-4o-mini"],
    "Google": ["gemini-2.0-flash"],
    "Ollama": ["ollama/llama3.2"],
    "Bedrock": ["bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0"]
  }
}
```

#### SSE guard_result Event

```json
{"type": "guard_result", "guards": [
  {"name": "no_pii_output", "passed": true, "duration_ms": 2.3, "violation_message": null},
  {"name": "cost_limit", "passed": false, "duration_ms": 0.1, "violation_message": "Cost limit exceeded"}
]}
```

## Data Models

### Runtime Configuration State (server.py)

```python
@dataclass
class RuntimeConfig:
    """Snapshot of agent configuration for drift detection."""
    model: str
    instructions: str
    tool_names: list[str]

# Module-level state
_original_config: RuntimeConfig | None = None
_disabled_tools: set[str] = set()
_all_tools: dict[str, Any] = {}  # name -> tool function
```

### Guard Evaluation Record

```python
@dataclass
class GuardEvalRecord:
    """Result of a single guard evaluation during a chat request."""
    name: str
    guard_type: str
    passed: bool
    duration_ms: float
    violation_message: str | None = None
```

### Streaming Metrics (client-side)

```javascript
// Computed in sendPrompt(), passed to updateTelemetry()
const streamingMetrics = {
    ttft_ms: 0,        // Time to first token
    tokens_per_sec: 0, // Output tokens / streaming duration
    stream_duration_ms: 0, // First token to done event
};
```

### Export Data Structures (client-side)

Conversation JSON export uses the existing conversation message format from `_conversations` storage. No new data model needed — the export serializes the existing structure.

Eval JSON export uses the results array returned by `/api/evals/run`. No new data model needed.


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Config response completeness

*For any* Agent instance with any combination of model string, instructions text, registered tools, and guards, the GET `/api/config` response SHALL contain the model string, full instructions, all tools with name/description/enabled fields, and all guards with name/type fields.

**Validates: Requirements 1.1, 1.3**

### Property 2: Config update correctness

*For any* valid model string and any instructions string, after a PATCH `/api/config` request containing those values, the Agent's `model` attribute SHALL equal the new model and the Agent's `instructions` attribute SHALL equal the new instructions.

**Validates: Requirements 2.1, 3.1**

### Property 3: Invalid model rejection

*For any* model string that does not match any known provider prefix (claude-, gpt-, gemini-, ollama/, bedrock/) and has no base_url configured, a PATCH `/api/config` with that model SHALL return an error response and the Agent's model attribute SHALL remain unchanged from its value before the request.

**Validates: Requirements 2.3**

### Property 4: Tool toggle round-trip

*For any* tool in the Agent's registry, disabling the tool and then re-enabling it SHALL result in the tool being present in the Agent's active tool set, and the active tool set SHALL be equivalent to its state before the disable operation.

**Validates: Requirements 4.1, 4.2**

### Property 5: Tool registry invariant

*For any* sequence of tool enable/disable operations, the full tool registry (`_all_tools`) SHALL remain unchanged in size and content — it SHALL always contain exactly the tools that were present when the Agent was loaded.

**Validates: Requirements 4.3**

### Property 6: Agent file patching round-trip

*For any* valid agent source file containing `Agent(model="M", instructions="I", tools=[T])` with string literal arguments, patching the model, instructions, and tools list with new values and then re-parsing the patched source SHALL yield the new values.

**Validates: Requirements 5.2**

### Property 7: Non-patchable field warning

*For any* agent source file where the model argument is not a string literal (e.g., `model=os.environ["MODEL"]` or `model=config.model`), the save operation SHALL return a warning for the model field and SHALL not modify that argument in the source.

**Validates: Requirements 5.3**

### Property 8: Drift detection correctness

*For any* pair of RuntimeConfig (current) and RuntimeConfig (original), the `has_drift` flag SHALL be `True` if and only if the model, instructions, or enabled tool set differs between the two configs.

**Validates: Requirements 7.1**

### Property 9: Guard results completeness

*For any* Agent with N guards configured, the guard evaluation results in the chat response SHALL contain exactly N entries, each with a name, passed boolean, duration_ms number, and violation_message (string or null).

**Validates: Requirements 8.1**

### Property 10: Guard event ordering in SSE

*For any* SSE stream from an Agent with guards, if a `guard_result` event is emitted, it SHALL appear before the `done` event in the event sequence.

**Validates: Requirements 8.4**

### Property 11: Streaming metrics computation

*For any* sequence of SSE events with known timestamps where the first `token` event arrives at time T1, the `done` event arrives at time T2, and N output tokens are produced: TTFT SHALL equal T1 minus the request start time, streaming duration SHALL equal T2 minus T1, and tokens per second SHALL equal N divided by ((T2 - T1) / 1000). When streaming duration is zero, tokens per second SHALL be zero.

**Validates: Requirements 9.1, 9.2, 9.3**

### Property 12: Conversation JSON export completeness

*For any* conversation containing user and agent messages, the JSON export SHALL parse as valid JSON and SHALL contain every message with its role, content, and timestamp fields. Agent messages SHALL additionally include token counts, cost, latency, and tool call arrays.

**Validates: Requirements 10.1**

### Property 13: Conversation Markdown export completeness

*For any* conversation containing user and agent messages, the Markdown export SHALL contain a section for every message with a role header and the message content. Agent messages with tool calls SHALL include the tool call names inline.

**Validates: Requirements 11.1**

### Property 14: Eval JSON export completeness

*For any* array of eval results, the JSON export SHALL parse as valid JSON and SHALL contain every result with its case name, input, expected output, actual output, score, and pass/fail status fields.

**Validates: Requirements 12.1**

### Property 15: AgentCore metadata detection

*For any* valid `agentcore.yaml` file containing agent_name, aws_region, and model_id fields, the GET `/api/config` response SHALL include an `agentcore` object with `detected: true` and the corresponding field values.

**Validates: Requirements 14.1**

### Property 16: AgentCore model mismatch detection

*For any* runtime model string and any AgentCore model_id string, the mismatch flag SHALL be `True` if and only if the two strings are not equal.

**Validates: Requirements 14.3**

## Error Handling

### Backend Errors

| Scenario | Response | HTTP Status |
|---|---|---|
| PATCH /api/config with invalid model | `{"error": "Model 'xyz' not recognized. Available prefixes: claude-, gpt-, gemini-, ollama/, bedrock/"}` | 400 |
| PATCH /api/config when no agent loaded | `{"error": "No agent loaded."}` | 503 |
| POST /api/config/save with empty model | `{"error": "Model string must not be empty."}` | 400 |
| POST /api/config/save with empty instructions | `{"error": "Instructions must not be empty."}` | 400 |
| POST /api/config/save file write failure | `{"error": "Failed to write agent file: <reason>"}` | 500 |
| POST /api/config/save non-patchable fields | `{"status": "saved", "warnings": ["Could not patch 'model' — value is not a string literal."]}` | 200 |
| GET /api/config when no agent loaded | `{"error": "No agent loaded."}` | 503 |
| Guard evaluation exception during stream | SSE event: `{"type": "error", "error": "Guard evaluation failed: <message>"}` | N/A (SSE) |

### Frontend Errors

- API call failures: Display error in a toast notification matching the CRT theme (red text, auto-dismiss after 5 seconds).
- Save warnings: Display in a yellow warning box below the Save button, listing each unpatchable field.
- Network errors during streaming: Handled by existing `sendPrompt()` error path — displays error message in chat area.

## Testing Strategy

### Unit Tests (tests/unit/)

- `test_ui_config.py`: Test config endpoint response structure, PATCH validation, drift detection logic, AgentCore yaml parsing.
- `test_ui_export.py`: Test JSON and Markdown export generation functions (if extracted as helpers).
- `test_ui_patching.py`: Test regex patching functions with various agent file patterns (string literals, env vars, multiline instructions, missing fields).

### Property-Based Tests (tests/property/)

- `test_ui_properties.py`: Property tests using `hypothesis` for:
  - Config response completeness (Property 1)
  - Config update correctness (Property 2)
  - Invalid model rejection (Property 3)
  - Tool toggle round-trip (Property 4)
  - Tool registry invariant (Property 5)
  - Agent file patching round-trip (Property 6)
  - Non-patchable field warning (Property 7)
  - Drift detection correctness (Property 8)
  - Streaming metrics computation (Property 11)
  - Conversation JSON export completeness (Property 12)
  - Conversation Markdown export completeness (Property 13)
  - Eval JSON export completeness (Property 14)

- Property tests requiring server integration (Properties 9, 10, 15, 16) will be tested as unit tests with specific examples since they require SSE stream mocking or filesystem setup.

### Property-Based Testing Configuration

- Library: `hypothesis` (Python)
- Minimum iterations: 100 per property (`@settings(max_examples=100)`)
- Each test tagged with: `# Feature: testing-ui-enhancements, Property N: <title>`
- Custom strategies for generating Agent configs, tool registries, conversation data, and agent source files.

### Frontend Testing

Frontend logic (streaming metrics computation, export generation, drift detection) is tested indirectly through the backend property tests where the logic is shared, and through manual testing for DOM-specific behavior. The export functions and metrics computation are pure functions that can be extracted and tested if a JS test runner is added in the future.
