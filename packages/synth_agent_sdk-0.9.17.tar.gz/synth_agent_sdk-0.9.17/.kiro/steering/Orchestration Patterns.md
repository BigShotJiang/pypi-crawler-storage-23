---
inclusion: fileMatch
fileMatchPattern: "synth/orchestration/*"
---

# Orchestration Patterns

Rules for implementing and modifying the orchestration layer in `synth/orchestration/`.

## Module Responsibilities

- `pipeline.py` — `Pipeline` class for linear sequential (and optionally parallel)
  agent chaining.
- `graph.py` — `Graph` class, `@node` decorator, edge routing with conditional logic,
  concurrent node execution, and `Graph.END` sentinel.
- `team.py` — `AgentTeam` class for multi-agent coordination with `"auto"` and
  `"parallel"` strategies.
- `human_in_loop.py` — `PausedRun` class and human-in-the-loop pause/resume logic.

## Pipeline Rules

- `Pipeline([agent_a, agent_b, agent_c])` executes sequentially by default. Each stage
  receives the previous stage's `result.text` as its prompt.
- `ParallelGroup` wraps agents for concurrent execution within a pipeline. These run
  via `asyncio.gather()` and merge outputs (concatenation by default, configurable via
  a merge function).
- On error at step k, halt execution immediately. Raise `PipelineError` with:
  - `failed_step` — the zero-indexed step that failed
  - `agent_name` — the name of the failing agent
  - `partial_results` — `list[RunResult]` from steps 0 through k-1
- Streaming wraps each event in `StageEvent(stage_name, event)` so consumers know
  which pipeline stage produced each event.
- If `output_schema` is passed to the pipeline, only the final stage's output is
  validated against the schema.

## Graph Rules

- `Graph.END` is a sentinel value, not a string. Use `sentinel("END")` or equivalent.
- Entry node is set via `graph.set_entry(name)`. Execution starts there.
- Edges are added with `graph.add_edge(source, target, when=lambda state: bool)`.
  The `when` parameter is optional — omitting it creates an unconditional edge.
- Edge conditions are evaluated against the state returned by the source node.
  If no outbound edge condition matches, raise `GraphRoutingError` with the node name
  and current state.
- If the target is `Graph.END`, terminate and return the final state as `RunResult`.

### Concurrent Node Execution

- When two or more nodes have no dependency on each other (no edge between them at the
  same level), execute them concurrently via `asyncio.gather()`.
- Concurrent nodes MUST receive isolated state copies. They MUST NOT share mutable
  state references. Deep-copy state before dispatching to parallel nodes.
- Merge results from concurrent nodes back into a single state before continuing.

### Loop Detection

- Track iteration count during execution. If it exceeds `max_iterations` (default 100),
  raise `GraphLoopError` with the full `node_history` and `max_iterations` value.
- `max_iterations` is configurable per `run()` / `arun()` call.

### The `@node` Decorator

- `@node` is syntactic sugar for `graph.add_node(name, fn)`.
- The decorated function receives state and returns state.
- If `name` is not provided, use `fn.__name__`.

### `visualise()`

- `graph.visualise()` returns a Mermaid diagram string by traversing node/edge
  definitions.
- Conditional edges should be annotated with a label in the Mermaid output.
- The output is a string, not rendered — rendering is the caller's responsibility.

## Human-in-the-Loop Rules

- Configure with `graph.with_human_in_the_loop(pause_at=["node_name"], timeout=..., fallback=...)`.
- When execution reaches a node in `pause_at`, persist a full `Checkpoint` and return
  a `PausedRun` object.
- `PausedRun` exposes `resume(human_input)` and `aresume(human_input)` methods.
- `resume()` restores the checkpoint and continues execution from the paused node,
  injecting `human_input` into the state.
- Timeouts MUST be enforced server-side. If `timeout` elapses before `resume()` is
  called, either abort the run or route to the configured `fallback` node.
- The checkpoint MUST be persisted to the configured `BaseCheckpointStore` so that
  `resume()` can be called from a different process, server, or session.
- `PausedRun.resume()` MUST validate authorization in multi-tenant deployments.
  Run IDs alone are insufficient.

## AgentTeam Rules

- `AgentTeam(orchestrator="model", agents=[...], strategy="auto"|"parallel")`.
- In `"auto"` mode:
  - The orchestrator agent receives the task plus a description of each available agent
    (name, instructions, tools).
  - It returns a structured routing decision indicating which agent to delegate to.
  - The team executor dispatches to the chosen agent, collects the result, and feeds it
    back to the orchestrator for synthesis or further delegation.
- In `"parallel"` mode:
  - All agents receive the task concurrently via `asyncio.gather()`.
  - Results are aggregated into a `TeamResult`.
- `handoff(target_agent, context)` is a special tool automatically injected into each
  team agent. When called, it signals the executor to transfer control to the named
  agent with the supplied context.
- If an agent in the team fails, log the failure, notify the orchestrator, and allow
  it to route to a different agent or surface the error.
- `team.run(task)` returns `TeamResult` containing: `answer` (final synthesized answer),
  `contributions` (each agent's `RunResult`), `message_trace`, `total_cost`, and
  `total_latency_ms`.

## Checkpointing Integration

- `graph.with_checkpointing(store=...)` enables checkpoint persistence after each node.
- If no store is provided, default to `LocalCheckpointStore` (disk-based JSON in
  `.synth/checkpoints/{run_id}/`).
- `graph.resume(run_id)` loads the last checkpoint and continues from that point.
- If no checkpoint exists for the `run_id`, raise `RunNotFoundError`.
- Checkpoint data MUST be JSON-serializable. Never use pickle.
- Use atomic writes: write-to-temp-then-rename for local, transactions for Redis.

## State Schema

- `Graph(state_schema=MyPydanticModel)` optionally enforces a Pydantic model on the
  graph state. If set, validate state after each node execution.
- State schemas use Pydantic `BaseModel`, not dataclasses — this is one of the
  exceptions to the "dataclasses for internal types" rule, because state schemas are
  user-defined and benefit from Pydantic validation.
