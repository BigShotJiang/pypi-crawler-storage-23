# Repository Guidelines

## Project Structure & Module Organization
- `src/sweetagent/`: Library source code (core agent logic, IO, memory backends, middlewares).
- `tests/`: Unit tests and examples.
- `tests/djangotest/`: Django Channels demo project and templates.
- Top-level config: `pyproject.toml`, `tox.ini`, `mypy.ini`, `README.md`.

## Build, Test, and Development Commands
- `pip install -e .`: Install the package in editable mode for local development.
- `python -m unittest tests`: Run the full unit test suite.
- `python -m unittest tests.test_prompting`: Run prompt engine tests only.
- `python -m unittest tests.test_agent`: Run agent behavior tests only.
- `tox`: Run the test matrix across supported Python versions (3.9–3.13).

## Coding Style & Naming Conventions
- Language: Python 3.8+ with 4-space indentation.
- Follow PEP 8 naming: `snake_case` for functions/variables, `PascalCase` for classes.
- Type hints are encouraged for public APIs and IO/memory interfaces.
- Tooling present in dev deps: `ruff`, `mypy`, `pre-commit`. If you add config, keep it in `pyproject.toml`.

## Testing Guidelines
- Framework: `unittest` (standard library).
- File naming: `tests/test_*.py`.
- Keep tests small and focused; prefer explicit fixtures in test modules.
- When adding features, include or update tests in the relevant `tests/` module.

## Commit & Pull Request Guidelines
- Commit messages in history are short and direct (e.g., “update readme”, “added tests for middlewares”).
- Use a similar concise summary; no strict conventional-commit format is enforced.
- PRs should include:
  - A short description of the change and rationale.
  - Linked issue or context if applicable.
  - Test results (e.g., `python -m unittest tests`).
  - Screenshots only when UI in `tests/djangotest/` is affected.

## Configuration & Environment
- Optional settings are documented in `README.md` (`LLM_PROVIDER`, `LLM_MODEL`, `OPENAI_API_KEYS`).
- For Django Channels demo work, keep changes under `tests/djangotest/` isolated from core library code.
