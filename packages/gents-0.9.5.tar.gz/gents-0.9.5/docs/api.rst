API
===

.. automodule:: gents.hfcollection
   :members:

.. automodule:: gents.meta
   :members:

.. automodule:: gents.timeseries
   :members:

.. automodule:: gents.utils
   :members: