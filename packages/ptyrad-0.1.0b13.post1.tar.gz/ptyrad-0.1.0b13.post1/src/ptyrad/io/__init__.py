"""
Common file I/O and PtyRAD-specific load/save functions

"""