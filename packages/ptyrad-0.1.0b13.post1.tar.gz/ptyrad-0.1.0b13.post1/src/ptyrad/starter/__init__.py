"""
PtyRAD Starter Kit

This directory contains the templates, examples, and notebooks
copied to the user's workspace during `ptyrad init`.
"""