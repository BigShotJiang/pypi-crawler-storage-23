"""
Runtime configurations including devices, logger, random seed, and diagnostics info (i.e. system and packages) logging

"""