# __init__.py is not strictly needed since Python 3.3 for the intepreter to recognize it as a package 
# However, this is still included for clarity and for initialization purpose

__version__ = "0.1.0b13.post1" # 2026.03.01