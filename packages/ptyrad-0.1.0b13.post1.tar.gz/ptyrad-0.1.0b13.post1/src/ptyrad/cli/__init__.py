"""
Command Line Interface (CLI) of PtyRAD, including running reconstructions, checking system information, and others

"""