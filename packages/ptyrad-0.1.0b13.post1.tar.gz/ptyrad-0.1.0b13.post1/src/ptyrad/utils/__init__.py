"""
Utility functions including time parsing, affine transformation, image processing, and dev tools

"""