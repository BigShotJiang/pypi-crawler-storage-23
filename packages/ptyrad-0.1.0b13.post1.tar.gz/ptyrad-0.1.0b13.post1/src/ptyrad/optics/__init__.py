"""
Aberrations, physical constants, probe, and propagator formulation

"""