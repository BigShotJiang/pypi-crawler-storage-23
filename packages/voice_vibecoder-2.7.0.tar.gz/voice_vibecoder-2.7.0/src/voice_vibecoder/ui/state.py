"""SessionState — persists transcript and instance output across sessions.

Mirrors all writes to transcript and instance panels in memory, then
saves to <state_dir>/realtime-session.json on cleanup. On next startup,
lines are replayed into the widgets to restore the previous session.

Uses display_key (branch for code instances, display_name for sessions)
as key because instance_ids are regenerated on each startup.
"""

import json
import logging
import threading
from pathlib import Path

logger = logging.getLogger(__name__)

# Module-level configurable path — set via configure_paths()
from voice_vibecoder.app_config import _default_data_dir

STATE_PATH = _default_data_dir() / "realtime-session.json"

MAX_TRANSCRIPT_LINES = 200
MAX_INSTANCE_LINES = 500


def configure_paths(data_dir: Path) -> None:
    """Set the session state file path based on the configured data directory."""
    global STATE_PATH
    STATE_PATH = data_dir / "realtime-session.json"


class SessionState:
    """Thread-safe tracker of transcript and per-instance output lines."""

    def __init__(self) -> None:
        self._transcript: list[str] = []
        self._instances: dict[str, list[str]] = {}
        self._fullscreen_branch: str | None = None
        self._lock = threading.Lock()

    def add_transcript_line(self, line: str) -> None:
        with self._lock:
            self._transcript.append(line)
            if len(self._transcript) > MAX_TRANSCRIPT_LINES:
                self._transcript = self._transcript[-MAX_TRANSCRIPT_LINES:]

    def add_instance_line(self, branch: str, line: str) -> None:
        with self._lock:
            buf = self._instances.setdefault(branch, [])
            buf.append(line)
            if len(buf) > MAX_INSTANCE_LINES:
                self._instances[branch] = buf[-MAX_INSTANCE_LINES:]

    def remove_instance(self, branch: str) -> None:
        with self._lock:
            self._instances.pop(branch, None)

    def save(self) -> None:
        try:
            with self._lock:
                data = {
                    "transcript": list(self._transcript),
                    "instances": {k: list(v) for k, v in self._instances.items()},
                    "fullscreen_branch": self._fullscreen_branch,
                }
            STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
            STATE_PATH.write_text(json.dumps(data, indent=2))
        except Exception as e:
            logger.warning("Failed to save session state: %s", e)

    @staticmethod
    def load() -> dict:
        if not STATE_PATH.exists():
            return {}
        try:
            return json.loads(STATE_PATH.read_text())
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load session state: %s", e)
            return {}
