from pydantic import BaseModel, Field


class ConnectorPaginationOptions(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=25, ge=1, le=500)

    @property
    def page_params(self) -> tuple[int, int]:
        if self.page is not None:
            return (self.page, self.page_size)
        else:
            raise ValueError(
                "Pagination options must be set to return a page and page size",
            )


# connector constants
S3_CONNECTOR_ENDPOINT_FIELD = "endpoint"
AWS_CONNECTOR_REGION_FIELD = "region"
AWS_CONNECTOR_ACCESS_KEY_ID_FIELD = "access_key_id"
AWS_CONNECTOR_SECRET_ACCESS_KEY_FIELD = "secret_access_key"
AWS_CONNECTOR_ROLE_ARN_FIELD = "role_arn"
AWS_CONNECTOR_EXTERNAL_ID_FIELD = "external_id"
AWS_CONNECTOR_ROLE_DURATION_SECONDS_FIELD = "role_duration_seconds"
BUCKET_BASED_CONNECTOR_BUCKET_FIELD = "bucket"
GOOGLE_CONNECTOR_CREDENTIALS_FIELD = "credentials"
GOOGLE_CONNECTOR_PROJECT_ID_FIELD = "project_id"
GOOGLE_CONNECTOR_LOCATION_FIELD = "location"
SHIELD_CONNECTOR_API_KEY_FIELD = "api_key"
SHIELD_CONNECTOR_ENDPOINT_FIELD = "endpoint"
ODBC_CONNECTOR_HOST_FIELD = "host"
ODBC_CONNECTOR_PORT_FIELD = "port"
ODBC_CONNECTOR_DATABASE_FIELD = "database"
ODBC_CONNECTOR_USERNAME_FIELD = "username"
ODBC_CONNECTOR_PASSWORD_FIELD = "password"
ODBC_CONNECTOR_DRIVER_FIELD = "driver"
ODBC_CONNECTOR_TABLE_NAME_FIELD = "table_name"
ODBC_CONNECTOR_DIALECT_FIELD = "dialect"

# Snowflake connector constants
SNOWFLAKE_CONNECTOR_ACCOUNT_FIELD = "account"
SNOWFLAKE_CONNECTOR_SCHEMA_FIELD = "schema"
SNOWFLAKE_CONNECTOR_WAREHOUSE_FIELD = "warehouse"
SNOWFLAKE_CONNECTOR_ROLE_FIELD = "role"
SNOWFLAKE_CONNECTOR_AUTHENTICATOR_FIELD = "authenticator"
SNOWFLAKE_CONNECTOR_PRIVATE_KEY_FIELD = "private_key"
SNOWFLAKE_CONNECTOR_PRIVATE_KEY_PASSPHRASE_FIELD = "private_key_passphrase"

# Databricks connector constants
DATABRICKS_CONNECTOR_SERVER_HOSTNAME_FIELD = "server_hostname"
DATABRICKS_CONNECTOR_HTTP_PATH_FIELD = "http_path"
DATABRICKS_CONNECTOR_PAT_FIELD = "personal_access_token"
DATABRICKS_CONNECTOR_CLIENT_ID_FIELD = "client_id"
DATABRICKS_CONNECTOR_CLIENT_SECRET_FIELD = "client_secret"
DATABRICKS_CONNECTOR_AUTH_METHOD_FIELD = "auth_method"
DATABRICKS_CONNECTOR_IDA_RESOURCE_URI_FIELD = "ida_resource_uri"
DATABRICKS_CONNECTOR_IDA_PROVIDER_URI_FIELD = "ida_provider_uri"
DATABRICKS_CONNECTOR_C2C_AUDIENCE_URI_FIELD = "c2c_audience_uri"
DATABRICKS_CONNECTOR_C2C_TOKEN_ENDPOINT_FIELD = "c2c_token_endpoint"
DATABRICKS_CONNECTOR_C2C_AUDIENCE_HEADER_NAME_FIELD = "c2c_audience_header_name"
DATABRICKS_CONNECTOR_C2C_SUBJECT_TOKEN_TYPE_FIELD = "c2c_subject_token_type"

# dataset (connector type dependent) constants
SHIELD_DATASET_TASK_ID_FIELD = "task_id"
BUCKET_BASED_DATASET_FILE_PREFIX_FIELD = "file_prefix"
BUCKET_BASED_DATASET_FILE_SUFFIX_FIELD = "file_suffix"
BUCKET_BASED_DATASET_FILE_TYPE_FIELD = "data_file_type"
BUCKET_BASED_DATASET_TIMESTAMP_TIME_ZONE_FIELD = "timestamp_time_zone"
BIG_QUERY_DATASET_TABLE_NAME_FIELD = "table_name"
BIG_QUERY_DATASET_DATASET_ID_FIELD = "dataset_id"
DATABRICKS_DATASET_CATALOG_FIELD = "catalog"
DATABRICKS_DATASET_SCHEMA_FIELD = "schema"

# CSV configuration field constants
CSV_DELIMITER_FIELD = "csv_delimiter"
CSV_QUOTE_CHAR_FIELD = "csv_quote_char"
CSV_ESCAPE_CHAR_FIELD = "csv_escape_char"
CSV_HAS_HEADER_FIELD = "csv_has_header"
CSV_ENCODING_FIELD = "csv_encoding"
