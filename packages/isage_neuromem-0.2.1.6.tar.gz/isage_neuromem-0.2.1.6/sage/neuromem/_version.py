"""Version information for isage-neuromem."""

__version__ = "0.2.1.7"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
