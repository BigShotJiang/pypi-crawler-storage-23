::: plugboard.tune
