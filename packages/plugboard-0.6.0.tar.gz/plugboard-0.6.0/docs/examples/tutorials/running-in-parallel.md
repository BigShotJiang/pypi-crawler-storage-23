---
tags:
  - ray
---
Up until now we have running all our models in a single computational process. This is perfectly sufficient for simple models, or when your components can make use of [Python's asyncio](https://docs.python.org/3/library/asyncio.html) to avoid blocking.

As your models get larger and more computationally intensive you may benefit from running parts of the model in parallel. Plugboard integrates with the [Ray](https://docs.ray.io/) framework, allowing you to split your computation across multiple CPU cores, or even across nodes in a [Ray cluster](https://docs.ray.io/en/latest/cluster/getting-started.html).

!!! tip
    Keep in mind that parallelising a model has a cost associated with it: the communication between the different components will be slower on Ray than it is locally.
    
    For small models, or when a single component is the computational bottleneck then this overhead may not be worth it. However, when you have multiple computationally-intensive components in different branches of your `Process` then moving to Ray can give you a performance boost.

Before running this tutorial be sure to install Ray with pip, or install plugboard with its optional `ray` extra.

## Parallelising a model

For demonstration purposes we're going to use a model with two branches that containing `Sleep` components to simulate computationally intensive activity. In real scenarios these might instead be calls to simulation software or machine-learning model inference.

```mermaid
flowchart LR
    input@{ shape: rounded, label: Iterator<br>**input** } --> slow-sleep@{ shape: rounded, label: Sleep<br>**slow-sleep** }
    input@{ shape: rounded, label: Iterator<br>**input** } --> very-slow-sleep@{ shape: rounded, label: Sleep<br>**very-slow-sleep** }
    slow-sleep@{ shape: rounded, label: Sleep<br>**slow-sleep** } --> timestamper@{ shape: rounded, label: Timestamper<br>**timestamper** }
    timestamper@{ shape: rounded, label: Timestamper<br>**timestamper** } --> save-results@{ shape: rounded, label: FileWriter<br>**save-results** }
    very-slow-sleep@{ shape: rounded, label: Sleep<br>**very-slow-sleep** } --> timestamper@{ shape: rounded, label: Timestamper<br>**timestamper** }
```

### Defining the components

Let's define the various components that we need. The `Timestamper` component simply emits the current time in ISO format so that our output file will contain a record of how long each step of the model took. We can again use [`FileWriter`][plugboard.library.FileWriter] to save the output to CSV.
```python
--8<-- "examples/tutorials/004_using_ray/hello_ray.py:components"
```

1. We're using `time.sleep` here and not `asyncio.sleep` because we're deliberately blocking execution to simulate a computationally intensive component.

### Running normally in a `LocalProcess`

First we can setup the [`LocalProcess`][plugboard.process.LocalProcess] and run it as we have in previous tutorials.
```python
--8<-- "examples/tutorials/004_using_ray/hello_ray.py:local"
```

Running 20 iterations takes around 30 seconds, because each step of the model contains 1.5s of computation.

### Running in parallel using `RayProcess`

With some small changes we can make the same model run in parallel on Ray. First we change the `Process` class to [`RayProcess`][plugboard.process.RayProcess]. Then when creating the [`Connector`][plugboard.connector.Connector] objects we need to change the channel type to [`RayChannel`][plugboard.connector.RayChannel].

!!! info
    [`Channel`][plugboard.connector.Channel] objects are used by Plugboard to handle the communication between components. So far we have used [`AsyncioChannel`][plugboard.connector.AsyncioChannel], which is the best option for simple models that don't require parallelisation.

    Plugboard provides different channel classes for use in parallel environments: [`RayChannel`][plugboard.connector.RayChannel] is suitable for single and multi-host Ray environments. [`ZMQChannel`][plugboard.connector.ZMQChannel] is faster, but currently only works on a single host.

```python
--8<-- "examples/tutorials/004_using_ray/hello_ray.py:ray"
```

Now the 20 iteration model takes around 23s, because the two different `Sleep` components are being executed in parallel (20s compute time plus a little overhead).

## Using YAML config

Defining your model as a YAML config file is particularly useful when you want to use more computational resources: the config file is **portable** and lets you easily move the model to different compute environments.

Specifying the process type and channel builder type in the YAML is the only change needed to get the example above to run on Ray.
```yaml hl_lines="3-5"
--8<-- "examples/tutorials/004_using_ray/model-ray.yaml"
```

1. Tell Plugboard to use a [`RayProcess`][plugboard.process.RayProcess] instead of the default [`LocalProcess`][plugboard.process.LocalProcess].
2. Also change the connector builder to [`RayConnector`][plugboard.connector.RayConnector], which will build [`RayChannel`][plugboard.connector.RayChannel] objects when creating the `Process`.

## Specifying resource requirements

When running components on Ray, you can specify resource requirements for each component to control how Ray allocates computational resources. This is particularly useful when you have components with different resource needs (e.g., CPU-intensive vs GPU-intensive tasks) and you are running on a Ray cluster.

!!! tip
    Normally Ray will start automatically when you are using Plugboard locally. If you want to start a separate Ray instance, for example so that you can control the configuration options, you can launch it from the [CLI](https://docs.ray.io/en/latest/ray-core/starting-ray.html). For example, this command will start a Ray instance with enough resources to run the example below.

    ```sh
    uv run ray start --head --num-cpus=4 --num-gpus=1 --resources='{"custom_hardware": 5}'
    ```

### Declaring resources at component definition

The recommended way to specify resource requirements is to declare them as a class attribute when defining your component. This makes the [`Resource`][plugboard.schemas.Resource] requirements explicit and part of the component's definition:

```python
--8<-- "examples/tutorials/004_using_ray/resources_example.py:definition"
```

1. Declare resources when defining the class.

### Overriding resources at instantiation

You can also override resource requirements when creating component instances. This is useful when you want to use the same component class with different resource requirements:

```python
--8<-- "examples/tutorials/004_using_ray/resources_example.py:77:77"
```

1. Pass a [`Resource`][plugboard.schemas.Resource] object to override the CPU requirements for this component.

### Example

For example, you can specify [`Resource`][plugboard.schemas.Resource] requirements like this when defining components:

```python
--8<-- "examples/tutorials/004_using_ray/resources_example.py:resources"
```

1. Override the resource requirement on this instance.
2. Use resources specified in class definition.
3. Use default resources.

Or override them in YAML configuration:

```yaml
--8<-- "examples/tutorials/004_using_ray/resources-example.yaml:11:"
```

1. Override DataProducer to require 1 CPU (instead of the default 0.001).
2. CPUIntensiveTask already declares cpu: 2.0 at the class level, so this matches the class definition.
3. Add 512MB memory requirement to CPUIntensiveTask (extending the class-level resources).
4. Requires 0.5 CPU, specified in Kubernetes-style format (500 milli CPUs). This matches the class-level declaration.
5. Requires 1 GPU, matching the class-level declaration.
6. Add a custom resource called `custom_hardware`. This needs to be specified in the configuration of your Ray cluster to make it available.

See the [Ray documentation](https://docs.ray.io/en/latest/ray-core/scheduling/resources.html) for more information about specifying resource requirements.
