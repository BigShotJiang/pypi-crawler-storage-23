"""Smoke tests package."""
