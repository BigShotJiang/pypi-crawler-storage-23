"""Init for module"""
