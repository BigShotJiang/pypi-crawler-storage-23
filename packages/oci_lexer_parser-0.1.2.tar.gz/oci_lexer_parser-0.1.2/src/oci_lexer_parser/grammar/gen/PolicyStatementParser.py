# Generated from PolicyStatement.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,47,263,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,1,0,4,0,50,8,0,11,0,12,0,51,1,
        0,1,0,1,1,1,1,1,1,1,1,3,1,60,8,1,1,2,1,2,1,2,1,2,1,2,3,2,67,8,2,
        1,2,1,2,1,2,1,2,3,2,73,8,2,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,3,4,89,8,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,
        5,5,100,8,5,10,5,12,5,103,9,5,1,5,3,5,106,8,5,1,6,1,6,1,7,1,7,1,
        7,1,7,1,7,1,7,3,7,116,8,7,1,8,1,8,1,8,5,8,121,8,8,10,8,12,8,124,
        9,8,1,9,1,9,1,9,5,9,129,8,9,10,9,12,9,132,9,9,1,10,1,10,1,10,1,10,
        1,10,5,10,139,8,10,10,10,12,10,142,9,10,1,11,1,11,1,11,3,11,147,
        8,11,1,12,1,12,1,13,1,13,1,14,1,14,1,14,1,14,3,14,157,8,14,1,14,
        1,14,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,3,15,169,8,15,1,16,
        3,16,172,8,16,1,16,1,16,1,16,1,16,1,16,3,16,179,8,16,1,16,1,16,1,
        16,3,16,184,8,16,1,16,1,16,1,16,1,16,3,16,190,8,16,1,17,3,17,193,
        8,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,3,17,204,8,17,
        1,18,1,18,3,18,208,8,18,1,19,1,19,1,19,3,19,213,8,19,1,20,1,20,3,
        20,217,8,20,1,21,1,21,1,21,1,21,1,21,5,21,224,8,21,10,21,12,21,227,
        9,21,1,21,1,21,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,5,22,
        240,8,22,10,22,12,22,243,9,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,
        1,22,1,22,1,22,1,22,1,22,1,22,1,22,3,22,259,8,22,1,23,1,23,1,23,
        0,0,24,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,
        42,44,46,0,7,1,0,1,2,2,0,27,27,44,44,1,0,44,45,1,0,41,42,1,0,25,
        26,1,0,39,40,1,0,41,45,281,0,49,1,0,0,0,2,59,1,0,0,0,4,61,1,0,0,
        0,6,74,1,0,0,0,8,88,1,0,0,0,10,105,1,0,0,0,12,107,1,0,0,0,14,115,
        1,0,0,0,16,117,1,0,0,0,18,125,1,0,0,0,20,133,1,0,0,0,22,143,1,0,
        0,0,24,148,1,0,0,0,26,150,1,0,0,0,28,152,1,0,0,0,30,168,1,0,0,0,
        32,171,1,0,0,0,34,192,1,0,0,0,36,207,1,0,0,0,38,212,1,0,0,0,40,216,
        1,0,0,0,42,218,1,0,0,0,44,258,1,0,0,0,46,260,1,0,0,0,48,50,3,2,1,
        0,49,48,1,0,0,0,50,51,1,0,0,0,51,49,1,0,0,0,51,52,1,0,0,0,52,53,
        1,0,0,0,53,54,5,0,0,1,54,1,1,0,0,0,55,60,3,4,2,0,56,60,3,28,14,0,
        57,60,3,32,16,0,58,60,3,34,17,0,59,55,1,0,0,0,59,56,1,0,0,0,59,57,
        1,0,0,0,59,58,1,0,0,0,60,3,1,0,0,0,61,62,3,6,3,0,62,63,3,8,4,0,63,
        64,5,3,0,0,64,66,3,10,5,0,65,67,3,12,6,0,66,65,1,0,0,0,66,67,1,0,
        0,0,67,68,1,0,0,0,68,69,5,4,0,0,69,72,3,14,7,0,70,71,5,5,0,0,71,
        73,3,40,20,0,72,70,1,0,0,0,72,73,1,0,0,0,73,5,1,0,0,0,74,75,7,0,
        0,0,75,7,1,0,0,0,76,89,5,14,0,0,77,89,5,15,0,0,78,79,5,16,0,0,79,
        89,3,18,9,0,80,81,5,12,0,0,81,89,3,18,9,0,82,83,5,12,0,0,83,89,3,
        20,10,0,84,85,5,13,0,0,85,89,3,18,9,0,86,87,5,13,0,0,87,89,3,20,
        10,0,88,76,1,0,0,0,88,77,1,0,0,0,88,78,1,0,0,0,88,80,1,0,0,0,88,
        82,1,0,0,0,88,84,1,0,0,0,88,86,1,0,0,0,89,9,1,0,0,0,90,106,5,21,
        0,0,91,106,5,22,0,0,92,106,5,23,0,0,93,106,5,24,0,0,94,106,5,44,
        0,0,95,96,5,35,0,0,96,101,5,44,0,0,97,98,5,32,0,0,98,100,5,44,0,
        0,99,97,1,0,0,0,100,103,1,0,0,0,101,99,1,0,0,0,101,102,1,0,0,0,102,
        104,1,0,0,0,103,101,1,0,0,0,104,106,5,36,0,0,105,90,1,0,0,0,105,
        91,1,0,0,0,105,92,1,0,0,0,105,93,1,0,0,0,105,94,1,0,0,0,105,95,1,
        0,0,0,106,11,1,0,0,0,107,108,7,1,0,0,108,13,1,0,0,0,109,116,5,18,
        0,0,110,111,5,17,0,0,111,112,5,20,0,0,112,116,3,26,13,0,113,114,
        5,17,0,0,114,116,3,16,8,0,115,109,1,0,0,0,115,110,1,0,0,0,115,113,
        1,0,0,0,116,15,1,0,0,0,117,122,3,24,12,0,118,119,5,34,0,0,119,121,
        3,24,12,0,120,118,1,0,0,0,121,124,1,0,0,0,122,120,1,0,0,0,122,123,
        1,0,0,0,123,17,1,0,0,0,124,122,1,0,0,0,125,130,3,22,11,0,126,127,
        5,32,0,0,127,129,3,22,11,0,128,126,1,0,0,0,129,132,1,0,0,0,130,128,
        1,0,0,0,130,131,1,0,0,0,131,19,1,0,0,0,132,130,1,0,0,0,133,134,5,
        20,0,0,134,140,3,26,13,0,135,136,5,32,0,0,136,137,5,20,0,0,137,139,
        3,26,13,0,138,135,1,0,0,0,139,142,1,0,0,0,140,138,1,0,0,0,140,141,
        1,0,0,0,141,21,1,0,0,0,142,140,1,0,0,0,143,146,3,24,12,0,144,145,
        5,33,0,0,145,147,3,24,12,0,146,144,1,0,0,0,146,147,1,0,0,0,147,23,
        1,0,0,0,148,149,7,2,0,0,149,25,1,0,0,0,150,151,7,3,0,0,151,27,1,
        0,0,0,152,153,5,6,0,0,153,154,3,30,15,0,154,156,5,7,0,0,155,157,
        5,20,0,0,156,155,1,0,0,0,156,157,1,0,0,0,157,158,1,0,0,0,158,159,
        3,26,13,0,159,29,1,0,0,0,160,161,5,18,0,0,161,169,3,24,12,0,162,
        163,5,12,0,0,163,169,3,22,11,0,164,165,5,13,0,0,165,169,3,22,11,
        0,166,167,5,17,0,0,167,169,3,24,12,0,168,160,1,0,0,0,168,162,1,0,
        0,0,168,164,1,0,0,0,168,166,1,0,0,0,169,31,1,0,0,0,170,172,5,2,0,
        0,171,170,1,0,0,0,171,172,1,0,0,0,172,173,1,0,0,0,173,174,5,8,0,
        0,174,178,3,8,4,0,175,176,5,9,0,0,176,177,5,18,0,0,177,179,3,24,
        12,0,178,175,1,0,0,0,178,179,1,0,0,0,179,180,1,0,0,0,180,181,5,3,
        0,0,181,183,3,10,5,0,182,184,3,12,6,0,183,182,1,0,0,0,183,184,1,
        0,0,0,184,185,1,0,0,0,185,186,5,4,0,0,186,189,3,14,7,0,187,188,5,
        5,0,0,188,190,3,40,20,0,189,187,1,0,0,0,189,190,1,0,0,0,190,33,1,
        0,0,0,191,193,5,2,0,0,192,191,1,0,0,0,192,193,1,0,0,0,193,194,1,
        0,0,0,194,195,5,10,0,0,195,196,3,8,4,0,196,197,5,3,0,0,197,198,3,
        36,18,0,198,199,3,12,6,0,199,200,5,4,0,0,200,203,3,38,19,0,201,202,
        5,5,0,0,202,204,3,40,20,0,203,201,1,0,0,0,203,204,1,0,0,0,204,35,
        1,0,0,0,205,208,3,10,5,0,206,208,5,11,0,0,207,205,1,0,0,0,207,206,
        1,0,0,0,208,37,1,0,0,0,209,213,5,19,0,0,210,211,5,18,0,0,211,213,
        3,24,12,0,212,209,1,0,0,0,212,210,1,0,0,0,213,39,1,0,0,0,214,217,
        3,42,21,0,215,217,3,44,22,0,216,214,1,0,0,0,216,215,1,0,0,0,217,
        41,1,0,0,0,218,219,7,4,0,0,219,220,5,35,0,0,220,225,3,40,20,0,221,
        222,5,32,0,0,222,224,3,40,20,0,223,221,1,0,0,0,224,227,1,0,0,0,225,
        223,1,0,0,0,225,226,1,0,0,0,226,228,1,0,0,0,227,225,1,0,0,0,228,
        229,5,36,0,0,229,43,1,0,0,0,230,231,5,44,0,0,231,232,7,5,0,0,232,
        259,3,46,23,0,233,234,5,44,0,0,234,235,5,4,0,0,235,236,5,37,0,0,
        236,241,3,46,23,0,237,238,5,32,0,0,238,240,3,46,23,0,239,237,1,0,
        0,0,240,243,1,0,0,0,241,239,1,0,0,0,241,242,1,0,0,0,242,244,1,0,
        0,0,243,241,1,0,0,0,244,245,5,38,0,0,245,259,1,0,0,0,246,247,5,44,
        0,0,247,248,5,28,0,0,248,259,3,46,23,0,249,250,5,44,0,0,250,251,
        5,29,0,0,251,259,3,46,23,0,252,253,5,44,0,0,253,254,5,30,0,0,254,
        255,3,46,23,0,255,256,5,31,0,0,256,257,3,46,23,0,257,259,1,0,0,0,
        258,230,1,0,0,0,258,233,1,0,0,0,258,246,1,0,0,0,258,249,1,0,0,0,
        258,252,1,0,0,0,259,45,1,0,0,0,260,261,7,6,0,0,261,47,1,0,0,0,26,
        51,59,66,72,88,101,105,115,122,130,140,146,156,168,171,178,183,189,
        192,203,207,212,216,225,241,258
    ]

class PolicyStatementParser ( Parser ):

    grammarFileName = "PolicyStatement.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "','", "'/'", "':'", "'{'", "'}'", "'('", "')'", "'='", 
                     "'!='" ]

    symbolicNames = [ "<INVALID>", "ALLOW", "DENY", "TO", "IN", "WHERE", 
                      "DEFINE", "AS", "ADMIT", "OF", "ENDORSE", "ASSOCIATE", 
                      "GROUP", "DYNAMIC_GROUP", "ANY_GROUP", "ANY_USER", 
                      "SERVICE", "COMPARTMENT", "TENANCY", "ANY_TENANCY", 
                      "ID", "MANAGE", "USE", "READ", "INSPECT", "ANY", "ALL", 
                      "ALL_RESOURCES", "BEFORE", "AFTER", "BETWEEN", "AND", 
                      "COMMA", "SLASH", "COLON", "LBRACE", "RBRACE", "LPAREN", 
                      "RPAREN", "EQ", "NEQ", "OCID", "QUOTED_OCID", "PATTERN", 
                      "WORD", "QUOTED", "WS", "OTHER" ]

    RULE_statements = 0
    RULE_statement = 1
    RULE_allowStmt = 2
    RULE_effect = 3
    RULE_subject = 4
    RULE_verb = 5
    RULE_resource = 6
    RULE_location = 7
    RULE_compartmentPath = 8
    RULE_nameList = 9
    RULE_idList = 10
    RULE_qualifiedName = 11
    RULE_name = 12
    RULE_ocid = 13
    RULE_defineStmt = 14
    RULE_defineTarget = 15
    RULE_admitStmt = 16
    RULE_endorseStmt = 17
    RULE_endorseVerb = 18
    RULE_endorseScope = 19
    RULE_conditionExpr = 20
    RULE_conditionGroup = 21
    RULE_condition = 22
    RULE_condValue = 23

    ruleNames =  [ "statements", "statement", "allowStmt", "effect", "subject", 
                   "verb", "resource", "location", "compartmentPath", "nameList", 
                   "idList", "qualifiedName", "name", "ocid", "defineStmt", 
                   "defineTarget", "admitStmt", "endorseStmt", "endorseVerb", 
                   "endorseScope", "conditionExpr", "conditionGroup", "condition", 
                   "condValue" ]

    EOF = Token.EOF
    ALLOW=1
    DENY=2
    TO=3
    IN=4
    WHERE=5
    DEFINE=6
    AS=7
    ADMIT=8
    OF=9
    ENDORSE=10
    ASSOCIATE=11
    GROUP=12
    DYNAMIC_GROUP=13
    ANY_GROUP=14
    ANY_USER=15
    SERVICE=16
    COMPARTMENT=17
    TENANCY=18
    ANY_TENANCY=19
    ID=20
    MANAGE=21
    USE=22
    READ=23
    INSPECT=24
    ANY=25
    ALL=26
    ALL_RESOURCES=27
    BEFORE=28
    AFTER=29
    BETWEEN=30
    AND=31
    COMMA=32
    SLASH=33
    COLON=34
    LBRACE=35
    RBRACE=36
    LPAREN=37
    RPAREN=38
    EQ=39
    NEQ=40
    OCID=41
    QUOTED_OCID=42
    PATTERN=43
    WORD=44
    QUOTED=45
    WS=46
    OTHER=47

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class StatementsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(PolicyStatementParser.EOF, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PolicyStatementParser.StatementContext)
            else:
                return self.getTypedRuleContext(PolicyStatementParser.StatementContext,i)


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_statements

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatements" ):
                listener.enterStatements(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatements" ):
                listener.exitStatements(self)




    def statements(self):

        localctx = PolicyStatementParser.StatementsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_statements)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 49 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 48
                self.statement()
                self.state = 51 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 1350) != 0)):
                    break

            self.state = 53
            self.match(PolicyStatementParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def allowStmt(self):
            return self.getTypedRuleContext(PolicyStatementParser.AllowStmtContext,0)


        def defineStmt(self):
            return self.getTypedRuleContext(PolicyStatementParser.DefineStmtContext,0)


        def admitStmt(self):
            return self.getTypedRuleContext(PolicyStatementParser.AdmitStmtContext,0)


        def endorseStmt(self):
            return self.getTypedRuleContext(PolicyStatementParser.EndorseStmtContext,0)


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)




    def statement(self):

        localctx = PolicyStatementParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 59
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 55
                self.allowStmt()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 56
                self.defineStmt()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 57
                self.admitStmt()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 58
                self.endorseStmt()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AllowStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def effect(self):
            return self.getTypedRuleContext(PolicyStatementParser.EffectContext,0)


        def subject(self):
            return self.getTypedRuleContext(PolicyStatementParser.SubjectContext,0)


        def TO(self):
            return self.getToken(PolicyStatementParser.TO, 0)

        def verb(self):
            return self.getTypedRuleContext(PolicyStatementParser.VerbContext,0)


        def IN(self):
            return self.getToken(PolicyStatementParser.IN, 0)

        def location(self):
            return self.getTypedRuleContext(PolicyStatementParser.LocationContext,0)


        def resource(self):
            return self.getTypedRuleContext(PolicyStatementParser.ResourceContext,0)


        def WHERE(self):
            return self.getToken(PolicyStatementParser.WHERE, 0)

        def conditionExpr(self):
            return self.getTypedRuleContext(PolicyStatementParser.ConditionExprContext,0)


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_allowStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAllowStmt" ):
                listener.enterAllowStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAllowStmt" ):
                listener.exitAllowStmt(self)




    def allowStmt(self):

        localctx = PolicyStatementParser.AllowStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_allowStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 61
            self.effect()
            self.state = 62
            self.subject()
            self.state = 63
            self.match(PolicyStatementParser.TO)
            self.state = 64
            self.verb()
            self.state = 66
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27 or _la==44:
                self.state = 65
                self.resource()


            self.state = 68
            self.match(PolicyStatementParser.IN)
            self.state = 69
            self.location()
            self.state = 72
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5:
                self.state = 70
                self.match(PolicyStatementParser.WHERE)
                self.state = 71
                self.conditionExpr()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EffectContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ALLOW(self):
            return self.getToken(PolicyStatementParser.ALLOW, 0)

        def DENY(self):
            return self.getToken(PolicyStatementParser.DENY, 0)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_effect

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEffect" ):
                listener.enterEffect(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEffect" ):
                listener.exitEffect(self)




    def effect(self):

        localctx = PolicyStatementParser.EffectContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_effect)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 74
            _la = self._input.LA(1)
            if not(_la==1 or _la==2):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SubjectContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_subject

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class AnyGroupContext(SubjectContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.SubjectContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ANY_GROUP(self):
            return self.getToken(PolicyStatementParser.ANY_GROUP, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAnyGroup" ):
                listener.enterAnyGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAnyGroup" ):
                listener.exitAnyGroup(self)


    class GroupByIdContext(SubjectContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.SubjectContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def GROUP(self):
            return self.getToken(PolicyStatementParser.GROUP, 0)
        def idList(self):
            return self.getTypedRuleContext(PolicyStatementParser.IdListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroupById" ):
                listener.enterGroupById(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroupById" ):
                listener.exitGroupById(self)


    class DynGroupByNameContext(SubjectContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.SubjectContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DYNAMIC_GROUP(self):
            return self.getToken(PolicyStatementParser.DYNAMIC_GROUP, 0)
        def nameList(self):
            return self.getTypedRuleContext(PolicyStatementParser.NameListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDynGroupByName" ):
                listener.enterDynGroupByName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDynGroupByName" ):
                listener.exitDynGroupByName(self)


    class DynGroupByIdContext(SubjectContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.SubjectContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def DYNAMIC_GROUP(self):
            return self.getToken(PolicyStatementParser.DYNAMIC_GROUP, 0)
        def idList(self):
            return self.getTypedRuleContext(PolicyStatementParser.IdListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDynGroupById" ):
                listener.enterDynGroupById(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDynGroupById" ):
                listener.exitDynGroupById(self)


    class ServiceSubjectContext(SubjectContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.SubjectContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def SERVICE(self):
            return self.getToken(PolicyStatementParser.SERVICE, 0)
        def nameList(self):
            return self.getTypedRuleContext(PolicyStatementParser.NameListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterServiceSubject" ):
                listener.enterServiceSubject(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitServiceSubject" ):
                listener.exitServiceSubject(self)


    class AnyUserContext(SubjectContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.SubjectContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ANY_USER(self):
            return self.getToken(PolicyStatementParser.ANY_USER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAnyUser" ):
                listener.enterAnyUser(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAnyUser" ):
                listener.exitAnyUser(self)


    class GroupByNameContext(SubjectContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.SubjectContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def GROUP(self):
            return self.getToken(PolicyStatementParser.GROUP, 0)
        def nameList(self):
            return self.getTypedRuleContext(PolicyStatementParser.NameListContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroupByName" ):
                listener.enterGroupByName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroupByName" ):
                listener.exitGroupByName(self)



    def subject(self):

        localctx = PolicyStatementParser.SubjectContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_subject)
        try:
            self.state = 88
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                localctx = PolicyStatementParser.AnyGroupContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 76
                self.match(PolicyStatementParser.ANY_GROUP)
                pass

            elif la_ == 2:
                localctx = PolicyStatementParser.AnyUserContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 77
                self.match(PolicyStatementParser.ANY_USER)
                pass

            elif la_ == 3:
                localctx = PolicyStatementParser.ServiceSubjectContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 78
                self.match(PolicyStatementParser.SERVICE)
                self.state = 79
                self.nameList()
                pass

            elif la_ == 4:
                localctx = PolicyStatementParser.GroupByNameContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 80
                self.match(PolicyStatementParser.GROUP)
                self.state = 81
                self.nameList()
                pass

            elif la_ == 5:
                localctx = PolicyStatementParser.GroupByIdContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 82
                self.match(PolicyStatementParser.GROUP)
                self.state = 83
                self.idList()
                pass

            elif la_ == 6:
                localctx = PolicyStatementParser.DynGroupByNameContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 84
                self.match(PolicyStatementParser.DYNAMIC_GROUP)
                self.state = 85
                self.nameList()
                pass

            elif la_ == 7:
                localctx = PolicyStatementParser.DynGroupByIdContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 86
                self.match(PolicyStatementParser.DYNAMIC_GROUP)
                self.state = 87
                self.idList()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VerbContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MANAGE(self):
            return self.getToken(PolicyStatementParser.MANAGE, 0)

        def USE(self):
            return self.getToken(PolicyStatementParser.USE, 0)

        def READ(self):
            return self.getToken(PolicyStatementParser.READ, 0)

        def INSPECT(self):
            return self.getToken(PolicyStatementParser.INSPECT, 0)

        def WORD(self, i:int=None):
            if i is None:
                return self.getTokens(PolicyStatementParser.WORD)
            else:
                return self.getToken(PolicyStatementParser.WORD, i)

        def LBRACE(self):
            return self.getToken(PolicyStatementParser.LBRACE, 0)

        def RBRACE(self):
            return self.getToken(PolicyStatementParser.RBRACE, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PolicyStatementParser.COMMA)
            else:
                return self.getToken(PolicyStatementParser.COMMA, i)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_verb

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVerb" ):
                listener.enterVerb(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVerb" ):
                listener.exitVerb(self)




    def verb(self):

        localctx = PolicyStatementParser.VerbContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_verb)
        self._la = 0 # Token type
        try:
            self.state = 105
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [21]:
                self.enterOuterAlt(localctx, 1)
                self.state = 90
                self.match(PolicyStatementParser.MANAGE)
                pass
            elif token in [22]:
                self.enterOuterAlt(localctx, 2)
                self.state = 91
                self.match(PolicyStatementParser.USE)
                pass
            elif token in [23]:
                self.enterOuterAlt(localctx, 3)
                self.state = 92
                self.match(PolicyStatementParser.READ)
                pass
            elif token in [24]:
                self.enterOuterAlt(localctx, 4)
                self.state = 93
                self.match(PolicyStatementParser.INSPECT)
                pass
            elif token in [44]:
                self.enterOuterAlt(localctx, 5)
                self.state = 94
                self.match(PolicyStatementParser.WORD)
                pass
            elif token in [35]:
                self.enterOuterAlt(localctx, 6)
                self.state = 95
                self.match(PolicyStatementParser.LBRACE)
                self.state = 96
                self.match(PolicyStatementParser.WORD)
                self.state = 101
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==32:
                    self.state = 97
                    self.match(PolicyStatementParser.COMMA)
                    self.state = 98
                    self.match(PolicyStatementParser.WORD)
                    self.state = 103
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 104
                self.match(PolicyStatementParser.RBRACE)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ResourceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ALL_RESOURCES(self):
            return self.getToken(PolicyStatementParser.ALL_RESOURCES, 0)

        def WORD(self):
            return self.getToken(PolicyStatementParser.WORD, 0)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_resource

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterResource" ):
                listener.enterResource(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitResource" ):
                listener.exitResource(self)




    def resource(self):

        localctx = PolicyStatementParser.ResourceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_resource)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 107
            _la = self._input.LA(1)
            if not(_la==27 or _la==44):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LocationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_location

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class LocCompartmentNameContext(LocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.LocationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def COMPARTMENT(self):
            return self.getToken(PolicyStatementParser.COMPARTMENT, 0)
        def compartmentPath(self):
            return self.getTypedRuleContext(PolicyStatementParser.CompartmentPathContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLocCompartmentName" ):
                listener.enterLocCompartmentName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLocCompartmentName" ):
                listener.exitLocCompartmentName(self)


    class LocTenancyContext(LocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.LocationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def TENANCY(self):
            return self.getToken(PolicyStatementParser.TENANCY, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLocTenancy" ):
                listener.enterLocTenancy(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLocTenancy" ):
                listener.exitLocTenancy(self)


    class LocCompartmentIdContext(LocationContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.LocationContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def COMPARTMENT(self):
            return self.getToken(PolicyStatementParser.COMPARTMENT, 0)
        def ID(self):
            return self.getToken(PolicyStatementParser.ID, 0)
        def ocid(self):
            return self.getTypedRuleContext(PolicyStatementParser.OcidContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLocCompartmentId" ):
                listener.enterLocCompartmentId(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLocCompartmentId" ):
                listener.exitLocCompartmentId(self)



    def location(self):

        localctx = PolicyStatementParser.LocationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_location)
        try:
            self.state = 115
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                localctx = PolicyStatementParser.LocTenancyContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 109
                self.match(PolicyStatementParser.TENANCY)
                pass

            elif la_ == 2:
                localctx = PolicyStatementParser.LocCompartmentIdContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 110
                self.match(PolicyStatementParser.COMPARTMENT)
                self.state = 111
                self.match(PolicyStatementParser.ID)
                self.state = 112
                self.ocid()
                pass

            elif la_ == 3:
                localctx = PolicyStatementParser.LocCompartmentNameContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 113
                self.match(PolicyStatementParser.COMPARTMENT)
                self.state = 114
                self.compartmentPath()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CompartmentPathContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PolicyStatementParser.NameContext)
            else:
                return self.getTypedRuleContext(PolicyStatementParser.NameContext,i)


        def COLON(self, i:int=None):
            if i is None:
                return self.getTokens(PolicyStatementParser.COLON)
            else:
                return self.getToken(PolicyStatementParser.COLON, i)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_compartmentPath

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompartmentPath" ):
                listener.enterCompartmentPath(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompartmentPath" ):
                listener.exitCompartmentPath(self)




    def compartmentPath(self):

        localctx = PolicyStatementParser.CompartmentPathContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_compartmentPath)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.name()
            self.state = 122
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==34:
                self.state = 118
                self.match(PolicyStatementParser.COLON)
                self.state = 119
                self.name()
                self.state = 124
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NameListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def qualifiedName(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PolicyStatementParser.QualifiedNameContext)
            else:
                return self.getTypedRuleContext(PolicyStatementParser.QualifiedNameContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PolicyStatementParser.COMMA)
            else:
                return self.getToken(PolicyStatementParser.COMMA, i)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_nameList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNameList" ):
                listener.enterNameList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNameList" ):
                listener.exitNameList(self)




    def nameList(self):

        localctx = PolicyStatementParser.NameListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_nameList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 125
            self.qualifiedName()
            self.state = 130
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==32:
                self.state = 126
                self.match(PolicyStatementParser.COMMA)
                self.state = 127
                self.qualifiedName()
                self.state = 132
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdListContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(PolicyStatementParser.ID)
            else:
                return self.getToken(PolicyStatementParser.ID, i)

        def ocid(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PolicyStatementParser.OcidContext)
            else:
                return self.getTypedRuleContext(PolicyStatementParser.OcidContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PolicyStatementParser.COMMA)
            else:
                return self.getToken(PolicyStatementParser.COMMA, i)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_idList

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIdList" ):
                listener.enterIdList(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIdList" ):
                listener.exitIdList(self)




    def idList(self):

        localctx = PolicyStatementParser.IdListContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_idList)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self.match(PolicyStatementParser.ID)
            self.state = 134
            self.ocid()
            self.state = 140
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==32:
                self.state = 135
                self.match(PolicyStatementParser.COMMA)
                self.state = 136
                self.match(PolicyStatementParser.ID)
                self.state = 137
                self.ocid()
                self.state = 142
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class QualifiedNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def name(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PolicyStatementParser.NameContext)
            else:
                return self.getTypedRuleContext(PolicyStatementParser.NameContext,i)


        def SLASH(self):
            return self.getToken(PolicyStatementParser.SLASH, 0)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_qualifiedName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQualifiedName" ):
                listener.enterQualifiedName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQualifiedName" ):
                listener.exitQualifiedName(self)




    def qualifiedName(self):

        localctx = PolicyStatementParser.QualifiedNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_qualifiedName)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 143
            self.name()
            self.state = 146
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==33:
                self.state = 144
                self.match(PolicyStatementParser.SLASH)
                self.state = 145
                self.name()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WORD(self):
            return self.getToken(PolicyStatementParser.WORD, 0)

        def QUOTED(self):
            return self.getToken(PolicyStatementParser.QUOTED, 0)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterName" ):
                listener.enterName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitName" ):
                listener.exitName(self)




    def name(self):

        localctx = PolicyStatementParser.NameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_name)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 148
            _la = self._input.LA(1)
            if not(_la==44 or _la==45):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OcidContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OCID(self):
            return self.getToken(PolicyStatementParser.OCID, 0)

        def QUOTED_OCID(self):
            return self.getToken(PolicyStatementParser.QUOTED_OCID, 0)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_ocid

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOcid" ):
                listener.enterOcid(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOcid" ):
                listener.exitOcid(self)




    def ocid(self):

        localctx = PolicyStatementParser.OcidContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_ocid)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            _la = self._input.LA(1)
            if not(_la==41 or _la==42):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefineStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DEFINE(self):
            return self.getToken(PolicyStatementParser.DEFINE, 0)

        def defineTarget(self):
            return self.getTypedRuleContext(PolicyStatementParser.DefineTargetContext,0)


        def AS(self):
            return self.getToken(PolicyStatementParser.AS, 0)

        def ocid(self):
            return self.getTypedRuleContext(PolicyStatementParser.OcidContext,0)


        def ID(self):
            return self.getToken(PolicyStatementParser.ID, 0)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_defineStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefineStmt" ):
                listener.enterDefineStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefineStmt" ):
                listener.exitDefineStmt(self)




    def defineStmt(self):

        localctx = PolicyStatementParser.DefineStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_defineStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 152
            self.match(PolicyStatementParser.DEFINE)
            self.state = 153
            self.defineTarget()
            self.state = 154
            self.match(PolicyStatementParser.AS)
            self.state = 156
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==20:
                self.state = 155
                self.match(PolicyStatementParser.ID)


            self.state = 158
            self.ocid()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefineTargetContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TENANCY(self):
            return self.getToken(PolicyStatementParser.TENANCY, 0)

        def name(self):
            return self.getTypedRuleContext(PolicyStatementParser.NameContext,0)


        def GROUP(self):
            return self.getToken(PolicyStatementParser.GROUP, 0)

        def qualifiedName(self):
            return self.getTypedRuleContext(PolicyStatementParser.QualifiedNameContext,0)


        def DYNAMIC_GROUP(self):
            return self.getToken(PolicyStatementParser.DYNAMIC_GROUP, 0)

        def COMPARTMENT(self):
            return self.getToken(PolicyStatementParser.COMPARTMENT, 0)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_defineTarget

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefineTarget" ):
                listener.enterDefineTarget(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefineTarget" ):
                listener.exitDefineTarget(self)




    def defineTarget(self):

        localctx = PolicyStatementParser.DefineTargetContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_defineTarget)
        try:
            self.state = 168
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [18]:
                self.enterOuterAlt(localctx, 1)
                self.state = 160
                self.match(PolicyStatementParser.TENANCY)
                self.state = 161
                self.name()
                pass
            elif token in [12]:
                self.enterOuterAlt(localctx, 2)
                self.state = 162
                self.match(PolicyStatementParser.GROUP)
                self.state = 163
                self.qualifiedName()
                pass
            elif token in [13]:
                self.enterOuterAlt(localctx, 3)
                self.state = 164
                self.match(PolicyStatementParser.DYNAMIC_GROUP)
                self.state = 165
                self.qualifiedName()
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 4)
                self.state = 166
                self.match(PolicyStatementParser.COMPARTMENT)
                self.state = 167
                self.name()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdmitStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ADMIT(self):
            return self.getToken(PolicyStatementParser.ADMIT, 0)

        def subject(self):
            return self.getTypedRuleContext(PolicyStatementParser.SubjectContext,0)


        def TO(self):
            return self.getToken(PolicyStatementParser.TO, 0)

        def verb(self):
            return self.getTypedRuleContext(PolicyStatementParser.VerbContext,0)


        def IN(self):
            return self.getToken(PolicyStatementParser.IN, 0)

        def location(self):
            return self.getTypedRuleContext(PolicyStatementParser.LocationContext,0)


        def DENY(self):
            return self.getToken(PolicyStatementParser.DENY, 0)

        def OF(self):
            return self.getToken(PolicyStatementParser.OF, 0)

        def TENANCY(self):
            return self.getToken(PolicyStatementParser.TENANCY, 0)

        def name(self):
            return self.getTypedRuleContext(PolicyStatementParser.NameContext,0)


        def resource(self):
            return self.getTypedRuleContext(PolicyStatementParser.ResourceContext,0)


        def WHERE(self):
            return self.getToken(PolicyStatementParser.WHERE, 0)

        def conditionExpr(self):
            return self.getTypedRuleContext(PolicyStatementParser.ConditionExprContext,0)


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_admitStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdmitStmt" ):
                listener.enterAdmitStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdmitStmt" ):
                listener.exitAdmitStmt(self)




    def admitStmt(self):

        localctx = PolicyStatementParser.AdmitStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_admitStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 171
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==2:
                self.state = 170
                self.match(PolicyStatementParser.DENY)


            self.state = 173
            self.match(PolicyStatementParser.ADMIT)
            self.state = 174
            self.subject()
            self.state = 178
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==9:
                self.state = 175
                self.match(PolicyStatementParser.OF)
                self.state = 176
                self.match(PolicyStatementParser.TENANCY)
                self.state = 177
                self.name()


            self.state = 180
            self.match(PolicyStatementParser.TO)
            self.state = 181
            self.verb()
            self.state = 183
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27 or _la==44:
                self.state = 182
                self.resource()


            self.state = 185
            self.match(PolicyStatementParser.IN)
            self.state = 186
            self.location()
            self.state = 189
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5:
                self.state = 187
                self.match(PolicyStatementParser.WHERE)
                self.state = 188
                self.conditionExpr()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EndorseStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ENDORSE(self):
            return self.getToken(PolicyStatementParser.ENDORSE, 0)

        def subject(self):
            return self.getTypedRuleContext(PolicyStatementParser.SubjectContext,0)


        def TO(self):
            return self.getToken(PolicyStatementParser.TO, 0)

        def endorseVerb(self):
            return self.getTypedRuleContext(PolicyStatementParser.EndorseVerbContext,0)


        def resource(self):
            return self.getTypedRuleContext(PolicyStatementParser.ResourceContext,0)


        def IN(self):
            return self.getToken(PolicyStatementParser.IN, 0)

        def endorseScope(self):
            return self.getTypedRuleContext(PolicyStatementParser.EndorseScopeContext,0)


        def DENY(self):
            return self.getToken(PolicyStatementParser.DENY, 0)

        def WHERE(self):
            return self.getToken(PolicyStatementParser.WHERE, 0)

        def conditionExpr(self):
            return self.getTypedRuleContext(PolicyStatementParser.ConditionExprContext,0)


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_endorseStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEndorseStmt" ):
                listener.enterEndorseStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEndorseStmt" ):
                listener.exitEndorseStmt(self)




    def endorseStmt(self):

        localctx = PolicyStatementParser.EndorseStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_endorseStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 192
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==2:
                self.state = 191
                self.match(PolicyStatementParser.DENY)


            self.state = 194
            self.match(PolicyStatementParser.ENDORSE)
            self.state = 195
            self.subject()
            self.state = 196
            self.match(PolicyStatementParser.TO)
            self.state = 197
            self.endorseVerb()
            self.state = 198
            self.resource()
            self.state = 199
            self.match(PolicyStatementParser.IN)
            self.state = 200
            self.endorseScope()
            self.state = 203
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5:
                self.state = 201
                self.match(PolicyStatementParser.WHERE)
                self.state = 202
                self.conditionExpr()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EndorseVerbContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def verb(self):
            return self.getTypedRuleContext(PolicyStatementParser.VerbContext,0)


        def ASSOCIATE(self):
            return self.getToken(PolicyStatementParser.ASSOCIATE, 0)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_endorseVerb

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEndorseVerb" ):
                listener.enterEndorseVerb(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEndorseVerb" ):
                listener.exitEndorseVerb(self)




    def endorseVerb(self):

        localctx = PolicyStatementParser.EndorseVerbContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_endorseVerb)
        try:
            self.state = 207
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [21, 22, 23, 24, 35, 44]:
                self.enterOuterAlt(localctx, 1)
                self.state = 205
                self.verb()
                pass
            elif token in [11]:
                self.enterOuterAlt(localctx, 2)
                self.state = 206
                self.match(PolicyStatementParser.ASSOCIATE)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EndorseScopeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ANY_TENANCY(self):
            return self.getToken(PolicyStatementParser.ANY_TENANCY, 0)

        def TENANCY(self):
            return self.getToken(PolicyStatementParser.TENANCY, 0)

        def name(self):
            return self.getTypedRuleContext(PolicyStatementParser.NameContext,0)


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_endorseScope

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEndorseScope" ):
                listener.enterEndorseScope(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEndorseScope" ):
                listener.exitEndorseScope(self)




    def endorseScope(self):

        localctx = PolicyStatementParser.EndorseScopeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_endorseScope)
        try:
            self.state = 212
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [19]:
                self.enterOuterAlt(localctx, 1)
                self.state = 209
                self.match(PolicyStatementParser.ANY_TENANCY)
                pass
            elif token in [18]:
                self.enterOuterAlt(localctx, 2)
                self.state = 210
                self.match(PolicyStatementParser.TENANCY)
                self.state = 211
                self.name()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConditionExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def conditionGroup(self):
            return self.getTypedRuleContext(PolicyStatementParser.ConditionGroupContext,0)


        def condition(self):
            return self.getTypedRuleContext(PolicyStatementParser.ConditionContext,0)


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_conditionExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConditionExpr" ):
                listener.enterConditionExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConditionExpr" ):
                listener.exitConditionExpr(self)




    def conditionExpr(self):

        localctx = PolicyStatementParser.ConditionExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_conditionExpr)
        try:
            self.state = 216
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [25, 26]:
                self.enterOuterAlt(localctx, 1)
                self.state = 214
                self.conditionGroup()
                pass
            elif token in [44]:
                self.enterOuterAlt(localctx, 2)
                self.state = 215
                self.condition()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConditionGroupContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACE(self):
            return self.getToken(PolicyStatementParser.LBRACE, 0)

        def conditionExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PolicyStatementParser.ConditionExprContext)
            else:
                return self.getTypedRuleContext(PolicyStatementParser.ConditionExprContext,i)


        def RBRACE(self):
            return self.getToken(PolicyStatementParser.RBRACE, 0)

        def ANY(self):
            return self.getToken(PolicyStatementParser.ANY, 0)

        def ALL(self):
            return self.getToken(PolicyStatementParser.ALL, 0)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PolicyStatementParser.COMMA)
            else:
                return self.getToken(PolicyStatementParser.COMMA, i)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_conditionGroup

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConditionGroup" ):
                listener.enterConditionGroup(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConditionGroup" ):
                listener.exitConditionGroup(self)




    def conditionGroup(self):

        localctx = PolicyStatementParser.ConditionGroupContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_conditionGroup)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 218
            _la = self._input.LA(1)
            if not(_la==25 or _la==26):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 219
            self.match(PolicyStatementParser.LBRACE)
            self.state = 220
            self.conditionExpr()
            self.state = 225
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==32:
                self.state = 221
                self.match(PolicyStatementParser.COMMA)
                self.state = 222
                self.conditionExpr()
                self.state = 227
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 228
            self.match(PolicyStatementParser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConditionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return PolicyStatementParser.RULE_condition

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class CondInContext(ConditionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.ConditionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WORD(self):
            return self.getToken(PolicyStatementParser.WORD, 0)
        def IN(self):
            return self.getToken(PolicyStatementParser.IN, 0)
        def LPAREN(self):
            return self.getToken(PolicyStatementParser.LPAREN, 0)
        def condValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PolicyStatementParser.CondValueContext)
            else:
                return self.getTypedRuleContext(PolicyStatementParser.CondValueContext,i)

        def RPAREN(self):
            return self.getToken(PolicyStatementParser.RPAREN, 0)
        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(PolicyStatementParser.COMMA)
            else:
                return self.getToken(PolicyStatementParser.COMMA, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondIn" ):
                listener.enterCondIn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondIn" ):
                listener.exitCondIn(self)


    class CondBeforeContext(ConditionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.ConditionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WORD(self):
            return self.getToken(PolicyStatementParser.WORD, 0)
        def BEFORE(self):
            return self.getToken(PolicyStatementParser.BEFORE, 0)
        def condValue(self):
            return self.getTypedRuleContext(PolicyStatementParser.CondValueContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondBefore" ):
                listener.enterCondBefore(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondBefore" ):
                listener.exitCondBefore(self)


    class CondBetweenContext(ConditionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.ConditionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WORD(self):
            return self.getToken(PolicyStatementParser.WORD, 0)
        def BETWEEN(self):
            return self.getToken(PolicyStatementParser.BETWEEN, 0)
        def condValue(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(PolicyStatementParser.CondValueContext)
            else:
                return self.getTypedRuleContext(PolicyStatementParser.CondValueContext,i)

        def AND(self):
            return self.getToken(PolicyStatementParser.AND, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondBetween" ):
                listener.enterCondBetween(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondBetween" ):
                listener.exitCondBetween(self)


    class CondEqContext(ConditionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.ConditionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WORD(self):
            return self.getToken(PolicyStatementParser.WORD, 0)
        def condValue(self):
            return self.getTypedRuleContext(PolicyStatementParser.CondValueContext,0)

        def EQ(self):
            return self.getToken(PolicyStatementParser.EQ, 0)
        def NEQ(self):
            return self.getToken(PolicyStatementParser.NEQ, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondEq" ):
                listener.enterCondEq(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondEq" ):
                listener.exitCondEq(self)


    class CondAfterContext(ConditionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a PolicyStatementParser.ConditionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WORD(self):
            return self.getToken(PolicyStatementParser.WORD, 0)
        def AFTER(self):
            return self.getToken(PolicyStatementParser.AFTER, 0)
        def condValue(self):
            return self.getTypedRuleContext(PolicyStatementParser.CondValueContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondAfter" ):
                listener.enterCondAfter(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondAfter" ):
                listener.exitCondAfter(self)



    def condition(self):

        localctx = PolicyStatementParser.ConditionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_condition)
        self._la = 0 # Token type
        try:
            self.state = 258
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
            if la_ == 1:
                localctx = PolicyStatementParser.CondEqContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 230
                self.match(PolicyStatementParser.WORD)
                self.state = 231
                _la = self._input.LA(1)
                if not(_la==39 or _la==40):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 232
                self.condValue()
                pass

            elif la_ == 2:
                localctx = PolicyStatementParser.CondInContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 233
                self.match(PolicyStatementParser.WORD)
                self.state = 234
                self.match(PolicyStatementParser.IN)
                self.state = 235
                self.match(PolicyStatementParser.LPAREN)
                self.state = 236
                self.condValue()
                self.state = 241
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==32:
                    self.state = 237
                    self.match(PolicyStatementParser.COMMA)
                    self.state = 238
                    self.condValue()
                    self.state = 243
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 244
                self.match(PolicyStatementParser.RPAREN)
                pass

            elif la_ == 3:
                localctx = PolicyStatementParser.CondBeforeContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 246
                self.match(PolicyStatementParser.WORD)
                self.state = 247
                self.match(PolicyStatementParser.BEFORE)
                self.state = 248
                self.condValue()
                pass

            elif la_ == 4:
                localctx = PolicyStatementParser.CondAfterContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 249
                self.match(PolicyStatementParser.WORD)
                self.state = 250
                self.match(PolicyStatementParser.AFTER)
                self.state = 251
                self.condValue()
                pass

            elif la_ == 5:
                localctx = PolicyStatementParser.CondBetweenContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 252
                self.match(PolicyStatementParser.WORD)
                self.state = 253
                self.match(PolicyStatementParser.BETWEEN)
                self.state = 254
                self.condValue()
                self.state = 255
                self.match(PolicyStatementParser.AND)
                self.state = 256
                self.condValue()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CondValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTED(self):
            return self.getToken(PolicyStatementParser.QUOTED, 0)

        def QUOTED_OCID(self):
            return self.getToken(PolicyStatementParser.QUOTED_OCID, 0)

        def OCID(self):
            return self.getToken(PolicyStatementParser.OCID, 0)

        def PATTERN(self):
            return self.getToken(PolicyStatementParser.PATTERN, 0)

        def WORD(self):
            return self.getToken(PolicyStatementParser.WORD, 0)

        def getRuleIndex(self):
            return PolicyStatementParser.RULE_condValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondValue" ):
                listener.enterCondValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondValue" ):
                listener.exitCondValue(self)




    def condValue(self):

        localctx = PolicyStatementParser.CondValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_condValue)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 260
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 68169720922112) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





