# API Reference

Since `npyodbc` builds on top of `pyodbc`, this reference contains only
documentation about features introduced by `npyodbc`. Consult the [`pyodbc`
wiki](https://github.com/mkleehammer/pyodbc/wiki) for more information about
base `pyodbc` features.

::: npyodbc
