# ADK Skills

> [!WARNING]
> This feature is **experimental** and under **active development**. APIs and
> functionality are subject to change without notice.

## Overview

The ADK Skills system enables dynamic loading of agent instructions, resources,
and scripts. This allows agents to be extended with new capabilities at
runtime.
