"""Relationship types for rTisanePy.

Ports causes.R, relates.R, nests.R, interacts.R.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union

from .variables import AbstractVariable, Unit
from .comparisons import Compares


@dataclass
class Causes:
    """Directed causal relationship: cause -> effect."""
    cause: AbstractVariable
    effect: AbstractVariable
    when: Compares | None = None
    then: Compares | None = None


@dataclass
class Relates:
    """Undirected (ambiguous) relationship between lhs and rhs."""
    lhs: AbstractVariable
    rhs: AbstractVariable
    when: Compares | None = None
    then: Compares | None = None


@dataclass
class Nests:
    """Nesting: base Unit nested within group Unit."""
    base: Unit
    group: Unit


@dataclass
class Interacts:
    """Interaction annotation among variables w.r.t. a DV."""
    variables: list[AbstractVariable] = field(default_factory=list)
    dv: AbstractVariable | None = None


# ---------------------------------------------------------------------------
# Standalone constructor functions
# ---------------------------------------------------------------------------

def causes(cause: AbstractVariable, effect: AbstractVariable, *,
           when: Compares | None = None, then: Compares | None = None) -> Causes:
    """Create a causal relationship."""
    return Causes(cause=cause, effect=effect, when=when, then=then)


def relates(lhs: AbstractVariable, rhs: AbstractVariable, *,
            when: Compares | None = None, then: Compares | None = None) -> Relates:
    """Create an undirected relationship."""
    return Relates(lhs=lhs, rhs=rhs, when=when, then=then)


def nests(base: Unit, group: Unit) -> Nests:
    """Create a nesting relationship."""
    return Nests(base=base, group=group)
