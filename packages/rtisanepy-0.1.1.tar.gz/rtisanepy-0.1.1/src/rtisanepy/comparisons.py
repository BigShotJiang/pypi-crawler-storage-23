"""Comparison predicates for when/then annotations.

Ports equals.R, increases.R, decreases.R, notEquals.R.
"""

from __future__ import annotations

from dataclasses import dataclass

from .variables import AbstractVariable


@dataclass(frozen=True)
class Compares:
    """Holds a variable reference and a condition string."""
    variable: AbstractVariable
    condition: str


def equals(variable: AbstractVariable, value) -> Compares:
    """Condition: variable == value."""
    return Compares(variable=variable, condition=f"=={value}")


def not_equals(variable: AbstractVariable, value) -> Compares:
    """Condition: variable != value."""
    return Compares(variable=variable, condition=f"!={value}")


def increases(variable: AbstractVariable) -> Compares:
    """Condition: variable increases."""
    return Compares(variable=variable, condition="increases")


def decreases(variable: AbstractVariable) -> Compares:
    """Condition: variable decreases."""
    return Compares(variable=variable, condition="decreases")
