"""Tests for relationships.py and comparisons.py."""

from rtisanepy import (
    Unit, continuous, categories, counts,
    causes, relates, nests,
    equals, not_equals, increases, decreases,
)
from rtisanepy.relationships import Causes, Relates, Nests
from rtisanepy.comparisons import Compares


class TestCauses:
    def test_basic(self):
        u = Unit("s", cardinality=10)
        x = continuous(u, "X")
        y = continuous(u, "Y")
        rel = causes(x, y)
        assert isinstance(rel, Causes)
        assert rel.cause is x
        assert rel.effect is y
        assert rel.when is None
        assert rel.then is None

    def test_with_when_then(self):
        u = Unit("s", cardinality=10)
        x = categories(u, "Tutoring", cardinality=2)
        y = continuous(u, "Score")
        rel = causes(x, y, when=equals(x, "in-person"), then=increases(y))
        assert isinstance(rel.when, Compares)
        assert rel.when.condition == "==in-person"
        assert rel.then.condition == "increases"


class TestRelates:
    def test_basic(self):
        u = Unit("s", cardinality=10)
        x = continuous(u, "X")
        y = continuous(u, "Y")
        rel = relates(x, y)
        assert isinstance(rel, Relates)
        assert rel.lhs is x
        assert rel.rhs is y


class TestNests:
    def test_basic(self):
        classroom = Unit("classroom", cardinality=10)
        student = Unit("student", cardinality=100)
        rel = nests(student, classroom)
        assert isinstance(rel, Nests)
        assert rel.base is student
        assert rel.group is classroom


class TestComparisons:
    def test_equals(self):
        u = Unit("s", cardinality=10)
        x = categories(u, "Color", cardinality=3)
        c = equals(x, "red")
        assert c.condition == "==red"

    def test_not_equals(self):
        u = Unit("s", cardinality=10)
        x = categories(u, "Color", cardinality=3)
        c = not_equals(x, "red")
        assert c.condition == "!=red"

    def test_increases(self):
        u = Unit("s", cardinality=10)
        x = continuous(u, "Score")
        c = increases(x)
        assert c.condition == "increases"

    def test_decreases(self):
        u = Unit("s", cardinality=10)
        x = continuous(u, "Score")
        c = decreases(x)
        assert c.condition == "decreases"
