"""Shared routing contracts used by dex/clode entrypoints."""

GEMINI_FLASH_MODEL = "gemini-3-flash"
# gemini-3-flash is served by OpenCode Zen (api.opencode.ai), not Google Gemini
GEMINI_FLASH_PROVIDER = "zen"
