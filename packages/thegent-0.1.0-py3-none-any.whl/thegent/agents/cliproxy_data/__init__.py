"""Internal cliproxy provider/model definitions. No external config dependency."""
