"""Control plane: config service for multi-tenant thegent."""

from thegent.control_plane.server import create_app

__all__ = ["create_app"]
