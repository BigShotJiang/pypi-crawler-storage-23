"""Audit constants."""

from pathlib import Path

DEFAULT_DB_PATH = Path.home() / ".thegent" / "registry.db"
