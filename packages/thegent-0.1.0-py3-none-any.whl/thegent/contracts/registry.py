"""Contract registry: authoritative contract versioning and compatibility.

Provides single source of truth for structured output contracts across
task-tool (18-tag), Zen rich protocol, and thegent provider outputs.
"""

from dataclasses import dataclass
from typing import Any

# Contract schema version for thegent orchestration contracts
CONTRACT_SCHEMA_VERSION = "csm-v1"


@dataclass(frozen=True)
class ContractVersion:
    """A registered contract version with compatibility metadata."""

    contract_id: str
    version: str
    description: str
    compatible_with: tuple[str, ...] = ()
    deprecated: bool = False
    migration_window_end: str | None = None  # ISO date; after this, deprecated versions are rejected


# Compatibility matrix: to_version -> from_versions that can be normalized to it
_COMPATIBILITY_MATRIX: dict[str, tuple[str, ...]] = {
    "csm-v1": ("csm-v1", "task-tool-18", "zen-rich-v1"),
    "task-tool-18": ("task-tool-18",),
    "zen-rich-v1": ("zen-rich-v1",),
}


class ContractRegistry:
    """Authoritative registry of contract definitions and compatibility."""

    def __init__(self) -> None:
        self._versions: dict[str, ContractVersion] = {}
        self._register_defaults()

    def _register_defaults(self) -> None:
        self.register(
            ContractVersion(
                contract_id="csm",
                version="csm-v1",
                description="Canonical Structured Message: unified schema for task-tool 18-tag and Zen rich protocol",
                compatible_with=("task-tool-18", "zen-rich-v1"),
            )
        )
        self.register(
            ContractVersion(
                contract_id="task-tool",
                version="task-tool-18",
                description="Task-tool canonical 18-tag XML contract (snake_case)",
                compatible_with=("csm-v1",),
            )
        )
        self.register(
            ContractVersion(
                contract_id="zen",
                version="zen-rich-v1",
                description="Zen rich protocol: status, progress, actions, files, quality",
                compatible_with=("csm-v1",),
            )
        )

    def register(self, cv: ContractVersion) -> None:
        """Register a contract version."""
        key = f"{cv.contract_id}@{cv.version}"
        self._versions[key] = cv

    def get(self, contract_id: str, version: str | None = None) -> ContractVersion | None:
        """Get contract version. If version is None, returns latest for contract_id."""
        if version:
            return self._versions.get(f"{contract_id}@{version}")
        # Find latest non-deprecated for contract_id
        candidates = [v for k, v in self._versions.items() if k.startswith(f"{contract_id}@") and not v.deprecated]
        return max(candidates, key=lambda v: v.version) if candidates else None

    def is_compatible(self, from_version: str, to_version: str) -> bool:
        """Check if from_version can be normalized to to_version."""
        compat = _COMPATIBILITY_MATRIX.get(to_version, ())
        return from_version in compat or to_version == from_version

    def list_versions(self) -> list[ContractVersion]:
        """List all registered contract versions."""
        return list(self._versions.values())

    def get_compatibility_matrix(self) -> dict[str, tuple[str, ...]]:
        """Return the current compatibility matrix (WP-7002)."""
        return _COMPATIBILITY_MATRIX.copy()


class ContractNegotiator:
    """WP-7001: Negotiates contract versions between client and server."""

    def __init__(self, registry: ContractRegistry | None = None) -> None:
        self.registry = registry or get_registry()

    def negotiate(self, contract_id: str, supported_versions: list[str]) -> dict[str, Any]:
        """Negotiate best version for contract_id given supported_versions.

        Returns:
            Dict with 'version', 'status', 'reason'.
        """
        # Find matches in registry
        available = [
            v.version for v in self.registry.list_versions() if v.contract_id == contract_id and not v.deprecated
        ]

        # Find intersection, preferring highest version in supported_versions (assumed sorted desc)
        matches = [v for v in supported_versions if v in available]
        if matches:
            return {
                "version": matches[0],
                "status": "success",
                "reason": f"Negotiated {contract_id}@{matches[0]} from {len(supported_versions)} options.",
            }

        # Fallback to compatibility check
        latest = self.registry.get(contract_id)
        if latest:
            for v in supported_versions:
                if self.registry.is_compatible(v, latest.version):
                    return {
                        "version": latest.version,
                        "status": "compat_mode",
                        "reason": f"Client version {v} compatible with server {latest.version}.",
                    }

        return {
            "version": None,
            "status": "failure",
            "reason": f"No compatible version found for {contract_id}. Client: {supported_versions}, Server: {available}",
        }


@dataclass(frozen=True)
class TaskDefinition:
    """Definition of a task type and its required contract."""

    task_type: str
    contract_id: str
    required_version: str | None = None
    description: str = ""


class TaskRegistry:
    """Registry for task types and their associated contract requirements."""

    def __init__(self) -> None:
        self._tasks: dict[str, TaskDefinition] = {}
        self._register_defaults()

    def _register_defaults(self) -> None:
        self.register(
            TaskDefinition(
                task_type="coding",
                contract_id="csm",
                description="General coding tasks requiring full CSM structure",
            )
        )
        self.register(
            TaskDefinition(
                task_type="research",
                contract_id="csm",
                description="Research tasks with emphasis on evidence and summaries",
            )
        )

    def register(self, td: TaskDefinition) -> None:
        """Register a task definition."""
        self._tasks[td.task_type] = td

    def get(self, task_type: str) -> TaskDefinition | None:
        """Get task definition by type."""
        return self._tasks.get(task_type)


_registry: ContractRegistry | None = None
_task_registry: TaskRegistry | None = None


def get_registry() -> ContractRegistry:
    """Get the global contract registry (singleton)."""
    global _registry
    if _registry is None:
        _registry = ContractRegistry()
    return _registry


def get_task_registry() -> TaskRegistry:
    """Get the global task registry (singleton)."""
    global _task_registry
    if _task_registry is None:
        _task_registry = TaskRegistry()
    return _task_registry
