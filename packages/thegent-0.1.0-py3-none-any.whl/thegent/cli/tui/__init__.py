"""TUI session helpers for thegent CLI — WL-031.

Exposes:
- `ParetoTuiSession`: live data session for the Pareto Frontier TUI panel.
"""

from thegent.cli.tui.pareto import ParetoTuiSession

__all__ = ["ParetoTuiSession"]
