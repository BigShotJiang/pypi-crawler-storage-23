"""Output formatting helpers for CLI commands."""
