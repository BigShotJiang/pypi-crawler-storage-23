"""Routing module.

Re-exports key symbols from thegent.utils.routing_impl.
"""

__all__ = []
