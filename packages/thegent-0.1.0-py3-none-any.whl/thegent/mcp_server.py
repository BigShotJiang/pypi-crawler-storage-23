"""Compatibility shim for ``thegent.mcp.server`` package exports."""

from thegent.mcp.server import *  # noqa: F401,F403 -- module re-exports 150+ public APIs for backward compatibility
