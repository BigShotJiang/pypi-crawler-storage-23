"""Desktop automation providers for thegent."""

from thegent.automation.macos_desktop import AutomationError, AutomationResult, MacOSDesktopAutomation

__all__ = [
    "AutomationError",
    "AutomationResult",
    "MacOSDesktopAutomation",
]
