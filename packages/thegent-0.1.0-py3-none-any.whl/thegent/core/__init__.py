"""thegent core: shared primitives used across subsystems."""
