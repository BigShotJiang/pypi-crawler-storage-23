# API Reference

Complete auto-generated reference for all Impulso modules.

*Reference pages will be added as modules are implemented.*
