from v2simux.gui.convertbox import *


if __name__ == "__main__":
    app = ConvertBox()
    app.mainloop()