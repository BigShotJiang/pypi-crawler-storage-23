from v2simux.gui.plgbox import PlgBox


def main():
    frm = PlgBox()
    frm.mainloop()


if __name__ == "__main__":
    main()