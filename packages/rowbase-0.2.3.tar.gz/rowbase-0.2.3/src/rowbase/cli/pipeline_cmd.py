"""Pipeline commands: validate, dry-run, run, info, deploy, list."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from rowbase.cli.discovery import (
    DiscoveredPipeline,
    discover_pipelines,
    resolve_pipelines_dir,
    resolve_single_pipeline,
)
from rowbase.cli.formatters import (
    print_dag_table,
    print_error,
    print_json,
    print_run_result,
    print_success,
)

app = typer.Typer(no_args_is_help=True)

FormatOption = Annotated[
    str,
    typer.Option("--format", "-f", help="Output format: text or json"),
]

DirOption = Annotated[
    Path | None,
    typer.Option("--dir", "-d", help="Pipeline source directory (overrides rowbase.yaml)"),
]


def _parse_inputs(inputs: list[str]) -> dict[str, Path]:
    """Parse --input name=path pairs."""
    result = {}
    for inp in inputs:
        if "=" not in inp:
            print_error(f"Invalid --input format: {inp!r}. Expected name=path.")
            raise typer.Exit(code=1)
        name, path_str = inp.split("=", 1)
        result[name] = Path(path_str)
    return result


@app.command()
def validate(
    name: Annotated[str | None, typer.Argument(help="Pipeline name (validates all if omitted)")] = None,
    dir: DirOption = None,
    fmt: FormatOption = "text",
) -> None:
    """Validate pipeline(s): check imports, DAG structure, naming rules."""
    from rowbase.dag import DAG
    from rowbase.errors import RowbaseError

    if name:
        targets = {name: resolve_single_pipeline(name, dir)}
    else:
        targets = discover_pipelines(dir)

    if not targets:
        print_error("No pipelines found.")
        raise typer.Exit(code=1)

    all_results = []
    any_failed = False

    for pipeline_name, discovered in targets.items():
        try:
            spec = discovered.pipeline_fn()
            DAG.from_context(spec.context)
            errors: list[dict[str, object]] = []
        except RowbaseError as e:
            errors = [e.to_dict()]
            spec = None

        if errors:
            any_failed = True

        if fmt == "json":
            data: dict[str, object] = {
                "name": pipeline_name,
                "valid": len(errors) == 0,
                "errors": errors,
            }
            if spec:
                data["sources"] = sorted(spec.context.sources.keys())
                data["datasets"] = sorted(spec.context.datasets.keys())
                data["assets"] = sorted(spec.context.assets.keys())
                data["published"] = sorted(spec.context.published)
            all_results.append(data)
        else:
            if errors:
                for err in errors:
                    print_error(f"[{pipeline_name}] [{err['code']}] {err['message']}")
            else:
                display_name = spec.name or pipeline_name  # type: ignore[union-attr]
                print_success(f'Pipeline "{display_name}" is valid')
                ctx = spec.context  # type: ignore[union-attr]
                src_names = ", ".join(sorted(ctx.sources.keys())) or "(none)"
                ds_info = [
                    f"{n} (intermediate)" if n not in ctx.published else n
                    for n in sorted(ctx.datasets.keys())
                ]
                asset_names = ", ".join(sorted(ctx.assets.keys()))
                typer.echo(f"  Sources: {src_names}")
                typer.echo(f"  Datasets: {', '.join(ds_info)}")
                if asset_names:
                    typer.echo(f"  Assets: {asset_names}")

    if fmt == "json":
        print_json(all_results if len(all_results) > 1 else all_results[0])

    if any_failed:
        raise typer.Exit(code=1)


@app.command(name="dry-run")
def dry_run(
    name: Annotated[str, typer.Argument(help="Pipeline name")],
    dir: DirOption = None,
    inputs: Annotated[list[str] | None, typer.Option("--input", "-i")] = None,
    sample_rows: Annotated[int, typer.Option("--sample-rows")] = 5,
    output_format: Annotated[str, typer.Option("--output-format")] = "parquet",
    fmt: FormatOption = "text",
) -> None:
    """Preview a pipeline run with limited sample rows."""
    from rowbase.execution import PipelineRunner

    discovered = resolve_single_pipeline(name, dir)
    spec = discovered.pipeline_fn()
    input_map = _parse_inputs(inputs or [])

    runner = PipelineRunner()
    result = runner.run(spec, input_map, sample_rows=sample_rows, output_format=output_format)

    if fmt == "json":
        print_json(_result_to_dict(result))
    else:
        print_run_result(_result_to_dict(result))


@app.command()
def run(
    name: Annotated[str, typer.Argument(help="Pipeline name")],
    dir: DirOption = None,
    inputs: Annotated[list[str] | None, typer.Option("--input", "-i")] = None,
    output_dir: Annotated[Path | None, typer.Option("--output-dir", "-o")] = None,
    run_id: Annotated[str | None, typer.Option("--run-id")] = None,
    output_format: Annotated[str, typer.Option("--output-format")] = "parquet",
    remote: Annotated[bool, typer.Option("--remote", help="Run on the Rowbase platform instead of locally")] = False,
    fmt: FormatOption = "text",
) -> None:
    """Run a pipeline end-to-end."""
    discovered = resolve_single_pipeline(name, dir)
    input_map = _parse_inputs(inputs or [])

    if remote:
        _run_remote(discovered, input_map, fmt)
    else:
        _run_local(discovered, input_map, output_dir, run_id, output_format, fmt)


def _run_local(
    discovered: DiscoveredPipeline,
    input_map: dict[str, Path],
    output_dir: Path | None,
    run_id: str | None,
    output_format: str,
    fmt: str,
) -> None:
    from rowbase.execution import PipelineRunner

    spec = discovered.pipeline_fn()

    runner = PipelineRunner()
    result = runner.run(spec, input_map, output_dir=output_dir, run_id=run_id, output_format=output_format)

    if fmt == "json":
        print_json(_result_to_dict(result))
    else:
        print_run_result(_result_to_dict(result))
        if not result.complete:
            raise typer.Exit(code=1)


def _run_remote(discovered: DiscoveredPipeline, input_map: dict[str, Path], fmt: str) -> None:
    from rowbase.api.client import RowbaseClient
    from rowbase.cli.formatters import console
    from rowbase.errors import RowbaseError

    spec = discovered.pipeline_fn()
    pipeline_name = spec.name or discovered.name

    try:
        client = RowbaseClient()
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    try:
        pipeline_id = client.resolve_pipeline_id(pipeline_name)
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    for name, path in input_map.items():
        if not path.exists():
            print_error(f"Input file not found: {path} (source '{name}')")
            raise typer.Exit(code=1)

    console.print(f"Submitting [bold]{pipeline_name}[/bold] to Rowbase platform...")

    try:
        result = client.submit_run(pipeline_id, input_map)
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    if fmt == "json":
        print_json(result)
        return

    run_public_id = result["public_id"]
    status = result["status"]
    color = "green" if status == "success" else "yellow" if status == "partial" else "red"

    console.print(f"\nRun [bold]{run_public_id}[/bold] — [{color}]{status}[/{color}]")
    if result.get("duration_ms"):
        console.print(f"Duration: {result['duration_ms']}ms")
    if result.get("error_message"):
        print_error(result["error_message"])

    datasets = result.get("datasets", [])
    if datasets:
        from rich.table import Table

        table = Table(title="Datasets")
        table.add_column("Name", style="cyan")
        table.add_column("Rows", justify="right")
        table.add_column("Columns", justify="right")
        table.add_column("Published", justify="center")

        for ds in datasets:
            pub = "[green]\u2713[/green]" if ds.get("is_published") else ""
            table.add_row(ds["name"], str(ds["row_count"]), str(len(ds["columns"])), pub)

        console.print(table)

    console.print(f"\n[dim]View details:[/dim]  rowbase runs show -p {pipeline_id} -r {run_public_id}")
    console.print(f"[dim]Download:[/dim]      rowbase runs download -p {pipeline_id} -r {run_public_id}")

    if status == "failed":
        raise typer.Exit(code=1)


@app.command()
def info(
    name: Annotated[str, typer.Argument(help="Pipeline name")],
    dir: DirOption = None,
    fmt: FormatOption = "text",
) -> None:
    """Show pipeline structure: sources, datasets, DAG."""
    from rowbase.dag import DAG

    discovered = resolve_single_pipeline(name, dir)
    spec = discovered.pipeline_fn()
    dag = DAG.from_context(spec.context)

    if fmt == "json":
        data = {
            "name": spec.name or discovered.name,
            "sources": [
                {"name": s.name, "columns": s.columns, "description": s.description}
                for s in spec.context.sources.values()
            ],
            "datasets": [
                {
                    "name": d.name,
                    "depends_on": d.depends_on,
                    "description": d.description,
                    "has_schema": d.schema is not None,
                }
                for d in spec.context.datasets.values()
            ],
            "assets": [
                {
                    "name": a.name,
                    "depends_on": a.depends_on,
                    "content_type": a.content_type,
                    "description": a.description,
                }
                for a in spec.context.assets.values()
            ],
            "published": sorted(spec.context.published),
            "dag": dag.to_dict(),
        }
        print_json(data)
    else:
        typer.echo(f"Pipeline: {spec.name or discovered.name}")
        typer.echo()
        print_dag_table(
            sources=[{"name": s.name, "columns": s.columns} for s in spec.context.sources.values()],
            datasets=[
                {"name": d.name, "depends_on": d.depends_on} for d in spec.context.datasets.values()
            ],
            assets=[
                {"name": a.name, "depends_on": a.depends_on} for a in spec.context.assets.values()
            ],
            published=spec.context.published,
        )


@app.command(name="list")
def list_pipelines(
    fmt: FormatOption = "text",
) -> None:
    """List deployed pipelines on the platform."""
    from rowbase.api.client import RowbaseClient
    from rowbase.errors import RowbaseError

    try:
        client = RowbaseClient()
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    try:
        pipelines = client.list_pipelines()
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    if fmt == "json":
        print_json(pipelines)
        return

    if not pipelines:
        typer.echo("No pipelines deployed.")
        return

    from rich.console import Console
    from rich.table import Table

    console = Console()
    table = Table(title="Deployed Pipelines")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="bold")
    table.add_column("Version", justify="right")
    table.add_column("Updated")

    for p in pipelines:
        v = p.get("current_version", {})
        v_num = f"v{v.get('version_number', '?')}" if v else "-"
        updated = p.get("updated_at", "")[:19]
        table.add_row(p["public_id"], p["name"], v_num, updated)

    console.print(table)


@app.command()
def deploy(
    name: Annotated[str | None, typer.Argument(help="Pipeline name (deploys all if omitted)")] = None,
    dir: DirOption = None,
    description: Annotated[str | None, typer.Option("--description", "-D")] = None,
) -> None:
    """Deploy pipeline(s) to the Rowbase platform."""
    if name:
        targets = {name: resolve_single_pipeline(name, dir)}
    else:
        targets = discover_pipelines(dir)

    if not targets:
        print_error("No pipelines found.")
        raise typer.Exit(code=1)

    for discovered in targets.values():
        _deploy_single(discovered, dir, description)


def _deploy_single(
    discovered: DiscoveredPipeline,
    dir_override: Path | None,
    description: str | None,
) -> None:
    from rowbase.api.client import RowbaseClient, collect_pipeline_files
    from rowbase.errors import RowbaseError

    pipelines_dir = resolve_pipelines_dir(dir_override)
    files, entrypoint = collect_pipeline_files(discovered.path, pipelines_dir)

    try:
        client = RowbaseClient()
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    try:
        result = client.register_pipeline(
            name=discovered.name,
            files=files,
            entrypoint=entrypoint,
            description=description,
        )
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    pipe_id = result["public_id"]
    version = result.get("current_version", {})
    v_num = version.get("version_number", "?")

    bundled_count = len(files) - 1
    print_success(f'Deployed "{discovered.name}" (v{v_num})')
    typer.echo(f"  Pipeline ID:  {pipe_id}")
    typer.echo(f"  Version:      {version.get('public_id', '?')}")
    if bundled_count > 0:
        typer.echo(f"  Bundled:      {bundled_count} auxiliary files")

    try:
        info_resp = client.discover_pipeline(pipe_id)
        sources = [s["name"] for s in info_resp.get("sources", [])]
        published = info_resp.get("published", [])
        assets = [a["name"] for a in info_resp.get("assets", [])]
        typer.echo(f"  Sources:      {', '.join(sources)}")
        typer.echo(f"  Published:    {', '.join(published)}")
        if assets:
            typer.echo(f"  Assets:       {', '.join(assets)}")
    except RowbaseError:
        pass


def _result_to_dict(result) -> dict:
    """Convert a RunResult to a serializable dict."""
    from dataclasses import asdict

    return {
        "run_id": result.run_id,
        "status": result.status,
        "complete": result.complete,
        "duration_ms": result.duration_ms,
        "params": result.params,
        "datasets": {
            name: {
                "row_count": dr.row_count,
                "columns": dr.columns,
                "stdout": dr.stdout,
                "stderr": dr.stderr,
            }
            for name, dr in result.datasets.items()
        },
        "assets": {
            name: {
                "file_count": ar.file_count,
                "total_bytes": ar.total_bytes,
                "content_type": ar.content_type,
                "filenames": ar.filenames,
                "stdout": ar.stdout,
                "stderr": ar.stderr,
            }
            for name, ar in result.assets.items()
        },
        "logs": [asdict(log) for log in result.logs],
        "errors": [e.to_dict() for e in result.errors],
    }
