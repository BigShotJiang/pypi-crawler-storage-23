<h1 align="center">😮‍💨 Lazy Commits Lint</h1>
<p align="center">
<p align="center">
  Want more strict commits format?<br/>
  <i>You're welcome!</i>
</p>
