"""Step 11: First gateway run (auto-init)."""

from __future__ import annotations

import asyncio

from easyclaw_tui.steps.base import BaseStep, StepResult


class InitGatewayStep(BaseStep):
    STEP_NUM = 11
    STEP_NAME = "Init Gateway"

    async def run(self) -> StepResult:
        self.info("Running gateway for 10 seconds to auto-initialize...")
        await self.run_cmd(
            f'timeout 15 openclaw gateway --bind "{self.state.bind}" >/dev/null 2>&1 || true'
        )
        await asyncio.sleep(2)
        self.ok("Gateway auto-initialized")
        return StepResult(True)
