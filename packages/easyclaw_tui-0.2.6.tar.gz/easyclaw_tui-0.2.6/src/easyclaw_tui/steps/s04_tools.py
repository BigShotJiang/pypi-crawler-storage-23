"""Step 4: Install mcporter and clawhub."""

from __future__ import annotations

from easyclaw_tui.steps.base import BaseStep, StepResult


class ToolsStep(BaseStep):
    STEP_NUM = 4
    STEP_NAME = "Tools"

    async def run(self) -> StepResult:
        # mcporter
        if not await self.cmd_ok("command -v mcporter"):
            self.info("Installing mcporter...")
            await self.run_cmd("npm install -g mcporter 2>/dev/null")

        ver = await self.cmd_output("mcporter --version 2>/dev/null")
        self.ok(f"mcporter {ver or 'installed'}")

        # clawhub
        if not await self.cmd_ok("command -v clawhub"):
            self.info("Installing clawhub...")
            await self.run_cmd("npm install -g clawhub 2>/dev/null")

        ver = await self.cmd_output("clawhub --version 2>/dev/null")
        self.ok(f"clawhub {ver or 'installed'}")

        return StepResult(True)
