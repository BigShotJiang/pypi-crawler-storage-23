"""Wrap all 13 MCP tools for agent tool use."""

from __future__ import annotations

from typing import Optional

from easyclaw_tui.api.client import MCPClient

_client: Optional[MCPClient] = None


def init_mcp(api_key: str) -> None:
    """Initialize the MCP client with the user's API key."""
    global _client
    _client = MCPClient(api_key)


def _require_client() -> MCPClient:
    if _client is None:
        raise RuntimeError("MCP tools unavailable — no EasyClaw API key configured")
    return _client


async def _call(tool: str, args: dict) -> str:
    client = _require_client()
    result = await client.call_tool(tool, args)
    return result.get("text", result.get("error", "No response"))


async def mcp_search_knowledge(query: str) -> str:
    """Search 17+ OpenClaw guides."""
    return await _call("search_knowledge", {"query": query})


async def mcp_get_full_guide(topic: str) -> str:
    """Get a complete guide by topic."""
    return await _call("get_full_guide", {"topic": topic})


async def mcp_get_model_recommendation(use_case: str) -> str:
    """Get LLM model recommendations for a use case."""
    return await _call("get_model_recommendation", {"use_case": use_case})


async def mcp_validate_config() -> str:
    """Validate the OpenClaw configuration."""
    return await _call("validate_config", {})


async def mcp_recommend_skills(use_case: str) -> str:
    """Get skill recommendations for a use case."""
    return await _call("recommend_skills", {"use_case": use_case})


async def mcp_security_audit() -> str:
    """Run a security audit checklist."""
    return await _call("security_audit", {})


async def mcp_estimate_cost(
    model: str = "minimax-m2.5",
    daily_messages: int = 100,
) -> str:
    """Estimate costs for running OpenClaw."""
    return await _call(
        "estimate_cost",
        {"model": model, "daily_messages": daily_messages},
    )


async def mcp_generate_config(template: str = "default") -> str:
    """Generate an OpenClaw config for a use case."""
    return await _call("generate_config", {"template": template})


async def mcp_search_web(query: str, engines: str = "google") -> str:
    """Search the web via SearXNG."""
    return await _call("search_web", {"query": query, "engines": engines})


async def mcp_diagnose_issue(
    error_text: str,
    context: str = "general",
) -> str:
    """Diagnose an OpenClaw error."""
    return await _call(
        "diagnose_issue",
        {"error_text": error_text, "context": context},
    )


async def mcp_validate_deployment(os_type: str = "linux") -> str:
    """Run deployment health checklist."""
    return await _call("validate_deployment", {"os_type": os_type})


async def mcp_get_foreman_config(
    model: str = "",
    channel: str = "",
    bind: str = "",
) -> str:
    """Generate a full Foreman config."""
    args: dict = {}
    if model:
        args["model"] = model
    if channel:
        args["channel"] = channel
    if bind:
        args["bind"] = bind
    return await _call("get_foreman_config", args)


async def mcp_troubleshoot_gateway(symptom: str = "") -> str:
    """Troubleshoot gateway issues."""
    args: dict = {}
    if symptom:
        args["symptom"] = symptom
    return await _call("troubleshoot_gateway", args)
