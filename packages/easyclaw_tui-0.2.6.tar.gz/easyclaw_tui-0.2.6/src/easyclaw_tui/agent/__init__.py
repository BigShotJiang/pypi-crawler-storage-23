"""EasyClaw Foreman Agent — AI-powered OpenClaw manager."""

from __future__ import annotations

from easyclaw_tui.agent.core import ForemanAgent

__all__ = ["ForemanAgent"]
