"""Compatibility module for account client."""

from databricks_api.clients.account import AccountClient

__all__ = ["AccountClient"]
