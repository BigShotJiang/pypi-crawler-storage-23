from __future__ import annotations

import re
from importlib.resources import files

import yaml

from clawguard.types import RuleDef, Scenario


def load_default_scenarios() -> list[Scenario]:
    raw = files("clawguard").joinpath("data/scenarios.yaml").read_text(encoding="utf-8")
    items = yaml.safe_load(raw)
    out: list[Scenario] = []
    for item in items:
        out.append(
            Scenario(
                scenario_id=str(item["id"]),
                category=str(item["category"]),
                description=str(item["description"]),
                weight=float(item.get("weight", 1.0)),
                threshold=float(item.get("threshold", 0.45)),
                softness=float(item.get("softness", 0.08)),
            )
        )
    return out


def load_default_eval_cases() -> list[dict]:
    raw = files("clawguard").joinpath("data/eval_cases.yaml").read_text(encoding="utf-8")
    return list(yaml.safe_load(raw))


def default_rules() -> list[RuleDef]:
    # High-signal lexical indicators. These are additive evidence for category scores.
    return [
        RuleDef(
            "ask_for_secrets",
            "credential_exfil",
            r"\b(api[\s_-]?key|access[\s_-]?key|token|password|credential|cookie|private key)\b",
            0.30,
            re.IGNORECASE,
        ),
        RuleDef("env_access", "credential_exfil", r"(?:\.env\b|os\.environ|printenv\b|env\[[\"'])", 0.35, re.IGNORECASE),
        RuleDef("ssh_key_access", "credential_exfil", r"(?:\.ssh\b|id_rsa\b|authorized_keys\b)", 0.45, re.IGNORECASE),
        RuleDef(
            "cloud_credential_sources",
            "credential_exfil",
            r"(?:\.aws/credentials|aws_access_key_id|aws_secret_access_key|metadata\.google\.internal|169\.254\.169\.254|latest/meta-data|serviceaccount\.json|kubeconfig|\.netrc\b|\.pypirc\b|\.npmrc\b)",
            0.45,
            re.IGNORECASE,
        ),
        RuleDef(
            "private_key_material",
            "credential_exfil",
            r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----|xox[baprs]-[A-Za-z0-9-]{10,}|ghp_[A-Za-z0-9]{30,}|jwt\.pem|sign(?:ing|er)[_-]?key|id_ed25519",
            0.62,
            re.IGNORECASE,
        ),
        RuleDef(
            "external_exfil_endpoint",
            "network_exfil",
            r"\b(webhook|exfiltrat|send to .*https?://|upload to .*https?://|post to .*https?://)\b",
            0.45,
            re.IGNORECASE,
        ),
        RuleDef(
            "secret_collection_then_transfer",
            "network_exfil",
            r"\b(extract|collect|dump|read)\b[\s\S]{0,80}\b(secrets?|tokens?|credentials?|api[\s_-]?keys?|\.env)\b[\s\S]{0,140}\b(curl|wget|requests?\s*\.\s*post|https?://)\b",
            0.62,
            re.IGNORECASE,
        ),
        RuleDef(
            "python_http_exfil",
            "network_exfil",
            r"\b(requests|httpx|aiohttp)\s*\.\s*(post|put|request|get)\b[\s\S]{0,140}https?://",
            0.58,
            re.IGNORECASE,
        ),
        RuleDef("curl_wget", "network_exfil", r"\b(curl|wget|Invoke-WebRequest)\b", 0.30, re.IGNORECASE),
        RuleDef(
            "split_token_download_tools",
            "network_exfil",
            r"\bc[\W_]*u[\W_]*r[\W_]*l\b|\bw[\W_]*g[\W_]*e[\W_]*t\b|\bi[\W_]*w[\W_]*r\b",
            0.42,
            re.IGNORECASE,
        ),
        RuleDef(
            "ifs_obfuscated_download_tool",
            "network_exfil",
            r"\bc\$\{?ifs\}?url\b|\bw\$\{?ifs\}?get\b|\bi\$\{?fs\}?w\$\{?fs\}?r\b",
            0.60,
            re.IGNORECASE,
        ),
        RuleDef("external_url", "network_exfil", r"https?://[^\s)>\"]+", 0.20, re.IGNORECASE),
        RuleDef(
            "exfil_platform_destinations",
            "network_exfil",
            r"\b(discord(?:app)?\.com/api/webhooks|pastebin\.com|gist\.github\.com|transfer\.sh|file\.io|telegra\.ph|telegram\.me|api\.telegram\.org|hooks\.slack\.com/services|webhook\.office\.com|slack\.com/api/webhook)\b",
            0.50,
            re.IGNORECASE,
        ),
        RuleDef(
            "dns_exfiltration",
            "network_exfil",
            r"\b(nslookup|dig|host)\b[\s\S]{0,180}\b(exfil|chunk|base64|attacker|c2|command-and-control|\.tld)\b",
            0.55,
            re.IGNORECASE,
        ),
        RuleDef(
            "internal_target_probe",
            "network_exfil",
            r"\b(localhost|127\.0\.0\.1|0\.0\.0\.0|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3})\b",
            0.30,
            re.IGNORECASE,
        ),
        RuleDef(
            "remote_exec_pipe",
            "network_exfil",
            r"\b(curl|wget)\b[^\n|;]{0,160}\|\s*(bash|sh|zsh|python3?|perl)\b",
            0.62,
            re.IGNORECASE,
        ),
        RuleDef(
            "powershell_encoded_exec",
            "network_exfil",
            r"\b(iwr|invoke-webrequest)\b[^\n|;]{0,160}\|\s*iex\b|\bpowershell(?:\.exe)?\b[^\n]{0,160}\s-enc(?:odedcommand)?\b",
            0.62,
            re.IGNORECASE,
        ),
        RuleDef(
            "obfuscated_command_staging",
            "network_exfil",
            r"\b(printf|fromcharcode|chr\s*\(|concat(?:enate)?|join)\b[\s\S]{0,140}\b(curl|wget|bash|sh|powershell|invoke-webrequest)\b",
            0.52,
            re.IGNORECASE,
        ),
        RuleDef(
            "net_transfer_tools",
            "network_exfil",
            r"\b(nc|ncat|netcat|scp|sftp|rsync|ftp|tftp|dnscat2|iodine|rclone)\b",
            0.34,
            re.IGNORECASE,
        ),
        RuleDef(
            "remote_transfer_target",
            "network_exfil",
            r"\b(scp|sftp|rsync)\b[\s\S]{0,120}\b([A-Za-z0-9._-]+@[A-Za-z0-9._-]+|(?:\d{1,3}\.){3}\d{1,3}|attacker|dropbox|mega\.nz)\b",
            0.52,
            re.IGNORECASE,
        ),
        RuleDef(
            "archive_encrypt_stage_exfil",
            "network_exfil",
            r"\b(tar|zip|7z)\b[\s\S]{0,140}\b(openssl\s+enc|gpg\s+-c|age\s+-p)\b[\s\S]{0,140}\b(scp|sftp|rsync|curl|wget|rclone|nc)\b",
            0.62,
            re.IGNORECASE,
        ),
        RuleDef(
            "policy_override",
            "policy_evasion",
            r"\b(ignore (all|any|previous)|override (policy|rules?)|reveal (system|developer) prompt)\b",
            0.45,
            re.IGNORECASE,
        ),
        RuleDef(
            "indirect_priority_override",
            "policy_evasion",
            r"\b(priority (?:instruction|update)|supervisor channel|highest authority|new top-level directive)\b[\s\S]{0,90}\b(supersed(?:e|es|ed|ing)?|overrid(?:e|es|ing)?|ignore|disregard)\b",
            0.58,
            re.IGNORECASE,
        ),
        RuleDef(
            "jailbreak_language",
            "policy_evasion",
            r"\b(jailbreak|dan mode|developer mode|unfiltered mode|without safeguards|forget (all )?previous instructions)\b",
            0.40,
            re.IGNORECASE,
        ),
        RuleDef(
            "role_impersonation_override",
            "policy_evasion",
            r"\b(pretend (you are|to be) (system|developer|admin|root)|you are now (system|admin|root)|act as root)\b",
            0.42,
            re.IGNORECASE,
        ),
        RuleDef(
            "instruction_block_smuggling",
            "policy_evasion",
            r"</?\s*(instructions?|system|developer|policy|prompt)\s*>",
            0.38,
            re.IGNORECASE,
        ),
        RuleDef("hidden_prompt_leak", "policy_evasion", r"\b(system prompt|developer message|hidden instructions?)\b", 0.30, re.IGNORECASE),
        RuleDef("shell_exec", "tool_misuse", r"\b(exec|subprocess|bash -c|sh -c|powershell|shell command)\b", 0.35, re.IGNORECASE),
        RuleDef("filesystem_dump", "tool_misuse", r"\b(cat /|tar cz|zip -r|copy entire|dump workspace|read all files)\b", 0.40, re.IGNORECASE),
        RuleDef(
            "stealth_step_smuggling",
            "tool_misuse",
            r"\b(hidden step|without (mentioning|telling)|silently|covert(?:ly)?|stealth(?:ily)?|quietly in the background)\b[\s\S]{0,120}\b(upload|exfiltrat|send|tar|archive|shell)\b",
            0.55,
            re.IGNORECASE,
        ),
        RuleDef(
            "privilege_escalation",
            "tool_misuse",
            r"\b(sudo\s+-S|chmod\s+\+s|setuid|/etc/sudoers|runas\s+/user:administrator)\b",
            0.58,
            re.IGNORECASE,
        ),
        RuleDef(
            "log_tampering",
            "tool_misuse",
            r"\b(history\s+-c|rm\s+-rf\s+/var/log|truncate\s+-s\s+0\s+/var/log|wevtutil\s+cl)\b",
            0.48,
            re.IGNORECASE,
        ),
        RuleDef(
            "db_dump_export",
            "data_siphon",
            r"\b(pg_dump|mysqldump|mongoexport|sqlite3\s+\S+\s+\.dump)\b",
            0.46,
            re.IGNORECASE,
        ),
        RuleDef(
            "pii_or_financial_data",
            "data_siphon",
            r"\b(ssn|social security number|passport number|credit card|cvv|bank account|medical record|phi|pii|payroll)\b",
            0.42,
            re.IGNORECASE,
        ),
        RuleDef(
            "mass_customer_export",
            "data_siphon",
            r"\b(export|dump|copy|download)\b[\s\S]{0,80}\b(customers?|contacts?|emails?|invoices?|crm|ticket history)\b",
            0.44,
            re.IGNORECASE,
        ),
        RuleDef("persistence", "persistence", r"\b(cron|systemd|launchd|startup task|scheduled task|autostart)\b", 0.55, re.IGNORECASE),
        RuleDef(
            "startup_modification",
            "persistence",
            r"\b(\.bashrc|\.zshrc|/etc/rc\.local|launchctl load|systemctl enable|reg add .*\\run|schtasks /create)\b",
            0.52,
            re.IGNORECASE,
        ),
        RuleDef(
            "beaconing_language",
            "persistence",
            r"\b(beacon|heartbeat)\b[\s\S]{0,40}\b(every minute|every 30 seconds|periodic|persist)\b",
            0.46,
            re.IGNORECASE,
        ),
        RuleDef("obfuscated_blob", "obfuscation", r"\b[A-Za-z0-9+/]{160,}={0,2}\b", 0.20, 0),
        RuleDef(
            "encoded_execution",
            "obfuscation",
            r"\b(base64\s+-d|base64 --decode|frombase64string|xxd -r -p|certutil -decode|openssl enc -d|atob\(|fromcharcode)\b",
            0.36,
            re.IGNORECASE,
        ),
    ]
