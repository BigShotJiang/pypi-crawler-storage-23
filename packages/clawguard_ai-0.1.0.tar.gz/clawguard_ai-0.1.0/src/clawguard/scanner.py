from __future__ import annotations

import math
import re
from collections import defaultdict
from dataclasses import dataclass

import numpy as np

from clawguard.embeddings import build_backend
from clawguard.resources import default_rules, load_default_scenarios
from clawguard.types import Finding, RuleHit, ScanResult, Severity


def _sigmoid(x: float) -> float:
    # Stable enough for our score ranges.
    if x > 18:
        return 0.999999
    if x < -18:
        return 0.000001
    return 1.0 / (1.0 + math.exp(-x))


def _normalize_text(text: str) -> str:
    # Map common homoglyphs used to hide dangerous tool names (e.g. Cyrillic "сurl").
    confusable_map = str.maketrans(
        {
            "а": "a",
            "е": "e",
            "о": "o",
            "р": "p",
            "с": "c",
            "у": "y",
            "х": "x",
            "і": "i",
            "ј": "j",
            "А": "A",
            "Е": "E",
            "О": "O",
            "Р": "P",
            "С": "C",
            "У": "Y",
            "Х": "X",
            "І": "I",
            "Ј": "J",
        }
    )
    text = text.translate(confusable_map)
    # Strip zero-width chars commonly used for obfuscation.
    text = re.sub(r"[\u200b-\u200f\ufeff]", "", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return text


def _has_defensive_context(text: str) -> bool:
    return bool(
        re.search(
            r"\b(policy|documentation|docs?|tutorial|example|training|drill|audit|hardening|prevent|mitigate|block|remove unauthorized|incident response)\b",
            text,
            flags=re.IGNORECASE,
        )
    )


def _has_overt_malicious_intent(text: str) -> bool:
    return bool(
        re.search(
            r"\b(steal|covert(?:ly)?|hidden step|silently|backdoor|payload|bypass|override safeguards|ignore previous|without telling)\b",
            text,
            flags=re.IGNORECASE,
        )
    )


def chunk_text(text: str, max_chars: int = 1400) -> list[str]:
    text = _normalize_text(text)
    # Split on headings or blank lines.
    parts = re.split(r"\n\s*\n|(?=^#{1,6}\s)", text, flags=re.MULTILINE)
    parts = [p.strip() for p in parts if p and p.strip()]
    if not parts:
        return []
    out: list[str] = []
    buf = ""
    for p in parts:
        if not buf:
            buf = p
            continue
        if len(buf) + 2 + len(p) <= max_chars:
            buf += "\n\n" + p
            continue
        out.append(buf)
        buf = p
    if buf:
        out.append(buf)
    return out


def cosine_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    if a.size == 0 or b.size == 0:
        return np.zeros((a.shape[0], b.shape[0]), dtype=np.float32)
    a_n = a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-12)
    b_n = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-12)
    return a_n @ b_n.T


def _severity_from_risk(r: float) -> Severity:
    if r >= 0.90:
        return Severity.critical
    if r >= 0.75:
        return Severity.high
    if r >= 0.45:
        return Severity.moderate
    if r >= 0.20:
        return Severity.low
    return Severity.minimal


@dataclass
class ScanConfig:
    model: str = "minilm"
    semantic_top_k: int = 3
    semantic_min_evidence: float = 0.35
    reject_at: Severity = Severity.high


class ClawGuardScanner:
    def __init__(self, config: ScanConfig | None = None):
        self.config = config or ScanConfig()
        # jina-v3 tends to produce broader semantic matches, so use a stricter
        # default evidence floor unless the caller explicitly set a higher value.
        model_key = self.config.model.strip().lower()
        if (model_key == "jina-v3" or model_key.startswith("jinaai/jina-embeddings-v3")) and self.config.semantic_min_evidence <= 0.35:
            self.config.semantic_min_evidence = 0.45
        self.backend = build_backend(self.config.model)
        self.scenarios = load_default_scenarios()
        self.rules = default_rules()
        self._scenario_embeddings = self.backend.encode([s.description for s in self.scenarios])

    def scan_text(self, text: str, *, target: str = "<inline>") -> ScanResult:
        chunks = chunk_text(text)
        chunks_for_embedding = chunks or [_normalize_text(text)]
        chunk_embeddings = self.backend.encode(chunks_for_embedding)
        sims = cosine_matrix(chunk_embeddings, self._scenario_embeddings)

        cat_scores: dict[str, float] = defaultdict(float)
        findings: list[Finding] = []
        rule_hits: list[RuleHit] = []

        # Semantic evidence per scenario.
        for s_idx, scenario in enumerate(self.scenarios):
            col = sims[:, s_idx]
            if col.size == 0:
                continue
            idxs = np.argsort(-col)[: self.config.semantic_top_k]
            for c_idx in idxs:
                sim = float(col[c_idx])
                ev = _sigmoid((sim - scenario.threshold) / max(scenario.softness, 1e-6))
                if ev < self.config.semantic_min_evidence:
                    continue
                contrib = max(0.0, min(0.96, scenario.weight * ev))
                prev = cat_scores[scenario.category]
                # Monotone noisy-OR update.
                cat_scores[scenario.category] = 1.0 - ((1.0 - prev) * (1.0 - contrib))
                findings.append(
                    Finding(
                        scenario_id=scenario.scenario_id,
                        category=scenario.category,
                        similarity=sim,
                        evidence=ev,
                        weight=scenario.weight,
                        chunk_snippet=chunks_for_embedding[c_idx][:280],
                    )
                )

        # Lexical/rule evidence per category.
        norm = _normalize_text(text)
        # Zero-width characters are frequently used as obfuscation primitives.
        if re.search(r"[\u200b-\u200f\ufeff]", text):
            prev = cat_scores["obfuscation"]
            cat_scores["obfuscation"] = 1.0 - ((1.0 - prev) * (1.0 - 0.28))
            rule_hits.append(
                RuleHit(
                    rule_id="zero_width_obfuscation",
                    category="obfuscation",
                    weight=0.28,
                    excerpt="contains zero-width unicode characters",
                )
            )
        for rule in self.rules:
            rx = re.compile(rule.pattern, flags=rule.flags)
            m = rx.search(norm)
            if not m:
                continue
            prev = cat_scores[rule.category]
            cat_scores[rule.category] = 1.0 - ((1.0 - prev) * (1.0 - min(rule.weight, 0.96)))
            start = max(0, m.start() - 32)
            end = min(len(norm), m.end() + 72)
            excerpt = norm[start:end].replace("\n", " ")
            rule_hits.append(RuleHit(rule_id=rule.rule_id, category=rule.category, weight=rule.weight, excerpt=excerpt))

        # Promote high-confidence lexical evidence so obviously dangerous
        # signatures don't stay below reject thresholds due sparse context.
        self._apply_high_confidence_rule_promotions(cat_scores, rule_hits)

        # Reduce semantic-only false positives when prompt explicitly constrains behavior.
        self._apply_safe_intent_adjustments(cat_scores, norm, rule_hits)

        # Interaction boosts (capability combinations).
        conservative_mode = _has_defensive_context(norm) and not _has_overt_malicious_intent(norm)
        self._apply_interactions(cat_scores, conservative_mode=conservative_mode)

        # Global risk as noisy-OR across category scores.
        risk = 0.0
        for _, cscore in cat_scores.items():
            risk = 1.0 - ((1.0 - risk) * (1.0 - max(0.0, min(cscore, 1.0))))

        severity = _severity_from_risk(risk)
        reject = severity >= self.config.reject_at
        findings.sort(key=lambda x: x.evidence * x.weight, reverse=True)
        return ScanResult(
            target=target,
            risk=risk,
            severity=severity,
            reject=reject,
            category_scores=dict(sorted(cat_scores.items(), key=lambda kv: kv[1], reverse=True)),
            findings=findings[:40],
            rule_hits=rule_hits,
        )

    @staticmethod
    def _apply_safe_intent_adjustments(
        cat_scores: dict[str, float], text: str, rule_hits: list[RuleHit]
    ) -> None:
        has_non_persistence_hard = any(
            (r.category in {"credential_exfil", "network_exfil", "policy_evasion"} and r.weight >= 0.30)
            or (r.category in {"tool_misuse", "data_siphon"} and r.weight >= 0.40)
            for r in rule_hits
        )
        has_persistence_hard = any(r.category == "persistence" and r.weight >= 0.40 for r in rule_hits)
        has_hard_rule_hit = has_non_persistence_hard or has_persistence_hard

        # If persistence only came from semantic similarity, cap it unless supported by lexical evidence.
        has_persistence_lexical_hit = any(r.category == "persistence" for r in rule_hits)
        if not has_persistence_lexical_hit and "persistence" in cat_scores:
            cat_scores["persistence"] = min(cat_scores["persistence"], 0.35)

        safety_patterns = [
            r"\bdo not\b[\s\S]{0,30}\b(transmit|send|upload|share|exfiltrat|expose|leak|execute)\b",
            r"\b(do not|never|without)\s+(export|dump|copy|download)\b",
            r"\b(do not access external services|no external services|no outbound network|do not call external endpoints?)\b",
            r"\b(never\s+exfiltrat|do not collect secrets|keep all data local|for defensive testing only)\b",
            r"\b(non[-\s]?secret|non[-\s]?sensitive|redact(?:ed)? secrets?)\b",
            r"\b(approved internal (?:infrastructure|network|systems?)|internal security review)\b",
        ]
        safety_signals = sum(1 for pat in safety_patterns if re.search(pat, text, flags=re.IGNORECASE))
        defensive_context = _has_defensive_context(text)
        overt_malicious_intent = _has_overt_malicious_intent(text)
        educational_obfuscation_context = bool(
            re.search(
                r"\b(training note|attackers may use|for detection|detect and block|block this pattern|do not execute)\b",
                text,
                flags=re.IGNORECASE,
            )
        )
        persistence_mitigation = bool(
            re.search(
                r"\b(audit|harden|remove|disable|block|prevent)\b[\s\S]{0,60}\b(cron|startup|autostart|persistence|backdoor|scheduled task|launchd|systemd)\b",
                text,
                flags=re.IGNORECASE,
            )
        )
        if persistence_mitigation and has_persistence_hard and not has_non_persistence_hard:
            cat_scores["persistence"] = min(cat_scores.get("persistence", 0.0), 0.28)
            has_hard_rule_hit = False

        # Do not dampen explicit malicious cues.
        if has_hard_rule_hit and not (defensive_context and safety_signals >= 1 and not overt_malicious_intent):
            return

        if safety_signals <= 0 and not defensive_context:
            return

        damp_factor = 0.70 if safety_signals == 1 else 0.45
        if defensive_context and safety_signals == 0:
            damp_factor = 0.75
        for category in ("credential_exfil", "network_exfil", "policy_evasion", "persistence", "data_siphon", "obfuscation"):
            if category in cat_scores:
                cat_scores[category] *= damp_factor

        if educational_obfuscation_context and defensive_context and not overt_malicious_intent:
            for category, cap in {
                "network_exfil": 0.34,
                "obfuscation": 0.34,
                "credential_exfil": 0.34,
                "policy_evasion": 0.30,
                "tool_misuse": 0.30,
            }.items():
                if category in cat_scores:
                    cat_scores[category] = min(cat_scores[category], cap)

    @staticmethod
    def _apply_high_confidence_rule_promotions(cat_scores: dict[str, float], rule_hits: list[RuleHit]) -> None:
        for hit in rule_hits:
            if hit.category not in {"credential_exfil", "network_exfil", "policy_evasion", "tool_misuse", "data_siphon", "persistence"}:
                continue
            if hit.weight >= 0.60:
                cat_scores[hit.category] = max(cat_scores.get(hit.category, 0.0), 0.76)
                continue
            if hit.weight >= 0.50:
                cat_scores[hit.category] = max(cat_scores.get(hit.category, 0.0), 0.76)
                continue
            if hit.weight >= 0.45:
                cat_scores[hit.category] = max(cat_scores.get(hit.category, 0.0), 0.60)

    @staticmethod
    def _apply_interactions(cat_scores: dict[str, float], *, conservative_mode: bool = False) -> None:
        def bump(cat: str, amount: float) -> None:
            prev = cat_scores.get(cat, 0.0)
            cat_scores[cat] = max(prev, min(1.0, prev + amount))

        # Credentials + network exfiltration is extremely high risk.
        if cat_scores.get("credential_exfil", 0.0) > 0.25 and cat_scores.get("network_exfil", 0.0) > 0.25:
            bump("credential_exfil", 0.24)
            bump("network_exfil", 0.24)
        # Policy evasion + tool misuse => likely prompt injection attempt.
        if (not conservative_mode) and cat_scores.get("policy_evasion", 0.0) > 0.35 and cat_scores.get("tool_misuse", 0.0) > 0.35:
            bump("policy_evasion", 0.15)
            bump("tool_misuse", 0.15)
        # Policy evasion paired with exfil or credential collection is highly suspicious.
        if (not conservative_mode) and cat_scores.get("policy_evasion", 0.0) > 0.25 and (
            cat_scores.get("network_exfil", 0.0) > 0.20 or cat_scores.get("credential_exfil", 0.0) > 0.20
        ):
            bump("policy_evasion", 0.20)
            bump("network_exfil", 0.12)
            bump("credential_exfil", 0.12)
        # Data siphon + exfiltration channel strongly indicates malicious export intent.
        if (not conservative_mode) and cat_scores.get("data_siphon", 0.0) > 0.20 and cat_scores.get("network_exfil", 0.0) > 0.20:
            bump("data_siphon", 0.22)
            bump("network_exfil", 0.22)
        # Tool misuse with outbound transfer/remote execution is strongly malicious.
        if (not conservative_mode) and cat_scores.get("tool_misuse", 0.0) > 0.30 and cat_scores.get("network_exfil", 0.0) > 0.25:
            bump("tool_misuse", 0.20)
            bump("network_exfil", 0.20)
        # Obfuscation plus execution/exfil signal indicates likely payload staging.
        if (not conservative_mode) and cat_scores.get("obfuscation", 0.0) > 0.30 and (
            cat_scores.get("tool_misuse", 0.0) > 0.25 or cat_scores.get("network_exfil", 0.0) > 0.25
        ):
            bump("obfuscation", 0.15)
            bump("tool_misuse", 0.10)
            bump("network_exfil", 0.10)
        # Persistence always should elevate severity.
        if cat_scores.get("persistence", 0.0) > 0.25:
            bump("persistence", 0.25)
        # Persistent external beaconing should be treated as critical-class risk.
        if cat_scores.get("persistence", 0.0) > 0.55 and cat_scores.get("network_exfil", 0.0) > 0.35:
            bump("persistence", 0.25)
            bump("network_exfil", 0.25)
