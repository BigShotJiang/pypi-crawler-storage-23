from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
import re
import shutil

import numpy as np


MODEL_ALIASES: dict[str, str] = {
    "minilm": "sentence-transformers/all-MiniLM-L6-v2",
    "jina-v3": "jinaai/jina-embeddings-v3",
}

_JINA_V3_MODEL_PREFIX = "jinaai/jina-embeddings-v3"
_JINA_FLASH_REPO = "jinaai/xlm-roberta-flash-implementation"
_JINA_FLASH_MODULE_DIR = "xlm_hyphen_roberta_hyphen_flash_hyphen_implementation"
_JINA_FLASH_REQUIRED_FILES = (
    "__init__.py",
    "block.py",
    "configuration_xlm_roberta.py",
    "embedding.py",
    "mha.py",
    "mlp.py",
    "modeling_lora.py",
    "modeling_xlm_roberta.py",
    "rotary.py",
    "stochastic_depth.py",
    "xlm_padding.py",
)


class EmbeddingBackend(Protocol):
    model_id: str

    def encode(self, texts: list[str]) -> np.ndarray:
        ...


@dataclass
class SentenceTransformerBackend:
    """
    First run downloads model weights into local cache.
    Models are not bundled with clawguard.
    """

    model_id: str
    trust_remote_code: bool = False

    def __post_init__(self) -> None:
        from sentence_transformers import SentenceTransformer  # lazy import

        try:
            self._model = SentenceTransformer(self.model_id, trust_remote_code=self.trust_remote_code)
        except FileNotFoundError as exc:
            if self._is_jina_v3():
                self._repair_jina_dynamic_module_cache(str(exc))
                self._model = SentenceTransformer(self.model_id, trust_remote_code=self.trust_remote_code)
            else:
                raise
        except ImportError as exc:
            if self._is_jina_v3():
                msg = (
                    "Failed to initialize jina-v3 embedding backend. "
                    "Ensure required extras are installed (for example: einops)."
                )
                raise RuntimeError(msg) from exc
            raise

    def encode(self, texts: list[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, 1), dtype=np.float32)
        vec = self._model.encode(texts, normalize_embeddings=True)
        return np.asarray(vec, dtype=np.float32)

    def _is_jina_v3(self) -> bool:
        return self.model_id.startswith(_JINA_V3_MODEL_PREFIX)

    def _repair_jina_dynamic_module_cache(self, error_text: str) -> None:
        """
        Work around an upstream Transformers dynamic module cache issue where
        some files in jinaai/xlm-roberta-flash-implementation are missing.
        """
        from huggingface_hub import hf_hub_download

        module_dirs: list[Path] = []
        # Prefer the failing path if present in the exception.
        match = re.search(
            r"'([^']*xlm_hyphen_roberta_hyphen_flash_hyphen_implementation[^']*)'",
            error_text,
        )
        if match:
            module_dirs.append(Path(match.group(1)).parent)

        base = (
            Path.home()
            / ".cache"
            / "huggingface"
            / "modules"
            / "transformers_modules"
            / "jinaai"
            / _JINA_FLASH_MODULE_DIR
        )
        if base.exists():
            module_dirs.extend([p for p in base.iterdir() if p.is_dir()])

        # Deduplicate while preserving order.
        unique_dirs: list[Path] = []
        seen: set[str] = set()
        for d in module_dirs:
            key = str(d.resolve()) if d.exists() else str(d)
            if key in seen:
                continue
            seen.add(key)
            unique_dirs.append(d)

        if not unique_dirs:
            return

        for module_dir in unique_dirs:
            module_dir.mkdir(parents=True, exist_ok=True)
            revision = module_dir.name
            for filename in _JINA_FLASH_REQUIRED_FILES:
                target = module_dir / filename
                if target.exists():
                    continue
                try:
                    src = hf_hub_download(
                        repo_id=_JINA_FLASH_REPO,
                        filename=filename,
                        revision=revision,
                    )
                except Exception:
                    src = hf_hub_download(
                        repo_id=_JINA_FLASH_REPO,
                        filename=filename,
                    )
                if Path(src).resolve() != target.resolve():
                    shutil.copyfile(src, target)


def resolve_model_id(model: str) -> str:
    key = model.strip()
    return MODEL_ALIASES.get(key, key)


def build_backend(model: str) -> EmbeddingBackend:
    model_id = resolve_model_id(model)
    trust_remote_code = model.strip() == "jina-v3" or model_id.startswith("jinaai/")
    return SentenceTransformerBackend(model_id=model_id, trust_remote_code=trust_remote_code)
