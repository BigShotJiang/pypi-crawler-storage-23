from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any


class Severity(IntEnum):
    minimal = 0
    low = 1
    moderate = 2
    high = 3
    critical = 4

    @classmethod
    def parse(cls, value: str) -> "Severity":
        v = value.strip().lower()
        try:
            return cls[v]
        except Exception as exc:  # pragma: no cover - defensive
            raise ValueError(f"invalid severity: {value}") from exc


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    category: str
    description: str
    weight: float = 1.0
    threshold: float = 0.45
    softness: float = 0.08


@dataclass(frozen=True)
class RuleDef:
    rule_id: str
    category: str
    pattern: str
    weight: float
    flags: int = 0


@dataclass(frozen=True)
class Finding:
    scenario_id: str
    category: str
    similarity: float
    evidence: float
    weight: float
    chunk_snippet: str


@dataclass(frozen=True)
class RuleHit:
    rule_id: str
    category: str
    weight: float
    excerpt: str


@dataclass(frozen=True)
class ScanResult:
    target: str
    risk: float
    severity: Severity
    reject: bool
    category_scores: dict[str, float]
    findings: list[Finding]
    rule_hits: list[RuleHit]

    def as_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "risk": round(float(self.risk), 6),
            "severity": self.severity.name,
            "reject": bool(self.reject),
            "category_scores": {k: round(float(v), 6) for k, v in self.category_scores.items()},
            "findings": [
                {
                    "scenario_id": f.scenario_id,
                    "category": f.category,
                    "similarity": round(float(f.similarity), 6),
                    "evidence": round(float(f.evidence), 6),
                    "weight": float(f.weight),
                    "chunk_snippet": f.chunk_snippet,
                }
                for f in self.findings
            ],
            "rule_hits": [
                {
                    "rule_id": r.rule_id,
                    "category": r.category,
                    "weight": float(r.weight),
                    "excerpt": r.excerpt,
                }
                for r in self.rule_hits
            ],
        }

