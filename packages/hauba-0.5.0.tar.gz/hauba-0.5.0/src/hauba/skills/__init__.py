"""Hauba skill system — pluggable .md skill files for domain-specific intelligence."""
