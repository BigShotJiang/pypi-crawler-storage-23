"""Hauba daemon — background agent that polls server for queued tasks."""

from __future__ import annotations
