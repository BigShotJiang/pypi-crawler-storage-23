"""Hauba channels — voice, Telegram, Discord, Web, and gateway."""

from __future__ import annotations
