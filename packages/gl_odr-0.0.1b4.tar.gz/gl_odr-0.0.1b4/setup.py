"""Setup script for GLLM Modules."""

from setuptools import setup

if __name__ == "__main__":
    setup(
        build_with_nuitka=True,
        name="-binary",
        version="0.0.1b4",
    )
