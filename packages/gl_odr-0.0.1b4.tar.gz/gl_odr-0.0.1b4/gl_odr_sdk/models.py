"""Data models for the GL Deep Research Python client.

This module contains Pydantic models for request and response data structures
used in the GL Deep Research Python client library.

Authors:
    Sahat Nicholas Simangunsong (sahat.n.simangunsong@gdplabs.id)

References:
    https://gdplabs.gitbook.io/gl-deepresearch/api-contract
"""

from enum import Enum
from typing import Any

from pydantic import BaseModel


# =============================================================================
# Common Enums
# =============================================================================


class TaskStatus(str, Enum):
    """Status of a task's overall progress."""

    PENDING = "PENDING"
    RECEIVED = "RECEIVED"
    STARTED = "STARTED"
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    REVOKED = "REVOKED"
    RETRY = "RETRY"


class TaskgroupStatus(str, Enum):
    """Status of a taskgroup."""

    EMPTY = "EMPTY"
    PENDING = "PENDING"
    STARTED = "STARTED"
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    PARTIAL_FAILURE = "PARTIAL_FAILURE"


class StreamEventType(str, Enum):
    """Types of streaming events."""

    THINKING_START = "THINKING_START"
    THINKING = "THINKING"
    THINKING_END = "THINKING_END"
    ACTIVITY = "ACTIVITY"
    RESPONSE = "RESPONSE"


# =============================================================================
# Health Models
# =============================================================================


class HealthResponse(BaseModel):
    """Health check response."""

    status: str


# =============================================================================
# Stream Models
# =============================================================================


class StreamEvent(BaseModel):
    """A single streaming event."""

    event_type: str
    value: str | dict[str, Any]


# =============================================================================
# Task Models
# =============================================================================


class WebhookConfig(BaseModel):
    """Webhook configuration."""

    url: str | None = None
    secret: str | None = None


class TaskCreateResponse(BaseModel):
    """Response from creating a task."""

    task_id: str
    taskgroup_id: str | None = None
    created_at: str
    error: str | None = None


class TaskData(BaseModel):
    """Task result data."""

    query: str
    result: str
    profile: str | None = None
    duration: float | None = None
    created_at: str | None = None
    completed_at: str | None = None


class TaskResponse(BaseModel):
    """Response from task API."""

    task_id: str
    taskgroup_id: str | None = None
    status: str
    data: TaskData | None = None
    error: str | None = None


class TaskStatusResponse(BaseModel):
    """Status response from task API."""

    task_id: str
    taskgroup_id: str | None = None
    status: str
    error: str | None = None


# =============================================================================
# Taskgroup Models
# =============================================================================


class TaskgroupWebhook(BaseModel):
    """Taskgroup webhook info (URL only, secret excluded)."""

    url: str


class TaskgroupCreateResponse(BaseModel):
    """Response from creating a taskgroup."""

    taskgroup_id: str
    created_at: str
    tasks: list[str]
    errors: list[str] | None = None


class TaskgroupResponse(BaseModel):
    """Response from taskgroup API."""

    taskgroup_id: str
    status: str
    profile: str
    created_at: str
    updated_at: str | None = None
    webhook: TaskgroupWebhook | None = None
    tasks: list[str]


class TaskgroupAddTaskResponse(BaseModel):
    """Response from adding a task to a taskgroup."""

    task_id: str
    taskgroup_id: str
    created_at: str
    error: str | None = None
