"""Health check for the GL Deep Research Python client.

This module provides the Health class for checking the GL DeepResearch service status.

Authors:
    Sahat Nicholas Simangunsong (sahat.n.simangunsong@gdplabs.id)

References:
    https://gdplabs.gitbook.io/gl-deepresearch/api-contract/api-health
"""

import logging
from urllib.parse import urljoin

from gl_odr_sdk.base import BaseAPI
from gl_odr_sdk.models import HealthResponse

logger = logging.getLogger(__name__)


class Health(BaseAPI):
    """Handles Health API operations for the GL Deep Research API."""

    def check(
        self,
        extra_headers: dict[str, str] | None = None,
    ) -> HealthResponse:
        """Check the health status of the GL DeepResearch service.

        Args:
            extra_headers: Additional headers

        Returns:
            HealthResponse: Health status

        Raises:
            httpx.HTTPStatusError: If the API request fails
        """
        logger.debug("Checking health status")

        url = urljoin(self._client.base_url, "health")
        headers = self._prepare_headers(extra_headers)

        response_data = self._make_request("GET", url, headers)
        return HealthResponse(**response_data)
