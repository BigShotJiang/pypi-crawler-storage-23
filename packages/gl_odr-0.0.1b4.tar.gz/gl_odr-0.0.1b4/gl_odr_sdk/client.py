"""GL Deep Research Python client library for interacting with the GL DeepResearch API.

This library provides a simple interface to interact with the GL DeepResearch API,
supporting Health, Tasks, and Taskgroups operations.

Example:
    >>> client = DeepResearchClient(api_key="your-api-key")
    >>> # Health check
    >>> health = client.health.check()
    >>>
    >>> # Create async task
    >>> task = client.tasks.create(
    ...     query="Research topic",
    ...     profile="GPTR-QUICK"
    ... )
    >>> print(task.task_id)

Authors:
    Sahat Nicholas Simangunsong (sahat.n.simangunsong@gdplabs.id)

References:
    https://gdplabs.gitbook.io/gl-deepresearch/api-contract
"""

import os

from gl_odr_sdk.health import Health
from gl_odr_sdk.taskgroups import Taskgroups
from gl_odr_sdk.tasks import Tasks

# Ensure the URL ends with a slash; without the trailing slash, the base path will be incorrect.
DEFAULT_BASE_URL = "https://stag-gl-deep-research.obrol.id/"


class DeepResearchClient:
    """GL Deep Research API Client.

    Attributes:
        api_key (str): API key for authentication
        base_url (str): Base URL for the GL Deep Research API
        timeout (float): Request timeout in seconds
        default_headers (dict[str, str]): Default headers to include in all requests
        health (Health): Health instance for service health checks
        tasks (Tasks): Tasks instance for asynchronous task operations
        taskgroups (Taskgroups): Taskgroups instance for task group management
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 300.0,
        default_headers: dict[str, str] | None = None,
    ):
        """
        Initialize DeepResearchClient.

        Args:
            api_key (str | None): API key for authentication. If not provided,
                will try to get from GLODR_API_KEY environment variable
            base_url (str | None): Base URL for the GL Deep Research API. If not provided,
                will try to get from GLODR_BASE_URL environment variable,
                otherwise uses default
            timeout (float): Request timeout in seconds (default 300s for long research tasks)
            default_headers (dict[str, str] | None): Default headers to include in all requests.
                These will be merged with any extra_headers provided to individual methods.
        """
        self.api_key = api_key or os.getenv("GLODR_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key is required. Provide it via 'api_key' parameter or "
                "'GLODR_API_KEY' environment variable."
            )

        self.base_url = base_url or os.getenv("GLODR_BASE_URL") or DEFAULT_BASE_URL
        self.timeout = timeout
        self.default_headers = default_headers or {}

        # Initialize API modules
        self.health = Health(self)
        self.tasks = Tasks(self)
        self.taskgroups = Taskgroups(self)
