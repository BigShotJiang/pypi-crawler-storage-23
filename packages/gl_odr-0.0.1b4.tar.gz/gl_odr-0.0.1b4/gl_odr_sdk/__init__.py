"""GL Deep Research Python client library for interacting with the GL DeepResearch API."""

from gl_odr_sdk.client import DeepResearchClient
from gl_odr_sdk.health import Health
from gl_odr_sdk.models import (
    HealthResponse,
    StreamEvent,
    StreamEventType,
    TaskCreateResponse,
    TaskData,
    TaskgroupAddTaskResponse,
    TaskgroupCreateResponse,
    TaskgroupResponse,
    TaskgroupStatus,
    TaskgroupWebhook,
    TaskResponse,
    TaskStatus,
    TaskStatusResponse,
    WebhookConfig,
)
from gl_odr_sdk.taskgroups import Taskgroups
from gl_odr_sdk.tasks import Tasks

__all__ = [
    # Client
    "DeepResearchClient",
    # API Classes
    "Health",
    "Tasks",
    "Taskgroups",
    # Enums
    "TaskStatus",
    "TaskgroupStatus",
    "StreamEventType",
    # Health Models
    "HealthResponse",
    "StreamEvent",
    # Task Models
    "WebhookConfig",
    "TaskCreateResponse",
    "TaskData",
    "TaskResponse",
    "TaskStatusResponse",
    # Taskgroup Models
    "TaskgroupWebhook",
    "TaskgroupCreateResponse",
    "TaskgroupResponse",
    "TaskgroupAddTaskResponse",
]
