# buganise

This package installs [buganize](https://pypi.org/project/buganize/). See https://pypi.org/project/buganize/ for details.
