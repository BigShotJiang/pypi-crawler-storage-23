[build-system]
requires = ["hatchling >= 1.26"]
build-backend = "hatchling.build"
