Evaluate response against requirements.

User request:
{user_input}

Requirements:
{requirements_json}

Candidate:
{candidate_response}

JSON only.