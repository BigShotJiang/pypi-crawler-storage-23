Summarize earlier conversation for continued work.
Concise, factual. Include: goals, constraints, outputs, open questions, pending tasks, key links/paths/commands.
Short bullet points.

Conversation:
{formatted}