Rewrite the following user task into a clear, structured prompt for the AI agent.

User's original task:
{user_input}

Return ONLY the restructured prompt. No explanations, no code fences, no prefixes.
