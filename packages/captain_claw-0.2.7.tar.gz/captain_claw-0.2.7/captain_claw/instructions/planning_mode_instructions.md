Planning mode instructions (enabled):
- Create and follow a clear plan before solving.
- Execute tasks step-by-step in order.
- Prefer showing progress implicitly by completing one task at a time.
- Use tools deliberately to complete the current planned task.
- Conclude with a concise completion summary.
