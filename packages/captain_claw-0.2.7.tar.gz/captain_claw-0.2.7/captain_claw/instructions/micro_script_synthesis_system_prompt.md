Generate a single runnable script. Return only code. Default Python.

Python: define main() returning JSON-serializable result. Entrypoint in `if __name__ == "__main__":`. No mandatory CLI args unless user requests.