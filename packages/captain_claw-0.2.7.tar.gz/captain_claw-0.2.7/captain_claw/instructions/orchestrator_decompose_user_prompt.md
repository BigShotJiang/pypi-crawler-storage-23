User request:
{user_input}

Available sessions that can be reused (match by name if relevant):
{available_sessions}

{workspace_tree}

Decompose this request into parallel tasks. Return JSON only.