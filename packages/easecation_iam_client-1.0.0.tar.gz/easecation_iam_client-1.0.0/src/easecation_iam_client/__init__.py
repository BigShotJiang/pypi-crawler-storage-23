"""
easecation-iam-client — IAM V2 client for EaseCation services (Python port of @easecation/iam-client).

Usage:
    from easecation_iam_client import IamClient, create_iam_client_from_env, ApiKeyRotationHelper

    client = create_iam_client_from_env()
    verify = client.verify_token(access_token)
    api_key_data = client.verify_api_key(key_value)
"""
from .client import IamClient, IamError
from .factory import create_iam_client, create_iam_client_from_env, resolve_iam_env_config
from .rotation import ApiKeyRotationHelper
from .types import (
    ApiKeyCreatedData,
    ApiKeyData,
    ApiKeyOwnerType,
    ApiKeyStatus,
    ApiKeyVerifyData,
    AppTokenData,
    HrBootstrapData,
    IamApiResponse,
    IamClientConfig,
    JwkData,
    JwksData,
    OAuthTokenData,
    RefreshTokenData,
    RevokeTokenData,
    UserBootstrapData,
    UserPermissionsData,
    UserProfileData,
    VerifyTokenData,
)

__all__ = [
    "IamClient",
    "IamError",
    "ApiKeyRotationHelper",
    "create_iam_client",
    "create_iam_client_from_env",
    "resolve_iam_env_config",
    "ApiKeyCreatedData",
    "ApiKeyData",
    "ApiKeyOwnerType",
    "ApiKeyStatus",
    "ApiKeyVerifyData",
    "AppTokenData",
    "HrBootstrapData",
    "IamApiResponse",
    "IamClientConfig",
    "JwkData",
    "JwksData",
    "OAuthTokenData",
    "RefreshTokenData",
    "RevokeTokenData",
    "UserBootstrapData",
    "UserPermissionsData",
    "UserProfileData",
    "VerifyTokenData",
]
