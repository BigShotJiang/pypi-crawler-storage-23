"""
Types for easecation-iam-client (IAM V2 API response shapes).
"""
from __future__ import annotations

from typing import Any, Literal, TypedDict


class IamApiResponse(TypedDict, total=False):
    success: bool
    data: Any
    message: str
    code: str


class AppTokenData(TypedDict):
    applicationSessionToken: str
    applicationId: int


class OAuthTokenData(TypedDict):
    access_token: str
    expires_in: int
    refresh_token: str
    refresh_token_expires_in: int
    token_type: Literal["Bearer"]


class VerifyTokenData(TypedDict):
    valid: bool
    uid: int
    application_id: int
    permissions: list[str]
    exp: int


class RefreshTokenData(TypedDict):
    access_token: str
    expires_in: int
    token_type: str


class RevokeTokenData(TypedDict):
    revoked: bool


class JwkData(TypedDict):
    kty: Literal["RSA"]
    use: Literal["sig"]
    alg: Literal["RS256"]
    kid: str
    n: str
    e: str


class JwksData(TypedDict):
    keys: list[JwkData]


class UserProfileData(TypedDict):
    uid: int
    name: str
    email: str
    status: str


class UserPermissionsData(TypedDict):
    permissions: list[str]
    application_id: int
    user_id: int


class UserBootstrapData(TypedDict):
    uid: int
    name: str
    email: str
    status: str
    application_id: int
    user_data: dict[str, str | None]


class HrBootstrapData(TypedDict, total=False):
    uid: int
    name: str
    email: str
    hrGroup: int
    ECID: str
    serverAdmin: int | None
    serverAdminDue: str


ApiKeyOwnerType = Literal["app", "user"]
ApiKeyStatus = Literal["active", "revoked", "expired"]


class ApiKeyVerifyData(TypedDict, total=False):
    valid: bool
    key_id: str
    owner_type: ApiKeyOwnerType
    owner_id: int
    scopes: list[str] | None
    user_id: int | None
    target_app_id: int | None


class ApiKeyData(TypedDict, total=False):
    id: int
    key_id: str
    name: str
    description: str | None
    owner_type: ApiKeyOwnerType
    owner_id: int
    scopes: list[str] | None
    status: ApiKeyStatus
    expires_at: str | None
    last_used_at: str | None
    created_by: int
    created_at: str
    updated_at: str


class ApiKeyCreatedData(ApiKeyData):
    key_value: str


class IamClientConfig(TypedDict, total=False):
    """Config for IamClient. iam_base_url, client_id, client_secret are required."""
    iam_base_url: str
    client_id: str
    client_secret: str
    app_token_cache_ttl_ms: int
    permission_cache_ttl_ms: int
    timeout_ms: int
