# easecation-iam-client

Python port of [@easecation/iam-client](https://www.npmjs.com/package/@easecation/iam-client). IAM V2 API wrapper for EaseCation services.

## Install

```bash
pip install easecation-iam-client
```

Or from repo:

```bash
pip install -e packages/iam-client-py
```

## Usage

```python
from easecation_iam_client import IamClient, create_iam_client_from_env

# From env (IAM_BASE_URL, IAM_CLIENT_ID, IAM_CLIENT_SECRET)
client = create_iam_client_from_env()

# Or explicit config
client = IamClient(
    iam_base_url="https://iamapi.easecation.net",
    client_id="YOUR_CLIENT_ID",
    client_secret="YOUR_CLIENT_SECRET",
)

# OAuth code exchange
tokens = client.exchange_oauth_code(code, redirect_uri)

# Verify access token
verify = client.verify_token(access_token)

# API key verification
api_key_data = client.verify_api_key(key_value)

# App session verification
valid = client.verify_app_session_token(app_session_token)
```

## API

- `get_app_session_token()`, `invalidate_app_token()`
- `exchange_oauth_code(code, redirect_uri)`
- `verify_token(access_token)`, `evict_from_verify_cache(access_token)`
- `refresh_token(refresh_token)`, `revoke_token(refresh_token)`
- `get_jwks()`, `get_user_profile(access_token)`, `get_user_bootstrap(...)`, `get_hr_bootstrap_data(...)`
- `verify_iam_callback_token(iam_token, ...)`, `get_user_permissions(user_id, ...)`
- `verify_api_key(key_value)`, `evict_api_key_from_cache(key_value)`, `clear_api_key_cache()`
- `verify_app_session_token(app_session_token)`, `clear_app_session_verify_cache()`

`ApiKeyRotationHelper` for zero-downtime key rotation: `create_new_key(...)`, `revoke_key(key_id, ...)`, `list_active_keys(owner_id?)`.
