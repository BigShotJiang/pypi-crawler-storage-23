::: anaplan_sdk.models.cloud_works

<style>
    [data-md-component="toc"] li:first-of-type{
        display:  none!important;
    }
</style>
