!!! note
    This Class is not meant to be instantiated directly, but rather accessed through the `audit` Property on an
    instance of [Client](sync_client.md). For more details, see the [Guide](../../guides/audit.md).

::: anaplan_sdk._clients._AuditClient

<style>
    [data-md-component="toc"] li:first-of-type{
        display:  none!important;
    }
</style>
