"""Feature 1: Team/Individual Context Governance module."""
