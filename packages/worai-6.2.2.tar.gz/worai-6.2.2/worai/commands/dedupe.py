"""CLI wrapper for dedupe."""

from __future__ import annotations

import typer

from worai.core.dedupe import DedupeOptions, run as dedupe_run
from worai.core.profile_loader import resolve_profile_api_key
from worai.core.wordlift import DEFAULT_GRAPHQL_ENDPOINT
from worai.errors import UsageError

app = typer.Typer(add_completion=False, no_args_is_help=True, invoke_without_command=True)


@app.callback(invoke_without_command=True)
def run(
    ctx: typer.Context,
    endpoint: str = typer.Option(DEFAULT_GRAPHQL_ENDPOINT, "--endpoint", help="GraphQL endpoint URL."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show delete calls without executing them."),
    rate_delay: float = typer.Option(0.0, "--rate-delay", help="Seconds to sleep between delete calls."),
    auto: bool = typer.Option(False, "--auto", help="Automatically keep the last IRI in each group."),
) -> None:
    try:
        api_key, _, _ = resolve_profile_api_key(ctx)
    except ValueError as exc:
        raise UsageError(str(exc)) from exc
    if not api_key:
        raise UsageError("WORDLIFT_API_KEY is required (or set profiles.<name>.api_key in config).")

    options = DedupeOptions(
        api_key=api_key,
        endpoint=endpoint,
        dry_run=dry_run,
        rate_delay=rate_delay,
        auto=auto,
    )
    dedupe_run(options)
