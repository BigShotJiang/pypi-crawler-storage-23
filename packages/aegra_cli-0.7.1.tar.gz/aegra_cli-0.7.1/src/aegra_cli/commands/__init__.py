"""Aegra CLI commands."""

from aegra_cli.commands.init import init

__all__ = ["init"]
