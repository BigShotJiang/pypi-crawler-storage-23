# pdoc documentation

SBOMPY can generate HTML documentation using `pdoc`.

From the repo root:

```bash
make create-venv
make install-req-docs
make doc-pdoc
```

The generated HTML will appear under this directory.
