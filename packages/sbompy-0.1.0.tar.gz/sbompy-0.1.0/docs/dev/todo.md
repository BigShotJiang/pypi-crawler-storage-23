## What I need to implement

- [ ] Ensure the python files are working properly
- [ ] Setup docker
- [ ] connect sbom logic to the python tools
- [ ] have sbompy have an attribut for version
