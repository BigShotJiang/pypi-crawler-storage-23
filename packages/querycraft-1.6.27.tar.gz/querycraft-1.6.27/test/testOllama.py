import json
import requests
from typing import List, Dict, Any

OLLAMA_HOST = "http://127.0.0.1:11434"   # adresse du serveur Ollama
MODEL       = "gemma3:1b"                # modèle que tu veux interroger


def ollama_chat(
    messages: List[Dict[str, str]],
    model: str = MODEL,
    host: str = OLLAMA_HOST,
    stream: bool = False,
    temperature: float = 0.7,
    max_tokens: int | None = None,
) -> Any:
    """
    Envoie une requête de type *chat* à Ollama.

    Parameters
    ----------
    messages: list of {"role": "user"/"assistant"/"system", "content": str}
    model: nom du modèle installé sur le serveur
    host: URL du serveur Ollama
    stream: si True, renvoie un générateur d’événements (SSE)
    temperature: contrôle de la créativité (0‑2)
    max_tokens: limite du nombre de tokens générés (optionnel)

    Returns
    -------
    - Si stream=False : dict JSON complet (inclut `message.content`).
    - Si stream=True : générateur qui yield chaque fragment de texte.
    """
    url = f"{host}/api/chat"
    payload: Dict[str, Any] = {
        "model": model,
        "messages": messages,
        "stream": stream,
        "temperature": temperature,
    }
    if max_tokens is not None:
        payload["max_tokens"] = max_tokens

    headers = {"Content-Type": "application/json"}
    response = requests.post(url, headers=headers,
                             data=json.dumps(payload),
                             stream=stream, timeout=240)

    # Gestion d’erreur HTTP
    if not response.ok:
        raise RuntimeError(f"Ollama error {response.status_code}: {response.text}")

    if stream:
        # Retourne un générateur qui décortique les lignes SSE
        def generator():
            for line in response.iter_lines():
                if line:
                    # chaque ligne est du JSON
                    data = json.loads(line.decode())
                    # le champ `message` contient le fragment
                    yield data.get("message", {}).get("content", "")
        return generator()
    else:
        return response.json()

def ollama_is_alive(host: str = OLLAMA_HOST) -> bool:
    try:
        r = requests.get(f"{host}/api/version", timeout=5)
        return r
    except Exception:
        return False


if __name__ == "__main__":
    i = ollama_is_alive()
    if not i.ok:
        raise RuntimeError("Le serveur Ollama ne répond pas – vérifie qu’il est lancé.")
    else:
        print(f"Le serveur Ollama est en ligne. Version : {i.json()['version']}")
    msgs = [
        {"role": "system", "content": "You are a helpful coding coach."},
        {"role": "user", "content": "Explique-moi la différence entre list et tuple en Python."},
    ]

    result = ollama_chat(messages=msgs, model="gemma3:1b", stream=False)
    answer = result["message"]["content"]
    print("\nRéponse d’Ollama :\n")
    print(answer)
