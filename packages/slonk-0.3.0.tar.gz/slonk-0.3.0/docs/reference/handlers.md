# Handlers

Built-in handler implementations and callable wrappers.

::: slonk.handlers
    options:
      members:
        - PathHandler
        - ShellCommandHandler
        - SQLAlchemyHandler
        - _CallableSource
        - _CallableTransform
        - _CallableSink
        - _ParallelHandler
        - parallel
        - _infer_callable_role
        - _wrap_callable
