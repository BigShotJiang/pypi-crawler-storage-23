# Built-in Middleware

Ready-to-use middleware implementations that ship with Slonk.

::: slonk.builtin_middleware
    options:
      members:
        - TimingMiddleware
        - LoggingMiddleware
        - StatsMiddleware
