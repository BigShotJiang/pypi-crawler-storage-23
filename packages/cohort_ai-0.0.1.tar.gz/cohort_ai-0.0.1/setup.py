from setuptools import setup

setup(
    name="cohort-ai",
    version="0.0.1",
    description="Multi-agent orchestration framework for structured AI deliberation",
    long_description="# cohort-ai\n\nMulti-agent orchestration framework. See the main `cohort` package.",
    long_description_content_type="text/markdown",
    author="Ryan Wheeler",
    url="https://github.com/rywheeler/cohort",
    py_modules=["cohort_ai"],
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
