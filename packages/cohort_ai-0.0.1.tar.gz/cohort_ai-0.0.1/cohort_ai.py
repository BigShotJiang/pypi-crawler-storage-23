# cohort-ai - See the main `cohort` package
__version__ = "0.0.1"
