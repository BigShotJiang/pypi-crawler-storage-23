"""Shopify data provider — reads from Shopify Admin GraphQL API.

Maps Shopify-specific resources into standard commerce schema:
    - Products/Variants → schema.Product, schema.Variant
    - Orders/LineItems → schema.Order, schema.LineItem
    - Customers → schema.Customer
    - InventoryItems/Levels → schema.InventoryItem, schema.InventoryLevel

Uses Shopify API version 2026-01 (GraphQL-first, REST is legacy).
"""

from platoon.data.providers.shopify.provider import ShopifyProvider
from platoon.data.providers.shopify.fake import FakeShopifyProvider

__all__ = ["ShopifyProvider", "FakeShopifyProvider"]
