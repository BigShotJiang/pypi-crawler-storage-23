# Performance Optimizer Memory — mcp-tap

## Project: mcp-tap (Python async MCP server)
- httpx for HTTP, asyncio subprocess for process management
- No performance findings yet. Fresh project.
