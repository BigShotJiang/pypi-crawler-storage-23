# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import online_bank_statement_provider_paypal
