import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "jjrawlins-cdk-deploy-pr-github-action",
    "version": "0.0.4",
    "description": "A projen construct that generates GitHub Actions workflows for CDK deployments with GitHub Environments, parallel stages, versioned assemblies, and manual rollback.",
    "license": "Apache-2.0",
    "url": "https://github.com/JaysonRawlins/cdk-deploy-pr-github-action.git",
    "long_description_content_type": "text/markdown",
    "author": "Jayson Rawlins<JaysonJ.Rawlins@gmail.com>",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/JaysonRawlins/cdk-deploy-pr-github-action.git"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "jjrawlins_cdk_deploy_pr_github_action",
        "jjrawlins_cdk_deploy_pr_github_action._jsii"
    ],
    "package_data": {
        "jjrawlins_cdk_deploy_pr_github_action._jsii": [
            "cdk-deploy-pr-github-action@0.0.4.jsii.tgz"
        ],
        "jjrawlins_cdk_deploy_pr_github_action": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.9",
    "install_requires": [
        "aws-cdk-lib>=2.85.0, <3.0.0",
        "constructs>=10.0.5, <11.0.0",
        "jsii>=1.127.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard==2.13.3"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed",
        "Development Status :: 5 - Production/Stable",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
