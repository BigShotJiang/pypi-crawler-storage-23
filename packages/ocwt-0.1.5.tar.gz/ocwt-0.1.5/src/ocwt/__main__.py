from ocwt.cli import run


def main() -> int:
    return run()


if __name__ == "__main__":
    raise SystemExit(main())
