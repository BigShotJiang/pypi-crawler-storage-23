"""Tests for search command."""

import re
import tempfile
from pathlib import Path
from unittest import mock

import pytest
from typer.testing import CliRunner

from fresh import app
from fresh.commands import search

runner = CliRunner()


class TestSearcher:
    """Tests for the searcher module."""

    def test_search_in_content_literal(self):
        """Should find literal matches in content."""
        from fresh.scraper.searcher import search_in_content

        content = "This is a test page.\nAnother line with test content."
        results = search_in_content(content, "test")

        assert len(results) == 2
        assert results[0]["match"] == "test"
        assert results[1]["match"] == "test"

    def test_search_in_content_case_sensitive(self):
        """Should respect case sensitivity."""
        from fresh.scraper.searcher import search_in_content

        content = "Test test TEST"
        results = search_in_content(content, "Test", case_sensitive=True)

        assert len(results) == 1
        assert results[0]["match"] == "Test"

    def test_search_in_content_case_insensitive(self):
        """Should be case insensitive by default."""
        from fresh.scraper.searcher import search_in_content

        content = "Test test TEST"
        results = search_in_content(content, "test")

        # Returns one result per line, but case-insensitive
        assert len(results) == 1
        assert results[0]["match"] == "Test"

    def test_search_in_content_regex(self):
        """Should support regex patterns."""
        from fresh.scraper.searcher import search_in_content

        content = "test123\ntest456\ntest789"
        results = search_in_content(content, r"test\d+", regex=True)

        assert len(results) == 3
        assert results[0]["match"] == "test123"

    def test_search_in_content_regex_invalid(self):
        """Should raise error for invalid regex."""
        from fresh.scraper.searcher import search_in_content

        with pytest.raises(re.error):
            search_in_content("content", "invalid[", regex=True)

    def test_create_snippet(self):
        """Should create snippet around match."""
        from fresh.scraper.searcher import create_snippet

        content = "Line 1\nLine 2\nMatch line\nLine 4\nLine 5"
        snippet = create_snippet(content, "Match", context_lines=1)

        assert "Match line" in snippet

    def test_create_snippet_no_match(self):
        """Should return start of content when no match."""
        from fresh.scraper.searcher import create_snippet

        content = "No match here"
        snippet = create_snippet(content, "test")

        assert snippet == content

    def test_create_snippet_max_length(self):
        """Should respect max_length parameter."""
        from fresh.scraper.searcher import create_snippet

        content = "a" * 500 + " match " + "b" * 500
        snippet = create_snippet(content, "match", max_length=100)

        assert len(snippet) <= 103  # 100 + "..."


class TestSearchCommand:
    """Tests for the search command."""

    @mock.patch("fresh.commands.search.fetch_binary_aware")
    @mock.patch("fresh.commands.search.sitemap.discover_sitemap")
    def test_search_no_sitemap_uses_crawler(self, mock_sitemap, mock_fetch):
        """Should use crawler when no sitemap found."""
        mock_sitemap.return_value = None
        mock_fetch.return_value = mock.MagicMock(text="<html>Test content</html>")

        result = runner.invoke(
            app,
            ["search", "test", "https://example.com", "--max-pages", "1"],
        )

        # Should complete without error even if no results
        assert result.exit_code in [0, 1]

    @mock.patch("fresh.commands.search.fetch_binary_aware")
    @mock.patch("fresh.commands.search.sitemap.discover_sitemap")
    def test_search_with_results(self, mock_sitemap, mock_fetch):
        """Should return results when matches found."""
        mock_sitemap.return_value = None
        mock_fetch.return_value = mock.MagicMock(
            text="<html><body>Test page with test content</body></html>"
        )

        result = runner.invoke(
            app,
            ["search", "test", "https://example.com", "--max-pages", "1"],
        )

        # Should find results
        assert "test" in result.output.lower() or result.exit_code == 0

    @mock.patch("fresh.commands.search.fetch_binary_aware")
    @mock.patch("fresh.commands.search.sitemap.discover_sitemap")
    def test_search_invalid_url(self, mock_sitemap, mock_fetch):
        """Should fail with invalid URL."""
        result = runner.invoke(app, ["search", "test", "invalid-url"])

        assert result.exit_code == 1
        assert "Invalid" in result.output or "Error" in result.output

    @mock.patch("fresh.commands.search.fetch_binary_aware")
    @mock.patch("fresh.commands.search.sitemap.discover_sitemap")
    def test_search_regex_option(self, mock_sitemap, mock_fetch):
        """Should support regex option."""
        mock_sitemap.return_value = None
        mock_fetch.return_value = mock.MagicMock(
            text="<html><body>test123 test456</body></html>"
        )

        result = runner.invoke(
            app,
            ["search", r"test\d+", "https://example.com", "--regex", "--max-pages", "1"],
        )

        # Should handle regex without crashing
        assert result.exit_code in [0, 1]

    @mock.patch("fresh.commands.search.fetch_binary_aware")
    @mock.patch("fresh.commands.search.sitemap.discover_sitemap")
    def test_search_case_sensitive_option(self, mock_sitemap, mock_fetch):
        """Should support case-sensitive option."""
        mock_sitemap.return_value = None
        mock_fetch.return_value = mock.MagicMock(
            text="<html><body>Test test TEST</body></html>"
        )

        result = runner.invoke(
            app,
            [
                "search",
                "Test",
                "https://example.com",
                "--case-sensitive",
                "--max-pages",
                "1",
            ],
        )

        # Should handle case-sensitive without crashing
        assert result.exit_code in [0, 1]


class TestLocalSearch:
    """Tests for local search functionality."""

    def test_url_to_local_path(self):
        """Should convert URL to local path correctly."""
        # Save original DEFAULT_SYNC_DIR
        original_sync_dir = search.DEFAULT_SYNC_DIR

        with tempfile.TemporaryDirectory() as tmpdir:
            # Override sync dir for testing
            search.DEFAULT_SYNC_DIR = Path(tmpdir)

            try:
                url = "https://example.com/docs/api/index.html"
                local_path = search._url_to_local_path(url)

                assert local_path is not None
                assert "example_com" in str(local_path)
                assert "docs" in str(local_path)
                assert "api" in str(local_path)
                assert local_path.suffix == ".html"
            finally:
                search.DEFAULT_SYNC_DIR = original_sync_dir

    def test_local_content_exists(self):
        """Should check if local content exists."""
        original_sync_dir = search.DEFAULT_SYNC_DIR

        with tempfile.TemporaryDirectory() as tmpdir:
            search.DEFAULT_SYNC_DIR = Path(tmpdir)

            try:
                # Create test file
                url = "https://example.com/test.html"
                local_path = search._url_to_local_path(url)
                local_path.parent.mkdir(parents=True, exist_ok=True)
                local_path.write_text("<html>test</html>")

                assert search.local_content_exists(url) is True
                assert search.local_content_exists("https://example.com/notexist.html") is False
            finally:
                search.DEFAULT_SYNC_DIR = original_sync_dir

    def test_get_local_content(self):
        """Should get local content."""
        original_sync_dir = search.DEFAULT_SYNC_DIR

        with tempfile.TemporaryDirectory() as tmpdir:
            search.DEFAULT_SYNC_DIR = Path(tmpdir)

            try:
                url = "https://example.com/test.html"
                local_path = search._url_to_local_path(url)
                local_path.parent.mkdir(parents=True, exist_ok=True)
                local_path.write_text("<html>test content</html>")

                content = search.get_local_content(url)
                assert content == "<html>test content</html>"

                # Non-existent URL
                assert search.get_local_content("https://example.com/notexist.html") is None
            finally:
                search.DEFAULT_SYNC_DIR = original_sync_dir

    def test_discover_local_urls(self):
        """Should discover URLs from local synced content."""
        original_sync_dir = search.DEFAULT_SYNC_DIR

        with tempfile.TemporaryDirectory() as tmpdir:
            search.DEFAULT_SYNC_DIR = Path(tmpdir)

            try:
                base_url = "https://example.com"

                # Create test files
                sync_dir = search._get_sync_dir_for_url(base_url)
                sync_dir.mkdir(parents=True, exist_ok=True)

                (sync_dir / "index.html").write_text("<html>Home</html>")
                (sync_dir / "about.html").write_text("<html>About</html>")
                (sync_dir / "docs.html").write_text("<html>Docs</html>")

                urls = search.discover_local_urls(base_url, max_pages=10)

                # Should find all 3 files (index.html becomes root /)
                assert len(urls) == 3
                # Check we have the files - index.html becomes just /
                assert any("about.html" in u for u in urls)
                assert any("docs.html" in u for u in urls)
                assert any("docs.html" in u for u in urls)
            finally:
                search.DEFAULT_SYNC_DIR = original_sync_dir


class TestSearchSource:
    """Tests for search source parameter."""

    @mock.patch("fresh.commands.search.get_local_content")
    @mock.patch("fresh.commands.search.discover_local_urls")
    def test_search_local_only(self, mock_discover, mock_get_content):
        """Should search only local content with source=local."""
        mock_discover.return_value = ["https://example.com/page.html"]
        mock_get_content.return_value = "<html>test content</html>"

        search.search_pages(
            "https://example.com",
            "test",
            source="local",
            verbose=False,
        )

        # Should not call remote
        mock_discover.assert_called_once()

    @mock.patch("fresh.commands.search.fetch_binary_aware")
    @mock.patch("fresh.commands.search.discover_documentation_urls")
    def test_search_remote_only(self, mock_discover, mock_fetch):
        """Should search only remote content with source=remote."""
        mock_discover.return_value = ["https://example.com/page.html"]
        mock_fetch.return_value = mock.MagicMock(text="<html>test content</html>")

        search.search_pages(
            "https://example.com",
            "test",
            source="remote",
            verbose=False,
        )

        # Should call remote fetch
        mock_fetch.assert_called()

    def test_search_result_has_source(self):
        """SearchResult should have source field."""
        from fresh.scraper.searcher import SearchResult

        result = SearchResult(
            path="/test",
            title="Test",
            snippet="test snippet",
            url="https://example.com/test",
            source="local",
        )

        assert result.source == "local"

        result2 = SearchResult(
            path="/test2",
            title="Test2",
            snippet="test2 snippet",
            url="https://example.com/test2",
            source="remote",
        )

        assert result2.source == "remote"
