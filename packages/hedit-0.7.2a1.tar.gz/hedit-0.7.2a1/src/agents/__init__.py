"""Agent implementations for HED annotation workflow."""
