from pathlib import Path

from setuptools import setup, find_packages

_readme = Path(__file__).parent / "README.md"
long_description = _readme.read_text(encoding="utf-8") if _readme.exists() else ""

setup(
    name="token-network",
    version="0.2.1",
    description="Validate input and return token network config (e.g. network.bitcoin, network.bsc.usdt)",
    long_description=long_description or None,
    long_description_content_type="text/markdown" if long_description else None,
    packages=find_packages(where=".", include=["token_network*"]),
    package_dir={"": "."},
    package_data={"token_network": ["data/*.yaml"]},
    python_requires=">=3.8",
    install_requires=[
        "PyYAML>=6.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
        ],
    },
    keywords=["blockchain", "tokens", "networks", "crypto", "config"],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
