"""
token_network: validate input and return token network config.

Usage:
    from token_network import network

    # All config for a network (config + tokens on that network)
    network.bitcoin.config
    network.bitcoin.tokens
    network.bitcoin.to_dict()   # {"config": {...}, "tokens": [...]}

    # Data for a specific token on a network
    network.bsc.usdt   # dict: network config, token info, contract_address, decimal, native
    network.ethereum.usdt
    network.tron.usdt

    # List all networks / tokens
    get_networks()   # ['bitcoin', 'bsc', 'dogecoin', 'ethereum', ...]
    get_tokens()     # ['AAVE', 'BNB', 'BTC', 'ETH', ...]
    network.get_networks()
    network.get_tokens()

    # Get token object by symbol, slug, or name (case-insensitive)
    get_token('USDT')   # or get_token('usdt'), get_token('tether')

    # Get network by network name (case-insensitive)
    get_network('bitcoin')   # {'config': {...}, 'tokens': [...]}
    get_network('BSC')

    # Get token_network config by token and network name
    get_token_network('USDT', 'bsc')   # or get_token_network('tether', 'BSC')

Unknown network or token raises token_network.TokenNetworkError.
"""

from ._accessor import TokenNetworkError, NetworkAccessor, network


def get_networks() -> list[str]:
    """Return list of all network ids (e.g. ['bitcoin', 'bsc', 'ethereum', ...])."""
    return network.get_networks()


def get_tokens() -> list[str]:
    """Return list of all token symbols (e.g. ['AAVE', 'BNB', 'BTC', ...])."""
    return network.get_tokens()


def get_token(identifier: str) -> dict:
    """
    Get token object by symbol, slug, or name (case-insensitive).
    Returns the token info dict (slug, symbol, standard_symbol, name, precision, factor).
    """
    return network.get_token(identifier)


def get_network(identifier: str) -> dict:
    """
    Get network object by network name/id (case-insensitive).
    Returns dict with "config" and "tokens" (same as network.bitcoin.to_dict()).
    """
    return network.get_network(identifier)


def get_token_network(token_identifier: str, network_identifier: str) -> dict:
    """
    Get token_network config by token (symbol/slug/name) and network name (case-insensitive).
    Returns dict with network, token, contract_address, decimal, native (same as network.bsc.usdt).
    """
    return network.get_token_network(token_identifier, network_identifier)


__all__ = ["network", "get_networks", "get_tokens", "get_token", "get_network", "get_token_network", "TokenNetworkError", "NetworkAccessor"]
__version__ = "0.1.0"
