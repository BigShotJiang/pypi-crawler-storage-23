"""Load and validate networks, tokens, and token_networks from YAML.

All YAML config is read from the package's data directory (token_network/data/).
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import yaml


def _data_dir() -> Path:
    """Return the path to the package data dir (token_network/data/)."""
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "token_network" / "data"
    try:
        from importlib.resources import files
        data = files("token_network") / "data"
        if data.is_dir():
            return Path(str(data))
    except Exception:
        pass
    here = Path(__file__).resolve().parent
    return here / "data"


def _load_yaml(name: str) -> dict[str, Any]:
    """Load a YAML file from the data dir (e.g. networks.yaml, tokens.yaml)."""
    path = _data_dir() / name
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_networks() -> dict[str, dict[str, Any]]:
    data = _load_yaml("networks.yaml")
    networks = data.get("networks") or {}
    if not isinstance(networks, dict):
        raise ValueError("networks.yaml: 'networks' must be a mapping")
    return {k.lower(): dict(v) for k, v in networks.items()}


def load_tokens() -> dict[str, dict[str, Any]]:
    data = _load_yaml("tokens.yaml")
    tokens_list = data.get("tokens") or []
    if not isinstance(tokens_list, list):
        raise ValueError("tokens.yaml: 'tokens' must be a list")
    by_symbol: dict[str, dict[str, Any]] = {}
    for t in tokens_list:
        sym = (t.get("symbol") or "").strip().upper()
        if not sym:
            continue
        by_symbol[sym] = dict(t)
    return by_symbol


TYPE_COIN = "COIN"
TYPE_TOKEN = "TOKEN"


def load_token_networks(testnet: bool = False) -> list[dict[str, Any]]:
    filename = "token_networks_testnet.yaml" if testnet else "token_networks.yaml"
    data = _load_yaml(filename)
    tn = data.get("token_networks") or []
    if not isinstance(tn, list):
        raise ValueError(f"{filename}: 'token_networks' must be a list")
    return [dict(entry) for entry in tn]


def _normalize_token_network_entry(
        entry: dict[str, Any],
        tokens: dict[str, dict[str, Any]],
        slug_to_symbol: dict[str, str],
) -> dict[str, Any] | None:
    net_key = (entry.get("network_slug") or entry.get("network") or "").strip().lower()
    symbol_slug = (entry.get("symbol_slug") or "").strip().lower()
    token_sym = (entry.get("token") or "").strip().upper()
    if symbol_slug and not token_sym:
        token_sym = slug_to_symbol.get(symbol_slug, "").upper()
    if not net_key or not token_sym:
        return None
    if token_sym not in tokens:
        return None

    decimals = entry.get("decimals") if entry.get("decimals") is not None else entry.get("decimal")
    type_raw = (entry.get("type") or "").strip().upper()
    if type_raw in (TYPE_COIN, TYPE_TOKEN):
        native = type_raw == TYPE_COIN
        type_val = type_raw
    else:
        native = bool(entry.get("native", True))
        type_val = TYPE_COIN if native else TYPE_TOKEN

    return {
        "network": net_key,
        "network_slug": net_key,
        "token": token_sym,
        "symbol_slug": tokens[token_sym].get("slug", "").lower(),
        "contract_address": entry.get("contract_address"),
        "decimal": decimals,
        "decimals": decimals,
        "native": native,
        "type": type_val,
    }


def build_index(
        networks: dict[str, dict[str, Any]],
        tokens: dict[str, dict[str, Any]],
        token_networks: list[dict[str, Any]],
) -> tuple[
    dict[str, dict[str, Any]],
    dict[tuple[str, str], dict[str, Any]],
]:

    slug_to_symbol = {
        (v.get("slug") or "").strip().lower(): k
        for k, v in tokens.items()
        if (v.get("slug") or "").strip()
    }
    network_tokens: dict[str, dict[str, Any]] = {}
    token_on_network: dict[tuple[str, str], dict[str, Any]] = {}

    for entry in token_networks:
        normalized = _normalize_token_network_entry(entry, tokens, slug_to_symbol)
        if normalized is None:
            continue
        net_key = normalized["network"]
        if net_key not in networks:
            continue

        token_sym = normalized["token"]
        net_config = networks[net_key]
        token_info = tokens[token_sym]
        binding = {
            "network": net_key,
            "network_slug": net_key,
            "token": token_sym,
            "symbol_slug": normalized["symbol_slug"],
            "contract_address": normalized["contract_address"],
            "decimal": normalized["decimal"],
            "decimals": normalized["decimals"],
            "native": normalized["native"],
            "type": normalized["type"],
        }

        if net_key not in network_tokens:
            network_tokens[net_key] = {"config": net_config, "tokens": []}
        network_tokens[net_key]["tokens"].append({
            **binding,
            "token_info": token_info,
        })

        key = (net_key, token_sym)
        token_on_network[key] = {
            "network": net_config,
            "token": token_info,
            "contract_address": binding["contract_address"],
            "decimal": binding["decimal"],
            "decimals": binding["decimals"],
            "native": binding["native"],
            "type": binding["type"],
        }

    # Ensure every network from networks.yaml appears (even if no tokens listed)
    for net_key, net_config in networks.items():
        if net_key not in network_tokens:
            network_tokens[net_key] = {"config": net_config, "tokens": []}

    return network_tokens, token_on_network


def load_all(testnet: bool = False) -> tuple[
    dict[str, dict[str, Any]],
    dict[tuple[str, str], dict[str, Any]],
    dict[str, dict[str, Any]],
    dict[str, dict[str, Any]],
]:
    """Load YAMLs and return (network_tokens, token_on_network, networks_only, tokens)."""
    networks = load_networks()
    tokens = load_tokens()
    token_networks = load_token_networks(testnet=testnet)
    network_tokens, token_on_network = build_index(networks, tokens, token_networks)
    networks_only = {k: v["config"] for k, v in network_tokens.items()}
    return network_tokens, token_on_network, networks_only, tokens
