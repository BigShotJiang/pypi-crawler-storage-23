"""Attribute-based access to network and token config: network.bitcoin, network.bsc.usdt."""

from __future__ import annotations

from typing import Any

from ._loader import load_all


class TokenNetworkError(Exception):
    """Raised when a network or token is unknown or invalid."""


class _NetworkNode:
    """Represents one network. Supports .config, .tokens, and .<token_symbol> (e.g. .usdt)."""

    __slots__ = ("_net_key", "_network_tokens", "_token_on_network")

    def __init__(
        self,
        net_key: str,
        network_tokens: dict[str, dict[str, Any]],
        token_on_network: dict[tuple[str, str], dict[str, Any]],
    ) -> None:
        self._net_key = net_key
        self._network_tokens = network_tokens
        self._token_on_network = token_on_network

    @property
    def config(self) -> dict[str, Any]:
        """Network config for this network."""
        if self._net_key not in self._network_tokens:
            raise TokenNetworkError(f"Unknown network: {self._net_key!r}")
        return dict(self._network_tokens[self._net_key]["config"])

    @property
    def tokens(self) -> list[dict[str, Any]]:
        """List of token bindings on this network (each with token_info, contract_address, etc.)."""
        if self._net_key not in self._network_tokens:
            raise TokenNetworkError(f"Unknown network: {self._net_key!r}")
        return list(self._network_tokens[self._net_key]["tokens"])

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        token_sym = name.upper()
        key = (self._net_key, token_sym)
        if key not in self._token_on_network:
            raise TokenNetworkError(
                f"Token {token_sym!r} is not defined on network {self._net_key!r}. "
                f"Available tokens: {[t['token'] for t in self.tokens]}"
            )
        return dict(self._token_on_network[key])

    def to_dict(self) -> dict[str, Any]:
        """Return full network data: config and tokens (e.g. 'all bitcoin config')."""
        return {"config": self.config, "tokens": self.tokens}


class NetworkAccessor:
    """
    Attribute-based access to token network config.
    - network.bitcoin  -> network node (use .config, .tokens, or .to_dict() for full config)
    - network.bsc.usdt -> dict with network config, token info, contract_address, decimal, native
    """

    __slots__ = ("_network_tokens", "_token_on_network", "_tokens")

    def __init__(self, testnet: bool = False) -> None:
        self._network_tokens, self._token_on_network, _, self._tokens = load_all(testnet=testnet)

    def get_networks(self) -> list[str]:
        """Return list of all network ids (e.g. ['bitcoin', 'bsc', 'ethereum', ...])."""
        return sorted(self._network_tokens.keys())

    def get_tokens(self) -> list[str]:
        """Return list of all token symbols (e.g. ['AAVE', 'BNB', 'BTC', ...])."""
        return sorted(self._tokens.keys())

    def get_token(self, identifier: str) -> dict[str, Any]:
        """
        Get token object by symbol, slug, or name (case-insensitive).
        Returns the token info dict (slug, symbol, standard_symbol, name, precision, factor).
        Raises TokenNetworkError if not found.
        """
        raw = (identifier or "").strip()
        if not raw:
            raise TokenNetworkError("Token identifier cannot be empty")
        key_upper = raw.upper()
        key_lower = raw.lower()
        if key_upper in self._tokens:
            return dict(self._tokens[key_upper])
        for sym, info in self._tokens.items():
            if (info.get("slug") or "").strip().lower() == key_lower:
                return dict(info)
            if (info.get("name") or "").strip().lower() == key_lower:
                return dict(info)
        raise TokenNetworkError(
            f"Unknown token: {identifier!r}. Known tokens: {self.get_tokens()}"
        )

    def get_network(self, identifier: str) -> dict[str, Any]:
        """
        Get network object by network name/id (case-insensitive).
        Returns dict with "config" (network config) and "tokens" (token bindings on this network).
        Raises TokenNetworkError if not found.
        """
        raw = (identifier or "").strip()
        if not raw:
            raise TokenNetworkError("Network identifier cannot be empty")
        net_key = raw.lower()
        if net_key not in self._network_tokens:
            raise TokenNetworkError(
                f"Unknown network: {identifier!r}. Known networks: {self.get_networks()}"
            )
        data = self._network_tokens[net_key]
        return {"config": dict(data["config"]), "tokens": list(data["tokens"])}

    def get_token_network(self, token_identifier: str, network_identifier: str) -> dict[str, Any]:
        """
        Get token_network config by token (symbol/slug/name) and network name (case-insensitive).
        Returns dict with network config, token info, contract_address, decimal, native.
        Same data as network.bsc.usdt. Raises TokenNetworkError if not found or token not on network.
        """
        token_info = self.get_token(token_identifier)
        symbol = (token_info.get("symbol") or "").strip().upper()
        if not symbol:
            raise TokenNetworkError("Token has no symbol")
        raw_net = (network_identifier or "").strip()
        if not raw_net:
            raise TokenNetworkError("Network identifier cannot be empty")
        net_key = raw_net.lower()
        if net_key not in self._network_tokens:
            raise TokenNetworkError(
                f"Unknown network: {network_identifier!r}. Known networks: {self.get_networks()}"
            )
        key = (net_key, symbol)
        if key not in self._token_on_network:
            tokens_on_net = [t["token"] for t in self._network_tokens[net_key]["tokens"]]
            raise TokenNetworkError(
                f"Token {symbol!r} is not on network {net_key!r}. "
                f"Available on this network: {tokens_on_net}"
            )
        return dict(self._token_on_network[key])

    def __getattr__(self, name: str) -> _NetworkNode:
        if name.startswith("_"):
            raise AttributeError(name)
        net_key = name.lower()
        if net_key not in self._network_tokens:
            known = ", ".join(self.get_networks())
            raise TokenNetworkError(
                f"Unknown network: {name!r}. Known networks: {known}"
            )
        return _NetworkNode(
            net_key,
            self._network_tokens,
            self._token_on_network,
        )

    def __dir__(self) -> list[str]:
        return self.get_networks()


# Singleton used as `network`
network = NetworkAccessor()
