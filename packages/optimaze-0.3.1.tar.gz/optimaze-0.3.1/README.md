# Optimaze

**AI-powered Gurobi optimization tuning — automatically speed up your models.**

[![PyPI](https://img.shields.io/pypi/v/optimaze)](https://pypi.org/project/optimaze/)
![Python](https://img.shields.io/badge/python-3.10+-blue)
![License](https://img.shields.io/badge/license-MIT-green)

## Installation

```bash
pip install optimaze
```

## Usage

```bash
optimaze optimize model.py --repo https://github.com/you/repo --key YOUR_KEY
```

**Options:**

| Flag | Description |
|------|-------------|
| `model.py` | Your Python script that builds and solves a Gurobi model |
| `--repo` | GitHub repo where improvements are committed |
| `--key` | Your Optimaze license key (or set `OPTIMAZE_KEY`) |
| `--max-iterations` | Max improvement iterations (default: 10) |

## How It Works

```
┌──────────────────────┐      ┌──────────────────────┐
│   Your Machine       │      │   Optimaze Cloud     │
│                      │      │                      │
│  1. Runs your model  │ ──── │  2. Analyzes logs    │
│     (your Gurobi     │ logs │     & source code    │
│      license)        │      │                      │
│                      │ ◄─── │  3. Generates code   │
│  4. Re-runs model    │ code │     improvements     │
│     with changes     │      │                      │
└──────────────────────┘      └──────────────────────┘
```

**EULA-compliant architecture**: Gurobi runs locally on your machine with your own license. The cloud service only analyzes solver logs and generates code — it never runs the solver.

## Example

```
============================================================
  OPTIMAZE
  AI-powered optimization tuning
============================================================

Script:     /path/to/model.py
Repo:       https://github.com/you/repo

[Iteration 0] Running model...
  Runtime: 18.25s
  (baseline)

[Iteration 1] Running model...
  Runtime: 13.10s
  Improvement: 28.2% faster

RESULTS
----------------------------------------
Baseline:  18.25s
Best:      13.10s
Speedup:   +28.2%

To apply:
  git merge agent/optimize-sess_xxxxx
```

## What It Tries

The agent analyzes your model's solver logs and applies targeted improvements:

- **Solver Parameters** — MIPFocus, Cuts, Presolve, Method, Heuristics, Threads, Symmetry
- **Big-M Tightening** — tighten large coefficients that cause numerical issues
- **Symmetry Breaking** — add constraints to eliminate symmetric solutions
- **Valid Inequalities** — strengthen the LP relaxation
- **Branching Priorities** — guide the branch-and-bound search
- **Warm Starting** — provide initial feasible solutions
- **Lazy Constraints** — defer rarely-binding constraints

Typical speedup: **20–50%**

## Requirements

- Python 3.10+
- Gurobi installed with a valid license ([free academic license](https://www.gurobi.com/academia/academic-program-and-licenses/))
- Git configured for your repo

## Environment Variables

| Variable | Description |
|----------|-------------|
| `OPTIMAZE_KEY` | Your license key |
| `OPTIMAZE_SERVER` | Custom server URL (optional) |

## License

MIT — see [LICENSE](LICENSE)
