#!/usr/bin/env python3
"""
Template: Standalone Gurobi Solver
==================================

This template is compatible with the optimization agent.
Copy this file to your repo and adapt it to your problem.

Requirements:
1. Model must be created DIRECTLY with gp.Model()
2. Must have if __name__ == "__main__": block
3. Model must complete within timeout (default 120s)
"""
import json
import os
import time

import gurobipy as gp


def main():
    print("=" * 60)
    print("YOUR OPTIMIZATION PROBLEM NAME")
    print("=" * 60)
    print()

    # =========================================================================
    # STEP 1: Load data
    # =========================================================================
    print("[1/3] Loading data...")

    # Option A: Load from JSON file
    data_path = os.path.join(os.path.dirname(__file__), "data.json")
    if os.path.exists(data_path):
        with open(data_path) as f:
            data = json.load(f)
    else:
        # Option B: Generate synthetic data for testing
        data = generate_test_data()

    # Print problem size
    print(f"      Items: {len(data.get('items', []))}")
    print()

    # =========================================================================
    # STEP 2: Build model
    # =========================================================================
    print("[2/3] Building optimization model...")

    # IMPORTANT: Create model DIRECTLY here (not in a helper function)
    model = gp.Model("MyProblem")

    # ------ Add your variables ------
    # Example: binary decision variables
    items = data.get("items", list(range(10)))
    x = {}
    for i in items:
        x[i] = model.addVar(vtype=gp.GRB.BINARY, name=f"x_{i}")

    # ------ Add your objective ------
    # Example: maximize sum of selected items
    values = data.get("values", {i: i + 1 for i in items})
    model.setObjective(
        gp.quicksum(values.get(i, 1) * x[i] for i in items),
        gp.GRB.MAXIMIZE
    )

    # ------ Add your constraints ------
    # Example: capacity constraint
    weights = data.get("weights", {i: 1 for i in items})
    capacity = data.get("capacity", len(items) // 2)
    model.addConstr(
        gp.quicksum(weights.get(i, 1) * x[i] for i in items) <= capacity,
        name="capacity"
    )

    print(f"      Variables: {model.NumVars:,}")
    print(f"      Constraints: {model.NumConstrs:,}")
    print()

    # =========================================================================
    # STEP 3: Solve
    # =========================================================================
    print("[3/3] Solving...")
    print("-" * 60)

    start_time = time.time()
    model.optimize()
    solve_time = time.time() - start_time

    print("-" * 60)
    print()

    # =========================================================================
    # Results
    # =========================================================================
    print("RESULTS")
    print("=" * 60)

    if model.Status == 2:  # Optimal
        print(f"Status: Optimal")
        print(f"Objective: {model.ObjVal:,.2f}")
        print(f"Solve time: {solve_time:.2f} seconds")
        print(f"Nodes explored: {int(model.NodeCount):,}")
    else:
        print(f"Status: {model.Status}")
        print(f"Solve time: {solve_time:.2f} seconds")

    print()


def generate_test_data():
    """Generate synthetic test data."""
    import random
    random.seed(42)

    n = 100  # Number of items
    items = list(range(n))
    values = {i: random.randint(1, 100) for i in items}
    weights = {i: random.randint(1, 50) for i in items}
    capacity = sum(weights.values()) // 3

    return {
        "items": items,
        "values": values,
        "weights": weights,
        "capacity": capacity,
    }


if __name__ == "__main__":
    main()
