"""
Optimaze CLI - AI-powered optimization model tuning.

Analyzes your solver logs and commits improvements directly to your repo.
No local repo copy needed — the server manages everything.

Usage:
    optimaze optimize --repo https://github.com/you/repo --entry solve.py --key YOUR_KEY
"""

import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx
import typer

app = typer.Typer(
    name="optimaze",
    help="AI-powered optimization. Analyzes solver logs, commits improvements to your repo.",
    add_completion=False,
)

# Default server URL
DEFAULT_SERVER = "https://beautiful-victory-production-de1e.up.railway.app"


def print_banner():
    """Print the CLI banner."""
    typer.echo("")
    typer.echo("=" * 60)
    typer.echo("  OPTIMAZE")
    typer.echo("  AI-powered optimization tuning")
    typer.echo("=" * 60)
    typer.echo("")


def run_model(script_path: Path, timeout: float = 300.0) -> tuple[bool, float, str]:
    """
    Run the model script.

    stdout is passed through so the user sees live output.
    Logs come from the Gurobi log file, not stdout.
    """
    start_time = time.time()
    try:
        result = subprocess.run(
            [sys.executable, str(script_path)],
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            cwd=script_path.parent,
        )
        runtime = time.time() - start_time
        return result.returncode == 0, runtime, result.stderr or ""
    except subprocess.TimeoutExpired:
        return False, timeout, "Timeout expired"
    except Exception as e:
        return False, 0.0, str(e)


def read_log_file(log_path: Path) -> str:
    """Read the solver log file."""
    if not log_path.exists():
        return ""
    return log_path.read_text()


def git_pull(branch: str, repo_dir: Path) -> bool:
    """Pull the latest changes from the branch."""
    try:
        subprocess.run(
            ["git", "fetch", "origin", branch],
            cwd=repo_dir, capture_output=True, check=True,
        )
        subprocess.run(
            ["git", "checkout", branch],
            cwd=repo_dir, capture_output=True, check=True,
        )
        subprocess.run(
            ["git", "pull", "origin", branch],
            cwd=repo_dir, capture_output=True, check=True,
        )
        return True
    except subprocess.CalledProcessError as e:
        typer.secho(f"Git error: {e}", fg=typer.colors.RED)
        return False


@app.command()
def optimize(
    repo: str = typer.Option(
        ...,
        "--repo", "-r",
        help="GitHub repo URL (e.g., https://github.com/you/repo)",
    ),
    entry: str = typer.Option(
        ...,
        "--entry", "-e",
        help="Entry file path inside the repo (e.g., solve.py or src/model.py)",
    ),
    key: str = typer.Option(
        ...,
        "--key", "-k",
        help="Your Optimaze license key",
        envvar="OPTIMAZE_KEY",
    ),
    log_file: str = typer.Option(
        "gurobi.log",
        "--log-file", "-l",
        help="Solver log file path (relative to entry file directory)",
    ),
    max_iterations: int = typer.Option(
        5,
        "--max-iterations", "-n",
        help="Maximum optimization iterations",
    ),
    timeout: float = typer.Option(
        300.0,
        "--timeout", "-t",
        help="Timeout per model run in seconds",
    ),
    server: str = typer.Option(
        DEFAULT_SERVER,
        "--server", "-s",
        help="API server URL",
        envvar="OPTIMAZE_SERVER",
    ),
):
    """
    Optimize your model automatically.

    The server creates a branch and PR on your repo. The CLI clones that branch,
    runs your model, and sends the solver logs back. The server commits
    improvements and the loop continues until no more gains are found.

    Example:
        optimaze optimize --repo https://github.com/you/repo --entry solve.py --key YOUR_KEY
    """
    print_banner()

    typer.echo(f"Repo:       {repo}")
    typer.echo(f"Entry:      {entry}")
    typer.echo("")

    # ── Create session (server creates branch + PR) ──────────────────────────
    typer.echo("Creating optimization session...")

    try:
        with httpx.Client(timeout=60.0) as client:
            response = client.post(
                f"{server}/sessions",
                json={"repo_url": repo, "entry_file": entry, "log_file": log_file},
                headers={"X-License-Key": key},
            )

        if response.status_code == 401:
            typer.secho("Error: Invalid license key", fg=typer.colors.RED)
            raise typer.Exit(1)

        if response.status_code != 200:
            typer.secho(f"Error creating session: {response.text}", fg=typer.colors.RED)
            raise typer.Exit(1)

        session_data = response.json()
        session_id = session_data["session_id"]
        branch = session_data["branch"]
        working_repo_url = session_data["working_repo_url"]

    except httpx.ConnectError:
        typer.secho("Error: Could not connect to server", fg=typer.colors.RED)
        raise typer.Exit(1)

    typer.secho(f"Session:    {session_id}", fg=typer.colors.GREEN)
    typer.secho(f"Branch:     {branch}", fg=typer.colors.GREEN)
    if session_data.get("pr_url"):
        typer.secho(f"PR:         {session_data['pr_url']}", fg=typer.colors.CYAN)
    typer.echo("")

    # ── Clone the branch into a temp directory ────────────────────────────────
    work_dir = Path(tempfile.mkdtemp(prefix="optimaze_"))
    typer.echo(f"Cloning branch {branch}...")

    try:
        subprocess.run(
            ["git", "clone", "--branch", branch, working_repo_url, str(work_dir)],
            capture_output=True, check=True, timeout=120,
        )
    except subprocess.CalledProcessError as e:
        typer.secho(
            f"Failed to clone repo: {e.stderr.decode()[:300]}",
            fg=typer.colors.RED,
        )
        shutil.rmtree(work_dir, ignore_errors=True)
        raise typer.Exit(1)

    # Entry file may be in a subdirectory (e.g., "src/model.py")
    script_path = work_dir / entry
    if not script_path.exists():
        typer.secho(f"Entry file not found in repo: {entry}", fg=typer.colors.RED)
        shutil.rmtree(work_dir, ignore_errors=True)
        raise typer.Exit(1)

    # Log file is relative to the entry file's directory
    log_path = script_path.parent / log_file

    typer.echo(f"Working dir: {work_dir}")
    typer.echo("")

    results = []
    baseline_runtime = None

    try:
        # ── Main optimization loop ────────────────────────────────────────────
        for iteration in range(max_iterations):
            typer.echo("-" * 60)
            typer.echo(f"[Iteration {iteration}] Running model...")

            success, runtime, stderr = run_model(script_path, timeout)

            if not success:
                typer.secho(f"  Model failed: {stderr[:200]}", fg=typer.colors.RED)
                break

            typer.echo(f"  Runtime: {runtime:.2f}s")

            if iteration == 0:
                baseline_runtime = runtime
                typer.echo("  (baseline)")
            else:
                improvement = ((baseline_runtime - runtime) / baseline_runtime) * 100
                if improvement > 0:
                    typer.secho(f"  Improvement: {improvement:.1f}% faster", fg=typer.colors.GREEN)
                else:
                    typer.echo(f"  Improvement: {improvement:.1f}%")

            logs = read_log_file(log_path)
            if not logs:
                typer.echo("  (No log file yet - agent will enable Gurobi logging)")
                logs = ""

            typer.echo("  Analyzing...")

            try:
                with httpx.Client(timeout=60.0) as client:
                    response = client.post(
                        f"{server}/sessions/{session_id}/logs",
                        json={"logs": logs, "runtime": runtime, "iteration": iteration},
                        headers={"X-License-Key": key},
                    )

                if response.status_code != 200:
                    typer.secho(f"  Error: {response.text}", fg=typer.colors.RED)
                    break

                result = response.json()

            except httpx.ConnectError:
                typer.secho("  Error: Lost connection to server", fg=typer.colors.RED)
                break

            results.append({
                "commit": result.get("commit"),
                "runtime": runtime,
                "iteration": iteration,
            })

            if result["action"] == "done":
                typer.echo("")
                typer.secho("No more improvements to try.", fg=typer.colors.YELLOW)
                break

            typer.secho(
                f"  Committed: \"{result.get('message', 'improvement')}\"",
                fg=typer.colors.CYAN,
            )
            typer.echo("  Pulling changes...")

            if not git_pull(branch, work_dir):
                typer.secho("  Failed to pull changes", fg=typer.colors.RED)
                break

            typer.echo("")

    finally:
        shutil.rmtree(work_dir, ignore_errors=True)

    # ── Complete session ──────────────────────────────────────────────────────
    typer.echo("")
    typer.echo("=" * 60)

    if not results:
        typer.secho("No results to report.", fg=typer.colors.YELLOW)
        raise typer.Exit(1)

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                f"{server}/sessions/{session_id}/complete",
                json={"results": results},
                headers={"X-License-Key": key},
            )

        if response.status_code == 200:
            final = response.json()

            typer.echo("")
            typer.secho("RESULTS", fg=typer.colors.GREEN, bold=True)
            typer.echo("-" * 40)
            typer.echo(f"Baseline:  {final['baseline_runtime']:.2f}s")
            typer.echo(f"Best:      {final['best_runtime']:.2f}s")

            if final["speedup"] > 0:
                typer.secho(
                    f"Speedup:   +{final['speedup']:.1f}%",
                    fg=typer.colors.GREEN, bold=True,
                )
            else:
                typer.echo(f"Speedup:   {final['speedup']:.1f}%")

            typer.echo("")

            if final.get("pr_url"):
                typer.secho("Pull Request updated!", fg=typer.colors.GREEN)
                typer.echo(f"  {final['pr_url']}")
            else:
                typer.echo(f"Branch: {branch}")
        else:
            typer.secho(f"Complete failed: {response.text}", fg=typer.colors.RED)

    except Exception as e:
        typer.secho(f"Error: {e}", fg=typer.colors.RED)

    typer.echo("")


@app.command()
def version():
    """Show version."""
    from . import __version__
    typer.echo(f"optimaze {__version__}")


@app.command()
def health(
    server: str = typer.Option(
        DEFAULT_SERVER,
        "--server", "-s",
        help="API server URL",
    ),
):
    """Check server status."""
    try:
        with httpx.Client(timeout=5.0) as client:
            response = client.get(f"{server}/health")

        if response.status_code == 200:
            typer.secho("Server is healthy", fg=typer.colors.GREEN)
        else:
            typer.secho(f"Server error: {response.status_code}", fg=typer.colors.RED)
            raise typer.Exit(1)

    except httpx.ConnectError:
        typer.secho("Cannot connect to server", fg=typer.colors.RED)
        raise typer.Exit(1)


def main():
    """Entry point."""
    app()


if __name__ == "__main__":
    main()
