"""
OptimizationAgent: Main orchestrator for the tax optimization loop.

Runs the iterative cycle: solve -> analyze -> fix -> repeat
"""

import json
import os
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from src.data.schemas import OptimizationConfig, PopulationData

from server.api.agent.analyzer import SolverAnalyzer
from server.api.agent.modifier import ModelModifier
from server.api.agent.solver import SolverResult, SolverWrapper


@dataclass
class IterationLog:
    """Log entry for one iteration."""

    iteration: int
    timestamp: str
    solver_status: str
    runtime_seconds: float
    analysis_status: str
    fix_applied: Optional[str] = None
    objective_value: Optional[float] = None


@dataclass
class AgentResult:
    """Final result from agent run."""

    success: bool
    status: str
    total_iterations: int
    total_runtime_seconds: float

    # Final solution (if successful)
    final_solution: Optional[dict] = None
    final_config: Optional[dict] = None

    # Logs
    iteration_logs: list[IterationLog] = field(default_factory=list)
    modification_log: list[dict] = field(default_factory=list)

    # For PR
    summary_for_pr: str = ""


class OptimizationAgent:
    """
    Main optimization agent.

    Workflow:
        1. Run solver
        2. Analyze result
        3. If optimal -> done
        4. If not -> generate fix, apply, repeat
    """

    def __init__(
        self,
        max_iterations: int = 10,
        log_dir: Optional[str] = None,
        verbose: bool = True,
    ):
        self.max_iterations = max_iterations
        self.log_dir = log_dir
        self.verbose = verbose

        # Components
        self.solver = SolverWrapper(log_dir)
        self.analyzer = SolverAnalyzer()
        self.modifier = ModelModifier()

        # State
        self.iteration_logs: list[IterationLog] = []
        self.current_iteration = 0

    def log(self, msg: str):
        """Print log message if verbose."""
        if self.verbose:
            print(f"[Agent] {msg}")

    def run(
        self,
        population: PopulationData,
        config: OptimizationConfig,
    ) -> AgentResult:
        """
        Run the optimization loop.

        Args:
            population: Population data
            config: Initial optimization config

        Returns:
            AgentResult with final status and solution
        """
        start_time = datetime.now()
        current_config = config

        self.log(f"Starting optimization with {population.n_persons} persons")
        self.log(f"Max iterations: {self.max_iterations}")

        for iteration in range(self.max_iterations):
            self.current_iteration = iteration
            self.modifier.increment_iteration()

            self.log(f"\n=== Iteration {iteration + 1}/{self.max_iterations} ===")

            # 1. Run solver
            self.log("Running solver...")
            result = self.solver.solve(population, current_config)
            self.log(f"Solver status: {result.status} ({result.runtime_seconds:.1f}s)")

            # 2. Analyze result
            self.log("Analyzing result...")
            analysis = self.analyzer.analyze(result)

            # 3. Log iteration
            log_entry = IterationLog(
                iteration=iteration,
                timestamp=datetime.now().isoformat(),
                solver_status=result.status,
                runtime_seconds=result.runtime_seconds,
                analysis_status=analysis.status,
                objective_value=result.objective_value,
            )

            # 4. Check termination
            if result.success:
                self.log("OPTIMAL solution found!")
                log_entry.fix_applied = None
                self.iteration_logs.append(log_entry)

                return self._build_success_result(
                    result,
                    current_config,
                    start_time,
                )

            # 5. Not optimal - try to fix
            self.log(f"Analysis: {analysis.summary}")
            if analysis.root_cause:
                self.log(f"Root cause: {analysis.root_cause}")

            if not analysis.suggested_fixes:
                self.log("No fixes suggested. Stopping.")
                self.iteration_logs.append(log_entry)
                break

            # 6. Apply best fix
            current_config, applied_fix = self.modifier.apply_best_fix(
                current_config,
                analysis,
            )

            if applied_fix:
                fix_desc = f"{applied_fix.parameter}: {applied_fix.current_value} -> {applied_fix.suggested_value}"
                self.log(f"Applying fix: {fix_desc}")
                log_entry.fix_applied = fix_desc
            else:
                self.log("No fix could be applied. Stopping.")
                self.iteration_logs.append(log_entry)
                break

            self.iteration_logs.append(log_entry)

        # Max iterations reached or no fix available
        total_time = (datetime.now() - start_time).total_seconds()
        self.log(f"\nAgent finished after {len(self.iteration_logs)} iterations")

        return AgentResult(
            success=False,
            status="MAX_ITERATIONS" if self.current_iteration >= self.max_iterations - 1 else "NO_FIX",
            total_iterations=len(self.iteration_logs),
            total_runtime_seconds=total_time,
            iteration_logs=self.iteration_logs,
            modification_log=self.modifier.get_modification_dict(),
            summary_for_pr=self._generate_failure_summary(),
        )

    def _build_success_result(
        self,
        result: SolverResult,
        config: OptimizationConfig,
        start_time: datetime,
    ) -> AgentResult:
        """Build result for successful optimization."""
        total_time = (datetime.now() - start_time).total_seconds()

        return AgentResult(
            success=True,
            status="OPTIMAL",
            total_iterations=len(self.iteration_logs),
            total_runtime_seconds=total_time,
            final_solution=result.solution,
            final_config=self._config_to_dict(config),
            iteration_logs=self.iteration_logs,
            modification_log=self.modifier.get_modification_dict(),
            summary_for_pr=self._generate_success_summary(result, config),
        )

    def _config_to_dict(self, config: OptimizationConfig) -> dict:
        """Convert config to dictionary."""
        return {
            "min_budget_change": config.min_budget_change,
            "max_budget_change": config.max_budget_change,
            "max_marginal_rate": config.max_marginal_rate,
            "max_relative_income_drop": config.max_relative_income_drop,
            "time_limit": config.time_limit,
            "mip_gap": config.mip_gap,
        }

    def _generate_success_summary(
        self,
        result: SolverResult,
        config: OptimizationConfig,
    ) -> str:
        """Generate PR summary for successful optimization."""
        sol = result.solution or {}
        brackets = sol.get("brackets", {})
        budget = sol.get("budget", {})

        lines = [
            "## Tax Bracket Optimization Solution",
            "",
            "### Summary",
            "- **Status**: OPTIMAL",
            f"- **Iterations**: {len(self.iteration_logs)}",
            f"- **Objective Value**: {result.objective_value:.4f}" if result.objective_value else "",
            "",
            "### Solution Details",
            "",
            "| Bracket | Lower Bound | Rate |",
            "|---------|-------------|------|",
        ]

        thresholds = brackets.get("thresholds", [])
        rates = brackets.get("rates", [])
        active = brackets.get("active", [])

        for i, (t, r, a) in enumerate(zip(thresholds, rates, active)):
            status = "" if a else " (inactive)"
            lines.append(f"| {i + 1} | €{t:,.0f} | {r:.1%}{status} |")

        lines.extend([
            "",
            "### Budget Impact",
            f"- **Previous Revenue**: €{budget.get('old_revenue', 0):,.0f}",
            f"- **New Revenue**: €{budget.get('new_revenue', 0):,.0f}",
            f"- **Change**: €{budget.get('change', 0):,.0f}",
            "",
            "### Constraints",
            f"- Max Marginal Rate: {config.max_marginal_rate:.0%}",
            f"- Max Income Drop: {config.max_relative_income_drop:.0%}",
            "",
        ])

        if self.modifier.applied_fixes:
            lines.append("### Agent Modifications")
            for fix in self.modifier.applied_fixes:
                lines.append(
                    f"- **{fix.parameter}**: {fix.old_value} → {fix.new_value} "
                    f"(Iteration {fix.iteration})"
                )
            lines.append("")

        lines.append("---")
        lines.append("*Generated by Tax Optimization Agent*")

        return "\n".join(lines)

    def _generate_failure_summary(self) -> str:
        """Generate PR summary for failed optimization."""
        lines = [
            "## Tax Bracket Optimization - FAILED",
            "",
            f"Optimization did not converge after {len(self.iteration_logs)} iterations.",
            "",
            "### Iteration History",
            "",
        ]

        for log in self.iteration_logs:
            lines.append(
                f"- **Iteration {log.iteration + 1}**: {log.solver_status} "
                f"({log.runtime_seconds:.1f}s)"
            )
            if log.fix_applied:
                lines.append(f"  - Fix: {log.fix_applied}")

        if self.modifier.applied_fixes:
            lines.append("")
            lines.append("### Modifications Attempted")
            for fix in self.modifier.applied_fixes:
                lines.append(
                    f"- {fix.parameter}: {fix.old_value} → {fix.new_value}"
                )

        lines.append("")
        lines.append("---")
        lines.append("*Generated by Tax Optimization Agent*")

        return "\n".join(lines)

    def save_logs(self, output_dir: str):
        """Save all logs to directory."""
        os.makedirs(output_dir, exist_ok=True)

        # Save iteration logs
        with open(os.path.join(output_dir, "iterations.json"), "w") as f:
            json.dump(
                [
                    {
                        "iteration": log.iteration,
                        "timestamp": log.timestamp,
                        "solver_status": log.solver_status,
                        "runtime_seconds": log.runtime_seconds,
                        "analysis_status": log.analysis_status,
                        "fix_applied": log.fix_applied,
                        "objective_value": log.objective_value,
                    }
                    for log in self.iteration_logs
                ],
                f,
                indent=2,
            )

        # Save modifications
        with open(os.path.join(output_dir, "modifications.json"), "w") as f:
            json.dump(self.modifier.get_modification_dict(), f, indent=2)
