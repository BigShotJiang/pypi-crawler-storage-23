"""
SolverWrapper: Structured interface to the Gurobi optimization model.

Provides clean input/output for the optimization agent.
"""

import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from src.data.schemas import OptimizationConfig, PopulationData
from src.optimization.model import TaxOptimizationModel


@dataclass
class SolverResult:
    """Structured result from solver execution."""

    # Status
    status: str  # OPTIMAL, INFEASIBLE, TIME_LIMIT, ERROR, etc.
    success: bool
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    # Performance
    runtime_seconds: float = 0.0
    mip_gap: Optional[float] = None

    # Solution (if optimal)
    objective_value: Optional[float] = None
    solution: Optional[dict] = None

    # Infeasibility info
    iis_constraints: Optional[list[str]] = None
    iis_variables: Optional[list[str]] = None
    iis_summary: Optional[str] = None

    # Model stats
    model_stats: Optional[dict] = None

    # Raw log
    gurobi_log: str = ""

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "status": self.status,
            "success": self.success,
            "timestamp": self.timestamp,
            "runtime_seconds": self.runtime_seconds,
            "mip_gap": self.mip_gap,
            "objective_value": self.objective_value,
            "solution": self.solution,
            "iis_constraints": self.iis_constraints,
            "iis_variables": self.iis_variables,
            "iis_summary": self.iis_summary,
            "model_stats": self.model_stats,
        }

    def to_json(self) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=2)


class SolverWrapper:
    """
    Wrapper around TaxOptimizationModel for agent interaction.

    Provides:
        - Structured input/output
        - Logging
        - Error handling
        - Solution interpretation
    """

    def __init__(self, log_dir: Optional[str] = None):
        self.log_dir = log_dir
        self.last_result: Optional[SolverResult] = None
        self.last_model: Optional[TaxOptimizationModel] = None

    def solve(
        self,
        population: PopulationData,
        config: OptimizationConfig,
    ) -> SolverResult:
        """
        Run the optimization and return structured result.

        Args:
            population: Population data for optimization
            config: Optimization configuration

        Returns:
            SolverResult with status, solution, and diagnostics
        """
        # Build model
        model = TaxOptimizationModel(population, config)
        self.last_model = model

        try:
            model.build()
            model_stats = model.get_model_stats()
        except Exception as e:
            return SolverResult(
                status="BUILD_ERROR",
                success=False,
                gurobi_log=str(e),
            )

        # Solve
        try:
            result = model.solve()
        except Exception as e:
            return SolverResult(
                status="SOLVE_ERROR",
                success=False,
                gurobi_log=str(e),
                model_stats=model_stats,
            )

        # Build structured result
        solver_result = SolverResult(
            status=result.status,
            success=(result.status == "OPTIMAL"),
            runtime_seconds=result.runtime_seconds,
            mip_gap=result.mip_gap,
            objective_value=result.objective_value,
            gurobi_log=result.gurobi_log,
            model_stats=model_stats,
        )

        # Add solution if optimal
        if result.status == "OPTIMAL":
            solver_result.solution = {
                "brackets": {
                    "thresholds": result.bracket_thresholds,
                    "rates": result.bracket_rates,
                    "active": result.bracket_active,
                },
                "budget": {
                    "old_revenue": result.old_revenue,
                    "new_revenue": result.new_revenue,
                    "change": result.budget_change,
                },
            }

        # Add IIS info if infeasible
        if result.status == "INFEASIBLE":
            solver_result.iis_constraints = result.iis_constraints
            solver_result.iis_variables = result.iis_variables
            solver_result.iis_summary = self._summarize_iis(
                result.iis_constraints,
                result.iis_variables,
            )

        self.last_result = solver_result
        return solver_result

    def _summarize_iis(
        self,
        constraints: Optional[list[str]],
        variables: Optional[list[str]],
    ) -> str:
        """Generate human-readable IIS summary."""
        lines = ["Infeasibility Analysis (IIS):"]

        if constraints:
            lines.append(f"\nConflicting constraints ({len(constraints)}):")

            # Group by type
            budget_constr = [c for c in constraints if "budget" in c.lower()]
            marginal_constr = [c for c in constraints if "marginal" in c.lower()]
            income_drop = [c for c in constraints if "income_drop" in c.lower()]
            bracket_constr = [c for c in constraints if "bracket" in c.lower() or "rate" in c.lower()]
            other = [
                c
                for c in constraints
                if c not in budget_constr + marginal_constr + income_drop + bracket_constr
            ]

            if budget_constr:
                lines.append(f"  - Budget constraints: {len(budget_constr)}")
            if marginal_constr:
                lines.append(f"  - Marginal pressure: {len(marginal_constr)}")
            if income_drop:
                lines.append(f"  - Income drop protection: {len(income_drop)}")
            if bracket_constr:
                lines.append(f"  - Bracket constraints: {len(bracket_constr)}")
            if other:
                lines.append(f"  - Other: {len(other)}")

        if variables:
            lines.append(f"\nConflicting variable bounds ({len(variables)}):")
            # Just show first few
            for v in variables[:5]:
                lines.append(f"  - {v}")
            if len(variables) > 5:
                lines.append(f"  ... and {len(variables) - 5} more")

        return "\n".join(lines)

    def get_solution_summary(self) -> str:
        """Get human-readable summary of last solution."""
        if self.last_result is None:
            return "No solution available"

        r = self.last_result
        lines = [f"Optimization Result: {r.status}"]
        lines.append(f"Runtime: {r.runtime_seconds:.2f}s")

        if r.success and r.solution:
            sol = r.solution
            lines.append(f"\nObjective Value: {r.objective_value:.4f}")

            if "brackets" in sol:
                lines.append("\nTax Brackets:")
                thresholds = sol["brackets"]["thresholds"]
                rates = sol["brackets"]["rates"]
                active = sol["brackets"]["active"]

                for i, (t, rate, a) in enumerate(zip(thresholds, rates, active)):
                    status = "ACTIVE" if a else "inactive"
                    lines.append(f"  Bracket {i + 1}: €{t:,.0f}+ @ {rate:.1%} [{status}]")

            if "budget" in sol:
                b = sol["budget"]
                lines.append("\nBudget Impact:")
                lines.append(f"  Old Revenue: €{b['old_revenue']:,.0f}")
                lines.append(f"  New Revenue: €{b['new_revenue']:,.0f}")
                lines.append(f"  Change: €{b['change']:,.0f}")

        elif r.status == "INFEASIBLE" and r.iis_summary:
            lines.append(f"\n{r.iis_summary}")

        return "\n".join(lines)
