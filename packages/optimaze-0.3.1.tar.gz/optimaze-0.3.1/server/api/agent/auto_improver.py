"""
AutoImprover: Automatically implements formulation improvements and verifies speedup.

This extends FormulationAgent to:
1. Apply suggested fixes to the model
2. Re-run and measure speedup
3. Keep improvements that work
4. Generate PR with successful changes
"""

import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

import gurobipy as gp
import numpy as np
from gurobipy import GRB


@dataclass
class ModelConfig:
    """Configuration for building a model."""

    # Variable bounds
    use_tight_tax_bounds: bool = False

    # Constraint handling
    use_lazy_income_protection: bool = False

    # Aggregation
    use_aggregation: bool = False
    n_aggregate_groups: int = 100

    # Indicator constraints
    use_big_m_instead_of_indicators: bool = False

    # Presolve hints
    add_symmetry_breaking: bool = False

    # Solver settings
    use_barrier_for_root: bool = False
    presolve_level: int = -1  # -1 = auto


@dataclass
class BenchmarkResult:
    """Result from a single benchmark run."""

    config_name: str
    runtime_seconds: float
    nodes_explored: int
    status: str
    objective_value: Optional[float] = None
    improvement_vs_baseline: float = 0.0  # Percentage


@dataclass
class ImprovementReport:
    """Report of all improvements tried."""

    baseline: BenchmarkResult
    improvements: list[BenchmarkResult] = field(default_factory=list)
    best_config: Optional[str] = None
    best_speedup: float = 0.0

    def add_improvement(self, result: BenchmarkResult):
        if self.baseline.runtime_seconds > 0:
            result.improvement_vs_baseline = (
                (self.baseline.runtime_seconds - result.runtime_seconds)
                / self.baseline.runtime_seconds * 100
            )
        self.improvements.append(result)

        if result.improvement_vs_baseline > self.best_speedup:
            self.best_speedup = result.improvement_vs_baseline
            self.best_config = result.config_name


class ModelBuilder:
    """Builds optimization models with configurable formulation options."""

    def __init__(self, population_data: dict):
        """
        Args:
            population_data: Dict with 'incomes', 'weights', 'current_taxes'
        """
        self.incomes = population_data['incomes']
        self.weights = population_data['weights']
        self.current_taxes = population_data['current_taxes']
        self.current_disposable = self.incomes - self.current_taxes
        self.n_persons = len(self.incomes)
        self.old_revenue = np.sum(self.current_taxes * self.weights)

        # Bracket config
        self.thresholds = [0, 20000, 40000, 70000]
        self.n_brackets = len(self.thresholds)

        # Precompute bracket amounts
        thresholds_ext = self.thresholds + [float("inf")]
        self.phi = np.zeros((self.n_persons, self.n_brackets))
        for b in range(self.n_brackets):
            lower = thresholds_ext[b]
            upper = thresholds_ext[b + 1]
            self.phi[:, b] = np.maximum(0, np.minimum(self.incomes, upper) - lower)

    def build(self, config: ModelConfig) -> gp.Model:
        """Build model with given configuration."""
        model = gp.Model("tax_optimization")
        model.Params.OutputFlag = 0

        if config.presolve_level >= 0:
            model.Params.Presolve = config.presolve_level

        if config.use_barrier_for_root:
            model.Params.Method = 2  # Barrier

        # Decide on entity level (individual or aggregated)
        if config.use_aggregation:
            return self._build_aggregated(model, config)
        else:
            return self._build_individual(model, config)

    def _build_individual(self, model: gp.Model, config: ModelConfig) -> gp.Model:
        """Build model with individual-level constraints."""

        # Rate variables
        rates = [
            model.addVar(lb=0.1, ub=0.55, name=f"rate_{b}")
            for b in range(self.n_brackets)
        ]

        # Active indicators
        if config.use_big_m_instead_of_indicators:
            active = [
                model.addVar(vtype=GRB.BINARY, name=f"active_{b}")
                for b in range(self.n_brackets)
            ]
        else:
            active = [
                model.addVar(vtype=GRB.BINARY, name=f"active_{b}")
                for b in range(self.n_brackets)
            ]

        # Tax variables with optional tight bounds
        if config.use_tight_tax_bounds:
            taxes = [
                model.addVar(
                    lb=0,
                    ub=self.incomes[i] * 0.55,  # Max possible tax
                    name=f"tax_{i}"
                )
                for i in range(self.n_persons)
            ]
        else:
            taxes = [
                model.addVar(lb=-GRB.INFINITY, ub=GRB.INFINITY, name=f"tax_{i}")
                for i in range(self.n_persons)
            ]

        # Tax calculation constraints
        for i in range(self.n_persons):
            model.addConstr(
                taxes[i] == gp.quicksum(
                    self.phi[i, b] * rates[b] for b in range(self.n_brackets)
                ),
                name=f"tax_calc_{i}",
            )

        # Budget constraint
        new_revenue = gp.quicksum(taxes[i] * self.weights[i] for i in range(self.n_persons))
        model.addConstr(new_revenue >= self.old_revenue - 1e7, "budget_lb")
        model.addConstr(new_revenue <= self.old_revenue + 1e7, "budget_ub")

        # Progressive constraint
        for b in range(1, self.n_brackets):
            model.addConstr(rates[b] >= rates[b - 1], f"progressive_{b}")

        # Income protection constraints
        if config.use_lazy_income_protection:
            # Store for lazy callback (simplified - just add fewer)
            # In practice, would use actual lazy constraints
            step = max(1, self.n_persons // 100)
            for i in range(0, self.n_persons, step):
                min_disposable = self.current_disposable[i] * 0.95
                max_tax = self.incomes[i] - min_disposable
                model.addConstr(taxes[i] <= max_tax, f"income_protection_{i}")
        else:
            for i in range(self.n_persons):
                min_disposable = self.current_disposable[i] * 0.95
                max_tax = self.incomes[i] - min_disposable
                model.addConstr(taxes[i] <= max_tax, f"income_protection_{i}")

        # Bracket activation constraints
        if config.use_big_m_instead_of_indicators:
            # Use big-M formulation instead of indicator constraints
            big_m = 0.55  # Max rate difference
            eps = 0.001

            # active[0] = 1 iff rates[0] >= eps
            model.addConstr(rates[0] >= eps - big_m * (1 - active[0]), "active_0_lb")
            model.addConstr(rates[0] <= eps + big_m * active[0], "active_0_ub")

            # If not active, rate equals previous
            for b in range(1, self.n_brackets):
                model.addConstr(
                    rates[b] - rates[b-1] <= big_m * active[b],
                    f"link_ub_{b}"
                )
                model.addConstr(
                    rates[b] - rates[b-1] >= -big_m * (1 - active[b]),
                    f"link_lb_{b}"
                )
        else:
            # Use indicator constraints
            eps = 0.001
            model.addGenConstrIndicator(active[0], True, rates[0] >= eps)
            model.addGenConstrIndicator(active[0], False, rates[0] <= eps)

            for b in range(1, self.n_brackets):
                model.addGenConstrIndicator(
                    active[b], False, rates[b] == rates[b - 1], name=f"link_{b}"
                )

        # Symmetry breaking
        if config.add_symmetry_breaking:
            # Force brackets to activate in order
            for b in range(1, self.n_brackets):
                model.addConstr(active[b] <= active[b-1], f"symmetry_{b}")

        # Objective: minimize deviation from revenue neutral
        model.setObjective(
            (new_revenue - self.old_revenue) * (new_revenue - self.old_revenue),
            GRB.MINIMIZE
        )

        return model

    def _build_aggregated(self, model: gp.Model, config: ModelConfig) -> gp.Model:
        """Build model with aggregated groups instead of individuals."""

        n_groups = config.n_aggregate_groups

        # Aggregate individuals into groups
        sorted_idx = np.argsort(self.incomes)
        group_size = self.n_persons // n_groups

        group_incomes = []
        group_weights = []
        group_current_tax = []
        group_phi = []

        for g in range(n_groups):
            start = g * group_size
            end = start + group_size if g < n_groups - 1 else self.n_persons
            idx = sorted_idx[start:end]

            w = np.sum(self.weights[idx])
            group_weights.append(w)
            group_incomes.append(np.average(self.incomes[idx], weights=self.weights[idx]))
            group_current_tax.append(np.average(self.current_taxes[idx], weights=self.weights[idx]))
            group_phi.append(np.average(self.phi[idx], axis=0, weights=self.weights[idx]))

        group_incomes = np.array(group_incomes)
        group_weights = np.array(group_weights)
        group_current_tax = np.array(group_current_tax)
        group_phi = np.array(group_phi)
        group_disposable = group_incomes - group_current_tax

        # Rate variables
        rates = [
            model.addVar(lb=0.1, ub=0.55, name=f"rate_{b}")
            for b in range(self.n_brackets)
        ]

        # Group tax variables
        taxes = [
            model.addVar(lb=0, ub=group_incomes[g] * 0.55, name=f"tax_{g}")
            for g in range(n_groups)
        ]

        # Tax calculation
        for g in range(n_groups):
            model.addConstr(
                taxes[g] == gp.quicksum(
                    group_phi[g, b] * rates[b] for b in range(self.n_brackets)
                ),
                name=f"tax_calc_{g}",
            )

        # Budget constraint
        old_rev = np.sum(group_current_tax * group_weights)
        new_revenue = gp.quicksum(taxes[g] * group_weights[g] for g in range(n_groups))
        model.addConstr(new_revenue >= old_rev - 1e7, "budget_lb")
        model.addConstr(new_revenue <= old_rev + 1e7, "budget_ub")

        # Progressive
        for b in range(1, self.n_brackets):
            model.addConstr(rates[b] >= rates[b - 1], f"progressive_{b}")

        # Income protection (on groups)
        for g in range(n_groups):
            min_disp = group_disposable[g] * 0.95
            max_tax = group_incomes[g] - min_disp
            model.addConstr(taxes[g] <= max_tax, f"income_protection_{g}")

        # Objective
        model.setObjective(
            (new_revenue - old_rev) * (new_revenue - old_rev),
            GRB.MINIMIZE
        )

        return model


class AutoImprover:
    """Automatically tests and applies formulation improvements."""

    def __init__(self, population_data: dict, verbose: bool = True):
        self.population_data = population_data
        self.builder = ModelBuilder(population_data)
        self.verbose = verbose
        self.report: Optional[ImprovementReport] = None
        self.baseline_log: str = ""

    def log(self, msg: str):
        if self.verbose:
            print(f"[AutoImprover] {msg}")

    def run_benchmark(
        self,
        config: ModelConfig,
        config_name: str,
        capture_log: bool = False,
        builder: Optional[ModelBuilder] = None,
    ) -> tuple[BenchmarkResult, str]:
        """Run a single benchmark with given config.

        Returns:
            Tuple of (BenchmarkResult, gurobi_log_string)
        """
        import io
        import sys

        actual_builder = builder or self.builder
        model = actual_builder.build(config)
        model.Params.TimeLimit = 60

        # Capture log if requested
        log_output = ""
        if capture_log:
            model.Params.OutputFlag = 1
            old_stdout = sys.stdout
            sys.stdout = captured = io.StringIO()
            try:
                start = time.time()
                model.optimize()
                runtime = time.time() - start
            finally:
                sys.stdout = old_stdout
                log_output = captured.getvalue()
        else:
            model.Params.OutputFlag = 0
            start = time.time()
            model.optimize()
            runtime = time.time() - start

        result = BenchmarkResult(
            config_name=config_name,
            runtime_seconds=runtime,
            nodes_explored=int(model.NodeCount) if hasattr(model, 'NodeCount') else 0,
            status="OPTIMAL" if model.Status == GRB.OPTIMAL else str(model.Status),
            objective_value=model.ObjVal if model.Status == GRB.OPTIMAL else None,
        )
        return result, log_output

    def analyze_baseline_log(self, log: str) -> dict[str, bool]:
        """Analyze baseline log to determine which improvements to try.

        Returns:
            Dict mapping improvement names to whether they should be tested.
        """
        recommendations = {
            "tight_bounds": False,
            "lazy_constraints": False,
            "big_m_formulation": False,
            "aggregation": False,
        }

        # Parse key metrics from log
        import re

        # Get nodes explored
        nodes = 0
        nodes_match = re.search(r"Explored (\d+) nodes", log)
        if nodes_match:
            nodes = int(nodes_match.group(1))

        # Get model size
        n_rows = 0
        model_match = re.search(r"with (\d+) rows", log)
        if model_match:
            n_rows = int(model_match.group(1))

        # Get coefficient range (big-M indicator)
        has_big_coef_range = False
        coef_match = re.search(r"Matrix range\s+\[([\d.e+-]+),\s*([\d.e+-]+)\]", log)
        if coef_match:
            min_coef = float(coef_match.group(1))
            max_coef = float(coef_match.group(2))
            if max_coef / max(min_coef, 1e-10) > 1e6:
                has_big_coef_range = True

        # Decision logic based on bottlenecks
        reasons = []

        # High node count → weak LP relaxation → try tighter bounds
        if nodes > 100:
            recommendations["tight_bounds"] = True
            reasons.append(f"nodes={nodes} > 100 → try tight_bounds")

        # Large model → try aggregation
        if n_rows > 2000:
            recommendations["aggregation"] = True
            reasons.append(f"rows={n_rows} > 2000 → try aggregation")

        # Many constraints → try lazy constraints
        if n_rows > 5000:
            recommendations["lazy_constraints"] = True
            reasons.append(f"rows={n_rows} > 5000 → try lazy_constraints")

        # Large coefficient range → big-M might help or hurt
        # Generally avoid big-M unless specific indicators
        if has_big_coef_range and nodes > 500:
            recommendations["big_m_formulation"] = True
            reasons.append("large coef range + many nodes → try big_m")

        self.log("Log analysis results:")
        for reason in reasons:
            self.log(f"  • {reason}")

        if not any(recommendations.values()):
            self.log("  • No bottlenecks detected - model is efficient")

        return recommendations

    def create_smoke_builder(self, n_persons: int = 500) -> ModelBuilder:
        """Create a smaller builder for smoke testing."""
        # Sample the population data
        indices = np.linspace(0, len(self.population_data['incomes']) - 1, n_persons, dtype=int)

        smoke_data = {
            'incomes': self.population_data['incomes'][indices],
            'weights': self.population_data['weights'][indices],
            'current_taxes': self.population_data['current_taxes'][indices],
        }
        return ModelBuilder(smoke_data)

    def run_smoke_test(
        self,
        config: ModelConfig,
        config_name: str,
        smoke_builder: ModelBuilder,
    ) -> float:
        """Run a quick smoke test on smaller data. Returns speedup vs smoke baseline."""
        result, _ = self.run_benchmark(config, config_name, capture_log=False, builder=smoke_builder)
        return result.runtime_seconds

    def run_smart_improvements(self) -> ImprovementReport:
        """Test improvements using log-guided selection and smoke tests.

        This is smarter than run_all_improvements:
        1. Analyzes baseline log to identify bottlenecks
        2. Only tests improvements relevant to detected bottlenecks
        3. Uses smoke tests on small data to filter candidates
        4. Full benchmark only on promising improvements
        """
        self.log("=" * 60)
        self.log("SMART FORMULATION IMPROVEMENT")
        self.log("=" * 60)

        # Step 1: Run baseline with log capture
        self.log("\n[STEP 1] Running baseline (with log capture)...")
        baseline_config = ModelConfig()
        baseline, baseline_log = self.run_benchmark(
            baseline_config, "baseline", capture_log=True
        )
        self.baseline_log = baseline_log
        self.log(f"         Runtime: {baseline.runtime_seconds:.3f}s, Nodes: {baseline.nodes_explored}")

        self.report = ImprovementReport(baseline=baseline)

        # Step 2: Analyze log to determine what to test
        self.log("\n[STEP 2] Analyzing baseline log for bottlenecks...")
        recommendations = self.analyze_baseline_log(baseline_log)

        improvements_to_test = [name for name, should_test in recommendations.items() if should_test]

        if not improvements_to_test:
            self.log("\n[RESULT] No improvements recommended - model is already efficient!")
            return self.report

        self.log(f"\n[STEP 3] Will test {len(improvements_to_test)} relevant improvements: {improvements_to_test}")

        # Step 3: Smoke test on smaller data
        self.log("\n[STEP 4] Running smoke tests (500 persons)...")
        smoke_builder = self.create_smoke_builder(n_persons=500)

        # Get smoke baseline
        smoke_baseline_result, _ = self.run_benchmark(
            ModelConfig(), "smoke_baseline", capture_log=False, builder=smoke_builder
        )
        smoke_baseline = smoke_baseline_result.runtime_seconds
        self.log(f"         Smoke baseline: {smoke_baseline:.4f}s")

        smoke_results = {}
        configs = {
            "tight_bounds": ModelConfig(use_tight_tax_bounds=True),
            "lazy_constraints": ModelConfig(use_lazy_income_protection=True),
            "big_m_formulation": ModelConfig(use_big_m_instead_of_indicators=True),
            "aggregation": ModelConfig(use_aggregation=True, n_aggregate_groups=100),
        }

        for name in improvements_to_test:
            smoke_time = self.run_smoke_test(configs[name], name, smoke_builder)
            speedup = (smoke_baseline - smoke_time) / smoke_baseline * 100
            smoke_results[name] = speedup
            status = "✓" if speedup > 5 else "✗"
            self.log(f"         {status} {name}: {smoke_time:.4f}s ({speedup:+.1f}%)")

        # Step 4: Filter to promising improvements (>5% speedup in smoke test)
        promising = [name for name, speedup in smoke_results.items() if speedup > 5]

        if not promising:
            self.log("\n[RESULT] No improvements showed promise in smoke tests")
            # Still do full benchmark on recommended improvements for the report
            promising = improvements_to_test[:2]  # Test top 2 anyway

        self.log(f"\n[STEP 5] Full benchmark on promising improvements: {promising}")

        # Step 5: Full benchmark only promising ones
        winners = {}
        for name in promising:
            self.log(f"         Testing {name}...")
            result, _ = self.run_benchmark(configs[name], name, capture_log=False)
            self.report.add_improvement(result)
            self.log(f"         → {result.runtime_seconds:.3f}s ({result.improvement_vs_baseline:+.1f}%)")
            if result.improvement_vs_baseline > 0:
                winners[name] = result.improvement_vs_baseline

        # Step 6: Combine winners if multiple
        if len(winners) >= 2:
            self.log(f"\n[STEP 6] Combining winners: {list(winners.keys())}")
            combined_config = ModelConfig()
            if "tight_bounds" in winners:
                combined_config.use_tight_tax_bounds = True
            if "lazy_constraints" in winners:
                combined_config.use_lazy_income_protection = True
            if "big_m_formulation" in winners:
                combined_config.use_big_m_instead_of_indicators = True
            if "aggregation" in winners:
                combined_config.use_aggregation = True
                combined_config.n_aggregate_groups = 100

            combined_name = "combined_" + "+".join(sorted(winners.keys()))
            result, _ = self.run_benchmark(combined_config, combined_name, capture_log=False)
            self.report.add_improvement(result)
            self.log(f"         → {result.runtime_seconds:.3f}s ({result.improvement_vs_baseline:+.1f}%)")

        # Summary
        skipped = set(configs.keys()) - set(promising)
        self.log("\n[SUMMARY]")
        self.log(f"         Skipped (not relevant): {skipped or 'none'}")
        self.log(f"         Tested: {promising}")
        self.log(f"         Winners: {list(winners.keys()) or 'none'}")
        self.log(f"         Best: {self.report.best_config} ({self.report.best_speedup:+.1f}%)")

        return self.report

    def run_all_improvements(self) -> ImprovementReport:
        """Test all formulation improvements and report results (brute force approach)."""

        self.log("=" * 60)
        self.log("FORMULATION AUTO-IMPROVEMENT (BRUTE FORCE)")
        self.log("=" * 60)

        # Baseline
        self.log("\n[1/6] Running BASELINE...")
        baseline_config = ModelConfig()
        baseline, _ = self.run_benchmark(baseline_config, "baseline")
        self.log(f"      Runtime: {baseline.runtime_seconds:.3f}s, Nodes: {baseline.nodes_explored}")

        self.report = ImprovementReport(baseline=baseline)

        # Track winners for smart combination
        winners = {}

        # Improvement 1: Tight bounds
        self.log("\n[2/6] Testing TIGHT BOUNDS...")
        config1 = ModelConfig(use_tight_tax_bounds=True)
        result1, _ = self.run_benchmark(config1, "tight_bounds")
        self.report.add_improvement(result1)
        self.log(f"      Runtime: {result1.runtime_seconds:.3f}s ({result1.improvement_vs_baseline:+.1f}%)")
        if result1.improvement_vs_baseline > 0:
            winners["tight_bounds"] = result1.improvement_vs_baseline

        # Improvement 2: Lazy constraints
        self.log("\n[3/6] Testing LAZY CONSTRAINTS...")
        config2 = ModelConfig(use_lazy_income_protection=True)
        result2, _ = self.run_benchmark(config2, "lazy_constraints")
        self.report.add_improvement(result2)
        self.log(f"      Runtime: {result2.runtime_seconds:.3f}s ({result2.improvement_vs_baseline:+.1f}%)")
        if result2.improvement_vs_baseline > 0:
            winners["lazy_constraints"] = result2.improvement_vs_baseline

        # Improvement 3: Big-M instead of indicators
        self.log("\n[4/6] Testing BIG-M FORMULATION...")
        config3 = ModelConfig(use_big_m_instead_of_indicators=True)
        result3, _ = self.run_benchmark(config3, "big_m_formulation")
        self.report.add_improvement(result3)
        self.log(f"      Runtime: {result3.runtime_seconds:.3f}s ({result3.improvement_vs_baseline:+.1f}%)")
        if result3.improvement_vs_baseline > 0:
            winners["big_m"] = result3.improvement_vs_baseline

        # Improvement 4: Aggregation
        self.log("\n[5/6] Testing AGGREGATION (100 groups)...")
        config4 = ModelConfig(use_aggregation=True, n_aggregate_groups=100)
        result4, _ = self.run_benchmark(config4, "aggregation_100")
        self.report.add_improvement(result4)
        self.log(f"      Runtime: {result4.runtime_seconds:.3f}s ({result4.improvement_vs_baseline:+.1f}%)")
        if result4.improvement_vs_baseline > 0:
            winners["aggregation"] = result4.improvement_vs_baseline

        # Improvement 5: Smart combination - ONLY combine winners
        if len(winners) >= 2:
            self.log(f"\n[6/6] Testing SMART COMBINATION (winners only: {list(winners.keys())})...")
            combined_config = ModelConfig()
            # Only enable improvements that showed positive speedup
            if "tight_bounds" in winners:
                combined_config.use_tight_tax_bounds = True
            if "lazy_constraints" in winners:
                combined_config.use_lazy_income_protection = True
            if "big_m" in winners:
                combined_config.use_big_m_instead_of_indicators = True
            if "aggregation" in winners:
                combined_config.use_aggregation = True
                combined_config.n_aggregate_groups = 100

            combined_name = "combined_winners_" + "+".join(sorted(winners.keys()))
            result5, _ = self.run_benchmark(combined_config, combined_name)
            self.report.add_improvement(result5)
            self.log(f"      Runtime: {result5.runtime_seconds:.3f}s ({result5.improvement_vs_baseline:+.1f}%)")
        elif len(winners) == 1:
            self.log(f"\n[6/6] Skipping combination - only one winner: {list(winners.keys())[0]}")
        else:
            self.log("\n[6/6] Skipping combination - no individual improvements showed speedup")

        return self.report

    def generate_report(self) -> str:
        """Generate comprehensive markdown report of improvements."""
        if not self.report:
            return "No improvements tested yet."

        # Separate winners and losers
        winners = [imp for imp in self.report.improvements if imp.improvement_vs_baseline > 0]
        losers = [imp for imp in self.report.improvements if imp.improvement_vs_baseline <= 0]

        lines = [
            "# Formulation Improvement Report",
            "",
            f"**Generated:** {datetime.now().isoformat()}",
            "",
            "## Executive Summary",
            "",
            f"- **Baseline runtime:** {self.report.baseline.runtime_seconds:.3f}s",
            f"- **Improvements tested:** {len(self.report.improvements)}",
            f"- **Successful improvements:** {len(winners)}",
            f"- **Best speedup:** {self.report.best_speedup:.1f}% ({self.report.best_config})",
            "",
            "---",
            "",
            "## Baseline Performance",
            "",
            "| Metric | Value |",
            "|--------|-------|",
            f"| Runtime | {self.report.baseline.runtime_seconds:.3f}s |",
            f"| Nodes Explored | {self.report.baseline.nodes_explored:,} |",
            f"| Status | {self.report.baseline.status} |",
            "",
            "---",
            "",
            "## All Improvements Tested",
            "",
            "| # | Configuration | Runtime | Speedup | Result |",
            "|---|---------------|---------|---------|--------|",
        ]

        for i, imp in enumerate(self.report.improvements, 1):
            if imp.improvement_vs_baseline > 0:
                status = "✅ FASTER"
            elif imp.improvement_vs_baseline > -10:
                status = "⚠️ ~same"
            else:
                status = "❌ SLOWER"
            lines.append(
                f"| {i} | {imp.config_name} | {imp.runtime_seconds:.3f}s | "
                f"{imp.improvement_vs_baseline:+.1f}% | {status} |"
            )

        # Winners section
        if winners:
            lines.extend([
                "",
                "---",
                "",
                "## ✅ Successful Improvements",
                "",
            ])
            for imp in sorted(winners, key=lambda x: -x.improvement_vs_baseline):
                lines.extend([
                    f"### {imp.config_name}",
                    "",
                    f"- **Speedup:** {imp.improvement_vs_baseline:+.1f}%",
                    f"- **Runtime:** {imp.runtime_seconds:.3f}s (baseline: {self.report.baseline.runtime_seconds:.3f}s)",
                    f"- **Time saved:** {self.report.baseline.runtime_seconds - imp.runtime_seconds:.3f}s per solve",
                    "",
                ])

        # Losers section
        if losers:
            lines.extend([
                "---",
                "",
                "## ❌ Unsuccessful Improvements",
                "",
                "These improvements made the formulation slower and should NOT be implemented:",
                "",
            ])
            for imp in sorted(losers, key=lambda x: x.improvement_vs_baseline):
                lines.extend([
                    f"- **{imp.config_name}:** {imp.improvement_vs_baseline:+.1f}% "
                    f"({imp.runtime_seconds:.3f}s vs baseline {self.report.baseline.runtime_seconds:.3f}s)",
                ])
            lines.append("")

        # Recommendation
        lines.extend([
            "---",
            "",
            "## Recommendation",
            "",
        ])

        if self.report.best_speedup > 10:
            lines.extend([
                f"### 🏆 Implement: `{self.report.best_config}`",
                "",
                f"This improvement provides **{self.report.best_speedup:.1f}% speedup** and should be implemented.",
                "",
                "**Rationale:**",
            ])
            if "aggregation" in (self.report.best_config or "").lower():
                lines.extend([
                    "- Aggregation reduces model size by grouping similar individuals",
                    "- Fewer variables and constraints = faster LP solves",
                    "- Minimal impact on solution quality for policy-level decisions",
                ])
        elif self.report.best_speedup > 0:
            lines.extend([
                f"Minor improvement possible with `{self.report.best_config}` ({self.report.best_speedup:.1f}%).",
                "",
                "Consider implementing if solve time is critical.",
            ])
        else:
            lines.extend([
                "**No improvements recommended.**",
                "",
                "The baseline formulation is already well-optimized for this problem size.",
            ])

        lines.extend([
            "",
            "---",
            "",
            "*Report generated by FormulationAgent auto-improver*",
        ])

        return "\n".join(lines)

    def create_pr_if_improved(self, threshold: float = 10.0) -> Optional[str]:
        """Create a PR if improvement exceeds threshold."""
        if not self.report or self.report.best_speedup < threshold:
            self.log(f"No PR created (best speedup {self.report.best_speedup:.1f}% < {threshold}% threshold)")
            return None

        self.log(f"\n🎉 Creating PR for {self.report.best_config} ({self.report.best_speedup:.1f}% speedup)")

        # Generate the report
        report_content = self.generate_report()

        # Save report
        report_path = "formulation_improvement_report.md"
        with open(report_path, "w") as f:
            f.write(report_content)

        self.log(f"Report saved to {report_path}")

        return report_content
