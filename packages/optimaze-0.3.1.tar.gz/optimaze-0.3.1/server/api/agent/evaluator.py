"""
SolutionEvaluator: Computes distributional metrics for tax solutions.

Analyzes the impact of a tax solution across income groups.
"""

from dataclasses import dataclass

import numpy as np
from src.data.schemas import PopulationData


@dataclass
class DistributionalMetrics:
    """Metrics measuring distributional impact of a tax solution."""

    # Overall metrics
    total_revenue_old: float
    total_revenue_new: float
    revenue_change: float
    revenue_change_pct: float

    # Progressivity
    gini_before: float
    gini_after: float
    gini_change: float
    kakwani_index: float  # Progressivity measure

    # Quintile analysis
    quintile_avg_income: list[float]  # Q1 to Q5
    quintile_avg_tax_old: list[float]
    quintile_avg_tax_new: list[float]
    quintile_tax_change: list[float]
    quintile_tax_change_pct: list[float]
    quintile_effective_rate_old: list[float]
    quintile_effective_rate_new: list[float]

    # Winners/losers
    n_winners: int  # People paying less
    n_losers: int  # People paying more
    n_unchanged: int
    pct_winners: float
    pct_losers: float
    avg_gain_winners: float
    avg_loss_losers: float

    # Income protection
    max_income_drop_pct: float
    n_violating_threshold: int  # People with drops > threshold


class SolutionEvaluator:
    """
    Evaluates tax solutions and computes distributional metrics.
    """

    def __init__(self, income_drop_threshold: float = 0.05):
        """
        Args:
            income_drop_threshold: Maximum acceptable income drop (for violation counting)
        """
        self.income_drop_threshold = income_drop_threshold

    def evaluate(
        self,
        population: PopulationData,
        old_taxes: np.ndarray,
        new_taxes: np.ndarray,
    ) -> DistributionalMetrics:
        """
        Evaluate a tax solution.

        Args:
            population: Population data
            old_taxes: Array of current tax liabilities
            new_taxes: Array of new tax liabilities

        Returns:
            DistributionalMetrics with full analysis
        """
        incomes = np.array([p.gross_income for p in population.persons])
        weights = np.array([p.weight for p in population.persons])

        # Disposable incomes
        disposable_old = incomes - old_taxes
        disposable_new = incomes - new_taxes

        # Revenue
        total_revenue_old = np.sum(old_taxes * weights)
        total_revenue_new = np.sum(new_taxes * weights)
        revenue_change = total_revenue_new - total_revenue_old

        # Gini coefficients
        gini_before = self._compute_gini(disposable_old, weights)
        gini_after = self._compute_gini(disposable_new, weights)

        # Kakwani progressivity index
        kakwani = self._compute_kakwani(incomes, new_taxes, weights, gini_before)

        # Quintile analysis
        quintiles = self._compute_quintile_metrics(
            incomes, old_taxes, new_taxes, weights
        )

        # Winners/losers
        tax_diff = new_taxes - old_taxes
        tolerance = 1.0  # €1 tolerance

        winners_mask = tax_diff < -tolerance
        losers_mask = tax_diff > tolerance
        unchanged_mask = ~winners_mask & ~losers_mask

        n_winners = int(np.sum(weights[winners_mask]))
        n_losers = int(np.sum(weights[losers_mask]))
        n_unchanged = int(np.sum(weights[unchanged_mask]))
        total_pop = n_winners + n_losers + n_unchanged

        avg_gain = np.average(-tax_diff[winners_mask], weights=weights[winners_mask]) if np.any(winners_mask) else 0
        avg_loss = np.average(tax_diff[losers_mask], weights=weights[losers_mask]) if np.any(losers_mask) else 0

        # Income protection
        income_drop_pct = (disposable_old - disposable_new) / np.maximum(disposable_old, 1)
        max_drop = np.max(income_drop_pct)
        n_violating = int(np.sum(weights[income_drop_pct > self.income_drop_threshold]))

        return DistributionalMetrics(
            total_revenue_old=total_revenue_old,
            total_revenue_new=total_revenue_new,
            revenue_change=revenue_change,
            revenue_change_pct=revenue_change / max(total_revenue_old, 1) * 100,
            gini_before=gini_before,
            gini_after=gini_after,
            gini_change=gini_after - gini_before,
            kakwani_index=kakwani,
            quintile_avg_income=quintiles["avg_income"],
            quintile_avg_tax_old=quintiles["avg_tax_old"],
            quintile_avg_tax_new=quintiles["avg_tax_new"],
            quintile_tax_change=quintiles["tax_change"],
            quintile_tax_change_pct=quintiles["tax_change_pct"],
            quintile_effective_rate_old=quintiles["eff_rate_old"],
            quintile_effective_rate_new=quintiles["eff_rate_new"],
            n_winners=n_winners,
            n_losers=n_losers,
            n_unchanged=n_unchanged,
            pct_winners=n_winners / max(total_pop, 1) * 100,
            pct_losers=n_losers / max(total_pop, 1) * 100,
            avg_gain_winners=avg_gain,
            avg_loss_losers=avg_loss,
            max_income_drop_pct=max_drop * 100,
            n_violating_threshold=n_violating,
        )

    def _compute_gini(self, incomes: np.ndarray, weights: np.ndarray) -> float:
        """Compute weighted Gini coefficient."""
        # Sort by income
        sorted_idx = np.argsort(incomes)
        sorted_incomes = incomes[sorted_idx]
        sorted_weights = weights[sorted_idx]

        # Cumulative weights and income
        cum_weights = np.cumsum(sorted_weights)
        cum_income = np.cumsum(sorted_incomes * sorted_weights)

        total_weight = cum_weights[-1]
        total_income = cum_income[-1]

        if total_income == 0:
            return 0.0

        # Normalize
        cum_weight_pct = cum_weights / total_weight
        cum_income_pct = cum_income / total_income

        # Area under Lorenz curve
        # Use np.trapezoid (numpy 2.0+) or fall back to np.trapz
        try:
            lorenz_area = np.trapezoid(cum_income_pct, cum_weight_pct)
        except AttributeError:
            lorenz_area = np.trapz(cum_income_pct, cum_weight_pct)

        # Gini = 1 - 2 * area under Lorenz curve
        gini = 1 - 2 * lorenz_area
        return max(0, min(1, gini))

    def _compute_kakwani(
        self,
        incomes: np.ndarray,
        taxes: np.ndarray,
        weights: np.ndarray,
        gini_income: float,
    ) -> float:
        """
        Compute Kakwani progressivity index.

        K = concentration_index(taxes) - gini(income)
        K > 0: Progressive (rich pay proportionally more)
        K = 0: Proportional
        K < 0: Regressive
        """
        # Concentration index of taxes
        sorted_idx = np.argsort(incomes)  # Sort by income, not by taxes
        sorted_taxes = taxes[sorted_idx]
        sorted_weights = weights[sorted_idx]

        cum_weights = np.cumsum(sorted_weights)
        cum_taxes = np.cumsum(sorted_taxes * sorted_weights)

        total_weight = cum_weights[-1]
        total_taxes = cum_taxes[-1]

        if total_taxes == 0:
            return 0.0

        cum_weight_pct = cum_weights / total_weight
        cum_tax_pct = cum_taxes / total_taxes

        try:
            concentration_area = np.trapezoid(cum_tax_pct, cum_weight_pct)
        except AttributeError:
            concentration_area = np.trapz(cum_tax_pct, cum_weight_pct)
        concentration_index = 1 - 2 * concentration_area

        return concentration_index - gini_income

    def _compute_quintile_metrics(
        self,
        incomes: np.ndarray,
        old_taxes: np.ndarray,
        new_taxes: np.ndarray,
        weights: np.ndarray,
    ) -> dict:
        """Compute metrics by income quintile."""
        # Sort by income
        sorted_idx = np.argsort(incomes)

        # Compute weighted quintile boundaries
        cum_weights = np.cumsum(weights[sorted_idx])
        total_weight = cum_weights[-1]
        quintile_bounds = [total_weight * i / 5 for i in range(1, 5)]

        # Find quintile assignments
        quintile_idx = np.searchsorted(cum_weights, quintile_bounds)
        quintile_idx = np.clip(quintile_idx, 0, len(incomes) - 1)

        # Create quintile masks
        quintile_masks = []
        prev_idx = 0
        for idx in quintile_idx:
            mask = np.zeros(len(incomes), dtype=bool)
            mask[sorted_idx[prev_idx : idx + 1]] = True
            quintile_masks.append(mask)
            prev_idx = idx + 1
        # Last quintile
        mask = np.zeros(len(incomes), dtype=bool)
        mask[sorted_idx[prev_idx:]] = True
        quintile_masks.append(mask)

        # Compute metrics per quintile
        avg_income = []
        avg_tax_old = []
        avg_tax_new = []
        tax_change = []
        tax_change_pct = []
        eff_rate_old = []
        eff_rate_new = []

        for q, mask in enumerate(quintile_masks):
            if np.any(mask):
                w = weights[mask]
                inc = incomes[mask]
                t_old = old_taxes[mask]
                t_new = new_taxes[mask]

                avg_inc = np.average(inc, weights=w)
                avg_t_old = np.average(t_old, weights=w)
                avg_t_new = np.average(t_new, weights=w)

                avg_income.append(avg_inc)
                avg_tax_old.append(avg_t_old)
                avg_tax_new.append(avg_t_new)
                tax_change.append(avg_t_new - avg_t_old)
                tax_change_pct.append(
                    (avg_t_new - avg_t_old) / max(avg_t_old, 1) * 100
                )
                eff_rate_old.append(avg_t_old / max(avg_inc, 1) * 100)
                eff_rate_new.append(avg_t_new / max(avg_inc, 1) * 100)
            else:
                avg_income.append(0)
                avg_tax_old.append(0)
                avg_tax_new.append(0)
                tax_change.append(0)
                tax_change_pct.append(0)
                eff_rate_old.append(0)
                eff_rate_new.append(0)

        return {
            "avg_income": avg_income,
            "avg_tax_old": avg_tax_old,
            "avg_tax_new": avg_tax_new,
            "tax_change": tax_change,
            "tax_change_pct": tax_change_pct,
            "eff_rate_old": eff_rate_old,
            "eff_rate_new": eff_rate_new,
        }

    def format_report(self, metrics: DistributionalMetrics) -> str:
        """Format metrics as a human-readable report."""
        lines = [
            "=" * 60,
            "DISTRIBUTIONAL IMPACT REPORT",
            "=" * 60,
            "",
            "REVENUE IMPACT",
            "-" * 40,
            f"  Previous Revenue:  €{metrics.total_revenue_old:>15,.0f}",
            f"  New Revenue:       €{metrics.total_revenue_new:>15,.0f}",
            f"  Change:            €{metrics.revenue_change:>15,.0f} ({metrics.revenue_change_pct:+.2f}%)",
            "",
            "INEQUALITY METRICS",
            "-" * 40,
            f"  Gini (before):     {metrics.gini_before:.4f}",
            f"  Gini (after):      {metrics.gini_after:.4f}",
            f"  Gini Change:       {metrics.gini_change:+.4f}",
            f"  Kakwani Index:     {metrics.kakwani_index:+.4f}",
            "    (>0 = progressive, <0 = regressive)",
            "",
            "QUINTILE ANALYSIS",
            "-" * 40,
            "  Quintile | Avg Income | Eff Rate Old → New | Tax Change",
        ]

        for q in range(5):
            lines.append(
                f"  Q{q+1}       | €{metrics.quintile_avg_income[q]:>9,.0f} | "
                f"{metrics.quintile_effective_rate_old[q]:>5.1f}% → {metrics.quintile_effective_rate_new[q]:>5.1f}% | "
                f"€{metrics.quintile_tax_change[q]:>+8,.0f}"
            )

        lines.extend([
            "",
            "WINNERS & LOSERS",
            "-" * 40,
            f"  Winners (pay less):   {metrics.n_winners:>10,} ({metrics.pct_winners:.1f}%)",
            f"    Avg gain:           €{metrics.avg_gain_winners:>10,.0f}",
            f"  Losers (pay more):    {metrics.n_losers:>10,} ({metrics.pct_losers:.1f}%)",
            f"    Avg loss:           €{metrics.avg_loss_losers:>10,.0f}",
            f"  Unchanged:            {metrics.n_unchanged:>10,}",
            "",
            "INCOME PROTECTION",
            "-" * 40,
            f"  Max income drop:      {metrics.max_income_drop_pct:.2f}%",
            f"  Violating threshold:  {metrics.n_violating_threshold:,}",
            "",
            "=" * 60,
        ])

        return "\n".join(lines)
