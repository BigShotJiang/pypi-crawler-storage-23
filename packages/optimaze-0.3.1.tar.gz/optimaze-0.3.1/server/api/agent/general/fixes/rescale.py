"""Fix: coefficient rescaling via LLM-based code suggestion."""

from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, Optional

from server.api.agent.general.fixes.base import BaseFix, FixResult

if TYPE_CHECKING:
    from server.api.agent.general.analysis.base import AnalysisResult
    from server.api.agent.general.llm_advisor import LLMAdvisor
    from server.api.agent.general.repo_types import GurobiCallSite
    from server.api.agent.general.types import ProblemProfile


class RescaleFix(BaseFix):
    """
    Rescales model coefficients using LLM-generated code changes.

    Targets models with moderate-to-large coefficient ranges where
    variable or constraint scaling can improve numerical stability.
    """

    name: ClassVar[str] = "rescale"

    def apply(
        self,
        call_site: "GurobiCallSite",
        analysis_results: list["AnalysisResult"],
        llm_advisor: Optional["LLMAdvisor"],
        profile: "ProblemProfile",
    ) -> FixResult:
        if not llm_advisor:
            return FixResult(
                fix_name=self.name,
                success=False,
                description="No LLM advisor available",
                modification=None,
            )

        try:
            source = Path(call_site.file_path).read_text(encoding="utf-8")
            suggestions = llm_advisor.suggest_improvements(
                source_code=source,
                call_site=call_site,
                profile=profile,
                gurobi_log="",
                focus_category="bound_tightening",
            )
        except Exception as e:
            return FixResult(
                fix_name=self.name,
                success=False,
                description=f"LLM call failed: {e}",
                modification=None,
            )

        if not suggestions:
            return FixResult(
                fix_name=self.name,
                success=False,
                description="LLM returned no rescaling suggestions",
                modification=None,
            )

        try:
            mod = llm_advisor.apply_improvement(suggestions[0], call_site)
        except Exception as e:
            return FixResult(
                fix_name=self.name,
                success=False,
                description=f"Failed to apply LLM suggestion: {e}",
                modification=None,
            )

        return FixResult(
            fix_name=self.name,
            success=True,
            description=suggestions[0].description,
            modification=mod,
        )
