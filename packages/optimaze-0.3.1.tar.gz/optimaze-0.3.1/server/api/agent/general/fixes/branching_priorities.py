"""Fix: branching priority hints via LLM."""

from typing import ClassVar

from server.api.agent.general.fixes.base import LLMBasedFix


class BranchingPrioritiesFix(LLMBasedFix):
    """Sets BranchPriority on high-impact variables to guide the B&B search order."""

    name: ClassVar[str] = "branching_priorities"
    focus_category: ClassVar[str] = "branching_priorities"
