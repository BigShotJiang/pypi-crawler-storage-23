"""Fix: solver parameter tuning via the existing catalog + matcher."""

from typing import TYPE_CHECKING, ClassVar, Optional

from server.api.agent.general.fixes.base import BaseFix, FixResult

if TYPE_CHECKING:
    from server.api.agent.general.analysis.base import AnalysisResult
    from server.api.agent.general.llm_advisor import LLMAdvisor
    from server.api.agent.general.repo_types import GurobiCallSite
    from server.api.agent.general.types import ProblemProfile


class SolverParamFix(BaseFix):
    """
    Applies solver parameter improvements from the catalog.

    Wraps the existing ImprovementCatalog + ImprovementMatcher.
    Tracks which improvements have already been applied so each call
    returns the next best untried improvement.
    """

    name: ClassVar[str] = "solver_params"

    def __init__(self, catalog, matcher):
        self._catalog = catalog
        self._matcher = matcher
        self._applied_params: set[str] = set()

    def apply(
        self,
        call_site: "GurobiCallSite",
        analysis_results: list["AnalysisResult"],
        llm_advisor: Optional["LLMAdvisor"],
        profile: "ProblemProfile",
    ) -> FixResult:
        from server.api.agent.general.code_modifier import CodeModifier

        matches = self._matcher.get_top_improvements(profile, n=10, min_confidence=0.3)

        for imp, conf, reason in matches:
            if imp.name not in self._applied_params and imp.gurobi_params:
                self._applied_params.add(imp.name)
                try:
                    mod = CodeModifier().apply_params(call_site, imp.gurobi_params)
                except Exception as e:
                    return FixResult(
                        fix_name=f"solver_params:{imp.name}",
                        success=False,
                        description=f"Failed to apply params: {e}",
                        modification=None,
                    )
                return FixResult(
                    fix_name=f"solver_params:{imp.name}",
                    success=True,
                    description=reason,
                    modification=mod,
                )

        return FixResult(
            fix_name=self.name,
            success=False,
            description="No more untried parameter improvements available",
            modification=None,
        )
