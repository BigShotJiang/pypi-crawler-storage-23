"""Base types for the fix layer."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, Optional

if TYPE_CHECKING:
    from server.api.agent.general.analysis.base import AnalysisResult
    from server.api.agent.general.llm_advisor import LLMAdvisor
    from server.api.agent.general.repo_types import CodeModification, GurobiCallSite
    from server.api.agent.general.types import ProblemProfile


@dataclass
class FixResult:
    """Result from a single fix attempt."""

    fix_name: str
    success: bool
    description: str
    modification: Optional["CodeModification"] = None  # used to revert if worse


class BaseFix(ABC):
    """Abstract base class for all fixes."""

    name: ClassVar[str]  # must be set in subclass

    @abstractmethod
    def apply(
        self,
        call_site: "GurobiCallSite",
        analysis_results: list["AnalysisResult"],
        llm_advisor: Optional["LLMAdvisor"],
        profile: "ProblemProfile",
    ) -> FixResult:
        """
        Attempt to apply this fix to the given call site.

        Args:
            call_site: The optimize() call site to modify.
            analysis_results: Full list of analysis results for context.
            llm_advisor: Optional LLM advisor for code-based fixes.
            profile: Current model profile.

        Returns:
            FixResult with success flag and optional CodeModification for revert.
        """
        ...


class LLMBasedFix(BaseFix):
    """
    Base class for fixes that delegate entirely to the LLM advisor.

    Subclasses only need to declare `name` and `focus_category`.
    The LLM is asked for suggestions in that category; the first validated
    suggestion is applied and returned.
    """

    focus_category: ClassVar[str]  # must be set in subclass

    def apply(
        self,
        call_site: "GurobiCallSite",
        analysis_results: list["AnalysisResult"],
        llm_advisor: Optional["LLMAdvisor"],
        profile: "ProblemProfile",
    ) -> FixResult:
        if not llm_advisor:
            return FixResult(
                fix_name=self.name,
                success=False,
                description="No LLM advisor available",
                modification=None,
            )

        try:
            source = Path(call_site.file_path).read_text(encoding="utf-8")
            suggestions = llm_advisor.suggest_improvements(
                source_code=source,
                call_site=call_site,
                profile=profile,
                gurobi_log="",
                focus_category=self.focus_category,
            )
        except Exception as e:
            return FixResult(
                fix_name=self.name,
                success=False,
                description=f"LLM call failed: {e}",
                modification=None,
            )

        if not suggestions:
            return FixResult(
                fix_name=self.name,
                success=False,
                description=f"LLM returned no {self.focus_category} suggestions",
                modification=None,
            )

        try:
            mod = llm_advisor.apply_improvement(suggestions[0], call_site)
        except Exception as e:
            return FixResult(
                fix_name=self.name,
                success=False,
                description=f"Failed to apply suggestion: {e}",
                modification=None,
            )

        return FixResult(
            fix_name=self.name,
            success=True,
            description=suggestions[0].description,
            modification=mod,
        )
