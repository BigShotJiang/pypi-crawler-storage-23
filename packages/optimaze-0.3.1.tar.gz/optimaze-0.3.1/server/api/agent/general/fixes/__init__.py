"""Fixes package: applies targeted improvements to Gurobi models."""

from server.api.agent.general.fixes.base import BaseFix, FixResult
from server.api.agent.general.fixes.benders import BendersDecompositionFix
from server.api.agent.general.fixes.big_m import BigMFix
from server.api.agent.general.fixes.branching_priorities import BranchingPrioritiesFix
from server.api.agent.general.fixes.constraint_tightening import ConstraintTighteningFix
from server.api.agent.general.fixes.lazy_constraints import LazyConstraintsFix
from server.api.agent.general.fixes.new_variables import NewVariablesFix
from server.api.agent.general.fixes.rescale import RescaleFix
from server.api.agent.general.fixes.solver_params import SolverParamFix
from server.api.agent.general.fixes.symmetry_breaking import SymmetryBreakingFix
from server.api.agent.general.fixes.valid_inequalities import ValidInequalitiesFix
from server.api.agent.general.fixes.warm_starting import WarmStartingFix

__all__ = [
    "FixResult",
    "BaseFix",
    "BigMFix",
    "RescaleFix",
    "BendersDecompositionFix",
    "NewVariablesFix",
    "SolverParamFix",
    "SymmetryBreakingFix",
    "ValidInequalitiesFix",
    "BranchingPrioritiesFix",
    "WarmStartingFix",
    "LazyConstraintsFix",
    "ConstraintTighteningFix",
]
