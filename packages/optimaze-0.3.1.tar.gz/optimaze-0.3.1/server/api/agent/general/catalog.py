"""
ImprovementCatalog: Library of all available improvements.

Includes:
- Core 10 Gurobi parameters
- Formulation transforms (bounds, symmetry, reformulation)
- (Future: decomposition methods)
"""

from dataclasses import dataclass

import gurobipy as gp
from gurobipy import GRB

from server.api.agent.general.types import (
    Improvement,
    ImprovementCategory,
    ProblemProfile,
)


@dataclass
class ParameterOption:
    """A single parameter value to try."""
    name: str
    param_name: str
    value: any
    description: str
    confidence: float = 0.5


class ImprovementCatalog:
    """
    Central catalog of all improvements the agent can try.

    Improvements are organized by category:
    - SOLVER_PARAM: Gurobi parameter tuning
    - BOUND_TIGHTENING: Variable bound improvements
    - SYMMETRY: Symmetry breaking
    - REFORMULATION: Model structure changes
    """

    def __init__(self):
        self._improvements: list[Improvement] = []
        self._build_catalog()

    def _build_catalog(self):
        """Build the full catalog of improvements."""
        self._add_solver_params()
        self._add_bound_improvements()
        self._add_symmetry_improvements()
        self._add_reformulation_improvements()

    def _add_solver_params(self):
        """Add core 10 Gurobi parameter improvements."""

        # MIPFocus: Controls MIP solving strategy
        self._improvements.extend([
            Improvement(
                name="MIPFocus_feasibility",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Focus on finding feasible solutions quickly",
                gurobi_params={"MIPFocus": 1},
                confidence=0.6,
                risk=0.1,
                requires_binary=True,
            ),
            Improvement(
                name="MIPFocus_optimality",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Focus on proving optimality",
                gurobi_params={"MIPFocus": 2},
                confidence=0.5,
                risk=0.1,
                requires_binary=True,
            ),
            Improvement(
                name="MIPFocus_bound",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Focus on improving best bound",
                gurobi_params={"MIPFocus": 3},
                confidence=0.4,
                risk=0.1,
                requires_binary=True,
            ),
        ])

        # Cuts: Cut generation aggressiveness
        self._improvements.extend([
            Improvement(
                name="Cuts_off",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Disable cut generation",
                gurobi_params={"Cuts": 0},
                confidence=0.3,
                risk=0.3,
                requires_binary=True,
            ),
            Improvement(
                name="Cuts_aggressive",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Aggressive cut generation",
                gurobi_params={"Cuts": 2},
                confidence=0.6,
                risk=0.1,
                requires_binary=True,
            ),
        ])

        # Heuristics: Time spent on heuristics
        self._improvements.extend([
            Improvement(
                name="Heuristics_off",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Disable MIP heuristics",
                gurobi_params={"Heuristics": 0.0},
                confidence=0.3,
                risk=0.2,
                requires_binary=True,
            ),
            Improvement(
                name="Heuristics_aggressive",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Spend more time on heuristics",
                gurobi_params={"Heuristics": 0.5},
                confidence=0.5,
                risk=0.1,
                requires_binary=True,
            ),
        ])

        # Presolve: Presolve level
        self._improvements.extend([
            Improvement(
                name="Presolve_off",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Disable presolve (for debugging)",
                gurobi_params={"Presolve": 0},
                confidence=0.2,
                risk=0.4,
            ),
            Improvement(
                name="Presolve_aggressive",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Aggressive presolve",
                gurobi_params={"Presolve": 2},
                confidence=0.6,
                risk=0.05,
            ),
        ])

        # Method: LP algorithm
        self._improvements.extend([
            Improvement(
                name="Method_primal",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Use primal simplex",
                gurobi_params={"Method": 0},
                confidence=0.4,
                risk=0.1,
            ),
            Improvement(
                name="Method_dual",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Use dual simplex",
                gurobi_params={"Method": 1},
                confidence=0.5,
                risk=0.1,
            ),
            Improvement(
                name="Method_barrier",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Use barrier method",
                gurobi_params={"Method": 2},
                confidence=0.5,
                risk=0.1,
            ),
        ])

        # Threads: Parallelism
        self._improvements.extend([
            Improvement(
                name="Threads_1",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Single-threaded (deterministic)",
                gurobi_params={"Threads": 1},
                confidence=0.3,
                risk=0.2,
            ),
            Improvement(
                name="Threads_max",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Use all available threads",
                gurobi_params={"Threads": 0},  # 0 = auto (all)
                confidence=0.5,
                risk=0.05,
            ),
        ])

        # Symmetry: Symmetry detection
        self._improvements.extend([
            Improvement(
                name="Symmetry_off",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Disable symmetry detection",
                gurobi_params={"Symmetry": 0},
                confidence=0.3,
                risk=0.2,
                requires_binary=True,
            ),
            Improvement(
                name="Symmetry_aggressive",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Aggressive symmetry detection",
                gurobi_params={"Symmetry": 2},
                confidence=0.5,
                risk=0.1,
                requires_binary=True,
            ),
        ])

        # NodeMethod: Algorithm for node relaxations
        self._improvements.extend([
            Improvement(
                name="NodeMethod_dual",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Dual simplex for node relaxations",
                gurobi_params={"NodeMethod": 1},
                confidence=0.5,
                risk=0.1,
                requires_binary=True,
            ),
            Improvement(
                name="NodeMethod_barrier",
                category=ImprovementCategory.SOLVER_PARAM,
                description="Barrier for node relaxations",
                gurobi_params={"NodeMethod": 2},
                confidence=0.4,
                risk=0.15,
                requires_binary=True,
            ),
        ])

    def _add_bound_improvements(self):
        """Add variable bound tightening improvements."""

        self._improvements.append(
            Improvement(
                name="tighten_bounds",
                category=ImprovementCategory.BOUND_TIGHTENING,
                description="Tighten variable bounds using constraint propagation",
                apply_fn=self._apply_bound_tightening,
                confidence=0.5,
                risk=0.1,
                complexity="medium",
            )
        )

    def _add_symmetry_improvements(self):
        """Add symmetry breaking improvements."""

        self._improvements.append(
            Improvement(
                name="add_symmetry_breaking",
                category=ImprovementCategory.SYMMETRY,
                description="Add symmetry-breaking constraints for binary variables",
                apply_fn=self._apply_symmetry_breaking,
                confidence=0.6,
                risk=0.15,
                requires_binary=True,
                complexity="medium",
            )
        )

    def _add_reformulation_improvements(self):
        """Add reformulation improvements."""

        self._improvements.extend([
            Improvement(
                name="indicator_to_bigm",
                category=ImprovementCategory.REFORMULATION,
                description="Convert indicator constraints to big-M formulation",
                apply_fn=self._apply_indicator_to_bigm,
                confidence=0.4,
                risk=0.2,
                complexity="high",
            ),
            Improvement(
                name="disaggregate_constraints",
                category=ImprovementCategory.REFORMULATION,
                description="Disaggregate aggregated constraints for tighter LP",
                apply_fn=self._apply_disaggregation,
                confidence=0.5,
                risk=0.1,
                complexity="high",
            ),
        ])

    # === Apply functions for formulation transforms ===

    @staticmethod
    def _apply_bound_tightening(model: gp.Model) -> gp.Model:
        """Apply simple bound tightening based on constraints."""
        # Run Gurobi's presolve to get tighter bounds, then create new model
        model_copy = model.copy()
        model_copy.Params.OutputFlag = 0
        model_copy.Params.Presolve = 2  # Aggressive presolve

        # Get bounds after presolve
        model_copy.presolve()

        return model_copy

    @staticmethod
    def _apply_symmetry_breaking(model: gp.Model) -> gp.Model:
        """Add basic symmetry-breaking constraints."""
        model_copy = model.copy()

        # Find binary variables with identical properties
        binary_vars = [v for v in model_copy.getVars() if v.VType == GRB.BINARY]

        # Group by (obj coefficient, bounds)
        groups: dict[tuple, list] = {}
        for var in binary_vars:
            key = (round(var.Obj, 4), round(var.LB, 2), round(var.UB, 2))
            if key not in groups:
                groups[key] = []
            groups[key].append(var)

        # Add ordering constraints for large groups
        for key, vars_list in groups.items():
            if len(vars_list) > 5:
                # Add x_i >= x_{i+1} constraints (lexicographic ordering)
                for i in range(min(len(vars_list) - 1, 10)):  # Limit to avoid too many
                    model_copy.addConstr(
                        vars_list[i] >= vars_list[i + 1],
                        name=f"sym_break_{i}"
                    )

        model_copy.update()
        return model_copy

    @staticmethod
    def _apply_indicator_to_bigm(model: gp.Model) -> gp.Model:
        """Convert indicator constraints to big-M (experimental)."""
        # This is complex and model-specific
        # For now, just return copy - would need deeper analysis
        return model.copy()

    @staticmethod
    def _apply_disaggregation(model: gp.Model) -> gp.Model:
        """Disaggregate constraints (placeholder)."""
        # This requires problem-specific knowledge
        return model.copy()

    # === Catalog access methods ===

    def get_all(self) -> list[Improvement]:
        """Get all improvements in the catalog."""
        return self._improvements.copy()

    def get_by_category(self, category: ImprovementCategory) -> list[Improvement]:
        """Get improvements by category."""
        return [imp for imp in self._improvements if imp.category == category]

    def get_solver_params(self) -> list[Improvement]:
        """Get only solver parameter improvements."""
        return self.get_by_category(ImprovementCategory.SOLVER_PARAM)

    def get_transforms(self) -> list[Improvement]:
        """Get formulation transform improvements."""
        categories = [
            ImprovementCategory.BOUND_TIGHTENING,
            ImprovementCategory.SYMMETRY,
            ImprovementCategory.REFORMULATION,
        ]
        return [imp for imp in self._improvements if imp.category in categories]

    def filter_for_profile(self, profile: ProblemProfile) -> list[Improvement]:
        """Filter improvements that are applicable to this problem profile."""
        applicable = []

        has_binary = profile.n_binary > 0
        has_integer = profile.n_integer > 0

        for imp in self._improvements:
            # Check requirements
            if imp.requires_binary and not has_binary:
                continue
            if imp.requires_integer and not has_integer:
                continue
            if imp.min_vars > 0 and profile.n_vars < imp.min_vars:
                continue
            if imp.min_constrs > 0 and profile.n_constrs < imp.min_constrs:
                continue

            applicable.append(imp)

        return applicable

    def __len__(self) -> int:
        return len(self._improvements)

    def __iter__(self):
        return iter(self._improvements)
